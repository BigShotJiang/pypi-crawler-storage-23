"""Local MITM proxy client."""

import http.client
import logging
import socket
import ssl
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from typing import Protocol
from urllib.parse import urlparse

from owl_proxy.certs.domain import DomainCertGenerator
from owl_proxy.client.forwarder import DirectForwarder, RemoteForwarder
from owl_proxy.config import CertConfig, ClientConfig

logger = logging.getLogger(__name__)


class Forwarder(Protocol):
    def forward(
        self,
        url: str,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: bytes | None = None,
    ) -> tuple[int, dict[str, str], bytes]: ...


class ClientHandler(BaseHTTPRequestHandler):
    """Local proxy handler that intercepts HTTPS via MITM."""

    cert_generator: DomainCertGenerator
    forwarder: Forwarder
    client_config: ClientConfig

    def log_message(self, format: str, *args: object) -> None:
        logger.debug("%s - %s", self.address_string(), format % args)

    # ── CONNECT (HTTPS MITM) ────────────────────────────────────

    def do_CONNECT(self) -> None:
        try:
            host, port = self._parse_host_port(self.path, default_port=443)
            logger.info("CONNECT %s:%d", host, port)

            self.send_response(200, "Connection Established")
            self.end_headers()

            ssl_ctx = self.cert_generator.create_ssl_context(host)
            try:
                ssl_sock = ssl_ctx.wrap_socket(self.connection, server_side=True)
            except ssl.SSLError as e:
                logger.error("SSL handshake failed for %s: %s", host, e)
                return

            self._handle_mitm(ssl_sock, host, port)

        except Exception as e:
            logger.error("CONNECT error: %s", e)

    def _handle_mitm(
        self, ssl_sock: ssl.SSLSocket, host: str, port: int
    ) -> None:
        try:
            ssl_sock.settimeout(self.client_config.timeout)

            data = b""
            while True:
                chunk = ssl_sock.recv(8192)
                if not chunk:
                    return
                data += chunk
                if b"\r\n\r\n" in data:
                    break

            header_end = data.index(b"\r\n\r\n")
            header_text = data[:header_end].decode("utf-8", errors="replace")
            remaining = data[header_end + 4:]

            lines = header_text.split("\r\n")
            if not lines:
                return

            parts = lines[0].split(" ", 2)
            if len(parts) < 2:
                return
            method, path = parts[0], parts[1]

            headers: dict[str, str] = {}
            content_length = 0
            for line in lines[1:]:
                if ": " in line:
                    k, v = line.split(": ", 1)
                    headers[k] = v
                    if k.lower() == "content-length":
                        content_length = int(v)

            body = remaining
            while len(body) < content_length:
                body += ssl_sock.recv(content_length - len(body))

            scheme = "https"
            url = f"{scheme}://{host}:{port}{path}" if port != 443 else f"{scheme}://{host}{path}"

            status, resp_headers, resp_body = self.forwarder.forward(
                url=url,
                method=method,
                headers=headers,
                body=body if body else None,
            )

            reason = http.client.responses.get(status, "Unknown")
            resp = f"HTTP/1.1 {status} {reason}\r\n"
            for k, v in resp_headers.items():
                resp += f"{k}: {v}\r\n"
            resp += f"Content-Length: {len(resp_body)}\r\n\r\n"

            ssl_sock.sendall(resp.encode() + resp_body)

        except ssl.SSLError as e:
            logger.debug("SSL error in MITM: %s", e)
        except socket.timeout:
            logger.debug("Socket timeout in MITM")
        except Exception as e:
            logger.error("MITM error: %s", e)
        finally:
            try:
                ssl_sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                ssl_sock.close()
            except Exception:
                pass

    # ── HTTP methods ─────────────────────────────────────────────

    def do_GET(self) -> None:
        self._handle_http("GET")

    def do_POST(self) -> None:
        self._handle_http("POST")

    def do_PUT(self) -> None:
        self._handle_http("PUT")

    def do_DELETE(self) -> None:
        self._handle_http("DELETE")

    def do_HEAD(self) -> None:
        self._handle_http("HEAD")

    def do_OPTIONS(self) -> None:
        self._handle_http("OPTIONS")

    def do_PATCH(self) -> None:
        self._handle_http("PATCH")

    def _handle_http(self, method: str) -> None:
        try:
            url = self.path
            parsed = urlparse(url)
            if not parsed.scheme:
                # Serve PAC file if enabled
                if self.client_config.serve_pac and self.path == "/proxy.pac":
                    self._serve_pac()
                    return
                self.send_error(400, "Expected absolute URL for proxy request")
                return

            logger.info("HTTP %s %s", method, url)

            headers = {
                k: v
                for k, v in self.headers.items()
                if k.lower() not in (
                    "proxy-connection", "proxy-authorization", "connection", "keep-alive"
                )
            }

            body = None
            cl = self.headers.get("Content-Length")
            if cl:
                body = self.rfile.read(int(cl))

            status, resp_headers, resp_body = self.forwarder.forward(
                url=url, method=method, headers=headers, body=body,
            )

            self.send_response(status)
            for k, v in resp_headers.items():
                self.send_header(k, v)
            self.send_header("Content-Length", str(len(resp_body)))
            self.end_headers()
            self.wfile.write(resp_body)

        except Exception as e:
            logger.error("HTTP proxy error: %s", e)
            self.send_error(500, "Internal Server Error")

    def _serve_pac(self) -> None:
        port = self.client_config.listen_port
        host = self.client_config.listen_host
        pac = f"""function FindProxyForURL(url, host) {{
    if (isPlainHostName(host) ||
        shExpMatch(host, "localhost") ||
        shExpMatch(host, "127.0.0.1") ||
        shExpMatch(host, "*.local")) {{
        return "DIRECT";
    }}
    return "PROXY {host}:{port}; DIRECT";
}}
"""
        body = pac.encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/x-ns-proxy-autoconfig")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    @staticmethod
    def _parse_host_port(address: str, default_port: int = 80) -> tuple[str, int]:
        if ":" in address:
            host, port_str = address.rsplit(":", 1)
            return host, int(port_str)
        return address, default_port


class ThreadedClientServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def run_client(
    client_config: ClientConfig | None = None,
    cert_config: CertConfig | None = None,
) -> None:
    """Start the Owl Proxy client (local MITM proxy)."""
    if client_config is None:
        client_config = ClientConfig()
        client_config.load_from_env()
    if cert_config is None:
        cert_config = CertConfig()

    # Cert generator
    cert_gen = DomainCertGenerator(
        ca_cert_path=cert_config.ca_cert_path,
        ca_key_path=cert_config.ca_key_path,
        cache_dir=cert_config.domain_cache_dir,
    )

    # Forwarder
    forwarder: Forwarder
    if client_config.remote_server and not client_config.direct:
        forwarder = RemoteForwarder(
            remote_url=client_config.remote_server,
            username=client_config.auth_username,
            password=client_config.auth_password,
            token=client_config.auth_token,
            timeout=client_config.timeout,
        )
        mode = f"remote → {client_config.remote_server}"
    else:
        forwarder = DirectForwarder(timeout=client_config.timeout)
        mode = "direct"

    # Inject into handler
    ClientHandler.cert_generator = cert_gen
    ClientHandler.forwarder = forwarder
    ClientHandler.client_config = client_config

    addr = (client_config.listen_host, client_config.listen_port)
    httpd = ThreadedClientServer(addr, ClientHandler)

    print(f"Owl Proxy client listening on {client_config.listen_host}:{client_config.listen_port}")
    print(f"  Mode: {mode}")
    print(f"  CA certificate: {cert_config.ca_cert_path}")
    if client_config.serve_pac:
        print(f"  PAC file: http://{client_config.listen_host}:{client_config.listen_port}/proxy.pac")
    print("Press Ctrl+C to stop")

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
        httpd.shutdown()
