"""Request forwarding — either to a remote Owl Proxy server or direct fetch."""

import base64
import logging
from typing import Any

import requests

from owl_proxy.server.handler import fetch_url as direct_fetch

logger = logging.getLogger(__name__)


class DirectForwarder:
    """Fetches URLs directly (no remote server)."""

    def __init__(self, timeout: int = 60) -> None:
        self._timeout = timeout

    def forward(
        self,
        url: str,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: bytes | None = None,
    ) -> tuple[int, dict[str, str], bytes]:
        result = direct_fetch(
            url=url, method=method, headers=headers, body=body, timeout=self._timeout,
        )
        return result["status"], result["headers"], result["body"]


class RemoteForwarder:
    """Forwards requests to a remote Owl Proxy server."""

    def __init__(
        self,
        remote_url: str,
        username: str = "",
        password: str = "",
        token: str = "",
        timeout: int = 60,
    ) -> None:
        self._remote_url = remote_url.rstrip("/")
        self._username = username
        self._password = password
        self._token = token
        self._timeout = timeout

    def _auth_header(self) -> str:
        if self._token:
            return f"Bearer {self._token}"
        if self._username:
            creds = f"{self._username}:{self._password}"
            return f"Basic {base64.b64encode(creds.encode()).decode()}"
        return ""

    def forward(
        self,
        url: str,
        method: str = "GET",
        headers: dict[str, str] | None = None,
        body: bytes | None = None,
    ) -> tuple[int, dict[str, str], bytes]:
        """Forward a request through the remote proxy server."""
        payload: dict[str, Any] = {
            "url": url,
            "method": method,
            "headers": headers or {},
        }
        if body:
            payload["body"] = base64.b64encode(body).decode("ascii")

        req_headers: dict[str, str] = {"Content-Type": "application/json"}
        auth = self._auth_header()
        if auth:
            req_headers["Proxy-Authorization"] = auth

        try:
            resp = requests.post(
                f"{self._remote_url}/proxy",
                json=payload,
                headers=req_headers,
                timeout=self._timeout,
            )

            if resp.status_code == 407:
                logger.error("Remote server returned 407 — check credentials")
                return 407, {}, b"Proxy authentication failed"

            if resp.status_code != 200:
                logger.error("Remote server returned %d: %s", resp.status_code, resp.text[:200])
                return 502, {}, b"Bad Gateway - remote server error"

            data = resp.json()
            status = data.get("status", 502)
            resp_headers = data.get("headers", {})
            body_b64 = data.get("body", "")
            resp_body = base64.b64decode(body_b64) if body_b64 else b""

            return status, resp_headers, resp_body

        except requests.exceptions.Timeout:
            logger.error("Timeout connecting to remote server")
            return 504, {}, b"Gateway Timeout"
        except requests.exceptions.ConnectionError as e:
            logger.error("Cannot connect to remote server: %s", e)
            return 502, {}, b"Bad Gateway - cannot reach remote server"
        except Exception as e:
            logger.error("Remote forward error: %s", e)
            return 502, {}, b"Bad Gateway"
