"""Owl Proxy client mode — local MITM proxy."""

from owl_proxy.client.proxy import run_client

__all__ = ["run_client"]
