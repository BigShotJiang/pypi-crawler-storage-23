"""Allow running as `python -m owl_proxy`."""

from owl_proxy.cli import main

main()
