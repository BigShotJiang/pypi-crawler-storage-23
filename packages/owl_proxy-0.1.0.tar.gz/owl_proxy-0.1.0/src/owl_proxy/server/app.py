"""Standalone proxy server — runs anywhere, replaces GAE backend."""

import base64
import http.client
import json
import logging
import socket
import ssl
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from socketserver import ThreadingMixIn
from urllib.parse import urlparse

from owl_proxy.certs.domain import DomainCertGenerator
from owl_proxy.config import CertConfig, ServerConfig
from owl_proxy.server.auth import Authenticator
from owl_proxy.server.handler import fetch_url

logger = logging.getLogger(__name__)


class ProxyHandler(BaseHTTPRequestHandler):
    """Handles both HTTP and HTTPS CONNECT proxy requests."""

    # Set by run_server before starting
    authenticator: Authenticator
    cert_generator: DomainCertGenerator
    server_config: ServerConfig

    def log_message(self, format: str, *args: object) -> None:
        logger.debug("%s - %s", self.address_string(), format % args)

    # ── Auth ──────────────────────────────────────────────────────

    def _check_auth(self) -> bool:
        if not self.authenticator.enabled:
            return True

        auth = self.headers.get("Proxy-Authorization") or self.headers.get("Authorization")
        if self.authenticator.check(auth):
            return True

        self.send_response(407)
        self.send_header(
            "Proxy-Authenticate", self.authenticator.www_authenticate_header()
        )
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(b"Proxy authentication required")
        return False

    # ── CONNECT (HTTPS) ──────────────────────────────────────────

    def do_CONNECT(self) -> None:
        if not self._check_auth():
            return

        try:
            host, port = self._parse_host_port(self.path, default_port=443)
            logger.info("CONNECT %s:%d", host, port)

            self.send_response(200, "Connection Established")
            self.end_headers()

            ssl_ctx = self.cert_generator.create_ssl_context(host)
            try:
                ssl_sock = ssl_ctx.wrap_socket(self.connection, server_side=True)
            except ssl.SSLError as e:
                logger.error("SSL handshake failed for %s: %s", host, e)
                return

            self._handle_mitm(ssl_sock, host, port)

        except Exception as e:
            logger.error("CONNECT error: %s", e)

    def _handle_mitm(
        self, ssl_sock: ssl.SSLSocket, host: str, port: int
    ) -> None:
        """Read decrypted HTTP from the MITM socket and proxy it."""
        try:
            ssl_sock.settimeout(self.server_config.timeout)

            # Read request headers
            data = b""
            while True:
                chunk = ssl_sock.recv(8192)
                if not chunk:
                    return
                data += chunk
                if b"\r\n\r\n" in data:
                    break

            header_end = data.index(b"\r\n\r\n")
            header_text = data[:header_end].decode("utf-8", errors="replace")
            remaining = data[header_end + 4:]

            lines = header_text.split("\r\n")
            if not lines:
                return

            parts = lines[0].split(" ", 2)
            if len(parts) < 2:
                return
            method, path = parts[0], parts[1]

            headers: dict[str, str] = {}
            content_length = 0
            for line in lines[1:]:
                if ": " in line:
                    k, v = line.split(": ", 1)
                    headers[k] = v
                    if k.lower() == "content-length":
                        content_length = int(v)

            body = remaining
            while len(body) < content_length:
                body += ssl_sock.recv(content_length - len(body))

            scheme = "https"
            url = f"{scheme}://{host}:{port}{path}" if port != 443 else f"{scheme}://{host}{path}"

            result = fetch_url(
                url=url,
                method=method,
                headers=headers,
                body=body if body else None,
                timeout=self.server_config.timeout,
                max_response_size=self.server_config.max_response_size,
            )

            status = result["status"]
            resp_body: bytes = result["body"]
            reason = http.client.responses.get(status, "Unknown")
            resp = f"HTTP/1.1 {status} {reason}\r\n"
            for k, v in result["headers"].items():
                resp += f"{k}: {v}\r\n"
            resp += f"Content-Length: {len(resp_body)}\r\n\r\n"

            ssl_sock.sendall(resp.encode() + resp_body)

        except ssl.SSLError as e:
            logger.debug("SSL error in MITM: %s", e)
        except socket.timeout:
            logger.debug("Socket timeout in MITM")
        except Exception as e:
            logger.error("MITM error: %s", e)
        finally:
            try:
                ssl_sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                ssl_sock.close()
            except Exception:
                pass

    # ── HTTP methods ─────────────────────────────────────────────

    def do_GET(self) -> None:
        self._handle_http("GET")

    def do_POST(self) -> None:
        self._handle_http("POST")

    def do_PUT(self) -> None:
        self._handle_http("PUT")

    def do_DELETE(self) -> None:
        self._handle_http("DELETE")

    def do_HEAD(self) -> None:
        self._handle_http("HEAD")

    def do_OPTIONS(self) -> None:
        self._handle_http("OPTIONS")

    def do_PATCH(self) -> None:
        self._handle_http("PATCH")

    def _handle_http(self, method: str) -> None:
        if not self._check_auth():
            return

        try:
            url = self.path
            parsed = urlparse(url)
            if not parsed.scheme:
                self.send_error(400, "Expected absolute URL for proxy request")
                return

            logger.info("HTTP %s %s", method, url)

            headers = {
                k: v
                for k, v in self.headers.items()
                if k.lower() not in ("proxy-connection", "proxy-authorization", "connection", "keep-alive")
            }

            body = None
            cl = self.headers.get("Content-Length")
            if cl:
                body = self.rfile.read(int(cl))

            result = fetch_url(
                url=url,
                method=method,
                headers=headers,
                body=body,
                timeout=self.server_config.timeout,
                max_response_size=self.server_config.max_response_size,
            )

            self.send_response(result["status"])
            for k, v in result["headers"].items():
                self.send_header(k, v)
            resp_body: bytes = result["body"]
            self.send_header("Content-Length", str(len(resp_body)))
            self.end_headers()
            self.wfile.write(resp_body)

        except Exception as e:
            logger.error("HTTP proxy error: %s", e)
            self.send_error(500, "Internal Server Error")

    # ── Helpers ───────────────────────────────────────────────────

    @staticmethod
    def _parse_host_port(address: str, default_port: int = 80) -> tuple[str, int]:
        if ":" in address:
            host, port_str = address.rsplit(":", 1)
            return host, int(port_str)
        return address, default_port


class ThreadedProxyServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def run_server(
    server_config: ServerConfig | None = None,
    cert_config: CertConfig | None = None,
) -> None:
    """Start the Owl Proxy server."""
    if server_config is None:
        server_config = ServerConfig()
        server_config.load_from_env()
    if cert_config is None:
        cert_config = CertConfig()

    # Auth
    authenticator = Authenticator(
        username=server_config.auth_username,
        password=server_config.auth_password,
        token=server_config.auth_token,
        no_auth=server_config.no_auth,
    )

    # Certs
    cert_gen = DomainCertGenerator(
        ca_cert_path=cert_config.ca_cert_path,
        ca_key_path=cert_config.ca_key_path,
        cache_dir=cert_config.domain_cache_dir,
    )

    # Inject into handler class
    ProxyHandler.authenticator = authenticator
    ProxyHandler.cert_generator = cert_gen
    ProxyHandler.server_config = server_config

    addr = (server_config.host, server_config.port)
    httpd = ThreadedProxyServer(addr, ProxyHandler)

    auth_status = "disabled" if server_config.no_auth else "enabled"
    if authenticator.enabled:
        auth_status = "basic" if server_config.auth_username else "bearer"

    print(f"Owl Proxy server listening on {server_config.host}:{server_config.port}")
    print(f"  Authentication: {auth_status}")
    print(f"  CA certificate: {cert_config.ca_cert_path}")
    print(f"  Domain cert cache: {cert_config.domain_cache_dir}")
    print("Press Ctrl+C to stop")

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
        httpd.shutdown()
