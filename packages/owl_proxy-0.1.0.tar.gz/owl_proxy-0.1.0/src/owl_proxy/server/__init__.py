"""Owl Proxy server mode — standalone proxy server."""

from owl_proxy.server.app import run_server

__all__ = ["run_server"]
