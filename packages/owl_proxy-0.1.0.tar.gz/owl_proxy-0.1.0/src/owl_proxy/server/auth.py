"""Authentication for the proxy server."""

import base64
import hashlib
import hmac
import logging

logger = logging.getLogger(__name__)


class Authenticator:
    """Validates proxy authentication credentials."""

    def __init__(
        self,
        username: str = "",
        password: str = "",
        token: str = "",
        no_auth: bool = False,
    ) -> None:
        self._username = username
        self._password = password
        self._token = token
        self._no_auth = no_auth

    @property
    def enabled(self) -> bool:
        return not self._no_auth and bool(self._username or self._token)

    def check(self, auth_header: str | None) -> bool:
        """Validate an Authorization or Proxy-Authorization header."""
        if self._no_auth:
            return True

        if not auth_header:
            return not self.enabled

        parts = auth_header.split(" ", 1)
        if len(parts) != 2:
            return False

        scheme, credentials = parts[0].lower(), parts[1]

        if scheme == "basic" and self._username:
            return self._check_basic(credentials)
        elif scheme == "bearer" and self._token:
            return self._check_bearer(credentials)

        return False

    def _check_basic(self, encoded: str) -> bool:
        try:
            decoded = base64.b64decode(encoded).decode("utf-8")
            username, password = decoded.split(":", 1)
            return (
                hmac.compare_digest(username, self._username)
                and hmac.compare_digest(password, self._password)
            )
        except (ValueError, UnicodeDecodeError):
            return False

    def _check_bearer(self, token: str) -> bool:
        return hmac.compare_digest(token.strip(), self._token)

    def www_authenticate_header(self) -> str:
        """Return the appropriate WWW-Authenticate / Proxy-Authenticate value."""
        if self._token:
            return 'Bearer realm="Owl Proxy"'
        return 'Basic realm="Owl Proxy"'
