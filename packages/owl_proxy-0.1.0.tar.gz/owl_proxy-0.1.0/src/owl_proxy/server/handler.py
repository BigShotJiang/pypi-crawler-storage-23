"""Direct URL fetching for server mode (replaces GAE backend)."""

import logging
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from owl_proxy.utils import (
    decompress_body,
    filter_request_headers,
    filter_response_headers,
    is_valid_proxy_url,
)

logger = logging.getLogger(__name__)

_session: requests.Session | None = None


def _get_session() -> requests.Session:
    global _session
    if _session is None:
        _session = requests.Session()
        retry = Retry(
            total=2,
            backoff_factor=0.5,
            status_forcelist=[502, 503, 504],
            allowed_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"],
        )
        adapter = HTTPAdapter(max_retries=retry, pool_connections=20, pool_maxsize=20)
        _session.mount("http://", adapter)
        _session.mount("https://", adapter)
    return _session


def fetch_url(
    url: str,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: bytes | None = None,
    timeout: int = 120,
    max_response_size: int = 50 * 1024 * 1024,
) -> dict[str, Any]:
    """
    Fetch a URL directly and return status, headers, body.

    This is the core fetch used in server mode — no GAE dependency.
    """
    if not is_valid_proxy_url(url):
        return {
            "status": 403,
            "headers": {"Content-Type": "text/plain"},
            "body": b"Blocked: private/invalid URL",
        }

    try:
        session = _get_session()
        filtered = filter_request_headers(headers or {})

        response = session.request(
            method=method.upper(),
            url=url,
            headers=filtered,
            data=body,
            timeout=timeout,
            allow_redirects=True,
            stream=True,
        )

        content = b""
        for chunk in response.iter_content(chunk_size=8192):
            content += chunk
            if len(content) > max_response_size:
                return {
                    "status": 413,
                    "headers": {"Content-Type": "text/plain"},
                    "body": b"Response too large",
                }

        encoding = response.headers.get("Content-Encoding")
        if encoding:
            content = decompress_body(content, encoding)

        return {
            "status": response.status_code,
            "headers": filter_response_headers(dict(response.headers)),
            "body": content,
        }

    except requests.exceptions.Timeout:
        return {
            "status": 504,
            "headers": {"Content-Type": "text/plain"},
            "body": b"Gateway Timeout",
        }
    except requests.exceptions.ConnectionError as e:
        logger.error("Connection error fetching %s: %s", url, e)
        return {
            "status": 502,
            "headers": {"Content-Type": "text/plain"},
            "body": b"Bad Gateway - connection failed",
        }
    except requests.exceptions.RequestException as e:
        logger.error("Request error fetching %s: %s", url, e)
        return {
            "status": 502,
            "headers": {"Content-Type": "text/plain"},
            "body": f"Bad Gateway - {e}".encode(),
        }
