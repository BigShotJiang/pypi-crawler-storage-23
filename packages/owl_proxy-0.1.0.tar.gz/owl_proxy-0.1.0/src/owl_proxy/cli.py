"""CLI entrypoint for owl-proxy."""

import logging
import sys
from pathlib import Path

import click

from owl_proxy import __version__
from owl_proxy.config import CertConfig, ClientConfig, ServerConfig


@click.group()
@click.version_option(__version__, prog_name="owl-proxy")
@click.option("--verbose", "-v", is_flag=True, help="Enable debug logging")
def main(verbose: bool) -> None:
    """Owl Proxy — MITM proxy with CA certificate management."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )


# ── cert ─────────────────────────────────────────────────────────

@main.group()
def cert() -> None:
    """Certificate management commands."""


@cert.command("generate")
@click.option("--output", "-o", type=click.Path(), default=None, help="Output directory")
@click.option("--key-size", type=click.Choice(["2048", "4096"]), default="4096")
@click.option("--validity-days", type=int, default=3650, help="Certificate validity in days")
@click.option("--organization", default="Owl Proxy CA")
@click.option("--common-name", default="Owl Proxy Root CA")
def cert_generate(
    output: str | None,
    key_size: str,
    validity_days: int,
    organization: str,
    common_name: str,
) -> None:
    """Generate a new root CA certificate."""
    from owl_proxy.certs.ca import generate_ca

    cfg = CertConfig()
    out_dir = Path(output) if output else cfg.data_dir

    cert_path, key_path = generate_ca(
        output_dir=out_dir,
        key_size=int(key_size),
        validity_days=validity_days,
        organization=organization,
        common_name=common_name,
    )

    click.echo(f"CA certificate: {cert_path}")
    click.echo(f"CA private key: {key_path}")
    click.echo()
    click.echo("Next: run 'owl-proxy cert install' to trust it system-wide,")
    click.echo("or distribute ca.crt to clients manually.")


@cert.command("install")
@click.option("--cert", "-c", "cert_path", type=click.Path(exists=True), default=None)
@click.option("--dry-run", is_flag=True, help="Show commands without executing")
def cert_install(cert_path: str | None, dry_run: bool) -> None:
    """Install the CA certificate into the OS trust store."""
    from owl_proxy.certs.trust import install_ca_to_trust_store

    cfg = CertConfig()
    path = Path(cert_path) if cert_path else cfg.ca_cert_path

    if not path.exists():
        click.echo(f"Certificate not found: {path}", err=True)
        click.echo("Run 'owl-proxy cert generate' first.", err=True)
        sys.exit(1)

    if dry_run:
        click.echo("Commands that would be executed:")

    commands = install_ca_to_trust_store(path, dry_run=dry_run)
    for cmd in commands:
        if dry_run:
            click.echo(f"  {cmd}")
        else:
            click.echo(f"Executed: {cmd}")

    if not dry_run:
        click.echo("CA certificate installed successfully.")


@cert.command("uninstall")
@click.option("--dry-run", is_flag=True, help="Show commands without executing")
def cert_uninstall(dry_run: bool) -> None:
    """Remove the CA certificate from the OS trust store."""
    from owl_proxy.certs.trust import uninstall_ca_from_trust_store

    commands = uninstall_ca_from_trust_store(dry_run=dry_run)
    for cmd in commands:
        if dry_run:
            click.echo(f"  {cmd}")
        else:
            click.echo(f"Executed: {cmd}")


@cert.command("info")
@click.option("--cert", "-c", "cert_path", type=click.Path(exists=True), default=None)
def cert_info(cert_path: str | None) -> None:
    """Show CA certificate details."""
    from owl_proxy.certs.ca import load_ca_info

    cfg = CertConfig()
    path = Path(cert_path) if cert_path else cfg.ca_cert_path

    if not path.exists():
        click.echo(f"Certificate not found: {path}", err=True)
        click.echo("Run 'owl-proxy cert generate' first.", err=True)
        sys.exit(1)

    info = load_ca_info(path)
    click.echo(f"  Common Name:  {info['common_name']}")
    click.echo(f"  Organization: {info['organization']}")
    click.echo(f"  Valid from:   {info['not_before']}")
    click.echo(f"  Valid until:  {info['not_after']}")
    click.echo(f"  Serial:       {info['serial']}")
    click.echo(f"  SHA-256:      {info['fingerprint_sha256']}")
    click.echo(f"  File:         {path}")


@cert.command("export")
@click.option("--cert", "-c", "cert_path", type=click.Path(exists=True), default=None)
@click.option("--dest", "-d", type=click.Path(), required=True, help="Destination path")
def cert_export(cert_path: str | None, dest: str) -> None:
    """Copy the CA certificate to a given path for sharing."""
    import shutil

    cfg = CertConfig()
    src = Path(cert_path) if cert_path else cfg.ca_cert_path

    if not src.exists():
        click.echo(f"Certificate not found: {src}", err=True)
        sys.exit(1)

    shutil.copy2(src, dest)
    click.echo(f"CA certificate copied to {dest}")


# ── server ───────────────────────────────────────────────────────

@main.command()
@click.option("--host", "-H", default="0.0.0.0", help="Bind address")
@click.option("--port", "-p", type=int, default=8443, help="Bind port")
@click.option("--auth", help="Basic auth as user:pass")
@click.option("--auth-token", help="Bearer token for auth")
@click.option("--no-auth", is_flag=True, help="Disable authentication")
@click.option("--ca-cert", type=click.Path(exists=True), default=None, help="CA certificate path")
@click.option("--ca-key", type=click.Path(exists=True), default=None, help="CA private key path")
@click.option("--timeout", type=int, default=120, help="Request timeout in seconds")
def server(
    host: str,
    port: int,
    auth: str | None,
    auth_token: str | None,
    no_auth: bool,
    ca_cert: str | None,
    ca_key: str | None,
    timeout: int,
) -> None:
    """Start the proxy server (run on your Pi, VPS, etc.)."""
    from owl_proxy.server.app import run_server

    server_cfg = ServerConfig(
        host=host,
        port=port,
        no_auth=no_auth,
        timeout=timeout,
    )
    server_cfg.load_from_env()

    # CLI overrides env
    if auth:
        parts = auth.split(":", 1)
        server_cfg.auth_username = parts[0]
        server_cfg.auth_password = parts[1] if len(parts) > 1 else ""
    if auth_token:
        server_cfg.auth_token = auth_token

    cert_cfg = CertConfig()
    if ca_cert:
        cert_cfg.data_dir = Path(ca_cert).parent
    if ca_key:
        # Validate the key is in the same dir or override
        pass

    run_server(server_config=server_cfg, cert_config=cert_cfg)


# ── client ───────────────────────────────────────────────────────

@main.command()
@click.option("--host", "-H", default="127.0.0.1", help="Listen address")
@click.option("--port", "-p", type=int, default=8080, help="Listen port")
@click.option("--remote", "-r", default="", help="Remote Owl Proxy server URL")
@click.option("--auth", help="Auth for remote server as user:pass")
@click.option("--auth-token", help="Bearer token for remote server")
@click.option("--direct", is_flag=True, help="Fetch URLs directly (no remote server)")
@click.option("--ca-cert", type=click.Path(exists=True), default=None, help="CA certificate path")
@click.option("--timeout", type=int, default=60, help="Request timeout in seconds")
@click.option("--pac", is_flag=True, help="Serve PAC file at /proxy.pac")
def client(
    host: str,
    port: int,
    remote: str,
    auth: str | None,
    auth_token: str | None,
    direct: bool,
    ca_cert: str | None,
    timeout: int,
    pac: bool,
) -> None:
    """Start the local proxy client (MITM proxy on your machine)."""
    from owl_proxy.client.proxy import run_client

    client_cfg = ClientConfig(
        listen_host=host,
        listen_port=port,
        remote_server=remote,
        direct=direct,
        timeout=timeout,
        serve_pac=pac,
    )
    client_cfg.load_from_env()

    # CLI overrides env
    if auth:
        parts = auth.split(":", 1)
        client_cfg.auth_username = parts[0]
        client_cfg.auth_password = parts[1] if len(parts) > 1 else ""
    if auth_token:
        client_cfg.auth_token = auth_token

    cert_cfg = CertConfig()
    if ca_cert:
        cert_cfg.data_dir = Path(ca_cert).parent

    run_client(client_config=client_cfg, cert_config=cert_cfg)
