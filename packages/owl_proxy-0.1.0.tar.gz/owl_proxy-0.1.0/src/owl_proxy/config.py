"""Unified configuration for Owl Proxy."""

import os
from dataclasses import dataclass, field
from pathlib import Path


def default_data_dir() -> Path:
    """Return the default data directory, respecting XDG on Linux."""
    xdg = os.environ.get("XDG_DATA_HOME")
    if xdg:
        return Path(xdg) / "owl-proxy"
    return Path.home() / ".owl-proxy"


@dataclass
class CertConfig:
    """Certificate configuration."""

    data_dir: Path = field(default_factory=default_data_dir)

    @property
    def ca_cert_path(self) -> Path:
        return self.data_dir / "ca.crt"

    @property
    def ca_key_path(self) -> Path:
        return self.data_dir / "ca.key"

    @property
    def domain_cache_dir(self) -> Path:
        return self.data_dir / "domain-certs"


@dataclass
class ServerConfig:
    """Server mode configuration."""

    host: str = "0.0.0.0"
    port: int = 8443
    auth_username: str = ""
    auth_password: str = ""
    auth_token: str = ""
    no_auth: bool = False
    timeout: int = 120
    max_response_size: int = 50 * 1024 * 1024  # 50MB

    def load_from_env(self) -> None:
        self.host = os.environ.get("OWL_PROXY_HOST", self.host)
        self.port = int(os.environ.get("OWL_PROXY_PORT", self.port))
        self.auth_username = os.environ.get("OWL_PROXY_USERNAME", self.auth_username)
        self.auth_password = os.environ.get("OWL_PROXY_PASSWORD", self.auth_password)
        self.auth_token = os.environ.get("OWL_PROXY_TOKEN", self.auth_token)
        self.timeout = int(os.environ.get("OWL_PROXY_TIMEOUT", self.timeout))


@dataclass
class ClientConfig:
    """Client mode configuration."""

    listen_host: str = "127.0.0.1"
    listen_port: int = 8080
    remote_server: str = ""  # empty = direct mode
    auth_username: str = ""
    auth_password: str = ""
    auth_token: str = ""
    timeout: int = 60
    serve_pac: bool = False
    direct: bool = False

    def load_from_env(self) -> None:
        self.listen_host = os.environ.get("OWL_CLIENT_HOST", self.listen_host)
        self.listen_port = int(os.environ.get("OWL_CLIENT_PORT", self.listen_port))
        self.remote_server = os.environ.get("OWL_REMOTE_SERVER", self.remote_server)
        self.auth_username = os.environ.get("OWL_PROXY_USERNAME", self.auth_username)
        self.auth_password = os.environ.get("OWL_PROXY_PASSWORD", self.auth_password)
        self.auth_token = os.environ.get("OWL_PROXY_TOKEN", self.auth_token)
        self.timeout = int(os.environ.get("OWL_PROXY_TIMEOUT", self.timeout))
