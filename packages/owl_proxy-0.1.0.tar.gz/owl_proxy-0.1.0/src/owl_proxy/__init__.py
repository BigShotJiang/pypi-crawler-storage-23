"""Owl Proxy - MITM proxy with CA certificate management."""

__version__ = "0.1.0"
