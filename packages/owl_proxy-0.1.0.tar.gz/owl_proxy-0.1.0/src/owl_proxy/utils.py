"""Shared utilities for Owl Proxy."""

import gzip
import ipaddress
import logging
import zlib
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

# Hop-by-hop headers that should not be forwarded
HOP_BY_HOP_HEADERS = frozenset([
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "proxy-connection",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
])

# Additional headers to remove from responses
RESPONSE_HEADERS_TO_REMOVE = frozenset([
    "content-encoding",
    "content-length",
    "transfer-encoding",
])


def filter_request_headers(headers: dict[str, str]) -> dict[str, str]:
    """Remove hop-by-hop and proxy headers from a request."""
    return {
        k: v for k, v in headers.items()
        if k.lower() not in HOP_BY_HOP_HEADERS
    }


def filter_response_headers(headers: dict[str, str]) -> dict[str, str]:
    """Remove hop-by-hop and encoding headers from a response."""
    return {
        k: v for k, v in headers.items()
        if k.lower() not in HOP_BY_HOP_HEADERS
        and k.lower() not in RESPONSE_HEADERS_TO_REMOVE
    }


def is_valid_proxy_url(url: str) -> bool:
    """Check if a URL is valid and safe to proxy (blocks private/local IPs)."""
    try:
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return False
        if not parsed.netloc:
            return False

        host = parsed.hostname or ""

        # Block obvious localhost names
        if host in ("localhost", "0.0.0.0", "::1"):
            return False

        # Try to parse as IP and check for private ranges
        try:
            addr = ipaddress.ip_address(host)
            if addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved:
                return False
        except ValueError:
            # Not an IP literal — it's a hostname, allow it
            # (DNS resolution happens later; we can't block all private DNS here)
            pass

        return True
    except Exception:
        return False


def decompress_body(content: bytes, encoding: str | None) -> bytes:
    """Decompress response content based on Content-Encoding."""
    if not encoding:
        return content

    encoding = encoding.lower()
    if encoding == "gzip":
        try:
            return gzip.decompress(content)
        except Exception:
            return content
    elif encoding == "deflate":
        try:
            return zlib.decompress(content, -zlib.MAX_WBITS)
        except Exception:
            try:
                return zlib.decompress(content)
            except Exception:
                return content
    elif encoding == "br":
        try:
            import brotli
            return brotli.decompress(content)
        except ImportError:
            logger.warning("Brotli decompression requested but brotli is not installed")
            return content
        except Exception:
            return content

    return content
