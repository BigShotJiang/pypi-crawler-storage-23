"""Cross-platform trust store installation for the CA certificate."""

import logging
import platform
import shutil
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)


def detect_platform() -> str:
    """Return 'macos', 'linux', or 'windows'."""
    system = platform.system().lower()
    if system == "darwin":
        return "macos"
    elif system == "windows":
        return "windows"
    return "linux"


def _detect_linux_family() -> str:
    """Return 'debian', 'redhat', or 'unknown'."""
    if Path("/etc/debian_version").exists():
        return "debian"
    if Path("/etc/redhat-release").exists():
        return "redhat"
    if Path("/etc/pki/ca-trust").exists():
        return "redhat"
    if Path("/usr/local/share/ca-certificates").exists():
        return "debian"
    return "unknown"


def install_ca_to_trust_store(cert_path: Path, *, dry_run: bool = False) -> list[str]:
    """
    Install a CA certificate into the OS trust store.

    Returns a list of commands that were (or would be) executed.
    If dry_run=True, only returns commands without executing.
    """
    cert_path = cert_path.resolve()
    if not cert_path.exists():
        raise FileNotFoundError(f"Certificate not found: {cert_path}")

    plat = detect_platform()
    commands: list[str] = []

    if plat == "macos":
        commands = _install_macos(cert_path, dry_run=dry_run)
    elif plat == "windows":
        commands = _install_windows(cert_path, dry_run=dry_run)
    elif plat == "linux":
        commands = _install_linux(cert_path, dry_run=dry_run)

    return commands


def _install_macos(cert_path: Path, *, dry_run: bool = False) -> list[str]:
    cmd = [
        "sudo", "security", "add-trusted-cert",
        "-d", "-r", "trustRoot",
        "-k", "/Library/Keychains/System.keychain",
        str(cert_path),
    ]
    cmd_str = " ".join(cmd)

    if not dry_run:
        logger.info("Installing CA to macOS System Keychain...")
        subprocess.run(cmd, check=True)
        logger.info("CA installed successfully")

    return [cmd_str]


def _install_linux(cert_path: Path, *, dry_run: bool = False) -> list[str]:
    family = _detect_linux_family()
    commands: list[str] = []

    if family == "debian":
        dest = Path("/usr/local/share/ca-certificates/owl-proxy-ca.crt")
        cp_cmd = f"sudo cp {cert_path} {dest}"
        update_cmd = "sudo update-ca-certificates"
        commands = [cp_cmd, update_cmd]

        if not dry_run:
            logger.info("Installing CA to Debian/Ubuntu trust store...")
            subprocess.run(["sudo", "cp", str(cert_path), str(dest)], check=True)
            subprocess.run(["sudo", "update-ca-certificates"], check=True)
            logger.info("CA installed successfully")

    elif family == "redhat":
        dest = Path("/etc/pki/ca-trust/source/anchors/owl-proxy-ca.crt")
        cp_cmd = f"sudo cp {cert_path} {dest}"
        update_cmd = "sudo update-ca-trust"
        commands = [cp_cmd, update_cmd]

        if not dry_run:
            logger.info("Installing CA to RHEL/Fedora trust store...")
            subprocess.run(["sudo", "cp", str(cert_path), str(dest)], check=True)
            subprocess.run(["sudo", "update-ca-trust"], check=True)
            logger.info("CA installed successfully")

    else:
        raise RuntimeError(
            "Could not detect Linux distribution.\n"
            "Manually copy the CA cert to your trust store:\n"
            f"  Debian/Ubuntu: sudo cp {cert_path} /usr/local/share/ca-certificates/ "
            "&& sudo update-ca-certificates\n"
            f"  RHEL/Fedora: sudo cp {cert_path} /etc/pki/ca-trust/source/anchors/ "
            "&& sudo update-ca-trust"
        )

    return commands


def _install_windows(cert_path: Path, *, dry_run: bool = False) -> list[str]:
    cmd = ["certutil", "-addstore", "-f", "ROOT", str(cert_path)]
    cmd_str = " ".join(cmd)

    if not dry_run:
        logger.info("Installing CA to Windows trust store...")
        subprocess.run(cmd, check=True)
        logger.info("CA installed successfully")

    return [cmd_str]


def uninstall_ca_from_trust_store(*, dry_run: bool = False) -> list[str]:
    """Remove the Owl Proxy CA from the OS trust store."""
    plat = detect_platform()
    commands: list[str] = []

    if plat == "macos":
        cmd = [
            "sudo", "security", "delete-certificate",
            "-c", "Owl Proxy Root CA",
            "/Library/Keychains/System.keychain",
        ]
        commands = [" ".join(cmd)]
        if not dry_run:
            subprocess.run(cmd, check=True)

    elif plat == "linux":
        family = _detect_linux_family()
        if family == "debian":
            dest = Path("/usr/local/share/ca-certificates/owl-proxy-ca.crt")
            commands = [f"sudo rm {dest}", "sudo update-ca-certificates --fresh"]
            if not dry_run:
                subprocess.run(["sudo", "rm", "-f", str(dest)], check=True)
                subprocess.run(["sudo", "update-ca-certificates", "--fresh"], check=True)
        elif family == "redhat":
            dest = Path("/etc/pki/ca-trust/source/anchors/owl-proxy-ca.crt")
            commands = [f"sudo rm {dest}", "sudo update-ca-trust"]
            if not dry_run:
                subprocess.run(["sudo", "rm", "-f", str(dest)], check=True)
                subprocess.run(["sudo", "update-ca-trust"], check=True)

    elif plat == "windows":
        cmd = ["certutil", "-delstore", "ROOT", "Owl Proxy Root CA"]
        commands = [" ".join(cmd)]
        if not dry_run:
            subprocess.run(cmd, check=True)

    return commands
