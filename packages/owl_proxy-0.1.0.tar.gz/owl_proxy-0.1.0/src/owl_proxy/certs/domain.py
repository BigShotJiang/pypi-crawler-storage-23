"""Per-domain certificate generation for MITM proxy."""

import logging
import ssl
import tempfile
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

logger = logging.getLogger(__name__)


class DomainCertGenerator:
    """
    Generates and caches SSL certificates signed by the root CA.

    Certificates are cached both in memory and optionally on disk
    so they survive restarts.
    """

    def __init__(
        self,
        ca_cert_path: Path,
        ca_key_path: Path,
        cache_dir: Path | None = None,
    ) -> None:
        self._ca_cert_path = ca_cert_path
        self._ca_key_path = ca_key_path
        self._cache_dir = cache_dir
        self._memory_cache: dict[str, tuple[bytes, bytes]] = {}
        self._lock = threading.Lock()

        # Load CA
        if not ca_cert_path.exists():
            raise FileNotFoundError(
                f"CA certificate not found: {ca_cert_path}\n"
                "Run 'owl-proxy cert generate' first."
            )
        if not ca_key_path.exists():
            raise FileNotFoundError(
                f"CA private key not found: {ca_key_path}\n"
                "Run 'owl-proxy cert generate' first."
            )

        with open(ca_cert_path, "rb") as f:
            self._ca_cert = x509.load_pem_x509_certificate(f.read())
        with open(ca_key_path, "rb") as f:
            self._ca_key = serialization.load_pem_private_key(f.read(), password=None)

        if cache_dir:
            cache_dir.mkdir(parents=True, exist_ok=True)

        logger.info("CA certificate loaded from %s", ca_cert_path)

    def get_cert(self, domain: str) -> tuple[bytes, bytes]:
        """
        Get (cert_pem, key_pem) for a domain. Uses cache if available.
        """
        with self._lock:
            if domain in self._memory_cache:
                return self._memory_cache[domain]

        # Check disk cache
        if self._cache_dir:
            cert_file = self._cache_dir / f"{domain}.crt"
            key_file = self._cache_dir / f"{domain}.key"
            if cert_file.exists() and key_file.exists():
                cert_pem = cert_file.read_bytes()
                key_pem = key_file.read_bytes()
                with self._lock:
                    self._memory_cache[domain] = (cert_pem, key_pem)
                return cert_pem, key_pem

        # Generate new cert
        cert_pem, key_pem = self._generate(domain)

        # Save to caches
        with self._lock:
            self._memory_cache[domain] = (cert_pem, key_pem)

        if self._cache_dir:
            (self._cache_dir / f"{domain}.crt").write_bytes(cert_pem)
            key_path = self._cache_dir / f"{domain}.key"
            key_path.write_bytes(key_pem)
            import os
            os.chmod(key_path, 0o600)

        return cert_pem, key_pem

    def _generate(self, domain: str) -> tuple[bytes, bytes]:
        """Generate a new certificate for the given domain."""
        logger.info("Generating certificate for %s", domain)

        key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
        )

        now = datetime.now(timezone.utc)
        cert = (
            x509.CertificateBuilder()
            .subject_name(x509.Name([
                x509.NameAttribute(NameOID.COMMON_NAME, domain),
            ]))
            .issuer_name(self._ca_cert.subject)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - timedelta(days=1))
            .not_valid_after(now + timedelta(days=365))
            .add_extension(
                x509.SubjectAlternativeName([
                    x509.DNSName(domain),
                    x509.DNSName(f"*.{domain}"),
                ]),
                critical=False,
            )
            .add_extension(
                x509.BasicConstraints(ca=False, path_length=None),
                critical=True,
            )
            .add_extension(
                x509.KeyUsage(
                    digital_signature=True,
                    content_commitment=False,
                    key_encipherment=True,
                    data_encipherment=False,
                    key_agreement=False,
                    key_cert_sign=False,
                    crl_sign=False,
                    encipher_only=False,
                    decipher_only=False,
                ),
                critical=True,
            )
            .add_extension(
                x509.ExtendedKeyUsage([x509.oid.ExtendedKeyUsageOID.SERVER_AUTH]),
                critical=False,
            )
            .sign(self._ca_key, hashes.SHA256())
        )

        cert_pem = cert.public_bytes(serialization.Encoding.PEM)
        key_pem = key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        )
        return cert_pem, key_pem

    def create_ssl_context(self, domain: str) -> ssl.SSLContext:
        """Create a server-side SSL context for MITM on the given domain."""
        cert_pem, key_pem = self.get_cert(domain)

        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2

        # Write to temp files (SSLContext requires file paths)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pem") as cf:
            cf.write(cert_pem)
            cert_path = cf.name
        with tempfile.NamedTemporaryFile(delete=False, suffix=".key") as kf:
            kf.write(key_pem)
            key_path = kf.name

        try:
            context.load_cert_chain(certfile=cert_path, keyfile=key_path)
        finally:
            import os
            os.unlink(cert_path)
            os.unlink(key_path)

        return context

    @property
    def cache_size(self) -> int:
        with self._lock:
            return len(self._memory_cache)

    def clear_cache(self) -> None:
        with self._lock:
            self._memory_cache.clear()
        if self._cache_dir and self._cache_dir.exists():
            for f in self._cache_dir.iterdir():
                f.unlink()
        logger.info("Certificate cache cleared")
