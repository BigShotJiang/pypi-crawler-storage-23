# Owl Proxy

MITM proxy with CA certificate management — server, client, and certificate tools.

## Install

```bash
pip install owl-proxy
```

## Quick Start

```bash
# 1. Generate CA certificate
owl-proxy cert generate

# 2. Install CA into OS trust store
owl-proxy cert install

# 3a. Run as a standalone proxy server
owl-proxy server --port 8443 --auth user:pass

# 3b. Run as a local MITM client (direct mode)
owl-proxy client --direct

# 3c. Run client forwarding through a remote server
owl-proxy client --remote https://my-server:8443 --auth user:pass
```

## Modes

### Server
Run on any machine (Raspberry Pi, VPS, etc.) as a proxy server:
```bash
owl-proxy server --host 0.0.0.0 --port 8443 --auth user:pass
```

### Client
Run locally as a MITM proxy that intercepts HTTPS traffic:
```bash
# Direct mode — fetches URLs itself
owl-proxy client --direct --port 8080

# Remote mode — forwards through an Owl Proxy server
owl-proxy client --remote https://my-pi:8443 --auth user:pass
```

### Certificate Management
```bash
owl-proxy cert generate          # Create new CA
owl-proxy cert install           # Trust CA system-wide
owl-proxy cert info              # Show CA details
owl-proxy cert export -d ./      # Copy CA cert for sharing
owl-proxy cert uninstall         # Remove from trust store
```

## Configuration

Settings can be provided via CLI flags, environment variables, or both:

| Environment Variable  | Description                |
|-----------------------|----------------------------|
| `OWL_PROXY_HOST`      | Server bind address        |
| `OWL_PROXY_PORT`      | Server bind port           |
| `OWL_PROXY_USERNAME`  | Auth username              |
| `OWL_PROXY_PASSWORD`  | Auth password              |
| `OWL_PROXY_TOKEN`     | Bearer token               |
| `OWL_PROXY_TIMEOUT`   | Request timeout (seconds)  |
| `OWL_CLIENT_HOST`     | Client listen address      |
| `OWL_CLIENT_PORT`     | Client listen port         |
| `OWL_REMOTE_SERVER`   | Remote server URL          |

Data is stored in `~/.owl-proxy/` by default (respects `XDG_DATA_HOME`).
