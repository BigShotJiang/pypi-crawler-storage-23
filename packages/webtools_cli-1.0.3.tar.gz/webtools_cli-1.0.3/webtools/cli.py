"""CLI entry point for webtools command"""
import sys
sys.dont_write_bytecode = True

def main():
    """Main entry point for the webtools CLI command"""
    from webtools.core import main_launcher
    try:
        main_launcher()
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
        sys.exit(0)

if __name__ == "__main__":
    main()
