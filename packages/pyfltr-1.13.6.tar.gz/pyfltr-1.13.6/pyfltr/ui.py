"""Textual UI関連の処理。"""

import argparse
import concurrent.futures
import logging
import sys
import threading
import time
import traceback
import typing

from textual.app import App, ComposeResult
from textual.widgets import Log, TabbedContent, TabPane

import pyfltr.command
import pyfltr.config
import pyfltr.executor


def can_use_ui() -> bool:
    """UIを使用するかどうか判定。"""
    return sys.stdin.isatty() and sys.stdout.isatty()


def run_commands_with_ui(
    commands: list[str],
    args: argparse.Namespace,
    config: pyfltr.config.Config,
) -> tuple[list[pyfltr.command.CommandResult], int]:
    """UI付きでコマンドを実行。"""
    app = UIApp(commands, args, config)
    try:
        return_code = app.run()
        if return_code is None:
            return_code = 0
        else:
            assert isinstance(return_code, int)

        return app.results, return_code
    except Exception:
        # Textualアプリケーション自体の例外処理
        error_msg = f"Failed to run UI application: {traceback.format_exc()}"
        logging.error(error_msg)
        print(f"ERROR: {error_msg}", file=sys.stderr)
        sys.exit(1)


class UIApp(App):
    """Textualアプリケーション。"""

    CSS = """
    Log.output {
        scrollbar-gutter: stable;
    }
    """

    def __init__(self, commands: list[str], args: argparse.Namespace, config: pyfltr.config.Config) -> None:
        super().__init__()
        self.commands = commands
        self.args = args
        self.config = config
        self.results: list[pyfltr.command.CommandResult] = []
        self.lock = threading.Lock()
        self.last_ctrl_c_time: float = 0.0
        self.ctrl_c_timeout: float = 1.0  # 1秒以内の連続押しで終了

    def compose(self) -> ComposeResult:
        """UIを構成。"""
        with TabbedContent(initial="summary"):
            with TabPane("Summary", id="summary"):
                yield Log(id="summary-content", classes="output")

            # 有効なコマンドのみタブを作成
            enabled_commands = [cmd for cmd in self.commands if self.config[cmd]]
            for command in enabled_commands:
                with TabPane(command, id=f"tab-{command}"):
                    yield Log(id=f"output-{command}", classes="output")

    def on_ready(self) -> None:
        """ready時の処理。"""
        # 初期表示
        self._write_log("#summary-content", "Running commands... (Press Ctrl+C twice to exit)\n")
        # コマンド実行をバックグラウンドで開始
        self.set_timer(0.1, self._run_commands)

    def on_key(self, event) -> None:
        """キー入力処理。"""
        if event.key == "ctrl+c":
            current_time = time.time()

            # 前回のCtrl+Cから1秒以内の場合は終了
            if current_time - self.last_ctrl_c_time <= self.ctrl_c_timeout:
                self.exit()  # return_code=130 : 128+SIGINT(2) もありだが…
            else:
                # 初回またはタイムアウト後のCtrl+C
                self.last_ctrl_c_time = current_time
                # ユーザーに2回目を促すメッセージを表示
                self._write_log("#summary-content", "Press Ctrl+C again within 1 second to exit...")

    def _run_commands(self) -> None:
        """backgroundでコマンドを実行。"""
        threading.Thread(target=self._run_in_background, daemon=True).start()

    def _run_in_background(self):
        """バックグラウンド処理。"""
        try:
            formatters, linters_and_testers = pyfltr.executor.split_commands_for_execution(self.commands, self.config)

            # formatters (serial)
            for command in formatters:
                self.results.append(self._execute_command(command))

            # linters/testers (parallel)
            if len(linters_and_testers) > 0:
                with concurrent.futures.ThreadPoolExecutor(max_workers=len(linters_and_testers)) as executor:
                    future_to_command = {
                        executor.submit(self._execute_command, command): command for command in linters_and_testers
                    }
                    for future in concurrent.futures.as_completed(future_to_command):
                        self.results.append(future.result())

            # summary更新と自動終了判定
            summary_lines = ["", "", "Results summary:", "=" * 40]
            for result in self.results:
                summary_lines.append(f"{result.command:<16s} {result.get_status_text()}")

            summary_lines.extend(["=" * 40])

            # returncode情報と自動終了判定
            statuses = [result.status for result in self.results]
            overall_status: typing.Literal["SUCCESS", "FORMATTED", "FAILED"]
            if any(status == "failed" for status in statuses):
                overall_status = "FAILED"
            elif any(status == "formatted" for status in statuses):
                overall_status = "FORMATTED"
            else:
                overall_status = "SUCCESS"

            summary_lines.append(f"Overall status: {overall_status}")
            summary_lines.append("")
            summary_lines.append("")
            self.call_from_thread(self._write_log, "#summary-content", "\n".join(summary_lines))

            # FORMATTED/SUCCESSの場合は自動終了（--keep-ui時は終了しない）
            if overall_status != "FAILED" and not self.args.keep_ui:
                self.call_from_thread(self.exit)

        except Exception:
            # Textualエラー時の処理
            error_msg = f"Fatal error in UI processing:\n{traceback.format_exc()}"
            try:
                # summaryタブにエラー表示
                self.call_from_thread(
                    self._write_log,
                    "#summary-content",
                    f"FATAL ERROR:\n{error_msg}\n\nPress Ctrl+C to exit.",
                )
            except Exception:
                logging.error(error_msg)
                self.call_from_thread(self._handle_fatal_error, error_msg)

    def _execute_command(self, command: str) -> pyfltr.command.CommandResult:
        """outputをキャプチャしながらコマンド実行。"""
        # コマンドタブに開始メッセージを出力
        self.call_from_thread(
            self._write_log,
            f"#output-{command}",
            f"Running {command}...\n",
        )

        def on_output(line: str) -> None:
            """出力行をリアルタイムでUIに反映。"""
            self.call_from_thread(self._write_log, f"#output-{command}", line.removesuffix("\n"))

        result = pyfltr.command.execute_command(command, self.args, self.config, on_output=on_output)

        with self.lock:
            # コマンド実行が完了した旨をサマリタブに出力
            self.call_from_thread(
                self._write_log,
                "#summary-content",
                f"Command {command} completed. ({result.status})",
            )

            # フッター情報のみ追記（本体はストリーミング済み）
            footer = f"{'-' * 40}\nReturn code: {result.returncode}\nStatus: {result.get_status_text()}\n"
            self.call_from_thread(
                self._write_log,
                f"#output-{result.command}",
                footer,
            )
            # コマンド失敗時のタブタイトル更新
            if result.status == "failed":
                self.call_from_thread(self._update_tab_title, result.command, True)

        return result

    def _write_log(self, widget_id: str, content: str) -> None:
        """ログの追記。"""
        try:
            widget = self.query_one(widget_id, Log)
            widget.write_lines([("\n" if len(line) == 0 else line) for line in (content + "\n").splitlines(keepends=True)])
        except Exception:
            logging.error(f"UIエラー: {widget_id}", exc_info=True)

    def _update_tab_title(self, command: str, has_error: bool) -> None:
        """タブタイトルを更新（エラー時に*を追加）。"""
        # pylint: disable=protected-access
        try:
            tc = self.query_one(TabbedContent)
            tab = tc.get_tab(f"tab-{command}")
            if has_error:
                tab.label = f"{command} *"  # type: ignore[assignment]
                # エラーが発生したタブをアクティブにする
                tc.active = f"tab-{command}"
            else:
                tab.label = command  # type: ignore[assignment]
        except Exception:
            logging.warning(f"タブタイトル更新失敗: {command}", exc_info=True)

    def _handle_fatal_error(self, msg: str) -> None:
        """致命的エラー時の処理。"""
        logging.error(f"Fatal error occurred: {msg}")
        # アプリケーションを終了
        self.exit(return_code=1)
