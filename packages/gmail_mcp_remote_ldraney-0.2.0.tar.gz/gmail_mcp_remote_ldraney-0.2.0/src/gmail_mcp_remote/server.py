"""Main entrypoint — configures the gmail-mcp FastMCP instance with OAuth
and serves it over Streamable HTTP.
"""

from __future__ import annotations

import html
import logging
import os
import secrets
import sys
import time

from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

GMAIL_OAUTH_CLIENT_ID = os.environ["GMAIL_OAUTH_CLIENT_ID"]
GMAIL_OAUTH_CLIENT_SECRET = os.environ["GMAIL_OAUTH_CLIENT_SECRET"]
SESSION_SECRET = os.environ["SESSION_SECRET"]
BASE_URL = os.environ.get("BASE_URL", "https://example.com")
HOST = os.environ.get("HOST", "127.0.0.1")
PORT = int(os.environ.get("PORT", "8002"))
ONBOARD_SECRET = os.environ.get("ONBOARD_SECRET", "")

logging.basicConfig(level=logging.INFO, stream=sys.stderr)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 1. Apply the per-request client monkey-patch BEFORE importing mcp
#    (gmail_mcp registers tools at import time)
# ---------------------------------------------------------------------------

from gmail_mcp_remote.client_patch import apply_patch  # noqa: E402

apply_patch()

# ---------------------------------------------------------------------------
# 2. Import the already-constructed FastMCP instance from gmail-mcp
# ---------------------------------------------------------------------------

from gmail_mcp.server import mcp  # noqa: E402

# ---------------------------------------------------------------------------
# 3. Set up auth provider and storage
# ---------------------------------------------------------------------------

from gmail_mcp_remote.auth.provider import (  # noqa: E402
    GOOGLE_AUTHORIZE_URL,
    GOOGLE_SCOPES,
    GoogleOAuthProvider,
)
from gmail_mcp_remote.auth.storage import TokenStore  # noqa: E402

store = TokenStore(secret=SESSION_SECRET)
provider = GoogleOAuthProvider(
    store=store,
    google_client_id=GMAIL_OAUTH_CLIENT_ID,
    google_client_secret=GMAIL_OAUTH_CLIENT_SECRET,
    base_url=BASE_URL,
)

# ---------------------------------------------------------------------------
# 4. Configure auth on the existing mcp instance
#    (bypassing constructor validation since instance is already built)
# ---------------------------------------------------------------------------

from mcp.server.auth.provider import ProviderTokenVerifier  # noqa: E402
from mcp.server.auth.settings import (  # noqa: E402
    AuthSettings,
    ClientRegistrationOptions,
    RevocationOptions,
)

mcp.settings.auth = AuthSettings(
    issuer_url=BASE_URL,
    resource_server_url=f"{BASE_URL}/mcp",
    client_registration_options=ClientRegistrationOptions(enabled=True),
    revocation_options=RevocationOptions(enabled=True),
)
mcp._auth_server_provider = provider
mcp._token_verifier = ProviderTokenVerifier(provider)

# ---------------------------------------------------------------------------
# 5. Configure HTTP transport settings
# ---------------------------------------------------------------------------

mcp.settings.host = HOST
mcp.settings.port = PORT
mcp.settings.stateless_http = False

# Allow the public hostname (and any additional internal hostnames) through
# transport security. ADDITIONAL_ALLOWED_HOSTS is comma-separated, used for
# K8s internal service names (e.g. "gmail-mcp-remote,gmail-mcp-remote:8002")
from urllib.parse import urlencode, urlparse  # noqa: E402

_allowed: list[str] = []
_parsed = urlparse(BASE_URL)
if _parsed.hostname:
    _allowed.append(_parsed.hostname)
    if _parsed.port:
        _allowed.append(f"{_parsed.hostname}:{_parsed.port}")
_extra = os.environ.get("ADDITIONAL_ALLOWED_HOSTS", "")
if _extra:
    _allowed.extend(h.strip() for h in _extra.split(",") if h.strip())
if _allowed:
    mcp.settings.transport_security.allowed_hosts = _allowed

# ---------------------------------------------------------------------------
# 6. Custom routes (health check + Google OAuth callback)
# ---------------------------------------------------------------------------

from starlette.requests import Request  # noqa: E402
from starlette.responses import JSONResponse, RedirectResponse, Response  # noqa: E402


@mcp.custom_route("/health", methods=["GET"])
async def health(request: Request) -> Response:
    return JSONResponse({"status": "ok"})


@mcp.custom_route("/.well-known/oauth-protected-resource", methods=["GET"])
async def oauth_protected_resource(request: Request) -> Response:
    """RFC 9728 — Protected Resource Metadata for MCP clients."""
    return JSONResponse({
        "resource": f"{BASE_URL}/mcp",
        "authorization_servers": [f"{BASE_URL}/"],
    })


@mcp.custom_route("/oauth/callback", methods=["GET"])
async def google_oauth_callback(request: Request) -> Response:
    """Handle Google's OAuth redirect after user authorizes.

    Exchanges Google's auth code for tokens, generates our own
    auth code, and redirects back to Claude's redirect_uri.
    """
    code = request.query_params.get("code")
    state = request.query_params.get("state")
    error = request.query_params.get("error")

    if error:
        logger.error("Google OAuth error: %s", error)
        return JSONResponse(
            {"error": "google_oauth_error", "detail": error}, status_code=400
        )

    if not code or not state:
        return JSONResponse(
            {"error": "missing_params", "detail": "code and state are required"},
            status_code=400,
        )

    try:
        redirect_url = await provider.exchange_google_code(code, state)
        return RedirectResponse(url=redirect_url, status_code=302)
    except ValueError as exc:
        logger.error("OAuth callback failed: %s", exc)
        return JSONResponse(
            {"error": "callback_failed", "detail": str(exc)}, status_code=400
        )
    except Exception as exc:
        logger.exception("Unexpected error in OAuth callback")
        return JSONResponse(
            {"error": "internal_error", "detail": "An internal error occurred"},
            status_code=500,
        )


# ---------------------------------------------------------------------------
# 6b. Onboarding routes (pre-authorize Gmail accounts)
# ---------------------------------------------------------------------------


def _error_html(message: str) -> str:
    """Return a simple HTML error page."""
    safe_message = html.escape(message)
    return (
        "<!DOCTYPE html><html><head><title>Error</title>"
        "<style>body{{font-family:sans-serif;max-width:600px;margin:60px auto;"
        "text-align:center}}h1{{color:#c0392b}}</style></head>"
        f"<body><h1>Error</h1><p>{safe_message}</p></body></html>"
    )


_CSP_HEADERS = {"Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'"}


@mcp.custom_route("/onboard", methods=["GET"])
async def onboard_page(request: Request) -> Response:
    """HTML page showing 'Connect Your Gmail' with a link to /onboard/start."""
    if ONBOARD_SECRET:
        provided_key = request.query_params.get("key", "")
        if not secrets.compare_digest(provided_key, ONBOARD_SECRET):
            return Response(
                content=_error_html("Invalid or missing onboard key."),
                media_type="text/html",
                status_code=403,
                headers=_CSP_HEADERS,
            )

    emails = store.list_preauth_emails()

    emails_html = ""
    if emails:
        items = "".join(f"<li>{html.escape(e)}</li>" for e in emails)
        emails_html = (
            "<h2>Already authorized</h2>"
            f"<ul>{items}</ul>"
        )

    link_url = f"{BASE_URL}/onboard/start"
    if ONBOARD_SECRET:
        link_url += f"?key={html.escape(ONBOARD_SECRET, quote=True)}"

    page_html = (
        "<!DOCTYPE html><html><head><title>Gmail Onboarding</title>"
        "<style>"
        "body{{font-family:sans-serif;max-width:600px;margin:60px auto;text-align:center}}"
        "a.btn{{display:inline-block;padding:12px 24px;background:#4285f4;color:#fff;"
        "text-decoration:none;border-radius:6px;font-size:16px;margin-top:20px}}"
        "a.btn:hover{{background:#3367d6}}"
        "ul{{list-style:none;padding:0}}li{{padding:4px 0;color:#27ae60}}"
        "</style></head>"
        "<body>"
        "<h1>Connect Your Gmail</h1>"
        "<p>Click below to authorize your Gmail account for use with the MCP server.</p>"
        f'<a class="btn" href="{link_url}">Authorize with Google</a>'
        f"{emails_html}"
        "</body></html>"
    )
    return Response(content=page_html, media_type="text/html", headers=_CSP_HEADERS)


@mcp.custom_route("/onboard/start", methods=["GET"])
async def onboard_start(request: Request) -> Response:
    """Validate key (if set), then redirect to Google OAuth for onboarding."""
    if ONBOARD_SECRET:
        provided_key = request.query_params.get("key", "")
        if not secrets.compare_digest(provided_key, ONBOARD_SECRET):
            return Response(
                content=_error_html("Invalid or missing onboard key."),
                media_type="text/html",
                status_code=403,
                headers=_CSP_HEADERS,
            )

    state = secrets.token_urlsafe(32)
    store.store_pending_auth(
        state,
        {
            "flow_type": "onboard",
            "expires_at": time.time() + 600,  # 10 minutes
        },
    )

    google_params = {
        "client_id": GMAIL_OAUTH_CLIENT_ID,
        "redirect_uri": f"{BASE_URL}/onboard/callback",
        "response_type": "code",
        "scope": f"{GOOGLE_SCOPES} openid email",
        "access_type": "offline",
        "prompt": "consent",
        "state": state,
    }
    google_url = f"{GOOGLE_AUTHORIZE_URL}?{urlencode(google_params)}"
    return RedirectResponse(url=google_url, status_code=302)


@mcp.custom_route("/onboard/callback", methods=["GET"])
async def onboard_callback(request: Request) -> Response:
    """Handle Google's redirect after onboarding authorization."""
    code = request.query_params.get("code")
    state = request.query_params.get("state")
    error = request.query_params.get("error")

    if error:
        logger.error("Google OAuth error (onboard): %s", error)
        return Response(
            content=_error_html(f"Google authorization error: {error}"),
            media_type="text/html",
            status_code=400,
            headers=_CSP_HEADERS,
        )

    if not code or not state:
        return Response(
            content=_error_html("Missing code or state parameter."),
            media_type="text/html",
            status_code=400,
            headers=_CSP_HEADERS,
        )

    try:
        email = await provider.exchange_onboard_google_code(code, state)
        safe_email = html.escape(email)
        success_html = (
            "<!DOCTYPE html><html><head><title>Gmail Connected</title>"
            "<style>"
            "body{{font-family:sans-serif;max-width:600px;margin:60px auto;text-align:center}}"
            ".check{{font-size:64px;color:#27ae60}}"
            "</style></head>"
            "<body>"
            '<div class="check">&#10003;</div>'
            "<h1>Gmail Connected</h1>"
            f"<p>Successfully authorized <strong>{safe_email}</strong>.</p>"
            "<p>You can now close this window. The next Claude MCP connection "
            "will use this account automatically.</p>"
            "</body></html>"
        )
        return Response(content=success_html, media_type="text/html", headers=_CSP_HEADERS)
    except ValueError as exc:
        logger.error("Onboard callback failed: %s", exc)
        return Response(
            content=_error_html(str(exc)),
            media_type="text/html",
            status_code=400,
            headers=_CSP_HEADERS,
        )
    except Exception:
        logger.exception("Unexpected error in onboard callback")
        return Response(
            content=_error_html("An internal error occurred."),
            media_type="text/html",
            status_code=500,
            headers=_CSP_HEADERS,
        )


# ---------------------------------------------------------------------------
# 7. Build the app with custom auth middleware for unauthenticated discovery
# ---------------------------------------------------------------------------

from gmail_mcp_remote.auth.discovery_auth import MethodAwareAuthMiddleware  # noqa: E402


def _build_app():
    """Build the Starlette app and patch /mcp auth to allow tool discovery."""
    app = mcp.streamable_http_app()

    for route in app.routes:
        if hasattr(route, "path") and route.path == "/mcp":
            auth_middleware = route.app
            inner_app = auth_middleware.app
            route.app = MethodAwareAuthMiddleware(
                app=inner_app,
                auth_middleware=auth_middleware,
            )
            logger.info("Patched /mcp with MethodAwareAuthMiddleware")
            break
    else:
        logger.warning("Could not find /mcp route to patch")

    return app


# ---------------------------------------------------------------------------
# 8. Run
# ---------------------------------------------------------------------------


def main() -> None:
    """Entry point for the console script and __main__."""
    import uvicorn  # noqa: E402

    logger.info("Starting gmail-mcp-remote on %s:%d", HOST, PORT)
    logger.info("Base URL: %s", BASE_URL)
    logger.info("MCP endpoint: %s/mcp", BASE_URL)
    app = _build_app()
    uvicorn.run(app, host=HOST, port=PORT)


if __name__ == "__main__":
    main()
