"""Per-request GmailClient injection via ContextVar.

Monkey-patches get_client() in gmail_mcp.server and all 8 tool modules
so each authenticated request gets its own GmailClient with the user's
Google OAuth credentials.
"""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar

from gmail_sdk import GmailClient

_request_client: ContextVar[GmailClient | None] = ContextVar(
    "_request_client", default=None
)


def patched_get_client(account: str | None = None) -> GmailClient:
    """Return the per-request GmailClient set by the OAuth flow.

    The account parameter is accepted for signature compatibility with
    gmail_mcp's get_client() but is ignored — in remote mode, the client
    is determined by the authenticated user's OAuth token, not by account alias.
    """
    client = _request_client.get()
    if client is None:
        raise RuntimeError(
            "No GmailClient set for this request — is OAuth configured?"
        )
    return client


def set_client_for_request(
    refresh_token: str,
    client_id: str,
    client_secret: str,
) -> None:
    """Refresh the Google access token and create a GmailClient on the contextvar.

    gmail_sdk's GmailClient uses httpx directly with a raw access_token,
    so we must refresh the token ourselves before constructing the client.
    """
    import httpx

    resp = httpx.post(
        "https://oauth2.googleapis.com/token",
        data={
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
            "client_secret": client_secret,
        },
    )
    resp.raise_for_status()
    access_token = resp.json()["access_token"]

    client = GmailClient(access_token=access_token)
    _request_client.set(client)


@contextmanager
def client_context(refresh_token: str, client_id: str, client_secret: str):
    """Context manager that sets up a per-request GmailClient."""
    import httpx

    resp = httpx.post(
        "https://oauth2.googleapis.com/token",
        data={
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
            "client_secret": client_secret,
        },
    )
    resp.raise_for_status()
    access_token = resp.json()["access_token"]

    token = _request_client.set(GmailClient(access_token=access_token))
    try:
        yield
    finally:
        _request_client.reset(token)


def apply_patch() -> None:
    """Replace get_client in gmail_mcp.server and all tool modules."""
    import gmail_mcp.server
    import gmail_mcp.tools.messages
    import gmail_mcp.tools.threads
    import gmail_mcp.tools.drafts
    import gmail_mcp.tools.labels
    import gmail_mcp.tools.attachments
    import gmail_mcp.tools.filters
    import gmail_mcp.tools.settings
    import gmail_mcp.tools.history

    gmail_mcp.server.get_client = patched_get_client

    for mod in [
        gmail_mcp.tools.messages,
        gmail_mcp.tools.threads,
        gmail_mcp.tools.drafts,
        gmail_mcp.tools.labels,
        gmail_mcp.tools.attachments,
        gmail_mcp.tools.filters,
        gmail_mcp.tools.settings,
        gmail_mcp.tools.history,
    ]:
        mod.get_client = patched_get_client
