"""OAuthAuthorizationServerProvider that proxies Google's OAuth 2.0 flow.

Implements the three-party OAuth dance:
  Claude.ai ↔ this server (MCP + OAuth AS) ↔ Google OAuth
"""

from __future__ import annotations

import logging
import secrets
import time
from urllib.parse import urlencode

import httpx
from pydantic import AnyUrl

from mcp.server.auth.provider import (
    AccessToken,
    AuthorizationCode,
    AuthorizationParams,
    OAuthAuthorizationServerProvider,
    RefreshToken,
    TokenError,
)
from mcp.shared.auth import OAuthClientInformationFull, OAuthToken

from gmail_mcp_remote.auth.storage import TokenStore
from gmail_mcp_remote.client_patch import set_client_for_request

logger = logging.getLogger(__name__)

# Google OAuth endpoints
GOOGLE_AUTHORIZE_URL = "https://accounts.google.com/o/oauth2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"

# Gmail API scopes
GOOGLE_SCOPES = " ".join([
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/gmail.modify",
    "https://www.googleapis.com/auth/gmail.settings.basic",
    "https://mail.google.com/",
])

# Token lifetimes
AUTH_CODE_LIFETIME = 300  # 5 minutes
ACCESS_TOKEN_LIFETIME = 86400  # 24 hours


class GoogleOAuthProvider:
    """OAuth provider that proxies to Google for user authorization.

    Implements OAuthAuthorizationServerProvider[AuthorizationCode, RefreshToken, AccessToken]
    """

    def __init__(
        self,
        store: TokenStore,
        google_client_id: str,
        google_client_secret: str,
        base_url: str,
    ) -> None:
        self.store = store
        self.google_client_id = google_client_id
        self.google_client_secret = google_client_secret
        self.base_url = base_url.rstrip("/")

    # ------------------------------------------------------------------
    # Dynamic Client Registration
    # ------------------------------------------------------------------

    async def get_client(self, client_id: str) -> OAuthClientInformationFull | None:
        data = self.store.get_client(client_id)
        if data is None:
            return None
        return OAuthClientInformationFull(**data)

    async def register_client(self, client_info: OAuthClientInformationFull) -> None:
        client_id = secrets.token_hex(16)
        client_secret = secrets.token_hex(32)
        client_info.client_id = client_id
        client_info.client_secret = client_secret
        client_info.client_id_issued_at = int(time.time())
        client_info.client_secret_expires_at = 0  # never expires
        self.store.store_client(client_id, client_info.model_dump(mode="json"))

    # ------------------------------------------------------------------
    # Authorization (redirect to Google)
    # ------------------------------------------------------------------

    async def authorize(
        self,
        client: OAuthClientInformationFull,
        params: AuthorizationParams,
    ) -> str:
        # Check for a pre-authorized Google refresh token (onboarding flow)
        preauth = self.store.pop_preauth_token()
        if preauth is not None:
            email, google_refresh_token = preauth
            logger.info("Using preauth token for %s — skipping Google consent", email)
            our_code = secrets.token_urlsafe(32)
            self.store.store_auth_code(
                our_code,
                {
                    "google_refresh_token": google_refresh_token,
                    "client_id": client.client_id,
                    "code_challenge": params.code_challenge,
                    "redirect_uri": str(params.redirect_uri),
                    "redirect_uri_provided_explicitly": params.redirect_uri_provided_explicitly,
                    "scopes": params.scopes or [],
                    "resource": str(params.resource) if params.resource else None,
                    "expires_at": time.time() + AUTH_CODE_LIFETIME,
                },
            )
            # Redirect back to Claude immediately with our auth code
            redirect_params = {"code": our_code}
            if params.state:
                redirect_params["state"] = params.state
            redirect_uri = str(params.redirect_uri)
            separator = "&" if "?" in redirect_uri else "?"
            return f"{redirect_uri}{separator}{urlencode(redirect_params)}"

        # Generate state for our Google OAuth request
        google_state = secrets.token_urlsafe(32)

        # Store Claude's params so the callback can complete the flow
        self.store.store_pending_auth(
            google_state,
            {
                "client_id": client.client_id,
                "redirect_uri": str(params.redirect_uri),
                "code_challenge": params.code_challenge,
                "state": params.state,
                "scopes": params.scopes,
                "redirect_uri_provided_explicitly": params.redirect_uri_provided_explicitly,
                "resource": str(params.resource) if params.resource else None,
                "expires_at": time.time() + 600,  # 10 minutes
            },
        )

        # Build Google OAuth URL
        google_params = {
            "client_id": self.google_client_id,
            "redirect_uri": f"{self.base_url}/oauth/callback",
            "response_type": "code",
            "scope": GOOGLE_SCOPES,
            "access_type": "offline",
            "prompt": "consent",
            "state": google_state,
        }
        return f"{GOOGLE_AUTHORIZE_URL}?{urlencode(google_params)}"

    # ------------------------------------------------------------------
    # Google token exchange (called from the callback route)
    # ------------------------------------------------------------------

    async def exchange_google_code(self, code: str, state: str) -> str:
        """Exchange Google auth code for tokens, store refresh token, return redirect URL.

        Called by the /oauth/callback custom route handler.
        Returns the full redirect URL to send the user back to Claude.
        """
        pending = self.store.get_pending_auth(state)
        if pending is None:
            raise ValueError("Unknown or expired auth state")

        if pending.get("flow_type") == "onboard":
            raise ValueError("Onboard flow cannot use the standard OAuth callback")

        # Exchange code with Google (form-encoded, not JSON)
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                GOOGLE_TOKEN_URL,
                data={
                    "grant_type": "authorization_code",
                    "code": code,
                    "redirect_uri": f"{self.base_url}/oauth/callback",
                    "client_id": self.google_client_id,
                    "client_secret": self.google_client_secret,
                },
            )
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as exc:
                logger.error(
                    "Google token exchange failed: %s %s",
                    exc.response.status_code,
                    exc.response.text,
                )
                raise ValueError(
                    "Failed to exchange authorization code with Google"
                ) from exc
            google_data = resp.json()

        google_refresh_token = google_data.get("refresh_token")
        if not google_refresh_token:
            raise ValueError(
                "Google did not return a refresh_token — "
                "ensure access_type=offline and prompt=consent"
            )

        # Generate our own authorization code for Claude
        our_code = secrets.token_urlsafe(32)
        self.store.store_auth_code(
            our_code,
            {
                "google_refresh_token": google_refresh_token,
                "client_id": pending["client_id"],
                "code_challenge": pending["code_challenge"],
                "redirect_uri": pending["redirect_uri"],
                "redirect_uri_provided_explicitly": pending[
                    "redirect_uri_provided_explicitly"
                ],
                "scopes": pending["scopes"] or [],
                "resource": pending.get("resource"),
                "expires_at": time.time() + AUTH_CODE_LIFETIME,
            },
        )

        # Clean up pending auth
        self.store.delete_pending_auth(state)

        # Build redirect back to Claude
        redirect_params = {"code": our_code}
        if pending["state"]:
            redirect_params["state"] = pending["state"]

        redirect_uri = pending["redirect_uri"]
        separator = "&" if "?" in redirect_uri else "?"
        return f"{redirect_uri}{separator}{urlencode(redirect_params)}"

    # ------------------------------------------------------------------
    # Onboarding Google token exchange (called from /onboard/callback)
    # ------------------------------------------------------------------

    async def exchange_onboard_google_code(self, code: str, state: str) -> str:
        """Exchange Google auth code from the onboarding flow for a preauth token.

        Validates the pending auth has flow_type == "onboard", exchanges the
        code with Google, fetches the user's email, and stores a preauth token.
        Returns the authorized email address.
        """
        pending = self.store.get_pending_auth(state)
        if pending is None:
            raise ValueError("Unknown or expired auth state")

        if pending.get("flow_type") != "onboard":
            raise ValueError("Expected onboard flow type")

        # Exchange code with Google
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                GOOGLE_TOKEN_URL,
                data={
                    "grant_type": "authorization_code",
                    "code": code,
                    "redirect_uri": f"{self.base_url}/onboard/callback",
                    "client_id": self.google_client_id,
                    "client_secret": self.google_client_secret,
                },
            )
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as exc:
                logger.error(
                    "Google token exchange (onboard) failed: %s %s",
                    exc.response.status_code,
                    exc.response.text,
                )
                raise ValueError(
                    "Failed to exchange authorization code with Google"
                ) from exc
            google_data = resp.json()

        google_refresh_token = google_data.get("refresh_token")
        if not google_refresh_token:
            raise ValueError(
                "Google did not return a refresh_token — "
                "ensure access_type=offline and prompt=consent"
            )

        # Fetch user email from Google
        access_token = google_data.get("access_token")
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                "https://www.googleapis.com/oauth2/v2/userinfo",
                headers={"Authorization": f"Bearer {access_token}"},
            )
            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as exc:
                logger.error(
                    "Failed to fetch user info: %s %s",
                    exc.response.status_code,
                    exc.response.text,
                )
                raise ValueError("Failed to fetch user email from Google") from exc
            email = resp.json().get("email")

        if not email:
            raise ValueError("Google did not return an email address")

        # Store preauth token
        self.store.store_preauth_token(email, google_refresh_token)

        # Clean up pending auth
        self.store.delete_pending_auth(state)

        logger.info("Onboard: stored preauth token for %s", email)
        return email

    # ------------------------------------------------------------------
    # Authorization code flow (called by FastMCP /token handler)
    # ------------------------------------------------------------------

    async def load_authorization_code(
        self,
        client: OAuthClientInformationFull,
        authorization_code: str,
    ) -> AuthorizationCode | None:
        data = self.store.get_auth_code(authorization_code)
        if data is None:
            return None
        if data["client_id"] != client.client_id:
            return None
        return AuthorizationCode(
            code=authorization_code,
            client_id=data["client_id"],
            code_challenge=data["code_challenge"],
            redirect_uri=AnyUrl(data["redirect_uri"]),
            redirect_uri_provided_explicitly=data["redirect_uri_provided_explicitly"],
            scopes=data.get("scopes") or [],
            expires_at=data["expires_at"],
            resource=data.get("resource"),
        )

    async def exchange_authorization_code(
        self,
        client: OAuthClientInformationFull,
        authorization_code: AuthorizationCode,
    ) -> OAuthToken:
        data = self.store.get_auth_code(authorization_code.code)
        if data is None:
            raise TokenError(
                error="invalid_grant", error_description="Authorization code not found"
            )

        google_refresh_token = data["google_refresh_token"]
        scopes = data.get("scopes") or []

        # Generate our tokens
        access_token = secrets.token_urlsafe(32)
        refresh_token = secrets.token_urlsafe(32)
        expires_at = int(time.time()) + ACCESS_TOKEN_LIFETIME

        # Store tokens with google_refresh_token mapping
        self.store.store_access_token(
            access_token,
            {
                "google_refresh_token": google_refresh_token,
                "client_id": client.client_id,
                "scopes": scopes,
                "expires_at": expires_at,
                "refresh_token": refresh_token,
                "resource": data.get("resource"),
            },
        )
        self.store.store_refresh_token(
            refresh_token,
            {
                "google_refresh_token": google_refresh_token,
                "client_id": client.client_id,
                "scopes": scopes,
                "access_token": access_token,
                "resource": data.get("resource"),
            },
        )

        # Delete used auth code
        self.store.delete_auth_code(authorization_code.code)

        return OAuthToken(
            access_token=access_token,
            token_type="Bearer",
            expires_in=ACCESS_TOKEN_LIFETIME,
            refresh_token=refresh_token,
            scope=" ".join(scopes) if scopes else None,
        )

    # ------------------------------------------------------------------
    # Token verification (called on every MCP request via BearerAuthBackend)
    # ------------------------------------------------------------------

    async def load_access_token(self, token: str) -> AccessToken | None:
        data = self.store.get_access_token(token)
        if data is None:
            return None

        # Set up per-request GmailClient via contextvar
        set_client_for_request(
            refresh_token=data["google_refresh_token"],
            client_id=self.google_client_id,
            client_secret=self.google_client_secret,
        )

        return AccessToken(
            token=token,
            client_id=data["client_id"],
            scopes=data.get("scopes") or [],
            expires_at=data.get("expires_at"),
            resource=data.get("resource"),
        )

    # ------------------------------------------------------------------
    # Refresh token flow
    # ------------------------------------------------------------------

    async def load_refresh_token(
        self,
        client: OAuthClientInformationFull,
        refresh_token: str,
    ) -> RefreshToken | None:
        data = self.store.get_refresh_token(refresh_token)
        if data is None:
            return None
        if data["client_id"] != client.client_id:
            return None
        return RefreshToken(
            token=refresh_token,
            client_id=data["client_id"],
            scopes=data.get("scopes") or [],
        )

    async def exchange_refresh_token(
        self,
        client: OAuthClientInformationFull,
        refresh_token: RefreshToken,
        scopes: list[str],
    ) -> OAuthToken:
        data = self.store.get_refresh_token(refresh_token.token)
        if data is None:
            raise TokenError(
                error="invalid_grant", error_description="Refresh token not found"
            )

        google_refresh_token = data["google_refresh_token"]
        effective_scopes = scopes if scopes else data.get("scopes") or []
        resource = data.get("resource")

        # Rotate tokens atomically
        new_access_token = secrets.token_urlsafe(32)
        new_refresh_token = secrets.token_urlsafe(32)
        expires_at = int(time.time()) + ACCESS_TOKEN_LIFETIME

        self.store.rotate_tokens(
            old_access_token=data.get("access_token"),
            old_refresh_token=refresh_token.token,
            new_access_token=new_access_token,
            new_access_data={
                "google_refresh_token": google_refresh_token,
                "client_id": client.client_id,
                "scopes": effective_scopes,
                "expires_at": expires_at,
                "refresh_token": new_refresh_token,
                "resource": resource,
            },
            new_refresh_token=new_refresh_token,
            new_refresh_data={
                "google_refresh_token": google_refresh_token,
                "client_id": client.client_id,
                "scopes": effective_scopes,
                "access_token": new_access_token,
                "resource": resource,
            },
        )

        return OAuthToken(
            access_token=new_access_token,
            token_type="Bearer",
            expires_in=ACCESS_TOKEN_LIFETIME,
            refresh_token=new_refresh_token,
            scope=" ".join(effective_scopes) if effective_scopes else None,
        )

    # ------------------------------------------------------------------
    # Revocation
    # ------------------------------------------------------------------

    async def revoke_token(
        self,
        token: AccessToken | RefreshToken,
    ) -> None:
        if isinstance(token, AccessToken):
            self.store.delete_tokens_for_access_token(token.token)
        elif isinstance(token, RefreshToken):
            self.store.delete_tokens_for_refresh_token(token.token)
