# Kernel version info database folder

The data contained in this folder was generated from the scripts available at https://github.com/marin-m/vte-samplelib