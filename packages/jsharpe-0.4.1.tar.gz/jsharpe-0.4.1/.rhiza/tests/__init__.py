"""Test package for rhiza tests.

This file makes test_rhiza a Python package, enabling relative imports
within the test modules (e.g., from .conftest import ...).
"""
