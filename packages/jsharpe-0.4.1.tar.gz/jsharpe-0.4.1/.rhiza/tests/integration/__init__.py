"""Integration tests — sandboxed git repos and subprocess execution."""
