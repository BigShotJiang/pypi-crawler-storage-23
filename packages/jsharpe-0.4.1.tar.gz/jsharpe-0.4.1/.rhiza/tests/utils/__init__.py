"""Utility tests — test infrastructure and helper utilities."""
