"""Dependency tests — requirements file content and pyproject validation."""
