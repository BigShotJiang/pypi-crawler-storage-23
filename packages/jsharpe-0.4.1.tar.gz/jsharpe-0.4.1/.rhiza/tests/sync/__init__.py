"""Sync tests — template sync, workflows, versioning, and content validation."""
