"""Structure tests — static assertions about file and directory presence."""
