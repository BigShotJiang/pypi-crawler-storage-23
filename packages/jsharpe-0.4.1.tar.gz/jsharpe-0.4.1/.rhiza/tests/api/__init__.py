"""API tests — Makefile target validation via dry-runs."""
