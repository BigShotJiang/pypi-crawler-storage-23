"""Version information for MicroPDF Python bindings."""

__version__ = "0.10.0"

