# shar

Простой магазин на PyQt6 + MySQL.

## Установка

```bash
pip install shar
```

## Получить файлы (app.py, database.sql, database.txt)

```bash
shar-get
```

Скопирует в текущую папку:
- app.py
- database.sql
- database.txt

## Запуск приложения

```bash
shar
```

## Требования

- Python 3.8+
- MySQL
- Выполни database.sql (или database.txt) в MySQL Workbench
