import os
import pymysql
from PyQt6.QtWidgets import *
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QPixmap, QIcon

DB = {"host": "localhost", "user": "root", "password": "anksoonamoon", "database": "users_db", "charset": "utf8mb4"}


def run_query(query, args=(), fetch=True):
    conn = pymysql.connect(**DB)
    cur = conn.cursor(pymysql.cursors.DictCursor)
    cur.execute(query, args)
    result = cur.fetchall() if fetch else None
    if not fetch:
        conn.commit()
    conn.close()
    return result


def get_user(login, password):
    rows = run_query("SELECT id, login FROM users WHERE login=%s AND password=%s", (login, password))
    return rows[0] if rows else None


def create_user(login, password):
    try:
        run_query("INSERT INTO users (login, password, is_admin) VALUES (%s, %s, 0)", (login, password), fetch=False)
        return True
    except Exception:
        return False


class Login(QWidget):
    def __init__(self, stacked):
        super().__init__()
        self.stacked = stacked
        self.setFixedSize(400, 300)
        layout = QVBoxLayout(self)
        self.login_edit = QLineEdit(placeholderText="Логин")
        self.pass_edit = QLineEdit(placeholderText="Пароль", echoMode=QLineEdit.EchoMode.Password)
        layout.addWidget(self.login_edit)
        layout.addWidget(self.pass_edit)
        layout.addWidget(QPushButton("Войти", clicked=self.do_login))
        layout.addWidget(QPushButton("Регистрация", clicked=self.do_register))

    def do_login(self):
        user = get_user(self.login_edit.text().strip(), self.pass_edit.text().strip())
        if user:
            self.stacked.widget(1).user_id = user["id"]
            self.stacked.setCurrentIndex(1)
        else:
            QMessageBox.warning(self, "", "Неверный логин или пароль")

    def do_register(self):
        login = self.login_edit.text().strip()
        password = self.pass_edit.text().strip()
        if login and password:
            if create_user(login, password):
                QMessageBox.information(self, "", "Успех")
            else:
                QMessageBox.warning(self, "", "Пользователь уже существует")


class Shop(QWidget):
    def __init__(self, stacked):
        super().__init__()
        self.stacked = stacked
        self.user_id = None
        self.setFixedSize(800, 600)
        main = QVBoxLayout(self)

        top = QHBoxLayout()
        self.search_edit = QLineEdit(placeholderText="Поиск...", textChanged=self.update_products)
        top.addWidget(self.search_edit)
        self.sort_combo = QComboBox()
        self.sort_combo.addItems(["По названию", "По цене"])
        self.sort_combo.currentTextChanged.connect(self.update_products)
        top.addWidget(self.sort_combo)
        main.addLayout(top)

        main.addWidget(QLabel("Товары:"))
        self.products_list = QListWidget()
        self.products_list.setMinimumHeight(200)
        self.products_list.setIconSize(QSize(48, 48))
        main.addWidget(self.products_list)
        main.addWidget(QPushButton("Добавить в корзину", clicked=self.add_to_cart))

        main.addWidget(QLabel("Корзина:"))
        self.cart_list = QListWidget()
        self.cart_list.setMinimumHeight(150)
        main.addWidget(self.cart_list)
        self.total_label = QLabel("Итого: 0 руб.")
        main.addWidget(self.total_label)

        buttons = QHBoxLayout()
        buttons.addWidget(QPushButton("Удалить из корзины", clicked=self.remove_from_cart))
        buttons.addWidget(QPushButton("Назад", clicked=lambda: self.stacked.setCurrentIndex(0)))
        main.addLayout(buttons)

    def showEvent(self, event):
        super().showEvent(event)
        self.update_products()

    def update_products(self):
        self.products_list.clear()
        search = self.search_edit.text().strip()
        conn = pymysql.connect(**DB)
        cur = conn.cursor(pymysql.cursors.DictCursor)
        if search:
            cur.execute("CALL sp_search_products(%s)", (search,))
        else:
            order = "name" if self.sort_combo.currentText() == "По названию" else "price"
            cur.execute("CALL sp_products_sorted(%s)", (order,))
        products = cur.fetchall()
        conn.close()

        pkg_dir = os.path.dirname(os.path.abspath(__file__))
        pix = QPixmap()
        for name in ("photo.jpg", "фото1.jpg"):
            path = os.path.join(pkg_dir, name)
            if os.path.exists(path):
                pix = QPixmap(path)
                break
        icon = QIcon(pix) if not pix.isNull() else QIcon()
        for product in products:
            item = QListWidgetItem(icon, f"{product['name']} | {product['price']} руб.")
            item.setData(Qt.ItemDataRole.UserRole, product["id"])
            self.products_list.addItem(item)
        self.update_cart()

    def update_cart(self):
        self.cart_list.clear()
        if not self.user_id:
            return
        conn = pymysql.connect(**DB)
        cur = conn.cursor(pymysql.cursors.DictCursor)
        cur.execute("SELECT * FROM v_cart_detail WHERE user_id=%s", (self.user_id,))
        for row in cur.fetchall():
            item = QListWidgetItem(f"{row['name']} x{row['quantity']} | {row['price']} руб.")
            item.setData(Qt.ItemDataRole.UserRole, row["product_id"])
            self.cart_list.addItem(item)
        cur.execute("SELECT fn_cart_total(%s) AS total", (self.user_id,))
        total = list(cur.fetchone().values())[0]
        self.total_label.setText(f"Итого: {total} руб.")
        conn.close()

    def add_to_cart(self):
        row = self.products_list.currentRow()
        if row < 0:
            QMessageBox.warning(self, "", "Выберите товар")
            return
        product_id = self.products_list.item(row).data(Qt.ItemDataRole.UserRole)
        conn = pymysql.connect(**DB)
        cur = conn.cursor()
        cur.callproc("sp_add_to_cart", (self.user_id, product_id))
        conn.commit()
        conn.close()
        self.update_cart()

    def remove_from_cart(self):
        row = self.cart_list.currentRow()
        if row < 0:
            QMessageBox.warning(self, "", "Выберите товар в корзине")
            return
        product_id = self.cart_list.item(row).data(Qt.ItemDataRole.UserRole)
        conn = pymysql.connect(**DB)
        cur = conn.cursor()
        cur.callproc("sp_remove_from_cart", (self.user_id, product_id))
        conn.commit()
        conn.close()
        self.update_cart()


def run():
    app = QApplication([])
    stacked = QStackedWidget()
    stacked.addWidget(Login(stacked))
    stacked.addWidget(Shop(stacked))
    stacked.show()
    app.exec()


if __name__ == "__main__":
    run()
