"""Shar - простой магазин на PyQt6 + MySQL."""
