"""Скопировать app.py, database.sql, database.txt в текущую папку."""
import shutil
import os


def main():
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    dest = os.getcwd()
    for name in ("app.py", "database.sql", "database.txt"):
        src = os.path.join(pkg_dir, name)
        if os.path.exists(src):
            shutil.copy(src, os.path.join(dest, name))
            print(f"Скопировано: {name}")
