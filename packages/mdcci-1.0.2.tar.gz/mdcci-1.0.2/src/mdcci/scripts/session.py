raw_usr = "zeta"
current_charset = []
