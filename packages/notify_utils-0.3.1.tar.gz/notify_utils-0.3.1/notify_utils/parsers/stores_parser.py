"""
Parsers específicos para lojas de e-commerce.

Implementações concretas da interface StoresParserInterface para
diferentes lojas (Nike, Maze Shop, Beleza na Web, etc).
"""

import logging
import json
import html
from typing import Optional
from notify_utils.models import Product, ResponseData
from notify_utils.parsers.stores_parser_interface import StoresParserInterface
from notify_utils.parser import parse_price

logger = logging.getLogger(__name__)


class ParserError(Exception):
    """
    Exceção customizada para erros de parsing.

    Levantada quando:
    - Formato de dados inválido
    - Parser não suporta o tipo de dados (JSON/HTML)
    - Dados obrigatórios estão ausentes
    """
    pass

class NikeAPIGatewayJSONParser(StoresParserInterface):
    """
    Parser para API Gateway da Nike.

    Extrai produtos de respostas JSON da API Gateway da Nike.

    Exemplo:
        >>> parser = NikeAPIGatewayJSONParser()
        >>> products = parser.from_json(nike_api_response)
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Nike de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API Gateway da Nike

        Returns:
            Lista de objetos Product extraídos (implementação pendente)

        Note:
            Implementação ainda não finalizada - retorna lista vazia
        """
        # TODO: Implementar lógica de parsing para Nike API Gateway
        logger.warning("NikeAPIGatewayJSONParser.from_json() não implementado ainda")
        return []

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para Nike API Gateway.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - Nike API usa JSON, não HTML
        """
        raise ParserError("HTML parsing is not supported for Nike API Gateway.")
    
    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se a resposta indica que é a última página de resultados.
        Args:
            response: Objeto ResponseData contendo status e dados da resposta
        Returns:
            bool: True se for a última página, False caso contrário
        Raises:
            NotImplementedError: Se o método não for implementado
        """
        raise NotImplementedError("Pagination check is not implemented for Nike API Gateway yet.")


class MazeAPIJSONParser(StoresParserInterface):
    """
    Parser para API da Maze Shop.

    Extrai produtos de respostas JSON da API da Maze Shop, incluindo:
    - ID do produto
    - Nome e descrição
    - Preços (atual e promocional)
    - Estoque e disponibilidade
    - URLs (produto e imagem)
    - SKU

    Validações automáticas:
    - Ignora produtos com preço inválido (≤ 0)
    - Converte preços com fallback seguro
    - Trata ausência de campos opcionais

    Exemplo:
        >>> parser = MazeAPIJSONParser()
        >>> products = parser.from_json(maze_api_response)
        >>> for product in products:
        ...     print(f"{product.name}: R$ {product.current_price}")
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Maze Shop de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API da Maze Shop
                      Estrutura esperada:
                      {
                          "products": [
                              {
                                  "idProduct": "123",
                                  "name": "Nome Produto",
                                  "price": 129.90,
                                  "pricePromotion": 99.90,
                                  "stock": 10,
                                  "urlFriendly": "produto-slug",
                                  "imageHome": "//cdn.maze.com.br/img.jpg",
                                  "code": "SKU123"
                              }
                          ]
                      }

        Returns:
            Lista de objetos Product extraídos e formatados.
            Lista vazia se não houver produtos ou se campo 'products' não existir.

        Note:
            - Produtos com preço inválido (≤ 0 ou None) são ignorados
            - Se pricePromotion existe, é usado como current_price
            - Caso contrário, price é usado como current_price
            - URLs são automaticamente formatadas com prefixo da loja
        """
        products: list[Product] = []
        logger.debug("Parsing Maze Shop products from JSON")

        products_json = json_data.get("products", [])
        if not products_json:
            logger.warning("No products found in JSON data.")
            return []

        for product_json in products_json:
            # Extrai preços com fallback seguro
            price_promotion = product_json.get("pricePromotion")
            price = product_json.get("price")
            available = product_json.get("stock", 0) > 0

            # Converte para float, tratando None e valores inválidos
            try:
                if price_promotion and float(price_promotion) > 0:
                    current_price = float(price_promotion)
                    old_price = float(price) if price else 0.0
                else:
                    current_price = float(price) if price else 0.0
                    old_price = 0.0  # Sem promoção: não há preço antigo diferente
            except (ValueError, TypeError):
                logger.warning(f"Preço inválido para produto {product_json.get('idProduct')}, pulando.")
                continue

            # Valida se o preço atual é válido (> 0)
            if current_price <= 0:
                logger.debug(f"Produto {product_json.get('idProduct')} tem preço atual inválido (R$ {current_price}), pulando.")
                continue

            url_friendly = product_json.get('urlFriendly', '') or ''
            image_home = product_json.get("imageHome", "") or ''

            product = Product(
                product_id=str(product_json.get("idProduct", "")),
                name=product_json.get("name", None),
                current_price_float=current_price,
                old_price_float=old_price,
                url=f"https://www.maze.com.br/{url_friendly}" if url_friendly else "",
                image_url=f"https:{image_home}" if image_home else "",
                sku=product_json.get("code", None),
                available=available,
                marketplace_name="Maze Shop",
                seller="Maze Shop"
            )

            products.append(product)
        return products

    def from_html(self, html_data: str) -> list[Product]:
        raise ParserError("HTML parsing is not supported for Maze API.")
    
    def is_last_page(self, response: ResponseData) -> bool:
        if not response.is_json():
            logger.warning("Response is not JSON, cannot determine pagination.")
            return True
        
        if response.is_not_found():
            logger.info("Response indicates no more pages (404 Not Found).")
            return True
        

        json_data = response.to_json()
        if json_data is None:
            logger.warning("Falha ao parsear JSON da resposta, assumindo última página.")
            return True

        products = json_data.get("products", [])
        if not products:
            logger.info("No products found in response, assuming no more pages.")
            return True

        return False  # Assume there may be more pages if products are present


class SephoraAPIJSONParser(StoresParserInterface):
    """
    Parser para API Linx Impulse da Sephora Brasil.

    Extrai produtos de respostas JSON da API da Sephora (Linx Impulse),
    expandindo SKUs (variações de tamanho) em produtos individuais.

    Características:
    - Expande SKUs: 1 produto com N variações → N produtos únicos
    - Cada SKU vira um Product separado (ex: 36 produtos → 105 SKUs)
    - Nome combinado: "{nome_produto} - {tamanho}"
    - Validações: preço > 0, status == "AVAILABLE"

    Estrutura JSON esperada:
    ```json
    {
      "products": [
        {
          "id": "33990494",
          "name": "Perfume Carolina Herrera Good Girl Blush...",
          "brand": "CAROLINA HERRERA",
          "url": "/perfume-...",
          "skus": [
            {
              "sku": "657444",
              "specs": { "size": "30 ml" },
              "properties": {
                "price": 453.43,
                "oldPrice": 529,
                "url": "/perfume-...-657444.html",
                "status": "AVAILABLE",
                "images": { "default": "//www.sephora..." }
              }
            }
          ]
        }
      ]
    }
    ```

    Exemplo:
        >>> parser = SephoraAPIJSONParser()
        >>> products = parser.from_json(sephora_response)
        >>> print(f"Extraídos {len(products)} SKUs únicos")
        Extraídos 105 SKUs únicos
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da Sephora de dados JSON, expandindo SKUs.

        Args:
            json_data: Dicionário contendo resposta JSON da API Sephora
                      Estrutura esperada:
                      {
                          "products": [
                              {
                                  "id": "33990494",
                                  "name": "Perfume X",
                                  "brand": "Marca Y",
                                  "url": "/produto",
                                  "skus": [
                                      {
                                          "sku": "657444",
                                          "specs": {"size": "30 ml"},
                                          "properties": {
                                              "price": 453.43,
                                              "oldPrice": 529,
                                              "url": "/produto-657444.html",
                                              "status": "AVAILABLE",
                                              "images": {"default": "//..."}
                                          }
                                      }
                                  ]
                              }
                          ]
                      }

        Returns:
            Lista de objetos Product expandidos (1 por SKU).
            Lista vazia se não houver produtos ou campo 'products' não existir.

        Note:
            - **Expande SKUs**: Cada SKU vira um Product individual
            - SKUs com `status != "AVAILABLE"` são ignorados
            - SKUs com `price <= 0` ou `None` são ignorados
            - Nome combinado: "{nome_produto} - {tamanho}"
            - URLs são convertidas para absolutas (https://www.sephora.com.br)
            - Imagens com protocolo relativo (`//cdn...`) ganham `https:`
            - oldPrice é opcional (default: 0.0)

        Example:
            >>> # 1 produto com 5 SKUs → 5 Products
            >>> parser = SephoraAPIJSONParser()
            >>> products = parser.from_json(api_data)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price_float}")
        """
        products: list[Product] = []
        logger.debug("Parsing Sephora products from JSON (expanding SKUs)")

        products_json = json_data.get("products", [])
        if not products_json:
            logger.warning("No products found in JSON data.")
            return []

        total_skus_processed = 0
        total_skus_ignored = 0

        for product_json in products_json:
            product_id = product_json.get("id")
            product_name = product_json.get("name", "")
            brand = product_json.get("brand", "")
            skus = product_json.get("skus", [])

            if not skus:
                logger.debug(f"Product {product_id} has no SKUs, skipping.")
                continue

            # Expandir cada SKU em um Product individual
            for sku_data in skus:
                try:
                    sku = sku_data.get("sku")
                    if not sku:
                        logger.debug(f"SKU without ID in product {product_id}, skipping.")
                        total_skus_ignored += 1
                        continue

                    # Extrair specs (tamanho/variação)
                    specs = sku_data.get("specs", {})
                    size = specs.get("size", "")

                    # Extrair properties (preços, status, urls)
                    props = sku_data.get("properties", {})
                    status = props.get("status", "UNAVAILABLE")

                    # Validação 1: Status
                    if status != "AVAILABLE":
                        logger.debug(f"SKU {sku} is not available (status={status}), skipping.")
                        total_skus_ignored += 1
                        continue

                    # Extrair preços
                    try:
                        current_price = float(props.get("price", 0))
                        old_price = float(props.get("oldPrice", 0))
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Invalid price for SKU {sku}: {e}, skipping.")
                        total_skus_ignored += 1
                        continue

                    # Validação 2: Preço válido
                    if current_price <= 0:
                        logger.debug(f"SKU {sku} has invalid price ({current_price}), skipping.")
                        total_skus_ignored += 1
                        continue

                    # Montar nome com tamanho
                    combined_name = f"{product_name} - {size}" if size else product_name

                    # URLs
                    sku_url = props.get("url", "")
                    absolute_url = self._make_absolute_url(sku_url)

                    # Imagem
                    images = props.get("images", {})
                    image_url = images.get("default", "")
                    if image_url and image_url.startswith("//"):
                        image_url = f"https:{image_url}"

                    # Criar Product
                    product = Product(
                        product_id=sku,  # SKU é o ID único
                        name=combined_name,
                        current_price_float=current_price,
                        old_price_float=old_price,
                        url=absolute_url,
                        image_url=image_url,
                        sku=sku,
                        available=True,  # Já validado acima
                        marketplace_name="Sephora Brasil",
                        seller="Sephora Brasil"
                    )

                    products.append(product)
                    total_skus_processed += 1

                except Exception as e:
                    logger.error(f"Unexpected error processing SKU in product {product_id}: {e}")
                    total_skus_ignored += 1
                    continue

        logger.info(
            f"Extracted {total_skus_processed} unique SKUs from {len(products_json)} products "
            f"({total_skus_ignored} SKUs ignored)"
        )

        return products

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para Sephora API.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - Sephora API usa JSON, não HTML
        """
        raise ParserError("Sephora API usa JSON, não HTML. Use from_json().")

    def _make_absolute_url(self, relative_url: str) -> str:
        """
        Converte URL relativa para absoluta.

        Args:
            relative_url: URL relativa ou absoluta

        Returns:
            URL absoluta com domínio completo da Sephora
        """
        if not relative_url:
            return ''

        if relative_url.startswith('http'):
            return relative_url

        if relative_url.startswith('/'):
            return f"https://www.sephora.com.br{relative_url}"

        return f"https://www.sephora.com.br/{relative_url}"

    def is_last_page(self, response: ResponseData) -> bool:
        """Verifica se a resposta indica que não há mais páginas (404 Not Found)."""


        return response.is_not_found()

class BelezaNaWebHTMLParser(StoresParserInterface):
    """
    Parser para HTML da Beleza na Web.

    Extrai produtos de páginas HTML da Beleza na Web (belezanaweb.com.br),
    com deduplicação automática de produtos repetidos em carrosséis.

    Características:
    - Parse híbrido: JSON embedded (data-event) + HTML estruturado
    - Deduplicação automática por SKU
    - Extrai: ID, nome, marca, preços (atual + antigo), URLs, desconto
    - Validações: ignora produtos sem SKU ou preço inválido

    Estrutura HTML esperada:
    - `<article class="showcase-item">` com atributo `data-event` (JSON)
    - Preço atual no JSON `data-event.price`
    - Preço antigo em `.item-price-max` (quando disponível)
    - URLs em `.showcase-card-link-overlay` e `img.showcase-image[data-src]`

    Exemplo:
        >>> parser = BelezaNaWebHTMLParser()
        >>> with open('beleza.html', 'r', encoding='utf-8') as f:
        ...     html = f.read()
        >>> products = parser.from_html(html)
        >>> print(f"Extraídos {len(products)} produtos únicos")
        Extraídos 36 produtos únicos
    """

    def __init__(self):
        """Inicializa parser e verifica dependência BeautifulSoup."""
        try:
            from bs4 import BeautifulSoup
            self.BeautifulSoup = BeautifulSoup
        except ImportError:
            raise ImportError(
                "beautifulsoup4 é necessário para BelezaNaWebHTMLParser. "
                "Instale com: pip install beautifulsoup4 lxml"
            )

    def from_json(self, json_data: dict) -> list[Product]:
        """
        JSON não suportado para Beleza na Web.

        Args:
            json_data: Dicionário JSON

        Raises:
            ParserError: Sempre - Beleza na Web usa HTML, não JSON
        """
        raise ParserError("Beleza na Web usa HTML parsing, não JSON. Use from_html().")

    def from_html(self, html_data: str) -> list[Product]:
        """
        Extrai produtos da Beleza na Web de HTML.

        Args:
            html_data: String contendo HTML da página de produtos
                      Estrutura esperada:
                      ```html
                      <article class="showcase-item" data-event="{...}">
                          <a class="showcase-card-link-overlay" href="/produto">...</a>
                          <img class="showcase-image" data-src="https://...">
                          <div class="item-price-max">R$ 599,00</div>
                          <span class="price-value">R$ 138,00</span>
                      </article>
                      ```

        Returns:
            Lista de objetos Product únicos (deduplicados por SKU).
            Lista vazia se não houver produtos válidos.

        Note:
            - Produtos duplicados (carrossel) são automaticamente removidos
            - Produtos sem SKU ou preço são ignorados com log de warning
            - Preço antigo é opcional (pode ser 0.0 se não disponível)
            - URLs relativas são convertidas para absolutas

        Example:
            >>> parser = BelezaNaWebHTMLParser()
            >>> products = parser.from_html(html_content)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - R$ {p.current_price}")
        """
        products: list[Product] = []
        seen_skus: set[str] = set()
        logger.debug("Parsing Beleza na Web products from HTML")

        try:
            # Parse HTML com lxml (mais rápido) ou html.parser (fallback)
            soup = self.BeautifulSoup(html_data, 'lxml')
        except Exception:
            # Fallback para html.parser se lxml não estiver instalado
            soup = self.BeautifulSoup(html_data, 'html.parser')
            logger.debug("lxml not available, using html.parser")

        # Encontrar todos os artigos de produtos
        articles = soup.find_all('article', class_='showcase-item')
        logger.debug(f"Found {len(articles)} article elements in HTML")

        duplicates_count = 0

        for article in articles:
            try:
                # 1. Parse JSON do data-event
                data_event_str = article.get('data-event', '{}')
                if not data_event_str or data_event_str == '{}':
                    logger.debug("Article without data-event, skipping")
                    continue

                # Unescape HTML entities (&quot; → ")
                data_event_str = html.unescape(data_event_str)
                data_event = json.loads(data_event_str)

                # 2. Extrair SKU e verificar duplicata
                sku = data_event.get('sku')
                if not sku:
                    logger.warning("Product without SKU in data-event, skipping")
                    continue

                if sku in seen_skus:
                    duplicates_count += 1
                    continue  # Skip duplicata

                seen_skus.add(sku)

                # 3. Extrair dados do JSON embedded
                current_price = float(data_event.get('price', 0))
                product_name = data_event.get('productName', '')
                brand = data_event.get('brand', '')

                # Validar preço
                if current_price <= 0:
                    logger.warning(f"Product {sku} has invalid price ({current_price}), skipping")
                    continue

                # 4. Extrair URL do produto
                url_elem = article.find('a', class_='showcase-card-link-overlay')
                relative_url = url_elem.get('href', '') if url_elem else ''
                product_url = self._make_absolute_url(relative_url)

                # 5. Extrair URL da imagem
                img_elem = article.find('img', class_='showcase-image')
                image_url = img_elem.get('data-src', '') if img_elem else ''

                # 6. Extrair preço antigo (opcional)
                old_price = self._extract_old_price(article)

                # 7. Criar objeto Product
                product = Product(
                    product_id=sku,
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=sku,
                    available=True,
                    marketplace_name="Beleza na Web",
                    seller="Beleza na Web"
                )

                products.append(product)

            except json.JSONDecodeError as e:
                logger.warning(f"Failed to parse data-event JSON: {e}")
                continue
            except (ValueError, TypeError) as e:
                logger.warning(f"Error processing product: {e}")
                continue
            except Exception as e:
                logger.error(f"Unexpected error processing article: {e}")
                continue

        logger.info(
            f"Extracted {len(products)} unique products "
            f"({duplicates_count} duplicates ignored)"
        )

        return products

    def _make_absolute_url(self, relative_url: str) -> str:
        """
        Converte URL relativa para absoluta.

        Args:
            relative_url: URL relativa ou absoluta

        Returns:
            URL absoluta com domínio completo
        """
        if not relative_url:
            return ''

        if relative_url.startswith('http'):
            return relative_url

        if relative_url.startswith('/'):
            return f"https://www.belezanaweb.com.br{relative_url}"

        return f"https://www.belezanaweb.com.br/{relative_url}"

    def _extract_old_price(self, article) -> float:
        """
        Extrai preço antigo (preço "de") do HTML.

        Args:
            article: Elemento BeautifulSoup do article

        Returns:
            Preço antigo como float, ou 0.0 se não disponível
        """
        try:
            old_price_elem = article.find('div', class_='item-price-max')
            if old_price_elem:
                old_price_text = old_price_elem.get_text(strip=True)
                # Parse usando função do projeto (normaliza "R$ 599,00" → 599.0)
                return parse_price(old_price_text)
        except Exception as e:
            logger.debug(f"Could not extract old price: {e}")

        return 0.0

    def is_last_page(self, response: ResponseData) -> bool:
        """Verifica se a resposta indica que não há mais páginas (404 Not Found)."""
        return response.is_not_found()


class NewEraAPIJSONParser(StoresParserInterface):
    """
    Parser para API da New Era Brasil.

    Extrai produtos de respostas JSON da API da New Era Brasil.

    Características:
    - **NÃO expande SKUs**: Retorna 1 Product por id_Product
    - `available = True` se PELO MENOS 1 SKU tiver estoque (qt_Stock > 0 e fg_B2C == True)
    - `available = False` se TODOS os SKUs estiverem sem estoque ou indisponíveis
    - SKU usado: primeiro SKU disponível encontrado
    - Validações: preço > 0

    Estrutura JSON esperada:
    ```json
    {
      "products": [
        {
          "id_Product": 105789,
          "nm_Product_Ecomm": "Camiseta Manga Curta NBA Indiana Pacers",
          "nm_Product": "camiseta-manga-curta-nba-indiana-pacers-nbi21tsh066",
          "nm_Brand": "NBA",
          "productPrice": [
            {
              "vl_Price": 118.9,
              "vl_Full_Price": 169.9,
              "vl_Perc_Discount": 30.02
            }
          ],
          "productStock": [
            {
              "cd_SKU": "7899564468967",
              "nm_Size": "P",
              "nm_Color": "Mescla Cinza",
              "qt_Stock": 1,
              "fg_B2C": true,
              "nm_Store": "New Era Brasil"
            }
          ],
          "productImage": [
            {
              "ds_Path_Image": "https://smarterappblob.blob.core.windows.net/public/1/image/thumb/...",
              "vl_Order": 1
            }
          ]
        }
      ],
      "qtProducts": 2476,
      "loadMore": true
    }
    ```

    Exemplo:
        >>> parser = NewEraAPIJSONParser()
        >>> products = parser.from_json(newera_response)
        >>> print(f"Extraídos {len(products)} produtos")
        Extraídos 48 produtos
        >>> available_count = sum(1 for p in products if p.available)
        >>> print(f"{available_count} produtos com estoque disponível")
    """

    def from_json(self, json_data: dict) -> list[Product]:
        """
        Extrai produtos da New Era de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API New Era
                      Estrutura esperada:
                      {
                          "products": [
                              {
                                  "id_Product": 105789,
                                  "nm_Product_Ecomm": "Nome do Produto",
                                  "nm_Product": "slug-produto",
                                  "nm_Brand": "Marca",
                                  "productPrice": [{"vl_Price": 99.90, "vl_Full_Price": 149.90}],
                                  "productStock": [
                                      {
                                          "cd_SKU": "123456789",
                                          "nm_Size": "M",
                                          "nm_Color": "Preto",
                                          "qt_Stock": 5,
                                          "fg_B2C": true,
                                          "nm_Store": "New Era Brasil"
                                      }
                                  ],
                                  "productImage": [{"ds_Path_Image": "https://..."}]
                              }
                          ],
                          "qtProducts": 2476,
                          "loadMore": true
                      }

        Returns:
            Lista de objetos Product (1 por id_Product).
            Lista vazia se não houver produtos ou campo 'products' não existir.

        Note:
            - **NÃO expande SKUs**: Retorna 1 Product por id_Product
            - `available = False` se TODOS os SKUs tiverem `qt_Stock <= 0` ou `fg_B2C == False`
            - `available = True` se PELO MENOS 1 SKU tiver `qt_Stock > 0` E `fg_B2C == True`
            - SKU usado: primeiro SKU disponível encontrado
            - Produtos com `vl_Price <= 0` são ignorados
            - URL: `https://www.neweracap.com.br/p/{nm_Product}`
            - Imagem: primeira imagem de `productImage` ordenada por `vl_Order`
            - Marketplace: "New Era Brasil"
            - Seller: extraído de `nm_Store` do primeiro SKU disponível

        Example:
            >>> parser = NewEraAPIJSONParser()
            >>> products = parser.from_json(api_data)
            >>> for p in products:
            ...     print(f"{p.product_id}: {p.name} - Disponível: {p.available}")
        """
        products: list[Product] = []
        logger.debug("Parsing New Era products from JSON")

        products_json = json_data.get("products", [])
        if not products_json:
            logger.warning("No products found in JSON data.")
            return []

        total_products_processed = 0
        total_products_ignored = 0

        for product_json in products_json:
            try:
                product_id = product_json.get("id_Product")
                product_name = product_json.get("nm_Product_Ecomm", "")
                product_slug = product_json.get("nm_Product", "")

                # Extrair preços do primeiro item de productPrice
                product_prices = product_json.get("productPrice", [])
                if not product_prices:
                    logger.debug(f"Product {product_id} has no prices, skipping.")
                    total_products_ignored += 1
                    continue

                price_data = product_prices[0]
                try:
                    current_price = float(price_data.get("vl_Price", 0))
                    old_price = float(price_data.get("vl_Full_Price", 0))
                except (ValueError, TypeError) as e:
                    logger.warning(f"Invalid price for product {product_id}: {e}, skipping.")
                    total_products_ignored += 1
                    continue

                # Validação: Preço válido
                if current_price <= 0:
                    logger.debug(f"Product {product_id} has invalid price ({current_price}), skipping.")
                    total_products_ignored += 1
                    continue

                # Extrair primeira imagem (ordenada por vl_Order)
                product_images = product_json.get("productImage", [])
                image_url = ""
                if product_images:
                    # Ordenar por vl_Order e pegar a primeira
                    sorted_images = sorted(product_images, key=lambda img: img.get("vl_Order", 999))
                    image_url = sorted_images[0].get("ds_Path_Image", "")

                # URL do produto
                product_url = f"https://www.neweracap.com.br/p/{product_slug}" if product_slug else ""

                # Verificar disponibilidade: pelo menos 1 SKU com estoque
                product_stocks = product_json.get("productStock", [])
                is_available = False
                first_available_sku = None
                first_seller = "New Era Brasil"

                for stock_data in product_stocks:
                    sku = stock_data.get("cd_SKU")
                    fg_b2c = stock_data.get("fg_B2C", False)
                    qt_stock = stock_data.get("qt_Stock", 0)

                    # Verifica se SKU está disponível
                    if sku and fg_b2c and qt_stock > 0:
                        is_available = True
                        if not first_available_sku:
                            first_available_sku = sku
                            first_seller = stock_data.get("nm_Store", "New Era Brasil")

                # Usar primeiro SKU disponível, ou primeiro SKU se nenhum disponível
                sku_to_use = first_available_sku
                if not sku_to_use and product_stocks:
                    # Se nenhum disponível, usar primeiro SKU mesmo assim
                    sku_to_use = product_stocks[0].get("cd_SKU", str(product_id))
                    first_seller = product_stocks[0].get("nm_Store", "New Era Brasil")
                elif not sku_to_use:
                    # Se não há stocks, usar id_Product como SKU
                    sku_to_use = str(product_id)

                # Criar Product
                product = Product(
                    product_id=str(product_id),
                    name=product_name,
                    current_price_float=current_price,
                    old_price_float=old_price,
                    url=product_url,
                    image_url=image_url,
                    sku=sku_to_use,
                    available=is_available,
                    marketplace_name="New Era Brasil",
                    seller=first_seller
                )

                products.append(product)
                total_products_processed += 1

            except Exception as e:
                logger.error(f"Unexpected error processing product {product_json.get('id_Product')}: {e}")
                total_products_ignored += 1
                continue

        logger.info(
            f"Extracted {total_products_processed} products from {len(products_json)} in response "
            f"({total_products_ignored} products ignored)"
        )

        return products

    def from_html(self, html_data: str) -> list[Product]:
        """
        HTML não suportado para New Era API.

        Args:
            html_data: String contendo HTML

        Raises:
            ParserError: Sempre - New Era API usa JSON, não HTML
        """
        raise ParserError("New Era API usa JSON, não HTML. Use from_json().")

    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se a resposta indica que é a última página de resultados.

        Args:
            response: Objeto ResponseData contendo status e dados da resposta

        Returns:
            bool: True se for a última página (loadMore == False ou sem produtos)

        Note:
            - Verifica campo `loadMore` no JSON
            - Também retorna True se não houver produtos na resposta
            - Retorna True se houver erro ao parsear JSON
        """
        # Verificar se é 404
        if response.is_not_found():
            return True

        # Tentar parsear JSON
        try:
            json_data = response.to_json()
            if not json_data:
                logger.debug("No JSON data in response, assuming last page.")
                return True

            # Verificar campo loadMore
            load_more = json_data.get("loadMore", False)
            if not load_more:
                logger.debug("loadMore is False, this is the last page.")
                return True

            # Verificar se há produtos
            products = json_data.get("products", [])
            if not products:
                logger.debug("No products in response, this is the last page.")
                return True

            return False

        except Exception as e:
            logger.warning(f"Error checking pagination: {e}, assuming last page.")
            return True