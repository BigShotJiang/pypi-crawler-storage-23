"""
Interface abstrata para parsers de lojas.
"""

from abc import ABC, abstractmethod
from notify_utils.models import ResponseData

class StoresParserInterface(ABC):
    """
    Interface abstrata para parsers de lojas específicas.

    Define métodos obrigatórios que cada parser deve implementar
    para extrair produtos de JSON ou HTML.

    Implementações devem herdar desta classe e fornecer lógica
    específica para cada loja (Nike, Maze, etc).
    """

    @abstractmethod
    def from_json(self, json_data: dict):
        """
        Extrai produtos de dados JSON.

        Args:
            json_data: Dicionário contendo resposta JSON da API

        Returns:
            Lista de objetos Product extraídos

        Raises:
            ParserError: Se parser não suportar JSON
        """
        raise NotImplementedError("JSON parsing is not implemented yet.")

    @abstractmethod
    def from_html(self, html_data: str):
        """
        Extrai produtos de HTML.

        Args:
            html_data: String contendo HTML da página

        Returns:
            Lista de objetos Product extraídos

        Raises:
            ParserError: Se parser não suportar HTML
        """
        raise NotImplementedError("HTML parsing is not implemented yet.")

    @abstractmethod
    def is_last_page(self, response: ResponseData) -> bool:
        """
        Verifica se a resposta indica que é a última página de resultados.
        Args:
            response: Objeto ResponseData contendo status e dados da resposta
        Returns:
            bool: True se for a última página, False caso contrário
        Raises:            NotImplementedError: Se o método não for implementado
        """
        raise NotImplementedError("Next page check is not implemented yet.")