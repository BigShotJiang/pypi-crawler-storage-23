# ADR-<NNN>: <название решения>

**Status:** proposed | accepted | deprecated | superseded by ADR-XXX
**Date:** <YYYY-MM-DD>

## Context
What problem or situation required a decision.

## Decision
What was decided and why.

## Alternatives
1. **<Alternative 1>:** <description> — rejected because <reason>
2. **<Alternative 2>:** <description> — rejected because <reason>

## Consequences
- Positive: <what improves>
- Negative: <trade-offs>
- Risks: <what could go wrong>
