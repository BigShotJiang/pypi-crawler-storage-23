from .flashlight import Flashlight

__all__ = [
    "Flashlight",
]
