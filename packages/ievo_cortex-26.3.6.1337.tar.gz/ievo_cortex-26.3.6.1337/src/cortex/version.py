"""Define the version of the cortex package."""

__version__ = "26.03.06.1337"
