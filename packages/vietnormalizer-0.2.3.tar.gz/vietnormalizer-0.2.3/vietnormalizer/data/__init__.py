# Data package for Vietnamese Normalizer
# Contains CSV dictionaries for acronyms and non-Vietnamese words

