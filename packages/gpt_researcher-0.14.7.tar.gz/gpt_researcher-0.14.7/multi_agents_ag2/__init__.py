"""AG2-powered multi-agent example for GPT Researcher."""
