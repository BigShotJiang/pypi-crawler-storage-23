# Copyright (c) 2025 Intel Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import copy
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor
from typing import Callable, Union

import threadpoolctl as tctl
import torch
import transformers
from tqdm import tqdm

from auto_round.data_type.utils import reshape_pad_tensor_by_group_size, revert_tensor_by_pad
from auto_round.export.export_to_autoround.export_to_fp8 import FP8QLinear
from auto_round.export.export_to_llmcompressor.config import check_compressed_tensors_supported
from auto_round.export.utils import save_model
from auto_round.utils import (
    SUPPORTED_LAYER_TYPES,
    check_start_with_block_name,
    check_to_quantized,
    copy_python_files_from_model_cache,
    get_module,
    get_packing_device,
    is_gaudi2,
    logger,
    set_module,
    unsupported_meta_device,
)


def pack_layer(layer_name: str, model: torch.nn.Module, data_type: str, device: str = None) -> None:
    """
    Packs a model layer for quantization based on its type and configuration.

    This function retrieves the specified layer from the model, checks its
    compatibility for quantization, and replaces it with a quantized version
    if applicable. The quantization process depends on the layer's bit-width,
    group size, symmetry, and activation bits.

    Args:
        layer_name (str): The name of the layer to be packed.
        model (torch.nn.Module): The model containing the layer.
        backend (str): The backend framework to be used for quantization.

    Returns:
        None: The function modifies the model in place.
    """
    from auto_round.export.export_to_autoround.export_to_fp8 import pack_layer as fp8_pack_layer

    fp8_pack_layer(layer_name, model, data_type, device, unsqueeze=True)


def _construct_kv_scheme():
    """Construct the default KV cache quantization scheme for FP8_STATIC export."""
    from compressed_tensors.quantization import (  # pylint: disable=E0401
        QuantizationArgs,
        QuantizationStrategy,
        QuantizationType,
    )

    default_kv_scheme = QuantizationArgs(
        num_bits=8,
        type=QuantizationType.FLOAT,
        strategy=QuantizationStrategy.TENSOR,
        symmetric=True,
        dynamic=False,
    )

    logger.warning_once(
        "Using default KV cache scheme: %s. "
        "Currently, only this KV cache scheme is supported for FP8_STATIC + FP8 KV.",
        repr(default_kv_scheme),
    )

    return default_kv_scheme


def _use_fp8_kv(static_kv_dtype: str | None) -> bool:
    """Return True if static KV cache should use FP8."""
    if static_kv_dtype in ("fp8", "float8_e4m3fn"):
        logger.warning_once("Exporting model with static KV cache in FP8 dtype.")
        return True
    return False


def _configure_gaudi2_fp8_dtype(quantization_config: dict) -> None:
    """Configure FP8 dtype flavor for Intel Gaudi2 hardware compatibility."""
    _GAUDI2_FP8_DTYPE_FLAVOR = "float8_e4m3fnuz"

    if is_gaudi2():
        quantization_config["fp8_dtype_flavor"] = _GAUDI2_FP8_DTYPE_FLAVOR
        logger.warning_once(
            (
                "Running on Intel Gaudi2 hardware."
                f" Setting FP8 dtype flavor to {_GAUDI2_FP8_DTYPE_FLAVOR} for compatibility."
            )
        )


def save_quantized_as_static_fp(
    output_dir: str,
    model: torch.nn.Module = None,
    tokenizer: Callable = None,
    layer_config: dict = None,
    inplace: bool = True,
    device: Union[str, torch.device] = "cpu",
    serialization_dict: dict = None,
    **kwargs,
) -> torch.nn.Module:
    """
    Saves a quantized model of FP8_STATIC scheme in the llm-compressor format.

    Args:
        output_dir (str): The directory where the quantized model will be saved.
        inplace (bool, optional): If True, modifies the model in place. Otherwise, creates a deepcopy of the model.
                                Default is True.
        backend (str, optional): The backend to be used for quantization.
                                  Default is "autoround:exllamav2".
        **kwargs: Additional keyword arguments including:
            - model (nn.Module): The model to be quantized.
            - layer_config (dict): The layer configuration for each layer.
            - serialization_dict (dict): The serialization configuration.
            - tokenizer (Tokenizer, optional): The tokenizer to be saved.

    Returns:
        None

    Raises:
        ValueError: If the backend is not supported.
    """
    safe_serialization = True if "safe_serialization" not in kwargs.keys() else kwargs["safe_serialization"]
    if not inplace:
        model = copy.deepcopy(model.to("cpu"))

    processor = kwargs.get("processor", None)
    image_processor = kwargs.get("image_processor", None)

    names = list(layer_config.keys())
    max_workers = 1
    if not torch.cuda.is_available() and not torch.xpu.is_available():
        max_workers = 2  ## 2 with cuda packing will cause hang occasionally
    if not unsupported_meta_device(model):
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            with tqdm(total=len(names), leave=True) as pbar:

                def wrapper(name):
                    pbar.set_description(f"packing {name}")
                    with tctl.threadpool_limits(limits=1):
                        pack_layer(name, model, serialization_dict.get("data_type", "fp8"), device)
                    pbar.update(1)

                for _ in executor.map(wrapper, names):
                    pass

    # Get llm-compressor format config
    check_compressed_tensors_supported()
    from compressed_tensors.quantization import (  # pylint: disable=E0401
        QuantizationArgs,
        QuantizationConfig,
        QuantizationScheme,
        QuantizationStatus,
        QuantizationStrategy,
        QuantizationType,
    )

    group_size = serialization_dict["group_size"]
    if group_size == -1:
        strategy = QuantizationStrategy.CHANNEL
    elif group_size == 0:
        strategy = QuantizationStrategy.TENSOR
    else:
        strategy = QuantizationStrategy.GROUP
    if serialization_dict["act_group_size"] != 0:
        logger.error(
            f"scheme FP8_STATIC export to llm_compressor format only support for act_group_size 0,"
            f" but got {serialization_dict['act_group_size']}, please check."
        )
        sys.exit(-1)
    scheme_args = dict(
        weights=QuantizationArgs(
            num_bits=8,
            type=QuantizationType.FLOAT,
            strategy=strategy,
            symmetric=True,
            dynamic=False,
        ),
        input_activations=QuantizationArgs(
            num_bits=8,
            type=QuantizationType.FLOAT,
            strategy=QuantizationStrategy.TENSOR,
            symmetric=True,
            dynamic=False,
        ),
    )
    targets = ["Linear"]
    ignore = []
    for layer_name in layer_config:
        if not check_to_quantized(layer_config[layer_name]):
            ignore.append(layer_name)
    config_groups = {}
    scheme = QuantizationScheme(targets=targets, **scheme_args)
    config_groups["group_0"] = scheme
    quantization_config = QuantizationConfig(
        config_groups=config_groups,
        kv_cache_scheme=(
            _construct_kv_scheme()
            if (
                _use_fp8_kv(serialization_dict.get("static_kv_dtype", None))
                or _use_fp8_kv(serialization_dict.get("static_attention_dtype", None))
            )
            else None
        ),
        quantization_status=QuantizationStatus.COMPRESSED,
        ignore=ignore,
    )
    quantization_config = quantization_config.to_dict()
    quantization_config["provider"] = "auto-round"
    _configure_gaudi2_fp8_dtype(quantization_config)
    quantization_config["format"] = "float-quantized"
    if group_size > 0:
        quantization_config["config_groups"]["group_0"]["weights"]["group_size"] = group_size
    if hasattr(model, "config"):
        model.config.quantization_config = quantization_config

    if output_dir is None:
        return model

    if os.path.exists(output_dir):
        logger.warning(f"{output_dir} already exists, this may cause model conflict")

    if tokenizer is not None:
        tokenizer.save_pretrained(output_dir)

    if processor is not None:
        processor.save_pretrained(output_dir)

    if image_processor is not None:
        image_processor.save_pretrained(output_dir)

    dtype = None
    save_model(model, output_dir, safe_serialization=safe_serialization, dtype=dtype)

    return model
