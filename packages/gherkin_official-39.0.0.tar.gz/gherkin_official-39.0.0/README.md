# Gherkin for Python

Gherkin parser/compiler for Python. Please see [Gherkin](https://github.com/cucumber/gherkin) for details.
