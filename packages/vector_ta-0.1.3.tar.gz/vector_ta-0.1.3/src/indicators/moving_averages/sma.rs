use crate::utilities::data_loader::{source_type, Candles};
use crate::utilities::enums::Kernel;
use crate::utilities::helpers::{
    alloc_with_nan_prefix, detect_best_batch_kernel, detect_best_kernel, init_matrix_prefixes,
    make_uninit_matrix,
};
#[cfg(feature = "python")]
use crate::utilities::kernel_validation::validate_kernel;
use aligned_vec::{AVec, CACHELINE_ALIGN};
#[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
use core::arch::x86_64::*;
#[cfg(not(target_arch = "wasm32"))]
use rayon::prelude::*;
use std::convert::AsRef;
use std::mem::MaybeUninit;
use thiserror::Error;

#[cfg(all(feature = "python", feature = "cuda"))]
use crate::cuda::moving_averages::{CudaSma, DeviceArrayF32};
#[cfg(all(feature = "python", feature = "cuda"))]
use cust::context::Context;
#[cfg(all(feature = "python", feature = "cuda"))]
use cust::memory::DeviceBuffer;
#[cfg(feature = "python")]
use numpy::{IntoPyArray, PyArray1, PyArrayMethods, PyReadonlyArray1, PyReadonlyArray2};
#[cfg(feature = "python")]
use pyo3::exceptions::PyValueError;
#[cfg(feature = "python")]
use pyo3::prelude::*;
#[cfg(feature = "python")]
use pyo3::types::PyDict;
#[cfg(all(feature = "python", feature = "cuda"))]
use std::sync::Arc;

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
use serde::{Deserialize, Serialize};
#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
use wasm_bindgen::prelude::*;

impl<'a> AsRef<[f64]> for SmaInput<'a> {
    #[inline(always)]
    fn as_ref(&self) -> &[f64] {
        match &self.data {
            SmaData::Slice(slice) => slice,
            SmaData::Candles { candles, source } => source_type(candles, source),
        }
    }
}

#[derive(Debug, Clone)]
pub enum SmaData<'a> {
    Candles {
        candles: &'a Candles,
        source: &'a str,
    },
    Slice(&'a [f64]),
}

#[derive(Debug, Clone)]
pub struct SmaOutput {
    pub values: Vec<f64>,
}

#[derive(Debug, Clone)]
#[cfg_attr(
    all(target_arch = "wasm32", feature = "wasm"),
    derive(Serialize, Deserialize)
)]
pub struct SmaParams {
    pub period: Option<usize>,
}

impl Default for SmaParams {
    fn default() -> Self {
        Self { period: Some(9) }
    }
}

#[derive(Debug, Clone)]
pub struct SmaInput<'a> {
    pub data: SmaData<'a>,
    pub params: SmaParams,
}

impl<'a> SmaInput<'a> {
    #[inline]
    pub fn from_candles(c: &'a Candles, s: &'a str, p: SmaParams) -> Self {
        Self {
            data: SmaData::Candles {
                candles: c,
                source: s,
            },
            params: p,
        }
    }
    #[inline]
    pub fn from_slice(sl: &'a [f64], p: SmaParams) -> Self {
        Self {
            data: SmaData::Slice(sl),
            params: p,
        }
    }
    #[inline]
    pub fn with_default_candles(c: &'a Candles) -> Self {
        Self::from_candles(c, "close", SmaParams::default())
    }
    #[inline]
    pub fn get_period(&self) -> usize {
        self.params.period.unwrap_or(9)
    }
}

#[derive(Copy, Clone, Debug)]
pub struct SmaBuilder {
    period: Option<usize>,
    kernel: Kernel,
}

impl Default for SmaBuilder {
    fn default() -> Self {
        Self {
            period: None,
            kernel: Kernel::Auto,
        }
    }
}

impl SmaBuilder {
    #[inline(always)]
    pub fn new() -> Self {
        Self::default()
    }
    #[inline(always)]
    pub fn period(mut self, n: usize) -> Self {
        self.period = Some(n);
        self
    }
    #[inline(always)]
    pub fn kernel(mut self, k: Kernel) -> Self {
        self.kernel = k;
        self
    }
    #[inline(always)]
    pub fn apply(self, c: &Candles) -> Result<SmaOutput, SmaError> {
        let p = SmaParams {
            period: self.period,
        };
        let i = SmaInput::from_candles(c, "close", p);
        sma_with_kernel(&i, self.kernel)
    }
    #[inline(always)]
    pub fn apply_slice(self, d: &[f64]) -> Result<SmaOutput, SmaError> {
        let p = SmaParams {
            period: self.period,
        };
        let i = SmaInput::from_slice(d, p);
        sma_with_kernel(&i, self.kernel)
    }
    #[inline(always)]
    pub fn into_stream(self) -> Result<SmaStream, SmaError> {
        let p = SmaParams {
            period: self.period,
        };
        SmaStream::try_new(p)
    }
}

#[derive(Debug, Error)]
pub enum SmaError {
    #[error("sma: Empty input data.")]
    EmptyInputData,
    #[error("sma: Invalid period: period = {period}, data length = {data_len}")]
    InvalidPeriod { period: usize, data_len: usize },
    #[error("sma: Not enough valid data: needed = {needed}, valid = {valid}")]
    NotEnoughValidData { needed: usize, valid: usize },
    #[error("sma: All values are NaN.")]
    AllValuesNaN,
    #[error("sma: Output buffer size mismatch: expected = {expected}, got = {got}")]
    OutputLengthMismatch { expected: usize, got: usize },
    #[error("sma: Invalid range: start={start}, end={end}, step={step}")]
    InvalidRange {
        start: usize,
        end: usize,
        step: usize,
    },
    #[error("sma: Invalid kernel for batch: {0:?}")]
    InvalidKernelForBatch(Kernel),
}

#[inline]
pub fn sma(input: &SmaInput) -> Result<SmaOutput, SmaError> {
    sma_with_kernel(input, Kernel::Auto)
}

pub fn sma_with_kernel(input: &SmaInput, kernel: Kernel) -> Result<SmaOutput, SmaError> {
    let (data, period, first, chosen) = sma_prepare(input, kernel)?;
    let mut out = alloc_with_nan_prefix(data.len(), first + period - 1);
    sma_compute_into(data, period, first, chosen, &mut out);
    Ok(SmaOutput { values: out })
}

#[cfg(not(all(target_arch = "wasm32", feature = "wasm")))]
#[inline]
pub fn sma_into(input: &SmaInput, out: &mut [f64]) -> Result<(), SmaError> {
    let (data, period, first, chosen) = sma_prepare(input, Kernel::Auto)?;

    if out.len() != data.len() {
        return Err(SmaError::OutputLengthMismatch {
            expected: data.len(),
            got: out.len(),
        });
    }

    let warm = (first + period - 1).min(out.len());
    for v in &mut out[..warm] {
        *v = f64::from_bits(0x7ff8_0000_0000_0000);
    }

    sma_compute_into(data, period, first, chosen, out);
    Ok(())
}

#[inline]
pub fn sma_into_slice(dst: &mut [f64], input: &SmaInput, kern: Kernel) -> Result<(), SmaError> {
    let (data, period, first, chosen) = sma_prepare(input, kern)?;

    if dst.len() != data.len() {
        return Err(SmaError::OutputLengthMismatch {
            expected: data.len(),
            got: dst.len(),
        });
    }

    let warmup = first + period - 1;
    for v in &mut dst[..warmup] {
        *v = f64::NAN;
    }

    sma_compute_into(data, period, first, chosen, dst);

    Ok(())
}

#[inline(always)]
fn sma_prepare<'a>(
    input: &'a SmaInput,
    kernel: Kernel,
) -> Result<(&'a [f64], usize, usize, Kernel), SmaError> {
    let data: &[f64] = input.as_ref();
    if data.is_empty() {
        return Err(SmaError::EmptyInputData);
    }

    let period = input.get_period();
    let len = data.len();
    if period == 0 || period > len {
        return Err(SmaError::InvalidPeriod {
            period,
            data_len: len,
        });
    }

    let first = data
        .iter()
        .position(|x| !x.is_nan())
        .ok_or(SmaError::AllValuesNaN)?;
    if len - first < period {
        return Err(SmaError::NotEnoughValidData {
            needed: period,
            valid: len - first,
        });
    }

    let chosen = match kernel {
        Kernel::Auto => detect_best_kernel(),
        k => k,
    };
    Ok((data, period, first, chosen))
}

#[inline]
fn sma_compute_into(data: &[f64], period: usize, first: usize, kernel: Kernel, out: &mut [f64]) {
    unsafe {
        match kernel {
            Kernel::Scalar | Kernel::ScalarBatch => {
                sma_scalar(data, period, first, out);
            }
            #[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
            Kernel::Avx2 | Kernel::Avx2Batch => {
                sma_scalar(data, period, first, out);
            }
            #[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
            Kernel::Avx512 | Kernel::Avx512Batch => {
                sma_avx512(data, period, first, out);
            }
            _ => unreachable!(),
        }
    }
}

#[inline(always)]
pub unsafe fn sma_scalar(data: &[f64], period: usize, first: usize, out: &mut [f64]) {
    debug_assert!(period >= 1);
    debug_assert_eq!(data.len(), out.len());
    let len = data.len();

    let dp = data.as_ptr();
    let op = out.as_mut_ptr();

    if period == 1 {
        for i in first..len {
            *op.add(i) = *dp.add(i);
        }
        return;
    }

    let mut sum = 0.0;
    for k in 0..period {
        sum += *dp.add(first + k);
    }
    let inv = 1.0 / (period as f64);

    *op.add(first + period - 1) = sum * inv;

    for i in (first + period)..len {
        sum += *dp.add(i) - *dp.add(i - period);
        *op.add(i) = sum * inv;
    }
}

#[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
#[target_feature(enable = "avx2")]
#[inline]
pub unsafe fn sma_avx2(data: &[f64], period: usize, first: usize, out: &mut [f64]) {
    use core::arch::x86_64::*;
    debug_assert!(period >= 1);
    debug_assert_eq!(data.len(), out.len());

    let len = data.len();
    let dp = data.as_ptr();
    let op = out.as_mut_ptr();

    if period == 1 {
        let mut i = first;
        while i < len {
            *op.add(i) = *dp.add(i);
            i += 1;
        }
        return;
    }

    let mut acc256 = _mm256_setzero_pd();
    let mut k = 0usize;
    let base = first;
    let p4 = period & !3;

    while k < p4 {
        let v = _mm256_loadu_pd(dp.add(base + k));
        acc256 = _mm256_add_pd(acc256, v);
        k += 4;
    }

    let hadd = _mm256_hadd_pd(acc256, acc256);
    let lo = _mm256_castpd256_pd128(hadd);
    let hi = _mm256_extractf128_pd(hadd, 1);
    let sum128 = _mm_add_sd(lo, hi);
    let mut sum = _mm_cvtsd_f64(sum128);

    while k < period {
        sum += *dp.add(base + k);
        k += 1;
    }

    let inv = 1.0 / (period as f64);
    let inv_v = _mm256_set1_pd(inv);
    let mut warm = first + period - 1;
    *op.add(warm) = sum.mul_add(inv, 0.0);

    let mut i = warm + 1;
    let end = len;
    let stride = 4usize;

    while i + stride - 1 < end {
        let v_new = _mm256_loadu_pd(dp.add(i));
        let v_old = _mm256_loadu_pd(dp.add(i - period));
        let d = _mm256_sub_pd(v_new, v_old);

        let d_lo = _mm256_castpd256_pd128(d);
        let d_hi = _mm256_extractf128_pd(d, 1);

        let t_lo = _mm_unpacklo_pd(_mm_setzero_pd(), d_lo);
        let p_lo = _mm_add_pd(d_lo, t_lo);

        let t_hi = _mm_unpacklo_pd(_mm_setzero_pd(), d_hi);
        let mut p_hi = _mm_add_pd(d_hi, t_hi);

        let carry = _mm_permute_pd(p_lo, 0b11);
        p_hi = _mm_add_pd(p_hi, carry);

        let mut prefix = _mm256_castpd128_pd256(p_lo);
        prefix = _mm256_insertf128_pd(prefix, p_hi, 1);

        let sum_v = _mm256_set1_pd(sum);
        let sums = _mm256_add_pd(sum_v, prefix);

        let out_v = _mm256_mul_pd(sums, inv_v);
        _mm256_storeu_pd(op.add(i), out_v);

        let sums_hi = _mm256_extractf128_pd(sums, 1);
        let last = _mm_unpackhi_pd(sums_hi, sums_hi);
        sum = _mm_cvtsd_f64(last);

        i += stride;
    }

    while i < end {
        sum += *dp.add(i) - *dp.add(i - period);
        *op.add(i) = sum.mul_add(inv, 0.0);
        i += 1;
    }
}

#[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
#[inline]
pub fn sma_avx512(data: &[f64], period: usize, first: usize, out: &mut [f64]) {
    if period <= 32 {
        unsafe { sma_avx512_short(data, period, first, out) }
    } else {
        unsafe { sma_avx512_long(data, period, first, out) }
    }
}

#[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
#[target_feature(enable = "avx512f")]
#[inline]
pub unsafe fn sma_avx512_short(data: &[f64], period: usize, first: usize, out: &mut [f64]) {
    sma_avx512_long(data, period, first, out);
}

#[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
#[target_feature(enable = "avx512f")]
#[inline]
pub unsafe fn sma_avx512_long(data: &[f64], period: usize, first: usize, out: &mut [f64]) {
    use core::arch::x86_64::*;
    debug_assert!(period >= 1);
    debug_assert_eq!(data.len(), out.len());

    let len = data.len();
    let dp = data.as_ptr();
    let op = out.as_mut_ptr();

    if period == 1 {
        let mut i = first;
        while i < len {
            *op.add(i) = *dp.add(i);
            i += 1;
        }
        return;
    }

    let mut acc512 = _mm512_setzero_pd();
    let mut k = 0usize;
    let base = first;
    let p8 = period & !7;

    while k < p8 {
        let v = _mm512_loadu_pd(dp.add(base + k));
        acc512 = _mm512_add_pd(acc512, v);
        k += 8;
    }

    let acc_lo256 = _mm512_castpd512_pd256(acc512);
    let acc_hi256 = _mm512_extractf64x4_pd(acc512, 1);
    let acc256 = _mm256_add_pd(acc_lo256, acc_hi256);

    let hadd = _mm256_hadd_pd(acc256, acc256);
    let lo = _mm256_castpd256_pd128(hadd);
    let hi = _mm256_extractf128_pd(hadd, 1);
    let sum128 = _mm_add_sd(lo, hi);
    let mut sum = _mm_cvtsd_f64(sum128);

    while k < period {
        sum += *dp.add(base + k);
        k += 1;
    }

    let inv = 1.0 / (period as f64);
    let inv_v = _mm512_set1_pd(inv);
    let warm = first + period - 1;
    *op.add(warm) = sum.mul_add(inv, 0.0);

    let idx_sl1 = _mm512_set_epi64(6, 5, 4, 3, 2, 1, 0, 0);

    let idx_sl2 = _mm512_set_epi64(5, 4, 3, 2, 1, 0, 0, 0);

    let idx_sl4 = _mm512_set_epi64(3, 2, 1, 0, 0, 0, 0, 0);

    let mut i = warm + 1;
    let end = len;

    while i + 7 < end {
        let v_new = _mm512_loadu_pd(dp.add(i));
        let v_old = _mm512_loadu_pd(dp.add(i - period));
        let d = _mm512_sub_pd(v_new, v_old);

        let mut pref = d;
        let sh1 = _mm512_maskz_permutexvar_pd(0b1111_1110, idx_sl1, pref);
        pref = _mm512_add_pd(pref, sh1);

        let sh2 = _mm512_maskz_permutexvar_pd(0b1111_1100, idx_sl2, pref);
        pref = _mm512_add_pd(pref, sh2);

        let sh4 = _mm512_maskz_permutexvar_pd(0b1111_0000, idx_sl4, pref);
        pref = _mm512_add_pd(pref, sh4);

        let sums = _mm512_add_pd(_mm512_set1_pd(sum), pref);

        let out_v = _mm512_mul_pd(sums, inv_v);
        _mm512_storeu_pd(op.add(i), out_v);

        let sums_hi256 = _mm512_extractf64x4_pd(sums, 1);
        let sums_hi128 = _mm256_extractf128_pd(sums_hi256, 1);
        let last = _mm_unpackhi_pd(sums_hi128, sums_hi128);
        sum = _mm_cvtsd_f64(last);

        i += 8;
    }

    while i < end {
        sum += *dp.add(i) - *dp.add(i - period);
        *op.add(i) = sum.mul_add(inv, 0.0);
        i += 1;
    }
}

#[derive(Debug, Clone)]
pub struct SmaStream {
    period: usize,
    buffer: Vec<f64>,
    head: usize,
    sum: f64,
    count: usize,
    inv: f64,

    use_mask: bool,
    mask: usize,
}

impl SmaStream {
    #[inline(always)]
    pub fn try_new(params: SmaParams) -> Result<Self, SmaError> {
        let period = params.period.unwrap_or(9);
        if period == 0 {
            return Err(SmaError::InvalidPeriod {
                period,
                data_len: 0,
            });
        }
        let use_mask = period.is_power_of_two();
        Ok(Self {
            period,
            buffer: vec![0.0; period],
            head: 0,
            sum: 0.0,
            count: 0,
            inv: (period as f64).recip(),
            use_mask,
            mask: period.wrapping_sub(1),
        })
    }

    #[inline(always)]
    fn advance_head(&mut self) {
        if self.use_mask {
            self.head = (self.head + 1) & self.mask;
        } else {
            let next = self.head + 1;
            self.head = if next == self.period { 0 } else { next };
        }
    }

    #[inline(always)]
    pub fn update(&mut self, value: f64) -> Option<f64> {
        if self.period == 1 {
            self.sum = value;
            self.buffer[0] = value;
            self.count = 1;
            return Some(value);
        }

        if self.count < self.period {
            self.sum += value;
            self.buffer[self.head] = value;
            self.advance_head();
            self.count += 1;
            if self.count == self.period {
                return Some(self.sum * self.inv);
            }
            return None;
        }

        let old = self.buffer[self.head];
        self.sum += value - old;
        self.buffer[self.head] = value;
        self.advance_head();
        Some(self.sum * self.inv)
    }
}

#[derive(Clone, Debug)]
pub struct SmaBatchRange {
    pub period: (usize, usize, usize),
}

impl Default for SmaBatchRange {
    fn default() -> Self {
        Self {
            period: (9, 258, 1),
        }
    }
}

#[derive(Clone, Debug, Default)]
pub struct SmaBatchBuilder {
    range: SmaBatchRange,
    kernel: Kernel,
}

impl SmaBatchBuilder {
    pub fn new() -> Self {
        Self::default()
    }
    pub fn kernel(mut self, k: Kernel) -> Self {
        self.kernel = k;
        self
    }
    #[inline]
    pub fn period_range(mut self, start: usize, end: usize, step: usize) -> Self {
        self.range.period = (start, end, step);
        self
    }
    #[inline]
    pub fn period_static(mut self, p: usize) -> Self {
        self.range.period = (p, p, 0);
        self
    }
    pub fn apply_slice(self, data: &[f64]) -> Result<SmaBatchOutput, SmaError> {
        sma_batch_with_kernel(data, &self.range, self.kernel)
    }
    pub fn with_default_slice(data: &[f64], k: Kernel) -> Result<SmaBatchOutput, SmaError> {
        SmaBatchBuilder::new().kernel(k).apply_slice(data)
    }
    pub fn apply_candles(self, c: &Candles, src: &str) -> Result<SmaBatchOutput, SmaError> {
        let slice = source_type(c, src);
        self.apply_slice(slice)
    }
    pub fn with_default_candles(c: &Candles) -> Result<SmaBatchOutput, SmaError> {
        SmaBatchBuilder::new()
            .kernel(Kernel::Auto)
            .apply_candles(c, "close")
    }
}

pub fn sma_batch_with_kernel(
    data: &[f64],
    sweep: &SmaBatchRange,
    k: Kernel,
) -> Result<SmaBatchOutput, SmaError> {
    let kernel = match k {
        Kernel::Auto => detect_best_batch_kernel(),
        other if other.is_batch() => other,
        other => return Err(SmaError::InvalidKernelForBatch(other)),
    };
    let simd = match kernel {
        Kernel::Avx512Batch => Kernel::Avx512,
        Kernel::Avx2Batch => Kernel::Avx2,
        Kernel::ScalarBatch => Kernel::Scalar,
        _ => unreachable!(),
    };
    sma_batch_par_slice(data, sweep, simd)
}

#[derive(Clone, Debug)]
pub struct SmaBatchOutput {
    pub values: Vec<f64>,
    pub combos: Vec<SmaParams>,
    pub rows: usize,
    pub cols: usize,
}
impl SmaBatchOutput {
    pub fn row_for_params(&self, p: &SmaParams) -> Option<usize> {
        self.combos
            .iter()
            .position(|c| c.period.unwrap_or(9) == p.period.unwrap_or(9))
    }
    pub fn values_for(&self, p: &SmaParams) -> Option<&[f64]> {
        self.row_for_params(p).map(|row| {
            let start = row * self.cols;
            &self.values[start..start + self.cols]
        })
    }
}

#[inline(always)]
pub fn expand_grid_sma(r: &SmaBatchRange) -> Result<Vec<SmaParams>, SmaError> {
    fn axis_usize((start, end, step): (usize, usize, usize)) -> Result<Vec<usize>, SmaError> {
        if step == 0 {
            return Ok(vec![start]);
        }
        if start == end {
            return Ok(vec![start]);
        }
        let mut vals = Vec::new();
        if start < end {
            let mut v = start;
            while v <= end {
                vals.push(v);
                match v.checked_add(step) {
                    Some(next) => {
                        if next == v {
                            break;
                        }
                        v = next;
                    }
                    None => break,
                }
            }
        } else {
            let mut v = start;
            while v >= end {
                vals.push(v);
                if v == 0 {
                    break;
                }
                let next = v.saturating_sub(step);
                if next == v {
                    break;
                }
                v = next;
                if v < end {
                    break;
                }
            }
        }
        if vals.is_empty() {
            return Err(SmaError::InvalidRange { start, end, step });
        }
        Ok(vals)
    }
    let periods = axis_usize(r.period)?;
    let mut out = Vec::with_capacity(periods.len());
    for &p in &periods {
        out.push(SmaParams { period: Some(p) });
    }
    Ok(out)
}

#[inline(always)]
pub fn sma_batch_slice(
    data: &[f64],
    sweep: &SmaBatchRange,
    kern: Kernel,
) -> Result<SmaBatchOutput, SmaError> {
    sma_batch_inner(data, sweep, kern, false)
}

#[inline(always)]
pub fn sma_batch_par_slice(
    data: &[f64],
    sweep: &SmaBatchRange,
    kern: Kernel,
) -> Result<SmaBatchOutput, SmaError> {
    sma_batch_inner(data, sweep, kern, true)
}

#[inline(always)]
fn sma_batch_inner(
    data: &[f64],
    sweep: &SmaBatchRange,
    kern: Kernel,
    parallel: bool,
) -> Result<SmaBatchOutput, SmaError> {
    let combos = expand_grid_sma(sweep)?;
    if data.is_empty() {
        return Err(SmaError::EmptyInputData);
    }

    let cols = data.len();
    let first = data
        .iter()
        .position(|x| !x.is_nan())
        .ok_or(SmaError::AllValuesNaN)?;
    let max_p = combos.iter().map(|c| c.period.unwrap()).max().unwrap();
    if cols - first < max_p {
        return Err(SmaError::NotEnoughValidData {
            needed: max_p,
            valid: cols - first,
        });
    }

    let rows = combos.len();

    rows.checked_mul(cols).ok_or(SmaError::InvalidRange {
        start: sweep.period.0,
        end: sweep.period.1,
        step: sweep.period.2,
    })?;

    let mut buf_mu = make_uninit_matrix(rows, cols);

    let mut guard = core::mem::ManuallyDrop::new(buf_mu);
    let out_slice: &mut [f64] =
        unsafe { core::slice::from_raw_parts_mut(guard.as_mut_ptr() as *mut f64, guard.len()) };

    sma_batch_inner_into(data, sweep, kern, parallel, out_slice)?;

    let values = unsafe {
        Vec::from_raw_parts(
            guard.as_mut_ptr() as *mut f64,
            guard.len(),
            guard.capacity(),
        )
    };

    Ok(SmaBatchOutput {
        values,
        combos,
        rows,
        cols,
    })
}

#[inline(always)]
unsafe fn sma_batch_row_prefixsum_scalar(
    ps: &[f64],
    period: usize,
    mut i: usize,
    cols: usize,
    inv: f64,
    dst: *mut f64,
) {
    while i < cols {
        let s_hi = *ps.get_unchecked(i);
        let s_lo = *ps.get_unchecked(i - period);
        *dst.add(i) = (s_hi - s_lo) * inv;
        i += 1;
    }
}

#[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
#[target_feature(enable = "avx2")]
#[inline]
unsafe fn sma_batch_row_prefixsum_avx2(
    ps: &[f64],
    period: usize,
    mut i: usize,
    cols: usize,
    inv: f64,
    dst: *mut f64,
) {
    use core::arch::x86_64::*;

    let inv_v = _mm256_set1_pd(inv);
    let ps_ptr = ps.as_ptr();
    let lanes = 4usize;

    while i + (lanes - 1) < cols {
        let hi = _mm256_loadu_pd(ps_ptr.add(i));
        let lo = _mm256_loadu_pd(ps_ptr.add(i - period));
        let diff = _mm256_sub_pd(hi, lo);
        let out_v = _mm256_mul_pd(diff, inv_v);
        _mm256_storeu_pd(dst.add(i), out_v);
        i += lanes;
    }

    sma_batch_row_prefixsum_scalar(ps, period, i, cols, inv, dst);
}

#[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
#[target_feature(enable = "avx512f")]
#[inline]
unsafe fn sma_batch_row_prefixsum_avx512(
    ps: &[f64],
    period: usize,
    mut i: usize,
    cols: usize,
    inv: f64,
    dst: *mut f64,
) {
    use core::arch::x86_64::*;

    let inv_v = _mm512_set1_pd(inv);
    let ps_ptr = ps.as_ptr();
    let lanes = 8usize;

    while i + (lanes - 1) < cols {
        let hi = _mm512_loadu_pd(ps_ptr.add(i));
        let lo = _mm512_loadu_pd(ps_ptr.add(i - period));
        let diff = _mm512_sub_pd(hi, lo);
        let out_v = _mm512_mul_pd(diff, inv_v);
        _mm512_storeu_pd(dst.add(i), out_v);
        i += lanes;
    }

    sma_batch_row_prefixsum_scalar(ps, period, i, cols, inv, dst);
}

#[inline(always)]
fn sma_batch_inner_into(
    data: &[f64],
    sweep: &SmaBatchRange,
    kern: Kernel,
    parallel: bool,
    out: &mut [f64],
) -> Result<Vec<SmaParams>, SmaError> {
    let combos = expand_grid_sma(sweep)?;
    if data.is_empty() {
        return Err(SmaError::EmptyInputData);
    }

    let first = data
        .iter()
        .position(|x| !x.is_nan())
        .ok_or(SmaError::AllValuesNaN)?;
    let max_p = combos.iter().map(|c| c.period.unwrap()).max().unwrap();
    if data.len() - first < max_p {
        return Err(SmaError::NotEnoughValidData {
            needed: max_p,
            valid: data.len() - first,
        });
    }

    let rows = combos.len();
    let cols = data.len();
    rows.checked_mul(cols).ok_or(SmaError::InvalidRange {
        start: sweep.period.0,
        end: sweep.period.1,
        step: sweep.period.2,
    })?;

    let actual_kern = match kern {
        Kernel::Auto => detect_best_batch_kernel(),
        k => k,
    };
    let actual_kern = match actual_kern {
        Kernel::Avx512Batch => Kernel::Avx512,
        Kernel::Avx2Batch => Kernel::Avx2,
        Kernel::ScalarBatch => Kernel::Scalar,
        other => other,
    };

    let out_uninit: &mut [MaybeUninit<f64>] = unsafe {
        core::slice::from_raw_parts_mut(out.as_mut_ptr() as *mut MaybeUninit<f64>, out.len())
    };

    let warm: Vec<usize> = combos
        .iter()
        .map(|c| first + c.period.unwrap_or(9) - 1)
        .collect();
    init_matrix_prefixes(out_uninit, cols, &warm);

    let mut ps = vec![0.0_f64; cols];
    if first < cols {
        ps[first] = data[first];
        for i in (first + 1)..cols {
            ps[i] = ps[i - 1] + data[i];
        }
    }

    let do_row = |row: usize, dst_mu: &mut [MaybeUninit<f64>]| unsafe {
        let period = combos[row].period.unwrap();
        let warm = first + period - 1;

        let dst = core::slice::from_raw_parts_mut(dst_mu.as_mut_ptr() as *mut f64, dst_mu.len());
        if warm >= cols {
            return;
        }
        let inv = (period as f64).recip();

        let s_hi = *ps.get_unchecked(warm);
        let s_lo = if warm >= period {
            *ps.get_unchecked(warm - period)
        } else {
            0.0
        };
        dst[warm] = (s_hi - s_lo) * inv;

        let mut i = warm + 1;
        if i >= cols {
            return;
        }

        let dst_ptr = dst.as_mut_ptr();
        match actual_kern {
            Kernel::Scalar => sma_batch_row_prefixsum_scalar(&ps, period, i, cols, inv, dst_ptr),
            #[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
            Kernel::Avx2 => sma_batch_row_prefixsum_avx2(&ps, period, i, cols, inv, dst_ptr),
            #[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
            Kernel::Avx512 => sma_batch_row_prefixsum_avx512(&ps, period, i, cols, inv, dst_ptr),
            _ => sma_batch_row_prefixsum_scalar(&ps, period, i, cols, inv, dst_ptr),
        }
    };

    if parallel {
        #[cfg(not(target_arch = "wasm32"))]
        out_uninit
            .par_chunks_mut(cols)
            .enumerate()
            .for_each(|(row, slice)| do_row(row, slice));
        #[cfg(target_arch = "wasm32")]
        for (row, slice) in out_uninit.chunks_mut(cols).enumerate() {
            do_row(row, slice);
        }
    } else {
        for (row, slice) in out_uninit.chunks_mut(cols).enumerate() {
            do_row(row, slice);
        }
    }

    Ok(combos)
}

#[inline(always)]
unsafe fn sma_row_scalar(data: &[f64], first: usize, period: usize, out: &mut [f64]) {
    sma_scalar(data, period, first, out);
}

#[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
#[inline(always)]
unsafe fn sma_row_avx2(data: &[f64], first: usize, period: usize, out: &mut [f64]) {
    sma_avx2(data, period, first, out);
}

#[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
#[inline(always)]
unsafe fn sma_row_avx512(data: &[f64], first: usize, period: usize, out: &mut [f64]) {
    if period <= 32 {
        sma_avx512_short(data, period, first, out);
    } else {
        sma_avx512_long(data, period, first, out);
    }
}

#[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
#[inline(always)]
unsafe fn sma_row_avx512_short(data: &[f64], period: usize, first: usize, out: &mut [f64]) {
    sma_avx512_short(data, period, first, out);
}

#[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
#[inline(always)]
unsafe fn sma_row_avx512_long(data: &[f64], period: usize, first: usize, out: &mut [f64]) {
    sma_avx512_long(data, period, first, out);
}

#[cfg(feature = "python")]
#[pyfunction(name = "sma")]
#[pyo3(signature = (data, period, kernel=None))]

pub fn sma_py<'py>(
    py: Python<'py>,
    data: PyReadonlyArray1<'py, f64>,
    period: usize,
    kernel: Option<&str>,
) -> PyResult<Bound<'py, PyArray1<f64>>> {
    use numpy::IntoPyArray;

    let kern = validate_kernel(kernel, false)?;

    let params = SmaParams {
        period: Some(period),
    };

    let result_vec: Vec<f64> = if let Ok(data_slice) = data.as_slice() {
        let input = SmaInput::from_slice(data_slice, params);
        py.allow_threads(|| sma_with_kernel(&input, kern).map(|o| o.values))
            .map_err(|e| PyValueError::new_err(e.to_string()))?
    } else {
        let owned = data.as_array().to_owned();
        let data_slice = owned
            .as_slice()
            .expect("owned numpy array should be contiguous");
        let input = SmaInput::from_slice(data_slice, params);
        py.allow_threads(|| sma_with_kernel(&input, kern).map(|o| o.values))
            .map_err(|e| PyValueError::new_err(e.to_string()))?
    };

    Ok(result_vec.into_pyarray(py))
}

#[cfg(feature = "python")]
#[pyfunction(name = "sma_batch")]
#[pyo3(signature = (data, period_range, kernel=None))]

pub fn sma_batch_py<'py>(
    py: Python<'py>,
    data: PyReadonlyArray1<'py, f64>,
    period_range: (usize, usize, usize),
    kernel: Option<&str>,
) -> PyResult<Bound<'py, PyDict>> {
    use numpy::IntoPyArray;
    use pyo3::types::PyDict;

    let kern = validate_kernel(kernel, true)?;

    let data_slice = data.as_slice()?;
    let range = SmaBatchRange {
        period: period_range,
    };

    let combos = expand_grid_sma(&range).map_err(|e| PyValueError::new_err(e.to_string()))?;
    if data_slice.is_empty() {
        return Err(PyValueError::new_err("Empty data"));
    }

    let rows = combos.len();
    let cols = data_slice.len();

    let nelems = rows
        .checked_mul(cols)
        .ok_or_else(|| PyValueError::new_err("rows*cols overflow"))?;

    let out_arr = unsafe { PyArray1::<f64>::new(py, [nelems], false) };
    let slice_out = unsafe { out_arr.as_slice_mut()? };

    let combos = py
        .allow_threads(|| {
            let kernel = match kern {
                Kernel::Auto => detect_best_batch_kernel(),
                k => k,
            };
            let simd = match kernel {
                Kernel::Avx512Batch => Kernel::Avx512,
                Kernel::Avx2Batch => Kernel::Avx2,
                Kernel::ScalarBatch => Kernel::Scalar,
                _ => unreachable!(),
            };

            sma_batch_inner_into(data_slice, &range, simd, true, slice_out)
        })
        .map_err(|e| PyValueError::new_err(e.to_string()))?;

    let dict = PyDict::new(py);
    dict.set_item("values", out_arr.reshape((rows, cols))?)?;

    dict.set_item(
        "periods",
        combos
            .iter()
            .map(|p| p.period.unwrap_or(9) as u64)
            .collect::<Vec<_>>()
            .into_pyarray(py),
    )?;

    Ok(dict.into())
}

#[cfg(all(feature = "python", feature = "cuda"))]
#[pyfunction(name = "sma_cuda_batch_dev")]
#[pyo3(signature = (data_f32, period_range, device_id=0))]
pub fn sma_cuda_batch_dev_py<'py>(
    py: Python<'py>,
    data_f32: numpy::PyReadonlyArray1<'py, f32>,
    period_range: (usize, usize, usize),
    device_id: usize,
) -> PyResult<(SmaDeviceArrayF32Py, Bound<'py, PyDict>)> {
    use crate::cuda::cuda_available;
    use numpy::IntoPyArray;
    use pyo3::types::PyDict;

    if !cuda_available() {
        return Err(PyValueError::new_err("CUDA not available"));
    }

    let slice_in = data_f32.as_slice()?;
    let sweep = SmaBatchRange {
        period: period_range,
    };

    let (inner, combos, ctx_arc, dev_id) = py.allow_threads(|| {
        let cuda = CudaSma::new(device_id).map_err(|e| PyValueError::new_err(e.to_string()))?;
        let (dev, combos) = cuda
            .sma_batch_dev(slice_in, &sweep)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        cuda.synchronize()
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok::<_, PyErr>((dev, combos, cuda.context_arc_clone(), cuda.device_id()))
    })?;

    let dict = PyDict::new(py);
    let periods: Vec<u64> = combos.iter().map(|c| c.period.unwrap() as u64).collect();
    dict.set_item("periods", periods.into_pyarray(py))?;

    Ok((
        SmaDeviceArrayF32Py {
            inner,
            _ctx: ctx_arc,
            device_id: dev_id,
        },
        dict,
    ))
}

#[cfg(all(feature = "python", feature = "cuda"))]
#[pyfunction(name = "sma_cuda_many_series_one_param_dev")]
#[pyo3(signature = (data_tm_f32, period, device_id=0))]
pub fn sma_cuda_many_series_one_param_dev_py(
    py: Python<'_>,
    data_tm_f32: numpy::PyReadonlyArray2<'_, f32>,
    period: usize,
    device_id: usize,
) -> PyResult<SmaDeviceArrayF32Py> {
    use crate::cuda::cuda_available;
    use numpy::PyUntypedArrayMethods;

    if !cuda_available() {
        return Err(PyValueError::new_err("CUDA not available"));
    }

    let flat_in = data_tm_f32.as_slice()?;
    let rows = data_tm_f32.shape()[0];
    let cols = data_tm_f32.shape()[1];
    let params = SmaParams {
        period: Some(period),
    };

    let (inner, ctx_arc, dev_id) = py.allow_threads(|| {
        let cuda = CudaSma::new(device_id).map_err(|e| PyValueError::new_err(e.to_string()))?;
        let dev = cuda
            .sma_multi_series_one_param_time_major_dev(flat_in, cols, rows, &params)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        cuda.synchronize()
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok::<_, PyErr>((dev, cuda.context_arc_clone(), cuda.device_id()))
    })?;

    Ok(SmaDeviceArrayF32Py {
        inner,
        _ctx: ctx_arc,
        device_id: dev_id,
    })
}

#[cfg(all(feature = "python", feature = "cuda"))]
#[pyclass(module = "ta_indicators.cuda", name = "SmaDeviceArrayF32", unsendable)]
pub struct SmaDeviceArrayF32Py {
    pub(crate) inner: DeviceArrayF32,
    pub(crate) _ctx: Arc<Context>,
    pub(crate) device_id: u32,
}

#[cfg(all(feature = "python", feature = "cuda"))]
#[pymethods]
impl SmaDeviceArrayF32Py {
    #[getter]
    fn __cuda_array_interface__<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        let d = PyDict::new(py);

        d.set_item("shape", (self.inner.rows, self.inner.cols))?;
        d.set_item("typestr", "<f4")?;
        d.set_item(
            "strides",
            (
                self.inner.cols * std::mem::size_of::<f32>(),
                std::mem::size_of::<f32>(),
            ),
        )?;
        d.set_item("data", (self.inner.device_ptr() as usize, false))?;

        d.set_item("version", 3)?;
        Ok(d)
    }

    fn __dlpack_device__(&self) -> (i32, i32) {
        (2, self.device_id as i32)
    }

    #[pyo3(signature=(stream=None, max_version=None, dl_device=None, copy=None))]
    fn __dlpack__<'py>(
        &mut self,
        py: Python<'py>,
        stream: Option<pyo3::PyObject>,
        max_version: Option<pyo3::PyObject>,
        dl_device: Option<pyo3::PyObject>,
        copy: Option<pyo3::PyObject>,
    ) -> PyResult<PyObject> {
        let (kdl, alloc_dev) = self.__dlpack_device__();
        if let Some(dev_obj) = dl_device.as_ref() {
            if let Ok((dev_ty, dev_id)) = dev_obj.extract::<(i32, i32)>(py) {
                if dev_ty != kdl || dev_id != alloc_dev {
                    let wants_copy = copy
                        .as_ref()
                        .and_then(|c| c.extract::<bool>(py).ok())
                        .unwrap_or(false);
                    if wants_copy {
                        return Err(PyValueError::new_err(
                            "device copy not implemented for __dlpack__",
                        ));
                    } else {
                        return Err(PyValueError::new_err("dl_device mismatch for __dlpack__"));
                    }
                }
            }
        }
        let _ = stream;

        let dummy =
            DeviceBuffer::from_slice(&[]).map_err(|e| PyValueError::new_err(e.to_string()))?;
        let inner = std::mem::replace(
            &mut self.inner,
            DeviceArrayF32 {
                buf: dummy,
                rows: 0,
                cols: 0,
            },
        );

        let rows = inner.rows;
        let cols = inner.cols;
        let buf = inner.buf;

        let max_version_bound = max_version.map(|obj| obj.into_bound(py));

        crate::utilities::dlpack_cuda::export_f32_cuda_dlpack_2d(
            py,
            buf,
            rows,
            cols,
            alloc_dev,
            max_version_bound,
        )
    }
}

#[cfg(feature = "python")]
#[pyclass(name = "SmaStream")]

pub struct SmaStreamPy {
    inner: SmaStream,
}

#[cfg(feature = "python")]
#[pymethods]
impl SmaStreamPy {
    #[new]
    #[pyo3(signature = (period))]
    pub fn new(period: usize) -> PyResult<Self> {
        let params = SmaParams {
            period: Some(period),
        };
        let inner = SmaStream::try_new(params).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    pub fn update(&mut self, value: f64) -> Option<f64> {
        self.inner.update(value)
    }
}

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
#[wasm_bindgen(js_name = "sma")]

pub fn sma_js(data: &[f64], period: usize) -> Result<Vec<f64>, JsValue> {
    let params = SmaParams {
        period: Some(period),
    };
    let input = SmaInput::from_slice(data, params);

    let mut output = vec![0.0; data.len()];

    sma_into_slice(&mut output, &input, Kernel::Auto)
        .map_err(|e| JsValue::from_str(&e.to_string()))?;

    Ok(output)
}

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
#[derive(Serialize, Deserialize)]
pub struct SmaBatchConfig {
    pub period_range: (usize, usize, usize),
}

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
#[derive(Serialize, Deserialize)]
pub struct SmaBatchJsOutput {
    pub values: Vec<f64>,
    pub combos: Vec<SmaParams>,
    pub periods: Vec<usize>,
    pub rows: usize,
    pub cols: usize,
}

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
#[wasm_bindgen(js_name = "sma_batch")]
pub fn sma_batch_unified_js(data: &[f64], config: JsValue) -> Result<JsValue, JsValue> {
    let config: SmaBatchConfig = serde_wasm_bindgen::from_value(config)
        .map_err(|e| JsValue::from_str(&format!("Invalid config: {}", e)))?;

    let sweep = SmaBatchRange {
        period: config.period_range,
    };

    let output = sma_batch_with_kernel(data, &sweep, Kernel::Auto)
        .map_err(|e| JsValue::from_str(&e.to_string()))?;

    let js_output = SmaBatchJsOutput {
        values: output.values,
        periods: output
            .combos
            .iter()
            .map(|c| c.period.unwrap_or(9))
            .collect(),
        combos: output.combos,
        rows: output.rows,
        cols: output.cols,
    };

    serde_wasm_bindgen::to_value(&js_output).map_err(|e| JsValue::from_str(&e.to_string()))
}

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
#[wasm_bindgen(js_name = "smaBatch")]
#[deprecated(since = "1.0.0", note = "Use sma_batch instead")]
pub fn sma_batch_js(
    data: &[f64],
    period_start: usize,
    period_end: usize,
    period_step: usize,
) -> Result<Vec<f64>, JsValue> {
    let range = SmaBatchRange {
        period: (period_start, period_end, period_step),
    };

    sma_batch_with_kernel(data, &range, Kernel::Auto)
        .map(|output| output.values)
        .map_err(|e| JsValue::from_str(&e.to_string()))
}

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
#[wasm_bindgen(js_name = "smaBatchMetadata")]
#[deprecated(since = "1.0.0", note = "Use sma_batch which returns metadata")]
pub fn sma_batch_metadata_js(
    period_start: usize,
    period_end: usize,
    period_step: usize,
) -> Vec<usize> {
    let range = SmaBatchRange {
        period: (period_start, period_end, period_step),
    };
    let combos = expand_grid_sma(&range).unwrap_or_default();
    combos.iter().map(|c| c.period.unwrap_or(9)).collect()
}

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
#[wasm_bindgen(js_name = "smaBatchRowsCols")]
#[deprecated(since = "1.0.0", note = "Use sma_batch which returns rows and cols")]
pub fn sma_batch_rows_cols_js(
    period_start: usize,
    period_end: usize,
    period_step: usize,
    data_len: usize,
) -> Vec<usize> {
    let range = SmaBatchRange {
        period: (period_start, period_end, period_step),
    };
    let combos = expand_grid_sma(&range).unwrap_or_default();
    vec![combos.len(), data_len]
}

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
#[wasm_bindgen]
pub fn sma_alloc(len: usize) -> *mut f64 {
    let mut vec = Vec::<f64>::with_capacity(len);
    let ptr = vec.as_mut_ptr();
    std::mem::forget(vec);
    ptr
}

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
#[wasm_bindgen]
pub fn sma_free(ptr: *mut f64, len: usize) {
    if !ptr.is_null() {
        unsafe {
            let _ = Vec::from_raw_parts(ptr, len, len);
        }
    }
}

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
#[wasm_bindgen]
pub fn sma_into(
    in_ptr: *const f64,
    out_ptr: *mut f64,
    len: usize,
    period: usize,
) -> Result<(), JsValue> {
    if in_ptr.is_null() || out_ptr.is_null() {
        return Err(JsValue::from_str("Null pointer provided"));
    }

    unsafe {
        let data = std::slice::from_raw_parts(in_ptr, len);

        let params = SmaParams {
            period: Some(period),
        };
        let input = SmaInput::from_slice(data, params);

        if in_ptr == out_ptr as *const f64 {
            let mut temp = vec![0.0; len];
            sma_into_slice(&mut temp, &input, Kernel::Auto)
                .map_err(|e| JsValue::from_str(&e.to_string()))?;

            let out = std::slice::from_raw_parts_mut(out_ptr, len);
            out.copy_from_slice(&temp);
        } else {
            let out = std::slice::from_raw_parts_mut(out_ptr, len);
            sma_into_slice(out, &input, Kernel::Auto)
                .map_err(|e| JsValue::from_str(&e.to_string()))?;
        }

        Ok(())
    }
}

#[cfg(all(target_arch = "wasm32", feature = "wasm"))]
#[wasm_bindgen]
pub fn sma_batch_into(
    in_ptr: *const f64,
    out_ptr: *mut f64,
    len: usize,
    period_start: usize,
    period_end: usize,
    period_step: usize,
) -> Result<usize, JsValue> {
    if in_ptr.is_null() || out_ptr.is_null() {
        return Err(JsValue::from_str("Null pointer provided"));
    }

    unsafe {
        let data = std::slice::from_raw_parts(in_ptr, len);

        let sweep = SmaBatchRange {
            period: (period_start, period_end, period_step),
        };

        let combos = expand_grid_sma(&sweep).map_err(|e| JsValue::from_str(&e.to_string()))?;
        let rows = combos.len();
        let total_size = rows * len;

        let out = std::slice::from_raw_parts_mut(out_ptr, total_size);

        let kernel = match detect_best_batch_kernel() {
            Kernel::Avx512Batch => Kernel::Avx512,
            Kernel::Avx2Batch => Kernel::Avx2,
            Kernel::ScalarBatch => Kernel::Scalar,
            other => other,
        };

        sma_batch_inner_into(data, &sweep, kernel, false, out)
            .map_err(|e| JsValue::from_str(&e.to_string()))?;

        Ok(rows)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::skip_if_unsupported;
    use crate::utilities::data_loader::read_candles_from_csv;

    #[test]
    fn test_sma_into_matches_api() -> Result<(), Box<dyn std::error::Error>> {
        let mut data = Vec::with_capacity(256);
        data.extend_from_slice(&[f64::NAN, f64::NAN, f64::NAN]);
        for i in 0..253u32 {
            let v = ((i % 17) as f64) * 1.2345 + (i as f64).sin() * 0.001;
            data.push(v);
        }

        let params = SmaParams::default();
        let input = SmaInput::from_slice(&data, params);

        let base = sma_with_kernel(&input, Kernel::Auto)?.values;

        let mut out = vec![0.0; data.len()];
        #[cfg(not(all(target_arch = "wasm32", feature = "wasm")))]
        {
            sma_into(&input, &mut out)?;
        }

        assert_eq!(base.len(), out.len());

        for (i, (a, b)) in base.iter().zip(out.iter()).enumerate() {
            let ok = if a.is_nan() && b.is_nan() {
                true
            } else {
                (a - b).abs() <= 1e-12
            };
            assert!(ok, "Mismatch at index {}: base={} vs into={}", i, a, b);
        }
        Ok(())
    }
    fn check_sma_partial_params(
        test_name: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test_name);
        let file_path = "src/data/2018-09-01-2024-Bitfinex_Spot-4h.csv";
        let candles = read_candles_from_csv(file_path)?;
        let default_params = SmaParams { period: None };
        let input = SmaInput::from_candles(&candles, "close", default_params);
        let output = sma_with_kernel(&input, kernel)?;
        assert_eq!(output.values.len(), candles.close.len());
        Ok(())
    }
    fn check_sma_accuracy(
        test_name: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test_name);
        let file_path = "src/data/2018-09-01-2024-Bitfinex_Spot-4h.csv";
        let candles = read_candles_from_csv(file_path)?;
        let params = SmaParams { period: Some(9) };
        let input = SmaInput::from_candles(&candles, "close", params);
        let result = sma_with_kernel(&input, kernel)?;
        let expected_last_five = [59180.8, 59175.0, 59129.4, 59085.4, 59133.7];
        let start = result.values.len().saturating_sub(5);
        for (i, &val) in result.values[start..].iter().enumerate() {
            let diff = (val - expected_last_five[i]).abs();
            assert!(
                diff < 1e-1,
                "[{}] SMA {:?} mismatch at idx {}: got {}, expected {}",
                test_name,
                kernel,
                i,
                val,
                expected_last_five[i]
            );
        }
        Ok(())
    }
    fn check_sma_default_candles(
        test_name: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test_name);
        let file_path = "src/data/2018-09-01-2024-Bitfinex_Spot-4h.csv";
        let candles = read_candles_from_csv(file_path)?;
        let input = SmaInput::with_default_candles(&candles);
        match input.data {
            SmaData::Candles { source, .. } => assert_eq!(source, "close"),
            _ => panic!("Expected SmaData::Candles"),
        }
        let output = sma_with_kernel(&input, kernel)?;
        assert_eq!(output.values.len(), candles.close.len());
        Ok(())
    }
    fn check_sma_zero_period(
        test_name: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test_name);
        let input_data = [10.0, 20.0, 30.0];
        let params = SmaParams { period: Some(0) };
        let input = SmaInput::from_slice(&input_data, params);
        let res = sma_with_kernel(&input, kernel);
        assert!(
            res.is_err(),
            "[{}] SMA should fail with zero period",
            test_name
        );
        Ok(())
    }
    fn check_sma_period_exceeds_length(
        test_name: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test_name);
        let data_small = [10.0, 20.0, 30.0];
        let params = SmaParams { period: Some(10) };
        let input = SmaInput::from_slice(&data_small, params);
        let res = sma_with_kernel(&input, kernel);
        assert!(
            res.is_err(),
            "[{}] SMA should fail with period exceeding length",
            test_name
        );
        Ok(())
    }
    fn check_sma_very_small_dataset(
        test_name: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test_name);
        let single_point = [42.0];
        let params = SmaParams { period: Some(9) };
        let input = SmaInput::from_slice(&single_point, params);
        let res = sma_with_kernel(&input, kernel);
        assert!(
            res.is_err(),
            "[{}] SMA should fail with insufficient data",
            test_name
        );
        Ok(())
    }
    fn check_sma_reinput(
        test_name: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test_name);
        let file_path = "src/data/2018-09-01-2024-Bitfinex_Spot-4h.csv";
        let candles = read_candles_from_csv(file_path)?;
        let first_params = SmaParams { period: Some(14) };
        let first_input = SmaInput::from_candles(&candles, "close", first_params);
        let first_result = sma_with_kernel(&first_input, kernel)?;
        let second_params = SmaParams { period: Some(14) };
        let second_input = SmaInput::from_slice(&first_result.values, second_params);
        let second_result = sma_with_kernel(&second_input, kernel)?;
        assert_eq!(second_result.values.len(), first_result.values.len());
        Ok(())
    }
    fn check_sma_nan_handling(
        test_name: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test_name);
        let file_path = "src/data/2018-09-01-2024-Bitfinex_Spot-4h.csv";
        let candles = read_candles_from_csv(file_path)?;
        let input = SmaInput::from_candles(&candles, "close", SmaParams { period: Some(9) });
        let res = sma_with_kernel(&input, kernel)?;
        assert_eq!(res.values.len(), candles.close.len());
        if res.values.len() > 240 {
            for (i, &val) in res.values[240..].iter().enumerate() {
                assert!(
                    !val.is_nan(),
                    "[{}] Found unexpected NaN at out-index {}",
                    test_name,
                    240 + i
                );
            }
        }
        Ok(())
    }
    fn check_sma_streaming(
        test_name: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test_name);
        let file_path = "src/data/2018-09-01-2024-Bitfinex_Spot-4h.csv";
        let candles = read_candles_from_csv(file_path)?;
        let period = 9;
        let input = SmaInput::from_candles(
            &candles,
            "close",
            SmaParams {
                period: Some(period),
            },
        );
        let batch_output = sma_with_kernel(&input, kernel)?.values;
        let mut stream = SmaStream::try_new(SmaParams {
            period: Some(period),
        })?;
        let mut stream_values = Vec::with_capacity(candles.close.len());
        for &price in &candles.close {
            match stream.update(price) {
                Some(sma_val) => stream_values.push(sma_val),
                None => stream_values.push(f64::NAN),
            }
        }
        assert_eq!(batch_output.len(), stream_values.len());
        for (i, (&b, &s)) in batch_output.iter().zip(stream_values.iter()).enumerate() {
            if b.is_nan() && s.is_nan() {
                continue;
            }
            let diff = (b - s).abs();
            assert!(
                diff < 1e-9,
                "[{}] SMA streaming f64 mismatch at idx {}: batch={}, stream={}, diff={}",
                test_name,
                i,
                b,
                s,
                diff
            );
        }
        Ok(())
    }

    #[cfg(debug_assertions)]
    fn check_sma_no_poison(
        test_name: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test_name);

        let file_path = "src/data/2018-09-01-2024-Bitfinex_Spot-4h.csv";
        let candles = read_candles_from_csv(file_path)?;

        let test_periods = vec![5, 9, 14, 20, 30, 50];

        for period in test_periods {
            let params = SmaParams {
                period: Some(period),
            };
            let input = SmaInput::from_candles(&candles, "close", params);
            let output = sma_with_kernel(&input, kernel)?;

            for (i, &val) in output.values.iter().enumerate() {
                if val.is_nan() {
                    continue;
                }

                let bits = val.to_bits();

                if bits == 0x11111111_11111111 {
                    panic!(
						"[{}] Found alloc_with_nan_prefix poison value {} (0x{:016X}) at index {} (period={})",
						test_name, val, bits, i, period
					);
                }

                if bits == 0x22222222_22222222 {
                    panic!(
						"[{}] Found init_matrix_prefixes poison value {} (0x{:016X}) at index {} (period={})",
						test_name, val, bits, i, period
					);
                }

                if bits == 0x33333333_33333333 {
                    panic!(
						"[{}] Found make_uninit_matrix poison value {} (0x{:016X}) at index {} (period={})",
						test_name, val, bits, i, period
					);
                }
            }
        }

        Ok(())
    }

    #[cfg(not(debug_assertions))]
    fn check_sma_no_poison(
        _test_name: &str,
        _kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        Ok(())
    }

    #[cfg(feature = "proptest")]
    #[allow(clippy::float_cmp)]
    fn check_sma_property(
        test_name: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        use proptest::prelude::*;
        skip_if_unsupported!(kernel, test_name);

        let strat = (1usize..=100).prop_flat_map(|period| {
            (
                prop::collection::vec(
                    (-1e6f64..1e6f64).prop_filter("finite", |x| x.is_finite()),
                    period..400,
                ),
                Just(period),
            )
        });

        proptest::test_runner::TestRunner::default()
            .run(&strat, |(data, period)| {
                let params = SmaParams {
                    period: Some(period),
                };
                let input = SmaInput::from_slice(&data, params);

                let SmaOutput { values: out } = sma_with_kernel(&input, kernel).unwrap();
                let SmaOutput { values: ref_out } =
                    sma_with_kernel(&input, Kernel::Scalar).unwrap();

                for i in 0..(period - 1) {
                    prop_assert!(
                        out[i].is_nan(),
                        "Expected NaN during warmup at index {}, got {}",
                        i,
                        out[i]
                    );
                }

                for i in (period - 1)..data.len() {
                    let window_start = i + 1 - period;
                    let window = &data[window_start..=i];

                    let expected_sum: f64 = window.iter().sum();
                    let expected_mean = expected_sum / period as f64;

                    let abs_tolerance = 1e-8_f64;
                    let rel_tolerance = 1e-12_f64;
                    let tolerance = abs_tolerance.max(expected_mean.abs() * rel_tolerance);

                    let kernel_tol = 5e-8_f64.max(tolerance);
                    prop_assert!(
                        (out[i] - expected_mean).abs() <= tolerance,
                        "SMA mismatch at index {}: expected {}, got {} (diff: {})",
                        i,
                        expected_mean,
                        out[i],
                        (out[i] - expected_mean).abs()
                    );

                    let window_min = window.iter().cloned().fold(f64::INFINITY, f64::min);
                    let window_max = window.iter().cloned().fold(f64::NEG_INFINITY, f64::max);

                    prop_assert!(
                        out[i] >= window_min - kernel_tol && out[i] <= window_max + kernel_tol,
                        "SMA out of bounds at index {}: {} not in [{}, {}]",
                        i,
                        out[i],
                        window_min,
                        window_max
                    );

                    if window.windows(2).all(|w| (w[0] - w[1]).abs() < 1e-12) {
                        let tolerance = kernel_tol.max(if period == 1 { 1e-8 } else { 1e-9 });
                        prop_assert!(
                            (out[i] - window[0]).abs() <= tolerance,
                            "Constant input property failed at index {}: expected {}, got {}",
                            i,
                            window[0],
                            out[i]
                        );
                    }

                    if period >= 3 {
                        let diffs: Vec<f64> = window.windows(2).map(|w| w[1] - w[0]).collect();
                        let is_linear = diffs.windows(2).all(|w| (w[0] - w[1]).abs() < 1e-9);

                        if is_linear && !diffs.is_empty() {
                            let midpoint_value = window[period / 2];
                            let tolerance = if period % 2 == 0 {
                                (window[period / 2 - 1] - window[period / 2]).abs() / 2.0
                                    + kernel_tol
                            } else {
                                kernel_tol
                            };

                            prop_assert!(
                                (out[i] - midpoint_value).abs() <= tolerance,
                                "Linear trend property failed at index {}: expected ~{}, got {}",
                                i,
                                midpoint_value,
                                out[i]
                            );
                        }
                    }

                    prop_assert!(
                        (out[i] - ref_out[i]).abs() <= kernel_tol
                            || (out[i].is_nan() && ref_out[i].is_nan()),
                        "Kernel mismatch at index {}: {} ({:?}) vs {} (Scalar)",
                        i,
                        out[i],
                        kernel,
                        ref_out[i]
                    );

                    if i >= period {
                        let new_value = data[i];
                        let old_value = data[i - period];
                        let expected_sma_change = (new_value - old_value) / period as f64;
                        let actual_sma_change = out[i] - out[i - 1];
                        let lag_tol = (expected_sma_change.abs() * rel_tolerance)
                            .max(5e-8_f64)
                            .max(2.0 * kernel_tol);

                        prop_assert!(
								(actual_sma_change - expected_sma_change).abs() <= lag_tol,
								"Lag property failed at index {}: SMA change {} should be {} (new: {}, old: {})",
								i,
								actual_sma_change,
							expected_sma_change,
							new_value,
							old_value
						);
                    }

                    #[cfg(debug_assertions)]
                    {
                        let bits = out[i].to_bits();
                        prop_assert!(
                            bits != 0x11111111_11111111
                                && bits != 0x22222222_22222222
                                && bits != 0x33333333_33333333,
                            "Found poison value at index {}: {} (0x{:016X})",
                            i,
                            out[i],
                            bits
                        );
                    }
                }

                if period == 1 {
                    for i in 0..data.len() {
                        prop_assert!(
                            (out[i] - data[i]).abs() <= 1e-8,
                            "Period=1 property failed at index {}: expected {}, got {}",
                            i,
                            data[i],
                            out[i]
                        );
                    }
                }

                Ok(())
            })
            .unwrap();

        Ok(())
    }

    macro_rules! generate_all_sma_tests {
        ($($test_fn:ident),*) => {
            paste::paste! {
                $(
                    #[test]
                    fn [<$test_fn _scalar_f64>]() {
                        let _ = $test_fn(stringify!([<$test_fn _scalar_f64>]), Kernel::Scalar);
                    }
                )*
                #[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
                $(
                    #[test]
                    fn [<$test_fn _avx2_f64>]() {
                        let _ = $test_fn(stringify!([<$test_fn _avx2_f64>]), Kernel::Avx2);
                    }
                    #[test]
                    fn [<$test_fn _avx512_f64>]() {
                        let _ = $test_fn(stringify!([<$test_fn _avx512_f64>]), Kernel::Avx512);
                    }
                )*
            }
        }
    }
    generate_all_sma_tests!(
        check_sma_partial_params,
        check_sma_accuracy,
        check_sma_default_candles,
        check_sma_zero_period,
        check_sma_period_exceeds_length,
        check_sma_very_small_dataset,
        check_sma_reinput,
        check_sma_nan_handling,
        check_sma_streaming,
        check_sma_no_poison
    );

    #[cfg(feature = "proptest")]
    generate_all_sma_tests!(check_sma_property);
    fn check_batch_default_row(
        test: &str,
        kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test);
        let file = "src/data/2018-09-01-2024-Bitfinex_Spot-4h.csv";
        let c = read_candles_from_csv(file)?;
        let output = SmaBatchBuilder::new()
            .kernel(kernel)
            .apply_candles(&c, "close")?;
        let def = SmaParams::default();
        let row = output.values_for(&def).expect("default row missing");
        assert_eq!(row.len(), c.close.len());
        let expected = [59180.8, 59175.0, 59129.4, 59085.4, 59133.7];
        let start = row.len() - 5;
        for (i, &v) in row[start..].iter().enumerate() {
            assert!(
                (v - expected[i]).abs() < 1e-1,
                "[{test}] default-row mismatch at idx {i}: {v} vs {expected:?}"
            );
        }
        Ok(())
    }

    #[cfg(debug_assertions)]
    fn check_batch_no_poison(test: &str, kernel: Kernel) -> Result<(), Box<dyn std::error::Error>> {
        skip_if_unsupported!(kernel, test);

        let file = "src/data/2018-09-01-2024-Bitfinex_Spot-4h.csv";
        let c = read_candles_from_csv(file)?;

        let test_configs = vec![(5, 15, 5), (10, 30, 10), (20, 50, 15), (2, 10, 2)];

        for (start, end, step) in test_configs {
            let output = SmaBatchBuilder::new()
                .kernel(kernel)
                .period_range(start, end, step)
                .apply_candles(&c, "close")?;

            for (idx, &val) in output.values.iter().enumerate() {
                if val.is_nan() {
                    continue;
                }

                let bits = val.to_bits();
                let row = idx / output.cols;
                let col = idx % output.cols;
                let period = output.combos[row].period.unwrap();

                if bits == 0x11111111_11111111 {
                    panic!(
                        "[{}] Found alloc_with_nan_prefix poison value {} (0x{:016X}) at row {} col {} (flat index {}, period={})",
                        test, val, bits, row, col, idx, period
                    );
                }

                if bits == 0x22222222_22222222 {
                    panic!(
                        "[{}] Found init_matrix_prefixes poison value {} (0x{:016X}) at row {} col {} (flat index {}, period={})",
                        test, val, bits, row, col, idx, period
                    );
                }

                if bits == 0x33333333_33333333 {
                    panic!(
                        "[{}] Found make_uninit_matrix poison value {} (0x{:016X}) at row {} col {} (flat index {}, period={})",
                        test, val, bits, row, col, idx, period
                    );
                }
            }
        }

        Ok(())
    }

    #[cfg(not(debug_assertions))]
    fn check_batch_no_poison(
        _test: &str,
        _kernel: Kernel,
    ) -> Result<(), Box<dyn std::error::Error>> {
        Ok(())
    }
    macro_rules! gen_batch_tests {
        ($fn_name:ident) => {
            paste::paste! {
                #[test] fn [<$fn_name _scalar>]()      {
                    let _ = $fn_name(stringify!([<$fn_name _scalar>]), Kernel::ScalarBatch);
                }
                #[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
                #[test] fn [<$fn_name _avx2>]()        {
                    let _ = $fn_name(stringify!([<$fn_name _avx2>]), Kernel::Avx2Batch);
                }
                #[cfg(all(feature = "nightly-avx", target_arch = "x86_64"))]
                #[test] fn [<$fn_name _avx512>]()      {
                    let _ = $fn_name(stringify!([<$fn_name _avx512>]), Kernel::Avx512Batch);
                }
                #[test] fn [<$fn_name _auto_detect>]() {
                    let _ = $fn_name(stringify!([<$fn_name _auto_detect>]), Kernel::Auto);
                }
            }
        };
    }
    gen_batch_tests!(check_batch_default_row);
    gen_batch_tests!(check_batch_no_poison);
}
