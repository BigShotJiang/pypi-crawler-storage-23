#[path = "wavetrend_wrapper.rs"]
pub mod wavetrend_wrapper;

pub use wavetrend_wrapper::{CudaWavetrend, CudaWavetrendBatch, CudaWavetrendError};
