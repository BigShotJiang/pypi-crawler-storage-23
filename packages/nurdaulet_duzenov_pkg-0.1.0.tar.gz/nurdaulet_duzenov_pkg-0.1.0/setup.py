
from setuptools import setup, find_packages

setup(
    name="nurdaulet_duzenov_pkg",
    version="0.1.0",
    packages=find_packages(),
    author="Erasyl",
    description="My first library from Colab",
    python_requires='>=3.6',
)
