def NurdauletDuzenov():
    print("mutable")