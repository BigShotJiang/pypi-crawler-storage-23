"""
Customer Retention ML Pipeline Framework.

A modular, production-ready framework for building customer retention
and churn prediction pipelines that work in both local and Databricks
environments.

Main module categories:
- core: Base infrastructure (config, utils, compatibility)
- stages: Pipeline stages (ingestion, profiling, cleaning, transformation,
          features, modeling, deployment, monitoring, validation, temporal)
- analysis: Analysis tools (diagnostics, interpretability, visualization,
            business, auto_explorer, discovery, recommendations)
- generators: Auto-generation tools (notebook_generator, pipeline_generator,
              orchestration)
- integrations: External system adapters (adapters, feature_store, streaming,
                llm_context, iteration)
"""

__version__ = "0.90.0a2"

# Environment utilities (always available)
from .core.compat import (
    is_databricks,
    is_notebook,
    is_spark_available,
    pd,
)

__all__ = [
    "__version__",
    # Environment
    "pd",
    "is_spark_available",
    "is_databricks",
    "is_notebook",
    # Databricks initialization
    "databricks_init",
]


def __getattr__(name: str):
    if name == "databricks_init":
        from .integrations.databricks_init import databricks_init

        return databricks_init
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
