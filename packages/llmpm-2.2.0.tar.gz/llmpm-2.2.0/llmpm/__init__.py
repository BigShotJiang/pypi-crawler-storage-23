"""llmpm — LLM Package Manager."""

__version__ = "2.2.0"
__author__ = "llmpm contributors"
