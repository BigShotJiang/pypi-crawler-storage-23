"""Tests for cli_sdk.output."""

from __future__ import annotations

from io import StringIO

from rich.console import Console

from cli_sdk import output


def _capture_console(fn, *args, **kwargs) -> str:
    """Run an output function with a captured console and return the text."""
    buf = StringIO()
    original = output.console
    output.console = Console(file=buf, force_terminal=False, width=120)
    try:
        fn(*args, **kwargs)
    finally:
        output.console = original
    return buf.getvalue()


def _capture_err_console(fn, *args, **kwargs) -> str:
    """Capture stderr console output."""
    buf = StringIO()
    original = output.err_console
    output.err_console = Console(file=buf, force_terminal=False, width=120)
    try:
        fn(*args, **kwargs)
    finally:
        output.err_console = original
    return buf.getvalue()


class TestPrintTable:
    def test_basic_table(self):
        text = _capture_console(output.print_table, ["Name", "Age"], [["Alice", 30], ["Bob", 25]])
        assert "Alice" in text
        assert "Bob" in text
        assert "Name" in text

    def test_table_with_title(self):
        text = _capture_console(
            output.print_table, ["Col"], [["val"]], title="My Table"
        )
        # Rich may wrap the title across lines at narrow widths, so check words
        assert "My" in text and "Table" in text

    def test_empty_rows(self):
        text = _capture_console(output.print_table, ["A", "B"], [])
        assert "A" in text
        assert "B" in text


class TestPrintJson:
    def test_dict_output(self):
        text = _capture_console(output.print_json, {"key": "value"})
        assert "key" in text
        assert "value" in text

    def test_string_input(self):
        text = _capture_console(output.print_json, '{"a": 1}')
        assert "a" in text


class TestMessages:
    def test_print_success(self):
        text = _capture_console(output.print_success, "All good")
        assert "SUCCESS" in text
        assert "All good" in text

    def test_print_error(self):
        text = _capture_err_console(output.print_error, "Something broke")
        assert "ERROR" in text
        assert "Something broke" in text

    def test_print_warning(self):
        text = _capture_console(output.print_warning, "Watch out")
        assert "WARNING" in text
        assert "Watch out" in text


class TestPrintTree:
    def test_nested_dict(self):
        data = {"a": {"b": "c"}, "d": [1, 2]}
        text = _capture_console(output.print_tree, data, label="test")
        assert "test" in text
        assert "a" in text
        assert "c" in text

    def test_flat_dict(self):
        text = _capture_console(output.print_tree, {"key": "val"})
        assert "key" in text
        assert "val" in text


class TestSpinner:
    def test_spinner_context_manager(self):
        # Spinner relies on terminal features; just verify it does not crash
        buf = StringIO()
        original = output.console
        output.console = Console(file=buf, force_terminal=False, width=80)
        try:
            with output.spinner("loading"):
                pass  # no-op
        finally:
            output.console = original
