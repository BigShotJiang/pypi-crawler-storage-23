"""Tests for cli_sdk.plugins."""

from __future__ import annotations

import click
import pytest

from cli_sdk.plugins import (
    clear_plugins,
    get_registered_plugins,
    load_plugins,
    register_plugin,
)


@pytest.fixture(autouse=True)
def _clean():
    clear_plugins()
    yield
    clear_plugins()


class TestRegisterPlugin:
    def test_register_and_retrieve(self):
        grp = click.Group("test-plugin")
        register_plugin("test-plugin", grp)

        plugins = get_registered_plugins()
        assert "test-plugin" in plugins
        assert plugins["test-plugin"] is grp

    def test_duplicate_raises(self):
        register_plugin("dup", click.Group("dup"))
        with pytest.raises(ValueError, match="already registered"):
            register_plugin("dup", click.Group("dup2"))

    def test_register_command(self):
        cmd = click.Command("cmd", callback=lambda: None)
        register_plugin("cmd", cmd)
        assert "cmd" in get_registered_plugins()


class TestLoadPlugins:
    def test_attaches_to_cli(self):
        cli = click.Group("root")
        grp = click.Group("ext")
        register_plugin("ext", grp)

        load_plugins(cli)
        assert "ext" in cli.commands

    def test_multiple_plugins(self):
        cli = click.Group("root")
        register_plugin("a", click.Group("a"))
        register_plugin("b", click.Group("b"))

        load_plugins(cli)
        assert "a" in cli.commands
        assert "b" in cli.commands


class TestClearPlugins:
    def test_clear_empties_registry(self):
        register_plugin("x", click.Group("x"))
        assert len(get_registered_plugins()) == 1
        clear_plugins()
        assert len(get_registered_plugins()) == 0
