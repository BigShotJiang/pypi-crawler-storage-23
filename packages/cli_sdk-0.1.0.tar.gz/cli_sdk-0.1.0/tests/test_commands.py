"""Tests for built-in commands: init, config, status."""

from __future__ import annotations

import json

from click.testing import CliRunner

from cli_sdk.base import create_cli
from cli_sdk.commands import config_group, init_command, status_command
from cli_sdk.config import reset_config


def _make_cli(tmp_path):
    """Create a test CLI with all built-in commands and a tmp config."""
    config_file = tmp_path / "config.json"
    config_file.write_text(json.dumps({"api_url": "http://localhost:9999", "api_key": "sk-test"}))

    cli = create_cli("testcli", "0.0.1")
    cli.add_command(init_command)
    cli.add_command(config_group)
    cli.add_command(status_command)
    return cli, config_file


class TestInitCommand:
    def setup_method(self):
        reset_config()

    def teardown_method(self):
        reset_config()

    def test_init_creates_config(self, tmp_path):
        out_file = tmp_path / "new-config.json"
        cli = create_cli("testcli", "0.0.1")
        cli.add_command(init_command)

        runner = CliRunner()
        result = runner.invoke(
            cli,
            ["--config", str(out_file), "init"],
            input="https://api.example.com\nmy-key\ntable\n",
        )
        assert result.exit_code == 0
        assert "SUCCESS" in result.output or "saved" in result.output.lower()


class TestConfigCommands:
    def setup_method(self):
        reset_config()

    def teardown_method(self):
        reset_config()

    def test_config_list(self, tmp_path):
        cli, config_file = _make_cli(tmp_path)
        runner = CliRunner()
        result = runner.invoke(cli, ["--config", str(config_file), "config", "list"])
        assert result.exit_code == 0
        assert "api_url" in result.output

    def test_config_get(self, tmp_path):
        cli, config_file = _make_cli(tmp_path)
        runner = CliRunner()
        result = runner.invoke(cli, ["--config", str(config_file), "config", "get", "api_url"])
        assert result.exit_code == 0
        assert "localhost:9999" in result.output

    def test_config_get_unknown_key(self, tmp_path):
        cli, config_file = _make_cli(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            cli, ["--config", str(config_file), "config", "get", "nonexistent"]
        )
        assert result.exit_code != 0

    def test_config_set(self, tmp_path):
        cli, config_file = _make_cli(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            cli, ["--config", str(config_file), "config", "set", "api_url", "https://new.io"]
        )
        assert result.exit_code == 0
        assert "SUCCESS" in result.output or "Set" in result.output

    def test_config_list_json(self, tmp_path):
        cli, config_file = _make_cli(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            cli, ["--json-output", "--config", str(config_file), "config", "list"]
        )
        assert result.exit_code == 0
        # JSON output should contain api_url
        assert "api_url" in result.output


class TestStatusCommand:
    def setup_method(self):
        reset_config()

    def teardown_method(self):
        reset_config()

    def test_status_shows_config(self, tmp_path):
        cli, config_file = _make_cli(tmp_path)
        runner = CliRunner()
        result = runner.invoke(cli, ["--config", str(config_file), "status"])
        # Should display API URL and auth status
        assert "localhost:9999" in result.output or "API" in result.output

    def test_status_json_output(self, tmp_path):
        cli, config_file = _make_cli(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            cli, ["--json-output", "--config", str(config_file), "status"]
        )
        assert result.exit_code == 0
        assert "api_url" in result.output
