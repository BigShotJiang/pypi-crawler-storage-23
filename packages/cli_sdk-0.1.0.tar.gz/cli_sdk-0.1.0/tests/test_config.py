"""Tests for cli_sdk.config."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from cli_sdk.config import CLIConfig, load_config, reset_config, save_config, get_config


@pytest.fixture(autouse=True)
def _reset():
    """Reset config singleton between tests."""
    reset_config()
    yield
    reset_config()


class TestCLIConfig:
    def test_defaults(self):
        cfg = CLIConfig()
        assert cfg.api_url == "http://localhost:8000"
        assert cfg.api_key == ""
        assert cfg.output_format == "table"

    def test_custom_values(self):
        cfg = CLIConfig(api_url="https://api.example.com", api_key="sk-123", output_format="json")
        assert cfg.api_url == "https://api.example.com"
        assert cfg.api_key == "sk-123"
        assert cfg.output_format == "json"

    def test_extra_fields_allowed(self):
        cfg = CLIConfig(custom_field="hello")
        assert cfg.custom_field == "hello"  # type: ignore[attr-defined]


class TestLoadConfig:
    def test_load_from_file(self, tmp_path: Path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"api_url": "https://test.io", "api_key": "key-abc"}))

        cfg = load_config(path=config_file)
        assert cfg.api_url == "https://test.io"
        assert cfg.api_key == "key-abc"

    def test_load_missing_file_returns_defaults(self, tmp_path: Path):
        cfg = load_config(path=tmp_path / "nonexistent.json")
        assert cfg.api_url == "http://localhost:8000"

    def test_load_partial_file(self, tmp_path: Path):
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps({"api_key": "partial"}))

        cfg = load_config(path=config_file)
        assert cfg.api_key == "partial"
        assert cfg.api_url == "http://localhost:8000"  # default preserved


class TestSaveConfig:
    def test_save_creates_file(self, tmp_path: Path):
        cfg = CLIConfig(api_url="https://saved.io")
        path = save_config(cfg, path=tmp_path / "out.json")

        assert path.exists()
        data = json.loads(path.read_text())
        assert data["api_url"] == "https://saved.io"

    def test_save_creates_parent_dirs(self, tmp_path: Path):
        nested = tmp_path / "a" / "b" / "config.json"
        save_config(CLIConfig(), path=nested)
        assert nested.exists()

    def test_save_updates_singleton(self, tmp_path: Path):
        new_cfg = CLIConfig(api_url="https://updated.io")
        save_config(new_cfg, path=tmp_path / "cfg.json")
        assert get_config().api_url == "https://updated.io"


class TestGetConfig:
    def test_returns_default_when_not_loaded(self):
        cfg = get_config()
        assert isinstance(cfg, CLIConfig)
        assert cfg.api_url == "http://localhost:8000"

    def test_returns_same_instance(self):
        a = get_config()
        b = get_config()
        assert a is b
