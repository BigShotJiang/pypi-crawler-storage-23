"""Tests for cli_sdk.base -- create_cli, BaseCommand, decorators."""

from __future__ import annotations

import click
from click.testing import CliRunner

from cli_sdk.base import BaseCommand, create_cli, requires_auth, with_spinner
from cli_sdk.config import reset_config


class TestCreateCli:
    def setup_method(self):
        reset_config()

    def teardown_method(self):
        reset_config()

    def test_creates_group_with_version(self):
        cli = create_cli("myapp", "1.0.0")
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert "1.0.0" in result.output

    def test_verbose_flag(self):
        cli = create_cli("myapp", "0.1.0")

        @cli.command()
        @click.pass_context
        def check(ctx):
            click.echo(f"verbose={ctx.obj['verbose']}")

        runner = CliRunner()
        result = runner.invoke(cli, ["-v", "check"])
        assert "verbose=True" in result.output

    def test_json_output_flag(self):
        cli = create_cli("myapp", "0.1.0")

        @cli.command()
        @click.pass_context
        def check(ctx):
            click.echo(f"json={ctx.obj['json_output']}")

        runner = CliRunner()
        result = runner.invoke(cli, ["--json-output", "check"])
        assert "json=True" in result.output

    def test_config_loaded(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_file.write_text('{"api_url": "https://test.io"}')

        cli = create_cli("myapp", "0.1.0")

        @cli.command()
        @click.pass_context
        def check(ctx):
            click.echo(f"url={ctx.obj['config'].api_url}")

        runner = CliRunner()
        result = runner.invoke(cli, ["--config", str(config_file), "check"])
        assert "url=https://test.io" in result.output


class TestBaseCommand:
    def test_basic_command(self):
        cli = click.Group("test")
        cmd = BaseCommand("greet", help="Say hi")
        cmd.add_argument("name")

        @cmd.callback
        def greet(name):
            click.echo(f"Hello, {name}!")

        cli.add_command(cmd.as_click_command())

        runner = CliRunner()
        result = runner.invoke(cli, ["greet", "World"])
        assert "Hello, World!" in result.output

    def test_error_handling(self):
        cli = click.Group("test")
        cmd = BaseCommand("fail", help="Fails")

        @cmd.callback
        def fail():
            raise RuntimeError("boom")

        cli.add_command(cmd.as_click_command())

        runner = CliRunner()
        result = runner.invoke(cli, ["fail"])
        assert result.exit_code == 1

    def test_no_callback_raises(self):
        cmd = BaseCommand("empty")
        import pytest

        with pytest.raises(RuntimeError, match="No callback"):
            cmd.as_click_command()

    def test_with_option(self):
        cli = click.Group("test")
        cmd = BaseCommand("echo", help="Echo")
        cmd.add_option("--msg", default="hi")

        @cmd.callback
        def echo(msg):
            click.echo(msg)

        cli.add_command(cmd.as_click_command())

        runner = CliRunner()
        result = runner.invoke(cli, ["echo", "--msg", "bye"])
        assert "bye" in result.output


class TestRequiresAuth:
    def setup_method(self):
        reset_config()

    def teardown_method(self):
        reset_config()

    def test_fails_without_api_key(self, tmp_path):
        config_file = tmp_path / "config.json"
        config_file.write_text('{"api_key": ""}')

        cli = create_cli("myapp", "0.1.0")

        @cli.command()
        @requires_auth
        def secret(self):
            click.echo("secret stuff")

        runner = CliRunner()
        result = runner.invoke(cli, ["--config", str(config_file), "secret"])
        assert result.exit_code != 0


class TestWithSpinner:
    def test_decorator_runs_function(self):
        called = False

        @with_spinner("test")
        def do_work():
            nonlocal called
            called = True

        do_work()
        assert called
