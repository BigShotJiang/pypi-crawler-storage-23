"""Tests for cli_sdk.api_client."""

from __future__ import annotations

import json

import httpx
import pytest
import respx

from cli_sdk.api_client import APIClient, APIError


BASE = "https://api.test.com"


class TestAPIClient:
    def test_get_success(self):
        with respx.mock:
            respx.get(f"{BASE}/items").mock(
                return_value=httpx.Response(200, json={"items": [1, 2, 3]})
            )
            with APIClient(BASE) as client:
                result = client.get("/items")
            assert result == {"items": [1, 2, 3]}

    def test_get_with_params(self):
        with respx.mock:
            route = respx.get(f"{BASE}/search").mock(
                return_value=httpx.Response(200, json={"q": "hello"})
            )
            with APIClient(BASE) as client:
                client.get("/search", params={"q": "hello"})
            assert route.called

    def test_post_success(self):
        with respx.mock:
            respx.post(f"{BASE}/items").mock(
                return_value=httpx.Response(201, json={"id": 42})
            )
            with APIClient(BASE) as client:
                result = client.post("/items", json={"name": "test"})
            assert result == {"id": 42}

    def test_patch_success(self):
        with respx.mock:
            respx.patch(f"{BASE}/items/1").mock(
                return_value=httpx.Response(200, json={"updated": True})
            )
            with APIClient(BASE) as client:
                result = client.patch("/items/1", json={"name": "new"})
            assert result["updated"] is True

    def test_delete_success(self):
        with respx.mock:
            respx.delete(f"{BASE}/items/1").mock(
                return_value=httpx.Response(204, text="")
            )
            with APIClient(BASE) as client:
                result = client.delete("/items/1")
            assert result == ""

    def test_error_raises_api_error(self):
        with respx.mock:
            respx.get(f"{BASE}/fail").mock(
                return_value=httpx.Response(404, json={"detail": "Not found"})
            )
            with APIClient(BASE) as client:
                with pytest.raises(APIError) as exc_info:
                    client.get("/fail")
            assert exc_info.value.status_code == 404
            assert "Not found" in exc_info.value.detail

    def test_error_without_json_body(self):
        with respx.mock:
            respx.get(f"{BASE}/err").mock(
                return_value=httpx.Response(500, text="Internal Server Error")
            )
            with APIClient(BASE) as client:
                with pytest.raises(APIError) as exc_info:
                    client.get("/err")
            assert exc_info.value.status_code == 500

    def test_auth_header_injected(self):
        with respx.mock:
            route = respx.get(f"{BASE}/me").mock(
                return_value=httpx.Response(200, json={"user": "me"})
            )
            with APIClient(BASE, api_key="sk-secret") as client:
                client.get("/me")
            request = route.calls[0].request
            assert request.headers["authorization"] == "Bearer sk-secret"

    def test_no_auth_header_when_empty(self):
        with respx.mock:
            route = respx.get(f"{BASE}/public").mock(
                return_value=httpx.Response(200, json={})
            )
            with APIClient(BASE) as client:
                client.get("/public")
            request = route.calls[0].request
            assert "authorization" not in request.headers

    def test_context_manager(self):
        client = APIClient(BASE)
        assert client._client is not None
        client.close()
        # Verify client is closed (subsequent calls would fail)
