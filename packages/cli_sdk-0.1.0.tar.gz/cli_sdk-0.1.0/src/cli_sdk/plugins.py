"""Simple plugin system for extending CLIs with additional command groups."""

from __future__ import annotations

import click

_plugin_registry: dict[str, click.BaseCommand] = {}


def register_plugin(name: str, group: click.BaseCommand) -> None:
    """Register a Click group or command as a named plugin.

    Args:
        name: Unique plugin name (used as the subcommand name).
        group: A Click Group or Command to attach.
    """
    if name in _plugin_registry:
        raise ValueError(f"Plugin '{name}' is already registered")
    _plugin_registry[name] = group


def load_plugins(cli: click.Group) -> None:
    """Attach all registered plugins to the given CLI group.

    Args:
        cli: The root Click group to extend.
    """
    for name, group in _plugin_registry.items():
        cli.add_command(group, name)


def get_registered_plugins() -> dict[str, click.BaseCommand]:
    """Return a copy of the current plugin registry."""
    return dict(_plugin_registry)


def clear_plugins() -> None:
    """Clear all registered plugins. Useful in tests."""
    _plugin_registry.clear()
