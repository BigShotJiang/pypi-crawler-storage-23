"""Configuration management for Willian CLI products."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

_DEFAULT_CONFIG_DIR = Path.home() / ".willian"

_config_instance: CLIConfig | None = None
_config_path: Path | None = None


class CLIConfig(BaseModel):
    """Configuration model for a CLI product."""

    api_url: str = "http://localhost:8000"
    api_key: str = ""
    output_format: Literal["table", "json", "text"] = "table"

    # Product-specific extra fields can be added by subclassing
    model_config = {"extra": "allow"}


def _resolve_path(path: str | Path | None, product: str | None = None) -> Path:
    """Resolve the config file path."""
    if path:
        return Path(path)
    product_name = product or "default"
    return _DEFAULT_CONFIG_DIR / product_name / "config.json"


def load_config(
    path: str | Path | None = None,
    product: str | None = None,
) -> CLIConfig:
    """Load configuration from a JSON file.

    Args:
        path: Explicit path to config file. If None, uses ~/.willian/<product>/config.json.
        product: Product name used to derive the default path.

    Returns:
        Loaded CLIConfig instance.
    """
    global _config_instance, _config_path
    resolved = _resolve_path(path, product)
    _config_path = resolved

    if resolved.exists():
        data = json.loads(resolved.read_text(encoding="utf-8"))
        _config_instance = CLIConfig.model_validate(data)
    else:
        _config_instance = CLIConfig()

    return _config_instance


def save_config(
    config: CLIConfig | None = None,
    path: str | Path | None = None,
    product: str | None = None,
) -> Path:
    """Write configuration to disk.

    Args:
        config: Config to save. Defaults to the current singleton.
        path: Explicit path. Falls back to the path used by load_config or the default.
        product: Product name for deriving the default path.

    Returns:
        The path the config was written to.
    """
    global _config_instance, _config_path
    cfg = config or _config_instance or CLIConfig()
    resolved = path or _config_path or _resolve_path(None, product)
    resolved = Path(resolved)

    resolved.parent.mkdir(parents=True, exist_ok=True)
    resolved.write_text(cfg.model_dump_json(indent=2) + "\n", encoding="utf-8")

    _config_instance = cfg
    _config_path = resolved
    return resolved


def get_config() -> CLIConfig:
    """Return the current config singleton, loading defaults if needed."""
    global _config_instance
    if _config_instance is None:
        _config_instance = CLIConfig()
    return _config_instance


def reset_config() -> None:
    """Reset the global config singleton. Useful in tests."""
    global _config_instance, _config_path
    _config_instance = None
    _config_path = None
