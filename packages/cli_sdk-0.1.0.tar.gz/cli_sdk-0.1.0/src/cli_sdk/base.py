"""Base CLI scaffolding: create_cli, BaseCommand, and common decorators."""

from __future__ import annotations

import functools
import sys
from typing import Any, Callable

import click

from cli_sdk.api_client import APIError
from cli_sdk.config import get_config, load_config
from cli_sdk.output import print_error, spinner as _spinner


def create_cli(
    name: str,
    version: str,
    *,
    product: str | None = None,
) -> click.Group:
    """Create a Click group pre-wired with common options.

    Args:
        name: CLI program name.
        version: Version string shown with --version.
        product: Product name used to derive config path (~/.willian/<product>/config.json).

    Returns:
        A Click group ready to register commands on.
    """

    @click.group(name=name)
    @click.version_option(version, prog_name=name)
    @click.option("--verbose", "-v", is_flag=True, help="Enable verbose output.")
    @click.option("--json-output", is_flag=True, help="Force JSON output format.")
    @click.option("--config", "config_path", default=None, help="Path to config file.")
    @click.pass_context
    def cli(ctx: click.Context, verbose: bool, json_output: bool, config_path: str | None) -> None:
        ctx.ensure_object(dict)
        ctx.obj["verbose"] = verbose
        ctx.obj["json_output"] = json_output

        cfg = load_config(path=config_path, product=product or name)
        if json_output:
            cfg.output_format = "json"
        ctx.obj["config"] = cfg

    return cli


class BaseCommand:
    """Wrapper around a Click command that adds error handling and output formatting.

    Usage:
        cmd = BaseCommand("greet", help="Say hello")

        @cmd.callback
        def greet(name: str):
            return {"message": f"Hello, {name}!"}

        cli.add_command(cmd.as_click_command())
    """

    def __init__(self, name: str, *, help: str = "") -> None:
        self.name = name
        self.help = help
        self._callback: Callable[..., Any] | None = None
        self._params: list[click.Parameter] = []

    def callback(self, fn: Callable[..., Any]) -> Callable[..., Any]:
        """Register the function as this command's callback."""
        self._callback = fn
        return fn

    def add_option(self, *args: Any, **kwargs: Any) -> BaseCommand:
        """Add a Click option to the command."""
        self._params.append(click.Option(args, **kwargs))
        return self

    def add_argument(self, *args: Any, **kwargs: Any) -> BaseCommand:
        """Add a Click argument to the command."""
        self._params.append(click.Argument(args, **kwargs))
        return self

    def as_click_command(self) -> click.Command:
        """Build and return the Click command object."""
        if self._callback is None:
            raise RuntimeError(f"No callback registered for command '{self.name}'")

        @functools.wraps(self._callback)
        def safe_invoke(**kwargs: Any) -> None:
            try:
                self._callback(**kwargs)  # type: ignore[misc]
            except APIError as exc:
                print_error(f"API error ({exc.status_code}): {exc.detail}")
                sys.exit(1)
            except click.Abort:
                raise
            except Exception as exc:
                print_error(str(exc))
                sys.exit(1)

        return click.Command(
            name=self.name,
            callback=safe_invoke,
            help=self.help,
            params=list(self._params),
        )


# ---------------------------------------------------------------------------
# Common decorators
# ---------------------------------------------------------------------------


def requires_auth(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Decorator that ensures an API key is configured before running."""

    @functools.wraps(fn)
    @click.pass_context
    def wrapper(ctx: click.Context, *args: Any, **kwargs: Any) -> Any:
        cfg = ctx.obj.get("config") or get_config()
        if not cfg.api_key:
            print_error("Not authenticated. Run 'init' or set api_key in config.")
            ctx.exit(1)
            return None
        return ctx.invoke(fn, *args, **kwargs)

    return wrapper


def with_spinner(message: str = "Working...") -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that wraps the command execution in a Rich spinner.

    Args:
        message: Text shown alongside the spinner.
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            with _spinner(message):
                return fn(*args, **kwargs)

        return wrapper

    return decorator
