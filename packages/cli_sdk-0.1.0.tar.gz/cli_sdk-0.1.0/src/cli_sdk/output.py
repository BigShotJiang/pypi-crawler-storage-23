"""Output formatting utilities using Rich."""

from __future__ import annotations

import json as json_mod
from contextlib import contextmanager
from typing import Any, Generator, Sequence

from rich.console import Console
from rich.json import JSON
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree
from rich.status import Status

console = Console()
err_console = Console(stderr=True)


def print_table(
    headers: Sequence[str],
    rows: Sequence[Sequence[Any]],
    *,
    title: str | None = None,
) -> None:
    """Render a Rich table to the terminal.

    Args:
        headers: Column header names.
        rows: List of row tuples/lists.
        title: Optional table title.
    """
    table = Table(title=title, show_header=True, header_style="bold cyan")
    for header in headers:
        table.add_column(str(header))
    for row in rows:
        table.add_row(*(str(cell) for cell in row))
    console.print(table)


def print_json(data: Any) -> None:
    """Pretty-print data as formatted JSON.

    Args:
        data: Any JSON-serializable object.
    """
    if isinstance(data, str):
        text = data
    else:
        text = json_mod.dumps(data, indent=2, default=str)
    console.print(JSON(text))


def print_success(msg: str) -> None:
    """Print a success message in green."""
    console.print(f"[bold green]SUCCESS[/bold green] {msg}")


def print_error(msg: str) -> None:
    """Print an error message in red to stderr."""
    err_console.print(f"[bold red]ERROR[/bold red] {msg}")


def print_warning(msg: str) -> None:
    """Print a warning message in yellow."""
    console.print(f"[bold yellow]WARNING[/bold yellow] {msg}")


def print_tree(data: dict[str, Any], *, label: str = "root") -> None:
    """Render hierarchical data as a Rich tree.

    Args:
        data: Nested dict to display.
        label: Root node label.
    """

    def _add_nodes(tree: Tree, obj: Any) -> None:
        if isinstance(obj, dict):
            for key, value in obj.items():
                if isinstance(value, (dict, list)):
                    branch = tree.add(f"[bold]{key}[/bold]")
                    _add_nodes(branch, value)
                else:
                    tree.add(f"[bold]{key}:[/bold] {value}")
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                if isinstance(item, (dict, list)):
                    branch = tree.add(f"[dim][{i}][/dim]")
                    _add_nodes(branch, item)
                else:
                    tree.add(str(item))
        else:
            tree.add(str(obj))

    root = Tree(f"[bold cyan]{label}[/bold cyan]")
    _add_nodes(root, data)
    console.print(root)


@contextmanager
def spinner(msg: str = "Working...") -> Generator[Status, None, None]:
    """Context manager that shows a Rich spinner.

    Usage:
        with spinner("Loading data..."):
            do_work()
    """
    with console.status(msg, spinner="dots") as status:
        yield status
