"""Willian CLI SDK -- Shared library for building product CLIs."""

from cli_sdk.base import BaseCommand, create_cli, requires_auth, with_spinner
from cli_sdk.config import CLIConfig, get_config, load_config, save_config
from cli_sdk.output import (
    print_error,
    print_json,
    print_success,
    print_table,
    print_tree,
    print_warning,
    spinner,
)
from cli_sdk.api_client import APIClient
from cli_sdk.plugins import load_plugins, register_plugin

__all__ = [
    "APIClient",
    "BaseCommand",
    "CLIConfig",
    "create_cli",
    "get_config",
    "load_config",
    "load_plugins",
    "print_error",
    "print_json",
    "print_success",
    "print_table",
    "print_tree",
    "print_warning",
    "register_plugin",
    "requires_auth",
    "save_config",
    "spinner",
    "with_spinner",
]
