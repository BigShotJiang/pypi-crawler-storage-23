"""HTTP API client with automatic auth and error handling."""

from __future__ import annotations

from typing import Any

import httpx


class APIError(Exception):
    """Raised when an API request fails."""

    def __init__(self, status_code: int, detail: str, url: str) -> None:
        self.status_code = status_code
        self.detail = detail
        self.url = url
        super().__init__(f"HTTP {status_code} from {url}: {detail}")


class APIClient:
    """Thin wrapper around httpx for calling product APIs.

    Args:
        base_url: Root URL of the API (e.g. ``https://api.example.com``).
        api_key: Bearer token for authentication.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str = "",
        *,
        timeout: float = 30.0,
    ) -> None:
        headers: dict[str, str] = {"Accept": "application/json"}
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        self._client = httpx.Client(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
        )

    # -- Public methods -------------------------------------------------------

    def get(self, path: str, *, params: dict[str, Any] | None = None) -> Any:
        """Send a GET request and return parsed JSON."""
        resp = self._client.get(path, params=params)
        return self._handle(resp)

    def post(self, path: str, *, json: Any = None) -> Any:
        """Send a POST request and return parsed JSON."""
        resp = self._client.post(path, json=json)
        return self._handle(resp)

    def patch(self, path: str, *, json: Any = None) -> Any:
        """Send a PATCH request and return parsed JSON."""
        resp = self._client.patch(path, json=json)
        return self._handle(resp)

    def delete(self, path: str) -> Any:
        """Send a DELETE request and return parsed JSON."""
        resp = self._client.delete(path)
        return self._handle(resp)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    # -- Context manager ------------------------------------------------------

    def __enter__(self) -> APIClient:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # -- Internal -------------------------------------------------------------

    @staticmethod
    def _handle(resp: httpx.Response) -> Any:
        """Parse the response, raising APIError on non-2xx status codes."""
        if resp.is_success:
            if resp.headers.get("content-type", "").startswith("application/json"):
                return resp.json()
            return resp.text
        # Build a useful error message
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        raise APIError(
            status_code=resp.status_code,
            detail=str(detail),
            url=str(resp.url),
        )
