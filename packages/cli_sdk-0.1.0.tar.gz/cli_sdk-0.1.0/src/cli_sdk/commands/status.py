"""Status command: check API health and display current configuration."""

from __future__ import annotations

import click

from cli_sdk.config import get_config
from cli_sdk.output import print_error, print_json, print_success, print_table, print_warning


@click.command("status")
@click.pass_context
def status_command(ctx: click.Context) -> None:
    """Check API health and display current configuration."""
    cfg = ctx.obj.get("config") or get_config()

    # Display config summary
    auth_status = "Configured" if cfg.api_key else "Not configured"
    rows = [
        ("API URL", cfg.api_url),
        ("Authentication", auth_status),
        ("Output Format", cfg.output_format),
    ]

    if ctx.obj.get("json_output"):
        print_json({"api_url": cfg.api_url, "auth": auth_status, "health": _check_health(cfg)})
        return

    print_table(["Setting", "Value"], rows, title="CLI Status")

    # Health check
    health = _check_health(cfg)
    if health == "ok":
        print_success("API is reachable")
    elif health == "unreachable":
        print_error(f"Cannot reach API at {cfg.api_url}")
    else:
        print_warning(f"API returned unexpected status: {health}")


def _check_health(cfg: object) -> str:
    """Attempt a simple GET to the API health endpoint."""
    import httpx

    api_url = getattr(cfg, "api_url", "http://localhost:8000")
    try:
        resp = httpx.get(f"{api_url}/health", timeout=5.0)
        if resp.is_success:
            return "ok"
        return f"HTTP {resp.status_code}"
    except httpx.ConnectError:
        return "unreachable"
    except Exception as exc:
        return str(exc)
