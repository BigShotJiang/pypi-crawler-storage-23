"""Config get/set/list commands."""

from __future__ import annotations

import click

from cli_sdk.config import get_config, save_config
from cli_sdk.output import print_error, print_json, print_success, print_table


@click.group("config")
def config_group() -> None:
    """View and modify CLI configuration."""


@config_group.command("list")
@click.pass_context
def config_list(ctx: click.Context) -> None:
    """List all configuration values."""
    cfg = ctx.obj.get("config") or get_config()
    data = cfg.model_dump()

    if ctx.obj.get("json_output"):
        print_json(data)
        return

    rows = [(k, _mask_if_secret(k, v)) for k, v in data.items()]
    print_table(["Key", "Value"], rows, title="Configuration")


@config_group.command("get")
@click.argument("key")
@click.pass_context
def config_get(ctx: click.Context, key: str) -> None:
    """Get a single configuration value."""
    cfg = ctx.obj.get("config") or get_config()
    data = cfg.model_dump()

    if key not in data:
        print_error(f"Unknown config key: {key}")
        ctx.exit(1)
        return

    value = data[key]
    if ctx.obj.get("json_output"):
        print_json({key: value})
    else:
        click.echo(f"{key}={_mask_if_secret(key, value)}")


@config_group.command("set")
@click.argument("key")
@click.argument("value")
@click.pass_context
def config_set(ctx: click.Context, key: str, value: str) -> None:
    """Set a configuration value."""
    cfg = ctx.obj.get("config") or get_config()
    data = cfg.model_dump()

    if key not in data:
        print_error(f"Unknown config key: {key}")
        ctx.exit(1)
        return

    data[key] = value
    from cli_sdk.config import CLIConfig

    updated = CLIConfig.model_validate(data)
    save_config(updated)
    print_success(f"Set {key}={_mask_if_secret(key, value)}")


def _mask_if_secret(key: str, value: object) -> str:
    """Mask sensitive values like API keys in display output."""
    secret_keys = {"api_key", "secret", "token", "password"}
    str_val = str(value)
    if key in secret_keys and str_val:
        visible = min(4, len(str_val))
        return str_val[:visible] + "*" * max(0, len(str_val) - visible)
    return str_val
