"""Interactive setup wizard for first-time CLI configuration."""

from __future__ import annotations

import click

from cli_sdk.config import CLIConfig, save_config
from cli_sdk.output import print_success


@click.command("init")
@click.option(
    "--api-url",
    prompt="API URL",
    default="http://localhost:8000",
    help="Base URL of the product API.",
)
@click.option(
    "--api-key",
    prompt="API Key",
    hide_input=True,
    default="",
    help="Bearer token for authentication.",
)
@click.option(
    "--output-format",
    prompt="Default output format",
    type=click.Choice(["table", "json", "text"], case_sensitive=False),
    default="table",
    help="Default output format.",
)
@click.pass_context
def init_command(
    ctx: click.Context,
    api_url: str,
    api_key: str,
    output_format: str,
) -> None:
    """Interactive setup wizard -- configure the CLI for first use."""
    config = CLIConfig(
        api_url=api_url,
        api_key=api_key,
        output_format=output_format,  # type: ignore[arg-type]
    )
    path = save_config(config)
    print_success(f"Configuration saved to {path}")
