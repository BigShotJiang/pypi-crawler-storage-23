from dataclasses import dataclass


@dataclass
class Exchange:
    """证券交易所数据类"""
    name: str  # 交易所名称
    abbr: str  # 交易所简称
    code: str  # 交易所代码


__all__ = ["Exchange"]
