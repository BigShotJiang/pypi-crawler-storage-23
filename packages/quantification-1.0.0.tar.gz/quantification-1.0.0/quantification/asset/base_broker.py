from abc import ABC, abstractmethod
from typing import TYPE_CHECKING
from datetime import date, time

from ..env import EnvGetter

if TYPE_CHECKING:
    from .base_asset import BaseAsset, Cash
    from ..data import BaseAPI
    from ..trader import BaseOrder, Result, Portfolio, BaseFilm


class BaseBroker[AssetType:"BaseAsset", CashType:"Cash"](ABC, EnvGetter):
    """
    撮合交易实现Asset与Cash之间的转化
    """

    def __init__(self):
        self.api = None
        self.start_date = None
        self.end_date = None
        self.film = None

    def init(self, api: "BaseAPI", start_date: date, end_date: date, film: "BaseFilm"):
        self.api = api
        self.start_date = start_date
        self.end_date = end_date
        self.film = film

    @abstractmethod
    def matchable(self, asset: type[AssetType]) -> bool:
        raise NotImplementedError

    @abstractmethod
    def execute_order(self, order: "BaseOrder[AssetType]", portfolio: "Portfolio") -> "Result|None":
        raise NotImplementedError

    @abstractmethod
    def liquidate_asset(self, asset: AssetType, day: date, moment: time) -> CashType:
        raise NotImplementedError

    def __repr__(self):
        return f"<{self.__class__.__name__}>"

    __str__ = __repr__


__all__ = ['BaseBroker']
