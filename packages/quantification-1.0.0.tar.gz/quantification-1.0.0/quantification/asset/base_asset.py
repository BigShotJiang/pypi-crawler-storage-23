from abc import ABCMeta, abstractmethod, ABC
from datetime import date, time

from .exchange import Exchange


class BaseAssetMeta(ABCMeta):
    def __repr__(self: "BaseAsset") -> str:
        return self.class_name()

    __str__ = __repr__


class BaseAsset(ABC, metaclass=BaseAssetMeta):
    is_closeable = True  # 若为True, 当empty时将从Portfolio中移除该资产

    @classmethod
    @abstractmethod
    def type(cls, *args, **kwargs) -> str:
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def class_name(cls, *args, **kwargs) -> str:
        raise NotImplementedError

    @abstractmethod
    def name(self, *args, **kwargs) -> str:
        raise NotImplementedError

    @property
    @abstractmethod
    def amount(self) -> float:
        raise NotImplementedError

    @property
    @abstractmethod
    def extra(self) -> dict:
        raise NotImplementedError

    @property
    def is_empty(self) -> bool:
        return self.amount == 0

    @abstractmethod
    def available(self, *args, **kwargs) -> "BaseAsset":
        raise NotImplementedError

    @property
    @abstractmethod
    def copy(self) -> "BaseAsset":
        raise NotImplementedError

    @abstractmethod
    def __add__(self, other: "BaseAsset") -> "BaseAsset":
        raise NotImplementedError

    @abstractmethod
    def __sub__(self, other: "BaseAsset") -> "BaseAsset":
        raise NotImplementedError

    @abstractmethod
    def __eq__(self, other: "BaseAsset") -> bool:
        raise NotImplementedError

    def __repr__(self) -> str:
        return self.name()

    __str__ = __repr__


class Cash(BaseAsset, ABC):
    symbol: str = None
    is_closeable = False  # 始终不从Portfolio移除

    @classmethod
    def type(cls) -> str:
        return "Cash"

    def name(self) -> str:
        return f"{self.class_name()}({self.amount}元)"

    @abstractmethod
    def liquidate(self, day: date, moment: time) -> float:
        """清算为人民币时的价值"""
        raise NotImplementedError


class Stock(BaseAsset, ABC):
    symbol: str = None
    exchange: Exchange = None

    @classmethod
    def type(cls) -> str:
        return "Stock"

    @classmethod
    def code(cls) -> str:
        return f"{cls.symbol}.{cls.exchange.code}"

    def name(self) -> str:
        return f"{self.class_name()}({self.amount}股)"

    @abstractmethod
    def __class_getitem__(cls, item):
        raise NotImplementedError


class ETF(BaseAsset, ABC):
    symbol: str = None
    exchange: Exchange = None

    @classmethod
    def type(cls) -> str:
        return "ETF"

    @classmethod
    def code(cls) -> str:
        return f"{cls.symbol}.{cls.exchange.code}"

    def name(self) -> str:
        return f"{self.class_name()}({self.amount}股)"

    @abstractmethod
    def __class_getitem__(cls, item):
        raise NotImplementedError


__all__ = ["BaseAsset", "Cash", "Stock", "ETF"]
