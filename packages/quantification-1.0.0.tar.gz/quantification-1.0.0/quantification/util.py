import types
import inspect
import functools
from typing import Callable, Any, Mapping

from pydantic import ValidationError, create_model, ConfigDict
from pydantic_core import PydanticUndefined


def to_str(x: Callable[..., Any]) -> str:
    """将可调用对象转换为描述性的字符串表示形式。

    Args:
        x: 任何可调用对象（函数、lambda、partial、类、方法等）

    Returns:
        可调用对象的字符串表示。

    Examples:
        >>> to_str(lambda num: num + 1)
        '<lambda>'
        >>> to_str(functools.partial(sorted, reverse=True))
        'functools.partial(builtins.sorted, reverse=True)'
    """
    # 1. 处理functools.partial对象
    if isinstance(x, functools.partial):
        func_str = to_str(x.func)
        args = [repr(a) for a in x.args]
        keywords = [f"{k}={repr(v)}" for k, v in x.keywords.items()]
        all_args = ", ".join(args + keywords)
        return f"functools.partial({func_str}, {all_args})"

    # 2. 处理类（因为类也是可调用的）
    if inspect.isclass(x):
        return f"{x.__module__}.{x.__qualname__}"

    # 3. 处理绑定方法（实例方法和类方法）
    if isinstance(x, (types.MethodType, types.BuiltinMethodType)):
        method_name = x.__name__
        owner = x.__self__

        if inspect.isclass(owner):
            owner_str = owner.__qualname__
            return f"<bound method {owner_str}.{method_name}>"

        class_name = owner.__class__.__qualname__
        return f"<bound method {class_name}.{method_name} of {repr(owner)}>"

    # 4. 处理函数和内置函数
    if isinstance(x, (types.FunctionType, types.BuiltinFunctionType)):
        module = x.__module__
        qualname = x.__qualname__

        # 特殊处理lambda函数
        if qualname == '<lambda>':
            try:
                source = inspect.getsource(x).strip()
                if '\n' in source:
                    return f"<lambda at {module}:{x.__code__.co_firstlineno}>"
                return source
            except (OSError, TypeError):
                return "<lambda>"

        return f"{module}.{qualname}"

    # 回退方案：使用标准字符串表示
    return str(x)


def get_function_location(func) -> str:
    """获取函数的定义位置（文件路径和行号）

    Args:
        func: 要检查的函数对象

    Returns:
        函数定义位置的字符串描述

    Examples:
        >>> get_function_location(lambda x: x)
        'lambda at <unknown location>'
        >>> get_function_location(sorted)
        '<unknown location>'
    """
    try:
        # 尝试获取函数的源文件和行号
        source_file = inspect.getsourcefile(func)
        lines, start_line = inspect.getsourcelines(func)
        end_line = start_line + len(lines) - 1

        # 如果是lambda函数，使用特殊格式
        if func.__name__ == '<lambda>':
            return f"lambda at {source_file}:{start_line}"

        return f"{source_file}:{start_line}-{end_line}"
    except Exception:  # noqa
        # 如果无法获取位置信息，返回默认值
        return "<unknown location>"


def format_arg_type(value) -> str:
    """格式化参数类型信息，特别处理类对象

    Args:
        value: 要格式化类型的值

    Returns:
        类型信息的字符串表示

    Examples:
        >>> format_arg_type(str)
        "<class 'builtins.str'>"
        >>> format_arg_type(123)
        "<class 'int'>"
    """
    if inspect.isclass(value):
        # 对于类对象，显示类名而不是元类
        return f"<class '{value.__module__}.{value.__qualname__}'>"
    return str(type(value))


def format_annotations(params: Mapping[str, inspect.Parameter]) -> str:
    """格式化参数注解信息

    Args:
        params: inspect.Parameter对象的字典

    Returns:
        格式化后的参数注解字符串
    """
    lines = []
    for name, param in params.items():
        # 跳过可变关键字参数
        if param.kind == inspect.Parameter.VAR_KEYWORD:
            continue

        # 获取类型注解
        ann = param.annotation
        ann_str = ann.__name__ if ann is not param.empty else "Any"

        # 添加默认值信息
        default = ""
        if param.default is not param.empty:
            default = f" (默认值: {repr(param.default)})"

        # 添加参数类型标记
        kind = ""
        if param.kind == inspect.Parameter.KEYWORD_ONLY:
            kind = " [keyword-only]"
        elif param.kind == inspect.Parameter.POSITIONAL_ONLY:
            kind = " [positional-only]"

        lines.append(f"  - {name}: {ann_str}{default}{kind}")
    return "\n".join(lines)


def inject(func, **kwargs) -> Any:
    """依赖注入装饰器/函数

    使用Pydantic验证和转换输入参数，使其符合目标函数的签名要求。
    自动处理类型转换和参数验证，提供详细的错误信息。

    Args:
        func: 要注入参数的函数或可调用对象
        **kwargs: 要注入的参数键值对

    Returns:
        函数调用结果

    Raises:
        TypeError: 当参数类型不匹配且无法转换时抛出

    Examples:
        >>> def example(girl: str, age: int = 18):
        ...     return f"{girl} is {age} years old"
        >>> inject(example, name="Alice", age="25")  # 字符串"25"会自动转换为整数25
        'Alice is 25 years old'

        >>> inject(example, name="Bob", age="invalid")
        # 抛出TypeError，显示详细的类型错误信息
    """
    # 获取函数签名
    sig = inspect.signature(func)
    params = sig.parameters

    # 构建Pydantic模型的字段定义
    model_fields = {}
    for name, param in params.items():
        # 跳过可变关键字参数（**kwargs）
        if param.kind == inspect.Parameter.VAR_KEYWORD:
            continue

        # 处理类型注解
        annotation = param.annotation
        if annotation is param.empty:
            annotation = Any

        # 处理默认值
        default = PydanticUndefined
        if param.default is not param.empty:
            default = param.default

        model_fields[name] = (annotation, default)

    # 获取函数名称用于模型命名
    func_name = to_str(func)

    # 创建Pydantic验证模型
    model = create_model(
        f"{func_name}_Params",
        __config__=ConfigDict(
            extra="allow",  # 允许额外参数
            arbitrary_types_allowed=True,  # 允许任意类型
            coerce_numbers_to_str=True  # 强制数字到字符串的转换
        ),
        **model_fields
    )

    try:
        # 验证和转换输入参数
        validated = model(**kwargs)
    except ValidationError as e:
        # 处理验证错误，生成友好的错误信息
        errors = []
        for error in e.errors():
            loc = ".".join(map(str, error["loc"]))
            expected_type = " | ".join(error.get("ctx", {}).get("expected", ["未知类型"]))
            actual_type = type(kwargs.get(loc, "<missing>")).__name__
            msg = f"无法将类型 {actual_type} 转换为函数定义的类型 {expected_type}"
            input_value = error.get("input", "<missing>")

            errors.append(f"  - {loc}: {msg} (输入值: {input_value})")

        # 格式化可用参数信息
        arg_types = "\n".join([
            f"  - {k}: {format_arg_type(v)}"
            for k, v in kwargs.items()
        ])

        # 抛出详细的类型错误
        raise TypeError(
            f"🚫 参数类型与可用参数不兼容，且强制转换失败，请检查 {func_name} 的定义:\n"
            f"📋 定义的参数:\n{format_annotations(params)}\n"
            f"📤 可用的全部参数(正确标准):\n{arg_types}\n"
            f"❌ 参数类型不匹配且转换失败:\n{"\n".join(errors)}\n"
            f"📍 函数定义位置: {get_function_location(func)}\n"
        )

    # 提取验证后的数据
    validated_data = validated.model_dump()

    # 处理可变关键字参数的情况
    if any((name for name, param in params.items() if param.kind == inspect.Parameter.VAR_KEYWORD)):
        return func(**validated_data)

    # 正常调用函数
    return func(**{p.name: validated_data[p.name] for p in params.values()})


__all__ = ["inject"]
