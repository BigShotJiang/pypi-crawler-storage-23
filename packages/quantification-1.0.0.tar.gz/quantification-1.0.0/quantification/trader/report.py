import hashlib
from typing import TYPE_CHECKING
from pathlib import Path
from datetime import datetime

import pandas as pd
from pydantic import BaseModel, Field
from quantstats import reports

from ..logger import Record
from ..configure import config

if TYPE_CHECKING:
    from .base_order import Result
    from ..asset import BaseAsset


class SaveModel(BaseModel):
    def save(self, output_dir: Path):
        if not output_dir.exists():
            output_dir.mkdir(parents=True, exist_ok=True)

        md5 = hashlib.md5()
        md5.update(self.title.encode('utf-8'))

        with open(output_dir / f"{md5.hexdigest()}.json", "w", encoding="utf-8") as f:
            f.write(self.model_dump_json(indent=4, ensure_ascii=False))


class AssetData(BaseModel):
    type: str
    name: str
    amount: float
    extra: dict

    @classmethod
    def from_asset(cls, asset: "BaseAsset", **kwargs) -> "AssetData":
        return cls(
            type=asset.type(),
            name=asset.__class__.class_name(),
            amount=asset.amount,
            extra={**asset.extra, **kwargs}
        )


class OrderResultData(BaseModel):
    order_type: str
    order_category: str
    order_asset: str
    order_extra: dict
    result_brought: list[AssetData]
    result_sold: list[AssetData]

    @classmethod
    def from_result(cls, result: "Result", **kwargs) -> "OrderResultData":
        return cls(
            order_type=result.order.type(),
            order_asset=str(result.order.asset),
            order_category=result.order.category,
            order_extra={**result.order.extra, **kwargs},
            result_brought=[AssetData.from_asset(i) for i in result.brought],
            result_sold=[AssetData.from_asset(i) for i in result.sold],
        )


class PeriodData(BaseModel):
    datetime: str
    liquidating_value: float

    logs: list[Record]
    portfolios: list[AssetData]
    transactions: list[OrderResultData]


class PointData(BaseModel):
    datetime: str
    value: float


class BenchmarkData(BaseModel):
    name: str
    init_value: float
    points: list[PointData]


class BaseStrategyReport(SaveModel):
    tag: str
    title: str
    description: str
    base: float
    scale: float
    start_date: str
    end_date: str
    benchmark: BenchmarkData

    def save(self, output_dir: Path = None) -> None:
        if output_dir is None:
            output_dir = Path(config.output_dir).absolute() / "back" / "report"

        super().save(output_dir)


class SingleStrategyReportV1(BaseStrategyReport):
    tag: str = Field(default="SingleStrategyReportV1")
    strategy: list[PeriodData]

    def stats(self, rf=0.02, output_html=None):
        strategy = pd.Series()
        benchmark = pd.Series()

        for i in self.strategy:
            strategy[pd.Timestamp(datetime.fromisoformat(i.datetime).date())] = i.liquidating_value

        for i in self.benchmark.points:
            benchmark[pd.Timestamp(datetime.fromisoformat(i.datetime).date())] = i.value

        strategy = strategy.pct_change().dropna()
        benchmark = benchmark.pct_change().dropna()

        if not output_html:
            reports.full(strategy, benchmark, rf=rf)
        else:
            reports.html(strategy, benchmark, rf=rf, output=output_html)

        return strategy, benchmark


class MultiStrategyReportV1(BaseStrategyReport):
    tag: str = Field(default="MultiStrategyReportV1")
    strategy: dict[str, list[PeriodData]]

    def stats(self, name, rf=0.02, output_html=None):
        strategy = pd.Series()
        benchmark = pd.Series()

        for i in self.strategy[name]:
            strategy[pd.Timestamp(datetime.fromisoformat(i.datetime).date())] = i.liquidating_value

        for i in self.benchmark.points:
            benchmark[pd.Timestamp(datetime.fromisoformat(i.datetime).date())] = i.value

        strategy = strategy.pct_change().dropna()
        benchmark = benchmark.pct_change().dropna()

        if not output_html:
            reports.full(strategy, benchmark, rf=rf, strategy_title=name)
        else:
            reports.html(strategy, benchmark, rf=rf, strategy_title=name, output=output_html)

        return strategy, benchmark
