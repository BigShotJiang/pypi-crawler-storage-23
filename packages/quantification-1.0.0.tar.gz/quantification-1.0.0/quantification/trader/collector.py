from datetime import date, time

from .portfolio import Portfolio
from .base_order import Result


class Shard:
    def __init__(
            self,
            day: date,
            moment: time,
            portfolio: Portfolio,
            results: list[Result],
            liquidating_values: list[float],
    ):
        self.day = day
        self.moment = moment
        self.portfolio = portfolio
        self.results: list[Result] = results
        self.liquidating_values = liquidating_values

    def __repr__(self) -> str:
        return (
            f"================{self.day} {self.moment}================\n"
            f"Portfolio: {self.portfolio}\n"
            f"Results: {self.results}\n"
        )

    __str__ = __repr__


__all__ = ["Shard"]
