import re
from typing import Iterator
from datetime import time


class BaseFilm:
    """
    基础时间序列类

    用于定义和管理交易时间序列，确保时间点严格递增。
    通过类属性定义多个时间段，自动合并并按时间顺序迭代。

    Examples:
        >>> class MyTradingFilm(BaseFilm):
        ...     morning = Period["9:30":"11:30":15]  # 上午交易时段，每15分钟
        ...     afternoon = Period["13:00":"15:00":30]  # 下午交易时段，每30分钟
        ...
        >>> film = MyTradingFilm()
        >>> for t in film:
        ...     print(t)
        09:30:00
        09:45:00
        10:00:00
        ...
    """

    def __iter__(self) -> Iterator[time]:
        """
        迭代器方法，按时间顺序生成所有时间点

        Returns:
            Iterator[time]: 严格递增的时间点迭代器

        Raises:
            ValueError: 如果时间序列不是严格递增的

        Note:
            该方法会自动收集所有Period实例的时间点，并按时间排序
        """
        previous_time = None

        # 遍历类的所有属性，找到Period实例
        for v in vars(self.__class__).values():
            if not isinstance(v, Period):
                continue

            # 遍历当前Period的所有时间点
            for current_time in v:
                # 检查时间是否递增
                if previous_time is not None and current_time <= previous_time:
                    raise ValueError(f"时间序列不是严格递增的: {previous_time} -> {current_time}")
                previous_time = current_time
                yield current_time

    def __repr__(self) -> str:
        """
        返回对象的字符串表示

        Returns:
            str: 包含类名和所有Period描述的字符串
        """
        return f"{self.__class__.__name__}({[v for v in vars(self.__class__).values() if isinstance(v, Period)]})"


class Period:
    """
    时间段类

    用于定义连续的时间点序列，支持单时间点和时间范围两种创建方式。
    可以通过字符串或slice语法灵活定义时间序列。

    Attributes:
        time_points (list[time]): 时间点列表
        description (str): 时间段的描述信息
    """

    def __class_getitem__(cls, ts: str | slice) -> "Period":
        """
        类方法，通过索引语法创建Period实例

        Args:
            ts: 时间定义，可以是字符串（单时间点）或slice（时间范围）
                - 字符串格式: "HH:MM" 如 "9:30"
                - slice格式: "start:stop:step" 如 "9:30:11:30:15"

        Returns:
            Period: 新创建的Period实例

        Raises:
            ValueError: 时间格式无效时抛出
            AssertionError: 开始时间不小于结束时间或步长不合法时抛出

        Examples:
            >>> Period["9:30"]  # 单个时间点
            >>> Period["9:30":"11:30"]  # 时间范围，默认步长1分钟
            >>> Period["9:30":"11:30":15]  # 时间范围，15分钟步长
        """
        if isinstance(ts, str):
            # 处理单时间点情况
            t = cls.to_time(ts)
            return cls([t], f"时间点{t}")
        else:
            # 处理时间范围情况
            start_t = cls.to_time(ts.start)
            end_t = cls.to_time(ts.stop)
            step = ts.step or 1  # 默认步长为1分钟

            # 参数验证
            assert start_t < end_t, f"结束时间必须大于开始时间: {start_t} >= {end_t}"
            assert isinstance(step, int) and step >= 1, f"步长必须为大于0的整数: {step}"

            # 生成时间点序列
            time_points = []
            current_time = start_t
            while current_time < end_t:
                time_points.append(current_time)
                # 计算下一个时间点（分钟累加）
                total_minutes = current_time.hour * 60 + current_time.minute + step
                current_time = time(hour=total_minutes // 60, minute=total_minutes % 60)

            return cls(time_points, f"开始{start_t} 结束{end_t} 步长{step}分钟")

    def __init__(self, time_points: list[time], description: str):
        """
        初始化时间段

        Args:
            time_points: 时间点列表
            description: 时间段的描述信息
        """
        self.time_points = time_points
        self.description = description

    @staticmethod
    def to_time(time_str: str) -> time:
        """
        将字符串转换为time对象

        Args:
            time_str: 时间字符串，格式为 "HH:MM"

        Returns:
            time: 对应的time对象

        Raises:
            ValueError: 当时间字符串格式无效时抛出

        Examples:
            >>> Period.to_time("9:30")
            datetime.time(9, 30)
        """
        match = re.match(r'(\d+):(\d+)', time_str)
        if not match:
            raise ValueError(f"无效的时间格式: {time_str}")

        hour = int(match.group(1))
        minute = int(match.group(2))

        return time(hour, minute)

    def __iter__(self) -> Iterator[time]:
        """
        迭代时间点

        Returns:
            Iterator[time]: 时间点迭代器
        """
        yield from self.time_points

    def __contains__(self, item: time) -> bool:
        """
        检查时间点是否在时间段内

        Args:
            item: 要检查的时间点

        Returns:
            bool: 如果时间点在时间段内返回True，否则返回False
        """
        return item in self.time_points

    def __repr__(self) -> str:
        """
        返回对象的字符串表示

        Returns:
            str: 包含类名和描述的字符串
        """
        return f"{self.__class__.__name__}({self.description})"

    __str__ = __repr__


__all__ = ["BaseFilm", "Period"]
