from abc import ABC, abstractmethod
from typing import TYPE_CHECKING
from inspect import isclass

if TYPE_CHECKING:
    from ..asset import BaseAsset


class BaseOrder[AssetType:"BaseAsset"](ABC):
    asset: type[AssetType]

    def __init__(self, asset: type[AssetType] | AssetType | str, category: str):
        if isclass(asset):
            assert issubclass(asset, self.asset), f"{asset.__name__}不是{self.asset.__name__}的子类"
        elif isinstance(asset, self.asset):
            asset = asset.__class__
        elif isinstance(asset, str):
            asset = self.asset[asset]
        else:
            raise ValueError(f"asset参数只能为{self.asset.__name__}的子类、子类实例、对应code，实际为{asset}")

        self.asset: type[AssetType] = asset
        self.category = category

    def type(self) -> str:
        return self.__class__.__name__

    @property
    @abstractmethod
    def extra(self) -> dict:
        raise NotImplementedError

    @abstractmethod
    def __repr__(self) -> str:
        raise NotImplementedError

    __str__ = __repr__


class Result[OrderType:BaseOrder]:
    def __init__(self, *, order: OrderType, sold: list["BaseAsset"], brought: list["BaseAsset"]):
        self.order = order
        self.sold = sold
        self.brought = brought

    def __repr__(self) -> str:
        return f"<Result sold={self.sold} brought={self.brought}>"

    __str__ = __repr__


__all__ = ['BaseOrder', 'Result']
