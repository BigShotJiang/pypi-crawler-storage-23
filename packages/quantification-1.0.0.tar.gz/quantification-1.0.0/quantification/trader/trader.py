from tqdm import tqdm
from typing import TYPE_CHECKING, Callable
from datetime import date, time, timedelta, datetime

from dataclasses import dataclass

from .query import Query
from .report import (
    AssetData,
    PointData,
    PeriodData,
    BenchmarkData,
    OrderResultData,
    SingleStrategyReportV1,
    MultiStrategyReportV1
)
from .portfolio import Portfolio
from .collector import Shard
from .base_film import BaseFilm
from .base_order import Result, BaseOrder
from ..asset.base_asset import Cash

from ..env import EnvGetter, Env
from ..util import inject
from ..logger import logger

if TYPE_CHECKING:
    from ..data import BaseAPI
    from ..asset import BaseBroker, BaseAsset
    from ..strategy import Strategy


@dataclass
class Rollup:
    strategy: "Strategy"
    portfolio: Portfolio
    shards: list[Shard]


@dataclass
class Param:
    func: Callable
    lazy: bool


class BaseTrader:
    def __init__(
            self,
            api: "BaseAPI",
            base: float,
            scale: float,
            start_date: date,
            end_date: date,
            padding: int,
            film: type[BaseFilm],
            brokers: list["BaseBroker"],
            **kwargs
    ):
        logger.clear()

        self.api = api
        self.base = base
        self.scale = scale
        self.start_date = start_date
        self.end_date = end_date
        self.film = film()  # 实例化时间序列管理器
        # 创建数据查询器，扩展查询范围以处理边界情况
        self.query = Query(api, start_date - timedelta(days=padding), end_date)
        # 初始化环境变量，设置为开始日期和第一个时间点
        self.env: Env = Env(date=self.start_date, time=next(iter(self.film)))
        # 初始化所有broker实例
        self.brokers = brokers

        for broker in brokers:
            broker.init(api, start_date - timedelta(days=30), end_date + timedelta(days=30), self.film)

        # 设置环境变量获取器
        EnvGetter.getter = lambda: self.env

        # 初始化注册参数字典
        self.registered_params: dict[str, Param] = {}

    def register(self, name: str, lazy=True):
        assert name not in self.registered_params, f"请勿重复注册参数: {name}"

        def wrapper(func):
            self.registered_params[name] = Param(func, lazy)
            return func

        return wrapper

    def match_broker(self, asset: "type[BaseAsset]") -> "BaseBroker|None":
        for candidate_broker in self.brokers:
            if candidate_broker.matchable(asset):
                return candidate_broker

        return None

    def liquidate(self, asset: "BaseAsset", day: date, moment: time) -> float:
        if isinstance(asset, Cash):
            return asset.liquidate(day, moment)

        # 查找匹配的broker进行资产清算
        if (broker := self.match_broker(asset.__class__)) is None:
            return -1

        return broker.liquidate_asset(asset, day, moment).liquidate(day, moment)

    @property
    def timeline(self):
        current_date = self.start_date
        while current_date <= self.end_date:
            # 遍历每天的所有时间点
            for current_time in self.film:
                # 更新环境变量
                self.env = Env(date=current_date, time=current_time)
                # 调用时间点钩子函数
                self.timeline_hook(current_date, current_time)
                yield current_date, current_time
            current_date += timedelta(days=1)

    def run_roll(self, roll: Rollup, day: date, moment: time):
        # 设置当前环境策略
        self.env.strategy = roll.strategy
        results = []
        triggered = False

        try:
            logger.trace(f"运行策略: {roll.strategy}")
            logger.trace(f"当前env: {self.env}")

            # 构建基础参数上下文
            params = {
                "day": day,
                "moment": moment,
                "portfolio": roll.portfolio,
                "context": roll.strategy.context,
                "query": self.query,
                "trader": self,
                "strategy": roll.strategy
            }
            logger.trace(f"基础params: {params}")

            # 注入非懒加载参数
            for name, param in self.registered_params.items():
                if param.lazy: continue

                params[name] = inject(param.func, **params)

            # 获取触发的钩子函数
            hooks = roll.strategy.triggered(**params)
            logger.trace(f"触发的全部hooks:{hooks}")

            if not hooks:
                return

            triggered = True

            # 注入懒加载参数
            for name, param in self.registered_params.items():
                if not param.lazy: continue

                params[name] = inject(param.func, **params)

            # 执行所有触发的钩子函数
            for hook in hooks:
                logger.trace(f"运行hook: {hook}")
                gen = hook(**params)
                order: BaseOrder | None = None
                result: Result | None = None

                # 处理生成器函数（支持多次yield订单）
                while True:
                    try:
                        # 获取下一个订单（首次使用next，后续使用send）
                        order = gen.send(result) if order else next(gen)

                        with logger.group(f"处理订单{order}"):
                            assert isinstance(order, BaseOrder), f"只能yield Order, 实际为{type(order)}"
                            logger.trace(f"{hook}发出Order:{order}, 开始匹配Broker")

                            # 匹配broker处理订单
                            broker = self.match_broker(order.asset)

                            if not broker:
                                logger.warning(f"{order}没有对应broker, 忽略该order")
                                result = None
                                continue

                            logger.trace(f"{broker}开始处理: {order}")

                            # 执行订单并处理结果
                            if result := broker.execute_order(order, roll.portfolio):
                                logger.trace(f"{broker}处理完成:{result}")
                                # 更新投资组合
                                roll.portfolio += result.brought
                                roll.portfolio -= result.sold
                                # 收集交易结果
                                results.append(result)
                                logger.trace(f"资产增加{result.brought}, 减少{result.sold}")
                            else:
                                logger.trace(f"{broker}跳过指令:{order}")

                    except StopIteration:
                        logger.trace(f"运行结束{hook}")
                        break
        finally:
            shard = Shard(
                day,
                moment,
                roll.portfolio.copy,
                results,
                [self.liquidate(asset, day, moment) for asset in roll.portfolio]
            )

            roll.shards.append(shard)

            if triggered:
                logger.success(
                    f"持仓: {roll.portfolio}\n"
                    f"净值: {sum(shard.liquidating_values)}"
                )
            else:
                logger.trace(
                    f"持仓: {roll.portfolio}\n"
                    f"净值: {sum(shard.liquidating_values)}"
                )

            # 确保清理环境策略
            self.env.strategy = None

    @staticmethod
    def gen_strategy_report(roll: Rollup, log: bool) -> list[PeriodData]:
        strategy_data = []
        # 使用进度条显示生成进度
        for shard in tqdm(roll.shards, f"生成报告:{roll.strategy}"):
            # 格式化日期时间
            datetime_str = datetime.combine(shard.day, shard.moment).isoformat()
            strategy_data.append(PeriodData(
                datetime=datetime_str,
                liquidating_value=sum(shard.liquidating_values),
                logs=logger.records.get(f"{roll.strategy.name}-{datetime_str}", []) if log else [],
                portfolios=[
                    AssetData.from_asset(asset, liquidating_value=liquidating_value)
                    for asset, liquidating_value in zip(shard.portfolio, shard.liquidating_values)
                ],
                transactions=[
                    OrderResultData.from_result(result)
                    for result in shard.results
                ]
            ))

        return strategy_data

    @staticmethod
    def gen_benchmark_report(benchmark_name: str, benchmark_points: dict[datetime, float]) -> BenchmarkData:
        points = []
        init_value = None

        for d, v in benchmark_points.items():
            if init_value is None:
                init_value = v

            points.append(PointData(datetime=d.isoformat(), value=v))

        return BenchmarkData(name=benchmark_name, init_value=init_value, points=points)

    def timeline_hook(self, current_date: date, current_time: time):
        ...


class SingleTrader[T:Strategy](BaseTrader):
    def __init__(
            self,
            api: "BaseAPI",
            base: float,
            scale: float,
            init_portfolio: Portfolio,
            start_date: date,
            end_date: date,
            padding: int,
            film: type[BaseFilm],
            brokers: list["BaseBroker"],
            **kwargs
    ):
        super().__init__(api, base, scale, start_date, end_date, padding, film, brokers, **kwargs)
        self.init_portfolio = init_portfolio
        self.roll = None

    def set_strategy(self, strategy: T):
        # 创建单个策略的运行上下文
        self.roll = Rollup(strategy=strategy, portfolio=self.init_portfolio, shards=[])

    def run(self):
        assert self.roll is not None, "未使用set_strategy设置策略"

        for day, stage in self.timeline:
            logger.trace(f"==========日期:{day}===阶段:{stage}==========")
            self.run_roll(self.roll, day, stage)

    def report(
            self,
            title: str,
            description: str,
            benchmark_name: str,
            benchmark_points: dict[datetime, float],
            log: bool = True
    ) -> SingleStrategyReportV1:
        return SingleStrategyReportV1(
            title=title,
            description=description,
            base=self.base,
            scale=self.scale,
            start_date=self.start_date.isoformat(),
            end_date=self.end_date.isoformat(),
            strategy=self.gen_strategy_report(self.roll, log),
            benchmark=self.gen_benchmark_report(benchmark_name, benchmark_points)
        )


class MultiTrader(BaseTrader):
    def __init__(
            self,
            api: "BaseAPI",
            base: float,
            scale: float,
            init_portfolio: Portfolio,
            start_date: date,
            end_date: date,
            padding: int,
            film: type[BaseFilm],
            brokers: list["BaseBroker"],
            **kwargs
    ):
        super().__init__(api, base, scale, start_date, end_date, padding, film, brokers, **kwargs)

        self.init_portfolio = init_portfolio
        self.rolls = []

    def set_strategies(self, strategies: list["Strategy"]):
        # 确保所有策略名称唯一
        assert len(strategies) == len(set(map(str, strategies))), "请给Strategy设置不同名称"

        # 为每个策略创建独立的运行上下文
        self.rolls = [
            Rollup(strategy=strategy, portfolio=self.init_portfolio.copy, shards=[])
            for strategy in strategies
        ]

    def run(self):
        for day, stage in self.timeline:
            logger.trace(f"==========日期:{day}===阶段:{stage}==========")
            for roll in self.rolls:
                self.run_roll(roll, day, stage)

    def report(
            self,
            title: str,
            description: str,
            benchmark_name: str,
            benchmark_points: dict[datetime, float],
            log: bool = True
    ) -> MultiStrategyReportV1:
        return MultiStrategyReportV1(
            title=title,
            description=description,
            base=self.base,
            scale=self.scale,
            start_date=self.start_date.isoformat(),
            end_date=self.end_date.isoformat(),
            strategy={roll.strategy.name: self.gen_strategy_report(roll, log) for roll in self.rolls},
            benchmark=self.gen_benchmark_report(benchmark_name, benchmark_points)
        )


__all__ = ["SingleTrader", "MultiTrader"]
