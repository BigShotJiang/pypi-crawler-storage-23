from ..asset.base_asset import BaseAsset


class Portfolio:
    def __init__(self, *args: BaseAsset):
        self.assets: list[BaseAsset] = list(args)

    def add(self, asset: BaseAsset):
        for index in range(len(self.assets)):
            # 检查是否为同类资产
            if self.assets[index] != asset:
                continue

            # 合并同类资产
            self.assets[index] += asset
            break
        else:
            # 如果没有找到同类资产，添加新资产
            self.assets.append(asset)

    def sub(self, asset: BaseAsset):
        for index in range(len(self.assets)):
            if self.assets[index] != asset:
                continue

            # 减少同类资产头寸
            self.assets[index] -= asset
            break
        else:
            # 如果没有找到同类资产，添加负头寸资产（做空）
            self.assets.append(-asset)

        # 清理头寸为0且可关闭的资产
        self.assets = [i for i in self.assets if not (i.is_empty and i.is_closeable)]

    def __add__(self, other: BaseAsset | list[BaseAsset]) -> "Portfolio":
        if isinstance(other, BaseAsset):
            self.add(other)

        if isinstance(other, list):
            for asset in other:
                assert isinstance(asset, BaseAsset), f"只允许添加资产, 实际为{type(asset)}"
                self.add(asset)

        return self

    def __sub__(self, other: BaseAsset | list[BaseAsset]) -> "Portfolio":
        if isinstance(other, BaseAsset):
            self.sub(other)

        if isinstance(other, list):
            for asset in other:
                assert isinstance(asset, BaseAsset), f"只允许减少资产, 实际为{type(asset)}"
                self.sub(asset)

        return self

    def __getitem__[AssetType:BaseAsset](self, item: type[AssetType]) -> list[AssetType]:
        return [i for i in self.copy.assets if isinstance(i, item)]

    def __iter__(self):
        return iter(self.copy.assets)

    @property
    def copy(self) -> "Portfolio":
        return Portfolio(*[asset.copy for asset in self.assets])

    def __repr__(self) -> str:
        return f"资产: {self.assets}"

    __str__ = __repr__


__all__ = ["Portfolio"]
