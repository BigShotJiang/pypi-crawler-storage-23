from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

LOG_LEVEL = Literal["TRACE", "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]


class Config(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra="allow")

    log_level: LOG_LEVEL = Field(default="INFO", description="日志等级")
    cache_dir: str = Field(default="./temp", description="缓存文件夹位置")
    output_dir: str = Field(default="./output", description="生成报告的存放位置")
    lru_capacity: int = Field(default=128, description="lru_cache的size")


config = Config()

__all__ = ["Config", "config"]
