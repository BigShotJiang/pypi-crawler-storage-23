from abc import abstractmethod, ABC
from datetime import datetime

from ..asset import BaseAsset


class BaseWhich[T:BaseAsset](ABC):
    def __or__(self, right: "BaseWhich") -> "BaseWhich":
        left = self

        # 创建并集组合类
        class CombinedOr(BaseWhich):
            def __init__(self):
                self.left = left  # 左侧操作数实例
                self.right = right  # 右侧操作数实例

            def query(self, *args, **kwargs) -> list[type[T]]:
                # 获取左右实例的查询结果
                res_left = self.left.query(*args, **kwargs)
                res_right = self.right.query(*args, **kwargs)

                # 合并结果并去重（保持顺序）
                merged = []
                seen = set()
                for item in res_left + res_right:
                    if item not in seen:
                        seen.add(item)
                        merged.append(item)
                return merged

        return CombinedOr()

    def __and__(self, right: "BaseWhich") -> "BaseWhich":
        left = self

        # 创建交集组合类
        class CombinedAnd(BaseWhich):
            def __init__(self):
                self.left = left  # 左侧操作数实例
                self.right = right  # 右侧操作数实例

            def query(self, *args, **kwargs) -> list[type[T]]:
                # 获取左右实例的查询结果
                res_left = self.left.query(*args, **kwargs)
                res_right = self.right.query(*args, **kwargs)

                # 计算交集（保持左侧顺序）
                set_right = set(res_right)
                return [item for item in res_left if item in set_right]

        return CombinedAnd()

    @abstractmethod
    def query(self, timepoint: datetime) -> list[type[T]]:
        ...


__all__ = ["BaseWhich"]
