from inspect import isclass
from datetime import date
from itertools import product

from pydantic import BaseModel

from .panel import DataPanel
from .base_delegate import BaseDelegate

from ..logger import logger
from ..configure import config, Config


class BaseAPIMeta(type):
    def __or__(
            self: "type[BaseAPI]",
            other: "type[BaseAPI]"
    ) -> "type[BaseCombinedAPI]":
        assert isclass(self), f"{self}不为类"
        assert isclass(other), f"{other}不为类"
        assert issubclass(self, BaseAPI), f"{self}不为BaseAPI的子类"
        assert issubclass(other, BaseAPI), f"{other}不为BaseAPI的子类"

        api_classes = []

        if issubclass(self, BaseCombinedAPI):
            api_classes.extend(self.api_classes)
        else:
            api_classes.append(self)

        if issubclass(other, BaseCombinedAPI):
            api_classes.extend(other.api_classes)
        else:
            api_classes.append(other)

        return type[BaseCombinedAPI](
            f"CombinedAPI",
            (BaseCombinedAPI,),
            {'api_classes': api_classes}
        )


class BaseAPI[SettingType](metaclass=BaseAPIMeta):
    setting_class: type[BaseModel]
    delegate_classes: list[type[BaseDelegate[SettingType]]]

    def __init_subclass__(cls, **kwargs):
        setting_class = getattr(cls, "setting_class", None)
        assert setting_class is not None, \
            f"{cls.__name__}必须实现类属性setting_class"
        assert isclass(setting_class), \
            f"{cls.__name__}类属性setting_class必须是类，实际为{setting_class}"
        assert issubclass(setting_class, BaseModel), \
            f"{cls.__name__}类属性setting_class必须为BaseModel子类, 实际为{setting_class}"

        delegate_classes = getattr(cls, "delegate_classes", None)
        assert delegate_classes is not None, \
            f"{cls.__name__}必须实现类属性delegate_classes"
        assert isinstance(delegate_classes, list), \
            f"{cls.__name__}类属性delegate_classes必须为列表, 实际为{type(delegate_classes)}"
        for delegate_class in delegate_classes:
            assert isclass(delegate_class), \
                f"{cls.__name__}类属性delegate_classes的元素必须为类，实际为{delegate_class}"
            assert issubclass(delegate_class, BaseDelegate), \
                f"{cls.__name__}类属性delegate_classes的元素必须为BaseDelegate子类, 实际为{delegate_class}"

    def __init__(self):
        self.config = config
        self.setting: SettingType = self.setting_class.model_validate(config.model_dump())
        self.delegates = self.initialize_delegates()

    def initialize_delegates(self) -> list[BaseDelegate[SettingType]]:
        return [i(self.config, self.setting) for i in self.delegate_classes]

    def query(self, start_date: date, end_date: date, fields: list[str], **kwargs) -> None | DataPanel:
        # 分配字段到对应的委托对象
        fields_delegation: dict[BaseDelegate[SettingType], list[str]] = {}

        picked = []
        invalid_delegate = []
        for delegate, field in product(self.delegates, fields):
            if field in picked:
                continue

            if not delegate.valid:
                invalid_delegate.append(delegate)
                continue

            if not delegate.has_field(field, **kwargs):
                continue

            if not fields_delegation.get(delegate):
                fields_delegation[delegate] = []

            fields_delegation[delegate].append(field)
            picked.append(field)

        # 记录无法查询的字段
        omitted = set(fields) - set(picked)

        logger.trace((
            f"不生效的delegate: {invalid_delegate}\n"
            f"无法查询的字段: {omitted}\n",
            f"字段查询分配: {fields_delegation}"
        ))

        if omitted:
            logger.warning(f"无法查询的字段: {omitted}")

        # 合并所有委托对象的查询结果
        res: None | DataPanel = None

        for delegate, fields in fields_delegation.items():
            panel = delegate.execute(start_date, end_date, fields, **kwargs)
            if res is None:
                res = panel
            else:
                res <<= panel

        return res

    def __repr__(self) -> str:
        return f"<API {self.__class__.__name__}>"

    __str__ = __repr__


class BaseCombinedAPI(BaseAPI):
    setting_class = Config
    delegate_classes = []
    api_classes: list[type[BaseAPI]]

    def __init_subclass__(cls, **kwargs):
        api_classes = getattr(cls, "api_classes", None)
        assert api_classes is not None, \
            f"{cls.__name__}必须实现类属性api_classes"
        for api_class in api_classes:
            assert isclass(api_class), \
                f"{cls.__name__}类属性delegate_classes元素必须为类, 实际为{api_class}"
            assert issubclass(api_class, BaseAPI), \
                f"{cls.__name__}类属性delegate_classes元素必须为BaseAPI子类, 实际为{api_class}"

    def initialize_delegates(self) -> list[BaseDelegate]:
        delegates = []

        for api_class in self.api_classes:
            delegates += api_class().delegates

        return delegates

    def __repr__(self) -> str:
        return f"<CombinedAPI {'|'.join(map(lambda x: x.__name__, self.api_classes))}>"

    __str__ = __repr__


__all__ = ["BaseAPI", "BaseCombinedAPI"]
