class AutoDescriptor:
    def __init__(self, name):
        self.name = name

    def __get__(self, obj, obj_type):
        return self.name


class AutoMeta(type):
    def __new__(cls, name, bases, attrs):
        new_attrs = {}
        for attr_name, attr_value in attrs.items():
            if isinstance(attr_value, Auto):
                # 替换为描述符，返回属性名本身
                new_attrs[attr_name] = AutoDescriptor(attr_name)
            else:
                new_attrs[attr_name] = attr_value
        return super().__new__(cls, name, bases, new_attrs)


class Auto(str):
    ...


# 使用元类
class Field(str, metaclass=AutoMeta):
    def __new__(cls, name) -> str:
        for k, v in cls.__dict__.items():
            if not isinstance(v, AutoDescriptor):
                continue

            if name == k:
                return v.name
        else:
            raise AttributeError(name)


__all__ = ["Field", "Auto"]
