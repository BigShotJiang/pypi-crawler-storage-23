from abc import ABC, abstractmethod
from typing import Callable
from datetime import date

import pandas as pd
from pydantic import BaseModel

from .panel import DataPanel
from ..configure import Config


class BaseDelegate[SettingType:BaseModel](ABC):
    pair: list[tuple[str, str]]
    field2str: dict[str, str]
    str2field: dict[str, str]

    DATE_FIELD = "日期"

    @property
    def valid(self):
        return True

    def __init_subclass__(cls, **kwargs):
        if ABC in cls.__bases__:
            return

        assert hasattr(cls, 'pair'), f'{cls.__name__}必须实现类属性pair'

        # 自动生成双向映射字典
        cls.field2str = {k: v for k, v in cls.pair}
        cls.str2field = {v: k for k, v in cls.pair}

    def __init__(self, config: Config, setting: SettingType) -> None:
        self.config = config
        self.setting = setting

    def rename_columns(self, data: pd.DataFrame, date_field: str) -> pd.DataFrame:
        if date_field != "index":
            data = data.rename(columns={**self.str2field, date_field: self.DATE_FIELD})
        else:
            data = data.rename(columns=self.str2field)
            data.index.name = self.DATE_FIELD
        return data

    def use_date_index(self, data: pd.DataFrame, formatter: Callable = None) -> pd.DataFrame:
        if formatter:
            data[self.DATE_FIELD] = data[self.DATE_FIELD].apply(formatter)

        data[self.DATE_FIELD] = pd.to_datetime(data[self.DATE_FIELD])
        data = data.set_index(self.DATE_FIELD)
        data = data.sort_index()

        return data

    def execute(self, start_date: date, end_date: date, fields: list[str], **kwargs) -> DataPanel:
        # 查询原始数据
        data = self.query(start_date, end_date, fields, **kwargs)
        # 生成数据掩码（避免未来数据）
        mask = None if kwargs.get("no_mask") else self.mask(data, start_date, end_date, fields, **kwargs)
        # 筛选指定字段，按日期范围过滤
        data = data[fields]
        data = data[start_date:end_date]

        if mask is not None:
            mask = mask[fields]
            mask = mask[start_date:end_date]
        return DataPanel(data, mask)

    @abstractmethod
    def has_field(self, field: str, **kwargs) -> bool:
        raise NotImplementedError

    @abstractmethod
    def query(self, start_date: date, end_date: date, fields: list[str], **kwargs) -> pd.DataFrame:
        raise NotImplementedError

    @abstractmethod
    def mask(
            self, data: pd.DataFrame,
            start_date: date,
            end_date: date,
            fields: list[str], **kwargs
    ) -> pd.DataFrame:
        raise NotImplementedError


__all__ = ["BaseDelegate"]
