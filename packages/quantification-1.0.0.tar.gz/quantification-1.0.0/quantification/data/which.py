from datetime import datetime

from .base_which import BaseWhich
from ..asset.base_asset import BaseAsset


class StaticWhich[T:BaseAsset](BaseWhich):
    def __init__(self, assets: list[type[T]]) -> None:
        self.assets = assets

    def query(self, timepoint: datetime) -> list[type[T]]:
        return self.assets


__all__ = ["StaticWhich"]
