from datetime import datetime

import pandas as pd


class DataPanel(pd.DataFrame):
    def __init__(self, data: pd.DataFrame, mask: pd.DataFrame = None):
        super().__init__(data)

        # 验证数据格式
        if self.shape[0] != 0:
            assert type(self.index) == pd.DatetimeIndex, \
                f"DataPanel data的索引必须为pd.DatetimeIndex, 实际为{type(self.index)}"

        for col in self.columns:
            assert type(col) == str, \
                f"DataPanel data的列必须为Field, {col}实际为{type(col)}"

        self.mask = mask
        if self.mask is not None:
            # 验证掩码格式
            if self.mask.shape[0] != 0:
                assert type(self.index) == pd.DatetimeIndex, \
                    f"DataPanel mask的索引必须为pd.DatetimeIndex, 实际为{type(self.index)}"

            for col in self.mask.columns:
                assert type(col) == str, \
                    f"DataPanel mask的列必须为Field, {col}实际为{type(col)}"

            # 验证数据和掩码结构一致性
            assert self.columns.equals(self.mask.columns) and self.shape == self.mask.shape, \
                f"DataPanel data与mask的结构不一致, data:\n{self}\nmask:\n{self.mask} "

    def __lshift__(self, other: "DataPanel") -> "DataPanel":
        assert self.mask is not None, "无mask 的 DataPanel不支持合并"
        assert other.mask is not None, "无mask 的 DataPanel不支持合并"
        assert isinstance(other, DataPanel), f"DataPanel只能与DataPanel进行lshift操作, 实际为{type(other)}"
        return DataPanel(self.join(other, how='outer'), self.mask.join(other.mask, how='outer'))

    def on(self, d: datetime) -> pd.DataFrame:
        assert self.mask is not None, "无mask 的 DataPanel不支持过滤"
        return self.where((self.mask <= d) | self.isna(), other="invalid")[:d.date()]

    @property
    def df(self) -> pd.DataFrame:
        return pd.DataFrame(self)


__all__ = ["DataPanel"]
