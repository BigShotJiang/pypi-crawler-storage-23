import pickle
import inspect
import hashlib
from functools import partial


def gen_func_sig(func):
    module = func.__module__ if not isinstance(func, partial) else func.func.__module__
    name = func.__name__ if not isinstance(func, partial) else func.func.__name__
    return f"{module}.{name}"


def gen_unique_sig(func, *args, **kwargs):
    # 绑定参数生成唯一缓存键
    sig = inspect.signature(func)
    bound_args = sig.bind(*args, **kwargs)
    bound_args.apply_defaults()
    args_dict = bound_args.arguments
    sorted_args = sorted(args_dict.items(), key=lambda x: x[0])

    key_data = (gen_func_sig(func), sorted_args)

    # 计算哈希作为文件名
    return f"sig_{hashlib.sha256(pickle.dumps(key_data)).hexdigest()}"
