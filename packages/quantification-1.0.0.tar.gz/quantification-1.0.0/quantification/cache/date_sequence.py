from typing import Callable, cast
from pathlib import Path
from datetime import date, timedelta, datetime
from functools import wraps

import pandas as pd

from .common import gen_func_sig, gen_unique_sig
from ..configure import config

CACHE_DIR = Path(config.cache_dir) / 'query' / "date_sequence"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


def merge_ranges(ranges: list[tuple[date, date]]) -> list[tuple[date, date]]:
    if not ranges:
        return []

    normalized_ranges = [
        (min(date1, date2), max(date1, date2))
        for date1, date2 in ranges
    ]

    normalized_ranges.sort(key=lambda x: x[0])

    ranges = []

    for current_start, current_end in normalized_ranges:
        if not ranges:
            ranges.append((current_start, current_end))
            continue

        # 获取上一个范围
        last_start, last_end = ranges[-1]

        # 检查当前范围是否与上一个范围重叠或相邻
        # 如果当前开始日期 <= 上一个结束日期 + 1天，则合并
        if current_start <= last_end + timedelta(days=1):
            # 合并范围，结束日期取两者中的最大值
            new_end = max(last_end, current_end)
            ranges[-1] = (last_start, new_end)
        else:
            # 不重叠也不相邻，添加新范围
            ranges.append((current_start, current_end))

    ranges.sort(key=lambda x: x[0])

    return ranges


def serialize_ranges(ranges: list[tuple[date, date]]) -> list[tuple[str, str]]:
    return [
        (start.strftime("%Y%m%d"), end.strftime("%Y%m%d"))
        for start, end in merge_ranges(ranges)
    ]


def deserialize_ranges(ranges: list[tuple[str, str]]) -> list[tuple[date, date]]:
    return merge_ranges([
        (datetime.strptime(start, "%Y%m%d").date(), datetime.strptime(end, "%Y%m%d").date())
        for start, end in ranges
    ])


def range_sub_ranges(
        target_range: tuple[date, date], merged_ranges: list[tuple[date, date]]
) -> list[tuple[date, date]]:
    """
     计算一个日期范围减去多个合并后的日期范围的结果

     参数:
         range: 目标范围 (开始日期, 结束日期)
         ranges: 已合并的范围列表，确保不相交且不相邻

     返回:
         剩余的范围列表，按开始日期排序
     """
    if not merged_ranges:
        return [target_range]

    # 规范化目标范围
    target_start, target_end = min(target_range[0], target_range[1]), max(target_range[0], target_range[1])

    # 确保合并的范围已排序
    sorted_ranges = sorted(merged_ranges, key=lambda x: x[0])

    result = []
    current_start = target_start

    # 遍历已合并的范围
    for r_start, r_end in sorted_ranges:
        # 如果当前范围完全在目标范围左侧，跳过
        if r_end < target_start:
            continue

        # 如果当前范围完全在目标范围右侧，结束循环
        if r_start > target_end:
            break

        # 如果当前范围与目标范围有重叠
        if r_start <= target_end and r_end >= target_start:
            # 计算重叠部分
            overlap_start = max(r_start, target_start)
            overlap_end = min(r_end, target_end)

            # 如果当前开始日期在重叠开始之前，添加未被覆盖的部分
            if current_start < overlap_start:
                result.append((current_start, overlap_start - timedelta(days=1)))

            # 更新当前开始日期为重叠结束日期的后一天
            current_start = overlap_end + timedelta(days=1)

            # 如果当前开始日期已经超过目标结束日期，结束循环
            if current_start > target_end:
                break

    # 处理最后一部分
    if current_start <= target_end:
        result.append((current_start, target_end))

    return result


class DateSequenceCacheAPI:
    def __init__(
            self,
            *,
            start_param: str,
            end_param: str,
            date_column: str,
            query_date_convertor: Callable | None,
            index_date_convertor: Callable | None
    ):
        self.start_param = start_param
        self.end_param = end_param
        self.date_column = date_column
        self.query_date_convertor = query_date_convertor
        self.index_date_convertor = index_date_convertor

    def query(self, func, start_date: date, end_date: date, args, kwargs) -> pd.DataFrame:
        kwargs[self.start_param] = self.query_date_convertor(start_date)
        kwargs[self.end_param] = self.query_date_convertor(end_date)
        res = func(*args, **kwargs)

        if res is None:
            print(gen_func_sig(func), start_date, end_date, args, kwargs)

        if self.index_date_convertor:
            res[self.date_column] = res[self.date_column].apply(self.index_date_convertor)

        res[self.date_column] = pd.to_datetime(res[self.date_column])
        res = res.set_index(self.date_column)
        res = res.sort_index()

        return res

    def __call__(self, func):
        @wraps(func)
        def wrapper(start_date: date, end_date: date, *args, **kwargs):
            assert start_date <= end_date, "结束日期必须大于等于开始日期"

            with pd.HDFStore(str(CACHE_DIR / f"{gen_func_sig(func)}.h5")) as h5:
                kwargs.pop(self.start_param, None)
                kwargs.pop(self.end_param, None)

                key = gen_unique_sig(func, *args, **kwargs)
                target_range = (start_date, end_date)

                if not key in h5:
                    res = self.query(func, start_date, end_date, args, kwargs)
                    h5.put(key, res, format='table')
                    h5.get_storer(key).attrs["ranges"] = serialize_ranges([target_range])
                    h5.flush()
                    return res

                cache = cast(pd.DataFrame, h5.get(key))
                ranges = deserialize_ranges(h5.get_storer(key).attrs["ranges"])
                sub_ranges = range_sub_ranges(target_range, ranges)

                if len(sub_ranges) == 0:
                    return cache[pd.Timestamp(start_date):pd.Timestamp(end_date)]

                if len(sub_ranges) == 1:
                    start, end = sub_ranges[0]
                    increment = self.query(func, start, end, args, kwargs)
                else:
                    increment = self.query(func, start_date, end_date, args, kwargs)

                result = pd.concat([cache, increment])
                result = result.groupby(result.index).last()
                result = result.sort_index()

                h5.put(key, result, format='table')
                h5.get_storer(key).attrs["ranges"] = serialize_ranges(merge_ranges([*ranges, target_range]))
                h5.flush()

                return result[pd.Timestamp(start_date):pd.Timestamp(end_date)]

        return wrapper


__all__ = ['DateSequenceCacheAPI']
