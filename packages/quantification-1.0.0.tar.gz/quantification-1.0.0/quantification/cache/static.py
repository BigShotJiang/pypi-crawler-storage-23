import time
import pickle
from pathlib import Path
from functools import lru_cache, wraps

from .common import gen_unique_sig
from ..configure import config

CACHE_DIR = Path(config.cache_dir) / "query" / "static"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


@lru_cache(maxsize=config.lru_capacity)
def get(cache_file):
    with open(cache_file, 'rb') as f:
        return pickle.load(f)


def flush(cache_file, func, *args, **kwargs):
    result = func(*args, **kwargs)
    with open(cache_file, 'wb') as file:
        pickle.dump(result, file)  # noqa
    return result


def get_or_flush(cache_file, func, *args, **kwargs):
    try:
        return get(cache_file)
    except (pickle.UnpicklingError, EOFError, FileNotFoundError):
        return flush(cache_file, func, *args, **kwargs)


class StaticCacheAPI:
    def __init__(self, *, update=None, expire_seconds=86400):
        self.update = update
        self.expire_seconds = expire_seconds

    def __call__(self, func):
        @wraps(func)
        def wrapper(*args, **kwargs):

            cache_file = CACHE_DIR / f"{gen_unique_sig(func, *args, **kwargs)}.pkl"
            cache_exists = cache_file.exists()

            match self.update:
                case True:
                    return flush(cache_file, func, *args, **kwargs)

                case False:
                    if not cache_exists:
                        return flush(cache_file, func, *args, **kwargs)

                    return get_or_flush(cache_file, func, *args, **kwargs)

                case None:
                    if not cache_exists:
                        return flush(cache_file, func, *args, **kwargs)

                    if self.expire_seconds is not None:
                        current_time = time.time()
                        mtime = cache_file.stat().st_mtime
                        cache_valid = (current_time - mtime) <= self.expire_seconds
                    else:
                        cache_valid = True  # 无有效期要求

                    if not cache_valid:
                        return flush(cache_file, func, *args, **kwargs)

                    return get_or_flush(cache_file, func, *args, **kwargs)

                case _:
                    raise ValueError("Invalid update parameter value")

        return wrapper


__all__ = ["StaticCacheAPI"]
