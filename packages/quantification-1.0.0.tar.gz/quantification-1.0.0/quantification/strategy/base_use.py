import inspect
from abc import ABC, abstractmethod
from typing import Generator, Callable

from ..util import inject
from ..trader import BaseOrder, Result

# 类型别名定义
OrderGenerator = Generator[BaseOrder, Result, None]  # 订单生成器类型
CommonFunc = Callable[..., None]  # 普通函数类型
GeneratorFunc = Callable[..., OrderGenerator]  # 生成器函数类型
Func = CommonFunc | GeneratorFunc  # 函数类型联合


class Injection(ABC):
    name: str

    @abstractmethod
    def __init__(self, *args, **kwargs) -> None:
        raise NotImplementedError

    def __init_subclass__(cls, **kwargs):
        name = getattr(cls, "name", None)
        assert name, \
            "Injection类需要指定参数名"
        assert isinstance(name, str), \
            "Injection指定的参数名必须为str"

    @abstractmethod
    def __call__(self, **kwargs):
        raise NotImplementedError


class Use:
    def __init__(self, injection: type[Injection]):
        self.injection = injection

    def __call__(self, *args, **kwargs):
        def wrapper(func: Func | WrappedFunc) -> WrappedFunc:
            # 如果函数已经被包装过，直接使用；否则创建新的包装
            wrapped_func = func if isinstance(func, WrappedFunc) else WrappedFunc(func)
            # 注册注入实例
            wrapped_func.register(self.injection(*args, **kwargs))
            return wrapped_func

        return wrapper


class WrappedFunc:
    def __init__(self, func: Func):
        self.func = func
        self.injections: list[Injection] = []

    def register(self, injection: Injection):
        self.injections.append(injection)

    def __call__(self, **kwargs):
        # 构建注入参数字典
        injection_kwargs = {
            **kwargs,
            **{injection.name: injection(**kwargs) for injection in self.injections}
        }

        # 使用依赖注入调用函数
        result = inject(self.func, **injection_kwargs)

        # 处理生成器函数
        return result if not inspect.isgenerator(result) else (yield from result)

    def __repr__(self) -> str:
        return f"<WrappedFunc {self.func.__name__}>"

    __str__ = __repr__


__all__ = ["Use", "Injection", "WrappedFunc", "Func"]
