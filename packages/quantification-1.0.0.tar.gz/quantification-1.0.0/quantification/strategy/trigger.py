from datetime import date, time

from .base_trigger import Condition, Trigger
from ..trader.base_film import Period


class EveryDay(Condition):
    def __call__(self):
        return True

    def name(self):
        return "每日"

    @property
    def copy(self):
        return self.__class__()


class EveryNDay(Condition):
    def __init__(self, days: int):
        self.days = days
        self.pre_date: date | None = None

    def __call__(self, day: date) -> bool:
        if self.pre_date is None:
            return True

        if (day - self.pre_date).days >= self.days:
            return True

        return False

    def settle(self, day: date):
        self.pre_date = day

    def name(self):
        return f"每{self.days}日"

    @property
    def copy(self):
        return self.__class__(self.days)


class EveryMonthNDay(Condition):
    def __init__(self, days: int):
        self.days = days
        self.triggered_date: date | None = None

    def __call__(self, day: date) -> bool:
        if self.triggered_date is None:
            return day.day >= self.days

        if self.triggered_date.month == day.month:
            return day < self.triggered_date

        self.triggered_date = None
        return day.day >= self.days

    def settle(self, day: date):
        self.triggered_date = day

    def name(self):
        return f"每月的第{self.days}日"

    @property
    def copy(self):
        return self.__class__(self.days)


class OnPeriod(Condition):
    def __init__(self, period: Period):
        self.period = period

    def __call__(self, moment: time) -> bool:
        return moment in self.period

    def name(self):
        return f"当时间再{self.period}内"

    @property
    def copy(self):
        return self.__class__(self.period)


class T:
    每日 = Trigger(EveryDay())
    每N日 = lambda x: Trigger(EveryNDay(x))
    每月第N日 = lambda x: Trigger(EveryMonthNDay(x))
    时期 = lambda x: Trigger(OnPeriod(x))


__all__ = ["T"]
