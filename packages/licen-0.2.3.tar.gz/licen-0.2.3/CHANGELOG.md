# 2026.02.23 v0.2.3
- replace docopt with docopt-ng

# 2026.02.23 v0.2.2(yanked)
- Support python 3.10+
- Drop python2.x support

# 2015.03.07 v0.2.1
- Support python 3.3
- Add test

# 2015.03.03 v0.1.0
- Initial release, feature support:
- list the supported license and header
- generate license and header
- list variables in the template
