#!/usr/bin/env python3

__title__ = "licen"
__version__ = "0.2.3"
__author__ = "lord63"
__license__ = "MIT"
__copyright__ = "Copyright 2015 lord63"
