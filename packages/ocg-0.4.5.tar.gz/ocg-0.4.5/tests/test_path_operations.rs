use std::collections::HashMap;
use ocg::{execute_with_params, PropertyGraph};

#[test]
fn test_shortest_path() {
    let mut graph = PropertyGraph::new();
    let params = HashMap::new();

    // Create a simple graph: (a)-[:R]->(b)-[:R]->(c)
    execute_with_params(
        &mut graph,
        "CREATE (a:Node {name: 'A'})-[:REL]->(b:Node {name: 'B'})-[:REL]->(c:Node {name: 'C'})",
        params.clone()
    ).unwrap();

    println!("\n=== Test 1: shortestPath with pattern ===");
    let result = execute_with_params(
        &mut graph,
        "MATCH (a:Node {name: 'A'}), (c:Node {name: 'C'})
         MATCH p = shortestPath((a)-[*]->(c))
         RETURN length(p) AS pathLength",
        params.clone()
    );
    println!("Result: {:?}", result);

    if let Ok(r) = result {
        println!("Path length: {:?}", r.rows[0].get("pathLength"));
    }

    println!("\n=== Test 2: nodes() function ===");
    let result = execute_with_params(
        &mut graph,
        "MATCH (a:Node {name: 'A'}), (c:Node {name: 'C'})
         MATCH p = shortestPath((a)-[*]->(c))
         RETURN nodes(p) AS pathNodes",
        params.clone()
    );
    println!("Result: {:?}", result);

    println!("\n=== Test 3: relationships() function ===");
    let result = execute_with_params(
        &mut graph,
        "MATCH (a:Node {name: 'A'}), (c:Node {name: 'C'})
         MATCH p = shortestPath((a)-[*]->(c))
         RETURN relationships(p) AS pathRels",
        params.clone()
    );
    println!("Result: {:?}", result);
}
