// Simple diagnostic test for basic WITH + ORDER BY
use ocg::{execute, PropertyGraph};

fn main() {
    let mut graph = PropertyGraph::new();

    // Test 1: Basic CREATE
    println!("Test 1: Basic CREATE");
    let result = execute(&mut graph, "CREATE (:A {num: 1})");
    match result {
        Ok(r) => println!("  ✓ Created {} nodes", r.stats.nodes_created),
        Err(e) => println!("  ✗ Error: {:?}", e),
    }

    // Test 2: Simple MATCH
    println!("\nTest 2: Simple MATCH");
    let result = execute(&mut graph, "MATCH (a:A) RETURN a");
    match result {
        Ok(r) => println!("  ✓ Found {} rows", r.row_count()),
        Err(e) => println!("  ✗ Error: {:?}", e),
    }

    // Test 3: WITH clause
    println!("\nTest 3: WITH clause");
    let result = execute(&mut graph, "MATCH (a:A) WITH a RETURN a");
    match result {
        Ok(r) => println!("  ✓ Found {} rows", r.row_count()),
        Err(e) => println!("  ✗ Error: {:?}", e),
    }

    // Test 4: WITH + ORDER BY + LIMIT (the failing case)
    println!("\nTest 4: WITH + ORDER BY + LIMIT");
    graph = PropertyGraph::new();
    execute(&mut graph, "CREATE (:A {num: 3}), (:A {num: 1}), (:A {num: 2})").ok();
    let result = execute(&mut graph, "MATCH (a:A) WITH a ORDER BY a.num LIMIT 2 RETURN a");
    match result {
        Ok(r) => {
            println!("  ✓ Found {} rows (expected 2)", r.row_count());
        }
        Err(e) => println!("  ✗ Error: {:?}", e),
    }
}
