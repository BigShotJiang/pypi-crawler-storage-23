//! Graph storage module.
//!
//! This module provides the property graph implementation using petgraph.

mod backend;
pub mod algorithm_engine;
pub mod backends;
pub mod serialization;
pub mod storage;
pub mod types;

pub use algorithm_engine::AlgorithmEngine;
pub use backend::{EdgeLike, GraphBackend, NodeLike};
pub use backends::{GraphrsBackend, NetworKitRustBackend, RustworkxCoreBackend};
pub use serialization::{GraphDump, SerializedGraph, SerializedEdge, dump_to_file, load_dump};
pub use storage::PropertyGraph;
pub use types::{GraphEdge, GraphNode, Path, PropertyValue};
