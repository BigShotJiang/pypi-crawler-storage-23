//! Graph algorithms for NetworKitRust.
//!
//! This module provides a comprehensive suite of graph algorithms from multiple sources,
//! all ported directly to work with NetworKit's Graph structure (zero conversion overhead):
//!
//! ## Native Algorithms (Ported from NetworKit C++)
//! - `distance`: BFS, Dijkstra, bidirectional Dijkstra, APSP, diameter, eccentricity
//! - `centrality`: Degree, betweenness, closeness, PageRank, eigenvector, Katz,
//!                 harmonic centrality, VoteRank
//! - `components`: Connected components, strongly connected components
//!
//! ## Ported from RustworkxCore (IBM Qiskit)
//! - `path`: A*, Bellman-Ford, Floyd-Warshall, all-pairs Dijkstra
//! - `shortest_path`: Dijkstra (single-source), all shortest paths, k-shortest, distance matrix
//! - `spanning_tree`: Kruskal's MST, Prim's MST, maximum spanning tree
//! - `dag`: Topological sort (Kahn + DFS + lex), DAG layers, collect_runs, longest path, cycles
//! - `flow`: Edmonds-Karp max flow, min cut
//! - `coloring`: Greedy node/edge coloring, Misra-Gries, two-color (bipartite),
//!               bipartite edge coloring, chromatic number
//! - `matching`: Max weight matching, max cardinality matching
//! - `connectivity`: Articulation points, bridges, core numbers, cycle basis, Johnson cycles,
//!                   Stoer-Wagner min cut, isolates, simple paths
//! - `traversal`: BFS layers, DFS edges, ancestors, descendants, BFS successors/predecessors
//! - `transitivity`: Triangle counting, global/local clustering coefficients
//! - `line_graph`: Line graph construction
//! - `planar`: Planarity testing (LR-planarity)
//! - `generators`: Complete, cycle, path, star, grid, Petersen, barbell, random, karate club
//! - `steiner_tree`: Metric closure, Steiner tree (Kou 2-approximation)
//! - `token_swapper`: Token swapping on graphs (quantum circuit routing)
//! - `contraction`: Node/edge contraction, quotient graph, parallel edge detection
//! - `euler`: Euler circuit/path detection and construction (Hierholzer's algorithm)
//!
//! ## Ported from Graphrs
//! - `community`: Louvain, Label Propagation, Girvan-Newman, modularity

// ─── Native NetworKit algorithms ─────────────────────────────────────────────
pub mod distance;
pub mod centrality;
pub mod components;

// ─── Ported from RustworkxCore ────────────────────────────────────────────────
pub mod path;
pub mod shortest_path;
pub mod spanning_tree;
pub mod dag;
pub mod flow;
pub mod coloring;
pub mod matching;
pub mod connectivity;
pub mod traversal;
pub mod transitivity;
pub mod line_graph;
pub mod planar;
pub mod generators;

pub mod steiner_tree;
pub mod clique;
pub mod token_swapper;
pub mod contraction;
pub mod euler;
pub mod graph_ops;
pub mod dominance;
pub mod layout;
pub mod isomorphism;

// ─── Ported from Graphrs ─────────────────────────────────────────────────────
pub mod community;


// ─── Native re-exports ────────────────────────────────────────────────────────
pub use distance::{BFS, Dijkstra, BidirectionalDijkstra, APSP, diameter, eccentricity};
pub use centrality::{
    DegreeCentrality, BetweennessCentrality, ClosenessCentrality, PageRank, CentralityResult,
    EigenvectorCentrality, KatzCentrality, harmonic_centrality, vote_rank,
    hits, HitsResult,
};
pub use components::{ConnectedComponents, StronglyConnectedComponents, ComponentResult};

// ─── Pathfinding re-exports ───────────────────────────────────────────────────
pub use path::{
    astar, bellman_ford, bellman_ford_path, floyd_warshall, all_pairs_dijkstra, has_negative_cycle,
};
pub use shortest_path::{
    dijkstra, all_shortest_paths, single_source_all_shortest_paths,
    k_shortest_paths, distance_matrix,
};

// ─── Spanning tree re-exports ─────────────────────────────────────────────────
pub use spanning_tree::{
    minimum_spanning_tree_kruskal, maximum_spanning_tree_kruskal, minimum_spanning_tree_prim,
};

// ─── DAG re-exports ───────────────────────────────────────────────────────────
pub use dag::{
    topological_sort, topological_sort_dfs, is_dag, find_cycles,
    dag_longest_path, dag_longest_path_length, dag_longest_path_weighted,
    transitive_closure, transitive_reduction, lexicographical_topological_sort, dag_layers,
    collect_runs, collect_bicolor_runs,
};

// ─── Flow re-exports ──────────────────────────────────────────────────────────
pub use flow::{edmonds_karp, min_cut, FlowResult, CutResult};

// ─── Coloring re-exports ──────────────────────────────────────────────────────
pub use coloring::{
    greedy_node_color, greedy_node_color_ordered, greedy_edge_color,
    is_valid_node_coloring, is_valid_edge_coloring, chromatic_number_approx, NodeOrder,
    two_color, misra_gries_edge_color, is_valid_misra_gries_coloring,
    bipartite_edge_color, bipartite_edge_color_given_partition, is_valid_bipartite_edge_coloring,
};

// ─── Matching re-exports ──────────────────────────────────────────────────────
pub use matching::{
    max_weight_matching, max_cardinality_matching,
    is_matching, is_perfect_matching, is_maximal_matching, Matching,
};

// ─── Connectivity re-exports ──────────────────────────────────────────────────
pub use connectivity::{
    articulation_points, bridges, core_number, cycle_basis,
    johnson_simple_cycles, stoer_wagner_min_cut, isolates, all_simple_paths,
    number_connected_components, node_connected_component,
    chain_decomposition, find_cycle,
    is_connected, is_strongly_connected, is_weakly_connected, is_bipartite,
    number_strongly_connected_components, number_weakly_connected_components,
    has_path, biconnected_components,
    is_tree, is_forest,
    all_pairs_all_simple_paths,
};

// ─── Traversal re-exports ─────────────────────────────────────────────────────
pub use traversal::{
    bfs_layers, dfs_edges, ancestors, descendants,
    bfs_successors, bfs_predecessors, DfsEdge, DfsEdgeType,
    Control, bfs_search, dfs_search, dijkstra_search,
};

// ─── Transitivity re-exports ─────────────────────────────────────────────────
pub use transitivity::{
    graph_transitivity, graph_node_triangles, clustering_coefficient, average_clustering,
};

// ─── Line graph re-exports ────────────────────────────────────────────────────
pub use line_graph::{line_graph, LineGraphResult};

// ─── Planar re-exports ────────────────────────────────────────────────────────
pub use planar::is_planar;

// ─── Generator re-exports ─────────────────────────────────────────────────────
pub use generators::{
    complete_graph, cycle_graph, path_graph, star_graph, grid_graph,
    petersen_graph, barbell_graph, random_graph, full_rary_tree, karate_club,
    lollipop_graph, barabasi_albert_graph, gnm_random_graph, random_bipartite_graph,
    random_regular_graph, hexagonal_lattice_graph, heavy_hex_graph, heavy_square_graph,
    binomial_tree_graph, generalized_petersen_graph,
    watts_strogatz_graph, configuration_model, expected_degree_graph,
};

// ─── Euler re-exports ─────────────────────────────────────────────────────────
pub use euler::{has_euler_circuit, has_euler_path, euler_circuit, euler_path};

// ─── Contraction re-exports ───────────────────────────────────────────────────
pub use contraction::{
    contract_nodes, contract_edge, has_parallel_edges, quotient_graph, ContractionResult,
};

// ─── Steiner tree re-exports ──────────────────────────────────────────────────
pub use steiner_tree::{metric_closure, steiner_tree, MetricClosure};

// ─── Token swapper re-exports ─────────────────────────────────────────────────
pub use token_swapper::{token_swapper, Swap, TokenSwapResult};

// ─── Graph operations re-exports ──────────────────────────────────────────────
pub use graph_ops::{
    complement, graph_union, UnionResult,
    tensor_product, cartesian_product,
    strong_product, lexicographic_product, graph_power,
    adjacency_matrix, bfs_distance_matrix,
};

// ─── Dominance re-exports ─────────────────────────────────────────────────────
pub use dominance::{immediate_dominators, dominance_frontiers};

// ─── Layout re-exports ────────────────────────────────────────────────────────
pub use layout::{
    Layout, random_layout, circular_layout, shell_layout, spiral_layout,
    bipartite_layout, spring_layout, kamada_kawai_layout, spectral_layout,
    sfdp_layout, hierarchical_layout,
    rescale_layout,
};

// ─── Isomorphism re-exports ───────────────────────────────────────────────────
pub use isomorphism::{
    is_isomorphic, vf2_mapping, vf2_all_mappings,
    is_subgraph_isomorphic, subgraph_vf2_mapping,
};

// ─── Flow (extended) re-exports ───────────────────────────────────────────────
pub use flow::MinCostFlowResult;
pub use flow::min_cost_flow;

// ─── Distance (extended) re-exports ──────────────────────────────────────────
pub use distance::{unweighted_average_shortest_path_length, longest_simple_path};

// ─── Clique re-exports ────────────────────────────────────────────────────────
pub use clique::{
    find_cliques, max_clique, clique_number, graph_clique_number,
    cliques_containing_node, node_clique_number,
};

// ─── Community re-exports ─────────────────────────────────────────────────────
pub use community::{
    louvain, label_propagation, girvan_newman, modularity, CommunityResult,
};
