//! Pure Rust implementation inspired by NetworKit's high-performance graph library.
//!
//! This module provides a NetworKit-style graph backend written in pure Rust,
//! combining NetworKit's proven design patterns with Rust's safety guarantees.

pub(crate) mod graph;
mod backend;
pub mod algorithms;
mod native_algorithms;
mod algorithm_engine_impl;

pub use graph::{Graph, GraphConfig, NodeId, EdgeId, Weight, Neighbor};
pub use backend::NetworKitRustBackend;
pub use algorithms::{
    BFS, Dijkstra, BidirectionalDijkstra, APSP, diameter, eccentricity,
    DegreeCentrality, BetweennessCentrality, ClosenessCentrality, PageRank,
    ConnectedComponents, StronglyConnectedComponents,
    CentralityResult, ComponentResult,
};
