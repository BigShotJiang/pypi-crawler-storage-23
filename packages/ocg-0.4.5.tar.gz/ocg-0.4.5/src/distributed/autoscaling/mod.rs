//! Dynamic partition rebalancing and Prometheus metrics.
//!
//! Monitors partition sizes and query rates, then triggers partition splits
//! or merges when load becomes imbalanced across pods.

pub mod metrics;
pub mod rebalancer;

pub use metrics::PartitionMetricsSnapshot;
pub use rebalancer::{RebalanceAction, Rebalancer, RebalancerConfig};
