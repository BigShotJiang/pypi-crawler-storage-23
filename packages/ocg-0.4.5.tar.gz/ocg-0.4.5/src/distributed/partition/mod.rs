//! Graph partitioning module.
//!
//! This module provides partitioning strategies for distributing graph data
//! across multiple nodes while maintaining backward compatibility with
//! single-instance mode.

pub mod etcd_retry;
pub mod fencing;
pub mod id;
pub mod location_service;
pub mod metadata;
pub mod partitioner;
pub mod hash;
pub mod range;

pub use id::{PartitionedId, PartitionIdAllocator, MAX_PARTITIONS, MAX_LOCAL_ID};
pub use metadata::{PartitionMap, PartitionMetadata, PartitionQualityMetrics};
pub use partitioner::{GraphPartitioner, PartitionConfig};
pub use hash::HashPartitioner;
pub use fencing::FencingToken;
pub use location_service::{PartitionLocation, PartitionLocationService, PartitionStatus};
pub use range::RangePartitioner;
