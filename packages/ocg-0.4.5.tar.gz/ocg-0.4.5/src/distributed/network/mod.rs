//! Distributed network layer for Arrow Flight RPC.
//!
//! This module provides zero-copy data transfer between graph partitions
//! using the Apache Arrow Flight protocol.

pub mod conversions;

#[cfg(feature = "distributed")]
pub mod flight_client;

#[cfg(feature = "distributed")]
pub mod flight_server;

#[cfg(feature = "distributed")]
pub mod superstep;

pub use conversions::{nodes_to_record_batch, edges_to_record_batch};

#[cfg(feature = "distributed")]
pub use flight_client::GraphFlightClient;

#[cfg(feature = "distributed")]
pub use flight_server::GraphFlightService;

#[cfg(feature = "distributed")]
pub use superstep::{BspCoordinator, BspAlgorithm, SuperstepRequest, SuperstepResponse, VertexMessage};
