import sys
from argparse import SUPPRESS, ArgumentParser, Namespace
from typing import Any, NoReturn

from codespeak_shared.exceptions import CodespeakUserError, InvalidCommandLineParameterUserError
from codespeak_shared.utils.lenient_namespace import LenientNamespace


class _ArgumentParserWithHelp(ArgumentParser):
    def error(self, message: str) -> NoReturn:
        sys.stderr.write(f"{message}\n")
        sys.stderr.write("\n")
        self.print_help()
        sys.exit(CodespeakUserError.EXIT_CODE)


def _add_spec_param(parser: ArgumentParser) -> None:
    parser.add_argument(
        "--spec",
        help="path to the specification file to build; if omitted, all registered specification files will be built",
        default=None,
    )


def add_common_params(parser: ArgumentParser) -> None:
    parser.add_argument("--enable-flag", action="append", help=SUPPRESS)
    parser.add_argument("--disable-flag", action="append", help=SUPPRESS)


def _add_build_params(parser: ArgumentParser) -> None:
    add_common_params(parser)
    parser.add_argument("--start", help=SUPPRESS)
    parser.add_argument("--until", help=SUPPRESS)
    parser.add_argument("--dry-run", action="store_true", help=SUPPRESS)
    parser.add_argument(
        "--no-diff-check",
        action="store_true",
        help=SUPPRESS,
    )
    parser.add_argument(
        "--no-interactive",
        action="store_true",
        default=None,
        help="run in non-interactive mode without real-time progress updates",
    )
    parser.add_argument(
        "--disable-parallelism",
        action="store_true",
        help=SUPPRESS,
    )
    _add_spec_param(parser)

    resume_control_group = parser.add_mutually_exclusive_group()
    resume_control_group.add_argument(
        "--clean",
        action="store_true",
        help=SUPPRESS,
    )
    resume_control_group.add_argument(
        "--retry",
        action="store_true",
        help=SUPPRESS,
    )
    parser.add_argument(
        "--skip-tests",
        action="store_true",
        help="Skip improving test coverage",
    )


def _add_init_params(parser: ArgumentParser) -> None:
    add_common_params(parser)
    parser.add_argument("--profile", help="configuration profile to use for initialization")
    parser.add_argument("--project-name", default=None, help="custom name for the project (defaults to directory name)")
    parser.add_argument(
        "--mixed",
        action="store_true",
        help="enable mixed mode, allowing both CodeSpeak spec-driven code and manually written code to coexist",
        default=False,
    )
    parser.add_argument(
        "--ignore-enclosing-project-check",
        default=False,
        action="store_true",
        help=SUPPRESS,
    )


def create_codespeak_parser(version: str) -> tuple[ArgumentParser, Any]:
    parser = _ArgumentParserWithHelp(description="CodeSpeak build system")
    parser.prog = "codespeak"
    parser.add_argument("--version", action="version", version=version)
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser(
        "init",
        help="initialize a new CodeSpeak project",
        description="Initialize a new CodeSpeak project in the current directory. This creates the necessary configuration files and project structure.",
    )
    _add_init_params(init_parser)

    build_parser = subparsers.add_parser(
        "build",
        help="run build",
        description="Build your project according to the specification file(s). CodeSpeak will generate or update code to match the spec.",
    )
    _add_build_params(build_parser)

    run_parser = subparsers.add_parser(
        "run",
        help="build and run the target application",
        description="Build and run target application.",
    )
    _add_build_params(run_parser)

    implement_change_request_parser = subparsers.add_parser(
        "change",
        help="code change request",
        description="Request a code change to an existing project. Use --new to create a change request file, or -m to specify the change directly.",
    )
    _add_build_params(implement_change_request_parser)
    implement_change_request_parser.add_argument(
        "--new",
        action="store_true",
        default=False,
        help="create an empty change request file for further manual editing; after editing, implement the change request with 'codespeak change'",
    )
    implement_change_request_parser.add_argument("-m", "--message", help="implement a given change request")

    takeover_parser = subparsers.add_parser(
        "takeover",
        help="extract a specification from existing code",
        description="Extract a specification from existing code at the given paths.",
    )
    add_common_params(takeover_parser)
    takeover_parser.add_argument(
        "paths",
        nargs="+",
        help="paths (files or folders) to extract specification from",
    )
    takeover_parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="output file path for the specification (relative to project root or absolute, must be under project root)",
    )
    takeover_parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        default=False,
        help="overwrite existing specification file if it exists",
    )

    task_parser = subparsers.add_parser(
        "task",
        help="execute a task with given name",
        description="Execute a task with given name.",
    )
    add_common_params(task_parser)
    _add_spec_param(task_parser)
    task_parser.add_argument("task_name")

    whitelist_parser = subparsers.add_parser(
        "whitelist",
        help="add files or glob patterns to the whitelist of managed files",
        description="Add file paths or glob patterns to the whitelist in codespeak.json. Whitelisted files can always be modified in mixed mode.",
    )
    add_common_params(whitelist_parser)
    whitelist_parser.add_argument(
        "patterns",
        nargs="+",
        help="file paths or glob patterns to whitelist (e.g. config.toml 'src/*.py' '**/*.go')",
    )

    coverage_parser = subparsers.add_parser(
        "coverage",
        help="improve test coverage",
        description="Improve test coverage in existing project.",
    )
    _add_build_params(coverage_parser)
    coverage_parser.add_argument(
        "--auto-configure",
        action="store_true",
        default=False,
        help="auto-detect and configure the test runner command for a spec (mutually exclusive with --target and --max-iterations)",
    )
    coverage_parser.add_argument(
        "--target",
        type=int,
        default=None,
        help="target coverage percentage (e.g. 100)",
    )
    coverage_parser.add_argument(
        "--max-iterations",
        type=int,
        default=None,
        help="maximum number of coverage improvement iterations",
    )

    managed_files_parser = subparsers.add_parser(
        "update-managed-files",
        help="update files managed by spec",
        description="Adds given files to the list of managed ones for the given spec. "
        + "By default, adds the violations of managed files recorded in the last run to the respective spec",
    )
    managed_files_parser.add_argument(
        "paths",
        nargs="*",
        help="paths (files or folders) to add managed files. Defaults to list of violations recorded in the last run",
    )
    _add_spec_param(managed_files_parser)

    return parser, subparsers


def parse_codespeak_args(parser: ArgumentParser) -> LenientNamespace:
    return parser.parse_args(namespace=LenientNamespace())


def validate_coverage_args(args: Namespace) -> None:
    if args.auto_configure:
        if args.target is not None or args.max_iterations is not None:
            raise InvalidCommandLineParameterUserError(
                "--auto-configure is mutually exclusive with --target and --max-iterations"
            )
    else:
        if args.target is None:
            raise InvalidCommandLineParameterUserError("--target is required (unless using --auto-configure)")
        if args.max_iterations is None:
            raise InvalidCommandLineParameterUserError("--max-iterations is required (unless using --auto-configure)")
        if not (0 < args.target <= 100):
            raise InvalidCommandLineParameterUserError("--target must be between 1 and 100")
        if not (0 < args.max_iterations <= 30):
            raise InvalidCommandLineParameterUserError("--max-iterations must be between 1 and 30")
