"""
QuarterBit CLI entry point.

Usage:
    quarterbit login           - Login via browser
    quarterbit activate <KEY>  - Activate license key
    quarterbit deactivate      - Remove license
    quarterbit status          - Show license info
"""

from .license import main

if __name__ == "__main__":
    main()
