# models-dev

Typed Python package for [models.dev](https://models.dev) data. Access 2000+ LLM models from 75+ providers with full typing support. No HTTP calls - data is bundled and auto-updated hourly.

See [GitHub](https://github.com/vklimontovich/models-dev) for documentation and examples.
