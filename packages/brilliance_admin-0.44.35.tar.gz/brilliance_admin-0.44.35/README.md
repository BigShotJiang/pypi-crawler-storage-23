<div align="center">
  <img src="https://github.com/brilliance-admin/backend-python/blob/main/example/static/logo-outline.png?raw=true"
       alt="Brilliance Admin"
       width="600">

[![PyPI](https://img.shields.io/pypi/v/brilliance-admin)](https://pypi.org/project/brilliance-admin/)
[![CI](https://github.com/brilliance-admin/backend-python/actions/workflows/deploy.yml/badge.svg)](https://github.com/brilliance-admin/backend-python/actions)

Simple and lightweight data management framework powered by `FastAPI` and `Vue3` `Vuetify` all-in-one. \
Integrated with `SQLAlchemy`. Inspaired by Django Admin and DRF.\
_Some call it heavenly in its brilliance._

### [Live Demo](https://brilliance-admin.com/) | [Demo Sources](https://github.com/brilliance-admin/backend-python/tree/main/example) | [Schowcase + Documentation](https://docs.brilliance-admin.com/)

Old repo: https://github.com/Innova-Group-LLC/custom_admin

  <img src="https://raw.githubusercontent.com/brilliance-admin/.github/refs/heads/main/screenshots/04.02.2026/all-devices-black.png"
       alt="Preview">

  <sub>Every ⭐ - helps to make it even more brilliant!</sub>
</div>

> [!TIP]
> If you found a bug or have a feature request, feel free to open an issue.

> [!WARNING]
>Not production ready, work in progress.

Full documentation including project overview, getting started guide, configuration reference, API examples, and component usage is available inside [Documentation](https://docs.brilliance-admin.com/) (GitHub Pages hosted)
