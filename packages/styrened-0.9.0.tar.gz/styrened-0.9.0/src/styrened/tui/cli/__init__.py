"""CLI tools for testing Styrene functionality without the TUI."""
