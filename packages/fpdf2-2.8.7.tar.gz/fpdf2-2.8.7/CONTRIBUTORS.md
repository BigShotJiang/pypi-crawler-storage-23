The list of contributors has been moved into the [README.md](README.md#contributors-).
