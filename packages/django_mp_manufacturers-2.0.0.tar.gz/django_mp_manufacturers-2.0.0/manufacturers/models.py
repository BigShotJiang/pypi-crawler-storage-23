from django.db import models
from django.utils.translation import gettext_lazy as _


class Manufacturer(models.Model):

    name = models.CharField(
        _('Manufacturer name'),
        max_length=255,
        unique=True,
        db_index=True)

    logo = models.ImageField(
        _('Logo'),
        max_length=255,
        blank=True,
        null=True,
        upload_to='manufacturers')

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']
        verbose_name = _('Manufacturer')
        verbose_name_plural = _('Manufacturers')
