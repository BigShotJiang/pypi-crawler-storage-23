# MP-manufacturers

Django manufacturers app.

### Installation

Install with pip:

```
pip install django-mp-manufacturers
```

settings.py
```
INSTALLED_APPS = [
    ...,
    'manufacturers',
]
```
