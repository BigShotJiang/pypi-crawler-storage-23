"""Adapter registry and discovery."""
