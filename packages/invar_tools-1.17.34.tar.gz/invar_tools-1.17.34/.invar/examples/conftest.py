# Skip pytest collection for example files
# These are reference examples, not tests.
collect_ignore = ["contracts.py", "core_shell.py", "functional.py", "workflow.md"]
