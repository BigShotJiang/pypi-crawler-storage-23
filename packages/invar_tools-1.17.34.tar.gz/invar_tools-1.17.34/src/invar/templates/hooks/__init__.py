# Invar Claude Code hook templates (DX-57)
