"""Template files for invar init command."""
