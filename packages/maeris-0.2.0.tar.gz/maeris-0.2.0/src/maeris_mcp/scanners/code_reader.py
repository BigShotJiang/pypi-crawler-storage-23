"""Code reader for LLM-guided security analysis."""

import os
from pathlib import Path

# SKIPLIST APPROACH: Scan all files EXCEPT those in the skip lists below.
# This ensures we don't miss unusual config files or framework-specific extensions.

# File extensions to SKIP (binary files, media, compiled/generated output)
SKIP_EXTENSIONS = {
    # Binary executables & libraries
    ".exe", ".dll", ".so", ".dylib", ".a", ".lib", ".bin", ".app",
    # Compiled code
    ".pyc", ".pyo", ".pyd", ".o", ".obj", ".class", ".jar", ".war", ".ear",
    # Archives & compressed files
    ".zip", ".tar", ".gz", ".bz2", ".xz", ".7z", ".rar", ".iso", ".dmg",
    # Images
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".ico", ".webp", ".tiff", ".psd",
    # Video & audio
    ".mp4", ".avi", ".mov", ".wmv", ".flv", ".mkv", ".webm",
    ".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a",
    # Fonts
    ".ttf", ".otf", ".woff", ".woff2", ".eot",
    # Documents (typically not source code)
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    # Database files
    ".db", ".sqlite", ".sqlite3", ".mdb",
    # Minified/bundled output (too large, not source)
    ".min.js", ".min.css", ".bundle.js", ".chunk.js",
    # Maps
    ".map", ".js.map", ".css.map",
    # Lockfiles for package managers (scanned separately by dep_scanner)
    # We keep package.json but skip large lockfiles since dep_scanner handles them
    ".lock",  # General lockfiles - be careful, this might be too broad
}

# Directories to skip
SKIP_DIRS = {
    "node_modules", "venv", ".venv", "env", "__pycache__",
    ".git", ".svn", ".hg", "dist", "build", ".next", "coverage",
    ".tox", ".mypy_cache", ".pytest_cache", "eggs", ".eggs",
    "vendor", "third_party", "external", ".gradle", "target",
}

# Sensitive file patterns to NEVER read (simple substring/suffix checks)
SENSITIVE_SUBSTRINGS = [
    ".env", ".envrc", "config.local", "settings.local", "local_settings",
    "credentials", "secrets", ".secret", "password", "api_key", "api-key",
    "auth_token", "auth-token", "aws_credentials", ".aws/", "gcloud",
    "service_account", "database.yml", "db.json", "docker-compose.override",
]

SENSITIVE_SUFFIXES = [
    ".pem", ".key", ".p12", ".pfx", ".jks",
    "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519",
    ".htpasswd", "shadow", "passwd", "known_hosts", "authorized_keys",
]

MAX_FILE_SIZE = 100 * 1024  # 100KB


def is_sensitive_file(file_path: Path) -> bool:
    """Check if a file path matches sensitive patterns."""
    path_str = str(file_path).lower()
    name = file_path.name.lower()
    for token in SENSITIVE_SUBSTRINGS:
        if token in path_str or token in name:
            return True
    for suffix in SENSITIVE_SUFFIXES:
        if name.endswith(suffix) or path_str.endswith(suffix):
            return True
    return False


def _is_candidate_file(file_path: Path) -> bool:
    """Return True if a file should be included in the scan (skiplist approach)."""
    name = file_path.name.lower()
    suffix = file_path.suffix.lower()

    # Skip binary/media/generated file extensions
    if suffix in SKIP_EXTENSIONS:
        return False

    # Skip minified files (special case for double extensions like .min.js)
    if ".min." in name or ".bundle." in name or ".chunk." in name:
        return False

    # Skip lockfiles - they're handled by dep_scanner
    if name in {"package-lock.json", "yarn.lock", "pnpm-lock.yaml", "poetry.lock",
                "gemfile.lock", "cargo.lock", "go.sum", "composer.lock", "mix.lock"}:
        return False

    # Accept everything else (text-based files, source code, config, etc.)
    return True


def collect_scan_files(target_path: str) -> tuple[list[str], list[str]]:
    """
    Collect files for LLM-guided security analysis.
    Returns:
        - files: list of absolute file paths
        - info: list of info/error messages
    """
    files: list[str] = []
    info: list[str] = []
    skipped_sensitive = 0
    skipped_large = 0

    path = Path(target_path)

    if not path.exists():
        info.append(f"Path does not exist: {target_path}")
        return files, info

    def _maybe_add_file(file_path: Path) -> None:
        nonlocal skipped_sensitive, skipped_large
        if is_sensitive_file(file_path):
            skipped_sensitive += 1
            return
        if file_path.is_file():
            try:
                if file_path.stat().st_size > MAX_FILE_SIZE:
                    skipped_large += 1
                    return
            except Exception:
                return
            files.append(str(file_path))

    if path.is_file():
        _maybe_add_file(path)
    else:
        for root, dirs, filenames in os.walk(path):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]

            for filename in filenames:
                file_path = Path(root) / filename
                if not _is_candidate_file(file_path):
                    continue
                _maybe_add_file(file_path)

    if skipped_sensitive > 0:
        info.append(f"Skipped {skipped_sensitive} sensitive file(s)")
    if skipped_large > 0:
        info.append(f"Skipped {skipped_large} large file(s) > {MAX_FILE_SIZE} bytes")

    info.append(f"Collected {len(files)} files for analysis")

    files = sorted(set(files))
    return files, info


def get_file_contents(file_paths: list[str]) -> dict[str, str]:
    """
    Read contents of specific files.
    Use this after collect_scan_files to get content only for files you need.

    Returns:
        Dict mapping file path to content (empty string if read failed)
    """
    contents: dict[str, str] = {}
    for file_path in file_paths:
        path = Path(file_path)
        if path.exists() and not is_sensitive_file(path):
            content = _read_file_content(path)
            contents[file_path] = content if content else ""
    return contents


def _read_file_content(path: Path) -> str | None:
    """Read file content, return None on error."""
    try:
        size = path.stat().st_size
        if size > MAX_FILE_SIZE:
            return None
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return None


# Legacy function for backwards compatibility
