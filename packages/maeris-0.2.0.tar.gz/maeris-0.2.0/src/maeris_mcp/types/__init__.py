"""Type definitions for the Maeris MCP server."""

from maeris_mcp.types.api import (
    APICallSite,
    APISummary,
    AuthDefinition,
    AuthType,
    ExtractedAPI,
    ExtractedAPICollection,
    HeaderDefinition,
    HTTPMethod,
    PathParam,
    PayloadDefinition,
    PayloadField,
    QueryParam,
    StoredAPIList,
)
from maeris_mcp.types.protocol import (
    AnalysisResult,
    DocumentationResult,
    ExtractionInstructions,
    MatchContext,
    OperationType,
    ProcessingResponse,
    SchemaResponse,
    SearchMatch,
    SearchResult,
)

__all__ = [
    # API types
    "HTTPMethod",
    "AuthType",
    "HeaderDefinition",
    "PayloadField",
    "PayloadDefinition",
    "AuthDefinition",
    "QueryParam",
    "PathParam",
    "APICallSite",
    "ExtractedAPI",
    "ExtractedAPICollection",
    "APISummary",
    "StoredAPIList",
    # Protocol types
    "OperationType",
    "SchemaResponse",
    "ExtractionInstructions",
    "ProcessingResponse",
    "AnalysisResult",
    "DocumentationResult",
    "SearchResult",
    "SearchMatch",
    "MatchContext",
]
