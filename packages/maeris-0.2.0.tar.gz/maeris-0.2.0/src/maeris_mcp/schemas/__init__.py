"""Schema definitions and registry for extraction operations."""
