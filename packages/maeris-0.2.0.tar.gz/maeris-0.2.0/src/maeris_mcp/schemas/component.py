"""React component extraction schema."""

from maeris_mcp.schemas.registry import Schema
from maeris_mcp.types.protocol import ExtractionInstructions, OperationType


def component_extraction_schema() -> Schema:
    """Return the JSON schema for React component extraction."""
    return Schema(
        id="react-component-v1",
        name="React Component Extraction",
        description="Schema for extracting React component structure and metadata",
        applicable_operations=[
            OperationType.ANALYZE_COMPONENT,
            OperationType.GENERATE_DOCS,
        ],
        json_schema={
            "$schema": "http://json-schema.org/draft-07/schema#",
            "title": "ReactComponentExtraction",
            "description": "Structured data extracted from a React component",
            "type": "object",
            "required": ["componentName", "filePath", "exportType", "componentType"],
            "properties": {
                "componentName": {
                    "type": "string",
                    "description": "Name of the React component",
                },
                "filePath": {
                    "type": "string",
                    "description": "Relative file path from project root",
                },
                "exportType": {
                    "type": "string",
                    "enum": ["default", "named", "both"],
                    "description": "How the component is exported",
                },
                "componentType": {
                    "type": "string",
                    "enum": ["functional", "class", "forwardRef", "memo", "hoc"],
                    "description": "Type of React component",
                },
                "propsInterfaceName": {
                    "type": "string",
                    "description": "Name of the props interface or type",
                },
                "props": {
                    "type": "array",
                    "description": "Component props definitions",
                    "items": {
                        "type": "object",
                        "required": ["name", "type", "required"],
                        "properties": {
                            "name": {"type": "string", "description": "Prop name"},
                            "type": {"type": "string", "description": "TypeScript type as string"},
                            "required": {"type": "boolean", "description": "Whether the prop is required"},
                            "defaultValue": {"type": "string", "description": "Default value if specified"},
                            "description": {"type": "string", "description": "JSDoc description"},
                        },
                    },
                },
                "localState": {
                    "type": "array",
                    "description": "Local state variables (useState, useReducer)",
                    "items": {
                        "type": "object",
                        "required": ["name", "type"],
                        "properties": {
                            "name": {"type": "string", "description": "State variable name"},
                            "type": {"type": "string", "description": "Type of the state"},
                            "initialValue": {"type": "string", "description": "Initial value expression (not the actual value)"},
                            "setter": {"type": "string", "description": "Setter function name"},
                        },
                    },
                },
                "hooks": {
                    "type": "array",
                    "description": "Hooks used in the component",
                    "items": {
                        "type": "object",
                        "required": ["hookName", "isCustom"],
                        "properties": {
                            "hookName": {"type": "string", "description": "Name of the hook (e.g., useState, useEffect, useMyCustomHook)"},
                            "isCustom": {"type": "boolean", "description": "Whether this is a custom hook"},
                            "arguments": {"type": "array", "items": {"type": "string"}, "description": "Brief description of arguments (not actual code)"},
                            "returnValue": {"type": "string", "description": "What the hook returns (type description)"},
                            "dependencies": {"type": "array", "items": {"type": "string"}, "description": "Dependency array variable names"},
                        },
                    },
                },
                "childComponents": {
                    "type": "array",
                    "description": "Child components rendered by this component",
                    "items": {
                        "type": "object",
                        "required": ["name", "isConditional"],
                        "properties": {
                            "name": {"type": "string", "description": "Child component name"},
                            "importPath": {"type": "string", "description": "Import path"},
                            "isConditional": {"type": "boolean", "description": "Whether rendering is conditional"},
                        },
                    },
                },
                "imports": {
                    "type": "array",
                    "description": "Import statements",
                    "items": {
                        "type": "object",
                        "required": ["source", "specifiers"],
                        "properties": {
                            "source": {"type": "string", "description": "Import source path"},
                            "specifiers": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "required": ["name", "isDefault"],
                                    "properties": {
                                        "name": {"type": "string", "description": "Imported name"},
                                        "alias": {"type": "string", "description": "Alias if renamed"},
                                        "isDefault": {"type": "boolean", "description": "Whether default import"},
                                    },
                                },
                            },
                        },
                    },
                },
                "patterns": {
                    "type": "array",
                    "description": "Detected React patterns",
                    "items": {
                        "type": "string",
                        "enum": [
                            "compound-component",
                            "render-props",
                            "higher-order-component",
                            "custom-hook",
                            "context-provider",
                            "controlled-component",
                            "uncontrolled-component",
                            "container-presentational",
                        ],
                    },
                },
                "jsdocComment": {"type": "string", "description": "JSDoc comment for the component"},
                "lineCount": {"type": "integer", "description": "Number of lines in the component file"},
                "complexity": {"type": "string", "enum": ["low", "medium", "high"], "description": "Estimated complexity level"},
            },
        },
        instructions=ExtractionInstructions(
            overview="Extract structured information about a React component without including any raw source code.",
            steps=[
                "1. Identify the component name and how it's exported",
                "2. Determine the component type (functional, class, memo, forwardRef, HOC)",
                "3. Extract prop definitions from the props interface/type",
                "4. Identify useState/useReducer calls for local state",
                "5. List all hooks used with their purposes (not implementations)",
                "6. Identify child components rendered in JSX",
                "7. List import statements",
                "8. Detect any React patterns being used",
            ],
            field_guidance={
                "props": "List prop names, types, and whether required. Do NOT include default value implementations.",
                "hooks": "List hook names and what they're used for. Do NOT include callback implementations.",
                "childComponents": "List component names rendered in JSX. Note if rendering is conditional.",
                "patterns": "Identify architectural patterns like render-props, compound components, etc.",
            },
            privacy_notes=[
                "NEVER include actual source code in any field",
                "For types, use TypeScript type notation (e.g., 'string', 'number', 'User[]')",
                "For default values, describe what it is (e.g., 'empty array', 'null') not the code",
                "For hook arguments, describe the purpose not the implementation",
            ],
        ),
    )
