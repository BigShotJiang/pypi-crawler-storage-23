"""Entry point for running the package with python -m maeris_mcp."""

from maeris_mcp.main import main

if __name__ == "__main__":
    main()
