"""LLM-guided security scanning tools for MCP server."""

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from mcp.types import TextContent, Tool

from maeris_mcp.scanners.code_reader import collect_scan_files, get_file_contents
from maeris_mcp.scanners.dep_scanner import scan_dependencies
from maeris_mcp.scanners.security_checks import get_checks_and_profiles
from maeris_mcp.storage.security_store import SecurityScanStore
from maeris_mcp.types.security import (
    Confidence,
    OWASPCategory,
    ScanSummary,
    SecurityFinding,
    SecurityScanResult,
    Severity,
    SeverityCounts,
    StoredSecurityScan,
)


def security_scan_tool() -> Tool:
    """Return the tool definition for security_scan."""
    return Tool(
        name="security_scan",
        description=(
            "LLM-guided static security scan. "
            "Fetches file batches and accepts findings in the same call. "
            "Pass findings=[...] alongside offset to submit findings from the previous batch while fetching the next. "
            "Set is_last=true on the final call to finalize the scan and receive the full report. "
            "Call list_security_checks to see available checks/profiles."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "target_path": {
                    "type": "string",
                    "description": "Absolute file or directory path to scan (optional; defaults to server working directory)",
                },
                "scan_id": {
                    "type": "string",
                    "description": "Existing scan session ID to continue/paginate",
                },
                "scan_profile": {
                    "type": "string",
                    "description": "Scan profile to use (default: all_static)",
                },
                "checks": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Explicit check IDs to use (overrides scan_profile)",
                },
                "include_content": {
                    "type": "boolean",
                    "description": "Include file contents for analysis. Default: false",
                    "default": False,
                },
                "offset": {
                    "type": "integer",
                    "description": "Skip first N files when including content. Default: 0",
                    "default": 0,
                },
                "limit": {
                    "type": "integer",
                    "description": "Max files to return content for (1-10). Default: 5",
                    "default": 5,
                },
                "findings": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "Findings from analyzing the previous file batch. Submit alongside the next batch offset.",
                },
                "is_last": {
                    "type": "boolean",
                    "description": "Set true on the final call to finalize the scan and get the full report.",
                },
            },
        },
    )


def list_security_checks_tool() -> Tool:
    """Return the tool definition for list_security_checks."""
    return Tool(
        name="list_security_checks",
        description=(
            "Lists available static-feasible security checks and scan profiles. "
            "Use this to decide which checks to run before calling security_scan."
        ),
        inputSchema={"type": "object", "properties": {}},
    )


def submit_security_findings_tool() -> Tool:
    """Return the tool definition for submit_security_findings (kept for backward compat)."""
    return Tool(
        name="submit_security_findings",
        description=(
            "Submit LLM findings for a scan in batches. "
            "Set is_last=true on the final batch to finalize the scan."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "scan_id": {"type": "string", "description": "Scan session ID"},
                "findings": {"type": "array", "items": {"type": "object"}},
                "is_last": {"type": "boolean", "description": "Finalize when true"},
            },
            "required": ["scan_id", "findings"],
        },
    )


def get_security_scans_tool() -> Tool:
    """Return the tool definition for get_security_scans."""
    return Tool(
        name="get_security_scans",
        description="Retrieves stored security scan results with full findings.",
        inputSchema={
            "type": "object",
            "properties": {
                "scan_id": {
                    "type": "string",
                    "description": "Specific scan ID to retrieve.",
                },
                "last_n": {
                    "type": "integer",
                    "description": "Return the last N scans (most recent first). E.g. last_n=3 for last 3 scans.",
                },
                "nth": {
                    "type": "integer",
                    "description": "Return the Nth most recent scan (1-indexed). 1=last, 2=second last, etc.",
                },
            },
        },
    )


def clear_security_scans_tool() -> Tool:
    """Return the tool definition for clear_security_scans."""
    return Tool(
        name="clear_security_scans",
        description="Clears stored security scans. Can clear all scans or a specific scan by ID.",
        inputSchema={
            "type": "object",
            "properties": {
                "scan_id": {
                    "type": "string",
                    "description": "Optional: specific scan ID to delete. If not provided, clears all.",
                },
            },
        },
    )


def _get_project_paths(target_path: str) -> tuple[Path, str]:
    """Return base for relative paths and display name."""
    path = Path(target_path)
    project_root = path if path.is_dir() else path.parent
    base_for_rel = project_root.parent if project_root.parent != project_root else project_root
    display_name = project_root.name or str(project_root)
    return base_for_rel, display_name


def _expected_output_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {
            "findings": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "id": {"type": "string"},
                        "ruleId": {"type": "string"},
                        "title": {"type": "string"},
                        "description": {"type": "string"},
                        "severity": {
                            "type": "string",
                            "enum": ["low", "medium", "high", "critical"],
                        },
                        "confidence": {
                            "type": "string",
                            "enum": ["low", "medium", "high"],
                        },
                        "owaspCategory": {
                            "type": "string",
                            "enum": [
                                "A01", "A02", "A03", "A04", "A05",
                                "A06", "A07", "A08", "A09", "A10",
                            ],
                        },
                        "cweId": {"type": "string"},
                        "filePath": {"type": "string"},
                        "lineStart": {"type": "integer"},
                        "lineEnd": {"type": "integer"},
                        "codeSnippet": {"type": "string"},
                        "recommendation": {"type": "string"},
                    },
                    "required": ["title", "filePath"],
                },
            },
            "isLast": {"type": "boolean"},
        },
        "required": ["findings"],
    }


def _analysis_instructions() -> str:
    return (
        "LLM-guided scan instructions:\n"
        "1) Call list_security_checks to see available checks/profiles.\n"
        "2) Call security_scan with include_content=true and offset=0 to fetch the first file batch.\n"
        "3) Analyze each file using the security analysis methodology below.\n"
        "4) Call security_scan again with findings=[...from previous batch] and the next offset to submit findings and fetch the next batch.\n"
        "5) Repeat until hasMore=false, then call with findings=[...last batch] and is_last=true to finalize.\n"
        "6) The final response includes the full scan report and all findings.\n"
        "7) After completion, call push_to_maeris with data_type='vulnerabilities' and scan_id to publish the results.\n"
        "Note: MCP does not perform detection; the LLM must analyze and produce findings.\n"
        "\n"
        "=== SECURITY ANALYSIS METHODOLOGY ===\n"
        "You are an expert security auditor. For each file, perform deep analysis using\n"
        "these principles. Do NOT rely only on pattern matching — reason about the code's\n"
        "security implications. Your goal is to find ALL vulnerabilities, including novel\n"
        "ones not covered by textbook examples.\n"
        "\n"
        "STEP 1: IDENTIFY TRUST BOUNDARIES\n"
        "- Where does external/untrusted input enter? (HTTP params, headers, body, cookies,\n"
        "  URL paths, file uploads, env vars, database reads, message queues, webhooks,\n"
        "  third-party API responses, WebSocket messages, CLI arguments)\n"
        "- Where does the code interact with sensitive systems? (databases, file system,\n"
        "  OS commands, network requests, auth systems, crypto operations,\n"
        "  serialization/deserialization, template engines, code evaluation)\n"
        "- What data crosses from untrusted to trusted contexts without validation?\n"
        "\n"
        "STEP 2: TRACE DATA FLOWS (TAINT ANALYSIS)\n"
        "For each source of untrusted input:\n"
        "- Follow the data through the code — is it validated, sanitized, or encoded\n"
        "  before reaching a sensitive sink?\n"
        "- Track direct usage, indirect usage through variables/assignments, and usage\n"
        "  after transformation or string interpolation.\n"
        "- Check if validation is adequate for the SPECIFIC context (e.g., HTML encoding\n"
        "  doesn't prevent SQL injection; URL validation doesn't prevent SSRF to internal IPs).\n"
        "- Consider ALL injection types: SQL, NoSQL, command, LDAP, XSS, SSTI, header,\n"
        "  XPath, code injection, deserialization — wherever untrusted data meets an interpreter.\n"
        "\n"
        "STEP 3: CHECK FOR MISSING SECURITY CONTROLS\n"
        "Vulnerabilities are often about what's ABSENT, not just what's present:\n"
        "- Missing authentication on routes that access or modify data\n"
        "- Missing authorization checks (ownership verification, role enforcement, tenant isolation)\n"
        "- Missing input validation before sensitive operations\n"
        "- Missing output encoding/escaping for the output context\n"
        "- Missing security headers in server/framework configuration\n"
        "- Missing rate limiting on authentication or sensitive endpoints\n"
        "- Missing encryption for sensitive data at rest or in transit\n"
        "- Sensitive fields (passwords, tokens, internal IDs) not excluded from API responses\n"
        "- Missing CSRF protection on state-changing endpoints\n"
        "- Missing session invalidation on logout or privilege change\n"
        "\n"
        "STEP 4: EVALUATE CRYPTOGRAPHIC & SECRET MANAGEMENT\n"
        "- Hardcoded secrets, API keys, database credentials, or fallback/default values in source\n"
        "- Weak hashing algorithms used for security purposes (passwords, tokens, signatures)\n"
        "- JWT configuration: algorithm restrictions, secret strength, claim validation (exp, iss, aud)\n"
        "- Cookie security attributes: Secure, HttpOnly, SameSite\n"
        "- Key/certificate management: key length, rotation, storage\n"
        "- Protocol choices: TLS version requirements, cipher suite selection\n"
        "\n"
        "STEP 5: ASSESS CONFIGURATION SECURITY\n"
        "- Framework/server config files for security-relevant settings\n"
        "- CORS policies, CSP directives, security response headers\n"
        "- Debug/development flags that should be disabled in production\n"
        "- Information disclosure through headers, error responses, or verbose logging\n"
        "- Infrastructure-as-code: IAM policies, storage ACLs, network rules, container privileges\n"
        "\n"
        "STEP 6: EVALUATE DEPENDENCY RISK\n"
        "- Flag packages you know to have CVEs at the specified version\n"
        "- Flag packages with inherently dangerous capabilities (serialization, code execution,\n"
        "  template compilation) especially when used with untrusted input\n"
        "- Flag significantly outdated major versions that likely lack security patches\n"
        "\n"
        "STEP 7: CONSIDER FRAMEWORK & ARCHITECTURAL RISKS\n"
        "- Identify the framework from file structure and imports, then apply\n"
        "  framework-specific security knowledge\n"
        "- Check that framework-specific security features are properly used\n"
        "- Look for architectural issues: improper separation of client/server code,\n"
        "  trust placed in client-side controls, missing middleware in request pipeline\n"
        "- Consider business logic flaws: race conditions, workflow bypass, privilege\n"
        "  escalation through parameter manipulation\n"
        "\n"
        "=== ANALYSIS PRINCIPLES ===\n"
        "1. THINK LIKE AN ATTACKER: For each file, ask 'How could an attacker abuse this?'\n"
        "   Consider both the obvious and the subtle.\n"
        "2. CONTEXT MATTERS: A function is only vulnerable if untrusted data can reach it.\n"
        "   Trace the actual data flow — don't just flag API names in isolation.\n"
        "3. DEFENSE IN DEPTH: A missing security layer is a finding even if other layers exist.\n"
        "4. LOOK BEYOND KNOWN PATTERNS: Use your full security expertise to identify novel\n"
        "   risks, emerging vulnerability classes, and architectural weaknesses — not just\n"
        "   textbook examples. The check catalog is a starting point, not a ceiling.\n"
        "5. CLASSIFY BY OWASP: Map each finding to the most relevant OWASP Top 10 category\n"
        "   (A01-A10) and include the CWE ID when applicable.\n"
        "6. BE THOROUGH, NOT NOISY: Only report issues with genuine security impact.\n"
        "   Explain WHY it's dangerous and HOW it could be exploited.\n"
        "\n"
        "=== OUTPUT REQUIREMENTS ===\n"
        "- Analyze EVERY file thoroughly. Do not skip files or rush through batches.\n"
        "- For each finding, provide: exact file path, line number(s), code snippet,\n"
        "  severity, OWASP category, and a specific remediation recommendation.\n"
        "- Check config/manifest files for security misconfigurations, not just code files.\n"
        "- When unsure about severity, consider the worst realistic exploitation scenario.\n"
    )


def _normalize_severity(value: str | None) -> Severity:
    if not value:
        return Severity.MEDIUM
    try:
        return Severity(value.lower())
    except Exception:
        return Severity.MEDIUM


def _normalize_confidence(value: str | None) -> Confidence:
    if not value:
        return Confidence.MEDIUM
    try:
        return Confidence(value.lower())
    except Exception:
        return Confidence.MEDIUM


def _normalize_owasp(value: str | None) -> OWASPCategory | None:
    if not value:
        return None
    cleaned = value.strip()
    if ":" in cleaned:
        cleaned = cleaned.split(":", 1)[0]
    cleaned = cleaned.upper()
    try:
        return OWASPCategory(cleaned)
    except Exception:
        return None


def _slugify(value: str) -> str:
    cleaned = "".join(ch.lower() if ch.isalnum() else "_" for ch in value)
    cleaned = "_".join([p for p in cleaned.split("_") if p])
    return cleaned or "finding"


def _normalize_finding(raw: dict[str, Any]) -> SecurityFinding:
    title = raw.get("title") or raw.get("name") or "Security finding"
    rule_id = raw.get("ruleId") or raw.get("rule_id") or _slugify(title)
    file_path = raw.get("filePath") or raw.get("file_path") or ""
    line_start = raw.get("lineStart") or raw.get("line_start") or 0
    line_end = raw.get("lineEnd") or raw.get("line_end")

    return SecurityFinding(
        id=raw.get("id") or str(uuid4()),
        rule_id=rule_id,
        owasp_category=_normalize_owasp(raw.get("owaspCategory") or raw.get("owasp_category")),
        cwe_id=raw.get("cweId") or raw.get("cwe_id"),
        severity=_normalize_severity(raw.get("severity")),
        confidence=_normalize_confidence(raw.get("confidence")),
        title=title,
        description=raw.get("description") or f"Detected potential security issue: {title}",
        file_path=file_path,
        line_start=int(line_start) if isinstance(line_start, (int, str)) and str(line_start).isdigit() else 0,
        line_end=int(line_end) if isinstance(line_end, (int, str)) and str(line_end).isdigit() else None,
        code_snippet=raw.get("codeSnippet") or raw.get("code_snippet"),
        recommendation=raw.get("recommendation"),
    )


def _resolve_checks(
    checks: list[dict[str, Any]],
    profiles: dict[str, list[str]],
    requested_checks: list[str] | None,
    scan_profile: str,
) -> tuple[list[str], str | None]:
    catalog_ids = {c.get("id") for c in checks}
    if requested_checks:
        invalid = [c for c in requested_checks if c not in catalog_ids]
        if invalid:
            return [], f"Invalid checks: {invalid}. Use list_security_checks to see valid IDs."
        return requested_checks, None
    if scan_profile not in profiles:
        return [], f"Invalid scan_profile '{scan_profile}'. Available: {sorted(profiles.keys())}"
    return profiles[scan_profile], None


def _build_scan_report(scan: StoredSecurityScan) -> str:
    """Build a human-readable summary block for a finalized scan."""
    summary = scan.result.summary
    sev = summary.by_severity
    lines = [
        "Security Scan Complete",
        f"Target: {scan.target_path}",
        f"Files scanned: {summary.files_scanned}",
        f"Total findings: {summary.total_findings} "
        f"({sev.critical} critical, {sev.high} high, {sev.medium} medium, {sev.low} low)",
    ]
    if summary.by_owasp_category:
        lines.append("")
        lines.append("OWASP breakdown:")
        for code, count in sorted(summary.by_owasp_category.items()):
            lines.append(f"  {code}: {count}")
    return "\n".join(lines)


async def handle_list_security_checks(arguments: dict) -> list[TextContent]:
    """Handle the list_security_checks tool call."""
    checks, profiles = get_checks_and_profiles()
    if not checks:
        return [TextContent(type="text", text="Error: No security checks available. Ensure security_checks.json is present.")]
    response = {
        "profiles": profiles,
        "checks": checks,
        "expectedOutputSchema": _expected_output_schema(),
        "analysisInstructions": _analysis_instructions(),
    }
    return [TextContent(type="text", text=json.dumps(response, indent=2))]


async def handle_security_scan(
    security_store: SecurityScanStore,
    arguments: dict,
) -> list[TextContent]:
    """Handle the security_scan tool call."""
    target_path = arguments.get("target_path") or os.getcwd()
    scan_id = arguments.get("scan_id") or arguments.get("scanId")
    include_content = arguments.get("include_content", False)
    offset = arguments.get("offset", 0)
    limit = min(arguments.get("limit", 5), 10)

    checks, profiles = get_checks_and_profiles()
    status = "pending"

    if scan_id:
        stored = security_store.get(scan_id)
        if not stored:
            return [TextContent(type="text", text=f"Error: scan not found: {scan_id}")]
        meta = security_store.get_meta(scan_id)
        if not meta:
            return [TextContent(type="text", text=f"Error: scan metadata missing: {scan_id}")]
        file_list = stored.file_list
        base_for_rel = meta.base_for_rel
        display_target = stored.target_path
        selected_checks = stored.selected_checks
        scan_profile = stored.scan_profile or "all_static"
        scan_timestamp = stored.result.scan_timestamp
        info = stored.result.errors
        status = stored.status
    else:
        scan_root = os.path.abspath(target_path)
        if not os.path.exists(scan_root):
            return [TextContent(type="text", text=f"Error: path does not exist: {target_path}")]

        scan_profile = arguments.get("scan_profile") or arguments.get("scanProfile") or "all_static"
        requested_checks = arguments.get("checks") or []
        if isinstance(requested_checks, str):
            requested_checks = [requested_checks]
        selected_checks, error = _resolve_checks(checks, profiles, requested_checks, scan_profile)
        if error:
            return [TextContent(type="text", text=f"Error: {error}\nHint: call list_security_checks to view available checks.")]
        if not selected_checks:
            return [TextContent(type="text", text="Error: No checks selected. Use list_security_checks to choose checks or a profile.")]

        base_for_rel, display_target = _get_project_paths(scan_root)
        files_abs, info = collect_scan_files(scan_root)
        file_list = [os.path.relpath(p, base_for_rel) for p in files_abs]

        scan_id = str(uuid4())
        timestamp = datetime.now(timezone.utc).isoformat()
        summary = ScanSummary(
            total_findings=0,
            by_severity=SeverityCounts(),
            by_owasp_category={},
            files_scanned=len(file_list),
        )
        scan_result = SecurityScanResult(
            scan_id=scan_id,
            target_path=display_target,
            scan_timestamp=timestamp,
            summary=summary,
            findings=[],
            errors=info,
        )
        security_store.create_scan(
            result=scan_result,
            file_list=file_list,
            selected_checks=selected_checks,
            scan_profile=scan_profile,
            scan_root=scan_root,
            base_for_rel=str(base_for_rel),
        )
        scan_timestamp = timestamp

    # Process any submitted findings before building the response
    raw_findings = arguments.get("findings") or []
    if isinstance(raw_findings, dict):
        raw_findings = [raw_findings]
    findings_stats: dict[str, int] = {}
    if raw_findings and isinstance(raw_findings, list):
        normalized = [_normalize_finding(r) for r in raw_findings if isinstance(r, dict)]
        findings_stats = security_store.add_findings(scan_id, normalized)

    # Finalize if is_last
    is_last = bool(arguments.get("is_last") or arguments.get("isLast"))

    total_files = len(file_list)
    response: dict[str, Any] = {
        "scanId": scan_id,
        "targetPath": display_target,
        "scanTimestamp": scan_timestamp,
        "status": status,
        "scanProfile": scan_profile,
        "selectedChecks": selected_checks,
        "filesTotal": total_files,
        "scanInfo": info,
        "analysisInstructions": _analysis_instructions(),
        "expectedOutputSchema": _expected_output_schema(),
        "availableProfiles": sorted(profiles.keys()),
        "catalogHint": "Call list_security_checks for full catalog.",
    }

    if findings_stats:
        response["findingsSubmitted"] = findings_stats

    if is_last:
        finalized = security_store.finalize_scan(scan_id)
        if finalized:
            response["status"] = "completed"
            response["summary"] = finalized.result.summary.model_dump(by_alias=True)
            response["findings"] = [f.model_dump(by_alias=True) for f in finalized.result.findings]
            response["scanReport"] = _build_scan_report(finalized)
        return [TextContent(type="text", text=json.dumps(response, indent=2))]

    if include_content:
        paginated_paths = file_list[offset:offset + limit]
        abs_paginated_paths = [str(Path(base_for_rel) / p) for p in paginated_paths]
        contents = get_file_contents(abs_paginated_paths)

        response["pagination"] = {
            "offset": offset,
            "limit": limit,
            "returned": len(paginated_paths),
            "total": total_files,
            "hasMore": offset + limit < total_files,
            "nextOffset": offset + limit if offset + limit < total_files else None,
        }

        response["fileContents"] = {
            rel: contents.get(abs_path, "")
            for rel, abs_path in zip(paginated_paths, abs_paginated_paths)
        }

        # Run automated dependency scanning on manifest files in this batch
        if offset == 0:
            # Collect all manifest files from the full file list for dep scanning
            manifest_names = {"package.json", "requirements.txt", "requirements-dev.txt"}
            manifest_paths = [p for p in file_list if Path(p).name.lower() in manifest_names]
            if manifest_paths:
                abs_manifest_paths = [str(Path(base_for_rel) / p) for p in manifest_paths]
                manifest_contents = get_file_contents(abs_manifest_paths)
                rel_manifest_contents = {
                    rel: manifest_contents.get(abs_path, "")
                    for rel, abs_path in zip(manifest_paths, abs_manifest_paths)
                }
                dep_findings = scan_dependencies(rel_manifest_contents)
                if dep_findings:
                    normalized = [_normalize_finding(f) for f in dep_findings]
                    stats = security_store.add_findings(scan_id, normalized)
                    response["depScanResults"] = {
                        "found": len(dep_findings),
                        "added": stats.get("added", 0),
                        "note": f"Automated dependency scan found {len(dep_findings)} vulnerable package(s). These findings have been auto-submitted.",
                    }
    else:
        response["nextStep"] = (
            "Call again with include_content=true, offset=0 to fetch file contents. "
            "Pass findings=[...] alongside subsequent offsets to submit findings as you go. "
            "Set is_last=true on the final call to finalize."
        )

    return [TextContent(type="text", text=json.dumps(response, indent=2))]


async def handle_submit_security_findings(
    security_store: SecurityScanStore,
    arguments: dict,
) -> list[TextContent]:
    """Handle the submit_security_findings tool call (kept for backward compat)."""
    scan_id = arguments.get("scan_id") or arguments.get("scanId")
    if not scan_id:
        return [TextContent(type="text", text="Error: scan_id is required")]

    raw_findings = arguments.get("findings") or []
    if isinstance(raw_findings, dict):
        raw_findings = [raw_findings]
    if not isinstance(raw_findings, list):
        return [TextContent(type="text", text="Error: findings must be a list")]

    stored = security_store.get(scan_id)
    if not stored:
        return [TextContent(type="text", text=f"Error: scan not found: {scan_id}")]
    if stored.status == "completed":
        return [TextContent(type="text", text=f"Error: scan already finalized: {scan_id}")]

    findings: list[SecurityFinding] = []
    for raw in raw_findings:
        if isinstance(raw, dict):
            findings.append(_normalize_finding(raw))

    stats = security_store.add_findings(scan_id, findings)

    is_last = arguments.get("is_last")
    if is_last is None:
        is_last = arguments.get("isLast")
    is_last = bool(is_last)

    summary = None
    if is_last:
        stored = security_store.finalize_scan(scan_id)
        if stored:
            summary = stored.result.summary.model_dump(by_alias=True)

    response = {
        "scanId": scan_id,
        "added": stats.get("added", 0),
        "deduped": stats.get("deduped", 0),
        "isLast": is_last,
        "status": "completed" if is_last else "pending",
        "summary": summary,
        "nextStep": (
            "Scan finalized. Call push_to_maeris with data_type='vulnerabilities' and scan_id."
            if is_last else "Submit more findings or set is_last=true to finalize."
        ),
    }

    return [TextContent(type="text", text=json.dumps(response, indent=2))]


async def handle_get_security_scans(
    security_store: SecurityScanStore,
    arguments: dict,
) -> list[TextContent]:
    """Handle the get_security_scans tool call."""
    scan_id = arguments.get("scan_id")
    last_n = arguments.get("last_n")
    nth = arguments.get("nth")
    result: Any

    if scan_id:
        stored = security_store.get(scan_id)
        if not stored:
            return [TextContent(type="text", text=f"Error: scan not found: {scan_id}")]
        result = _build_response(stored)
    elif nth:
        recent = security_store.get_recent(nth)
        if len(recent) < nth:
            return [TextContent(
                type="text",
                text=f"Error: requested nth={nth} but only {len(recent)} scan(s) available.",
            )]
        result = _build_response(recent[nth - 1])
    elif last_n:
        recent = security_store.get_recent(last_n)
        result = [_build_response(s) for s in recent]
    else:
        result = [_build_response(s) for s in security_store.get_recent(100)]

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def handle_clear_security_scans(
    security_store: SecurityScanStore,
    arguments: dict,
) -> list[TextContent]:
    """Handle the clear_security_scans tool call."""
    scan_id = arguments.get("scan_id")

    if scan_id:
        deleted = security_store.delete(scan_id)
        response = {
            "success": deleted,
            "message": f"Deleted scan: {scan_id}" if deleted else f"Scan not found: {scan_id}",
        }
    else:
        count = security_store.clear()
        response = {
            "success": True,
            "message": f"Cleared {count} scan(s)",
            "count": count,
        }

    return [TextContent(type="text", text=json.dumps(response, indent=2))]


def _build_response(scan: StoredSecurityScan, include_findings: bool = True) -> dict:
    result = {
        "scanId": scan.result.scan_id,
        "targetPath": scan.target_path,
        "scanTimestamp": scan.result.scan_timestamp,
        "storedAt": scan.stored_at,
        "status": scan.status,
        "scanProfile": scan.scan_profile,
        "selectedChecks": scan.selected_checks,
        "filesScanned": scan.result.summary.files_scanned,
        "pushedToMaeris": scan.pushed_to_maeris,
        "pushedAt": scan.pushed_at,
        "summary": scan.result.summary.model_dump(by_alias=True),
    }
    if include_findings:
        result["findings"] = [f.model_dump(by_alias=True) for f in scan.result.findings]
    return result
