# Maeris

Security and API scanning for your codebase, powered by Claude.

Maeris is an MCP (Model Context Protocol) server that gives Claude the ability to scan your code for security vulnerabilities, extract API definitions, and push results to the [Maeris Portal](https://autoe-light-dev.up.railway.app).

## Quick Start

**1. Install**
```bash
pip install maeris
```

**2. Register the MCP server for your project** (run from your project root)
```bash
maeris init
```

**3. Restart Claude Code**

That's it. Claude can now scan your codebase for security vulnerabilities and API calls.

## Authentication

Some features (like pushing scan results to the Maeris Portal) require an account.

```bash
maeris login
```

This opens your browser to authenticate. Credentials are stored per-project so each repo is fully isolated.

## Commands

| Command | Description |
|---|---|
| `maeris init` | Register the MCP server for the current repository |
| `maeris login` | Authenticate with Maeris Portal |
| `maeris logout` | Sign out and remove stored credentials |
| `maeris status` | Show current authentication status |
| `maeris switch-app` | Switch the active application |

## What Claude Can Do

Once the MCP server is running, ask Claude to:

- **Scan for vulnerabilities** — `"Scan this codebase for security issues"`
- **Extract APIs** — `"Extract all API calls from the src/ folder"`
- **Push to Maeris** — `"Push the scan results to Maeris"`

## Requirements

- Python 3.11+
- [Claude Code](https://claude.ai/code)

## License

MIT
