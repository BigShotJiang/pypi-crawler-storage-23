# OWASP Static Checklist (Comprehensive, Inferred)

This document enumerates every item in `docs/owasp_categories.md` and expands each item with inferred subchecks. It also indicates whether each check is statically feasible (without executing the target) and whether it is currently supported by the Maeris scanner.

**Static feasible?** Yes = can be determined from source code or config/manifest/lockfiles without executing. Partial = sometimes possible with static analysis, but may require runtime context or complete configs. No = requires live runtime, network probing, or operational data.

**Current support?** Yes = covered by the LLM-guided analysis engine (principle-based reasoning + data flow tracing). Partial = detectable in some cases but depends on code complexity and context. No = requires runtime, network probing, or external data not available during static analysis.

**How the scanner works:** Maeris uses an LLM as the detection engine. Code and config files are collected and sent in batches to the LLM, which performs principle-based security analysis — tracing data flows from untrusted sources to sensitive sinks, checking for missing security controls, evaluating cryptographic practices, and assessing configuration security. The LLM applies its full security expertise rather than relying on fixed pattern lists, enabling it to detect novel vulnerability patterns and framework-specific risks. Automated dependency scanning via OSV.dev handles known CVE detection for package manifests.

## OWASP Top 10 (A01-A10)

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| A01: Role escalation checks | Partial | Partial | LLM-guided analysis traces authorization logic and role hierarchy patterns in auth middleware. | Doc |
| A01: Role escalation checks - verify role hierarchy comparisons in auth middleware/guards | Partial | Partial | LLM reasons about control-flow and authorization patterns in middleware/guards. | Inferred |
| A01: Role escalation checks - flag role assignment from untrusted request fields | Partial | Partial | LLM traces data-flow from request inputs to role assignment. | Inferred |
| A01: Unauthenticated access | Partial | Partial | LLM analyzes route-to-auth mapping and identifies unprotected sensitive endpoints. | Doc |
| A01: Unauthenticated access - detect routes lacking auth middleware | Partial | Partial | LLM performs framework-aware routing analysis to find missing auth guards. | Inferred |
| A01: Unauthenticated access - public endpoints returning sensitive data | Partial | Partial | LLM applies semantic data classification to identify sensitive responses on public routes. | Inferred |
| A01: Horizontal privilege escalation | Partial | Partial | LLM checks for missing ownership verification across CRUD handlers. | Doc |
| A01: Horizontal privilege escalation - ensure resource owner checks on CRUD handlers | Partial | Partial | LLM reasons about object ownership patterns in data access logic. | Inferred |
| A01: Horizontal privilege escalation - derive user/tenant from auth context (not request) | Partial | Partial | LLM traces data-flow to verify user/tenant derived from auth context. | Inferred |
| A01: Vertical privilege escalation | Partial | Partial | LLM verifies role/permission enforcement on privileged actions. | Doc |
| A01: Vertical privilege escalation - admin-only actions gated by role checks | Partial | Partial | LLM analyzes authorization guards on admin endpoints. | Inferred |
| A01: Vertical privilege escalation - avoid client-side role flags for auth decisions | Partial | Partial | LLM identifies trust-boundary violations in auth decision logic. | Inferred |
| A01: Forced browsing | Partial | Partial | LLM analyzes route definitions and auth coverage to detect unprotected paths. | Doc |
| A01: Forced browsing - detect unlinked routes or legacy endpoints without auth | Partial | Partial | LLM inventories endpoints and checks auth middleware coverage. | Inferred |
| A01: Forced browsing - direct file/dir access in static handlers | Partial | Partial | LLM analyzes server config and static file handler access controls. | Inferred |
| A01: IDOR testing | Partial | Partial | LLM checks object reference usage against access control enforcement. | Doc |
| A01: IDOR testing - object IDs used without authz guard | Partial | Partial | LLM traces object ID usage to verify ownership/permission checks. | Inferred |
| A01: IDOR testing - sequential IDs without access control | Partial | Partial | LLM identifies sequential ID patterns lacking authorization validation. | Inferred |
| A01: URL manipulation | Partial | Partial | LLM validates path/query parameter handling in auth decision flows. | Doc |
| A01: URL manipulation - validate path params used for access decisions | Partial | Partial | LLM traces parameter usage in access control logic. | Inferred |
| A01: URL manipulation - open redirect via next/returnUrl parameters | Partial | Partial | LLM identifies redirect parameters lacking validation/allowlisting. | Inferred |
| A01: Access bypass via headers/cookies | Partial | Partial | LLM analyzes trust boundaries for client-provided headers and cookies in auth flows. | Doc |
| A01: Access bypass via headers/cookies - auth based on client headers | Partial | Partial | LLM identifies auth decisions sourced from untrusted client headers. | Inferred |
| A01: Access bypass via headers/cookies - debug/test headers enabling access | Partial | Partial | LLM detects debug/test header checks that bypass normal auth. | Inferred |
| A01: Multi-tenant boundary testing | Partial | Partial | LLM traces tenant isolation patterns across data access paths. | Doc |
| A01: Multi-tenant boundary testing - enforce tenant_id filters on queries | Partial | Partial | LLM verifies tenant_id filtering in database queries. | Inferred |
| A01: Multi-tenant boundary testing - tenant_id not accepted from request body | Partial | Partial | LLM traces data-flow to verify tenant_id derived from auth context, not request. | Inferred |
| A02: Weak TLS protocols (SSLv2, SSLv3, TLS 1.0/1.1) | Partial | Partial | LLM analyzes server/proxy config files (nginx, Apache, app settings) for TLS version constraints. | Doc |
| A02: Weak TLS protocols - min TLS version set to 1.2+ in server config | Partial | Partial | LLM parses server config for minimum TLS version settings. | Inferred |
| A02: Weak TLS protocols - legacy protocol flags disabled (nginx/Apache/app) | Partial | Partial | LLM identifies legacy protocol enablement in config files. | Inferred |
| A02: Weak cipher suites | Partial | Partial | LLM evaluates cipher suite configuration in server/proxy configs. | Doc |
| A02: Weak cipher suites - disallow RC4/3DES/NULL ciphers | Partial | Partial | LLM identifies weak cipher references in TLS config. | Inferred |
| A02: Weak cipher suites - enforce strong cipher ordering | Partial | Partial | LLM checks cipher ordering and preference settings. | Inferred |
| A02: Missing HSTS | Partial | Partial | LLM checks for Strict-Transport-Security header configuration in server/app code. | Doc |
| A02: Missing HSTS - Strict-Transport-Security header set | Partial | Partial | LLM identifies HSTS header presence in middleware/config. | Inferred |
| A02: Missing HSTS - HSTS max-age and includeSubDomains configured | Partial | Partial | LLM validates HSTS parameters in header configuration. | Inferred |
| A02: Mixed content | Partial | Partial | LLM scans templates and frontend code for insecure protocol references. | Doc |
| A02: Mixed content - http:// asset references in templates | Partial | Partial | LLM detects http:// references in HTML/template files. | Inferred |
| A02: Mixed content - ws:// or insecure mixed protocols in frontend | Partial | Partial | LLM identifies insecure WebSocket and mixed protocol usage. | Inferred |
| A02: Sensitive data over HTTP | Partial | Partial | LLM identifies hardcoded HTTP URLs and insecure protocol usage for sensitive operations. | Doc |
| A02: Sensitive data over HTTP - hardcoded http:// API endpoints | Partial | Partial | LLM detects hardcoded http:// endpoints in code and config. | Inferred |
| A02: Sensitive data over HTTP - HTTP used for auth/token exchange | Partial | Partial | LLM traces protocol usage in authentication and token exchange flows. | Inferred |
| A02: Weak cookie attributes | Partial | Partial | LLM analyzes cookie configuration for missing security attributes. | Doc |
| A02: Weak cookie attributes - missing Secure/HttpOnly/SameSite | Partial | Partial | LLM checks Set-Cookie and cookie middleware configuration. | Inferred |
| A02: Weak cookie attributes - session cookies without Secure flag | Partial | Partial | LLM identifies session cookie definitions lacking Secure flag. | Inferred |
| A02: Improper key lengths | Partial | Partial | LLM evaluates cryptographic key size parameters in code and config. | Doc |
| A02: Improper key lengths - RSA <2048 or EC <256 keys | Partial | Partial | LLM detects insufficient key lengths in crypto initialization code. | Inferred |
| A02: Improper key lengths - weak PBKDF iterations or salt sizes | Partial | Partial | LLM checks PBKDF2/bcrypt/scrypt iteration counts and salt parameters. | Inferred |
| A03: SQL injection | Partial | Partial | LLM-guided data-flow analysis traces untrusted input into SQL construction, plus regex patterns. | Doc |
| A03: SQL injection - SQL string formatting (format/f-string) | Yes | Yes | Covered by regex and LLM data-flow analysis for SQL string formatting. | Inferred |
| A03: SQL injection - SQL concatenation in execute() | Yes | Yes | Covered by regex and LLM data-flow analysis for SQL concatenation. | Inferred |
| A03: SQL injection - ORM raw queries with untrusted input | Partial | Partial | LLM traces data-flow from request inputs into ORM raw query APIs. | Inferred |
| A03: NoSQL injection | Partial | Partial | LLM analyzes query object construction from untrusted request data. | Doc |
| A03: NoSQL injection - MongoDB query object built from request body | Partial | Partial | LLM traces data-flow from request body into MongoDB query construction. | Inferred |
| A03: NoSQL injection - use of $where with user input | Partial | Partial | LLM identifies $where clauses with user-controlled input via data-flow reasoning. | Inferred |
| A03: Command injection | Partial | Partial | LLM-guided taint analysis traces user input into shell commands, plus regex patterns. | Doc |
| A03: Command injection - subprocess with shell=True | Yes | Yes | Covered by regex and LLM analysis for shell=True. | Inferred |
| A03: Command injection - os.system/os.popen with variable | Yes | Yes | Covered by regex and LLM analysis for os.system/os.popen. | Inferred |
| A03: Command injection - command constructed from user input | Partial | Partial | LLM performs taint tracking from request inputs to command construction. | Inferred |
| A03: Server Side Template Injection (SSTI) | Partial | Partial | LLM traces user-controlled data into template rendering APIs. | Doc |
| A03: SSTI - render() called with user-controlled template string | Partial | Partial | LLM traces data-flow from user input into template render calls. | Inferred |
| A03: SSTI - eval-like template features enabled with untrusted input | Partial | Partial | LLM performs framework-aware analysis of template engine configuration and usage. | Inferred |
| A03: LDAP injection | Partial | Partial | LLM analyzes LDAP filter construction for unsanitized input concatenation. | Doc |
| A03: LDAP injection - LDAP filter string concatenation | Partial | Partial | LLM detects string concatenation in LDAP filter construction. | Inferred |
| A03: LDAP injection - unescaped input in directory search filters | Partial | Partial | LLM traces unescaped user input into directory search filter parameters. | Inferred |
| A03: HTML injection | Partial | Partial | Regex detects some DOM sinks only. | Doc |
| A03: HTML injection - innerHTML assigned from variable | Yes | Yes | Covered by regex for innerHTML with variable. | Inferred |
| A03: HTML injection - dangerouslySetInnerHTML usage | Yes | Yes | Covered by regex for dangerouslySetInnerHTML. | Inferred |
| A03: HTML injection - document.write with variable | Yes | Yes | Covered by regex for document.write with variable. | Inferred |
| A03: Stored/Reflected/DOM XSS | Partial | Partial | LLM traces user input to DOM sinks and template outputs, plus regex for known sinks. | Doc |
| A03: XSS - DOM sinks (innerHTML/document.write) | Yes | Yes | Covered by regex and LLM analysis for DOM sinks. | Inferred |
| A03: XSS - reflected output without escaping | Partial | Partial | LLM performs context-aware analysis of template output escaping for reflected input. | Inferred |
| A03: XSS - stored content rendered without sanitization | Partial | Partial | LLM traces data-flow from storage to rendering, checking for missing sanitization. | Inferred |
| A03: Injection on headers | Partial | Partial | LLM analyzes header construction for user-controlled input injection. | Doc |
| A03: Injection on headers - response headers built from user input | Partial | Partial | LLM traces data-flow from user input into response header construction. | Inferred |
| A03: Injection on headers - request headers injected into downstream calls | Partial | Partial | LLM analyzes request/response flow for header injection propagation. | Inferred |
| A04: Missing rate limits | Partial | Partial | LLM checks for rate-limiting middleware on auth and sensitive endpoints. | Doc |
| A04: Missing rate limits - no rate limiter on auth endpoints | Partial | Partial | LLM analyzes route/middleware mapping for missing rate limiters on auth routes. | Inferred |
| A04: Missing rate limits - no per-IP or per-user throttling config | Partial | Partial | LLM inspects middleware config for per-IP/per-user throttling. | Inferred |
| A04: Absent account lockout | Partial | Partial | LLM analyzes auth flow for missing lockout/tracking mechanisms. | Doc |
| A04: Absent account lockout - login attempts not tracked | Partial | Partial | LLM checks auth handlers for failed attempt tracking logic. | Inferred |
| A04: Absent account lockout - no exponential backoff or lockout policy | Partial | Partial | LLM inspects auth policy configuration for lockout/backoff settings. | Inferred |
| A04: Weak session lifecycle | Partial | Partial | LLM analyzes session management for rotation, expiry, and lifecycle issues. | Doc |
| A04: Weak session lifecycle - session not rotated on login/privilege change | Partial | Partial | LLM traces auth/session flow for missing session rotation on login. | Inferred |
| A04: Weak session lifecycle - session TTL not enforced | Partial | Partial | LLM checks session configuration for TTL enforcement. | Inferred |
| A04: Password reset flow flaws | Partial | No | Requires flow-specific logic checks. | Doc |
| A04: Password reset flow flaws - reset tokens not single-use | Partial | No | Requires token lifecycle analysis. | Inferred |
| A04: Password reset flow flaws - reset token lacks expiry/binding | Partial | No | Needs token validation analysis. | Inferred |
| A04: No defense-in-depth mechanisms | Partial | No | Architectural requirement beyond regex scanning. | Doc |
| A04: No defense-in-depth - critical actions lack secondary checks | Partial | No | Requires business logic analysis. | Inferred |
| A04: No defense-in-depth - no monitoring on privileged actions | Partial | No | Requires operational design review. | Inferred |
| A05: Directory listing | Partial | Partial | LLM analyzes server/static file configuration for directory listing enablement. | Doc |
| A05: Directory listing - web server autoindex enabled | Partial | Partial | LLM detects autoindex/directory-listing flags in server config files. | Inferred |
| A05: Directory listing - static root exposes sensitive dirs | Partial | Partial | LLM evaluates static file handler paths for sensitive directory exposure. | Inferred |
| A05: Unpatched application servers | Partial | Partial | LLM + OSV.dev scanning identifies outdated versions in manifests/configs. | Doc |
| A05: Unpatched servers - outdated runtime/framework versions in config | Partial | Partial | LLM parses version strings from manifests; OSV.dev checks for known vulnerabilities. | Inferred |
| A05: Unpatched servers - vulnerable base images in containers | Partial | Partial | LLM analyzes Dockerfile base image tags for outdated/vulnerable versions. | Inferred |
| A05: Debug mode enabled | Yes | Yes | LLM detects debug flags across framework configs, not just DEBUG=True regex. | Doc |
| A05: Debug mode enabled - framework debug flags in config files | Partial | Partial | LLM performs framework-aware config analysis for debug/development mode settings. | Inferred |
| A05: Debug mode enabled - verbose stack traces enabled | Partial | Partial | LLM identifies verbose error/stack trace settings across frameworks. | Inferred |
| A05: Verbose error messages | Partial | Partial | LLM analyzes error handlers for stack trace and exception detail exposure. | Doc |
| A05: Verbose error messages - stack traces returned to clients | Partial | Partial | LLM identifies error handlers that return stack traces in responses. | Inferred |
| A05: Verbose error messages - exception details logged to client responses | Partial | Partial | LLM traces exception handling to detect details leaking into responses. | Inferred |
| A05: Missing security headers | Partial | Partial | LLM checks server/middleware config for security header presence. | Doc |
| A05: Missing security headers - no CSP/HSTS/X-Frame-Options | Partial | Partial | LLM identifies missing CSP/HSTS/X-Frame-Options in middleware and server config. | Inferred |
| A05: Missing security headers - no X-Content-Type-Options/Referrer-Policy | Partial | Partial | LLM checks for X-Content-Type-Options and Referrer-Policy configuration. | Inferred |
| A05: Unsafe HTTP methods (TRACE, OPTIONS, PUT, DELETE) | Partial | Partial | LLM analyzes router/server method configuration for overly permissive methods. | Doc |
| A05: Unsafe HTTP methods - TRACE/PUT/DELETE enabled without auth | Partial | Partial | LLM checks route definitions for dangerous methods lacking auth middleware. | Inferred |
| A05: Unsafe HTTP methods - OPTIONS reveals sensitive routes | Partial | Partial | LLM analyzes CORS and OPTIONS handling in router configuration. | Inferred |
| A05: CORS misconfiguration | Partial | Partial | LLM evaluates CORS middleware/config for insecure origin policies. | Doc |
| A05: CORS misconfiguration - wildcard origin with credentials | Partial | Partial | LLM detects wildcard origins combined with credentials in CORS config. | Inferred |
| A05: CORS misconfiguration - origin reflection without allowlist | Partial | Partial | LLM identifies dynamic origin reflection without allowlist validation. | Inferred |
| A06: JS library fingerprinting | Partial | Partial | LLM parses package.json/lockfiles for versions; OSV.dev matches against vulnerability data. | Doc |
| A06: JS library fingerprinting - parse package.json/lockfiles for versions | Partial | Yes | Automated OSV.dev scanning parses package.json and lockfiles for dependency versions. | Inferred |
| A06: JS library fingerprinting - detect versions from bundle comments | Partial | Partial | LLM can identify version comments in bundled JS files. | Inferred |
| A06: Package version detection | Partial | Yes | OSV.dev integration automatically parses manifests/lockfiles for all supported ecosystems. | Doc |
| A06: Package version detection - parse requirements.txt/go.mod/package.json | Partial | Yes | OSV.dev scanner parses requirements.txt, go.mod, package.json, and other manifests. | Inferred |
| A06: Package version detection - parse lockfiles for exact versions | Partial | Yes | OSV.dev scanner parses lockfiles (package-lock.json, yarn.lock, etc.) for exact versions. | Inferred |
| A06: CVE matching | Partial | Yes | OSV.dev integration provides automated CVE/vulnerability matching for detected dependencies. | Doc |
| A06: CVE matching - match dependencies to CVE feeds | Partial | Yes | OSV.dev API matches dependency versions against the OSV vulnerability database. | Inferred |
| A06: CVE matching - include transitive dependencies | Partial | Partial | OSV.dev covers direct dependencies from lockfiles; transitive coverage depends on lockfile detail. | Inferred |
| A06: Known vulnerable dependencies | Partial | Yes | OSV.dev integration flags known vulnerable dependency versions automatically. | Doc |
| A06: Known vulnerable dependencies - enforce denylist for risky packages | Partial | Partial | LLM can identify known risky packages; OSV.dev flags vulnerable versions. | Inferred |
| A06: Known vulnerable dependencies - flag deprecated/out-of-support libs | Partial | Partial | LLM applies security knowledge to identify deprecated/unmaintained libraries. | Inferred |
| A06: SBOM-based vulnerability mapping | Partial | Partial | OSV.dev provides vulnerability mapping; full SBOM generation is not yet automated. | Doc |
| A06: SBOM mapping - generate SBOM from manifests | Partial | Partial | Manifest parsing provides partial SBOM data; dedicated SBOM generation not yet integrated. | Inferred |
| A06: SBOM mapping - map SBOM components to CVE feed | Partial | Partial | OSV.dev maps detected components to vulnerability data. | Inferred |
| A07: Brute-force susceptibility | Partial | Partial | LLM analyzes auth endpoints for missing rate-limiting and lockout mechanisms. | Doc |
| A07: Brute-force susceptibility - no rate limiting on login endpoints | Partial | Partial | LLM checks login route middleware for rate-limiting configuration. | Inferred |
| A07: Brute-force susceptibility - no lockout/backoff policy | Partial | Partial | LLM inspects auth handlers for lockout/backoff policy enforcement. | Inferred |
| A07: Session fixation | Partial | Partial | LLM analyzes session lifecycle for missing ID regeneration on login. | Doc |
| A07: Session fixation - session ID not regenerated on login | Partial | Partial | LLM traces session handling to verify ID regeneration after authentication. | Inferred |
| A07: Session fixation - session ID accepted from URL params | Partial | Partial | LLM checks request parsing for session ID acceptance from URL parameters. | Inferred |
| A07: Session ID predictability | Partial | Partial | LLM evaluates session ID generation for use of non-cryptographic RNG. | Doc |
| A07: Session ID predictability - non-cryptographic RNG for session IDs | Partial | Partial | LLM identifies use of weak RNG (e.g., Math.random, random.randint) for session IDs. | Inferred |
| A07: Session ID predictability - sequential or timestamp-based IDs | Partial | Partial | LLM detects sequential or timestamp-based ID generation patterns. | Inferred |
| A07: No MFA | Partial | Partial | LLM analyzes auth flow for missing MFA steps on privileged operations. | Doc |
| A07: No MFA - MFA step missing for privileged actions | Partial | Partial | LLM checks auth flow for MFA enforcement on sensitive/admin actions. | Inferred |
| A07: No MFA - MFA flag ignored in auth pipeline | Partial | Partial | LLM traces auth pipeline to detect bypassed MFA flags. | Inferred |
| A07: Weak password policy | Partial | Partial | LLM inspects password validation logic for insufficient complexity requirements. | Doc |
| A07: Weak password policy - minimum length too low | Partial | Partial | LLM checks password validation for minimum length thresholds. | Inferred |
| A07: Weak password policy - no complexity/blacklist checks | Partial | Partial | LLM evaluates password validation for missing complexity and dictionary checks. | Inferred |
| A07: Insecure remember-me tokens | Partial | Partial | LLM analyzes remember-me token lifecycle for rotation and storage issues. | Doc |
| A07: Insecure remember-me tokens - long-lived tokens without rotation | Partial | Partial | LLM checks token management for missing rotation on long-lived tokens. | Inferred |
| A07: Insecure remember-me tokens - tokens stored or logged in plaintext | Partial | Partial | LLM traces token storage and logging to detect plaintext exposure. | Inferred |
| A08: Unsafe deserialization | Yes | Yes | LLM detects deserialization of untrusted data across languages, plus regex for known patterns. | Doc |
| A08: Unsafe deserialization - pickle.loads usage | Yes | Yes | Covered by regex and LLM analysis for pickle deserialization. | Inferred |
| A08: Unsafe deserialization - yaml.load/unsafe_load usage | Yes | Yes | Covered by regex and LLM analysis for unsafe YAML loading. | Inferred |
| A08: Unsafe deserialization - marshal.loads or PHP unserialize | Yes | Yes | Covered by regex and LLM analysis for marshal/unserialize. | Inferred |
| A08: Unverified dependencies | Partial | Partial | LLM analyzes lockfile integrity fields and CI pipeline config for unsigned artifacts. | Doc |
| A08: Unverified dependencies - no checksum verification in lockfiles | Partial | Partial | LLM checks lockfile format for missing integrity/checksum fields. | Inferred |
| A08: Unverified dependencies - unsigned artifacts allowed in CI | Partial | Partial | LLM analyzes CI pipeline config for missing artifact signature verification. | Inferred |
| A08: Integrity of delivered JS | Partial | Partial | LLM scans HTML/templates for missing SRI attributes on CDN scripts. | Doc |
| A08: Integrity of delivered JS - missing SRI for CDN scripts | Partial | Partial | LLM detects script tags loading from CDN without integrity attributes. | Inferred |
| A08: Integrity of delivered JS - no integrity hash checks in pipeline | Partial | Partial | LLM analyzes build config for missing integrity verification steps. | Inferred |
| A08: Supply chain vulnerability analysis | Partial | No | Requires dependency provenance/vuln data. | Doc |
| A08: Supply chain analysis - typosquatting package detection | Partial | No | Needs package metadata. | Inferred |
| A08: Supply chain analysis - verify publisher signatures | Partial | No | Requires registry signature data. | Inferred |
| A09: Missing audit logs | Partial | Partial | LLM analyzes auth and admin handlers for missing audit log statements. | Doc |
| A09: Missing audit logs - auth and admin actions not logged | Partial | Partial | LLM checks auth/admin endpoints for logging coverage. | Inferred |
| A09: Missing audit logs - critical data changes not logged | Partial | Partial | LLM traces data modification handlers for missing audit trail. | Inferred |
| A09: No anomaly detection | No | No | Requires runtime monitoring/alerting. | Doc |
| A09: No anomaly detection - no alert rules for suspicious events | No | No | Operational monitoring requirement. | Inferred |
| A09: No anomaly detection - no SIEM integration | No | No | Requires external systems. | Inferred |
| A09: Sensitive data in logs | Partial | Partial | LLM analyzes log statements for sensitive data (passwords, tokens, PII) exposure. | Doc |
| A09: Sensitive data in logs - logging passwords/tokens | Partial | Partial | LLM detects log statements that include password, token, or secret variables. | Inferred |
| A09: Sensitive data in logs - logging full request bodies | Partial | Partial | LLM identifies log calls that dump full request/response bodies. | Inferred |
| A09: No security event alerts | No | No | Requires operational alerting systems. | Doc |
| A09: No security event alerts - no alerts on auth failures | No | No | Requires monitoring setup. | Inferred |
| A09: No security event alerts - no alerts on privilege changes | No | No | Requires monitoring setup. | Inferred |
| A10: URL-fetch endpoints | Partial | Yes | LLM traces dynamic URL usage in HTTP clients plus regex patterns for common sinks. | Doc |
| A10: URL-fetch endpoints - dynamic URL in requests.get/post | Yes | Yes | Covered by regex and LLM data-flow analysis for dynamic URL in requests. | Inferred |
| A10: URL-fetch endpoints - dynamic URL in urlopen | Yes | Yes | Covered by regex and LLM data-flow analysis for urlopen dynamic URL. | Inferred |
| A10: Unsafe webhooks | Partial | Partial | LLM analyzes webhook handlers for missing URL allowlisting and signature verification. | Doc |
| A10: Unsafe webhooks - webhook URL not allowlisted | Partial | Partial | LLM checks webhook target URL handling for missing allowlist validation. | Inferred |
| A10: Unsafe webhooks - missing signature verification | Partial | Partial | LLM analyzes webhook endpoints for missing HMAC/signature verification. | Inferred |
| A10: Internal IP probing | No | No | Requires runtime network testing. | Doc |
| A10: Internal IP probing - no internal IP range blocking | Partial | Partial | LLM checks URL validation logic for missing internal/private IP range blocking. | Inferred |
| A10: Internal IP probing - no DNS/IP resolution checks | Partial | Partial | LLM analyzes URL fetch code for missing DNS resolution validation. | Inferred |
| A10: DNS rebinding tests | No | No | Requires runtime DNS behavior testing. | Doc |
| A10: DNS rebinding tests - no DNS pinning or re-resolve checks | Partial | No | Requires URL validation logic. | Inferred |
| A10: DNS rebinding tests - no protection against hostname to IP changes | Partial | No | Requires runtime safeguards. | Inferred |

## API Security Testing (OWASP API Top 10 + API-specific checks)

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| API1: Broken Object Level Authorization (BOLA) | Partial | Partial | LLM checks API handlers for missing object ownership and authorization verification. | Doc |
| API1: BOLA - object ID in path used without ownership check | Partial | Partial | LLM traces object ID parameters to verify ownership checks in handler logic. | Inferred |
| API1: BOLA - missing tenant filter in API queries | Partial | Partial | LLM verifies tenant_id filtering in API query construction. | Inferred |
| API2: Broken Authentication | Partial | Partial | LLM analyzes API authentication flow for missing validation steps. | Doc |
| API2: Broken Authentication - JWT signature validation missing | Partial | Partial | LLM inspects auth middleware for JWT signature verification logic. | Inferred |
| API2: Broken Authentication - login endpoints lack rate limiting | Partial | Partial | LLM checks API login routes for rate-limiting middleware. | Inferred |
| API3: Excessive Data Exposure | Partial | Partial | LLM analyzes API response serialization for over-exposed model fields. | Doc |
| API3: Excessive Data Exposure - model serialization returns all fields | Partial | Partial | LLM inspects serializers/schemas for missing field filtering. | Inferred |
| API3: Excessive Data Exposure - field filtering not role-aware | Partial | Partial | LLM checks serialization logic for role-based field visibility. | Inferred |
| API4: Lack of Rate Limiting | Partial | Partial | LLM checks API route middleware for rate-limiting configuration. | Doc |
| API4: Lack of Rate Limiting - no rate limiter on API routes | Partial | Partial | LLM analyzes route/middleware mapping for missing rate limiters. | Inferred |
| API4: Lack of Rate Limiting - missing per-client quotas | Partial | Partial | LLM inspects rate-limiting config for per-client quota settings. | Inferred |
| API5: Broken Function Level Authorization | Partial | Partial | LLM checks API endpoints for missing function-level permission enforcement. | Doc |
| API5: BFLA - admin endpoints missing role checks | Partial | Partial | LLM identifies admin API endpoints lacking role-based authorization guards. | Inferred |
| API5: BFLA - function-level permissions not enforced in handlers | Partial | Partial | LLM analyzes handler logic for missing permission checks on sensitive operations. | Inferred |
| API6: Mass Assignment | Partial | Partial | LLM detects direct request body binding to ORM models without field allowlisting. | Doc |
| API6: Mass Assignment - request body bound directly to ORM model | Partial | Partial | LLM traces request body binding to identify unfiltered model updates. | Inferred |
| API6: Mass Assignment - missing allowlist for writable fields | Partial | Partial | LLM checks DTO/schema definitions for missing field allowlists. | Inferred |
| API7: Security Misconfigurations | Partial | Partial | LLM analyzes API gateway and app config for security misconfigurations. | Doc |
| API7: Security Misconfigurations - CORS wildcard with credentials | Partial | Partial | LLM detects wildcard origins with credentials in CORS config. | Inferred |
| API7: Security Misconfigurations - debug/verbose errors enabled | Partial | Partial | LLM identifies debug/verbose error settings in API config. | Inferred |
| API8: Injection | Partial | Partial | LLM-guided data-flow analysis traces untrusted input to injection sinks, plus regex patterns. | Doc |
| API8: Injection - SQL concatenation in API handlers | Yes | Yes | Covered by regex and LLM data-flow analysis for SQL concatenation. | Inferred |
| API8: Injection - shell=True or os.system in API handlers | Yes | Yes | Covered by regex and LLM analysis for command injection patterns. | Inferred |
| API8: Injection - NoSQL queries built from request body | Partial | Partial | LLM traces data-flow from request body into NoSQL query construction. | Inferred |
| API9: Improper Asset Management | Partial | No | Requires endpoint inventory and versioning analysis. | Doc |
| API9: Improper Asset Management - undocumented/legacy endpoints deployed | Partial | No | Needs route inventory vs spec comparison. | Inferred |
| API9: Improper Asset Management - inconsistent versioning or deprecation | Partial | No | Requires API catalog analysis. | Inferred |
| API10: Server-Side Request Forgery | Partial | Partial | LLM traces user-controlled URLs into HTTP clients plus regex patterns. | Doc |
| API10: SSRF - dynamic URL in requests.get/post | Yes | Yes | Covered by regex and LLM data-flow analysis for dynamic URL in requests. | Inferred |
| API10: SSRF - user-controlled URL used in downstream HTTP client | Partial | Partial | LLM performs taint tracking from user input to HTTP client URL parameters. | Inferred |
| API-specific: JWT token analysis | Partial | Partial | LLM inspects JWT validation logic for common weaknesses. | Doc |
| JWT analysis - alg=none accepted | Partial | Partial | LLM checks auth middleware for missing algorithm restriction on JWT verification. | Inferred |
| JWT analysis - weak HMAC key length | Partial | Partial | LLM evaluates JWT signing key configuration for insufficient key lengths. | Inferred |
| JWT analysis - missing exp/nbf validation | Partial | Partial | LLM inspects token validation code for missing expiry/not-before checks. | Inferred |
| JWT analysis - issuer/audience not validated | Partial | Partial | LLM checks JWT validation for missing issuer/audience verification. | Inferred |
| API-specific: OAuth2/OpenID Connect misconfigurations | Partial | No | Requires OAuth/OIDC config analysis. | Doc |
| OAuth2/OIDC - redirect URI wildcards | Partial | No | Requires client config inspection. | Inferred |
| OAuth2/OIDC - missing PKCE for public clients | Partial | No | Requires flow configuration analysis. | Inferred |
| OAuth2/OIDC - implicit flow enabled in production | Partial | No | Requires provider config analysis. | Inferred |
| API-specific: API key leakage detection | Yes | Partial | Regex detects some hardcoded key patterns only. | Doc |
| API key leakage - hardcoded api_key literal in code | Yes | Yes | Covered by regex for hardcoded API key. | Inferred |
| API key leakage - keys embedded in config/examples/docs | Partial | No | Requires config/doc scanning. | Inferred |
| API-specific: GraphQL introspection abuse | No | No | Requires runtime GraphQL endpoint testing. | Doc |
| GraphQL introspection - introspection enabled in production | No | No | Requires live endpoint probing. | Inferred |
| API-specific: gRPC enumeration | No | No | Requires network/service discovery. | Doc |
| gRPC enumeration - list services via reflection | No | No | Requires runtime reflection probing. | Inferred |
| API-specific: WSDL/SOAP discovery | No | No | Requires network/service discovery. | Doc |
| WSDL/SOAP discovery - probe for ?wsdl endpoints | No | No | Requires runtime probing. | Inferred |

## Network Security / Pentesting

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| Nmap: Port scanning | No | No | Requires live network probing. | Doc |
| Port scanning - TCP SYN scan across full port range | No | No | Runtime network test. | Inferred |
| Port scanning - UDP scan for common services | No | No | Runtime network test. | Inferred |
| Nmap: Service detection | No | No | Requires banner/version probing. | Doc |
| Service detection - version probes on open ports | No | No | Runtime network test. | Inferred |
| Service detection - banner parsing for service type | No | No | Runtime network test. | Inferred |
| Nmap: OS fingerprinting | No | No | Requires live TCP/IP stack probing. | Doc |
| OS fingerprinting - TCP/IP stack signature analysis | No | No | Runtime network test. | Inferred |
| OS fingerprinting - ICMP/TTL behavior analysis | No | No | Runtime network test. | Inferred |
| Nmap: TLS fingerprinting | No | No | Requires live TLS handshake analysis. | Doc |
| TLS fingerprinting - JA3/JA3S fingerprint collection | No | No | Runtime network test. | Inferred |
| TLS fingerprinting - certificate chain and cipher analysis | No | No | Runtime network test. | Inferred |
| Nmap: Vulnerability scripts | No | No | Requires NSE scripts against live services. | Doc |
| Vulnerability scripts - run NSE CVE scripts | No | No | Runtime network test. | Inferred |
| Vulnerability scripts - integrate Vulners API results | No | No | Runtime network test. | Inferred |
| Nmap: Firewall/IDS evasion | No | No | Requires live evasion techniques. | Doc |
| Firewall/IDS evasion - fragmentation/decoy scans | No | No | Runtime network test. | Inferred |
| Firewall/IDS evasion - timing/packet rate evasion | No | No | Runtime network test. | Inferred |
| Nmap: Host discovery | No | No | Requires live network discovery. | Doc |
| Host discovery - ICMP ping sweep | No | No | Runtime network test. | Inferred |
| Host discovery - ARP scan on local network | No | No | Runtime network test. | Inferred |
| Vulnerability scanning: Open ports -> known vulnerabilities | No | No | Requires live service discovery + CVE mapping. | Doc |
| Open ports -> CVE mapping by service/version | No | No | Runtime network test. | Inferred |
| Open ports -> NSE/Vulners correlation | No | No | Runtime network test. | Inferred |
| Vulnerability scanning: SMB tests | No | No | Requires live SMB probing. | Doc |
| SMB tests - SMBv1 enabled or weak signing | No | No | Runtime network test. | Inferred |
| SMB tests - null session or anonymous access | No | No | Runtime network test. | Inferred |
| Vulnerability scanning: FTP misconfigurations | No | No | Requires live FTP probing. | Doc |
| FTP misconfig - anonymous login enabled | No | No | Runtime network test. | Inferred |
| FTP misconfig - cleartext credentials allowed | No | No | Runtime network test. | Inferred |
| Vulnerability scanning: SSH hardening analysis | No | No | Requires live SSH probing. | Doc |
| SSH hardening - weak ciphers/kex algorithms | No | No | Runtime network test. | Inferred |
| SSH hardening - root login permitted | No | No | Runtime network test. | Inferred |
| Banner grabbing: Identify framework versions | No | No | Requires live banner/header inspection. | Doc |
| Banner grabbing - Server/X-Powered-By reveals version | No | No | Runtime network test. | Inferred |
| Banner grabbing - error pages leak framework versions | No | No | Runtime network test. | Inferred |
| Banner grabbing: Exposed infrastructure details | No | No | Requires live response inspection. | Doc |
| Exposed infra details - internal hostnames or IPs in banners | No | No | Runtime network test. | Inferred |
| Exposed infra details - load balancer or proxy fingerprints | No | No | Runtime network test. | Inferred |
| Service enumeration: Redis open access | No | No | Requires live service access tests. | Doc |
| Redis open access - no AUTH configured | No | No | Runtime network test. | Inferred |
| Redis open access - bound to 0.0.0.0 without firewall | No | No | Runtime network test. | Inferred |
| Service enumeration: MongoDB unauthenticated | No | No | Requires live service access tests. | Doc |
| MongoDB unauthenticated - no auth enabled | No | No | Runtime network test. | Inferred |
| MongoDB unauthenticated - open bind without IP whitelist | No | No | Runtime network test. | Inferred |
| Service enumeration: Elasticsearch unrestricted access | No | No | Requires live service access tests. | Doc |
| Elasticsearch unrestricted - no auth or TLS | No | No | Runtime network test. | Inferred |
| Elasticsearch unrestricted - open bind without IP whitelist | No | No | Runtime network test. | Inferred |

## DAST - Dynamic Application Security Testing

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| DAST: Automated spidering + crawling | No | No | Requires live application crawling. | Doc |
| DAST: Spidering - discover routes via links/forms | No | No | Runtime crawler behavior. | Inferred |
| DAST: Spidering - authenticated crawling with session handling | No | No | Runtime crawler behavior. | Inferred |
| DAST: Active injection tests | No | No | Requires runtime payload execution. | Doc |
| DAST: Active injection - SQLi payloads against inputs | No | No | Runtime testing. | Inferred |
| DAST: Active injection - XSS payloads against inputs | No | No | Runtime testing. | Inferred |
| DAST: Fuzzing input parameters | No | No | Requires runtime fuzzing. | Doc |
| DAST: Fuzzing - mutation-based parameter fuzzing | No | No | Runtime testing. | Inferred |
| DAST: Fuzzing - boundary/size fuzzing for payloads | No | No | Runtime testing. | Inferred |
| DAST: Session handling | No | No | Requires live session management. | Doc |
| DAST: Session handling - cookie management and replay | No | No | Runtime testing. | Inferred |
| DAST: Session handling - CSRF token capture/reuse | No | No | Runtime testing. | Inferred |
| DAST: ZAP policy-based scanning | No | No | Requires runtime scanning configuration. | Doc |
| DAST: ZAP policy-based scanning - configure alert thresholds | No | No | Runtime scanning. | Inferred |
| DAST: ZAP policy-based scanning - enable/disable rule packs | No | No | Runtime scanning. | Inferred |
| DAST: AJAX spider for SPA apps | No | No | Requires JS execution in crawler. | Doc |
| DAST: AJAX spider - execute SPA routes and XHR discovery | No | No | Runtime testing. | Inferred |
| DAST: AJAX spider - capture dynamic parameters/state | No | No | Runtime testing. | Inferred |
| DAST: Response analysis for vulnerabilities | No | No | Requires runtime response inspection. | Doc |
| DAST: Response analysis - error-based vulnerability detection | No | No | Runtime testing. | Inferred |
| DAST: Response analysis - behavioral anomaly detection | No | No | Runtime testing. | Inferred |
| DAST: CSRF token analysis | No | No | Requires runtime CSRF checks. | Doc |
| DAST: CSRF analysis - missing/invalid token validation | No | No | Runtime testing. | Inferred |
| DAST: CSRF analysis - SameSite cookie effectiveness | No | No | Runtime testing. | Inferred |
| DAST: Vulnerability category - SQLi | No | No | Runtime payload validation required. | Doc |
| SQLi testing - error-based payloads | No | No | Runtime testing. | Inferred |
| SQLi testing - time-based blind payloads | No | No | Runtime testing. | Inferred |
| DAST: Vulnerability category - XSS | No | No | Runtime payload execution required. | Doc |
| XSS testing - reflected payloads | No | No | Runtime testing. | Inferred |
| XSS testing - DOM-based payloads in browser | No | No | Runtime testing. | Inferred |
| DAST: Vulnerability category - CSRF | No | No | Runtime request validation required. | Doc |
| CSRF testing - missing token on state-changing requests | No | No | Runtime testing. | Inferred |
| CSRF testing - token reuse or weak binding | No | No | Runtime testing. | Inferred |
| DAST: Vulnerability category - Path traversal | No | No | Runtime file access attempts required. | Doc |
| Path traversal testing - ../ and encoded variants | No | No | Runtime testing. | Inferred |
| Path traversal testing - null byte or double-encoding | No | No | Runtime testing. | Inferred |
| DAST: Vulnerability category - XXE | No | No | Runtime XML parser probing required. | Doc |
| XXE testing - external entity to file:// | No | No | Runtime testing. | Inferred |
| XXE testing - SSRF via external entity | No | No | Runtime testing. | Inferred |
| DAST: Vulnerability category - Open redirect | No | No | Runtime redirect manipulation required. | Doc |
| Open redirect testing - redirect parameter tampering | No | No | Runtime testing. | Inferred |
| Open redirect testing - allowlist bypass techniques | No | No | Runtime testing. | Inferred |
| DAST: Vulnerability category - CORS misconfig | No | No | Runtime response/header inspection required. | Doc |
| CORS testing - origin reflection with credentials | No | No | Runtime testing. | Inferred |
| CORS testing - wildcard origin with credentials | No | No | Runtime testing. | Inferred |
| DAST: Vulnerability category - Content sniffing issues | No | No | Runtime header inspection required. | Doc |
| Content sniffing - missing X-Content-Type-Options | No | No | Runtime testing. | Inferred |
| Content sniffing - MIME confusion behaviors | No | No | Runtime testing. | Inferred |
| DAST: Vulnerability category - Authentication flaws | No | No | Runtime auth testing required. | Doc |
| Auth flaws - weak password policy enforcement | No | No | Runtime testing. | Inferred |
| Auth flaws - session fixation via login flows | No | No | Runtime testing. | Inferred |

## SAST - Static Application Security Testing

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| SAST: Hardcoded secrets detection | Yes | Yes | LLM detects hardcoded secrets across code, config, and documentation files using contextual analysis. | Doc |
| Hardcoded secrets - password literals in code | Yes | Yes | Covered by regex and LLM contextual analysis for hardcoded passwords. | Inferred |
| Hardcoded secrets - API/secret/private key literals in code | Yes | Yes | Covered by regex and LLM contextual analysis for hardcoded keys. | Inferred |
| Hardcoded secrets - secrets in config/examples/docs | Partial | Partial | LLM scans config and documentation files for embedded secrets. | Inferred |
| SAST: Dependency vulnerability scanning | Partial | Yes | OSV.dev integration provides automated dependency vulnerability scanning. | Doc |
| Dependency scanning - parse manifests/lockfiles for versions | Partial | Yes | OSV.dev automatically parses manifests and lockfiles for dependency versions. | Inferred |
| Dependency scanning - match versions to CVE feeds | Partial | Yes | OSV.dev matches parsed versions against the OSV vulnerability database. | Inferred |
| SAST: Code-level injection detection | Partial | Partial | LLM-guided data-flow analysis traces untrusted input to injection sinks, plus regex patterns. | Doc |
| Code injection - SQL concatenation/format in execute() | Yes | Yes | Covered by regex and LLM data-flow analysis. | Inferred |
| Code injection - shell=True or os.system/os.popen | Yes | Yes | Covered by regex and LLM data-flow analysis. | Inferred |
| Code injection - template injection patterns | Partial | Partial | LLM performs framework-aware analysis of template injection vectors. | Inferred |
| SAST: Unsafe crypto usage | Partial | Yes | LLM evaluates cryptographic usage patterns including algorithm choice, key lengths, and parameters. | Doc |
| Unsafe crypto - MD5/SHA1 usage | Yes | Yes | Covered by regex and LLM analysis for weak hash algorithms. | Inferred |
| Unsafe crypto - DES cipher usage | Yes | Yes | Covered by regex and LLM analysis for weak ciphers. | Inferred |
| Unsafe crypto - weak key lengths/parameters | Partial | Partial | LLM evaluates cryptographic key lengths, iteration counts, and parameters. | Inferred |
| SAST: Dangerous APIs | Partial | Yes | LLM detects dangerous API usage with data-flow context, plus regex patterns. | Doc |
| Dangerous APIs - eval/exec with variable | Yes | Yes | Covered by regex and LLM analysis for eval/exec with untrusted input. | Inferred |
| Dangerous APIs - os.system/os.popen usage | Yes | Yes | Covered by regex and LLM analysis for os.system/os.popen. | Inferred |
| Dangerous APIs - dynamic code loading from network | Partial | Partial | LLM traces data-flow to identify dynamic code loading from network sources. | Inferred |
| SAST: Input validation mistakes | Partial | Partial | LLM analyzes input validation logic and traces request params to sinks. | Doc |
| Input validation - missing allowlist for inputs | Partial | Partial | LLM checks input handling for missing allowlist/validation rules. | Inferred |
| Input validation - direct use of request params in sinks | Partial | Partial | LLM performs taint analysis tracing request parameters to security-sensitive sinks. | Inferred |
| SAST: Broken access logic in code | Partial | Partial | LLM analyzes authorization logic for missing checks and bypassable branches. | Doc |
| Broken access logic - missing auth checks in handlers | Partial | Partial | LLM checks route handlers for missing authorization middleware/guards. | Inferred |
| Broken access logic - bypassable authorization branches | Partial | Partial | LLM performs control-flow analysis to identify bypassable auth branches. | Inferred |
| SAST: Static taint analysis | Partial | Partial | LLM performs principle-based taint analysis, tracing sources to sinks with sanitizer awareness. | Doc |
| Static taint analysis - source to sink mapping | Partial | Partial | LLM traces data-flow from untrusted sources to security-sensitive sinks. | Inferred |
| Static taint analysis - sanitization/validation tracking | Partial | Partial | LLM identifies sanitization/validation steps in data-flow paths. | Inferred |
| SAST tools list: Semgrep, SonarQube, Checkmarx, Veracode, CodeQL | No | No | Tooling reference, not a scan check. | Doc |

## IAST - Interactive Application Security Testing

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| IAST: Detect runtime injection | No | No | Requires instrumentation during execution. | Doc |
| IAST: Runtime injection - capture SQL/command sinks | No | No | Runtime instrumentation required. | Inferred |
| IAST: Runtime injection - verify tainted input reaches sinks | No | No | Runtime taint tracking required. | Inferred |
| IAST: Monitor tainted variables | No | No | Requires runtime taint tracking. | Doc |
| IAST: Taint tracking - user input propagation | No | No | Runtime instrumentation required. | Inferred |
| IAST: Taint tracking - sanitizer effectiveness | No | No | Runtime instrumentation required. | Inferred |
| IAST: Track unsafe deserialization | No | No | Requires runtime hooks in serializers. | Doc |
| IAST: Unsafe deserialization - detect unsafe parser usage | No | No | Runtime instrumentation required. | Inferred |
| IAST: Unsafe deserialization - block/alert on untrusted payloads | No | No | Runtime instrumentation required. | Inferred |
| IAST: Detect SSRF at runtime | No | No | Requires live outbound request monitoring. | Doc |
| IAST: SSRF runtime - alert on internal IP targets | No | No | Runtime instrumentation required. | Inferred |
| IAST: SSRF runtime - enforce allowlists on outbound calls | No | No | Runtime instrumentation required. | Inferred |
| IAST: Memory-based analysis | No | No | Requires runtime memory inspection. | Doc |
| IAST: Memory analysis - detect secrets in memory | No | No | Runtime instrumentation required. | Inferred |
| IAST: Memory analysis - detect unsafe object graphs | No | No | Runtime instrumentation required. | Inferred |
| IAST: Real-time API input/output tracking | No | No | Requires runtime instrumentation on API layer. | Doc |
| IAST: API tracking - request/response diffing | No | No | Runtime instrumentation required. | Inferred |
| IAST: API tracking - detect sensitive data exposure | No | No | Runtime instrumentation required. | Inferred |

## Cloud Security Testing (AWS, GCP, Azure)

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| Cloud IAM: Over-permissive roles | Partial | No | Requires IAM/IaC policy analysis. | Doc |
| IAM over-permissive - wildcard actions/resources in policies | Partial | No | Needs IaC/policy parsing. | Inferred |
| IAM over-permissive - admin privileges granted broadly | Partial | No | Requires policy analysis. | Inferred |
| Cloud IAM: Unrestricted policies | Partial | No | Requires IAM policy inspection. | Doc |
| IAM unrestricted - principal "*" in resource policies | Partial | No | Requires policy parsing. | Inferred |
| IAM unrestricted - no condition constraints | Partial | No | Requires policy analysis. | Inferred |
| Cloud Storage: Public S3 buckets | Partial | No | Requires IaC or cloud inventory analysis. | Doc |
| Public S3 - bucket policy allows public read/write | Partial | No | Needs policy parsing. | Inferred |
| Public S3 - ACL grants AllUsers/AuthenticatedUsers | Partial | No | Requires ACL analysis. | Inferred |
| Cloud Storage: Public GCP storage | Partial | No | Requires IaC or cloud inventory analysis. | Doc |
| Public GCP storage - allUsers IAM binding | Partial | No | Needs policy parsing. | Inferred |
| Public GCP storage - public ACLs on buckets | Partial | No | Requires ACL analysis. | Inferred |
| Cloud Storage: Misconfigured Azure Blobs | Partial | No | Requires IaC or cloud inventory analysis. | Doc |
| Azure Blobs - public container access level | Partial | No | Needs policy/ACL analysis. | Inferred |
| Azure Blobs - SAS tokens overly permissive | Partial | No | Requires config analysis. | Inferred |
| Cloud Network: Open security groups | Partial | No | Requires IaC/cloud security group analysis. | Doc |
| Open security groups - 0.0.0.0/0 on sensitive ports | Partial | No | Needs IaC parsing. | Inferred |
| Open security groups - wide inbound rules without justification | Partial | No | Requires policy review. | Inferred |
| Cloud Network: Publicly exposed databases | Partial | No | Requires inventory and network rules. | Doc |
| Public DBs - database ports open to internet | Partial | No | Needs SG/firewall analysis. | Inferred |
| Public DBs - no private subnets or VPC-only access | Partial | No | Requires IaC analysis. | Inferred |
| Cloud metadata attacks: IMDSv1 misuse | Partial | No | Requires instance metadata configuration analysis. | Doc |
| IMDSv1 misuse - metadata service v1 enabled | Partial | No | Needs cloud config analysis. | Inferred |
| IMDSv1 misuse - no hop limit or token enforcement | Partial | No | Requires metadata config analysis. | Inferred |
| Cloud tools list: ScoutSuite, Prowler, CloudSploit | No | No | Tooling reference, not a scan check. | Doc |

## Container & DevOps Security

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| Docker: Insecure base images | Partial | No | Requires Dockerfile/image inventory + CVE data. | Doc |
| Insecure base images - outdated or vulnerable base image tags | Partial | No | Needs image/version analysis. | Inferred |
| Insecure base images - unpinned latest tags | Partial | No | Requires Dockerfile analysis. | Inferred |
| Docker: Privileged containers | Partial | No | Requires Docker/K8s manifest analysis. | Doc |
| Privileged containers - privileged: true in manifests | Partial | No | Needs manifest parsing. | Inferred |
| Privileged containers - hostPath or hostNetwork usage | Partial | No | Requires manifest inspection. | Inferred |
| Docker: Hardcoded secrets in images | Partial | No | Requires image or Dockerfile scan. | Doc |
| Secrets in images - secrets baked into Dockerfile ENV | Partial | No | Needs Dockerfile analysis. | Inferred |
| Secrets in images - credentials in image layers | Partial | No | Requires image scanning. | Inferred |
| Kubernetes: RBAC misconfigurations | Partial | No | Requires RBAC manifest analysis. | Doc |
| RBAC misconfig - cluster-admin bound to broad subjects | Partial | No | Needs RBAC parsing. | Inferred |
| RBAC misconfig - wildcard verbs/resources | Partial | No | Requires RBAC analysis. | Inferred |
| Kubernetes: Anonymous API access | Partial | No | Requires API server config analysis. | Doc |
| Anonymous API access - anonymous-auth enabled | Partial | No | Needs cluster config analysis. | Inferred |
| Anonymous API access - unauthenticated access to /metrics | Partial | No | Requires cluster policy review. | Inferred |
| Kubernetes: Open dashboards | Partial | No | Requires service exposure analysis. | Doc |
| Open dashboards - dashboard service exposed via LoadBalancer/NodePort | Partial | No | Needs service manifest analysis. | Inferred |
| Open dashboards - no auth on dashboard ingress | Partial | No | Requires ingress/auth analysis. | Inferred |
| Kubernetes: Insecure pod security policies | Partial | No | Requires PSP/PSA policy analysis. | Doc |
| Insecure PSP - allow privileged containers | Partial | No | Needs policy parsing. | Inferred |
| Insecure PSP - allow hostPath/hostNetwork/hostPID | Partial | No | Requires policy analysis. | Inferred |
| CI/CD: Credential leakage | Partial | No | Requires pipeline config/log analysis. | Doc |
| CI/CD credential leakage - secrets in pipeline logs | Partial | No | Needs log scanning. | Inferred |
| CI/CD credential leakage - secrets in CI config variables | Partial | No | Requires config scanning. | Inferred |
| CI/CD: Insecure pipelines | Partial | No | Requires pipeline policy analysis. | Doc |
| Insecure pipelines - unsigned artifacts promoted | Partial | No | Needs pipeline policy analysis. | Inferred |
| Insecure pipelines - untrusted code running with secrets | Partial | No | Requires pipeline isolation analysis. | Inferred |
| Container/DevOps tools list: Trivy, Clair, Falco, kube-bench | No | No | Tooling reference, not a scan check. | Doc |

## Runtime Security / Observability (RASP)

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| RASP: Detect XSS injection attempts | No | No | Requires runtime instrumentation. | Doc |
| RASP: XSS detection - block suspicious payloads | No | No | Runtime detection required. | Inferred |
| RASP: XSS detection - alert on DOM sink usage at runtime | No | No | Runtime instrumentation required. | Inferred |
| RASP: Detect unwanted SQL strings | No | No | Requires runtime SQL monitoring. | Doc |
| RASP: SQL detection - alert on suspicious query patterns | No | No | Runtime instrumentation required. | Inferred |
| RASP: SQL detection - block stacked queries | No | No | Runtime instrumentation required. | Inferred |
| RASP: Identify active path traversal | No | No | Requires runtime request analysis. | Doc |
| RASP: Path traversal - block ../ and encoded variants | No | No | Runtime detection required. | Inferred |
| RASP: Path traversal - alert on file access outside root | No | No | Runtime instrumentation required. | Inferred |
| RASP: Block SSRF attempts | No | No | Requires runtime outbound request monitoring. | Doc |
| RASP: SSRF - block internal IP/metadata targets | No | No | Runtime detection required. | Inferred |
| RASP: SSRF - enforce outbound allowlists | No | No | Runtime instrumentation required. | Inferred |
| RASP: Monitor unusual session behavior | No | No | Requires runtime behavior analytics. | Doc |
| RASP: Session behavior - anomaly detection on IP/UA changes | No | No | Runtime monitoring required. | Inferred |
| RASP: Session behavior - alert on rapid token reuse | No | No | Runtime monitoring required. | Inferred |

## Authentication & Authorization Security

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| Auth: Password brute-force detection | Partial | Partial | LLM analyzes auth flow for missing rate-limiting and lockout mechanisms. | Doc |
| Brute-force detection - no login rate limiting | Partial | Partial | LLM checks login routes for missing rate-limiting middleware. | Inferred |
| Brute-force detection - no lockout/backoff policy | Partial | Partial | LLM inspects auth handlers for missing lockout/backoff enforcement. | Inferred |
| Auth: Credential stuffing detection | Partial | Partial | LLM analyzes auth flow for missing anomaly detection and bot mitigation. | Doc |
| Credential stuffing - lack of IP/device anomaly checks | Partial | Partial | LLM checks auth handlers for missing IP/device fingerprint validation. | Inferred |
| Credential stuffing - no bot detection or MFA triggers | Partial | Partial | LLM inspects auth flow for missing bot detection or adaptive MFA triggers. | Inferred |
| Auth: Weak login flows | Partial | Partial | LLM analyzes login flow for missing security controls and bypass opportunities. | Doc |
| Weak login flows - missing MFA or step-up auth | Partial | Partial | LLM checks auth flow for missing MFA or step-up authentication on sensitive actions. | Inferred |
| Weak login flows - password reset bypassable | Partial | Partial | LLM analyzes password reset flow for token validation and bypass weaknesses. | Inferred |
| Auth: OAuth misconfigurations | Partial | Partial | LLM inspects OAuth client/provider configuration for insecure settings. | Doc |
| OAuth misconfig - redirect URI wildcards | Partial | Partial | LLM checks OAuth redirect_uri configuration for wildcard or open patterns. | Inferred |
| OAuth misconfig - missing PKCE for public clients | Partial | Partial | LLM verifies PKCE enforcement for public OAuth clients. | Inferred |
| Auth: JWT weakness tests | Partial | Partial | LLM inspects JWT validation logic for common security weaknesses. | Doc |
| JWT weakness - alg none allowed | Partial | Partial | LLM checks JWT verification for missing algorithm restriction. | Doc |
| JWT weakness - alg none allowed - reject unsigned tokens | Partial | Partial | LLM verifies that token validation rejects alg=none/unsigned tokens. | Inferred |
| JWT weakness - weak HMAC keys | Partial | Partial | LLM evaluates JWT HMAC key management for insufficient key lengths. | Doc |
| JWT weakness - weak HMAC keys - enforce minimum key length/rotation | Partial | Partial | LLM checks key configuration for minimum length and rotation policy. | Inferred |
| JWT weakness - expiry issues | Partial | Partial | LLM inspects token validation for missing expiry enforcement. | Doc |
| JWT weakness - expiry issues - enforce exp/nbf/iat and max TTL | Partial | Partial | LLM verifies exp/nbf/iat claims are validated and max TTL is enforced. | Inferred |
| JWT weakness - issuer/audience not validated | Partial | Partial | LLM checks JWT validation for missing issuer/audience verification. | Inferred |
| JWT weakness - kid header injection/path traversal | Partial | Partial | LLM analyzes kid header handling for injection/traversal vulnerabilities. | Inferred |

## Session Security

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| Session: SameSite/HttpOnly/Secure checks | Partial | Partial | LLM analyzes cookie configuration for missing security attributes. | Doc |
| Session cookies - missing Secure/HttpOnly/SameSite flags | Partial | Partial | LLM checks Set-Cookie and session middleware config for missing security flags. | Inferred |
| Session cookies - insecure defaults in framework config | Partial | Partial | LLM evaluates framework session config for insecure default settings. | Inferred |
| Session: Session fixation | Partial | Partial | LLM analyzes session lifecycle for missing ID regeneration on auth events. | Doc |
| Session fixation - session ID not rotated on login | Partial | Partial | LLM traces auth/session flow for missing session rotation on login. | Inferred |
| Session fixation - session ID accepted from URL | Partial | Partial | LLM checks request parsing for session ID acceptance from URL parameters. | Inferred |
| Session: Session hijacking | Partial | Partial | LLM analyzes session controls for missing binding and security attributes. | Doc |
| Session hijacking - missing IP/UA binding or alerts | Partial | Partial | LLM checks session logic for missing IP/user-agent binding. | Inferred |
| Session hijacking - cookies not secure/httponly | Partial | Partial | LLM verifies cookie configuration includes Secure and HttpOnly flags. | Inferred |
| Session: Token replay analysis | Partial | Partial | LLM analyzes token lifecycle for rotation and replay prevention. | Doc |
| Token replay - long-lived tokens without rotation | Partial | Partial | LLM checks token management for missing rotation on long-lived tokens. | Inferred |
| Token replay - no jti/nonce tracking | Partial | Partial | LLM inspects token validation for missing jti/nonce claim tracking. | Inferred |

## Business Logic Testing

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| Business logic: Abuse flows | Partial | No | Requires workflow and business rule analysis. | Doc |
| Abuse flows - bypass intended workflow steps | Partial | No | Needs state machine/flow analysis. | Inferred |
| Abuse flows - unexpected state transitions allowed | Partial | No | Requires domain logic analysis. | Inferred |
| Business logic: Discount logic manipulation | Partial | No | Requires pricing/discount rule analysis. | Doc |
| Discount manipulation - client-controlled discount fields | Partial | No | Needs data-flow analysis. | Inferred |
| Discount manipulation - missing server-side validation | Partial | No | Requires business rule inspection. | Inferred |
| Business logic: Workflow bypass | Partial | No | Requires step/order enforcement analysis. | Doc |
| Workflow bypass - missing step validation | Partial | No | Needs flow analysis. | Inferred |
| Workflow bypass - direct access to later stages | Partial | No | Requires route/flow inspection. | Inferred |
| Business logic: Multi-step approval skipping | Partial | No | Requires approval workflow analysis. | Doc |
| Approval skipping - approvals not enforced in code | Partial | No | Needs business rule inspection. | Inferred |
| Approval skipping - missing role checks at approval steps | Partial | No | Requires authz analysis. | Inferred |
| Business logic: Race condition testing | Partial | No | Requires concurrency/transaction analysis. | Doc |
| Race conditions - missing transaction isolation/locking | Partial | No | Needs DB/transaction analysis. | Inferred |
| Race conditions - double-submit endpoints without idempotency | Partial | No | Requires idempotency checks. | Inferred |
| Business logic note: Hardest area to automate | Partial | No | Doc note; indicates partial inference via state machine/LLM. | Doc |

## Compliance & Governance

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| Compliance: OWASP ASVS | Partial | No | Requires mapping controls to code/config. | Doc |
| OWASP ASVS - map requirements to implemented controls | Partial | No | Needs control mapping. | Inferred |
| OWASP ASVS - identify gaps in auth/session/crypto controls | Partial | No | Requires policy mapping. | Inferred |
| Compliance: PCI-DSS (credit card handling) | Partial | No | Requires data flow + storage analysis. | Doc |
| PCI-DSS - detect PAN storage/processing locations | Partial | No | Requires data classification. | Inferred |
| PCI-DSS - validate encryption and key management | Partial | No | Needs config/crypto analysis. | Inferred |
| Compliance: HIPAA (health data) | Partial | No | Requires PHI identification and policy mapping. | Doc |
| HIPAA - detect PHI handling in data flows | Partial | No | Requires data classification. | Inferred |
| HIPAA - ensure access logging for PHI | Partial | No | Needs logging analysis. | Inferred |
| Compliance: GDPR (PII leakage) | Partial | No | Requires PII identification and policy mapping. | Doc |
| GDPR - detect PII fields and processing purposes | Partial | No | Requires data classification. | Inferred |
| GDPR - verify data retention and deletion logic | Partial | No | Requires policy/code analysis. | Inferred |
| Compliance: ISO 27001 control checks | Partial | No | Requires mapping controls to practices. | Doc |
| ISO 27001 - identify required security controls | Partial | No | Requires governance mapping. | Inferred |
| ISO 27001 - verify security policies in code/config | Partial | No | Needs policy mapping. | Inferred |
| Compliance: SOC2 audit preparation | Partial | No | Requires control evidence mapping. | Doc |
| SOC2 - map trust criteria to controls | Partial | No | Requires governance analysis. | Inferred |
| SOC2 - collect evidence from code/config/logs | Partial | No | Requires audit evidence pipeline. | Inferred |
| Compliance note: mapping-level checks can be automated | Partial | No | Doc note; indicates scope for mapping automation. | Doc |

## Data Exposure & PII Leakage

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| Data exposure: Email leakage | Partial | No | Requires log/response/data classification analysis. | Doc |
| Email leakage - email patterns in logs or responses | Partial | No | Requires content scanning beyond regex rules. | Inferred |
| Email leakage - emails embedded in frontend bundles | Partial | No | Requires bundle scanning. | Inferred |
| Data exposure: Phone number leakage | Partial | No | Requires log/response/data classification analysis. | Doc |
| Phone leakage - phone patterns in logs or responses | Partial | No | Requires content scanning. | Inferred |
| Phone leakage - phone numbers in frontend bundles | Partial | No | Requires bundle scanning. | Inferred |
| Data exposure: Sensitive logs | Partial | Partial | LLM analyzes log statements for sensitive data (passwords, tokens, PII) exposure. | Doc |
| Sensitive logs - passwords/tokens logged | Partial | Partial | LLM detects log statements that include password, token, or secret variables. | Inferred |
| Sensitive logs - full request bodies logged | Partial | Partial | LLM identifies log calls that dump full request/response bodies. | Inferred |
| Data exposure: Debug data exposure | Partial | Partial | LLM analyzes error handlers and debug config for data exposure to clients. | Doc |
| Debug exposure - stack traces returned to clients | Partial | Partial | LLM identifies error handlers that return stack traces in responses. | Inferred |
| Debug exposure - debug endpoints enabled | Partial | Partial | LLM detects debug/diagnostic endpoints enabled in production config. | Inferred |
| Data exposure: API responses leaking internal IDs | Partial | No | Requires response schema analysis. | Doc |
| API response leakage - expose internal IDs without need | Partial | No | Needs serializer/DTO inspection. | Inferred |
| API response leakage - expose database keys or secrets | Partial | No | Requires data classification. | Inferred |
| Data exposure: JS bundles leaking secrets | Partial | No | Requires bundle/source map scanning. | Doc |
| JS bundle secrets - API keys embedded in JS | Partial | No | Requires build output scanning. | Inferred |
| JS bundle secrets - sensitive endpoints or tokens in bundles | Partial | No | Requires bundle scanning. | Inferred |

## Performance + Security Hybrid

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| Performance+Security: Rate-limit bypass | Partial | No | Requires rate limiting design and runtime testing. | Doc |
| Rate-limit bypass - missing keying on user/IP/device | Partial | No | Needs policy/config analysis. | Inferred |
| Rate-limit bypass - multiple endpoints share no global limits | Partial | No | Requires rate-limit design review. | Inferred |
| Performance+Security: DoS against login pages | No | No | Requires runtime load testing. | Doc |
| DoS login - high request volume throttling tests | No | No | Runtime testing. | Inferred |
| DoS login - resource exhaustion via slow requests | No | No | Runtime testing. | Inferred |
| Performance+Security: Expensive operations triggering timeouts | Partial | No | Requires code path cost analysis and runtime testing. | Doc |
| Expensive ops - unbounded queries or N+1 patterns | Partial | No | Requires query/path analysis. | Inferred |
| Expensive ops - large payload processing without limits | Partial | No | Requires input validation analysis. | Inferred |
| Performance+Security: API flood resistance | No | No | Requires runtime load testing. | Doc |
| API flood resistance - rate limits and circuit breakers | Partial | No | Requires config/policy analysis. | Inferred |
| API flood resistance - autoscaling and backpressure | No | No | Requires runtime/infra analysis. | Inferred |

## Threat Modeling

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| Threat modeling: Attack surface mapping | Partial | No | Can be inferred from routes/endpoints but requires modeling. | Doc |
| Attack surface mapping - enumerate routes/endpoints from code | Partial | No | Requires framework-specific route discovery. | Inferred |
| Attack surface mapping - identify externally exposed services | Partial | No | Requires deployment/IaC analysis. | Inferred |
| Threat modeling: STRIDE analysis | Partial | No | Requires architectural/context modeling. | Doc |
| STRIDE analysis - map threats to components/data flows | Partial | No | Needs system modeling. | Inferred |
| STRIDE analysis - prioritize threats by impact/likelihood | Partial | No | Requires risk analysis. | Inferred |
| Threat modeling: Data flow modelling | Partial | No | Requires data flow graphing. | Doc |
| Data flow modelling - identify trust boundaries | Partial | No | Needs architecture modeling. | Inferred |
| Data flow modelling - map sensitive data paths | Partial | No | Requires data classification. | Inferred |
| Threat modeling: Misuse case generation | Partial | No | Requires domain knowledge and modeling. | Doc |
| Misuse cases - derive abuse cases from business flows | Partial | No | Needs flow modeling. | Inferred |
| Misuse cases - identify privilege escalation paths | Partial | No | Requires threat analysis. | Inferred |
| Threat modeling: LLM-assisted threat generation | No | No | Requires LLM tooling and context. | Doc |
| LLM-assisted threats - generate threat candidates from code/docs | Partial | No | Requires LLM integration. | Inferred |
| Threat modeling note: pairs with Maeris | Partial | No | Doc note; indicates strategic fit. | Doc |

## Summary Master List (Flat)

| Check | Static feasible? | Current support? | Justification | Source |
| --- | --- | --- | --- | --- |
| Summary: OWASP Top 10 | Partial | Partial | LLM-guided analysis covers most static-feasible A01-A10 checks through principle-based reasoning. | Doc |
| OWASP Top 10 - map findings to A01-A10 categories | Partial | Partial | LLM maps findings to OWASP categories; broad coverage via data-flow and config analysis. | Inferred |
| Summary: OWASP API Top 10 | Partial | Partial | LLM analyzes API handlers for authz, injection, mass assignment, and config issues. | Doc |
| OWASP API Top 10 - inventory endpoints vs API risks | Partial | Partial | LLM inventories API endpoints and evaluates them against API security risks. | Inferred |
| Summary: ZAP scanning | No | No | Requires runtime scanner. | Doc |
| ZAP scanning - policy-based active scan | No | No | Runtime testing. | Inferred |
| Summary: Burp scanning | No | No | Requires runtime scanner. | Doc |
| Burp scanning - active scan profiles | No | No | Runtime testing. | Inferred |
| Summary: Nmap scanning | No | No | Requires live network scanning. | Doc |
| Nmap scanning - host discovery and port scan | No | No | Runtime network test. | Inferred |
| Summary: CVE detection | Partial | Yes | OSV.dev integration provides automated CVE detection for dependency manifests. | Doc |
| CVE detection - match dependency versions to CVE DB | Partial | Yes | OSV.dev API matches dependency versions against the OSV vulnerability database. | Inferred |
| Summary: Library fingerprinting | Partial | Yes | OSV.dev parses manifests/lockfiles; LLM identifies versions in code/config. | Doc |
| Library fingerprinting - parse manifests/lockfiles for versions | Partial | Yes | OSV.dev automatically parses manifests and lockfiles for dependency versions. | Inferred |
| Summary: TLS analysis | Partial | Partial | LLM analyzes TLS/SSL configuration in server and proxy config files. | Doc |
| TLS analysis - verify min TLS version and ciphers | Partial | Partial | LLM checks server config for TLS version and cipher suite settings. | Inferred |
| Summary: Security header analysis | Partial | Partial | LLM checks server/middleware config for security header presence and values. | Doc |
| Security headers - CSP/HSTS/X-Frame-Options presence | Partial | Partial | LLM identifies missing security headers in middleware and server config. | Inferred |
| Summary: Cookie/session security | Partial | Partial | LLM analyzes cookie and session configuration for security attributes. | Doc |
| Cookie/session security - Secure/HttpOnly/SameSite flags | Partial | Partial | LLM checks cookie middleware config for Secure/HttpOnly/SameSite flags. | Inferred |
| Summary: SSRF testing | Partial | Partial | LLM traces user-controlled URLs into HTTP clients plus regex patterns. | Doc |
| SSRF testing - dynamic URL in HTTP client | Partial | Yes | Covered by regex and LLM data-flow analysis for dynamic URL in HTTP clients. | Inferred |
| Summary: CSRF detection | Partial | Partial | LLM analyzes form handlers and state-changing endpoints for CSRF token validation. | Doc |
| CSRF detection - missing CSRF token validation | Partial | Partial | LLM performs framework-aware analysis of CSRF protection on state-changing routes. | Inferred |
| Summary: XSS/SSTI/SQLi injections | Partial | Partial | LLM-guided data-flow analysis traces untrusted input to injection sinks, plus regex patterns. | Doc |
| XSS/SSTI/SQLi - SQL concatenation and DOM sinks | Yes | Yes | Covered by regex and LLM data-flow analysis. | Inferred |
| Summary: Path traversal | Partial | Partial | LLM traces user input into file path operations and checks for sanitization. | Doc |
| Path traversal - ../ or encoded traversal in file ops | Partial | Partial | LLM traces user input to file access APIs, checking for path sanitization. | Inferred |
| Summary: File upload vulnerabilities | Partial | Partial | LLM analyzes upload handlers for missing content-type and extension validation. | Doc |
| File upload vulns - missing content-type/extension validation | Partial | Partial | LLM checks upload handlers for content-type/extension/size validation. | Inferred |
| Summary: Directory traversal | Partial | Partial | LLM traces path construction from user input to file system operations. | Doc |
| Directory traversal - unsanitized path joins | Partial | Partial | LLM identifies unsanitized path.join with user-controlled segments. | Inferred |
| Summary: Access control testing | Partial | Partial | LLM analyzes route handlers for missing authorization checks. | Doc |
| Access control testing - missing auth guards on endpoints | Partial | Partial | LLM checks route/middleware definitions for missing auth guards. | Inferred |
| Summary: Broken auth testing | Partial | Partial | LLM analyzes auth flows for weak policies and missing controls. | Doc |
| Broken auth testing - weak password/MFA policies | Partial | Partial | LLM inspects password validation and MFA enforcement logic. | Inferred |
| Summary: API auth/token testing | Partial | Partial | LLM inspects JWT validation, token scopes, and API auth middleware. | Doc |
| API auth/token testing - JWT validation and scopes | Partial | Partial | LLM checks auth middleware for JWT validation, scope enforcement, and expiry. | Inferred |
| Summary: Cloud security checks | Partial | Partial | LLM analyzes IaC and cloud config files for IAM/storage/network issues. | Doc |
| Cloud security checks - IAM/storage/network policies | Partial | Partial | LLM parses IaC templates for overly permissive IAM, public storage, and open network rules. | Inferred |
| Summary: Container/K8s security | Partial | Partial | LLM analyzes Dockerfiles and K8s manifests for security misconfigurations. | Doc |
| Container/K8s security - privileged and RBAC checks | Partial | Partial | LLM checks container manifests for privileged mode, RBAC wildcards, and insecure configs. | Inferred |
| Summary: Runtime (RASP) detection | No | No | Requires runtime instrumentation. | Doc |
| RASP detection - block XSS/SQL/SSRF at runtime | No | No | Runtime instrumentation required. | Inferred |
| Summary: Code scanning (SAST) | Yes | Yes | LLM-guided analysis provides comprehensive static code scanning with data-flow reasoning. | Doc |
| Code scanning - LLM-guided detection of dangerous APIs and patterns | Yes | Yes | LLM performs principle-based security analysis beyond fixed regex patterns. | Inferred |
| Summary: Dep vulnerability scanning | Partial | Yes | OSV.dev integration provides automated dependency vulnerability scanning. | Doc |
| Dep scanning - lockfile version + CVE mapping | Partial | Yes | OSV.dev automatically maps dependency versions to known vulnerabilities. | Inferred |
| Summary: Threat modeling | Partial | Partial | LLM can infer attack surfaces and data flows from code analysis. | Doc |
| Threat modeling - attack surface and data flow mapping | Partial | Partial | LLM identifies attack surfaces, entry points, and sensitive data flows during analysis. | Inferred |
| Summary: Business logic pentesting | Partial | Partial | LLM reasons about workflow logic and state management patterns. | Doc |
| Business logic pentesting - abuse flow modeling | Partial | Partial | LLM analyzes state machines and workflow logic for bypass opportunities. | Inferred |
| Summary: Compliance scans (PCI, GDPR, ISO) | Partial | Partial | LLM can identify data handling patterns relevant to compliance requirements. | Doc |
| Compliance scans - map controls to code/config | Partial | Partial | LLM maps security controls in code/config against compliance requirements. | Inferred |
| Summary: PII detection | Partial | Partial | LLM identifies PII handling patterns in code, logs, and responses. | Doc |
| PII detection - LLM-guided PII detection in logs/responses | Partial | Partial | LLM applies semantic analysis to detect PII exposure in logging and response handling. | Inferred |
| Summary: Data exposure scan | Partial | Partial | LLM analyzes response serialization, logging, and config for data exposure. | Doc |
| Data exposure scan - sensitive fields in responses | Partial | Partial | LLM checks serializers and response handlers for sensitive field exposure. | Inferred |
| Summary: Rate limiting + brute force detection | Partial | Partial | LLM checks auth endpoints for missing rate-limiting and lockout mechanisms. | Doc |
| Rate limit/brute force - missing throttling on auth | Partial | Partial | LLM analyzes auth route middleware for rate-limiting configuration. | Inferred |
| Summary: DoS resistance tests | No | No | Requires runtime load testing. | Doc |
| DoS resistance - load tests for resource exhaustion | No | No | Runtime testing. | Inferred |
