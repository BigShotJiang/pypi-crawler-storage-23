# Maeris Security Scan — OWASP Categories & Analysis Guide

This document defines the vulnerability categories covered by the Maeris security scanner and provides guidance for the LLM-guided analysis engine. Each category describes **what to look for** and **how to reason about it** — not an exhaustive list of patterns. The LLM should use its full security expertise to identify vulnerabilities within each category, including novel patterns not explicitly listed here.

## Analysis Approach

The scanner uses **principle-based reasoning** rather than pattern matching:

1. **Taint analysis** — Trace untrusted input (HTTP params, headers, body, cookies, URL paths, file uploads, environment variables, external API responses) through the code to sensitive sinks (databases, OS commands, file system, network requests, template engines, serialization).
2. **Missing controls** — Check for the ABSENCE of security mechanisms: authentication, authorization, input validation, output encoding, rate limiting, encryption, security headers.
3. **Configuration review** — Evaluate framework/server configuration for security misconfigurations, overly permissive policies, debug flags, and information disclosure.
4. **Cryptographic assessment** — Review secret management, algorithm choices, key strength, token validation, and cookie security.
5. **Dependency analysis** — Flag known vulnerable packages (via OSV.dev automated scanning) and packages with dangerous capabilities used with untrusted input.
6. **Architectural reasoning** — Identify framework-specific risks, improper trust boundaries, and business logic vulnerabilities.

---

## 1. OWASP Top 10

#### **A01 – Broken Access Control**

*Core question: Can users access resources or perform actions beyond their intended permissions?*

* Role escalation checks
* Unauthenticated access
* Horizontal privilege escalation
* Vertical privilege escalation
* Forced browsing
* IDOR testing
* URL manipulation & open redirects
* Access bypass via headers/cookies
* Multi-tenant boundary testing
* Mass assignment / unprotected fields

#### **A02 – Cryptographic Failures**

*Core question: Is sensitive data protected with appropriate cryptography at rest and in transit?*

* Hardcoded secrets, API keys, DB credentials, and fallback values in source
* Weak hashing algorithms for passwords/tokens (MD5, SHA1 vs bcrypt/argon2)
* Weak TLS protocols (SSLv2, SSLv3, TLS 1.0/1.1)
* Weak cipher suites
* Missing HSTS
* Mixed content
* Sensitive data over HTTP
* Weak cookie attributes (missing Secure, HttpOnly, SameSite)
* Improper key lengths
* JWT secret strength and algorithm restrictions

#### **A03 – Injection**

*Core question: Can untrusted data reach an interpreter (SQL, OS, template, HTML, LDAP, etc.) without proper sanitization?*

* SQL injection (string concatenation, ORM raw queries)
* NoSQL injection ($where, query object manipulation)
* Command injection (shell execution with user input — all languages)
* Server Side Template Injection (SSTI)
* LDAP injection
* HTML injection / XSS (DOM, reflected, stored)
* Client-side code execution (eval, new Function, dangerouslySetInnerHTML)
* Header injection
* Unsafe deserialization (pickle, yaml.unsafe_load, node-serialize, etc.)

#### **A04 – Insecure Design**

*Core question: Are security controls designed into the application, or are fundamental protections missing?*

* Missing rate limits on authentication and sensitive endpoints
* Absent account lockout / exponential backoff
* Weak session lifecycle (no rotation, no TTL enforcement)
* Password reset flow flaws (token reuse, no expiry, no binding)
* No defense-in-depth mechanisms

#### **A05 – Security Misconfiguration**

*Core question: Are security settings properly configured across the entire stack?*

* Directory listing enabled
* Unpatched application servers
* Debug mode / verbose errors enabled in production
* Missing security headers (CSP, HSTS, X-Frame-Options, X-Content-Type-Options)
* Unsafe HTTP methods enabled without authentication
* CORS misconfiguration (wildcard origins, origin reflection)
* Information disclosure via X-Powered-By or error responses
* Permissive framework config (next.config, nuxt.config, etc.)

#### **A06 – Vulnerable & Outdated Components**

*Core question: Does the application use components with known vulnerabilities?*
*Note: Maeris performs automated CVE scanning via OSV.dev for package.json and requirements.txt.*

* JS library fingerprinting
* Package version detection from manifests/lockfiles
* Automated CVE matching via OSV.dev API
* Known vulnerable dependencies (denylist packages)
* Packages with dangerous capabilities used with untrusted input
* SBOM-based vulnerability mapping

#### **A07 – Identification & Authentication Failures**

*Core question: Can an attacker compromise authentication mechanisms or session management?*

* Brute-force susceptibility (missing rate limiting / lockout)
* Session fixation (no regeneration on login)
* Session ID predictability (weak RNG)
* No MFA on privileged actions
* Weak password policy enforcement
* Insecure remember-me tokens (long-lived, no rotation)
* Tokens stored in localStorage (XSS-accessible)

#### **A08 – Software & Data Integrity Failures**

*Core question: Can data or code integrity be compromised through deserialization, dependency, or delivery chain attacks?*

* Unsafe deserialization (pickle, yaml.unsafe_load, node-serialize, etc.)
* Prototype pollution via deep merge of untrusted objects
* Unverified dependencies (missing checksums, unsigned artifacts)
* Integrity of delivered JS (missing SRI for CDN scripts)
* Supply chain vulnerability analysis

#### **A09 – Logging & Monitoring Failures**

*Core question: Would a breach go undetected, and are logs safe from leaking sensitive data?*

* Missing audit logs for auth and admin actions
* No anomaly detection / SIEM integration
* Sensitive data in logs (passwords, tokens, PII, full request bodies)
* No security event alerts

#### **A10 – SSRF**

*Core question: Can an attacker make the server issue requests to unintended destinations?*

* URL-fetch endpoints (fetch, axios, requests, urllib with user-controlled URLs)
* Unsafe webhooks (no URL allowlisting, no signature verification)
* Internal IP probing (no internal IP range blocking)
* DNS rebinding tests (no DNS pinning)

## 2. API Security Testing

(Aligned with **OWASP API Top 10** — the LLM should reason about each API endpoint's authorization model, input handling, and response filtering)

1. **API1:2019 – Broken Object Level Authorization (BOLA)**

2. **API2 – Broken Authentication**

3. **API3 – Excessive Data Exposure**

4. **API4 – Lack of Rate Limiting**

5. **API5 – Broken Function Level Authorization**

6. **API6 – Mass Assignment**

7. **API7 – Security Misconfigurations**

8. **API8 – Injection**

9. **API9 – Improper Asset Management**

10. **API10 – Server-Side Request Forgery**

API-specific checks also include:

* JWT token analysis

* OAuth2/OpenID Connect misconfigurations

* API key leakage detection

* GraphQL introspection abuse

* gRPC enumeration

* WSDL/SOAP discovery

## 3. Network Security / Pentesting

(Traditional pentest tools: **Nmap**, **Nikto**, **ZAP**, **Burp**, etc.)

### **Nmap (Network Mapping)**

* Port scanning

* Service detection

* OS fingerprinting

* TLS fingerprinting

* Vulnerability scripts

* Firewall/IDS evasion

* Host discovery

### **Vulnerability Scanning**

* Open ports → known vulnerabilities (NSE scripts, Vulners API)

* SMB tests

* FTP misconfigurations

* SSH hardening analysis

### **Banner Grabbing**

* Identify framework versions

* Exposed infrastructure details

### **Service Enumeration**

* Redis open access

* MongoDB unauthenticated

* Elasticsearch unrestricted access

## 4. DAST — Dynamic Application Security Testing

(Active scanning tools like **OWASP ZAP**, **Burp Active Scan**, **Arachni**)

### **Typical capabilities:**

* Automated spidering \+ crawling

* Active injection tests

* Fuzzing input parameters

* Session handling

* ZAP policy-based scanning

* AJAX spider for SPA apps

* Response analysis for vulnerabilities

* CSRF token analysis

### **Vulnerability categories covered:**

* SQLi

* XSS

* CSRF

* Path traversal

* XXE

* Open redirect

* CORS misconfig

* Content sniffing issues

* Authentication flaws

## 5. SAST — Static Application Security Testing

(Code-level scanning — this is the primary mode of the Maeris LLM-guided scanner)

*The LLM performs deep static analysis by reasoning about code semantics, tracing data flows, and applying security principles — not just matching patterns.*

* Hardcoded secrets detection (passwords, API keys, credentials, fallback values)
* Dependency vulnerability scanning (automated via OSV.dev + LLM knowledge)
* Code-level injection detection (SQL, NoSQL, command, XSS, SSTI, etc.)
* Unsafe crypto usage (weak algorithms, short keys, insecure parameters)
* Dangerous APIs (eval, exec, deserialization, dynamic code loading)
* Input validation mistakes (missing allowlists, direct param usage in sinks)
* Broken access logic in code (missing auth checks, bypassable authorization)
* Static taint analysis (source-to-sink data flow tracing via LLM reasoning)
* Framework-specific security patterns and anti-patterns

Tools: Semgrep, SonarQube, Checkmarx, Veracode, GitHub CodeQL

---

## 6. IAST — Interactive Application Security Testing

(Run app with instrumentation)

* Detect runtime injection

* Monitor tainted variables

* Track unsafe deserialization

* Detect SSRF at runtime

* Memory-based analysis

* Real-time API input/output tracking

---

## 7. Cloud Security Testing (AWS, GCP, Azure)

### **IAM Misconfigurations**

* Over-permissive roles

* Unrestricted policies

### **Storage**

* Public S3 buckets

* Public GCP storage

* Misconfigured Azure Blobs

### **Network**

* Open security groups

* Publicly exposed databases

### **Cloud metadata attacks**

* IMDSv1 misuse

Tools: ScoutSuite, Prowler, CloudSploit

---

## 8. Container & DevOps Security

### **Docker**

* Insecure base images

* Privileged containers

* Hardcoded secrets in images

### **Kubernetes**

* RBAC misconfigurations

* Anonymous API access

* Open dashboards

* Insecure pod security policies

### **CI/CD pipelines**

* Credential leakage

* Insecure pipelines

Tools: Trivy, Clair, Falco, kube-bench

---

## 9. Runtime Security / Observability (RASP)

* Detect XSS injection attempts

* Detect unwanted SQL strings

* Identify active path traversal

* Block SSRF attempts

* Monitor unusual session behavior

---

## 10. Authentication & Authorization Security

*The LLM should trace auth flows end-to-end: login, token issuance, validation, session management, and logout.*

* Password brute-force detection (missing rate limiting / lockout)
* Credential stuffing detection (missing bot/anomaly detection)
* Weak login flows (missing MFA, bypassable password reset)
* OAuth misconfigurations (redirect URI wildcards, missing PKCE, implicit flow)
* JWT weakness tests:
  * Algorithm manipulation (none alg, algorithm confusion)
  * Weak HMAC keys / hardcoded secrets
  * Missing claim validation (exp, iss, aud, nbf)
  * kid header injection / path traversal

---

## 11. Session Security

* SameSite/HttpOnly/Secure checks

* Session fixation

* Session hijacking

* Token replay analysis

---

## 12. Business Logic Testing

* Abuse flows

* Discount logic manipulation

* Workflow bypass

* Multi-step approval skipping

* Race condition testing

*Hardest area to automate, but the LLM-guided scanner can partially infer business logic issues by reasoning about state machine flows, missing validation steps, and race conditions in code.*

---

## 13. Compliance & Governance

* OWASP ASVS

* PCI-DSS (credit card handling)

* HIPAA (health data)

* GDPR (PII leakage)

* ISO 27001 control checks

* SOC2 audit preparation

*Maeris can automate many mapping-level checks by having the LLM reason about which controls are present in code/config and mapping them to compliance requirements.*

---

## 14. Data Exposure & PII Leakage

* Email leakage

* Phone number leakage

* Sensitive logs

* Debug data exposure

* API responses leaking internal IDs

* JS bundles leaking secrets

---

## 15. Performance + Security Hybrid

* Rate-limit bypass

* DoS against login pages

* Expensive operations triggering timeouts

* API flood resistance

---

## 16. Threat Modeling

* Attack surface mapping

* STRIDE analysis

* Data flow modelling

* Misuse case generation

* LLM-assisted threat generation

*Threat modeling is a natural strength of the LLM-guided scanner — it can reason about attack surfaces, data flows, and abuse scenarios from code structure.*

---

## Summary: Full Security Coverage

Below is the **flat master list** for quick reference:

* OWASP Top 10

* OWASP API Top 10

* ZAP scanning

* Burp scanning

* Nmap scanning

* CVE detection

* Library fingerprinting

* TLS analysis

* Security header analysis

* Cookie/session security

* SSRF testing

* CSRF detection

* XSS/SSTI/SQLi injections

* Path traversal

* File upload vulnerabilities

* Directory traversal

* Access control testing

* Broken auth testing

* API auth/token testing

* Cloud security checks

* Container/K8s security

* Runtime (RASP) detection

* Code scanning (SAST)

* Dep vulnerability scanning

* Threat modeling

* Business logic pentesting

* Compliance scans (PCI, GDPR, ISO)

* PII detection

* Data exposure scan

* Rate limiting \+ brute force detection

* DoS resistance tests

