"""Universal eval primitive for Wafer CLI.

One command, two modes:
    wafer tool eval --task kernelbench --after ./optimized
    wafer tool eval --task kernelbench --before ./original --after ./optimized

The scorer owns everything: what to run, how to parse output, how to score.
The eval tool is target-agnostic. GPU access is composed via 'wafer target run'.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import typer


def eval_main(
    task: str | None = typer.Option(
        None,
        "--task",
        "-t",
        help="Code scorer name (built-in) or path to .py file (required unless --list-tasks)",
    ),
    after: Path = typer.Option(
        ".",
        "--after",
        "-a",
        help="Directory to evaluate (default: current directory)",
    ),
    before: Path | None = typer.Option(
        None,
        "--before",
        "-b",
        help="Baseline directory for comparison (optional)",
    ),
    list_tasks_flag: bool = typer.Option(
        False,
        "--list-tasks",
        help="List available built-in scorers and exit",
    ),
) -> None:
    """Evaluate kernel correctness and performance"""
    from wafer.eval import list_code_scorers, load_code_scorer

    if list_tasks_flag:
        available = list_code_scorers()
        typer.echo("Available code scorers:")
        for name in available:
            typer.echo(f"  {name}")
        raise typer.Exit(0)

    if not task:
        typer.echo("Error: --task is required. Use --list-tasks to see available code scorers.", err=True)
        raise typer.Exit(1)

    after_dir = after.resolve()
    assert after_dir.is_dir(), f"--after is not a directory: {after_dir}"

    scorer = load_code_scorer(task, resolve_from_dir=after_dir)

    before_dir: Path | None = None
    if before is not None:
        before_dir = before.resolve()
        assert before_dir.is_dir(), f"--before is not a directory: {before_dir}"

    typer.echo(f"[wafer eval] Running scorer {task!r} on {after_dir}", err=True)
    score = asyncio.run(scorer(after_dir, baseline_dir=before_dir))
    print(json.dumps(score.to_dict(), indent=2))
