"""Sandbox heartbeat daemon.

Runs inside each managed sandbox (tmux session on a GPU target).
Responsibilities:
- Track agent PIDs via /tmp/.wafer_sandbox/{sandbox_id}/pids/
- Monitor GPU utilization (vendor-specific)
- Detect GPU-blocked processes via /proc status
- Write gpu_status.json every 1s
- Extend TTL every 30s via poll_queue_entry (when queue_id provided)
- Release machine when ALL agents exit via release_and_promote (when queue_id provided)
- Push metrics to wafer-api every 5s (when WAFER_API_URL / WAFER_AUTH_TOKEN set)

Invoked as: wafer sandbox _heartbeat --sandbox-id X --gpu-vendor V --gpu-count N [--queue-id Q]
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path

import httpx

logger = logging.getLogger(__name__)

_PUSH_INTERVAL_SEC = 5


@dataclass(frozen=True)
class GpuUtilSnapshot:
    gpu_id: int
    util_pct: float
    mem_used_mb: float


@dataclass(frozen=True)
class BlockedProcess:
    pid: int
    cmd: str
    state: str


def read_pid_files(pids_dir: Path) -> list[int]:
    """Read all PID files from the sandbox pids directory."""
    pids = []
    if not pids_dir.exists():
        return pids
    for f in pids_dir.iterdir():
        if f.suffix == ".pid":
            try:
                pid = int(f.read_text().strip())
                pids.append(pid)
            except (ValueError, OSError):
                continue
    return pids


def pid_exists(pid: int) -> bool:
    """Check if a process exists."""
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def remove_pid_file(pids_dir: Path, pid: int) -> None:
    """Remove PID file for a dead process."""
    for f in pids_dir.iterdir():
        if f.suffix == ".pid":
            try:
                if int(f.read_text().strip()) == pid:
                    f.unlink(missing_ok=True)
            except (ValueError, OSError):
                continue


def get_all_descendants(pids: list[int]) -> list[int]:
    """Get all PIDs including children of the given PIDs."""
    all_pids = list(pids)
    for pid in pids:
        children_dir = Path(f"/proc/{pid}/task")
        if children_dir.exists():
            try:
                children_file = Path(f"/proc/{pid}/children")
                if children_file.exists():
                    child_pids = children_file.read_text().strip().split()
                    all_pids.extend(int(p) for p in child_pids if p)
            except (OSError, ValueError):
                pass
    return all_pids


def detect_blocked_processes(agent_pids: list[int]) -> list[BlockedProcess]:
    """Detect processes in D (uninterruptible sleep) state via /proc."""
    blocked = []
    for pid in get_all_descendants(agent_pids):
        try:
            status = Path(f"/proc/{pid}/status").read_text()
            state_line = [line for line in status.splitlines() if line.startswith("State:")]
            if not state_line:
                continue
            state = state_line[0].split()[1]
            if state == "D":
                cmdline = Path(f"/proc/{pid}/cmdline").read_text().replace("\0", " ").strip()
                blocked.append(BlockedProcess(pid=pid, cmd=cmdline, state="gpu_blocked"))
        except (FileNotFoundError, IndexError, OSError):
            continue
    return blocked


def query_gpu_util(gpu_id: int, vendor: str) -> GpuUtilSnapshot:
    """Query GPU utilization for a single GPU."""
    try:
        if vendor == "nvidia":
            out = subprocess.run(
                ["nvidia-smi", "--query-gpu=utilization.gpu,memory.used",
                 "--format=csv,noheader,nounits", "-i", str(gpu_id)],
                capture_output=True, text=True, timeout=5,
            )
            if out.returncode == 0:
                parts = out.stdout.strip().split(",")
                return GpuUtilSnapshot(
                    gpu_id=gpu_id,
                    util_pct=float(parts[0].strip()),
                    mem_used_mb=float(parts[1].strip()),
                )
        elif vendor == "amd":
            out = subprocess.run(
                ["rocm-smi", "-d", str(gpu_id), "--showuse", "--csv"],
                capture_output=True, text=True, timeout=5,
            )
            return GpuUtilSnapshot(gpu_id=gpu_id, util_pct=0.0, mem_used_mb=0.0)
        elif vendor == "trainium":
            return GpuUtilSnapshot(gpu_id=gpu_id, util_pct=0.0, mem_used_mb=0.0)
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return GpuUtilSnapshot(gpu_id=gpu_id, util_pct=0.0, mem_used_mb=0.0)


async def _push_to_api(api_url: str, auth_token: str, payload: dict) -> None:
    """POST heartbeat to wafer-api. Best-effort, no retries."""
    import httpx

    async with httpx.AsyncClient(timeout=5) as client:
        await client.post(
            f"{api_url}/v1/user-targets/heartbeat",
            headers={"Authorization": f"Bearer {auth_token}"},
            json=payload,
        )


async def heartbeat_loop(
    sandbox_id: str,
    queue_id: str | None,
    gpu_vendor: str,
    gpu_count: int,
) -> None:
    """Main heartbeat loop. Runs until all agents exit."""
    last_ttl_refresh = time.monotonic()
    last_push = 0.0
    sandbox_dir = Path(f"/tmp/.wafer_sandbox/{sandbox_id}")
    pids_dir = sandbox_dir / "pids"
    status_file = sandbox_dir / "gpu_status.json"

    api_url = os.environ.get("WAFER_API_URL")
    auth_token = os.environ.get("WAFER_AUTH_TOKEN")

    pids_dir.mkdir(parents=True, exist_ok=True)

    while True:
        tracked_pids = read_pid_files(pids_dir)
        alive_pids = [p for p in tracked_pids if pid_exists(p)]
        dead_pids = [p for p in tracked_pids if p not in alive_pids]

        for pid in dead_pids:
            remove_pid_file(pids_dir, pid)

        gpu_utils = [query_gpu_util(i, gpu_vendor) for i in range(gpu_count)]

        blocked = detect_blocked_processes(alive_pids) if alive_pids else []

        payload = {
            "sandbox_id": sandbox_id,
            "gpu_vendor": gpu_vendor,
            "gpu_count": gpu_count,
            "gpus": [
                {"gpu_id": g.gpu_id, "utilization_pct": g.util_pct, "memory_used_mb": g.mem_used_mb}
                for g in gpu_utils
            ],
            "agents_alive": len(alive_pids),
            "agents_total": len(tracked_pids),
            "blocked_processes": [
                {"pid": b.pid, "cmd": b.cmd, "state": b.state}
                for b in blocked
            ],
            "timestamp": time.time(),
        }

        status_file.write_text(json.dumps(payload))

        if api_url and auth_token and (time.monotonic() - last_push >= _PUSH_INTERVAL_SEC):
            try:
                await _push_to_api(api_url, auth_token, payload)
            except (httpx.HTTPError, httpx.RequestError, OSError):
                logger.debug("Failed to push heartbeat to API", exc_info=True)
            last_push = time.monotonic()

        if tracked_pids and not alive_pids:
            if queue_id:
                from wafer.cli.gpu_queue_api import release_and_promote
                await release_and_promote(queue_id)
            logger.info("All agents exited. Released machine for sandbox %s", sandbox_id)
            break

        if queue_id and time.monotonic() - last_ttl_refresh > 30:
            from wafer.cli.gpu_queue_api import poll_queue_entry
            await poll_queue_entry(queue_id)
            last_ttl_refresh = time.monotonic()

        await asyncio.sleep(1)


def run_heartbeat(
    sandbox_id: str,
    queue_id: str | None,
    gpu_vendor: str,
    gpu_count: int,
) -> None:
    """Entry point for the heartbeat daemon."""
    asyncio.run(heartbeat_loop(sandbox_id, queue_id, gpu_vendor, gpu_count))
