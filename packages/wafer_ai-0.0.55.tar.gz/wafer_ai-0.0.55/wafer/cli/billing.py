"""Billing CLI - Manage credits and subscription.

This module provides the implementation for the `wafer billing` subcommand.
"""

import json

import httpx

from .api_client import get_api_url
from .auth import get_auth_headers


def _get_client() -> tuple[str, dict[str, str]]:
    """Get API URL and auth headers."""
    api_url = get_api_url()
    headers = get_auth_headers()

    assert api_url, "API URL must be configured"
    assert api_url.startswith("http"), "API URL must be a valid HTTP(S) URL"

    return api_url, headers


def format_cents(cents: int) -> str:
    """Format cents as a dollar amount.

    Args:
        cents: Amount in cents (e.g., 2500 for $25.00)

    Returns:
        Formatted string (e.g., "$25.00")
    """
    dollars = cents / 100
    return f"${dollars:.2f}"


def validate_topup_amount(amount_cents: int) -> None:
    """Validate topup amount is within allowed range.

    Args:
        amount_cents: Amount in cents

    Raises:
        ValueError: If amount is out of range ($10-$500)
    """
    min_cents = 1000  # $10
    max_cents = 50000  # $500

    if amount_cents < min_cents:
        raise ValueError(f"Amount must be at least ${min_cents // 100}")

    if amount_cents > max_cents:
        raise ValueError(f"Amount must be at most ${max_cents // 100}")


def format_usage_text(usage: dict) -> str:
    """Format billing usage as human-readable text.

    Args:
        usage: Usage data from API

    Returns:
        Formatted multi-line string
    """
    tier = usage.get("tier", "unknown")
    status = usage.get("status", "unknown")
    credits_used = usage.get("credits_used_cents", 0)
    credits_limit = usage.get("credits_limit_cents", 0)
    credits_remaining = usage.get("credits_remaining_cents", 0)
    topup_balance = usage.get("topup_balance_cents", 0)
    has_hw_counters = usage.get("has_hardware_counters", False)
    has_slack = usage.get("has_slack_access", False)
    period_ends = usage.get("period_ends_at")

    # Capitalize tier for display, remap Start to Hacker
    tier_display = "Hacker" if tier.lower() == "start" else tier.capitalize()

    lines = [
        f"Plan: {tier_display} ({status})",
    ]

    # Status warnings
    if status == "past_due":
        lines.append("  Warning: Payment past due. Update at: wafer billing portal")

    lines.append("")

    # Credits section - different handling for enterprise (unlimited)
    if credits_limit == -1 or tier.lower() == "enterprise":
        lines.extend([
            "Credits:",
            f"  Used this period: {format_cents(credits_used)}",
            "  Plan allowance: Unlimited",
        ])
    else:
        # Show total balance as the primary number (plan remaining + topup)
        total_balance = credits_remaining + topup_balance
        lines.extend([
            "Credits:",
            f"  Balance: {format_cents(total_balance)}",
            f"  Plan allowance: {format_cents(credits_used)} used of {format_cents(credits_limit)}/month",
        ])

    # Topup balance breakdown (only when non-zero, to explain the math)
    if topup_balance > 0:
        lines.append(f"  Topup credits: {format_cents(topup_balance)}")

    lines.append("")

    # Features -- explain what they mean
    included: list[str] = []
    not_included: list[str] = []
    if has_hw_counters:
        included.append("  Hardware performance counters (NCU/NSYS)")
    else:
        not_included.append("  Hardware performance counters (NCU/NSYS)")
    if has_slack:
        included.append("  Priority Slack support")
    else:
        not_included.append("  Priority Slack support")

    if included:
        lines.append("Included features:")
        lines.extend(included)
    if not_included:
        lines.append("Not included (upgrade: wafer billing portal):")
        lines.extend(not_included)

    # Period end date
    if period_ends:
        lines.append("")
        lines.append(f"Period ends: {period_ends}")

    return "\n".join(lines)


def get_usage(json_output: bool = False) -> str:
    """Get billing usage information.

    Args:
        json_output: If True, return raw JSON; otherwise return formatted text

    Returns:
        Usage info as string (JSON or formatted text)

    Raises:
        RuntimeError: On authentication or API errors
    """
    api_url, headers = _get_client()

    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.get(f"{api_url}/v1/billing/usage")
            response.raise_for_status()
            usage = response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e

    if json_output:
        from .output import json_response
        return json_response(data=usage)

    return format_usage_text(usage)


def create_topup(amount_cents: int) -> dict:
    """Create a topup checkout session.

    Args:
        amount_cents: Amount to add in cents (1000-50000)

    Returns:
        Dict with checkout_url and session_id

    Raises:
        RuntimeError: On authentication, validation, or API errors
    """
    api_url, headers = _get_client()

    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.post(
                f"{api_url}/v1/billing/topup",
                json={"amount_cents": amount_cents},
            )
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        if e.response.status_code == 400:
            # Invalid amount
            try:
                detail = e.response.json().get("detail", e.response.text)
            except (json.JSONDecodeError, ValueError):
                detail = e.response.text
            raise RuntimeError(f"Invalid amount: {detail}") from e
        if e.response.status_code == 403:
            raise RuntimeError("Topup not available for your account.") from e
        if e.response.status_code == 503:
            raise RuntimeError("Billing service temporarily unavailable. Please try again later.") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e


def get_portal_url() -> dict:
    """Get Stripe billing portal URL.

    Returns:
        Dict with portal_url

    Raises:
        RuntimeError: On authentication or API errors
    """
    api_url, headers = _get_client()

    try:
        with httpx.Client(timeout=30.0, headers=headers) as client:
            response = client.post(f"{api_url}/v1/billing/portal")
            response.raise_for_status()
            return response.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise RuntimeError("Not authenticated. Run: wafer login") from e
        raise RuntimeError(f"API error: {e.response.status_code} - {e.response.text}") from e
    except httpx.RequestError as e:
        raise RuntimeError(f"Could not reach API: {e}") from e
