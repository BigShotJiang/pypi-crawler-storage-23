# ruff: noqa: PLR0913, E402
"""Tool commands for the Wafer CLI.

All `wafer tool ...` subcommands live here: profiling (Perfetto, ROCprofiler),
analysis (roofline, ISA, compare), execution (eval, baseline, autotuner, capture),
and inspection (TraceLens).
"""
from __future__ import annotations

import os
from collections.abc import Callable
from pathlib import Path
from typing import Any

import typer

# ---------------------------------------------------------------------------
# tool_app + sub-app Typer definitions
# ---------------------------------------------------------------------------

tool_app = typer.Typer(
    name="tool",
    help="Run profiling, evaluation, and analysis tools",
    no_args_is_help=True,
)

perfetto_app = typer.Typer(help="Perfetto trace analysis and SQL queries")
tracelens_app = typer.Typer(help="TraceLens performance reports")

isa_app = typer.Typer(help="ISA analysis for AMD GPU kernels (.co, .s, .ll, .ttgir files)")
compare_app = typer.Typer(help="Compare GPU traces across platforms (AMD vs NVIDIA)")

# Register sub-apps on tool_app
tool_app.add_typer(perfetto_app, name="perfetto", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(tracelens_app, name="tracelens", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(isa_app, name="isa", rich_help_panel="AMD Profiling")
tool_app.add_typer(compare_app, name="compare", rich_help_panel="Analysis")

# External sub-apps
from .problems_cli import problems_app
from .evaluate import eval_main
from .baseline import baseline_app
from .distributed_traces import nvidia_distributed_traces_app, amd_distributed_traces_app

tool_app.command("eval", rich_help_panel="Execution")(eval_main)
tool_app.add_typer(baseline_app, name="baseline", rich_help_panel="Execution")
tool_app.add_typer(nvidia_distributed_traces_app, name="nvidia-distributed-traces", rich_help_panel="NVIDIA Profiling")
tool_app.add_typer(amd_distributed_traces_app, name="amd-distributed-traces", rich_help_panel="AMD Profiling")
tool_app.add_typer(problems_app, name="problems", rich_help_panel="Eval")

# Dynamically-defined sub-apps (registered inline below their commands)
rocprof_sdk_app = typer.Typer(help="ROCprofiler-SDK profiling tool commands")
tool_app.add_typer(rocprof_sdk_app, name="rocprof-sdk", rich_help_panel="AMD Profiling")

rocprof_systems_app = typer.Typer(help="ROCprofiler-Systems profiling tool commands")
tool_app.add_typer(rocprof_systems_app, name="rocprof-systems", rich_help_panel="AMD Profiling")

rocprof_compute_app = typer.Typer(help="ROCprofiler-Compute profiling tool commands")
tool_app.add_typer(rocprof_compute_app, name="rocprof-compute", rich_help_panel="AMD Profiling")

autotuner_app = typer.Typer(help="Hyperparameter sweep for performance engineering")
tool_app.add_typer(autotuner_app, name="autotuner", hidden=True)

capture_app = typer.Typer(help="Capture execution snapshots for reproducibility and comparison")
tool_app.add_typer(capture_app, name="capture", rich_help_panel="Other")


# ---------------------------------------------------------------------------
# Shared helpers (imported from app.py)
# ---------------------------------------------------------------------------

def _mark_command_success() -> None:
    from .app import _mark_command_success as _impl
    _impl()


def _exit_with_error(msg: str) -> None:
    typer.echo(f"Error: {msg}", err=True)
    raise typer.Exit(1) from None


# ===================================================================
# Roofline
# ===================================================================

def _roofline_list_gpus(get_all_gpus: Callable[[], list[str]], get_gpu_spec: Callable[..., Any], json_output: bool) -> None:
    assert callable(get_all_gpus), "get_all_gpus must be callable"
    assert callable(get_gpu_spec), "get_gpu_spec must be callable"

    if json_output:
        from .output import json_response
        gpu_list = []
        for name in get_all_gpus():
            spec = get_gpu_spec(name)
            gpu_list.append({
                "name": name,
                "full_name": spec.name,
                "peak_bandwidth_gbps": spec.peak_bandwidth_gbps,
                "peak_tflops_fp16": spec.peak_tflops_fp16,
                "peak_tflops_fp32": spec.peak_tflops_fp32,
            })
        typer.echo(json_response(data={"gpus": gpu_list}))
    else:
        typer.echo("Available GPUs:")
        for name in get_all_gpus():
            spec = get_gpu_spec(name)
            typer.echo(
                f"  {name}: {spec.peak_bandwidth_gbps:.0f} GB/s, {spec.peak_tflops_fp16:.0f} TFLOPS FP16"
            )


def _roofline_validate_args(
    gpu: str | None, bytes_moved: float | None, flops: float | None,
    time_ms: float | None, json_output: bool,
) -> None:
    assert isinstance(json_output, bool), "json_output must be a bool"
    assert isinstance(gpu, (str, type(None))), "gpu must be str or None"

    missing = []
    if gpu is None:
        missing.append("--gpu")
    if bytes_moved is None:
        missing.append("--bytes")
    if flops is None:
        missing.append("--flops")
    if time_ms is None:
        missing.append("--time-ms")
    if missing:
        if json_output:
            from .output import json_error
            typer.echo(json_error(f"Missing required options: {', '.join(missing)}"))
        else:
            typer.echo(f"Error: Missing required options: {', '.join(missing)}", err=True)
            typer.echo("", err=True)
            typer.echo("Run 'wafer tool roofline --help' for usage.", err=True)
        raise typer.Exit(1)


def _roofline_result_to_dict(result: Any) -> dict[str, Any]:
    assert result is not None, "result must not be None"
    assert hasattr(result, "gpu"), "result must have a gpu attribute"

    return {
        "gpu": result.gpu.name,
        "dtype": result.dtype.value,
        "bottleneck": result.bottleneck.value,
        "arithmetic_intensity": result.arithmetic_intensity,
        "ridge_point": result.ridge_point,
        "efficiency_pct": result.efficiency_pct,
        "bytes_moved": result.bytes_moved,
        "flops": result.flops,
        "actual_time_s": result.actual_time_s,
        "theoretical_time_s": result.theoretical_time_s,
        "memory_bound_time_s": result.memory_bound_time_s,
        "compute_bound_time_s": result.compute_bound_time_s,
        "peak_bandwidth_bytes_per_s": result.peak_bandwidth_bytes_per_s,
        "peak_flops_per_s": result.peak_flops_per_s,
        "achieved_compute_flops_per_s": result.achieved_compute_flops_per_s,
        "achieved_bandwidth_bytes_per_s": result.achieved_bandwidth_bytes_per_s,
        "compute_efficiency_pct": result.compute_efficiency_pct,
        "bandwidth_efficiency_pct": result.bandwidth_efficiency_pct,
    }


@tool_app.command("roofline", rich_help_panel="Analysis")
def roofline_cmd(
    gpu: str | None = typer.Option(
        None, "--gpu", "-g", help="GPU name (e.g., H100, B200, MI300X, A100)"
    ),
    bytes_moved: float | None = typer.Option(
        None, "--bytes", "-b", help="Theoretical minimum bytes moved"
    ),
    flops: float | None = typer.Option(None, "--flops", "-f", help="Theoretical minimum FLOPs"),
    time_ms: float | None = typer.Option(
        None, "--time-ms", "-t", help="Actual kernel time in milliseconds"
    ),
    dtype: str = typer.Option(
        "fp16", "--dtype", "-d", help="Data type for compute ceiling (fp16, fp32, bf16, fp8, int8)"
    ),
    list_gpus: bool = typer.Option(False, "--list-gpus", help="List available GPU specs and exit"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Analyze kernel performance against roofline model

    Examples:
        wafer tool roofline --gpu H100 --bytes 100.7e6 --flops 137.4e12 --time-ms 85
        wafer tool roofline --list-gpus
    """
    from wafer.core.roofline import get_gpu_spec, roofline_analysis
    from wafer.core.roofline import list_gpus as get_all_gpus
    if list_gpus:
        _roofline_list_gpus(get_all_gpus, get_gpu_spec, json_output)
        return
    _roofline_validate_args(gpu, bytes_moved, flops, time_ms, json_output)
    try:
        result = roofline_analysis(
            gpu=gpu, dtype=dtype, bytes_moved=bytes_moved, flops=flops, time_ms=time_ms,
        )
    except ValueError as e:
        if json_output:
            from .output import json_error
            typer.echo(json_error(str(e)))
        else:
            typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    if json_output:
        from .output import json_response
        typer.echo(json_response(data=_roofline_result_to_dict(result)))
    else:
        typer.echo(result.format_report())


# ===================================================================
# Perfetto
# ===================================================================

@perfetto_app.command("query")
def perfetto_query(
    trace_path: Path = typer.Argument(..., help="Path to Perfetto trace file"),
    sql: str = typer.Argument(..., help="SQL query to execute"),
    json_output: bool = typer.Option(True, "--json", "-j", help="Output as JSON"),
) -> None:
    """Execute SQL query against a Perfetto trace."""
    from wafer.core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    try:
        results, err = tool.query(sql, str(trace_path))
        if err:
            typer.echo(f"Error: {err}", err=True)
            raise typer.Exit(1)
        if json_output:
            from .output import json_response
            typer.echo(json_response(data={"results": results, "count": len(results or [])}))
        else:
            if not results:
                typer.echo("No results")
            else:
                # Simple table output
                if results:
                    headers = list(results[0].keys())
                    typer.echo("\t".join(headers))
                    for row in results:
                        typer.echo("\t".join(str(row.get(h, "")) for h in headers))
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


COMMON_PERFETTO_TABLES = [
    "slice",
    "track",
    "thread",
    "process",
    "thread_track",
    "process_track",
    "counter",
    "counter_track",
    "sched_slice",
    "gpu_slice",
]


@perfetto_app.command("tables")
def perfetto_tables(
    trace_path: Path = typer.Argument(..., help="Path to Perfetto trace file"),
    common: bool = typer.Option(False, "--common", help="Show commonly used tables (default)"),
    tables_filter: str | None = typer.Option(
        None, "--tables", "-t", help="Comma-separated list of table names to show"
    ),
    all_tables: bool = typer.Option(False, "--all", help="Show all tables (including internal)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List available tables in a Perfetto trace."""
    from wafer.core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    # Default to --common if no filter specified
    flag_count = sum([common, tables_filter is not None, all_tables])
    if flag_count == 0:
        common = True
        flag_count = 1
    if flag_count > 1:
        typer.echo("Error: Use only one of --common, --tables, or --all", err=True)
        raise typer.Exit(1)
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    try:
        all_table_names, err = tool.get_tables(str(trace_path))
        if err:
            typer.echo(f"Error: {err}", err=True)
            raise typer.Exit(1)
        all_table_names = all_table_names or []
        if all_tables:
            filtered = all_table_names
        elif common:
            # Show common tables that exist in this trace
            filtered = [t for t in COMMON_PERFETTO_TABLES if t in all_table_names]
        else:
            # --tables flag
            requested = [t.strip() for t in (tables_filter or "").split(",") if t.strip()]
            filtered = [t for t in requested if t in all_table_names]
            missing = [t for t in requested if t not in all_table_names]
            if missing:
                typer.echo(f"Warning: Tables not found: {', '.join(missing)}", err=True)
        if json_output:
            from .output import json_response
            typer.echo(json_response(data={"tables": filtered}))
        else:
            typer.echo(f"Found {len(filtered)} tables:")
            for table in filtered:
                typer.echo(f"  {table}")
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@perfetto_app.command("schema")
def perfetto_schema(
    trace_path: Path = typer.Argument(..., help="Path to Perfetto trace file"),
    table: str = typer.Argument(..., help="Table name"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Get schema for a table in a Perfetto trace."""
    from wafer.core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    try:
        columns, err = tool.get_schema(table, str(trace_path))
        if err:
            typer.echo(f"Error: {err}", err=True)
            raise typer.Exit(1)
        if json_output:
            from .output import json_response
            typer.echo(json_response(data={"table": table, "columns": columns}))
        else:
            typer.echo(f"Schema for table '{table}':")
            for col in columns or []:
                nullable = "NULL" if col.get("nullable") else "NOT NULL"
                typer.echo(f"  {col['name']}: {col['type']} {nullable}")
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@perfetto_app.command("check")
def perfetto_check(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Check if trace_processor is available."""
    from wafer.core.lib.perfetto.perfetto_tool import PerfettoConfig, PerfettoTool
    config = PerfettoConfig(
        workspace_root=".",
        storage_dir=str(Path.home() / ".wafer" / "perfetto"),
    )
    tool = PerfettoTool(config)
    status = tool.check_processor()
    if json_output:
        from .output import json_response
        typer.echo(json_response(data=status.to_dict()))
    else:
        if status.available:
            typer.echo(f"[ok] trace_processor available at {status.binary_path}")
            typer.echo(f"  Version: {status.version}")
            if not status.version_matches_ui:
                typer.echo(f"  [warn] Version mismatch with UI (expected: {status.ui_version})")
        else:
            typer.echo(f"[fail] trace_processor not available: {status.error}")
            typer.echo("  Run 'wafer perfetto check' to auto-download")


# ===================================================================
# ROCprofiler-SDK
# ===================================================================

@rocprof_sdk_app.command("list-counters")
def rocprof_sdk_list_counters() -> None:
    """List available hardware counters for your GPU."""
    from .rocprof_sdk import list_counters_command
    try:
        list_counters_command()
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_sdk_app.command("profile")
def rocprof_sdk_profile(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    output_format: str = typer.Option(
        "csv", "--format", "-f", help="Output format (csv, json, rocpd, pftrace, otf2)"
    ),
    counters: str | None = typer.Option(
        None, "--counters", "-c", help="Comma-separated hardware counters"
    ),
    kernel_include: str | None = typer.Option(
        None, "--kernel-include", help="Include only kernels matching this regex"
    ),
    kernel_exclude: str | None = typer.Option(
        None, "--kernel-exclude", help="Exclude kernels matching this regex"
    ),
    trace_hip_runtime: bool = typer.Option(
        False, "--trace-hip-runtime", help="Enable HIP runtime API tracing"
    ),
    trace_hip_compiler: bool = typer.Option(
        False, "--trace-hip-compiler", help="Enable HIP compiler code tracing"
    ),
    trace_hsa: bool = typer.Option(False, "--trace-hsa", help="Enable HSA API tracing"),
    trace_marker: bool = typer.Option(False, "--trace-marker", help="Enable ROCTx marker tracing"),
    trace_memory_copy: bool = typer.Option(
        False, "--trace-memory-copy", help="Enable memory copy tracing"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Profile a command with rocprofv3.

    Examples:
        wafer rocprof-sdk profile './my_kernel'
        wafer rocprof-sdk profile './kernel' --counters SQ_WAVES,L2_CACHE_HITS
    """
    from .rocprof_sdk import profile_command
    counter_list = counters.split(",") if counters else None
    try:
        result = profile_command(
            command,
            output_dir,
            output_format,
            counter_list,
            kernel_include,
            kernel_exclude,
            trace_hip_runtime,
            trace_hip_compiler,
            trace_hsa,
            trace_marker,
            trace_memory_copy,
            json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_sdk_app.command("analyze")
def rocprof_sdk_analyze(
    file_path: Path = typer.Argument(
        ..., help="Path to rocprofiler output file (.csv, .json, .db)"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Analyze a rocprofiler output file (CSV, JSON, or rocpd)."""
    from .rocprof_sdk import analyze_command
    if not file_path.exists():
        typer.echo(f"Error: File not found: {file_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(str(file_path), json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


# ===================================================================
# ROCprofiler-Systems
# ===================================================================

@rocprof_systems_app.command("run")
def rocprof_systems_run(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    trace: bool = typer.Option(
        True, "--trace/--no-trace", help="Generate detailed trace (Perfetto)"
    ),
    profile: bool = typer.Option(False, "--profile", help="Generate call-stack-based profile"),
    flat_profile: bool = typer.Option(False, "--flat-profile", help="Generate flat profile"),
    sample: bool = typer.Option(False, "--sample", help="Enable sampling profiling"),
    host: bool = typer.Option(False, "--host", help="Enable host metrics"),
    device: bool = typer.Option(False, "--device", help="Enable device metrics"),
    wait: float | None = typer.Option(None, "--wait", help="Wait time before collecting (seconds)"),
    duration: float | None = typer.Option(
        None, "--duration", help="Duration of collection (seconds)"
    ),
    use_rocm: bool = typer.Option(True, "--use-rocm/--no-rocm", help="Enable ROCm backend"),
    use_sampling: bool = typer.Option(False, "--use-sampling", help="Enable sampling backend"),
    use_kokkosp: bool = typer.Option(
        False, "--use-kokkosp", help="Enable Kokkos profiling backend"
    ),
    use_mpip: bool = typer.Option(False, "--use-mpip", help="Enable MPI profiling backend"),
    use_rocpd: bool = typer.Option(False, "--use-rocpd", help="Enable rocpd database output"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run system profiling with rocprof-sys-run."""
    from .rocprof_systems import run_command
    try:
        result = run_command(
            command=command,
            output_dir=output_dir,
            trace=trace,
            profile=profile,
            flat_profile=flat_profile,
            sample=sample,
            host=host,
            device=device,
            wait=wait,
            duration=duration,
            use_rocm=use_rocm,
            use_sampling=use_sampling,
            use_kokkosp=use_kokkosp,
            use_mpip=use_mpip,
            use_rocpd=use_rocpd,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("analyze")
def rocprof_systems_analyze(
    file_path: Path = typer.Argument(..., help="Path to rocprof-sys output file (.json, .txt)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Analyze a rocprof-sys output file."""
    from .rocprof_systems import analyze_command
    if not file_path.exists():
        typer.echo(f"Error: File not found: {file_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(str(file_path), json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("sample")
def rocprof_systems_sample(
    command: str = typer.Argument(..., help="Command to profile"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    frequency: int | None = typer.Option(
        None, "--frequency", "--freq", "-f", help="Sampling frequency in Hz"
    ),
    trace: bool = typer.Option(False, "--trace", help="Generate detailed trace"),
    profile: bool = typer.Option(False, "--profile", help="Generate call-stack profile"),
    flat_profile: bool = typer.Option(False, "--flat-profile", help="Generate flat profile"),
    host: bool = typer.Option(False, "--host", help="Enable host metrics"),
    device: bool = typer.Option(False, "--device", help="Enable device metrics"),
    wait: float | None = typer.Option(None, "--wait", help="Wait time (seconds)"),
    duration: float | None = typer.Option(None, "--duration", help="Duration (seconds)"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run sampling profiling with rocprof-sys-sample."""
    from .rocprof_systems import sample_command
    try:
        result = sample_command(
            command=command,
            output_dir=output_dir,
            frequency=frequency,
            trace=trace,
            profile=profile,
            flat_profile=flat_profile,
            host=host,
            device=device,
            wait=wait,
            duration=duration,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("instrument")
def rocprof_systems_instrument(
    command: str = typer.Argument(..., help="Command to instrument"),
    output_dir: str | None = typer.Option(None, "--output-dir", "-o", help="Output directory"),
    simulate: bool = typer.Option(False, "--simulate", help="Simulate without creating binary"),
    function_include: list[str] | None = typer.Option(
        None, "--function-include", help="Function patterns to include"
    ),
    function_exclude: list[str] | None = typer.Option(
        None, "--function-exclude", help="Function patterns to exclude"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Run binary instrumentation with rocprof-sys-instrument."""
    from .rocprof_systems import instrument_command
    try:
        result = instrument_command(
            command=command,
            output_dir=output_dir,
            simulate=simulate,
            function_include=function_include,
            function_exclude=function_exclude,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_systems_app.command("query")
def rocprof_systems_query(
    components: bool = typer.Option(False, "--components", help="Query available components"),
    hw_counters: bool = typer.Option(False, "--hw-counters", help="Query hardware counters"),
    all_metrics: bool = typer.Option(False, "--all", help="Query all metrics"),
    filter_pattern: str | None = typer.Option(None, "--filter", help="Filter results"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Query available profiling metrics and components."""
    from .rocprof_systems import query_command
    try:
        result = query_command(
            components=components,
            hw_counters=hw_counters,
            all_metrics=all_metrics,
            filter_pattern=filter_pattern,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


# ===================================================================
# ROCprofiler-Compute
# ===================================================================

@rocprof_compute_app.command("profile")
def rocprof_compute_profile(
    command: str = typer.Argument(..., help="Command to profile"),
    name: str = typer.Option(..., "--name", "-n", help="Workload name"),
    path: str | None = typer.Option(None, "--path", "-p", help="Workload base path"),
    kernel: str | None = typer.Option(
        None, "--kernel", "-k", help="Kernel filter (comma-separated)"
    ),
    dispatch: str | None = typer.Option(
        None, "--dispatch", "-d", help="Dispatch filter (comma-separated)"
    ),
    block: str | None = typer.Option(None, "--block", "-b", help="Block filter (comma-separated)"),
    no_roof: bool = typer.Option(False, "--no-roof", help="Skip roofline data"),
    roof_only: bool = typer.Option(False, "--roof-only", help="Profile roofline only (fastest)"),
    hip_trace: bool = typer.Option(False, "--hip-trace", help="Enable HIP trace"),
    verbose: int = typer.Option(0, "--verbose", "-v", count=True, help="Increase verbosity"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Profile a command with rocprof-compute.

    Examples:
        wafer rocprof-compute profile --name vcopy -- './vcopy -n 1048576'
        wafer rocprof-compute profile -n test -b SQ,TCC -- './kernel'
    """
    from .rocprof_compute import profile_command
    try:
        result = profile_command(
            command,
            name,
            path,
            kernel,
            dispatch,
            block,
            no_roof,
            roof_only,
            hip_trace,
            verbose,
            json_output,
        )
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_compute_app.command("analyze")
def rocprof_compute_analyze(
    workload_path: Path = typer.Argument(..., help="Path to workload directory"),
    kernel: str | None = typer.Option(None, "--kernel", "-k", help="Kernel filter"),
    dispatch: str | None = typer.Option(None, "--dispatch", "-d", help="Dispatch filter"),
    block: str | None = typer.Option(None, "--block", "-b", help="Block filter"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file"),
    list_stats: bool = typer.Option(
        False, "--list-stats", help="List all detected kernels and dispatches"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    gui: bool = typer.Option(
        False, "--gui", help="Launch interactive GUI viewer (bundled Python viewer by default)"
    ),
    port: int = typer.Option(8050, "--port", "-p", help="Port for GUI server"),
) -> None:
    """Analyze a rocprof-compute workload directory.

    Examples:
        wafer rocprof-compute analyze ./workloads/vcopy
        wafer rocprof-compute analyze ./workloads/app --gui
    """
    from .rocprof_compute import analyze_command
    if not workload_path.exists():
        typer.echo(f"Error: Workload path not found: {workload_path}", err=True)
        raise typer.Exit(1)
    try:
        result = analyze_command(
            str(workload_path),
            kernel,
            dispatch,
            block,
            output,
            list_stats,
            json_output,
            gui,
            port,
        )
        if json_output or not gui:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@rocprof_compute_app.command("list-metrics")
def rocprof_compute_list_metrics(
    arch: str = typer.Argument(..., help="Architecture (gfx90a, gfx942, etc.)"),
) -> None:
    """List available metrics for an architecture."""
    from .rocprof_compute import list_metrics_command
    try:
        result = list_metrics_command(arch)
        if result:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


# ===================================================================
# Autotuner
# ===================================================================

def _setup_wafer_env() -> None:
    """Set environment variables for wafer-ai to use.
    Call this before using wafer functions that need API access.
    Respects explicit environment variable overrides:
    - WAFER_API_URL: If already set, uses that instead of config
    - WAFER_AUTH_TOKEN: If already set, uses that instead of cached token
    """
    from .auth import get_valid_token
    from .global_config import get_api_url

    os.environ["WAFER_API_URL"] = get_api_url()
    if "WAFER_AUTH_TOKEN" not in os.environ:
        token = get_valid_token()
        if token:
            os.environ["WAFER_AUTH_TOKEN"] = token


@autotuner_app.command("list")
def autotuner_list(
    show_all: bool = typer.Option(
        False, "--all", help="Show all sweeps including pending and failed"
    ),
) -> None:
    """List sweeps for the current user.
    By default, only shows running and completed sweeps.
    Use --all to include pending and failed sweeps.
    Examples:
        wafer autotuner list
        wafer autotuner list --all
    """
    _setup_wafer_env()
    from .autotuner import list_command
    try:
        result = list_command(show_all=show_all)
        print(result)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@autotuner_app.command("delete")
def autotuner_delete(
    sweep_id: str | None = typer.Argument(None, help="Sweep ID to delete (omit when using --all)"),
    delete_all: bool = typer.Option(
        False, "--all", help="Delete all sweeps (optionally filtered by --status)"
    ),
    status: str | None = typer.Option(
        None,
        "--status",
        help="Filter by status when using --all (pending, running, completed, failed)",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
) -> None:
    """Delete a sweep (or all sweeps) and their trials.
    WARNING: This permanently deletes sweeps and cannot be undone.
    Examples:
        # Delete single sweep
        wafer autotuner delete <sweep-id>
        wafer autotuner delete <sweep-id> --yes
        # Delete all sweeps
        wafer autotuner delete --all
        wafer autotuner delete --all --status pending
        wafer autotuner delete --all --status failed --yes
    """
    _setup_wafer_env()
    from .autotuner import delete_all_command, delete_command
    if delete_all and sweep_id:
        typer.echo("Error: Cannot specify both sweep_id and --all flag", err=True)
        raise typer.Exit(1)
    if not delete_all and not sweep_id:
        typer.echo("Error: Must specify either sweep_id or --all flag", err=True)
        raise typer.Exit(1)
    if status and not delete_all:
        typer.echo("Error: --status can only be used with --all flag", err=True)
        raise typer.Exit(1)
    try:
        if delete_all:
            if not yes:
                status_msg = f" with status '{status}'" if status else ""
                confirm = typer.confirm(f"Are you sure you want to delete all sweeps{status_msg}?")
                if not confirm:
                    typer.echo("Deletion cancelled.")
                    raise typer.Exit(0)
            result = delete_all_command(status_filter=status)
        else:
            if not yes:
                confirm = typer.confirm(f"Are you sure you want to delete sweep {sweep_id}?")
                if not confirm:
                    typer.echo("Deletion cancelled.")
                    raise typer.Exit(0)
            result = delete_command(sweep_id)
        print(result)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@autotuner_app.command("run")
def autotuner_run(
    config_file: Path | None = typer.Argument(
        None, help="Path to JSON config file (required unless --resume)"
    ),
    parallel: int = typer.Option(
        4, "--parallel", "-p", help="Number of trials to run concurrently"
    ),
    resume: str | None = typer.Option(None, "--resume", "-r", help="Resume existing sweep by ID"),
) -> None:
    """Run hyperparameter sweep from JSON config or resume existing sweep.
    Examples:
        # Start new sweep
        wafer autotuner run config.json
        wafer autotuner run config.json --parallel 8
        # Resume failed/interrupted sweep
        wafer autotuner run --resume <sweep-id>
        wafer autotuner run --resume <sweep-id> --parallel 8
    """
    _setup_wafer_env()
    from .autotuner import run_sweep_command
    if not resume and not config_file:
        typer.echo("Error: Must specify either config file or --resume <sweep-id>", err=True)
        raise typer.Exit(1)
    if resume and config_file:
        typer.echo("Error: Cannot specify both config file and --resume", err=True)
        raise typer.Exit(1)
    try:
        result = run_sweep_command(
            config_file=config_file, parallel=parallel, resume_sweep_id=resume
        )
        print(result)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@autotuner_app.command("results")
def autotuner_results(
    sweep_id: str = typer.Argument(..., help="Sweep ID to retrieve"),
    mode: str = typer.Argument("list", help="Display mode: 'list', 'best', or trial number"),
    sort_by: str | None = typer.Option(
        None, "--sort-by", help="Metric name to sort by (list mode)"
    ),
    direction: str = typer.Option("maximize", "--direction", help="Sort direction (list mode)"),
    pareto: str | None = typer.Option(
        None, "--pareto", help="Comma-separated metrics for Pareto frontier (list mode)"
    ),
    show_all: bool = typer.Option(
        False, "--show-all", help="Include failed and constraint-violated trials (list mode)"
    ),
    limit: int | None = typer.Option(
        None, "--limit", help="Maximum number of results to show (list mode, default: all)"
    ),
    metric: str | None = typer.Option(
        None, "--metric", help="Metric to optimize (REQUIRED for best mode)"
    ),
) -> None:
    """Show sweep results (list/best/trial).
    Commands:
        wafer autotuner results <sweep-id>                    # List all results
        wafer autotuner results <sweep-id> --sort-by <metric> # List sorted
        wafer autotuner results <sweep-id> best --metric <m>  # Show best config
        wafer autotuner results <sweep-id> <N>                # Show trial N
    """
    from .autotuner import best_command, results_command, trial_command
    try:
        if mode == "best":
            if not metric:
                typer.echo("Error: --metric is required for 'best' mode", err=True)
                raise typer.Exit(1)
            result = best_command(sweep_id=sweep_id, metric=metric)
        elif mode == "list":
            result = results_command(
                sweep_id=sweep_id,
                sort_by=sort_by,
                direction=direction,
                pareto=pareto,
                show_all=show_all,
                limit=limit,
            )
        else:
            try:
                trial_number = int(mode)
                result = trial_command(sweep_id=sweep_id, trial_number=trial_number)
            except ValueError as e:
                typer.echo(
                    f"Error: Invalid mode '{mode}'. Use 'list', 'best', or a trial number.",
                    err=True,
                )
                raise typer.Exit(1) from e
        print(result)
    except ValueError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


# ===================================================================
# Capture
# ===================================================================

def _capture_setup_env() -> None:
    import os

    from .auth import get_valid_token
    from .global_config import get_api_url

    os.environ["WAFER_API_URL"] = get_api_url()
    if "WAFER_AUTH_TOKEN" not in os.environ:
        token = get_valid_token()
        if token:
            os.environ["WAFER_AUTH_TOKEN"] = token


def _capture_load_denylists(work_dir: Path) -> tuple[list[str] | None, list[str] | None]:
    assert isinstance(work_dir, Path), "work_dir must be a Path"
    assert work_dir.is_absolute(), f"work_dir must be an absolute path: {work_dir}"

    import tomllib
    config_code_denylist = None
    config_artifact_denylist = None
    global_config_path = Path.home() / ".wafer" / "capture.toml"
    if global_config_path.exists():
        try:
            with open(global_config_path, "rb") as f:
                data = tomllib.load(f)
            config_code_denylist = data.get("code_denylist")
            config_artifact_denylist = data.get("artifact_denylist")
        except Exception as e:
            typer.echo(f"\u26a0\ufe0f  Warning: Failed to load {global_config_path}: {e}", err=True)
    project_config_path = work_dir / ".wafer-capture.toml"
    if project_config_path.exists():
        try:
            with open(project_config_path, "rb") as f:
                pdata = tomllib.load(f)
            if "code_denylist" in pdata:
                config_code_denylist = pdata["code_denylist"]
            if "artifact_denylist" in pdata:
                config_artifact_denylist = pdata["artifact_denylist"]
        except Exception as e:
            typer.echo(f"\u26a0\ufe0f  Warning: Failed to load {project_config_path}: {e}", err=True)
    return config_code_denylist, config_artifact_denylist


def _capture_parse_sweep(sweep: list[str] | None) -> dict[str, list[str]]:
    assert sweep is None or isinstance(sweep, list), "sweep must be a list or None"
    assert sweep is None or all(isinstance(s, str) for s in sweep), "all sweep entries must be strings"

    sweep_vars: dict[str, list[str]] = {}
    if not sweep:
        return sweep_vars
    for sweep_spec in sweep:
        if "=" not in sweep_spec:
            typer.echo(f"Error: Invalid sweep format: {sweep_spec}", err=True)
            typer.echo("   Expected format: VAR=val1,val2,val3", err=True)
            raise typer.Exit(1)
        var_name, values_str = sweep_spec.split("=", 1)
        sweep_vars[var_name] = [v.strip() for v in values_str.split(",")]
    return sweep_vars


def _capture_build_combinations(
    sweep_vars: dict[str, list[str]], label: str, json_output: bool,
) -> tuple[list[tuple[str, ...]], list[str]]:
    assert isinstance(sweep_vars, dict), "sweep_vars must be a dict"
    assert isinstance(label, str) and label, "label must be a non-empty string"

    import itertools
    if sweep_vars:
        var_names = list(sweep_vars.keys())
        var_values = [sweep_vars[name] for name in var_names]
        combinations = list(itertools.product(*var_values))
        if not json_output:
            typer.echo(f"Running sweep: {label}")
            typer.echo(f"   Variables: {', '.join(var_names)}")
            typer.echo(f"   Total runs: {len(combinations)}")
            typer.echo()
        return combinations, var_names
    return [()], []


def _capture_result_to_dict(result: Any, label: str, cmd: str, sweep_info: dict[str, str]) -> dict[str, Any]:
    assert result is not None, "result must not be None"
    assert isinstance(label, str) and label, "label must be a non-empty string"

    data = {
        "id": result.id,
        "label": label,
        "command": cmd,
        "exit_code": result.exit_code,
        "duration_seconds": result.duration_seconds,
        "code_files": len(result.code_files),
        "artifacts": len(result.artifacts),
    }
    if result.metrics.stdout_metrics:
        data["metrics_count"] = len(result.metrics.stdout_metrics)
    if sweep_info:
        data["sweep"] = sweep_info
    return data


def _capture_print_result(result: Any) -> None:
    assert result is not None, "result must not be None"
    assert hasattr(result, "id"), "result must have an id attribute"

    typer.echo()
    typer.echo("\u2713 Capture complete")
    typer.echo(f"   ID: {result.id}")
    typer.echo(f"   Exit code: {result.exit_code}")
    typer.echo(f"   Duration: {result.duration_seconds:.2f}s")
    typer.echo(f"   Code files: {len(result.code_files)}")
    typer.echo(f"   Artifacts: {len(result.artifacts)}")
    if result.metrics.stdout_metrics:
        typer.echo(f"   Metrics: {len(result.metrics.stdout_metrics)}")
    typer.echo()


async def _capture_sweep_loop(
    combinations: list[tuple[str, ...]], var_names: list[str], sweep_vars: dict[str, list[str]],
    command: str, variant: str | None, label: str, work_dir: Path,
    tags: list[str] | None, code_denylist: list[str] | None,
    artifact_denylist: list[str] | None, json_output: bool,
    CaptureConfig: type, capture_fn: Callable[..., Any], execute_fn: Callable[..., Any],
    progress: Callable[[str], None],
) -> list[dict[str, Any]]:
    assert isinstance(combinations, list) and combinations, "combinations must be a non-empty list"
    assert isinstance(command, str) and command, "command must be a non-empty string"

    successful = 0
    failed = 0
    capture_results: list[dict] = []
    for idx, combo in enumerate(combinations, 1):
        substituted_cmd = command
        sweep_info = {}
        for var_name, value in zip(var_names, combo, strict=True):
            substituted_cmd = substituted_cmd.replace(f"{{{var_name}}}", value)
            sweep_info[var_name] = value
        run_variant = _capture_resolve_variant(sweep_vars, sweep_info, variant)
        denylist_kwargs = {}
        if code_denylist:
            denylist_kwargs["code_denylist"] = code_denylist
        if artifact_denylist:
            denylist_kwargs["artifact_denylist"] = artifact_denylist
        config = CaptureConfig(
            label=label, command=substituted_cmd, working_dir=work_dir,
            variant=run_variant, tags=tags or [], **denylist_kwargs,
        )
        try:
            if not json_output:
                _capture_print_run_header(sweep_vars, sweep_info, idx, len(combinations), label, substituted_cmd, work_dir)
            result = await capture_fn(config=config, runner=execute_fn, progress_callback=progress)
            capture_results.append(_capture_result_to_dict(result, label, substituted_cmd, sweep_info))
            if not json_output:
                _capture_print_result(result)
            successful += 1
        except Exception as e:
            if json_output:
                capture_results.append({"label": label, "command": substituted_cmd, "error": str(e)})
            else:
                typer.echo(f"\n\u2717 Capture failed: {e}", err=True)
                typer.echo()
            failed += 1
    _capture_print_summary(json_output, sweep_vars, combinations, successful, failed, capture_results)
    if failed > 0:
        raise typer.Exit(1)
    return capture_results


def _capture_resolve_variant(
    sweep_vars: dict[str, list[str]], sweep_info: dict[str, str], variant: str | None,
) -> str | None:
    assert isinstance(sweep_vars, dict), "sweep_vars must be a dict"
    assert isinstance(sweep_info, dict), "sweep_info must be a dict"

    if not sweep_vars:
        return variant
    variant_parts = [f"{k}={v}" for k, v in sweep_info.items()]
    run_variant = "_".join(variant_parts)
    if variant:
        run_variant = f"{variant}_{run_variant}"
    return run_variant


def _capture_print_run_header(
    sweep_vars: dict[str, list[str]], sweep_info: dict[str, str], idx: int, total: int,
    label: str, cmd: str, work_dir: Path,
) -> None:
    assert idx >= 1, f"idx must be >= 1, got {idx}"
    assert total >= 1, f"total must be >= 1, got {total}"

    if sweep_vars:
        typer.echo(f"[{idx}/{total}] {', '.join(f'{k}={v}' for k, v in sweep_info.items())}")
    else:
        typer.echo(f"Capturing: {label}")
    typer.echo(f"   Command: {cmd}")
    typer.echo(f"   Working dir: {work_dir}")
    typer.echo()


def _capture_print_summary(
    json_output: bool, sweep_vars: dict[str, list[str]], combinations: list[tuple[str, ...]],
    successful: int, failed: int, capture_results: list[dict[str, Any]],
) -> None:
    assert isinstance(json_output, bool), "json_output must be a bool"
    assert successful + failed == len(combinations), "successful + failed must equal total combinations"

    if json_output:
        from .output import json_response
        status = "ok" if failed == 0 else "error"
        data = {"captures": capture_results, "successful": successful, "failed": failed}
        typer.echo(json_response(data=data, status=status))
    elif sweep_vars and len(combinations) > 1:
        typer.echo("=" * 60)
        typer.echo(f"Sweep complete: {successful} successful, {failed} failed")


@capture_app.command("run")
def capture_command(  # noqa: PLR0915
    label: str = typer.Argument(
        ..., help="Label for this capture (e.g., 'baseline', 'optimized-v2')"
    ),
    command: str = typer.Argument(..., help="Command to execute and capture"),
    variant: str | None = typer.Option(
        None, "--variant", "-v", help="Variant identifier for grouping related captures"
    ),
    tags: list[str] | None = typer.Option(
        None, "--tag", "-t", help="Tags for categorization (can be specified multiple times)"
    ),  # noqa: B008
    working_dir: Path | None = typer.Option(
        None, "--dir", "-d", help="Working directory (default: current directory)"
    ),
    sweep: list[str] | None = typer.Option(
        None, "--sweep", "-s", help="Parameter sweep (format: VAR=val1,val2,val3)"
    ),  # noqa: B008
    code_denylist: list[str] | None = typer.Option(
        None,
        "--code-denylist",
        help="Patterns to exclude from code files (e.g., '*.log', '**/test/**')",
    ),  # noqa: B008
    artifact_denylist: list[str] | None = typer.Option(
        None,
        "--artifact-denylist",
        help="Patterns to exclude from artifacts (e.g., '*.tmp', '*.o')",
    ),  # noqa: B008
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Capture an execution snapshot for reproducibility and comparison.

    Examples:
        wafer tool capture baseline "python benchmark.py"
        wafer tool capture optimized "python benchmark.py" --variant v2
    """
    import trio

    _capture_setup_env()
    work_dir = working_dir.resolve() if working_dir else Path.cwd()
    config_code_denylist, config_artifact_denylist = _capture_load_denylists(work_dir)
    sweep_vars = _capture_parse_sweep(sweep)
    combinations, var_names = _capture_build_combinations(sweep_vars, label, json_output)
    effective_code_denylist = code_denylist or config_code_denylist
    effective_artifact_denylist = artifact_denylist or config_artifact_denylist

    from wafer.core.tools.capture_tool import CaptureConfig, capture, execute_command

    def progress(msg: str) -> None:
        if not json_output:
            typer.echo(f"  {msg}")

    async def run_capture_sweep() -> list[dict]:
        return await _capture_sweep_loop(
            combinations, var_names, sweep_vars, command, variant, label,
            work_dir, tags, effective_code_denylist, effective_artifact_denylist,
            json_output, CaptureConfig, capture, execute_command, progress,
        )

    trio.run(run_capture_sweep)


@capture_app.command("list")
def capture_list_command(
    label: str | None = typer.Option(None, "--label", "-l", help="Filter by label"),
    limit: int = typer.Option(100, "--limit", "-n", help="Maximum number of results"),
    offset: int = typer.Option(0, "--offset", "-o", help="Offset for pagination"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List captured executions.

    Examples:
        wafer tool capture list --label baseline
        wafer tool capture list --json --limit 10
    """
    import os

    from .auth import get_valid_token
    from .global_config import get_api_url

    os.environ["WAFER_API_URL"] = get_api_url()
    if "WAFER_AUTH_TOKEN" not in os.environ:
        token = get_valid_token()
        if token:
            os.environ["WAFER_AUTH_TOKEN"] = token
    import trio

    from wafer.core.utils.backend import list_captures  # pragma: no cover

    async def run_list() -> None:
        try:
            captures = await list_captures(label=label, limit=limit, offset=offset)
            if json_output:
                from .output import json_response
                typer.echo(json_response(data={"captures": captures}))
            else:
                if not captures:
                    typer.echo("No captures found.")
                    return
                typer.echo(f"Found {len(captures)} captures:\n")
                typer.echo(
                    f"{'ID':<36}  {'Label':<20}  {'Variant':<20}  {'Exit':<4}  {'Duration':<8}  {'Created'}"
                )
                typer.echo("-" * 120)
                for cap in captures:
                    cap_id = cap.get("id", "")[:36]
                    cap_label = cap.get("label", "")[:20]
                    cap_variant = (cap.get("variant") or "")[:20]
                    exit_code = cap.get("exit_code", "")
                    duration = f"{cap.get('duration_seconds', 0):.2f}s"
                    created = cap.get("created_at", "")[:19]
                    typer.echo(
                        f"{cap_id:<36}  {cap_label:<20}  {cap_variant:<20}  {exit_code:<4}  {duration:<8}  {created}"
                    )
        except Exception as e:
            typer.echo(f"Error: Failed to list captures: {e}", err=True)
            raise typer.Exit(1) from None
    trio.run(run_list)


# ===================================================================
# TraceLens
# ===================================================================

@tracelens_app.command("check")
def tracelens_check(
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Check if TraceLens is installed."""
    from .tracelens import check_command
    try:
        result = check_command(json_output)
        if json_output:
            typer.echo(result)
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@tracelens_app.command("report")
def tracelens_report(
    trace_path: str = typer.Argument(..., help="Path to trace file (.json, .zip, .gz, .pb)"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file path"),
    trace_format: str = typer.Option(
        "auto", "--format", "-f", help="Trace format: auto, pytorch, rocprof, jax"
    ),
    short_kernel: bool = typer.Option(
        False, "--short-kernel", help="Include short kernel analysis"
    ),
    kernel_details: bool = typer.Option(
        False, "--kernel-details", help="Include detailed kernel breakdown"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Generate performance report from a trace file."""
    from .tracelens import report_command
    try:
        result = report_command(
            trace_path=trace_path,
            output_path=output,
            trace_format=trace_format,
            short_kernel=short_kernel,
            kernel_details=kernel_details,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None


@tracelens_app.command("compare")
def tracelens_compare(
    baseline: str = typer.Argument(..., help="Path to baseline Excel report"),
    candidate: str = typer.Argument(..., help="Path to candidate Excel report"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output comparison file"),
    baseline_name: str = typer.Option(
        "baseline", "--baseline-name", help="Display name for baseline"
    ),
    candidate_name: str = typer.Option(
        "candidate", "--candidate-name", help="Display name for candidate"
    ),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Compare two performance reports."""
    from .tracelens import compare_command
    try:
        result = compare_command(
            baseline_path=baseline,
            candidate_path=candidate,
            output_path=output,
            baseline_name=baseline_name,
            candidate_name=candidate_name,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None


@tracelens_app.command("collective")
def tracelens_collective(
    trace_dir: str = typer.Argument(..., help="Directory containing trace files for all ranks"),
    world_size: int = typer.Option(..., "--world-size", "-w", help="Number of ranks (GPUs)"),
    output: str | None = typer.Option(None, "--output", "-o", help="Output file path"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Generate multi-rank collective performance report."""
    from .tracelens import collective_command
    try:
        result = collective_command(
            trace_dir=trace_dir,
            world_size=world_size,
            output_path=output,
            json_output=json_output,
        )
        if json_output:
            typer.echo(result)
    except RuntimeError:
        raise typer.Exit(1) from None


# ===================================================================
# ISA
# ===================================================================

@isa_app.command("analyze")
def isa_analyze(
    path: Path = typer.Argument(..., help="Path to file or directory to analyze"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    csv_output: bool = typer.Option(False, "--csv", help="Output as CSV"),
    recursive: bool = typer.Option(
        True, "--recursive/--no-recursive", "-r", help="Scan directories recursively"
    ),
    filter_expr: str | None = typer.Option(
        None, "--filter", "-f", help="Filter results (e.g., 'spills > 0')"
    ),
    output_file: Path | None = typer.Option(None, "--output", "-o", help="Write output to file"),
    kernel_index: int = typer.Option(0, "--kernel", "-k", help="Kernel index if multiple in file"),
) -> None:
    """Analyze AMD GPU ISA files (.co, .s, .ll, .ttgir).

    Examples:
        wafer tool isa analyze kernel.co
        wafer tool isa analyze kernel.s --json
    """
    from .auth import get_auth_headers
    from .global_config import get_api_url
    from .kernel_scope import analyze_command
    api_url = get_api_url()
    auth_headers = get_auth_headers()
    try:
        output = analyze_command(
            path=str(path),
            json_output=json_output,
            csv_output=csv_output,
            recursive=recursive,
            filter_expr=filter_expr,
            output_file=str(output_file) if output_file else None,
            kernel_index=kernel_index,
            api_url=api_url,
            auth_headers=auth_headers,
        )
        typer.echo(output)
    except FileNotFoundError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None


@isa_app.command("metrics")
def isa_metrics() -> None:
    """List available metrics for ISA analysis."""
    from .kernel_scope import metrics_command
    output = metrics_command()
    typer.echo(output)


@isa_app.command("targets")
def isa_targets() -> None:
    """List supported GPU targets and their specifications."""
    from .kernel_scope import targets_command
    output = targets_command()
    typer.echo(output)


# ===================================================================
# Compare
# ===================================================================

@compare_app.command("analyze")
def compare_analyze(
    trace1: Path = typer.Argument(..., help="First trace file (AMD or NVIDIA)", exists=True),
    trace2: Path = typer.Argument(..., help="Second trace file (AMD or NVIDIA)", exists=True),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
    format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    phase: str = typer.Option(
        "all",
        "--phase",
        help="Filter by phase: all, prefill, or decode",
    ),
    all: bool = typer.Option(False, "--all", help="Show all items without truncation"),
    stack_traces: bool = typer.Option(False, "--stack-traces", help="Show Python stack traces for operations"),
    grouped: bool = typer.Option(False, "--grouped", help="Group kernels by operation type (default: position order)"),
    max_graphs: int = typer.Option(1, "--max-graphs", help="Maximum number of CUDA graph patterns to show (default: 1)"),
    fusion: bool = typer.Option(False, "--fusion", help="Also show fusion analysis (kernel fusion differences)"),
    min_group_size: int = typer.Option(300, "--min-group-size", help="Minimum correlation group size for fusion analysis (default: 300)"),
    json: bool = typer.Option(False, "--json", hidden=True, help="Ignored (for compatibility with cliExecutor)"),
) -> None:
    """Compare GPU traces and generate performance report.

    Examples:
        wafer compare analyze amd_trace.json nvidia_trace.json
        wafer compare analyze amd_trace.json nvidia_trace.json --fusion --json
    """
    from .trace_compare import compare_traces
    compare_traces(
        trace1=trace1,
        trace2=trace2,
        output=output,
        output_format=format,
        phase=phase,
        show_all=all,
        show_stack_traces=stack_traces,
        grouped=grouped,
        max_graphs=max_graphs,
        show_fusion=fusion,
        min_group_size=min_group_size,
    )
    _mark_command_success()


@compare_app.command("fusion")
def compare_fusion_cmd(
    trace1: Path = typer.Argument(..., help="First trace file (AMD or NVIDIA)", exists=True),
    trace2: Path = typer.Argument(..., help="Second trace file (AMD or NVIDIA)", exists=True),
    format: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file (default: stdout)"),
    min_group_size: int = typer.Option(
        300,
        "--min-group-size",
        help="Minimum correlation group size to analyze (default: 300 for transformer layers)",
    ),
    json: bool = typer.Option(False, "--json", hidden=True, help="Ignored (for compatibility with cliExecutor)"),
) -> None:
    """Analyze kernel fusion differences using graph-based matching."""
    from .trace_compare import compare_fusion
    compare_fusion(
        trace1=trace1,
        trace2=trace2,
        output=output,
        format_type=format,
        min_group_size=min_group_size,
    )
    _mark_command_success()
