"""Built-in code scorers (CodeScorer subclasses / async score() functions)."""
