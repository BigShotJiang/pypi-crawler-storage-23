"""hipBLASLt GEMM bench script.

Benchmarks GEMM operations using PyTorch with hipBLASLt backend.
Outputs JSON to stdout.

Usage: python -m wafer.eval.bench.hipblaslt [--shape M,K,N] [--dtype fp16]
"""
from __future__ import annotations

import argparse
import json
import sys
import time


def main() -> None:
    import torch

    parser = argparse.ArgumentParser(description="hipBLASLt GEMM benchmark")
    parser.add_argument("--shape", default="256,4096,11008", help="M,K,N dimensions")
    parser.add_argument("--dtype", default="fp16", choices=["fp16", "bf16", "fp32"])
    parser.add_argument("--num-warmup", type=int, default=10)
    parser.add_argument("--num-trials", type=int, default=100)
    args = parser.parse_args()

    parts = args.shape.split(",")
    assert len(parts) == 3, f"Shape must be M,K,N but got: {args.shape}"
    m, k, n = int(parts[0]), int(parts[1]), int(parts[2])

    dtype_map = {"fp16": torch.float16, "bf16": torch.bfloat16, "fp32": torch.float32}
    torch_dtype = dtype_map[args.dtype]

    result: dict = {
        "success": False,
        "correct": False,
        "tflops": None,
        "time_ms": None,
        "min_time_ms": None,
        "shape": [m, k, n],
        "dtype": args.dtype,
        "error": None,
    }

    try:
        assert torch.cuda.is_available(), "CUDA not available"

        a = torch.randn(m, k, dtype=torch_dtype, device="cuda")
        b = torch.randn(k, n, dtype=torch_dtype, device="cuda")

        ref = torch.mm(a.float(), b.float())
        out = torch.mm(a, b)
        correct = torch.allclose(out.float(), ref, rtol=1e-2, atol=1e-2)
        result["correct"] = correct

        if correct:
            for _ in range(args.num_warmup):
                torch.mm(a, b)
            torch.cuda.synchronize()

            start = torch.cuda.Event(enable_timing=True)
            end = torch.cuda.Event(enable_timing=True)

            times = []
            for _ in range(args.num_trials):
                start.record()
                torch.mm(a, b)
                end.record()
                torch.cuda.synchronize()
                times.append(start.elapsed_time(end))

            import statistics
            median_ms = statistics.median(times)
            min_ms = min(times)

            flops = 2.0 * m * k * n
            tflops = flops / (median_ms / 1000.0) / 1e12

            result["time_ms"] = median_ms
            result["min_time_ms"] = min_ms
            result["tflops"] = tflops
            result["success"] = True
        else:
            result["error"] = "Correctness check failed"

    except Exception as e:
        result["error"] = str(e)

    print(f"EVAL_RESULT_JSON:{json.dumps(result)}")


if __name__ == "__main__":
    main()
