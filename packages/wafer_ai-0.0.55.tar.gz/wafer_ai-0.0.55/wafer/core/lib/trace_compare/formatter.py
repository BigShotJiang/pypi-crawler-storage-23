"""Report formatting for trace comparison results.
Provides text, CSV, and JSON output formatters for comparison and fusion analysis.
"""
import json
from typing import Any

try:
    import orjson
    HAS_ORJSON = True
except ImportError:
    HAS_ORJSON = False


def format_text(results: dict[str, Any], show_all: bool = False, show_stack_traces: bool = False, grouped: bool = False, graph_results: dict[str, Any] | None = None, max_graphs: int = 1) -> str:
    """Format comparison results as human-readable text report.
    Args:
        results: Analysis results from analyze_traces()
        show_all: Whether to show all items without truncation
        show_stack_traces: Whether to show Python stack traces
        grouped: Whether to group kernels by operation type in kernel details
        graph_results: Optional graph matching results from match_traces() for kernel-level details
        max_graphs: Maximum number of CUDA graph patterns to show in detail (default: 1)
    Returns:
        Formatted text report
    """
    lines = []
    meta = results["metadata"]
    lines.append("=" * 80)
    lines.append("VLLM TRACE COMPARISON REPORT")
    if "phase" in meta and meta["phase"] != "all":
        lines.append(f"Phase: {meta['phase'].upper()}")
    lines.append("=" * 80)
    lines.append("")

    is_trace1_amd = meta['trace1_platform'] == 'AMD'
    if is_trace1_amd:
        amd_gpu, nvidia_gpu = meta['trace1_gpu'], meta['trace2_gpu']
        amd_kernels, nvidia_kernels = meta['trace1_kernels'], meta['trace2_kernels']
        amd_total_ms, nvidia_total_ms = meta['trace1_total_ms'], meta['trace2_total_ms']
    else:
        amd_gpu, nvidia_gpu = meta['trace2_gpu'], meta['trace1_gpu']
        amd_kernels, nvidia_kernels = meta['trace2_kernels'], meta['trace1_kernels']
        amd_total_ms, nvidia_total_ms = meta['trace2_total_ms'], meta['trace1_total_ms']
    amd_dev = meta['trace1_device'] if is_trace1_amd else meta['trace2_device']
    nvidia_dev = meta['trace2_device'] if is_trace1_amd else meta['trace1_device']
    lines.append(f"AMD GPU:      {amd_gpu}")
    lines.append(f"  Compute:    {amd_dev['compute_capability']}")
    lines.append(f"  Memory:     {amd_dev['total_memory_gb']:.1f} GB")
    lines.append(f"  SMs:        {amd_dev['sm_count']}")
    lines.append(f"  Warp Size:  {amd_dev['warp_size']}")
    lines.append("")
    lines.append(f"NVIDIA GPU:   {nvidia_gpu}")
    lines.append(f"  Compute:    {nvidia_dev['compute_capability']}")
    lines.append(f"  Memory:     {nvidia_dev['total_memory_gb']:.1f} GB")
    lines.append(f"  SMs:        {nvidia_dev['sm_count']}")
    lines.append(f"  Warp Size:  {nvidia_dev['warp_size']}")
    lines.append("")
    lines.append(f"AMD Kernels:  {amd_kernels:,}")
    lines.append(f"NVIDIA Kernels: {nvidia_kernels:,}")
    lines.append(f"AMD Total:    {amd_total_ms:.1f} ms")
    lines.append(f"NVIDIA Total: {nvidia_total_ms:.1f} ms")
    if nvidia_total_ms > 0:
        ratio_str = f"{amd_total_ms / nvidia_total_ms:.2f}x"
    elif amd_total_ms > 0:
        ratio_str = "∞ (NVIDIA has no data)"
    else:
        ratio_str = "N/A (both traces empty)"
    lines.append(f"Ratio:        {ratio_str}")
    lines.append("")
    ops = results["operations"]
    for op in ops:
        if is_trace1_amd:
            op['amd_count'] = op['trace1_count']
            op['nvidia_count'] = op['trace2_count']
            op['amd_avg_us'] = op['trace1_avg_us']
            op['nvidia_avg_us'] = op['trace2_avg_us']
            op['amd_total_ms'] = op['trace1_total_ms']
            op['nvidia_total_ms'] = op['trace2_total_ms']
            op['amd_cpu_op'] = op.get('trace1_cpu_op')
            op['nvidia_cpu_op'] = op.get('trace2_cpu_op')
            op['amd_pattern'] = op.get('trace1_pattern')
            op['nvidia_pattern'] = op.get('trace2_pattern')
            op['amd_kernels'] = op.get('trace1_kernels', [])
            op['nvidia_kernels'] = op.get('trace2_kernels', [])
        else:
            op['amd_count'] = op['trace2_count']
            op['nvidia_count'] = op['trace1_count']
            op['amd_avg_us'] = op['trace2_avg_us']
            op['nvidia_avg_us'] = op['trace1_avg_us']
            op['amd_total_ms'] = op['trace2_total_ms']
            op['nvidia_total_ms'] = op['trace1_total_ms']
            op['amd_cpu_op'] = op.get('trace2_cpu_op')
            op['nvidia_cpu_op'] = op.get('trace1_cpu_op')
            op['amd_pattern'] = op.get('trace2_pattern')
            op['nvidia_pattern'] = op.get('trace1_pattern')
            op['amd_kernels'] = op.get('trace2_kernels', [])
            op['nvidia_kernels'] = op.get('trace1_kernels', [])
    layers = results.get("layers", [])
    for layer in layers:
        if is_trace1_amd:
            layer['amd_kernels'] = layer['trace1_kernels']
            layer['nvidia_kernels'] = layer['trace2_kernels']
            layer['amd_total_ms'] = layer['trace1_total_ms']
            layer['nvidia_total_ms'] = layer['trace2_total_ms']
        else:
            layer['amd_kernels'] = layer['trace2_kernels']
            layer['nvidia_kernels'] = layer['trace1_kernels']
            layer['amd_total_ms'] = layer['trace2_total_ms']
            layer['nvidia_total_ms'] = layer['trace1_total_ms']

    if is_trace1_amd:
        meta['amd_layers'] = meta.get('trace1_layers', 0)
        meta['nvidia_layers'] = meta.get('trace2_layers', 0)
    else:
        meta['amd_layers'] = meta.get('trace2_layers', 0)
        meta['nvidia_layers'] = meta.get('trace1_layers', 0)
    # Summary stats
    slower = [o for o in ops if o["status"] == "slower"]
    faster = [o for o in ops if o["status"] == "faster"]
    similar = [o for o in ops if o["status"] == "similar"]
    lines.append("SUMMARY")
    lines.append("-" * 80)
    lines.append(f"Operations where AMD is slower:  {len(slower)}")
    lines.append(f"Operations where AMD is faster:  {len(faster)}")
    lines.append(f"Operations with similar perf:    {len(similar)}")
    lines.append("")
    # AMD Slower
    if slower:
        slower_to_show = slower if show_all else slower[:10]
        lines.append(f"[SLOW] AMD SLOWER THAN NVIDIA (Optimization Targets) - Showing {len(slower_to_show)}/{len(slower)}")
        lines.append("=" * 140)
        lines.append(
            f"{'Operation':<22} {'AMD Count':>11} {'NV Count':>10} {'AMD Avg':>10} "
            f"{'NV Avg':>10} {'Ratio':>8} {'AMD Total':>11} {'NV Total':>11} {'AMD Slower By':>14}"
        )
        lines.append("-" * 140)
        for op in slower_to_show:
            diff_abs = abs(op["gap_ms"])
            op_name = op['operation']
            # Other operations are already split by phase (Prefill/Decode) when filtering
            if "(Mixed)" in op_name and op.get('phase_distribution') and len(op['phase_distribution']) > 1:
                # Format as "Operation (Mixed) (XX% prefill, YY% decode)"
                phase_parts = []
                for phase in ['prefill', 'decode']:  # Don't include 'mixed' in the breakdown
                    if phase in op['phase_distribution']:
                        pct = op['phase_distribution'][phase]['percentage']
                        phase_parts.append(f"{pct:.0f}% {phase}")
                if phase_parts:
                    # Replace "(Mixed)" with "(Mixed) (XX% prefill, YY% decode)"
                    op_name = op_name.replace("(Mixed)", f"(Mixed) ({', '.join(phase_parts)})")
            lines.append(
                f"{op_name:<22} "
                f"{op['amd_count']:>11,} "
                f"{op['nvidia_count']:>10,} "
                f"{op['amd_avg_us']:>8.1f}µs "
                f"{op['nvidia_avg_us']:>8.1f}µs "
                f"{op['ratio']:>7.2f}x "
                f"{op['amd_total_ms']:>9.1f}ms "
                f"{op['nvidia_total_ms']:>9.1f}ms "
                f"{diff_abs:>13.1f}ms"
            )
        lines.append("")
    # AMD Faster
    if faster:
        faster_to_show = faster if show_all else faster[:10]
        lines.append(f"[FAST] AMD FASTER THAN NVIDIA (Wins) - Showing {len(faster_to_show)}/{len(faster)}")
        lines.append("=" * 140)
        lines.append(
            f"{'Operation':<22} {'AMD Count':>11} {'NV Count':>10} {'AMD Avg':>10} "
            f"{'NV Avg':>10} {'Ratio':>8} {'AMD Total':>11} {'NV Total':>11} {'AMD Faster By':>14}"
        )
        lines.append("-" * 140)
        for op in faster_to_show:
            diff_abs = abs(op["gap_ms"])
            op_name = op['operation']
            if "(Mixed)" in op_name and op.get('phase_distribution') and len(op['phase_distribution']) > 1:
                phase_parts = []
                for phase in ['prefill', 'decode']:
                    if phase in op['phase_distribution']:
                        pct = op['phase_distribution'][phase]['percentage']
                        phase_parts.append(f"{pct:.0f}% {phase}")
                if phase_parts:
                    op_name = op_name.replace("(Mixed)", f"(Mixed) ({', '.join(phase_parts)})")
            lines.append(
                f"{op_name:<22} "
                f"{op['amd_count']:>11,} "
                f"{op['nvidia_count']:>10,} "
                f"{op['amd_avg_us']:>8.1f}µs "
                f"{op['nvidia_avg_us']:>8.1f}µs "
                f"{op['ratio']:>7.2f}x "
                f"{op['amd_total_ms']:>9.1f}ms "
                f"{op['nvidia_total_ms']:>9.1f}ms "
                f"{diff_abs:>13.1f}ms"
            )
        lines.append("")
    # Similar Performance
    if similar:
        lines.append("SIMILAR PERFORMANCE (Within 10% difference)")
        lines.append("=" * 140)
        lines.append(
            f"{'Operation':<22} {'AMD Count':>11} {'NV Count':>10} {'AMD Avg':>10} "
            f"{'NV Avg':>10} {'Ratio':>8} {'AMD Total':>11} {'NV Total':>11} {'Winner':>14}"
        )
        lines.append("-" * 140)
        for op in similar:
            if op["gap_ms"] < 0:
                winner = f"AMD by {abs(op['gap_ms']):.1f}ms"
            elif op["gap_ms"] > 0:
                winner = f"NV by {op['gap_ms']:.1f}ms"
            else:
                winner = "Tie"
            op_name = op['operation']
            if "(Mixed)" in op_name and op.get('phase_distribution') and len(op['phase_distribution']) > 1:
                phase_parts = []
                for phase in ['prefill', 'decode']:
                    if phase in op['phase_distribution']:
                        pct = op['phase_distribution'][phase]['percentage']
                        phase_parts.append(f"{pct:.0f}% {phase}")
                if phase_parts:
                    op_name = op_name.replace("(Mixed)", f"(Mixed) ({', '.join(phase_parts)})")
            lines.append(
                f"{op_name:<22} "
                f"{op['amd_count']:>11,} "
                f"{op['nvidia_count']:>10,} "
                f"{op['amd_avg_us']:>8.1f}µs "
                f"{op['nvidia_avg_us']:>8.1f}µs "
                f"{op['ratio']:>7.2f}x "
                f"{op['amd_total_ms']:>9.1f}ms "
                f"{op['nvidia_total_ms']:>9.1f}ms "
                f"{winner:>14}"
            )
        lines.append("")
    # CPU operator mapping with stack trace info
    if not show_stack_traces:
        cpu_ops_to_show = ops if show_all else ops[:15]
        lines.append(f"CPU OPERATOR MAPPING - Showing {len(cpu_ops_to_show)}/{len(ops)}")
        lines.append("=" * 80)
        lines.append("Shows the most common PyTorch/vLLM call path for each GPU operation.")
        lines.append("Use --stack-traces to see full call stacks and all variants.")
        lines.append("")
        lines.append(f"{'Operation':<25} {'CPU Operator (most common)':<45} {'Variants':<10}")
        lines.append("-" * 80)

        has_multiple_stacks = False
        for op in cpu_ops_to_show:
            cpu_op = op.get("amd_cpu_op") or op.get("nvidia_cpu_op", "N/A")
            if cpu_op and cpu_op != "N/A":
                # Shorten long operator names
                if len(cpu_op) > 43:
                    cpu_op = cpu_op[:40] + "..."
                # Count unique stack traces across both traces
                amd_stacks = op.get("trace1_python_stacks", []) if is_trace1_amd else op.get("trace2_python_stacks", [])
                nv_stacks = op.get("trace2_python_stacks", []) if is_trace1_amd else op.get("trace1_python_stacks", [])
                total_stacks = len(amd_stacks) + len(nv_stacks)
                stack_info = ""
                if total_stacks > 1:
                    stack_info = f"{total_stacks} paths"
                    has_multiple_stacks = True
                elif total_stacks == 1:
                    stack_info = "1 path"
                else:
                    stack_info = "-"
                lines.append(f"{op['operation']:<25} {cpu_op:<45} {stack_info:<10}")
        lines.append("")
        if has_multiple_stacks:
            lines.append("[warn] Multiple call paths detected. Use --stack-traces to see all variants.")
        lines.append("")
    # Kernel-level details with graph-based matching
    use_graph_matching = False
    if graph_results and graph_results.get('graph_pairs'):
        graph_pairs = graph_results['graph_pairs']
        total_kernels = 0
        matched_kernels = 0
        for pair in graph_pairs[:min(20, len(graph_pairs))]:  # Sample first 20 pairs
            for match in pair.get('matches', []):
                total_kernels += 1
                if match.get('status') == 'MATCH':
                    matched_kernels += 1
        match_rate = matched_kernels / total_kernels if total_kernels > 0 else 0
        # Only use graph matching if match rate is decent (>20%)
        # Low match rates indicate non-CUDA-graph workloads where correlation groups don't align
        use_graph_matching = match_rate > 0.20
    if use_graph_matching:

        large_graphs = [p for p in graph_pairs if len(p.get('matches', [])) >= 300]
        small_groups = [p for p in graph_pairs if len(p.get('matches', [])) < 300]
        # Section 1: Large CUDA Graphs (high accuracy, decode phase)
        if large_graphs:
            lines.append("KERNEL-LEVEL DETAILS - LARGE CUDA GRAPHS (Decode Phase)")
            lines.append("=" * 80)
            lines.append("")
            num_large_to_show = min(max_graphs, len(large_graphs)) if not show_all else len(large_graphs)
            lines.append(f"Showing {num_large_to_show} of {len(large_graphs)} large CUDA graph patterns (300+ kernels each).")
            lines.append("These are decode-phase CUDA graph captures with high matching accuracy.")
            if grouped:
                lines.append("Kernels are grouped by operation type.")
            else:
                lines.append("Kernels are shown in execution order.")
            lines.append("")
            # Show large graph patterns
            for pattern_idx in range(num_large_to_show):
                if pattern_idx >= len(large_graphs):
                    break
                graph_pair = large_graphs[pattern_idx]
                matches = graph_pair['matches']
                if num_large_to_show > 1:
                    lines.append("")
                    lines.append(f"{'=' * 80}")
                    lines.append(f"PATTERN {pattern_idx + 1}")
                    lines.append(f"{'=' * 80}")
                    lines.append("")
                if grouped:
                    lines.extend(_format_graph_kernels_grouped_by_op(matches, show_all))
                else:
                    lines.extend(_format_graph_kernels_in_order(matches, show_all))
            lines.append("")
            lines.append("=" * 80)
        # Section 2: Small Groups (prefill and misc decode kernels)
        if small_groups:
            # Detect which phases are actually present in small groups
            phases_present = set()
            for group in small_groups:
                matches = group.get('matches', [])
                for match in matches:
                    kernel = match.get('amd_kernel') or match.get('nv_kernel')
                    if kernel:
                        phase = kernel.get('phase', 'unknown')
                        if phase != 'unknown':
                            phases_present.add(phase)
            # Generate dynamic label based on phases present
            if phases_present:
                phase_labels = sorted(phases_present)
                if len(phase_labels) == 1:
                    phase_label = phase_labels[0].capitalize()
                elif 'prefill' in phase_labels and 'decode' in phase_labels:
                    phase_label = "Prefill & Decode"
                else:
                    phase_label = " & ".join(p.capitalize() for p in phase_labels)
            else:
                phase_label = "Mixed"
            lines.append("")
            lines.append(f"KERNEL-LEVEL DETAILS - SMALL GROUPS ({phase_label})")
            lines.append("=" * 80)
            lines.append("")
            # Dynamic description based on phases
            if phase_label == "Decode":
                description = "These are decode-phase kernels not captured in large CUDA graphs."
            elif phase_label == "Prefill":
                description = "These are prefill-phase kernels (typically launched individually)."
            else:
                description = f"These are {phase_label.lower()} kernels not in large CUDA graphs."
            # Flatten all small group matches into a single chronological list
            # Small groups don't have meaningful "patterns" - they're just individual kernel launches
            all_small_matches = []
            for group in small_groups:
                all_small_matches.extend(group.get('matches', []))
            all_small_matches.sort(key=lambda m: (
                m.get('amd_kernel', {}).get('ts', 0) if m.get('amd_kernel')
                else m.get('nv_kernel', {}).get('ts', 0)
            ))
            total_kernels = len(all_small_matches)
            num_to_show = min(max_graphs * 20, total_kernels) if not show_all else total_kernels  # Show more since they're not grouped
            lines.append(f"Showing {num_to_show:,} of {total_kernels:,} kernel pairs in chronological order.")
            lines.append(description)
            lines.append("These are individual kernel launches, not repeating CUDA graph patterns.")
            lines.append("")
            # Show kernels in chronological order
            if grouped:
                lines.extend(_format_graph_kernels_grouped_by_op(all_small_matches[:num_to_show], show_all))
            else:
                lines.extend(_format_graph_kernels_in_order(all_small_matches[:num_to_show], show_all))
            lines.append("")
            lines.append("=" * 80)
    else:

        non_similar_ops = [op for op in ops if op["status"] != "similar"]
        top_ops = non_similar_ops if show_all else non_similar_ops[:3]
        lines.append("KERNEL-LEVEL DETAILS (Top Individual Kernels)")
        lines.append("=" * 80)
        lines.append("")
        if show_all:
            lines.append(f"Showing all kernels for {len(top_ops)} operations with performance gaps:")
        else:
            lines.append("Showing top 10 kernels for the 3 operations with largest performance gaps:")
        lines.append("")
        for op in top_ops:
            lines.append(f"Operation: {op['operation']}")
            lines.append("-" * 80)
            # AMD kernels
            all_amd_kernels = op.get("amd_kernels", [])
            amd_kernels = all_amd_kernels if show_all else all_amd_kernels[:10]
            if amd_kernels:
                kernel_label = f"All {len(amd_kernels)}" if show_all else "Top 10"
                lines.append(f"\n  AMD {kernel_label} Kernels (Total: {op['amd_count']} invocations):")
                lines.append(f"  {'Kernel Name':<50} {'Total (µs)':>12} {'Count':>8} {'Avg (µs)':>10}")
                lines.append("  " + "-" * 80)
                for k in amd_kernels:
                    name = k["name"][:47] + "..." if len(k["name"]) > 50 else k["name"]
                    lines.append(
                        f"  {name:<50} {k['total_us']:>12.0f} {k['count']:>8,} {k['avg_us']:>10.1f}"
                    )
            # NVIDIA kernels
            all_nv_kernels = op.get("nvidia_kernels", [])
            nv_kernels = all_nv_kernels if show_all else all_nv_kernels[:10]
            if nv_kernels:
                kernel_label = f"All {len(nv_kernels)}" if show_all else "Top 10"
                lines.append(f"\n  NVIDIA {kernel_label} Kernels (Total: {op['nvidia_count']} invocations):")
                lines.append(f"  {'Kernel Name':<50} {'Total (µs)':>12} {'Count':>8} {'Avg (µs)':>10}")
                lines.append("  " + "-" * 80)
                for k in nv_kernels:
                    name = k["name"][:47] + "..." if len(k["name"]) > 50 else k["name"]
                    lines.append(
                        f"  {name:<50} {k['total_us']:>12.0f} {k['count']:>8,} {k['avg_us']:>10.1f}"
                    )
            lines.append("")
        lines.append("=" * 80)
    # Python stack traces if requested
    if show_stack_traces:
        stack_trace_report = _format_stack_trace_report(results, show_all=show_all)
        lines.append("")
        lines.extend(stack_trace_report)
    return "\n".join(lines)


def _format_stack_trace_report(results: dict[str, Any], show_all: bool = False) -> list[str]:
    """Format Python stack traces for operations.
    Args:
        results: Analysis results
        show_all: Whether to show all stack traces without truncation
    Returns:
        List of formatted text lines
    """
    lines = []
    ops = results["operations"]
    meta = results["metadata"]
    is_trace1_amd = meta['trace1_platform'] == 'AMD'
    lines.append("=" * 80)
    lines.append("PYTHON STACK TRACES & CPU OPERATOR MAPPING")
    lines.append("=" * 80)
    lines.append("")
    lines.append("Full call stacks showing where GPU operations are invoked from PyTorch/vLLM.")
    lines.append("")
    # Show stack traces for top operations by impact (or all if show_all)
    ops_with_stacks = [
        op for op in ops
        if (op.get("trace1_python_stacks") or op.get("trace2_python_stacks"))
    ]
    if not ops_with_stacks:
        lines.append("No stack trace information available.")
        return lines
    ops_to_show = ops_with_stacks if show_all else ops_with_stacks[:10]
    lines.append(f"Showing {len(ops_to_show)}/{len(ops_with_stacks)} operations")
    lines.append("")
    for op in ops_to_show:
        lines.append(f"Operation: {op['operation']}")
        # Show CPU operator info
        amd_cpu = op.get("trace1_cpu_op" if is_trace1_amd else "trace2_cpu_op", "N/A")
        nv_cpu = op.get("trace2_cpu_op" if is_trace1_amd else "trace1_cpu_op", "N/A")
        if amd_cpu != "N/A" or nv_cpu != "N/A":
            lines.append("  Most common CPU operator:")
            if amd_cpu != "N/A":
                lines.append(f"    AMD:    {amd_cpu}")
            if nv_cpu != "N/A":
                lines.append(f"    NVIDIA: {nv_cpu}")
        lines.append("-" * 80)
        # AMD/Trace1 stacks
        trace1_stacks = op.get("trace1_python_stacks", [])
        if trace1_stacks:
            stacks_to_show = trace1_stacks if show_all else trace1_stacks[:3]
            label = "AMD" if is_trace1_amd else "NVIDIA"
            lines.append(f"  {label} Stack Traces ({len(stacks_to_show)}/{len(trace1_stacks)} shown):")
            for i, stack in enumerate(stacks_to_show, 1):
                lines.append(f"    Variant {i}:")
                for frame in stack:
                    lines.append(f"      {frame}")
                if i < len(stacks_to_show):
                    lines.append("")
        # NVIDIA/Trace2 stacks
        trace2_stacks = op.get("trace2_python_stacks", [])
        if trace2_stacks:
            stacks_to_show = trace2_stacks if show_all else trace2_stacks[:3]
            label = "NVIDIA" if is_trace1_amd else "AMD"
            if trace1_stacks:
                lines.append("")
            lines.append(f"  {label} Stack Traces ({len(stacks_to_show)}/{len(trace2_stacks)} shown):")
            for i, stack in enumerate(stacks_to_show, 1):
                lines.append(f"    Variant {i}:")
                for frame in stack:
                    lines.append(f"      {frame}")
                if i < len(stacks_to_show):
                    lines.append("")
        lines.append("")
    return lines


def format_csv(results: dict[str, Any], report_type: str = "operations") -> str:
    """Format comparison results as CSV.
    Args:
        results: Analysis results
        report_type: 'operations' or 'layers'
    Returns:
        CSV formatted string
    """
    lines = []
    meta = results["metadata"]
    is_trace1_amd = meta['trace1_platform'] == 'AMD'
    if report_type == "layers":
        lines.append("layer,amd_kernels,nvidia_kernels,amd_total_ms,nvidia_total_ms,ratio,gap_ms,status,in_both")
        for layer in results.get("layers", []):
            if is_trace1_amd:
                amd_kernels = layer['trace1_kernels']
                nvidia_kernels = layer['trace2_kernels']
                amd_total_ms = layer['trace1_total_ms']
                nvidia_total_ms = layer['trace2_total_ms']
            else:
                amd_kernels = layer['trace2_kernels']
                nvidia_kernels = layer['trace1_kernels']
                amd_total_ms = layer['trace2_total_ms']
                nvidia_total_ms = layer['trace1_total_ms']
            lines.append(
                f"{layer['layer']},"
                f"{amd_kernels},"
                f"{nvidia_kernels},"
                f"{amd_total_ms:.2f},"
                f"{nvidia_total_ms:.2f},"
                f"{layer['ratio']:.3f},"
                f"{layer['gap_ms']:.2f},"
                f"{layer['status']},"
                f"{layer.get('in_both', True)}"
            )
    else:
        lines.append(
            "operation,amd_count,nvidia_count,amd_avg_us,nvidia_avg_us,amd_total_ms,"
            "nvidia_total_ms,ratio,gap_ms,status,amd_kernel,nvidia_kernel,amd_cpu_op,nvidia_cpu_op"
        )
        for op in results["operations"]:
            if is_trace1_amd:
                amd_count = op['trace1_count']
                nvidia_count = op['trace2_count']
                amd_avg_us = op['trace1_avg_us']
                nvidia_avg_us = op['trace2_avg_us']
                amd_total_ms = op['trace1_total_ms']
                nvidia_total_ms = op['trace2_total_ms']
                amd_kernel = op.get('trace1_kernel', '')
                nvidia_kernel = op.get('trace2_kernel', '')
                amd_cpu_op = op.get('trace1_cpu_op', '')
                nvidia_cpu_op = op.get('trace2_cpu_op', '')
            else:
                amd_count = op['trace2_count']
                nvidia_count = op['trace1_count']
                amd_avg_us = op['trace2_avg_us']
                nvidia_avg_us = op['trace1_avg_us']
                amd_total_ms = op['trace2_total_ms']
                nvidia_total_ms = op['trace1_total_ms']
                amd_kernel = op.get('trace2_kernel', '')
                nvidia_kernel = op.get('trace1_kernel', '')
                amd_cpu_op = op.get('trace2_cpu_op', '')
                nvidia_cpu_op = op.get('trace1_cpu_op', '')
            lines.append(
                f"{op['operation']},"
                f"{amd_count},"
                f"{nvidia_count},"
                f"{amd_avg_us:.2f},"
                f"{nvidia_avg_us:.2f},"
                f"{amd_total_ms:.2f},"
                f"{nvidia_total_ms:.2f},"
                f"{op['ratio']:.3f},"
                f"{op['gap_ms']:.2f},"
                f"{op['status']},"
                f"{amd_kernel},"
                f"{nvidia_kernel},"
                f"{amd_cpu_op},"
                f"{nvidia_cpu_op}"
            )
    return "\n".join(lines)


def format_json(results: dict[str, Any], graph_results: dict[str, Any] | None = None, compact: bool = False) -> str:
    """Format comparison results as JSON.
    Args:
        results: Analysis results
        graph_results: Optional graph matching results from match_traces()
        compact: If True, use compact JSON (no indentation). Recommended for programmatic use
                 to reduce output size by ~2x. Default False for human readability.
    Returns:
        JSON formatted string
    """
    output = _sanitize_for_json(results)
    # Include graph matching data if available
    if graph_results:
        output['graph_matching'] = _sanitize_for_json(graph_results)
    if HAS_ORJSON:
        # orjson.dumps returns bytes, need to decode to str
        # OPT_NON_STR_KEYS allows non-string dict keys (needed for some data structures)
        if compact:
            return orjson.dumps(output, option=orjson.OPT_NON_STR_KEYS).decode('utf-8')
        else:
            # OPT_INDENT_2 provides readable formatting like json.dumps(indent=2)
            return orjson.dumps(output, option=orjson.OPT_INDENT_2 | orjson.OPT_NON_STR_KEYS).decode('utf-8')
    else:
        if compact:
            return json.dumps(output)
        else:
            return json.dumps(output, indent=2)


def format_fusion_text(results: dict[str, Any]) -> str:
    """Format fusion analysis results as human-readable text.
    Args:
        results: Fusion analysis results
    Returns:
        Formatted text report
    """
    lines = []
    meta = results["metadata"]
    lines.append("=" * 80)
    lines.append("FUSION ANALYSIS REPORT")
    lines.append("=" * 80)
    lines.append("")
    lines.append(f"Trace 1 GPU:  {meta['trace1_gpu']}")
    lines.append(f"Trace 2 GPU:  {meta['trace2_gpu']}")
    lines.append(f"Trace 1 Kernels:  {meta['trace1_total_kernels']:,}")
    lines.append(f"Trace 2 Kernels: {meta['trace2_total_kernels']:,}")
    lines.append("")
    lines.append("Correlation Groups Analyzed:")
    lines.append(f"  Trace 1: {meta['trace1_correlation_groups']}")
    lines.append(f"  Trace 2: {meta['trace2_correlation_groups']}")
    lines.append(f"  Matched: {meta['matched_groups']}")
    lines.append("")
    # Note: fusion analyzer always uses AMD as trace1, NVIDIA as trace2
    global_counts = results["global_counts"]
    for ktype, counts in global_counts.items():
        counts["amd_count"] = counts["trace1_count"]
        counts["nv_count"] = counts["trace2_count"]
    for opp in results.get("fusion_opportunities", []):
        opp["amd_total"] = opp["trace1_total"]
        opp["nvidia_total"] = opp["trace2_total"]
        opp["amd_avg_per_group"] = opp["trace1_avg_per_group"]
        opp["nvidia_avg_per_group"] = opp["trace2_avg_per_group"]
        opp["amd_time_ms"] = opp["trace1_time_ms"]
        opp["nvidia_time_ms"] = opp["trace2_time_ms"]
    # Global kernel type distribution
    lines.append("GLOBAL KERNEL TYPE DISTRIBUTION")
    lines.append("=" * 80)
    lines.append(f"{'Kernel Type':<25} {'AMD Count':>12} {'NVIDIA Count':>15} {'Ratio':>12}")
    lines.append("-" * 80)
    sorted_types = sorted(
        global_counts.items(),
        key=lambda x: x[1]["amd_count"] + x[1]["nv_count"],
        reverse=True,
    )
    for ktype, counts in sorted_types:
        amd_c = counts["amd_count"]
        nv_c = counts["nv_count"]
        ratio = counts["ratio"]
        # Mark significant differences
        marker = ""
        if ratio > 2.0:
            marker = " [warn] AMD has more"
        elif ratio < 0.5:
            marker = " [warn] NVIDIA has more"
        elif nv_c == 0 and amd_c > 20:
            marker = " AMD ONLY"
        elif amd_c == 0 and nv_c > 20:
            marker = " NVIDIA ONLY"
        ratio_str = f"{ratio:.2f}x" if ratio != float("inf") else "∞"
        lines.append(f"{ktype:<25} {amd_c:>12,} {nv_c:>15,} {ratio_str:>12}{marker}")
    lines.append("")
    # Fusion opportunities
    if results["fusion_opportunities"]:
        lines.append("FUSION OPPORTUNITIES")
        lines.append("=" * 80)
        lines.append("")
        amd_fuses = [opp for opp in results["fusion_opportunities"] if opp["fused_by"] in ("AMD", "Trace 1")]
        nv_fuses = [opp for opp in results["fusion_opportunities"] if opp["fused_by"] in ("NVIDIA", "Trace 2")]
        if nv_fuses:
            lines.append("[SLOW] OPERATIONS AMD RUNS SEPARATELY (NVIDIA fuses them)")
            lines.append("-" * 80)
            lines.append("")
            for i, opp in enumerate(nv_fuses, 1):
                lines.append(f"{i}. {opp['kernel_type']}")
                lines.append("   Kernel Launches:")
                lines.append(f"     AMD:    {opp['amd_total']:,} calls ({opp['amd_avg_per_group']:.1f} per group)")
                lines.append(f"     NVIDIA: {opp['nvidia_total']:,} calls ({opp['nvidia_avg_per_group']:.1f} per group)")
                lines.append(f"     Ratio:  {opp['ratio']:.2f}x (AMD launches more)")
                lines.append("   Execution Time:")
                lines.append(f"     AMD:    {opp['amd_time_ms']:.2f} ms")
                lines.append(f"     NVIDIA: {opp['nvidia_time_ms']:.2f} ms")
                time_marker = ""
                if opp["time_ratio"] > 1.2:
                    time_marker = " (AMD slower [warn])"
                elif opp["time_ratio"] < 0.8:
                    time_marker = " (AMD faster [ok])"
                else:
                    time_marker = " (similar)"
                lines.append(f"     Ratio:  {opp['time_ratio']:.2f}x{time_marker}")
                lines.append(f"   Impact: {opp['groups_affected']}/{opp['total_groups']} groups show this difference")
                # Provide interpretation
                if opp["nvidia_total"] == 0:
                    lines.append("   -> NVIDIA completely fuses this operation into another kernel")
                else:
                    lines.append(f"   -> NVIDIA partially fuses, using {opp['ratio']:.1f}x fewer calls")
                lines.append("")
        if amd_fuses:
            lines.append("[FAST] OPERATIONS NVIDIA RUNS SEPARATELY (AMD fuses them)")
            lines.append("-" * 80)
            lines.append("")
            for i, opp in enumerate(amd_fuses, 1):
                lines.append(f"{i}. {opp['kernel_type']}")
                lines.append("   Kernel Launches:")
                lines.append(f"     AMD:    {opp['amd_total']:,} calls ({opp['amd_avg_per_group']:.1f} per group)")
                lines.append(f"     NVIDIA: {opp['nvidia_total']:,} calls ({opp['nvidia_avg_per_group']:.1f} per group)")
                lines.append(f"     Ratio:  {opp['ratio']:.2f}x (NVIDIA launches more)")
                lines.append("   Execution Time:")
                lines.append(f"     AMD:    {opp['amd_time_ms']:.2f} ms")
                lines.append(f"     NVIDIA: {opp['nvidia_time_ms']:.2f} ms")
                time_marker = ""
                if opp["time_ratio"] > 1.2:
                    time_marker = " (AMD slower despite fusion [warn])"
                elif opp["time_ratio"] < 0.8:
                    time_marker = " (AMD faster via fusion [ok])"
                else:
                    time_marker = " (similar)"
                lines.append(f"     Ratio:  {opp['time_ratio']:.2f}x{time_marker}")
                lines.append(f"   Impact: {opp['groups_affected']}/{opp['total_groups']} groups show this difference")
                lines.append("")
    else:
        lines.append("No significant fusion differences detected.")
        lines.append("")
    # Fusion mappings
    fusion_mappings = results.get("fusion_mappings", [])
    if fusion_mappings:
        lines.append("")
        lines.append("FUSION MAPPINGS")
        lines.append("=" * 80)
        lines.append("")
        sequence_mappings = []
        intra_type_mappings = []
        partial_mappings = []
        for mapping in fusion_mappings:
            if len(mapping["unfused_sequence"]) == 2 and \
               mapping["unfused_sequence"][0] == mapping["unfused_sequence"][1] and \
               mapping["unfused_sequence"][0] == mapping["fused_kernel_type"]:
                intra_type_mappings.append(mapping)
            elif len(mapping["unfused_sequence"]) == 1:
                partial_mappings.append(mapping)
            else:
                sequence_mappings.append(mapping)
        # Show sequence fusion
        if sequence_mappings:
            lines.append("SEQUENCE FUSION")
            lines.append("-" * 80)
            lines.append("")
            from collections import defaultdict
            grouped = defaultdict(list)
            for m in sequence_mappings:
                grouped[m["evidence"]].append(m)
            for evidence, group in list(grouped.items())[:5]:  # Show top 5 patterns
                lines.append(f"Pattern: {evidence}")
                lines.append(f"  Occurrences: {len(group)} correlation groups")
                lines.append(f"  Total calls: {sum(m['pattern_count'] for m in group):,}")
                lines.append(f"  Confidence: {group[0]['pattern_confidence'] * 100:.0f}%")
                lines.append("")
            if len(grouped) > 5:
                lines.append(f"... and {len(grouped) - 5} more sequence fusion patterns")
                lines.append("")
        # Show intra-type fusion
        if intra_type_mappings:
            lines.append("INTRA-TYPE FUSION (Chain Compression)")
            lines.append("-" * 80)
            lines.append("")
            for mapping in intra_type_mappings:
                # pattern_count = unfused_total - fused_total, so unfused_total = pattern_count + fused_count
                unfused_total = mapping['pattern_count'] + mapping['fused_count']
                compression_ratio = unfused_total / max(mapping['fused_count'], 1)
                lines.append(f"Kernel: {mapping['fused_kernel_type']}")
                lines.append(f"  {mapping['evidence']}")
                lines.append(f"  Compression ratio: {compression_ratio:.1f}x")
                lines.append("")
        # Show partial fusion
        if partial_mappings:
            lines.append("PARTIAL FUSION")
            lines.append("-" * 80)
            lines.append("")
            for mapping in partial_mappings[:5]:  # Show top 5
                lines.append(f"Kernel: {mapping['unfused_sequence'][0]}")
                lines.append(f"  {mapping['evidence']}")
                lines.append("")
    lines.append("=" * 80)
    return "\n".join(lines)


def _sanitize_for_json(obj: Any) -> Any:
    """Recursively sanitize data structure to handle Infinity, NaN, and numpy types.
    Args:
        obj: Data structure to sanitize
    Returns:
        Sanitized data structure with special values and types converted to JSON-compatible types
    """
    import math
    if hasattr(obj, 'item'):  # numpy scalar
        obj = obj.item()  # Convert to native Python type
    if isinstance(obj, float):
        if math.isinf(obj) or math.isnan(obj):
            return None
        return obj
    elif isinstance(obj, dict):
        return {k: _sanitize_for_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_sanitize_for_json(item) for item in obj]
    else:
        return obj


def format_fusion_json(results: dict[str, Any]) -> str:
    """Format fusion analysis results as JSON.
    Args:
        results: Fusion analysis results
    Returns:
        JSON formatted string
    """
    sanitized = _sanitize_for_json(results)
    return json.dumps(sanitized, indent=2)


def _format_graph_kernels_in_order(matches: list[dict[str, Any]], show_all: bool) -> list[str]:
    """Format graph-matched kernels in position order for kernel-level details section."""
    lines = []
    max_pairs = len(matches) if show_all else min(20, len(matches))
    lines.append(f"{'Pos':<4} {'AMD Kernel':<35} {'AMD µs':>8} {'NV Kernel':<35} {'NV µs':>8} {'Ratio':>7} {'Status':<9}")
    lines.append("-" * 120)
    for idx, match in enumerate(matches[:max_pairs], 1):
        status_icon = {
            'MATCH': 'MATCH',
            'AMD_ONLY': 'AMD-only',
            'NV_ONLY': 'NV-only',
            'MISMATCH': 'MISMATCH',
        }.get(match['status'], '?')
        if idx == 1 or (idx > 1 and match['amd_type'] != matches[idx - 2]['amd_type']):
            op_type = match['amd_type'] if match['amd_type'] != '-' else match['nv_type']
            lines.append("")
            lines.append(f"[{op_type}]")
        amd_name = match['amd_name'][:34] if match['amd_name'] != '-' else '-'
        nv_name = match['nv_name'][:34] if match['nv_name'] != '-' else '-'
        amd_dur = match.get('amd_kernel', {}).get('dur', 0) if match.get('amd_kernel') else 0
        nv_dur = match.get('nv_kernel', {}).get('dur', 0) if match.get('nv_kernel') else 0
        # Format timing columns
        amd_time_str = f"{amd_dur:.1f}" if amd_dur > 0 else "-"
        nv_time_str = f"{nv_dur:.1f}" if nv_dur > 0 else "-"
        if amd_dur > 0 and nv_dur > 0:
            ratio = amd_dur / nv_dur
            ratio_str = f"{ratio:.2f}x"
        else:
            ratio_str = "-"
        lines.append(f"{idx:<4} {amd_name:<35} {amd_time_str:>8} {nv_name:<35} {nv_time_str:>8} {ratio_str:>7} {status_icon:<9}")
    if not show_all and len(matches) > 20:
        lines.append(f"     ... ({len(matches) - 20} more kernel pairs)")
    return lines


def _format_graph_kernels_grouped_by_op(matches: list[dict[str, Any]], show_all: bool) -> list[str]:
    """Format graph-matched kernels grouped by operation type for kernel-level details section."""
    from collections import defaultdict
    lines = []
    by_op: dict[str, list[tuple[int, dict[str, Any]]]] = defaultdict(list)
    for idx, match in enumerate(matches, 1):
        op_type = match['amd_type'] if match['amd_type'] != '-' else match['nv_type']
        by_op[op_type].append((idx, match))
    sorted_ops = sorted(by_op.items(), key=lambda x: x[1][0][0])
    for op_type, op_matches in sorted_ops:
        lines.append(f"── {op_type} ({len(op_matches)} kernel pairs) " + "─" * (80 - len(f"── {op_type} ({len(op_matches)} kernel pairs) ")))
        lines.append(f"{'Pos':<4} {'AMD Kernel':<35} {'AMD µs':>8} {'NV Kernel':<35} {'NV µs':>8} {'Ratio':>7} {'Status':<9}")
        lines.append("-" * 120)
        max_to_show = len(op_matches) if show_all else min(5, len(op_matches))
        for idx, match in op_matches[:max_to_show]:
            status_icon = {
                'MATCH': 'MATCH',
                'AMD_ONLY': 'AMD-only',
                'NV_ONLY': 'NV-only',
                'MISMATCH': 'MISMATCH',
            }.get(match['status'], '?')
            amd_name = match['amd_name'][:34] if match['amd_name'] != '-' else '-'
            nv_name = match['nv_name'][:34] if match['nv_name'] != '-' else '-'
            amd_dur = match.get('amd_kernel', {}).get('dur', 0) if match.get('amd_kernel') else 0
            nv_dur = match.get('nv_kernel', {}).get('dur', 0) if match.get('nv_kernel') else 0
            # Format timing columns
            amd_time_str = f"{amd_dur:.1f}" if amd_dur > 0 else "-"
            nv_time_str = f"{nv_dur:.1f}" if nv_dur > 0 else "-"
            if amd_dur > 0 and nv_dur > 0:
                ratio = amd_dur / nv_dur
                ratio_str = f"{ratio:.2f}x"
            else:
                ratio_str = "-"
            lines.append(f"{idx:<4} {amd_name:<35} {amd_time_str:>8} {nv_name:<35} {nv_time_str:>8} {ratio_str:>7} {status_icon:<9}")
        if not show_all and len(op_matches) > 5:
            lines.append(f"     ... ({len(op_matches) - 5} more {op_type} pairs)")
        lines.append("")
    return lines
