"""
Tool execution component - displays tool calls with arguments and results.
"""
from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from ..tui import Container
from .text import Text

if TYPE_CHECKING:
    from ....dtypes import DetailLevel


class ToolExecution(Container):
    """Component that renders a tool call with its result (updateable)."""
    def __init__(
        self,
        tool_name: str,
        args: dict[str, Any] | None = None,
        bg_fn_pending: Callable[[str], str] | None = None,
        bg_fn_success: Callable[[str], str] | None = None,
        bg_fn_error: Callable[[str], str] | None = None,
        theme: Any | None = None,
        formatter: Callable[[str, dict[str, Any], dict[str, Any] | None, bool, Any], str]
        | None = None,
        render_config: Any | None = None,  # ToolRenderConfig, Any to avoid circular import
    ) -> None:
        """Initialize tool execution component.
        Args:
            tool_name: Name of the tool
            args: Tool arguments (may be partial during streaming)
            bg_fn_pending: Background color function for pending state
            bg_fn_success: Background color function for success state
            bg_fn_error: Background color function for error state
            theme: Theme for styling
            formatter: Formatter function for display
            render_config: ToolRenderConfig from environment
        """
        super().__init__()
        self._tool_name = tool_name
        self._args = args or {}
        self._result: dict[str, Any] | None = None
        # Import here to avoid circular imports at module level
        from ....dtypes import DetailLevel
        self._detail_level: DetailLevel = DetailLevel.STANDARD
        self._theme = theme
        self._formatter = formatter
        self._render_config = render_config
        # Default background functions (can be overridden)
        self._bg_fn_pending = bg_fn_pending or (lambda x: x)
        self._bg_fn_success = bg_fn_success or (lambda x: x)
        self._bg_fn_error = bg_fn_error or (lambda x: x)
        self._content_text: Text | None = None
        self._streaming_output: str = ""
        self._rebuild_display()

    def update_args(self, args: dict[str, Any]) -> None:
        """Update tool arguments (called during streaming).
        Reuses existing Text component via set_text() to avoid recreating it on every delta.
        """
        self._args = args
        if self._content_text is not None and not self._result:
            formatted_text = self._format_tool_execution()
            self._content_text.set_text(formatted_text)
        else:
            self._rebuild_display()

    def update_result_delta(self, delta: str) -> None:
        """Append incremental output while tool is still running (e.g., bash stdout)."""
        self._streaming_output += delta
        if self._content_text is not None and not self._result:
            formatted_text = self._format_tool_execution()
            self._content_text.set_text(formatted_text)

    def update_result(
        self,
        result: dict[str, Any],
        is_error: bool = False,
    ) -> None:
        """Update tool result.
        Args:
            result: Result data (may contain 'content' list, 'details' dict, or 'text' string)
            is_error: Whether this is an error result
        """
        assert "content" in result or "details" in result, (
            f"Result must have 'content' or 'details' key, got: {list(result.keys())}"
        )
        self._result = {**result, "isError": is_error}
        self._rebuild_display()

    def set_detail_level(self, level: DetailLevel) -> None:
        """Set the detail level for output display."""
        self._detail_level = level
        self._rebuild_display()

    def _rebuild_display(self) -> None:
        """Rebuild the display from current state."""
        self.clear()

        if self._result:
            bg_fn = self._bg_fn_error if self._result.get("isError") else self._bg_fn_success
        else:
            bg_fn = self._bg_fn_pending
        # Format tool execution text
        formatted_text = self._format_tool_execution()
        if self._theme:
            if self._result:
                gutter = (
                    self._theme.tool_error_gutter
                    if self._result.get("isError")
                    else self._theme.tool_success_gutter
                )
            else:
                gutter = self._theme.tool_success_gutter  # Pending state uses success gutter
            padding_y = self._theme.tool_padding_y if hasattr(self._theme, "tool_padding_y") else 0
        else:

            gutter = ""
            padding_y = 0
        self._content_text = Text(
            formatted_text,
            padding_x=1,
            padding_y=padding_y,
            custom_bg_fn=bg_fn,
            gutter_prefix=gutter,
        )
        self.add_child(self._content_text)

    def _get_text_output(self) -> str:
        """Extract text output from result."""
        if not self._result:
            return ""
        content = self._result.get("content", {})
        # If content is a string, return it directly
        if isinstance(content, str):
            return content
        # If content is a dict with a "content" key, extract from that
        if isinstance(content, dict):
            content_list = content.get("content", [])
            if isinstance(content_list, list):
                text_blocks = [
                    c for c in content_list if isinstance(c, dict) and c.get("type") == "text"
                ]
                text_output = "\n".join(c.get("text", "") for c in text_blocks if c.get("text"))
                # Strip ANSI codes and carriage returns
                import re
                text_output = re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", text_output)  # Strip ANSI
                text_output = text_output.replace("\r", "")  # Strip carriage returns
                return text_output
        return ""

    def _format_tool_execution(self) -> str:
        """Format tool execution display.
        When streaming (no result yet), shows the tool header plus the streaming
        content arg (e.g. file content, command) as it arrives from the LLM.
        If live output is arriving (bash streaming), shows that below the header.
        When complete (result received), delegates to format_tool for final display.
        """
        from ....environments._formatting import format_streaming_tool, format_tool

        if not self._result and self._args:
            base = format_streaming_tool(
                self._tool_name,
                self._args,
                self._detail_level,
                self._theme,
                self._render_config,
            )
            if self._streaming_output:
                return self._append_live_output(base)
            return base

        if self._render_config:
            return format_tool(
                self._tool_name,
                self._args,
                self._result,
                self._detail_level,
                self._theme,
                self._render_config,
            )
        if self._formatter:
            from ....dtypes import DetailLevel
            expanded_bool = self._detail_level >= DetailLevel.EXPANDED
            return self._formatter(
                self._tool_name, self._args, self._result, expanded_bool, self._theme
            )
        return format_tool(
            self._tool_name, self._args, self._result, self._detail_level, self._theme
        )

    def _append_live_output(self, base: str) -> str:
        """Append live streaming output below the header, showing last N lines."""
        max_live_lines = 10
        lines = self._streaming_output.rstrip("\n").split("\n")
        total = len(lines)
        if total > max_live_lines:
            visible = lines[-max_live_lines:]
            parts = [base, f"  ... ({total - max_live_lines} lines above)"]
        else:
            visible = lines
            parts = [base]
        for line in visible:
            parts.append(f"  {line}")
        return "\n".join(parts)
