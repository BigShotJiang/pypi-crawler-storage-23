"""Per-turn score extraction from agent trajectories.

Scans tool output messages for Score JSON ({"metrics": [...]}) and records
a TurnScore at each message index. Gives per-turn reward curves for RL.
"""
from __future__ import annotations

import json
from typing import Any

from wafer.core.rollouts.dtypes import Score, TurnScore


def extract_json_objects(text: str) -> list[dict[str, Any]]:
    """Extract all top-level JSON objects from a string via brace-counting."""
    results: list[dict[str, Any]] = []
    i = 0
    while i < len(text):
        if text[i] == "{":
            depth = 0
            start = i
            in_string = False
            escape_next = False
            for j in range(i, len(text)):
                c = text[j]
                if escape_next:
                    escape_next = False
                    continue
                if c == "\\" and in_string:
                    escape_next = True
                    continue
                if c == '"' and not escape_next:
                    in_string = not in_string
                    continue
                if in_string:
                    continue
                if c == "{":
                    depth += 1
                elif c == "}":
                    depth -= 1
                    if depth == 0:
                        candidate = text[start : j + 1]
                        try:
                            obj = json.loads(candidate)
                            if isinstance(obj, dict):
                                results.append(obj)
                        except (json.JSONDecodeError, ValueError):
                            pass
                        i = j + 1
                        break
            else:
                i += 1
        else:
            i += 1
    return results


def extract_turn_scores(sample: Any) -> tuple[TurnScore, ...]:
    """Scan tool output messages for Score JSON, return per-turn scores.

    Each tool output that contains a valid {"metrics": [...]} JSON object
    produces a TurnScore anchored to that message's index.
    """
    trajectory = sample.trajectory
    if trajectory is None or not trajectory.messages:
        return ()

    results: list[TurnScore] = []
    for i, msg in enumerate(trajectory.messages):
        role = msg.role if hasattr(msg, "role") else msg.get("role")
        if role != "tool":
            continue
        content = msg.content if hasattr(msg, "content") else msg.get("content")
        if not isinstance(content, str) or not content.strip():
            continue
        for data in extract_json_objects(content):
            if "metrics" not in data:
                continue
            try:
                score = Score.from_dict(data)
                results.append(TurnScore(message_index=i, score=score))
            except (AssertionError, KeyError, TypeError):
                continue
    return tuple(results)


def best_turn_score(turn_scores: tuple[TurnScore, ...]) -> TurnScore | None:
    """Return the TurnScore with highest reward, or None if empty."""
    if not turn_scores:
        return None
    return max(turn_scores, key=lambda ts: ts.score.reward)
