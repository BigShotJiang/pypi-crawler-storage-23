"""Eval code scorer tool for agent-driven hillclimbing.

Exposes CodeScorer as a first-class agent tool.
The agent can use builtin code scorers (kernelbench, gpumode, etc.) or write
a custom scorer in a .py file and point this tool at it.

The CodeScorer interface the agent must implement:

    from pathlib import Path
    from wafer.eval import Score, Metric
    from wafer.eval.sandbox_runner import sandbox_run

    async def score(work_dir: Path) -> Score:
        output = await sandbox_run(
            "cd solution && nvcc -O3 gemm.cu -o gemm -lcublas && ./gemm",
            sync_path=work_dir,
        )
        # Parse output, return Score with Metric entries
        return Score(metrics=(
            Metric("my_metric", value, weight=0.0),
            Metric("score", composite, weight=1.0),
        ))

For remote GPU execution, use sandbox_run() from wafer.eval.sandbox_runner.
"""
import json
from pathlib import Path

from wafer.core.rollouts.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
)

EVAL_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="eval_task",
        description=(
            "Evaluate the current solution using a Scorer. "
            "Pass a path to a .py file that defines an async score(work_dir) function, "
            "or a builtin name. Returns JSON with scored metrics. Use in a loop: "
            "edit code -> eval_task(task='./scorer.py', after='.') -> read score -> repeat.\n\n"
            "Create scorer.py with an async score(work_dir) function. For GPU execution, use "
            "sandbox_run(sync_path=work_dir, command='...') so the scorer syncs the "
            "local dir and runs on the remote GPU—no manual sandbox upload needed.\n"
            "Example: output = await sandbox_run('cd solution && nvcc -O3 gemm.cu "
            "-o gemm -lcublas && ./gemm', sync_path=work_dir)"
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "task": {
                    "type": "string",
                    "description": (
                        "Path to a .py file (e.g. './scorer.py') with an async score() function, "
                        "or builtin name (kernelbench, hipblaslt-gemm, etc.). Custom scorers "
                        "use sandbox_run(sync_path=...) to sync and run on GPU."
                    ),
                },
                "after": {
                    "type": "string",
                    "description": "Directory to evaluate (default: current directory '.')",
                },
                "before": {
                    "type": "string",
                    "description": "Optional baseline directory for comparison scoring.",
                },
            },
        ),
        required=["task"],
    ),
)


async def exec_eval(
    tool_call: ToolCall,
    working_dir: Path,
) -> ToolResult:
    """Execute eval scorer: load scorer, call it on the directory."""
    assert tool_call.name == "eval_task"
    assert "task" in tool_call.args

    scorer_name = tool_call.args["task"]
    after_dir = Path(tool_call.args.get("after", "."))
    before_dir_str = tool_call.args.get("before")

    if not after_dir.is_absolute():
        after_dir = working_dir / after_dir
    after_dir = after_dir.resolve()

    assert after_dir.is_dir(), f"--after directory does not exist: {after_dir}"

    if scorer_name.endswith(".py") and not Path(scorer_name).is_absolute():
        scorer_name = str((working_dir / scorer_name).resolve())

    try:
        from wafer.eval import load_code_scorer
        scorer = load_code_scorer(scorer_name)
    except Exception as e:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=f"Failed to load code scorer {scorer_name!r}: {e}",
        )

    before_dir: Path | None = None
    if before_dir_str:
        before_dir = Path(before_dir_str)
        if not before_dir.is_absolute():
            before_dir = working_dir / before_dir
        before_dir = before_dir.resolve()
        assert before_dir.is_dir(), f"--before directory does not exist: {before_dir}"

    try:
        import trio
        score = await trio.to_thread.run_sync(
            lambda: _run_scorer(scorer, after_dir, before_dir)
        )
    except Exception as e:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content="",
            error=f"Scorer failed: {e}",
        )

    score_dict = score.to_dict()
    details = {m["name"]: m["value"] for m in score_dict["metrics"]}

    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=json.dumps(score_dict, indent=2),
        details=details,
    )


def _run_scorer(scorer: object, work_dir: Path, baseline_dir: Path | None) -> object:
    """Run scorer in a sync context (called via trio.to_thread)."""
    import asyncio
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(scorer(work_dir, baseline_dir=baseline_dir))
    finally:
        loop.close()
