# TrustClaw

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

**Cloud agent with OAuth, sandbox, and 1000+ tools.**

Looking for a production-ready agent orchestration SDK? Check out [CMDOP](https://cmdop.com) — a platform for building and managing AI agents with terminal access, file operations, browser automation, and more.

```bash
pip install cmdop
```

## Quick Start

```python
from cmdop import CMDOPClient

# Connect to a local agent
client = CMDOPClient.local()

# Or connect remotely
client = CMDOPClient.remote(api_key="cmdop_your_key")
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/cmdop/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk)
- [PyPI — cmdop](https://pypi.org/project/cmdop/)
