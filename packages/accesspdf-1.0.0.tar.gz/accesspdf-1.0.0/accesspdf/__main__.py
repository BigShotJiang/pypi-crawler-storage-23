"""Allow running as ``python -m accesspdf``."""

from accesspdf.cli import app

app()
