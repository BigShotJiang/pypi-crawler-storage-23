"""BytePlus Images API provider package."""
