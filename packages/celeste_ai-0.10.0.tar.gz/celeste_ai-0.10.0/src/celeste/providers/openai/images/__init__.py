"""OpenAI Images API provider package."""
