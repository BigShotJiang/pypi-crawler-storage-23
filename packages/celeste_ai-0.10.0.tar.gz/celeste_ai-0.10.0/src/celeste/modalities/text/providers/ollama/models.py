"""Ollama models for text modality."""

from celeste.models import Model

MODELS: list[Model] = []
