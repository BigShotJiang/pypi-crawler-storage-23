# -*- coding: utf-8 -*-

"""SFTP-based ETL components."""

from core_ftp.etls.file_based import IBaseEtlFromFtpFile
from core_ftp.etls.file_based import SftpFileConfig


__all__ = [
    "IBaseEtlFromFtpFile",
    "SftpFileConfig",
]
