# core-ftp
===============================================================================

This project/library provides a comprehensive set of common components and 
interfaces designed to facilitate and streamline FTP connections, 
ensuring efficient communication and data transfer...

===============================================================================

.. image:: https://img.shields.io/pypi/pyversions/core-ftp.svg
    :target: https://pypi.org/project/core-ftp/
    :alt: Python Versions

.. image:: https://img.shields.io/badge/license-MIT-blue.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-ftp/-/blob/main/LICENSE
    :alt: License

.. image:: https://gitlab.com/bytecode-solutions/core/core-ftp/badges/release/pipeline.svg
    :target: https://gitlab.com/bytecode-solutions/core/core-ftp/-/pipelines
    :alt: Pipeline Status

.. image:: https://readthedocs.org/projects/core-ftp/badge/?version=latest
    :target: https://readthedocs.org/projects/core-ftp/
    :alt: Docs Status

.. image:: https://img.shields.io/badge/security-bandit-yellow.svg
    :target: https://github.com/PyCQA/bandit
    :alt: Security

|


Installation
===============================================================================

Install from PyPI using pip:

.. code-block:: bash

    pip install core-ftp
    uv pip install core-ftp  # Or using UV...


Features
===============================================================================

**SFTP Client**

* Simplified SFTP connection management with context manager support
* Multiple authentication methods:

  * Password-based authentication
  * SSH private key authentication with optional passphrase
  * Customizable transport and connection parameters

* Comprehensive file operations:

  * List files and directories with detailed attributes
  * Upload files from local filesystem or file-like objects
  * Download files to local filesystem
  * Delete files and directories
  * Change and retrieve current working directory

* Built-in error handling with custom exceptions
* Automatic resource cleanup

**ETL Support**

* Abstract base class for SFTP-based ETL tasks
* Seamless integration with core-etl framework
* File filtering capabilities:

  * Filter by file extension
  * Filter by filename prefix
  * Time-based filtering with delay options

* Optional automatic file cleanup after successful processing


Examples
===============================================================================

**Password authentication**

.. code-block:: python

    from core_ftp.clients.sftp import SftpClient, SftpConnectionConfig

    config = SftpConnectionConfig(host="test.rebex.net", port=22, user="demo", password="password")

    with SftpClient(config) as client:
        for name, attr in client.list_files("/"):
            print(name, attr)

**SSH key authentication**

.. code-block:: python

    from core_ftp.clients.sftp import SftpClient, SftpConnectionConfig

    config = SftpConnectionConfig(host="localhost", port=23, user="foo", private_key_path="/path/to/id_rsa")

    with SftpClient(config) as client:
        client.download_file("remote/file.txt", "/local/file.txt")

**Upload a file**

.. code-block:: python

    from core_ftp.clients.sftp import SftpClient, SftpConnectionConfig

    config = SftpConnectionConfig(host="localhost", user="foo", password="pass")

    with SftpClient(config) as client:
        client.chdir("/upload")
        client.upload_file("/local/report.csv", "report.csv", confirm=True)

**ETL task (file-based processing)**

.. code-block:: python

    from core_ftp.clients.sftp import SftpConnectionConfig
    from core_ftp.etls.file_based import IBaseEtlFromFtpFile, SftpFileConfig

    class DataProcessor(IBaseEtlFromFtpFile):
        @classmethod
        def registered_name(cls) -> str:
            return "DataProcessor"

        def process_file(self, path: str, **kwargs):
            print(f"Processing {path}")

    DataProcessor(
        connection=SftpConnectionConfig(host="data.server.com", user="admin", password="secret"),
        file_config=SftpFileConfig(path="/data/csv", file_ext=".csv", delete_file_on_success=True),
    ).execute()


Local SFTP server using Docker
===============================================================================

Functional tests require two local SFTP servers running via Docker
(`atmoz/sftp <https://hub.docker.com/r/atmoz/sftp/>`_): one for password
authentication (port 22) and one for SSH key authentication (port 23).

.. note::

    **Docker Desktop users (macOS / Windows / Linux):** Docker Desktop runs
    inside a VM and can only bind-mount paths that are explicitly shared with
    it. Before starting the containers, add the following paths in
    **Docker Desktop → Settings → Resources → File Sharing**, then click
    **Apply & Restart**:

    * ``<project_root>/tests/resources/upload``
    * ``<project_root>/tests/resources/ssh_keys``

    Without this step the containers will fail with
    *"bind source path does not exist"* or *"path is not shared from the host"*.

**1. Password authentication (port 22)**

.. code-block:: shell

    docker run \
      --mount type=bind,source="$(pwd)/tests/resources/upload",target=/home/foo/upload \
      -p 22:22 -d atmoz/sftp foo:pass:::upload

**2. SSH key authentication (port 23)**

.. code-block:: shell

    docker run \
      --mount type=bind,source="$(pwd)/tests/resources/ssh_keys/id_rsa.pub",target=/home/foo/.ssh/keys/id_rsa.pub,readonly \
      --mount type=bind,source="$(pwd)/tests/resources/upload",target=/home/foo/upload \
      -p 23:22 -d atmoz/sftp foo::1001

**Run functional tests**

.. code-block:: shell

    python manager.py run-tests --test-type functional --pattern "*.py"


Quick Start
===============================================================================

Installation
-------------------------------------------------------------------------------

Install the package:

.. code-block:: bash

    pip install core-ftp
    uv pip install core-ftp     # Or using UV...
    pip install -e ".[dev]"     # For development...


Setting Up Environment
-------------------------------------------------------------------------------

1. Install required libraries:

.. code-block:: bash

    pip install --upgrade pip
    pip install virtualenv

2. Create Python virtual environment:

.. code-block:: bash

    virtualenv --python=python3.12 .venv

3. Activate the virtual environment:

.. code-block:: bash

    source .venv/bin/activate

Install packages
-------------------------------------------------------------------------------

.. code-block:: bash

    pip install .
    pip install -e ".[dev]"

Check tests and coverage
-------------------------------------------------------------------------------

.. code-block:: shell

    python manager.py run-tests
    python manager.py run-coverage


Contributing
===============================================================================

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Write tests for new functionality
4. Ensure all tests pass: ``pytest -n auto``
5. Run linting: ``pylint core_ftp``
6. Run security checks: ``bandit -r core_ftp``
7. Submit a pull request


License
===============================================================================

This project is licensed under the MIT License. See the LICENSE file for details.


Links
===============================================================================

* **Documentation:** https://core-ftp.readthedocs.io/en/latest/
* **Repository:** https://gitlab.com/bytecode-solutions/core/core-ftp
* **Issues:** https://gitlab.com/bytecode-solutions/core/core-ftp/-/issues
* **Changelog:** https://gitlab.com/bytecode-solutions/core/core-ftp/-/blob/master/CHANGELOG.md
* **PyPI:** https://pypi.org/project/core-ftp/


Support
===============================================================================

For questions or support, please open an issue on GitLab or contact the maintainers.


Authors
===============================================================================

* **Alejandro Cora González** - *Initial work* - alek.cora.glez@gmail.com
