"""Generator command handlers for the Christian Who Codes CLI."""

from .random import *
