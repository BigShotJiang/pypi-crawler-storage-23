"""
TikHub 小红书 API Python SDK

两个核心接口：
1. 获取笔记信息 V2 (蒲公英商家后台)
2. 搜索笔记

Usage:
    from tikhub_xiaohongshu import TikHubClient
    
    client = TikHubClient(api_key="your_api_key")
    
    # 获取笔记信息
    note = client.get_note_info(note_id="665f95200000000006005624")
    
    # 搜索笔记
    results = client.search_notes(keyword="美食推荐", page=1)
"""

import requests
import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class TikHubResponse:
    """API 响应封装"""
    code: int
    message: str
    message_zh: str
    data: Optional[Dict[str, Any]] = None
    request_id: Optional[str] = None
    cache_url: Optional[str] = None
    
    @property
    def success(self) -> bool:
        return self.code == 200
    
    def get_notes(self) -> List[Dict[str, Any]]:
        """
        获取搜索笔记列表（适用于 search_notes 接口）
        
        API 返回结构：
        {
            "code": 200,
            "data": {
                "code": 0,
                "success": true,
                "data": {
                    "items": [
                        {
                            "model_type": "note",
                            "note": {...}  # 实际笔记数据在这里
                        }
                    ]
                }
            }
        }
        
        Returns:
            笔记列表（提取 note 字段）
        """
        if not self.data or not isinstance(self.data, dict):
            return []
        
        inner_data = self.data.get("data", {})
        if not isinstance(inner_data, dict):
            return []
        
        items = inner_data.get("items", [])
        if not isinstance(items, list):
            return []
        
        # 提取 items 中的 note 字段
        notes = []
        for item in items:
            if isinstance(item, dict):
                # 检查是否有 note 包装层
                if "note" in item and isinstance(item["note"], dict):
                    # 有 note 包装，提取出来
                    note_data = item["note"].copy()
                    # 保留 model_type（如果需要）
                    if "model_type" in item:
                        note_data["model_type"] = item["model_type"]
                    notes.append(note_data)
                else:
                    # 没有 note 包装，直接使用
                    notes.append(item)
        
        return notes
    
    def get_search_params(self) -> Dict[str, Any]:
        """
        获取搜索参数（search_id, search_session_id, has_more）
        
        Returns:
            包含翻页参数的字典
        """
        if not self.data or not isinstance(self.data, dict):
            return {}
        
        inner_data = self.data.get("data", {})
        if isinstance(inner_data, dict):
            return {
                "search_id": inner_data.get("search_id"),
                "search_session_id": inner_data.get("search_session_id"),
                "has_more": inner_data.get("has_more", False)
            }
        
        return {}


class TikHubClient:
    """TikHub 小红书 API 客户端"""
    
    # 主 API 地址（优先使用）
    BASE_URL = "https://api.tikhub.dev/api/v1"
    
    # 备用 API 地址（兜底）
    FALLBACK_BASE_URL = "https://api.tikhub.io/api/v1"
    
    def __init__(self, api_key: str):
        """
        初始化客户端
        
        Args:
            api_key: TikHub API Key
        """
        self.api_key = api_key
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        })
    
    def _request(self, method: str, endpoint: str, params: Optional[Dict] = None) -> TikHubResponse:
        """发送 HTTP 请求（使用默认 BASE_URL）"""
        return self._request_with_base_url(method, endpoint, params, self.BASE_URL)
    
    def _request_with_base_url(self, method: str, endpoint: str, params: Optional[Dict] = None, base_url: Optional[str] = None) -> TikHubResponse:
        """发送 HTTP 请求（可指定 base_url）"""
        url = f"{base_url or self.BASE_URL}{endpoint}"
        
        response = self.session.request(method, url, params=params)
        response.raise_for_status()
        
        result = response.json()
        return TikHubResponse(
            code=result.get("code", 0),
            message=result.get("message", ""),
            message_zh=result.get("message_zh", ""),
            data=result.get("data"),
            request_id=result.get("request_id"),
            cache_url=result.get("cache_url")
        )
    
    def get_note_info(
        self,
        note_id: Optional[str] = None,
        share_text: Optional[str] = None
    ) -> TikHubResponse:
        """
        获取笔记详情（带兜底机制）
        
        兜底顺序：
        1. api.tikhub.dev/api/v1/xiaohongshu/app_v2/get_image_note_detail (新接口)
        2. api.tikhub.io/api/v1/xiaohongshu/app/get_note_info_v2 (备用)
        3. api.tikhub.io/api/v1/xiaohongshu/app/get_note_info (旧接口)
        
        Args:
            note_id: 笔记 ID（从分享链接获取）
            share_text: 小红书分享链接（支持 APP 和 Web 端）
        
        Returns:
            TikHubResponse: 笔记详情数据
        
        Example:
            >>> client.get_note_info(note_id="665f95200000000006005624")
            >>> client.get_note_info(share_text="https://www.xiaohongshu.com/explore/xxx")
        
        Note:
            note_id 和 share_text 二选一，如都提供则以 note_id 为准
        """
        if not note_id and not share_text:
            raise ValueError("note_id 或 share_text 必须提供一个")
        
        # 兜底接口列表
        endpoints = [
            # 1. 新接口（优先）
            {
                "base_url": self.BASE_URL,
                "endpoint": "/xiaohongshu/app_v2/get_image_note_detail",
                "params": {"note_id": note_id, "share_text": share_text}
            },
            # 2. V2 接口（备用）
            {
                "base_url": self.FALLBACK_BASE_URL,
                "endpoint": "/xiaohongshu/app/get_note_info_v2",
                "params": {"note_id": note_id, "share_text": share_text}
            },
            # 3. 旧接口（兜底）
            {
                "base_url": self.FALLBACK_BASE_URL,
                "endpoint": "/xiaohongshu/app/get_note_info",
                "params": {"note_id": note_id, "share_text": share_text}
            }
        ]
        
        # 依次尝试
        for i, config in enumerate(endpoints, 1):
            try:
                logger.info(f"尝试接口 {i}/3: {config['base_url']}{config['endpoint']}")
                
                # 过滤空参数
                params = {k: v for k, v in config['params'].items() if v}
                
                result = self._request_with_base_url(
                    "GET",
                    config['endpoint'],
                    params=params,
                    base_url=config['base_url']
                )
                
                # 如果成功，返回结果
                if result.success:
                    logger.info(f"接口 {i} 调用成功")
                    return result
                else:
                    logger.warning(f"接口 {i} 返回失败：{result.message_zh}")
                    
            except Exception as e:
                logger.warning(f"接口 {i} 调用异常：{e}")
                # 继续尝试下一个接口
                continue
        
        # 所有接口都失败，返回错误响应
        logger.error("所有接口调用失败")
        return TikHubResponse(
            code=500,
            message="All endpoints failed",
            message_zh="所有接口调用失败，请检查 API Key 余额或网络"
        )
    
    def search_notes(
        self,
        keyword: str,
        page: int = 1,
        sort_type: str = "general",
        note_type: str = "不限",
        time_filter: str = "不限",
        search_id: Optional[str] = None,
        search_session_id: Optional[str] = None,
        ai_mode: int = 0
    ) -> TikHubResponse:
        """
        搜索笔记
        
        Args:
            keyword: 搜索关键词（必需），如 "美食推荐"
            page: 页码，从 1 开始，默认 1
            sort_type: 排序方式
                - "general": 综合排序（默认）
                - "time_descending": 按时间倒序（最新）
                - "popularity_descending": 按点赞数排序
                - "comment_descending": 按评论数排序
                - "collect_descending": 按收藏数排序
                - "english_preferred": 英文优先
            note_type: 笔记类型筛选
                - "不限": 所有类型（默认）
                - "视频笔记": 仅视频
                - "普通笔记": 仅图文
                - "直播笔记": 仅直播
            time_filter: 发布时间筛选
                - "不限": 所有时间（默认）
                - "一天内": 24 小时内
                - "一周内": 7 天内
                - "半年内": 6 个月内
            search_id: 搜索 ID（翻页时使用，首次请求不需要）
            search_session_id: 搜索会话 ID（翻页时使用，首次请求不需要）
            ai_mode: AI 模式，0=关闭（默认），1=开启
        
        Returns:
            TikHubResponse: 搜索结果数据，包含笔记列表和分页信息
        
        Example:
            >>> # 首次搜索
            >>> result = client.search_notes(keyword="美食推荐", page=1)
            >>> notes = result.data["notes"]
            
            >>> # 翻页（使用首次返回的 search_id 和 search_session_id）
            >>> result2 = client.search_notes(
            ...     keyword="美食推荐",
            ...     page=2,
            ...     search_id=result.data["search_id"],
            ...     search_session_id=result.data["search_session_id"]
            ... )
        
        Note:
            翻页时必须传入首次搜索返回的 search_id 和 search_session_id
        """
        params = {
            "keyword": keyword,
            "page": page,
            "sort_type": sort_type,
            "note_type": note_type,
            "time_filter": time_filter,
            "ai_mode": ai_mode
        }
        
        if search_id:
            params["search_id"] = search_id
        if search_session_id:
            params["search_session_id"] = search_session_id
        
        return self._request("GET", "/xiaohongshu/app_v2/search_notes", params)
    
    def search_notes_all(
        self,
        keyword: str,
        max_pages: int = 10,
        fetch_details: bool = False,
        detail_limit: int = 0,
        **search_kwargs
    ) -> Dict[str, Any]:
        """
        搜索笔记（自动翻页，获取全部结果）
        
        Args:
            keyword: 搜索关键词
            max_pages: 最大页数，默认 10
            fetch_details: 是否获取笔记详情，默认 False
            detail_limit: 获取详情的数量限制，0=不限制，默认 0
            **search_kwargs: 其他搜索参数（sort_type, note_type 等）
        
        Returns:
            Dict: {
                "notes": List[Dict] - 笔记列表，
                "details": List[Dict] - 详情列表（如果 fetch_details=True）
            }
        
        Example:
            >>> # 只搜索
            >>> result = client.search_notes_all("美食推荐", max_pages=5)
            >>> print(f"共获取 {len(result['notes'])} 篇笔记")
            
            >>> # 搜索 + 获取前 3 条详情
            >>> result = client.search_notes_all("美食推荐", fetch_details=True, detail_limit=3)
            >>> print(f"获取 {len(result['details'])} 条详情")
        """
        all_notes = []
        details = []
        search_id = None
        search_session_id = None
        
        for page in range(1, max_pages + 1):
            result = self.search_notes(
                keyword=keyword,
                page=page,
                search_id=search_id,
                search_session_id=search_session_id,
                **search_kwargs
            )
            
            if not result.success or not result.data:
                break
            
            # API 返回结构：result.data.data.items
            inner_data = result.data.get("data", {}) if isinstance(result.data, dict) else {}
            notes = inner_data.get("items", []) if isinstance(inner_data, dict) else []
            all_notes.extend(notes)
            
            # 获取笔记详情（如果启用）
            if fetch_details and notes:
                for note in notes:
                    # 检查是否已达到详情数量限制
                    if detail_limit > 0 and len(details) >= detail_limit:
                        break
                    
                    # 提取 note_id（注意：note.note.id）
                    note_id = note.get("note", {}).get("id") or note.get("id")
                    if note_id:
                        try:
                            detail_result = self.get_note_info(note_id=note_id)
                            if detail_result.success and detail_result.data:
                                # 提取真正的详情数据
                                # 结构：data.data[0].note_list[0]
                                detail_list = detail_result.data.get("data", [])
                                if detail_list and isinstance(detail_list, list) and len(detail_list) > 0:
                                    first_item = detail_list[0]
                                    note_list = first_item.get("note_list", [])
                                    if note_list and isinstance(note_list, list) and len(note_list) > 0:
                                        # 取第一篇笔记的详情
                                        detail_data = note_list[0]
                                        # 合并用户信息
                                        user_info = first_item.get("user", {})
                                        if user_info:
                                            detail_data["user"] = user_info
                                        details.append(detail_data)
                        except Exception as e:
                            logger.warning(f"获取笔记 {note_id} 详情失败：{e}")
                    
                    # 再次检查是否达到限制
                    if detail_limit > 0 and len(details) >= detail_limit:
                        break
            
            # 如果已达到详情限制，停止翻页
            if detail_limit > 0 and len(details) >= detail_limit:
                break
            
            # 更新翻页参数（从内层 data 获取）
            if isinstance(inner_data, dict):
                search_id = inner_data.get("search_id")
                search_session_id = inner_data.get("search_session_id")
                
                # 没有更多数据时停止
                if not inner_data.get("has_more"):
                    break
        
        return {
            "notes": all_notes,
            "details": details
        }


# 快捷使用示例
if __name__ == "__main__":
    import os
    
    # 从环境变量获取 API Key
    api_key = os.getenv("TIKHUB_API_KEY", "your_api_key_here")
    client = TikHubClient(api_key)
    
    # 示例 1: 获取笔记信息
    # note = client.get_note_info(note_id="665f95200000000006005624")
    # if note.success:
    #     print(f"标题：{note.data['title']}")
    #     print(f"点赞：{note.data['interact_info']['liked_count']}")
    
    # 示例 2: 搜索笔记
    # result = client.search_notes(keyword="美食推荐", page=1)
    # if result.success:
    #     for note in result.data["notes"]:
    #         print(f"- {note['title']}")
    
    # 示例 3: 搜索并自动翻页
    # notes = client.search_notes_all("美食推荐", max_pages=5)
    # print(f"共获取 {len(notes)} 篇笔记")
