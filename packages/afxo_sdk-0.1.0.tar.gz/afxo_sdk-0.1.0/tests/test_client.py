# SPDX-License-Identifier: UNLICENSED
"""
Copyright (c) 2025 Digitalyze Labs Ltd. All rights reserved.

This software is proprietary and confidential to Digitalyze Labs Ltd.
Unauthorized copying, modification, distribution, or use of this
software, in whole or in part, is strictly prohibited except as
expressly authorized in writing by Digitalyze Labs Ltd.

Use of this software is subject to the terms of a separate license
or commercial agreement with Digitalyze Labs Ltd. This software is
provided "as is" and without warranties of any kind, express or
implied, including without limitation any warranties of merchantability,
fitness for a particular purpose, or non-infringement.
"""

"""
Unit tests for the afxo-sdk Python client.
Uses respx to mock httpx HTTP requests.
"""

import pytest
import httpx
import respx

from afxo import AFXOClient, AFXOError, AFXOAuthError, AFXORateLimitError


BASE_URL = "https://api.afxo.ai/v1"


@pytest.fixture
def client():
    """Create a test client."""
    return AFXOClient(api_key="test-key-123", base_url=BASE_URL)


# ================================================================
# Construction
# ================================================================


class TestConstruction:
    def test_creates_client(self):
        c = AFXOClient(api_key="key")
        assert c is not None
        c.close()

    def test_context_manager(self):
        with AFXOClient(api_key="key") as c:
            assert c is not None


# ================================================================
# FX Oracle - Rates
# ================================================================


class TestRates:
    @respx.mock
    def test_get_rate(self, client):
        respx.get(f"{BASE_URL}/rates/KES/USD").mock(
            return_value=httpx.Response(200, json={
                "quoteCurrency": "KES",
                "baseCurrency": "USD",
                "rate": 129.87,
                "confidence": 94,
                "timestamp": "2026-03-03T12:00:00Z",
                "sources": [
                    {"sourceId": "fastforex", "rate": 129.85, "weight": 0.25, "included": True}
                ],
                "metadata": {},
            })
        )

        rate = client.get_rate("KES", "USD")
        assert rate.rate == 129.87
        assert rate.confidence == 94
        assert rate.quote_currency == "KES"
        assert len(rate.sources) == 1
        assert rate.sources[0].source_id == "fastforex"

    @respx.mock
    def test_get_rates_batch(self, client):
        respx.get(f"{BASE_URL}/rates/batch").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "rates": [
                        {"pair": "KES/USD", "rate": 129.87, "confidence": 94, "sources": 6, "timestamp": "2026-03-03T12:00:00Z"},
                        {"pair": "NGN/USD", "rate": 1580.50, "confidence": 91, "sources": 5, "timestamp": "2026-03-03T12:00:00Z"},
                    ],
                    "requestedAt": "2026-03-03T12:00:01Z",
                },
            })
        )

        batch = client.get_rates_batch(["KES/USD", "NGN/USD"])
        assert batch.success is True
        assert len(batch.rates) == 2
        assert batch.rates[0].pair == "KES/USD"
        assert batch.rates[1].rate == 1580.50

    @respx.mock
    def test_get_history(self, client):
        respx.get(f"{BASE_URL}/rates/KES/USD/history").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "pair": "KES/USD",
                    "period": "7d",
                    "interval": "daily",
                    "count": 7,
                    "rates": [
                        {"time": "2026-02-25", "open": 129.68, "high": 130.12, "low": 129.45, "close": 129.87, "avgConfidence": 92, "dataPoints": 288}
                    ],
                },
            })
        )

        history = client.get_history("KES", "USD", period="7d", interval="daily")
        assert history.success is True
        assert history.period == "7d"
        assert history.interval == "daily"
        assert history.count == 7

    @respx.mock
    def test_get_currencies(self, client):
        respx.get(f"{BASE_URL}/currencies").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "baseCurrency": "USD",
                    "currencies": ["KES", "NGN", "GHS"],
                    "pairs": ["USD/KES", "USD/NGN", "USD/GHS"],
                    "count": 3,
                },
            })
        )

        result = client.get_currencies()
        assert result.count == 3
        assert "KES" in result.currencies

    @respx.mock
    def test_get_status(self, client):
        respx.get(f"{BASE_URL}/status").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "data": {
                    "status": "operational",
                    "timestamp": "2026-03-03T12:00:00Z",
                    "services": {"aggregator": "operational"},
                },
            })
        )

        result = client.get_status()
        assert result.status == "operational"


# ================================================================
# Economic Intelligence
# ================================================================


class TestIntelligence:
    @respx.mock
    def test_get_intelligence(self, client):
        respx.get(f"{BASE_URL}/intelligence/KES").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "currency": "KES",
                "timestamp": "2026-03-03T12:00:00Z",
                "data": {"interestRate": {"policyRate": 12.0}},
            })
        )

        result = client.get_intelligence("KES")
        assert result.currency == "KES"
        assert result.success is True

    @respx.mock
    def test_get_quant_dashboard(self, client):
        respx.get(f"{BASE_URL}/quant/dashboard").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "timestamp": "2026-03-03T12:00:00Z",
                "marketRegime": "RISK_ON",
            })
        )

        result = client.get_quant_dashboard()
        assert result["marketRegime"] == "RISK_ON"

    @respx.mock
    def test_get_irp(self, client):
        respx.get(f"{BASE_URL}/quant/irp/KES").mock(
            return_value=httpx.Response(200, json={
                "success": True,
                "currency": "KES",
                "rateDifferential": 7.5,
            })
        )

        result = client.get_irp("KES")
        assert result["rateDifferential"] == 7.5


# ================================================================
# TrueRandom
# ================================================================


class TestTrueRandom:
    @respx.mock
    def test_get_latest_beacon(self, client):
        respx.get(f"{BASE_URL}/truerandom/beacon/latest").mock(
            return_value=httpx.Response(200, json={
                "data": {
                    "round": 327,
                    "randomness": "0xabc123",
                    "timestamp": "2026-03-03T12:00:00Z",
                    "beaconId": "0xdef456",
                },
            })
        )

        beacon = client.get_latest_beacon()
        assert beacon.round == 327
        assert beacon.randomness == "0xabc123"

    @respx.mock
    def test_get_beacon_by_round(self, client):
        respx.get(f"{BASE_URL}/truerandom/beacon/100").mock(
            return_value=httpx.Response(200, json={
                "data": {
                    "round": 100,
                    "randomness": "0x789abc",
                    "timestamp": "2026-03-03T10:00:00Z",
                    "beaconId": "0x123def",
                },
            })
        )

        beacon = client.get_beacon(100)
        assert beacon.round == 100

    @respx.mock
    def test_get_truerandom_status(self, client):
        respx.get(f"{BASE_URL}/truerandom/status").mock(
            return_value=httpx.Response(200, json={
                "data": {
                    "status": "healthy",
                    "round": 327,
                    "committee": {"total": 1, "active": 1},
                    "uptime": 99.2,
                },
            })
        )

        status = client.get_truerandom_status()
        assert status.status == "healthy"
        assert status.round == 327


# ================================================================
# Error Handling
# ================================================================


class TestErrors:
    @respx.mock
    def test_401_raises_auth_error(self, client):
        respx.get(f"{BASE_URL}/rates/KES/USD").mock(
            return_value=httpx.Response(401, json={"error": "Unauthorized"})
        )

        with pytest.raises(AFXOAuthError):
            client.get_rate("KES", "USD")

    @respx.mock
    def test_429_raises_rate_limit_error(self, client):
        respx.get(f"{BASE_URL}/rates/KES/USD").mock(
            return_value=httpx.Response(429, json={"error": "Rate limit exceeded"}, headers={"Retry-After": "60"})
        )

        with pytest.raises(AFXORateLimitError) as exc_info:
            client.get_rate("KES", "USD")
        assert exc_info.value.retry_after == 60

    @respx.mock
    def test_500_raises_afxo_error(self, client):
        respx.get(f"{BASE_URL}/rates/KES/USD").mock(
            return_value=httpx.Response(500, json={"error": "Internal server error"})
        )

        with pytest.raises(AFXOError) as exc_info:
            client.get_rate("KES", "USD")
        assert exc_info.value.status_code == 500

    @respx.mock
    def test_404_raises_afxo_error(self, client):
        respx.get(f"{BASE_URL}/rates/XYZ/USD").mock(
            return_value=httpx.Response(404, json={"error": "Not found"})
        )

        with pytest.raises(AFXOError) as exc_info:
            client.get_rate("XYZ", "USD")
        assert exc_info.value.status_code == 404
