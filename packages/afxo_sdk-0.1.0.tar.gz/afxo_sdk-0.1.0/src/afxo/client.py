# SPDX-License-Identifier: UNLICENSED
"""
Copyright (c) 2025 Digitalyze Labs Ltd. All rights reserved.

This software is proprietary and confidential to Digitalyze Labs Ltd.
Unauthorized copying, modification, distribution, or use of this
software, in whole or in part, is strictly prohibited except as
expressly authorized in writing by Digitalyze Labs Ltd.

Use of this software is subject to the terms of a separate license
or commercial agreement with Digitalyze Labs Ltd. This software is
provided "as is" and without warranties of any kind, express or
implied, including without limitation any warranties of merchantability,
fitness for a particular purpose, or non-infringement.
"""

from __future__ import annotations

from typing import Any, Literal

import httpx

from afxo.exceptions import AFXOError, AFXORateLimitError, AFXOAuthError
from afxo.types import (
    RateResponse,
    RateSource,
    BatchRateResponse,
    BatchRateItem,
    HistoryResponse,
    SignedFeedResponse,
    CurrenciesResponse,
    StatusResponse,
    IntelligenceResponse,
    InterestRatesResponse,
    BeaconResponse,
    TrueRandomStatus,
    QuantDashboard,
)

DEFAULT_BASE_URL = "https://api.afxo.ai/v1"
DEFAULT_TIMEOUT = 10.0


class AFXOClient:
    """Official AFXO API client.

    Usage::

        from afxo import AFXOClient

        client = AFXOClient(api_key="your-key")
        rate = client.get_rate("KES", "USD")
        print(rate.rate, rate.confidence)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={
                "X-API-Key": api_key,
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> AFXOClient:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ================================================================
    # Internal
    # ================================================================

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        response = self._client.request(method, path, **kwargs)

        if response.status_code == 401:
            raise AFXOAuthError()
        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", "60"))
            raise AFXORateLimitError("Rate limit exceeded", retry_after)
        if response.status_code >= 400:
            try:
                body = response.json()
                msg = body.get("error", body.get("message", f"HTTP {response.status_code}"))
            except Exception:
                msg = f"HTTP {response.status_code}"
            raise AFXOError(msg, response.status_code)

        return response.json()

    def _get(self, path: str, **kwargs: Any) -> dict[str, Any]:
        return self._request("GET", path, **kwargs)

    # ================================================================
    # FX Oracle — Rates
    # ================================================================

    def get_rate(self, currency: str, base_currency: str) -> RateResponse:
        """Get current exchange rate for a currency pair."""
        data = self._get(f"/rates/{currency}/{base_currency}")
        sources = [
            RateSource(
                source_id=s.get("sourceId", ""),
                rate=s.get("rate", 0),
                weight=s.get("weight", 0),
                included=s.get("included", False),
            )
            for s in data.get("sources", [])
        ]
        return RateResponse(
            quote_currency=data.get("quoteCurrency", currency),
            base_currency=data.get("baseCurrency", base_currency),
            rate=data.get("rate", 0),
            confidence=data.get("confidence", 0),
            timestamp=data.get("timestamp", ""),
            sources=sources,
            metadata=data.get("metadata", {}),
        )

    def get_rates_batch(self, pairs: list[str]) -> BatchRateResponse:
        """Get rates for multiple currency pairs."""
        data = self._get("/rates/batch", params={"pairs": ",".join(pairs)})
        inner = data.get("data", data)
        items = [
            BatchRateItem(
                pair=r["pair"],
                rate=r["rate"],
                confidence=r["confidence"],
                sources=r["sources"],
                timestamp=r["timestamp"],
            )
            for r in inner.get("rates", [])
        ]
        return BatchRateResponse(
            success=data.get("success", True),
            rates=items,
            errors=inner.get("errors"),
            requested_at=inner.get("requestedAt", ""),
        )

    def get_history(
        self,
        currency: str,
        base_currency: str,
        period: Literal["1h", "6h", "12h", "24h", "7d", "30d", "90d", "365d"] = "24h",
        interval: Literal["raw", "hourly", "daily"] = "raw",
    ) -> HistoryResponse:
        """Get historical rates for a currency pair."""
        data = self._get(
            f"/rates/{currency}/{base_currency}/history",
            params={"period": period, "interval": interval},
        )
        inner = data.get("data", data)
        return HistoryResponse(
            success=data.get("success", True),
            pair=inner.get("pair", f"{currency}/{base_currency}"),
            period=inner.get("period", period),
            interval=inner.get("interval", interval),
            count=inner.get("count", 0),
            rates=inner.get("rates", []),
        )

    def get_signed_rate(
        self,
        base_currency: str,
        quote_currency: str,
        chain_id: int | None = None,
        validity: int | None = None,
    ) -> SignedFeedResponse:
        """Get EIP-712 signed rate (v2 format)."""
        params: dict[str, Any] = {}
        if chain_id is not None:
            params["chainId"] = chain_id
        if validity is not None:
            params["validity"] = validity

        data = self._get(
            f"/signed/{base_currency}/{quote_currency}/signed",
            params=params or None,
        )
        return SignedFeedResponse(
            success=data.get("success", True),
            version=data.get("version", ""),
            feed=data.get("feed", {}),
            signature=data.get("signature", ""),
            signer=data.get("signer", ""),
            domain=data.get("domain", {}),
            metadata=data.get("metadata", {}),
        )

    def get_currencies(self) -> CurrenciesResponse:
        """Get list of supported currencies."""
        data = self._get("/currencies")
        inner = data.get("data", data)
        return CurrenciesResponse(
            success=data.get("success", True),
            base_currency=inner.get("baseCurrency", "USD"),
            currencies=inner.get("currencies", []),
            pairs=inner.get("pairs", []),
            count=inner.get("count", 0),
        )

    def get_status(self) -> StatusResponse:
        """Get system status."""
        data = self._get("/status")
        inner = data.get("data", data)
        return StatusResponse(
            success=data.get("success", True),
            status=inner.get("status", ""),
            timestamp=inner.get("timestamp", ""),
            services=inner.get("services", {}),
        )

    # ================================================================
    # Economic Intelligence
    # ================================================================

    def get_intelligence(self, currency: str) -> IntelligenceResponse:
        """Get full economic intelligence for a currency."""
        data = self._get(f"/intelligence/{currency}")
        return IntelligenceResponse(
            success=data.get("success", True),
            currency=data.get("currency", currency),
            timestamp=data.get("timestamp", ""),
            data=data.get("data", data),
        )

    def get_interest_rates(self, currency: str | None = None) -> InterestRatesResponse:
        """Get interest rates for a currency or all currencies."""
        path = f"/rates/interest/{currency}" if currency else "/rates/interest"
        data = self._get(path)
        return InterestRatesResponse(
            success=data.get("success", True),
            rates=data.get("rates", []),
        )

    def get_irp(self, currency: str | None = None) -> dict[str, Any]:
        """Get Interest Rate Parity analysis."""
        path = f"/quant/irp/{currency}" if currency else "/quant/irp"
        return self._get(path)

    def get_carry_vol(self, currency: str | None = None) -> dict[str, Any]:
        """Get carry-to-volatility ratios."""
        path = f"/quant/carry-vol/{currency}" if currency else "/quant/carry-vol"
        return self._get(path)

    def get_zscore(self, currency: str | None = None) -> dict[str, Any]:
        """Get Z-score deviation analysis."""
        path = f"/quant/zscore/{currency}" if currency else "/quant/zscore"
        return self._get(path)

    def get_risk_parity(self) -> dict[str, Any]:
        """Get risk parity portfolio weights."""
        return self._get("/quant/risk-parity")

    def get_cross_currency(self, currency1: str, currency2: str) -> dict[str, Any]:
        """Get cross-currency spread analysis."""
        return self._get(f"/quant/cross-currency/{currency1}/{currency2}")

    def get_quant_dashboard(self) -> dict[str, Any]:
        """Get quantitative dashboard."""
        return self._get("/quant/dashboard")

    # ================================================================
    # TrueRandom
    # ================================================================

    def get_latest_beacon(self) -> BeaconResponse:
        """Get the latest TrueRandom beacon."""
        data = self._get("/truerandom/beacon/latest")
        inner = data.get("data", data)
        return BeaconResponse(
            round=inner.get("round", 0),
            randomness=inner.get("randomness", ""),
            timestamp=inner.get("timestamp", ""),
            beacon_id=inner.get("beaconId", ""),
        )

    def get_beacon(self, round_number: int) -> BeaconResponse:
        """Get a TrueRandom beacon by round number."""
        data = self._get(f"/truerandom/beacon/{round_number}")
        inner = data.get("data", data)
        return BeaconResponse(
            round=inner.get("round", round_number),
            randomness=inner.get("randomness", ""),
            timestamp=inner.get("timestamp", ""),
            beacon_id=inner.get("beaconId", ""),
        )

    def get_truerandom_status(self) -> TrueRandomStatus:
        """Get TrueRandom system status."""
        data = self._get("/truerandom/status")
        inner = data.get("data", data)
        return TrueRandomStatus(
            status=inner.get("status", ""),
            round=inner.get("round", 0),
            committee=inner.get("committee", {}),
            uptime=inner.get("uptime", 0),
        )
