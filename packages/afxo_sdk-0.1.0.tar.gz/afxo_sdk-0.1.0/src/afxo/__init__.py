# SPDX-License-Identifier: UNLICENSED
"""
Copyright (c) 2025 Digitalyze Labs Ltd. All rights reserved.

This software is proprietary and confidential to Digitalyze Labs Ltd.
Unauthorized copying, modification, distribution, or use of this
software, in whole or in part, is strictly prohibited except as
expressly authorized in writing by Digitalyze Labs Ltd.

Use of this software is subject to the terms of a separate license
or commercial agreement with Digitalyze Labs Ltd. This software is
provided "as is" and without warranties of any kind, express or
implied, including without limitation any warranties of merchantability,
fitness for a particular purpose, or non-infringement.
"""

from afxo.client import AFXOClient
from afxo.types import (
    RateResponse,
    BatchRateResponse,
    HistoryResponse,
    SignedFeedResponse,
    CurrenciesResponse,
    StatusResponse,
    IntelligenceResponse,
    InterestRatesResponse,
    BeaconResponse,
    TrueRandomStatus,
    QuantDashboard,
)
from afxo.exceptions import AFXOError, AFXORateLimitError, AFXOAuthError

__all__ = [
    "AFXOClient",
    "RateResponse",
    "BatchRateResponse",
    "HistoryResponse",
    "SignedFeedResponse",
    "CurrenciesResponse",
    "StatusResponse",
    "IntelligenceResponse",
    "InterestRatesResponse",
    "BeaconResponse",
    "TrueRandomStatus",
    "QuantDashboard",
    "AFXOError",
    "AFXORateLimitError",
    "AFXOAuthError",
]

__version__ = "0.1.0"
