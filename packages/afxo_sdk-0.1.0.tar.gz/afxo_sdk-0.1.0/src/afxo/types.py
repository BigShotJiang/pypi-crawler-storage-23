# SPDX-License-Identifier: UNLICENSED
"""
Copyright (c) 2025 Digitalyze Labs Ltd. All rights reserved.

This software is proprietary and confidential to Digitalyze Labs Ltd.
Unauthorized copying, modification, distribution, or use of this
software, in whole or in part, is strictly prohibited except as
expressly authorized in writing by Digitalyze Labs Ltd.

Use of this software is subject to the terms of a separate license
or commercial agreement with Digitalyze Labs Ltd. This software is
provided "as is" and without warranties of any kind, express or
implied, including without limitation any warranties of merchantability,
fitness for a particular purpose, or non-infringement.
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class RateSource:
    source_id: str
    rate: float
    weight: float
    included: bool


@dataclass
class RateResponse:
    quote_currency: str
    base_currency: str
    rate: float
    confidence: float
    timestamp: str
    sources: list[RateSource] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class BatchRateItem:
    pair: str
    rate: float
    confidence: float
    sources: int
    timestamp: str


@dataclass
class BatchRateResponse:
    success: bool
    rates: list[BatchRateItem] = field(default_factory=list)
    errors: list[dict[str, str]] | None = None
    requested_at: str = ""


@dataclass
class HistoryDataPoint:
    time: str
    rate: float
    confidence: float = 0.0


@dataclass
class HistoryResponse:
    success: bool
    pair: str
    period: str
    interval: str
    count: int
    rates: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class SignedFeedResponse:
    success: bool
    version: str = ""
    feed: dict[str, Any] = field(default_factory=dict)
    signature: str = ""
    signer: str = ""
    domain: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CurrenciesResponse:
    success: bool
    base_currency: str = ""
    currencies: list[str] = field(default_factory=list)
    pairs: list[str] = field(default_factory=list)
    count: int = 0


@dataclass
class StatusResponse:
    success: bool
    status: str = ""
    timestamp: str = ""
    services: dict[str, str] = field(default_factory=dict)


@dataclass
class IntelligenceResponse:
    success: bool
    currency: str = ""
    timestamp: str = ""
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class InterestRateData:
    currency: str
    policy_rate: float
    spread_vs_usd: float
    yield_tier: str
    real_rate: float
    inflation_rate: float
    source: str = ""
    last_updated: str = ""


@dataclass
class InterestRatesResponse:
    success: bool
    rates: list[InterestRateData] = field(default_factory=list)


@dataclass
class BeaconResponse:
    round: int
    randomness: str
    timestamp: str
    beacon_id: str = ""


@dataclass
class TrueRandomStatus:
    status: str
    round: int = 0
    committee: dict[str, int] = field(default_factory=dict)
    uptime: float = 0.0


@dataclass
class QuantDashboard:
    timestamp: str
    market_regime: str = ""
    global_carry_index: float = 0.0
    volatility_regime: str = ""
    top_carry_trades: list[dict[str, Any]] = field(default_factory=list)
    top_mean_reversion_trades: list[dict[str, Any]] = field(default_factory=list)
    risk_warnings: list[str] = field(default_factory=list)
