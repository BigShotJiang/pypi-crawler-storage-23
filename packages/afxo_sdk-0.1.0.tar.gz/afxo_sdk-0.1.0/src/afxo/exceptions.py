# SPDX-License-Identifier: UNLICENSED
"""
Copyright (c) 2025 Digitalyze Labs Ltd. All rights reserved.

This software is proprietary and confidential to Digitalyze Labs Ltd.
Unauthorized copying, modification, distribution, or use of this
software, in whole or in part, is strictly prohibited except as
expressly authorized in writing by Digitalyze Labs Ltd.

Use of this software is subject to the terms of a separate license
or commercial agreement with Digitalyze Labs Ltd. This software is
provided "as is" and without warranties of any kind, express or
implied, including without limitation any warranties of merchantability,
fitness for a particular purpose, or non-infringement.
"""


class AFXOError(Exception):
    """Base exception for AFXO API errors."""

    def __init__(self, message: str, status_code: int, code: str | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.code = code


class AFXORateLimitError(AFXOError):
    """Raised when rate limit is exceeded."""

    def __init__(self, message: str, retry_after: int):
        super().__init__(message, 429, "RATE_LIMIT_EXCEEDED")
        self.retry_after = retry_after


class AFXOAuthError(AFXOError):
    """Raised when authentication fails."""

    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, 401, "UNAUTHORIZED")
