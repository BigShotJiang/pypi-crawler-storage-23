"""
QA Tests — Issue #9: memories=N respects searchLimit in build_context_packet.

Verifies that the `search_limit` parameter passed to pre_turn() is correctly
honoured all the way through to the ContextPacket:
  - searchLimit=3 → ContextPacket.memories count ≤ 3
  - searchLimit=0 → ContextPacket.memories count = 0
  - memories=N header matches actual recalled count

Also tests the public memory_retrieval() wrapper added to AntarisPipeline.

Run with:
    cd /Users/moro/.openclaw/extensions/antaris-suite
    python3 -m pytest tests/test_search_limit.py -v
"""

import shutil
import tempfile
import unittest


class TestBuildContextPacketRespectLimit(unittest.TestCase):
    """Test ContextPacketBuilder.build() respects max_memories parameter."""

    def setUp(self):
        from antaris_memory import MemorySystem
        self.tmpdir = tempfile.mkdtemp()
        self.mem = MemorySystem(self.tmpdir)
        self.mem.load()
        # Ingest 10 relevant memories to ensure we have enough to test limits
        topics = [
            "PostgreSQL is the primary relational database",
            "Redis handles session caching at 100k req/s",
            "JWT tokens expire after 24 hours for security",
            "React frontend communicates via REST API",
            "Docker containers deployed to Kubernetes cluster",
            "CI/CD pipeline runs on GitHub Actions",
            "Prometheus monitors system metrics",
            "Grafana dashboards visualize performance data",
            "Nginx serves static assets with 99.9% uptime",
            "Load balancer distributes traffic across 3 nodes",
        ]
        for t in topics:
            self.mem.ingest(t, source="docs", category="technical")

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_max_memories_3_respected(self):
        """build_context_packet(max_memories=3) returns ≤3 memories."""
        packet = self.mem.build_context_packet(
            task="database cache authentication frontend",
            max_memories=3,
        )
        self.assertLessEqual(
            len(packet.memories), 3,
            f"Expected ≤3 memories in packet, got {len(packet.memories)}",
        )

    def test_max_memories_0_returns_empty(self):
        """build_context_packet(max_memories=0) returns 0 memories."""
        packet = self.mem.build_context_packet(
            task="database cache authentication",
            max_memories=0,
        )
        self.assertEqual(
            len(packet.memories), 0,
            f"Expected 0 memories, got {len(packet.memories)}",
        )

    def test_max_memories_1_returns_at_most_1(self):
        """build_context_packet(max_memories=1) returns ≤1 memory."""
        packet = self.mem.build_context_packet(
            task="postgresql database",
            max_memories=1,
        )
        self.assertLessEqual(len(packet.memories), 1)

    def test_metadata_results_included_matches_actual(self):
        """metadata.results_included should match len(packet.memories)."""
        packet = self.mem.build_context_packet(
            task="kubernetes docker ci pipeline",
            max_memories=5,
        )
        self.assertEqual(
            packet.metadata.get("results_included"),
            len(packet.memories),
            "metadata.results_included should match actual memory count",
        )


class TestPipelinePublicMemoryRetrieval(unittest.TestCase):
    """Test AntarisPipeline.memory_retrieval() public wrapper (Issue #9)."""

    def setUp(self):
        """Skip if antaris-pipeline isn't installed."""
        try:
            from antaris_pipeline.pipeline import AntarisPipeline, create_pipeline
            self._create_pipeline = create_pipeline
            self._AntarisPipeline = AntarisPipeline
        except ImportError:
            self.skipTest("antaris-pipeline not installed")

        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_memory_retrieval_method_exists(self):
        """AntarisPipeline must expose a public memory_retrieval() method."""
        pipeline = self._create_pipeline(storage_path=self.tmpdir)
        self.assertTrue(
            hasattr(pipeline, "memory_retrieval"),
            "AntarisPipeline must have a public memory_retrieval() method",
        )
        self.assertTrue(callable(pipeline.memory_retrieval))

    def test_memory_retrieval_with_limit_0_returns_empty(self):
        """memory_retrieval(limit=0) returns 0 retrievals."""
        pipeline = self._create_pipeline(storage_path=self.tmpdir)
        result = pipeline.memory_retrieval("test query", None, limit=0)
        self.assertEqual(
            len(result.get("retrievals", [])), 0,
            "limit=0 should return 0 retrievals",
        )
        cp = result.get("context_packet", {})
        self.assertEqual(cp.get("memory_count", 0), 0)

    def test_memory_retrieval_with_limit_respected(self):
        """memory_retrieval(limit=3) returns ≤3 retrievals when memories exist."""
        pipeline = self._create_pipeline(storage_path=self.tmpdir)
        # Ingest some memories first
        for i in range(10):
            pipeline.memory.ingest(
                f"Test memory number {i} about databases and caching systems",
                source="test",
            )
        result = pipeline.memory_retrieval(
            "database caching systems test", None, limit=3
        )
        retrievals = result.get("retrievals", [])
        self.assertLessEqual(
            len(retrievals), 3,
            f"Expected ≤3 retrievals with limit=3, got {len(retrievals)}",
        )
        # Context packet should also respect the limit
        cp = result.get("context_packet", {})
        self.assertLessEqual(cp.get("memory_count", 0), 3)


class TestAgentPipelineSearchLimit(unittest.TestCase):
    """Test that AgentPipeline.pre_turn(search_limit=N) is honoured."""

    def setUp(self):
        """Skip if antaris-pipeline isn't installed."""
        try:
            from antaris_pipeline import AgentPipeline
            self._AgentPipeline = AgentPipeline
        except ImportError:
            self.skipTest("antaris-pipeline not installed")

        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _make_pipeline_with_memories(self, n=10):
        """Create an AgentPipeline and populate it with n test memories."""
        pipeline = self._AgentPipeline(
            storage_path=self.tmpdir,
            memory=True,
            guard=False,
            context=False,
        )
        for i in range(n):
            pipeline.pipeline.memory.ingest(
                f"Memory {i}: details about databases caching auth routing",
                source="test",
            )
        return pipeline

    def test_search_limit_0_returns_0_memories(self):
        """pre_turn(search_limit=0) should recall 0 memories."""
        agent = self._make_pipeline_with_memories(10)
        result = agent.pre_turn(
            "databases caching auth routing",
            auto_recall=True,
            search_limit=0,
        )
        self.assertEqual(
            result.memory_count, 0,
            f"search_limit=0 should recall 0 memories, got {result.memory_count}",
        )

    def test_search_limit_3_recalls_at_most_3(self):
        """pre_turn(search_limit=3) should recall ≤3 memories."""
        agent = self._make_pipeline_with_memories(10)
        result = agent.pre_turn(
            "databases caching auth routing",
            auto_recall=True,
            search_limit=3,
        )
        self.assertLessEqual(
            result.memory_count, 3,
            f"search_limit=3 should recall ≤3 memories, got {result.memory_count}",
        )

    def test_auto_recall_false_returns_0_memories(self):
        """pre_turn(auto_recall=False) should skip recall entirely."""
        agent = self._make_pipeline_with_memories(5)
        result = agent.pre_turn(
            "databases caching auth",
            auto_recall=False,
        )
        self.assertEqual(result.memory_count, 0)


class TestContextPacketHeaderMatchesCount(unittest.TestCase):
    """The memories=N header in rendered packet must match actual count."""

    def setUp(self):
        from antaris_memory import MemorySystem, ContextPacket
        self._ContextPacket = ContextPacket
        self.tmpdir = tempfile.mkdtemp()
        self.mem = MemorySystem(self.tmpdir)
        self.mem.load()
        for i in range(8):
            self.mem.ingest(
                f"Memory {i} about system architecture routing and databases",
                source="docs",
            )

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_repr_memories_count_matches_actual(self):
        """ContextPacket.__repr__ reports the correct memory count."""
        packet = self.mem.build_context_packet(
            task="system architecture routing databases",
            max_memories=4,
        )
        r = repr(packet)
        self.assertIn(f"memories={len(packet.memories)}", r,
                      f"repr should show actual count. repr={r!r}, actual={len(packet.memories)}")

    def test_metadata_results_included_matches_len(self):
        """metadata.results_included must equal len(packet.memories) always."""
        for limit in [1, 3, 5, 10]:
            with self.subTest(limit=limit):
                packet = self.mem.build_context_packet(
                    task="system architecture routing",
                    max_memories=limit,
                )
                self.assertEqual(
                    packet.metadata.get("results_included"),
                    len(packet.memories),
                    f"With limit={limit}: metadata.results_included "
                    f"({packet.metadata.get('results_included')}) != "
                    f"len(memories) ({len(packet.memories)})",
                )


if __name__ == "__main__":
    unittest.main()
