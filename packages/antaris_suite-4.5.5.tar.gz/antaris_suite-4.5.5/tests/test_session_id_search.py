"""
QA Tests — Issue #7: session_id=None returns empty results in search.py

Tests the session isolation fix in SearchEngine.search() and
MemorySystemV4.search():
  - session_id=None → deprecation warning + empty results
  - session_id="*"  → all memories returned (cross-session opt-in)
  - session_id=<str> → only memories with that session_id

Run with:
    cd /Users/moro/.openclaw/extensions/antaris-suite
    python3 -m pytest tests/test_session_id_search.py -v
"""

import logging
import shutil
import tempfile
import unittest
import warnings

from antaris_memory import MemorySystem, SearchEngine, SearchResult
from antaris_memory.entry import MemoryEntry


class TestSearchEngineSessionId(unittest.TestCase):
    """Test session_id behaviour directly in SearchEngine.search()."""

    def setUp(self):
        self.engine = SearchEngine()
        # Create entries with different session_ids
        self.mem_a = MemoryEntry("PostgreSQL is our primary database", "docs", 1, "technical")
        self.mem_a.session_id = "session-A"

        self.mem_b = MemoryEntry("Redis is used for caching", "docs", 2, "technical")
        self.mem_b.session_id = "session-B"

        self.mem_no_session = MemoryEntry("JWT tokens are used for auth", "docs", 3, "security")
        # session_id intentionally left as "" (no session assigned)

        self.memories = [self.mem_a, self.mem_b, self.mem_no_session]
        self.engine.build_index(self.memories)

    # ── session_id=None ─────────────────────────────────────────────────────

    def test_none_session_id_returns_empty(self):
        """session_id=None must return empty results (privacy isolation fix)."""
        results = self.engine.search("database cache auth", self.memories, session_id=None)
        self.assertEqual(results, [], "session_id=None should return empty results")

    def test_none_session_id_emits_warning(self):
        """session_id=None must emit a deprecation warning."""
        with self.assertLogs("antaris_memory.search", level="WARNING") as cm:
            self.engine.search("database", self.memories, session_id=None)
        self.assertTrue(
            any("deprecated" in msg.lower() for msg in cm.output),
            "Expected deprecation warning in log output",
        )

    # ── session_id="*" ──────────────────────────────────────────────────────

    def test_star_session_id_returns_all(self):
        """session_id='*' should return memories across all sessions."""
        results = self.engine.search("database cache auth", self.memories, session_id="*")
        self.assertGreater(len(results), 0, "session_id='*' should return results")

    def test_star_session_id_includes_all_sessions(self):
        """Results from session_id='*' should include entries from different sessions."""
        results = self.engine.search("postgresql redis jwt", self.memories, session_id="*")
        contents = [r.content for r in results]
        # At least one result should be returned
        self.assertGreater(len(results), 0)

    # ── session_id=<specific string> ────────────────────────────────────────

    def test_specific_session_filters_to_that_session(self):
        """session_id='session-A' should only return memories from that session."""
        results = self.engine.search("postgresql redis jwt database cache auth",
                                     self.memories, session_id="session-A")
        for r in results:
            self.assertEqual(
                getattr(r.entry, "session_id", ""),
                "session-A",
                f"Result should only contain session-A entries, got: {r.entry.session_id!r}",
            )

    def test_specific_session_excludes_other_sessions(self):
        """Memories from session-B should not appear in session-A search."""
        results = self.engine.search("redis caching", self.memories, session_id="session-A")
        # Redis memory belongs to session-B, so session-A search should not return it
        contents = [r.content.lower() for r in results]
        self.assertFalse(
            any("redis" in c for c in contents),
            "session-B memory (Redis) should not appear in session-A results",
        )

    def test_unknown_session_returns_empty(self):
        """A session_id with no matching entries should return empty."""
        results = self.engine.search("anything", self.memories, session_id="session-X")
        self.assertEqual(results, [])


class TestMemorySystemSessionId(unittest.TestCase):
    """Test session_id behaviour via the MemorySystem API (MemorySystemV4)."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.mem = MemorySystem(self.tmpdir)
        self.mem.load()

        # Ingest memories and manually assign session_ids
        self.mem.ingest("PostgreSQL migration completed", source="log", category="technical")
        self.mem.memories[-1].session_id = "session-A"

        self.mem.ingest("Redis cluster deployed", source="log", category="technical")
        self.mem.memories[-1].session_id = "session-B"

        self.mem.ingest("Auth tokens rotated", source="log", category="security")
        self.mem.memories[-1].session_id = "session-A"

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_star_session_returns_all_memories(self):
        """session_id='*' returns memories from all sessions."""
        results = self.mem.search("postgresql redis auth", session_id="*")
        self.assertGreater(len(results), 0)

    def test_session_a_excludes_session_b(self):
        """Searching with session_id='session-A' should exclude session-B entries."""
        results = self.mem.search("redis cluster", session_id="session-A")
        for r in results:
            self.assertNotEqual(
                getattr(r, "session_id", ""),
                "session-B",
                "session-B entry should not appear in session-A search",
            )

    def test_default_session_id_is_star(self):
        """MemorySystem.search() default session_id='*' preserves backward compat."""
        # Old code doesn't pass session_id — should still work and return results
        results = self.mem.search("postgresql migration")
        # Should return results (default is "*" = cross-session)
        self.assertGreater(len(results), 0, "Default search should still return results")


class TestMemoryEntrySessionId(unittest.TestCase):
    """Test that MemoryEntry.session_id serializes and deserializes correctly."""

    def test_default_session_id_is_empty_string(self):
        m = MemoryEntry("test content", "src", 1, "general")
        self.assertEqual(m.session_id, "")

    def test_session_id_round_trips(self):
        m = MemoryEntry("test content", "src", 1, "general")
        m.session_id = "my-session-123"
        d = m.to_dict()
        self.assertEqual(d.get("session_id"), "my-session-123")
        m2 = MemoryEntry.from_dict(d)
        self.assertEqual(m2.session_id, "my-session-123")

    def test_empty_session_id_not_serialized(self):
        """Empty session_id should not appear in the dict (keeps file size lean)."""
        m = MemoryEntry("test content", "src", 1, "general")
        d = m.to_dict()
        self.assertNotIn("session_id", d)

    def test_missing_session_id_in_dict_defaults_to_empty(self):
        """from_dict with no session_id field → empty string (backward compat)."""
        d = {
            "content": "old memory without session",
            "source": "old-source",
            "line": 0,
            "category": "general",
        }
        m = MemoryEntry.from_dict(d)
        self.assertEqual(m.session_id, "")


if __name__ == "__main__":
    unittest.main()
