# MixLift

Marketing Mix Modeling as an MCP server. CSV in, budget recommendations out.

MixLift runs Bayesian Media Mix Models (MMM) using [PyMC-Marketing](https://github.com/pymc-labs/pymc-marketing) and exposes results through the [Model Context Protocol](https://modelcontextprotocol.io/) so AI assistants like Claude can analyze your marketing data.

## What you get

- **Channel ROAS** — Return on ad spend per channel with 90% credible intervals
- **Marginal ROAS** — Diminishing returns at current spend levels
- **Budget optimization** — Optimal allocation across channels with expected lift
- **Saturation curves** — Spend vs. response curves showing diminishing returns
- **Convergence diagnostics** — MCMC health checks (R-hat, divergences)
- **Actionable recommendations** — Ranked list of budget reallocation moves

## Install

```bash
pip install mixlift
```

Requires Python 3.11+. PyMC and its dependencies (PyTensor, NumPy, etc.) are installed automatically.

## Setup with Claude Desktop

Add to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "mixlift": {
      "command": "mixlift-mcp"
    }
  }
}
```

Restart Claude Desktop. You now have the `mixlift_analyze` tool available.

## Setup with Claude Code

Add to your Claude Code MCP settings:

```json
{
  "mcpServers": {
    "mixlift": {
      "command": "mixlift-mcp"
    }
  }
}
```

## Usage

Ask Claude to analyze your marketing data:

> "Run a marketing mix model on my data at ~/marketing/spend_data.csv"

Or try the bundled demo dataset:

> "Run mixlift_analyze with no arguments to use the demo data"

### CSV format

MixLift auto-detects your CSV format. The simplest is **wide format**:

| date | google_search_spend | meta_spend | tiktok_spend | revenue |
|------|-------------------|------------|-------------|---------|
| 2024-03-11 | 5243.77 | 5658.76 | 1991.60 | 61475.19 |
| 2024-03-18 | 4237.89 | 7190.88 | 1825.93 | 59907.05 |

Requirements:
- `date` column (weekly granularity works best)
- One or more `*_spend` columns
- A `revenue`, `target`, or `sales` column

Platform exports from Meta Ads, Google Ads, and TikTok Ads are also supported.

## Pricing

- **Free**: 3 channels, 1,000 rows
- **Pro** ($199/mo): Unlimited channels and rows — [mixlift.io/pricing](https://mixlift.io/pricing)

## How it works

1. Your CSV is loaded and auto-detected (wide format or platform export)
2. A Bayesian MMM is fit using MCMC sampling (~30-60 seconds)
3. Channel contributions, ROAS, and saturation parameters are extracted
4. Budget is optimized using gradient-based reallocation
5. Results are returned as structured JSON to the AI assistant

## License

MIT
