"""Tests for billing helper functions."""

from unittest.mock import patch

from mixlift.billing.router import _resolve_plan_from_subscription


def test_resolve_plan_starter():
    subscription = {"items": {"data": [{"price": {"id": "price_starter_123"}}]}}

    with patch("mixlift.billing.router.settings") as mock_settings:
        mock_settings.stripe_starter_price_id = "price_starter_123"
        mock_settings.stripe_pro_price_id = "price_pro_456"

        result = _resolve_plan_from_subscription(subscription)

    assert result == "starter"


def test_resolve_plan_pro():
    subscription = {"items": {"data": [{"price": {"id": "price_pro_456"}}]}}

    with patch("mixlift.billing.router.settings") as mock_settings:
        mock_settings.stripe_starter_price_id = "price_starter_123"
        mock_settings.stripe_pro_price_id = "price_pro_456"

        result = _resolve_plan_from_subscription(subscription)

    assert result == "pro"


def test_resolve_plan_unknown_defaults_starter():
    subscription = {"items": {"data": [{"price": {"id": "price_unknown_999"}}]}}

    with patch("mixlift.billing.router.settings") as mock_settings:
        mock_settings.stripe_starter_price_id = "price_starter_123"
        mock_settings.stripe_pro_price_id = "price_pro_456"

        result = _resolve_plan_from_subscription(subscription)

    assert result == "starter"
