"""Tests for MixLift MCP license validation."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from mixlift_mcp.license import LicenseStatus, free_tier, validate_license


class TestFreeTier:
    def test_free_tier_defaults(self):
        status = free_tier()
        assert status.is_pro is False
        assert status.max_channels == 3
        assert status.max_rows == 1000
        assert status.message == "Free tier"

    def test_free_tier_custom_message(self):
        status = free_tier("custom msg")
        assert status.message == "custom msg"
        assert status.is_pro is False


class TestValidateLicense:
    @pytest.mark.asyncio
    async def test_none_key_returns_free(self):
        result = await validate_license(None)
        assert result.is_pro is False
        assert result.max_channels == 3
        assert "no license" in result.message.lower()

    @pytest.mark.asyncio
    async def test_empty_key_returns_free(self):
        result = await validate_license("")
        assert result.is_pro is False
        assert result.max_channels == 3

    @pytest.mark.asyncio
    async def test_valid_pro_key(self):
        mock_response = MagicMock()
        mock_response.json.return_value = {"valid": True, "tier": "pro"}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        # Make it work as async context manager
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("mixlift_mcp.license.httpx.AsyncClient", return_value=mock_client):
            result = await validate_license("valid-pro-key-123")

        assert result.is_pro is True
        assert result.max_channels == 999
        assert result.max_rows == 999_999
        assert "pro" in result.message.lower()
        mock_client.post.assert_called_once()

    @pytest.mark.asyncio
    async def test_invalid_key_returns_free(self):
        mock_response = MagicMock()
        mock_response.json.return_value = {"valid": False}
        mock_response.raise_for_status = MagicMock()

        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("mixlift_mcp.license.httpx.AsyncClient", return_value=mock_client):
            result = await validate_license("bad-key")

        assert result.is_pro is False
        assert result.max_channels == 3
        assert "invalid" in result.message.lower()

    @pytest.mark.asyncio
    async def test_network_error_returns_free(self):
        mock_client = AsyncMock()
        mock_client.post.side_effect = Exception("Connection refused")
        mock_client.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client.__aexit__ = AsyncMock(return_value=False)

        with patch("mixlift_mcp.license.httpx.AsyncClient", return_value=mock_client):
            result = await validate_license("some-key")

        assert result.is_pro is False
        assert "unavailable" in result.message.lower()
