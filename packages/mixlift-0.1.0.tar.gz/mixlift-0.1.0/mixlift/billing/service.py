"""Stripe billing service (stub for MVP)."""


async def update_user_tier(user_id: str, plan: str, status: str) -> None:
    """Update user's tier based on Stripe subscription status.

    Called by the webhook handler when subscription events occur.
    """
    from sqlalchemy import select

    from mixlift.db import async_session
    from mixlift.projects.models import User

    async with async_session() as session:
        result = await session.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        if not user:
            return

        if status == "active":
            user.tier = plan
        elif status in ("canceled", "unpaid", "past_due"):
            user.tier = "free"

        await session.commit()
