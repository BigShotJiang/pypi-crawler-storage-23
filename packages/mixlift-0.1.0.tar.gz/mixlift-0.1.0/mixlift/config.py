"""Application configuration via environment variables."""

from pathlib import Path

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # App
    app_name: str = "MixLift"
    environment: str = "development"
    debug: bool = False

    # Auth
    secret_key: str = "dev-secret-key-change-in-production"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 60
    refresh_token_expire_days: int = 30

    # Database
    database_url: str = "postgresql+asyncpg://mixlift:mixlift_dev@localhost:5432/mixlift"

    # Storage
    data_dir: Path = Path("data")
    upload_dir: Path = Path("data/uploads")
    model_dir: Path = Path("data/models")

    # Frontend
    frontend_url: str = "http://localhost:8501"

    # Stripe (paid tier)
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    stripe_starter_price_id: str = ""
    stripe_pro_price_id: str = ""

    # Modeling defaults
    mcmc_chains: int = 2
    mcmc_tune: int = 1000
    mcmc_draws: int = 500
    adstock_l_max: int = 8
    yearly_seasonality: int = 2

    # Tier limits
    free_max_rows: int = 1000
    free_max_channels: int = 3
    free_max_runs_per_month: int = 3
    free_max_projects: int = 3

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()

# Ensure directories exist
settings.data_dir.mkdir(parents=True, exist_ok=True)
settings.upload_dir.mkdir(parents=True, exist_ok=True)
settings.model_dir.mkdir(parents=True, exist_ok=True)
