"""Opinionated default configuration for the MMM model."""

# MCMC sampler settings (balance speed vs quality)
DEFAULT_MCMC_CONFIG = {
    "chains": 2,
    "tune": 1000,
    "draws": 500,
    "target_accept": 0.9,
    "random_seed": 42,
}

# Adstock settings
DEFAULT_ADSTOCK_CONFIG = {
    "type": "geometric",  # simplest, 1 parameter. Weibull in v2.
    "l_max": 8,  # max lag in weeks
}

# Saturation settings
DEFAULT_SATURATION_CONFIG = {
    "type": "logistic",
}

# Seasonality
DEFAULT_SEASONALITY = {
    "yearly_seasonality": 2,  # number of Fourier terms
}

# Model fitting
FAST_CONFIG = {
    "chains": 2,
    "tune": 500,
    "draws": 250,
    "target_accept": 0.85,
    "random_seed": 42,
}
