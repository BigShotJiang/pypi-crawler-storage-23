"""Preprocessing: transform canonical data into model-ready format."""

import numpy as np
import pandas as pd


def aggregate_to_weekly(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate daily data to weekly sums.

    Input: canonical format (date, channel, spend, impressions, clicks, conversions)
    Output: same format, aggregated to ISO weeks
    """
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    # Use Monday as week start
    df["week"] = df["date"].dt.to_period("W-MON").dt.start_time

    agg = (
        df.groupby(["week", "channel"])
        .agg(
            spend=("spend", "sum"),
            impressions=("impressions", "sum"),
            clicks=("clicks", "sum"),
            conversions=("conversions", "sum"),
        )
        .reset_index()
        .rename(columns={"week": "date"})
    )

    return agg.sort_values(["date", "channel"]).reset_index(drop=True)


def fill_date_gaps(df: pd.DataFrame) -> pd.DataFrame:
    """Fill missing weeks with zero spend for each channel."""
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])

    all_weeks = pd.date_range(df["date"].min(), df["date"].max(), freq="W-MON")
    all_channels = df["channel"].unique()

    full_index = pd.MultiIndex.from_product(
        [all_weeks, all_channels], names=["date", "channel"]
    )

    df = df.set_index(["date", "channel"]).reindex(full_index, fill_value=0).reset_index()
    return df.sort_values(["date", "channel"]).reset_index(drop=True)


def pivot_channels(df: pd.DataFrame, value_col: str = "spend") -> pd.DataFrame:
    """Pivot from long format to wide: one column per channel's spend.

    Returns DataFrame indexed by date with columns like 'google_search_spend', etc.
    """
    pivoted = df.pivot_table(
        index="date",
        columns="channel",
        values=value_col,
        aggfunc="sum",
        fill_value=0,
    )

    # Clean column names: lowercase, underscores, append value_col
    pivoted.columns = [
        f"{c.lower().replace(' ', '_').replace('-', '_')}_{value_col}" for c in pivoted.columns
    ]

    return pivoted.reset_index()


def add_control_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Add trend and any other control columns to the wide-format DataFrame."""
    df = df.copy()
    df["trend"] = np.arange(len(df), dtype=float)
    return df


def prepare_model_data(
    canonical_df: pd.DataFrame,
    target_series: pd.Series | None = None,
) -> tuple[pd.DataFrame, pd.Series, list[str]]:
    """Full preprocessing pipeline: canonical → model-ready X and y.

    Args:
        canonical_df: Canonical format DataFrame (date, channel, spend, ...)
        target_series: Optional revenue/target series aligned by date.
                      If None, uses conversions summed across channels.

    Returns:
        X: DataFrame with spend columns + controls, indexed by date
        y: Target series
        channel_columns: List of channel spend column names
    """
    # Aggregate to weekly
    weekly = aggregate_to_weekly(canonical_df)

    # Fill gaps
    weekly = fill_date_gaps(weekly)

    # Pivot spend columns
    X = pivot_channels(weekly, value_col="spend")

    # Add controls
    X = add_control_columns(X)

    # Identify channel columns
    channel_columns = [c for c in X.columns if c.endswith("_spend")]

    # Build target
    if target_series is not None:
        target_series = target_series.copy()
        target_series.index = pd.to_datetime(target_series.index)
        y = target_series.reindex(X["date"]).fillna(0)
    else:
        # Sum conversions per week as target
        conv_pivot = pivot_channels(weekly, value_col="conversions")
        conv_cols = [c for c in conv_pivot.columns if c.endswith("_conversions")]
        y = conv_pivot[conv_cols].sum(axis=1)

    # Ensure alignment
    assert len(X) == len(y), f"X has {len(X)} rows but y has {len(y)}"

    return X, y, channel_columns
