"""MixLift MCP Server — Marketing Mix Modeling for AI assistants."""
