from sklearn.model_selection import GridSearchCV, TimeSeriesSplit

def build_model_forecast(pipelines, param_grids, X, y, scoring='neg_mean_absolute_error', n_splits=5, train_size=0.33, verbose=1):
    """
    Lance GridSearchCV avec TimeSeriesSplit pour du forecasting.
    """
    results = {}
    tscv = TimeSeriesSplit(n_splits=n_splits, test_size=int(len(y)/n_splits*train_size))

    for i, pipeline in enumerate(pipelines):
        name = f'pipeline_{i}'
        grid = param_grids.get(name, {})
        print(f"\n GridSearch temporel pour {name}...")

        search = GridSearchCV(
            estimator=pipeline,
            param_grid=grid,
            scoring=scoring,
            cv=tscv,
            verbose=verbose,
            n_jobs=-1
        )
        search.fit(X, y)

        results[name] = {
            'best_model': search.best_estimator_,
            'best_score_cv': search.best_score_,
            'best_params': search.best_params_,
        }

    return results