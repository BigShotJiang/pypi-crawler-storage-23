
from sklearn.base import BaseEstimator, TransformerMixin
import pandas as pd

class MonthBinaryEncoder(BaseEstimator, TransformerMixin):
    def __init__(self, date_column:str):
        self.date_column = date_column
        self.month_names = [
            'janvier', 'fevrier', 'mars', 'avril', 'mai', 'juin',
            'juillet', 'aout', 'septembre', 'octobre', 'novembre', 'decembre'
        ]

    def fit(self, X, y=None):
        return self  # Pas d'apprentissage nécessaire

    def transform(self, X):
        X_ = X.copy()
        if not pd.api.types.is_datetime64_any_dtype(X_[self.date_column]):
            X_[self.date_column] = pd.to_datetime(X_[self.date_column])

        # Extraire le mois et créer les colonnes binaires
        for i, name in enumerate(self.month_names, start=1):
            X_[f'is_{name}'] = X_[self.date_column].dt.month == i

        return X_

class MonthlyCumulativeSalesTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, date_column='date', value_column='sales'):
        self.date_column = date_column
        self.value_column = value_column
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X_copy = X.copy()
        X_copy[self.date_column] = pd.to_datetime(X_copy[self.date_column])
        X_copy['year_month'] = X_copy[self.date_column].dt.to_period('M')
        X_copy.sort_values(by=self.date_column, inplace=True)
        X_copy['monthly_cumulative_sales'] = X_copy.groupby('year_month')[self.value_column].cumsum()
        X_copy.drop(columns=['year_month'], inplace=True)
        return X_copy

class MonthlySumLagTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, date_col: str, value_col: str, lags: list[int], fillna: bool = True):
        self.date_col = date_col
        self.value_col = value_col
        self.lags = lags
        self.fillna = fillna

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        df = X.copy()
        df[self.date_col] = pd.to_datetime(df[self.date_col])
        df['month'] = df[self.date_col].dt.to_period('M').dt.to_timestamp()

        # Agrégation mensuelle
        monthly = df.groupby('month')[self.value_col].sum().reset_index()
        monthly.columns = ['month', f'{self.value_col}_monthly_sum']

        # Ajout des lags
        for lag in self.lags:
            lagged = monthly.copy()
            lagged['month'] += pd.DateOffset(months=lag)
            lagged.columns = ['month', f'{self.value_col}_monthly_sum_lag{lag}']
            df = df.merge(lagged, on='month', how='left')

        # Ajout de la valeur agrégée actuelle
        df = df.merge(monthly, on='month', how='left')

        if self.fillna:
            df.fillna(value=pd.NA, inplace=True)

        return df.drop(columns=['month', f'{self.value_col}_monthly_sum'])

class MovingAverageDeltaTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, date_column:str, value_column:str, window_pairs:list[tuple]=[(7, 28)]):
        self.date_column = date_column
        self.value_column = value_column
        self.window_pairs = window_pairs

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X_ = X.copy()
        X_[self.date_column] = pd.to_datetime(X_[self.date_column])
        X_.sort_values(by=self.date_column, inplace=True)

        # Calcul des moyennes mobiles
        for short_win, long_win in self.window_pairs:
            short_ma = X_[self.value_column].rolling(window=short_win, min_periods=1).mean()
            long_ma = X_[self.value_column].rolling(window=long_win, min_periods=1).mean()
            delta = short_ma - long_ma
            col_name = f'delta_ma_{short_win}_{long_win}'
            X_[col_name] = delta

        return X_

class RemainingWeekdaysInMonthTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, date_column: str):
        self.date_column = date_column

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        X_ = X.copy()
        X_[self.date_column] = pd.to_datetime(X_[self.date_column])

        weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

        def count_remaining_weekdays_excluding_today(date):
            end_of_month = date + pd.offsets.MonthEnd(0)
            remaining_dates = pd.date_range(start=date + pd.Timedelta(days=1), end=end_of_month)
            counts = {day: 0 for day in weekdays}
            for d in remaining_dates:
                day_name = d.day_name()
                counts[day_name] += 1
            return pd.Series(counts)

        weekday_counts = X_[self.date_column].apply(count_remaining_weekdays_excluding_today)
        X_ = pd.concat([X_, weekday_counts], axis=1)

        return X_