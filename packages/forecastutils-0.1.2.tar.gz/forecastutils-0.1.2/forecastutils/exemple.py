from sklearn.pipeline import Pipeline
from xgboost import XGBRegressor
from sklearn.preprocessing import StandardScaler
from forecastutils.preprocessing import MonthBinaryEncoder, MonthlySumLagTransformer
import pandas as pd
import numpy as np

def create_random_daily_sales_df(start:str, end:str, min:int, max:int, seed:int=None)->pd.DataFrame:
    dates = pd.date_range(start=start, end=end, freq='D')
    np.random.seed(seed)
    ventes = np.random.randint(min,max,size=len(dates))
    return pd.DataFrame({'date':dates,'vente':ventes})
    

pipe0 = Pipeline([
    ('month_encoder', MonthBinaryEncoder(date_column='date')),
    ('scaler', StandardScaler()),    
    ('xgb', XGBRegressor())
])

pipe1 = Pipeline([
    ('month_encoder', MonthBinaryEncoder(date_column='date')),
    ('lag_aggregator', MonthlySumLagTransformer(date_col='date', value_col='value', lags=[1], fillna=False)),
    ('xgb', XGBRegressor())
])

param_grids = {
    'pipeline_0': {
        'xgb__n_estimators': [50, 100],
        'xgb__max_depth': [3, 5]
    },
    'pipeline_1': {
        'xgb__learning_rate': [0.1, 0.3],
        'xgb__max_depth': [2, 4]
    }
}

# results = build_model([pipe1, pipe2], param_grids, X_train, y_train, X_test, y_test)