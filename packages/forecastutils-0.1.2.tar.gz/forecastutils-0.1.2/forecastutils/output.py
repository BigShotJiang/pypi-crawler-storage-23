import pandas as pd
import numpy as np
import requests
import json
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.backends.backend_pdf import PdfPages
from datetime import datetime


# =====================================================================
# FONCTIONS AUXILIAIRES
# =====================================================================

def _preparer_donnees_futures(df_enseigne):
    """Prépare les dates futures jusqu'à la fin du mois."""
    start = df_enseigne['DateVteInitialString'].max()
    start_ts = pd.to_datetime(start)
    end_ts = start_ts + pd.offsets.MonthEnd(0)
    dates = pd.date_range(start=start_ts, end=end_ts, freq="D")
    formatted = dates.strftime("%Y-%m-%d").tolist()

    add = pd.DataFrame(data={
        "Pays_code": [df_enseigne["Pays_code"].tolist()[-1]] * len(formatted[1:]),
        "Enseigne": [df_enseigne["Enseigne"].tolist()[-1]] * len(formatted[1:]),
        "DateVteInitialString": formatted[1:],
        "NbVentes": [np.nan] * len(formatted[1:])
    })
    
    return pd.concat([df_enseigne, add]).reset_index(drop=True)


def _appeler_api_prediction(data_input, model_uri,
                            mlflow_url="https://mlflow-service2-334094007809.europe-west1.run.app",
                            apiprev_url="https://apiprev-service-334094007809.europe-west1.run.app/predict"):
    """Appelle l'API de prédiction MLflow."""
    uri = mlflow_url
    data_api = data_input[["Pays_code", "Enseigne", "DateVteInitialString", "NbVentes"]].copy().fillna(0)
    cols = list(data_api.columns)

    payload = {
        "mlflow_url": uri,
        "model_uri": model_uri,
        "columns": cols,
        "data": data_api.iloc[:].values.tolist()
    }

    url = apiprev_url
    response = requests.post(url, json=payload)
    
    return pd.Series(json.loads(response.text)["prediction"]).astype(int)


def _appliquer_correction(data_input):
    """Applique la correction sur les prévisions du mois en cours."""
    current_month = max(data_input["DateVteInitialString"].astype(str).str[:7])
    df_current_month = data_input[data_input["DateVteInitialString"].astype(str).str[:7] == current_month]
    df_current_month_dropna = df_current_month.dropna()
    coeff = sum(df_current_month_dropna.output) / sum(df_current_month_dropna.NbVentes)

    df_current_month['output_corrig'] = (df_current_month['output'] / coeff).astype(int)
    data_input['output'].iloc[-len(df_current_month['output_corrig']):] = df_current_month['output_corrig']
    
    return data_input


def _calculer_metriques_comparatives(data_input):
    """Calcule les cumuls mensuels et le comparatif N-1."""
    # Convertir et trier
    data_input["Date"] = pd.to_datetime(data_input["DateVteInitialString"])
    data_input = data_input.sort_values("Date")
    data_input["diff"] = data_input["output"] - data_input["NbVentes"]
    
    # Préparer les colonnes pour N-1
    data_input['Year'] = pd.to_datetime(data_input['DateVteInitialString']).dt.year
    data_input['MonthDay'] = pd.to_datetime(data_input['DateVteInitialString']).dt.strftime('%m-%d')
    
    # Calculer NbVentes N-1
    data_input['NbVentes_N-1'] = None
    for idx in data_input.index:
        current_year = data_input.loc[idx, 'Year']
        current_monthday = data_input.loc[idx, 'MonthDay']
        previous_year_data = data_input[
            (data_input['Year'] == current_year - 1) & 
            (data_input['MonthDay'] == current_monthday)
        ]
        if len(previous_year_data) > 0:
            data_input.loc[idx, 'NbVentes_N-1'] = previous_year_data['NbVentes'].values[0]
    
    # Calculer les cumuls mensuels
    data_input['YearMonth'] = pd.to_datetime(data_input['DateVteInitialString']).dt.to_period('M')
    data_input['Cumul_Réel'] = data_input.groupby('YearMonth')['NbVentes'].transform(lambda x: x.fillna(0).cumsum())
    data_input['Cumul_Prévision'] = data_input.groupby('YearMonth')['output'].transform(lambda x: x.fillna(0).cumsum())
    
    return data_input


def _creer_graphiques_matplotlib(df_plot, enseigne, export_pdf):
    """Crée les graphiques matplotlib et exporte en PDF si demandé."""
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 10), sharex=True)
    fig.suptitle("Comparaison NbVentes vs Prévision & Différence par jour", 
                 fontsize=16, fontweight='bold', y=0.995)
    
    # Graphique 1 : NbVentes vs Prévision
    ax1.plot(df_plot["Date"], df_plot["NbVentes"], 
            marker='o', linestyle='-', linewidth=2, markersize=4,
            color='#1f77b4', label='NbVentes')
    
    ax1.plot(df_plot["Date"], df_plot["output"], 
            marker='o', linestyle='-', linewidth=2, markersize=4,
            color='#ff7f0e', label='Prévision')
    
    ax1.set_ylabel('Volume', fontsize=12, fontweight='bold')
    ax1.set_title('NbVentes vs Prévision (par jour)', fontsize=13, pad=10)
    ax1.legend(loc='best', framealpha=0.9)
    ax1.grid(True, alpha=0.3, linestyle='--')
    ax1.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
    ax1.tick_params(axis='x', rotation=45)
    
    # Graphique 2 : Différence
    df_plot_clean = df_plot.dropna(subset=['diff'])
    ax2.bar(df_plot_clean["Date"], df_plot_clean["diff"], 
           color='#2ca02c', alpha=0.7, 
           label='Différence (prévision - NbVentes)')
    
    ax2.axhline(y=0, color='black', linestyle='-', linewidth=0.8, alpha=0.5)
    ax2.set_xlabel('Date', fontsize=12, fontweight='bold')
    ax2.set_ylabel('Différence', fontsize=12, fontweight='bold')
    ax2.set_title('Différence (prévision - NbVentes)', fontsize=13, pad=10)
    ax2.legend(loc='best', framealpha=0.9)
    ax2.grid(True, alpha=0.3, linestyle='--')
    ax2.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
    ax2.tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    
    if export_pdf:
        _exporter_pdf(fig, df_plot, enseigne)
    
    plt.show()


def _exporter_pdf(fig, df_plot, enseigne):
    """Exporte les graphiques et le tableau en PDF."""
    pdf_filename = f"{enseigne}_previsions.pdf"
    
    with PdfPages(pdf_filename) as pdf:
        # Page 1 : Les graphiques
        pdf.savefig(fig, bbox_inches='tight')
        
        # Page 2 : Tableau
        fig_table = plt.figure(figsize=(14, 10))
        ax_table = fig_table.add_subplot(111)
        ax_table.axis('off')
        
        df_display = df_plot.tail(31)[['DateVteInitialString', 'NbVentes', 'output', 'diff', 
                                       'Cumul_Réel', 'Cumul_Prévision', 'NbVentes_N-1']].copy()
        df_display = df_display.reset_index(drop=True)
        df_display.columns = ['Date', 'NbVentes', 'Prévision', 'Différence', 
                             'Cumul Réel', 'Cumul Prév.', 'NbVentes N-1']
        
        table_data = [df_display.columns.tolist()] + df_display.values.tolist()
        table = ax_table.table(cellText=table_data, cellLoc='center', loc='center', bbox=[0, 0, 1, 1])
        
        table.auto_set_font_size(False)
        table.set_fontsize(7)
        table.scale(1, 2)
        
        # Style du header
        for i in range(len(df_display.columns)):
            table[(0, i)].set_facecolor('#4472C4')
            table[(0, i)].set_text_props(weight='bold', color='white')
        
        # Alternance de couleurs
        for i in range(1, len(table_data)):
            for j in range(len(df_display.columns)):
                if i % 2 == 0:
                    table[(i, j)].set_facecolor('#E7E6E6')
                else:
                    table[(i, j)].set_facecolor('white')
        
        ax_table.set_title(f'Données de prévision - {enseigne} (31 dernières lignes)', 
                          fontsize=14, fontweight='bold', pad=20)
        
        pdf.savefig(fig_table, bbox_inches='tight')
        plt.close(fig_table)
        
        # Métadonnées
        d = pdf.infodict()
        d['Title'] = f'Prévisions {enseigne}'
        d['Author'] = 'Système de Prévision'
        d['Subject'] = 'Analyse des ventes et prévisions'
        d['Keywords'] = f'Prévisions, {enseigne}, Ventes'
        d['CreationDate'] = datetime.now()
    
    print(f"✅ PDF exporté : {pdf_filename}")


def _exporter_csv(df_plot, enseigne):
    """Exporte les données en CSV."""
    csv_filename = f"{enseigne}_previsions.csv"
    
    df_export_final = df_plot[['DateVteInitialString', 'NbVentes', 'output', 'diff', 
                               'Cumul_Réel', 'Cumul_Prévision', 'NbVentes_N-1']].copy()
    df_export_final.columns = ['Date', 'NbVentes', 'Prévision', 'Différence', 
                              'Cumul_Réel', 'Cumul_Prévision', 'NbVentes_N-1']
    
    df_export_final.to_csv(csv_filename, index=False, encoding='utf-8-sig')
    print(f"✅ CSV exporté : {csv_filename}")


def _formater_sortie_schema(df_plot, df_enseigne, model_uri, geo_scale_type, geo_scale_value):
    """Formate le DataFrame de sortie selon le schéma standardisé."""
    max_date_input = df_enseigne[df_enseigne['NbVentes'].notna()]['DateVteInitialString'].max()
    model_id = model_uri.replace('models:/', '')
    
    df_schema = pd.DataFrame({
        'date': df_plot['DateVteInitialString'].values,
        'prevision': df_plot['output'].values,
        'pays_code': df_plot['Pays_code'].values,
        'enseigne': df_plot['Enseigne'].values,
        'model_id': model_id,
        'max_date_input': max_date_input,
        'target_type': 'journalier' if 'jour' in model_id else 'reste a faire',
        'creation_date': datetime.now().strftime('%Y%m%d'),
        'anneemois_prevision': pd.to_datetime(df_plot['DateVteInitialString']).dt.strftime('%Y%m').values,
        'geo_scale_type': geo_scale_type,
        'geo_scale_value': geo_scale_value
    })
    
    return df_schema


# =====================================================================
# FONCTION PRINCIPALE
# =====================================================================

def get_prev(df, enseigne, date_min, model_uri, show_panel=[1], correction=False, 
             export_pdf=False, export_csv=False, format_output='simple', 
             geo_scale_type=None, geo_scale_value=None):
    """
    Fonction de prévision avec visualisation matplotlib et export PDF/CSV optionnel.
    
    Parameters:
    -----------
    df : DataFrame
        DataFrame contenant les données de ventes
    enseigne : str
        Nom de l'enseigne à analyser
    date_min : str
        Date minimale pour l'affichage (format YYYY-MM-DD)
    model_uri : str
        URI du modèle MLflow
    show_panel : list
        Liste des panneaux à afficher (par défaut [1])
    correction : bool
        Appliquer la correction ou non
    export_pdf : bool
        Si True, exporte les graphiques et données en PDF
    export_csv : bool
        Si True, exporte les données en CSV
    format_output : str
        Format du DataFrame retourné: 'simple' (défaut) ou 'schema' pour le format standardisé
    geo_scale_type : str, optional
        Type d'échelle géographique (ex: 'region', 'department', etc.)
    geo_scale_value : str, optional
        Valeur de l'échelle géographique (ex: 'Grand Est', '67', etc.)
    
    Returns:
    --------
    df_output : DataFrame
        DataFrame avec les prévisions (format dépend de format_output)
    """
    
    # Filtrer par enseigne
    df_enseigne = df[df["Enseigne"] == enseigne]
    
    # Préparer les données avec dates futures
    data_input = _preparer_donnees_futures(df_enseigne)
    
    # Appeler l'API pour les prévisions
    data_input['output'] = _appeler_api_prediction(data_input, model_uri)
    
    # Appliquer correction si demandé
    if correction:
        data_input = _appliquer_correction(data_input)
    
    # Calculer les métriques comparatives (cumuls, N-1, etc.)
    data_input = _calculer_metriques_comparatives(data_input)
    
    # Filtrer par date_min
    df_plot = data_input[data_input["DateVteInitialString"] >= date_min].copy()
    
    # Visualisation
    if 1 in show_panel:
        _creer_graphiques_matplotlib(df_plot, enseigne, export_pdf)
    
    # Export CSV
    if export_csv:
        _exporter_csv(df_plot, enseigne)
    
    # Formatage de la sortie
    if format_output == 'schema':
        return _formater_sortie_schema(df_plot, df_enseigne, model_uri, geo_scale_type, geo_scale_value)
    else:
        return df_plot
