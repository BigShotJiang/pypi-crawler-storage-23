from setuptools import setup, find_packages
import pathlib

# Lit le requirements.txt
this_dir = pathlib.Path(__file__).parent
requirements_path = this_dir / "requirements.txt"
with open(requirements_path, "r") as f:
    requirements = f.read().splitlines()


setup(
    name="forecastutils",
    version="0.1.2",
    packages=['forecastutils'],
    install_requires=requirements,
    include_package_data=True,
    description="Custom utilities for prediction pipeline",
    python_requires='>=3.8',
)