# Roadmap

> Update this file as you plan and complete milestones. AI agents read this to understand the "When".

## Milestone 1: MVP
- [ ] Feature 1
- [ ] Feature 2
- [ ] Feature 3

## Milestone 2: Scale
- [ ] Performance optimization
- [ ] Caching layer
- [ ] Monitoring

## Milestone 3: Polish
- [ ] UI/UX refinement
- [ ] Documentation
- [ ] Public launch
