"""MCP tool registrations — import sub-modules to trigger @mcp.tool() decorators."""
