from .gnomopo import getpos, getsize, invoke, setverbosity, Installer

__version__ = "0.1.1"