from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python <3.11
    import tomli as tomllib

from .model import SourceConfig


@dataclass(frozen=True)
class AppConfig:
    sources: list[SourceConfig]


DEFAULT_CONFIG_PATH = Path(os.path.expanduser("~/.config/trail/config.toml"))


def _default_sources() -> list[SourceConfig]:
    return [
        SourceConfig(
            name="codex",
            kind="codex",
            path=Path(os.path.expanduser("~/.codex")),
            include=["sessions/**/*.jsonl", "sessions/**/*.json"],
        ),
        SourceConfig(
            name="lmstudio",
            kind="lmstudio",
            path=Path(os.path.expanduser("~/.lmstudio")),
            include=["conversations/*.conversation.json"],
        ),
    ]


def load_config(path: Path | None = None) -> AppConfig:
    config_path = path or DEFAULT_CONFIG_PATH
    if not config_path.exists():
        return AppConfig(sources=_default_sources())

    data = _read_toml(config_path)
    sources: list[SourceConfig] = []
    sources_tbl = data.get("sources", {})
    for name, src in sources_tbl.items():
        sources.append(_parse_source(name, src))

    if not sources:
        sources = _default_sources()
    return AppConfig(sources=sources)


def default_config_text() -> str:
    return (
        "[sources.codex]\n"
        "kind = \"codex\"\n"
        "path = \"~/.codex\"\n"
        "include = [\"sessions/**/*.jsonl\", \"sessions/**/*.json\"]\n\n"
        "[sources.claude]\n"
        "kind = \"claude\"\n"
        "path = \"~/.claude\"\n"
        "include = [\"projects/**/*.jsonl\"]\n\n"
        "[sources.gemini]\n"
        "kind = \"gemini\"\n"
        "path = \"~/.gemini\"\n"
        "include = [\"tmp/*/chats/session-*.json\", \"tmp/*/logs.json\"]\n\n"
        "[sources.lmstudio]\n"
        "kind = \"lmstudio\"\n"
        "path = \"~/.lmstudio\"\n"
        "include = [\"conversations/*.conversation.json\"]\n"
    )


def write_default_config(path: Path | None = None, *, force: bool = False) -> Path:
    config_path = path or DEFAULT_CONFIG_PATH
    if config_path.exists() and not force:
        raise FileExistsError(f"Config already exists: {config_path}")
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(default_config_text(), encoding="utf-8")
    return config_path


def _read_toml(path: Path) -> dict[str, Any]:
    with path.open("rb") as handle:
        return tomllib.load(handle)


def _parse_source(name: str, src: dict[str, Any]) -> SourceConfig:
    kind = str(src.get("kind", name))
    path = Path(os.path.expanduser(str(src.get("path", ""))))
    include = src.get("include") or ["**/*.jsonl"]
    if isinstance(include, str):
        include = [include]
    return SourceConfig(name=name, kind=kind, path=path, include=list(include))
