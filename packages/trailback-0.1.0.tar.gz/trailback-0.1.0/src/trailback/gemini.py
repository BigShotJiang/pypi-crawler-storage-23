from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .model import Event, Session, SourceConfig
from .tokens import load_tokenizer


def iter_sessions(source: SourceConfig) -> list[Session]:
    files = _collect_files(source)
    sessions: list[Session] = []
    for path in files:
        if path.name == "logs.json":
            sessions.extend(_read_log_sessions(source, path))
            continue
        session = _read_session(source, path)
        if session:
            sessions.append(session)
    sessions = _dedupe_sessions(sessions)
    sessions.sort(key=lambda s: s.started_at or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    return sessions


def _collect_files(source: SourceConfig) -> list[Path]:
    files: list[Path] = []
    for pattern in source.include:
        files.extend(sorted(source.path.glob(pattern)))
    unique = {p.resolve() for p in files if p.is_file()}
    return sorted(unique)


def _read_session(source: SourceConfig, path: Path) -> Session | None:
    data = _read_json(path)
    if not isinstance(data, dict):
        return None
    messages = data.get("messages")
    if not isinstance(messages, list):
        return None

    events: list[Event] = []
    started_at: datetime | None = _parse_timestamp(data.get("startTime"))
    title: str | None = None
    model: str | None = None

    session_id = _extract_session_id(data, path, source)
    for raw in messages:
        if not isinstance(raw, dict):
            continue
        event = _normalize_message(source, path, raw, session_id)
        if event is None:
            continue
        events.append(event)
        if started_at is None and event.timestamp:
            started_at = event.timestamp
        if title is None and event.role == "user" and event.content:
            candidate = _title_candidate(event.content)
            if candidate:
                title = candidate
        if model is None and isinstance(raw.get("model"), str):
            model = raw["model"]

    if not events:
        return None

    usage = _aggregate_usage(events)
    usage_estimate = _estimate_usage(events, model)

    return Session(
        source=source.name,
        session_id=session_id,
        path=path,
        events=events,
        started_at=started_at,
        title=title,
        model=model,
        cwd=None,
        group_id=None,
        sub_id=None,
        usage=usage,
        usage_estimate=usage_estimate,
    )


def _read_log_sessions(source: SourceConfig, path: Path) -> list[Session]:
    data = _read_json(path)
    if not isinstance(data, list):
        return []

    grouped: dict[str, list[Event]] = {}
    for raw in data:
        if not isinstance(raw, dict):
            continue
        session_id = raw.get("sessionId")
        if not isinstance(session_id, str):
            continue
        event = _normalize_log_item(source, path, raw, session_id)
        if event is None:
            continue
        grouped.setdefault(session_id, []).append(event)

    sessions: list[Session] = []
    for session_id, events in grouped.items():
        events.sort(key=lambda e: e.timestamp or datetime.min.replace(tzinfo=timezone.utc))
        started_at = next((e.timestamp for e in events if e.timestamp), None)
        title = None
        for event in events:
            if event.role == "user" and event.content:
                candidate = _title_candidate(event.content)
                if candidate:
                    title = candidate
                    break
        usage = _aggregate_usage(events)
        usage_estimate = _estimate_usage(events, None)
        sessions.append(
            Session(
                source=source.name,
                session_id=session_id,
                path=path,
                events=events,
                started_at=started_at,
                title=title,
                model=f"{source.name} (logs)",
                cwd=None,
                group_id=None,
                sub_id=None,
                usage=usage,
                usage_estimate=usage_estimate,
            )
        )
    return sessions


def _read_json(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None


def _normalize_message(
    source: SourceConfig, path: Path, raw: dict[str, Any], session_id: str
) -> Event | None:
    timestamp = _parse_timestamp(raw.get("timestamp"))
    event_type = raw.get("type")
    role = _normalize_role(raw.get("type"))
    content = _normalize_content(raw.get("content"))
    usage = _extract_usage(raw)
    meta = _extract_meta(raw, path)

    if role is None and content is None and not usage:
        return None

    return Event(
        source=source.name,
        session_id=session_id,
        timestamp=timestamp,
        event_type=event_type,
        role=role,
        content=content,
        usage=usage,
        meta=meta,
        tool={},
    )


def _normalize_log_item(
    source: SourceConfig, path: Path, raw: dict[str, Any], session_id: str
) -> Event | None:
    timestamp = _parse_timestamp(raw.get("timestamp"))
    event_type = raw.get("type")
    role = _normalize_role(raw.get("type"))
    content = _normalize_content(raw.get("message"))
    if role is None and content is None:
        return None
    meta = _extract_meta(raw, path)
    if "messageId" in raw:
        meta.setdefault("messageId", raw.get("messageId"))

    return Event(
        source=source.name,
        session_id=session_id,
        timestamp=timestamp,
        event_type=event_type,
        role=role,
        content=content,
        usage={},
        meta=meta,
        tool={},
    )


def _extract_session_id(raw: dict[str, Any], path: Path, source: SourceConfig) -> str:
    session_id = raw.get("sessionId") if isinstance(raw, dict) else None
    if isinstance(session_id, str) and session_id:
        return session_id
    try:
        return str(path.relative_to(source.path))
    except ValueError:
        return str(path)


def _normalize_role(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    lowered = value.lower()
    if lowered == "gemini":
        return "assistant"
    if lowered in {"user", "assistant", "system"}:
        return lowered
    return None


def _normalize_content(value: Any) -> str | None:
    if isinstance(value, str):
        return value
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                text = item.get("text") or item.get("content")
                if isinstance(text, str):
                    parts.append(text)
        if parts:
            return "\n".join(parts)
    return None


def _parse_timestamp(value: Any) -> datetime | None:
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    return None


def _extract_usage(raw: dict[str, Any]) -> dict[str, Any]:
    tokens = raw.get("tokens")
    if not isinstance(tokens, dict):
        return {}
    input_tokens = tokens.get("input")
    output_tokens = tokens.get("output")
    total_tokens = tokens.get("total")

    usage: dict[str, Any] = {}
    if isinstance(input_tokens, int):
        usage["input_tokens"] = input_tokens
    if isinstance(output_tokens, int):
        usage["output_tokens"] = output_tokens
    if isinstance(total_tokens, int):
        usage["total_tokens"] = total_tokens
    elif isinstance(input_tokens, int) or isinstance(output_tokens, int):
        usage["total_tokens"] = (input_tokens or 0) + (output_tokens or 0)
    return usage


def _extract_meta(raw: dict[str, Any], path: Path) -> dict[str, Any]:
    meta: dict[str, Any] = {}
    tokens = raw.get("tokens")
    if isinstance(tokens, dict):
        for key in ("cached", "thoughts", "tool"):
            value = tokens.get(key)
            if isinstance(value, int):
                meta[f"tokens_{key}"] = value
    if isinstance(raw.get("thoughts"), list):
        meta["thoughts"] = raw.get("thoughts")
    meta.setdefault("path", str(path))
    return meta


def _aggregate_usage(events: list[Event]) -> dict[str, Any]:
    totals = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    found = False
    for event in events:
        usage = event.usage
        if not usage:
            continue
        found = True
        input_tokens = usage.get("input_tokens")
        output_tokens = usage.get("output_tokens")
        total_tokens = usage.get("total_tokens")
        if isinstance(input_tokens, int):
            totals["input_tokens"] += input_tokens
        if isinstance(output_tokens, int):
            totals["output_tokens"] += output_tokens
        if isinstance(total_tokens, int):
            totals["total_tokens"] += total_tokens
    return totals if found else {}


def _estimate_usage(events: list[Event], model: str | None) -> dict[str, Any]:
    tokenizer = load_tokenizer(model)
    if tokenizer is None:
        return {"available": False, "reason": "tokenizer_unavailable"}

    input_tokens = 0
    output_tokens = 0
    for event in events:
        if not event.content:
            continue
        tokens = tokenizer.count(event.content)
        if event.role == "user":
            input_tokens += tokens
        elif event.role == "assistant":
            output_tokens += tokens
    return {
        "available": True,
        "tokenizer": tokenizer.name,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": input_tokens + output_tokens,
    }


def _title_candidate(content: str) -> str | None:
    text = content.strip()
    if not text:
        return None
    first_line = text.splitlines()[0].strip()
    return first_line[:120]


def _dedupe_sessions(sessions: list[Session]) -> list[Session]:
    best: dict[str, Session] = {}
    for session in sessions:
        current = best.get(session.session_id)
        if current is None:
            best[session.session_id] = session
            continue
        if _session_rank(session) > _session_rank(current):
            best[session.session_id] = session
        elif _session_rank(session) == _session_rank(current):
            if _ts_or_min(session.started_at) > _ts_or_min(current.started_at):
                best[session.session_id] = session
    return list(best.values())


def _session_rank(session: Session) -> int:
    score = len(session.events)
    if session.model:
        score += 5
    if session.usage:
        score += 10
    if any(event.role == "assistant" for event in session.events):
        score += 1000
    return score


def _ts_or_min(value: datetime | None) -> datetime:
    if value is None:
        return datetime.min.replace(tzinfo=timezone.utc)
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value
