from __future__ import annotations

import argparse
from datetime import datetime, timezone
from pathlib import Path

from .codex import iter_sessions as iter_codex_sessions
from .claude import iter_sessions as iter_claude_sessions
from .gemini import iter_sessions as iter_gemini_sessions
from .lmstudio import iter_sessions as iter_lmstudio_sessions
from .config import load_config, write_default_config
from .todos import iter_todos


def main() -> None:
    parser = argparse.ArgumentParser(prog="trail", description="Browse local agent logs")
    parser.add_argument("--config", type=Path, help="Path to config.toml")

    subparsers = parser.add_subparsers(dest="command", required=True)

    sources_cmd = subparsers.add_parser("sources", help="List configured sources")
    sources_cmd.add_argument("--kind", help="Filter by source kind")

    ls_cmd = subparsers.add_parser("ls", help="List sessions")
    ls_cmd.add_argument("--source", help="Source name")
    ls_cmd.add_argument("--limit", type=int, default=50)
    ls_cmd.add_argument("--no-cwd", action="store_true", help="Hide cwd column")
    ls_cmd.add_argument("--show-ids", action="store_true", help="Show group/subsession ids")
    ls_cmd.add_argument("--group", action="store_true", help="Group related sessions")
    ls_cmd.add_argument("--header", action="store_true", help="Show header row")

    open_cmd = subparsers.add_parser("open", help="Print a session transcript")
    open_cmd.add_argument("session_id", help="Session id as shown by ls")
    open_cmd.add_argument("--source", help="Source name")
    open_cmd.add_argument("--group", action="store_true", help="Open grouped session by group_id")
    open_cmd.add_argument("--todo", action="store_true", help="Open todo list by session_id")

    stats_cmd = subparsers.add_parser("stats", help="Show usage stats by date and month")
    stats_cmd.add_argument("--source", help="Source name")
    stats_cmd.add_argument(
        "--format",
        choices=("text", "csv", "json"),
        default="text",
        help="Output format",
    )
    stats_cmd.add_argument(
        "--no-header",
        action="store_true",
        help="Omit header row for CSV output",
    )
    stats_cmd.add_argument(
        "--period",
        choices=("all", "daily", "monthly", "yearly"),
        default="all",
        help="Aggregation period",
    )

    tui_cmd = subparsers.add_parser("tui", help="Launch the TUI", add_help=False)
    tui_cmd.add_argument("-h", "--help", action="store_true", help="Show TUI keybinds and exit")
    tui_cmd.add_argument("--keys", action="store_true", help="Show TUI keybinds and exit")

    todos_cmd = subparsers.add_parser("todos", help="List todos from Claude sessions")
    todos_cmd.add_argument("--orphaned", action="store_true", help="Only show todos without sessions")
    todos_cmd.add_argument("--pending", action="store_true", help="Only show pending todos")
    todos_cmd.add_argument("--completed", action="store_true", help="Only show completed todos")

    init_cmd = subparsers.add_parser("init", help="Create a default config file")
    init_cmd.add_argument("--path", type=Path, help="Config path override")
    init_cmd.add_argument("--force", action="store_true", help="Overwrite existing file")

    args = parser.parse_args()
    config = load_config(args.config)

    if args.command == "sources":
        _cmd_sources(config, args.kind)
        return
    if args.command == "ls":
        show_ids = args.show_ids or args.group
        _cmd_ls(config, args.source, args.limit, args.no_cwd, show_ids, args.group, args.header)
        return
    if args.command == "open":
        _cmd_open(config, args.source, args.session_id, args.group, args.todo)
        return
    if args.command == "stats":
        _cmd_stats(config, args.source, args.format, args.period, args.no_header)
        return
    if args.command == "tui":
        if getattr(args, "help", False) or getattr(args, "keys", False):
            _print_tui_help()
            return
        _cmd_tui(config)
        return
    if args.command == "todos":
        _cmd_todos(config, args.orphaned, args.pending, args.completed)
        return
    if args.command == "init":
        _cmd_init(args.path, args.force)
        return


def _cmd_sources(config, kind: str | None) -> None:
    for source in config.sources:
        if kind and source.kind != kind:
            continue
        print(f"{source.name}\t{source.kind}\t{source.path}")


def _cmd_ls(
    config,
    source_name: str | None,
    limit: int,
    no_cwd: bool,
    show_ids: bool,
    group: bool,
    header: bool,
) -> None:
    sources = _filter_sources(config, source_name)
    rows = []
    totals_reported: dict[str, dict[str, int]] = {}
    totals_estimated: dict[str, dict[str, int]] = {}
    sessions = []
    for source in sources:
        for session in _iter_source_sessions(source):
            sessions.append(session)
            started = session.started_at.isoformat() if session.started_at else ""
            model = session.model or ""
            cwd = session.cwd or ""
            rep_usage, est_usage = _usage_for_stats(session)
            usage = _format_usage(rep_usage)
            estimate = _format_estimate(est_usage)
            rep_usage, est_usage = _usage_for_stats(session)
            _accumulate_totals(totals_reported, model, rep_usage)
            _accumulate_totals(totals_estimated, model, est_usage)
            group_id = session.group_id or ""
            sub_id = session.sub_id or ""
            if not group:
                row_base = [started, session.source, session.session_id]
                if show_ids:
                    row_base.extend([group_id, sub_id])
                if not no_cwd:
                    row_base.append(cwd)
                row_base.extend([model, usage, estimate])
                rows.append(tuple(row_base))

    if group:
        for grouped in _group_sessions_for_cli(sessions, _usage_for_stats):
            started = grouped["started_at"]
            source = grouped["source"]
            session_id = grouped["session_id"]
            cwd = grouped["cwd"]
            model = grouped["model"]
            usage = _format_usage(grouped["usage"])
            estimate = _format_estimate(grouped["usage_estimate"])
            row_base = [started, source, session_id]
            # Always include group_id when grouped, even if show_ids is false.
            row_base.append(grouped.get("group_id", ""))
            if show_ids:
                row_base.append(grouped.get("sub_id", ""))
            if not no_cwd:
                row_base.append(cwd)
            row_base.extend([model, usage, estimate])
            rows.append(tuple(row_base))

    if header:
        header_row = ["started_at", "source", "session_id"]
        if group:
            header_row.append("group_id")
        if show_ids:
            header_row.append("sub_id")
        if not no_cwd:
            header_row.append("cwd")
        header_row.extend(["model", "usage", "usage_estimate"])
        print("\t".join(header_row))
    for row in rows[:limit]:
        print("\t".join(row))
    _print_totals(totals_reported, totals_estimated)


def _cmd_open(config, source_name: str | None, session_id: str, group: bool, todo: bool = False) -> None:
    sources = _filter_sources(config, source_name)

    # Load todos for Claude sources (for joining with sessions)
    todos_by_session: dict[str, list] = {}
    todo_snapshots: dict[str, object] = {}
    for source in sources:
        if source.kind == "claude":
            for snapshot in iter_todos(source):
                if snapshot.items:
                    todos_by_session[snapshot.session_id] = snapshot.items
                    todo_snapshots[snapshot.session_id] = snapshot

    # Collect all session IDs to determine which todos have sessions
    session_ids: set[str] = set()
    for source in sources:
        for session in _iter_source_sessions(source):
            session_ids.add(session.group_id or session.session_id)
            session_ids.add(session.session_id)

    # Mark which todos have sessions
    for snapshot in todo_snapshots.values():
        snapshot.has_session = snapshot.session_id in session_ids

    # Handle --todo flag: show todo list for session_id
    if todo:
        if session_id not in todo_snapshots:
            raise SystemExit(f"No todos found for session: {session_id}")
        snapshot = todo_snapshots[session_id]
        _print_todo_detail(snapshot, sources)
        return

    matches = []
    direct_match = False
    group_sources = set()
    for source in sources:
        for session in _iter_source_sessions(source):
            if group and session.group_id == session_id:
                matches.append(session)
                group_sources.add(source.name)
            elif not group and session.session_id == session_id:
                todos = todos_by_session.get(session.group_id or session.session_id, [])
                _print_transcript(session, todos)
                direct_match = True
                return
            elif not group and session.group_id == session_id:
                matches.append(session)
                group_sources.add(source.name)
    if matches and not direct_match:
        if not group and len(group_sources) > 1:
            raise SystemExit(
                f"Multiple group matches for {session_id}. Use --source to disambiguate."
            )
        todos = todos_by_session.get(session_id, [])
        _print_group_transcript(session_id, matches, todos)
        return
    raise SystemExit(f"Session not found: {session_id}")


def _cmd_stats(
    config, source_name: str | None, fmt: str, period: str, no_header: bool
) -> None:
    sources = _filter_sources(config, source_name)
    daily_reported: dict[str, dict[str, int]] = {}
    daily_estimated: dict[str, dict[str, int]] = {}
    monthly_reported: dict[str, dict[str, int]] = {}
    monthly_estimated: dict[str, dict[str, int]] = {}
    yearly_reported: dict[str, dict[str, int]] = {}
    yearly_estimated: dict[str, dict[str, int]] = {}

    # Todo counts by period (for orphaned todos)
    daily_todos: dict[str, int] = {}
    monthly_todos: dict[str, int] = {}
    yearly_todos: dict[str, int] = {}

    # Collect session IDs to identify orphaned todos
    session_ids: set[str] = set()

    for source in sources:
        for session in _iter_source_sessions(source):
            if session.group_id:
                session_ids.add(session.group_id)
            session_ids.add(session.session_id)
            if not session.started_at:
                continue
            day_key = session.started_at.date().isoformat()
            month_key = session.started_at.strftime("%Y-%m")
            year_key = session.started_at.strftime("%Y")
            rep_usage, est_usage = _usage_for_stats(session)
            _accumulate_bucket(daily_reported, day_key, rep_usage)
            _accumulate_bucket(daily_estimated, day_key, est_usage)
            _accumulate_bucket(monthly_reported, month_key, rep_usage)
            _accumulate_bucket(monthly_estimated, month_key, est_usage)
            _accumulate_bucket(yearly_reported, year_key, rep_usage)
            _accumulate_bucket(yearly_estimated, year_key, est_usage)

    # Load orphaned todos and aggregate by date
    for source in sources:
        if source.kind == "claude":
            for snapshot in iter_todos(source):
                # Only count orphaned todos (no corresponding session)
                if snapshot.session_id in session_ids:
                    continue
                if not snapshot.modified_at:
                    continue
                day_key = snapshot.modified_at.date().isoformat()
                month_key = snapshot.modified_at.strftime("%Y-%m")
                year_key = snapshot.modified_at.strftime("%Y")
                todo_count = len(snapshot.items)
                daily_todos[day_key] = daily_todos.get(day_key, 0) + todo_count
                monthly_todos[month_key] = monthly_todos.get(month_key, 0) + todo_count
                yearly_todos[year_key] = yearly_todos.get(year_key, 0) + todo_count

    if fmt == "text":
        if period in ("all", "daily"):
            _print_stats("Daily", daily_reported, daily_estimated, daily_todos)
        if period == "all":
            print("")
        if period in ("all", "monthly"):
            _print_stats("Monthly", monthly_reported, monthly_estimated, monthly_todos)
        if period == "all":
            print("")
        if period in ("all", "yearly"):
            _print_stats("Yearly", yearly_reported, yearly_estimated, yearly_todos)
        return
    rows = _stats_rows(
        daily_reported,
        daily_estimated,
        monthly_reported,
        monthly_estimated,
        yearly_reported,
        yearly_estimated,
        daily_todos,
        monthly_todos,
        yearly_todos,
        period,
    )
    if fmt == "csv":
        _print_csv(rows, no_header)
        return
    if fmt == "json":
        _print_json(rows)
        return


def _cmd_tui(config) -> None:
    from .tui import run

    run(config)


def _print_tui_help() -> None:
    print(
        "Trail TUI\n"
        "\n"
        "Usage:\n"
        "  trail tui\n"
        "\n"
        "Keybind overrides:\n"
        "  Optional file: ~/.config/trail/keybinds.toml\n"
        "  Use [bindings] to override action keys (replaces defaults for that action).\n"
        "  If an action is present with an empty list, it disables that binding.\n"
        "\n"
        "Example:\n"
        "  [bindings]\n"
        "  copy_transcript = [\"y\", \"ctrl+shift+c\"]\n"
        "  toggle_mode = [\"m\"]\n"
        "  focus_sessions = [\",\"]\n"
        "  focus_transcript = [\".\"]\n"
        "\n"
        "Default keybindings:\n"
        "  quit: q\n"
        "  open: enter (also e toggles groups)\n"
        "  focus_next: tab\n"
        "  focus_previous: shift+tab\n"
        "  focus_sessions: s\n"
        "  focus_transcript: t\n"
        "  focus_filter: f\n"
        "  focus_search: /\n"
        "  show_sessions: 1, ctrl+1, f1\n"
        "  show_stats: 2, ctrl+2, f2\n"
        "  toggle_mode: m\n"
        "  stats_heatmap: h\n"
        "  stats_list: l\n"
        "  stats_prev_page: [\n"
        "  stats_next_page: ]\n"
        "  copy_transcript: y, ctrl+shift+c\n"
        "\n"
        "Available actions:\n"
        "  quit, open, focus_next, focus_previous, focus_sessions, focus_transcript,\n"
        "  focus_filter, focus_search, show_sessions, show_stats, toggle_mode,\n"
        "  stats_heatmap, stats_list, stats_prev_page, stats_next_page, copy_transcript\n"
        "\n"
        "Notes:\n"
        "  - Comma/period/bracket keys can be written as literal characters in TOML lists.\n"
        "    For period, you can also use \"full_stop\".\n"
    )


def _cmd_todos(config, orphaned: bool, pending: bool, completed: bool) -> None:
    """List todos from Claude sessions."""
    # Only load from Claude sources
    claude_sources = [s for s in config.sources if s.kind == "claude"]
    if not claude_sources:
        print("No Claude sources configured")
        return

    # Collect all todos
    all_todos = []
    for source in claude_sources:
        for snapshot in iter_todos(source):
            all_todos.append(snapshot)

    if not all_todos:
        print("No todos found")
        return

    # Load sessions to determine which todos have sessions
    session_ids: set[str] = set()
    for source in claude_sources:
        for session in iter_claude_sessions(source):
            session_ids.add(session.group_id or session.session_id)

    # Mark todos that have sessions
    for snapshot in all_todos:
        snapshot.has_session = snapshot.session_id in session_ids

    # Apply filters
    if orphaned:
        all_todos = [t for t in all_todos if not t.has_session]

    # Sort by modified_at (newest first)
    all_todos.sort(key=lambda t: t.modified_at or datetime.min.replace(tzinfo=timezone.utc), reverse=True)

    # Print todos in summary format (like trail ls)
    for snapshot in all_todos:
        # Count items by status (respecting filters)
        total = len(snapshot.items)
        done = sum(1 for item in snapshot.items if item.status == "completed")
        pend = total - done

        # Apply status filters for display
        if pending and pend == 0:
            continue
        if completed and done == 0:
            continue

        # Format datetime
        if snapshot.modified_at:
            dt_str = snapshot.modified_at.isoformat()
        else:
            dt_str = ""

        # Format status marker
        status_marker = "[orphaned]" if not snapshot.has_session else ""

        # Format item count
        count_str = f"{total} items ({done}✓ {pend}○)"

        # Print tab-separated like trail ls
        print(f"{dt_str}\t{snapshot.session_id}\t{status_marker}\t{count_str}")


def _cmd_init(path: Path | None, force: bool) -> None:
    try:
        config_path = write_default_config(path, force=force)
    except FileExistsError as exc:
        raise SystemExit(str(exc)) from exc
    print(f"Wrote config: {config_path}")


def _filter_sources(config, source_name: str | None):
    if source_name:
        return [s for s in config.sources if s.name == source_name]
    return config.sources


def _iter_source_sessions(source):
    if source.kind == "codex":
        return iter_codex_sessions(source)
    if source.kind == "claude":
        return iter_claude_sessions(source)
    if source.kind == "gemini":
        return iter_gemini_sessions(source)
    if source.kind == "lmstudio":
        return iter_lmstudio_sessions(source)
    return []


def _usage_for_stats(session) -> tuple[dict, dict]:
    estimate = session.usage_estimate or {}
    if estimate.get("available") is False:
        estimate = {}
    return session.usage or {}, estimate


def _print_transcript(session, todos: list | None = None) -> None:
    header = f"{session.source}\t{session.session_id}"
    print(header)
    if session.started_at:
        print(f"started_at\t{session.started_at.isoformat()}")
    if session.model:
        print(f"model\t{session.model}")
    if session.cwd:
        print(f"cwd\t{session.cwd}")
    if session.group_id:
        print(f"group_id\t{session.group_id}")
    if session.sub_id:
        print(f"sub_id\t{session.sub_id}")
    if session.usage:
        print(f"usage\t{_format_usage(session.usage)}")
    if session.usage_estimate:
        print(f"usage_estimate\t{_format_estimate(session.usage_estimate)}")

    # Print todos if present
    if todos:
        print(f"todos\t{len(todos)} items")
        print("")
        print("[todos]")
        for item in todos:
            status_icon = "✓" if item.status == "completed" else "○"
            priority_tag = f"[{item.priority}]" if item.priority != "medium" else ""
            print(f"  {status_icon} {item.content} {priority_tag}")
        print("")
    else:
        print("")

    for event in session.events:
        role = event.role or "event"
        if event.content:
            print(f"[{role}]\n{event.content}\n")


def _print_group_transcript(group_id: str, sessions, todos: list | None = None) -> None:
    print(f"group_id\t{group_id}")
    print(f"sessions\t{len(sessions)}")
    models = sorted({s.model for s in sessions if s.model})
    if models:
        print(f"models\t{', '.join(models)}")

    # Print todos if present
    if todos:
        print(f"todos\t{len(todos)} items")
        print("")
        print("[todos]")
        for item in todos:
            status_icon = "✓" if item.status == "completed" else "○"
            priority_tag = f"[{item.priority}]" if item.priority != "medium" else ""
            print(f"  {status_icon} {item.content} {priority_tag}")
        print("")
    else:
        print("")

    merged = []
    for session in sessions:
        sub_id = session.sub_id or session.session_id
        for event in session.events:
            if not event.content:
                continue
            ts = event.timestamp or datetime.min
            merged.append((ts, sub_id, event.role or "event", event.content))
    merged.sort(key=lambda x: x[0])
    for ts, sub_id, role, content in merged:
        print(f"[{role} | {sub_id}]\n{content}\n")


def _print_todo_detail(snapshot, sources) -> None:
    """Print detailed todo list for a session, plus transcript if session exists."""
    print(f"session_id\t{snapshot.session_id}")
    if snapshot.modified_at:
        print(f"modified_at\t{snapshot.modified_at.isoformat()}")
    print(f"file\t{snapshot.path.name}")

    # Count items
    total = len(snapshot.items)
    done = sum(1 for item in snapshot.items if item.status == "completed")
    pend = total - done
    status = "[orphaned]" if not snapshot.has_session else ""
    print(f"items\t{total} ({done}✓ {pend}○) {status}")
    print("")

    # Print all todos with full content
    print("[todos]")
    for item in snapshot.items:
        status_icon = "✓" if item.status == "completed" else "○"
        priority_tag = f"[{item.priority}]" if item.priority != "medium" else ""
        print(f"  {status_icon} {item.content} {priority_tag}")
    print("")

    # If session exists, also print transcript
    if snapshot.has_session:
        # Find and print matching sessions
        matches = []
        for source in sources:
            for session in _iter_source_sessions(source):
                if session.group_id == snapshot.session_id or session.session_id == snapshot.session_id:
                    matches.append(session)
        if matches:
            if len(matches) == 1:
                print("[transcript]")
                for event in matches[0].events:
                    if event.content:
                        role = event.role or "event"
                        print(f"[{role}]\n{event.content}\n")
            else:
                # Multiple sessions (group)
                print(f"[transcript - {len(matches)} sessions]")
                merged = []
                for session in matches:
                    sub_id = session.sub_id or session.session_id
                    for event in session.events:
                        if not event.content:
                            continue
                        ts = event.timestamp or datetime.min
                        merged.append((ts, sub_id, event.role or "event", event.content))
                merged.sort(key=lambda x: x[0])
                for ts, sub_id, role, content in merged:
                    print(f"[{role} | {sub_id}]\n{content}\n")


def _format_usage(usage: dict) -> str:
    if not usage:
        return ""
    input_tokens = usage.get("input_tokens")
    output_tokens = usage.get("output_tokens")
    total_tokens = usage.get("total_tokens")
    parts = []
    if isinstance(input_tokens, int):
        parts.append(f"in={input_tokens}")
    if isinstance(output_tokens, int):
        parts.append(f"out={output_tokens}")
    if isinstance(total_tokens, int):
        parts.append(f"total={total_tokens}")
    return " ".join(parts)


def _format_estimate(estimate: dict) -> str:
    if not estimate:
        return ""
    if estimate.get("available") is False:
        reason = estimate.get("reason", "unknown")
        return f"unavailable({reason})"
    input_tokens = estimate.get("input_tokens")
    output_tokens = estimate.get("output_tokens")
    total_tokens = estimate.get("total_tokens")
    tokenizer = estimate.get("tokenizer")
    parts = []
    if tokenizer:
        parts.append(f"tok={tokenizer}")
    if isinstance(input_tokens, int):
        parts.append(f"in={input_tokens}")
    if isinstance(output_tokens, int):
        parts.append(f"out={output_tokens}")
    if isinstance(total_tokens, int):
        parts.append(f"total={total_tokens}")
    return " ".join(parts)


def _group_sessions_for_cli(sessions, usage_selector=None):
    usage_selector = usage_selector or (lambda s: (s.usage or {}, s.usage_estimate or {}))
    groups: dict[tuple[str, str], list] = {}
    singles = []
    for session in sessions:
        if session.group_id:
            groups.setdefault((session.source, session.group_id), []).append(session)
        else:
            singles.append(session)
    rows = []
    for (source, group_id), group_sessions in groups.items():
        started = max(
            (_ts_or_min(s.started_at) for s in group_sessions), default=_ts_or_min(None)
        )
        cwds = {s.cwd for s in group_sessions if s.cwd}
        cwd = ""
        if len(cwds) == 1:
            cwd = next(iter(cwds))
        elif len(cwds) > 1:
            cwd = "(multiple)"
        models = sorted({s.model for s in group_sessions if s.model})
        model_text = ", ".join(models[:3]) + ("…" if len(models) > 3 else "")
        usage = _sum_usage([usage_selector(s)[0] for s in group_sessions])
        estimate = _sum_usage([usage_selector(s)[1] for s in group_sessions])
        rows.append(
            {
                "started_at": started.isoformat() if started != _ts_or_min(None) else "",
                "source": source,
                "session_id": group_id,
                "group_id": group_id,
                "sub_id": f"{len(group_sessions)} subs",
                "cwd": cwd,
                "model": model_text,
                "usage": usage,
                "usage_estimate": estimate,
            }
        )
    for session in singles:
        rep_usage, est_usage = usage_selector(session)
        rows.append(
            {
                "started_at": _ts_or_min(session.started_at).isoformat()
                if session.started_at
                else "",
                "source": session.source,
                "session_id": session.session_id,
                "group_id": session.group_id or "",
                "sub_id": session.sub_id or "",
                "cwd": session.cwd or "",
                "model": session.model or "",
                "usage": rep_usage,
                "usage_estimate": est_usage,
            }
        )
    rows.sort(key=lambda r: r["started_at"], reverse=True)
    return rows


def _sum_usage(usages):
    totals = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    for usage in usages:
        if not usage:
            continue
        input_tokens = usage.get("input_tokens") or usage.get("prompt_tokens")
        output_tokens = usage.get("output_tokens") or usage.get("completion_tokens")
        total_tokens = usage.get("total_tokens")
        if isinstance(input_tokens, int):
            totals["input_tokens"] += input_tokens
        if isinstance(output_tokens, int):
            totals["output_tokens"] += output_tokens
        if isinstance(total_tokens, int):
            totals["total_tokens"] += total_tokens
        else:
            if isinstance(input_tokens, int) or isinstance(output_tokens, int):
                totals["total_tokens"] += (input_tokens or 0) + (output_tokens or 0)
    return totals


def _ts_or_min(value: datetime | None) -> datetime:
    if value is None:
        return datetime.min.replace(tzinfo=timezone.utc)
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value


def _accumulate_bucket(buckets: dict[str, dict[str, int]], key: str, usage: dict) -> None:
    if not usage:
        return
    bucket = buckets.setdefault(key, {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0})
    input_tokens = usage.get("input_tokens") or usage.get("prompt_tokens")
    output_tokens = usage.get("output_tokens") or usage.get("completion_tokens")
    total_tokens = usage.get("total_tokens")
    if isinstance(input_tokens, int):
        bucket["input_tokens"] += input_tokens
    if isinstance(output_tokens, int):
        bucket["output_tokens"] += output_tokens
    if isinstance(total_tokens, int):
        bucket["total_tokens"] += total_tokens
    else:
        if isinstance(input_tokens, int) or isinstance(output_tokens, int):
            bucket["total_tokens"] += (input_tokens or 0) + (output_tokens or 0)


def _print_stats(
    title: str,
    reported: dict[str, dict[str, int]],
    estimated: dict[str, dict[str, int]],
    todos: dict[str, int] | None = None,
) -> None:
    print(f"{title} usage")
    todos = todos or {}
    keys = sorted(set(reported.keys()) | set(estimated.keys()) | set(todos.keys()))
    for key in keys:
        rep = reported.get(key, {})
        est = estimated.get(key, {})
        rep_in = rep.get("input_tokens", 0)
        rep_out = rep.get("output_tokens", 0)
        rep_total = rep.get("total_tokens", 0)
        est_in = est.get("input_tokens", 0)
        est_out = est.get("output_tokens", 0)
        est_total = est.get("total_tokens", 0)
        todo_count = todos.get(key, 0)
        todo_str = f"\ttodos={todo_count}" if todo_count > 0 else ""
        print(
            f"{key}\treported in={rep_in} out={rep_out} total={rep_total}\t"
            f"estimated in={est_in} out={est_out} total={est_total}{todo_str}"
        )


def _stats_rows(
    daily_reported: dict[str, dict[str, int]],
    daily_estimated: dict[str, dict[str, int]],
    monthly_reported: dict[str, dict[str, int]],
    monthly_estimated: dict[str, dict[str, int]],
    yearly_reported: dict[str, dict[str, int]],
    yearly_estimated: dict[str, dict[str, int]],
    daily_todos: dict[str, int] | None = None,
    monthly_todos: dict[str, int] | None = None,
    yearly_todos: dict[str, int] | None = None,
    period: str = "all",
) -> list[dict[str, int | str]]:
    rows: list[dict[str, int | str]] = []
    if period in ("all", "daily"):
        rows.extend(_stats_rows_for_period("daily", daily_reported, daily_estimated, daily_todos))
    if period in ("all", "monthly"):
        rows.extend(_stats_rows_for_period("monthly", monthly_reported, monthly_estimated, monthly_todos))
    if period in ("all", "yearly"):
        rows.extend(_stats_rows_for_period("yearly", yearly_reported, yearly_estimated, yearly_todos))
    return rows


def _stats_rows_for_period(
    period: str,
    reported: dict[str, dict[str, int]],
    estimated: dict[str, dict[str, int]],
    todos: dict[str, int] | None = None,
) -> list[dict[str, int | str]]:
    rows: list[dict[str, int | str]] = []
    todos = todos or {}
    keys = sorted(set(reported.keys()) | set(estimated.keys()) | set(todos.keys()))
    for key in keys:
        rep = reported.get(key, {})
        est = estimated.get(key, {})
        rows.append(
            {
                "period": period,
                "key": key,
                "reported_input_tokens": rep.get("input_tokens", 0),
                "reported_output_tokens": rep.get("output_tokens", 0),
                "reported_total_tokens": rep.get("total_tokens", 0),
                "estimated_input_tokens": est.get("input_tokens", 0),
                "estimated_output_tokens": est.get("output_tokens", 0),
                "estimated_total_tokens": est.get("total_tokens", 0),
                "todo_items": todos.get(key, 0),
            }
        )
    return rows


def _print_csv(rows: list[dict[str, int | str]], no_header: bool) -> None:
    if not rows:
        return
    columns = [
        "period",
        "key",
        "reported_input_tokens",
        "reported_output_tokens",
        "reported_total_tokens",
        "estimated_input_tokens",
        "estimated_output_tokens",
        "estimated_total_tokens",
        "todo_items",
    ]
    if not no_header:
        print(",".join(columns))
    for row in rows:
        values = [str(row.get(col, "")) for col in columns]
        print(",".join(values))


def _print_json(rows: list[dict[str, int | str]]) -> None:
    import json

    daily = [row for row in rows if row.get("period") == "daily"]
    monthly = [row for row in rows if row.get("period") == "monthly"]
    payload: dict[str, list[dict[str, int | str]]] = {}
    if daily:
        payload["daily"] = daily
    if monthly:
        payload["monthly"] = monthly
    print(json.dumps(payload, indent=2, sort_keys=True))

def _accumulate_totals(totals: dict[str, dict[str, int]], model: str, usage: dict) -> None:
    if not usage:
        return
    model_key = model or "unknown"
    bucket = totals.setdefault(model_key, {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0})
    input_tokens = usage.get("input_tokens") or usage.get("prompt_tokens")
    output_tokens = usage.get("output_tokens") or usage.get("completion_tokens")
    total_tokens = usage.get("total_tokens")
    if isinstance(input_tokens, int):
        bucket["input_tokens"] += input_tokens
    if isinstance(output_tokens, int):
        bucket["output_tokens"] += output_tokens
    if isinstance(total_tokens, int):
        bucket["total_tokens"] += total_tokens
    else:
        if isinstance(input_tokens, int) or isinstance(output_tokens, int):
            bucket["total_tokens"] += (input_tokens or 0) + (output_tokens or 0)


def _print_totals(
    reported: dict[str, dict[str, int]], estimated: dict[str, dict[str, int]]
) -> None:
    if not reported and not estimated:
        return
    print("")
    print("Totals by model")
    models = set(reported.keys()) | set(estimated.keys())
    for model in sorted(models):
        rep = reported.get(model, {})
        est = estimated.get(model, {})
        rep_in = rep.get("input_tokens", 0)
        rep_out = rep.get("output_tokens", 0)
        rep_total = rep.get("total_tokens", 0)
        est_in = est.get("input_tokens", 0)
        est_out = est.get("output_tokens", 0)
        est_total = est.get("total_tokens", 0)
        print(
            f"{model}\treported in={rep_in} out={rep_out} total={rep_total}\t"
            f"estimated in={est_in} out={est_out} total={est_total}"
        )
    rep_all = _sum_totals(reported)
    est_all = _sum_totals(estimated)
    if rep_all or est_all:
        print(
            "ALL\t"
            f"reported in={rep_all.get('input_tokens', 0)} out={rep_all.get('output_tokens', 0)} "
            f"total={rep_all.get('total_tokens', 0)}\t"
            f"estimated in={est_all.get('input_tokens', 0)} out={est_all.get('output_tokens', 0)} "
            f"total={est_all.get('total_tokens', 0)}"
        )


def _sum_totals(totals: dict[str, dict[str, int]]) -> dict[str, int]:
    agg = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    for usage in totals.values():
        agg["input_tokens"] += usage.get("input_tokens", 0)
        agg["output_tokens"] += usage.get("output_tokens", 0)
        agg["total_tokens"] += usage.get("total_tokens", 0)
    return agg
