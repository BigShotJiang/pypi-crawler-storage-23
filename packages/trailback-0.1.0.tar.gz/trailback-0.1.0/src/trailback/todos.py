from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from .model import SourceConfig, TodoItem, TodoSnapshot


def iter_todos(source: SourceConfig) -> list[TodoSnapshot]:
    """Read all todo files from ~/.claude/todos/ and return snapshots."""
    todos_dir = source.path / "todos"
    if not todos_dir.is_dir():
        return []

    snapshots: list[TodoSnapshot] = []
    for path in sorted(todos_dir.glob("*.json")):
        snapshot = _read_todo_file(path)
        if snapshot is not None:
            snapshots.append(snapshot)
    return snapshots


def _read_todo_file(path: Path) -> TodoSnapshot | None:
    """Parse JSON array from todo file. Returns None if empty or invalid."""
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None

    if not isinstance(data, list) or not data:
        return None

    items = _parse_items(data)
    if not items:
        return None

    # Get file modification time
    try:
        mtime = path.stat().st_mtime
        modified_at = datetime.fromtimestamp(mtime, tz=timezone.utc)
    except OSError:
        modified_at = None

    session_id = _extract_session_id(path)
    return TodoSnapshot(
        session_id=session_id,
        path=path,
        items=items,
        modified_at=modified_at,
        has_session=False,
    )


def _parse_items(data: list) -> list[TodoItem]:
    """Parse todo items from JSON array."""
    items: list[TodoItem] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        content = item.get("content")
        status = item.get("status")
        priority = item.get("priority", "medium")
        item_id = item.get("id", "")
        if isinstance(content, str) and isinstance(status, str):
            items.append(TodoItem(
                content=content,
                status=status,
                priority=priority if isinstance(priority, str) else "medium",
                id=str(item_id),
            ))
    return items


def _extract_session_id(path: Path) -> str:
    """Extract sessionId from filename pattern.

    Patterns:
    - <uuid>-agent-<uuid>.json -> first uuid is sessionId
    - <uuid>.json -> uuid is sessionId
    """
    stem = path.stem
    # Pattern: <uuid>-agent-<uuid>
    match = re.match(r"^([a-f0-9-]+)-agent-", stem)
    if match:
        return match.group(1)
    # Pattern: <uuid> only
    if re.match(r"^[a-f0-9-]+$", stem):
        return stem
    return stem
