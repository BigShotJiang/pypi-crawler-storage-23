from __future__ import annotations

from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
import subprocess
from datetime import date, datetime, timedelta, timezone
from typing import Iterable

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.widgets import Header, Input, ListItem, ListView, RichLog, Static, TextArea
from rich.text import Text

from .codex import iter_sessions as iter_codex_sessions
from .claude import iter_sessions as iter_claude_sessions
from .gemini import iter_sessions as iter_gemini_sessions
from .lmstudio import iter_sessions as iter_lmstudio_sessions
from .config import AppConfig, load_config
from .model import Session, TodoItem, TodoSnapshot
from .todos import iter_todos

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python <3.11
    import tomli as tomllib


@dataclass
class SessionItem:
    session: Session
    todos_count: int = 0

    def label(self) -> Text:
        if self.session.started_at:
            started = self.session.started_at.strftime("%Y-%m-%d %H:%M")
        else:
            started = ""
        model = self.session.model or ""
        cwd = self.session.cwd or ""
        text = Text()
        if started:
            text.append(started)
        if cwd:
            if text:
                text.append("  ")
            text.append(cwd, style=_color_for(_cwd_key(cwd), _CWD_PALETTE))
        if model:
            if text:
                text.append("  ")
            text.append(f" {model} ", style=_model_style(model))
        if self.todos_count > 0:
            text.append(f"  📋 {self.todos_count}")
        return text


class SessionListItem(ListItem):
    def __init__(self, item: SessionItem) -> None:
        super().__init__(Static(item.label()))
        self.item = item


@dataclass
class GroupItem:
    source: str
    group_id: str
    sessions: list[Session]
    todos_count: int = 0

    def label(self) -> Text:
        latest = max((s.started_at for s in self.sessions if s.started_at), default=None)
        if latest:
            started = latest.strftime("%Y-%m-%d %H:%M")
        else:
            started = ""
        cwds = {s.cwd for s in self.sessions if s.cwd}
        cwd = ""
        if len(cwds) == 1:
            cwd = next(iter(cwds))
        elif len(cwds) > 1:
            cwd = "(multiple)"
        models = sorted({s.model for s in self.sessions if s.model})
        model_text = ", ".join(models[:3]) + ("…" if len(models) > 3 else "")
        text = Text()
        if started:
            text.append(started)
        if cwd:
            if text:
                text.append("  ")
            text.append(cwd, style=_color_for(_cwd_key(cwd), _CWD_PALETTE))
        if model_text:
            if text:
                text.append("  ")
            text.append(f" {model_text} ", style=_model_style(model_text))
        text.append(f"  [{len(self.sessions)}]")
        if self.todos_count > 0:
            text.append(f"  📋 {self.todos_count}")
        return text


class GroupListItem(ListItem):
    def __init__(self, item: GroupItem) -> None:
        super().__init__(Static(item.label()))
        self.item = item


class ChildSessionListItem(ListItem):
    def __init__(self, item: SessionItem) -> None:
        label = item.label()
        if isinstance(label, Text):
            label = Text("  └ ") + label
        super().__init__(Static(label))
        self.item = item


@dataclass
class TodoGroupItem:
    """Represents an orphaned todo snapshot (no corresponding session)."""
    snapshot: TodoSnapshot

    def label(self) -> Text:
        if self.snapshot.modified_at:
            modified = self.snapshot.modified_at.strftime("%Y-%m-%d %H:%M")
        else:
            modified = ""
        total = len(self.snapshot.items)
        done = sum(1 for item in self.snapshot.items if item.status == "completed")
        pend = total - done
        text = Text()
        if modified:
            text.append(modified)
        text.append("  ")
        text.append("[orphaned]", style="dim red")
        text.append(f"  📋 {total} ({done}✓ {pend}○)")
        return text


class TodoGroupListItem(ListItem):
    def __init__(self, item: TodoGroupItem) -> None:
        super().__init__(Static(item.label()))
        self.item = item


@dataclass
class PeriodItem:
    key: str


class PeriodListItem(ListItem):
    def __init__(self, item: PeriodItem) -> None:
        super().__init__(Static(item.key))
        self.item = item


_CWD_PALETTE = [
    "cyan",
    "magenta",
    "green",
    "yellow",
    "bright_cyan",
    "bright_magenta",
    "bright_green",
    "bright_yellow",
    "blue",
    "bright_blue",
    "red",
    "bright_red",
    "white",
    "bright_white",
]

_MODEL_VENDOR_PALETTES = {
    "openai": ["#5B2CFF", "#6C2BD9", "#3E1FA8", "#7A3FF2"],
    "anthropic": ["#E4572E", "#E07A3F", "#CC4B2C", "#F28C28"],
    "google": ["#34A853", "#7CB342", "#66BB6A", "#9CCC65"],
    "other": ["#455A64", "#546E7A", "#607D8B", "#78909C"],
}

DEFAULT_BINDINGS: list[Binding] = [
    Binding("q", "quit", "Quit"),
    Binding("enter", "open", "Open"),
    Binding("e", "open", "Toggle group"),
    Binding("tab", "focus_next", "Next pane"),
    Binding("shift+tab", "focus_previous", "Prev pane"),
    Binding("s", "focus_sessions", "Sessions"),
    Binding("t", "focus_transcript", "Transcript"),
    Binding("f", "focus_filter", "Filter"),
    Binding("/", "focus_search", "Search"),
    Binding("1", "show_sessions", "Sessions"),
    Binding("2", "show_stats", "Stats"),
    Binding("ctrl+1", "show_sessions", "Sessions"),
    Binding("ctrl+2", "show_stats", "Stats"),
    Binding("f1", "show_sessions", "Sessions"),
    Binding("f2", "show_stats", "Stats"),
    Binding("m", "toggle_mode", "Toggle mode"),
    Binding("h", "stats_heatmap", "Heatmap"),
    Binding("l", "stats_list", "List"),
    Binding("[", "stats_prev_page", "Prev page"),
    Binding("]", "stats_next_page", "Next page"),
    Binding("ctrl+shift+c,y", "copy_transcript", "Copy"),
]


def _color_for(value: str, palette: list[str]) -> str:
    digest = hashlib.sha256(value.encode("utf-8")).digest()
    idx = digest[0] % len(palette)
    return palette[idx]


def _cwd_key(cwd: str) -> str:
    parts = [p for p in cwd.split("/") if p]
    if parts:
        return parts[-1]
    return cwd


def _model_style(model: str) -> str:
    vendor = _model_vendor(model)
    palette = _MODEL_VENDOR_PALETTES.get(vendor, _MODEL_VENDOR_PALETTES["other"])
    bg = _color_for(model, palette)
    return f"black on {bg}"


def _model_vendor(model: str) -> str:
    value = model.lower()
    if any(tag in value for tag in ("gpt", "o1", "o3", "codex", "openai")):
        return "openai"
    if any(tag in value for tag in ("claude", "anthropic")):
        return "anthropic"
    if any(tag in value for tag in ("gemini", "google", "palm")):
        return "google"
    return "other"


def _keybinds_path() -> Path:
    return Path(os.path.expanduser("~/.config/trail/keybinds.toml"))


def _load_keybinds() -> dict[str, list[str]]:
    path = _keybinds_path()
    if not path.exists():
        return {}
    try:
        with path.open("rb") as handle:
            data = tomllib.load(handle)
    except (OSError, tomllib.TOMLDecodeError):
        return {}
    bindings = data.get("bindings", {})
    if not isinstance(bindings, dict):
        return {}
    out: dict[str, list[str]] = {}
    for action, keys in bindings.items():
        if not isinstance(action, str):
            continue
        if isinstance(keys, str):
            out[action] = [keys]
        elif isinstance(keys, list):
            normalized: list[str] = []
            for key in keys:
                if isinstance(key, str) and key:
                    normalized.append(_normalize_key_name(key))
            out[action] = normalized
    return out


def _normalize_key_name(key: str) -> str:
    key = key.strip()
    lowered = key.lower()
    if lowered in {",", "comma"}:
        return ","
    if lowered in {".", "period", "full_stop"}:
        return "full_stop"
    if key == "[" or lowered in {"lbracket", "left_square_bracket"}:
        return "left_square_bracket"
    if key == "]" or lowered in {"rbracket", "right_square_bracket"}:
        return "right_square_bracket"
    return key


def _bindings_by_action(bindings: Iterable[Binding]) -> dict[str, list[Binding]]:
    by_action: dict[str, list[Binding]] = {}
    for binding in bindings:
        by_action.setdefault(binding.action, []).append(binding)
    return by_action


def _build_bindings(overrides: dict[str, list[str]]) -> list[Binding]:
    if not overrides:
        return list(DEFAULT_BINDINGS)
    by_action = _bindings_by_action(DEFAULT_BINDINGS)
    actions = set(by_action.keys()) | set(overrides.keys())
    result: list[Binding] = []
    for action in sorted(actions):
        keys = overrides.get(action)
        defaults = by_action.get(action, [])
        if keys is None:
            result.extend(defaults)
            continue
        if not keys:
            continue
        template = defaults[0] if defaults else Binding("", action, action.replace("_", " ").title())
        for key in keys:
            result.append(
                Binding(
                    key,
                    action,
                    description=template.description,
                    show=template.show,
                    key_display=template.key_display,
                    priority=template.priority,
                    tooltip=template.tooltip,
                )
            )
    return result


def _session_matches(session: Session, query: str) -> bool:
    parts = [
        session.session_id,
        session.source,
        session.cwd,
        session.model,
    ]
    if session.started_at:
        parts.append(session.started_at.strftime("%Y-%m-%d"))
        parts.append(session.started_at.strftime("%Y-%m-%d %H:%M"))
    haystack = " ".join([p for p in parts if p]).lower()
    return query in haystack


def _event_matches(event, query: str) -> bool:
    content = event.content or ""
    return query in content.lower()


def _group_sessions(sessions: list[Session]) -> list[Session | GroupItem]:
    groups: dict[tuple[str, str], list[Session]] = {}
    singles: list[Session] = []
    for session in sessions:
        if session.source == "claude" and session.group_id:
            groups.setdefault((session.source, session.group_id), []).append(session)
        else:
            singles.append(session)
    items: list[Session | GroupItem] = []
    for (source, group_id), group_sessions in groups.items():
        group_sessions.sort(key=lambda s: _ts_or_min(s.started_at), reverse=True)
        items.append(GroupItem(source=source, group_id=group_id, sessions=group_sessions))
    items.extend(singles)
    items.sort(
        key=lambda item: (
            _group_latest(item) if isinstance(item, GroupItem) else _ts_or_min(item.started_at)
        ),
        reverse=True,
    )
    return items


def _group_latest(group: GroupItem) -> datetime:
    return max((_ts_or_min(s.started_at) for s in group.sessions), default=_ts_or_min(None))


def _group_matches(group: GroupItem, query: str) -> bool:
    if query in group.source.lower():
        return True
    if query in group.group_id.lower():
        return True
    for session in group.sessions:
        if _session_matches(session, query):
            return True
    return False


def _group_children(group: GroupItem, query: str) -> list[Session]:
    if not query:
        return group.sessions
    return [s for s in group.sessions if _session_matches(s, query)]


def _group_key(source: str, group_id: str) -> str:
    return f"{source}:{group_id}"


def _ts_or_min(value: datetime | None) -> datetime:
    if value is None:
        return datetime.min.replace(tzinfo=timezone.utc)
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value


def _accumulate_bucket(buckets: dict[str, dict[str, int]], key: str, usage: dict) -> None:
    if not usage:
        return
    bucket = buckets.setdefault(key, {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0})
    input_tokens = usage.get("input_tokens") or usage.get("prompt_tokens")
    output_tokens = usage.get("output_tokens") or usage.get("completion_tokens")
    total_tokens = usage.get("total_tokens")
    if isinstance(input_tokens, int):
        bucket["input_tokens"] += input_tokens
    if isinstance(output_tokens, int):
        bucket["output_tokens"] += output_tokens
    if isinstance(total_tokens, int):
        bucket["total_tokens"] += total_tokens
    else:
        if isinstance(input_tokens, int) or isinstance(output_tokens, int):
            bucket["total_tokens"] += (input_tokens or 0) + (output_tokens or 0)


def _write_stats(transcript: RichLog, reported: dict[str, dict[str, int]], estimated: dict[str, dict[str, int]]) -> None:
    keys = sorted(set(reported.keys()) | set(estimated.keys()))
    for key in keys:
        rep = reported.get(key, {})
        est = estimated.get(key, {})
        rep_in = rep.get("input_tokens", 0)
        rep_out = rep.get("output_tokens", 0)
        rep_total = rep.get("total_tokens", 0)
        est_in = est.get("input_tokens", 0)
        est_out = est.get("output_tokens", 0)
        est_total = est.get("total_tokens", 0)
        transcript.write(
            f"{key}\treported in={rep_in} out={rep_out} total={rep_total}\t"
            f"estimated in={est_in} out={est_out} total={est_total}"
        )


def _sum_usage(usages: list[dict]) -> dict[str, int]:
    totals = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    for usage in usages:
        if not usage:
            continue
        input_tokens = usage.get("input_tokens") or usage.get("prompt_tokens")
        output_tokens = usage.get("output_tokens") or usage.get("completion_tokens")
        total_tokens = usage.get("total_tokens")
        if isinstance(input_tokens, int):
            totals["input_tokens"] += input_tokens
        if isinstance(output_tokens, int):
            totals["output_tokens"] += output_tokens
        if isinstance(total_tokens, int):
            totals["total_tokens"] += total_tokens
        else:
            if isinstance(input_tokens, int) or isinstance(output_tokens, int):
                totals["total_tokens"] += (input_tokens or 0) + (output_tokens or 0)
    return totals


def _render_heatmap(
    transcript: RichLog,
    reported: dict[str, dict[str, int]],
    estimated: dict[str, dict[str, int]],
    todos: dict[str, int] | None = None,
) -> None:
    todos = todos or {}
    token_values: dict[date, int] = {}
    todo_values: dict[date, int] = {}

    keys = set(reported.keys()) | set(estimated.keys()) | set(todos.keys())
    for key in keys:
        try:
            day = date.fromisoformat(key)
        except ValueError:
            continue
        rep_total = reported.get(key, {}).get("total_tokens", 0)
        if rep_total > 0:
            token_values[day] = rep_total
        todo_count = todos.get(key, 0)
        if todo_count > 0:
            todo_values[day] = todo_count

    all_days = set(token_values.keys()) | set(todo_values.keys())
    if not all_days:
        if any(estimated.get(key, {}).get("total_tokens", 0) > 0 for key in estimated):
            transcript.write("No reported data available. Switch to list view for estimates.")
        else:
            transcript.write("No daily data available.")
        return

    min_day = min(all_days)
    max_day = max(all_days)

    # Align start to Monday for a consistent grid.
    start = min_day - timedelta(days=min_day.weekday())
    end = max_day + timedelta(days=(6 - max_day.weekday()))

    days: list[date] = []
    cursor = start
    while cursor <= end:
        days.append(cursor)
        cursor += timedelta(days=1)

    max_token = max(token_values.values()) if token_values else 0
    max_todo = max(todo_values.values()) if todo_values else 0
    token_levels = _heat_levels(max_token)
    todo_levels = _todo_heat_levels(max_todo)

    # Build grid: rows are weeks, columns are days (Mon-Sun).
    weeks = len(days) // 7
    grid: list[list[date]] = []
    for week_idx in range(weeks):
        week_days = days[week_idx * 7 : (week_idx + 1) * 7]
        grid.append(week_days)

    header = Text("Week    Mon Tue Wed Thu Fri Sat Sun")
    transcript.write(header)
    last_year = None
    for week_days in grid:
        week_start = week_days[0]
        iso = week_start.isocalendar()
        label = f"{iso.year}-W{iso.week:02d}"
        if last_year is None:
            last_year = iso.year
        elif iso.year != last_year:
            transcript.write("")
            last_year = iso.year
        line = Text(f"{label}  ")
        for day in week_days:
            token_total = token_values.get(day, 0) if day else 0
            todo_total = todo_values.get(day, 0) if day else 0
            # Prefer token color (green), fall back to todo color (purple)
            if token_total > 0:
                style = _heat_style(token_total, max_token, token_levels)
            elif todo_total > 0:
                style = _todo_heat_style(todo_total, max_todo, todo_levels)
            else:
                style = f"on {token_levels[0]}"
            line.append("  ", style=style)
            line.append(" ")
        transcript.write(line)

    # Two-tone legend
    legend = Text()
    legend.append("Tokens: ")
    for level in token_levels:
        legend.append("  ", style=f"on {level}")
        legend.append(" ")
    transcript.write(legend)

    legend2 = Text()
    legend2.append("Todos:  ")
    for level in todo_levels:
        legend2.append("  ", style=f"on {level}")
        legend2.append(" ")
    transcript.write(legend2)


def _render_period_list(
    transcript: RichLog,
    reported: dict[str, dict[str, int]],
    estimated: dict[str, dict[str, int]],
    page: int,
    page_size: int,
    label: str,
    todos: dict[str, int] | None = None,
) -> None:
    rows = _period_rows(reported, estimated, todos)
    if not rows:
        transcript.write(f"No {label} data available.")
        return
    total_pages = max(1, (len(rows) + page_size - 1) // page_size)
    page = max(0, min(page, total_pages - 1))
    start = page * page_size
    end = start + page_size
    transcript.write(
        f"{label}\treported_in\treported_out\treported_total\test_in\test_out\test_total\ttodos"
    )
    for row in rows[start:end]:
        todo_str = str(row.get('todos', 0)) if row.get('todos', 0) > 0 else ""
        transcript.write(
            f"{row['date']}\t{row['reported_in']}\t{row['reported_out']}\t{row['reported_total']}\t"
            f"{row['estimated_in']}\t{row['estimated_out']}\t{row['estimated_total']}\t{todo_str}"
        )
    transcript.write(f"Page {page + 1} / {total_pages} (latest first)")


def _period_rows(
    reported: dict[str, dict[str, int]],
    estimated: dict[str, dict[str, int]],
    todos: dict[str, int] | None = None,
) -> list[dict[str, int | str]]:
    todos = todos or {}
    rows: list[dict[str, int | str]] = []
    keys = sorted(set(reported.keys()) | set(estimated.keys()) | set(todos.keys()), reverse=True)
    for key in keys:
        rep = reported.get(key, {})
        est = estimated.get(key, {})
        rep_total = rep.get("total_tokens", 0)
        est_total = est.get("total_tokens", 0)
        todo_count = todos.get(key, 0)
        total = rep_total if rep_total > 0 else est_total
        # Show row if has tokens OR has todos
        if total <= 0 and todo_count <= 0:
            continue
        rows.append(
            {
                "date": key,
                "reported_in": rep.get("input_tokens", 0),
                "reported_out": rep.get("output_tokens", 0),
                "reported_total": rep_total,
                "estimated_in": est.get("input_tokens", 0),
                "estimated_out": est.get("output_tokens", 0),
                "estimated_total": est_total,
                "todos": todo_count,
            }
        )
    return rows


def _heat_levels(max_value: int) -> list[str]:
    if max_value <= 0:
        return ["#1f1f1f"]
    return ["#1f1f1f", "#1f4f2f", "#2e7d32", "#43a047", "#66bb6a"]


def _todo_heat_levels(max_value: int) -> list[str]:
    """Purple/blue color palette for todos."""
    if max_value <= 0:
        return ["#1f1f1f"]
    return ["#1f1f1f", "#2d1f4f", "#4a148c", "#7b1fa2", "#ab47bc"]


def _heat_style(value: int, max_value: int, levels: list[str]) -> str:
    if value <= 0 or max_value <= 0:
        return f"on {levels[0]}"
    return f"on {levels[_heat_bucket(value, max_value, levels)]}"


def _todo_heat_style(value: int, max_value: int, levels: list[str]) -> str:
    """Style for todo heatmap cells."""
    if value <= 0 or max_value <= 0:
        return f"on {levels[0]}"
    return f"on {levels[_heat_bucket(value, max_value, levels)]}"


def _heat_bucket(value: int, max_value: int, levels: list[str]) -> int:
    if value <= 0 or max_value <= 0:
        return 0
    # Bucket by percentage of max to adapt to scale.
    ratio = value / max_value
    if ratio < 0.25:
        return min(1, len(levels) - 1)
    if ratio < 0.5:
        return min(2, len(levels) - 1)
    if ratio < 0.75:
        return min(3, len(levels) - 1)
    return len(levels) - 1


def _usage_for_stats(session: Session) -> tuple[dict, dict]:
    estimate = session.usage_estimate or {}
    if estimate.get("available") is False:
        estimate = {}
    return session.usage or {}, estimate


class TrailApp(App):
    CSS = """
    Screen {
        layout: vertical;
    }

    #mode_bar {
        dock: top;
        padding: 0 1;
    }

    #help_bar {
        dock: bottom;
        padding: 0 1;
    }

    #left-pane {
        width: 40%;
        border: tall $panel;
    }

    #right-pane {
        width: 1fr;
        border: tall $panel;
    }

    #session_filter {
        dock: top;
    }

    #transcript_search {
        dock: top;
    }

    #sessions {
        height: 1fr;
    }

    #transcript_text {
        height: 1fr;
        padding: 1 2;
        overflow: auto;
    }

    #transcript_log {
        height: 1fr;
        padding: 1 2;
        overflow: auto;
    }
    """

    BINDINGS: list[Binding] = []

    def __init__(self, config: AppConfig | None = None) -> None:
        super().__init__()
        overrides = _load_keybinds()
        self._trail_bindings = _build_bindings(overrides) if overrides else list(DEFAULT_BINDINGS)
        for binding in self._trail_bindings:
            self.bind(
                binding.key,
                binding.action,
                description=binding.description,
                show=binding.show,
                key_display=binding.key_display,
            )
        self.sessions: list[Session] = []
        self.config = config or load_config()
        self.expanded_groups: set[str] = set()
        self.mode = "sessions"
        self.view_mode = "transcript"
        self.stats_view = "heatmap"
        self.stats_page = 0
        self.todos_by_session: dict[str, list[TodoItem]] = {}
        self.orphaned_todos: list[TodoSnapshot] = []
        self._help_text = ""

    def compose(self) -> ComposeResult:
        yield Header()
        yield Static("Mode: Sessions (1) | Stats (2)", id="mode_bar")
        with Horizontal():
            with Vertical(id="left-pane"):
                yield Input(placeholder="Filter sessions (date/model/cwd)...", id="session_filter")
                yield ListView(id="sessions")
            with Vertical(id="right-pane"):
                yield Input(placeholder="Search transcript...", id="transcript_search")
                yield TextArea(id="transcript_text", read_only=True, soft_wrap=True, show_cursor=False)
                yield RichLog(id="transcript_log", wrap=True)
        yield Static("", id="help_bar")

    def on_mount(self) -> None:
        if not hasattr(self, "mode"):
            self.mode = "sessions"
        self.current_session: Session | None = None
        self._load_sessions()
        self._set_mode("sessions")
        self.query_one("#sessions", ListView).focus()

    def action_open(self) -> None:
        list_view = self.query_one("#sessions", ListView)
        if list_view.index is None:
            return
        item = list_view.children[list_view.index]
        if isinstance(item, SessionListItem):
            self._render_session(item.item.session)
        elif isinstance(item, GroupListItem):
            group_id = item.item.group_id
            if group_id in self.expanded_groups:
                self.expanded_groups.remove(group_id)
            else:
                self.expanded_groups.add(group_id)
            self._apply_filter(self.query_one("#session_filter", Input).value)
        elif isinstance(item, ChildSessionListItem):
            self._render_session(item.item.session)

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        if isinstance(event.item, SessionListItem):
            self._render_session(event.item.item.session)
        if isinstance(event.item, PeriodListItem):
            self._render_stats(event.item.item.key)
        if isinstance(event.item, GroupListItem):
            group_key = _group_key(event.item.item.source, event.item.item.group_id)
            if group_key in self.expanded_groups:
                self.expanded_groups.remove(group_key)
            else:
                self.expanded_groups.add(group_key)
            self._apply_filter(self.query_one("#session_filter", Input).value)
            self._render_group(event.item.item)
        if isinstance(event.item, ChildSessionListItem):
            self._render_session(event.item.item.session)
        if isinstance(event.item, TodoGroupListItem):
            self._render_todo_group(event.item.item)

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id == "session_filter":
            self._apply_filter(event.value)
        if event.input.id == "transcript_search":
            self._render_session(self.current_session)

    def action_focus_sessions(self) -> None:
        self.query_one("#sessions", ListView).focus()

    def action_focus_transcript(self) -> None:
        if self.mode == "stats":
            self.query_one("#transcript_log", RichLog).focus()
        else:
            self.query_one("#transcript_text", TextArea).focus()

    def action_show_stats(self) -> None:
        self._set_mode("stats")

    def action_focus_filter(self) -> None:
        self.query_one("#session_filter", Input).focus()

    def action_focus_search(self) -> None:
        self.query_one("#transcript_search", Input).focus()

    def action_show_sessions(self) -> None:
        self._set_mode("sessions")

    def action_copy_transcript(self) -> None:
        if self.mode != "sessions":
            return
        transcript = self.query_one("#transcript_text", TextArea)
        selected_text = getattr(transcript, "selected_text", "")
        if not selected_text:
            self._flash_help("No selection to copy.")
            return
        try:
            self.copy_to_clipboard(selected_text)
            self._flash_help(f"Copied {len(selected_text)} chars.")
            return
        except Exception:
            pass
        try:
            subprocess.run(
                ["pbcopy"],
                input=selected_text,
                text=True,
                check=False,
            )
            self._flash_help(f"Copied {len(selected_text)} chars (pbcopy).")
        except Exception:
            self._flash_help("Copy failed.")
            pass

    def _action_keys(self, action: str) -> list[str]:
        keys: list[str] = []
        for binding in self._trail_bindings:
            if binding.action != action:
                continue
            for key in binding.key.split(","):
                key = key.strip()
                if key:
                    keys.append(key)
        return keys

    def _first_key(self, action: str) -> str | None:
        keys = self._action_keys(action)
        if not keys:
            return None
        key = keys[0]
        if key == "full_stop":
            return "."
        if key == "left_square_bracket":
            return "["
        if key == "right_square_bracket":
            return "]"
        return key

    def _flash_help(self, message: str, duration: float = 2.0) -> None:
        help_bar = self.query_one("#help_bar", Static)
        previous = self._help_text
        help_bar.update(message)

        def _restore() -> None:
            help_bar.update(previous)

        self.set_timer(duration, _restore)

    def action_stats_heatmap(self) -> None:
        if self.mode != "stats":
            return
        self.stats_view = "heatmap"
        self._render_stats("daily")

    def action_stats_list(self) -> None:
        if self.mode != "stats":
            return
        self.stats_view = "list"
        self._render_stats("daily")

    def action_stats_prev_page(self) -> None:
        if self.mode != "stats" or self.stats_view != "list":
            return
        if self.stats_page > 0:
            self.stats_page -= 1
            self._render_stats("daily")

    def action_stats_next_page(self) -> None:
        if self.mode != "stats" or self.stats_view != "list":
            return
        self.stats_page += 1
        self._render_stats("daily")

    def action_toggle_mode(self) -> None:
        if self.mode == "sessions":
            self._set_mode("stats")
        else:
            self._set_mode("sessions")

    def _load_sessions(self) -> None:
        items: list[Session] = []
        self.todos_by_session = {}
        self.orphaned_todos = []
        all_snapshots: list[TodoSnapshot] = []

        for source in self.config.sources:
            if source.kind == "codex":
                items.extend(iter_codex_sessions(source))
            elif source.kind == "claude":
                items.extend(iter_claude_sessions(source))
                # Load todos for Claude sources
                for snapshot in iter_todos(source):
                    if snapshot.items:
                        self.todos_by_session[snapshot.session_id] = snapshot.items
                        all_snapshots.append(snapshot)
            elif source.kind == "gemini":
                items.extend(iter_gemini_sessions(source))
            elif source.kind == "lmstudio":
                items.extend(iter_lmstudio_sessions(source))

        # Identify orphaned todos (no matching session)
        session_ids: set[str] = set()
        for session in items:
            session_ids.add(session.group_id or session.session_id)
            session_ids.add(session.session_id)

        for snapshot in all_snapshots:
            if snapshot.session_id not in session_ids:
                snapshot.has_session = False
                self.orphaned_todos.append(snapshot)
            else:
                snapshot.has_session = True

        # Sort orphaned todos by modified_at (newest first)
        self.orphaned_todos.sort(
            key=lambda t: t.modified_at or _ts_or_min(None),
            reverse=True
        )

        self.sessions = items
        self._apply_filter("")

    def _apply_filter(self, text: str) -> None:
        query = text.strip().lower()
        list_view = self.query_one("#sessions", ListView)
        list_view.clear()
        if self.mode == "stats":
            self._load_periods()
            return
        grouped = _group_sessions(self.sessions)
        for group in grouped:
            if isinstance(group, GroupItem):
                if query and not _group_matches(group, query):
                    continue
                # Get todos count for this group
                todos_count = len(self.todos_by_session.get(group.group_id, []))
                group.todos_count = todos_count
                list_view.append(GroupListItem(group))
                if _group_key(group.source, group.group_id) in self.expanded_groups:
                    for child in _group_children(group, query):
                        child_todos = len(self.todos_by_session.get(child.group_id or child.session_id, []))
                        list_view.append(ChildSessionListItem(SessionItem(child, child_todos)))
            else:
                session = group
                if query and not _session_matches(session, query):
                    continue
                # Get todos count for this session
                session_key = session.group_id or session.session_id
                todos_count = len(self.todos_by_session.get(session_key, []))
                list_view.append(SessionListItem(SessionItem(session, todos_count)))

        # Add orphaned todos at the end
        for snapshot in self.orphaned_todos:
            if query and query not in snapshot.session_id.lower():
                continue
            list_view.append(TodoGroupListItem(TodoGroupItem(snapshot)))

    def _render_session(self, session: Session | None) -> None:
        transcript = self.query_one("#transcript_text", TextArea)
        lines: list[str] = []
        if session is None:
            transcript.text = ""
            return
        self.view_mode = "transcript"
        self.current_session = session
        search = self.query_one("#transcript_search", Input).value.strip().lower()
        lines.append(f"{session.source}  {session.session_id}")
        if session.started_at:
            lines.append(f"started_at: {session.started_at.isoformat()}")
        if session.model:
            lines.append(f"model: {session.model}")
        if session.cwd:
            lines.append(f"cwd: {session.cwd}")
        if session.usage:
            lines.append(f"usage: {session.usage}")
        if session.usage_estimate:
            lines.append(f"usage_estimate: {session.usage_estimate}")

        # Show todos if present
        session_key = session.group_id or session.session_id
        todos = self.todos_by_session.get(session_key, [])
        if todos:
            lines.append(f"todos: {len(todos)} items")
            lines.append("")
            lines.append("[todos]")
            for item in todos:
                status_icon = "✓" if item.status == "completed" else "○"
                priority_tag = f"[{item.priority}]" if item.priority != "medium" else ""
                lines.append(f"  {status_icon} {item.content} {priority_tag}")
            lines.append("")
        else:
            lines.append("")

        for event in session.events:
            if not event.content:
                continue
            role = event.role or "event"
            if search:
                if not _event_matches(event, search):
                    continue
            lines.append(f"[{role}]")
            lines.append(event.content)
            lines.append("")
        transcript.text = "\n".join(lines)

    def _render_group(self, group: GroupItem) -> None:
        transcript = self.query_one("#transcript_text", TextArea)
        lines: list[str] = []
        lines.append(f"Group: {group.group_id}")
        lines.append(f"Sessions: {len(group.sessions)}")
        models = sorted({s.model for s in group.sessions if s.model})
        if models:
            lines.append(f"Models: {', '.join(models)}")
        cwds = sorted({s.cwd for s in group.sessions if s.cwd})
        if cwds:
            lines.append("CWDs:")
            for cwd in cwds[:10]:
                lines.append(f"- {cwd}")
        usage = _sum_usage([s.usage for s in group.sessions])
        estimate = _sum_usage([s.usage_estimate for s in group.sessions])
        if usage:
            lines.append(
                f"Usage: in={usage.get('input_tokens', 0)} out={usage.get('output_tokens', 0)} "
                f"total={usage.get('total_tokens', 0)}"
            )
        if estimate:
            lines.append(
                f"Estimate: in={estimate.get('input_tokens', 0)} out={estimate.get('output_tokens', 0)} "
                f"total={estimate.get('total_tokens', 0)}"
            )

        # Show todos if present
        todos = self.todos_by_session.get(group.group_id, [])
        if todos:
            lines.append(f"Todos: {len(todos)} items")
            lines.append("")
            lines.append("[todos]")
            for item in todos:
                status_icon = "✓" if item.status == "completed" else "○"
                priority_tag = f"[{item.priority}]" if item.priority != "medium" else ""
                lines.append(f"  {status_icon} {item.content} {priority_tag}")
            lines.append("")
        else:
            lines.append("")

        merged = []
        for session in group.sessions:
            sub_id = session.sub_id or session.session_id
            for event in session.events:
                if not event.content:
                    continue
                ts = _ts_or_min(event.timestamp)
                merged.append((ts, sub_id, event.role or "event", event.content))
        merged.sort(key=lambda x: x[0])
        for ts, sub_id, role, content in merged:
            lines.append(f"[{role} | {sub_id}]")
            lines.append(content)
            lines.append("")
        transcript.text = "\n".join(lines)

    def _render_todo_group(self, todo_group: TodoGroupItem) -> None:
        """Render an orphaned todo snapshot in the transcript pane."""
        transcript = self.query_one("#transcript_text", TextArea)
        lines: list[str] = []
        snapshot = todo_group.snapshot

        lines.append(f"Session ID: {snapshot.session_id}")
        if snapshot.modified_at:
            lines.append(f"Modified: {snapshot.modified_at.isoformat()}")
        lines.append(f"File: {snapshot.path.name}")
        lines.append("[orphaned] - No corresponding session found")

        # Count items
        total = len(snapshot.items)
        done = sum(1 for item in snapshot.items if item.status == "completed")
        pend = total - done
        lines.append(f"Items: {total} ({done}✓ {pend}○)")
        lines.append("")

        # Print all todos
        lines.append("[todos]")
        for item in snapshot.items:
            status_icon = "✓" if item.status == "completed" else "○"
            priority_tag = f"[{item.priority}]" if item.priority != "medium" else ""
            lines.append(f"  {status_icon} {item.content} {priority_tag}")
        lines.append("")
        transcript.text = "\n".join(lines)

    def _set_mode(self, mode: str) -> None:
        self.mode = mode
        mode_bar = self.query_one("#mode_bar", Static)
        if mode == "sessions":
            mode_bar.update("Mode: Sessions (1) | Stats (2)")
        else:
            mode_bar.update("Mode: Stats (1) | Sessions (2)")
        session_filter = self.query_one("#session_filter", Input)
        transcript_search = self.query_one("#transcript_search", Input)
        if mode == "sessions":
            session_filter.display = True
            transcript_search.display = True
            self.query_one("#transcript_text", TextArea).display = True
            self.query_one("#transcript_log", RichLog).display = False
            self._apply_filter(session_filter.value)
        else:
            session_filter.display = False
            transcript_search.display = False
            self.query_one("#transcript_text", TextArea).display = False
            self.query_one("#transcript_log", RichLog).display = True
            self._load_periods()
            self.stats_page = 0
            self._render_stats("daily")
        self._update_help()

    def _load_periods(self) -> None:
        list_view = self.query_one("#sessions", ListView)
        list_view.clear()
        for key in ["daily", "monthly", "yearly"]:
            list_view.append(PeriodListItem(PeriodItem(key)))

    def _render_stats(self, period: str) -> None:
        transcript = self.query_one("#transcript_log", RichLog)
        transcript.clear()
        daily_reported: dict[str, dict[str, int]] = {}
        daily_estimated: dict[str, dict[str, int]] = {}
        monthly_reported: dict[str, dict[str, int]] = {}
        monthly_estimated: dict[str, dict[str, int]] = {}
        yearly_reported: dict[str, dict[str, int]] = {}
        yearly_estimated: dict[str, dict[str, int]] = {}

        # Todo counts by period (for orphaned todos)
        daily_todos: dict[str, int] = {}
        monthly_todos: dict[str, int] = {}
        yearly_todos: dict[str, int] = {}

        for session in self.sessions:
            if not session.started_at:
                continue
            day_key = session.started_at.date().isoformat()
            month_key = session.started_at.strftime("%Y-%m")
            year_key = session.started_at.strftime("%Y")
            rep_usage, est_usage = _usage_for_stats(session)
            _accumulate_bucket(daily_reported, day_key, rep_usage)
            _accumulate_bucket(daily_estimated, day_key, est_usage)
            _accumulate_bucket(monthly_reported, month_key, rep_usage)
            _accumulate_bucket(monthly_estimated, month_key, est_usage)
            _accumulate_bucket(yearly_reported, year_key, rep_usage)
            _accumulate_bucket(yearly_estimated, year_key, est_usage)

        # Aggregate orphaned todos by date
        for snapshot in self.orphaned_todos:
            if not snapshot.modified_at:
                continue
            day_key = snapshot.modified_at.date().isoformat()
            month_key = snapshot.modified_at.strftime("%Y-%m")
            year_key = snapshot.modified_at.strftime("%Y")
            todo_count = len(snapshot.items)
            daily_todos[day_key] = daily_todos.get(day_key, 0) + todo_count
            monthly_todos[month_key] = monthly_todos.get(month_key, 0) + todo_count
            yearly_todos[year_key] = yearly_todos.get(year_key, 0) + todo_count

        if period == "daily":
            if self.stats_view == "heatmap":
                transcript.write("Daily usage (heatmap)")
                _render_heatmap(transcript, daily_reported, daily_estimated, daily_todos)
            else:
                transcript.write("Daily usage (list)")
                _render_period_list(
                    transcript, daily_reported, daily_estimated, self.stats_page, 30, "date", daily_todos
                )
        elif period == "monthly":
            transcript.write("Monthly usage (list)")
            _render_period_list(
                transcript, monthly_reported, monthly_estimated, self.stats_page, 24, "month", monthly_todos
            )
        else:
            transcript.write("Yearly usage (list)")
            _render_period_list(
                transcript, yearly_reported, yearly_estimated, self.stats_page, 10, "year", yearly_todos
            )

    def _update_help(self) -> None:
        help_bar = self.query_one("#help_bar", Static)
        if self.mode == "sessions":
            parts = []
            for action, label in (
                ("quit", "quit"),
                ("toggle_mode", "toggle"),
                ("focus_sessions", "left"),
                ("focus_transcript", "right"),
                ("focus_filter", "filter"),
                ("focus_search", "search"),
                ("open", "open"),
                ("copy_transcript", "copy"),
            ):
                key = self._first_key(action)
                if key:
                    parts.append(f"{label}={key}")
            self._help_text = "Keys: " + " | ".join(parts)
            help_bar.update(self._help_text)
        else:
            if self.stats_view == "list":
                parts = []
                for action, label in (
                    ("quit", "quit"),
                    ("toggle_mode", "toggle"),
                    ("stats_heatmap", "heatmap"),
                    ("stats_list", "list"),
                    ("stats_prev_page", "prev"),
                    ("stats_next_page", "next"),
                    ("open", "select"),
                ):
                    key = self._first_key(action)
                    if key:
                        parts.append(f"{label}={key}")
                self._help_text = "Keys: " + " | ".join(parts)
                help_bar.update(self._help_text)
            else:
                parts = []
                for action, label in (
                    ("quit", "quit"),
                    ("toggle_mode", "toggle"),
                    ("stats_heatmap", "heatmap"),
                    ("stats_list", "list"),
                    ("open", "select"),
                ):
                    key = self._first_key(action)
                    if key:
                        parts.append(f"{label}={key}")
                self._help_text = "Keys: " + " | ".join(parts)
                help_bar.update(self._help_text)


def run(config: AppConfig | None = None) -> None:
    app = TrailApp(config)
    app.run(mouse=True)
    print("Exited trail tui")
