from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .model import Event, Session, SourceConfig
from .tokens import load_tokenizer


def iter_sessions(source: SourceConfig) -> list[Session]:
    files = _collect_files(source)
    sessions: list[Session] = []
    legacy_entries: list[tuple[Session, list[str]]] = []
    for path in files:
        if path.suffix == ".json":
            session, sequence = _read_legacy_session(source, path)
            if session and sequence is not None:
                legacy_entries.append((session, sequence))
        else:
            session = _read_session(source, path)
            if session:
                sessions.append(session)
    sessions.extend(_dedupe_legacy_sessions(legacy_entries))
    sessions.sort(key=lambda s: s.started_at or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    return sessions


def _collect_files(source: SourceConfig) -> list[Path]:
    files: list[Path] = []
    for pattern in source.include:
        files.extend(sorted(source.path.glob(pattern)))
    return [p for p in files if p.is_file()]


def _read_legacy_session(
    source: SourceConfig, path: Path
) -> tuple[Session | None, list[str] | None]:
    raw_items, session_meta = _read_json_session(path)
    sequence = _legacy_sequence(raw_items, session_meta)
    session = _read_session_from_items(source, path, raw_items, session_meta)
    if session is None:
        return None, None
    if session.model is None:
        session.model = "codex (snapshot)"
    return session, sequence


def _read_session(source: SourceConfig, path: Path) -> Session | None:
    return _read_session_from_items(source, path, _read_jsonl(path), None)


def _read_session_from_items(
    source: SourceConfig,
    path: Path,
    raw_items: Iterable[dict[str, Any]],
    session_meta: dict[str, Any] | None,
) -> Session | None:
    events: list[Event] = []
    started_at: datetime | None = None
    session_started_at: datetime | None = None
    title: str | None = None
    model: str | None = None
    cwd: str | None = None
    session_usage: dict[str, Any] | None = None

    if session_meta:
        session_started_at = _parse_timestamp(session_meta)

    for raw in raw_items:
        if raw.get("type") == "session_meta":
            payload = raw.get("payload")
            if isinstance(payload, dict) and isinstance(payload.get("cwd"), str):
                cwd = payload["cwd"]
        if raw.get("type") == "event_msg":
            payload = raw.get("payload")
            if isinstance(payload, dict) and payload.get("type") == "token_count":
                info = payload.get("info")
                if isinstance(info, dict) and isinstance(info.get("total_token_usage"), dict):
                    session_usage = info["total_token_usage"]
        event = _normalize_event(source, path, raw)
        if event is None:
            continue
        events.append(event)
        if started_at is None and event.timestamp:
            started_at = event.timestamp
        if title is None and event.role == "user" and event.content:
            candidate = _title_candidate(event.content)
            if candidate:
                title = candidate
        if model is None:
            model = _extract_model(raw)

    if started_at is None:
        started_at = session_started_at

    if not events:
        return None

    usage = session_usage or _aggregate_usage(events)
    usage_estimate = _estimate_usage(events, model)

    session_id = _session_id_for_path(source, path)
    return Session(
        source=source.name,
        session_id=session_id,
        path=path,
        events=events,
        started_at=started_at,
        title=title,
        model=model,
        cwd=cwd,
        group_id=None,
        sub_id=None,
        usage=usage,
        usage_estimate=usage_estimate,
    )


def _read_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    yield json.loads(line)
                except json.JSONDecodeError:
                    continue
    except OSError:
        return


def _read_json_session(path: Path) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return [], None
    if not isinstance(data, dict):
        return [], None
    items = data.get("items")
    if not isinstance(items, list):
        return [], None
    session_meta = data.get("session")
    if not isinstance(session_meta, dict):
        session_meta = None
    return [item for item in items if isinstance(item, dict)], session_meta


def _legacy_sequence(
    items: list[dict[str, Any]], session_meta: dict[str, Any] | None
) -> list[str]:
    sequence: list[str] = []
    if isinstance(session_meta, dict):
        instructions = session_meta.get("instructions")
        if isinstance(instructions, str) and instructions.strip():
            token = _legacy_item_fingerprint(
                {"type": "session_instructions", "content": instructions}
            )
            if token:
                sequence.append(token)
    for item in items:
        token = _legacy_item_fingerprint(item)
        if token:
            sequence.append(token)
    return sequence


def _legacy_item_fingerprint(item: dict[str, Any]) -> str | None:
    hasher = hashlib.sha256()
    added = False

    def add(value: str) -> None:
        nonlocal added
        hasher.update(value.encode("utf-8", "ignore"))
        hasher.update(b"\0")
        added = True

    item_type = item.get("type")
    if isinstance(item_type, str):
        add(f"type:{item_type}")
    role = item.get("role")
    if isinstance(role, str):
        add(f"role:{role}")
    name = item.get("name")
    if isinstance(name, str):
        add(f"name:{name}")
    arguments = item.get("arguments")
    if isinstance(arguments, str):
        add(f"arguments:{arguments}")

    content = item.get("content")
    if isinstance(content, list):
        parts: list[str] = []
        for part in content:
            _append_content_part(parts, part)
        for text in parts:
            add(f"content:{text}")
    elif isinstance(content, str):
        add(f"content:{content}")

    summary = item.get("summary")
    if isinstance(summary, list):
        for entry in summary:
            if isinstance(entry, dict):
                text = entry.get("text") or entry.get("summary_text")
                if isinstance(text, str):
                    add(f"summary:{text}")

    output = item.get("output")
    if isinstance(output, str):
        add(f"output:{output}")

    if not added:
        return None
    return hasher.hexdigest()


def _dedupe_legacy_sessions(entries: list[tuple[Session, list[str]]]) -> list[Session]:
    by_day: dict[str, list[tuple[Session, list[str]]]] = {}
    for session, sequence in entries:
        day = session.started_at.date().isoformat() if session.started_at else "unknown"
        by_day.setdefault(day, []).append((session, sequence))

    survivors: list[Session] = []
    for group in by_day.values():
        survivors.extend(_dedupe_legacy_group(group))
    return survivors


def _dedupe_legacy_group(entries: list[tuple[Session, list[str]]]) -> list[Session]:
    by_sequence: dict[tuple[str, ...], Session] = {}
    for session, sequence in entries:
        key = tuple(sequence)
        existing = by_sequence.get(key)
        if existing is None or _ts_or_min(session.started_at) > _ts_or_min(existing.started_at):
            by_sequence[key] = session

    unique = [(session, list(seq)) for seq, session in by_sequence.items()]
    unique.sort(key=lambda item: (len(item[1]), _ts_or_min(item[0].started_at)))

    keep = [True] * len(unique)
    for idx, (session, sequence) in enumerate(unique):
        if not keep[idx]:
            continue
        for other_idx in range(idx + 1, len(unique)):
            other_session, other_sequence = unique[other_idx]
            if not session.started_at or not other_session.started_at:
                continue
            if _ts_or_min(other_session.started_at) < _ts_or_min(session.started_at):
                continue
            if _is_prefix(sequence, other_sequence):
                keep[idx] = False
                break
    return [unique[idx][0] for idx, keep_flag in enumerate(keep) if keep_flag]


def _is_prefix(prefix: list[str], full: list[str]) -> bool:
    if len(prefix) > len(full):
        return False
    return full[: len(prefix)] == prefix


def _normalize_event(source: SourceConfig, path: Path, raw: dict[str, Any]) -> Event | None:
    timestamp = _parse_timestamp(raw)
    event_type = raw.get("type") or raw.get("event_type") or raw.get("kind")
    role = _extract_role(raw)
    content = _extract_content(raw)
    usage = _extract_usage(raw)
    meta = _extract_meta(raw, path)
    tool = _extract_tool(raw)

    session_id = _session_id_for_path(source, path)
    return Event(
        source=source.name,
        session_id=session_id,
        timestamp=timestamp,
        event_type=event_type,
        role=role,
        content=content,
        usage=usage,
        meta=meta,
        tool=tool,
    )


def _session_id_for_path(source: SourceConfig, path: Path) -> str:
    try:
        return str(path.relative_to(source.path))
    except ValueError:
        return str(path)


def _title_candidate(content: str) -> str | None:
    text = content.strip()
    if not text:
        return None
    first_line = text.splitlines()[0].strip()
    if first_line.startswith("# AGENTS.md instructions"):
        return None
    if first_line.startswith("<environment_context"):
        return None
    return first_line[:120]


def _parse_timestamp(raw: dict[str, Any]) -> datetime | None:
    for key in ("timestamp", "time", "created_at", "created"):
        if key in raw:
            value = raw.get(key)
            if isinstance(value, (int, float)):
                return datetime.fromtimestamp(value, tz=timezone.utc)
            if isinstance(value, str):
                try:
                    return datetime.fromisoformat(value.replace("Z", "+00:00"))
                except ValueError:
                    continue
    return None


def _extract_role(raw: dict[str, Any]) -> str | None:
    if isinstance(raw.get("role"), str):
        return raw["role"]
    payload = raw.get("payload")
    if isinstance(payload, dict) and isinstance(payload.get("role"), str):
        return payload["role"]
    if isinstance(payload, dict) and isinstance(payload.get("type"), str):
        if payload["type"] == "user_message":
            return "user"
        if payload["type"] == "assistant_message":
            return "assistant"
    message = raw.get("message")
    if isinstance(message, dict) and isinstance(message.get("role"), str):
        return message["role"]
    if isinstance(payload, dict):
        message = payload.get("message")
        if isinstance(message, dict) and isinstance(message.get("role"), str):
            return message["role"]
    return None


def _extract_content(raw: dict[str, Any]) -> str | None:
    if isinstance(raw.get("content"), str):
        return raw["content"]
    if isinstance(raw.get("content"), list):
        parts: list[str] = []
        for item in raw["content"]:
            _append_content_part(parts, item)
        if parts:
            return "\n".join(parts)
    payload = raw.get("payload")
    if isinstance(payload, dict):
        content = payload.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for item in content:
                _append_content_part(parts, item)
            if parts:
                return "\n".join(parts)
        if isinstance(payload.get("message"), str):
            return payload["message"]
    message = raw.get("message")
    if isinstance(message, dict):
        content = message.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for item in content:
                _append_content_part(parts, item)
            if parts:
                return "\n".join(parts)
    if isinstance(payload, dict):
        message = payload.get("message")
        if isinstance(message, dict):
            content = message.get("content")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                parts: list[str] = []
                for item in content:
                    _append_content_part(parts, item)
                if parts:
                    return "\n".join(parts)
    return None


def _append_content_part(parts: list[str], item: Any) -> None:
    if isinstance(item, str):
        parts.append(item)
        return
    if not isinstance(item, dict):
        return
    text = item.get("text") or item.get("content")
    if isinstance(text, str):
        parts.append(text)
        return
    if item.get("type") in {"input_text", "output_text"} and isinstance(item.get("text"), str):
        parts.append(item["text"])


def _ts_or_min(value: datetime | None) -> datetime:
    if value is None:
        return datetime.min.replace(tzinfo=timezone.utc)
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value


def _extract_tool(raw: dict[str, Any]) -> dict[str, Any]:
    tool = {}
    if "tool" in raw and isinstance(raw["tool"], dict):
        tool = raw["tool"].copy()
    elif "tool_call" in raw and isinstance(raw["tool_call"], dict):
        tool = raw["tool_call"].copy()
    return tool


def _extract_usage(raw: dict[str, Any]) -> dict[str, Any]:
    usage = raw.get("usage")
    if isinstance(usage, dict):
        return usage
    payload = raw.get("payload")
    if isinstance(payload, dict) and isinstance(payload.get("usage"), dict):
        return payload["usage"]
    if raw.get("type") == "event_msg" and isinstance(payload, dict):
        if payload.get("type") == "token_count" and isinstance(payload.get("info"), dict):
            info = payload["info"]
            if isinstance(info.get("total_token_usage"), dict):
                return info["total_token_usage"]
            if isinstance(info.get("last_token_usage"), dict):
                return info["last_token_usage"]
    return {}


def _extract_model(raw: dict[str, Any]) -> str | None:
    if isinstance(raw.get("model"), str):
        return raw["model"]
    meta = raw.get("meta")
    if isinstance(meta, dict) and isinstance(meta.get("model"), str):
        return meta["model"]
    payload = raw.get("payload")
    if isinstance(payload, dict) and isinstance(payload.get("model"), str):
        return payload["model"]
    return None


def _extract_meta(raw: dict[str, Any], path: Path) -> dict[str, Any]:
    meta: dict[str, Any] = {}
    if isinstance(raw.get("meta"), dict):
        meta.update(raw["meta"])
    meta.setdefault("path", str(path))
    return meta


def _aggregate_usage(events: list[Event]) -> dict[str, Any]:
    totals = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    found = False
    for event in events:
        usage = event.usage
        if not usage:
            continue
        found = True
        input_tokens = usage.get("input_tokens") or usage.get("prompt_tokens")
        output_tokens = usage.get("output_tokens") or usage.get("completion_tokens")
        total_tokens = usage.get("total_tokens")
        if isinstance(input_tokens, int):
            totals["input_tokens"] += input_tokens
        if isinstance(output_tokens, int):
            totals["output_tokens"] += output_tokens
        if isinstance(total_tokens, int):
            totals["total_tokens"] += total_tokens
    if not found:
        return {}
    if totals["total_tokens"] == 0 and (totals["input_tokens"] or totals["output_tokens"]):
        totals["total_tokens"] = totals["input_tokens"] + totals["output_tokens"]
    return totals


def _estimate_usage(events: list[Event], model: str | None) -> dict[str, Any]:
    tokenizer = load_tokenizer(model)
    if tokenizer is None:
        return {"available": False, "reason": "tokenizer_unavailable"}

    input_tokens = 0
    output_tokens = 0
    for event in events:
        if not event.content:
            continue
        tokens = tokenizer.count(event.content)
        if event.role == "user":
            input_tokens += tokens
        elif event.role == "assistant":
            output_tokens += tokens
    return {
        "available": True,
        "tokenizer": tokenizer.name,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": input_tokens + output_tokens,
    }
