from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .model import Event, Session, SourceConfig
from .tokens import load_tokenizer


def iter_sessions(source: SourceConfig) -> list[Session]:
    files = _collect_files(source)
    sessions: list[Session] = []
    for path in files:
        session = _read_session(source, path)
        if session:
            sessions.append(session)
    sessions.sort(key=lambda s: s.started_at or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    return sessions


def _collect_files(source: SourceConfig) -> list[Path]:
    files: list[Path] = []
    for pattern in source.include:
        files.extend(sorted(source.path.glob(pattern)))
    # De-dupe when globs overlap (e.g., projects/**/*.jsonl + agent-*.jsonl)
    unique = {p.resolve() for p in files if p.is_file()}
    return sorted(unique)


def _read_session(source: SourceConfig, path: Path) -> Session | None:
    events: list[Event] = []
    started_at: datetime | None = None
    title: str | None = None
    model: str | None = None
    cwd: str | None = None
    group_id: str | None = None

    for raw in _read_jsonl(path):
        event = _normalize_event(source, path, raw)
        if event is None:
            continue
        events.append(event)
        if started_at is None and event.timestamp:
            started_at = event.timestamp
        if title is None and event.role == "user" and event.content:
            candidate = _title_candidate(event.content)
            if candidate:
                title = candidate
        if model is None:
            model = _extract_model(raw)
        if cwd is None:
            cwd = _extract_cwd(raw)
        if group_id is None:
            group_id = _extract_session_id(raw)

    if not events:
        return None

    usage = _aggregate_usage(events)
    usage_estimate = _estimate_usage(events, model)

    session_id = _session_id_for_path(source, path)
    return Session(
        source=source.name,
        session_id=session_id,
        path=path,
        events=events,
        started_at=started_at,
        title=title,
        model=model,
        cwd=cwd,
        group_id=group_id,
        sub_id=path.stem,
        usage=usage,
        usage_estimate=usage_estimate,
    )


def _read_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    yield json.loads(line)
                except json.JSONDecodeError:
                    continue
    except OSError:
        return


def _normalize_event(source: SourceConfig, path: Path, raw: dict[str, Any]) -> Event | None:
    event_type = raw.get("type")
    if event_type in {"file-history-snapshot"}:
        return None
    timestamp = _parse_timestamp(raw)
    usage = _extract_usage(raw)
    role = _extract_role(raw)
    content = _extract_content(raw)
    if role is None and content is None and not usage:
        return None
    meta = _extract_meta(raw, path)
    tool = _extract_tool(raw)

    session_id = _session_id_for_path(source, path)
    return Event(
        source=source.name,
        session_id=session_id,
        timestamp=timestamp,
        event_type=event_type,
        role=role,
        content=content,
        usage=usage,
        meta=meta,
        tool=tool,
    )


def _session_id_for_path(source: SourceConfig, path: Path) -> str:
    try:
        return str(path.relative_to(source.path))
    except ValueError:
        return str(path)


def _parse_timestamp(raw: dict[str, Any]) -> datetime | None:
    value = raw.get("timestamp")
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    return None


def _extract_role(raw: dict[str, Any]) -> str | None:
    if raw.get("type") in {"user", "assistant"}:
        return raw.get("type")
    message = raw.get("message")
    if isinstance(message, dict) and isinstance(message.get("role"), str):
        return message["role"]
    return None


def _extract_content(raw: dict[str, Any]) -> str | None:
    message = raw.get("message")
    if isinstance(message, dict):
        content = message.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts: list[str] = []
            for item in content:
                if isinstance(item, dict):
                    if item.get("type") == "text" and isinstance(item.get("text"), str):
                        parts.append(item["text"])
                    elif item.get("type") == "thinking" and isinstance(item.get("thinking"), str):
                        parts.append(item["thinking"])
                    elif item.get("type") == "tool_use":
                        name = item.get("name")
                        if isinstance(name, str):
                            parts.append(f"[tool_use] {name}")
            if parts:
                return "\n".join(parts)
    return None


def _extract_tool(raw: dict[str, Any]) -> dict[str, Any]:
    message = raw.get("message")
    if isinstance(message, dict) and isinstance(message.get("content"), list):
        for item in message["content"]:
            if isinstance(item, dict) and item.get("type") == "tool_use":
                return item
    return {}


def _extract_usage(raw: dict[str, Any]) -> dict[str, Any]:
    message = raw.get("message")
    if isinstance(message, dict) and isinstance(message.get("usage"), dict):
        usage = message["usage"].copy()
        cache_create = usage.get("cache_creation_input_tokens")
        cache_read = usage.get("cache_read_input_tokens")
        input_tokens = usage.get("input_tokens")
        if isinstance(input_tokens, int) or isinstance(cache_create, int) or isinstance(cache_read, int):
            usage["input_tokens"] = (input_tokens or 0) + (cache_create or 0) + (cache_read or 0)
        if "total_tokens" not in usage and isinstance(usage.get("input_tokens"), int) and isinstance(
            usage.get("output_tokens"), int
        ):
            usage["total_tokens"] = usage["input_tokens"] + usage["output_tokens"]
        return usage
    return {}


def _extract_model(raw: dict[str, Any]) -> str | None:
    message = raw.get("message")
    if isinstance(message, dict) and isinstance(message.get("model"), str):
        return message["model"]
    return None


def _extract_cwd(raw: dict[str, Any]) -> str | None:
    value = raw.get("cwd")
    if isinstance(value, str):
        return value
    return None


def _extract_session_id(raw: dict[str, Any]) -> str | None:
    value = raw.get("sessionId")
    if isinstance(value, str):
        return value
    return None


def _extract_meta(raw: dict[str, Any], path: Path) -> dict[str, Any]:
    meta: dict[str, Any] = {}
    for key in ("gitBranch", "version", "userType", "sessionId"):
        if key in raw:
            meta[key] = raw.get(key)
    meta.setdefault("path", str(path))
    return meta


def _aggregate_usage(events: list[Event]) -> dict[str, Any]:
    totals = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
    found = False
    for event in events:
        usage = event.usage
        if not usage:
            continue
        found = True
        input_tokens = usage.get("input_tokens")
        output_tokens = usage.get("output_tokens")
        total_tokens = usage.get("total_tokens")
        if isinstance(input_tokens, int):
            totals["input_tokens"] += input_tokens
        if isinstance(output_tokens, int):
            totals["output_tokens"] += output_tokens
        if isinstance(total_tokens, int):
            totals["total_tokens"] += total_tokens
        else:
            if isinstance(input_tokens, int) or isinstance(output_tokens, int):
                totals["total_tokens"] += (input_tokens or 0) + (output_tokens or 0)
    return totals if found else {}


def _estimate_usage(events: list[Event], model: str | None) -> dict[str, Any]:
    tokenizer = load_tokenizer(model)
    if tokenizer is None:
        return {"available": False, "reason": "tokenizer_unavailable"}

    input_tokens = 0
    output_tokens = 0
    for event in events:
        if not event.content:
            continue
        tokens = tokenizer.count(event.content)
        if event.role == "user":
            input_tokens += tokens
        elif event.role == "assistant":
            output_tokens += tokens
    return {
        "available": True,
        "tokenizer": tokenizer.name,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": input_tokens + output_tokens,
    }


def _title_candidate(content: str) -> str | None:
    text = content.strip()
    if not text:
        return None
    first_line = text.splitlines()[0].strip()
    return first_line[:120]
