from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class SourceConfig:
    name: str
    kind: str
    path: Path
    include: list[str]


@dataclass
class Event:
    source: str
    session_id: str
    timestamp: datetime | None
    event_type: str | None
    role: str | None
    content: str | None
    usage: dict[str, Any] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)
    tool: dict[str, Any] = field(default_factory=dict)


@dataclass
class Session:
    source: str
    session_id: str
    path: Path
    events: list[Event]
    started_at: datetime | None
    title: str | None
    model: str | None
    cwd: str | None
    group_id: str | None = None
    sub_id: str | None = None
    usage: dict[str, Any] = field(default_factory=dict)
    usage_estimate: dict[str, Any] = field(default_factory=dict)
    todos: list[TodoItem] = field(default_factory=list)


@dataclass
class TodoItem:
    content: str
    status: str  # "pending" | "completed"
    priority: str  # "high" | "medium" | "low"
    id: str


@dataclass
class TodoSnapshot:
    session_id: str
    path: Path
    items: list[TodoItem]
    modified_at: datetime | None = None  # File modification time
    has_session: bool = False  # Set after JOIN with sessions
