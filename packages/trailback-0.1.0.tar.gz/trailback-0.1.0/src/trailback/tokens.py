from __future__ import annotations

from dataclasses import dataclass
from typing import Callable


@dataclass(frozen=True)
class Tokenizer:
    name: str
    count: Callable[[str], int]


def load_tokenizer(model: str | None) -> Tokenizer | None:
    try:
        import tiktoken
    except Exception:
        return None

    enc = None
    if model:
        try:
            enc = tiktoken.encoding_for_model(model)
        except Exception:
            enc = None
    if enc is None:
        enc = tiktoken.get_encoding("cl100k_base")

    def _count(text: str) -> int:
        return len(enc.encode(text))

    return Tokenizer(name=getattr(enc, "name", "cl100k_base"), count=_count)
