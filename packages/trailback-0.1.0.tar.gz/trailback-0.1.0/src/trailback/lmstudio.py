from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .model import Event, Session, SourceConfig
from .tokens import load_tokenizer


def iter_sessions(source: SourceConfig) -> list[Session]:
    files = _collect_files(source)
    sessions: list[Session] = []
    for path in files:
        session = _read_session(source, path)
        if session:
            sessions.append(session)
    sessions.sort(key=lambda s: s.started_at or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    return sessions


def _collect_files(source: SourceConfig) -> list[Path]:
    files: list[Path] = []
    for pattern in source.include:
        files.extend(sorted(source.path.glob(pattern)))
    unique = {p.resolve() for p in files if p.is_file()}
    return sorted(unique)


def _read_session(source: SourceConfig, path: Path) -> Session | None:
    data = _read_json(path)
    if not isinstance(data, dict):
        return None
    messages = data.get("messages")
    if not isinstance(messages, list):
        return None

    session_id = _extract_session_id(path, source)
    events: list[Event] = []
    started_at = _parse_epoch_millis(data.get("createdAt"))
    title = data.get("name") if isinstance(data.get("name"), str) else None
    model = _extract_model(data)

    system_prompt = data.get("systemPrompt")
    if isinstance(system_prompt, str) and system_prompt.strip():
        events.append(
            Event(
                source=source.name,
                session_id=session_id,
                timestamp=None,
                event_type="system_prompt",
                role="system",
                content=system_prompt,
                usage={},
                meta={},
                tool={},
            )
        )

    for raw in messages:
        if not isinstance(raw, dict):
            continue
        version = _select_version(raw)
        if not isinstance(version, dict):
            continue
        role = _normalize_role(version.get("role"))
        content = _extract_version_content(version)
        event_type = version.get("type") if isinstance(version.get("type"), str) else None
        if role is None and content is None:
            continue
        events.append(
            Event(
                source=source.name,
                session_id=session_id,
                timestamp=None,
                event_type=event_type,
                role=role,
                content=content,
                usage={},
                meta={},
                tool={},
            )
        )
        if title is None and role == "user" and content:
            candidate = _title_candidate(content)
            if candidate:
                title = candidate

    if not events:
        return None

    usage = _extract_usage(data, messages)
    usage_estimate = _estimate_usage(events, model)

    return Session(
        source=source.name,
        session_id=session_id,
        path=path,
        events=events,
        started_at=started_at,
        title=title,
        model=model,
        cwd=None,
        group_id=None,
        sub_id=None,
        usage=usage,
        usage_estimate=usage_estimate,
    )


def _read_json(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None


def _select_version(raw: dict[str, Any]) -> dict[str, Any] | None:
    versions = raw.get("versions")
    if not isinstance(versions, list) or not versions:
        return None
    selected = raw.get("currentlySelected")
    if isinstance(selected, int) and 0 <= selected < len(versions):
        version = versions[selected]
        return version if isinstance(version, dict) else None
    last = versions[-1]
    return last if isinstance(last, dict) else None


def _extract_version_content(version: dict[str, Any]) -> str | None:
    version_type = version.get("type")
    if version_type == "singleStep":
        return _content_from_parts(version.get("content"))
    if version_type == "multiStep":
        parts: list[str] = []
        steps = version.get("steps")
        if not isinstance(steps, list):
            return None
        for step in steps:
            if not isinstance(step, dict):
                continue
            if step.get("type") != "contentBlock":
                continue
            style = step.get("style")
            if isinstance(style, dict) and style.get("type") == "thinking":
                continue
            block_text = _content_from_parts(step.get("content"))
            if block_text:
                parts.append(block_text)
        return "\n".join(parts) if parts else None
    return None


def _content_from_parts(value: Any) -> str | None:
    if not isinstance(value, list):
        return None
    parts: list[str] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        if item.get("type") != "text":
            continue
        if item.get("isStructural") is True:
            continue
        text = item.get("text")
        if isinstance(text, str) and text:
            parts.append(text)
    if not parts:
        return None
    return "\n".join(parts)


def _extract_session_id(path: Path, source: SourceConfig) -> str:
    try:
        return str(path.relative_to(source.path))
    except ValueError:
        return str(path)


def _normalize_role(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    lowered = value.lower()
    if lowered in {"user", "assistant", "system"}:
        return lowered
    return None


def _parse_epoch_millis(value: Any) -> datetime | None:
    if isinstance(value, (int, float)):
        try:
            return datetime.fromtimestamp(value / 1000, tz=timezone.utc)
        except (OSError, OverflowError):
            return None
    return None


def _extract_model(data: dict[str, Any]) -> str | None:
    last_used = data.get("lastUsedModel")
    if isinstance(last_used, dict):
        for key in ("identifier", "indexedModelIdentifier", "id", "modelId"):
            value = last_used.get(key)
            if isinstance(value, str) and value:
                return value
    return None


def _extract_usage(data: dict[str, Any], messages: list[Any]) -> dict[str, Any]:
    token_count = data.get("tokenCount")
    output_sum = 0
    max_prompt = None
    max_total = None

    for raw in messages:
        if not isinstance(raw, dict):
            continue
        version = _select_version(raw)
        if not isinstance(version, dict):
            continue
        for stats in _iter_gen_stats(version):
            prompt = stats.get("promptTokensCount")
            predicted = stats.get("predictedTokensCount")
            total = stats.get("totalTokensCount")
            if isinstance(prompt, int):
                max_prompt = prompt if max_prompt is None else max(max_prompt, prompt)
            if isinstance(predicted, int):
                output_sum += predicted
            if isinstance(total, int):
                max_total = total if max_total is None else max(max_total, total)

    input_tokens = None
    output_tokens = None
    total_tokens = None

    has_reported_total = isinstance(token_count, int)
    if has_reported_total:
        total_tokens = token_count
        if max_total is not None and abs(token_count - max_total) <= 2 and max_prompt is not None:
            input_tokens = max_prompt
            if total_tokens >= input_tokens:
                output_tokens = total_tokens - input_tokens
    elif max_prompt is not None:
        input_tokens = max_prompt

    if output_tokens is None and output_sum > 0 and not has_reported_total:
        if total_tokens is None:
            output_tokens = output_sum
        elif input_tokens is None and output_sum <= total_tokens:
            output_tokens = output_sum

    if total_tokens is None:
        if input_tokens is not None and output_tokens is not None:
            total_tokens = input_tokens + output_tokens
        elif input_tokens is not None:
            total_tokens = input_tokens
        elif output_tokens is not None:
            total_tokens = output_tokens

    usage: dict[str, Any] = {}
    if isinstance(input_tokens, int):
        usage["input_tokens"] = input_tokens
    if isinstance(output_tokens, int):
        usage["output_tokens"] = output_tokens
    if isinstance(total_tokens, int):
        usage["total_tokens"] = total_tokens
    return usage


def _iter_gen_stats(version: dict[str, Any]) -> list[dict[str, Any]]:
    stats_list: list[dict[str, Any]] = []
    gen_info = version.get("genInfo")
    if isinstance(gen_info, dict):
        stats = gen_info.get("stats")
        if isinstance(stats, dict):
            stats_list.append(stats)
    steps = version.get("steps")
    if isinstance(steps, list):
        for step in steps:
            if not isinstance(step, dict):
                continue
            gen_info = step.get("genInfo")
            if not isinstance(gen_info, dict):
                continue
            stats = gen_info.get("stats")
            if isinstance(stats, dict):
                stats_list.append(stats)
    return stats_list


def _estimate_usage(events: list[Event], model: str | None) -> dict[str, Any]:
    tokenizer = load_tokenizer(model)
    if tokenizer is None:
        return {"available": False, "reason": "tokenizer_unavailable"}

    input_tokens = 0
    output_tokens = 0
    for event in events:
        if not event.content:
            continue
        tokens = tokenizer.count(event.content)
        if event.role == "user":
            input_tokens += tokens
        elif event.role == "assistant":
            output_tokens += tokens
    return {
        "available": True,
        "tokenizer": tokenizer.name,
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "total_tokens": input_tokens + output_tokens,
    }


def _title_candidate(content: str) -> str | None:
    text = content.strip()
    if not text:
        return None
    first_line = text.splitlines()[0].strip()
    return first_line[:120]
