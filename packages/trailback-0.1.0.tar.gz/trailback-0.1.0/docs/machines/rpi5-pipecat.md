# rpi5-pipecat

Raspberry Pi 5 running as a secondary sync machine.

## Machine Info

- **Hostname**: rpi5-pipecat
- **Tailscale IP**: 100.91.146.46
- **OS**: Raspberry Pi OS (Linux)
- **User**: pipecat
- **Primary**: manganese-m4m (100.91.68.70)

## Sync Setup

**SSH key**: `~/.ssh/id_ed25519_trailsync`

**SSH config** (`~/.ssh/config`):
```
Host trail-primary
  HostName 100.91.68.70
  User vr000m
  IdentityFile ~/.ssh/id_ed25519_trailsync
  IdentitiesOnly yes
```

**Crontab** (`crontab -l`):
```
# Trail sync - run every 6 hours
0 */6 * * * PRIMARY_USER=vr000m PRIMARY_HOST=trail-primary SSH_OPTS="-i /home/pipecat/.ssh/id_ed25519_trailsync -o StrictHostKeyChecking=accept-new" /home/pipecat/Code/tinkerbox/trail-code-cli/scripts/sync-logs.sh >> /home/pipecat/.local/log/trail-sync.log 2>&1
```

**Sync log**: `~/.local/log/trail-sync.log`

## Useful Commands

```bash
# Manual sync
PRIMARY_USER=vr000m PRIMARY_HOST=trail-primary \
  SSH_OPTS="-i ~/.ssh/id_ed25519_trailsync" \
  /home/pipecat/Code/tinkerbox/trail-code-cli/scripts/sync-logs.sh

# Dry-run sync
DRY_RUN=1 VERBOSE=1 PRIMARY_USER=vr000m PRIMARY_HOST=trail-primary \
  SSH_OPTS="-i ~/.ssh/id_ed25519_trailsync" \
  /home/pipecat/Code/tinkerbox/trail-code-cli/scripts/sync-logs.sh

# Check sync log
tail ~/.local/log/trail-sync.log

# Verify cron
crontab -l | grep trail
```

## Setup Date

2025-01-11
