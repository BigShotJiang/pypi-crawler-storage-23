# Log Sync Design

This repo includes a simple, local-first sync strategy for merging Codex,
Claude, and Gemini logs across multiple machines without a central database.

## Goals

- Keep raw logs local; avoid cloud ingestion.
- Prefer append-only sync for JSONL logs.
- Avoid copying in-progress files that are still being written.
- Keep the solution simple: rsync over SSH (Tailscale/MagicDNS supported).

## Data characteristics

- Codex and Claude sessions are append-only JSONL. Safe to sync by appending,
  as long as we avoid files that are still being written.
- Gemini session files are single JSON documents that are rewritten as the
  session progresses. These must be copied only after a quiet window.

## Sync strategy

- One-way sync from secondary -> primary. This avoids merge conflicts and keeps
  the primary machine as the canonical store.
- Use rsync over SSH. If Tailscale is enabled, MagicDNS or the Tailscale IP
  address can be used without opening public ports.
- Apply a quiet window (default 60 minutes) so in-progress files are skipped.
  This is intentional: long-running sessions only sync once they have been
  idle for the quiet window.

## Implementation notes

The sync wrapper lives at:

```
scripts/sync-logs.sh
```

Key behaviors:

- Uses `find -mmin` to select files older than the quiet window.
- Syncs Codex and Claude JSONL with rsync append mode.
- Syncs Gemini `session-*.json` and `logs.json` only after the quiet window.
- Uses SSH; authentication should be handled via key-based auth.

Environment variables:

- `PRIMARY_HOST` (default: `100.91.68.70`)
- `PRIMARY_USER` (default: `$USER`)
- `MIN_AGE_MINUTES` (default: `60`)
- `RSYNC_BIN` (default: `rsync`)
- `SSH_OPTS` (default: empty; passed to `ssh` and `rsync -e`)
- `DRY_RUN` (set `1` for dry-run)
- `VERBOSE` (set `1` for verbose rsync output)

For a LaunchAgent, set `SSH_OPTS` in the plist `EnvironmentVariables` to pass
extra SSH flags without editing the script.

## Why not a database?

It is possible to ingest logs into SQLite or another database, but this adds
centralization, schema drift, and a second data pipeline. The log sync keeps
the system local-first and uses the native log formats directly.
