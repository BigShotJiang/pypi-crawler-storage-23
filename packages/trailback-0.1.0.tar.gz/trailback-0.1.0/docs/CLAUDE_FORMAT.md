# Claude Formats

This document captures on-disk layout and JSONL schema details observed in Claude Code v2.0.x.

## Directory structure

```
~/.claude/
├── projects/                      # Session transcripts (current format)
│   └── -Users-username-path.../   # Escaped project path as directory name
│       ├── <uuid>.jsonl           # Main session files
│       └── agent-<hash>.jsonl     # Agent/subagent session files
├── todos/                         # Todo snapshots (JSON, not JSONL)
│   └── <uuid>-agent-<uuid>.json   # JSON arrays with todo items
├── history.jsonl                  # Command/prompt history
├── debug/                         # Debug logs (.txt files)
├── plans/                         # Plan data (currently empty)
├── session-env/                   # Session environment snapshots
├── shell-snapshots/               # Shell environment snapshots
├── settings.json                  # User settings
├── statsig/                       # Feature flag cache
├── local/                         # Local installation (npm package)
├── plugins/                       # Plugin data and marketplaces
└── ide/                           # IDE integration data
```

Root-level files:
- `~/.claude.json` - Project metadata (allowed tools, MCP servers, onboarding state)

## Session JSONL format

Each line is a JSON object:

```json
{
  "type": "user" | "assistant",
  "parentUuid": "<uuid>",
  "isSidechain": false,
  "userType": "external",
  "cwd": "/path/to/project",
  "sessionId": "<uuid>",
  "version": "2.0.76",
  "gitBranch": "main",
  "message": {
    "role": "user" | "assistant",
    "content": "string" | [{"type": "text", "text": "..."}, ...],
    "model": "claude-sonnet-4-5-20250929",
    "usage": {
      "input_tokens": 1234,
      "output_tokens": 5678,
      "cache_creation_input_tokens": 0,
      "cache_read_input_tokens": 0
    }
  },
  "uuid": "<uuid>",
  "timestamp": "2026-01-01T18:26:23.403Z"
}
```

Agent sessions include additional fields:
- `agentId`: Short hash identifying the agent
- `isSidechain`: true for agent sessions

Special event types:
- `type: "summary"` - Session summary with `leafUuid`
- `type: "file-history-snapshot"` - File tracking data (filtered out by Trail)

## Todos format (JSON, not JSONL)

Files in `~/.claude/todos/` are JSON arrays:

```json
[
  {"content": "Task description", "status": "completed", "priority": "high", "id": "1"},
  {"content": "Another task", "status": "pending", "priority": "medium", "id": "2"}
]
```

File naming: `<sessionId>-agent-<sessionId>.json` or `<sessionId>.json`

## History format

`~/.claude/history.jsonl` stores command history:

```json
{"display": "user prompt text", "pastedContents": {}, "timestamp": 1767298415108, "project": "/path", "sessionId": "<uuid>"}
```

## Known issues / format changes

Missing old sessions (pre-Dec 2025):
- Observed: `todos/` files exist from May-Oct 2025, but corresponding session JSONL files are missing
- The `projects/` directory only contains recent sessions
- Hypothesis: Claude Code changed session storage format at some point
- Old sessions may have been stored differently (in memory, different location, or ephemeral)
- The todos were persisted separately and survived, but session transcripts did not

## Trail support

- Reads: `projects/**/*.jsonl`, `todos/*.json`
- Does NOT read: `history.jsonl`

## Notes

- JSONL messages store per-message usage; we sum usage across the session
- Multiple files may belong to the same session (grouped by `sessionId`)
- Agent sessions (`agent-*.jsonl`) are treated as subsessions of the main session
- Cache tokens (creation + read) are added to input_tokens for accurate totals
