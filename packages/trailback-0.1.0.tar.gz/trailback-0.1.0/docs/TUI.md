# TUI

## Overview
The Trail TUI provides an interactive view of sessions and usage stats.

Launch:

```
trail tui
```

Show TUI keybinds:

```
trail tui --help
```

## Keybind overrides

Optional file: `~/.config/trail/keybinds.toml`

Use `[bindings]` to override action keys (replaces defaults for that action).
If an action is present with an empty list, it disables that binding.

Example:

```
[bindings]
copy_transcript = ["y", "ctrl+shift+c"]
toggle_mode = ["m"]
focus_sessions = [","]
focus_transcript = ["."]
```

Notes:
- Comma/period/bracket keys can be written as literal characters in TOML lists.
  For period, you can also use `"full_stop"`.

## Default keybindings

- `quit`: `q`
- `open`: `enter` (also `e` toggles groups)
- `focus_next`: `tab`
- `focus_previous`: `shift+tab`
- `focus_sessions`: `s`
- `focus_transcript`: `t`
- `focus_filter`: `f`
- `focus_search`: `/`
- `show_sessions`: `1`, `ctrl+1`, `f1`
- `show_stats`: `2`, `ctrl+2`, `f2`
- `toggle_mode`: `m`
- `stats_heatmap`: `h`
- `stats_list`: `l`
- `stats_prev_page`: `[`
- `stats_next_page`: `]`
- `copy_transcript`: `y`, `ctrl+shift+c`

## Action names

`quit`, `open`, `focus_next`, `focus_previous`, `focus_sessions`, `focus_transcript`,
`focus_filter`, `focus_search`, `show_sessions`, `show_stats`, `toggle_mode`,
`stats_heatmap`, `stats_list`, `stats_prev_page`, `stats_next_page`, `copy_transcript`.
