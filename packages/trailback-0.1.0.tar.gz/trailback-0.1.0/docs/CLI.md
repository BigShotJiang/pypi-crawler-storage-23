# CLI

## Overview
Trail is a vendor-neutral CLI for browsing local agent logs. The MVP supports Codex, Claude, and Gemini logs.

## Commands

### TUI
Launch the TUI:

```
trail tui
```

TUI keybinds and customization live in `docs/TUI.md` (also see `trail tui --help`).

### Sources
List configured sources:

```
trail sources
```

Filter by kind:

```
trail sources --kind codex
```

### Init config
Create a default config file at `~/.config/trail/config.toml`:

```
trail init
```

Overwrite an existing file:

```
trail init --force
```

Example config for Claude (also included in `trail init`):

```
[sources.claude]
kind = "claude"
path = "~/.claude"
include = ["projects/**/*.jsonl"]
```

Example config for Gemini:

```
[sources.gemini]
kind = "gemini"
path = "~/.gemini"
include = ["tmp/*/chats/session-*.json", "tmp/*/logs.json"]
```

### Sessions list
List recent sessions (tab-separated):

```
trail ls
```

Hide cwd for screenshots:

```
trail ls --no-cwd
```

Limit results:

```
trail ls --limit 10
```

Show group/subsession ids (useful for Claude grouping):

```
trail ls --show-ids
```

Group related sessions (Claude sessionId; implies `--show-ids` and always includes `group_id`):

```
trail ls --group
```

Add a header row:

```
trail ls --header
```

Example output (redacted):

```
2025-12-24T05:10:20.146000+00:00	codex	sessions/2025/12/23/rollout-...jsonl	/Users/<user>/Code/project	gpt-5.2-codex	in=10140 out=32 total=10172	tok=cl100k_base in=12650 out=2079 total=14729
2025-12-20T20:52:34.892000+00:00	codex	sessions/2025/12/20/rollout-...jsonl	/Users/<user>/Code/project	gpt-5.2-codex	in=1238 out=1385 total=2623	tok=cl100k_base in=1238 out=1385 total=2623
```

### Open a session
Print a session transcript:

```
trail open <session_id>
```

Open a grouped Claude session (auto-detected):

```
trail open <group_id>
```

Example output (Codex - no todos):

```
codex	sessions/2025/12/11/rollout-...jsonl
started_at	2025-12-12T06:03:37.114000+00:00
cwd	/Users/<user>/Code/project
usage	tok=cl100k_base in=271 out=1610 total=1881

[user]
<environment_context>...

[user]
I bought a new computer
```

Example output (Claude with todos):

```
group_id	90100483-fe28-4cad-818b-bab8cbcd4212
sessions	4
models	claude-haiku-4-5-20251001, claude-opus-4-5-20251101
todos	6 items

[todos]
  ✓ Phase 1: Create todos adapter
  ✓ Phase 2: Add data models
  ○ Phase 3: Add CLI command

[user | agent-ab6339e]
Warmup

[assistant | agent-ab6339e]
I'm ready to help you...
```

Notes:
- For Claude sessions, todos are shown at the top if present
- Grouped sessions show merged transcript from all subsessions
- Codex sessions work unchanged (no todos)

### Todos
List todos from Claude sessions (reads `~/.claude/todos/*.json`):

```
trail todos
```

Only show orphaned todos (no corresponding session):

```
trail todos --orphaned
```

Filter by status:

```
trail todos --pending
trail todos --completed
```

Example output (summary format like `trail ls`):

```
2025-08-06T06:14:01  396fa0c0-...  [orphaned]  28 items (25✓ 3○)
2025-07-27T06:59:26  58e1cb47-...  [orphaned]  11 items (9✓ 2○)
2026-01-01T12:30:00  90100483-...             6 items (3✓ 3○)
```

Open a todo list with full details:

```
trail open --todo <session-id>
```

Example output:

```
session_id	396fa0c0-3f86-4b48-a4f1-fb34cef8bc1b
modified_at	2025-08-06T06:14:01.226954+00:00
file	396fa0c0-...-agent-396fa0c0-....json
items	28 (25✓ 3○) [orphaned]

[todos]
  ✓ Design system architecture [high]
  ✓ Implement backend processing
  ○ Add visualization tools [low]
```

If the session exists, the transcript is also shown after the todo list.

Notes:
- `[orphaned]` indicates todos without a corresponding session JSONL file
- Datetime is the file modification time (mtime)
- Status icons: ✓ completed, ○ pending
- Item count shows: `N items (X✓ Y○)`
- Empty todo files (`[]`) are filtered out
- Only reads from Claude sources (Codex has no todos)

### Stats
Show daily + monthly + yearly usage:

```
trail stats
```

Daily only:

```
trail stats --period daily
```

Monthly CSV for piping:

```
trail stats --period monthly --format csv --no-header
```

JSON output:

```
trail stats --format json
```

Example output:

```
Monthly usage
2025-06	reported in=0 out=0 total=0	estimated in=0 out=0 total=0	todos=33
2025-07	reported in=0 out=0 total=0	estimated in=0 out=0 total=0	todos=46
2025-10	reported in=101497 out=3603 total=105100	estimated in=245 out=173 total=418
2025-12	reported in=743114 out=11043 total=754157	estimated in=4838 out=5937 total=10775
```

Notes:
- `todos=N` shows orphaned todo item count for periods with no session transcripts
- This provides visibility into historical work where session files were lost

### TUI
Launch the TUI:

```
trail tui
```

Navigation:
- Use arrow keys to move in the sessions list.
- Press Enter to open a session.
- Press Tab / Shift+Tab to switch focus between panes.
- Press `s` to focus left pane, `t` to focus right pane.
- Press `f` to focus the session filter, `/` to focus transcript search (Sessions mode only).
- Press `1`/`2` for Sessions/Stats mode (use `Ctrl+1`/`Ctrl+2` or `F1`/`F2` if focus is in a text input).
- Press `m` to toggle modes.
- Claude groups expand/collapse on selection; `e` toggles group expansion.
- Scroll the transcript with arrow keys or PageUp/PageDown.

Stats mode:
- Daily view renders a two-tone heatmap with week rows and Mon–Sun columns.
  - Green: reported token usage
  - Purple: orphaned todos (days with todo activity but no session transcripts)
- Press `h` for heatmap and `l` for list.
- List shows only dates with usage or todos (newest first), 30 rows per page. Use `[` / `]` to page.
- Todos column shows orphaned todo item count.
- Monthly and yearly views use the same list layout with paging and todos.

List styling:
- Sessions show `date time  cwd  model`.
- CWD is color-coded (foreground) for quick visual grouping.
- Model is color-coded with a background tint by vendor family (OpenAI, Anthropic, Google, Other).

Todos in TUI:
- Sessions and groups with todos show a `📋 N` indicator in the list.
- Orphaned todos appear at the bottom of the session list with `[orphaned]` marker.
- Selecting a session/group shows todos at the top of the transcript pane.
- Selecting an orphaned todo shows the full todo list in the transcript pane.
- Format: status icons (✓/○), content, priority tags.

## Notes
- `trail ls` columns: started_at, source, session_id, cwd (hidden via `--no-cwd`), model, usage, usage_estimate.
- `usage` uses reported totals from on-disk provider metadata.
- `usage_estimate` uses tokenizer-based estimates.
- For Claude, cached input tokens are included in reported input totals when present.
- Timestamps are shown in UTC.
