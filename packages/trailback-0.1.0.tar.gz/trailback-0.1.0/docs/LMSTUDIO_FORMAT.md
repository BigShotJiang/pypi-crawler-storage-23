# LM Studio Formats

This document captures the on-disk layout and conversation JSON schema details
observed in LM Studio sessions.

## Directory structure

```
~/.lmstudio/
├── conversations/                 # Saved chats
│   └── <epoch>.conversation.json  # Conversation documents (epoch millis)
├── models/                        # Downloaded models
├── presets/                       # Config presets (if present)
├── server-logs/                   # Local server logs
└── user-files/                    # Uploaded files
```

Notes:
- Observed conversations use epoch-millis timestamps for filenames.
- Only the `conversations/` directory is currently relevant to Trail.

## Conversation JSON format

Each conversation file is a single JSON object with top-level metadata and a
`messages` array.

Top-level keys (observed):
- `name`: Human-friendly conversation title.
- `pinned`: Boolean pin state.
- `createdAt`: Epoch millis for creation time.
- `userLastMessagedAt`: Epoch millis for latest user message.
- `assistantLastMessagedAt`: Epoch millis for latest assistant message.
- `tokenCount`: Token count for the most recent generation (observed; not a session total).
- `systemPrompt`: String system prompt (empty if none).
- `messages`: Array of message entries (see below).
- `lastUsedModel`: Object describing the last model used (identifier fields).
- `usePerChatPredictionConfig`, `perChatPredictionConfig`: Prediction config.
- `clientInput`, `clientInputFiles`, `userFilesSizeBytes`: Client inputs/files.
- `notes`, `plugins`, `pluginConfigs`, `disabledPluginTools`, `looseFiles`.

### Message entries

Each entry in `messages` has:

```json
{
  "versions": [ ... ],
  "currentlySelected": 0
}
```

`versions` is a list of message versions; `currentlySelected` is the active
index.

### Version types

Observed version shapes:

#### `singleStep`

```json
{
  "type": "singleStep",
  "role": "user",
  "content": [
    { "type": "text", "text": "..." }
  ]
}
```

Notes:
- `role` is typically `user` or `assistant`.
- `content` is an array of content blocks. `text` is observed; other content
  types may exist (images, files, etc.).

#### `multiStep`

```json
{
  "type": "multiStep",
  "role": "assistant",
  "senderInfo": { "senderName": "model-id" },
  "steps": [ ... ]
}
```

`steps` entries are typed. Observed step types:

- `contentBlock`: contains `content` array (text blocks), optional `style`
  metadata (e.g. thinking), `prefix`/`suffix`, and optional `genInfo`.
- `debugInfoBlock`: contains `debugInfo` string.

Example `contentBlock` shape:

```json
{
  "type": "contentBlock",
  "stepIdentifier": "<id>",
  "content": [
    {
      "type": "text",
      "text": "...",
      "fromDraftModel": false,
      "tokensCount": 12,
      "isStructural": false
    }
  ],
  "defaultShouldIncludeInContext": true,
  "shouldIncludeInContext": true,
  "style": { "type": "thinking", "ended": true },
  "prefix": "<|channel|>analysis<|message|>",
  "suffix": "<|end|>"
}
```

`genInfo` (when present) includes model identifiers, prediction configs, and
generation stats (token counts, timings, stop reason).

Token notes:
- `genInfo.stats.promptTokensCount`, `predictedTokensCount`, and
  `totalTokensCount` appear to be per-generation counts (per assistant message),
  not cumulative session totals.
- The top-level `tokenCount` observed in conversations matches the latest
  generation `totalTokensCount` in sample files, suggesting it reflects the
  most recent generation rather than a session-wide total.

## Trail support

- CLI/TUI support: `lmstudio` source adapter.
- Read pattern: `~/.lmstudio/conversations/*.conversation.json`
 - Reported usage uses LM Studio's per-generation token counts; estimates use
   tokenizer-based session totals.
