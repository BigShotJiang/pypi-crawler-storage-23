# Codex Formats

This document captures on-disk layout and JSONL/JSON schema details observed in Codex sessions.

## Directory structure

```
~/.codex/
├── sessions/                      # Session transcripts
│   ├── YYYY/MM/DD/                # Current JSONL layout
│   │   └── rollout-<timestamp>-<uuid>.jsonl
│   └── rollout-<date>-<uuid>.json # Legacy JSON snapshots
├── shell_snapshots/               # Shell environment snapshots
├── skills/                        # Installed skills
├── log/                           # Logs
├── auth.json                      # Auth metadata
├── config.json                    # Config metadata
├── config.toml                    # User config
└── version.json                   # Version metadata
```

## Session JSONL format

Each line is a JSON object. Common record types:

```json
{"type":"session_meta","payload":{"cwd":"/path","...": "..."}}
{"type":"event_msg","payload":{"type":"token_count","info":{"total_token_usage":{"input_tokens":1,"output_tokens":2,"total_tokens":3}}}}
{"type":"message","role":"user","content":"..."}
```

Notes:
- `event_msg` + `token_count` reports cumulative totals; Trail uses the final total per session.
- Message content may appear in multiple shapes (string, list of content parts, payload/message nesting).

## Legacy JSON snapshots

Legacy files are a single JSON object with a `session` and `items` array:

```json
{
  "session": {
    "timestamp": "2025-09-13T00:43:56.190Z",
    "id": "<uuid>",
    "instructions": "..."
  },
  "items": [
    {"type":"message","role":"user","content":[{"type":"input_text","text":"..."}]},
    {"type":"reasoning","summary":[{"type":"summary_text","text":"..."}]},
    {"type":"function_call","name":"shell","arguments":"{...}"},
    {"type":"function_call_output","output":"{...}"}
  ]
}
```

Notes:
- Items do not include per-item timestamps.
- Trail uses the `session.timestamp` as the session start time.
- Legacy snapshots can be rollouts of the same session; Trail drops snapshots that are prefixes of later snapshots within the same day (by timestamp) and includes `session.instructions` in the signature.
- Trail labels legacy JSON sessions as `codex (snapshot)` when no model is present.

## Trail support

- Reads: `sessions/**/*.jsonl`, `sessions/**/*.json`
- Dedupes legacy JSON snapshots by prefix rule (newer snapshot wins).
