# gemini adapter

Start date: 2026-01-01
Updated date: 2026-01-01

## Summary
- Document Gemini CLI on-disk formats.
- Add Gemini sessions to Trail (CLI first, then TUI).

## Details
- Scope: docs + parser + CLI/TUI wiring.
- Provider: Gemini.
- Output: `trail ls/open/stats` and TUI list support.

## Work completed
- Captured Gemini layout + schema details in `docs/GEMINI_FORMAT.md`.
- Added Gemini source locations to `docs/SOURCES.md`.
- Implemented Gemini adapter and CLI wiring.
- Wired Gemini sessions into the TUI.

## Todo
- [ ] Validate stats against sample Gemini sessions.
- [ ] Confirm whether Gemini `tokens.total` is cumulative; adjust aggregation if needed.
- [ ] Decide whether to include `logs.json` by default (or make it opt-in).
