# codex parser and usage

Start date: 2025-10-19
Updated date: 2026-01-01

## Summary
- Build a Python CLI MVP that reads Codex JSONL sessions.
- Normalize events and compute usage (reported + estimated via tokenizer).
- Identify and fix schema mismatches in the Codex parser.

## Details
- Scope: CLI + minimal TUI.
- Provider: Codex.
- Output: `trail sources`, `trail ls`, `trail open`.

## Work completed
- Scaffolded Python project structure.
- Implemented config loading and Codex session scanning.
- Added usage aggregation and tokenizer-based estimation.
- Added docs tracking (architecture, decisions, todo).
- Extracted Codex `cwd` from session metadata for display.

## Experiments / changes
- Updated parser to read Codex `payload` fields, including `response_item` content lists and `event_msg` messages.
- Removed title column from `trail ls` to avoid leaking prompts in screenshots.
- Added `trail ls --no-cwd` for screenshot-safe output.
- Added per-model usage totals footer in `trail ls`.
- Added reported vs estimated totals per model and overall.
- Extract model from `turn_context` payloads and reported usage from `token_count` events.
- Use final `token_count.total_token_usage` as session reported usage (avoid summing cumulative totals).
- Added `trail stats` for daily and monthly usage totals (reported vs estimated).
- Added `trail stats --format csv|json` for exportable outputs.
- Updated README/docs with current CLI commands and stats outputs.
- Added `trail stats --period all|daily|monthly` to scope aggregation.
- Added `trail stats --period yearly` for annual rollups.
- Added `trail stats --format csv --no-header` for piping.
- Added `docs/CLI.md` with command examples.
- Added redacted example outputs to `docs/CLI.md`.
- Added initial TUI scaffold (`trail tui`) and documented it in CLI docs.
- Added TUI focus/navigation bindings and transcript scrolling.
- Added TUI footer and exit message on quit.
- Fixed TUI to respect CLI --config by passing resolved config into the app.
- Shortened TUI session timestamps to minute precision.
- Reordered TUI list label to date, cwd, model and added deterministic colors for cwd/model.
- Added vendor-tinted background colors for model labels and expanded cwd palette.
- CWD color now keys off the last path segment for better differentiation.
- Added a TUI stats mode with period list (daily/monthly/yearly) and top bar mode toggle.
- Added fallback keybindings for mode switch (Ctrl+1/2, F1/F2, m).
- Added daily stats heatmap in TUI (based on total tokens).
- Switched heatmap layout to week rows with Mon–Sun columns and ISO week labels.
- Made footer mode-specific and added ,/. pane focus shortcuts; removed stats-only g hint.
- Removed pane focus bindings for punctuation; kept `s`/`t`.
- Added daily stats list view with paging (`h`/`l`, `[`/`]`).
- Added table-style list views for monthly/yearly stats.
- Fixed token totals aggregation to include input/output-only sessions.
- Added initial Claude adapter and CLI/TUI wiring.
- Adjusted Claude usage to include cached input tokens.
- Removed Codex-only guards so Claude shows in ls/open/stats.
- De-duplicated Claude session files when glob patterns overlap.
- Added `trail init` to generate a default config file.
- Added Claude group/subsession IDs and TUI grouping with expand/collapse.
- Added CLI grouped listing and grouped open for Claude sessions.
- Made `trail open <group_id>` auto-detect and merge grouped sessions.
- Made `trail ls --group` imply `--show-ids` and always show `group_id`.
- Added TUI group expand/collapse on selection with `e` toggle.
- Preserve Claude usage-only events so token stats are not undercounted.
- Fixed timezone-aware sorting for grouped sessions and transcripts; group by (source, group_id).
- Documented UTC timestamps and doc-update process.

## Todo
- [x] Inspect real JSONL lines and adapt parser to match schema.
- [x] Verify `trail open` outputs transcript text.
- [x] Ensure token estimates are non-zero when content exists.
- [x] Update docs with any schema findings.
