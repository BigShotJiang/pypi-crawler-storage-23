# session layout audit

Start date: 2026-01-01
Updated date: 2026-01-01

## Summary
- Verify Codex/Claude session storage layouts across releases.
- Update defaults/docs to capture legacy Claude sessions.

## Details
- Scope: config defaults + docs.
- Providers: Codex, Claude.
- Output: updated include patterns, updated SOURCES/CLI/README.

## Work completed
- Audited local Codex/Claude layouts and confirmed current paths.
- Updated Claude default config include to add sessions globs.
- Added Codex support for legacy session JSON files and listed them in sources docs.
- Documented legacy Claude session layouts and flat Codex sessions.
- Deduplicated legacy Codex JSON rollouts by prefix rule with timestamps (keep latest superset).
- Included `session.instructions` in legacy snapshot equivalence.

## Todo
- [ ] Decide whether to ingest `~/.claude/history.jsonl`.
- [ ] Add a brief note about sparse metadata in early Codex sessions if needed.
