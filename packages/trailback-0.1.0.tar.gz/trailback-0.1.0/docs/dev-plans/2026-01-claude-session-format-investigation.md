# Claude Session Format Investigation

Start date: 2026-01-01
Updated date: 2026-01-01

## Summary

Investigated missing old Claude Code sessions and documented the ~/.claude directory structure.

## Problem Statement

User observed:
- `~/.claude/todos/` contains 65 files from May-Oct 2025
- `~/.claude/projects/` only contains recent sessions from Jan 2026
- Trail CLI/TUI only shows the latest sessions

## Findings

### Key Discovery: Old Session Transcripts Are Missing

The todos files exist as orphaned references to sessions that no longer have corresponding JSONL transcripts.

| Data | Date Range | Count | Status |
|------|------------|-------|--------|
| Todo snapshots | May 2025 - Oct 2025 | 65 files | Present |
| Session JSONL | Jan 2026 only | 9 files | Present |
| Old session JSONL | May-Oct 2025 | 0 files | **Missing** |

### Hypothesis: Claude Code Format Change

Evidence suggests Claude Code changed how sessions are stored:

1. **Todos persisted separately** - Written to `~/.claude/todos/<uuid>.json` independently
2. **Projects directory** - Contains session JSONL files organized by project path
3. **Old sessions not migrated** - When format changed, existing sessions were not preserved

### Current ~/.claude Structure Documented

See `docs/SOURCES.md` for complete documentation of:
- Directory structure
- Session JSONL format
- Todos format
- History format
- Known issues

## Current Trail Support

| Data Source | Format | Trail Support |
|-------------|--------|---------------|
| `projects/**/*.jsonl` | JSONL | Yes |
| `todos/*.json` | JSON arrays | **Yes** (implemented) |
| `history.jsonl` | JSONL | No |

## Implementation Completed

### Todos Support Added

Files created/modified:
- `src/trail/todos.py` (new) - Todos adapter to read `~/.claude/todos/*.json`
- `src/trail/model.py` - Added `TodoItem`, `TodoSnapshot` dataclasses
- `src/trail/cli.py` - Added `trail todos` command with filters
- `src/trail/tui.py` - Added todos display in session/group views
- `docs/CLI.md` - Updated with todos command documentation
- `docs/SOURCES.md` - Updated with todos format documentation

### Data Structures

**TodoItem** (model.py):
```python
@dataclass
class TodoItem:
    content: str      # Task description
    status: str       # "pending" | "completed"
    priority: str     # "high" | "medium" | "low"
    id: str           # Item ID within the todo list
```

**TodoSnapshot** (model.py):
```python
@dataclass
class TodoSnapshot:
    session_id: str           # Extracted from filename
    path: Path                # Full path to JSON file
    items: list[TodoItem]     # Parsed todo items
    has_session: bool = False # Set after JOIN with sessions
```

**Session.todos** field added:
```python
todos: list[TodoItem] = field(default_factory=list)
```

### Key Functions

**todos.py:**
- `iter_todos(source)` - Read all todo files from `~/.claude/todos/`
- `_read_todo_file(path)` - Parse JSON array, return None if empty/invalid
- `_parse_items(data)` - Convert JSON to TodoItem objects
- `_extract_session_id(path)` - Extract sessionId from filename patterns:
  - `<uuid>-agent-<uuid>.json` → first uuid
  - `<uuid>.json` → uuid

**cli.py:**
- `_cmd_todos()` - New command handler with orphaned/pending/completed filters
- `_cmd_open()` - Modified to load and pass todos to print functions
- `_print_transcript(session, todos)` - Show todos at top of transcript
- `_print_group_transcript(group_id, sessions, todos)` - Show todos for groups

**tui.py:**
- `TrailApp.todos_by_session` - Dict mapping sessionId to list of TodoItem
- `_load_sessions()` - Also loads todos for Claude sources
- `_render_session()` - Shows todos in transcript pane
- `_render_group()` - Shows todos for group view

### Design Decisions

1. **Todos as sibling entries** - Follows same pattern as agent sessions
   - Sessions grouped by `sessionId`
   - Todos matched by same `sessionId` from filename
   - Display alongside session data, not as separate entity

2. **JOIN strategy** - Load todos separately, join by sessionId
   - Avoids modifying core session loading
   - Allows orphaned todos to be displayed
   - Simple dict lookup: `todos_by_session[session_id]`

3. **Empty file handling** - Skip files containing only `[]`
   - Claude creates empty todo files for all sessions
   - Only show sessions that actually have todos

4. **Codex compatibility** - Todos only for Claude sources
   - Check `source.kind == "claude"` before loading todos
   - Codex sessions unaffected, no todos field populated

### Features

**CLI:**
- `trail todos` - List all todos grouped by session
- `trail todos --orphaned` - Only show todos without sessions
- `trail todos --pending` - Only show pending todos
- `trail todos --completed` - Only show completed todos
- `trail open <sessionId>` - Now shows todos at top of transcript

**TUI:**
- Session/group views show todos count and checklist
- Orphaned todos marked with `[session missing]`
- Status icons: ✓ completed, ○ pending
- Priority tags shown for high/low priority items

### Codex Compatibility
- Codex sessions continue to work unchanged
- Todos only loaded for Claude sources

## Work Completed

- [x] Explored ~/.claude directory structure
- [x] Identified missing session JSONL files issue
- [x] Documented session format in docs/SOURCES.md
- [x] Created this dev-plan
- [x] Implemented todos adapter (`src/trail/todos.py`)
- [x] Added data models (`TodoItem`, `TodoSnapshot`)
- [x] Added `trail todos` CLI command
- [x] Integrated todos with `trail open`
- [x] Added TUI todos display
- [x] Updated docs/CLI.md with todos command documentation
- [x] Updated this dev-plan with implementation details

## Testing

Commands verified working:
```bash
uv run trail todos                    # Lists all 65 orphaned todos
uv run trail todos --orphaned         # Same (all are orphaned)
uv run trail todos --pending          # Shows only pending items
uv run trail open <sessionId>         # Shows todos + transcript
uv run trail open <sessionId> --source codex  # Works, no todos
```

## Recent Updates (2026-01-01)

### Todos Display Fixes

**Issue 1: `trail todos` output format**
- Changed from verbose format to summary format (like `trail ls`)
- Added datetime (file mtime)
- Added `trail open --todo <session-id>` for full todo list + transcript

**Issue 2: TUI todos not showing**
- Added `TodoGroupItem` and `TodoGroupListItem` for orphaned todos
- Orphaned todos now appear at bottom of session list
- Added `📋 N` indicator to sessions/groups with todos
- Fixed key mismatch in todos lookup

**Issue 3: Stats should show orphaned todos activity**
- Added todo item count to stats (CLI and TUI)
- CLI: `todos=N` column in stats output
- TUI: Two-tone heatmap (green=tokens, purple=todos)
- TUI: Todos column in list views

**Files modified:**
- `src/trail/model.py` - Added `modified_at` field to `TodoSnapshot`
- `src/trail/todos.py` - Read file mtime
- `src/trail/cli.py` - Updated `_cmd_todos()` format, added `--todo` flag, added todos to stats
- `src/trail/tui.py` - Added orphaned todos support, todos indicators, two-tone heatmap
- `docs/CLI.md` - Updated documentation

## Next Steps

- [ ] Research Claude Code version history for storage changes
- [ ] Consider adding history.jsonl support
