# TODO

## Done
- ~~Fix Codex parser to match real JSONL schema (content extraction, roles, timestamps).~~
- ~~Verify token estimate counts after parser update.~~
- ~~Document CLI stats outputs (text/csv/json).~~
- ~~Validate Claude adapter against sample logs.~~
- ~~Add grouped CLI view for Claude sessions.~~
- ~~Polish TUI grouping behavior and document navigation.~~
- ~~Add minimal Textual TUI (session list + transcript view).~~
- ~~Add Claude adapter.~~
- ~~Add todos support (orphaned todos, stats integration).~~
- ~~Add Gemini adapter (CLI/TUI wiring + docs).~~

## Now
- Add `trail export` for JSON/Markdown.
- Add `trail grep` for searching across sessions.

## Later
- Add indexing with SQLite/DuckDB.
- Add cost estimation + model aliasing.
- Add attachments/tool-call rendering improvements.
- Add history.jsonl support.
- Verify Gemini token semantics (cumulative vs per-message totals).
- Decide whether `logs.json` should be included by default.
