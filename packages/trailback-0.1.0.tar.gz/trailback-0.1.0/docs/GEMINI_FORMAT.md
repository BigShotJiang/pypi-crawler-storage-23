# Gemini Formats

This document captures on-disk layout and JSON schema details observed in Gemini CLI sessions.

## Directory structure

```
~/.gemini/
├── tmp/
│   └── <projectHash>/
│       ├── chats/
│       │   └── session-YYYY-MM-DDTHH-MM-<hash>.json
│       └── logs.json
├── GEMINI.md
├── settings.json
├── installation_id
└── user_id
```

## Session JSON format

Each session file is a single JSON object:

```json
{
  "sessionId": "<uuid>",
  "projectHash": "<hash>",
  "startTime": "2025-09-25T06:22:04.818Z",
  "lastUpdated": "2025-09-25T10:18:41.218Z",
  "messages": [
    {
      "id": "<uuid>",
      "timestamp": "2025-09-25T06:22:04.818Z",
      "type": "user" | "gemini",
      "content": "...",
      "thoughts": [
        {"subject": "...", "description": "...", "timestamp": "..."}
      ],
      "tokens": {
        "input": 123,
        "output": 456,
        "cached": 0,
        "thoughts": 0,
        "tool": 0,
        "total": 579
      },
      "model": "gemini-2.5-pro"
    }
  ]
}
```

Notes:
- `messages` mixes user and model responses.
- `thoughts` appears on Gemini messages (array of subject/description/timestamp).
- `tokens` includes separate `input/output/cached/thoughts/tool/total` counts.

## Logs format

`logs.json` is an array of short records (often user-only):

```json
[
  {
    "sessionId": "<uuid>",
    "messageId": 0,
    "type": "user",
    "message": "...",
    "timestamp": "2025-09-13T16:21:19.575Z"
  }
]
```

Notes:
- Logs do not include assistant responses.
- Session files provide the full transcript and usage data.
- Trail labels log-only sessions as `gemini (logs)` in listings.
- Trail uses `tokens.input`, `tokens.output`, and `tokens.total` as reported; cached/thought/tool counts are stored in event metadata.

## Trail support

- Primary: `tmp/*/chats/session-*.json`
- Fallback: `tmp/*/logs.json` (if needed)
