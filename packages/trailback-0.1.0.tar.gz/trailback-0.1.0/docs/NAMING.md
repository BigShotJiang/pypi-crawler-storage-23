# Naming Discussion

## Context

When extracting `trail-code-cli` from the `tinkerbox` monorepo into its own
standalone project, we evaluated naming and domain options. The tool is a
vendor-neutral CLI/TUI for browsing local AI agent logs (Claude, Codex, Gemini,
LM Studio) — listing sessions, viewing transcripts, tracking usage stats, and
searching past conversations.

## Requirements

- Works as both a CLI command and a future Mac menu bar app
- Avoid names that are too CLI-specific (`.sh`, `-cli`) since the product may
  expand beyond the terminal
- Memorable, searchable, and descriptive of the core action: **reviewing past
  AI coding sessions**

## Names Considered

| Name | Pros | Cons |
|---|---|---|
| trail | Short, easy to type | Too generic, hard to search, could be anything |
| trail-cli | Clear for CLI | Doesn't fit a Mac app |
| trailcode | Ties to coding | "code" is redundant given the audience |
| codetrail | Sounds like a product | `.com` and `.dev` taken — trademark risk |
| trailview | Descriptive | Only `.dev` available |
| logtrail | Literal, clear | Slightly boring |
| retrail | Clever wordplay | Could be misread as "re-tail" |
| **trailback** | "Trail back through sessions" — verb-like, fits CLI + app | — |

## Domain Availability (checked 2025-03-01)

| Domain | Available | Price/yr |
|---|---|---|
| trailback.dev | Yes | $13 |
| trailback.app | Yes | $15 |
| trailcode.dev | Yes | $13 |
| trailcode.app | Yes | $15 |
| trailview.dev | Yes | $13 |
| logtrail.dev | Yes | $13 |
| codetrail.dev | No | — |
| codetrail.com | No | — |

## Decision

**trailback** — purchased `trailback.dev`.

Rationale: "Trail back through your AI coding sessions" captures the core use
case. Works equally well as a CLI command (`trailback ls`) and a Mac menu bar
app name. Both `.dev` and `.app` domains are available.

## TODO

- [x] Rename package from `trail` to `trailback`
- [x] Update CLI entry point, pyproject.toml, README
- [x] Set up GitHub repo at `vr000m/trailback`
- [ ] Point `trailback.dev` to landing page / docs

## CLI command

The CLI command remains `trail` (not `trailback`) — it's shorter, already used
in all docs and examples, and the config path stays `~/.config/trail/`. The
package name (`trailback`) is used for PyPI, the GitHub repo, and the domain.
