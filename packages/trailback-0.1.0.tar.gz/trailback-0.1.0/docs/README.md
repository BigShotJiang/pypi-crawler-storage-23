# Docs

This folder tracks architecture, decisions, and planned work for Trail.

- `ARCHITECTURE.md`: current architecture and layering
- `CLI.md`: command reference and examples
- `TUI.md`: TUI keybinds and customization
- `CODEX_FORMAT.md`: Codex on-disk layout and JSONL/JSON schema notes
- `DECISIONS.md`: key decisions and rationale
- `CLAUDE_FORMAT.md`: Claude on-disk layout and JSONL schema notes
- `GEMINI_FORMAT.md`: Gemini on-disk layout and session schema notes
- `LMSTUDIO_FORMAT.md`: LM Studio on-disk layout and conversation schema notes
- `SOURCES.md`: known on-disk layouts for supported providers
- `TODO.md`: near-term and long-term tasks
- `dev-plans/`: per-session dev notes with start date, summary, and checklists.
  Guardrails: once a dev-plan file is created, keep using the same filename (even if it has an old date).
  If a new session starts, either update the existing plan or create a new one after explicitly asking.
  Process: update docs and TODOs for each completed task so state stays current across sessions.

## CLI references
Core commands live in the repo README and should be kept current when CLI flags change.
