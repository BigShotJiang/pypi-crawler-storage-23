# Architecture

## Overview
Trail is a vendor-neutral CLI/TUI for browsing local agent logs. Providers are added via source adapters that normalize raw log entries into a shared event model.

## Current scope (MVP)
- Provider: Codex, Claude
- CLI: list sessions, open a session, usage stats
- Usage: aggregate usage from logs when present + estimate tokens via tokenizer

## Proposed layering
- cli.py: argument parsing and command handlers
- config.py: config loading with default sources
- codex.py: adapter for Codex JSONL sessions
- model.py: shared data structures
- tokens.py: tokenizer utilities

## Adapter responsibilities
- Read provider log files and normalize into Event objects
- Extract metadata: timestamps, role, content, model, usage
- Provide a stable Session view (title, started_at, usage totals)

## Future extensions
- Additional adapters: Claude, Gemini
- Indexing: SQLite/DuckDB for fast search
- Exporters: Markdown/HTML/JSON
- TUI: Textual, 2-3 pane explorer
