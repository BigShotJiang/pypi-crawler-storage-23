# Decisions

## Naming
- Goal: avoid provider-branded names.
- Binary name: `trail`.
- Repo name: `trail-code-cli` (current).

## Tech stack
- Language: Python (current).
- TUI: Textual (planned).

## Architecture
- Source adapters convert provider logs into a normalized event model.
- Config controls sources and paths; defaults to Codex in ~/.codex.

## Token usage
- Use usage metadata from logs when present.
- Always compute tokenizer-based estimates to validate against reported usage.
- For Gemini, use `tokens.input/output/total` as reported; cached/thought/tool counts are kept as metadata.

## Legacy Codex snapshots
- Deduplicate legacy Codex `.json` rollouts by dropping snapshots that are prefixes of later files (when the later file has a newer timestamp).
- Include `session.instructions` in the snapshot signature so instruction changes start a new chain.
