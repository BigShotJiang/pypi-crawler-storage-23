# Sources

This document records known on-disk layouts for supported sources. Paths and formats can vary between versions.

## Codex

Base path:
- `~/.codex`

Session logs:
- `~/.codex/sessions/rollout-*.json` (older flat layout)
- `~/.codex/sessions/rollout-*.jsonl` (older flat layout)
- `~/.codex/sessions/YYYY/MM/DD/rollout-*.jsonl`

Notes:
- JSONL event streams with mixed record types.
- Usage is reported via `event_msg` with `token_count` payloads (cumulative totals), so we take the final total per session.
- Legacy JSON sessions store a `session` object and an `items` array (no per-item timestamps).
- Detailed layout and schema notes live in `docs/CODEX_FORMAT.md`.

## Claude

Base path:
- `~/.claude`

Project logs:
- `~/.claude/projects/*/*.jsonl`
- Agent logs often appear as `agent-*.jsonl` within the same project directory.

Session logs (older layouts):
- `~/.claude/sessions/*.jsonl`
- `~/.claude/sessions/YYYY/MM/DD/*.jsonl`

Notes:
- JSONL messages store per-message usage; we sum usage across the session.
- Multiple files may belong to the same session (grouped by `sessionId`).
- Detailed layout and schema notes live in `docs/CLAUDE_FORMAT.md`.

## Gemini

Base path:
- `~/.gemini`

Session logs:
- `~/.gemini/tmp/*/chats/session-*.json`

Optional logs:
- `~/.gemini/tmp/*/logs.json`

Notes:
- Session files are full JSON documents (not JSONL).
- Detailed layout and schema notes live in `docs/GEMINI_FORMAT.md`.

## LM Studio

Base path:
- `~/.lmstudio`

Conversation logs:
- `~/.lmstudio/conversations/*.conversation.json`

Notes:
- Conversation files are full JSON documents (not JSONL).
- Token counts in LM Studio conversations appear to be per-generation (per assistant
  message); the top-level `tokenCount` matches the latest generation total in
  sample files rather than a session-wide cumulative total.
- Detailed layout and schema notes live in `docs/LMSTUDIO_FORMAT.md`.

## Usage aggregation notes

Trail distinguishes between:
- **Reported usage**: provider-reported token counts (as found on disk).
- **Estimated usage**: tokenizer-based totals computed from message text.

When a provider only exposes per-generation counts (not session totals), reported
usage may not reflect a full session; estimates are used to approximate session
totals for stats. Provider-specific details are documented in each `*_FORMAT.md`.
