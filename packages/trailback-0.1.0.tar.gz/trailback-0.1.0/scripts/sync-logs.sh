#!/usr/bin/env bash
set -euo pipefail

PRIMARY_HOST="${PRIMARY_HOST:-100.91.68.70}"
PRIMARY_USER="${PRIMARY_USER:-$USER}"
PRIMARY="${PRIMARY_USER}@${PRIMARY_HOST}"
RSYNC_BIN="${RSYNC_BIN:-rsync}"
SSH_OPTS="${SSH_OPTS:-}"

# Quiet window for in-progress sessions.
MIN_AGE_MINUTES="${MIN_AGE_MINUTES:-60}"
DRY_RUN="${DRY_RUN:-0}"
VERBOSE="${VERBOSE:-0}"
LOG_TIMESTAMP="${LOG_TIMESTAMP:-0}"

RSYNC_HELP="$("${RSYNC_BIN}" --help 2>/dev/null || true)"

rsync_supports() {
  printf '%s' "${RSYNC_HELP}" | grep -q -- "$1"
}

SSH_OPTS_ARR=()
if [[ -n "${SSH_OPTS}" ]]; then
  # shellcheck disable=SC2206
  SSH_OPTS_ARR=(${SSH_OPTS})
fi

RSYNC_SSH="ssh"
if [[ -n "${SSH_OPTS}" ]]; then
  RSYNC_SSH+=" ${SSH_OPTS}"
fi

timestamp_pipe() {
  awk '{ print strftime("[%Y-%m-%d %H:%M:%S]"), $0 }'
}

if [[ "${LOG_TIMESTAMP}" == "1" ]]; then
  exec > >(timestamp_pipe) 2> >(timestamp_pipe >&2)
fi

APPEND_FLAG="--append"
if rsync_supports '--append-verify'; then
  APPEND_FLAG="--append-verify"
fi

rsync_from_find() {
  local base="$1"
  local append_flag="${2:-}"
  shift 2
  if [[ ! -d "${base}" ]]; then
    return 0
  fi
  local -a flags
  flags=(-az)
  if [[ "${VERBOSE}" == "1" ]]; then
    flags+=(-v --itemize-changes)
  fi
  if [[ "${DRY_RUN}" == "1" ]]; then
    flags+=(--dry-run)
  fi
  if [[ -n "${append_flag}" ]]; then
    flags+=("${append_flag}")
  fi
  if [[ -n "${SSH_OPTS}" ]]; then
    flags+=(-e "${RSYNC_SSH}")
  fi
  find "${base}" -type f "$@" -mmin +"${MIN_AGE_MINUTES}" -print \
    | sed "s|^${HOME}/||" \
    | "${RSYNC_BIN}" "${flags[@]}" --files-from=- "${HOME}/" "${PRIMARY}:~/"
}

rsync_append_only() {
  local src="$1"
  rsync_from_find "${src}" "${APPEND_FLAG}"
}

rsync_quiet_json() {
  local base="$1"
  rsync_from_find "${base}" "" \( -name 'session-*.json' -o -name 'logs.json' \)
}

ssh -o BatchMode=yes -o ConnectTimeout=10 ${SSH_OPTS_ARR[@]+"${SSH_OPTS_ARR[@]}"} "${PRIMARY}" \
  "mkdir -p ~/.codex/sessions ~/.claude/projects ~/.claude/todos ~/.gemini/tmp"

rsync_append_only "${HOME}/.codex/sessions/"
rsync_append_only "${HOME}/.claude/projects/"
rsync_append_only "${HOME}/.claude/todos/"

rsync_quiet_json "${HOME}/.gemini/tmp"
