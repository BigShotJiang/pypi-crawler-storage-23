import json
from hnt_sap_financeiro.hnt_sap_gui import SapGui


def test_create():
    with open("./devdata/json/lancamento_taxa_FIN-60747.json", "r", encoding="utf-8") as payload_json: payload = json.load(payload_json)
    taxa = payload['payloads'][0]['taxa']
    result = SapGui().run_FV60(taxa)
    assert result['error'] is None
