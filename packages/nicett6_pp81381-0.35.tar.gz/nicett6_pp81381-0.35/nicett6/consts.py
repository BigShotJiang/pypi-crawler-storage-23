RCV_EOL = b"\r"
SEND_EOL = b"\r\n"
