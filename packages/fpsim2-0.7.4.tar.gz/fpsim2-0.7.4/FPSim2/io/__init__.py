from .backends.pytables import create_db_file

try:
    from .backends.sqla import create_db_table
except ImportError:
    create_db_table = None
