#pragma once

#include <cstdint>

struct Result {
    uint32_t idx;
    uint32_t mol_id;
    float coeff;
};
