from .main import parse, FastFeedParserDict

__version__ = "0.5.1"
__all__ = ["parse", "FastFeedParserDict"]
