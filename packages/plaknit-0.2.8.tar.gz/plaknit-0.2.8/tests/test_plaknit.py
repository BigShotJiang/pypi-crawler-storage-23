#!/usr/bin/env python

"""Tests for `plaknit` package."""

import unittest

from plaknit import plaknit


class TestPlaknit(unittest.TestCase):
    """Tests for `plaknit` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
