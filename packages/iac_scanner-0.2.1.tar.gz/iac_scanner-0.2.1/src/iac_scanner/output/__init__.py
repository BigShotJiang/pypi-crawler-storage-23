"""Output: report and fixed code files."""

from iac_scanner.output.report import write_report_and_fixes

__all__ = ["write_report_and_fixes"]
