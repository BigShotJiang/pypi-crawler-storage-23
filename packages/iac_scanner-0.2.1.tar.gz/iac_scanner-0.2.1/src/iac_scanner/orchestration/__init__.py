"""LangChain orchestration - tasks and chains with different AI per task."""

from iac_scanner.orchestration.runner import run_pipeline

__all__ = ["run_pipeline"]
