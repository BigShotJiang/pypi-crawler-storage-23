# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2026-02-24

### Added

#### Core Commands
- **Scan Commands** - Local compliance scanning
  - `scan static` - Static analysis with Checkov
  - `scan evaluation` - Terraform plan evaluation with OPA
  - `scan runtime` - Runtime compliance monitoring
  - `scan submit-results` - Submit scan results to backend
- **Token Commands** - API token lifecycle management
  - `token create` - Create personal or pipeline tokens
  - `token list` - List workspace tokens
  - `token revoke` - Revoke tokens by ID
- **Compliance Commands** - Compliance posture querying
  - `compliance scans list/get` - View scan history
  - `compliance violations list/get` - Track violations
  - `compliance reports list/generate` - Generate compliance reports
  - `compliance summary` - View compliance summary
- **Config Commands** - CLI configuration management
  - `config get/set/list` - Manage settings

#### Architecture
- Three-layer design (CLI → Operations → Services)
- Operations layer for workflow orchestration
- Services layer for business logic and API calls
- Auto-generated API client from OpenAPI spec
- Type-safe backend integration

#### Scanner System
- Multi-scanner orchestration (Checkov, OPA)
- Policy resolution and artifact downloading
- Scan state management and provenance tracking
- Result aggregation and submission
- Multi-framework policy support (CIS, SOC2, HIPAA)

#### CI/CD Integration
- Automatic CI/CD environment detection (GitHub, GitLab, CircleCI, Jenkins, Azure, Bitbucket)
- CI/CD context injection in scan submissions
- Pipeline-specific token support

#### Developer Experience
- Rich terminal output with colors and tables
- Secure credential storage via system keyring
- Flexible configuration (env vars, config file, CLI flags)
- Comprehensive error messages with path sanitization

### Quality Assurance
- 56 unit tests (100% passing)
- 28% code coverage (focused on core business logic)
- 100% mypy strict compliance (60 source files)
- 100% ruff compliance
- Pre-commit hooks for code quality
- CI/CD pipeline with quality gates

### Infrastructure
- GitHub Actions CI/CD workflow
  - Multi-platform testing (Ubuntu, macOS, Windows)
  - Multi-Python version testing (3.11, 3.12)
  - Code quality checks (Ruff, MyPy)
  - Security scanning (Bandit, Safety, pip-audit)
  - Coverage reporting (Codecov integration)
  - Build verification

### Dependencies
- Python 3.11+ required
- Typer for CLI framework
- Rich for terminal output
- httpx for HTTP client
- Pydantic for data validation
- Keyring for credential storage
- Optional: Checkov for static analysis

### Notes
- This is the initial **0.2.0** release following [semantic versioning](https://semver.org/)
- Focused rebuild: scanning and compliance only (no platform management)
- The API is **not yet stable** during the 0.x series
- Breaking changes may occur in minor versions during 0.x phase

[0.2.0]: https://github.com/ilterohq/iltero-cli/releases/tag/v0.2.0
