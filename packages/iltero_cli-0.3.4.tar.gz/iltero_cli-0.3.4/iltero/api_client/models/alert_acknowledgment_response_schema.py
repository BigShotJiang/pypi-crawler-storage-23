from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AlertAcknowledgmentResponseSchema")


@_attrs_define
class AlertAcknowledgmentResponseSchema:
    """Response schema for alert acknowledgment.

    Attributes:
        alert_id (UUID): Alert ID
        stack_id (UUID): Stack ID
        status (str): Updated alert status
        acknowledged_by (UUID): User who acknowledged
        acknowledged (bool | Unset): Whether alert is acknowledged Default: True.
        acknowledged_at (datetime.datetime | Unset): When alert was acknowledged
        message (str | Unset): Acknowledgment message Default: 'Alert acknowledged successfully'.
        next_action (None | str | Unset): Suggested next action
    """

    alert_id: UUID
    stack_id: UUID
    status: str
    acknowledged_by: UUID
    acknowledged: bool | Unset = True
    acknowledged_at: datetime.datetime | Unset = UNSET
    message: str | Unset = "Alert acknowledged successfully"
    next_action: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        alert_id = str(self.alert_id)

        stack_id = str(self.stack_id)

        status = self.status

        acknowledged_by = str(self.acknowledged_by)

        acknowledged = self.acknowledged

        acknowledged_at: str | Unset = UNSET
        if not isinstance(self.acknowledged_at, Unset):
            acknowledged_at = self.acknowledged_at.isoformat()

        message = self.message

        next_action: None | str | Unset
        if isinstance(self.next_action, Unset):
            next_action = UNSET
        else:
            next_action = self.next_action

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "alert_id": alert_id,
                "stack_id": stack_id,
                "status": status,
                "acknowledged_by": acknowledged_by,
            }
        )
        if acknowledged is not UNSET:
            field_dict["acknowledged"] = acknowledged
        if acknowledged_at is not UNSET:
            field_dict["acknowledged_at"] = acknowledged_at
        if message is not UNSET:
            field_dict["message"] = message
        if next_action is not UNSET:
            field_dict["next_action"] = next_action

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        alert_id = UUID(d.pop("alert_id"))

        stack_id = UUID(d.pop("stack_id"))

        status = d.pop("status")

        acknowledged_by = UUID(d.pop("acknowledged_by"))

        acknowledged = d.pop("acknowledged", UNSET)

        _acknowledged_at = d.pop("acknowledged_at", UNSET)
        acknowledged_at: datetime.datetime | Unset
        if isinstance(_acknowledged_at, Unset):
            acknowledged_at = UNSET
        else:
            acknowledged_at = isoparse(_acknowledged_at)

        message = d.pop("message", UNSET)

        def _parse_next_action(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        next_action = _parse_next_action(d.pop("next_action", UNSET))

        alert_acknowledgment_response_schema = cls(
            alert_id=alert_id,
            stack_id=stack_id,
            status=status,
            acknowledged_by=acknowledged_by,
            acknowledged=acknowledged,
            acknowledged_at=acknowledged_at,
            message=message,
            next_action=next_action,
        )

        alert_acknowledgment_response_schema.additional_properties = d
        return alert_acknowledgment_response_schema

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
