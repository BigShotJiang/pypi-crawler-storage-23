from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_environment_response_schema import APIResponseModelEnvironmentResponseSchema
from ...models.environment_update_schema import EnvironmentUpdateSchema
from ...types import Response


def _get_kwargs(
    environment_id: str,
    *,
    body: EnvironmentUpdateSchema,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/environments/{environment_id}".format(
            environment_id=quote(str(environment_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelEnvironmentResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelEnvironmentResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelEnvironmentResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    environment_id: str,
    *,
    client: AuthenticatedClient,
    body: EnvironmentUpdateSchema,
) -> Response[APIResponseModelEnvironmentResponseSchema]:
    """Update environment


            Updates environment details and configuration.

            Policy changes are applied immediately to all associated workspaces.


    Args:
        environment_id (str):
        body (EnvironmentUpdateSchema): Schema for environment updates.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelEnvironmentResponseSchema]
    """

    kwargs = _get_kwargs(
        environment_id=environment_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    environment_id: str,
    *,
    client: AuthenticatedClient,
    body: EnvironmentUpdateSchema,
) -> APIResponseModelEnvironmentResponseSchema | None:
    """Update environment


            Updates environment details and configuration.

            Policy changes are applied immediately to all associated workspaces.


    Args:
        environment_id (str):
        body (EnvironmentUpdateSchema): Schema for environment updates.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelEnvironmentResponseSchema
    """

    return sync_detailed(
        environment_id=environment_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    environment_id: str,
    *,
    client: AuthenticatedClient,
    body: EnvironmentUpdateSchema,
) -> Response[APIResponseModelEnvironmentResponseSchema]:
    """Update environment


            Updates environment details and configuration.

            Policy changes are applied immediately to all associated workspaces.


    Args:
        environment_id (str):
        body (EnvironmentUpdateSchema): Schema for environment updates.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelEnvironmentResponseSchema]
    """

    kwargs = _get_kwargs(
        environment_id=environment_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    environment_id: str,
    *,
    client: AuthenticatedClient,
    body: EnvironmentUpdateSchema,
) -> APIResponseModelEnvironmentResponseSchema | None:
    """Update environment


            Updates environment details and configuration.

            Policy changes are applied immediately to all associated workspaces.


    Args:
        environment_id (str):
        body (EnvironmentUpdateSchema): Schema for environment updates.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelEnvironmentResponseSchema
    """

    return (
        await asyncio_detailed(
            environment_id=environment_id,
            client=client,
            body=body,
        )
    ).parsed
