from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_evidence_collection_policy_schema import (
    APIResponseModelEvidenceCollectionPolicySchema,
)
from ...models.evidence_collection_policy_schema import EvidenceCollectionPolicySchema
from ...types import Response


def _get_kwargs(
    environment_id: str,
    *,
    body: EvidenceCollectionPolicySchema,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/environments/{environment_id}/policies/evidence".format(
            environment_id=quote(str(environment_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelEvidenceCollectionPolicySchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelEvidenceCollectionPolicySchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelEvidenceCollectionPolicySchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    environment_id: str,
    *,
    client: AuthenticatedClient,
    body: EvidenceCollectionPolicySchema,
) -> Response[APIResponseModelEvidenceCollectionPolicySchema]:
    """Update evidence collection policies


            Update evidence collection policies for the environment.

            This controls how compliance evidence is collected, stored,
            and managed for all workspaces in this environment.


    Args:
        environment_id (str):
        body (EvidenceCollectionPolicySchema): Schema for evidence collection policies.

            Unified evidence types:
            - terraform_output: Module outputs proving implementation (PRIMARY)
            - terraform_state: Terraform state file (PRIMARY)
            - configuration: Input variables and settings (SECONDARY)
            - terraform_plan: Planned changes (SECONDARY)
            - runtime_validation: Live cloud API checks (CONTINUOUS)
            - drift_detection: State vs actual comparison (CONTINUOUS)
            - audit_log: Deployment and access history (CONTINUOUS)
            - scan_result: Security/compliance scan outputs (ASSESSMENT)
            - manual_attestation: Human-verified assertions (ASSESSMENT)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelEvidenceCollectionPolicySchema]
    """

    kwargs = _get_kwargs(
        environment_id=environment_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    environment_id: str,
    *,
    client: AuthenticatedClient,
    body: EvidenceCollectionPolicySchema,
) -> APIResponseModelEvidenceCollectionPolicySchema | None:
    """Update evidence collection policies


            Update evidence collection policies for the environment.

            This controls how compliance evidence is collected, stored,
            and managed for all workspaces in this environment.


    Args:
        environment_id (str):
        body (EvidenceCollectionPolicySchema): Schema for evidence collection policies.

            Unified evidence types:
            - terraform_output: Module outputs proving implementation (PRIMARY)
            - terraform_state: Terraform state file (PRIMARY)
            - configuration: Input variables and settings (SECONDARY)
            - terraform_plan: Planned changes (SECONDARY)
            - runtime_validation: Live cloud API checks (CONTINUOUS)
            - drift_detection: State vs actual comparison (CONTINUOUS)
            - audit_log: Deployment and access history (CONTINUOUS)
            - scan_result: Security/compliance scan outputs (ASSESSMENT)
            - manual_attestation: Human-verified assertions (ASSESSMENT)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelEvidenceCollectionPolicySchema
    """

    return sync_detailed(
        environment_id=environment_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    environment_id: str,
    *,
    client: AuthenticatedClient,
    body: EvidenceCollectionPolicySchema,
) -> Response[APIResponseModelEvidenceCollectionPolicySchema]:
    """Update evidence collection policies


            Update evidence collection policies for the environment.

            This controls how compliance evidence is collected, stored,
            and managed for all workspaces in this environment.


    Args:
        environment_id (str):
        body (EvidenceCollectionPolicySchema): Schema for evidence collection policies.

            Unified evidence types:
            - terraform_output: Module outputs proving implementation (PRIMARY)
            - terraform_state: Terraform state file (PRIMARY)
            - configuration: Input variables and settings (SECONDARY)
            - terraform_plan: Planned changes (SECONDARY)
            - runtime_validation: Live cloud API checks (CONTINUOUS)
            - drift_detection: State vs actual comparison (CONTINUOUS)
            - audit_log: Deployment and access history (CONTINUOUS)
            - scan_result: Security/compliance scan outputs (ASSESSMENT)
            - manual_attestation: Human-verified assertions (ASSESSMENT)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelEvidenceCollectionPolicySchema]
    """

    kwargs = _get_kwargs(
        environment_id=environment_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    environment_id: str,
    *,
    client: AuthenticatedClient,
    body: EvidenceCollectionPolicySchema,
) -> APIResponseModelEvidenceCollectionPolicySchema | None:
    """Update evidence collection policies


            Update evidence collection policies for the environment.

            This controls how compliance evidence is collected, stored,
            and managed for all workspaces in this environment.


    Args:
        environment_id (str):
        body (EvidenceCollectionPolicySchema): Schema for evidence collection policies.

            Unified evidence types:
            - terraform_output: Module outputs proving implementation (PRIMARY)
            - terraform_state: Terraform state file (PRIMARY)
            - configuration: Input variables and settings (SECONDARY)
            - terraform_plan: Planned changes (SECONDARY)
            - runtime_validation: Live cloud API checks (CONTINUOUS)
            - drift_detection: State vs actual comparison (CONTINUOUS)
            - audit_log: Deployment and access history (CONTINUOUS)
            - scan_result: Security/compliance scan outputs (ASSESSMENT)
            - manual_attestation: Human-verified assertions (ASSESSMENT)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelEvidenceCollectionPolicySchema
    """

    return (
        await asyncio_detailed(
            environment_id=environment_id,
            client=client,
            body=body,
        )
    ).parsed
