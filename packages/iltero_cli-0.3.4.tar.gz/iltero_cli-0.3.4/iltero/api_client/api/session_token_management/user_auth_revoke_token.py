from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_token_revoke_response_schema import APIResponseModelTokenRevokeResponseSchema
from ...models.token_schema import TokenSchema
from ...types import Response


def _get_kwargs(
    *,
    body: TokenSchema,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/auth/session/token/revoke",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelTokenRevokeResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelTokenRevokeResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelTokenRevokeResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: TokenSchema,
) -> Response[APIResponseModelTokenRevokeResponseSchema]:
    """Revoke authentication token


            Revokes an authentication token.

            Invalidates the provided token, preventing it from being used for
            future authentication. Useful for logging out or invalidating
            compromised tokens.


    Args:
        body (TokenSchema): Token request/response schema.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelTokenRevokeResponseSchema]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: TokenSchema,
) -> APIResponseModelTokenRevokeResponseSchema | None:
    """Revoke authentication token


            Revokes an authentication token.

            Invalidates the provided token, preventing it from being used for
            future authentication. Useful for logging out or invalidating
            compromised tokens.


    Args:
        body (TokenSchema): Token request/response schema.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelTokenRevokeResponseSchema
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: TokenSchema,
) -> Response[APIResponseModelTokenRevokeResponseSchema]:
    """Revoke authentication token


            Revokes an authentication token.

            Invalidates the provided token, preventing it from being used for
            future authentication. Useful for logging out or invalidating
            compromised tokens.


    Args:
        body (TokenSchema): Token request/response schema.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelTokenRevokeResponseSchema]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: TokenSchema,
) -> APIResponseModelTokenRevokeResponseSchema | None:
    """Revoke authentication token


            Revokes an authentication token.

            Invalidates the provided token, preventing it from being used for
            future authentication. Useful for logging out or invalidating
            compromised tokens.


    Args:
        body (TokenSchema): Token request/response schema.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelTokenRevokeResponseSchema
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
