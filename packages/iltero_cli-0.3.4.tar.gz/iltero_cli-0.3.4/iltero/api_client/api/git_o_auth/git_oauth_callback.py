from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_git_o_auth_callback_response_schema import (
    APIResponseModelGitOAuthCallbackResponseSchema,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    provider: str,
    *,
    code: str,
    state: str,
    error: None | str | Unset = UNSET,
    error_description: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["code"] = code

    params["state"] = state

    json_error: None | str | Unset
    if isinstance(error, Unset):
        json_error = UNSET
    else:
        json_error = error
    params["error"] = json_error

    json_error_description: None | str | Unset
    if isinstance(error_description, Unset):
        json_error_description = UNSET
    else:
        json_error_description = error_description
    params["error_description"] = json_error_description

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/repositories/oauth/{provider}/callback".format(
            provider=quote(str(provider), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelGitOAuthCallbackResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelGitOAuthCallbackResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelGitOAuthCallbackResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
    code: str,
    state: str,
    error: None | str | Unset = UNSET,
    error_description: None | str | Unset = UNSET,
) -> Response[APIResponseModelGitOAuthCallbackResponseSchema]:
    """OAuth callback handler


            Handles OAuth callback from Git provider.

            Validates state parameter, exchanges code for tokens,
            stores encrypted credentials, returns success.

            No authentication required - user identified via validated state parameter.


    Args:
        provider (str):
        code (str):
        state (str):
        error (None | str | Unset):
        error_description (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelGitOAuthCallbackResponseSchema]
    """

    kwargs = _get_kwargs(
        provider=provider,
        code=code,
        state=state,
        error=error,
        error_description=error_description,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
    code: str,
    state: str,
    error: None | str | Unset = UNSET,
    error_description: None | str | Unset = UNSET,
) -> APIResponseModelGitOAuthCallbackResponseSchema | None:
    """OAuth callback handler


            Handles OAuth callback from Git provider.

            Validates state parameter, exchanges code for tokens,
            stores encrypted credentials, returns success.

            No authentication required - user identified via validated state parameter.


    Args:
        provider (str):
        code (str):
        state (str):
        error (None | str | Unset):
        error_description (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelGitOAuthCallbackResponseSchema
    """

    return sync_detailed(
        provider=provider,
        client=client,
        code=code,
        state=state,
        error=error,
        error_description=error_description,
    ).parsed


async def asyncio_detailed(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
    code: str,
    state: str,
    error: None | str | Unset = UNSET,
    error_description: None | str | Unset = UNSET,
) -> Response[APIResponseModelGitOAuthCallbackResponseSchema]:
    """OAuth callback handler


            Handles OAuth callback from Git provider.

            Validates state parameter, exchanges code for tokens,
            stores encrypted credentials, returns success.

            No authentication required - user identified via validated state parameter.


    Args:
        provider (str):
        code (str):
        state (str):
        error (None | str | Unset):
        error_description (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelGitOAuthCallbackResponseSchema]
    """

    kwargs = _get_kwargs(
        provider=provider,
        code=code,
        state=state,
        error=error,
        error_description=error_description,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    provider: str,
    *,
    client: AuthenticatedClient | Client,
    code: str,
    state: str,
    error: None | str | Unset = UNSET,
    error_description: None | str | Unset = UNSET,
) -> APIResponseModelGitOAuthCallbackResponseSchema | None:
    """OAuth callback handler


            Handles OAuth callback from Git provider.

            Validates state parameter, exchanges code for tokens,
            stores encrypted credentials, returns success.

            No authentication required - user identified via validated state parameter.


    Args:
        provider (str):
        code (str):
        state (str):
        error (None | str | Unset):
        error_description (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelGitOAuthCallbackResponseSchema
    """

    return (
        await asyncio_detailed(
            provider=provider,
            client=client,
            code=code,
            state=state,
            error=error,
            error_description=error_description,
        )
    ).parsed
