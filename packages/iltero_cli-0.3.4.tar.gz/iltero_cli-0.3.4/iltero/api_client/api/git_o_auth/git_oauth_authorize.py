from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_git_o_auth_authorize_response_schema import (
    APIResponseModelGitOAuthAuthorizeResponseSchema,
)
from ...models.git_o_auth_authorize_request_schema import GitOAuthAuthorizeRequestSchema
from ...types import Response


def _get_kwargs(
    provider: str,
    *,
    body: GitOAuthAuthorizeRequestSchema,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/repositories/oauth/{provider}/authorize".format(
            provider=quote(str(provider), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelGitOAuthAuthorizeResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelGitOAuthAuthorizeResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelGitOAuthAuthorizeResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    provider: str,
    *,
    client: AuthenticatedClient,
    body: GitOAuthAuthorizeRequestSchema,
) -> Response[APIResponseModelGitOAuthAuthorizeResponseSchema]:
    """Generate OAuth authorization URL


            Generates OAuth authorization URL for connecting Git credentials.

            User must be logged in. Returns URL to redirect user to Git provider
            for authorization. Includes CSRF-protected state parameter.

            This is for Git repository authorization, NOT user authentication.


    Args:
        provider (str):
        body (GitOAuthAuthorizeRequestSchema): Request schema for OAuth authorization URL
            generation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelGitOAuthAuthorizeResponseSchema]
    """

    kwargs = _get_kwargs(
        provider=provider,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    provider: str,
    *,
    client: AuthenticatedClient,
    body: GitOAuthAuthorizeRequestSchema,
) -> APIResponseModelGitOAuthAuthorizeResponseSchema | None:
    """Generate OAuth authorization URL


            Generates OAuth authorization URL for connecting Git credentials.

            User must be logged in. Returns URL to redirect user to Git provider
            for authorization. Includes CSRF-protected state parameter.

            This is for Git repository authorization, NOT user authentication.


    Args:
        provider (str):
        body (GitOAuthAuthorizeRequestSchema): Request schema for OAuth authorization URL
            generation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelGitOAuthAuthorizeResponseSchema
    """

    return sync_detailed(
        provider=provider,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    provider: str,
    *,
    client: AuthenticatedClient,
    body: GitOAuthAuthorizeRequestSchema,
) -> Response[APIResponseModelGitOAuthAuthorizeResponseSchema]:
    """Generate OAuth authorization URL


            Generates OAuth authorization URL for connecting Git credentials.

            User must be logged in. Returns URL to redirect user to Git provider
            for authorization. Includes CSRF-protected state parameter.

            This is for Git repository authorization, NOT user authentication.


    Args:
        provider (str):
        body (GitOAuthAuthorizeRequestSchema): Request schema for OAuth authorization URL
            generation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelGitOAuthAuthorizeResponseSchema]
    """

    kwargs = _get_kwargs(
        provider=provider,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    provider: str,
    *,
    client: AuthenticatedClient,
    body: GitOAuthAuthorizeRequestSchema,
) -> APIResponseModelGitOAuthAuthorizeResponseSchema | None:
    """Generate OAuth authorization URL


            Generates OAuth authorization URL for connecting Git credentials.

            User must be logged in. Returns URL to redirect user to Git provider
            for authorization. Includes CSRF-protected state parameter.

            This is for Git repository authorization, NOT user authentication.


    Args:
        provider (str):
        body (GitOAuthAuthorizeRequestSchema): Request schema for OAuth authorization URL
            generation.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelGitOAuthAuthorizeResponseSchema
    """

    return (
        await asyncio_detailed(
            provider=provider,
            client=client,
            body=body,
        )
    ).parsed
