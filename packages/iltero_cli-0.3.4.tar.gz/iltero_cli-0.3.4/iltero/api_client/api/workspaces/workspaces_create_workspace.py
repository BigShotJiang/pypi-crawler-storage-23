from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_workspace_detail_response_schema import APIResponseModelWorkspaceDetailResponseSchema
from ...models.workspace_create_schema import WorkspaceCreateSchema
from ...types import Response


def _get_kwargs(
    *,
    body: WorkspaceCreateSchema,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/workspaces",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelWorkspaceDetailResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelWorkspaceDetailResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelWorkspaceDetailResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: WorkspaceCreateSchema,
) -> Response[APIResponseModelWorkspaceDetailResponseSchema]:
    """Create workspace


            Creates a new workspace within an organization.

            Workspaces group related infrastructure stacks and inherit
            policies from their associated environment.

            Supports two input modes for environments:
            1. Simple: environment_ids - branches inherited from Environment
            2. Explicit: environment_mappings with optional branch overrides

            Each environment must map to a unique Git branch after inheritance.


    Args:
        body (WorkspaceCreateSchema): Schema for workspace creation with multi-environment
            support.

            Supports two input modes:
            1. Simple: Just provide environment_ids - branches are inherited from
            Environment.repo_ref_name
            2. Explicit: Provide environment_mappings with optional branch overrides

            Note: If both are provided, environment_mappings takes precedence.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelWorkspaceDetailResponseSchema]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: WorkspaceCreateSchema,
) -> APIResponseModelWorkspaceDetailResponseSchema | None:
    """Create workspace


            Creates a new workspace within an organization.

            Workspaces group related infrastructure stacks and inherit
            policies from their associated environment.

            Supports two input modes for environments:
            1. Simple: environment_ids - branches inherited from Environment
            2. Explicit: environment_mappings with optional branch overrides

            Each environment must map to a unique Git branch after inheritance.


    Args:
        body (WorkspaceCreateSchema): Schema for workspace creation with multi-environment
            support.

            Supports two input modes:
            1. Simple: Just provide environment_ids - branches are inherited from
            Environment.repo_ref_name
            2. Explicit: Provide environment_mappings with optional branch overrides

            Note: If both are provided, environment_mappings takes precedence.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelWorkspaceDetailResponseSchema
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: WorkspaceCreateSchema,
) -> Response[APIResponseModelWorkspaceDetailResponseSchema]:
    """Create workspace


            Creates a new workspace within an organization.

            Workspaces group related infrastructure stacks and inherit
            policies from their associated environment.

            Supports two input modes for environments:
            1. Simple: environment_ids - branches inherited from Environment
            2. Explicit: environment_mappings with optional branch overrides

            Each environment must map to a unique Git branch after inheritance.


    Args:
        body (WorkspaceCreateSchema): Schema for workspace creation with multi-environment
            support.

            Supports two input modes:
            1. Simple: Just provide environment_ids - branches are inherited from
            Environment.repo_ref_name
            2. Explicit: Provide environment_mappings with optional branch overrides

            Note: If both are provided, environment_mappings takes precedence.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelWorkspaceDetailResponseSchema]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: WorkspaceCreateSchema,
) -> APIResponseModelWorkspaceDetailResponseSchema | None:
    """Create workspace


            Creates a new workspace within an organization.

            Workspaces group related infrastructure stacks and inherit
            policies from their associated environment.

            Supports two input modes for environments:
            1. Simple: environment_ids - branches inherited from Environment
            2. Explicit: environment_mappings with optional branch overrides

            Each environment must map to a unique Git branch after inheritance.


    Args:
        body (WorkspaceCreateSchema): Schema for workspace creation with multi-environment
            support.

            Supports two input modes:
            1. Simple: Just provide environment_ids - branches are inherited from
            Environment.repo_ref_name
            2. Explicit: Provide environment_mappings with optional branch overrides

            Note: If both are provided, environment_mappings takes precedence.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelWorkspaceDetailResponseSchema
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
