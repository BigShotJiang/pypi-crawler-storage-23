from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_repository_initialize_response_schema import (
    APIResponseModelRepositoryInitializeResponseSchema,
)
from ...models.repository_initialize_request_schema import RepositoryInitializeRequestSchema
from ...types import UNSET, Response, Unset


def _get_kwargs(
    repository_id: str,
    *,
    body: None | RepositoryInitializeRequestSchema | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/repositories/{repository_id}/initialize".format(
            repository_id=quote(str(repository_id), safe=""),
        ),
    }

    if isinstance(body, RepositoryInitializeRequestSchema):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelRepositoryInitializeResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelRepositoryInitializeResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelRepositoryInitializeResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    repository_id: str,
    *,
    client: AuthenticatedClient,
    body: None | RepositoryInitializeRequestSchema | Unset = UNSET,
) -> Response[APIResponseModelRepositoryInitializeResponseSchema]:
    """Initialize Repository CI/CD


            Initialize repository with base CI/CD infrastructure.

            One-time operation creating base workflows and repository secrets.
            Returns PR URL that must be merged before stack bootstrapping.


    Args:
        repository_id (str):
        body (None | RepositoryInitializeRequestSchema | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelRepositoryInitializeResponseSchema]
    """

    kwargs = _get_kwargs(
        repository_id=repository_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    repository_id: str,
    *,
    client: AuthenticatedClient,
    body: None | RepositoryInitializeRequestSchema | Unset = UNSET,
) -> APIResponseModelRepositoryInitializeResponseSchema | None:
    """Initialize Repository CI/CD


            Initialize repository with base CI/CD infrastructure.

            One-time operation creating base workflows and repository secrets.
            Returns PR URL that must be merged before stack bootstrapping.


    Args:
        repository_id (str):
        body (None | RepositoryInitializeRequestSchema | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelRepositoryInitializeResponseSchema
    """

    return sync_detailed(
        repository_id=repository_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    repository_id: str,
    *,
    client: AuthenticatedClient,
    body: None | RepositoryInitializeRequestSchema | Unset = UNSET,
) -> Response[APIResponseModelRepositoryInitializeResponseSchema]:
    """Initialize Repository CI/CD


            Initialize repository with base CI/CD infrastructure.

            One-time operation creating base workflows and repository secrets.
            Returns PR URL that must be merged before stack bootstrapping.


    Args:
        repository_id (str):
        body (None | RepositoryInitializeRequestSchema | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelRepositoryInitializeResponseSchema]
    """

    kwargs = _get_kwargs(
        repository_id=repository_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    repository_id: str,
    *,
    client: AuthenticatedClient,
    body: None | RepositoryInitializeRequestSchema | Unset = UNSET,
) -> APIResponseModelRepositoryInitializeResponseSchema | None:
    """Initialize Repository CI/CD


            Initialize repository with base CI/CD infrastructure.

            One-time operation creating base workflows and repository secrets.
            Returns PR URL that must be merged before stack bootstrapping.


    Args:
        repository_id (str):
        body (None | RepositoryInitializeRequestSchema | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelRepositoryInitializeResponseSchema
    """

    return (
        await asyncio_detailed(
            repository_id=repository_id,
            client=client,
            body=body,
        )
    ).parsed
