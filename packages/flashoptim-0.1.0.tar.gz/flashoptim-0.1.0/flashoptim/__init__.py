"""FlashOptim: Efficient PyTorch optimizers with quantization and Triton kernels."""

from .optimizers import (
    FlashAdam,
    FlashAdamW,
    FlashLion,
    FlashOptimizer,
    FlashSGD,
    GradientReleaseHandle,
    NumericsError,
    compute_ecc_bits,
    downcast_model,
    enable_gradient_release,
    reconstruct_fp32_param,
)

__version__ = "0.1.0"

__all__ = [
    "FlashAdam",
    "FlashAdamW",
    "FlashLion",
    "FlashOptimizer",
    "FlashSGD",
    "GradientReleaseHandle",
    "NumericsError",
    "compute_ecc_bits",
    "downcast_model",
    "enable_gradient_release",
    "reconstruct_fp32_param",
]
