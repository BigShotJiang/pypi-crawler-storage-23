"""
ConceptCheck class.

This module provides validation for concept arrays in criteria.

GUARD RAIL: This module implements Java CIRCE-BE functionality.
Any changes must maintain 1:1 compatibility with Java classes.
Reference: JAVA_CLASS_MAPPINGS.md for Java equivalents.
"""

from .base_value_check import BaseValueCheck
from .concept_checker_factory import ConceptCheckerFactory
from .warning_reporter import WarningReporter


class ConceptCheck(BaseValueCheck):
    """Check for empty concept arrays in criteria.

    Java equivalent: org.ohdsi.circe.check.checkers.ConceptCheck
    """

    def _get_factory(
        self, reporter: WarningReporter, name: str
    ) -> ConceptCheckerFactory:
        """Get a concept checker factory.

        Args:
            reporter: The warning reporter to use
            name: The name of the criteria group

        Returns:
            A ConceptCheckerFactory instance
        """
        return ConceptCheckerFactory.get_factory(reporter, name)
