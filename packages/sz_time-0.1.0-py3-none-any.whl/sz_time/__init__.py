import datetime

__all__ = ['get_current_time_with_shenzhen']

def get_current_time_with_shenzhen():
    """
    获取当前时间并添加深圳位置信息
    
    Returns:
        str: 包含当前时间和深圳位置的字符串
    """
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return f"{current_time} 深圳"

if __name__ == "__main__":
    print(get_current_time_with_shenzhen())