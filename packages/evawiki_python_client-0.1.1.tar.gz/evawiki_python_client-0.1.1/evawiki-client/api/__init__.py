# flake8: noqa

# import apis into api package
from evawiki-client.api.default_api import DefaultApi

