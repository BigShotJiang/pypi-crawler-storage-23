## [0.4.12](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.11...v0.4.12) (2026-02-21)


### Bug Fixes

* add support for --generate-dashboard-from ([7e6eb2b](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/7e6eb2b35dca62a0832a537f394d8dad42ed374f))

## [0.4.11](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.10...v0.4.11) (2026-02-21)


### Bug Fixes

* update footer ([26fae34](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/26fae34a4a0fd921b752210a5879945a9f571569))

## [0.4.10](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.9...v0.4.10) (2026-02-21)


### Bug Fixes

* make dashboard more mobile friendly ([0233fc9](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/0233fc98f96b0534ba75aae86e970e1c646e9321))

## [0.4.9](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.8...v0.4.9) (2026-02-21)


### Bug Fixes

* refactor ESC9 detection ([25edd71](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/25edd71178dc0525520225678283deee06e2817a))

## [0.4.8](https://github.com/l4rm4nd/PyADRecon-ADWS/compare/v0.4.7...v0.4.8) (2026-02-21)


### Bug Fixes

* refactor ESC2, ESC3, ESC4 detection; add manager approval to dashboard ([9f2a78b](https://github.com/l4rm4nd/PyADRecon-ADWS/commit/9f2a78b513d0b4c5edb97037fbff9e5e2cd0905f))

