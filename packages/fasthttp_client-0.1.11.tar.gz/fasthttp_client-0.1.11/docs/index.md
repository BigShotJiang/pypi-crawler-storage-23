# FastHTTP Client

Fast and simple HTTP client library with async support and beautiful logging.

## Features

- 🚀 Fast and simple HTTP client
- 📝 Beautiful logging
- 🔄 Async support
- ✅ Pydantic validation
- 🔒 HTTP/2 support

## Documentation

- [English Documentation](./en/)
- [Русская документация](./ru/)
