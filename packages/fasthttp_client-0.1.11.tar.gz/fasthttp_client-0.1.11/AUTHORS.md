# Authors

<!-- ALL-CONTRIBUTORS-LIST:START -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tbody>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://github.com/ndugram"><img src="https://avatars.githubusercontent.com/u/????s=100" width="100px;" alt="ndugram"/><br /><sub><b>ndugram</b></sub></a><br /><a href="https://github.com/ndugram/fasthttp/commits?author=ndugram" title="Code">💻</a> <a href="https://github.com/ndugram/fasthttp/commits?author=ndugram" title="Documentation">📖</a> <a href="#maintenance-ndugram" title="Maintenance">🚧</a> <a href="https://github.com/ndugram/fasthttp/commits?author=ndugram" title="Tests">⚠️</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://neforceo.github.io/NEFORDEV/"><img src="https://avatars.githubusercontent.com/u/205934457?v=4?s=100" width="100px;" alt="安𝐍ᴇғᴏʀ &#124; ᵈᵉᵛ"/><br /><sub><b>安𝐍ᴇғᴏʀ &#124; ᵈᵉᵛ</b></sub></a><br /><a href="https://github.com/ndugram/fasthttp/commits?author=NEFORCEO" title="Code">💻</a></td>
    </tr>
  </tbody>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->
