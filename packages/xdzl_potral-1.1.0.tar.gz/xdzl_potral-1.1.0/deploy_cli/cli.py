#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
环境构建CLI工具
命令说明：
  deploy-cli build    - 生成pyproject.toml配置文件（交互式选择框架/版本/设备）
  deploy-cli install  - 一键安装/配置虚拟环境（依赖pyproject.toml）
  deploy-cli --help   - 查看帮助信息
"""
import argparse
import sys
import os

# 导入两个核心SDK模块
from deploy_cli.env_builder import EnvBuilderSDK
from deploy_cli.env_installer import create_portal_env


def build_pyproject():
    """生成pyproject.toml配置文件"""
    print("===== 开始生成pyproject.toml配置文件 =====")
    sdk = EnvBuilderSDK()
    sdk.run()


def install_env(args):
    """安装/配置虚拟环境"""
    print("===== 开始一键构建虚拟环境 =====")
    create_portal_env(env_name=args.env_name, python_version=args.python)


def main():
    # 创建顶级解析器
    parser = argparse.ArgumentParser(
        prog="deploy-cli",
        description="环境构建CLI工具（Python 3.10.19）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""使用示例:
  deploy-cli build                     # 交互式生成pyproject.toml
  deploy-cli install                   # 使用默认参数安装环境
  deploy-cli install --env-name my_env # 指定环境名称安装
  deploy-cli install --python 3.10.19  # 指定Python版本安装"""
    )

    # 创建子命令解析器
    subparsers = parser.add_subparsers(dest="command", required=True, help="子命令")

    # 1. build子命令（生成pyproject.toml）
    build_parser = subparsers.add_parser("build", help="生成pyproject.toml配置文件")

    # 2. install子命令（安装环境）
    install_parser = subparsers.add_parser("install", help="一键构建虚拟环境")
    install_parser.add_argument(
        "--env-name",
        default="portal_test",
        help="虚拟环境名称（默认：portal_test）"
    )
    install_parser.add_argument(
        "--python",
        default="3.10.19",
        help="Python版本（默认：3.10.19）"
    )

    # 解析参数
    args = parser.parse_args()

    # 执行对应子命令
    if args.command == "build":
        build_pyproject()
    elif args.command == "install":
        install_env(args)


if __name__ == "__main__":
    # 检查Python版本（最低3.10）
    if sys.version_info < (3, 10):
        print(f"错误：该工具需要Python 3.10及以上版本，当前版本：{sys.version}")
        sys.exit(1)
    
    # 检查工作目录权限
    if not os.access(os.getcwd(), os.W_OK):
        print("错误：当前目录无写入权限，无法生成配置文件/安装环境")
        sys.exit(1)

    main()