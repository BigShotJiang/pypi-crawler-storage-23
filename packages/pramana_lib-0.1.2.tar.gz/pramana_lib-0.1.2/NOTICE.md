# Third-Party Notices

## Gaussian Integers and Gaussian Rationals (Zi & Qi)

The `Zi` (Gaussian Integer) and `Qi` (Gaussian Rational) classes in
`src/pramana/gaussians.py` are forked from:

- **Author:** Alfred J. Reich, Ph.D.
- **Contact:** al.reich@gmail.com
- **Source:** https://github.com/alreich/gaussian_integers
- **License:** MIT
- **Copyright:** Copyright (C) 2024 Alfred J. Reich, Ph.D.

Dr. Reich's implementation provides exact arithmetic for Gaussian integers (Z[i])
and Gaussian rationals (Q[i]), including number-theoretic operations such as the
Euclidean algorithm (GCD), Extended Euclidean Algorithm (Bezout coefficients),
Gaussian primality testing, and the Modified Division Theorem from Keith Conrad's
"The Gaussian Integers."

The original MIT license text is reproduced below:

```
MIT License

Copyright (c) 2024 Alfred J Reich, PhD

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
