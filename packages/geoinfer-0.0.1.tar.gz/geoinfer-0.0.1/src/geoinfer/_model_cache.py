"""Live model cache with TTL-based refresh."""

from __future__ import annotations

import threading
import time

from .exceptions import InvalidModelError
from .types import Model

_DEFAULT_TTL: float = 300.0  # seconds


class _ModelCache:
    """Model list cache with TTL-based refresh.

    A ``threading.Lock`` guards the fetch path so that concurrent threads
    cannot both observe a stale cache and issue duplicate network requests.
    """

    def __init__(self, ttl: float = _DEFAULT_TTL) -> None:
        self._ttl = ttl
        self._fetched_at: float | None = None
        self._by_id: dict[str, Model] = {}
        self._lock = threading.Lock()

    def needs_refresh(self) -> bool:
        if self._fetched_at is None:
            return True
        return (time.monotonic() - self._fetched_at) >= self._ttl

    def load(self, models: list[Model]) -> None:
        """Populate the cache from a freshly fetched model list."""
        self._by_id = {m.model_id: m for m in models}
        self._fetched_at = time.monotonic()

    def validate(self, model_id: str) -> None:
        """Raise :class:`~geoinfer.InvalidModelError` if *model_id* is unknown or disabled.

        Parameters
        ----------
        model_id:
            The model identifier to validate.
        """
        model = self._by_id.get(model_id)
        if model is None:
            available = ", ".join(f"{m.model_id!r}" for m in self._by_id.values()) or "(none)"
            raise InvalidModelError(
                f"model_id {model_id!r} is not available on this account. "
                f"Available models: {available}"
            )
        if not model.enabled:
            raise InvalidModelError(f"model_id {model_id!r} exists but is currently disabled.")

    def all(self) -> list[Model]:
        return list(self._by_id.values())
