"""Internal HTTP client shared by sync and async resource classes."""

from __future__ import annotations

import contextlib
import mimetypes
from pathlib import Path
from types import TracebackType
from typing import IO, Any, Union

import httpx

from .exceptions import (
    APIError,
    AuthenticationError,
    FileTooLargeError,
    ForbiddenError,
    GeoInferError,
    InsufficientCreditsError,
    InvalidFileTypeError,
    RateLimitError,
)

_DEFAULT_BASE_URL = "https://api.geoinfer.com"
_DEFAULT_TIMEOUT = 60.0  # seconds

# Mapping of HTTP status codes to exception classes
_STATUS_EXCEPTIONS: dict[int, type[GeoInferError]] = {
    401: AuthenticationError,
    402: InsufficientCreditsError,
    403: ForbiddenError,
    413: FileTooLargeError,
    422: InvalidFileTypeError,
}

FileInput = Union[str, Path, bytes, IO[bytes]]


def _fetch_url(url: str) -> tuple[str, bytes, str]:
    """Download *url* and return *(filename, content, mime_type)*."""
    with httpx.Client(timeout=60.0) as http:
        response = http.get(url, follow_redirects=True)
    if not response.is_success:
        raise ValueError(f"Failed to fetch image from URL {url!r}: HTTP {response.status_code}")
    filename = url.rstrip("/").split("/")[-1].split("?")[0] or "upload"
    mime = response.headers.get("content-type", "").split(";")[0].strip()
    if not mime:
        mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
    return filename, response.content, mime


def _prepare_file(source: FileInput) -> tuple[str, bytes, str]:
    """Return *(filename, content, mime_type)* for the given file input."""
    if isinstance(source, str) and (source.startswith("http://") or source.startswith("https://")):
        return _fetch_url(source)

    if isinstance(source, (str, Path)):
        path = Path(source)
        content = path.read_bytes()
        filename = path.name
        mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        return filename, content, mime

    if isinstance(source, bytes):
        return "upload", source, "application/octet-stream"

    # File-like object
    raw = source.read()
    if isinstance(raw, str):
        raise TypeError(
            "File object must be opened in binary mode ('rb'), not text mode. "
            f"Got str from {source!r}.read()"
        )
    name = getattr(source, "name", "upload")
    filename = Path(name).name if name else "upload"
    mime = mimetypes.guess_type(filename)[0] or "application/octet-stream"
    return filename, raw, mime


def _raise_for_status(response: httpx.Response) -> None:
    """Raise the appropriate :class:`GeoInferError` subclass for error responses."""
    if response.is_success:
        return

    message_code = "ERROR"
    message = response.text

    try:
        body = response.json()
    except ValueError:
        pass
    else:
        if isinstance(body, dict):
            message_code = body.get("message_code", message_code)
            message = body.get("message", message)

    status = response.status_code

    if status == 429:
        retry_after: int | None = None
        raw = response.headers.get("Retry-After")
        if raw is not None:
            with contextlib.suppress(ValueError):
                retry_after = int(raw)
        raise RateLimitError(
            message,
            message_code=message_code,
            status_code=status,
            retry_after=retry_after,
        )

    exc_class = _STATUS_EXCEPTIONS.get(status, APIError)
    raise exc_class(message, message_code=message_code, status_code=status)


def _unwrap(body: Any) -> Any:
    """Extract ``data`` from the standard API envelope."""
    if isinstance(body, dict):
        if "data" not in body:
            raise APIError(
                "Unexpected API response: missing 'data' envelope key. "
                f"Got keys: {list(body.keys())}"
            )
        return body["data"]
    return body


# ---------------------------------------------------------------------------
# Sync client
# ---------------------------------------------------------------------------


class SyncHTTPClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        self._http = httpx.Client(
            base_url=base_url,
            headers={"X-GeoInfer-Key": api_key},
            timeout=timeout,
        )

    def get(self, path: str, **kwargs: Any) -> tuple[Any, httpx.Headers]:
        response = self._http.get(path, **kwargs)
        _raise_for_status(response)
        return _unwrap(response.json()), response.headers

    def post_multipart(
        self,
        path: str,
        file: FileInput,
        params: dict[str, Any] | None = None,
    ) -> tuple[Any, httpx.Headers]:
        filename, content, mime = _prepare_file(file)
        files = {"file": (filename, content, mime)}
        response = self._http.post(path, files=files, params=params or {})
        _raise_for_status(response)
        return _unwrap(response.json()), response.headers

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> SyncHTTPClient:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------


class AsyncHTTPClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        self._http = httpx.AsyncClient(
            base_url=base_url,
            headers={"X-GeoInfer-Key": api_key},
            timeout=timeout,
        )

    async def get(self, path: str, **kwargs: Any) -> tuple[Any, httpx.Headers]:
        response = await self._http.get(path, **kwargs)
        _raise_for_status(response)
        return _unwrap(response.json()), response.headers

    async def post_multipart(
        self,
        path: str,
        file: FileInput,
        params: dict[str, Any] | None = None,
    ) -> tuple[Any, httpx.Headers]:
        filename, content, mime = _prepare_file(file)
        files = {"file": (filename, content, mime)}
        response = await self._http.post(path, files=files, params=params or {})
        _raise_for_status(response)
        return _unwrap(response.json()), response.headers

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> AsyncHTTPClient:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.aclose()
