"""Internal helpers for parsing raw API dicts into typed dataclasses."""

from __future__ import annotations

from datetime import datetime
from typing import Any

import httpx

from .types import (
    AccuracyPrediction,
    AccuracyPredictionResult,
    Cluster,
    CoordinatePredictionResult,
    CreditsSummary,
    CreditsSummaryTotals,
    LatLon,
    Location,
    Model,
    OverageInfo,
    PredictionResponse,
    RateLimitInfo,
    SubscriptionInfo,
    TopupInfo,
)

# ---------------------------------------------------------------------------
# Rate-limit header parsing
# ---------------------------------------------------------------------------


def parse_rate_limit(headers: httpx.Headers) -> RateLimitInfo:
    def _int(key: str) -> int | None:
        val = headers.get(key)
        if val is None:
            return None
        try:
            return int(val)
        except ValueError:
            return None

    return RateLimitInfo(
        limit=_int("X-RateLimit-Limit"),
        remaining=_int("X-RateLimit-Remaining"),
        reset=_int("X-RateLimit-Reset"),
        window=_int("X-RateLimit-Window"),
    )


# ---------------------------------------------------------------------------
# Sub-type parsers
# ---------------------------------------------------------------------------


def _parse_latlon(d: dict[str, Any]) -> LatLon:
    return LatLon(latitude=d["latitude"], longitude=d["longitude"])


def _parse_location_opt(d: dict[str, Any] | None) -> Location | None:
    if d is None:
        return None
    return Location(
        name=d["name"],
        admin1=d["admin1"],
        admin2=d["admin2"],
        country_code=d["country_code"],
    )


def _parse_cluster(d: dict[str, Any]) -> Cluster:
    location = _parse_location_opt(d["location"])
    if location is None:
        raise ValueError(f"Cluster is missing required 'location' field: {d!r}")
    return Cluster(
        center=_parse_latlon(d["center"]),
        location=location,
        radius_km=d["radius_km"],
        points=tuple(_parse_latlon(p) for p in d.get("points", [])),
    )


def _parse_accuracy_prediction(d: dict[str, Any]) -> AccuracyPrediction:
    return AccuracyPrediction(
        latitude=d["latitude"],
        longitude=d["longitude"],
        confidence=d["confidence"],
        rank=d["rank"],
        likely_pano_id=d.get("likely_pano_id"),
        location=_parse_location_opt(d.get("location")),
    )


# ---------------------------------------------------------------------------
# Prediction result — discriminated on result_type
# ---------------------------------------------------------------------------


def parse_prediction_result(
    d: dict[str, Any],
) -> CoordinatePredictionResult | AccuracyPredictionResult:
    result_type = d["result_type"]

    if result_type == "coordinates":
        return CoordinatePredictionResult(
            result_type="coordinates",
            clusters=tuple(_parse_cluster(c) for c in d.get("clusters", [])),
            processing_time_ms=d["processing_time_ms"],
        )

    if result_type == "accuracy":
        top_raw = d.get("top_prediction")
        return AccuracyPredictionResult(
            result_type="accuracy",
            predictions=tuple(_parse_accuracy_prediction(p) for p in d.get("predictions", [])),
            top_prediction=_parse_accuracy_prediction(top_raw) if top_raw else None,
            processing_time_ms=d["processing_time_ms"],
        )

    raise ValueError(f"Unknown result_type: {result_type!r}")


def parse_prediction_response(
    data: dict[str, Any],
    headers: httpx.Headers,
) -> PredictionResponse[CoordinatePredictionResult] | PredictionResponse[AccuracyPredictionResult]:
    prediction = parse_prediction_result(data["prediction"])
    if isinstance(prediction, CoordinatePredictionResult):
        return PredictionResponse(
            prediction_id=data["prediction_id"],
            model_id=data["model_id"],
            credits_consumed=data["credits_consumed"],
            prediction=prediction,
            rate_limit=parse_rate_limit(headers),
        )
    return PredictionResponse(
        prediction_id=data["prediction_id"],
        model_id=data["model_id"],
        credits_consumed=data["credits_consumed"],
        prediction=prediction,
        rate_limit=parse_rate_limit(headers),
    )


# ---------------------------------------------------------------------------
# Models list
# ---------------------------------------------------------------------------


def parse_models(data: list[dict[str, Any]]) -> list[Model]:
    return [
        Model(
            model_id=m["id"],
            model_type=m["type"].upper(),  # API returns lowercase "global" / "accuracy"
            enabled=m["enabled"],
            credits_per_use=float(m.get("credits_per_use", 0)),
        )
        for m in data
    ]


# ---------------------------------------------------------------------------
# Credits summary
# ---------------------------------------------------------------------------


def _parse_dt(value: str) -> datetime:
    # fromisoformat only supports trailing 'Z' from Python 3.11+
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _parse_dt_opt(value: str | None) -> datetime | None:
    return _parse_dt(value) if value is not None else None


def _parse_subscription(d: dict[str, Any] | None) -> SubscriptionInfo | None:
    if d is None:
        return None
    return SubscriptionInfo(
        id=d["id"],
        monthly_allowance=d["monthly_allowance"],
        granted_this_period=d["granted_this_period"],
        used_this_period=d["used_this_period"],
        remaining=d["remaining"],
        period_start=_parse_dt(d["period_start"]),
        period_end=_parse_dt(d["period_end"]),
        status=d["status"],
        billing_interval=d["billing_interval"],
        price_paid=d["price_paid"],
        overage_unit_price=d["overage_unit_price"],
        cancel_at_period_end=d["cancel_at_period_end"],
        pause_access=d["pause_access"],
    )


def _parse_overage(d: dict[str, Any] | None) -> OverageInfo | None:
    if d is None:
        return None
    return OverageInfo(
        enabled=d["enabled"],
        used=d["used"],
        reported_to_stripe=d["reported_to_stripe"],
        cap=d.get("cap"),
        remaining_until_cap=d.get("remaining_until_cap"),
        unit_price=d["unit_price"],
    )


def _parse_topup(d: dict[str, Any]) -> TopupInfo:
    return TopupInfo(
        id=d["id"],
        name=d["name"],
        granted=d["granted"],
        used=d["used"],
        remaining=d["remaining"],
        expires_at=_parse_dt_opt(d.get("expires_at")),
        purchased_at=_parse_dt(d["purchased_at"]),
    )


def parse_credits_summary(data: dict[str, Any]) -> CreditsSummary:
    s = data["summary"]
    return CreditsSummary(
        subscription=_parse_subscription(data.get("subscription")),
        overage=_parse_overage(data.get("overage")),
        topups=tuple(_parse_topup(t) for t in data.get("topups", [])),
        summary=CreditsSummaryTotals(
            total_available=s["total_available"],
            subscription_credits=s["subscription_credits"],
            topup_credits=s["topup_credits"],
            overage_credits=s["overage_credits"],
        ),
    )
