"""Top-level client classes: :class:`GeoInfer` (sync) and :class:`AsyncGeoInfer`."""

from __future__ import annotations

from types import TracebackType

from ._client import _DEFAULT_BASE_URL, _DEFAULT_TIMEOUT, AsyncHTTPClient, SyncHTTPClient
from ._model_cache import _ModelCache
from .resources.credits import AsyncCreditsResource, CreditsResource
from .resources.predictions import AsyncPredictionsResource, PredictionsResource

_DEFAULT_MODEL_CACHE_TTL = 300.0  # 5 minutes


class GeoInfer:
    """Synchronous GeoInfer API client.

    Parameters
    ----------
    api_key:
        Your GeoInfer API key (``geo_...``).
    base_url:
        Override the default API base URL.
    timeout:
        HTTP request timeout in seconds.  Defaults to 60.
    model_cache_ttl:
        How long (seconds) to cache the account's model list before
        re-fetching.  Defaults to 300 (5 minutes).

    Example
    -------
    ::

        from geoinfer import GeoInfer

        client = GeoInfer(api_key="geo_...")

        # Discover which models this account has access to
        models = client.predictions.models()

        # Global model → CoordinatePredictionResult
        result = client.predictions.predict("photo.jpg", model_id="global_v0_1")
        print(result.prediction.clusters[0].location.name)

        # Accuracy model → AccuracyPredictionResult
        result = client.predictions.predict("photo.jpg", model_id="pais_vasco_v0_1")
        print(result.prediction.top_prediction.confidence)

    Can also be used as a context manager::

        with GeoInfer(api_key="geo_...") as client:
            result = client.predictions.predict("photo.jpg", model_id="global_v0_1")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        model_cache_ttl: float = _DEFAULT_MODEL_CACHE_TTL,
    ) -> None:
        self._http = SyncHTTPClient(api_key=api_key, base_url=base_url, timeout=timeout)
        cache = _ModelCache(ttl=model_cache_ttl)
        self.predictions = PredictionsResource(self._http, cache)
        self.credits = CreditsResource(self._http)

    def close(self) -> None:
        """Release underlying HTTP connections."""
        self._http.close()

    def __enter__(self) -> GeoInfer:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        self.close()


class AsyncGeoInfer:
    """Asynchronous GeoInfer API client.

    Parameters
    ----------
    api_key:
        Your GeoInfer API key (``geo_...``).
    base_url:
        Override the default API base URL.
    timeout:
        HTTP request timeout in seconds.  Defaults to 60.
    model_cache_ttl:
        How long (seconds) to cache the account's model list before
        re-fetching.  Defaults to 300 (5 minutes).

    Example
    -------
    ::

        import asyncio
        from geoinfer import AsyncGeoInfer

        async def main():
            async with AsyncGeoInfer(api_key="geo_...") as client:
                result = await client.predictions.predict("photo.jpg", model_id="global_v0_1")
                print(result.prediction.clusters[0].location.name)

        asyncio.run(main())
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        model_cache_ttl: float = _DEFAULT_MODEL_CACHE_TTL,
    ) -> None:
        self._http = AsyncHTTPClient(api_key=api_key, base_url=base_url, timeout=timeout)
        cache = _ModelCache(ttl=model_cache_ttl)
        self.predictions = AsyncPredictionsResource(self._http, cache)
        self.credits = AsyncCreditsResource(self._http)

    async def aclose(self) -> None:
        """Release underlying HTTP connections."""
        await self._http.aclose()

    async def __aenter__(self) -> AsyncGeoInfer:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self.aclose()
