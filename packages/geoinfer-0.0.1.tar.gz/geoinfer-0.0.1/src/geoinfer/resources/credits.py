"""Credits resource — sync and async variants."""

from __future__ import annotations

from .._client import AsyncHTTPClient, SyncHTTPClient
from .._parsers import parse_credits_summary
from ..types import CreditsSummary

_SUMMARY_PATH = "/v1/credits/summary"


class CreditsResource:
    """Synchronous credits resource."""

    def __init__(self, http: SyncHTTPClient) -> None:
        self._http = http

    def summary(self) -> CreditsSummary:
        """Fetch the full credits state for the authenticated account."""
        data, _ = self._http.get(_SUMMARY_PATH)
        return parse_credits_summary(data)


class AsyncCreditsResource:
    """Asynchronous credits resource."""

    def __init__(self, http: AsyncHTTPClient) -> None:
        self._http = http

    async def summary(self) -> CreditsSummary:
        """Fetch the full credits state for the authenticated account (async)."""
        data, _ = await self._http.get(_SUMMARY_PATH)
        return parse_credits_summary(data)
