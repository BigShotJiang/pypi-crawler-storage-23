"""Predictions resource — sync and async variants."""

from __future__ import annotations

import asyncio

from .._client import AsyncHTTPClient, FileInput, SyncHTTPClient
from .._model_cache import _ModelCache
from .._parsers import parse_models, parse_prediction_response
from ..types import (
    Model,
    PredictionResponse,
    PredictionResult,
)

_PREDICT_PATH = "/v1/prediction/predict"
_MODELS_PATH = "/v1/prediction/models"


# ---------------------------------------------------------------------------
# Sync resource
# ---------------------------------------------------------------------------


class PredictionsResource:
    """Synchronous predictions resource."""

    def __init__(self, http: SyncHTTPClient, cache: _ModelCache) -> None:
        self._http = http
        self._cache = cache

    def _ensure_models(self) -> None:
        """Fetch and cache the model list if stale, with a lock to prevent duplicate fetches."""
        if not self._cache.needs_refresh():
            return
        with self._cache._lock:
            if self._cache.needs_refresh():  # double-checked under lock
                data, _ = self._http.get(_MODELS_PATH)
                self._cache.load(parse_models(data))

    def predict(
        self,
        file: FileInput,
        model_id: str,
    ) -> PredictionResponse[PredictionResult]:
        """Submit an image to any model and get a prediction back.

        The model list for this account is fetched on first call and cached for
        5 minutes.  ``model_id`` is validated against the live list before the
        prediction request is sent.

        Parameters
        ----------
        file:
            Path string, :class:`pathlib.Path`, URL string, raw ``bytes``, or
            any file-like object opened in binary mode.
        model_id:
            Model identifier.  Obtain available IDs from :meth:`models`.

        Raises
        ------
        InvalidModelError
            If ``model_id`` is not available on this account or is disabled.
        """
        self._ensure_models()
        self._cache.validate(model_id)
        data, headers = self._http.post_multipart(
            _PREDICT_PATH,
            file=file,
            params={"model_id": model_id},
        )
        return parse_prediction_response(data, headers)  # type: ignore[return-value]

    def models(self) -> list[Model]:
        """Return all models available on this account.

        Results are cached for 5 minutes.  Call this to discover model IDs
        before passing them to :meth:`predict`.
        """
        self._ensure_models()
        return self._cache.all()


# ---------------------------------------------------------------------------
# Async resource
# ---------------------------------------------------------------------------


class AsyncPredictionsResource:
    """Asynchronous predictions resource."""

    def __init__(self, http: AsyncHTTPClient, cache: _ModelCache) -> None:
        self._http = http
        self._cache = cache
        self._refresh_lock: asyncio.Lock = asyncio.Lock()

    async def _ensure_models(self) -> None:
        """Fetch and cache the model list if stale, with an async lock to prevent
        concurrent coroutines from issuing duplicate fetches."""
        if not self._cache.needs_refresh():
            return
        async with self._refresh_lock:
            if self._cache.needs_refresh():  # double-checked under lock
                data, _ = await self._http.get(_MODELS_PATH)
                self._cache.load(parse_models(data))

    async def predict(
        self,
        file: FileInput,
        model_id: str,
    ) -> PredictionResponse[PredictionResult]:
        """Submit an image to any model (async).

        Parameters
        ----------
        file:
            Path string, :class:`pathlib.Path`, URL string, raw ``bytes``, or
            any file-like object opened in binary mode.
        model_id:
            Model identifier.  Obtain available IDs from :meth:`models`.

        Raises
        ------
        InvalidModelError
            If ``model_id`` is not available on this account or is disabled.
        """
        await self._ensure_models()
        self._cache.validate(model_id)
        data, headers = await self._http.post_multipart(
            _PREDICT_PATH,
            file=file,
            params={"model_id": model_id},
        )
        return parse_prediction_response(data, headers)  # type: ignore[return-value]

    async def models(self) -> list[Model]:
        """Return all models available on this account (async).

        Results are cached for 5 minutes.
        """
        await self._ensure_models()
        return self._cache.all()
