"""GeoInfer SDK exceptions."""

from __future__ import annotations


class GeoInferError(Exception):
    """Base exception for all GeoInfer SDK errors."""

    message_code: str
    message: str
    status_code: int | None

    def __init__(
        self,
        message: str,
        *,
        message_code: str = "ERROR",
        status_code: int | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.message_code = message_code
        self.status_code = status_code

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"message_code={self.message_code!r}, "
            f"message={self.message!r}, "
            f"status_code={self.status_code!r})"
        )


class AuthenticationError(GeoInferError):
    """Raised on 401 — missing or invalid API key."""


class InsufficientCreditsError(GeoInferError):
    """Raised on 402 — not enough credits to complete the request."""


class ForbiddenError(GeoInferError):
    """Raised on 403 — access forbidden."""


class FileTooLargeError(GeoInferError):
    """Raised on 413 — uploaded file exceeds the 10 MB limit."""


class InvalidFileTypeError(GeoInferError):
    """Raised on 422 — file format is not supported."""


class InvalidModelError(GeoInferError):
    """Raised when a model_id is not available on this account, is disabled,
    or belongs to the wrong model type for the called method."""


class RateLimitError(GeoInferError):
    """Raised on 429 — rate limit exceeded.

    Attributes
    ----------
    retry_after:
        Number of seconds to wait before retrying, sourced from the
        ``Retry-After`` response header when available.
    """

    retry_after: int | None

    def __init__(
        self,
        message: str,
        *,
        message_code: str = "RATE_LIMITED",
        status_code: int | None = 429,
        retry_after: int | None = None,
    ) -> None:
        super().__init__(message, message_code=message_code, status_code=status_code)
        self.retry_after = retry_after

    def __repr__(self) -> str:
        return (
            f"{type(self).__name__}("
            f"message_code={self.message_code!r}, "
            f"message={self.message!r}, "
            f"status_code={self.status_code!r}, "
            f"retry_after={self.retry_after!r})"
        )


class APIError(GeoInferError):
    """Raised for unexpected non-2xx responses not covered by a specific subclass."""
