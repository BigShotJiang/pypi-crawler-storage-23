"""GeoInfer SDK type definitions.

All public types are frozen dataclasses — lightweight, introspectable, and
dependency-free.  Sequence fields use ``tuple`` (not ``list``) so that
``frozen=True`` actually guarantees immutability.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Generic, Literal, Optional, TypeVar, Union

# Generic parameter for PredictionResponse[T]
_T = TypeVar("_T")


# ---------------------------------------------------------------------------
# Shared sub-types
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class LatLon:
    latitude: float
    longitude: float


@dataclass(frozen=True)
class Location:
    name: str
    admin1: str
    admin2: str
    country_code: str


# ---------------------------------------------------------------------------
# Coordinate prediction (global model)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Cluster:
    center: LatLon
    location: Location
    radius_km: float
    points: tuple[LatLon, ...]


@dataclass(frozen=True)
class CoordinatePredictionResult:
    result_type: Literal["coordinates"]
    clusters: tuple[Cluster, ...]
    processing_time_ms: float


# ---------------------------------------------------------------------------
# Accuracy prediction (accuracy / regional models)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AccuracyPrediction:
    latitude: float
    longitude: float
    confidence: float
    rank: int
    likely_pano_id: Optional[str]
    location: Optional[Location]


@dataclass(frozen=True)
class AccuracyPredictionResult:
    result_type: Literal["accuracy"]
    predictions: tuple[AccuracyPrediction, ...]
    top_prediction: Optional[AccuracyPrediction]
    processing_time_ms: float


# Discriminated union — narrow on ``result_type``
PredictionResult = Union[CoordinatePredictionResult, AccuracyPredictionResult]


# ---------------------------------------------------------------------------
# Rate-limit metadata surfaced on prediction responses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class RateLimitInfo:
    """Values parsed from rate-limit response headers."""

    limit: Optional[int] = None
    remaining: Optional[int] = None
    reset: Optional[int] = None
    window: Optional[int] = None


# ---------------------------------------------------------------------------
# Prediction response wrapper — generic so the type checker narrows .prediction
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PredictionResponse(Generic[_T]):
    """Wrapper returned by :meth:`~geoinfer.GeoInfer.predictions.predict`.

    The ``prediction`` attribute is narrowed to
    :class:`CoordinatePredictionResult` or :class:`AccuracyPredictionResult`
    depending on which method was called.
    """

    prediction_id: str
    model_id: str
    credits_consumed: float
    prediction: _T
    rate_limit: RateLimitInfo = field(default_factory=RateLimitInfo)


# ---------------------------------------------------------------------------
# Models list
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Model:
    model_id: str
    model_type: Literal["GLOBAL", "ACCURACY"]
    enabled: bool
    credits_per_use: float


# ---------------------------------------------------------------------------
# Credits
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SubscriptionInfo:
    id: str
    monthly_allowance: float
    granted_this_period: float
    used_this_period: float
    remaining: float
    period_start: datetime
    period_end: datetime
    status: str
    billing_interval: str
    price_paid: float
    overage_unit_price: float
    cancel_at_period_end: bool
    pause_access: bool


@dataclass(frozen=True)
class OverageInfo:
    enabled: bool
    used: float
    reported_to_stripe: float
    cap: Optional[float]
    remaining_until_cap: Optional[float]
    unit_price: float


@dataclass(frozen=True)
class TopupInfo:
    id: str
    name: str
    granted: float
    used: float
    remaining: float
    expires_at: Optional[datetime]
    purchased_at: datetime


@dataclass(frozen=True)
class CreditsSummaryTotals:
    total_available: float
    subscription_credits: float
    topup_credits: float
    overage_credits: float


@dataclass(frozen=True)
class CreditsSummary:
    subscription: Optional[SubscriptionInfo]
    overage: Optional[OverageInfo]
    topups: tuple[TopupInfo, ...]
    summary: CreditsSummaryTotals
