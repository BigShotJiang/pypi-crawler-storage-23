"""Tests for error handling — HTTP error responses and client-side validation."""

from __future__ import annotations

import httpx
import pytest
import respx

from geoinfer import (
    APIError,
    AuthenticationError,
    FileTooLargeError,
    ForbiddenError,
    GeoInfer,
    InsufficientCreditsError,
    InvalidFileTypeError,
    RateLimitError,
)

from .conftest import MODELS_RESPONSE, JPEG_1x1

BASE = "https://api.geoinfer.com"

# One models mock is needed before every prediction call so the cache is warm.
_MODELS_MOCK = lambda: respx.get(f"{BASE}/v1/prediction/models").mock(  # noqa: E731
    return_value=httpx.Response(200, json=MODELS_RESPONSE)
)


def _error_body(message_code: str, message: str) -> dict:
    return {"message_code": message_code, "message": message}


@respx.mock
def test_401_raises_authentication_error():
    _MODELS_MOCK()
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(401, json=_error_body("UNAUTHORIZED", "Invalid API key"))
    )
    client = GeoInfer(api_key="geo_bad")
    with pytest.raises(AuthenticationError) as exc_info:
        client.predictions.predict(JPEG_1x1, model_id="global_v0_1")
    assert exc_info.value.status_code == 401
    assert exc_info.value.message_code == "UNAUTHORIZED"


@respx.mock
def test_402_raises_insufficient_credits():
    _MODELS_MOCK()
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(
            402, json=_error_body("INSUFFICIENT_CREDITS", "Not enough credits")
        )
    )
    client = GeoInfer(api_key="geo_test")
    with pytest.raises(InsufficientCreditsError) as exc_info:
        client.predictions.predict(JPEG_1x1, model_id="global_v0_1")
    assert exc_info.value.status_code == 402


@respx.mock
def test_403_raises_forbidden_error():
    _MODELS_MOCK()
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(403, json=_error_body("FORBIDDEN", "Access denied"))
    )
    client = GeoInfer(api_key="geo_test")
    with pytest.raises(ForbiddenError) as exc_info:
        client.predictions.predict(JPEG_1x1, model_id="global_v0_1")
    assert exc_info.value.status_code == 403


@respx.mock
def test_413_raises_file_too_large():
    _MODELS_MOCK()
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(413, json=_error_body("FILE_TOO_LARGE", "Max 10 MB"))
    )
    client = GeoInfer(api_key="geo_test")
    with pytest.raises(FileTooLargeError):
        client.predictions.predict(JPEG_1x1, model_id="global_v0_1")


@respx.mock
def test_422_raises_invalid_file_type():
    _MODELS_MOCK()
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(
            422, json=_error_body("INVALID_FILE_TYPE", "Unsupported format")
        )
    )
    client = GeoInfer(api_key="geo_test")
    with pytest.raises(InvalidFileTypeError):
        client.predictions.predict(JPEG_1x1, model_id="global_v0_1")


@respx.mock
def test_429_raises_rate_limit_error_with_retry_after():
    _MODELS_MOCK()
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(
            429,
            json=_error_body("RATE_LIMITED", "Too many requests"),
            headers={"Retry-After": "42"},
        )
    )
    client = GeoInfer(api_key="geo_test")
    with pytest.raises(RateLimitError) as exc_info:
        client.predictions.predict(JPEG_1x1, model_id="global_v0_1")
    err = exc_info.value
    assert err.status_code == 429
    assert err.retry_after == 42


@respx.mock
def test_429_without_retry_after_header():
    _MODELS_MOCK()
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(429, json=_error_body("RATE_LIMITED", "Too many requests"))
    )
    client = GeoInfer(api_key="geo_test")
    with pytest.raises(RateLimitError) as exc_info:
        client.predictions.predict(JPEG_1x1, model_id="global_v0_1")
    assert exc_info.value.retry_after is None


@respx.mock
def test_500_raises_api_error():
    _MODELS_MOCK()
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    client = GeoInfer(api_key="geo_test")
    with pytest.raises(APIError) as exc_info:
        client.predictions.predict(JPEG_1x1, model_id="global_v0_1")
    assert exc_info.value.status_code == 500


@respx.mock
def test_non_dict_json_error_body_does_not_crash():
    """A JSON array error body (not a dict) must not cause AttributeError."""
    _MODELS_MOCK()
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(500, json=["unexpected", "array"])
    )
    client = GeoInfer(api_key="geo_test")
    with pytest.raises(APIError):
        client.predictions.predict(JPEG_1x1, model_id="global_v0_1")


@respx.mock
def test_non_json_error_body_does_not_crash():
    """Plain-text error body must still surface as APIError."""
    _MODELS_MOCK()
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(503, text="Service Unavailable")
    )
    client = GeoInfer(api_key="geo_test")
    with pytest.raises(APIError) as exc_info:
        client.predictions.predict(JPEG_1x1, model_id="global_v0_1")
    assert "Service Unavailable" in exc_info.value.message


@respx.mock
def test_rate_limit_error_repr_includes_retry_after():
    err = RateLimitError("Too many requests", retry_after=30)
    r = repr(err)
    assert "retry_after=30" in r
    assert "RATE_LIMITED" in r


def test_missing_data_envelope_raises_api_error():
    """_unwrap must raise APIError when the 'data' key is absent."""
    from geoinfer import APIError
    from geoinfer._client import _unwrap

    with pytest.raises(APIError, match="missing 'data' envelope"):
        _unwrap({"message_code": "SUCCESS", "message": "ok"})
