"""Tests for the credits resource."""

from __future__ import annotations

import httpx
import respx

from geoinfer import AsyncGeoInfer, GeoInfer

from .conftest import CREDITS_RESPONSE

BASE = "https://api.geoinfer.com"


@respx.mock
def test_credits_summary_parsed():
    respx.get(f"{BASE}/v1/credits/summary").mock(
        return_value=httpx.Response(200, json=CREDITS_RESPONSE)
    )

    client = GeoInfer(api_key="geo_test")
    summary = client.credits.summary()

    assert summary.summary.total_available == 127
    assert summary.summary.subscription_credits == 0
    assert summary.summary.topup_credits == 127
    assert summary.summary.overage_credits == 0
    assert summary.subscription is None
    assert summary.overage is None


@respx.mock
def test_credits_topup_parsed():
    respx.get(f"{BASE}/v1/credits/summary").mock(
        return_value=httpx.Response(200, json=CREDITS_RESPONSE)
    )

    client = GeoInfer(api_key="geo_test")
    summary = client.credits.summary()

    assert len(summary.topups) == 1
    assert isinstance(summary.topups, tuple)

    topup = summary.topups[0]
    assert topup.id == "d10f5b23-7c6e-4d3a-998c-c93c15dd1379"
    assert topup.name == "Geoinfer Trial Credits"
    assert topup.granted == 300
    assert topup.used == 173
    assert topup.remaining == 127

    # Timestamps should be parsed as aware datetimes
    assert topup.expires_at is not None
    assert topup.expires_at.tzinfo is not None
    assert topup.purchased_at.tzinfo is not None
    assert topup.expires_at.year == 2027
    assert topup.purchased_at.year == 2026


@respx.mock
async def test_async_credits_summary():
    respx.get(f"{BASE}/v1/credits/summary").mock(
        return_value=httpx.Response(200, json=CREDITS_RESPONSE)
    )

    async with AsyncGeoInfer(api_key="geo_test") as client:
        summary = await client.credits.summary()

    assert summary.summary.total_available == 127
    assert len(summary.topups) == 1
