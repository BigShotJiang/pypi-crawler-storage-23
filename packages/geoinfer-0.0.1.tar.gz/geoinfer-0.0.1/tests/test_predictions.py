"""Tests for the predictions resource — sync and async, with mocked HTTP."""

from __future__ import annotations

import io

import httpx
import pytest
import respx

from geoinfer import AsyncGeoInfer, GeoInfer, InvalidModelError
from geoinfer.types import AccuracyPredictionResult, CoordinatePredictionResult

from .conftest import (
    MODELS_RESPONSE,
    PREDICT_ACCURACY_RESPONSE,
    PREDICT_GLOBAL_RESPONSE,
    RATE_LIMIT_HEADERS,
    JPEG_1x1,
)

BASE = "https://api.geoinfer.com"


# ---------------------------------------------------------------------------
# Sync — predict (global model)
# ---------------------------------------------------------------------------


@respx.mock
def test_predict_returns_coordinate_result():
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(200, json=PREDICT_GLOBAL_RESPONSE, headers=RATE_LIMIT_HEADERS)
    )

    client = GeoInfer(api_key="geo_test")
    result = client.predictions.predict(JPEG_1x1, model_id="global_v0_1")

    assert result.prediction_id == "ebe9c79a-5045-4396-802d-506c56bf1402"
    assert result.model_id == "global_v0_1"
    assert result.credits_consumed == 1
    assert isinstance(result.prediction, CoordinatePredictionResult)
    assert result.prediction.result_type == "coordinates"
    assert len(result.prediction.clusters) == 1

    top = result.prediction.clusters[0]
    assert top.location.name == "Blackley"
    assert top.location.country_code == "GB"
    assert top.center.latitude == pytest.approx(53.4936)
    assert top.center.longitude == pytest.approx(-2.1996)
    assert len(top.points) == 2

    # Clusters and points must be tuples (frozen dataclass immutability)
    assert isinstance(result.prediction.clusters, tuple)
    assert isinstance(top.points, tuple)


@respx.mock
def test_predict_rate_limit_headers_parsed():
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(200, json=PREDICT_GLOBAL_RESPONSE, headers=RATE_LIMIT_HEADERS)
    )

    client = GeoInfer(api_key="geo_test")
    result = client.predictions.predict(JPEG_1x1, model_id="global_v0_1")

    rl = result.rate_limit
    assert rl.limit == 60
    assert rl.remaining == 59
    assert rl.reset == 30
    assert rl.window == 60


@respx.mock
def test_predict_accepts_path_string(tmp_path):
    img = tmp_path / "photo.jpg"
    img.write_bytes(JPEG_1x1)

    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(200, json=PREDICT_GLOBAL_RESPONSE, headers={})
    )

    client = GeoInfer(api_key="geo_test")
    result = client.predictions.predict(str(img), model_id="global_v0_1")
    assert result.prediction.result_type == "coordinates"


@respx.mock
def test_predict_accepts_file_object(tmp_path):
    img = tmp_path / "photo.jpg"
    img.write_bytes(JPEG_1x1)

    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(200, json=PREDICT_GLOBAL_RESPONSE, headers={})
    )

    client = GeoInfer(api_key="geo_test")
    with open(img, "rb") as f:
        result = client.predictions.predict(f, model_id="global_v0_1")
    assert result.prediction.result_type == "coordinates"


def test_predict_text_mode_file_raises():
    client = GeoInfer(api_key="geo_test")
    buf = io.StringIO("not binary")
    with pytest.raises(TypeError, match="binary mode"):
        client.predictions.predict(buf, model_id="global_v0_1")  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Sync — predict (accuracy / regional model)
# ---------------------------------------------------------------------------


@respx.mock
def test_predict_returns_accuracy_result():
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(200, json=PREDICT_ACCURACY_RESPONSE, headers={})
    )

    client = GeoInfer(api_key="geo_test")
    result = client.predictions.predict(JPEG_1x1, model_id="pais_vasco_v0_1")

    assert isinstance(result.prediction, AccuracyPredictionResult)
    assert result.prediction.result_type == "accuracy"
    assert result.credits_consumed == 3
    assert len(result.prediction.predictions) == 2
    assert isinstance(result.prediction.predictions, tuple)

    top = result.prediction.top_prediction
    assert top is not None
    assert top.rank == 1
    assert top.confidence == pytest.approx(0.94)
    assert top.location is not None
    assert top.location.name == "Ibarra"

    # Second prediction has no location
    second = result.prediction.predictions[1]
    assert second.location is None


# ---------------------------------------------------------------------------
# Sync — model validation
# ---------------------------------------------------------------------------


@respx.mock
def test_predict_unknown_model_raises_invalid_model_error():
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )

    client = GeoInfer(api_key="geo_test")
    with pytest.raises(InvalidModelError, match="not available"):
        client.predictions.predict(JPEG_1x1, model_id="nonexistent_model")


@respx.mock
def test_disabled_model_raises_invalid_model_error():
    disabled_models = {
        **MODELS_RESPONSE,
        "data": [
            {**MODELS_RESPONSE["data"][0], "enabled": False},
            MODELS_RESPONSE["data"][1],
        ],
    }
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=disabled_models)
    )

    client = GeoInfer(api_key="geo_test")
    with pytest.raises(InvalidModelError, match="disabled"):
        client.predictions.predict(JPEG_1x1, model_id="global_v0_1")


# ---------------------------------------------------------------------------
# Sync — models()
# ---------------------------------------------------------------------------


@respx.mock
def test_models_returns_parsed_list():
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )

    client = GeoInfer(api_key="geo_test")
    models = client.predictions.models()

    assert len(models) == 2
    global_m = next(m for m in models if m.model_id == "global_v0_1")
    assert global_m.model_type == "GLOBAL"
    assert global_m.enabled is True
    assert global_m.credits_per_use == 1.0

    accuracy_m = next(m for m in models if m.model_id == "pais_vasco_v0_1")
    assert accuracy_m.model_type == "ACCURACY"


@respx.mock
def test_models_fetched_only_once_within_ttl():
    route = respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )

    client = GeoInfer(api_key="geo_test", model_cache_ttl=300)
    client.predictions.models()
    client.predictions.models()
    client.predictions.models()

    assert route.call_count == 1


# ---------------------------------------------------------------------------
# Async — predict
# ---------------------------------------------------------------------------


@respx.mock
async def test_async_predict_returns_coordinate_result():
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(200, json=PREDICT_GLOBAL_RESPONSE, headers=RATE_LIMIT_HEADERS)
    )

    async with AsyncGeoInfer(api_key="geo_test") as client:
        result = await client.predictions.predict(JPEG_1x1, model_id="global_v0_1")

    assert isinstance(result.prediction, CoordinatePredictionResult)
    assert result.prediction.result_type == "coordinates"
    assert len(result.prediction.clusters) == 1
    assert result.rate_limit.remaining == 59


@respx.mock
async def test_async_predict_returns_accuracy_result():
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(200, json=PREDICT_ACCURACY_RESPONSE, headers={})
    )

    async with AsyncGeoInfer(api_key="geo_test") as client:
        result = await client.predictions.predict(JPEG_1x1, model_id="pais_vasco_v0_1")

    assert isinstance(result.prediction, AccuracyPredictionResult)
    assert result.prediction.top_prediction is not None
    assert result.prediction.top_prediction.confidence == pytest.approx(0.94)


@respx.mock
async def test_async_unknown_model_raises():
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )

    async with AsyncGeoInfer(api_key="geo_test") as client:
        with pytest.raises(InvalidModelError):
            await client.predictions.predict(JPEG_1x1, model_id="bad_model")


# ---------------------------------------------------------------------------
# URL input
# ---------------------------------------------------------------------------

IMAGE_URL = "https://example.com/photo.jpg"


@respx.mock
def test_predict_accepts_https_url():
    respx.get(IMAGE_URL).mock(
        return_value=httpx.Response(200, content=JPEG_1x1, headers={"content-type": "image/jpeg"})
    )
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(200, json=PREDICT_GLOBAL_RESPONSE, headers={})
    )

    client = GeoInfer(api_key="geo_test")
    result = client.predictions.predict(IMAGE_URL, model_id="global_v0_1")
    assert isinstance(result.prediction, CoordinatePredictionResult)
    assert result.prediction.result_type == "coordinates"


@respx.mock
def test_predict_url_non_200_raises_value_error():
    respx.get(IMAGE_URL).mock(return_value=httpx.Response(404))
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )

    client = GeoInfer(api_key="geo_test")
    with pytest.raises(ValueError, match="Failed to fetch image"):
        client.predictions.predict(IMAGE_URL, model_id="global_v0_1")


@respx.mock
def test_predict_url_mime_type_from_content_type_header():
    """MIME type is taken from Content-Type response header when present."""
    respx.get(IMAGE_URL).mock(
        return_value=httpx.Response(
            200, content=JPEG_1x1, headers={"content-type": "image/jpeg; charset=binary"}
        )
    )
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )
    predict_route = respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(200, json=PREDICT_GLOBAL_RESPONSE, headers={})
    )

    client = GeoInfer(api_key="geo_test")
    client.predictions.predict(IMAGE_URL, model_id="global_v0_1")
    # Verify a prediction request was actually sent (URL was fetched and uploaded)
    assert predict_route.called


@respx.mock
def test_predict_url_filename_extracted_from_url_path():
    """Filename is derived from the URL path."""
    url = "https://cdn.example.com/images/street_view.jpg?v=2"
    respx.get(url).mock(
        return_value=httpx.Response(200, content=JPEG_1x1, headers={"content-type": "image/jpeg"})
    )
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(200, json=PREDICT_GLOBAL_RESPONSE, headers={})
    )

    client = GeoInfer(api_key="geo_test")
    result = client.predictions.predict(url, model_id="global_v0_1")
    assert result.prediction.result_type == "coordinates"


@respx.mock
async def test_async_predict_accepts_url():
    respx.get(IMAGE_URL).mock(
        return_value=httpx.Response(200, content=JPEG_1x1, headers={"content-type": "image/jpeg"})
    )
    respx.get(f"{BASE}/v1/prediction/models").mock(
        return_value=httpx.Response(200, json=MODELS_RESPONSE)
    )
    respx.post(f"{BASE}/v1/prediction/predict").mock(
        return_value=httpx.Response(200, json=PREDICT_GLOBAL_RESPONSE, headers={})
    )

    async with AsyncGeoInfer(api_key="geo_test") as client:
        result = await client.predictions.predict(IMAGE_URL, model_id="global_v0_1")

    assert isinstance(result.prediction, CoordinatePredictionResult)
