"""UV boost module."""

from pimp_my_repo.core.boost.uv.uv import UvBoost

__all__ = ["UvBoost"]
