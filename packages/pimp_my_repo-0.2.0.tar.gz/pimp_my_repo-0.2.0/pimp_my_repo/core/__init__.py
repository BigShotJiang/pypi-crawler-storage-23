"""Core modules for pimp-my-repo."""

from pimp_my_repo.core.git import GitManager

__all__ = ["GitManager"]
