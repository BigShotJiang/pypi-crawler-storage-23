"""Models for pimp-my-repo."""

from pimp_my_repo.models.result import BoostResult, RunResult

__all__ = ["BoostResult", "RunResult"]
