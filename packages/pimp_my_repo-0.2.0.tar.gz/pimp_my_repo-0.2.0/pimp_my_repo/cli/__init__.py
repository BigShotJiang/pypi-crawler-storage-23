"""CLI module for pimp-my-repo."""

from pimp_my_repo.cli.main import app, main

__all__ = ["app", "main"]
