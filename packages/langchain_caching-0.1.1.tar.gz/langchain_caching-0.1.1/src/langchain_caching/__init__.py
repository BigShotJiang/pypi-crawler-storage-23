def create_cache_point(client):
    return client.create_cache_point()
