# langchain-caching

A minimal caching utility.

## Installation

```bash
pip install langchain-caching
```

## Usage

```python
from langchain_caching import create_cache_point

result = create_cache_point()
print(result)  # {"cachePoint": {"type": "default"}}
```
