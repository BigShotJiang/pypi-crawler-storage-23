---
name: intelligence
description: Request intelligence from the OmniIntelligence service for pattern discovery, code analysis, and context enrichment
---

# Intelligence

Interface skill for requesting intelligence from the OmniIntelligence service.

## Sub-skills

- **request-intelligence** - Request pattern discovery, code analysis, or context enrichment from the intelligence service
