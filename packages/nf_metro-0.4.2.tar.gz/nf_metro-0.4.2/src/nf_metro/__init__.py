"""nf-metro: Generate metro-map-style SVG diagrams from Mermaid graph definitions."""

__version__ = "0.4.2"

__all__ = ["__version__"]
