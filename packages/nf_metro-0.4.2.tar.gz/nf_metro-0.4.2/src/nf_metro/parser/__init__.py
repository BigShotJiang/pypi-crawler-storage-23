"""Mermaid + metro directive parser."""

from nf_metro.parser.mermaid import parse_metro_mermaid

__all__ = ["parse_metro_mermaid"]
