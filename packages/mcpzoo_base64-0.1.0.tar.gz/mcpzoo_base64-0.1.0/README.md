# mcpzoo-base64

> Base64 编解码 — 对文本进行 Base64 编码或解码

## Installation

```bash
uvx mcpzoo-base64
```

## uvx JSON

```json
{
  "mcpServers": {
    "base64": {
      "args": ["mcpzoo-base64"],
      "command": "uvx"
    }
  }
}
```
