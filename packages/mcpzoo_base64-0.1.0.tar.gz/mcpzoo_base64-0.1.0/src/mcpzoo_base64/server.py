import base64 as b64
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("base64")


@mcp.tool()
def base64_encode(text: str) -> str:
    """将文本进行 Base64 编码。"""
    return b64.b64encode(text.encode("utf-8")).decode("ascii")


@mcp.tool()
def base64_decode(text: str) -> str:
    """将 Base64 编码的字符串解码为原始文本。"""
    try:
        return b64.b64decode(text).decode("utf-8")
    except Exception as e:
        return f"解码失败: {e}"


def main():
    mcp.run()


if __name__ == "__main__":
    main()
