# src/emotionics/__init__.py
from .core import activate, estimate

__all__ = ["activate", "estimate"]
__version__ = "0.1.2"