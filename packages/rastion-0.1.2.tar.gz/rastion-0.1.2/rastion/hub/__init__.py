"""Hub client public API."""

from rastion.hub.client import HubClient, HubClientError

__all__ = ["HubClient", "HubClientError"]
