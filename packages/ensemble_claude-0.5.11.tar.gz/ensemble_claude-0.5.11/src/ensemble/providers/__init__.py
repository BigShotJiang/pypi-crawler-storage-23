"""Issue providers for different code hosting platforms."""

from ensemble.providers.github import GitHubProvider

__all__ = ["GitHubProvider"]
