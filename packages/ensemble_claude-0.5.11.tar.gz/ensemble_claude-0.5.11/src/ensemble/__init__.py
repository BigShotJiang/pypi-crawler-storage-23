"""Ensemble AI Orchestration - Multi-agent orchestration for Claude Code."""

__version__ = "0.5.11"
__author__ = "Ensemble Team"

