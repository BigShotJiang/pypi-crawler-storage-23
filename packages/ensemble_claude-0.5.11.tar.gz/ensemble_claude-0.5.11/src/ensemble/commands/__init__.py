"""Ensemble CLI commands."""
