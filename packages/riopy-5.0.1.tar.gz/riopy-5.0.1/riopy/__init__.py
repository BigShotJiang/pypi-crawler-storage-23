from .sessions import SQLiteSession, StringSession
from .client import Client
from .rubino import Rubino
from . import _types as types, utils, filters, exceptions, enums, sync
from .bot import BotClient
from . import bot
from .plugins import Plugin, PluginManager, PluginMeta

# اضافه کردن این خط برای جلوگیری از circular import
__author__ = 'Riopy Project'
__version__ = '5.0.1'
__license__ = 'GNU Lesser General Public License v3 (LGPLv3)'
__welcome__ = (
    f'Welcome to riopy (version {__version__})\n'
    'Riopy is free software and comes with ABSOLUTELY NO WARRANTY. Licensed\n'
    f'under the terms of the {__license__}.\n\n'
)
