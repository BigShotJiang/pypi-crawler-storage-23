from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class Policy:
    """Simple policy hook for future authorization controls."""

    def allow_read(self, pipeline_id: str, op: str, resource: str) -> bool:
        del pipeline_id, op, resource
        return True

    def allow_write(self, pipeline_id: str, op: str, resource: str) -> bool:
        del pipeline_id, op, resource
        return True
