"""Tests for Pydantic schema validation on DataFrames."""

import polars as pl
import pytest
from pydantic import BaseModel

from rowbase.errors import SchemaError
from rowbase.schema import validate_dataframe


class Product(BaseModel):
    sku: str
    name: str
    price: float


class TestValidateDataframe:
    def test_all_valid(self):
        df = pl.DataFrame(
            {
                "sku": ["A1", "B2"],
                "name": ["Widget", "Gadget"],
                "price": [9.99, 19.99],
            }
        )
        result_df, errors = validate_dataframe(df, Product)
        assert result_df.shape == (2, 3)
        assert errors == []

    def test_fail_mode_raises_on_first_error(self):
        df = pl.DataFrame(
            {
                "sku": [None, "B2"],
                "name": ["Widget", "Gadget"],
                "price": [9.99, 19.99],
            }
        )
        with pytest.raises(SchemaError, match="Row 0 failed"):
            validate_dataframe(df, Product, on_error="fail")

    def test_skip_mode_drops_invalid_rows(self):
        df = pl.DataFrame(
            {
                "sku": ["A1", None, "C3"],
                "name": ["Widget", "Gadget", "Doohickey"],
                "price": [9.99, 19.99, 29.99],
            }
        )
        result_df, errors = validate_dataframe(df, Product, on_error="skip")
        assert result_df.shape[0] == 2
        assert errors == []

    def test_collect_mode_returns_errors(self):
        df = pl.DataFrame(
            {
                "sku": [None, "B2", None],
                "name": ["Widget", "Gadget", "Thing"],
                "price": [9.99, 19.99, 29.99],
            }
        )
        result_df, errors = validate_dataframe(df, Product, on_error="collect")
        assert result_df.shape[0] == 1  # only B2 valid
        assert len(errors) == 2
        assert all(e.code == "OUTPUT_SCHEMA_ERROR" for e in errors)

    def test_empty_dataframe(self):
        df = pl.DataFrame({"sku": [], "name": [], "price": []}).cast(
            {"sku": pl.Utf8, "name": pl.Utf8, "price": pl.Float64}
        )
        result_df, errors = validate_dataframe(df, Product)
        assert result_df.shape[0] == 0
        assert errors == []

    def test_all_invalid_returns_empty(self):
        df = pl.DataFrame(
            {
                "sku": [None, None],
                "name": ["A", "B"],
                "price": [1.0, 2.0],
            }
        )
        result_df, errors = validate_dataframe(df, Product, on_error="collect")
        assert result_df.shape[0] == 0
        assert len(errors) == 2

    def test_schema_error_has_row_index(self):
        df = pl.DataFrame(
            {
                "sku": ["A", None],
                "name": ["X", "Y"],
                "price": [1.0, 2.0],
            }
        )
        with pytest.raises(SchemaError) as exc_info:
            validate_dataframe(df, Product, on_error="fail")
        assert exc_info.value.row_index == 1
