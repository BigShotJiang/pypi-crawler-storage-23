"""Tests for YAML config loading and access."""

from pathlib import Path

import pytest
import yaml

from rowbase.config import Config, reset_config
from rowbase.errors import ConfigError


@pytest.fixture(autouse=True)
def _reset():
    """Reset global config singleton between tests."""
    reset_config()
    yield
    reset_config()


@pytest.fixture()
def config_file(tmp_path):
    """Create a rowbase.yaml in a temp dir and return the path."""

    def _write(data: dict) -> Path:
        path = tmp_path / "rowbase.yaml"
        with open(path, "w") as f:
            yaml.dump(data, f)
        return path

    return _write


class TestConfigLoad:
    def test_load_basic(self, config_file):
        path = config_file(
            {
                "name": "my_pipeline",
                "config": {"domestic_countries": ["US", "PR"]},
            }
        )
        cfg = Config.load(path)
        assert cfg.get("domestic_countries") == ["US", "PR"]

    def test_load_missing_file_returns_empty(self, tmp_path):
        cfg = Config.load(tmp_path / "nonexistent.yaml")
        assert cfg.get("anything") is None

    def test_load_empty_file(self, config_file):
        path = config_file({})
        cfg = Config.load(path)
        assert cfg.get("anything") is None

    def test_load_no_config_section(self, config_file):
        path = config_file({"name": "test"})
        cfg = Config.load(path)
        assert cfg.get("anything") is None

    def test_invalid_yaml(self, tmp_path):
        path = tmp_path / "rowbase.yaml"
        path.write_text(": : : bad yaml [[[")
        with pytest.raises(ConfigError, match="Failed to parse"):
            Config.load(path)

    def test_non_dict_config_section(self, config_file):
        path = config_file({"config": "not a dict"})
        with pytest.raises(ConfigError, match="must be a mapping"):
            Config.load(path)


class TestConfigGet:
    def test_get_simple_key(self, config_file):
        path = config_file({"config": {"key": "value"}})
        cfg = Config.load(path)
        assert cfg.get("key") == "value"

    def test_get_default(self, config_file):
        path = config_file({"config": {}})
        cfg = Config.load(path)
        assert cfg.get("missing", "default") == "default"

    def test_get_nested_dot_notation(self, config_file):
        path = config_file({"config": {"db": {"host": "localhost", "port": 5432}}})
        cfg = Config.load(path)
        assert cfg.get("db.host") == "localhost"
        assert cfg.get("db.port") == 5432

    def test_env_var_override(self, config_file, monkeypatch):
        path = config_file({"config": {"key": "from_yaml"}})
        monkeypatch.setenv("ROWBASE_CONFIG_KEY", "from_env")
        cfg = Config.load(path)
        assert cfg.get("key") == "from_env"

    def test_env_var_json_parsing(self, config_file, monkeypatch):
        path = config_file({"config": {}})
        monkeypatch.setenv("ROWBASE_CONFIG_COUNTRIES", '["US","CA"]')
        cfg = Config.load(path)
        assert cfg.get("countries") == ["US", "CA"]

    def test_env_var_plain_string(self, config_file, monkeypatch):
        path = config_file({"config": {}})
        monkeypatch.setenv("ROWBASE_CONFIG_NAME", "hello")
        cfg = Config.load(path)
        assert cfg.get("name") == "hello"
