"""Tests for file readers."""

import polars as pl
import pytest

from rowbase._internal.registry import SourceMetadata
from rowbase.errors import RowbaseError
from rowbase.io.readers import read_source


@pytest.fixture()
def sample_csv(tmp_path):
    path = tmp_path / "orders.csv"
    df = pl.DataFrame({"email": ["a@b.com", "c@d.com"], "total": [9.99, 19.99]})
    df.write_csv(path)
    return path


@pytest.fixture()
def sample_parquet(tmp_path):
    path = tmp_path / "orders.parquet"
    df = pl.DataFrame({"email": ["a@b.com", "c@d.com"], "total": [9.99, 19.99]})
    df.write_parquet(path)
    return path


class TestReadSource:
    def test_read_csv(self, sample_csv):
        meta = SourceMetadata(name="orders")
        df = read_source(sample_csv, meta)
        assert df.shape == (2, 2)
        assert "email" in df.columns

    def test_read_parquet(self, sample_parquet):
        meta = SourceMetadata(name="orders")
        df = read_source(sample_parquet, meta)
        assert df.shape == (2, 2)

    def test_file_not_found(self, tmp_path):
        meta = SourceMetadata(name="orders")
        with pytest.raises(RowbaseError, match="FILE_NOT_FOUND"):
            read_source(tmp_path / "nonexistent.csv", meta)

    def test_unsupported_format(self, tmp_path):
        path = tmp_path / "data.json"
        path.write_text('{"a": 1}')
        meta = SourceMetadata(name="data")
        with pytest.raises(RowbaseError, match="Unsupported file format"):
            read_source(path, meta)

    def test_column_validation_passes(self, sample_csv):
        meta = SourceMetadata(name="orders", columns=["email", "total"])
        df = read_source(sample_csv, meta)
        assert df.shape == (2, 2)

    def test_column_validation_fails(self, sample_csv):
        meta = SourceMetadata(name="orders", columns=["email", "shipping_country"])
        with pytest.raises(RowbaseError, match="SCHEMA_MISMATCH"):
            read_source(sample_csv, meta)

    def test_column_validation_dict(self, sample_csv):
        meta = SourceMetadata(name="orders", columns={"email": str, "total": float})
        df = read_source(sample_csv, meta)
        assert df.shape == (2, 2)


class TestReaderOptions:
    def test_csv_skip_rows(self, tmp_path):
        path = tmp_path / "data.csv"
        path.write_text("junk line\nemail,total\na@b.com,9.99\n")
        meta = SourceMetadata(name="data", reader_options={"skip_rows": 1})
        df = read_source(path, meta)
        assert "email" in df.columns
        assert df.shape[0] == 1

    def test_csv_separator(self, tmp_path):
        path = tmp_path / "data.csv"
        path.write_text("email\ttotal\na@b.com\t9.99\n")
        meta = SourceMetadata(name="data", reader_options={"separator": "\t"})
        df = read_source(path, meta)
        assert "email" in df.columns
        assert df.shape[0] == 1

    def test_csv_no_header(self, tmp_path):
        path = tmp_path / "data.csv"
        path.write_text("a@b.com,9.99\nc@d.com,19.99\n")
        meta = SourceMetadata(name="data", reader_options={"has_header": False})
        df = read_source(path, meta)
        assert df.shape == (2, 2)
        assert df.columns[0] != "a@b.com"  # Should not use first row as header

    def test_reader_options_none(self, sample_csv):
        meta = SourceMetadata(name="orders", reader_options=None)
        df = read_source(sample_csv, meta)
        assert df.shape == (2, 2)
