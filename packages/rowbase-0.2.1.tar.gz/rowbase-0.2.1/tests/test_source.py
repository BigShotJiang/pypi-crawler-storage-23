"""Tests for source() declaration."""

import pytest

from rowbase._internal.registry import PipelineContext, set_current_context
from rowbase.errors import ValidationError
from rowbase.source import SourceHandle, source


@pytest.fixture()
def ctx():
    """Provide a fresh PipelineContext and set it as current."""
    context = PipelineContext()
    token = set_current_context(context)
    yield context
    set_current_context(token.old_value)


class TestSource:
    def test_basic_source(self, ctx):
        handle = source("orders")
        assert isinstance(handle, SourceHandle)
        assert handle.name == "orders"
        assert handle.columns is None
        assert handle.description == ""
        assert "orders" in ctx.sources

    def test_source_with_column_list(self, ctx):
        handle = source("orders", columns=["email", "total"])
        assert handle.columns == ["email", "total"]
        assert ctx.sources["orders"].columns == ["email", "total"]

    def test_source_with_column_dict(self, ctx):
        handle = source("orders", columns={"email": str, "total": float})
        assert handle.columns == {"email": str, "total": float}

    def test_source_with_description(self, ctx):
        handle = source("orders", description="Shopify order export")
        assert handle.description == "Shopify order export"
        assert ctx.sources["orders"].description == "Shopify order export"

    def test_source_repr(self, ctx):
        handle = source("orders")
        assert repr(handle) == "SourceHandle('orders')"

    def test_invalid_name_not_identifier(self, ctx):
        with pytest.raises(ValidationError, match="not a valid Python identifier"):
            source("my orders")

    def test_invalid_name_starts_with_number(self, ctx):
        with pytest.raises(ValidationError, match="not a valid Python identifier"):
            source("123data")

    def test_duplicate_source_name(self, ctx):
        source("orders")
        with pytest.raises(ValidationError, match="already registered"):
            source("orders")

    def test_source_outside_pipeline_raises(self):
        """source() called without a current context should raise RuntimeError."""
        set_current_context(None)
        with pytest.raises(RuntimeError, match="inside a @pipeline"):
            source("orders")

    def test_multiple_sources(self, ctx):
        source("orders")
        source("customers")
        assert len(ctx.sources) == 2
        assert "orders" in ctx.sources
        assert "customers" in ctx.sources

    def test_source_with_reader_options(self, ctx):
        handle = source("data", reader_options={"sheet_name": "ALL", "skip_rows": 2})
        assert handle.reader_options == {"sheet_name": "ALL", "skip_rows": 2}
        assert ctx.sources["data"].reader_options == {"sheet_name": "ALL", "skip_rows": 2}

    def test_source_optional_default_false(self, ctx):
        handle = source("orders")
        assert handle.optional is False
        assert ctx.sources["orders"].optional is False

    def test_source_optional_true(self, ctx):
        handle = source("existing", optional=True)
        assert handle.optional is True
        assert ctx.sources["existing"].optional is True
