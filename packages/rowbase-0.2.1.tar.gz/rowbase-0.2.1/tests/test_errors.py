"""Tests for the structured error hierarchy."""

from rowbase.errors import (
    AIError,
    ConfigError,
    DatasetError,
    RowbaseError,
    SchemaError,
    ValidationError,
)


class TestRowbaseError:
    def test_basic_error(self):
        err = RowbaseError(code="TEST", message="something broke")
        assert err.code == "TEST"
        assert err.message == "something broke"
        assert err.hint is None
        assert err.details == {}

    def test_error_with_hint_and_details(self):
        err = RowbaseError(
            code="FILE_NOT_FOUND",
            message="Source file missing",
            hint="Check the --input flag.",
            details={"path": "/data/orders.parquet"},
        )
        assert err.hint == "Check the --input flag."
        assert err.details["path"] == "/data/orders.parquet"

    def test_str_without_hint(self):
        err = RowbaseError(code="TEST", message="broke")
        assert str(err) == "[TEST] broke"

    def test_str_with_hint(self):
        err = RowbaseError(code="TEST", message="broke", hint="try again")
        assert "[TEST] broke" in str(err)
        assert "Hint: try again" in str(err)

    def test_to_dict_minimal(self):
        err = RowbaseError(code="TEST", message="broke")
        d = err.to_dict()
        assert d == {"code": "TEST", "message": "broke"}

    def test_to_dict_full(self):
        err = RowbaseError(
            code="X",
            message="m",
            hint="h",
            details={"k": "v"},
        )
        d = err.to_dict()
        assert d["hint"] == "h"
        assert d["details"] == {"k": "v"}

    def test_is_exception(self):
        err = RowbaseError(code="X", message="m")
        assert isinstance(err, Exception)


class TestSubclasses:
    def test_schema_error(self):
        err = SchemaError(
            code="OUTPUT_SCHEMA_ERROR",
            message="Row 3 invalid",
            row_index=3,
            column="price",
        )
        assert isinstance(err, RowbaseError)
        assert err.row_index == 3
        assert err.column == "price"

    def test_validation_error(self):
        err = ValidationError(code="INVALID_PIPELINE", message="cycle detected")
        assert isinstance(err, RowbaseError)

    def test_dataset_error(self):
        original = ValueError("bad value")
        err = DatasetError(
            code="DATASET_ERROR",
            message="Failed in cleaned",
            dataset_name="cleaned",
            original_error=original,
        )
        assert isinstance(err, RowbaseError)
        assert err.dataset_name == "cleaned"
        assert err.original_error is original

    def test_config_error(self):
        err = ConfigError(code="CONFIG_ERROR", message="bad yaml")
        assert isinstance(err, RowbaseError)

    def test_ai_error(self):
        original = RuntimeError("timeout")
        err = AIError(
            code="AI_TIMEOUT",
            message="Job timed out",
            job_id="job-123",
            original_error=original,
        )
        assert isinstance(err, RowbaseError)
        assert err.job_id == "job-123"
        assert err.original_error is original
