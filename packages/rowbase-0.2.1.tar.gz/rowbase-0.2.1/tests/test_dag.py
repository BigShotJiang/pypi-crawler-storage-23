"""Tests for DAG construction, validation, and topological sort."""

import polars as pl
import pytest

import rowbase
from rowbase.dag import DAG
from rowbase.errors import ValidationError


def _discover(pipeline_fn):
    """Helper: call the pipeline function and return its context."""
    return pipeline_fn().context


class TestDAGConstruction:
    def test_simple_linear(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield cleaned

        ctx = _discover(pipe)
        dag = DAG.from_context(ctx)

        assert set(dag.source_nodes) == {"orders"}
        assert set(dag.dataset_nodes) == {"cleaned"}
        assert ("orders", "cleaned") in dag.edges

    def test_fan_out(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            @rowbase.dataset("domestic", data_from=cleaned)
            def domestic(cleaned: pl.DataFrame) -> pl.DataFrame:
                return cleaned

            @rowbase.dataset("international", data_from=cleaned)
            def international(cleaned: pl.DataFrame) -> pl.DataFrame:
                return cleaned

            yield domestic
            yield international

        ctx = _discover(pipe)
        dag = DAG.from_context(ctx)

        assert ("orders", "cleaned") in dag.edges
        assert ("cleaned", "domestic") in dag.edges
        assert ("cleaned", "international") in dag.edges

    def test_multi_source_join(self):
        @rowbase.pipeline
        def pipe():
            data = rowbase.source("data")
            prices = rowbase.source("prices")

            @rowbase.dataset("joined", data_from=[data, prices])
            def joined(data: pl.DataFrame, prices: pl.DataFrame) -> pl.DataFrame:
                return data

            yield joined

        ctx = _discover(pipe)
        dag = DAG.from_context(ctx)

        assert ("data", "joined") in dag.edges
        assert ("prices", "joined") in dag.edges

    def test_topological_order(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            @rowbase.dataset("products", data_from=cleaned)
            def products(cleaned: pl.DataFrame) -> pl.DataFrame:
                return cleaned

            yield products

        ctx = _discover(pipe)
        dag = DAG.from_context(ctx)

        assert dag.nodes.index("orders") < dag.nodes.index("cleaned")
        assert dag.nodes.index("cleaned") < dag.nodes.index("products")

    def test_execution_order_excludes_sources(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield cleaned

        ctx = _discover(pipe)
        dag = DAG.from_context(ctx)

        exec_order = dag.execution_order()
        assert exec_order == ["cleaned"]
        assert "orders" not in exec_order

    def test_to_dict(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            yield cleaned

        ctx = _discover(pipe)
        dag = DAG.from_context(ctx)
        d = dag.to_dict()

        assert "nodes" in d
        assert "edges" in d
        assert "sources" in d
        assert "datasets" in d


class TestDAGAssets:
    def test_asset_in_dag(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            @rowbase.asset("report", data_from=cleaned, content_type="text/plain", extension=".txt")
            def report(cleaned: pl.DataFrame) -> bytes:
                return b"hello"

            yield cleaned
            yield report

        ctx = _discover(pipe)
        dag = DAG.from_context(ctx)

        assert "report" in dag.asset_nodes
        assert ("cleaned", "report") in dag.edges

    def test_asset_in_execution_order(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.dataset("cleaned", data_from=orders)
            def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
                return orders

            @rowbase.asset("report", data_from=cleaned)
            def report(cleaned: pl.DataFrame) -> bytes:
                return b""

            yield cleaned
            yield report

        ctx = _discover(pipe)
        dag = DAG.from_context(ctx)

        exec_order = dag.execution_order()
        assert "cleaned" in exec_order
        assert "report" in exec_order
        assert exec_order.index("cleaned") < exec_order.index("report")

    def test_asset_depends_on_another_asset(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.asset("raw", data_from=orders)
            def raw(orders: pl.DataFrame) -> bytes:
                return b"raw"

            @rowbase.asset("processed", data_from=raw)
            def processed(raw: bytes) -> bytes:
                return raw

            yield processed

        ctx = _discover(pipe)
        dag = DAG.from_context(ctx)

        assert ("orders", "raw") in dag.edges
        assert ("raw", "processed") in dag.edges

    def test_to_dict_includes_assets(self):
        @rowbase.pipeline
        def pipe():
            orders = rowbase.source("orders")

            @rowbase.asset("report", data_from=orders)
            def report(orders: pl.DataFrame) -> bytes:
                return b""

            yield report

        ctx = _discover(pipe)
        dag = DAG.from_context(ctx)
        d = dag.to_dict()

        assert "assets" in d
        assert "report" in d["assets"]

    def test_dataset_cannot_depend_on_asset(self):
        from rowbase._internal.registry import (
            AssetMetadata,
            DatasetMetadata,
            PipelineContext,
            SourceMetadata,
        )

        ctx = PipelineContext()
        ctx.sources["orders"] = SourceMetadata(name="orders")
        ctx.assets["report"] = AssetMetadata(name="report", fn=lambda: None, depends_on=["orders"])
        ctx.datasets["bad"] = DatasetMetadata(name="bad", fn=lambda: None, depends_on=["report"])

        with pytest.raises(ValidationError, match="cannot depend on assets"):
            DAG.from_context(ctx)


class TestDAGValidation:
    def test_unresolved_dependency(self):
        """Manually create a context with a bad reference to test validation."""
        from rowbase._internal.registry import DatasetMetadata, PipelineContext, SourceMetadata

        ctx = PipelineContext()
        ctx.sources["orders"] = SourceMetadata(name="orders")
        ctx.datasets["cleaned"] = DatasetMetadata(
            name="cleaned", fn=lambda: None, depends_on=["nonexistent"]
        )

        with pytest.raises(ValidationError, match="not a registered source or dataset"):
            DAG.from_context(ctx)

    def test_cycle_detection(self):
        """Manually construct a context with a cycle to test detection."""
        from rowbase._internal.registry import DatasetMetadata, PipelineContext

        ctx = PipelineContext()
        ctx.datasets["a"] = DatasetMetadata(name="a", fn=lambda b: b, depends_on=["b"])
        ctx.datasets["b"] = DatasetMetadata(name="b", fn=lambda a: a, depends_on=["a"])

        with pytest.raises(ValidationError, match="dependency cycle"):
            DAG.from_context(ctx)

    def test_self_referencing_cycle(self):
        from rowbase._internal.registry import DatasetMetadata, PipelineContext

        ctx = PipelineContext()
        ctx.datasets["a"] = DatasetMetadata(name="a", fn=lambda a: a, depends_on=["a"])

        with pytest.raises(ValidationError, match="dependency cycle"):
            DAG.from_context(ctx)
