"""Tests for @asset decorator."""

import polars as pl
import pytest

from rowbase._internal.registry import PipelineContext, set_current_context
from rowbase.asset import asset
from rowbase.dataset import dataset
from rowbase.errors import ValidationError
from rowbase.source import source


@pytest.fixture()
def ctx():
    """Provide a PipelineContext with some sources pre-registered."""
    context = PipelineContext()
    token = set_current_context(context)

    yield context
    set_current_context(token.old_value)


class TestAsset:
    def test_basic_asset(self, ctx):
        orders = source("orders")

        @asset("report", data_from=orders, content_type="text/plain", extension=".txt")
        def report(orders: pl.DataFrame) -> bytes:
            return b"hello"

        assert "report" in ctx.assets
        assert ctx.assets["report"].name == "report"
        assert ctx.assets["report"].depends_on == ["orders"]
        assert ctx.assets["report"].content_type == "text/plain"
        assert ctx.assets["report"].extension == ".txt"

    def test_asset_depends_on_dataset(self, ctx):
        orders = source("orders")

        @dataset("cleaned", data_from=orders)
        def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
            return orders

        @asset("report", data_from=cleaned, content_type="text/plain", extension=".txt")
        def report(cleaned: pl.DataFrame) -> bytes:
            return b"hello"

        assert ctx.assets["report"].depends_on == ["cleaned"]

    def test_asset_depends_on_asset(self, ctx):
        orders = source("orders")

        @asset("raw_report", data_from=orders, content_type="text/plain", extension=".txt")
        def raw_report(orders: pl.DataFrame) -> bytes:
            return b"hello"

        @asset("final_report", data_from=raw_report, content_type="text/plain", extension=".txt")
        def final_report(raw_report: bytes) -> bytes:
            return raw_report

        assert ctx.assets["final_report"].depends_on == ["raw_report"]

    def test_asset_name_attribute(self, ctx):
        orders = source("orders")

        @asset("report", data_from=orders)
        def report(orders: pl.DataFrame) -> bytes:
            return b""

        assert report._asset_name == "report"

    def test_asset_meta_attribute(self, ctx):
        orders = source("orders")

        @asset("report", data_from=orders, content_type="image/jpeg")
        def report(orders: pl.DataFrame) -> bytes:
            return b""

        assert report._asset_meta.content_type == "image/jpeg"

    def test_invalid_name(self, ctx):
        with pytest.raises(ValidationError, match="not a valid Python identifier"):

            @asset("my asset")
            def bad() -> bytes:
                return b""

    def test_duplicate_name_with_source(self, ctx):
        source("orders")
        with pytest.raises(ValidationError, match="already registered"):

            @asset("orders")
            def bad() -> bytes:
                return b""

    def test_duplicate_name_with_dataset(self, ctx):
        orders = source("orders")

        @dataset("cleaned", data_from=orders)
        def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
            return orders

        with pytest.raises(ValidationError, match="already registered"):

            @asset("cleaned", data_from=orders)
            def bad(orders: pl.DataFrame) -> bytes:
                return b""

    def test_duplicate_asset_name(self, ctx):
        orders = source("orders")

        @asset("report", data_from=orders)
        def report1(orders: pl.DataFrame) -> bytes:
            return b""

        with pytest.raises(ValidationError, match="already registered"):

            @asset("report", data_from=orders)
            def report2(orders: pl.DataFrame) -> bytes:
                return b""

    def test_outside_pipeline_raises(self):
        set_current_context(None)
        with pytest.raises(RuntimeError, match="inside a @pipeline"):

            @asset("x")
            def bad() -> bytes:
                return b""

    def test_invalid_data_from_value(self, ctx):
        with pytest.raises(ValidationError, match="Invalid data_from"):

            @asset("x", data_from="not_a_handle")
            def bad() -> bytes:
                return b""

    def test_default_content_type(self, ctx):
        @asset("report")
        def report() -> bytes:
            return b""

        assert ctx.assets["report"].content_type == "application/octet-stream"

    def test_description_stored(self, ctx):
        @asset("report", description="A test report")
        def report() -> bytes:
            return b""

        assert ctx.assets["report"].description == "A test report"

    def test_wrapped_function_callable(self, ctx):
        @asset("report")
        def report() -> bytes:
            return b"result"

        assert report() == b"result"

    def test_all_names_includes_assets(self, ctx):
        orders = source("orders")

        @dataset("cleaned", data_from=orders)
        def cleaned(orders: pl.DataFrame) -> pl.DataFrame:
            return orders

        @asset("report", data_from=cleaned)
        def report(cleaned: pl.DataFrame) -> bytes:
            return b""

        assert ctx.all_names == {"orders", "cleaned", "report"}
