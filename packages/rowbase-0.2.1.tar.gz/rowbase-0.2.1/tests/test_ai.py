"""Tests for the AI operations module."""

from __future__ import annotations

import io
from unittest.mock import MagicMock, patch

import polars as pl
import pytest

from rowbase.ai._client import _download_result, _poll_until_complete, _submit_ai_job
from rowbase.ai.detect_headers import detect_headers
from rowbase.ai.models import FieldType
from rowbase.ai.use_ai import use_ai
from rowbase.errors import AIError


@pytest.fixture()
def mock_client():
    client = MagicMock()
    client._client = MagicMock()
    client._raise_for_error = MagicMock()
    return client


@pytest.fixture()
def sample_df():
    return pl.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]})


class TestSubmitAIJob:
    def test_submits_parquet_and_returns_job_id(self, mock_client, sample_df):
        mock_client._client.post.return_value.json.return_value = {"job_id": "j-1"}

        result = _submit_ai_job("detect-headers", sample_df, {"k": "v"}, mock_client)

        assert result == "j-1"
        mock_client._client.post.assert_called_once()
        call_kwargs = mock_client._client.post.call_args
        assert "/ai/detect-headers" in call_kwargs.args

    def test_raises_on_api_error(self, mock_client, sample_df):
        mock_client._raise_for_error.side_effect = AIError(
            code="API_ERROR", message="fail"
        )

        with pytest.raises(AIError, match="fail"):
            _submit_ai_job("detect-headers", sample_df, {}, mock_client)


class TestPollUntilComplete:
    def test_returns_on_completed(self, mock_client):
        mock_client._client.get.return_value.json.return_value = {
            "status": "completed"
        }

        result = _poll_until_complete("j-1", mock_client)
        assert result["status"] == "completed"

    def test_returns_on_failed(self, mock_client):
        mock_client._client.get.return_value.json.return_value = {
            "status": "failed",
            "error": "bad input",
        }

        result = _poll_until_complete("j-1", mock_client)
        assert result["status"] == "failed"

    @patch("rowbase.ai._client.time")
    def test_timeout_raises_ai_error(self, mock_time, mock_client):
        mock_client._client.get.return_value.json.return_value = {
            "status": "running"
        }
        # Simulate time moving past the deadline
        mock_time.monotonic.side_effect = [0.0, 601.0]
        mock_time.sleep = MagicMock()

        with pytest.raises(AIError, match="did not complete") as exc_info:
            _poll_until_complete("j-1", mock_client, max_wait=600.0)

        assert exc_info.value.job_id == "j-1"
        assert exc_info.value.code == "AI_TIMEOUT"

    @patch("rowbase.ai._client.time")
    def test_polls_until_complete(self, mock_time, mock_client):
        responses = [
            {"status": "running"},
            {"status": "running"},
            {"status": "completed"},
        ]
        mock_client._client.get.return_value.json.side_effect = responses
        mock_time.monotonic.side_effect = [0.0, 1.0, 2.0, 3.0, 4.0, 5.0]
        mock_time.sleep = MagicMock()

        result = _poll_until_complete("j-1", mock_client, max_wait=600.0)
        assert result["status"] == "completed"
        assert mock_client._client.get.call_count == 3


class TestDownloadResult:
    def test_downloads_and_parses_parquet(self, mock_client):
        expected = pl.DataFrame({"x": [1, 2]})
        parquet_bytes = io.BytesIO()
        expected.write_parquet(parquet_bytes)

        mock_client._client.get.return_value.content = parquet_bytes.getvalue()

        result = _download_result("j-1", mock_client)
        assert result.equals(expected)


class TestDetectHeaders:
    @patch("rowbase.ai.detect_headers.RowbaseClient")
    def test_success_flow(self, MockClient, sample_df):
        client = MockClient.return_value
        client._client = MagicMock()
        client._raise_for_error = MagicMock()

        client._client.post.return_value.json.return_value = {"job_id": "j-1"}
        client._client.get.return_value.json.side_effect = [
            {"status": "completed"},
        ]

        expected = pl.DataFrame({"col_a": [1, 2, 3]})
        buf = io.BytesIO()
        expected.write_parquet(buf)
        client._client.get.return_value.content = buf.getvalue()

        result = detect_headers(sample_df)
        assert result.equals(expected)

    @patch("rowbase.ai.detect_headers.RowbaseClient")
    def test_failed_job_raises_with_job_id(self, MockClient, sample_df):
        client = MockClient.return_value
        client._client = MagicMock()
        client._raise_for_error = MagicMock()

        client._client.post.return_value.json.return_value = {"job_id": "j-2"}
        client._client.get.return_value.json.return_value = {
            "status": "failed",
            "error": "bad data",
        }

        with pytest.raises(AIError) as exc_info:
            detect_headers(sample_df)

        assert exc_info.value.job_id == "j-2"
        assert exc_info.value.code == "AI_JOB_FAILED"
        assert "bad data" in exc_info.value.message


class TestUseAI:
    @patch("rowbase.ai.use_ai.RowbaseClient")
    def test_success_flow(self, MockClient, sample_df):
        client = MockClient.return_value
        client._client = MagicMock()
        client._raise_for_error = MagicMock()

        client._client.post.return_value.json.return_value = {"job_id": "j-3"}
        client._client.get.return_value.json.side_effect = [
            {"status": "completed"},
        ]

        expected = pl.DataFrame({"category": ["tech", "health", "edu"]})
        buf = io.BytesIO()
        expected.write_parquet(buf)
        client._client.get.return_value.content = buf.getvalue()

        result = use_ai(sample_df, prompt="Classify {{b}}")
        assert result.equals(expected)

    def test_invalid_output_format(self, sample_df):
        with pytest.raises(AIError, match="output_format must be") as exc_info:
            use_ai(sample_df, prompt="test", output_format="invalid")
        assert exc_info.value.code == "AI_INVALID_PARAMS"

    def test_json_schema_requires_schema(self, sample_df):
        with pytest.raises(AIError, match="json_schema is required") as exc_info:
            use_ai(sample_df, prompt="test", output_format="json_schema")
        assert exc_info.value.code == "AI_INVALID_PARAMS"

    @patch("rowbase.ai.use_ai.RowbaseClient")
    def test_failed_job_raises_with_job_id(self, MockClient, sample_df):
        client = MockClient.return_value
        client._client = MagicMock()
        client._raise_for_error = MagicMock()

        client._client.post.return_value.json.return_value = {"job_id": "j-4"}
        client._client.get.return_value.json.return_value = {
            "status": "failed",
            "error": "LLM error",
        }

        with pytest.raises(AIError) as exc_info:
            use_ai(sample_df, prompt="Classify {{b}}")

        assert exc_info.value.job_id == "j-4"
        assert exc_info.value.code == "AI_JOB_FAILED"


class TestFieldType:
    def test_enum_values(self):
        assert FieldType.TEXT == "text"
        assert FieldType.NUMBER == "number"
        assert FieldType.SELECT == "select"

    def test_importable_from_rowbase(self):
        from rowbase import FieldType as FT

        assert FT is FieldType

    def test_importable_from_rowbase_ai(self):
        from rowbase.ai import FieldType as FT

        assert FT is FieldType
