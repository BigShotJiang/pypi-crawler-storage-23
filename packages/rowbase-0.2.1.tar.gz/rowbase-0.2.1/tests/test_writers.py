"""Tests for atomic output writing."""

import json

import polars as pl
import pytest

from rowbase.execution import AssetResult, DatasetResult, RunResult, StepMetric
from rowbase.io.writers import write_outputs


@pytest.fixture()
def sample_result():
    return RunResult(
        run_id="abc123",
        status="success",
        complete=True,
        datasets={
            "cleaned": DatasetResult(name="cleaned", row_count=10, columns=["a", "b"]),
        },
        step_metrics=[
            StepMetric(dataset="cleaned", input_rows={"orders": 10}, output_rows=10, duration_ms=5),
        ],
        errors=[],
        duration_ms=50,
    )


@pytest.fixture()
def sample_result_with_assets():
    return RunResult(
        run_id="abc456",
        status="success",
        complete=True,
        datasets={
            "cleaned": DatasetResult(name="cleaned", row_count=10, columns=["a", "b"]),
        },
        assets={
            "report": AssetResult(
                name="report",
                file_count=1,
                total_bytes=5,
                content_type="text/plain",
                extension=".txt",
                filenames=["report.txt"],
            ),
            "swatches": AssetResult(
                name="swatches",
                file_count=2,
                total_bytes=12,
                content_type="image/jpeg",
                extension=".jpg",
                filenames=["red.jpg", "blue.jpg"],
            ),
        },
        step_metrics=[],
        errors=[],
        duration_ms=50,
    )


class TestWriteOutputs:
    def test_writes_parquet_and_metadata(self, tmp_path, sample_result):
        df = pl.DataFrame({"a": [1, 2], "b": [3, 4]})
        output_dir = tmp_path / "output"

        run_dir = write_outputs(sample_result, output_dir, {"cleaned": df})

        assert (run_dir / "cleaned.parquet").exists()
        assert (run_dir / "run_metadata.json").exists()

        meta = json.loads((run_dir / "run_metadata.json").read_text())
        assert meta["run_id"] == "abc123"
        assert meta["complete"] is True
        assert meta["datasets"]["cleaned"]["row_count"] == 10

    def test_staging_cleaned_up_on_success(self, tmp_path, sample_result):
        df = pl.DataFrame({"a": [1]})
        output_dir = tmp_path / "output"

        write_outputs(sample_result, output_dir, {"cleaned": df})

        # Staging directory should not exist after successful write
        staging = output_dir / f".staging_{sample_result.run_id}"
        assert not staging.exists()

    def test_parquet_readable(self, tmp_path, sample_result):
        df = pl.DataFrame({"a": [1, 2, 3], "b": ["x", "y", "z"]})
        output_dir = tmp_path / "output"

        run_dir = write_outputs(sample_result, output_dir, {"cleaned": df})

        read_back = pl.read_parquet(run_dir / "cleaned.parquet")
        assert read_back.shape == (3, 2)
        assert read_back.columns == ["a", "b"]

    def test_writes_csv(self, tmp_path, sample_result):
        df = pl.DataFrame({"a": [1, 2], "b": ["x", "y"]})
        output_dir = tmp_path / "output"

        run_dir = write_outputs(sample_result, output_dir, {"cleaned": df}, output_format="csv")

        csv_path = run_dir / "cleaned.csv"
        assert csv_path.exists()
        read_back = pl.read_csv(csv_path)
        assert read_back.shape == (2, 2)
        assert read_back.columns == ["a", "b"]

    def test_writes_json(self, tmp_path, sample_result):
        df = pl.DataFrame({"a": [1, 2], "b": ["x", "y"]})
        output_dir = tmp_path / "output"

        run_dir = write_outputs(sample_result, output_dir, {"cleaned": df}, output_format="json")

        json_path = run_dir / "cleaned.json"
        assert json_path.exists()
        read_back = pl.read_ndjson(json_path)
        assert read_back.shape == (2, 2)

    def test_writes_xlsx(self, tmp_path, sample_result):
        df = pl.DataFrame({"a": [1, 2], "b": ["x", "y"]})
        output_dir = tmp_path / "output"

        run_dir = write_outputs(sample_result, output_dir, {"cleaned": df}, output_format="xlsx")

        xlsx_path = run_dir / "cleaned.xlsx"
        assert xlsx_path.exists()
        read_back = pl.read_excel(xlsx_path)
        assert read_back.shape == (2, 2)

    def test_unsupported_format_raises(self, tmp_path, sample_result):
        df = pl.DataFrame({"a": [1]})
        output_dir = tmp_path / "output"

        with pytest.raises(ValueError, match="Unsupported output format"):
            write_outputs(sample_result, output_dir, {"cleaned": df}, output_format="xml")


class TestWriteAssets:
    def test_writes_asset_files(self, tmp_path, sample_result_with_assets):
        df = pl.DataFrame({"a": [1, 2], "b": [3, 4]})
        output_dir = tmp_path / "output"
        asset_data = {
            "report": {"report.txt": b"hello"},
            "swatches": {"red.jpg": b"red_img", "blue.jpg": b"blue_img"},
        }

        run_dir = write_outputs(
            sample_result_with_assets, output_dir, {"cleaned": df}, asset_data=asset_data
        )

        assert (run_dir / "assets" / "report" / "report.txt").exists()
        assert (run_dir / "assets" / "report" / "report.txt").read_bytes() == b"hello"
        assert (run_dir / "assets" / "swatches" / "red.jpg").read_bytes() == b"red_img"
        assert (run_dir / "assets" / "swatches" / "blue.jpg").read_bytes() == b"blue_img"

    def test_run_metadata_includes_assets(self, tmp_path, sample_result_with_assets):
        df = pl.DataFrame({"a": [1]})
        output_dir = tmp_path / "output"

        run_dir = write_outputs(
            sample_result_with_assets, output_dir, {"cleaned": df},
            asset_data={"report": {"report.txt": b"hello"}},
        )

        meta = json.loads((run_dir / "run_metadata.json").read_text())
        assert "assets" in meta
        assert "report" in meta["assets"]
        assert meta["assets"]["report"]["file_count"] == 1
        assert meta["assets"]["report"]["content_type"] == "text/plain"
        assert meta["assets"]["report"]["filenames"] == ["report.txt"]

    def test_no_asset_data_still_works(self, tmp_path, sample_result):
        df = pl.DataFrame({"a": [1]})
        output_dir = tmp_path / "output"

        run_dir = write_outputs(sample_result, output_dir, {"cleaned": df})

        assert (run_dir / "cleaned.parquet").exists()
        meta = json.loads((run_dir / "run_metadata.json").read_text())
        assert meta["assets"] == {}
