"""Tests for CLI auth commands and browser-based login flow."""

from __future__ import annotations

import threading
from unittest.mock import patch

import httpx
from typer.testing import CliRunner

from rowbase.cli.auth_cmd import app
from rowbase.cli.browser_auth import DEFAULT_FRONTEND_URL, _get_frontend_url, browser_login

runner = CliRunner()


# ── auth login ──────────────────────────────────────────────────────


class TestAuthLogin:
    def test_login_with_valid_api_key(self):
        with patch("rowbase.api.client.save_credentials") as mock_save:
            result = runner.invoke(app, ["login", "--api-key", "rb_key_abc123def456xxxx"])
            assert result.exit_code == 0
            assert "API key saved" in result.output
            mock_save.assert_called_once_with("rb_key_abc123def456xxxx")

    def test_login_rejects_invalid_prefix(self):
        result = runner.invoke(app, ["login", "--api-key", "bad_key_1234567890123"])
        assert result.exit_code == 1
        assert "Invalid API key format" in result.output

    def test_login_browser_flow_success(self):
        with (
            patch(
                "rowbase.cli.browser_auth.browser_login",
                return_value="rb_key_from_browser_xxxx",
            ),
            patch("rowbase.api.client.save_credentials") as mock_save,
        ):
            result = runner.invoke(app, ["login"])
            assert result.exit_code == 0
            assert "API key saved" in result.output
            mock_save.assert_called_once_with("rb_key_from_browser_xxxx")

    def test_login_browser_flow_timeout(self):
        with patch("rowbase.cli.browser_auth.browser_login", return_value=None):
            result = runner.invoke(app, ["login"])
            assert result.exit_code == 1
            assert "timed out" in result.output


# ── auth logout ─────────────────────────────────────────────────────


class TestAuthLogout:
    def test_logout(self):
        with patch("rowbase.api.client.clear_credentials") as mock_clear:
            result = runner.invoke(app, ["logout"])
            assert result.exit_code == 0
            assert "Credentials cleared" in result.output
            mock_clear.assert_called_once()


# ── auth status ─────────────────────────────────────────────────────


class TestAuthStatus:
    def test_status_authenticated(self):
        info = {
            "authenticated": True,
            "api_url": "https://api.rowbase.com",
            "key_prefix": "rb_key_abc123def4...",
            "source": "env (ROWBASE_API_KEY)",
        }
        with patch("rowbase.api.client.get_credentials_info", return_value=info):
            result = runner.invoke(app, ["status"])
            assert result.exit_code == 0
            assert "Authenticated" in result.output
            assert "api.rowbase.com" in result.output

    def test_status_not_authenticated(self):
        info = {
            "authenticated": False,
            "api_url": "https://api.rowbase.com",
            "key_prefix": None,
            "source": None,
        }
        with patch("rowbase.api.client.get_credentials_info", return_value=info):
            result = runner.invoke(app, ["status"])
            assert result.exit_code == 0
            assert "Not authenticated" in result.output


# ── browser_auth ────────────────────────────────────────────────────


class TestGetFrontendUrl:
    def test_default(self, monkeypatch):
        monkeypatch.delenv("ROWBASE_FRONTEND_URL", raising=False)
        assert _get_frontend_url() == DEFAULT_FRONTEND_URL

    def test_override(self, monkeypatch):
        monkeypatch.setenv("ROWBASE_FRONTEND_URL", "http://localhost:3000")
        assert _get_frontend_url() == "http://localhost:3000"


class TestBrowserLogin:
    def test_callback_returns_key(self):
        """Simulate the browser sending the key back to the local callback server."""

        def _send_key_to_server(port: int) -> None:
            import time

            time.sleep(0.1)
            httpx.get(f"http://127.0.0.1:{port}/callback?key=rb_key_test1234567890")

        import http.server

        real_init = http.server.HTTPServer.__init__

        def patched_init(self, *args, **kwargs):
            real_init(self, *args, **kwargs)
            threading.Thread(
                target=_send_key_to_server,
                args=(self.server_address[1],),
                daemon=True,
            ).start()

        with (
            patch("rowbase.cli.browser_auth.webbrowser.open", return_value=True),
            patch.object(http.server.HTTPServer, "__init__", patched_init),
        ):
            result = browser_login(timeout=5)

        assert result == "rb_key_test1234567890"

    def test_timeout_returns_none(self):
        """When no callback arrives, browser_login returns None."""
        with patch("rowbase.cli.browser_auth.webbrowser.open", return_value=True):
            result = browser_login(timeout=0.2)
            assert result is None

    def test_non_callback_path_returns_404(self):
        """Requests to paths other than /callback get a 404."""
        captured_status = {}

        def _hit_bad_path(port: int) -> None:
            import time

            time.sleep(0.1)
            resp = httpx.get(f"http://127.0.0.1:{port}/not-a-callback")
            captured_status["code"] = resp.status_code

        import http.server

        real_init = http.server.HTTPServer.__init__

        def patched_init(self, *args, **kwargs):
            real_init(self, *args, **kwargs)
            threading.Thread(
                target=_hit_bad_path,
                args=(self.server_address[1],),
                daemon=True,
            ).start()

        with (
            patch("rowbase.cli.browser_auth.webbrowser.open", return_value=True),
            patch.object(http.server.HTTPServer, "__init__", patched_init),
        ):
            result = browser_login(timeout=1)

        assert result is None
        assert captured_status.get("code") == 404
