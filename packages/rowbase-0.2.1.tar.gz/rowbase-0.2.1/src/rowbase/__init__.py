"""Rowbase SDK — declare data pipelines as Python functions."""

__version__ = "0.1.0"

from rowbase.ai import FieldType, detect_headers, use_ai
from rowbase.asset import asset
from rowbase.config import get_config as _get_config
from rowbase.dataset import dataset
from rowbase.errors import AIError, RowbaseError
from rowbase.pipeline import pipeline
from rowbase.source import source


class _ConfigProxy:
    """Lazy proxy so `rowbase.config.get(...)` works without explicit loading."""

    def get(self, key: str, default: object = None) -> object:
        return _get_config().get(key, default)


config = _ConfigProxy()

__all__ = [
    "AIError",
    "FieldType",
    "RowbaseError",
    "asset",
    "config",
    "dataset",
    "detect_headers",
    "pipeline",
    "source",
    "use_ai",
]


def connect(api_key: str | None = None) -> None:
    """Connect to the Rowbase platform. No-op in Phase 1."""
