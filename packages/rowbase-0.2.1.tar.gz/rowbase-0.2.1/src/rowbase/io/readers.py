"""File readers: detect format from extension and read into polars DataFrame."""

from __future__ import annotations

from pathlib import Path

import polars as pl

from rowbase._internal.registry import SourceMetadata
from rowbase.errors import RowbaseError


def read_source(path: Path, meta: SourceMetadata) -> pl.DataFrame:
    """Read a source file into a polars DataFrame and validate columns if declared."""
    if not path.exists():
        raise RowbaseError(
            code="FILE_NOT_FOUND",
            message=f"Source file not found: {path}",
            hint=f"Provide the file via --input {meta.name}=<path>",
        )

    opts = meta.reader_options or {}
    df = _read_file(path, opts)
    _validate_columns(df, meta, path)
    return df


_CSV_OPTS = {"skip_rows", "has_header", "separator", "infer_schema_length"}
_EXCEL_PASSTHROUGH = {"sheet_name", "has_header"}


def _pick(opts: dict, allowed: set[str]) -> dict:
    """Return the subset of opts whose keys are in allowed."""
    return {k: v for k, v in opts.items() if k in allowed}


def _read_excel(path: Path, opts: dict) -> pl.DataFrame:
    """Read an Excel file, handling skip_rows manually.

    Polars read_excel doesn't support pandas-style header=N, so when
    skip_rows is specified we read headerless, slice off the leading rows,
    and promote the first remaining row to column names.

    skip_rows uses pandas-compatible semantics: the value is the 0-indexed
    row number to use as headers (e.g., skip_rows=2 means row 2 is headers).
    """
    excel_kwargs = _pick(opts, _EXCEL_PASSTHROUGH)
    skip = opts.get("skip_rows", 0)

    if skip:
        df = pl.read_excel(path, has_header=False, **_pick(opts, {"sheet_name"}))
        df = df.slice(skip)
        headers = [str(v) if v is not None else f"col_{i}" for i, v in enumerate(df.row(0))]
        df = df.slice(1)
        df.columns = headers
        return df

    return pl.read_excel(path, **excel_kwargs)


def _read_file(path: Path, opts: dict | None = None) -> pl.DataFrame:
    """Read a file based on its extension, applying reader_options."""
    suffix = path.suffix.lower()
    opts = opts or {}
    try:
        if suffix == ".parquet":
            return pl.read_parquet(path)
        elif suffix == ".csv":
            return pl.read_csv(path, **_pick(opts, _CSV_OPTS))
        elif suffix in (".xlsx", ".xls"):
            return _read_excel(path, opts)
        else:
            raise RowbaseError(
                code="FILE_PARSE_ERROR",
                message=f"Unsupported file format: {suffix}",
                hint="Supported formats: .parquet, .csv, .xlsx, .xls",
            )
    except RowbaseError:
        raise
    except Exception as e:
        raise RowbaseError(
            code="FILE_PARSE_ERROR",
            message=f"Failed to read {path}: {e}",
            hint="Check that the file is valid and not corrupted.",
            details={"path": str(path), "error": str(e)},
        ) from e


def _validate_columns(df: pl.DataFrame, meta: SourceMetadata, path: Path) -> None:
    """Validate that expected columns exist in the DataFrame."""
    if meta.columns is None:
        return

    expected = set(meta.columns) if isinstance(meta.columns, list) else set(meta.columns.keys())
    actual = set(df.columns)
    missing = expected - actual

    if missing:
        raise RowbaseError(
            code="SCHEMA_MISMATCH",
            message=f"Source {meta.name!r} is missing columns: {sorted(missing)}",
            hint=f"File {path.name} has columns: {sorted(actual)}",
            details={"missing": sorted(missing), "actual": sorted(actual)},
        )
