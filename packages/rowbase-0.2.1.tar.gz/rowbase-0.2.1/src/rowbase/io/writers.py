"""Two-phase atomic output writing."""

from __future__ import annotations

import json
import shutil
from dataclasses import asdict
from pathlib import Path
from typing import TYPE_CHECKING

import polars as pl

if TYPE_CHECKING:
    from rowbase.execution import RunResult


_FORMAT_EXTENSIONS = {
    "parquet": ".parquet",
    "csv": ".csv",
    "json": ".json",
    "xlsx": ".xlsx",
}


def _write_dataset(df: pl.DataFrame, path: Path, fmt: str) -> None:
    """Write a single DataFrame in the specified format."""
    if fmt == "parquet":
        df.write_parquet(path)
    elif fmt == "csv":
        df.write_csv(path)
    elif fmt == "json":
        df.write_ndjson(path)
    elif fmt == "xlsx":
        df.write_excel(path)
    else:
        raise ValueError(f"Unsupported output format: {fmt!r}")


def write_outputs(
    result: RunResult,
    output_dir: Path,
    datasets: dict[str, pl.DataFrame],
    *,
    asset_data: dict[str, dict[str, bytes]] | None = None,
    output_format: str = "parquet",
) -> Path:
    """Write published datasets and assets to output directory using two-phase commit.

    1. Write everything to a staging directory
    2. Atomically rename staging → final
    """
    ext = _FORMAT_EXTENSIONS.get(output_format)
    if ext is None:
        raise ValueError(
            f"Unsupported output format: {output_format!r}. "
            f"Supported: {', '.join(_FORMAT_EXTENSIONS)}"
        )

    run_dir = output_dir / result.run_id
    staging_dir = output_dir / f".staging_{result.run_id}"

    staging_dir.mkdir(parents=True, exist_ok=True)

    try:
        # Write each published dataset in the requested format
        for ds_name, df in datasets.items():
            out_path = staging_dir / f"{ds_name}{ext}"
            _write_dataset(df, out_path, output_format)

        # Write asset files
        if asset_data:
            for asset_name, files_dict in asset_data.items():
                asset_dir = staging_dir / "assets" / asset_name
                asset_dir.mkdir(parents=True, exist_ok=True)
                for filename, content in files_dict.items():
                    (asset_dir / filename).write_bytes(content)

        # Write run metadata as the final file
        metadata = {
            "run_id": result.run_id,
            "status": result.status,
            "complete": result.complete,
            "duration_ms": result.duration_ms,
            "datasets": {
                name: {
                    "row_count": dr.row_count,
                    "columns": dr.columns,
                    "stdout": dr.stdout,
                    "stderr": dr.stderr,
                }
                for name, dr in result.datasets.items()
            },
            "assets": {
                name: {
                    "file_count": ar.file_count,
                    "total_bytes": ar.total_bytes,
                    "content_type": ar.content_type,
                    "extension": ar.extension,
                    "filenames": ar.filenames,
                    "stdout": ar.stdout,
                    "stderr": ar.stderr,
                }
                for name, ar in result.assets.items()
            },
            "errors": [e.to_dict() for e in result.errors],
            "logs": [asdict(log) for log in result.logs],
            "step_metrics": [asdict(m) for m in result.step_metrics],
            "published_names": sorted(result.published_names),
        }
        meta_path = staging_dir / "run_metadata.json"
        meta_path.write_text(json.dumps(metadata, indent=2))

        # Atomic rename: staging → final
        if run_dir.exists():
            shutil.rmtree(run_dir)
        staging_dir.rename(run_dir)

    except Exception:
        # Clean up staging on failure
        if staging_dir.exists():
            shutil.rmtree(staging_dir)
        raise

    return run_dir
