"""Pipeline execution engine."""

from __future__ import annotations

import contextlib
import io
import logging
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import polars as pl

from rowbase.dag import DAG
from rowbase.errors import AssetError, DatasetError, RowbaseError
from rowbase.io.readers import read_source
from rowbase.pipeline import PipelineSpec
from rowbase.schema import validate_dataframe


@dataclass
class DatasetResult:
    """Result metadata for a single dataset."""

    name: str
    row_count: int
    columns: list[str]
    stdout: str = ""
    stderr: str = ""


@dataclass
class AssetResult:
    """Result metadata for a single asset."""

    name: str
    file_count: int
    total_bytes: int
    content_type: str
    extension: str
    filenames: list[str]
    stdout: str = ""
    stderr: str = ""


@dataclass
class StepMetric:
    """Timing and row count for a single execution step."""

    dataset: str
    input_rows: dict[str, int]
    output_rows: int
    duration_ms: int


@dataclass
class CapturedLog:
    """A single log record captured during pipeline execution."""

    dataset: str
    level: str
    message: str


@dataclass
class RunResult:
    """Full result of a pipeline run."""

    run_id: str
    status: str  # "success" | "partial" | "failed"
    complete: bool
    datasets: dict[str, DatasetResult] = field(default_factory=dict)
    dataframes: dict[str, pl.DataFrame] = field(default_factory=dict)
    assets: dict[str, AssetResult] = field(default_factory=dict)
    asset_data: dict[str, dict[str, bytes]] = field(default_factory=dict)
    step_metrics: list[StepMetric] = field(default_factory=list)
    errors: list[RowbaseError] = field(default_factory=list)
    logs: list[CapturedLog] = field(default_factory=list)
    published_names: set[str] = field(default_factory=set)
    duration_ms: int = 0


class _LogCaptureHandler(logging.Handler):
    """Logging handler that captures records into a list."""

    def __init__(self, logs: list[CapturedLog], step_name: str) -> None:
        super().__init__()
        self._logs = logs
        self._step_name = step_name

    def emit(self, record: logging.LogRecord) -> None:
        self._logs.append(
            CapturedLog(
                dataset=self._step_name,
                level=record.levelname,
                message=self.format(record),
            )
        )


class PipelineRunner:
    """Executes a discovered pipeline against source files."""

    def run(
        self,
        spec: PipelineSpec,
        inputs: dict[str, Path],
        *,
        output_dir: Path | None = None,
        sample_rows: int | None = None,
        run_id: str | None = None,
        output_format: str = "parquet",
    ) -> RunResult:
        """Run a pipeline end-to-end.

        All print() calls and log output from dataset/asset functions are
        captured and attached to the RunResult rather than going to
        stdout/stderr.
        """
        result = RunResult(
            run_id=run_id or uuid.uuid4().hex[:12],
            status="failed",
            complete=False,
        )
        start = time.monotonic()
        cache: dict[str, pl.DataFrame] = {}
        asset_cache: dict[str, bytes | dict[str, bytes]] = {}
        ctx = spec.context

        try:
            # 1. Build DAG
            dag = DAG.from_context(ctx)

            # 2. Load sources
            for src_name, src_meta in ctx.sources.items():
                if src_name not in inputs:
                    if src_meta.optional:
                        cache[src_name] = pl.DataFrame()
                        continue
                    raise RowbaseError(
                        code="FILE_NOT_FOUND",
                        message=f"No input file provided for source {src_name!r}.",
                        hint=f"Use --input {src_name}=<path>",
                    )
                src_path = inputs[src_name]
                if src_meta.optional and not src_path.exists():
                    cache[src_name] = pl.DataFrame()
                    continue
                df = read_source(src_path, src_meta)
                if sample_rows is not None:
                    df = df.head(sample_rows)
                cache[src_name] = df

            # 3. Walk DAG in topological order, execute datasets and assets
            for step_name in dag.execution_order():
                if step_name in ctx.datasets:
                    self._run_dataset(step_name, ctx, cache, result)
                elif step_name in ctx.assets:
                    self._run_asset(step_name, ctx, cache, asset_cache, result)

            result.status = "success" if not result.errors else "partial"
            result.complete = True
            result.dataframes = dict(cache)
            result.published_names = set(ctx.published)

            # 4. Write outputs if requested (after status is finalized)
            if output_dir is not None:
                from rowbase.io.writers import write_outputs

                published_dfs = {name: cache[name] for name in ctx.published if name in cache}
                published_assets = {
                    name: result.asset_data[name]
                    for name in ctx.published
                    if name in result.asset_data
                }
                write_outputs(
                    result,
                    output_dir,
                    published_dfs,
                    asset_data=published_assets,
                    output_format=output_format,
                )

        except RowbaseError as e:
            result.errors.append(e)
            result.status = "failed"

        result.duration_ms = int((time.monotonic() - start) * 1000)
        return result

    def _run_dataset(
        self,
        ds_name: str,
        ctx: Any,
        cache: dict[str, pl.DataFrame],
        result: RunResult,
    ) -> None:
        """Execute a single dataset step."""
        ds_meta = ctx.datasets[ds_name]
        step_start = time.monotonic()

        # Resolve inputs from cache
        input_rows: dict[str, int] = {}
        kwargs: dict[str, Any] = {}
        for dep_name in ds_meta.depends_on:
            dep_df = cache[dep_name]
            kwargs[dep_name] = dep_df
            input_rows[dep_name] = dep_df.shape[0]

        # Execute with stdout/stderr/logging capture
        stdout_buf, stderr_buf, output_df = self._execute_step(
            ds_name, ds_meta.fn, kwargs, result.logs
        )

        if not isinstance(output_df, pl.DataFrame):
            raise DatasetError(
                code="DATASET_ERROR",
                message=f"Dataset {ds_name!r} must return a polars DataFrame, got {type(output_df).__name__}.",
                dataset_name=ds_name,
            )

        # Schema validation
        if ds_meta.schema is not None:
            output_df, schema_errors = validate_dataframe(
                output_df, ds_meta.schema, on_error=ds_meta.on_schema_error
            )
            result.errors.extend(schema_errors)

        # Inject _rb_* metadata columns
        if ds_meta.metadata:
            output_df = output_df.with_columns(
                pl.lit(result.run_id).alias("_rb_run_id"),
                pl.lit(datetime.now(timezone.utc)).alias("_rb_loaded_at"),
                pl.lit(ds_name).alias("_rb_dataset_name"),
            )

        cache[ds_name] = output_df

        step_ms = int((time.monotonic() - step_start) * 1000)
        result.step_metrics.append(
            StepMetric(
                dataset=ds_name,
                input_rows=input_rows,
                output_rows=output_df.shape[0],
                duration_ms=step_ms,
            )
        )
        result.datasets[ds_name] = DatasetResult(
            name=ds_name,
            row_count=output_df.shape[0],
            columns=output_df.columns,
            stdout=stdout_buf,
            stderr=stderr_buf,
        )

    def _run_asset(
        self,
        asset_name: str,
        ctx: Any,
        cache: dict[str, pl.DataFrame],
        asset_cache: dict[str, bytes | dict[str, bytes]],
        result: RunResult,
    ) -> None:
        """Execute a single asset step."""
        asset_meta = ctx.assets[asset_name]
        step_start = time.monotonic()

        # Resolve inputs from DataFrame cache or asset cache
        kwargs: dict[str, Any] = {}
        for dep_name in asset_meta.depends_on:
            if dep_name in cache:
                kwargs[dep_name] = cache[dep_name]
            elif dep_name in asset_cache:
                kwargs[dep_name] = asset_cache[dep_name]

        # Execute with stdout/stderr/logging capture
        stdout_buf, stderr_buf, output = self._execute_step(
            asset_name, asset_meta.fn, kwargs, result.logs
        )

        # Validate and normalize return type
        if isinstance(output, bytes):
            normalized = {f"{asset_name}{asset_meta.extension}": output}
        elif isinstance(output, dict) and all(
            isinstance(k, str) and isinstance(v, bytes) for k, v in output.items()
        ):
            normalized = output
        else:
            raise AssetError(
                code="ASSET_ERROR",
                message=f"Asset {asset_name!r} must return bytes or dict[str, bytes], "
                f"got {type(output).__name__}.",
                asset_name=asset_name,
            )

        asset_cache[asset_name] = output
        result.asset_data[asset_name] = normalized

        total_bytes = sum(len(v) for v in normalized.values())
        step_ms = int((time.monotonic() - step_start) * 1000)

        result.step_metrics.append(
            StepMetric(
                dataset=asset_name,
                input_rows={},
                output_rows=len(normalized),
                duration_ms=step_ms,
            )
        )
        result.assets[asset_name] = AssetResult(
            name=asset_name,
            file_count=len(normalized),
            total_bytes=total_bytes,
            content_type=asset_meta.content_type,
            extension=asset_meta.extension,
            filenames=list(normalized.keys()),
            stdout=stdout_buf,
            stderr=stderr_buf,
        )

    def _execute_step(
        self,
        step_name: str,
        fn: Any,
        kwargs: dict[str, Any],
        logs: list[CapturedLog],
    ) -> tuple[str, str, Any]:
        """Call a step function with stdout, stderr, and logging captured."""
        stdout_capture = io.StringIO()
        stderr_capture = io.StringIO()

        log_handler = _LogCaptureHandler(logs, step_name)
        log_handler.setLevel(logging.DEBUG)
        root_logger = logging.getLogger()
        root_logger.addHandler(log_handler)

        try:
            with (
                contextlib.redirect_stdout(stdout_capture),
                contextlib.redirect_stderr(stderr_capture),
            ):
                output = fn(**kwargs)
        except AssetError:
            raise
        except DatasetError:
            raise
        except Exception as e:
            raise DatasetError(
                code="DATASET_ERROR",
                message=f"Step {step_name!r} raised an exception: {e}",
                hint=f"Check the {step_name} function for errors.",
                dataset_name=step_name,
                original_error=e,
            ) from e
        finally:
            root_logger.removeHandler(log_handler)

        return stdout_capture.getvalue(), stderr_capture.getvalue(), output
