"""Source declaration for pipeline inputs."""

from __future__ import annotations

from rowbase._internal.registry import SourceMetadata, get_current_context
from rowbase.errors import ValidationError


class SourceHandle:
    """Lightweight handle returned by source(). Used for DAG discovery, not data access."""

    def __init__(
        self,
        name: str,
        columns: list[str] | dict[str, type] | None,
        description: str,
        reader_options: dict | None = None,
        optional: bool = False,
    ):
        self.name = name
        self.columns = columns
        self.description = description
        self.reader_options = reader_options
        self.optional = optional

    def __repr__(self) -> str:
        return f"SourceHandle({self.name!r})"


def source(
    name: str,
    *,
    columns: list[str] | dict[str, type] | None = None,
    description: str = "",
    reader_options: dict | None = None,
    optional: bool = False,
) -> SourceHandle:
    """Declare a data source inside a pipeline function.

    Args:
        name: Logical name for this source. Must be a valid Python identifier
              and unique across all sources and datasets in the pipeline.
        columns: Optional column validation. A list of expected column names,
                 or a dict mapping column names to types.
        description: Human-readable description of this source.
        reader_options: Options passed to the file reader. Supports:
            - sheet_name: Excel sheet name or index
            - skip_rows: Number of rows to skip before header
            - has_header: Whether the file has a header row (default True)
            - separator: CSV column separator (default ",")
        optional: If True, missing input files produce an empty DataFrame
                  instead of raising an error.

    Returns:
        A SourceHandle used for DAG discovery.
    """
    if not name.isidentifier():
        raise ValidationError(
            code="INVALID_PIPELINE",
            message=f"Source name {name!r} is not a valid Python identifier.",
            hint="Source names must be valid Python identifiers (e.g., 'orders', 'hinkley_data').",
        )

    ctx = get_current_context()

    if name in ctx.all_names:
        raise ValidationError(
            code="INVALID_PIPELINE",
            message=f"Name {name!r} is already registered as a source or dataset.",
            hint="Source and dataset names must be unique across the entire pipeline.",
        )

    meta = SourceMetadata(
        name=name,
        columns=columns,
        description=description,
        reader_options=reader_options,
        optional=optional,
    )
    ctx.register_source(meta)

    return SourceHandle(
        name=name,
        columns=columns,
        description=description,
        reader_options=reader_options,
        optional=optional,
    )
