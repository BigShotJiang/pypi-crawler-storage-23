"""Pipeline decorator and discovery."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

from rowbase._internal.registry import PipelineContext, set_current_context
from rowbase.errors import ValidationError

if TYPE_CHECKING:
    from collections.abc import Callable


@dataclass
class PipelineSpec:
    """The result of discovering a pipeline — its metadata and registered context."""

    name: str | None
    fn: Callable[..., Any]
    context: PipelineContext


def pipeline(
    fn: Callable[..., Any] | None = None,
    *,
    name: str | None = None,
) -> Any:
    """Decorator for pipeline generator functions.

    Can be used as @pipeline, @pipeline(), or @pipeline(name="my_pipeline").

    When the decorated function is called, it:
    1. Creates a fresh PipelineContext
    2. Sets it as the current context (so source/dataset can register)
    3. Iterates the generator to collect yielded (published) datasets
    4. Returns a PipelineSpec with the discovered graph
    """

    def decorator(gen_fn: Callable[..., Any]) -> Callable[..., PipelineSpec]:
        def discover() -> PipelineSpec:
            ctx = PipelineContext()
            token = set_current_context(ctx)
            try:
                gen = gen_fn()
                # Iterate the generator to discover sources, datasets, and published outputs
                for yielded in gen:
                    ds_name = getattr(yielded, "_dataset_name", None)
                    asset_name = getattr(yielded, "_asset_name", None)

                    if ds_name is not None:
                        if ds_name not in ctx.datasets:
                            raise ValidationError(
                                code="INVALID_PIPELINE",
                                message=f"Yielded dataset {ds_name!r} was not registered in this pipeline.",
                            )
                        ctx.mark_published(ds_name)
                    elif asset_name is not None:
                        if asset_name not in ctx.assets:
                            raise ValidationError(
                                code="INVALID_PIPELINE",
                                message=f"Yielded asset {asset_name!r} was not registered in this pipeline.",
                            )
                        ctx.mark_published(asset_name)
                    else:
                        raise ValidationError(
                            code="INVALID_PIPELINE",
                            message="Yielded value is not a dataset or asset.",
                            hint="Only yield @dataset or @asset decorated functions from a pipeline.",
                        )
            finally:
                set_current_context(token.old_value)  # type: ignore[arg-type]

            return PipelineSpec(name=name, fn=gen_fn, context=ctx)

        # Make the discover function accessible
        discover._is_pipeline = True  # type: ignore[attr-defined]
        discover._pipeline_name = name  # type: ignore[attr-defined]
        discover.__name__ = gen_fn.__name__
        discover.__qualname__ = gen_fn.__qualname__
        discover.__wrapped__ = gen_fn  # type: ignore[attr-defined]

        return discover

    # Support @pipeline (no parens) and @pipeline() and @pipeline(name=...)
    if fn is not None:
        return decorator(fn)
    return decorator
