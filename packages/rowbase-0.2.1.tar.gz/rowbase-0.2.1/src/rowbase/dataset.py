"""Dataset decorator for transform functions."""

from __future__ import annotations

import functools
from typing import TYPE_CHECKING, Any

from rowbase._internal.registry import DatasetMetadata, get_current_context, resolve_dependency_name
from rowbase.errors import ValidationError
from rowbase.source import SourceHandle

if TYPE_CHECKING:
    from collections.abc import Callable

    from pydantic import BaseModel

# A data_from value: a SourceHandle, a decorated dataset/asset function, or a list of either.
DataFrom = SourceHandle | Any


def dataset(
    name: str,
    *,
    data_from: DataFrom | list[DataFrom] | None = None,
    schema: type[BaseModel] | None = None,
    on_schema_error: str = "fail",
    description: str = "",
    metadata: bool = True,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator for dataset transform functions.

    Args:
        name: Dataset name. Must be a valid Python identifier and unique.
        data_from: Input dependencies — a SourceHandle, a decorated dataset,
                   or a list of either. Required when consuming sources/datasets.
                   Omit for self-created datasets that generate data from scratch.
        schema: Optional Pydantic model for output validation.
        on_schema_error: Behavior on schema failure: "fail", "skip", or "collect".
        description: Human-readable description.
        metadata: Whether to inject _rb_* metadata columns into the output.
    """
    if not name.isidentifier():
        raise ValidationError(
            code="INVALID_PIPELINE",
            message=f"Dataset name {name!r} is not a valid Python identifier.",
            hint="Dataset names must be valid identifiers (e.g., 'cleaned', 'domestic_orders').",
        )

    if on_schema_error not in ("fail", "skip", "collect"):
        raise ValidationError(
            code="INVALID_PIPELINE",
            message=f"Invalid on_schema_error value: {on_schema_error!r}.",
            hint="Must be one of: 'fail', 'skip', 'collect'.",
        )

    # Normalize data_from to a list
    if data_from is None:
        deps: list[DataFrom] = []
    elif isinstance(data_from, list):
        deps = data_from
    else:
        deps = [data_from]

    depends_on = [resolve_dependency_name(d) for d in deps]

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        ctx = get_current_context()

        if name in ctx.all_names:
            raise ValidationError(
                code="INVALID_PIPELINE",
                message=f"Name {name!r} is already registered as a source or dataset.",
                hint="Source and dataset names must be unique across the entire pipeline.",
            )

        meta = DatasetMetadata(
            name=name,
            fn=fn,
            schema=schema,
            on_schema_error=on_schema_error,
            description=description,
            depends_on=depends_on,
            metadata=metadata,
        )
        ctx.register_dataset(meta)

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return fn(*args, **kwargs)

        wrapper._dataset_name = name  # type: ignore[attr-defined]
        wrapper._dataset_meta = meta  # type: ignore[attr-defined]

        return wrapper

    return decorator
