"""Asset decorator for binary file output functions."""

from __future__ import annotations

import functools
from typing import TYPE_CHECKING, Any

from rowbase._internal.registry import AssetMetadata, get_current_context, resolve_dependency_name
from rowbase.errors import ValidationError
from rowbase.source import SourceHandle

if TYPE_CHECKING:
    from collections.abc import Callable

DataFrom = SourceHandle | Any


def asset(
    name: str,
    *,
    data_from: DataFrom | list[DataFrom] | None = None,
    content_type: str = "application/octet-stream",
    extension: str = "",
    description: str = "",
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator for asset output functions.

    Assets produce binary files (bytes) instead of DataFrames. They can depend
    on sources, datasets, and other assets.

    Args:
        name: Asset name. Must be a valid Python identifier and unique.
        data_from: Input dependencies — a SourceHandle, a decorated dataset/asset,
                   or a list of either.
        content_type: MIME type for the output files (e.g. "image/jpeg").
        extension: File extension including dot (e.g. ".jpg"). Used when the
                   asset function returns a single ``bytes`` value.
        description: Human-readable description.
    """
    if not name.isidentifier():
        raise ValidationError(
            code="INVALID_PIPELINE",
            message=f"Asset name {name!r} is not a valid Python identifier.",
            hint="Asset names must be valid identifiers (e.g., 'swatches', 'color_report').",
        )

    if data_from is None:
        deps: list[DataFrom] = []
    elif isinstance(data_from, list):
        deps = data_from
    else:
        deps = [data_from]

    depends_on = [resolve_dependency_name(d) for d in deps]

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        ctx = get_current_context()

        if name in ctx.all_names:
            raise ValidationError(
                code="INVALID_PIPELINE",
                message=f"Name {name!r} is already registered as a source, dataset, or asset.",
                hint="Source, dataset, and asset names must be unique across the entire pipeline.",
            )

        meta = AssetMetadata(
            name=name,
            fn=fn,
            content_type=content_type,
            extension=extension,
            description=description,
            depends_on=depends_on,
        )
        ctx.register_asset(meta)

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            return fn(*args, **kwargs)

        wrapper._asset_name = name  # type: ignore[attr-defined]
        wrapper._asset_meta = meta  # type: ignore[attr-defined]

        return wrapper

    return decorator
