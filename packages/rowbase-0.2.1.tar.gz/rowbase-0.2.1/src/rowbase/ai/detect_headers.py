"""Detect and apply column headers using AI analysis."""

from __future__ import annotations

import polars as pl

from rowbase.ai._client import _download_result, _poll_until_complete, _submit_ai_job
from rowbase.api.client import RowbaseClient
from rowbase.errors import AIError


def detect_headers(
    df: pl.DataFrame,
    *,
    rows_to_analyze: int = 15,
    normalize_names: bool = True,
    remove_metadata_rows: bool = True,
    heuristic_confidence_threshold: float = 0.90,
) -> pl.DataFrame:
    """Detect and apply column headers using AI analysis.

    Analyzes the first N rows to find header rows using heuristics,
    falling back to LLM if confidence is below threshold.

    Args:
        df: Input DataFrame with potential header rows in the data.
        rows_to_analyze: Number of rows to analyze for header detection.
        normalize_names: Convert detected header names to snake_case.
        remove_metadata_rows: Remove rows above the detected header row(s).
        heuristic_confidence_threshold: Confidence threshold for heuristic detection.

    Returns:
        DataFrame with headers applied and metadata rows removed.
    """
    params = {
        "rows_to_analyze": rows_to_analyze,
        "normalize_names": normalize_names,
        "remove_metadata_rows": remove_metadata_rows,
        "heuristic_confidence_threshold": heuristic_confidence_threshold,
    }

    client = RowbaseClient()
    job_id = _submit_ai_job("detect-headers", df, params, client)
    result = _poll_until_complete(job_id, client)

    if result["status"] == "failed":
        raise AIError(
            code="AI_JOB_FAILED",
            message=result.get("error", "Header detection failed"),
            job_id=job_id,
        )

    return _download_result(job_id, client)
