"""Data models for AI operations."""

from enum import StrEnum


class FieldType(StrEnum):
    TEXT = "text"
    NUMBER = "number"
    BOOLEAN = "boolean"
    URL = "url"
    SELECT = "select"
    EMAIL = "email"
