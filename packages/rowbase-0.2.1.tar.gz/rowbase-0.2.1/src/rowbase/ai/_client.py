"""Internal helpers for AI job submission, polling, and result download."""

from __future__ import annotations

import io
import json
import time
from typing import Any

import polars as pl

from rowbase.api.client import RowbaseClient
from rowbase.errors import AIError


def _submit_ai_job(
    operation: str, df: pl.DataFrame, params: dict[str, Any], client: RowbaseClient
) -> str:
    """Serialize DataFrame to Parquet, upload to API, return job_id."""
    buf = io.BytesIO()
    df.write_parquet(buf)
    buf.seek(0)

    response = client._client.post(
        f"/ai/{operation}",
        files={"file": ("data.parquet", buf, "application/octet-stream")},
        data={"params": json.dumps(params)},
    )
    client._raise_for_error(response)
    return response.json()["job_id"]


def _poll_until_complete(
    job_id: str,
    client: RowbaseClient,
    poll_interval: float = 1.0,
    max_wait: float = 600.0,
) -> dict[str, Any]:
    """Poll job status until completed or failed."""
    deadline = time.monotonic() + max_wait

    while True:
        resp = client._client.get(f"/ai/jobs/{job_id}")
        client._raise_for_error(resp)
        status = resp.json()

        if status["status"] in ("completed", "failed"):
            return status

        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break

        time.sleep(min(poll_interval, remaining))

    raise AIError(
        code="AI_TIMEOUT",
        message=f"AI job {job_id} did not complete within {max_wait}s",
        job_id=job_id,
    )


def _download_result(job_id: str, client: RowbaseClient) -> pl.DataFrame:
    """Download result Parquet and reconstruct DataFrame."""
    resp = client._client.get(f"/ai/jobs/{job_id}/result")
    client._raise_for_error(resp)
    return pl.read_parquet(io.BytesIO(resp.content))
