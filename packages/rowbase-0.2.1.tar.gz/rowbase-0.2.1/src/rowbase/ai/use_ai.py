"""Generate AI-powered columns based on a prompt template."""

from __future__ import annotations

from typing import Any

import polars as pl

from rowbase.ai._client import _download_result, _poll_until_complete, _submit_ai_job
from rowbase.api.client import RowbaseClient
from rowbase.errors import AIError

_VALID_OUTPUT_FORMATS = {"fields", "json_schema"}


def use_ai(
    df: pl.DataFrame,
    *,
    prompt: str,
    fields: list[dict[str, Any]] | None = None,
    output_format: str = "fields",
    json_schema: dict[str, Any] | None = None,
    split_into_columns: bool = True,
) -> pl.DataFrame:
    """Generate AI-powered columns based on a prompt template.

    Column references use {{column_name}} syntax in the prompt.

    Args:
        df: Input DataFrame.
        prompt: Prompt template with {{column_name}} references.
        fields: Output field definitions (name, type, description, options).
        output_format: "fields" or "json_schema".
        json_schema: JSON schema for output (when output_format="json_schema").
        split_into_columns: Split output fields into separate columns.

    Returns:
        DataFrame with AI-generated columns appended.
    """
    if output_format not in _VALID_OUTPUT_FORMATS:
        raise AIError(
            code="AI_INVALID_PARAMS",
            message=f"output_format must be one of {sorted(_VALID_OUTPUT_FORMATS)!r}, got {output_format!r}",
        )
    if output_format == "json_schema" and json_schema is None:
        raise AIError(
            code="AI_INVALID_PARAMS",
            message="json_schema is required when output_format='json_schema'",
        )

    params: dict[str, Any] = {
        "prompt": prompt,
        "output_format": output_format,
        "split_into_columns": split_into_columns,
    }
    if fields is not None:
        params["fields"] = fields
    if json_schema is not None:
        params["json_schema"] = json_schema

    client = RowbaseClient()
    job_id = _submit_ai_job("use-ai", df, params, client)
    result = _poll_until_complete(job_id, client)

    if result["status"] == "failed":
        raise AIError(
            code="AI_JOB_FAILED",
            message=result.get("error", "AI processing failed"),
            job_id=job_id,
        )

    return _download_result(job_id, client)
