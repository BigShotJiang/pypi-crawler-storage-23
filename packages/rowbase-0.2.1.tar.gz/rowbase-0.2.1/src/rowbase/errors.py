"""Structured error hierarchy for the Rowbase SDK."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class RowbaseError(Exception):
    """Base error for all Rowbase SDK errors."""

    code: str
    message: str
    hint: str | None = None
    details: dict[str, object] = field(default_factory=dict)

    def __str__(self) -> str:
        parts = [f"[{self.code}] {self.message}"]
        if self.hint:
            parts.append(f"  Hint: {self.hint}")
        return "\n".join(parts)

    def to_dict(self) -> dict[str, object]:
        d: dict[str, object] = {"code": self.code, "message": self.message}
        if self.hint:
            d["hint"] = self.hint
        if self.details:
            d["details"] = self.details
        return d


@dataclass
class SchemaError(RowbaseError):
    """Pydantic schema validation failure on dataset output."""

    row_index: int | None = None
    column: str | None = None


@dataclass
class ValidationError(RowbaseError):
    """Pre-execution validation failure (DAG structure, source refs, naming)."""


@dataclass
class DatasetError(RowbaseError):
    """Exception raised inside a dataset function during execution."""

    dataset_name: str | None = None
    original_error: Exception | None = field(default=None, repr=False)


@dataclass
class AssetError(RowbaseError):
    """Exception raised inside an asset function during execution."""

    asset_name: str | None = None
    original_error: Exception | None = field(default=None, repr=False)


@dataclass
class AIError(RowbaseError):
    """Error from an AI operation (detect_headers, use_ai, etc.)."""

    job_id: str | None = None
    original_error: Exception | None = field(default=None, repr=False)


@dataclass
class ConfigError(RowbaseError):
    """YAML config loading or access error."""
