"""YAML config loading and access.

Loads the `config:` section from rowbase.yaml. Values are accessible via
dot-notation keys and can be overridden by ROWBASE_CONFIG_<KEY> env vars.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import yaml

from rowbase.errors import ConfigError


class Config:
    """Access config values from rowbase.yaml's `config:` section."""

    def __init__(self, data: dict[str, Any] | None = None) -> None:
        self._data: dict[str, Any] = data or {}
        self._loaded = data is not None

    @classmethod
    def load(cls, path: Path | None = None) -> Config:
        """Load config from rowbase.yaml. Returns empty config if file doesn't exist."""
        if path is None:
            path = Path.cwd() / "rowbase.yaml"

        if not path.exists():
            return cls()

        try:
            with open(path) as f:
                raw = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            raise ConfigError(
                code="CONFIG_ERROR",
                message=f"Failed to parse {path}",
                hint="Check that rowbase.yaml contains valid YAML.",
                details={"path": str(path), "error": str(e)},
            ) from e

        if not isinstance(raw, dict):
            raise ConfigError(
                code="CONFIG_ERROR",
                message=f"Expected a mapping at top level of {path}",
                hint="rowbase.yaml should start with key-value pairs, not a list.",
            )

        config_section = raw.get("config", {})
        if not isinstance(config_section, dict):
            raise ConfigError(
                code="CONFIG_ERROR",
                message="The 'config' section in rowbase.yaml must be a mapping.",
            )

        instance = cls(config_section)
        return instance

    def get(self, key: str, default: Any = None) -> Any:
        """Get a config value. Env var ROWBASE_CONFIG_<KEY> takes precedence."""
        env_key = f"ROWBASE_CONFIG_{key.upper()}"
        env_val = os.environ.get(env_key)
        if env_val is not None:
            return _parse_env_value(env_val)

        parts = key.split(".")
        current: Any = self._data
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            else:
                return default
            if current is None:
                return default
        return current


def _parse_env_value(val: str) -> Any:
    """Attempt to parse an env var value as JSON, fall back to string."""
    try:
        return json.loads(val)
    except (json.JSONDecodeError, ValueError):
        return val


# Module-level singleton, lazily loaded on first access.
_config: Config | None = None


def get_config() -> Config:
    """Get the global config singleton, loading from rowbase.yaml if needed."""
    global _config  # noqa: PLW0603
    if _config is None:
        _config = Config.load()
    return _config


def reset_config() -> None:
    """Reset the global config singleton (for testing)."""
    global _config  # noqa: PLW0603
    _config = None
