"""Scaffold a new Rowbase pipeline project."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from rowbase.cli.formatters import print_error, print_success

PIPELINE_TEMPLATE = '''\
"""Pipeline: {name}"""

import polars as pl

import rowbase


@rowbase.pipeline(name="{name}")
def {fn_name}():
    data = rowbase.source("data", columns=["id"])

    @rowbase.dataset("cleaned", data_from=data)
    def cleaned(data: pl.DataFrame) -> pl.DataFrame:
        return data

    yield cleaned
'''

YAML_TEMPLATE = """\
name: {name}
version: "1.0.0"
description: ""
pipelines_dir: src

config: {{}}
"""

GITIGNORE_TEMPLATE = """\
__pycache__/
*.pyc
.venv/
.rowbase/
.staging_*/
"""


def init_command(
    name: Annotated[str, typer.Option("--name", "-n", help="Project name")],
    directory: Annotated[Path, typer.Argument(help="Directory to create")] = Path("."),
) -> None:
    """Scaffold a new Rowbase pipeline project."""
    project_dir = directory / name if directory == Path(".") else directory

    if project_dir.exists() and any(project_dir.iterdir()):
        print_error(f"Directory {project_dir} already exists and is not empty.")
        raise typer.Exit(code=1)

    project_dir.mkdir(parents=True, exist_ok=True)

    fn_name = name.replace("-", "_").replace(" ", "_")

    src_dir = project_dir / "src"
    src_dir.mkdir(exist_ok=True)
    (src_dir / f"{fn_name}.py").write_text(PIPELINE_TEMPLATE.format(name=name, fn_name=fn_name))
    (project_dir / "rowbase.yaml").write_text(YAML_TEMPLATE.format(name=name))
    (project_dir / ".gitignore").write_text(GITIGNORE_TEMPLATE)

    print_success(f"Created project {name!r} in {project_dir}/")
    typer.echo(f"  src/{fn_name}.py  — your pipeline code")
    typer.echo("  rowbase.yaml      — project configuration")
    typer.echo("\nNext steps:")
    typer.echo(f"  cd {project_dir}")
    typer.echo(f"  rowbase pipeline validate {fn_name}")
