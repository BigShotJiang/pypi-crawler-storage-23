"""Data commands: inspect local files."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from rowbase.cli.formatters import print_error, print_json

app = typer.Typer(no_args_is_help=True)


@app.command()
def inspect(
    file_path: Annotated[Path, typer.Argument(help="Path to a data file (csv, parquet, xlsx)")],
    fmt: Annotated[str, typer.Option("--format", "-f")] = "text",
) -> None:
    """Inspect a local data file: show columns, types, row count, and sample values."""

    from rowbase.io.readers import _read_file

    if not file_path.exists():
        print_error(f"File not found: {file_path}")
        raise typer.Exit(code=1)

    try:
        df = _read_file(file_path)
    except Exception as e:
        print_error(f"Failed to read file: {e}")
        raise typer.Exit(code=1) from e

    col_info = []
    for col_name in df.columns:
        series = df[col_name]
        col_info.append(
            {
                "name": col_name,
                "dtype": str(series.dtype),
                "null_count": series.null_count(),
                "unique_count": series.n_unique(),
            }
        )

    if fmt == "json":
        print_json(
            {
                "file": str(file_path),
                "rows": df.shape[0],
                "columns": col_info,
            }
        )
    else:
        from rich.console import Console
        from rich.table import Table

        console = Console()
        console.print(
            f"\n[bold]{file_path.name}[/bold] — {df.shape[0]:,} rows, {df.shape[1]} columns\n"
        )

        table = Table()
        table.add_column("Column", style="cyan")
        table.add_column("Type", style="green")
        table.add_column("Nulls", justify="right")
        table.add_column("Unique", justify="right")

        for c in col_info:
            table.add_row(c["name"], c["dtype"], str(c["null_count"]), str(c["unique_count"]))

        console.print(table)
