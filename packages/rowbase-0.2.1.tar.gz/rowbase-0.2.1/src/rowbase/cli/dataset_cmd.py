"""Dataset commands: test a single dataset."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from rowbase.cli.discovery import resolve_single_pipeline
from rowbase.cli.formatters import print_error, print_json, print_success
from rowbase.cli.pipeline_cmd import DirOption, FormatOption, _parse_inputs

app = typer.Typer(no_args_is_help=True)


@app.command()
def test(
    pipeline_name: Annotated[str, typer.Argument(help="Pipeline name")],
    dataset_name: Annotated[str, typer.Option("--dataset", "-d")],
    dir: DirOption = None,
    inputs: Annotated[list[str] | None, typer.Option("--input", "-i")] = None,
    sample_rows: Annotated[int, typer.Option("--sample-rows")] = 5,
    fmt: FormatOption = "text",
) -> None:
    """Test a single dataset with sample data."""
    from rowbase.execution import PipelineRunner

    discovered = resolve_single_pipeline(pipeline_name, dir)
    spec = discovered.pipeline_fn()

    if dataset_name not in spec.context.datasets:
        print_error(f"Dataset {dataset_name!r} not found in pipeline.")
        available = sorted(spec.context.datasets.keys())
        typer.echo(f"  Available: {', '.join(available)}")
        raise typer.Exit(code=1)

    input_map = _parse_inputs(inputs or [])
    runner = PipelineRunner()
    result = runner.run(spec, input_map, sample_rows=sample_rows)

    if dataset_name not in result.datasets:
        print_error(f"Dataset {dataset_name!r} did not produce output.")
        for err in result.errors:
            print_error(f"  [{err.code}] {err.message}")
        raise typer.Exit(code=1)

    ds_result = result.datasets[dataset_name]

    if fmt == "json":
        print_json(
            {
                "dataset": dataset_name,
                "row_count": ds_result.row_count,
                "columns": ds_result.columns,
                "status": result.status,
                "errors": [e.to_dict() for e in result.errors],
            }
        )
    else:
        print_success(
            f"Dataset {dataset_name!r}: {ds_result.row_count} rows, {len(ds_result.columns)} columns"
        )
        typer.echo(f"  Columns: {', '.join(ds_result.columns)}")
