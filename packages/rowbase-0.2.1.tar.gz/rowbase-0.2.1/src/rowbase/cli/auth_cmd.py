"""Authentication commands: login, logout, status."""

from __future__ import annotations

from typing import Annotated

import typer

from rowbase.cli.formatters import print_error, print_success

app = typer.Typer(no_args_is_help=True)


@app.command()
def login(
    api_key: Annotated[
        str | None,
        typer.Option("--api-key", "-k", help="Provide an API key directly (skip browser flow)"),
    ] = None,
) -> None:
    """Authenticate with the Rowbase platform via the browser."""
    from rowbase.api.client import save_credentials

    if api_key is None:
        from rowbase.cli.browser_auth import browser_login

        typer.echo("Opening browser for authentication...\n  Waiting for authorization (Ctrl+C to cancel)")
        api_key = browser_login()

        if api_key is None:
            print_error("Authentication timed out or was cancelled.")
            raise typer.Exit(code=1)

    if not api_key.startswith("rb_key_"):
        print_error("Invalid API key format. Expected prefix: rb_key_")
        raise typer.Exit(code=1)

    save_credentials(api_key)
    print_success(f"API key saved ({api_key[:20]}...)")


@app.command()
def logout() -> None:
    """Remove stored credentials."""
    from rowbase.api.client import clear_credentials

    clear_credentials()
    print_success("Credentials cleared.")


@app.command()
def status() -> None:
    """Show current authentication status."""
    from rowbase.api.client import get_credentials_info

    info = get_credentials_info()
    if info["authenticated"]:
        print_success("Authenticated")
        typer.echo(f"  API URL:  {info['api_url']}")
        typer.echo(f"  Key:      {info['key_prefix']}")
        typer.echo(f"  Source:   {info['source']}")
    else:
        print_error("Not authenticated")
        typer.echo("  Run 'rowbase auth login' or set ROWBASE_API_KEY env var.")
