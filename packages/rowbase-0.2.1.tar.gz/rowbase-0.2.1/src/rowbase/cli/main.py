"""Rowbase CLI — Typer entry point."""

from __future__ import annotations

import typer

from rowbase.cli.auth_cmd import app as auth_app
from rowbase.cli.data_cmd import app as data_app
from rowbase.cli.dataset_cmd import app as dataset_app
from rowbase.cli.init_cmd import init_command
from rowbase.cli.pipeline_cmd import app as pipeline_app
from rowbase.cli.runs_cmd import app as runs_app

app = typer.Typer(
    name="rowbase",
    help="Rowbase SDK — declare data pipelines as Python functions.",
    no_args_is_help=True,
)

app.add_typer(pipeline_app, name="pipeline", help="Pipeline commands: validate, run, info")
app.add_typer(dataset_app, name="dataset", help="Dataset commands: test")
app.add_typer(data_app, name="data", help="Data commands: inspect")
app.add_typer(auth_app, name="auth", help="Authentication: login, logout, status")
app.add_typer(runs_app, name="runs", help="Runs: list, show, download results")
app.command("init")(init_command)
