"""Pipeline discovery: scan a directory for @pipeline-decorated functions."""

from __future__ import annotations

import importlib.util
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import typer
import yaml

from rowbase.cli.formatters import print_error


@dataclass
class DiscoveredPipeline:
    """A pipeline found during directory scanning."""

    name: str
    path: Path
    pipeline_fn: Any


def find_project_root(start: Path | None = None) -> Path | None:
    """Walk up from *start* (default cwd) looking for rowbase.yaml."""
    current = (start or Path.cwd()).resolve()
    for directory in [current, *current.parents]:
        if (directory / "rowbase.yaml").exists():
            return directory
    return None


def resolve_pipelines_dir(dir_override: Path | None = None) -> Path:
    """Determine the pipelines directory.

    Priority: --dir flag > rowbase.yaml pipelines_dir > default 'src/'
    """
    project_root = find_project_root()

    if dir_override is not None:
        if not dir_override.is_absolute():
            base = project_root or Path.cwd()
            return (base / dir_override).resolve()
        return dir_override.resolve()

    if project_root is not None:
        yaml_path = project_root / "rowbase.yaml"
        try:
            with open(yaml_path) as f:
                raw = yaml.safe_load(f) or {}
            pipelines_dir = raw.get("pipelines_dir", "src")
        except (yaml.YAMLError, OSError):
            pipelines_dir = "src"
        return (project_root / pipelines_dir).resolve()

    return (Path.cwd() / "src").resolve()


def _import_pipeline_from_file(
    file_path: Path, pipelines_dir: Path
) -> DiscoveredPipeline | None:
    """Import a .py file and return a DiscoveredPipeline if it contains one."""
    dir_str = str(pipelines_dir)
    if dir_str not in sys.path:
        sys.path.insert(0, dir_str)

    module_name = f"_pipeline_{file_path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    if spec is None or spec.loader is None:
        return None

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module

    try:
        spec.loader.exec_module(module)
    except Exception:
        return None

    for attr_name in dir(module):
        attr = getattr(module, attr_name)
        if getattr(attr, "_is_pipeline", False):
            name = getattr(attr, "_pipeline_name", None) or file_path.stem
            return DiscoveredPipeline(name=name, path=file_path, pipeline_fn=attr)

    return None


def discover_pipelines(
    dir_override: Path | None = None,
) -> dict[str, DiscoveredPipeline]:
    """Scan the pipelines directory and return ``{name: DiscoveredPipeline}``."""
    pipelines_dir = resolve_pipelines_dir(dir_override)

    if not pipelines_dir.is_dir():
        print_error(f"Pipelines directory not found: {pipelines_dir}")
        raise typer.Exit(code=1)

    result: dict[str, DiscoveredPipeline] = {}
    duplicates: list[str] = []

    for py_file in sorted(pipelines_dir.glob("*.py")):
        if py_file.name.startswith("__"):
            continue

        discovered = _import_pipeline_from_file(py_file, pipelines_dir)
        if discovered is None:
            continue

        if discovered.name in result:
            existing = result[discovered.name]
            duplicates.append(
                f"  '{discovered.name}' in both {existing.path.name} and {py_file.name}"
            )
            continue

        result[discovered.name] = discovered

    if duplicates:
        print_error("Duplicate pipeline names:\n" + "\n".join(duplicates))
        raise typer.Exit(code=1)

    return result


def resolve_single_pipeline(
    name: str,
    dir_override: Path | None = None,
) -> DiscoveredPipeline:
    """Find a single pipeline by name, or exit with a helpful error."""
    pipelines = discover_pipelines(dir_override)
    if name not in pipelines:
        available = ", ".join(sorted(pipelines.keys())) or "(none found)"
        print_error(f"Pipeline '{name}' not found. Available: {available}")
        raise typer.Exit(code=1)
    return pipelines[name]
