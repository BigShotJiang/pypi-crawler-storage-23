"""Runs commands: list, show, download results from the platform."""

from __future__ import annotations

import io
from pathlib import Path
from typing import Annotated

import typer

from rowbase.cli.formatters import console, print_error, print_json, print_success

app = typer.Typer(no_args_is_help=True)


def _get_client():
    from rowbase.api.client import RowbaseClient
    from rowbase.errors import RowbaseError

    try:
        return RowbaseClient()
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e


@app.command(name="list")
def list_runs(
    pipeline_id: Annotated[str, typer.Option("--pipeline", "-p", help="Pipeline ID")],
    fmt: Annotated[str, typer.Option("--format", "-f")] = "text",
) -> None:
    """List runs for a deployed pipeline."""
    client = _get_client()

    from rowbase.errors import RowbaseError

    try:
        runs = client.list_runs(pipeline_id)
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e

    if fmt == "json":
        print_json(runs)
        return

    if not runs:
        typer.echo("No runs found.")
        return

    from rich.table import Table

    table = Table(title=f"Runs for {pipeline_id}")
    table.add_column("Run ID", style="cyan")
    table.add_column("Status")
    table.add_column("Duration", justify="right")
    table.add_column("Datasets", justify="right")
    table.add_column("Created")

    for r in runs:
        status = r["status"]
        color = "green" if status == "success" else "yellow" if status == "partial" else "red"
        duration = f"{r['duration_ms']}ms" if r.get("duration_ms") else "-"
        ds_count = str(len(r.get("datasets", [])))
        created = r.get("started_at", r.get("created_at", ""))[:19]
        table.add_row(r["public_id"], f"[{color}]{status}[/{color}]", duration, ds_count, created)

    console.print(table)


@app.command()
def show(
    pipeline_id: Annotated[str, typer.Option("--pipeline", "-p", help="Pipeline ID")],
    run_id: Annotated[str, typer.Option("--run", "-r", help="Run ID")],
    fmt: Annotated[str, typer.Option("--format", "-f")] = "text",
) -> None:
    """Show details of a specific run."""
    client = _get_client()

    from rowbase.errors import RowbaseError

    try:
        run = client.get_run(pipeline_id, run_id)
        metrics = client.get_step_metrics(pipeline_id, run_id)
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e

    if fmt == "json":
        print_json({"run": run, "metrics": metrics})
        return

    status = run["status"]
    color = "green" if status == "success" else "yellow" if status == "partial" else "red"
    console.print(f"\nRun [bold cyan]{run['public_id']}[/bold cyan] — [{color}]{status}[/{color}]")
    if run.get("duration_ms"):
        console.print(f"Duration: {run['duration_ms']}ms")
    if run.get("error_message"):
        print_error(run["error_message"])

    if run.get("datasets"):
        from rich.table import Table

        table = Table(title="Datasets")
        table.add_column("Name", style="cyan")
        table.add_column("Rows", justify="right")
        table.add_column("Columns", justify="right")
        table.add_column("Published", justify="center")

        for ds in run["datasets"]:
            pub = "[green]✓[/green]" if ds.get("is_published") else ""
            table.add_row(ds["name"], str(ds["row_count"]), str(len(ds["columns"])), pub)

        console.print(table)

    if metrics:
        from rich.table import Table

        mtable = Table(title="Step Metrics")
        mtable.add_column("Dataset", style="cyan")
        mtable.add_column("Input Rows")
        mtable.add_column("Output Rows", justify="right")
        mtable.add_column("Duration", justify="right")

        for m in metrics:
            inputs = ", ".join(f"{k}={v}" for k, v in m["input_rows"].items())
            mtable.add_row(m["dataset"], inputs, str(m["output_rows"]), f"{m['duration_ms']}ms")

        console.print(mtable)


@app.command()
def logs(
    pipeline_id: Annotated[str, typer.Option("--pipeline", "-p", help="Pipeline ID")],
    run_id: Annotated[str, typer.Option("--run", "-r", help="Run ID")],
    dataset: Annotated[str | None, typer.Option("--dataset", "-d", help="Filter to a specific dataset")] = None,
    fmt: Annotated[str, typer.Option("--format", "-f")] = "text",
) -> None:
    """Show logs, stdout, and stderr from a run."""
    from rowbase.errors import RowbaseError

    client = _get_client()

    try:
        run = client.get_run(pipeline_id, run_id)
        log_records = client.get_logs(pipeline_id, run_id)
        errors = client.get_errors(pipeline_id, run_id)
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e

    # Fetch stdout/stderr per dataset
    ds_output: dict[str, dict[str, str]] = {}
    for ds in run.get("datasets", []):
        ds_name = ds["name"]
        if dataset and ds_name != dataset:
            continue
        try:
            detail = client.get_dataset_detail(pipeline_id, run_id, ds_name)
            stdout = detail.get("stdout", "")
            stderr = detail.get("stderr", "")
            if stdout or stderr:
                ds_output[ds_name] = {"stdout": stdout, "stderr": stderr}
        except RowbaseError:
            pass

    if dataset:
        log_records = [l for l in log_records if l.get("dataset") == dataset]
        errors = [e for e in errors if e.get("dataset_name") == dataset]

    if fmt == "json":
        print_json({"logs": log_records, "errors": errors, "output": ds_output})
        return

    has_content = False

    # Print captured stdout/stderr per dataset
    for ds_name, output in ds_output.items():
        if output.get("stdout"):
            has_content = True
            console.print(f"\n[bold cyan]{ds_name}[/bold cyan] [dim](stdout)[/dim]")
            for line in output["stdout"].rstrip().splitlines():
                console.print(f"  {line}")
        if output.get("stderr"):
            has_content = True
            console.print(f"\n[bold cyan]{ds_name}[/bold cyan] [dim](stderr)[/dim]")
            for line in output["stderr"].rstrip().splitlines():
                console.print(f"  [yellow]{line}[/yellow]")

    # Print log records
    if log_records:
        has_content = True
        console.print(f"\n[bold]Log records[/bold] ({len(log_records)})")
        for log in log_records:
            level = log.get("level", "INFO")
            level_color = {"WARNING": "yellow", "ERROR": "red", "CRITICAL": "red bold"}.get(level, "dim")
            ds_label = f"[cyan]{log.get('dataset', '?')}[/cyan] " if log.get("dataset") else ""
            console.print(f"  {ds_label}[{level_color}]{level}[/{level_color}] {log['message']}")

    # Print errors
    if errors:
        has_content = True
        console.print(f"\n[bold red]Errors[/bold red] ({len(errors)})")
        for err in errors:
            ds_label = f"[cyan]{err['dataset_name']}[/cyan] " if err.get("dataset_name") else ""
            console.print(f"  {ds_label}[red][{err['code']}][/red] {err['message']}")
            if err.get("hint"):
                console.print(f"    [dim]Hint: {err['hint']}[/dim]")

    if not has_content:
        typer.echo("No logs, output, or errors for this run.")


@app.command()
def download(
    pipeline_id: Annotated[str, typer.Option("--pipeline", "-p", help="Pipeline ID")],
    run_id: Annotated[str, typer.Option("--run", "-r", help="Run ID")],
    dataset: Annotated[str | None, typer.Option("--dataset", "-d", help="Dataset name (default: all published)")] = None,
    output_dir: Annotated[Path, typer.Option("--output-dir", "-o")] = Path("downloads"),
    output_format: Annotated[str, typer.Option("--output-format")] = "csv",
) -> None:
    """Download dataset results from a run."""
    import polars as pl

    from rowbase.errors import RowbaseError

    client = _get_client()

    try:
        run = client.get_run(pipeline_id, run_id)
    except RowbaseError as e:
        print_error(e.message)
        raise typer.Exit(code=1) from e

    datasets_to_download = []
    if dataset:
        datasets_to_download = [dataset]
    else:
        # Download all published datasets
        datasets_to_download = [
            ds["name"] for ds in run.get("datasets", []) if ds.get("is_published")
        ]
        if not datasets_to_download:
            # Fallback to all datasets
            datasets_to_download = [ds["name"] for ds in run.get("datasets", [])]

    output_dir.mkdir(parents=True, exist_ok=True)

    for ds_name in datasets_to_download:
        try:
            data = client.get_dataset_data(pipeline_id, run_id, ds_name)
        except RowbaseError as e:
            print_error(f"Failed to download {ds_name}: {e.message}")
            continue

        rows = data.get("rows", [])
        if not rows:
            print_error(f"Dataset {ds_name}: no data")
            continue

        df = pl.DataFrame(rows)
        ext = output_format
        out_path = output_dir / f"{ds_name}.{ext}"

        if output_format == "csv":
            df.write_csv(out_path)
        elif output_format == "parquet":
            df.write_parquet(out_path)
        elif output_format == "json":
            df.write_ndjson(out_path)
        else:
            print_error(f"Unsupported format: {output_format}")
            raise typer.Exit(code=1)

        print_success(f"{ds_name} → {out_path} ({df.shape[0]} rows, {df.shape[1]} cols)")

    typer.echo(f"\nDownloaded {len(datasets_to_download)} dataset(s) to {output_dir}/")
