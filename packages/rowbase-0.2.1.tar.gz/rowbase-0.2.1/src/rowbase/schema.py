"""Pydantic model validation for dataset output DataFrames."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import polars as pl

from rowbase.errors import SchemaError

if TYPE_CHECKING:
    from pydantic import BaseModel


def validate_dataframe(
    df: pl.DataFrame,
    model: type[BaseModel],
    on_error: str = "fail",
) -> tuple[pl.DataFrame, list[SchemaError]]:
    """Validate a DataFrame against a Pydantic model.

    Args:
        df: The DataFrame to validate.
        model: Pydantic model class to validate each row against.
        on_error: "fail" raises on first error, "skip" drops invalid rows,
                  "collect" drops invalid rows and returns all errors.

    Returns:
        Tuple of (validated DataFrame, list of errors).
        For "fail" mode, raises SchemaError on first invalid row.
        For "skip" mode, returns filtered DataFrame with empty error list.
        For "collect" mode, returns filtered DataFrame with all errors.
    """
    rows: list[dict[str, Any]] = df.to_dicts()
    errors: list[SchemaError] = []
    valid_indices: list[int] = []

    for i, row in enumerate(rows):
        try:
            model.model_validate(row)
            valid_indices.append(i)
        except Exception as e:
            error = SchemaError(
                code="OUTPUT_SCHEMA_ERROR",
                message=f"Row {i} failed schema validation: {e}",
                hint=f"Check that row {i} conforms to {model.__name__}.",
                details={"row_index": i, "validation_error": str(e)},
                row_index=i,
            )

            if on_error == "fail":
                raise error from e

            errors.append(error)

            if on_error == "skip":
                continue
            # "collect" continues and collects all errors

    if valid_indices and len(valid_indices) < len(rows):
        df = df[valid_indices]
    elif not valid_indices and rows:
        df = df.clear()

    if on_error == "skip":
        return df, []

    return df, errors
