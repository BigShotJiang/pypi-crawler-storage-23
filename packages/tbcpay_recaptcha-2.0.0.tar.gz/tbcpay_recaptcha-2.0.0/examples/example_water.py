#!/usr/bin/env python3
"""Example: Checking Tbilisi Water balance using the v2 API."""

import asyncio
import sys

from tbcpay_recaptcha import create_service


async def check_water_balance(account_number: str) -> None:
    print(f"Checking Tbilisi Water balance for account {account_number}...")
    print("-" * 50)

    async with create_service("water") as service:
        result = await service.check_balance_async(account_id=account_number)

        if result["status"] == "success":
            print(f"  Customer: {result['customer_name']}")
            print(f"  Balance:  {result['balance']:.2f} {result['currency']}")
            print(f"  To pay:   {result['amount_to_pay']:.2f} {result['currency']}")
        else:
            print(f"  Error: {result['error']}")


if __name__ == "__main__":
    account = sys.argv[1] if len(sys.argv) > 1 else "123456789"
    asyncio.run(check_water_balance(account))
