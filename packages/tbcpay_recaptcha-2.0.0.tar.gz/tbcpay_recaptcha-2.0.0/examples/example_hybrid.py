#!/usr/bin/env python3
"""Example: Hybrid solver -- zendriver first, capsolver as fallback.

If the browser-based solver fails, automatically falls back to the API solver.
Set TBCPAY_CAPSOLVER_API_KEY for the fallback to work.
"""

import asyncio
import sys

from tbcpay_recaptcha import (
    CachedSolver,
    FallbackSolver,
    RetrySolver,
    SolverConfig,
    TBCPayService,
    get_service_config,
    get_solver,
)


async def check_balance(account_number: str) -> None:
    config = SolverConfig.from_env()

    # Build solver chain: zendriver -> capsolver fallback, with retry + cache
    solvers = [get_solver("zendriver", config)]
    if config.capsolver_api_key:
        solvers.append(get_solver("capsolver", config))

    solver = CachedSolver(RetrySolver(FallbackSolver(solvers)))
    svc_cfg = get_service_config("water")

    service = TBCPayService(
        service_id=svc_cfg.service_id,
        service_name=svc_cfg.service_name,
        solver=solver,
    )

    async with service:
        result = await service.check_balance_async(account_id=account_number)

        if result["status"] == "success":
            print(f"  Customer: {result['customer_name']}")
            print(f"  Balance:  {result['balance']:.2f} {result['currency']}")
        else:
            print(f"  Error: {result['error']}")


if __name__ == "__main__":
    account = sys.argv[1] if len(sys.argv) > 1 else "123456789"
    asyncio.run(check_balance(account))
