#!/usr/bin/env python3
"""Example: Using an API-based solver (2captcha or capsolver) instead of browser.

Set one of these env vars before running:
    export TBCPAY_TWOCAPTCHA_API_KEY="your-key"
    export TBCPAY_CAPSOLVER_API_KEY="your-key"
"""

import asyncio
import os
import sys

from tbcpay_recaptcha import create_service


async def check_balance(account_number: str) -> None:
    # Pick solver based on which API key is available
    if os.getenv("TBCPAY_CAPSOLVER_API_KEY"):
        backend = "capsolver"
    elif os.getenv("TBCPAY_TWOCAPTCHA_API_KEY"):
        backend = "twocaptcha"
    else:
        print("Set TBCPAY_CAPSOLVER_API_KEY or TBCPAY_TWOCAPTCHA_API_KEY first")
        sys.exit(1)

    print(f"Using {backend} solver for account {account_number}...")

    async with create_service("water", backend=backend) as service:
        result = await service.check_balance_async(account_id=account_number)

        if result["status"] == "success":
            print(f"  Customer: {result['customer_name']}")
            print(f"  Balance:  {result['balance']:.2f} {result['currency']}")
        else:
            print(f"  Error: {result['error']}")


if __name__ == "__main__":
    account = sys.argv[1] if len(sys.argv) > 1 else "123456789"
    asyncio.run(check_balance(account))
