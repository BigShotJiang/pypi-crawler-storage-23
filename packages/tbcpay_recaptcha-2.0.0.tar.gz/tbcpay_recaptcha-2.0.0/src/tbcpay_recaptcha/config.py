"""Configuration loading from environment variables."""

import os
from dataclasses import dataclass

_PREFIX = "TBCPAY_"


@dataclass
class SolverConfig:
    """Configuration for solver backends and HTTP client."""

    # Zendriver
    headless: bool = True

    # API-based solvers
    twocaptcha_api_key: str = ""
    capsolver_api_key: str = ""

    # reCAPTCHA parameters
    site_url: str = "https://tbcpay.ge"
    site_key: str = "6LeYsrYZAAAAAMhY05m7_AIPPftm2v0AgNl2nloP"
    action: str = "payment"

    # Behavior
    token_lifetime: int = 110  # seconds
    max_retries: int = 3
    retry_delay: float = 1.0  # seconds, doubles on each retry
    request_timeout: float = 15.0  # seconds for HTTP requests

    @classmethod
    def from_env(cls) -> "SolverConfig":
        """Load configuration from TBCPAY_* environment variables."""
        return cls(
            headless=os.getenv(f"{_PREFIX}HEADLESS", "true").lower() == "true",
            twocaptcha_api_key=os.getenv(f"{_PREFIX}TWOCAPTCHA_API_KEY", ""),
            capsolver_api_key=os.getenv(f"{_PREFIX}CAPSOLVER_API_KEY", ""),
            site_url=os.getenv(f"{_PREFIX}SITE_URL", cls.site_url),
            site_key=os.getenv(f"{_PREFIX}SITE_KEY", cls.site_key),
            action=os.getenv(f"{_PREFIX}ACTION", cls.action),
            token_lifetime=int(os.getenv(f"{_PREFIX}TOKEN_LIFETIME", str(cls.token_lifetime))),
            max_retries=int(os.getenv(f"{_PREFIX}MAX_RETRIES", str(cls.max_retries))),
            retry_delay=float(os.getenv(f"{_PREFIX}RETRY_DELAY", str(cls.retry_delay))),
            request_timeout=float(
                os.getenv(f"{_PREFIX}REQUEST_TIMEOUT", str(cls.request_timeout))
            ),
        )
