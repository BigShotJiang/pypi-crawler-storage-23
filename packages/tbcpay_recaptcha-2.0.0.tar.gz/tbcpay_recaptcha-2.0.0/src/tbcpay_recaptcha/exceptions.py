"""Typed exception hierarchy for tbcpay-recaptcha."""


class TBCPayError(Exception):
    """Base exception for all tbcpay-recaptcha errors."""


class SolverError(TBCPayError):
    """Base exception for solver-related errors."""


class SolverNotAvailableError(SolverError):
    """Raised when a solver backend's dependency is not installed."""

    def __init__(self, backend: str, package: str) -> None:
        super().__init__(f"{backend} backend requires '{package}' -- run: pip install {package}")
        self.backend = backend
        self.package = package


class TokenError(SolverError):
    """Raised when token generation fails after all retries."""


class BrowserError(SolverError):
    """Raised for browser lifecycle issues (start/stop/leak)."""


class APIError(TBCPayError):
    """Raised when the TBCPay API returns an error."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class ConfigError(TBCPayError):
    """Raised for configuration validation errors."""
