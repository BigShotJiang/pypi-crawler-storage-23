"""Registry of known TBCPay utility services."""

from .types import ServiceConfig

_SERVICES: dict[str, ServiceConfig] = {
    "water": ServiceConfig(service_id=2758, service_name="Tbilisi Water"),
    "electricity": ServiceConfig(service_id=771, service_name="Tbilisi Energy"),
    "telmico": ServiceConfig(service_id=2817, service_name="TELMICO"),
    "tbilservice": ServiceConfig(service_id=765, service_name="Tbilservice Group"),
    "citycom": ServiceConfig(service_id=915, service_name="CityCom", step_order=1),
}


def get_service_config(name: str) -> ServiceConfig:
    """Look up a known service by short name.

    Raises:
        KeyError: If the service name is not registered.
    """
    return _SERVICES[name]


def register_service(name: str, config: ServiceConfig) -> None:
    """Register a custom service."""
    _SERVICES[name] = config


def list_services() -> dict[str, ServiceConfig]:
    """Return all registered services."""
    return dict(_SERVICES)
