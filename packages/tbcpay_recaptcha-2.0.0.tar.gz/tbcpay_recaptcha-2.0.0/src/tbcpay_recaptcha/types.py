"""Type definitions for tbcpay-recaptcha."""

from dataclasses import dataclass, field
from typing import Any, TypedDict


class BalanceResult(TypedDict, total=False):
    """Result of a balance check. Backwards-compatible with v1 dict format."""

    account_id: str
    service: str
    status: str  # "success" or "error"
    customer_name: str
    balance: float
    amount_to_pay: float
    currency: str
    can_pay: bool
    raw_data: dict[str, Any]
    error: str


@dataclass(frozen=True)
class ServiceConfig:
    """Configuration for a known utility service."""

    service_id: int
    service_name: str
    step_order: int = 2
    root_service_id: int | None = None
    extra_context: list[dict[str, str]] = field(default_factory=list)
