"""TBCPay reCAPTCHA Solver -- utility bill checker for TBCPay (Georgia).

Quick start:
    from tbcpay_recaptcha import create_service
    async with create_service("water") as svc:
        result = await svc.check_balance_async("123456")
"""

from dataclasses import replace

from .config import SolverConfig
from .exceptions import (
    APIError,
    BrowserError,
    ConfigError,
    SolverError,
    SolverNotAvailableError,
    TBCPayError,
    TokenError,
)
from .registry import get_service_config, list_services, register_service
from .service import TBCPayService
from .solver import CachedSolver, FallbackSolver, RetrySolver, SolverBackend, get_solver
from .types import BalanceResult, ServiceConfig

__version__ = "2.0.0"


def create_service(
    service_name_or_id: str | int,
    *,
    backend: str = "zendriver",
    config: SolverConfig | None = None,
    headless: bool = True,
    step_order: int | None = None,
    with_retry: bool = True,
    with_cache: bool = True,
) -> TBCPayService:
    """Convenience factory to create a TBCPayService with sensible defaults.

    Args:
        service_name_or_id: Registry name ("water") or raw service_id (2758).
        backend: Solver backend name ("zendriver", "twocaptcha", "capsolver").
        config: SolverConfig, or None to load from env vars.
        headless: Browser headless mode (zendriver only).
        step_order: Override default step_order for the service.
        with_retry: Wrap solver in RetrySolver.
        with_cache: Wrap solver in CachedSolver.
    """
    if config is None:
        config = SolverConfig.from_env()
    config.headless = headless

    # Resolve service config
    if isinstance(service_name_or_id, str):
        svc_cfg = get_service_config(service_name_or_id)
    else:
        svc_cfg = ServiceConfig(
            service_id=service_name_or_id,
            service_name=f"Service {service_name_or_id}",
        )

    if step_order is not None:
        svc_cfg = replace(svc_cfg, step_order=step_order)

    # Build solver chain
    solver: SolverBackend = get_solver(backend, config)
    if with_retry:
        solver = RetrySolver(solver)
    if with_cache:
        solver = CachedSolver(solver)

    return TBCPayService(
        service_id=svc_cfg.service_id,
        service_name=svc_cfg.service_name,
        solver=solver,
        config=config,
    )


# Backwards-compatible convenience function
async def get_recaptcha_token(headless: bool = True, action: str = "payment") -> str | None:
    """Get a reCAPTCHA token (backwards-compatible convenience function).

    Prefer using create_service() or the solver API directly.
    """
    config = SolverConfig(headless=headless, action=action)
    solver = get_solver("zendriver", config)
    try:
        async with solver:
            return await solver.get_token()
    except Exception:
        return None


__all__ = [
    # Main API
    "TBCPayService",
    "create_service",
    "get_recaptcha_token",
    # Solvers
    "SolverBackend",
    "get_solver",
    "FallbackSolver",
    "CachedSolver",
    "RetrySolver",
    # Config & Types
    "SolverConfig",
    "ServiceConfig",
    "BalanceResult",
    # Registry
    "get_service_config",
    "list_services",
    "register_service",
    # Exceptions
    "TBCPayError",
    "SolverError",
    "SolverNotAvailableError",
    "TokenError",
    "BrowserError",
    "APIError",
    "ConfigError",
]
