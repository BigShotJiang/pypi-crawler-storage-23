"""TBCPay API client for utility bill checks."""

import logging
from typing import Any

from .config import SolverConfig
from .exceptions import APIError, TokenError
from .http import TBCPayHTTPClient
from .solver.base import SolverBackend
from .types import BalanceResult

logger = logging.getLogger(__name__)


class TBCPayService:
    """Check utility bills through TBCPay API.

    Args:
        service_id: TBCPay internal service identifier.
        service_name: Human-readable name for logging/results.
        solver: A SolverBackend instance for obtaining reCAPTCHA tokens.
        config: Optional SolverConfig (uses solver's config if not provided).
    """

    API_PATH = "/api/Service/GetNextSteps"

    def __init__(
        self,
        service_id: int,
        service_name: str,
        solver: SolverBackend,
        config: SolverConfig | None = None,
    ) -> None:
        self.service_id = service_id
        self.service_name = service_name
        self._solver = solver
        self._config = config or solver.config
        self._http = TBCPayHTTPClient(self._config)

    async def __aenter__(self) -> "TBCPayService":
        await self._solver.start()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.close()

    async def check_balance_async(
        self,
        account_id: str,
        step_order: int = 2,
        extra_context: list[dict[str, str]] | None = None,
        root_service_id: int | None = None,
    ) -> BalanceResult:
        """Check account balance via TBCPay API.

        Returns a BalanceResult dict with 'status' == 'success' or 'error'.
        """
        try:
            token = await self._solver.get_token()
        except TokenError as e:
            return self._error_result(account_id, f"Failed to get reCAPTCHA token: {e}")

        root_id = root_service_id if root_service_id is not None else self.service_id
        context: list[dict[str, str]] = [
            {"key": "ROOT_SERVICE_ID", "value": str(root_id)},
            {"key": "abonentCode", "value": str(account_id)},
        ]
        if extra_context:
            context.extend(extra_context)

        payload: dict[str, Any] = {
            "context": context,
            "recaptchaToken": token,
            "serviceId": self.service_id,
            "stepOrder": step_order,
            "origin": "Payment",
        }

        try:
            data = await self._http.post_json(self.API_PATH, payload)
        except APIError as e:
            return self._error_result(account_id, str(e))

        if data.get("success") and data.get("data"):
            return self._parse_response(data, account_id)

        error_msg = self._extract_error(data)
        return self._error_result(account_id, error_msg)

    def _parse_response(self, data: dict[str, Any], account_id: str) -> BalanceResult:
        """Parse API response into BalanceResult."""
        step_data = data["data"].get("step", {})
        step_params = step_data.get("stepParameters", [])

        if not isinstance(step_params, list):
            return self._error_result(account_id, "Invalid response format")

        params: dict[str, str] = {p["key"]: p.get("value", "") for p in step_params}

        try:
            debt = float(params.get("DEBT", "0") or "0")
            debt_amount = float(params.get("DebtAmount", str(debt)) or str(debt))
        except (ValueError, TypeError):
            debt = 0.0
            debt_amount = 0.0

        name = (
            params.get("CLIENTINFO")
            or params.get("NAME")
            or params.get("customerName")
            or "N/A"
        )

        return BalanceResult(
            account_id=params.get("abonentCode", account_id),
            service=self.service_name,
            status="success",
            customer_name=name,
            balance=debt,
            amount_to_pay=abs(debt_amount) if debt > 0 else 0,
            currency=params.get("DebtCurrency", "GEL"),
            can_pay=params.get("CANPAY") == "1",
            raw_data=params,
        )

    def _extract_error(self, data: dict[str, Any]) -> str:
        """Extract error message from API response."""
        errors = data.get("errors")
        if errors:
            if isinstance(errors, list):
                return "; ".join(
                    e.get("message", str(e)) if isinstance(e, dict) else str(e)
                    for e in errors
                )
            return str(errors)
        return "Unknown error"

    def _error_result(self, account_id: str, error: str) -> BalanceResult:
        return BalanceResult(
            account_id=account_id,
            service=self.service_name,
            status="error",
            error=error,
        )

    async def close(self) -> None:
        """Release all resources."""
        await self._solver.stop()
        await self._http.close()
