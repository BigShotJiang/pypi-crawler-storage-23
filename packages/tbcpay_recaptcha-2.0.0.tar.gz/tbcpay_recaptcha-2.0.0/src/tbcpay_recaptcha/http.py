"""Async HTTP client for TBCPay API."""

import logging
from typing import Any

import aiohttp

from .config import SolverConfig
from .exceptions import APIError

logger = logging.getLogger(__name__)

DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/135.0.0.0 Safari/537.36"
)

DEFAULT_HEADERS = {
    "Content-Type": "application/json",
    "Clientid": "Web",
    "Origin": "https://tbcpay.ge",
    "Referer": "https://tbcpay.ge/",
    "Accept-Language": "en-US,en;q=0.9",
    "Lang": "en-US",
}


class TBCPayHTTPClient:
    """Async HTTP client for TBCPay API requests."""

    API_BASE = "https://api.tbcpay.ge"

    def __init__(self, config: SolverConfig) -> None:
        self.config = config
        self._session: aiohttp.ClientSession | None = None

    async def _ensure_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            headers = {**DEFAULT_HEADERS, "User-Agent": DEFAULT_UA}
            timeout = aiohttp.ClientTimeout(total=self.config.request_timeout)
            self._session = aiohttp.ClientSession(headers=headers, timeout=timeout)
        return self._session

    async def post_json(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        """POST JSON to TBCPay API and return parsed response.

        Raises:
            APIError: On non-200 status or network errors.
        """
        session = await self._ensure_session()
        url = f"{self.API_BASE}{path}"
        try:
            async with session.post(url, json=payload) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    raise APIError(f"HTTP {resp.status}: {text[:200]}", status_code=resp.status)
                data = await resp.json()
                if not isinstance(data, dict):
                    raise APIError("Unexpected response format")
                return data
        except aiohttp.ClientError as e:
            raise APIError(f"Network error: {e}") from e

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
