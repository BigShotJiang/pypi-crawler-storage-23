"""Zendriver-based reCAPTCHA solver (browser automation via CDP)."""

import asyncio
import logging
import re

from ..config import SolverConfig
from ..exceptions import BrowserError, SolverNotAvailableError, TokenError
from .base import SolverBackend

try:
    import zendriver as zd
except ImportError:
    zd = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)

_SAFE_ACTION_RE = re.compile(r"^[a-zA-Z0-9_-]+$")
_SAFE_SITEKEY_RE = re.compile(r"^6[A-Za-z0-9_-]{38,}$")


class ZendriverSolver(SolverBackend):
    """Browser-based solver using zendriver (CDP).

    Launches a real Chromium instance, navigates to the target page,
    and calls grecaptcha.execute() to get tokens with high behavioral scores.
    """

    def __init__(self, config: SolverConfig) -> None:
        if zd is None:
            raise SolverNotAvailableError("zendriver", "zendriver")
        super().__init__(config)
        self._browser: object | None = None
        self._page: object | None = None
        self._detected_site_key: str | None = None

    async def start(self) -> None:
        if self._browser is not None:
            return
        logger.info("Starting zendriver browser...")
        self._browser = await zd.start(headless=self.config.headless)
        self._page = await self._browser.get(self.config.site_url)
        await asyncio.sleep(3)  # reCAPTCHA JS init time
        logger.info("Zendriver browser ready")

    async def stop(self) -> None:
        if self._browser:
            logger.info("Stopping zendriver browser...")
            try:
                await self._browser.stop()
            except Exception as e:
                logger.warning("Error stopping browser: %s", e)
            self._browser = None
            self._page = None
            self._detected_site_key = None

    def __del__(self) -> None:
        if self._browser is not None:
            logger.warning(
                "ZendriverSolver garbage-collected with browser still running. "
                "Call await solver.stop() or use 'async with' to prevent leaks."
            )

    async def get_token(self) -> str:
        if not self._browser or not self._page:
            raise BrowserError("Browser not started -- call start() or use 'async with'")

        site_key = self._detected_site_key or self.config.site_key
        token = await self._try_get_token(site_key)

        # If failed with current key and we haven't tried auto-detection yet
        if token is None and self._detected_site_key is None:
            logger.warning("Failed with configured key, trying auto-detection...")
            detected = await self._detect_site_key()
            if detected and detected != self.config.site_key:
                self._detected_site_key = detected
                logger.info("Retrying with auto-detected key...")
                token = await self._try_get_token(detected)

        if token is None:
            raise TokenError("Failed to obtain reCAPTCHA token")
        return token

    async def _try_get_token(self, site_key: str) -> str | None:
        """Try to get a reCAPTCHA token with the given site key."""
        action = self.config.action

        # Validate before JS interpolation to prevent injection
        if not _SAFE_ACTION_RE.match(action):
            raise TokenError(f"Invalid reCAPTCHA action: {action!r}")
        if not _SAFE_SITEKEY_RE.match(site_key):
            raise TokenError(f"Invalid reCAPTCHA site key format: {site_key[:20]}...")

        logger.info("Getting token with site key: %s...", site_key[:20])

        script = f"""
        (async () => {{
            for (let i = 0; i < 60; i++) {{
                if (typeof grecaptcha !== 'undefined'
                    && typeof grecaptcha.execute === 'function') break;
                await new Promise(r => setTimeout(r, 500));
            }}
            if (typeof grecaptcha === 'undefined' || typeof grecaptcha.execute !== 'function') {{
                throw new Error('grecaptcha.execute not available after 30s');
            }}
            return await grecaptcha.execute('{site_key}', {{action: '{action}'}});
        }})()
        """

        try:
            cdp_result = await self._page.send(zd.cdp.runtime.evaluate(
                expression=script,
                await_promise=True,
                return_by_value=True,
            ))

            result, exception = cdp_result if isinstance(cdp_result, tuple) else (cdp_result, None)

            if exception:
                logger.error("CDP exception: %s", exception)
                return None

            if result and hasattr(result, "value") and isinstance(result.value, str):
                logger.info("reCAPTCHA token obtained (length: %d)", len(result.value))
                return result.value

            logger.error("Failed to extract token from CDP result")
            return None

        except asyncio.TimeoutError:
            logger.error("Timeout waiting for reCAPTCHA token")
            return None
        except Exception as e:
            logger.error("Error getting reCAPTCHA token: %s", e)
            return None

    async def _detect_site_key(self) -> str | None:
        """Auto-detect reCAPTCHA site key from the page."""
        try:
            # Method 1: JS introspection
            js_result = await self._page.send(zd.cdp.runtime.evaluate(
                expression="""
                (() => {
                    if (window.grecaptcha && window.grecaptcha.enterprise) {
                        return window.grecaptcha.enterprise.sitekey;
                    }
                    const scripts = Array.from(document.scripts);
                    for (const script of scripts) {
                        const content = script.innerHTML || script.src;
                        const match = content.match(/6[A-Za-z0-9_-]{38,}/);
                        if (match) return match[0];
                    }
                    return null;
                })()
                """,
                return_by_value=True,
            ))

            result, exception = js_result if isinstance(js_result, tuple) else (js_result, None)
            if not exception and result and hasattr(result, "value") and result.value:
                key = result.value
                if len(key) > 30 and key.startswith("6"):
                    logger.info("Auto-detected site key from JS: %s...", key[:20])
                    return key
        except Exception as e:
            logger.debug("JS detection failed: %s", e)

        try:
            # Method 2: HTML regex parsing
            html_result = await self._page.send(zd.cdp.runtime.evaluate(
                expression="document.documentElement.outerHTML",
                return_by_value=True,
            ))
            result, exception = (
                html_result if isinstance(html_result, tuple) else (html_result, None)
            )
            if exception or not result or not hasattr(result, "value"):
                return None

            html = result.value
            patterns = [
                r"6[A-Za-z0-9_-]{38,}",
                r"grecaptcha\.execute\(['\"]([^\"']+)['\"]",
                r"data-sitekey=['\"]([^\"']+)['\"]",
                r"sitekey['\"]?\s*:\s*['\"]([^\"']+)['\"]",
                r"render['\"]?\s*:\s*['\"]([^\"']+)['\"]",
            ]
            for pattern in patterns:
                match = re.search(pattern, html, re.IGNORECASE)
                if match:
                    key = match.group(1) if match.lastindex else match.group(0)
                    if len(key) > 30 and key.startswith("6"):
                        logger.info("Auto-detected site key from HTML: %s...", key[:20])
                        return key
        except Exception as e:
            logger.debug("HTML detection failed: %s", e)

        logger.warning("Could not auto-detect site key")
        return None
