"""Solver backends and factory function."""

from __future__ import annotations

import asyncio
import importlib
import logging
import time
from collections.abc import Sequence

from ..config import SolverConfig
from ..exceptions import TokenError
from .base import SolverBackend

logger = logging.getLogger(__name__)

# Registry of known backend names -> (module, class_name)
_BACKENDS: dict[str, tuple[str, str]] = {
    "zendriver": (".zendriver", "ZendriverSolver"),
    "twocaptcha": (".twocaptcha", "TwoCaptchaSolver"),
    "capsolver": (".capsolver", "CapSolverSolver"),
}


def get_solver(backend: str, config: SolverConfig | None = None) -> SolverBackend:
    """Create a solver backend by name.

    Args:
        backend: One of "zendriver", "twocaptcha", "capsolver".
        config: Configuration. Uses SolverConfig.from_env() if None.
    """
    if config is None:
        config = SolverConfig.from_env()

    if backend not in _BACKENDS:
        raise ValueError(f"Unknown solver backend: {backend!r}. Known: {list(_BACKENDS)}")

    module_name, class_name = _BACKENDS[backend]
    mod = importlib.import_module(module_name, package=__package__)
    cls = getattr(mod, class_name)
    return cls(config)


class FallbackSolver(SolverBackend):
    """Tries multiple solver backends in order until one succeeds."""

    def __init__(
        self, solvers: Sequence[SolverBackend], config: SolverConfig | None = None,
    ) -> None:
        super().__init__(config or (solvers[0].config if solvers else SolverConfig()))
        self._solvers = list(solvers)

    async def start(self) -> None:
        for solver in self._solvers:
            await solver.start()

    async def stop(self) -> None:
        for solver in self._solvers:
            await solver.stop()

    async def get_token(self) -> str:
        last_error: Exception | None = None
        for solver in self._solvers:
            try:
                return await solver.get_token()
            except TokenError as e:
                logger.warning("Solver %s failed: %s", solver.name, e)
                last_error = e
        raise TokenError(f"All {len(self._solvers)} solvers failed") from last_error


class CachedSolver(SolverBackend):
    """Wraps another solver and caches tokens for a configurable duration."""

    def __init__(self, inner: SolverBackend) -> None:
        super().__init__(inner.config)
        self._inner = inner
        self._cached_token: str | None = None
        self._cached_at: float = 0.0

    async def start(self) -> None:
        await self._inner.start()

    async def stop(self) -> None:
        await self._inner.stop()
        self._cached_token = None

    async def get_token(self) -> str:
        now = time.monotonic()
        if self._cached_token and (now - self._cached_at) < self.config.token_lifetime:
            age = int(now - self._cached_at)
            logger.debug("Using cached token (%ds old)", age)
            return self._cached_token

        token = await self._inner.get_token()
        self._cached_token = token
        self._cached_at = now
        return token


class RetrySolver(SolverBackend):
    """Wraps another solver and retries on failure with exponential backoff."""

    def __init__(self, inner: SolverBackend) -> None:
        super().__init__(inner.config)
        self._inner = inner

    async def start(self) -> None:
        await self._inner.start()

    async def stop(self) -> None:
        await self._inner.stop()

    async def get_token(self) -> str:
        last_error: Exception | None = None
        delay = self.config.retry_delay
        for attempt in range(1, self.config.max_retries + 1):
            try:
                return await self._inner.get_token()
            except TokenError as e:
                last_error = e
                if attempt < self.config.max_retries:
                    logger.warning(
                        "Attempt %d/%d failed: %s. Retrying in %.1fs...",
                        attempt, self.config.max_retries, e, delay,
                    )
                    await asyncio.sleep(delay)
                    delay *= 2
        raise TokenError(f"Failed after {self.config.max_retries} attempts") from last_error


__all__ = [
    "SolverBackend",
    "get_solver",
    "FallbackSolver",
    "CachedSolver",
    "RetrySolver",
]
