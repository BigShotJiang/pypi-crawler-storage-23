"""Abstract base for solver backends."""

from abc import ABC, abstractmethod
from typing import Any

from ..config import SolverConfig


class SolverBackend(ABC):
    """Base class for reCAPTCHA token solvers.

    All backends must implement get_token(). Backends that manage
    resources (browsers, sessions) should override start()/stop()
    and support async context manager usage.
    """

    def __init__(self, config: SolverConfig) -> None:
        self.config = config

    async def start(self) -> None:  # noqa: B027
        """Initialize resources. Override if the backend needs setup."""

    async def stop(self) -> None:  # noqa: B027
        """Release resources. Override if the backend needs cleanup."""

    async def __aenter__(self) -> "SolverBackend":
        await self.start()
        return self

    async def __aexit__(
        self, exc_type: type[BaseException] | None, exc_val: Any, exc_tb: Any,
    ) -> None:
        await self.stop()

    @abstractmethod
    async def get_token(self) -> str:
        """Obtain a reCAPTCHA v3 token.

        Returns:
            The token string.

        Raises:
            TokenError: If token generation fails.
        """
        ...

    @property
    def name(self) -> str:
        """Human-readable name for this backend."""
        return self.__class__.__name__
