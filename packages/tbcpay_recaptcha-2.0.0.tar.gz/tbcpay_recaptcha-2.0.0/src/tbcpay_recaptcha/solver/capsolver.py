"""CapSolver API-based reCAPTCHA solver."""

import asyncio
import logging

from ..config import SolverConfig
from ..exceptions import SolverNotAvailableError, TokenError
from .base import SolverBackend

try:
    import capsolver as _capsolver
except ImportError:
    _capsolver = None  # type: ignore[assignment]

logger = logging.getLogger(__name__)


class CapSolverSolver(SolverBackend):
    """Solver using capsolver.com API (AI-powered).

    Requires TBCPAY_CAPSOLVER_API_KEY env var or config.capsolver_api_key.
    Install: pip install capsolver
    """

    def __init__(self, config: SolverConfig) -> None:
        if _capsolver is None:
            raise SolverNotAvailableError("capsolver", "capsolver")
        if not config.capsolver_api_key:
            raise TokenError("TBCPAY_CAPSOLVER_API_KEY not set")
        super().__init__(config)
        _capsolver.api_key = config.capsolver_api_key

    async def get_token(self) -> str:
        loop = asyncio.get_running_loop()
        try:
            result = await loop.run_in_executor(
                None,
                lambda: _capsolver.solve({
                    "type": "ReCaptchaV3TaskProxyLess",
                    "websiteURL": self.config.site_url,
                    "websiteKey": self.config.site_key,
                    "pageAction": self.config.action,
                    "minScore": 0.9,
                }),
            )
            token = result.get("gRecaptchaResponse", "") if isinstance(result, dict) else ""
            if not token:
                raise TokenError("capsolver returned empty token")
            logger.info("capsolver token obtained (length: %d)", len(token))
            return token
        except TokenError:
            raise
        except Exception as e:
            raise TokenError(f"capsolver API error: {e}") from e
