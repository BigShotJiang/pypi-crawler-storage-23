"""2Captcha API-based reCAPTCHA solver."""

import asyncio
import logging

from ..config import SolverConfig
from ..exceptions import SolverNotAvailableError, TokenError
from .base import SolverBackend

try:
    from twocaptcha import TwoCaptcha
except ImportError:
    TwoCaptcha = None  # type: ignore[assignment, misc]

logger = logging.getLogger(__name__)


class TwoCaptchaSolver(SolverBackend):
    """Solver using 2captcha.com API (human-powered).

    Requires TBCPAY_TWOCAPTCHA_API_KEY env var or config.twocaptcha_api_key.
    Install: pip install 2captcha-python
    """

    def __init__(self, config: SolverConfig) -> None:
        if TwoCaptcha is None:
            raise SolverNotAvailableError("twocaptcha", "2captcha-python")
        if not config.twocaptcha_api_key:
            raise TokenError("TBCPAY_TWOCAPTCHA_API_KEY not set")
        super().__init__(config)
        self._client = TwoCaptcha(config.twocaptcha_api_key)

    async def get_token(self) -> str:
        loop = asyncio.get_running_loop()
        try:
            result = await loop.run_in_executor(
                None,
                lambda: self._client.recaptcha(
                    sitekey=self.config.site_key,
                    url=self.config.site_url,
                    version="v3",
                    action=self.config.action,
                    score=0.9,
                ),
            )
            token = result.get("code", "") if isinstance(result, dict) else str(result)
            if not token:
                raise TokenError("2captcha returned empty token")
            logger.info("2captcha token obtained (length: %d)", len(token))
            return token
        except TokenError:
            raise
        except Exception as e:
            raise TokenError(f"2captcha API error: {e}") from e
