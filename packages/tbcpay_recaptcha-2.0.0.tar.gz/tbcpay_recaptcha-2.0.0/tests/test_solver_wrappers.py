"""Tests for solver wrappers: CachedSolver, RetrySolver, FallbackSolver."""

import pytest

from tbcpay_recaptcha.config import SolverConfig
from tbcpay_recaptcha.exceptions import TokenError
from tbcpay_recaptcha.solver import CachedSolver, FallbackSolver, RetrySolver

from .conftest import FailingSolver, MockSolver


class TestCachedSolver:
    @pytest.mark.asyncio
    async def test_caches_token(self, mock_solver: MockSolver) -> None:
        cached = CachedSolver(mock_solver)

        token1 = await cached.get_token()
        token2 = await cached.get_token()

        assert token1 == token2 == "mock-token-123"
        assert mock_solver.get_token_count == 1  # called only once

    @pytest.mark.asyncio
    async def test_cache_expires(self) -> None:
        config = SolverConfig(token_lifetime=0)  # expire immediately
        solver = MockSolver(config=config)
        cached = CachedSolver(solver)

        await cached.get_token()
        await cached.get_token()

        assert solver.get_token_count == 2  # called twice

    @pytest.mark.asyncio
    async def test_start_stop_delegates(self, mock_solver: MockSolver) -> None:
        cached = CachedSolver(mock_solver)
        await cached.start()
        assert mock_solver.started
        await cached.stop()
        assert mock_solver.stopped

    @pytest.mark.asyncio
    async def test_stop_clears_cache(self, mock_solver: MockSolver) -> None:
        cached = CachedSolver(mock_solver)
        await cached.get_token()
        assert mock_solver.get_token_count == 1

        await cached.stop()
        # After stop, cache should be cleared, so next call fetches again
        mock_solver.stopped = False  # reset for re-start
        await cached.get_token()
        assert mock_solver.get_token_count == 2


class TestRetrySolver:
    @pytest.mark.asyncio
    async def test_succeeds_first_try(self, mock_solver: MockSolver) -> None:
        retry = RetrySolver(mock_solver)
        token = await retry.get_token()
        assert token == "mock-token-123"
        assert mock_solver.get_token_count == 1

    @pytest.mark.asyncio
    async def test_retries_on_failure(self, config: SolverConfig) -> None:
        # Solver that fails twice, then succeeds
        call_count = 0

        class FlakySolver(MockSolver):
            async def get_token(self) -> str:
                nonlocal call_count
                call_count += 1
                if call_count < 3:
                    raise TokenError(f"Fail {call_count}")
                return "success-token"

        solver = FlakySolver(config=config)
        retry = RetrySolver(solver)
        token = await retry.get_token()
        assert token == "success-token"
        assert call_count == 3

    @pytest.mark.asyncio
    async def test_exhausts_retries(self, failing_solver: FailingSolver) -> None:
        retry = RetrySolver(failing_solver)
        with pytest.raises(TokenError, match="Failed after 3 attempts"):
            await retry.get_token()
        assert failing_solver.attempt_count == 3

    @pytest.mark.asyncio
    async def test_start_stop_delegates(self, mock_solver: MockSolver) -> None:
        retry = RetrySolver(mock_solver)
        await retry.start()
        assert mock_solver.started
        await retry.stop()
        assert mock_solver.stopped


class TestFallbackSolver:
    @pytest.mark.asyncio
    async def test_uses_first_solver(self, config: SolverConfig) -> None:
        solver1 = MockSolver(token="token-1", config=config)
        solver2 = MockSolver(token="token-2", config=config)
        fallback = FallbackSolver([solver1, solver2])

        token = await fallback.get_token()
        assert token == "token-1"
        assert solver1.get_token_count == 1
        assert solver2.get_token_count == 0

    @pytest.mark.asyncio
    async def test_falls_back_on_failure(self, config: SolverConfig) -> None:
        solver1 = FailingSolver(config=config)
        solver2 = MockSolver(token="fallback-token", config=config)
        fallback = FallbackSolver([solver1, solver2])

        token = await fallback.get_token()
        assert token == "fallback-token"
        assert solver1.attempt_count == 1
        assert solver2.get_token_count == 1

    @pytest.mark.asyncio
    async def test_all_fail(self, config: SolverConfig) -> None:
        solver1 = FailingSolver(config=config)
        solver2 = FailingSolver(config=config)
        fallback = FallbackSolver([solver1, solver2])

        with pytest.raises(TokenError, match="All 2 solvers failed"):
            await fallback.get_token()

    @pytest.mark.asyncio
    async def test_start_stop_all(self, config: SolverConfig) -> None:
        solver1 = MockSolver(config=config)
        solver2 = MockSolver(config=config)
        fallback = FallbackSolver([solver1, solver2])

        await fallback.start()
        assert solver1.started and solver2.started

        await fallback.stop()
        assert solver1.stopped and solver2.stopped
