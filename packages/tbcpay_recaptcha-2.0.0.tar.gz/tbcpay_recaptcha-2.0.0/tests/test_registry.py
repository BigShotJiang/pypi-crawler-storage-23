"""Tests for the service registry."""

import pytest

from tbcpay_recaptcha.registry import get_service_config, list_services, register_service
from tbcpay_recaptcha.types import ServiceConfig


class TestRegistry:
    def test_known_services(self) -> None:
        water = get_service_config("water")
        assert water.service_id == 2758
        assert water.service_name == "Tbilisi Water"
        assert water.step_order == 2

    def test_citycom_step_order(self) -> None:
        citycom = get_service_config("citycom")
        assert citycom.step_order == 1

    def test_unknown_service(self) -> None:
        with pytest.raises(KeyError):
            get_service_config("nonexistent")

    def test_register_custom(self) -> None:
        cfg = ServiceConfig(service_id=9999, service_name="Custom Service", step_order=3)
        register_service("custom", cfg)
        result = get_service_config("custom")
        assert result.service_id == 9999
        assert result.step_order == 3

    def test_list_services(self) -> None:
        services = list_services()
        assert "water" in services
        assert "electricity" in services
        assert len(services) >= 5

    def test_list_returns_copy(self) -> None:
        s1 = list_services()
        s2 = list_services()
        assert s1 is not s2
