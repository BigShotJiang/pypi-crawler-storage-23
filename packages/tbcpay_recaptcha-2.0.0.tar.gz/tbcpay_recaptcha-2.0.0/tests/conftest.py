"""Shared test fixtures."""

import pytest

from tbcpay_recaptcha.config import SolverConfig
from tbcpay_recaptcha.exceptions import TokenError
from tbcpay_recaptcha.solver.base import SolverBackend


class MockSolver(SolverBackend):
    """Solver that returns a configurable token for testing."""

    def __init__(
        self,
        token: str = "mock-token-123",
        fail: bool = False,
        config: SolverConfig | None = None,
    ) -> None:
        super().__init__(config or SolverConfig())
        self.token = token
        self.fail = fail
        self.get_token_count = 0
        self.started = False
        self.stopped = False

    async def start(self) -> None:
        self.started = True

    async def stop(self) -> None:
        self.stopped = True

    async def get_token(self) -> str:
        self.get_token_count += 1
        if self.fail:
            raise TokenError("Mock solver failure")
        return self.token


class FailingSolver(SolverBackend):
    """Solver that always fails -- for testing retry/fallback."""

    def __init__(self, config: SolverConfig | None = None) -> None:
        super().__init__(config or SolverConfig())
        self.attempt_count = 0

    async def get_token(self) -> str:
        self.attempt_count += 1
        raise TokenError(f"Failure #{self.attempt_count}")


@pytest.fixture
def config() -> SolverConfig:
    return SolverConfig(
        max_retries=3,
        retry_delay=0.01,  # fast retries for tests
        token_lifetime=110,
    )


@pytest.fixture
def mock_solver(config: SolverConfig) -> MockSolver:
    return MockSolver(config=config)


@pytest.fixture
def failing_solver(config: SolverConfig) -> FailingSolver:
    return FailingSolver(config=config)
