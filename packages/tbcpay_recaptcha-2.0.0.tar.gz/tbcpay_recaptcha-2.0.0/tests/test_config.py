"""Tests for configuration loading."""

import os

from tbcpay_recaptcha.config import SolverConfig


class TestSolverConfig:
    def test_defaults(self) -> None:
        cfg = SolverConfig()
        assert cfg.headless is True
        assert cfg.twocaptcha_api_key == ""
        assert cfg.capsolver_api_key == ""
        assert cfg.site_url == "https://tbcpay.ge"
        assert cfg.action == "payment"
        assert cfg.token_lifetime == 110
        assert cfg.max_retries == 3
        assert cfg.retry_delay == 1.0
        assert cfg.request_timeout == 15.0

    def test_from_env(self, monkeypatch: object) -> None:
        mp = monkeypatch  # type: ignore[assignment]
        mp.setenv("TBCPAY_HEADLESS", "false")
        mp.setenv("TBCPAY_TWOCAPTCHA_API_KEY", "test-key-123")
        mp.setenv("TBCPAY_CAPSOLVER_API_KEY", "cap-key-456")
        mp.setenv("TBCPAY_MAX_RETRIES", "5")
        mp.setenv("TBCPAY_RETRY_DELAY", "2.5")

        cfg = SolverConfig.from_env()
        assert cfg.headless is False
        assert cfg.twocaptcha_api_key == "test-key-123"
        assert cfg.capsolver_api_key == "cap-key-456"
        assert cfg.max_retries == 5
        assert cfg.retry_delay == 2.5

    def test_from_env_defaults(self) -> None:
        # Ensure defaults work when no env vars are set
        # (clear any that might be set in the test environment)
        for key in list(os.environ):
            if key.startswith("TBCPAY_"):
                del os.environ[key]

        cfg = SolverConfig.from_env()
        assert cfg.headless is True
        assert cfg.max_retries == 3

    def test_custom_values(self) -> None:
        cfg = SolverConfig(
            headless=False,
            max_retries=10,
            site_key="custom-key",
        )
        assert cfg.headless is False
        assert cfg.max_retries == 10
        assert cfg.site_key == "custom-key"
