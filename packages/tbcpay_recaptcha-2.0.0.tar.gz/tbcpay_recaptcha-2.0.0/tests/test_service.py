"""Tests for TBCPayService -- response parsing, error handling."""

from tbcpay_recaptcha.service import TBCPayService

from .conftest import MockSolver


def make_service(solver: MockSolver) -> TBCPayService:
    return TBCPayService(
        service_id=2758,
        service_name="Test Water",
        solver=solver,
    )


class TestParseResponse:
    """Test _parse_response with various API response shapes."""

    def setup_method(self) -> None:
        self.solver = MockSolver()
        self.service = make_service(self.solver)

    def test_successful_response(self) -> None:
        data = {
            "success": True,
            "data": {
                "step": {
                    "stepParameters": [
                        {"key": "abonentCode", "value": "123456"},
                        {"key": "CLIENTINFO", "value": "John Doe"},
                        {"key": "DEBT", "value": "25.50"},
                        {"key": "DebtAmount", "value": "25.50"},
                        {"key": "DebtCurrency", "value": "GEL"},
                        {"key": "CANPAY", "value": "1"},
                    ]
                }
            },
        }
        result = self.service._parse_response(data, "123456")
        assert result["status"] == "success"
        assert result["customer_name"] == "John Doe"
        assert result["balance"] == 25.50
        assert result["amount_to_pay"] == 25.50
        assert result["currency"] == "GEL"
        assert result["can_pay"] is True
        assert result["account_id"] == "123456"

    def test_zero_debt(self) -> None:
        data = {
            "success": True,
            "data": {
                "step": {
                    "stepParameters": [
                        {"key": "DEBT", "value": "0"},
                        {"key": "DebtAmount", "value": "0"},
                        {"key": "NAME", "value": "Jane"},
                        {"key": "CANPAY", "value": "0"},
                    ]
                }
            },
        }
        result = self.service._parse_response(data, "999")
        assert result["status"] == "success"
        assert result["balance"] == 0.0
        assert result["amount_to_pay"] == 0
        assert result["can_pay"] is False

    def test_negative_debt(self) -> None:
        """Negative debt means overpayment/credit."""
        data = {
            "success": True,
            "data": {
                "step": {
                    "stepParameters": [
                        {"key": "DEBT", "value": "-10.0"},
                        {"key": "DebtAmount", "value": "-10.0"},
                    ]
                }
            },
        }
        result = self.service._parse_response(data, "123")
        assert result["balance"] == -10.0
        assert result["amount_to_pay"] == 0  # negative debt = no payment needed

    def test_invalid_debt_values(self) -> None:
        data = {
            "success": True,
            "data": {
                "step": {
                    "stepParameters": [
                        {"key": "DEBT", "value": "not-a-number"},
                    ]
                }
            },
        }
        result = self.service._parse_response(data, "123")
        assert result["status"] == "success"
        assert result["balance"] == 0.0

    def test_missing_step_parameters(self) -> None:
        data = {"success": True, "data": {"step": {}}}
        result = self.service._parse_response(data, "123")
        assert result["status"] == "success"
        assert result["customer_name"] == "N/A"

    def test_invalid_step_parameters_type(self) -> None:
        data = {"success": True, "data": {"step": {"stepParameters": "not-a-list"}}}
        result = self.service._parse_response(data, "123")
        assert result["status"] == "error"

    def test_customer_name_fallback(self) -> None:
        """Falls back through CLIENTINFO -> NAME -> customerName -> N/A."""
        data = {
            "success": True,
            "data": {"step": {"stepParameters": [{"key": "customerName", "value": "Fallback"}]}},
        }
        result = self.service._parse_response(data, "123")
        assert result["customer_name"] == "Fallback"


class TestExtractError:
    def setup_method(self) -> None:
        self.solver = MockSolver()
        self.service = make_service(self.solver)

    def test_list_errors(self) -> None:
        data = {"errors": [{"message": "Error 1"}, {"message": "Error 2"}]}
        assert self.service._extract_error(data) == "Error 1; Error 2"

    def test_string_errors(self) -> None:
        data = {"errors": "Something went wrong"}
        assert self.service._extract_error(data) == "Something went wrong"

    def test_no_errors(self) -> None:
        data = {}
        assert self.service._extract_error(data) == "Unknown error"

    def test_list_with_plain_strings(self) -> None:
        data = {"errors": ["err1", "err2"]}
        assert self.service._extract_error(data) == "err1; err2"


class TestErrorResult:
    def test_error_result_structure(self) -> None:
        solver = MockSolver()
        service = make_service(solver)
        result = service._error_result("acc123", "Something failed")
        assert result["account_id"] == "acc123"
        assert result["service"] == "Test Water"
        assert result["status"] == "error"
        assert result["error"] == "Something failed"
