##########################################################################
#
#  Copyright (c) 2026 - Datatailr Inc.
#  All Rights Reserved.
#
#  This file is part of Datatailr and subject to the terms and conditions
#  defined in 'LICENSE.txt'. Unauthorized copying and/or distribution
#  of this file, in parts or full, via any medium is strictly prohibited.
##########################################################################

from __future__ import annotations

from datatailr.wrapper import dt__Kv
from datatailr import ACL


__client__ = dt__Kv()


class Secrets:
    """Interface for managing secrets stored in the Datatailr platform.

    Secrets are sensitive key-value pairs (passwords, API keys, tokens, etc.)
    that are stored securely and scoped to the current environment
    (dev/pre/prod).  Access is controlled by per-secret ACLs.

    Example:
        ```python
        from datatailr import Secrets
        secrets = Secrets()
        db_password = secrets.get("database_password")
        all_secrets = secrets.ls()
        ```
    """

    def get(self, key: str) -> str:
        """
        Retrieve a secret value by its key. Only secrets that are available at the current environment (dev/pre/prod) can be accessed.
        The user must have the appropriate permissions to access the secret.

        Args:
            key (str): The key of the secret to retrieve.

        Returns:
            str: The value of the secret.

        Example:
        ```python
        from datatailr import Secrets
        secrets = Secrets()
        db_password = secrets.get("database_password")
        ```
        """
        return __client__.get(key, secure=True)

    def ls(self) -> list[dict[str, str | ACL]]:
        """
        List all available secret keys in the current environment (dev/pre/prod).
        The user must have the appropriate permissions to list the secrets.

        Returns:
            list[dict[str, str|ACL]]: A list of all secret keys along with their ACLs.
        Example:
        ```python
        from datatailr import Secrets
        secrets = Secrets()
        all_secrets = secrets.ls()
        ```
        """
        records = __client__.ls(acls=True, secure=True) or []
        return [
            record | {"acl": ACL.from_dict(record.get("acl", {}))} for record in records
        ]
