# *************************************************************************
#
#  Copyright (c) 2026 - Datatailr Inc.
#  All Rights Reserved.
#
#  This file is part of Datatailr and subject to the terms and conditions
#  defined in 'LICENSE.txt'. Unauthorized copying and/or distribution
#  of this file, in parts or full, via any medium is strictly prohibited.
# *************************************************************************

from __future__ import annotations

import argparse


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dt",
        description=(
            "Remote dt CLI client for the Datatailr platform. "
            "Use dt <command> <subcommand> [args...] as usual to issue remote commands. "
            "Use 'datatailr login' and setup commands for local configuration."
        ),
    )

    return parser
