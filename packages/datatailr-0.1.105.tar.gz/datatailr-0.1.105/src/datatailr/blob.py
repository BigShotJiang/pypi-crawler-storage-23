##########################################################################
#
#  Copyright (c) 2026 - Datatailr Inc.
#  All Rights Reserved.
#
#  This file is part of Datatailr and subject to the terms and conditions
#  defined in 'LICENSE.txt'. Unauthorized copying and/or distribution
#  of this file, in parts or full, via any medium is strictly prohibited.
##########################################################################

from __future__ import annotations

from typing import Optional

from datatailr.acl import ACL
from datatailr.wrapper import dt__Blob

# Datatailr Blob API Client
__client__ = dt__Blob()


class Blob:
    """Interface for Datatailr's binary large object (blob) storage.

    Blob storage allows you to persist and retrieve arbitrary files and binary
    data.  Each blob is identified by a unique name (key).

    Example:
        ```python
        from datatailr import Blob
        blob = Blob()
        blob.put("greeting", b"Hello, world!")
        data = blob.get("greeting")
        ```
    """

    def ls(self, path: str) -> list[str]:
        """
        List files in the specified path.

        :param path: The path to list files from.
        :return: A list of file names in the specified path.
        """
        return __client__.ls(path)

    def get_file(self, name: str, path: str):
        """
        Copy a blob file to a local file.

        Args:
            name (str): The name of the blob to retrieve.
            path (str): The path to store the blob as a file.
        """
        return __client__.cp(f"blob://{name}", path)

    def put_file(self, name: str, path: str, acl: Optional[ACL] = None):
        """
        Copy a local file to a blob.

        Args:
            name (str): The name of the blob to create.
            path (str): The path of the local file to copy.
            acl (ACL): The access control list for the blob.
        """
        if acl is None:
            return __client__.cp(path, f"blob://{name}")
        return __client__.cp(path, f"blob://{name}", **acl.to_cli_command())

    def exists(self, name: str) -> bool:
        """
        Check if a blob exists.

        Args:
            name (str): The name of the blob to check.

        Returns:
            bool: True if the blob exists, False otherwise.
        """
        return __client__.exists(name)

    def delete(self, name: str):
        """
        Delete a blob.

        Args:
            name (str): The name of the blob to delete.
        """
        return __client__.rm(name)

    def get(self, name: str) -> bytes:
        """
        Get a blob object.

        Args:
            name (str): The name of the blob to retrieve.

        Returns:
            Blob: The blob object.
        """
        return __client__.get(f"blob://{name}", _raw_output=True)

    def put(self, name: str, blob: bytes | str, acl: Optional[ACL] = None):
        """
        Put a blob object into the blob storage.

        Args:
            name (str): The name of the blob to create.
            blob: The blob object to store.
            acl (ACL): The access control list for the blob.
        """
        if isinstance(blob, str):
            blob = blob.encode("utf-8")

        if acl is None:
            return __client__.put(f"blob://{name}", _stdin=blob)
        return __client__.put(f"blob://{name}", _stdin=blob, **acl.to_cli_command())

    def acls(self, path: str) -> ACL:
        """
        Retrieve the access control list (ACL) for a specific blob path.

        Args:
            path (str): The blob path for which to retrieve the ACL.

        Returns:
            ACL: The ACL for the blob path.
        """
        acl: dict[str, list[int]] = __client__.get_acl(path) or {}
        return ACL.from_dict(acl)

    def set_acls(self, path: str, acls: ACL) -> None:
        """
        Set the access control list (ACL) for a specific blob path.

        Args:
            path (str): The blob path for which to set the ACL.
            acls (ACL): The ACL to apply.
        """
        __client__.set_acl(path, **acls.to_cli_command())
        return None
