import platformdirs

oi_dir = platformdirs.user_config_dir("probe")
