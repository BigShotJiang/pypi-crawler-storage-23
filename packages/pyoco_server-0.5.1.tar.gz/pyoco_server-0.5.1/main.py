def main():
    print("Hello from pyoco-server!")


if __name__ == "__main__":
    main()
