# NOTE

このファイル名は、過去の参照との互換性のために残しています。

正本は `docs/architecture.md` です。
