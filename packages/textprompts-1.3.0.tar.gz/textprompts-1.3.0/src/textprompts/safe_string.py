"""Backward-compatible alias module."""  # pragma: no cover

from .prompt_string import PromptString, SafeString  # pragma: no cover

__all__ = ["PromptString", "SafeString"]  # pragma: no cover
