"""Tests for DataBridge AI Community Edition modules."""
