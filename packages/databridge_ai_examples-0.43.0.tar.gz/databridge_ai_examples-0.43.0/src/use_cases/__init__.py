"""DataBridge AI use-case tutorials.

Organized by category:
    - beginner: Cases 01-04 (pizza, friends, school, sports)
    - financial: Cases 05-11 (SEC EDGAR / Apple / Microsoft)
    - faux_objects: Cases 12-19 (domain persona tutorials)
"""
