import asyncio
import logging
from dataclasses import asdict
from dataclasses import dataclass
from enum import StrEnum
from logging import getLogger

from csu.worker.engine import AbstractConsumer
from csu.worker.engine import AbstractEngine
from csu.worker.engine import AbstractProducer
from csu.worker.engine import TaskProtocol
from csu.worker.job import Job

logger = getLogger(__name__)


@dataclass
class NoOpTask:
    """
    Simple task model that doesn't store anything.
    """

    id: int

    @property
    def job_kwargs(self):
        return asdict(self)

    async def done_watchdog(self, job: Job):
        """
        Nothing done as there's no storage for this job.
        """


@dataclass
class ExampleJob[RequestStruct](Job):
    id: int


class ExampleResultType(StrEnum):
    PENDING = "PENDING"
    SUCCESS = "SUCCESS"
    ERROR = "ERROR"
    ABSENT = "ABSENT"


class ExampleProducer(AbstractProducer):
    engine: ExampleEngine
    job_class = ExampleJob
    counter = 0

    async def fetch_task(self) -> TaskProtocol | None:
        self.counter += 1
        logger.info("%s.fetch_task() -> %s", self, self.counter)
        return NoOpTask(self.counter)


class ExampleConsumer(AbstractConsumer):
    result_type_enum = ExampleResultType
    engine: ExampleEngine

    async def perform_work(self, job: ExampleJob):
        logger.info("%s.perform_work(%s)", self, job)
        await asyncio.sleep(1)
        return {"foo": "bar"}

    async def save_result(self, job: ExampleJob, /, **kwargs):
        logger.info("%s.save_result(%s)", self, job)


WORKERS = 5


class ExampleEngine(AbstractEngine):
    queue_maxsize = WORKERS

    async def start(self):
        await super().start()
        logger.info("Starting workers...")

        for _ in range(WORKERS):
            consumer = ExampleConsumer(engine=self)
            consumer.start()
            self.workers.append(consumer)

        producer = ExampleProducer(engine=self)
        producer.start()
        self.workers.append(producer)

        while self.is_work_pending():
            await asyncio.sleep(1)
            logger.info("%s", self.inspect())
        logger.info("DONE: %s", self.inspect())


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    engine = ExampleEngine()
    print(engine)
    asyncio.run(engine.start())
