# SPDX-License-Identifier: MIT
"""Lightweight MCP server implementation backed by the tool registry."""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from fenix_mcp.application.prompt_registry import (
    PromptRegistry,
    build_default_prompt_registry,
)
from fenix_mcp.application.tool_registry import ToolRegistry, build_default_registry
from fenix_mcp.application.tools.team import MY_TEAMS_URI, TeamTool
from fenix_mcp.infrastructure.context import AppContext


class McpServerError(RuntimeError):
    pass


@dataclass
class SimpleMcpServer:
    context: AppContext
    registry: ToolRegistry
    prompt_registry: PromptRegistry
    session_id: str
    _init_instructions: Optional[str] = field(default=None, repr=False)

    def set_personal_access_token(self, token: Optional[str]) -> None:
        self.context.api_client.update_token(token)

    async def _build_auto_init_instructions(self) -> str:
        """Load Fenix context automatically on MCP protocol initialize."""
        api = self.context.api_client
        logger = self.context.logger

        # Single API call to get profile with documents
        try:
            profile = await asyncio.to_thread(api.get_profile, include_documents=True)
        except Exception as exc:
            logger.warning("Auto-init API call failed: %s", exc)
            profile = None

        if profile is None:
            profile = {}

        core_documents = profile.get("coreDocuments") or []
        user_documents = profile.get("userDocuments") or []

        # Build context summary
        user_info = (profile or {}).get("user") or {}
        tenant_info = (profile or {}).get("tenant") or {}
        team_info = (profile or {}).get("team") or {}
        teams_list: list[Any] = (profile or {}).get("teams") or []

        # Store teams in context for pre-flight checks in tools
        self.context.user_teams = teams_list

        lines = [
            "# Fenix Cloud Context (Auto-initialized)",
            "",
            "## User Context",
            f"- **User**: {user_info.get('name', 'Unknown')} (`{user_info.get('id', 'N/A')}`)",
            f"- **Tenant**: {tenant_info.get('name', 'Unknown')} (`{tenant_info.get('id', 'N/A')}`)",
        ]

        if len(teams_list) > 1:
            # Multi-team user — explicitly clear any previously set team.
            self.context.active_team_id = None
            self.context.active_team_name = None
            self.context.api_client.set_active_team(None)
            lines.append("- **Active Team**: ⚠️ Not set (multi-team user)")
            lines.append(f"- **Teams** ({len(teams_list)} available):")
            for t in teams_list:
                prefix = t.get("prefix", "")
                prefix_str = f" [{prefix}]" if prefix else ""
                lines.append(f"  - `{t['id']}` — **{t.get('name', '?')}**{prefix_str}")
        else:
            # Single team or legacy
            active_team = teams_list[0] if teams_list else team_info
            team_id = active_team.get("id")
            if team_id:
                self.context.active_team_id = team_id
                self.context.active_team_name = active_team.get("name")
                self.context.api_client.set_active_team(team_id)
            lines.append(
                f"- **Team**: {active_team.get('name', 'Unknown')} (`{team_id or 'N/A'}`)"
            )

        if core_documents:
            lines.extend(["", "## Core Documents"])
            for doc in core_documents:
                name = doc.get("name", "untitled")
                content = doc.get("content", "")
                metadata = doc.get("metadata", "")
                lines.append(f"\n### {name}")
                if content:
                    lines.append(content)
                if metadata:
                    lines.append(f"\n**Metadata:**\n{metadata}")

        if user_documents:
            lines.extend(["", "## User Documents"])
            for doc in user_documents:
                name = doc.get("name", "untitled")
                content = doc.get("content", "")
                lines.append(f"\n### {name}")
                if content:
                    lines.append(content)

        lines.extend(
            [
                "",
                "## Available Tools",
                "Use `mcp__fenix__work_items` for work items, `mcp__fenix__docs` for documentation,",
                "`mcp__fenix__sprints` for sprints, `mcp__fenix__boards` for boards,",
                "`mcp__fenix__rules` for coding standards, `mcp__fenix__api_catalog` for API catalog.",
                "Use `mcp__fenix__intelligence` for semantic memory search/save.",
                "Use `mcp__fenix__productivity` for TODOs.",
                "Team-scoped tools accept optional `team_id`; defaults are resolved automatically.",
                "Use MCP resource `fenix://my-teams` to discover available teams.",
            ]
        )

        return "\n".join(lines)

    async def handle(self, request: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        method = request.get("method")
        request_id = request.get("id")

        if method == "initialize":
            # Auto-load Fenix context
            try:
                self._init_instructions = await self._build_auto_init_instructions()
            except Exception as exc:
                self.context.logger.warning("Auto-init failed: %s", exc)
                self._init_instructions = None

            result = {
                "protocolVersion": "2024-11-05",
                "capabilities": {
                    "tools": {},
                    "prompts": {},
                    "resources": {},
                    "logging": {},
                },
                "serverInfo": {"name": "fenix_cloud_mcp_py", "version": "0.1.0"},
                "sessionId": self.session_id,
            }

            if self._init_instructions:
                result["instructions"] = self._init_instructions

            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": result,
            }

        if method == "tools/list":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {"tools": self.registry.list_definitions()},
            }

        if method == "tools/call":
            params = request.get("params") or {}
            name = params.get("name")
            arguments = params.get("arguments") or {}

            if not name:
                raise McpServerError("Missing tool name in tools/call payload")

            result = await self.registry.execute(name, arguments, self.context)

            return {"jsonrpc": "2.0", "id": request_id, "result": result}

        if method == "resources/list":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "resources": [
                        {
                            "uri": MY_TEAMS_URI,
                            "name": "My Teams",
                            "mimeType": "application/json",
                        }
                    ]
                },
            }

        if method == "resources/read":
            params = request.get("params") or {}
            uri = params.get("uri")
            if uri != MY_TEAMS_URI:
                raise McpServerError(f"Unsupported resource URI: {uri}")

            resource = TeamTool.build_my_teams_resource(self.context)
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {
                    "contents": [
                        {
                            "uri": resource["uri"],
                            "mimeType": resource["mimeType"],
                            "text": resource["text"],
                        }
                    ]
                },
            }

        if method == "prompts/list":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {"prompts": self.prompt_registry.list_definitions()},
            }

        if method == "prompts/get":
            params = request.get("params") or {}
            name = params.get("name")
            arguments = params.get("arguments") or {}

            if not name:
                raise McpServerError("Missing prompt name in prompts/get payload")

            prompt_result = self.prompt_registry.get(name, arguments)

            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": prompt_result.to_dict(),
            }

        if method == "notifications/initialized":
            # Notifications do not require a response
            return None

        if method == "notifications/cancelled":
            # Client cancelled a request - no response needed
            return None

        if method == "logging/setLevel":
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {},
            }

        raise McpServerError(f"Unsupported method: {method}")


def build_server(context: AppContext) -> SimpleMcpServer:
    registry = build_default_registry(context)
    prompt_registry = build_default_prompt_registry()
    return SimpleMcpServer(
        context=context,
        registry=registry,
        prompt_registry=prompt_registry,
        session_id=str(uuid.uuid4()),
    )
