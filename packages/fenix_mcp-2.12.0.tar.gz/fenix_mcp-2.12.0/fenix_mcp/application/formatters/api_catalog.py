# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import Any, Dict, List


def _format_api_search_result(api: Dict[str, Any]) -> str:
    """Format an API search result with similarity and matched endpoint."""
    lines: List[str] = []

    title = api.get("title", "Untitled API")
    slug = api.get("slug", "")
    similarity = api.get("similarity")

    # Title with similarity
    if similarity is not None:
        pct = float(similarity) * 100
        lines.append(f"🔗 **{title}** ({pct:.0f}% match)")
    else:
        lines.append(f"🔗 **{title}**")

    lines.append(f"Slug: {slug}")

    # Status
    status = api.get("lifecycle_status", "unknown")
    lines.append(f"Status: {status}")

    # Description (truncated)
    desc = api.get("description")
    if desc:
        truncated = desc[:150] + "..." if len(desc) > 150 else desc
        lines.append(f"Description: {truncated}")

    # Team info
    team = api.get("team")
    if isinstance(team, dict):
        lines.append(f"Team: {team.get('name', 'Unknown')}")

    # Matched endpoint (for semantic search)
    matched = api.get("matchedEndpoint")
    if matched:
        method = matched.get("method", "").upper()
        path = matched.get("path", "")
        summary = matched.get("summary", "")
        lines.append(f"Best match: **{method} {path}**")
        if summary:
            lines.append(f"  └─ {summary}")

    # Current version
    version = api.get("current_version")
    if isinstance(version, dict):
        lines.append(f"Version: {version.get('version', 'N/A')}")

    return "\n".join(lines)


def _format_api_item(api: Dict[str, Any]) -> str:
    """Format an API item for listing."""
    lines: List[str] = []

    title = api.get("title", "Untitled API")
    slug = api.get("slug", "")
    status = api.get("lifecycle_status", "unknown")

    lines.append(f"📦 **{title}**")
    lines.append(f"ID: {api.get('id', 'N/A')}")
    lines.append(f"Slug: {slug}")
    lines.append(f"Status: {status}")

    # Tags
    tags = api.get("tags", [])
    if tags:
        lines.append(f"Tags: {', '.join(tags)}")

    # Team
    team = api.get("team")
    if isinstance(team, dict):
        lines.append(f"Team: {team.get('name', 'Unknown')}")

    # Version
    version = api.get("current_version")
    if isinstance(version, dict):
        lines.append(f"Version: {version.get('version', 'N/A')}")

    return "\n".join(lines)


def _format_api_detail(api: Dict[str, Any]) -> str:
    """Format detailed API specification view."""
    lines: List[str] = []

    title = api.get("title", "Untitled API")
    slug = api.get("slug", "")

    lines.append(f"📚 **{title}**")
    lines.append("")
    lines.append(f"ID: {api.get('id', 'N/A')}")
    lines.append(f"Slug: {slug}")
    lines.append(f"Status: {api.get('lifecycle_status', 'unknown')}")

    # Description
    desc = api.get("description")
    if desc:
        lines.append("")
        lines.append("**Description:**")
        lines.append(desc)

    # Tags
    tags = api.get("tags", [])
    if tags:
        lines.append("")
        lines.append(f"Tags: {', '.join(tags)}")

    # Team
    team = api.get("team")
    if isinstance(team, dict):
        lines.append(f"Team: {team.get('name', 'Unknown')}")

    # Current version
    version = api.get("current_version")
    if isinstance(version, dict):
        lines.append("")
        lines.append("**Current Version:**")
        lines.append(f"- Version: {version.get('version', 'N/A')}")
        lines.append(f"- OpenAPI: {version.get('openapi_version', 'N/A')}")

        # Endpoints from current version
        endpoints = version.get("endpoint_embeddings", [])
        if endpoints:
            lines.append(f"- Endpoints: {len(endpoints)}")
            lines.append("")
            lines.append("**Endpoints:**")
            for ep in endpoints[:10]:  # Limit to 10
                method = ep.get("method", "").upper()
                path = ep.get("path", "")
                summary = ep.get("summary", "")
                if summary:
                    lines.append(f"- **{method}** {path} - {summary}")
                else:
                    lines.append(f"- **{method}** {path}")
            if len(endpoints) > 10:
                lines.append(f"  ... and {len(endpoints) - 10} more endpoints")

    # Environments
    environments = api.get("environments", [])
    if environments:
        lines.append("")
        lines.append("**Environments:**")
        for env in environments:
            name = env.get("name", "Unnamed")
            url = env.get("base_url", "")
            lines.append(f"- {name}: {url}")

    # Permissions
    permissions = api.get("permissions", {})
    if permissions:
        lines.append("")
        lines.append("**Your Permissions:**")
        if permissions.get("canEdit"):
            lines.append("- ✅ Edit")
        if permissions.get("canDelete"):
            lines.append("- ✅ Delete")
        if permissions.get("canPublish"):
            lines.append("- ✅ Publish")
        if permissions.get("canManageVersions"):
            lines.append("- ✅ Manage Versions")

    return "\n".join(lines)
