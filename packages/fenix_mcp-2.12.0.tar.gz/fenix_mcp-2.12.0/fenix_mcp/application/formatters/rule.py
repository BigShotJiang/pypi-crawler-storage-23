# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fenix_mcp.domain._service_base import _format_date


def _format_rule(
    rule: Dict[str, Any],
    *,
    header: Optional[str] = None,
    show_content: bool = False,
) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")

    name = rule.get("name", "Untitled")
    scope = rule.get("scope", "unknown")
    scope_emoji = {
        "personal": "👤",
        "team": "👥",
        "organization": "🏢",
        "marketplace": "🌍",
    }.get(scope, "📜")

    lines.extend(
        [
            f"{scope_emoji} **{name}**",
            f"ID: {rule.get('id', 'N/A')}",
            f"Scope: {scope}",
            f"Version: {rule.get('version', '1.0')}",
        ]
    )

    if rule.get("description"):
        lines.append(f"Description: {rule.get('description')}")

    # Author info
    author = rule.get("author")
    if isinstance(author, dict):
        lines.append(f"Author: {author.get('name', 'Unknown')}")

    # Forked from info
    forked_from = rule.get("forked_from")
    if isinstance(forked_from, dict):
        forked_author = forked_from.get("author", {})
        author_name = (
            forked_author.get("name", "Unknown")
            if isinstance(forked_author, dict)
            else "Unknown"
        )
        lines.append(
            f"Forked from: {forked_from.get('name', 'Unknown')} by {author_name}"
        )

    if rule.get("is_active") is False:
        lines.append("Status: Inactive")

    if rule.get("updated_at") or rule.get("updatedAt"):
        lines.append(
            f"Updated: {_format_date(rule.get('updated_at') or rule.get('updatedAt'))}"
        )

    # Show content only when explicitly requested
    if show_content and rule.get("content"):
        lines.append("")
        lines.append("**Content:**")
        lines.append(str(rule.get("content") or ""))

    return "\n".join(lines)


def _format_marketplace_rule(rule: Dict[str, Any]) -> str:
    """Format a marketplace rule with download/rating info."""
    lines: List[str] = []

    name = rule.get("name", "Untitled")
    downloads = rule.get("downloads", 0)
    rating = rule.get("rating")

    lines.append(f"🌍 **{name}**")
    lines.append(f"ID: {rule.get('id', 'N/A')}")

    if rule.get("description"):
        lines.append(f"Description: {rule.get('description')}")

    # Author info
    author = rule.get("author")
    if isinstance(author, dict):
        lines.append(f"Author: {author.get('name', 'Unknown')}")

    # Stats
    stats_parts = [f"⬇️ {downloads}"]
    if rating is not None:
        stats_parts.append(f"⭐ {float(rating):.1f}")
    lines.append(" | ".join(stats_parts))

    return "\n".join(lines)
