# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fenix_mcp.domain._service_base import _format_date


def _format_work(
    item: Dict[str, Any],
    *,
    header: Optional[str] = None,
    show_description: bool = False,
) -> str:
    lines: List[str] = []
    if header:
        lines.append(header)
        lines.append("")

    key = item.get("key", "")
    title = item.get("title") or item.get("name") or "Untitled"
    item_type = item.get("item_type") or item.get("type") or "unknown"

    status_obj = item.get("status")
    if isinstance(status_obj, dict):
        status = status_obj.get("name", "unknown")
    else:
        status = item.get("status_id") or status_obj or "unknown"

    priority = item.get("priority") or item.get("priority_level") or "undefined"
    item_id = item.get("id", "N/A")

    assignee = item.get("assignee_id")
    if not assignee and item.get("assignee"):
        assignee_obj = item.get("assignee", {})
        assignee = assignee_obj.get("name") or assignee_obj.get("id")
    if not assignee:
        assignee = "N/A"

    if key:
        lines.append(f"🎯 **[{key}] {title}**")
    else:
        lines.append(f"🎯 **{title}**")

    lines.extend(
        [
            f"ID: {item_id}",
            f"Type: {item_type}",
            f"Status: {status}",
            f"Priority: {priority}",
            f"Assignee: {assignee}",
        ]
    )

    if key:
        lines.append(f"Key: {key}")

    if item.get("due_date") or item.get("dueDate"):
        lines.append(
            f"Due date: {_format_date(item.get('due_date') or item.get('dueDate'))}"
        )
    if item.get("tags"):
        tags = item.get("tags", [])
        if tags:
            lines.append(f"Tags: {', '.join(tags)}")

    if show_description and item.get("description"):
        lines.append("")
        lines.append("**Description:**")
        lines.append(str(item.get("description") or ""))

    return "\n".join(lines)
