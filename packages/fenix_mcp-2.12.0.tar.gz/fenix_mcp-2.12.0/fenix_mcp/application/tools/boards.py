# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import Literal, Optional, cast

from pydantic import ConfigDict, Field

from fenix_mcp.application.formatters import _format_board
from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import (
    Tool,
    ToolRequest,
    UUIDStr,
    resolve_team_id,
)
from fenix_mcp.domain.boards import BoardService
from fenix_mcp.infrastructure.context import AppContext

BoardsAction = Literal[
    "board_list",
    "board_favorites",
    "board_get",
    "board_columns",
]


def _board_action_choices() -> list[str]:
    return [
        "board_list",
        "board_favorites",
        "board_get",
        "board_columns",
    ]


class BoardsRequest(ToolRequest):
    model_config = ConfigDict(extra="forbid")

    action: BoardsAction
    team_id: Optional[UUIDStr] = Field(
        default=None, description="Associated team ID (UUID)."
    )

    board_id: Optional[UUIDStr] = Field(
        default=None, description="Associated board ID (UUID)."
    )
    limit: int = Field(default=20, ge=1, le=100, description="Result limit.")
    offset: int = Field(
        default=0, ge=0, description="Pagination offset (when supported)."
    )


class BoardsTool(Tool):
    name = "boards"
    description = """Access Fenix work boards and columns for board-level discovery workflows.

Available actions:
- `board_list`, `board_favorites`, `board_get`, `board_columns`

Common example:
- List available boards:
  `{"action":"board_list"}`

Team scoping:
- Optional `team_id` can be sent in any request.
- If omitted, the tool uses the active/default team resolution from context.
"""
    request_model = BoardsRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = BoardService(context.api_client, context.logger)

    async def run(self, payload: ToolRequest, context: AppContext):
        payload = cast(BoardsRequest, payload)
        team_id = resolve_team_id(requested_team_id=payload.team_id, context=context)
        action = payload.action

        if action == "board_list":
            boards = await self._service.board_list(
                team_id=team_id,
                limit=payload.limit,
                offset=payload.offset,
            )
            if not boards:
                return text("🗂️ No boards found.")
            body = "\n\n".join(_format_board(board) for board in boards)
            return text(f"🗂️ **Boards ({len(boards)}):**\n\n{body}")

        if action == "board_favorites":
            boards = await self._service.board_favorites(team_id=team_id)
            if not boards:
                return text("⭐ No favorite boards registered.")
            body = "\n\n".join(_format_board(board) for board in boards)
            return text(f"⭐ **Favorite boards ({len(boards)}):**\n\n{body}")

        if action == "board_get":
            if not payload.board_id:
                return text("❌ Provide board_id to get details.")
            board = await self._service.board_get(payload.board_id, team_id=team_id)
            return text(_format_board(board, header="🗂️ Board details"))

        if action == "board_columns":
            if not payload.board_id:
                return text("❌ Provide board_id to list columns.")
            columns = await self._service.board_columns(
                payload.board_id, team_id=team_id
            )
            if not columns:
                return text("📊 Board has no columns registered.")
            body = "\n".join(
                f"- {col.get('name', 'Unnamed')} (ID: {col.get('id')})"
                for col in columns
            )
            return text(f"📊 **Board columns:**\n{body}")

        return text(
            "❌ Unsupported board action.\n\nChoose one of the values:\n"
            + "\n".join(f"- `{value}`" for value in _board_action_choices())
        )


__all__ = ["BoardsTool", "BoardsAction", "BoardsRequest"]
