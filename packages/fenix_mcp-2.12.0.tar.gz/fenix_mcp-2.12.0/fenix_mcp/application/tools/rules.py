# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import Literal, Optional, cast

from pydantic import ConfigDict, Field

from fenix_mcp.application.formatters import _format_marketplace_rule, _format_rule
from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import (
    DescriptionStr,
    MERMAID_HINT,
    MarkdownStr,
    TitleStr,
    Tool,
    ToolRequest,
    UUIDStr,
    resolve_team_id,
    sanitize_null,
)
from fenix_mcp.domain.rules import RuleService
from fenix_mcp.infrastructure.context import AppContext

RulesAction = Literal[
    "rule_create",
    "rule_list",
    "rule_get",
    "rule_update",
    "rule_delete",
    "rule_marketplace",
    "rule_fork",
    "rule_export",
]


def _rule_action_choices() -> list[str]:
    return [
        "rule_create",
        "rule_list",
        "rule_get",
        "rule_update",
        "rule_delete",
        "rule_marketplace",
        "rule_fork",
        "rule_export",
    ]


class RulesRequest(ToolRequest):
    model_config = ConfigDict(extra="forbid")

    action: RulesAction
    team_id: Optional[UUIDStr] = Field(
        default=None, description="Associated team ID (UUID)."
    )

    id: Optional[UUIDStr] = Field(
        default=None, description="Primary resource ID (UUID)."
    )
    limit: int = Field(default=20, ge=1, le=100, description="Result limit.")
    offset: int = Field(
        default=0, ge=0, description="Pagination offset (when supported)."
    )
    query: Optional[str] = Field(default=None, description="Filter/search term.")

    rule_id: Optional[UUIDStr] = Field(default=None, description="Rule ID (UUID).")
    rule_scope: Optional[str] = Field(
        default=None,
        description="Rule scope. Values: personal, team, organization, marketplace.",
    )
    rule_name: Optional[TitleStr] = Field(default=None, description="Rule name.")
    rule_slug: Optional[str] = Field(
        default=None, description="Rule slug (auto-generated if not provided)."
    )
    rule_description: Optional[DescriptionStr] = Field(
        default=None, description="Rule description."
    )
    rule_content: Optional[MarkdownStr] = Field(
        default=None, description=f"Rule content (Markdown).{MERMAID_HINT}"
    )
    rule_team_id: Optional[UUIDStr] = Field(
        default=None, description="Team ID for team-scoped rules (UUID)."
    )
    rule_export_format: Optional[str] = Field(
        default=None,
        description="Export format. Values: cursor, claude, copilot, windsurf.",
    )
    rule_is_active: Optional[bool] = Field(
        default=None, description="Whether the rule is active."
    )
    rule_category: Optional[str] = Field(
        default=None,
        description="Rule category. REQUIRED for rule_create. Values: frontend, backend, mobile, fullstack, devops, infrastructure, architecture, code_review, testing, security, documentation, performance, other.",
    )


class RulesTool(Tool):
    name = "rules"
    description = """Manage Fenix coding rules including team rules, marketplace browsing, fork, and export.

Available actions:
- `rule_create`, `rule_list`, `rule_get`, `rule_update`, `rule_delete`
- `rule_marketplace`, `rule_fork`, `rule_export`

Common example:
- List team rules:
  `{"action":"rule_list"}`

Team scoping:
- Optional `team_id` can be sent in any request.
- If omitted, the tool uses the active/default team resolution from context.
"""
    request_model = RulesRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = RuleService(context.api_client, context.logger)

    async def run(self, payload: ToolRequest, context: AppContext):
        payload = cast(RulesRequest, payload)
        team_id = resolve_team_id(requested_team_id=payload.team_id, context=context)
        action = payload.action

        if action == "rule_create":
            if not payload.rule_name:
                return text("❌ Provide rule_name to create the rule.")
            if not payload.rule_content:
                return text("❌ Provide rule_content to create the rule.")
            if not payload.rule_scope:
                return text(
                    "❌ Provide rule_scope to create the rule. "
                    "Values: personal, team, organization, marketplace."
                )
            if payload.rule_scope == "team" and not payload.rule_team_id:
                return text("❌ Provide rule_team_id for team-scoped rules.")
            if not payload.rule_category:
                return text(
                    "❌ Provide rule_category to create the rule. "
                    "Values: frontend, backend, mobile, fullstack, devops, infrastructure, "
                    "architecture, code_review, testing, security, documentation, performance, other."
                )

            rule = await self._service.rule_create(
                {
                    "scope": payload.rule_scope,
                    "name": payload.rule_name,
                    "slug": sanitize_null(payload.rule_slug),
                    "description": sanitize_null(payload.rule_description),
                    "content": payload.rule_content,
                    "team_id": sanitize_null(payload.rule_team_id),
                    "category": payload.rule_category,
                },
                team_id=team_id,
            )
            return text(_format_rule(rule, header="✅ Rule created"))

        if action == "rule_list":
            rules = await self._service.rule_list(
                team_id=team_id,
                limit=payload.limit,
                offset=payload.offset,
                scope=sanitize_null(payload.rule_scope),
                query=sanitize_null(payload.query),
            )
            if not rules:
                return text("📜 No rules found.")
            body = "\n\n".join(_format_rule(rule) for rule in rules)
            return text(f"📜 **Rules ({len(rules)}):**\n\n{body}")

        if action == "rule_get":
            rule_id = payload.rule_id or payload.id
            if not rule_id:
                return text("❌ Provide rule_id or id to get the rule.")
            rule = await self._service.rule_get(rule_id, team_id=team_id)
            return text(_format_rule(rule, header="📜 Rule details", show_content=True))

        if action == "rule_update":
            rule_id = payload.rule_id or payload.id
            if not rule_id:
                return text("❌ Provide rule_id or id to update the rule.")
            rule = await self._service.rule_update(
                rule_id,
                {
                    "name": sanitize_null(payload.rule_name),
                    "description": sanitize_null(payload.rule_description),
                    "content": sanitize_null(payload.rule_content),
                    "is_active": payload.rule_is_active,
                    "category": sanitize_null(payload.rule_category),
                },
                team_id=team_id,
            )
            return text(_format_rule(rule, header="✅ Rule updated"))

        if action == "rule_delete":
            rule_id = payload.rule_id or payload.id
            if not rule_id:
                return text("❌ Provide rule_id or id to delete the rule.")
            await self._service.rule_delete(rule_id, team_id=team_id)
            return text(f"🗑️ Rule {rule_id} removed.")

        if action == "rule_marketplace":
            rules = await self._service.rule_marketplace(
                team_id=team_id,
                limit=payload.limit,
                offset=payload.offset,
                query=sanitize_null(payload.query),
            )
            if not rules:
                return text("🏪 No marketplace rules found.")
            body = "\n\n".join(_format_marketplace_rule(rule) for rule in rules)
            return text(f"🏪 **Marketplace Rules ({len(rules)}):**\n\n{body}")

        if action == "rule_fork":
            rule_id = payload.rule_id or payload.id
            if not rule_id:
                return text("❌ Provide rule_id or id to fork the rule.")
            if not payload.rule_scope:
                return text(
                    "❌ Provide rule_scope for the forked rule. "
                    "Values: personal, team, organization."
                )
            rule = await self._service.rule_fork(
                rule_id,
                {
                    "scope": payload.rule_scope,
                    "name": sanitize_null(payload.rule_name),
                    "team_id": sanitize_null(payload.rule_team_id),
                    "category": sanitize_null(payload.rule_category),
                },
                team_id=team_id,
            )
            return text(_format_rule(rule, header="✅ Rule forked"))

        if action == "rule_export":
            rule_id = payload.rule_id or payload.id
            if not rule_id:
                return text("❌ Provide rule_id or id to export the rule.")
            if not payload.rule_export_format:
                return text(
                    "❌ Provide rule_export_format. "
                    "Values: cursor, claude, copilot, windsurf."
                )
            content = await self._service.rule_export(
                rule_id, payload.rule_export_format, team_id=team_id
            )
            return text(
                f"📤 **Export ({payload.rule_export_format}):**\n\n```\n{content}\n```"
            )

        return text(
            "❌ Unsupported rule action.\n\nChoose one of the values:\n"
            + "\n".join(f"- `{value}`" for value in _rule_action_choices())
        )


__all__ = ["RulesTool", "RulesAction", "RulesRequest"]
