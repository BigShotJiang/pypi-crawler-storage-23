# SPDX-License-Identifier: MIT

from __future__ import annotations

import json
from typing import Any, Dict, Literal, cast

from pydantic import ConfigDict

from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import Tool, ToolRequest
from fenix_mcp.infrastructure.context import AppContext

MY_TEAMS_URI = "fenix://my-teams"

TeamAction = Literal["team_help"]


class TeamRequest(ToolRequest):
    model_config = ConfigDict(extra="forbid")
    action: TeamAction = "team_help"


def build_my_teams_resource(context: AppContext) -> Dict[str, Any]:
    return {
        "uri": MY_TEAMS_URI,
        "mimeType": "application/json",
        "text": json.dumps({"teams": context.user_teams}, ensure_ascii=False, indent=2),
    }


class TeamTool(Tool):
    name = "team"
    description = "Team context resource helper"
    request_model = TeamRequest

    def __init__(self, context: AppContext):
        self._context = context

    @staticmethod
    def build_my_teams_resource(context: AppContext) -> Dict[str, Any]:
        return build_my_teams_resource(context)

    async def run(self, payload: ToolRequest, context: AppContext):
        payload = cast(TeamRequest, payload)
        if payload.action == "team_help":
            return text(
                "Use MCP resource `fenix://my-teams` to read teams available "
                "to the authenticated user."
            )
        return text("❌ Unsupported team action.")


__all__ = [
    "MY_TEAMS_URI",
    "TeamTool",
    "TeamAction",
    "TeamRequest",
    "build_my_teams_resource",
]
