# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import Literal, Optional, cast

from pydantic import ConfigDict, Field

from fenix_mcp.application.formatters import (
    _format_api_detail,
    _format_api_item,
    _format_api_search_result,
)
from fenix_mcp.application.presenters import text
from fenix_mcp.application.tool_base import (
    Tool,
    ToolRequest,
    UUIDStr,
    resolve_team_id,
    sanitize_null,
)
from fenix_mcp.domain.api_catalog import ApiCatalogService
from fenix_mcp.infrastructure.context import AppContext

ApiCatalogAction = Literal[
    "api_catalog_search",
    "api_catalog_list",
    "api_catalog_get",
]


def _api_catalog_action_choices() -> list[str]:
    return [
        "api_catalog_search",
        "api_catalog_list",
        "api_catalog_get",
    ]


class ApiCatalogRequest(ToolRequest):
    model_config = ConfigDict(extra="forbid")

    action: ApiCatalogAction
    team_id: Optional[UUIDStr] = Field(
        default=None, description="Associated team ID (UUID)."
    )

    id: Optional[UUIDStr] = Field(
        default=None, description="Primary resource ID (UUID)."
    )
    limit: int = Field(default=20, ge=1, le=100, description="Result limit.")
    offset: int = Field(
        default=0, ge=0, description="Pagination offset (when supported)."
    )
    query: Optional[str] = Field(default=None, description="Filter/search term.")

    api_spec_id: Optional[UUIDStr] = Field(
        default=None,
        description="API specification ID (UUID). Can also use 'id' field instead.",
    )


class ApiCatalogTool(Tool):
    name = "api_catalog"
    description = """Discover Fenix API specifications and inspect endpoint-rich API details.

Available actions:
- `api_catalog_search`, `api_catalog_list`, `api_catalog_get`

Common example:
- Semantic API lookup by natural language:
  `{"action":"api_catalog_search","query":"user authentication"}`

Team scoping:
- Optional `team_id` can be sent in any request.
- If omitted, the tool uses the active/default team resolution from context.
"""
    request_model = ApiCatalogRequest

    def __init__(self, context: AppContext):
        self._context = context
        self._service = ApiCatalogService(context.api_client, context.logger)

    async def run(self, payload: ToolRequest, context: AppContext):
        payload = cast(ApiCatalogRequest, payload)
        team_id = resolve_team_id(requested_team_id=payload.team_id, context=context)
        action = payload.action

        if action == "api_catalog_search":
            query = sanitize_null(payload.query)
            if not query:
                return text("❌ Provide query to search APIs.")

            result = await self._service.api_catalog_search(
                query=query,
                limit=payload.limit,
                team_id=team_id,
            )

            data = result.get("data", [])
            if not data:
                return text(
                    f"🔍 No APIs found for: **{query}**\n\n"
                    "Try a different search term or use `api_catalog_list` to see all APIs."
                )

            body = "\n\n".join(_format_api_search_result(api) for api in data)
            total = len(data)

            return text(f"🔍 **APIs found for '{query}'** ({total} results)\n\n{body}")

        if action == "api_catalog_list":
            apis = await self._service.api_catalog_list(
                team_id=team_id,
                limit=payload.limit,
                offset=payload.offset,
            )

            if not apis:
                return text("📚 No APIs found in the catalog.")

            body = "\n\n".join(_format_api_item(api) for api in apis)
            return text(f"📚 **API Catalog ({len(apis)} APIs)**\n\n{body}")

        if action == "api_catalog_get":
            spec_id = payload.api_spec_id or payload.id
            if not spec_id:
                return text("❌ Provide api_spec_id or id to get the API details.")

            api = await self._service.api_catalog_get(spec_id, team_id=team_id)
            return text(_format_api_detail(api))

        return text(
            "❌ Unsupported API Catalog action.\n\nChoose one of the values:\n"
            + "\n".join(f"- `{value}`" for value in _api_catalog_action_choices())
        )


__all__ = ["ApiCatalogTool", "ApiCatalogAction", "ApiCatalogRequest"]
