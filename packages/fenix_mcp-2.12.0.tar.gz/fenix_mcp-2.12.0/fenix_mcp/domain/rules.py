# SPDX-License-Identifier: MIT

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from fenix_mcp.domain._service_base import ServiceBase, _strip_none


@dataclass(slots=True)
class RuleService(ServiceBase):
    api: Any
    logger: Any

    async def rule_create(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.create_rule, _strip_none(payload), team_id=team_id
        )

    async def rule_list(
        self, *, team_id: Optional[str] = None, **filters: Any
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.list_rules, team_id=team_id, **_strip_none(filters)
        )

    async def rule_get(
        self, rule_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(self.api.get_rule, rule_id, team_id=team_id)

    async def rule_update(
        self,
        rule_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.update_rule, rule_id, _strip_none(payload), team_id=team_id
        )

    async def rule_delete(self, rule_id: str, *, team_id: Optional[str] = None) -> None:
        await self._call(self.api.delete_rule, rule_id, team_id=team_id)

    async def rule_marketplace(
        self, *, team_id: Optional[str] = None, **filters: Any
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.list_marketplace_rules, team_id=team_id, **_strip_none(filters)
        )

    async def rule_fork(
        self,
        rule_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.fork_rule, rule_id, _strip_none(payload), team_id=team_id
        )

    async def rule_export(
        self, rule_id: str, format: str, *, team_id: Optional[str] = None
    ) -> str:
        result = await self._call(
            self.api.export_rule, rule_id, format, team_id=team_id
        )
        return result if isinstance(result, str) else str(result or "")


__all__ = ["RuleService"]
