# SPDX-License-Identifier: MIT

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from fenix_mcp.domain._service_base import (
    ServiceBase,
    _ensure_dict,
    _ensure_list,
    _strip_none,
)


@dataclass(slots=True)
class DocService(ServiceBase):
    api: Any
    logger: Any

    async def doc_create(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.create_documentation_item, _strip_none(payload), team_id=team_id
        )

    async def doc_list(
        self, *, team_id: Optional[str] = None, **filters: Any
    ) -> List[Dict[str, Any]]:
        result = await self._call(
            self.api.list_documentation_items, team_id=team_id, **_strip_none(filters)
        )
        return _ensure_list(result)

    async def doc_get(
        self, doc_id: str, *, team_id: Optional[str] = None, **filters: Any
    ) -> Dict[str, Any]:
        result = await self._call(
            self.api.get_documentation_item,
            doc_id,
            team_id=team_id,
            **_strip_none(filters),
        )
        return _ensure_dict(result)

    async def doc_update(
        self,
        doc_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.update_documentation_item,
            doc_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def doc_delete(self, doc_id: str, *, team_id: Optional[str] = None) -> None:
        await self._call(self.api.delete_documentation_item, doc_id, team_id=team_id)

    async def doc_roots(self, *, team_id: Optional[str] = None) -> List[Dict[str, Any]]:
        result = await self._call(self.api.list_documentation_roots, team_id=team_id)
        return _ensure_list(result)

    async def doc_recent(
        self, *, limit: int, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        result = await self._call(
            self.api.list_documentation_recent,
            limit=limit,
            team_id=team_id,
        )
        return _ensure_list(result)

    async def doc_analytics(self, *, team_id: Optional[str] = None) -> Dict[str, Any]:
        result = await self._call(self.api.get_documentation_analytics, team_id=team_id)
        return _ensure_dict(result)

    async def doc_children(
        self, doc_id: str, *, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        return await self._call_list(
            self.api.get_documentation_children, doc_id, team_id=team_id
        )

    async def doc_tree(
        self, doc_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return (
            await self._call(self.api.get_documentation_tree, doc_id, team_id=team_id)
            or {}
        )

    async def doc_full_tree(self, *, team_id: Optional[str] = None) -> Dict[str, Any]:
        return (
            await self._call(self.api.get_documentation_full_tree, team_id=team_id)
            or {}
        )

    async def doc_move(
        self,
        doc_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.move_documentation_item,
            doc_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def doc_publish(
        self, doc_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.publish_documentation_item, doc_id, team_id=team_id
        )

    async def doc_version(
        self,
        doc_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.create_documentation_version,
            doc_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def doc_duplicate(
        self,
        doc_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call_dict(
            self.api.duplicate_documentation_item,
            doc_id,
            _strip_none(payload),
            team_id=team_id,
        )


__all__ = ["DocService"]
