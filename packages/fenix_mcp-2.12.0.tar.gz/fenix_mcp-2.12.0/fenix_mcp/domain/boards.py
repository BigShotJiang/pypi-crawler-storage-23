# SPDX-License-Identifier: MIT

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from fenix_mcp.domain._service_base import (
    ServiceBase,
    _ensure_dict,
    _ensure_list,
    _strip_none,
)


@dataclass(slots=True)
class BoardService(ServiceBase):
    api: Any
    logger: Any

    async def board_create(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.create_work_board, _strip_none(payload), team_id=team_id
        )

    async def board_list(
        self, *, team_id: Optional[str] = None, **filters: Any
    ) -> List[Dict[str, Any]]:
        result = await self._call(
            self.api.list_work_boards, team_id=team_id, **_strip_none(filters)
        )
        return _ensure_list(result)

    async def board_favorites(
        self, *, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        result = await self._call(self.api.list_favorite_work_boards, team_id=team_id)
        return _ensure_list(result)

    async def board_search(
        self, *, query: str, limit: int, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        result = await self._call(
            self.api.search_work_boards,
            query=query,
            limit=limit,
            team_id=team_id,
        )
        return _ensure_list(result)

    async def board_recent(
        self, *, limit: int, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        result = await self._call(
            self.api.list_recent_work_boards, limit=limit, team_id=team_id
        )
        return _ensure_list(result)

    async def board_get(
        self, board_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        result = await self._call(self.api.get_work_board, board_id, team_id=team_id)
        return _ensure_dict(result)

    async def board_update(
        self,
        board_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.update_work_board,
            board_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def board_delete(
        self, board_id: str, *, team_id: Optional[str] = None
    ) -> None:
        await self._call(self.api.delete_work_board, board_id, team_id=team_id)

    async def board_analytics(
        self, board_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return (
            await self._call(
                self.api.get_work_board_analytics, board_id, team_id=team_id
            )
            or {}
        )

    async def board_columns(
        self, board_id: str, *, team_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        result = await self._call(
            self.api.list_work_board_columns, board_id, team_id=team_id
        )
        return _ensure_list(result)

    async def board_toggle_favorite(
        self,
        board_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.toggle_work_board_favorite,
            board_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def board_clone(
        self,
        board_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.clone_work_board,
            board_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def board_reorder(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.reorder_work_boards, _strip_none(payload), team_id=team_id
        )

    async def board_column_create(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.create_work_board_column, _strip_none(payload), team_id=team_id
        )

    async def board_column_reorder(
        self, payload: Dict[str, Any], *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.reorder_work_board_columns,
            _strip_none(payload),
            team_id=team_id,
        )

    async def board_column_get(
        self, column_id: str, *, team_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.get_work_board_column, column_id, team_id=team_id
        )

    async def board_column_update(
        self,
        column_id: str,
        payload: Dict[str, Any],
        *,
        team_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        return await self._call(
            self.api.update_work_board_column,
            column_id,
            _strip_none(payload),
            team_id=team_id,
        )

    async def board_column_delete(
        self, column_id: str, *, team_id: Optional[str] = None
    ) -> None:
        await self._call(self.api.delete_work_board_column, column_id, team_id=team_id)


__all__ = ["BoardService"]
