## Summary

<!-- Briefly describe what this PR does -->

## Type of Change

<!-- Check all that apply -->

- [ ] 🐛 Bug fix (fixes an issue with existing functionality)
- [ ] ✨ New feature (adds new functionality)
- [ ] 📝 Documentation (documentation only changes)
- [ ] 🎨 Style (formatting, whitespace, no functional changes)
- [ ] ♻️ Refactoring (code restructuring without changing behavior)
- [ ] ⚡ Performance improvement
- [ ] 🔒 Type safety (type annotations, type checking fixes)
- [ ] 🧪 Tests (adding or updating tests)
- [ ] 🔧 Configuration (pyproject.toml, CI/CD, etc.)
- [ ] 📊 New Protocol (new evaluation protocol)

## Related Issue

<!-- Link to related issues -->

Closes #<!-- Issue number -->

## Changes Made

<!-- Describe your changes in detail -->

### Modified Files

- `file/path.py`: Description of changes

### Impact on Existing Code

<!-- How does this change affect existing functionality? -->

- [ ] New protocol added
- [ ] API changes (breaking changes)
- [ ] Evaluation logic changes
- [ ] Performance improvements
- [ ] Bug fixes
- [ ] Documentation only
- [ ] No impact on existing functionality

### Breaking Changes

<!-- Check if this introduces breaking changes -->

- [ ] Yes (describe below)
- [ ] No

<!-- Details of breaking changes and migration guide -->
```

```

## Testing

<!-- Describe how you tested your changes -->

### Test Commands

```bash
# Run all tests
uv run pytest tests/ -v

# Run specific test file
uv run pytest tests/test_integration.py -v

# Check code quality
uv run ruff check
uv run ruff format .
uv run ty check

# Run pre-commit hooks
uv run pre-commit run --all-files
```

### Test Results

```bash
# Paste test output here
```

### Test Environment

- OS: <!-- e.g. Ubuntu 22.04, macOS 14.0 -->
- Python version: <!-- e.g. 3.12.0 -->
- PyTorch version: <!-- e.g. 2.9.0 -->
- PyTorch Geometric version: <!-- e.g. 2.6.0 -->
- CUDA version (if applicable): <!-- e.g. 12.6 -->
- GPU (if applicable): <!-- e.g. RTX 4090 -->

## Screenshots (if applicable)

<!-- Add screenshots for visual changes or output examples -->

## Checklist

<!-- Please check all items before requesting review -->

### Code Quality

- [ ] Code follows the project's style guidelines
- [ ] Code is well-commented and self-documenting
- [ ] All tests pass (`uv run pytest tests/`)
- [ ] Code linting passes (`uv run ruff check`)
- [ ] Code formatting is correct (`uv run ruff format .`)
- [ ] Type checking passes (`uv run ty check`)
- [ ] Pre-commit hooks pass (`uv run pre-commit run --all-files`)

### Testing

- [ ] Added tests for new functionality
- [ ] Updated existing tests (if needed)
- [ ] All edge cases are covered
- [ ] Tests are reproducible with fixed seeds
- [ ] Integration tests pass (if applicable)

### Documentation

- [ ] Updated README.md (if needed)
- [ ] Added/updated docstrings for new/modified functions
- [ ] Added usage examples (if new feature)
- [ ] Updated type annotations
- [ ] Added comments for complex logic

### Protocols (if applicable)

- [ ] Protocol implements BenchmarkProtocol interface
- [ ] Data splitting works correctly
- [ ] Evaluation metrics are accurate
- [ ] Reproducible with seeds
- [ ] Example usage is provided

### Evaluators (if applicable)

- [ ] Evaluator works with all protocols
- [ ] Statistical aggregation is correct (if multi-run)
- [ ] Confidence intervals are calculated properly
- [ ] Seed management works correctly
- [ ] Example usage is provided

### Performance (if applicable)

- [ ] Tested with large datasets
- [ ] Memory usage is reasonable
- [ ] No significant performance regression
- [ ] Benchmarked against baseline (if optimization)

### Backward Compatibility

- [ ] Changes are backward compatible
- [ ] If breaking changes exist, migration guide is provided
- [ ] Deprecation warnings added (if removing features)

## Reviewer Notes

<!-- Any specific areas you'd like reviewers to focus on, or questions you have -->

---

**Thank you for your contribution!** 🙏

<!--
Review Guidelines:
- Check code quality and style
- Verify tests pass and cover edge cases
- Review documentation completeness
- Test the changes locally if possible
- Provide constructive feedback
-->
