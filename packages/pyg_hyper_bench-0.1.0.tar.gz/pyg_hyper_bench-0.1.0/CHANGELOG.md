# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [v0.1.0] - 2026-02-21

### Added
- Initial release of pyg-hyper-bench
- Benchmark protocols:
  - **NodeClassificationProtocol**: Node classification with random/stratified splits
  - **LinkPredictionProtocol**: Hyperedge prediction with positive/negative sampling
  - **ClusteringProtocol**: Unsupervised clustering evaluation (NMI, ARI, AMI)
  - **SSLLinearEvaluationProtocol**: Self-supervised learning evaluation
    - Node classification task with frozen embeddings
    - Hyperedge prediction task with frozen embeddings
    - Selectable classifiers: Logistic Regression or MLP
- Evaluators:
  - **SingleRunEvaluator**: Single evaluation run
  - **MultiRunEvaluator**: Multiple runs with statistics (mean, std, min, max)
- Data split utilities:
  - Random split
  - Stratified split (class-balanced)
  - Inductive split (training graph isolation)
- Comprehensive metrics:
  - Classification: Accuracy, F1 (macro/micro)
  - Link prediction: AUC, AP
  - Clustering: NMI, ARI, AMI
- Pre-commit hooks (ruff lint/format)
- Type-safe implementation with full type hints
- 55 comprehensive tests
- CI/CD with automatic PyPI publishing

### Features
- Flexible protocol system for easy extension
- Statistical evaluation with confidence intervals
- Reproducible results with seed control
- Integration with pyg-hyper-data datasets
- Memory-efficient evaluation
- Rich result dictionaries with all metrics

[Unreleased]: https://github.com/your-username/pyg-hyper-bench/compare/v0.1.0...HEAD
[v0.1.0]: https://github.com/your-username/pyg-hyper-bench/releases/tag/v0.1.0
