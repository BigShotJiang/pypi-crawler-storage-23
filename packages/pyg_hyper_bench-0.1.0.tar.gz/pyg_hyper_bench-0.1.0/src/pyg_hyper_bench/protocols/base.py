"""Base protocol for hypergraph benchmarking.

This module defines the abstract base class for all evaluation protocols.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyg_hyper_data.data import HyperData

__all__ = ["BenchmarkProtocol"]


@dataclass
class BenchmarkProtocol(ABC):
    """Abstract base class for benchmark protocols.

    A benchmark protocol defines:
    1. How to split data into train/val/test
    2. What evaluation metrics to compute
    3. Which experimental setting to use (transductive/inductive)

    This ensures reproducibility and fair comparisons across studies.
    """

    seed: int = 42
    """Random seed for reproducibility"""

    @abstractmethod
    def split_data(self, data: HyperData) -> dict[str, Any]:
        """Split data according to protocol.

        Args:
            data: Input HyperData object

        Returns:
            Dictionary with split data and masks
        """
        ...

    @abstractmethod
    def evaluate(self, predictions, targets) -> dict[str, float]:  # noqa: ANN001
        """Compute evaluation metrics.

        Args:
            predictions: Model predictions
            targets: Ground truth labels

        Returns:
            Dictionary of metric names to values
        """
        ...
