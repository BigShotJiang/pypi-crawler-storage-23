"""Node classification protocol for hypergraph benchmarking."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from pyg_hyper_data.data import HyperData

from pyg_hyper_bench.protocols.base import BenchmarkProtocol

__all__ = ["NodeClassificationProtocol"]


@dataclass
class NodeClassificationProtocol(BenchmarkProtocol):
    """Standard protocol for node classification tasks.

    This protocol implements the standard benchmarking setup used in most
    hypergraph learning papers (HyperGCN, AllSet, ED-HNN, etc.):

    - **Split ratio**: 60/20/20 (train/val/test)
    - **Split type**: Transductive or Inductive
    - **Metrics**: Accuracy, F1 (macro/micro)
    - **Stratification**: Optional (maintains class balance)

    Attributes:
        train_ratio: Fraction of nodes for training (default: 0.6)
        val_ratio: Fraction for validation (default: 0.2)
        test_ratio: Fraction for testing (default: 0.2)
        split_type: 'transductive' or 'inductive' (default: 'transductive')
        stratified: Whether to stratify by class labels (default: True)
        seed: Random seed (default: 42)

    Example:
        >>> from pyg_hyper_data.datasets import CoraCocitation
        >>> from pyg_hyper_bench.protocols import NodeClassificationProtocol
        >>>
        >>> dataset = CoraCocitation()
        >>> data = dataset[0]
        >>>
        >>> # Create protocol
        >>> protocol = NodeClassificationProtocol(
        ...     split_type='transductive',
        ...     stratified=True,
        ...     seed=42
        ... )
        >>>
        >>> # Split data
        >>> split = protocol.split_data(data)
        >>> train_mask = split['train_mask']
        >>> val_mask = split['val_mask']
        >>> test_mask = split['test_mask']
        >>>
        >>> # ... train model ...
        >>>
        >>> # Evaluate
        >>> metrics = protocol.evaluate(predictions[test_mask], data.y[test_mask])
        >>> print(f"Test Accuracy: {metrics['accuracy']:.4f}")
        >>> print(f"Test F1 (macro): {metrics['f1_macro']:.4f}")

    References:
        - HyperGCN: Feng et al., 2019 (50/25/25 split)
        - AllSet: Chien et al., 2022 (50/25/25 split)
        - HGNN: Feng et al., 2019 (standard splits from TriCL)
    """

    train_ratio: float = 0.6
    val_ratio: float = 0.2
    test_ratio: float = 0.2
    split_type: Literal["transductive", "inductive"] = "transductive"
    stratified: bool = True
    seed: int = 42

    def split_data(self, data: HyperData) -> dict[str, Any]:
        """Split data for node classification.

        Args:
            data: HyperData object with node features and labels

        Returns:
            Dictionary containing:
            - For transductive: train_mask, val_mask, test_mask
            - For inductive: train_data, val_data, test_data
        """
        if self.split_type == "transductive":
            return self._split_transductive(data)
        return self._split_inductive(data)

    def _split_transductive(self, data: HyperData) -> dict[str, Any]:
        """Transductive split: all nodes visible, only labels masked."""
        import torch
        from pyg_hyper_data.transforms import (
            random_hypergraph_split,
            stratified_hypergraph_split,
        )

        if self.stratified and data.y is not None and isinstance(data.y, torch.Tensor):
            train_mask, val_mask, test_mask = stratified_hypergraph_split(
                data.y,
                train_ratio=self.train_ratio,
                val_ratio=self.val_ratio,
                test_ratio=self.test_ratio,
                seed=self.seed,
            )
        else:
            num_nodes = data.num_nodes if data.num_nodes is not None else 0
            train_mask, val_mask, test_mask = random_hypergraph_split(
                num_nodes,
                train_ratio=self.train_ratio,
                val_ratio=self.val_ratio,
                test_ratio=self.test_ratio,
                seed=self.seed,
            )

        return {
            "train_mask": train_mask,
            "val_mask": val_mask,
            "test_mask": test_mask,
            "data": data,  # Full graph structure visible
        }

    def _split_inductive(self, data: HyperData) -> dict[str, Any]:
        """Inductive split: test nodes and edges completely hidden."""
        from pyg_hyper_data.transforms import inductive_hypergraph_split

        train_data, val_data, test_data = inductive_hypergraph_split(
            data,
            train_ratio=self.train_ratio,
            val_ratio=self.val_ratio,
            test_ratio=self.test_ratio,
            seed=self.seed,
        )

        return {
            "train_data": train_data,
            "val_data": val_data,
            "test_data": test_data,
        }

    def evaluate(self, predictions, targets) -> dict[str, float]:  # noqa: ANN001
        """Compute node classification metrics.

        Args:
            predictions: Model predictions [num_nodes] or [num_nodes, num_classes]
                If 2D, will use argmax along dim=1
            targets: Ground truth labels [num_nodes]

        Returns:
            Dictionary with metrics:
            - accuracy: Overall accuracy
            - f1_macro: Macro-averaged F1 score
            - f1_micro: Micro-averaged F1 score
        """
        # Handle probabilistic predictions
        if predictions.dim() == 2:
            predictions = predictions.argmax(dim=1)

        # Ensure same device
        predictions = predictions.to(targets.device)

        # Compute accuracy
        accuracy = (predictions == targets).float().mean().item()

        # Compute F1 scores
        num_classes = int(targets.max().item()) + 1

        # Macro F1: Average F1 across classes
        f1_scores = []
        for c in range(num_classes):
            pred_c = predictions == c
            target_c = targets == c

            true_pos = (pred_c & target_c).sum().float()
            pred_pos = pred_c.sum().float()
            target_pos = target_c.sum().float()

            if pred_pos == 0 or target_pos == 0:
                f1_scores.append(0.0)
                continue

            precision = true_pos / pred_pos
            recall = true_pos / target_pos

            if precision + recall == 0:
                f1_scores.append(0.0)
            else:
                f1 = 2 * (precision * recall) / (precision + recall)
                f1_scores.append(f1.item())

        f1_macro = sum(f1_scores) / len(f1_scores)

        # Micro F1: Global counts
        true_pos_total = (predictions == targets).sum().float()
        pred_pos_total = predictions.numel()
        target_pos_total = targets.numel()

        precision_micro = true_pos_total / pred_pos_total
        recall_micro = true_pos_total / target_pos_total
        f1_micro = (
            2 * (precision_micro * recall_micro) / (precision_micro + recall_micro)
        ).item()

        return {
            "accuracy": accuracy,
            "f1_macro": f1_macro,
            "f1_micro": f1_micro,
        }

    def __str__(self) -> str:
        """Return string representation."""
        return (
            f"NodeClassificationProtocol("
            f"split={self.split_type}, "
            f"ratio={self.train_ratio}/{self.val_ratio}/{self.test_ratio}, "
            f"stratified={self.stratified}, "
            f"seed={self.seed})"
        )
