"""Clustering protocol for hypergraph benchmarking."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import torch
    from pyg_hyper_data.data import HyperData

from pyg_hyper_bench.protocols.base import BenchmarkProtocol

__all__ = ["ClusteringProtocol"]


@dataclass
class ClusteringProtocol(BenchmarkProtocol):
    """Protocol for unsupervised clustering evaluation.

    This protocol evaluates clustering quality of learned node embeddings
    against ground truth labels. Unlike classification, clustering is
    unsupervised - labels are only used for evaluation, not training.

    **Evaluation Strategy**:
    - Train model to learn node embeddings (unsupervised)
    - Apply clustering algorithm (e.g., K-Means) to embeddings
    - Compare predicted clusters with ground truth labels

    Attributes:
        seed: Random seed (default: 42)
        n_clusters: Number of clusters (if None, inferred from labels)

    Example:
        >>> from pyg_hyper_data.datasets import CoraCocitation
        >>> from pyg_hyper_bench.protocols import ClusteringProtocol
        >>> import torch
        >>>
        >>> dataset = CoraCocitation()
        >>> data = dataset[0]
        >>>
        >>> # Create protocol
        >>> protocol = ClusteringProtocol(seed=42)
        >>>
        >>> # No data splitting needed for unsupervised evaluation
        >>> # Train model to learn embeddings (unsupervised)
        >>> # embeddings = model.encode(data)  # [num_nodes, embedding_dim]
        >>>
        >>> # Evaluate clustering quality
        >>> metrics = protocol.evaluate(embeddings, data.y)
        >>> print(f"NMI: {metrics['nmi']:.4f}")
        >>> print(f"ARI: {metrics['ari']:.4f}")
        >>> print(f"AMI: {metrics['ami']:.4f}")

    References:
        - Normalized Mutual Information (NMI): Measures clustering quality
        - Adjusted Rand Index (ARI): Measures clustering similarity
        - Adjusted Mutual Information (AMI): Adjusted version of MI
    """

    seed: int = 42
    n_clusters: int | None = None

    def split_data(self, data: HyperData) -> dict[str, Any]:
        """No splitting needed for unsupervised clustering.

        Args:
            data: HyperData object

        Returns:
            Dictionary containing original data (no split)
        """
        return {"data": data}

    def evaluate(
        self, embeddings: torch.Tensor, labels: torch.Tensor
    ) -> dict[str, float]:
        """Compute clustering metrics.

        Args:
            embeddings: Node embeddings [num_nodes, embedding_dim]
            labels: Ground truth labels [num_nodes]

        Returns:
            Dictionary with metrics:
            - nmi: Normalized Mutual Information
            - ari: Adjusted Rand Index
            - ami: Adjusted Mutual Information

        Note:
            Uses K-Means clustering on embeddings, then compares with labels.
        """
        import torch
        from sklearn.cluster import KMeans
        from sklearn.metrics import (
            adjusted_mutual_info_score,
            adjusted_rand_score,
            normalized_mutual_info_score,
        )

        # Convert to numpy
        embeddings_np = embeddings.detach().cpu().numpy()
        labels_np = labels.detach().cpu().numpy()

        # Determine number of clusters
        n_clusters = self.n_clusters
        if n_clusters is None:
            n_clusters = len(torch.unique(labels))

        # Apply K-Means clustering
        kmeans = KMeans(n_clusters=n_clusters, random_state=self.seed, n_init=10)
        predicted_clusters = kmeans.fit_predict(embeddings_np)

        # Compute metrics
        nmi = normalized_mutual_info_score(labels_np, predicted_clusters)
        ari = adjusted_rand_score(labels_np, predicted_clusters)
        ami = adjusted_mutual_info_score(labels_np, predicted_clusters)

        return {
            "nmi": float(nmi),
            "ari": float(ari),
            "ami": float(ami),
        }

    def __str__(self) -> str:
        """Return string representation."""
        n_clusters_str = str(self.n_clusters) if self.n_clusters else "auto"
        return f"ClusteringProtocol(n_clusters={n_clusters_str}, seed={self.seed})"
