"""Evaluation protocols for hypergraph benchmarking."""

from pyg_hyper_bench.protocols.base import BenchmarkProtocol
from pyg_hyper_bench.protocols.clustering import ClusteringProtocol
from pyg_hyper_bench.protocols.link_prediction import LinkPredictionProtocol
from pyg_hyper_bench.protocols.node_classification import NodeClassificationProtocol
from pyg_hyper_bench.protocols.ssl_linear_evaluation import (
    SSLLinearEvaluationProtocol,
)

__all__ = [
    "BenchmarkProtocol",
    "ClusteringProtocol",
    "LinkPredictionProtocol",
    "NodeClassificationProtocol",
    "SSLLinearEvaluationProtocol",
]
