"""SSL Linear Evaluation protocol for hypergraph benchmarking."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    import torch
    from pyg_hyper_data.data import HyperData

from pyg_hyper_bench.protocols.base import BenchmarkProtocol

__all__ = ["SSLLinearEvaluationProtocol"]


@dataclass
class SSLLinearEvaluationProtocol(BenchmarkProtocol):
    """Linear evaluation protocol for self-supervised learning methods.

    This protocol evaluates SSL methods using the standard linear evaluation:
    1. Pre-train SSL model (labels not used during pre-training)
    2. Freeze encoder and extract node embeddings
    3. Train a linear classifier/predictor on frozen embeddings
    4. Evaluate on test set

    This measures the quality of learned representations without fine-tuning.

    Supports two evaluation tasks:
    - node_classification: Multi-class classification of nodes
    - hyperedge_prediction: Binary prediction of node-hyperedge membership

    Attributes:
        train_ratio: Fraction of nodes for training (default: 0.6)
        val_ratio: Fraction for validation (default: 0.2)
        test_ratio: Fraction for testing (default: 0.2)
        stratified: Use stratified sampling (default: True)
        seed: Random seed (default: 42)
        task: Evaluation task type (default: "node_classification")
        classifier_type: Type of linear classifier (default: "logistic_regression")
        classifier_hidden_dim: Hidden dimension for MLP classifier (default: 128)
        classifier_lr: Learning rate for classifier (default: 0.01)
        classifier_epochs: Training epochs for classifier (default: 200)
        classifier_weight_decay: Weight decay for classifier (default: 0.0)

    Example:
        >>> from pyg_hyper_ssl.methods.contrastive import TriCL
        >>> from pyg_hyper_bench.protocols import SSLLinearEvaluationProtocol
        >>> from pyg_hyper_data.datasets import CoraCocitation
        >>>
        >>> dataset = CoraCocitation()
        >>> data = dataset[0]
        >>>
        >>> # SSL Pre-training (simplified)
        >>> model = TriCL(encoder=encoder, proj_dim=256)
        >>> # ... train SSL model without using labels ...
        >>>
        >>> # Get frozen embeddings
        >>> model.eval()
        >>> embeddings = model.get_embeddings(data)
        >>>
        >>> # Linear evaluation
        >>> protocol = SSLLinearEvaluationProtocol(
        ...     classifier_type="logistic_regression",
        ...     seed=42
        ... )
        >>> split = protocol.split_data(data)
        >>> metrics = protocol.evaluate(
        ...     embeddings=embeddings,
        ...     labels=data.y,
        ...     train_mask=split["train_mask"],
        ...     val_mask=split["val_mask"],
        ...     test_mask=split["test_mask"],
        ... )
        >>> print(f"Test Accuracy: {metrics['test_accuracy']:.4f}")

    References:
        - TriCL (AAAI'23): Uses LogisticRegression for linear evaluation
        - HypeBoy (KDD'23): Uses MLP for linear evaluation
        - Standard SSL evaluation protocol across many papers
    """

    # Data split settings (same as NodeClassificationProtocol)
    train_ratio: float = 0.6
    val_ratio: float = 0.2
    test_ratio: float = 0.2
    stratified: bool = True
    seed: int = 42

    # Evaluation task settings
    task: Literal["node_classification", "hyperedge_prediction"] = "node_classification"

    # Linear classifier settings
    classifier_type: Literal["logistic_regression", "mlp"] = "logistic_regression"
    classifier_hidden_dim: int = 128  # For MLP
    classifier_lr: float = 0.01
    classifier_epochs: int = 200
    classifier_weight_decay: float = 0.0

    def split_data(self, data: HyperData) -> dict[str, Any]:
        """Split data for SSL evaluation.

        Args:
            data: HyperData object with node labels (for node_classification)
                 or hyperedge_index (for hyperedge_prediction)

        Returns:
            Dictionary containing:
            - For node_classification:
                - data: Original data
                - train_mask, val_mask, test_mask: Boolean masks for splits
            - For hyperedge_prediction:
                - train_data: Data with only train hyperedges
                - train_pos_edge, train_neg_edge: Training edge samples
                - val_pos_edge, val_neg_edge: Validation edge samples
                - test_pos_edge, test_neg_edge: Test edge samples

        Note:
            SSL pre-training does NOT use labels. Labels/edges are only used
            for evaluating the linear classifier/predictor.
        """
        if self.task == "node_classification":
            import torch
            from pyg_hyper_data.transforms import stratified_hypergraph_split

            # Get stratified masks
            assert isinstance(data.y, torch.Tensor), (
                "data.y must be a Tensor for node classification"
            )
            train_mask, val_mask, test_mask = stratified_hypergraph_split(
                labels=data.y,
                train_ratio=self.train_ratio,
                val_ratio=self.val_ratio,
                test_ratio=self.test_ratio,
                seed=self.seed,
            )

            return {
                "data": data,
                "train_mask": train_mask,
                "val_mask": val_mask,
                "test_mask": test_mask,
            }
        # hyperedge_prediction
        from pyg_hyper_data.transforms import hyperedge_prediction_split

        return hyperedge_prediction_split(
            data=data,
            train_ratio=self.train_ratio,
            val_ratio=self.val_ratio,
            test_ratio=self.test_ratio,
            negative_sampling_ratio=1.0,
            seed=self.seed,
        )

    def evaluate(  # noqa: D417
        self,
        embeddings: torch.Tensor,
        labels: torch.Tensor | None = None,
        train_mask: torch.Tensor | None = None,
        val_mask: torch.Tensor | None = None,
        test_mask: torch.Tensor | None = None,
        train_pos_edge: torch.Tensor | None = None,
        train_neg_edge: torch.Tensor | None = None,
        val_pos_edge: torch.Tensor | None = None,
        val_neg_edge: torch.Tensor | None = None,
        test_pos_edge: torch.Tensor | None = None,
        test_neg_edge: torch.Tensor | None = None,
    ) -> dict[str, float]:
        """Evaluate frozen embeddings with a linear classifier/predictor.

        Args:
            embeddings: Pre-computed frozen embeddings [num_nodes, emb_dim]
                       These should be obtained from SSL model with:
                       model.eval() + torch.no_grad()

            For node_classification task:
                labels: Node labels [num_nodes]
                train_mask: Training mask [num_nodes]
                val_mask: Validation mask [num_nodes]
                test_mask: Test mask [num_nodes]

            For hyperedge_prediction task:
                train_pos_edge, train_neg_edge: Training edge samples [2, num_edges]
                val_pos_edge, val_neg_edge: Validation edge samples [2, num_edges]
                test_pos_edge, test_neg_edge: Test edge samples [2, num_edges]

        Returns:
            Dictionary with metrics:
            - For node_classification:
                val_accuracy, val_f1_macro, val_f1_micro
                test_accuracy, test_f1_macro, test_f1_micro
            - For hyperedge_prediction:
                val_auc, val_ap
                test_auc, test_ap

        Note:
            Embeddings must be frozen (detached). This ensures we only
            evaluate the quality of representations, not the classifier.
        """
        # Ensure embeddings are detached (frozen)
        embeddings = embeddings.detach()

        if self.task == "node_classification":
            if labels is None or train_mask is None:
                msg = "labels and train_mask are required for node_classification"
                raise ValueError(msg)

            if self.classifier_type == "logistic_regression":
                return self._evaluate_node_with_logreg(
                    embeddings, labels, train_mask, val_mask, test_mask
                )
            # mlp
            return self._evaluate_node_with_mlp(
                embeddings, labels, train_mask, val_mask, test_mask
            )
        # hyperedge_prediction
        if train_pos_edge is None or val_pos_edge is None:
            msg = "edge samples are required for hyperedge_prediction"
            raise ValueError(msg)

        return self._evaluate_hyperedge_with_mlp(
            embeddings,
            train_pos_edge,
            train_neg_edge,
            val_pos_edge,
            val_neg_edge,
            test_pos_edge,
            test_neg_edge,
        )

    def _evaluate_node_with_logreg(
        self,
        embeddings: torch.Tensor,
        labels: torch.Tensor,
        train_mask: torch.Tensor,
        val_mask: torch.Tensor,
        test_mask: torch.Tensor,
    ) -> dict[str, float]:
        """Evaluate node classification with Logistic Regression (sklearn).

        This is the standard approach used in TriCL and many SSL papers.
        """
        from sklearn.linear_model import LogisticRegression
        from sklearn.metrics import accuracy_score, f1_score

        # Convert to numpy
        x_train = embeddings[train_mask].cpu().numpy()
        y_train = labels[train_mask].cpu().numpy()
        x_val = embeddings[val_mask].cpu().numpy()
        y_val = labels[val_mask].cpu().numpy()
        x_test = embeddings[test_mask].cpu().numpy()
        y_test = labels[test_mask].cpu().numpy()

        # Train LogisticRegression
        clf = LogisticRegression(
            max_iter=self.classifier_epochs,
            random_state=self.seed,
        )
        clf.fit(x_train, y_train)

        # Predict
        y_pred_val = clf.predict(x_val)
        y_pred_test = clf.predict(x_test)

        return {
            "val_accuracy": float(accuracy_score(y_val, y_pred_val)),
            "val_f1_macro": float(f1_score(y_val, y_pred_val, average="macro")),
            "val_f1_micro": float(f1_score(y_val, y_pred_val, average="micro")),
            "test_accuracy": float(accuracy_score(y_test, y_pred_test)),
            "test_f1_macro": float(f1_score(y_test, y_pred_test, average="macro")),
            "test_f1_micro": float(f1_score(y_test, y_pred_test, average="micro")),
        }

    def _evaluate_node_with_mlp(
        self,
        embeddings: torch.Tensor,
        labels: torch.Tensor,
        train_mask: torch.Tensor,
        val_mask: torch.Tensor,
        test_mask: torch.Tensor,
    ) -> dict[str, float]:
        """Evaluate node classification with MLP classifier (PyTorch).

        This approach is used in HypeBoy and provides more flexibility.
        """
        import copy

        import torch
        import torch.nn.functional
        from sklearn.metrics import f1_score
        from torch import nn

        num_classes = int(labels.max()) + 1
        emb_dim = embeddings.shape[1]
        device = embeddings.device

        # Simple MLP classifier
        classifier = nn.Sequential(
            nn.Linear(emb_dim, self.classifier_hidden_dim),
            nn.ReLU(),
            nn.Linear(self.classifier_hidden_dim, num_classes),
        ).to(device)

        optimizer = torch.optim.Adam(
            classifier.parameters(),
            lr=self.classifier_lr,
            weight_decay=self.classifier_weight_decay,
        )

        # Train classifier on frozen embeddings
        best_val_acc = 0.0
        best_state = None

        for epoch in range(self.classifier_epochs):
            classifier.train()
            optimizer.zero_grad()

            logits = classifier(embeddings[train_mask])
            loss = torch.nn.functional.cross_entropy(logits, labels[train_mask])
            loss.backward()
            optimizer.step()

            # Validation every 10 epochs
            if epoch % 10 == 0:
                classifier.eval()
                with torch.no_grad():
                    val_logits = classifier(embeddings[val_mask])
                    val_pred = val_logits.argmax(dim=1)
                    val_acc = (val_pred == labels[val_mask]).float().mean().item()

                    if val_acc > best_val_acc:
                        best_val_acc = val_acc
                        best_state = copy.deepcopy(classifier.state_dict())

        # Load best model and evaluate
        if best_state is not None:
            classifier.load_state_dict(best_state)
        classifier.eval()

        with torch.no_grad():
            val_logits = classifier(embeddings[val_mask])
            test_logits = classifier(embeddings[test_mask])

            val_pred = val_logits.argmax(dim=1)
            test_pred = test_logits.argmax(dim=1)

            # Convert to numpy for sklearn metrics
            val_pred_np = val_pred.cpu().numpy()
            val_labels_np = labels[val_mask].cpu().numpy()
            test_pred_np = test_pred.cpu().numpy()
            test_labels_np = labels[test_mask].cpu().numpy()

            return {
                "val_accuracy": float(
                    (val_pred == labels[val_mask]).float().mean().item()
                ),
                "val_f1_macro": float(
                    f1_score(val_labels_np, val_pred_np, average="macro")
                ),
                "val_f1_micro": float(
                    f1_score(val_labels_np, val_pred_np, average="micro")
                ),
                "test_accuracy": float(
                    (test_pred == labels[test_mask]).float().mean().item()
                ),
                "test_f1_macro": float(
                    f1_score(test_labels_np, test_pred_np, average="macro")
                ),
                "test_f1_micro": float(
                    f1_score(test_labels_np, test_pred_np, average="micro")
                ),
            }

    def _evaluate_hyperedge_with_mlp(
        self,
        embeddings: torch.Tensor,
        train_pos_edge: torch.Tensor,
        train_neg_edge: torch.Tensor,
        val_pos_edge: torch.Tensor,
        val_neg_edge: torch.Tensor,
        test_pos_edge: torch.Tensor,
        test_neg_edge: torch.Tensor,
    ) -> dict[str, float]:
        """Evaluate hyperedge prediction with MLP predictor (PyTorch).

        Following HypeBoy's linear_edge evaluation approach.
        Uses frozen embeddings to predict node-hyperedge membership as binary classification.

        The prediction task: Given frozen node embeddings, predict whether nodes belong to
        a hyperedge by aggregating node embeddings per hyperedge.

        Args:
            embeddings: Frozen node embeddings [num_nodes, emb_dim]
            train_pos_edge: Positive training samples [2, num_samples]
                          Format: [node_indices, hyperedge_indices]
            train_neg_edge: Negative training samples [2, num_samples]
            val_pos_edge: Positive validation samples [2, num_samples]
            val_neg_edge: Negative validation samples [2, num_samples]
            test_pos_edge: Positive test samples [2, num_samples]
            test_neg_edge: Negative test samples [2, num_samples]

        Returns:
            Dictionary with metrics: val_auc, val_ap, test_auc, test_ap

        Note:
            Following HypeBoy's MLP_HENN architecture:
            - Aggregate node embeddings by hyperedge using scatter-sum
            - Pass aggregated hyperedge representations through MLP
            - Output binary prediction per hyperedge
        """
        import copy

        import torch
        from sklearn.metrics import average_precision_score, roc_auc_score
        from torch import nn
        from torch_scatter import scatter

        emb_dim = embeddings.shape[1]
        device = embeddings.device

        # MLP predictor for hyperedge prediction (following HypeBoy's MLP_HENN)
        predictor = nn.Sequential(
            nn.Linear(emb_dim, self.classifier_hidden_dim),
            nn.ReLU(),
            nn.Dropout(p=0.5),
            nn.Linear(self.classifier_hidden_dim, 1),
        ).to(device)

        optimizer = torch.optim.Adam(
            predictor.parameters(),
            lr=self.classifier_lr,
            weight_decay=1e-6,  # Following HypeBoy
        )

        criterion = nn.BCELoss()

        # Prepare training data
        train_node_idx = torch.cat([train_pos_edge[0], train_neg_edge[0]])
        train_edge_idx = torch.cat([train_pos_edge[1], train_neg_edge[1]])
        train_labels = torch.cat(
            [
                torch.ones(train_pos_edge.size(1)),
                torch.zeros(train_neg_edge.size(1)),
            ]
        ).to(device)

        # Train predictor on frozen embeddings
        best_val_auc = 0.0
        best_state = None

        for epoch in range(self.classifier_epochs):
            predictor.train()
            optimizer.zero_grad()

            # Aggregate node embeddings per hyperedge using scatter
            hyperedge_emb = scatter(
                src=embeddings[train_node_idx],
                index=train_edge_idx,
                dim=0,
                reduce="sum",
            )

            # Predict hyperedge probability
            logits = predictor(hyperedge_emb).squeeze()
            # Get probabilities from unique hyperedge IDs
            _, inverse_indices = torch.unique(train_edge_idx, return_inverse=True)
            pred_probs = torch.sigmoid(logits[inverse_indices])

            loss = criterion(pred_probs, train_labels)
            loss.backward()
            optimizer.step()

            # Validation every 10 epochs
            if epoch % 10 == 0:
                predictor.eval()
                with torch.no_grad():
                    # Validation predictions
                    val_node_idx = torch.cat([val_pos_edge[0], val_neg_edge[0]])
                    val_edge_idx = torch.cat([val_pos_edge[1], val_neg_edge[1]])
                    val_labels_all = torch.cat(
                        [
                            torch.ones(val_pos_edge.size(1)),
                            torch.zeros(val_neg_edge.size(1)),
                        ]
                    )

                    val_hyperedge_emb = scatter(
                        src=embeddings[val_node_idx],
                        index=val_edge_idx,
                        dim=0,
                        reduce="sum",
                    )

                    val_logits = predictor(val_hyperedge_emb).squeeze()
                    _, val_inverse = torch.unique(val_edge_idx, return_inverse=True)
                    val_pred = torch.sigmoid(val_logits[val_inverse])

                    # Calculate AUC
                    val_auc = roc_auc_score(
                        val_labels_all.cpu().numpy(), val_pred.cpu().numpy()
                    )

                    if val_auc > best_val_auc:
                        best_val_auc = val_auc
                        best_state = copy.deepcopy(predictor.state_dict())

        # Load best model and evaluate
        if best_state is not None:
            predictor.load_state_dict(best_state)
        predictor.eval()

        with torch.no_grad():
            # Validation metrics
            val_node_idx = torch.cat([val_pos_edge[0], val_neg_edge[0]])
            val_edge_idx = torch.cat([val_pos_edge[1], val_neg_edge[1]])
            val_labels_all = torch.cat(
                [
                    torch.ones(val_pos_edge.size(1)),
                    torch.zeros(val_neg_edge.size(1)),
                ]
            )

            val_hyperedge_emb = scatter(
                src=embeddings[val_node_idx],
                index=val_edge_idx,
                dim=0,
                reduce="sum",
            )

            val_logits = predictor(val_hyperedge_emb).squeeze()
            _, val_inverse = torch.unique(val_edge_idx, return_inverse=True)
            val_pred = torch.sigmoid(val_logits[val_inverse])

            # Test metrics
            test_node_idx = torch.cat([test_pos_edge[0], test_neg_edge[0]])
            test_edge_idx = torch.cat([test_pos_edge[1], test_neg_edge[1]])
            test_labels_all = torch.cat(
                [
                    torch.ones(test_pos_edge.size(1)),
                    torch.zeros(test_neg_edge.size(1)),
                ]
            )

            test_hyperedge_emb = scatter(
                src=embeddings[test_node_idx],
                index=test_edge_idx,
                dim=0,
                reduce="sum",
            )

            test_logits = predictor(test_hyperedge_emb).squeeze()
            _, test_inverse = torch.unique(test_edge_idx, return_inverse=True)
            test_pred = torch.sigmoid(test_logits[test_inverse])

            # Convert to numpy
            val_labels_np = val_labels_all.cpu().numpy()
            val_pred_np = val_pred.cpu().numpy()
            test_labels_np = test_labels_all.cpu().numpy()
            test_pred_np = test_pred.cpu().numpy()

            return {
                "val_auc": float(roc_auc_score(val_labels_np, val_pred_np)),
                "val_ap": float(average_precision_score(val_labels_np, val_pred_np)),
                "test_auc": float(roc_auc_score(test_labels_np, test_pred_np)),
                "test_ap": float(average_precision_score(test_labels_np, test_pred_np)),
            }

    def __str__(self) -> str:
        """Return string representation."""
        return (
            f"SSLLinearEvaluationProtocol("
            f"task={self.task}, "
            f"classifier={self.classifier_type}, "
            f"ratio={self.train_ratio}/{self.val_ratio}/{self.test_ratio}, "
            f"seed={self.seed})"
        )
