"""Link prediction protocol for hypergraph benchmarking."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import torch
    from pyg_hyper_data.data import HyperData

from pyg_hyper_bench.protocols.base import BenchmarkProtocol

__all__ = ["LinkPredictionProtocol"]


@dataclass
class LinkPredictionProtocol(BenchmarkProtocol):
    """Protocol for hyperedge prediction tasks.

    This protocol implements hyperedge link prediction benchmarking:
    - Predict whether a set of nodes forms a hyperedge
    - Positive samples: existing hyperedges
    - Negative samples: node sets that don't form hyperedges

    **Evaluation Strategy**:
    - Train on subset of hyperedges
    - Predict presence/absence of held-out hyperedges
    - Binary classification: real hyperedge vs random node set

    Attributes:
        train_ratio: Fraction of hyperedges for training (default: 0.7)
        val_ratio: Fraction for validation (default: 0.1)
        test_ratio: Fraction for testing (default: 0.2)
        negative_sampling_ratio: Ratio of negative to positive samples (default: 1.0)
        seed: Random seed (default: 42)

    Example:
        >>> from pyg_hyper_data.datasets import CoraCocitation
        >>> from pyg_hyper_bench.protocols import LinkPredictionProtocol
        >>>
        >>> dataset = CoraCocitation()
        >>> data = dataset[0]
        >>>
        >>> # Create protocol
        >>> protocol = LinkPredictionProtocol(
        ...     train_ratio=0.7,
        ...     val_ratio=0.1,
        ...     test_ratio=0.2,
        ...     negative_sampling_ratio=1.0,
        ...     seed=42
        ... )
        >>>
        >>> # Split data
        >>> split = protocol.split_data(data)
        >>> train_data = split['train_data']  # Graph for training
        >>> val_pos = split['val_pos_edge']   # Positive validation samples
        >>> val_neg = split['val_neg_edge']   # Negative validation samples
        >>>
        >>> # ... train model on train_data ...
        >>>
        >>> # Evaluate
        >>> # Score positive and negative samples
        >>> pos_scores = model.predict(val_pos)
        >>> neg_scores = model.predict(val_neg)
        >>> metrics = protocol.evaluate(pos_scores, neg_scores)
        >>> print(f"AUC: {metrics['auc']:.4f}")
        >>> print(f"MRR: {metrics['mrr']:.4f}")

    References:
        - HyperGCN: Hyperedge prediction task
        - PyG RandomLinkSplit: Pairwise link prediction
        - Research Report 2, Section 4.4: HyperedgeLinkSplit
    """

    train_ratio: float = 0.7
    val_ratio: float = 0.1
    test_ratio: float = 0.2
    negative_sampling_ratio: float = 1.0
    seed: int = 42

    def split_data(self, data: HyperData) -> dict[str, Any]:
        """Split data for link prediction.

        Args:
            data: HyperData object with hyperedge_index

        Returns:
            Dictionary containing:
            - train_data: HyperData with train hyperedges only
            - train_pos_edge, train_neg_edge: Training samples
            - val_pos_edge, val_neg_edge: Validation samples
            - test_pos_edge, test_neg_edge: Test samples
            - train_mask, val_mask, test_mask: Boolean masks
        """
        from pyg_hyper_data.transforms import hyperedge_prediction_split

        return hyperedge_prediction_split(
            data,
            train_ratio=self.train_ratio,
            val_ratio=self.val_ratio,
            test_ratio=self.test_ratio,
            seed=self.seed,
            negative_sampling_ratio=self.negative_sampling_ratio,
        )

    def evaluate(
        self, pos_scores: torch.Tensor, neg_scores: torch.Tensor
    ) -> dict[str, float]:
        """Compute link prediction metrics.

        Args:
            pos_scores: Scores for positive samples [num_pos]
            neg_scores: Scores for negative samples [num_neg]

        Returns:
            Dictionary with metrics:
            - auc: Area Under ROC Curve
            - ap: Average Precision
            - mrr: Mean Reciprocal Rank
            - hits@10: Hits at 10
            - hits@50: Hits at 50
            - hits@100: Hits at 100

        Note:
            Scores should be in range [0, 1] or raw logits.
            Higher scores indicate higher probability of being a real hyperedge.
        """
        # Ensure same device
        pos_scores = pos_scores.to(pos_scores.device)
        neg_scores = neg_scores.to(pos_scores.device)

        # Flatten if needed
        if pos_scores.dim() > 1:
            pos_scores = pos_scores.flatten()
        if neg_scores.dim() > 1:
            neg_scores = neg_scores.flatten()

        # AUC (Area Under ROC Curve)
        auc = self._compute_auc(pos_scores, neg_scores)

        # Average Precision
        ap = self._compute_average_precision(pos_scores, neg_scores)

        # MRR (Mean Reciprocal Rank)
        mrr = self._compute_mrr(pos_scores, neg_scores)

        # Hits@K
        hits_at_10 = self._compute_hits_at_k(pos_scores, neg_scores, k=10)
        hits_at_50 = self._compute_hits_at_k(pos_scores, neg_scores, k=50)
        hits_at_100 = self._compute_hits_at_k(pos_scores, neg_scores, k=100)

        return {
            "auc": auc,
            "ap": ap,
            "mrr": mrr,
            "hits@10": hits_at_10,
            "hits@50": hits_at_50,
            "hits@100": hits_at_100,
        }

    def _compute_auc(self, pos_scores: torch.Tensor, neg_scores: torch.Tensor) -> float:
        """Compute Area Under ROC Curve.

        AUC measures the probability that a positive sample has a higher
        score than a negative sample.
        """
        import torch

        # Combine scores and labels
        scores = torch.cat([pos_scores, neg_scores])
        labels = torch.cat(
            [
                torch.ones(pos_scores.size(0)),
                torch.zeros(neg_scores.size(0)),
            ]
        ).to(scores.device)

        # Sort by scores (descending)
        sorted_indices = torch.argsort(scores, descending=True)
        sorted_labels = labels[sorted_indices]

        # Compute AUC using trapezoidal rule
        n_pos = pos_scores.size(0)
        n_neg = neg_scores.size(0)

        # Count true positives and false positives at each threshold
        tp = torch.cumsum(sorted_labels, dim=0)
        fp = torch.cumsum(1 - sorted_labels, dim=0)

        # Compute TPR and FPR
        tpr = tp / n_pos
        fpr = fp / n_neg

        # Add (0, 0) and (1, 1) points
        tpr = torch.cat([torch.tensor([0.0]).to(tpr.device), tpr])
        fpr = torch.cat([torch.tensor([0.0]).to(fpr.device), fpr])

        # Compute AUC using trapezoidal rule
        auc = torch.trapz(tpr, fpr).item()

        return float(auc)

    def _compute_average_precision(
        self, pos_scores: torch.Tensor, neg_scores: torch.Tensor
    ) -> float:
        """Compute Average Precision.

        AP summarizes the precision-recall curve as the weighted mean of
        precisions at each threshold.
        """
        import torch

        # Combine scores and labels
        scores = torch.cat([pos_scores, neg_scores])
        labels = torch.cat(
            [
                torch.ones(pos_scores.size(0)),
                torch.zeros(neg_scores.size(0)),
            ]
        ).to(scores.device)

        # Sort by scores (descending)
        sorted_indices = torch.argsort(scores, descending=True)
        sorted_labels = labels[sorted_indices]

        # Compute precision at each threshold
        tp = torch.cumsum(sorted_labels, dim=0)
        total = torch.arange(1, len(sorted_labels) + 1, device=tp.device).float()
        precision = tp / total

        # Average precision: mean of precisions where label is positive
        ap = (precision * sorted_labels).sum() / sorted_labels.sum()

        return float(ap.item())

    def _compute_mrr(self, pos_scores: torch.Tensor, neg_scores: torch.Tensor) -> float:
        """Compute Mean Reciprocal Rank.

        MRR measures the average of reciprocal ranks of positive samples
        when ranked against negative samples.
        """
        num_pos = pos_scores.size(0)
        reciprocal_ranks = []

        for i in range(num_pos):
            # Rank this positive sample against all negative samples
            pos_score = pos_scores[i]
            # Count how many negative samples have higher scores
            rank = (neg_scores > pos_score).sum().item() + 1
            reciprocal_ranks.append(1.0 / rank)

        mrr = sum(reciprocal_ranks) / len(reciprocal_ranks)
        return float(mrr)

    def _compute_hits_at_k(
        self, pos_scores: torch.Tensor, neg_scores: torch.Tensor, k: int
    ) -> float:
        """Compute Hits@K.

        Hits@K measures the fraction of positive samples that are ranked
        in the top K when ranked against negative samples.
        """
        num_pos = pos_scores.size(0)
        hits = 0

        for i in range(num_pos):
            # Rank this positive sample against all negative samples
            pos_score = pos_scores[i]
            # Count how many negative samples have higher scores
            rank = (neg_scores > pos_score).sum().item() + 1
            if rank <= k:
                hits += 1

        hits_at_k = hits / num_pos
        return float(hits_at_k)

    def __str__(self) -> str:
        """Return string representation."""
        return (
            f"LinkPredictionProtocol("
            f"ratio={self.train_ratio}/{self.val_ratio}/{self.test_ratio}, "
            f"neg_ratio={self.negative_sampling_ratio}, "
            f"seed={self.seed})"
        )
