"""pyg-hyper-bench: Comprehensive benchmarking framework for hypergraph learning.

This package provides statistical evaluation, multi-run benchmarks, and PyTorch Lightning
integration for hypergraph neural networks.
"""

__version__ = "0.1.0"

# Avoid circular import - import at module level only when needed
__all__ = [
    "BenchmarkProtocol",
    "ClusteringProtocol",
    "LinkPredictionProtocol",
    "MultiRunEvaluator",
    "MultiRunResult",
    "NodeClassificationProtocol",
    "SSLLinearEvaluationProtocol",
    "SingleRunEvaluator",
]


def __getattr__(name: str):
    """Lazy import for avoiding circular dependencies."""
    if name == "BenchmarkProtocol":
        from pyg_hyper_bench.protocols import BenchmarkProtocol

        return BenchmarkProtocol
    if name == "ClusteringProtocol":
        from pyg_hyper_bench.protocols import ClusteringProtocol

        return ClusteringProtocol
    if name == "LinkPredictionProtocol":
        from pyg_hyper_bench.protocols import LinkPredictionProtocol

        return LinkPredictionProtocol
    if name == "NodeClassificationProtocol":
        from pyg_hyper_bench.protocols import NodeClassificationProtocol

        return NodeClassificationProtocol
    if name == "SSLLinearEvaluationProtocol":
        from pyg_hyper_bench.protocols import SSLLinearEvaluationProtocol

        return SSLLinearEvaluationProtocol
    if name == "SingleRunEvaluator":
        from pyg_hyper_bench.evaluators import SingleRunEvaluator

        return SingleRunEvaluator
    if name == "MultiRunEvaluator":
        from pyg_hyper_bench.evaluators import MultiRunEvaluator

        return MultiRunEvaluator
    if name == "MultiRunResult":
        from pyg_hyper_bench.evaluators import MultiRunResult

        return MultiRunResult
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)
