"""Multi-run evaluator with statistical analysis.

This module provides multi-run evaluation capabilities with statistical aggregation,
following patterns from TriCL and HyperGCL reference implementations.

Reference implementations:
- TriCL: Multi-seed x multi-split evaluation with mean ± std
- HyperGCL: Logger-based multi-run tracking with best epoch selection
- HyperBoy: 20-split evaluation with mean ± std aggregation
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

    from pyg_hyper_data.datasets.base import BaseHyperDataset

    from pyg_hyper_bench.protocols.base import BenchmarkProtocol

import numpy as np
import torch
from scipy import stats
from tqdm import tqdm

__all__ = [
    "MultiRunEvaluator",
    "MultiRunResult",
]


@dataclass
class MultiRunResult:
    """Multi-run evaluation result with statistical aggregation.

    Attributes:
        means: Mean values for each metric {metric_name: mean}
        stds: Standard deviations {metric_name: std}
        confidence_intervals: 95% confidence intervals {metric_name: (lower, upper)}
        raw_results: Raw results from each run List[{metric_name: value}]
        n_runs: Number of runs
    """

    means: dict[str, float]
    stds: dict[str, float]
    confidence_intervals: dict[str, tuple[float, float]]
    raw_results: list[dict[str, float]]
    n_runs: int

    def summary_table(self, split: str = "test") -> str:
        """Generate summary table in Markdown format.

        Args:
            split: Split name for table title

        Returns:
            Markdown-formatted table string
        """
        lines = [f"## {split.capitalize()} Results (n={self.n_runs} runs)"]
        lines.append("")
        lines.append("| Metric | Mean ± Std | 95% CI |")
        lines.append("|--------|------------|--------|")

        for metric, mean in self.means.items():
            std = self.stds[metric]
            ci_lower, ci_upper = self.confidence_intervals[metric]
            lines.append(
                f"| {metric} | {mean:.4f} ± {std:.4f} | [{ci_lower:.4f}, {ci_upper:.4f}] |"
            )

        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "means": self.means,
            "stds": self.stds,
            "confidence_intervals": {
                k: {"lower": v[0], "upper": v[1]}
                for k, v in self.confidence_intervals.items()
            },
            "raw_results": self.raw_results,
            "n_runs": self.n_runs,
        }


class MultiRunEvaluator:
    """Multi-run evaluator with statistical analysis.

    Wraps pyg-hyper-data's protocols and runs multiple evaluations with different
    random seeds, then aggregates results with statistical measures (mean, std, CI).

    Reference patterns:
    - TriCL: Outer loop over seeds, inner loop over splits
    - HyperGCL: Logger tracks per-run metrics, selects best by validation
    - HyperBoy: 20 pre-generated splits with mean ± std aggregation

    Example:
        >>> from pyg_hyper_data.datasets import CoraCocitation
        >>> from pyg_hyper_data.benchmark import NodeClassificationProtocol
        >>> from pyg_hyper_bench.evaluators import MultiRunEvaluator
        >>>
        >>> dataset = CoraCocitation()
        >>> protocol = NodeClassificationProtocol()
        >>>
        >>> evaluator = MultiRunEvaluator(
        ...     dataset=dataset,
        ...     protocol=protocol,
        ...     n_runs=10,
        ...     device="cuda"
        ... )
        >>>
        >>> def model_fn(seed):
        ...     return MyModel(...)
        >>>
        >>> def train_fn(model, data, train_mask, val_mask):
        ...     # Training logic
        ...     return trained_model
        >>>
        >>> results = evaluator.run_evaluation(model_fn, train_fn)
        >>> print(results["test"].summary_table())
    """

    def __init__(
        self,
        dataset: BaseHyperDataset,
        protocol: BenchmarkProtocol,
        n_runs: int = 10,
        seeds: list[int] | None = None,
        device: str = "cpu",
        verbose: bool = True,
    ) -> None:
        """Initialize MultiRunEvaluator.

        Args:
            dataset: Benchmark dataset
            protocol: Evaluation protocol (from pyg-hyper-data or pyg-hyper-bench)
            n_runs: Number of runs (default: 10, following HyperGCL)
            seeds: List of seeds for each run (default: [42, 43, ..., 42+n_runs-1])
            device: Device ("cpu" or "cuda")
            verbose: Show progress bars
        """
        self.dataset = dataset
        self.protocol = protocol
        self.n_runs = n_runs
        self.seeds = seeds or list(range(42, 42 + n_runs))
        self.device = device
        self.verbose = verbose

        if len(self.seeds) != n_runs:
            msg = f"seeds length ({len(self.seeds)}) must match n_runs ({n_runs})"
            raise ValueError(msg)

    def run_evaluation(
        self,
        model_fn: Callable,
        train_fn: Callable,
        splits: list[str] | None = None,
    ) -> dict[str, MultiRunResult]:
        """Run multi-run evaluation.

        Args:
            model_fn: Model factory function taking seed as argument
            train_fn: Training function (model, data, train_mask, val_mask) -> trained_model
            splits: Splits to evaluate (default: ["val", "test"])

        Returns:
            Dictionary mapping split names to MultiRunResult objects
        """
        if splits is None:
            splits = ["val", "test"]

        all_results = {split: [] for split in splits}

        iterator = enumerate(self.seeds)
        if self.verbose:
            iterator = tqdm(
                iterator, total=len(self.seeds), desc="Multi-run evaluation"
            )

        for run_idx, seed in iterator:
            # Set all random seeds for reproducibility
            self._set_seed(seed)

            # Create model
            model = model_fn(seed=seed)
            if hasattr(model, "to"):
                model = model.to(self.device)

            # Get data and split
            data = self.dataset[0]
            if hasattr(data, "to"):
                data = data.to(self.device)

            split_dict = self.protocol.split_data(data)

            # Train model
            trained_model = train_fn(
                model,
                data=split_dict.get("data", data),
                train_mask=split_dict.get("train_mask"),
                val_mask=split_dict.get("val_mask"),
            )

            # Evaluate on each split
            for split in splits:
                mask = split_dict.get(f"{split}_mask")

                with torch.no_grad():
                    if hasattr(trained_model, "eval"):
                        trained_model.eval()

                    # Get predictions
                    predictions = trained_model(data.x, data.hyperedge_index)

                    # Evaluate using protocol
                    metrics = self.protocol.evaluate(predictions[mask], data.y[mask])

                all_results[split].append(metrics)

            if self.verbose and isinstance(iterator, enumerate):
                # Update progress bar description with latest results
                test_acc = all_results["test"][-1].get("accuracy", 0.0)
                tqdm.write(
                    f"Run {run_idx + 1}/{self.n_runs}: test_acc = {test_acc:.4f}"
                )

        # Aggregate results for each split
        aggregated = {}
        for split in splits:
            aggregated[split] = self._aggregate_results(all_results[split])

        return aggregated

    def _aggregate_results(self, results: list[dict[str, float]]) -> MultiRunResult:
        """Aggregate results with statistical measures.

        Follows TriCL pattern: mean ± std across all runs.

        Args:
            results: List of metric dictionaries from each run

        Returns:
            MultiRunResult with aggregated statistics
        """
        if not results:
            return MultiRunResult(
                means={}, stds={}, confidence_intervals={}, raw_results=[], n_runs=0
            )

        metric_names = results[0].keys()

        means = {}
        stds = {}
        confidence_intervals = {}

        for metric in metric_names:
            values = np.array([r[metric] for r in results])

            # Mean and std (TriCL pattern)
            means[metric] = float(np.mean(values))
            stds[metric] = float(np.std(values))

            # 95% confidence interval using t-distribution
            if len(values) > 1:
                ci = stats.t.interval(
                    0.95, len(values) - 1, loc=means[metric], scale=stats.sem(values)
                )
                confidence_intervals[metric] = (float(ci[0]), float(ci[1]))
            else:
                # Single run: CI = mean
                confidence_intervals[metric] = (means[metric], means[metric])

        return MultiRunResult(
            means=means,
            stds=stds,
            confidence_intervals=confidence_intervals,
            raw_results=results,
            n_runs=len(results),
        )

    def _set_seed(self, seed: int) -> None:
        """Set all random seeds for reproducibility.

        Following TriCL's fix_seed pattern.

        Args:
            seed: Random seed
        """
        import random

        random.seed(seed)
        # Note: Using legacy np.random.seed for compatibility with reference implementations
        np.random.seed(seed)  # noqa: NPY002
        torch.manual_seed(seed)

        if torch.cuda.is_available():
            torch.cuda.manual_seed(seed)
            torch.cuda.manual_seed_all(seed)
            # Deterministic behavior (may impact performance)
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False
