"""Single-run evaluator for hypergraph learning tasks.

This module provides a unified interface for evaluating hypergraph models
across different datasets and experimental settings.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pyg_hyper_data.data import HyperData
    from pyg_hyper_data.datasets.base import BaseHyperDataset

    from pyg_hyper_bench.protocols.base import BenchmarkProtocol

logger = logging.getLogger(__name__)

__all__ = ["SingleRunEvaluator"]


class SingleRunEvaluator:
    """Single-run evaluator for hypergraph benchmarks.

    This class provides a consistent interface for evaluating models across
    different datasets and protocols, ensuring:
    - Reproducible results with fixed seeds
    - Consistent metric computation
    - Easy comparison across different settings

    Attributes:
        dataset: Hypergraph dataset to evaluate on
        protocol: Benchmark protocol defining splits and metrics
        device: Device for evaluation (default: 'cpu')

    Example:
        >>> from pyg_hyper_data.datasets import CoraCocitation
        >>> from pyg_hyper_bench.protocols import NodeClassificationProtocol
        >>> from pyg_hyper_bench.evaluators import SingleRunEvaluator
        >>>
        >>> # Setup
        >>> dataset = CoraCocitation()
        >>> protocol = NodeClassificationProtocol(
        ...     split_type='transductive',
        ...     seed=42
        ... )
        >>> evaluator = SingleRunEvaluator(dataset, protocol)
        >>>
        >>> # Get splits
        >>> split = evaluator.get_split()
        >>> train_mask = split['train_mask']
        >>> data = split['data']
        >>>
        >>> # ... train your model ...
        >>> # predictions = model(data)
        >>>
        >>> # Evaluate (example with dummy predictions)
        >>> import torch
        >>> predictions = torch.randint(0, 7, (data.num_nodes,))
        >>> metrics = evaluator.evaluate(
        ...     predictions=predictions[split['test_mask']],
        ...     targets=data.y[split['test_mask']],
        ...     split='test'
        ... )
        >>> print(f"Test Accuracy: {metrics['accuracy']:.4f}")

    Note:
        This evaluator is designed for research reproducibility.
        For production use, consider caching splits and using more
        efficient batch evaluation.
    """

    def __init__(
        self,
        dataset: BaseHyperDataset,
        protocol: BenchmarkProtocol,
        device: str = "cpu",
    ) -> None:
        """Initialize evaluator.

        Args:
            dataset: Hypergraph dataset
            protocol: Evaluation protocol
            device: Device for evaluation
        """
        self.dataset = dataset
        self.protocol = protocol
        self.device = device

        # Get data
        from pyg_hyper_data.data import HyperData

        data = dataset[0]
        if isinstance(data, HyperData):
            self.data: HyperData = data
        else:
            msg = f"Dataset must return HyperData, got {type(data)}"
            raise TypeError(msg)

        # Create split
        self._split = None

        logger.info(
            "Initialized SingleRunEvaluator:\n"
            "  Dataset: %s (%d nodes, %d hyperedges)\n"
            "  Protocol: %s",
            dataset.__class__.__name__,
            self.data.num_nodes,
            self.data.num_hyperedges,
            protocol,
        )

    def get_split(self) -> dict:
        """Get train/val/test split according to protocol.

        Returns:
            Dictionary with split data and masks
        """
        if self._split is None:
            self._split = self.protocol.split_data(self.data)
            logger.info("Created data split using protocol")

        return self._split

    def evaluate(
        self,
        predictions,  # noqa: ANN001
        targets,  # noqa: ANN001
        split: str = "test",
    ) -> dict[str, float]:
        """Evaluate predictions using protocol metrics.

        Args:
            predictions: Model predictions
            targets: Ground truth targets
            split: Which split ('train', 'val', or 'test')

        Returns:
            Dictionary of metric names to values
        """
        metrics = self.protocol.evaluate(predictions, targets)

        logger.info(
            "%s metrics: %s",
            split.capitalize(),
            ", ".join(f"{k}={v:.4f}" for k, v in metrics.items()),
        )

        return metrics

    def run_evaluation(
        self,
        model_fn,  # noqa: ANN001
        splits: list[str] | None = None,
    ) -> dict[str, dict[str, float]]:
        """Run full evaluation pipeline.

        This is a convenience method that:
        1. Gets the data split
        2. Runs model on each split
        3. Computes metrics

        Args:
            model_fn: Function that takes data and returns predictions
                Signature: (data, mask) -> predictions
            splits: Which splits to evaluate (default: ['val', 'test'])

        Returns:
            Dictionary mapping split names to their metrics

        Example:
            >>> def my_model(data, mask):
            ...     # Your model logic here
            ...     return predictions[mask]
            >>>
            >>> results = evaluator.run_evaluation(my_model)
            >>> print(results['test']['accuracy'])
        """
        if splits is None:
            splits = ["val", "test"]

        split_data = self.get_split()
        results = {}

        for split_name in splits:
            # Get split mask
            if self.protocol.split_type == "transductive":
                mask = split_data[f"{split_name}_mask"]
                data = split_data["data"]
                targets = data.y[mask]
            else:
                # Inductive
                data = split_data[f"{split_name}_data"]
                mask = None
                targets = data.y

            # Run model
            predictions = model_fn(data, mask)

            # Evaluate
            metrics = self.evaluate(predictions, targets, split=split_name)
            results[split_name] = metrics

        return results

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"SingleRunEvaluator(\n"
            f"  dataset={self.dataset.__class__.__name__},\n"
            f"  protocol={self.protocol},\n"
            f"  device={self.device}\n"
            f")"
        )
