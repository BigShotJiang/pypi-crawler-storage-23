"""Tests for LinkPredictionProtocol."""

import pytest
import torch
from pyg_hyper_data.datasets import CoraCocitation

from pyg_hyper_bench.protocols import LinkPredictionProtocol


class TestLinkPredictionProtocol:
    """Test LinkPredictionProtocol."""

    def test_initialization(self) -> None:
        """Test protocol initialization."""
        protocol = LinkPredictionProtocol(
            train_ratio=0.7,
            val_ratio=0.1,
            test_ratio=0.2,
            negative_sampling_ratio=1.0,
            seed=42,
        )

        assert protocol.train_ratio == 0.7
        assert protocol.val_ratio == 0.1
        assert protocol.test_ratio == 0.2
        assert protocol.negative_sampling_ratio == 1.0
        assert protocol.seed == 42

    def test_split_data(self) -> None:
        """Test data splitting for link prediction."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol = LinkPredictionProtocol(
            train_ratio=0.7, val_ratio=0.1, test_ratio=0.2, seed=42
        )

        split = protocol.split_data(data)

        # Check required keys
        assert "train_data" in split
        assert "train_pos_edge" in split
        assert "train_neg_edge" in split
        assert "val_pos_edge" in split
        assert "val_neg_edge" in split
        assert "test_pos_edge" in split
        assert "test_neg_edge" in split

        # Check train_data structure
        train_data = split["train_data"]
        assert hasattr(train_data, "hyperedge_index")
        assert hasattr(train_data, "num_hyperedges")

        # Check positive/negative samples
        train_pos = split["train_pos_edge"]
        train_neg = split["train_neg_edge"]
        assert train_pos.size(0) == 2  # [2, num_edges]
        assert train_neg.size(0) == 2
        assert train_pos.size(1) > 0
        assert train_neg.size(1) > 0

        # Check ratios (approximately)
        total_edges = data.num_hyperedges
        train_edges = train_data.num_hyperedges
        assert 0.6 < train_edges / total_edges < 0.8  # Approximately 0.7

        print("\nData split:")
        print(f"  Original: {total_edges} hyperedges")
        print(f"  Train: {train_data.num_hyperedges} hyperedges")
        print(f"  Val pos: {split['val_pos_edge'].size(1)}")
        print(f"  Test pos: {split['test_pos_edge'].size(1)}")

    def test_evaluate_auc(self) -> None:
        """Test AUC metric computation."""
        protocol = LinkPredictionProtocol()

        # Perfect separation
        pos_scores = torch.tensor([0.9, 0.8, 0.7, 0.6])
        neg_scores = torch.tensor([0.5, 0.4, 0.3, 0.2])

        metrics = protocol.evaluate(pos_scores, neg_scores)

        assert "auc" in metrics
        assert "ap" in metrics
        assert "mrr" in metrics
        assert "hits@10" in metrics

        # AUC should be 1.0 for perfect separation
        assert metrics["auc"] == pytest.approx(1.0, abs=0.01)

        # All metrics should be in valid range
        for value in metrics.values():
            assert 0.0 <= value <= 1.0, f"Metric value {value} not in [0, 1]"

    def test_evaluate_random(self) -> None:
        """Test evaluation with random scores."""
        protocol = LinkPredictionProtocol()

        # Random scores
        torch.manual_seed(42)
        pos_scores = torch.rand(50)
        neg_scores = torch.rand(50)

        metrics = protocol.evaluate(pos_scores, neg_scores)

        # AUC should be around 0.5 for random
        assert 0.3 < metrics["auc"] < 0.7

        # All metrics should be in valid range
        for value in metrics.values():
            assert 0.0 <= value <= 1.0

        print("\nRandom scores metrics:")
        for name, value in metrics.items():
            print(f"  {name}: {value:.4f}")

    def test_evaluate_perfect_scores(self) -> None:
        """Test evaluation with perfect scores."""
        protocol = LinkPredictionProtocol()

        # All positive higher than negative
        pos_scores = torch.ones(10) * 0.9
        neg_scores = torch.ones(10) * 0.1

        metrics = protocol.evaluate(pos_scores, neg_scores)

        # Should have perfect metrics
        assert metrics["auc"] == pytest.approx(1.0, abs=0.01)
        assert metrics["ap"] == pytest.approx(1.0, abs=0.01)
        assert metrics["hits@10"] == pytest.approx(1.0, abs=0.01)

    def test_evaluate_worst_scores(self) -> None:
        """Test evaluation with worst case scores."""
        protocol = LinkPredictionProtocol()

        # All negative higher than positive
        pos_scores = torch.ones(10) * 0.1
        neg_scores = torch.ones(10) * 0.9

        metrics = protocol.evaluate(pos_scores, neg_scores)

        # Should have worst metrics
        assert metrics["auc"] == pytest.approx(0.0, abs=0.01)
        # AP is affected by the ratio of positive samples, not always close to 0
        assert 0.0 <= metrics["ap"] <= 1.0
        assert metrics["hits@10"] == pytest.approx(0.0, abs=0.01)

    def test_mrr_computation(self) -> None:
        """Test MRR computation."""
        protocol = LinkPredictionProtocol()

        # Positive scores ranked 1st among negatives
        pos_scores = torch.tensor([1.0, 0.5, 0.3])
        neg_scores = torch.tensor([0.4, 0.2, 0.1])

        metrics = protocol.evaluate(pos_scores, neg_scores)

        # MRR should be high (pos samples rank well)
        assert metrics["mrr"] > 0.5

        print("\nMRR test:")
        print(f"  Positive scores: {pos_scores.tolist()}")
        print(f"  Negative scores: {neg_scores.tolist()}")
        print(f"  MRR: {metrics['mrr']:.4f}")

    def test_hits_at_k(self) -> None:
        """Test Hits@K computation."""
        protocol = LinkPredictionProtocol()

        # Create scenario where some positives rank in top K
        pos_scores = torch.tensor([0.9, 0.5, 0.1])  # 3 positive
        neg_scores = torch.tensor([0.8, 0.7, 0.6, 0.4, 0.3, 0.2])  # 6 negative

        metrics = protocol.evaluate(pos_scores, neg_scores)

        # First positive (0.9) ranks 1st → hits@10 >= 1/3
        # Second positive (0.5) ranks 5th → hits@10 >= 2/3
        # Third positive (0.1) ranks last → not in top 10

        assert metrics["hits@10"] > 0.0
        print("\nHits@K test:")
        print(f"  hits@10: {metrics['hits@10']:.4f}")
        print(f"  hits@50: {metrics['hits@50']:.4f}")
        print(f"  hits@100: {metrics['hits@100']:.4f}")

    def test_reproducibility(self) -> None:
        """Test that same seed produces same split."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol1 = LinkPredictionProtocol(seed=42)
        protocol2 = LinkPredictionProtocol(seed=42)

        split1 = protocol1.split_data(data)
        split2 = protocol2.split_data(data)

        # Train data should have same number of hyperedges
        assert (
            split1["train_data"].num_hyperedges == split2["train_data"].num_hyperedges
        )

        # Validation samples should be identical
        assert torch.equal(split1["val_pos_edge"], split2["val_pos_edge"])

        print("\n✓ Same seed produces identical splits")

    def test_different_seeds(self) -> None:
        """Test that different seeds produce different splits."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol1 = LinkPredictionProtocol(seed=42)
        protocol2 = LinkPredictionProtocol(seed=43)

        split1 = protocol1.split_data(data)
        split2 = protocol2.split_data(data)

        # Different seeds should produce different splits
        assert not torch.equal(split1["val_pos_edge"], split2["val_pos_edge"])

        print("\n✓ Different seeds produce different splits")

    def test_negative_sampling_ratio(self) -> None:
        """Test different negative sampling ratios."""
        dataset = CoraCocitation()
        data = dataset[0]

        # Test with different ratios
        for ratio in [0.5, 1.0, 2.0]:
            protocol = LinkPredictionProtocol(negative_sampling_ratio=ratio, seed=42)
            split = protocol.split_data(data)

            val_pos_count = split["val_pos_edge"].size(1)
            val_neg_count = split["val_neg_edge"].size(1)

            # Note: pyg-hyper-data's negative sampling may not exactly match the ratio
            # due to hypergraph structure constraints (variable hyperedge sizes)
            # Just check that we have some negative samples
            assert val_neg_count > 0

            print(f"\nNegative sampling ratio {ratio}:")
            print(f"  Positive: {val_pos_count}")
            print(f"  Negative: {val_neg_count}")
            print(f"  Actual ratio: {val_neg_count / val_pos_count:.2f}")

    def test_str_representation(self) -> None:
        """Test string representation."""
        protocol = LinkPredictionProtocol(
            train_ratio=0.7,
            val_ratio=0.1,
            test_ratio=0.2,
            negative_sampling_ratio=1.5,
            seed=42,
        )

        str_repr = str(protocol)
        assert "LinkPredictionProtocol" in str_repr
        assert "0.7" in str_repr or "0.1" in str_repr or "0.2" in str_repr
        assert "1.5" in str_repr
        assert "42" in str_repr

        print(f"\nString representation: {str_repr}")
