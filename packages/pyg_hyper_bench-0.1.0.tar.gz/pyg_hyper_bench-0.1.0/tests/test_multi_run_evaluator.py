"""Tests for MultiRunEvaluator."""

import numpy as np
import pytest
import torch
from torch import Tensor

from pyg_hyper_bench.evaluators import MultiRunEvaluator, MultiRunResult


class TestMultiRunResult:
    """Test MultiRunResult dataclass."""

    def test_summary_table(self) -> None:
        """Test summary table generation."""
        result = MultiRunResult(
            means={"accuracy": 0.8234, "f1_macro": 0.8156},
            stds={"accuracy": 0.0123, "f1_macro": 0.0135},
            confidence_intervals={
                "accuracy": (0.8145, 0.8323),
                "f1_macro": (0.8059, 0.8253),
            },
            raw_results=[
                {"accuracy": 0.82, "f1_macro": 0.81},
                {"accuracy": 0.83, "f1_macro": 0.82},
            ],
            n_runs=10,
        )

        table = result.summary_table(split="test")

        assert "## Test Results (n=10 runs)" in table
        assert "| Metric | Mean ± Std | 95% CI |" in table
        assert "| accuracy | 0.8234 ± 0.0123 | [0.8145, 0.8323] |" in table
        assert "| f1_macro | 0.8156 ± 0.0135 | [0.8059, 0.8253] |" in table

    def test_to_dict(self) -> None:
        """Test dictionary conversion for JSON serialization."""
        result = MultiRunResult(
            means={"accuracy": 0.85},
            stds={"accuracy": 0.01},
            confidence_intervals={"accuracy": (0.84, 0.86)},
            raw_results=[{"accuracy": 0.85}],
            n_runs=5,
        )

        d = result.to_dict()

        assert d["means"] == {"accuracy": 0.85}
        assert d["stds"] == {"accuracy": 0.01}
        assert d["confidence_intervals"]["accuracy"] == {"lower": 0.84, "upper": 0.86}
        assert d["raw_results"] == [{"accuracy": 0.85}]
        assert d["n_runs"] == 5


class TestMultiRunEvaluator:
    """Test MultiRunEvaluator."""

    def test_initialization(self) -> None:
        """Test evaluator initialization."""
        from pyg_hyper_data.datasets import CoraCocitation

        from pyg_hyper_bench.protocols import NodeClassificationProtocol

        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol()

        evaluator = MultiRunEvaluator(
            dataset=dataset,
            protocol=protocol,
            n_runs=5,
            device="cpu",
        )

        assert evaluator.n_runs == 5
        assert evaluator.seeds == [42, 43, 44, 45, 46]
        assert evaluator.device == "cpu"

    def test_initialization_with_custom_seeds(self) -> None:
        """Test evaluator initialization with custom seeds."""
        from pyg_hyper_data.datasets import CoraCocitation

        from pyg_hyper_bench.protocols import NodeClassificationProtocol

        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol()

        custom_seeds = [0, 10, 20, 30, 40]
        evaluator = MultiRunEvaluator(
            dataset=dataset,
            protocol=protocol,
            n_runs=5,
            seeds=custom_seeds,
            device="cpu",
        )

        assert evaluator.seeds == custom_seeds

    def test_initialization_seed_mismatch(self) -> None:
        """Test that seed list length must match n_runs."""
        from pyg_hyper_data.datasets import CoraCocitation

        from pyg_hyper_bench.protocols import NodeClassificationProtocol

        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol()

        with pytest.raises(ValueError, match=r"seeds length .* must match n_runs"):
            MultiRunEvaluator(
                dataset=dataset,
                protocol=protocol,
                n_runs=5,
                seeds=[0, 1, 2],  # Only 3 seeds
                device="cpu",
            )

    def test_set_seed(self) -> None:
        """Test seed setting for reproducibility."""
        from pyg_hyper_data.datasets import CoraCocitation

        from pyg_hyper_bench.protocols import NodeClassificationProtocol

        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol()
        evaluator = MultiRunEvaluator(dataset, protocol, n_runs=1)

        # Set seed
        evaluator._set_seed(42)

        # Generate random numbers
        r1 = torch.rand(5)
        n1 = np.random.rand(5)

        # Reset seed
        evaluator._set_seed(42)

        # Generate again - should match
        r2 = torch.rand(5)
        n2 = np.random.rand(5)

        assert torch.allclose(r1, r2)
        assert np.allclose(n1, n2)

    def test_aggregate_results(self) -> None:
        """Test statistical aggregation of results."""
        from pyg_hyper_data.datasets import CoraCocitation

        from pyg_hyper_bench.protocols import NodeClassificationProtocol

        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol()
        evaluator = MultiRunEvaluator(dataset, protocol, n_runs=5)

        # Mock results
        results = [
            {"accuracy": 0.80, "f1_macro": 0.78},
            {"accuracy": 0.82, "f1_macro": 0.80},
            {"accuracy": 0.81, "f1_macro": 0.79},
            {"accuracy": 0.83, "f1_macro": 0.81},
            {"accuracy": 0.79, "f1_macro": 0.77},
        ]

        aggregated = evaluator._aggregate_results(results)

        # Check means
        assert aggregated.means["accuracy"] == pytest.approx(0.81, abs=0.01)
        assert aggregated.means["f1_macro"] == pytest.approx(0.79, abs=0.01)

        # Check stds
        assert aggregated.stds["accuracy"] > 0
        assert aggregated.stds["f1_macro"] > 0

        # Check confidence intervals
        ci_acc = aggregated.confidence_intervals["accuracy"]
        assert ci_acc[0] < aggregated.means["accuracy"] < ci_acc[1]

        # Check raw results preserved
        assert len(aggregated.raw_results) == 5
        assert aggregated.n_runs == 5

    def test_aggregate_results_single_run(self) -> None:
        """Test aggregation with single run."""
        from pyg_hyper_data.datasets import CoraCocitation

        from pyg_hyper_bench.protocols import NodeClassificationProtocol

        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol()
        evaluator = MultiRunEvaluator(dataset, protocol, n_runs=1)

        results = [{"accuracy": 0.85}]

        aggregated = evaluator._aggregate_results(results)

        assert aggregated.means["accuracy"] == 0.85
        assert aggregated.stds["accuracy"] == 0.0
        assert aggregated.confidence_intervals["accuracy"] == (0.85, 0.85)

    def test_aggregate_results_empty(self) -> None:
        """Test aggregation with empty results."""
        from pyg_hyper_data.datasets import CoraCocitation

        from pyg_hyper_bench.protocols import NodeClassificationProtocol

        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol()
        evaluator = MultiRunEvaluator(dataset, protocol, n_runs=0)

        aggregated = evaluator._aggregate_results([])

        assert aggregated.means == {}
        assert aggregated.stds == {}
        assert aggregated.confidence_intervals == {}
        assert aggregated.raw_results == []
        assert aggregated.n_runs == 0

    def test_run_evaluation_basic(self) -> None:
        """Test basic multi-run evaluation."""
        from pyg_hyper_data.datasets import CoraCocitation

        from pyg_hyper_bench.protocols import NodeClassificationProtocol

        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol(seed=42)

        evaluator = MultiRunEvaluator(
            dataset=dataset,
            protocol=protocol,
            n_runs=2,  # Small number for testing
            device="cpu",
            verbose=False,
        )

        # Simple hypergraph model
        class SimpleHypergraphModel(torch.nn.Module):
            def __init__(self, in_channels: int, out_channels: int):
                super().__init__()
                self.lin = torch.nn.Linear(in_channels, out_channels)

            def forward(self, x: Tensor, hyperedge_index: Tensor) -> Tensor:
                # Ignore hyperedge structure for simplicity
                return self.lin(x)

        # Simple model factory
        def model_fn(seed: int) -> torch.nn.Module:
            return SimpleHypergraphModel(dataset.num_node_features, dataset.num_classes)

        # Simple training function (no actual training for speed)
        def train_fn(
            model: torch.nn.Module,
            data: object,
            train_mask: Tensor | None = None,
            val_mask: Tensor | None = None,
        ) -> torch.nn.Module:
            return model  # Return untrained model for testing

        results = evaluator.run_evaluation(
            model_fn=model_fn,
            train_fn=train_fn,
            splits=["test"],
        )

        # Check structure
        assert "test" in results
        assert isinstance(results["test"], MultiRunResult)
        assert results["test"].n_runs == 2

        # Check metrics exist
        assert "accuracy" in results["test"].means
        assert "f1_macro" in results["test"].means
        assert "f1_micro" in results["test"].means


class TestMultiRunEvaluatorIntegration:
    """Integration tests for MultiRunEvaluator."""

    def test_multi_run_with_actual_training(self) -> None:
        """Test multi-run with minimal actual training (slow test)."""
        pytest.skip("Slow integration test - run manually")

        from pyg_hyper_data.datasets import CoraCocitation

        from pyg_hyper_bench.protocols import NodeClassificationProtocol

        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol(seed=42)

        evaluator = MultiRunEvaluator(
            dataset=dataset,
            protocol=protocol,
            n_runs=3,
            device="cpu",
            verbose=True,
        )

        def model_fn(seed: int) -> torch.nn.Module:
            return torch.nn.Sequential(
                torch.nn.Linear(dataset.num_node_features, 64),
                torch.nn.ReLU(),
                torch.nn.Linear(64, dataset.num_classes),
            )

        def train_fn(
            model: torch.nn.Module,
            data: object,
            train_mask: Tensor | None = None,
            _val_mask: Tensor | None = None,
        ) -> torch.nn.Module:
            optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
            criterion = torch.nn.CrossEntropyLoss()

            model.train()
            for _ in range(10):  # Mini training
                optimizer.zero_grad()
                out = model(data.x)
                loss = criterion(out[train_mask], data.y[train_mask])
                loss.backward()
                optimizer.step()

            return model

        results = evaluator.run_evaluation(
            model_fn=model_fn,
            train_fn=train_fn,
            splits=["val", "test"],
        )

        # Verify structure (print statement removed for testing)
        assert results["test"].n_runs == 3
        assert results["test"].means["accuracy"] > 0.0
