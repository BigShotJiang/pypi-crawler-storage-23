"""Tests for ClusteringProtocol."""

import pytest
import torch
from pyg_hyper_data.datasets import CoraCocitation

from pyg_hyper_bench.protocols import ClusteringProtocol


class TestClusteringProtocol:
    """Test ClusteringProtocol."""

    def test_initialization(self) -> None:
        """Test protocol initialization."""
        protocol = ClusteringProtocol(seed=42, n_clusters=7)

        assert protocol.seed == 42
        assert protocol.n_clusters == 7

    def test_initialization_auto_clusters(self) -> None:
        """Test initialization with auto clusters."""
        protocol = ClusteringProtocol(seed=42)

        assert protocol.seed == 42
        assert protocol.n_clusters is None

    def test_split_data(self) -> None:
        """Test split_data returns original data."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol = ClusteringProtocol(seed=42)
        split = protocol.split_data(data)

        # Clustering is unsupervised, no split needed
        assert "data" in split
        assert split["data"] is data

    def test_evaluate_with_ground_truth(self) -> None:
        """Test evaluation with ground truth labels."""
        dataset = CoraCocitation()
        data = dataset[0]

        # Create simple embeddings (use features as embeddings)
        embeddings = data.x[:100]  # First 100 nodes
        labels = data.y[:100]

        protocol = ClusteringProtocol(seed=42)
        metrics = protocol.evaluate(embeddings, labels)

        # Check required keys
        assert "nmi" in metrics
        assert "ari" in metrics
        assert "ami" in metrics

        # All metrics should be in valid range [-1, 1] or [0, 1]
        # NMI is in [0, 1]
        assert 0.0 <= metrics["nmi"] <= 1.0
        # ARI can be negative (worse than random)
        assert -1.0 <= metrics["ari"] <= 1.0
        # AMI can be negative (worse than random)
        assert -1.0 <= metrics["ami"] <= 1.0

        print("\nClustering metrics:")
        print(f"  NMI: {metrics['nmi']:.4f}")
        print(f"  ARI: {metrics['ari']:.4f}")
        print(f"  AMI: {metrics['ami']:.4f}")

    def test_evaluate_perfect_clustering(self) -> None:
        """Test evaluation with perfect clustering."""
        # Create embeddings where each class forms a tight cluster
        n_samples_per_class = 20
        n_classes = 3
        embedding_dim = 10

        embeddings = []
        labels = []

        for class_id in range(n_classes):
            # Create tight cluster for this class
            center = torch.randn(1, embedding_dim) * 10
            class_embeddings = (
                center + torch.randn(n_samples_per_class, embedding_dim) * 0.1
            )
            embeddings.append(class_embeddings)
            labels.append(
                torch.full((n_samples_per_class,), class_id, dtype=torch.long)
            )

        embeddings = torch.cat(embeddings)
        labels = torch.cat(labels)

        protocol = ClusteringProtocol(seed=42, n_clusters=n_classes)
        metrics = protocol.evaluate(embeddings, labels)

        # Perfect clustering should have high metrics
        assert metrics["nmi"] > 0.8, f"Expected NMI > 0.8, got {metrics['nmi']:.4f}"
        assert metrics["ari"] > 0.8, f"Expected ARI > 0.8, got {metrics['ari']:.4f}"
        assert metrics["ami"] > 0.8, f"Expected AMI > 0.8, got {metrics['ami']:.4f}"

        print("\nPerfect clustering metrics:")
        print(f"  NMI: {metrics['nmi']:.4f}")
        print(f"  ARI: {metrics['ari']:.4f}")
        print(f"  AMI: {metrics['ami']:.4f}")

    def test_evaluate_random_embeddings(self) -> None:
        """Test evaluation with random embeddings."""
        # Random embeddings should give poor clustering
        torch.manual_seed(42)
        embeddings = torch.randn(100, 10)
        labels = torch.randint(0, 5, (100,))

        protocol = ClusteringProtocol(seed=42, n_clusters=5)
        metrics = protocol.evaluate(embeddings, labels)

        # Random embeddings should give low metrics
        # NMI close to 0 for random
        assert metrics["nmi"] < 0.5

        print("\nRandom embeddings metrics:")
        print(f"  NMI: {metrics['nmi']:.4f}")
        print(f"  ARI: {metrics['ari']:.4f}")
        print(f"  AMI: {metrics['ami']:.4f}")

    def test_auto_detect_clusters(self) -> None:
        """Test automatic cluster detection from labels."""
        # Create data with 4 classes
        embeddings = torch.randn(100, 10)
        labels = torch.randint(0, 4, (100,))

        # Protocol without n_clusters should auto-detect
        protocol = ClusteringProtocol(seed=42)
        metrics = protocol.evaluate(embeddings, labels)

        # Should work without error
        assert "nmi" in metrics
        assert "ari" in metrics
        assert "ami" in metrics

    def test_reproducibility(self) -> None:
        """Test that same seed produces same clustering."""
        embeddings = torch.randn(100, 10)
        labels = torch.randint(0, 5, (100,))

        protocol1 = ClusteringProtocol(seed=42, n_clusters=5)
        protocol2 = ClusteringProtocol(seed=42, n_clusters=5)

        metrics1 = protocol1.evaluate(embeddings, labels)
        metrics2 = protocol2.evaluate(embeddings, labels)

        # Same seed should give same results
        assert metrics1["nmi"] == pytest.approx(metrics2["nmi"], abs=1e-6)
        assert metrics1["ari"] == pytest.approx(metrics2["ari"], abs=1e-6)
        assert metrics1["ami"] == pytest.approx(metrics2["ami"], abs=1e-6)

        print("\n✓ Same seed produces identical clustering")

    def test_different_seeds(self) -> None:
        """Test that different seeds may produce different clustering."""
        embeddings = torch.randn(100, 10)
        labels = torch.randint(0, 5, (100,))

        protocol1 = ClusteringProtocol(seed=42, n_clusters=5)
        protocol2 = ClusteringProtocol(seed=43, n_clusters=5)

        metrics1 = protocol1.evaluate(embeddings, labels)
        metrics2 = protocol2.evaluate(embeddings, labels)

        # Different seeds may give different results
        # (though not guaranteed to be different)
        # Just check both run successfully
        assert "nmi" in metrics1
        assert "nmi" in metrics2

        print("\n✓ Different seeds produce valid clustering")

    def test_str_representation(self) -> None:
        """Test string representation."""
        protocol1 = ClusteringProtocol(seed=42, n_clusters=7)
        str_repr1 = str(protocol1)
        assert "ClusteringProtocol" in str_repr1
        assert "7" in str_repr1
        assert "42" in str_repr1

        protocol2 = ClusteringProtocol(seed=42)
        str_repr2 = str(protocol2)
        assert "ClusteringProtocol" in str_repr2
        assert "auto" in str_repr2
        assert "42" in str_repr2

        print("\nString representations:")
        print(f"  {str_repr1}")
        print(f"  {str_repr2}")

    def test_metrics_with_single_cluster_prediction(self) -> None:
        """Test metrics when all samples predicted to one cluster."""
        # Create diverse labels
        embeddings = torch.randn(50, 10)
        labels = torch.randint(0, 5, (50,))

        # With very tight init (all samples to one cluster)
        # K-Means might converge to degenerate solution
        # But it should still return valid metrics
        protocol = ClusteringProtocol(seed=42, n_clusters=1)
        metrics = protocol.evaluate(embeddings, labels)

        # Single cluster should give NMI = 0 (no information)
        assert metrics["nmi"] == pytest.approx(0.0, abs=0.01)

        print("\nSingle cluster metrics:")
        print(f"  NMI: {metrics['nmi']:.4f}")
        print(f"  ARI: {metrics['ari']:.4f}")
        print(f"  AMI: {metrics['ami']:.4f}")

    def test_high_dimensional_embeddings(self) -> None:
        """Test with high-dimensional embeddings."""
        # Test with 128-dim embeddings (typical for GNNs)
        embeddings = torch.randn(100, 128)
        labels = torch.randint(0, 5, (100,))

        protocol = ClusteringProtocol(seed=42, n_clusters=5)
        metrics = protocol.evaluate(embeddings, labels)

        # Should work without error
        assert "nmi" in metrics
        assert "ari" in metrics
        assert "ami" in metrics

        print("\nHigh-dimensional embeddings (128-dim):")
        print(f"  NMI: {metrics['nmi']:.4f}")
        print(f"  ARI: {metrics['ari']:.4f}")
        print(f"  AMI: {metrics['ami']:.4f}")
