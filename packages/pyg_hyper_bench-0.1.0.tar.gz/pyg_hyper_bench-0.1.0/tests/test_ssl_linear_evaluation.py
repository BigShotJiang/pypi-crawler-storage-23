"""Tests for SSLLinearEvaluationProtocol."""

from typing import cast

import pytest
import torch
from pyg_hyper_data.datasets import CoraCocitation

from pyg_hyper_bench.protocols import SSLLinearEvaluationProtocol


class TestSSLLinearEvaluationProtocol:
    """Test SSLLinearEvaluationProtocol."""

    def test_initialization(self) -> None:
        """Test protocol initialization."""
        protocol = SSLLinearEvaluationProtocol(
            train_ratio=0.6,
            val_ratio=0.2,
            test_ratio=0.2,
            classifier_type="logistic_regression",
            classifier_epochs=100,
            seed=42,
        )

        assert protocol.train_ratio == 0.6
        assert protocol.val_ratio == 0.2
        assert protocol.test_ratio == 0.2
        assert protocol.classifier_type == "logistic_regression"
        assert protocol.classifier_epochs == 100
        assert protocol.seed == 42

    def test_split_data(self) -> None:
        """Test data splitting."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol = SSLLinearEvaluationProtocol(seed=42)
        split = protocol.split_data(data)

        # Check required keys
        assert "data" in split
        assert "train_mask" in split
        assert "val_mask" in split
        assert "test_mask" in split

        # Check masks are boolean tensors
        assert cast("torch.Tensor", split["train_mask"]).dtype == torch.bool
        assert cast("torch.Tensor", split["val_mask"]).dtype == torch.bool
        assert cast("torch.Tensor", split["test_mask"]).dtype == torch.bool

        # Check no overlap
        train_mask = cast("torch.Tensor", split["train_mask"])
        val_mask = cast("torch.Tensor", split["val_mask"])
        test_mask = cast("torch.Tensor", split["test_mask"])

        assert not torch.any(train_mask & val_mask)
        assert not torch.any(train_mask & test_mask)
        assert not torch.any(val_mask & test_mask)

        print("\nData split:")
        print(f"  Train: {train_mask.sum()}")
        print(f"  Val: {val_mask.sum()}")
        print(f"  Test: {test_mask.sum()}")

    def test_evaluate_with_logreg(self) -> None:
        """Test evaluation with Logistic Regression."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol = SSLLinearEvaluationProtocol(
            classifier_type="logistic_regression",
            classifier_epochs=100,
            seed=42,
        )
        split = protocol.split_data(data)

        # Create random embeddings (simulating SSL output)
        torch.manual_seed(42)
        embeddings = torch.randn(int(data.num_nodes), 64)

        metrics = protocol.evaluate(
            embeddings=embeddings,
            labels=data.y,
            train_mask=cast("torch.Tensor", split["train_mask"]),
            val_mask=cast("torch.Tensor", split["val_mask"]),
            test_mask=cast("torch.Tensor", split["test_mask"]),
        )

        # Check required metrics
        assert "val_accuracy" in metrics
        assert "val_f1_macro" in metrics
        assert "val_f1_micro" in metrics
        assert "test_accuracy" in metrics
        assert "test_f1_macro" in metrics
        assert "test_f1_micro" in metrics

        # Check valid range
        for value in metrics.values():
            assert 0.0 <= value <= 1.0

        print("\nLogistic Regression metrics:")
        print(f"  Val Accuracy: {metrics['val_accuracy']:.4f}")
        print(f"  Test Accuracy: {metrics['test_accuracy']:.4f}")
        print(f"  Test F1-macro: {metrics['test_f1_macro']:.4f}")

    def test_evaluate_with_mlp(self) -> None:
        """Test evaluation with MLP classifier."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol = SSLLinearEvaluationProtocol(
            classifier_type="mlp",
            classifier_hidden_dim=64,
            classifier_epochs=50,  # Fewer epochs for testing
            classifier_lr=0.01,
            seed=42,
        )
        split = protocol.split_data(data)

        # Create random embeddings
        torch.manual_seed(42)
        embeddings = torch.randn(int(data.num_nodes), 64)

        metrics = protocol.evaluate(
            embeddings=embeddings,
            labels=data.y,
            train_mask=cast("torch.Tensor", split["train_mask"]),
            val_mask=cast("torch.Tensor", split["val_mask"]),
            test_mask=cast("torch.Tensor", split["test_mask"]),
        )

        # Check required metrics
        assert "val_accuracy" in metrics
        assert "test_accuracy" in metrics

        # Check valid range
        for value in metrics.values():
            assert 0.0 <= value <= 1.0

        print("\nMLP classifier metrics:")
        print(f"  Val Accuracy: {metrics['val_accuracy']:.4f}")
        print(f"  Test Accuracy: {metrics['test_accuracy']:.4f}")

    def test_embeddings_are_frozen(self) -> None:
        """Test that embeddings are properly frozen during evaluation."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol = SSLLinearEvaluationProtocol(
            classifier_type="mlp",
            classifier_epochs=10,
            seed=42,
        )
        split = protocol.split_data(data)

        # Create embeddings with gradients
        embeddings = torch.randn(int(data.num_nodes), 64, requires_grad=True)
        embeddings_copy = embeddings.clone().detach()

        _ = protocol.evaluate(
            embeddings=embeddings,
            labels=data.y,
            train_mask=cast("torch.Tensor", split["train_mask"]),
            val_mask=cast("torch.Tensor", split["val_mask"]),
            test_mask=cast("torch.Tensor", split["test_mask"]),
        )

        # Embeddings should not have been modified
        assert torch.allclose(embeddings.detach(), embeddings_copy)
        assert not embeddings.grad_fn  # No gradient tracking

        print("\n✓ Embeddings remain frozen during evaluation")

    def test_good_embeddings_vs_random(self) -> None:
        """Test that good embeddings perform better than random."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol = SSLLinearEvaluationProtocol(
            classifier_type="logistic_regression",
            classifier_epochs=100,
            seed=42,
        )
        split = protocol.split_data(data)

        # Random embeddings (poor quality)
        torch.manual_seed(42)
        random_embeddings = torch.randn(int(data.num_nodes), 64)

        # "Good" embeddings: use actual features (better than random)
        good_embeddings = (
            data.x[:, :64]
            if data.x.shape[1] >= 64
            else torch.cat(
                [data.x, torch.zeros(int(data.num_nodes), 64 - data.x.shape[1])], dim=1
            )
        )

        metrics_random = protocol.evaluate(
            embeddings=random_embeddings,
            labels=data.y,
            train_mask=cast("torch.Tensor", split["train_mask"]),
            val_mask=cast("torch.Tensor", split["val_mask"]),
            test_mask=cast("torch.Tensor", split["test_mask"]),
        )

        metrics_good = protocol.evaluate(
            embeddings=good_embeddings,
            labels=data.y,
            train_mask=cast("torch.Tensor", split["train_mask"]),
            val_mask=cast("torch.Tensor", split["val_mask"]),
            test_mask=cast("torch.Tensor", split["test_mask"]),
        )

        # Good embeddings should outperform random
        assert metrics_good["test_accuracy"] > metrics_random["test_accuracy"], (
            "Feature-based embeddings should outperform random"
        )

        print("\nEmbedding quality comparison:")
        print(f"  Random: {metrics_random['test_accuracy']:.4f}")
        print(f"  Features: {metrics_good['test_accuracy']:.4f}")
        print(
            f"  Improvement: {metrics_good['test_accuracy'] - metrics_random['test_accuracy']:.4f}"
        )

    def test_reproducibility(self) -> None:
        """Test that same seed produces same results."""
        dataset = CoraCocitation()
        data = dataset[0]

        # Same embeddings
        torch.manual_seed(42)
        embeddings = torch.randn(int(data.num_nodes), 64)

        protocol1 = SSLLinearEvaluationProtocol(
            classifier_type="logistic_regression", seed=42
        )
        protocol2 = SSLLinearEvaluationProtocol(
            classifier_type="logistic_regression", seed=42
        )

        split1 = protocol1.split_data(data)
        split2 = protocol2.split_data(data)

        metrics1 = protocol1.evaluate(
            embeddings=embeddings,
            labels=data.y,
            train_mask=split1["train_mask"],
            val_mask=split1["val_mask"],
            test_mask=split1["test_mask"],
        )

        metrics2 = protocol2.evaluate(
            embeddings=embeddings,
            labels=data.y,
            train_mask=split2["train_mask"],
            val_mask=split2["val_mask"],
            test_mask=split2["test_mask"],
        )

        # Same seed should give same results
        assert metrics1["test_accuracy"] == pytest.approx(
            metrics2["test_accuracy"], abs=1e-6
        )

        print("\n✓ Same seed produces identical results")

    def test_different_classifiers_comparable(self) -> None:
        """Test that different classifiers can be compared."""
        dataset = CoraCocitation()
        data = dataset[0]

        torch.manual_seed(42)
        embeddings = torch.randn(int(data.num_nodes), 64)

        protocol_logreg = SSLLinearEvaluationProtocol(
            classifier_type="logistic_regression",
            classifier_epochs=100,
            seed=42,
        )
        protocol_mlp = SSLLinearEvaluationProtocol(
            classifier_type="mlp",
            classifier_epochs=100,
            seed=42,
        )

        split = protocol_logreg.split_data(data)

        metrics_logreg = protocol_logreg.evaluate(
            embeddings=embeddings,
            labels=data.y,
            train_mask=cast("torch.Tensor", split["train_mask"]),
            val_mask=cast("torch.Tensor", split["val_mask"]),
            test_mask=cast("torch.Tensor", split["test_mask"]),
        )

        metrics_mlp = protocol_mlp.evaluate(
            embeddings=embeddings,
            labels=data.y,
            train_mask=cast("torch.Tensor", split["train_mask"]),
            val_mask=cast("torch.Tensor", split["val_mask"]),
            test_mask=cast("torch.Tensor", split["test_mask"]),
        )

        # Both should return same metric keys
        assert set(metrics_logreg.keys()) == set(metrics_mlp.keys())

        # Both should be in valid range
        for metrics in [metrics_logreg, metrics_mlp]:
            for value in metrics.values():
                assert 0.0 <= value <= 1.0

        print("\nClassifier comparison:")
        print(f"  LogReg: {metrics_logreg['test_accuracy']:.4f}")
        print(f"  MLP: {metrics_mlp['test_accuracy']:.4f}")

    def test_str_representation(self) -> None:
        """Test string representation."""
        protocol = SSLLinearEvaluationProtocol(
            classifier_type="logistic_regression",
            train_ratio=0.6,
            val_ratio=0.2,
            test_ratio=0.2,
            seed=42,
        )

        str_repr = str(protocol)
        assert "SSLLinearEvaluationProtocol" in str_repr
        assert "node_classification" in str_repr
        assert "logistic_regression" in str_repr
        assert "42" in str_repr

        print(f"\nString representation: {str_repr}")

    def test_stratified_split(self) -> None:
        """Test that stratified split maintains class balance."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol = SSLLinearEvaluationProtocol(stratified=True, seed=42)
        split = protocol.split_data(data)

        # Get class distribution in each split
        train_labels = data.y[cast("torch.Tensor", split["train_mask"])]
        val_labels = data.y[cast("torch.Tensor", split["val_mask"])]
        test_labels = data.y[cast("torch.Tensor", split["test_mask"])]

        # Check all classes present in each split (if enough samples)
        num_classes = int(data.y.max()) + 1
        for labels in [train_labels, val_labels, test_labels]:
            unique_classes = torch.unique(labels)
            # Most classes should be present
            assert len(unique_classes) >= num_classes * 0.7

        print("\nStratified split class distribution:")
        print(f"  Train: {len(torch.unique(train_labels))} classes")
        print(f"  Val: {len(torch.unique(val_labels))} classes")
        print(f"  Test: {len(torch.unique(test_labels))} classes")

    def test_hyperedge_prediction_split(self) -> None:
        """Test hyperedge prediction data splitting."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol = SSLLinearEvaluationProtocol(
            task="hyperedge_prediction",
            seed=42,
        )
        split = protocol.split_data(data)

        # Check required keys
        assert "train_data" in split
        assert "train_pos_edge" in split
        assert "train_neg_edge" in split
        assert "val_pos_edge" in split
        assert "val_neg_edge" in split
        assert "test_pos_edge" in split
        assert "test_neg_edge" in split

        # Check data types
        assert cast("torch.Tensor", split["train_pos_edge"]).size(0) == 2
        assert cast("torch.Tensor", split["val_pos_edge"]).size(0) == 2
        assert cast("torch.Tensor", split["test_pos_edge"]).size(0) == 2

        print("\nHyperedge prediction split:")
        print(f"  Train pos: {split['train_pos_edge'].size(1)}")
        print(f"  Val pos: {split['val_pos_edge'].size(1)}")
        print(f"  Test pos: {split['test_pos_edge'].size(1)}")

    def test_evaluate_hyperedge_prediction(self) -> None:
        """Test hyperedge prediction evaluation."""
        dataset = CoraCocitation()
        data = dataset[0]

        protocol = SSLLinearEvaluationProtocol(
            task="hyperedge_prediction",
            classifier_type="mlp",
            classifier_epochs=50,
            seed=42,
        )
        split = protocol.split_data(data)

        # Create random embeddings
        torch.manual_seed(42)
        embeddings = torch.randn(int(data.num_nodes), 64)

        metrics = protocol.evaluate(
            embeddings=embeddings,
            train_pos_edge=cast("torch.Tensor", split["train_pos_edge"]),
            train_neg_edge=cast("torch.Tensor", split["train_neg_edge"]),
            val_pos_edge=cast("torch.Tensor", split["val_pos_edge"]),
            val_neg_edge=cast("torch.Tensor", split["val_neg_edge"]),
            test_pos_edge=cast("torch.Tensor", split["test_pos_edge"]),
            test_neg_edge=cast("torch.Tensor", split["test_neg_edge"]),
        )

        # Check required metrics
        assert "val_auc" in metrics
        assert "val_ap" in metrics
        assert "test_auc" in metrics
        assert "test_ap" in metrics

        # Check valid range
        for value in metrics.values():
            assert 0.0 <= value <= 1.0

        print("\nHyperedge prediction metrics:")
        print(f"  Val AUC: {metrics['val_auc']:.4f}")
        print(f"  Test AUC: {metrics['test_auc']:.4f}")
        print(f"  Test AP: {metrics['test_ap']:.4f}")

    def test_task_parameter_validation(self) -> None:
        """Test that missing required parameters raise errors."""
        dataset = CoraCocitation()
        data = dataset[0]

        # Node classification without labels should fail
        protocol_node = SSLLinearEvaluationProtocol(task="node_classification")
        embeddings = torch.randn(int(data.num_nodes), 64)

        with pytest.raises(ValueError, match="labels and train_mask are required"):
            _ = protocol_node.evaluate(embeddings=embeddings)

        # Hyperedge prediction without edges should fail
        protocol_edge = SSLLinearEvaluationProtocol(task="hyperedge_prediction")

        with pytest.raises(ValueError, match="edge samples are required"):
            _ = protocol_edge.evaluate(embeddings=embeddings)

        print("\n✓ Parameter validation works correctly")
