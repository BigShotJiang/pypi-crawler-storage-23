"""Integration tests with actual datasets and models."""

import pytest
import torch
from pyg_hyper_data.datasets import CoraCocitation
from torch import Tensor, nn

from pyg_hyper_bench.evaluators import MultiRunEvaluator, SingleRunEvaluator
from pyg_hyper_bench.protocols import NodeClassificationProtocol


class SimpleHypergraphGNN(nn.Module):
    """Simple hypergraph GNN for testing.

    Uses a basic architecture:
    - Linear layer for node feature transformation
    - Mean aggregation over hyperedges
    - Linear layer for classification
    """

    def __init__(self, in_channels: int, hidden_channels: int, out_channels: int):
        """Initialize model.

        Args:
            in_channels: Input feature dimension
            hidden_channels: Hidden layer dimension
            out_channels: Number of output classes
        """
        super().__init__()
        self.lin1 = nn.Linear(in_channels, hidden_channels)
        self.lin2 = nn.Linear(hidden_channels, out_channels)
        self.activation = nn.ReLU()
        self.dropout = nn.Dropout(0.5)

    def forward(self, x: Tensor, hyperedge_index: Tensor) -> Tensor:
        """Forward pass.

        Args:
            x: Node features [num_nodes, in_channels]
            hyperedge_index: Hyperedge indices [2, num_edges]

        Returns:
            Output logits [num_nodes, out_channels]
        """
        # Simple message passing
        h = self.lin1(x)
        h = self.activation(h)
        h = self.dropout(h)

        # Hyperedge aggregation (mean pooling)
        if hyperedge_index.numel() > 0:
            node_idx = hyperedge_index[0]
            edge_idx = hyperedge_index[1]
            num_hyperedges = edge_idx.max().item() + 1

            # Aggregate node features to hyperedges
            edge_feat = torch.zeros(
                num_hyperedges, h.size(1), device=h.device, dtype=h.dtype
            )
            edge_count = torch.zeros(num_hyperedges, device=h.device, dtype=h.dtype)

            edge_feat.index_add_(0, edge_idx, h[node_idx])
            edge_count.index_add_(
                0, edge_idx, torch.ones(edge_idx.size(0), device=h.device)
            )

            edge_feat = edge_feat / edge_count.unsqueeze(1).clamp(min=1)

            # Aggregate hyperedge features back to nodes
            h_new = torch.zeros_like(h)
            node_count = torch.zeros(h.size(0), device=h.device, dtype=h.dtype)

            h_new.index_add_(0, node_idx, edge_feat[edge_idx])
            node_count.index_add_(
                0, node_idx, torch.ones(node_idx.size(0), device=h.device)
            )

            h = h_new / node_count.unsqueeze(1).clamp(min=1)

        # Classification
        return self.lin2(h)


class TestSingleRunIntegration:
    """Integration tests for SingleRunEvaluator with real data and model."""

    def test_single_run_with_training(self) -> None:
        """Test single run evaluation with actual training."""
        # Setup
        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol(
            split_type="transductive", stratified=True, seed=42
        )
        evaluator = SingleRunEvaluator(dataset, protocol, device="cpu")

        # Get data and split
        split = evaluator.get_split()
        data = split["data"]
        train_mask = split["train_mask"]
        val_mask = split["val_mask"]
        test_mask = split["test_mask"]

        # Create model
        model = SimpleHypergraphGNN(
            in_channels=dataset.num_node_features,
            hidden_channels=64,
            out_channels=dataset.num_classes,
        )

        # Training setup
        optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=5e-4)
        criterion = nn.CrossEntropyLoss()

        # Train for a few epochs
        model.train()
        for _epoch in range(10):
            optimizer.zero_grad()
            out = model(data.x, data.hyperedge_index)
            loss = criterion(out[train_mask], data.y[train_mask])
            loss.backward()
            optimizer.step()

        # Evaluate
        model.eval()
        with torch.no_grad():
            predictions = model(data.x, data.hyperedge_index)

            # Evaluate on all splits
            train_metrics = evaluator.evaluate(
                predictions[train_mask], data.y[train_mask], split="train"
            )
            val_metrics = evaluator.evaluate(
                predictions[val_mask], data.y[val_mask], split="val"
            )
            test_metrics = evaluator.evaluate(
                predictions[test_mask], data.y[test_mask], split="test"
            )

        # Assertions - model should perform better than random (1/7 ≈ 0.14)
        assert train_metrics["accuracy"] > 0.2
        assert val_metrics["accuracy"] > 0.1
        assert test_metrics["accuracy"] > 0.1

        # Metrics should be in valid range
        for metrics in [train_metrics, val_metrics, test_metrics]:
            assert 0.0 <= metrics["accuracy"] <= 1.0
            assert 0.0 <= metrics["f1_macro"] <= 1.0
            assert 0.0 <= metrics["f1_micro"] <= 1.0

        # Training accuracy should be higher than test (overfitting check)
        assert train_metrics["accuracy"] >= test_metrics["accuracy"]

        print("\nSingle Run Results:")
        print(f"  Train: acc={train_metrics['accuracy']:.4f}")
        print(f"  Val:   acc={val_metrics['accuracy']:.4f}")
        print(f"  Test:  acc={test_metrics['accuracy']:.4f}")


class TestMultiRunIntegration:
    """Integration tests for MultiRunEvaluator with real data and model."""

    def test_multi_run_with_training(self) -> None:
        """Test multi-run evaluation with actual training."""
        # Setup
        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol(
            split_type="transductive", stratified=True, seed=42
        )
        evaluator = MultiRunEvaluator(
            dataset=dataset, protocol=protocol, n_runs=3, device="cpu", verbose=True
        )

        # Model factory
        def model_fn(seed: int) -> nn.Module:
            torch.manual_seed(seed)
            return SimpleHypergraphGNN(
                in_channels=dataset.num_node_features,
                hidden_channels=64,
                out_channels=dataset.num_classes,
            )

        # Training function
        def train_fn(
            model: nn.Module,
            data: object,
            train_mask: Tensor | None = None,
            val_mask: Tensor | None = None,
        ) -> nn.Module:
            optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=5e-4)
            criterion = nn.CrossEntropyLoss()

            model.train()
            for _epoch in range(10):
                optimizer.zero_grad()
                out = model(data.x, data.hyperedge_index)
                loss = criterion(out[train_mask], data.y[train_mask])
                loss.backward()
                optimizer.step()

            return model

        # Run evaluation
        results = evaluator.run_evaluation(
            model_fn=model_fn, train_fn=train_fn, splits=["val", "test"]
        )

        # Assertions
        assert "val" in results
        assert "test" in results

        # Check result structure
        val_result = results["val"]
        test_result = results["test"]

        assert val_result.n_runs == 3
        assert test_result.n_runs == 3

        # Check metrics exist
        for metric in ["accuracy", "f1_macro", "f1_micro"]:
            assert metric in val_result.means
            assert metric in val_result.stds
            assert metric in val_result.confidence_intervals

            assert metric in test_result.means
            assert metric in test_result.stds
            assert metric in test_result.confidence_intervals

        # Metrics should be better than random
        assert test_result.means["accuracy"] > 0.1
        assert val_result.means["accuracy"] > 0.1

        # Standard deviation should be positive (different runs give different results)
        assert test_result.stds["accuracy"] >= 0.0
        assert val_result.stds["accuracy"] >= 0.0

        # Confidence intervals should be valid
        for metric in ["accuracy", "f1_macro", "f1_micro"]:
            ci_lower, ci_upper = test_result.confidence_intervals[metric]
            assert ci_lower <= test_result.means[metric] <= ci_upper
            assert ci_lower >= 0.0
            assert ci_upper <= 1.0

        # Print summary
        print(f"\n{test_result.summary_table(split='test')}")
        print(f"\n{val_result.summary_table(split='val')}")


class TestProtocolVariations:
    """Test different protocol configurations."""

    @pytest.mark.skip(reason="inductive_hypergraph_split has issues in pyg-hyper-data")
    def test_transductive_vs_inductive(self) -> None:
        """Test both transductive and inductive settings."""
        dataset = CoraCocitation()

        # Transductive
        protocol_trans = NodeClassificationProtocol(
            split_type="transductive", stratified=True, seed=42
        )
        split_trans = protocol_trans.split_data(dataset[0])

        assert "train_mask" in split_trans
        assert "val_mask" in split_trans
        assert "test_mask" in split_trans
        assert "data" in split_trans

        # Check masks are boolean tensors
        assert split_trans["train_mask"].dtype == torch.bool
        assert split_trans["val_mask"].dtype == torch.bool
        assert split_trans["test_mask"].dtype == torch.bool

        # Check no overlap
        assert not (split_trans["train_mask"] & split_trans["val_mask"]).any()
        assert not (split_trans["train_mask"] & split_trans["test_mask"]).any()
        assert not (split_trans["val_mask"] & split_trans["test_mask"]).any()

        # Check coverage
        total = (
            split_trans["train_mask"]
            | split_trans["val_mask"]
            | split_trans["test_mask"]
        )
        assert total.all()

        print("\nTransductive split:")
        print(f"  Train: {split_trans['train_mask'].sum()}")
        print(f"  Val:   {split_trans['val_mask'].sum()}")
        print(f"  Test:  {split_trans['test_mask'].sum()}")

        # Inductive
        protocol_induc = NodeClassificationProtocol(
            split_type="inductive", stratified=False, seed=42
        )
        split_induc = protocol_induc.split_data(dataset[0])

        assert "train_data" in split_induc
        assert "val_data" in split_induc
        assert "test_data" in split_induc

        # Check data objects
        train_data = split_induc["train_data"]
        val_data = split_induc["val_data"]
        test_data = split_induc["test_data"]

        # All should have hypergraph structure
        assert hasattr(train_data, "hyperedge_index")
        assert hasattr(val_data, "hyperedge_index")
        assert hasattr(test_data, "hyperedge_index")

        print("\nInductive split:")
        print(f"  Train: {train_data.num_nodes} nodes")
        print(f"  Val:   {val_data.num_nodes} nodes")
        print(f"  Test:  {test_data.num_nodes} nodes")

    def test_different_split_ratios(self) -> None:
        """Test different split ratios."""
        dataset = CoraCocitation()
        data = dataset[0]

        # Test 50/25/25 split (HyperGCN style)
        protocol = NodeClassificationProtocol(
            train_ratio=0.5, val_ratio=0.25, test_ratio=0.25, seed=42
        )
        split = protocol.split_data(data)

        train_count = split["train_mask"].sum().item()
        val_count = split["val_mask"].sum().item()
        test_count = split["test_mask"].sum().item()
        total = train_count + val_count + test_count

        # Check ratios (within 1% tolerance)
        assert abs(train_count / total - 0.5) < 0.01
        assert abs(val_count / total - 0.25) < 0.01
        assert abs(test_count / total - 0.25) < 0.01

        print("\n50/25/25 split:")
        print(f"  Train: {train_count} ({train_count / total:.1%})")
        print(f"  Val:   {val_count} ({val_count / total:.1%})")
        print(f"  Test:  {test_count} ({test_count / total:.1%})")

    def test_stratified_vs_random(self) -> None:
        """Test stratified vs random splitting."""
        dataset = CoraCocitation()
        data = dataset[0]

        # Stratified
        protocol_strat = NodeClassificationProtocol(
            stratified=True, seed=42, split_type="transductive"
        )
        split_strat = protocol_strat.split_data(data)

        # Random
        protocol_rand = NodeClassificationProtocol(
            stratified=False, seed=42, split_type="transductive"
        )
        split_rand = protocol_rand.split_data(data)

        # Both should have approximately same total size (within a few nodes)
        strat_count = split_strat["train_mask"].sum().item()
        rand_count = split_rand["train_mask"].sum().item()
        assert abs(strat_count - rand_count) < 10  # Within 10 nodes is acceptable

        # Class distribution in stratified should be more balanced
        train_labels_strat = data.y[split_strat["train_mask"]]
        train_labels_rand = data.y[split_rand["train_mask"]]

        # Count classes
        num_classes = dataset.num_classes
        strat_dist = torch.bincount(train_labels_strat, minlength=num_classes)
        rand_dist = torch.bincount(train_labels_rand, minlength=num_classes)

        print("\nClass distribution in train split:")
        print(f"  Stratified: {strat_dist.tolist()}")
        print(f"  Random:     {rand_dist.tolist()}")

        # Stratified should have more balanced distribution (lower std)
        strat_std = strat_dist.float().std()
        rand_std = rand_dist.float().std()
        print(f"  Stratified std: {strat_std:.2f}")
        print(f"  Random std:     {rand_std:.2f}")


class TestReproducibility:
    """Test reproducibility with seeds."""

    def test_same_seed_same_results(self) -> None:
        """Test that same seed produces same results."""
        dataset = CoraCocitation()
        protocol = NodeClassificationProtocol(seed=42)

        # Run twice with same seed
        split1 = protocol.split_data(dataset[0])
        split2 = protocol.split_data(dataset[0])

        # Should be identical
        assert torch.equal(split1["train_mask"], split2["train_mask"])
        assert torch.equal(split1["val_mask"], split2["val_mask"])
        assert torch.equal(split1["test_mask"], split2["test_mask"])

        print("\n✓ Same seed produces identical splits")

    def test_different_seed_different_results(self) -> None:
        """Test that different seeds produce different results."""
        dataset = CoraCocitation()

        protocol1 = NodeClassificationProtocol(seed=42)
        protocol2 = NodeClassificationProtocol(seed=43)

        split1 = protocol1.split_data(dataset[0])
        split2 = protocol2.split_data(dataset[0])

        # Should be different
        assert not torch.equal(split1["train_mask"], split2["train_mask"])

        # But same size
        assert split1["train_mask"].sum() == split2["train_mask"].sum()

        print("\n✓ Different seeds produce different splits (same size)")
