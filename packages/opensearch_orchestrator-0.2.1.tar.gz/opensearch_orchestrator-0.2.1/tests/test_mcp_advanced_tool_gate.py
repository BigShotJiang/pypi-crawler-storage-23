import asyncio

import pytest

import opensearch_orchestrator.mcp_server as mcp_server


def test_advanced_tools_disabled_by_default(monkeypatch) -> None:
    monkeypatch.delenv(mcp_server.ADVANCED_TOOLS_ENV, raising=False)
    assert not mcp_server._advanced_tools_enabled()


@pytest.mark.parametrize("value", ["1", "true", "yes", "on", "TRUE", " Yes "])
def test_advanced_tools_enabled_values(monkeypatch, value: str) -> None:
    monkeypatch.setenv(mcp_server.ADVANCED_TOOLS_ENV, value)
    assert mcp_server._advanced_tools_enabled()


@pytest.mark.parametrize("value", ["0", "false", "no", "off", "", "random"])
def test_advanced_tools_disabled_values(monkeypatch, value: str) -> None:
    monkeypatch.setenv(mcp_server.ADVANCED_TOOLS_ENV, value)
    assert not mcp_server._advanced_tools_enabled()


def test_default_tool_surface_is_workflow_only() -> None:
    tool_names = {tool.name for tool in asyncio.run(mcp_server.mcp.list_tools())}
    assert tool_names == {
        "cleanup",
        "execute_plan",
        "finalize_plan",
        "load_sample",
        "refine_plan",
        "retry_execution",
        "set_plan_from_planning_complete",
        "set_preferences",
        "start_planning",
    }
