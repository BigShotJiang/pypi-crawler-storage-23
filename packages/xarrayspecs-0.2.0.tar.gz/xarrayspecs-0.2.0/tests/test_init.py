# dependencies
import xarrayspecs as xs


def test_namespace() -> None:
    # submodules
    xs.api
    xs.spec
    # aliases
    xs.Dims
    xs.Dtype
    xs.asdataarray
    xs.asdataset
    xs.asdatatree
    xs.attrs
    xs.dims
    xs.dtype
    xs.name
    xs.node
    xs.parse
    xs.use
