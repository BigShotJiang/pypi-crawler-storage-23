from . import aqi_cn, aqi_usa

__all__ = ["aqi_cn", "aqi_usa"]
