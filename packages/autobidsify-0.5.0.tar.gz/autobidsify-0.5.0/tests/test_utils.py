"""Tests for utils module."""

import unittest
import tempfile
import json
import yaml
from pathlib import Path
import shutil

from autobidsify.utils import (
    ensure_dir,
    write_json,
    read_json,
    write_yaml,
    read_yaml,
    write_text,
    read_text,
    copy_file,
    copy_tree,
    list_all_files,
    sha1_head,
    sha256_full,
)


class TestEnsureDir(unittest.TestCase):
    """Tests for ensure_dir function."""

    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_create_single_directory(self):
        """Test creating a single directory."""
        new_dir = self.temp_dir / "new_folder"
        ensure_dir(new_dir)
        self.assertTrue(new_dir.exists())
        self.assertTrue(new_dir.is_dir())

    def test_create_nested_directories(self):
        """Test creating nested directories."""
        nested_dir = self.temp_dir / "level1" / "level2" / "level3"
        ensure_dir(nested_dir)
        self.assertTrue(nested_dir.exists())

    def test_existing_directory(self):
        """Test that existing directory doesn't raise error."""
        existing_dir = self.temp_dir / "existing"
        existing_dir.mkdir()
        # Should not raise
        ensure_dir(existing_dir)
        self.assertTrue(existing_dir.exists())


class TestJsonIO(unittest.TestCase):
    """Tests for JSON read/write functions."""

    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_write_and_read_json(self):
        """Test writing and reading JSON data."""
        data = {"name": "test", "value": 42, "nested": {"key": "value"}}
        json_path = self.temp_dir / "test.json"
        
        write_json(json_path, data)
        self.assertTrue(json_path.exists())
        
        loaded = read_json(json_path)
        self.assertEqual(loaded, data)

    def test_json_unicode(self):
        """Test JSON with unicode characters."""
        data = {"name": "测试", "emoji": "🧠", "special": "äöü"}
        json_path = self.temp_dir / "unicode.json"
        
        write_json(json_path, data)
        loaded = read_json(json_path)
        self.assertEqual(loaded, data)

    def test_json_creates_parent_dirs(self):
        """Test that write_json creates parent directories."""
        json_path = self.temp_dir / "nested" / "deep" / "test.json"
        write_json(json_path, {"key": "value"})
        self.assertTrue(json_path.exists())

    def test_json_list_data(self):
        """Test JSON with list data."""
        data = [1, 2, 3, {"nested": True}]
        json_path = self.temp_dir / "list.json"
        
        write_json(json_path, data)
        loaded = read_json(json_path)
        self.assertEqual(loaded, data)


class TestYamlIO(unittest.TestCase):
    """Tests for YAML read/write functions."""

    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_write_and_read_yaml(self):
        """Test writing and reading YAML data."""
        data = {
            "subjects": {"count": 10, "labels": ["01", "02", "03"]},
            "mappings": [{"modality": "mri", "format_ready": True}]
        }
        yaml_path = self.temp_dir / "test.yaml"
        
        write_yaml(yaml_path, data)
        self.assertTrue(yaml_path.exists())
        
        loaded = read_yaml(yaml_path)
        self.assertEqual(loaded, data)

    def test_yaml_unicode(self):
        """Test YAML with unicode characters."""
        data = {"description": "北京大学数据集"}
        yaml_path = self.temp_dir / "unicode.yaml"
        
        write_yaml(yaml_path, data)
        loaded = read_yaml(yaml_path)
        self.assertEqual(loaded, data)


class TestTextIO(unittest.TestCase):
    """Tests for text read/write functions."""

    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_write_and_read_text(self):
        """Test writing and reading text."""
        content = "Hello, World!\nLine 2\nLine 3"
        text_path = self.temp_dir / "test.txt"
        
        write_text(text_path, content)
        self.assertTrue(text_path.exists())
        
        loaded = read_text(text_path)
        self.assertEqual(loaded, content)

    def test_text_unicode(self):
        """Test text with unicode."""
        content = "日本語テスト\n中文测试\nEmoji: 🧠🔬"
        text_path = self.temp_dir / "unicode.txt"
        
        write_text(text_path, content)
        loaded = read_text(text_path)
        self.assertEqual(loaded, content)


class TestFileCopy(unittest.TestCase):
    """Tests for file copy functions."""

    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_copy_file(self):
        """Test copying a single file."""
        src = self.temp_dir / "source.txt"
        dst = self.temp_dir / "dest.txt"
        
        write_text(src, "test content")
        copy_file(src, dst)
        
        self.assertTrue(dst.exists())
        self.assertEqual(read_text(dst), "test content")

    def test_copy_file_creates_parent(self):
        """Test that copy_file creates parent directories."""
        src = self.temp_dir / "source.txt"
        dst = self.temp_dir / "nested" / "deep" / "dest.txt"
        
        write_text(src, "test content")
        copy_file(src, dst)
        
        self.assertTrue(dst.exists())

    def test_copy_tree(self):
        """Test copying a directory tree."""
        src_dir = self.temp_dir / "source_tree"
        src_dir.mkdir()
        (src_dir / "file1.txt").write_text("content1")
        (src_dir / "subdir").mkdir()
        (src_dir / "subdir" / "file2.txt").write_text("content2")
        
        dst_dir = self.temp_dir / "dest_tree"
        copy_tree(src_dir, dst_dir)
        
        self.assertTrue((dst_dir / "file1.txt").exists())
        self.assertTrue((dst_dir / "subdir" / "file2.txt").exists())


class TestListAllFiles(unittest.TestCase):
    """Tests for list_all_files function."""

    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_list_files_recursive(self):
        """Test listing files recursively."""
        # Create test structure
        (self.temp_dir / "file1.txt").write_text("1")
        (self.temp_dir / "subdir").mkdir()
        (self.temp_dir / "subdir" / "file2.txt").write_text("2")
        (self.temp_dir / "subdir" / "deep").mkdir()
        (self.temp_dir / "subdir" / "deep" / "file3.txt").write_text("3")
        
        files = list_all_files(self.temp_dir)
        
        self.assertEqual(len(files), 3)
        filenames = [f.name for f in files]
        self.assertIn("file1.txt", filenames)
        self.assertIn("file2.txt", filenames)
        self.assertIn("file3.txt", filenames)

    def test_skip_hidden_files(self):
        """Test that hidden files are skipped."""
        (self.temp_dir / "visible.txt").write_text("1")
        (self.temp_dir / ".hidden").write_text("2")
        
        files = list_all_files(self.temp_dir)
        
        self.assertEqual(len(files), 1)
        self.assertEqual(files[0].name, "visible.txt")

    def test_empty_directory(self):
        """Test listing empty directory."""
        files = list_all_files(self.temp_dir)
        self.assertEqual(files, [])


class TestHashFunctions(unittest.TestCase):
    """Tests for hash functions."""

    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())

    def tearDown(self):
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_sha1_head(self):
        """Test SHA1 head hash."""
        test_file = self.temp_dir / "test.bin"
        test_file.write_bytes(b"test content for hashing")
        
        hash_result = sha1_head(test_file)
        
        self.assertIsInstance(hash_result, str)
        self.assertEqual(len(hash_result), 16)

    def test_sha1_head_nonexistent(self):
        """Test SHA1 head with nonexistent file."""
        result = sha1_head(self.temp_dir / "nonexistent.txt")
        self.assertEqual(result, "error")

    def test_sha256_full(self):
        """Test SHA256 full hash."""
        hash1 = sha256_full("test string")
        hash2 = sha256_full("test string")
        hash3 = sha256_full("different string")
        
        self.assertEqual(hash1, hash2)
        self.assertNotEqual(hash1, hash3)
        self.assertEqual(len(hash1), 64)


if __name__ == '__main__':
    unittest.main()