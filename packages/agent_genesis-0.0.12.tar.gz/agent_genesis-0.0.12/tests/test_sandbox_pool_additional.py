from __future__ import annotations

import sys
from types import SimpleNamespace

import pytest

import evaluation.sandbox_pool as sp


class _FakeSemaphore:
    def __init__(self, acquired: bool = True) -> None:
        self.acquired = acquired
        self.released = 0

    def acquire(self, timeout: int = 0) -> bool:
        _ = timeout
        return self.acquired

    def release(self) -> None:
        self.released += 1


class _Sandbox:
    def __init__(self, sid: str = "sb-1") -> None:
        self.id = sid
        self.closed = False
        self.killed = False

    def close(self) -> None:
        self.closed = True

    def kill(self) -> None:
        self.killed = True


def setup_function() -> None:
    sp.SandboxManager._instance = None


def test_get_instance_singleton(monkeypatch) -> None:
    monkeypatch.setattr(sp, "get_config", lambda: SimpleNamespace(max_workers=1))
    s1 = sp.SandboxManager.get_instance()
    s2 = sp.SandboxManager.get_instance()
    assert s1 is s2


def test_create_fallback_typeerror_and_runtime_error(monkeypatch) -> None:
    monkeypatch.setattr(sp, "get_config", lambda: SimpleNamespace(max_workers=2))
    mgr = sp.SandboxManager()
    mgr._semaphore = _FakeSemaphore(acquired=True)

    calls = {"n": 0}
    sb = _Sandbox("sb-fallback")

    class _SandboxCls:
        @staticmethod
        def create(*args, **kwargs):
            calls["n"] += 1
            if calls["n"] == 1:
                raise TypeError("unsupported kwargs")
            return sb

    monkeypatch.setitem(sys.modules, "ppio_sandbox.code_interpreter", SimpleNamespace(Sandbox=_SandboxCls))
    out = mgr.create(sandbox_timeout=10, template_id="tpl", cpu_count=2, memory_mb=256)
    assert out is sb
    assert mgr.get_stats()["total_created"] == 1

    # create generic failure -> RuntimeError and semaphore release
    mgr2 = sp.SandboxManager()
    mgr2._semaphore = _FakeSemaphore(acquired=True)

    class _SandboxFail:
        @staticmethod
        def create(*args, **kwargs):
            raise RuntimeError("create fail")

    monkeypatch.setitem(sys.modules, "ppio_sandbox.code_interpreter", SimpleNamespace(Sandbox=_SandboxFail))
    with pytest.raises(RuntimeError, match="Failed to create sandbox"):
        mgr2.create(sandbox_timeout=10)
    assert mgr2._semaphore.released == 1


def test_destroy_kill_branch_and_shutdown(monkeypatch) -> None:
    monkeypatch.setattr(sp, "get_config", lambda: SimpleNamespace(max_workers=2))
    mgr = sp.SandboxManager()
    mgr._semaphore = _FakeSemaphore(acquired=True)

    sb_close = _Sandbox("sb-close")
    sb_kill_only = SimpleNamespace(id="sb-kill", kill=lambda: None)
    mgr._active_sandboxes = {"sb-close": sb_close, "sb-kill": sb_kill_only}
    mgr._stats["current_active"] = 2

    mgr.destroy(sb_kill_only)
    assert mgr._stats["total_destroyed"] >= 1
    assert mgr._semaphore.released >= 1

    # shutdown catches destroy exceptions
    bad = _Sandbox("bad")
    mgr._active_sandboxes["bad"] = bad
    original_destroy = mgr.destroy

    def _destroy_raise(sandbox):
        if getattr(sandbox, "id", "") == "bad":
            raise RuntimeError("boom")
        return original_destroy(sandbox)

    mgr.destroy = _destroy_raise  # type: ignore[method-assign]
    mgr.shutdown()

