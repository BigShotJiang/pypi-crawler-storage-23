# agent-genesis

`agent-genesis` is an evaluation SDK package for dual-sandbox execution, protocol routing, and submission orchestration.

Import path supports both `agent_genesis` and `evaluation` for compatibility.

## Install

```bash
pip install agent-genesis
```

## Build

```bash
python -m pip install --upgrade build twine
python -m build
python -m twine check dist/*
```

## TestPyPI First (Recommended)

Upload to TestPyPI:

```bash
python -m twine upload --repository testpypi dist/*
```

Install from TestPyPI:

```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ agent-genesis
```

## Publish to PyPI

After TestPyPI verification:

```bash
python -m twine upload dist/*
```

## License

Apache License 2.0
