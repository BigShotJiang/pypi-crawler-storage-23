# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2026/1/11 15:03
# Description:

from silars.alphalens.backtest import backtest
from silars.transformer import Function
from silars.alphalens import FactorStrategy
import polars as pl

def run():
    data = pl.read_csv("../data/target_weight.csv")
    backtest.fit(data)


if __name__ == '__main__':
    run()