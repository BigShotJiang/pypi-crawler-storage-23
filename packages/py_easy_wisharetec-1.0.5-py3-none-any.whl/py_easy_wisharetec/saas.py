#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
Wisharetec SaaS 系统交互模块

该模块提供了与 Wisharetec SaaS 系统交互的核心功能，包括：
- 认证登录
- 数据查询
- 缓存管理
- 各种业务数据的获取和处理

主要类：
- QueryConditionFormatter: 查询条件格式化类
- Saas: 与 Wisharetec SaaS 系统交互的主要类
"""
import dataclasses
import hashlib
from typing import Optional, Union

import diskcache
import httpx
import redis
from py_easy_httpx.request import AsyncHttpxRequest
from py_easy_httpx.response import json_paser, async_json_paser


@dataclasses.dataclass
class QueryConditionFormatter:
    """
    查询条件格式化类

    用于构建和格式化与 Wisharetec SaaS 系统交互的查询条件。
    该类是不可变的（frozen=True），一旦创建就不能修改其属性。

    :param conditions: 查询条件字典，默认为空字典
    :param count: 是否返回总记录数，默认为 True
    :param last: 是否返回最后一页，默认为 True
    :param orderBy: 排序字段列表，默认为空列表
    :param pageNum: 页码，默认为 1
    :param pageSize: 每页记录数，默认为 50
    """
    conditions: dict = dataclasses.field(default_factory=dict)
    """查询条件字典，默认为空字典"""
    count: bool = True
    """是否返回总记录数，默认为 True"""
    last: bool = True
    """是否返回最后一页，默认为 True"""
    orderBy: list = dataclasses.field(default_factory=list)
    """排序字段列表，默认为空列表"""
    pageNum: int = 1
    """页码，默认为 1"""
    pageSize: int = 50
    """每页记录数，默认为 50"""

    def to_dict(self) -> dict:
        """将查询条件格式化为字典"""
        return dataclasses.asdict(self)


class Saas(AsyncHttpxRequest):
    """
    Wisharetec SaaS 系统交互类

    用于与 Wisharetec SaaS 系统进行交互，提供了认证、数据查询等功能。
    继承自 AsyncHttpxRequest，支持同步和异步请求。

    :param base_url: SaaS 系统基础 URL，默认为 "https://saas.wisharetec.com/"
    :param account: 登录账号
    :param password: 登录密码
    :param cache_config: 缓存配置字典
    :param client_kwargs: 客户端配置字典
    """

    def __init__(
            self,
            base_url: Optional[str] = "https://saas.wisharetec.com/",
            account: Optional[str] = None,
            password: Optional[str] = None,
            cache_config: Optional[dict] = None,
            client_kwargs: Optional[dict] = None
    ):
        """
        初始化 Saas 实例

        :param base_url: SaaS 系统基础 URL，默认为 "https://saas.wisharetec.com/"
        :param account: 登录账号
        :param password: 登录密码
        :param cache_config: 缓存配置字典
        :param client_kwargs: 客户端配置字典
        """
        # 处理基础 URL
        self.base_url = base_url or "https://saas.wisharetec.com/"
        self.base_url = self.base_url[:-1] if self.base_url.endswith("/") else self.base_url

        # 处理账号密码
        self.account = account or ""
        self.password = password or ""

        # 处理缓存配置
        self.cache_config = cache_config or {}
        self.cache_config.setdefault("key", f"py_easy_wisharetec_saas_{self.account}")
        self.cache_config.setdefault("expire", 86400 * 180)  # 缓存过期时间，默认180天

        # 处理客户端配置
        self.client_kwargs = client_kwargs or {}
        self.client_kwargs.setdefault("base_url", self.base_url)
        self.client_kwargs.setdefault("timeout", 600)
        headers = self.client_kwargs.get("headers", {})
        headers.setdefault("client", "co-pc")
        self.client_kwargs["headers"] = headers

        # 初始化认证令牌
        self.token = ""

    @json_paser(path_expr="$")
    def request(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        同步请求方法

        :param client: 可选的同步客户端实例
        :param **kwargs: 传递给client.request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)  # 认证令牌
        kwargs["headers"] = headers

        # 处理客户端实例
        if not isinstance(client, httpx.Client):
            with self.client() as client:
                return client.request(**kwargs)
        return client.request(**kwargs)

    @async_json_paser(path_expr="$")
    async def async_request(self, client: Optional[httpx.AsyncClient] = None, **kwargs) -> httpx.Response:
        """
        异步请求方法

        :param client: 可选的异步客户端实例
        :param **kwargs: 传递给client.request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)  # 认证令牌
        kwargs["headers"] = headers

        # 处理客户端实例
        if not isinstance(client, httpx.AsyncClient):
            async with self.async_client() as client:
                return await client.request(**kwargs)
        return await client.request(**kwargs)

    @json_paser(
        validator={
            "type": "array",
            "minItems": 1,
        },
        path_expr="$"
    )
    def query_manage_tree(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        查询管理树

        :param client: 可选的同步客户端实例
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求参数
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", "/api/space/space/manageTree")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)  # 认证令牌
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
            "properties": {
                # "tenantSimpleInfoVList": {"type": "array", "minItems": 1},
                "userLoginV": {
                    "type": "object",
                    "properties": {
                        "userInfoV": {
                            "type": "object",
                            "properties": {
                                "id": {"type": "string", "minLength": 1}
                            },
                            "required": ["id"]
                        },
                    },
                    "required": ["userInfoV"]
                }
            },
            "required": ["userLoginV"],
        }
    )
    def login(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        登录 SaaS 系统

        :param client: 可选的同步客户端实例
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求参数
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", "/api/user/loginInteractive")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("client", "co-pc")
        kwargs["headers"] = headers

        # 设置请求体
        json_data = kwargs.get("json", {})
        json_data.setdefault("account", self.account)
        json_data.setdefault("password", hashlib.md5(self.password.encode("utf-8")).hexdigest())
        kwargs["json"] = json_data

        # 发送请求
        if not isinstance(client, httpx.Client):
            with self.client() as client:
                response = client.request(**kwargs)
        else:
            response = client.request(**kwargs)

        # 处理响应
        if response.is_success:
            self.token = response.headers.get("authorization", "")

        return response

    def refresh_login(
            self,
            client: Optional[httpx.Client] = None,
            login_kwargs: Optional[dict] = None,
            query_manage_tree_kwargs: Optional[dict] = None,
    ) -> 'Saas':
        """
        刷新登录状态

        尝试从缓存获取token，如果缓存中没有或token无效，则重新登录。

        :param client: 可选的同步客户端实例
        :param login_kwargs: 传递给login的额外参数
        :param query_manage_tree_kwargs: 传递给query_manage_tree的额外参数
        :return: Saas - 返回自身实例
        """
        # 处理参数
        login_kwargs = login_kwargs or {}
        query_manage_tree_kwargs = query_manage_tree_kwargs or {}

        # 获取缓存配置
        cache_key = self.cache_config.get("key", f"py_easy_wisharetec_saas_{self.account}")
        cache_expire = self.cache_config.get("expire", 86400 * 180)
        cache_instance = self.cache_config.get("instance", None)

        # 处理缓存
        if not isinstance(cache_instance, Union[diskcache.Cache, redis.Redis]):
            # 无缓存实例，直接登录
            is_login: bool = self.login(client=client, **login_kwargs)
            if is_login:
                self.token = self.token
        else:
            # 有缓存实例时，先尝试从缓存获取
            self.token = cache_instance.get(cache_key, "")
            # 验证token是否有效
            manage_tree = self.query_manage_tree(client=client, **query_manage_tree_kwargs)
            if not isinstance(manage_tree, list):
                # token无效，重新获取
                is_login: bool = self.login(client=client, **login_kwargs)
                if is_login:
                    self.token = self.token
                    # 缓存新的token
                    if isinstance(cache_instance, diskcache.Cache):
                        cache_instance.set(cache_key, self.token, expire=cache_expire)
                    elif isinstance(cache_instance, redis.Redis):
                        cache_instance.set(cache_key, self.token, ex=cache_expire)

        return self

    @json_paser(
        validator={
            "type": "object",
            "properties": {
                "records": {"type": "array"},
            },
            "required": ["records"],
        },
        path_expr="$"
    )
    def query_property_owners(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        查询业主列表

        :param client: 可选的同步客户端实例
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求参数
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", "/api/space/archive/examine/page")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
        },
        path_expr="$"
    )
    def query_property_owner(
            self,
            client: Optional[httpx.Client] = None,
            user_id: str = None,
            company_id: str = None,
            space_id: str = None,
            **kwargs
    ) -> httpx.Response:
        """
        查询业主详情

        :param client: 可选的同步客户端实例
        :param user_id: 用户ID
        :param company_id: 公司ID
        :param space_id: 空间ID
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 处理参数
        user_id = user_id or ""
        company_id = company_id or ""
        space_id = space_id or ""

        # 设置查询参数
        params = kwargs.get("params", {})
        params.setdefault("userId", user_id)
        params.setdefault("companyId", company_id)
        params.setdefault("spaceId", space_id)
        kwargs["params"] = params

        # 设置请求参数
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", "/api/space/archive/archive/detailSensitive")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
            "properties": {
                "records": {"type": "array"},
            },
            "required": ["records"],
        },
        path_expr="$"
    )
    def query_cars(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        查询车辆列表

        :param client: 可选的同步客户端实例
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求参数
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", "/api/space/carManage/pageCarManage")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
        },
        path_expr="$"
    )
    def query_car(self, client: Optional[httpx.Client] = None, id: str = None, **kwargs) -> httpx.Response:
        """
        查询车辆详情

        :param client: 可选的同步客户端实例
        :param id: 车辆ID
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 处理参数
        id = id or ""

        # 设置查询参数
        params = kwargs.get("params", {})
        params.setdefault("id", id)
        kwargs["params"] = params

        # 设置请求参数
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", "/api/space/carManage/detail")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
            "properties": {
                "records": {"type": "array"},
            },
            "required": ["records"],
        },
        path_expr="$"
    )
    def query_parking_spaces(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        查询停车位列表

        :param client: 可选的同步客户端实例
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求参数
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", "/api/space/parking/parkingPage")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
        },
        path_expr="$"
    )
    def query_parking_space(self, client: Optional[httpx.Client] = None, id: str = None, **kwargs) -> httpx.Response:
        """
        查询停车位详情

        :param client: 可选的同步客户端实例
        :param id: 停车位ID
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 处理参数
        id = id or ""

        # 设置查询参数
        params = kwargs.get("params", {})
        params.setdefault("id", id)
        kwargs["params"] = params

        # 设置请求参数
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", "/api/space/parking/getParking")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
            "properties": {
                "records": {"type": "array"},
            },
            "required": ["records"],
        },
        path_expr="$"
    )
    def query_parking_lots(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        查询停车场列表

        :param client: 可选的同步客户端实例
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求参数
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", "/api/space/space/yardArchivePage")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",

        },
        path_expr="$"
    )
    def query_parking_lot(self, client: Optional[httpx.Client] = None, id: str = None, **kwargs) -> httpx.Response:
        """
        查询停车场详情

        :param client: 可选的同步客户端实例
        :param id: 停车场ID
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 处理参数
        id = id or ""

        # 设置查询参数
        params = kwargs.get("params", {})
        params.setdefault("id", id)
        kwargs["params"] = params

        # 设置请求参数
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", "/api/space/space/getYardArchivePage")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
            "properties": {
                "records": {"type": "array"},
            },
            "required": ["records"],
        },
        path_expr="$"
    )
    def query_parking_approvals(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        查询停车审批列表

        :param client: 可选的同步客户端实例
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求参数
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", "/api/bpm/process/approval")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
        },
        path_expr="$"
    )
    def query_parking_approval(self, client: Optional[httpx.Client] = None, id: str = None, **kwargs) -> httpx.Response:
        """
        查询停车审批详情

        :param client: 可选的同步客户端实例
        :param id: 审批ID
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 处理参数
        id = id or ""

        # 设置请求参数
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", f"/api/bpm/process/progress/{id}/node_433279443693")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
        },
        path_expr="$"
    )
    def update_parking_approval(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        更新停车审批状态

        :param client: 可选的同步客户端实例
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求参数
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", f"/api/bpm/process/task/handler")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
            "properties": {
                "records": {"type": "array"},
            },
            "required": ["records"],
        },
        path_expr="$"
    )
    def query_shop_orders(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        查询商城订单列表

        :param client: 可选的同步客户端实例
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求参数
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", "/api/retailmall/order/pageFront")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
        },
        path_expr="$"
    )
    def query_shop_order(self, client: Optional[httpx.Client] = None, id: str = None, **kwargs) -> httpx.Response:
        """
        查询商城订单详情

        :param client: 可选的同步客户端实例
        :param id: 订单ID
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 处理参数
        id = id or ""

        # 设置查询参数
        params = kwargs.get("params", {})
        params.setdefault("id", id)
        kwargs["params"] = params

        # 设置请求参数
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", f"/api/retailmall/order/detailPC")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
            "properties": {
                "records": {"type": "array"},
            },
            "required": ["records"],
        },
        path_expr="$"
    )
    def query_service_orders(self, client: Optional[httpx.Client] = None, **kwargs) -> httpx.Response:
        """
        查询服务订单列表

        :param client: 可选的同步客户端实例
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 设置请求参数
        kwargs.setdefault("method", "POST")
        kwargs.setdefault("url", "/api/houseserve/order/pageFront")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
        },
        path_expr="$"
    )
    def query_service_order(self, client: Optional[httpx.Client] = None, id: str = None, **kwargs) -> httpx.Response:
        """
        查询服务订单详情

        :param client: 可选的同步客户端实例
        :param id: 订单ID
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 处理参数
        id = id or ""

        # 设置查询参数
        params = kwargs.get("params", {})
        params.setdefault("id", id)
        kwargs["params"] = params

        # 设置请求参数
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", f"/api/houseserve/order/detailPC")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)

    @json_paser(
        validator={
            "type": "object",
        },
        path_expr="$"
    )
    def query_property(self, client: Optional[httpx.Client] = None, id: str = None, **kwargs) -> httpx.Response:
        """
        查询房产详情

        :param client: 可选的同步客户端实例
        :param id: 房产ID
        :param **kwargs: 传递给request的额外参数
        :return: httpx.Response - HTTP响应对象
        """
        # 处理参数
        id = id or ""

        # 设置查询参数
        params = kwargs.get("params", {})
        params.setdefault("id", id)
        kwargs["params"] = params

        # 设置请求参数
        kwargs.setdefault("method", "GET")
        kwargs.setdefault("url", f"/api/space/property/getProperty")

        # 设置请求头
        headers = kwargs.get("headers", {})
        headers.setdefault("content-type", "application/json")
        headers.setdefault("client", "co-pc")
        headers.setdefault("authorization", self.token)
        kwargs["headers"] = headers

        return self.request(client=client, **kwargs)
