pytroll-monitor
===============

[![Build status](https://github.com/pytroll/pytroll-monitor/workflows/CI/badge.svg?branch=main)](https://github.com/pytroll/pytroll-monitor/workflows/CI/badge.svg?branch=main)
[![Coverage Status](https://coveralls.io/repos/github/pytroll/pytroll-monitor/badge.svg?branch=main)](https://coveralls.io/github/pytroll/pytroll-monitor?branch=main)
[![PyPI version](https://badge.fury.io/py/pytroll-monitor.svg)](https://badge.fury.io/py/pytroll-monitor)

Monitoring tools for pytroll
