-- missing some commas
vacuum (full analyze false skip_locked true);
