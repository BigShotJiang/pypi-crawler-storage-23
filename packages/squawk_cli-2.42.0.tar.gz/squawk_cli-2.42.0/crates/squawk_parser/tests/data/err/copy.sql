-- missing a couple commas
copy x (i y) from '/tmp/input.file' (on_error ignore  log_verbosity verbose);
