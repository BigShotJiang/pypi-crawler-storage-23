-- missing commas
reindex (concurrently verbose tablespace t) index i;
