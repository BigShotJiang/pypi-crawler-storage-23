-- simple
create operator family f using i;

-- full
create operator family a.b using i;

