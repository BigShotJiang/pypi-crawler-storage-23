-- pg_docs
deallocate prepare all;

deallocate all;

deallocate foo;

