-- simple
drop group s;

-- full
drop group if exists a, b, c;

