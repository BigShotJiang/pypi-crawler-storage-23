-- rename
alter language x rename to y;
alter procedural language x rename to y;

-- owner
alter language x owner to u;
alter procedural language x owner to current_user;

