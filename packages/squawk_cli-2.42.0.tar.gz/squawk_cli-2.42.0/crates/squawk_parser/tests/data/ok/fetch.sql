-- pg_docs
fetch next from cursor_name;
fetch prior from cursor_name;
fetch prior in cursor_name;
fetch prior cursor_name;

FETCH NEXT FROM cursor_name;
FETCH PRIOR FROM cursor_name;
FETCH FIRST FROM cursor_name;
FETCH LAST FROM cursor_name;
FETCH ABSOLUTE 10 FROM cursor_name;
FETCH RELATIVE 10 FROM cursor_name;
FETCH 10 FROM cursor_name;
FETCH ALL FROM cursor_name;
FETCH FORWARD FROM cursor_name;
FETCH FORWARD 10 FROM cursor_name;
FETCH FORWARD ALL FROM cursor_name;
FETCH BACKWARD FROM cursor_name;
FETCH BACKWARD 10 FROM cursor_name;
FETCH BACKWARD ALL FROM cursor_name;

