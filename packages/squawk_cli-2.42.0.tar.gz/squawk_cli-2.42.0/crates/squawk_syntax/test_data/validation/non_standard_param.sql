-- invalid param type
select :x;
select : foo;
