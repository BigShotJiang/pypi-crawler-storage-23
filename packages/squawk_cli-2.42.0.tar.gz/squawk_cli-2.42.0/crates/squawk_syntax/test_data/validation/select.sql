
from t select c;

from t;

with t as (from k)
select * from t;
