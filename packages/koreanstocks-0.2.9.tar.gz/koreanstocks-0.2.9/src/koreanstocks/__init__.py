VERSION = "0.2.9"

import warnings
warnings.filterwarnings("ignore", message="pkg_resources is deprecated")
