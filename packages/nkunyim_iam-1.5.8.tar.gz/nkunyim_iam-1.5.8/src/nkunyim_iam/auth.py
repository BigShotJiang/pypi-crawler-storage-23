import base64
from datetime import datetime, timezone
import hashlib
import hmac
import json
from typing import Optional

from django.conf import settings

from nkunyim_iam.commands import UserCommand
from nkunyim_iam.configs import ServiceConfig
from nkunyim_iam.data import AccessTokenData, UserinfoData
from nkunyim_iam.encryption import JWTEncryption
from nkunyim_iam.handlers import LoggingHandler, UserHandler
from nkunyim_iam.models import User


class Auth:
    @staticmethod
    def get_config() -> ServiceConfig:
        _config = settings.NKUNYIM_SERVICE_CONFIG
        return ServiceConfig(**_config)

    
    @staticmethod
    def sign(key: str, payload: dict) -> str:
        message = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        digest = hmac.new(key.encode(), msg=message.encode(), digestmod=hashlib.sha256,).hexdigest()
        encoded = digest.encode()
        signature = base64.b64encode(encoded).decode()
        return signature
    
    
    @staticmethod
    def verify(signature: str, payload: dict) -> bool:
        config = Auth.get_config()
        if not config.verify:
            return True
        
        resign = Auth.sign(key=config.key, payload=payload)
        return resign == signature
    
    
    @staticmethod
    def jwt_userinfo(access_token: str) -> Optional[UserinfoData]:
        try:
            decoded = JWTEncryption.decode(token=access_token)
            access_token_data = AccessTokenData(**decoded)
            if access_token_data.exp <= int(datetime.now(timezone.utc).timestamp()):
                LoggingHandler.danger(
                    message="Access token has expired.",
                    context={"method": "Auth.jwt_userinfo", "exp": str(access_token_data.exp)},
                )
                return None
            
            _config = Auth.get_config()
            if _config.name.lower() not in  access_token_data.access.roles:
                LoggingHandler.danger(
                    message="Access denied, invalid role claim.",
                    context={
                        "method": "Auth.jwt_userinfo",
                        "name": _config.name.lower(),
                        "roles": ", ".join(access_token_data.access.roles)
                    },
                )
                return None
                
            userinfo = access_token_data.access.user
            userinfo_data = userinfo.model_dump()
            return UserinfoData(**userinfo_data)
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to decode userinfo data from JWT.",
                context={"method": "Auth.jwt_userinfo", "exception": str(ex)},
            )
            return None
        

    @staticmethod
    def authenticate(token: str) -> Optional[User]:
        try:
            userinfo_data = Auth.jwt_userinfo(access_token=token)
            if not userinfo_data:
                return None

            userinfo = userinfo_data.model_dump()
            user_command = UserCommand(**userinfo)
            user_model = UserHandler.handle(command=user_command)
            
            return user_model
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to retrieve user data from API.",
                context={"method": "Auth.authenticate", "exception": str(ex)},
            )
            return None


    @staticmethod
    def authorize(token: str) -> Optional[User]:
        try:
            userinfo_data = Auth.jwt_userinfo(access_token=token)
            if not userinfo_data:
                return None

            userinfo = userinfo_data.model_dump()
            user_command = UserCommand(**userinfo)
            user_model = UserHandler.find(id=user_command.id)
            
            return user_model
        except Exception as ex:
            LoggingHandler.danger(
                message="Failed to retrieve user data from API.",
                context={"method": "Auth.authorize", "exception": str(ex)},
            )
            return None
