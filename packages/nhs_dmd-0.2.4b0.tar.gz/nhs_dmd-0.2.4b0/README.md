# DMD database

[![version](https://img.shields.io/badge/version-0.2.4b0-blue)](https://gitlab.com/cfinan/dmd)
[![python](https://img.shields.io/badge/python-3.11%20%7C%203.12%20%7C%203.13-blue)](https://www.python.org)
[![license](https://img.shields.io/badge/license-GPL--3.0-green)](LICENSE.txt)

A Python toolkit for building the NHS Dictionary of Medicines and Devices
(DM+D) XML distribution files into a relational database. It provides an
SQLAlchemy 2 ORM, CLI scripts for building single-version and multi-version
warehouse databases, and a query API for looking up medicines by name, ID, or
ingredient.

There is [online documentation](https://cfinan.gitlab.io/dmd/index.html) for
dmd.

Please note, this is for research purposes only and was built to map
prescriptions from sources such as CPRD and the UK BioBank. Please do not use
for any healthcare related implementation.

## Installation

### Using pip

Install from a local clone for development:

```bash
git clone git@gitlab.com:cfinan/dmd.git
cd dmd
pip install -e ".[dev]"
```

### Using conda

A conda package is available in the `cfin` channel for Python 3.11--3.13
(Linux-64):

```bash
conda install -c cfin -c conda-forge dmd
```

## Usage

### Command line

Build a DM+D database from the NHS TRUD zip archives:

```bash
dmd-build -v -B nhsbsa_dmdbonus_<version>.zip nhsbsa_dmd_<version>.zip ~/dmd.db
```

More information on DM+D can be found on the NHS digital
[TRUD](https://isd.digital.nhs.uk/trud/user/guest/group/0/home) site. You will
need an account to subscribe and download.

For full CLI help:

```bash
dmd-build --help
dmd-warehouse-build --help
```

### Python API

```python
import sqlalchemy
from dmd.build import build_dmd

engine = sqlalchemy.create_engine("sqlite:///dmd.db")
sm = sqlalchemy.orm.sessionmaker(bind=engine)

build_dmd(
    sm,
    "nhsbsa_dmd_<version>.zip",
    bonus_zip="nhsbsa_dmdbonus_<version>.zip",
)
```

## Schema

The final database will have the following schema (including bonus file). Open
in a separate browser tab to make it larger.

<div>
<img style="float: right;" width="100%" height="100%" src="./resources/images/dmd_schema.png">
</div>
