"""NHS DM+D database builder and query toolkit.

Provides an SQLAlchemy ORM, CLI scripts, and a query API for building
and querying the NHS Dictionary of Medicines and Devices (DM+D).
"""

__version__ = '0.2.4b0'
from .build import (
    build_dmd
)
