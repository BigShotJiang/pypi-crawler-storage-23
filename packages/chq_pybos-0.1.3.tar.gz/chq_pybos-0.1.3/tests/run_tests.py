"""
Test runner and utilities for pybos integration tests.

This module provides utilities for running tests and managing test data.
"""

import sys
import subprocess
import argparse
from pathlib import Path
from typing import List, Optional

# Add the project root to the Python path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))


def validate_environment() -> tuple[bool, str]:
    """Validate that the test environment is properly configured."""
    from tests.config import validate_test_environment, load_env_from_files

    # Ensure .env files are loaded
    load_env_from_files()
    return validate_test_environment()


def run_tests(
    test_pattern: Optional[str] = None,
    verbose: bool = False,
    skip_slow: bool = False,
    service: Optional[str] = None,
) -> int:
    """
    Run the integration tests.

    Args:
        test_pattern: Specific test pattern to run
        verbose: Enable verbose output
        skip_slow: Skip slow-running tests
        service: Run tests for specific service only

    Returns:
        Exit code (0 for success, non-zero for failure)
    """
    # Validate environment first
    is_valid, error_msg = validate_environment()
    if not is_valid:
        print(f"❌ Environment validation failed: {error_msg}")
        print("\nPlease configure the required environment variables:")
        print("BOS_TEST_URL=https://your-test-environment.com")
        print("BOS_TEST_API_KEY=your-test-api-key")
        return 1

    print("✅ Environment validation passed")

    # Build pytest command using the current interpreter to ensure correct environment
    cmd = [str(sys.executable), "-m", "pytest"]

    # Determine what to run
    tests_root = project_root / "tests"
    services_root = tests_root / "services"

    if test_pattern:
        # Run exactly the provided pattern/path
        cmd.append(test_pattern)
    elif service:
        # Prefer tests/services/<service>.py, then directory or legacy name
        service_dir = services_root / service
        service_file_flat = services_root / f"{service}.py"
        service_file_in_services = services_root / f"test_{service}.py"
        legacy_service_file = tests_root / f"test_{service}.py"

        def dir_has_tests(path: Path) -> bool:
            return (
                path.exists()
                and path.is_dir()
                and any(
                    p.is_file() and p.suffix == ".py" and p.name.startswith("test_")
                    for p in path.iterdir()
                )
            )

        if service_file_flat.exists():
            cmd.append(str(service_file_flat))
        elif dir_has_tests(service_dir):
            cmd.append(str(service_dir))
        elif service_file_in_services.exists():
            cmd.append(str(service_file_in_services))
        elif legacy_service_file.exists():
            cmd.append(str(legacy_service_file))
        else:
            print(f"❌ Could not find tests for service '{service}'.")
            print(
                "Looked for: "
                f"{service_dir} (dir), {service_file_in_services} (file), {legacy_service_file} (file)"
            )
            return 1
    else:
        # Default: run the whole test suite
        cmd.append("tests/")

    # Add verbosity
    if verbose:
        cmd.extend(["-v", "-s"])
    else:
        cmd.append("-q")

    # Add markers for slow tests
    if skip_slow:
        cmd.extend(["-m", "not slow"])

    # Add test discovery
    cmd.extend(["--tb=short", "--strict-markers"])

    print(f"Running command: {' '.join(cmd)}")
    print("-" * 50)

    # Run the tests
    result = subprocess.run(cmd, cwd=project_root)
    return result.returncode


def run_specific_service_tests(service: str, verbose: bool = False) -> int:
    """Run tests for a specific service."""
    # Delegate to run_tests with service selection
    return run_tests(service=service, verbose=verbose)


def get_available_services() -> List[str]:
    """Infer available service test targets from filesystem.

    - Includes directory names under tests/services/
    - Includes legacy top-level files named tests/test_<name>.py
    """
    services: set[str] = set()

    tests_root = project_root / "tests"
    services_root = tests_root / "services"

    # Directory-based services (only include directories that contain test files)
    if services_root.exists() and services_root.is_dir():
        for item in services_root.iterdir():
            if item.is_dir():
                if any(
                    p.is_file()
                    and p.suffix == ".py"
                    and (p.name.startswith("test_") or not p.name.startswith("__"))
                    for p in item.iterdir()
                ):
                    services.add(item.name)
            elif item.is_file() and item.suffix == ".py":
                # Accept either test_<name>.py or <name>.py
                name = item.stem
                if name.startswith("test_"):
                    name = name.replace("test_", "", 1)
                services.add(name)

    # Legacy files at tests/
    if tests_root.exists() and tests_root.is_dir():
        for item in tests_root.iterdir():
            if (
                item.is_file()
                and item.name.startswith("test_")
                and item.suffix == ".py"
            ):
                services.add(item.stem.replace("test_", "", 1))

    return sorted(services)


def main():
    """Main entry point for the test runner."""
    parser = argparse.ArgumentParser(description="Run pybos integration tests")
    # Discover available services dynamically
    available_services = get_available_services()

    parser.add_argument(
        "--service",
        help="Run tests for specific service only",
        choices=available_services if available_services else None,
    )
    parser.add_argument("--pattern", help="Run tests matching specific pattern")
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="Enable verbose output"
    )
    parser.add_argument(
        "--skip-slow", action="store_true", help="Skip slow-running tests"
    )
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Only validate environment, don't run tests",
    )

    args = parser.parse_args()

    if args.validate_only:
        is_valid, error_msg = validate_environment()
        if is_valid:
            print("✅ Environment validation passed")
            return 0
        else:
            print(f"❌ Environment validation failed: {error_msg}")
            return 1

    if args.service:
        return run_specific_service_tests(args.service, args.verbose)
    else:
        return run_tests(
            test_pattern=args.pattern, verbose=args.verbose, skip_slow=args.skip_slow
        )


if __name__ == "__main__":
    sys.exit(main())
