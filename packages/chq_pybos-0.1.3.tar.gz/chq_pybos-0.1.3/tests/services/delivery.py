"""
Integration tests for pybos DeliveryService.

These tests validate that the DeliveryService works correctly with the actual BOS API.
"""

from pybos import BOS
from pybos.types.deliveryenquiry import FindAllDeliveryResponse


class TestDeliveryService:
    """Test cases for DeliveryService integration."""

    def test_find_all_delivery(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test finding all delivery methods."""
        result = bos_client.delivery.find_all_delivery()
        
        # Validate response structure
        assert isinstance(result, FindAllDeliveryResponse)
        assert hasattr(result, "error")
        # Should return a response even if empty

