"""
Integration tests for pybos SeasonalPriceService.

These tests validate that the SeasonalPriceService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestSeasonalPriceService:
    """Test cases for SeasonalPriceService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that SeasonalPriceService is accessible."""
        assert hasattr(bos_client, "seasonalprice")
        assert bos_client.seasonalprice is not None

