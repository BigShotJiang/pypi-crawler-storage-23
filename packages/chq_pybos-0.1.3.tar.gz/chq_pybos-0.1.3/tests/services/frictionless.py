"""
Integration tests for pybos FrictionlessService.

These tests validate that the FrictionlessService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestFrictionlessService:
    """Test cases for FrictionlessService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that FrictionlessService is accessible."""
        assert hasattr(bos_client, "frictionless")
        assert bos_client.frictionless is not None

