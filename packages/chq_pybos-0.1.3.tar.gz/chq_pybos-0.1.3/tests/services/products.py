"""
Integration tests for pybos ProductService.

These tests validate that the ProductService works correctly with the actual BOS API.
"""

from pybos import BOS
from pybos.types.productenquiry import (
    FindAllProductsResponse,
    FindAllStatisticalGroupResponse,
)


class TestProductService:
    """Test cases for ProductService integration."""

    def test_find_all_products(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test finding all products."""
        result = bos_client.products.find_all_products()
        
        # Validate response structure
        assert isinstance(result, FindAllProductsResponse)
        assert hasattr(result, "error")
        assert hasattr(result, "product_list")

    def test_find_all_statistical_group(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test finding all statistical groups."""
        result = bos_client.products.find_all_statistical_group()
        
        # Validate response structure
        assert isinstance(result, FindAllStatisticalGroupResponse)
        assert hasattr(result, "error")

