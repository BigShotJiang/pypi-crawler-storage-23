"""
Integration tests for pybos ExternalReservationService.

These tests validate that the ExternalReservationService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestExternalReservationService:
    """Test cases for ExternalReservationService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that ExternalReservationService is accessible."""
        assert hasattr(bos_client, "externalreservation")
        assert bos_client.externalreservation is not None

