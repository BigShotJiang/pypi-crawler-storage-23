"""
Integration tests for pybos InstallmentService.

These tests validate that the InstallmentService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestInstallmentService:
    """Test cases for InstallmentService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that InstallmentService is accessible."""
        assert hasattr(bos_client, "installment")
        assert bos_client.installment is not None

