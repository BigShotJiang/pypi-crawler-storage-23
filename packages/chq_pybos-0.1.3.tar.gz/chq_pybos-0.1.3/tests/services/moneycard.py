"""
Integration tests for pybos MoneyCardService.

These tests validate that the MoneyCardService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestMoneyCardService:
    """Test cases for MoneyCardService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that MoneyCardService is accessible."""
        assert hasattr(bos_client, "moneycard")
        assert bos_client.moneycard is not None

