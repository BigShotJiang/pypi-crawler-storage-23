"""
Integration tests for pybos ReportService.

These tests validate that the ReportService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestReportService:
    """Test cases for ReportService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that ReportService is accessible."""
        assert hasattr(bos_client, "report")
        assert bos_client.report is not None

