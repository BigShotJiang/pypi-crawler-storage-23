"""
Integration tests for pybos InvoiceService.

These tests validate that the InvoiceService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestInvoiceService:
    """Test cases for InvoiceService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that InvoiceService is accessible."""
        assert hasattr(bos_client, "invoice")
        assert bos_client.invoice is not None

