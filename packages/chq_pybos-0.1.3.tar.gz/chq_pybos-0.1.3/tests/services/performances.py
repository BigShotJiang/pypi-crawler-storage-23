"""
Integration tests for pybos PerformanceService.

These tests validate that the PerformanceService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestPerformanceService:
    """Test cases for PerformanceService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that PerformanceService is accessible."""
        assert hasattr(bos_client, "performances")
        assert bos_client.performances is not None

