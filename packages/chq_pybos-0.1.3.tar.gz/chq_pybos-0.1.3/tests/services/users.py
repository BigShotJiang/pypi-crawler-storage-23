"""
Integration tests for pybos UserService.

These tests validate that the UserService works correctly with the actual BOS API.
"""

from pybos import BOS
from pybos.types.user import CheckSessionResponse, UserLoginResponse, UserLogoutResponse


class TestUserService:
    """Test cases for UserService integration."""

    def test_check_session(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test session validation functionality."""
        result = bos_client.users.check_session()

        # Validate response structure
        assert isinstance(result, CheckSessionResponse)
        # Session check should return session status information
        # The exact structure depends on the API response format
        assert result.error.code == "200"
        assert result.app_server_version is not None

    def test_check_session_with_invalid_credentials(self, bos_client: BOS):
        """Test session check with invalid credentials."""
        # Create a client with invalid API key
        invalid_client = BOS(isapi_url=bos_client.isapi_url, api_key="invalid-api-key")

        result = invalid_client.users.check_session()

        # Should return error information
        assert isinstance(result, CheckSessionResponse)
        assert result.error.code == "401"
        assert result.app_server_version is None

    def test_user_logout(self, bos_client: BOS):
        """Test user logout functionality."""
        result = bos_client.users.user_logout()
        assert isinstance(result, UserLogoutResponse)
        assert result.error.code == "200"

    def test_user_login(
        self,
        bos_client: BOS,
        test_config: dict,
        skip_if_no_credentials: bool,
    ):
        """Test user login functionality."""
        workstation = test_config.get("workstation", "test-workstation")
        username = test_config.get("username", "testuser")
        password = test_config.get("password", "test-password")

        result = bos_client.users.user_login(workstation, username, password)
        assert isinstance(result, UserLoginResponse)
        # Login may succeed or fail depending on credentials, but should return proper response
        assert result.error.code in ["200", "401", "403"]
        if result.error.code == "200":
            assert result.session_id is not None
