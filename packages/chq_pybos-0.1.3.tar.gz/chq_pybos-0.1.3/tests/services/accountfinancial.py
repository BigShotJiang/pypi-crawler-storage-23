"""
Integration tests for pybos AccountFinancialService.

These tests validate that the AccountFinancialService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestAccountFinancialService:
    """Test cases for AccountFinancialService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that AccountFinancialService is accessible."""
        assert hasattr(bos_client, "accountfinancial")
        assert bos_client.accountfinancial is not None

