"""
Integration tests for pybos AccountService.

These tests validate that the AccountService works correctly with the actual BOS API.
"""

from pybos import BOS
from pybos.types import AccountField, SaveAccountRequest, SaveAccountResponse


class TestAccountService:
    """Test cases for AccountService integration."""

    def test_save_account_new(
        self, bos_client: BOS, test_account_data: dict, skip_if_no_credentials: bool
    ):
        """Test creating a new account."""
        fields = [
            AccountField("Integration Test Account", 1),  # Name
            AccountField("integration-test@example.com", 2),  # Email
        ]

        request = SaveAccountRequest(
            dmg_category_ak=test_account_data["dmg_category_ak"],
            fields=fields,
            status=1,
        )

        result = bos_client.accounts.save_account(request)

        # Validate response structure
        assert isinstance(result, SaveAccountResponse)
        # Account creation may succeed or fail depending on permissions/data
        assert result.error.code in ["200", "400", "401", "403"]

        if result.error.code == "200":
            assert result.account_info is not None
            assert result.account_info.ak is not None

    def test_save_account_invalid_data(
        self, bos_client: BOS, skip_if_no_credentials: bool
    ):
        """Test account creation with invalid data."""
        # Test with empty fields list
        request = SaveAccountRequest(
            dmg_category_ak="INVALID_CATEGORY",
            fields=[],
            status=1,
        )

        result = bos_client.accounts.save_account(request)

        # Should return error for invalid data
        assert isinstance(result, SaveAccountResponse)
        assert result.error.code in ["400", "401", "403", "404"]
