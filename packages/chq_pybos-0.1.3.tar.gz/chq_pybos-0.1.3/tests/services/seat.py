"""
Integration tests for pybos SeatService.

These tests validate that the SeatService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestSeatService:
    """Test cases for SeatService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that SeatService is accessible."""
        assert hasattr(bos_client, "seat")
        assert bos_client.seat is not None

