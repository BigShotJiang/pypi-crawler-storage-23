"""
Integration tests for pybos RenewalPlanService.

These tests validate that the RenewalPlanService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestRenewalPlanService:
    """Test cases for RenewalPlanService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that RenewalPlanService is accessible."""
        assert hasattr(bos_client, "renewalplan")
        assert bos_client.renewalplan is not None

