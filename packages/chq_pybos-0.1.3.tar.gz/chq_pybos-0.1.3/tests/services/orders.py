"""
Integration tests for pybos OrderService.

These tests validate that the OrderService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestOrderService:
    """Test cases for OrderService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that OrderService is accessible."""
        assert hasattr(bos_client, "orders")
        assert bos_client.orders is not None

