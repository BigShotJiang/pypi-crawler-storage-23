"""
Integration tests for pybos PromotionService.

These tests validate that the PromotionService works correctly with the actual BOS API.
"""

from pybos import BOS
from pybos.types.promotionenquiry import FindAllPromotionResponse


class TestPromotionService:
    """Test cases for PromotionService integration."""

    def test_find_all_promotion(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test finding all promotions."""
        result = bos_client.promotion.find_all_promotion()
        
        # Validate response structure
        assert isinstance(result, FindAllPromotionResponse)
        assert hasattr(result, "error")

