"""
Integration tests for pybos UpsellService.

These tests validate that the UpsellService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestUpsellService:
    """Test cases for UpsellService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that UpsellService is accessible."""
        assert hasattr(bos_client, "upsell")
        assert bos_client.upsell is not None

