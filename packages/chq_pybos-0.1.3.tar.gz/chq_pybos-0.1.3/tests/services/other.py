"""
Integration tests for pybos OtherService.

These tests validate that the OtherService works correctly with the actual BOS API.
"""

from pybos import BOS


class TestOtherService:
    """Test cases for OtherService integration."""

    def test_service_accessible(
        self,
        bos_client: BOS,
        skip_if_no_credentials: bool,
    ):
        """Test that OtherService is accessible."""
        assert hasattr(bos_client, "other")
        assert bos_client.other is not None

