# pybos Integration Tests

This directory contains integration tests for the pybos library that validate the library works correctly by making actual API calls to a test environment.

## Overview

The tests are designed to:
- Validate that all API services work correctly
- Test error handling with invalid data
- Ensure proper response structure validation
- Verify authentication and connectivity

## Test Structure

```
tests/
├── __init__.py              # Test package initialization
├── conftest.py              # Pytest configuration and fixtures
├── config.py                # Test environment configuration
├── run_tests.py             # Test runner utility
├── services/                # Service-focused integration tests (flat files)
│   ├── accounts.py          # AccountService tests
│   ├── users.py             # UserService tests
│   └── ...                  # Add more services as <service>.py
└── README.md                # This document
```

## Environment Setup

### Required Environment Variables

Set these environment variables before running tests:

```bash
# Required
export BOS_TEST_URL="https://your-test-environment.com"
export BOS_TEST_API_KEY="your-test-api-key"

# Optional
export BOS_TEST_USERNAME="testuser"
export BOS_TEST_WORKSTATION="test-workstation"
export BOS_TEST_PASSWORD="test-password"
```

### Using .env File

Create a `.env` file in the project root:

```bash
BOS_TEST_URL=https://test-bos.example.com
BOS_TEST_API_KEY=your-test-api-key-here
BOS_TEST_USERNAME=testuser
BOS_TEST_WORKSTATION=test-workstation
BOS_TEST_PASSWORD=test-password
```

## Running Tests

### Prerequisites

Install test dependencies:

```bash
pip install pytest requests
```

### Basic Test Execution

```bash
# Run all tests
python -m tests.run_tests

# Run with verbose output
python -m tests.run_tests --verbose

# Validate environment only (no tests)
python -m tests.run_tests --validate-only
```

### Service-Specific Tests

```bash
# Run tests for specific service (discovers tests/services/<service>.py first)
python -m tests.run_tests --service accounts
python -m tests.run_tests --service users

# Or run by path/pattern
python -m tests.run_tests --pattern tests/services/accounts.py
```

### Using pytest Directly

```bash
# Run all tests
pytest tests/

# Run specific test file
pytest tests/services/accounts.py

# Run specific test method
pytest tests/services/accounts.py::TestAccountService::test_search_account_basic

# Run with verbose output
pytest tests/ -v

# Run and stop on first failure
pytest tests/ -x
```

## Test Categories

### Basic Functionality Tests
- Test core API operations for each service
- Validate response structure and data types
- Test with valid test data

### Error Handling Tests
- Test with invalid parameters
- Test with non-existent resources
- Validate error response structure

### Edge Case Tests
- Test with empty data
- Test with boundary values
- Test with special characters

## Test Data

Tests use synthetic test data that should be safe for test environments:
- Test account names and emails
- Test event codes and titles
- Test performance schedules
- Test product matrix cells

## Safety Considerations

- Tests are designed to be safe for test environments
- No destructive operations on production data
- Uses test-specific identifiers and codes
- Includes proper error handling validation

## Troubleshooting

### Environment Issues

```bash
# Check environment configuration
python tests/run_tests.py --validate-only
```

### Connection Issues

- Verify BOS_TEST_URL is correct and accessible
- Check API key validity
- Ensure test environment is running

### Test Failures

- Check test environment data availability
- Verify test data IDs exist in test environment
- Review error messages for specific API issues

## Contributing

When adding new tests:

1. Follow the existing test structure
2. Use descriptive test names
3. Include both success and error cases
4. Add appropriate fixtures in `conftest.py`
5. Place new service tests under `tests/services/` as `<service>.py`
6. Update this documentation if needed

## Notes

- Tests require a valid test environment with appropriate test data
- Some tests may fail if test data doesn't exist in the environment
- Tests are designed to be idempotent and safe to run multiple times
- Consider the test environment's data cleanup policies
