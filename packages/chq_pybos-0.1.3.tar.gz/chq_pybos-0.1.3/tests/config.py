"""
Environment configuration for pybos integration tests.

This module provides utilities for managing test environment configuration
and validating API connectivity.
"""

import os
from pathlib import Path
import requests
from typing import Dict, Optional
from dataclasses import dataclass


@dataclass
class TestEnvironment:
    """Configuration for test environment."""

    isapi_url: str
    api_key: str
    username: Optional[str] = None
    workstation: Optional[str] = None
    password: Optional[str] = None

    @classmethod
    def from_env(cls) -> "TestEnvironment":
        """Create TestEnvironment from environment variables."""
        # Ensure .env is loaded before reading environment
        load_env_from_files()
        return cls(
            isapi_url=os.getenv("BOS_TEST_URL", "https://test-bos.example.com"),
            api_key=os.getenv("BOS_TEST_API_KEY", ""),
            username=os.getenv("BOS_TEST_USERNAME"),
            workstation=os.getenv("BOS_TEST_WORKSTATION"),
            password=os.getenv("BOS_TEST_PASSWORD"),
        )

    def is_configured(self) -> bool:
        """Check if environment is properly configured for testing."""
        return bool(self.isapi_url and self.api_key and self.api_key != "test-api-key")

    def validate_connectivity(self) -> bool:
        """Validate that the test environment is reachable."""
        try:
            # Try to reach the base URL
            response = requests.get(self.isapi_url + "/bosservices.dll", timeout=10)
            return response.status_code in [
                200,
                404,
                405,
            ]  # 404/405 are OK for API endpoints

        except requests.RequestException:
            return False


def get_test_config() -> Dict[str, str]:
    """Get test configuration as a dictionary."""
    env = TestEnvironment.from_env()
    return {
        "isapi_url": env.isapi_url,
        "api_key": env.api_key,
        "username": env.username or "",
        "workstation": env.workstation or "",
        "password": env.password or "",
    }


def validate_test_environment() -> tuple[bool, str]:
    """
    Validate the test environment configuration.

    Returns:
        tuple: (is_valid, error_message)
    """
    # Load .env files before validation
    load_env_from_files()
    env = TestEnvironment.from_env()

    if not env.is_configured():
        return (
            False,
            "Test environment not configured. Set BOS_TEST_URL and BOS_TEST_API_KEY environment variables.",
        )

    if not env.validate_connectivity():
        return False, f"Cannot reach test environment at {env.isapi_url}"

    return True, ""


def load_env_from_files() -> None:
    """Load environment variables from .env if present (no external deps).

    Precedence (first found wins for each variable and does not overwrite existing os.environ):
    1. Project root .env (repo root)
    2. tests/.env
    3. Current working directory .env
    """
    candidates = [
        Path(__file__).resolve().parents[1] / ".env",  # repo root
        Path(__file__).resolve().parent / ".env",  # tests/.env
        Path.cwd() / ".env",  # CWD .env
    ]

    for path in candidates:
        try:
            if not path.exists() or not path.is_file():
                continue
            for raw_line in path.read_text(encoding="utf-8").splitlines():
                line = raw_line.strip()
                if not line or line.startswith("#"):
                    continue
                if "=" not in line:
                    continue
                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if key and key not in os.environ:
                    os.environ[key] = value
        except Exception:
            # Fail-quietly: environment loading should never break tests
            continue


# Environment variable documentation
ENV_VARS_DOC = """
Required Environment Variables for Testing:

BOS_TEST_URL: The base URL of the BOS test environment
  Example: https://test-bos.example.com

BOS_TEST_API_KEY: API key for authentication
  Example: your-test-api-key-here

Optional Environment Variables:

BOS_TEST_USERNAME: Username for authentication
BOS_TEST_WORKSTATION: Workstation identifier
BOS_TEST_PASSWORD: Password for authentication

Example .env file:
BOS_TEST_URL=https://test-bos.example.com
BOS_TEST_API_KEY=your-test-api-key-here
BOS_TEST_USERNAME=testuser
BOS_TEST_WORKSTATION=test-workstation
BOS_TEST_PASSWORD=test-password
"""
