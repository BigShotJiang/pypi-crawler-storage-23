"""
Report service for the BOS API.

This service provides methods for report operations including reading,
searching, and printing reports.
"""

from ..base_service import BaseService
from ..types.reportenquiry import (
    ReadSaleRevenueRequest,
    ReadSaleRevenueResponse,
    SearchReportRequest,
    SearchReportResponse,
    PrintReservationConfirmRequest,
    PrintReservationConfirmResponse,
    PrintAccountReportRequest,
    PrintAccountReportResponse,
    PrintReportRequest,
    PrintReportResponse,
    ReadReportByAKRequest,
    ReadReportByAKResponse,
)


class ReportService(BaseService):
    """Service for BOS report operations.

    This service provides methods for report management including reading,
    searching, and printing reports in the BOS system. All complex data
    structures use typed classes instead of dictionaries for better IDE
    support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIReport")

    Example:
        >>> service = ReportService(bos_api, "IWsAPIReport")
        >>> request = ReadSaleRevenueRequest(
        ...     date_from="2024-01-01",
        ...     date_to="2024-12-31"
        ... )
        >>> response = service.read_sale_revenue(request)
        >>> if response.error.is_success:
        ...     print("Revenue data retrieved")
    """

    def read_sale_revenue(
        self, request: ReadSaleRevenueRequest
    ) -> ReadSaleRevenueResponse:
        """Read sale revenue.

        Args:
            request: ReadSaleRevenueRequest with date range and filters

        Returns:
            ReadSaleRevenueResponse: Response containing revenue data

        Example:
            >>> request = ReadSaleRevenueRequest(
            ...     date_from="2024-01-01",
            ...     date_to="2024-12-31",
            ...     site_ak="SITE123"
            ... )
            >>> response = service.read_sale_revenue(request)
            >>> if response.error.is_success:
            ...     print("Revenue data retrieved")
        """
        payload = {
            "urn:ReadSaleRevenue": {"READSALEREVENUEREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return ReadSaleRevenueResponse.from_dict(
            response["ReadSaleRevenueResponse"]["return"]
        )

    def search_report(
        self, request: SearchReportRequest
    ) -> SearchReportResponse:
        """Search for reports.

        Args:
            request: SearchReportRequest with search criteria

        Returns:
            SearchReportResponse: Response containing list of reports

        Example:
            >>> from ..types.common import PageRequest
            >>> request = SearchReportRequest(
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_report(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.report_item_list)} reports")
        """
        payload = {"urn:SearchReport": {"SEARCHREPORTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SearchReportResponse.from_dict(
            response["SearchReportResponse"]["return"]
        )

    def print_reservation_confirm(
        self, request: PrintReservationConfirmRequest
    ) -> PrintReservationConfirmResponse:
        """Print reservation confirmation.

        Args:
            request: PrintReservationConfirmRequest with report and sale AK

        Returns:
            PrintReservationConfirmResponse: Response containing PDF/EXCEL output

        Example:
            >>> request = PrintReservationConfirmRequest(
            ...     report_ak="REPORT123",
            ...     output_type={"PDF": True},
            ...     sale_ak="SALE123"
            ... )
            >>> response = service.print_reservation_confirm(request)
            >>> if response.error.is_success:
            ...     pdf_data = response.output.get("PDF")
        """
        payload = {
            "urn:PrintReservationConfirm": {
                "PRINTRESERVATIONCONFIRMREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return PrintReservationConfirmResponse.from_dict(
            response["PrintReservationConfirmResponse"]["return"]
        )

    def print_account_report(
        self, request: PrintAccountReportRequest
    ) -> PrintAccountReportResponse:
        """Print account report.

        Args:
            request: PrintAccountReportRequest with report and account AK

        Returns:
            PrintAccountReportResponse: Response containing PDF/EXCEL output

        Example:
            >>> from ..types.common import BaseDateFilter
            >>> request = PrintAccountReportRequest(
            ...     report_ak="REPORT123",
            ...     output_type={"PDF": True},
            ...     account_ak="ACC123",
            ...     date_filter=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31")
            ... )
            >>> response = service.print_account_report(request)
            >>> if response.error.is_success:
            ...     pdf_data = response.output.get("PDF")
        """
        payload = {
            "urn:PrintAccountReport": {
                "PRINTACCOUNTREPORTREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return PrintAccountReportResponse.from_dict(
            response["PrintAccountReportResponse"]["return"]
        )

    def print_report(
        self, request: PrintReportRequest
    ) -> PrintReportResponse:
        """Print report.

        Args:
            request: PrintReportRequest with report and parameters

        Returns:
            PrintReportResponse: Response containing PDF/EXCEL output

        Example:
            >>> request = PrintReportRequest(
            ...     report_ak="REPORT123",
            ...     output_type={"PDF": True},
            ...     parameter_list=[{"NAME": "PARAM1", "VALUE": "VALUE1"}]
            ... )
            >>> response = service.print_report(request)
            >>> if response.error.is_success:
            ...     pdf_data = response.output.get("PDF")
        """
        payload = {"urn:PrintReport": {"PRINTREPORTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return PrintReportResponse.from_dict(
            response["PrintReportResponse"]["return"]
        )

    def read_report_by_ak(
        self, request: ReadReportByAKRequest
    ) -> ReadReportByAKResponse:
        """Read report by AK.

        Args:
            request: ReadReportByAKRequest with report AK

        Returns:
            ReadReportByAKResponse: Response containing report details

        Example:
            >>> request = ReadReportByAKRequest(ak="REPORT123")
            >>> response = service.read_report_by_ak(request)
            >>> if response.error.is_success:
            ...     print(f"Report: {response.report_item.get('NAME')}")
        """
        payload = {
            "urn:ReadReportByAK": {"READREPORTBYAKREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return ReadReportByAKResponse.from_dict(
            response["ReadReportByAKResponse"]["return"]
        )
