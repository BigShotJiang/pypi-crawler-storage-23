"""
Money Card service for the BOS API.

This service provides methods for money card operations including usage,
recharge, cash out, and operation reading.
"""

from ..base_service import BaseService
from ..types.moneycard import (
    RecordMoneyCardUsageRequest,
    RecordMoneyCardUsageResponse,
    RecordMoneyCardRechargeRequest,
    RecordMoneyCardRechargeResponse,
    RecordMoneyCardCashOutRequest,
    RecordMoneyCardCashOutResponse,
    ReadMoneyCardOperationRequest,
    ReadMoneyCardOperationResponse,
)


class MoneyCardService(BaseService):
    """Service for BOS money card operations.

    This service provides methods for money card management including usage,
    recharge, cash out, and operation reading in the BOS system. All complex
    data structures use typed classes instead of dictionaries for better IDE
    support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIMoneyCard")

    Example:
        >>> service = MoneyCardService(bos_api, "IWsAPIMoneyCard")
        >>> request = RecordMoneyCardUsageRequest(
        ...     amount=10.0,
        ...     search={"MEDIACODE": "MEDIA123"}
        ... )
        >>> response = service.record_money_card_usage(request)
        >>> if response.error.is_success:
        ...     print(f"Balance: {response.money_card.get('BALANCE')}")
    """

    def record_money_card_usage(
        self, request: RecordMoneyCardUsageRequest
    ) -> RecordMoneyCardUsageResponse:
        """Record money card usage.

        Args:
            request: RecordMoneyCardUsageRequest with amount and search

        Returns:
            RecordMoneyCardUsageResponse: Response containing money card and tickets

        Example:
            >>> request = RecordMoneyCardUsageRequest(
            ...     amount=10.0,
            ...     search={"MEDIACODE": "MEDIA123"}
            ... )
            >>> response = service.record_money_card_usage(request)
            >>> if response.error.is_success:
            ...     print(f"Balance: {response.money_card.get('BALANCE')}")
        """
        payload = {
            "urn:RecordMoneyCardUsage": {"RecordMoneyCardUsageReq": request.to_dict()}
        }
        response = self.send_request(payload)
        return RecordMoneyCardUsageResponse.from_dict(
            response["RecordMoneyCardUsageResponse"]["return"]
        )

    def record_money_card_recharge(
        self, request: RecordMoneyCardRechargeRequest
    ) -> RecordMoneyCardRechargeResponse:
        """Record money card recharge.

        Args:
            request: RecordMoneyCardRechargeRequest with amount and search

        Returns:
            RecordMoneyCardRechargeResponse: Response containing money card and tickets

        Example:
            >>> request = RecordMoneyCardRechargeRequest(
            ...     amount=50.0,
            ...     search={"MEDIACODE": "MEDIA123"}
            ... )
            >>> response = service.record_money_card_recharge(request)
            >>> if response.error.is_success:
            ...     print(f"Balance: {response.money_card.get('BALANCE')}")
        """
        payload = {
            "urn:RecordMoneyCardRecharge": {
                "RecordMoneyCardRechargeReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return RecordMoneyCardRechargeResponse.from_dict(
            response["RecordMoneyCardRechargeResponse"]["return"]
        )

    def record_money_card_cash_out(
        self, request: RecordMoneyCardCashOutRequest
    ) -> RecordMoneyCardCashOutResponse:
        """Record money card cash out.

        Args:
            request: RecordMoneyCardCashOutRequest with amount and search

        Returns:
            RecordMoneyCardCashOutResponse: Response containing money card and tickets

        Example:
            >>> request = RecordMoneyCardCashOutRequest(
            ...     amount=20.0,
            ...     search={"MEDIACODE": "MEDIA123"}
            ... )
            >>> response = service.record_money_card_cash_out(request)
            >>> if response.error.is_success:
            ...     print(f"Balance: {response.money_card.get('BALANCE')}")
        """
        payload = {
            "urn:RecordMoneyCardCashOut": {
                "RecordMoneyCardCashOutReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return RecordMoneyCardCashOutResponse.from_dict(
            response["RecordMoneyCardCashOutResponse"]["return"]
        )

    def read_money_card_operation(
        self, request: ReadMoneyCardOperationRequest
    ) -> ReadMoneyCardOperationResponse:
        """Read money card operations.

        Args:
            request: ReadMoneyCardOperationRequest with search

        Returns:
            ReadMoneyCardOperationResponse: Response containing operations and money card

        Example:
            >>> request = ReadMoneyCardOperationRequest(
            ...     search={"MEDIACODE": "MEDIA123"}
            ... )
            >>> response = service.read_money_card_operation(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.money_card_operation_list)} operations")
        """
        payload = {
            "urn:ReadMoneyCardOperation": {
                "ReadMoneyCardOperationReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadMoneyCardOperationResponse.from_dict(
            response["ReadMoneyCardOperationResponse"]["return"]
        )
