"""
Third party service for the BOS API.

This service provides methods for third party operations including login,
seating info, seat management, and payment processing.
"""

from ..base_service import BaseService
from ..types.thirdparty import (
    LoginRequest,
    LoginResponse,
    SeatingInfoRequest,
    SeatingInfoResponse,
    ThirdHoldSeatRequest,
    ThirdHoldSeatResponse,
    ThirdReleaseSeatRequest,
    ThirdReleaseSeatResponse,
    DownloadExternalPDFRequest,
    DownloadExternalPDFResponse,
    GetAccountByUUIDRequest,
    GetAccountByUUIDResponse,
    SetCanalByAccountAKRequest,
    SetCanalByAccountAKResponse,
    ReleasePerformanceByUUIDRequest,
    ReleasePerformanceByUUIDResponse,
    ReleasePerformanceByTicketIdRequest,
    ReleasePerformanceByTicketIdResponse,
    BottomLinePayRequest,
    BottomLinePayResponse,
)


class ThirdPartyService(BaseService):
    """Service for BOS third party operations.

    This service provides methods for third party integration including login,
    seating info, seat management, and payment processing in the BOS system.
    All complex data structures use typed classes instead of dictionaries for
    better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIThirdParty")

    Example:
        >>> service = ThirdPartyService(bos_api, "IWsAPIThirdParty")
        >>> request = LoginRequest(user="user", password="pass")
        >>> response = service.login_socio(request)
        >>> if response.error.is_success:
        ...     print("Logged in")
    """

    def login_socio(self, request: LoginRequest) -> LoginResponse:
        """Login socio.

        Args:
            request: LoginRequest with user credentials

        Returns:
            LoginResponse: Response with operation result

        Example:
            >>> request = LoginRequest(user="user", password="pass", ip="127.0.0.1")
            >>> response = service.login_socio(request)
            >>> if response.error.is_success:
            ...     print("Logged in")
        """
        payload = {"urn:LoginSocio": {"LoginReq": request.to_dict()}}
        response = self.send_request(payload)
        return LoginResponse.from_dict(
            response["LoginSocioResponse"]["return"]
        )

    def login_preventa(self, request: LoginRequest) -> LoginResponse:
        """Login preventa.

        Args:
            request: LoginRequest with user credentials

        Returns:
            LoginResponse: Response with operation result

        Example:
            >>> request = LoginRequest(user="user", password="pass")
            >>> response = service.login_preventa(request)
            >>> if response.error.is_success:
            ...     print("Logged in")
        """
        payload = {"urn:LoginPreventa": {"LoginReq": request.to_dict()}}
        response = self.send_request(payload)
        return LoginResponse.from_dict(
            response["LoginPreventaResponse"]["return"]
        )

    def seating_info(
        self, request: SeatingInfoRequest
    ) -> SeatingInfoResponse:
        """Get seating information.

        Args:
            request: SeatingInfoRequest with space structure AK

        Returns:
            SeatingInfoResponse: Response containing seating information

        Example:
            >>> request = SeatingInfoRequest(
            ...     space_structure_ak="SPACE123",
            ...     only_available=True
            ... )
            >>> response = service.seating_info(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.seating_info_list)} seats")
        """
        payload = {"urn:SeatingInfo": {"SeatingInfoReq": request.to_dict()}}
        response = self.send_request(payload)
        return SeatingInfoResponse.from_dict(
            response["SeatingInfoResponse"]["return"]
        )

    def hold_seat(self, request: ThirdHoldSeatRequest) -> ThirdHoldSeatResponse:
        """Hold seat.

        Args:
            request: ThirdHoldSeatRequest with seat details

        Returns:
            ThirdHoldSeatResponse: Response with operation result

        Example:
            >>> request = ThirdHoldSeatRequest(
            ...     space_structure_ak="SPACE123",
            ...     seat_list={"SEATINFO": [{"SEATID": 1}]}
            ... )
            >>> response = service.hold_seat(request)
            >>> if response.error.is_success:
            ...     print("Seat held")
        """
        payload = {"urn:HoldSeat": {"HoldSeatReq": request.to_dict()}}
        response = self.send_request(payload)
        return ThirdHoldSeatResponse.from_dict(
            response["HoldSeatResponse"]["return"]
        )

    def release_seat(
        self, request: ThirdReleaseSeatRequest
    ) -> ThirdReleaseSeatResponse:
        """Release seat.

        Args:
            request: ThirdReleaseSeatRequest with seat details

        Returns:
            ThirdReleaseSeatResponse: Response with operation result

        Example:
            >>> request = ThirdReleaseSeatRequest(
            ...     space_structure_ak="SPACE123",
            ...     seat_list={"SEATINFO": [{"SEATID": 1}]}
            ... )
            >>> response = service.release_seat(request)
            >>> if response.error.is_success:
            ...     print("Seat released")
        """
        payload = {"urn:ReleaseSeat": {"ReleaseSeatReq": request.to_dict()}}
        response = self.send_request(payload)
        return ThirdReleaseSeatResponse.from_dict(
            response["ReleaseSeatResponse"]["return"]
        )

    def download_external_pdf(
        self, request: DownloadExternalPDFRequest
    ) -> DownloadExternalPDFResponse:
        """Download external PDF.

        Args:
            request: DownloadExternalPDFRequest with sale AK

        Returns:
            DownloadExternalPDFResponse: Response containing PDF data

        Example:
            >>> request = DownloadExternalPDFRequest(sale_ak="SALE123")
            >>> response = service.download_external_pdf(request)
            >>> if response.error.is_success:
            ...     pdf_data = response.pdf
        """
        payload = {
            "urn:DownloadExternalPDF": {"DownloadExternalPDFReq": request.to_dict()}
        }
        response = self.send_request(payload)
        return DownloadExternalPDFResponse.from_dict(
            response["DownloadExternalPDFResponse"]["return"]
        )

    def get_account_by_uuid(
        self, request: GetAccountByUUIDRequest
    ) -> GetAccountByUUIDResponse:
        """Get account by UUID.

        Args:
            request: GetAccountByUUIDRequest with UUID

        Returns:
            GetAccountByUUIDResponse: Response containing account AK and canal list

        Example:
            >>> request = GetAccountByUUIDRequest(uuid="uuid-123")
            >>> response = service.get_account_by_uuid(request)
            >>> if response.error.is_success:
            ...     print(f"Account: {response.account_ak}")
        """
        payload = {
            "urn:GetAccountByUUID": {"GetAccountByUUIDReq": request.to_dict()}
        }
        response = self.send_request(payload)
        return GetAccountByUUIDResponse.from_dict(
            response["GetAccountByUUIDResponse"]["return"]
        )

    def set_canal_by_account_ak(
        self, request: SetCanalByAccountAKRequest
    ) -> SetCanalByAccountAKResponse:
        """Set canal by account AK.

        Args:
            request: SetCanalByAccountAKRequest with account AK and canal

        Returns:
            SetCanalByAccountAKResponse: Response with operation result

        Example:
            >>> request = SetCanalByAccountAKRequest(
            ...     account_ak="ACC123",
            ...     canal="CANAL001"
            ... )
            >>> response = service.set_canal_by_account_ak(request)
            >>> if response.error.is_success:
            ...     print(f"Set canal for: {response.account_ak}")
        """
        payload = {
            "urn:SetCanalByAccountAK": {"SetCanalByAccountAKReq": request.to_dict()}
        }
        response = self.send_request(payload)
        return SetCanalByAccountAKResponse.from_dict(
            response["SetCanalByAccountAKResponse"]["return"]
        )

    def release_performance_by_uuid(
        self, request: ReleasePerformanceByUUIDRequest
    ) -> ReleasePerformanceByUUIDResponse:
        """Release performance by UUID.

        Args:
            request: ReleasePerformanceByUUIDRequest with UUID and performance details

        Returns:
            ReleasePerformanceByUUIDResponse: Response with operation result

        Example:
            >>> request = ReleasePerformanceByUUIDRequest(
            ...     uuid="uuid-123",
            ...     performance_ak="PERF123",
            ...     space_structure_ak="SPACE123"
            ... )
            >>> response = service.release_performance_by_uuid(request)
            >>> if response.error.is_success:
            ...     print("Performance released")
        """
        payload = {
            "urn:ReleasePerformanceByUUID": {
                "ReleasePerformanceByUUIDReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReleasePerformanceByUUIDResponse.from_dict(
            response["ReleasePerformanceByUUIDResponse"]["return"]
        )

    def release_performance_by_ticket_id(
        self, request: ReleasePerformanceByTicketIdRequest
    ) -> ReleasePerformanceByTicketIdResponse:
        """Release performance by ticket ID.

        Args:
            request: ReleasePerformanceByTicketIdRequest with ticket ID

        Returns:
            ReleasePerformanceByTicketIdResponse: Response with operation result

        Example:
            >>> request = ReleasePerformanceByTicketIdRequest(
            ...     ticket_id=12345,
            ...     performance_ak="PERF123"
            ... )
            >>> response = service.release_performance_by_ticket_id(request)
            >>> if response.error.is_success:
            ...     print("Performance released")
        """
        payload = {
            "urn:ReleasePerformanceByTicketId": {
                "ReleasePerformanceByTicketIdReq": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReleasePerformanceByTicketIdResponse.from_dict(
            response["ReleasePerformanceByTicketIdResponse"]["return"]
        )

    def bottom_line_pay(
        self, request: BottomLinePayRequest
    ) -> BottomLinePayResponse:
        """Bottom line pay.

        Args:
            request: BottomLinePayRequest with payment details

        Returns:
            BottomLinePayResponse: Response with operation result

        Example:
            >>> request = BottomLinePayRequest(
            ...     sale_ak="SALE123",
            ...     payment_code="PM001",
            ...     amount=100.0
            ... )
            >>> response = service.bottom_line_pay(request)
            >>> if response.error.is_success:
            ...     print("Payment processed")
        """
        payload = {"urn:BottomLinePay": {"BottomLinePayReq": request.to_dict()}}
        response = self.send_request(payload)
        return BottomLinePayResponse.from_dict(
            response["BottomLinePayResponse"]["return"]
        )
