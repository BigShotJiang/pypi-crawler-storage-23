from ..base_service import BaseService
from ..types.performanceenquiry import (
    ReadPerformanceByDateRequest,
    ReadPerformanceByDateResponse,
    ReadPerformanceByAKResponse,
    ReadSpaceStructureByAKResponse,
    GetCalendarAvailabilityRequest,
    GetCalendarAvailabilityResponse,
    FindAllPerformanceByCategoriesRequest,
    FindAllPerformanceByCategoriesResponse,
    FindAllPerformanceProductByAKRequest,
    FindAllPerformanceProductByAKResponse,
    FindAllPerformanceProductByAKV2Response,
    FindAllPerformanceProductAndAttributeByAKRequest,
    FindAllPerformanceProductAndAttributeByAKResponse,
    FindPerformanceCapacityByAKResponse,
    FindPerformanceCapacityAndProductByAKRequest,
    FindPerformanceCapacityAndProductByAKResponse,
    SearchPerformanceRequest,
    SearchPerformanceResponse,
    SearchCalendarAvailabilityRequest,
    SearchCalendarAvailabilityResponse,
    ChangePerformanceStatusRequest,
    ChangePerformanceStatusResponse,
    SearchPerformanceEntriesRequest,
    SearchPerformanceEntriesResponse,
    SetPerformancePriceRequest,
    SetPerformancePriceResponse,
    GetDaysAvailabilityRequest,
    GetDaysAvailabilityResponse,
    GetDayPerformancesRequest,
    GetDayPerformancesResponse,
    FindPerformanceBlockedByLimitRequest,
    FindPerformanceBlockedByLimitResponse,
    CreatePerformancesRequest,
    CreatePerformancesResponse,
    UpdatePerformancesRequest,
    UpdatePerformancesResponse,
    GetPerformanceTotalUsagesRequest,
    GetPerformanceTotalUsagesResponse,
)


class PerformanceService(BaseService):
    """Call related to the performance service"""

    def create_performances(
        self,
        event_ak: str,
        dmg_category_ak: str,
        event_location_admission_profile: bool,
        price_table_ak: str,
        performance_name: str,
        performance_code: str,
        date_from: str,
        date_to: str,
        performance_quantity_per_timeslot: int,
        week_days: list[str],
        start_time: str,
        end_time: str,
        duration: int,
        duration_type: str,
        location_ak: str,
        access_configuration_id: str,
        waitlist_enabled: str,
        minutes_on_screen: int,
        time_opening: int,
        time_limit: int,
    ):
        """Creates a performance"""

        week_days_selected = {
            "MONDAY": "false",
            "TUESDAY": "false",
            "WEDNESDAY": "false",
            "THURSDAY": "false",
            "FRIDAY": "false",
            "SATURDAY": "false",
            "SUNDAY": "false",
        }

        for day in week_days:
            week_days_selected[day.upper()] = "true"

        payload = {
            "urn:CreatePerformances": {
                "CREATEPERFORMANCESREQ": {
                    "EVENTAK": event_ak,
                    "DMGCATEGORYAK": dmg_category_ak,
                    "EVENTLOCATIONANDADMPROFILE": event_location_admission_profile,
                    "PRICETABLEAK": price_table_ak,
                    "PERFORMANCENAME": performance_name,
                    "PERFORMANCECODE": performance_code,
                    "WAITLISTENABLED": waitlist_enabled,
                    "LOCATIONAK": location_ak,
                    "ACCESSCONFIGURATIONID": access_configuration_id,
                    "SCHEDULE": {
                        "PERFQTYPERTIMESLOT": performance_quantity_per_timeslot,
                        "DATEFROM": date_from,
                        "DATETO": date_to,
                        "MONDAY": week_days_selected["MONDAY"],
                        "TUESDAY": week_days_selected["TUESDAY"],
                        "WEDNESDAY": week_days_selected["WEDNESDAY"],
                        "THURSDAY": week_days_selected["THURSDAY"],
                        "FRIDAY": week_days_selected["FRIDAY"],
                        "SATURDAY": week_days_selected["SATURDAY"],
                        "SUNDAY": week_days_selected["SUNDAY"],
                        "FIXEDTIMESELECTIONLIST": {
                            "FIXEDTIMESELECTION": {
                                "STARTTIME": start_time,
                                "ENDTIME": end_time,
                                "DURATION": duration,
                                "DURATIONTYPE": duration_type,
                                "MINUTESONSCREEN": minutes_on_screen,
                                "TIMEOPENING": time_opening,
                                "TIMELIMIT": time_limit,
                            }
                        },
                    },
                }
            }
        }

        response = self.send_request(payload)
        return response["CreatePerformancesResponse"]["return"]

    def update_performance(
        self,
        performance_ak: str,
        performance_name: str,
        performance_code: str,
        performance_description: str,
    ):
        """Updates a performance"""

        payload = {
            "urn:UpdatePerformances": {
                "UPDATEPERFORMANCESREQ": {
                    "PERFORMANCELIST": {
                        "PERFORMANCEAK": {"AK": performance_ak},
                    },
                    "PERFORMANCENAME": performance_name,
                    "PERFORMANCECODE": performance_code,
                    "PERFORMANCEDESCRIPTION": performance_description,
                }
            }
        }

        response = self.send_request(payload)
        return response["UpdatePerformancesResponse"]["return"]

    def update_performance_status(
        self,
        event_ak: str,
        date_from: str,
        date_to: str,
        start_time: str,
        end_time: str,
        status: int
    ) -> dict:
        """Updates a performance status"""
        payload = {
            "urn:ChangePerformanceStatus": {
                "CHANGEPERFORMANCESTATUSREQ": {
                    "SEARCHPERFORMANCE": {
                        "MULTIPLE": {
                            "DATE":{
                                "FROM": date_from,
                                "TO": date_to,
                            },
                            "TIME":{
                                "FROM": start_time,
                                "TO": end_time,
                            },
                            "EVENTAK": event_ak,
                        },
                    },
                    "PERFSTATUS": status,
                },
            },
        }

        response = self.send_request(payload)
        return response["ChangePerformanceStatusResponse"]["return"]

    def read_performance_by_date(
        self, request: ReadPerformanceByDateRequest
    ) -> ReadPerformanceByDateResponse:
        """Read performances by date range."""
        payload = {
            "urn:ReadPerformanceByDate": {
                "READPERFORMANCEBYDATEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadPerformanceByDateResponse.from_dict(response["ReadPerformanceByDateResponse"]["return"])

    def read_performance_by_ak(
        self, performance_ak: str
    ) -> ReadPerformanceByAKResponse:
        """Read performance by AK."""
        payload = {
            "urn:ReadPerformanceByAK": {
                "APerformanceAK": performance_ak
            }
        }
        response = self.send_request(payload)
        return ReadPerformanceByAKResponse.from_dict(response["ReadPerformanceByAKResponse"]["return"])

    def read_space_structure_by_ak(
        self, space_structure_ak: str
    ) -> ReadSpaceStructureByAKResponse:
        """Read space structure by AK."""
        payload = {
            "urn:ReadSpaceStructureByAK": {
                "ASpaceStructureAK": space_structure_ak
            }
        }
        response = self.send_request(payload)
        return ReadSpaceStructureByAKResponse.from_dict(response["ReadSpaceStructureByAKResponse"]["return"])

    def get_calendar_availability(
        self, request: GetCalendarAvailabilityRequest
    ) -> GetCalendarAvailabilityResponse:
        """Get calendar availability for an event."""
        payload = {
            "urn:GetCalendarAvailability": {
                "GETCALENDARAVAILABILITYREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return GetCalendarAvailabilityResponse.from_dict(response["GetCalendarAvailabilityResponse"]["return"])

    def search_calendar_availability(
        self, request: SearchCalendarAvailabilityRequest
    ) -> SearchCalendarAvailabilityResponse:
        """Search calendar availability with filters."""
        payload = {
            "urn:SearchCalendarAvailability": {
                "SEARCHCALENDARAVAILABILITYREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchCalendarAvailabilityResponse.from_dict(response["SearchCalendarAvailabilityResponse"]["return"])

    def find_all_performance_by_categories(
        self, request: FindAllPerformanceByCategoriesRequest
    ) -> FindAllPerformanceByCategoriesResponse:
        """Find all performances by categories."""
        payload = {
            "urn:FindAllPerformanceByCategories": {
                "FINDALLPERFORMANCEBYCATEGORIESREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return FindAllPerformanceByCategoriesResponse.from_dict(response["FindAllPerformanceByCategoriesResponse"]["return"])

    def find_all_performance_product_by_ak(
        self, request: FindAllPerformanceProductByAKRequest
    ) -> FindAllPerformanceProductByAKResponse:
        """Find all performance products by AK."""
        payload = {
            "urn:FindAllPerformanceProductByAk": {
                "FINDALLPERFORMANCEPRODUCTBYAKREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return FindAllPerformanceProductByAKResponse.from_dict(response["FindAllPerformanceProductByAkResponse"]["return"])

    def find_all_performance_product_by_ak_v2(
        self, request: FindAllPerformanceProductByAKRequest
    ) -> FindAllPerformanceProductByAKV2Response:
        """Find all performance products by AK (V2)."""
        payload = {
            "urn:FindAllPerformanceProductByAkV2": {
                "FINDALLPERFORMANCEPRODUCTBYAKREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return FindAllPerformanceProductByAKV2Response.from_dict(response["FindAllPerformanceProductByAkV2Response"]["return"])

    def find_all_performance_product_and_attribute_by_ak(
        self, request: FindAllPerformanceProductAndAttributeByAKRequest
    ) -> FindAllPerformanceProductAndAttributeByAKResponse:
        """Find all performance products and attributes by AK."""
        payload = {
            "urn:FindAllPerformanceProductAndAttributeByAk": {
                "FINDALLPERFORMANCEPRODUCTANDATTRIBUTEBYAKREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return FindAllPerformanceProductAndAttributeByAKResponse.from_dict(response["FindAllPerformanceProductAndAttributeByAkResponse"]["return"])

    def find_performance_capacity_by_ak(
        self, performance_ak: str
    ) -> FindPerformanceCapacityByAKResponse:
        """Find performance capacity by AK."""
        payload = {
            "urn:FindPerformanceCapacityByAk": {
                "APerformanceAK": performance_ak
            }
        }
        response = self.send_request(payload)
        return FindPerformanceCapacityByAKResponse.from_dict(response["FindPerformanceCapacityByAkResponse"]["return"])

    def find_performance_capacity_and_product_by_ak(
        self, request: FindPerformanceCapacityAndProductByAKRequest
    ) -> FindPerformanceCapacityAndProductByAKResponse:
        """Find performance capacity and products by AK."""
        payload = {
            "urn:FindPerformanceCapacityAndProduct": {
                "FINDPERFORMANCECAPACITYANDPRODUCTBYAKREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return FindPerformanceCapacityAndProductByAKResponse.from_dict(response["FindPerformanceCapacityAndProductResponse"]["return"])

    def search_performance(
        self, request: SearchPerformanceRequest
    ) -> SearchPerformanceResponse:
        """Search performances with filters."""
        payload = {
            "urn:SearchPerformance": {
                "SEARCHPERFORMANCEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchPerformanceResponse.from_dict(response["SearchPerformanceResponse"]["return"])

    def change_performance_status(
        self, request: ChangePerformanceStatusRequest
    ) -> ChangePerformanceStatusResponse:
        """Change performance status."""
        payload = {
            "urn:ChangePerformanceStatus": {
                "CHANGEPERFORMANCESTATUSREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ChangePerformanceStatusResponse.from_dict(response["ChangePerformanceStatusResponse"]["return"])

    def search_performance_entries(
        self, request: SearchPerformanceEntriesRequest
    ) -> SearchPerformanceEntriesResponse:
        """Search performance entries."""
        payload = {
            "urn:SearchPerformanceEntries": {
                "SEARCHPERFORMANCEENTRIESREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchPerformanceEntriesResponse.from_dict(response["SearchPerformanceEntriesResponse"]["return"])

    def set_performance_price(
        self, request: SetPerformancePriceRequest
    ) -> SetPerformancePriceResponse:
        """Set performance price."""
        payload = {
            "urn:SetPerformancePrice": {
                "SETPERFORMANCEPRICEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SetPerformancePriceResponse.from_dict(response["SetPerformancePriceResponse"]["return"])

    def get_days_availability(
        self, request: GetDaysAvailabilityRequest
    ) -> GetDaysAvailabilityResponse:
        """Get days availability."""
        payload = {
            "urn:GetDaysAvailability": {
                "GETDAYSAVAILABILITYREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return GetDaysAvailabilityResponse.from_dict(response["GetDaysAvailabilityResponse"]["return"])

    def get_day_performances(
        self, request: GetDayPerformancesRequest
    ) -> GetDayPerformancesResponse:
        """Get day performances."""
        payload = {
            "urn:GetDayPerformances": {
                "GETDAYPERFORMANCESREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return GetDayPerformancesResponse.from_dict(response["GetDayPerformancesResponse"]["return"])

    def find_performance_blocked_by_limit(
        self, request: FindPerformanceBlockedByLimitRequest
    ) -> FindPerformanceBlockedByLimitResponse:
        """Find performances blocked by limit."""
        payload = {
            "urn:FindPerformanceBlockedByLimit": {
                "FINDPERFORMANCEBLOCKEDBYLIMITREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return FindPerformanceBlockedByLimitResponse.from_dict(response["FindPerformanceBlockedByLimitResponse"]["return"])

    def update_performances(
        self, request: UpdatePerformancesRequest
    ) -> UpdatePerformancesResponse:
        """Update performances."""
        payload = {
            "urn:UpdatePerformances": {
                "UPDATEPERFORMANCESREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return UpdatePerformancesResponse.from_dict(response["UpdatePerformancesResponse"]["return"])

    def get_performance_total_usages(
        self, request: GetPerformanceTotalUsagesRequest
    ) -> GetPerformanceTotalUsagesResponse:
        """Get performance total usages."""
        payload = {
            "urn:GetPerformanceTotalUsages": {
                "GETPERFORMANCETOTALUSAGESREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return GetPerformanceTotalUsagesResponse.from_dict(response["GetPerformanceTotalUsagesResponse"]["return"])
