"""
Resource Management service for the BOS API.

This service provides methods for resource management operations including
search, availability checking, and template management.
"""

from ..base_service import BaseService
from ..types.resourceenquiry import (
    SearchResourceAvailabilityRequest,
    SearchResourceAvailabilityResponse,
    SearchResourceRequest,
    SearchResourceResponse,
    SearchRequirementTemplatesAndTemplateSetsRequest,
    SearchRequirementTemplatesAndTemplateSetsResponse,
    SetTemplateSetRequest,
    SetTemplateSetResponse,
)


class ResourceManagementService(BaseService):
    """Service for BOS resource management operations.

    This service provides methods for resource management, search, availability
    checking, and template management in the BOS system. All complex data
    structures use typed classes instead of dictionaries for better IDE support
    and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIResourceManagement")

    Example:
        >>> service = ResourceManagementService(bos_api, "IWsAPIResourceManagement")
        >>> from ..types.common import BaseDateFilter
        >>> request = SearchResourceAvailabilityRequest(
        ...     date=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31")
        ... )
        >>> response = service.search_resource_availability(request)
        >>> if response.error.is_success:
        ...     print(f"Found {len(response.resource_schedule_list)} schedules")
    """

    def search_resource_availability(
        self, request: SearchResourceAvailabilityRequest
    ) -> SearchResourceAvailabilityResponse:
        """Search resource availability.

        Args:
            request: SearchResourceAvailabilityRequest with date and filters

        Returns:
            SearchResourceAvailabilityResponse: Response containing resource schedules

        Example:
            >>> from ..types.common import BaseDateFilter
            >>> request = SearchResourceAvailabilityRequest(
            ...     date=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31"),
            ...     resource_filter_list=["RES123"]
            ... )
            >>> response = service.search_resource_availability(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.resource_schedule_list)} schedules")
        """
        payload = {
            "urn:SearchResourceAvailability": {
                "SEARCHRESOURCEAVAILABILITYREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchResourceAvailabilityResponse.from_dict(
            response["SearchResourceAvailabilityResponse"]["return"]
        )

    def search_resource(
        self, request: SearchResourceRequest
    ) -> SearchResourceResponse:
        """Search for resources.

        Args:
            request: SearchResourceRequest with search criteria

        Returns:
            SearchResourceResponse: Response containing list of resources

        Example:
            >>> from ..types.common import BaseDateFilter
            >>> request = SearchResourceRequest(
            ...     date=BaseDateFilter(from_date="2024-01-01", to_date="2024-12-31"),
            ...     disabled=False
            ... )
            >>> response = service.search_resource(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.resource_list)} resources")
        """
        payload = {
            "urn:SearchResource": {"SEARCHRESOURCEREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SearchResourceResponse.from_dict(
            response["SearchResourceResponse"]["return"]
        )

    def search_requirement_templates_and_template_sets(
        self, request: SearchRequirementTemplatesAndTemplateSetsRequest
    ) -> SearchRequirementTemplatesAndTemplateSetsResponse:
        """Search requirement templates and template sets.

        Args:
            request: SearchRequirementTemplatesAndTemplateSetsRequest with filters

        Returns:
            SearchRequirementTemplatesAndTemplateSetsResponse: Response containing requirements

        Example:
            >>> request = SearchRequirementTemplatesAndTemplateSetsRequest(
            ...     event_filter_list=["EVENT123"]
            ... )
            >>> response = service.search_requirement_templates_and_template_sets(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.requirement_list)} requirements")
        """
        payload = {
            "urn:SearchRequirementTemplatesAndTemplateSets": {
                "SEARCHREQUIREMENTTEMPLATESANDTEMPLATESETSREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchRequirementTemplatesAndTemplateSetsResponse.from_dict(
            response["SearchRequirementTemplatesAndTemplateSetsResponse"]["return"]
        )

    def set_template_set(
        self, request: SetTemplateSetRequest
    ) -> SetTemplateSetResponse:
        """Set template set for a performance.

        Args:
            request: SetTemplateSetRequest with performance and requirement AK

        Returns:
            SetTemplateSetResponse: Response with operation result

        Example:
            >>> request = SetTemplateSetRequest(
            ...     performance_ak="PERF123",
            ...     requirement_ak="REQ123"
            ... )
            >>> response = service.set_template_set(request)
            >>> if response.error.is_success:
            ...     print("Template set updated")
        """
        payload = {
            "urn:SetTemplateSet": {"SETTEMPLATESETREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SetTemplateSetResponse.from_dict(
            response["SetTemplateSetResponse"]["return"]
        )
