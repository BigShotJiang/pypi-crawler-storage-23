"""
Seasonal Price service for the BOS API.

This service provides methods for seasonal price information operations.
"""

from ..base_service import BaseService
from ..types.seasonalpriceenquiry import ReadSeasonalPriceInfoResponse


class SeasonalPriceService(BaseService):
    """Service for BOS seasonal price operations.

    This service provides methods for reading seasonal price information in the
    BOS system. All complex data structures use typed classes instead of
    dictionaries for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPISeasonalPrice")

    Example:
        >>> service = SeasonalPriceService(bos_api, "IWsAPISeasonalPrice")
        >>> response = service.read_seasonal_price_info()
        >>> if response.error.is_success:
        ...     print(f"Found {len(response.rule_list)} rules")
    """

    def read_seasonal_price_info(self) -> ReadSeasonalPriceInfoResponse:
        """Read seasonal price information.

        Returns:
            ReadSeasonalPriceInfoResponse: Response containing seasonal price data

        Example:
            >>> response = service.read_seasonal_price_info()
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.rule_list)} rules")
            ...     print(f"Found {len(response.price_table_list)} price tables")
            ...     print(f"Found {len(response.ticket_list)} tickets")
        """
        payload = {"urn:ReadSeasonalPriceInfo": None}
        response = self.send_request(payload)
        return ReadSeasonalPriceInfoResponse.from_dict(
            response["ReadSeasonalPriceInfoResponse"]["return"]
        )
