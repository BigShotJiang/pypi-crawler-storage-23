"""
Mask service for the BOS API.

This service provides methods for mask operations including reading account
categories, extended info, data providers, images, and attachments.
"""

from ..base_service import BaseService
from ..types.maskenquiry import (
    FindAllAccountCategoriesResponse,
    ReadAccountCategoryByCodeResponse,
    ReadAccountCategoryByAKResponse,
    ReadExtendedInfoByAKResponse,
    ReadExtendedInfoByCodeResponse,
    ReadDataProviderByCodeResponse,
    ReadImageByAKResponse,
    ReadAttachmentByAKResponse,
    SearchDataMaskRequest,
    SearchDataMaskResponse,
    SaveDmgTranslationRequest,
    SaveDmgTranslationResponse,
    SaveMaskTableItemRequest,
    SaveMaskTableItemResponse,
)


class MaskService(BaseService):
    """Service for BOS mask operations.

    This service provides methods for mask management including reading account
    categories, extended info, data providers, images, and attachments in the
    BOS system. All complex data structures use typed classes instead of
    dictionaries for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIMask")

    Example:
        >>> service = MaskService(bos_api, "IWsAPIMask")
        >>> response = service.find_all_account_categories()
        >>> if response.error.is_success:
        ...     print(f"Found {len(response.dmg_category_list)} categories")
    """

    def find_all_account_categories(
        self,
    ) -> FindAllAccountCategoriesResponse:
        """Find all account categories.

        Returns:
            FindAllAccountCategoriesResponse: Response containing list of categories

        Example:
            >>> response = service.find_all_account_categories()
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.dmg_category_list)} categories")
        """
        payload = {"urn:FindAllAccountCategories": None}
        response = self.send_request(payload)
        return FindAllAccountCategoriesResponse.from_dict(
            response["FindAllAccountCategoriesResponse"]["return"]
        )

    def read_account_category_by_code(
        self, dmg_category_code: str
    ) -> ReadAccountCategoryByCodeResponse:
        """Read account category by code.

        Args:
            dmg_category_code: Demographic category code

        Returns:
            ReadAccountCategoryByCodeResponse: Response containing category details

        Example:
            >>> response = service.read_account_category_by_code("CAT001")
            >>> if response.error.is_success:
            ...     print(f"Category: {response.dmg_category.get('NAME')}")
        """
        payload = {
            "urn:ReadAccountCategoryByCode": {
                "ADmgCategoryCode": dmg_category_code
            }
        }
        response = self.send_request(payload)
        return ReadAccountCategoryByCodeResponse.from_dict(
            response["ReadAccountCategoryByCodeResponse"]["return"]
        )

    def read_account_category_by_ak(
        self, dmg_category_ak: str
    ) -> ReadAccountCategoryByAKResponse:
        """Read account category by AK.

        Args:
            dmg_category_ak: Demographic category AK

        Returns:
            ReadAccountCategoryByAKResponse: Response containing category details

        Example:
            >>> response = service.read_account_category_by_ak("CAT123")
            >>> if response.error.is_success:
            ...     print(f"Category: {response.dmg_category.get('NAME')}")
        """
        payload = {
            "urn:ReadAccountCategoryByAK": {"ADmgCategoryAK": dmg_category_ak}
        }
        response = self.send_request(payload)
        return ReadAccountCategoryByAKResponse.from_dict(
            response["ReadAccountCategoryByAKResponse"]["return"]
        )

    def read_extended_info_by_ak(
        self, dmg_category_ak: str
    ) -> ReadExtendedInfoByAKResponse:
        """Read extended info by AK.

        Args:
            dmg_category_ak: Demographic category AK

        Returns:
            ReadExtendedInfoByAKResponse: Response containing extended info

        Example:
            >>> response = service.read_extended_info_by_ak("CAT123")
            >>> if response.error.is_success:
            ...     print("Extended info retrieved")
        """
        payload = {"urn:ReadExtendedInfoByAK": {"ADmgCategoryAK": dmg_category_ak}}
        response = self.send_request(payload)
        return ReadExtendedInfoByAKResponse.from_dict(
            response["ReadExtendedInfoByAKResponse"]["return"]
        )

    def read_extended_info_by_code(
        self, dmg_category_code: str
    ) -> ReadExtendedInfoByCodeResponse:
        """Read extended info by code.

        Args:
            dmg_category_code: Demographic category code

        Returns:
            ReadExtendedInfoByCodeResponse: Response containing extended info

        Example:
            >>> response = service.read_extended_info_by_code("CAT001")
            >>> if response.error.is_success:
            ...     print("Extended info retrieved")
        """
        payload = {
            "urn:ReadExtendedInfoByCode": {"ADmgCategoryCode": dmg_category_code}
        }
        response = self.send_request(payload)
        return ReadExtendedInfoByCodeResponse.from_dict(
            response["ReadExtendedInfoByCodeResponse"]["return"]
        )

    def read_data_provider_by_code(
        self, data_provider_code: str, lang_code: str
    ) -> ReadDataProviderByCodeResponse:
        """Read data provider by code.

        Args:
            data_provider_code: Data provider code
            lang_code: Language code

        Returns:
            ReadDataProviderByCodeResponse: Response containing data provider details

        Example:
            >>> response = service.read_data_provider_by_code("PROV001", "en")
            >>> if response.error.is_success:
            ...     print(f"Provider: {response.data_provider.get('NAME')}")
        """
        payload = {
            "urn:ReadDataProviderByCode": {
                "ADataProviderCode": data_provider_code,
                "ALangCode": lang_code,
            }
        }
        response = self.send_request(payload)
        return ReadDataProviderByCodeResponse.from_dict(
            response["ReadDataProviderByCodeResponse"]["return"]
        )

    def read_image_by_ak(self, image_ak: str) -> ReadImageByAKResponse:
        """Read image by AK.

        Args:
            image_ak: Image AK

        Returns:
            ReadImageByAKResponse: Response containing image data

        Example:
            >>> response = service.read_image_by_ak("IMG123")
            >>> if response.error.is_success:
            ...     image_value = response.image.get("VALUE")
        """
        payload = {"urn:ReadImageByAK": {"AImageAK": image_ak}}
        response = self.send_request(payload)
        return ReadImageByAKResponse.from_dict(
            response["ReadImageByAKResponse"]["return"]
        )

    def read_attachment_by_ak(
        self, attachment_ak: str
    ) -> ReadAttachmentByAKResponse:
        """Read attachment by AK.

        Args:
            attachment_ak: Attachment AK

        Returns:
            ReadAttachmentByAKResponse: Response containing attachment data

        Example:
            >>> response = service.read_attachment_by_ak("ATT123")
            >>> if response.error.is_success:
            ...     attachment_value = response.attachment.get("VALUE")
        """
        payload = {"urn:ReadAttachmentByAK": {"AAttachmentAK": attachment_ak}}
        response = self.send_request(payload)
        return ReadAttachmentByAKResponse.from_dict(
            response["ReadAttachmentByAKResponse"]["return"]
        )

    def search_data_mask(
        self, request: SearchDataMaskRequest
    ) -> SearchDataMaskResponse:
        """Search data mask.

        Args:
            request: SearchDataMaskRequest with search criteria

        Returns:
            SearchDataMaskResponse: Response containing list of categories

        Example:
            >>> from ..types.common import PageRequest
            >>> request = SearchDataMaskRequest(
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_data_mask(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.dmg_category_list)} categories")
        """
        payload = {
            "urn:SearchDataMask": {"SEARCHDATAMASKREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SearchDataMaskResponse.from_dict(
            response["SearchDataMaskResponse"]["return"]
        )

    def save_dmg_translation(
        self, request: SaveDmgTranslationRequest
    ) -> SaveDmgTranslationResponse:
        """Save demographic translation.

        Args:
            request: SaveDmgTranslationRequest with translation data

        Returns:
            SaveDmgTranslationResponse: Response with operation result

        Example:
            >>> request = SaveDmgTranslationRequest(
            ...     dmg_type=7,  # 7=Event, 8=Performance
            ...     entity_ak="EVENT123",
            ...     field_list=[{"OBJTYPE": 1, "VALUE": "Translation"}]
            ... )
            >>> response = service.save_dmg_translation(request)
            >>> if response.error.is_success:
            ...     print("Translation saved")
        """
        payload = {
            "urn:SaveDmgTranslation": {"SAVEDMGTRANSLATIONREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SaveDmgTranslationResponse.from_dict(
            response["SaveDmgTranslationResponse"]["return"]
        )

    def save_mask_table_item(
        self, request: SaveMaskTableItemRequest
    ) -> SaveMaskTableItemResponse:
        """Save mask table item.

        Args:
            request: SaveMaskTableItemRequest with mask table item data

        Returns:
            SaveMaskTableItemResponse: Response with operation result

        Example:
            >>> request = SaveMaskTableItemRequest(
            ...     mask_table_item={"MASKAK": "MASK123", "VALUE": "Item"}
            ... )
            >>> response = service.save_mask_table_item(request)
            >>> if response.error.is_success:
            ...     print("Mask table item saved")
        """
        payload = {
            "urn:SaveMaskTableItem": {"SAVEMASKTABLEITEMREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SaveMaskTableItemResponse.from_dict(
            response["SaveMaskTableItemResponse"]["SAVEMASKTABLEITEMRESP"]
        )