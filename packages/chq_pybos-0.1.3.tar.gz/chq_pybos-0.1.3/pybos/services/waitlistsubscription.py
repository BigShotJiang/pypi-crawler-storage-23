from ..base_service import BaseService
from ..types import (
    SearchWaitListSubscriptionsRequest,
    SearchWaitListSubscriptionsV2Request,
    SubscribeRequest,
    SubscribeV2Request,
    UnSubscribeRequest,
    UnSubscribeV2Request,
    SearchWaitListSubscriptionsResponse,
    SearchWaitListSubscriptionsV2Response,
    SubscribeResponse,
    SubscribeV2Response,
    UnSubscribeResponse,
    UnSubscribeV2Response,
)


class WaitListSubscriptionService(BaseService):
    """Service for managing BOS waitlist subscriptions with improved developer ergonomics.

    This service provides methods for searching, subscribing, and unsubscribing from
    waitlist subscriptions in the BOS system. All complex data structures use typed
    classes instead of tuples for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            service_name: Name of the WSDL service (e.g., "IWsAPIWaitListSubscription")

    Example:
        >>> service = WaitListSubscriptionService(bos_api, "IWsAPIWaitListSubscription")
        >>> request = SearchWaitListSubscriptionsRequest(email="user@example.com")
        >>> result = service.search_waitlist_subscriptions(request)
        >>> print(f"Found {len(result.subscription_list)} subscriptions")
    """

    def search_waitlist_subscriptions(
        self, request: SearchWaitListSubscriptionsRequest
    ) -> SearchWaitListSubscriptionsResponse:
        """Search for waitlist subscriptions with structured request parameters.

        Args:
            request: SearchWaitListSubscriptionsRequest object with search criteria

        Returns:
            SearchWaitListSubscriptionsResponse: Search results with subscription list

        Example:
            >>> request = SearchWaitListSubscriptionsRequest(
            ...     email="user@example.com",
            ...     performance_ak="perf123"
            ... )
            >>> response = service.search_waitlist_subscriptions(request)
            >>> for sub in response.subscription_list:
            ...     print(f"Subscription: {sub.email} for {sub.performance_ak}")
        """
        payload = {
            "urn:SearchWaitListSubscriptions": {
                "SEARCHWAITLISTSUBSCRIPTIONSREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchWaitListSubscriptionsResponse.from_dict(
            response["SearchWaitListSubscriptionsResponse"]["return"]
        )

    def search_waitlist_subscriptions_v2(
        self, request: SearchWaitListSubscriptionsV2Request
    ) -> SearchWaitListSubscriptionsV2Response:
        """Search for waitlist subscriptions V2 with structured request parameters.

        Args:
            request: SearchWaitListSubscriptionsV2Request object with search criteria

        Returns:
            SearchWaitListSubscriptionsV2Response: Search results with subscription list V2

        Example:
            >>> request = SearchWaitListSubscriptionsV2Request(
            ...     email="user@example.com",
            ...     search_choice={"SEARCHSINGLE": {"PERFORMANCEAK": "perf123"}}
            ... )
            >>> response = service.search_waitlist_subscriptions_v2(request)
            >>> print(f"Found {len(response.subscription_list)} subscriptions")
        """
        payload = {
            "urn:SearchWaitListSubscriptionsV2": {
                "SEARCHWAITLISTSUBSCRIPTIONS_V2REQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchWaitListSubscriptionsV2Response.from_dict(
            response["SearchWaitListSubscriptionsV2Response"]["return"]
        )

    def subscribe(self, request: SubscribeRequest) -> SubscribeResponse:
        """Subscribe to a waitlist with structured request parameters.

        Args:
            request: SubscribeRequest object with subscription details

        Returns:
            SubscribeResponse: Subscription response with created subscription item

        Example:
            >>> request = SubscribeRequest(
            ...     email="user@example.com",
            ...     performance_ak="perf123",
            ...     qty=2,
            ...     seat_category_code="VIP"
            ... )
            >>> response = service.subscribe(request)
            >>> if response.error.is_success:
            ...     print("Successfully subscribed to waitlist")
        """
        payload = {"urn:Subscribe": {"SUBSCRIBEREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SubscribeResponse.from_dict(response["SubscribeResponse"]["return"])

    def subscribe_v2(self, request: SubscribeV2Request) -> SubscribeV2Response:
        """Subscribe to a waitlist V2 with structured request parameters.

        Args:
            request: SubscribeV2Request object with subscription details

        Returns:
            SubscribeV2Response: Subscription response with created subscription item V2

        Example:
            >>> request = SubscribeV2Request(
            ...     email="user@example.com",
            ...     qty=2,
            ...     subscription_type=1,
            ...     choice={"SINGLE": {"PERFORMANCEAK": "perf123"}}
            ... )
            >>> response = service.subscribe_v2(request)
            >>> if response.error.is_success:
            ...     print("Successfully subscribed to waitlist V2")
        """
        payload = {"urn:SubscribeV2": {"SUBSCRIBE_V2REQ": request.to_dict()}}
        response = self.send_request(payload)
        return SubscribeV2Response.from_dict(response["SubscribeV2Response"]["return"])

    def unsubscribe(self, request: UnSubscribeRequest) -> UnSubscribeResponse:
        """Unsubscribe from a waitlist with structured request parameters.

        Args:
            request: UnSubscribeRequest object with unsubscription details

        Returns:
            UnSubscribeResponse: Unsubscription response with removed subscription item

        Example:
            >>> request = UnSubscribeRequest(
            ...     email="user@example.com",
            ...     performance_ak="perf123"
            ... )
            >>> response = service.unsubscribe(request)
            >>> if response.error.is_success:
            ...     print("Successfully unsubscribed from waitlist")
        """
        payload = {"urn:UnSubscribe": {"UNSUBSCRIBEREQ": request.to_dict()}}
        response = self.send_request(payload)
        return UnSubscribeResponse.from_dict(response["UnSubscribeResponse"]["return"])

    def unsubscribe_v2(self, request: UnSubscribeV2Request) -> UnSubscribeV2Response:
        """Unsubscribe from a waitlist V2 with structured request parameters.

        Args:
            request: UnSubscribeV2Request object with unsubscription details

        Returns:
            UnSubscribeV2Response: Unsubscription response with removed subscription item V2

        Example:
            >>> request = UnSubscribeV2Request(waitlist_subscription_id=12345)
            >>> response = service.unsubscribe_v2(request)
            >>> if response.error.is_success:
            ...     print("Successfully unsubscribed from waitlist V2")
        """
        payload = {"urn:UnSubscribeV2": {"UNSUBSCRIBE_V2REQ": request.to_dict()}}
        response = self.send_request(payload)
        return UnSubscribeV2Response.from_dict(
            response["UnSubscribeV2Response"]["return"]
        )
