"""
SIAE third party integration service for the BOS API.

This service provides methods for SIAE third party integration operations including
record import, user login, and user logout.
"""

from ..base_service import BaseService
from ..types.siaethirdpartyintegration import (
    ImportRecordLTARequest,
    ImportRecordLTAResponse,
    UserLoginThirdPartyRequest,
    UserLoginThirdPartyResponse,
    UserLogoutThirdPartyRequest,
    UserLogoutThirdPartyResponse,
)


class SiaeThirdPartyIntegrationService(BaseService):
    """Service for BOS SIAE third party integration operations with improved developer ergonomics.

    This service provides methods for SIAE third party integration, including
    record import and user authentication in the BOS system. All complex data
    structures use typed classes instead of dictionaries for better IDE support
    and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPISiaeThirdPartyIntegration")

    Example:
        >>> service = SiaeThirdPartyIntegrationService(bos_api, "IWsAPISiaeThirdPartyIntegration")
        >>> request = ImportRecordLTARequest(
        ...     tipo_record=0,
        ...     codice_esterno_ak="EXT123",
        ...     cf_organizzatore="CF123456",
        ...     tipo_genere="01",
        ...     codice_sistema_emissione="SYS001",
        ...     cf_sistema_emissione="CF789",
        ...     emissione=Emissione(...),
        ...     dati_supporto=DatiSupporto(...),
        ...     stato_titolo="01"
        ... )
        >>> response = service.import_record_lta(request)
        >>> if response.error.code == 200:
        ...     print("Record imported successfully")
    """

    def import_record_lta(
        self, request: ImportRecordLTARequest
    ) -> ImportRecordLTAResponse:
        """Import record LTA.

        Args:
            request: ImportRecordLTARequest with record data

        Returns:
            ImportRecordLTAResponse: Response containing import result

        Example:
            >>> from ..types.siaethirdpartyintegration import Emissione, DatiSupporto
            >>> request = ImportRecordLTARequest(
            ...     tipo_record=0,
            ...     codice_esterno_ak="EXT123",
            ...     cf_organizzatore="CF123456",
            ...     tipo_genere="01",
            ...     codice_sistema_emissione="SYS001",
            ...     cf_sistema_emissione="CF789",
            ...     emissione=Emissione(
            ...         codice_carta="CARD001",
            ...         progressivo=1,
            ...         sigillo="SIG001",
            ...         data="2024-01-01",
            ...         ora="10:00:00",
            ...         tipo_titolo="01",
            ...         corrispettivo_lordo=100.0,
            ...         ordine_di_posto="01",
            ...         iva_titolo=22.0
            ...     ),
            ...     dati_supporto=DatiSupporto(
            ...         codice_supporto="01",
            ...         identificativo_supporto="SUP001"
            ...     ),
            ...     stato_titolo="01"
            ... )
            >>> response = service.import_record_lta(request)
            >>> if response.error.code == 200:
            ...     print("Record imported successfully")
        """
        payload = {"urn:ImportRecordLTA": {"IMPORTRECORDLTAREQ": request.to_dict()}}
        response = self.send_request(payload)
        return ImportRecordLTAResponse.from_dict(
            response["ImportRecordLTAResponse"]["return"]
        )

    def user_login_third_party(
        self, request: UserLoginThirdPartyRequest
    ) -> UserLoginThirdPartyResponse:
        """User login third party.

        Args:
            request: UserLoginThirdPartyRequest with login credentials

        Returns:
            UserLoginThirdPartyResponse: Response containing session information

        Example:
            >>> request = UserLoginThirdPartyRequest(
            ...     workstation_ak="WS001",
            ...     username="user123",
            ...     password="password123"
            ... )
            >>> response = service.user_login_third_party(request)
            >>> if response.error.code == 200:
            ...     print(f"Logged in: {response.session_id}")
        """
        payload = {
            "urn:UserLoginThirdParty": {"USERLOGINTHIRDPARTYREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return UserLoginThirdPartyResponse.from_dict(
            response["UserLoginThirdPartyResponse"]["return"]
        )

    def user_logout_third_party(
        self, request: UserLogoutThirdPartyRequest
    ) -> UserLogoutThirdPartyResponse:
        """User logout third party.

        Args:
            request: UserLogoutThirdPartyRequest (empty request)

        Returns:
            UserLogoutThirdPartyResponse: Response containing logout result

        Example:
            >>> request = UserLogoutThirdPartyRequest()
            >>> response = service.user_logout_third_party(request)
            >>> if response.error.code == 200:
            ...     print("Logged out successfully")
        """
        payload = {
            "urn:UserLogoutThirdParty": {"USERLOGOUTTHIRDPARTYREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return UserLogoutThirdPartyResponse.from_dict(
            response["UserLogoutThirdPartyResponse"]["return"]
        )
