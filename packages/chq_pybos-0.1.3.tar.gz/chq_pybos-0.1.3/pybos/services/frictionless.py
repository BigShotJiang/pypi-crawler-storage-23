"""
Frictionless service for the BOS API.

This service provides methods for frictionless operations.
"""

from ..base_service import BaseService
from ..types.frictionless import (
    MediaCodeInfoRequest,
    MediaCodeInfoResponse,
)


class FrictionlessService(BaseService):
    """Service for BOS frictionless operations.

    This service provides methods for frictionless media code operations in the
    BOS system. All complex data structures use typed classes instead of
    dictionaries for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIFrictionless")

    Example:
        >>> service = FrictionlessService(bos_api, "IWsAPIFrictionless")
        >>> request = MediaCodeInfoRequest(media_code="MEDIA123")
        >>> response = service.media_code(request)
        >>> if response.error.is_success:
        ...     print(f"Status: {response.media_code_info.get('STATUS')}")
    """

    def media_code(
        self, request: MediaCodeInfoRequest
    ) -> MediaCodeInfoResponse:
        """Get media code information.

        Args:
            request: MediaCodeInfoRequest with media code

        Returns:
            MediaCodeInfoResponse: Response containing media code information

        Example:
            >>> request = MediaCodeInfoRequest(media_code="MEDIA123")
            >>> response = service.media_code(request)
            >>> if response.error.is_success:
            ...     print(f"Status: {response.media_code_info.get('STATUS')}")
            ...     print(f"Used: {response.media_code_info.get('USED')}")
        """
        payload = {
            "urn:MediaCode": {"MEDIACODEINFOREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return MediaCodeInfoResponse.from_dict(
            response["MediaCodeResponse"]["return"]
        )
