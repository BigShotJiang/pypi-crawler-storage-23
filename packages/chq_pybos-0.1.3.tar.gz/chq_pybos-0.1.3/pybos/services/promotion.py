"""
Promotion service for the BOS API.

This service provides methods for promotion operations including coupon validation,
package management, and promotion search.
"""

from ..base_service import BaseService
from ..types.promotionenquiry import (
    ValidateCouponCodeResponse,
    ReadPromotionByCodeResponse,
    ValidateCouponCodeByDmgCategoryResponse,
    FindAllPromotionResponse,
    ImportIndividualCodeRequest,
    ImportIndividualCodeResponse,
    ReadPackageByCodeResponse,
    ReadExternalPackageByCodeResponse,
    SearchPromotionRequest,
    SearchPromotionResponse,
    SearchPackageRequest,
    SearchPackageResponse,
    GetCouponQuotaPerAccountRequest,
    GetCouponQuotaPerAccountResponse,
    SearchIndividualCodeRequest,
    SearchIndividualCodeResponse,
    ValidatePackageCodeResponse,
)


class PromotionService(BaseService):
    """Service for BOS promotion operations with improved developer ergonomics.

    This service provides methods for promotion management, coupon validation,
    package operations, and promotion search in the BOS system. All complex data
    structures use typed classes instead of dictionaries for better IDE support
    and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIPromotion")

    Example:
        >>> service = PromotionService(bos_api, "IWsAPIPromotion")
        >>> response = service.validate_coupon_code("COUPON123")
        >>> if response.error.is_success:
        ...     print(f"Coupon: {response.coupon.code}")
    """

    def validate_coupon_code(self, coupon_code: str) -> ValidateCouponCodeResponse:
        """Validate a coupon code.

        Args:
            coupon_code: Coupon code to validate

        Returns:
            ValidateCouponCodeResponse: Response containing coupon information

        Example:
            >>> response = service.validate_coupon_code("COUPON123")
            >>> if response.error.is_success:
            ...     print(f"Valid coupon: {response.coupon.code}")
        """
        payload = {"urn:ValidateCouponCode": {"ACouponCode": coupon_code}}
        response = self.send_request(payload)
        return ValidateCouponCodeResponse.from_dict(
            response["ValidateCouponCodeResponse"]["return"]
        )

    def read_promotion_by_code(
        self, promotion_code: str
    ) -> ReadPromotionByCodeResponse:
        """Read promotion details by promotion code.

        Args:
            promotion_code: Promotion code

        Returns:
            ReadPromotionByCodeResponse: Response containing promotion details

        Example:
            >>> response = service.read_promotion_by_code("PROMO123")
            >>> if response.error.is_success:
            ...     print(f"Promotion: {response.promotion.name}")
        """
        payload = {"urn:ReadPromotionByCode": {"APromotionCode": promotion_code}}
        response = self.send_request(payload)
        return ReadPromotionByCodeResponse.from_dict(
            response["ReadPromotionByCodeResponse"]["return"]
        )

    def validate_coupon_code_by_dmg_category(
        self, coupon_code: str, dmg_category_ak: str
    ) -> ValidateCouponCodeByDmgCategoryResponse:
        """Validate a coupon code by DMG category.

        Args:
            coupon_code: Coupon code to validate
            dmg_category_ak: DMG category AK

        Returns:
            ValidateCouponCodeByDmgCategoryResponse: Response containing coupon information

        Example:
            >>> response = service.validate_coupon_code_by_dmg_category("COUPON123", "CAT123")
            >>> if response.error.is_success:
            ...     print(f"Valid coupon: {response.coupon.code}")
        """
        payload = {
            "urn:ValidateCouponCodeByDmgCategory": {
                "ACouponCode": coupon_code,
                "ADmgCategoryAK": dmg_category_ak,
            }
        }
        response = self.send_request(payload)
        return ValidateCouponCodeByDmgCategoryResponse.from_dict(
            response["ValidateCouponCodeByDmgCategoryResponse"]["return"]
        )

    def find_all_promotion(self) -> FindAllPromotionResponse:
        """Find all promotions.

        Returns:
            FindAllPromotionResponse: Response containing list of promotions

        Example:
            >>> response = service.find_all_promotion()
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.promotion_list)} promotions")
        """
        payload = {"urn:FindAllPromotion": None}
        response = self.send_request(payload)
        return FindAllPromotionResponse.from_dict(
            response["FindAllPromotionResponse"]["return"]
        )

    def import_individual_code(
        self, request: ImportIndividualCodeRequest
    ) -> ImportIndividualCodeResponse:
        """Import individual coupon codes.

        Args:
            request: ImportIndividualCodeRequest with promotion code and coupon codes

        Returns:
            ImportIndividualCodeResponse: Response containing import results

        Example:
            >>> request = ImportIndividualCodeRequest(
            ...     promotion_code="PROMO123",
            ...     individual_coupon_list=["CODE1", "CODE2", "CODE3"]
            ... )
            >>> response = service.import_individual_code(request)
            >>> if response.error.is_success:
            ...     print(f"Imported {len(response.imported_coupon_list)} codes")
        """
        payload = {
            "urn:ImportIndividualCode": {
                "IMPORTINDIVIDUALCODEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ImportIndividualCodeResponse.from_dict(
            response["ImportIndividualCodeResponse"]["return"]
        )

    def read_package_by_code(self, package_code: str) -> ReadPackageByCodeResponse:
        """Read package details by package code.

        Args:
            package_code: Package code

        Returns:
            ReadPackageByCodeResponse: Response containing package details

        Example:
            >>> response = service.read_package_by_code("PKG123")
            >>> if response.error.is_success:
            ...     print(f"Package: {response.package.name}")
        """
        payload = {"urn:ReadPackageByCode": {"APackageCode": package_code}}
        response = self.send_request(payload)
        return ReadPackageByCodeResponse.from_dict(
            response["ReadPackageByCodeResponse"]["return"]
        )

    def read_external_package_by_code(
        self, package_code: str, package_serial: str
    ) -> ReadExternalPackageByCodeResponse:
        """Read external package details by package code and serial.

        Args:
            package_code: Package code
            package_serial: Package serial

        Returns:
            ReadExternalPackageByCodeResponse: Response containing external package details

        Example:
            >>> response = service.read_external_package_by_code("PKG123", "SERIAL001")
            >>> if response.error.is_success:
            ...     print(f"Package: {response.package.name}")
        """
        payload = {
            "urn:ReadExternalPackageByCode": {
                "APackageCode": package_code,
                "APackageSerial": package_serial,
            }
        }
        response = self.send_request(payload)
        return ReadExternalPackageByCodeResponse.from_dict(
            response["ReadExternalPackageByCodeResponse"]["return"]
        )

    def get_coupon_quota_per_account(
        self, request: GetCouponQuotaPerAccountRequest
    ) -> GetCouponQuotaPerAccountResponse:
        """Get coupon quota per account.

        Args:
            request: GetCouponQuotaPerAccountRequest with account and coupon info

        Returns:
            GetCouponQuotaPerAccountResponse: Response containing quota information

        Example:
            >>> request = GetCouponQuotaPerAccountRequest(
            ...     account_ak="ACC123",
            ...     coupon_code="COUPON123"
            ... )
            >>> response = service.get_coupon_quota_per_account(request)
            >>> if response.error.is_success:
            ...     print(f"Quota: {len(response.quota_list)} items")
        """
        payload = {
            "urn:GetCouponQuotaPerAccount": {
                "GETCOUPONQUOTAPERACCOUNTREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return GetCouponQuotaPerAccountResponse.from_dict(
            response["GetCouponQuotaPerAccountResponse"]["return"]
        )

    def search_promotion(
        self, request: SearchPromotionRequest
    ) -> SearchPromotionResponse:
        """Search for promotions with various filters.

        Args:
            request: SearchPromotionRequest with search criteria

        Returns:
            SearchPromotionResponse: Response containing list of promotions

        Example:
            >>> request = SearchPromotionRequest(
            ...     promotion_type=1,
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_promotion(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.promotion_list)} promotions")
        """
        payload = {
            "urn:SearchPromotion": {"SEARCHPROMOTIONREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SearchPromotionResponse.from_dict(
            response["SearchPromotionResponse"]["return"]
        )

    def search_package(self, request: SearchPackageRequest) -> SearchPackageResponse:
        """Search for packages with various filters.

        Args:
            request: SearchPackageRequest with search criteria

        Returns:
            SearchPackageResponse: Response containing list of packages

        Example:
            >>> request = SearchPackageRequest(
            ...     status=True,
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_package(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.result_package_list)} packages")
        """
        payload = {"urn:SearchPackage": {"SEARCHPACKAGEREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SearchPackageResponse.from_dict(
            response["SearchPackageResponse"]["return"]
        )

    def search_individual_code(
        self, request: SearchIndividualCodeRequest
    ) -> SearchIndividualCodeResponse:
        """Search for individual codes with various filters.

        Args:
            request: SearchIndividualCodeRequest with search criteria

        Returns:
            SearchIndividualCodeResponse: Response containing list of individual codes

        Example:
            >>> request = SearchIndividualCodeRequest(
            ...     active=True,
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_individual_code(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.individual_code_list)} codes")
        """
        payload = {
            "urn:SearchIndividualCode": {
                "SEARCHINDIVIDUALCODEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return SearchIndividualCodeResponse.from_dict(
            response["SearchIndividualCodeResponse"]["return"]
        )

    def validate_package_code(
        self, package_code: str
    ) -> ValidatePackageCodeResponse:
        """Validate a package code.

        Args:
            package_code: Package code to validate

        Returns:
            ValidatePackageCodeResponse: Response containing package information

        Example:
            >>> response = service.validate_package_code("PKG123")
            >>> if response.error.is_success:
            ...     print(f"Valid package: {response.package.code}")
        """
        payload = {"urn:ValidatePackageCode": {"APackageCode": package_code}}
        response = self.send_request(payload)
        return ValidatePackageCodeResponse.from_dict(
            response["ValidatePackageCodeResponse"]["return"]
        )
