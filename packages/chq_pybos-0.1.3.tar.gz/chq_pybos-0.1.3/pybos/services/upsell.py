"""
Upsell service for the BOS API.

This service provides methods for upsell operations including search,
reading, and shopcart checking.
"""

from ..base_service import BaseService
from ..types.upsell import (
    FindAllUpsellResponse,
    FindAllUpsellCategoryResponse,
    ReadUpsellByAKResponse,
    FindUpsellByProductAKResponse,
    SearchUpsellRequest,
    SearchUpsellResponse,
    CheckShopCartUpsellRequest,
    CheckShopCartUpsellResponse,
    CheckShopCartUpsellAndAvailabilityResponse,
)


class UpsellService(BaseService):
    """Service for BOS upsell operations.

    This service provides methods for upsell management including search,
    reading, and shopcart checking in the BOS system. All complex data
    structures use typed classes instead of dictionaries for better IDE
    support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIUpsell")

    Example:
        >>> service = UpsellService(bos_api, "IWsAPIUpsell")
        >>> response = service.find_all_upsell()
        >>> if response.error.is_success:
        ...     print(f"Found {len(response.upsell_list)} upsells")
    """

    def find_all_upsell(self) -> FindAllUpsellResponse:
        """Find all upsells.

        Returns:
            FindAllUpsellResponse: Response containing list of upsells

        Example:
            >>> response = service.find_all_upsell()
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.upsell_list)} upsells")
        """
        payload = {"urn:FindAllUpsell": None}
        response = self.send_request(payload)
        return FindAllUpsellResponse.from_dict(
            response["FindAllUpsellResponse"]["return"]
        )

    def find_all_upsell_category(self) -> FindAllUpsellCategoryResponse:
        """Find all upsell categories.

        Returns:
            FindAllUpsellCategoryResponse: Response containing list of categories

        Example:
            >>> response = service.find_all_upsell_category()
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.upsell_category_list)} categories")
        """
        payload = {"urn:FindAllUpsellCategory": None}
        response = self.send_request(payload)
        return FindAllUpsellCategoryResponse.from_dict(
            response["FindAllUpsellCategoryResponse"]["return"]
        )

    def read_upsell_by_ak(self, upsell_ak: str) -> ReadUpsellByAKResponse:
        """Read upsell by AK.

        Args:
            upsell_ak: Upsell AK identifier

        Returns:
            ReadUpsellByAKResponse: Response containing upsell details

        Example:
            >>> response = service.read_upsell_by_ak("UPSELL123")
            >>> if response.error.is_success:
            ...     print(f"Upsell: {response.upsell_item.get('NAME')}")
        """
        payload = {"urn:ReadUpsellByAK": {"AUpsellAK": upsell_ak}}
        response = self.send_request(payload)
        return ReadUpsellByAKResponse.from_dict(
            response["ReadUpsellByAKResponse"]["return"]
        )

    def find_upsell_by_product_ak(
        self, product_ak: str
    ) -> FindUpsellByProductAKResponse:
        """Find upsells by product AK.

        Args:
            product_ak: Product AK identifier

        Returns:
            FindUpsellByProductAKResponse: Response containing product upsells

        Example:
            >>> response = service.find_upsell_by_product_ak("PROD123")
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.product_upsell_list)} upsells")
        """
        payload = {"urn:FindUpsellByProductAK": {"AProductAK": product_ak}}
        response = self.send_request(payload)
        return FindUpsellByProductAKResponse.from_dict(
            response["FindUpsellByProductAKResponse"]["return"]
        )

    def search_upsell(
        self, request: SearchUpsellRequest
    ) -> SearchUpsellResponse:
        """Search for upsells.

        Args:
            request: SearchUpsellRequest with search criteria

        Returns:
            SearchUpsellResponse: Response containing list of upsells

        Example:
            >>> from ..types.common import PageRequest
            >>> request = SearchUpsellRequest(
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_upsell(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.upsell_list)} upsells")
        """
        payload = {"urn:SearchUpsell": {"SEARCHUPSELLREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SearchUpsellResponse.from_dict(
            response["SearchUpsellResponse"]["return"]
        )

    def check_shopcart_upsell(
        self, request: CheckShopCartUpsellRequest
    ) -> CheckShopCartUpsellResponse:
        """Check shopcart for upsells.

        Args:
            request: CheckShopCartUpsellRequest with shopcart

        Returns:
            CheckShopCartUpsellResponse: Response containing available upsells

        Example:
            >>> request = CheckShopCartUpsellRequest(
            ...     shopcart={"ITEMLIST": {"ITEM": []}}
            ... )
            >>> response = service.check_shopcart_upsell(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.upsell_list)} upsells")
        """
        payload = {
            "urn:CheckShopCartUpsell": {
                "CHECKSHOPCARTUPSELLREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CheckShopCartUpsellResponse.from_dict(
            response["CheckShopCartUpsellResponse"]["return"]
        )

    def check_shopcart_upsell_and_availability(
        self, request: CheckShopCartUpsellRequest
    ) -> CheckShopCartUpsellAndAvailabilityResponse:
        """Check shopcart for upsells with availability.

        Args:
            request: CheckShopCartUpsellRequest with shopcart

        Returns:
            CheckShopCartUpsellAndAvailabilityResponse: Response containing upsells with availability

        Example:
            >>> request = CheckShopCartUpsellRequest(
            ...     shopcart={"ITEMLIST": {"ITEM": []}}
            ... )
            >>> response = service.check_shopcart_upsell_and_availability(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.upsell_list)} upsells")
        """
        payload = {
            "urn:CheckShopCartUpsellAndAvailability": {
                "CHECKSHOPCARTUPSELLREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return CheckShopCartUpsellAndAvailabilityResponse.from_dict(
            response["CheckShopCartUpsellResponseAndAvailability"]["return"]
        )
