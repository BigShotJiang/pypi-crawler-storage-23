"""
Seat service for the BOS API.

This service provides methods for seat operations including seat information,
holding, and releasing seats.
"""

from ..base_service import BaseService
from ..types.seat import (
    SeatInfoRequest,
    SeatInfoResponse,
    HoldSeatRequest,
    HoldSeatResponse,
    ReleaseSeatRequest,
    ReleaseSeatResponse,
    SeatInfoSubscriptionRequest,
    SeatInfoSubscriptionResponse,
    HoldSeatSubscriptionRequest,
    HoldSeatSubscriptionResponse,
)


class SeatService(BaseService):
    """Service for BOS seat operations with improved developer ergonomics.

    This service provides methods for seat management, information retrieval,
    holding, and releasing seats in the BOS system. All complex data structures
    use typed classes instead of dictionaries for better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPISeat")

    Example:
        >>> service = SeatService(bos_api, "IWsAPISeat")
        >>> request = SeatInfoRequest(space_structure_ak="SPACE123")
        >>> response = service.seat_info(request)
        >>> if response.error.is_success:
        ...     print(f"Found seats")
    """

    def seat_info(self, request: SeatInfoRequest) -> SeatInfoResponse:
        """Get seat information for a space structure.

        Args:
            request: SeatInfoRequest with space structure and filters

        Returns:
            SeatInfoResponse: Response containing seat information

        Example:
            >>> request = SeatInfoRequest(
            ...     space_structure_ak="SPACE123",
            ...     only_available=True
            ... )
            >>> response = service.seat_info(request)
            >>> if response.error.is_success:
            ...     print(f"Found seats")
        """
        payload = {"urn:SeatInfo": {"SeatInfoReq": request.to_dict()}}
        response = self.send_request(payload)
        return SeatInfoResponse.from_dict(
            response["SeatInfoResponse"]["return"]
        )

    def hold_seat(self, request: HoldSeatRequest) -> HoldSeatResponse:
        """Hold seats for a space structure.

        Args:
            request: HoldSeatRequest with space structure, seat list, and item GUID

        Returns:
            HoldSeatResponse: Response containing hold result

        Example:
            >>> request = HoldSeatRequest(
            ...     space_structure_ak="SPACE123",
            ...     seat_list={"SEAT": [{"SEATID": 1}]},
            ...     item_guid="GUID123"
            ... )
            >>> response = service.hold_seat(request)
            >>> if response.error.is_success:
            ...     print(f"Seats held: {response.item_guid}")
        """
        payload = {"urn:HoldSeat": {"HoldSeatReq": request.to_dict()}}
        response = self.send_request(payload)
        return HoldSeatResponse.from_dict(
            response["HoldSeatResponse"]["return"]
        )

    def release_seat(self, request: ReleaseSeatRequest) -> ReleaseSeatResponse:
        """Release held seats for a space structure.

        Args:
            request: ReleaseSeatRequest with space structure, seat list, and item GUID

        Returns:
            ReleaseSeatResponse: Response containing release result

        Example:
            >>> request = ReleaseSeatRequest(
            ...     space_structure_ak="SPACE123",
            ...     seat_list={"SEAT": [{"SEATID": 1}]},
            ...     item_guid="GUID123"
            ... )
            >>> response = service.release_seat(request)
            >>> if response.error.is_success:
            ...     print("Seats released")
        """
        payload = {"urn:ReleaseSeat": {"ReleaseSeatReq": request.to_dict()}}
        response = self.send_request(payload)
        return ReleaseSeatResponse.from_dict(
            response["ReleaseSeatResponse"]["return"]
        )

    def seat_info_subscription(
        self, request: SeatInfoSubscriptionRequest
    ) -> SeatInfoSubscriptionResponse:
        """Get seat information for subscription.

        Args:
            request: SeatInfoSubscriptionRequest with space structure and filters

        Returns:
            SeatInfoSubscriptionResponse: Response containing seat information

        Example:
            >>> request = SeatInfoSubscriptionRequest(
            ...     space_structure_ak="SPACE123",
            ...     only_available=True
            ... )
            >>> response = service.seat_info_subscription(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.seat_list)} seats")
        """
        payload = {
            "urn:SeatInfoSubscription": {"SeatInfoSubscriptionReq": request.to_dict()}
        }
        response = self.send_request(payload)
        return SeatInfoSubscriptionResponse.from_dict(
            response["SeatInfoSubscriptionResponse"]["return"]
        )

    def hold_seat_subscription(
        self, request: HoldSeatSubscriptionRequest
    ) -> HoldSeatSubscriptionResponse:
        """Hold seats for subscription.

        Args:
            request: HoldSeatSubscriptionRequest with parent seat list

        Returns:
            HoldSeatSubscriptionResponse: Response containing hold result

        Example:
            >>> request = HoldSeatSubscriptionRequest(
            ...     parent_seat_list=[
            ...         {
            ...             "PARENTSEATID": 1,
            ...             "SPACESTRUCTUREAK": "SPACE123",
            ...             "SEATLIST": {"SEAT": [{"SEATID": 1}]},
            ...             "ITEMGUID": "GUID123"
            ...         }
            ...     ]
            ... )
            >>> response = service.hold_seat_subscription(request)
            >>> if response.error.is_success:
            ...     print("Seats held")
        """
        payload = {
            "urn:HoldSeatSubscription": {"HoldSeatSubscriptionReq": request.to_dict()}
        }
        response = self.send_request(payload)
        return HoldSeatSubscriptionResponse.from_dict(
            response["HoldSeatSubscriptionResponse"]["return"]
        )
