"""
Donation service for the BOS API.

This service provides methods for donation operations.
"""

from ..base_service import BaseService
from ..types.donationenquiry import (
    SearchDonationsRequest,
    SearchDonationsResponse,
)


class DonationService(BaseService):
    """Service for BOS donation operations.

    This service provides methods for searching donations in the BOS system.
    All complex data structures use typed classes instead of dictionaries for
    better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIDonation")

    Example:
        >>> service = DonationService(bos_api, "IWsAPIDonation")
        >>> request = SearchDonationsRequest(enabled=True)
        >>> response = service.search_donations(request)
        >>> if response.error.is_success:
        ...     print(f"Found {len(response.donation_group_list)} donation groups")
    """

    def search_donations(
        self, request: SearchDonationsRequest
    ) -> SearchDonationsResponse:
        """Search for donations.

        Args:
            request: SearchDonationsRequest with search criteria

        Returns:
            SearchDonationsResponse: Response containing list of donation groups

        Example:
            >>> from ..types.common import PageRequest
            >>> request = SearchDonationsRequest(
            ...     enabled=True,
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_donations(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.donation_group_list)} donation groups")
        """
        payload = {
            "urn:SearchDonations": {"SEARCHDONATIONSREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SearchDonationsResponse.from_dict(
            response["SearchDonationsResponse"]["return"]
        )
