"""
Delivery service for the BOS API.

This service provides methods for delivery operations.
"""

from ..base_service import BaseService
from ..types.deliveryenquiry import (
    FindAllDeliveryResponse,
    ReadDeliveryByAKResponse,
    SearchDeliveryRequest,
    SearchDeliveryResponse,
)


class DeliveryService(BaseService):
    """Service for BOS delivery operations.

    This service provides methods for delivery management in the BOS system.
    All complex data structures use typed classes instead of dictionaries for
    better IDE support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIDelivery")

    Example:
        >>> service = DeliveryService(bos_api, "IWsAPIDelivery")
        >>> response = service.find_all_delivery()
        >>> if response.error.is_success:
        ...     print(f"Found {len(response.delivery_list)} deliveries")
    """

    def find_all_delivery(self) -> FindAllDeliveryResponse:
        """Find all deliveries.

        Returns:
            FindAllDeliveryResponse: Response containing list of deliveries

        Example:
            >>> response = service.find_all_delivery()
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.delivery_list)} deliveries")
        """
        payload = {"urn:FindAllDelivery": None}
        response = self.send_request(payload)
        return FindAllDeliveryResponse.from_dict(
            response["FindAllDeliveryResponse"]["return"]
        )

    def read_delivery_by_ak(
        self, delivery_ak: str
    ) -> ReadDeliveryByAKResponse:
        """Read delivery by AK.

        Args:
            delivery_ak: Delivery AK identifier

        Returns:
            ReadDeliveryByAKResponse: Response containing delivery details

        Example:
            >>> response = service.read_delivery_by_ak("DELIVERY123")
            >>> if response.error.is_success:
            ...     print(f"Delivery: {response.delivery.get('NAME')}")
        """
        payload = {"urn:ReadDeliveryByAk": {"ADeliveryAk": delivery_ak}}
        response = self.send_request(payload)
        return ReadDeliveryByAKResponse.from_dict(
            response["ReadDeliveryByAkResponse"]["return"]
        )

    def search_delivery(
        self, request: SearchDeliveryRequest
    ) -> SearchDeliveryResponse:
        """Search for deliveries.

        Args:
            request: SearchDeliveryRequest with search criteria

        Returns:
            SearchDeliveryResponse: Response containing list of deliveries

        Example:
            >>> from ..types.common import PageRequest
            >>> request = SearchDeliveryRequest(
            ...     delivery_ak_list=["DELIVERY123"],
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_delivery(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.delivery_list)} deliveries")
        """
        payload = {
            "urn:SearchDelivery": {"SEARCHDELIVERYREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SearchDeliveryResponse.from_dict(
            response["SearchDeliveryResponse"]["return"]
        )
