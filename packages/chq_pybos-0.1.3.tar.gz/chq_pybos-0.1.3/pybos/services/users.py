"""
User service for the BOS API.

This service provides methods for user operations including login, logout,
session management, and user/role search.
"""

from ..base_service import BaseService
from ..types.useroperation import (
    UserLoginResponse,
    UserLogoutResponse,
    ResetISAPICacheResponse,
    CheckSessionResponse,
    FindAllPaymentResponse,
    SearchUserRoleRequest,
    SearchUserRoleResponse,
    SearchUserRequest,
    SearchUserResponse,
    SaveUserRequest,
    SaveUserResponse,
)


class UserService(BaseService):
    """Service for BOS user operations.

    This service provides methods for user management including login, logout,
    session management, and user/role search in the BOS system. All complex
    data structures use typed classes instead of dictionaries for better IDE
    support and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPIUser")

    Example:
        >>> service = UserService(bos_api, "IWsAPIUser")
        >>> response = service.user_login("WS123", "username", "password")
        >>> if response.error.is_success:
        ...     print(f"Session ID: {response.session_id}")
    """

    def user_login(
        self, workstation_ak: str, username: str, password: str
    ) -> UserLoginResponse:
        """User login.

        Args:
            workstation_ak: Workstation AK
            username: Username
            password: Password

        Returns:
            UserLoginResponse: Response with session ID and user info

        Example:
            >>> response = service.user_login("WS123", "username", "password")
            >>> if response.error.is_success:
            ...     print(f"Session ID: {response.session_id}")
        """
        payload = {
            "urn:UserLogin": {
                "AWorkstationAK": workstation_ak,
                "AUserName": username,
                "APassword": password,
            }
        }
        response = self.send_request(payload)
        return UserLoginResponse.from_dict(
            response["UserLoginResponse"]["return"]
        )

    def user_logout(self) -> UserLogoutResponse:
        """User logout.

        Returns:
            UserLogoutResponse: Response with operation result

        Example:
            >>> response = service.user_logout()
            >>> if response.error.is_success:
            ...     print("Logged out")
        """
        payload = {"urn:UserLogout": None}
        response = self.send_request(payload)
        return UserLogoutResponse.from_dict(
            response["UserLogoutResponse"]["return"]
        )

    def reset_isapi_cache(self) -> ResetISAPICacheResponse:
        """Reset ISAPI cache.

        Returns:
            ResetISAPICacheResponse: Response with operation result

        Example:
            >>> response = service.reset_isapi_cache()
            >>> if response.error.is_success:
            ...     print("Cache reset")
        """
        payload = {"urn:ResetISAPICache": None}
        response = self.send_request(payload)
        return ResetISAPICacheResponse.from_dict(
            response["ResetISAPICacheResponse"]["return"]
        )

    def check_session(self) -> CheckSessionResponse:
        """Check session.

        Returns:
            CheckSessionResponse: Response with session status

        Example:
            >>> response = service.check_session()
            >>> if response.error.is_success:
            ...     print(f"Server version: {response.app_server_version}")
        """
        payload = {"urn:CheckSession": None}
        response = self.send_request(payload)
        return CheckSessionResponse.from_dict(
            response["CheckSessionResponse"]["return"]
        )

    def read_payment_method_by_ak(
        self, payment_method_ak: str
    ) -> FindAllPaymentResponse:
        """Read payment method by AK.

        Args:
            payment_method_ak: Payment method AK

        Returns:
            FindAllPaymentResponse: Response containing payment method list

        Example:
            >>> response = service.read_payment_method_by_ak("PM123")
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.payment_method_list)} methods")
        """
        payload = {
            "urn:ReadPaymentMethodByAk": {"APaymentMethodAk": payment_method_ak}
        }
        response = self.send_request(payload)
        return FindAllPaymentResponse.from_dict(
            response["ReadPaymentMethodByAkResponse"]["return"]
        )

    def find_all_payment_method(self) -> FindAllPaymentResponse:
        """Find all payment methods.

        Returns:
            FindAllPaymentResponse: Response containing payment method list

        Example:
            >>> response = service.find_all_payment_method()
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.payment_method_list)} methods")
        """
        payload = {"urn:FindAllPaymentMethod": None}
        response = self.send_request(payload)
        return FindAllPaymentResponse.from_dict(
            response["FindAllPaymentMethodResponse"]["return"]
        )

    def search_user_role(
        self, request: SearchUserRoleRequest
    ) -> SearchUserRoleResponse:
        """Search user role.

        Args:
            request: SearchUserRoleRequest with search criteria

        Returns:
            SearchUserRoleResponse: Response containing user role list

        Example:
            >>> from ..types.common import PageRequest
            >>> request = SearchUserRoleRequest(
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_user_role(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.user_role_list)} roles")
        """
        payload = {
            "urn:SearchUserRole": {"SEARCHUSERROLEREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return SearchUserRoleResponse.from_dict(
            response["SearchUserRoleResponse"]["return"]
        )

    def search_user(self, request: SearchUserRequest) -> SearchUserResponse:
        """Search user.

        Args:
            request: SearchUserRequest with search criteria

        Returns:
            SearchUserResponse: Response containing user list

        Example:
            >>> from ..types.common import PageRequest
            >>> request = SearchUserRequest(
            ...     name="John",
            ...     page_req=PageRequest(page_index=1, page_size=10)
            ... )
            >>> response = service.search_user(request)
            >>> if response.error.is_success:
            ...     print(f"Found {len(response.user_info_list)} users")
        """
        payload = {"urn:SearchUser": {"SEARCHUSERREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SearchUserResponse.from_dict(
            response["SearchUserResponse"]["return"]
        )

    def save_user(self, request: SaveUserRequest) -> SaveUserResponse:
        """Save user.

        Args:
            request: SaveUserRequest with user data

        Returns:
            SaveUserResponse: Response with saved user info

        Example:
            >>> request = SaveUserRequest(
            ...     code="USER001",
            ...     name="John Doe",
            ...     status=1
            ... )
            >>> response = service.save_user(request)
            >>> if response.error.is_success:
            ...     print("User saved")
        """
        payload = {"urn:SaveUser": {"SAVEUSERREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SaveUserResponse.from_dict(
            response["SaveUserResponse"]["return"]
        )

