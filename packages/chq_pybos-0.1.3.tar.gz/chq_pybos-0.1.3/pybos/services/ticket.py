"""
Ticket service for the BOS API.

This service provides methods for ticket operations including ticket reading,
blocking, printing, validity management, performance changes, redemption,
and wallet generation.
"""

from ..base_service import BaseService
from ..types.ticket import (
    ReadTicketByIdResponse,
    ReadTicketByMediaCodeResponse,
    ReadTicketUsageResponse,
    ReadTicketUsageByRequest,
    ReadTicketUsageByResponse,
    BlockTicketByIdResponse,
    UnBlockTicketByIdResponse,
    BlockTicketByMediaCodeResponse,
    UnBlockTicketByMediaCodeResponse,
    BlockMediaByMediaCodeResponse,
    UnBlockMediaByMediaCodeResponse,
    PrintPdfTicketResponse,
    PrintPdfTicketSinglePageResponse,
    UpdateTicketValidityByIdRequest,
    UpdateTicketValidityByMediaCodeRequest,
    UpdateTicketValidityResponse,
    ReadRenewInfoByMediaCodeResponse,
    ReadUpgradeInfoByMediaCodeResponse,
    ReadUpgradeInfoRequest,
    ReadUpgradeInfoResponse,
    ReadRenewInfoRequest,
    ReadRenewInfoResponse,
    ReadChangePerfInfoRequest,
    ReadChangePerfInfoResponse,
    AddTicketNoteByMediaCodeRequest,
    AddTicketNoteByMediaCodeResponse,
    AddTicketNoteByIdRequest,
    AddTicketNoteByIdResponse,
    ChangePerformanceRequest,
    ChangePerformanceResponse,
    TryChangePerformanceRequest,
    TryChangePerformanceResponse,
    ChangePerformanceSimpleRequest,
    ChangeAccountRequest,
    ChangeAccountResponse,
    ReadRedeemableProductRequest,
    ReadRedeemableProductResponse,
    ReadRedeemableProductV2Response,
    RedeemProductRequest,
    RedeemProductResponse,
    VoidRedeemProductRequest,
    VoidRedeemProductResponse,
    ReadRedeemableEntitlementRequest,
    ReadRedeemableEntitlementResponse,
    ReadRedeemableEntitlementV2Request,
    ReadRedeemableEntitlementV2Response,
    ReadRedeemableEntitlementV3Request,
    ReadRedeemableEntitlementV3Response,
    ReadPerformanceTicketRequest,
    ReadPerformanceTicketResponse,
    ReadPerformanceTicketFullRequest,
    ReadPerformanceTicketFullResponse,
    SwapMediaRequest,
    SwapMediaResponse,
    SwapMultipleMediaRequest,
    SwapMultipleMediaResponse,
    FindAllTicketPackagesResponse,
    SaveExtendedInfoRequest,
    SaveExtendedInfoResponse,
    ReadExtendedInfoByAKResponse,
    SearchTicketRequest,
    SearchTicketResponse,
    ChangePerformanceMultipleTicketsRequest,
    ChangePerformanceMultipleTicketsResponse,
    WhiteListTicketRequest,
    WhiteListTicketResponse,
    ReleasePerformanceRequest,
    ReleasePerformanceResponse,
    PrintPdfTicketV2Request,
    GenerateMagicLinkRequest,
    GenerateMagicLinkResponse,
    SendMagicLinkRequest,
    SendMagicLinkResponse,
    DynamicQrCodePhoneAssociationRequest,
    DynamicQrCodePhoneAssociationResponse,
    DynamicQrCodePhoneReassociationRequest,
    DynamicQrCodePhoneReassociationResponse,
    GenerateWalletResponse,
    GenerateWalletPackageResponse,
)


class TicketService(BaseService):
    """Service for BOS ticket operations with improved developer ergonomics.

    This service provides methods for ticket management, including reading tickets,
    blocking/unblocking, printing, validity management, performance changes,
    redemption, wallet generation, and more in the BOS system. All complex data
    structures use typed classes instead of dictionaries for better IDE support
    and type safety.

    Attributes:
        Inherits from BaseService:
            bos_api: BOS API client instance
            wsdl_service: Name of the WSDL service (e.g., "IWsAPITicket")

    Example:
        >>> service = TicketService(bos_api, "IWsAPITicket")
        >>> response = service.read_ticket_by_id(12345)
        >>> if response.error.is_success:
        ...     print(f"Ticket: {response.ticket}")
    """

    def read_ticket_by_media_code(self, media_code: str) -> ReadTicketByMediaCodeResponse:
        """Read ticket by media code.

        Args:
            media_code: Media code identifier

        Returns:
            ReadTicketByMediaCodeResponse: Response containing ticket information
        """
        payload = {"urn:ReadTicketByMediaCode": {"AMediaCode": media_code}}
        response = self.send_request(payload)
        return ReadTicketByMediaCodeResponse.from_dict(
            response["ReadTicketByMediaCodeResponse"]["return"]
        )

    def read_ticket_by_id(self, ticket_id: int) -> ReadTicketByIdResponse:
        """Read ticket by ticket ID.

        Args:
            ticket_id: Ticket ID

        Returns:
            ReadTicketByIdResponse: Response containing ticket information
        """
        payload = {"urn:ReadTicketById": {"ATicketId": ticket_id}}
        response = self.send_request(payload)
        return ReadTicketByIdResponse.from_dict(
            response["ReadTicketByIdResponse"]["return"]
        )

    def read_ticket_usage_by_id(self, ticket_id: int) -> ReadTicketUsageResponse:
        """Read ticket usage by ticket ID.

        Args:
            ticket_id: Ticket ID

        Returns:
            ReadTicketUsageResponse: Response containing ticket usage information
        """
        payload = {"urn:ReadTicketUsageById": {"ATicketId": ticket_id}}
        response = self.send_request(payload)
        return ReadTicketUsageResponse.from_dict(
            response["ReadTicketUsageByIdResponse"]["return"]
        )

    def read_ticket_usage_by_media_code(self, media_code: str) -> ReadTicketUsageResponse:
        """Read ticket usage by media code.

        Args:
            media_code: Media code identifier

        Returns:
            ReadTicketUsageResponse: Response containing ticket usage information
        """
        payload = {"urn:ReadTicketUsageByMediaCode": {"AMediaCode": media_code}}
        response = self.send_request(payload)
        return ReadTicketUsageResponse.from_dict(
            response["ReadTicketUsageByMediaCodeResponse"]["return"]
        )

    def read_ticket_usage_by(self, request: ReadTicketUsageByRequest) -> ReadTicketUsageByResponse:
        """Read ticket usage by request.

        Args:
            request: Read ticket usage by request

        Returns:
            ReadTicketUsageByResponse: Response containing ticket usage information
        """
        payload = {"urn:ReadTicketUsageBy": {"READTICKETUSAGEBYREQ": request.to_dict()}}
        response = self.send_request(payload)
        return ReadTicketUsageByResponse.from_dict(
            response["ReadTicketUsageByResponse"]["return"]
        )

    def block_ticket_by_id(self, ticket_id: int) -> BlockTicketByIdResponse:
        """Block ticket by ticket ID.

        Args:
            ticket_id: Ticket ID

        Returns:
            BlockTicketByIdResponse: Response containing blocking result
        """
        payload = {"urn:BlockTicketById": {"ATicketId": ticket_id}}
        response = self.send_request(payload)
        return BlockTicketByIdResponse.from_dict(
            response["BlockTicketByIdResponse"]["return"]
        )

    def unblock_ticket_by_id(self, ticket_id: int) -> UnBlockTicketByIdResponse:
        """Unblock ticket by ticket ID.

        Args:
            ticket_id: Ticket ID

        Returns:
            UnBlockTicketByIdResponse: Response containing unblocking result
        """
        payload = {"urn:UnBlockTicketById": {"ATicketId": ticket_id}}
        response = self.send_request(payload)
        return UnBlockTicketByIdResponse.from_dict(
            response["UnBlockTicketByIdResponse"]["return"]
        )

    def block_ticket_by_media_code(self, media_code: str) -> BlockTicketByMediaCodeResponse:
        """Block ticket by media code.

        Args:
            media_code: Media code identifier

        Returns:
            BlockTicketByMediaCodeResponse: Response containing blocking result
        """
        payload = {"urn:BlockTicketByMediaCode": {"AMediaCode": media_code}}
        response = self.send_request(payload)
        return BlockTicketByMediaCodeResponse.from_dict(
            response["BlockTicketByMediaCodeResponse"]["return"]
        )

    def unblock_ticket_by_media_code(self, media_code: str) -> UnBlockTicketByMediaCodeResponse:
        """Unblock ticket by media code.

        Args:
            media_code: Media code identifier

        Returns:
            UnBlockTicketByMediaCodeResponse: Response containing unblocking result
        """
        payload = {"urn:UnBlockTicketByMediaCode": {"AMediaCode": media_code}}
        response = self.send_request(payload)
        return UnBlockTicketByMediaCodeResponse.from_dict(
            response["UnBlockTicketByMediaCodeResponse"]["return"]
        )

    def block_media_by_media_code(self, media_code: str) -> BlockMediaByMediaCodeResponse:
        """Block media by media code.

        Args:
            media_code: Media code identifier

        Returns:
            BlockMediaByMediaCodeResponse: Response containing blocking result
        """
        payload = {"urn:BlockMediaByMediaCode": {"AMediaCode": media_code}}
        response = self.send_request(payload)
        return BlockMediaByMediaCodeResponse.from_dict(
            response["BlockMediaByMediaCodeResponse"]["return"]
        )

    def unblock_media_by_media_code(self, media_code: str) -> UnBlockMediaByMediaCodeResponse:
        """Unblock media by media code.

        Args:
            media_code: Media code identifier

        Returns:
            UnBlockMediaByMediaCodeResponse: Response containing unblocking result
        """
        payload = {"urn:UnBlockMediaByMediaCode": {"AMediaCode": media_code}}
        response = self.send_request(payload)
        return UnBlockMediaByMediaCodeResponse.from_dict(
            response["UnBlockMediaByMediaCodeResponse"]["return"]
        )

    def print_pdf_ticket(
        self, sale_ak: str, ticket_id: int, media_code: str, template_type: int
    ) -> PrintPdfTicketResponse:
        """Print PDF ticket.

        Args:
            sale_ak: Sale AK
            ticket_id: Ticket ID
            media_code: Media code
            template_type: Template type

        Returns:
            PrintPdfTicketResponse: Response containing PDF content
        """
        payload = {
            "urn:PrintPdfTicket": {
                "ASaleAk": sale_ak,
                "ATicketId": ticket_id,
                "AMediaCode": media_code,
                "ATemplateType": template_type,
            }
        }
        response = self.send_request(payload)
        return PrintPdfTicketResponse.from_dict(
            response["PrintPdfTicketResponse"]["return"]
        )

    def print_pdf_ticket_v2(self, request: PrintPdfTicketV2Request) -> PrintPdfTicketResponse:
        """Print PDF ticket V2.

        Args:
            request: Print PDF ticket V2 request

        Returns:
            PrintPdfTicketResponse: Response containing PDF content
        """
        payload = {"urn:PrintPdfTicketV2": {"PRINTPDFTICKETV2REQ": request.to_dict()}}
        response = self.send_request(payload)
        return PrintPdfTicketResponse.from_dict(
            response["PrintPdfTicketV2Response"]["return"]
        )

    def print_pdf_ticket_single_page(
        self, sale_ak: str, ticket_id: int, media_code: str, template_type: int
    ) -> PrintPdfTicketSinglePageResponse:
        """Print PDF ticket single page.

        Args:
            sale_ak: Sale AK
            ticket_id: Ticket ID
            media_code: Media code
            template_type: Template type

        Returns:
            PrintPdfTicketSinglePageResponse: Response containing PDF files
        """
        payload = {
            "urn:PrintPdfTicketSinglePage": {
                "ASaleAk": sale_ak,
                "ATicketId": ticket_id,
                "AMediaCode": media_code,
                "ATemplateType": template_type,
            }
        }
        response = self.send_request(payload)
        return PrintPdfTicketSinglePageResponse.from_dict(
            response["PrintPdfTicketSinglePageResponse"]["return"]
        )

    def generate_wallet(self, sale_ak: str) -> GenerateWalletResponse:
        """Generate wallet.

        Args:
            sale_ak: Sale AK

        Returns:
            GenerateWalletResponse: Response containing wallet information
        """
        payload = {"urn:GenerateWallet": {"ASaleAk": sale_ak}}
        response = self.send_request(payload)
        return GenerateWalletResponse.from_dict(
            response["GenerateWalletResponse"]["return"]
        )

    def generate_wallet_package(self, sale_ak: str) -> GenerateWalletPackageResponse:
        """Generate wallet package.

        Args:
            sale_ak: Sale AK

        Returns:
            GenerateWalletPackageResponse: Response containing wallet package information
        """
        payload = {"urn:GenerateWalletPackage": {"ASaleAk": sale_ak}}
        response = self.send_request(payload)
        return GenerateWalletPackageResponse.from_dict(
            response["GenerateWalletPackageResponse"]["return"]
        )

    def update_ticket_validity_by_id(
        self, request: UpdateTicketValidityByIdRequest
    ) -> UpdateTicketValidityResponse:
        """Update ticket validity by ticket ID.

        Args:
            request: Update ticket validity by ID request

        Returns:
            UpdateTicketValidityResponse: Response containing update result
        """
        payload = {
            "urn:UpdateTicketValidityById": {
                "UPDATETICKETVALIDITYBYIDREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return UpdateTicketValidityResponse.from_dict(
            response["UpdateTicketValidityByIdResponse"]["return"]
        )

    def update_ticket_validity_by_media_code(
        self, request: UpdateTicketValidityByMediaCodeRequest
    ) -> UpdateTicketValidityResponse:
        """Update ticket validity by media code.

        Args:
            request: Update ticket validity by media code request

        Returns:
            UpdateTicketValidityResponse: Response containing update result
        """
        payload = {
            "urn:UpdateTicketValidityByMediaCode": {
                "UPDATETICKETVALIDITYBYMEDIACODEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return UpdateTicketValidityResponse.from_dict(
            response["UpdateTicketValidityByMediaCodeResponse"]["return"]
        )

    def read_renew_info_by_media_code(
        self, media_code: str
    ) -> ReadRenewInfoByMediaCodeResponse:
        """Read renew info by media code.

        Args:
            media_code: Media code identifier

        Returns:
            ReadRenewInfoByMediaCodeResponse: Response containing renew information
        """
        payload = {"urn:ReadRenewInfoByMediaCode": {"AMediaCode": media_code}}
        response = self.send_request(payload)
        return ReadRenewInfoByMediaCodeResponse.from_dict(
            response["ReadRenewInfoByMediaCodeResponse"]["return"]
        )

    def read_upgrade_info_by_media_code(
        self, media_code: str
    ) -> ReadUpgradeInfoByMediaCodeResponse:
        """Read upgrade info by media code.

        Args:
            media_code: Media code identifier

        Returns:
            ReadUpgradeInfoByMediaCodeResponse: Response containing upgrade information
        """
        payload = {"urn:ReadUpgradeInfoByMediaCode": {"AMediaCode": media_code}}
        response = self.send_request(payload)
        return ReadUpgradeInfoByMediaCodeResponse.from_dict(
            response["ReadUpgradeInfoByMediaCodeResponse"]["return"]
        )

    def read_upgrade_info(self, request: ReadUpgradeInfoRequest) -> ReadUpgradeInfoResponse:
        """Read upgrade info.

        Args:
            request: Read upgrade info request

        Returns:
            ReadUpgradeInfoResponse: Response containing upgrade information
        """
        payload = {"urn:ReadUpgradeInfo": {"READUPGRADEINFOREQ": request.to_dict()}}
        response = self.send_request(payload)
        return ReadUpgradeInfoResponse.from_dict(
            response["ReadUpgradeInfoResponse"]["return"]
        )

    def read_renew_info(self, request: ReadRenewInfoRequest) -> ReadRenewInfoResponse:
        """Read renew info.

        Args:
            request: Read renew info request

        Returns:
            ReadRenewInfoResponse: Response containing renew information
        """
        payload = {"urn:ReadRenewInfo": {"READRENEWINFOREQ": request.to_dict()}}
        response = self.send_request(payload)
        return ReadRenewInfoResponse.from_dict(
            response["ReadRenewInfoResponse"]["return"]
        )

    def read_change_performance_info(
        self, request: ReadChangePerfInfoRequest
    ) -> ReadChangePerfInfoResponse:
        """Read change performance info.

        Args:
            request: Read change performance info request

        Returns:
            ReadChangePerfInfoResponse: Response containing change performance information
        """
        payload = {
            "urn:ReadChangePerformanceInfo": {
                "READCHANGEPERFINFOREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadChangePerfInfoResponse.from_dict(
            response["ReadChangePerformanceInfoResponse"]["return"]
        )

    def add_ticket_note_by_media_code(
        self, request: AddTicketNoteByMediaCodeRequest
    ) -> AddTicketNoteByMediaCodeResponse:
        """Add ticket note by media code.

        Args:
            request: Add ticket note by media code request

        Returns:
            AddTicketNoteByMediaCodeResponse: Response containing add note result
        """
        payload = {
            "urn:AddTicketNoteByMediaCode": {
                "ADDTICKETNOTEBYMEDIACODEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return AddTicketNoteByMediaCodeResponse.from_dict(
            response["AddTicketNoteByMediaCodeResponse"]["return"]
        )

    def add_ticket_note_by_id(
        self, request: AddTicketNoteByIdRequest
    ) -> AddTicketNoteByIdResponse:
        """Add ticket note by ticket ID.

        Args:
            request: Add ticket note by ID request

        Returns:
            AddTicketNoteByIdResponse: Response containing add note result
        """
        payload = {"urn:AddTicketNoteById": {"ADDTICKETNOTEBYIDREQ": request.to_dict()}}
        response = self.send_request(payload)
        return AddTicketNoteByIdResponse.from_dict(
            response["AddTicketNoteByIdResponse"]["return"]
        )

    def swap_media(self, request: SwapMediaRequest) -> SwapMediaResponse:
        """Swap media.

        Args:
            request: Swap media request

        Returns:
            SwapMediaResponse: Response containing swap result
        """
        payload = {"urn:SwapMedia": {"SWAPMEDIAREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SwapMediaResponse.from_dict(response["SwapMediaResponse"]["return"])

    def swap_multiple_media(
        self, request: SwapMultipleMediaRequest
    ) -> SwapMultipleMediaResponse:
        """Swap multiple media.

        Args:
            request: Swap multiple media request

        Returns:
            SwapMultipleMediaResponse: Response containing swap results
        """
        payload = {"urn:SwapMultipleMedia": {"SWAPMULTIPLEMEDIAREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SwapMultipleMediaResponse.from_dict(
            response["SwapMultipleMediaResponse"]["return"]
        )

    def find_all_ticket_packages(
        self, matrix_cell_ak: str
    ) -> FindAllTicketPackagesResponse:
        """Find all ticket packages.

        Args:
            matrix_cell_ak: Matrix cell AK

        Returns:
            FindAllTicketPackagesResponse: Response containing ticket packages
        """
        payload = {"urn:FindAllTicketPackages": {"AMatrixCellAk": matrix_cell_ak}}
        response = self.send_request(payload)
        return FindAllTicketPackagesResponse.from_dict(
            response["FindAllTicketPackagesResponse"]["return"]
        )

    def save_extended_info(
        self, request: SaveExtendedInfoRequest
    ) -> SaveExtendedInfoResponse:
        """Save extended info.

        Args:
            request: Save extended info request

        Returns:
            SaveExtendedInfoResponse: Response containing save result
        """
        payload = {"urn:SaveExtendedInfo": {"SAVEEXTENDEDINFOREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SaveExtendedInfoResponse.from_dict(
            response["SaveExtendedInfoResponse"]["return"]
        )

    def read_ticket_extended_info_by_ak(
        self, extended_info_ak: str
    ) -> ReadExtendedInfoByAKResponse:
        """Read ticket extended info by AK.

        Args:
            extended_info_ak: Extended info AK

        Returns:
            ReadExtendedInfoByAKResponse: Response containing extended info
        """
        payload = {
            "urn:ReadTicketExtendedInfoByAK": {"AExtendedInfoAK": extended_info_ak}
        }
        response = self.send_request(payload)
        return ReadExtendedInfoByAKResponse.from_dict(
            response["ReadTicketExtendedInfoByAKResponse"]["return"]
        )

    def change_performance(self, request: ChangePerformanceRequest) -> ChangePerformanceResponse:
        """Change performance.

        Args:
            request: Change performance request

        Returns:
            ChangePerformanceResponse: Response containing change result
        """
        payload = {
            "urn:ChangePerformance": {"CHANGEPERFORMANCEREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return ChangePerformanceResponse.from_dict(
            response["ChangePerformanceResponse"]["return"]
        )

    def try_change_performance(
        self, request: TryChangePerformanceRequest
    ) -> TryChangePerformanceResponse:
        """Try change performance.

        Args:
            request: Try change performance request

        Returns:
            TryChangePerformanceResponse: Response containing try change result
        """
        payload = {
            "urn:TryChangePerformance": {"TRYCHANGEPERFORMANCEREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return TryChangePerformanceResponse.from_dict(
            response["TryChangePerformanceResponse"]["return"]
        )

    def change_performance_simple(
        self, request: ChangePerformanceSimpleRequest
    ) -> ChangePerformanceResponse:
        """Change performance simple.

        Args:
            request: Change performance simple request

        Returns:
            ChangePerformanceResponse: Response containing change result
        """
        payload = {
            "urn:ChangePerformanceSimple": {
                "CHANGEPERFORMANCESIMPLEREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ChangePerformanceResponse.from_dict(
            response["ChangePerformanceSimpleResponse"]["return"]
        )

    def change_performance_multiple_tickets(
        self, request: ChangePerformanceMultipleTicketsRequest
    ) -> ChangePerformanceMultipleTicketsResponse:
        """Change performance multiple tickets.

        Args:
            request: Change performance multiple tickets request

        Returns:
            ChangePerformanceMultipleTicketsResponse: Response containing change results
        """
        payload = {
            "urn:ChangePerformanceMultipleTickets": {
                "CHANGEPERFORMANCEMULTIPLETICKETSREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ChangePerformanceMultipleTicketsResponse.from_dict(
            response["ChangePerformanceMultipleTicketsResponse"]["return"]
        )

    def change_account(self, request: ChangeAccountRequest) -> ChangeAccountResponse:
        """Change account.

        Args:
            request: Change account request

        Returns:
            ChangeAccountResponse: Response containing change result
        """
        payload = {"urn:ChangeAccount": {"CHANGEACCOUNTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return ChangeAccountResponse.from_dict(
            response["ChangeAccountResponse"]["return"]
        )

    def read_redeemable_product(
        self, request: ReadRedeemableProductRequest
    ) -> ReadRedeemableProductResponse:
        """Read redeemable product.

        Args:
            request: Read redeemable product request

        Returns:
            ReadRedeemableProductResponse: Response containing redeemable products
        """
        payload = {
            "urn:ReadRedeemableProduct": {
                "READREDEEMABLEPRODUCTREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadRedeemableProductResponse.from_dict(
            response["ReadRedeemableProductResponse"]["return"]
        )

    def read_redeemable_product_v2(
        self, request: ReadRedeemableProductRequest
    ) -> ReadRedeemableProductV2Response:
        """Read redeemable product V2.

        Args:
            request: Read redeemable product request

        Returns:
            ReadRedeemableProductV2Response: Response containing redeemable products V2
        """
        payload = {
            "urn:ReadRedeemableProductV2": {
                "READREDEEMABLEPRODUCTREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadRedeemableProductV2Response.from_dict(
            response["ReadRedeemableProductV2Response"]["return"]
        )

    def redeem_product(self, request: RedeemProductRequest) -> RedeemProductResponse:
        """Redeem product.

        Args:
            request: Redeem product request

        Returns:
            RedeemProductResponse: Response containing redemption result
        """
        payload = {"urn:RedeemProduct": {"REDEEMPRODUCTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return RedeemProductResponse.from_dict(
            response["RedeemProductResponse"]["return"]
        )

    def void_redeem_product(
        self, request: VoidRedeemProductRequest
    ) -> VoidRedeemProductResponse:
        """Void redeem product.

        Args:
            request: Void redeem product request

        Returns:
            VoidRedeemProductResponse: Response containing void result
        """
        payload = {"urn:VoidRedeemProduct": {"VOIDREDEEMPRODUCTREQ": request.to_dict()}}
        response = self.send_request(payload)
        return VoidRedeemProductResponse.from_dict(
            response["VoidRedeemProductResponse"]["return"]
        )

    def read_redeemable_entitlement(
        self, media_code: str
    ) -> ReadRedeemableEntitlementResponse:
        """Read redeemable entitlement.

        Args:
            media_code: Media code identifier

        Returns:
            ReadRedeemableEntitlementResponse: Response containing redeemable entitlements
        """
        payload = {"urn:ReadRedeemableEntitlement": {"AMediaCode": media_code}}
        response = self.send_request(payload)
        return ReadRedeemableEntitlementResponse.from_dict(
            response["ReadRedeemableEntitlementResponse"]["return"]
        )

    def read_redeemable_entitlement_v2(
        self, request: ReadRedeemableEntitlementV2Request
    ) -> ReadRedeemableEntitlementV2Response:
        """Read redeemable entitlement V2.

        Args:
            request: Read redeemable entitlement V2 request

        Returns:
            ReadRedeemableEntitlementV2Response: Response containing redeemable entitlements V2
        """
        payload = {
            "urn:ReadRedeemableEntitlementV2": {
                "READREDEEMABLEENTITLEMENTV2REQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadRedeemableEntitlementV2Response.from_dict(
            response["ReadRedeemableEntitlementV2Response"]["return"]
        )

    def read_redeemable_entitlement_v3(
        self, request: ReadRedeemableEntitlementV3Request
    ) -> ReadRedeemableEntitlementV3Response:
        """Read redeemable entitlement V3.

        Args:
            request: Read redeemable entitlement V3 request

        Returns:
            ReadRedeemableEntitlementV3Response: Response containing redeemable entitlements V3
        """
        payload = {
            "urn:ReadRedeemableEntitlementV3": {
                "READREDEEMABLEENTITLEMENTV3REQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadRedeemableEntitlementV3Response.from_dict(
            response["ReadRedeemableEntitlementV3Response"]["return"]
        )

    def read_performance_ticket(
        self, request: ReadPerformanceTicketRequest
    ) -> ReadPerformanceTicketResponse:
        """Read performance ticket.

        Args:
            request: Read performance ticket request

        Returns:
            ReadPerformanceTicketResponse: Response containing performance tickets
        """
        payload = {
            "urn:ReadPerformanceTicket": {
                "READPERFORMANCETICKETREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadPerformanceTicketResponse.from_dict(
            response["ReadPerformanceTicketResponse"]["return"]
        )

    def read_performance_ticket_full(
        self, request: ReadPerformanceTicketFullRequest
    ) -> ReadPerformanceTicketFullResponse:
        """Read performance ticket full.

        Args:
            request: Read performance ticket full request

        Returns:
            ReadPerformanceTicketFullResponse: Response containing performance tickets full
        """
        payload = {
            "urn:ReadPerformanceTicketFull": {
                "READPERFORMANCETICKETFULLREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return ReadPerformanceTicketFullResponse.from_dict(
            response["ReadPerformanceTicketFullResponse"]["return"]
        )

    def search_ticket(self, request: SearchTicketRequest) -> SearchTicketResponse:
        """Search ticket.

        Args:
            request: Search ticket request

        Returns:
            SearchTicketResponse: Response containing search results
        """
        payload = {"urn:SearchTicket": {"SEARCHTICKETREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SearchTicketResponse.from_dict(
            response["SearchTicketResponse"]["return"]
        )

    def white_list_ticket(
        self, request: WhiteListTicketRequest
    ) -> WhiteListTicketResponse:
        """White list ticket.

        Args:
            request: White list ticket request

        Returns:
            WhiteListTicketResponse: Response containing white list result
        """
        payload = {"urn:WhiteListTicket": {"WHITELISTTICKETREQ": request.to_dict()}}
        response = self.send_request(payload)
        return WhiteListTicketResponse.from_dict(
            response["WhiteListTicketResponse"]["return"]
        )

    def release_performance(
        self, request: ReleasePerformanceRequest
    ) -> ReleasePerformanceResponse:
        """Release performance.

        Args:
            request: Release performance request

        Returns:
            ReleasePerformanceResponse: Response containing release result
        """
        payload = {
            "urn:ReleasePerformance": {"RELEASEPERFORMANCEREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return ReleasePerformanceResponse.from_dict(
            response["ReleasePerformanceResponse"]["return"]
        )

    def generate_magic_link(
        self, request: GenerateMagicLinkRequest
    ) -> GenerateMagicLinkResponse:
        """Generate magic link.

        Args:
            request: Generate magic link request

        Returns:
            GenerateMagicLinkResponse: Response containing magic link
        """
        payload = {
            "urn:GenerateMagicLink": {"GENERATEMAGICLINKREQ": request.to_dict()}
        }
        response = self.send_request(payload)
        return GenerateMagicLinkResponse.from_dict(
            response["GenerateMagicLinkResponse"]["return"]
        )

    def send_magic_link(
        self, request: SendMagicLinkRequest
    ) -> SendMagicLinkResponse:
        """Send magic link.

        Args:
            request: Send magic link request

        Returns:
            SendMagicLinkResponse: Response containing send result
        """
        payload = {"urn:SendMagicLink": {"SENDMAGICLINKREQ": request.to_dict()}}
        response = self.send_request(payload)
        return SendMagicLinkResponse.from_dict(
            response["SendMagicLinkResponse"]["return"]
        )

    def dynamic_qr_code_create_association(
        self, request: DynamicQrCodePhoneAssociationRequest
    ) -> DynamicQrCodePhoneAssociationResponse:
        """Dynamic QR code create association.

        Args:
            request: Dynamic QR code phone association request

        Returns:
            DynamicQrCodePhoneAssociationResponse: Response containing association result
        """
        payload = {
            "urn:DynamicQrCodeCreateAssociation": {
                "DYNAMICQRCODEPHONEASSOCIATIONREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return DynamicQrCodePhoneAssociationResponse.from_dict(
            response["DynamicQrCodeCreateAssociationResponse"]["return"]
        )

    def dynamic_qr_code_create_reassociation(
        self, request: DynamicQrCodePhoneReassociationRequest
    ) -> DynamicQrCodePhoneReassociationResponse:
        """Dynamic QR code create reassociation.

        Args:
            request: Dynamic QR code phone reassociation request

        Returns:
            DynamicQrCodePhoneReassociationResponse: Response containing reassociation result
        """
        payload = {
            "urn:DynamicQrCodeCreateReassociation": {
                "DYNAMICQRCODEPHONEREASSOCIATIONREQ": request.to_dict()
            }
        }
        response = self.send_request(payload)
        return DynamicQrCodePhoneReassociationResponse.from_dict(
            response["DynamicQrCodeCreateReassociationResponse"]["return"]
        )
