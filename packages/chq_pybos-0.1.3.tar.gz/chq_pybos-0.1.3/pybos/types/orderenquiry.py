"""
Type definitions for OrderEnquiry and ShopCart.

This module provides structured classes for order and shop cart operations,
replacing tuple-based parameters with type-safe, self-documenting classes.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BasicInfo


# OrderEnquiry Types
@dataclass
class ReadOrderByAKResponse:
    """Response for ReadOrderByAK operation."""
    error: Error
    sale: Optional[Dict[str, Any]] = None
    item_list: Optional[List[Dict[str, Any]]] = None
    order_delivery_item_list: Optional[List[Dict[str, Any]]] = None
    order_donation_item_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadOrderByAKResponse":
        items = data.get("ITEMLIST", {})
        if items and "ITEM" in items:
            item_list = items["ITEM"] if isinstance(items["ITEM"], list) else [items["ITEM"]]
        else:
            item_list = None
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            sale=data.get("SALE"),
            item_list=item_list,
            order_delivery_item_list=data.get("ORDERDELIVERYITEMLIST"),
            order_donation_item_list=data.get("ORDERDONATIONITEMLIST"),
        )


@dataclass
class ReadOrderByAK_V2Response:
    """Response for ReadOrderByAK_V2 operation."""
    error: Error
    sale: Optional[Dict[str, Any]] = None
    item_list: Optional[List[Dict[str, Any]]] = None
    order_delivery_item_list: Optional[List[Dict[str, Any]]] = None
    order_donation_item_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadOrderByAK_V2Response":
        items = data.get("ITEMLIST", {})
        if items and "ITEM" in items:
            item_list = items["ITEM"] if isinstance(items["ITEM"], list) else [items["ITEM"]]
        else:
            item_list = None
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            sale=data.get("SALE"),
            item_list=item_list,
            order_delivery_item_list=data.get("ORDERDELIVERYITEMLIST"),
            order_donation_item_list=data.get("ORDERDONATIONITEMLIST"),
        )


@dataclass
class FindSaleByExternalMediaResponse:
    """Response for FindSaleByExternalMedia operation."""
    error: Error
    sale: Optional[Dict[str, Any]] = None
    item_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindSaleByExternalMediaResponse":
        items = data.get("ITEMLIST", {})
        if items and "ITEM" in items:
            item_list = items["ITEM"] if isinstance(items["ITEM"], list) else [items["ITEM"]]
        else:
            item_list = None
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            sale=data.get("SALE"),
            item_list=item_list,
        )


# ShopCart Types - Request Classes
@dataclass
class CheckOutRequest:
    """Request for CheckOut operation."""
    sale_ak: Optional[str] = None
    shop_cart: Dict[str, Any] = None
    gift_aid: Optional[int] = None
    
    def to_dict(self) -> dict:
        result = {}
        if self.sale_ak:
            result["SALEAK"] = self.sale_ak
        if self.shop_cart:
            result["SHOPCART"] = self.shop_cart
        if self.gift_aid is not None:
            result["GIFTAID"] = self.gift_aid
        return result


@dataclass
class CheckOut2Request:
    """Request for CheckOut2 operation."""
    shop_cart: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return {"SHOPCART": self.shop_cart}


@dataclass
class CheckOutMixedRequest:
    """Request for CheckOutMixed operation."""
    reservation: Optional[Dict[str, Any]] = None
    coupon_list: Optional[List[Dict[str, str]]] = None
    sale: Optional[Dict[str, Any]] = None
    renew: Optional[Dict[str, Any]] = None
    upgrade: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        result = {}
        if self.reservation:
            result["RESERVATION"] = self.reservation
        if self.coupon_list:
            result["COUPONLIST"] = {"COUPON": self.coupon_list}
        if self.sale:
            result["SALE"] = self.sale
        if self.renew:
            result["RENEW"] = self.renew
        if self.upgrade:
            result["UPGRADE"] = self.upgrade
        return result


@dataclass
class CheckBasketRequest:
    """Request for CheckBasket operation."""
    sale_ak: Optional[str] = None
    shop_cart: Dict[str, Any] = None
    capacity_management: Optional[bool] = None
    quota_coupon_management: Optional[bool] = None
    ignore_warnings: Optional[bool] = None
    
    def to_dict(self) -> dict:
        result = {}
        if self.sale_ak:
            result["SALEAK"] = self.sale_ak
        if self.shop_cart:
            result["SHOPCART"] = self.shop_cart
        if self.capacity_management is not None:
            result["CAPACITYMANAGEMENT"] = self.capacity_management
        if self.quota_coupon_management is not None:
            result["QUOTACOUPONMANAGEMENT"] = self.quota_coupon_management
        if self.ignore_warnings is not None:
            result["IGNOREWARNINGS"] = self.ignore_warnings
        return result


@dataclass
class CheckBasketMixedRequest:
    """Request for CheckBasketMixed operation."""
    reservation: Optional[Dict[str, Any]] = None
    coupon_list: Optional[List[Dict[str, str]]] = None
    sale: Optional[Dict[str, Any]] = None
    renew: Optional[Dict[str, Any]] = None
    upgrade: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        result = {}
        if self.reservation:
            result["RESERVATION"] = self.reservation
        if self.coupon_list:
            result["COUPONLIST"] = {"COUPON": self.coupon_list}
        if self.sale:
            result["SALE"] = self.sale
        if self.renew:
            result["RENEW"] = self.renew
        if self.upgrade:
            result["UPGRADE"] = self.upgrade
        return result


@dataclass
class CloseOrderRequest:
    """Request for CloseOrder operation."""
    ak: str
    
    def to_dict(self) -> dict:
        return {"AK": self.ak}


@dataclass
class CloseBulkOrderRequest:
    """Request for CloseBulkOrder operation."""
    order_ak_list: List[str]
    
    def to_dict(self) -> dict:
        return {
            "ORDERAKLIST": {
                "ORDERAK": self.order_ak_list
            }
        }


@dataclass
class CloseMultipleOrderRequest:
    """Request for CloseMultipleOrder operation."""
    order_ak_list: List[str]
    close_date: Optional[str] = None
    
    def to_dict(self) -> dict:
        result = {
            "ORDERAKLIST": {
                "ORDERAK": self.order_ak_list
            }
        }
        if self.close_date:
            result["CLOSEDATE"] = self.close_date
        return result


@dataclass
class CloseMultipleOrder2Request:
    """Request for CloseMultipleOrder2 operation."""
    order_ak_list: List[str]
    close_date: Optional[str] = None
    close_time: Optional[str] = None
    
    def to_dict(self) -> dict:
        result = {
            "ORDERAKLIST": {
                "ORDERAK": self.order_ak_list
            }
        }
        if self.close_date:
            result["CLOSEDATE"] = self.close_date
        if self.close_time:
            result["CLOSETIME"] = self.close_time
        return result


@dataclass
class RenewRequest:
    """Request for Renew operation."""
    renew_match_item_list: Dict[str, Any]
    coupon_list: Optional[List[Dict[str, str]]] = None
    
    def to_dict(self) -> dict:
        result = {
            "RENEWMATCHITEMLIST": self.renew_match_item_list
        }
        if self.coupon_list:
            result["COUPONLIST"] = {"COUPON": self.coupon_list}
        return result


@dataclass
class TryRenewRequest:
    """Request for TryRenew operation."""
    renew_match_item_list: Dict[str, Any]
    coupon_list: Optional[List[Dict[str, str]]] = None
    
    def to_dict(self) -> dict:
        result = {
            "RENEWMATCHITEMLIST": self.renew_match_item_list
        }
        if self.coupon_list:
            result["COUPONLIST"] = {"COUPON": self.coupon_list}
        return result


@dataclass
class UpgradeRequest:
    """Request for Upgrade operation."""
    upgrade_match_item_list: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return {
            "UPGRADEMATCHITEMLIST": self.upgrade_match_item_list
        }


@dataclass
class TryUpgradeRequest:
    """Request for TryUpgrade operation."""
    upgrade_match_item_list: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return {
            "UPGRADEMATCHITEMLIST": self.upgrade_match_item_list
        }


@dataclass
class MoneyCardRechargeRequest:
    """Request for MoneyCardRecharge operation."""
    money_card_recharge_req: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return self.money_card_recharge_req


@dataclass
class MoneyCardCashOutRequest:
    """Request for MoneyCardCashOut operation."""
    money_card_cashout_req: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return self.money_card_cashout_req


@dataclass
class DeleteReservationRequest:
    """Request for DeleteReservation operation."""
    delete_reservation_req: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return self.delete_reservation_req


@dataclass
class DepositOnReservationRequest:
    """Request for DepositOnReservation operation."""
    deposit_on_reservation_req: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return self.deposit_on_reservation_req


@dataclass
class AddSaleNoteRequest:
    """Request for AddOrderNote/AddSaleNote operation."""
    ak: str
    note: str
    
    def to_dict(self) -> dict:
        return {
            "AK": self.ak,
            "NOTE": self.note[:500]  # Max length 500
        }


@dataclass
class AddPackageRequest:
    """Request for AddPackage operation."""
    package_serial: str
    
    def to_dict(self) -> dict:
        return {"APackageSerial": self.package_serial}


@dataclass
class AddExternalPackageRequest:
    """Request for AddExternalPackage operation."""
    package_serial: str
    promotion_code: str
    
    def to_dict(self) -> dict:
        return {
            "APackageSerial": self.package_serial,
            "APromotionCode": self.promotion_code
        }


@dataclass
class ValidatePackageRequest:
    """Request for ValidatePackage operation."""
    package_serial: str
    
    def to_dict(self) -> dict:
        return {"APackageSerial": self.package_serial}


@dataclass
class ValidateExternalPackageRequest:
    """Request for ValidateExternalPackage operation."""
    package_serial: str
    promotion_code: str
    
    def to_dict(self) -> dict:
        return {
            "APackageSerial": self.package_serial,
            "APromotionCode": self.promotion_code
        }


@dataclass
class ActivateTicketPackageRequest:
    """Request for ActivateTicketPackage operation."""
    ticket_package_list: Dict[str, Any]
    flag: Dict[str, bool]  # ORDERSTATUS
    reservation: Dict[str, Any]  # RESERVATIONBASE
    delivery: Optional[Dict[str, Any]] = None
    coupon_list: Optional[List[Dict[str, str]]] = None
    language_ak: Optional[str] = None
    
    def to_dict(self) -> dict:
        result = {
            "TICKETPACKAGELIST": self.ticket_package_list,
            "FLAG": self.flag,
            "RESERVATION": self.reservation,
        }
        if self.delivery:
            result["DELIVERY"] = self.delivery
        if self.coupon_list:
            result["COUPONLIST"] = {"COUPON": self.coupon_list}
        if self.language_ak:
            result["LANGUAGEAK"] = self.language_ak
        return result


@dataclass
class PreSaleRequest:
    """Request for PreSale operation."""
    logged_account: Dict[str, str]  # ACCOUNTSAVEBASE
    performance_ak: str
    
    def to_dict(self) -> dict:
        return {
            "LOGGEDACCOUNT": self.logged_account,
            "PERFORMANCEAK": self.performance_ak
        }


@dataclass
class ApproveAccountTicketRequest:
    """Request for ApproveAccountTicket operation."""
    account_ak: str
    payment_code: str
    language_ak: str
    
    def to_dict(self) -> dict:
        return {
            "AAccountAK": self.account_ak,
            "APaymentCode": self.payment_code,
            "ALanguageAK": self.language_ak
        }


@dataclass
class VoidTicketRequest:
    """Request for VoidTicket operation."""
    void_ticket_req: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return self.void_ticket_req


@dataclass
class CheckSuggestiveSellRequest:
    """Request for CheckSuggestiveSell operation."""
    shop_cart: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return {"SHOPCART": self.shop_cart}


@dataclass
class CheckSuggestiveSellAndAvailabilityRequest:
    """Request for CheckSuggestiveSellAndAvailability operation."""
    check_suggestive_sell_req: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return self.check_suggestive_sell_req


@dataclass
class ReadTransactionBySaleRequest:
    """Request for ReadTransactionBySale operation."""
    sale_ak: str
    
    def to_dict(self) -> dict:
        return {"ASaleAK": self.sale_ak}


@dataclass
class TransferPerformanceRequest:
    """Request for TransferPerformance operation."""
    transfer_performance_req: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return self.transfer_performance_req


@dataclass
class TryTransferPerformanceRequest:
    """Request for TryTransferPerformance operation."""
    try_transfer_performance_req: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return self.try_transfer_performance_req


@dataclass
class GenerateReferralCodeRequest:
    """Request for GenerateReferralCode operation."""
    media_code: str
    
    def to_dict(self) -> dict:
        return {"AMediaCode": self.media_code}


@dataclass
class ChangeRedeemProductQuantityRequest:
    """Request for ChangeRedeemProductQuantity operation."""
    sale_ak: str
    matrix_cell_list: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return {
            "SALEAK": self.sale_ak,
            "MATRIXCELLLIST": self.matrix_cell_list
        }


@dataclass
class ChangePerformanceCheckOutRequest:
    """Request for ChangePerformanceCheckOut operation."""
    match_item_list: Dict[str, Any]
    logged_account: Optional[Dict[str, str]] = None
    reservation_owner: Optional[Dict[str, str]] = None
    billing_account: Optional[Dict[str, str]] = None
    
    def to_dict(self) -> dict:
        result = {
            "MATCHITEMLIST": self.match_item_list
        }
        if self.logged_account:
            result["LOGGEDACCOUNT"] = self.logged_account
        if self.reservation_owner:
            result["RESERVATIONOWNER"] = self.reservation_owner
        if self.billing_account:
            result["BILLINGACCOUNT"] = self.billing_account
        return result


@dataclass
class UpdateExternalReservationCodeRequest:
    """Request for UpdateExternalReservationCode operation."""
    update_external_reservation_code_req: Dict[str, Any]
    
    def to_dict(self) -> dict:
        return self.update_external_reservation_code_req


# ShopCart Types - Response Classes
@dataclass
class CheckOutResponse:
    """Response for CheckOut operations."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    coupon_list: Optional[Dict[str, Any]] = None
    flex_contract_list: Optional[Dict[str, Any]] = None
    delivery_item_list: Optional[Dict[str, Any]] = None
    donation_item_list: Optional[Dict[str, Any]] = None
    product_error_list: Optional[Dict[str, Any]] = None
    payment_method_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "CheckOutResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
            coupon_list=data.get("COUPONLIST"),
            flex_contract_list=data.get("FLEXCONTRACTLIST"),
            delivery_item_list=data.get("DELIVERYITEMLIST"),
            donation_item_list=data.get("DONATIONITEMLIST"),
            product_error_list=data.get("PRODUCTERRORLIST"),
            payment_method_list=data.get("PAYMENTMETHODLIST"),
        )


@dataclass
class CheckBasketResponse:
    """Response for CheckBasket operations."""
    error: Error
    basket_total: Optional[Dict[str, Any]] = None
    coupon_list: Optional[Dict[str, Any]] = None
    flex_contract_list: Optional[Dict[str, Any]] = None
    delivery_item_list: Optional[Dict[str, Any]] = None
    available_delivery_list: Optional[Dict[str, Any]] = None
    product_error_list: Optional[Dict[str, Any]] = None
    donation_item_list: Optional[Dict[str, Any]] = None
    payment_method_list: Optional[Dict[str, Any]] = None
    gift_aid_info: Optional[bool] = None
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "CheckBasketResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            basket_total=data.get("BASKETTOTAL"),
            coupon_list=data.get("COUPONLIST"),
            flex_contract_list=data.get("FLEXCONTRACTLIST"),
            delivery_item_list=data.get("DELIVERYITEMLIST"),
            available_delivery_list=data.get("AVAILABLEDELIVERYLIST"),
            product_error_list=data.get("PRODUCTERRORLIST"),
            donation_item_list=data.get("DONATIONITEMLIST"),
            payment_method_list=data.get("PAYMENTMETHODLIST"),
            gift_aid_info=data.get("GIFTAIDINFO"),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class CloseOrderResponse:
    """Response for CloseOrder operations."""
    error: Error
    sale: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "CloseOrderResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            sale=data.get("SALE"),
        )


@dataclass
class CloseBulkOrderResponse:
    """Response for CloseBulkOrder operation."""
    error: Error
    order_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "CloseBulkOrderResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            order_list=data.get("ORDERLIST"),
        )


@dataclass
class CloseMultipleOrderResponse:
    """Response for CloseMultipleOrder operations."""
    error: Error
    order_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "CloseMultipleOrderResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            order_list=data.get("ORDERLIST"),
        )


@dataclass
class RenewResponse:
    """Response for Renew operations."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "RenewResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class TryRenewResponse:
    """Response for TryRenew operation."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "TryRenewResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class UpgradeResponse:
    """Response for Upgrade operations."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "UpgradeResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class TryUpgradeResponse:
    """Response for TryUpgrade operation."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "TryUpgradeResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class MoneyCardRechargeResponse:
    """Response for MoneyCardRecharge operation."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "MoneyCardRechargeResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class MoneyCardCashOutResponse:
    """Response for MoneyCardCashOut operation."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "MoneyCardCashOutResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class DeleteReservationCreditResponse:
    """Response for DeleteReservationCredit operation."""
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "DeleteReservationCreditResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
        )


@dataclass
class TryDeleteReservationCreditResponse:
    """Response for TryDeleteReservationCredit operation."""
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "TryDeleteReservationCreditResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
        )


@dataclass
class DeleteReservationResponse:
    """Response for DeleteReservation operations."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "DeleteReservationResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class DepositOnReservationResponse:
    """Response for DepositOnReservation operation."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "DepositOnReservationResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class AddSaleNoteResponse:
    """Response for AddSaleNote operation."""
    error: Error
    ak: str
    note: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "AddSaleNoteResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ak=data.get("AK", ""),
            note=data.get("NOTE"),
        )


@dataclass
class AddPackageResponse:
    """Response for AddPackage operations."""
    error: Error
    shop_cart: str
    err_msg: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "AddPackageResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            shop_cart=data.get("SHOPCART", ""),
            err_msg=data.get("ERRMSG", ""),
        )


@dataclass
class ValidatePackageResponse:
    """Response for ValidatePackage operations."""
    error: Error
    shop_cart: Optional[str] = None
    err_msg: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ValidatePackageResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            shop_cart=data.get("SHOPCART"),
            err_msg=data.get("ERRMSG"),
        )


@dataclass
class AbortSaleResponse:
    """Response for AbortSale operation."""
    error: Error
    sale: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "AbortSaleResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            sale=data.get("SALE"),
        )


@dataclass
class ActivateTicketPackageResponse:
    """Response for ActivateTicketPackage operation."""
    error: Error
    ticket_package_list: Optional[Dict[str, Any]] = None
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ActivateTicketPackageResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_package_list=data.get("TICKETPACKAGELIST"),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class ApproveAccountTicketResponse:
    """Response for ApproveAccountTicket operation."""
    error: Error
    sale: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ApproveAccountTicketResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            sale=data.get("SALE"),
        )


@dataclass
class VoidTicketResponse:
    """Response for VoidTicket operation."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "VoidTicketResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class CheckSuggestiveSellResponse:
    """Response for CheckSuggestiveSell operation."""
    error: Error
    suggestive_sell: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "CheckSuggestiveSellResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            suggestive_sell=data.get("SUGGESTIVESELL"),
        )


@dataclass
class CheckSuggestiveSellAndAvailabilityResponse:
    """Response for CheckSuggestiveSellAndAvailability operation."""
    error: Error
    suggestive_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "CheckSuggestiveSellAndAvailabilityResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            suggestive_list=data.get("SUGGESTIVELIST"),
        )


@dataclass
class ReadTransactionBySaleResponse:
    """Response for ReadTransactionBySale operation."""
    error: Error
    transaction_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadTransactionBySaleResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            transaction_list=data.get("TRANSACTIONLIST"),
        )


@dataclass
class TransferPerformanceResponse:
    """Response for TransferPerformance operation."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "TransferPerformanceResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class TryTransferPerformanceResponse:
    """Response for TryTransferPerformance operation."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "TryTransferPerformanceResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class GenerateReferralCodeResponse:
    """Response for GenerateReferralCode operation."""
    error: Error
    referral_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "GenerateReferralCodeResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            referral_code=data.get("REFERRALCODE"),
        )


@dataclass
class ChangeRedeemProductQuantityResponse:
    """Response for ChangeRedeemProductQuantity operation."""
    error: Error
    sale_ak: str
    ticket_redeem_prod_list: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ChangeRedeemProductQuantityResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            sale_ak=data.get("SALEAK", ""),
            ticket_redeem_prod_list=data.get("TICKETREDEEMPRODLIST"),
        )


@dataclass
class ChangePerformanceCheckOutResponse:
    """Response for ChangePerformanceCheckOut operation."""
    error: Error
    item_list: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    sale: Optional[Dict[str, Any]] = None
    reservation: Optional[Dict[str, Any]] = None
    merchant_code: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ChangePerformanceCheckOutResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            item_list=data.get("ITEMLIST"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            sale=data.get("SALE"),
            reservation=data.get("RESERVATION"),
            merchant_code=data.get("MERCHANTCODE"),
        )


@dataclass
class UpdateExternalReservationCodeResponse:
    """Response for UpdateExternalReservationCode operation."""
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "UpdateExternalReservationCodeResponse":
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
        )
