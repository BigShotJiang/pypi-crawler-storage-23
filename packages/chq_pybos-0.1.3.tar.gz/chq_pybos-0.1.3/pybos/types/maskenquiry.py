"""
Type definitions for MaskEnquiry.

This module provides structured classes for mask operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, PageRequest, PageResponse


# Request Classes
@dataclass
class SearchDataMaskRequest:
    """Request for SearchDataMask operation.
    
    Based on MaskEnquiry.xsd SEARCHDATAMASKREQ type.
    
    Attributes:
        dmg_category_ak_list: Demographic category AK list (optional)
        matrix_cell_ak: Matrix cell AK (optional)
        search_in_all_datamask_categories: Search in all DataMask categories flag (optional)
        page_req: Page request (optional)
    """
    
    dmg_category_ak_list: Optional[List[str]] = None
    matrix_cell_ak: Optional[str] = None
    search_in_all_datamask_categories: Optional[int] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.dmg_category_ak_list is not None:
            result["DMGCATEGORYAKLIST"] = {
                "DMGCATEGORYAKITEM": [
                    {"DMGCATEGORYAK": ak} for ak in self.dmg_category_ak_list
                ]
            }
        if self.matrix_cell_ak is not None:
            result["MATRIXCELLAK"] = self.matrix_cell_ak
        if self.search_in_all_datamask_categories is not None:
            result["SEARCHINALLDATAMASKCATEGORIES"] = (
                self.search_in_all_datamask_categories
            )
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


@dataclass
class SaveDmgTranslationRequest:
    """Request for SaveDmgTranslation operation.
    
    Based on MaskEnquiry.xsd SAVEDMGTRANSLATIONREQ type.
    
    Attributes:
        language_ak: Language AK (optional)
        dmg_type: Demographic type (7=Event, 8=Performance)
        entity_ak: Entity AK (Event or Performance AK)
        field_list: Field list with translations
    """
    
    dmg_type: int
    entity_ak: str
    field_list: List[Dict[str, Any]]
    language_ak: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "DMGTYPE": self.dmg_type,
            "ENTITYAK": self.entity_ak,
            "FIELDLIST": {"FIELD": self.field_list},
        }
        if self.language_ak is not None:
            result["LANGUAGEAK"] = self.language_ak
        return result


@dataclass
class SaveMaskTableItemRequest:
    """Request for SaveMaskTableItem operation.
    
    Based on MaskEnquiry.xsd SAVEMASKTABLEITEMREQ type.
    
    Attributes:
        mask_table_item: Mask table item data
    """
    
    mask_table_item: Dict[str, Any]
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"SAVEMASKTABLEITEMREQ": self.mask_table_item}


# Response Classes
@dataclass
class FindAllAccountCategoriesResponse:
    """Response for FindAllAccountCategories operation.
    
    Based on MaskEnquiry.xsd FINDALLACCOUNTCATEGORIESRESP type.
    
    Attributes:
        error: Error information
        dmg_category_list: List of demographic categories (optional)
    """
    
    error: Error
    dmg_category_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllAccountCategoriesResponse":
        """Create FindAllAccountCategoriesResponse from API response dictionary."""
        category_data = data.get("DMGCATEGORYLIST", {}).get("DMGCATEGORY")
        category_list = None
        if category_data:
            if isinstance(category_data, list):
                category_list = category_data
            else:
                category_list = [category_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            dmg_category_list=category_list,
        )


@dataclass
class ReadAccountCategoryByCodeResponse:
    """Response for ReadAccountCategoryByCode operation.
    
    Based on MaskEnquiry.xsd READACCOUNTCATEGORYBYCODERESP type.
    
    Attributes:
        error: Error information
        dmg_category: Demographic category information (optional)
    """
    
    error: Error
    dmg_category: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadAccountCategoryByCodeResponse":
        """Create ReadAccountCategoryByCodeResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            dmg_category=data.get("DMGCATEGORY"),
        )


@dataclass
class ReadAccountCategoryByAKResponse:
    """Response for ReadAccountCategoryByAK operation.
    
    Based on MaskEnquiry.xsd READACCOUNTCATEGORYBYAKRESP type.
    
    Attributes:
        error: Error information
        dmg_category: Demographic category information (optional)
    """
    
    error: Error
    dmg_category: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadAccountCategoryByAKResponse":
        """Create ReadAccountCategoryByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            dmg_category=data.get("DMGCATEGORY"),
        )


@dataclass
class ReadExtendedInfoByAKResponse:
    """Response for ReadExtendedInfoByAK operation.
    
    Based on MaskEnquiry.xsd READEXTENEDINFOBYAKRESP type.
    
    Attributes:
        error: Error information
        dmg_category: Demographic category information (optional)
    """
    
    error: Error
    dmg_category: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadExtendedInfoByAKResponse":
        """Create ReadExtendedInfoByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            dmg_category=data.get("DMGCATEGORY"),
        )


@dataclass
class ReadExtendedInfoByCodeResponse:
    """Response for ReadExtendedInfoByCode operation.
    
    Based on MaskEnquiry.xsd READEXTENEDINFOBYCODERESP type.
    
    Attributes:
        error: Error information
        dmg_category: Demographic category information (optional)
    """
    
    error: Error
    dmg_category: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadExtendedInfoByCodeResponse":
        """Create ReadExtendedInfoByCodeResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            dmg_category=data.get("DMGCATEGORY"),
        )


@dataclass
class ReadDataProviderByCodeResponse:
    """Response for ReadDataProviderByCode operation.
    
    Based on MaskEnquiry.xsd READDATAPROVIDERBYCODERESP type.
    
    Attributes:
        error: Error information
        data_provider: Data provider information (optional)
    """
    
    error: Error
    data_provider: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadDataProviderByCodeResponse":
        """Create ReadDataProviderByCodeResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            data_provider=data.get("DATAPROVIDER"),
        )


@dataclass
class ReadImageByAKResponse:
    """Response for ReadImageByAK operation.
    
    Based on MaskEnquiry.xsd READIMAGEBYAKRESP type.
    
    Attributes:
        error: Error information
        image: Image information (value and filename)
    """
    
    error: Error
    image: Dict[str, str]
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadImageByAKResponse":
        """Create ReadImageByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            image=data.get("IMAGE", {}),
        )


@dataclass
class ReadAttachmentByAKResponse:
    """Response for ReadAttachmentByAK operation.
    
    Based on MaskEnquiry.xsd READATTACHMENTBYAKRESP type.
    
    Attributes:
        error: Error information
        attachment: Attachment information (value and filename)
    """
    
    error: Error
    attachment: Dict[str, str]
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadAttachmentByAKResponse":
        """Create ReadAttachmentByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            attachment=data.get("ATTACHMENT", {}),
        )


@dataclass
class SearchDataMaskResponse:
    """Response for SearchDataMask operation.
    
    Based on MaskEnquiry.xsd SEARCHDATAMASKRESP type.
    
    Attributes:
        error: Error information
        dmg_category_list: List of demographic categories (optional)
        page_resp: Page response
    """
    
    error: Error
    dmg_category_list: Optional[List[Dict[str, Any]]] = None
    page_resp: PageResponse = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchDataMaskResponse":
        """Create SearchDataMaskResponse from API response dictionary."""
        category_data = data.get("DMGCATEGORYLIST", {}).get("DMGCATEGORY")
        category_list = None
        if category_data:
            if isinstance(category_data, list):
                category_list = category_data
            else:
                category_list = [category_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            dmg_category_list=category_list,
            page_resp=PageResponse.from_dict(data.get("PAGERESP", {})),
        )


@dataclass
class SaveDmgTranslationResponse:
    """Response for SaveDmgTranslation operation.
    
    Based on MaskEnquiry.xsd SAVEDMGTRANSLATIONRESP type.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "SaveDmgTranslationResponse":
        """Create SaveDmgTranslationResponse from API response dictionary."""
        return cls(error=Error.from_dict(data.get("ERROR", {})))


@dataclass
class SaveMaskTableItemResponse:
    """Response for SaveMaskTableItem operation.
    
    Based on MaskEnquiry.xsd SAVEMASKTABLEITEMRESP type.
    
    Attributes:
        error: Error information
        mask_table_item: Mask table item response data
    """
    
    error: Error
    mask_table_item: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "SaveMaskTableItemResponse":
        """Create SaveMaskTableItemResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            mask_table_item=data.get("SAVEMASKTABLEITEMRESP", {}),
        )
