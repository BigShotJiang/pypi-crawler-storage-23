"""
Type definitions for SeasonalPriceEnquiry.

This module provides structured classes for seasonal price operations.
"""

from dataclasses import dataclass
from typing import List, Dict, Any
from .common import Error


# Response Classes
@dataclass
class ReadSeasonalPriceInfoResponse:
    """Response for ReadSeasonalPriceInfo operation.
    
    Based on SeasonalPriceEnquiry.xsd READSEASONALPRICEINFORESP type.
    
    Attributes:
        error: Error information
        rule_list: Rule list
        price_table_list: Price table list
        price_list_list: Price list list
        ticket_list: Ticket list
        date_list: Date list
    """
    
    error: Error
    rule_list: List[Dict[str, Any]]
    price_table_list: List[Dict[str, Any]]
    price_list_list: List[Dict[str, Any]]
    ticket_list: List[Dict[str, Any]]
    date_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadSeasonalPriceInfoResponse":
        """Create ReadSeasonalPriceInfoResponse from API response dictionary."""
        rule_data = data.get("RULELIST", {}).get("RULE")
        rule_list = []
        if rule_data:
            if isinstance(rule_data, list):
                rule_list = rule_data
            else:
                rule_list = [rule_data]
        price_table_data = data.get("PRICETABLELIST", {}).get("PRICETABLE")
        price_table_list = []
        if price_table_data:
            if isinstance(price_table_data, list):
                price_table_list = price_table_data
            else:
                price_table_list = [price_table_data]
        price_list_data = data.get("PRICELISTLIST", {}).get("PRICELIST")
        price_list_list = []
        if price_list_data:
            if isinstance(price_list_data, list):
                price_list_list = price_list_data
            else:
                price_list_list = [price_list_data]
        ticket_data = data.get("TICKETLIST", {}).get("TICKET")
        ticket_list = []
        if ticket_data:
            if isinstance(ticket_data, list):
                ticket_list = ticket_data
            else:
                ticket_list = [ticket_data]
        date_data = data.get("DATELIST", {}).get("DATE")
        date_list = []
        if date_data:
            if isinstance(date_data, list):
                date_list = date_data
            else:
                date_list = [date_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            rule_list=rule_list,
            price_table_list=price_table_list,
            price_list_list=price_list_list,
            ticket_list=ticket_list,
            date_list=date_list,
        )
