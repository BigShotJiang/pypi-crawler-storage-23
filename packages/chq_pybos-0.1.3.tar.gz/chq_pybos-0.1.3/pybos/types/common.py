"""
Common data types shared across all BOS API services.

This module provides base classes and common structures used by multiple services,
including error handling, basic information structures, and shared utilities.
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any


class PybosAPIError(Exception):
    """Raised when the BOS API returns an error response.

    Attributes:
        code: Error code from the API (e.g. 1002)
        type: Error type (e.g. 'Managed')
        text: Human-readable error message (e.g. 'Unable to Retrieve Account')
    """

    def __init__(self, error: "Error"):
        self.code = error.code
        self.type = error.type
        self.text = error.text
        super().__init__(f"API Error {self.code}: {self.text or 'Unknown error'}")

    def __str__(self) -> str:
        return f"API Error {self.code}: {self.text or 'Unknown error'}"


@dataclass
class Error:
    """Standard error response structure used across all BOS API services.

    Based on APICommon.xsd ERROR type. This class provides consistent error
    handling across all service operations.

    Attributes:
        code: Error code (200 = success, other values indicate errors)
        type: Error type description
        text: Human-readable error message
    """

    code: int
    type: Optional[str] = None
    text: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Error":
        """Create Error from API response dictionary.

        Args:
            data: Dictionary containing error information from API response

        Returns:
            Error instance with parsed error information
        """
        raw_code = data.get("CODE", 0)
        code = int(raw_code) if raw_code else 0
        return cls(
            code=code,
            type=data.get("TYPE"),
            text=data.get("TEXT"),
        )

    @property
    def is_success(self) -> bool:
        """Check if the error code indicates success.

        Returns:
            True if code is 200 (success), False otherwise
        """
        return self.code == 200

    def __str__(self) -> str:
        """String representation of the error."""
        if self.is_success:
            return "Success"
        return f"Error {self.code}: {self.text or 'Unknown error'}"


@dataclass
class BasicInfo:
    """Basic information structure used across multiple services.

    Based on APICommon.xsd BASICINFO type. This class provides a common structure
    for basic entity information that is shared across different service types.

    Attributes:
        account_ak: Account AK identifier
        dmg_cat_ak: Category code
        display_name: Display name
        account_type: Account type
        note_list: List of notes
        account_id: Account ID
        status: Status (0: Disabled, 1: Enabled)
        billing_account_ak: Billing account AK
    """

    account_ak: str
    dmg_cat_ak: Optional[str] = None
    display_name: Optional[str] = None
    account_type: Optional[int] = None
    note_list: Optional[Dict[str, Any]] = None
    account_id: Optional[int] = None
    status: Optional[int] = None
    billing_account_ak: Optional[str] = None

    @classmethod
    def from_dict(
        cls, data: dict, ak_field: str = "ACCOUNTAK", id_field: str = "ACCOUNTID"
    ) -> "BasicInfo":
        """Create BasicInfo from API response dictionary.

        Args:
            data: Dictionary containing entity information
            ak_field: Field name for the AK identifier
            id_field: Field name for the ID field

        Returns:
            BasicInfo instance with parsed entity information
        """
        return cls(
            account_ak=data.get(ak_field, ""),
            dmg_cat_ak=data.get("DMGCATAK"),
            display_name=data.get("DISPLAYNAME"),
            account_type=data.get("ACCOUNTTYPE"),
            note_list=data.get("NOTELIST"),
            account_id=data.get(id_field),
            status=data.get("STATUS"),
            billing_account_ak=data.get("BILLINGACCOUNTAK"),
        )


@dataclass
class BaseDateFilter:
    """Base date filter structure.

    Based on APICommon.xsd BASEDATEFILTER type.

    Attributes:
        from_date: Start date
        to_date: End date
    """

    from_date: str
    to_date: str

    @classmethod
    def from_dict(cls, data: dict) -> "BaseDateFilter":
        """Create BaseDateFilter from API response dictionary."""
        return cls(
            from_date=data.get("FROM", ""),
            to_date=data.get("TO", ""),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "FROM": self.from_date,
            "TO": self.to_date,
        }


@dataclass
class BaseTimeFilter:
    """Base time filter structure.

    Based on APICommon.xsd BASETIMEFILTER type.

    Attributes:
        from_time: Start time
        to_time: End time
    """

    from_time: str
    to_time: str

    @classmethod
    def from_dict(cls, data: dict) -> "BaseTimeFilter":
        """Create BaseTimeFilter from API response dictionary."""
        return cls(
            from_time=data.get("FROM", ""),
            to_time=data.get("TO", ""),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "FROM": self.from_time,
            "TO": self.to_time,
        }


@dataclass
class PageRequest:
    """Pagination request parameters.

    Based on APICommon.xsd PAGEREQ type.

    Attributes:
        page_index: Page index (0-based)
        page_size: Number of items per page
        sort_direction: Sort direction (ASC, DESC)
    """

    page_index: int = 1
    page_size: int = 10
    sort_direction: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "PageRequest":
        """Create PageRequest from API response dictionary."""
        return cls(
            page_index=data.get("PAGEINDEX", 1),
            page_size=data.get("PAGESIZE", 10),
            sort_direction=data.get("SORTDIRECTION"),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "PAGEINDEX": self.page_index,
            "PAGESIZE": self.page_size,
        }
        if self.sort_direction is not None:
            result["SORTDIRECTION"] = self.sort_direction
        return result


@dataclass
class PageResponse:
    """Pagination response information.

    Based on APICommon.xsd PAGERESP type.

    Attributes:
        page_index: Current page index
        page_count: Total number of pages
        page_size: Items per page
        record_count: Total number of records
    """

    page_index: int
    page_count: int
    page_size: int
    record_count: int

    @classmethod
    def from_dict(cls, data: dict) -> "PageResponse":
        """Create PageResponse from API response dictionary."""
        return cls(
            page_index=data.get("PAGEINDEX", 1),
            page_count=data.get("PAGECOUNT", 0),
            page_size=data.get("PAGESIZE", 10),
            record_count=data.get("RECORDCOUNT", 0),
        )


@dataclass
class EventBase:
    """Base event information structure.

    Based on APICommon.xsd EVENTBASE type.

    Attributes:
        code: Event code
        ak: Event AK
    """

    code: str
    ak: str

    @classmethod
    def from_dict(cls, data: dict) -> "EventBase":
        """Create EventBase from API response dictionary."""
        return cls(
            code=data.get("CODE", ""),
            ak=data.get("AK", ""),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "CODE": self.code,
            "AK": self.ak,
        }


@dataclass
class PerformanceBase:
    """Base performance information structure.

    Based on APICommon.xsd PERFORMANCEBASE type.

    Attributes:
        ak: Performance AK
        event_ak: Event AK
        event_code: Event code
    """

    ak: str
    event_ak: str
    event_code: str

    @classmethod
    def from_dict(cls, data: dict) -> "PerformanceBase":
        """Create PerformanceBase from API response dictionary."""
        return cls(
            ak=data.get("AK", ""),
            event_ak=data.get("EVENTAK", ""),
            event_code=data.get("EVENTCODE", ""),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "AK": self.ak,
            "EVENTAK": self.event_ak,
            "EVENTCODE": self.event_code,
        }


@dataclass
class WorkstationBase:
    """Base workstation information structure.

    Based on APICommon.xsd WORKSTATIONBASE type.

    Attributes:
        ak: Workstation AK
        name: Workstation name
    """

    ak: str
    name: str

    @classmethod
    def from_dict(cls, data: dict) -> "WorkstationBase":
        """Create WorkstationBase from API response dictionary."""
        return cls(
            ak=data.get("AK", ""),
            name=data.get("NAME", ""),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "AK": self.ak,
            "NAME": self.name,
        }


@dataclass
class LocationBase:
    """Base location information structure.

    Based on APICommon.xsd LOCATIONBASE type.

    Attributes:
        ak: Location AK
        code: Location code
    """

    ak: str
    code: str

    @classmethod
    def from_dict(cls, data: dict) -> "LocationBase":
        """Create LocationBase from API response dictionary."""
        return cls(
            ak=data.get("AK", ""),
            code=data.get("CODE", ""),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "AK": self.ak,
            "CODE": self.code,
        }


@dataclass
class Language:
    """Language information structure.

    Based on APICommon.xsd LANGUAGE type.

    Attributes:
        id: Language ID
        code: Language ISO code
        i18n_code: Language i18n code
    """

    id: int
    code: str
    i18n_code: str

    @classmethod
    def from_dict(cls, data: dict) -> "Language":
        """Create Language from API response dictionary."""
        return cls(
            id=data.get("ID", 0),
            code=data.get("CODE", ""),
            i18n_code=data.get("I18NCODE", ""),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "ID": self.id,
            "CODE": self.code,
            "I18NCODE": self.i18n_code,
        }


@dataclass
class Encoding:
    """Encoding information structure.

    Based on APICommon.xsd ENCODING type.

    Attributes:
        site_id: Encoding site ID
        site_name: Encoding site name
        site_code: Encoding site code
        wks_id: Encoding workstation ID
        wks_code: Encoding workstation code
    """

    site_id: int
    site_name: str
    site_code: str
    wks_id: int
    wks_code: str

    @classmethod
    def from_dict(cls, data: dict) -> "Encoding":
        """Create Encoding from API response dictionary."""
        return cls(
            site_id=data.get("SITEID", 0),
            site_name=data.get("SITENAME", ""),
            site_code=data.get("SITECODE", ""),
            wks_id=data.get("WKSID", 0),
            wks_code=data.get("WKSCODE", ""),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "SITEID": self.site_id,
            "SITENAME": self.site_name,
            "SITECODE": self.site_code,
            "WKSID": self.wks_id,
            "WKSCODE": self.wks_code,
        }


@dataclass
class Invoice:
    """Invoice information structure.

    Based on APICommon.xsd INVOICE type.

    Attributes:
        section: Invoice section
        prefix: Invoice prefix
        invoice_number: Invoice number
        suffix: Invoice suffix
    """

    section: str
    prefix: str
    invoice_number: str
    suffix: str

    @classmethod
    def from_dict(cls, data: dict) -> "Invoice":
        """Create Invoice from API response dictionary."""
        return cls(
            section=data.get("SECTION", ""),
            prefix=data.get("PREFIX", ""),
            invoice_number=data.get("INVOICENUMBER", ""),
            suffix=data.get("SUFFIX", ""),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "SECTION": self.section,
            "PREFIX": self.prefix,
            "INVOICENUMBER": self.invoice_number,
            "SUFFIX": self.suffix,
        }


@dataclass
class LookupInfo:
    """Lookup information structure.

    Based on APICommon.xsd LOOKUPINFO type.

    Attributes:
        key: Lookup key
        descr: Description
        value: Value
    """

    key: int
    descr: str
    value: str

    @classmethod
    def from_dict(cls, data: dict) -> "LookupInfo":
        """Create LookupInfo from API response dictionary."""
        return cls(
            key=data.get("KEY", 0),
            descr=data.get("DESCR", ""),
            value=data.get("VALUE", ""),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "KEY": self.key,
            "DESCR": self.descr,
            "VALUE": self.value,
        }


    