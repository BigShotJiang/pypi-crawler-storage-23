"""
Type definitions for WaitListSubscriptionsEnquiry.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any


# TODO: Add type definitions based on WaitListSubscriptionsEnquiry.xsd
