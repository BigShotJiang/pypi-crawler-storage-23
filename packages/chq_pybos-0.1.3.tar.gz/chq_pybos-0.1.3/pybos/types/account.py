"""
Account-related data types for the BOS API.

This module provides structured classes for account operations,
replacing tuple-based parameters with type-safe, self-documenting classes.
"""

from dataclasses import dataclass
from typing import Optional, List, Any
from enum import IntEnum
from .common import Error, BasicInfo, PybosAPIError


class SearchType(IntEnum):
    """Search type enumeration for account filters.

    Based on Account.xsd SEARCHTYPE restriction (lines 830-838):
    - 0: Unknown/Default
    - 1: Equal match
    - 2: Like match (partial)
    """

    UNKNOWN = 0
    EQUAL = 1
    LIKE = 2


class AccountType(IntEnum):
    """Account type enumeration.

    Based on BOS system documentation.
    """

    ORGANIZATION = 1
    PERSON = 2
    RESOURCE = 3
    PRIMARY = 4
    SECONDARY = 5
    SIAE_TITOLARE_TESSERA_TIFOSO = 6
    SIAE_TITOLARE_BIGLIETTO = 7


class AccountStatus(IntEnum):
    """Account status enumeration.

    Based on BOS system documentation.
    """

    DISABLED = 0
    ENABLED = 1
    TO_BE_APPROVED = 90
    REFUSED = 91


class FieldType(IntEnum):
    """Field type enumeration for account fields.

    Based on BOS system documentation.
    """

    TEXT = 0
    IMAGE = 1
    MEMO = 2
    PASSWORD = 3
    HTML = 4
    ATTACHMENT = 6


@dataclass
class AccountFilter:
    """Represents a filter for account search operations.

    Based on Account.xsd FILTER structure (lines 825-841):
    - OBJTYPE: Object type identifier (int)
    - VALUE: Filter value (string)
    - SEARCHTYPE: Type of search to perform (SearchType enum)
    """

    object_type: int
    value: str
    search_type: SearchType

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "OBJTYPE": self.object_type,
            "VALUE": self.value,
            "SEARCHTYPE": self.search_type,
        }


@dataclass
class AccountField:
    """Represents a field for account save operations.

    Based on FIELDLIST structure referenced in Account.xsd (line 636).
    The exact structure depends on the FIELDLIST type definition.
    """

    value: Any
    object_type: int
    field_data_type: Optional[int] = None
    filename: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"VALUE": self.value, "OBJTYPE": self.object_type}
        if self.field_data_type is not None:
            result["FIELDDATATYPE"] = self.field_data_type
        if self.filename is not None:
            result["FILENAME"] = self.filename
        return result


@dataclass
class AccountImage:
    """Represents an image for account save operations.

    Based on Account.xsd IMAGE structure (lines 661-679):
    - FILENAME: Name of the image file (string)
    - FILECONTENT: Image content (string)
    - OBJTYPE: Object type of the field (int)
    """

    filename: str
    file_content: str
    object_type: int

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "FILENAME": self.filename,
            "FILECONTENT": self.file_content,
            "OBJTYPE": self.object_type,
        }


@dataclass
class AccountAttachment:
    """Represents an attachment for account save operations.

    Based on Account.xsd ATTACHMENT structure (lines 694-712):
    - FILENAME: Name of the attachment file (string)
    - FILECONTENT: Attachment content (string)
    - OBJTYPE: Object type of the field (int)
    """

    filename: str
    file_content: str
    object_type: int

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "FILENAME": self.filename,
            "FILECONTENT": self.file_content,
            "OBJTYPE": self.object_type,
        }


@dataclass
class SearchAccountRequest:
    """Structured request for SearchAccount operation.

    Based on Account.xsd SEARCHACCOUNTREQ structure (lines 805-868).
    """

    filters: List[AccountFilter]
    account_ak: Optional[str] = None
    parent_account_ak: Optional[str] = None
    active_only: Optional[bool] = None
    dmg_category_list: Optional[List[str]] = None
    creation_date: Optional[dict] = None  # BASEDATEFILTER type
    page_req: Optional[dict] = None  # PAGEREQ type

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "FILTERLIST": {
                "FILTER": [filter_obj.to_dict() for filter_obj in self.filters]
            }
        }

        if self.account_ak is not None:
            result["ACCOUNTAK"] = self.account_ak
        if self.parent_account_ak is not None:
            result["PARENTACCOUNTAK"] = self.parent_account_ak
        if self.active_only is not None:
            result["ACTIVEONLY"] = self.active_only
        if self.dmg_category_list is not None:
            result["DMGCATEGORYLIST"] = {
                "DMGCATEGORY": [
                    {"DMGCATEGORYAK": cat} for cat in self.dmg_category_list
                ]
            }
        if self.creation_date is not None:
            result["CREATIONDATE"] = self.creation_date
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()

        return result


@dataclass
class SaveAccountRequest:
    """Structured request for SaveAccount operation.

    Based on Account.xsd SAVEACCOUNTREQ structure (lines 634-773).
    """

    dmg_category_ak: str
    fields: List[AccountField]
    account_ak: Optional[str] = None
    parent_account_ak: Optional[str] = None
    status: Optional[AccountStatus] = None
    images: Optional[List[AccountImage]] = None
    attachments: Optional[List[AccountAttachment]] = None
    billing_account_ak: Optional[str] = None
    del_billing_account: Optional[bool] = None
    detail_list: Optional[List[dict]] = None  # Complex nested structure

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "DMGCATEGORYAK": self.dmg_category_ak,
            "FIELDLIST": {"FIELD": [field.to_dict() for field in self.fields]},
        }

        if self.account_ak is not None:
            result["ACCOUNTAK"] = self.account_ak
        if self.parent_account_ak is not None:
            result["PARENTACCOUNTAK"] = self.parent_account_ak
        if self.status is not None:
            result["STATUS"] = self.status
        if self.images is not None:
            result["IMAGELIST"] = {"IMAGE": [image.to_dict() for image in self.images]}
        if self.attachments is not None:
            result["ATTACHMENTLIST"] = {
                "ATTACHMENT": [attachment.to_dict() for attachment in self.attachments]
            }
        if self.billing_account_ak is not None:
            result["BILLINGACCOUNTAK"] = self.billing_account_ak
        if self.del_billing_account is not None:
            result["DELBILLINGACCOUNT"] = self.del_billing_account
        if self.detail_list is not None:
            result["DETAILLIST"] = self.detail_list

        return result


@dataclass
class ChangeAccountCategoryRequest:
    """Structured request for ChangeAccountCategory operation.

    Based on Account.xsd CHANGEACCOUNTCATEGORYREQ structure (lines 289-294).
    """

    account_ak: str
    dmg_category_ak: str

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"ACCOUNTAK": self.account_ak, "DMGCATEGORYAK": self.dmg_category_ak}


@dataclass
class ManageAccountRelationshipRequest:
    """Structured request for ManageAccountRelationship operation.

    Based on WSDL message definition for ManageAccountRelationship9Request.
    """

    source_account_ak: str
    target_account_ak: str
    operation_type: int

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "ASourceAccountAK": self.source_account_ak,
            "ATargetAccountAK": self.target_account_ak,
            "AOperationType": self.operation_type,
        }


@dataclass
class AccountLoginRequest:
    """Structured request for AccountLogIn operation.

    Based on Account.xsd ACCOUNTLOGINREQ structure.
    """

    username: str
    password: str
    dmg_category_ak: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "USERNAME": self.username,
            "PASSWORD": self.password,
        }
        if self.dmg_category_ak is not None:
            result["DMGCATEGORYAK"] = self.dmg_category_ak
        return result


@dataclass
class AddAccountNoteRequest:
    """Structured request for AddAccountNote operation.

    Based on Account.xsd ADDACCOUNTNOTEREQ structure.
    """

    account_ak: str
    note_text: str
    note_type: Optional[int] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "ACCOUNTAK": self.account_ak,
            "NOTETEXT": self.note_text,
        }
        if self.note_type is not None:
            result["NOTETYPE"] = self.note_type
        return result


@dataclass
class ReadAccountSaleHierarchyRequest:
    """Structured request for ReadAccountSaleHierarchy operation.

    Based on Account.xsd READACCOUNTSALEHIERARCHYREQ structure.
    """

    account_ak: str
    include_inactive: Optional[bool] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"ACCOUNTAK": self.account_ak}
        if self.include_inactive is not None:
            result["INCLUDEINACTIVE"] = self.include_inactive
        return result


@dataclass
class FindAccountSaleByDateRequest:
    """Structured request for FindAccountSaleByDate operation.

    Based on Account.xsd FINDACCOUNTSALEBYDATEREQ structure.
    """

    account_ak: str
    start_date: str
    end_date: str
    include_details: Optional[bool] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "ACCOUNTAK": self.account_ak,
            "STARTDATE": self.start_date,
            "ENDDATE": self.end_date,
        }
        if self.include_details is not None:
            result["INCLUDEDETAILS"] = self.include_details
        return result


@dataclass
class MergeAccountRequest:
    """Structured request for MergeAccount operation.

    Based on Account.xsd MERGEACCOUNTREQ structure.
    """

    source_account_ak: str
    target_account_ak: str
    merge_type: Optional[int] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "SOURCEACCOUNTAK": self.source_account_ak,
            "TARGETACCOUNTAK": self.target_account_ak,
        }
        if self.merge_type is not None:
            result["MERGETYPE"] = self.merge_type
        return result


@dataclass
class UnmergeAccountRequest:
    """Structured request for UnmergeAccount operation.

    Based on Account.xsd UNMERGEACCOUNTREQ structure.
    """

    account_ak: str
    unmerge_type: Optional[int] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"ACCOUNTAK": self.account_ak}
        if self.unmerge_type is not None:
            result["UNMERGETYPE"] = self.unmerge_type
        return result


@dataclass
class AddMediaToAccountRequest:
    """Structured request for AddMediaToAccount operation.

    Based on Account.xsd ADDMEDIATOACCOUNTREQ structure.
    """

    account_ak: str
    media_type: (
        int  # This might be different from MediaCodeType, keeping as int for now
    )
    file_content: str
    filename: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "ACCOUNTAK": self.account_ak,
            "MEDIATYPE": self.media_type,
            "FILECONTENT": self.file_content,
        }
        if self.filename is not None:
            result["FILENAME"] = self.filename
        return result


@dataclass
class ChangeAccountStatusRequest:
    """Structured request for ChangeAccountStatus operation.

    Based on Account.xsd CHANGEACCOUNTSTATUSREQ structure.
    """

    account_ak: str
    new_status: AccountStatus
    reason: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "ACCOUNTAK": self.account_ak,
            "NEWSTATUS": self.new_status.value,
        }
        if self.reason is not None:
            result["REASON"] = self.reason
        return result


@dataclass
class ReadAccountTicketsByAkRequest:
    """Structured request for ReadAccountTicketsByAk operation.

    Based on Account.xsd READACCOUNTTICKETSBYAKREQ structure.
    """

    account_ak: str
    include_used: Optional[bool] = None
    include_cancelled: Optional[bool] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"ACCOUNTAK": self.account_ak}
        if self.include_used is not None:
            result["INCLUDEUSED"] = self.include_used
        if self.include_cancelled is not None:
            result["INCLUDECANCELLED"] = self.include_cancelled
        return result


@dataclass
class ResetAccountPasswordRequest:
    """Structured request for ResetAccountPassword operation.

    Based on Account.xsd RESETACCOUNTPASSWORDREQ structure.
    """

    account_ak: str
    new_password: Optional[str] = None
    send_email: Optional[bool] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"ACCOUNTAK": self.account_ak}
        if self.new_password is not None:
            result["NEWPASSWORD"] = self.new_password
        if self.send_email is not None:
            result["SENDEMAIL"] = self.send_email
        return result


@dataclass
class SearchTotalsByStatisticalGroupRequest:
    """Structured request for SearchTotalsByStatisticalGroup operation.

    Based on Account.xsd SEARCHTOTALSBYSTATISTICALGROUPREQ structure.
    """

    dmg_category_ak: str
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    group_by: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"DMGCATEGORYAK": self.dmg_category_ak}
        if self.start_date is not None:
            result["STARTDATE"] = self.start_date
        if self.end_date is not None:
            result["ENDDATE"] = self.end_date
        if self.group_by is not None:
            result["GROUPBY"] = self.group_by
        return result


@dataclass
class ManageAccountGiftAidRequest:
    """Structured request for ManageAccountGiftAid operation.

    Based on Account.xsd MANAGEACCOUNTGIFTAIDREQ structure.
    """

    account_ak: str
    gift_aid_enabled: bool
    gift_aid_amount: Optional[float] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "ACCOUNTAK": self.account_ak,
            "GIFTAIDENABLED": self.gift_aid_enabled,
        }
        if self.gift_aid_amount is not None:
            result["GIFTAIDAMOUNT"] = self.gift_aid_amount
        return result


@dataclass
class SearchZipCodeOnExternalDBRequest:
    """Structured request for SearchZipCodeOnExternalDB operation.

    Based on Account.xsd SEARCHZIPCODEONEXTERNALDBREQ structure.
    """

    zip_code: str
    country_code: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"ZIPCODE": self.zip_code}
        if self.country_code is not None:
            result["COUNTRYCODE"] = self.country_code
        return result


# Response Classes
@dataclass
class ReadAccountByAkResponse:
    """Response for ReadAccountByAK operation.

    Based on Account.xsd READACCOUNTBYAKRESP structure.
    """

    error: Error
    account: Optional[dict] = None  # Full ACCOUNT structure
    media_list: Optional[List[dict]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ReadAccountByAkResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            account=data.get("ACCOUNT"),
            media_list=(
                data.get("MEDIALIST", {}).get("MEDIACODE", [])
                if data.get("MEDIALIST")
                else None
            ),
        )


@dataclass
class ReadAccountByIdResponse:
    """Response for ReadAccountByID operation.

    Based on Account.xsd READACCOUNTBYIDRESP structure.
    """

    error: Error
    account: Optional[dict] = None  # Full ACCOUNT structure

    @classmethod
    def from_dict(cls, data: dict) -> "ReadAccountByIdResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            account=data.get("ACCOUNT"),
        )


@dataclass
class B2BAgencyLoginResponse:
    """Response for B2BAccountLogIn operation.

    Based on Account.xsd B2BAGENCYLOGINRESP structure.
    """

    error: Error
    session_token: Optional[str] = None
    account_info: Optional[BasicInfo] = None

    @classmethod
    def from_dict(cls, data: dict) -> "B2BAgencyLoginResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            session_token=data.get("SESSIONTOKEN"),
            account_info=(
                BasicInfo.from_dict(
                    data.get("ACCOUNTINFO", {}), "ACCOUNTAK", "ACCOUNTID"
                )
                if data.get("ACCOUNTINFO")
                else None
            ),
        )


@dataclass
class AccountLoginResponse:
    """Response for AccountLogIn operation.

    Based on Account.xsd ACCOUNTLOGINRESP structure.
    """

    error: Error
    session_token: Optional[str] = None
    account_info: Optional[BasicInfo] = None

    @classmethod
    def from_dict(cls, data: dict) -> "AccountLoginResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            session_token=data.get("SESSIONTOKEN"),
            account_info=(
                BasicInfo.from_dict(
                    data.get("ACCOUNTINFO", {}), "ACCOUNTAK", "ACCOUNTID"
                )
                if data.get("ACCOUNTINFO")
                else None
            ),
        )


@dataclass
class SearchAccountResponse:
    """Response for SearchAccount operation.

    Based on Account.xsd SEARCHACCOUNTRESP structure.
    """

    error: Error
    account_count: int
    account_list: List[BasicInfo]

    @classmethod
    def from_dict(cls, data: dict) -> "SearchAccountResponse":
        """Create response from API dictionary.

        Raises:
            PybosAPIError: When the API returns an error (e.g. CODE 1002).
        """
        error = Error.from_dict(data.get("ERROR", {"CODE": 200}))
        # if not error.is_success:
        #     raise PybosAPIError(error)

        acc_list = data.get("ACCOUNTLIST")
        if acc_list is None:
            raw_accounts: List[Any] = []
            account_count = 0
        else:
            raw = acc_list.get("ACCOUNT", [])
            raw_accounts = raw if isinstance(raw, list) else ([raw] if raw else [])
            account_count = data.get("ACCOUNTCOUNT", 0)

        return cls(
            error=error,
            account_count=account_count,
            account_list=[BasicInfo.from_dict(acc, "ACCOUNTAK", "ACCOUNTID") for acc in raw_accounts],
        )


@dataclass
class SaveAccountResponse:
    """Response for SaveAccount operation.

    Based on Account.xsd SAVEACCOUNTRESP structure.
    """

    error: Error
    basic_info: Optional[BasicInfo] = None

    @classmethod
    def from_dict(cls, data: dict) -> "SaveAccountResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            basic_info=(
                BasicInfo.from_dict(data.get("BASICINFO", {}), "ACCOUNTAK", "ACCOUNTID")
                if data.get("BASICINFO")
                else None
            ),
        )


@dataclass
class AccountCanPayResponse:
    """Response for AccountCanPay operation.

    Based on Account.xsd ACCOUNTCANPAYRESP structure.
    Attributes:
        error: Error information
        can_pay: Whether the account can pay
        reason: Reason for the payment capability
        remaining_amount: Remaining amount that can be paid (-1 = unlimited)
    """

    error: Error
    can_pay: bool
    reason: Optional[str] = None
    remaining_amount: Optional[float] = None

    @classmethod
    def from_dict(cls, data: dict) -> "AccountCanPayResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            can_pay=data.get("CANPAY", False),
            reason=data.get("REASON"),
        )


@dataclass
class AddAccountNoteResponse:
    """Response for AddAccountNote operation.

    Based on Account.xsd ADDACCOUNTNOTERESP structure.
    """

    error: Error
    note_id: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "AddAccountNoteResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            note_id=data.get("NOTEID"),
        )


@dataclass
class ChangeAccountCategoryResponse:
    """Response for ChangeAccountCategory operation.

    Based on Account.xsd CHANGEACCOUNTCATEGORYRESP structure.
    """

    error: Error
    success: bool = False

    @classmethod
    def from_dict(cls, data: dict) -> "ChangeAccountCategoryResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            success=data.get("SUCCESS", False),
        )


@dataclass
class ReadAccountHierarchyResponse:
    """Response for ReadAccountHierarchy operation.

    Based on Account.xsd READACCOUNTHIERARCHYRESP structure.
    """

    error: Error
    hierarchy: Optional[List[dict]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ReadAccountHierarchyResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            hierarchy=data.get("HIERARCHY"),
        )


@dataclass
class ReadAccountSaleHierarchyResponse:
    """Response for ReadAccountSaleHierarchy operation.

    Based on Account.xsd READACCOUNTSALEHIERARCHYRESP structure.
    """

    error: Error
    sale_hierarchy: Optional[List[dict]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ReadAccountSaleHierarchyResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            sale_hierarchy=data.get("SALEHIERARCHY"),
        )


@dataclass
class ReadAccountHistoryByAkResponse:
    """Response for ReadAccountHistoryByAK operation.

    Based on Account.xsd READACCOUNTHISTORYBYAKRESP structure.
    """

    error: Error
    history: Optional[List[dict]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ReadAccountHistoryByAkResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            history=data.get("HISTORY"),
        )


@dataclass
class ManageAccountRelationshipResponse:
    """Response for ManageAccountRelationship operation.

    Based on Account.xsd MANAGEACCOUNTRELATIONSHIPRESP structure.
    """

    error: Error
    success: bool = False

    @classmethod
    def from_dict(cls, data: dict) -> "ManageAccountRelationshipResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            success=data.get("SUCCESS", False),
        )


@dataclass
class PrintAccountPdfResponse:
    """Response for PrintAccountPDF operation.

    Based on Account.xsd PRINTACCOUNTPDFRESP structure.
    """

    error: Error
    pdf_content: Optional[str] = None
    filename: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "PrintAccountPdfResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            pdf_content=data.get("PDFCONTENT"),
            filename=data.get("FILENAME"),
        )


@dataclass
class ChangeAccountPasswordResponse:
    """Response for ChangeAccountPassword operation.

    Based on Account.xsd CHANGEACCOUNTPASSWORDRESP structure.
    """

    error: Error
    success: bool = False

    @classmethod
    def from_dict(cls, data: dict) -> "ChangeAccountPasswordResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            success=data.get("SUCCESS", False),
        )


@dataclass
class FindAccountSaleByDateResponse:
    """Response for FindAccountSaleByDate operation.

    Based on Account.xsd FINDACCOUNTSALEBYDATERESP structure.
    """

    error: Error
    sales: Optional[List[dict]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "FindAccountSaleByDateResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            sales=data.get("SALES"),
        )


@dataclass
class MergeAccountResponse:
    """Response for MergeAccount operation.

    Based on Account.xsd MERGEACCOUNTRESP structure.
    """

    error: Error
    success: bool = False
    merged_account: Optional[BasicInfo] = None

    @classmethod
    def from_dict(cls, data: dict) -> "MergeAccountResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            success=data.get("SUCCESS", False),
            merged_account=(
                BasicInfo.from_dict(
                    data.get("MERGEDACCOUNT", {}), "ACCOUNTAK", "ACCOUNTID"
                )
                if data.get("MERGEDACCOUNT")
                else None
            ),
        )


@dataclass
class UnmergeAccountResponse:
    """Response for UnmergeAccount operation.

    Based on Account.xsd UNMERGEACCOUNTRESP structure.
    """

    error: Error
    success: bool = False

    @classmethod
    def from_dict(cls, data: dict) -> "UnmergeAccountResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            success=data.get("SUCCESS", False),
        )


@dataclass
class GetAccountCsvResponse:
    """Response for GetAccountCSV operation.

    Based on Account.xsd GETACCOUNTCSVRESP structure.
    """

    error: Error
    csv_content: Optional[str] = None
    filename: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "GetAccountCsvResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            csv_content=data.get("CSVCONTENT"),
            filename=data.get("FILENAME"),
        )


@dataclass
class ReadSaleRestrictionResponse:
    """Response for ReadSaleRestriction operation.

    Based on Account.xsd READSALERESTRICTIONRESP structure.
    """

    error: Error
    restrictions: Optional[List[dict]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ReadSaleRestrictionResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            restrictions=data.get("RESTRICTIONS"),
        )


@dataclass
class AddMediaToAccountResponse:
    """Response for AddMediaToAccount operation.

    Based on Account.xsd ADDMEDIATOACCOUNTRESP structure.
    """

    error: Error
    media_id: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "AddMediaToAccountResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            media_id=data.get("MEDIAID"),
        )


@dataclass
class ChangeAccountStatusResponse:
    """Response for ChangeAccountStatus operation.

    Based on Account.xsd CHANGEACCOUNTSTATUSRESP structure.
    """

    error: Error
    success: bool = False

    @classmethod
    def from_dict(cls, data: dict) -> "ChangeAccountStatusResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            success=data.get("SUCCESS", False),
        )


@dataclass
class ReadAccountTicketsByAkResponse:
    """Response for ReadAccountTicketsByAk operation.

    Based on Account.xsd READACCOUNTTICKETSBYAKRESP structure.
    """

    error: Error
    tickets: Optional[List[dict]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ReadAccountTicketsByAkResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            tickets=data.get("TICKETS"),
        )


@dataclass
class ResetAccountPasswordResponse:
    """Response for ResetAccountPassword operation.

    Based on Account.xsd RESETACCOUNTPASSWORDRESP structure.
    """

    error: Error
    success: bool = False
    new_password: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ResetAccountPasswordResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            success=data.get("SUCCESS", False),
            new_password=data.get("NEWPASSWORD"),
        )


@dataclass
class SearchTotalsByStatisticalGroupResponse:
    """Response for SearchTotalsByStatisticalGroup operation.

    Based on Account.xsd SEARCHTOTALSBYSTATISTICALGROUPRESP structure.
    """

    error: Error
    totals: Optional[List[dict]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "SearchTotalsByStatisticalGroupResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            totals=data.get("TOTALS"),
        )


@dataclass
class ManageAccountGiftAidResponse:
    """Response for ManageAccountGiftAid operation.

    Based on Account.xsd MANAGEACCOUNTGIFTAIDRESP structure.
    """

    error: Error
    success: bool = False

    @classmethod
    def from_dict(cls, data: dict) -> "ManageAccountGiftAidResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            success=data.get("SUCCESS", False),
        )


@dataclass
class SearchZipCodeOnExternalDbResponse:
    """Response for SearchZipCodeOnExternalDB operation.

    Based on Account.xsd SEARCHZIPCODEONEXTERNALDBRESP structure.
    """

    error: Error
    zip_codes: Optional[List[dict]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "SearchZipCodeOnExternalDbResponse":
        """Create response from API dictionary."""
        zip_code_list = data.get("ZIPCODELIST", {}).get("ZIPCODE", [])
        if not isinstance(zip_code_list, list):
            zip_code_list = [zip_code_list] if zip_code_list else []

        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            zip_codes=zip_code_list,
        )
