"""
Type definitions for SiaeThirdPartyIntegration.

This module provides structured classes for SIAE third party integration operations,
replacing tuple-based parameters with type-safe, self-documenting classes.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error


@dataclass
class SiaeError:
    """SIAE error structure.
    
    Attributes:
        code: Error code (200 = Success)
        type: Error type
        text: Error text
    """
    
    code: int
    type: str
    text: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "SiaeError":
        """Create SiaeError from API response dictionary."""
        return cls(
            code=data.get("CODE", 0),
            type=data.get("TYPE", ""),
            text=data.get("TEXT", ""),
        )


@dataclass
class SiaeWarning:
    """SIAE warning structure.
    
    Attributes:
        code: Warning code
        description: Warning description
    """
    
    code: int
    description: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "SiaeWarning":
        """Create SiaeWarning from API response dictionary."""
        return cls(
            code=data.get("CODE", 0),
            description=data.get("DESCRIPTION", ""),
        )


@dataclass
class Emissione:
    """Emissione structure.
    
    Attributes:
        codice_carta: Card code
        progressivo: Progressive number
        sigillo: Seal
        data: Date
        ora: Time
        tipo_titolo: Title type
        corrispettivo_lordo: Gross amount
        ordine_di_posto: Seat order
        iva_titolo: Title VAT
    """
    
    codice_carta: str
    progressivo: int
    sigillo: str
    data: str
    ora: str
    tipo_titolo: str
    corrispettivo_lordo: float
    ordine_di_posto: str
    iva_titolo: float
    
    @classmethod
    def from_dict(cls, data: dict) -> "Emissione":
        """Create Emissione from API response dictionary."""
        return cls(
            codice_carta=data.get("CODICECARTA", ""),
            progressivo=data.get("PROGRESSIVO", 0),
            sigillo=data.get("SIGILLO", ""),
            data=data.get("DATA", ""),
            ora=data.get("ORA", ""),
            tipo_titolo=data.get("TIPOTITOLO", ""),
            corrispettivo_lordo=data.get("CORRISPETTIVOLORDO", 0.0),
            ordine_di_posto=data.get("ORDINEDIPOSTO", ""),
            iva_titolo=data.get("IVATITOLO", 0.0),
        )
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "CODICECARTA": self.codice_carta,
            "PROGRESSIVO": self.progressivo,
            "SIGILLO": self.sigillo,
            "DATA": self.data,
            "ORA": self.ora,
            "TIPOTITOLO": self.tipo_titolo,
            "CORRISPETTIVOLORDO": self.corrispettivo_lordo,
            "ORDINEDIPOSTO": self.ordine_di_posto,
            "IVATITOLO": self.iva_titolo,
        }


@dataclass
class Abbonamento:
    """Abbonamento structure.
    
    Attributes:
        codice_abbonamento: Subscription code
        progressivo_abbonamento: Subscription progressive
        numero_eventi: Number of events
        tipo_abbonamento: Subscription type (F=Fixed Date, L=Free Date)
        data_limite_abbonamento: Subscription limit date
        rateo: Rate
        iva_rateo: Rate VAT
    """
    
    codice_abbonamento: str
    progressivo_abbonamento: int
    numero_eventi: int
    tipo_abbonamento: str
    data_limite_abbonamento: str
    rateo: float
    iva_rateo: float
    
    @classmethod
    def from_dict(cls, data: dict) -> "Abbonamento":
        """Create Abbonamento from API response dictionary."""
        return cls(
            codice_abbonamento=data.get("CODICEABBONAMENTO", ""),
            progressivo_abbonamento=data.get("PROGRESSIVOABBONAMENTO", 0),
            numero_eventi=data.get("NUMEROEVENTI", 0),
            tipo_abbonamento=data.get("TIPOABBONAMENTO", ""),
            data_limite_abbonamento=data.get("DATALIMITEABBONAMENTO", ""),
            rateo=data.get("RATEO", 0.0),
            iva_rateo=data.get("IVARATEO", 0.0),
        )
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "CODICEABBONAMENTO": self.codice_abbonamento,
            "PROGRESSIVOABBONAMENTO": self.progressivo_abbonamento,
            "NUMEROEVENTI": self.numero_eventi,
            "TIPOABBONAMENTO": self.tipo_abbonamento,
            "DATALIMITEABBONAMENTO": self.data_limite_abbonamento,
            "RATEO": self.rateo,
            "IVARATEO": self.iva_rateo,
        }


@dataclass
class Annullo:
    """Annullo structure.
    
    Attributes:
        codice_carta: Card code
        progressivo: Progressive number
        sigillo: Seal
        data: Date
        ora: Time
    """
    
    codice_carta: str
    progressivo: int
    sigillo: str
    data: str
    ora: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "Annullo":
        """Create Annullo from API response dictionary."""
        return cls(
            codice_carta=data.get("CODICECARTA", ""),
            progressivo=data.get("PROGRESSIVO", 0),
            sigillo=data.get("SIGILLO", ""),
            data=data.get("DATA", ""),
            ora=data.get("ORA", ""),
        )
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "CODICECARTA": self.codice_carta,
            "PROGRESSIVO": self.progressivo,
            "SIGILLO": self.sigillo,
            "DATA": self.data,
            "ORA": self.ora,
        }


@dataclass
class DatiSupporto:
    """Dati supporto structure.
    
    Attributes:
        codice_supporto: Support code
        identificativo_supporto: Support identifier
        descrizione_supporto: Support description (optional)
        identificativo_supporto_alternativo: Alternative support identifier (optional)
    """
    
    codice_supporto: str
    identificativo_supporto: str
    descrizione_supporto: Optional[str] = None
    identificativo_supporto_alternativo: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "DatiSupporto":
        """Create DatiSupporto from API response dictionary."""
        return cls(
            codice_supporto=data.get("CODICESUPPORTO", ""),
            identificativo_supporto=data.get("IDENTIFICATIVOSUPPORTO", ""),
            descrizione_supporto=data.get("DESCRIZIONESUPPORTO"),
            identificativo_supporto_alternativo=data.get("IDENTIFICATIVOSUPPORTOALTERNATIVO"),
        )
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "CODICESUPPORTO": self.codice_supporto,
            "IDENTIFICATIVOSUPPORTO": self.identificativo_supporto,
        }
        if self.descrizione_supporto is not None:
            result["DESCRIZIONESUPPORTO"] = self.descrizione_supporto
        if self.identificativo_supporto_alternativo is not None:
            result["IDENTIFICATIVOSUPPORTOALTERNATIVO"] = self.identificativo_supporto_alternativo
        return result


@dataclass
class Evento:
    """Evento structure.
    
    Attributes:
        codice_locale: Local code
        data: Date
        ora: Time
    """
    
    codice_locale: str
    data: str
    ora: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "Evento":
        """Create Evento from API response dictionary."""
        return cls(
            codice_locale=data.get("CODICELOCALE", ""),
            data=data.get("DATA", ""),
            ora=data.get("ORA", ""),
        )
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "CODICELOCALE": self.codice_locale,
            "DATA": self.data,
            "ORA": self.ora,
        }


@dataclass
class ImportRecordLTARequest:
    """Import record LTA request structure.
    
    Attributes:
        tipo_record: Record type (0=Insert, 1=Update Stato Titolo, 2=Update Swap Media, 3=Update for Void, 9=Void)
        codice_esterno_ak: External code AK
        cf_organizzatore: Organizer tax code
        codice_locale: Local code (optional)
        tipo_genere: Genre type
        codice_sistema_emissione: Emission system code
        cf_sistema_emissione: Emission system tax code
        emissione: Emission data
        abbonamento: Subscription data (optional)
        annullo: Cancellation data (optional)
        dati_supporto: Support data
        stato_titolo: Title status
        lista_eventi: Event list (optional)
    """
    
    tipo_record: int
    codice_esterno_ak: str
    cf_organizzatore: str
    tipo_genere: str
    codice_sistema_emissione: str
    cf_sistema_emissione: str
    emissione: Emissione
    dati_supporto: DatiSupporto
    stato_titolo: str
    codice_locale: Optional[str] = None
    abbonamento: Optional[Abbonamento] = None
    annullo: Optional[Annullo] = None
    lista_eventi: Optional[List[Evento]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "TIPORECORD": self.tipo_record,
            "CODICEESTERNOAK": self.codice_esterno_ak,
            "CFORGANIZZATORE": self.cf_organizzatore,
            "TIPOGENERE": self.tipo_genere,
            "CODICESISTEMAEMISSIONE": self.codice_sistema_emissione,
            "CFSISTEMAEMISSIONE": self.cf_sistema_emissione,
            "EMISSIONE": self.emissione.to_dict(),
            "DATISUPPORTO": self.dati_supporto.to_dict(),
            "STATOTITOLO": self.stato_titolo,
        }
        if self.codice_locale is not None:
            result["CODICELOCALE"] = self.codice_locale
        if self.abbonamento is not None:
            result["ABBONAMENTO"] = self.abbonamento.to_dict()
        if self.annullo is not None:
            result["ANNULLO"] = self.annullo.to_dict()
        if self.lista_eventi is not None:
            result["LISTAEVENTI"] = {"EVENTO": [e.to_dict() for e in self.lista_eventi]}
        return result


@dataclass
class ImportRecordLTAResponse:
    """Import record LTA response structure.
    
    Attributes:
        error: Error information
        error_additional_description: Additional error description (optional)
        warning: Warning information (optional)
    """
    
    error: SiaeError
    error_additional_description: Optional[str] = None
    warning: Optional[SiaeWarning] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ImportRecordLTAResponse":
        """Create ImportRecordLTAResponse from API response dictionary."""
        warning_data = data.get("WARNING")
        return cls(
            error=SiaeError.from_dict(data.get("ERROR", {})),
            error_additional_description=data.get("ERRORADDITIONALDESCRIPTION"),
            warning=SiaeWarning.from_dict(warning_data) if warning_data else None,
        )


@dataclass
class UserLoginThirdPartyRequest:
    """User login third party request structure.
    
    Attributes:
        workstation_ak: Workstation AK
        username: Username
        password: Password
    """
    
    workstation_ak: str
    username: str
    password: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "WORKSTATIONAK": self.workstation_ak,
            "USERNAME": self.username,
            "PASSWORD": self.password,
        }


@dataclass
class UserLoginThirdPartyResponse:
    """User login third party response structure.
    
    Attributes:
        error: Error information
        session_id: Session ID (optional)
        user_code: User code (optional)
        app_server_version: Application server version (optional)
        language_id: Language ID (optional)
        password_expiration: Password expiration date (optional)
        user_ak: User AK (optional)
    """
    
    error: SiaeError
    session_id: Optional[str] = None
    user_code: Optional[str] = None
    app_server_version: Optional[str] = None
    language_id: Optional[int] = None
    password_expiration: Optional[str] = None
    user_ak: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "UserLoginThirdPartyResponse":
        """Create UserLoginThirdPartyResponse from API response dictionary."""
        return cls(
            error=SiaeError.from_dict(data.get("ERROR", {})),
            session_id=data.get("SESSIONID"),
            user_code=data.get("USERCODE"),
            app_server_version=data.get("APPSERVERVERSION"),
            language_id=data.get("LANGUAGEID"),
            password_expiration=data.get("PASSWORDEXPIRATION"),
            user_ak=data.get("USERAK"),
        )


@dataclass
class UserLogoutThirdPartyRequest:
    """User logout third party request structure.
    
    This is an empty request.
    """
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {}


@dataclass
class UserLogoutThirdPartyResponse:
    """User logout third party response structure.
    
    Attributes:
        error: Error information
    """
    
    error: SiaeError
    
    @classmethod
    def from_dict(cls, data: dict) -> "UserLogoutThirdPartyResponse":
        """Create UserLogoutThirdPartyResponse from API response dictionary."""
        return cls(
            error=SiaeError.from_dict(data.get("ERROR", {})),
        )
