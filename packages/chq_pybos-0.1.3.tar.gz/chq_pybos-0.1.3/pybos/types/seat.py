"""
Type definitions for Seat service.

This module provides structured classes for seat operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error


# Request Classes
@dataclass
class SeatInfoRequest:
    """Request for SeatInfo operation.
    
    Based on Seat.xsd SEATINFOREQ type.
    
    Attributes:
        space_structure_ak: Space structure AK
        only_available: Only available flag (optional)
        billing_account: Billing account (optional)
        logged_account: Logged account (optional)
        best_seat: Best seat information (optional)
        matrix_cell_ak: Matrix cell AK (optional)
        return_product: Return product flag (optional)
    """
    
    space_structure_ak: str
    only_available: Optional[bool] = None
    billing_account: Optional[Dict[str, Any]] = None
    logged_account: Optional[Dict[str, Any]] = None
    best_seat: Optional[Dict[str, Any]] = None
    matrix_cell_ak: Optional[str] = None
    return_product: Optional[bool] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"SPACESTRUCTUREAK": self.space_structure_ak}
        if self.only_available is not None:
            result["ONLYAVAILABLE"] = self.only_available
        if self.billing_account is not None:
            result["BILLINGACCOUNT"] = self.billing_account
        if self.logged_account is not None:
            result["LOGGEDACCOUNT"] = self.logged_account
        if self.best_seat is not None:
            result["BESTSEAT"] = self.best_seat
        if self.matrix_cell_ak is not None:
            result["MATRIXCELLAK"] = self.matrix_cell_ak
        if self.return_product is not None:
            result["RETURNPRODUCT"] = self.return_product
        return result


@dataclass
class HoldSeatRequest:
    """Request for HoldSeat operation.
    
    Based on Seat.xsd HOLDSEATREQ type.
    
    Attributes:
        space_structure_ak: Space structure AK
        seat_list: Seat list (SEATINFOLISTBASE type)
        item_guid: Item GUID
    """
    
    space_structure_ak: str
    seat_list: Dict[str, Any]  # SEATINFOLISTBASE type
    item_guid: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "SPACESTRUCTUREAK": self.space_structure_ak,
            "SEATLIST": self.seat_list,
            "ITEMGUID": self.item_guid,
        }


@dataclass
class ReleaseSeatRequest:
    """Request for ReleaseSeat operation.
    
    Based on Seat.xsd RELEASESEATREQ type.
    
    Attributes:
        space_structure_ak: Space structure AK
        seat_list: Seat list (SEATINFOLISTBASE type)
        item_guid: Item GUID
    """
    
    space_structure_ak: str
    seat_list: Dict[str, Any]  # SEATINFOLISTBASE type
    item_guid: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "SPACESTRUCTUREAK": self.space_structure_ak,
            "SEATLIST": self.seat_list,
            "ITEMGUID": self.item_guid,
        }


@dataclass
class SeatInfoSubscriptionRequest:
    """Request for SeatInfoSubscription operation.
    
    Based on Seat.xsd SEATINFOSUBSCRIPTIONREQ type.
    
    Attributes:
        space_structure_ak: Space structure AK
        only_available: Only available flag (optional)
        billing_account: Billing account (optional)
        logged_account: Logged account (optional)
        matrix_cell_ak: Matrix cell AK (optional)
        return_product: Return product flag (optional)
        seat_list: Seat list (optional)
    """
    
    space_structure_ak: str
    only_available: Optional[bool] = None
    billing_account: Optional[Dict[str, Any]] = None
    logged_account: Optional[Dict[str, Any]] = None
    matrix_cell_ak: Optional[str] = None
    return_product: Optional[bool] = None
    seat_list: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"SPACESTRUCTUREAK": self.space_structure_ak}
        if self.only_available is not None:
            result["ONLYAVAILABLE"] = self.only_available
        if self.billing_account is not None:
            result["BILLINGACCOUNT"] = self.billing_account
        if self.logged_account is not None:
            result["LOGGEDACCOUNT"] = self.logged_account
        if self.matrix_cell_ak is not None:
            result["MATRIXCELLAK"] = self.matrix_cell_ak
        if self.return_product is not None:
            result["RETURNPRODUCT"] = self.return_product
        if self.seat_list is not None:
            result["SEATLIST"] = self.seat_list
        return result


@dataclass
class HoldSeatSubscriptionRequest:
    """Request for HoldSeatSubscription operation.
    
    Based on Seat.xsd HOLDSEATSUBSCRIPTIONREQ type.
    
    Attributes:
        parent_seat_list: Parent seat list (optional)
    """
    
    parent_seat_list: Optional[List[Dict[str, Any]]] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.parent_seat_list is not None:
            result["PARENTSEATLIST"] = {"PARENTSEAT": self.parent_seat_list}
        return result


# Response Classes
@dataclass
class SeatInfoResponse:
    """Response for SeatInfo operation.
    
    Based on Seat.xsd SEATINFORESP type.
    
    Attributes:
        error: Error information
        seat_info_list: Seat info list (SEATINFOLIST type)
        best_seat_list: Best seat list (optional)
        item_guid: Item GUID (optional)
    """
    
    error: Error
    seat_info_list: Dict[str, Any]  # SEATINFOLIST type
    best_seat_list: Optional[Dict[str, Any]] = None
    item_guid: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SeatInfoResponse":
        """Create SeatInfoResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            seat_info_list=data.get("SEATINFOLIST", {}),
            best_seat_list=data.get("BESTSEATLIST"),
            item_guid=data.get("ITEMGUID"),
        )


@dataclass
class HoldSeatResponse:
    """Response for HoldSeat operation.
    
    Based on Seat.xsd HOLDSEATRESP type.
    
    Attributes:
        error: Error information
        seat_list: Seat list (optional)
        item_guid: Item GUID (optional)
    """
    
    error: Error
    seat_list: Optional[Dict[str, Any]] = None
    item_guid: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "HoldSeatResponse":
        """Create HoldSeatResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            seat_list=data.get("SEATLIST"),
            item_guid=data.get("ITEMGUID"),
        )


@dataclass
class ReleaseSeatResponse:
    """Response for ReleaseSeat operation.
    
    Based on Seat.xsd RELEASESEATRESP type.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReleaseSeatResponse":
        """Create ReleaseSeatResponse from API response dictionary."""
        return cls(error=Error.from_dict(data.get("ERROR", {})))


@dataclass
class SeatInfoSubscriptionResponse:
    """Response for SeatInfoSubscription operation.
    
    Based on Seat.xsd SEATINFOSUBSCRIPTIONRESP type.
    
    Attributes:
        error: Error information
        seat_list: Seat list (optional)
    """
    
    error: Error
    seat_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SeatInfoSubscriptionResponse":
        """Create SeatInfoSubscriptionResponse from API response dictionary."""
        seat_data = data.get("SEATLIST", {}).get("SEAT")
        seat_list = None
        if seat_data:
            if isinstance(seat_data, list):
                seat_list = seat_data
            else:
                seat_list = [seat_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            seat_list=seat_list,
        )


@dataclass
class HoldSeatSubscriptionResponse:
    """Response for HoldSeatSubscription operation.
    
    Based on Seat.xsd HOLDSEATSUBSCRIPTIONRESP type.
    
    Attributes:
        error: Error information
        parent_seat_list: Parent seat list (optional)
    """
    
    error: Error
    parent_seat_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "HoldSeatSubscriptionResponse":
        """Create HoldSeatSubscriptionResponse from API response dictionary."""
        parent_seat_data = data.get("PARENTSEATLIST", {}).get("PARENTSEAT")
        parent_seat_list = None
        if parent_seat_data:
            if isinstance(parent_seat_data, list):
                parent_seat_list = parent_seat_data
            else:
                parent_seat_list = [parent_seat_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            parent_seat_list=parent_seat_list,
        )
