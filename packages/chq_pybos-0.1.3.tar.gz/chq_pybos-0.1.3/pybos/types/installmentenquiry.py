"""
Type definitions for InstallmentEnquiry.

This module provides structured classes for installment operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error


# Request Classes
@dataclass
class UpdatePaymentInfoRequest:
    """Request for UpdatePaymentInfo operation.
    
    Based on InstallmentEnquiry.xsd UPDATEPAYMENTINFOREQ type.
    
    Attributes:
        payment_flex_ak: Payment flex AK
        payment_flex_info: Payment flex info (PAYMENTFLEXINFO type)
    """
    
    payment_flex_ak: str
    payment_flex_info: Dict[str, Any]  # PAYMENTFLEXINFO type
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "PAYMENTFLEXAK": self.payment_flex_ak,
            "PAYMENTFLEXINFO": self.payment_flex_info,
        }


@dataclass
class PayInstallmentAmountRequest:
    """Request for PayInstallmentAmount operation.
    
    Based on InstallmentEnquiry.xsd PAYINSTALLMENTAMOUNTREQ type.
    
    Attributes:
        payment_flex_ak: Payment flex AK
        amount: Amount to pay
    """
    
    payment_flex_ak: str
    amount: float
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "PAYMENTFLEXAK": self.payment_flex_ak,
            "AMOUNT": self.amount,
        }


@dataclass
class UpdateRetryInstallmentRequest:
    """Request for UpdateRetryInstallment operation.
    
    Based on InstallmentEnquiry.xsd UPDATERETRYINSTALLMENTREQ type.
    
    Attributes:
        payment_plan_list: Payment plan list
    """
    
    payment_plan_list: List[str]  # List of payment plan AKs
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "PAYMENTPLANLIST": {
                "PAYMENTPLAN": [{"AK": ak} for ak in self.payment_plan_list]
            }
        }


@dataclass
class CancelInstallmentPlanRequest:
    """Request for CancelInstallment operation.
    
    Based on InstallmentEnquiry.xsd CANCELINSTALLMENTPLANREQ type.
    
    Attributes:
        payment_flex_ak: Payment flex AK
    """
    
    payment_flex_ak: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"PAYMENTFLEXAK": self.payment_flex_ak}


@dataclass
class VoidInstallmentPlanRequest:
    """Request for VoidInstallmentPlan operation.
    
    Based on InstallmentEnquiry.xsd VOIDINSTALLMENTPLANREQ type.
    
    Attributes:
        payment_flex_ak: Payment flex AK
        void_fee: Void fee flag (optional, default: False)
    """
    
    payment_flex_ak: str
    void_fee: Optional[bool] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"PAYMENTFLEXAK": self.payment_flex_ak}
        if self.void_fee is not None:
            result["VOIDFEE"] = self.void_fee
        return result


# Response Classes
@dataclass
class ReadInstallmentInfoByAccountAKResponse:
    """Response for ReadInstallmentInfoByAccountAK operation.
    
    Based on InstallmentEnquiry.xsd READINSTALLMENTINFOBYACCOUNTAKRESP type.
    
    Attributes:
        error: Error information
        account_ak: Account AK
        installment_list: List of installments
        payor: Payor information
    """
    
    error: Error
    account_ak: str
    installment_list: List[Dict[str, Any]]
    payor: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadInstallmentInfoByAccountAKResponse":
        """Create ReadInstallmentInfoByAccountAKResponse from API response dictionary."""
        installment_data = data.get("INSTALLMENTLIST", {}).get("INSTALLMENT")
        installment_list = []
        if installment_data:
            if isinstance(installment_data, list):
                installment_list = installment_data
            else:
                installment_list = [installment_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account_ak=data.get("ACCOUNTAK", ""),
            installment_list=installment_list,
            payor=data.get("PAYOR", {}),
        )


@dataclass
class UpdatePaymentInfoResponse:
    """Response for UpdatePaymentInfo operation.
    
    Based on InstallmentEnquiry.xsd UPDATEPAYMENTINFORESP type.
    
    Attributes:
        error: Error information
        payment_flex_ak: Payment flex AK
    """
    
    error: Error
    payment_flex_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "UpdatePaymentInfoResponse":
        """Create UpdatePaymentInfoResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            payment_flex_ak=data.get("PAYMENTFLEXAK", ""),
        )


@dataclass
class ChangeContractStatusResponse:
    """Response for ReactivateContract and DeactivateContract operations.
    
    Based on InstallmentEnquiry.xsd CHANGECONTRACTSTATUSRESP type.
    
    Attributes:
        error: Error information
        payment_flex_ak: Payment flex AK
    """
    
    error: Error
    payment_flex_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "ChangeContractStatusResponse":
        """Create ChangeContractStatusResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            payment_flex_ak=data.get("PAYMENTFLEXAK", ""),
        )


@dataclass
class TryCancelAutoRenewResponse:
    """Response for TryCancelAutoRenew operation.
    
    Based on InstallmentEnquiry.xsd TRYCANCELAUTORENEWRESP type.
    
    Attributes:
        error: Error information
        payment_flex_ak: Payment flex AK
        fee_amount: Fee amount
        fee_list: List of fees
    """
    
    error: Error
    payment_flex_ak: str
    fee_amount: float
    fee_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "TryCancelAutoRenewResponse":
        """Create TryCancelAutoRenewResponse from API response dictionary."""
        fee_data = data.get("FEELIST", {}).get("FEE")
        fee_list = []
        if fee_data:
            if isinstance(fee_data, list):
                fee_list = fee_data
            else:
                fee_list = [fee_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            payment_flex_ak=data.get("PAYMENTFLEXAK", ""),
            fee_amount=data.get("FEEAMOUNT", 0.0),
            fee_list=fee_list,
        )


@dataclass
class CancelAutoRenewResponse:
    """Response for CancelAutoRenew operation.
    
    Based on InstallmentEnquiry.xsd CANCELAUTORENEWRESP type.
    
    Attributes:
        error: Error information
        payment_flex_ak: Payment flex AK
        fee_amount: Fee amount
        fee_list: List of fees
        sale: Sale information
    """
    
    error: Error
    payment_flex_ak: str
    fee_amount: float
    fee_list: List[Dict[str, Any]]
    sale: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "CancelAutoRenewResponse":
        """Create CancelAutoRenewResponse from API response dictionary."""
        fee_data = data.get("FEELIST", {}).get("FEE")
        fee_list = []
        if fee_data:
            if isinstance(fee_data, list):
                fee_list = fee_data
            else:
                fee_list = [fee_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            payment_flex_ak=data.get("PAYMENTFLEXAK", ""),
            fee_amount=data.get("FEEAMOUNT", 0.0),
            fee_list=fee_list,
            sale=data.get("SALE", {}),
        )


@dataclass
class ReActivateAutoRenewResponse:
    """Response for ReActivateAutoRenew operation.
    
    Based on InstallmentEnquiry.xsd REACTIVATEAUTORENEWRESP type.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReActivateAutoRenewResponse":
        """Create ReActivateAutoRenewResponse from API response dictionary."""
        return cls(error=Error.from_dict(data.get("ERROR", {})))


@dataclass
class PayInstallmentAmountResponse:
    """Response for PayInstallmentAmount operation.
    
    Based on InstallmentEnquiry.xsd PAYINSTALLMENTAMOUNTRESP type.
    
    Attributes:
        payment_flex_ak: Payment flex AK
        error: Error information
        sale_ak: Sale AK
    """
    
    payment_flex_ak: str
    error: Error
    sale_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "PayInstallmentAmountResponse":
        """Create PayInstallmentAmountResponse from API response dictionary."""
        return cls(
            payment_flex_ak=data.get("PAYMENTFLEXAK", ""),
            error=Error.from_dict(data.get("ERROR", {})),
            sale_ak=data.get("SALEAK", ""),
        )


@dataclass
class ReadInstallmentInfoByAKResponse:
    """Response for ReadInstallmentInfoByAK operation.
    
    Based on InstallmentEnquiry.xsd READINSTALLMENTINFOBYAKRESP type.
    
    Attributes:
        error: Error information
        payment_flex_ak: Payment flex AK
        installment: Installment information
    """
    
    error: Error
    payment_flex_ak: str
    installment: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadInstallmentInfoByAKResponse":
        """Create ReadInstallmentInfoByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            payment_flex_ak=data.get("PAYMENTFLEXAK", ""),
            installment=data.get("INSTALLMENT", {}),
        )


@dataclass
class ReadFlexContractTemplateResponse:
    """Response for ReadFlexContractTemplateByAK operation.
    
    Based on InstallmentEnquiry.xsd READFLEXCONTRACTTEMPLATERESP type.
    
    Attributes:
        error: Error information
        flex_contract_ak: Flex contract AK
        flex_contract: Flex contract information
    """
    
    error: Error
    flex_contract_ak: str
    flex_contract: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadFlexContractTemplateResponse":
        """Create ReadFlexContractTemplateResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            flex_contract_ak=data.get("FLEXCONTRACTAK", ""),
            flex_contract=data.get("FLEXCONTRACT", {}),
        )


@dataclass
class UpdateRetryInstallmentResponse:
    """Response for UpdateRetryInstallment operation.
    
    Based on InstallmentEnquiry.xsd UPDATERETRYINSTALLMENTRESP type.
    
    Attributes:
        error: Error information
        payment_plan_list: Payment plan list with errors
    """
    
    error: Error
    payment_plan_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "UpdateRetryInstallmentResponse":
        """Create UpdateRetryInstallmentResponse from API response dictionary."""
        plan_data = data.get("PAYMENTPLANLIST", {}).get("PAYMENTPLAN")
        plan_list = []
        if plan_data:
            if isinstance(plan_data, list):
                plan_list = plan_data
            else:
                plan_list = [plan_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            payment_plan_list=plan_list,
        )


@dataclass
class ReadFlexContractOperationRightsResponse:
    """Response for ReadFlexContractOperationRights operation.
    
    Based on InstallmentEnquiry.xsd READFLEXCONTRACTOPERATIONRIGHTSRESP type.
    
    Attributes:
        error: Error information
        operation_list: List of operations
    """
    
    error: Error
    operation_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadFlexContractOperationRightsResponse":
        """Create ReadFlexContractOperationRightsResponse from API response dictionary."""
        operation_data = data.get("OPERATIONLIST", {}).get("OPERATION")
        operation_list = []
        if operation_data:
            if isinstance(operation_data, list):
                operation_list = operation_data
            else:
                operation_list = [operation_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            operation_list=operation_list,
        )


@dataclass
class CheckAccountEligibilityAsPayorResponse:
    """Response for CheckAccountEligibilityAsPayor operation.
    
    Based on InstallmentEnquiry.xsd CHECKACCOUNTELIGIBILITYASPAYORRESP type.
    
    Attributes:
        error: Error information
        account_ak: Account AK
        eligible: Whether account is eligible
    """
    
    error: Error
    account_ak: str
    eligible: bool
    
    @classmethod
    def from_dict(cls, data: dict) -> "CheckAccountEligibilityAsPayorResponse":
        """Create CheckAccountEligibilityAsPayorResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account_ak=data.get("ACCOUNTAK", ""),
            eligible=data.get("ELIGIBLE", False),
        )


@dataclass
class CancelInstallmentPlanResponse:
    """Response for CancelInstallment operation.
    
    Based on InstallmentEnquiry.xsd CANCELINSTALLMENTPLANRESP type.
    
    Attributes:
        ak: Payment plan AK
        error: Error information
        payment_flex_ak: Payment flex AK
    """
    
    ak: str
    error: Error
    payment_flex_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "CancelInstallmentPlanResponse":
        """Create CancelInstallmentPlanResponse from API response dictionary."""
        return cls(
            ak=data.get("AK", ""),
            error=Error.from_dict(data.get("ERROR", {})),
            payment_flex_ak=data.get("PAYMENTFLEXAK", ""),
        )


@dataclass
class VoidInstallmentPlanResponse:
    """Response for VoidInstallmentPlan operation.
    
    Based on InstallmentEnquiry.xsd VOIDINSTALLMENTPLANRESP type.
    
    Attributes:
        error: Error information
        payment_flex_ak: Payment flex AK
        sale: Order sale information
        installment: Installment information
    """
    
    error: Error
    payment_flex_ak: str
    sale: Dict[str, Any]
    installment: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "VoidInstallmentPlanResponse":
        """Create VoidInstallmentPlanResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            payment_flex_ak=data.get("PAYMENTFLEXAK", ""),
            sale=data.get("SALE", {}),
            installment=data.get("INSTALLMENT", {}),
        )
