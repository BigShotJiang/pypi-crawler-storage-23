"""
User-related data types for the BOS API.

This module provides structured classes for user operations,
replacing tuple-based parameters with type-safe, self-documenting classes.
"""

from dataclasses import dataclass
from typing import Optional, List
from .common import Error


@dataclass
class UserInfo:
    """User information structure.

    Based on UserOperation.xsd USERINFO type.

    Attributes:
        ak: User AK identifier
        code: User code
        name: User name
        description: User description
        ext_auth: External authentication info
        note: User notes
        status: User status
        role_list: List of user roles
        expiration_date: User expiration date
    """

    ak: str
    code: str
    name: str
    description: str
    ext_auth: str
    note: str
    status: str
    role_list: Optional[List[dict]] = None
    expiration_date: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "UserInfo":
        """Create UserInfo from API response dictionary."""
        return cls(
            ak=data.get("AK", ""),
            code=data.get("CODE", ""),
            name=data.get("NAME", ""),
            description=data.get("DESCRIPTION", ""),
            ext_auth=data.get("EXTAUTH", ""),
            note=data.get("NOTE", ""),
            status=data.get("STATUS", ""),
            role_list=data.get("ROLELIST"),
            expiration_date=data.get("EXPIRATIONDATE"),
        )


@dataclass
class PaymentMethod:
    """Payment method information structure.

    Based on UserOperation.xsd PAYMENTMETHOD type.

    Attributes:
        ak: Payment method AK
        code: Payment method code
        name: Payment method name
        description: Payment method description
        status: Payment method status
    """

    ak: str
    code: str
    name: str
    description: str
    status: str

    @classmethod
    def from_dict(cls, data: dict) -> "PaymentMethod":
        """Create PaymentMethod from API response dictionary."""
        return cls(
            ak=data.get("AK", ""),
            code=data.get("CODE", ""),
            name=data.get("NAME", ""),
            description=data.get("DESCRIPTION", ""),
            status=data.get("STATUS", ""),
        )


# Request Classes
@dataclass
class SearchUserRequest:
    """Structured request for SearchUser operation.

    Based on UserOperation.xsd SEARCHUSERREQ structure.

    Attributes:
        filters: Search filters
        user_ak: Specific user AK to search for
        active_only: Whether to search only active users
    """

    filters: Optional[List[dict]] = None
    user_ak: Optional[str] = None
    active_only: Optional[bool] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.filters is not None:
            result["FILTERLIST"] = {"FILTER": self.filters}
        if self.user_ak is not None:
            result["USERAK"] = self.user_ak
        if self.active_only is not None:
            result["ACTIVEONLY"] = self.active_only
        return result


@dataclass
class SearchUserRoleRequest:
    """Structured request for SearchUserRole operation.

    Based on UserOperation.xsd SEARCHUSERROLEREQ structure.

    Attributes:
        role_filters: Role search filters
        user_ak: User AK to search roles for
    """

    role_filters: Optional[List[dict]] = None
    user_ak: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.role_filters is not None:
            result["ROLEFILTERLIST"] = {"ROLEFILTER": self.role_filters}
        if self.user_ak is not None:
            result["USERAK"] = self.user_ak
        return result


@dataclass
class SaveUserRequest:
    """Structured request for SaveUser operation.

    Based on UserOperation.xsd SAVEUSERREQ structure.

    Attributes:
        user_info: User information to save
        password: User password
        confirm_password: Password confirmation
        role_list: List of user roles
    """

    user_info: UserInfo
    password: Optional[str] = None
    confirm_password: Optional[str] = None
    role_list: Optional[List[dict]] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "USERINFO": {
                "AK": self.user_info.ak,
                "CODE": self.user_info.code,
                "NAME": self.user_info.name,
                "DESCRIPTION": self.user_info.description,
                "EXTAUTH": self.user_info.ext_auth,
                "NOTE": self.user_info.note,
                "STATUS": self.user_info.status,
            }
        }

        if self.user_info.role_list is not None:
            result["USERINFO"]["ROLELIST"] = self.user_info.role_list
        if self.user_info.expiration_date is not None:
            result["USERINFO"]["EXPIRATIONDATE"] = self.user_info.expiration_date
        if self.password is not None:
            result["PASSWORD"] = self.password
        if self.confirm_password is not None:
            result["CONFIRMPASSWORD"] = self.confirm_password
        if self.role_list is not None:
            result["ROLELIST"] = {"ROLE": self.role_list}

        return result


# Response Classes
@dataclass
class UserLoginResponse:
    """Response for UserLogin operation.

    Based on UserOperation.xsd USERLOGINRESP structure.

    Attributes:
        error: Error information
        session_id: Session ID token for authenticated user
        user_code: User code used to login
        app_server_version: Application server version
        language_id: Default language ID for the logged in user (-1 means unset)
        password_expiration: Password expiration date
        user_ak: AK of the logged in user
        price_list_list: Price lists associated to the logged in workstation
        payment_method_list: Payment methods associated to the logged in workstation
    """

    error: Error
    session_id: Optional[str] = None
    user_code: Optional[str] = None
    app_server_version: Optional[str] = None
    language_id: Optional[int] = None
    password_expiration: Optional[str] = None
    user_ak: Optional[str] = None
    price_list_list: Optional[List[dict]] = None
    payment_method_list: Optional[List[PaymentMethod]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "UserLoginResponse":
        """Create response from API dictionary."""
        payment_methods = []
        if data.get("PAYMENTMETHODLIST"):
            pm_list = data["PAYMENTMETHODLIST"].get("PAYMENTMETHOD", [])
            if not isinstance(pm_list, list):
                pm_list = [pm_list] if pm_list else []
            payment_methods = [PaymentMethod.from_dict(pm) for pm in pm_list]

        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            session_id=data.get("SESSIONID"),
            user_code=data.get("USERCODE"),
            app_server_version=data.get("APPSERVERVERSION"),
            language_id=data.get("LANGUAGEID"),
            password_expiration=data.get("PASSWORDEXPIRATION"),
            user_ak=data.get("USERAK"),
            price_list_list=data.get("PRICELISTLIST"),
            payment_method_list=payment_methods,
        )


@dataclass
class UserLogoutResponse:
    """Response for UserLogout operation.

    Based on UserOperation.xsd USERLOGOUTRESP structure.

    Attributes:
        error: Error information
    """

    error: Error

    @classmethod
    def from_dict(cls, data: dict) -> "UserLogoutResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
        )


@dataclass
class CheckSessionResponse:
    """Response for CheckSession operation.

    Based on UserOperation.xsd CHECKSESSIONRESP structure.

    Attributes:
        error: Error information
        app_server_version: Application server version string
    """

    error: Error
    app_server_version: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "CheckSessionResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            app_server_version=data.get("APPSERVERVERSION"),
        )


@dataclass
class ResetISAPICacheResponse:
    """Response for ResetISAPICache operation.

    Based on UserOperation.xsd RESETISAPICACHERESP structure.

    Attributes:
        error: Error information
        success: Whether cache reset was successful
    """

    error: Error
    success: bool = False

    @classmethod
    def from_dict(cls, data: dict) -> "ResetISAPICacheResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            success=data.get("SUCCESS", False),
        )


@dataclass
class FindAllPaymentMethodResponse:
    """Response for FindAllPaymentMethod operation.

    Based on UserOperation.xsd FINDALLPAYMENTRESP structure.

    Attributes:
        error: Error information
        payment_method_list: List of available payment methods
    """

    error: Error
    payment_method_list: List[PaymentMethod]

    @classmethod
    def from_dict(cls, data: dict) -> "FindAllPaymentMethodResponse":
        """Create response from API dictionary."""
        pm_list = data.get("PAYMENTMETHODLIST", {}).get("PAYMENTMETHOD", [])
        if not isinstance(pm_list, list):
            pm_list = [pm_list] if pm_list else []

        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            payment_method_list=[PaymentMethod.from_dict(pm) for pm in pm_list],
        )


@dataclass
class SearchUserResponse:
    """Response for SearchUser operation.

    Based on UserOperation.xsd SEARCHUSERRESP structure.

    Attributes:
        error: Error information
        user_count: Number of users found
        user_list: List of found users
    """

    error: Error
    user_count: int
    user_list: List[UserInfo]

    @classmethod
    def from_dict(cls, data: dict) -> "SearchUserResponse":
        """Create response from API dictionary."""
        user_list_data = data.get("USERINFOLIST", {}).get("USERINFO", [])
        if not isinstance(user_list_data, list):
            user_list_data = [user_list_data] if user_list_data else []

        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            user_count=data.get("USERCOUNT", 0),
            user_list=[UserInfo.from_dict(user) for user in user_list_data],
        )


@dataclass
class SearchUserRoleResponse:
    """Response for SearchUserRole operation.

    Based on UserOperation.xsd SEARCHUSERROLERESP structure.

    Attributes:
        error: Error information
        role_count: Number of roles found
        role_list: List of found roles
    """

    error: Error
    role_count: int
    role_list: List[dict]

    @classmethod
    def from_dict(cls, data: dict) -> "SearchUserRoleResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            role_count=data.get("ROLECOUNT", 0),
            role_list=data.get("ROLELIST", []),
        )


@dataclass
class SaveUserResponse:
    """Response for SaveUser operation.

    Based on UserOperation.xsd SAVEUSERRESP structure.

    Attributes:
        error: Error information
        user_info: Saved user information
    """

    error: Error
    user_info: Optional[UserInfo] = None

    @classmethod
    def from_dict(cls, data: dict) -> "SaveUserResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            user_info=(
                UserInfo.from_dict(data.get("USERINFO", {}))
                if data.get("USERINFO")
                else None
            ),
        )
