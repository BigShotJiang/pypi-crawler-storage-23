"""
Type definitions for SubscriptionEnquiry.

This module provides structured classes for subscription operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter, PageRequest, PageResponse, LocationBase, PerformanceBase


# Base Types
@dataclass
class Subscription:
    """Subscription information structure.
    
    Based on SubscriptionEnquiry.xsd SUBSCRIPTION type.
    
    Attributes:
        ak: Subscription AK
        code: Subscription code
        name: Subscription name
        title: Subscription title
        setting: Subscription setting
        validity: Validity date filter
        status: Subscription status
        sort_order: Sort order
        i18n_list: Internationalization list (optional)
        location: Location information (optional)
        performance_list: Performance list
        reduction_list: Reduction list
    """
    
    ak: str
    code: str
    name: str
    title: str
    setting: Dict[str, int]
    validity: BaseDateFilter
    status: int
    sort_order: int
    performance_list: List[PerformanceBase]
    reduction_list: List[Dict[str, Any]]
    i18n_list: Optional[Dict[str, Any]] = None
    location: Optional[LocationBase] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "Subscription":
        """Create Subscription from API response dictionary."""
        validity_data = data.get("VALIDITY", {})
        location_data = data.get("LOCATION")
        performance_data = data.get("PERFORMANCELIST", {}).get("PERFORMANCE")
        performance_list = []
        if performance_data:
            if isinstance(performance_data, list):
                performance_list = [PerformanceBase.from_dict(p) for p in performance_data]
            else:
                performance_list = [PerformanceBase.from_dict(performance_data)]
        reduction_data = data.get("REDUCTIONLIST", {}).get("REDUCTIONITEM")
        reduction_list = []
        if reduction_data:
            if isinstance(reduction_data, list):
                reduction_list = reduction_data
            else:
                reduction_list = [reduction_data]
        return cls(
            ak=data.get("AK", ""),
            code=data.get("CODE", ""),
            name=data.get("NAME", ""),
            title=data.get("TITLE", ""),
            setting=data.get("SETTING", {}),
            validity=BaseDateFilter.from_dict(validity_data) if validity_data else BaseDateFilter(from_date="", to_date=""),
            status=data.get("STATUS", 0),
            sort_order=data.get("SORTORDER", 0),
            i18n_list=data.get("I18NLIST"),
            location=LocationBase.from_dict(location_data) if location_data else None,
            performance_list=performance_list,
            reduction_list=reduction_list,
        )


@dataclass
class Subscription2:
    """Subscription2 information structure (extends SUBSCRIPTION).
    
    Based on SubscriptionEnquiry.xsd SUBSCRIPTION2 type.
    
    Attributes:
        All attributes from Subscription plus:
        event_category_list: Event category list
    """
    
    ak: str
    code: str
    name: str
    title: str
    setting: Dict[str, int]
    validity: BaseDateFilter
    status: int
    sort_order: int
    performance_list: List[PerformanceBase]
    reduction_list: List[Dict[str, Any]]
    event_category_list: Optional[List[Dict[str, str]]] = None
    i18n_list: Optional[Dict[str, Any]] = None
    location: Optional[LocationBase] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "Subscription2":
        """Create Subscription2 from API response dictionary."""
        subscription = Subscription.from_dict(data)
        event_category_data = data.get("EVENTCATEGORYLIST", {}).get("EVENTCATEGORY")
        event_category_list = None
        if event_category_data:
            if isinstance(event_category_data, list):
                event_category_list = event_category_data
            else:
                event_category_list = [event_category_data]
        return cls(
            ak=subscription.ak,
            code=subscription.code,
            name=subscription.name,
            title=subscription.title,
            setting=subscription.setting,
            validity=subscription.validity,
            status=subscription.status,
            sort_order=subscription.sort_order,
            performance_list=subscription.performance_list,
            reduction_list=subscription.reduction_list,
            event_category_list=event_category_list,
            i18n_list=subscription.i18n_list,
            location=subscription.location,
        )


# Request Classes
@dataclass
class GetSubscriptionAvailabilityRequest:
    """Request for GetSubscriptionAvailability operation.
    
    Based on SubscriptionEnquiry.xsd GETSUBSCRIPTIONAVAILABILITYREQ type.
    
    Attributes:
        subscription_ak: Subscription AK
        selected_reduction_list: List of selected reductions
    """
    
    subscription_ak: str
    selected_reduction_list: List[Dict[str, int]]
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "SUBSCRIPTIONAK": self.subscription_ak,
            "SELECTEDREDUCTIONLIST": {
                "SELECTEDREDUCTIONITEM": self.selected_reduction_list
            },
        }


@dataclass
class SearchSubscriptionRequest:
    """Request for SearchSubscription operation.
    
    Based on SubscriptionEnquiry.xsd SEARCHSUBSCRIPTIONREQ type.
    
    Attributes:
        page_req: Page request (optional)
        subscription_ak_list: Subscription AK list (optional)
        subscription_code_list: Subscription code list (optional)
        event_category_list: Event category list (optional)
        subscription_type: Subscription type (optional) - 1 = Fixed, 2 = Variable
        subscription_status: Subscription status (optional) - 0 = Closed, 1 = On Sale, 2 = Suspended, 3 = Informative, 4 = Waiting
    """
    
    page_req: Optional[PageRequest] = None
    subscription_ak_list: Optional[List[str]] = None
    subscription_code_list: Optional[List[str]] = None
    event_category_list: Optional[List[Dict[str, str]]] = None
    subscription_type: Optional[int] = None
    subscription_status: Optional[int] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        if self.subscription_ak_list is not None:
            result["SUBSCRIPTIONAKLIST"] = {
                "SUBSCRIPTIONAKITEM": [{"SUBSCRIPTIONAK": ak} for ak in self.subscription_ak_list]
            }
        if self.subscription_code_list is not None:
            result["SUBSCRIPTIONCODELIST"] = {
                "SUBSCRIPTIONCODEITEM": [{"SUBSCRIPTIONCODE": code} for code in self.subscription_code_list]
            }
        if self.event_category_list is not None:
            result["EVENTCATEGORYLIST"] = {
                "EVENTCATEGORY": self.event_category_list
            }
        if self.subscription_type is not None:
            result["SUBSCRIPTIONTYPE"] = self.subscription_type
        if self.subscription_status is not None:
            result["SUBSCRIPTIONSTATUS"] = self.subscription_status
        return result


# Response Classes
@dataclass
class FindAllSubscriptionResponse:
    """Response for FindAllSubscription operation.
    
    Based on SubscriptionEnquiry.xsd FINDALLSUBSCRIPTIONRESP type.
    
    Attributes:
        error: Error information
        subscription_list: List of subscriptions (optional)
    """
    
    error: Error
    subscription_list: Optional[List[Subscription]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllSubscriptionResponse":
        """Create FindAllSubscriptionResponse from API response dictionary."""
        subscription_data = data.get("SUBSCRIPTIONLIST", {}).get("SUBSCRIPTION")
        subscription_list = None
        if subscription_data:
            if isinstance(subscription_data, list):
                subscription_list = [Subscription.from_dict(s) for s in subscription_data]
            else:
                subscription_list = [Subscription.from_dict(subscription_data)]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            subscription_list=subscription_list,
        )


@dataclass
class ReadSubscriptionByAKResponse:
    """Response for ReadSubscriptionByAK operation.
    
    Based on SubscriptionEnquiry.xsd READSUBSCRIPTIONBYAKRESP type.
    
    Attributes:
        error: Error information
        subscription: Subscription information (optional)
    """
    
    error: Error
    subscription: Optional[Subscription] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadSubscriptionByAKResponse":
        """Create ReadSubscriptionByAKResponse from API response dictionary."""
        subscription_data = data.get("SUBSCRIPTION")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            subscription=Subscription.from_dict(subscription_data) if subscription_data else None,
        )


@dataclass
class GetSubscriptionAvailabilityResponse:
    """Response for GetSubscriptionAvailability operation.
    
    Based on SubscriptionEnquiry.xsd GETSUBSCRIPTIONAVAILABILITYRESP type.
    
    Attributes:
        error: Error information
        subscription_perf_list: List of subscription performance items
    """
    
    error: Error
    subscription_perf_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetSubscriptionAvailabilityResponse":
        """Create GetSubscriptionAvailabilityResponse from API response dictionary."""
        perf_data = data.get("SUBSCRIPTIONPERFLIST", {}).get("SUBSCRIPTIONPERFITEM")
        perf_list = []
        if perf_data:
            if isinstance(perf_data, list):
                perf_list = perf_data
            else:
                perf_list = [perf_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            subscription_perf_list=perf_list,
        )


@dataclass
class SearchSubscriptionResponse:
    """Response for SearchSubscription operation.
    
    Based on SubscriptionEnquiry.xsd SEARCHSUBSCRIPTIONRESP type.
    
    Attributes:
        error: Error information
        subscription_list: List of subscriptions (optional)
        page_resp: Page response (optional)
    """
    
    error: Error
    subscription_list: Optional[List[Subscription2]] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchSubscriptionResponse":
        """Create SearchSubscriptionResponse from API response dictionary."""
        subscription_data = data.get("SUBSCRIPTIONLIST", {}).get("SUBSCRIPTIONITEM")
        subscription_list = None
        if subscription_data:
            if isinstance(subscription_data, list):
                subscription_list = [Subscription2.from_dict(s) for s in subscription_data]
            else:
                subscription_list = [Subscription2.from_dict(subscription_data)]
        page_resp_data = data.get("PAGERESP")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            subscription_list=subscription_list,
            page_resp=PageResponse.from_dict(page_resp_data) if page_resp_data else None,
        )
