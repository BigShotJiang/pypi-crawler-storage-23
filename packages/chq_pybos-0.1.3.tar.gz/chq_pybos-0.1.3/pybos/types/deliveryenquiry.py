"""
Type definitions for DeliveryEnquiry.

This module provides structured classes for delivery operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, PageRequest, PageResponse


# Request Classes
@dataclass
class SearchDeliveryRequest:
    """Request for SearchDelivery operation.
    
    Based on DeliveryEnquiry.xsd SEARCHDELIVERYREQ type.
    
    Attributes:
        delivery_ak_list: Delivery AK list (optional)
        page_req: Page request (optional)
    """
    
    delivery_ak_list: Optional[List[str]] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.delivery_ak_list is not None:
            result["DELIVERYAKLIST"] = {
                "DELIVERYAKITEM": [{"DELIVERYAK": ak} for ak in self.delivery_ak_list]
            }
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


# Response Classes
@dataclass
class FindAllDeliveryResponse:
    """Response for FindAllDelivery operation.
    
    Based on DeliveryEnquiry.xsd FINDALLDELIVERYRESP type.
    
    Attributes:
        error: Error information
        delivery_list: List of deliveries
    """
    
    error: Error
    delivery_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllDeliveryResponse":
        """Create FindAllDeliveryResponse from API response dictionary."""
        delivery_data = data.get("DELIVERYLIST", {}).get("DELIVERYITEM")
        delivery_list = []
        if delivery_data:
            if isinstance(delivery_data, list):
                delivery_list = delivery_data
            else:
                delivery_list = [delivery_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            delivery_list=delivery_list,
        )


@dataclass
class ReadDeliveryByAKResponse:
    """Response for ReadDeliveryByAK operation.
    
    Based on DeliveryEnquiry.xsd READDELIVERYBYAKRESP type.
    
    Attributes:
        error: Error information
        delivery: Delivery information (optional)
    """
    
    error: Error
    delivery: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadDeliveryByAKResponse":
        """Create ReadDeliveryByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            delivery=data.get("DELIVERY"),
        )


@dataclass
class SearchDeliveryResponse:
    """Response for SearchDelivery operation.
    
    Based on DeliveryEnquiry.xsd SEARCHDELIVERYRESP type.
    
    Attributes:
        error: Error information
        delivery_list: List of deliveries
        page_resp: Page response
    """
    
    error: Error
    delivery_list: List[Dict[str, Any]]
    page_resp: PageResponse
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchDeliveryResponse":
        """Create SearchDeliveryResponse from API response dictionary."""
        delivery_data = data.get("DELIVERYLIST", {}).get("DELIVERYITEM")
        delivery_list = []
        if delivery_data:
            if isinstance(delivery_data, list):
                delivery_list = delivery_data
            else:
                delivery_list = [delivery_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            delivery_list=delivery_list,
            page_resp=PageResponse.from_dict(data.get("PAGERESP", {})),
        )
