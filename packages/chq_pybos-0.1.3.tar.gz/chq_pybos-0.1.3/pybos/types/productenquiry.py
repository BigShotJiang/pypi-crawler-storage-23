"""
Type definitions for ProductEnquiry.

This module provides structured classes for product operations,
replacing tuple-based parameters with type-safe, self-documenting classes.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter, PageRequest, PageResponse
from .accountfinancial import PriceBase


# Base Types
@dataclass
class ProductBase:
    """Base product information structure.
    
    Based on APICommon.xsd PRODUCTBASE type.
    
    Attributes:
        ak: Product AK identifier
        sheet_name: Name of the sheet containing the product
        price_list: Price list information
        price_table: Price table information
    """
    
    ak: str
    sheet_name: str
    price_list: Optional[Dict[str, Any]] = None
    price_table: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ProductBase":
        """Create ProductBase from API response dictionary."""
        return cls(
            ak=data.get("AK", ""),
            sheet_name=data.get("SHEETNAME", ""),
            price_list=data.get("PRICELIST"),
            price_table=data.get("PRICETABLE"),
        )


@dataclass
class AdditionalInfo:
    """Additional information structure.
    
    Based on ProductEnquiry.xsd ADDITIONALINFO type.
    
    Attributes:
        required: Whether this information is required
        dmg_ak: Required category AK (optional)
        apply_to_all: Whether account is applied to all products (optional)
        required_type: Required type (optional)
    """
    
    required: bool
    dmg_ak: Optional[str] = None
    apply_to_all: Optional[bool] = None
    required_type: Optional[int] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "AdditionalInfo":
        """Create AdditionalInfo from API response dictionary."""
        return cls(
            required=data.get("REQUIRED", False),
            dmg_ak=data.get("DMGAK"),
            apply_to_all=data.get("APPLYTOALL"),
            required_type=data.get("REQUIREDTYPE"),
        )
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"REQUIRED": self.required}
        if self.dmg_ak is not None:
            result["DMGAK"] = self.dmg_ak
        if self.apply_to_all is not None:
            result["APPLYTOALL"] = self.apply_to_all
        if self.required_type is not None:
            result["REQUIREDTYPE"] = self.required_type
        return result


@dataclass
class Warning:
    """Warning information structure.
    
    Based on ProductEnquiry.xsd WARNING type.
    
    Attributes:
        account: Account warning information (optional)
        ext_info: Extended information warning (optional)
        date_from: Date from warning (optional)
        date_to: Date to warning (optional)
        performance: Performance warning (optional)
        people_count: People count warning (optional)
        variable_price: Variable price warning (optional)
        sale_restriction: Sale restriction warning (optional)
        media_link: Media link warning (optional)
        sale_validity: Sale validity warning (optional)
        money_card: Money card warning (optional)
        gift_aid: Gift aid warning (optional)
        dynamic_price: Dynamic price warning (optional)
    """
    
    account: Optional[Dict[str, Any]] = None
    ext_info: Optional[AdditionalInfo] = None
    date_from: Optional[Dict[str, Any]] = None
    date_to: Optional[Dict[str, Any]] = None
    performance: Optional[Dict[str, Any]] = None
    people_count: Optional[Dict[str, Any]] = None
    variable_price: Optional[Dict[str, Any]] = None
    sale_restriction: Optional[Dict[str, Any]] = None
    media_link: Optional[Dict[str, Any]] = None
    sale_validity: Optional[Dict[str, Any]] = None
    money_card: Optional[Dict[str, Any]] = None
    gift_aid: Optional[Dict[str, Any]] = None
    dynamic_price: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "Warning":
        """Create Warning from API response dictionary."""
        ext_info = data.get("EXTINFO")
        return cls(
            account=data.get("ACCOUNT"),
            ext_info=AdditionalInfo.from_dict(ext_info) if ext_info else None,
            date_from=data.get("DATEFROM"),
            date_to=data.get("DATETO"),
            performance=data.get("PERFORMANCE"),
            people_count=data.get("PEOPLECOUNT"),
            variable_price=data.get("VARIABLEPRICE"),
            sale_restriction=data.get("SALERESTRICTION"),
            media_link=data.get("MEDIALINK"),
            sale_validity=data.get("SALEVALIDITY"),
            money_card=data.get("MONEYCARD"),
            gift_aid=data.get("GIFTAID"),
            dynamic_price=data.get("DYNAMICPRICE"),
        )


@dataclass
class Product:
    """Product information structure.
    
    Based on ProductEnquiry.xsd PRODUCT type (extends PRODUCTBASE).
    
    Attributes:
        ak: Product AK identifier
        sheet_name: Name of the sheet containing the product
        price: Product price
        sort_order: Sort order value
        product_type: Type of product (1 = ticket, 2 = food and merchandise)
        warning: Warning information
        code: Product code
        name: Product name
        description: Product description
        additional_desc: Additional description
        event_list: List of events the product can be used for
        i18n_list: List of translations
        stat_group_list: Statistical group list (optional)
        template_ak: Template AK
        upsell_list: Upsell list (optional)
        flex_contract_base_list: Flex contract base list (optional)
        status: Product status
        price_type: Price type
        price_list: Price list information (from base)
        price_table: Price table information (from base)
    """
    
    ak: str
    sheet_name: str
    price: PriceBase
    sort_order: int
    product_type: int
    warning: Warning
    code: str
    name: str
    description: str
    additional_desc: str
    template_ak: str
    status: int
    price_type: int
    event_list: Optional[Dict[str, Any]] = None
    i18n_list: Optional[Dict[str, Any]] = None
    stat_group_list: Optional[List[Dict[str, Any]]] = None
    upsell_list: Optional[List[Dict[str, Any]]] = None
    flex_contract_base_list: Optional[Dict[str, Any]] = None
    price_list: Optional[Dict[str, Any]] = None
    price_table: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "Product":
        """Create Product from API response dictionary."""
        price_data = data.get("PRICE", {})
        warning_data = data.get("WARNING", {})
        return cls(
            ak=data.get("AK", ""),
            sheet_name=data.get("SHEETNAME", ""),
            price=PriceBase.from_dict(price_data) if price_data else PriceBase(currency="", net=0.0, tax=0.0, gross=0.0),
            sort_order=data.get("SORTORDER", 0),
            product_type=data.get("PRODUCTTYPE", 0),
            warning=Warning.from_dict(warning_data) if warning_data else Warning(),
            code=data.get("CODE", ""),
            name=data.get("NAME", ""),
            description=data.get("DESCRIPTION", ""),
            additional_desc=data.get("ADDITIONALDESC", ""),
            template_ak=data.get("TEMPLATEAK", ""),
            status=data.get("STATUS", 0),
            price_type=data.get("PRICETYPE", 0),
            event_list=data.get("EVENTLIST"),
            i18n_list=data.get("I18NLIST"),
            stat_group_list=data.get("STATGROUPLIST", {}).get("STATGROUP") if data.get("STATGROUPLIST") else None,
            upsell_list=data.get("UPSELLLIST", {}).get("UPSELLITEM") if data.get("UPSELLLIST") else None,
            flex_contract_base_list=data.get("FLEXCONTRACTBASELIST"),
            price_list=data.get("PRICELIST"),
            price_table=data.get("PRICETABLE"),
        )


@dataclass
class Quick:
    """Quick information structure.
    
    Based on ProductEnquiry.xsd QUICK type.
    
    Attributes:
        quick_only: Whether quick only
        target_product_list: Target product list (optional)
    """
    
    quick_only: bool
    target_product_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "Quick":
        """Create Quick from API response dictionary."""
        return cls(
            quick_only=data.get("QUICKONLY", False),
            target_product_list=data.get("TARGETPRODUCTLIST", {}).get("TARGETITEM") if data.get("TARGETPRODUCTLIST") else None,
        )


@dataclass
class Info:
    """Info structure.
    
    Based on ProductEnquiry.xsd INFO type.
    
    Attributes:
        type: Info type
    """
    
    type: int
    
    @classmethod
    def from_dict(cls, data: dict) -> "Info":
        """Create Info from API response dictionary."""
        return cls(type=data.get("TYPE", 0))


# Request Classes
@dataclass
class FindAccountProductRequest:
    """Request for FindAccountProduct operation.
    
    Based on ProductEnquiry.xsd FINDACCOUNTPRODUCTREQ type.
    
    Attributes:
        account_ak: Account AK
    """
    
    account_ak: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"ACCOUNTAK": self.account_ak}


@dataclass
class FindAllProductByStatGroupRequest:
    """Request for FindAllProductByStatGroup operation.
    
    Based on ProductEnquiry.xsd FINDALLPRODUCTBYSTATGROUPREQ type.
    
    Attributes:
        stat_group_list: Statistical group list
    """
    
    stat_group_list: List[Dict[str, Any]]
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"STATGROUPLIST": {"STATGROUP": self.stat_group_list}}


@dataclass
class SearchProductRequest:
    """Request for SearchProduct operation.
    
    Based on ProductEnquiry.xsd SEARCHPRODUCTREQ type.
    
    Attributes:
        static_group_list: Static group list (optional)
        page_req: Page request (optional)
        account_ak: Account AK (optional)
        matrix_cell_ak_list: Matrix cell AK list (optional)
        event_ak: Event AK (optional)
        product_type: Product type (optional)
        price_list_ak: Price list AK (optional)
        price_table_ak: Price table AK (optional)
        matrix_sheet_name: Matrix sheet name (optional)
        dimension_list: Dimension list (optional)
        price_type: Price type (optional)
        include_matrix_cell_template: Include matrix cell template (optional)
        return_redeemable_product_conf: Return redeemable product conf (optional)
        sku: SKU (optional)
        barcode: Barcode (optional)
        additional_code: Additional code (optional)
        return_product_info: Return product info (optional)
        return_card_dependency_warning: Return card dependency warning (optional)
    """
    
    static_group_list: Optional[List[Dict[str, str]]] = None
    page_req: Optional[PageRequest] = None
    account_ak: Optional[str] = None
    matrix_cell_ak_list: Optional[List[str]] = None
    event_ak: Optional[str] = None
    product_type: Optional[int] = None
    price_list_ak: Optional[str] = None
    price_table_ak: Optional[str] = None
    matrix_sheet_name: Optional[str] = None
    dimension_list: Optional[List[Dict[str, Any]]] = None
    price_type: Optional[int] = None
    include_matrix_cell_template: Optional[bool] = None
    return_redeemable_product_conf: Optional[bool] = None
    sku: Optional[str] = None
    barcode: Optional[str] = None
    additional_code: Optional[str] = None
    return_product_info: Optional[bool] = None
    return_card_dependency_warning: Optional[bool] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.static_group_list is not None:
            result["STATICGROUPLIST"] = {"STATICGROUPITEM": self.static_group_list}
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        if self.account_ak is not None:
            result["ACCOUNTAK"] = self.account_ak
        if self.matrix_cell_ak_list is not None:
            result["MATRIXCELLAKLIST"] = {
                "MATRIXCELLAKITEM": [{"MATRIXCELLAK": ak} for ak in self.matrix_cell_ak_list]
            }
        if self.event_ak is not None:
            result["EVENTAK"] = self.event_ak
        if self.product_type is not None:
            result["PRODUCTTYPE"] = self.product_type
        if self.price_list_ak is not None:
            result["PRICELISTAK"] = self.price_list_ak
        if self.price_table_ak is not None:
            result["PRICETABLEAK"] = self.price_table_ak
        if self.matrix_sheet_name is not None:
            result["MATRIXSHEETNAME"] = self.matrix_sheet_name
        if self.dimension_list is not None:
            result["DIMENSIONLIST"] = {"DIMENSIONITEM": self.dimension_list}
        if self.price_type is not None:
            result["PRICETYPE"] = self.price_type
        if self.include_matrix_cell_template is not None:
            result["INCLUDEMATRIXCELLTEMPLATE"] = self.include_matrix_cell_template
        if self.return_redeemable_product_conf is not None:
            result["RETURNREDEEMABLEPRODUCTCONF"] = self.return_redeemable_product_conf
        if self.sku is not None:
            result["SKU"] = self.sku
        if self.barcode is not None:
            result["BARCODE"] = self.barcode
        if self.additional_code is not None:
            result["ADDITIONALCODE"] = self.additional_code
        if self.return_product_info is not None:
            result["RETURNPRODUCTINFO"] = self.return_product_info
        if self.return_card_dependency_warning is not None:
            result["RETURNCARDDEPENDENCYWARNING"] = self.return_card_dependency_warning
        return result


@dataclass
class SearchPriceByDateProductRequest:
    """Request for SearchPriceByDateProduct operation.
    
    Based on ProductEnquiry.xsd SEARCHPRICEBYDATEPRODUCTREQ type.
    
    Attributes:
        date: Date filter
        static_group_list: Static group list (optional)
        matrix_cell_ak_list: Matrix cell AK list (optional)
        price_list_ak: Price list AK (optional)
        price_table_ak: Price table AK (optional)
        matrix_sheet_name: Matrix sheet name (optional)
    """
    
    date: BaseDateFilter
    static_group_list: Optional[List[Dict[str, str]]] = None
    matrix_cell_ak_list: Optional[List[str]] = None
    price_list_ak: Optional[str] = None
    price_table_ak: Optional[str] = None
    matrix_sheet_name: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"DATE": self.date.to_dict()}
        if self.static_group_list is not None:
            result["STATICGROUPLIST"] = {"STATICGROUPITEM": self.static_group_list}
        if self.matrix_cell_ak_list is not None:
            result["MATRIXCELLAKLIST"] = {
                "MATRIXCELLAKITEM": [{"MATRIXCELLAK": ak} for ak in self.matrix_cell_ak_list]
            }
        if self.price_list_ak is not None:
            result["PRICELISTAK"] = self.price_list_ak
        if self.price_table_ak is not None:
            result["PRICETABLEAK"] = self.price_table_ak
        if self.matrix_sheet_name is not None:
            result["MATRIXSHEETNAME"] = self.matrix_sheet_name
        return result


@dataclass
class ImportProductRequest:
    """Request for ImportProduct operation.
    
    Based on ProductEnquiry.xsd IMPORTPRODUCTREQ type.
    
    Attributes:
        product_name: Product name
        description: Description
        matrix_sheet_ak: Matrix sheet AK
        product_code: Product code
        price_list_ak: Price list AK
        sku: SKU
        barcode_list: Barcode list
        um_ak: Unit of measure AK
        price_type: Price type
        sell_price: Sell price
        printed_price: Printed price
        stock_product_category_ak: Stock product category AK
        status: Status
        tax_type: Tax type
        tax_package_ak: Tax package AK
        additional_code: Additional code (optional)
        additional_description: Additional description (optional)
        variable_min_price: Variable min price (optional)
        variable_max_price: Variable max price (optional)
        cost_center_validity_list: Cost center validity list (optional)
        statistical_group_ak_list: Statistical group AK list (optional)
        receipt_template_ak: Receipt template AK (optional)
        receipt_not_required: Receipt not required (optional)
        not_refundable: Not refundable (optional)
        supervisor_approval_required: Supervisor approval required (optional)
        marketing_survey_ak: Marketing survey AK (optional)
        additional_info_mask_ak: Additional info mask AK (optional)
        mandatory_on_sale: Mandatory on sale (optional)
        apply_to_all: Apply to all (optional)
        stock_move_quantity: Stock move quantity (optional)
        stock_check_inventory: Stock check inventory (optional)
    """
    
    product_name: str
    description: str
    matrix_sheet_ak: str
    product_code: str
    price_list_ak: str
    sku: str
    barcode_list: List[str]
    um_ak: str
    price_type: int
    sell_price: float
    printed_price: float
    stock_product_category_ak: str
    status: bool
    tax_type: int
    tax_package_ak: str
    additional_code: Optional[str] = None
    additional_description: Optional[str] = None
    variable_min_price: Optional[float] = None
    variable_max_price: Optional[float] = None
    cost_center_validity_list: Optional[List[Dict[str, Any]]] = None
    statistical_group_ak_list: Optional[List[str]] = None
    receipt_template_ak: Optional[str] = None
    receipt_not_required: Optional[bool] = None
    not_refundable: Optional[bool] = None
    supervisor_approval_required: Optional[bool] = None
    marketing_survey_ak: Optional[str] = None
    additional_info_mask_ak: Optional[str] = None
    mandatory_on_sale: Optional[bool] = None
    apply_to_all: Optional[bool] = None
    stock_move_quantity: Optional[bool] = None
    stock_check_inventory: Optional[bool] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "IMPORTPRODUCT": {
                "PRODUCTNAME": self.product_name,
                "DESCRIPTION": self.description,
                "MATRIXSHEETAK": self.matrix_sheet_ak,
                "PRODUCTCODE": self.product_code,
                "PRICELISTAK": self.price_list_ak,
                "SKU": self.sku,
                "BARCODELIST": {"BARCODE": self.barcode_list},
                "UMAK": self.um_ak,
                "PRICETYPE": self.price_type,
                "SELLPRICE": self.sell_price,
                "PRINTEDPRICE": self.printed_price,
                "STOCKPRODUCTCATEGORYAK": self.stock_product_category_ak,
                "STATUS": self.status,
                "TAXTYPE": self.tax_type,
                "TAXPACKAGEAK": self.tax_package_ak,
            }
        }
        imp_product = result["IMPORTPRODUCT"]
        if self.additional_code is not None:
            imp_product["ADDITIONALCODE"] = self.additional_code
        if self.additional_description is not None:
            imp_product["ADDITIONALDESCRIPTION"] = self.additional_description
        if self.variable_min_price is not None:
            imp_product["VARIABLEMINPRICE"] = self.variable_min_price
        if self.variable_max_price is not None:
            imp_product["VARIABLEMAXPRICE"] = self.variable_max_price
        if self.cost_center_validity_list is not None:
            imp_product["COSTCENTERVALIDITYLIST"] = {
                "COSTCENTERVALIDITY": self.cost_center_validity_list
            }
        if self.statistical_group_ak_list is not None:
            imp_product["STATISTICALGROUPAKLIST"] = {
                "STATISTICALGROUPAK": self.statistical_group_ak_list
            }
        if self.receipt_template_ak is not None:
            imp_product["RECEIPTTEMPLATEAK"] = self.receipt_template_ak
        if self.receipt_not_required is not None:
            imp_product["RECEIPTNOTREQUIRED"] = self.receipt_not_required
        if self.not_refundable is not None:
            imp_product["NOTREFUNDABLE"] = self.not_refundable
        if self.supervisor_approval_required is not None:
            imp_product["SUPERVISORAPPROVALREQUIRED"] = self.supervisor_approval_required
        if self.marketing_survey_ak is not None:
            imp_product["MARKETINGSURVEYAK"] = self.marketing_survey_ak
        if self.additional_info_mask_ak is not None:
            imp_product["ADDITIONALINFOMASKAK"] = self.additional_info_mask_ak
        if self.mandatory_on_sale is not None:
            imp_product["MANDATORYONSALE"] = self.mandatory_on_sale
        if self.apply_to_all is not None:
            imp_product["APPLYTOALL"] = self.apply_to_all
        if self.stock_move_quantity is not None:
            imp_product["STOCKMOVEQUANTITY"] = self.stock_move_quantity
        if self.stock_check_inventory is not None:
            imp_product["STOCKCHECKINVENTORY"] = self.stock_check_inventory
        return result


@dataclass
class UpdateProductRequest:
    """Request for UpdateProduct operation.
    
    Based on ProductEnquiry.xsd UPDATEPRODUCTREQ type.
    
    Attributes:
        matrix_cell_ak: Matrix cell AK
        update_product_name: Update product name flag
        update_description: Update description flag
        update_additional_description: Update additional description flag
        update_product_code: Update product code flag
        update_price: Update price flag
        update_status: Update status flag
        update_taxes: Update taxes flag
        update_receipt_info: Update receipt info flag
        update_not_refundable: Update not refundable flag
        update_supervisor_approval: Update supervisor approval flag
        update_marketing_survey: Update marketing survey flag
        update_additional_info_mask: Update additional info mask flag
        update_product: Product update data
    """
    
    matrix_cell_ak: str
    update_product_name: bool
    update_description: bool
    update_additional_description: bool
    update_product_code: bool
    update_price: bool
    update_status: bool
    update_taxes: bool
    update_receipt_info: bool
    update_not_refundable: bool
    update_supervisor_approval: bool
    update_marketing_survey: bool
    update_additional_info_mask: bool
    update_product: Dict[str, Any]
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "MATRIXCELLAK": self.matrix_cell_ak,
            "UPDATEPRODUCTNAME": self.update_product_name,
            "UPDATEDESCRIPTION": self.update_description,
            "UPDATEADDITIONALDESCRIPTION": self.update_additional_description,
            "UPDATEPRODUCTCODE": self.update_product_code,
            "UPDATEPRICE": self.update_price,
            "UPDATESTATUS": self.update_status,
            "UPDATETAXES": self.update_taxes,
            "UPDATERECEIPTINFO": self.update_receipt_info,
            "UPDATENOTREFUNDABLE": self.update_not_refundable,
            "UPDATESUPERVISORAPPROVAL": self.update_supervisor_approval,
            "UPDATEMARKETINGSURVEY": self.update_marketing_survey,
            "UPDATEADDITIONALINFOMASK": self.update_additional_info_mask,
            "UPDATEPRODUCT": self.update_product,
        }


@dataclass
class GetAttributeByComponentCodeRequest:
    """Request for GetAttributeByComponentCode operation.
    
    Based on ProductEnquiry.xsd GETATTRIBUTEBYCOMPONENTCODEREQ type.
    
    Attributes:
        component_code: Component code
        return_warning: Return warning flag (optional)
    """
    
    component_code: str
    return_warning: Optional[bool] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"COMPONENT": {"CODE": self.component_code}}
        if self.return_warning is not None:
            result["RETURNWARNING"] = self.return_warning
        return result


@dataclass
class ProductTransferRequest:
    """Request for ProductWarehouseChange operation.
    
    Based on ProductEnquiry.xsd PRODUCTTRANSFERREQ type.
    
    Attributes:
        product_filter: Product filter (PRODUCTAK, SKU, or ADDITIONALCODE)
        request_id: Request ID
        approval_status: Approval status (0 = To Be Approved, 1 = Approved)
        warehouse_id_source: Warehouse ID source
        warehouse_id_destination: Warehouse ID destination
        quantity: Quantity
        um_ak: Unit of measure AK
        value: Value
        request_date: Request date (optional)
        note: Note (optional)
    """
    
    product_filter: Dict[str, str]  # PRODUCTAK, SKU, or ADDITIONALCODE
    request_id: str
    approval_status: int
    warehouse_id_source: int
    warehouse_id_destination: int
    quantity: int
    um_ak: str
    value: float
    request_date: Optional[str] = None
    note: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "PRODUCTFILTER": self.product_filter,
            "REQUESTID": self.request_id,
            "APPROVALSTATUS": self.approval_status,
            "WAREHOUSEIDSOURCE": self.warehouse_id_source,
            "WAREHOUSEIDDESTINATION": self.warehouse_id_destination,
            "QUANTITY": self.quantity,
            "UMAK": self.um_ak,
            "VALUE": self.value,
        }
        if self.request_date is not None:
            result["REQUESTDATE"] = self.request_date
        if self.note is not None:
            result["NOTE"] = self.note
        return result


@dataclass
class ProductTransferApprovalRequest:
    """Request for ProductWarehouseChangeApproval operation.
    
    Based on ProductEnquiry.xsd PRODUCTTRANSFERAPPROVALREQ type.
    
    Attributes:
        request_id: Request ID
        approval_status: Approval status (1 = Approved, 2 = Rejected)
    """
    
    request_id: str
    approval_status: int
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "REQUESTID": self.request_id,
            "APPROVALSTATUS": self.approval_status,
        }


@dataclass
class SearchWarehouseMovementRequest:
    """Request for SearchWarehouseMovement operation.
    
    Based on ProductEnquiry.xsd SEARCHWAREHOUSEMOVEMENTREQ type.
    
    Attributes:
        page_req: Page request (optional)
        movement_date: Movement date filter (optional)
        request_date: Request date filter (optional)
        request_id: Request ID (optional)
        warehouse_id: Warehouse ID (optional)
        movement_type: Movement type (optional)
        approval_status: Approval status (optional)
        product_filter: Product filter (optional)
        note: Note (optional)
    """
    
    page_req: Optional[PageRequest] = None
    movement_date: Optional[BaseDateFilter] = None
    request_date: Optional[BaseDateFilter] = None
    request_id: Optional[str] = None
    warehouse_id: Optional[int] = None
    movement_type: Optional[int] = None
    approval_status: Optional[int] = None
    product_filter: Optional[Dict[str, str]] = None
    note: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        if self.movement_date is not None:
            result["MOVEMENTDATE"] = self.movement_date.to_dict()
        if self.request_date is not None:
            result["REQUESTDATE"] = self.request_date.to_dict()
        if self.request_id is not None:
            result["REQUESTID"] = self.request_id
        if self.warehouse_id is not None:
            result["WAREHOUSEID"] = self.warehouse_id
        if self.movement_type is not None:
            result["MOVEMENTTYPE"] = self.movement_type
        if self.approval_status is not None:
            result["APPROVALSTATUS"] = self.approval_status
        if self.product_filter is not None:
            result["PRODUCTFILTER"] = self.product_filter
        if self.note is not None:
            result["NOTE"] = self.note
        return result


@dataclass
class ProductInventoryUpdateRequest:
    """Request for ProductInventoryUpdate operation.
    
    Based on ProductEnquiry.xsd PRODUCTINVENTORYUPDATEREQ type.
    
    Attributes:
        product_filter: Product filter (PRODUCTAK, SKU, or ADDITIONALCODE)
        movement_type: Movement type (1 = Incoming, 2 = OutGoing, 10 = AdjustQuantity)
        warehouse_id: Warehouse ID
        quantity: Quantity
        um_ak: Unit of measure AK
        value: Value
        note: Note (optional)
    """
    
    product_filter: Dict[str, str]  # PRODUCTAK, SKU, or ADDITIONALCODE
    movement_type: int
    warehouse_id: int
    quantity: int
    um_ak: str
    value: float
    note: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "PRODUCTFILTER": self.product_filter,
            "MOVEMENTTYPE": self.movement_type,
            "WAREHOUSEID": self.warehouse_id,
            "QUANTITY": self.quantity,
            "UMAK": self.um_ak,
            "VALUE": self.value,
        }
        if self.note is not None:
            result["NOTE"] = self.note
        return result


# Response Classes
@dataclass
class FindAllProductsResponse:
    """Response for FindAllProducts operation.
    
    Based on ProductEnquiry.xsd FINDALLPRODUCTRESPONSE type.
    
    Attributes:
        error: Error information
        product_list: List of products (optional)
    """
    
    error: Error
    product_list: Optional[List[Product]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllProductsResponse":
        """Create FindAllProductsResponse from API response dictionary."""
        product_list_data = data.get("PRODUCTLIST", {}).get("PRODUCT")
        product_list = None
        if product_list_data:
            if isinstance(product_list_data, list):
                product_list = [Product.from_dict(p) for p in product_list_data]
            else:
                product_list = [Product.from_dict(product_list_data)]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product_list=product_list,
        )


@dataclass
class ReadProductByAKResponse:
    """Response for ReadProductByAK operation.
    
    Based on ProductEnquiry.xsd READPRODUCTBYAKRESP type.
    
    Attributes:
        error: Error information
        product: Product information (optional)
    """
    
    error: Error
    product: Optional[Product] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadProductByAKResponse":
        """Create ReadProductByAKResponse from API response dictionary."""
        product_data = data.get("PRODUCT")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product=Product.from_dict(product_data) if product_data else None,
        )


@dataclass
class ReadProductByIDResponse:
    """Response for ReadProductByID operation.
    
    Based on ProductEnquiry.xsd READPRODUCTBYIDRESP type.
    
    Attributes:
        error: Error information
        product: Product information (optional)
    """
    
    error: Error
    product: Optional[Product] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadProductByIDResponse":
        """Create ReadProductByIDResponse from API response dictionary."""
        product_data = data.get("PRODUCT")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product=Product.from_dict(product_data) if product_data else None,
        )


@dataclass
class FindAllStatisticalGroupResponse:
    """Response for FindAllStatisticalGroup operation.
    
    Based on ProductEnquiry.xsd FINDALLSTATISTICALGROUPRESP type.
    
    Attributes:
        error: Error information
        statistical_group_list: List of statistical groups (optional)
    """
    
    error: Error
    statistical_group_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllStatisticalGroupResponse":
        """Create FindAllStatisticalGroupResponse from API response dictionary."""
        stat_group_data = data.get("STATISTICALGROUPLIST", {}).get("STATISTICALGROUP")
        stat_group_list = None
        if stat_group_data:
            if isinstance(stat_group_data, list):
                stat_group_list = stat_group_data
            else:
                stat_group_list = [stat_group_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            statistical_group_list=stat_group_list,
        )


@dataclass
class FindB2BAccountProductResponse:
    """Response for FindB2BAccountProduct operation.
    
    Based on ProductEnquiry.xsd FINDB2BACCOUNTPRODUCTRESPONSE type.
    
    Attributes:
        error: Error information
        product_list: List of products (optional)
    """
    
    error: Error
    product_list: Optional[List[Product]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindB2BAccountProductResponse":
        """Create FindB2BAccountProductResponse from API response dictionary."""
        product_list_data = data.get("PRODUCTLIST", {}).get("PRODUCT")
        product_list = None
        if product_list_data:
            if isinstance(product_list_data, list):
                product_list = [Product.from_dict(p) for p in product_list_data]
            else:
                product_list = [Product.from_dict(product_list_data)]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product_list=product_list,
        )


@dataclass
class ReadProductDimensionByAKResponse:
    """Response for ReadProductDimensionByAK operation.
    
    Based on ProductEnquiry.xsd READPRODUCTDIMENSIONBYAKRESP type.
    
    Attributes:
        error: Error information
        product: Product base information (optional)
        dimension_list: Dimension list
    """
    
    error: Error
    dimension_list: List[Dict[str, Any]]
    product: Optional[ProductBase] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadProductDimensionByAKResponse":
        """Create ReadProductDimensionByAKResponse from API response dictionary."""
        product_data = data.get("PRODUCT")
        dimension_data = data.get("DIMENSIONLIST", {}).get("DIMENSION")
        dimension_list = []
        if dimension_data:
            if isinstance(dimension_data, list):
                dimension_list = dimension_data
            else:
                dimension_list = [dimension_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product=ProductBase.from_dict(product_data) if product_data else None,
            dimension_list=dimension_list,
        )


@dataclass
class ImportProductResponse:
    """Response for ImportProduct operation.
    
    Based on ProductEnquiry.xsd IMPORTPRODUCTRESP type.
    
    Attributes:
        error: Error information
        product_ak: Product AK
    """
    
    error: Error
    product_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "ImportProductResponse":
        """Create ImportProductResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product_ak=data.get("PRODUCTAK", ""),
        )


@dataclass
class UpdateProductResponse:
    """Response for UpdateProduct operation.
    
    Based on ProductEnquiry.xsd UPDATEPRODUCTRESP type.
    
    Attributes:
        error: Error information
        product_ak: Product AK
    """
    
    error: Error
    product_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "UpdateProductResponse":
        """Create UpdateProductResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product_ak=data.get("PRODUCTAK", ""),
        )


@dataclass
class ActivateProductByAKResponse:
    """Response for ActivateProductByAK operation.
    
    Based on ProductEnquiry.xsd ACTIVATEPRODUCTBYAKRESP type.
    
    Attributes:
        error: Error information
        matrix_cell_ak: Matrix cell AK
    """
    
    error: Error
    matrix_cell_ak: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ActivateProductByAKResponse":
        """Create ActivateProductByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            matrix_cell_ak=data.get("MAXTRIXCELLAK"),
        )


@dataclass
class DeactivateProductByAKResponse:
    """Response for DeactivateProductByAK operation.
    
    Based on ProductEnquiry.xsd DEACTIVATEPRODUCTBYAKRESP type.
    
    Attributes:
        error: Error information
        matrix_cell_ak: Matrix cell AK
    """
    
    error: Error
    matrix_cell_ak: Optional[str] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "DeactivateProductByAKResponse":
        """Create DeactivateProductByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            matrix_cell_ak=data.get("MAXTRIXCELLAK"),
        )


@dataclass
class FindAllProductByStatGroupResponse:
    """Response for FindAllProductByStatGroup operation.
    
    Based on ProductEnquiry.xsd FINDALLPRODUCTBYSTATGROUPRESP type.
    
    Attributes:
        error: Error information
        product_list: List of products (optional)
    """
    
    error: Error
    product_list: Optional[List[Product]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAllProductByStatGroupResponse":
        """Create FindAllProductByStatGroupResponse from API response dictionary."""
        product_list_data = data.get("PRODUCTLIST", {}).get("PRODUCT")
        product_list = None
        if product_list_data:
            if isinstance(product_list_data, list):
                product_list = [Product.from_dict(p) for p in product_list_data]
            else:
                product_list = [Product.from_dict(product_list_data)]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product_list=product_list,
        )


@dataclass
class ReadStatisticalGroupByCodeResponse:
    """Response for ReadStatisticalGroupByCode operation.
    
    Based on ProductEnquiry.xsd READSTATISTICALGROUPBYCODERESP type.
    
    Attributes:
        error: Error information
        statistical_group: Statistical group information
    """
    
    error: Error
    statistical_group: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadStatisticalGroupByCodeResponse":
        """Create ReadStatisticalGroupByCodeResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            statistical_group=data.get("STATISTICALGROUP", {}),
        )


@dataclass
class FindAccountProductResponse:
    """Response for FindAccountProduct operation.
    
    Based on ProductEnquiry.xsd FINDACCOUNTPRODUCTRESP type.
    
    Attributes:
        error: Error information
        account_product_list: List of account products (optional)
    """
    
    error: Error
    account_product_list: Optional[List[Dict[str, str]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "FindAccountProductResponse":
        """Create FindAccountProductResponse from API response dictionary."""
        account_product_data = data.get("ACCOUNTPRODUCTLIST", {}).get("ACCOUNTPRODUCTITEM")
        account_product_list = None
        if account_product_data:
            if isinstance(account_product_data, list):
                account_product_list = account_product_data
            else:
                account_product_list = [account_product_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account_product_list=account_product_list,
        )


@dataclass
class SearchProductResponse:
    """Response for SearchProduct operation.
    
    Based on ProductEnquiry.xsd SEARCHPRODUCTRESP type.
    
    Attributes:
        error: Error information
        product_list: List of products (optional)
        page_resp: Page response (optional)
    """
    
    error: Error
    product_list: Optional[List[Product]] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchProductResponse":
        """Create SearchProductResponse from API response dictionary."""
        product_list_data = data.get("PRODUCTLIST", {}).get("PRODUCT")
        product_list = None
        if product_list_data:
            if isinstance(product_list_data, list):
                product_list = [Product.from_dict(p) for p in product_list_data]
            else:
                product_list = [Product.from_dict(product_list_data)]
        page_resp_data = data.get("PAGERESP")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product_list=product_list,
            page_resp=PageResponse.from_dict(page_resp_data) if page_resp_data else None,
        )


@dataclass
class SearchPriceByDateProductResponse:
    """Response for SearchPriceByDateProduct operation.
    
    Based on ProductEnquiry.xsd SEARCHPRICEBYDATEPRODUCTRESP type.
    
    Attributes:
        error: Error information
        product_list: List of products with price by date (optional)
    """
    
    error: Error
    product_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchPriceByDateProductResponse":
        """Create SearchPriceByDateProductResponse from API response dictionary."""
        product_list_data = data.get("PRODUCTLIST", {}).get("PRODUCT")
        product_list = None
        if product_list_data:
            if isinstance(product_list_data, list):
                product_list = product_list_data
            else:
                product_list = [product_list_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product_list=product_list,
        )


@dataclass
class GetAttributeByComponentCodeResponse:
    """Response for GetAttributeByComponentCode operation.
    
    Based on ProductEnquiry.xsd GETATTRIBUTEBYCOMPONENTCODERESP type.
    
    Attributes:
        error: Error information
        dimension_list: Dimension list
    """
    
    error: Error
    dimension_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetAttributeByComponentCodeResponse":
        """Create GetAttributeByComponentCodeResponse from API response dictionary."""
        dimension_data = data.get("DIMENSIONLIST", {}).get("DIMENSION")
        dimension_list = []
        if dimension_data:
            if isinstance(dimension_data, list):
                dimension_list = dimension_data
            else:
                dimension_list = [dimension_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            dimension_list=dimension_list,
        )


@dataclass
class ProductTransferResponse:
    """Response for ProductWarehouseChange operation.
    
    Based on ProductEnquiry.xsd PRODUCTTRANSFERRESP type.
    
    Attributes:
        error: Error information
        product_ak: Product AK
        request_id: Request ID
        request_datetime: Request date time
    """
    
    error: Error
    product_ak: str
    request_id: str
    request_datetime: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "ProductTransferResponse":
        """Create ProductTransferResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product_ak=data.get("PRODUCTAK", ""),
            request_id=data.get("REQUESTID", ""),
            request_datetime=data.get("REQUESTDATETIME", ""),
        )


@dataclass
class ProductTransferApprovalResponse:
    """Response for ProductWarehouseChangeApproval operation.
    
    Based on ProductEnquiry.xsd PRODUCTTRANSFERAPPROVALRESP type.
    
    Attributes:
        error: Error information
        request_id: Request ID
        request_datetime: Request date time
        approval_status: Approval status (0 = To Be Approved, 1 = Approved)
    """
    
    error: Error
    request_id: str
    request_datetime: str
    approval_status: int
    
    @classmethod
    def from_dict(cls, data: dict) -> "ProductTransferApprovalResponse":
        """Create ProductTransferApprovalResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            request_id=data.get("REQUESTID", ""),
            request_datetime=data.get("REQUESTDATETIME", ""),
            approval_status=data.get("APPROVALSTATUS", 0),
        )


@dataclass
class SearchWarehouseMovementResponse:
    """Response for SearchWarehouseMovement operation.
    
    Based on ProductEnquiry.xsd SEARCHWAREHOUSEMOVEMENTRESP type.
    
    Attributes:
        error: Error information
        movement_list: List of movements (optional)
        page_resp: Page response (optional)
    """
    
    error: Error
    movement_list: Optional[List[Dict[str, Any]]] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchWarehouseMovementResponse":
        """Create SearchWarehouseMovementResponse from API response dictionary."""
        movement_data = data.get("MOVEMENTTLIST", {}).get("MOVEMENT")
        movement_list = None
        if movement_data:
            if isinstance(movement_data, list):
                movement_list = movement_data
            else:
                movement_list = [movement_data]
        page_resp_data = data.get("PAGERESP")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            movement_list=movement_list,
            page_resp=PageResponse.from_dict(page_resp_data) if page_resp_data else None,
        )


@dataclass
class ProductInventoryUpdateResponse:
    """Response for ProductInventoryUpdate operation.
    
    Based on ProductEnquiry.xsd PRODUCTINVENTORYUPDATERESP type.
    
    Attributes:
        error: Error information
        product_ak: Product AK
    """
    
    error: Error
    product_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "ProductInventoryUpdateResponse":
        """Create ProductInventoryUpdateResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            product_ak=data.get("PRODUCTAK", ""),
        )
