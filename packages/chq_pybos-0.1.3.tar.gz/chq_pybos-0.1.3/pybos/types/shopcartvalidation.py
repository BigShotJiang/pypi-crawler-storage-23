"""
Type definitions for ShopcartValidation service.

This module provides structured classes for shopcart validation operations.
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any
from .common import Error, PageRequest, PageResponse


# Request Classes
@dataclass
class SearchShopcartValidationRequest:
    """Request for SearchShopcartValidation operation.
    
    Based on ShopcartValidation.xsd SEARCHSHOPCARTVALIDATIONREQ type.
    
    Attributes:
        ak: AK (optional)
        phases_filter: Phases filter (optional)
        page_req: Page request (optional)
    """
    
    ak: Optional[str] = None
    phases_filter: Optional[Dict[str, bool]] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.ak is not None:
            result["AK"] = self.ak
        if self.phases_filter is not None:
            result["PHASESFILTER"] = self.phases_filter
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


# Response Classes
@dataclass
class SearchShopcartValidationResponse:
    """Response for SearchShopcartValidation operation.
    
    Based on ShopcartValidation.xsd SEARCHSHOPCARTVALIDATIONRESP type.
    
    Attributes:
        error: Error information
        validations: Validations data
        page_resp: Page response
    """
    
    error: Error
    validations: Dict[str, Any]
    page_resp: PageResponse
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchShopcartValidationResponse":
        """Create SearchShopcartValidationResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            validations=data.get("VALIDATIONS", {}),
            page_resp=PageResponse.from_dict(data.get("PAGERESP", {})),
        )
