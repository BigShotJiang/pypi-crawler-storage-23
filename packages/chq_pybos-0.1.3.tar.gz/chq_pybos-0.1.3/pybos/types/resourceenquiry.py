"""
Type definitions for ResourceEnquiry.

This module provides structured classes for resource management operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter, BaseTimeFilter, PageRequest, PageResponse


# Request Classes
@dataclass
class SearchResourceAvailabilityRequest:
    """Request for SearchResourceAvailability operation.
    
    Based on ResourceEnquiry.xsd SEARCHRESOURCEAVAILABILITYREQ type.
    
    Attributes:
        date: Date filter
        time: Time filter (optional)
        resource_filter_list: Resource filter list (optional)
        page_req: Page request (optional)
    """
    
    date: BaseDateFilter
    time: Optional[BaseTimeFilter] = None
    resource_filter_list: Optional[List[str]] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"DATE": self.date.to_dict()}
        if self.time is not None:
            result["TIME"] = self.time.to_dict()
        if self.resource_filter_list is not None:
            result["RESOURCEFILTERLIST"] = {
                "RESOURCE": [{"AK": ak} for ak in self.resource_filter_list]
            }
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


@dataclass
class SearchResourceRequest:
    """Request for SearchResource operation.
    
    Based on ResourceEnquiry.xsd SEARCHRESOURCEREQ type.
    
    Attributes:
        date: Date filter (optional)
        resource_filter_list: Resource filter list (optional)
        type_filter_list: Type filter list (optional)
        disabled: Disabled flag (optional)
        page_req: Page request (optional)
    """
    
    date: Optional[BaseDateFilter] = None
    resource_filter_list: Optional[List[str]] = None
    type_filter_list: Optional[List[int]] = None
    disabled: Optional[bool] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.date is not None:
            result["DATE"] = self.date.to_dict()
        if self.resource_filter_list is not None:
            result["RESOURCEFILTERLIST"] = {
                "RESOURCE": [{"AK": ak} for ak in self.resource_filter_list]
            }
        if self.type_filter_list is not None:
            result["TYPEFILTERLIST"] = {"TYPE": self.type_filter_list}
        if self.disabled is not None:
            result["DISABLED"] = self.disabled
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


@dataclass
class SearchRequirementTemplatesAndTemplateSetsRequest:
    """Request for SearchRequirementTemplatesAndTemplateSets operation.
    
    Based on ResourceEnquiry.xsd SEARCHREQUIREMENTTEMPLATESANDTEMPLATESETSREQ type.
    
    Attributes:
        event_category_list: Event category list (optional)
        event_filter_list: Event filter list (optional)
        performance_ak: Performance AK (optional)
    """
    
    event_category_list: Optional[List[Dict[str, str]]] = None
    event_filter_list: Optional[List[str]] = None
    performance_ak: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.event_category_list is not None:
            result["EVENTCATEGORYLIST"] = {"EVENTCATEGORY": self.event_category_list}
        if self.event_filter_list is not None:
            result["EVENTFILTERLIST"] = {
                "EVENT": [{"AK": ak} for ak in self.event_filter_list]
            }
        if self.performance_ak is not None:
            result["PERFORMANCEAK"] = self.performance_ak
        return result


@dataclass
class SetTemplateSetRequest:
    """Request for SetTemplateSet operation.
    
    Based on ResourceEnquiry.xsd SETTEMPLATESETREQ type.
    
    Attributes:
        performance_ak: Performance AK
        requirement_ak: Requirement AK (optional) - if empty, removes schedule
    """
    
    performance_ak: str
    requirement_ak: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"PERFORMANCEAK": self.performance_ak}
        if self.requirement_ak is not None:
            result["REQUIREMENTAK"] = self.requirement_ak
        return result


# Response Classes
@dataclass
class SearchResourceAvailabilityResponse:
    """Response for SearchResourceAvailability operation.
    
    Based on ResourceEnquiry.xsd SEARCHRESOURCEAVAILABILITYRESP type.
    
    Attributes:
        error: Error information
        resource_schedule_list: Resource schedule list (optional)
        page_resp: Page response (optional)
    """
    
    error: Error
    resource_schedule_list: Optional[List[Dict[str, Any]]] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchResourceAvailabilityResponse":
        """Create SearchResourceAvailabilityResponse from API response dictionary."""
        schedule_data = data.get("RESOURCESCHEDULELIST", {}).get("RESOURCESCHEDULE")
        schedule_list = None
        if schedule_data:
            if isinstance(schedule_data, list):
                schedule_list = schedule_data
            else:
                schedule_list = [schedule_data]
        page_resp_data = data.get("PAGERESP")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            resource_schedule_list=schedule_list,
            page_resp=PageResponse.from_dict(page_resp_data) if page_resp_data else None,
        )


@dataclass
class SearchResourceResponse:
    """Response for SearchResource operation.
    
    Based on ResourceEnquiry.xsd SEARCHRESOURCERESP type.
    
    Attributes:
        error: Error information
        resource_list: Resource list (optional)
        page_resp: Page response (optional)
    """
    
    error: Error
    resource_list: Optional[List[Dict[str, Any]]] = None
    page_resp: Optional[PageResponse] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchResourceResponse":
        """Create SearchResourceResponse from API response dictionary."""
        resource_data = data.get("RESOURCELIST", {}).get("RESOURCE")
        resource_list = None
        if resource_data:
            if isinstance(resource_data, list):
                resource_list = resource_data
            else:
                resource_list = [resource_data]
        page_resp_data = data.get("PAGERESP")
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            resource_list=resource_list,
            page_resp=PageResponse.from_dict(page_resp_data) if page_resp_data else None,
        )


@dataclass
class SearchRequirementTemplatesAndTemplateSetsResponse:
    """Response for SearchRequirementTemplatesAndTemplateSets operation.
    
    Based on ResourceEnquiry.xsd SEARCHREQUIREMENTTEMPLATESANDTEMPLATESETSRESP type.
    
    Attributes:
        error: Error information
        requirement_list: Requirement list (optional)
    """
    
    error: Error
    requirement_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchRequirementTemplatesAndTemplateSetsResponse":
        """Create SearchRequirementTemplatesAndTemplateSetsResponse from API response dictionary."""
        requirement_data = data.get("REQUIREMENTLIST", {}).get("REQUIREMENT")
        requirement_list = None
        if requirement_data:
            if isinstance(requirement_data, list):
                requirement_list = requirement_data
            else:
                requirement_list = [requirement_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            requirement_list=requirement_list,
        )


@dataclass
class SetTemplateSetResponse:
    """Response for SetTemplateSet operation.
    
    Based on ResourceEnquiry.xsd SETTEMPLATESETRESP type.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "SetTemplateSetResponse":
        """Create SetTemplateSetResponse from API response dictionary."""
        return cls(error=Error.from_dict(data.get("ERROR", {})))
