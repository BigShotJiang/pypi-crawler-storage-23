"""
Waitlist subscription-related data types for the BOS API.

This module provides structured classes for waitlist subscription operations,
replacing tuple-based parameters with type-safe, self-documenting classes.
"""

from dataclasses import dataclass
from typing import Optional, List, Union
from .common import Error, PageRequest, PageResponse, BaseDateFilter


@dataclass
class WaitListSubscription:
    """Waitlist subscription information structure.

    Based on WaitListSubscriptionsEnquiry.xsd WAITLISTSUBSCRIPTION type.

    Attributes:
        datetime: Timestamp of the subscription
        email: Email of subscriber
        performance_ak: Performance AK being waited for
        qty: Quantity waited for
        seat_category_code: Seat category code (optional)
        space_structure_ak: Sector/space structure AK (optional)
        envelope_code: Envelope code (optional)
        last_notification_datetime: Last notification datetime (optional)
        sale_ak: Fulfilled sale AK (optional)
        purge: Flag to purge the subscription (optional)
    """

    datetime: str
    email: str
    performance_ak: str
    qty: int
    seat_category_code: Optional[str] = None
    space_structure_ak: Optional[str] = None
    envelope_code: Optional[str] = None
    last_notification_datetime: Optional[str] = None
    sale_ak: Optional[str] = None
    purge: Optional[bool] = None

    @classmethod
    def from_dict(cls, data: dict) -> "WaitListSubscription":
        """Create WaitListSubscription from API response dictionary."""
        return cls(
            datetime=data.get("DATETIME", ""),
            email=data.get("EMAIL", ""),
            performance_ak=data.get("PERFORMANCEAK", ""),
            qty=data.get("QTY", 0),
            seat_category_code=data.get("SEATCATEGORYCODE"),
            space_structure_ak=data.get("SPACESTRUCTUREAK"),
            envelope_code=data.get("ENVELOPECODE"),
            last_notification_datetime=data.get("LASTNOTIFICATIONDATETIME"),
            sale_ak=data.get("SALEAK"),
            purge=data.get("PURGE"),
        )


@dataclass
class WaitListSubscriptionV2:
    """Waitlist subscription V2 information structure.

    Based on WaitListSubscriptionsEnquiry.xsd WAITLISTSUBSCRIPTION_V2 type.

    Attributes:
        datetime: Timestamp of the subscription
        email: Email of subscriber
        qty: Quantity waited for
        seat_category_code: Seat category code (optional)
        space_structure_ak: Sector/space structure AK (optional)
        envelope_code: Envelope code (optional)
        last_notification_datetime: Last notification datetime (optional)
        sale_ak: Fulfilled sale AK (optional)
        purge: Flag to purge the subscription (optional)
        choice: Choice between single performance or multiple performances
        waitlist_subscription_type: Type of waitlist subscription
        waitlist_subscription_id: ID of the waitlist subscription (optional)
    """

    datetime: str
    email: str
    qty: int
    seat_category_code: Optional[str] = None
    space_structure_ak: Optional[str] = None
    envelope_code: Optional[str] = None
    last_notification_datetime: Optional[str] = None
    sale_ak: Optional[str] = None
    purge: Optional[bool] = None
    choice: Optional[dict] = None
    waitlist_subscription_type: int = 0
    waitlist_subscription_id: Optional[int] = None

    @classmethod
    def from_dict(cls, data: dict) -> "WaitListSubscriptionV2":
        """Create WaitListSubscriptionV2 from API response dictionary."""
        return cls(
            datetime=data.get("DATETIME", ""),
            email=data.get("EMAIL", ""),
            qty=data.get("QTY", 0),
            seat_category_code=data.get("SEATCATEGORYCODE"),
            space_structure_ak=data.get("SPACESTRUCTUREAK"),
            envelope_code=data.get("ENVELOPECODE"),
            last_notification_datetime=data.get("LASTNOTIFICATIONDATETIME"),
            sale_ak=data.get("SALEAK"),
            purge=data.get("PURGE"),
            choice=data.get("CHOICE"),
            waitlist_subscription_type=data.get("WAITLISTSUBSCRIPTIONTYPE", 0),
            waitlist_subscription_id=data.get("WAITLISTSUBSCRIPTIONID"),
        )


# Request Classes
@dataclass
class SearchWaitListSubscriptionsRequest:
    """Structured request for SearchWaitListSubscriptions operation.

    Based on WaitListSubscriptionsEnquiry.xsd SEARCHWAITLISTSUBSCRIPTIONSREQ structure.

    Attributes:
        date_filter: Date filter for search
        email: Email to search for
        performance_ak: Performance AK to search for
        event_ak: Event AK to search for
        page_request: Pagination parameters
    """

    date_filter: Optional[BaseDateFilter] = None
    email: Optional[str] = None
    performance_ak: Optional[str] = None
    event_ak: Optional[str] = None
    page_request: Optional[PageRequest] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.date_filter is not None:
            result["DATE"] = self.date_filter.to_dict()
        if self.email is not None:
            result["EMAIL"] = self.email
        if self.performance_ak is not None:
            result["PERFORMANCEAK"] = self.performance_ak
        if self.event_ak is not None:
            result["EVENTAK"] = self.event_ak
        if self.page_request is not None:
            result["PAGEREQ"] = self.page_request.to_dict()
        return result


@dataclass
class SearchWaitListSubscriptionsV2Request:
    """Structured request for SearchWaitListSubscriptionsV2 operation.

    Based on WaitListSubscriptionsEnquiry.xsd SEARCHWAITLISTSUBSCRIPTIONS_V2REQ structure.

    Attributes:
        date_filter: Date filter for search
        email: Email to search for
        search_choice: Choice between single or multiple performance search
        event_ak: Event AK to search for
        page_request: Pagination parameters
    """

    date_filter: Optional[BaseDateFilter] = None
    email: Optional[str] = None
    search_choice: Optional[dict] = None
    event_ak: Optional[str] = None
    page_request: Optional[PageRequest] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.date_filter is not None:
            result["DATE"] = self.date_filter.to_dict()
        if self.email is not None:
            result["EMAIL"] = self.email
        if self.search_choice is not None:
            result["SEARCHCHOICE"] = self.search_choice
        if self.event_ak is not None:
            result["EVENTAK"] = self.event_ak
        if self.page_request is not None:
            result["PAGEREQ"] = self.page_request.to_dict()
        return result


@dataclass
class SubscribeRequest:
    """Structured request for Subscribe operation.

    Based on WaitListSubscriptionsEnquiry.xsd SUBSCRIBEREQ structure.

    Attributes:
        email: Email of subscriber
        performance_ak: Performance AK to subscribe to
        qty: Quantity to subscribe for
        seat_category_code: Seat category code (optional)
        space_structure_ak: Sector/space structure AK (optional)
        envelope_code: Envelope code (optional)
        update: Whether to update existing subscription (optional)
    """

    email: str
    performance_ak: str
    qty: int
    seat_category_code: Optional[str] = None
    space_structure_ak: Optional[str] = None
    envelope_code: Optional[str] = None
    update: Optional[bool] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "EMAIL": self.email,
            "PERFORMANCEAK": self.performance_ak,
            "QTY": self.qty,
        }
        if self.seat_category_code is not None:
            result["SEATCATEGORYCODE"] = self.seat_category_code
        if self.space_structure_ak is not None:
            result["SPACESTRUCTUREAK"] = self.space_structure_ak
        if self.envelope_code is not None:
            result["ENVELOPECODE"] = self.envelope_code
        if self.update is not None:
            result["UPDATE"] = self.update
        return result


@dataclass
class SubscribeV2Request:
    """Structured request for SubscribeV2 operation.

    Based on WaitListSubscriptionsEnquiry.xsd SUBSCRIBE_V2REQ structure.

    Attributes:
        email: Email of subscriber
        qty: Quantity to subscribe for
        seat_category_code: Seat category code (optional)
        space_structure_ak: Sector/space structure AK (optional)
        envelope_code: Envelope code (optional)
        update: Whether to update existing subscription (optional)
        choice: Choice between single performance or multiple performances
        subscription_type: Type of subscription
    """

    email: str
    qty: int
    seat_category_code: Optional[str] = None
    space_structure_ak: Optional[str] = None
    envelope_code: Optional[str] = None
    update: Optional[bool] = None
    choice: Optional[dict] = None
    subscription_type: int = 0

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "EMAIL": self.email,
            "QTY": self.qty,
            "SUBSCRIPTIONTYPE": self.subscription_type,
        }
        if self.seat_category_code is not None:
            result["SEATCATEGORYCODE"] = self.seat_category_code
        if self.space_structure_ak is not None:
            result["SPACESTRUCTUREAK"] = self.space_structure_ak
        if self.envelope_code is not None:
            result["ENVELOPECODE"] = self.envelope_code
        if self.update is not None:
            result["UPDATE"] = self.update
        if self.choice is not None:
            result["CHOICE"] = self.choice
        return result


@dataclass
class UnSubscribeRequest:
    """Structured request for UnSubscribe operation.

    Based on WaitListSubscriptionsEnquiry.xsd UNSUBSCRIBEREQ structure.

    Attributes:
        email: Email of subscriber
        performance_ak: Performance AK to unsubscribe from
    """

    email: str
    performance_ak: str

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "EMAIL": self.email,
            "PERFORMANCEAK": self.performance_ak,
        }


@dataclass
class UnSubscribeV2Request:
    """Structured request for UnSubscribeV2 operation.

    Based on WaitListSubscriptionsEnquiry.xsd UNSUBSCRIBE_V2REQ structure.

    Attributes:
        waitlist_subscription_id: ID of the waitlist subscription to unsubscribe from
    """

    waitlist_subscription_id: int

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "WAITLISTSUBSCRIPTIONID": self.waitlist_subscription_id,
        }


# Response Classes
@dataclass
class SearchWaitListSubscriptionsResponse:
    """Response for SearchWaitListSubscriptions operation.

    Based on WaitListSubscriptionsEnquiry.xsd SEARCHWAITLISTSUBSCRIPTIONSRESP structure.

    Attributes:
        error: Error information
        page_response: Pagination response information
        subscription_list: List of waitlist subscriptions
    """

    error: Error
    page_response: PageResponse
    subscription_list: List[WaitListSubscription]

    @classmethod
    def from_dict(cls, data: dict) -> "SearchWaitListSubscriptionsResponse":
        """Create response from API dictionary."""
        subscription_list_data = data.get("WAITLISTSUBSCRIPTIONLIST", {}).get(
            "WAITLISTSUBSCRIPTIONITEM", []
        )
        if not isinstance(subscription_list_data, list):
            subscription_list_data = (
                [subscription_list_data] if subscription_list_data else []
            )

        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            page_response=PageResponse.from_dict(data.get("PAGERESP", {})),
            subscription_list=[
                WaitListSubscription.from_dict(sub) for sub in subscription_list_data
            ],
        )


@dataclass
class SearchWaitListSubscriptionsV2Response:
    """Response for SearchWaitListSubscriptionsV2 operation.

    Based on WaitListSubscriptionsEnquiry.xsd SEARCHWAITLISTSUBSCRIPTIONS_V2RESP structure.

    Attributes:
        error: Error information
        page_response: Pagination response information
        subscription_list: List of waitlist subscriptions V2
    """

    error: Error
    page_response: PageResponse
    subscription_list: List[WaitListSubscriptionV2]

    @classmethod
    def from_dict(cls, data: dict) -> "SearchWaitListSubscriptionsV2Response":
        """Create response from API dictionary."""
        subscription_list_data = data.get("WAITLISTSUBSCRIPTIONLIST_V2", {}).get(
            "WAITLISTSUBSCRIPTIONITEM", []
        )
        if not isinstance(subscription_list_data, list):
            subscription_list_data = (
                [subscription_list_data] if subscription_list_data else []
            )

        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            page_response=PageResponse.from_dict(data.get("PAGERESP", {})),
            subscription_list=[
                WaitListSubscriptionV2.from_dict(sub) for sub in subscription_list_data
            ],
        )


@dataclass
class SubscribeResponse:
    """Response for Subscribe operation.

    Based on WaitListSubscriptionsEnquiry.xsd SUBSCRIBERESP structure.

    Attributes:
        error: Error information
        subscription_item: Created waitlist subscription item
    """

    error: Error
    subscription_item: Optional[WaitListSubscription] = None

    @classmethod
    def from_dict(cls, data: dict) -> "SubscribeResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            subscription_item=(
                WaitListSubscription.from_dict(data.get("WAITLISTSUBSCRIPTIONITEM", {}))
                if data.get("WAITLISTSUBSCRIPTIONITEM")
                else None
            ),
        )


@dataclass
class SubscribeV2Response:
    """Response for SubscribeV2 operation.

    Based on WaitListSubscriptionsEnquiry.xsd SUBSCRIBE_V2RESP structure.

    Attributes:
        error: Error information
        subscription_item: Created waitlist subscription item V2
    """

    error: Error
    subscription_item: Optional[WaitListSubscriptionV2] = None

    @classmethod
    def from_dict(cls, data: dict) -> "SubscribeV2Response":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            subscription_item=(
                WaitListSubscriptionV2.from_dict(
                    data.get("WAITLISTSUBSCRIPTIONITEM", {})
                )
                if data.get("WAITLISTSUBSCRIPTIONITEM")
                else None
            ),
        )


@dataclass
class UnSubscribeResponse:
    """Response for UnSubscribe operation.

    Based on WaitListSubscriptionsEnquiry.xsd UNSUBSCRIBERESP structure.

    Attributes:
        error: Error information
        subscription_item: Unsubscribed waitlist subscription item
    """

    error: Error
    subscription_item: Optional[WaitListSubscription] = None

    @classmethod
    def from_dict(cls, data: dict) -> "UnSubscribeResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            subscription_item=(
                WaitListSubscription.from_dict(data.get("WAITLISTSUBSCRIPTIONITEM", {}))
                if data.get("WAITLISTSUBSCRIPTIONITEM")
                else None
            ),
        )


@dataclass
class UnSubscribeV2Response:
    """Response for UnSubscribeV2 operation.

    Based on WaitListSubscriptionsEnquiry.xsd UNSUBSCRIBE_V2RESP structure.

    Attributes:
        error: Error information
        subscription_item: Unsubscribed waitlist subscription item V2
    """

    error: Error
    subscription_item: Optional[WaitListSubscriptionV2] = None

    @classmethod
    def from_dict(cls, data: dict) -> "UnSubscribeV2Response":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            subscription_item=(
                WaitListSubscriptionV2.from_dict(
                    data.get("WAITLISTSUBSCRIPTIONITEM", {})
                )
                if data.get("WAITLISTSUBSCRIPTIONITEM")
                else None
            ),
        )
