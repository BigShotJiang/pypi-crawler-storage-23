"""
Type definitions for MoneyCard service.

This module provides structured classes for money card operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error


# Request Classes
@dataclass
class RecordMoneyCardUsageRequest:
    """Request for RecordMoneyCardUsage operation.
    
    Based on MoneyCard.xsd RECORDMONEYCARDUSAGEREQ type.
    
    Attributes:
        amount: Amount
        search: Ticket input search (TICKETINPUTSEARCH type)
        ext_operation_code: External operation code (optional)
    """
    
    amount: float
    search: Dict[str, Any]  # TICKETINPUTSEARCH type
    ext_operation_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"AMOUNT": self.amount, "SEARCH": self.search}
        if self.ext_operation_code is not None:
            result["EXTOPERATIONCODE"] = self.ext_operation_code
        return result


@dataclass
class RecordMoneyCardRechargeRequest:
    """Request for RecordMoneyCardRecharge operation.
    
    Based on MoneyCard.xsd RECORDMONEYCARDRECHARGEREQ type.
    
    Attributes:
        amount: Amount
        search: Ticket input search (TICKETINPUTSEARCH type)
        ext_operation_code: External operation code (optional)
    """
    
    amount: float
    search: Dict[str, Any]  # TICKETINPUTSEARCH type
    ext_operation_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"AMOUNT": self.amount, "SEARCH": self.search}
        if self.ext_operation_code is not None:
            result["EXTOPERATIONCODE"] = self.ext_operation_code
        return result


@dataclass
class RecordMoneyCardCashOutRequest:
    """Request for RecordMoneyCardCashOut operation.
    
    Based on MoneyCard.xsd RECORDMONEYCARDCASHOUTREQ type.
    
    Attributes:
        amount: Amount
        search: Ticket input search (TICKETINPUTSEARCH type)
        ext_operation_code: External operation code (optional)
    """
    
    amount: float
    search: Dict[str, Any]  # TICKETINPUTSEARCH type
    ext_operation_code: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"AMOUNT": self.amount, "SEARCH": self.search}
        if self.ext_operation_code is not None:
            result["EXTOPERATIONCODE"] = self.ext_operation_code
        return result


@dataclass
class ReadMoneyCardOperationRequest:
    """Request for ReadMoneyCardOperation operation.
    
    Based on MoneyCard.xsd READMONEYCARDOPERATIONREQ type.
    
    Attributes:
        search: Ticket input search (TICKETINPUTSEARCH type)
    """
    
    search: Dict[str, Any]  # TICKETINPUTSEARCH type
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"SEARCH": self.search}


# Response Classes
@dataclass
class RecordMoneyCardUsageResponse:
    """Response for RecordMoneyCardUsage operation.
    
    Based on MoneyCard.xsd RECORDMONEYCARDUSAGERESP type.
    
    Attributes:
        error: Error information
        money_card: Money card information (optional)
        ticket_list: Ticket list (optional)
    """
    
    error: Error
    money_card: Optional[Dict[str, Any]] = None
    ticket_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "RecordMoneyCardUsageResponse":
        """Create RecordMoneyCardUsageResponse from API response dictionary."""
        ticket_data = data.get("TICKETLIST", {}).get("TICKET")
        ticket_list = None
        if ticket_data:
            if isinstance(ticket_data, list):
                ticket_list = ticket_data
            else:
                ticket_list = [ticket_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            money_card=data.get("MONEYCARD"),
            ticket_list=ticket_list,
        )


@dataclass
class RecordMoneyCardRechargeResponse:
    """Response for RecordMoneyCardRecharge operation.
    
    Based on MoneyCard.xsd RECORDMONEYCARDRECHARGERESP type.
    
    Attributes:
        error: Error information
        money_card: Money card information (optional)
        ticket_list: Ticket list (optional)
    """
    
    error: Error
    money_card: Optional[Dict[str, Any]] = None
    ticket_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "RecordMoneyCardRechargeResponse":
        """Create RecordMoneyCardRechargeResponse from API response dictionary."""
        ticket_data = data.get("TICKETLIST", {}).get("TICKET")
        ticket_list = None
        if ticket_data:
            if isinstance(ticket_data, list):
                ticket_list = ticket_data
            else:
                ticket_list = [ticket_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            money_card=data.get("MONEYCARD"),
            ticket_list=ticket_list,
        )


@dataclass
class RecordMoneyCardCashOutResponse:
    """Response for RecordMoneyCardCashOut operation.
    
    Based on MoneyCard.xsd RECORDMONEYCARDCASHOUTRESP type.
    
    Attributes:
        error: Error information
        money_card: Money card information (optional)
        ticket_list: Ticket list (optional)
    """
    
    error: Error
    money_card: Optional[Dict[str, Any]] = None
    ticket_list: Optional[List[Dict[str, Any]]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "RecordMoneyCardCashOutResponse":
        """Create RecordMoneyCardCashOutResponse from API response dictionary."""
        ticket_data = data.get("TICKETLIST", {}).get("TICKET")
        ticket_list = None
        if ticket_data:
            if isinstance(ticket_data, list):
                ticket_list = ticket_data
            else:
                ticket_list = [ticket_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            money_card=data.get("MONEYCARD"),
            ticket_list=ticket_list,
        )


@dataclass
class ReadMoneyCardOperationResponse:
    """Response for ReadMoneyCardOperation operation.
    
    Based on MoneyCard.xsd READMONEYCARDOPERATIONRESP type.
    
    Attributes:
        error: Error information
        money_card_operation_list: Money card operation list (optional)
        money_card: Money card information (optional)
    """
    
    error: Error
    money_card_operation_list: Optional[List[Dict[str, Any]]] = None
    money_card: Optional[Dict[str, Any]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadMoneyCardOperationResponse":
        """Create ReadMoneyCardOperationResponse from API response dictionary."""
        operation_data = data.get("MONEYCARDOPERATIONLIST", {}).get("MONEYCARDOPERATION")
        operation_list = None
        if operation_data:
            if isinstance(operation_data, list):
                operation_list = operation_data
            else:
                operation_list = [operation_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            money_card_operation_list=operation_list,
            money_card=data.get("MONEYCARD"),
        )
