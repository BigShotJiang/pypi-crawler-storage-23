"""
Type definitions for ThirdParty.

This module provides structured classes for third party operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error


# Request Classes
@dataclass
class LoginRequest:
    """Request for LoginSocio and LoginPreventa operations.
    
    Based on ThirdParty.xsd LOGINREQ type.
    
    Attributes:
        user: Username
        password: Password
        ip: IP address (optional)
    """
    
    user: str
    password: str
    ip: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"USER": self.user, "PASSWORD": self.password}
        if self.ip is not None:
            result["IP"] = self.ip
        return result


@dataclass
class SeatingInfoRequest:
    """Request for SeatingInfo operation.
    
    Based on ThirdParty.xsd SEATINGINFOREQ type.
    
    Attributes:
        space_structure_ak: Space structure AK
        only_available: Only available flag (optional)
        billing_account: Billing account (optional)
        logged_account: Logged account (optional)
        ip: IP address (optional)
    """
    
    space_structure_ak: str
    only_available: Optional[bool] = None
    billing_account: Optional[Dict[str, Any]] = None
    logged_account: Optional[Dict[str, Any]] = None
    ip: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"SPACESTRUCTUREAK": self.space_structure_ak}
        if self.only_available is not None:
            result["ONLYAVAILABLE"] = self.only_available
        if self.billing_account is not None:
            result["BILLINGACCOUNT"] = self.billing_account
        if self.logged_account is not None:
            result["LOGGEDACCOUNT"] = self.logged_account
        if self.ip is not None:
            result["IP"] = self.ip
        return result


@dataclass
class ThirdHoldSeatRequest:
    """Request for HoldSeat operation.
    
    Based on ThirdParty.xsd THIRDHOLDSEATREQ type.
    
    Attributes:
        space_structure_ak: Space structure AK
        seat_list: Seat list (SEATINFOLISTBASE type)
    """
    
    space_structure_ak: str
    seat_list: Dict[str, Any]  # SEATINFOLISTBASE type
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "SPACESTRUCTUREAK": self.space_structure_ak,
            "SEATLIST": self.seat_list,
        }


@dataclass
class ThirdReleaseSeatRequest:
    """Request for ReleaseSeat operation.
    
    Based on ThirdParty.xsd THIRDRELEASESEATREQ type.
    
    Attributes:
        space_structure_ak: Space structure AK
        seat_list: Seat list (SEATINFOLISTBASE type)
    """
    
    space_structure_ak: str
    seat_list: Dict[str, Any]  # SEATINFOLISTBASE type
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "SPACESTRUCTUREAK": self.space_structure_ak,
            "SEATLIST": self.seat_list,
        }


@dataclass
class DownloadExternalPDFRequest:
    """Request for DownloadExternalPDF operation.
    
    Based on ThirdParty.xsd DOWNLOADEXTERNALPDFREQ type.
    
    Attributes:
        sale_ak: Sale AK
    """
    
    sale_ak: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"SALEAK": self.sale_ak}


@dataclass
class GetAccountByUUIDRequest:
    """Request for GetAccountByUUID operation.
    
    Based on ThirdParty.xsd GETACCOUNTBYUUIDREQ type.
    
    Attributes:
        uuid: UUID
    """
    
    uuid: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"UUID": self.uuid}


@dataclass
class SetCanalByAccountAKRequest:
    """Request for SetCanalByAccountAK operation.
    
    Based on ThirdParty.xsd SETCANALBYACCOUNTAKREQ type.
    
    Attributes:
        account_ak: Account AK
        canal: Canal
    """
    
    account_ak: str
    canal: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"ACCOUNTAK": self.account_ak, "CANAL": self.canal}


@dataclass
class ReleasePerformanceByUUIDRequest:
    """Request for ReleasePerformanceByUUID operation.
    
    Based on ThirdParty.xsd RELEASEPERFORMANCEBYUUIDREQ type.
    
    Attributes:
        uuid: UUID
        performance_ak: Performance AK
        space_structure_ak: Space structure AK
        seat_row: Seat row (optional)
        seat_col: Seat column (optional)
    """
    
    uuid: str
    performance_ak: str
    space_structure_ak: str
    seat_row: Optional[str] = None
    seat_col: Optional[str] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "UUID": self.uuid,
            "PERFORMANCEAK": self.performance_ak,
            "SPACESTRUCTUREAK": self.space_structure_ak,
        }
        if self.seat_row is not None:
            result["SEATROW"] = self.seat_row
        if self.seat_col is not None:
            result["SEATCOL"] = self.seat_col
        return result


@dataclass
class ReleasePerformanceByTicketIdRequest:
    """Request for ReleasePerformanceByTicketId operation.
    
    Based on ThirdParty.xsd RELEASEPERFORMANCEBYTICKETIDREQ type.
    
    Attributes:
        ticket_id: Ticket ID
        performance_ak: Performance AK
    """
    
    ticket_id: int
    performance_ak: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "TICKETID": self.ticket_id,
            "PERFORMANCEAK": self.performance_ak,
        }


@dataclass
class BottomLinePayRequest:
    """Request for BottomLinePay operation.
    
    Based on ThirdParty.xsd BOTTOMLINEPAYREQ type.
    
    Attributes:
        sale_ak: Sale AK
        payment_code: Payment code
        amount: Amount
        account_ak: Account AK (optional)
        card_on_file_id: Card on file ID (optional)
    """
    
    sale_ak: str
    payment_code: str
    amount: float
    account_ak: Optional[str] = None
    card_on_file_id: Optional[int] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "SALEAK": self.sale_ak,
            "PAYMENTCODE": self.payment_code,
            "AMOUNT": self.amount,
        }
        if self.account_ak is not None:
            result["ACCOUNTAK"] = self.account_ak
        if self.card_on_file_id is not None:
            result["CARDONFILEID"] = self.card_on_file_id
        return result


# Response Classes
@dataclass
class LoginResponse:
    """Response for LoginSocio and LoginPreventa operations.
    
    Based on ThirdParty.xsd LOGINRESP type.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "LoginResponse":
        """Create LoginResponse from API response dictionary."""
        return cls(error=Error.from_dict(data.get("ERROR", {})))


@dataclass
class SeatingInfoResponse:
    """Response for SeatingInfo operation.
    
    Based on ThirdParty.xsd SEATINGINFORESP type.
    
    Attributes:
        error: Error information
        seating_info_list: List of seating information
    """
    
    error: Error
    seating_info_list: List[Dict[str, Any]]
    
    @classmethod
    def from_dict(cls, data: dict) -> "SeatingInfoResponse":
        """Create SeatingInfoResponse from API response dictionary."""
        seating_data = data.get("SEATINGINFOLIST", {}).get("SEATINGINFO")
        seating_list = []
        if seating_data:
            if isinstance(seating_data, list):
                seating_list = seating_data
            else:
                seating_list = [seating_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            seating_info_list=seating_list,
        )


@dataclass
class ThirdHoldSeatResponse:
    """Response for HoldSeat operation.
    
    Based on ThirdParty.xsd THIRDHOLDSEATRESP type.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "ThirdHoldSeatResponse":
        """Create ThirdHoldSeatResponse from API response dictionary."""
        return cls(error=Error.from_dict(data.get("ERROR", {})))


@dataclass
class ThirdReleaseSeatResponse:
    """Response for ReleaseSeat operation.
    
    Based on ThirdParty.xsd THIRDRELEASESEATRESP type.
    
    Attributes:
        error: Error information
    """
    
    error: Error
    
    @classmethod
    def from_dict(cls, data: dict) -> "ThirdReleaseSeatResponse":
        """Create ThirdReleaseSeatResponse from API response dictionary."""
        return cls(error=Error.from_dict(data.get("ERROR", {})))


@dataclass
class DownloadExternalPDFResponse:
    """Response for DownloadExternalPDF operation.
    
    Based on ThirdParty.xsd DOWNLOADEXTERNALPDFRESP type.
    
    Attributes:
        error: Error information
        pdf: PDF data (hexBinary)
    """
    
    error: Error
    pdf: bytes
    
    @classmethod
    def from_dict(cls, data: dict) -> "DownloadExternalPDFResponse":
        """Create DownloadExternalPDFResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            pdf=data.get("PDF", b""),
        )


@dataclass
class GetAccountByUUIDResponse:
    """Response for GetAccountByUUID operation.
    
    Based on ThirdParty.xsd GETACCOUNTBYUUIDRESP type.
    
    Attributes:
        error: Error information
        account_ak: Account AK
        canal_list: Canal list
    """
    
    error: Error
    account_ak: str
    canal_list: List[str]
    
    @classmethod
    def from_dict(cls, data: dict) -> "GetAccountByUUIDResponse":
        """Create GetAccountByUUIDResponse from API response dictionary."""
        canal_data = data.get("CANALLIST", {}).get("CANAL")
        canal_list = []
        if canal_data:
            if isinstance(canal_data, list):
                canal_list = canal_data
            else:
                canal_list = [canal_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account_ak=data.get("ACCOUNTAK", ""),
            canal_list=canal_list,
        )


@dataclass
class SetCanalByAccountAKResponse:
    """Response for SetCanalByAccountAK operation.
    
    Based on ThirdParty.xsd SETCANALBYACCOUNTAKRESP type.
    
    Attributes:
        error: Error information
        account_ak: Account AK
    """
    
    error: Error
    account_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "SetCanalByAccountAKResponse":
        """Create SetCanalByAccountAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            account_ak=data.get("ACCOUNTAK", ""),
        )


@dataclass
class ReleasePerformanceByUUIDResponse:
    """Response for ReleasePerformanceByUUID operation.
    
    Based on ThirdParty.xsd RELEASEPERFORMANCEBYUUIDRESP type.
    
    Attributes:
        error: Error information
        uuid: UUID (optional)
        space_structure_ak: Space structure AK (optional)
        seat_row: Seat row (optional)
        seat_col: Seat column (optional)
        performance_list: Performance list (optional)
    """
    
    error: Error
    uuid: Optional[str] = None
    space_structure_ak: Optional[str] = None
    seat_row: Optional[str] = None
    seat_col: Optional[str] = None
    performance_list: Optional[List[str]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReleasePerformanceByUUIDResponse":
        """Create ReleasePerformanceByUUIDResponse from API response dictionary."""
        perf_data = data.get("PERFORMANCELIST", {}).get("PERFORMANCE")
        perf_list = None
        if perf_data:
            if isinstance(perf_data, list):
                perf_list = [p.get("AK", "") for p in perf_data]
            else:
                perf_list = [perf_data.get("AK", "")]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            uuid=data.get("UUID"),
            space_structure_ak=data.get("SPACESTRUCTUREAK"),
            seat_row=data.get("SEATROW"),
            seat_col=data.get("SEATCOL"),
            performance_list=perf_list,
        )


@dataclass
class ReleasePerformanceByTicketIdResponse:
    """Response for ReleasePerformanceByTicketId operation.
    
    Based on ThirdParty.xsd RELEASEPERFORMANCEBYTICKETIDRESP type.
    
    Attributes:
        error: Error information
        ticket_id: Ticket ID
        performance_ak: Performance AK
    """
    
    error: Error
    ticket_id: int
    performance_ak: str
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReleasePerformanceByTicketIdResponse":
        """Create ReleasePerformanceByTicketIdResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            ticket_id=data.get("TICKETID", 0),
            performance_ak=data.get("PERFORMANCEAK", ""),
        )


@dataclass
class BottomLinePayResponse:
    """Response for BottomLinePay operation.
    
    Based on ThirdParty.xsd BOTTOMLINEPAYRESP type.
    
    Attributes:
        error: Error information
        customer_error_messages: Customer error messages (optional)
    """
    
    error: Error
    customer_error_messages: Optional[List[str]] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "BottomLinePayResponse":
        """Create BottomLinePayResponse from API response dictionary."""
        msg_data = data.get("CUSTOMERRORMESSAGES", {}).get("MESSAGE")
        msg_list = None
        if msg_data:
            if isinstance(msg_data, list):
                msg_list = msg_data
            else:
                msg_list = [msg_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            customer_error_messages=msg_list,
        )
