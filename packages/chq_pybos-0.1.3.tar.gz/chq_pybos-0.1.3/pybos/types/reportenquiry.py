"""
Type definitions for ReportEnquiry.

This module provides structured classes for report operations.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from .common import Error, BaseDateFilter, PageRequest, PageResponse


# Request Classes
@dataclass
class ReadSaleRevenueRequest:
    """Request for ReadSaleRevenue operation.
    
    Based on ReportEnquiry.xsd READSALEREVENUEREQ type.
    
    Attributes:
        date_from: Date from
        date_to: Date to
        site_ak: Site AK (optional)
        workstation_ak: Workstation AK (optional)
        product_type: Product type (optional)
    """
    
    date_from: str  # xs:date
    date_to: str  # xs:date
    site_ak: Optional[str] = None
    workstation_ak: Optional[str] = None
    product_type: Optional[int] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {"DATEFROM": self.date_from, "DATETO": self.date_to}
        if self.site_ak is not None:
            result["SITEAK"] = self.site_ak
        if self.workstation_ak is not None:
            result["WORKSTATIONAK"] = self.workstation_ak
        if self.product_type is not None:
            result["PRODUCTTYPE"] = self.product_type
        return result


@dataclass
class SearchReportRequest:
    """Request for SearchReport operation.
    
    Based on ReportEnquiry.xsd SEARCHREPORTREQ type.
    
    Attributes:
        report_filter_list: Report filter list (optional)
        dmg_category_ak: DMG category AK (optional)
        context_type: Context type (optional)
        page_req: Page request (optional)
    """
    
    report_filter_list: Optional[List[str]] = None
    dmg_category_ak: Optional[str] = None
    context_type: Optional[int] = None
    page_req: Optional[PageRequest] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {}
        if self.report_filter_list is not None:
            result["REPORTFILTERLIST"] = {
                "REPORTFILTERITEM": [{"AK": ak} for ak in self.report_filter_list]
            }
        if self.dmg_category_ak is not None:
            result["DMGCATEGORYAK"] = self.dmg_category_ak
        if self.context_type is not None:
            result["CONTEXTTYPE"] = self.context_type
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        return result


@dataclass
class PrintReservationConfirmRequest:
    """Request for PrintReservationConfirm operation.
    
    Based on ReportEnquiry.xsd PRINTRESERVATIONCONFIRMREQ type.
    
    Attributes:
        report_ak: Report AK
        output_type: Output type (PDF or EXCEL)
        sale_ak: Sale AK
    """
    
    report_ak: str
    output_type: Dict[str, bool]  # OUTPUTTYPE: PDF or EXCEL
    sale_ak: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "REPORTAK": self.report_ak,
            "OUTPUTTYPE": self.output_type,
            "PARAMETER": {"SALEAK": self.sale_ak},
        }


@dataclass
class PrintAccountReportRequest:
    """Request for PrintAccountReport operation.
    
    Based on ReportEnquiry.xsd PRINTACCOUNTREPORTREQ type.
    
    Attributes:
        report_ak: Report AK
        output_type: Output type (PDF or EXCEL)
        account_ak: Account AK
        date_filter: Date filter (optional)
    """
    
    report_ak: str
    output_type: Dict[str, bool]  # OUTPUTTYPE: PDF or EXCEL
    account_ak: str
    date_filter: Optional[BaseDateFilter] = None
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "REPORTAK": self.report_ak,
            "OUTPUTTYPE": self.output_type,
            "PARAMETER": {"ACCOUNTAK": self.account_ak},
        }
        if self.date_filter is not None:
            result["PARAMETER"]["DATEFILTER"] = self.date_filter.to_dict()
        return result


@dataclass
class PrintReportRequest:
    """Request for PrintReport operation.
    
    Based on ReportEnquiry.xsd PRINTREPORTREQ type.
    
    Attributes:
        report_ak: Report AK
        output_type: Output type (PDF or EXCEL)
        parameter_list: Parameter list
    """
    
    report_ak: str
    output_type: Dict[str, bool]  # OUTPUTTYPE: PDF or EXCEL
    parameter_list: List[Dict[str, Any]]  # PARAMETERLISTTYPE
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "REPORTAK": self.report_ak,
            "OUTPUTTYPE": self.output_type,
            "PARAMETERLIST": {"PARAMETERITEM": self.parameter_list},
        }


@dataclass
class ReadReportByAKRequest:
    """Request for ReadReportByAK operation.
    
    Based on ReportEnquiry.xsd READREPORTBYAKREQ type.
    
    Attributes:
        ak: Report AK
    """
    
    ak: str
    
    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {"AK": self.ak}


# Response Classes
@dataclass
class ReadSaleRevenueResponse:
    """Response for ReadSaleRevenue operation.
    
    Based on ReportEnquiry.xsd READSALEREVENUERESP type.
    
    Attributes:
        error: Error information
        request: Request information
        site_list: Site list
        total: Total revenue
    """
    
    error: Error
    request: Dict[str, str]
    site_list: List[Dict[str, Any]]
    total: Dict[str, Any]  # SALEREVENUE type
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadSaleRevenueResponse":
        """Create ReadSaleRevenueResponse from API response dictionary."""
        site_data = data.get("SITELIST", {}).get("SITE")
        site_list = []
        if site_data:
            if isinstance(site_data, list):
                site_list = site_data
            else:
                site_list = [site_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            request=data.get("REQUEST", {}),
            site_list=site_list,
            total=data.get("TOTAL", {}),
        )


@dataclass
class SearchReportResponse:
    """Response for SearchReport operation.
    
    Based on ReportEnquiry.xsd SEARCHREPORTRESP type.
    
    Attributes:
        error: Error information
        report_item_list: List of report items
        page_resp: Page response
    """
    
    error: Error
    report_item_list: List[Dict[str, Any]]
    page_resp: PageResponse
    
    @classmethod
    def from_dict(cls, data: dict) -> "SearchReportResponse":
        """Create SearchReportResponse from API response dictionary."""
        report_data = data.get("REPORTITEMLIST", {}).get("REPORTITEM")
        report_list = []
        if report_data:
            if isinstance(report_data, list):
                report_list = report_data
            else:
                report_list = [report_data]
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            report_item_list=report_list,
            page_resp=PageResponse.from_dict(data.get("PAGERESP", {})),
        )


@dataclass
class PrintReservationConfirmResponse:
    """Response for PrintReservationConfirm operation.
    
    Based on ReportEnquiry.xsd PRINTRESERVATIONCONFIRMRESP type.
    
    Attributes:
        error: Error information
        output: Output (PDF or EXCEL hexBinary)
    """
    
    error: Error
    output: Dict[str, bytes]  # OUTPUT: PDF or EXCEL
    
    @classmethod
    def from_dict(cls, data: dict) -> "PrintReservationConfirmResponse":
        """Create PrintReservationConfirmResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            output=data.get("OUTPUT", {}),
        )


@dataclass
class PrintAccountReportResponse:
    """Response for PrintAccountReport operation.
    
    Based on ReportEnquiry.xsd PRINTACCOUNTREPORTRESP type.
    
    Attributes:
        error: Error information
        output: Output (PDF or EXCEL hexBinary)
    """
    
    error: Error
    output: Dict[str, bytes]  # OUTPUT: PDF or EXCEL
    
    @classmethod
    def from_dict(cls, data: dict) -> "PrintAccountReportResponse":
        """Create PrintAccountReportResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            output=data.get("OUTPUT", {}),
        )


@dataclass
class PrintReportResponse:
    """Response for PrintReport operation.
    
    Based on ReportEnquiry.xsd PRINTREPORTRESP type.
    
    Attributes:
        error: Error information
        output: Output (PDF or EXCEL hexBinary)
    """
    
    error: Error
    output: Dict[str, bytes]  # OUTPUT: PDF or EXCEL
    
    @classmethod
    def from_dict(cls, data: dict) -> "PrintReportResponse":
        """Create PrintReportResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            output=data.get("OUTPUT", {}),
        )


@dataclass
class ReadReportByAKResponse:
    """Response for ReadReportByAK operation.
    
    Based on ReportEnquiry.xsd READREPORTBYAKRESP type.
    
    Attributes:
        error: Error information
        report_item: Report item with parameters
    """
    
    error: Error
    report_item: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> "ReadReportByAKResponse":
        """Create ReadReportByAKResponse from API response dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {})),
            report_item=data.get("REPORTITEM", {}),
        )
