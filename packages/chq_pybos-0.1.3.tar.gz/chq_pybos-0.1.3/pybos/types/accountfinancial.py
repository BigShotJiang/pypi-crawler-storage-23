"""
Account financial-related data types for the BOS API.

This module provides structured classes for account financial operations,
including credit management, payment processing, and financial configuration.
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from enum import IntEnum
from .common import Error, BasicInfo, BaseDateFilter, PageRequest, PageResponse


class CreditStatus(IntEnum):
    """Credit status enumeration.

    Based on AccountFinancial.xsd BASECREDITSTATUSType.
    """

    OPENED = 1
    INVOICED = 2
    PAID = 3
    RECONCILED = 4
    WRITTEN_OFF = 5


@dataclass
class PaymentInfo:
    """Payment information structure.

    Based on AccountFinancial.xsd PAYMENT structure within BASECREDITITEM.

    Attributes:
        type: Payment type
        description: Payment description
        code: Payment code
    """

    type: int
    description: str
    code: str

    @classmethod
    def from_dict(cls, data: dict) -> "PaymentInfo":
        """Create PaymentInfo from API response dictionary."""
        return cls(
            type=data.get("TYPE", 0),
            description=data.get("DESCRIPTION", ""),
            code=data.get("CODE", ""),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "TYPE": self.type,
            "DESCRIPTION": self.description,
            "CODE": self.code,
        }


@dataclass
class PriceBase:
    """Price base structure.

    Based on APICommon.xsd PRICEBASE type.

    Attributes:
        currency: Currency code
        net: Net amount
        tax: Tax amount
        gross: Gross amount
        recharge: Recharge amount (optional)
        printed: Printed amount (optional)
        rounding: Rounding amount (optional)
        tax_list: List of taxes (optional)
        foreign_currency_list: Foreign currency list (optional)
    """

    currency: str
    net: float
    tax: float
    gross: float
    recharge: Optional[float] = None
    printed: Optional[float] = None
    rounding: Optional[float] = None
    tax_list: Optional[List[Dict[str, Any]]] = None
    foreign_currency_list: Optional[List[Dict[str, Any]]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "PriceBase":
        """Create PriceBase from API response dictionary."""
        return cls(
            currency=data.get("CURRENCY", ""),
            net=data.get("NET", 0.0),
            tax=data.get("TAX", 0.0),
            gross=data.get("GROSS", 0.0),
            recharge=data.get("RECHARGE"),
            printed=data.get("PRINTED"),
            rounding=data.get("ROUNDING"),
            tax_list=data.get("TAXLIST"),
            foreign_currency_list=data.get("FOREIGNCURRENCYLIST"),
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "CURRENCY": self.currency,
            "NET": self.net,
            "TAX": self.tax,
            "GROSS": self.gross,
        }
        if self.recharge is not None:
            result["RECHARGE"] = self.recharge
        if self.printed is not None:
            result["PRINTED"] = self.printed
        if self.rounding is not None:
            result["ROUNDING"] = self.rounding
        if self.tax_list is not None:
            result["TAXLIST"] = self.tax_list
        if self.foreign_currency_list is not None:
            result["FOREIGNCURRENCYLIST"] = self.foreign_currency_list
        return result


@dataclass
class CreditItem:
    """Credit item structure.

    Based on AccountFinancial.xsd BASECREDITITEM type.

    Attributes:
        credit_ak: Credit AK
        description: Credit description
        credit_type: Credit type
        date: Credit date
        payment: Payment information
        amount: Credit amount
        due_date: Due date (optional)
        status: Credit status
        settle_sale: Settle sale information (optional)
        original_sale: Original sale information (optional)
    """

    credit_ak: str
    description: str
    credit_type: int
    date: str
    payment: PaymentInfo
    amount: PriceBase
    due_date: Optional[str] = None
    status: CreditStatus = CreditStatus.OPENED
    settle_sale: Optional[Dict[str, Any]] = None
    original_sale: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "CreditItem":
        """Create CreditItem from API response dictionary."""
        credit_data = data.get("CREDIT", {})
        return cls(
            credit_ak=credit_data.get("CREDITAK", ""),
            description=credit_data.get("DESCRIPTION", ""),
            credit_type=credit_data.get("CREDITTYPE", 0),
            date=credit_data.get("DATE", ""),
            payment=PaymentInfo.from_dict(credit_data.get("PAYMENT", {})),
            amount=PriceBase.from_dict(credit_data.get("AMOUNT", {})),
            due_date=credit_data.get("DUEDATE"),
            status=CreditStatus(credit_data.get("STATUS", 1)),
            settle_sale=data.get("SETTLESALE"),
            original_sale=data.get("ORIGINALSALE"),
        )


@dataclass
class CreditListLight:
    """Light credit list structure.

    Based on AccountFinancial.xsd BASECREDITLISTLIGHT type.

    Attributes:
        credits: List of credit AKs
    """

    credits: List[str]

    @classmethod
    def from_dict(cls, data: dict) -> "CreditListLight":
        """Create CreditListLight from API response dictionary."""
        credit_list = data.get("CREDITLIST", {}).get("CREDIT", [])
        if not isinstance(credit_list, list):
            credit_list = [credit_list] if credit_list else []

        return cls(
            credits=[credit.get("AK", "") for credit in credit_list if credit.get("AK")]
        )

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        return {
            "CREDITLIST": {"CREDIT": [{"AK": credit_ak} for credit_ak in self.credits]}
        }


# Request Classes
@dataclass
class UpdateFinancialConfigRequest:
    """Structured request for UpdateFinancialConfig operation.

    Based on AccountFinancial.xsd UPDATEFINANCIALCONFIGREQ structure.

    Attributes:
        update_account_ak: Account AK to update
        update_credit_info: Credit information to update (optional)
        update_price_list: Price list to update (optional)
        update_billing_account: Billing account to update (optional)
        update_tax_info: Tax information to update (optional)
    """

    update_account_ak: str
    update_credit_info: Optional[Dict[str, Any]] = None
    update_price_list: Optional[Dict[str, Any]] = None
    update_billing_account: Optional[Dict[str, Any]] = None
    update_tax_info: Optional[Dict[str, Any]] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "UPDATEACCOUNTAK": self.update_account_ak,
        }
        if self.update_credit_info is not None:
            result["UPDATECREDITINFO"] = self.update_credit_info
        if self.update_price_list is not None:
            result["UPDATEPRICELIST"] = self.update_price_list
        if self.update_billing_account is not None:
            result["UPDATEBILLINGACCOUNT"] = self.update_billing_account
        if self.update_tax_info is not None:
            result["UPDATETAXINFO"] = self.update_tax_info
        return result


@dataclass
class AdvancePaymentRequest:
    """Structured request for AdvancePayment operation.

    Based on AccountFinancial.xsd ADVANCEPAYMENTREQ structure.

    Attributes:
        account_ak: Account AK
        amount: Payment amount
        note: Payment note (optional)
    """

    account_ak: str
    amount: float
    note: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "ACCOUNTAK": self.account_ak,
            "AMOUNT": self.amount,
        }
        if self.note is not None:
            result["NOTE"] = self.note
        return result


@dataclass
class SearchCreditRequest:
    """Structured request for SearchCredit operation.

    Based on AccountFinancial.xsd SEARCHCREDITREQ structure.

    Attributes:
        sale_date: Sale date filter
        due_date: Due date filter (optional)
        status: Credit status filter (optional)
        account_ak: Account AK
        reservation_code: Reservation code (optional)
        external_reservation_code: External reservation code (optional)
        visit_date: Visit date filter (optional)
        page_req: Pagination request (optional)
        include_credit_recharge: Include credit recharge flag (optional)
    """

    sale_date: BaseDateFilter
    due_date: Optional[BaseDateFilter] = None
    status: Optional[CreditStatus] = None
    account_ak: str = ""
    reservation_code: Optional[str] = None
    external_reservation_code: Optional[str] = None
    visit_date: Optional[BaseDateFilter] = None
    page_req: Optional[PageRequest] = None
    include_credit_recharge: Optional[int] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "SALEDATE": self.sale_date.to_dict(),
            "ACCOUNTAK": self.account_ak,
        }
        if self.due_date is not None:
            result["DUEDATE"] = self.due_date.to_dict()
        if self.status is not None:
            result["STATUS"] = self.status.value
        if self.reservation_code is not None:
            result["RESERVATIONCODE"] = self.reservation_code
        if self.external_reservation_code is not None:
            result["EXTERNALRESERVATIONCODE"] = self.external_reservation_code
        if self.visit_date is not None:
            result["VISITDATE"] = self.visit_date.to_dict()
        if self.page_req is not None:
            result["PAGEREQ"] = self.page_req.to_dict()
        if self.include_credit_recharge is not None:
            result["INCLUDECREDITRECHARGE"] = self.include_credit_recharge
        return result


@dataclass
class CreditSettlementRequest:
    """Structured request for CreditSettlement operation.

    Based on AccountFinancial.xsd CREDITSETTLEMENTREQ structure.

    Attributes:
        credit_list: List of credits to settle
        payment_info_list: Payment information list
        note: Settlement note (optional)
    """

    credit_list: CreditListLight
    payment_info_list: Dict[str, Any]  # PAYMENTLISTBASE type
    note: Optional[str] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "CREDITLIST": self.credit_list.to_dict(),
            "PAYMENTINFOLIST": self.payment_info_list,
        }
        if self.note is not None:
            result["NOTE"] = self.note
        return result


@dataclass
class ChangeCreditDetailsRequest:
    """Structured request for ChangeCreditDetails operation.

    Based on AccountFinancial.xsd CHANGECREDITDETAILSREQ structure.

    Attributes:
        credit_list: List of credits to change
        due_date: New due date (optional)
        status: New status (optional)
    """

    credit_list: CreditListLight
    due_date: Optional[str] = None
    status: Optional[int] = None

    def to_dict(self) -> dict:
        """Convert to dictionary format expected by the API."""
        result = {
            "CREDITLIST": self.credit_list.to_dict(),
        }
        if self.due_date is not None:
            result["DUEDATE"] = self.due_date
        if self.status is not None:
            result["STATUS"] = self.status
        return result


# Response Classes
@dataclass
class UpdateFinancialConfigResponse:
    """Response for UpdateFinancialConfig operation.

    Based on AccountFinancial.xsd UPDATEFINANCIALCONFIGRESP structure.

    Attributes:
        error: Error information
        account: Updated account financial information (optional)
    """

    error: Error
    account: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "UpdateFinancialConfigResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            account=data.get("ACCOUNT"),
        )


@dataclass
class AdvancePaymentResponse:
    """Response for AdvancePayment operation.

    Based on AccountFinancial.xsd ADVANCEPAYMENTRESP structure.

    Attributes:
        error: Error information
        order_ak: Order AK (optional)
        order_id: Order ID (optional)
        invoice: Invoice information (optional)
        total: Total amount (optional)
        sale_type: Sale type (optional)
        order_flag: Order flag (optional)
        date: Order date (optional)
        fiscal_date: Fiscal date (optional)
        serial: Order serial (optional)
        owner: Order owner (optional)
        payment_list: Payment list (optional)
        language: Language (optional)
        encoding: Encoding (optional)
        note_list: Note list (optional)
        id: Order ID (optional)
        reservation_ak: Reservation AK (optional)
        logged_account: Logged account (optional)
        billing_account: Billing account (optional)
        promotion_applied_list: Promotion applied list (optional)
        status_code: Status code (optional)
        workstation: Workstation (optional)
        external_reservation_code: External reservation code (optional)
        invoice_info: Invoice info (optional)
        pick_up_date: Pick up date (optional)
    """

    error: Error
    order_ak: Optional[str] = None
    order_id: Optional[int] = None
    invoice: Optional[Dict[str, Any]] = None
    total: Optional[Dict[str, Any]] = None
    sale_type: Optional[int] = None
    order_flag: Optional[Dict[str, Any]] = None
    date: Optional[str] = None
    fiscal_date: Optional[str] = None
    serial: Optional[int] = None
    owner: Optional[Dict[str, Any]] = None
    payment_list: Optional[Dict[str, Any]] = None
    language: Optional[Dict[str, Any]] = None
    encoding: Optional[Dict[str, Any]] = None
    note_list: Optional[Dict[str, Any]] = None
    id: Optional[int] = None
    reservation_ak: Optional[str] = None
    logged_account: Optional[Dict[str, Any]] = None
    billing_account: Optional[Dict[str, Any]] = None
    promotion_applied_list: Optional[Dict[str, Any]] = None
    status_code: Optional[int] = None
    workstation: Optional[Dict[str, Any]] = None
    external_reservation_code: Optional[str] = None
    invoice_info: Optional[Dict[str, Any]] = None
    pick_up_date: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "AdvancePaymentResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            order_ak=data.get("ORDERAK"),
            order_id=data.get("ORDERID"),
            invoice=data.get("INVOICE"),
            total=data.get("TOTAL"),
            sale_type=data.get("SALETYPE"),
            order_flag=data.get("ORDERFLAG"),
            date=data.get("DATE"),
            fiscal_date=data.get("FISCALDATE"),
            serial=data.get("SERIAL"),
            owner=data.get("OWNER"),
            payment_list=data.get("PAYMENTLIST"),
            language=data.get("LANGUAGE"),
            encoding=data.get("ENCODING"),
            note_list=data.get("NOTELIST"),
            id=data.get("ID"),
            reservation_ak=data.get("RESERVATIONAK"),
            logged_account=data.get("LOGGEDACCOUNT"),
            billing_account=data.get("BILLINGACCOUNT"),
            promotion_applied_list=data.get("PROMOTIONAPPLIEDLIST"),
            status_code=data.get("STATUSCODE"),
            workstation=data.get("WORKSTATION"),
            external_reservation_code=data.get("EXTERNALRESERVATIONCODE"),
            invoice_info=data.get("INVOICE"),
            pick_up_date=data.get("PICKUPDATE"),
        )


@dataclass
class SearchCreditResponse:
    """Response for SearchCredit operation.

    Based on AccountFinancial.xsd SEARCHCREDITRESP structure.

    Attributes:
        error: Error information
        credit_list: List of credit items
        page_response: Pagination response information
    """

    error: Error
    credit_list: List[CreditItem]
    page_response: PageResponse

    @classmethod
    def from_dict(cls, data: dict) -> "SearchCreditResponse":
        """Create response from API dictionary."""
        credit_list_data = data.get("CREDITLIST", {}).get("CREDITITEM", [])
        if not isinstance(credit_list_data, list):
            credit_list_data = [credit_list_data] if credit_list_data else []

        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            credit_list=[CreditItem.from_dict(credit) for credit in credit_list_data],
            page_response=PageResponse.from_dict(data.get("PAGERESP", {})),
        )


@dataclass
class ActivateFinancialResponse:
    """Response for ActivateFinancial operation.

    Based on AccountFinancial.xsd ACTIVATEFINANCIALRESP structure.

    Attributes:
        error: Error information
        account: Activated account information (optional)
    """

    error: Error
    account: Optional[BasicInfo] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ActivateFinancialResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            account=(
                BasicInfo.from_dict(data.get("ACCOUNT", {}), "ACCOUNTAK", "ACCOUNTID")
                if data.get("ACCOUNT")
                else None
            ),
        )


@dataclass
class CreditSettlementResponse:
    """Response for CreditSettlement operation.

    Based on AccountFinancial.xsd CREDITSETTLEMENTRESP structure.

    Attributes:
        error: Error information
        sale: Sale information (optional)
    """

    error: Error
    sale: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "CreditSettlementResponse":
        """Create response from API dictionary."""
        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            sale=data.get("SALE"),
        )


@dataclass
class ChangeCreditDetailsResponse:
    """Response for ChangeCreditDetails operation.

    Based on AccountFinancial.xsd CHANGECREDITDETAILSRESP structure.

    Attributes:
        error: Error information
        credit_list: Updated credit list
    """

    error: Error
    credit_list: List[CreditItem]

    @classmethod
    def from_dict(cls, data: dict) -> "ChangeCreditDetailsResponse":
        """Create response from API dictionary."""
        credit_list_data = data.get("CREDITLIST", {}).get("CREDITITEM", [])
        if not isinstance(credit_list_data, list):
            credit_list_data = [credit_list_data] if credit_list_data else []

        return cls(
            error=Error.from_dict(data.get("ERROR", {"CODE": 200})),
            credit_list=[CreditItem.from_dict(credit) for credit in credit_list_data],
        )
