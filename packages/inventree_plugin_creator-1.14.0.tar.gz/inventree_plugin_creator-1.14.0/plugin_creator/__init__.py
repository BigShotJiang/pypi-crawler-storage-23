# -*- coding: utf-8 -*-

PLUGIN_CREATOR_VERSION = "1.14.0"
