"""Diagrid Core - Shared auth and Catalyst API client."""
