
## Value network (wip)

Exploration into some new research surrounding value networks

## Citations

```bibtex
@article{Farebrother2024StopRT,
    title   = {Stop Regressing: Training Value Functions via Classification for Scalable Deep RL},
    author  = {Jesse Farebrother and Jordi Orbay and Quan Ho Vuong and Adrien Ali Taiga and Yevgen Chebotar and Ted Xiao and Alex Irpan and Sergey Levine and Pablo Samuel Castro and Aleksandra Faust and Aviral Kumar and Rishabh Agarwal},
    journal = {ArXiv},
    year   = {2024},
    volume = {abs/2403.03950},
    url    = {https://api.semanticscholar.org/CorpusID:268253088}
}
```

```bibtex
@misc{lee2025banelexplorationposteriorsgenerative,
    title    = {BaNEL: Exploration Posteriors for Generative Modeling Using Only Negative Rewards}, 
    author   = {Sangyun Lee and Brandon Amos and Giulia Fanti},
    year     = {2025},
    eprint   = {2510.09596},
    archivePrefix = {arXiv},
    primaryClass = {cs.LG},
    url      = {https://arxiv.org/abs/2510.09596}, 
}
```

```bibtex
@misc{ma2024visionlanguagemodelsincontext,
    title   = {Vision Language Models are In-Context Value Learners}, 
    author  = {Yecheng Jason Ma and Joey Hejna and Ayzaan Wahid and Chuyuan Fu and Dhruv Shah and Jacky Liang and Zhuo Xu and Sean Kirmani and Peng Xu and Danny Driess and Ted Xiao and Jonathan Tompson and Osbert Bastani and Dinesh Jayaraman and Wenhao Yu and Tingnan Zhang and Dorsa Sadigh and Fei Xia},
    year    = {2024},
    eprint  = {2411.04549},
    archivePrefix = {arXiv},
    primaryClass = {cs.RO},
    url     = {https://arxiv.org/abs/2411.04549}, 
}
```

```bibtex
@misc{yang2026riseselfimprovingrobotpolicy,
    title   = {RISE: Self-Improving Robot Policy with Compositional World Model}, 
    author  = {Jiazhi Yang and Kunyang Lin and Jinwei Li and Wencong Zhang and Tianwei Lin and Longyan Wu and Zhizhong Su and Hao Zhao and Ya-Qin Zhang and Li Chen and Ping Luo and Xiangyu Yue and Hongyang Li},
    year    = {2026},
    eprint  = {2602.11075},
    archivePrefix = {arXiv},
    primaryClass = {cs.RO},
    url     = {https://arxiv.org/abs/2602.11075}, 
}
```
