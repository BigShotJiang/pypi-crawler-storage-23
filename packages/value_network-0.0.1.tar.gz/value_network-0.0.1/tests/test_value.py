
def test_value():
    assert True
