"""
sahim-django-common - Django utilities and common components by SahimCo.

https://github.com/sahimco/sahim-django-common
"""

__version__ = "0.1.0"
