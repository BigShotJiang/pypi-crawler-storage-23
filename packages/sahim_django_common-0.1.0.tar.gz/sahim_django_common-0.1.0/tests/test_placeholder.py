"""Placeholder test until real tests are added."""


def test_placeholder():
    """Ensure pytest runs successfully."""
    assert True
