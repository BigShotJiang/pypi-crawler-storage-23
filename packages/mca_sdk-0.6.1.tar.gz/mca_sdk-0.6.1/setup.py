"""Setup configuration for MCA SDK."""
from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="mca-sdk",
    version="0.6.1",
    description="Model Collector Agent SDK for OpenTelemetry monitoring",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(include=["mca_sdk", "mca_sdk.*"]),
    python_requires=">=3.10",
    install_requires=[
        "opentelemetry-api>=1.39.0",
        "opentelemetry-sdk>=1.39.0",
        "opentelemetry-exporter-otlp-proto-http>=1.39.0",
        "protobuf>=5.0,<6.0",
        "pyyaml>=6.0",
        "pybreaker>=1.4.1",
        "cryptography>=46.0.0",
        "requests>=2.31.0",
    ],
    extras_require={
        "genai": [
            "litellm>=1.17.0",
        ],
        "vendor": [
            "flask>=3.0.0",
        ],
        "prometheus": [
            "opentelemetry-exporter-prometheus>=0.48b0",
        ],
        "gcp-auth": [
            "google-auth>=2.27.0,<3.0.0",
        ],
        "gcp-secrets": [
            "google-cloud-secret-manager>=2.26.0,<3.0.0",
        ],
        "gcp-trace": [
            "google-cloud-trace>=1.11.0,<2.0.0",
            "google-auth>=2.27.0,<3.0.0",
        ],
        "gcp-logging": [
            "google-cloud-logging>=3.13.0,<4.0.0",
        ],
        "gcp": [
            "google-auth>=2.27.0,<3.0.0",
            "google-cloud-secret-manager>=2.26.0,<3.0.0",
            "google-cloud-logging>=3.13.0,<4.0.0",
            "google-cloud-trace>=1.11.0,<2.0.0",
        ],
        "test": [
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "pytest-mock>=3.12.0",
            "pytest-asyncio>=0.23.0",
            "opentelemetry-exporter-prometheus>=0.48b0",
        ],
        "dev": [
            "black>=24.0.0",
            "mypy>=1.8.0",
            "ruff>=0.1.0",
            "pytest>=7.4.0",
            "pytest-cov>=4.1.0",
            "pytest-mock>=3.12.0",
            "pytest-asyncio>=0.23.0",
            "opentelemetry-exporter-prometheus>=0.48b0",
        ],
        "all": [
            "litellm>=1.17.0",
            "flask>=3.0.0",
            "google-auth>=2.27.0",
            "google-cloud-secret-manager>=2.26.0",
            "google-cloud-logging>=3.13.0,<4.0.0",
            "google-cloud-trace>=1.11.0,<2.0.0",
            "opentelemetry-exporter-prometheus>=0.48b0",
        ],
    },
)
