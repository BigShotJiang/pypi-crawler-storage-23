"""
Wrapper for queued telemetry items with retry attempt tracking.

This module provides QueuedItem, a wrapper class that tracks per-item retry
attempts across worker loop iterations to prevent poisoned message infinite loops.
"""

from dataclasses import dataclass, field
from typing import Any, Optional
from datetime import datetime, timezone


@dataclass
class QueuedItem:
    """
    Wrapper for queued telemetry with retry tracking.

    Prevents poisoned message infinite retry loops by tracking how many times
    an item has been dequeued and re-queued. After max_queue_retry_attempts,
    the item is dropped or moved to dead letter queue.

    Attributes:
        data: The actual telemetry data (MetricsData, LogData, or SpanData)
        attempt_count: Number of times this item has been dequeued for export
        first_queued_at: Timestamp when item was first queued
        last_error: Last error message from failed export attempt
    """

    data: Any
    attempt_count: int = 0
    first_queued_at: Optional[datetime] = field(default=None)
    last_error: Optional[str] = None

    def __post_init__(self) -> None:
        """Set first_queued_at timestamp if not already set."""
        if self.first_queued_at is None:
            self.first_queued_at = datetime.now(timezone.utc)
