"""Resilience patterns for MCA SDK.

This module provides resilience patterns including circuit breakers,
retry policies, and failure handling mechanisms to ensure robust
telemetry collection even when the collector is temporarily unavailable.
"""

from .circuit_breaker import CircuitBreakerRetryPolicy

__all__ = ["CircuitBreakerRetryPolicy"]
