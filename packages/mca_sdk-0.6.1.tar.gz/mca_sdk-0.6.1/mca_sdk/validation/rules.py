"""Validation rules for resource attributes based on model taxonomy."""

import copy
from typing import Dict, List, Tuple

# Shared attribute name constants to prevent typos and enable refactoring
ATTR_SERVICE_NAME = "service.name"
ATTR_MODEL_ID = "model.id"
ATTR_MODEL_VERSION = "model.version"
ATTR_MODEL_TYPE = "model.type"
ATTR_TEAM_NAME = "team.name"
ATTR_LLM_PROVIDER = "llm.provider"
ATTR_LLM_MODEL = "llm.model"
ATTR_VENDOR_NAME = "vendor.name"
ATTR_SERVICE_VERSION = "service.version"
ATTR_DEPLOYMENT_ENV = "deployment.environment"

# Common optional attribute sets (functions to prevent shared mutable list issues)


def _get_common_optional() -> List[str]:
    """Return common optional attributes (new list each time to prevent mutation)."""
    return [ATTR_SERVICE_VERSION, ATTR_DEPLOYMENT_ENV]


def _get_genai_optional() -> List[str]:
    """Return GenAI optional attributes (new list each time to prevent mutation)."""
    return [ATTR_MODEL_ID, ATTR_MODEL_VERSION, ATTR_SERVICE_VERSION, ATTR_DEPLOYMENT_ENV]


# Validation rules matrix keyed by (model_category, model_type)
# "vendor" category uses a wildcard "*" for model_type
VALIDATION_RULES: Dict[Tuple[str, str], Dict[str, List[str]]] = {
    ("internal", "regression"): {
        "required": [ATTR_SERVICE_NAME, ATTR_MODEL_ID, ATTR_MODEL_VERSION, ATTR_TEAM_NAME],
        "optional": _get_common_optional(),
    },
    ("internal", "time-series"): {
        "required": [ATTR_SERVICE_NAME, ATTR_MODEL_ID, ATTR_MODEL_VERSION, ATTR_TEAM_NAME],
        "optional": _get_common_optional(),
    },
    ("internal", "classification"): {
        "required": [ATTR_SERVICE_NAME, ATTR_MODEL_ID, ATTR_MODEL_VERSION, ATTR_TEAM_NAME],
        "optional": _get_common_optional(),
    },
    ("internal", "generative"): {
        "required": [ATTR_SERVICE_NAME, ATTR_LLM_PROVIDER, ATTR_LLM_MODEL, ATTR_TEAM_NAME],
        "optional": _get_genai_optional(),
    },
    ("internal", "agentic"): {
        "required": [ATTR_SERVICE_NAME, ATTR_LLM_PROVIDER, ATTR_LLM_MODEL, ATTR_TEAM_NAME],
        "optional": _get_genai_optional(),
    },
    ("vendor", "*"): {  # Applies to all vendor model_types
        "required": [ATTR_SERVICE_NAME, ATTR_VENDOR_NAME, ATTR_TEAM_NAME],
        "optional": [ATTR_MODEL_TYPE, ATTR_SERVICE_VERSION, ATTR_DEPLOYMENT_ENV],
    },
}


def get_validation_rules(model_category: str, model_type: str) -> Dict[str, List[str]]:
    """Get validation rules for given taxonomy.

    Args:
        model_category: High-level category ("internal" or "vendor")
        model_type: Specific model type ("regression", "generative", etc.)

    Returns:
        Deep copy of dictionary with "required" and "optional" attribute lists.
        Returns a new dict to prevent mutation of module-level VALIDATION_RULES.

    Raises:
        ValueError: If no rules exist for the given combination
    """
    # Normalize model_category to lowercase for case-insensitive comparison
    model_category_normalized = model_category.strip().lower()

    if model_category_normalized == "vendor":
        return copy.deepcopy(VALIDATION_RULES[("vendor", "*")])

    key = (model_category_normalized, model_type)
    if key not in VALIDATION_RULES:
        raise ValueError(
            f"No validation rules for model_category={model_category}, model_type={model_type}"
        )

    return copy.deepcopy(VALIDATION_RULES[key])
