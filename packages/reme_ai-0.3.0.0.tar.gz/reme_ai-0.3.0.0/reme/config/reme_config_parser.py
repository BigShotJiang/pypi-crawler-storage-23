"""Configuration parser for ReMe framework."""

from ..core.utils import PydanticConfigParser


class ReMeConfigParser(PydanticConfigParser):
    """Configuration parser for ReMe framework."""
