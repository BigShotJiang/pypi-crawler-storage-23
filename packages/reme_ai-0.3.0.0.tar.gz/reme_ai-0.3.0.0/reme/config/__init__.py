"""config"""

from .reme_config_parser import ReMeConfigParser

__all__ = ["ReMeConfigParser"]
