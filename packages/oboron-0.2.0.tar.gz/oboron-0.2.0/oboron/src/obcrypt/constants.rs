// AES-CBC padding byte
#[cfg(feature = "upbc")]
pub const CBC_PADDING_BYTE: u8 = 0x01;
#[cfg(feature = "upbc")]
pub const AES_BLOCK_SIZE: usize = 16;
