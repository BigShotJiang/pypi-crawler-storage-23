from oboron import generate_key

if __name__ == "__main__":
    print(generate_key())
