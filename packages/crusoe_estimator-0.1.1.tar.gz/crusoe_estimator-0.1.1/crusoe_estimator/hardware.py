"""
Local hardware detection module.

Detects the local GPU (NVIDIA CUDA, Apple MPS, or CPU-only)
and retrieves specifications for performance estimation.
"""

import subprocess
import platform
from dataclasses import dataclass
from typing import Optional, Tuple

from .gpu_database import GPUSpec, match_gpu, KNOWN_GPUS


@dataclass
class LocalHardware:
    """Detected local hardware information."""
    gpu_name: str
    gpu_spec: Optional[GPUSpec]
    device_type: str                # "cuda", "mps", "cpu"
    device_index: int
    driver_version: Optional[str]
    cuda_version: Optional[str]
    gpu_memory_total_mb: Optional[float]
    gpu_memory_used_mb: Optional[float]
    power_draw_watts: Optional[float]
    power_limit_watts: Optional[float]


def detect_gpu() -> LocalHardware:
    """
    Detect the local GPU and return hardware information.
    Supports NVIDIA CUDA, Apple MPS, and CPU fallback.
    """
    # Try NVIDIA CUDA first
    try:
        import torch
        if torch.cuda.is_available():
            return _detect_cuda_gpu()
    except ImportError:
        pass

    # Try Apple MPS
    try:
        import torch
        if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            return _detect_mps_gpu()
    except (ImportError, AttributeError):
        pass

    # CPU fallback
    return _detect_cpu()


def _detect_cuda_gpu(device_index: int = 0) -> LocalHardware:
    """Detect NVIDIA CUDA GPU details."""
    import torch

    gpu_name = torch.cuda.get_device_name(device_index)
    gpu_props = torch.cuda.get_device_properties(device_index)
    total_mem_mb = gpu_props.total_mem / (1024 ** 2)

    # Try to get more details from nvidia-smi
    driver_version = None
    cuda_version = str(torch.version.cuda) if torch.version.cuda else None
    power_draw = None
    power_limit = None
    mem_used = None

    try:
        smi_output = _run_nvidia_smi(device_index)
        if smi_output:
            driver_version = smi_output.get("driver_version")
            power_draw = smi_output.get("power_draw")
            power_limit = smi_output.get("power_limit")
            mem_used = smi_output.get("memory_used")
    except Exception:
        pass

    gpu_spec = match_gpu(gpu_name)

    # If we can't find in database, create a spec from detected info
    if gpu_spec is None:
        gpu_spec = _estimate_spec_from_properties(gpu_name, gpu_props, power_limit)

    return LocalHardware(
        gpu_name=gpu_name,
        gpu_spec=gpu_spec,
        device_type="cuda",
        device_index=device_index,
        driver_version=driver_version,
        cuda_version=cuda_version,
        gpu_memory_total_mb=total_mem_mb,
        gpu_memory_used_mb=mem_used,
        power_draw_watts=power_draw,
        power_limit_watts=power_limit,
    )


def _detect_mps_gpu() -> LocalHardware:
    """Detect Apple Silicon GPU details."""
    chip_name = _detect_apple_chip()
    gpu_spec = match_gpu(chip_name) if chip_name else None

    return LocalHardware(
        gpu_name=chip_name or "Apple Silicon (Unknown)",
        gpu_spec=gpu_spec,
        device_type="mps",
        device_index=0,
        driver_version=None,
        cuda_version=None,
        gpu_memory_total_mb=None,
        gpu_memory_used_mb=None,
        power_draw_watts=gpu_spec.tdp_watts if gpu_spec else 30,
        power_limit_watts=gpu_spec.tdp_watts if gpu_spec else 30,
    )


def _detect_cpu() -> LocalHardware:
    """CPU-only fallback."""
    cpu_name = platform.processor() or "Unknown CPU"

    return LocalHardware(
        gpu_name=f"CPU only ({cpu_name})",
        gpu_spec=None,
        device_type="cpu",
        device_index=-1,
        driver_version=None,
        cuda_version=None,
        gpu_memory_total_mb=None,
        gpu_memory_used_mb=None,
        power_draw_watts=65,  # Typical CPU TDP
        power_limit_watts=65,
    )


def _detect_apple_chip() -> Optional[str]:
    """Detect Apple Silicon chip model."""
    try:
        result = subprocess.run(
            ["sysctl", "-n", "machdep.cpu.brand_string"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            brand = result.stdout.strip()
            if "Apple" in brand:
                return brand
    except Exception:
        pass

    # Fallback: try system_profiler
    try:
        result = subprocess.run(
            ["system_profiler", "SPHardwareDataType"],
            capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            for line in result.stdout.split("\n"):
                if "Chip" in line or "Processor Name" in line:
                    chip = line.split(":")[-1].strip()
                    return f"Apple {chip}" if not chip.startswith("Apple") else chip
    except Exception:
        pass

    return None


def _run_nvidia_smi(device_index: int = 0) -> Optional[dict]:
    """Run nvidia-smi and parse output."""
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                f"--id={device_index}",
                "--query-gpu=driver_version,power.draw,power.limit,memory.used",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            parts = [p.strip() for p in result.stdout.strip().split(",")]
            if len(parts) >= 4:
                return {
                    "driver_version": parts[0],
                    "power_draw": float(parts[1]) if parts[1] != "[N/A]" else None,
                    "power_limit": float(parts[2]) if parts[2] != "[N/A]" else None,
                    "memory_used": float(parts[3]) if parts[3] != "[N/A]" else None,
                }
    except (FileNotFoundError, Exception):
        pass
    return None


def _estimate_spec_from_properties(gpu_name: str, gpu_props, power_limit: Optional[float]) -> GPUSpec:
    """
    Estimate GPU specs from torch.cuda device properties when
    the GPU is not found in our database.
    """
    # Rough TFLOPS estimation based on CUDA cores and clock speed
    # This is approximate but better than nothing
    sm_count = gpu_props.multi_processor_count

    # Estimate FP16 tensor cores TFLOPS based on architecture
    major, minor = gpu_props.major, gpu_props.minor
    clock_ghz = gpu_props.clock_rate / 1e6  # Convert kHz to GHz

    if major >= 9:  # Hopper+
        fp16_ops_per_sm = 512
    elif major >= 8:  # Ampere/Ada
        fp16_ops_per_sm = 256
    elif major >= 7:  # Volta/Turing
        fp16_ops_per_sm = 128
    else:
        fp16_ops_per_sm = 64

    estimated_tflops = sm_count * fp16_ops_per_sm * clock_ghz * 2 / 1000
    memory_gb = gpu_props.total_mem / (1024 ** 3)

    arch_names = {9: "Hopper", 8: "Ampere/Ada", 7: "Volta/Turing", 6: "Pascal"}
    arch = arch_names.get(major, f"SM {major}.{minor}")

    return GPUSpec(
        name=gpu_name,
        fp16_tflops=estimated_tflops,
        memory_gb=memory_gb,
        memory_bandwidth_tbps=0.5,  # Conservative estimate
        tdp_watts=power_limit or 250,
        architecture=arch,
    )


def get_power_draw(device_index: int = 0) -> Optional[float]:
    """Get current GPU power draw in watts via nvidia-smi."""
    smi = _run_nvidia_smi(device_index)
    if smi:
        return smi.get("power_draw")

    # Try pynvml
    try:
        import pynvml
        pynvml.nvmlInit()
        handle = pynvml.nvmlDeviceGetHandleByIndex(device_index)
        power_mw = pynvml.nvmlDeviceGetPowerUsage(handle)
        return power_mw / 1000.0  # Convert mW to W
    except Exception:
        pass

    return None


def get_gpu_utilization(device_index: int = 0) -> Optional[Tuple[float, float]]:
    """
    Get GPU utilization (gpu_util%, memory_util%) via nvidia-smi.
    Returns (gpu_utilization, memory_utilization) as percentages.
    """
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                f"--id={device_index}",
                "--query-gpu=utilization.gpu,utilization.memory",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            parts = [p.strip() for p in result.stdout.strip().split(",")]
            if len(parts) >= 2:
                return float(parts[0]), float(parts[1])
    except Exception:
        pass
    return None
