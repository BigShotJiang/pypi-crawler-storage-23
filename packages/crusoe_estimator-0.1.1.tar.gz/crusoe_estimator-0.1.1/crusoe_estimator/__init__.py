"""
crusoe-estimator: PyTorch Training Cost & Carbon Estimator for Crusoe Cloud

Benchmark your training loop locally, then estimate time, cost, and CO2
savings on Crusoe Cloud GPUs — powered by 100% renewable energy.

Usage:
    from crusoe_estimator import CrusoeEstimator

    estimator = CrusoeEstimator(total_epochs=100, location="HR")

    # Pattern 1: Training loop wrapper
    for epoch in estimator.epochs(sample=3):
        train_one_epoch(model, dataloader)
    estimator.generate_report("report.html")

    # Pattern 2: Decorator
    @estimator.watch(sample_epochs=3)
    def train_epoch():
        ...

    # Pattern 3: Context manager
    with estimator.track():
        for epoch in range(3):
            train_one_epoch(model, dataloader)
    estimator.generate_report("report.html")

    # Pattern 4: Function wrapper
    result = estimator.estimate(train_fn=train_one_epoch, sample_epochs=3)
"""

__version__ = "0.1.0"
__author__ = "HackEurope Team"

from .estimator import (
    CrusoeEstimator,
    CrusoeEstimate,
    EstimationResult,
    EpochMetrics,
)

from .gpu_database import (
    GPUSpec,
    CrusoeGPU,
    KNOWN_GPUS,
    CRUSOE_GPUS,
    get_crusoe_gpus,
    match_gpu,
    list_supported_gpus,
)

from .hardware import (
    LocalHardware,
    detect_gpu,
    get_power_draw,
    get_gpu_utilization,
)

from .carbon import (
    CarbonEstimate,
    estimate_carbon,
    estimate_carbon_savings,
    get_carbon_intensity,
    get_electricity_price,
    list_locations,
    CARBON_INTENSITY,
    ELECTRICITY_PRICE,
)

from .report import (
    generate_html_report,
    generate_markdown_report,
)

from .live_data import (
    DataSources,
    DetectedLocation,
    LiveCarbonData,
    detect_location,
    fetch_carbon_intensity,
    fetch_electricity_price,
    get_all_live_data,
)

__all__ = [
    # Main class
    "CrusoeEstimator",
    # Data classes
    "CrusoeEstimate",
    "EstimationResult",
    "EpochMetrics",
    "GPUSpec",
    "CrusoeGPU",
    "LocalHardware",
    "CarbonEstimate",
    "DataSources",
    "DetectedLocation",
    "LiveCarbonData",
    # GPU database
    "KNOWN_GPUS",
    "CRUSOE_GPUS",
    "get_crusoe_gpus",
    "match_gpu",
    "list_supported_gpus",
    # Hardware detection
    "detect_gpu",
    "get_power_draw",
    "get_gpu_utilization",
    # Carbon
    "estimate_carbon",
    "estimate_carbon_savings",
    "get_carbon_intensity",
    "get_electricity_price",
    "list_locations",
    "CARBON_INTENSITY",
    "ELECTRICITY_PRICE",
    # Live data
    "detect_location",
    "fetch_carbon_intensity",
    "fetch_electricity_price",
    "get_all_live_data",
    # Reports
    "generate_html_report",
    "generate_markdown_report",
]
