"""
HTML report generator for Crusoe Estimator.

Generates a visually appealing HTML report with tables, charts (CSS-based),
and CO2 savings comparison.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .estimator import EstimationResult


def _format_time(seconds: float) -> str:
    """Format seconds into human-readable time."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        return f"{seconds / 60:.1f} min"
    elif seconds < 86400:
        return f"{seconds / 3600:.1f} hrs"
    else:
        days = seconds / 86400
        hours = (seconds % 86400) / 3600
        return f"{days:.0f}d {hours:.0f}h"


def _format_cost(usd: float) -> str:
    """Format USD cost."""
    if usd < 0.01:
        return f"${usd:.4f}"
    elif usd < 1:
        return f"${usd:.3f}"
    elif usd < 100:
        return f"${usd:.2f}"
    else:
        return f"${usd:,.2f}"


def _format_co2(grams: float) -> str:
    """Format CO2 in appropriate units."""
    if grams < 1:
        return f"{grams * 1000:.1f} mg"
    elif grams < 1000:
        return f"{grams:.1f} g"
    else:
        return f"{grams / 1000:.2f} kg"


def _bar_width(value: float, max_value: float) -> float:
    """Calculate bar width percentage."""
    if max_value <= 0:
        return 0
    return min(100, (value / max_value) * 100)


def generate_html_report(result: "EstimationResult") -> str:
    """Generate a complete HTML report from estimation results."""

    hw = result.local_hardware
    gpu_name = hw.gpu_name
    gpu_perf = f"{hw.gpu_spec.fp16_tflops:.1f}" if hw.gpu_spec else "N/A"
    gpu_mem = f"{hw.gpu_spec.memory_gb:.0f}" if hw.gpu_spec else "N/A"
    gpu_arch = hw.gpu_spec.architecture if hw.gpu_spec else "Unknown"

    # Find max time for bar chart scaling
    all_times = [result.estimated_local_time_seconds] + [
        e.estimated_time_seconds for e in result.crusoe_estimates.values()
    ]
    max_time = max(all_times)
    max_cost = max(e.estimated_cost_usd for e in result.crusoe_estimates.values()) if result.crusoe_estimates else 1

    # Build Crusoe GPU comparison rows
    crusoe_rows_html = ""
    for key, est in result.crusoe_estimates.items():
        savings = result.carbon_savings[key]
        time_bar_w = _bar_width(est.estimated_time_seconds, max_time)
        # Range bar: show optimistic-pessimistic as a range overlay
        range_left = _bar_width(est.time_optimistic_seconds, max_time)
        range_right = _bar_width(est.time_pessimistic_seconds, max_time)
        cost_bar_w = _bar_width(est.estimated_cost_usd, max_cost)

        crusoe_rows_html += f"""
        <tr>
            <td class="gpu-name"><strong>{est.gpu_name}</strong></td>
            <td>
                <div class="bar-container range-bar">
                    <div class="bar-range" style="left: {range_left}%; width: {range_right - range_left}%;"></div>
                    <div class="bar bar-crusoe" style="width: {time_bar_w}%"></div>
                </div>
                <span class="value">{_format_time(est.estimated_time_seconds)}</span>
                <span class="range-text">({_format_time(est.time_optimistic_seconds)} – {_format_time(est.time_pessimistic_seconds)})</span>
            </td>
            <td>
                <span class="speedup">{est.speedup_vs_local:.1f}x</span>
                <span class="range-text">{est.speedup_pessimistic:.0f}x–{est.speedup_optimistic:.0f}x</span>
            </td>
            <td>
                <div class="bar-container">
                    <div class="bar bar-cost" style="width: {cost_bar_w}%"></div>
                </div>
                <span class="value">{_format_cost(est.estimated_cost_usd)}</span>
                <span class="range-text">({_format_cost(est.cost_optimistic_usd)} – {_format_cost(est.cost_pessimistic_usd)})</span>
                <span class="rate">(${est.price_per_gpu_hour:.2f}/hr)</span>
            </td>
            <td class="co2-cell">
                <span class="co2-zero">≈ 0 g CO₂</span>
                <span class="savings-badge">-{savings['savings_percent']:.0f}%</span>
            </td>
        </tr>
        """

    # Epoch timing chart data
    epoch_bars_html = ""
    for m in result.epoch_metrics:
        bar_w = _bar_width(m.duration_seconds, max(em.duration_seconds for em in result.epoch_metrics))
        label = "warmup" if m.epoch_index == 0 and len(result.epoch_metrics) > 1 else ""
        css_class = "bar-warmup" if label == "warmup" else "bar-epoch"
        epoch_bars_html += f"""
        <div class="epoch-row">
            <span class="epoch-label">Epoch {m.epoch_index + 1} {f'<small>({label})</small>' if label else ''}</span>
            <div class="bar-container">
                <div class="bar {css_class}" style="width: {bar_w}%"></div>
            </div>
            <span class="value">{m.duration_seconds:.2f}s</span>
        </div>
        """

    # Carbon comparison
    local_co2_g = result.local_carbon.carbon_g
    best_key = min(result.crusoe_estimates, key=lambda k: result.crusoe_estimates[k].estimated_cost_usd)
    best_savings = result.carbon_savings[best_key]

    # Fastest & cheapest
    fastest_key = min(result.crusoe_estimates, key=lambda k: result.crusoe_estimates[k].estimated_time_seconds)
    cheapest_key = min(result.crusoe_estimates, key=lambda k: result.crusoe_estimates[k].estimated_cost_usd)
    fastest = result.crusoe_estimates[fastest_key]
    cheapest = result.crusoe_estimates[cheapest_key]

    # Confidence & efficiency
    conf_class = "confidence-high" if result.confidence_score >= 70 else ("confidence-medium" if result.confidence_score >= 40 else "confidence-low")
    conf_color = "var(--accent-green)" if result.confidence_score >= 70 else ("var(--accent-orange)" if result.confidence_score >= 40 else "var(--accent-red)")
    eff_color = "var(--accent-green)" if result.gpu_efficiency >= 70 else ("var(--accent-orange)" if result.gpu_efficiency >= 40 else "var(--accent-red)")

    warnings_html = ""
    if result.warnings:
        warning_items = "".join(f'<div class="warning-item">{w}</div>' for w in result.warnings)
        warnings_html = f'<div class="warning-box">{warning_items}</div>'

    # Data sources info
    data_sources_html = ""
    if result.data_sources:
        ds = result.data_sources
        co2_badge_class = "badge-live" if ds.co2_is_live else "badge-default"
        co2_badge_text = "LIVE" if ds.co2_is_live else "DEFAULT"
        elec_is_live = ds.electricity_is_live if hasattr(ds, 'electricity_is_live') else ds.electricity_source not in ("default", "user-override")
        elec_badge_class = "badge-live" if elec_is_live else ("badge-user" if ds.electricity_source == "user-override" else "badge-default")
        elec_badge_text = "LIVE" if elec_is_live else ("USER" if ds.electricity_source == "user-override" else "DEFAULT")
        loc_text = f"{ds.location_name}" if ds.location_name != ds.location_code else ds.location_code

        # Exchange rate info
        fx_html = ""
        if hasattr(ds, 'exchange_rate') and ds.exchange_rate is not None:
            fx_badge_class = "badge-live" if ds.exchange_rate_source == "frankfurter.app" else "badge-default"
            fx_badge_text = "LIVE" if ds.exchange_rate_source == "frankfurter.app" else "DEFAULT"
            fx_html = f'''
            <div style="font-size: 0.8rem; color: var(--text-dim);">
                💱 EUR/USD: <strong>{ds.exchange_rate:.4f}</strong>
                <span class="data-badge {fx_badge_class}">{fx_badge_text}</span>
                <span style="font-size: 0.7rem; opacity: 0.6;">{ds.exchange_rate_source}</span>
            </div>'''

        data_sources_html = f'''
        <div style="display: flex; gap: 1rem; flex-wrap: wrap; margin-top: 0.8rem; padding-top: 0.8rem; border-top: 1px solid var(--card-border);">
            <div style="font-size: 0.8rem; color: var(--text-dim);">
                📍 <strong>{loc_text}</strong>
                <span style="font-size: 0.7rem; opacity: 0.6;">({ds.location_source})</span>
            </div>
            <div style="font-size: 0.8rem; color: var(--text-dim);">
                CO₂: <span class="data-badge {co2_badge_class}">{co2_badge_text}</span>
                <span style="font-size: 0.7rem; opacity: 0.6;">{ds.co2_source}</span>
            </div>
            <div style="font-size: 0.8rem; color: var(--text-dim);">
                ⚡ Price: <span class="data-badge {elec_badge_class}">{elec_badge_text}</span>
                <span style="font-size: 0.7rem; opacity: 0.6;">{ds.electricity_source}</span>
            </div>
            {fx_html}
        </div>'''

    # ── Multi-GPU scaling table ──────────────────────────────────────────
    multi_gpu_html = ""
    for key, est in result.crusoe_estimates.items():
        if not est.multi_gpu_estimates or len(est.multi_gpu_estimates) <= 1:
            continue
        multi_gpu_html += f'<div style="margin-bottom: 1rem;"><strong>{est.gpu_name}</strong>'
        multi_gpu_html += '<div style="display: flex; gap: 0.5rem; flex-wrap: wrap; margin-top: 0.4rem;">'
        for n_gpus, mdata in sorted(est.multi_gpu_estimates.items()):
            is_single = n_gpus == 1
            border_color = "var(--card-border)" if is_single else "var(--accent)"
            multi_gpu_html += f'''
            <div style="
                background: rgba(56, 189, 248, {'0.05' if is_single else '0.1'});
                border: 1px solid {border_color};
                border-radius: 8px; padding: 0.5rem 0.8rem;
                font-size: 0.82rem; min-width: 120px;
            ">
                <div style="font-weight: 700; color: var(--accent);">{n_gpus}x GPU</div>
                <div>⏱️ {_format_time(mdata['time_seconds'])}</div>
                <div>💰 {_format_cost(mdata['cost_usd'])}</div>
                <div style="color: var(--text-dim);">{mdata['speedup_vs_local']:.0f}x faster</div>
            </div>'''
        multi_gpu_html += '</div></div>'

    # ── Savings overview calculations ────────────────────────────────────
    best_est = result.crusoe_estimates[best_key]
    time_saved_sec = result.estimated_local_time_seconds - best_est.estimated_time_seconds
    money_vs_elec = result.local_electricity_cost_usd - best_est.estimated_cost_usd

    # Throughput text
    throughput_text = ""
    if result.throughput_samples_sec > 0:
        throughput_text = f"{result.throughput_samples_sec:.1f} samples/sec"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crusoe Estimator — Training Report</title>
    <style>
        :root {{
            --bg: #0a0e17;
            --card-bg: #131a2b;
            --card-border: #1e2d4a;
            --text: #e2e8f0;
            --text-dim: #8892a8;
            --accent: #38bdf8;
            --accent-green: #34d399;
            --accent-orange: #fb923c;
            --accent-red: #f87171;
            --accent-purple: #a78bfa;
            --crusoe-green: #22c55e;
            --bar-local: #f87171;
            --bar-crusoe: #38bdf8;
            --bar-cost: #fb923c;
            --bar-epoch: #a78bfa;
            --bar-warmup: #64748b;
        }}

        * {{ margin: 0; padding: 0; box-sizing: border-box; }}

        body {{
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: var(--bg);
            color: var(--text);
            line-height: 1.6;
            padding: 2rem;
        }}

        .container {{
            max-width: 1100px;
            margin: 0 auto;
        }}

        .header {{
            text-align: center;
            margin-bottom: 2.5rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid var(--card-border);
        }}

        .header h1 {{
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--accent), var(--crusoe-green));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 0.3rem;
        }}

        .header .subtitle {{
            color: var(--text-dim);
            font-size: 0.95rem;
        }}

        .grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            margin-bottom: 1.5rem;
        }}

        .card {{
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: 12px;
            padding: 1.5rem;
        }}

        .card-full {{
            grid-column: 1 / -1;
        }}

        .card h2 {{
            font-size: 1.1rem;
            font-weight: 600;
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }}

        .card h2 .icon {{
            font-size: 1.3rem;
        }}

        .stat-grid {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.8rem;
        }}

        .stat {{
            background: rgba(56, 189, 248, 0.05);
            border: 1px solid rgba(56, 189, 248, 0.1);
            border-radius: 8px;
            padding: 0.8rem;
        }}

        .stat .label {{
            font-size: 0.75rem;
            color: var(--text-dim);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }}

        .stat .value {{
            font-size: 1.3rem;
            font-weight: 700;
            color: var(--accent);
        }}

        .stat.green .value {{ color: var(--accent-green); }}
        .stat.orange .value {{ color: var(--accent-orange); }}
        .stat.red .value {{ color: var(--accent-red); }}
        .stat.purple .value {{ color: var(--accent-purple); }}

        /* Table styles */
        table {{
            width: 100%;
            border-collapse: collapse;
        }}

        th {{
            text-align: left;
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-dim);
            padding: 0.5rem 0.8rem;
            border-bottom: 1px solid var(--card-border);
        }}

        td {{
            padding: 0.8rem;
            border-bottom: 1px solid rgba(30, 45, 74, 0.5);
            vertical-align: middle;
        }}

        tr:last-child td {{
            border-bottom: none;
        }}

        .gpu-name {{
            white-space: nowrap;
        }}

        /* Bar chart */
        .bar-container {{
            height: 8px;
            background: rgba(255,255,255,0.05);
            border-radius: 4px;
            overflow: hidden;
            margin-bottom: 4px;
            min-width: 80px;
        }}

        .bar {{
            height: 100%;
            border-radius: 4px;
            transition: width 0.5s ease;
        }}

        .bar-local {{ background: var(--bar-local); }}
        .bar-crusoe {{ background: var(--bar-crusoe); }}
        .bar-cost {{ background: var(--bar-cost); }}
        .bar-epoch {{ background: var(--bar-epoch); }}
        .bar-warmup {{ background: var(--bar-warmup); }}

        .value {{
            font-size: 0.9rem;
            font-weight: 600;
        }}

        .rate {{
            font-size: 0.75rem;
            color: var(--text-dim);
            margin-left: 4px;
        }}

        .speedup {{
            font-weight: 700;
            color: var(--accent-green);
            font-size: 1rem;
        }}

        .co2-cell {{
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }}

        .co2-zero {{
            color: var(--crusoe-green);
            font-weight: 600;
        }}

        .savings-badge {{
            background: rgba(34, 197, 94, 0.15);
            color: var(--crusoe-green);
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.75rem;
            font-weight: 700;
        }}

        /* Local time row */
        .local-row {{
            background: rgba(248, 113, 113, 0.05);
        }}

        .local-row td {{
            border-bottom: 2px solid var(--card-border);
        }}

        /* Epoch chart */
        .epoch-row {{
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 0.5rem;
        }}

        .epoch-label {{
            width: 110px;
            font-size: 0.85rem;
            color: var(--text-dim);
            flex-shrink: 0;
        }}

        .epoch-label small {{
            color: var(--accent-orange);
        }}

        .epoch-row .bar-container {{
            flex: 1;
        }}

        .epoch-row .value {{
            width: 70px;
            text-align: right;
            flex-shrink: 0;
        }}

        /* Carbon section */
        .carbon-comparison {{
            display: flex;
            align-items: center;
            gap: 2rem;
            margin-top: 1rem;
        }}

        .carbon-bar {{
            flex: 1;
        }}

        .carbon-label {{
            font-size: 0.85rem;
            margin-bottom: 0.3rem;
        }}

        .carbon-bar-inner {{
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            padding: 0 12px;
            font-weight: 700;
            font-size: 0.9rem;
        }}

        .carbon-local {{
            background: linear-gradient(90deg, var(--accent-red), var(--accent-orange));
        }}

        .carbon-crusoe {{
            background: linear-gradient(90deg, var(--crusoe-green), var(--accent-green));
            max-width: 60px;
        }}

        .carbon-arrow {{
            font-size: 2rem;
            color: var(--crusoe-green);
        }}

        .equivalents {{
            display: flex;
            gap: 1.5rem;
            margin-top: 1rem;
            flex-wrap: wrap;
        }}

        .equivalent-item {{
            background: rgba(34, 197, 94, 0.08);
            border: 1px solid rgba(34, 197, 94, 0.15);
            border-radius: 8px;
            padding: 0.6rem 1rem;
            font-size: 0.85rem;
        }}

        .equivalent-item strong {{
            color: var(--crusoe-green);
        }}

        /* Range estimates */
        .range-bar {{
            position: relative;
        }}

        .bar-range {{
            position: absolute;
            top: 0;
            height: 100%;
            background: rgba(56, 189, 248, 0.15);
            border-radius: 4px;
            border: 1px dashed rgba(56, 189, 248, 0.3);
        }}

        .range-text {{
            font-size: 0.7rem;
            color: var(--text-dim);
            margin-left: 4px;
        }}

        /* Confidence */
        .confidence-badge {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: 700;
            font-size: 0.9rem;
        }}

        .confidence-high {{
            background: rgba(34, 197, 94, 0.15);
            color: var(--accent-green);
            border: 1px solid rgba(34, 197, 94, 0.3);
        }}

        .confidence-medium {{
            background: rgba(251, 146, 60, 0.15);
            color: var(--accent-orange);
            border: 1px solid rgba(251, 146, 60, 0.3);
        }}

        .confidence-low {{
            background: rgba(248, 113, 113, 0.15);
            color: var(--accent-red);
            border: 1px solid rgba(248, 113, 113, 0.3);
        }}

        .confidence-meter {{
            height: 8px;
            background: rgba(255,255,255,0.05);
            border-radius: 4px;
            overflow: hidden;
            flex: 1;
        }}

        .confidence-fill {{
            height: 100%;
            border-radius: 4px;
            transition: width 0.5s ease;
        }}

        .warning-box {{
            background: rgba(251, 146, 60, 0.08);
            border: 1px solid rgba(251, 146, 60, 0.2);
            border-radius: 8px;
            padding: 1rem;
            margin-top: 1rem;
        }}

        .warning-item {{
            font-size: 0.85rem;
            color: var(--accent-orange);
            margin-bottom: 0.4rem;
            padding-left: 1.2rem;
            position: relative;
        }}

        .warning-item::before {{
            content: '⚠';
            position: absolute;
            left: 0;
        }}

        .efficiency-bar {{
            display: flex;
            align-items: center;
            gap: 0.8rem;
            margin-top: 0.5rem;
        }}

        /* Recommendation */
        .recommendation {{
            background: linear-gradient(135deg, rgba(56, 189, 248, 0.1), rgba(34, 197, 94, 0.1));
            border: 1px solid rgba(56, 189, 248, 0.2);
            border-radius: 12px;
            padding: 1.5rem;
            margin-top: 1.5rem;
        }}

        .recommendation h2 {{
            margin-bottom: 0.8rem;
        }}

        .rec-options {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }}

        .rec-card {{
            background: rgba(0,0,0,0.2);
            border-radius: 8px;
            padding: 1rem;
        }}

        .rec-card h3 {{
            font-size: 0.9rem;
            color: var(--text-dim);
            margin-bottom: 0.3rem;
        }}

        .rec-card .rec-gpu {{
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--accent);
        }}

        .rec-card .rec-detail {{
            font-size: 0.85rem;
            color: var(--text-dim);
            margin-top: 0.3rem;
        }}

        /* Savings overview */
        .savings-overview {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }}

        .savings-card {{
            background: rgba(0,0,0,0.25);
            border-radius: 10px;
            padding: 1.2rem;
            text-align: center;
        }}

        .savings-card .savings-icon {{
            font-size: 1.8rem;
            margin-bottom: 0.4rem;
        }}

        .savings-card .savings-value {{
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--accent-green);
        }}

        .savings-card .savings-label {{
            font-size: 0.8rem;
            color: var(--text-dim);
            margin-top: 0.2rem;
        }}

        /* Cost comparison */
        .cost-compare {{
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-top: 1rem;
            flex-wrap: wrap;
        }}

        .cost-pill {{
            background: rgba(0,0,0,0.2);
            border-radius: 20px;
            padding: 0.5rem 1.2rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
        }}

        .cost-pill .cost-amount {{
            font-weight: 700;
            font-size: 1.1rem;
        }}

        /* Data source badges */
        .data-badge {{
            display: inline-block;
            padding: 1px 8px;
            border-radius: 10px;
            font-size: 0.65rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}

        .badge-live {{
            background: rgba(34, 197, 94, 0.2);
            color: var(--accent-green);
            border: 1px solid rgba(34, 197, 94, 0.4);
        }}

        .badge-default {{
            background: rgba(100, 116, 139, 0.2);
            color: var(--text-dim);
            border: 1px solid rgba(100, 116, 139, 0.3);
        }}

        .badge-user {{
            background: rgba(56, 189, 248, 0.2);
            color: var(--accent);
            border: 1px solid rgba(56, 189, 248, 0.3);
        }}

        .footer {{
            text-align: center;
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid var(--card-border);
            color: var(--text-dim);
            font-size: 0.8rem;
        }}

        .footer a {{
            color: var(--accent);
            text-decoration: none;
        }}

        @media (max-width: 768px) {{
            .grid {{ grid-template-columns: 1fr; }}
            .rec-options {{ grid-template-columns: 1fr; }}
            body {{ padding: 1rem; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>⚡ Crusoe Training Estimator</h1>
            <p class="subtitle">GPU Training Cost &amp; Carbon Analysis Report</p>
        </div>

        <!-- Hardware & Benchmark Info -->
        <div class="grid">
            <div class="card">
                <h2><span class="icon">🖥️</span> Local Hardware</h2>
                <div class="stat-grid">
                    <div class="stat">
                        <div class="label">GPU</div>
                        <div class="value" style="font-size: 1rem;">{gpu_name}</div>
                    </div>
                    <div class="stat">
                        <div class="label">Architecture</div>
                        <div class="value" style="font-size: 1rem;">{gpu_arch}</div>
                    </div>
                    <div class="stat purple">
                        <div class="label">FP16 Performance</div>
                        <div class="value">{gpu_perf} TFLOPS</div>
                    </div>
                    <div class="stat">
                        <div class="label">Memory</div>
                        <div class="value">{gpu_mem} GB</div>
                    </div>
                </div>
            </div>

            <div class="card">
                <h2><span class="icon">📏</span> Benchmark Config</h2>
                <div class="stat-grid">
                    <div class="stat">
                        <div class="label">Sample Epochs</div>
                        <div class="value">{result.sample_epochs}</div>
                    </div>
                    <div class="stat">
                        <div class="label">Total Epochs</div>
                        <div class="value">{result.total_epochs}</div>
                    </div>
                    <div class="stat orange">
                        <div class="label">Avg Epoch Time</div>
                        <div class="value">{_format_time(result.avg_epoch_time)}</div>
                    </div>
                    <div class="stat red">
                        <div class="label">Est. Local Total</div>
                        <div class="value">{_format_time(result.estimated_local_time_seconds)}</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Local Cost -->
        <div class="card card-full" style="margin-bottom: 1.5rem;">
            <h2><span class="icon">💡</span> Local Training Cost</h2>
            <div class="cost-compare">
                <div class="cost-pill">
                    📍 Local electricity
                    <span class="cost-amount" style="color: var(--accent-orange);">${result.local_electricity_cost_usd:.2f}</span>
                </div>
                <span style="color: var(--text-dim);">at</span>
                <div class="cost-pill">
                    ⚡ ${result.local_electricity_price_kwh:.3f}/kWh
                    <span style="color: var(--text-dim);">({result.location})</span>
                </div>
                <span style="color: var(--text-dim);">for</span>
                <div class="cost-pill">
                    🔋 {result.local_carbon.energy_kwh:.3f} kWh
                    <span style="color: var(--text-dim);">@{result.local_power_watts:.0f}W × {result.estimated_local_time_hours:.1f}h</span>
                </div>
                {'<div class="cost-pill">📊 ' + throughput_text + '</div>' if throughput_text else ''}
            </div>
        </div>

        <!-- Confidence & GPU Efficiency -->
        <div class="card card-full" style="margin-bottom: 1.5rem;">
            <h2><span class="icon">🎯</span> Estimate Confidence</h2>
            <div style="display: flex; gap: 2rem; align-items: flex-start; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 200px;">
                    <div style="display: flex; align-items: center; gap: 0.8rem; margin-bottom: 0.8rem;">
                        <span class="confidence-badge {conf_class}">{result.confidence_label} ({result.confidence_score:.0f}%)</span>
                    </div>
                    <div class="efficiency-bar">
                        <span style="font-size: 0.8rem; color: var(--text-dim); width: 100px;">Confidence</span>
                        <div class="confidence-meter">
                            <div class="confidence-fill" style="width: {result.confidence_score}%; background: {conf_color};"></div>
                        </div>
                        <span style="font-size: 0.85rem; font-weight: 600; color: {conf_color};">{result.confidence_score:.0f}%</span>
                    </div>
                    <div class="efficiency-bar">
                        <span style="font-size: 0.8rem; color: var(--text-dim); width: 100px;">GPU Efficiency</span>
                        <div class="confidence-meter">
                            <div class="confidence-fill" style="width: {result.gpu_efficiency}%; background: {eff_color};"></div>
                        </div>
                        <span style="font-size: 0.85rem; font-weight: 600; color: {eff_color};">~{result.gpu_efficiency:.0f}%</span>
                    </div>
                    <div class="efficiency-bar">
                        <span style="font-size: 0.8rem; color: var(--text-dim); width: 100px;">Epoch Variance</span>
                        <div class="confidence-meter">
                            <div class="confidence-fill" style="width: {min(100, result.epoch_variance * 500)}%; background: {'var(--accent-green)' if result.epoch_variance < 0.1 else 'var(--accent-orange)'};"></div>
                        </div>
                        <span style="font-size: 0.85rem; font-weight: 600;">{result.epoch_variance:.1%}</span>
                    </div>
                </div>
                <div style="flex: 1; min-width: 250px;">
                    <p style="font-size: 0.85rem; color: var(--text-dim); margin-bottom: 0.5rem;">
                        <strong>What this means:</strong> Estimates are based on {result.sample_epochs} sample epoch(s)
                        scaled by FLOPS ratio. GPU efficiency measures how compute-bound the workload is —
                        higher efficiency means FLOPS scaling is more reliable.
                    </p>
                    <p style="font-size: 0.85rem; color: var(--text-dim);">
                        Time ranges shown in the table below reflect optimistic (pure compute scaling)
                        to pessimistic (accounting for CPU/IO overhead that won't speed up with a faster GPU).
                    </p>
                </div>
            </div>
            {warnings_html}
        </div>

        <!-- Epoch Timing -->
        <div class="card card-full" style="margin-bottom: 1.5rem;">
            <h2><span class="icon">⏱️</span> Epoch Timing (Benchmark)</h2>
            {epoch_bars_html}
        </div>

        <!-- GPU Comparison Table -->
        <div class="card card-full" style="margin-bottom: 1.5rem;">
            <h2><span class="icon">☁️</span> Crusoe Cloud GPU Comparison</h2>
            <table>
                <thead>
                    <tr>
                        <th>GPU</th>
                        <th>Est. Training Time</th>
                        <th>Speedup</th>
                        <th>Est. Cost</th>
                        <th>CO₂ Emissions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="local-row">
                        <td class="gpu-name"><strong>📍 {gpu_name}</strong> <small>(local)</small></td>
                        <td>
                            <div class="bar-container">
                                <div class="bar bar-local" style="width: 100%"></div>
                            </div>
                            <span class="value">{_format_time(result.estimated_local_time_seconds)}</span>
                        </td>
                        <td><span style="color: var(--text-dim);">1.0x</span></td>
                        <td><span class="value" style="color: var(--text-dim);">—</span></td>
                        <td class="co2-cell">
                            <span style="color: var(--accent-red); font-weight: 600;">
                                {_format_co2(local_co2_g)}
                            </span>
                        </td>
                    </tr>
                    {crusoe_rows_html}
                </tbody>
            </table>
        </div>

        <!-- Multi-GPU Scaling -->
        {'<div class="card card-full" style="margin-bottom: 1.5rem;"><h2><span class="icon">🔀</span> Multi-GPU Scaling</h2><p style="color: var(--text-dim); font-size: 0.85rem; margin-bottom: 1rem;">Estimated time and cost with multiple GPUs. Scaling assumes ~92%% efficiency per doubling (accounting for communication overhead).</p>' + multi_gpu_html + '</div>' if multi_gpu_html else ''}

        <!-- Savings Overview -->
        <div class="card card-full" style="margin-bottom: 1.5rem;">
            <h2><span class="icon">📊</span> Savings Overview — Crusoe vs Local</h2>
            <div class="savings-overview">
                <div class="savings-card">
                    <div class="savings-icon">⏱️</div>
                    <div class="savings-value">{_format_time(time_saved_sec)}</div>
                    <div class="savings-label">Time saved</div>
                </div>
                <div class="savings-card">
                    <div class="savings-icon">💰</div>
                    <div class="savings-value" style="color: {'var(--accent-green)' if money_vs_elec > 0 else 'var(--accent-orange)'};">
                        {'−$' + f'{abs(money_vs_elec):.2f}' if money_vs_elec > 0 else '+$' + f'{abs(money_vs_elec):.2f}'}
                    </div>
                    <div class="savings-label">{'Cheaper than local electricity' if money_vs_elec > 0 else 'Cloud premium vs electricity'}</div>
                </div>
                <div class="savings-card">
                    <div class="savings-icon">🌍</div>
                    <div class="savings-value">{_format_co2(result.local_carbon.carbon_g)}</div>
                    <div class="savings-label">CO₂ saved (100%%)</div>
                </div>
                <div class="savings-card">
                    <div class="savings-icon">⚡</div>
                    <div class="savings-value">{best_est.speedup_vs_local:.0f}x</div>
                    <div class="savings-label">Faster ({best_est.gpu_name})</div>
                </div>
            </div>
        </div>

        <!-- Carbon Savings -->
        <div class="card card-full" style="margin-bottom: 1.5rem;">
            <h2><span class="icon">🌍</span> Carbon Emissions Comparison</h2>
            <p style="color: var(--text-dim); font-size: 0.9rem; margin-bottom: 1rem;">
                Local training in <strong>{result.location}</strong>
                (carbon intensity: {result.local_carbon.carbon_intensity} kg CO₂/kWh)
                vs Crusoe Cloud (≈ 0 kg CO₂/kWh — 100% renewable energy)
            </p>

            <div class="carbon-comparison">
                <div class="carbon-bar" style="flex: 2;">
                    <div class="carbon-label">📍 Local ({result.location})</div>
                    <div class="carbon-bar-inner carbon-local" style="width: 100%;">
                        {_format_co2(local_co2_g)} CO₂
                    </div>
                </div>
                <div class="carbon-arrow">→</div>
                <div class="carbon-bar" style="flex: 1;">
                    <div class="carbon-label">☁️ Crusoe Cloud</div>
                    <div class="carbon-bar-inner carbon-crusoe">
                        ≈ 0
                    </div>
                </div>
            </div>

            <div class="equivalents">
                <div class="equivalent-item">
                    🚗 CO₂ saved ≈ <strong>{best_savings['equivalent_km_saved']:.1f} km</strong> not driven
                </div>
                <div class="equivalent-item">
                    🌳 Equivalent to <strong>{best_savings['equivalent_trees']:.4f} trees</strong> absorbing CO₂ for a year
                </div>
                <div class="equivalent-item">
                    🔋 Energy: <strong>{result.local_carbon.energy_kwh:.3f} kWh</strong> local
                    → saved with Crusoe
                </div>
                <div class="equivalent-item">
                    📱 ≈ <strong>{result.local_carbon.equivalent_smartphone_charges:.0f} smartphone charges</strong> worth of energy
                </div>
            </div>
        </div>

        <!-- Recommendation -->
        <div class="recommendation">
            <h2><span class="icon">💡</span> Recommendation</h2>
            <div class="rec-options">
                <div class="rec-card">
                    <h3>💰 Best Value</h3>
                    <div class="rec-gpu">{cheapest.gpu_name}</div>
                    <div class="rec-detail">
                        {_format_time(cheapest.estimated_time_seconds)} •
                        {_format_cost(cheapest.estimated_cost_usd)} •
                        {cheapest.speedup_vs_local:.1f}x faster
                    </div>
                    <div class="rec-detail" style="margin-top: 0.2rem; font-size: 0.75rem;">
                        Range: {_format_time(cheapest.time_optimistic_seconds)} – {_format_time(cheapest.time_pessimistic_seconds)}
                        ({_format_cost(cheapest.cost_optimistic_usd)} – {_format_cost(cheapest.cost_pessimistic_usd)})
                    </div>
                </div>
                <div class="rec-card">
                    <h3>⚡ Fastest</h3>
                    <div class="rec-gpu">{fastest.gpu_name}</div>
                    <div class="rec-detail">
                        {_format_time(fastest.estimated_time_seconds)} •
                        {_format_cost(fastest.estimated_cost_usd)} •
                        {fastest.speedup_vs_local:.1f}x faster
                    </div>
                    <div class="rec-detail" style="margin-top: 0.2rem; font-size: 0.75rem;">
                        Range: {_format_time(fastest.time_optimistic_seconds)} – {_format_time(fastest.time_pessimistic_seconds)}
                        ({_format_cost(fastest.cost_optimistic_usd)} – {_format_cost(fastest.cost_pessimistic_usd)})
                    </div>
                </div>
            </div>
        </div>

        <div class="footer">
            <p>Generated by <strong>crusoe-estimator</strong> •
               Powered by <a href="https://crusoe.ai" target="_blank">Crusoe Cloud</a> •
               100% Renewable Energy ♻️</p>
            <p style="margin-top: 0.3rem;">
                Estimates are based on {result.sample_epochs} sample epochs extrapolated to
                {result.total_epochs} total epochs using FLOPS and memory bandwidth scaling.
                Confidence: <strong>{result.confidence_label} ({result.confidence_score:.0f}%)</strong>.
                GPU efficiency: <strong>~{result.gpu_efficiency:.0f}%</strong>.
                Actual performance may vary.
            </p>
            {data_sources_html}
        </div>
    </div>
</body>
</html>"""

    return html


def generate_markdown_report(result: "EstimationResult") -> str:
    """Generate a Markdown report from estimation results."""
    hw = result.local_hardware
    lines = []

    lines.append("# ⚡ Crusoe Training Estimator Report\n")

    lines.append("## 🖥️ Local Hardware\n")
    lines.append(f"| Property | Value |")
    lines.append(f"|----------|-------|")
    lines.append(f"| GPU | {hw.gpu_name} |")
    if hw.gpu_spec:
        lines.append(f"| FP16 TFLOPS | {hw.gpu_spec.fp16_tflops:.1f} |")
        lines.append(f"| Memory | {hw.gpu_spec.memory_gb:.0f} GB |")
        lines.append(f"| Architecture | {hw.gpu_spec.architecture} |")
    lines.append(f"| Device | {hw.device_type} |")
    lines.append("")

    lines.append("## 📏 Benchmark\n")
    lines.append(f"- **Sample epochs:** {result.sample_epochs}")
    lines.append(f"- **Total epochs:** {result.total_epochs}")
    lines.append(f"- **Avg epoch time:** {_format_time(result.avg_epoch_time)}")
    lines.append(f"- **Est. local total:** {_format_time(result.estimated_local_time_seconds)}")
    if result.dataset_scale_factor != 1.0:
        lines.append(f"- **Dataset scale:** {result.dataset_scale_factor:.1f}x")
    lines.append("")

    lines.append("## ☁️ Crusoe Cloud Comparison\n")
    lines.append("| GPU | Time | Speedup | Cost | CO₂ |")
    lines.append("|-----|------|---------|------|-----|")
    lines.append(f"| 📍 {hw.gpu_name} (local) | {_format_time(result.estimated_local_time_seconds)} "
                 f"| 1.0x | — | {_format_co2(result.local_carbon.carbon_g)} |")

    for key, est in result.crusoe_estimates.items():
        savings = result.carbon_savings[key]
        lines.append(
            f"| {est.gpu_name} | {_format_time(est.estimated_time_seconds)} "
            f"| {est.speedup_vs_local:.1f}x | {_format_cost(est.estimated_cost_usd)} "
            f"| ≈ 0 (-{savings['savings_percent']:.0f}%) |"
        )
    lines.append("")

    lines.append("## 🌍 Carbon Savings\n")
    best_key = min(result.crusoe_estimates, key=lambda k: result.crusoe_estimates[k].estimated_cost_usd)
    savings = result.carbon_savings[best_key]
    lines.append(f"- **Local CO₂:** {_format_co2(result.local_carbon.carbon_g)}")
    lines.append(f"- **Crusoe CO₂:** ≈ 0 g")
    lines.append(f"- **Savings:** {savings['savings_percent']:.0f}%")
    lines.append(f"- **Equivalent:** {savings['equivalent_km_saved']:.1f} km not driven by car")
    lines.append("")

    lines.append("---")
    lines.append("*Generated by crusoe-estimator • Powered by [Crusoe Cloud](https://crusoe.ai)*")

    return "\n".join(lines)
