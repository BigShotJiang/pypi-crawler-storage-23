"""
Core estimator module.

CrusoeEstimator is the main class that benchmarks a PyTorch training loop
on a small sample and extrapolates performance, cost, and CO2 estimates
for Crusoe Cloud GPUs.
"""

import time
import math
import functools
from dataclasses import dataclass, field
from typing import (
    Any,
    Callable,
    Dict,
    Iterator,
    List,
    Optional,
    Tuple,
    Union,
)

from .gpu_database import CrusoeGPU, GPUSpec, get_crusoe_gpus
from .hardware import LocalHardware, detect_gpu, get_power_draw
from .carbon import (
    CarbonEstimate,
    estimate_carbon,
    estimate_carbon_savings,
    get_electricity_price,
)
from .live_data import (
    DataSources,
    get_all_live_data,
    detect_location,
)


@dataclass
class EpochMetrics:
    """Metrics collected for a single epoch."""
    epoch_index: int
    duration_seconds: float
    samples_processed: int
    batches_processed: int
    avg_power_watts: Optional[float] = None
    peak_memory_mb: Optional[float] = None


@dataclass
class CrusoeEstimate:
    """Training estimate for a specific Crusoe GPU."""
    gpu_name: str
    gpu_key: str
    estimated_time_seconds: float
    estimated_time_hours: float
    price_per_gpu_hour: float
    estimated_cost_usd: float
    carbon_estimate: CarbonEstimate
    speedup_vs_local: float
    num_gpus: int = 1
    # Range estimates
    time_optimistic_seconds: float = 0.0
    time_pessimistic_seconds: float = 0.0
    cost_optimistic_usd: float = 0.0
    cost_pessimistic_usd: float = 0.0
    speedup_optimistic: float = 0.0
    speedup_pessimistic: float = 0.0
    # Multi-GPU options
    multi_gpu_estimates: Optional[Dict[int, Dict]] = None  # {num_gpus: {time, cost, speedup}}


@dataclass
class EstimationResult:
    """Complete estimation result with all comparisons."""
    # Local hardware info
    local_hardware: LocalHardware
    location: str

    # Benchmark results
    sample_epochs: int
    total_epochs: int
    epoch_metrics: List[EpochMetrics]
    dataset_scale_factor: float  # total_dataset_size / sample_dataset_size

    # Local estimates
    avg_epoch_time: float
    estimated_local_time_seconds: float
    estimated_local_time_hours: float
    local_power_watts: float
    local_carbon: CarbonEstimate

    # Crusoe estimates
    crusoe_estimates: Dict[str, CrusoeEstimate]

    # Carbon savings
    carbon_savings: Dict[str, dict]

    # Local electricity cost
    local_electricity_price_kwh: float = 0.0   # USD per kWh
    local_electricity_cost_usd: float = 0.0    # Total local electricity cost

    # Throughput
    throughput_samples_sec: float = 0.0   # Samples per second
    throughput_batches_sec: float = 0.0   # Batches per second

    # Data sources (live vs fallback)
    data_sources: Optional[DataSources] = None

    # Confidence & GPU efficiency
    confidence_score: float = 0.0       # 0-100%, how reliable the estimate is
    confidence_label: str = "Unknown"   # "High", "Medium", "Low"
    gpu_efficiency: float = 0.0         # 0-100%, how well the GPU was utilized
    epoch_variance: float = 0.0         # Coefficient of variation of epoch times
    warnings: List[str] = field(default_factory=list)

    # Timestamps
    benchmark_start: float = 0.0
    benchmark_end: float = 0.0

    @property
    def benchmark_duration(self) -> float:
        return self.benchmark_end - self.benchmark_start


class CrusoeEstimator:
    """
    PyTorch training cost and carbon estimator for Crusoe Cloud.

    This is a framework plugin that wraps your training loop, benchmarks
    a small sample of epochs, and extrapolates training time, cost, and
    CO2 emissions across all Crusoe GPU offerings.

    Usage patterns:

    1. Training loop wrapper:
        estimator = CrusoeEstimator(total_epochs=100)
        for epoch in estimator.epochs(sample=3):
            train_one_epoch(model, dataloader)
        result = estimator.result()

    2. Decorator:
        estimator = CrusoeEstimator(total_epochs=100)
        @estimator.watch(sample_epochs=3)
        def train_epoch():
            ...

    3. Context manager:
        estimator = CrusoeEstimator(total_epochs=100, sample_epochs=3)
        with estimator.track():
            for epoch in range(3):
                train_one_epoch(model, dataloader)
        result = estimator.result()
    """

    def __init__(
        self,
        total_epochs: int,
        sample_epochs: Optional[int] = None,
        total_dataset_size: Optional[int] = None,
        sample_dataset_size: Optional[int] = None,
        dataset_fraction: Optional[float] = None,
        location: Optional[str] = None,
        device_index: int = 0,
        crusoe_gpus: Optional[Dict[str, CrusoeGPU]] = None,
        power_watts_override: Optional[float] = None,
        electricity_price: Optional[float] = None,
        electricity_maps_api_key: Optional[str] = None,
        entsoe_api_key: Optional[str] = None,
    ):
        """
        Args:
            total_epochs: Total number of epochs for the full training run.
            sample_epochs: Number of epochs to actually run for benchmarking.
                           If None, defaults to min(3, total_epochs).
            total_dataset_size: Total dataset size (for scaling estimation).
            sample_dataset_size: Dataset size used in sample run.
                                If different from total, time is scaled linearly.
            dataset_fraction: Fraction of dataset to use for benchmarking
                              (e.g. 0.2 = 20%). Automatically creates a subset
                              and scales estimates to the full dataset.
                              Overrides sample_dataset_size if set.
            location: Country/region code (e.g. "HR", "DE", "US").
                      If None, auto-detected from IP address.
            device_index: CUDA device index (default 0).
            crusoe_gpus: Override Crusoe GPU offerings (for custom pricing).
            power_watts_override: Override auto-detected power draw (watts).
            electricity_price: Your electricity price in USD/kWh.
                               If None, fetched live or from defaults.
            electricity_maps_api_key: API key for Electricity Maps (live CO2).
                                      Also reads ELECTRICITY_MAPS_API_KEY env var.
            entsoe_api_key: API key for ENTSO-E (live EU electricity prices).
                            Also reads ENTSOE_API_KEY env var.
        """
        self.total_epochs = total_epochs
        self.sample_epochs = sample_epochs or min(3, total_epochs)
        self.total_dataset_size = total_dataset_size
        self.sample_dataset_size = sample_dataset_size or total_dataset_size
        self.dataset_fraction = dataset_fraction
        self.device_index = device_index
        self.crusoe_gpus = crusoe_gpus or get_crusoe_gpus()
        self.power_watts_override = power_watts_override

        # Fetch live data (CO2, electricity price, auto-detect location)
        loc_code, co2_intensity, elec_price, data_sources = get_all_live_data(
            location=location,
            electricity_maps_key=electricity_maps_api_key,
            entsoe_key=entsoe_api_key,
            electricity_price_override=electricity_price,
        )
        self.location = loc_code
        self._live_carbon_intensity = co2_intensity  # kg CO2/kWh
        self._live_electricity_price = elec_price    # USD/kWh
        self._data_sources = data_sources

        # Internal state
        self._epoch_metrics: List[EpochMetrics] = []
        self._current_epoch_start: Optional[float] = None
        self._current_epoch_index: int = 0
        self._benchmark_start: Optional[float] = None
        self._benchmark_end: Optional[float] = None
        self._local_hardware: Optional[LocalHardware] = None
        self._result: Optional[EstimationResult] = None
        self._power_readings: List[float] = []
        self._track_start: Optional[float] = None
        self._total_track_time: Optional[float] = None
        self._samples_per_epoch: int = 0
        self._batches_per_epoch: int = 0
        self._gpu_compute_times: List[float] = []  # GPU-only time per epoch
        self._gpu_idle_times: List[float] = []      # CPU/IO time per epoch

    # ─── Pattern 1: Training loop wrapper ────────────────────────────────

    def make_subset(self, dataloader, fraction: Optional[float] = None,
                    strategy: str = "random"):
        """
        Create a subset DataLoader from an existing one for fast benchmarking.

        Takes a fraction of the dataset and returns a new DataLoader with
        the same settings (batch_size, num_workers, etc.) but fewer samples.
        Automatically sets total_dataset_size and sample_dataset_size for
        correct scaling in estimates.

        Usage:
            estimator = CrusoeEstimator(total_epochs=300, dataset_fraction=0.2)
            subset_loader = estimator.make_subset(train_loader)  # random 20%
            subset_loader = estimator.make_subset(train_loader, strategy="first")  # first 20%

        Args:
            dataloader: Original PyTorch DataLoader.
            fraction: Fraction to use (0.0-1.0). If None, uses
                      self.dataset_fraction. Defaults to 1.0 (no subset).
            strategy: How to select the subset:
                - "random": Random sample (default, best for representative estimate)
                - "first": Take the first N samples (faster, deterministic)

        Returns:
            New DataLoader with subset of the data if fraction < 1.0,
            or the original DataLoader if fraction >= 1.0.
        """
        import torch
        from torch.utils.data import DataLoader, Subset

        frac = fraction or self.dataset_fraction or 1.0
        frac = max(0.01, min(1.0, frac))  # Clamp to [1%, 100%]

        dataset = dataloader.dataset
        full_size = len(dataset)

        # Set total dataset size (the full dataset)
        self.total_dataset_size = full_size

        if frac >= 1.0:
            self.sample_dataset_size = full_size
            return dataloader

        # Create subset based on strategy
        sample_size = max(1, int(full_size * frac))

        if strategy == "first":
            indices = list(range(sample_size))
        else:  # "random"
            indices = torch.randperm(full_size)[:sample_size].tolist()

        subset = Subset(dataset, indices)

        self.sample_dataset_size = sample_size

        # Re-create DataLoader with same settings
        new_loader = DataLoader(
            subset,
            batch_size=dataloader.batch_size,
            shuffle=(strategy == "random"),
            num_workers=dataloader.num_workers,
            pin_memory=getattr(dataloader, 'pin_memory', False),
            drop_last=getattr(dataloader, 'drop_last', False),
        )

        strategy_label = "random" if strategy == "random" else "first"
        print(f"📊 Dataset subset: {sample_size}/{full_size} samples "
              f"({frac:.0%}, {strategy_label}) → {len(new_loader)} batches/epoch")

        return new_loader

    def epochs(
        self,
        sample: Optional[int] = None,
        total_range: Optional[range] = None,
    ) -> Iterator[int]:
        """
        Generator that yields epoch indices. Only runs `sample` epochs
        but records timing for full training estimation.

        Usage:
            for epoch in estimator.epochs(sample=3):
                train_one_epoch(model, dataloader)

        Args:
            sample: Number of sample epochs to run (overrides constructor).
            total_range: Optional range object (overrides total_epochs).
        """
        if sample is not None:
            self.sample_epochs = sample
        if total_range is not None:
            self.total_epochs = len(total_range)

        self._init_benchmark()

        for i in range(self.sample_epochs):
            self._epoch_start(i)
            yield i
            self._epoch_end(i)

        self._finalize_benchmark()

    # ─── Pattern 2: Decorator ────────────────────────────────────────────

    def watch(
        self,
        sample_epochs: Optional[int] = None,
    ):
        """
        Decorator that wraps a train_epoch function. Calls it
        `sample_epochs` times and benchmarks each call.

        Usage:
            @estimator.watch(sample_epochs=3)
            def train_epoch(model, dataloader, epoch):
                for batch in dataloader:
                    ...
        """
        if sample_epochs is not None:
            self.sample_epochs = sample_epochs

        def decorator(fn: Callable) -> Callable:
            @functools.wraps(fn)
            def wrapper(*args, **kwargs):
                self._init_benchmark()
                last_result = None
                for i in range(self.sample_epochs):
                    self._epoch_start(i)
                    last_result = fn(*args, **kwargs)
                    self._epoch_end(i)
                self._finalize_benchmark()
                return last_result
            return wrapper
        return decorator

    # ─── Pattern 3: Context manager ──────────────────────────────────────

    def track(self):
        """
        Context manager for benchmarking a training block.

        Usage:
            with estimator.track():
                for epoch in range(3):
                    train_one_epoch(model, dataloader)
        """
        return _TrackContext(self)

    # ─── Pattern 4: Function wrapper ─────────────────────────────────────

    def estimate(
        self,
        train_fn: Callable,
        *args,
        sample_epochs: Optional[int] = None,
        **kwargs,
    ) -> "EstimationResult":
        """
        Run train_fn for sample_epochs iterations and estimate full training.

        The train_fn should train for ONE epoch. It will be called
        sample_epochs times.

        Usage:
            result = estimator.estimate(
                train_fn=lambda: train_one_epoch(model, loader),
                sample_epochs=3,
            )

        Args:
            train_fn: Function that trains for one epoch.
            sample_epochs: Override sample epochs count.

        Returns:
            EstimationResult with all estimates.
        """
        if sample_epochs is not None:
            self.sample_epochs = sample_epochs

        self._init_benchmark()
        for i in range(self.sample_epochs):
            self._epoch_start(i)
            train_fn(*args, **kwargs)
            self._epoch_end(i)
        self._finalize_benchmark()

        return self._result

    # ─── Manual epoch tracking ───────────────────────────────────────────

    def epoch_start(self):
        """Manually mark the start of an epoch."""
        self._epoch_start(self._current_epoch_index)

    def epoch_end(self, samples: int = 0, batches: int = 0):
        """Manually mark the end of an epoch."""
        self._samples_per_epoch = samples
        self._batches_per_epoch = batches
        self._epoch_end(self._current_epoch_index)
        self._current_epoch_index += 1

    # ─── Set dataset info ────────────────────────────────────────────────

    def set_dataset_info(
        self,
        total_size: int,
        sample_size: Optional[int] = None,
        batch_size: Optional[int] = None,
    ):
        """Set dataset size information for scaling estimation."""
        self.total_dataset_size = total_size
        if sample_size is not None:
            self.sample_dataset_size = sample_size
        if batch_size is not None:
            self._batches_per_epoch = total_size // batch_size

    # ─── Results ─────────────────────────────────────────────────────────

    def result(self) -> "EstimationResult":
        """Get the estimation result. Must be called after benchmarking."""
        if self._result is None:
            if self._epoch_metrics:
                self._finalize_benchmark()
            else:
                raise RuntimeError(
                    "No benchmark data available. Run training first using "
                    "epochs(), watch(), track(), or estimate()."
                )
        return self._result

    def generate_report(self, output_path: str = "crusoe_report.html") -> str:
        """
        Generate an HTML report and save to file.

        Args:
            output_path: Path for the output HTML file.

        Returns:
            HTML content as string.
        """
        from .report import generate_html_report

        result = self.result()
        html = generate_html_report(result)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)

        print(f"📊 Report saved to: {output_path}")
        return html

    def summary(self) -> str:
        """Print a text summary of results."""
        result = self.result()
        return _format_summary(result)

    # ─── Internal methods ────────────────────────────────────────────────

    def _init_benchmark(self):
        """Initialize benchmark state."""
        self._local_hardware = detect_gpu()
        self._epoch_metrics = []
        self._power_readings = []
        self._benchmark_start = time.time()
        self._current_epoch_index = 0

        # Warm up GPU
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.synchronize()
        except ImportError:
            pass

    def _epoch_start(self, epoch_index: int):
        """Record epoch start."""
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()
        except ImportError:
            pass

        self._current_epoch_start = time.time()

        # Sample power draw
        power = get_power_draw(self.device_index)
        if power is not None:
            self._power_readings.append(power)

    def _epoch_end(self, epoch_index: int):
        """Record epoch end and collect metrics."""
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.synchronize()
        except ImportError:
            pass

        duration = time.time() - self._current_epoch_start

        # Collect power reading
        power = get_power_draw(self.device_index)
        if power is not None:
            self._power_readings.append(power)

        # Peak memory
        peak_mem = None
        try:
            import torch
            if torch.cuda.is_available():
                peak_mem = torch.cuda.max_memory_allocated() / (1024 ** 2)
        except ImportError:
            pass

        avg_power = (
            sum(self._power_readings) / len(self._power_readings)
            if self._power_readings
            else None
        )

        metrics = EpochMetrics(
            epoch_index=epoch_index,
            duration_seconds=duration,
            samples_processed=self._samples_per_epoch,
            batches_processed=self._batches_per_epoch,
            avg_power_watts=avg_power,
            peak_memory_mb=peak_mem,
        )
        self._epoch_metrics.append(metrics)

    def _finalize_benchmark(self):
        """Calculate all estimates from collected metrics."""
        self._benchmark_end = time.time()

        if not self._epoch_metrics:
            raise RuntimeError("No epoch metrics collected.")

        # Skip first epoch (warmup) if we have more than 1
        metrics = self._epoch_metrics
        if len(metrics) > 1:
            timing_metrics = metrics[1:]  # Skip first for timing
        else:
            timing_metrics = metrics

        # Average epoch time (excluding warmup)
        avg_epoch_time = sum(m.duration_seconds for m in timing_metrics) / len(timing_metrics)

        # ── Epoch variance (coefficient of variation) ────────────────────
        if len(timing_metrics) > 1:
            mean_t = avg_epoch_time
            variance = sum((m.duration_seconds - mean_t) ** 2 for m in timing_metrics) / len(timing_metrics)
            std_dev = math.sqrt(variance)
            epoch_cv = (std_dev / mean_t) if mean_t > 0 else 0.0
        else:
            epoch_cv = 0.15  # Assume 15% uncertainty with only 1 data point

        # ── GPU Efficiency estimation ────────────────────────────────────
        gpu_efficiency = self._estimate_gpu_efficiency(timing_metrics)

        # ── Confidence scoring ───────────────────────────────────────────
        warnings: List[str] = []
        confidence = self._calculate_confidence(
            timing_metrics, epoch_cv, gpu_efficiency, warnings
        )
        if confidence >= 70:
            confidence_label = "High"
        elif confidence >= 40:
            confidence_label = "Medium"
        else:
            confidence_label = "Low"

        # Dataset scaling factor
        if self.total_dataset_size and self.sample_dataset_size and self.total_dataset_size != self.sample_dataset_size:
            dataset_scale = self.total_dataset_size / self.sample_dataset_size
        else:
            dataset_scale = 1.0

        # Estimated local total time
        estimated_local_seconds = avg_epoch_time * self.total_epochs * dataset_scale

        # Power draw
        if self.power_watts_override:
            power_w = self.power_watts_override
        elif self._power_readings:
            power_w = sum(self._power_readings) / len(self._power_readings)
        elif self._local_hardware and self._local_hardware.gpu_spec:
            power_w = self._local_hardware.gpu_spec.tdp_watts * 0.7  # ~70% TDP typical
        else:
            power_w = 200.0  # Conservative default

        # Local carbon estimate — use live CO2 intensity if available
        local_carbon = estimate_carbon(
            power_watts=power_w,
            duration_seconds=estimated_local_seconds,
            location=self.location,
            carbon_intensity_override=self._live_carbon_intensity,
        )

        # Crusoe estimates
        crusoe_estimates = {}
        carbon_savings = {}
        local_spec = self._local_hardware.gpu_spec if self._local_hardware else None

        for key, crusoe_gpu in self.crusoe_gpus.items():
            crusoe_est = self._estimate_crusoe(
                crusoe_key=key,
                crusoe_gpu=crusoe_gpu,
                local_spec=local_spec,
                local_total_seconds=estimated_local_seconds,
                avg_epoch_time=avg_epoch_time,
                gpu_efficiency=gpu_efficiency,
                epoch_cv=epoch_cv,
            )
            crusoe_estimates[key] = crusoe_est

            # Carbon savings
            crusoe_carbon = estimate_carbon(
                power_watts=crusoe_gpu.spec.tdp_watts * 0.7,  # ~70% TDP under load
                duration_seconds=crusoe_est.estimated_time_seconds,
                location="CRUSOE",
            )
            savings = estimate_carbon_savings(
                local_estimate=local_carbon,
                crusoe_power_watts=crusoe_gpu.spec.tdp_watts * 0.7,
                crusoe_duration_seconds=crusoe_est.estimated_time_seconds,
            )
            carbon_savings[key] = savings

        # ── Local electricity cost ───────────────────────────────────────
        elec_price = self._live_electricity_price
        elec_cost = local_carbon.energy_kwh * elec_price

        # ── Throughput metrics ───────────────────────────────────────────
        total_samples = sum(m.samples_processed for m in timing_metrics)
        total_batches = sum(m.batches_processed for m in timing_metrics)
        total_bench_time = sum(m.duration_seconds for m in timing_metrics)
        throughput_sps = total_samples / total_bench_time if total_bench_time > 0 and total_samples > 0 else 0.0
        throughput_bps = total_batches / total_bench_time if total_bench_time > 0 and total_batches > 0 else 0.0

        # ── Multi-GPU estimates for each Crusoe GPU ──────────────────────
        for key, est in crusoe_estimates.items():
            crusoe_gpu = self.crusoe_gpus[key]
            multi = {}
            for n_gpus in [1, 2, 4, 8]:
                if n_gpus > crusoe_gpu.max_gpus:
                    continue
                # Multi-GPU efficiency: diminishing returns
                # Amdahl-style: 1 GPU = 1x, 2 GPU ~1.85x, 4 GPU ~3.5x, 8 GPU ~6.4x
                if n_gpus == 1:
                    multi_speedup = 1.0
                else:
                    # ~92% scaling efficiency per doubling
                    multi_speedup = n_gpus * (0.92 ** math.log2(n_gpus))
                t = est.estimated_time_seconds / multi_speedup
                c = (t / 3600.0) * crusoe_gpu.price_per_gpu_hour * n_gpus
                multi[n_gpus] = {
                    "time_seconds": t,
                    "cost_usd": c,
                    "speedup_vs_local": est.speedup_vs_local * multi_speedup,
                    "multi_speedup": multi_speedup,
                }
            est.multi_gpu_estimates = multi

        self._result = EstimationResult(
            local_hardware=self._local_hardware,
            location=self.location,
            sample_epochs=self.sample_epochs,
            total_epochs=self.total_epochs,
            epoch_metrics=self._epoch_metrics,
            dataset_scale_factor=dataset_scale,
            avg_epoch_time=avg_epoch_time,
            estimated_local_time_seconds=estimated_local_seconds,
            estimated_local_time_hours=estimated_local_seconds / 3600,
            local_power_watts=power_w,
            local_carbon=local_carbon,
            crusoe_estimates=crusoe_estimates,
            carbon_savings=carbon_savings,
            local_electricity_price_kwh=elec_price,
            local_electricity_cost_usd=elec_cost,
            throughput_samples_sec=throughput_sps,
            throughput_batches_sec=throughput_bps,
            data_sources=self._data_sources,
            confidence_score=confidence,
            confidence_label=confidence_label,
            gpu_efficiency=gpu_efficiency,
            epoch_variance=epoch_cv,
            warnings=warnings,
            benchmark_start=self._benchmark_start,
            benchmark_end=self._benchmark_end,
        )

    def _estimate_gpu_efficiency(self, timing_metrics: List[EpochMetrics]) -> float:
        """
        Estimate how GPU-bound the workload is (0-100%).

        Uses multiple heuristics:
        1. CUDA event timing (if available) — most accurate
        2. Epoch time vs theoretical compute time
        3. Power draw analysis
        """
        # Method 1: Check if we have CUDA utilization data
        try:
            from .hardware import get_gpu_utilization
            util = get_gpu_utilization(self.device_index)
            if util is not None:
                gpu_util, mem_util = util
                # Weight GPU compute util more than memory util
                return min(100.0, 0.8 * gpu_util + 0.2 * mem_util)
        except Exception:
            pass

        # Method 2: Compare actual throughput vs theoretical peak
        if (self._local_hardware and self._local_hardware.gpu_spec
                and self._local_hardware.gpu_spec.fp16_tflops > 0):
            spec = self._local_hardware.gpu_spec

            # Try to estimate actual FLOPS from timing
            # For typical training: ~6 * params * batch_size * batches_per_epoch FLOPS per epoch
            # (forward + backward ≈ 3x forward, forward ≈ 2 * params * batch)
            if self._batches_per_epoch > 0:
                try:
                    import torch
                    model_params = None
                    # We can't access the model directly, so use heuristic
                except Exception:
                    pass

            # Method 3: Power-based heuristic
            # If GPU draws significantly less than TDP, it's likely not fully utilized
            if self._power_readings:
                avg_power = sum(self._power_readings) / len(self._power_readings)
                tdp = spec.tdp_watts
                if tdp > 0:
                    power_ratio = avg_power / tdp
                    # GPUs under full compute load typically draw 70-95% of TDP
                    # Map power_ratio to efficiency: 0.7→80%, 0.85→95%, <0.3→30%
                    efficiency = min(100.0, max(10.0, power_ratio * 110))
                    return efficiency

        # Method 4: Warmup ratio heuristic
        # If first epoch is MUCH slower than rest, GPU is well-utilized
        # (warmup = JIT compilation, CUDA kernel caching = GPU-bound indicators)
        #
        # Note: MPS (Apple Metal) doesn't show the same warmup behavior as CUDA,
        # so a flat warmup ratio on MPS doesn't mean low GPU utilization.
        is_mps = (self._local_hardware and self._local_hardware.device_type == "mps")

        if len(self._epoch_metrics) > 1:
            warmup_time = self._epoch_metrics[0].duration_seconds
            avg_time = sum(m.duration_seconds for m in self._epoch_metrics[1:]) / len(self._epoch_metrics[1:])
            warmup_ratio = warmup_time / avg_time if avg_time > 0 else 1.0

            if is_mps:
                # MPS doesn't have CUDA-style JIT warmup, so assume reasonably GPU-bound
                if warmup_ratio > 1.2:
                    return 80.0
                else:
                    return 70.0  # MPS training is generally GPU-bound

            if warmup_ratio > 1.3:
                # Significant warmup → likely GPU-bound (JIT, caching)
                return 75.0
            elif warmup_ratio > 1.1:
                return 60.0
            else:
                # No warmup effect → might be CPU/IO-bound
                return 45.0

        # Default: moderate uncertainty
        if is_mps:
            return 65.0
        return 50.0

    def _calculate_confidence(
        self,
        timing_metrics: List[EpochMetrics],
        epoch_cv: float,
        gpu_efficiency: float,
        warnings: List[str],
    ) -> float:
        """
        Calculate confidence score (0-100) for the estimates.

        Factors:
        - Number of sample epochs (more = better)
        - Epoch time consistency (low variance = better)
        - GPU efficiency (higher = FLOPS scaling more accurate)
        - Whether we have a known GPU spec
        """
        score = 50.0  # Start at 50

        # Factor 1: Number of sample epochs
        n_epochs = len(timing_metrics)
        if n_epochs >= 5:
            score += 15
        elif n_epochs >= 3:
            score += 10
        elif n_epochs >= 2:
            score += 5
        else:
            score -= 10
            warnings.append("Only 1 epoch measured (excluding warmup). Run more sample epochs for better accuracy.")

        # Factor 2: Epoch time consistency
        if epoch_cv < 0.05:
            score += 15  # Very consistent
        elif epoch_cv < 0.10:
            score += 10
        elif epoch_cv < 0.20:
            score += 5
        elif epoch_cv < 0.30:
            score -= 5
        else:
            score -= 15
            warnings.append(f"High epoch time variance ({epoch_cv:.0%}). Training may be I/O-bound or unstable.")

        # Factor 3: GPU efficiency
        if gpu_efficiency >= 70:
            score += 15  # GPU well-utilized → FLOPS scaling reliable
        elif gpu_efficiency >= 50:
            score += 5
        elif gpu_efficiency >= 30:
            score -= 5
            warnings.append(
                f"GPU efficiency ~{gpu_efficiency:.0f}%. Training may be CPU/data-loading bound. "
                f"Crusoe speedup estimates may be optimistic — a faster GPU won't help if the bottleneck is CPU."
            )
        else:
            score -= 15
            warnings.append(
                f"GPU efficiency very low (~{gpu_efficiency:.0f}%). The workload appears CPU/IO-bound. "
                f"FLOPS-based scaling is unreliable. Consider optimizing your DataLoader "
                f"(more workers, pin_memory, prefetch) before scaling to cloud GPUs."
            )

        # Factor 4: Known GPU spec & cross-platform penalty
        if self._local_hardware and self._local_hardware.gpu_spec:
            if self._local_hardware.gpu_spec.name.startswith("Apple"):
                # MPS→CUDA is fundamentally unreliable for time estimation.
                # FLOPS are not comparable across platforms. CUDA has tensor
                # cores, cuDNN auto-tuning, Flash Attention, fused ops — none
                # of which exist on MPS. Real error is ±100-400%.
                score -= 25
                if not any("MPS" in w for w in warnings):
                    warnings.append(
                        "⚠️ MPS→CUDA cross-platform estimation: FLOPS scaling between Apple MPS and "
                        "NVIDIA CUDA is fundamentally approximate. CUDA tensor cores, cuDNN, and "
                        "fused operations can make real performance 2-5× better than FLOPS ratio "
                        "suggests. The confidence range is wide to reflect this (±100-400% error). "
                        "Actual Crusoe performance is likely BETTER than the central estimate."
                    )
            else:
                score += 5
        else:
            score -= 20
            warnings.append(
                "GPU not found in database. Using rough estimates — "
                "confidence range is very wide (±200-500% error)."
            )

        return max(5.0, min(95.0, score))

    def _estimate_crusoe(
        self,
        crusoe_key: str,
        crusoe_gpu: CrusoeGPU,
        local_spec: Optional[GPUSpec],
        local_total_seconds: float,
        avg_epoch_time: float,
        gpu_efficiency: float = 100.0,
        epoch_cv: float = 0.0,
    ) -> CrusoeEstimate:
        """Estimate training time and cost on a specific Crusoe GPU, with ranges.

        Confidence intervals reflect the fundamental limitations of FLOPS-based
        scaling, which vary dramatically depending on source→target platform:

        - CUDA→CUDA (same gen):   ±30-50% error typical
        - CUDA→CUDA (cross gen):  ±50-100% error typical
        - MPS→CUDA:               ±100-400% error typical
          (CUDA tensor cores, cuDNN, Flash Attention, fused ops all
          dramatically outperform MPS. FLOPS ratio underestimates
          the real speedup.)
        - Unknown GPU:            ±200-500% error typical
        """

        # ── Detect cross-platform scenario ───────────────────────────────
        is_mps_source = (
            local_spec is not None
            and local_spec.name.startswith("Apple")
        )
        is_cuda_source = (
            local_spec is not None
            and not local_spec.name.startswith("Apple")
            and local_spec.fp16_tflops > 0
        )

        if local_spec and local_spec.fp16_tflops > 0:
            # Scale by FLOPS ratio (compute-bound assumption)
            compute_ratio = local_spec.fp16_tflops / crusoe_gpu.spec.fp16_tflops

            # Also consider memory bandwidth ratio
            if local_spec.memory_bandwidth_tbps > 0 and crusoe_gpu.spec.memory_bandwidth_tbps > 0:
                bw_ratio = local_spec.memory_bandwidth_tbps / crusoe_gpu.spec.memory_bandwidth_tbps
                # Weighted average: 70% compute, 30% memory bandwidth
                scaling_factor = 0.7 * compute_ratio + 0.3 * bw_ratio
            else:
                scaling_factor = compute_ratio
        else:
            # Fallback: assume Crusoe H100 is ~3x faster than average GPU
            scaling_factor = 0.33 if "H100" in crusoe_key or "H200" in crusoe_key else 0.5

        # ── Calculate ranges with HONEST uncertainty ─────────────────────
        #
        # The range reflects two independent sources of error:
        #   1. FLOPS scaling inaccuracy (platform-dependent, see docstring)
        #   2. GPU efficiency / CPU overhead (workload-dependent)
        #
        # Lower factor = faster on Crusoe (optimistic = positive surprise)
        # Higher factor = slower than expected (pessimistic)

        eff = gpu_efficiency / 100.0  # 0..1
        cpu_overhead = 1 - eff
        variance_spread = max(0.05, epoch_cv)

        if is_mps_source:
            # ── MPS → CUDA: widest range ─────────────────────────────
            # CUDA tensor cores, cuDNN, Flash Attention etc. mean the
            # real speedup is often 2-5x BETTER than raw FLOPS ratio.
            # But data loading / CPU bottlenecks can limit gains.
            #
            # Optimistic: CUDA is 2-5x better than FLOPS suggest
            #   → multiply scaling_factor by 0.2-0.5 (time is LESS)
            # Pessimistic: data loading bottleneck, scaling overestimates
            #   → multiply scaling_factor by 2-4x (time is MORE)
            optimistic_factor = scaling_factor * 0.25  # CUDA could be 4× better than FLOPS ratio
            pessimistic_multiplier = 2.0 + 2.0 * cpu_overhead  # 2× to 4×
            pessimistic_factor = scaling_factor * pessimistic_multiplier

        elif is_cuda_source:
            # ── CUDA → CUDA ──────────────────────────────────────────
            # Same ecosystem, so FLOPS scaling is more meaningful.
            # Cross-generational jumps (e.g. RTX 3090 → H100) still have
            # architecture differences (tensor core versions, HBM vs GDDR).
            flops_ratio = crusoe_gpu.spec.fp16_tflops / max(local_spec.fp16_tflops, 0.1)
            if flops_ratio > 5:  # Big generational jump
                optimistic_factor = scaling_factor * 0.5   # Could be 2× better
                pessimistic_multiplier = 1.5 + 1.5 * cpu_overhead  # 1.5× to 3×
            else:  # Similar tier
                optimistic_factor = scaling_factor * 0.7   # Could be ~1.4× better
                pessimistic_multiplier = 1.3 + 1.0 * cpu_overhead  # 1.3× to 2.3×
            pessimistic_factor = scaling_factor * pessimistic_multiplier

        else:
            # ── Unknown GPU: very wide range ─────────────────────────
            optimistic_factor = scaling_factor * 0.2
            pessimistic_factor = scaling_factor * 5.0

        # Apply epoch variance to widen range further
        optimistic_seconds = local_total_seconds * optimistic_factor * (1 - variance_spread)
        estimated_seconds = local_total_seconds * scaling_factor
        pessimistic_seconds = local_total_seconds * pessimistic_factor * (1 + variance_spread)

        # Ensure ordering
        optimistic_seconds = min(optimistic_seconds, estimated_seconds)
        pessimistic_seconds = max(pessimistic_seconds, estimated_seconds)

        estimated_hours = estimated_seconds / 3600.0
        cost = estimated_hours * crusoe_gpu.price_per_gpu_hour
        speedup = local_total_seconds / estimated_seconds if estimated_seconds > 0 else float("inf")

        # Range costs
        opt_hours = optimistic_seconds / 3600.0
        pess_hours = pessimistic_seconds / 3600.0
        cost_optimistic = opt_hours * crusoe_gpu.price_per_gpu_hour
        cost_pessimistic = pess_hours * crusoe_gpu.price_per_gpu_hour

        speedup_optimistic = local_total_seconds / optimistic_seconds if optimistic_seconds > 0 else float("inf")
        speedup_pessimistic = local_total_seconds / pessimistic_seconds if pessimistic_seconds > 0 else 1.0

        # Carbon on Crusoe (near-zero)
        crusoe_carbon = estimate_carbon(
            power_watts=crusoe_gpu.spec.tdp_watts * 0.7,
            duration_seconds=estimated_seconds,
            location="CRUSOE",
        )

        return CrusoeEstimate(
            gpu_name=crusoe_gpu.spec.name,
            gpu_key=crusoe_key,
            estimated_time_seconds=estimated_seconds,
            estimated_time_hours=estimated_hours,
            price_per_gpu_hour=crusoe_gpu.price_per_gpu_hour,
            estimated_cost_usd=cost,
            carbon_estimate=crusoe_carbon,
            speedup_vs_local=speedup,
            num_gpus=1,
            time_optimistic_seconds=optimistic_seconds,
            time_pessimistic_seconds=pessimistic_seconds,
            cost_optimistic_usd=cost_optimistic,
            cost_pessimistic_usd=cost_pessimistic,
            speedup_optimistic=speedup_optimistic,
            speedup_pessimistic=speedup_pessimistic,
        )


class _TrackContext:
    """Context manager for tracking a training block."""

    def __init__(self, estimator: CrusoeEstimator):
        self.estimator = estimator

    def __enter__(self):
        self.estimator._init_benchmark()
        self.estimator._track_start = time.time()
        return self.estimator

    def __exit__(self, exc_type, exc_val, exc_tb):
        end = time.time()
        total_time = end - self.estimator._track_start

        # If no individual epochs were tracked, treat entire block as one measurement
        if not self.estimator._epoch_metrics:
            # Infer epochs from sample_epochs
            epoch_time = total_time / self.estimator.sample_epochs
            for i in range(self.estimator.sample_epochs):
                metrics = EpochMetrics(
                    epoch_index=i,
                    duration_seconds=epoch_time,
                    samples_processed=0,
                    batches_processed=0,
                    avg_power_watts=(
                        sum(self.estimator._power_readings) / len(self.estimator._power_readings)
                        if self.estimator._power_readings
                        else None
                    ),
                )
                self.estimator._epoch_metrics.append(metrics)

        self.estimator._finalize_benchmark()
        return False  # Don't suppress exceptions


def _format_time(seconds: float) -> str:
    """Format seconds into human-readable time."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        mins = seconds / 60
        return f"{mins:.1f}min"
    elif seconds < 86400:
        hours = seconds / 3600
        return f"{hours:.1f}h"
    else:
        days = seconds / 86400
        hours = (seconds % 86400) / 3600
        return f"{days:.0f}d {hours:.0f}h"


def _format_summary(result: EstimationResult) -> str:
    """Format a text summary of the estimation result."""
    lines = []
    lines.append("=" * 60)
    lines.append("  CRUSOE TRAINING ESTIMATOR — RESULTS")
    lines.append("=" * 60)

    # Local hardware
    hw = result.local_hardware
    lines.append(f"\n🖥️  Local GPU: {hw.gpu_name}")
    if hw.gpu_spec:
        lines.append(f"   Performance: {hw.gpu_spec.fp16_tflops:.1f} TFLOPS (FP16)")
        lines.append(f"   Memory: {hw.gpu_spec.memory_gb:.0f} GB")
    lines.append(f"   Device: {hw.device_type}")

    # Data sources
    if result.data_sources:
        ds = result.data_sources
        loc_info = f"{ds.location_name}" if ds.location_name != ds.location_code else ds.location_code
        lines.append(f"\n📍 Location: {loc_info} ({ds.location_code})"
                     f" [detected via {ds.location_source}]")
        co2_label = "� live" if ds.co2_is_live else "⚪ default"
        lines.append(f"   CO₂ data: {co2_label} (source: {ds.co2_source})")
        elec_live = getattr(ds, 'electricity_is_live', False)
        elec_label = "🟢 live" if elec_live else "⚪ default"
        lines.append(f"   Electricity price: {elec_label} (source: {ds.electricity_source})")
        if hasattr(ds, 'exchange_rate') and ds.exchange_rate is not None:
            fx_label = "🟢 live" if ds.exchange_rate_source == "frankfurter.app" else "⚪ fallback"
            lines.append(f"   EUR/USD rate: {ds.exchange_rate:.4f} {fx_label} ({ds.exchange_rate_source})")

    # Confidence & GPU efficiency
    conf_emoji = "🟢" if result.confidence_score >= 70 else ("🟡" if result.confidence_score >= 40 else "🔴")
    lines.append(f"\n{conf_emoji} Confidence: {result.confidence_label} ({result.confidence_score:.0f}%)")
    lines.append(f"   GPU efficiency: ~{result.gpu_efficiency:.0f}%")
    lines.append(f"   Epoch variance: {result.epoch_variance:.1%}")

    # Warnings
    if result.warnings:
        lines.append(f"\n⚠️  WARNINGS:")
        for w in result.warnings:
            lines.append(f"   • {w}")

    # Benchmark info
    lines.append(f"\n📏 Benchmark: {result.sample_epochs} sample epochs "
                 f"→ {result.total_epochs} total epochs")
    lines.append(f"   Avg epoch time: {_format_time(result.avg_epoch_time)}")
    if result.dataset_scale_factor != 1.0:
        lines.append(f"   Dataset scale: {result.dataset_scale_factor:.1f}x")
    if result.throughput_samples_sec > 0:
        lines.append(f"   Throughput: {result.throughput_samples_sec:.1f} samples/sec")

    # Local estimate
    lines.append(f"\n⏱️  Estimated LOCAL training time: "
                 f"{_format_time(result.estimated_local_time_seconds)}")
    lines.append(f"   Energy: {result.local_carbon.energy_kwh:.2f} kWh")
    lines.append(f"   💡 Electricity cost: ${result.local_electricity_cost_usd:.2f} "
                 f"(${result.local_electricity_price_kwh:.2f}/kWh in {result.location})")
    lines.append(f"   CO2: {result.local_carbon.carbon_g:.1f}g "
                 f"({result.location}, {result.local_carbon.carbon_intensity} kg/kWh)")

    # Crusoe estimates with ranges
    lines.append(f"\n☁️  CRUSOE CLOUD ESTIMATES:")
    lines.append("-" * 50)

    for key, est in result.crusoe_estimates.items():
        lines.append(f"\n  {est.gpu_name}:")
        lines.append(f"    Time: {_format_time(est.estimated_time_seconds)} "
                     f"({est.speedup_vs_local:.1f}x faster)")
        lines.append(f"    Range: {_format_time(est.time_optimistic_seconds)} – "
                     f"{_format_time(est.time_pessimistic_seconds)} "
                     f"({est.speedup_optimistic:.0f}x – {est.speedup_pessimistic:.0f}x)")
        lines.append(f"    Cost: ${est.estimated_cost_usd:.2f} "
                     f"(${est.cost_optimistic_usd:.2f} – ${est.cost_pessimistic_usd:.2f})")
        lines.append(f"           ${est.price_per_gpu_hour:.2f}/hr")
        # Multi-GPU
        if est.multi_gpu_estimates:
            multi_parts = []
            for n_gpus, mdata in sorted(est.multi_gpu_estimates.items()):
                if n_gpus == 1:
                    continue
                multi_parts.append(
                    f"{n_gpus}x GPU: {_format_time(mdata['time_seconds'])} / ${mdata['cost_usd']:.2f}"
                )
            if multi_parts:
                lines.append(f"    Multi-GPU: {' │ '.join(multi_parts)}")
        savings = result.carbon_savings[key]
        lines.append(f"    CO2 saved: {savings['savings_g']:.1f}g "
                     f"({savings['savings_percent']:.0f}% reduction)")

    # Best option
    best_key = min(result.crusoe_estimates, key=lambda k: result.crusoe_estimates[k].estimated_cost_usd)
    best = result.crusoe_estimates[best_key]
    lines.append(f"\n💡 Best value: {best.gpu_name} — "
                 f"${best.estimated_cost_usd:.2f} "
                 f"(${best.cost_optimistic_usd:.2f}–${best.cost_pessimistic_usd:.2f}), "
                 f"{best.speedup_vs_local:.1f}x faster")

    fastest_key = min(result.crusoe_estimates, key=lambda k: result.crusoe_estimates[k].estimated_time_seconds)
    fastest = result.crusoe_estimates[fastest_key]
    lines.append(f"⚡ Fastest: {fastest.gpu_name} — "
                 f"{_format_time(fastest.estimated_time_seconds)}, "
                 f"${fastest.estimated_cost_usd:.2f}")

    # ── Savings summary ──────────────────────────────────────────────────
    total_savings = result.carbon_savings[best_key]
    time_saved = result.estimated_local_time_seconds - best.estimated_time_seconds
    money_vs_electricity = result.local_electricity_cost_usd - best.estimated_cost_usd

    lines.append(f"\n📊 SAVINGS WITH CRUSOE ({best.gpu_name}):")
    lines.append(f"   ⏱️  Time saved: {_format_time(time_saved)}")
    if money_vs_electricity > 0:
        lines.append(f"   💰 Cheaper than local electricity by ${money_vs_electricity:.2f}")
    else:
        lines.append(f"   💰 Cloud cost vs local electricity: +${-money_vs_electricity:.2f}")
    lines.append(f"   🌍 CO2 saved: {total_savings['savings_g']:.1f}g "
                 f"({total_savings['savings_percent']:.0f}% reduction)")
    lines.append(f"   ≈ {total_savings['equivalent_km_saved']:.1f} km not driven by car")

    lines.append("\n" + "=" * 60)
    return "\n".join(lines)
