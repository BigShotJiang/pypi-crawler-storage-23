"""
Carbon emissions calculation module.

Estimates CO2 emissions from GPU training based on power consumption
and regional electricity carbon intensity.
"""

from dataclasses import dataclass
from typing import Optional


# Carbon intensity by country/region in kg CO2 per kWh
# Source: IEA, Ember, European Environment Agency (2024 data)
CARBON_INTENSITY: dict[str, float] = {
    # World
    "WORLD": 0.475,

    # Europe
    "EU": 0.230,
    "HR": 0.170,   # Croatia / Hrvatska
    "DE": 0.340,   # Germany
    "FR": 0.056,   # France (nuclear heavy)
    "PL": 0.660,   # Poland (coal heavy)
    "UK": 0.210,   # United Kingdom
    "IT": 0.330,   # Italy
    "ES": 0.180,   # Spain
    "NL": 0.340,   # Netherlands
    "SE": 0.013,   # Sweden
    "NO": 0.008,   # Norway (hydro)
    "FI": 0.070,   # Finland
    "AT": 0.090,   # Austria
    "BE": 0.160,   # Belgium
    "CZ": 0.430,   # Czech Republic
    "DK": 0.120,   # Denmark
    "PT": 0.170,   # Portugal
    "RO": 0.280,   # Romania
    "BG": 0.420,   # Bulgaria
    "HU": 0.220,   # Hungary
    "SK": 0.130,   # Slovakia
    "SI": 0.220,   # Slovenia
    "RS": 0.650,   # Serbia
    "BA": 0.600,   # Bosnia and Herzegovina
    "CH": 0.015,   # Switzerland
    "IE": 0.300,   # Ireland
    "GR": 0.380,   # Greece

    # Americas
    "US": 0.390,
    "CA": 0.120,
    "BR": 0.070,
    "MX": 0.430,

    # Asia-Pacific
    "CN": 0.560,   # China
    "IN": 0.710,   # India
    "JP": 0.460,   # Japan
    "KR": 0.420,   # South Korea
    "AU": 0.660,   # Australia
    "SG": 0.400,   # Singapore
    "TW": 0.510,   # Taiwan

    # Middle East / Africa
    "SA": 0.680,   # Saudi Arabia
    "AE": 0.410,   # UAE
    "ZA": 0.870,   # South Africa
    "IL": 0.460,   # Israel

    # Crusoe Cloud - near zero emissions (renewable/waste gas energy)
    "CRUSOE": 0.000,
}

# Aliases for convenience
CARBON_INTENSITY["CROATIA"] = CARBON_INTENSITY["HR"]
CARBON_INTENSITY["HRVATSKA"] = CARBON_INTENSITY["HR"]
CARBON_INTENSITY["GERMANY"] = CARBON_INTENSITY["DE"]
CARBON_INTENSITY["FRANCE"] = CARBON_INTENSITY["FR"]
CARBON_INTENSITY["POLAND"] = CARBON_INTENSITY["PL"]
CARBON_INTENSITY["SPAIN"] = CARBON_INTENSITY["ES"]
CARBON_INTENSITY["ITALY"] = CARBON_INTENSITY["IT"]
CARBON_INTENSITY["SWEDEN"] = CARBON_INTENSITY["SE"]
CARBON_INTENSITY["NORWAY"] = CARBON_INTENSITY["NO"]
CARBON_INTENSITY["USA"] = CARBON_INTENSITY["US"]
CARBON_INTENSITY["CANADA"] = CARBON_INTENSITY["CA"]
CARBON_INTENSITY["BRAZIL"] = CARBON_INTENSITY["BR"]
CARBON_INTENSITY["CHINA"] = CARBON_INTENSITY["CN"]
CARBON_INTENSITY["INDIA"] = CARBON_INTENSITY["IN"]
CARBON_INTENSITY["JAPAN"] = CARBON_INTENSITY["JP"]
CARBON_INTENSITY["AUSTRALIA"] = CARBON_INTENSITY["AU"]
CARBON_INTENSITY["SWITZERLAND"] = CARBON_INTENSITY["CH"]


# ─── Electricity Prices by Country (EUR/kWh → converted to USD/kWh) ─────────
# Sources: Eurostat, EIA, IEA (2024/2025 household rates, inc. taxes)
# Using 1 EUR ≈ 1.08 USD for European prices
ELECTRICITY_PRICE: dict[str, float] = {
    # Europe (Eurostat household prices 2024 H2, EUR→USD)
    "HR": 0.14,    # Croatia — ~0.13 EUR/kWh
    "DE": 0.37,    # Germany — highest in EU
    "FR": 0.23,    # France
    "PL": 0.18,    # Poland
    "UK": 0.31,    # United Kingdom
    "IT": 0.27,    # Italy
    "ES": 0.22,    # Spain
    "NL": 0.30,    # Netherlands
    "SE": 0.22,    # Sweden
    "NO": 0.18,    # Norway
    "FI": 0.20,    # Finland
    "AT": 0.28,    # Austria
    "BE": 0.33,    # Belgium
    "CZ": 0.24,    # Czech Republic
    "DK": 0.36,    # Denmark
    "PT": 0.22,    # Portugal
    "RO": 0.15,    # Romania
    "BG": 0.12,    # Bulgaria — cheapest in EU
    "HU": 0.11,    # Hungary (subsidized)
    "SK": 0.19,    # Slovakia
    "SI": 0.20,    # Slovenia
    "RS": 0.08,    # Serbia
    "BA": 0.09,    # Bosnia and Herzegovina
    "CH": 0.27,    # Switzerland
    "IE": 0.30,    # Ireland
    "GR": 0.20,    # Greece
    "EU": 0.25,    # EU average

    # Americas
    "US": 0.16,    # US average (EIA 2024)
    "CA": 0.13,    # Canada
    "BR": 0.14,    # Brazil
    "MX": 0.09,    # Mexico

    # Asia-Pacific
    "CN": 0.08,    # China
    "IN": 0.08,    # India
    "JP": 0.26,    # Japan
    "KR": 0.12,    # South Korea
    "AU": 0.25,    # Australia
    "SG": 0.22,    # Singapore
    "TW": 0.09,    # Taiwan

    # Middle East / Africa
    "SA": 0.05,    # Saudi Arabia (subsidized)
    "AE": 0.08,    # UAE
    "ZA": 0.09,    # South Africa
    "IL": 0.17,    # Israel

    # Special
    "WORLD": 0.18, # World average
    "CRUSOE": 0.0, # Crusoe — included in GPU pricing
}

# Aliases
for _alias, _code in [
    ("CROATIA", "HR"), ("HRVATSKA", "HR"), ("GERMANY", "DE"), ("FRANCE", "FR"),
    ("POLAND", "PL"), ("SPAIN", "ES"), ("ITALY", "IT"), ("SWEDEN", "SE"),
    ("NORWAY", "NO"), ("USA", "US"), ("CANADA", "CA"), ("BRAZIL", "BR"),
    ("CHINA", "CN"), ("INDIA", "IN"), ("JAPAN", "JP"), ("AUSTRALIA", "AU"),
    ("SWITZERLAND", "CH"), ("UNITED KINGDOM", "UK"),
]:
    ELECTRICITY_PRICE[_alias] = ELECTRICITY_PRICE[_code]


def get_electricity_price(location: str) -> float:
    """
    Get electricity price (USD per kWh) for a given location.

    Args:
        location: Country code (ISO 3166-1 alpha-2) or name.

    Returns:
        Electricity price in USD per kWh.
    """
    key = location.upper().strip()
    if key in ELECTRICITY_PRICE:
        return ELECTRICITY_PRICE[key]

    # Try partial matching
    for k, v in ELECTRICITY_PRICE.items():
        if key in k or k in key:
            return v

    return ELECTRICITY_PRICE["WORLD"]


@dataclass
class CarbonEstimate:
    """CO2 emission estimate for a training run."""
    energy_kwh: float           # Total energy consumed in kWh
    carbon_kg: float            # Total CO2 emissions in kg
    carbon_g: float             # Total CO2 emissions in grams
    carbon_intensity: float     # kg CO2 per kWh used
    location: str               # Location code
    power_watts: float          # Average power draw in watts
    duration_hours: float       # Training duration in hours

    @property
    def equivalent_km_driven(self) -> float:
        """Equivalent km driven by average car (120g CO2/km)."""
        return self.carbon_g / 120.0

    @property
    def equivalent_trees_yearly(self) -> float:
        """Number of trees needed to absorb this CO2 in a year (22kg CO2/tree/year)."""
        return self.carbon_kg / 22.0

    @property
    def equivalent_smartphone_charges(self) -> float:
        """Equivalent smartphone charges (0.012 kWh per charge)."""
        return self.energy_kwh / 0.012


def get_carbon_intensity(location: str) -> float:
    """
    Get carbon intensity for a given location.

    Args:
        location: Country code (ISO 3166-1 alpha-2), region name,
                  or 'CRUSOE' for Crusoe Cloud.

    Returns:
        Carbon intensity in kg CO2 per kWh.
    """
    key = location.upper().strip()
    if key in CARBON_INTENSITY:
        return CARBON_INTENSITY[key]

    # Try partial matching
    for k, v in CARBON_INTENSITY.items():
        if key in k or k in key:
            return v

    # Default to world average
    return CARBON_INTENSITY["WORLD"]


def estimate_carbon(
    power_watts: float,
    duration_seconds: float,
    location: str = "WORLD",
    carbon_intensity_override: Optional[float] = None,
) -> CarbonEstimate:
    """
    Estimate CO2 emissions for a given power consumption and duration.

    Args:
        power_watts: Average power draw in watts.
        duration_seconds: Total training duration in seconds.
        location: Country/region code for carbon intensity.
        carbon_intensity_override: If set, use this value (kg CO2/kWh)
                                    instead of looking up from database.

    Returns:
        CarbonEstimate with all emission details.
    """
    duration_hours = duration_seconds / 3600.0
    energy_kwh = (power_watts / 1000.0) * duration_hours
    if carbon_intensity_override is not None:
        intensity = carbon_intensity_override
    else:
        intensity = get_carbon_intensity(location)
    carbon_kg = energy_kwh * intensity

    return CarbonEstimate(
        energy_kwh=energy_kwh,
        carbon_kg=carbon_kg,
        carbon_g=carbon_kg * 1000,
        carbon_intensity=intensity,
        location=location.upper(),
        power_watts=power_watts,
        duration_hours=duration_hours,
    )


def estimate_carbon_savings(
    local_estimate: CarbonEstimate,
    crusoe_power_watts: float,
    crusoe_duration_seconds: float,
) -> dict:
    """
    Calculate CO2 savings from using Crusoe Cloud vs local training.

    Returns dict with savings details.
    """
    crusoe_estimate = estimate_carbon(
        power_watts=crusoe_power_watts,
        duration_seconds=crusoe_duration_seconds,
        location="CRUSOE",
    )

    savings_kg = local_estimate.carbon_kg - crusoe_estimate.carbon_kg
    savings_pct = (savings_kg / local_estimate.carbon_kg * 100) if local_estimate.carbon_kg > 0 else 100.0

    return {
        "local": local_estimate,
        "crusoe": crusoe_estimate,
        "savings_kg": savings_kg,
        "savings_g": savings_kg * 1000,
        "savings_percent": savings_pct,
        "equivalent_km_saved": savings_kg * 1000 / 120.0,
        "equivalent_trees": savings_kg / 22.0,
    }


def list_locations() -> dict[str, float]:
    """Return all available locations and their carbon intensities."""
    return CARBON_INTENSITY.copy()
