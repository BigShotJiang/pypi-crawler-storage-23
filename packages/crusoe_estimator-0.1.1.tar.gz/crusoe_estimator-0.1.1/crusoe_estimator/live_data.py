"""
Live data fetching module.

Fetches real-time CO2 carbon intensity, electricity prices, exchange
rates, and auto-detects user location via IP geolocation.

Data sources:
- CO2 intensity: Electricity Maps API (https://electricitymap.org)
- Location: ipapi.co / ipinfo.io / freeipapi.com (HTTPS, free, no key)
- Electricity prices: Eurostat API (EU, free, no key) + ENTSO-E (EU, needs key)
- Exchange rates: frankfurter.app (ECB data, free, no key)

All functions gracefully fall back to defaults on network errors.
"""

import json
import os
import time
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Optional, Dict, Tuple

# ─── Cache ────────────────────────────────────────────────────────────────────
# Simple in-memory cache with TTL to avoid hammering APIs
_cache: Dict[str, Tuple[float, object]] = {}  # key → (timestamp, value)
_CACHE_TTL = 600  # 10 minutes
_CACHE_TTL_LONG = 86400  # 24 hours (for slowly-changing data like exchange rates)


def _cache_get(key: str) -> Optional[object]:
    """Get a cached value if not expired (10 min TTL)."""
    if key in _cache:
        ts, val = _cache[key]
        if time.time() - ts < _CACHE_TTL:
            return val
    return None


def _cache_set(key: str, value: object):
    """Set a cached value (10 min TTL)."""
    _cache[key] = (time.time(), value)


def _cache_get_long(key: str) -> Optional[object]:
    """Get a cached value with long TTL (24h — for exchange rates, Eurostat)."""
    if key in _cache:
        ts, val = _cache[key]
        if time.time() - ts < _CACHE_TTL_LONG:
            return val
    return None


def _cache_set_long(key: str, value: object):
    """Set a cached value with long TTL marker (uses same store)."""
    _cache[key] = (time.time(), value)


# ─── HTTP helper ──────────────────────────────────────────────────────────────

def _fetch_json(url: str, headers: Optional[dict] = None, timeout: float = 5.0) -> Optional[dict]:
    """Fetch JSON from a URL. Returns None on any error."""
    try:
        req = urllib.request.Request(url)
        if headers:
            for k, v in headers.items():
                req.add_header(k, v)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


# ─── Live Exchange Rates ──────────────────────────────────────────────────────

def _fetch_exchange_rate(from_currency: str = "EUR", to_currency: str = "USD") -> float:
    """
    Fetch live exchange rate from frankfurter.app (ECB data, free, no key).

    Falls back to a conservative default if the API is unavailable.
    Cached for 24 hours (rates update daily).

    Returns:
        Exchange rate (e.g. 1.08 for EUR→USD).
    """
    cache_key = f"fx_{from_currency}_{to_currency}"
    cached = _cache_get_long(cache_key)
    if cached is not None:
        return cached

    data = _fetch_json(
        f"https://api.frankfurter.app/latest?from={from_currency}&to={to_currency}",
        headers={"User-Agent": "Python/crusoe-estimator"},
    )

    if data and "rates" in data and to_currency in data["rates"]:
        rate = float(data["rates"][to_currency])
        _cache_set_long(cache_key, rate)
        return rate

    # Fallback: conservative estimate
    _FALLBACK_RATES = {"EUR_USD": 1.08, "GBP_USD": 1.25, "USD_EUR": 0.93}
    return _FALLBACK_RATES.get(f"{from_currency}_{to_currency}", 1.0)


# ─── Eurostat Electricity Prices ──────────────────────────────────────────────

# EU country codes available in Eurostat nrg_pc_204 dataset
_EUROSTAT_COUNTRIES = {
    "HR", "DE", "FR", "PL", "IT", "ES", "NL", "SE", "NO", "FI",
    "AT", "BE", "CZ", "DK", "PT", "RO", "BG", "HU", "SK", "SI",
    "GR", "IE", "CH", "UK", "EE", "LV", "LT", "LU", "MT", "CY",
}


def _fetch_eurostat_electricity_price(country_code: str) -> Optional[float]:
    """
    Fetch household electricity price from Eurostat API (free, no key).

    Uses dataset nrg_pc_204 (electricity prices for household consumers).
    Returns price in EUR/kWh including all taxes and levies.

    Eurostat updates semi-annually (S1 = Jan-Jun, S2 = Jul-Dec).
    Cached for 24 hours.

    Args:
        country_code: ISO 3166-1 alpha-2 (e.g. "HR", "DE").

    Returns:
        Price in EUR/kWh, or None if unavailable.
    """
    cc = country_code.upper()
    if cc not in _EUROSTAT_COUNTRIES:
        return None

    cache_key = f"eurostat_elec_{cc}"
    cached = _cache_get_long(cache_key)
    if cached is not None:
        return cached

    # Special mapping: Greece uses "EL" in Eurostat
    eurostat_geo = "EL" if cc == "GR" else cc

    # Query: household electricity prices, all taxes included, EUR/kWh
    # We don't filter by time — get all available, pick the latest
    url = (
        f"https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/"
        f"nrg_pc_204?format=JSON&geo={eurostat_geo}"
        f"&unit=KWH&tax=I_TAX&currency=EUR"
    )

    data = _fetch_json(url, timeout=10.0)
    if not data or "value" not in data or not data["value"]:
        return None

    try:
        # Parse Eurostat JSON-stat flat format
        # We need to find the latest time period and a reasonable consumption band
        dimensions = data.get("id", [])
        sizes = data.get("size", [])
        dim_info = data.get("dimension", {})

        if not dimensions or not sizes:
            return None

        # Build dimension index maps
        dim_indices = {}
        for dim_name in dimensions:
            cat = dim_info.get(dim_name, {}).get("category", {})
            idx = cat.get("index", {})
            label = cat.get("label", {})
            dim_indices[dim_name] = {"index": idx, "label": label}

        # Find the time dimension — pick latest available period
        time_idx = dim_indices.get("time", {}).get("index", {})
        if not time_idx:
            return None

        # Sort time periods to find latest (e.g. "2024-S2" > "2024-S1" > "2023-S2")
        latest_time = max(time_idx.keys())
        latest_time_pos = time_idx[latest_time]

        # Find consumption band dimension — pick band DD (5000-15000 kWh/year)
        # which is the most representative for typical EU households
        nrg_cons_idx = dim_indices.get("nrg_cons", {}).get("index", {})
        target_band_pos = None
        band_source = "average"

        if nrg_cons_idx:
            # Try bands in order of preference
            for band_code in ["MRN_5000-14999", "MRN_2500-4999", "TOT_KWH"]:
                if band_code in nrg_cons_idx:
                    target_band_pos = nrg_cons_idx[band_code]
                    band_source = band_code
                    break

        # Compute flat index for the target combination
        # Flat index = sum(pos_i * product(sizes[i+1:]))
        values = data["value"]

        # Strategy: collect all values for latest time period, take median
        # This is simpler and handles unknown band codes
        dim_positions = {}
        for i, dim_name in enumerate(dimensions):
            if dim_name == "time":
                dim_positions[i] = latest_time_pos
            elif dim_name == "nrg_cons" and target_band_pos is not None:
                dim_positions[i] = target_band_pos
            # Other dimensions (freq, siec, unit, tax, currency, geo)
            # should have size 1 since we filtered them in the query
            else:
                dim_positions[i] = 0

        # Compute flat index
        flat_idx = 0
        for i in range(len(dimensions)):
            pos = dim_positions.get(i, 0)
            stride = 1
            for j in range(i + 1, len(dimensions)):
                stride *= sizes[j]
            flat_idx += pos * stride

        price_eur = values.get(str(flat_idx))
        if price_eur is not None and isinstance(price_eur, (int, float)):
            _cache_set_long(cache_key, float(price_eur))
            return float(price_eur)

        # If exact index didn't work, try finding any value for latest time
        # by scanning all values for the latest time position
        time_dim_idx = dimensions.index("time") if "time" in dimensions else -1
        if time_dim_idx >= 0:
            time_stride = 1
            for j in range(time_dim_idx + 1, len(dimensions)):
                time_stride *= sizes[j]

            collected = []
            for idx_str, val in values.items():
                idx = int(idx_str)
                # Check if this index corresponds to the latest time
                pos_in_time = (idx // time_stride) % sizes[time_dim_idx]
                if pos_in_time == latest_time_pos and isinstance(val, (int, float)):
                    collected.append(val)

            if collected:
                # Take median of available prices (across different bands)
                collected.sort()
                median_price = collected[len(collected) // 2]
                _cache_set_long(cache_key, median_price)
                return median_price

    except Exception:
        pass

    return None


# ─── Location Detection ──────────────────────────────────────────────────────

@dataclass
class DetectedLocation:
    """Auto-detected location from IP geolocation."""
    country_code: str       # ISO 3166-1 alpha-2 (e.g. "HR")
    country_name: str       # Full name (e.g. "Croatia")
    city: str               # City name
    region: str             # Region/state
    timezone: str           # IANA timezone
    lat: float              # Latitude
    lon: float              # Longitude
    source: str             # "ip-api" or "fallback"


def detect_location() -> DetectedLocation:
    """
    Auto-detect the user's location from their IP address.

    Tries multiple free HTTPS geolocation APIs in order:
    1. ipapi.co (HTTPS, free, no key, 1000 req/day)
    2. ipinfo.io (HTTPS, free, no key, 50k req/month)
    3. freeipapi.com (HTTPS, free, no key)

    Falls back to "WORLD" if all fail.
    """
    cached = _cache_get("location")
    if cached:
        return cached

    # Try ipapi.co first (most reliable, HTTPS)
    data = _fetch_json(
        "https://ipapi.co/json/",
        headers={"User-Agent": "Python/crusoe-estimator"},
    )
    if data and data.get("country_code") and not data.get("error"):
        loc = DetectedLocation(
            country_code=data.get("country_code", "WORLD"),
            country_name=data.get("country_name", "Unknown"),
            city=data.get("city", ""),
            region=data.get("region", ""),
            timezone=data.get("timezone", ""),
            lat=data.get("latitude", 0.0),
            lon=data.get("longitude", 0.0),
            source="ipapi.co",
        )
        _cache_set("location", loc)
        return loc

    # Try ipinfo.io as fallback
    data = _fetch_json(
        "https://ipinfo.io/json",
        headers={"User-Agent": "Python/crusoe-estimator"},
    )
    if data and data.get("country"):
        # ipinfo.io returns "loc": "lat,lon" format
        lat, lon = 0.0, 0.0
        if data.get("loc"):
            try:
                lat, lon = [float(x) for x in data["loc"].split(",")]
            except (ValueError, IndexError):
                pass
        loc = DetectedLocation(
            country_code=data.get("country", "WORLD"),
            country_name=data.get("country", "Unknown"),  # ipinfo doesn't give full name
            city=data.get("city", ""),
            region=data.get("region", ""),
            timezone=data.get("timezone", ""),
            lat=lat,
            lon=lon,
            source="ipinfo.io",
        )
        _cache_set("location", loc)
        return loc

    # Try freeipapi.com as last resort
    data = _fetch_json(
        "https://freeipapi.com/api/json",
        headers={"User-Agent": "Python/crusoe-estimator"},
    )
    if data and data.get("countryCode"):
        loc = DetectedLocation(
            country_code=data.get("countryCode", "WORLD"),
            country_name=data.get("countryName", "Unknown"),
            city=data.get("cityName", ""),
            region=data.get("regionName", ""),
            timezone=data.get("timeZone", ""),
            lat=data.get("latitude", 0.0),
            lon=data.get("longitude", 0.0),
            source="freeipapi.com",
        )
        _cache_set("location", loc)
        return loc

    # All failed — fallback
    return DetectedLocation(
        country_code="WORLD",
        country_name="Unknown",
        city="",
        region="",
        timezone="",
        lat=0.0,
        lon=0.0,
        source="fallback",
    )


# ─── Electricity Maps Zone Mapping ───────────────────────────────────────────
# Electricity Maps uses zones like "HR", "DE", "FR" for most countries.
# Some countries (US, CA, AU) have sub-zones. We map to the most common one.

_COUNTRY_TO_ZONE: Dict[str, str] = {
    # Most European countries map 1:1
    "US": "US-MIDA-PJM",     # PJM (largest US grid, covers east coast)
    "CA": "CA-ON",           # Ontario
    "AU": "AU-NSW",          # New South Wales
    "BR": "BR-S",            # South Brazil
    "IN": "IN-WE",           # Western India
    "JP": "JP-TK",           # Tokyo
}


def _country_to_zone(country_code: str) -> str:
    """Map country code to Electricity Maps zone."""
    return _COUNTRY_TO_ZONE.get(country_code.upper(), country_code.upper())


# ─── Live CO2 Carbon Intensity ───────────────────────────────────────────────

@dataclass
class LiveCarbonData:
    """Live carbon intensity data from Electricity Maps."""
    carbon_intensity: float     # gCO2eq/kWh
    zone: str                   # Electricity Maps zone
    source: str                 # "electricity-maps", "fallback"
    is_live: bool               # True if fetched live, False if fallback
    timestamp: str              # ISO timestamp or "N/A"


def fetch_carbon_intensity(
    location: str,
    api_key: Optional[str] = None,
) -> LiveCarbonData:
    """
    Fetch live CO2 carbon intensity for a location.

    Uses Electricity Maps API if API key is available (via parameter or
    ELECTRICITY_MAPS_API_KEY env var). Falls back to hardcoded defaults.

    Free API key: register at https://api-portal.electricitymaps.com/

    Args:
        location: Country code (e.g. "HR") or Electricity Maps zone.
        api_key: Electricity Maps API key. If None, reads from
                 ELECTRICITY_MAPS_API_KEY environment variable.

    Returns:
        LiveCarbonData with carbon intensity in gCO2eq/kWh.
    """
    zone = _country_to_zone(location)
    cache_key = f"co2_{zone}"
    cached = _cache_get(cache_key)
    if cached:
        return cached

    # Get API key
    key = api_key or os.environ.get("ELECTRICITY_MAPS_API_KEY", "")

    if key:
        # Electricity Maps API v3
        url = f"https://api.electricitymap.org/v3/carbon-intensity/latest?zone={zone}"
        headers = {"auth-token": key}
        data = _fetch_json(url, headers=headers)

        if data and "carbonIntensity" in data:
            result = LiveCarbonData(
                carbon_intensity=data["carbonIntensity"],  # gCO2eq/kWh
                zone=data.get("zone", zone),
                source="electricity-maps",
                is_live=True,
                timestamp=data.get("datetime", ""),
            )
            _cache_set(cache_key, result)
            return result

    # Try CO2signal (same company, alternative endpoint — free, no key for some zones)
    url = f"https://api.co2signal.com/v1/latest?countryCode={location.upper()}"
    data = _fetch_json(url)
    if data and "data" in data and "carbonIntensity" in data["data"]:
        result = LiveCarbonData(
            carbon_intensity=data["data"]["carbonIntensity"],
            zone=location.upper(),
            source="co2signal",
            is_live=True,
            timestamp=data.get("updatedAt", ""),
        )
        _cache_set(cache_key, result)
        return result

    # Fallback: use hardcoded defaults
    from .carbon import CARBON_INTENSITY
    fallback = CARBON_INTENSITY.get(location.upper(), 0.475) * 1000  # kg→g
    return LiveCarbonData(
        carbon_intensity=fallback,
        zone=location.upper(),
        source="fallback",
        is_live=False,
        timestamp="N/A",
    )


# ─── Live Electricity Prices ─────────────────────────────────────────────────
# Pipeline: Eurostat (EU, free) → ENTSO-E (EU, needs key) → hardcoded fallback
# Exchange rates fetched live from frankfurter.app (ECB, free).

# Per-country tax/distribution markup for ENTSO-E wholesale → household price
# Source: Eurostat analysis of price components (taxes, levies, network costs)
_ENTSO_E_TAX_MARKUP: Dict[str, float] = {
    "DE": 1.90,  # Germany: high taxes (~90% markup)
    "DK": 1.85,  # Denmark: high taxes
    "BE": 1.60,  # Belgium
    "AT": 1.55,  # Austria
    "NL": 1.50,  # Netherlands
    "IT": 1.45,  # Italy
    "FR": 1.40,  # France
    "PT": 1.35,  # Portugal
    "ES": 1.30,  # Spain
    "IE": 1.30,  # Ireland
    "SE": 1.30,  # Sweden
    "FI": 1.30,  # Finland
    "GR": 1.35,  # Greece
    "SI": 1.30,  # Slovenia
    "HR": 1.25,  # Croatia
    "CZ": 1.35,  # Czech Republic
    "PL": 1.30,  # Poland
    "SK": 1.30,  # Slovakia
    "RO": 1.25,  # Romania
    "BG": 1.20,  # Bulgaria
    "HU": 1.15,  # Hungary (heavily subsidized)
    "NO": 1.25,  # Norway
    "CH": 1.35,  # Switzerland
    "UK": 1.40,  # UK
}

def fetch_electricity_price(
    location: str,
    api_key: Optional[str] = None,
) -> Tuple[float, str]:
    """
    Fetch electricity price for a location.

    Pipeline (tries in order):
    1. Eurostat API — official EU household prices (free, no key, semi-annual)
    2. ENTSO-E API — EU day-ahead wholesale prices (needs key, converts to
       household with per-country markup + live EUR/USD rate)
    3. Hardcoded fallback — based on 2024 Eurostat/IEA/EIA data

    Args:
        location: Country code (e.g. "HR", "DE").
        api_key: ENTSO-E API key. If None, reads from ENTSOE_API_KEY env var.

    Returns:
        Tuple of (price_usd_per_kwh, source_name).
    """
    cache_key = f"elec_{location.upper()}"
    cached = _cache_get(cache_key)
    if cached:
        return cached

    cc = location.upper()

    # ── Source 1: Eurostat (EU countries, free, no key needed) ────────────
    if cc in _EUROSTAT_COUNTRIES:
        eur_price = _fetch_eurostat_electricity_price(cc)
        if eur_price is not None:
            # Convert EUR → USD using live exchange rate
            eur_usd = _fetch_exchange_rate("EUR", "USD")
            usd_price = eur_price * eur_usd
            result = (round(usd_price, 4), "eurostat-live")
            _cache_set(cache_key, result)
            return result

    # ── Source 2: ENTSO-E (EU countries, needs API key) ──────────────────
    eu_zones = {
        "HR", "DE", "FR", "PL", "IT", "ES", "NL", "SE", "NO", "FI",
        "AT", "BE", "CZ", "DK", "PT", "RO", "BG", "HU", "SK", "SI",
        "GR", "IE", "CH", "UK",
    }

    key = api_key or os.environ.get("ENTSOE_API_KEY", "")

    if key and cc in eu_zones:
        # ENTSO-E domain mapping
        domain_map = {
            "HR": "10YHR-HEP------M",
            "DE": "10Y1001A1001A83F",
            "FR": "10YFR-RTE------C",
            "PL": "10YPL-AREA-----S",
            "IT": "10YIT-GRTN-----B",
            "ES": "10YES-REE------0",
            "NL": "10YNL----------L",
            "SE": "10YSE-1--------K",
            "NO": "10YNO-0--------C",
            "FI": "10YFI-1--------U",
            "AT": "10YAT-APG------L",
            "BE": "10YBE----------2",
            "CZ": "10YCZ-CEPS-----N",
            "DK": "10Y1001A1001A65H",
            "PT": "10YPT-REN------W",
            "RO": "10YRO-TEL------P",
            "BG": "10YCA-BULGARIA-R",
            "HU": "10YHU-MAVIR----U",
            "SK": "10YSK-SEPS-----K",
            "SI": "10YSI-ELES-----O",
            "GR": "10YGR-HTSO-----Y",
            "IE": "10YIE-1001A00010",
            "CH": "10YCH-SWISSGRIDZ",
            "UK": "10YGB----------A",
        }

        domain = domain_map.get(location.upper())
        if domain:
            from datetime import datetime, timezone
            now = datetime.now(timezone.utc)
            period_start = now.strftime("%Y%m%d0000")
            period_end = now.strftime("%Y%m%d2300")

            url = (
                f"https://web-api.tp.entsoe.eu/api?"
                f"securityToken={key}"
                f"&documentType=A44"
                f"&in_Domain={domain}"
                f"&out_Domain={domain}"
                f"&periodStart={period_start}"
                f"&periodEnd={period_end}"
            )

            try:
                req = urllib.request.Request(url)
                with urllib.request.urlopen(req, timeout=10) as resp:
                    body = resp.read().decode("utf-8")
                    # Parse XML for day-ahead prices
                    # Simple extraction: find all <price.amount> values
                    import re
                    prices = re.findall(r"<price\.amount>([\d.]+)</price\.amount>", body)
                    if prices:
                        avg_eur_mwh = sum(float(p) for p in prices) / len(prices)
                        # Convert EUR/MWh → USD/kWh using live exchange rate
                        eur_usd = _fetch_exchange_rate("EUR", "USD")
                        # Apply per-country tax/distribution markup
                        markup = _ENTSO_E_TAX_MARKUP.get(cc, 1.30)
                        avg_usd_kwh = (avg_eur_mwh / 1000) * eur_usd * markup
                        result = (round(avg_usd_kwh, 4), "entsoe-live")
                        _cache_set(cache_key, result)
                        return result
            except Exception:
                pass

    # Fallback to hardcoded
    from .carbon import ELECTRICITY_PRICE
    price = ELECTRICITY_PRICE.get(location.upper(), ELECTRICITY_PRICE.get("WORLD", 0.18))
    result = (price, "default")
    _cache_set(cache_key, result)
    return result


# ─── Data Source Info ─────────────────────────────────────────────────────────

@dataclass
class DataSources:
    """Information about which data sources were used."""
    co2_source: str = "fallback"       # "electricity-maps", "co2signal", "fallback"
    co2_is_live: bool = False
    co2_timestamp: str = "N/A"
    electricity_source: str = "default"  # "eurostat-live", "entsoe-live", "default", "user-override"
    electricity_is_live: bool = False
    exchange_rate_source: str = "none"   # "frankfurter.app", "fallback", "none"
    exchange_rate: Optional[float] = None  # EUR/USD rate used
    location_source: str = "user"        # "ipapi.co", "ipinfo.io", "freeipapi.com", "user", "fallback"
    location_code: str = "WORLD"
    location_name: str = "Unknown"


def get_all_live_data(
    location: Optional[str] = None,
    electricity_maps_key: Optional[str] = None,
    entsoe_key: Optional[str] = None,
    electricity_price_override: Optional[float] = None,
) -> Tuple[str, float, float, DataSources]:
    """
    Get all live data needed for estimation in one call.

    Auto-detects location if not provided, fetches live CO2 intensity
    and electricity prices.

    Args:
        location: Country code. Auto-detected from IP if None.
        electricity_maps_key: API key for Electricity Maps.
        entsoe_key: API key for ENTSO-E electricity prices.
        electricity_price_override: Manual electricity price in USD/kWh.

    Returns:
        Tuple of (location_code, carbon_intensity_kg_per_kwh,
                  electricity_price_usd_per_kwh, DataSources).
    """
    sources = DataSources()

    # ── Location ─────────────────────────────────────────────────────────
    if location:
        sources.location_source = "user"
        sources.location_code = location.upper()
        sources.location_name = location.upper()
    else:
        detected = detect_location()
        sources.location_source = detected.source
        sources.location_code = detected.country_code
        sources.location_name = f"{detected.city}, {detected.country_name}" if detected.city else detected.country_name
        location = detected.country_code

    # ── CO2 intensity ────────────────────────────────────────────────────
    co2_data = fetch_carbon_intensity(location, api_key=electricity_maps_key)
    carbon_intensity_kg = co2_data.carbon_intensity / 1000.0  # g → kg

    sources.co2_source = co2_data.source
    sources.co2_is_live = co2_data.is_live
    sources.co2_timestamp = co2_data.timestamp

    # ── Electricity price ────────────────────────────────────────────────
    if electricity_price_override is not None:
        elec_price = electricity_price_override
        sources.electricity_source = "user-override"
    else:
        elec_price, elec_source = fetch_electricity_price(location, api_key=entsoe_key)
        sources.electricity_source = elec_source
        sources.electricity_is_live = elec_source in ("eurostat-live", "entsoe-live")

    # ── Exchange rate info ───────────────────────────────────────────────
    # Check if we fetched a live rate (it'll be cached if so)
    fx_cached = _cache_get_long("fx_EUR_USD")
    if fx_cached is not None:
        sources.exchange_rate_source = "frankfurter.app"
        sources.exchange_rate = fx_cached
    elif sources.electricity_is_live:
        sources.exchange_rate_source = "fallback"
        sources.exchange_rate = 1.08

    return (location.upper(), carbon_intensity_kg, elec_price, sources)
