"""
GPU specifications database and Crusoe Cloud pricing.

Contains performance specs for common consumer/workstation GPUs and
Crusoe Cloud GPU offerings with pricing information.
"""

from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class GPUSpec:
    """Specification for a single GPU model."""
    name: str
    fp16_tflops: float          # FP16 Tensor Core TFLOPS (dense)
    memory_gb: float            # GPU memory in GB
    memory_bandwidth_tbps: float  # Memory bandwidth in TB/s
    tdp_watts: float            # Thermal Design Power in watts
    architecture: str           # GPU architecture name


@dataclass
class CrusoeGPU:
    """Crusoe Cloud GPU offering with pricing."""
    spec: GPUSpec
    price_per_gpu_hour: float   # USD per GPU per hour
    min_gpus: int = 1
    max_gpus: int = 8
    co2_kg_per_kwh: float = 0.0  # Crusoe uses ~100% renewable energy


# ─── Known GPU Specifications ────────────────────────────────────────────────

KNOWN_GPUS: Dict[str, GPUSpec] = {
    # NVIDIA Data Center
    "A100-SXM4-80GB": GPUSpec("A100 80GB SXM", 312.0, 80, 2.039, 400, "Ampere"),
    "A100-SXM4-40GB": GPUSpec("A100 40GB SXM", 312.0, 40, 2.039, 400, "Ampere"),
    "A100-PCIE-80GB": GPUSpec("A100 80GB PCIe", 312.0, 80, 2.039, 300, "Ampere"),
    "A100-PCIE-40GB": GPUSpec("A100 40GB PCIe", 312.0, 40, 1.555, 250, "Ampere"),
    "H100-SXM": GPUSpec("H100 SXM", 989.4, 80, 3.35, 700, "Hopper"),
    "H100-PCIE": GPUSpec("H100 PCIe", 756.0, 80, 2.0, 350, "Hopper"),
    "H200-SXM": GPUSpec("H200 SXM", 989.4, 141, 4.8, 700, "Hopper"),
    "V100-SXM2-32GB": GPUSpec("V100 32GB", 125.0, 32, 0.9, 300, "Volta"),
    "V100-SXM2-16GB": GPUSpec("V100 16GB", 125.0, 16, 0.9, 300, "Volta"),
    "T4": GPUSpec("T4", 65.0, 16, 0.3, 70, "Turing"),

    # AMD Data Center
    "MI300X": GPUSpec("MI300X", 1307.4, 192, 5.3, 750, "CDNA 3"),
    "MI250X": GPUSpec("MI250X", 383.0, 128, 3.2, 560, "CDNA 2"),

    # NVIDIA Consumer - RTX 40 series
    "RTX 4090": GPUSpec("RTX 4090", 330.3, 24, 1.008, 450, "Ada Lovelace"),
    "RTX 4080 SUPER": GPUSpec("RTX 4080 SUPER", 206.1, 16, 0.736, 320, "Ada Lovelace"),
    "RTX 4080": GPUSpec("RTX 4080", 206.1, 16, 0.716, 320, "Ada Lovelace"),
    "RTX 4070 Ti SUPER": GPUSpec("RTX 4070 Ti SUPER", 184.6, 16, 0.672, 285, "Ada Lovelace"),
    "RTX 4070 Ti": GPUSpec("RTX 4070 Ti", 184.6, 12, 0.504, 285, "Ada Lovelace"),
    "RTX 4070 SUPER": GPUSpec("RTX 4070 SUPER", 140.7, 12, 0.504, 220, "Ada Lovelace"),
    "RTX 4070": GPUSpec("RTX 4070", 122.4, 12, 0.504, 200, "Ada Lovelace"),
    "RTX 4060 Ti": GPUSpec("RTX 4060 Ti", 88.5, 8, 0.288, 160, "Ada Lovelace"),
    "RTX 4060": GPUSpec("RTX 4060", 73.7, 8, 0.272, 115, "Ada Lovelace"),

    # NVIDIA Consumer - RTX 30 series
    "RTX 3090 Ti": GPUSpec("RTX 3090 Ti", 160.0, 24, 1.008, 450, "Ampere"),
    "RTX 3090": GPUSpec("RTX 3090", 142.0, 24, 0.936, 350, "Ampere"),
    "RTX 3080 Ti": GPUSpec("RTX 3080 Ti", 136.0, 12, 0.912, 350, "Ampere"),
    "RTX 3080": GPUSpec("RTX 3080", 119.0, 10, 0.760, 320, "Ampere"),
    "RTX 3070 Ti": GPUSpec("RTX 3070 Ti", 87.0, 8, 0.608, 290, "Ampere"),
    "RTX 3070": GPUSpec("RTX 3070", 81.0, 8, 0.512, 220, "Ampere"),
    "RTX 3060 Ti": GPUSpec("RTX 3060 Ti", 65.0, 8, 0.448, 200, "Ampere"),
    "RTX 3060": GPUSpec("RTX 3060", 51.0, 12, 0.360, 170, "Ampere"),

    # NVIDIA Consumer - RTX 20 series
    "RTX 2080 Ti": GPUSpec("RTX 2080 Ti", 53.8, 11, 0.616, 250, "Turing"),
    "RTX 2080 SUPER": GPUSpec("RTX 2080 SUPER", 45.2, 8, 0.496, 250, "Turing"),
    "RTX 2080": GPUSpec("RTX 2080", 40.3, 8, 0.448, 215, "Turing"),
    "RTX 2070 SUPER": GPUSpec("RTX 2070 SUPER", 36.4, 8, 0.448, 215, "Turing"),
    "RTX 2070": GPUSpec("RTX 2070", 29.2, 8, 0.384, 175, "Turing"),
    "RTX 2060 SUPER": GPUSpec("RTX 2060 SUPER", 28.6, 8, 0.384, 175, "Turing"),
    "RTX 2060": GPUSpec("RTX 2060", 22.2, 6, 0.336, 160, "Turing"),

    # NVIDIA Laptop GPUs (common ones)
    "RTX 4090 Laptop": GPUSpec("RTX 4090 Laptop", 228.0, 16, 0.576, 150, "Ada Lovelace"),
    "RTX 4080 Laptop": GPUSpec("RTX 4080 Laptop", 164.0, 12, 0.432, 150, "Ada Lovelace"),
    "RTX 4070 Laptop": GPUSpec("RTX 4070 Laptop", 117.0, 8, 0.384, 115, "Ada Lovelace"),
    "RTX 4060 Laptop": GPUSpec("RTX 4060 Laptop", 88.5, 8, 0.256, 115, "Ada Lovelace"),
    "RTX 3080 Laptop": GPUSpec("RTX 3080 Laptop", 93.0, 16, 0.448, 150, "Ampere"),
    "RTX 3070 Laptop": GPUSpec("RTX 3070 Laptop", 64.0, 8, 0.384, 130, "Ampere"),
    "RTX 3060 Laptop": GPUSpec("RTX 3060 Laptop", 48.0, 6, 0.336, 115, "Ampere"),

    # Apple Silicon (MPS)
    "Apple M1": GPUSpec("Apple M1", 2.6, 16, 0.068, 20, "Apple Silicon"),
    "Apple M1 Pro": GPUSpec("Apple M1 Pro", 5.3, 16, 0.2, 30, "Apple Silicon"),
    "Apple M1 Max": GPUSpec("Apple M1 Max", 10.6, 32, 0.4, 40, "Apple Silicon"),
    "Apple M1 Ultra": GPUSpec("Apple M1 Ultra", 21.2, 64, 0.8, 60, "Apple Silicon"),
    "Apple M2": GPUSpec("Apple M2", 3.6, 16, 0.1, 22, "Apple Silicon"),
    "Apple M2 Pro": GPUSpec("Apple M2 Pro", 6.8, 16, 0.2, 30, "Apple Silicon"),
    "Apple M2 Max": GPUSpec("Apple M2 Max", 13.6, 32, 0.4, 40, "Apple Silicon"),
    "Apple M2 Ultra": GPUSpec("Apple M2 Ultra", 27.2, 64, 0.8, 60, "Apple Silicon"),
    "Apple M3": GPUSpec("Apple M3", 4.1, 24, 0.1, 22, "Apple Silicon"),
    "Apple M3 Pro": GPUSpec("Apple M3 Pro", 7.4, 18, 0.15, 30, "Apple Silicon"),
    "Apple M3 Max": GPUSpec("Apple M3 Max", 14.2, 36, 0.3, 40, "Apple Silicon"),
    "Apple M4": GPUSpec("Apple M4", 4.6, 16, 0.12, 22, "Apple Silicon"),
    "Apple M4 Pro": GPUSpec("Apple M4 Pro", 8.3, 24, 0.273, 30, "Apple Silicon"),
    "Apple M4 Max": GPUSpec("Apple M4 Max", 16.5, 36, 0.546, 40, "Apple Silicon"),
}

# ─── Crusoe Cloud GPU Offerings ─────────────────────────────────────────────

CRUSOE_GPUS: Dict[str, CrusoeGPU] = {
    "A100-80GB": CrusoeGPU(
        spec=GPUSpec("NVIDIA A100 80GB", 312.0, 80, 2.039, 400, "Ampere"),
        price_per_gpu_hour=1.47,
        min_gpus=1,
        max_gpus=8,
    ),
    "H100": CrusoeGPU(
        spec=GPUSpec("NVIDIA H100 SXM", 989.4, 80, 3.35, 700, "Hopper"),
        price_per_gpu_hour=2.25,
        min_gpus=1,
        max_gpus=8,
    ),
    "H200": CrusoeGPU(
        spec=GPUSpec("NVIDIA H200 SXM", 989.4, 141, 4.8, 700, "Hopper"),
        price_per_gpu_hour=3.25,
        min_gpus=1,
        max_gpus=8,
    ),
    "MI300X": CrusoeGPU(
        spec=GPUSpec("AMD MI300X", 1307.4, 192, 5.3, 750, "CDNA 3"),
        price_per_gpu_hour=2.49,
        min_gpus=1,
        max_gpus=8,
    ),
}


def match_gpu(gpu_name: str) -> Optional[GPUSpec]:
    """
    Try to match a detected GPU name to our database.
    Uses fuzzy matching on known GPU names.
    """
    gpu_name_upper = gpu_name.upper()

    # Direct match attempts
    for key, spec in KNOWN_GPUS.items():
        if key.upper() in gpu_name_upper or spec.name.upper() in gpu_name_upper:
            return spec

    # Partial matching - try extracting model number
    import re

    # Try matching patterns like "RTX 4090", "A100", "H100", etc.
    patterns = [
        r"(RTX\s*\d{4}\s*(Ti|SUPER)?(\s*Laptop)?)",
        r"(A100|H100|H200|V100|T4|MI\d+X?)",
        r"(M[1-4]\s*(Pro|Max|Ultra)?)",
    ]

    for pattern in patterns:
        match = re.search(pattern, gpu_name, re.IGNORECASE)
        if match:
            matched_name = match.group(1).strip()
            for key, spec in KNOWN_GPUS.items():
                if matched_name.upper().replace(" ", "") in key.upper().replace(" ", ""):
                    return spec
                if matched_name.upper().replace(" ", "") in spec.name.upper().replace(" ", ""):
                    return spec

    return None


def get_crusoe_gpus() -> Dict[str, CrusoeGPU]:
    """Return all available Crusoe Cloud GPU offerings."""
    return CRUSOE_GPUS.copy()


def list_supported_gpus() -> list:
    """List all GPU names in the database."""
    return list(KNOWN_GPUS.keys())
