"""Chirp extensions — optional integrations (chirp-ui, etc.)."""
