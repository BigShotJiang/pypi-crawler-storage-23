"""Internal utilities — not part of the public API."""
