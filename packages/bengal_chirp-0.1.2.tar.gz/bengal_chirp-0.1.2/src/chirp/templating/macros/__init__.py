"""Chirp template macros — shipped as importable Kida components."""
