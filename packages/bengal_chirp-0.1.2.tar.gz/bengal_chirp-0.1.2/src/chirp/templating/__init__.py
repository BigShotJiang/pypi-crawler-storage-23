"""Kida template integration — not a dependency, a feature.

Provides Template, Fragment, and Stream return types with
direct kida rendering support.
"""
