"""Real-time — Server-Sent Events and EventStream.

Push kida-rendered HTML fragments to the browser over SSE.
No WebSocket protocol upgrade, no special infrastructure.
"""
