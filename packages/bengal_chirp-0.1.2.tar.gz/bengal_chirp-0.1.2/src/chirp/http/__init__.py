"""HTTP abstractions — Request, Response, Headers, QueryParams, FormData.

This subpackage has zero internal dependencies. It can be tested and
reasoned about in complete isolation.
"""
