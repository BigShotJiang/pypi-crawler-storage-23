"""Server — ASGI handler and development server.

The only layer that touches ASGI directly and performs I/O.
"""
