"""
ucis.ncdb — Native Coverage Database (NCDB) backend.

ZIP-based binary format for efficient storage of UCIS coverage data.
See COVERAGE_FILE_FORMAT_DESIGN.md for the format specification.
"""
