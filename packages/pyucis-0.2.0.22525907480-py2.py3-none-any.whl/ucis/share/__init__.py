"""PyUCIS AgentSkills package.

This package contains the AgentSkills definition for PyUCIS, which provides
detailed information about PyUCIS capabilities for LLM agents.
"""

__all__ = []
