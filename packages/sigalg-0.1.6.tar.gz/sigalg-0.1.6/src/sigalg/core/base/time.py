"""Time module.

This module provides the `Time` class, which represents time indices for
stochastic processes and other objects. Time indices can be discrete (integer-valued) or continuous (real-valued).

Classes
-------
Time
    Represents a time index for temporal processes.

Examples
--------
>>> from sigalg.core import Time
>>> # Discrete time
>>> time_discrete = Time.discrete(start=0, length=5)
>>> time_discrete # doctest: +NORMALIZE_WHITESPACE
Time 'T':
[0, 1, 2, 3, 4, 5]
>>> # Continuous time
>>> time_continuous = Time.continuous(start=0.0, stop=1.0, num_points=9)
>>> time_continuous # doctest: +NORMALIZE_WHITESPACE
Time 'T':
[0.0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1.0]
"""

from __future__ import annotations

from collections.abc import Hashable
from numbers import Real

import numpy as np
import pandas as pd

from ...validation.time_in import TimeIn
from .index import Index


# TODO: review docstrings
class Time(Index):
    """A class representing a time index.

    Parameters
    ----------
    name : Hashable | None, default="T"
        Name identifier for the index.
    data_name : Hashable | None, default="time"
        Name for the internal `pd.Index`.

    Examples
    --------
    >>> from sigalg.core import Time
    >>> # Discrete time
    >>> time_discrete = Time.discrete(start=0, length=5)
    >>> time_discrete # doctest: +NORMALIZE_WHITESPACE
    Time 'T':
    [0, 1, 2, 3, 4, 5]
    >>> # Continuous time
    >>> time_continuous = Time.continuous(start=0.0, stop=1.0, num_points=9)
    >>> time_continuous # doctest: +NORMALIZE_WHITESPACE
    Time 'T':
    [0.0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1.0]
    """

    # --------------------- constructors --------------------- #

    def __init__(
        self,
        name: Hashable | None = "T",
        data_name: Hashable | None = "time",
    ) -> None:
        super().__init__(name=name, data_name=data_name)

    def from_list(
        self,
        indices: list[Real],
        is_discrete: bool = True,
    ) -> Index:
        """Create a `Time` from a list of time points.

        The time points can represent either discrete time steps (integers) or
        continuous time points (real numbers). They must be monotonically
        increasing and are used as the temporal dimension for stochastic processes and other objects.

        Parameters
        ----------
        indices : list[Real]
            List of real-valued time points to use for the index.
        is_discrete : bool, default=True
            Whether the time index represents discrete (`True`) or continuous (`False`) time.

        Returns
        -------
        self : Time
            The current `Time` instance with updated indices.
        """
        v = TimeIn(indices=indices, is_discrete=is_discrete)
        self.is_discrete = v.is_discrete
        self._indices = v.indices
        return self

    # --------------------- factory methods --------------------- #

    @classmethod
    def discrete(
        cls,
        length: int | None = None,
        start: int = 0,
        stop: int | None = None,
        name: Hashable | None = "T",
        data_name: Hashable | None = "time",
    ) -> Time:
        """Create a discrete time index with integer time steps.

        Generates a time index with consecutive integer time points starting
        from the specified `start`. The user may pass either the `length` of the time interval, or the `stop` value, but not both. The relation between the three parameters is `length = stop - start`.

        Parameters
        ----------
        length : int | None, default=None
            Number of time points to generate. Must be positive.
        start : int, default=0
            Starting time point.
        stop : int | None, default=None
            Ending time point. Mutually exclusive with `length`.
        name : Hashable | None, default="T"
            Name identifier for the index.
        data_name : Hashable | None, default="time"
            Name for the internal `pd.Index`.

        Returns
        -------
        time : Time
            A discrete time index with integer time points.

        Raises
        ------
        ValueError
            If `length` is not a positive integer or if `stop` is not an integer greater than `start`, or if both `length` and `stop` are specified, or if neither is specified.
        TypeError
            If `start` is not an integer.

        Examples
        --------
        >>> from sigalg.core import Time
        >>> time = Time.discrete(start=0, length=5)
        >>> list(time)
        [0, 1, 2, 3, 4, 5]
        >>> time.is_discrete
        True
        """
        if not isinstance(start, int):
            raise TypeError("start must be an integer.")
        if length is not None and (not isinstance(length, int) or length <= 0):
            raise ValueError("length must be a positive integer.")
        if stop is not None and (not isinstance(stop, int) or stop <= start):
            raise ValueError("stop must be an integer greater than start.")
        if length is not None and stop is not None:
            raise ValueError("Specify exactly one of length or stop.")
        if length is None and stop is None:
            raise ValueError("Specify exactly one of length or stop.")

        if stop is not None:
            length = stop - start

        indices = list(range(start, start + length + 1))
        return cls(name=name, data_name=data_name).from_list(indices, is_discrete=True)

    @classmethod
    def continuous(
        cls,
        start: Real,
        stop: Real,
        dt: Real | None = None,
        num_points: int | None = None,
        name: Hashable | None = "T",
        data_name: Hashable | None = "time",
    ) -> Time:
        """Create a continuous time index with real-valued time points.

        Generates a time index with real-valued time points either by specifying
        the time step (`dt`) or the number of points (`num_points`). Exactly one of
        these parameters must be provided.

        Parameters
        ----------
        start : Real
            Starting time point.
        stop : Real
            Ending time point.
        dt : Real, optional
            Time step between consecutive points. Mutually exclusive with `num_points`.
        num_points : int, optional
            Number of evenly-spaced points to generate. Mutually exclusive with `dt`.
        name : Hashable | None, default="T"
            Name identifier for the index.
        data_name : Hashable | None, default="time"
            Name for the internal `pd.Index`.

        Returns
        -------
        time : Time
            A continuous time index with real-valued time points.

        Raises
        ------
        ValueError
            If both `dt` and `num_points` are specified, or if neither is specified. Also raised if `start` is not less than `stop`, or if `dt` is not positive, or if `num_points` is less than 2.
        TypeError
            If `start`, `stop`, or `dt` (if given) are not real numbers, or if `num_points` (if given) is not an integer.

        Examples
        --------
        >>> from sigalg.core import Time
        >>> # Using num_points
        >>> time1 = Time.continuous(start=0.0, stop=1.0, num_points=3)
        >>> list(time1)
        [0.0, 0.5, 1.0]
        >>> # Using dt
        >>> time2 = Time.continuous(start=0.0, stop=1.0, dt=0.25)
        >>> len(time2)
        5
        """
        if (dt is None) == (num_points is None):
            raise ValueError("Specify exactly one of dt or num_points.")
        if not isinstance(start, Real) or not isinstance(stop, Real):
            raise TypeError("start and stop must be real numbers.")
        if start >= stop:
            raise ValueError("start must be less than stop.")
        if dt is not None and (not isinstance(dt, Real) or dt <= 0):
            raise ValueError("If given, dt must be a positive real number.")
        if num_points is not None and (
            not isinstance(num_points, int) or num_points < 2
        ):
            raise ValueError("If given, num_points must be an integer >= 2.")
        if num_points is not None:
            indices = list(np.linspace(start, stop, num_points))
        else:
            num_steps = int(np.round((stop - start) / dt)) + 1
            indices = list(np.linspace(start, stop, num_steps))
        return cls(name=name, data_name=data_name).from_list(indices, is_discrete=False)

    # --------------------- data access methods --------------------- #

    def _getitem_hook(self, pos: int | list[int] | slice) -> Time:
        """Internal hook for indexing operations.

        This method is called by `__getitem__` from the parent `Index` class. In `Time`, the purpose of this method is to ensure that `__getitem__` returns an instance of `Time`. Times are retrieved by position.

        Parameters
        ----------
        pos : int | list[int] | slice
            Index, slice, or other key for accessing elements positionally.

        Returns
        -------
        time : Time
            A `Time` object containing the indexed time points.

        Examples
        --------
        >>> from sigalg.core import Time
        >>> time = Time.discrete(start=0, length=5)
        >>> print(time) # doctest: +NORMALIZE_WHITESPACE
        Time 'T':
        [0, 1, 2, 3, 4, 5]
        >>> # Access via integer index
        >>> print(time[0])
        0
        >>> # Access via slice
        >>> print(time[1:3]) # doctest: +NORMALIZE_WHITESPACE
        Time:
        [1, 2]
        >>> # Access via list of positions
        >>> print(time[[0, 2]]) # doctest: +NORMALIZE_WHITESPACE
        Time:
        [0, 2]
        """  # noqa: D401
        if not isinstance(pos, (int, list, slice)):
            raise TypeError("pos must be int | list[int] | slice.")
        if isinstance(pos, list) and not all(isinstance(i, int) for i in pos):
            raise TypeError("pos list must contain only int.")

        data = self.data[pos]
        if isinstance(data, pd.Index):
            return Time(data_name=self.data.name, name=None).from_list(
                indices=data.to_list(), is_discrete=self.is_discrete
            )
        else:
            return data

    def find_nearest_time(self, time_point: Real) -> Real:
        """Find the nearest time point to the given value.

        Parameters
        ----------
        time_point : Real
            The time point to find the nearest index for.

        Returns
        -------
        time : Real
            The nearest time point in the Time index.

        Raises
        ------
        ValueError
            If the Time index is empty.
        """
        if len(self) == 0:
            raise ValueError("Time index is empty.")
        array = np.array(self.data)
        if time_point < array[0]:
            raise ValueError(
                f"time_point {time_point} is before the start of the Time index."
            )
        if time_point > array[-1]:
            raise ValueError(
                f"time_point {time_point} is after the end of the Time index."
            )
        nearest_idx = (np.abs(array - time_point)).argmin()
        return self.data[nearest_idx]

    def insert_time(self, time: Real) -> Time:
        """Insert a new time point into the Time index.

        Parameters
        ----------
        time : Real
            The time point to insert. Must be an integer for discrete Time indices.

        Raises
        ------
        TypeError
            If `time` is not a real number.
        ValueError
            If the Time index is empty or if `time` already exists in the Time index.

        Returns
        -------
        new_time : Time
            A new Time object with the inserted time point.
        """
        if not isinstance(time, Real):
            raise TypeError("time must be a real number.")
        if self.data is None:
            raise ValueError("Time index is empty.")
        if time in self.data:
            raise ValueError(f"time {time} already exists in the Time index.")

        data = self.data.copy()
        pos = data.searchsorted(time)
        new_data = data.insert(pos, time)
        new_name = f"insert({self.name})" if self.name is not None else None
        new_time = Time(data_name=self.data.name, name=new_name).from_pandas(new_data)
        new_time.is_discrete = self.is_discrete
        return new_time

    def remove_time(self, time: Real | None = None, pos: int | None = None) -> Time:
        """Remove a time point from the Time index.

        Parameters
        ----------
        time : Real | None, default=None
            The time point to remove. Must be specified if `pos` is not provided.
        pos : int | None, default=None
            The position of the time point to remove. Must be specified if `time` is not provided.

        Raises
        ------
        TypeError
            If `time` is not a real number or `pos` is not an integer.
        ValueError
            If the Time index is empty, if `time` does not exist in the Time index, if `pos` is out of bounds, if both `time` and `pos` are provided, or if neither is provided.

        Returns
        -------
        new_time : Time
            A new Time object with the specified time point removed.
        """
        if self.data is None:
            raise ValueError("Time index is empty.")
        if time is not None and not isinstance(time, Real):
            raise TypeError("If provided, time must be a real number.")
        if pos is not None and not isinstance(pos, int):
            raise TypeError("If provided, pos must be an integer.")
        if time is not None and time not in self.data:
            raise ValueError(f"time {time} does not exist in the Time index.")
        if time is None and pos is None:
            raise ValueError("Either time or pos must be specified.")
        if time is not None and pos is not None:
            raise ValueError("Only one of time or pos must be specified.")
        if pos is not None and (pos < 0 or pos >= len(self.data)):
            raise ValueError(f"pos {pos} is out of bounds.")

        data = self.data.copy()
        if pos is None:
            pos = data.get_loc(time)
        new_data = data.delete(pos)
        new_name = f"remove({self.name})" if self.name is not None else None
        new_time = Time(data_name=self.data.name, name=new_name).from_pandas(new_data)
        new_time.is_discrete = self.is_discrete
        return new_time

    # --------------------- representation --------------------- #

    def __repr__(self) -> str:
        """Return a string representation of the index.

        Returns
        -------
        repr_str : str
            String representation of the index.
        """
        if self.name is None:
            return f"Time:\n{self.data.to_list()}"
        else:
            return f"Time '{self.name}':\n{self.data.to_list()}"

    # --------------------- equality --------------------- #

    def __eq__(self, other: Time) -> bool:
        """Check equality with another time index.

        Two time indices are equal if they have the same time points in the
        same order and the same discrete/continuous flag.

        Parameters
        ----------
        other : object
            Another object to compare with.

        Returns
        -------
        is_equal : bool
            `True` if the other object is a `Time` with identical values and
            `is_discrete` flag, `False` otherwise.
        """
        return (
            isinstance(other, Time)
            and super().__eq__(other)
            and self.is_discrete == other.is_discrete
        )
