from .base import L2  # noqa: D104

__all__ = ["L2"]
