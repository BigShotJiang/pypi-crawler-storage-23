[![PyPI version](https://img.shields.io/pypi/v/sigalg.svg)](https://pypi.org/project/sigalg/) [![Python versions](https://img.shields.io/pypi/pyversions/sigalg.svg)](https://pypi.org/project/sigalg/) [![License](https://img.shields.io/pypi/l/sigalg.svg)](https://github.com/jmyers7/sigalg/blob/main/LICENSE) [![Status](https://img.shields.io/pypi/status/sigalg.svg)](https://pypi.org/project/sigalg/) [![codecov](https://codecov.io/gh/jmyers7/sigalg/branch/main/graph/badge.svg?token=DORWUC3G6R)](https://codecov.io/gh/jmyers7/sigalg)

Click the pic ↓↓↓↓↓↓

[![docs](landing.png)](https://johnmyers-phd.com/sigalg/)

