GOOGLE_DRIVE_EXPORT_TYPES = {
    "application/vnd.google-apps.document": "application/"
    "vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.google-apps.spreadsheet": "application/"
    "vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.google-apps.presentation": "application/"
    "vnd.openxmlformats-officedocument.presentationml.presentation",
    "application/vnd.google-apps.photo": "image/jpeg",
}
