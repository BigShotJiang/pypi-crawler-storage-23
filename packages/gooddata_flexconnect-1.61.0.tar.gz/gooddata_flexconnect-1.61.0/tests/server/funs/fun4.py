#  (C) 2024 GoodData Corporation
import time

import pyarrow
from gooddata_flexconnect.function.function import FlexConnectFunction
from gooddata_flight_server import ArrowData

_DATA: pyarrow.Table | None = None


class _PollableFun(FlexConnectFunction):
    Name = "PollableFun"
    Schema = pyarrow.schema(
        fields=[
            pyarrow.field("col1", pyarrow.int64()),
            pyarrow.field("col2", pyarrow.string()),
            pyarrow.field("col3", pyarrow.bool_()),
        ]
    )

    def call(
        self,
        parameters: dict,
        columns: tuple[str, ...] | None,
        headers: dict[str, list[str]],
    ) -> ArrowData:
        # sleep is intentionally setup to be longer than one polling interval
        # (see conftest.py // flexconnect_server fixture)
        time.sleep(0.7)

        return pyarrow.table(
            data={
                "col1": [1, 2, 3],
                "col2": ["a", "b", "c"],
                "col3": [True, False, True],
            },
            schema=self.Schema,
        )
