## 0.2.1 (2026-02-23)

### Chore

- added py.typed marker for PEP 561 compliance

## 0.2.0 (2025-11-16)

### Fix

- context as BaseContext

## 0.1.1 (2025-11-16)

### Feat

- fastapi inject decorator
