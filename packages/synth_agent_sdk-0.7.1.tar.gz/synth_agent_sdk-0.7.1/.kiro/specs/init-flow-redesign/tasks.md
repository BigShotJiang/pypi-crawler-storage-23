# Implementation Plan: Init Flow Redesign

## Overview

Refactor `synth/cli/init_cmd.py` to fix the `bedrock/` prefix bug, split `_run_agentcore_setup()` into two focused functions, reorder the init wizard steps, and add a post-generation deploy prompt. All changes are in a single file.

## Tasks

- [x] 1. Implement `_run_model_selection()` and fix the bedrock prefix bug
  - [x] 1.1 Create `_run_model_selection(provider, cfg, agentcore_state)` function
    - Extract model selection logic from `_run_agentcore_setup()` into a new function
    - Accept `provider: str`, `cfg: dict[str, str]`, and `agentcore_state: dict[str, Any] | None = None`
    - For AgentCore: prompt region, display models via `RegionValidator`, get effective model ID, prepend `bedrock/` if not already prefixed, write `aws_region` and `cris_enabled` into `agentcore_state`
    - For non-AgentCore: return `cfg["model"]` directly
    - Use lazy imports for `CredentialResolver`, `ModelCatalog`, `RegionValidator`
    - _Requirements: 1.1, 1.3, 2.2, 2.3, 2.4_

  - [ ]* 1.2 Write property tests for `_run_model_selection()`
    - **Property 1: Bedrock prefix correctness**
    - **Validates: Requirements 1.1, 1.3, 2.3**
    - **Property 2: Non-AgentCore model passthrough**
    - **Validates: Requirements 2.4**
    - File: `tests/property/test_prop_init_flow_redesign.py`

- [x] 2. Implement `_run_credential_check()` and remove `_run_agentcore_setup()`
  - [x] 2.1 Create `_run_credential_check()` function
    - Extract credential detection logic from `_run_agentcore_setup()` into a new function
    - Return `dict` with `aws_profile` key
    - Use lazy import for `CredentialResolver`
    - Match existing credential detection behavior (resolve → confirm/decline → fallback prompt)
    - _Requirements: 2.1, 2.5_

  - [x] 2.2 Remove `_run_agentcore_setup()` function
    - Delete the old function entirely after both new functions are in place
    - _Requirements: 2.6_

- [x] 3. Rewrite `run_init()` with new step order
  - [x] 3.1 Update `run_init()` step sequence
    - Reorder to: name → description → provider → model selection → instructions → tool wizard → MCP wizard → features → credential check → summary → generate → deploy prompt
    - Call `_run_model_selection(provider, cfg, agentcore_state)` at step 4 for all providers
    - Call `_run_credential_check()` at step 9 only for AgentCore
    - Assemble `agentcore_setup` dict from `agentcore_state` + credential result + model ID
    - Pass assembled dict to `_generate_project()` unchanged
    - _Requirements: 3.1, 3.4, 3.5, 5.5_

  - [x] 3.2 Remove "tools" from `_FEATURES` dict
    - Remove the `"tools": "Custom tool functions"` entry from `_FEATURES`
    - Tool configuration is handled by the tool wizard at step 6
    - _Requirements: 3.2_

  - [x] 3.3 Add "Deploy now?" prompt after project generation
    - After `_generate_project()` returns, if provider is AgentCore, prompt `"Deploy now?"` (default: no)
    - If yes: lazily import and call `run_deploy(target="agentcore", dry_run=False, file=os.path.join(name, "agent.py"))`
    - If no: print message about deploying later
    - Skip entirely for non-AgentCore providers
    - _Requirements: 4.1, 4.2, 4.3, 4.4_

  - [ ]* 3.4 Write unit tests for the redesigned init flow
    - Test step order by mocking click prompts and verifying call sequence
    - Test "tools" is not in feature selection options
    - Test credential check is skipped for non-AgentCore providers
    - Test deploy prompt shown only for AgentCore
    - Test deploy invocation when user confirms
    - Test deploy decline message
    - Test agentcore_setup dict passed to _generate_project has bedrock/-prefixed model_id
    - File: `tests/unit/test_init_flow_redesign.py`
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 4.1, 4.2, 4.3, 4.4, 1.2, 5.5_

- [x] 4. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- All changes are scoped to `synth/cli/init_cmd.py` — no modifications to `_generate_project`, `_run_tool_wizard`, `_run_mcp_wizard`, `_build_agent_code`, or other helpers
- Property tests use Hypothesis with `@settings(max_examples=100)`
- Unit tests use `click.testing.CliRunner` and `unittest.mock.patch` for CLI interaction tests
- Lazy imports for `CredentialResolver`, `ModelCatalog`, `RegionValidator` follow existing SDK patterns
