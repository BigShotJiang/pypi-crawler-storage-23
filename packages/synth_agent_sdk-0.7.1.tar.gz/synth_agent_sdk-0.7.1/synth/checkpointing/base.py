"""Abstract base class for checkpoint stores.

Defines the interface that all checkpoint backends (local disk, Redis, etc.)
must implement.  Checkpoint data is always JSON-serializable — never pickle.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from synth.types import Checkpoint


class BaseCheckpointStore(ABC):
    """Abstract checkpoint store.

    Subclasses persist and retrieve ``Checkpoint`` objects so that graph
    and pipeline runs can be resumed after interruption.
    """

    @abstractmethod
    async def save(self, checkpoint: Checkpoint) -> None:
        """Persist a checkpoint.

        Parameters
        ----------
        checkpoint:
            The checkpoint to persist.
        """
        ...

    @abstractmethod
    async def load(self, run_id: str) -> Checkpoint | None:
        """Load the most recent checkpoint for *run_id*.

        Parameters
        ----------
        run_id:
            The run identifier.

        Returns
        -------
        Checkpoint | None
            The checkpoint if found, otherwise ``None``.
        """
        ...

    @abstractmethod
    async def delete(self, run_id: str) -> None:
        """Delete all checkpoints for *run_id*.

        Parameters
        ----------
        run_id:
            The run identifier.
        """
        ...
