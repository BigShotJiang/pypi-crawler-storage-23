"""Local disk checkpoint store using JSON files.

Stores checkpoints as JSON files in ``.synth/checkpoints/{run_id}/``.
Uses atomic writes (write-to-temp-then-rename) to prevent corruption.
Files are created with restrictive permissions (owner read/write only).
"""

from __future__ import annotations

import json
import os
import stat
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from synth.checkpointing.base import BaseCheckpointStore
from synth.types import Checkpoint


class LocalCheckpointStore(BaseCheckpointStore):
    """Disk-based checkpoint store using JSON files.

    Parameters
    ----------
    base_dir:
        Root directory for checkpoint storage.  Defaults to
        ``.synth/checkpoints`` in the current working directory.
    """

    def __init__(self, base_dir: str | None = None) -> None:
        self._base_dir = Path(base_dir or ".synth/checkpoints")

    # ------------------------------------------------------------------
    # BaseCheckpointStore interface
    # ------------------------------------------------------------------

    async def save(self, checkpoint: Checkpoint) -> None:
        """Persist *checkpoint* as a JSON file with atomic write."""
        run_dir = self._base_dir / checkpoint.run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        data = {
            "run_id": checkpoint.run_id,
            "state": checkpoint.state,
            "step": checkpoint.step,
            "node_name": checkpoint.node_name,
            "timestamp": checkpoint.timestamp.isoformat(),
        }

        dest = run_dir / f"step_{checkpoint.step}.json"

        # Atomic write: write to temp file then rename
        fd, tmp_path = tempfile.mkstemp(
            dir=str(run_dir), suffix=".tmp",
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, default=str)

            # Restrictive permissions (owner read/write only)
            os.chmod(tmp_path, stat.S_IRUSR | stat.S_IWUSR)

            # Atomic rename
            os.replace(tmp_path, str(dest))
        except Exception:
            # Clean up temp file on failure
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    async def load(self, run_id: str) -> Checkpoint | None:
        """Load the most recent checkpoint for *run_id*."""
        run_dir = self._base_dir / run_id
        if not run_dir.exists():
            return None

        # Find the highest step file
        step_files = sorted(
            run_dir.glob("step_*.json"),
            key=lambda p: int(p.stem.split("_")[1]),
        )
        if not step_files:
            return None

        latest = step_files[-1]
        data = json.loads(latest.read_text(encoding="utf-8"))

        return Checkpoint(
            run_id=data["run_id"],
            state=data["state"],
            step=data["step"],
            node_name=data["node_name"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
        )

    async def delete(self, run_id: str) -> None:
        """Delete all checkpoints for *run_id*."""
        run_dir = self._base_dir / run_id
        if run_dir.exists():
            import shutil

            shutil.rmtree(run_dir)
