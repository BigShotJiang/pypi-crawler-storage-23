"""Evaluation framework: Eval, scorers, EvalReport."""

from synth.eval.eval import Eval
from synth.eval.report import EvalCaseResult, EvalComparison, EvalReport
from synth.eval.scorers import CustomScorer, ExactMatchScorer, SemanticSimilarityScorer

__all__ = [
    "Eval",
    "EvalCaseResult",
    "EvalComparison",
    "EvalReport",
    "CustomScorer",
    "ExactMatchScorer",
    "SemanticSimilarityScorer",
]
