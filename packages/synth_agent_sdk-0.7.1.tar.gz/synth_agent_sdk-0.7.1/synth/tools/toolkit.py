"""ToolKit — groups multiple ``@tool`` functions into a single unit.

A ``ToolKit`` accepts a list of ``@tool``-decorated functions and exposes
convenience methods for retrieving their JSON schemas and a name→function
mapping.
"""

from __future__ import annotations

from synth.tools.decorator import ToolFunction


class ToolKit:
    """Bundle of ``@tool``-decorated functions.

    Parameters
    ----------
    tools:
        A list of functions that have been decorated with ``@tool``.
        Each function must carry a ``_tool_schema`` attribute (set by the
        decorator).
    """

    def __init__(self, tools: list[ToolFunction]) -> None:
        self._tools = list(tools)

    def get_schemas(self) -> list[dict]:
        """Return the JSON schema dicts for every tool in this kit."""
        return [fn._tool_schema for fn in self._tools]  # type: ignore[attr-defined]

    def get_tools(self) -> dict[str, ToolFunction]:
        """Return a mapping of tool name → decorated function."""
        return {fn._tool_schema["name"]: fn for fn in self._tools}  # type: ignore[attr-defined]
