"""``synth deploy`` command — deploy agent to a target platform.

Implements the Deploy_Wizard: a sequential stage runner that validates
prerequisites, resolves credentials, packages the agent, and submits to
the AgentCore API.  Each stage prints ``[  OK  ]`` or ``[FAIL]`` and the
wizard halts on the first failure.

Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import click

from synth.errors import SynthConfigError


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class StageResult:
    """Result from a single Deploy_Wizard stage.

    Parameters
    ----------
    success:
        Whether the stage completed successfully.
    message:
        Human-readable status message.
    suggestion:
        Corrective action to display on failure.  Should be non-empty when
        ``success`` is ``False`` (Requirement 2.3).
    data:
        Optional payload passed between stages (e.g. loaded agent, manifest).
    """

    success: bool
    message: str
    suggestion: str | None = None
    data: Any = field(default=None, repr=False)


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def _print_stage_result(
    stage_name: str,
    result: StageResult,
    *,
    dry_run: bool = False,
) -> None:
    """Print a ``[  OK  ]`` or ``[FAIL]`` line for *stage_name*.

    Parameters
    ----------
    stage_name:
        Display name of the stage (e.g. ``"Credential validation"``).
    result:
        The ``StageResult`` returned by the stage function.
    dry_run:
        When ``True``, prefix the line with ``[DRY RUN]`` (Requirement 2.7).
    """
    prefix = click.style("[DRY RUN] ", fg="cyan") if dry_run else ""

    if result.success:
        status = click.style("[  OK  ]", fg="green")
        click.echo(f"  {prefix}{status} {stage_name}: {result.message}")
    else:
        status = click.style("[FAIL]", fg="red")
        click.echo(f"  {prefix}{status}  {stage_name}: {result.message}")
        if result.suggestion:
            click.echo(
                f"         {click.style('Suggestion:', fg='yellow')} {result.suggestion}"
            )


# ---------------------------------------------------------------------------
# Stage functions
# ---------------------------------------------------------------------------


def _stage_credentials(profile: str | None) -> StageResult:
    """Stage 1 — Validate AWS credentials (Requirement 2.4, 2.5).

    Parameters
    ----------
    profile:
        Named AWS profile from ``agentcore.yaml``, or ``None`` to use the
        default credential chain.

    Returns
    -------
    StageResult
        Success with masked account ID, or failure with instructions.
    """
    try:
        from synth.deploy.agentcore.credentials import CredentialResolver

        resolver = CredentialResolver()

        # If a named profile is configured, try it first (Requirement 7.2)
        creds = None
        if profile:
            creds = resolver.resolve_profile(profile)
            if creds is None:
                return StageResult(
                    success=False,
                    message=f"Profile '{profile}' not found.",
                    suggestion=(
                        f"Ensure '{profile}' exists in ~/.aws/credentials "
                        "or run: aws configure --profile " + profile
                    ),
                )

        if creds is None:
            creds = resolver.resolve()

        if creds is None:
            return StageResult(
                success=False,
                message="No AWS credentials found.",
                suggestion=(
                    "Run: aws configure  or  pip install awscli && aws configure"
                ),
            )

        masked = resolver.mask_account_id(creds.account_id)
        profile_info = f" (profile: {creds.profile_name})" if creds.profile_name else ""
        return StageResult(
            success=True,
            message=f"Account {masked} via {creds.source}{profile_info}",
            data=creds,
        )

    except SynthConfigError as exc:
        return StageResult(
            success=False,
            message=str(exc),
            suggestion=exc.suggestion,
        )
    except Exception as exc:
        return StageResult(
            success=False,
            message=f"Credential check failed: {exc}",
            suggestion="Run: aws configure",
        )


def _stage_dependencies() -> StageResult:
    """Stage 2 — Check that ``synth[agentcore]`` is installed (Requirement 2.1).

    Returns
    -------
    StageResult
        Success if the AgentCore adapter can be imported, failure otherwise.
    """
    try:
        from synth.deploy.agentcore.adapter import AgentCoreAdapter  # noqa: F401

        return StageResult(
            success=True,
            message="synth[agentcore] is installed.",
        )
    except ImportError:
        return StageResult(
            success=False,
            message="synth[agentcore] is not installed.",
            suggestion="Run: pip install synth-agent-sdk[agentcore]",
        )


def _stage_validate_file(file: str) -> StageResult:
    """Stage 3 — Load and validate the agent file (Requirement 2.1).

    Parameters
    ----------
    file:
        Path to the agent Python file.

    Returns
    -------
    StageResult
        Success with the loaded agent object, or failure with details.
    """
    if not Path(file).exists():
        return StageResult(
            success=False,
            message=f"File not found: {file}",
            suggestion=f"Check the path and try again: {file}",
        )

    try:
        from synth.cli.run_cmd import _load_agent

        agent = _load_agent(file)
        model = getattr(agent, "model", "unknown")
        return StageResult(
            success=True,
            message=f"Agent loaded (model: {model})",
            data=agent,
        )
    except SystemExit:
        return StageResult(
            success=False,
            message=f"Failed to load agent from '{file}'.",
            suggestion="Ensure the file defines an 'agent' variable.",
        )
    except Exception as exc:
        return StageResult(
            success=False,
            message=f"Agent file error: {exc}",
            suggestion="Ensure the file defines an 'agent' variable.",
        )


def _stage_manifest(agent: Any) -> StageResult:
    """Stage 4 — Generate the AgentCore manifest (Requirement 2.1).

    Parameters
    ----------
    agent:
        The loaded Synth Agent or Graph instance.

    Returns
    -------
    StageResult
        Success with the manifest dict, or failure with details.
    """
    try:
        from synth.deploy.agentcore.manifest import generate_manifest

        manifest = generate_manifest(agent)
        action_count = len(manifest.get("actions", []))
        return StageResult(
            success=True,
            message=f"Manifest generated ({action_count} action(s)).",
            data=manifest,
        )
    except SynthConfigError as exc:
        return StageResult(
            success=False,
            message=str(exc),
            suggestion=exc.suggestion,
        )
    except Exception as exc:
        return StageResult(
            success=False,
            message=f"Manifest generation failed: {exc}",
            suggestion="Check agent configuration and try again.",
        )


def _stage_package(agent: Any, dry_run: bool) -> StageResult:
    """Stage 5 — Package the deployment artifact (Requirement 2.1).

    Skipped in dry-run mode (Requirement 2.7).

    Parameters
    ----------
    agent:
        The loaded Synth Agent or Graph instance.
    dry_run:
        When ``True``, this stage is skipped.

    Returns
    -------
    StageResult
        Success with the manifest, or failure with details.
    """
    if dry_run:
        return StageResult(
            success=True,
            message="Skipped (dry-run mode).",
        )

    try:
        from synth.deploy.packager import package

        manifest = package(agent, dry_run=False)
        return StageResult(
            success=True,
            message="Deployment artifact created in dist/.",
            data=manifest,
        )
    except SynthConfigError as exc:
        return StageResult(
            success=False,
            message=str(exc),
            suggestion=exc.suggestion,
        )
    except Exception as exc:
        return StageResult(
            success=False,
            message=f"Packaging failed: {exc}",
            suggestion="Check file permissions and available disk space.",
        )


def _boto3_client(service: str, region: str) -> Any:
    """Create a boto3 client — extracted for testability.

    Parameters
    ----------
    service:
        AWS service name (e.g. ``"bedrock-agentcore"``).
    region:
        AWS region string.

    Returns
    -------
    Any
        A boto3 service client.

    Raises
    ------
    ImportError
        If boto3 is not installed.
    """
    import boto3  # type: ignore[import-untyped]

    return boto3.client(service, region_name=region)


def _stage_submit(
    manifest: dict[str, Any],
    region: str,
    model_id: str,
    dry_run: bool,
) -> StageResult:
    """Stage 6 — Submit to the AgentCore API (Requirement 2.1, 2.6).

    Skipped in dry-run mode (Requirement 2.7).

    Parameters
    ----------
    manifest:
        The generated agent manifest.
    region:
        AWS region for deployment.
    model_id:
        Bedrock model ID used by the agent.
    dry_run:
        When ``True``, this stage is skipped.

    Returns
    -------
    StageResult
        Success with the agent ARN, or failure with details.
    """
    if dry_run:
        return StageResult(
            success=True,
            message="Skipped (dry-run mode).",
        )

    try:
        client = _boto3_client("bedrock-agentcore", region)
        agent_name = manifest.get("name", "synth-agent")
        description = manifest.get("description", "")

        response = client.create_agent(
            agentName=agent_name,
            description=description[:200] if description else "",
        )

        agent_arn = response.get("agentArn", response.get("agent", {}).get("agentArn", ""))
        return StageResult(
            success=True,
            message=f"Agent deployed: {agent_arn}",
            data={"arn": agent_arn, "region": region, "model_id": model_id},
        )

    except ImportError:
        return StageResult(
            success=False,
            message="boto3 is not installed.",
            suggestion="Run: pip install synth-agent-sdk[agentcore]",
        )
    except SynthConfigError as exc:
        return StageResult(
            success=False,
            message=str(exc),
            suggestion=exc.suggestion,
        )
    except Exception as exc:
        return StageResult(
            success=False,
            message=f"AgentCore API submission failed: {exc}",
            suggestion=(
                "Check AWS credentials, region, and that AgentCore is available "
                "in your account."
            ),
        )



# ---------------------------------------------------------------------------
# Config reader
# ---------------------------------------------------------------------------


def _read_agentcore_yaml(file: str) -> dict[str, Any]:
    """Read ``agentcore.yaml`` from the same directory as *file*.

    Parameters
    ----------
    file:
        Path to the agent Python file.

    Returns
    -------
    dict
        Parsed YAML contents, or an empty dict if the file is absent.
    """
    agent_dir = Path(file).parent if file else Path(".")
    yaml_path = agent_dir / "agentcore.yaml"

    if not yaml_path.exists():
        return {}

    try:
        import yaml  # type: ignore[import-untyped]

        with yaml_path.open(encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        return data if isinstance(data, dict) else {}
    except ImportError:
        # PyYAML not available — try a minimal key=value fallback
        return _parse_yaml_minimal(yaml_path)
    except Exception:
        return {}


def _parse_yaml_minimal(path: Path) -> dict[str, Any]:
    """Minimal YAML parser for simple ``key: value`` lines (no PyYAML)."""
    result: dict[str, Any] = {}
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                key, _, value = line.partition(":")
                result[key.strip()] = value.strip().strip('"').strip("'")
    except Exception:
        pass
    return result


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def run_deploy(target: str, dry_run: bool, file: str | None) -> None:
    """Run the Deploy_Wizard for the specified *target*.

    Reads ``agentcore.yaml`` for ``aws_profile``, ``aws_region``, and
    ``model_id``, then executes six sequential stages.  Halts on the first
    failure (Requirement 2.3).  In dry-run mode, only stages 1–4 run
    (Requirement 2.7).

    Parameters
    ----------
    target:
        Deployment target — only ``"agentcore"`` is supported.
    dry_run:
        When ``True``, run stages 1–4 only and prefix output with
        ``[DRY RUN]``.
    file:
        Path to the agent Python file.
    """
    if target != "agentcore":
        click.echo(
            click.style(
                f"Unknown target '{target}'. Supported: agentcore", fg="red"
            ),
            err=True,
        )
        sys.exit(1)

    if not file:
        click.echo(
            click.style("No agent file specified.", fg="red"),
            err=True,
        )
        sys.exit(1)

    # Read agentcore.yaml for persisted config (Requirements 4.7, 7.1, 7.3)
    config = _read_agentcore_yaml(file)
    aws_profile: str | None = config.get("aws_profile") or None
    aws_region: str = config.get("aws_region") or "us-east-1"
    model_id: str = config.get("model_id") or "unknown"

    if dry_run:
        click.echo(click.style("[DRY RUN] Starting deploy validation...", fg="cyan"))
    else:
        click.echo(click.style("Starting AgentCore deployment...", fg="cyan"))
    click.echo("")

    # ------------------------------------------------------------------
    # Stage 1: Credential validation
    # ------------------------------------------------------------------
    result1 = _stage_credentials(aws_profile)
    _print_stage_result("Credential validation", result1, dry_run=dry_run)
    if not result1.success:
        sys.exit(1)

    # ------------------------------------------------------------------
    # Stage 2: Dependency check
    # ------------------------------------------------------------------
    result2 = _stage_dependencies()
    _print_stage_result("Dependency check", result2, dry_run=dry_run)
    if not result2.success:
        sys.exit(1)

    # ------------------------------------------------------------------
    # Stage 3: Agent file validation
    # ------------------------------------------------------------------
    result3 = _stage_validate_file(file)
    _print_stage_result("Agent file validation", result3, dry_run=dry_run)
    if not result3.success:
        sys.exit(1)

    agent = result3.data

    # ------------------------------------------------------------------
    # Stage 4: Manifest generation
    # ------------------------------------------------------------------
    result4 = _stage_manifest(agent)
    _print_stage_result("Manifest generation", result4, dry_run=dry_run)
    if not result4.success:
        sys.exit(1)

    manifest = result4.data

    # Dry-run stops after stage 4 (Requirement 2.7)
    if dry_run:
        click.echo("")
        click.echo(
            click.style("[DRY RUN] Validation passed. No artifact created.", fg="cyan")
        )
        return

    # ------------------------------------------------------------------
    # Stage 5: Artifact packaging
    # ------------------------------------------------------------------
    result5 = _stage_package(agent, dry_run=False)
    _print_stage_result("Artifact packaging", result5, dry_run=False)
    if not result5.success:
        sys.exit(1)

    # ------------------------------------------------------------------
    # Stage 6: AgentCore API submission
    # ------------------------------------------------------------------
    result6 = _stage_submit(manifest, aws_region, model_id, dry_run=False)
    _print_stage_result("AgentCore API submission", result6, dry_run=False)
    if not result6.success:
        sys.exit(1)

    # ------------------------------------------------------------------
    # Success summary (Requirement 2.6)
    # ------------------------------------------------------------------
    click.echo("")
    click.echo(click.style("Deployment complete.", fg="green"))

    submit_data = result6.data or {}
    agent_arn = submit_data.get("arn", "N/A")
    deployed_region = submit_data.get("region", aws_region)
    deployed_model = submit_data.get("model_id", model_id)

    click.echo(f"  Agent ARN : {agent_arn}")
    click.echo(f"  Region    : {deployed_region}")
    click.echo(f"  Model ID  : {deployed_model}")
