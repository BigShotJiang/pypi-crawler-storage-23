"""``synth init`` command — interactive project initializer.

Walks the user through a series of prompts to set up a complete
Synth agent project, similar to ``npm init`` but tailored for
AI agent development.
"""

from __future__ import annotations

import os
import subprocess
import sys
from dataclasses import dataclass, field
from typing import Any

import click


# ------------------------------------------------------------------
# Provider / feature configuration
# ------------------------------------------------------------------

_PROVIDERS = {
    "anthropic": {
        "model": "claude-sonnet-4-5",
        "extra": "anthropic",
        "env_var": "ANTHROPIC_API_KEY",
        "display": "Anthropic (Claude)",
    },
    "openai": {
        "model": "gpt-4o",
        "extra": "openai",
        "env_var": "OPENAI_API_KEY",
        "display": "OpenAI (GPT)",
    },
    "llama": {
        "model": "ollama/llama3.2",
        "extra": "ollama",
        "env_var": "",
        "display": "Llama (via Ollama)",
    },
    "gemini": {
        "model": "gemini/gemini-2.0-flash",
        "extra": "google",
        "env_var": "GOOGLE_API_KEY",
        "display": "Google Gemini",
    },
    "agentcore": {
        "model": "bedrock/us.anthropic.claude-sonnet-4-5-20250514-v1:0",
        "extra": "agentcore",
        "env_var": "",
        "display": "AWS AgentCore (Bedrock)",
    },
}

_PROVIDER_CHOICES = click.Choice(
    list(_PROVIDERS.keys()), case_sensitive=False,
)

_FEATURES = {
    "memory": "Conversation memory",
    "guards": "Input/output guards (PII, cost, custom)",
    "structured": "Structured output (Pydantic models)",
    "eval": "Evaluation suite",
    "deploy": "AgentCore deployment handler",
}


# ------------------------------------------------------------------
# Tool and MCP catalogs
# ------------------------------------------------------------------

_TOOL_CATALOG: list[dict[str, str]] = [
    {
        "key": "web_search",
        "display": "Web search",
        "code": '''\
@tool
def web_search(query: str, limit: int = 5) -> list[str]:
    """Search the web for information matching the query."""
    # TODO: Replace with your real search implementation (e.g. SerpAPI, Tavily)
    return [f"Result {i + 1} for '{query}'" for i in range(limit)]
''',
        "import": "web_search",
    },
    {
        "key": "calculator",
        "display": "Calculator",
        "code": '''\
@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression safely."""
    import math
    allowed = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
    try:
        result = eval(expression, {"__builtins__": {}}, allowed)  # noqa: S307
        return str(result)
    except Exception as exc:
        return f"Error: {exc}"
''',
        "import": "calculate",
    },
    {
        "key": "file_reader",
        "display": "File reader",
        "code": '''\
@tool
def read_file(path: str) -> str:
    """Read and return the text content of a local file."""
    with open(path, encoding="utf-8") as fh:
        return fh.read()
''',
        "import": "read_file",
    },
    {
        "key": "http_fetch",
        "display": "HTTP fetch",
        "code": '''\
@tool
async def http_fetch(url: str) -> str:
    """Fetch the text content of a URL."""
    import httpx
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, follow_redirects=True, timeout=10.0)
        resp.raise_for_status()
        return resp.text[:4000]
''',
        "import": "http_fetch",
    },
    {
        "key": "datetime",
        "display": "Date/time",
        "code": '''\
@tool
def get_current_datetime() -> str:
    """Return the current UTC date and time in ISO 8601 format."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()
''',
        "import": "get_current_datetime",
    },
]

_MCP_CATALOG: list[dict[str, str]] = [
    {
        "key": "filesystem",
        "display": "Filesystem MCP",
        "server_code": '''\
"""Filesystem MCP server — exposes local file operations via MCP."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("filesystem")


@mcp.tool()
def read_file(path: str) -> str:
    """Read the contents of a file at the given path."""
    with open(path, encoding="utf-8") as fh:
        return fh.read()


@mcp.tool()
def list_directory(path: str = ".") -> list[str]:
    """List files and directories at the given path."""
    import os
    return os.listdir(path)


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "github",
        "display": "GitHub MCP",
        "server_code": '''\
"""GitHub MCP server — exposes GitHub API operations via MCP."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("github")


@mcp.tool()
def get_repo(owner: str, repo: str) -> dict:
    """Get information about a GitHub repository."""
    import httpx
    resp = httpx.get(f"https://api.github.com/repos/{owner}/{repo}")
    resp.raise_for_status()
    return resp.json()


@mcp.tool()
def list_issues(owner: str, repo: str, state: str = "open") -> list[dict]:
    """List issues for a GitHub repository."""
    import httpx
    resp = httpx.get(
        f"https://api.github.com/repos/{owner}/{repo}/issues",
        params={"state": state},
    )
    resp.raise_for_status()
    return resp.json()


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "slack",
        "display": "Slack MCP",
        "server_code": '''\
"""Slack MCP server — exposes Slack messaging operations via MCP."""

from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("slack")

_SLACK_TOKEN = os.environ.get("SLACK_BOT_TOKEN", "")


@mcp.tool()
def send_message(channel: str, text: str) -> dict:
    """Send a message to a Slack channel."""
    import httpx
    resp = httpx.post(
        "https://slack.com/api/chat.postMessage",
        headers={"Authorization": f"Bearer {_SLACK_TOKEN}"},
        json={"channel": channel, "text": text},
    )
    resp.raise_for_status()
    return resp.json()


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "database",
        "display": "Database MCP",
        "server_code": '''\
"""Database MCP server — exposes SQL query operations via MCP."""

from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("database")

_DB_URL = os.environ.get("DATABASE_URL", "sqlite:///./app.db")


@mcp.tool()
def query(sql: str) -> list[dict]:
    """Execute a read-only SQL query and return the results."""
    import sqlite3
    conn = sqlite3.connect(_DB_URL.replace("sqlite:///", ""))
    conn.row_factory = sqlite3.Row
    cur = conn.execute(sql)
    rows = [dict(row) for row in cur.fetchall()]
    conn.close()
    return rows


if __name__ == "__main__":
    mcp.run()
''',
    },
]


# ------------------------------------------------------------------
# Wizard result dataclasses
# ------------------------------------------------------------------

@dataclass
class ToolWizardResult:
    """Result from the tool creation wizard.

    Parameters
    ----------
    tools_code:
        Content to write to ``tools.py``.
    agent_imports:
        Import names to add to ``agent.py`` (e.g. ``["web_search", "calculate"]``).
    files_created:
        List of file paths that will be written (relative to project dir).
    """

    tools_code: str = ""
    agent_imports: list[str] = field(default_factory=list)
    files_created: list[str] = field(default_factory=list)


@dataclass
class McpWizardResult:
    """Result from the MCP server creation wizard.

    Parameters
    ----------
    server_dir:
        Directory name for the MCP server (e.g. ``"mcp-server"``).
    server_code:
        Content to write to ``<server_dir>/server.py``.
    agent_mcp_registration:
        Code snippet to append to ``agent.py`` for MCP client registration.
    files_created:
        List of file paths that will be written (relative to project dir).
    """

    server_dir: str = ""
    server_code: str = ""
    agent_mcp_registration: str = ""
    files_created: list[str] = field(default_factory=list)


# ------------------------------------------------------------------
# Tool wizard
# ------------------------------------------------------------------

def _run_tool_wizard() -> ToolWizardResult:
    """Interactive wizard for adding tools to the project.

    Returns
    -------
    ToolWizardResult
        Populated result if the user chose to add tools; empty result otherwise.
    """
    click.echo("")
    want_tools = click.confirm(
        click.style("  Add tools to your project?", fg="cyan"),
        default=False,
    )
    if not want_tools:
        return ToolWizardResult()

    # Build numbered list: catalog entries + custom scaffolding
    click.echo("")
    click.echo(click.style("  Available tools:", fg="cyan"))
    for idx, entry in enumerate(_TOOL_CATALOG, start=1):
        click.echo(f"    {idx}. {entry['display']}")
    custom_idx = len(_TOOL_CATALOG) + 1
    click.echo(f"    {custom_idx}. Create custom scaffolding")
    click.echo("")

    raw = click.prompt(
        click.style(
            "  Select tools (comma-separated numbers, e.g. 1,3)", fg="cyan"
        ),
        default="",
    ).strip()

    if not raw:
        return ToolWizardResult()

    selected_indices: list[int] = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            val = int(part)
            if 1 <= val <= custom_idx:
                selected_indices.append(val)

    if not selected_indices:
        return ToolWizardResult()

    want_custom = custom_idx in selected_indices
    prebuilt_indices = [i for i in selected_indices if i != custom_idx]

    # Collect code blocks and import names
    code_blocks: list[str] = []
    import_names: list[str] = []

    for idx in prebuilt_indices:
        entry = _TOOL_CATALOG[idx - 1]
        code_blocks.append(entry["code"])
        import_names.append(entry["import"])

    # Custom scaffolding sub-wizard
    if want_custom:
        click.echo("")
        click.echo(click.style(
            "  Custom tool scaffolding (up to 3 tools):", fg="cyan"
        ))
        for slot in range(1, 4):
            tool_name = click.prompt(
                click.style(f"    Tool {slot} name (or Enter to stop)", fg="cyan"),
                default="",
            ).strip()
            if not tool_name:
                break
            tool_desc = click.prompt(
                click.style(f"    Tool {slot} description", fg="cyan"),
                default=f"A custom tool named {tool_name}.",
            ).strip()
            # Sanitise name to a valid Python identifier
            safe_name = tool_name.lower().replace(" ", "_").replace("-", "_")
            stub = (
                f"@tool\n"
                f"def {safe_name}(input: str) -> str:\n"
                f'    """{tool_desc}"""\n'
                f"    # TODO: implement {safe_name}\n"
                f"    raise NotImplementedError\n"
            )
            code_blocks.append(stub)
            import_names.append(safe_name)

    if not code_blocks:
        return ToolWizardResult()

    header = (
        '"""Custom tools for the agent."""\n\n'
        "from __future__ import annotations\n\n"
        "from synth import tool\n\n\n"
    )
    tools_code = header + "\n\n".join(code_blocks)

    return ToolWizardResult(
        tools_code=tools_code,
        agent_imports=import_names,
        files_created=["tools.py"],
    )


# ------------------------------------------------------------------
# MCP wizard
# ------------------------------------------------------------------

def _run_mcp_wizard() -> McpWizardResult:
    """Interactive wizard for adding an MCP server to the project.

    Returns
    -------
    McpWizardResult
        Populated result if the user chose to add an MCP server; empty otherwise.
    """
    click.echo("")
    want_mcp = click.confirm(
        click.style("  Add an MCP server to your project?", fg="cyan"),
        default=False,
    )
    if not want_mcp:
        return McpWizardResult()

    # Build numbered list: catalog entries + custom scaffolding
    click.echo("")
    click.echo(click.style("  Available MCP servers:", fg="cyan"))
    for idx, entry in enumerate(_MCP_CATALOG, start=1):
        click.echo(f"    {idx}. {entry['display']}")
    custom_idx = len(_MCP_CATALOG) + 1
    click.echo(f"    {custom_idx}. Create custom scaffolding")
    click.echo("")

    choice_raw = click.prompt(
        click.style("  Select MCP server (number)", fg="cyan"),
        type=click.IntRange(1, custom_idx),
        default=1,
    )

    if choice_raw == custom_idx:
        # Custom scaffolding
        server_name = click.prompt(
            click.style("  MCP server name", fg="cyan"),
            default="mcp-server",
        ).strip() or "mcp-server"

        click.echo("")
        click.echo(click.style(
            "  Custom MCP tool scaffolding (up to 3 tools):", fg="cyan"
        ))
        tool_stubs: list[str] = []
        for slot in range(1, 4):
            tool_name = click.prompt(
                click.style(f"    MCP tool {slot} name (or Enter to stop)", fg="cyan"),
                default="",
            ).strip()
            if not tool_name:
                break
            tool_desc = click.prompt(
                click.style(f"    MCP tool {slot} description", fg="cyan"),
                default=f"A custom MCP tool named {tool_name}.",
            ).strip()
            safe_name = tool_name.lower().replace(" ", "_").replace("-", "_")
            stub = (
                f"@mcp.tool()\n"
                f"def {safe_name}(input: str) -> str:\n"
                f'    """{tool_desc}"""\n'
                f"    # TODO: implement {safe_name}\n"
                f"    raise NotImplementedError\n"
            )
            tool_stubs.append(stub)

        if not tool_stubs:
            tool_stubs = [
                "@mcp.tool()\ndef example_tool(input: str) -> str:\n"
                '    """An example MCP tool stub."""\n'
                "    raise NotImplementedError\n"
            ]

        server_code = (
            f'"""Custom MCP server: {server_name}."""\n\n'
            "from __future__ import annotations\n\n"
            "from mcp.server.fastmcp import FastMCP\n\n"
            f'mcp = FastMCP("{server_name}")\n\n\n'
            + "\n\n".join(tool_stubs)
            + "\n\nif __name__ == \"__main__\":\n    mcp.run()\n"
        )
    else:
        catalog_entry = _MCP_CATALOG[choice_raw - 1]
        server_name = catalog_entry["key"]
        server_code = catalog_entry["server_code"]

    registration = (
        f"\n\n# MCP server registration\n"
        f"# Uncomment and configure to connect to the {server_name} MCP server:\n"
        f"# from synth.tools.mcp import MCPClient\n"
        f"# mcp_client = MCPClient(\"{server_name}/server.py\")\n"
    )

    return McpWizardResult(
        server_dir=server_name,
        server_code=server_code,
        agent_mcp_registration=registration,
        files_created=[f"{server_name}/server.py"],
    )

# ------------------------------------------------------------------
# Model selection helper
# ------------------------------------------------------------------

def _run_model_selection(
    provider: str,
    cfg: dict[str, str],
    agentcore_state: dict[str, Any] | None = None,
) -> str:
    """Select the model ID for the given provider.

    For AgentCore, prompts for a target AWS region, displays available
    models filtered by that region via ``RegionValidator``, and returns
    the ``bedrock/``-prefixed effective model ID.  Region and CRIS data
    are written into *agentcore_state* so the caller can forward them.

    For every other provider the default model from *cfg* is returned
    directly without additional prompting.

    Parameters
    ----------
    provider : str
        Provider key (e.g. ``"agentcore"``, ``"anthropic"``).
    cfg : dict[str, str]
        Provider config dict from ``_PROVIDERS``.
    agentcore_state : dict[str, Any] | None
        Mutable dict that receives ``aws_region`` and ``cris_enabled``
        when *provider* is ``"agentcore"``.  Ignored otherwise.

    Returns
    -------
    str
        The selected model ID string.  For AgentCore this includes the
        ``bedrock/`` prefix.
    """
    if provider != "agentcore":
        return cfg["model"]

    # --- Lazy imports (AgentCore extras) ---
    try:
        from synth.deploy.agentcore.model_catalog import (
            ModelCatalog,
            RegionValidator,
        )
    except ImportError as exc:
        from synth.errors import SynthConfigError

        raise SynthConfigError(
            "AgentCore extras are not installed.",
            component="init",
            suggestion="pip install synth[agentcore]",
        ) from exc

    # --- Region selection ---
    click.echo("")
    aws_region: str = click.prompt(
        click.style("  Target AWS region", fg="cyan"),
        default="us-east-1",
    )

    # --- Model selection ---
    catalog = ModelCatalog()
    validator = RegionValidator(catalog)

    availability_unknown = validator.availability_unknown_for_region(
        aws_region,
    )
    models = validator.models_for_region(aws_region)

    click.echo("")
    if availability_unknown:
        click.echo(
            click.style(
                f"  Warning: regional availability for '{aws_region}' "
                "could not be verified. Showing all models.",
                fg="yellow",
            )
        )

    click.echo(click.style("  Available models:", fg="cyan"))
    for idx, entry in enumerate(models, start=1):
        cris_note = ""
        if validator.requires_cris(entry.model_id, aws_region):
            cris_note = click.style(" [CRIS]", fg="yellow")
        click.echo(f"    {idx}. {entry.display_name}{cris_note}")

    model_choice = click.prompt(
        click.style("  Select model (number)", fg="cyan"),
        type=click.IntRange(1, len(models)),
        default=1,
    )
    selected_entry = models[model_choice - 1]
    cris_enabled = validator.requires_cris(
        selected_entry.model_id, aws_region,
    )
    effective_id = validator.effective_model_id(
        selected_entry.model_id, aws_region,
    )

    # --- Bedrock prefix (no double-prefixing) ---
    if not effective_id.startswith("bedrock/"):
        effective_id = f"bedrock/{effective_id}"

    if cris_enabled:
        click.echo(
            click.style(
                f"  Note: {selected_entry.display_name} is not natively "
                f"available in '{aws_region}'. Cross-Region Inference "
                f"(CRIS) will be used.\n"
                f"  Model ID: {effective_id}",
                fg="yellow",
            )
        )
    else:
        click.echo(
            f"  Model: "
            f"{click.style(selected_entry.display_name, fg='green')} "
            f"({effective_id})"
        )

    # --- Populate agentcore_state for the caller ---
    if agentcore_state is not None:
        agentcore_state["aws_region"] = aws_region
        agentcore_state["cris_enabled"] = cris_enabled

    return effective_id


# ------------------------------------------------------------------
# AWS credential check helper
# ------------------------------------------------------------------


# ------------------------------------------------------------------
# Provider dependency probes — maps each extra to a package that
# must be importable for the provider to work.
# ------------------------------------------------------------------

_EXTRA_PROBE_PACKAGES: dict[str, list[str]] = {
    "anthropic": ["anthropic"],
    "openai": ["openai"],
    "ollama": ["ollama"],
    "google": ["google.genai"],
    "agentcore": ["boto3", "botocore", "awscrt", "bedrock_agentcore"],
    "bedrock": ["boto3", "botocore", "awscrt"],
}

# For AWS providers, recommend the unified "aws" extra
_AWS_EXTRAS = {"agentcore", "bedrock"}


def _check_provider_deps(provider: str, cfg: dict[str, str]) -> None:
    """Check that the provider's dependencies are installed.

    If any required package is missing, offers to install them
    automatically via ``pip install synth-agent-sdk[<extra>]``.
    Aborts the init flow if the user declines and deps are missing.

    Parameters
    ----------
    provider:
        The provider key (e.g. ``"agentcore"``, ``"anthropic"``).
    cfg:
        Provider config dict from ``_PROVIDERS``.
    """
    extra = cfg.get("extra", provider)
    probes = _EXTRA_PROBE_PACKAGES.get(extra, [])
    if not probes:
        return

    missing: list[str] = []
    for pkg in probes:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)

    if not missing:
        return

    # Determine the right install extra name
    install_extra = "aws" if extra in _AWS_EXTRAS else extra
    install_cmd = f"pip install synth-agent-sdk[{install_extra}]"

    click.echo("")
    click.echo(
        click.style(
            f"  Missing dependencies for {cfg.get('display', provider)}: "
            f"{', '.join(missing)}",
            fg="yellow",
        )
    )
    click.echo(
        f"  Install with: {click.style(install_cmd, fg='green')}"
    )

    if click.confirm(
        click.style("  Install now?", fg="cyan"),
        default=True,
    ):
        click.echo(f"  Running: {install_cmd}")
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install",
             f"synth-agent-sdk[{install_extra}]"],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            click.echo(
                click.style(
                    f"  Installation failed. Please run manually:\n"
                    f"    {install_cmd}",
                    fg="red",
                )
            )
            raise SystemExit(1)

        # Verify newly installed packages are importable in this process
        import importlib

        still_missing: list[str] = []
        for pkg in missing:
            try:
                importlib.import_module(pkg)
            except ImportError:
                still_missing.append(pkg)

        if still_missing:
            click.echo(
                click.style(
                    "  Dependencies installed, but a process restart "
                    "is needed for them to take effect.\n"
                    "  Please re-run: synth init",
                    fg="yellow",
                )
            )
            raise SystemExit(0)

        click.echo(
            click.style("  Dependencies installed.", fg="green")
        )
    else:
        click.echo(
            click.style(
                f"  Cannot continue without dependencies.\n"
                f"  Run: {install_cmd}",
                fg="red",
            )
        )
        raise SystemExit(1)


def _prompt_profile_selection(
    resolver: object,
    available: list[str],
    default_profile: str | None = None,
) -> str | None:
    """Show a numbered list of AWS profiles and let the user pick one.

    Parameters
    ----------
    resolver:
        A ``CredentialResolver`` instance for validation.
    available:
        List of profile names to display.
    default_profile:
        Profile to mark as the default selection.  When ``None``, the
        first profile in the list is used.

    Returns
    -------
    str | None
        The chosen profile name, or ``None`` if the user skips.
    """
    for idx, name in enumerate(available, 1):
        marker = " (detected)" if name == default_profile else ""
        click.echo(
            f"    {click.style(str(idx), fg='green')}) {name}"
            f"{click.style(marker, dim=True)}"
        )
    click.echo(
        f"    {click.style(str(len(available) + 1), fg='green')}) "
        f"Enter a different profile name"
    )
    click.echo(
        f"    {click.style(str(len(available) + 2), fg='green')}) "
        f"Skip"
    )
    click.echo("")

    # Determine default choice number
    if default_profile and default_profile in available:
        default_idx = available.index(default_profile) + 1
    else:
        default_idx = 1

    choice = click.prompt(
        click.style("  Select option", fg="cyan"),
        type=int,
        default=default_idx,
    )

    skip_idx = len(available) + 2
    custom_idx = len(available) + 1

    if choice == skip_idx:
        return None
    if choice == custom_idx:
        profile = click.prompt(
            click.style("  Enter AWS profile name", fg="cyan"),
        )
    elif 1 <= choice <= len(available):
        profile = available[choice - 1]
    else:
        click.echo(click.style("  Invalid selection.", fg="yellow"))
        return None

    # Validate the chosen profile
    try:
        named = resolver.resolve_profile(profile)  # type: ignore[attr-defined]
        if named is not None:
            masked = resolver.mask_account_id(  # type: ignore[attr-defined]
                named.account_id,
            )
            click.echo(
                f"  Profile "
                f"{click.style(profile, fg='green')} "
                f"resolved (account: "
                f"{click.style(masked, fg='green')})"
            )
        else:
            click.echo(
                click.style(
                    f"  Warning: could not verify profile "
                    f"'{profile}'. Continuing anyway.",
                    fg="yellow",
                )
            )
    except Exception as exc:  # noqa: BLE001
        err_msg = str(exc)
        if "botocore" in err_msg.lower() and "crt" in err_msg.lower():
            click.echo(
                click.style(
                    f"  Missing dependency: botocore[crt] is required "
                    f"for SSO/login credential providers.\n"
                    f"  Run: pip install \"botocore[crt]\"",
                    fg="red",
                )
            )
            if click.confirm(
                click.style("  Install now?", fg="cyan"),
                default=True,
            ):
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install",
                     "botocore[crt]"],
                    capture_output=True,
                    text=True,
                )
                if result.returncode == 0:
                    click.echo(
                        click.style(
                            "  botocore[crt] installed. "
                            "Retrying profile validation...",
                            fg="green",
                        )
                    )
                    # Retry validation after install
                    try:
                        named = resolver.resolve_profile(profile)  # type: ignore[attr-defined]
                        if named is not None:
                            masked = resolver.mask_account_id(  # type: ignore[attr-defined]
                                named.account_id,
                            )
                            click.echo(
                                f"  Profile "
                                f"{click.style(profile, fg='green')} "
                                f"resolved (account: "
                                f"{click.style(masked, fg='green')})"
                            )
                    except Exception:  # noqa: BLE001
                        click.echo(
                            click.style(
                                f"  Warning: still could not verify "
                                f"profile '{profile}'. "
                                f"Continuing anyway.",
                                fg="yellow",
                            )
                        )
                else:
                    click.echo(
                        click.style(
                            "  Installation failed. Continuing "
                            "without verification.",
                            fg="yellow",
                        )
                    )
        else:
            click.echo(
                click.style(
                    f"  Warning: could not verify profile "
                    f"'{profile}'. Continuing anyway.",
                    fg="yellow",
                )
            )
    return profile


def _run_credential_check() -> dict[str, Any]:
    """Detect and validate AWS credentials.

    Lazily imports ``CredentialResolver`` from the AgentCore extras and
    attempts automatic credential detection.  When credentials are found
    the user is asked to confirm or supply an alternative profile.  When
    no credentials are detected a warning is printed and the user may
    pick from available profiles or enter one manually.

    Returns
    -------
    dict[str, Any]
        Keys: ``aws_profile`` (``str | None``).
    """
    try:
        from synth.deploy.agentcore.credentials import CredentialResolver
    except ImportError as exc:
        from synth.errors import SynthConfigError

        raise SynthConfigError(
            "AgentCore extras are not installed.",
            component="init",
            suggestion="pip install synth[agentcore]",
        ) from exc

    resolver = CredentialResolver()
    aws_profile: str | None = None
    available = resolver.list_available_profiles()

    # --- Credential detection ---
    click.echo("")
    click.echo(click.style("  AWS Credentials", fg="cyan", bold=True))

    creds = None
    try:
        creds = resolver.resolve()
    except Exception:  # noqa: BLE001
        pass  # handled below

    if creds is not None:
        masked = resolver.mask_account_id(creds.account_id)
        click.echo(
            f"  Found credentials via "
            f"{click.style(creds.source, fg='green')} "
            f"(account: {click.style(masked, fg='green')})"
        )

        # If there are other profiles available, let the user choose
        if len(available) > 1:
            use_found = click.confirm(
                click.style("  Use these credentials?", fg="cyan"),
                default=True,
            )
            if use_found:
                aws_profile = creds.profile_name
            else:
                click.echo("")
                click.echo(
                    click.style("  Available profiles:", fg="cyan"),
                )
                aws_profile = _prompt_profile_selection(
                    resolver,
                    available,
                    default_profile=creds.profile_name,
                )
        else:
            # Only one profile — just confirm
            use_found = click.confirm(
                click.style("  Use these credentials?", fg="cyan"),
                default=True,
            )
            if use_found:
                aws_profile = creds.profile_name
            else:
                aws_profile = click.prompt(
                    click.style("  Enter AWS profile name", fg="cyan"),
                    default="default",
                )
    else:
        if available:
            click.echo(
                click.style(
                    "  No AWS credentials auto-detected, but "
                    "profiles are available:",
                    fg="yellow",
                )
            )
            aws_profile = _prompt_profile_selection(
                resolver, available,
            )
        else:
            click.echo(
                click.style(
                    "  No AWS credentials found.\n"
                    "  Configure them with:\n"
                    "    pip install awscli && aws configure\n"
                    "  Or install the AWS Toolkit VS Code extension.",
                    fg="yellow",
                )
            )
            aws_profile = click.prompt(
                click.style(
                    "  Enter AWS profile name to use "
                    "(or press Enter to skip)",
                    fg="cyan",
                ),
                default="",
            ) or None

    return {"aws_profile": aws_profile}




# ------------------------------------------------------------------
# Main init flow
# ------------------------------------------------------------------


def run_init() -> None:
    """Run the interactive project initializer."""
    click.echo("")
    click.echo(click.style("  SYNTH INIT", fg="green", bold=True))
    click.echo(click.style(
        "  Interactive project setup\n",
        dim=True,
    ))

    # 1. Project name
    name = click.prompt(
        click.style("  Project name", fg="cyan"),
        default=os.path.basename(os.getcwd()),
    )

    # 2. Description
    description = click.prompt(
        click.style("  Description", fg="cyan"),
        default="An AI agent built with SynthAgentSDK",
    )

    # 3. Provider
    click.echo("")
    click.echo(click.style("  Available providers:", fg="cyan"))
    for key, pcfg in _PROVIDERS.items():
        click.echo(
            f"    {click.style(key, fg='green'):<22s} {pcfg['display']}",
        )
    click.echo("")
    provider = click.prompt(
        click.style("  Provider", fg="cyan"),
        type=_PROVIDER_CHOICES,
        default="anthropic",
    )
    cfg = dict(_PROVIDERS[provider.lower()])
    is_agentcore = provider.lower() == "agentcore"

    # 3b. Check provider dependencies are installed
    _check_provider_deps(provider.lower(), cfg)

    # 4. Model selection (all providers)
    agentcore_state: dict[str, Any] = {}
    model_id = _run_model_selection(
        provider.lower(),
        cfg,
        agentcore_state if is_agentcore else None,
    )
    cfg["model"] = model_id

    # 5. Agent instructions
    click.echo("")
    instructions = click.prompt(
        click.style("  Agent instructions", fg="cyan"),
        default="You are a helpful assistant.",
    )

    # 6. Tool wizard
    tool_result = _run_tool_wizard()

    # 7. MCP wizard
    mcp_result = _run_mcp_wizard()

    # 8. Feature selection
    click.echo("")
    click.echo(click.style("  Select features:", fg="cyan"))
    selected_features: list[str] = []
    for key, desc in _FEATURES.items():
        if key == "deploy" and not is_agentcore:
            continue
        if click.confirm(
            f"    {click.style(desc, dim=True)}",
            default=False,
        ):
            selected_features.append(key)

    # 9. Credential check (AgentCore only)
    cred_result: dict[str, Any] = {}
    if is_agentcore:
        cred_result = _run_credential_check()

    # 10. Summary + confirm
    click.echo("")
    click.echo(click.style("  Summary:", fg="green", bold=True))
    click.echo(f"    Name:         {name}")
    click.echo(f"    Provider:     {cfg['display']}")
    click.echo(f"    Model:        {cfg['model']}")
    click.echo(f"    Features:     {', '.join(selected_features) or 'none'}")
    click.echo(f"    Instructions: {instructions[:50]}...")

    # Files to be created
    files_to_create = ["agent.py", "README.md", "synth.toml"]
    if is_agentcore:
        files_to_create += ["agentcore.yaml", ".env.template"]
    if "tools" in selected_features and not tool_result.files_created:
        files_to_create.append("tools.py")
    files_to_create.extend(tool_result.files_created)
    files_to_create.extend(mcp_result.files_created)
    if "eval" in selected_features:
        files_to_create.append("eval_dataset.json")
    click.echo(f"    Files:        {', '.join(files_to_create)}")
    click.echo("")

    if not click.confirm(
        click.style("  Create project?", fg="cyan"),
        default=True,
    ):
        click.echo("  Cancelled.")
        return

    # Assemble agentcore_setup dict for AgentCore projects
    agentcore_setup: dict[str, Any] | None = None
    if is_agentcore:
        agentcore_setup = {
            "aws_region": agentcore_state.get("aws_region", "us-east-1"),
            "model_id": model_id,
            "cris_enabled": agentcore_state.get("cris_enabled", False),
            "aws_profile": cred_result.get("aws_profile"),
        }

    # 11. Generate
    _generate_project(
        name=name,
        description=description,
        provider=provider.lower(),
        cfg=cfg,
        features=selected_features,
        instructions=instructions,
        agentcore_setup=agentcore_setup,
        tool_result=tool_result,
        mcp_result=mcp_result,
    )

    # 12. Deploy prompt (AgentCore only)
    if is_agentcore:
        click.echo("")
        if click.confirm(
            click.style("  Deploy now?", fg="cyan"),
            default=False,
        ):
            from synth.cli.deploy_cmd import run_deploy

            run_deploy(
                target="agentcore",
                dry_run=False,
                file=os.path.join(name, "agent.py"),
            )
        else:
            click.echo(
                click.style(
                    "  You can deploy later with: "
                    "synth deploy --target agentcore agent.py",
                    dim=True,
                ),
            )


# ------------------------------------------------------------------
# Project generation
# ------------------------------------------------------------------

def _generate_project(
    name: str,
    description: str,
    provider: str,
    cfg: dict[str, str],
    features: list[str],
    instructions: str,
    agentcore_setup: dict[str, Any] | None = None,
    tool_result: ToolWizardResult | None = None,
    mcp_result: McpWizardResult | None = None,
) -> None:
    """Generate the project directory and files."""
    if os.path.exists(name):
        click.echo(
            click.style(f"  Directory '{name}' already exists.", fg="red"),
        )
        raise SystemExit(1)

    os.makedirs(name)

    # Resolve wizard results
    tool_res = tool_result or ToolWizardResult()
    mcp_res = mcp_result or McpWizardResult()

    # Build agent.py — pass wizard results so imports/tools list is correct
    agent_code = _build_agent_code(
        provider, cfg, features, instructions,
        tool_imports=tool_res.agent_imports,
        mcp_registration=mcp_res.agent_mcp_registration,
    )
    _write(os.path.join(name, "agent.py"), agent_code)

    # Tools file — from wizard if provided, else legacy feature flag
    if tool_res.tools_code:
        _write(os.path.join(name, "tools.py"), tool_res.tools_code)
    elif "tools" in features:
        _write(os.path.join(name, "tools.py"), _TOOLS_CODE)

    # MCP server directory
    if mcp_res.server_dir and mcp_res.server_code:
        server_dir = os.path.join(name, mcp_res.server_dir)
        os.makedirs(server_dir, exist_ok=True)
        _write(os.path.join(server_dir, "server.py"), mcp_res.server_code)

    # Eval dataset
    if "eval" in features:
        _write(
            os.path.join(name, "eval_dataset.json"),
            _EVAL_DATASET,
        )

    # agentcore.yaml + .env.template for agentcore
    if provider == "agentcore":
        _write(os.path.join(name, ".env.template"), _ENV_TEMPLATE)
        _write(
            os.path.join(name, "agentcore.yaml"),
            _build_agentcore_yaml(name, agentcore_setup or {}),
        )

    # README
    _write(
        os.path.join(name, "README.md"),
        _build_readme(name, description, cfg, features),
    )

    # synth.toml config
    _write(
        os.path.join(name, "synth.toml"),
        _build_config(cfg, features),
    )

    # Success
    click.echo("")
    click.echo(click.style("  Project created!", fg="green", bold=True))
    click.echo("")
    click.echo(f"  {click.style(name + '/', fg='cyan')}")
    for f in os.listdir(name):
        click.echo(f"    {f}")
    click.echo("")
    click.echo("  Next steps:")
    click.echo(f"    {click.style('>', dim=True)} cd {name}")
    click.echo(
        f"    {click.style('>', dim=True)} "
        f"pip install synth-agent-sdk[{cfg['extra']}]",
    )
    if cfg["env_var"]:
        click.echo(
            f"    {click.style('>', dim=True)} "
            f'export {cfg["env_var"]}="your-key"',
        )
    click.echo(
        f'    {click.style(">", dim=True)} '
        f'synth  # interactive shell, then: dev agent.py',
    )
    click.echo("")


# ------------------------------------------------------------------
# Code generation helpers
# ------------------------------------------------------------------

def _build_agent_code(
    provider: str,
    cfg: dict[str, str],
    features: list[str],
    instructions: str,
    tool_imports: list[str] | None = None,
    mcp_registration: str | None = None,
) -> str:
    """Build the agent.py source code.

    Parameters
    ----------
    provider:
        Provider key (e.g. ``"anthropic"``).
    cfg:
        Provider config dict.
    features:
        Selected feature keys.
    instructions:
        Agent instruction string.
    tool_imports:
        Tool function names from the Tool Wizard to import from ``tools.py``.
    mcp_registration:
        MCP registration comment block to append (from MCP Wizard).
    """
    tool_imports = tool_imports or []

    imports = ['from synth import Agent']
    if "tools" in features or tool_imports:
        imports[0] += ', tool'
    if "tools" in features and not tool_imports:
        imports.append('from tools import search, calculate')
    elif tool_imports:
        imports.append(f'from tools import {", ".join(tool_imports)}')
    if "memory" in features:
        imports.append('from synth import Memory')
    if "guards" in features:
        imports.append('from synth import Guard')
    if "structured" in features:
        imports.append('from pydantic import BaseModel')
    if "deploy" in features:
        imports.append(
            'from synth.deploy.agentcore import agentcore_handler',
        )

    lines = [
        f'"""{cfg["display"]} agent built with SynthAgentSDK."""',
        '',
        'from __future__ import annotations',
        '',
    ]
    lines.extend(imports)
    lines.append('')

    # Structured output model
    if "structured" in features:
        lines.extend([
            '',
            'class Response(BaseModel):',
            '    """Structured response from the agent."""',
            '    answer: str',
            '    confidence: float',
            '',
        ])

    # Agent construction
    all_tool_names: list[str] = []
    if "tools" in features and not tool_imports:
        all_tool_names = ['search', 'calculate']
    elif tool_imports:
        all_tool_names = list(tool_imports)

    lines.append('')
    lines.append('agent = Agent(')
    lines.append(f'    model="{cfg["model"]}",')
    lines.append(f'    instructions="{instructions}",')
    if all_tool_names:
        lines.append(f'    tools=[{", ".join(all_tool_names)}],')
    if "memory" in features:
        lines.append('    memory=Memory.thread(),')
    if "guards" in features:
        lines.append('    guards=[Guard.no_pii_output()],')
    if "structured" in features:
        lines.append('    output_schema=Response,')
    lines.append(')')

    # AgentCore handler
    if "deploy" in features:
        lines.extend([
            '',
            '# AgentCore entry point - creates a BedrockAgentCoreApp instance',
            'app = agentcore_handler(agent)',
        ])

    # MCP registration comment block
    if mcp_registration:
        lines.append(mcp_registration.rstrip())

    # Main block
    lines.extend([
        '',
        '',
        'if __name__ == "__main__":',
        '    result = agent.run("Hello! What can you do?")',
        '    print(result.text)',
    ])

    return '\n'.join(lines) + '\n'


_TOOLS_CODE = '''"""Custom tools for the agent."""

from __future__ import annotations

from synth import tool


@tool
def search(query: str, limit: int = 5) -> list[str]:
    """Search for information matching the query."""
    # TODO: Replace with your real search implementation
    return [f"Result {i + 1} for '{query}'" for i in range(limit)]


@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression safely."""
    import math
    allowed = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
    try:
        result = eval(expression, {"__builtins__": {}}, allowed)  # noqa: S307
        return str(result)
    except Exception as e:
        return f"Error: {e}"
'''

_EVAL_DATASET = '''[
    {
        "input": "What is 2 + 2?",
        "expected": "4"
    },
    {
        "input": "Say hello",
        "expected": "Hello"
    }
]
'''

_ENV_TEMPLATE = '''# AWS Configuration
AWS_DEFAULT_REGION=us-east-1
# AWS_ACCESS_KEY_ID=your-access-key
# AWS_SECRET_ACCESS_KEY=your-secret-key
SYNTH_NO_BANNER=0
'''


def _build_readme(
    name: str,
    description: str,
    cfg: dict[str, str],
    features: list[str],
) -> str:
    """Build the README.md content."""
    lines = [
        f'# {name}',
        '',
        description,
        '',
        '## Setup',
        '',
        '```bash',
        f'pip install synth-agent-sdk[{cfg["extra"]}]',
    ]
    if cfg["env_var"]:
        lines.append(f'export {cfg["env_var"]}="your-key-here"')
    lines.extend([
        '```',
        '',
        '## Run',
        '',
        '```bash',
        'synth              # interactive shell',
        'synth dev agent.py',
        'synth run agent.py "Hello"',
        '```',
    ])
    if "eval" in features:
        lines.extend([
            '',
            '## Evaluate',
            '',
            '```bash',
            'synth eval agent.py --dataset eval_dataset.json',
            '```',
        ])
    if "deploy" in features:
        lines.extend([
            '',
            '## Deploy',
            '',
            '```bash',
            'synth deploy --target agentcore agent.py',
            '```',
        ])
    lines.append('')
    return '\n'.join(lines)


def _build_config(
    cfg: dict[str, str],
    features: list[str],
) -> str:
    """Build the synth.toml config file."""
    lines = [
        '# Synth SDK project configuration',
        '',
        '[agent]',
        f'model = "{cfg["model"]}"',
        '',
        '[dev]',
        'hot_reload = true',
        'stream = true',
        '',
    ]
    if "eval" in features:
        lines.extend([
            '[eval]',
            'dataset = "eval_dataset.json"',
            'threshold = 0.5',
            '',
        ])
    return '\n'.join(lines)


def _build_agentcore_yaml(name: str, setup: dict[str, Any]) -> str:
    """Build the agentcore.yaml content with region/model/CRIS fields.

    Parameters
    ----------
    name:
        The project/agent name.
    setup:
        Dict assembled in ``run_init()`` containing ``aws_region``,
        ``model_id``, ``cris_enabled``, ``aws_profile``.

    Returns
    -------
    str
        YAML content for ``agentcore.yaml``.
    """
    aws_region = setup.get("aws_region", "us-east-1")
    model_id = setup.get("model_id", "us.anthropic.claude-sonnet-4-5-20250514-v1:0")
    cris_enabled = setup.get("cris_enabled", False)
    aws_profile = setup.get("aws_profile")

    lines = [
        "# AgentCore Deployment Configuration",
        "#",
        "# This file is used by: synth deploy --target agentcore",
        "#",
        "# Agent Metadata",
        f"agent_name: {name}",
        'agent_description: "AI agent deployed to AWS AgentCore"',
        "",
        "# AWS Configuration",
        f"aws_region: {aws_region}",
        f"model_id: {model_id}",
        f"cris_enabled: {'true' if cris_enabled else 'false'}",
    ]

    if aws_profile:
        lines.append(f"aws_profile: {aws_profile}")

    lines.extend([
        "",
        "# IAM Permissions (least-privilege)",
        "permissions:",
        '  - "bedrock:InvokeModel"',
        '  - "bedrock:InvokeModelWithResponseStream"',
        '  - "bedrock-agentcore:*"',
        '  - "ssm:GetParameter"',
        '  - "secretsmanager:GetSecretValue"',
        "",
        "# Runtime Configuration",
        "runtime:",
        "  memory_mb: 512",
        "  timeout_seconds: 300",
        "",
        "# Environment Variables (non-sensitive only)",
        "environment:",
        '  SYNTH_NO_BANNER: "1"',
        "",
    ])

    return "\n".join(lines)


def _write(path: str, content: str) -> None:
    """Write content to a file."""
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
