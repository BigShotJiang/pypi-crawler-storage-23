"""Custom guard wrapper for the Synth SDK.

Wraps a user-supplied callable into a guard that raises a violation when
the function returns ``False`` or raises an exception.
"""

from __future__ import annotations

from typing import Callable

from synth.guards.base import BaseGuard
from synth.types import GuardContext, GuardResult


class CustomGuard(BaseGuard):
    """Guard that delegates to a user-supplied check function.

    Calls ``self.fn(content)`` and interprets the result:

    - ``True`` → check passes
    - ``False`` → check fails with a generic violation message
    - Exception raised → check fails with the exception message

    Parameters
    ----------
    fn:
        A callable that receives the content string and returns ``True``
        if the check passes.
    """

    def __init__(self, fn: Callable[..., bool]) -> None:
        super().__init__(name="CustomGuard")
        self.fn = fn

    async def check(self, content: str, context: GuardContext) -> GuardResult:
        """Run the user-supplied function against the content.

        Parameters
        ----------
        content:
            The text to inspect.
        context:
            Run context passed through for custom logic.

        Returns
        -------
        GuardResult
            Pass/fail result based on the function's return value.
        """
        try:
            result = self.fn(content)
        except Exception as exc:
            return GuardResult(
                passed=False,
                violation_message=(
                    f"Custom guard raised an exception: {exc}"
                ),
            )

        if result:
            return GuardResult(passed=True)
        return GuardResult(
            passed=False,
            violation_message="Custom guard check failed",
        )
