"""PII detection guard for the Synth SDK.

Scans agent output for personally identifiable information patterns
(emails, phone numbers, SSNs, etc.) and raises a violation when detected.
"""

from __future__ import annotations

import re

from synth.guards.base import BaseGuard
from synth.types import GuardContext, GuardResult


class PIIGuard(BaseGuard):
    """Guard that detects PII patterns in agent output.

    Uses regex-based detection for common PII types: email addresses,
    US phone numbers, and Social Security Numbers (SSNs).
    """

    _PII_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
        ("email", re.compile(
            r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
        )),
        ("phone number", re.compile(
            r"(?:\+?1[-.\s]?)?"
            r"(?:\(\d{3}\)|\d{3})"
            r"[-.\s]?\d{3}[-.\s]?\d{4}"
        )),
        ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ]

    def __init__(self) -> None:
        super().__init__(name="PIIGuard")

    async def check(self, content: str, context: GuardContext) -> GuardResult:
        """Scan content for PII patterns.

        Parameters
        ----------
        content:
            The text to inspect.
        context:
            Run context (unused by this guard).

        Returns
        -------
        GuardResult
            Pass/fail result with violation details if PII is found.
        """
        for pii_type, pattern in self._PII_PATTERNS:
            match = pattern.search(content)
            if match:
                return GuardResult(
                    passed=False,
                    violation_message=(
                        f"PII detected: {pii_type} found in output"
                    ),
                )
        return GuardResult(passed=True)
