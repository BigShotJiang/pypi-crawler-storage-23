"""Base memory ABC and Memory factory.

Defines the abstract interface that all memory backends must implement,
along with the ``Memory`` factory class that provides convenient static
methods for creating concrete memory instances.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable

from synth.types import Message


# ---------------------------------------------------------------------------
# BaseMemory ABC
# ---------------------------------------------------------------------------


class BaseMemory(ABC):
    """Abstract base class for all memory backends.

    Every memory implementation (thread, persistent, semantic) must subclass
    ``BaseMemory`` and implement :meth:`get_messages` and :meth:`add_messages`.

    Examples
    --------
    ::

        class MyMemory(BaseMemory):
            async def get_messages(self, thread_id: str) -> list[Message]:
                ...
            async def add_messages(self, thread_id: str, messages: list[Message]) -> None:
                ...
    """

    @abstractmethod
    async def get_messages(self, thread_id: str) -> list[Message]:
        """Retrieve all messages for the given thread.

        Parameters
        ----------
        thread_id:
            Unique identifier for the conversation thread.

        Returns
        -------
        list[Message]
            Ordered list of messages in the thread.
        """
        ...

    @abstractmethod
    async def add_messages(self, thread_id: str, messages: list[Message]) -> None:
        """Append messages to the given thread.

        Parameters
        ----------
        thread_id:
            Unique identifier for the conversation thread.
        messages:
            Messages to append.
        """
        ...


# ---------------------------------------------------------------------------
# Memory factory
# ---------------------------------------------------------------------------


class Memory:
    """Factory class for creating memory backend instances.

    Provides static methods that return concrete memory implementations.
    Use these instead of importing concrete classes directly.

    Examples
    --------
    ::

        agent = Agent(model="claude-sonnet-4-5", memory=Memory.thread())
        agent = Agent(model="gpt-4o", memory=Memory.persistent("redis://localhost"))
        agent = Agent(model="gemini-2.0-flash", memory=Memory.semantic(embedder=my_fn))
    """

    @staticmethod
    def thread(max_tokens: int = 100_000) -> ThreadMemory:  # type: ignore[name-defined]  # noqa: F821
        """Create an in-process thread-scoped memory backend.

        Parameters
        ----------
        max_tokens:
            Maximum estimated token count per thread before older messages
            are truncated.  Defaults to ``100_000``.

        Returns
        -------
        ThreadMemory
            A memory backend that stores messages in an in-process dictionary
            keyed by ``thread_id``.
        """
        from synth.memory.thread import ThreadMemory

        return ThreadMemory(max_tokens=max_tokens)

    @staticmethod
    def persistent(url: str) -> PersistentMemory:  # type: ignore[name-defined]  # noqa: F821
        """Create a persistent memory backend backed by an external store.

        Parameters
        ----------
        url:
            Connection URL for the backend (e.g. ``"redis://localhost:6379"``).

        Returns
        -------
        PersistentMemory
            A memory backend that stores and retrieves thread history from
            the external backend.
        """
        from synth.memory.persistent import PersistentMemory

        return PersistentMemory(url=url)

    @staticmethod
    def semantic(embedder: Callable) -> SemanticMemory:  # type: ignore[name-defined]  # noqa: F821
        """Create a semantic memory backend using vector embeddings.

        Parameters
        ----------
        embedder:
            A callable that converts text into vector embeddings for
            similarity-based retrieval.

        Returns
        -------
        SemanticMemory
            A memory backend that stores turns as vector embeddings and
            retrieves the most relevant context chunks at each call.
        """
        from synth.memory.semantic import SemanticMemory

        return SemanticMemory(embedder=embedder)
