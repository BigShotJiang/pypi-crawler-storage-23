"""AgentCore manifest (agent descriptor) generation.

Generates a deterministic agent descriptor declaring the agent's name,
description, supported actions, and required IAM permissions.
"""

from __future__ import annotations

from typing import Any


def generate_manifest(
    agent_or_graph: Any,
    *,
    name: str | None = None,
    description: str | None = None,
    permissions: list[str] | None = None,
) -> dict[str, Any]:
    """Generate an AgentCore agent descriptor.

    Parameters
    ----------
    agent_or_graph:
        A Synth ``Agent`` or ``Graph`` instance.
    name:
        Agent name.  Defaults to the model string or ``"synth-agent"``.
    description:
        Agent description.  Defaults to the agent's instructions.
    permissions:
        IAM permissions the agent requires.  Follows least-privilege.

    Returns
    -------
    dict
        A deterministic AgentCore manifest.
    """
    agent_name = name or _derive_name(agent_or_graph)
    agent_desc = description or _derive_description(agent_or_graph)
    actions = _derive_actions(agent_or_graph)

    return {
        "name": agent_name,
        "description": agent_desc,
        "actions": actions,
        "permissions": permissions or [],
        "runtime": {
            "type": "synth-sdk",
            "version": "0.4.0",
        },
    }


def _sanitize_for_path(value: str) -> str:
    """Sanitize a string for use as a directory/file name across platforms."""
    import re
    return re.sub(r'[:/\\*?"<>|]', "-", value)


def _derive_name(target: Any) -> str:
    """Derive a name from the agent or graph."""
    if hasattr(target, "model"):
        return _sanitize_for_path(str(target.model))
    return "synth-agent"


def _derive_description(target: Any) -> str:
    """Derive a description from the agent's instructions."""
    if hasattr(target, "instructions") and target.instructions:
        return target.instructions[:200]
    return "A Synth SDK agent deployed to AgentCore."


def _derive_actions(target: Any) -> list[dict[str, Any]]:
    """Derive supported actions from the agent's tools."""
    actions: list[dict[str, Any]] = [
        {"name": "invoke", "description": "Run the agent with a prompt."},
    ]

    if hasattr(target, "_registered_tools"):
        for tool_name, fn in target._registered_tools.items():
            schema = getattr(fn, "_tool_schema", {})
            actions.append({
                "name": tool_name,
                "description": schema.get("description", ""),
            })

    return actions
