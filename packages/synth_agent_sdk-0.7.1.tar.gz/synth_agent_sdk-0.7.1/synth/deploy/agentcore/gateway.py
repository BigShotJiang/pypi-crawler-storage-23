"""AgentCore Gateway MCP client.

Provides a ``GatewayMCPClient`` that connects a Synth agent to an
AgentCore Gateway using the Model Context Protocol (MCP).  The Gateway
exposes Lambda-backed tools via MCP, enabling agents to call them without
knowing the underlying Lambda ARNs or IAM details.

Two integration styles are supported:
- ``GatewayMCPClient`` — wraps the Strands ``MCPClient`` pattern
- ``create_langgraph_gateway_client`` — returns a ``MultiServerMCPClient``
  for LangGraph/LangChain agents

Authentication uses OAuth2 client credentials flow via Cognito, with
credentials stored in SSM Parameter Store and Secrets Manager.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from synth.errors import SynthConfigError

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Strands-style MCP client
# ---------------------------------------------------------------------------

class GatewayMCPClient:
    """MCP client for AgentCore Gateway (Strands-compatible).

    Connects to an AgentCore Gateway endpoint using Bearer token
    authentication and exposes tools via the MCP protocol.

    Parameters
    ----------
    gateway_url:
        The AgentCore Gateway URL.  If omitted, fetched from SSM using
        ``stack_name``.
    stack_name:
        The deployed stack name.  Defaults to the ``STACK_NAME`` env var.
        Used to look up ``gateway_url`` and Cognito credentials from SSM.
    access_token:
        A pre-obtained OAuth2 Bearer token.  If omitted, one is fetched
        automatically via the client credentials flow.

    Examples
    --------
    >>> client = GatewayMCPClient()
    >>> # Use as a tool source in a Strands agent:
    >>> agent = Agent(tools=[client.as_mcp_client()])
    """

    def __init__(
        self,
        gateway_url: str | None = None,
        stack_name: str | None = None,
        access_token: str | None = None,
    ) -> None:
        self._stack_name = stack_name or os.environ.get("STACK_NAME")
        self._gateway_url = gateway_url
        self._access_token = access_token

    def _resolve_gateway_url(self) -> str:
        """Resolve the Gateway URL from SSM if not provided directly."""
        if self._gateway_url:
            return self._gateway_url

        if not self._stack_name:
            raise SynthConfigError(
                message="STACK_NAME environment variable is required to resolve the Gateway URL.",
                component="GatewayMCPClient",
                suggestion="Set STACK_NAME or pass gateway_url directly to GatewayMCPClient.",
            )

        from synth.deploy.agentcore.ssm import get_ssm_parameter
        url = get_ssm_parameter(f"/{self._stack_name}/gateway_url")
        self._gateway_url = url
        return url

    def _resolve_token(self) -> str:
        """Resolve the OAuth2 access token, fetching one if needed."""
        if self._access_token:
            return self._access_token

        from synth.deploy.agentcore.auth import get_gateway_token
        token = get_gateway_token(self._stack_name)
        self._access_token = token
        return token

    def as_mcp_client(self, prefix: str = "gateway") -> Any:
        """Return a Strands ``MCPClient`` connected to the Gateway.

        Parameters
        ----------
        prefix:
            Tool name prefix applied by the MCP client.

        Returns
        -------
        MCPClient
            A configured Strands MCPClient instance.

        Raises
        ------
        SynthConfigError
            If the ``mcp`` or ``strands`` package is not installed.
        """
        try:
            from mcp.client.streamable_http import streamablehttp_client
            from strands.tools.mcp import MCPClient
        except ImportError:
            raise SynthConfigError(
                message="strands and mcp packages are required. Run: pip install synth-agent-sdk[agentcore]",
                component="GatewayMCPClient.as_mcp_client",
                suggestion="pip install synth-agent-sdk[agentcore]",
            )

        url = self._resolve_gateway_url()
        token = self._resolve_token()

        return MCPClient(
            lambda: streamablehttp_client(
                url=url,
                headers={"Authorization": f"Bearer {token}"},
            ),
            prefix=prefix,
        )

    async def as_langgraph_client(self) -> Any:
        """Return a LangGraph ``MultiServerMCPClient`` connected to the Gateway.

        Returns
        -------
        MultiServerMCPClient
            A configured LangGraph MCP client with tools loaded.

        Raises
        ------
        SynthConfigError
            If ``langchain-mcp-adapters`` is not installed.
        """
        try:
            from langchain_mcp_adapters.client import MultiServerMCPClient
        except ImportError:
            raise SynthConfigError(
                message="langchain-mcp-adapters is required. Run: pip install langchain-mcp-adapters",
                component="GatewayMCPClient.as_langgraph_client",
                suggestion="pip install langchain-mcp-adapters",
            )

        url = self._resolve_gateway_url()
        token = self._resolve_token()

        return MultiServerMCPClient({
            "gateway": {
                "transport": "streamable_http",
                "url": url,
                "headers": {"Authorization": f"Bearer {token}"},
            }
        })


# ---------------------------------------------------------------------------
# Convenience factory
# ---------------------------------------------------------------------------

def create_gateway_client(
    stack_name: str | None = None,
    gateway_url: str | None = None,
    access_token: str | None = None,
) -> GatewayMCPClient:
    """Create a ``GatewayMCPClient`` with automatic credential resolution.

    Parameters
    ----------
    stack_name:
        Deployed stack name.  Defaults to ``STACK_NAME`` env var.
    gateway_url:
        Gateway URL.  If omitted, fetched from SSM.
    access_token:
        Pre-obtained Bearer token.  If omitted, fetched via OAuth2.

    Returns
    -------
    GatewayMCPClient

    Examples
    --------
    >>> from synth.deploy.agentcore.gateway import create_gateway_client
    >>> client = create_gateway_client()
    >>> mcp = client.as_mcp_client()
    """
    return GatewayMCPClient(
        gateway_url=gateway_url,
        stack_name=stack_name,
        access_token=access_token,
    )
