"""AWS credential resolution for AgentCore deployments.

Detects and surfaces AWS credentials from environment variables,
``~/.aws/credentials``, the active IDE's AWS Toolkit extension, and the
AWS Toolkit VS Code extension profile store.  Credential values are never
stored as instance attributes or logged at any level above DEBUG.
"""

from __future__ import annotations

import configparser
import json
import logging
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path

from synth.errors import SynthConfigError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# IDE detection
# ---------------------------------------------------------------------------


class IDEType(Enum):
    """Identifies the IDE hosting the current terminal session."""

    KIRO = "kiro"
    VSCODE = "vscode"
    OTHER = "other"


def _detect_ide() -> IDEType:
    """Detect the IDE from the ``TERM_PROGRAM`` environment variable."""
    term_program = os.environ.get("TERM_PROGRAM", "").lower()
    if term_program == "kiro":
        return IDEType.KIRO
    if term_program == "vscode":
        return IDEType.VSCODE
    return IDEType.OTHER


def _find_kiro_token() -> dict | None:
    """Read the Kiro AWS Toolkit auth token if present and not expired.

    Returns ``None`` if the file doesn't exist, is malformed, belongs to a
    different auth method, or the token is expired.
    """
    token_path = Path.home() / ".aws" / "sso" / "cache" / "kiro-auth-token.json"
    if not token_path.exists():
        return None

    try:
        data = json.loads(token_path.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.debug("CredentialResolver: failed to read Kiro token file: %s", exc)
        return None

    # Must be a Kiro IdC token
    if data.get("authMethod") != "IdC" or data.get("provider") != "Internal":
        return None

    if not data.get("accessToken"):
        return None

    # Check expiry
    expires_at_str = data.get("expiresAt", "")
    try:
        expires_at = datetime.fromisoformat(expires_at_str.replace("Z", "+00:00"))
        if expires_at <= datetime.now(timezone.utc):
            logger.debug(
                "CredentialResolver: Kiro auth token is expired (expiresAt=%s)",
                expires_at_str,
            )
            return None
    except Exception:
        pass  # If we can't parse expiry, try anyway

    return data


def _exchange_idc_token_for_credentials(
    access_token: str,
    region: str,
    account_id: str | None = None,
) -> dict | None:
    """Exchange an AWS Identity Center access token for temporary IAM credentials.

    Uses ``sso.list_accounts()`` to find the first available account, then
    ``sso.list_account_roles()`` to find the first role, then
    ``sso.get_role_credentials()`` to obtain temporary credentials.

    Parameters
    ----------
    access_token:
        The IdC bearer token from the Kiro token file.
    region:
        AWS region for the SSO endpoint.
    account_id:
        Optional account ID to use directly, skipping ``list_accounts``.

    Returns
    -------
    dict | None
        Dict with keys ``accessKeyId``, ``secretAccessKey``, ``sessionToken``,
        ``expiration``, or ``None`` on failure.
    """
    try:
        boto3 = _import_boto3()
        sso_client = boto3.client("sso", region_name=region)

        if account_id is None:
            accounts_resp = sso_client.list_accounts(
                accessToken=access_token, maxResults=1
            )
            accounts = accounts_resp.get("accountList", [])
            if not accounts:
                logger.debug("CredentialResolver: no SSO accounts found for Kiro token")
                return None
            account_id = accounts[0]["accountId"]

        roles_resp = sso_client.list_account_roles(
            accessToken=access_token,
            accountId=account_id,
            maxResults=1,
        )
        roles = roles_resp.get("roleList", [])
        if not roles:
            logger.debug(
                "CredentialResolver: no SSO roles found for account %s", account_id
            )
            return None

        role_name = roles[0]["roleName"]
        creds_resp = sso_client.get_role_credentials(
            accessToken=access_token,
            accountId=account_id,
            roleName=role_name,
        )
        return creds_resp.get("roleCredentials")
    except Exception as exc:
        logger.debug("CredentialResolver: IdC token exchange failed: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Patterns for credential redaction (Requirement 8.2)
# ---------------------------------------------------------------------------

# AWS access key IDs: 20-char uppercase alphanumeric starting with AKIA or ASIA
_ACCESS_KEY_PATTERN = re.compile(r"(AKIA|ASIA)[A-Z0-9]{16}")

# AWS secret access keys: 40-char base64-like string
# Base64 alphabet: A-Z, a-z, 0-9, +, /, =
_SECRET_KEY_PATTERN = re.compile(r"[A-Za-z0-9+/]{40}")


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class ResolvedCredentials:
    """Resolved AWS credential metadata.

    Stores only the credential *source* and *account ID* for display
    purposes.  The actual key values are never stored here.

    Parameters
    ----------
    source:
        Where the credentials were found: ``"env"``, ``"aws_file"``,
        ``"aws_toolkit"``, or ``"profile:<name>"``.
    account_id:
        The raw AWS account ID (12-digit string).  Use
        ``CredentialResolver.mask_account_id()`` before displaying.
    profile_name:
        The named AWS profile, if applicable.
    """

    source: str
    account_id: str
    profile_name: str | None


# ---------------------------------------------------------------------------
# CredentialResolver
# ---------------------------------------------------------------------------


class CredentialResolver:
    """Detect and validate AWS credentials from multiple sources.

    Resolution order (per Requirement 1.1 / 7.2):

    1. ``AWS_ACCESS_KEY_ID`` / ``AWS_SECRET_ACCESS_KEY`` environment variables
    2. ``AWS_PROFILE`` environment variable (set by IDE toolkits and shells)
    3. ``~/.aws/credentials`` default profile
    4. ``~/.aws/credentials`` and ``~/.aws/config`` named profiles
    5. Active IDE toolkit (Kiro IdC token exchange via AWS SSO API)
    6. AWS Toolkit VS Code extension profiles (``~/.aws/sso/cache/``)

    Each source is tried in a ``try/except``; exceptions are logged at
    ``DEBUG`` level only and the resolver continues to the next source
    (Requirements 1.5 / 8.6).

    Credential values are **never** stored as instance attributes.

    Examples
    --------
    >>> resolver = CredentialResolver()
    >>> creds = resolver.resolve()
    >>> if creds:
    ...     print(resolver.mask_account_id(creds.account_id))
    """

    def resolve(self) -> ResolvedCredentials | None:
        """Check credential sources in priority order and return the first match.

        Returns
        -------
        ResolvedCredentials | None
            The first successfully resolved credentials, or ``None`` if no
            source yields valid credentials.
        """
        sources = [
            self._resolve_env_vars,
            self._resolve_aws_profile_env,
            self._resolve_aws_credentials_file,
            self._resolve_named_profiles,
            self._resolve_ide_toolkit,
            self._resolve_aws_toolkit,
        ]
        for source_fn in sources:
            try:
                result = source_fn()
                if result is not None:
                    return result
            except Exception as exc:  # noqa: BLE001
                logger.debug(
                    "CredentialResolver: source %s raised %s — continuing.",
                    source_fn.__name__,
                    type(exc).__name__,
                )
        return None

    def resolve_profile(self, profile_name: str) -> ResolvedCredentials | None:
        """Resolve credentials for a specific named AWS profile.

        Parameters
        ----------
        profile_name:
            The name of the AWS profile to resolve.

        Returns
        -------
        ResolvedCredentials | None
            Resolved credentials for the named profile, or ``None`` if the
            profile does not exist or cannot be read.

        Raises
        ------
        SynthConfigError
            If the profile name is empty or boto3 is unavailable.
        """
        if not profile_name or not profile_name.strip():
            raise SynthConfigError(
                message="Profile name must not be empty.",
                component="CredentialResolver",
                suggestion="Provide a valid AWS profile name from ~/.aws/credentials.",
            )

        try:
            boto3 = _import_boto3()
            region = self.get_profile_region(profile_name) or "us-east-1"
            session = boto3.Session(
                profile_name=profile_name,
                region_name=region,
            )
            account_id = _get_account_id(session)
            return ResolvedCredentials(
                source=f"profile:{profile_name}",
                account_id=account_id,
                profile_name=profile_name,
            )
        except SynthConfigError:
            raise
        except Exception as exc:
            logger.debug(
                "CredentialResolver: resolve_profile(%r) failed: %s",
                profile_name,
                exc,
            )
            return None

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def mask_account_id(self, account_id: str) -> str:
        """Return a masked version of an AWS account ID.

        Parameters
        ----------
        account_id:
            The raw 12-digit AWS account ID.

        Returns
        -------
        str
            ``"****"`` followed by the last 4 characters of the account ID.

        Examples
        --------
        >>> resolver = CredentialResolver()
        >>> resolver.mask_account_id("123456789012")
        '****9012'
        """
        if not account_id:
            return "****"
        return "****" + account_id[-4:]

    def redact_credentials(self, text: str) -> str:
        """Replace AWS credential patterns in *text* with ``[REDACTED]``.

        Replaces:

        - AWS access key IDs (``AKIA``/``ASIA`` + 16 alphanumeric chars)
        - AWS secret access keys (40-char base64-like strings)

        Parameters
        ----------
        text:
            The string to scan and redact.

        Returns
        -------
        str
            The input string with all credential patterns replaced by
            ``[REDACTED]``.

        Examples
        --------
        >>> resolver = CredentialResolver()
        >>> resolver.redact_credentials("key=AKIAIOSFODNN7EXAMPLE1234")
        'key=[REDACTED]'
        """
        # Redact access keys first (more specific pattern)
        text = _ACCESS_KEY_PATTERN.sub("[REDACTED]", text)
        # Redact 40-char base64-like secret keys
        text = _SECRET_KEY_PATTERN.sub("[REDACTED]", text)
        return text

    def list_available_profiles(self) -> list[str]:
        """Return names of all configured AWS profiles.

        Reads profile names from both ``~/.aws/credentials`` and
        ``~/.aws/config`` (where SSO profiles are typically defined).
        Does not validate whether the profiles have working credentials.

        Returns
        -------
        list[str]
            Sorted, deduplicated list of profile names.
        """
        profiles: set[str] = set()

        # ~/.aws/credentials profiles
        credentials_path = Path.home() / ".aws" / "credentials"
        if credentials_path.exists():
            creds_config = configparser.ConfigParser()
            creds_config.read(credentials_path)
            profiles.update(creds_config.sections())

        # ~/.aws/config profiles (SSO, assume-role, etc.)
        config_path = Path.home() / ".aws" / "config"
        if config_path.exists():
            aws_config = configparser.ConfigParser()
            aws_config.read(config_path)
            for section in aws_config.sections():
                # ~/.aws/config uses "profile <name>" sections
                if section.startswith("profile "):
                    profiles.add(section.removeprefix("profile ").strip())
                elif section != "default":
                    profiles.add(section)
                else:
                    profiles.add("default")

        return sorted(profiles)

    def get_profile_region(self, profile_name: str) -> str | None:
        """Read the region configured for a named AWS profile.

        Checks ``~/.aws/config`` first, then falls back to
        ``~/.aws/credentials`` (some tools write region there).
        Also checks the ``AWS_DEFAULT_REGION`` environment variable
        as a last resort.

        Parameters
        ----------
        profile_name:
            The AWS profile name to look up.

        Returns
        -------
        str | None
            The region string (e.g. ``"us-west-2"``), or ``None`` if
            no region is configured for the profile.
        """
        # 1. Check ~/.aws/config
        config_path = Path.home() / ".aws" / "config"
        if config_path.exists():
            aws_config = configparser.ConfigParser()
            aws_config.read(config_path)

            # ~/.aws/config uses "profile <name>" sections, except "default"
            section = (
                "default" if profile_name == "default"
                else f"profile {profile_name}"
            )
            if section in aws_config:
                region = aws_config[section].get("region")
                if region:
                    return region

        # 2. Check ~/.aws/credentials (non-standard but some tools use it)
        credentials_path = Path.home() / ".aws" / "credentials"
        if credentials_path.exists():
            creds_config = configparser.ConfigParser()
            creds_config.read(credentials_path)
            if profile_name in creds_config:
                region = creds_config[profile_name].get("region")
                if region:
                    return region

        # 3. Fall back to environment variable
        return os.environ.get("AWS_DEFAULT_REGION") or None

    # ------------------------------------------------------------------
    # Private source resolvers
    # ------------------------------------------------------------------

    def _resolve_env_vars(self) -> ResolvedCredentials | None:
        """Resolve credentials from environment variables."""
        access_key = os.environ.get("AWS_ACCESS_KEY_ID")
        secret_key = os.environ.get("AWS_SECRET_ACCESS_KEY")
        if not access_key or not secret_key:
            return None

        boto3 = _import_boto3()
        region = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
        session = boto3.Session(region_name=region)
        account_id = _get_account_id(session)
        return ResolvedCredentials(
            source="env",
            account_id=account_id,
            profile_name=None,
        )

    def _resolve_aws_credentials_file(self) -> ResolvedCredentials | None:
        """Resolve credentials from ``~/.aws/credentials`` default profile."""
        credentials_path = Path.home() / ".aws" / "credentials"
        if not credentials_path.exists():
            return None

        config = configparser.ConfigParser()
        config.read(credentials_path)

        if "default" not in config:
            return None

        default = config["default"]
        if not default.get("aws_access_key_id") or not default.get("aws_secret_access_key"):
            return None

        try:
            boto3 = _import_boto3()
            region = self.get_profile_region("default") or "us-east-1"
            session = boto3.Session(
                profile_name="default",
                region_name=region,
            )
            account_id = _get_account_id(session)
            return ResolvedCredentials(
                source="aws_file",
                account_id=account_id,
                profile_name="default",
            )
        except Exception as exc:
            # Surface expiry specifically so the user knows why this source was skipped
            if "Expired" in type(exc).__name__ or "expired" in str(exc).lower():
                logger.debug(
                    "CredentialResolver: ~/.aws/credentials [default] has expired tokens — skipping."
                )
            else:
                logger.debug(
                    "CredentialResolver: ~/.aws/credentials [default] failed: %s", exc
                )
            return None

    def _resolve_aws_profile_env(self) -> ResolvedCredentials | None:
        """Resolve credentials from the ``AWS_PROFILE`` environment variable.

        IDE toolkits and shell configurations often set ``AWS_PROFILE``
        to indicate the active profile.  This source is checked before
        the credentials file default profile so that the user's explicit
        choice takes precedence.
        """
        profile_name = os.environ.get("AWS_PROFILE")
        if not profile_name:
            return None

        try:
            boto3 = _import_boto3()
            region = self.get_profile_region(profile_name) or "us-east-1"
            session = boto3.Session(
                profile_name=profile_name,
                region_name=region,
            )
            account_id = _get_account_id(session)
            return ResolvedCredentials(
                source=f"env:AWS_PROFILE={profile_name}",
                account_id=account_id,
                profile_name=profile_name,
            )
        except Exception as exc:
            logger.debug(
                "CredentialResolver: AWS_PROFILE=%r failed: %s",
                profile_name,
                exc,
            )
            return None

    def _resolve_named_profiles(self) -> ResolvedCredentials | None:
        """Try all named profiles from ``~/.aws/credentials`` and ``~/.aws/config``.

        Iterates through available profiles (excluding ``default``, which is
        already handled by ``_resolve_aws_credentials_file``) and returns the
        first one that successfully resolves via STS.
        """
        profiles = self.list_available_profiles()
        # default is already tried by _resolve_aws_credentials_file
        profiles = [p for p in profiles if p != "default"]
        if not profiles:
            return None

        boto3 = _import_boto3()
        for profile_name in profiles:
            try:
                region = self.get_profile_region(profile_name) or "us-east-1"
                session = boto3.Session(
                    profile_name=profile_name,
                    region_name=region,
                )
                account_id = _get_account_id(session)
                return ResolvedCredentials(
                    source=f"profile:{profile_name}",
                    account_id=account_id,
                    profile_name=profile_name,
                )
            except Exception as exc:
                logger.debug(
                    "CredentialResolver: profile %r failed: %s",
                    profile_name,
                    exc,
                )
                continue
        return None

    def _resolve_ide_toolkit(self) -> ResolvedCredentials | None:
        """Resolve credentials from the active IDE's AWS Toolkit extension.

        Currently supports Kiro: reads ``kiro-auth-token.json`` and exchanges
        the IdC bearer token via the AWS SSO API to obtain temporary IAM
        credentials.  VS Code with IdC auth uses the same mechanism and can
        be extended here.
        """
        ide = _detect_ide()

        if ide == IDEType.KIRO:
            token_data = _find_kiro_token()
            if token_data is None:
                return None

            access_token = token_data["accessToken"]
            region = token_data.get("region", "us-east-1")

            temp_creds = _exchange_idc_token_for_credentials(access_token, region)
            if temp_creds is None:
                return None

            # Inject into environment so boto3 picks them up for subsequent calls
            os.environ["AWS_ACCESS_KEY_ID"] = temp_creds["accessKeyId"]
            os.environ["AWS_SECRET_ACCESS_KEY"] = temp_creds["secretAccessKey"]
            os.environ["AWS_SESSION_TOKEN"] = temp_creds["sessionToken"]
            os.environ["AWS_DEFAULT_REGION"] = region

            boto3 = _import_boto3()
            session = boto3.Session(region_name=region)
            account_id = _get_account_id(session)
            return ResolvedCredentials(
                source="ide_toolkit:kiro",
                account_id=account_id,
                profile_name=None,
            )

        # VS Code with AWS Toolkit uses the same SSO cache format — extend here if needed
        return None

    def _resolve_aws_toolkit(self) -> ResolvedCredentials | None:
        """Resolve credentials from AWS Toolkit VS Code SSO cache."""
        sso_cache_dir = Path.home() / ".aws" / "sso" / "cache"
        if not sso_cache_dir.exists():
            return None

        for cache_file in sorted(sso_cache_dir.glob("*.json")):
            try:
                data = json.loads(cache_file.read_text(encoding="utf-8"))
            except Exception as exc:
                logger.debug(
                    "CredentialResolver: failed to read SSO cache file %s: %s",
                    cache_file,
                    exc,
                )
                continue

            # SSO cache entries contain accessToken and expiresAt
            access_token = data.get("accessToken")
            if not access_token:
                continue

            # Try to get account info from the SSO token
            start_url = data.get("startUrl", "")
            profile_name = f"aws_toolkit:{Path(cache_file).stem}"

            try:
                boto3 = _import_boto3()
                session = boto3.Session(region_name="us-east-1")
                account_id = _get_account_id(session)
                return ResolvedCredentials(
                    source="aws_toolkit",
                    account_id=account_id,
                    profile_name=profile_name,
                )
            except Exception as exc:
                logger.debug(
                    "CredentialResolver: AWS Toolkit SSO session failed: %s", exc
                )
                continue

        return None


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _import_boto3():  # type: ignore[return]
    """Lazily import boto3, raising ``SynthConfigError`` if unavailable."""
    try:
        import boto3  # type: ignore[import-untyped]
        return boto3
    except ImportError as exc:
        raise SynthConfigError(
            message="boto3 is not installed. Run: pip install synth-agent-sdk[agentcore]",
            component="CredentialResolver",
            suggestion="pip install synth-agent-sdk[agentcore]",
        ) from exc


def _get_account_id(session: object) -> str:
    """Call STS GetCallerIdentity to retrieve the AWS account ID.

    Parameters
    ----------
    session:
        A ``boto3.Session`` instance.

    Returns
    -------
    str
        The 12-digit AWS account ID.

    Raises
    ------
    SynthConfigError
        If the STS call fails or returns no account ID.
    """
    try:
        # STS is a global service; fall back to us-east-1 if no region
        # is configured on the session.
        region = getattr(session, "region_name", None) or "us-east-1"
        sts = session.client("sts", region_name=region)  # type: ignore[attr-defined]
        identity = sts.get_caller_identity()
        account_id = identity.get("Account")
        if not account_id:
            raise SynthConfigError(
                message="STS GetCallerIdentity returned no Account field.",
                component="CredentialResolver",
                suggestion="Ensure the AWS credentials have sts:GetCallerIdentity permission.",
            )
        return account_id
    except SynthConfigError:
        raise
    except Exception as exc:
        err_str = str(exc)
        if "crt" in err_str.lower() or "login credential provider" in err_str.lower():
            suggestion = (
                'Install the AWS CRT dependency: pip install "botocore[crt]"'
            )
        else:
            suggestion = (
                "Ensure AWS credentials are valid and have "
                "sts:GetCallerIdentity permission."
            )
        raise SynthConfigError(
            message=f"Failed to call STS GetCallerIdentity: {exc}",
            component="CredentialResolver",
            suggestion=suggestion,
        ) from exc
