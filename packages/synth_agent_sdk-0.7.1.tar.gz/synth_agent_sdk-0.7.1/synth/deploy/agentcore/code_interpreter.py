"""AgentCore Code Interpreter tool.

Provides a framework-agnostic ``CodeInterpreterTools`` class that wraps
the Amazon Bedrock AgentCore Code Interpreter service.  Code Interpreter
executes Python (and other languages) in a secure, isolated sandbox with
session state persistence.

This is a built-in AgentCore service — it is integrated directly into
agents rather than proxied through the Gateway, following the AWS
documented pattern and avoiding unnecessary Lambda hops.

Usage with Synth ``@tool`` decorator:

    from synth.deploy.agentcore.code_interpreter import CodeInterpreterTools

    ci = CodeInterpreterTools()

    @tool
    def execute_python(code: str) -> str:
        \"\"\"Execute Python code in a secure AgentCore sandbox.\"\"\"
        return ci.execute(code)

    agent = Agent(model="bedrock/...", tools=[execute_python])
"""

from __future__ import annotations

import json
import logging
import os

from synth.errors import SynthConfigError

logger = logging.getLogger(__name__)


class CodeInterpreterTools:
    """Framework-agnostic wrapper for AgentCore Code Interpreter.

    Manages session lifecycle and provides a single ``execute()`` method
    for running code in the AgentCore sandbox.  Sessions persist state
    across calls (``clearContext=False`` by default), so variables defined
    in one call are available in subsequent calls.

    Parameters
    ----------
    region:
        AWS region.  Defaults to ``AWS_DEFAULT_REGION`` env var or
        ``us-east-1``.
    clear_context:
        If ``True``, reset the sandbox state between calls.  Defaults to
        ``False`` (persistent session).

    Examples
    --------
    >>> ci = CodeInterpreterTools()
    >>> result = ci.execute("print(2 + 2)")
    >>> print(result)
    """

    def __init__(
        self,
        region: str | None = None,
        clear_context: bool = False,
    ) -> None:
        self._region = region or os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
        self._clear_context = clear_context
        self._client: object | None = None

    # ------------------------------------------------------------------
    # Session management
    # ------------------------------------------------------------------

    def _get_client(self) -> object:
        """Lazily initialise the Code Interpreter client."""
        if self._client is None:
            try:
                from bedrock_agentcore.tools.code_interpreter_client import (
                    CodeInterpreter,
                )
            except ImportError:
                raise SynthConfigError(
                    message=(
                        "bedrock-agentcore is not installed. "
                        "Run: pip install synth-agent-sdk[agentcore]"
                    ),
                    component="CodeInterpreterTools",
                    suggestion="pip install synth-agent-sdk[agentcore]",
                )

            self._client = CodeInterpreter(self._region)
            self._client.start()  # type: ignore[attr-defined]
            logger.info("Code Interpreter session started in region %s", self._region)

        return self._client

    def cleanup(self) -> None:
        """Stop the Code Interpreter session and release resources.

        AgentCore automatically cleans up inactive sessions after a
        timeout, so calling this is optional but recommended for
        immediate resource release.
        """
        if self._client is not None:
            try:
                self._client.stop()  # type: ignore[attr-defined]
            except Exception as exc:
                logger.warning("Error stopping Code Interpreter session: %s", exc)
            finally:
                self._client = None
                logger.info("Code Interpreter session stopped.")

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def execute(self, code: str, language: str = "python") -> str:
        """Execute code in the AgentCore sandbox.

        Parameters
        ----------
        code:
            Source code to execute.
        language:
            Programming language.  Defaults to ``"python"``.

        Returns
        -------
        str
            JSON-encoded execution results, or an error message.

        Examples
        --------
        >>> ci = CodeInterpreterTools()
        >>> print(ci.execute("x = 42\\nprint(x)"))
        """
        client = self._get_client()
        try:
            response = client.invoke(  # type: ignore[attr-defined]
                "executeCode",
                {
                    "code": code,
                    "language": language,
                    "clearContext": self._clear_context,
                },
            )

            results = [
                event["result"]
                for event in response.get("stream", [])
                if "result" in event
            ]

            if results:
                return json.dumps(results, indent=2)
            return json.dumps({"output": "Code executed successfully (no output)."})

        except Exception as exc:
            logger.error("Code execution failed: %s", exc)
            return json.dumps({"error": f"Code execution failed: {exc}"})

    def execute_python(self, code: str) -> str:
        """Execute Python code in the AgentCore sandbox.

        Convenience wrapper around ``execute()`` for Python specifically.
        Suitable for use as a Synth ``@tool`` function body.

        Parameters
        ----------
        code:
            Python source code to execute.

        Returns
        -------
        str
            JSON-encoded execution results.

        Examples
        --------
        >>> ci = CodeInterpreterTools()
        >>> result = ci.execute_python("import math; print(math.pi)")
        """
        return self.execute(code, language="python")
