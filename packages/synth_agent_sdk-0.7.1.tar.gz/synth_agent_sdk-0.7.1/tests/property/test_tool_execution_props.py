# Feature: synth-agent-sdk, Properties 2, 3, 4, 38: Tool execution properties
"""Property-based tests for tool execution, registration, and type warnings.

**Property 2: Tool registration completeness**
**Validates: Requirements 2.2, 2.6**

For any collection of @tool functions and ToolKit instances, every individual
tool should be registered and available for invocation, with the total
registered tool count equal to the sum of all individual tools and all tools
within each ToolKit.

**Property 3: Tool execution feeds result back into conversation**
**Validates: Requirements 2.3**

For any tool call with valid arguments, the ToolExecutor should execute the
corresponding function and the return value should be available.

**Property 4: Tool execution error structure**
**Validates: Requirements 2.4**

For any tool function that raises an exception during execution, the resulting
ToolExecutionError should contain the tool name, the exact arguments passed,
and the original exception message.

**Property 38: Type mismatch warning for tool return values**
**Validates: Requirements 15.4**

For any tool whose return value type does not match its declared return
annotation, the Agent should emit a warning containing the tool name, the
expected type, and the actual type.
"""

from __future__ import annotations

import asyncio
import warnings

from hypothesis import given, settings, assume
from hypothesis import strategies as st

from synth.errors import ToolExecutionError
from synth.tools.decorator import tool
from synth.tools.toolkit import ToolKit
from synth.tools.executor import ToolExecutor, TypeMismatchWarning


def _run_async(coro):  # type: ignore[no-untyped-def]
    """Run a coroutine in a fresh event loop (safe inside Hypothesis tests)."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()

# ---------------------------------------------------------------------------
# Strategies
# ---------------------------------------------------------------------------

_VALID_IDENTS = st.from_regex(r"[a-z][a-z0-9_]{0,15}", fullmatch=True).filter(
    lambda s: s not in {
        "self", "cls", "return", "lambda", "def", "class", "import",
        "from", "if", "else", "elif", "for", "while", "try", "except",
        "with", "as", "pass", "break", "continue", "raise", "yield",
        "and", "or", "not", "in", "is", "None", "True", "False",
        "global", "nonlocal", "del", "assert", "finally",
    }
)

# Return values for tool functions
_RETURN_VALUES = st.one_of(
    st.text(min_size=0, max_size=50),
    st.integers(min_value=-1000, max_value=1000),
    st.floats(allow_nan=False, allow_infinity=False),
    st.booleans(),
)

# Exception types and messages for Property 4
_EXCEPTION_TYPES = st.sampled_from([ValueError, TypeError, RuntimeError, KeyError, IOError])
_EXCEPTION_MESSAGES = st.text(min_size=1, max_size=80).filter(lambda s: s.strip())


def _make_tool_fn(name: str, return_value):
    """Create a @tool-decorated function that returns a fixed value."""
    func_code = f"def {name}(x: str) -> str:\n    \"\"\"Tool {name}.\"\"\"\n    return __ret_val__"
    local_ns: dict = {"__ret_val__": return_value}
    exec(func_code, local_ns, local_ns)
    fn = local_ns[name]
    fn.__annotations__ = {"x": str, "return": str}
    return tool(fn)


def _make_raising_tool(name: str, exc_type: type, exc_msg: str):
    """Create a @tool-decorated function that raises an exception."""
    func_code = (
        f"def {name}(x: str) -> str:\n"
        f"    \"\"\"Tool {name}.\"\"\"\n"
        f"    raise __exc_type__(__exc_msg__)"
    )
    local_ns: dict = {"__exc_type__": exc_type, "__exc_msg__": exc_msg}
    exec(func_code, local_ns, local_ns)
    fn = local_ns[name]
    fn.__annotations__ = {"x": str, "return": str}
    return tool(fn)


# ---------------------------------------------------------------------------
# Property 2: Tool registration completeness
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    individual_names=st.lists(
        _VALID_IDENTS, min_size=0, max_size=4, unique=True,
    ),
    toolkit_names=st.lists(
        st.lists(_VALID_IDENTS, min_size=1, max_size=3, unique=True),
        min_size=0,
        max_size=3,
    ),
)
def test_tool_registration_completeness(individual_names, toolkit_names):
    """Property 2: For any collection of @tool functions and ToolKit instances,
    every individual tool should be registered and available, with the total
    count equal to the sum of all individual tools and all tools within each
    ToolKit.

    **Validates: Requirements 2.2, 2.6**
    """
    # Flatten all toolkit names and ensure global uniqueness
    all_toolkit_names = [n for group in toolkit_names for n in group]
    all_names = individual_names + all_toolkit_names
    assume(len(all_names) == len(set(all_names)))
    assume(len(all_names) > 0)

    # Create individual tool functions
    individual_tools = [_make_tool_fn(name, "ok") for name in individual_names]

    # Create ToolKit instances
    toolkits = []
    for group in toolkit_names:
        kit_tools = [_make_tool_fn(name, "ok") for name in group]
        toolkits.append(ToolKit(kit_tools))

    # Collect all tools into a single dict (simulating Agent registration)
    registered: dict = {}
    for fn in individual_tools:
        registered[fn._tool_schema["name"]] = fn
    for tk in toolkits:
        registered.update(tk.get_tools())

    # Total count equals sum of individual + toolkit tools
    expected_count = len(individual_names) + sum(len(g) for g in toolkit_names)
    assert len(registered) == expected_count

    # Every tool name is present
    for name in all_names:
        assert name in registered, f"Tool '{name}' not registered"

    # Every registered tool is callable
    for name, fn in registered.items():
        assert callable(fn)
        assert hasattr(fn, "_tool_schema")


# ---------------------------------------------------------------------------
# Property 3: Tool execution feeds result back into conversation
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    func_name=_VALID_IDENTS,
    return_value=_RETURN_VALUES,
    arg_value=st.text(min_size=1, max_size=30),
)
def test_tool_execution_feeds_result_back(func_name, return_value, arg_value):
    """Property 3: For any tool call with valid arguments, the ToolExecutor
    should execute the function and the return value should be available.

    **Validates: Requirements 2.3**
    """
    fn = _make_tool_fn(func_name, return_value)
    executor = ToolExecutor({func_name: fn})

    result = _run_async(executor.execute(func_name, {"x": arg_value}))

    # The result from execution matches the tool's return value
    assert result == return_value or (
        # Handle float NaN-like edge cases (already filtered, but be safe)
        type(result) == type(return_value) and str(result) == str(return_value)
    )


# ---------------------------------------------------------------------------
# Property 4: Tool execution error structure
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    func_name=_VALID_IDENTS,
    exc_type=_EXCEPTION_TYPES,
    exc_msg=_EXCEPTION_MESSAGES,
    arg_value=st.text(min_size=1, max_size=30),
)
def test_tool_execution_error_structure(func_name, exc_type, exc_msg, arg_value):
    """Property 4: For any tool function that raises an exception, the
    resulting ToolExecutionError should contain the tool name, the exact
    arguments passed, and the original exception message.

    **Validates: Requirements 2.4**
    """
    fn = _make_raising_tool(func_name, exc_type, exc_msg)
    executor = ToolExecutor({func_name: fn})
    args = {"x": arg_value}

    try:
        _run_async(executor.execute(func_name, args))
        raise AssertionError("Expected ToolExecutionError")
    except ToolExecutionError as err:
        # Tool name is preserved
        assert err.tool_name == func_name

        # Exact arguments are preserved
        assert err.tool_args == args

        # Original exception type and message are preserved
        assert isinstance(err.original_error, exc_type)
        # KeyError wraps its arg in quotes in __str__, so check args[0]
        assert err.original_error.args[0] == exc_msg

        # Error has required SynthError fields
        assert err.component == "ToolExecutor"
        assert err.suggestion  # non-empty


# ---------------------------------------------------------------------------
# Property 38: Type mismatch warning for tool return values
# ---------------------------------------------------------------------------


@settings(max_examples=100)
@given(
    func_name=_VALID_IDENTS,
    int_return=st.integers(min_value=-1000, max_value=1000),
)
def test_type_mismatch_warning_for_tool_return_values(func_name, int_return):
    """Property 38: For any tool whose return value type does not match its
    declared return annotation, the Agent should emit a warning containing the
    tool name, the expected type, and the actual type.

    **Validates: Requirements 15.4**
    """
    # Create a tool annotated to return str but actually returning int
    func_code = (
        f"def {func_name}(x: str) -> str:\n"
        f"    \"\"\"Tool {func_name}.\"\"\"\n"
        f"    return __ret_val__"
    )
    local_ns: dict = {"__ret_val__": int_return}
    exec(func_code, local_ns, local_ns)
    fn = local_ns[func_name]
    fn.__annotations__ = {"x": str, "return": str}
    decorated = tool(fn)

    executor = ToolExecutor({func_name: decorated})

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = _run_async(executor.execute(func_name, {"x": "test"}))

    # The result is still returned (warning, not error)
    assert result == int_return

    # Exactly one TypeMismatchWarning was emitted
    type_warnings = [x for x in w if issubclass(x.category, TypeMismatchWarning)]
    assert len(type_warnings) == 1

    warning_msg = str(type_warnings[0].message)
    # Warning contains the tool name
    assert func_name in warning_msg
    # Warning contains the expected type
    assert "str" in warning_msg
    # Warning contains the actual type
    assert "int" in warning_msg
