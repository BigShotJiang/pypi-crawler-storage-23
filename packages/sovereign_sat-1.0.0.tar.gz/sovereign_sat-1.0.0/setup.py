from setuptools import setup, find_packages
from setuptools.command.install import install
import subprocess
import os

class PostInstallCommand(install):
    def run(self):
        # This compiles the NS-33 engine on the user's machine
        print("--- SEIZING CONTROL: COMPILING NS-33 ENGINE ---")
        try:
            subprocess.run(["./configure"], check=True)
            subprocess.run(["make"], check=True)
        except Exception as e:
            print(f"Compilation failed: {e}")
        install.run(self)

setup(
    name="sovereign-sat",
    version="1.0.0",
    packages=find_packages(),
    include_package_data=True,
    cmdclass={
        'install': PostInstallCommand,
    },
    entry_points={
        'console_scripts': [
            'sovereign=sovereign_pkg.engine:main',
        ],
    },
    author="Americo Simoes",
    description="P=NP Sovereign Engine: NS-33 Fractal Layer",
    url="https://github.com/your-repo/Kissat-Sovereign",
)
