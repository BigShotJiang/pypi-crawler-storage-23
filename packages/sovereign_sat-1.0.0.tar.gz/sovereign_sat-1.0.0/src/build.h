#define VERSION "1.0.0-sovereign"
#define COMPILER "gcc"
#define ID "Singapore Zenith"
#define BUILD "2026"
