---
name: text_editor
description: View and edit files
---

### Overview
View and edit files on the local filesystem.

### Tools
- `text_editor`: A versatile tool to view, create, edit, and insert text into files.

### Usage
Use this skill to modify configuration files, read logs, or write new scripts.
