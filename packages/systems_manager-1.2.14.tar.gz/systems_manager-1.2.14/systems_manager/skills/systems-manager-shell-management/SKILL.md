---
name: systems-manager-shell-management
description: Systems Manager Shell Management capabilities for A2A Agent.
---
### Overview
This skill provides access to shell profile management.

### Capabilities
- **add_shell_alias**: Adds an alias to the user's shell profile.
