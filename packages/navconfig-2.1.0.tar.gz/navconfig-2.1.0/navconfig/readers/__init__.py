"""
Readers can add multiple object readers for loading data from different data sources.
"""
