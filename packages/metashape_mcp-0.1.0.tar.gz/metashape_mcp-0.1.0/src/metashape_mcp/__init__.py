"""Metashape MCP Server - LLM-driven photogrammetry workflows."""

__version__ = "0.1.0"
