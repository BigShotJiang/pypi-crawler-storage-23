# plain-redirection changelog

## [0.31.5](https://github.com/dropseed/plain/releases/plain-redirection@0.31.5) (2026-02-26)

### What's changed

- Removed redundant `allow_global_search = False` from redirect, redirect log, and not-found log admin views — this is now the default in plain-admin ([05d6fa2764](https://github.com/dropseed/plain/commit/05d6fa2764))

### Upgrade instructions

- No changes required.

## [0.31.4](https://github.com/dropseed/plain/releases/plain-redirection@0.31.4) (2026-02-26)

### What's changed

- Auto-formatted config files with updated linter configuration ([028bb95c3ae3](https://github.com/dropseed/plain/commit/028bb95c3ae3))

### Upgrade instructions

- No changes required.

## [0.31.3](https://github.com/dropseed/plain/releases/plain-redirection@0.31.3) (2026-02-12)

### What's changed

- Fixed missing `template_name` on Redirect admin CreateView and UpdateView ([ee27ad10c407](https://github.com/dropseed/plain/commit/ee27ad10c407))

### Upgrade instructions

- No changes required.

## [0.31.2](https://github.com/dropseed/plain/releases/plain-redirection@0.31.2) (2026-02-04)

### What's changed

- Added `__all__` export to `models` module for explicit public API boundaries ([f26a63a5c941](https://github.com/dropseed/plain/commit/f26a63a5c941))

### Upgrade instructions

- No changes required.

## [0.31.1](https://github.com/dropseed/plain/releases/plain-redirection@0.31.1) (2026-01-28)

### What's changed

- Added Settings section to README ([803fee1ad5](https://github.com/dropseed/plain/commit/803fee1ad5))

### Upgrade instructions

- No changes required.

## [0.31.0](https://github.com/dropseed/plain/releases/plain-redirection@0.31.0) (2026-01-15)

### What's changed

- Admin navigation icons updated to use more distinctive icons: `signpost-split` for redirects, `arrow-repeat` for redirect logs, and `exclamation-circle` for 404 logs ([0fc4dd345f](https://github.com/dropseed/plain/commit/0fc4dd345f))
- Admin list views for Redirects and 404 logs now include descriptive text to help users understand their purpose ([0fc4dd345f](https://github.com/dropseed/plain/commit/0fc4dd345f))

### Upgrade instructions

- No changes required

## [0.30.0](https://github.com/dropseed/plain/releases/plain-redirection@0.30.0) (2026-01-13)

### What's changed

- Improved README documentation with better organization, examples, and a consistent structure ([da37a78fbb](https://github.com/dropseed/plain/commit/da37a78fbb))

### Upgrade instructions

- No changes required

## [0.29.0](https://github.com/dropseed/plain/releases/plain-redirection@0.29.0) (2026-01-13)

### What's changed

- Updated internal redirect response to use the renamed `RedirectResponse` class (previously `ResponseRedirect`) to match the new naming convention in the core framework ([fad5bf28b0](https://github.com/dropseed/plain/commit/fad5bf28b0))

### Upgrade instructions

- No changes required

## [0.28.0](https://github.com/dropseed/plain/releases/plain-redirection@0.28.0) (2025-12-01)

### What's changed

- Uses new `request.client_ip` property instead of custom IP detection logic for logging redirects and 404s ([cb0bc5d08f](https://github.com/dropseed/plain/commit/cb0bc5d08f))

### Upgrade instructions

- No changes required

## [0.27.0](https://github.com/dropseed/plain/releases/plain-redirection@0.27.0) (2025-11-21)

### What's changed

- `ForeignKey` field renamed to `ForeignKeyField` for consistency with other field types ([8010204b36](https://github.com/dropseed/plain/commit/8010204b36))

### Upgrade instructions

- No changes required

## [0.26.1](https://github.com/dropseed/plain/releases/plain-redirection@0.26.1) (2025-11-17)

### What's changed

- Model queryset type annotations no longer use `ClassVar` to resolve type checker issues ([1c624ff29e](https://github.com/dropseed/plain/commit/1c624ff29e))

### Upgrade instructions

- No changes required

## [0.26.0](https://github.com/dropseed/plain/releases/plain-redirection@0.26.0) (2025-11-13)

### What's changed

- Model querysets now use `ClassVar` type annotations for improved type checking support ([c3b00a693c](https://github.com/dropseed/plain/commit/c3b00a693c))

### Upgrade instructions

- No changes required

## [0.25.0](https://github.com/dropseed/plain/releases/plain-redirection@0.25.0) (2025-11-13)

### What's changed

- Model fields now use explicit type annotations with `plain.models.types` field descriptors for improved IDE support and type checking ([c8f40fc75a](https://github.com/dropseed/plain/commit/c8f40fc75a))

### Upgrade instructions

- No changes required

## [0.24.1](https://github.com/dropseed/plain/releases/plain-redirection@0.24.1) (2025-10-31)

### What's changed

- Added BSD-3-Clause LICENSE file to the package ([8477355e65](https://github.com/dropseed/plain/commit/8477355e65))
- Added explicit `license = "BSD-3-Clause"` field to pyproject.toml for improved package metadata ([8477355e65](https://github.com/dropseed/plain/commit/8477355e65))

### Upgrade instructions

- No changes required

## [0.24.0](https://github.com/dropseed/plain/releases/plain-redirection@0.24.0) (2025-10-22)

### What's changed

- Middleware has been refactored to inherit from `HttpMiddleware` abstract base class ([b960eed6c6](https://github.com/dropseed/plain/commit/b960eed6c6))

### Upgrade instructions

- No changes required

## [0.23.0](https://github.com/dropseed/plain/releases/plain-redirection@0.23.0) (2025-10-17)

### What's changed

- Chores have been rewritten as abstract base classes instead of plain functions ([c4466d3c](https://github.com/dropseed/plain/commit/c4466d3c))

### Upgrade instructions

- No changes required

## [0.22.0](https://github.com/dropseed/plain/releases/plain-redirection@0.22.0) (2025-10-07)

### What's changed

- Model configuration changed from `class Meta` to `_meta` descriptor, then to `model_options` attribute ([17a378dc](https://github.com/dropseed/plain/commit/17a378dc), [73ba469b](https://github.com/dropseed/plain/commit/73ba469b))

### Upgrade instructions

- No changes required

## [0.21.1](https://github.com/dropseed/plain/releases/plain-redirection@0.21.1) (2025-10-06)

### What's changed

- Added comprehensive type annotations for improved IDE support and type checking ([c87ca27e](https://github.com/dropseed/plain/commit/c87ca27e))

### Upgrade instructions

- No changes required

## [0.21.0](https://github.com/dropseed/plain/releases/plain-redirection@0.21.0) (2025-09-12)

### What's changed

- Database manager `objects` attribute renamed to `query` for all models ([037a239e](https://github.com/dropseed/plain/commit/037a239e))
- Admin navigation icons updated to use consistent `arrow-right-circle` icon ([2aac07de](https://github.com/dropseed/plain/commit/2aac07de))
- Python 3.13 minimum requirement ([d86e307e](https://github.com/dropseed/plain/commit/d86e307e))

### Upgrade instructions

- Update all model queries from `.objects` to `.query` (e.g., `Redirect.objects.create()` becomes `Redirect.query.create()`, `RedirectLog.objects.all()` becomes `RedirectLog.query.all()`)

## [0.20.1](https://github.com/dropseed/plain/releases/plain-redirection@0.20.1) (2025-08-22)

### What's changed

- Admin navigation icons are now displayed on section headers instead of individual items for improved visual organization ([5a6479ac](https://github.com/dropseed/plain/commit/5a6479ac))

### Upgrade instructions

- No changes required

## [0.20.0](https://github.com/dropseed/plain/releases/plain-redirection@0.20.0) (2025-08-19)

### What's changed

- Added comprehensive README documentation with usage examples, API reference, and installation instructions ([4ebecd18](https://github.com/dropseed/plain/commit/4ebecd18))
- Removed manual CSRF token requirement from admin forms as part of framework-wide CSRF improvements ([955150800c](https://github.com/dropseed/plain/commit/955150800c))
- Updated package description in pyproject.toml to "A flexible URL redirection system with admin interface and logging" ([4ebecd18](https://github.com/dropseed/plain/commit/4ebecd18))

### Upgrade instructions

- No changes required

## [0.19.0](https://github.com/dropseed/plain/releases/plain-redirection@0.19.0) (2025-07-23)

### What's changed

- Admin navigation now includes Bootstrap icons for redirect, log, and 404 log sections ([9e9f8b0](https://github.com/dropseed/plain/commit/9e9f8b0))

### Upgrade instructions

- No changes required

## [0.18.0](https://github.com/dropseed/plain/releases/plain-redirection@0.18.0) (2025-07-22)

### What's changed

- Database models now use the simplified `PrimaryKeyField` instead of `BigAutoField` for primary keys ([4b8fa6a](https://github.com/dropseed/plain/commit/4b8fa6a))

### Upgrade instructions

- No changes required

## [0.17.0](https://github.com/dropseed/plain/releases/plain-redirection@0.17.0) (2025-07-18)

### What's changed

- Migration files have been consolidated into a single initial migration ([484f1b6](https://github.com/dropseed/plain/commit/484f1b6)).

### Upgrade instructions

- If you have an existing installation with applied migrations, run `plain migrate --prune plainredirection` to handle the migration consolidation (both in development and production environments).

## [0.16.2](https://github.com/dropseed/plain/releases/plain-redirection@0.16.2) (2025-06-24)

### What's changed

- No user-facing changes. This release only updates internal CHANGELOG formatting ([e1f5dd3](https://github.com/dropseed/plain/commit/e1f5dd3), [9a1963d](https://github.com/dropseed/plain/commit/9a1963d)).

### Upgrade instructions

- No changes required
