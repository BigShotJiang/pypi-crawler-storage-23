//! PyObsPlan: observation plan compilation and execution with NumPy zero-copy.

use numpy::{PyArray1, PyArrayMethods, PyReadonlyArray2, PyUntypedArrayMethods};
use pyo3::prelude::*;

use murk_ffi::{
    murk_obsplan_compile, murk_obsplan_destroy, murk_obsplan_execute, murk_obsplan_execute_agents,
    murk_obsplan_mask_len, murk_obsplan_output_len, MurkObsEntry, MurkObsResult,
};

use crate::config::{DType, PoolKernel, RegionType, TransformType};
use crate::error::check_status;
use crate::world::World;

/// A single observation entry describing what to observe.
#[pyclass(from_py_object)]
#[derive(Clone)]
pub(crate) struct ObsEntry {
    pub(crate) inner: MurkObsEntry,
}

#[pymethods]
impl ObsEntry {
    /// Create an observation entry.
    ///
    /// Args:
    ///     field_id: Field index to observe.
    ///     region_type: RegionType enum (All, AgentDisk, AgentRect).
    ///     transform_type: TransformType enum (Identity, Normalize).
    ///     normalize_min: Lower bound for Normalize transform.
    ///     normalize_max: Upper bound for Normalize transform.
    ///     dtype: DType enum (F32).
    ///     region_params: List of int32 region parameters (up to 8).
    ///         For AgentDisk: [radius].
    ///         For AgentRect: [half_extent_0, half_extent_1, ...].
    ///     pool_kernel: PoolKernel enum (NoPool, Mean, Max, Min, Sum).
    ///     pool_kernel_size: Pooling window size (ignored if pool_kernel=NoPool).
    ///     pool_stride: Pooling stride (ignored if pool_kernel=NoPool).
    #[new]
    #[pyo3(signature = (
        field_id,
        region_type=RegionType::All,
        transform_type=TransformType::Identity,
        normalize_min=0.0,
        normalize_max=1.0,
        dtype=DType::F32,
        region_params=None,
        pool_kernel=PoolKernel::NoPool,
        pool_kernel_size=0,
        pool_stride=0,
    ))]
    #[allow(clippy::too_many_arguments)]
    fn new(
        field_id: u32,
        region_type: RegionType,
        transform_type: TransformType,
        normalize_min: f32,
        normalize_max: f32,
        dtype: DType,
        region_params: Option<Vec<i32>>,
        pool_kernel: PoolKernel,
        pool_kernel_size: i32,
        pool_stride: i32,
    ) -> PyResult<Self> {
        let mut params = [0i32; 8];
        let n_params = if let Some(ref rp) = region_params {
            if rp.len() > 8 {
                return Err(pyo3::exceptions::PyValueError::new_err(
                    "region_params must have at most 8 elements",
                ));
            }
            for (i, &v) in rp.iter().enumerate() {
                params[i] = v;
            }
            rp.len() as i32
        } else {
            0
        };

        Ok(ObsEntry {
            inner: MurkObsEntry {
                field_id,
                region_type: region_type as i32,
                transform_type: transform_type as i32,
                normalize_min,
                normalize_max,
                dtype: dtype as i32,
                region_params: params,
                n_region_params: n_params,
                pool_kernel: pool_kernel as i32,
                pool_kernel_size,
                pool_stride,
            },
        })
    }
}

/// A compiled observation plan for efficient observation extraction.
///
/// Compile once, execute many times. Fills caller-allocated numpy buffers.
#[pyclass]
pub(crate) struct ObsPlan {
    handle: Option<u64>,
    cached_output_len: usize,
    cached_mask_len: usize,
}

#[pymethods]
impl ObsPlan {
    /// Compile an observation plan against a world.
    ///
    /// Args:
    ///     world: The world to compile against (for space topology).
    ///     entries: List of ObsEntry describing what to observe.
    #[new]
    fn new(py: Python<'_>, world: &World, entries: Vec<PyRef<'_, ObsEntry>>) -> PyResult<Self> {
        let world_h = world.handle()?;
        let ffi_entries: Vec<MurkObsEntry> = entries.iter().map(|e| e.inner).collect();

        let entries_addr = if ffi_entries.is_empty() {
            0usize
        } else {
            ffi_entries.as_ptr() as usize
        };
        let n_entries = ffi_entries.len();

        // Release GIL: murk_obsplan_compile locks OBS_PLANS + WORLDS.
        let (status, plan_h) = py.detach(|| {
            let mut ph: u64 = 0;
            let ptr = if entries_addr == 0 {
                std::ptr::null()
            } else {
                entries_addr as *const MurkObsEntry
            };
            let s = murk_obsplan_compile(world_h, ptr, n_entries, &mut ph);
            (s, ph)
        });
        check_status(status)?;

        // These lock OBS_PLANS briefly but don't touch WORLDS.
        let output_len = murk_obsplan_output_len(plan_h);
        let mask_len = murk_obsplan_mask_len(plan_h);
        if output_len < 0 || mask_len < 0 {
            return Err(pyo3::exceptions::PyRuntimeError::new_err(
                "failed to query obs plan dimensions",
            ));
        }

        Ok(ObsPlan {
            handle: Some(plan_h),
            cached_output_len: output_len as usize,
            cached_mask_len: mask_len as usize,
        })
    }

    /// Execute the observation plan, filling pre-allocated numpy buffers.
    ///
    /// Args:
    ///     world: The world to observe.
    ///     output: Pre-allocated **C-contiguous** float32 array of shape (output_len,).
    ///     mask: Pre-allocated **C-contiguous** uint8 array of shape (mask_len,).
    ///
    /// Returns:
    ///     Tuple of (tick_id, age_ticks).
    ///
    /// Raises:
    ///     ValueError: If `output` or `mask` is not C-contiguous.
    #[allow(unsafe_code)]
    fn execute<'py>(
        &self,
        py: Python<'py>,
        world: &World,
        output: &Bound<'py, PyArray1<f32>>,
        mask: &Bound<'py, PyArray1<u8>>,
    ) -> PyResult<(u64, u64)> {
        let plan_h = self.require_handle()?;
        let world_h = world.handle()?;

        if !output.is_c_contiguous() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "output array must be C-contiguous",
            ));
        }
        if !mask.is_c_contiguous() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "mask array must be C-contiguous",
            ));
        }

        // Convert pointers to usize so the closure is Ungil.
        let out_addr = unsafe { output.as_array_mut().as_mut_ptr() } as usize;
        let out_len = output.len();
        let mask_addr = unsafe { mask.as_array_mut().as_mut_ptr() } as usize;
        let mask_len = mask.len();

        let mut result = MurkObsResult::default();
        let result_addr = &mut result as *mut MurkObsResult as usize;

        let status = py.detach(|| {
            murk_obsplan_execute(
                world_h,
                plan_h,
                out_addr as *mut f32,
                out_len,
                mask_addr as *mut u8,
                mask_len,
                result_addr as *mut MurkObsResult,
            )
        });
        check_status(status)?;

        Ok((result.tick_id, result.age_ticks))
    }

    /// Execute the observation plan for N agents, filling pre-allocated numpy buffers.
    ///
    /// Args:
    ///     world: The world to observe.
    ///     agent_centers: C-contiguous int32 array of shape (N, ndim) with agent positions.
    ///     output: Pre-allocated C-contiguous float32 array of shape (N * output_len,).
    ///     mask: Pre-allocated C-contiguous uint8 array of shape (N * mask_len,).
    ///
    /// Returns:
    ///     List of (tick_id, age_ticks) tuples, one per agent.
    ///
    /// Raises:
    ///     ValueError: If arrays are not C-contiguous or have wrong shape.
    #[allow(unsafe_code)]
    fn execute_agents<'py>(
        &self,
        py: Python<'py>,
        world: &World,
        agent_centers: PyReadonlyArray2<'py, i32>,
        output: &Bound<'py, PyArray1<f32>>,
        mask: &Bound<'py, PyArray1<u8>>,
    ) -> PyResult<Vec<(u64, u64)>> {
        let plan_h = self.require_handle()?;
        let world_h = world.handle()?;

        if !agent_centers.is_c_contiguous() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "agent_centers array must be C-contiguous",
            ));
        }
        if !output.is_c_contiguous() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "output array must be C-contiguous",
            ));
        }
        if !mask.is_c_contiguous() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "mask array must be C-contiguous",
            ));
        }

        let shape = agent_centers.shape();
        let n_agents = shape[0] as i32;
        let ndim = shape[1] as i32;

        if n_agents <= 0 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "agent_centers must have at least one agent",
            ));
        }

        // Pointer addresses as usize for Ungil closure.
        let centers_addr = agent_centers.as_ptr() as usize;
        let out_addr = unsafe { output.as_array_mut().as_mut_ptr() } as usize;
        let out_len = output.len();
        let mask_addr = unsafe { mask.as_array_mut().as_mut_ptr() } as usize;
        let mask_len = mask.len();

        let n = n_agents as usize;
        let mut results = vec![MurkObsResult::default(); n];
        let results_addr = results.as_mut_ptr() as usize;

        let status = py.detach(|| {
            murk_obsplan_execute_agents(
                world_h,
                plan_h,
                centers_addr as *const i32,
                ndim,
                n_agents,
                out_addr as *mut f32,
                out_len,
                mask_addr as *mut u8,
                mask_len,
                results_addr as *mut MurkObsResult,
            )
        });
        check_status(status)?;

        Ok(results.iter().map(|r| (r.tick_id, r.age_ticks)).collect())
    }

    /// Number of f32 elements in the output buffer.
    #[getter]
    fn output_len(&self) -> usize {
        self.cached_output_len
    }

    /// Number of bytes in the mask buffer.
    #[getter]
    fn mask_len(&self) -> usize {
        self.cached_mask_len
    }

    /// Explicitly destroy the observation plan handle.
    fn destroy(&mut self, py: Python<'_>) {
        if let Some(h) = self.handle.take() {
            py.detach(|| murk_obsplan_destroy(h));
        }
    }

    fn __enter__(slf: PyRef<'_, Self>) -> PyRef<'_, Self> {
        slf
    }

    #[pyo3(signature = (_exc_type=None, _exc_val=None, _exc_tb=None))]
    fn __exit__(
        &mut self,
        py: Python<'_>,
        _exc_type: Option<&Bound<'_, PyAny>>,
        _exc_val: Option<&Bound<'_, PyAny>>,
        _exc_tb: Option<&Bound<'_, PyAny>>,
    ) {
        self.destroy(py);
    }
}

impl ObsPlan {
    fn require_handle(&self) -> PyResult<u64> {
        self.handle
            .ok_or_else(|| pyo3::exceptions::PyRuntimeError::new_err("ObsPlan already destroyed"))
    }
}

impl Drop for ObsPlan {
    fn drop(&mut self) {
        if let Some(h) = self.handle.take() {
            // Release GIL: murk_obsplan_destroy locks OBS_PLANS.
            Python::attach(|py| {
                py.detach(|| murk_obsplan_destroy(h));
            });
        }
    }
}
