import{J as r}from"./index-Bkyr7ll1.js";var a=r();export{a as r};
