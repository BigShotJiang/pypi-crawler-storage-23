import{c as o}from"./index-Bkyr7ll1.js";const c=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],n=o("chevron-up",c);export{n as C};
