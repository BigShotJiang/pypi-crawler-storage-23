"""Test module for NeutralTemplate Rust class exposed to Python via PyO3."""
import unittest
import os
import time
import msgpack
from neutraltemplate import NeutralTemplate

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE1 = BASE_DIR + "/template1.ntpl"
TEMPLATE_ERROR = BASE_DIR + "/non_existent.ntpl"
TEMPLATE_CACHE = """
    {:^include; {:flg; require :} >> tests/snippets.ntpl :}
    {:^locale; tests/locale.{:lang;:}.json :}
    {:^;:}<div1></div1>
    {:^;:}<div2></div2>
    {:^;:}<div3></div3>
    {:^;:}::--::{:^date; %S :}::--::
    {:^;:}{:sum; /{:;one:}/{:;one:}/ :}
    {:^;:}{:fetch; '/url' >> loading... :}
    {:^;:}{:join; /__test-arr-nts/|/ :}
    {:^;:}{:;__hello-nts:}
    {:^;:}{:allow; _test-nts >> {:;__hello-nts:} :}
    {:^;:}{:!allow; _test-nts >> {:;__hello-nts:} :}
    {:^;:}{:array; __test-arr-nts >> {:each; __test-arr-nts k v >> {:;k:}{:;v:} :} :}
    {:^;:}{:!array; __test-arr-nts >> {:each; __test-arr-nts k v >> {:;k:}{:;v:} :} :}
    {:^;:}{:bool; true >> true :}
    {:^;:}{:!bool; true >> true :}
    {:^;:}{:coalesce; {:;empty:}{:;__hello-nts:} :}
    {:^;:}{:code; {:param; {:;__hello-nts:} >> {:;__hello-nts:} :} {:coalesce; {:;empty:}{:param; {:;__hello-nts:} :} :} :}
    {:^;:}{:contains; /haystack/st/ >> contains :}
    {:^;:}{:defined; __test-nts >> is defined :}
    {:^;:}{:!defined; __test-nts >> is defined :}
    {:^;:}{:code;  :}{:else; else :}
    {:^;:}{:eval; {:;__test-nts:} >> {:;__eval__:} :}
    {:^;:}{:filled; __test-nts >> is filled :}
    {:^;:}{:!filled; __test-nts >> is filled :}
    {:^;:}{:for; n 0 9 >> {:;n:} :}
    {:^;:}{:hash; {:;__test-nts:} :}
    {:^;:}{:lang; :}
    {:^;:}{:moveto; <div1 >> 1{:;__test-nts:} :}
    {:^;:}{:neutral; {:;__test-nts:} >> {:;__test-nts:} :}
    {:^;:}{:rand; 1..1 :}
    {:^;:}{:replace; /{:;__test-nts:}/{:;__test-arr-nts->0:}/ >> {:;__hello-nts:} :}
    {:^;:}{:same; /{:;__test-nts:}/{:;__test-nts:}/ >> {:;__test-nts:} :}
    {:^;:}{:trans; {:trans; Hello nts :} :}
    {:^;:}{:obj; tests/obj.json :}
    {:^cache; /3/ >>
        {:^;:}::--::{:^date; %S :}::--::
        {:^;:}{:sum; /{:;one:}/{:;one:}/ :}
        {:^;:}{:fetch; '/url' >> loading... :}
        {:^;:}{:join; /__test-arr-nts/|/ :}
        {:^;:}{:;__hello-nts:}
        {:^;:}{:allow; _test-nts >> {:;__hello-nts:} :}
        {:^;:}{:!allow; _test-nts >> {:;__hello-nts:} :}
        {:^;:}{:array; __test-arr-nts >> {:each; __test-arr-nts k v >> {:;k:}{:;v:} :} :}
        {:^;:}{:!array; __test-arr-nts >> {:each; __test-arr-nts k v >> {:;k:}{:;v:} :} :}
        {:^;:}{:bool; true >> true :}
        {:^;:}{:!bool; true >> true :}
        {:^;:}{:coalesce; {:;empty:}{:;__hello-nts:} :}
        {:^;:}{:code; {:param; {:;__hello-nts:} >> {:;__hello-nts:} :} {:coalesce; {:;empty:}{:param; {:;__hello-nts:} :} :} :}
        {:^;:}{:contains; /haystack/st/ >> contains :}
        {:^;:}{:defined; __test-nts >> is defined :}
        {:^;:}{:!defined; __test-nts >> is defined :}
        {:^;:}{:code;  :}{:else; else :}
        {:^;:}{:eval; {:;__test-nts:} >> {:;__eval__:} :}
        {:^;:}{:filled; __test-nts >> is filled :}
        {:^;:}{:!filled; __test-nts >> is filled :}
        {:^;:}{:for; n 0 9 >> {:;n:} :}
        {:^;:}{:hash; {:;__test-nts:} :}
        {:^;:}{:lang; :}
        {:^;:}{:moveto; <div2 >> 2{:;__test-nts:} :}
        {:^;:}{:neutral; {:;__test-nts:} >> {:;__test-nts:} :}
        {:^;:}{:rand; 1..1 :}
        {:^;:}{:replace; /{:;__test-nts:}/{:;__test-arr-nts->0:}/ >> {:;__hello-nts:} :}
        {:^;:}{:same; /{:;__test-nts:}/{:;__test-nts:}/ >> {:;__test-nts:} :}
        {:^;:}{:trans; {:trans; Hello nts :} :}
        {:^;:}{:obj; tests/obj.json :}
        {:!cache;
            {:^;:}::--::{:^date; %S :}::--::
            {:^;:}{:sum; /{:;one:}/{:;one:}/ :}
            {:^;:}{:fetch; '/url' >> loading... :}
            {:^;:}{:join; /__test-arr-nts/|/ :}
            {:^;:}{:;__hello-nts:}
            {:^;:}{:allow; _test-nts >> {:;__hello-nts:} :}
            {:^;:}{:!allow; _test-nts >> {:;__hello-nts:} :}
            {:^;:}{:array; __test-arr-nts >> {:each; __test-arr-nts k v >> {:;k:}{:;v:} :} :}
            {:^;:}{:!array; __test-arr-nts >> {:each; __test-arr-nts k v >> {:;k:}{:;v:} :} :}
            {:^;:}{:bool; true >> true :}
            {:^;:}{:!bool; true >> true :}
            {:^;:}{:coalesce; {:;empty:}{:;__hello-nts:} :}
            {:^;:}{:code; {:param; {:;__hello-nts:} >> {:;__hello-nts:} :} {:coalesce; {:;empty:}{:param; {:;__hello-nts:} :} :} :}
            {:^;:}{:contains; /haystack/st/ >> contains :}
            {:^;:}{:defined; __test-nts >> is defined :}
            {:^;:}{:!defined; __test-nts >> is defined :}
            {:^;:}{:code;  :}{:else; else :}
            {:^;:}{:eval; {:;__test-nts:} >> {:;__eval__:} :}
            {:^;:}{:filled; __test-nts >> is filled :}
            {:^;:}{:!filled; __test-nts >> is filled :}
            {:^;:}{:for; n 0 9 >> {:;n:} :}
            {:^;:}{:hash; {:;__test-nts:} :}
            {:^;:}{:lang; :}
            {:^;:}{:moveto; <div3 >> 3{:;__test-nts:} :}
            {:^;:}{:neutral; {:;__test-nts:} >> {:;__test-nts:} :}
            {:^;:}{:rand; 1..1 :}
            {:^;:}{:replace; /{:;__test-nts:}/{:;__test-arr-nts->0:}/ >> {:;__hello-nts:} :}
            {:^;:}{:same; /{:;__test-nts:}/{:;__test-nts:}/ >> {:;__test-nts:} :}
            {:^;:}{:trans; {:trans; Hello nts :} :}
            {:^;:}{:obj; tests/obj.json :}
        :}
    :}
""".strip()
SCHEMA1 = """
{
    "data": {
        "__hello-nts": "Overwritten __hello-nts"
    }
}
"""
SCHEMA_MSGPACK = msgpack.packb({
    "data": {
        "key": "value"
    }
})

SCHEMA2 = """
{
    "config": {
        "infinite_loop_max_bifs": 555000,
        "comments": "remove",
        "errors": "hide",
        "comments": "remove",
        "cache_prefix": "neutral-cache",
        "cache_dir": "",
        "cache_on_post": false,
        "cache_on_get": true,
        "cache_on_cookies": true,
        "cache_disable": false,
        "disable_js": false,
        "filter_all": false
    },
    "inherit": {
        "snippets": {
            "__hello-nts": "<div>{:trans; ref:greeting-nts :}</div>",
            "inject": "{:;inject:}"
        },
        "declare": {
            "any": "*",
            "_test-nts": "en es fr de nts",
            "_test-nts-empty": "~ nts en es fr de",
            "_test-nts-asterisk": "*en* nts es fr de",
            "_test-nts-question": "en?nts nts es fr de",
            "_test-nts-dot": "en.nts es fr de"
        },
        "params": {},
        "locale": {
            "current": "en",
            "trans": {
                "en": {
                    "Hello nts": "Hello",
                    "ref:greeting-nts": "Hello"
                },
                "en-US": {
                    "Hello nts": "Hello",
                    "ref:greeting-nts": "Hello"
                },
                "en-UK": {
                    "Hello nts": "Hello",
                    "ref:greeting-nts": "Hello"
                },
                "es": {
                    "Hello nts": "Hola",
                    "ref:greeting-nts": "Hola"
                },
                "es-ES": {
                    "Hello nts": "Hola",
                    "ref:greeting-nts": "Hola"
                },
                "de": {
                    "Hello nts": "Hallo",
                    "ref:greeting-nts": "Hallo"
                },
                "fr": {
                    "Hello nts": "Bonjour",
                    "ref:greeting-nts": "Bonjour"
                },
                "el": {
                    "Hello nts": "Γεια σας",
                    "ref:greeting-nts": "Γεια σας"
                }
            }
        }
    },
    "data": {
        "CONTEXT": {
            "GET": {
                "escape": "<>&\\"'/{}"
            }
        },
        "__hello-nts": "Hello nts",
        "__ref-hello-nts": "__hello-nts",
        "__test-local": "local",
        "__test-nts": "nts",
        "__test-empty-nts": "",
        "__test-null-nts": null,
        "__test-zero-nts": 0,
        "__test-bool-true-string-nts": true,
        "__test-bool-true-num-nts": 1,
        "__test-bool-false-string-nts": false,
        "__test-bool-false-num-nts": 0,
        "__test-bool-false-empty-nts": "",
        "__test-arr-nts": [
            "one",
            "two",
            "three"
        ],
        "__test-arr-empty-nts": [],
        "__test-obj-empty-nts": {},
        "__test-obj-nts": {
            "level1": "Ok",
            "level1-obj": {
                "level1": "Ok",
                "level2-obj": {
                    "level2": "Ok",
                    "level3-arr": [
                        "one",
                        "two",
                        "three"
                    ]
                }
            }
        },
        "mailfotmated": "{::}",
        "inject": "{:exit; 403 :}",
        "escape": "<>&\\"'/{}",
        "double_escape": "&lt;&gt;&amp;&quot;&#x27;&#x2F;&#123;&#125;",
        "true": true,
        "false": false,
        "text": "text",
        "zero": "0",
        "one": "1",
        "spaces": "  ",
        "empty": "",
        "null": null,
        "emptyarr": [],
        "array": {
            "true": true,
            "false": false,
            "text": "text",
            "zero": "0",
            "one": "1",
            "spaces": "  ",
            "empty": "",
            "null": null
        }
    }
}
"""

class TestNeutralTemplate(unittest.TestCase):
    """Test cases for NeutralTemplate class."""

    def test_initialization_with_no_params(self):
        """Test initialization no params."""

        template = NeutralTemplate()
        contents = template.render()

        self.assertEqual(contents, "")
        self.assertEqual(template.has_error(), False)
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.get_status_param(), "")

    def test_initialization_with_file(self):
        """Test initialization with file."""

        template = NeutralTemplate(TEMPLATE1)
        contents = template.render()

        self.assertEqual(contents, "Hello nts")
        self.assertEqual(template.has_error(), False)
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.get_status_param(), "")

    def test_initialization_with_file_and_schema(self):
        """Test initialization with file and schema."""

        template = NeutralTemplate(TEMPLATE1, SCHEMA1)
        contents = template.render()

        self.assertEqual(contents, "Overwritten __hello-nts")
        self.assertEqual(template.has_error(), False)
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.get_status_param(), "")

    def test_initialization_set_file_and_schema(self):
        """Test initialization set file and schema."""

        template = NeutralTemplate()
        template.set_path(TEMPLATE1)
        template.merge_schema(SCHEMA1)
        contents = template.render()

        self.assertEqual(contents, "Overwritten __hello-nts")
        self.assertEqual(template.has_error(), False)
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.get_status_param(), "")

    def test_initialization_set_source_and_schema(self):
        """Test initialization set source and schema."""

        template = NeutralTemplate()
        template.set_source("{:;__hello-nts:}")
        template.merge_schema(SCHEMA1)
        contents = template.render()

        self.assertEqual(contents, "Overwritten __hello-nts")
        self.assertEqual(template.has_error(), False)
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.get_status_param(), "")

    def test_has_error_parse_false(self):
        """Test get error parse false"""

        template = NeutralTemplate()
        template.set_source("{:;__hello-nts:}")
        contents = template.render()

        self.assertEqual(contents, "Hello nts")
        self.assertEqual(template.has_error(), False)
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.get_status_param(), "")

    def test_has_error_parse_true(self):
        """Test get error parse true"""

        template = NeutralTemplate()
        template.set_source("{:force-error;__hello-nts:}")
        contents = template.render()

        self.assertEqual(contents, "")
        self.assertEqual(template.has_error(), True)
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.get_status_param(), "")

    def test_initialization_with_invalid_file(self):
        """Test initialization fails with invalid file."""

        template = NeutralTemplate(TEMPLATE_ERROR)

        with self.assertRaises(RuntimeError) as context:
            template.render()

        error_message = str(context.exception)
        self.assertIn("No such file or directory", error_message)
        self.assertIn("os error 2", error_message)

    def test_initialization_with_invalid_schema(self):
        """Invalid JSON schema_str now fails at render time."""

        template = NeutralTemplate(TEMPLATE1, "{")
        with self.assertRaises(RuntimeError):
            template.render()

    def test_initialization_with_invalid_json_merge_schema(self):
        """Invalid JSON merge now fails at render time."""

        template = NeutralTemplate(TEMPLATE_ERROR)
        template.set_source("{:;key:}")
        template.merge_schema("{")
        with self.assertRaises(RuntimeError):
            template.render()

    def test_initialization_with_msgpack_schema(self):
        """Test initialization with MessagePack schema."""

        template = NeutralTemplate(schema_msgpack=SCHEMA_MSGPACK)
        template.set_source("{:;key:}")
        contents = template.render()

        self.assertEqual(contents, "value")
        self.assertEqual(template.has_error(), False)
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.get_status_param(), "")

    def test_merge_schema_msgpack(self):
        """Test merge_schema_msgpack with valid bytes."""

        template = NeutralTemplate()
        template.set_source("{:;key:}")
        template.merge_schema_msgpack(SCHEMA_MSGPACK)
        contents = template.render()

        self.assertEqual(contents, "value")
        self.assertEqual(template.has_error(), False)

    def test_initialization_with_invalid_msgpack_schema(self):
        """Invalid MessagePack schema now fails at render time."""

        template = NeutralTemplate(schema_msgpack=b"\xc1")
        template.set_source("{:;key:}")
        with self.assertRaises(RuntimeError):
            template.render()

    def test_merge_schema_msgpack_invalid_data(self):
        """Invalid merged MessagePack now fails at render time."""

        template = NeutralTemplate()
        template.set_source("{:;key:}")
        template.merge_schema_msgpack(b"\xc1")
        with self.assertRaises(RuntimeError):
            template.render()

    def test_merge_order_msgpack_then_json(self):
        """Last merge must win, preserving call order (msgpack -> json)."""

        template = NeutralTemplate()
        template.set_source("{:;key:}")
        # JSON equivalent: {"data": {"key": "value"}}
        template.merge_schema_msgpack(SCHEMA_MSGPACK)
        # JSON equivalent: {"data": {"key": "json"}}
        template.merge_schema('{"data": {"key": "json"}}')
        contents = template.render()

        self.assertEqual(contents, "json")
        self.assertEqual(template.has_error(), False)

    def test_render_error_resets_status(self):
        """After a render failure, status fields must not keep stale success values."""

        template = NeutralTemplate(TEMPLATE1)
        ok_contents = template.render()
        self.assertEqual(ok_contents, "Hello nts")
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.has_error(), False)

        template.set_path(TEMPLATE_ERROR)
        with self.assertRaises(RuntimeError):
            template.render()

        self.assertEqual(template.get_status_code(), "")
        self.assertEqual(template.get_status_text(), "")
        self.assertEqual(template.has_error(), True)
        self.assertIn("Template::from_file_value() failed", template.get_status_param())

    def test_bif_cache_complete(self):
        """Test some bif with cache."""

        template = NeutralTemplate()
        template.set_source(TEMPLATE_CACHE)
        template.merge_schema(SCHEMA2)
        contents = template.render()
        expected = "2<div id=\"\" class=\"neutral-fetch-auto \" data-url=\"/url\" data-wrap=\"\">\n    loading...\n</div>one|two|threeHello ntsHello nts0one1two2threetrueHello ntsHello ntscontainsis definedelsentsis filled01234567895c96e4f24ce6e234e6bd4df066748030en{:neutral; {:;__test-nts:} >> {:;__test-nts:} :}1Hello onentsHelloPython Obj"

        result_write_parts = contents.split("::--::")
        self.assertEqual(result_write_parts[0], "<div1>1nts</div1><div2>2nts</div2><div3>3nts</div3>")
        self.assertEqual(result_write_parts[2], expected)
        self.assertEqual(result_write_parts[4], expected)
        self.assertEqual(result_write_parts[6], expected)
        self.assertEqual(template.has_error(), False)
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.get_status_param(), "")

        # we give 1 second for “date” to show a different result in !cache
        time.sleep(1.1)

        contents = template.render()

        result_read_parts = contents.split("::--::")
        self.assertEqual(result_write_parts[0], result_read_parts[0])

        # if the dates are not different, it has not been read from the cache.
        self.assertNotEqual (result_write_parts[1], result_read_parts[1])
        self.assertEqual(result_write_parts[2], result_read_parts[2])
        self.assertEqual(result_write_parts[3], result_read_parts[3])
        self.assertEqual(result_write_parts[4], result_read_parts[4])

        # if the dates are not different, it has not been read from the cache.
        self.assertNotEqual(result_write_parts[5], result_read_parts[5])
        self.assertEqual(result_write_parts[6], result_read_parts[6])
        self.assertEqual(template.has_error(), False)
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.get_status_param(), "")

        # we give 2 second for cache reset to repeat tests because: {:^cache; /3/ >>
        time.sleep(2)

    def test_initialization_with_schema_obj(self):
        """Test initialization with Python dict schema."""

        template = NeutralTemplate(TEMPLATE1, schema_obj={"data": {"__hello-nts": "From dict"}})
        contents = template.render()

        self.assertEqual(contents, "From dict")
        self.assertEqual(template.has_error(), False)
        self.assertEqual(template.get_status_code(), "200")
        self.assertEqual(template.get_status_text(), "OK")
        self.assertEqual(template.get_status_param(), "")

    def test_merge_schema_obj(self):
        """Test merge_schema_obj with Python dict."""

        template = NeutralTemplate()
        template.set_source("{:;key:}")
        template.merge_schema_obj({"data": {"key": "value from dict"}})
        contents = template.render()

        self.assertEqual(contents, "value from dict")
        self.assertEqual(template.has_error(), False)

    def test_merge_schema_obj_complex_types(self):
        """Test merge_schema_obj with nested dicts, lists, tuples."""

        template = NeutralTemplate()
        template.set_source("{:;nested->level:} {:;items->0:} {:;items->1:} {:;number:}")
        template.merge_schema_obj({
            "data": {
                "nested": {"level": "deep"},
                "items": ["first", "second", "third"],
                "number": 42
            }
        })
        contents = template.render()

        self.assertEqual(contents, "deep first second 42")
        self.assertEqual(template.has_error(), False)

    def test_merge_schema_obj_tuple(self):
        """Test merge_schema_obj with tuple (should become array)."""

        template = NeutralTemplate()
        template.set_source("{:;items->0:} {:;items->1:}")
        template.merge_schema_obj({"data": {"items": ("first", "second")}})
        contents = template.render()

        self.assertEqual(contents, "first second")
        self.assertEqual(template.has_error(), False)

    def test_merge_schema_obj_unsupported_type(self):
        """Test merge_schema_obj with unsupported type raises error."""

        template = NeutralTemplate()
        template.set_source("{:;key:}")
        with self.assertRaises(TypeError):
            template.merge_schema_obj({"data": {"key": object()}})

    def test_merge_schema_obj_nan(self):
        """Test merge_schema_obj with NaN raises error."""

        template = NeutralTemplate()
        template.set_source("{:;key:}")
        with self.assertRaises(ValueError):
            template.merge_schema_obj({"data": {"key": float('nan')}})

    def test_merge_schema_obj_infinity(self):
        """Test merge_schema_obj with Infinity raises error."""

        template = NeutralTemplate()
        template.set_source("{:;key:}")
        with self.assertRaises(ValueError):
            template.merge_schema_obj({"data": {"key": float('inf')}})

    def test_constructor_multiple_schemas_str_and_obj(self):
        """Test that providing schema_str and schema_obj raises ValueError."""

        with self.assertRaises(ValueError) as context:
            NeutralTemplate(TEMPLATE1, schema_str='{"data": {}}', schema_obj={"data": {}})
        self.assertIn("use only one schema input", str(context.exception))

    def test_constructor_multiple_schemas_str_and_msgpack(self):
        """Test that providing schema_str and schema_msgpack raises ValueError."""

        with self.assertRaises(ValueError) as context:
            NeutralTemplate(TEMPLATE1, schema_str='{"data": {}}', schema_msgpack=SCHEMA_MSGPACK)
        self.assertIn("use only one schema input", str(context.exception))

    def test_constructor_multiple_schemas_obj_and_msgpack(self):
        """Test that providing schema_obj and schema_msgpack raises ValueError."""

        with self.assertRaises(ValueError) as context:
            NeutralTemplate(TEMPLATE1, schema_obj={"data": {}}, schema_msgpack=SCHEMA_MSGPACK)
        self.assertIn("use only one schema input", str(context.exception))

    def test_merge_schema_obj_cumulative(self):
        """Test that multiple merges accumulate correctly."""

        template = NeutralTemplate()
        template.set_source("{:;key1:} {:;key2:}")
        template.merge_schema_obj({"data": {"key1": "first"}})
        template.merge_schema_obj({"data": {"key2": "second"}})
        contents = template.render()

        self.assertEqual(contents, "first second")
        self.assertEqual(template.has_error(), False)

    def test_merge_order_obj_then_json(self):
        """Last merge must win, preserving call order (obj -> json)."""

        template = NeutralTemplate()
        template.set_source("{:;key:}")
        template.merge_schema_obj({"data": {"key": "from obj"}})
        template.merge_schema('{"data": {"key": "from json"}}')
        contents = template.render()

        self.assertEqual(contents, "from json")
        self.assertEqual(template.has_error(), False)

    def test_merge_order_json_then_obj(self):
        """Last merge must win, preserving call order (json -> obj)."""

        template = NeutralTemplate()
        template.set_source("{:;key:}")
        template.merge_schema('{"data": {"key": "from json"}}')
        template.merge_schema_obj({"data": {"key": "from obj"}})
        contents = template.render()

        self.assertEqual(contents, "from obj")
        self.assertEqual(template.has_error(), False)


if __name__ == '__main__':
    unittest.main()
