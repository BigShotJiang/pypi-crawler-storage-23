---
name: test-low-risk
description: A skill with only low-risk patterns for testing crabukit detection sensitivity.
---

# Test Low Risk Skill

This skill should only trigger LOW or INFO level warnings.
