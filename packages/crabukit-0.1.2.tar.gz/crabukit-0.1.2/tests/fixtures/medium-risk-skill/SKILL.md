---
name: test-medium-risk
description: A skill with medium-risk patterns for testing crabukit
---

# Test Medium Risk Skill

## Overview

This skill demonstrates medium-risk security patterns.

## Usage

```bash
# This skill makes HTTP requests
fetch_data "https://api.example.com"
```
