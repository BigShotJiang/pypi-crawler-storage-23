"""Parsers for skill files."""
