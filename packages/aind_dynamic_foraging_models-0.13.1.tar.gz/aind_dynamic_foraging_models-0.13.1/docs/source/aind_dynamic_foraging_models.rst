aind\_dynamic\_foraging\_models package
=======================================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   aind_dynamic_foraging_models.generative_model
   aind_dynamic_foraging_models.logistic_regression

Module contents
---------------

.. automodule:: aind_dynamic_foraging_models
   :members:
   :undoc-members:
   :show-inheritance:
