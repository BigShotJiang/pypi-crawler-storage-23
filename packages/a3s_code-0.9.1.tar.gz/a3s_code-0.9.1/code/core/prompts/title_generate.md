Generate a short, descriptive title (max 6 words) for this conversation. Reply with ONLY the title, no quotes, no explanation.

{conversation}
