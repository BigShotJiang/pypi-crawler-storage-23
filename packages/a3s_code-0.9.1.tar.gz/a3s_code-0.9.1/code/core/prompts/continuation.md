The task is not yet complete. Continue working.

Review what has been done so far and identify what still needs to be finished.
Use tools to make progress — do not summarise or explain, just act.
