Generate a concise title (5-10 words) for this conversation.
The title should capture the main topic or task being discussed.
Return only the title, no explanation.
