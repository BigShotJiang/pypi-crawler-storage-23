"""
This package contains all related code for the TensorFlow (TF) RETURNN backend.
"""
