library flet_lottie;

export "src/extension.dart" show Extension;
