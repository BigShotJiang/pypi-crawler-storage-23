# Attestant

Python client library for [Attestant](https://getattestant.com) — automated ML compliance, fairness analysis, and HYDRA-32 provenance tracking for regulated AI deployments.

Compliance analysis runs entirely on the Attestant cloud. This library sends your model and evaluation data to the service and returns a pass/fail result with a dashboard link.

```
pip install attestant
```

## Quick Start

```python
import attestant

attestant.configure(api_key="pvt_live_...")

result = attestant.validate(
    model=clf,
    X_test=X_test,
    y_test=y_test,
    protected_df=demographics,
    protected_columns=["age", "race", "gender"],
)

if result.approved:
    print(f"Approved ({result.compliance_score}/100)")
else:
    print(f"Blocked: {result.reason}")
    for finding in result.findings:
        print(f"  - {finding}")

print(result.dashboard_url)
```

`validate()` uploads the model, evaluation features, ground-truth labels, and protected attributes to Attestant. The service runs disparate impact analysis (ECOA / Reg B), SR 11-7 model risk checks, and EU AI Act requirements, then returns the result synchronously. Row-level provenance — every feature cell and protected attribute for every evaluation row — is stored automatically.

## Usage Patterns

### Compliance gate (post-training)

```python
result = attestant.validate(
    model=clf,
    X_test=X_test,
    y_test=y_test,
    protected_df=demographics,             # separate from X_test — never fed to model
    protected_columns=["age", "race", "gender"],
    model_name="loan_approval",
    model_version="2.1.0",
)
```

### Inference monitoring (production)

```python
model = attestant.wrap(
    clf,
    model_name="loan_approval",
    model_version="2.1.0",
    protected_columns=["age", "race", "gender"],
)

# Drop-in replacement — tracks every prediction in background
predictions = model.predict(X_batch, protected_df=demographics_batch)

# Wait for uploads before process exits
model.flush()
```

### Fire-and-forget inference logging

```python
attestant.log_inference(
    model_name="loan_approval",
    predictions=external_preds,
    X=X_batch,
    protected_df=demographics_batch,
    protected_columns=["age", "race", "gender"],
)
```

### HYDRA-32 proxy discrimination detection (advanced)

HYDRA-32 is a 32-bit provenance encoding that propagates taint through feature engineering. If a model feature is derived from a protected attribute, its taint bit is set — enabling automatic proxy discrimination detection on the server.

```python
from attestant.utilities.hydra32_dag import DAGTracker, wrap_dataframe_dag
from attestant.utilities.hydra32 import ProvenanceTracker

dag_tracker = DAGTracker()
raw = wrap_dataframe_dag(data, dag_tracker, "applicants",
                         protected=["age", "race", "gender"])

# Derived features inherit taint if computed from protected columns
monthly_income = (raw["annual_income"] + raw["other_income"]) / 12
dti = raw["monthly_debt_payments"] / monthly_income

# Collect columns where taint propagated (proxy risk signals)
taint_risks = {
    col: ProvenanceTracker.risk_score(int(s._prov[0]))
    for col, s in tracked_series.items()
    if hasattr(s, "_prov") and ProvenanceTracker.is_tainted(int(s._prov[0]))
}

result = attestant.validate(..., taint_risks=taint_risks)
```

## What gets uploaded

| Call | Data sent |
|------|-----------|
| `validate()` | model (pickle), X_test, y_test, protected_df, taint_risks |
| `wrap().fit()` | training X, y, protected_df |
| `wrap().predict()` | inference X, predictions, protected_df |
| `log_inference()` | predictions, X, protected_df |

Protected attributes are stored as `source_protected` nodes in the provenance DAG — never used as model inputs, only for fairness analysis.

## Logging

The library is silent unless something fails. Errors surface through Python's standard `logging` module under the `attestant` logger:

```python
import logging
logging.basicConfig(level=logging.WARNING)  # see attestant errors
```

For structured production logging (JSON, compatible with Splunk/CloudWatch/Datadog):

```python
attestant.setup_logging(level="WARNING", fmt="json")
```

## ValidationResult

```python
result.approved            # bool — pass/fail
result.compliance_score    # float 0–100
result.findings            # list[str] — issues detected
result.dashboard_url       # link to full report
result.reason              # human-readable explanation if blocked
result.model_id            # server-assigned model ID
result.profile_used        # which compliance profile ran
result.regulations_run     # list of regulations checked
```

## Install options

```bash
pip install attestant                    # core (numpy, pandas only)
pip install "attestant[fairness]"        # + scikit-learn (for SHAP-based features)
```

## Requirements

- Python >= 3.9
- numpy >= 1.24
- pandas >= 2.0

## Dashboard

Results are available at [https://getattestant.com/client/](https://getattestant.com/client/).

## License

Business Source License 1.1 (BUSL-1.1). Copyright © 2024–2026 Attestant, Inc.
