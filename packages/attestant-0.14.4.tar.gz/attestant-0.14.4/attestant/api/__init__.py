"""
Attestant API Server: hosted backend for customer provenance persistence.

Implements the REST API that the `provenanced` package calls when
customers run `attestant.configure(api_key="...")`.

Endpoints:
    POST /api/v1/auth/validate     - Validate API key
    GET  /v1/health                - Health check
    POST /v1/pipelines             - Create pipeline
    PATCH /v1/pipelines/<id>       - Complete pipeline
    POST /v1/nodes                 - Batch store nodes
    GET  /v1/nodes                 - Query by fingerprint
    GET  /v1/nodes/fingerprint-map - Fingerprint→node_id map
    POST /v1/edges                 - Batch store edges
    GET  /v1/edges                 - Query edges for node
    POST /v1/sources               - Register source
    GET  /v1/sources               - Query source info
    POST /v1/results               - Store per-row results
    GET  /v1/results               - Query results for row
    GET  /v1/stats                 - Get storage stats

Usage:
    ATTESTANT_DSN=postgresql://... ATTESTANT_API_SECRET=... python -m attestant.api.server
"""
