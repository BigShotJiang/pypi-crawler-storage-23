"""Alias module for backward compatibility - maps docs.* to documentation.*"""
