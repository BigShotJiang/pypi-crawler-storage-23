"""
Admin / Founder Dashboard: Platform-Wide Monitoring.

Shows all tenants, system health, pipeline stats, error rates,
global compliance posture, and alert overview.

Protected by user authentication with granular permissions.

Usage:
    DASH_WRITER_DSN=postgresql://... python -m attestant.dashboard.admin_app
    # Then open: http://localhost:5004

Requires Aurora PostgreSQL (DASH_WRITER_DSN).
"""

import hashlib
import hmac
import logging
import os
import re
import secrets
import time
from collections import defaultdict
from functools import wraps
from typing import Any, Optional

try:
    import bcrypt as _bcrypt
    bcrypt: Optional[Any] = _bcrypt
except ImportError:
    bcrypt = None

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from flask import Flask, jsonify, render_template, render_template_string, request, redirect, make_response

logger = logging.getLogger(__name__)

app = Flask(__name__)


class _ReverseProxied:
    """WSGI middleware that adjusts SCRIPT_NAME from X-Script-Name header."""
    def __init__(self, wsgi_app):
        self.app = wsgi_app

    def __call__(self, environ, start_response):
        script_name = environ.get("HTTP_X_SCRIPT_NAME", "")
        if script_name:
            environ["SCRIPT_NAME"] = script_name
            path_info = environ.get("PATH_INFO", "")
            if path_info.startswith(script_name):
                environ["PATH_INFO"] = path_info[len(script_name):]
        # Trust X-Forwarded-Proto from nginx so request.scheme is correct
        forwarded_proto = environ.get("HTTP_X_FORWARDED_PROTO", "")
        if forwarded_proto in ("https", "http"):
            environ["wsgi.url_scheme"] = forwarded_proto
        return self.app(environ, start_response)


app.wsgi_app = _ReverseProxied(app.wsgi_app)


@app.after_request
def _fix_redirect_location(response):
    """Prepend SCRIPT_NAME to redirect Location headers."""
    if response.status_code in (301, 302, 303, 307, 308):
        location = response.headers.get("Location", "")
        if location.startswith("/") and not location.startswith(request.script_root + "/"):
            response.headers["Location"] = request.script_root + location
    return response


ADMIN_TENANT = "_platform_admin"

TIER_PRICING = {
    "enterprise": int(os.environ.get("ATTESTANT_PRICE_ENTERPRISE", "5000")),
    "professional": int(os.environ.get("ATTESTANT_PRICE_PROFESSIONAL", "2000")),
    "starter": int(os.environ.get("ATTESTANT_PRICE_STARTER", "500")),
}

_store = None

_SESSION_SECRET = os.environ.get("ADMIN_SESSION_SECRET") or secrets.token_hex(32)

VALID_ROLES = ("admin", "manager", "analyst")

# ---------------------------------------------------------------------------
# Granular Permissions
# ---------------------------------------------------------------------------

from attestant.dashboard.dashdb import ALL_PERMISSIONS, ROLE_DEFAULTS
from attestant.dashboard import billing as _billing

def _get_effective_permissions(tenant_id, user_email, user_role):
    store = _get_store()
    if store is None:
        return ROLE_DEFAULTS.get(user_role, ROLE_DEFAULTS["analyst"])
    user_row = store.get_user_by_email(tenant_id, user_email)
    if not user_row:
        return ROLE_DEFAULTS.get(user_role, ROLE_DEFAULTS["analyst"])
    db_perms = store.get_user_permissions(tenant_id, user_row["id"])
    if db_perms:
        defaults = ROLE_DEFAULTS.get(user_role, ROLE_DEFAULTS["analyst"])
        merged = dict(defaults)
        merged.update(db_perms)
        return merged
    return ROLE_DEFAULTS.get(user_role, ROLE_DEFAULTS["analyst"])


def require_permission(perm_name):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = getattr(request, "current_user", None)
            if not user:
                return jsonify({"error": "Unauthorized"}), 401
            if user["role"] == "admin":
                return f(*args, **kwargs)
            perms = _get_effective_permissions(
                ADMIN_TENANT, user["email"], user["role"]
            )
            if not perms.get(perm_name, False):
                return jsonify({"error": "Insufficient permissions"}), 403
            return f(*args, **kwargs)
        return decorated
    return decorator


@app.after_request
def add_security_headers(response):
    """Add security headers to all responses."""
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data:; "
        "connect-src 'self'"
    )
    return response


def _get_store():
    global _store
    if _store is not None:
        return _store
    try:
        from .dashdb import DashboardStore
        store = DashboardStore(
            writer_dsn=os.environ["DASH_WRITER_DSN"],
            reader_dsn=os.environ.get("DASH_READER_DSN"),
        )
        store.connect()
        store.ensure_schema()
        _store = store
        return _store
    except Exception as exc:
        logger.error("Admin store init failed: %s", exc)
        return None


_AUTH_FAILURES: defaultdict = defaultdict(list)
_MAX_FAILURES = 5
_FAILURE_WINDOW = 300
_LOCKOUT_DURATION = 600


def _is_rate_limited(ip: str) -> bool:
    """Check if an IP is currently locked out due to repeated auth failures."""
    now = time.monotonic()
    _AUTH_FAILURES[ip] = [t for t in _AUTH_FAILURES[ip] if now - t < _FAILURE_WINDOW]
    if len(_AUTH_FAILURES[ip]) >= _MAX_FAILURES:
        if now - _AUTH_FAILURES[ip][-1] < _LOCKOUT_DURATION:
            return True
        _AUTH_FAILURES[ip].clear()
    return False


def _record_auth_failure(ip: str) -> None:
    """Record a failed authentication attempt for rate limiting."""
    _AUTH_FAILURES[ip].append(time.monotonic())
    logger.warning("Failed admin auth attempt from %s (attempt %d)", ip, len(_AUTH_FAILURES[ip]))


def _hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    if not bcrypt:
        raise RuntimeError("bcrypt not installed")
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def _verify_password(password: str, password_hash: str) -> bool:
    """Verify a password against a bcrypt hash (timing-safe)."""
    if not bcrypt:
        raise RuntimeError("bcrypt not installed")
    if len(password) > 1024:
        return False
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))
    except Exception as exc:
        logger.warning("Password verification error: %s", exc)
        return False


def _make_session_token(email: str) -> str:
    """Create an HMAC session token with timestamp for 1hr expiry."""
    ts = str(int(time.time()))
    payload = f"{email}|{ts}"
    sig = hmac.new(_SESSION_SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return f"{payload}|{sig}"


def _get_user_from_session():
    """Extract user from session cookie, return user dict or None."""
    cookie = request.cookies.get("attestant_admin_session")
    if not cookie:
        return None
    try:
        parts = cookie.rsplit("|", 1)
        if len(parts) != 2:
            return None
        payload, sig = parts
        expected = hmac.new(_SESSION_SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected):
            return None
        fields = payload.split("|")
        if len(fields) != 2:
            return None
        email, ts = fields
        age = int(time.time()) - int(ts)
        if age > 3600 or age < -60:
            return None
    except Exception as exc:
        logger.debug("Admin session token parse error: %s", exc)
        return None
    store = _get_store()
    if not store:
        return None
    user = store.get_user_by_email(ADMIN_TENANT, email)
    if not user or not user.get("active", True):
        return None
    return user


def require_admin_auth(f):
    """User-based authentication for admin endpoints. Also accepts static Bearer token for cron/automation."""
    @wraps(f)
    def decorated(*args, **kwargs):
        user = _get_user_from_session()
        if user:
            request.current_user = user
            return f(*args, **kwargs)

        # Static token auth for cron jobs / automation
        static_token = os.environ.get("ADMIN_TOKEN", "")
        if static_token:
            auth_header = request.headers.get("Authorization", "")
            if auth_header.startswith("Bearer "):
                token = auth_header[7:]
                if hmac.compare_digest(token, static_token):
                    request.current_user = {"email": "cron@system", "role": "admin"}
                    return f(*args, **kwargs)

        client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")
        if "," in client_ip:
            client_ip = client_ip.split(",")[0].strip()

        accept = request.headers.get("Accept", "")
        is_ajax = request.headers.get("X-Requested-With") == "XMLHttpRequest"
        is_fetch = "application/json" in accept and "text/html" not in accept
        if not is_ajax and not is_fetch and "text/html" in accept:
            return redirect("/login")

        return jsonify({"error": "Unauthorized"}), 401
    return decorated


def require_role(role: str):
    """Require a specific role."""
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user = getattr(request, "current_user", None)
            if not user:
                return jsonify({"error": "Unauthorized"}), 401
            if user["role"] != role:
                return jsonify({"error": "Forbidden"}), 403
            return f(*args, **kwargs)
        return decorated
    return decorator


def _validate_email(email: str) -> bool:
    """Basic email validation."""
    return bool(re.match(r"^[^@]+@[^@]+\.[^@]+$", email))


# ---------------------------------------------------------------------------
# Login page
# ---------------------------------------------------------------------------

_LOGIN_HTML = """<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Attestant -- Admin Login</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#f1f5f9;--surface:#ffffff;--border:#e2e8f0;--text-1:#0f172a;--text-2:#64748b;--text-3:#94a3b8;--blue:#3b82f6;--red:#ef4444;--radius:8px}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:var(--bg);color:var(--text-1);display:flex;align-items:center;justify-content:center;min-height:100vh;-webkit-font-smoothing:antialiased}
.login-card{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:40px;width:360px;text-align:center;box-shadow:0 1px 3px rgba(0,0,0,0.06)}
.logo{font-size:20px;font-weight:700;letter-spacing:-0.5px;margin-bottom:4px}
.logo-sub{font-size:12px;color:var(--text-3);margin-bottom:32px}
label{display:block;text-align:left;font-size:12px;font-weight:500;color:var(--text-2);margin-bottom:6px}
input{width:100%;height:40px;padding:0 12px;font-size:13px;font-family:inherit;background:var(--bg);border:1px solid var(--border);border-radius:var(--radius);color:var(--text-1);outline:none;transition:border-color 0.15s;margin-bottom:12px}
input:focus{border-color:var(--blue)}
button{width:100%;height:40px;margin-top:8px;font-size:13px;font-weight:600;font-family:inherit;background:var(--blue);color:#fff;border:none;border-radius:var(--radius);cursor:pointer;transition:opacity 0.15s}
button:hover{opacity:0.9}
.error{color:var(--red);font-size:12px;margin-top:12px;display:none}
</style>
</head><body>
<div class="login-card">
<div class="logo">Attestant</div>
<div class="logo-sub">Platform Admin</div>
<form method="POST" action="{{ request.script_root }}/login">
<label for="email">Email</label>
<input type="email" id="email" name="email" placeholder="your@email.com" autofocus>
<label for="password">Password</label>
<input type="password" id="password" name="password" placeholder="Enter password">
<button type="submit">Sign In</button>
</form>
<div class="error" id="err">Invalid credentials. Please try again.</div>
</div>
<script>
if (location.search.includes('error=1')) document.getElementById('err').style.display='block';
</script>
</body></html>"""


@app.route("/login", methods=["GET", "POST"])
def login():
    """Login page for browser-based admin access."""
    if request.method == "GET":
        if _get_user_from_session():
            return redirect("/")
        return render_template_string(_LOGIN_HTML)

    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "")[:1024]

    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown")
    if "," in client_ip:
        client_ip = client_ip.split(",")[0].strip()

    if _is_rate_limited(client_ip):
        return redirect("/login?error=1")

    store = _get_store()
    if not store:
        _record_auth_failure(client_ip)
        return redirect("/login?error=1")

    user = store.get_user_by_email(ADMIN_TENANT, email)
    if not user or not user.get("active", True):
        _record_auth_failure(client_ip)
        return redirect("/login?error=1")

    if not user.get("password_hash"):
        _record_auth_failure(client_ip)
        return redirect("/login?error=1")

    if not _verify_password(password, user["password_hash"]):
        _record_auth_failure(client_ip)
        return redirect("/login?error=1")

    store.record_login(ADMIN_TENANT, email)

    resp = make_response(redirect("/"))
    session_value = _make_session_token(email)
    resp.set_cookie(
        "attestant_admin_session",
        session_value,
        httponly=True,
        samesite="Lax",
        secure=request.scheme == "https",
        max_age=86400,
    )
    return resp


@app.route("/logout")
def logout():
    """Clear the admin session cookie."""
    resp = make_response(redirect("/login"))
    resp.delete_cookie("attestant_admin_session")
    return resp


# ---------------------------------------------------------------------------
# Error Handlers
# ---------------------------------------------------------------------------

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Not found"}), 404


@app.errorhandler(500)
def server_error(e):
    logger.exception("Internal server error")
    return jsonify({"error": "Internal server error"}), 500


@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"error": "Method not allowed"}), 405


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
@require_admin_auth
def index():
    return render_template("admin_dashboard.html")


@app.route("/health")
def health():
    return jsonify({"status": "healthy", "role": "admin"})


def _read_api_egress_bytes() -> int:
    """Sum response bytes from the API service access log (field 10, 1-indexed)."""
    log_path = "/var/log/attestant/api-access.log"
    total = 0
    try:
        with open(log_path) as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 10:
                    try:
                        total += int(parts[9])
                    except (ValueError, IndexError):
                        pass
    except FileNotFoundError:
        pass
    return total


@app.route("/api/tenants")
@require_admin_auth
def api_tenants():
    store = _get_store()
    try:
        tenants = store.admin_tenant_summary()
        total_egress = _read_api_egress_bytes()
        n = len(tenants)
        if n > 0:
            total_calls = sum(t.get("api_calls") or 0 for t in tenants)
            for t in tenants:
                if total_calls > 0:
                    t["egress_bytes"] = int(total_egress * (t.get("api_calls") or 0) / total_calls)
                else:
                    t["egress_bytes"] = total_egress // n
        return jsonify(tenants)
    except Exception as exc:
        logger.exception("api_tenants failed")
        return jsonify({"error": "Failed to load tenant data", "code": "TENANTS_ERROR"}), 500


@app.route("/api/tenants", methods=["POST"])
@require_admin_auth
def create_tenant_api():
    body = request.get_json()
    if not body:
        return jsonify({"error": "JSON body required"}), 400
    tenant_id = body.get("tenant_id", "").strip()[:63]
    name = body.get("name", "").strip()[:255]
    tier = body.get("tier", "starter")

    if not tenant_id or not name:
        return jsonify({"error": "tenant_id and name are required"}), 400

    if tier not in ("starter", "professional", "growth", "enterprise"):
        return jsonify({"error": "Invalid tier"}), 400

    store = _get_store()
    store.create_tenant(tenant_id, name, tier=tier)
    store.upsert_subscription(tenant_id, plan=tier, status="active")

    return jsonify({"ok": True, "tenant_id": tenant_id})


@app.route("/api/system-health")
@require_admin_auth
def api_system_health():
    store = _get_store()
    try:
        return jsonify(store.admin_system_health())
    except Exception as exc:
        logger.exception("api_system_health failed")
        return jsonify({"error": "Failed to load system health", "code": "SYSTEM_HEALTH_ERROR"}), 500


@app.route("/api/platform-egress")
@require_admin_auth
def api_platform_egress():
    log_path = "/var/log/attestant/api-access.log"
    total_bytes = 0
    line_count = 0
    try:
        with open(log_path) as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 10:
                    try:
                        total_bytes += int(parts[9])
                        line_count += 1
                    except (ValueError, IndexError):
                        pass
    except FileNotFoundError:
        pass
    return jsonify({"total_egress_bytes": total_bytes, "total_requests": line_count})




@app.route("/api/pipelines")
@require_admin_auth
def api_pipelines():
    store = _get_store()
    limit = min(request.args.get("limit", 50, type=int), 200)
    try:
        return jsonify(store.get_pipeline_stats(limit=limit))
    except Exception as exc:
        logger.exception("api_pipelines failed")
        return jsonify({"error": "Failed to load pipelines", "code": "PIPELINES_ERROR"}), 500


@app.route("/api/metrics")
@require_admin_auth
def api_metrics():
    store = _get_store()
    try:
        return jsonify(store.get_latest_metrics())
    except Exception as exc:
        logger.exception("api_metrics failed")
        return jsonify({"error": "Failed to load metrics", "code": "METRICS_ERROR"}), 500


@app.route("/api/alerts")
@require_admin_auth
def api_alerts():
    store = _get_store()
    try:
        return jsonify(store.get_all_alerts_platform(limit=50))
    except Exception as exc:
        logger.exception("api_alerts failed")
        return jsonify({"error": "Failed to load alerts", "code": "ALERTS_ERROR"}), 500


@app.route("/api/alerts/<int:alert_id>/resolve", methods=["POST"])
@require_admin_auth
def api_resolve_alert(alert_id):
    store = _get_store()
    try:
        store.resolve_alert(alert_id)
    except Exception as exc:
        logger.error("resolve_alert failed: %s", exc)
        return jsonify({"ok": False, "error": "Failed to resolve alert"}), 500
    return jsonify({"ok": True})


_TENANT_ID_RE = re.compile(r'^[a-zA-Z0-9_-]{1,128}$')


@app.route("/api/tenants/<tenant_id>")
@require_admin_auth
def api_tenant_detail(tenant_id):
    if not _TENANT_ID_RE.match(tenant_id):
        return jsonify({"error": "Invalid tenant ID"}), 400
    store = _get_store()
    try:
        t = store.get_tenant(tenant_id)
    except Exception as exc:
        logger.error("get_tenant failed: %s", exc)
        return jsonify({"error": "Database error"}), 500
    if not t:
        return jsonify({"error": "Tenant not found"}), 404
    try:
        comp = store.get_latest_compliance(tenant_id)
        comp_history = store.get_compliance_history(tenant_id, limit=12)
        models = store.get_models(tenant_id)
        alerts = store.get_alerts(tenant_id, unresolved_only=True)
        pipelines = store.get_pipeline_stats(tenant_id=tenant_id, limit=20)
        fairness = store.get_all_fairness(tenant_id)
        certs = store.get_certifications(tenant_id)
    except Exception as exc:
        logger.error("tenant detail queries failed: %s", exc)
        comp = None
        comp_history = []
        models = []
        alerts = []
        pipelines = []
        fairness = []
        certs = []
    return jsonify({
        "tenant_id": t["tenant_id"],
        "name": t["name"],
        "tier": t["tier"],
        "created_at": t.get("created_at"),
        "compliance": comp,
        "compliance_history": comp_history,
        "models": models,
        "alerts": alerts,
        "pipelines": pipelines,
        "fairness": fairness,
        "certifications": certs,
    })


@app.route("/api/models/all")
@require_admin_auth
def api_models_all():
    store = _get_store()
    try:
        return jsonify(store.get_all_models_platform())
    except Exception as exc:
        logger.exception("api_models_all failed")
        return jsonify({"error": "Failed to load models", "code": "MODELS_ERROR"}), 500


@app.route("/api/fairness/all")
@require_admin_auth
def api_fairness_all():
    store = _get_store()
    try:
        return jsonify(store.get_all_fairness_platform())
    except Exception as exc:
        logger.exception("api_fairness_all failed")
        return jsonify({"error": "Failed to load fairness data", "code": "FAIRNESS_ERROR"}), 500


@app.route("/api/models/<model_id>/approve", methods=["POST"])
@require_admin_auth
@require_permission("manage_users")
def api_approve_model(model_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 503
    data = request.get_json(force=True, silent=True) or {}
    tenant_id = data.get("tenant_id")
    if not tenant_id:
        return jsonify({"error": "tenant_id is required"}), 400
    try:
        store.approve_model(tenant_id, model_id, approved_by=request.current_user["email"])
        return jsonify({"ok": True, "model_id": model_id, "status": "approved"})
    except Exception as exc:
        logger.exception("Failed to approve model %s", model_id)
        return jsonify({"error": "Failed to approve model", "code": "APPROVE_ERROR"}), 500


@app.route("/api/compliance/platform")
@require_admin_auth
def api_compliance_platform():
    store = _get_store()
    try:
        return jsonify(store.get_compliance_platform())
    except Exception as exc:
        logger.exception("api_compliance_platform failed")
        return jsonify({"error": "Failed to load compliance data", "code": "COMPLIANCE_ERROR"}), 500


@app.route("/api/pipelines/summary")
@require_admin_auth
def api_pipeline_summary():
    store = _get_store()
    try:
        return jsonify(store.get_pipeline_summary())
    except Exception as exc:
        logger.exception("api_pipeline_summary failed")
        return jsonify({"error": "Failed to load pipeline summary", "code": "PIPELINE_SUMMARY_ERROR"}), 500


@app.route("/api/dag/pipeline/<int:ps_id>")
@require_admin_auth
def api_dag_pipeline_summary(ps_id):
    """Return DAG column breakdown (feature vs. protected) for a pipeline."""
    store = _get_store()
    try:
        row = store._read_one(
            "SELECT provenance_pipeline_id FROM pipeline_stats WHERE id = %s",
            (ps_id,),
        )
        if not row:
            return jsonify({"error": "Pipeline not found"}), 404
        prov_id = row[0]
        if prov_id is None:
            return jsonify({
                "feature_columns": [], "protected_columns": [],
                "total_nodes": 0, "protected_isolated": True,
            })
        return jsonify(store.get_dag_column_summary(prov_id))
    except Exception as exc:
        logger.exception("api_dag_pipeline_summary failed for ps_id=%s", ps_id)
        return jsonify({"error": "Failed to load DAG summary", "code": "DAG_ERROR"}), 500


@app.route("/api/revenue")
@require_admin_auth
def api_revenue():
    store = _get_store()
    try:
        rows = store._read_dicts(
            "SELECT plan, COUNT(*) AS count FROM subscriptions WHERE status = 'active' GROUP BY plan",
            ()
        )
        plan_counts = {r["plan"]: r["count"] for r in rows}

        total_tenants_row = store._read_dict(
            "SELECT COUNT(*) AS total FROM tenants WHERE active = TRUE AND tenant_id != '_platform_admin'",
            ()
        )
        total_tenants = total_tenants_row["total"] if total_tenants_row else 0

        period = _billing.current_billing_period()
        meter_breakdown = {"model_validations": 0, "pipeline_runs": 0, "storage_gb": 0, "egress_gb": 0}

        tenant_rows = store._read_dicts(
            "SELECT tenant_id FROM tenants WHERE active = TRUE AND tenant_id != '_platform_admin'",
            ()
        )
        for t in tenant_rows:
            usage = store.get_usage_this_period(t["tenant_id"], period)
            for k in meter_breakdown:
                meter_breakdown[k] += int(usage.get(k, 0))

        active_clients = total_tenants
        base_revenue = active_clients * (_billing.BASE_MONTHLY_CENTS / 100)
        usage_revenue = (
            meter_breakdown["model_validations"] * 10.0 +
            meter_breakdown["pipeline_runs"] * 2.0 +
            meter_breakdown["storage_gb"] * 0.25 +
            meter_breakdown["egress_gb"] * 0.20
        )
        mrr_estimate = round(base_revenue + usage_revenue, 2)

        return jsonify({
            "plans": {
                "starter":      plan_counts.get("starter", 0),
                "professional": plan_counts.get("professional", 0),
                "growth":       plan_counts.get("growth", 0),
                "metered":      plan_counts.get("metered", 0),
                "enterprise":   plan_counts.get("enterprise", 0),
            },
            "mrr_estimate":    mrr_estimate,
            "base_revenue":    round(base_revenue, 2),
            "usage_revenue":   round(usage_revenue, 2),
            "total_tenants":   total_tenants,
            "meter_breakdown": meter_breakdown,
            "usage_rates": {
                "model_validations": 10.0,
                "pipeline_runs":     2.0,
                "storage_gb":        0.25,
                "egress_gb":         0.20,
            },
        })
    except Exception as exc:
        logger.exception("api_revenue failed")
        return jsonify({"error": "Failed to load revenue data", "code": "REVENUE_ERROR"}), 500


@app.route("/api/billing/report-storage", methods=["POST"])
@require_admin_auth
def api_billing_report_storage():
    store = _get_store()
    try:
        tenants = store.admin_tenant_summary()
        reported = []
        for t in tenants:
            tid = t.get("tenant_id")
            if not tid or tid == "_platform_admin":
                continue
            storage_bytes = int(t.get("storage_bytes", 0))
            gb = round(storage_bytes / 1_073_741_824, 3)
            gb_int = max(1, int(round(gb))) if gb > 0 else 0
            if gb_int > 0:
                _billing.record_usage(store, tid, "storage_gb", quantity=gb_int)
            reported.append({"tenant_id": tid, "storage_bytes": storage_bytes, "storage_gb": gb, "reported_gb": gb_int})
        return jsonify({"reported": reported})
    except Exception as exc:
        logger.exception("api_billing_report_storage failed")
        return jsonify({"error": "Failed to report storage", "code": "STORAGE_REPORT_ERROR"}), 500


@app.route("/api/billing/report-egress", methods=["POST"])
@require_admin_auth
def api_billing_report_egress():
    try:
        from attestant.dashboard.client_app import _egress_buffer
        store = _get_store()
        reported = []
        for tid, total_bytes in list(_egress_buffer.items()):
            if not tid or tid == "_platform_admin" or total_bytes <= 0:
                continue
            gb = round(total_bytes / 1_073_741_824, 3)
            gb_int = max(1, int(round(gb))) if gb > 0 else 0
            if gb_int > 0 and store is not None:
                _billing.record_usage(store, tid, "egress_gb", quantity=gb_int)
            _egress_buffer[tid] = 0
            reported.append({"tenant_id": tid, "egress_bytes": total_bytes, "egress_gb": gb, "reported_gb": gb_int})
        return jsonify({"reported": reported})
    except Exception as exc:
        logger.exception("api_billing_report_egress failed")
        return jsonify({"error": "Failed to report egress", "code": "EGRESS_REPORT_ERROR"}), 500


@app.route("/api/calendar")
@require_admin_auth
def api_calendar():
    try:
        from attestant.governance.regulatory_calendar import RegulatoryCalendar
        cal = RegulatoryCalendar()
        return jsonify(cal.generate_report())
    except Exception as exc:
        logger.exception("api_calendar failed")
        return jsonify({"error": "Failed to load calendar", "code": "CALENDAR_ERROR"}), 500


@app.route("/api/deployment/gate-status")
@require_admin_auth
def api_deployment_gate_status():
    """Get deployment gate status across all tenants/models."""
    store = _get_store()
    try:
        status = store.get_deployment_gate_status()
        return jsonify(status)
    except Exception as exc:
        logger.exception("Failed to get deployment gate status")
        return jsonify({"error": "Failed to load deployment gate status", "code": "GATE_STATUS_ERROR"}), 500


@app.route("/api/compliance/violations")
@require_admin_auth
def api_compliance_violations():
    """Get active compliance violations across all models."""
    store = _get_store()
    try:
        violations = store.get_compliance_violations()
        return jsonify(violations)
    except Exception as exc:
        logger.exception("Failed to get compliance violations")
        return jsonify({"error": "Failed to load compliance violations", "code": "VIOLATIONS_ERROR"}), 500


@app.route("/api/fairness/regression-trends")
@require_admin_auth
def api_fairness_regression_trends():
    """Get fairness regression trends across model versions."""
    store = _get_store()
    try:
        trends = store.get_fairness_regression_trends()
        return jsonify(trends)
    except Exception as exc:
        logger.exception("Failed to get fairness regression trends")
        return jsonify({"error": "Failed to load fairness trends", "code": "FAIRNESS_TRENDS_ERROR"}), 500


@app.route("/api/models/<model_name>/lifecycle")
@require_admin_auth
def api_model_lifecycle(model_name):
    """Get complete lifecycle view for a specific model."""
    store = _get_store()
    try:
        lifecycle = store.get_model_lifecycle(model_name)
        return jsonify(lifecycle)
    except Exception as exc:
        logger.exception("Failed to get model lifecycle for %s", model_name)
        return jsonify({"error": "Failed to load model lifecycle", "code": "LIFECYCLE_ERROR"}), 500


@app.route("/api/admin/cleanup", methods=["POST"])
@require_admin_auth
def admin_cleanup():
    store = _get_store()
    counts = store.cleanup_old_data()
    return jsonify({"deleted": counts})


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# User Management API
# ---------------------------------------------------------------------------

@app.route("/api/users")
@require_admin_auth
@require_permission("manage_users")
def api_users():
    store = _get_store()
    if store is None:
        return jsonify([])
    users = store.get_users(ADMIN_TENANT)
    for u in users:
        u.pop("password_hash", None)
    return jsonify(users)


@app.route("/api/users", methods=["POST"])
@require_admin_auth
@require_permission("manage_users")
def api_create_user():
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    data = request.json or {}
    email = (data.get("email") or "").strip().lower()[:254]
    role = data.get("role", "analyst")
    display_name = str(data.get("display_name", ""))[:255]
    password = str(data.get("password", ""))[:1024]

    if not email or not _validate_email(email):
        return jsonify({"error": "Invalid email address"}), 400

    if role not in VALID_ROLES:
        return jsonify({"error": f"Invalid role. Must be one of: {', '.join(VALID_ROLES)}"}), 400

    current = request.current_user
    if role == "admin" and current["role"] != "admin":
        return jsonify({"error": "Only admins can create admin users"}), 403

    pw_hash = _hash_password(password) if password else None

    user_id = store.create_user(
        tenant_id=ADMIN_TENANT,
        email=email,
        password_hash=pw_hash,
        display_name=display_name or email.split("@")[0].replace(".", " ").title(),
        role=role,
        invited_by=current["email"],
    )
    if user_id is None:
        return jsonify({"error": "User already exists"}), 409

    store.initialize_user_permissions(ADMIN_TENANT, user_id, role)

    return jsonify({"id": user_id, "email": email, "role": role}), 201


@app.route("/api/users/<int:user_id>/role", methods=["PUT"])
@require_admin_auth
@require_role("admin")
def api_update_user_role(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    data = request.json or {}
    role = data.get("role")
    if role not in VALID_ROLES:
        return jsonify({"error": f"Invalid role. Must be one of: {', '.join(VALID_ROLES)}"}), 400

    store.update_user_role(ADMIN_TENANT, user_id, role)
    store.delete_user_permissions(ADMIN_TENANT, user_id)
    store.initialize_user_permissions(ADMIN_TENANT, user_id, role)
    return jsonify({"ok": True})


@app.route("/api/users/<int:user_id>", methods=["DELETE"])
@require_admin_auth
@require_role("admin")
def api_deactivate_user(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    store.deactivate_user(ADMIN_TENANT, user_id)
    return jsonify({"ok": True})


@app.route("/api/users/<int:user_id>/reactivate", methods=["POST"])
@require_admin_auth
@require_role("admin")
def api_reactivate_user(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    store.reactivate_user(ADMIN_TENANT, user_id)
    return jsonify({"ok": True})


@app.route("/api/me")
@require_admin_auth
def api_me():
    user = {k: v for k, v in request.current_user.items() if k != "password_hash"}
    return jsonify(user)


# ---------------------------------------------------------------------------
# Permission Management API
# ---------------------------------------------------------------------------

@app.route("/api/me/permissions")
@require_admin_auth
def api_my_permissions():
    user = request.current_user
    perms = _get_effective_permissions(ADMIN_TENANT, user["email"], user["role"])
    return jsonify(perms)


@app.route("/api/users/<int:user_id>/permissions")
@require_admin_auth
@require_role("admin")
def api_get_user_permissions(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500
    perms = store.get_user_permissions(ADMIN_TENANT, user_id)
    if not perms:
        users = store.get_users(ADMIN_TENANT)
        target = next((u for u in users if u["id"] == user_id), None)
        if target:
            perms = ROLE_DEFAULTS.get(target["role"], ROLE_DEFAULTS["analyst"])
        else:
            return jsonify({"error": "User not found"}), 404
    return jsonify(perms)


@app.route("/api/users/<int:user_id>/permissions", methods=["PUT"])
@require_admin_auth
@require_role("admin")
def api_update_user_permissions(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    data = request.json or {}
    permissions = data.get("permissions", {})

    if not isinstance(permissions, dict):
        return jsonify({"error": "permissions must be a dict"}), 400

    for key in permissions:
        if key not in ALL_PERMISSIONS:
            return jsonify({"error": f"Unknown permission: {key}"}), 400

    users = store.get_users(ADMIN_TENANT)
    target = next((u for u in users if u["id"] == user_id), None)
    if not target:
        return jsonify({"error": "User not found"}), 404

    current_user = request.current_user
    current_user_row = store.get_user_by_email(ADMIN_TENANT, current_user["email"])

    if current_user_row and current_user_row["id"] == user_id:
        if "manage_permissions" in permissions and not permissions["manage_permissions"]:
            return jsonify({"error": "Cannot remove manage_permissions from yourself"}), 400

    if "manage_permissions" in permissions and not permissions["manage_permissions"]:
        admins_with_perm = 0
        for u in users:
            if u["id"] == user_id:
                continue
            if not u.get("active", True):
                continue
            if u["role"] == "admin":
                u_perms = store.get_user_permissions(ADMIN_TENANT, u["id"])
                has_perm = u_perms.get("manage_permissions", True) if u_perms else True
                if has_perm:
                    admins_with_perm += 1
        if admins_with_perm == 0:
            return jsonify({"error": "Cannot remove manage_permissions from the last admin with this permission"}), 400

    defaults = ROLE_DEFAULTS.get(target["role"], ROLE_DEFAULTS["analyst"])
    merged = dict(defaults)
    merged.update(permissions)

    store.set_user_permissions_bulk(
        ADMIN_TENANT, user_id, merged,
        granted_by=current_user["email"],
    )
    return jsonify({"ok": True, "permissions": merged})


@app.route("/api/users/<int:user_id>/permissions/reset", methods=["POST"])
@require_admin_auth
@require_role("admin")
def api_reset_user_permissions(user_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500

    users = store.get_users(ADMIN_TENANT)
    target = next((u for u in users if u["id"] == user_id), None)
    if not target:
        return jsonify({"error": "User not found"}), 404

    role = target["role"]
    defaults = ROLE_DEFAULTS.get(role, ROLE_DEFAULTS["analyst"])

    store.delete_user_permissions(ADMIN_TENANT, user_id)
    store.initialize_user_permissions(ADMIN_TENANT, user_id, role)

    return jsonify({"ok": True, "permissions": defaults})


@app.route("/api/keys", methods=["GET"])
@require_admin_auth
def api_list_keys():
    store = _get_store()
    if store is None:
        return jsonify([])
    keys = store.list_api_keys(ADMIN_TENANT)
    return jsonify(keys)


@app.route("/api/keys", methods=["POST"])
@require_admin_auth
@require_role("admin")
def api_create_key():
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500
    data = request.get_json(force=True, silent=True) or {}
    key_name = (data.get("name") or "").strip() or "API Key"
    created_by = request.current_user.get("email", "admin")
    key_value, key_id = store.create_api_key(ADMIN_TENANT, key_name, created_by=created_by)
    return jsonify({"ok": True, "key_id": key_id, "key_value": key_value, "key_name": key_name})


@app.route("/api/keys/<int:key_id>", methods=["DELETE"])
@require_admin_auth
@require_role("admin")
def api_revoke_key(key_id):
    store = _get_store()
    if store is None:
        return jsonify({"error": "Store not available"}), 500
    store.revoke_api_key(ADMIN_TENANT, key_id)
    return jsonify({"ok": True})


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Attestant Admin Dashboard")
    parser.add_argument("--port", default=5004, type=int)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    from attestant import __version__

    mode_label = "Aurora PostgreSQL"

    url = f"http://{args.host}:{args.port}"

    print()
    print("  Attestant Admin Dashboard v" + __version__)
    print("  " + "=" * 44)
    print(f"  Mode:       {mode_label}")
    print(f"  Auth:       user-based with permissions")
    print(f"  Dashboard:  {url}")
    print()

    app.run(debug=args.debug, port=args.port, host=args.host)


if __name__ == "__main__":
    main()
