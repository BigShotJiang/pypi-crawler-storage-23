"""Legacy utilities and alternative implementations."""
