"""
Examiner-Ready Package Generation.

One-click generation of regulatory examination bundles containing all
compliance documentation, model cards, fairness reports, and audit trails
needed for OCC, Fed, CFPB, and state regulatory examinations.

Modules:
    - package: ExaminerPackage assembler
    - model_card: Auto-generated model cards from DAG + FairLens results
"""

from .package import (
    ExaminerPackage,
    ExaminerSection,
)
from .model_card import (
    ModelCardGenerator,
    ModelCard,
)

__all__ = [
    "ExaminerPackage",
    "ExaminerSection",
    "ModelCardGenerator",
    "ModelCard",
]
