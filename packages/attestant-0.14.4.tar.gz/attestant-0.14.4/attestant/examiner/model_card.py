"""
Model Card Auto-Generator.

Generates standardised model cards per Mitchell et al. (2019) "Model Cards
for Model Reporting" from HYDRA-32 DAG metadata, FairLens fairness
analysis results, and compliance engine outputs.

Model cards are the industry standard for model documentation in regulated
industries and are required or recommended by:
    - SR 11-7 §3 (model documentation)
    - EU AI Act Article 13 / Annex IV (transparency documentation)
    - NIST AI RMF MAP 1.5 (documentation of intended use)
    - Colorado AI Act § 6-1-1703(2) (developer documentation duties)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


@dataclass
class ModelCard:
    """A standardised model card per Mitchell et al. (2019).

    Sections:
        1. Model Details
        2. Intended Use
        3. Factors (relevant demographic groups, instrumentation)
        4. Metrics (performance + fairness)
        5. Training Data
        6. Evaluation Data
        7. Ethical Considerations
        8. Caveats and Recommendations
        9. Quantitative Analyses (fairness metrics)
        10. Regulatory Compliance
    """
    # Section 1: Model Details
    model_name: str = ""
    model_version: str = ""
    model_type: str = ""
    model_hash: str = ""
    model_owner: str = ""
    model_developer: str = ""
    model_date: str = ""
    model_description: str = ""
    license: str = ""
    contact: str = ""

    # Section 2: Intended Use
    primary_intended_uses: List[str] = field(default_factory=list)
    primary_intended_users: List[str] = field(default_factory=list)
    out_of_scope_uses: List[str] = field(default_factory=list)

    # Section 3: Factors
    relevant_factors: List[str] = field(default_factory=list)
    evaluation_factors: List[str] = field(default_factory=list)

    # Section 4: Metrics
    performance_metrics: Dict[str, Any] = field(default_factory=dict)
    fairness_metrics: Dict[str, Any] = field(default_factory=dict)
    decision_thresholds: Dict[str, Any] = field(default_factory=dict)

    # Section 5-6: Data
    training_data_description: str = ""
    training_data_size: int = 0
    training_data_sources: List[str] = field(default_factory=list)
    evaluation_data_description: str = ""
    evaluation_data_size: int = 0

    # Section 7: Ethical Considerations
    ethical_considerations: List[str] = field(default_factory=list)

    # Section 8: Caveats
    caveats: List[str] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)

    # Section 9: Quantitative Analyses
    disparate_impact_results: Dict[str, Any] = field(default_factory=dict)
    proxy_detection_results: Dict[str, Any] = field(default_factory=dict)

    # Section 10: Regulatory Compliance
    compliance_status: Dict[str, Any] = field(default_factory=dict)
    risk_tier: str = ""
    regulatory_citations: List[str] = field(default_factory=list)

    # Metadata
    generated_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model_details": {
                "name": self.model_name,
                "version": self.model_version,
                "type": self.model_type,
                "hash": self.model_hash,
                "owner": self.model_owner,
                "developer": self.model_developer,
                "date": self.model_date,
                "description": self.model_description,
                "license": self.license,
                "contact": self.contact,
            },
            "intended_use": {
                "primary_intended_uses": self.primary_intended_uses,
                "primary_intended_users": self.primary_intended_users,
                "out_of_scope_uses": self.out_of_scope_uses,
            },
            "factors": {
                "relevant_factors": self.relevant_factors,
                "evaluation_factors": self.evaluation_factors,
            },
            "metrics": {
                "performance": self.performance_metrics,
                "fairness": self.fairness_metrics,
                "decision_thresholds": self.decision_thresholds,
            },
            "data": {
                "training": {
                    "description": self.training_data_description,
                    "size": self.training_data_size,
                    "sources": self.training_data_sources,
                },
                "evaluation": {
                    "description": self.evaluation_data_description,
                    "size": self.evaluation_data_size,
                },
            },
            "ethical_considerations": self.ethical_considerations,
            "caveats_and_recommendations": {
                "caveats": self.caveats,
                "recommendations": self.recommendations,
            },
            "quantitative_analyses": {
                "disparate_impact": self.disparate_impact_results,
                "proxy_detection": self.proxy_detection_results,
            },
            "regulatory_compliance": {
                "status": self.compliance_status,
                "risk_tier": self.risk_tier,
                "citations": self.regulatory_citations,
            },
            "generated_at": self.generated_at.isoformat(),
        }

    def to_markdown(self) -> str:
        """Render the model card as Markdown."""
        lines: List[str] = []
        lines.append(f"# Model Card: {self.model_name or 'Unnamed Model'}")
        lines.append(f"*Generated: {self.generated_at.strftime('%Y-%m-%d %H:%M UTC')}*")
        lines.append("")

        # Section 1
        lines.append("## 1. Model Details")
        if self.model_name:
            lines.append(f"- **Name:** {self.model_name}")
        if self.model_version:
            lines.append(f"- **Version:** {self.model_version}")
        if self.model_type:
            lines.append(f"- **Type:** {self.model_type}")
        if self.model_hash:
            lines.append(f"- **SHA-256 Hash:** `{self.model_hash}`")
        if self.model_owner:
            lines.append(f"- **Owner:** {self.model_owner}")
        if self.model_developer:
            lines.append(f"- **Developer:** {self.model_developer}")
        if self.model_date:
            lines.append(f"- **Date:** {self.model_date}")
        if self.model_description:
            lines.append(f"\n{self.model_description}")
        if self.risk_tier:
            lines.append(f"- **Risk Tier:** {self.risk_tier}")
        lines.append("")

        # Section 2
        lines.append("## 2. Intended Use")
        if self.primary_intended_uses:
            lines.append("**Primary Intended Uses:**")
            for u in self.primary_intended_uses:
                lines.append(f"- {u}")
        if self.primary_intended_users:
            lines.append("\n**Primary Intended Users:**")
            for u in self.primary_intended_users:
                lines.append(f"- {u}")
        if self.out_of_scope_uses:
            lines.append("\n**Out of Scope Uses:**")
            for u in self.out_of_scope_uses:
                lines.append(f"- {u}")
        lines.append("")

        # Section 3
        if self.relevant_factors or self.evaluation_factors:
            lines.append("## 3. Factors")
            if self.relevant_factors:
                lines.append("**Relevant Factors:**")
                for f in self.relevant_factors:
                    lines.append(f"- {f}")
            if self.evaluation_factors:
                lines.append("\n**Evaluation Factors:**")
                for f in self.evaluation_factors:
                    lines.append(f"- {f}")
            lines.append("")

        # Section 4
        lines.append("## 4. Metrics")
        if self.performance_metrics:
            lines.append("**Performance Metrics:**")
            lines.append("| Metric | Value |")
            lines.append("|--------|-------|")
            for k, v in self.performance_metrics.items():
                lines.append(f"| {k} | {v} |")
        if self.fairness_metrics:
            lines.append("\n**Fairness Metrics:**")
            lines.append("| Metric | Value |")
            lines.append("|--------|-------|")
            for k, v in self.fairness_metrics.items():
                lines.append(f"| {k} | {v} |")
        lines.append("")

        # Section 5-6
        if self.training_data_description or self.evaluation_data_description:
            lines.append("## 5. Training & Evaluation Data")
            if self.training_data_description:
                lines.append(f"**Training Data:** {self.training_data_description}")
                if self.training_data_size:
                    lines.append(f"- Size: {self.training_data_size:,} records")
                if self.training_data_sources:
                    lines.append("- Sources: " + ", ".join(self.training_data_sources))
            if self.evaluation_data_description:
                lines.append(f"\n**Evaluation Data:** {self.evaluation_data_description}")
                if self.evaluation_data_size:
                    lines.append(f"- Size: {self.evaluation_data_size:,} records")
            lines.append("")

        # Section 7
        if self.ethical_considerations:
            lines.append("## 6. Ethical Considerations")
            for c in self.ethical_considerations:
                lines.append(f"- {c}")
            lines.append("")

        # Section 8
        if self.caveats or self.recommendations:
            lines.append("## 7. Caveats and Recommendations")
            if self.caveats:
                lines.append("**Caveats:**")
                for c in self.caveats:
                    lines.append(f"- {c}")
            if self.recommendations:
                lines.append("\n**Recommendations:**")
                for r in self.recommendations:
                    lines.append(f"- {r}")
            lines.append("")

        # Section 9
        if self.disparate_impact_results or self.proxy_detection_results:
            lines.append("## 8. Quantitative Analyses")
            if self.disparate_impact_results:
                lines.append("**Disparate Impact Results:**")
                di_data = self.disparate_impact_results
                if isinstance(di_data, dict):
                    for attr, result in di_data.items():
                        lines.append(f"- **{attr}:** {result}")
                elif isinstance(di_data, list):
                    for r in di_data:
                        if isinstance(r, dict):
                            attr = r.get("protected_attribute", "unknown")
                            ratio = r.get("worst_ratio", "N/A")
                            lines.append(f"- **{attr}:** ratio={ratio}")
                        else:
                            lines.append(f"- {r}")
            if self.proxy_detection_results:
                lines.append("\n**Proxy Detection Results:**")
                for proxy, result in self.proxy_detection_results.items():
                    lines.append(f"- **{proxy}:** {result}")
            lines.append("")

        # Section 10
        if self.compliance_status or self.regulatory_citations:
            lines.append("## 9. Regulatory Compliance")
            if self.compliance_status:
                lines.append("| Regulation | Status |")
                lines.append("|-----------|--------|")
                for reg, status in self.compliance_status.items():
                    lines.append(f"| {reg} | {status} |")
            if self.regulatory_citations:
                lines.append("\n**Applicable Citations:**")
                for c in self.regulatory_citations:
                    lines.append(f"- {c}")
            lines.append("")

        return "\n".join(lines)


class ModelCardGenerator:
    """Auto-generates model cards from DAG metadata and analysis results.

    Usage::

        gen = ModelCardGenerator()
        card = gen.generate(
            model_metadata={
                "name": "Credit Scoring Model v3.2",
                "version": "3.2.0",
                "type": "XGBoost",
                "owner": "Model Risk Management",
                "risk_tier": "critical",
            },
            dag_metadata={
                "source_tables": ["applications", "bureau"],
                "feature_count": 42,
                "depth": 5,
            },
            fairness_results={
                "disparate_impact": {"race": 0.85, "sex": 0.92},
                "proxy_detected": ["zip_code"],
            },
            compliance_results={
                "ECOA / Reg B": "PASS",
                "SR 11-7": "PASS",
                "EU AI Act": "WARNING",
            },
        )
        print(card.to_markdown())
    """

    def generate(
        self,
        model_metadata: Optional[Dict[str, Any]] = None,
        dag_metadata: Optional[Dict[str, Any]] = None,
        fairness_results: Optional[Dict[str, Any]] = None,
        compliance_results: Optional[Dict[str, Any]] = None,
        training_metadata: Optional[Dict[str, Any]] = None,
    ) -> ModelCard:
        """Generate a ModelCard from available metadata.

        All parameters are optional; the generator populates whatever
        sections have data available.
        """
        model_meta = model_metadata or {}
        dag_meta = dag_metadata or {}
        fair = fairness_results or {}
        comp = compliance_results or {}
        train = training_metadata or {}

        card = ModelCard(
            model_name=model_meta.get("name", ""),
            model_version=model_meta.get("version", ""),
            model_type=model_meta.get("type", ""),
            model_hash=model_meta.get("hash", ""),
            model_owner=model_meta.get("owner", ""),
            model_developer=model_meta.get("developer", ""),
            model_date=model_meta.get("date", ""),
            model_description=model_meta.get("description", ""),
            risk_tier=model_meta.get("risk_tier", ""),
            contact=model_meta.get("contact", ""),
        )

        # Intended use
        if model_meta.get("intended_uses"):
            card.primary_intended_uses = model_meta["intended_uses"]
        if model_meta.get("intended_users"):
            card.primary_intended_users = model_meta["intended_users"]
        if model_meta.get("out_of_scope"):
            card.out_of_scope_uses = model_meta["out_of_scope"]

        # Factors from DAG
        if dag_meta.get("source_tables"):
            card.relevant_factors.append(
                f"Data sources: {', '.join(dag_meta['source_tables'])}"
            )
        if dag_meta.get("feature_count"):
            card.relevant_factors.append(
                f"Feature count: {dag_meta['feature_count']}"
            )
        if dag_meta.get("depth"):
            card.relevant_factors.append(
                f"Computation depth: {dag_meta['depth']}"
            )

        # Performance metrics
        if model_meta.get("metrics"):
            card.performance_metrics = model_meta["metrics"]

        # Fairness metrics
        if fair.get("disparate_impact"):
            card.disparate_impact_results = fair["disparate_impact"]
            di_data = fair["disparate_impact"]
            if isinstance(di_data, dict):
                card.fairness_metrics = {
                    f"DI Ratio ({attr})": f"{ratio:.4f}"
                    for attr, ratio in di_data.items()
                    if isinstance(ratio, (int, float))
                }
            elif isinstance(di_data, list):
                card.fairness_metrics = {
                    f"DI Ratio ({r.get('protected_attribute', 'unknown')})":
                    f"{r.get('worst_ratio', 0):.4f}"
                    for r in di_data
                    if isinstance(r, dict)
                }

        if fair.get("proxy_detected"):
            card.proxy_detection_results = {
                proxy: "Proxy correlation detected"
                for proxy in fair["proxy_detected"]
            }
            card.ethical_considerations.append(
                f"Proxy variables detected: {', '.join(fair['proxy_detected'])}. "
                f"These features may serve as proxies for protected attributes."
            )

        # Training data
        if train.get("description"):
            card.training_data_description = train["description"]
        if train.get("size"):
            card.training_data_size = train["size"]
        if train.get("sources"):
            card.training_data_sources = train["sources"]
        if train.get("eval_description"):
            card.evaluation_data_description = train["eval_description"]
        if train.get("eval_size"):
            card.evaluation_data_size = train["eval_size"]

        # Compliance
        if comp:
            card.compliance_status = comp

        # Auto-generate ethical considerations
        if model_meta.get("risk_tier") in ("critical", "high"):
            card.ethical_considerations.append(
                f"This model is classified as {model_meta['risk_tier']}-risk. "
                f"Enhanced monitoring, validation, and governance controls apply."
            )

        # Auto-generate caveats
        if model_meta.get("limitations"):
            card.caveats = model_meta["limitations"]
        if model_meta.get("assumptions"):
            card.caveats.append(
                f"Model assumptions: {model_meta['assumptions']}"
            )

        return card
