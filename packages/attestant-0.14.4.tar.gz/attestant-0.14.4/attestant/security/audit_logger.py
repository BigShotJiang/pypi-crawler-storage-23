"""
Security Audit Logging for Attestant

Comprehensive immutable audit log for compliance and forensics.
Retention: 7 years (banking compliance requirement).

Tracks all security-relevant events:
- Authentication (login, logout, MFA)
- Authorization (permission changes, access denials)
- Data access (view, create, update, delete)
- Administrative actions (user management, config changes)
"""

from datetime import datetime
from typing import Any, Optional, Dict, List
import psycopg2


class AuditLogger:
    """Immutable audit log for security events"""

    def __init__(self, db_conn):
        self.db_conn = db_conn

    def log_event(
        self,
        tenant_id: str,
        event_type: str,
        event_category: str,
        status: str,
        user_id: Optional[str] = None,
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        action: Optional[str] = None,
        details: Optional[Dict] = None,
        session_id: Optional[str] = None,
        api_key_id: Optional[str] = None,
        severity: str = "info",
        risk_score: int = 0,
    ):
        """
        Log a security event to immutable audit log.

        Args:
            tenant_id: Tenant ID
            event_type: login, logout, api_call, permission_change, etc.
            event_category: authentication, authorization, data_access, admin
            status: success, failure, blocked
            user_id: User ID (if applicable)
            ip_address: Client IP
            user_agent: Client user agent
            resource_type: model, pipeline, user, permission
            resource_id: Resource identifier
            action: view, create, update, delete
            details: Additional JSON details
            session_id: Session ID
            api_key_id: API key ID
            severity: info, warning, critical
            risk_score: 0-100 for anomaly detection
        """
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO security_audit_log (
                    tenant_id, user_id, event_type, event_category, severity,
                    ip_address, user_agent, resource_type, resource_id, action,
                    status, details, session_id, api_key_id, risk_score
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    tenant_id,
                    user_id,
                    event_type,
                    event_category,
                    severity,
                    ip_address,
                    user_agent,
                    resource_type,
                    resource_id,
                    action,
                    status,
                    details or {},
                    session_id,
                    api_key_id,
                    risk_score,
                ),
            )
            self.db_conn.commit()

    def log_login(
        self,
        tenant_id: str,
        user_id: str,
        ip_address: str,
        user_agent: str,
        success: bool,
        mfa_used: bool = False,
        failure_reason: Optional[str] = None,
    ):
        """Log login attempt"""
        self.log_event(
            tenant_id=tenant_id,
            event_type="login",
            event_category="authentication",
            status="success" if success else "failure",
            user_id=user_id,
            ip_address=ip_address,
            user_agent=user_agent,
            severity="info" if success else "warning",
            details={
                "mfa_used": mfa_used,
                "failure_reason": failure_reason if not success else None,
            },
            risk_score=0 if success else 10,
        )

    def log_permission_change(
        self,
        tenant_id: str,
        admin_user_id: str,
        target_user_id: str,
        permission: str,
        granted: bool,
        ip_address: str,
    ):
        """Log permission change"""
        self.log_event(
            tenant_id=tenant_id,
            event_type="permission_change",
            event_category="authorization",
            status="success",
            user_id=admin_user_id,
            ip_address=ip_address,
            resource_type="permission",
            resource_id=target_user_id,
            action="grant" if granted else "revoke",
            severity="warning",
            details={"permission": permission, "target_user": target_user_id},
            risk_score=5,
        )

    def log_data_access(
        self,
        tenant_id: str,
        user_id: str,
        resource_type: str,
        resource_id: str,
        action: str,
        ip_address: str,
        api_key_id: Optional[str] = None,
    ):
        """Log data access event"""
        self.log_event(
            tenant_id=tenant_id,
            event_type="data_access",
            event_category="data_access",
            status="success",
            user_id=user_id,
            ip_address=ip_address,
            resource_type=resource_type,
            resource_id=resource_id,
            action=action,
            api_key_id=api_key_id,
            severity="info",
        )

    def log_api_call(
        self,
        tenant_id: str,
        api_key_id: str,
        endpoint: str,
        ip_address: str,
        status_code: int,
        response_time_ms: int,
    ):
        """Log API call"""
        self.log_event(
            tenant_id=tenant_id,
            event_type="api_call",
            event_category="data_access",
            status="success" if status_code < 400 else "failure",
            ip_address=ip_address,
            api_key_id=api_key_id,
            severity="info" if status_code < 400 else "warning",
            details={
                "endpoint": endpoint,
                "status_code": status_code,
                "response_time_ms": response_time_ms,
            },
        )

    def get_audit_trail(
        self,
        tenant_id: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        user_id: Optional[str] = None,
        event_type: Optional[str] = None,
        limit: int = 100,
    ) -> list:
        """
        Retrieve audit trail for compliance reporting.

        Returns:
            List of audit log entries
        """
        query = """
            SELECT
                event_timestamp, tenant_id, user_id, event_type,
                event_category, severity, ip_address, resource_type,
                resource_id, action, status, details
            FROM security_audit_log
            WHERE tenant_id = %s
        """
        params: List[Any] = [tenant_id]

        if start_date:
            query += " AND event_timestamp >= %s"
            params.append(start_date)

        if end_date:
            query += " AND event_timestamp <= %s"
            params.append(end_date)

        if user_id:
            query += " AND user_id = %s"
            params.append(user_id)

        if event_type:
            query += " AND event_type = %s"
            params.append(event_type)

        query += " ORDER BY event_timestamp DESC LIMIT %s"
        params.append(limit)

        with self.db_conn.cursor() as cur:
            cur.execute(query, params)
            rows = cur.fetchall()

        return [
            {
                "timestamp": row[0],
                "tenant_id": row[1],
                "user_id": row[2],
                "event_type": row[3],
                "event_category": row[4],
                "severity": row[5],
                "ip_address": row[6],
                "resource_type": row[7],
                "resource_id": row[8],
                "action": row[9],
                "status": row[10],
                "details": row[11],
            }
            for row in rows
        ]


def log_security_event(
    tenant_id: str,
    event_type: str,
    event_category: str,
    status: str,
    db_conn,
    **kwargs,
):
    """
    Standalone audit logging function.

    Usage:
        log_security_event(
            tenant_id="test_company",
            event_type="login",
            event_category="authentication",
            status="success",
            db_conn=conn,
            user_id="user_123",
            ip_address="192.168.1.1"
        )
    """
    logger = AuditLogger(db_conn)
    logger.log_event(tenant_id, event_type, event_category, status, **kwargs)
