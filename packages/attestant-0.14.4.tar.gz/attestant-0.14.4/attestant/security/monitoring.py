"""
Security Monitoring and Anomaly Detection for Attestant

Real-time security event monitoring with:
- Anomaly detection (unusual login patterns, rate limit violations)
- Automatic alerting for high-severity events
- IP reputation tracking
- Automated incident response
"""

from datetime import datetime, timedelta
from typing import List, Dict, Optional
import psycopg2


class SecurityMonitor:
    """Real-time security monitoring and anomaly detection"""

    def __init__(self, db_conn):
        self.db_conn = db_conn

    def log_security_event(
        self,
        tenant_id: str,
        event_type: str,
        severity: str,
        description: str,
        source_ip: Optional[str] = None,
        user_id: Optional[str] = None,
        api_key_id: Optional[str] = None,
        metadata: Optional[Dict] = None,
    ) -> int:
        """
        Log a security event (suspicious activity).

        High/critical events automatically create alerts.

        Returns:
            Event ID
        """
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO security_events (
                    tenant_id, event_type, severity, source_ip,
                    user_id, api_key_id, description, metadata
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING id
                """,
                (
                    tenant_id,
                    event_type,
                    severity,
                    source_ip,
                    user_id,
                    api_key_id,
                    description,
                    metadata or {},
                ),
            )
            event_id = cur.fetchone()[0]
            self.db_conn.commit()

        return event_id

    def detect_failed_login_anomaly(
        self, tenant_id: str, user_id: str, ip_address: str
    ) -> bool:
        """
        Detect suspicious failed login patterns.

        Returns:
            True if anomaly detected
        """
        # Check failed logins in last hour
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                SELECT COUNT(*)
                FROM security_audit_log
                WHERE tenant_id = %s
                  AND user_id = %s
                  AND event_type = 'login'
                  AND status = 'failure'
                  AND event_timestamp > NOW() - INTERVAL '1 hour'
                """,
                (tenant_id, user_id),
            )
            failed_count = cur.fetchone()[0]

        if failed_count >= 5:
            # Log security event
            self.log_security_event(
                tenant_id=tenant_id,
                event_type="failed_login_anomaly",
                severity="high",
                description=f"User {user_id} has {failed_count} failed login attempts in the last hour",
                source_ip=ip_address,
                user_id=user_id,
                metadata={"failed_attempts": failed_count},
            )
            return True

        return False

    def detect_rate_limit_abuse(
        self, tenant_id: str, api_key_id: str, endpoint: str
    ) -> bool:
        """
        Detect rate limit abuse patterns.

        Returns:
            True if abuse detected
        """
        # Check rate limit violations in last hour
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                SELECT COUNT(*)
                FROM security_audit_log
                WHERE tenant_id = %s
                  AND api_key_id = %s
                  AND event_type = 'api_call'
                  AND status = 'failure'
                  AND details->>'status_code' = '429'
                  AND event_timestamp > NOW() - INTERVAL '1 hour'
                """,
                (tenant_id, api_key_id),
            )
            violation_count = cur.fetchone()[0]

        if violation_count >= 10:
            # Log security event
            self.log_security_event(
                tenant_id=tenant_id,
                event_type="rate_limit_abuse",
                severity="medium",
                description=f"API key {api_key_id[:10]}... has {violation_count} rate limit violations in the last hour",
                api_key_id=api_key_id,
                metadata={
                    "violation_count": violation_count,
                    "endpoint": endpoint,
                },
            )
            return True

        return False

    def detect_suspicious_ip(self, ip_address: str) -> bool:
        """
        Check IP reputation.

        Returns:
            True if IP is suspicious
        """
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                SELECT reputation_score, is_blocked, failed_logins
                FROM ip_reputation
                WHERE ip_address = %s
                """,
                (ip_address,),
            )
            row = cur.fetchone()

        if not row:
            return False

        reputation_score, is_blocked, failed_logins = row

        # Suspicious if score < 50 or >5 failed logins
        return reputation_score < 50 or failed_logins > 5 or is_blocked

    def update_ip_reputation(
        self, ip_address: str, event_type: str, country: Optional[str] = None
    ):
        """
        Update IP reputation based on activity.

        Args:
            ip_address: IP address
            event_type: 'request', 'failed_login', 'blocked'
            country: Optional country code
        """
        with self.db_conn.cursor() as cur:
            cur.execute(
                "SELECT update_ip_reputation(%s, %s, %s)",
                (ip_address, event_type, country),
            )
            self.db_conn.commit()

    def get_unresolved_events(
        self, tenant_id: str, severity: Optional[str] = None
    ) -> List[Dict]:
        """
        Get unresolved security events.

        Args:
            tenant_id: Tenant ID
            severity: Optional filter by severity (low, medium, high, critical)

        Returns:
            List of unresolved security events
        """
        query = """
            SELECT
                id, event_timestamp, event_type, severity,
                source_ip, user_id, api_key_id, description, metadata
            FROM security_events
            WHERE tenant_id = %s AND NOT resolved
        """
        params = [tenant_id]

        if severity:
            query += " AND severity = %s"
            params.append(severity)

        query += " ORDER BY event_timestamp DESC LIMIT 100"

        with self.db_conn.cursor() as cur:
            cur.execute(query, params)
            rows = cur.fetchall()

        return [
            {
                "id": row[0],
                "timestamp": row[1],
                "event_type": row[2],
                "severity": row[3],
                "source_ip": row[4],
                "user_id": row[5],
                "api_key_id": row[6],
                "description": row[7],
                "metadata": row[8],
            }
            for row in rows
        ]

    def resolve_event(self, event_id: int, resolved_by: str, notes: str):
        """Mark a security event as resolved"""
        with self.db_conn.cursor() as cur:
            cur.execute(
                """
                UPDATE security_events
                SET resolved = TRUE, resolved_at = NOW(),
                    resolved_by = %s, resolution_notes = %s
                WHERE id = %s
                """,
                (resolved_by, notes, event_id),
            )
            self.db_conn.commit()

    def get_security_summary(self, tenant_id: str, days: int = 7) -> Dict:
        """
        Get security summary for dashboard.

        Returns:
            {
                "total_events": int,
                "critical_events": int,
                "failed_logins": int,
                "rate_limit_violations": int,
                "blocked_ips": int,
                "active_sessions": int
            }
        """
        start_date = datetime.now() - timedelta(days=days)

        with self.db_conn.cursor() as cur:
            # Total security events
            cur.execute(
                """
                SELECT COUNT(*)
                FROM security_events
                WHERE tenant_id = %s AND event_timestamp > %s
                """,
                (tenant_id, start_date),
            )
            total_events = cur.fetchone()[0]

            # Critical events
            cur.execute(
                """
                SELECT COUNT(*)
                FROM security_events
                WHERE tenant_id = %s
                  AND event_timestamp > %s
                  AND severity = 'critical'
                """,
                (tenant_id, start_date),
            )
            critical_events = cur.fetchone()[0]

            # Failed logins
            cur.execute(
                """
                SELECT COUNT(*)
                FROM security_audit_log
                WHERE tenant_id = %s
                  AND event_timestamp > %s
                  AND event_type = 'login'
                  AND status = 'failure'
                """,
                (tenant_id, start_date),
            )
            failed_logins = cur.fetchone()[0]

            # Rate limit violations
            cur.execute(
                """
                SELECT COUNT(*)
                FROM security_audit_log
                WHERE tenant_id = %s
                  AND event_timestamp > %s
                  AND event_type = 'api_call'
                  AND details->>'status_code' = '429'
                """,
                (tenant_id, start_date),
            )
            rate_limit_violations = cur.fetchone()[0]

            # Blocked IPs
            cur.execute(
                """
                SELECT COUNT(*)
                FROM ip_reputation
                WHERE is_blocked = TRUE
                """
            )
            blocked_ips = cur.fetchone()[0]

            # Active sessions
            cur.execute(
                """
                SELECT COUNT(*)
                FROM active_sessions
                WHERE tenant_id = %s
                  AND NOT revoked
                  AND expires_at > NOW()
                """,
                (tenant_id,),
            )
            active_sessions = cur.fetchone()[0]

        return {
            "total_events": total_events,
            "critical_events": critical_events,
            "failed_logins": failed_logins,
            "rate_limit_violations": rate_limit_violations,
            "blocked_ips": blocked_ips,
            "active_sessions": active_sessions,
        }


def detect_anomalies(tenant_id: str, user_id: str, ip_address: str, db_conn) -> List[str]:
    """
    Standalone anomaly detection function.

    Returns:
        List of detected anomalies (descriptions)
    """
    monitor = SecurityMonitor(db_conn)
    anomalies = []

    if monitor.detect_failed_login_anomaly(tenant_id, user_id, ip_address):
        anomalies.append("Multiple failed login attempts detected")

    if monitor.detect_suspicious_ip(ip_address):
        anomalies.append("Request from suspicious IP address")

    return anomalies
