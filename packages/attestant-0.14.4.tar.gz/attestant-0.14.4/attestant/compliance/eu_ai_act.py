"""
EU AI Act Compliance Engine for HYDRA-32.

Implements checks against the EU Artificial Intelligence Act (Regulation
(EU) 2024/1689), with particular focus on Article 12 (Record-keeping /
automatic logging) and the obligations that apply to high-risk AI systems
under Title III, Chapter 2.

Key articles checked:
    Article  9  - Risk management system
    Article 10  - Data and data governance
    Article 11  - Technical documentation
    Article 12  - Record-keeping (automatic logging)
    Article 13  - Transparency and provision of information to deployers
    Article 14  - Human oversight
    Article 15  - Accuracy, robustness and cybersecurity
    Article 17  - Quality management system

The engine analyses a HYDRA-32 ComputationDAG and optional metadata to
determine whether the provenance record satisfies the logging and
traceability requirements imposed by the Act.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Set

from ..utilities.hydra32_dag import ComputationDAG, DAGNode, NodeType
from ..utilities.hydra32 import ProvenanceTracker as _PT
from .base import (
    BaseComplianceEngine,
    ComplianceFinding,
    ComplianceResult,
    Severity,
)


# ---------------------------------------------------------------------------
# Risk classification
# ---------------------------------------------------------------------------

_HIGH_RISK_DOMAINS: Set[str] = {
    "credit_scoring",
    "loan_approval",
    "insurance_pricing",
    "recruitment",
    "hiring",
    "education_assessment",
    "law_enforcement",
    "border_control",
    "critical_infrastructure",
    "biometric_identification",
    "employment",
    "healthcare_triage",
    "social_scoring",
    "judicial",
}

_PROHIBITED_PRACTICES: Set[str] = {
    "social_scoring",
    "subliminal_manipulation",
    "exploitation_of_vulnerabilities",
    "real_time_biometric_identification",
}


def _classify_risk(metadata: Dict[str, Any]) -> str:
    """Return 'prohibited', 'high', 'limited', or 'minimal'."""
    domain = (metadata.get("domain") or metadata.get("use_case") or "").lower().strip()
    model_type = (metadata.get("model_type") or "").lower().strip()

    if domain in _PROHIBITED_PRACTICES:
        return "prohibited"

    if domain in _HIGH_RISK_DOMAINS:
        return "high"

    if model_type in ("generative", "foundation_model", "general_purpose"):
        return "limited"

    return "minimal"


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class EUAIActEngine(BaseComplianceEngine):
    """Compliance engine for the EU Artificial Intelligence Act.

    Runs the following families of checks against a ``ComputationDAG``:

    1. **Tamper-evident logging** (Article 12) -- verifies that the DAG
       contains provenance fingerprints, edges, and sufficient depth to
       reconstruct the computation.
    2. **Human oversight documentation** (Article 14) -- verifies that
       metadata declares a human-in-the-loop or human-on-the-loop
       mechanism.
    3. **Data governance** (Article 10) -- verifies that data sources are
       documented and that protected data is flagged.
    4. **Transparency** (Article 13) -- verifies that model type,
       intended purpose, and known limitations are documented.
    5. **Risk classification** (Article 6, Annex III) -- classifies the
       system and applies the corresponding requirements.
    """

    _CHECK_MAP = {
        "eu_ai_act.risk_classification": "_check_risk_classification",
        "eu_ai_act.risk_management": "_check_risk_management",
        "eu_ai_act.logging": "_check_logging",
        "eu_ai_act.traceability": "_check_traceability",
        "eu_ai_act.human_oversight": "_check_human_oversight",
        "eu_ai_act.data_governance": "_check_data_governance",
        "eu_ai_act.technical_documentation": "_check_technical_documentation",
        "eu_ai_act.transparency": "_check_transparency",
        "eu_ai_act.accuracy_robustness": "_check_accuracy_robustness",
        "eu_ai_act.cybersecurity": "_check_cybersecurity",
        "eu_ai_act.fundamental_rights_impact": "_check_fundamental_rights_impact",
        "eu_ai_act.data_bias_representativeness": "_check_data_bias_representativeness",
        "eu_ai_act.quality_management": "_check_quality_management",
    }

    @property
    def regulation_name(self) -> str:
        return "EU AI Act"

    def _resolve_risk_level(self, meta: Dict[str, Any]) -> str:
        """Resolve risk level from metadata using the module-level _classify_risk function."""
        return _classify_risk(meta)

    def check(
        self,
        dag: ComputationDAG,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ComplianceResult:
        meta = metadata or {}
        findings: List[ComplianceFinding] = []
        citations: List[str] = []

        for _f in [
            self._check_risk_classification(dag, meta),
            self._check_risk_management(dag, meta),
            self._check_logging(dag, meta),
            self._check_traceability(dag, meta),
            self._check_human_oversight(dag, meta),
            self._check_data_governance(dag, meta),
            self._check_technical_documentation(dag, meta),
            self._check_transparency(dag, meta),
            self._check_accuracy_robustness(dag, meta),
            self._check_cybersecurity(dag, meta),
            self._check_fundamental_rights_impact(dag, meta),
            self._check_data_bias_representativeness(dag, meta),
            self._check_quality_management(dag, meta),
        ]:
            if _f is not None:
                findings.extend(_f)

        for f in findings:
            if f.regulation_citation and f.regulation_citation not in citations:
                citations.append(f.regulation_citation)

        passed = all(f.severity != Severity.CRITICAL for f in findings)

        from .base import ComplianceReport
        remediation_recs = ComplianceReport._dedup_flat(
            [[f.remediation] for f in findings if f.remediation]
        )

        risk_level = _classify_risk(meta)
        result_metadata: Dict[str, Any] = {"risk_level": risk_level}
        taint_risks = dag.column_taint_risks()
        if taint_risks:
            result_metadata["taint_risk_summary"] = {
                "tainted_columns": len(taint_risks),
                "max_risk": round(max(taint_risks.values()), 4),
                "columns": {
                    col: round(risk, 4)
                    for col, risk in sorted(
                        taint_risks.items(), key=lambda x: x[1], reverse=True,
                    )[:10]
                },
            }

        return ComplianceResult(
            passed=passed,
            regulation_name=self.regulation_name,
            findings=findings,
            citations=citations,
            remediation_recommendations=remediation_recs,
            metadata=result_metadata,
        )

    # -- individual checks ---------------------------------------------------

    def _check_risk_classification(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        risk_level = self._resolve_risk_level(meta)
        findings: List[ComplianceFinding] = []

        if risk_level == "prohibited":
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "This AI system falls under a prohibited practice as "
                    "defined in Article 5 of the EU AI Act. Deployment within "
                    "the EU is not permitted."
                ),
                regulation_citation="Article 5",
                remediation=(
                    "Cease deployment immediately. Re-evaluate the system's "
                    "purpose to ensure it does not constitute a prohibited AI "
                    "practice under Article 5."
                ),
            ))

        elif risk_level == "high":
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    f"System classified as HIGH-RISK (domain: "
                    f"{meta.get('domain', 'unknown')}). All Title III, "
                    f"Chapter 2 obligations apply."
                ),
                regulation_citation="Article 6, Annex III",
            ))

            if not meta.get("conformity_assessment"):
                findings.append(ComplianceFinding(
                    severity=Severity.WARNING,
                    description=(
                        "No conformity assessment record found. High-risk AI "
                        "systems must undergo a conformity assessment before "
                        "being placed on the market."
                    ),
                    regulation_citation="Article 43",
                    remediation=(
                        "Conduct a conformity assessment per Article 43 and "
                        "retain the documentation for at least 10 years."
                    ),
                ))

            if not meta.get("eu_database_registration"):
                findings.append(ComplianceFinding(
                    severity=Severity.WARNING,
                    description=(
                        "No EU database registration ID found. High-risk AI "
                        "systems must be registered in the EU database before "
                        "being placed on the market or put into service."
                    ),
                    regulation_citation="Article 49(1)",
                    remediation=(
                        "Register the AI system in the EU database established "
                        "under Article 71 before deployment."
                    ),
                ))

        elif risk_level == "limited":
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "System classified as LIMITED-RISK. Transparency "
                    "obligations under Article 52 apply."
                ),
                regulation_citation="Article 52",
            ))

        else:
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description="System classified as MINIMAL-RISK. No mandatory requirements beyond voluntary codes of conduct.",
                regulation_citation="Article 69",
            ))

        return findings

    def _check_logging(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """Article 12 -- Record-keeping / automatic logging."""
        findings: List[ComplianceFinding] = []

        if not dag.nodes:
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "The computation DAG contains no nodes. Article 12(1) "
                    "requires that high-risk AI systems are designed and "
                    "developed with capabilities enabling the automatic "
                    "recording of events (logs) while the system is operating."
                ),
                regulation_citation="Article 12(1)",
                remediation=(
                    "Integrate HYDRA-32 DAG tracking into the AI pipeline so "
                    "that every computation step is automatically logged."
                ),
            ))
            return findings

        nodes_without_provenance = [
            n.node_id for n in dag.nodes.values()
            if n.provenance == 0 and not n.is_source
        ]
        if nodes_without_provenance:
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    f"{len(nodes_without_provenance)} computation node(s) lack "
                    f"provenance fingerprints. Article 12(1) requires automatic "
                    f"recording of events to ensure traceability."
                ),
                regulation_citation="Article 12(1)",
                affected_nodes=nodes_without_provenance,
                remediation=(
                    "Ensure all computation steps produce provenance "
                    "fingerprints through HYDRA-32 tracked operations."
                ),
            ))

        if not dag.edges:
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "The DAG contains no edges. Without causal links between "
                    "computation steps the log does not enable traceability of "
                    "the AI system's operation as required by Article 12(2)."
                ),
                regulation_citation="Article 12(2)",
                remediation=(
                    "Use HYDRA-32 DAG-tracked operations (binary, unary, "
                    "merge) so that edges are automatically recorded."
                ),
            ))

        if len(dag.source_nodes) == 0:
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No source data nodes found in the DAG. Article 12(2)(a) "
                    "requires logging of the period of each use, the reference "
                    "database against which input data has been checked, and "
                    "the input data for which the search has led to a match."
                ),
                regulation_citation="Article 12(2)(a)",
                remediation=(
                    "Register all input data sources via "
                    "wrap_dataframe_dag() so that source nodes appear in the "
                    "DAG."
                ),
            ))

        expected_event_types = {"start_time", "end_time", "model_version"}
        provided_events = set(meta.keys())
        missing_events = expected_event_types - provided_events
        if missing_events:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    f"Metadata is missing event logging fields: "
                    f"{', '.join(sorted(missing_events))}. Article 12(2) "
                    f"requires logs to include the period of each use and the "
                    f"reference database."
                ),
                regulation_citation="Article 12(2)",
                remediation=(
                    "Include 'start_time', 'end_time', and 'model_version' in "
                    "the metadata passed to the compliance engine."
                ),
            ))

        log_retention = meta.get("log_retention_months")
        if log_retention is not None and log_retention < 6:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    f"Log retention period is {log_retention} month(s). "
                    f"Article 12(3) requires logs to be kept for a period "
                    f"appropriate to the intended purpose, and at least six "
                    f"months unless otherwise provided by applicable law."
                ),
                regulation_citation="Article 12(3)",
                remediation=(
                    "Configure log retention to at least 6 months."
                ),
            ))

        return findings

    def _check_traceability(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """Article 12(2) -- Traceability requirements."""
        findings: List[ComplianceFinding] = []

        if dag.depth < 1 and len(dag.nodes) > 1:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "DAG depth is less than 1 despite having multiple nodes. "
                    "This may indicate that intermediate computation steps are "
                    "not being captured, which undermines the traceability "
                    "requirement of Article 12(2)."
                ),
                regulation_citation="Article 12(2)",
                remediation=(
                    "Verify that all intermediate transformations are executed "
                    "through HYDRA-32 tracked operations to build a complete "
                    "lineage chain."
                ),
            ))

        duplicate_provenance_nodes: List[int] = []
        seen_provs: Dict[int, int] = {}
        for node in dag.nodes.values():
            if not node.is_source:
                p = node.provenance
                if p in seen_provs:
                    duplicate_provenance_nodes.append(node.node_id)
                else:
                    seen_provs[p] = node.node_id

        if duplicate_provenance_nodes:
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    f"{len(duplicate_provenance_nodes)} computation node(s) "
                    f"share a provenance fingerprint with another node. While "
                    f"not necessarily an error, duplicate fingerprints can "
                    f"impair the uniqueness requirement of event logs under "
                    f"Article 12(1)."
                ),
                regulation_citation="Article 12(1)",
                affected_nodes=duplicate_provenance_nodes,
                remediation=(
                    "Review the computation pipeline for redundant or "
                    "identical steps that collapse provenance."
                ),
            ))

        tamper_evidence = meta.get("tamper_evidence_enabled", True)
        if not tamper_evidence:
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "Tamper-evidence has been explicitly disabled. Article "
                    "12(1) requires that logging capabilities are designed to "
                    "ensure a level of traceability appropriate to the "
                    "intended purpose. Tamper-proof provenance is essential "
                    "for this."
                ),
                regulation_citation="Article 12(1)",
                remediation=(
                    "Re-enable tamper-evident provenance by using the HYDRA-32 "
                    "DAGTracker with default settings."
                ),
            ))

        return findings

    def _check_human_oversight(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """Article 14 -- Human oversight."""
        findings: List[ComplianceFinding] = []

        oversight_mode = meta.get("human_oversight_mode")

        if not oversight_mode:
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No human oversight mechanism documented. Article 14(1) "
                    "requires that high-risk AI systems be designed and "
                    "developed so that they can be effectively overseen by "
                    "natural persons during the period of use."
                ),
                regulation_citation="Article 14(1)",
                remediation=(
                    "Document the human oversight mechanism in metadata "
                    "(key: 'human_oversight_mode'). Accepted values: "
                    "'human_in_the_loop', 'human_on_the_loop', "
                    "'human_in_command'."
                ),
            ))
        else:
            valid_modes = {
                "human_in_the_loop",
                "human_on_the_loop",
                "human_in_command",
            }
            if oversight_mode not in valid_modes:
                findings.append(ComplianceFinding(
                    severity=Severity.WARNING,
                    description=(
                        f"Human oversight mode '{oversight_mode}' is not a "
                        f"recognised mode. Article 14(3) specifies oversight "
                        f"measures that enable the individuals to whom human "
                        f"oversight is assigned to properly understand the "
                        f"relevant capacities and limitations of the system."
                    ),
                    regulation_citation="Article 14(3)",
                    remediation=(
                        "Set 'human_oversight_mode' to one of: "
                        "'human_in_the_loop', 'human_on_the_loop', "
                        "'human_in_command'."
                    ),
                ))

        if not meta.get("override_capability"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No override capability documented. Article 14(4)(d) "
                    "requires that the human overseers are able to decide, in "
                    "any particular situation, not to use the system or to "
                    "disregard, override, or reverse the output."
                ),
                regulation_citation="Article 14(4)(d)",
                remediation=(
                    "Document the override / stop mechanism (key: "
                    "'override_capability') in metadata."
                ),
            ))

        return findings

    def _check_data_governance(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> List[ComplianceFinding]:
        """Article 10 -- Data and data governance."""
        findings: List[ComplianceFinding] = []

        sources = dag.source_nodes
        if sources:
            sources_without_table = [
                n.node_id for n in sources if not n.table
            ]
            if sources_without_table:
                findings.append(ComplianceFinding(
                    severity=Severity.WARNING,
                    description=(
                        f"{len(sources_without_table)} source node(s) have no "
                        f"table name. Article 10(2)(f) requires that data sets "
                        f"are relevant, representative, and to the best extent "
                        f"possible, free of errors and complete in view of the "
                        f"intended purpose. Source identification is a "
                        f"prerequisite."
                    ),
                    regulation_citation="Article 10(2)(f)",
                    affected_nodes=sources_without_table,
                    remediation=(
                        "Assign meaningful table names when wrapping data "
                        "sources with wrap_dataframe_dag()."
                    ),
                ))

        if dag.has_protected:
            protected = dag.protected_sources
            protected_tables = set(n.table for n in protected if n.table)
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    f"Protected data source(s) detected in computation: "
                    f"{', '.join(sorted(protected_tables))}. Article 10(5) "
                    f"permits processing of special categories of personal "
                    f"data only to the extent that it is strictly necessary "
                    f"for bias monitoring and correction."
                ),
                regulation_citation="Article 10(5)",
                affected_nodes=[n.node_id for n in protected],
                remediation=(
                    "Verify that use of protected data is strictly necessary "
                    "for bias detection. Document the justification."
                ),
            ))

        if not meta.get("training_data_description"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No training data description found in metadata. Article "
                    "10(2) requires appropriate data governance measures for "
                    "training, validation, and testing datasets."
                ),
                regulation_citation="Article 10(2)",
                remediation=(
                    "Add 'training_data_description' to metadata with details "
                    "about data collection, labelling, cleaning, and "
                    "representativeness."
                ),
            ))

        return findings

    def _check_transparency(
        self, dag: ComputationDAG, meta: Dict[str, Any],
    ) -> List[ComplianceFinding]:
        """Article 13 -- Transparency.

        When a DAG with HYDRA-32 taint data is available, also reports
        taint propagation paths as part of the explainability requirement.
        """
        findings: List[ComplianceFinding] = []

        if not meta.get("intended_purpose"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No intended purpose documented. Article 13(3)(b)(i) "
                    "requires that instructions for use include the intended "
                    "purpose of the AI system."
                ),
                regulation_citation="Article 13(3)(b)(i)",
                remediation=(
                    "Add 'intended_purpose' to metadata describing the "
                    "system's designed use."
                ),
            ))

        if not meta.get("known_limitations"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No known limitations documented. Article 13(3)(b)(ii) "
                    "requires disclosure of the level of accuracy, including "
                    "its metrics, robustness, and cybersecurity against which "
                    "the system has been tested and validated, and any known "
                    "and foreseeable circumstances that may have an impact on "
                    "that expected level."
                ),
                regulation_citation="Article 13(3)(b)(ii)",
                remediation=(
                    "Add 'known_limitations' to metadata describing "
                    "foreseeable failure modes and accuracy boundaries."
                ),
            ))

        if not meta.get("model_type"):
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "No model type specified. Providing model type helps "
                    "determine the applicable transparency obligations."
                ),
                regulation_citation="Article 13(1)",
                remediation=(
                    "Add 'model_type' to metadata (e.g. 'logistic_regression', "
                    "'gradient_boosting', 'neural_network')."
                ),
            ))

        # HYDRA-32 taint transparency: report propagation paths
        if dag is not None:
            taint_risks = dag.column_taint_risks()
            if taint_risks:
                max_risk = max(taint_risks.values())
                tainted_cols = sorted(taint_risks.keys())
                findings.append(ComplianceFinding(
                    severity=Severity.INFO,
                    description=(
                        f"HYDRA-32 taint analysis: {len(tainted_cols)} "
                        f"column(s) carry taint from protected data sources "
                        f"(max risk: {max_risk:.2f}). Tainted columns: "
                        f"{', '.join(tainted_cols[:10])}. Article 13(1) "
                        f"requires transparency about how the AI system "
                        f"processes personal data, including protected "
                        f"attributes."
                    ),
                    regulation_citation="Article 13(1)",
                    remediation=(
                        "Include taint propagation analysis in the system's "
                        "transparency documentation to demonstrate awareness "
                        "of protected data influence paths."
                    ),
                ))

        return findings

    def _check_accuracy_robustness(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> Optional[List[ComplianceFinding]]:
        """Article 15 -- Accuracy, robustness and cybersecurity."""
        risk_level = self._resolve_risk_level(meta)
        if risk_level != "high":
            return None  # N/A: Article 15 accuracy/robustness requirements only apply to high-risk AI systems

        findings: List[ComplianceFinding] = []

        if not meta.get("accuracy_metrics"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No accuracy metrics provided. Article 15(1) requires "
                    "that high-risk AI systems are designed and developed so "
                    "that they achieve an appropriate level of accuracy."
                ),
                regulation_citation="Article 15(1)",
                remediation=(
                    "Add 'accuracy_metrics' to metadata (e.g. "
                    "{'auc': 0.85, 'precision': 0.82})."
                ),
            ))

        if not meta.get("robustness_testing"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No robustness testing documented. Article 15(4) requires "
                    "that high-risk AI systems be resilient to errors, faults, "
                    "or inconsistencies."
                ),
                regulation_citation="Article 15(4)",
                remediation=(
                    "Document robustness testing results in "
                    "'robustness_testing' metadata key."
                ),
            ))

        return findings

    def _check_quality_management(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> Optional[List[ComplianceFinding]]:
        """Article 17 -- Quality management system."""
        risk_level = self._resolve_risk_level(meta)
        if risk_level != "high":
            return None  # N/A: Article 17 quality management requirements only apply to high-risk AI systems

        findings: List[ComplianceFinding] = []

        if not meta.get("quality_management_system"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No quality management system documented. Article 17(1) "
                    "requires providers of high-risk AI systems to put a "
                    "quality management system in place that ensures "
                    "compliance with this Regulation."
                ),
                regulation_citation="Article 17(1)",
                remediation=(
                    "Establish and document a quality management system. "
                    "Reference it in metadata under 'quality_management_system'."
                ),
            ))

        if not meta.get("version_control"):
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "No version control information documented. Article "
                    "17(1)(d) requires strategies and procedures for version "
                    "management."
                ),
                regulation_citation="Article 17(1)(d)",
                remediation=(
                    "Add 'version_control' to metadata with the system version "
                    "and change-management process reference."
                ),
            ))

        return findings

    def _check_risk_management(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> Optional[List[ComplianceFinding]]:
        """Article 9: Risk management system.

        High-risk AI systems must implement a documented risk management
        system that identifies, analyses, evaluates, and mitigates risks.
        Compliance deadline: August 2, 2026.
        """
        risk_level = self._resolve_risk_level(meta)
        findings: List[ComplianceFinding] = []

        if risk_level not in ("high",):
            return None

        if not meta.get("risk_management_plan"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No risk management plan documented. Article 9(1) "
                    "requires providers of high-risk AI systems to "
                    "establish, implement, document, and maintain a risk "
                    "management system. Compliance deadline: August 2, 2026."
                ),
                regulation_citation="Article 9(1)",
                remediation=(
                    "Create a formal risk management plan covering risk "
                    "identification, analysis, evaluation, and mitigation. "
                    "Record under 'risk_management_plan' in metadata."
                ),
            ))

        if not meta.get("risk_assessment_completed"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No risk assessment documented. Article 9(2)(a) "
                    "requires identification and analysis of known and "
                    "reasonably foreseeable risks before deployment."
                ),
                regulation_citation="Article 9(2)(a)",
                remediation=(
                    "Perform and document a risk assessment covering "
                    "foreseeable risks of the AI system. Set "
                    "'risk_assessment_completed' to True."
                ),
            ))

        if not meta.get("risk_mitigation_measures"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No risk mitigation measures documented. Article 9(4) "
                    "requires appropriate risk mitigation measures to be "
                    "implemented and documented."
                ),
                regulation_citation="Article 9(4)",
                remediation=(
                    "Document risk mitigation measures under "
                    "'risk_mitigation_measures' in metadata."
                ),
            ))

        if not meta.get("post_market_monitoring"):
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "No post-market monitoring plan documented. Article "
                    "9(9) requires providers to ensure the system is "
                    "monitored throughout its lifecycle."
                ),
                regulation_citation="Article 9(9)",
                remediation=(
                    "Establish a post-market monitoring plan and record "
                    "under 'post_market_monitoring' in metadata."
                ),
            ))

        return findings

    def _check_technical_documentation(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> Optional[List[ComplianceFinding]]:
        """Article 11: Technical documentation.

        High-risk AI systems must maintain technical documentation
        demonstrating compliance and providing authorities with
        information to assess compliance.
        """
        risk_level = self._resolve_risk_level(meta)
        findings: List[ComplianceFinding] = []

        if risk_level not in ("high",):
            return None

        if not meta.get("technical_documentation"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No technical documentation referenced. Article 11(1) "
                    "requires high-risk AI providers to draw up and "
                    "maintain technical documentation before the system "
                    "is placed on the market."
                ),
                regulation_citation="Article 11(1)",
                remediation=(
                    "Create comprehensive technical documentation per "
                    "Annex IV requirements and reference it under "
                    "'technical_documentation' in metadata."
                ),
            ))

        if not meta.get("algorithm_description"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No algorithm description documented. Annex IV(2)(b) "
                    "requires a general description of the AI system's "
                    "logic, including the main algorithmic choices."
                ),
                regulation_citation="Annex IV(2)(b)",
                remediation=(
                    "Document the model type, key algorithmic choices, "
                    "and decision logic under 'algorithm_description'."
                ),
            ))

        if not meta.get("training_data_description"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No training data description documented. Annex IV(2)(d) "
                    "requires information about the training, validation, "
                    "and testing data used."
                ),
                regulation_citation="Annex IV(2)(d)",
                remediation=(
                    "Document the training data source, time period, size, "
                    "and known limitations under 'training_data_description'."
                ),
            ))

        if not meta.get("performance_benchmarks"):
            findings.append(ComplianceFinding(
                severity=Severity.INFO,
                description=(
                    "No performance benchmarks documented. Annex IV(3) "
                    "requires detailed information about the performance "
                    "of the AI system."
                ),
                regulation_citation="Annex IV(3)",
                remediation=(
                    "Record performance metrics (accuracy, precision, "
                    "recall, fairness) under 'performance_benchmarks'."
                ),
            ))

        return findings

    def _check_cybersecurity(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> Optional[List[ComplianceFinding]]:
        """Article 15(5): Cybersecurity measures."""
        risk_level = self._resolve_risk_level(meta)
        if risk_level != "high":
            return None  # N/A: Article 15(5) cybersecurity requirements only apply to high-risk AI systems

        findings: List[ComplianceFinding] = []

        if not meta.get("cybersecurity_measures"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No cybersecurity measures documented. Article 15(5) "
                    "requires that high-risk AI systems are resilient "
                    "against attempts by unauthorised third parties to "
                    "alter their use, outputs, or performance by "
                    "exploiting system vulnerabilities."
                ),
                regulation_citation="Article 15(5)",
                remediation=(
                    "Document cybersecurity measures (access controls, "
                    "adversarial robustness testing, data integrity "
                    "checks) under 'cybersecurity_measures'."
                ),
            ))

        return findings

    def _check_fundamental_rights_impact(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> Optional[List[ComplianceFinding]]:
        """Article 27: Fundamental rights impact assessment (FRIA).

        Deployers of high-risk AI systems must conduct and document a
        fundamental rights impact assessment before deployment.
        """
        risk_level = self._resolve_risk_level(meta)
        findings: List[ComplianceFinding] = []

        if risk_level != "high":
            return None

        if not meta.get("fundamental_rights_impact_assessment"):
            findings.append(ComplianceFinding(
                severity=Severity.CRITICAL,
                description=(
                    "No fundamental rights impact assessment (FRIA) "
                    "documented. Article 27(1) requires deployers of "
                    "high-risk AI systems to perform and document an "
                    "assessment of the system's impact on fundamental "
                    "rights before putting it into use."
                ),
                regulation_citation="Article 27(1)",
                remediation=(
                    "Conduct a FRIA covering: (1) intended purpose and "
                    "deployment context, (2) affected groups and potential "
                    "harms, (3) impact on equality and non-discrimination, "
                    "(4) mitigation measures. Record under "
                    "'fundamental_rights_impact_assessment'."
                ),
            ))

        if not meta.get("affected_persons_description"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No description of affected persons. Article 27(3) "
                    "requires identifying categories of natural persons "
                    "and groups likely to be affected by the AI system."
                ),
                regulation_citation="Article 27(3)",
                remediation=(
                    "Document affected persons and groups under "
                    "'affected_persons_description'."
                ),
            ))

        return findings

    def _check_data_bias_representativeness(
        self, dag: ComputationDAG, meta: Dict[str, Any]
    ) -> Optional[List[ComplianceFinding]]:
        """Article 10(2)(f-g): Data bias and representativeness.

        Training, validation, and testing datasets must be relevant,
        representative, free of errors, and complete.  Providers must
        examine data for possible biases.
        """
        risk_level = self._resolve_risk_level(meta)
        findings: List[ComplianceFinding] = []

        if risk_level != "high":
            return None

        if not meta.get("bias_examination_documented"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No bias examination documented for training data. "
                    "Article 10(2)(f) requires providers to examine data "
                    "for possible biases that are likely to affect the "
                    "health and safety of persons, have an adverse impact "
                    "on fundamental rights, or lead to discrimination."
                ),
                regulation_citation="Article 10(2)(f)",
                remediation=(
                    "Conduct and document a bias examination of training "
                    "data. Record findings under 'bias_examination_documented'."
                ),
            ))

        if not meta.get("data_representativeness_assessment"):
            findings.append(ComplianceFinding(
                severity=Severity.WARNING,
                description=(
                    "No data representativeness assessment documented. "
                    "Article 10(2)(g) requires that datasets are "
                    "appropriate in view of the geographical, contextual, "
                    "behavioural, or functional setting within which the "
                    "system is intended to be used."
                ),
                regulation_citation="Article 10(2)(g)",
                remediation=(
                    "Assess whether training data is representative of "
                    "the deployment population and document under "
                    "'data_representativeness_assessment'."
                ),
            ))

        return findings
