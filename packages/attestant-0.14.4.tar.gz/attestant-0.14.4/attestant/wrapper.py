"""
Model wrapper for automatic Attestant compliance tracking and value-level provenance.

Wraps any ML model (scikit-learn, XGBoost, LightGBM, PyTorch, etc.) to
intercept fit() and predict() calls and automatically:

  1. Upload training data / predictions for fairness analysis and compliance
     reporting (SR 11-7, ECOA, EU AI Act).
  2. Record full value-level provenance — every column, every row, every
     prediction — as a queryable computation DAG in the Attestant backend.

Both happen in a background daemon thread so your pipeline is never blocked.
"""

import hashlib
import logging
import threading
import queue
import time
import json
import base64
import pickle
import urllib.parse
import urllib.request
import urllib.error
from typing import Any, List, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tamper-detection
# ---------------------------------------------------------------------------

class ModelTamperError(RuntimeError):
    """
    Raised when a model's local hash does not match the latest approved
    attestation stored in Attestant.

    This means the model was modified after its last validated deployment
    gate.  Inference is blocked until the new model is re-attested via
    ``attestant.validate()``.
    """


def _compute_model_hash(model) -> Optional[str]:
    """
    SHA-256 of the pickled model bytes, truncated to 16 hex chars.

    Matches the hash stored in ``model_snapshots.model_hash`` by the
    server — enabling apples-to-apples comparison at wrap() time.

    Returns ``None`` when the model cannot be pickled (non-picklable
    types: PyTorch nn.Module, TF SavedModel, custom classes without
    ``__reduce__``).  In that case tamper-detection is skipped with a
    warning rather than raising.
    """
    try:
        return hashlib.sha256(pickle.dumps(model)).hexdigest()[:16]
    except Exception:
        return None


def _fetch_attested_hash(
    service_url: str,
    api_key: str,
    model_name: str,
    timeout: int = 10,
) -> Optional[str]:
    """
    Return the ``model_hash`` from the most recent **approved** attestation
    for *model_name* belonging to the authenticated tenant.

    Return values:
      str  — 16-char hex hash when an approved attestation exists.
      None — no approved attestation has been recorded yet (first-time model).

    Raises:
      RuntimeError      — non-404 HTTP error from the server.
      urllib.error.URLError — network failure (caller decides severity).
    """
    safe_name = urllib.parse.quote(model_name, safe="")
    url = "%s/v1/models/%s/attested-hash" % (service_url.rstrip("/"), safe_name)
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": "Bearer %s" % api_key,
            "User-Agent": "attestant-python-client/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("model_hash")  # None if no approved attestation
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise RuntimeError(
            "HTTP %d fetching attested hash for '%s'" % (e.code, model_name)
        ) from e


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------

def _sanitize_value(v):
    """Return None for NaN/inf floats (JSON null), otherwise pass through."""
    import math
    try:
        if isinstance(v, float) and not math.isfinite(v):
            return None
    except Exception:
        pass
    return v


def _sanitize_rows(rows):
    """Walk a list-of-lists and replace NaN/inf with None."""
    return [[_sanitize_value(v) for v in row] for row in rows]


def _sanitize_list(lst):
    """Replace NaN/inf floats with None in a flat list."""
    return [_sanitize_value(v) for v in lst]


def _serialize(arr) -> Optional[dict]:
    """Convert any array-like to a JSON-safe dict the server can decode."""
    if arr is None:
        return None
    try:
        import pandas as pd
        import numpy as np

        if isinstance(arr, pd.DataFrame):
            split = arr.to_dict(orient="split")
            split["data"] = _sanitize_rows(split["data"])
            return {"type": "dataframe", "data": split}
        if isinstance(arr, pd.Series):
            return {"type": "series", "data": _sanitize_list(arr.tolist())}
        if isinstance(arr, np.ndarray):
            return {"type": "ndarray", "data": _sanitize_list(arr.tolist())}
        try:
            import scipy.sparse as sp
            if sp.issparse(arr):
                return {"type": "ndarray", "data": arr.toarray().tolist()}
        except ImportError:
            pass
        return {"type": "list", "data": [
            v.item() if hasattr(v, "item") else v for v in arr
        ]}
    except Exception as e:
        logger.warning(f"[attestant] Could not serialize {type(arr).__name__}: {e}")
        return None


def _resolve_protected(X, protected_df, protected_columns) -> Optional[Any]:
    """
    Resolve protected attribute data.

    Priority:
      1. Explicit ``protected_df`` (DataFrame or dict for single-row cases).
      2. Columns named in ``protected_columns`` that already exist in X.
    """
    if protected_df is not None:
        try:
            import pandas as pd
            if isinstance(protected_df, dict):
                return pd.DataFrame([protected_df])
        except ImportError:
            pass
        return protected_df

    if protected_columns:
        try:
            import pandas as pd
            if isinstance(X, pd.DataFrame):
                cols = [c for c in protected_columns if c in X.columns]
                if cols:
                    return X[cols]
        except ImportError:
            pass

    return None


def _run_local_predict(model, X):
    """
    Run predictions locally using any model type.

    Tries (in order):
      1. predict_proba  (sklearn, XGBoost, LightGBM, CatBoost) — probabilities
         preferred for richer fairness analysis
      2. predict        (any sklearn-compatible model)
      3. PyTorch nn.Module  (torch.tensor → forward → detach)
      4. TensorFlow / Keras model.predict()
      5. ONNX Runtime InferenceSession.run()
      6. Bare callable   (any function / lambda)

    Returns a 1-D numpy array of predictions (float).
    Raises RuntimeError if all attempts fail.
    """
    import numpy as np

    # 1. prefer predict_proba for richer fairness analysis
    if hasattr(model, "predict_proba"):
        try:
            proba = model.predict_proba(X)
            arr = np.asarray(proba, dtype=float)
            return arr[:, -1] if arr.ndim == 2 else arr.flatten()
        except Exception:
            pass

    # 2. sklearn-compatible predict
    if hasattr(model, "predict"):
        try:
            return np.asarray(model.predict(X), dtype=float).flatten()
        except Exception:
            pass

    # 3. PyTorch nn.Module
    try:
        import torch
        raw = X.values if hasattr(X, "values") else np.asarray(X)
        t = torch.tensor(raw, dtype=torch.float32)
        with torch.no_grad():
            out = model(t)
        arr = out.detach().cpu().numpy().flatten()
        return arr.astype(float)
    except Exception:
        pass

    # 4. TensorFlow / Keras (model.predict returns ndarray)
    try:
        result = model.predict(X)
        return np.asarray(result, dtype=float).flatten()
    except Exception:
        pass

    # 5. ONNX Runtime InferenceSession
    try:
        raw = X.values if hasattr(X, "values") else np.asarray(X, dtype=np.float32)
        input_name = model.get_inputs()[0].name
        result = model.run(None, {input_name: raw.astype(np.float32)})
        return np.asarray(result[0], dtype=float).flatten()
    except Exception:
        pass

    # 6. Bare callable
    if callable(model):
        try:
            return np.asarray(model(X), dtype=float).flatten()
        except Exception:
            pass

    raise RuntimeError(
        "Cannot generate predictions from %s. "
        "Pass predictions= directly to attestant.validate() instead."
        % type(model).__name__
    )


def _resolve_inputs(train_df, test_df, label_column, X_train, y_train, X_test, y_test, protected_columns):
    """
    Resolve any combination of data inputs into canonical form:
      (X_train, y_train, X_test, y_test, protected_df)

    Supports two input styles:

    DataFrame style (recommended):
      test_df=df, label_column="approved"
      Protected columns are auto-extracted from the DataFrame — the model
      never sees them as features (ECOA / Reg B compliance pattern).

    Array style (legacy / NumPy):
      X_test=X, y_test=y
      Protected columns auto-extracted from X if it is a DataFrame.

    In both cases protected_df is returned separately from X_test.
    """
    try:
        import pandas as pd
        import numpy as np
        has_pandas = True
    except ImportError:
        has_pandas = False

    protected_df = None

    # --- DataFrame mode ---
    if test_df is not None:
        if label_column is None:
            raise ValueError(
                "label_column is required when passing test_df. "
                "Example: validate(model=clf, test_df=df, label_column='approved', ...)"
            )
        if not has_pandas:
            raise ImportError("pandas is required when using train_df/test_df mode")

        if not isinstance(test_df, pd.DataFrame):
            test_df = pd.DataFrame(test_df)

        y_test = test_df[label_column].values

        prot_in_test = [c for c in protected_columns if c in test_df.columns]
        if prot_in_test:
            protected_df = test_df[prot_in_test].reset_index(drop=True)

        drop_cols = [label_column] + prot_in_test
        X_test = test_df.drop(
            columns=[c for c in drop_cols if c in test_df.columns]
        ).reset_index(drop=True)

        if train_df is not None:
            if not isinstance(train_df, pd.DataFrame):
                train_df = pd.DataFrame(train_df)
            y_train = train_df[label_column].values
            prot_in_train = [c for c in protected_columns if c in train_df.columns]
            X_train = train_df.drop(
                columns=[c for c in [label_column] + prot_in_train if c in train_df.columns]
            ).reset_index(drop=True)

    # --- Array mode ---
    elif X_test is not None:
        if has_pandas and isinstance(X_test, pd.DataFrame):
            prot_in_X = [c for c in protected_columns if c in X_test.columns]
            if prot_in_X:
                protected_df = X_test[prot_in_X].reset_index(drop=True)
                X_test = X_test.drop(columns=prot_in_X).reset_index(drop=True)
            if X_train is not None and isinstance(X_train, pd.DataFrame):
                prot_in_train = [c for c in protected_columns if c in X_train.columns]
                if prot_in_train:
                    X_train = X_train.drop(columns=prot_in_train).reset_index(drop=True)
    else:
        raise ValueError(
            "No data provided. Pass either test_df= (DataFrame mode) "
            "or X_test= (array mode)."
        )

    return X_train, y_train, X_test, y_test, protected_df


def _post_json(url: str, api_key: str, payload, timeout: int = 120) -> dict:
    """POST a JSON payload with Bearer authentication."""
    body = json.dumps(payload, default=str).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "attestant-python-client/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_text = e.read().decode("utf-8", errors="replace")[:400]
        raise RuntimeError(f"HTTP {e.code} from {url}: {error_text}") from e


def _patch_json(url: str, api_key: str, payload: dict, timeout: int = 30) -> dict:
    """PATCH a JSON payload with Bearer authentication."""
    body = json.dumps(payload, default=str).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        method="PATCH",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "attestant-python-client/1.0",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        error_text = e.read().decode("utf-8", errors="replace")[:200]
        raise RuntimeError(f"HTTP {e.code} (PATCH) from {url}: {error_text}") from e


def _fingerprint(*parts: str) -> int:
    """
    Deterministic 32-bit integer fingerprint from string components.

    Used as node identifiers in the provenance DAG.  Consistent across
    processes and Python versions (does not use hash()).
    """
    h = hashlib.md5("|".join(str(p) for p in parts).encode()).hexdigest()
    return int(h[:8], 16)  # first 32 bits of MD5


def _row_hash(row_dict: dict) -> str:
    """SHA-256 of a row's key-value pairs for tamper detection."""
    try:
        canonical = json.dumps(row_dict, sort_keys=True, default=str)
        return hashlib.sha256(canonical.encode()).hexdigest()
    except Exception:
        return ""


def _col_names(X, fallback_prefix: str = "feature") -> List[str]:
    """Extract column names from X, generating names for numpy arrays."""
    try:
        import pandas as pd
        if isinstance(X, pd.DataFrame):
            return [str(c) for c in X.columns]
    except ImportError:
        pass
    try:
        import numpy as np
        arr = np.asarray(X)
        n = arr.shape[1] if arr.ndim == 2 else 1
        return [f"{fallback_prefix}_{j}" for j in range(n)]
    except Exception:
        return [fallback_prefix]


def _row_count(X) -> int:
    """Return number of rows in X."""
    try:
        return len(X)
    except TypeError:
        try:
            import numpy as np
            return np.asarray(X).shape[0]
        except Exception:
            return 0


def _get_scalar(val) -> tuple:
    """Return (numeric_value, text_value) for a cell value."""
    try:
        import numpy as np
        if isinstance(val, (bool,)):
            return (float(val), None)
        if isinstance(val, (int, float, np.integer, np.floating)):
            v = float(val)
            return (None if (v != v) else v, None)  # NaN → None
    except ImportError:
        if isinstance(val, (bool, int, float)):
            return (float(val), None)
    return (None, str(val)[:255] if val is not None else None)


# ---------------------------------------------------------------------------
# Standalone provenance for validate()
# ---------------------------------------------------------------------------

def _run_validate_provenance(
    X,
    y,
    protected_data,
    protected_columns: List[str],
    model_name: str,
    model_version: str,
    api_key: str,
    service_url: str,
    model_id: str = "",
) -> None:
    """
    Store row-level provenance for a validate() call.

    Creates a pipeline record, registers source nodes (features + protected
    attributes), stores per-row results, and uploads all cell values.
    Called synchronously from validate() so the data is committed before
    validate() returns.
    """
    service_url = service_url.rstrip("/")
    feature_cols = _col_names(X)
    protected_cols = (
        _col_names(protected_data, "protected") if protected_data is not None else []
    )
    all_source_cols = feature_cols + [c for c in protected_cols if c not in feature_cols]

    # 1. Create pipeline
    try:
        resp = _post_json(
            f"{service_url}/v1/pipelines",
            api_key,
            {
                "pipeline_name": f"{model_name}_v{model_version}",
                "config": {
                    "model_name":    model_name,
                    "model_version": model_version,
                    "model_id":      model_id,
                },
            },
        )
        pipeline_id = int(resp["pipeline_id"])
    except Exception as e:
        logger.error("[attestant] validate() provenance: pipeline creation failed: %s", e)
        return

    # 2. Source nodes + validation operation node
    PAGE = 100
    val_fp = _fingerprint("validation", model_name, model_version)
    nodes: List[dict] = []

    for col in all_source_cols:
        is_prot = col in protected_cols or col in protected_columns
        fp = _fingerprint("source", model_name, col)
        nodes.append({
            "fingerprint":  fp,
            "node_type":    "source",
            "operation":    "source_protected" if is_prot else "source_feature",
            "table_name":   model_name,
            "column_name":  col,
            "pair_id":      fp,
            "is_protected": is_prot,
            "pipeline_id":  pipeline_id,
        })
        try:
            _post_json(
                f"{service_url}/v1/sources", api_key,
                {"pair_id": fp, "table_name": model_name,
                 "column_name": col, "is_protected": is_prot},
            )
        except Exception:
            pass

    nodes.append({
        "fingerprint":  val_fp,
        "node_type":    "computation",
        "operation":    "model_validate",
        "table_name":   model_name,
        "column_name":  "output",
        "is_protected": False,
        "pipeline_id":  pipeline_id,
        "metadata":     {"model_version": model_version, "model_id": model_id},
    })
    for offset in range(0, len(nodes), PAGE):
        try:
            _post_json(f"{service_url}/v1/nodes", api_key, nodes[offset:offset + PAGE])
        except Exception as e:
            logger.warning("[attestant] validate() provenance: node batch failed: %s", e)

    # 3. Edges: each source column → validation node
    edges = [
        {"parent_fingerprint": _fingerprint("source", model_name, col),
         "child_fingerprint":  val_fp}
        for col in all_source_cols
    ]
    for offset in range(0, len(edges), PAGE):
        try:
            _post_json(f"{service_url}/v1/edges", api_key, edges[offset:offset + PAGE])
        except Exception as e:
            logger.warning("[attestant] validate() provenance: edge batch failed: %s", e)

    # 4. Per-row results (one record per row — label + input hash)
    n = _row_count(X)
    if n == 0:
        return

    x_rows    = ModelWrapper._to_row_dicts(X, feature_cols)
    prot_rows = (ModelWrapper._to_row_dicts(protected_data, protected_cols)
                 if protected_data is not None else [])
    out_list  = ModelWrapper._flatten_outputs(y, n)

    results = []
    for i in range(n):
        row_data    = x_rows[i] if i < len(x_rows) else {}
        out_val     = out_list[i] if i < len(out_list) else None
        num_val, _  = _get_scalar(out_val)
        results.append({
            "row_key":      f"{model_name}_{pipeline_id}_model_validate_{i}",
            "output_name":  "model_validate",
            "fingerprint":  val_fp,
            "output_value": num_val,
            "input_hash":   _row_hash(row_data),
        })
    try:
        _post_json(
            f"{service_url}/v1/results", api_key,
            {"pipeline_id": pipeline_id, "results": results},
        )
    except Exception as e:
        logger.error("[attestant] validate() provenance: results upload failed: %s", e)

    # 5. Cell-level values (every column, every row, including protected attrs)
    values: List[dict] = []
    for i in range(n):
        row  = x_rows[i] if i < len(x_rows) else {}
        prow = prot_rows[i] if i < len(prot_rows) else {}

        for col in feature_cols:
            num_v, txt_v = _get_scalar(row.get(col))
            values.append({
                "pipeline_id":    pipeline_id,
                "row_index":      i,
                "fingerprint":    _fingerprint("source", model_name, col),
                "node_operation": "source_feature",
                "column_name":    col,
                "value":          num_v,
                "text_value":     txt_v,
            })
        for col in protected_cols:
            num_v, txt_v = _get_scalar(prow.get(col))
            values.append({
                "pipeline_id":    pipeline_id,
                "row_index":      i,
                "fingerprint":    _fingerprint("source", model_name, col),
                "node_operation": "source_protected",
                "column_name":    col,
                "value":          num_v,
                "text_value":     txt_v,
            })

        out_val = out_list[i] if i < len(out_list) else None
        num_v, txt_v = _get_scalar(out_val)
        values.append({
            "pipeline_id":    pipeline_id,
            "row_index":      i,
            "fingerprint":    val_fp,
            "node_operation": "model_validate",
            "column_name":    "output",
            "value":          num_v,
            "text_value":     txt_v,
        })

    PAGE_V = 500
    for offset in range(0, len(values), PAGE_V):
        try:
            _post_json(f"{service_url}/v1/values", api_key, values[offset:offset + PAGE_V])
        except Exception as e:
            logger.error("[attestant] validate() provenance: values batch failed: %s", e)

    try:
        _patch_json(
            f"{service_url}/v1/pipelines/{pipeline_id}", api_key,
            {"status": "validation_complete"},
        )
    except Exception:
        pass



# ---------------------------------------------------------------------------
# ModelWrapper
# ---------------------------------------------------------------------------

class ModelWrapper:
    """
    Drop-in wrapper for any ML model that automatically tracks:

    - Fairness analysis (disparate impact, statistical significance)
    - Compliance scoring (SR 11-7, ECOA, EU AI Act)
    - Full value-level provenance (every row, every column, every prediction)

    Behaves exactly like the wrapped model — all attribute access and sklearn,
    XGBoost, LightGBM, and custom model interfaces pass through transparently.
    All tracking happens in a background daemon thread.

    Usage::

        model = attestant.wrap(clf, model_name="loan_approval",
                               protected_columns=["age", "race", "gender"])

        # Protected columns in a separate DataFrame (ECOA / Reg B pattern):
        model.fit(X_train, y_train, protected_df=demographics_train)
        preds = model.predict(X_test, protected_df=demographics_test)

        # Or, if protected columns are already in X:
        model.fit(X_train, y_train)
        preds = model.predict(X_test)

        # Single real-time decision:
        pred = model.predict(features,
                             protected_df={"age": 34, "race": "White"})

        # Short-lived scripts: wait for uploads before exit
        model.flush()
    """

    def __init__(
        self,
        model: Any,
        model_name: str,
        protected_columns: List[str],
        api_key: str,
        service_url: str = "https://getattestant.com",
        model_version: str = "1.0.0",
        verify_hash: bool = True,
        on_network_error: str = "warn",
        **metadata,
    ):
        """
        Parameters
        ----------
        verify_hash : bool
            When ``True`` (default), the model's local hash is compared
            against the most recent approved attestation in Attestant before
            any inference is permitted.  Set ``False`` only for initial
            registration runs where no attestation exists yet.
        on_network_error : str
            What to do when the server is unreachable during hash
            verification.  ``"warn"`` (default) logs a warning and continues;
            ``"raise"`` treats network failures as security violations and
            raises :class:`ModelTamperError`.
        """
        self._model = model
        self._model_name = model_name
        self._protected_columns = list(protected_columns)
        self._api_key = api_key
        self._service_url = service_url.rstrip("/")
        self._model_version = str(model_version)
        self._metadata = metadata

        # Thread-safe first-fit guard
        self._training_captured = False
        self._capture_lock = threading.Lock()

        # pipeline_id is set after the first training upload and reused
        # for all subsequent inference uploads (set only inside worker thread)
        self._pipeline_id: Optional[int] = None

        # Compliance result from training upload (set by worker thread)
        self._result: Optional[Any] = None

        # ── Tamper-detection (runs synchronously at construction) ──────────
        self._local_hash: Optional[str] = _compute_model_hash(model)
        if verify_hash:
            self._verify_hash(on_network_error)

        # Background upload queue + single worker thread
        self._queue: queue.Queue = queue.Queue()
        self._worker_thread = threading.Thread(
            target=self._worker_loop,
            daemon=True,
            name=f"attestant-{model_name}",
        )
        self._worker_thread.start()

    # ------------------------------------------------------------------
    # Tamper-detection
    # ------------------------------------------------------------------

    def _verify_hash(self, on_network_error: str = "warn") -> None:
        """
        Compare the local model hash against the server-attested hash.

        Raises :class:`ModelTamperError` immediately if the hashes differ —
        blocking construction of the wrapper (and therefore all inference)
        before a single prediction is produced.

        Does nothing when:
        - The model is non-picklable (hash cannot be computed).
        - No approved attestation exists yet (first-time model).

        Network failures are governed by *on_network_error*:
        - ``"warn"``  — logs and continues (default; preserves availability).
        - ``"raise"`` — treats connectivity loss as a security violation.
        """
        if self._local_hash is None:
            logger.warning(
                "[attestant] %s: model is non-picklable — "
                "tamper-detection skipped (hash cannot be computed)",
                self._model_name,
            )
            return

        try:
            attested = _fetch_attested_hash(
                self._service_url, self._api_key, self._model_name
            )
        except Exception as exc:
            msg = (
                "[attestant] %s: could not fetch attested hash from server: %s"
                % (self._model_name, exc)
            )
            if on_network_error == "raise":
                raise ModelTamperError(msg) from exc
            logger.warning(msg)
            return

        if attested is None:
            logger.warning(
                "[attestant] %s: no approved attestation on record — "
                "run attestant.validate() before wrap() to enable tamper detection",
                self._model_name,
            )
            return

        if self._local_hash != attested:
            raise ModelTamperError(
                "Model '%s' hash mismatch — inference blocked.\n"
                "  Local model hash : %s\n"
                "  Attested hash    : %s\n"
                "The model has been altered since its last approved attestation. "
                "Re-run attestant.validate() to attest the updated model."
                % (self._model_name, self._local_hash, attested)
            )

        logger.info(
            "[attestant] %s: hash verified ✓ (local=%s attested=%s)",
            self._model_name, self._local_hash, attested,
        )

    # ------------------------------------------------------------------
    # sklearn-compatible public API
    # ------------------------------------------------------------------

    def fit(self, X, y=None, protected_df=None, **kwargs):
        """
        Fit the model, capturing training data for compliance analysis and
        full value-level provenance.

        Parameters
        ----------
        X : array-like
            Training features (numpy array, pandas DataFrame, sparse matrix, …).
        y : array-like, optional
            Training labels. Passed through to the model unchanged.
        protected_df : DataFrame or dict, optional
            Protected attribute columns (age, race, gender, …).
            Required when these are *not* already columns in X (ECOA / Reg B).
            Must align row-for-row with X. A ``dict`` is accepted for single-row.
        **kwargs
            Passed directly to the underlying model's ``fit()``.
            ``sample_weight``, ``eval_set``, ``callbacks``, etc. all work.

        Returns
        -------
        self
        """
        self._model.fit(X, y, **kwargs)

        with self._capture_lock:
            first_fit = not self._training_captured
            if first_fit:
                self._training_captured = True

        if first_fit:
            protected = _resolve_protected(X, protected_df, self._protected_columns)
            self._queue.put(("training", X, y, protected))

        return self

    def predict(self, X, protected_df=None, **kwargs):
        """
        Predict and capture results for inference monitoring and provenance.

        Parameters
        ----------
        X : array-like
            Features.
        protected_df : DataFrame or dict, optional
            Protected attributes when not already in X.
        **kwargs
            Passed to the underlying model's ``predict()``.

        Returns
        -------
        array-like
            Predictions — identical to the unwrapped model.
        """
        predictions = self._model.predict(X, **kwargs)
        protected = _resolve_protected(X, protected_df, self._protected_columns)
        self._queue.put(("inference", X, predictions, protected))
        return predictions

    def predict_proba(self, X, protected_df=None, **kwargs):
        """
        Predict class probabilities and capture for monitoring and provenance.

        Parameters
        ----------
        X : array-like
            Features.
        protected_df : DataFrame or dict, optional
            Protected attributes when not already in X.
        **kwargs
            Passed to the underlying model's ``predict_proba()``.

        Returns
        -------
        array-like
            Class probability array — identical to the unwrapped model.
        """
        probas = self._model.predict_proba(X, **kwargs)
        protected = _resolve_protected(X, protected_df, self._protected_columns)
        self._queue.put(("inference", X, probas, protected))
        return probas

    def score(self, X, y, **kwargs):
        """Compute model score. Passes through to the wrapped model."""
        return self._model.score(X, y, **kwargs)

    @property
    def result(self):
        """Compliance result from the last training upload.

        Returns ``None`` until ``flush()`` completes. After that, returns a
        :class:`~attestant.ValidationResult` with pass/fail, compliance score,
        findings, and the dashboard URL.

        Example::

            model.fit(X_train, y_train)
            model.flush()
            if model.result:
                print(model.result.dashboard_url)
        """
        return self._result

    def flush(self, timeout: float = 60.0) -> bool:
        """
        Wait for all queued uploads to complete.

        Useful at the end of a short-lived script to ensure no data is lost
        before the process exits. Long-running services do not need this.

        After ``flush()`` returns, check ``model.result`` for compliance
        results and the dashboard URL.

        Parameters
        ----------
        timeout : float
            Maximum seconds to wait (default 60).

        Returns
        -------
        bool
            True if all uploads completed, False if timed out.
        """
        done = threading.Event()
        self._queue.put(("_flush", done))
        completed = done.wait(timeout=timeout)
        if not completed:
            logger.warning(
                f"[attestant] flush() timed out after {timeout}s — "
                "some uploads may not have completed"
            )
        return completed

    def __repr__(self) -> str:
        return (
            f"ModelWrapper({self._model!r}, "
            f"model_name={self._model_name!r}, "
            f"model_version={self._model_version!r})"
        )

    def __getattr__(self, name: str):
        """Pass all other attribute access to the wrapped model."""
        try:
            model = object.__getattribute__(self, "_model")
        except AttributeError:
            raise AttributeError(
                f"'{type(self).__name__}' object has no attribute '{name}'"
            )
        return getattr(model, name)

    # ------------------------------------------------------------------
    # Background worker
    # ------------------------------------------------------------------

    def _worker_loop(self):
        """Single-threaded FIFO worker. Always calls task_done() via finally."""
        while True:
            item = None
            try:
                item = self._queue.get(timeout=1.0)
                kind = item[0]

                if kind == "training":
                    _, X, y, protected = item
                    self._do_upload_training(X, y, protected)

                elif kind == "inference":
                    _, X, predictions, protected = item
                    self._do_upload_inference(X, predictions, protected)

                elif kind == "_flush":
                    _, event = item
                    event.set()

            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"[attestant] Worker error: {e}")
                time.sleep(1)
            finally:
                if item is not None:
                    self._queue.task_done()

    # ------------------------------------------------------------------
    # Compliance uploads
    # ------------------------------------------------------------------

    def _do_upload_training(self, X, y, protected_data):
        """Upload training data for compliance analysis, then record provenance."""
        # --- Compliance ---
        try:
            model_b64 = base64.b64encode(pickle.dumps(self._model)).decode("utf-8")
            # Run predictions locally (works for any model type)
            import numpy as _np
            try:
                local_preds = _run_local_predict(self._model, X)
            except Exception as _pe:
                logger.warning("[attestant] Local predict failed in wrap().fit(): %s", _pe)
                local_preds = None

            train_payload: dict = {
                "model_name":        self._model_name,
                "model_version":     self._model_version,
                "X_test":            _serialize(X),
                "y_test":            _serialize(y),
                "protected_data":    _serialize(protected_data),
                "protected_columns": self._protected_columns,
                "metadata":          self._metadata,
            }
            if local_preds is not None:
                train_payload["predictions"] = _serialize(_np.asarray(local_preds))
            if model_b64:
                train_payload["model_b64"] = model_b64

            resp = _post_json(
                f"{self._service_url}/v1/training",
                self._api_key,
                train_payload,
            )

            # Surface compliance results
            from . import ValidationResult
            dashboard_url = resp.get(
                "dashboard_url",
                "%s/client/models/%s" % (self._service_url, self._model_name),
            )
            self._result = ValidationResult(
                approved=resp.get("deployment_approved", False),
                compliance_score=float(resp.get("compliance_score", 0)),
                findings=resp.get("findings", []),
                dashboard_url=dashboard_url,
                model_id=resp.get("model_id", ""),
                details=resp,
            )
        except Exception as e:
            logger.error(f"[attestant] Training upload failed: {e}")

        # --- Value-level provenance ---
        try:
            self._run_training_provenance(X, y, protected_data)
        except Exception as e:
            logger.error(f"[attestant] Training provenance failed: {e}")

    def _do_upload_inference(self, X, predictions, protected_data):
        """Upload inference batch for compliance monitoring, then record provenance."""
        batch_id = f"batch_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"

        # --- Compliance ---
        try:
            _post_json(
                f"{self._service_url}/v1/inference",
                self._api_key,
                {
                    "model_name":        self._model_name,
                    "model_version":     self._model_version,
                    "X_production":      _serialize(X),
                    "predictions":       _serialize(predictions),
                    "protected_data":    _serialize(protected_data),
                    "protected_columns": self._protected_columns,
                    "batch_id":          batch_id,
                    "metadata":          self._metadata,
                },
            )
            pass
        except Exception as e:
            logger.error(f"[attestant] Inference upload failed: {e}")

        # --- Value-level provenance ---
        try:
            self._run_inference_provenance(X, predictions, protected_data, batch_id)
        except Exception as e:
            logger.error(f"[attestant] Inference provenance failed: {e}")

    # ------------------------------------------------------------------
    # Provenance: training
    # ------------------------------------------------------------------

    def _run_training_provenance(self, X, y, protected_data):
        """
        Record full value-level provenance for a training run:
          1. Create pipeline record
          2. Register source nodes (features + protected attrs)
          3. Register training operation node
          4. Register edges (sources → training)
          5. Per-row audit trail (input hash + label per row)
          6. Per-row cell values (every column, every row)
        """
        # 1. Create pipeline
        pipeline_id = self._create_pipeline()
        self._pipeline_id = pipeline_id

        feature_cols = _col_names(X)
        protected_cols = _col_names(protected_data, "protected") if protected_data is not None else []
        # deduplicate: protected cols already in X are still tracked as protected
        all_source_cols = feature_cols + [c for c in protected_cols if c not in feature_cols]

        # 2. Register source nodes (one per column)
        source_nodes = []
        for col in all_source_cols:
            is_protected = (col in protected_cols or col in self._protected_columns)
            fp = _fingerprint("source", self._model_name, col)
            source_nodes.append({
                "fingerprint":  fp,
                "node_type":    "source",
                "operation":    "source_protected" if is_protected else "source_feature",
                "table_name":   self._model_name,
                "column_name":  col,
                "pair_id":      fp,
                "is_protected": is_protected,
                "pipeline_id":  pipeline_id,
            })
            # Register in source_registry for queryable metadata
            try:
                _post_json(
                    f"{self._service_url}/v1/sources",
                    self._api_key,
                    {
                        "pair_id":      fp,
                        "table_name":   self._model_name,
                        "column_name":  col,
                        "is_protected": is_protected,
                    },
                )
            except Exception:
                pass

        # 3. Register training node
        train_fp = _fingerprint("training", self._model_name, self._model_version)
        source_nodes.append({
            "fingerprint":  train_fp,
            "node_type":    "computation",
            "operation":    "model_fit",
            "table_name":   self._model_name,
            "column_name":  "output",
            "is_protected": False,
            "pipeline_id":  pipeline_id,
            "metadata":     {
                "model_version": self._model_version,
                **{k: str(v) for k, v in self._metadata.items()},
            },
        })
        self._post_nodes(source_nodes)

        # 4. Register edges: each source column → training node
        edges = [
            {"parent_fingerprint": _fingerprint("source", self._model_name, col),
             "child_fingerprint":  train_fp}
            for col in all_source_cols
        ]
        if edges:
            self._post_edges(edges)

        # 5 & 6. Per-row results + cell values
        self._store_rows(
            X=X,
            outputs=y,
            protected_data=protected_data,
            pipeline_id=pipeline_id,
            output_fp=train_fp,
            operation="model_fit",
            feature_cols=feature_cols,
            protected_cols=protected_cols,
        )

        # Mark pipeline training complete
        try:
            _patch_json(
                f"{self._service_url}/v1/pipelines/{pipeline_id}",
                self._api_key,
                {"status": "training_complete"},
            )
        except Exception:
            pass


    # ------------------------------------------------------------------
    # Provenance: inference
    # ------------------------------------------------------------------

    def _run_inference_provenance(self, X, predictions, protected_data, batch_id: str):
        """
        Record full value-level provenance for an inference batch:
          1. Reuse (or create) pipeline record
          2. Re-register source nodes (server ignores duplicates)
          3. Register inference operation node
          4. Register edges (training node → inference node)
          5. Per-row audit trail (input hash + prediction per row)
          6. Per-row cell values (every column, every row)
        """
        # Reuse training pipeline if available; otherwise create standalone
        pipeline_id = self._pipeline_id
        if pipeline_id is None:
            pipeline_id = self._create_pipeline()
            self._pipeline_id = pipeline_id

        feature_cols = _col_names(X)
        protected_cols = _col_names(protected_data, "protected") if protected_data is not None else []
        all_source_cols = feature_cols + [c for c in protected_cols if c not in feature_cols]

        # Re-register source nodes (upsert: server ignores existing fingerprints)
        source_nodes = []
        for col in all_source_cols:
            is_protected = (col in protected_cols or col in self._protected_columns)
            source_nodes.append({
                "fingerprint":  _fingerprint("source", self._model_name, col),
                "node_type":    "source",
                "operation":    "source_protected" if is_protected else "source_feature",
                "table_name":   self._model_name,
                "column_name":  col,
                "pair_id":      _fingerprint("source", self._model_name, col),
                "is_protected": is_protected,
                "pipeline_id":  pipeline_id,
            })

        # Inference node (unique per batch)
        infer_fp = _fingerprint("inference", self._model_name, self._model_version, batch_id)
        train_fp = _fingerprint("training", self._model_name, self._model_version)
        source_nodes.append({
            "fingerprint":  infer_fp,
            "node_type":    "computation",
            "operation":    "model_predict",
            "table_name":   self._model_name,
            "column_name":  "prediction",
            "is_protected": False,
            "pipeline_id":  pipeline_id,
            "metadata":     {"batch_id": batch_id},
        })
        self._post_nodes(source_nodes)

        # Edges: sources → inference node, and training node → inference node
        edges = [
            {"parent_fingerprint": _fingerprint("source", self._model_name, col),
             "child_fingerprint":  infer_fp}
            for col in all_source_cols
        ]
        edges.append({
            "parent_fingerprint": train_fp,
            "child_fingerprint":  infer_fp,
        })
        self._post_edges(edges)

        # Per-row results + cell values
        self._store_rows(
            X=X,
            outputs=predictions,
            protected_data=protected_data,
            pipeline_id=pipeline_id,
            output_fp=infer_fp,
            operation="model_predict",
            feature_cols=feature_cols,
            protected_cols=protected_cols,
        )


    # ------------------------------------------------------------------
    # Provenance: shared row storage
    # ------------------------------------------------------------------

    def _store_rows(
        self,
        X,
        outputs,
        protected_data,
        pipeline_id: int,
        output_fp: int,
        operation: str,
        feature_cols: List[str],
        protected_cols: List[str],
    ):
        """
        Store per-row audit trail and cell-level values.

        pipeline_results  — one record per row: row_key, fingerprint, output value, input hash
        row_values        — one record per (row, column): every cell in X and protected_data
        """
        import numpy as np

        try:
            import pandas as pd
        except ImportError:
            pd = None

        n = _row_count(X)
        if n == 0:
            return

        # ---- Build X as a list of dicts ----
        x_rows = self._to_row_dicts(X, feature_cols)

        # ---- Build protected rows as a list of dicts ----
        prot_rows: List[dict] = []
        if protected_data is not None:
            prot_rows = self._to_row_dicts(protected_data, protected_cols)

        # ---- Build outputs as a flat list ----
        out_list = self._flatten_outputs(outputs, n)

        # ---- Accumulate pipeline_results records ----
        results = []
        for i in range(n):
            row_data = x_rows[i] if i < len(x_rows) else {}
            input_hash = _row_hash(row_data)
            out_val = out_list[i] if i < len(out_list) else None
            num_val, _ = _get_scalar(out_val)
            results.append({
                "row_key":      f"{self._model_name}_{pipeline_id}_{operation}_{i}",
                "output_name":  operation,
                "fingerprint":  output_fp,
                "output_value": num_val,
                "input_hash":   input_hash,
            })

        _post_json(
            f"{self._service_url}/v1/results",
            self._api_key,
            {"pipeline_id": pipeline_id, "results": results},
        )

        # ---- Accumulate row_values records ----
        values = []
        for i in range(n):
            # Feature columns
            row = x_rows[i] if i < len(x_rows) else {}
            for col in feature_cols:
                val = row.get(col)
                num_v, txt_v = _get_scalar(val)
                col_fp = _fingerprint("source", self._model_name, col)
                values.append({
                    "pipeline_id":   pipeline_id,
                    "row_index":     i,
                    "fingerprint":   col_fp,
                    "node_operation":"source_feature",
                    "column_name":   col,
                    "value":         num_v,
                    "text_value":    txt_v,
                })

            # Protected attribute columns
            prow = prot_rows[i] if i < len(prot_rows) else {}
            for col in protected_cols:
                val = prow.get(col)
                num_v, txt_v = _get_scalar(val)
                col_fp = _fingerprint("source", self._model_name, col)
                values.append({
                    "pipeline_id":   pipeline_id,
                    "row_index":     i,
                    "fingerprint":   col_fp,
                    "node_operation":"source_protected",
                    "column_name":   col,
                    "value":         num_v,
                    "text_value":    txt_v,
                })

            # Output / prediction value
            out_val = out_list[i] if i < len(out_list) else None
            num_v, txt_v = _get_scalar(out_val)
            values.append({
                "pipeline_id":   pipeline_id,
                "row_index":     i,
                "fingerprint":   output_fp,
                "node_operation": operation,
                "column_name":   "output",
                "value":         num_v,
                "text_value":    txt_v,
            })

        # Send in batches of 500 (server's page_size)
        PAGE = 500
        for offset in range(0, len(values), PAGE):
            _post_json(
                f"{self._service_url}/v1/values",
                self._api_key,
                values[offset : offset + PAGE],
            )

    # ------------------------------------------------------------------
    # Provenance: low-level helpers
    # ------------------------------------------------------------------

    def _create_pipeline(self) -> int:
        resp = _post_json(
            f"{self._service_url}/v1/pipelines",
            self._api_key,
            {
                "pipeline_name": f"{self._model_name}_v{self._model_version}",
                "config": {
                    "model_name":    self._model_name,
                    "model_version": self._model_version,
                },
            },
        )
        return int(resp["pipeline_id"])

    def _post_nodes(self, nodes: list):
        """Batch-post DAG nodes; server ignores duplicates (ON CONFLICT DO NOTHING)."""
        PAGE = 100
        for offset in range(0, len(nodes), PAGE):
            try:
                _post_json(
                    f"{self._service_url}/v1/nodes",
                    self._api_key,
                    nodes[offset : offset + PAGE],
                )
            except Exception as e:
                logger.warning(f"[attestant] Node batch failed: {e}")

    def _post_edges(self, edges: list):
        """Batch-post DAG edges; server ignores duplicates."""
        PAGE = 100
        for offset in range(0, len(edges), PAGE):
            try:
                _post_json(
                    f"{self._service_url}/v1/edges",
                    self._api_key,
                    edges[offset : offset + PAGE],
                )
            except Exception as e:
                logger.warning(f"[attestant] Edge batch failed: {e}")

    @staticmethod
    def _to_row_dicts(X, cols: List[str]) -> List[dict]:
        """Convert X to a list of {column: value} dicts, one per row."""
        try:
            import pandas as pd
            if isinstance(X, pd.DataFrame):
                return [
                    {col: row[col] if col in row.index else None
                     for col in cols}
                    for _, row in X.iterrows()
                ]
            if isinstance(X, pd.Series):
                return [{cols[0]: v} for v in X]
        except ImportError:
            pass
        try:
            import numpy as np
            arr = np.asarray(X, dtype=object)
            if arr.ndim == 1:
                arr = arr.reshape(-1, 1)
            return [
                {cols[j]: arr[i, j] for j in range(min(len(cols), arr.shape[1]))}
                for i in range(arr.shape[0])
            ]
        except Exception:
            pass
        try:
            return [{cols[j]: row[j] for j in range(min(len(cols), len(row)))}
                    for row in X]
        except Exception:
            return []

    @staticmethod
    def _flatten_outputs(outputs, n: int) -> List:
        """Flatten any output type (binary array, probability matrix, scalar) to a list of n values."""
        if outputs is None:
            return [None] * n
        try:
            import numpy as np
            arr = np.asarray(outputs)
            if arr.ndim == 2:
                # Probability matrix — store the positive-class probability (last column)
                arr = arr[:, -1]
            return arr.tolist()
        except Exception:
            pass
        try:
            return list(outputs)
        except TypeError:
            return [outputs] + [None] * (n - 1)
