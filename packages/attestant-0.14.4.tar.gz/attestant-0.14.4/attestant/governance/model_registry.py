"""
Model Registry: Lifecycle Management for Regulated AI Models.

Tracks models from development through deployment, monitoring, and
retirement.  Designed for SR 11-7 compliance where the OCC expects
banks to maintain a complete model inventory with:

- Model identification and classification (SR 11-7 § III.A)
- Risk tiering (Tier 1/2/3 per OCC Bulletin 2011-12)
- Validation status and history
- Ongoing monitoring results
- Use limitations and change history
- Ownership and accountability

This is a key competitive differentiator vs. ValidMind (which only
documents the validation process) and ModelOp (which doesn't have
cryptographic provenance).

Usage::

    from attestant.governance.model_registry import ModelRegistry, ModelRecord

    registry = ModelRegistry()
    registry.register(ModelRecord(
        model_id="credit_score_v1",
        name="Consumer Credit Score Model",
        version="1.0.0",
        tier=1,
        owner="Model Risk Management",
        domain="lending",
        status="production",
    ))

    # Track validation
    registry.record_validation("credit_score_v1", ...)

    # Generate model inventory report for examiners
    report = registry.inventory_report()
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


class ModelStatus(Enum):
    """Lifecycle status of a model."""
    DEVELOPMENT = "development"
    VALIDATION = "validation"
    APPROVED = "approved"
    PRODUCTION = "production"
    MONITORING = "monitoring"
    UNDER_REVIEW = "under_review"
    DEPRECATED = "deprecated"
    RETIRED = "retired"


class ModelTier(Enum):
    """Risk tier per SR 11-7 / OCC guidance.

    Tier 1: Critical models (credit decisions, pricing, capital)
    Tier 2: Significant models (marketing, fraud detection)
    Tier 3: Low-risk models (internal reporting, analytics)
    """
    TIER_1 = 1
    TIER_2 = 2
    TIER_3 = 3


@dataclass
class ValidationRecord:
    """Record of a model validation event."""
    validation_id: str
    date: datetime
    validator: str
    independent: bool
    result: str  # "approved", "approved_with_conditions", "rejected"
    findings_count: int = 0
    conditions: List[str] = field(default_factory=list)
    next_validation_date: Optional[datetime] = None
    report_reference: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "validation_id": self.validation_id,
            "date": self.date.isoformat(),
            "validator": self.validator,
            "independent": self.independent,
            "result": self.result,
            "findings_count": self.findings_count,
            "conditions": self.conditions,
            "next_validation_date": (
                self.next_validation_date.isoformat()
                if self.next_validation_date else None
            ),
            "report_reference": self.report_reference,
        }


@dataclass
class MonitoringResult:
    """Result of an ongoing monitoring check."""
    date: datetime
    monitor_type: str  # "fairness", "performance", "drift", "compliance"
    passed: bool
    metrics: Dict[str, Any] = field(default_factory=dict)
    alerts: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "date": self.date.isoformat(),
            "monitor_type": self.monitor_type,
            "passed": self.passed,
            "metrics": self.metrics,
            "alerts": self.alerts,
        }


@dataclass
class ModelRecord:
    """Complete record of a model in the registry.

    Captures everything an OCC examiner expects to see in a
    model inventory per SR 11-7 and the OCC Model Risk Management
    Handbook.
    """
    model_id: str
    name: str
    version: str
    tier: int  # 1, 2, or 3
    owner: str
    domain: str
    status: str = "development"
    description: str = ""
    model_type: str = ""
    developer: str = ""
    development_date: Optional[datetime] = None
    deployment_date: Optional[datetime] = None
    last_validation_date: Optional[datetime] = None
    next_validation_date: Optional[datetime] = None
    model_hash: str = ""
    use_limitations: List[str] = field(default_factory=list)
    data_sources: List[str] = field(default_factory=list)
    protected_attributes: List[str] = field(default_factory=list)
    compliance_score: Optional[float] = None
    validations: List[ValidationRecord] = field(default_factory=list)
    monitoring_results: List[MonitoringResult] = field(default_factory=list)
    change_history: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    updated_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    @property
    def tier_enum(self) -> ModelTier:
        return ModelTier(self.tier)

    @property
    def status_enum(self) -> ModelStatus:
        return ModelStatus(self.status)

    @property
    def is_production(self) -> bool:
        return self.status in ("production", "monitoring")

    @property
    def is_active(self) -> bool:
        return self.status not in ("deprecated", "retired")

    @property
    def validation_overdue(self) -> bool:
        """Check if validation is overdue per SR 11-7 requirements.

        Tier 1: Annual validation required
        Tier 2: Every 2 years
        Tier 3: Every 3 years
        """
        if self.next_validation_date is None:
            return self.last_validation_date is None
        return datetime.now(timezone.utc) > self.next_validation_date

    @property
    def monitoring_frequency_days(self) -> int:
        """Required monitoring frequency based on tier."""
        if self.tier == 1:
            return 90   # Quarterly
        elif self.tier == 2:
            return 180  # Semi-annual
        return 365      # Annual

    @property
    def latest_monitoring(self) -> Optional[MonitoringResult]:
        if not self.monitoring_results:
            return None
        return max(self.monitoring_results, key=lambda r: r.date)

    @property
    def monitoring_overdue(self) -> bool:
        latest = self.latest_monitoring
        if latest is None:
            return self.is_production
        days_since = (datetime.now(timezone.utc) - latest.date).days
        return days_since > self.monitoring_frequency_days

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model_id": self.model_id,
            "name": self.name,
            "version": self.version,
            "tier": self.tier,
            "owner": self.owner,
            "domain": self.domain,
            "status": self.status,
            "description": self.description,
            "model_type": self.model_type,
            "developer": self.developer,
            "development_date": (
                self.development_date.isoformat()
                if self.development_date else None
            ),
            "deployment_date": (
                self.deployment_date.isoformat()
                if self.deployment_date else None
            ),
            "last_validation_date": (
                self.last_validation_date.isoformat()
                if self.last_validation_date else None
            ),
            "next_validation_date": (
                self.next_validation_date.isoformat()
                if self.next_validation_date else None
            ),
            "model_hash": self.model_hash,
            "use_limitations": self.use_limitations,
            "data_sources": self.data_sources,
            "protected_attributes": self.protected_attributes,
            "compliance_score": self.compliance_score,
            "is_production": self.is_production,
            "is_active": self.is_active,
            "validation_overdue": self.validation_overdue,
            "monitoring_overdue": self.monitoring_overdue,
            "validations": [v.to_dict() for v in self.validations],
            "monitoring_results": [
                m.to_dict() for m in self.monitoring_results[-10:]
            ],
            "change_history": self.change_history[-20:],
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }


class ModelRegistry:
    """In-memory model registry for lifecycle management.

    Provides a complete model inventory that maps to the OCC's
    expectations for model risk management per SR 11-7.
    """

    def __init__(self) -> None:
        self._models: Dict[str, ModelRecord] = {}

    def register(self, model: ModelRecord) -> None:
        """Register a model in the registry."""
        model.change_history.append({
            "date": datetime.now(timezone.utc).isoformat(),
            "action": "registered",
            "details": f"Model {model.model_id} v{model.version} registered",
        })
        self._models[model.model_id] = model

    def get(self, model_id: str) -> Optional[ModelRecord]:
        """Get a model by ID."""
        return self._models.get(model_id)

    def update_status(self, model_id: str, new_status: str) -> None:
        """Update a model's lifecycle status."""
        model = self._models.get(model_id)
        if model is None:
            raise KeyError(f"Model {model_id} not found in registry")
        old_status = model.status
        model.status = new_status
        model.updated_at = datetime.now(timezone.utc)
        model.change_history.append({
            "date": datetime.now(timezone.utc).isoformat(),
            "action": "status_change",
            "details": f"Status changed from {old_status} to {new_status}",
        })

    def record_validation(
        self,
        model_id: str,
        validation: ValidationRecord,
    ) -> None:
        """Record a validation event for a model."""
        model = self._models.get(model_id)
        if model is None:
            raise KeyError(f"Model {model_id} not found in registry")
        model.validations.append(validation)
        model.last_validation_date = validation.date
        if validation.next_validation_date:
            model.next_validation_date = validation.next_validation_date
        model.updated_at = datetime.now(timezone.utc)
        model.change_history.append({
            "date": datetime.now(timezone.utc).isoformat(),
            "action": "validation",
            "details": (
                f"Validation by {validation.validator}: "
                f"{validation.result}"
            ),
        })

    def record_monitoring(
        self,
        model_id: str,
        result: MonitoringResult,
    ) -> None:
        """Record a monitoring result for a model."""
        model = self._models.get(model_id)
        if model is None:
            raise KeyError(f"Model {model_id} not found in registry")
        model.monitoring_results.append(result)
        model.updated_at = datetime.now(timezone.utc)
        if not result.passed:
            model.change_history.append({
                "date": datetime.now(timezone.utc).isoformat(),
                "action": "monitoring_alert",
                "details": (
                    f"Monitoring check failed: {result.monitor_type}. "
                    f"Alerts: {', '.join(result.alerts)}"
                ),
            })

    def update_compliance_score(
        self, model_id: str, score: float,
    ) -> None:
        """Update the compliance score for a model."""
        model = self._models.get(model_id)
        if model is None:
            raise KeyError(f"Model {model_id} not found in registry")
        model.compliance_score = score
        model.updated_at = datetime.now(timezone.utc)

    # -- Queries --

    @property
    def all_models(self) -> List[ModelRecord]:
        """All registered models."""
        return list(self._models.values())

    @property
    def active_models(self) -> List[ModelRecord]:
        """Models that are not deprecated or retired."""
        return [m for m in self._models.values() if m.is_active]

    @property
    def production_models(self) -> List[ModelRecord]:
        """Models currently in production."""
        return [m for m in self._models.values() if m.is_production]

    def models_by_tier(self, tier: int) -> List[ModelRecord]:
        """Get models by risk tier."""
        return [m for m in self._models.values() if m.tier == tier]

    def models_by_domain(self, domain: str) -> List[ModelRecord]:
        """Get models by business domain."""
        return [
            m for m in self._models.values()
            if m.domain.lower() == domain.lower()
        ]

    @property
    def validation_overdue(self) -> List[ModelRecord]:
        """Models with overdue validations."""
        return [
            m for m in self._models.values()
            if m.is_active and m.validation_overdue
        ]

    @property
    def monitoring_overdue(self) -> List[ModelRecord]:
        """Production models with overdue monitoring."""
        return [
            m for m in self._models.values()
            if m.is_production and m.monitoring_overdue
        ]

    # -- Reports --

    def inventory_report(self) -> Dict[str, Any]:
        """Generate a model inventory report for examiners.

        Organized per the OCC Model Risk Management Handbook
        structure that examiners expect.
        """
        models = self.all_models
        active = self.active_models
        production = self.production_models

        tier_counts = {1: 0, 2: 0, 3: 0}
        domain_counts: Dict[str, int] = {}
        for m in active:
            tier_counts[m.tier] = tier_counts.get(m.tier, 0) + 1
            domain_counts[m.domain] = domain_counts.get(m.domain, 0) + 1

        overdue_validation = self.validation_overdue
        overdue_monitoring = self.monitoring_overdue

        avg_score = None
        scores = [
            m.compliance_score for m in active if m.compliance_score is not None
        ]
        if scores:
            avg_score = sum(scores) / len(scores)

        return {
            "report_date": datetime.now(timezone.utc).isoformat(),
            "total_models": len(models),
            "active_models": len(active),
            "production_models": len(production),
            "by_tier": tier_counts,
            "by_domain": domain_counts,
            "by_status": {
                status.value: sum(
                    1 for m in models if m.status == status.value
                )
                for status in ModelStatus
            },
            "validation_overdue": [
                {"model_id": m.model_id, "name": m.name, "tier": m.tier}
                for m in overdue_validation
            ],
            "monitoring_overdue": [
                {"model_id": m.model_id, "name": m.name, "tier": m.tier}
                for m in overdue_monitoring
            ],
            "average_compliance_score": (
                round(avg_score, 1) if avg_score is not None else None
            ),
            "models": [m.to_dict() for m in models],
        }

    def revalidation_needed(self) -> List[Dict[str, Any]]:
        """Identify models that need revalidation.

        Returns a list of models flagged for revalidation, including:
        - Models with overdue validation dates
        - Models with failed monitoring checks
        - Models with monitoring showing drift

        This is the "one-click" check a CRO runs to see what needs
        immediate attention.

        Returns:
            List of dicts with model info and revalidation reasons.
        """
        flagged: List[Dict[str, Any]] = []

        for model in self.active_models:
            reasons: List[str] = []

            if model.validation_overdue:
                reasons.append("Validation overdue per SR 11-7 schedule")

            if model.monitoring_overdue and model.is_production:
                reasons.append(
                    f"Monitoring overdue (required every "
                    f"{model.monitoring_frequency_days} days)"
                )

            latest = model.latest_monitoring
            if latest and not latest.passed:
                reasons.append(
                    f"Latest monitoring check FAILED: {latest.monitor_type}"
                )
                if latest.alerts:
                    reasons.append(
                        f"Monitoring alerts: {', '.join(latest.alerts[:3])}"
                    )

            if model.compliance_score is not None and model.compliance_score < 60:
                reasons.append(
                    f"Compliance score below threshold: "
                    f"{model.compliance_score:.0f}/100"
                )

            if reasons:
                flagged.append({
                    "model_id": model.model_id,
                    "name": model.name,
                    "tier": model.tier,
                    "domain": model.domain,
                    "status": model.status,
                    "reasons": reasons,
                    "last_validated": (
                        model.last_validation_date.isoformat()
                        if model.last_validation_date else None
                    ),
                    "priority": "urgent" if model.tier == 1 else (
                        "high" if model.tier == 2 else "normal"
                    ),
                })

        # Sort by tier (lower = higher priority), then by number of reasons
        flagged.sort(key=lambda f: (f["tier"], -len(f["reasons"])))
        return flagged

    def trigger_revalidation(
        self,
        model_id: str,
        requested_by: str = "",
        reason: str = "",
    ) -> Dict[str, Any]:
        """Trigger a revalidation workflow for a model.

        Updates the model status to UNDER_REVIEW and records the
        revalidation trigger in the change history.

        Args:
            model_id: ID of the model to revalidate.
            requested_by: Who requested the revalidation.
            reason: Reason for revalidation.

        Returns:
            Dict with revalidation details.

        Raises:
            KeyError: If model not found.
        """
        model = self._models.get(model_id)
        if model is None:
            raise KeyError(f"Model {model_id} not found in registry")

        old_status = model.status
        model.status = "under_review"
        model.updated_at = datetime.now(timezone.utc)
        model.change_history.append({
            "date": datetime.now(timezone.utc).isoformat(),
            "action": "revalidation_triggered",
            "details": (
                f"Revalidation triggered by {requested_by or 'system'}. "
                f"Reason: {reason or 'scheduled'}. "
                f"Previous status: {old_status}."
            ),
        })

        return {
            "model_id": model_id,
            "name": model.name,
            "previous_status": old_status,
            "new_status": "under_review",
            "triggered_by": requested_by or "system",
            "reason": reason or "scheduled",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    def risk_summary(self) -> Dict[str, Any]:
        """Generate a risk-focused summary for board reporting."""
        active = self.active_models
        production = self.production_models

        high_risk = [m for m in production if m.tier == 1]
        failing_monitoring = [
            m for m in production
            if m.latest_monitoring and not m.latest_monitoring.passed
        ]
        low_scores = [
            m for m in active
            if m.compliance_score is not None and m.compliance_score < 60
        ]

        return {
            "total_production_models": len(production),
            "tier_1_models": len(high_risk),
            "validation_overdue_count": len(self.validation_overdue),
            "monitoring_overdue_count": len(self.monitoring_overdue),
            "failing_monitoring_count": len(failing_monitoring),
            "low_compliance_score_count": len(low_scores),
            "risk_items": (
                [
                    f"{len(self.validation_overdue)} model(s) overdue for validation"
                    for _ in [1] if self.validation_overdue
                ]
                + [
                    f"{len(self.monitoring_overdue)} model(s) overdue for monitoring"
                    for _ in [1] if self.monitoring_overdue
                ]
                + [
                    f"{len(failing_monitoring)} model(s) failing monitoring checks"
                    for _ in [1] if failing_monitoring
                ]
                + [
                    f"{len(low_scores)} model(s) with compliance score below 60"
                    for _ in [1] if low_scores
                ]
            ),
        }
