# Copyright (C) 2025 Twist Innovation
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
#
# See the GNU General Public License for more details:
# https://www.gnu.org/licenses/gpl-3.0.html

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .TwistAPI import TwistAPI


class TwistScene:
    def __init__(self, key: str, name: str, link_id: int, status: int, api: TwistAPI):
        self.key = key
        self.name = name
        self.link_id = link_id
        self.status = status
        self.api = api

    async def activate(self):
        await self.api.activate_scene(self)
