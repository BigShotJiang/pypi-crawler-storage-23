"""commune credits — credit balance and bundle management."""

from __future__ import annotations

import typer

from ..client import CommuneClient
from ..errors import api_error, auth_required_error, network_error
from ..output import print_list, print_record
from ..state import AppState

app = typer.Typer(help="Credit balance and available bundles.", no_args_is_help=True)


@app.command("balance")
def credits_balance(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Get current credit balance. GET /v1/credits."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get("/v1/credits")
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_record(r.json(), json_output=json_output or state.should_json(), title="Credit Balance")


@app.command("bundles")
def credits_bundles(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """List available credit bundles. GET /v1/credits/bundles."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get("/v1/credits/bundles")
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_list(
        r.json(),
        json_output=json_output or state.should_json(),
        title="Credit Bundles",
        columns=[
            ("ID", "id"),
            ("Credits", "credits"),
            ("Price", "price"),
            ("Description", "description"),
        ],
    )
