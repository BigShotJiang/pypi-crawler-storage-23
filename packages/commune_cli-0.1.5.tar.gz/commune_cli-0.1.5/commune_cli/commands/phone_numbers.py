"""commune phone-numbers — phone number management."""

from __future__ import annotations

from typing import Optional

import typer

from ..client import CommuneClient
from ..errors import api_error, auth_required_error, network_error
from ..output import print_list, print_record
from ..state import AppState

app = typer.Typer(help="Phone number management: list, get, settings.", no_args_is_help=True)


@app.command("list")
def phone_numbers_list(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """List all phone numbers in your organization. GET /v1/phone-numbers."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get("/v1/phone-numbers")
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_list(
        r.json(),
        json_output=json_output or state.should_json(),
        title="Phone Numbers",
        columns=[
            ("ID", "id"),
            ("Number", "phoneNumber"),
            ("Friendly Name", "friendlyName"),
            ("Status", "status"),
            ("Created", "createdAt"),
        ],
    )


@app.command("get")
def phone_numbers_get(
    ctx: typer.Context,
    phone_number_id: str = typer.Argument(..., help="Phone number ID."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Get a specific phone number. GET /v1/phone-numbers/{phoneNumberId}."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get(f"/v1/phone-numbers/{phone_number_id}")
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_record(r.json(), json_output=json_output or state.should_json(), title="Phone Number")


@app.command("settings")
def phone_numbers_settings(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Get SMS quota settings for your organization. GET /v1/phone-settings."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get("/v1/phone-settings")
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_record(r.json(), json_output=json_output or state.should_json(), title="SMS Settings")
