"""commune sms — send SMS and manage conversations."""

from __future__ import annotations

from typing import Optional
from urllib.parse import quote

import typer

from ..client import CommuneClient
from ..errors import api_error, auth_required_error, network_error, validation_error
from ..output import print_json, print_list, print_record, print_success
from ..state import AppState

app = typer.Typer(help="Send SMS and manage conversations.", no_args_is_help=True)


@app.command("send")
def sms_send(
    ctx: typer.Context,
    to: str = typer.Option(..., "--to", help="Recipient phone number in E.164 format (e.g. +1234567890)."),
    body: str = typer.Option(..., "--body", help="SMS message body."),
    phone_number_id: Optional[str] = typer.Option(
        None,
        "--phone-number-id",
        help="Phone number ID to send from. Uses org default if omitted.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Send an SMS message. POST /v1/sms/send."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    payload: dict = {"to": to, "body": body}
    if phone_number_id:
        payload["phone_number_id"] = phone_number_id

    client = CommuneClient.from_state(state)
    try:
        r = client.post("/v1/sms/send", json=payload)
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    data = r.json()
    if json_output or state.should_json():
        print_json(data)
        return

    msg_id = data.get("id") or data.get("messageId", "")
    print_success(f"SMS sent. ID: [bold]{msg_id}[/bold]")


@app.command("conversations")
def sms_conversations(
    ctx: typer.Context,
    phone_number_id: Optional[str] = typer.Option(
        None,
        "--phone-number-id",
        help="Filter by phone number ID.",
    ),
    limit: Optional[int] = typer.Option(20, "--limit", help="Maximum results to return."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """List SMS conversations. GET /v1/sms/conversations."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get("/v1/sms/conversations", params={
            "phone_number_id": phone_number_id,
            "limit": limit,
        })
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_list(
        r.json(),
        json_output=json_output or state.should_json(),
        title="SMS Conversations",
        columns=[
            ("Remote Number", "remoteNumber"),
            ("Last Message", "lastMessage"),
            ("Direction", "lastDirection"),
            ("Updated", "updatedAt"),
        ],
    )


@app.command("thread")
def sms_thread(
    ctx: typer.Context,
    remote_number: str = typer.Argument(..., help="Remote phone number (E.164, e.g. +1234567890)."),
    phone_number_id: str = typer.Option(
        ...,
        "--phone-number-id",
        help="Phone number ID for the conversation.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Get the message thread with a specific number. GET /v1/sms/conversations/{remoteNumber}."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    encoded = quote(remote_number, safe="")
    client = CommuneClient.from_state(state)
    try:
        r = client.get(
            f"/v1/sms/conversations/{encoded}",
            params={"phone_number_id": phone_number_id},
        )
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    data = r.json()
    if json_output or state.should_json():
        print_json(data)
        return

    messages = data if isinstance(data, list) else data.get("data", data)
    print_list(
        messages,
        json_output=False,
        title=f"Thread with {remote_number}",
        columns=[
            ("ID", "id"),
            ("Direction", "direction"),
            ("Body", "body"),
            ("Sent At", "createdAt"),
        ],
    )


@app.command("search")
def sms_search(
    ctx: typer.Context,
    query: str = typer.Argument(..., help="Search query."),
    phone_number_id: Optional[str] = typer.Option(
        None,
        "--phone-number-id",
        help="Scope search to a specific phone number.",
    ),
    limit: Optional[int] = typer.Option(20, "--limit", help="Maximum results to return."),
    json_output: bool = typer.Option(False, "--json", help="Output JSON."),
) -> None:
    """Search SMS messages. GET /v1/sms/search."""
    state: AppState = ctx.obj or AppState()
    if not state.has_any_auth():
        auth_required_error(json_output=json_output or state.should_json())

    client = CommuneClient.from_state(state)
    try:
        r = client.get("/v1/sms/search", params={
            "q": query,
            "phone_number_id": phone_number_id,
            "limit": limit,
        })
    except Exception as exc:
        network_error(exc, json_output=json_output or state.should_json())

    if not r.is_success:
        api_error(r, json_output=json_output or state.should_json())

    print_list(
        r.json(),
        json_output=json_output or state.should_json(),
        title=f"SMS Search: {query}",
        columns=[
            ("ID", "id"),
            ("From", "from"),
            ("To", "to"),
            ("Body", "body"),
            ("Date", "createdAt"),
        ],
    )
