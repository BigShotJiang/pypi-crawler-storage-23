"""Compatibility utilities for optional dependency checking."""


def require_extra(module: str, package: str, extra: str) -> None:
    """Check that an optional dependency is installed.

    Call this at the top of a module's ``__init__.py`` to fail fast when
    the required extras group has not been installed.

    Parameters
    ----------
    module : str
        The pycarta subpackage name (e.g. ``"mqtt"``).
    package : str
        The pip package to probe via import (e.g. ``"aiomqtt"``).
    extra : str
        The extras group name (e.g. ``"mqtt"``).

    Raises
    ------
    ImportError
        If *package* cannot be imported.
    """
    try:
        __import__(package)
    except ImportError:
        raise ImportError(
            f"pycarta.{module} requires '{package}'. "
            f"Install it with: pip install pycarta[{extra}]"
        ) from None
