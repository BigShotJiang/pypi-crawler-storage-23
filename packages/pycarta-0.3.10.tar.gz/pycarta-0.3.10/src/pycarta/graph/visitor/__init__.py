from pycarta.graph.visitor.base import Aggregator, Propagator
