
CARTA_FS_SERVICE_PATH = 'service/carta/fs'

