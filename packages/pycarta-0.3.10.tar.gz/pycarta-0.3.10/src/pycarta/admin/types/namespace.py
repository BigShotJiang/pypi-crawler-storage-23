from .document_history import TrackedItem


class Namespace(TrackedItem):
    name: str

