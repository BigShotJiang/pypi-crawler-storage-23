from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field

from .item import Item
from .user import User


class DocumentHistory(BaseModel):
    addedBy: User | None = Field(default=None)
    dateAdded: datetime | None = Field(default=None)
    dateModified: datetime | None = Field(default=None)
    modifiedBy: User | None = Field(default=None)


class TrackedItem(Item):
    document_history: DocumentHistory | None = Field(alias='documentHistory', default=None)
