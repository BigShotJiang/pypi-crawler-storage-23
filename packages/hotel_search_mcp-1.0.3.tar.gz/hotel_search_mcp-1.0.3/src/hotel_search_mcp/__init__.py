"""酒店搜索 MCP 服务"""

__version__ = "1.0.3"
__author__ = "Your Name"

from .server import main

__all__ = ["main"]
