#!/usr/bin/env python3
"""
酒店搜索 MCP Server
支持 stdio 和 SSE 两种模式
"""

import asyncio
import json
import re
import sys
import os
from typing import List, Dict, Optional, Any
from datetime import datetime
import httpx
from urllib.parse import quote

# MCP 相关导入
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# SSE 相关导入（可选）
try:
    from starlette.applications import Starlette
    from starlette.requests import Request
    from starlette.responses import Response
    from starlette.routing import Route
    from sse_starlette.sse import EventSourceResponse
    import uvicorn
    SSE_AVAILABLE = True
except ImportError:
    SSE_AVAILABLE = False


class HotelSearcher:
    """酒店搜索核心功能"""

    def __init__(self, amap_key: str):
        self.amap_key = amap_key
        self.amap_base_url = "https://restapi.amap.com/v3"

    def _extract_amap_type(self, hotel: Dict) -> str:
        """提取高德酒店类型"""
        if 'type' in hotel and hotel['type']:
            type_str = hotel['type']
            parts = type_str.split(';')
            if len(parts) >= 3:
                return parts[2]
            elif len(parts) >= 2:
                return parts[1]

        if 'typecode' in hotel:
            typecode = hotel['typecode']
            type_mapping = {
                '100100': '宾馆酒店',
                '100101': '星级酒店',
                '100102': '快捷酒店',
                '100103': '公寓式酒店',
                '100104': '经济型酒店',
                '100105': '青年旅舍',
                '100106': '招待所',
                '100107': '客栈',
                '100108': '度假村',
                '100109': '民宿'
            }
            if typecode in type_mapping:
                return type_mapping[typecode]

        name = hotel.get('name', '')
        if '星级' in name or '五星' in name or '四星' in name:
            return '星级酒店'
        elif '快捷' in name or '连锁' in name:
            return '快捷酒店'
        elif '公寓' in name:
            return '公寓式酒店'
        elif '青旅' in name or '青年' in name:
            return '青年旅舍'
        elif '民宿' in name:
            return '民宿'
        elif '客栈' in name:
            return '客栈'
        elif '度假' in name or '温泉' in name:
            return '度假酒店'

        return '宾馆酒店'

    async def geocode_amap(self, address: str, city: str = None) -> Optional[str]:
        """高德地图地理编码"""
        url = f"{self.amap_base_url}/geocode/geo"
        params = {'key': self.amap_key, 'address': address}
        if city:
            params['city'] = city

        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.get(url, params=params)
                result = response.json()
                if result['status'] == '1' and result['geocodes']:
                    return result['geocodes'][0]['location']
        except Exception as e:
            print(f"地址解析异常: {str(e)}", file=sys.stderr)
        return None

    async def search_nearby_hotels_amap(self, location: str, radius: int = 10000) -> List[Dict]:
        """搜索周边酒店"""
        url = f"{self.amap_base_url}/place/around"
        all_hotels = []

        async with httpx.AsyncClient(timeout=10) as client:
            for page in range(1, 4):
                params = {
                    'key': self.amap_key, 'location': location,
                    'keywords': '酒店', 'types': '100100',
                    'radius': radius, 'offset': 25, 'page': page,
                    'extensions': 'all', 'sortrule': 'distance'
                }

                try:
                    response = await client.get(url, params=params)
                    result = response.json()

                    if result['status'] == '1' and 'pois' in result and result['pois']:
                        hotels = result['pois']
                        filtered = [h for h in hotels if self._check_rating(h) >= 4.5]
                        all_hotels.extend(filtered)
                    else:
                        break
                except:
                    break

        return all_hotels

    def _check_rating(self, hotel: Dict) -> float:
        """检查评分"""
        if 'biz_ext' in hotel and hotel['biz_ext']:
            rating_str = hotel['biz_ext'].get('rating', '')
            if rating_str:
                try:
                    match = re.search(r'(\d+\.?\d*)', rating_str)
                    if match:
                        return float(match.group(1))
                except:
                    pass
        return 0.0

    async def get_baidu_hotel_info(self, hotel_name: str, city: str) -> Dict:
        """获取百度酒店信息"""
        result = {'价格': '暂无', '评分': '暂无', '评论数': '暂无', '类型': '暂无'}

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Referer': 'https://map.baidu.com/'
        }

        try:
            search_url = f"https://map.baidu.com/?qt=s&wd={quote(city + hotel_name)}&ie=utf-8&oue=1&fromproduct=jsapi&res=api"

            async with httpx.AsyncClient(timeout=10, headers=headers) as client:
                response = await client.get(search_url)
                html = response.text

                try:
                    if html.strip().startswith('{'):
                        data = json.loads(html)
                        if 'content' in data and data['content']:
                            poi = data['content'][0]
                            if 'ext' in poi and 'detail_info' in poi['ext']:
                                info = poi['ext']['detail_info']

                                for field in ['price', 'pc_realtime_price', 'wise_realtime_price']:
                                    if field in info and info[field]:
                                        result['价格'] = f"¥{info[field]}"
                                        break

                                if 'overall_rating' in info:
                                    result['评分'] = str(info['overall_rating'])
                                if 'comment_num' in info:
                                    result['评论数'] = f"{info['comment_num']}条"
                                if 'category' in info:
                                    result['类型'] = info['category']
                except:
                    pass
        except:
            pass

        return result

    async def search_hotels(
            self, city: str, address: str,
            min_price: Optional[int] = None, max_price: Optional[int] = None,
            radius: int = 10000, max_results: int = 20
    ) -> Dict:
        """主搜索功能"""

        location = await self.geocode_amap(f"{city}{address}", city)
        if not location:
            return {"success": False, "error": "无法获取地址坐标"}

        hotels = await self.search_nearby_hotels_amap(location, radius)
        if not hotels:
            return {"success": False, "error": "未找到附近的酒店"}

        # 获取百度信息
        for hotel in hotels:
            baidu_info = await self.get_baidu_hotel_info(hotel.get('name', ''), city)
            amap_type = self._extract_amap_type(hotel)

            hotel.update({
                '_baidu_price': baidu_info['价格'],
                '_baidu_rating': baidu_info['评分'],
                '_baidu_comments': baidu_info['评论数'],
                '_baidu_type': baidu_info['类型'],
                '_amap_type': amap_type
            })
            await asyncio.sleep(0.5)

        # 价格筛选
        if min_price or max_price:
            filtered = []
            for hotel in hotels:
                price_str = hotel.get('_baidu_price', '暂无')
                if price_str != '暂无':
                    try:
                        price = int(re.search(r'(\d+)', price_str).group(1))
                        if (not min_price or price >= min_price) and (not max_price or price <= max_price):
                            filtered.append(hotel)
                    except:
                        filtered.append(hotel)
                else:
                    filtered.append(hotel)
            hotels = filtered

        # 排序并构建结果
        hotels.sort(key=lambda x: int(x.get('distance', '999999')))

        result_hotels = []
        for hotel in hotels[:max_results]:
            dist = int(hotel.get('distance', '0'))
            dist_str = f"{dist}米" if dist < 1000 else f"{dist / 1000:.1f}公里"

            result_hotels.append({
                "名称": hotel.get('name', ''),
                "地址": hotel.get('address', ''),
                "距离": dist_str,
                "电话": hotel.get('tel', ''),
                "高德评分": str(self._check_rating(hotel)),
                "百度评分": hotel.get('_baidu_rating', '暂无'),
                "参考价格": hotel.get('_baidu_price', '暂无'),
                "评论数": hotel.get('_baidu_comments', '暂无'),
                "高德类型": hotel.get('_amap_type', '暂无'),
                "百度类型": hotel.get('_baidu_type', '暂无'),
                "坐标": hotel.get('location', '')
            })

        return {
            "success": True,
            "搜索时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "城市": city, "地址": address,
            "总数量": len(hotels),
            "返回数量": len(result_hotels),
            "酒店列表": result_hotels
        }


class MCPHotelServer:
    """MCP 酒店搜索服务器"""

    def __init__(self, amap_key: str):
        self.searcher = HotelSearcher(amap_key)
        self.server = Server("hotel-search-mcp")
        self._setup_handlers()

    def _setup_handlers(self):
        @self.server.list_tools()
        async def list_tools() -> list[Tool]:
            return [
                Tool(
                    name="search_hotels",
                    description="搜索周边酒店，获取价格、评分、类型等信息。支持按价格筛选，自动按距离排序。",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "city": {"type": "string", "description": "城市名称，如：杭州、上海"},
                            "address": {"type": "string", "description": "具体地址或地标，如：西湖、外滩"},
                            "min_price": {"type": "integer", "description": "最低价格（元/晚）"},
                            "max_price": {"type": "integer", "description": "最高价格（元/晚）"},
                            "radius": {"type": "integer", "default": 10000, "description": "搜索半径（米）"},
                            "max_results": {"type": "integer", "default": 20, "description": "返回结果数量"}
                        },
                        "required": ["city", "address"]
                    }
                )
            ]

        @self.server.call_tool()
        async def call_tool(name: str, arguments: dict) -> list[TextContent]:
            if name == "search_hotels":
                result = await self.searcher.search_hotels(**arguments)
                return [TextContent(
                    type="text",
                    text=json.dumps(result, ensure_ascii=False, indent=2)
                )]
            raise ValueError(f"Unknown tool: {name}")

    async def run_stdio(self):
        """运行 stdio 模式（用于 uvx/uv tool run）"""
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                self.server.create_initialization_options()
            )

    def create_sse_app(self):
        """创建 SSE Web 应用"""
        if not SSE_AVAILABLE:
            raise ImportError("SSE 模式需要安装: pip install starlette uvicorn sse-starlette")

        async def handle_sse(request: Request):
            """处理 SSE 连接"""
            async def event_generator():
                session_id = str(id(request))
                yield {
                    "event": "endpoint",
                    "data": json.dumps({"endpoint": f"/messages?session={session_id}"})
                }
                while True:
                    await asyncio.sleep(30)
                    yield {"event": "ping", "data": ""}

            return EventSourceResponse(event_generator())

        async def handle_messages(request: Request):
            """处理消息"""
            try:
                body = await request.json()
                method = body.get("method")
                params = body.get("params", {})
                msg_id = body.get("id")

                response_data = None

                if method == "initialize":
                    response_data = {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "hotel-search-mcp", "version": "1.0.3"}
                    }

                elif method == "tools/list":
                    tools_result = await self.server._tool_manager.list_tools()
                    response_data = {
                        "tools": [
                            {
                                "name": t.name,
                                "description": t.description,
                                "inputSchema": t.inputSchema
                            } for t in tools_result.tools
                        ]
                    }

                elif method == "tools/call":
                    tool_name = params.get("name")
                    arguments = params.get("arguments", {})
                    result = await self.searcher.search_hotels(**arguments)
                    response_data = {
                        "content": [
                            {
                                "type": "text",
                                "text": json.dumps(result, ensure_ascii=False)
                            }
                        ]
                    }

                return Response(
                    content=json.dumps({
                        "jsonrpc": "2.0",
                        "id": msg_id,
                        "result": response_data
                    }),
                    media_type="application/json"
                )

            except Exception as e:
                return Response(
                    content=json.dumps({
                        "jsonrpc": "2.0",
                        "id": body.get("id") if 'body' in locals() else None,
                        "error": {"code": -32603, "message": str(e)}
                    }),
                    media_type="application/json",
                    status_code=500
                )

        app = Starlette(
            routes=[
                Route("/sse", endpoint=handle_sse, methods=["GET"]),
                Route("/messages", endpoint=handle_messages, methods=["POST"]),
            ]
        )

        return app

def main():

    """命令行入口"""

    import argparse

    parser = argparse.ArgumentParser(description="酒店搜索 MCP Server")

    parser.add_argument(

        "--mode",

        choices=["stdio", "sse"],

        default="stdio",

        help="运行模式：stdio（标准输入输出）或 sse（HTTP服务器）"

    )

    parser.add_argument(

        "--host",

        default="0.0.0.0",

        help="SSE 模式的监听地址（默认：0.0.0.0）"

    )

    parser.add_argument(

        "--port",

        type=int,

        default=8000,

        help="SSE 模式的监听端口（默认：8000）"

    )

    parser.add_argument(

        "--amap-key",

        default=None,

        help="高德地图 API Key（也可通过环境变量 AMAP_API_KEY 设置）"

    )

    args = parser.parse_args()

    # 获取 API Key

    amap_key = args.amap_key or os.environ.get("AMAP_API_KEY")

    if not amap_key:
        print("错误：未设置高德地图 API Key", file=sys.stderr)

        print("请通过 --amap-key 参数或 AMAP_API_KEY 环境变量设置", file=sys.stderr)

        sys.exit(1)

    server = MCPHotelServer(amap_key)

    if args.mode == "stdio":

        # Stdio 模式（用于 Cursor、Claude Desktop 等）
        # 注意：不要输出到 stderr，某些客户端可能会认为这是错误
        # print("🚀 启动 Stdio 模式 MCP Server...", file=sys.stderr)

        asyncio.run(server.run_stdio())


    elif args.mode == "sse":

        # SSE 模式（用于 Web 集成、百炼平台等）

        print("=" * 80, file=sys.stderr)

        print("🚀 酒店搜索 MCP Server 启动 (SSE 模式)", file=sys.stderr)

        print("=" * 80, file=sys.stderr)

        print(f"📡 SSE 端点: http://{args.host}:{args.port}/sse", file=sys.stderr)

        print(f"📨 消息端点: http://{args.host}:{args.port}/messages", file=sys.stderr)

        print("=" * 80, file=sys.stderr)

        try:

            app = server.create_sse_app()

            uvicorn.run(app, host=args.host, port=args.port)

        except ImportError as e:

            print(f"错误：{e}", file=sys.stderr)

            print("请安装 SSE 依赖：pip install starlette uvicorn sse-starlette", file=sys.stderr)

            sys.exit(1)

if __name__ == "__main__":
    main()

