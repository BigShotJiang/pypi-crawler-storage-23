"""Schema derivation tests."""

from __future__ import annotations

from sqlmodel import SQLModel
from tests.conftest import Book

from auen import derive_schemas
from auen.config import NestedRelationConfig, NestedWriteConfig


class NoPkModel(SQLModel):
    """Model without table=True — PK detection fallback."""

    name: str


class NestedRelatedModel(SQLModel):
    label: str


def test_derive_schemas_with_include() -> None:
    schemas = derive_schemas(Book, include={"title", "isbn", "id"})
    assert "pages" not in schemas.create.model_fields


def test_derive_schemas_with_exclude() -> None:
    schemas = derive_schemas(Book, exclude={"pages"})
    assert "pages" not in schemas.create.model_fields


def test_derive_schemas_pk_fallback() -> None:
    schemas = derive_schemas(NoPkModel)
    assert "name" in schemas.create.model_fields


def test_derive_schemas_with_nested_writes() -> None:
    schemas = derive_schemas(
        Book,
        nested_writes=NestedWriteConfig(
            fields={"author": NestedRelationConfig(model=NestedRelatedModel)}
        ),
    )
    assert "author" in schemas.create.model_fields
    assert "author" in schemas.update.model_fields
    assert "author" in schemas.read.model_fields
