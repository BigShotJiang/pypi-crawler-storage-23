"""Pagination and filter tests."""

from __future__ import annotations

from httpx import AsyncClient


async def test_default_limit_applied(pagination_client: AsyncClient) -> None:
    """Default limit from PaginationConfig is applied."""
    for i in range(5):
        await pagination_client.post(
            "/books/",
            json={"title": f"Book {i}", "isbn": f"ISBN-{i}"},
        )

    resp = await pagination_client.get("/books/")
    assert resp.status_code == 200
    # default_limit=2
    assert len(resp.json()) == 2


async def test_max_limit_enforced(pagination_client: AsyncClient) -> None:
    """Requesting more than max_limit is rejected (422)."""
    resp = await pagination_client.get("/books/?limit=100")
    assert resp.status_code == 422


async def test_offset_pagination(pagination_client: AsyncClient) -> None:
    """Offset works correctly."""
    for i in range(4):
        await pagination_client.post(
            "/books/",
            json={
                "title": f"PagBook {i}",
                "isbn": f"PAG-{i}",
            },
        )

    resp = await pagination_client.get("/books/?offset=2&limit=2")
    assert resp.status_code == 200
    books = resp.json()
    assert len(books) <= 2


async def test_sorting(pagination_client: AsyncClient) -> None:
    """Sorting on allowlisted field works."""
    await pagination_client.post(
        "/books/",
        json={"title": "You Don't Know JS", "isbn": "978-1491924464"},
    )
    await pagination_client.post(
        "/books/",
        json={"title": "Algorithms", "isbn": "978-0321573513"},
    )

    resp = await pagination_client.get("/books/?sort=title&limit=5")
    assert resp.status_code == 200
    books = resp.json()
    titles = [b["title"] for b in books]
    assert titles == sorted(titles)


async def test_sorting_disallowed_field(pagination_client: AsyncClient) -> None:
    """Sorting on non-allowlisted field returns 422."""
    resp = await pagination_client.get("/books/?sort=isbn")
    assert resp.status_code == 422


async def test_filter_eq(pagination_client: AsyncClient) -> None:
    """Filtering by eq works."""
    await pagination_client.post(
        "/books/",
        json={"title": "Algorithms", "isbn": "978-0321573513"},
    )
    await pagination_client.post(
        "/books/",
        json={"title": "Clean Code", "isbn": "978-0132350884"},
    )

    resp = await pagination_client.get("/books/?title=Algorithms")
    assert resp.status_code == 200
    books = resp.json()
    assert len(books) == 1
    assert books[0]["title"] == "Algorithms"


async def test_page_style_pagination(page_pagination_client: AsyncClient) -> None:
    """Page-style pagination uses page/size."""
    for title in ["A", "B", "C", "D"]:
        await page_pagination_client.post(
            "/books/",
            json={"title": title, "isbn": f"ISBN-{title}"},
        )

    resp = await page_pagination_client.get("/books/?page=2&size=2&sort=title")
    assert resp.status_code == 200
    titles = [b["title"] for b in resp.json()]
    assert titles == ["C", "D"]
