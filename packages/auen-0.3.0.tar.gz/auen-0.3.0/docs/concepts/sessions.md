# Session Dependency

Auen does **not** create database engines or manage connections. You provide a FastAPI dependency that yields a SQLModel `AsyncSession`.

## Canonical pattern

```python
from sqlalchemy.ext.asyncio import create_async_engine
from sqlmodel.ext.asyncio.session import AsyncSession

async_engine = create_async_engine("sqlite+aiosqlite:///app.db")

async def get_session() -> AsyncSession:
    async with AsyncSession(async_engine) as session:
        yield session
```

Pass `get_session` as `session_dep` to `CrudRouterBuilder`. Auen injects it via `Depends()`.

## Dependency caching

FastAPI caches dependencies per-request. If your auth dependency also needs a session, both will receive the same `AsyncSession` instance when using the same dependency callable.
