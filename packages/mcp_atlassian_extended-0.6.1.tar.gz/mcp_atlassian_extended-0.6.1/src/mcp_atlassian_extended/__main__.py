"""Allow running with `python -m mcp_atlassian_extended`."""

from mcp_atlassian_extended import main

main()
