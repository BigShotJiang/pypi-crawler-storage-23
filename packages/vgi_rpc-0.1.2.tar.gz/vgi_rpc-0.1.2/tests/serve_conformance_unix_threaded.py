# © Copyright 2025-2026, Query.Farm LLC - https://query.farm
# SPDX-License-Identifier: Apache-2.0

"""Threaded Unix socket server entry point for conformance tests.

Can be run directly: ``python tests/serve_conformance_unix_threaded.py /path/to/socket``

Imports the conformance service Protocol and implementation, then serves
RPC requests over a threaded Unix domain socket.
"""

import sys

from vgi_rpc.conformance import ConformanceService, ConformanceServiceImpl
from vgi_rpc.rpc import RpcServer, serve_unix


def main() -> None:
    """Serve the conformance service over a threaded Unix domain socket."""
    path = sys.argv[1]
    server = RpcServer(ConformanceService, ConformanceServiceImpl())
    print(f"UNIX:{path}", flush=True)
    serve_unix(server, path, threaded=True)


if __name__ == "__main__":
    main()
