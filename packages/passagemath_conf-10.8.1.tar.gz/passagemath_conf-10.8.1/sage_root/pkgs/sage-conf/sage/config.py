from _sage_conf._conf import *
from _sage_conf.__main__ import _main


if __name__ == "__main__":
    _main()
