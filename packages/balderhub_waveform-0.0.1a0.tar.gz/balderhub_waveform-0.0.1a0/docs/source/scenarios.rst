Scenarios
*********

Scenarios describe **what you need**. They define the tests and the necessary devices for them. Here you can find all
scenarios that are implemented in this BalderHub package.


.. note::
    This BalderHub project doesn't have any scenarios.


.. todo add your scenarios with .. autoclass
    .. autoclass:: balderhub.waveform.scenarios.ScenarioMyTest
        :members:
