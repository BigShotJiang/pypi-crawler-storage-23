Examples
********

.. todo provide some examples

.. note::
    THIS SECTION IS STILL UNDER DEVELOPMENT
