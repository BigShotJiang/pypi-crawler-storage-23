Introduction into Waveform
**************************

.. todo provide an explanation of your specific topic that can help others to use your BalderHub project

.. note::
    THIS SECTION IS STILL UNDER DEVELOPMENT


This BalderHub project provides different working objects to write test that use waveforms.

The following BalderHub packages are using this package to interact with their test equipment devices:

+-----------------------+----------------------------------------------------------------------------------------------+
| Device Type           | BalderHub project                                                                            |
+=======================+==============================================================================================+
| Oscilloscopes         | `balderhub-waveformmonitor <https://hub.balder.dev/projects/waveformmonitor>`_               |
+-----------------------+----------------------------------------------------------------------------------------------+
| Function Generators   | `balderhub-waveformgenerator <https://hub.balder.dev/projects/waveformgenerator>`_           |
+-----------------------+----------------------------------------------------------------------------------------------+