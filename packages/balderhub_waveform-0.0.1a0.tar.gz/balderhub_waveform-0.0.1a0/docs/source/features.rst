Features
********


This section describes all features that are shipped with this package.


Scenario Features
=================

.. note::
    This package does not provide any scenario features

.. todo add your features with .. autoclass
    .. autoclass:: balderhub.waveform.lib.scenario_features.MyScenarioFeature
        :members:


Setup Features
==============

.. note::
    This package does not provide any setup features.

.. todo add your features with .. autoclass
    .. autoclass:: balderhub.waveform.lib.setup_features.MySetupFeature
        :members: