SHARED MEMORY (Cross-Agent Knowledge Base):
  synapse memory save <key> "<content>" [--tags tag1,tag2]  - Save knowledge
  synapse memory list [--author <id>]                       - List memories
  synapse memory search <query>                             - Search knowledge
  synapse memory show <key>                                 - View details
  synapse memory delete <key> [--force]                     - Delete memory
  synapse memory stats                                      - View statistics
