"""Command-line entry point for `python -m bnnr`."""

from __future__ import annotations

from bnnr.cli import main

if __name__ == "__main__":
    main()
