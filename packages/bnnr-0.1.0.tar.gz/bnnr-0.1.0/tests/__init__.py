"""Test package marker for BNNR test modules."""

