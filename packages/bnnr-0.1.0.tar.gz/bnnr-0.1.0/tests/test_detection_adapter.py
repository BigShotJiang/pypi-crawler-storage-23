"""Tests for bnnr.detection_adapter — DetectionAdapter lifecycle.

Covers init, train_step, eval_step, epoch_end_eval, epoch_end,
state_dict/load_state_dict, get_model, get_target_layers, and
the _targets_to_device helper.
"""

from __future__ import annotations

from typing import Any

import torch
from torch import Tensor, nn

from bnnr.detection_adapter import DetectionAdapter, _targets_to_device

# ---------------------------------------------------------------------------
# Helpers — tiny detection model that mimics the torchvision contract.
# ---------------------------------------------------------------------------


class _TinyDetectionModel(nn.Module):
    """Minimal detection model stub satisfying train/eval API."""

    def __init__(self) -> None:
        super().__init__()
        self.conv = nn.Conv2d(3, 8, 3, padding=1)
        self.fc = nn.Linear(8, 4)

    def forward(
        self,
        images: list[Tensor],
        targets: list[dict[str, Tensor]] | None = None,
    ) -> Any:
        if self.training and targets is not None:
            # Return loss dict (training mode)
            dummy_loss = torch.tensor(0.5, requires_grad=True)
            return {"loss_classifier": dummy_loss, "loss_box_reg": dummy_loss * 0.3}
        else:
            # Return predictions list (eval mode)
            preds = []
            for img in images:
                preds.append({
                    "boxes": torch.tensor([[10.0, 10.0, 50.0, 50.0]]),
                    "scores": torch.tensor([0.9]),
                    "labels": torch.tensor([1]),
                })
            return preds


def _make_batch(n: int = 2, img_size: int = 32) -> tuple[Tensor, list[dict[str, Tensor]]]:
    """Create a synthetic detection batch."""
    images = torch.randn(n, 3, img_size, img_size)
    targets = []
    for _ in range(n):
        targets.append({
            "boxes": torch.tensor([[5.0, 5.0, 25.0, 25.0]], dtype=torch.float32),
            "labels": torch.tensor([1], dtype=torch.int64),
        })
    return images, targets


# ---------------------------------------------------------------------------
# _targets_to_device
# ---------------------------------------------------------------------------


class TestTargetsToDevice:
    def test_moves_tensors(self):
        targets = [
            {"boxes": torch.zeros(1, 4), "labels": torch.zeros(1, dtype=torch.long)},
        ]
        result = _targets_to_device(targets, "cpu")
        assert result[0]["boxes"].device.type == "cpu"

    def test_preserves_non_tensors(self):
        targets = [{"boxes": torch.zeros(1, 4), "meta": "hello"}]
        result = _targets_to_device(targets, "cpu")
        assert result[0]["meta"] == "hello"

    def test_empty_list(self):
        result = _targets_to_device([], "cpu")
        assert result == []


# ---------------------------------------------------------------------------
# DetectionAdapter
# ---------------------------------------------------------------------------


class TestDetectionAdapterInit:
    def test_default_init(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        assert adapter.device == "cpu"
        assert adapter.use_amp is False
        assert adapter.score_threshold == 0.05
        assert len(adapter.target_layers) > 0

    def test_custom_target_layers(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(
            model=model, optimizer=opt, device="cpu",
            target_layers=[model.conv],
        )
        assert adapter.target_layers == [model.conv]

    def test_auto_target_layers(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        # Should auto-detect the Conv2d layer
        assert isinstance(adapter.target_layers[0], nn.Conv2d)

    def test_scheduler_stored(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        sched = torch.optim.lr_scheduler.StepLR(opt, step_size=1)
        adapter = DetectionAdapter(
            model=model, optimizer=opt, device="cpu",
            scheduler=sched,
        )
        assert adapter.scheduler is sched


class TestDetectionAdapterTrainStep:
    def test_train_step_returns_loss(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        images, targets = _make_batch(2)
        metrics = adapter.train_step((images, targets))
        assert "loss" in metrics
        assert isinstance(metrics["loss"], float)
        assert metrics["loss"] > 0

    def test_train_step_has_component_losses(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        images, targets = _make_batch(1)
        metrics = adapter.train_step((images, targets))
        # Should have loss_xxx keys from the model's loss dict
        loss_keys = [k for k in metrics if k.startswith("loss_")]
        assert len(loss_keys) >= 1


class TestDetectionAdapterEvalStep:
    def test_eval_step_accumulates_preds(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        images, targets = _make_batch(2)
        metrics = adapter.eval_step((images, targets))
        assert "loss" in metrics
        # Predictions should be accumulated
        assert len(adapter._eval_preds) == 2
        assert len(adapter._eval_targets) == 2

    def test_eval_step_filters_by_score(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(
            model=model, optimizer=opt, device="cpu",
            score_threshold=0.95,  # Higher than model's 0.9
        )
        images, targets = _make_batch(1)
        adapter.eval_step((images, targets))
        # All predictions should be filtered out since score=0.9 < threshold=0.95
        assert adapter._eval_preds[0]["boxes"].shape[0] == 0


class TestDetectionAdapterEpochEnd:
    def test_epoch_end_eval_computes_metrics(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        images, targets = _make_batch(2)
        adapter.eval_step((images, targets))
        metrics = adapter.epoch_end_eval()
        assert "map_50" in metrics
        assert "map_50_95" in metrics
        # Accumulators should be reset
        assert len(adapter._eval_preds) == 0
        assert len(adapter._eval_targets) == 0

    def test_epoch_end_eval_empty_returns_zeros(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        metrics = adapter.epoch_end_eval()
        assert metrics["map_50"] == 0.0
        assert metrics["map_50_95"] == 0.0

    def test_epoch_end_eval_snapshots_last_eval(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        images, targets = _make_batch(2)
        adapter.eval_step((images, targets))
        adapter.epoch_end_eval()
        # last_eval_preds/targets should be snapshot
        assert len(adapter.last_eval_preds) == 2
        assert len(adapter.last_eval_targets) == 2

    def test_epoch_end_steps_scheduler(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.1)
        sched = torch.optim.lr_scheduler.StepLR(opt, step_size=1, gamma=0.5)
        adapter = DetectionAdapter(
            model=model, optimizer=opt, device="cpu", scheduler=sched,
        )
        lr_before = opt.param_groups[0]["lr"]
        adapter.epoch_end()
        lr_after = opt.param_groups[0]["lr"]
        assert lr_after < lr_before

    def test_epoch_end_no_scheduler(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        adapter.epoch_end()  # Should not raise


class TestDetectionAdapterStateDict:
    def test_state_dict_contains_model_and_optimizer(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        state = adapter.state_dict()
        assert "model" in state
        assert "optimizer" in state

    def test_state_dict_contains_scheduler(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        sched = torch.optim.lr_scheduler.StepLR(opt, step_size=1)
        adapter = DetectionAdapter(
            model=model, optimizer=opt, device="cpu", scheduler=sched,
        )
        state = adapter.state_dict()
        assert "scheduler" in state

    def test_load_state_dict_roundtrip(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")

        # Do a train step to change weights
        images, targets = _make_batch(1)
        adapter.train_step((images, targets))

        state = adapter.state_dict()

        # Create new adapter and load state
        model2 = _TinyDetectionModel()
        opt2 = torch.optim.SGD(model2.parameters(), lr=0.01)
        adapter2 = DetectionAdapter(model=model2, optimizer=opt2, device="cpu")
        adapter2.load_state_dict(state)

        # Weights should match
        for (k1, v1), (k2, v2) in zip(
            adapter.model.state_dict().items(),
            adapter2.model.state_dict().items(),
        ):
            assert k1 == k2
            assert torch.allclose(v1, v2)


class TestDetectionAdapterProtocol:
    def test_get_model(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        assert adapter.get_model() is model

    def test_get_target_layers(self):
        model = _TinyDetectionModel()
        opt = torch.optim.SGD(model.parameters(), lr=0.01)
        adapter = DetectionAdapter(model=model, optimizer=opt, device="cpu")
        layers = adapter.get_target_layers()
        assert isinstance(layers, list)
        assert len(layers) > 0
