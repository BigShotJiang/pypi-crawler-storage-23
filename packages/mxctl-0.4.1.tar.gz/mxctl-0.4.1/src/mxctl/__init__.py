"""mxctl: Apple Mail from your terminal."""

__version__ = "0.3.0"
