"""Allow running as: python -m eu_ai_act_scanner"""
from eu_ai_act_scanner.cli import main

main()
