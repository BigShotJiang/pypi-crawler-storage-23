#!/bin/bash
# Detect available LLM backends

<?ono check for ollama, sglang, llama.cpp, vllm and return available ones as comma-separated list ?>

<?ono if ollama is available, check for models and return list of available models ?>

<?ono if no models found, return "no_models" ?>

<?ono if no backends found, return "no_backends" ?>
