"""
This module contains the tests for the Ono context manager.
"""

# TODO: Add tests for the Ono context manager