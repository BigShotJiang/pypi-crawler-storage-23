"""
This module contains the tests for the Ono parser.
"""

# TODO: Add tests for the Ono parser