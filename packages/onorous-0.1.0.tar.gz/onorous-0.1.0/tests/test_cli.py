"""
This module contains the tests for the Ono CLI.
"""

# TODO: Add tests for the Ono CLI