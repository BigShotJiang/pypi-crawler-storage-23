"""
This module contains the tests for the Ono metadata generator.
"""

# TODO: Add tests for the Ono metadata generator