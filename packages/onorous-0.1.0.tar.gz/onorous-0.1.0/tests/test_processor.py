"""
This module contains the tests for the Ono processor.
"""

# TODO: Add tests for the Ono processor