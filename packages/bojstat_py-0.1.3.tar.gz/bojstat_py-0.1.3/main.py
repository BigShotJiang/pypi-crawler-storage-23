def main():
    print("Hello from bojstat!")


if __name__ == "__main__":
    main()
