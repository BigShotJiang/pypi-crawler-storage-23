"""LoopMessage Beta API client."""

import asyncio
from typing import Any, Dict, List, Optional, Union
from urllib.parse import urljoin

import httpx
from pydantic import ValidationError

from ..exceptions import (
    AccountSuspendedError,
    AuthenticationError,
    DeliveryError,
    InsufficientCreditsError,
    InvalidParameterError,
    InvalidRecipientError,
    LoopMessageError,
    MessageNotFoundError,
    RateLimitError,
    SenderNameError,
)
from .enums import ChannelType, MessageEffect
from .models import (
    CampaignMessage,
    CreateCampaignResponse,
    MessageStatusResponse,
    OptInUrlResponse,
    SendMessageResponse,
    ShowTypingResponse,
    WebhookEvent,
)


class BetaLoopMessageClient:
    """Async client for the LoopMessage Beta API."""

    BASE_URL = "https://a.loopmessage.com/api/v1/"
    # Status endpoint uses a different base path (no /api/ prefix)
    STATUS_BASE_URL = "https://a.loopmessage.com/v1/"

    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        """
        Initialize the LoopMessage Beta client.

        Args:
            api_key: Your API key (Authorization header)
            base_url: Custom base URL for the API
            timeout: Request timeout in seconds
            max_retries: Maximum number of retries for failed requests
        """
        self.api_key = api_key
        self.base_url = base_url or self.BASE_URL
        self.timeout = timeout
        self.max_retries = max_retries

        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self) -> "BetaLoopMessageClient":
        """Async context manager entry."""
        await self._get_client()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.close()

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
                headers={
                    "Authorization": self.api_key,
                    "Content-Type": "application/json",
                },
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    def _handle_error_response(self, response_data: Dict[str, Any]) -> None:
        """Handle API error responses."""
        if not response_data.get("success", True):
            code = response_data.get("code", 0)
            message = response_data.get("message", "Unknown error")

            # Map error codes to specific exceptions
            if code in [110, 125]:
                raise AuthenticationError(message, code)
            elif code in [130]:
                raise AuthenticationError(message, code)
            elif code in [120, 140, 150, 570, 580, 590, 595, 600, 610, 620, 630, 640]:
                raise InvalidParameterError(message, code)
            elif code in [160, 170, 180, 190, 270, 280]:
                raise InvalidRecipientError(message, code)
            elif code in [210, 220, 230, 240, 540, 545, 550, 560]:
                raise SenderNameError(message, code)
            elif code in [400]:
                raise InsufficientCreditsError(message, code)
            elif code in [500, 510, 520, 530]:
                raise AccountSuspendedError(message, code)
            elif code in [1000, 1010, 1020, 1030, 1110, 1120, 1130, 1140]:
                raise DeliveryError(message, code)
            else:
                raise LoopMessageError(message, code)

    async def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        retries: int = 0,
        use_status_base: bool = False,
    ) -> Dict[str, Any]:
        """Make an HTTP request to the API."""
        client = await self._get_client()
        base = self.STATUS_BASE_URL if use_status_base else self.base_url
        url = urljoin(base, endpoint)

        try:
            if method.upper() == "GET":
                response = await client.get(url)
            elif method.upper() == "POST":
                response = await client.post(url, json=data)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            # Try to parse JSON response first
            try:
                response_data: Dict[str, Any] = response.json()
                # Handle API errors in JSON response (even if HTTP status is 4xx)
                if "success" in response_data and not response_data["success"]:
                    self._handle_error_response(response_data)

                # If we get here and status is bad, raise HTTP error
                response.raise_for_status()
                return response_data
            except ValueError:
                # No JSON response, just check HTTP status
                response.raise_for_status()
                return {}

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                raise MessageNotFoundError("Message not found", 404) from e
            elif e.response.status_code == 402:
                raise InsufficientCreditsError("Insufficient credits", 402) from e
            elif e.response.status_code == 401:
                raise AuthenticationError("Authentication failed", 401) from e
            else:
                try:
                    error_data = e.response.json()
                    self._handle_error_response(error_data)
                    raise LoopMessageError(
                        f"HTTP {e.response.status_code}: Unhandled error"
                    )
                except Exception:
                    raise LoopMessageError(
                        f"HTTP {e.response.status_code}: {e.response.text}"
                    ) from e

        except httpx.RequestError as e:
            if retries < self.max_retries:
                await asyncio.sleep(2**retries)  # Exponential backoff
                return await self._make_request(
                    method, endpoint, data, retries + 1, use_status_base
                )
            raise LoopMessageError(f"Request failed: {str(e)}") from e

    async def send_message(
        self,
        text: str,
        contact: Optional[str] = None,
        group: Optional[str] = None,
        subject: Optional[str] = None,
        sender: Optional[str] = None,
        attachments: Optional[List[str]] = None,
        effect: Optional[MessageEffect] = None,
        reply_to_id: Optional[str] = None,
        passthrough: Optional[str] = None,
        channel: Optional[ChannelType] = None,
        contact_file: Optional[bool] = None,
    ) -> SendMessageResponse:
        """
        Send a message to a contact or group.

        Args:
            text: Message text (max 10000 characters)
            contact: Phone number, email, or Contact ID (for individual messages)
            group: iMessage group ID (for group messages, from webhook)
            subject: Optional message subject (shown as bold title, iMessage only)
            sender: Optional sender name ID
            attachments: List of attachment URLs (max 3, HTTPS only, max 256 chars each)
            effect: Message effect (slam, loud, gentle, etc.; iMessage only)
            reply_to_id: Message ID to reply to (from webhook)
            passthrough: Metadata to store with message (max 1000 chars)
            channel: Override delivery channel (imessage, sms, rcs, whatsapp).
                     Only use when you need to force a specific channel;
                     leave unset to let the API choose automatically.
                     SMS does not support subject, effect, or reply_to_id.
            contact_file: If True, attaches a vCard (contact file) to the message.
                          Only use when explicitly sharing a contact card.

        Returns:
            SendMessageResponse: Response with message ID and details
        """
        if not contact and not group:
            raise InvalidParameterError("Either contact or group must be specified")

        if contact and group:
            raise InvalidParameterError("Cannot specify both contact and group")

        data: Dict[str, Any] = {
            "text": text,
        }

        if contact:
            data["contact"] = contact
        if group:
            data["group"] = group
        if subject:
            data["subject"] = subject
        if sender:
            data["sender"] = sender
        if attachments:
            data["attachments"] = attachments
        if effect:
            data["effect"] = effect.value
        if reply_to_id:
            data["reply_to_id"] = reply_to_id
        if passthrough:
            data["passthrough"] = passthrough
        if channel:
            data["channel"] = channel.value
        if contact_file is not None:
            data["contact_file"] = contact_file

        response_data = await self._make_request("POST", "message/send/", data)
        return SendMessageResponse(**response_data)

    async def send_audio_message(
        self,
        media_url: str,
        contact: Optional[str] = None,
        group: Optional[str] = None,
        sender: Optional[str] = None,
        passthrough: Optional[str] = None,
    ) -> SendMessageResponse:
        """
        Send an audio/voice message.

        Args:
            media_url: URL of the audio file (HTTPS, max 256 chars)
                      Supported formats: mp3, wav, m4a, caf, aac
            contact: Phone number or email (for individual messages)
            group: Group ID (for group messages)
            sender: Optional sender name ID
            passthrough: Metadata to store with the message (max 1000 chars)

        Returns:
            SendMessageResponse: Response with message ID and details

        Note:
            To send a voice message to an iMessage group, use the group parameter
            instead of contact.
        """
        if not contact and not group:
            raise InvalidParameterError("Either contact or group must be specified")

        if contact and group:
            raise InvalidParameterError("Cannot specify both contact and group")

        data: Dict[str, Any] = {
            "media_url": media_url,
        }

        if contact:
            data["contact"] = contact
        if group:
            data["group"] = group
        if sender:
            data["sender"] = sender
        if passthrough:
            data["passthrough"] = passthrough

        response_data = await self._make_request("POST", "message/send/", data)
        return SendMessageResponse(**response_data)

    async def add_reaction(
        self,
        contact: str,
        message_id: str,
        reaction: str,
    ) -> Dict[str, Any]:
        """
        Add a reaction (tapback) to a message.

        Args:
            contact: Phone number or Email
            message_id: The message_id from the webhook
            reaction: Reaction type - possible values:
                     love, like, dislike, laugh, emphasize, question
                     Can also use ReactionType enum (e.g., ReactionType.LOVE.value)

        Returns:
            Dict[str, Any]: API response

        Example:
            await client.add_reaction(
                contact="+1234567890",
                message_id="msg-123",
                reaction="love"
            )
        """
        if not contact:
            raise InvalidParameterError("Contact must be specified")
        if not message_id:
            raise InvalidParameterError("Message ID must be specified")
        if not reaction:
            raise InvalidParameterError("Reaction must be specified")

        data: Dict[str, Any] = {
            "contact": contact,
            "message_id": message_id,
            "reaction": reaction,
        }

        response_data = await self._make_request("POST", "message/send/", data)
        return response_data

    async def remove_reaction(
        self,
        contact: str,
        message_id: str,
        reaction: str,
    ) -> Dict[str, Any]:
        """
        Remove a reaction (tapback) from a message.

        Args:
            contact: Phone number or Email
            message_id: The message_id from the webhook
            reaction: Reaction type to remove - possible values:
                     love, like, dislike, laugh, emphasize, question
                     Can also use ReactionType enum (e.g., ReactionType.LOVE.value)

        Returns:
            Dict[str, Any]: API response

        Example:
            await client.remove_reaction(
                contact="+1234567890",
                message_id="msg-123",
                reaction="love"
            )
        """
        if not contact:
            raise InvalidParameterError("Contact must be specified")
        if not message_id:
            raise InvalidParameterError("Message ID must be specified")
        if not reaction:
            raise InvalidParameterError("Reaction must be specified")

        # Prefix with - to indicate removal
        data: Dict[str, Any] = {
            "contact": contact,
            "message_id": message_id,
            "reaction": f"-{reaction}",
        }

        response_data = await self._make_request("POST", "message/send/", data)
        return response_data

    async def show_typing(
        self,
        message_id: Optional[str] = None,
        contact: Optional[str] = None,
        sender: Optional[str] = None,
        typing: Optional[int] = None,
        read: Optional[bool] = None,
    ) -> ShowTypingResponse:
        """
        Show a typing indicator and/or mark a conversation as read.

        You must provide either message_id (preferred) or both contact + sender.

        Args:
            message_id: The message_id from an inbound webhook. When provided,
                        the API resolves the contact and sender automatically.
            contact: Phone number or email of the contact (used when message_id
                     is not available; requires sender too).
            sender: ID of your sender name (required when contact is used instead
                    of message_id).
            typing: How long (in seconds) to show the typing indicator. Max 60.
                    The indicator disappears automatically when you send a message.
                    Note: Only works in active conversations (last message < 5 min).
            read: Mark the conversation as read. Defaults to True when typing is set.

        Returns:
            ShowTypingResponse: Response confirming the request was accepted.

        Example:
            # Using message_id from webhook:
            await client.show_typing(message_id="webhook-msg-id", typing=5)

            # Using contact + sender:
            await client.show_typing(
                contact="+1234567890",
                sender="my-sender-id",
                typing=10,
                read=True,
            )
        """
        if not message_id and not (contact and sender):
            raise InvalidParameterError(
                "Either message_id or both contact and sender must be specified"
            )

        if typing is not None and not (1 <= typing <= 60):
            raise InvalidParameterError("typing must be between 1 and 60 seconds")

        data: Dict[str, Any] = {}

        if message_id:
            data["message_id"] = message_id
        if contact:
            data["contact"] = contact
        if sender:
            data["sender"] = sender
        if typing is not None:
            data["typing"] = typing
        if read is not None:
            data["read"] = read

        response_data = await self._make_request("POST", "message/show-typing/", data)
        return ShowTypingResponse(**response_data)

    async def create_campaign(
        self,
        name: str,
        text: Optional[str] = None,
        contacts: Optional[List[str]] = None,
        messages: Optional[List[CampaignMessage]] = None,
        attachments: Optional[List[str]] = None,
        effect: Optional[MessageEffect] = None,
        subject: Optional[str] = None,
        from_date: Optional[str] = None,
        from_time: Optional[str] = None,
        to_time: Optional[str] = None,
        timezone: Optional[str] = None,
    ) -> CreateCampaignResponse:
        """
        Schedule a bulk messaging campaign.

        Provide either (text + contacts) for a uniform broadcast, or messages
        for per-contact customisation. Only contacts who have already communicated
        with your sender name can be targeted; cold-messaging is not supported.

        Args:
            name: Campaign name.
            text: Message text sent to every contact (use with contacts).
            contacts: List of phone numbers / emails / contact IDs to message.
            messages: List of CampaignMessage objects for per-contact text /
                      attachments / effect / subject customisation.
            attachments: Attachment URLs applied to every message (use with
                         contacts + text; max 3, HTTPS only).
            effect: iMessage effect applied to every message (use with contacts).
            subject: Subject line applied to every message (iMessage only,
                     use with contacts).
            from_date: Start date in YYYY-MM-DD format (default: today).
            from_time: Earliest send time in HH:mm format (default: "10:00").
            to_time: Latest send time in HH:mm format (default: "22:00").
            timezone: TZ identifier, e.g. "America/Los_Angeles"
                      (default: "America/New_York").

        Returns:
            CreateCampaignResponse: Campaign ID, name, and creation timestamp.

        Raises:
            InvalidParameterError: If neither contacts+text nor messages are provided,
                                   or if both are provided simultaneously.

        Example:
            # Broadcast the same message to multiple contacts
            response = await client.create_campaign(
                name="Summer Sale",
                text="Check out our summer deals!",
                contacts=["+13231112233", "+13232112233"],
                from_date="2026-06-01",
                from_time="09:00",
                to_time="18:00",
                timezone="America/Los_Angeles",
            )

            # Per-contact personalisation
            response = await client.create_campaign(
                name="Personalised Outreach",
                messages=[
                    CampaignMessage(contact="+13231112233", text="Hi Alice!"),
                    CampaignMessage(contact="+13232112233", text="Hi Bob!"),
                ],
            )
        """
        if contacts is not None and messages is not None:
            raise InvalidParameterError(
                "Provide either contacts+text or messages, not both"
            )
        if contacts is None and messages is None:
            raise InvalidParameterError(
                "Either contacts (with text) or messages must be provided"
            )
        if contacts is not None and not text:
            raise InvalidParameterError(
                "text is required when using the contacts array"
            )

        data: Dict[str, Any] = {"name": name}

        if contacts is not None:
            data["contacts"] = contacts
            data["text"] = text
            if attachments:
                data["attachments"] = attachments
            if effect:
                data["effect"] = effect.value
            if subject:
                data["subject"] = subject
        else:
            # messages branch — serialise each CampaignMessage
            data["messages"] = [
                {
                    k: (v.value if hasattr(v, "value") else v)
                    for k, v in msg.model_dump(exclude_none=True).items()
                }
                for msg in (messages or [])
            ]

        if from_date:
            data["from_date"] = from_date
        if from_time:
            data["from_time"] = from_time
        if to_time:
            data["to_time"] = to_time
        if timezone:
            data["timezone"] = timezone

        response_data = await self._make_request("POST", "campaigns/new/", data)
        return CreateCampaignResponse(**response_data)

    async def get_message_status(self, message_id: str) -> MessageStatusResponse:
        """
        Get the status of a message.

        Args:
            message_id: The message ID to check

        Returns:
            MessageStatusResponse: Current status of the message
        """
        # Beta API uses /v1/message/status/{id}/ without 'api' prefix
        response_data = await self._make_request(
            "GET", f"message/status/{message_id}/", use_status_base=True
        )
        return MessageStatusResponse(**response_data)

    async def generate_opt_in_url(
        self,
        body: str = "[opt-in-code]",
        **custom_parameters: Any,
    ) -> OptInUrlResponse:
        """
        Generate an opt-in URL for user subscription.

        Args:
            body: Custom message body. Must contain [opt-in-code] placeholder
                  which will be replaced with a unique code.
            **custom_parameters: Any additional parameters (click_id, utm_campaign, etc.)
                                 These will be returned in the webhook when user opts in.

        Returns:
            OptInUrlResponse: Contains iMessage, SMS, and smart link URLs

        Example:
            response = await client.generate_opt_in_url(
                body="Subscribe to updates! [opt-in-code]",
                click_id="abc123",
                utm_campaign="summer_sale"
            )
        """
        if "[opt-in-code]" not in body:
            raise InvalidParameterError("body must contain [opt-in-code] placeholder")

        data: Dict[str, Any] = {"body": body}
        data.update(custom_parameters)

        response_data = await self._make_request("POST", "opt-in/generate-url/", data)
        return OptInUrlResponse(**response_data)

    def parse_webhook(self, webhook_data: Union[Dict[str, Any], str]) -> WebhookEvent:
        """
        Parse webhook data into a WebhookEvent model.

        Args:
            webhook_data: Raw webhook data (dict or JSON string)

        Returns:
            WebhookEvent: Parsed webhook event

        Raises:
            LoopMessageError: If webhook data is invalid
        """
        parsed_data: Dict[str, Any]
        if isinstance(webhook_data, str):
            import json

            parsed_data = json.loads(webhook_data)
        else:
            parsed_data = webhook_data

        try:
            return WebhookEvent(**parsed_data)
        except ValidationError as e:
            raise LoopMessageError(f"Invalid webhook data: {e}") from e
