"""History resource methods."""

from __future__ import annotations

from collections.abc import Iterator

from ._params import build_query_params, normalize_timestamp
from ._response import enrich_response
from .models import (
    BooksResponseAllTokens,
    BooksResponseSingleToken,
    MetricDataPoint,
    MetricsResponse,
    OrderBookSnapshot,
    PriceDataPoint,
    PricesResponseAllTokens,
    PricesResponseSingleToken,
)
from .pagination import iter_cursor_pages, iter_items_from_pages
from .transport import SyncTransport
from .types import Resolution, TimestampInput


class HistoryAPI:
    """History endpoint surface."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    # ------------------------------------------------------------------
    # Single-page methods
    # ------------------------------------------------------------------

    def get_market_metrics(
        self,
        id_or_slug: str,
        *,
        start_ts: TimestampInput,
        end_ts: TimestampInput,
        resolution: Resolution | str,
        limit: int = 100,
        cursor: str | None = None,
    ) -> MetricsResponse:
        params = _history_params(start_ts, end_ts, resolution, limit, cursor)
        response, body = self._transport.request(
            "GET", f"/markets/{id_or_slug}/metrics", params=params
        )
        return enrich_response(MetricsResponse, body, response)

    def get_market_prices(
        self,
        id_or_slug: str,
        *,
        start_ts: TimestampInput,
        end_ts: TimestampInput,
        resolution: Resolution | str,
        limit: int = 100,
        cursor: str | None = None,
    ) -> PricesResponseAllTokens:
        params = _history_params(start_ts, end_ts, resolution, limit, cursor)
        response, body = self._transport.request(
            "GET", f"/markets/{id_or_slug}/prices", params=params
        )
        return enrich_response(PricesResponseAllTokens, body, response)

    def get_token_prices(
        self,
        token_id: str,
        *,
        start_ts: TimestampInput,
        end_ts: TimestampInput,
        resolution: Resolution | str,
        limit: int = 100,
        cursor: str | None = None,
    ) -> PricesResponseSingleToken:
        params = _history_params(start_ts, end_ts, resolution, limit, cursor)
        response, body = self._transport.request(
            "GET", f"/tokens/{token_id}/prices", params=params
        )
        return enrich_response(PricesResponseSingleToken, body, response)

    def get_market_books(
        self,
        id_or_slug: str,
        *,
        start_ts: TimestampInput,
        end_ts: TimestampInput,
        resolution: Resolution | str,
        limit: int = 100,
        cursor: str | None = None,
    ) -> BooksResponseAllTokens:
        params = _history_params(start_ts, end_ts, resolution, limit, cursor)
        response, body = self._transport.request(
            "GET", f"/markets/{id_or_slug}/books", params=params
        )
        return enrich_response(BooksResponseAllTokens, body, response)

    def get_token_books(
        self,
        token_id: str,
        *,
        start_ts: TimestampInput,
        end_ts: TimestampInput,
        resolution: Resolution | str,
        limit: int = 100,
        cursor: str | None = None,
    ) -> BooksResponseSingleToken:
        params = _history_params(start_ts, end_ts, resolution, limit, cursor)
        response, body = self._transport.request(
            "GET", f"/tokens/{token_id}/books", params=params
        )
        return enrich_response(BooksResponseSingleToken, body, response)

    # ------------------------------------------------------------------
    # Auto-paginating iterators — item-level
    # ------------------------------------------------------------------

    def iter_market_metrics(
        self,
        id_or_slug: str,
        *,
        start_ts: TimestampInput,
        end_ts: TimestampInput,
        resolution: Resolution | str,
        page_size: int = 100,
        max_points: int | None = None,
    ) -> Iterator[MetricDataPoint]:
        def fetch_page(*, cursor: str | None, limit: int) -> MetricsResponse:
            return self.get_market_metrics(
                id_or_slug,
                start_ts=start_ts,
                end_ts=end_ts,
                resolution=resolution,
                limit=limit,
                cursor=cursor,
            )

        pages = iter_cursor_pages(
            fetch_page, page_size=page_size, get_next_cursor=lambda r: r.metadata.next_cursor
        )
        yield from iter_items_from_pages(
            pages, get_items=lambda r: r.data, max_items=max_points
        )

    def iter_token_prices(
        self,
        token_id: str,
        *,
        start_ts: TimestampInput,
        end_ts: TimestampInput,
        resolution: Resolution | str,
        page_size: int = 100,
        max_points: int | None = None,
    ) -> Iterator[PriceDataPoint]:
        def fetch_page(*, cursor: str | None, limit: int) -> PricesResponseSingleToken:
            return self.get_token_prices(
                token_id,
                start_ts=start_ts,
                end_ts=end_ts,
                resolution=resolution,
                limit=limit,
                cursor=cursor,
            )

        pages = iter_cursor_pages(
            fetch_page, page_size=page_size, get_next_cursor=lambda r: r.metadata.next_cursor
        )
        yield from iter_items_from_pages(
            pages, get_items=lambda r: r.data, max_items=max_points
        )

    def iter_token_books(
        self,
        token_id: str,
        *,
        start_ts: TimestampInput,
        end_ts: TimestampInput,
        resolution: Resolution | str,
        page_size: int = 100,
        max_points: int | None = None,
    ) -> Iterator[OrderBookSnapshot]:
        def fetch_page(*, cursor: str | None, limit: int) -> BooksResponseSingleToken:
            return self.get_token_books(
                token_id,
                start_ts=start_ts,
                end_ts=end_ts,
                resolution=resolution,
                limit=limit,
                cursor=cursor,
            )

        pages = iter_cursor_pages(
            fetch_page, page_size=page_size, get_next_cursor=lambda r: r.metadata.next_cursor
        )
        yield from iter_items_from_pages(
            pages, get_items=lambda r: r.data, max_items=max_points
        )

    # ------------------------------------------------------------------
    # Auto-paginating iterators — page-level
    # ------------------------------------------------------------------

    def iter_market_prices_pages(
        self,
        id_or_slug: str,
        *,
        start_ts: TimestampInput,
        end_ts: TimestampInput,
        resolution: Resolution | str,
        page_size: int = 100,
        max_pages: int | None = None,
    ) -> Iterator[PricesResponseAllTokens]:
        def fetch_page(*, cursor: str | None, limit: int) -> PricesResponseAllTokens:
            return self.get_market_prices(
                id_or_slug,
                start_ts=start_ts,
                end_ts=end_ts,
                resolution=resolution,
                limit=limit,
                cursor=cursor,
            )

        yield from iter_cursor_pages(
            fetch_page,
            page_size=page_size,
            max_pages=max_pages,
            get_next_cursor=lambda r: r.metadata.next_cursor,
        )

    def iter_market_books_pages(
        self,
        id_or_slug: str,
        *,
        start_ts: TimestampInput,
        end_ts: TimestampInput,
        resolution: Resolution | str,
        page_size: int = 100,
        max_pages: int | None = None,
    ) -> Iterator[BooksResponseAllTokens]:
        def fetch_page(*, cursor: str | None, limit: int) -> BooksResponseAllTokens:
            return self.get_market_books(
                id_or_slug,
                start_ts=start_ts,
                end_ts=end_ts,
                resolution=resolution,
                limit=limit,
                cursor=cursor,
            )

        yield from iter_cursor_pages(
            fetch_page,
            page_size=page_size,
            max_pages=max_pages,
            get_next_cursor=lambda r: r.metadata.next_cursor,
        )


def _history_params(
    start_ts: TimestampInput,
    end_ts: TimestampInput,
    resolution: Resolution | str,
    limit: int,
    cursor: str | None,
) -> dict[str, str]:
    """Build the common query-parameter dict for all history endpoints."""
    return build_query_params(
        start_ts=normalize_timestamp(start_ts, "start_ts"),
        end_ts=normalize_timestamp(end_ts, "end_ts"),
        resolution=resolution,
        limit=limit,
        cursor=cursor,
    )
