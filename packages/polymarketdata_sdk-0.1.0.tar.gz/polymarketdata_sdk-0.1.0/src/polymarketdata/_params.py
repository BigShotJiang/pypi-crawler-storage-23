"""Parameter normalization helpers for SDK methods."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime, timezone
from enum import Enum
from typing import Any


def normalize_timestamp(value: datetime | str | int | float, param_name: str) -> str:
    """Convert a timestamp input to a string suitable for a query parameter.

    For ``start_ts`` / ``end_ts`` (history endpoints) the value is converted to
    a Unix-epoch integer string.  For ``start_date_*`` / ``end_date_*``
    (discovery endpoints) the value is converted to an ISO-8601 date string.
    """
    if isinstance(value, datetime):
        if value.tzinfo is None:
            msg = (
                f"Parameter '{param_name}' received a naive datetime. "
                "Pass a timezone-aware datetime (e.g. datetime(..., tzinfo=timezone.utc))."
            )
            raise ValueError(msg)
        if "date" in param_name:
            return value.astimezone(timezone.utc).date().isoformat()
        return str(int(value.timestamp()))

    if isinstance(value, (int, float)):
        return str(int(value))

    return str(value)


def normalize_tags(tags: str | Sequence[str] | None) -> str | None:
    """Normalize a tags value to a comma-separated string or ``None``."""
    if tags is None:
        return None
    if isinstance(tags, str):
        return tags
    return ",".join(tags)


def build_query_params(**kwargs: Any) -> dict[str, str]:
    """Build a clean query-parameter dict from keyword arguments.

    * ``None`` values are dropped.
    * Enum members are converted to their ``.value``.
    * Numeric types are stringified.
    """
    params: dict[str, str] = {}
    for key, value in kwargs.items():
        if value is None:
            continue
        if isinstance(value, Enum):
            params[key] = value.value
        elif isinstance(value, bool):
            params[key] = str(value).lower()
        elif isinstance(value, (int, float)):
            params[key] = str(value)
        else:
            params[key] = str(value)
    return params
