"""Error hierarchy used by the SDK."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


class PolymarketDataError(Exception):
    """Base exception for all SDK errors."""

    def __init__(
        self,
        detail: str,
        *,
        status_code: int | None = None,
        request_id: str | None = None,
        headers: Mapping[str, str] | None = None,
        raw_body: Any = None,
    ) -> None:
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail
        self.request_id = request_id
        self.headers = dict(headers) if headers else {}
        self.raw_body = raw_body


class BadRequestError(PolymarketDataError):
    """Raised for HTTP 400 responses."""


class AuthenticationError(PolymarketDataError):
    """Raised for HTTP 401 responses."""


class PermissionDeniedError(PolymarketDataError):
    """Raised for HTTP 403 responses."""


class NotFoundError(PolymarketDataError):
    """Raised for HTTP 404 responses."""


class RateLimitError(PolymarketDataError):
    """Raised for HTTP 429 responses."""


class ServerError(PolymarketDataError):
    """Raised for HTTP 5xx responses."""


class NetworkError(PolymarketDataError):
    """Raised for networking failures before a response is available."""


class RequestTimeoutError(NetworkError):
    """Raised for request timeout failures."""
