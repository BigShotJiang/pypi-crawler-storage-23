"""Top-level client for the PolymarketData SDK."""

from __future__ import annotations

import os
from types import TracebackType

from .discovery import DiscoveryAPI
from .history import HistoryAPI
from .transport import DEFAULT_BASE_URL, DEFAULT_TIMEOUT, SyncTransport
from .utility import UtilityAPI


class PolymarketDataClient:
    """Sync API client surface for PolymarketData."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 2,
        retry_backoff_base: float = 0.5,
        retry_backoff_max: float = 8.0,
        user_agent_extra: str | None = None,
    ) -> None:
        resolved_api_key = api_key or os.getenv("POLYMARKETDATA_API_KEY")
        self._transport = SyncTransport(
            api_key=resolved_api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            retry_backoff_base=retry_backoff_base,
            retry_backoff_max=retry_backoff_max,
            user_agent_extra=user_agent_extra,
        )
        self.discovery = DiscoveryAPI(self._transport)
        self.history = HistoryAPI(self._transport)
        self.utility = UtilityAPI(self._transport)

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> PolymarketDataClient:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        del exc_type, exc_value, traceback
        self.close()
