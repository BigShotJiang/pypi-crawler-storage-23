"""Pagination helpers shared across resources."""

from __future__ import annotations

from collections.abc import Callable, Iterable, Iterator
from typing import TypeVar

T = TypeVar("T")
ResponseT = TypeVar("ResponseT")
ItemT = TypeVar("ItemT")


def apply_item_limit(items: Iterable[T], *, max_items: int | None) -> Iterator[T]:
    """Yield items until max_items is reached, if provided."""

    if max_items is None:
        yield from items
        return

    yielded = 0
    for item in items:
        if yielded >= max_items:
            break
        yield item
        yielded += 1


def iter_cursor_pages(
    fetch_page: Callable[..., ResponseT],
    *,
    page_size: int,
    max_pages: int | None = None,
    get_next_cursor: Callable[[ResponseT], str | None],
) -> Iterator[ResponseT]:
    """Yield successive pages by following cursor links.

    *fetch_page* is called with ``cursor`` and ``limit`` keyword arguments.
    Iteration stops when *get_next_cursor* returns ``None`` or *max_pages* is
    reached.
    """
    cursor: str | None = None
    pages_yielded = 0
    while True:
        if max_pages is not None and pages_yielded >= max_pages:
            break
        page = fetch_page(cursor=cursor, limit=page_size)
        yield page
        pages_yielded += 1
        cursor = get_next_cursor(page)
        if cursor is None:
            break


def iter_items_from_pages(
    pages: Iterator[ResponseT],
    get_items: Callable[[ResponseT], list[ItemT]],
    *,
    max_items: int | None = None,
) -> Iterator[ItemT]:
    """Flatten paginated responses into individual items with optional limit."""
    yielded = 0
    for page in pages:
        for item in get_items(page):
            if max_items is not None and yielded >= max_items:
                return
            yield item
            yielded += 1
