"""Optional pandas helpers for analyst workflows."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

from pydantic import BaseModel


def _require_pandas() -> Any:
    try:
        import pandas as pd
    except ImportError as exc:
        message = (
            "Pandas helpers require the dataframe extra. "
            "Install with `pip install polymarketdata-sdk[dataframe]`."
        )
        raise ImportError(
            message
        ) from exc
    return pd


def _to_dicts(data: Sequence[Mapping[str, Any] | BaseModel] | BaseModel) -> list[dict[str, Any]]:
    """Normalise input to a list of plain dicts.

    Accepts:
    * A full response object (e.g. ``MetricsResponse``) — extracts ``.data``.
    * A list of Pydantic models — calls ``model_dump()`` on each.
    * A list of plain dicts — returns as-is.
    """
    if isinstance(data, BaseModel):
        items: Any = getattr(data, "data", None)
        if items is not None:
            return [
                item.model_dump() if isinstance(item, BaseModel) else dict(item)
                for item in items
            ]
        return [data.model_dump()]
    return [
        item.model_dump() if isinstance(item, BaseModel) else dict(item) for item in data
    ]


def to_dataframe_records(
    records: Sequence[Mapping[str, Any] | BaseModel] | BaseModel,
) -> Any:
    """Convert generic records into a pandas DataFrame."""
    pd = _require_pandas()
    return pd.DataFrame(_to_dicts(records))


def to_dataframe_metrics(
    data: Sequence[Mapping[str, Any] | BaseModel] | BaseModel,
) -> Any:
    """Convert metrics data into a DataFrame with UTC timestamps."""
    pd = _require_pandas()
    df = pd.DataFrame(_to_dicts(data))
    if "t" in df.columns and not df.empty:
        df["t"] = pd.to_datetime(df["t"], utc=True)
    return df


def to_dataframe_prices(
    data: Sequence[Mapping[str, Any] | BaseModel] | BaseModel,
) -> Any:
    """Convert price data into a DataFrame with UTC timestamps."""
    pd = _require_pandas()
    df = pd.DataFrame(_to_dicts(data))
    if "t" in df.columns and not df.empty:
        df["t"] = pd.to_datetime(df["t"], utc=True)
    return df


def to_dataframe_books(
    data: Sequence[Mapping[str, Any] | BaseModel] | BaseModel,
) -> Any:
    """Convert order book snapshots into a DataFrame with UTC timestamps."""
    pd = _require_pandas()
    df = pd.DataFrame(_to_dicts(data))
    if "t" in df.columns and not df.empty:
        df["t"] = pd.to_datetime(df["t"], utc=True)
    return df
