"""Response enrichment helper shared by all resource methods."""

from __future__ import annotations

from typing import Any, TypeVar

import httpx
from pydantic import BaseModel

from .models.generated import RawPayload
from .models.generated import RequestMeta as PydanticRequestMeta

T = TypeVar("T", bound=BaseModel)


def enrich_response(model_class: type[T], body: dict[str, Any], response: httpx.Response) -> T:
    """Parse *body* into *model_class* and attach ``.raw`` and ``.meta``."""
    result = model_class.model_validate(body)
    result.raw = RawPayload.model_validate(body)  # type: ignore[attr-defined]
    result.meta = PydanticRequestMeta(  # type: ignore[attr-defined]
        status_code=response.status_code,
        request_id=response.headers.get("x-request-id"),
        headers=dict(response.headers),
    )
    return result
