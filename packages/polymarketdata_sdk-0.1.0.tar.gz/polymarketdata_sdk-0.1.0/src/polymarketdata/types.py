"""Shared public types and enums for the SDK."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import TypeAlias

TimestampInput: TypeAlias = datetime | str | int | float


class Resolution(str, Enum):
    """Supported aggregation resolutions for history endpoints."""

    ONE_MINUTE = "1m"
    FIVE_MINUTES = "5m"
    FIFTEEN_MINUTES = "15m"
    ONE_HOUR = "1h"
    SIX_HOURS = "6h"
    ONE_DAY = "1d"


class SortField(str, Enum):
    """Supported sort fields for discovery endpoints."""

    UPDATED_AT = "updated_at"
    START_DATE = "start_date"
    END_DATE = "end_date"


class SortOrder(str, Enum):
    """Supported sort directions."""

    ASC = "asc"
    DESC = "desc"


class TagsMatchMode(str, Enum):
    """How tags are matched in discovery filters."""

    ANY = "any"
    ALL = "all"


@dataclass(frozen=True, slots=True)
class RequestMeta:
    """Metadata collected from an HTTP response."""

    status_code: int
    request_id: str | None = None
    headers: Mapping[str, str] = field(default_factory=dict)
