"""HTTP transport utilities for the SDK."""

from __future__ import annotations

import os
import random
import time
from importlib.metadata import PackageNotFoundError, version
from typing import Any

import httpx

from .errors import (
    AuthenticationError,
    BadRequestError,
    NetworkError,
    NotFoundError,
    PermissionDeniedError,
    PolymarketDataError,
    RateLimitError,
    RequestTimeoutError,
    ServerError,
)

DEFAULT_BASE_URL = "https://api.polymarketdata.co/v1"
DEFAULT_TIMEOUT = 30.0

_STATUS_ERROR_MAP: dict[int, type[PolymarketDataError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: NotFoundError,
    429: RateLimitError,
}

_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


class SyncTransport:
    """Sync transport wrapper used by API resources."""

    def __init__(
        self,
        *,
        api_key: str | None,
        base_url: str,
        timeout: float,
        max_retries: int,
        retry_backoff_base: float,
        retry_backoff_max: float,
        user_agent_extra: str | None,
    ) -> None:
        self.api_key = api_key
        self.base_url = os.getenv("POLYMARKETDATA_BASE_URL", base_url)
        timeout_from_env = os.getenv("POLYMARKETDATA_TIMEOUT")
        self.timeout = float(timeout_from_env) if timeout_from_env is not None else timeout
        self.max_retries = max_retries
        self.retry_backoff_base = retry_backoff_base
        self.retry_backoff_max = retry_backoff_max
        self.user_agent_extra = user_agent_extra
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=self.timeout,
            headers=self._build_headers(),
        )

    @property
    def client(self) -> httpx.Client:
        return self._client

    def close(self) -> None:
        self._client.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
    ) -> tuple[httpx.Response, dict[str, Any]]:
        """Execute an HTTP request with retry logic and error mapping.

        Returns the httpx Response and the parsed JSON body.
        """
        max_attempts = self.max_retries + 1
        last_exc: Exception | None = None

        for attempt in range(max_attempts):
            try:
                response = self._client.request(method, path, params=params)
            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt < max_attempts - 1:
                    self._sleep_backoff(attempt)
                    continue
                raise RequestTimeoutError(
                    f"Request timed out after {self.timeout}s",
                    status_code=None,
                ) from exc
            except httpx.ConnectError as exc:
                last_exc = exc
                if attempt < max_attempts - 1:
                    self._sleep_backoff(attempt)
                    continue
                raise NetworkError(str(exc), status_code=None) from exc

            status = response.status_code

            if 200 <= status < 300:
                return response, response.json()

            if status in _RETRYABLE_STATUS_CODES and attempt < max_attempts - 1:
                self._sleep_backoff(attempt, response=response)
                continue

            _raise_for_status(response)

        # Should not be reached, but satisfy the type checker.
        if last_exc is not None:  # pragma: no cover
            raise last_exc  # pragma: no cover
        raise RuntimeError("Unexpected state in request loop")  # pragma: no cover

    def _sleep_backoff(
        self,
        attempt: int,
        *,
        response: httpx.Response | None = None,
    ) -> None:
        delay = min(
            self.retry_backoff_base * (2**attempt),
            self.retry_backoff_max,
        )
        jitter = random.uniform(0, delay * 0.25)
        actual_delay = delay + jitter

        if response is not None:
            retry_after = response.headers.get("retry-after")
            if retry_after is not None:
                try:
                    actual_delay = max(float(retry_after), actual_delay)
                except ValueError:
                    pass

        time.sleep(actual_delay)

    def _build_headers(self) -> dict[str, str]:
        sdk_version = _resolve_sdk_version()
        user_agent = f"polymarketdata-python/{sdk_version}"
        if self.user_agent_extra:
            user_agent = f"{user_agent} {self.user_agent_extra}"

        headers = {"User-Agent": user_agent}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        return headers

    def __repr__(self) -> str:
        return f"SyncTransport(base_url={self.base_url!r}, api_key=****)"


def _raise_for_status(response: httpx.Response) -> None:
    """Map an HTTP error response to the appropriate SDK exception."""
    status = response.status_code
    headers = dict(response.headers)

    try:
        body = response.json()
        detail = body.get("detail", response.text)
    except Exception:
        body = None
        detail = response.text

    request_id = (
        (body.get("request_id") if isinstance(body, dict) else None)
        or response.headers.get("x-request-id")
    )

    error_cls = _STATUS_ERROR_MAP.get(status)
    if error_cls is None and status >= 500:
        error_cls = ServerError
    if error_cls is None:
        error_cls = BadRequestError

    raise error_cls(
        detail,
        status_code=status,
        request_id=request_id,
        headers=headers,
        raw_body=body,
    )


def _resolve_sdk_version() -> str:
    try:
        return version("polymarketdata-sdk")
    except PackageNotFoundError:
        return "0.1.0"
