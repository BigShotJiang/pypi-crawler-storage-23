"""Discovery resource methods."""

from __future__ import annotations

from collections.abc import Iterator, Sequence

from ._params import build_query_params, normalize_tags, normalize_timestamp
from ._response import enrich_response
from .models import (
    EventItem,
    EventListResponse,
    MarketDetailResponse,
    MarketItem,
    MarketListResponse,
    SeriesItem,
    SeriesListResponse,
    TagListResponse,
)
from .pagination import iter_cursor_pages, iter_items_from_pages
from .transport import SyncTransport
from .types import SortField, SortOrder, TagsMatchMode, TimestampInput


class DiscoveryAPI:
    """Discovery endpoint surface."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    # ------------------------------------------------------------------
    # Single-page methods
    # ------------------------------------------------------------------

    def list_series(
        self,
        *,
        search: str | None = None,
        limit: int = 100,
        cursor: str | None = None,
        start_date_min: TimestampInput | None = None,
        start_date_max: TimestampInput | None = None,
        end_date_min: TimestampInput | None = None,
        end_date_max: TimestampInput | None = None,
        tags: str | Sequence[str] | None = None,
        tags_match: TagsMatchMode | str = TagsMatchMode.ANY,
        sort: SortField | str = SortField.UPDATED_AT,
        order: SortOrder | str = SortOrder.DESC,
    ) -> SeriesListResponse:
        params = build_query_params(
            search=search,
            limit=limit,
            cursor=cursor,
            start_date_min=(
                normalize_timestamp(start_date_min, "start_date_min")
                if start_date_min is not None
                else None
            ),
            start_date_max=(
                normalize_timestamp(start_date_max, "start_date_max")
                if start_date_max is not None
                else None
            ),
            end_date_min=(
                normalize_timestamp(end_date_min, "end_date_min")
                if end_date_min is not None
                else None
            ),
            end_date_max=(
                normalize_timestamp(end_date_max, "end_date_max")
                if end_date_max is not None
                else None
            ),
            tags=normalize_tags(tags),
            tags_match=tags_match,
            sort=sort,
            order=order,
        )
        response, body = self._transport.request("GET", "/series", params=params)
        return enrich_response(SeriesListResponse, body, response)

    def list_events(
        self,
        *,
        search: str | None = None,
        series_id: str | None = None,
        series_slug: str | None = None,
        limit: int = 100,
        cursor: str | None = None,
        sort: SortField | str = SortField.UPDATED_AT,
        order: SortOrder | str = SortOrder.DESC,
    ) -> EventListResponse:
        params = build_query_params(
            search=search,
            series_id=series_id,
            series_slug=series_slug,
            limit=limit,
            cursor=cursor,
            sort=sort,
            order=order,
        )
        response, body = self._transport.request("GET", "/events", params=params)
        return enrich_response(EventListResponse, body, response)

    def list_markets(
        self,
        *,
        search: str | None = None,
        event_id: str | None = None,
        event_slug: str | None = None,
        limit: int = 100,
        cursor: str | None = None,
        sort: SortField | str = SortField.UPDATED_AT,
        order: SortOrder | str = SortOrder.DESC,
    ) -> MarketListResponse:
        params = build_query_params(
            search=search,
            event_id=event_id,
            event_slug=event_slug,
            limit=limit,
            cursor=cursor,
            sort=sort,
            order=order,
        )
        response, body = self._transport.request("GET", "/markets", params=params)
        return enrich_response(MarketListResponse, body, response)

    def list_tags(self) -> TagListResponse:
        response, body = self._transport.request("GET", "/tags")
        return enrich_response(TagListResponse, body, response)

    def get_market(self, id_or_slug: str) -> MarketDetailResponse:
        response, body = self._transport.request("GET", f"/markets/{id_or_slug}")
        # API returns the market fields at top level; wrap for SDK model
        return enrich_response(MarketDetailResponse, {"market": body}, response)

    # ------------------------------------------------------------------
    # Auto-paginating iterators
    # ------------------------------------------------------------------

    def iter_series(
        self,
        *,
        search: str | None = None,
        page_size: int = 100,
        max_items: int | None = None,
        start_date_min: TimestampInput | None = None,
        start_date_max: TimestampInput | None = None,
        end_date_min: TimestampInput | None = None,
        end_date_max: TimestampInput | None = None,
        tags: str | Sequence[str] | None = None,
        tags_match: TagsMatchMode | str = TagsMatchMode.ANY,
        sort: SortField | str = SortField.UPDATED_AT,
        order: SortOrder | str = SortOrder.DESC,
    ) -> Iterator[SeriesItem]:
        def fetch_page(*, cursor: str | None, limit: int) -> SeriesListResponse:
            return self.list_series(
                search=search,
                limit=limit,
                cursor=cursor,
                start_date_min=start_date_min,
                start_date_max=start_date_max,
                end_date_min=end_date_min,
                end_date_max=end_date_max,
                tags=tags,
                tags_match=tags_match,
                sort=sort,
                order=order,
            )

        pages = iter_cursor_pages(
            fetch_page,
            page_size=page_size,
            get_next_cursor=lambda r: r.metadata.next_cursor,
        )
        yield from iter_items_from_pages(pages, get_items=lambda r: r.data, max_items=max_items)

    def iter_events(
        self,
        *,
        search: str | None = None,
        series_id: str | None = None,
        series_slug: str | None = None,
        page_size: int = 100,
        max_items: int | None = None,
        sort: SortField | str = SortField.UPDATED_AT,
        order: SortOrder | str = SortOrder.DESC,
    ) -> Iterator[EventItem]:
        def fetch_page(*, cursor: str | None, limit: int) -> EventListResponse:
            return self.list_events(
                search=search,
                series_id=series_id,
                series_slug=series_slug,
                limit=limit,
                cursor=cursor,
                sort=sort,
                order=order,
            )

        pages = iter_cursor_pages(
            fetch_page,
            page_size=page_size,
            get_next_cursor=lambda r: r.metadata.next_cursor,
        )
        yield from iter_items_from_pages(pages, get_items=lambda r: r.data, max_items=max_items)

    def iter_markets(
        self,
        *,
        search: str | None = None,
        event_id: str | None = None,
        event_slug: str | None = None,
        page_size: int = 100,
        max_items: int | None = None,
        sort: SortField | str = SortField.UPDATED_AT,
        order: SortOrder | str = SortOrder.DESC,
    ) -> Iterator[MarketItem]:
        def fetch_page(*, cursor: str | None, limit: int) -> MarketListResponse:
            return self.list_markets(
                search=search,
                event_id=event_id,
                event_slug=event_slug,
                limit=limit,
                cursor=cursor,
                sort=sort,
                order=order,
            )

        pages = iter_cursor_pages(
            fetch_page,
            page_size=page_size,
            get_next_cursor=lambda r: r.metadata.next_cursor,
        )
        yield from iter_items_from_pages(pages, get_items=lambda r: r.data, max_items=max_items)
