"""Utility resource methods."""

from __future__ import annotations

from ._response import enrich_response
from .models import LivenessResponse, UsageResponse
from .transport import SyncTransport


class UtilityAPI:
    """Utility endpoint surface."""

    def __init__(self, transport: SyncTransport) -> None:
        self._transport = transport

    def health(self) -> LivenessResponse:
        response, body = self._transport.request("GET", "/health")
        return enrich_response(LivenessResponse, body, response)

    def usage(self) -> UsageResponse:
        response, body = self._transport.request("GET", "/usage")
        return enrich_response(UsageResponse, body, response)
