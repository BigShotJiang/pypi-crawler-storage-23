# Contributing

Thanks for contributing to `polymarketdata-sdk`.

## Local setup

1. Install [uv](https://docs.astral.sh/uv/).
2. Sync dependencies:

```bash
uv sync --group dev
```

3. Regenerate models when `openapi/openapi.json` changes:

```bash
uv run python scripts/update_openapi.py
```

## Quality gates

Run all checks before opening a PR:

```bash
uv run ruff check .
uv run mypy src scripts
uv run pytest
uv run python scripts/update_openapi.py --check
```

## Pull request expectations

- Keep changes focused and small.
- Add or update tests for behavior changes.
- Update docs/examples when public behavior changes.
- Do not commit secrets, API keys, or customer data.
