"""Live smoke test against the real PolymarketData API.

Requires POLYMARKETDATA_API_KEY to be set.
"""

from __future__ import annotations

import os
import sys
import time
import traceback
from collections.abc import Callable
from typing import Any

# Ensure the src layout is importable when running directly
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from polymarketdata import PolymarketDataClient, Resolution


def main() -> None:
    api_key = os.getenv("POLYMARKETDATA_API_KEY")
    if not api_key:
        print("POLYMARKETDATA_API_KEY not set, skipping smoke test.")
        sys.exit(1)

    client = PolymarketDataClient(api_key=api_key)
    passed = 0
    failed = 0

    def run(name: str, fn: Callable[[], Any]) -> Any:
        nonlocal passed, failed
        try:
            result = fn()
            print(f"  PASS  {name}")
            passed += 1
            return result
        except Exception:
            print(f"  FAIL  {name}")
            traceback.print_exc()
            failed += 1
            return None

    print("=== Utility ===")

    health_result = run("health()", lambda: client.utility.health())
    if health_result:
        print(f"         status={health_result.status}")
        print(f"         meta.status_code={health_result.meta and health_result.meta.status_code}")
        print(f"         raw={health_result.raw}")

    usage_result = run("usage()", lambda: client.utility.usage())
    if usage_result:
        remaining = usage_result.limits.requests_remaining
        print(f"         plan={usage_result.plan}, remaining={remaining}")

    print("\n=== Discovery ===")

    series_result = run("list_series(limit=3)", lambda: client.discovery.list_series(limit=3))
    if series_result:
        next_cur = series_result.metadata.next_cursor
        print(f"         count={len(series_result.data)}, next_cursor={next_cur}")
        for s in series_result.data:
            print(f"         - {s.id}: {s.title}")

    events_result = run("list_events(limit=3)", lambda: client.discovery.list_events(limit=3))
    if events_result:
        print(f"         count={len(events_result.data)}")
        for e in events_result.data:
            print(f"         - {e.id}: {e.title}")

    markets_result = run("list_markets(limit=3)", lambda: client.discovery.list_markets(limit=3))
    if markets_result:
        print(f"         count={len(markets_result.data)}")
        for m in markets_result.data:
            print(f"         - {m.id}: {m.question}")

    tags_result = run("list_tags()", lambda: client.discovery.list_tags())
    if tags_result:
        print(f"         tags={tags_result.data[:5]}...")

    # Get a specific market if we have one
    market_id = None
    if markets_result and markets_result.data:
        market_id = markets_result.data[0].slug or markets_result.data[0].id
        detail_result = run(
            f"get_market({market_id!r})",
            lambda: client.discovery.get_market(market_id),
        )
        if detail_result:
            print(f"         market={detail_result.market.question}")

    # Test iterator (just take 5 items)
    run(
        "iter_series(max_items=5)",
        lambda: list(client.discovery.iter_series(max_items=5)),
    )

    print("\n=== History ===")

    # Use a known market for history if available
    if market_id:
        metrics_result = run(
            f"get_market_metrics({market_id!r}, 1d)",
            lambda: client.history.get_market_metrics(
                market_id,
                start_ts=0,
                end_ts=int(time.time()),
                resolution=Resolution.ONE_DAY,
                limit=5,
            ),
        )
        if metrics_result:
            print(f"         data_points={len(metrics_result.data)}")
            for dp in metrics_result.data[:3]:
                print(f"         - t={dp.t}, volume={dp.volume}, liquidity={dp.liquidity}")

        prices_result = run(
            f"get_market_prices({market_id!r}, 1d)",
            lambda: client.history.get_market_prices(
                market_id,
                start_ts=0,
                end_ts=int(time.time()),
                resolution=Resolution.ONE_DAY,
                limit=5,
            ),
        )
        if prices_result:
            print(f"         tokens={list(prices_result.tokens.keys())}")
            for label, points in prices_result.data.items():
                print(f"         [{label}] {len(points)} points")
                for dp in points[:2]:
                    print(f"           - t={dp.t}, p={dp.p}")

        books_result = run(
            f"get_market_books({market_id!r}, 1d)",
            lambda: client.history.get_market_books(
                market_id,
                start_ts=0,
                end_ts=int(time.time()),
                resolution=Resolution.ONE_DAY,
                limit=3,
            ),
        )
        if books_result:
            for label, snaps in books_result.data.items():
                print(f"         [{label}] {len(snaps)} snapshots")
                for snap in snaps[:2]:
                    print(f"           - t={snap.t}, bids={len(snap.bids)}, asks={len(snap.asks)}")

    print(f"\n=== Results: {passed} passed, {failed} failed ===")
    client.close()
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
