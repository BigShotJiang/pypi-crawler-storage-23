#!/usr/bin/env python3
"""Regenerate typed models from the pinned OpenAPI snapshot."""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OPENAPI_PATH = ROOT / "openapi" / "openapi.json"
OUTPUT_PATH = ROOT / "src" / "polymarketdata" / "models" / "generated.py"


def run_datamodel_codegen(*, check: bool) -> None:
    cmd = [
        sys.executable,
        "-m",
        "datamodel_code_generator",
        "--input",
        str(OPENAPI_PATH),
        "--input-file-type",
        "openapi",
        "--output",
        str(OUTPUT_PATH),
        "--output-model-type",
        "pydantic_v2.BaseModel",
        "--target-python-version",
        "3.10",
        "--openapi-scopes",
        "schemas",
        "--disable-timestamp",
        "--use-annotated",
        "--formatters",
        "ruff-format",
        "--use-standard-collections",
    ]
    if check:
        cmd.append("--check")

    subprocess.run(cmd, check=True, cwd=ROOT)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--check",
        action="store_true",
        help="Fail if generated models differ from the committed output.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if not OPENAPI_PATH.exists():
        print(f"Missing OpenAPI snapshot: {OPENAPI_PATH}", file=sys.stderr)
        return 2

    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

    if args.check and not OUTPUT_PATH.exists():
        print(
            f"Generated models are missing at {OUTPUT_PATH}. Run scripts/update_openapi.py first.",
            file=sys.stderr,
        )
        return 1

    try:
        run_datamodel_codegen(check=args.check)
    except subprocess.CalledProcessError as exc:
        return exc.returncode

    if args.check:
        print("OpenAPI models are up-to-date.")
    else:
        print(f"Generated models at {OUTPUT_PATH}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
