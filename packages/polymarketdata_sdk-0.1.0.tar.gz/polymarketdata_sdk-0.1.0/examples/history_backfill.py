"""History backfill example.

Shows how to fetch time-series data (metrics, prices, order books) for a market,
including auto-paginating iterators for large date ranges.

Usage:
    export POLYMARKETDATA_API_KEY="your-key"
    python examples/history_backfill.py
"""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from polymarketdata import PolymarketDataClient, Resolution

# A well-known resolved market to use as a concrete example.
# Swap this for any market ID or slug you want to inspect.
MARKET_SLUG = "will-the-federal-reserve-cut-rates-in-september-2024"

START = "2024-01-01T00:00:00Z"
END = "2024-10-01T00:00:00Z"


def main() -> None:
    api_key = os.getenv("POLYMARKETDATA_API_KEY")
    if not api_key:
        sys.exit("Set POLYMARKETDATA_API_KEY before running this example.")

    with PolymarketDataClient(api_key=api_key) as client:
        # ------------------------------------------------------------------
        # 0. Discover the market and its tokens
        # ------------------------------------------------------------------
        print(f"=== Market detail: {MARKET_SLUG} ===")
        detail = client.discovery.get_market(MARKET_SLUG)
        mkt = detail.market
        print(f"  question: {mkt.question}")
        print(f"  status:   {mkt.status}")
        tokens = mkt.tokens or []
        for tok in tokens:
            print(f"  token: {tok.label:10s}  id={tok.id}")
        print()

        if not tokens:
            print("No tokens found — try a different market slug.")
            return

        # ------------------------------------------------------------------
        # 1. Market-level metrics (volume, liquidity, spread) — daily bars
        # ------------------------------------------------------------------
        print("=== Market metrics (daily, first 5 bars) ===")
        metrics = client.history.get_market_metrics(
            MARKET_SLUG,
            start_ts=START,
            end_ts=END,
            resolution=Resolution.ONE_DAY,
            limit=5,
        )
        print(f"  market_id={metrics.market_id}  resolution={metrics.resolution}")
        for dp in metrics.data:
            print(
                f"  {dp.t}  volume={dp.volume:>12.2f}  "
                f"liquidity={dp.liquidity:>12.2f}  spread={dp.spread:.6f}"
            )
        print(
            f"  total available: {metrics.metadata.count}"
            f"  next_cursor={metrics.metadata.next_cursor}\n"
        )

        # Streaming all bars with the iterator (no cursor management needed)
        print("=== iter_market_metrics (all daily bars) ===")
        all_metrics = list(
            client.history.iter_market_metrics(
                MARKET_SLUG,
                start_ts=START,
                end_ts=END,
                resolution=Resolution.ONE_DAY,
            )
        )
        print(f"  fetched {len(all_metrics)} data points total\n")

        # ------------------------------------------------------------------
        # 2. Market-level prices (all tokens) — hourly bars
        # ------------------------------------------------------------------
        print("=== Market prices — all tokens (first 3 bars per token) ===")
        prices = client.history.get_market_prices(
            MARKET_SLUG,
            start_ts=START,
            end_ts=END,
            resolution=Resolution.ONE_HOUR,
            limit=3,
        )
        print(f"  tokens: {prices.tokens}")  # {"Yes": "<id>", "No": "<id>"}
        for label, points in prices.data.items():
            print(f"  [{label}] {len(points)} points")
            for dp in points:
                print(f"    t={dp.t}  p={dp.p:.6f}")
        print()

        # ------------------------------------------------------------------
        # 3. Single-token prices — auto-paginating iterator
        # ------------------------------------------------------------------
        yes_token_id = prices.tokens.get("Yes") or tokens[0].id
        print(f"=== iter_token_prices for 'Yes' token ({yes_token_id[:16]}...) — daily ===")
        price_points = list(
            client.history.iter_token_prices(
                yes_token_id,
                start_ts=START,
                end_ts=END,
                resolution=Resolution.ONE_DAY,
            )
        )
        print(f"  fetched {len(price_points)} price points")
        if price_points:
            first, last = price_points[0], price_points[-1]
            print(f"  first: t={first.t}  p={first.p:.6f}")
            print(f"  last:  t={last.t}  p={last.p:.6f}")
        print()

        # ------------------------------------------------------------------
        # 4. Order book snapshots — market-level (hourly)
        # ------------------------------------------------------------------
        print("=== Market order books (first 2 snapshots per token) ===")
        books = client.history.get_market_books(
            MARKET_SLUG,
            start_ts=START,
            end_ts="2024-01-07T00:00:00Z",  # short window to keep output manageable
            resolution=Resolution.ONE_HOUR,
            limit=2,
        )
        for label, snapshots in books.data.items():
            print(f"  [{label}]  {len(snapshots)} snapshots")
            for snap in snapshots:
                best_bid = snap.bids[0] if snap.bids else None
                best_ask = snap.asks[0] if snap.asks else None
                print(f"    t={snap.t}")
                print(f"    best bid: {best_bid}  (price, size)")
                print(f"    best ask: {best_ask}  (price, size)")
                print(f"    depth: {len(snap.bids)} bids / {len(snap.asks)} asks")
        print()

        # ------------------------------------------------------------------
        # 5. Single-token book iterator — compute mid-price time series
        # ------------------------------------------------------------------
        print("=== iter_token_books for 'Yes' token — mid-price series (first 5) ===")
        shown = 0
        for snap in client.history.iter_token_books(
            yes_token_id,
            start_ts=START,
            end_ts="2024-03-01T00:00:00Z",
            resolution=Resolution.ONE_HOUR,
        ):
            if shown >= 5:
                break
            if snap.bids and snap.asks:
                mid = (snap.bids[0][0] + snap.asks[0][0]) / 2
                spread = snap.asks[0][0] - snap.bids[0][0]
                print(f"  t={snap.t}  mid={mid:.6f}  spread={spread:.6f}")
                shown += 1
        print()

        # ------------------------------------------------------------------
        # 6. Page-level iterator — process prices in batches
        # ------------------------------------------------------------------
        print("=== iter_market_prices_pages (batch processing, max 2 pages) ===")
        page_num = 0
        for page in client.history.iter_market_prices_pages(
            MARKET_SLUG,
            start_ts=START,
            end_ts=END,
            resolution=Resolution.ONE_DAY,
            max_pages=2,
        ):
            page_num += 1
            total_points = sum(len(pts) for pts in page.data.values())
            print(f"  page {page_num}: {total_points} data points across {len(page.data)} tokens")
        print()

        # ------------------------------------------------------------------
        # 7. Rate-limit check at the end
        # ------------------------------------------------------------------
        usage = client.utility.usage()
        print("=== Usage after example ===")
        print(f"  plan:               {usage.plan}")
        print(f"  requests remaining: {usage.limits.requests_remaining}")
        print(f"  resets at:          {usage.reset_at}  (Unix timestamp)")


if __name__ == "__main__":
    main()
