"""Discovery flow example.

Shows how to navigate the hierarchy:  series → events → markets.

Usage:
    export POLYMARKETDATA_API_KEY="your-key"
    python examples/discovery_flow.py
"""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from polymarketdata import NotFoundError, PolymarketDataClient


def main() -> None:
    api_key = os.getenv("POLYMARKETDATA_API_KEY")
    if not api_key:
        sys.exit("Set POLYMARKETDATA_API_KEY before running this example.")

    with PolymarketDataClient(api_key=api_key) as client:
        # ------------------------------------------------------------------
        # 1. Check plan / remaining quota
        # ------------------------------------------------------------------
        usage = client.utility.usage()
        print(f"Plan: {usage.plan}  |  requests remaining: {usage.limits.requests_remaining}\n")

        # ------------------------------------------------------------------
        # 2. List series (first page)
        # ------------------------------------------------------------------
        print("=== Series (first 5) ===")
        series_page = client.discovery.list_series(limit=5)
        for s in series_page.data:
            print(f"  {s.id:40s}  {s.title}")
        next_cur = series_page.metadata.next_cursor
        print(f"  → next_cursor={next_cur}\n")

        if not series_page.data:
            print("No series returned — check your API key and try again.")
            return

        # ------------------------------------------------------------------
        # 3. Browse all available tags
        # ------------------------------------------------------------------
        print("=== Available tags (first 10) ===")
        tags = client.discovery.list_tags()
        print(f"  {tags.data[:10]}\n")

        # ------------------------------------------------------------------
        # 4. Drill into the first series: list its events
        # ------------------------------------------------------------------
        first_series = series_page.data[0]
        print(f"=== Events in series '{first_series.slug}' (first 5) ===")
        events_page = client.discovery.list_events(series_slug=first_series.slug, limit=5)
        for e in events_page.data:
            print(f"  {e.id:40s}  {e.title}")
        print()

        if not events_page.data:
            print("No events in this series.")
            return

        # ------------------------------------------------------------------
        # 5. Drill into the first event: list its markets
        # ------------------------------------------------------------------
        first_event = events_page.data[0]
        print(f"=== Markets in event '{first_event.slug}' ===")
        markets_page = client.discovery.list_markets(event_slug=first_event.slug, limit=10)
        for m in markets_page.data:
            tokens = ", ".join(t.label for t in (m.tokens or []))
            print(f"  {m.id:40s}  {m.question[:60]}  [{tokens}]")
        print()

        if not markets_page.data:
            print("No markets in this event.")
            return

        # ------------------------------------------------------------------
        # 6. Fetch full detail for the first market
        # ------------------------------------------------------------------
        first_market = markets_page.data[0]
        print(f"=== Market detail: {first_market.slug} ===")
        try:
            detail = client.discovery.get_market(first_market.slug)
            m = detail.market
            print(f"  question:              {m.question}")
            print(f"  status:                {m.status}")
            print(f"  start_date:            {m.start_date}")
            print(f"  end_date:              {m.end_date}")
            print(f"  resolved_token_label:  {m.resolved_token_label}")
            if m.tokens:
                for tok in m.tokens:
                    print(f"  token: {tok.label:10s}  id={tok.id}")
        except NotFoundError as exc:
            print(f"  Not found: {exc.detail}")
        print()

        # ------------------------------------------------------------------
        # 7. Auto-paginating iterator demo (cap at 15 items)
        # ------------------------------------------------------------------
        print("=== iter_series (max_items=15) ===")
        count = 0
        for s in client.discovery.iter_series(max_items=15):
            print(f"  {s.slug:50s}  {s.title[:60]}")
            count += 1
        print(f"  → yielded {count} series\n")


if __name__ == "__main__":
    main()
