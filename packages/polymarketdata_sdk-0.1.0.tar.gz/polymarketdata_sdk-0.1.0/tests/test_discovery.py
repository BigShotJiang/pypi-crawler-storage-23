"""Tests for the discovery API resource."""

from __future__ import annotations

import pytest

from polymarketdata import PolymarketDataClient
from polymarketdata.errors import NotFoundError
from polymarketdata.models.generated import SeriesItem

_EMPTY_META = {"count": 0, "limit": 100, "next_cursor": None}


# --- list_series ---


def test_list_series_sends_correct_params(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        json={"metadata": _EMPTY_META, "data": []},
    )
    client.discovery.list_series(search="election", limit=10)
    request = httpx_mock.get_requests()[0]
    assert request.url.params["search"] == "election"
    assert request.url.params["limit"] == "10"
    assert "/series" in str(request.url)


def test_list_series_parses_response(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        json={
            "metadata": {"count": 1, "limit": 100, "next_cursor": "cur_abc"},
            "data": [
                {"id": "s1", "slug": "2024-election", "title": "2024 US Election"},
            ],
        },
    )
    result = client.discovery.list_series()
    assert len(result.data) == 1
    assert result.data[0].id == "s1"
    assert result.metadata.next_cursor == "cur_abc"


def test_list_series_with_tags_list(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(json={"metadata": _EMPTY_META, "data": []})
    client.discovery.list_series(tags=["politics", "sports"])
    request = httpx_mock.get_requests()[0]
    assert request.url.params["tags"] == "politics,sports"


# --- list_events ---


def test_list_events_sends_series_filters(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(json={"metadata": _EMPTY_META, "data": []})
    client.discovery.list_events(series_id="ser_123")
    request = httpx_mock.get_requests()[0]
    assert request.url.params["series_id"] == "ser_123"


def test_list_events_parses_response(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        json={
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
            "data": [{"id": "e1", "slug": "event-one", "title": "Event One"}],
        },
    )
    result = client.discovery.list_events()
    assert result.data[0].slug == "event-one"


# --- list_markets ---


def test_list_markets_sends_event_filters(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(json={"metadata": _EMPTY_META, "data": []})
    client.discovery.list_markets(event_slug="evt-slug")
    request = httpx_mock.get_requests()[0]
    assert request.url.params["event_slug"] == "evt-slug"


def test_list_markets_parses_response(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        json={
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
            "data": [{"id": "m1", "slug": "market-one", "question": "Will X happen?"}],
        },
    )
    result = client.discovery.list_markets()
    assert result.data[0].question == "Will X happen?"


# --- list_tags ---


def test_list_tags_returns_tag_list(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        json={"count": 2, "data": ["politics", "sports"]},
    )
    result = client.discovery.list_tags()
    assert len(result.data) == 2
    assert result.data[0] == "politics"


# --- get_market ---


def test_get_market_by_slug(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        json={"id": "m1", "slug": "my-market-slug", "question": "Q?"},
    )
    result = client.discovery.get_market("my-market-slug")
    assert result.market.slug == "my-market-slug"


def test_get_market_404_raises_not_found(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        status_code=404,
        json={"detail": "Market not found"},
    )
    with pytest.raises(NotFoundError):
        client.discovery.get_market("nonexistent")


# --- iter_series ---


def test_iter_series_auto_paginates(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        json={
            "metadata": {"count": 2, "limit": 100, "next_cursor": "page2"},
            "data": [
                {"id": "s1", "slug": "a", "title": "A"},
                {"id": "s2", "slug": "b", "title": "B"},
            ],
        },
    )
    httpx_mock.add_response(
        json={
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
            "data": [{"id": "s3", "slug": "c", "title": "C"}],
        },
    )
    items = list(client.discovery.iter_series())
    assert len(items) == 3
    assert all(isinstance(item, SeriesItem) for item in items)


def test_iter_series_respects_max_items(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        json={
            "metadata": {"count": 3, "limit": 100, "next_cursor": "page2"},
            "data": [
                {"id": "s1", "slug": "a", "title": "A"},
                {"id": "s2", "slug": "b", "title": "B"},
                {"id": "s3", "slug": "c", "title": "C"},
            ],
        },
    )
    items = list(client.discovery.iter_series(max_items=2))
    assert len(items) == 2


# --- iter_events ---


def test_iter_events_auto_paginates(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        json={
            "metadata": {"count": 1, "limit": 100, "next_cursor": "p2"},
            "data": [{"id": "e1", "slug": "x", "title": "X"}],
        },
    )
    httpx_mock.add_response(
        json={
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
            "data": [{"id": "e2", "slug": "y", "title": "Y"}],
        },
    )
    items = list(client.discovery.iter_events())
    assert len(items) == 2


# --- iter_markets ---


def test_iter_markets_auto_paginates(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        json={
            "metadata": {"count": 1, "limit": 100, "next_cursor": "p2"},
            "data": [{"id": "m1", "slug": "x", "question": "Q1?"}],
        },
    )
    httpx_mock.add_response(
        json={
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
            "data": [{"id": "m2", "slug": "y", "question": "Q2?"}],
        },
    )
    items = list(client.discovery.iter_markets())
    assert len(items) == 2
