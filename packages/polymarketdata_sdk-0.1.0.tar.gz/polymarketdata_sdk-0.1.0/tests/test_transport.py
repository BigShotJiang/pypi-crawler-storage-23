"""Tests for the transport layer: request, retry, error mapping."""

from __future__ import annotations

import httpx
import pytest

from polymarketdata.errors import (
    AuthenticationError,
    BadRequestError,
    NetworkError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    RequestTimeoutError,
    ServerError,
)
from polymarketdata.transport import SyncTransport

# --- successful request ---


def test_request_returns_parsed_json(transport: SyncTransport, httpx_mock) -> None:
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/health",
        json={"status": "ok"},
    )
    response, body = transport.request("GET", "/health")
    assert body == {"status": "ok"}
    assert response.status_code == 200


# --- error mapping ---


@pytest.mark.parametrize(
    ("status_code", "error_class"),
    [
        (400, BadRequestError),
        (401, AuthenticationError),
        (403, PermissionDeniedError),
        (404, NotFoundError),
        (429, RateLimitError),
        (500, ServerError),
        (502, ServerError),
        (503, ServerError),
    ],
)
def test_request_maps_status_to_error(
    transport: SyncTransport,
    httpx_mock,
    status_code: int,
    error_class: type,
) -> None:
    # No retries on transport fixture for these tests; set max_retries=0
    transport.max_retries = 0
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/test",
        status_code=status_code,
        json={"detail": "error message"},
    )
    with pytest.raises(error_class) as exc_info:
        transport.request("GET", "/test")
    assert exc_info.value.status_code == status_code
    assert exc_info.value.detail == "error message"


def test_error_includes_request_id(transport: SyncTransport, httpx_mock) -> None:
    transport.max_retries = 0
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/test",
        status_code=404,
        json={"detail": "not found"},
        headers={"x-request-id": "req_abc123"},
    )
    with pytest.raises(NotFoundError) as exc_info:
        transport.request("GET", "/test")
    assert exc_info.value.request_id == "req_abc123"


# --- retry logic ---


def test_request_retries_on_429(transport: SyncTransport, httpx_mock) -> None:
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/test",
        status_code=429,
        json={"detail": "rate limited"},
    )
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/test",
        json={"data": "ok"},
    )
    _, body = transport.request("GET", "/test")
    assert body == {"data": "ok"}
    assert len(httpx_mock.get_requests()) == 2


def test_request_retries_on_500(transport: SyncTransport, httpx_mock) -> None:
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/test",
        status_code=500,
        json={"detail": "server error"},
    )
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/test",
        json={"data": "ok"},
    )
    _, body = transport.request("GET", "/test")
    assert body == {"data": "ok"}


def test_request_retries_on_timeout(transport: SyncTransport, httpx_mock) -> None:
    httpx_mock.add_exception(httpx.ReadTimeout("read timeout"))
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/test",
        json={"data": "ok"},
    )
    _, body = transport.request("GET", "/test")
    assert body == {"data": "ok"}


def test_request_exhausts_retries_then_raises(transport: SyncTransport, httpx_mock) -> None:
    for _ in range(3):
        httpx_mock.add_response(
            url="https://api.polymarketdata.co/v1/test",
            status_code=500,
            json={"detail": "server error"},
        )
    with pytest.raises(ServerError):
        transport.request("GET", "/test")
    assert len(httpx_mock.get_requests()) == 3


def test_request_does_not_retry_4xx(transport: SyncTransport, httpx_mock) -> None:
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/test",
        status_code=400,
        json={"detail": "bad request"},
    )
    with pytest.raises(BadRequestError):
        transport.request("GET", "/test")
    assert len(httpx_mock.get_requests()) == 1


def test_request_timeout_raises_request_timeout_error(
    transport: SyncTransport, httpx_mock
) -> None:
    transport.max_retries = 0
    httpx_mock.add_exception(httpx.ReadTimeout("timeout"))
    with pytest.raises(RequestTimeoutError):
        transport.request("GET", "/test")


def test_request_connect_error_raises_network_error(
    transport: SyncTransport, httpx_mock
) -> None:
    transport.max_retries = 0
    httpx_mock.add_exception(httpx.ConnectError("connection refused"))
    with pytest.raises(NetworkError):
        transport.request("GET", "/test")


# --- headers ---


def test_request_sends_auth_header(transport: SyncTransport, httpx_mock) -> None:
    httpx_mock.add_response(json={"status": "ok"})
    transport.request("GET", "/health")
    request = httpx_mock.get_requests()[0]
    assert request.headers["x-api-key"] == "test-key"


def test_request_sends_user_agent(transport: SyncTransport, httpx_mock) -> None:
    httpx_mock.add_response(json={"status": "ok"})
    transport.request("GET", "/health")
    request = httpx_mock.get_requests()[0]
    assert "polymarketdata-python/" in request.headers["user-agent"]
