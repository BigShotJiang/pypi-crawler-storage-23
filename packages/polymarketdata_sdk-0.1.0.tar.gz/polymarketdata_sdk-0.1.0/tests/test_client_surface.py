from polymarketdata import PolymarketDataClient
from polymarketdata.discovery import DiscoveryAPI
from polymarketdata.history import HistoryAPI
from polymarketdata.utility import UtilityAPI


def test_client_resource_surface() -> None:
    client = PolymarketDataClient(api_key="test-key")
    assert isinstance(client.discovery, DiscoveryAPI)
    assert isinstance(client.history, HistoryAPI)
    assert isinstance(client.utility, UtilityAPI)
    client.close()


def test_context_manager_closes_transport_client() -> None:
    with PolymarketDataClient(api_key="test-key") as client:
        assert client._transport.client.is_closed is False

    assert client._transport.client.is_closed is True
