"""Tests for dataframe helpers."""

from __future__ import annotations

import pytest

pd = pytest.importorskip("pandas")

from polymarketdata.dataframe import (  # noqa: E402
    to_dataframe_books,
    to_dataframe_metrics,
    to_dataframe_prices,
    to_dataframe_records,
)
from polymarketdata.models.generated import (  # noqa: E402
    ListMetadata,
    MetricDataPoint,
    MetricsResponse,
    OrderBookSnapshot,
    PriceDataPoint,
)

_TS = "2024-01-01T00:00:00Z"
_TS2 = "2024-01-01T01:00:00Z"
_META = ListMetadata(count=1, limit=100)


def test_to_dataframe_records_from_models() -> None:
    items = [
        MetricDataPoint(t=_TS, volume=1.0, liquidity=0.5, spread=0.01),
        MetricDataPoint(t=_TS2, volume=2.0, liquidity=0.8, spread=0.02),
    ]
    df = to_dataframe_records(items)
    assert len(df) == 2
    assert "t" in df.columns
    assert "volume" in df.columns


def test_to_dataframe_metrics_from_response() -> None:
    resp = MetricsResponse(
        market_id="m1",
        resolution="1h",
        metadata=_META,
        data=[
            MetricDataPoint(t=_TS, volume=100.0, liquidity=50.0, spread=0.01),
            MetricDataPoint(t=_TS2, volume=200.0, liquidity=80.0, spread=0.02),
        ],
    )
    df = to_dataframe_metrics(resp)
    assert len(df) == 2
    assert pd.api.types.is_datetime64_any_dtype(df["t"])


def test_to_dataframe_metrics_from_list() -> None:
    items = [MetricDataPoint(t=_TS, volume=10.0, liquidity=5.0, spread=0.01)]
    df = to_dataframe_metrics(items)
    assert len(df) == 1
    assert pd.api.types.is_datetime64_any_dtype(df["t"])


def test_to_dataframe_prices_converts_timestamps() -> None:
    items = [PriceDataPoint(t=_TS, p=0.5)]
    df = to_dataframe_prices(items)
    assert pd.api.types.is_datetime64_any_dtype(df["t"])


def test_to_dataframe_books_converts_timestamps() -> None:
    items = [
        OrderBookSnapshot(
            t=_TS,
            bids=[[0.4, 10.0]],
            asks=[[0.6, 5.0]],
        )
    ]
    df = to_dataframe_books(items)
    assert pd.api.types.is_datetime64_any_dtype(df["t"])


def test_to_dataframe_metrics_empty() -> None:
    df = to_dataframe_metrics([])
    assert len(df) == 0
