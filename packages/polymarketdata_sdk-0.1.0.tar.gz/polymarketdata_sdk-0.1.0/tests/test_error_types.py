from polymarketdata.errors import (
    AuthenticationError,
    BadRequestError,
    NetworkError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    RequestTimeoutError,
    ServerError,
)


def test_error_hierarchy_fields_are_preserved() -> None:
    err = RateLimitError(
        "Too many requests",
        status_code=429,
        request_id="req_123",
        headers={"retry-after": "1"},
        raw_body={"detail": "rate_limited"},
    )

    assert err.status_code == 429
    assert err.detail == "Too many requests"
    assert err.request_id == "req_123"
    assert err.headers["retry-after"] == "1"
    assert err.raw_body == {"detail": "rate_limited"}


def test_error_types_are_constructible() -> None:
    assert isinstance(BadRequestError("bad"), Exception)
    assert isinstance(AuthenticationError("unauthorized"), Exception)
    assert isinstance(PermissionDeniedError("forbidden"), Exception)
    assert isinstance(NotFoundError("missing"), Exception)
    assert isinstance(ServerError("server"), Exception)
    assert isinstance(NetworkError("network"), Exception)
    assert isinstance(RequestTimeoutError("timeout"), Exception)
