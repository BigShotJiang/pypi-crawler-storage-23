from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def test_openapi_generation_is_up_to_date() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    result = subprocess.run(
        [sys.executable, "scripts/update_openapi.py", "--check"],
        cwd=repo_root,
        capture_output=True,
        text=True,
        check=False,
    )

    output = f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
    assert result.returncode == 0, output
