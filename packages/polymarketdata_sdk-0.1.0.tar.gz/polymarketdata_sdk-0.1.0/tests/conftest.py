"""Shared fixtures for the test suite."""

from __future__ import annotations

import pytest

from polymarketdata import PolymarketDataClient
from polymarketdata.transport import SyncTransport


@pytest.fixture
def client(httpx_mock):
    """A client instance configured for testing with mocked HTTP."""
    with PolymarketDataClient(
        api_key="test-key-123",
        max_retries=0,
    ) as c:
        yield c


@pytest.fixture
def retrying_client(httpx_mock):
    """A client with fast retry settings for testing retry logic."""
    with PolymarketDataClient(
        api_key="test-key-123",
        max_retries=2,
        retry_backoff_base=0.001,
        retry_backoff_max=0.005,
    ) as c:
        yield c


@pytest.fixture
def transport(httpx_mock):
    """A bare transport for low-level testing."""
    t = SyncTransport(
        api_key="test-key",
        base_url="https://api.polymarketdata.co/v1",
        timeout=5.0,
        max_retries=2,
        retry_backoff_base=0.001,
        retry_backoff_max=0.005,
        user_agent_extra=None,
    )
    yield t
    t.close()
