"""Tests for pagination helpers."""

from __future__ import annotations

from polymarketdata.pagination import (
    apply_item_limit,
    iter_cursor_pages,
    iter_items_from_pages,
)

# --- apply_item_limit (existing) ---


def test_apply_item_limit_unlimited() -> None:
    items = list(apply_item_limit([1, 2, 3], max_items=None))
    assert items == [1, 2, 3]


def test_apply_item_limit_capped() -> None:
    items = list(apply_item_limit([1, 2, 3, 4, 5], max_items=3))
    assert items == [1, 2, 3]


# --- iter_cursor_pages ---


class FakePage:
    def __init__(self, items: list[int], next_cursor: str | None) -> None:
        self.items = items
        self.next_cursor = next_cursor


def test_iter_cursor_pages_follows_cursors() -> None:
    pages_data = [
        FakePage([1, 2], "cur2"),
        FakePage([3, 4], "cur3"),
        FakePage([5], None),
    ]
    call_count = 0

    def fetch(*, cursor: str | None, limit: int) -> FakePage:
        nonlocal call_count
        page = pages_data[call_count]
        call_count += 1
        return page

    pages = list(
        iter_cursor_pages(fetch, page_size=10, get_next_cursor=lambda p: p.next_cursor)
    )
    assert len(pages) == 3
    assert call_count == 3


def test_iter_cursor_pages_stops_at_max_pages() -> None:
    pages_data = [
        FakePage([1], "cur2"),
        FakePage([2], "cur3"),
        FakePage([3], None),
    ]
    call_count = 0

    def fetch(*, cursor: str | None, limit: int) -> FakePage:
        nonlocal call_count
        page = pages_data[call_count]
        call_count += 1
        return page

    pages = list(
        iter_cursor_pages(
            fetch, page_size=10, max_pages=2, get_next_cursor=lambda p: p.next_cursor
        )
    )
    assert len(pages) == 2
    assert call_count == 2


def test_iter_cursor_pages_stops_on_null_cursor() -> None:
    call_count = 0

    def fetch(*, cursor: str | None, limit: int) -> FakePage:
        nonlocal call_count
        call_count += 1
        return FakePage([1], None)

    pages = list(
        iter_cursor_pages(fetch, page_size=10, get_next_cursor=lambda p: p.next_cursor)
    )
    assert len(pages) == 1
    assert call_count == 1


# --- iter_items_from_pages ---


def test_iter_items_from_pages_flattens() -> None:
    pages = [FakePage([1, 2, 3], "c"), FakePage([4, 5, 6], None)]
    items = list(iter_items_from_pages(iter(pages), get_items=lambda p: p.items))
    assert items == [1, 2, 3, 4, 5, 6]


def test_iter_items_from_pages_respects_max_items() -> None:
    pages = [FakePage([1, 2, 3], "c"), FakePage([4, 5, 6], None)]
    items = list(
        iter_items_from_pages(iter(pages), get_items=lambda p: p.items, max_items=5)
    )
    assert items == [1, 2, 3, 4, 5]
