"""Full-stack integration tests: client -> resource -> transport -> mock."""

from __future__ import annotations

import pytest

from polymarketdata import PolymarketDataClient
from polymarketdata.errors import AuthenticationError

_META = {"count": 1, "limit": 100, "next_cursor": None}


def test_full_stack_health(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/health",
        json={"status": "ok"},
    )
    result = client.utility.health()
    assert result.status == "ok"
    assert result.raw is not None
    assert result.meta is not None


def test_full_stack_list_series(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        json={
            "metadata": _META,
            "data": [{"id": "s1", "slug": "test", "title": "Test Series"}],
        },
    )
    result = client.discovery.list_series(search="test")
    assert len(result.data) == 1
    assert result.data[0].title == "Test Series"


def test_full_stack_iter_series_pagination(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "metadata": {"count": 1, "limit": 100, "next_cursor": "p2"},
            "data": [{"id": "s1", "slug": "a", "title": "A"}],
        },
    )
    httpx_mock.add_response(
        json={
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
            "data": [{"id": "s2", "slug": "b", "title": "B"}],
        },
    )
    items = list(client.discovery.iter_series())
    assert len(items) == 2


def test_full_stack_get_market_metrics(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "resolution": "1h",
            "data": [
                {"t": "2024-01-01T00:00:00Z", "volume": 42.0, "liquidity": 10.0, "spread": 0.01}
            ],
            "metadata": _META,
        },
    )
    result = client.history.get_market_metrics(
        "m1", start_ts=1704067200, end_ts=1704153600, resolution="1h"
    )
    assert result.data[0].volume == 42.0


def test_full_stack_error_propagation(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        status_code=401,
        json={"detail": "Invalid API key"},
    )
    with pytest.raises(AuthenticationError) as exc_info:
        client.utility.health()
    assert exc_info.value.status_code == 401


def test_full_stack_retry_then_success(
    retrying_client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        status_code=429,
        json={"detail": "rate limited"},
    )
    httpx_mock.add_response(
        json={"status": "ok"},
    )
    result = retrying_client.utility.health()
    assert result.status == "ok"
    assert len(httpx_mock.get_requests()) == 2
