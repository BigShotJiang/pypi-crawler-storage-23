from polymarketdata import (
    AuthenticationError,
    PolymarketDataClient,
    Resolution,
    SortField,
    SortOrder,
    TagsMatchMode,
)


def test_public_exports_are_importable() -> None:
    assert PolymarketDataClient is not None
    assert AuthenticationError is not None
    assert Resolution.ONE_HOUR.value == "1h"
    assert SortField.UPDATED_AT.value == "updated_at"
    assert SortOrder.DESC.value == "desc"
    assert TagsMatchMode.ANY.value == "any"
