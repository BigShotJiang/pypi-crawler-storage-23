"""Tests for parameter normalization helpers."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from polymarketdata._params import build_query_params, normalize_tags, normalize_timestamp
from polymarketdata.types import Resolution, SortField, SortOrder

# --- normalize_timestamp ---


def test_normalize_timestamp_aware_datetime_epoch() -> None:
    dt = datetime(2024, 1, 15, 12, 0, 0, tzinfo=timezone.utc)
    result = normalize_timestamp(dt, "start_ts")
    assert result == str(int(dt.timestamp()))


def test_normalize_timestamp_aware_datetime_date_param() -> None:
    dt = datetime(2024, 6, 15, 14, 30, 0, tzinfo=timezone.utc)
    result = normalize_timestamp(dt, "start_date_min")
    assert result == "2024-06-15"


def test_normalize_timestamp_naive_datetime_raises() -> None:
    dt = datetime(2024, 1, 15, 12, 0, 0)
    with pytest.raises(ValueError, match="naive datetime"):
        normalize_timestamp(dt, "start_ts")


def test_normalize_timestamp_string_passthrough() -> None:
    assert normalize_timestamp("2024-01-15T00:00:00Z", "start_ts") == "2024-01-15T00:00:00Z"


def test_normalize_timestamp_int() -> None:
    assert normalize_timestamp(1705276800, "start_ts") == "1705276800"


def test_normalize_timestamp_float() -> None:
    assert normalize_timestamp(1705276800.5, "start_ts") == "1705276800"


# --- normalize_tags ---


def test_normalize_tags_list_to_csv() -> None:
    assert normalize_tags(["politics", "sports"]) == "politics,sports"


def test_normalize_tags_string_passthrough() -> None:
    assert normalize_tags("politics") == "politics"


def test_normalize_tags_none() -> None:
    assert normalize_tags(None) is None


# --- build_query_params ---


def test_build_query_params_filters_none() -> None:
    result = build_query_params(search="test", cursor=None, limit=10)
    assert result == {"search": "test", "limit": "10"}
    assert "cursor" not in result


def test_build_query_params_converts_enums() -> None:
    result = build_query_params(
        sort=SortField.UPDATED_AT,
        order=SortOrder.DESC,
        resolution=Resolution.ONE_HOUR,
    )
    assert result == {"sort": "updated_at", "order": "desc", "resolution": "1h"}


def test_build_query_params_converts_numbers() -> None:
    result = build_query_params(limit=100, timeout=30.5)
    assert result == {"limit": "100", "timeout": "30.5"}
