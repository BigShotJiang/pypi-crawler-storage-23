"""Tests for the utility API resource."""

from __future__ import annotations

from polymarketdata import PolymarketDataClient

_USAGE_LIMITS = {
    "requests_per_minute": 60,
    "requests_remaining": 450,
    "granularity_allowed": "1m",
    "max_history_days": "365",
}


def test_health_returns_liveness_response(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/health",
        json={"status": "ok"},
        headers={"x-request-id": "req_h1"},
    )
    result = client.utility.health()
    assert result.status == "ok"


def test_health_attaches_raw_and_meta(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/health",
        json={"status": "ok"},
        headers={"x-request-id": "req_h2"},
    )
    result = client.utility.health()
    assert result.raw is not None
    assert result.meta is not None
    assert result.meta.status_code == 200
    assert result.meta.request_id == "req_h2"


def test_usage_returns_usage_response(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/usage",
        json={
            "plan": "pro",
            "organization": "Acme",
            "limits": _USAGE_LIMITS,
            "reset_at": 1708900800,
        },
        headers={"x-request-id": "req_u1"},
    )
    result = client.utility.usage()
    assert result.plan == "pro"
    assert result.limits.requests_remaining == 450
    assert result.reset_at == 1708900800


def test_usage_attaches_meta(client: PolymarketDataClient, httpx_mock) -> None:
    httpx_mock.add_response(
        url="https://api.polymarketdata.co/v1/usage",
        json={
            "plan": "free",
            "organization": None,
            "limits": _USAGE_LIMITS,
            "reset_at": 1708900800,
        },
        headers={"x-request-id": "req_u2"},
    )
    result = client.utility.usage()
    assert result.meta is not None
    assert result.meta.request_id == "req_u2"
