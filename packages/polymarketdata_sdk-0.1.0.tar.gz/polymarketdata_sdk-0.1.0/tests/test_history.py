"""Tests for the history API resource."""

from __future__ import annotations

from datetime import datetime, timezone

from polymarketdata import PolymarketDataClient, Resolution
from polymarketdata.models.generated import (
    MetricDataPoint,
    OrderBookSnapshot,
    PriceDataPoint,
)

_META = {"count": 1, "limit": 100, "next_cursor": None}
_TS = "2024-01-01T00:00:00Z"
_TS2 = "2024-01-01T01:00:00Z"


# --- get_market_metrics ---


def test_get_market_metrics_sends_correct_params(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "market-1",
            "resolution": "1h",
            "data": [],
            "metadata": _META,
        }
    )
    client.history.get_market_metrics(
        "market-1",
        start_ts=1704067200,
        end_ts=1704153600,
        resolution=Resolution.ONE_HOUR,
        limit=50,
    )
    request = httpx_mock.get_requests()[0]
    assert "/markets/market-1/metrics" in str(request.url)
    assert request.url.params["start_ts"] == "1704067200"
    assert request.url.params["end_ts"] == "1704153600"
    assert request.url.params["resolution"] == "1h"
    assert request.url.params["limit"] == "50"


def test_get_market_metrics_parses_response(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "resolution": "1h",
            "data": [
                {"t": _TS, "volume": 100.5, "liquidity": 50.0, "spread": 0.01},
                {"t": _TS2, "volume": 102.3, "liquidity": 55.0, "spread": 0.02},
            ],
            "metadata": {"count": 2, "limit": 100, "next_cursor": None},
        },
    )
    result = client.history.get_market_metrics(
        "m1", start_ts=1704067200, end_ts=1704153600, resolution="1h"
    )
    assert len(result.data) == 2
    assert result.data[0].volume == 100.5
    assert result.data[0].t == _TS


def test_history_timestamps_converted_from_datetime(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={"market_id": "m1", "resolution": "1h", "data": [], "metadata": _META}
    )
    start = datetime(2024, 1, 1, tzinfo=timezone.utc)
    end = datetime(2024, 1, 2, tzinfo=timezone.utc)
    client.history.get_market_metrics(
        "m1", start_ts=start, end_ts=end, resolution="1h"
    )
    request = httpx_mock.get_requests()[0]
    assert request.url.params["start_ts"] == str(int(start.timestamp()))
    assert request.url.params["end_ts"] == str(int(end.timestamp()))


# --- get_market_prices ---


def test_get_market_prices_parses_response(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "resolution": "1h",
            "tokens": {"Yes": "tok1", "No": "tok2"},
            "data": {
                "Yes": [{"t": _TS, "p": 0.45}],
                "No": [{"t": _TS, "p": 0.55}],
            },
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
        },
    )
    result = client.history.get_market_prices(
        "m1", start_ts=1704067200, end_ts=1704153600, resolution="1h"
    )
    assert "Yes" in result.data
    assert result.data["Yes"][0].p == 0.45


# --- get_token_prices ---


def test_get_token_prices_uses_token_path(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "token_id": "tok_abc",
            "token_label": "Yes",
            "resolution": "1h",
            "data": [],
            "metadata": _META,
        }
    )
    client.history.get_token_prices(
        "tok_abc", start_ts=1704067200, end_ts=1704153600, resolution="1h"
    )
    request = httpx_mock.get_requests()[0]
    assert "/tokens/tok_abc/prices" in str(request.url)


def test_get_token_prices_parses_response(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "token_id": "tok_abc",
            "token_label": "Yes",
            "resolution": "1h",
            "data": [{"t": _TS, "p": 0.72}],
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
        },
    )
    result = client.history.get_token_prices(
        "tok_abc", start_ts=1704067200, end_ts=1704153600, resolution="1h"
    )
    assert len(result.data) == 1
    assert result.data[0].p == 0.72
    assert isinstance(result.data[0], PriceDataPoint)


# --- get_market_books ---


def test_get_market_books_parses_response(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "resolution": "1h",
            "tokens": {"Yes": "tok1", "No": "tok2"},
            "data": {
                "Yes": [{"t": _TS, "bids": [[0.4, 10.0]], "asks": [[0.6, 5.0]]}],
            },
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
        },
    )
    result = client.history.get_market_books(
        "m1", start_ts=1704067200, end_ts=1704153600, resolution="1h"
    )
    yes_snaps = result.data["Yes"]
    assert len(yes_snaps) == 1
    assert yes_snaps[0].bids == [[0.4, 10.0]]


# --- get_token_books ---


def test_get_token_books_uses_token_path(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "token_id": "tok_abc",
            "token_label": "Yes",
            "resolution": "1h",
            "data": [],
            "metadata": _META,
        }
    )
    client.history.get_token_books(
        "tok_abc", start_ts=1704067200, end_ts=1704153600, resolution="1h"
    )
    request = httpx_mock.get_requests()[0]
    assert "/tokens/tok_abc/books" in str(request.url)


def test_get_token_books_parses_response(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "token_id": "tok_abc",
            "token_label": "Yes",
            "resolution": "1h",
            "data": [{"t": _TS, "bids": [[0.4, 10.0]], "asks": [[0.6, 5.0]]}],
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
        },
    )
    result = client.history.get_token_books(
        "tok_abc", start_ts=1704067200, end_ts=1704153600, resolution="1h"
    )
    assert len(result.data) == 1
    assert isinstance(result.data[0], OrderBookSnapshot)
    assert result.data[0].asks == [[0.6, 5.0]]


# --- iter_market_metrics ---


def test_iter_market_metrics_auto_paginates(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "resolution": "1h",
            "data": [{"t": _TS, "volume": 10.0, "liquidity": 5.0, "spread": 0.01}],
            "metadata": {"count": 1, "limit": 100, "next_cursor": "p2"},
        },
    )
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "resolution": "1h",
            "data": [{"t": _TS2, "volume": 20.0, "liquidity": 8.0, "spread": 0.02}],
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
        },
    )
    points = list(
        client.history.iter_market_metrics(
            "m1", start_ts=1704067200, end_ts=1704153600, resolution="1h"
        )
    )
    assert len(points) == 2
    assert all(isinstance(p, MetricDataPoint) for p in points)


# --- iter_token_prices ---


def test_iter_token_prices_auto_paginates(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "token_id": "tok1",
            "token_label": "Yes",
            "resolution": "1h",
            "data": [{"t": _TS, "p": 0.45}],
            "metadata": {"count": 1, "limit": 100, "next_cursor": "p2"},
        },
    )
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "token_id": "tok1",
            "token_label": "Yes",
            "resolution": "1h",
            "data": [{"t": _TS2, "p": 0.47}],
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
        },
    )
    points = list(
        client.history.iter_token_prices(
            "tok1", start_ts=1704067200, end_ts=1704153600, resolution="1h"
        )
    )
    assert len(points) == 2


# --- iter_market_prices_pages ---


def test_iter_market_prices_pages_yields_pages(
    client: PolymarketDataClient, httpx_mock
) -> None:
    httpx_mock.add_response(
        json={
            "market_id": "m1",
            "resolution": "1h",
            "tokens": {"Yes": "tok1"},
            "data": {"Yes": [{"t": _TS, "p": 0.45}]},
            "metadata": {"count": 1, "limit": 100, "next_cursor": None},
        },
    )
    pages = list(
        client.history.iter_market_prices_pages(
            "m1", start_ts=1704067200, end_ts=1704153600, resolution="1h"
        )
    )
    assert len(pages) == 1
    assert "Yes" in pages[0].data
