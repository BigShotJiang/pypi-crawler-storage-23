## Summary

-

## Checklist

- [ ] Tests added or updated for behavior changes.
- [ ] `uv run ruff check .` passes.
- [ ] `uv run mypy src scripts` passes.
- [ ] `uv run pytest` passes.
- [ ] `uv run python scripts/update_openapi.py --check` passes.
- [ ] Docs/examples updated (if needed).
