"""Moss Agent - Lightweight wrapper for LiveKit Agents.

Provides obfuscation of proprietary configuration and simplified agent setup.
All imports should come from moss_agent - users should never import from livekit directly.
"""

from .session import MossAgentSession
from .config import MossConfig
from .metrics import MossMetrics
from .diagnostics import MetricsCollector

# Re-export LiveKit core types (hide livekit imports)
from livekit.agents import (
    JobContext,
    WorkerOptions,
    WorkerType,
    cli,
    AutoSubscribe,
    metrics as agent_metrics,
    MetricsCollectedEvent,
    llm,
)
from livekit.agents.voice import Agent, RunContext
from livekit.agents.voice.events import (
    UserInputTranscribedEvent,
    AgentStateChangedEvent,
)
from livekit.agents.voice.room_io import RoomInputOptions
from livekit import api, rtc

# Re-export commonly used plugins (hide livekit.plugins imports)
from livekit.plugins import silero, noise_cancellation

__version__ = "1.0.0-beta.6"

__all__ = [
    # Core moss-agent classes
    "MossAgentSession",
    "MossConfig",
    "MossMetrics",
    "MetricsCollector",

    # LiveKit core (re-exported)
    "JobContext",
    "WorkerOptions",
    "WorkerType",
    "cli",
    "AutoSubscribe",
    "agent_metrics",
    "MetricsCollectedEvent",
    "llm",

    # Voice agents
    "Agent",
    "RunContext",

    # Voice events
    "UserInputTranscribedEvent",
    "AgentStateChangedEvent",

    # Room IO
    "RoomInputOptions",

    # API and RTC
    "api",
    "rtc",

    # Plugins
    "silero",
    "noise_cancellation",
]
