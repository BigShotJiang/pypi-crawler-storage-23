# Tests for MCP resources
