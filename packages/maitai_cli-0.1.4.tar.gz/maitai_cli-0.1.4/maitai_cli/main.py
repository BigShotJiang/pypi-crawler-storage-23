"""
Maitai CLI - Command-line interface for the Maitai Platform Developer API.

API docs: See docs/internal and docs/external in the maitai-mono repository.
"""

from typing import Optional

import typer

# Import generated commands and register them
from maitai_cli.commands_generated import register_commands
from maitai_cli.config import clear_config, get_api_key, get_base_url, save_config
from maitai_cli.utils import console, get_client, handle_api_errors, print_json
from rich.console import Console

app = typer.Typer(
    name="maitai",
    help="Maitai Platform Developer API CLI (api/v1). API docs: docs/internal and docs/external in maitai-mono. Create API keys at https://portal.trymaitai.com → Settings → API Keys.",
    no_args_is_help=True,
)

# Register generated resource commands
register_commands(app)


# ─── Auth (hand-written) ────────────────────────────────────────────────────


@app.command()
def login(
    api_key: Optional[str] = typer.Option(
        None,
        "--api-key",
        "-k",
        help="Maitai API key (or set MAITAI_API_KEY)",
    ),
    base_url: Optional[str] = typer.Option(
        None,
        "--base-url",
        "-u",
        help="API base URL (default: https://api.trymaitai.ai/api/v1)",
    ),
):
    """Authenticate and store your API key for future commands."""
    key = api_key or get_api_key()
    if not key:
        console.print(
            "[yellow]Provide your API key via --api-key, or set MAITAI_API_KEY.[/yellow]"
        )
        console.print(
            "Create keys at [link=https://portal.trymaitai.com]portal.trymaitai.com[/link] → Settings → API Keys"
        )
        raise typer.Exit(1)
    save_config(key, base_url)
    console.print("[green]✓ Authenticated. API key saved to ~/.maitai/config[/green]")


@app.command()
def logout():
    """Remove stored credentials."""
    clear_config()
    console.print("[green]✓ Logged out. Credentials removed.[/green]")


@app.command()
def docs():
    """Show API documentation references."""
    console.print("[bold]Maitai Developer API (api/v1)[/bold]")
    console.print()
    console.print("  [link=https://docs.trymaitai.ai]External docs[/link]")
    console.print(
        "  [link=https://docs.trymaitai.ai/api-reference]API Reference[/link]"
    )
    console.print(
        "  [link=https://portal.trymaitai.com]Portal (create API keys)[/link]"
    )
    console.print()
    console.print("[dim]In maitai-mono repo:[/dim]")
    console.print("  docs/external/openapi.yaml  - OpenAPI spec")
    console.print("  docs/external/api-reference/ - API reference pages")
    console.print("  docs/internal/              - Internal design docs")


@app.command()
def whoami():
    """Show current authentication status."""
    key = get_api_key()
    base_url = get_base_url()
    if not key:
        console.print("[red]Not authenticated.[/red]")
        console.print("Run [bold]maitai login[/bold] or set MAITAI_API_KEY.")
        raise typer.Exit(1)
    console.print("[green]Authenticated[/green]")
    console.print(f"  Base URL: {base_url}")
    console.print(f"  API key: {key[:8]}...{key[-4:]}")


# ─── Raw API (hand-written) ──────────────────────────────────────────────────


@app.command("api")
@handle_api_errors
def raw_api(
    method: str = typer.Argument("GET", help="HTTP method"),
    path: str = typer.Argument(..., help="API path (e.g. /applications)"),
    body: Optional[str] = typer.Option(
        None, "--body", "-b", help="JSON body for POST/PUT"
    ),
):
    """Make a raw API request. Path is relative to base URL (e.g. /applications)."""
    import json

    client = get_client()
    path = path if path.startswith("/") else f"/{path}"
    json_body = json.loads(body) if body else None
    if method.upper() == "GET":
        r = client.get(path)
    elif method.upper() == "POST":
        r = client.post(path, json=json_body)
    elif method.upper() == "PUT":
        r = client.put(path, json=json_body)
    elif method.upper() == "DELETE":
        r = client.delete(path)
    else:
        console.print("[red]Unsupported method. Use GET, POST, PUT, or DELETE.[/red]")
        raise typer.Exit(1)
    print_json(r)


def main():
    """Entry point."""
    try:
        app()
    except KeyboardInterrupt:
        raise typer.Exit(130)


if __name__ == "__main__":
    main()
