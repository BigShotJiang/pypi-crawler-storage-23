"""Generated CLI commands from OpenAPI spec. Do not edit by hand."""

from typing import Optional

import typer
from maitai_cli.utils import console, get_client, handle_api_errors, print_json


@handle_api_errors
def _agents(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List agents"),
    get_id: Optional[int] = typer.Option(None, "--get", "-g", help="Get by ID"),
    create_body: Optional[str] = typer.Option(
        None, "--create", "-c", help="Create (JSON body)"
    ),
    update_id: Optional[int] = typer.Option(
        None, "--update", "-u", help="Update by ID"
    ),
    delete_id: Optional[int] = typer.Option(
        None, "--delete", "-d", help="Delete by ID"
    ),
    include_subagents: Optional[bool] = typer.Option(
        None, "--include-subagents", help="Include sub-agents in the response."
    ),
    include_actions: Optional[bool] = typer.Option(
        None, "--include-actions", help="Include agent actions in the response."
    ),
    detailed: Optional[bool] = typer.Option(
        None, "--detailed", help="Include full configuration details in results."
    ),
    page: Optional[int] = typer.Option(
        None, "--page", help="Page number (1-indexed) for page-based pagination."
    ),
    page_size: Optional[int] = typer.Option(
        None, "--page-size", help="Number of items per page."
    ),
    version: Optional[str] = typer.Option(
        None, "--version", help="Filter by version string."
    ),
):
    """/agents - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if include_subagents is not None:
        params["include_subagents"] = include_subagents
    if include_actions is not None:
        params["include_actions"] = include_actions
    if detailed is not None:
        params["detailed"] = detailed
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if version is not None:
        params["version"] = version
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/agents", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/agents/{get_id}", params=params)
        print_json(r.get("data"))
        return
    if create_body:
        import json

        body = json.loads(create_body)
        r = client.post("/agents", json=body)
        print_json(r.get("data"))
        return
    if update_id is not None:
        import json

        body = json.loads(typer.prompt("JSON body for update") or "{}")
        r = client.put(f"/agents/{update_id}", json=body)
        print_json(r.get("data"))
        return
    if delete_id is not None:
        client.delete(f"/agents/{delete_id}")
        console.print("[green]Deleted.[/green]")
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _applications(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List applications"),
    get_id: Optional[int] = typer.Option(None, "--get", "-g", help="Get by ID"),
    create_body: Optional[str] = typer.Option(
        None, "--create", "-c", help="Create (JSON body)"
    ),
    update_id: Optional[int] = typer.Option(
        None, "--update", "-u", help="Update by ID"
    ),
    delete_id: Optional[int] = typer.Option(
        None, "--delete", "-d", help="Delete by ID"
    ),
    detailed: bool = typer.Option(False, "--detailed", help="Include full config"),
):
    """/applications - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if detailed is not None:
        params["detailed"] = detailed
    if detailed:
        params["detailed"] = "true"
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/applications", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/applications/{get_id}", params=params)
        print_json(r.get("data"))
        return
    if create_body:
        import json

        body = json.loads(create_body)
        r = client.post("/applications", json=body)
        print_json(r.get("data"))
        return
    if update_id is not None:
        import json

        body = json.loads(typer.prompt("JSON body for update") or "{}")
        r = client.put(f"/applications/{update_id}", json=body)
        print_json(r.get("data"))
        return
    if delete_id is not None:
        client.delete(f"/applications/{delete_id}")
        console.print("[green]Deleted.[/green]")
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _conversation_trees(
    list_cmd: bool = typer.Option(
        False, "--list", "-l", help="List conversation trees"
    ),
    get_id: Optional[str] = typer.Option(None, "--get", "-g", help="Get by ID"),
    delete_id: Optional[str] = typer.Option(
        None, "--delete", "-d", help="Delete by ID"
    ),
    application_id: Optional[int] = typer.Option(
        None, "--application-id", help="Filter by application ID."
    ),
):
    """/conversation-trees - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if application_id is not None:
        params["application_id"] = application_id
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/conversation-trees", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/conversation-trees/{get_id}", params=params)
        print_json(r.get("data"))
        return
    if delete_id is not None:
        client.delete(f"/conversation-trees/{delete_id}")
        console.print("[green]Deleted.[/green]")
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _datasets(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List datasets"),
    get_id: Optional[int] = typer.Option(None, "--get", "-g", help="Get by ID"),
    create_body: Optional[str] = typer.Option(
        None, "--create", "-c", help="Create (JSON body)"
    ),
    update_id: Optional[int] = typer.Option(
        None, "--update", "-u", help="Update by ID"
    ),
    delete_id: Optional[int] = typer.Option(
        None, "--delete", "-d", help="Delete by ID"
    ),
):
    """/datasets - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/datasets", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/datasets/{get_id}", params=params)
        print_json(r.get("data"))
        return
    if create_body:
        import json

        body = json.loads(create_body)
        r = client.post("/datasets", json=body)
        print_json(r.get("data"))
        return
    if update_id is not None:
        import json

        body = json.loads(typer.prompt("JSON body for update") or "{}")
        r = client.put(f"/datasets/{update_id}", json=body)
        print_json(r.get("data"))
        return
    if delete_id is not None:
        client.delete(f"/datasets/{delete_id}")
        console.print("[green]Deleted.[/green]")
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _evaluations(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List evaluations"),
    get_id: Optional[str] = typer.Option(None, "--get", "-g", help="Get by ID"),
    create_body: Optional[str] = typer.Option(
        None, "--create", "-c", help="Create (JSON body)"
    ),
    full: Optional[bool] = typer.Option(
        None, "--full", help="Include full evaluation details."
    ),
):
    """/evaluations - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if full is not None:
        params["full"] = full
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/evaluations", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/evaluations/{get_id}", params=params)
        print_json(r.get("data"))
        return
    if create_body:
        import json

        body = json.loads(create_body)
        r = client.post("/evaluations", json=body)
        print_json(r.get("data"))
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _finetune_runs(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List finetune runs"),
    get_id: Optional[int] = typer.Option(None, "--get", "-g", help="Get by ID"),
    create_body: Optional[str] = typer.Option(
        None, "--create", "-c", help="Create (JSON body)"
    ),
    status: Optional[str] = typer.Option(
        None, "--status", help="Filter by status (can be specified multiple times)"
    ),
):
    """/finetune-runs - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if status is not None:
        params["status"] = status
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/finetune-runs", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/finetune-runs/{get_id}", params=params)
        print_json(r.get("data"))
        return
    if create_body:
        import json

        body = json.loads(create_body)
        r = client.post("/finetune-runs", json=body)
        print_json(r.get("data"))
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _intent_groups(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List intent groups"),
    get_id: Optional[int] = typer.Option(None, "--get", "-g", help="Get by ID"),
    detailed: Optional[bool] = typer.Option(
        None, "--detailed", help="Include full configuration details in results."
    ),
    start_date: Optional[int] = typer.Option(
        None, "--start-date", help="Start of date range as Unix timestamp (millisecond"
    ),
    end_date: Optional[int] = typer.Option(
        None, "--end-date", help="End of date range as Unix timestamp (milliseconds)"
    ),
    include_messages: Optional[bool] = typer.Option(
        None, "--include-messages", help="Include full message history in results."
    ),
):
    """/intent-groups - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if detailed is not None:
        params["detailed"] = detailed
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if include_messages is not None:
        params["include_messages"] = include_messages
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/intent-groups", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/intent-groups/{get_id}", params=params)
        print_json(r.get("data"))
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _models(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List models"),
    model_type: Optional[str] = typer.Option(
        None, "--model-type", help="Filter by model type (can be specified multiple ti"
    ),
    available: bool = typer.Option(
        False, "--available", "-a", help="List available base models"
    ),
):
    """/models - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if model_type is not None:
        params["model_type"] = model_type
    if available:
        r = client.get("/models/available")
        print_json(r.get("data", []))
        return
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/models", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _requests(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List requests"),
    get_id: Optional[int] = typer.Option(None, "--get", "-g", help="Get by ID"),
    application_id: Optional[int] = typer.Option(
        None, "--application-id", help="Filter by application ID."
    ),
    intent_id: Optional[int] = typer.Option(
        None, "--intent-id", help="Filter by intent ID."
    ),
    start_date: Optional[int] = typer.Option(
        None, "--start-date", help="Start of date range as Unix timestamp (millisecond"
    ),
    end_date: Optional[int] = typer.Option(
        None, "--end-date", help="End of date range as Unix timestamp (milliseconds)"
    ),
    include_messages: Optional[bool] = typer.Option(
        None, "--include-messages", help="Include full message history in results."
    ),
):
    """/requests - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if application_id is not None:
        params["application_id"] = application_id
    if intent_id is not None:
        params["intent_id"] = intent_id
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if include_messages is not None:
        params["include_messages"] = include_messages
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/requests", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/requests/{get_id}", params=params)
        print_json(r.get("data"))
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _sentinels(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List sentinels"),
    get_id: Optional[int] = typer.Option(None, "--get", "-g", help="Get by ID"),
    create_body: Optional[str] = typer.Option(
        None, "--create", "-c", help="Create (JSON body)"
    ),
    update_id: Optional[int] = typer.Option(
        None, "--update", "-u", help="Update by ID"
    ),
    delete_id: Optional[int] = typer.Option(
        None, "--delete", "-d", help="Delete by ID"
    ),
):
    """/sentinels - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/sentinels", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/sentinels/{get_id}", params=params)
        print_json(r.get("data"))
        return
    if create_body:
        import json

        body = json.loads(create_body)
        r = client.post("/sentinels", json=body)
        print_json(r.get("data"))
        return
    if update_id is not None:
        import json

        body = json.loads(typer.prompt("JSON body for update") or "{}")
        r = client.put(f"/sentinels/{update_id}", json=body)
        print_json(r.get("data"))
        return
    if delete_id is not None:
        client.delete(f"/sentinels/{delete_id}")
        console.print("[green]Deleted.[/green]")
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _sessions(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List sessions"),
    get_id: Optional[str] = typer.Option(None, "--get", "-g", help="Get by ID"),
    application_id: Optional[int] = typer.Option(
        None, "--application-id", help="Filter by application ID."
    ),
):
    """/sessions - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if application_id is not None:
        params["application_id"] = application_id
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/sessions", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/sessions/{get_id}", params=params)
        print_json(r.get("data"))
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _test_runs(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List test runs"),
    get_id: Optional[int] = typer.Option(None, "--get", "-g", help="Get by ID"),
    create_body: Optional[str] = typer.Option(
        None, "--create", "-c", help="Create (JSON body)"
    ),
    delete_id: Optional[int] = typer.Option(
        None, "--delete", "-d", help="Delete by ID"
    ),
    intent_group_id: Optional[int] = typer.Option(
        None, "--intent-group-id", help="intent_group_id"
    ),
):
    """/test-runs - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if intent_group_id is not None:
        params["intent_group_id"] = intent_group_id
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/test-runs", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/test-runs/{get_id}", params=params)
        print_json(r.get("data"))
        return
    if create_body:
        import json

        body = json.loads(create_body)
        r = client.post("/test-runs", json=body)
        print_json(r.get("data"))
        return
    if delete_id is not None:
        client.delete(f"/test-runs/{delete_id}")
        console.print("[green]Deleted.[/green]")
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


@handle_api_errors
def _test_sets(
    list_cmd: bool = typer.Option(False, "--list", "-l", help="List test sets"),
    get_id: Optional[int] = typer.Option(None, "--get", "-g", help="Get by ID"),
    create_body: Optional[str] = typer.Option(
        None, "--create", "-c", help="Create (JSON body)"
    ),
    update_id: Optional[int] = typer.Option(
        None, "--update", "-u", help="Update by ID"
    ),
    delete_id: Optional[int] = typer.Option(
        None, "--delete", "-d", help="Delete by ID"
    ),
    start_date: Optional[int] = typer.Option(
        None, "--start-date", help="Start of date range as Unix timestamp (millisecond"
    ),
    end_date: Optional[int] = typer.Option(
        None, "--end-date", help="End of date range as Unix timestamp (milliseconds)"
    ),
):
    """/test-sets - generated from OpenAPI."""
    client = get_client()
    params: dict = {}
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if list_cmd or (not get_id and not create_body and not update_id and not delete_id):
        r = client.get("/test-sets", params=params)
        print_json(r.get("data", []), r.get("pagination"))
        return
    if get_id is not None:
        r = client.get(f"/test-sets/{get_id}", params=params)
        print_json(r.get("data"))
        return
    if create_body:
        import json

        body = json.loads(create_body)
        r = client.post("/test-sets", json=body)
        print_json(r.get("data"))
        return
    if update_id is not None:
        import json

        body = json.loads(typer.prompt("JSON body for update") or "{}")
        r = client.put(f"/test-sets/{update_id}", json=body)
        print_json(r.get("data"))
        return
    if delete_id is not None:
        client.delete(f"/test-sets/{delete_id}")
        console.print("[green]Deleted.[/green]")
        return
    typer.echo(
        'Use --list, --get ID, --create \'{"key":"val"}\', --update ID, or --delete ID'
    )


def register_commands(typer_app: typer.Typer) -> None:
    """Register all generated commands with the Typer app."""
    typer_app.command(name="agents")(_agents)
    typer_app.command(name="applications")(_applications)
    typer_app.command(name="conversation-trees")(_conversation_trees)
    typer_app.command(name="datasets")(_datasets)
    typer_app.command(name="evaluations")(_evaluations)
    typer_app.command(name="finetune-runs")(_finetune_runs)
    typer_app.command(name="intent-groups")(_intent_groups)
    typer_app.command(name="models")(_models)
    typer_app.command(name="requests")(_requests)
    typer_app.command(name="sentinels")(_sentinels)
    typer_app.command(name="sessions")(_sessions)
    typer_app.command(name="test-runs")(_test_runs)
    typer_app.command(name="test-sets")(_test_sets)
