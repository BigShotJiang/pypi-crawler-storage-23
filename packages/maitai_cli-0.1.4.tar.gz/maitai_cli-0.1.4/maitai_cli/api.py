"""
API client for the Maitai Platform Developer API (api/v1).

API documentation: docs/internal and docs/external in the maitai-mono repo.
Base URL: https://api.trymaitai.ai/api/v1
Authentication: X-Maitai-Api-Key header (create keys in Portal → Settings → API Keys).
"""

from typing import Any

import httpx
from maitai_cli.config import get_api_key, get_base_url


class APIError(Exception):
    """Raised when an API request fails."""

    def __init__(self, status_code: int, message: str, details: dict | None = None):
        self.status_code = status_code
        self.message = message
        self.details = details or {}
        super().__init__(f"{status_code}: {message}")


class APIClient:
    """HTTP client for the Maitai Developer API."""

    def __init__(self, api_key: str | None = None, base_url: str | None = None):
        self.api_key = api_key or get_api_key()
        self.base_url = (base_url or get_base_url()).rstrip("/")
        self._client: httpx.Client | None = None

    def _get_client(self) -> httpx.Client:
        if self._client is None:
            headers = {}
            if self.api_key:
                headers["X-Maitai-Api-Key"] = self.api_key
            self._client = httpx.Client(
                base_url=self.base_url,
                headers=headers,
                timeout=30.0,
            )
        return self._client

    def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            self._client.close()
            self._client = None

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict | None = None,
        json: dict | None = None,
    ) -> dict[str, Any]:
        """Make an API request and return the parsed JSON response."""
        if not self.api_key:
            raise APIError(
                401, "Not authenticated. Run 'maitai login' or set MAITAI_API_KEY."
            )
        client = self._get_client()
        path = path if path.startswith("/") else f"/{path}"
        r = client.request(method, path, params=params, json=json)
        try:
            body = r.json()
        except Exception:
            body = {}
        if r.status_code >= 400:
            err = body.get("error", {})
            raise APIError(
                r.status_code,
                err.get("message", r.text or str(r.status_code)),
                err.get("details"),
            )
        return body

    def get(self, path: str, params: dict | None = None) -> dict[str, Any]:
        return self._request("GET", path, params=params)

    def post(self, path: str, json: dict | None = None) -> dict[str, Any]:
        return self._request("POST", path, json=json)

    def put(self, path: str, json: dict | None = None) -> dict[str, Any]:
        return self._request("PUT", path, json=json)

    def delete(self, path: str) -> dict[str, Any]:
        return self._request("DELETE", path)
