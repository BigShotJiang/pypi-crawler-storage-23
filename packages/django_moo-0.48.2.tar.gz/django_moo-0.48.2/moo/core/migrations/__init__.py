# -*- coding: utf-8 -*-
"""
Django database migrations
"""
