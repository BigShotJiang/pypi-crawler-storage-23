class AdatConcatError(Exception):
    pass
