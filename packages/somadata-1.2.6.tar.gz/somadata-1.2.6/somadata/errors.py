class AdatBaseError(Exception):
    pass


class AdatKeyError(Exception):
    pass


class AdatMetaError(Exception):
    pass


class AnnotationsLiftingError(Exception):
    pass
