class AnnotationsReadError(Exception):
    pass


class UnknownAnnotationsFileError(Exception):
    pass


class AnnotationsMissingDataError(Exception):
    pass
