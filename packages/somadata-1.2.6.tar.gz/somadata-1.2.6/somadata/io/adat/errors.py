class AdatReadError(Exception):
    pass
