"""The root of the jabs.behavior package."""
