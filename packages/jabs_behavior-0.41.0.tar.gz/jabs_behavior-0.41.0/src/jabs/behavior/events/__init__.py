"""jabs.behavior.events package."""

from .behavior_events import BehaviorEvents, ClassLabels

__all__ = [
    "BehaviorEvents",
    "ClassLabels",
]
