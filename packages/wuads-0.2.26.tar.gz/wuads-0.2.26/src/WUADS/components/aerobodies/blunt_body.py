from ..component import PhysicalComponent
import numpy as np


class BluntBody(PhysicalComponent):
    """
    Class containing all methods and variables for a generic blunt blody
    """

    def __init__(self, params):
        """
        Initializes fuselage with given parameters.

        :param <dict> params: list of parameters to edit
        """

        # Default Values
        self.length = 0  # Length Tip to Nose (ft)
        self.width = 0  # Width (ft)
        self.height = 0  # Height (ft)
        self.a_max = 0  # Cross-sectional area at thickest point (ft^2)
        self.diameter = 0  # Average Diameter (Ft)
        self.fineness_ratio = 0  # Form Factor
        self.s_wet = 0

        self.Q = 1.1  # Interference Factor - Landing gear and wing correction
        self.laminar_percent = .05  # Laminar flow percentage

        self.weight_averages = [1/3, 1/3, 1/3]  # [Raymer, Torenbeek, NASA] - weighted averages used for weight estimation

        super().__init__(params)

        # Calculate class variables
        self.a_max = .25 * np.pi * self.diameter ** 2
        if self.diameter == 0 or self.length == 0:
            return

        self.fineness_ratio = self.length / self.diameter
        f = self.fineness_ratio
        # Torenbeek 1988 wetted area estimation
        self.s_wet = np.pi * self.diameter * self.length * (1 - 2 / f) ** (2 / 3) * (1 + 1 / (f ** 2))