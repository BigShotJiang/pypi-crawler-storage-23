#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
CipherHUB compatibility defaults.
Keep in sync with CipherHUB web_app/API so easy_encryption_tool and CipherHUB
can interoperate (encrypt/decrypt, sign/verify, hash/hmac) with same params.
"""
from __future__ import annotations

# Default plaintext (CipherHUB web_app compatible)
DEFAULT_PLAINTEXT = "你好，密码学人 CipherHUB!"

# Block cipher CBC defaults (AES128/AES256/SM4)
DEFAULT_KEY_32 = "".join(
    [str(i % 10) for i in range(32)]
)  # 01234567890123456789012345678901
DEFAULT_KEY_16 = "".join([str(i % 10) for i in range(16)])  # 0123456789012345
DEFAULT_IV_16 = "".join([str(i % 10) for i in range(16)])  # 0123456789012345

# Stream cipher GCM defaults (AES256GCM/ChaCha20Poly1305/SM4GCM)
DEFAULT_NONCE_12 = "".join([str(i % 10) for i in range(12)])  # 012345678901234567890123
DEFAULT_AAD = "密码学人 CipherHUB 默认 AAD 数据"

# ZUC defaults (key and iv both 16 bytes)
DEFAULT_ZUC_KEY = DEFAULT_KEY_16
DEFAULT_ZUC_IV = DEFAULT_IV_16

# HMAC default key (32 bytes)
DEFAULT_HMAC_KEY = DEFAULT_KEY_32

# SM2 sign/verify default signer ID (CipherHUB compatible, used in Z value)
DEFAULT_SM2_SIGNER_ID = "1234567812345678"

# ECC key exchange defaults (CipherHUB api/ecc_key_exchange.py compatible)
DEFAULT_ECC_SALT = "密码学人【CipherHUB】"
DEFAULT_ECC_ADDITIONAL_INFO = """
    Serious Cryptography
    Creative Solutions
    Mapping Digital Trust
"""
DEFAULT_ECC_DERIVED_KEY_LENGTH = 32
DEFAULT_ECC_HASH = "sha512"  # CipherHUB ECC default Sha512
