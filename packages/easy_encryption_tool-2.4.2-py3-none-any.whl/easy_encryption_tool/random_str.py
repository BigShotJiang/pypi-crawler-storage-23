#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-04-01 09:04:43
"""
Cryptographically secure random: uses secrets module (CSPRNG).
"""
import secrets
import string
import sys
import time

import click

from easy_encryption_tool import common, shell_completion
from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error

special_characters = "&=!@#$%^*()_+`"
characters: str = (
    string.ascii_lowercase + string.ascii_uppercase + string.digits + special_characters
)


def generate_random_str(length: int) -> str:
    """Generate cryptographically secure random string via secrets"""
    return "".join(secrets.choice(characters) for _ in range(length))


def generate_random_bytes(length: int) -> bytes:
    """Generate cryptographically secure random bytes for key/IV padding etc."""
    return secrets.token_bytes(length)


@click.command(name="random-str", short_help="Random string generator")
@click.option(
    "-l",
    "--length",
    required=False,
    type=click.IntRange(min=1, max=sys.maxsize),
    default=32,
    show_default=True,
    help="Min 1 byte, max length up to system max int",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file path; file must be writable",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "--no-force",
    is_flag=True,
    default=False,
    help="Do not overwrite existing output file",
)
@output_format_options
def get_random_str(
    length: int,
    output_file: str,
    no_force: bool = False,
    output_format: str | None = None,
):
    write_to_output = None
    if output_file and len(output_file) > 0:
        try:
            write_to_output = common.write_to_file(output_file, force=not no_force)
        except OSError:
            error("try write to {} failed".format(output_file))
            return

    request_id = create_request_id()
    start = time.perf_counter()

    # Generate 32 bytes per block to avoid high memory for long strings
    block_size = 32
    collected: list[str] = []
    remaining = length
    bytes_written = 0

    while remaining > 0:
        chunk_len = min(block_size, remaining)
        tmp = generate_random_str(chunk_len)
        if write_to_output is not None:
            data = tmp.encode("utf-8")
            if not write_to_output.write_bytes(data):
                return
            bytes_written += len(data)
        else:
            collected.append(tmp)
        remaining -= chunk_len

    duration_ms = (time.perf_counter() - start) * 1000

    metadata = build_metadata(
        operation="random",
        algorithm="cspng",
        encoding="utf-8",
        input_type="stdin",
        input_size=0,
        parameters={"length": length},
    )

    if write_to_output is not None:
        result = build_result(output_file=output_file, bytes_written=bytes_written)
        primary_key = "output_file"
    else:
        value = "".join(collected)
        result = build_result(value=value)
        primary_key = "value"

    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key=primary_key)


if __name__ == "__main__":
    get_random_str()
