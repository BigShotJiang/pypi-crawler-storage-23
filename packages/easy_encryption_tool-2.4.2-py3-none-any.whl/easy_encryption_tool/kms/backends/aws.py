#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""AWS KMS backend implementation."""

from __future__ import annotations

from typing import TYPE_CHECKING

from easy_encryption_tool.kms.config import KMSConfig, get_default_kms_config
from easy_encryption_tool.kms.errors import KMSError

if TYPE_CHECKING:
    pass


def _get_request_id_from_exception(exc: Exception) -> str | None:
    """Extract AWS request_id from ClientError if present."""
    try:
        if hasattr(exc, "response") and isinstance(exc.response, dict):
            meta = exc.response.get("ResponseMetadata", {})
            return meta.get("RequestId")
    except Exception:
        pass
    return None


class AWSKMSBackend:
    """AWS KMS backend for envelope encryption."""

    def __init__(
        self,
        region: str,
        endpoint_url: str | None = None,
        config: KMSConfig | None = None,
    ):
        self.region = region
        self.endpoint_url = endpoint_url
        self._config = config or get_default_kms_config()

    def _get_client(self):
        import boto3
        from botocore.config import Config

        cfg = Config(
            retries={"mode": "standard", "max_attempts": 3},
            connect_timeout=self._config.connect_timeout,
            read_timeout=self._config.read_timeout,
        )
        return boto3.client(
            "kms",
            region_name=self.region,
            endpoint_url=self.endpoint_url,
            config=cfg,
        )

    def generate_data_key(
        self,
        key_id: str,
        number_of_bytes: int,
    ) -> tuple[bytes, bytes, str | None]:
        """
        Generate data key. Returns (plaintext_dek, ciphertext_blob, request_id).
        For envelope: number_of_bytes = key_len + nonce_len (e.g. 44 for AES-256-GCM).
        Plaintext is returned as-is; caller splits into key + nonce.
        """
        try:
            client = self._get_client()
            resp = client.generate_data_key(
                KeyId=key_id,
                NumberOfBytes=number_of_bytes,
            )
            plaintext = resp["Plaintext"]
            ciphertext_blob = resp["CiphertextBlob"]
            request_id = resp.get("ResponseMetadata", {}).get("RequestId")
            return (bytes(plaintext), bytes(ciphertext_blob), request_id)
        except Exception as e:
            req_id = _get_request_id_from_exception(e)
            raise KMSError(
                f"AWS KMS GenerateDataKey failed: {e!s}"
                + (f" (request_id={req_id})" if req_id else "")
            ) from e

    def decrypt(self, ciphertext_blob: bytes, key_id: str | None = None) -> tuple[bytes, str | None]:
        """
        Decrypt ciphertext blob. Returns (plaintext, request_id).
        key_id is optional for symmetric keys - KMS extracts from blob metadata.
        """
        try:
            client = self._get_client()
            kwargs = {"CiphertextBlob": ciphertext_blob}
            if key_id:
                kwargs["KeyId"] = key_id
            resp = client.decrypt(**kwargs)
            plaintext = resp["Plaintext"]
            request_id = resp.get("ResponseMetadata", {}).get("RequestId")
            return (bytes(plaintext), request_id)
        except Exception as e:
            req_id = _get_request_id_from_exception(e)
            raise KMSError(
                f"AWS KMS Decrypt failed: {e!s}"
                + (f" (request_id={req_id})" if req_id else "")
            ) from e
