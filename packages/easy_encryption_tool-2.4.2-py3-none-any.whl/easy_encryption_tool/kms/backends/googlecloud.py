#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""Google Cloud KMS backend implementation."""

from __future__ import annotations

import base64
import json
import os
from typing import TYPE_CHECKING

from easy_encryption_tool.kms.config import KMSConfig, get_default_kms_config
from easy_encryption_tool.kms.errors import KMSError

if TYPE_CHECKING:
    pass


def _get_project_id(project_id_override: str | None) -> str | None:
    """Get Google Cloud project ID. Priority: override > env vars."""
    if project_id_override:
        return project_id_override
    return (
        os.environ.get("GOOGLE_CLOUD_PROJECT")
        or os.environ.get("GCLOUD_PROJECT")
        or os.environ.get("GCP_PROJECT")
    )


def _encode_googlecloud_enc_dek(key_id: str, ciphertext: bytes) -> bytes:
    """Encode Google Cloud KMS enc_dek: store key_id + ciphertext for decrypt.
    Decrypt API requires the key name (resource path).
    """
    payload = {
        "key_id": key_id,
        "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
    }
    return json.dumps(payload, separators=(",", ":")).encode("utf-8")


def _decode_googlecloud_enc_dek(enc_dek: bytes) -> tuple[str, bytes]:
    """Decode Google Cloud enc_dek to (key_id, ciphertext). Raises on invalid format."""
    try:
        data = json.loads(enc_dek.decode("utf-8"))
        key_id = data.get("key_id")
        ciphertext_b64 = data.get("ciphertext")
        if key_id and ciphertext_b64:
            ciphertext = base64.b64decode(ciphertext_b64)
            return (str(key_id), ciphertext)
    except (json.JSONDecodeError, UnicodeDecodeError, KeyError, ValueError):
        pass
    raise KMSError("Invalid Google Cloud KMS envelope: enc_dek format error")


def _normalize_key_id(key_id: str, region: str, project_id: str | None) -> str:
    """Normalize key_id to full resource name.
    Accepts:
    - Full: projects/PROJECT/locations/LOCATION/keyRings/RING/cryptoKeys/KEY
    - Short: key_ring_id/crypto_key_id (uses project_id from env/config, region from --kms-region)
    """
    if key_id.startswith("projects/"):
        return key_id
    if project_id and "/" in key_id:
        parts = key_id.split("/")
        if len(parts) == 2:
            key_ring_id, crypto_key_id = parts
            return (
                f"projects/{project_id}/locations/{region}/keyRings/{key_ring_id}/cryptoKeys/{crypto_key_id}"
            )
    raise KMSError(
        "Google Cloud KMS key_id must be full resource name "
        "(projects/PROJECT/locations/LOCATION/keyRings/RING/cryptoKeys/KEY) "
        "or short format (KEY_RING/CRYPTO_KEY) with --kms-project-id and --kms-region"
    )


def _get_request_id_from_exception(exc: Exception) -> str | None:
    """Extract Google Cloud request metadata from exception if present."""
    try:
        if hasattr(exc, "metadata") and isinstance(exc.metadata, dict):
            return exc.metadata.get("request-id")
    except Exception:
        pass
    return None


class GoogleCloudKMSBackend:
    """Google Cloud KMS backend for envelope encryption.

    Uses Encrypt and Decrypt APIs (no GenerateDataKey; DEK is generated locally
    then wrapped by Encrypt). Credentials from Application Default Credentials:
    1. GOOGLE_APPLICATION_CREDENTIALS env var (service account JSON)
    2. gcloud auth application-default login
    3. GCP metadata (when running on GCP Compute Engine, etc.)

    See: https://cloud.google.com/kms/docs/envelope-encryption
    """

    def __init__(
        self,
        region: str,
        endpoint_url: str | None = None,
        project_id: str | None = None,
        config: KMSConfig | None = None,
    ):
        self.region = region
        self.endpoint_url = endpoint_url
        self._project_id = _get_project_id(project_id)
        self._config = config or get_default_kms_config()

    def _get_client(self):
        try:
            from google.cloud import kms_v1
        except ImportError as e:
            raise KMSError(
                "Google Cloud KMS requires google-cloud-kms. "
                "Install: pip install easy_encryption_tool[kms]"
            ) from e

        client_options = None
        if self.endpoint_url:
            from google.api_core.client_options import ClientOptions

            client_options = ClientOptions(api_endpoint=self.endpoint_url)

        return kms_v1.KeyManagementServiceClient(client_options=client_options)

    def generate_data_key(
        self,
        key_id: str,
        number_of_bytes: int,
    ) -> tuple[bytes, bytes, str | None]:
        """
        Generate data key. Returns (plaintext_dek, ciphertext_blob, request_id).
        For envelope: number_of_bytes = key_len + nonce_len (e.g. 44 for AES-256-GCM).
        Google Cloud KMS has no GenerateDataKey; we generate DEK locally and wrap with Encrypt.
        """
        try:
            from easy_encryption_tool import random_str

            plaintext_dek = random_str.generate_random_bytes(number_of_bytes)
        except ImportError:
            plaintext_dek = os.urandom(number_of_bytes)
        key_name = _normalize_key_id(key_id, self.region, self._project_id)

        try:
            client = self._get_client()
            encrypt_response = client.encrypt(
                request={
                    "name": key_name,
                    "plaintext": plaintext_dek,
                }
            )
        except Exception as e:
            req_id = _get_request_id_from_exception(e)
            raise KMSError(
                f"Google Cloud KMS Encrypt failed: {e!s}"
                + (f" (request_id={req_id})" if req_id else "")
            ) from e

        ciphertext = bytes(encrypt_response.ciphertext)
        enc_dek = _encode_googlecloud_enc_dek(key_name, ciphertext)
        # GCP Encrypt response has no request_id; "name" is CryptoKeyVersion resource
        key_version = getattr(encrypt_response, "name", None)
        return (plaintext_dek, enc_dek, None, "Encrypt", key_version)

    def decrypt(self, ciphertext_blob: bytes, key_id: str | None = None) -> tuple[bytes, str | None]:
        """
        Decrypt ciphertext blob. Returns (plaintext, request_id).
        For Google Cloud, ciphertext_blob is our enc_dek format (JSON with key_id + ciphertext).
        key_id from CLI is ignored; we use the one stored in enc_dek.
        """
        try:
            stored_key_id, ciphertext = _decode_googlecloud_enc_dek(ciphertext_blob)
            # Always use key_id from envelope (full resource name); CLI key_id ignored
            key_name_to_use = stored_key_id

            client = self._get_client()
            decrypt_response = client.decrypt(
                request={
                    "name": key_name_to_use,
                    "ciphertext": ciphertext,
                }
            )
            plaintext = bytes(decrypt_response.plaintext)
            return (plaintext, None)
        except KMSError:
            raise
        except Exception as e:
            req_id = _get_request_id_from_exception(e)
            raise KMSError(
                f"Google Cloud KMS Decrypt failed: {e!s}"
                + (f" (request_id={req_id})" if req_id else "")
            ) from e
