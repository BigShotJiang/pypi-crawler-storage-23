#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""Huawei Cloud KMS backend implementation."""

from __future__ import annotations

import configparser
import json
import os
from pathlib import Path
from typing import TYPE_CHECKING

from easy_encryption_tool.kms.config import KMSConfig, get_default_kms_config
from easy_encryption_tool.kms.errors import KMSError

if TYPE_CHECKING:
    pass

# KooCLI (hcloud) credential paths - INI format: cli-access-key, cli-secret-key, cli-project-id
_KOOCLI_CREDENTIAL_PATHS = [
    Path.home() / ".hcloud" / "credentials.ini",
    Path.home() / ".hcloud" / "credentials",
]

# JSON config file paths (ak, sk, project_id)
_HUAWEI_JSON_CREDENTIAL_PATHS = [
    Path.home() / ".huaweicloud" / "credentials",
    Path.home() / ".config" / "huaweicloud" / "credentials",
]


def _load_credential_from_koocli() -> tuple[str, str, str | None] | None:
    """Load credential from KooCLI (hcloud) config. Returns (ak, sk, project_id) or None.
    Supports INI format with cli-access-key, cli-secret-key, cli-project-id.
    Reads [default] section first, then first available section.
    """
    for path in _KOOCLI_CREDENTIAL_PATHS:
        try:
            if not path.exists():
                continue
            content = path.read_text(encoding="utf-8")
            parser = configparser.ConfigParser()
            parser.read_string(content)
            sections = ["default", "DEFAULT"] + [
                s for s in parser.sections() if s not in ("default", "DEFAULT")
            ]
            for section in sections:
                if not parser.has_section(section):
                    continue
                ak = (
                    parser.get(section, "cli-access-key", fallback="").strip()
                    or parser.get(section, "access_key", fallback="").strip()
                )
                sk = (
                    parser.get(section, "cli-secret-key", fallback="").strip()
                    or parser.get(section, "secret_key", fallback="").strip()
                )
                project_id = (
                    parser.get(section, "cli-project-id", fallback="").strip()
                    or parser.get(section, "project_id", fallback="").strip()
                    or None
                )
                if ak and sk:
                    return (ak, sk, project_id if project_id else None)
        except (OSError, configparser.Error, KeyError):
            pass
    return None


def _load_credential_from_json_file() -> tuple[str, str, str | None] | None:
    """Load credential from JSON config file. Returns (ak, sk, project_id) or None."""
    for path in _HUAWEI_JSON_CREDENTIAL_PATHS:
        try:
            if not path.exists():
                continue
            data = json.loads(path.read_text(encoding="utf-8"))
            ak = data.get("ak") or data.get("access_key") or data.get("access_key_id")
            sk = data.get("sk") or data.get("secret_key") or data.get("secret_access_key")
            project_id = data.get("project_id")
            if ak and sk:
                return (str(ak), str(sk), str(project_id) if project_id else None)
        except (OSError, json.JSONDecodeError, KeyError):
            pass
    return None


def _load_credential_from_file() -> tuple[str, str, str | None] | None:
    """Load credential from config files. Priority: KooCLI > JSON.
    Returns (ak, sk, project_id) or None.
    """
    cred = _load_credential_from_koocli()
    if cred:
        return cred
    return _load_credential_from_json_file()


def _get_credential() -> tuple[str, str]:
    """Get Huawei Cloud AK/SK. Priority:
    1. Env vars HUAWEICLOUD_SDK_AK, HUAWEICLOUD_SDK_SK
    2. KooCLI: ~/.hcloud/credentials.ini (INI: cli-access-key, cli-secret-key)
    3. Config file: ~/.huaweicloud/credentials (JSON: ak, sk)
    """
    ak = os.environ.get("HUAWEICLOUD_SDK_AK")
    sk = os.environ.get("HUAWEICLOUD_SDK_SK")
    if ak and sk:
        return (ak, sk)

    file_cred = _load_credential_from_file()
    if file_cred:
        return (file_cred[0], file_cred[1])

    raise KMSError(
        "Huawei Cloud KMS requires credentials. Set HUAWEICLOUD_SDK_AK and "
        "HUAWEICLOUD_SDK_SK env vars, or use KooCLI (~/.hcloud/credentials.ini), "
        "or ~/.huaweicloud/credentials (JSON: ak, sk)"
    )


def _get_project_id(project_id_override: str | None) -> str:
    """Get project_id. Priority: override > env > config file."""
    if project_id_override:
        return project_id_override
    pid = os.environ.get("HUAWEICLOUD_SDK_PROJECT_ID")
    if pid:
        return pid
    file_cred = _load_credential_from_file()
    if file_cred and file_cred[2]:
        return file_cred[2]
    raise KMSError(
        "Huawei Cloud KMS requires project_id. Set HUAWEICLOUD_SDK_PROJECT_ID env var, "
        "or add project_id to KooCLI/credentials config, or use --kms-project-id"
    )


def _get_request_id_from_exception(exc: Exception) -> str | None:
    """Extract Huawei Cloud request_id from exception if present."""
    try:
        if hasattr(exc, "request_id"):
            return getattr(exc, "request_id", None)
        if hasattr(exc, "error_code") and hasattr(exc, "error_msg"):
            return None
    except Exception:
        pass
    return None


def _encode_huawei_enc_dek(key_id: str, cipher_text: str, datakey_length: str) -> bytes:
    """Encode Huawei KMS enc_dek: store key_id + cipher_text + datakey_length for decrypt.
    DecryptDatakey requires key_id and datakey_cipher_length explicitly.
    """
    payload = {
        "key_id": key_id,
        "cipher_text": cipher_text,
        "datakey_length": datakey_length,
    }
    return json.dumps(payload, separators=(",", ":")).encode("utf-8")


def _decode_huawei_enc_dek(enc_dek: bytes) -> tuple[str, str, str]:
    """Decode Huawei enc_dek to (key_id, cipher_text, datakey_length). Raises on invalid format."""
    try:
        data = json.loads(enc_dek.decode("utf-8"))
        key_id = data.get("key_id")
        cipher_text = data.get("cipher_text")
        datakey_length = data.get("datakey_length", "44")
        if key_id and cipher_text:
            return (str(key_id), str(cipher_text), str(datakey_length))
    except (json.JSONDecodeError, UnicodeDecodeError, KeyError):
        pass
    raise KMSError("Invalid Huawei Cloud KMS envelope: enc_dek format error")


class HuaweiCloudKMSBackend:
    """Huawei Cloud KMS backend for envelope encryption.

    Uses CreateDatakey and DecryptDatakey APIs. Credentials from (in order):
    1. Env vars HUAWEICLOUD_SDK_AK, HUAWEICLOUD_SDK_SK; HUAWEICLOUD_SDK_PROJECT_ID
    2. KooCLI: ~/.hcloud/credentials.ini (INI: cli-access-key, cli-secret-key, cli-project-id)
    3. Config file: ~/.huaweicloud/credentials (JSON: ak, sk, project_id)
    See: https://support.huaweicloud.com/intl/zh-cn/api-dew/CreateDatakey.html
    """

    def __init__(
        self,
        region: str,
        endpoint_url: str | None = None,
        project_id: str | None = None,
        config: KMSConfig | None = None,
    ):
        self.region = region
        self.endpoint_url = endpoint_url
        self._project_id = _get_project_id(project_id)
        self._config = config or get_default_kms_config()

    def _get_client(self):
        try:
            from huaweicloudsdkcore.auth.credentials import BasicCredentials
            from huaweicloudsdkcore.http.http_config import HttpConfig
            from huaweicloudsdkkms.v2.kms_client import KmsClient
            from huaweicloudsdkkms.v2.region.kms_region import KmsRegion
        except ImportError as e:
            raise KMSError(
                "Huawei Cloud KMS requires huaweicloudsdkkms. "
                "Install: pip install easy_encryption_tool[kms]"
            ) from e

        ak, sk = _get_credential()
        credentials = BasicCredentials(ak, sk, self._project_id)

        config = HttpConfig()
        config.ignore_ssl_verification = False
        config.connect_timeout = int(self._config.connect_timeout)
        config.read_timeout = int(self._config.read_timeout)

        builder = (
            KmsClient.new_builder()
            .with_credentials(credentials)
            .with_http_config(config)
            .with_region(KmsRegion.value_of(self.region))
        )
        if self.endpoint_url:
            builder = builder.with_endpoint(self.endpoint_url)
        return builder.build()

    def generate_data_key(
        self,
        key_id: str,
        number_of_bytes: int,
    ) -> tuple[bytes, bytes, str | None]:
        """
        Generate data key. Returns (plaintext_dek, ciphertext_blob, request_id).
        For envelope: number_of_bytes = key_len + nonce_len (e.g. 44 for AES-256-GCM).
        Huawei returns plain_text and cipher_text as hex strings.
        We store enc_dek as JSON {key_id, cipher_text} for DecryptDatakey (requires key_id).
        """
        try:
            from huaweicloudsdkkms.v2 import CreateDatakeyRequest, CreateDatakeyRequestBody

            client = self._get_client()
            body = CreateDatakeyRequestBody(key_id=key_id, datakey_length=str(number_of_bytes * 8))
            req = CreateDatakeyRequest(body=body)
            resp = client.create_datakey(req)

            plain_text_hex = resp.plain_text
            cipher_text_hex = resp.cipher_text
            request_id = getattr(resp, "request_id", None)

            plaintext = bytes.fromhex(plain_text_hex)
            enc_dek = _encode_huawei_enc_dek(
                key_id, cipher_text_hex, str(number_of_bytes)
            )
            return (plaintext, enc_dek, request_id)
        except Exception as e:
            req_id = _get_request_id_from_exception(e)
            raise KMSError(
                f"Huawei Cloud KMS CreateDatakey failed: {e!s}"
                + (f" (request_id={req_id})" if req_id else "")
            ) from e

    def decrypt(self, ciphertext_blob: bytes, key_id: str | None = None) -> tuple[bytes, str | None]:
        """
        Decrypt ciphertext blob. Returns (plaintext, request_id).
        For Huawei, ciphertext_blob is our enc_dek format (JSON with key_id + cipher_text).
        key_id from CLI is ignored; we use the one stored in enc_dek.
        """
        try:
            from huaweicloudsdkkms.v2 import DecryptDatakeyRequest, DecryptDatakeyRequestBody

            stored_key_id, cipher_text_hex, datakey_length = _decode_huawei_enc_dek(
                ciphertext_blob
            )
            key_id_to_use = key_id or stored_key_id

            client = self._get_client()
            body = DecryptDatakeyRequestBody(
                key_id=key_id_to_use,
                cipher_text=cipher_text_hex,
                datakey_cipher_length=datakey_length,
            )
            req = DecryptDatakeyRequest(body=body)
            resp = client.decrypt_datakey(req)

            data_key_hex = resp.data_key
            request_id = getattr(resp, "request_id", None)
            plaintext = bytes.fromhex(data_key_hex)
            return (plaintext, request_id)
        except KMSError:
            raise
        except Exception as e:
            req_id = _get_request_id_from_exception(e)
            raise KMSError(
                f"Huawei Cloud KMS DecryptDatakey failed: {e!s}"
                + (f" (request_id={req_id})" if req_id else "")
            ) from e
