#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""KMS backends."""

from __future__ import annotations

from typing import Union

from easy_encryption_tool.kms.config import KMSConfig, get_default_kms_config
from easy_encryption_tool.kms.backends.aliyun import AliyunKMSBackend
from easy_encryption_tool.kms.backends.aws import AWSKMSBackend
from easy_encryption_tool.kms.backends.googlecloud import GoogleCloudKMSBackend
from easy_encryption_tool.kms.backends.hashicorpvault import HashiCorpVaultKMSBackend
from easy_encryption_tool.kms.backends.huaweicloud import HuaweiCloudKMSBackend
from easy_encryption_tool.kms.backends.tencentcloud import TencentCloudKMSBackend


def get_backend(
    backend_name: str,
    region: str,
    endpoint_url: str | None = None,
    config: KMSConfig | None = None,
    project_id: str | None = None,
) -> Union[
    AliyunKMSBackend,
    AWSKMSBackend,
    TencentCloudKMSBackend,
    HuaweiCloudKMSBackend,
    GoogleCloudKMSBackend,
    HashiCorpVaultKMSBackend,
]:
    """Get KMS backend instance. Supports 'aws', 'tencentcloud', 'aliyun', 'huaweicloud', 'googlecloud', 'hashicorpvault'.
    config: KMS timeout config; default 5s connect/read. All backends enforce timeout.
    project_id: Required for huaweicloud; optional for googlecloud (short key format).
    """
    kms_config = config or get_default_kms_config()
    if backend_name == "aws":
        return AWSKMSBackend(
            region=region,
            endpoint_url=endpoint_url,
            config=kms_config,
        )
    if backend_name == "tencentcloud":
        return TencentCloudKMSBackend(
            region=region,
            endpoint_url=endpoint_url,
            config=kms_config,
        )
    if backend_name == "aliyun":
        return AliyunKMSBackend(
            region=region,
            endpoint_url=endpoint_url,
            config=kms_config,
        )
    if backend_name == "huaweicloud":
        return HuaweiCloudKMSBackend(
            region=region,
            endpoint_url=endpoint_url,
            project_id=project_id,
            config=kms_config,
        )
    if backend_name == "googlecloud":
        return GoogleCloudKMSBackend(
            region=region,
            endpoint_url=endpoint_url,
            project_id=project_id,
            config=kms_config,
        )
    if backend_name == "hashicorpvault":
        return HashiCorpVaultKMSBackend(
            region=region or "default",
            endpoint_url=endpoint_url,
            config=kms_config,
        )
    raise ValueError(f"Unsupported KMS backend: {backend_name}")
