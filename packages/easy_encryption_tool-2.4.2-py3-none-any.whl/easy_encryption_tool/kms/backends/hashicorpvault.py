#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""HashiCorp Vault Transit KMS backend implementation."""

from __future__ import annotations

import base64
import json
import os
from typing import TYPE_CHECKING

from easy_encryption_tool.kms.config import KMSConfig, get_default_kms_config
from easy_encryption_tool.kms.errors import KMSError

if TYPE_CHECKING:
    pass


def _encode_hashicorpvault_enc_dek(key_id: str, ciphertext: str) -> bytes:
    """Encode HashiCorp Vault enc_dek: store key_id + ciphertext for decrypt.
    Vault Transit returns ciphertext as "vault:v1:base64..." string.
    """
    payload = {
        "key_id": key_id,
        "ciphertext": ciphertext,
    }
    return json.dumps(payload, separators=(",", ":")).encode("utf-8")


def _parse_transit_key_path(key_id: str) -> tuple[str, str]:
    """Parse full key path to (mount_point, key_name). E.g. transit/data-protection-key -> (transit, data-protection-key).
    Requires key_id to contain '/' (full path, no default mount).
    """
    if "/" not in key_id:
        raise KMSError(
            "HashiCorp Vault --kms-key-id must be full path (e.g. transit/data-protection-key). "
            "Cannot default to transit mount."
        )
    parts = key_id.split("/")
    mount_point = parts[0]
    key_name = parts[-1]
    if not mount_point or not key_name:
        raise KMSError(
            "HashiCorp Vault --kms-key-id invalid format. "
            "Use mount_point/key_name (e.g. transit/data-protection-key)."
        )
    return (mount_point, key_name)


def _decode_hashicorpvault_enc_dek(enc_dek: bytes) -> tuple[str, str]:
    """Decode HashiCorp Vault enc_dek to (key_id, ciphertext). Raises on invalid format."""
    try:
        data = json.loads(enc_dek.decode("utf-8"))
        key_id = data.get("key_id")
        ciphertext = data.get("ciphertext")
        if key_id and ciphertext:
            return (str(key_id), str(ciphertext))
    except (json.JSONDecodeError, UnicodeDecodeError, KeyError, ValueError):
        pass
    raise KMSError("Invalid HashiCorp Vault envelope: enc_dek format error")


def _get_vault_client(url: str) -> object:
    """Create hvac client with VAULT_ADDR and VAULT_TOKEN."""
    try:
        import hvac
    except ImportError as e:
        raise KMSError(
            "HashiCorp Vault requires hvac. "
            "Install: pip install easy_encryption_tool[kms]"
        ) from e

    token = os.environ.get("VAULT_TOKEN")
    if not token:
        raise KMSError(
            "HashiCorp Vault requires VAULT_TOKEN. "
            "Set VAULT_TOKEN environment variable."
        )

    client = hvac.Client(url=url, token=token)
    if not client.is_authenticated():
        raise KMSError("HashiCorp Vault authentication failed: invalid or expired token")

    return client


class HashiCorpVaultKMSBackend:
    """HashiCorp Vault Transit backend for envelope encryption.

    Uses Transit encrypt/decrypt APIs (no GenerateDataKey; DEK is generated locally
    then wrapped by Transit encrypt). Same flow as Google Cloud KMS.
    Credentials: VAULT_ADDR and VAULT_TOKEN environment variables.

    Encrypt: local DEK → Transit encrypt → store enc_dek (key_id + ciphertext)
    Decrypt: Transit decrypt enc_dek → DEK → decrypt data

    See: https://developer.hashicorp.com/vault/docs/secrets/transit
    """

    def __init__(
        self,
        region: str,
        endpoint_url: str | None = None,
        config: KMSConfig | None = None,
    ):
        self.region = region
        self.endpoint_url = endpoint_url
        self._config = config or get_default_kms_config()
        self._vault_url = endpoint_url or os.environ.get("VAULT_ADDR")
        if not self._vault_url:
            raise KMSError(
                "HashiCorp Vault requires vault address. "
                "Set --kms-endpoint or VAULT_ADDR environment variable."
            )
        self._vault_url = self._vault_url.rstrip("/")

    def _get_client(self):
        return _get_vault_client(self._vault_url)

    def generate_data_key(
        self,
        key_id: str,
        number_of_bytes: int,
    ) -> tuple[bytes, bytes, str | None]:
        """
        Generate data key. Returns (plaintext_dek, ciphertext_blob, request_id).
        For envelope: number_of_bytes = key_len + nonce_len (e.g. 44 for AES-256-GCM).
        HashiCorp Vault Transit has no GenerateDataKey; we generate DEK locally
        and wrap with Transit encrypt.
        """
        try:
            from easy_encryption_tool import random_str

            plaintext_dek = random_str.generate_random_bytes(number_of_bytes)
        except ImportError:
            plaintext_dek = os.urandom(number_of_bytes)

        plaintext_b64 = base64.b64encode(plaintext_dek).decode("ascii")

        mount_point, key_name = _parse_transit_key_path(key_id)
        try:
            client = self._get_client()
            encrypt_response = client.secrets.transit.encrypt_data(
                name=key_name,
                plaintext=plaintext_b64,
                mount_point=mount_point,
            )
        except Exception as e:
            raise KMSError(
                f"HashiCorp Vault Transit encrypt failed: {e!s}"
            ) from e

        ciphertext_str = encrypt_response["data"]["ciphertext"]
        enc_dek = _encode_hashicorpvault_enc_dek(key_id, ciphertext_str)
        return (plaintext_dek, enc_dek, None, "TransitEncrypt", None)

    def decrypt(self, ciphertext_blob: bytes, key_id: str | None = None) -> tuple[bytes, str | None]:
        """
        Decrypt ciphertext blob. Returns (plaintext, request_id).
        For HashiCorp Vault, ciphertext_blob is our enc_dek format (JSON with key_id + ciphertext).
        key_id from CLI is ignored; we use the one stored in enc_dek.
        """
        try:
            stored_key_id, ciphertext_str = _decode_hashicorpvault_enc_dek(ciphertext_blob)
            mount_point, key_name = _parse_transit_key_path(stored_key_id)

            client = self._get_client()
            decrypt_response = client.secrets.transit.decrypt_data(
                name=key_name,
                ciphertext=ciphertext_str,
                mount_point=mount_point,
            )
            plaintext_b64 = decrypt_response["data"]["plaintext"]
            plaintext = base64.b64decode(plaintext_b64)
            return (plaintext, None)
        except KMSError:
            raise
        except Exception as e:
            raise KMSError(
                f"HashiCorp Vault Transit decrypt failed: {e!s}"
            ) from e
