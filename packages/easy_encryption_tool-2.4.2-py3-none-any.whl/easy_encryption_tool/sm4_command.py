#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2025-02-16
"""
SM4 symmetric encryption (Chinese standard, similar to AES).
Supports CBC and GCM modes.
"""
from __future__ import annotations

import base64
import os
import time
from typing import Tuple

import click
from click.core import ParameterSource
from cryptography.hazmat.primitives import padding

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import hints
from easy_encryption_tool import random_str
from easy_encryption_tool import shell_completion
from easy_encryption_tool import validators
from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error, warning

try:
    from easy_gmssl import EasySm4CBC, EasySm4GCM
    from easy_gmssl.gmssl import (
        SM4_BLOCK_SIZE,
        SM4_CBC_IV_SIZE,
        SM4_GCM_DEFAULT_IV_SIZE,
    )

    EASY_GMSSL_AVAILABLE = True
except ImportError:
    EASY_GMSSL_AVAILABLE = False

algorithm: str = "sm4"

sm4_key_len: int = 16  # 16 bytes
sm4_iv_len: int = 16  # CBC mode 16 bytes
sm4_nonce_len: int = 12  # GCM mode 12 bytes

sm4_cbc_mode: str = "cbc"
sm4_gcm_mode: str = "gcm"

sm4_encrypt_action = "encrypt"
sm4_decrypt_action = "decrypt"

sm4_gcm_tag_len = SM4_BLOCK_SIZE if EASY_GMSSL_AVAILABLE else 16

sm4_file_read_block = 16


def _check_gmssl():
    if not EASY_GMSSL_AVAILABLE:
        hints.hint_missing_gmssl("SM4")
        return False
    return True


def generate_random_key() -> str:
    return random_str.generate_random_str(sm4_key_len)


def generate_random_iv_nonce(mode: str) -> str:
    if mode == sm4_cbc_mode:
        return random_str.generate_random_str(sm4_iv_len)
    elif mode == sm4_gcm_mode:
        return random_str.generate_random_str(sm4_nonce_len)


def process_key_iv(is_random: bool, key: str, iv: str, mode: str) -> Tuple[str, str, bool, bool, bool, bool]:
    return common.process_key_iv(
        is_random,
        key,
        iv,
        key_len=sm4_key_len,
        iv_len=sm4_iv_len,
        nonce_len=sm4_nonce_len,
        mode=mode,
    )


def padding_data(data: bytes) -> bytes:
    padder = padding.PKCS7(128).padder()
    return padder.update(data) + padder.finalize()


def remove_padding_data(data: bytes) -> bytes:
    if data is None or len(data) == 0:
        return b""
    unpadder = padding.PKCS7(128).unpadder()
    return unpadder.update(data) + unpadder.finalize()


def check_b64_input_data(input_data: str, input_limit: int) -> Tuple[bool, bytes]:
    """Validate and decode base64 input. Returns (success, decoded_bytes)."""
    if input_data is None:
        error("need input data")
        return False, b""
    valid, input_raw_bytes = common.check_b64_data(input_data)
    if not valid:
        error("invalid b64 encoded data")
        hints.hint_invalid_b64("SM4")
        return False, b""
    if len(input_raw_bytes) > input_limit * 1024 * 1024:
        error(
            "data exceeds limit: {} Bytes (max {} Bytes)".format(
                len(input_raw_bytes), input_limit * 1024 * 1024
            )
        )
        return False, b""
    if len(input_raw_bytes) <= 0:
        error("got empty after base64 decode")
        return False, b""
    return True, input_raw_bytes


@click.command(
    name="sm4", short_help="SM4 encrypt/decrypt, supports sm4-cbc and sm4-gcm"
)
@click.option(
    "-m",
    "--mode",
    required=False,
    type=click.Choice([sm4_cbc_mode, sm4_gcm_mode]),
    default="cbc",
    show_default=True,
    help="SM4 mode: cbc or gcm, default cbc",
)
@click.option(
    "-k",
    "--key",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_KEY_16,
    help="Key 16 bytes, CipherHUB compatible; pad or truncate as needed",
    show_default=True,
)
@click.option(
    "-v",
    "--iv-nonce",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_IV_16,
    help="CBC: iv 16 bytes; GCM: nonce 12 bytes. CipherHUB compatible; pad or truncate as needed",
    show_default=True,
)
@click.option(
    "--aad",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_AAD,
    help='GCM additional authenticated data (AAD), default: "{}"'.format(
        cipherhub_defaults.DEFAULT_AAD
    ),
    show_default=True,
)
@click.option(
    "-r",
    "--random-key-iv",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Auto-generate random key and iv/nonce",
)
@click.option(
    "--key-b64",
    required=False,
    type=click.STRING,
    default=None,
    help="[Advanced] Key as base64-encoded bytes (16 bytes). Mutually exclusive with -k when used.",
)
@click.option(
    "--iv-b64",
    required=False,
    type=click.STRING,
    default=None,
    help="[Advanced] IV/nonce as base64-encoded bytes (CBC: 16 bytes, GCM: 12 bytes). Mutually exclusive with -v when used.",
)
@click.option(
    "-A",
    "--action",
    required=False,
    type=click.Choice([sm4_encrypt_action, sm4_decrypt_action]),
    default="encrypt",
    show_default=True,
    help="encrypt or decrypt; encrypt outputs base64-encoded string",
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input data: encrypt accepts string/base64/file; decrypt accepts base64/file",
    shell_complete=shell_completion.complete_file_path_if_input_is_file,
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="Input is base64-encoded; -e and -f are mutually exclusive",
)
@click.option(
    "-f",
    "--is-a-file",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=False,
    help="Input is a file path; -e and -f are mutually exclusive",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=1,
    show_default=True,
    help="Max input length in MB (default 1), applies when -i is not a file; use -l N for larger data",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file path; required when input is a file",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "--no-force",
    is_flag=True,
    default=False,
    help="Do not overwrite existing output file (default: overwrite)",
)
@click.option(
    "--gcm-pad",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="[GCM only] PKCS#7 pad plaintext before encrypt, unpad after decrypt. Default: no padding (CipherHUB compatible); "
    "encrypt and decrypt must both use or both omit --gcm-pad. "
    "File decrypt with --gcm-pad loads entire file into memory; large files may cause OOM.",
)
@output_format_options
@click.pass_context
def sm4_command(
    ctx: click.Context,
    mode: str,
    key: str,
    iv_nonce: str,
    random_key_iv: bool,
    key_b64: str | None,
    iv_b64: str | None,
    action: str,
    input_data: str,
    is_base64_encoded: bool,
    is_a_file: bool,
    input_limit: int,
    output_file: str,
    aad: str,
    no_force: bool = False,
    gcm_pad: bool = False,
    output_format: str | None = None,
):
    """SM4 symmetric encrypt/decrypt, CBC and GCM modes. Default -i is UTF-8 plaintext; -e means base64; -f means file."""
    if not _check_gmssl():
        return

    request_id = create_request_id()
    start = time.perf_counter()

    key_bytes: bytes
    iv_bytes: bytes
    key_display: str
    iv_display: str

    if random_key_iv:
        if key_b64 is not None or iv_b64 is not None:
            error("SM4: -r/--random-key-iv cannot be used with --key-b64 or --iv-b64")
            return
        key, iv_nonce, _, _, _, _ = process_key_iv(random_key_iv, key, iv_nonce, mode)
        key_bytes = key.encode("utf-8")
        iv_bytes = iv_nonce.encode("utf-8")
        key_display = key
        iv_display = iv_nonce
    else:
        key_from_cli = ctx.get_parameter_source("key") == ParameterSource.COMMANDLINE
        iv_from_cli = ctx.get_parameter_source("iv_nonce") == ParameterSource.COMMANDLINE
        if key_b64 is not None and key_from_cli:
            error("SM4: -k/--key and --key-b64 are mutually exclusive; specify one only")
            return
        if iv_b64 is not None and iv_from_cli:
            error("SM4: -v/--iv-nonce and --iv-b64 are mutually exclusive; specify one only")
            return
        key_str, iv_str, key_padded, iv_padded, key_truncated, iv_truncated = process_key_iv(
            False, key, iv_nonce, mode
        )
        if key_b64 is not None or iv_b64 is not None:
            ok, err, kb, ib = common.decode_key_iv_b64(
                key_b64,
                iv_b64,
                key_len=sm4_key_len,
                iv_len=sm4_iv_len,
                nonce_len=sm4_nonce_len,
                mode=mode,
            )
            if not ok:
                error("SM4: {}".format(err or ""))
                return
            key_bytes = kb if kb is not None else key_str.encode("utf-8")
            iv_bytes = ib if ib is not None else iv_str.encode("utf-8")
        else:
            key_bytes = key_str.encode("utf-8")
            iv_bytes = iv_str.encode("utf-8")
        key_display = key_str
        iv_display = iv_str
        if (
            not key_from_cli
            and not iv_from_cli
            and key_b64 is None
            and iv_b64 is None
        ):
            warning(
                "Using default key/IV. Insecure for production. Use -r or provide explicit -k/-v."
            )
        if (key_padded or iv_padded) and key_b64 is None and iv_b64 is None:
            warning(
                "Key/IV was padded (short input). Ensure compatibility with peer; consider using full-length key/IV."
            )
        if (key_truncated or iv_truncated) and key_b64 is None and iv_b64 is None:
            warning(
                "Key/IV was truncated (long input). Ensure compatibility with peer; consider using exact-length key/IV."
            )

    if len(input_data) <= 0:
        error("no input data, it is required")
        return

    ok, err = validators.validate_b64_or_file(is_base64_encoded, is_a_file, "SM4")
    if not ok:
        error(err or "")
        hints.hint_input_file_or_b64_conflict()
        return

    ok, err = validators.validate_file_output_required(is_a_file, output_file, "SM4")
    if not ok:
        error(err or "")
        return

    if (
        action == sm4_decrypt_action
        and not is_base64_encoded
        and not is_a_file
    ):
        error("decrypt requires base64 cipher or file; use -e for base64 input")
        hints.hint_invalid_b64("SM4")
        return

    input_raw_bytes = b""
    input_raw_tag = b""

    if is_base64_encoded:
        ok, input_raw_bytes = check_b64_input_data(input_data, input_limit)
        if not ok:
            return
        # GCM decrypt: cipher format is cipher||tag, split from end
        if mode == sm4_gcm_mode and action == sm4_decrypt_action:
            if len(input_raw_bytes) < sm4_gcm_tag_len:
                error(
                    "invalid cipher: too short for gcm tag (need at least {} bytes)".format(
                        sm4_gcm_tag_len
                    )
                )
                return
            input_raw_tag = input_raw_bytes[-sm4_gcm_tag_len:]
            input_raw_bytes = input_raw_bytes[:-sm4_gcm_tag_len]

    input_from_file = None
    output_to_file = None
    if not is_base64_encoded and not is_a_file:
        if len(input_data) > input_limit * 1024 * 1024:
            error(
                "data exceeds limit: {} Bytes (max {} Bytes)".format(
                    len(input_data), input_limit * 1024 * 1024
                )
            )
            return
        try:
            input_raw_bytes = input_data.encode("utf-8")
        except UnicodeEncodeError:
            error("input contains invalid UTF-8 characters")
            return

    file_gcm_cipher_bytes = None
    input_raw_tag = b""
    gcm_decrypt_use_streaming = False  # set when we use streaming path

    if (
        mode == sm4_gcm_mode
        and action == sm4_decrypt_action
        and len(input_raw_tag) == 0
        and not is_a_file
    ):
        error("gcm mode decrypt requires cipher in base64(cipher||tag) format")
        return

    # --gcm-pad only applies in GCM mode; CBC always pads
    use_gcm_pad = mode == sm4_gcm_mode and gcm_pad

    if len(output_file) > 0:
        try:
            output_to_file = common.write_to_file(output_file, force=not no_force)
        except OSError:
            error(
                "{} may not exist or may not be writable (use --no-force to avoid overwrite)".format(
                    output_file
                )
            )
            return

    if mode == sm4_gcm_mode:
        auth_data = (aad or cipherhub_defaults.DEFAULT_AAD).encode("utf-8")
        sm4_op = EasySm4GCM(
            key=key_bytes,
            iv=iv_bytes,
            aad=auth_data,
            do_encrypt=(action == sm4_encrypt_action),
        )
    else:
        sm4_op = EasySm4CBC(
            key=key_bytes, iv=iv_bytes, do_encrypt=(action == sm4_encrypt_action)
        )

    if not is_a_file:
        if action == sm4_encrypt_action:
            if mode == sm4_cbc_mode:
                # SM4-CBC: 按 sm4_cbc_demo.py 逻辑，明文 UTF-8 编码后直接 Update + Finish，
                # 由 EasySm4CBC.Finish() 内部完成 PKCS7 padding，不做预填充
                padded_raw_bytes = input_raw_bytes
            else:
                padded_raw_bytes = (
                    padding_data(input_raw_bytes) if use_gcm_pad else input_raw_bytes
                )
            cipher = sm4_op.Update(padded_raw_bytes) + sm4_op.Finish()
            if mode == sm4_gcm_mode:
                ret_tags = cipher[-sm4_gcm_tag_len:]
                all_cipher = cipher[:-sm4_gcm_tag_len]
                cipher_with_tag = all_cipher + ret_tags
                if not common.validate_gcm_cipher_format(
                    cipher_with_tag, sm4_gcm_tag_len
                ):
                    error(
                        "invalid gcm cipher format: cipher_with_tag length < tag_len"
                    )
                    return
                all_cipher_str = base64.b64encode(cipher_with_tag).decode("utf-8")
                if output_to_file is not None and not output_to_file.write_bytes(
                    cipher_with_tag
                ):
                    return
                duration_ms = (time.perf_counter() - start) * 1000
                formats = {"cipher": "base64"}
                if random_key_iv:
                    formats["key"] = "utf-8"
                    formats["iv"] = "utf-8"
                metadata = build_metadata(
                    operation="encrypt",
                    algorithm="sm4-gcm",
                    formats=formats,
                    input_type="binary" if is_base64_encoded else "text",
                    input_size=len(input_raw_bytes),
                    parameters={"mode": "gcm", "tag_size": sm4_gcm_tag_len},
                )
                result_data = {"cipher": all_cipher_str}
                if random_key_iv:
                    result_data["key"] = key_display
                    result_data["iv"] = iv_display
                result = build_result(**result_data)
                output = build_output(
                    metadata=metadata,
                    result=result,
                    request_id=request_id,
                    duration_ms=duration_ms,
                )
                render(output, mode=resolve_output_format(output_format), primary_key="cipher")
            else:
                all_cipher = cipher
                all_cipher_str = base64.b64encode(all_cipher).decode("utf-8")
                if output_to_file is not None and not output_to_file.write_bytes(
                    all_cipher
                ):
                    return
                duration_ms = (time.perf_counter() - start) * 1000
                formats = {"cipher": "base64"}
                if random_key_iv:
                    formats["key"] = "utf-8"
                    formats["iv"] = "utf-8"
                metadata = build_metadata(
                    operation="encrypt",
                    algorithm="sm4-cbc",
                    formats=formats,
                    input_type="binary" if is_base64_encoded else "text",
                    input_size=len(input_raw_bytes),
                    parameters={"mode": "cbc"},
                )
                result_data = {"cipher": all_cipher_str}
                if random_key_iv:
                    result_data["key"] = key_display
                    result_data["iv"] = iv_display
                result = build_result(**result_data)
                output = build_output(
                    metadata=metadata,
                    result=result,
                    request_id=request_id,
                    duration_ms=duration_ms,
                )
                render(output, mode=resolve_output_format(output_format), primary_key="cipher")
        if action == sm4_decrypt_action:
            try:
                if mode == sm4_gcm_mode:
                    cipher_with_tag = input_raw_bytes + input_raw_tag
                    plain = sm4_op.Update(cipher_with_tag) + sm4_op.Finish()
                    plain = remove_padding_data(plain) if use_gcm_pad else plain
                else:
                    # SM4-CBC: 按 sm4_cbc_demo.py 逻辑，密文直接 Update + Finish，
                    # 由 EasySm4CBC.Finish() 内部完成 PKCS7 去填充
                    plain = sm4_op.Update(input_raw_bytes) + sm4_op.Finish()
            except ValueError as e:
                err_msg = str(e).lower()
                if "padding" in err_msg or "pkcs7" in err_msg:
                    error(
                        "decrypt failed: PKCS#7 unpad error. If cipher was GCM-encrypted without padding, retry without --gcm-pad"
                    )
                else:
                    error("decrypt {} failed: {}".format(input_data, e))
                return
            except BaseException as e:
                err_lower = str(e).lower()
                if mode == sm4_gcm_mode and (
                    "tag" in err_lower or "auth" in err_lower or "verify" in err_lower or "gcm" in err_lower
                ):
                    error(
                        "decrypt failed: GCM authentication tag verification failed (cipher may be tampered)"
                    )
                else:
                    error("decrypt {} failed: {}".format(input_data, e))
                return
            be_str, ret = common.bytes_to_str(plain)
            if output_to_file is not None and not output_to_file.write_bytes(plain):
                return
            duration_ms = (time.perf_counter() - start) * 1000
            alg_name = "sm4-gcm" if mode == sm4_gcm_mode else "sm4-cbc"
            metadata = build_metadata(
                operation="decrypt",
                algorithm=alg_name,
                formats={"plain": "utf-8" if be_str else "base64"},
                input_type="binary" if is_base64_encoded else "text",
                input_size=len(input_raw_bytes) + (len(input_raw_tag) if mode == sm4_gcm_mode else 0),
                parameters={"mode": "gcm" if mode == sm4_gcm_mode else "cbc"},
            )
            result = build_result(plain=ret)
            output = build_output(
                metadata=metadata,
                result=result,
                request_id=request_id,
                duration_ms=duration_ms,
            )
            render(output, mode=resolve_output_format(output_format), primary_key="plain")

    if is_a_file and output_to_file is not None:
        # SM4 GCM file decrypt: streaming path (when not use_gcm_pad)
        if (
            mode == sm4_gcm_mode
            and action == sm4_decrypt_action
            and not use_gcm_pad
        ):
            try:
                with common.stream_gcm_cipher_from_file(
                    input_data, sm4_gcm_tag_len
                ) as (tag_bytes, fin, cipher_size):
                    sm4_dec = EasySm4GCM(
                        key=key_bytes,
                        iv=iv_bytes,
                        aad=(aad or cipherhub_defaults.DEFAULT_AAD).encode("utf-8"),
                        do_encrypt=False,
                    )
                    output_size = 0
                    remaining = cipher_size
                    if cipher_size == 0:
                        # M-04: Empty cipher case - file contains only Tag (16 bytes).
                        # EasySm4GCM expects cipher||tag; when cipher is empty, tag_bytes
                        # is the full input. Update(tag) + Finish() parses as 0B cipher + 16B tag.
                        plain_last = sm4_dec.Update(tag_bytes) + sm4_dec.Finish()
                        output_size = len(plain_last)
                        if not output_to_file.write_bytes(plain_last):
                            return
                    else:
                        while remaining > 0:
                            to_read = min(
                                common.GCM_STREAM_CHUNK_SIZE, remaining
                            )
                            chunk = fin.read(to_read)
                            remaining -= len(chunk)
                            if remaining == 0:
                                chunk = chunk + tag_bytes
                            plain = sm4_dec.Update(chunk)
                            output_size += len(plain)
                            if not output_to_file.write_bytes(plain):
                                return
                        plain_last = sm4_dec.Finish()
                        output_size += len(plain_last)
                        if not output_to_file.write_bytes(plain_last):
                            return
                    duration_ms = (time.perf_counter() - start) * 1000
                    metadata = build_metadata(
                        operation="decrypt",
                        algorithm="sm4-gcm",
                        formats={"output_file": "path"},
                        input_type="file",
                        input_size=os.stat(input_data).st_size,
                        parameters={"mode": "gcm"},
                    )
                    result = build_result(
                        output_file=output_file, plain_size=output_size
                    )
                    output = build_output(
                        metadata=metadata,
                        result=result,
                        request_id=request_id,
                        duration_ms=duration_ms,
                    )
                    render(
                        output,
                        mode=resolve_output_format(output_format),
                        primary_key="output_file",
                    )
            except ValueError as e:
                if output_to_file is not None:
                    output_to_file.abort()
                if "too short" in str(e).lower():
                    error("invalid cipher file: too short for gcm tag")
                else:
                    error("decrypt {} failed: {}".format(input_data, e))
                return
            except BaseException as e:
                if output_to_file is not None:
                    output_to_file.abort()
                err_lower = str(e).lower()
                if "tag" in err_lower or "auth" in err_lower or "verify" in err_lower or "gcm" in err_lower:
                    error(
                        "decrypt failed: GCM authentication tag verification failed (cipher may be tampered)"
                    )
                else:
                    error("decrypt {} failed: {}".format(input_data, e))
                return
            return

        # GCM decrypt with use_gcm_pad: need full plaintext for unpad, read entire file
        if (
            mode == sm4_gcm_mode
            and action == sm4_decrypt_action
            and use_gcm_pad
        ):
            try:
                warning(
                    "--gcm-pad with file decrypt loads entire file into memory; "
                    "large files may cause OOM"
                )
                with common.read_from_file(input_data) as input_from_file:
                    file_size_for_read = os.stat(input_data).st_size
                    if file_size_for_read < sm4_gcm_tag_len:
                        error("invalid cipher file: too short for gcm tag")
                        return
                    file_content = input_from_file.read_n_bytes(file_size_for_read)
                    input_raw_tag = file_content[-sm4_gcm_tag_len:]
                    file_gcm_cipher_bytes = file_content[:-sm4_gcm_tag_len]
            except OSError:
                error("{} may not exist or may be unreadable".format(input_data))
                return

        if (
            mode == sm4_gcm_mode
            and action == sm4_decrypt_action
            and file_gcm_cipher_bytes is not None
        ):
            try:
                plain = (
                    sm4_op.Update(file_gcm_cipher_bytes + input_raw_tag)
                    + sm4_op.Finish()
                )
                plain = remove_padding_data(plain) if use_gcm_pad else plain
                if not output_to_file.write_bytes(plain):
                    return
                duration_ms = (time.perf_counter() - start) * 1000
                metadata = build_metadata(
                    operation="decrypt",
                    algorithm="sm4-gcm",
                    formats={"output_file": "path"},
                    input_type="file",
                    input_size=os.stat(input_data).st_size,
                    parameters={"mode": "gcm"},
                )
                result = build_result(output_file=output_file, plain_size=len(plain))
                output = build_output(
                    metadata=metadata,
                    result=result,
                    request_id=request_id,
                    duration_ms=duration_ms,
                )
                render(output, mode=resolve_output_format(output_format), primary_key="output_file")
            except ValueError as e:
                if output_to_file is not None:
                    output_to_file.abort()
                err_msg = str(e).lower()
                if "padding" in err_msg or "pkcs7" in err_msg:
                    error(
                        "decrypt failed: PKCS#7 unpad error. If cipher was GCM-encrypted without padding, retry without --gcm-pad"
                    )
                else:
                    error("decrypt {} failed: {}".format(input_data, e))
            except BaseException as e:
                if output_to_file is not None:
                    output_to_file.abort()
                err_lower = str(e).lower()
                if "tag" in err_lower or "auth" in err_lower or "verify" in err_lower or "gcm" in err_lower:
                    error(
                        "decrypt failed: GCM authentication tag verification failed (cipher may be tampered)"
                    )
                else:
                    error("decrypt {} failed: {}".format(input_data, e))
        else:
            try:
                with common.read_from_file(input_data) as input_from_file:
                    read_size = common.FILE_READ_CHUNK_SIZE
                    init_file_size = os.stat(input_data).st_size
                    file_size = init_file_size
                    output_size = 0
                    if action == sm4_encrypt_action:
                        while True:
                            chunk = input_from_file.read_n_bytes(read_size)
                            file_size -= len(chunk)
                            if file_size <= 0:
                                if mode == sm4_cbc_mode:
                                    # SM4-CBC: 按 sm4_cbc_demo.py 逻辑，直接 Update + Finish，由 Finish 完成 padding
                                    pass
                                else:
                                    chunk = (
                                        padding_data(chunk) if use_gcm_pad else chunk
                                    )
                                cipher = sm4_op.Update(chunk) + sm4_op.Finish()
                                if mode == sm4_gcm_mode:
                                    tag = cipher[-sm4_gcm_tag_len:]
                                    cipher = cipher[:-sm4_gcm_tag_len]
                                    cipher_with_tag = cipher + tag
                                    if not common.validate_gcm_cipher_format(
                                        cipher_with_tag, sm4_gcm_tag_len
                                    ):
                                        error(
                                            "invalid gcm cipher format: cipher_with_tag length < tag_len"
                                        )
                                        return
                                    output_size += len(cipher_with_tag)
                                    if not output_to_file.write_bytes(cipher_with_tag):
                                        return
                                    duration_ms = (time.perf_counter() - start) * 1000
                                    formats = {"output_file": "path"}
                                    if random_key_iv:
                                        formats["key"] = "utf-8"
                                        formats["iv"] = "utf-8"
                                    metadata = build_metadata(
                                        operation="encrypt",
                                        algorithm="sm4-gcm",
                                        formats=formats,
                                        input_type="file",
                                        input_size=init_file_size,
                                        parameters={"mode": "gcm", "tag_size": sm4_gcm_tag_len},
                                    )
                                    result_data = {"output_file": output_file, "cipher_size": output_size}
                                    if random_key_iv:
                                        result_data["key"] = key_display
                                        result_data["iv"] = iv_display
                                    result = build_result(**result_data)
                                    output = build_output(
                                        metadata=metadata,
                                        result=result,
                                        request_id=request_id,
                                        duration_ms=duration_ms,
                                    )
                                    render(output, mode=resolve_output_format(output_format), primary_key="output_file")
                                else:
                                    output_size += len(cipher)
                                    if not output_to_file.write_bytes(cipher):
                                        return
                                    duration_ms = (time.perf_counter() - start) * 1000
                                    formats = {"output_file": "path"}
                                    if random_key_iv:
                                        formats["key"] = "utf-8"
                                        formats["iv"] = "utf-8"
                                    metadata = build_metadata(
                                        operation="encrypt",
                                        algorithm="sm4-cbc",
                                        formats=formats,
                                        input_type="file",
                                        input_size=init_file_size,
                                        parameters={"mode": "cbc"},
                                    )
                                    result_data = {"output_file": output_file, "cipher_size": output_size}
                                    if random_key_iv:
                                        result_data["key"] = key_display
                                        result_data["iv"] = iv_display
                                    result = build_result(**result_data)
                                    output = build_output(
                                        metadata=metadata,
                                        result=result,
                                        request_id=request_id,
                                        duration_ms=duration_ms,
                                    )
                                    render(output, mode=resolve_output_format(output_format), primary_key="output_file")
                                break
                            cipher = sm4_op.Update(chunk)
                            output_size += len(cipher)
                            if not output_to_file.write_bytes(cipher):
                                return
                    if action == sm4_decrypt_action:
                        try:
                            if (
                                file_size < sm4_file_read_block
                                or file_size % sm4_file_read_block != 0
                            ):
                                error(
                                    "invalid cipher file size: {} Bytes".format(
                                        file_size
                                    )
                                )
                                return
                            while True:
                                chunk = input_from_file.read_n_bytes(read_size)
                                file_size -= len(chunk)
                                plain = sm4_op.Update(chunk)
                                if file_size == 0:
                                    plain = plain + sm4_op.Finish()
                                    # SM4-CBC: 按 sm4_cbc_demo.py 逻辑，Finish 内部完成 PKCS7 去填充
                                    output_size += len(plain)
                                    if not output_to_file.write_bytes(plain):
                                        return
                                    duration_ms = (time.perf_counter() - start) * 1000
                                    metadata = build_metadata(
                                        operation="decrypt",
                                        algorithm="sm4-cbc",
                                        formats={"output_file": "path"},
                                        input_type="file",
                                        input_size=os.stat(input_data).st_size,
                                        parameters={"mode": "cbc"},
                                    )
                                    result = build_result(output_file=output_file, plain_size=output_size)
                                    output = build_output(
                                        metadata=metadata,
                                        result=result,
                                        request_id=request_id,
                                        duration_ms=duration_ms,
                                    )
                                    render(output, mode=resolve_output_format(output_format), primary_key="output_file")
                                    return
                                output_size += len(plain)
                                if not output_to_file.write_bytes(plain):
                                    return
                        except BaseException as e:
                            if output_to_file is not None:
                                output_to_file.abort()
                            error("decrypt {} failed: {}".format(input_data, e))
            except OSError:
                error("{} may not exist or may be unreadable".format(input_data))


if __name__ == "__main__":
    sm4_command()
