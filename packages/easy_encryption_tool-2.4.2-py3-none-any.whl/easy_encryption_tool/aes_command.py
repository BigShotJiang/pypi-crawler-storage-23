#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
# @Time: 2024-03-30 15:53:00
from __future__ import annotations

import base64
import os
from typing import Tuple

import click
from click.core import ParameterSource
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import algorithms, Cipher, modes

from cryptography.exceptions import InvalidTag

import time

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import common
from easy_encryption_tool import hints
from easy_encryption_tool import shell_completion
from easy_encryption_tool import random_str
from easy_encryption_tool import validators
from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error, hint, warning

algorithm: str = "aes"

aes_block_in_bytes = algorithms.AES.block_size // 8

aes_key_len_256: int = 32  # 32 bytes
aes_iv_len_128: int = 16  # 16 bytes
aes_nonce_len_128: int = 12  # 12 bytes

aes_cbc_mode: str = "cbc"
aes_gcm_mode: str = "gcm"

aes_encrypt_action = "encrypt"
aes_decrypt_action = "decrypt"

aes_gcm_tag_len = aes_block_in_bytes

aes_file_read_block = aes_block_in_bytes


def generate_random_key() -> str:
    return random_str.generate_random_str(aes_key_len_256)


def generate_random_iv_nonce(mode: str) -> str:
    if mode == aes_cbc_mode:
        return random_str.generate_random_str(aes_iv_len_128)
    elif mode == aes_gcm_mode:
        return random_str.generate_random_str(aes_nonce_len_128)


def process_key_iv(is_random: bool, key: str, iv: str, mode: str) -> Tuple[str, str, bool, bool, bool, bool]:
    return common.process_key_iv(
        is_random,
        key,
        iv,
        key_len=aes_key_len_256,
        iv_len=aes_iv_len_128,
        nonce_len=aes_nonce_len_128,
        mode=mode,
    )


def padding_data(data: bytes) -> bytes:
    padder = padding.PKCS7(128).padder()
    padded_data = padder.update(data) + padder.finalize()
    return padded_data


def remove_padding_data(data: bytes) -> bytes:
    # For empty byte stream, return empty directly
    if data is None or len(data) == 0:
        return b""
    unpadder = padding.PKCS7(128).unpadder()
    decrypted_data = unpadder.update(data) + unpadder.finalize()
    return decrypted_data


class aes_operator(object):
    def __init__(
        self,
        mode: str,
        action: str,
        key: bytes,
        iv: bytes,
        tags: bytes,
        aad: bytes = None,
    ):
        """
        :param mode: cbc or gcm
        :param action: encrypt or decrypt
        :param key: 32 bytes
        :param iv:  16 bytes (cbc) or 12 bytes (gcm nonce)
        :param tags:  required for gcm decrypt
        :param aad:   GCM additional authenticated data, CipherHUB compatible by default
        """
        self.__mode = mode
        self.__action = action
        self.__tags = tags
        self.__key = key
        self.__iv = iv
        if mode == aes_cbc_mode:
            self.__aes_cbc_obj = Cipher(
                algorithms.AES(self.__key),
                modes.CBC(self.__iv),
                backend=default_backend(),
            )
            if action == aes_encrypt_action:
                self.__aes_cbc_enc_op = self.__aes_cbc_obj.encryptor()
            if action == aes_decrypt_action:
                self.__aes_cbc_dec_op = self.__aes_cbc_obj.decryptor()
        if mode == aes_gcm_mode:
            self.__auth_data = (
                aad
                if aad is not None
                else cipherhub_defaults.DEFAULT_AAD.encode("utf-8")
            )
            if action == aes_encrypt_action:
                self.__aes_gcm_obj = Cipher(
                    algorithms.AES(self.__key),
                    modes.GCM(self.__iv),
                    backend=default_backend(),
                )
                self.__aes_gcm_enc_op = self.__aes_gcm_obj.encryptor()
                self.__aes_gcm_enc_op.authenticate_additional_data(self.__auth_data)
            if action == aes_decrypt_action:
                self.__aes_gcm_obj = Cipher(
                    algorithms.AES(self.__key),
                    modes.GCM(self.__iv, self.__tags),
                    backend=default_backend(),
                )
                self.__aes_gcm_dec_op = self.__aes_gcm_obj.decryptor()
                self.__aes_gcm_dec_op.authenticate_additional_data(self.__auth_data)

    def process_data(self, data: bytes) -> bytes:
        if self.__mode == aes_cbc_mode:
            if self.__action == aes_encrypt_action:
                return self.__aes_cbc_enc_op.update(data)
            if self.__action == aes_decrypt_action:
                return self.__aes_cbc_dec_op.update(data)
        if self.__mode == aes_gcm_mode:
            if self.__action == aes_encrypt_action:
                return self.__aes_gcm_enc_op.update(data)
            if self.__action == aes_decrypt_action:
                return self.__aes_gcm_dec_op.update(data)

    def finalize(self) -> Tuple[bytes, bytes]:
        """
        GCM encrypt returns ciphertext and tag.
        GCM decrypt requires tag.
        """
        if self.__mode == aes_cbc_mode:
            if self.__action == aes_encrypt_action:
                return self.__aes_cbc_enc_op.finalize(), b""
            if self.__action == aes_decrypt_action:
                return self.__aes_cbc_dec_op.finalize(), b""
        if self.__mode == aes_gcm_mode:
            if self.__action == aes_encrypt_action:
                return self.__aes_gcm_enc_op.finalize(), self.__aes_gcm_enc_op.tag
            if self.__action == aes_decrypt_action:
                return self.__aes_gcm_dec_op.finalize(), b""

    @property
    def mode(self) -> str:
        return self.__mode

    @property
    def action(self) -> str:
        return self.__action

    @property
    def key(self) -> bytes:
        return self.__key

    @property
    def iv_nonce(self) -> bytes:
        return self.__iv


def check_b64_input_data(input_data: str, input_limit: int) -> Tuple[bool, bytes]:
    """Validate and decode base64 input. Returns (success, decoded_bytes)."""
    if input_data is None:
        error("need input data")
        return False, b""
    valid, input_raw_bytes = common.check_b64_data(input_data)
    if not valid:
        error("invalid b64 encoded data")
        hints.hint_invalid_b64("AES")
        return False, b""
    if len(input_raw_bytes) > input_limit * 1024 * 1024:
        error(
            "data exceeds limit: {} Bytes (max {} Bytes)".format(
                len(input_raw_bytes), input_limit * 1024 * 1024
            )
        )
        return False, b""
    if len(input_raw_bytes) <= 0:
        error("got empty after base64 decode")
        return False, b""
    return True, input_raw_bytes


@click.command(
    name="aes", short_help="AES encrypt/decrypt, supports aes-cbc-256 and aes-gcm-256"
)
@click.option(
    "-m",
    "--mode",
    required=False,
    type=click.Choice([aes_cbc_mode, aes_gcm_mode]),
    default="cbc",
    show_default=True,
    help="AES mode: cbc or gcm, default cbc",
    is_flag=False,
    multiple=False,
)
@click.option(
    "-k",
    "--key",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_KEY_32,
    help="Key 32 bytes (256-bit), CipherHUB compatible; pad or truncate as needed",
    show_default=True,
    is_flag=False,
    multiple=False,
)
@click.option(
    "-v",
    "--iv-nonce",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_IV_16,
    help="CBC: iv 16 bytes; GCM: nonce 12 bytes. CipherHUB compatible; pad or truncate as needed",
    show_default=True,
    is_flag=False,
    multiple=False,
)
@click.option(
    "--aad",
    required=False,
    type=click.STRING,
    default=cipherhub_defaults.DEFAULT_AAD,
    help='GCM additional authenticated data (AAD), default: "{}"'.format(
        cipherhub_defaults.DEFAULT_AAD
    ),
    show_default=True,
    is_flag=False,
    multiple=False,
)
@click.option(
    "-r",
    "--random-key-iv",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    help="Auto-generate random key and iv/nonce (key 32 bytes, iv 16 bytes, nonce 12 bytes)",
    multiple=False,
)
@click.option(
    "--key-b64",
    required=False,
    type=click.STRING,
    default=None,
    help="[Advanced] Key as base64-encoded bytes (32 bytes). Mutually exclusive with -k when used.",
)
@click.option(
    "--iv-b64",
    required=False,
    type=click.STRING,
    default=None,
    help="[Advanced] IV/nonce as base64-encoded bytes (CBC: 16 bytes, GCM: 12 bytes). Mutually exclusive with -v when used.",
)
@click.option(
    "-A",
    "--action",
    required=False,
    type=click.Choice([aes_encrypt_action, aes_decrypt_action]),
    default="encrypt",
    show_default=True,
    help="encrypt or decrypt; encrypt outputs base64-encoded string",
    is_flag=False,
    multiple=False,
)
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="Input data: encrypt accepts string/base64/file; decrypt accepts base64/file",
    shell_complete=shell_completion.complete_file_path_if_input_is_file,
)
@click.option(
    "-e",
    "--is-base64-encoded",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="Input is base64-encoded; -e and -f are mutually exclusive",
)
@click.option(
    "-f",
    "--is-a-file",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=False,
    help="Input is a file path; -e and -f are mutually exclusive",
)
@click.option(
    "-l",
    "--input-limit",
    required=False,
    type=click.INT,
    default=1,
    show_default=True,
    help="Max input length in MB (default 1), applies when -i is not a file; use -l N for larger data",
)
@click.option(
    "-o",
    "--output-file",
    required=False,
    type=click.STRING,
    default="",
    help="Output file path; required when input is a file",
    shell_complete=shell_completion.complete_file_path,
)
@click.option(
    "--no-force",
    is_flag=True,
    default=False,
    help="Do not overwrite existing output file (default: overwrite)",
)
@click.option(
    "--gcm-pad",
    required=False,
    type=click.BOOL,
    is_flag=True,
    default=False,
    show_default=True,
    help="[GCM only] PKCS#7 pad plaintext before encrypt, unpad after decrypt. Default: no padding (CipherHUB compatible); "
    "encrypt and decrypt must both use or both omit --gcm-pad. "
    "File decrypt with --gcm-pad loads entire file into memory; large files may cause OOM.",
)
@output_format_options
@click.pass_context
def aes_command(
    ctx: click.Context,
    mode: click.STRING,
    key: click.STRING,
    iv_nonce: click.STRING,
    random_key_iv: click.BOOL,
    key_b64: str | None,
    iv_b64: str | None,
    action: click.STRING,
    input_data: click.STRING,
    is_base64_encoded: click.BOOL,
    is_a_file: click.BOOL,
    input_limit: click.INT,
    output_file: click.STRING,
    aad: click.STRING,
    no_force: bool,
    gcm_pad: bool = False,
    output_format: str | None = None,
):
    """
    Encrypt: plaintext/base64(-e)/file(-f). Decrypt: base64(-e)/file(-f).
    Default -i is UTF-8 plaintext; -e means base64; -f means file path.
    """
    request_id = create_request_id()
    start = time.perf_counter()

    key_bytes: bytes
    iv_bytes: bytes
    key_display: str  # for output when -r
    iv_display: str

    if random_key_iv:
        if key_b64 is not None or iv_b64 is not None:
            error("AES: -r/--random-key-iv cannot be used with --key-b64 or --iv-b64")
            return
        key, iv_nonce, _, _, _, _ = process_key_iv(random_key_iv, key, iv_nonce, mode)
        key_bytes = key.encode("utf-8")
        iv_bytes = iv_nonce.encode("utf-8")
        key_display = key
        iv_display = iv_nonce
    else:
        key_from_cli = ctx.get_parameter_source("key") == ParameterSource.COMMANDLINE
        iv_from_cli = ctx.get_parameter_source("iv_nonce") == ParameterSource.COMMANDLINE
        if key_b64 is not None and key_from_cli:
            error("AES: -k/--key and --key-b64 are mutually exclusive; specify one only")
            return
        if iv_b64 is not None and iv_from_cli:
            error("AES: -v/--iv-nonce and --iv-b64 are mutually exclusive; specify one only")
            return
        key_str, iv_str, key_padded, iv_padded, key_truncated, iv_truncated = process_key_iv(
            False, key, iv_nonce, mode
        )
        if key_b64 is not None or iv_b64 is not None:
            ok, err, kb, ib = common.decode_key_iv_b64(
                key_b64,
                iv_b64,
                key_len=aes_key_len_256,
                iv_len=aes_iv_len_128,
                nonce_len=aes_nonce_len_128,
                mode=mode,
            )
            if not ok:
                error("AES: {}".format(err or ""))
                return
            key_bytes = kb if kb is not None else key_str.encode("utf-8")
            iv_bytes = ib if ib is not None else iv_str.encode("utf-8")
        else:
            key_bytes = key_str.encode("utf-8")
            iv_bytes = iv_str.encode("utf-8")
        key_display = key_str
        iv_display = iv_str
        # Security warnings
        if (
            not key_from_cli
            and not iv_from_cli
            and key_b64 is None
            and iv_b64 is None
        ):
            warning(
                "Using default key/IV. Insecure for production. Use -r or provide explicit -k/-v."
            )
        if (key_padded or iv_padded) and key_b64 is None and iv_b64 is None:
            warning(
                "Key/IV was padded (short input). Ensure compatibility with peer; consider using full-length key/IV."
            )
        if (key_truncated or iv_truncated) and key_b64 is None and iv_b64 is None:
            warning(
                "Key/IV was truncated (long input). Ensure compatibility with peer; consider using exact-length key/IV."
            )

    if len(input_data) <= 0:
        error("no input data, it is required")
        return

    ok, err = validators.validate_b64_or_file(is_base64_encoded, is_a_file, "AES")
    if not ok:
        error(err or "")
        hints.hint_input_file_or_b64_conflict()
        return

    ok, err = validators.validate_file_output_required(is_a_file, output_file, "AES")
    if not ok:
        error(err or "")
        return

    if (
        action == aes_decrypt_action
        and not is_base64_encoded
        and not is_a_file
    ):
        error("decrypt requires base64 cipher or file; use -e for base64 input")
        hints.hint_invalid_b64("AES")
        return

    input_raw_bytes = b""
    input_raw_tag = b""
    gcm_decrypt_total_input_len = 0  # total input (cipher+tag) for GCM decrypt display

    # If input is base64-encoded
    if is_base64_encoded:
        ok, input_raw_bytes = check_b64_input_data(input_data, input_limit)
        if not ok:
            return
        # GCM decrypt: cipher format is cipher||tag, split from end
        if mode == aes_gcm_mode and action == aes_decrypt_action:
            if len(input_raw_bytes) < aes_gcm_tag_len:
                error(
                    "invalid cipher: too short for gcm tag (need at least {} bytes)".format(
                        aes_gcm_tag_len
                    )
                )
                return
            gcm_decrypt_total_input_len = len(input_raw_bytes)
            input_raw_tag = input_raw_bytes[-aes_gcm_tag_len:]
            input_raw_bytes = input_raw_bytes[:-aes_gcm_tag_len]

    input_from_file = None
    output_to_file = None

    # Neither base64 nor file: treat as UTF-8 plaintext string
    if not is_base64_encoded and not is_a_file:
        if len(input_data) > input_limit * 1024 * 1024:
            error(
                "data exceeds limit: {} Bytes (max {} Bytes)".format(
                    len(input_data), input_limit * 1024 * 1024
                )
            )
            return
        try:
            input_raw_bytes = input_data.encode("utf-8")
        except UnicodeEncodeError:
            error("input contains invalid UTF-8 characters")
            return

    file_gcm_cipher_bytes = None

    if len(output_file) > 0:
        try:
            output_to_file = common.write_to_file(output_file, force=not no_force)
        except OSError:
            error(
                "{} may not exist or may not be writable (use --no-force to avoid overwrite)".format(
                    output_file
                )
            )
            return

    # GCM decrypt needs tag (parsed from cipher end, format cipher||tag)
    # Skip when is_a_file: tag will be parsed from file in the file block
    if (
        mode == aes_gcm_mode
        and action == aes_decrypt_action
        and len(input_raw_tag) == 0
        and not is_a_file
    ):
        error("gcm mode decrypt requires cipher in base64(cipher||tag) format")
        return

    def _make_aes_op(tag: bytes):
        return aes_operator(
            mode=mode,
            action=action,
            key=key_bytes,
            iv=iv_bytes,
            tags=tag,
            aad=aad.encode("utf-8") if aad else None,
        )

    # --gcm-pad only applies in GCM mode; CBC always pads
    use_gcm_pad = mode == aes_gcm_mode and gcm_pad

    if not is_a_file:
        aes_op = _make_aes_op(input_raw_tag)
        if action == aes_encrypt_action:
            if mode == aes_cbc_mode:
                padded_raw_bytes = padding_data(input_raw_bytes)
            else:
                # GCM: no padding by default; pad only when --gcm-pad
                padded_raw_bytes = (
                    padding_data(input_raw_bytes) if use_gcm_pad else input_raw_bytes
                )
            cipher = aes_op.process_data(padded_raw_bytes)
            cipher_last_block, ret_tags = aes_op.finalize()
            all_cipher = cipher + cipher_last_block
            if mode == aes_gcm_mode:
                # GCM: output single base64 cipher (cipher||tag, NIST SP 800-38D format)
                cipher_with_tag = all_cipher + ret_tags
                if not common.validate_gcm_cipher_format(
                    cipher_with_tag, aes_gcm_tag_len
                ):
                    error("invalid gcm cipher format: cipher_with_tag length < tag_len")
                    return
                all_cipher_str = base64.b64encode(cipher_with_tag).decode("utf-8")
                if output_to_file is not None and not output_to_file.write_bytes(
                    cipher_with_tag
                ):
                    return
                duration_ms = (time.perf_counter() - start) * 1000
                alg_name = "aes-gcm-256"
                input_type = "binary" if is_base64_encoded else "text"
                formats = {"cipher": "base64"}
                if random_key_iv:
                    formats["key"] = "utf-8"
                    formats["iv"] = "utf-8"
                metadata = build_metadata(
                    operation="encrypt",
                    algorithm=alg_name,
                    formats=formats,
                    input_type=input_type,
                    input_size=len(input_raw_bytes),
                    parameters={
                        "mode": "gcm",
                        "tag_size": len(ret_tags),
                        "nonce_size": len(iv_bytes),
                    },
                )
                result_data = {"cipher": all_cipher_str}
                if random_key_iv:
                    result_data["key"] = key_display
                    result_data["iv"] = iv_display
                result = build_result(**result_data)
                output = build_output(
                    metadata=metadata,
                    result=result,
                    request_id=request_id,
                    duration_ms=duration_ms,
                )
                mode_fmt = resolve_output_format(output_format)
                render(output, mode=mode_fmt, primary_key="cipher")
            else:
                all_cipher_str = base64.b64encode(all_cipher).decode("utf-8")
                if output_to_file is not None and not output_to_file.write_bytes(
                    all_cipher
                ):
                    return
                duration_ms = (time.perf_counter() - start) * 1000
                alg_name = "aes-cbc-256"
                input_type = "binary" if is_base64_encoded else "text"
                formats = {"cipher": "base64"}
                if random_key_iv:
                    formats["key"] = "utf-8"
                    formats["iv"] = "utf-8"
                metadata = build_metadata(
                    operation="encrypt",
                    algorithm=alg_name,
                    formats=formats,
                    input_type=input_type,
                    input_size=len(input_raw_bytes),
                    parameters={
                        "mode": "cbc",
                        "iv_size": len(iv_bytes),
                    },
                )
                result_data = {"cipher": all_cipher_str}
                if random_key_iv:
                    result_data["key"] = key_display
                    result_data["iv"] = iv_display
                result = build_result(**result_data)
                output = build_output(
                    metadata=metadata,
                    result=result,
                    request_id=request_id,
                    duration_ms=duration_ms,
                )
                mode_fmt = resolve_output_format(output_format)
                render(output, mode=mode_fmt, primary_key="cipher")
        if action == aes_decrypt_action:
            try:
                plain = aes_op.process_data(input_raw_bytes)
                plain_last_block, ret_tags = aes_op.finalize()
                raw_plain = plain + plain_last_block
                if mode == aes_cbc_mode:
                    origin_plain = remove_padding_data(raw_plain)
                else:
                    # GCM: remove PKCS#7 padding only when --gcm-pad
                    origin_plain = (
                        remove_padding_data(raw_plain) if use_gcm_pad else raw_plain
                    )
            except InvalidTag:
                error(
                    "decrypt failed: GCM authentication tag verification failed (cipher may be tampered)"
                )
                hint_msg = validators.hint_decrypt_maybe_b64(input_data, "AES decrypt")
                if hint_msg:
                    hint(hint_msg)
                return
            except ValueError as e:
                err_msg = str(e).lower()
                if "padding" in err_msg or "pkcs7" in err_msg:
                    error(
                        "decrypt failed: PKCS#7 unpad error. If cipher was GCM-encrypted without padding, retry without --gcm-pad"
                    )
                else:
                    error("decrypt failed: {}".format(e))
                hint_msg = validators.hint_decrypt_maybe_b64(input_data, "AES decrypt")
                if hint_msg:
                    hint(hint_msg)
                return
            except BaseException as e:
                error("decrypt failed: {}".format(e))
                hint_msg = validators.hint_decrypt_maybe_b64(input_data, "AES decrypt")
                if hint_msg:
                    hint(hint_msg)
                return
            else:  # If decrypt succeeds, try UTF-8 decode; if ok print directly, else print base64
                be_str, ret = common.bytes_to_str(origin_plain)
                if output_to_file is not None and not output_to_file.write_bytes(
                    origin_plain
                ):
                    return
                duration_ms = (time.perf_counter() - start) * 1000
                alg_name = "aes-gcm-256" if mode == aes_gcm_mode else "aes-cbc-256"
                input_type = "binary" if is_base64_encoded else "text"
                params = {"mode": "gcm" if mode == aes_gcm_mode else "cbc"}
                if mode == aes_gcm_mode:
                    params["tag_size"] = len(input_raw_tag)
                metadata = build_metadata(
                    operation="decrypt",
                    algorithm=alg_name,
                    formats={"plain": "utf-8" if be_str else "base64"},
                    input_type=input_type,
                    input_size=len(input_raw_bytes) + (len(input_raw_tag) if mode == aes_gcm_mode else 0),
                    parameters=params,
                )
                result = build_result(plain=ret)
                output = build_output(
                    metadata=metadata,
                    result=result,
                    request_id=request_id,
                    duration_ms=duration_ms,
                )
                mode_fmt = resolve_output_format(output_format)
                render(output, mode=mode_fmt, primary_key="plain")

    if is_a_file and output_to_file is not None:
        try:
            # GCM file decrypt: streaming path (avoid loading entire file into memory)
            # When use_gcm_pad we need full plaintext for unpad, so fall back to buffered path
            if (
                mode == aes_gcm_mode
                and action == aes_decrypt_action
                and not use_gcm_pad
            ):
                try:
                    with common.stream_gcm_cipher_from_file(
                        input_data, aes_gcm_tag_len
                    ) as (input_raw_tag, fin, cipher_size):
                        aes_op = _make_aes_op(input_raw_tag)
                        output_size = 0
                        remaining = cipher_size
                        if remaining == 0:
                            # M-03: cipher_size==0 means file has only Tag (16 bytes), no ciphertext
                            plain = aes_op.process_data(b"")
                            plain_last, _ = aes_op.finalize()
                            raw_plain = plain + plain_last
                            origin_plain = (
                                remove_padding_data(raw_plain)
                                if use_gcm_pad
                                else raw_plain
                            )
                            output_size = len(origin_plain)
                            if not output_to_file.write_bytes(origin_plain):
                                return
                        else:
                            while remaining > 0:
                                to_read = min(
                                    common.GCM_STREAM_CHUNK_SIZE, remaining
                                )
                                chunk = fin.read(to_read)
                                remaining -= len(chunk)
                                plain = aes_op.process_data(chunk)
                                output_size += len(plain)
                                if not output_to_file.write_bytes(plain):
                                    return
                            plain_last, _ = aes_op.finalize()
                            output_size += len(plain_last)
                            origin_plain = (
                                remove_padding_data(plain_last)
                                if use_gcm_pad
                                else plain_last
                            )
                            if not output_to_file.write_bytes(origin_plain):
                                return
                        duration_ms = (time.perf_counter() - start) * 1000
                        formats = {"output_file": "path"}
                        metadata = build_metadata(
                            operation="decrypt",
                            algorithm="aes-gcm-256",
                            formats=formats,
                            input_type="file",
                            input_size=os.stat(input_data).st_size,
                            parameters={"mode": "gcm"},
                        )
                        result = build_result(
                            output_file=output_file, plain_size=output_size
                        )
                        output = build_output(
                            metadata=metadata,
                            result=result,
                            request_id=request_id,
                            duration_ms=duration_ms,
                        )
                        render(
                            output,
                            mode=resolve_output_format(output_format),
                            primary_key="output_file",
                        )
                except ValueError as e:
                    if output_to_file is not None:
                        output_to_file.abort()
                    if "too short" in str(e).lower():
                        error("invalid cipher file: too short for gcm tag")
                    else:
                        error("decrypt failed: {}".format(e))
                    return
                except InvalidTag:
                    if output_to_file is not None:
                        output_to_file.abort()
                    error(
                        "decrypt failed: GCM authentication tag verification failed"
                    )
                    return
                except BaseException as e:
                    if output_to_file is not None:
                        output_to_file.abort()
                    error("decrypt failed: {}".format(e))
                    return
                return

            with common.read_from_file(input_data) as input_from_file:
                file_gcm_cipher_bytes = None
                input_raw_tag = b""
                if mode == aes_gcm_mode and action == aes_decrypt_action:
                    # use_gcm_pad: need full plaintext for unpad, use buffered path
                    file_size_for_read = os.stat(input_data).st_size
                    if file_size_for_read < aes_gcm_tag_len:
                        error("invalid cipher file: too short for gcm tag")
                        return
                    warning(
                        "--gcm-pad with file decrypt loads entire file into memory; "
                        "large files may cause OOM"
                    )
                    file_content = input_from_file.read_n_bytes(file_size_for_read)
                    input_raw_tag = file_content[-aes_gcm_tag_len:]
                    file_gcm_cipher_bytes = file_content[:-aes_gcm_tag_len]
                aes_op = _make_aes_op(input_raw_tag)
                read_size = common.FILE_READ_CHUNK_SIZE
                init_file_size = os.stat(input_data).st_size
                file_size = init_file_size
                output_size = 0

                if action == aes_encrypt_action:
                    while True:
                        chunk = input_from_file.read_n_bytes(read_size)
                        file_size -= len(chunk)
                        if file_size <= 0:
                            if mode == aes_cbc_mode:
                                chunk = padding_data(chunk)
                            else:
                                chunk = padding_data(chunk) if use_gcm_pad else chunk
                            cipher = aes_op.process_data(chunk)
                            output_size += len(cipher)
                            cipher_last_block, tag = aes_op.finalize()
                            output_size += len(cipher_last_block)
                            if mode == aes_gcm_mode:
                                cipher_with_tag = cipher + cipher_last_block + tag
                                if not common.validate_gcm_cipher_format(
                                    cipher_with_tag, aes_gcm_tag_len
                                ):
                                    error(
                                        "invalid gcm cipher format: cipher_with_tag length < tag_len"
                                    )
                                    return
                                if not output_to_file.write_bytes(cipher_with_tag):
                                    return
                                duration_ms = (time.perf_counter() - start) * 1000
                                formats = {"output_file": "path"}
                                if random_key_iv:
                                    formats["key"] = "utf-8"
                                    formats["iv"] = "utf-8"
                                metadata = build_metadata(
                                    operation="encrypt",
                                    algorithm="aes-gcm-256",
                                    formats=formats,
                                    input_type="file",
                                    input_size=init_file_size,
                                    parameters={"mode": "gcm", "tag_size": len(tag)},
                                )
                                result_data = {"output_file": output_file, "cipher_size": output_size + len(tag)}
                                if random_key_iv:
                                    result_data["key"] = key_display
                                    result_data["iv"] = iv_display
                                result = build_result(**result_data)
                                output = build_output(
                                    metadata=metadata,
                                    result=result,
                                    request_id=request_id,
                                    duration_ms=duration_ms,
                                )
                                render(output, mode=resolve_output_format(output_format), primary_key="output_file")
                            else:
                                if not output_to_file.write_bytes(cipher):
                                    return
                                if not output_to_file.write_bytes(cipher_last_block):
                                    return
                                duration_ms = (time.perf_counter() - start) * 1000
                                formats = {"output_file": "path"}
                                if random_key_iv:
                                    formats["key"] = "utf-8"
                                    formats["iv"] = "utf-8"
                                metadata = build_metadata(
                                    operation="encrypt",
                                    algorithm="aes-cbc-256",
                                    formats=formats,
                                    input_type="file",
                                    input_size=init_file_size,
                                    parameters={"mode": "cbc"},
                                )
                                result_data = {"output_file": output_file, "cipher_size": output_size}
                                if random_key_iv:
                                    result_data["key"] = key_display
                                    result_data["iv"] = iv_display
                                result = build_result(**result_data)
                                output = build_output(
                                    metadata=metadata,
                                    result=result,
                                    request_id=request_id,
                                    duration_ms=duration_ms,
                                )
                                render(output, mode=resolve_output_format(output_format), primary_key="output_file")
                            break
                        cipher = aes_op.process_data(chunk)
                        output_size += len(cipher)
                        if not output_to_file.write_bytes(cipher):
                            return

                if action == aes_decrypt_action:
                    try:
                        if mode == aes_gcm_mode and file_gcm_cipher_bytes is not None:
                            plain = aes_op.process_data(file_gcm_cipher_bytes)
                            plain_last_block, _ = aes_op.finalize()
                            raw_plain = plain + plain_last_block
                            origin_plain = (
                                remove_padding_data(raw_plain)
                                if use_gcm_pad
                                else raw_plain
                            )
                            output_size = len(origin_plain)
                            if not output_to_file.write_bytes(origin_plain):
                                return
                            duration_ms = (time.perf_counter() - start) * 1000
                            metadata = build_metadata(
                                operation="decrypt",
                                algorithm="aes-gcm-256",
                                formats={"output_file": "path"},
                                input_type="file",
                                input_size=os.stat(input_data).st_size,
                                parameters={"mode": "gcm"},
                            )
                            result = build_result(output_file=output_file, plain_size=output_size)
                            output = build_output(
                                metadata=metadata,
                                result=result,
                                request_id=request_id,
                                duration_ms=duration_ms,
                            )
                            render(output, mode=resolve_output_format(output_format), primary_key="output_file")
                        else:
                            if mode == aes_cbc_mode and (
                                file_size < aes_file_read_block
                                or file_size % aes_file_read_block != 0
                            ):
                                error(
                                    "invalid cipher file size: {} Bytes".format(
                                        file_size
                                    )
                                )
                                return
                            while True:
                                chunk = input_from_file.read_n_bytes(read_size)
                                file_size -= len(chunk)
                                plain = aes_op.process_data(chunk)
                                if file_size == 0:
                                    plain_last, _ = aes_op.finalize()
                                    plain = remove_padding_data(plain + plain_last)
                                    output_size += len(plain)
                                    if not output_to_file.write_bytes(plain):
                                        return
                                    duration_ms = (time.perf_counter() - start) * 1000
                                    metadata = build_metadata(
                                        operation="decrypt",
                                        algorithm="aes-cbc-256",
                                        formats={"output_file": "path"},
                                        input_type="file",
                                        input_size=os.stat(input_data).st_size,
                                        parameters={"mode": "cbc"},
                                    )
                                    result = build_result(output_file=output_file, plain_size=output_size)
                                    output = build_output(
                                        metadata=metadata,
                                        result=result,
                                        request_id=request_id,
                                        duration_ms=duration_ms,
                                    )
                                    render(output, mode=resolve_output_format(output_format), primary_key="output_file")
                                    return
                                output_size += len(plain)
                                if not output_to_file.write_bytes(plain):
                                    return
                    except InvalidTag:
                        if output_to_file is not None:
                            output_to_file.abort()
                        error(
                            "decrypt failed: GCM authentication tag verification failed"
                        )
                        return
                    except ValueError as e:
                        if output_to_file is not None:
                            output_to_file.abort()
                        err_msg = str(e).lower()
                        if "padding" in err_msg or "pkcs7" in err_msg:
                            error(
                                "decrypt failed: PKCS#7 unpad error. If cipher was GCM-encrypted without padding, retry without --gcm-pad"
                            )
                        else:
                            error("decrypt {} failed: {}".format(input_data, e))
                        return
                    except BaseException as e:
                        if output_to_file is not None:
                            output_to_file.abort()
                        error("decrypt {} failed: {}".format(input_data, e))
                        return
        except OSError:
            error("{} may not exist or may be unreadable".format(input_data))


if __name__ == "__main__":
    aes_command()
