#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
字符串格式转换：UTF-8 ↔ Base64 ↔ Hex
"""
from __future__ import annotations

import base64
import binascii
import string
import time

import click

from easy_encryption_tool import common
from easy_encryption_tool.output_builder import (
    build_metadata,
    build_output,
    build_result,
    create_request_id,
)
from easy_encryption_tool.output_renderer import (
    output_format_options,
    render,
    resolve_output_format,
)
from easy_encryption_tool.rich_ui import error


def _is_printable_utf8(data: bytes) -> bool:
    """判断字节流是否为可打印 UTF-8 文本（所有字符均在 string.printable 内）"""
    try:
        s = data.decode("utf-8")
        return all(c in string.printable for c in s)
    except UnicodeDecodeError:
        return False


@click.group(name="convert", short_help="String format conversion: UTF-8, Base64, Hex")
def convert_group():
    """字符串格式转换：UTF-8 与 Base64、Hex 之间的编码/解码。"""
    pass


@convert_group.command(name="utf8-to-base64", short_help="UTF-8 string to Base64")
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="输入：UTF-8 编码的字符串",
)
@output_format_options
def utf8_to_base64(input_data: str, output_format: str | None):
    """将 UTF-8 字符串编码为 Base64 字符串。"""
    request_id = create_request_id()
    start = time.perf_counter()

    try:
        raw_bytes = input_data.encode("utf-8")
    except UnicodeEncodeError:
        error("输入包含非法 UTF-8 字符")
        return

    result_b64 = base64.b64encode(raw_bytes).decode("ascii")
    duration_ms = (time.perf_counter() - start) * 1000

    metadata = build_metadata(
        operation="encode",
        algorithm="utf8-to-base64",
        encoding="base64",
        input_type="text",
        input_size=len(raw_bytes),
        parameters={"source": "utf-8", "target": "base64"},
    )
    result = build_result(value=result_b64)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key="value")


@convert_group.command(name="utf8-to-hex", short_help="UTF-8 string to Hex")
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="输入：UTF-8 编码的字符串",
)
@output_format_options
def utf8_to_hex(input_data: str, output_format: str | None):
    """将 UTF-8 字符串编码为 Hex 字符串。"""
    request_id = create_request_id()
    start = time.perf_counter()

    try:
        raw_bytes = input_data.encode("utf-8")
    except UnicodeEncodeError:
        error("输入包含非法 UTF-8 字符")
        return

    result_hex = raw_bytes.hex()
    duration_ms = (time.perf_counter() - start) * 1000

    metadata = build_metadata(
        operation="encode",
        algorithm="utf8-to-hex",
        encoding="hex",
        input_type="text",
        input_size=len(raw_bytes),
        parameters={"source": "utf-8", "target": "hex"},
    )
    result = build_result(value=result_hex)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key="value")


@convert_group.command(name="base64-decode", short_help="Base64 decode to UTF-8 or Hex")
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="输入：Base64 编码的字符串",
)
@output_format_options
def base64_decode(input_data: str, output_format: str | None):
    """解码 Base64 字符串。若解码后的字节均为可打印 UTF-8 字符则输出 UTF-8，否则输出 Hex。"""
    request_id = create_request_id()
    start = time.perf_counter()

    try:
        raw_bytes = common.decode_b64_data(input_data)
    except (binascii.Error, ValueError) as e:
        error("Base64 解码失败: {}".format(e))
        return

    output_as_utf8 = _is_printable_utf8(raw_bytes)
    if output_as_utf8:
        value = raw_bytes.decode("utf-8")
        out_encoding = "utf-8"
    else:
        value = raw_bytes.hex()
        out_encoding = "hex"

    duration_ms = (time.perf_counter() - start) * 1000

    metadata = build_metadata(
        operation="decode",
        algorithm="base64-decode",
        encoding=out_encoding,
        input_type="base64",
        input_size=len(input_data),
        parameters={"source": "base64", "target": out_encoding, "auto_detected": True},
    )
    result = build_result(value=value, output_encoding=out_encoding)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key="value")


@convert_group.command(name="hex-decode", short_help="Hex decode to UTF-8 or Base64")
@click.option(
    "-i",
    "--input-data",
    required=True,
    type=click.STRING,
    help="输入：Hex 编码的字符串（偶数长度，仅含 0-9a-fA-F）",
)
@output_format_options
def hex_decode(input_data: str, output_format: str | None):
    """解码 Hex 字符串。若解码后的字节均为可打印 UTF-8 字符则输出 UTF-8，否则输出 Base64。"""
    request_id = create_request_id()
    start = time.perf_counter()

    input_clean = input_data.strip().replace(" ", "").replace("\n", "").replace("\r", "")
    if len(input_clean) % 2 != 0:
        error("Hex 字符串长度必须为偶数")
        return
    try:
        raw_bytes = bytes.fromhex(input_clean)
    except ValueError as e:
        error("Hex 解码失败: {}".format(e))
        return

    output_as_utf8 = _is_printable_utf8(raw_bytes)
    if output_as_utf8:
        value = raw_bytes.decode("utf-8")
        out_encoding = "utf-8"
    else:
        value = base64.b64encode(raw_bytes).decode("ascii")
        out_encoding = "base64"

    duration_ms = (time.perf_counter() - start) * 1000

    metadata = build_metadata(
        operation="decode",
        algorithm="hex-decode",
        encoding=out_encoding,
        input_type="hex",
        input_size=len(input_clean) // 2,
        parameters={"source": "hex", "target": out_encoding, "auto_detected": True},
    )
    result = build_result(value=value, output_encoding=out_encoding)
    output = build_output(
        metadata=metadata,
        result=result,
        request_id=request_id,
        duration_ms=duration_ms,
    )
    render(output, mode=resolve_output_format(output_format), primary_key="value")


if __name__ == "__main__":
    convert_group()
