#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SM2 命令单元测试（需 easy_gmssl）。
"""
from __future__ import annotations

import os
import re
import tempfile

import pytest
from click.testing import CliRunner

from .conftest import extract_base64, extract_value_after_key, strip_ansi
from easy_encryption_tool import sm2_command


runner = CliRunner()
GMSSL_AVAILABLE = getattr(sm2_command, "EASY_GMSSL_AVAILABLE", False)


@pytest.fixture
def sm2_key_pair(tmp_path):
    """生成 SM2 密钥对"""
    if not GMSSL_AVAILABLE:
        pytest.skip("easy_gmssl not installed")
    prefix = str(tmp_path / "sm2_demo")
    result = runner.invoke(
        sm2_command.sm2_generate,
        ["-f", prefix, "-p", "12345678"],
    )
    assert result.exit_code == 0
    pub = tmp_path / "sm2_demo_sm2_public.pem"
    pri = tmp_path / "sm2_demo_sm2_private.pem"
    if not pub.exists():
        files = list(tmp_path.glob("*.pem"))
        pub = next((f for f in files if "public" in f.name), pub)
        pri = next((f for f in files if "private" in f.name), pri)
    return str(pub), str(pri), "12345678"


@pytest.mark.skipif(not GMSSL_AVAILABLE, reason="easy_gmssl not installed")
class TestSm2Generate:
    """SM2 密钥生成"""

    def test_generate_with_password(self, tmp_path):
        result = runner.invoke(
            sm2_command.sm2_generate,
            ["-f", str(tmp_path / "k"), "-p", "pass123"],
        )
        assert result.exit_code == 0

    def test_generate_invalid_password_length_fails(self, tmp_path):
        result = runner.invoke(
            sm2_command.sm2_generate,
            ["-f", str(tmp_path / "k"), "-p", ""],
        )
        assert result.exit_code != 0


@pytest.mark.skipif(not GMSSL_AVAILABLE, reason="easy_gmssl not installed")
class TestSm2EncryptDecrypt:
    """SM2 加解密"""

    def test_encrypt_decrypt_roundtrip(self, sm2_key_pair):
        pub_path, pri_path, password = sm2_key_pair
        enc = runner.invoke(
            sm2_command.sm2_encrypt,
            ["-f", pub_path, "-i", "hello"],
        )
        assert enc.exit_code == 0
        out = strip_ansi(enc.output)
        cipher = extract_value_after_key(out, "cipher") or extract_base64(out, min_len=50)
        if not cipher:
            for line in out.split("\n"):
                if "cipher:" in line and "cipher_mode" not in line:
                    cipher = re.sub(r"[^A-Za-z0-9+/=]", "", line.split("cipher:", 1)[1])
                    break
        assert cipher
        dec = runner.invoke(
            sm2_command.sm2_decrypt,
            ["-f", pri_path, "-i", cipher, "-p", password],
        )
        assert dec.exit_code == 0
        dec_out = strip_ansi(dec.output)
        assert "hello" in dec_out or "plain" in dec_out.lower()


@pytest.mark.skipif(not GMSSL_AVAILABLE, reason="easy_gmssl not installed")
class TestSm2SignVerify:
    """SM2 签名验签"""

    def test_sign_verify_roundtrip(self, sm2_key_pair):
        pub_path, pri_path, password = sm2_key_pair
        sign_result = runner.invoke(
            sm2_command.sm2_sign,
            [
                "-f", pri_path,
                "-i", "message",
                "-p", password,
            ],
        )
        assert sign_result.exit_code == 0
        out = strip_ansi(sign_result.output)
        sig_b64 = extract_value_after_key(out, "signature_b64") or extract_base64(out, min_len=50)
        if not sig_b64:
            for line in out.split("\n"):
                if "signature_b64:" in line:
                    sig_b64 = re.sub(r"[^A-Za-z0-9+/=]", "", line.split("signature_b64:", 1)[1])
                    break
        assert sig_b64
        verify_result = runner.invoke(
            sm2_command.sm2_verify,
            [
                "-f", pub_path,
                "-i", "message",
                "-s", sig_b64,
            ],
        )
        assert verify_result.exit_code == 0
        verify_out = strip_ansi(verify_result.output)
        assert "success" in verify_out.lower()


class TestSm2HelperFunctions:
    """SM2 辅助函数（不依赖 gmssl 的纯逻辑）"""

    def test_normalize_hex_input(self):
        from easy_encryption_tool.sm2_command import _normalize_hex_input
        assert _normalize_hex_input("0x1234") == "1234"
        assert _normalize_hex_input("  0Xab  ") == "ab"
        assert _normalize_hex_input("1234") == "1234"

    def test_cipher_format_from_str(self):
        if not GMSSL_AVAILABLE:
            pytest.skip("easy_gmssl not installed")
        from easy_encryption_tool.sm2_command import _cipher_format_from_str
        from easy_gmssl import SM2CipherFormat
        assert _cipher_format_from_str("base64") == SM2CipherFormat.Base64Str
        assert _cipher_format_from_str("hex") == SM2CipherFormat.HexStr

    def test_cipher_mode_from_str(self):
        if not GMSSL_AVAILABLE:
            pytest.skip("easy_gmssl not installed")
        from easy_encryption_tool.sm2_command import _cipher_mode_from_str
        from easy_gmssl import SM2CipherMode
        assert _cipher_mode_from_str("C1C3C2_ASN1") == SM2CipherMode.C1C3C2_ASN1
        assert _cipher_mode_from_str("C1C2C3") == SM2CipherMode.C1C2C3


@pytest.mark.skipif(not GMSSL_AVAILABLE, reason="easy_gmssl not installed")
class TestSm2AllCipherModes:
    """SM2 所有密文格式加解密"""

    def test_encrypt_decrypt_c1c2c3(self, sm2_key_pair):
        pub_path, pri_path, password = sm2_key_pair
        enc = runner.invoke(
            sm2_command.sm2_encrypt,
            ["-f", pub_path, "-i", "hello", "-m", "C1C2C3", "-o", "base64"],
        )
        assert enc.exit_code == 0
        out = strip_ansi(enc.output)
        cipher = extract_value_after_key(out, "cipher") or extract_base64(out, min_len=50)
        if not cipher:
            for line in out.split("\n"):
                if "cipher:" in line and "cipher_mode" not in line:
                    cipher = re.sub(r"[^A-Za-z0-9+/=]", "", line.split("cipher:", 1)[1])
                    break
        assert cipher
        dec = runner.invoke(
            sm2_command.sm2_decrypt,
            ["-f", pri_path, "-i", cipher, "-p", password, "-m", "C1C2C3"],
        )
        assert dec.exit_code == 0
