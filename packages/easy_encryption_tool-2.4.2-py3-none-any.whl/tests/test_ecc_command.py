#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
ECC 命令单元测试。
"""
from __future__ import annotations

import os

import pytest
from click.testing import CliRunner

from .conftest import strip_ansi
from easy_encryption_tool import ecc_command


runner = CliRunner()


@pytest.fixture
def ecc_key_pair(tmp_path):
    """生成 ECC 密钥对 (secp256r1)"""
    result = runner.invoke(
        ecc_command.generate,
        [
            "-c", "secp256r1",
            "-f", str(tmp_path / "ecc_demo"),
        ],
    )
    assert result.exit_code == 0
    pub = tmp_path / "ecc_demo_ecc_public.pem"
    pri = tmp_path / "ecc_demo_ecc_private.pem"
    assert pub.exists() and pri.exists()
    return str(pub), str(pri)


@pytest.fixture
def ecc_key_pair_bob(tmp_path):
    """Bob 的 ECC 密钥对"""
    result = runner.invoke(
        ecc_command.generate,
        ["-c", "secp256r1", "-f", str(tmp_path / "bob")],
    )
    assert result.exit_code == 0
    return (
        str(tmp_path / "bob_ecc_public.pem"),
        str(tmp_path / "bob_ecc_private.pem"),
    )


class TestEccGenerate:
    """ECC 密钥生成"""

    def test_generate_secp256r1(self, tmp_path):
        result = runner.invoke(
            ecc_command.generate,
            ["-c", "secp256r1", "-f", str(tmp_path / "test")],
        )
        assert result.exit_code == 0

    def test_generate_ed25519(self, tmp_path):
        result = runner.invoke(
            ecc_command.generate,
            ["-c", "ed25519", "-f", str(tmp_path / "ed")],
        )
        assert result.exit_code == 0

    def test_generate_x25519(self, tmp_path):
        result = runner.invoke(
            ecc_command.generate,
            ["-c", "x25519", "-f", str(tmp_path / "x")],
        )
        assert result.exit_code == 0


class TestEccSignVerify:
    """ECC 签名验签"""

    def test_sign_verify_secp256r1(self, ecc_key_pair):
        """ECC 签名验签往返（使用 cryptography 生成签名，CLI 验签）"""
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import ec
        import base64
        pub_path, pri_path = ecc_key_pair
        with open(pri_path, "rb") as f:
            pri_key = serialization.load_pem_private_key(f.read(), password=None)
        with open(pub_path, "rb") as f:
            pub_key = serialization.load_pem_public_key(f.read())
        msg = b"message"
        sig = pri_key.sign(msg, ec.ECDSA(hashes.SHA256()))
        sig_b64 = base64.b64encode(sig).decode("utf-8")
        verify_result = runner.invoke(
            ecc_command.ecc_verify,
            [
                "-f", pub_path,
                "-i", "message",
                "-s", sig_b64,
                "-a", "sha256",
            ],
        )
        assert verify_result.exit_code == 0
        assert '"valid"' in verify_result.output and "true" in verify_result.output.lower()

    def test_sign_verify_ed25519(self, tmp_path):
        runner.invoke(
            ecc_command.generate,
            ["-c", "ed25519", "-f", str(tmp_path / "ed")],
        )
        pub = tmp_path / "ed_ecc_public.pem"
        pri = tmp_path / "ed_ecc_private.pem"
        sign_result = runner.invoke(
            ecc_command.ecc_sign,
            ["-f", str(pri), "-i", "msg"],
        )
        assert sign_result.exit_code == 0
        out = strip_ansi(sign_result.output)
        import re
        sig_match = re.search(r"[A-Za-z0-9+/]{40,}=*", out)
        assert sig_match
        sig_b64 = sig_match.group(0)
        verify_result = runner.invoke(
            ecc_command.ecc_verify,
            ["-f", str(pub), "-i", "msg", "-s", sig_b64],
        )
        assert verify_result.exit_code == 0


class TestEccKeyExchange:
    """ECC 密钥交换"""

    def test_ecdh_key_exchange(self, ecc_key_pair, ecc_key_pair_bob):
        """ECDH 正常协商（-a 可选，可不传）"""
        alice_pub, alice_pri = ecc_key_pair
        bob_pub, _ = ecc_key_pair_bob
        result = runner.invoke(
            ecc_command.key_exchange,
            ["-k", alice_pri, "-b", bob_pub],
        )
        assert result.exit_code == 0
        assert '"key"' in result.output

    def test_ecdh_with_alice_pub_optional(self, ecc_key_pair, ecc_key_pair_bob):
        """ECDH 传 -a 时做一致性校验"""
        alice_pub, alice_pri = ecc_key_pair
        bob_pub, _ = ecc_key_pair_bob
        result = runner.invoke(
            ecc_command.key_exchange,
            ["-a", alice_pub, "-k", alice_pri, "-b", bob_pub],
        )
        assert result.exit_code == 0
        assert '"key"' in result.output

    def test_ecdh_same_key_pair_rejected(self, ecc_key_pair):
        """同一密钥对用于协商时应报错"""
        alice_pub, alice_pri = ecc_key_pair
        result = runner.invoke(
            ecc_command.key_exchange,
            ["-k", alice_pri, "-b", alice_pub],
        )
        assert result.exit_code != 0
        assert "same key pair" in result.output.lower()

    def test_ecdh_curve_mismatch_rejected(self, ecc_key_pair, tmp_path):
        """不同曲线（secp256r1 vs secp384r1）协商时应报错"""
        runner.invoke(ecc_command.generate, ["-c", "secp384r1", "-f", str(tmp_path / "bob384")])
        _, alice_pri = ecc_key_pair
        bob384_pub = tmp_path / "bob384_ecc_public.pem"
        result = runner.invoke(
            ecc_command.key_exchange,
            ["-k", alice_pri, "-b", str(bob384_pub)],
        )
        assert result.exit_code != 0
        assert "curve" in result.output.lower() or "mismatch" in result.output.lower()


class TestEccHelperFunctions:
    """ECC 辅助函数"""

    def test_get_curve_name_from_private_key(self):
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.backends import default_backend
        key = ec.generate_private_key(ec.SECP256R1(), default_backend())
        from easy_encryption_tool.ecc_command import _get_curve_name_from_private_key
        name = _get_curve_name_from_private_key(key)
        assert "secp256r1" in name or "prime256v1" in name
