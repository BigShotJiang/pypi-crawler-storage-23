#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
SM4 命令单元测试（需 easy_gmssl）。
"""
from __future__ import annotations

import base64
import os

import pytest
from click.testing import CliRunner

from .conftest import extract_base64, strip_ansi
from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool import sm4_command


runner = CliRunner()
GMSSL_AVAILABLE = getattr(sm4_command, "EASY_GMSSL_AVAILABLE", False)


@pytest.mark.skipif(not GMSSL_AVAILABLE, reason="easy_gmssl not installed")
class TestSm4CommandCbc:
    """SM4 CBC 模式测试"""

    def test_encrypt_plaintext(self):
        result = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "cbc", "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", "hello",
            ],
        )
        assert result.exit_code == 0

    def test_encrypt_decrypt_roundtrip(self):
        enc = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "cbc", "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", "secret",
            ],
        )
        assert enc.exit_code == 0
        out = strip_ansi(enc.output)
        cipher_b64 = extract_base64(out, min_len=16)
        if not cipher_b64:
            for line in out.split("\n"):
                if "cipher:" in line and "cipher size:" not in line:
                    cipher_b64 = line.split("cipher:", 1)[1].strip()
                    break
        assert cipher_b64
        dec = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "cbc", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", cipher_b64, "-e",
            ],
        )
        assert dec.exit_code == 0
        dec_out = strip_ansi(dec.output)
        assert "secret" in dec_out or "plain" in dec_out.lower()


@pytest.mark.skipif(not GMSSL_AVAILABLE, reason="easy_gmssl not installed")
class TestSm4CommandGcm:
    """SM4 GCM 模式测试"""

    def test_encrypt_decrypt_roundtrip(self):
        enc = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "gcm", "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", "data",
            ],
        )
        assert enc.exit_code == 0
        out = strip_ansi(enc.output)
        cipher_b64 = extract_base64(out, min_len=16)
        if not cipher_b64:
            for line in out.split("\n"):
                if "cipher:" in line and "cipher size:" not in line:
                    cipher_b64 = line.split("cipher:", 1)[1].strip()
                    break
        assert cipher_b64
        dec = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "gcm", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", cipher_b64, "-e",
            ],
        )
        assert dec.exit_code == 0


@pytest.mark.skipif(not GMSSL_AVAILABLE, reason="easy_gmssl not installed")
class TestSm4GcmPadding:
    """SM4 GCM --gcm-pad 模式"""

    def test_gcm_pad_encrypt_decrypt_roundtrip(self):
        enc = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "gcm", "-A", "encrypt", "--gcm-pad",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", "padded data",
            ],
        )
        assert enc.exit_code == 0
        out = strip_ansi(enc.output)
        cipher_b64 = extract_base64(out, min_len=16)
        if not cipher_b64:
            for line in out.split("\n"):
                if "cipher:" in line and "cipher size:" not in line:
                    cipher_b64 = line.split("cipher:", 1)[1].strip()
                    cipher_b64 = "".join(c for c in cipher_b64 if c.isalnum() or c in "+/=")
                    break
        assert cipher_b64
        dec = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "gcm", "-A", "decrypt", "--gcm-pad",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", cipher_b64, "-e",
            ],
        )
        assert dec.exit_code == 0
        assert "padded data" in strip_ansi(dec.output) or "plain" in dec.output.lower()


@pytest.mark.skipif(not GMSSL_AVAILABLE, reason="easy_gmssl not installed")
class TestSm4HelperFunctions:
    """SM4 辅助函数"""

    def test_padding_remove_padding(self):
        from easy_encryption_tool.sm4_command import padding_data, remove_padding_data
        data = b"hello"
        padded = padding_data(data)
        assert remove_padding_data(padded) == data

    def test_process_key_iv(self):
        from easy_encryption_tool.sm4_command import process_key_iv
        key, iv, _, _, _, _ = process_key_iv(
            False,
            cipherhub_defaults.DEFAULT_KEY_16,
            cipherhub_defaults.DEFAULT_IV_16,
            "cbc",
        )
        assert len(key) == 16
        assert len(iv) == 16

    def test_generate_random_key_iv(self):
        from easy_encryption_tool.sm4_command import generate_random_key, generate_random_iv_nonce
        k = generate_random_key()
        assert len(k) == 16
        iv_cbc = generate_random_iv_nonce("cbc")
        iv_gcm = generate_random_iv_nonce("gcm")
        assert len(iv_cbc) == 16
        assert len(iv_gcm) == 12


@pytest.mark.skipif(not GMSSL_AVAILABLE, reason="easy_gmssl not installed")
class TestSm4FileMode:
    """SM4 文件模式测试"""

    def test_encrypt_decrypt_file_roundtrip_cbc(self, tmp_file):
        from pathlib import Path
        plain_path = tmp_file(b"sm4 secret file")
        enc_path = plain_path + ".enc"
        dec_path = plain_path + ".dec"
        enc = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "cbc", "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", plain_path, "-f", "-o", enc_path,
            ],
        )
        assert enc.exit_code == 0
        dec = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "cbc", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", enc_path, "-f", "-o", dec_path,
            ],
        )
        assert dec.exit_code == 0
        assert Path(dec_path).read_bytes() == b"sm4 secret file"

    def test_encrypt_decrypt_file_roundtrip_gcm(self, tmp_file):
        from pathlib import Path
        plain_path = tmp_file(b"sm4 gcm file")
        enc_path = plain_path + ".enc"
        dec_path = plain_path + ".dec"
        enc = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "gcm", "-A", "encrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", plain_path, "-f", "-o", enc_path,
            ],
        )
        assert enc.exit_code == 0
        dec = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "gcm", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_NONCE_12,
                "-i", enc_path, "-f", "-o", dec_path,
            ],
        )
        assert dec.exit_code == 0
        assert Path(dec_path).read_bytes() == b"sm4 gcm file"

    def test_random_key_iv(self):
        result = runner.invoke(
            sm4_command.sm4_command,
            ["-m", "cbc", "-A", "encrypt", "-r", "-i", "hello"],
        )
        assert result.exit_code == 0

    def test_decrypt_invalid_b64_fails(self):
        result = runner.invoke(
            sm4_command.sm4_command,
            [
                "-m", "cbc", "-A", "decrypt",
                "-k", cipherhub_defaults.DEFAULT_KEY_16,
                "-v", cipherhub_defaults.DEFAULT_IV_16,
                "-i", "!!!invalid!!!", "-e",
            ],
        )
        assert result.exit_code != 0 or "invalid" in strip_ansi(result.output).lower()


@pytest.mark.skipif(GMSSL_AVAILABLE, reason="gmssl installed, skip no-gmssl tests")
class TestSm4WithoutGmssl:
    """无 easy_gmssl 时的行为"""

    def test_command_fails_with_hint(self):
        result = runner.invoke(
            sm4_command.sm4_command,
            ["-m", "cbc", "-A", "encrypt", "-i", "x"],
        )
        assert result.exit_code != 0 or "easy_gmssl" in result.output or "gmssl" in result.output.lower()
