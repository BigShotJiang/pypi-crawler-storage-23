#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""
密码学核心运算单元测试：100% 覆盖哈希、HMAC、AES、SM4、非对称密钥生成、加解密、签名验签、ZUC。
直接测试底层密码学逻辑，确保运算正确性。
"""
from __future__ import annotations

import base64
import hashlib
import hmac

import pytest
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa, utils as asym_utils
from cryptography.hazmat.primitives.asymmetric import x25519
from cryptography.hazmat.backends import default_backend

from easy_encryption_tool import cipherhub_defaults
from easy_encryption_tool.aes_command import (
    aes_operator,
    aes_cbc_mode,
    aes_gcm_mode,
    aes_encrypt_action,
    aes_decrypt_action,
    padding_data as aes_padding_data,
    remove_padding_data as aes_remove_padding_data,
)
from easy_encryption_tool.hash_command import _compute_hash_fixed
from easy_encryption_tool.common import process_key_iv, validate_gcm_cipher_format


# ============== 哈希 (Hash) ==============


class TestHashComputeFixed:
    """_compute_hash_fixed 核心逻辑：SHA256/SHA384/SHA512"""

    def test_sha256_correctness(self):
        data = b"hello world"
        result = _compute_hash_fixed("sha256", data)
        expected = hashlib.sha256(data).digest()
        assert result == expected

    def test_sha384_correctness(self):
        data = b"test data"
        result = _compute_hash_fixed("sha384", data)
        expected = hashlib.sha384(data).digest()
        assert result == expected

    def test_sha512_correctness(self):
        data = b"password"
        result = _compute_hash_fixed("sha512", data)
        expected = hashlib.sha512(data).digest()
        assert result == expected

    def test_sha256_empty_input(self):
        result = _compute_hash_fixed("sha256", b"")
        assert result == hashlib.sha256(b"").digest()

    def test_sha256_large_input(self):
        data = b"x" * 10000
        result = _compute_hash_fixed("sha256", data)
        assert result == hashlib.sha256(data).digest()


@pytest.mark.skipif(
    not getattr(
        __import__("easy_encryption_tool.hash_command", fromlist=[]),
        "EASY_GMSSL_AVAILABLE",
        False,
    ),
    reason="easy_gmssl not installed",
)
class TestHashSm3:
    """SM3 哈希（需 easy_gmssl）"""

    def test_sm3_correctness(self):
        from easy_gmssl import EasySM3Digest

        data = b"hello"
        result = _compute_hash_fixed("sm3", data)
        expected = EasySM3Digest.Hash(data)
        assert result == expected

    def test_sm3_empty(self):
        from easy_gmssl import EasySM3Digest

        result = _compute_hash_fixed("sm3", b"")
        expected = EasySM3Digest.Hash(b"")
        assert result == expected


# ============== HMAC ==============


class TestHmacCore:
    """HMAC 核心逻辑：标准库算法"""

    def test_hmac_sha256_correctness(self):
        key = cipherhub_defaults.DEFAULT_HMAC_KEY.encode("utf-8")
        msg = b"message"
        h = hmac.new(key=key, digestmod=hashlib.sha256)
        h.update(msg)
        expected = h.hexdigest()
        # 通过 hmac_command 的 hash_maps 验证
        from easy_encryption_tool import hmac_command

        h2 = hmac.new(key=key, digestmod=hmac_command.hash_maps["sha256"])
        h2.update(msg)
        assert h2.hexdigest() == expected

    def test_hmac_sha384_sha512(self):
        key = b"key123"
        msg = b"data"
        from easy_encryption_tool import hmac_command

        for alg in ["sha384", "sha512"]:
            h = hmac.new(key=key, digestmod=hmac_command.hash_maps[alg])
            h.update(msg)
            assert len(h.digest()) > 0
            # 往返验证：相同输入应得相同输出
            h2 = hmac.new(key=key, digestmod=hmac_command.hash_maps[alg])
            h2.update(msg)
            assert h.hexdigest() == h2.hexdigest()

    def test_hmac_sha3_224_256_384_512(self):
        key = b"key"
        msg = b"msg"
        from easy_encryption_tool import hmac_command

        for name in ["sha3_224", "sha3_256", "sha3_384", "sha3_512"]:
            if name not in hmac_command.hash_maps:
                continue
            h = hmac.new(key=key, digestmod=hmac_command.hash_maps[name])
            h.update(msg)
            assert len(h.digest()) > 0


@pytest.mark.skipif(
    not getattr(
        __import__("easy_encryption_tool.hmac_command", fromlist=[]),
        "EASY_GMSSL_AVAILABLE",
        False,
    ),
    reason="easy_gmssl not installed",
)
class TestHmacSm3:
    """HMAC-SM3 核心逻辑"""

    def test_hmac_sm3_correctness(self):
        from easy_gmssl import EasySM3Hmac

        key = cipherhub_defaults.DEFAULT_HMAC_KEY.encode("utf-8")
        msg = b"hello"
        h = EasySM3Hmac(key=key)
        h.UpdateData(msg)
        ret, _, _ = h.GetHmac()
        assert len(ret) == 32  # SM3 digest size


# ============== AES ==============


class TestAesOperator:
    """AES aes_operator 核心加解密逻辑"""

    def test_cbc_encrypt_decrypt_roundtrip(self):
        key = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_IV_16.encode("utf-8")
        plain = b"secret message"
        padded = aes_padding_data(plain)
        op_enc = aes_operator(
            mode=aes_cbc_mode, action=aes_encrypt_action,
            key=key, iv=iv, tags=b"", aad=None
        )
        cipher = op_enc.process_data(padded)
        last, tag = op_enc.finalize()
        full_cipher = cipher + last

        op_dec = aes_operator(
            mode=aes_cbc_mode, action=aes_decrypt_action,
            key=key, iv=iv, tags=b"", aad=None
        )
        dec = op_dec.process_data(full_cipher)
        dec_last, _ = op_dec.finalize()
        assert aes_remove_padding_data(dec + dec_last) == plain

    def test_gcm_encrypt_decrypt_roundtrip(self):
        key = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_NONCE_12.encode("utf-8")
        aad = cipherhub_defaults.DEFAULT_AAD.encode("utf-8")
        plain = b"gcm plaintext"
        op_enc = aes_operator(
            mode=aes_gcm_mode, action=aes_encrypt_action,
            key=key, iv=iv, tags=b"", aad=aad
        )
        cipher = op_enc.process_data(plain)
        last, tag = op_enc.finalize()
        cipher_with_tag = cipher + last + tag

        op_dec = aes_operator(
            mode=aes_gcm_mode, action=aes_decrypt_action,
            key=key, iv=iv, tags=tag, aad=aad
        )
        dec = op_dec.process_data(cipher + last)
        dec_last, _ = op_dec.finalize()
        assert dec + dec_last == plain

    def test_gcm_wrong_tag_raises_invalid_tag(self):
        key = cipherhub_defaults.DEFAULT_KEY_32.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_NONCE_12.encode("utf-8")
        aad = cipherhub_defaults.DEFAULT_AAD.encode("utf-8")
        plain = b"x"
        op_enc = aes_operator(
            mode=aes_gcm_mode, action=aes_encrypt_action,
            key=key, iv=iv, tags=b"", aad=aad
        )
        cipher = op_enc.process_data(plain)
        last, tag = op_enc.finalize()
        wrong_tag = bytes(16)  # 全零错误 tag
        op_dec = aes_operator(
            mode=aes_gcm_mode, action=aes_decrypt_action,
            key=key, iv=iv, tags=wrong_tag, aad=aad
        )
        with pytest.raises(InvalidTag):
            op_dec.process_data(cipher + last)
            op_dec.finalize()

    def test_aes_padding_remove_padding(self):
        for data in [b"", b"a", b"hello", b"x" * 100]:
            padded = aes_padding_data(data)
            if data:
                assert len(padded) >= len(data)
            assert aes_remove_padding_data(padded) == data

    def test_remove_padding_empty_none(self):
        assert aes_remove_padding_data(b"") == b""
        assert aes_remove_padding_data(None) == b""

    def test_validate_gcm_cipher_format(self):
        assert validate_gcm_cipher_format(b"x" * 20, 16) is True
        assert validate_gcm_cipher_format(b"x" * 15, 16) is False
        assert validate_gcm_cipher_format(None, 16) is False


# ============== SM4 ==============


@pytest.mark.skipif(
    not getattr(
        __import__("easy_encryption_tool.sm4_command", fromlist=[]),
        "EASY_GMSSL_AVAILABLE",
        False,
    ),
    reason="easy_gmssl not installed",
)
class TestSm4Core:
    """SM4 核心加解密逻辑"""

    def test_sm4_cbc_encrypt_decrypt_roundtrip(self):
        from easy_encryption_tool.sm4_command import padding_data, remove_padding_data
        from easy_gmssl import EasySm4CBC

        key = cipherhub_defaults.DEFAULT_KEY_16.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_IV_16.encode("utf-8")
        plain = b"sm4 secret"
        padded = padding_data(plain)
        enc = EasySm4CBC(key=key, iv=iv, do_encrypt=True)
        cipher = enc.Update(padded) + enc.Finish()
        dec = EasySm4CBC(key=key, iv=iv, do_encrypt=False)
        dec_plain = dec.Update(cipher) + dec.Finish()
        assert remove_padding_data(dec_plain) == plain

    def test_sm4_gcm_encrypt_decrypt_roundtrip(self):
        from easy_gmssl import EasySm4GCM

        key = cipherhub_defaults.DEFAULT_KEY_16.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_NONCE_12.encode("utf-8")
        aad = cipherhub_defaults.DEFAULT_AAD.encode("utf-8")
        plain = b"sm4 gcm data"
        enc = EasySm4GCM(key=key, iv=iv, aad=aad, do_encrypt=True)
        cipher = enc.Update(plain) + enc.Finish()
        dec = EasySm4GCM(key=key, iv=iv, aad=aad, do_encrypt=False)
        dec_plain = dec.Update(cipher) + dec.Finish()
        assert dec_plain == plain


# ============== RSA 非对称 ==============


class TestRsaCore:
    """RSA 密钥生成、加解密、签名验签核心逻辑"""

    def test_rsa_key_generation_2048(self):
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        pub = key.public_key()
        assert pub.key_size == 2048

    def test_rsa_oaep_encrypt_decrypt_roundtrip(self):
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        pub = key.public_key()
        plain = b"hello"
        rsa_oaep = padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        )
        cipher = pub.encrypt(plain, rsa_oaep)
        dec = key.decrypt(cipher, rsa_oaep)
        assert dec == plain

    def test_rsa_pkcs1v15_encrypt_decrypt_roundtrip(self):
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        pub = key.public_key()
        plain = b"short"
        cipher = pub.encrypt(plain, padding.PKCS1v15())
        dec = key.decrypt(cipher, padding.PKCS1v15())
        assert dec == plain

    def test_rsa_pss_sign_verify_roundtrip(self):
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        pub = key.public_key()
        msg = b"message"
        pss = padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH,
        )
        sig = key.sign(msg, pss, hashes.SHA256())
        pub.verify(sig, msg, pss, hashes.SHA256())

    def test_rsa_pkcs1v15_sign_verify_roundtrip(self):
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        pub = key.public_key()
        msg = b"msg"
        sig = key.sign(msg, padding.PKCS1v15(), hashes.SHA256())
        pub.verify(sig, msg, padding.PKCS1v15(), hashes.SHA256())

    def test_rsa_prehashed_sign_verify(self):
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        pub = key.public_key()
        msg = b"data"
        digest = hashes.Hash(hashes.SHA256())
        digest.update(msg)
        d = digest.finalize()
        pss = padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH,
        )
        sig = key.sign(d, pss, asym_utils.Prehashed(hashes.SHA256()))
        pub.verify(sig, d, pss, asym_utils.Prehashed(hashes.SHA256()))


# ============== ECC 非对称 ==============


class TestEccCore:
    """ECC 密钥生成、ECDH、签名验签核心逻辑"""

    def test_ec_secp256r1_key_generation(self):
        key = ec.generate_private_key(ec.SECP256R1(), default_backend())
        pub = key.public_key()
        assert pub.curve.name

    def test_ec_ecdsa_sign_verify_roundtrip(self):
        key = ec.generate_private_key(ec.SECP256R1(), default_backend())
        pub = key.public_key()
        msg = b"message"
        sig = key.sign(msg, ec.ECDSA(hashes.SHA256()))
        pub.verify(sig, msg, ec.ECDSA(hashes.SHA256()))

    def test_ed25519_sign_verify_roundtrip(self):
        key = ed25519.Ed25519PrivateKey.generate()
        pub = key.public_key()
        msg = b"ed25519 msg"
        sig = key.sign(msg)
        pub.verify(sig, msg)

    def test_x25519_key_exchange(self):
        alice = x25519.X25519PrivateKey.generate()
        bob = x25519.X25519PrivateKey.generate()
        alice_pub = alice.public_key()
        bob_pub = bob.public_key()
        shared_a = alice.exchange(bob_pub)
        shared_b = bob.exchange(alice_pub)
        assert shared_a == shared_b

    def test_ec_ecdh_secp256r1(self):
        alice = ec.generate_private_key(ec.SECP256R1(), default_backend())
        bob = ec.generate_private_key(ec.SECP256R1(), default_backend())
        shared_a = alice.exchange(ec.ECDH(), bob.public_key())
        shared_b = bob.exchange(ec.ECDH(), alice.public_key())
        assert shared_a == shared_b


# ============== SM2 非对称 ==============


@pytest.mark.skipif(
    not getattr(
        __import__("easy_encryption_tool.sm2_command", fromlist=[]),
        "EASY_GMSSL_AVAILABLE",
        False,
    ),
    reason="easy_gmssl not installed",
)
class TestSm2Core:
    """SM2 密钥生成、加解密、签名验签核心逻辑"""

    def test_sm2_key_generation(self):
        from easy_gmssl import EasySm2EncryptionKey

        key = EasySm2EncryptionKey()
        key.NewKey()
        assert key is not None

    def test_sm2_encrypt_decrypt_roundtrip(self, tmp_path):
        from easy_gmssl import EasySm2EncryptionKey, SM2CipherMode, SM2CipherFormat

        key = EasySm2EncryptionKey()
        key.NewKey()
        prefix = str(tmp_path / "sm2_test")
        key.ExportToPemFile(file_name_prefix=prefix, pri_key_password="12345678")
        pub_path = prefix + "_sm2_public.pem"
        pri_path = prefix + "_sm2_private.pem"

        enc_key = EasySm2EncryptionKey()
        enc_key.LoadSm2PubKey(pub_path)
        plain = b"hello sm2"
        cipher = enc_key.Encrypt(
            plain_data=plain,
            cipher_mode=SM2CipherMode.C1C3C2_ASN1,
            cipher_format=SM2CipherFormat.Base64Str,
        )

        dec_key = EasySm2EncryptionKey()
        dec_key.LoadSm2PrivateKey(pri_key_file=pri_path, password="12345678")
        if isinstance(cipher, str):
            cipher_bytes = base64.b64decode(cipher)
        else:
            cipher_bytes = cipher
        dec_plain = dec_key.Decrypt(
            cipher_data=cipher_bytes,
            cipher_mode=SM2CipherMode.C1C3C2_ASN1,
        )
        assert dec_plain == plain

    def test_sm2_sign_verify_roundtrip_raw(self, tmp_path):
        from easy_gmssl import EasySM2SignKey, EasySM2VerifyKey, EasySm2EncryptionKey, SignatureMode

        key = EasySm2EncryptionKey()
        key.NewKey()
        prefix = str(tmp_path / "sm2_sig")
        key.ExportToPemFile(file_name_prefix=prefix, pri_key_password="12345678")
        pub_path = prefix + "_sm2_public.pem"
        pri_path = prefix + "_sm2_private.pem"

        sign_key = EasySM2SignKey(
            signer_id="1234567812345678",
            pem_private_key_file=pri_path,
            password="12345678",
        )
        msg = b"message to sign"
        sign_key.UpdateData(msg)
        sig = sign_key.GetSignValue(signature_mode=SignatureMode.RS_ASN1)

        verify_key = EasySM2VerifyKey(
            signer_id="1234567812345678",
            pem_public_key_file=pub_path,
        )
        verify_key.UpdateData(msg)
        ok = verify_key.VerifySignature(signature_data=sig, signature_mode=SignatureMode.RS_ASN1)
        assert ok is True


# ============== ZUC ==============


@pytest.mark.skipif(
    not getattr(
        __import__("easy_encryption_tool.zuc_command", fromlist=[]),
        "EASY_GMSSL_AVAILABLE",
        False,
    ),
    reason="easy_gmssl not installed",
)
class TestZucCore:
    """ZUC 流密码核心逻辑"""

    def test_zuc_encrypt_decrypt_roundtrip(self):
        from easy_gmssl import EasyZuc

        key = cipherhub_defaults.DEFAULT_ZUC_KEY.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_ZUC_IV.encode("utf-8")
        plain = b"zuc secret data"
        zuc_enc = EasyZuc(key=key, iv=iv)
        cipher = zuc_enc.Update(plain) + zuc_enc.Finish()
        zuc_dec = EasyZuc(key=key, iv=iv)
        dec = zuc_dec.Update(cipher) + zuc_dec.Finish()
        assert dec == plain

    def test_zuc_empty_input(self):
        from easy_gmssl import EasyZuc

        key = cipherhub_defaults.DEFAULT_ZUC_KEY.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_ZUC_IV.encode("utf-8")
        zuc = EasyZuc(key=key, iv=iv)
        out = zuc.Update(b"") + zuc.Finish()
        assert out == b""

    def test_zuc_stream_cipher_same_length(self):
        from easy_gmssl import EasyZuc

        key = cipherhub_defaults.DEFAULT_ZUC_KEY.encode("utf-8")
        iv = cipherhub_defaults.DEFAULT_ZUC_IV.encode("utf-8")
        plain = b"x" * 100
        zuc = EasyZuc(key=key, iv=iv)
        cipher = zuc.Update(plain) + zuc.Finish()
        assert len(cipher) == len(plain)


# ============== common.process_key_iv ==============


class TestProcessKeyIv:
    """process_key_iv 密钥/IV 处理逻辑"""

    def test_random_mode_cbc(self):
        key, iv, _, _, _, _ = process_key_iv(
            is_random=True, key="", iv="",
            key_len=32, iv_len=16, nonce_len=12, mode="cbc"
        )
        assert len(key) == 32
        assert len(iv) == 16

    def test_random_mode_gcm(self):
        key, iv, _, _, _, _ = process_key_iv(
            is_random=True, key="", iv="",
            key_len=32, iv_len=16, nonce_len=12, mode="gcm"
        )
        assert len(key) == 32
        assert len(iv) == 12

    def test_pad_truncate_key(self):
        key, iv, _, _, _, _ = process_key_iv(
            is_random=False, key="k" * 40, iv="v" * 20,
            key_len=32, iv_len=16, nonce_len=None, mode=None
        )
        assert len(key) == 32
        assert len(iv) == 16

    def test_short_key_padded(self):
        key, iv, _, _, _, _ = process_key_iv(
            is_random=False, key="ab", iv="cd",
            key_len=8, iv_len=4, nonce_len=None, mode=None
        )
        assert len(key) == 8
        assert len(iv) == 4
