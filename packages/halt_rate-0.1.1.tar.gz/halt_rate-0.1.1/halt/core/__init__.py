"""Core components for Halt rate limiting."""
