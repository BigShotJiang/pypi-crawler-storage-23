"""Framework adapters for Halt rate limiting."""
