"""Storage backends for Halt rate limiting."""
