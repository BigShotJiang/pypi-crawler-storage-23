import pytest

pytest.skip("Idempotent response mode not yet implemented", allow_module_level=True)

def test_placeholder():
    pass
