"""Structured execution logging with secret redaction for the LLM pipeline.

This module provides structured logging for the three-stage pipeline:
CommandSpec -> ProviderSpec -> ExecSpec, with automatic secret redaction
for environment variables and command arguments.

Logs are emitted at DEBUG level with correlation via spec_id.
Set OBRA_DEBUG_EXEC_SPECS=1 to disable redaction for debugging.
"""

import json
import logging
import os
import re
from typing import Any

from obra.execution.pipeline_types import CommandSpec, ProviderSpec, ExecSpec
from obra.execution.os_compat import EnvironmentProfile

logger = logging.getLogger('obra.execution.spec_logger')

# Environment variables that are safe to log without redaction
SAFE_ENV_ALLOWLIST = {'PATH', 'HOME', 'PWD', 'LANG', 'TERM', 'SHELL'}

# Patterns for environment variable names that should always be redacted
SECRET_PATTERNS = [
    re.compile(r'.*_KEY$'),
    re.compile(r'.*_TOKEN$'),
    re.compile(r'.*_SECRET$'),
    re.compile(r'.*_CREDENTIALS$'),
]


def _should_redact_env_var(key: str) -> bool:
    """Check if an environment variable should be redacted.

    Args:
        key: Environment variable name

    Returns:
        True if the variable should be redacted, False if it's safe to log
    """
    # Always redact if it matches a secret pattern, even if in allowlist
    for pattern in SECRET_PATTERNS:
        if pattern.match(key):
            return True

    # Otherwise, redact unless in allowlist
    return key not in SAFE_ENV_ALLOWLIST


def _redact_env(env: dict[str, str], debug_mode: bool) -> dict[str, str]:
    """Redact sensitive environment variables.

    Args:
        env: Environment variable dictionary
        debug_mode: If True, skip redaction

    Returns:
        Dictionary with sensitive values replaced by '[REDACTED]'
    """
    if debug_mode:
        return env

    return {
        key: '[REDACTED]' if _should_redact_env_var(key) else value
        for key, value in env.items()
    }


def _format_argv(argv: list[str]) -> list[dict[int, str]]:
    """Format argv as positional dictionaries for structured logging.

    Args:
        argv: Command arguments list

    Returns:
        List of single-key dicts mapping position to argument

    Example:
        ['codex', 'exec', '-C', '/home'] ->
        [{0: 'codex'}, {1: 'exec'}, {2: '-C'}, {3: '/home'}]
    """
    return [{i: arg} for i, arg in enumerate(argv)]


def _redact_prompt_content(value: str, debug_mode: bool) -> str:
    """Replace prompt file content with size reference.

    Args:
        value: String that may contain prompt content
        debug_mode: If True, skip redaction

    Returns:
        Original value or '<file:N bytes>' replacement
    """
    if debug_mode:
        return value

    # This is a simple heuristic - in practice, prompt content is in temp files
    # and we're logging file paths, not content. This is defensive.
    if len(value) > 1000:
        return f'<file:{len(value)} bytes>'
    return value


def _build_spec_data(
    spec: CommandSpec | ProviderSpec | ExecSpec,
    profile: EnvironmentProfile,
    debug_mode: bool
) -> dict[str, Any]:
    """Build spec-specific data for logging.

    Args:
        spec: One of the three pipeline spec types
        profile: Resolved environment profile
        debug_mode: If True, skip redaction

    Returns:
        Dictionary with spec fields and profile metadata
    """
    data: dict[str, Any] = {
        'profile': {
            'path_format': profile.path_format,
            'encoding': profile.encoding,
        }
    }

    if isinstance(spec, CommandSpec):
        data.update({
            'provider': spec.provider,
            'model': spec.model,
            'mode': spec.mode,
            'response_format': spec.response_format,
            'reasoning_level': spec.reasoning_level,
            'provider_reasoning_level': spec.provider_reasoning_level,
            'cwd': str(spec.cwd),
            'streaming': spec.streaming,
            'timeout_s': spec.timeout_s,
            'auth_method': spec.auth_method,
            'codex_config': spec.codex_config if debug_mode else (
                '[REDACTED]' if spec.codex_config else None
            ),
        })
    elif isinstance(spec, ProviderSpec):
        data.update({
            'argv': _format_argv(spec.argv),
            'cli_executable': spec.cli_executable,
            'env_overrides': _redact_env(spec.env_overrides, debug_mode),
            'prompt_delivery': spec.prompt_delivery,
            'stdin_content': (
                _redact_prompt_content(spec.stdin_content, debug_mode)
                if spec.stdin_content else None
            ),
            'use_absolute_paths': spec.use_absolute_paths,
            'provider_meta': spec.provider_meta,
        })
    elif isinstance(spec, ExecSpec):
        data.update({
            'cmd': _format_argv(spec.cmd),
            'env': _redact_env(spec.env, debug_mode),
            'cwd': spec.cwd,
            'encoding': spec.encoding,
            'preexec_fn': 'set' if spec.preexec_fn else 'none',
            'shell': spec.shell,
            'timeout_s': spec.timeout_s,
            'streaming': spec.streaming,
            'temp_files': spec.temp_files,
        })

    return data


def log_spec_event(
    stage: str,
    spec: CommandSpec | ProviderSpec | ExecSpec,
    spec_id: str,
    profile: EnvironmentProfile
) -> None:
    """Log a structured pipeline stage event with secret redaction.

    Emits a DEBUG-level log entry containing:
    - Correlation spec_id
    - Stage name (command_spec_created, provider_spec_resolved, exec_spec_built)
    - Environment profile metadata (path_format, encoding)
    - Spec-specific fields with sensitive data redacted

    Redaction can be disabled by setting OBRA_DEBUG_EXEC_SPECS=1 in the environment.

    Args:
        stage: Pipeline stage name
        spec: The spec object for this stage
        spec_id: Correlation ID from CommandSpec
        profile: Resolved environment profile

    Valid stages:
        - 'command_spec_created': After building CommandSpec
        - 'provider_spec_resolved': After building ProviderSpec
        - 'exec_spec_built': After building ExecSpec
    """
    debug_mode = os.environ.get('OBRA_DEBUG_EXEC_SPECS') == '1'

    spec_data = _build_spec_data(spec, profile, debug_mode)

    log_entry = {
        'spec_id': spec_id,
        'stage': stage,
        **spec_data
    }

    # Emit as JSON for structured logging
    logger.debug('Pipeline spec event: %s', json.dumps(log_entry, indent=2))
