"""Terminal detection utilities.

Consolidates headless-detection logic that was previously scattered
across cli.py and orchestrator.py into a single source of truth.
"""

import os
import sys


def is_headless() -> bool:
    """Detect whether the current process is running in headless mode.

    Returns True if ANY of these conditions hold:
    1. OBRA_HEADLESS=1 environment variable is set
    2. CI environment variable is truthy (true or 1)
    3. OBRA_UNATTENDED=1 environment variable is set
    4. stdin is not a TTY (e.g., piped input, subprocess)

    Returns:
        True if running headless, False if interactive.
    """
    if os.environ.get("OBRA_HEADLESS", "0") == "1":
        return True
    if os.environ.get("CI", "").lower() in ("true", "1"):
        return True
    if os.environ.get("OBRA_UNATTENDED", "0") == "1":
        return True
    if not sys.stdin.isatty():
        return True
    return False
