"""Code quality review agent for maintainability analysis.

This module provides CodeQualityAgent, which analyzes code for quality
metrics including complexity, consistency, and maintainability using
LLM-powered semantic analysis.

Checks Performed:
    - Cyclomatic complexity
    - Function/method length
    - Nesting depth
    - Code duplication patterns
    - Naming conventions
    - Type hint coverage

Scoring Dimensions:
    - maintainability: Overall maintainability score
    - complexity: Code complexity metrics
    - consistency: Code style consistency

Related:
    - obra/agents/base.py
    - obra/agents/registry.py
    - obra/agents/prompts/code_quality.txt
"""

import logging
import time
from pathlib import Path

from obra.agents.base import AgentIssue, AgentResult, BaseAgent
from obra.agents.registry import register_agent
from obra.agents.tier_config import resolve_agent_tier_config
from obra.api.protocol import AgentType, Priority
from obra.exceptions import ExecutionError
from obra.llm.content_chunker import ContentChunker
from obra.prompts.agents import load_prompt
from obra.review.quality_tiers import IssueCountTier

logger = logging.getLogger(__name__)


@register_agent(AgentType.CODE_QUALITY)
class CodeQualityAgent(BaseAgent):
    """Code quality review agent with LLM-powered maintainability analysis.

    Uses LLM-based analysis for comprehensive code quality review.
    Works with any programming language (Python, JavaScript, Go, etc.).

    When no LLM config is provided, returns empty result with warning.

    Example:
        >>> agent = CodeQualityAgent(Path("/workspace"), llm_config=llm_config)
        >>> result = agent.analyze(
        ...     item_id="T1",
        ...     changed_files=["src/auth.py"],
        ...     timeout_ms=60000
        ... )
        >>> print(f"Maintainability: {result.scores['maintainability']}")
    """

    agent_type = AgentType.CODE_QUALITY

    def analyze(
        self,
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
    ) -> AgentResult:
        """Analyze code for quality metrics.

        Uses LLM-based analysis when invoker is available. Analyzes
        any programming language, not just Python.

        Parameter Contracts (ADR-042):
            item_id: MUST be non-empty string. Typically matches [A-Z]+-[0-9]+ format.
            changed_files: If None, analyzes all files in working_dir.
                          If provided, only analyzes specified files.
                          Uses blocklist approach to analyze all code files.
            timeout_ms: If None, uses config-based timeout via get_review_agent_timeout().
                       If provided, MUST be positive integer. Typical range: [5000-300000].

        Args:
            item_id: Plan item ID being reviewed
            changed_files: List of files that changed
            timeout_ms: Maximum execution time (None = use config default)

        Returns:
            AgentResult with quality issues and scores
        """
        # Resolve timeout from config if not provided
        timeout_ms = self._resolve_timeout_ms(timeout_ms)

        # Validate parameters (ADR-042)
        self._validate_analyze_params(item_id, timeout_ms)

        start_time = time.time()
        logger.info(f"CodeQualityAgent analyzing {item_id}")

        # Get files to analyze - use blocklist approach for language-agnostic analysis
        files = self.get_files_to_analyze(changed_files=changed_files)
        logger.debug(f"Analyzing {len(files)} files for code quality")

        # Use LLM-based analysis if config is available
        if self._llm_config:
            return self._analyze_with_llm(
                item_id=item_id,
                files=files,
                start_time=start_time,
                timeout_ms=timeout_ms,
            )

        # Fallback: No config available, return empty result with warning
        logger.warning("CodeQualityAgent: No LLM config available, skipping analysis")
        execution_time = int((time.time() - start_time) * 1000)
        return AgentResult(
            agent_type=self.agent_type,
            status="complete",
            issues=[],
            scores={
                "maintainability": 1.0,
                "complexity": 1.0,
                "consistency": 1.0,
            },
            execution_time_ms=execution_time,
            metadata={
                "files_analyzed": 0,
                "mode": "no_invoker",
            },
        )

    def _analyze_with_llm(
        self,
        # TODO: Will be used for item-specific analysis configuration and result
        # correlation in multi-item analysis batches
        item_id: str,
        files: list[Path],
        start_time: float,
        timeout_ms: int,
    ) -> AgentResult:
        """Perform LLM-based code quality analysis.

        Args:
            item_id: Plan item ID
            files: List of files to analyze
            start_time: Analysis start time
            timeout_ms: Maximum execution time

        Returns:
            AgentResult with issues from LLM analysis
        """
        deadline = start_time + (timeout_ms / 1000)

        # Load tier configuration and prompt template
        try:
            quality_template = load_prompt("code_quality")
        except FileNotFoundError as e:
            logger.exception("Failed to load prompt template")
            return self._error_result(f"Missing prompt template: {e}", start_time)

        llm_config = resolve_agent_tier_config("code_review")

        # Collect file contents for analysis
        files_content, collection_stats = self._collect_files_for_analysis(files, deadline)

        if not files_content:
            return self._empty_files_result(files, collection_stats, start_time)

        # Run LLM analysis
        return self._run_llm_analysis(
            files_content=files_content,
            template=quality_template,
            llm_config=llm_config,
            timeout_ms=timeout_ms,
            start_time=start_time,
        )

    def _collect_files_for_analysis(
        self,
        files: list[Path],
        deadline: float,
    ) -> tuple[dict[str, str], dict[str, int | bool]]:
        """Collect file contents for analysis, filtering test/excluded files.

        Args:
            files: List of files to process
            deadline: Timeout deadline

        Returns:
            Tuple of (files_content dict, collection_stats dict)
        """
        files_content: dict[str, str] = {}
        stats = {
            "excluded_count": 0,
            "test_file_count": 0,
            "read_fail_count": 0,
            "timeout_during_collection": False,
        }

        for file_path in files:
            if time.time() > deadline:
                logger.warning("CodeQualityAgent timed out during file collection")
                stats["timeout_during_collection"] = True
                break

            if self.is_test_file(file_path):
                stats["test_file_count"] += 1
                continue
            if self.is_excluded_file(file_path):
                stats["excluded_count"] += 1
                continue

            content = self.read_file(file_path)
            if content:
                try:
                    rel_path = str(file_path.relative_to(self._working_dir))
                except ValueError:
                    rel_path = str(file_path)
                files_content[rel_path] = content
            else:
                stats["read_fail_count"] += 1

        return files_content, stats

    def _empty_files_result(
        self,
        files: list[Path],
        stats: dict[str, int | bool],
        start_time: float,
    ) -> AgentResult:
        """Build result when no files remain after filtering.

        Args:
            files: Original file list
            stats: Collection statistics
            start_time: Analysis start time

        Returns:
            AgentResult with skipped status
        """
        logger.warning(
            "CodeQualityAgent: No analyzable files. "
            "working_dir=%s, files_scanned=%d, test_files=%d, excluded=%d, read_failed=%d, timeout=%s",
            self._working_dir,
            len(files),
            stats["test_file_count"],
            stats["excluded_count"],
            stats["read_fail_count"],
            stats["timeout_during_collection"],
        )
        return AgentResult(
            agent_type=self.agent_type,
            status="skipped",
            issues=[],
            scores={"maintainability": 1.0, "complexity": 1.0, "consistency": 1.0},
            execution_time_ms=int((time.time() - start_time) * 1000),
            metadata={
                "files_analyzed": 0,
                "mode": "llm",
                "skip_reason": "no_files_after_filter",
                "working_dir": str(self._working_dir),
                "files_scanned": len(files),
                "files_test": stats["test_file_count"],
                "files_excluded": stats["excluded_count"],
                "files_read_failed": stats["read_fail_count"],
                "timeout_during_collection": stats["timeout_during_collection"],
            },
        )

    def _error_result(self, error: str, start_time: float) -> AgentResult:
        """Build an error result.

        Args:
            error: Error message
            start_time: Analysis start time

        Returns:
            AgentResult with error status
        """
        return AgentResult(
            agent_type=self.agent_type,
            status="error",
            error=error,
            execution_time_ms=int((time.time() - start_time) * 1000),
        )

    def _run_llm_analysis(
        self,
        files_content: dict[str, str],
        template: str,
        llm_config: dict,
        timeout_ms: int,
        start_time: float,
    ) -> AgentResult:
        """Run LLM analysis and build result.

        Args:
            files_content: Dict mapping file paths to contents
            template: Prompt template
            llm_config: LLM configuration
            timeout_ms: Maximum execution time
            start_time: Analysis start time

        Returns:
            AgentResult with analysis findings
        """
        code_content = self._format_code_for_prompt(files_content)
        logger.info(
            f"Running code quality analysis with {llm_config['provider']}/{llm_config['model']}"
        )

        analysis_prompt = template.format(code_content=code_content)
        analysis_prompt = self._inject_intent_context(analysis_prompt)

        try:
            response_text = self._invoke_cli(
                call_site="code_quality_analysis",
                prompt=analysis_prompt,
                timeout_ms=timeout_ms,
            )

            if not response_text:
                logger.warning("LLM invocation returned empty response")
                return self._error_result("LLM invocation returned empty response", start_time)

            issues = self.parse_structured_response(response_text, prefix="QUAL")
            logger.info(f"Found {len(issues)} code quality issues")

        except ExecutionError as e:
            logger.error("Code quality analysis failed: %s", e)  # noqa: TRY400
            return self._error_result(f"Analysis failed: {e}", start_time)
        except Exception as e:
            logger.exception("Code quality analysis failed")
            return self._error_result(f"Analysis failed: {e}", start_time)

        scores = self._calculate_scores_from_issues(issues)
        execution_time = int((time.time() - start_time) * 1000)
        logger.info(f"CodeQualityAgent complete: {len(issues)} issues found in {execution_time}ms")

        return AgentResult(
            agent_type=self.agent_type,
            status="complete",
            issues=issues,
            scores=scores,
            execution_time_ms=execution_time,
            metadata={
                "files_analyzed": len(files_content),
                "mode": "llm",
                "provider": llm_config["provider"],
                "model": llm_config["model"],
                "issues_found": len(issues),
                "scores": scores,
            },
        )

    def _format_code_for_prompt(self, files_content: dict[str, str]) -> str:
        """Format file contents for LLM prompt.

        Args:
            files_content: Dict mapping file paths to contents

        Returns:
            Formatted string with file headers
        """
        # Get model from agent config for content chunking
        model = "sonnet"  # Default model
        provider = "anthropic"  # Default provider
        if self._llm_config:
            model = self._llm_config.get("model", model)
            provider = self._llm_config.get("provider", provider)
        chunker = ContentChunker(model=model, provider=provider)

        parts = []
        for file_path, content in files_content.items():
            # Limit content size to avoid token limits (model-aware)
            truncated = chunker.truncate(content)
            numbered = "\n".join(
                f"{line_no:>4}: {line}"
                for line_no, line in enumerate(truncated.splitlines(), start=1)
            )
            parts.append(f"=== FILE: {file_path} ===\n{numbered}")
        return "\n\n".join(parts)

    def _calculate_scores_from_issues(self, issues: list[AgentIssue]) -> dict[str, float]:
        """Calculate dimension scores based on issues.

        Args:
            issues: All issues found

        Returns:
            Dict of dimension scores
        """
        maintainability_issues = 0
        complexity_issues = 0
        consistency_issues = 0

        for issue in issues:
            dim = issue.dimension
            if dim == "maintainability":
                maintainability_issues += 1
            elif dim == "complexity":
                complexity_issues += 1
            elif dim == "consistency":
                consistency_issues += 1
            # Map priority to dimension for LLM issues without explicit dimension
            elif issue.priority in (Priority.P0, Priority.P1):
                maintainability_issues += 1
            elif issue.priority == Priority.P2:
                complexity_issues += 1
            else:
                consistency_issues += 1

        def score(issue_count: int) -> float:
            return IssueCountTier.from_count(issue_count).base_score

        return {
            "maintainability": score(maintainability_issues),
            "complexity": score(complexity_issues),
            "consistency": score(consistency_issues),
        }


__all__ = ["CodeQualityAgent"]
