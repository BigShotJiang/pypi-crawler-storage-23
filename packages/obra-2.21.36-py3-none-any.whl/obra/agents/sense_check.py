"""SenseCheck semantic review agent.

This module provides SenseCheckAgent, which performs semantic validation
of code changes during the review phase. It checks for:

1. Problem framing - Root cause accuracy and completeness
2. Solution quality - No band-aids, brittle patterns, or hardcoded values
3. Pattern quality - Industry best practices, no over-engineering

Read-Only Constraint: This agent only reads project files and writes to its
AgentReport output. No project file modifications are allowed during parallel
execution (see PRD FR-7).

Scoring Dimensions:
    - problem_framing: Root causes are correct, complete, and well-scoped
    - solution_quality: Solutions are correct, sufficient, and lean
    - pattern_quality: Follows industry best practices

Related:
    - obra/agents/base.py
    - obra/agents/registry.py
    - obra/prompts/agents/sense_check.txt
    - docs/design/prds/SENSECHECK_AGENT_PRD.md
"""

import logging
import time
from pathlib import Path

from obra.agents.base import AgentIssue, AgentResult, BaseAgent
from obra.agents.registry import register_agent
from obra.agents.tier_config import resolve_agent_tier_config
from obra.api.protocol import AgentType, Priority
from obra.llm.content_chunker import ContentChunker
from obra.prompts.agents import load_prompt
from obra.review.quality_tiers import IssueCountTier

logger = logging.getLogger(__name__)


@register_agent(AgentType.SENSE_CHECK)
class SenseCheckAgent(BaseAgent):
    """SenseCheck semantic review agent with LLM-powered validation.

    Performs semantic review to detect:
    - Incorrect or incomplete root cause analysis
    - Band-aid fixes that don't address underlying issues
    - Brittle patterns and hardcoded values
    - Over-engineering and unnecessary complexity

    Read-Only Constraint: This agent only reads project files and writes to its
    AgentReport output. No project file modifications are allowed during parallel
    execution (see PRD FR-7).

    When no LLM config is provided, returns empty results (no findings).

    Example:
        >>> agent = SenseCheckAgent(Path("/workspace"), llm_config=llm_config)
        >>> result = agent.analyze(
        ...     item_id="T1",
        ...     changed_files=["src/fix.py"],
        ...     timeout_ms=60000
        ... )
        >>> print(f"Found {len(result.issues)} semantic issues")
    """

    agent_type = AgentType.SENSE_CHECK

    def analyze(
        self,
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
    ) -> AgentResult:
        """Analyze code for semantic correctness and completeness.

        Uses LLM-based analysis to validate problem framing, solution quality,
        and adherence to best practices.

        Parameter Contracts (ADR-042):
            - item_id: non-empty string
            - timeout_ms: positive integer if provided, None uses config default

        Args:
            item_id: Plan item ID being reviewed
            changed_files: List of files that changed
            timeout_ms: Maximum execution time (None = use config default)

        Returns:
            AgentResult with semantic issues and scores
        """
        # Resolve timeout from config if not provided
        timeout_ms = self._resolve_timeout_ms(timeout_ms)

        # Validate parameters (ADR-042)
        self._validate_analyze_params(item_id, timeout_ms)

        start_time = time.time()
        logger.info(f"SenseCheckAgent analyzing {item_id}")

        # Get files to analyze
        files = self.get_files_to_analyze(changed_files=changed_files)
        logger.debug(f"Analyzing {len(files)} files for semantic issues")

        # Use LLM-based analysis if config is available
        if self._llm_config:
            return self._analyze_with_llm(
                item_id=item_id,
                files=files,
                start_time=start_time,
                timeout_ms=timeout_ms,
            )

        # Fallback: No config available, return empty result with warning
        logger.warning("SenseCheckAgent: No LLM config available, skipping analysis")
        execution_time = int((time.time() - start_time) * 1000)
        return AgentResult(
            agent_type=self.agent_type,
            status="complete",
            issues=[],
            scores={
                "problem_framing": 1.0,
                "solution_quality": 1.0,
                "pattern_quality": 1.0,
            },
            execution_time_ms=execution_time,
            metadata={
                "files_analyzed": 0,
                "mode": "no_invoker",
            },
        )

    def _analyze_with_llm(
        self,
        item_id: str,
        files: list[Path],
        start_time: float,
        timeout_ms: int,
    ) -> AgentResult:
        """Perform LLM-based semantic analysis.

        Uses high-tier model by default since review agents must be at least
        as capable as implementation agents to catch their mistakes.

        Args:
            item_id: Plan item ID
            files: List of files to analyze
            start_time: Analysis start time
            timeout_ms: Maximum execution time

        Returns:
            AgentResult with semantic issues
        """
        deadline = start_time + (timeout_ms / 1000)

        # Load prompt template
        try:
            prompt_template = load_prompt("sense_check")
        except FileNotFoundError as e:
            logger.exception("Failed to load prompt template")
            return self._error_result(f"Missing prompt template: {e}", start_time)

        tier_config = resolve_agent_tier_config("sense_check")

        # Collect file contents for analysis
        files_content, collection_stats = self._collect_files_for_analysis(files, deadline)

        if not files_content:
            return self._empty_files_result(files, collection_stats, start_time)

        # Build and execute analysis
        return self._run_analysis(
            files_content=files_content,
            prompt_template=prompt_template,
            tier_config=tier_config,
            timeout_ms=timeout_ms,
            start_time=start_time,
        )

    def _collect_files_for_analysis(
        self,
        files: list[Path],
        deadline: float,
    ) -> tuple[dict[str, str], dict[str, int | bool]]:
        """Collect file contents for analysis, filtering excluded files.

        Args:
            files: List of files to process
            deadline: Timeout deadline

        Returns:
            Tuple of (files_content dict, collection_stats dict)
        """
        files_content: dict[str, str] = {}
        stats: dict[str, int | bool] = {
            "excluded_count": 0,
            "read_fail_count": 0,
            "timeout_during_collection": False,
        }

        for file_path in files:
            if time.time() > deadline:
                logger.warning("SenseCheckAgent timed out during file collection")
                stats["timeout_during_collection"] = True
                break

            if self.is_excluded_file(file_path):
                stats["excluded_count"] = int(stats["excluded_count"]) + 1
                continue

            content = self.read_file(file_path)
            if content:
                try:
                    rel_path = str(file_path.relative_to(self._working_dir))
                except ValueError:
                    rel_path = str(file_path)
                files_content[rel_path] = content
            else:
                stats["read_fail_count"] = int(stats["read_fail_count"]) + 1

        return files_content, stats

    def _empty_files_result(
        self,
        files: list[Path],
        stats: dict[str, int | bool],
        start_time: float,
    ) -> AgentResult:
        """Build result when no files remain after filtering.

        Args:
            files: Original file list
            stats: Collection statistics
            start_time: Analysis start time

        Returns:
            AgentResult with skipped status
        """
        logger.warning(
            "SenseCheckAgent: No analyzable files. "
            "working_dir=%s, files_scanned=%d, excluded=%d, read_failed=%d, timeout=%s",
            self._working_dir,
            len(files),
            stats["excluded_count"],
            stats["read_fail_count"],
            stats["timeout_during_collection"],
        )
        return AgentResult(
            agent_type=self.agent_type,
            status="skipped",
            issues=[],
            scores={
                "problem_framing": 1.0,
                "solution_quality": 1.0,
                "pattern_quality": 1.0,
            },
            execution_time_ms=int((time.time() - start_time) * 1000),
            metadata={
                "files_analyzed": 0,
                "mode": "llm",
                "skip_reason": "no_files_after_filter",
                "working_dir": str(self._working_dir),
                "files_scanned": len(files),
                "files_excluded": stats["excluded_count"],
                "files_read_failed": stats["read_fail_count"],
                "timeout_during_collection": stats["timeout_during_collection"],
            },
        )

    def _error_result(self, error: str, start_time: float) -> AgentResult:
        """Build an error result.

        Args:
            error: Error message
            start_time: Analysis start time

        Returns:
            AgentResult with error status
        """
        return AgentResult(
            agent_type=self.agent_type,
            status="error",
            error=error,
            execution_time_ms=int((time.time() - start_time) * 1000),
        )

    def _run_analysis(
        self,
        files_content: dict[str, str],
        prompt_template: str,
        tier_config: dict,
        timeout_ms: int,
        start_time: float,
    ) -> AgentResult:
        """Run semantic analysis on collected files.

        Args:
            files_content: Dict mapping file paths to contents
            prompt_template: Prompt template
            tier_config: LLM tier configuration
            timeout_ms: Maximum execution time
            start_time: Analysis start time

        Returns:
            AgentResult with analysis findings
        """
        code_content = self._format_code_for_prompt(files_content)
        logger.info(
            f"Running SenseCheck analysis with {tier_config['provider']}/{tier_config['model']}"
        )

        # Build prompt with content
        prompt = prompt_template.format(content=code_content)
        prompt = self._inject_intent_context(prompt)

        try:
            response = self._invoke_cli(
                call_site="sense_check",
                prompt=prompt,
                timeout_ms=timeout_ms,
            )

            if not response:
                logger.warning("SenseCheck LLM invocation returned empty response")
                return self._error_result("LLM invocation returned empty response", start_time)

            # Parse response - check for SOUND indicator first
            issues = self._parse_sense_check_response(response)
            logger.info(f"SenseCheck found {len(issues)} issues")

            # Calculate scores based on issues
            scores = self._calculate_scores_from_issues(issues)

            execution_time = int((time.time() - start_time) * 1000)
            logger.info(
                f"SenseCheckAgent complete: {len(issues)} issues found in {execution_time}ms"
            )

            return AgentResult(
                agent_type=self.agent_type,
                status="complete",
                issues=issues,
                scores=scores,
                execution_time_ms=execution_time,
                metadata={
                    "files_analyzed": len(files_content),
                    "mode": "llm",
                    "provider": tier_config["provider"],
                    "model": tier_config["model"],
                    "issues_found": len(issues),
                },
            )

        except Exception as e:
            logger.exception(f"SenseCheck analysis failed: {e}")
            return self._error_result(f"Analysis failed: {e}", start_time)

    def _format_code_for_prompt(self, files_content: dict[str, str]) -> str:
        """Format file contents for LLM prompt.

        Args:
            files_content: Dict mapping file paths to contents

        Returns:
            Formatted string with file headers
        """
        # Get model from agent config for content chunking
        model = "sonnet"  # Default model
        provider = "anthropic"  # Default provider
        if self._llm_config:
            model = self._llm_config.get("model", model)
            provider = self._llm_config.get("provider", provider)
        chunker = ContentChunker(model=model, provider=provider)

        parts = []
        for file_path, content in files_content.items():
            # Limit content size to avoid token limits (model-aware)
            truncated = chunker.truncate(content)
            numbered = "\n".join(
                f"{line_no:>4}: {line}"
                for line_no, line in enumerate(truncated.splitlines(), start=1)
            )
            parts.append(f"=== FILE: {file_path} ===\n{numbered}")
        return "\n\n".join(parts)

    def _parse_sense_check_response(self, response: str) -> list[AgentIssue]:
        """Parse SenseCheck LLM response into issues.

        Handles both SOUND (no issues) and structured issue list formats.

        Args:
            response: Raw LLM response text

        Returns:
            List of AgentIssue objects
        """
        if not response or not response.strip():
            return []

        # Check for SOUND indicator (no issues found)
        response_upper = response.strip().upper()
        if response_upper.startswith("SOUND") or "SOUND" in response_upper[:50]:
            logger.debug("SenseCheck response indicates SOUND - no issues")
            return []

        # Parse structured response using base class parser
        issues = self.parse_structured_response(response, prefix="SENSE")

        # Map severity to dimensions for issues without explicit dimension
        for issue in issues:
            if not issue.dimension:
                # Infer dimension from content or priority
                if "root cause" in issue.description.lower() or "problem" in issue.title.lower():
                    issue.dimension = "problem_framing"
                elif (
                    "band-aid" in issue.description.lower()
                    or "brittle" in issue.description.lower()
                ):
                    issue.dimension = "solution_quality"
                else:
                    issue.dimension = "pattern_quality"

            # Map severity strings to Priority if needed
            if issue.metadata.get("severity_raw"):
                severity = issue.metadata["severity_raw"].lower()
                if severity in ("critical",):
                    issue.priority = Priority.P0
                elif severity in ("major",):
                    issue.priority = Priority.P1
                elif severity in ("minor",):
                    issue.priority = Priority.P2

        return issues

    def _calculate_scores_from_issues(self, issues: list[AgentIssue]) -> dict[str, float]:
        """Calculate dimension scores based on issues.

        Args:
            issues: All issues found

        Returns:
            Dict of dimension scores
        """
        problem_framing_issues = 0
        solution_quality_issues = 0
        pattern_quality_issues = 0

        for issue in issues:
            dim = issue.dimension
            if dim == "problem_framing":
                problem_framing_issues += 1
            elif dim == "solution_quality":
                solution_quality_issues += 1
            elif dim == "pattern_quality":
                pattern_quality_issues += 1
            # Map priority to dimension for issues without explicit dimension
            elif issue.priority == Priority.P0:
                problem_framing_issues += 1
            elif issue.priority == Priority.P1:
                solution_quality_issues += 1
            else:
                pattern_quality_issues += 1

        def score(issue_count: int) -> float:
            # Use standard IssueCountTier for consistent scoring across agents
            return IssueCountTier.from_count(issue_count).base_score

        return {
            "problem_framing": score(problem_framing_issues),
            "solution_quality": score(solution_quality_issues),
            "pattern_quality": score(pattern_quality_issues),
        }


__all__ = ["SenseCheckAgent"]
