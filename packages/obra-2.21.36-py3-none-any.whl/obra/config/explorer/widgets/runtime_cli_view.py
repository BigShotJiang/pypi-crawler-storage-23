"""Runtime & CLI View widget.

Provides Codex runtime feature controls for headless execution.
"""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.message import Message
from textual.widgets import Input, Static, Switch

from obra.config.explorer.widgets.navigation_menu import get_menu_info
from obra.config.explorer.widgets.saveable_view import SaveableViewMixin

ENABLE_PATH = "llm.codex.enable_features"
DISABLE_PATH = "llm.codex.disable_features"
MULTI_AGENT_FEATURE = "multi_agent"

ALL_RUNTIME_CLI_SETTINGS: list[str] = [ENABLE_PATH, DISABLE_PATH]


def _normalize_feature_list(raw: Any) -> list[str]:
    """Normalize feature values to a de-duplicated list of strings."""
    if isinstance(raw, str):
        items = [part.strip() for part in raw.split(",")]
    elif isinstance(raw, list):
        items = [part.strip() for part in raw if isinstance(part, str)]
    else:
        return []

    normalized: list[str] = []
    seen: set[str] = set()
    for item in items:
        if not item or item in seen:
            continue
        seen.add(item)
        normalized.append(item)
    return normalized


class RuntimeCLIView(SaveableViewMixin, Static):
    """Runtime & CLI configuration view.

    Emits:
        Changed: When a runtime setting changes.
    """

    DEFAULT_CSS = """
    RuntimeCLIView {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    RuntimeCLIView > Vertical {
        width: 100%;
        height: 100%;
    }

    RuntimeCLIView #content-scroll {
        width: 100%;
        height: 1fr;
        min-height: 10;
    }

    RuntimeCLIView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    RuntimeCLIView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 2;
        width: 100%;
    }

    RuntimeCLIView .section {
        width: 100%;
        height: auto;
        padding: 1;
        background: $surface;
        border: solid $primary-background;
    }

    RuntimeCLIView .section-title {
        text-style: bold;
        margin-bottom: 1;
        color: $primary;
    }

    RuntimeCLIView .setting-card {
        width: 100%;
        height: auto;
        margin-bottom: 1;
        padding: 1;
        border: solid $panel;
        background: $surface-darken-1;
    }

    RuntimeCLIView .switch-row {
        width: 100%;
        height: auto;
    }

    RuntimeCLIView .switch-label {
        width: 1fr;
        text-style: bold;
    }

    RuntimeCLIView .setting-label {
        text-style: bold;
        margin-bottom: 1;
    }

    RuntimeCLIView .setting-description {
        color: $text-muted;
        margin-bottom: 1;
    }

    RuntimeCLIView .setting-input {
        width: 100%;
    }

    RuntimeCLIView Input {
        width: 100%;
    }

    RuntimeCLIView .preview-box {
        width: 100%;
        height: auto;
        min-height: 4;
        margin-top: 1;
        padding: 1;
        background: $surface-darken-1;
        border: solid $primary-darken-2;
    }

    RuntimeCLIView .preview-title {
        text-style: bold;
        margin-bottom: 1;
    }

    RuntimeCLIView .conflict-warning {
        color: $warning;
        margin-top: 1;
        text-style: bold;
    }

    RuntimeCLIView .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: center;
        width: 100%;
    }
    """

    class Changed(Message):
        """Message emitted when a runtime setting changes."""

        def __init__(self, path: str, value: Any) -> None:
            super().__init__()
            self.path = path
            self.value = value

    def __init__(
        self,
        current_values: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        source_values = current_values.copy() if current_values else {}
        self._current_values: dict[str, list[str]] = {
            ENABLE_PATH: _normalize_feature_list(source_values.get(ENABLE_PATH)),
            DISABLE_PATH: _normalize_feature_list(source_values.get(DISABLE_PATH)),
        }
        self._initializing = True
        self._suppress_events = False
        self._snapshot_state()

    def on_mount(self) -> None:
        """Allow change events after mount completes."""
        def finish_initialization() -> None:
            self._initializing = False
            self._snapshot_state()
            self._update_preview()

        self.call_after_refresh(finish_initialization)

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("runtime_cli")
        with Vertical():
            yield Static(menu_info["label"], classes="header")
            yield Static(menu_info["subtitle"], classes="description")

            with ScrollableContainer(id="content-scroll"):
                with Vertical(classes="section"):
                    yield Static("Codex Features", classes="section-title")

                    with Vertical(classes="setting-card"):
                        with Horizontal(classes="switch-row"):
                            yield Static(
                                "Parallel Workers (experimental)",
                                classes="switch-label",
                            )
                            yield Switch(
                                value=MULTI_AGENT_FEATURE
                                in self._current_values.get(ENABLE_PATH, []),
                                id="switch-parallel-workers",
                            )
                        yield Static(
                            "Enable Codex internal fan-out for faster large tasks. "
                            "Default is OFF.",
                            classes="setting-description",
                        )

                    with Vertical(classes="setting-card"):
                        yield Static("Enable Features", classes="setting-label")
                        yield Static(
                            "Comma-separated feature names to pass as repeated "
                            "--enable flags.",
                            classes="setting-description",
                        )
                        yield Input(
                            value=", ".join(self._current_values.get(ENABLE_PATH, [])),
                            placeholder="multi_agent, feature_name",
                            id="input-enable-features",
                            classes="setting-input",
                        )

                    with Vertical(classes="setting-card"):
                        yield Static("Disable Features", classes="setting-label")
                        yield Static(
                            "Comma-separated feature names to pass as repeated "
                            "--disable flags.",
                            classes="setting-description",
                        )
                        yield Input(
                            value=", ".join(self._current_values.get(DISABLE_PATH, [])),
                            placeholder="legacy_feature",
                            id="input-disable-features",
                            classes="setting-input",
                        )

                    yield Static("", id="runtime-conflict", classes="conflict-warning")

                    with Vertical(classes="preview-box"):
                        yield Static("Effective Command Flags", classes="preview-title")
                        yield Static("", id="runtime-preview")

            yield Static(
                "Changes are applied when you save. Use 's' to save.",
                classes="help-text",
            )

    def _emit_change(self, path: str, value: list[str]) -> None:
        if self._initializing or self._suppress_events:
            return
        self.post_message(self.Changed(path, value))

    def _update_preview(self) -> None:
        """Refresh command preview and conflict warning."""
        enable_features = self._current_values.get(ENABLE_PATH, [])
        disable_features = self._current_values.get(DISABLE_PATH, [])
        conflict = sorted(set(enable_features) & set(disable_features))

        args: list[str] = []
        for feature_name in enable_features:
            args.append(f"--enable {feature_name}")
        for feature_name in disable_features:
            args.append(f"--disable {feature_name}")

        preview_text = "\n".join(args) if args else "(no codex feature flags configured)"
        try:
            self.query_one("#runtime-preview", Static).update(preview_text)
        except Exception:
            pass

        conflict_text = ""
        if conflict:
            conflict_text = (
                "Conflict: same feature appears in both lists: "
                + ", ".join(conflict)
            )
        try:
            self.query_one("#runtime-conflict", Static).update(conflict_text)
        except Exception:
            pass

    def _sync_widgets(self) -> None:
        """Sync widget values from current state without emitting events."""
        self._suppress_events = True
        try:
            enable_features = self._current_values.get(ENABLE_PATH, [])
            disable_features = self._current_values.get(DISABLE_PATH, [])

            try:
                enable_input = self.query_one("#input-enable-features", Input)
                enable_input.value = ", ".join(enable_features)
            except Exception:
                pass

            try:
                disable_input = self.query_one("#input-disable-features", Input)
                disable_input.value = ", ".join(disable_features)
            except Exception:
                pass

            try:
                parallel_switch = self.query_one("#switch-parallel-workers", Switch)
                parallel_switch.value = (
                    MULTI_AGENT_FEATURE in enable_features
                    and MULTI_AGENT_FEATURE not in disable_features
                )
            except Exception:
                pass
        finally:
            self._suppress_events = False
        self._update_preview()

    def on_switch_changed(self, event: Switch.Changed) -> None:
        """Handle parallel workers toggle changes."""
        if self._initializing or self._suppress_events:
            return
        if event.switch.id != "switch-parallel-workers":
            return

        enable_features = list(self._current_values.get(ENABLE_PATH, []))
        disable_features = list(self._current_values.get(DISABLE_PATH, []))

        if event.value:
            if MULTI_AGENT_FEATURE not in enable_features:
                enable_features.append(MULTI_AGENT_FEATURE)
            disable_features = [f for f in disable_features if f != MULTI_AGENT_FEATURE]
        else:
            enable_features = [f for f in enable_features if f != MULTI_AGENT_FEATURE]
            if MULTI_AGENT_FEATURE not in disable_features:
                disable_features.append(MULTI_AGENT_FEATURE)

        self._current_values[ENABLE_PATH] = enable_features
        self._current_values[DISABLE_PATH] = disable_features
        self._sync_widgets()
        self._emit_change(ENABLE_PATH, enable_features)
        self._emit_change(DISABLE_PATH, disable_features)

    def on_input_changed(self, event: Input.Changed) -> None:
        """Handle feature list input changes."""
        if self._initializing or self._suppress_events:
            return

        if event.input.id == "input-enable-features":
            path = ENABLE_PATH
        elif event.input.id == "input-disable-features":
            path = DISABLE_PATH
        else:
            return

        value = _normalize_feature_list(event.value)
        self._current_values[path] = value
        self._sync_widgets()
        self._emit_change(path, value)

    # --- SaveableViewMixin implementation ---

    def _get_saveable_state(self) -> dict[str, Any]:
        """Get current state for dirty tracking."""
        return {
            ENABLE_PATH: list(self._current_values.get(ENABLE_PATH, [])),
            DISABLE_PATH: list(self._current_values.get(DISABLE_PATH, [])),
        }

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from snapshot and refresh widgets."""
        self._current_values = {
            ENABLE_PATH: _normalize_feature_list(state.get(ENABLE_PATH)),
            DISABLE_PATH: _normalize_feature_list(state.get(DISABLE_PATH)),
        }
        self._sync_widgets()
