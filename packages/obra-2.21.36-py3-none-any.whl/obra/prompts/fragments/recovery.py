"""Prompt builders for recovery and retry banners."""

from __future__ import annotations

__all__ = ["build_interactive_recovery_banner", "build_zero_output_recovery_banner"]


def build_interactive_recovery_banner(line: str | None) -> str:
    """Build prompt banner for interactive guard recovery retry.

    Args:
        line: Matched interactive prompt line

    Returns:
        Recovery banner string
    """
    line_text = line.strip() if line else "unknown"
    return (
        "## Recovery Notice\n"
        "The previous run was blocked due to interactive output:\n"
        f"> {line_text}\n"
        "Do not run interactive shell commands. If a command would prompt for input or "
        "confirmation, stop and return an error instead. Continue non-interactively."
    )


def build_zero_output_recovery_banner(working_dir: str) -> str:
    """Build prompt banner for zero-output recovery retry.

    Used when the LLM subprocess exits successfully but creates no files.
    Directs the LLM to use file-writing tools and confirms the working directory.

    Args:
        working_dir: Absolute path to the project working directory

    Returns:
        Recovery banner string
    """
    return (
        "## Recovery Notice\n"
        "The previous attempt completed without creating any files.\n"
        f"Working directory: {working_dir}\n"
        "You MUST use your file-writing tools (Write, Edit) to create the requested files. "
        "Do not describe changes in text — actually create the code files in the working directory."
    )
