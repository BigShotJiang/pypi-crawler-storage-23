"""User story generator from intent documents.

This module provides automated user story generation with verification methods
from enriched intent documents. Generated stories include acceptance criteria,
proof commands for automated verification, and manual steps for non-automatable
scenarios.

Related:
    - docs/design/prds/USER_STORY_QA_GATE_PRD.md (FR-1, FR-3, FR-4, FR-5)
    - obra/intent/models.py (UserStory, VerificationMethod, ProofType)
    - obra/prompts/intent/user_stories.py
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Callable

from pydantic import ValidationError

from obra.config.llm import resolve_tier_config
from obra.config.loaders import (
    get_user_story_generation_enabled,
    get_user_story_generation_timeout_s,
    get_user_story_max_stories,
    get_user_story_model_tier,
)
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline
from obra.intent.models import IntentModel, UserStory
from obra.prompts.intent.user_stories import build_user_story_generation_prompt

logger = logging.getLogger(__name__)


class UserStoryGenerator:
    """Generates user stories with verification methods from intent documents.

    This generator uses LLM-powered template editing to produce concrete,
    testable user stories from abstract intent documents. Stories include
    verification methods (automated/manual/not_verifiable) and domain-specific
    proof commands.

    The generator is non-blocking by design - failures do not raise and the
    pipeline continues. It prefers validated LLM stories, and falls back to
    deterministic manual-checklist stories when LLM output is unusable.

    Attributes:
        working_dir: Working directory for template files
        llm_config: Optional LLM configuration override
        on_stream: Optional streaming callback
        on_progress: Optional progress callback
        log_event: Optional event logging callback
        production_logger: Optional production logger instance
    """

    def __init__(
        self,
        working_dir: Path,
        *,
        llm_config: dict[str, Any] | None = None,
        on_stream: Callable | None = None,
        on_progress: Callable | None = None,
        log_event: Callable | None = None,
        production_logger: Any | None = None,
    ):
        """Initialize user story generator.

        Args:
            working_dir: Working directory for template files
            llm_config: Optional LLM configuration override
            on_stream: Optional streaming callback
            on_progress: Optional progress callback
            log_event: Optional event logging callback
            production_logger: Optional production logger instance
        """
        self.working_dir = working_dir
        self.llm_config = llm_config
        self.on_stream = on_stream
        self.on_progress = on_progress
        self.log_event = log_event
        self.production_logger = production_logger
        self.last_result_reason: str | None = None

    def _emit_event(self, event_name: str, *, reason: str) -> None:
        """Emit structured user-story generator event if callback is available."""
        if not self.log_event:
            return
        try:
            self.log_event(event_name, reason=reason)
        except Exception as exc:
            logger.debug("User story event logging skipped: %s", exc)

    @staticmethod
    def _to_user_stories(stories_data: list[Any], *, max_stories: int) -> list[UserStory]:
        """Convert raw story dicts to validated UserStory models."""
        stories: list[UserStory] = []
        for story_dict in stories_data[:max_stories]:
            try:
                story = UserStory.model_validate(story_dict)
                stories.append(story)
            except ValidationError as e:
                logger.warning("Skipping invalid user story (validation failed): %s", e)
        return stories

    @staticmethod
    def _build_deterministic_fallback_stories(
        intent: IntentModel,
        *,
        max_stories: int,
    ) -> list[dict[str, Any]]:
        """Build minimal but valid stories when LLM generation is unusable."""
        candidate_texts: list[str] = []
        seen: set[str] = set()

        for text in intent.requirements + intent.acceptance_criteria:
            normalized = str(text).strip()
            if normalized and normalized not in seen:
                candidate_texts.append(normalized)
                seen.add(normalized)

        if not candidate_texts:
            fallback_text = str(intent.problem_statement or intent.raw_objective).strip()
            if fallback_text:
                candidate_texts.append(fallback_text)
        if not candidate_texts:
            candidate_texts.append("Core project objective is implemented and usable")

        story_limit = max(1, min(max_stories, len(candidate_texts) or 1, 5))
        stories: list[dict[str, Any]] = []
        for index, text in enumerate(candidate_texts[:story_limit], start=1):
            stories.append(
                {
                    "id": f"US-{index}",
                    "role": "end user",
                    "action": text,
                    "outcome": "expected behavior is delivered and observable",
                    "verification_method": "manual",
                    "proof_type": None,
                    "proof_command": None,
                    "proof_expected": None,
                    "preconditions": [],
                    "manual_steps": [
                        "Start the application in the intended runtime environment.",
                        f"Perform the behavior: {text}",
                        "Confirm the expected result occurs without runtime errors.",
                    ],
                }
            )
        return stories

    def generate(
        self,
        intent: IntentModel,
        project_context: str | None = None,
    ) -> list[UserStory]:
        """Generate user stories from intent document.

        Args:
            intent: Enriched intent document
            project_context: Optional project context (JSON-serialized dict)

        Returns:
            List of UserStory objects (empty list only if disabled or hard failure)

        Note:
            This method is non-blocking - failures do not raise. Check logs for
            warnings when deterministic fallback stories are used.
        """
        self.last_result_reason = None

        # Check if feature is enabled
        if not get_user_story_generation_enabled():
            logger.debug("User story generation disabled via config")
            self.last_result_reason = "disabled"
            self._emit_event("user_story_generation_skipped", reason="disabled")
            return []

        try:
            # Resolve model tier configuration
            model_tier = get_user_story_model_tier()
            resolved = resolve_tier_config(
                model_tier,
                role="orchestrator",
            )

            # Build prompt
            max_stories = max(1, get_user_story_max_stories())
            prompt = build_user_story_generation_prompt(
                objective=intent.raw_objective,
                intent=intent,
                project_context=project_context,
                max_stories=max_stories,
            )

            # Create template edit pipeline
            pipeline = TemplateEditPipeline(
                working_dir=self.working_dir,
                action_name="user_story_generation",
                on_stream=self.on_stream,
                log_event=self.log_event,
                max_retries=3,  # Allow retries for validation failures
            )

            # Template schema for user story array
            template_schema = {
                "stories": [],
                "_instructions": (
                    "Generate an array of UserStory objects.\n"
                    "Each story must have: id, role, action, outcome, "
                    "verification_method, proof_type, proof_command, "
                    "proof_expected, preconditions, manual_steps.\n"
                    "Replace this stories array with your generated stories."
                ),
            }

            # Validator: check stories array structure
            def validator(data: dict) -> tuple[bool, str | None]:
                if not isinstance(data, dict):
                    return (False, "response must be a JSON object")
                stories = data.get("stories")
                if not isinstance(stories, list):
                    return (False, "stories must be an array")
                if not stories:
                    return (False, "stories must contain at least one story")
                required_fields = {"id", "role", "action", "outcome", "verification_method"}
                for index, story in enumerate(stories):
                    if not isinstance(story, dict):
                        return (False, f"stories[{index}] must be an object")
                    missing = required_fields - story.keys()
                    if missing:
                        missing_csv = ", ".join(sorted(missing))
                        return (False, f"stories[{index}] missing fields: {missing_csv}")
                return (True, None)

            fallback_story_dicts = self._build_deterministic_fallback_stories(
                intent,
                max_stories=max_stories,
            )

            # Fallback returns deterministic stories for downstream coverage.
            def fallback() -> dict:
                return {"stories": fallback_story_dicts}

            # Execute pipeline with timeout
            timeout_s = get_user_story_generation_timeout_s()
            result_data, metadata = pipeline.execute(
                base_prompt=prompt,
                template_content=template_schema,
                validator=validator,
                fallback_fn=fallback,
                timeout_s=timeout_s,
                allow_unchanged=False,
                llm_config={
                    "provider": resolved["provider"],
                    "model": resolved["model"],
                    "reasoning_level": resolved["reasoning_level"],
                    "auth": resolved["auth_method"],
                },
            )
            status = str(metadata.get("status", ""))
            if status in {"template_fallback", "template_error", "validation_failed"}:
                logger.warning(
                    "User story generation used fallback path (status=%s).",
                    status,
                )
                self.last_result_reason = status
                self._emit_event("user_story_generation_fallback", reason=status)

            # Parse stories from result
            stories_data = result_data.get("stories", [])
            if not isinstance(stories_data, list):
                logger.warning("Invalid stories data type: %s", type(stories_data))
                stories_data = fallback_story_dicts

            # Convert to UserStory objects with validation.
            stories = self._to_user_stories(stories_data, max_stories=max_stories)
            if not stories:
                logger.warning(
                    "User story generation produced no valid stories; using deterministic fallback stories."
                )
                self.last_result_reason = "zero_valid_stories"
                self._emit_event("user_story_generation_fallback", reason="zero_valid_stories")
                stories = self._to_user_stories(fallback_story_dicts, max_stories=max_stories)

            logger.info(
                "Generated %d user stories (max: %d)",
                len(stories),
                max_stories,
            )
            return stories

        except Exception as e:
            # Non-blocking: log warning and return empty list
            logger.warning(
                "User story generation failed (non-blocking): %s",
                e,
                exc_info=True,
            )
            self.last_result_reason = str(e)
            self._emit_event("user_story_generation_failed", reason=str(e))
            return []
