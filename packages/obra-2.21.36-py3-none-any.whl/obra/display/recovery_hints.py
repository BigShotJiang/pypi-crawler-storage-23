"""Recovery hint helpers for consistent CLI messaging."""

import logging

from obra.messages.recovery import build_resume_hints

_logger = logging.getLogger(__name__)
_logger.debug("obra.display.recovery_hints is deprecated. Use obra.messages.recovery instead.")


def build_resume_continue_hints(session_id: str) -> str:
    """Return standard resume/continue guidance for a session."""
    return build_resume_hints(session_id)


def build_interrupt_recovery_hints(session_id: str | None = None) -> str:
    """Return the standard Ctrl+C interruption recovery block."""
    sid = str(session_id).strip() if session_id else ""
    has_valid_sid = bool(sid) and sid != "<pending>"

    lines = ["Ctrl+C: pause safely at next checkpoint"]

    if has_valid_sid:
        lines.extend(build_resume_hints(sid).splitlines())
        lines.append(f"Session: {sid}")
    else:
        lines.extend(
            [
                "Resume:",
                "  obra run --resume <session_id>",
                "",
                "Continue (re-derive, skip completed; uses original objective):",
                "  obra run --continue-from <session_id>",
            ]
        )

    return "\n".join(lines)


def has_resume_continue_hints(text: str) -> bool:
    """Check if recovery text already includes resume/continue guidance."""
    if not text:
        return False
    return "obra run --resume" in text or "obra run --continue-from" in text


__all__ = [
    "build_interrupt_recovery_hints",
    "build_resume_continue_hints",
    "has_resume_continue_hints",
]
