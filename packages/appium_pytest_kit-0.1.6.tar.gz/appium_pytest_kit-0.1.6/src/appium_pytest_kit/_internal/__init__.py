"""Internal modules for appium-pytest-kit.

This namespace is intentionally private and may change between releases.
"""
