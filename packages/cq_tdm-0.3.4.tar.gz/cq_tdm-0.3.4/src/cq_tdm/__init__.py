"""CQ TDM - CT Scanner Quality Control Software."""

__version__ = "0.3.4"
