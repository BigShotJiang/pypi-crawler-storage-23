"""Allow running the package with python -m cq_tdm."""

from cq_tdm.main import main

if __name__ == "__main__":
    main()
