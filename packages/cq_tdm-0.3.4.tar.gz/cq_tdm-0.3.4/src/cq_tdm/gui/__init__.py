"""GUI components for CQ TDM."""
