"""Tests for nexus-control."""
