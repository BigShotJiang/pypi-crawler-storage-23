"""bicep-whatif-advisor: Azure What-If deployment analyzer using LLMs."""

__version__ = "3.1.0"
