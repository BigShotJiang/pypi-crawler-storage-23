
class NWKBroadcastTransactionTable:
    """
    Structure representing a NWK broadcast transaction table, keeping track of broadcasts.
    """
    def __init__(self):
        self.table = {}
