"""
WHAD ESB stack exceptions.
"""
class LinkLayerTimeoutException(Exception):
    """ESB Link-layer timeout exception
    """
