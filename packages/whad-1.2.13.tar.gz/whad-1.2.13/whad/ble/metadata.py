"""Old metadata stuff, do we need to remove it ?
"""
