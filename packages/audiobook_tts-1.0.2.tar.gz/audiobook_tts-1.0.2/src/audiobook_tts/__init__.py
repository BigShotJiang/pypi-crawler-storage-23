"""
Audiobook TTS - Local audiobook generation using MLX-Audio.

A high-quality text-to-speech system optimized for Apple Silicon,
supporting narration (Kokoro) and multi-speaker dialogue (Dia).
"""

__version__ = "1.0.0"
