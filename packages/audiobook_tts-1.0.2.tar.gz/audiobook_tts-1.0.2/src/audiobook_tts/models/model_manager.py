"""
Model manager for TTS engines.

Handles lazy loading and caching of TTS models to optimize memory usage.
"""

from typing import Optional

from ..config import TTSModel
from .tts_engine import BaseTTSEngine, ChatterboxEngine, CSMEngine, DiaEngine, KokoroEngine


class ModelManager:
    """
    Manages TTS model lifecycle.

    Provides lazy loading and caching of models to optimize memory usage.
    Only keeps one model loaded at a time by default.
    """

    def __init__(self, keep_all_loaded: bool = False, dia_use_4bit: bool = False):
        """
        Initialize model manager.

        Args:
            keep_all_loaded: If True, keep all models loaded. If False, unload
                             previous model when loading a new one.
            dia_use_4bit: Use 4-bit quantized Dia model for lower memory usage.
        """
        self._keep_all_loaded = keep_all_loaded
        self._dia_use_4bit = dia_use_4bit
        self._engines: dict[TTSModel, BaseTTSEngine] = {}
        self._current_model: Optional[TTSModel] = None

    def get_engine(self, model: TTSModel) -> BaseTTSEngine:
        """
        Get or create a TTS engine for the specified model.

        Args:
            model: The TTS model to get an engine for.

        Returns:
            The TTS engine, loaded and ready to use.
        """
        # Create engine if not exists
        if model not in self._engines:
            self._engines[model] = self._create_engine(model)

        engine = self._engines[model]

        # Handle model switching
        if not self._keep_all_loaded and self._current_model != model:
            # Unload previous model
            if self._current_model and self._current_model in self._engines:
                prev_engine = self._engines[self._current_model]
                if prev_engine.is_loaded():
                    prev_engine.unload()

        # Load new model if needed
        if not engine.is_loaded():
            engine.load()

        self._current_model = model
        return engine

    def _create_engine(self, model: TTSModel) -> BaseTTSEngine:
        """Create a new engine instance for the given model."""
        if model == TTSModel.KOKORO:
            return KokoroEngine()
        elif model in (TTSModel.DIA, TTSModel.DIA_4BIT):
            use_4bit = model == TTSModel.DIA_4BIT or self._dia_use_4bit
            return DiaEngine(use_4bit=use_4bit)
        elif model == TTSModel.CSM:
            return CSMEngine()
        elif model == TTSModel.CHATTERBOX:
            return ChatterboxEngine()
        else:
            raise ValueError(f"Unknown model: {model}")

    def get_kokoro(self) -> KokoroEngine:
        """Get Kokoro engine (convenience method)."""
        return self.get_engine(TTSModel.KOKORO)

    def get_dia(self) -> DiaEngine:
        """Get Dia engine (convenience method)."""
        return self.get_engine(TTSModel.DIA)

    def get_csm(self) -> CSMEngine:
        """Get CSM engine (convenience method)."""
        return self.get_engine(TTSModel.CSM)

    def get_chatterbox(self) -> ChatterboxEngine:
        """Get Chatterbox engine (convenience method)."""
        return self.get_engine(TTSModel.CHATTERBOX)

    def unload_all(self) -> None:
        """Unload all models from memory."""
        for engine in self._engines.values():
            if engine.is_loaded():
                engine.unload()
        self._current_model = None

    def loaded_models(self) -> list[TTSModel]:
        """Return list of currently loaded models."""
        return [
            model for model, engine in self._engines.items() if engine.is_loaded()
        ]
