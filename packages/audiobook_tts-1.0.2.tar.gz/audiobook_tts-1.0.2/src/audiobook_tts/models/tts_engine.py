"""
TTS Engine wrapper for mlx-audio models.

Provides unified interface for:
- Kokoro (preset voices, fast narration)
- Dia (multi-speaker dialogue)
- CSM (voice cloning from reference audio)
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Generator, Optional

import numpy as np


@dataclass
class AudioSegment:
    """Container for generated audio."""

    audio: np.ndarray
    sample_rate: int
    text: str
    duration_seconds: float


class BaseTTSEngine(ABC):
    """Abstract base class for TTS engines."""

    @abstractmethod
    def generate(self, text: str, **kwargs) -> Generator[AudioSegment, None, None]:
        """Generate audio from text, yielding segments."""
        pass

    @abstractmethod
    def is_loaded(self) -> bool:
        """Check if model is loaded."""
        pass

    @abstractmethod
    def load(self) -> None:
        """Load the model into memory."""
        pass

    @abstractmethod
    def unload(self) -> None:
        """Unload the model from memory."""
        pass


class KokoroEngine(BaseTTSEngine):
    """
    Kokoro TTS engine for narration.

    Features:
    - 54 preset voices (American, British, Japanese, Chinese)
    - Fast inference (~25x real-time on M4)
    - Speed control (0.5x - 2.0x)
    - Apache 2.0 license (commercial OK)

    Usage:
        engine = KokoroEngine()
        engine.load()
        for segment in engine.generate("Hello world", voice="af_bella"):
            # process segment.audio
    """

    MODEL_ID = "mlx-community/Kokoro-82M-bf16"

    # Available voices by category
    VOICES = {
        "american_female": [
            "af_heart",
            "af_bella",
            "af_nova",
            "af_sky",
            "af_nicole",
            "af_sarah",
        ],
        "american_male": [
            "am_adam",
            "am_echo",
            "am_eric",
            "am_liam",
            "am_michael",
            "am_onyx",
        ],
        "british_female": ["bf_alice", "bf_emma", "bf_isabella", "bf_lily"],
        "british_male": ["bm_daniel", "bm_fable", "bm_george", "bm_lewis"],
        "japanese_female": ["jf_alpha", "jf_gongitsune", "jf_nezumi"],
        "japanese_male": ["jm_kumo"],
        "chinese_female": ["zf_xiaobei", "zf_xiaoni", "zf_xiaoxiao"],
        "chinese_male": ["zm_yunxi", "zm_yunyang"],
    }

    def __init__(self):
        self._model = None

    def load(self) -> None:
        """Load Kokoro model into memory."""
        if self._model is None:
            from audiobook_tts.compat import ensure_espeak_compat

            ensure_espeak_compat()
            from mlx_audio.tts.utils import load_model

            self._model = load_model(self.MODEL_ID)

    def unload(self) -> None:
        """Unload model from memory."""
        self._model = None

    def is_loaded(self) -> bool:
        return self._model is not None

    def generate(
        self,
        text: str,
        voice: str = "af_bella",
        speed: float = 1.0,
        lang_code: str = "a",
    ) -> Generator[AudioSegment, None, None]:
        """
        Generate audio from text.

        Args:
            text: Text to synthesize
            voice: Voice preset (see VOICES dict)
            speed: Speech speed multiplier (0.5 - 2.0)
            lang_code: Language code ('a' = American, 'b' = British,
                       'j' = Japanese, 'z' = Chinese)

        Yields:
            AudioSegment for each generated chunk
        """
        if not self.is_loaded():
            self.load()

        for result in self._model.generate(
            text=text,
            voice=voice,
            speed=speed,
            lang_code=lang_code,
        ):
            audio_array = np.array(result.audio)
            duration = len(audio_array) / 24000

            yield AudioSegment(
                audio=audio_array,
                sample_rate=24000,
                text=text,
                duration_seconds=duration,
            )


class DiaEngine(BaseTTSEngine):
    """
    Dia TTS engine for multi-speaker dialogue.

    Features:
    - Native multi-speaker support with [S1], [S2] tags
    - Non-verbal sounds: (laughs), (sighs), (coughs), etc.
    - Voice cloning with audio conditioning
    - Apache 2.0 license (commercial OK)

    Usage:
        engine = DiaEngine()
        engine.load()
        text = "[S1] Hello! [S2] Hi there. (laughs)"
        for segment in engine.generate(text):
            # process segment.audio
    """

    MODEL_ID = "mlx-community/Dia-1.6B"
    MODEL_ID_4BIT = "mlx-community/Dia-1.6B-4bit"

    # Supported non-verbal tags
    NONVERBAL_TAGS = [
        "(laughs)",
        "(clears throat)",
        "(sighs)",
        "(gasps)",
        "(coughs)",
        "(singing)",
        "(sings)",
        "(mumbles)",
        "(groans)",
        "(sniffs)",
        "(claps)",
        "(screams)",
        "(inhales)",
        "(exhales)",
        "(applause)",
        "(burps)",
        "(humming)",
        "(sneezes)",
        "(chuckle)",
        "(whistles)",
    ]

    def __init__(self, use_4bit: bool = False):
        """
        Initialize Dia engine.

        Args:
            use_4bit: Use 4-bit quantized model (lower memory, slightly lower quality)
        """
        self._model = None
        self._model_id = self.MODEL_ID_4BIT if use_4bit else self.MODEL_ID

    def load(self) -> None:
        """Load Dia model into memory."""
        if self._model is None:
            from audiobook_tts.compat import ensure_espeak_compat

            ensure_espeak_compat()
            from mlx_audio.tts.utils import load_model

            self._model = load_model(self._model_id)

    def unload(self) -> None:
        """Unload model from memory."""
        self._model = None

    def is_loaded(self) -> bool:
        return self._model is not None

    def generate(
        self,
        text: str,
        reference_audio: Optional[Path] = None,
        reference_text: Optional[str] = None,
    ) -> Generator[AudioSegment, None, None]:
        """
        Generate multi-speaker dialogue audio.

        Args:
            text: Script with speaker tags, e.g., "[S1] Hello! [S2] Hi there."
            reference_audio: Optional audio file for voice cloning
            reference_text: Transcript of reference audio (required if
                            reference_audio provided)

        Yields:
            AudioSegment for the complete dialogue

        Note:
            - Always start text with [S1]
            - Alternate between [S1] and [S2]
            - Optimal text length: 5-20 seconds of speech
        """
        if not self.is_loaded():
            self.load()

        # Dia generates complete dialogue in one pass
        generate_kwargs = {"text": text}

        if reference_audio and reference_text:
            generate_kwargs["ref_audio"] = str(reference_audio)
            generate_kwargs["ref_text"] = reference_text

        for result in self._model.generate(**generate_kwargs):
            audio_array = np.array(result.audio)
            duration = len(audio_array) / 24000

            yield AudioSegment(
                audio=audio_array,
                sample_rate=24000,
                text=text,
                duration_seconds=duration,
            )


class ChatterboxEngine(BaseTTSEngine):
    """
    Chatterbox TTS engine for voice cloning with emotion control.

    Features:
    - Zero-shot voice cloning from reference audio
    - Emotion exaggeration control (0.0 = neutral, 1.0 = maximum)
    - CFG weight for generation quality tuning
    - Temperature control for variation

    Usage:
        engine = ChatterboxEngine()
        engine.load()
        for segment in engine.generate(
            "Hello world",
            ref_audio=Path("reference.wav"),
            exaggeration=0.5,
        ):
            # process segment.audio
    """

    MODEL_ID = "mlx-community/chatterbox-fp16"

    def __init__(self):
        self._model = None

    def load(self) -> None:
        if self._model is None:
            from audiobook_tts.compat import ensure_espeak_compat

            ensure_espeak_compat()
            from mlx_audio.tts.utils import load_model

            self._model = load_model(self.MODEL_ID)

    def unload(self) -> None:
        self._model = None

    def is_loaded(self) -> bool:
        return self._model is not None

    def generate(
        self,
        text: str,
        ref_audio: Optional[Path] = None,
        exaggeration: float = 0.5,
        cfg_weight: float = 0.5,
        temperature: float = 0.8,
    ) -> Generator[AudioSegment, None, None]:
        """
        Generate audio with cloned voice and emotion control.

        Args:
            text: Text to synthesize
            ref_audio: Path to reference audio file for voice cloning
            exaggeration: Emotion exaggeration level (0.0-1.0)
            cfg_weight: Classifier-free guidance weight
            temperature: Sampling temperature

        Yields:
            AudioSegment with cloned voice
        """
        if not self.is_loaded():
            self.load()

        generate_kwargs = {
            "text": text,
            "exaggeration": exaggeration,
            "cfg_weight": cfg_weight,
            "temperature": temperature,
        }
        if ref_audio:
            generate_kwargs["audio_prompt"] = str(ref_audio)
            generate_kwargs["audio_prompt_sr"] = 24000

        for result in self._model.generate(**generate_kwargs):
            audio_array = np.array(result.audio)
            duration = len(audio_array) / 24000

            yield AudioSegment(
                audio=audio_array,
                sample_rate=24000,
                text=text,
                duration_seconds=duration,
            )


class CSMEngine(BaseTTSEngine):
    """
    CSM (Conversational Speech Model) engine for voice cloning.

    Features:
    - Zero-shot voice cloning from ~10-15 second reference
    - High-quality conversational speech

    Usage:
        engine = CSMEngine()
        engine.load()
        for segment in engine.generate(
            "Hello world",
            reference_audio=Path("reference.wav")
        ):
            # process segment.audio
    """

    MODEL_ID = "mlx-community/csm-1b"

    def __init__(self):
        self._model = None

    def load(self) -> None:
        if self._model is None:
            from audiobook_tts.compat import ensure_espeak_compat

            ensure_espeak_compat()
            from mlx_audio.tts.utils import load_model

            self._model = load_model(self.MODEL_ID)

    def unload(self) -> None:
        self._model = None

    def is_loaded(self) -> bool:
        return self._model is not None

    def generate(
        self,
        text: str,
        reference_audio: Optional[Path] = None,
    ) -> Generator[AudioSegment, None, None]:
        """
        Generate audio cloning voice from reference.

        Args:
            text: Text to synthesize
            reference_audio: Audio file to clone voice from (10-15 seconds recommended)

        Yields:
            AudioSegment with cloned voice
        """
        if not self.is_loaded():
            self.load()

        generate_kwargs = {"text": text}
        if reference_audio:
            generate_kwargs["ref_audio"] = str(reference_audio)

        for result in self._model.generate(**generate_kwargs):
            audio_array = np.array(result.audio)
            duration = len(audio_array) / 24000

            yield AudioSegment(
                audio=audio_array,
                sample_rate=24000,
                text=text,
                duration_seconds=duration,
            )
