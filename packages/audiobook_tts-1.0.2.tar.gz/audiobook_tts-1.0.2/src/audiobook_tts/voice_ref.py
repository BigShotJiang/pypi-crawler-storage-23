"""
Generate voice reference clips for Chatterbox voice cloning.

Uses Kokoro to generate ~15 second WAV clips for each Kokoro voice preset.
These clips serve as reference audio for Chatterbox to clone voice characteristics.

Usage:
    audiobook-voice-ref --all
    audiobook-voice-ref --preset af_bella
    audiobook-voice-ref --list
    audiobook-voice-ref --preset af_bella --text "Custom reference text"
    audiobook-voice-ref --all --output-dir .audiobook/voice-refs
"""

import argparse
import sys
from pathlib import Path

# Phonetically diverse passage with neutral emotion — covers a range of
# vowels, consonants, fricatives, and prosodic patterns in ~15 seconds.
DEFAULT_REFERENCE_TEXT = (
    "The morning light filtered through the ancient stone arches, casting long "
    "shadows across the weathered courtyard. A gentle breeze carried the scent "
    "of jasmine and fresh bread from the bakery beyond the eastern gate. "
    "Children gathered near the fountain, their quiet voices blending with the "
    "soft murmur of flowing water. Above them, swallows traced wide circles "
    "against a sky the colour of pale silver."
)

# All 20 English Kokoro presets with their language codes
ENGLISH_PRESETS = {
    # American female
    "af_heart": {"lang_code": "a", "speed": 1.0, "category": "American Female"},
    "af_bella": {"lang_code": "a", "speed": 1.0, "category": "American Female"},
    "af_nova": {"lang_code": "a", "speed": 1.0, "category": "American Female"},
    "af_sky": {"lang_code": "a", "speed": 1.0, "category": "American Female"},
    "af_nicole": {"lang_code": "a", "speed": 1.0, "category": "American Female"},
    "af_sarah": {"lang_code": "a", "speed": 1.0, "category": "American Female"},
    # American male
    "am_adam": {"lang_code": "a", "speed": 1.0, "category": "American Male"},
    "am_echo": {"lang_code": "a", "speed": 1.0, "category": "American Male"},
    "am_eric": {"lang_code": "a", "speed": 1.0, "category": "American Male"},
    "am_liam": {"lang_code": "a", "speed": 1.0, "category": "American Male"},
    "am_michael": {"lang_code": "a", "speed": 1.0, "category": "American Male"},
    "am_onyx": {"lang_code": "a", "speed": 1.0, "category": "American Male"},
    # British female
    "bf_alice": {"lang_code": "b", "speed": 1.0, "category": "British Female"},
    "bf_emma": {"lang_code": "b", "speed": 1.0, "category": "British Female"},
    "bf_isabella": {"lang_code": "b", "speed": 1.0, "category": "British Female"},
    "bf_lily": {"lang_code": "b", "speed": 1.0, "category": "British Female"},
    # British male
    "bm_daniel": {"lang_code": "b", "speed": 1.0, "category": "British Male"},
    "bm_fable": {"lang_code": "b", "speed": 1.0, "category": "British Male"},
    "bm_george": {"lang_code": "b", "speed": 1.0, "category": "British Male"},
    "bm_lewis": {"lang_code": "b", "speed": 1.0, "category": "British Male"},
}


def list_presets():
    """Print all available Kokoro presets grouped by category."""
    from rich.console import Console
    from rich.table import Table

    console = Console()

    current_category = None
    table = None

    for preset_name, info in ENGLISH_PRESETS.items():
        if info["category"] != current_category:
            if table is not None:
                console.print(table)
                console.print()
            current_category = info["category"]
            table = Table(title=current_category)
            table.add_column("Preset", style="green")
            table.add_column("Lang Code", style="cyan")

        table.add_row(preset_name, info["lang_code"])

    if table is not None:
        console.print(table)

    console.print(f"\n[blue]{len(ENGLISH_PRESETS)} presets available[/blue]")


def generate_preset(
    preset_name: str,
    output_dir: Path,
    text: str = DEFAULT_REFERENCE_TEXT,
    skip_existing: bool = True,
) -> bool:
    """
    Generate a single voice reference clip.

    Args:
        preset_name: Kokoro preset name (e.g., "af_bella")
        output_dir: Directory to save the WAV file
        text: Reference text to speak
        skip_existing: Skip if output file already exists

    Returns:
        True if generated or skipped, False on failure
    """
    import numpy as np
    import soundfile as sf
    from rich.console import Console

    console = Console()

    if preset_name not in ENGLISH_PRESETS:
        console.print(f"[red]Unknown preset: {preset_name}[/red]")
        console.print(f"[dim]Run audiobook-voice-ref --list to see available presets[/dim]")
        return False

    output_path = output_dir / f"{preset_name}.wav"

    if skip_existing and output_path.exists():
        console.print(f"  [dim]Skipping {preset_name} (already exists)[/dim]")
        return True

    params = ENGLISH_PRESETS[preset_name]

    from audiobook_tts.models.tts_engine import KokoroEngine

    engine = KokoroEngine()
    engine.load()

    audio_chunks = []
    for segment in engine.generate(
        text=text,
        voice=preset_name,
        speed=params["speed"],
        lang_code=params["lang_code"],
    ):
        audio_chunks.append(segment.audio)

    if not audio_chunks:
        console.print(f"  [red]Failed to generate {preset_name}[/red]")
        return False

    combined = np.concatenate(audio_chunks)
    output_dir.mkdir(parents=True, exist_ok=True)
    sf.write(str(output_path), combined, 24000)

    duration = len(combined) / 24000
    console.print(f"  [green]{preset_name}.wav[/green] — {duration:.1f}s")
    return True


def generate_all(
    output_dir: Path,
    text: str = DEFAULT_REFERENCE_TEXT,
    skip_existing: bool = True,
):
    """Generate reference clips for all English Kokoro presets."""
    import numpy as np
    import soundfile as sf
    from rich.console import Console
    from rich.progress import Progress

    from audiobook_tts.models.tts_engine import KokoroEngine

    console = Console()

    output_dir.mkdir(parents=True, exist_ok=True)
    console.print(f"[blue]Output directory: {output_dir}[/blue]")
    console.print(f"[blue]Generating {len(ENGLISH_PRESETS)} voice reference clips...[/blue]\n")

    engine = KokoroEngine()
    console.print("[yellow]Loading Kokoro model...[/yellow]")
    engine.load()
    console.print("[green]Kokoro loaded.[/green]\n")

    generated = 0
    skipped = 0

    with Progress(console=console) as progress:
        task = progress.add_task("[cyan]Generating clips", total=len(ENGLISH_PRESETS))

        for preset_name, params in ENGLISH_PRESETS.items():
            output_path = output_dir / f"{preset_name}.wav"

            if skip_existing and output_path.exists():
                console.print(f"  [dim]Skipping {preset_name} (already exists)[/dim]")
                skipped += 1
                progress.advance(task)
                continue

            audio_chunks = []
            for segment in engine.generate(
                text=text,
                voice=preset_name,
                speed=params["speed"],
                lang_code=params["lang_code"],
            ):
                audio_chunks.append(segment.audio)

            if not audio_chunks:
                console.print(f"  [red]Failed to generate {preset_name}[/red]")
                progress.advance(task)
                continue

            combined = np.concatenate(audio_chunks)
            sf.write(str(output_path), combined, 24000)

            duration = len(combined) / 24000
            console.print(f"  [green]{preset_name}.wav[/green] — {duration:.1f}s")
            generated += 1
            progress.advance(task)

    console.print(
        f"\n[green]Done! {generated} generated, {skipped} skipped "
        f"(total {len(ENGLISH_PRESETS)} presets)[/green]"
    )


def main():
    """Main entry point for audiobook-voice-ref CLI."""
    parser = argparse.ArgumentParser(
        description="Generate Kokoro voice reference clips for Chatterbox voice cloning",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Generate all 20 English Kokoro reference clips
    audiobook-voice-ref --all

    # Generate a single preset
    audiobook-voice-ref --preset af_bella

    # List all available presets
    audiobook-voice-ref --list

    # Use custom reference text
    audiobook-voice-ref --preset af_bella --text "Custom reference text here"

    # Output to custom directory
    audiobook-voice-ref --all --output-dir ./my-voice-refs

    # Force regeneration of existing clips
    audiobook-voice-ref --all --no-skip-existing
        """,
    )

    parser.add_argument(
        "--all",
        action="store_true",
        help="Generate reference clips for all 20 English Kokoro presets",
    )
    parser.add_argument(
        "--preset",
        type=str,
        help="Generate clip for a specific Kokoro preset (e.g., af_bella)",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List all available Kokoro presets",
    )
    parser.add_argument(
        "--text",
        type=str,
        default=DEFAULT_REFERENCE_TEXT,
        help="Custom reference text to speak (default: built-in phonetically diverse passage)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(".audiobook/voice-refs"),
        help="Output directory for WAV files (default: .audiobook/voice-refs)",
    )
    parser.add_argument(
        "--no-skip-existing",
        action="store_true",
        help="Regenerate clips even if they already exist",
    )

    args = parser.parse_args()

    if args.list:
        list_presets()
        return 0

    if not args.all and not args.preset:
        parser.print_help()
        print("\nError: specify --all, --preset, or --list")
        return 1

    skip_existing = not args.no_skip_existing

    if args.all:
        generate_all(args.output_dir, text=args.text, skip_existing=skip_existing)
    elif args.preset:
        success = generate_preset(
            args.preset, args.output_dir, text=args.text, skip_existing=skip_existing
        )
        if not success:
            return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
