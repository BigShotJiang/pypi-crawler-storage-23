"""
Utility functions for audiobook TTS system.

Provides:
- Dependency validation (ffmpeg, etc.)
- System information gathering
- Helper functions
"""

import re
import subprocess
from typing import Optional


class DependencyError(Exception):
    """Exception raised when a required dependency is missing."""

    pass


def check_ffmpeg() -> tuple[bool, Optional[str]]:
    """
    Check if ffmpeg is installed and get its version.

    Returns:
        Tuple of (available: bool, version: str or None)
    """
    try:
        result = subprocess.run(
            ["ffmpeg", "-version"],
            capture_output=True,
            text=True,
        )

        if result.returncode == 0:
            # Extract version from output
            # Format: "ffmpeg version 6.0.1 Copyright..."
            version_output = result.stderr or result.stdout
            version_match = re.search(
                r"ffmpeg version (\d+\.\d+(?:\.\d+)?)",
                version_output
            )
            version = version_match.group(1) if version_match else "unknown"
            return True, version

        return False, None

    except FileNotFoundError:
        return False, None
    except Exception:
        return False, None


def check_ffmpeg_normalize() -> tuple[bool, Optional[str]]:
    """
    Check if ffmpeg-normalize is installed and get its version.

    Returns:
        Tuple of (available: bool, version: str or None)
    """
    try:
        result = subprocess.run(
            ["ffmpeg-normalize", "--version"],
            capture_output=True,
            text=True,
        )

        if result.returncode == 0:
            version = result.stdout.strip() if result.stdout else "unknown"
            return True, version

        return False, None

    except FileNotFoundError:
        return False, None
    except Exception:
        return False, None


def check_dependencies() -> dict[str, dict[str, any]]:
    """
    Check all required external dependencies.

    Returns:
        Dictionary with dependency names as keys and status dicts as values.
        Each status dict contains 'available' (bool) and 'version' (str or None).
    """
    ffmpeg_available, ffmpeg_version = check_ffmpeg()
    ffmpeg_normalize_available, ffmpeg_normalize_version = check_ffmpeg_normalize()

    return {
        "ffmpeg": {
            "available": ffmpeg_available,
            "version": ffmpeg_version,
            "required": True,
            "install_hint": "brew install ffmpeg (macOS) or apt install ffmpeg (Linux)",
        },
        "ffmpeg-normalize": {
            "available": ffmpeg_normalize_available,
            "version": ffmpeg_normalize_version,
            "required": True,
            "install_hint": "pip install ffmpeg-normalize",
        },
    }


def require_ffmpeg() -> str:
    """
    Require ffmpeg to be available, raising DependencyError if not.

    Returns:
        Version string if ffmpeg is available

    Raises:
        DependencyError: If ffmpeg is not installed
    """
    available, version = check_ffmpeg()

    if not available:
        raise DependencyError(
            "ffmpeg is required but not found.\n"
            "Please install it:\n"
            "  macOS: brew install ffmpeg\n"
            "  Linux: apt install ffmpeg\n"
            "  Windows: Download from https://ffmpeg.org/download.html"
        )

    return version


def get_dependency_status() -> str:
    """
    Get a user-friendly status report of all dependencies.

    Returns:
        Formatted string with dependency status information
    """
    deps = check_dependencies()
    lines = ["Dependency Status:", "=" * 40]

    for name, info in deps.items():
        status = "OK" if info["available"] else "MISSING"
        version = info["version"] if info["version"] else "N/A"
        required = "required" if info["required"] else "optional"

        if info["available"]:
            lines.append(f"  {name}: {status} (v{version})")
        else:
            lines.append(f"  {name}: {status} ({required})")
            lines.append(f"    Install: {info['install_hint']}")

    return "\n".join(lines)
