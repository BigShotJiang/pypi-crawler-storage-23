"""
Command-line interface for audiobook generation.

Usage:
    # Generate from compiled manuscript
    audiobook-generate --input compiled/1-resonance-and-reason-manuscript.md

    # Generate specific chapters
    audiobook-generate --input compiled/book.md --chapters 1-5

    # Use specific voice
    audiobook-generate --input compiled/book.md --voice narrator_male_uk

    # Resume interrupted generation
    audiobook-generate --input compiled/book.md --resume

    # Generate as MP3 (ACX-ready)
    audiobook-generate --input compiled/book.md --format mp3

    # Use series configuration for automatic book detection
    audiobook-generate --input compiled/1-resonance-and-reason-manuscript.md --series-config .audiobook/series.yaml
"""

import argparse
import sys
from pathlib import Path
from typing import Optional

import numpy as np

from rich.console import Console
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)
from rich.table import Table

from .config import Config, TTSModel, VoiceProfile
from .models.model_manager import ModelManager
from .models.tts_engine import AudioSegment
from .processing.audio_processor import AudioProcessor
from .processing.manuscript import Chapter, ManuscriptProcessor
from .processing.text_processor import TextChunk, TextProcessor

console = Console()


def parse_chapter_range(range_str: str) -> list[int]:
    """
    Parse chapter range string like '1-5' or '1,3,5' or '1-3,7,9-12'.

    Returns list of chapter numbers.
    """
    chapters = []
    for part in range_str.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-")
            chapters.extend(range(int(start), int(end) + 1))
        else:
            chapters.append(int(part))
    return sorted(set(chapters))


def create_argument_parser() -> argparse.ArgumentParser:
    """
    Create and configure the argument parser for the CLI.

    Returns:
        Configured ArgumentParser instance
    """
    parser = argparse.ArgumentParser(
        description="Generate audiobook from manuscript files",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Generate full audiobook from compiled manuscript
    audiobook-generate --input compiled/1-resonance-and-reason-manuscript.md

    # Generate specific chapters
    audiobook-generate --input compiled/book.md --chapters 1-5

    # Generate chapters 1, 3, and 5-10
    audiobook-generate --input compiled/book.md --chapters 1,3,5-10

    # Use a specific voice
    audiobook-generate --input compiled/book.md --voice narrator_male_uk

    # Output to specific directory
    audiobook-generate --input compiled/book.md --output ./audiobook-output

    # Generate as MP3 (ACX-ready)
    audiobook-generate --input compiled/book.md --format mp3

    # Use series configuration for automatic book/voice selection
    audiobook-generate --input compiled/1-resonance-and-reason-manuscript.md --series-config .audiobook/series.yaml

    # List available voices
    audiobook-generate --list-voices
        """,
    )

    parser.add_argument(
        "--input",
        "-i",
        type=Path,
        help="Path to compiled manuscript file or chapter directory",
    )
    parser.add_argument(
        "--output",
        "-o",
        type=Path,
        default=Path("./output"),
        help="Output directory for audio files (default: ./output)",
    )
    parser.add_argument(
        "--chapters",
        "-c",
        type=str,
        help="Chapter range to generate (e.g., '1-5' or '1,3,5-10')",
    )
    parser.add_argument(
        "--voice",
        "-v",
        type=str,
        default="narrator_female_us",
        help="Voice profile to use (default: narrator_female_us)",
    )
    parser.add_argument(
        "--format",
        "-f",
        type=str,
        choices=["wav", "mp3"],
        default="wav",
        help="Output audio format (default: wav)",
    )
    parser.add_argument(
        "--resume",
        "-r",
        action="store_true",
        help="Resume from last progress checkpoint",
    )
    parser.add_argument(
        "--list-voices",
        action="store_true",
        help="List available voice profiles",
    )
    parser.add_argument(
        "--no-normalize",
        action="store_true",
        help="Skip ACX normalization (faster, but not production-ready)",
    )
    parser.add_argument(
        "--config",
        type=Path,
        help="Path to YAML configuration file",
    )
    parser.add_argument(
        "--series-config",
        type=Path,
        default=None,
        help="Path to series configuration YAML file for automatic book detection and voice mapping",
    )

    return parser


def _generate_with_engine(
    model_manager: ModelManager,
    text: str,
    voice_config: VoiceProfile,
) -> list[AudioSegment]:
    """
    Generate audio using the appropriate engine based on voice config.

    Dispatches to Kokoro or Chatterbox with the correct parameters.

    Args:
        model_manager: Model manager instance
        text: Text to synthesize
        voice_config: Voice profile with model-specific parameters

    Returns:
        List of AudioSegment objects
    """
    engine = model_manager.get_engine(voice_config.model)
    segments = []

    # Pre-process text for Chatterbox to preserve prosody cues
    if voice_config.model == TTSModel.CHATTERBOX:
        text = TextProcessor.prepare_for_chatterbox(text)

    if voice_config.model == TTSModel.CHATTERBOX:
        ref_path = Path(voice_config.ref_audio) if voice_config.ref_audio else None
        if ref_path and not ref_path.exists():
            raise FileNotFoundError(
                f"Reference audio not found: {ref_path.resolve()} "
                f"(from voice profile '{voice_config.name}'). "
                f"Run: audiobook-voice-ref --all"
            )
        for segment in engine.generate(
            text=text,
            ref_audio=ref_path,
            exaggeration=voice_config.exaggeration,
            cfg_weight=voice_config.cfg_weight,
            temperature=voice_config.temperature,
        ):
            segments.append(segment)
    elif voice_config.model == TTSModel.KOKORO:
        for segment in engine.generate(
            text=text,
            voice=voice_config.voice_preset,
            speed=voice_config.speed,
            lang_code=voice_config.lang_code,
        ):
            segments.append(segment)
    else:
        # Fallback for other engines (Dia, CSM)
        for segment in engine.generate(text=text):
            segments.append(segment)

    return segments


def generate_chapter_audio(
    chapter: Chapter,
    config: Config,
    model_manager: ModelManager,
    text_processor: TextProcessor,
    audio_processor: AudioProcessor,
    output_dir: Path,
    output_format: str = "wav",
    normalize: bool = True,
    progress: Optional[Progress] = None,
    task_id: Optional[int] = None,
) -> Path:
    """
    Generate audio for a single chapter.

    Args:
        chapter: Chapter to generate audio for
        config: Configuration
        model_manager: Model manager
        text_processor: Text processor
        audio_processor: Audio processor
        output_dir: Directory to save output
        output_format: Output format (wav or mp3)
        progress: Optional rich Progress instance
        task_id: Optional task ID for progress updates

    Returns:
        Path to generated audio file
    """
    # Get voice config based on POV character mapping
    voice_config = config.get_voice_for_pov(chapter.pov_character)

    audio_segments = []

    # Generate chapter announcement if enabled
    if config.chapter_announcement.enabled:
        announcement_text = chapter.get_announcement_text(
            config.chapter_announcement.format_string
        )
        for segment in _generate_with_engine(model_manager, announcement_text, voice_config):
            audio_segments.append(segment.audio)
        # Add pause after announcement
        pause_samples = int(
            config.chapter_announcement.pause_after_ms * config.audio.sample_rate / 1000
        )
        audio_segments.append(np.zeros(pause_samples, dtype=np.float32))

    # Chunk the chapter text with structural pauses
    chunks = text_processor.chunk_text_structured(
        chapter.text,
        scene_break_pause_ms=config.processing.scene_break_pause_ms,
        paragraph_pause_ms=config.processing.paragraph_pause_ms,
    )

    for i, chunk in enumerate(chunks):
        for segment in _generate_with_engine(model_manager, chunk.text, voice_config):
            audio_segments.append(segment.audio)

        # Insert structural pause (scene break or paragraph gap)
        if chunk.pause_after_ms > 0:
            pause_samples = int(chunk.pause_after_ms * config.audio.sample_rate / 1000)
            audio_segments.append(np.zeros(pause_samples, dtype=np.float32))

        if progress and task_id is not None:
            progress.update(task_id, completed=i + 1)

    # Concatenate segments
    combined = audio_processor.concatenate_segments(
        audio_segments,
        crossfade_ms=config.processing.crossfade_ms,
    )

    # Add silence padding
    combined = audio_processor.add_silence_padding(
        combined,
        start_ms=config.processing.silence_padding_ms,
        end_ms=config.processing.silence_padding_ms,
    )

    # Save to WAV first
    wav_filename = f"chapter-{chapter.number:02d}.wav"
    wav_path = output_dir / wav_filename

    audio_processor.save_audio(
        combined,
        wav_path,
        normalize=normalize,
    )

    # Convert to MP3 if requested
    if output_format == "mp3":
        mp3_path = audio_processor.convert_to_mp3(wav_path)
        # Remove the WAV file
        wav_path.unlink(missing_ok=True)
        return mp3_path

    return wav_path


def main():
    """Main CLI entry point."""
    parser = create_argument_parser()
    args = parser.parse_args()

    # List voices and exit
    if args.list_voices:
        list_voices()
        return 0

    # Require input file for generation
    if not args.input:
        parser.print_help()
        console.print("\n[red]Error: --input is required for generation[/red]")
        return 1

    if not args.input.exists():
        console.print(f"[red]Error: Input file not found: {args.input}[/red]")
        return 1

    # Load configuration (layered: package defaults + project overrides)
    if args.config:
        config = Config.load_merged(args.config)
    elif args.series_config:
        project_voices = args.series_config.parent / "voices.yaml"
        config = Config.load_merged(project_voices if project_voices.exists() else None)
    else:
        config = Config.load_merged(None)

    # Apply series configuration if provided
    if args.series_config and args.series_config.exists():
        from .series_config import (
            apply_book_config,
            detect_book_from_filename,
            load_series_config,
        )

        series_config = load_series_config(args.series_config)
        book_config = detect_book_from_filename(series_config, args.input)

        if book_config:
            console.print(
                f"[blue]Detected book: {book_config.title}[/blue]"
            )
            config = apply_book_config(
                config, book_config, series_config.default_voice
            )
        else:
            console.print(
                "[yellow]Warning: Could not detect book from filename, "
                "using default configuration[/yellow]"
            )

    config.output_dir = args.output

    # Initialize components
    console.print("[blue]Initializing TTS engine...[/blue]")

    manuscript_processor = ManuscriptProcessor(cache_dir=config.cache_dir)
    model_manager = ModelManager()
    text_processor = TextProcessor(max_chunk_chars=config.processing.max_chunk_chars)
    audio_processor = AudioProcessor()

    # Load manuscript
    console.print(f"[blue]Loading manuscript from {args.input}...[/blue]")

    if args.input.is_dir():
        chapters = manuscript_processor.load_chapter_directory(args.input)
    else:
        chapters = manuscript_processor.load_compiled_manuscript(args.input)

    if not chapters:
        console.print("[red]Error: No chapters found in manuscript[/red]")
        return 1

    console.print(f"[green]Found {len(chapters)} chapters[/green]")

    # Filter chapters if specified
    if args.chapters:
        chapter_nums = parse_chapter_range(args.chapters)
        chapters = [c for c in chapters if c.number in chapter_nums]
        console.print(f"[blue]Generating chapters: {chapter_nums}[/blue]")

    if not chapters:
        console.print("[red]Error: No matching chapters found[/red]")
        return 1

    # Show summary
    total_words = sum(c.word_count for c in chapters)
    estimated_minutes = sum(c.estimated_duration_minutes for c in chapters)

    table = Table(title="Generation Summary")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")
    table.add_row("Chapters", str(len(chapters)))
    table.add_row("Total Words", f"{total_words:,}")
    table.add_row("Estimated Duration", f"{estimated_minutes:.1f} minutes")
    if config.pov_voice_mapping:
        table.add_row("Voice Mode", "POV-mapped (per character)")
    else:
        table.add_row("Voice", args.voice)
    table.add_row("Output Format", args.format.upper())
    table.add_row("Output Directory", str(args.output))
    console.print(table)

    # Create output directory
    args.output.mkdir(parents=True, exist_ok=True)

    # Load progress if resuming
    book_title = args.input.stem
    progress_tracker = manuscript_processor.load_or_create_progress(
        book_title, chapters
    )

    if args.resume and progress_tracker.completed_chapters:
        completed = set(progress_tracker.completed_chapters)
        chapters = [c for c in chapters if c.number not in completed]
        console.print(
            f"[yellow]Resuming: {len(progress_tracker.completed_chapters)} "
            f"chapters already complete, {len(chapters)} remaining[/yellow]"
        )

    # Generate audio for each chapter
    console.print("\n[blue]Starting generation...[/blue]\n")

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        overall_task = progress.add_task(
            "[cyan]Overall progress", total=len(chapters)
        )

        for chapter in chapters:
            # Create task for this chapter
            chunks = text_processor.chunk_text_structured(
                chapter.text,
                scene_break_pause_ms=config.processing.scene_break_pause_ms,
                paragraph_pause_ms=config.processing.paragraph_pause_ms,
            )
            chapter_task = progress.add_task(
                f"[green]Chapter {chapter.number}: {chapter.title[:30]}...",
                total=len(chunks),
            )

            try:
                output_path = generate_chapter_audio(
                    chapter=chapter,
                    config=config,
                    model_manager=model_manager,
                    text_processor=text_processor,
                    audio_processor=audio_processor,
                    output_dir=args.output,
                    output_format=args.format,
                    normalize=not args.no_normalize,
                    progress=progress,
                    task_id=chapter_task,
                )

                # Update progress tracker
                progress_tracker.completed_chapters.append(chapter.number)
                progress_tracker.output_files[chapter.number] = str(output_path)
                progress_tracker.save(
                    manuscript_processor.get_progress_file(book_title)
                )

                progress.update(chapter_task, completed=len(chunks))
                progress.update(overall_task, advance=1)

            except Exception as e:
                console.print(
                    f"\n[red]Error generating chapter {chapter.number}: {e}[/red]"
                )
                progress.update(chapter_task, description=f"[red]Failed: {e}[/red]")
                # Continue with next chapter

    console.print("\n[green]Generation complete![/green]")
    console.print(f"[blue]Output files saved to: {args.output}[/blue]")

    return 0


def list_voices():
    """List available voice profiles."""
    from .models.tts_engine import KokoroEngine

    console.print("\n[bold cyan]Available Kokoro Voices[/bold cyan]\n")

    for category, voices in KokoroEngine.VOICES.items():
        table = Table(title=category.replace("_", " ").title())
        table.add_column("Voice ID", style="green")
        for voice in voices:
            table.add_row(voice)
        console.print(table)
        console.print()

    console.print("[bold cyan]Configured Voice Profiles[/bold cyan]\n")

    config = Config.default()
    table = Table()
    table.add_column("Profile Name", style="cyan")
    table.add_column("Model", style="blue")
    table.add_column("Voice Preset", style="green")
    table.add_column("Description")

    for name, profile in config.voices.items():
        table.add_row(
            name,
            profile.model.name,
            profile.voice_preset or "(speaker tags)",
            profile.description,
        )

    console.print(table)


if __name__ == "__main__":
    sys.exit(main())
