"""
Configuration module for audiobook TTS system.

Defines:
- Voice profiles (name -> model + voice preset mapping)
- Audio output settings (sample rate, format, normalization targets)
- Processing settings (chunk size, overlap, etc.)
- POV-to-voice mapping for automatic voice selection
- Chapter announcement settings
"""

import importlib.resources
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

import yaml


class TTSModel(Enum):
    """Supported TTS models."""

    KOKORO = "mlx-community/Kokoro-82M-bf16"
    DIA = "mlx-community/Dia-1.6B"
    DIA_4BIT = "mlx-community/Dia-1.6B-4bit"
    CSM = "mlx-community/csm-1b"
    CHATTERBOX = "mlx-community/chatterbox-fp16"


@dataclass
class VoiceProfile:
    """Configuration for a single voice."""

    name: str
    model: TTSModel
    voice_preset: str  # e.g., "af_bella" for Kokoro
    speed: float = 1.0
    lang_code: str = "a"  # 'a' = American English, 'b' = British
    description: str = ""
    # Chatterbox-specific fields
    ref_audio: Optional[str] = None  # Path to reference audio for voice cloning
    exaggeration: float = 0.5  # Emotion exaggeration (0.0 = neutral, 1.0 = max)
    cfg_weight: float = 0.5  # Classifier-free guidance weight
    temperature: float = 0.8  # Sampling temperature


@dataclass
class AudioSettings:
    """Audio output configuration."""

    sample_rate: int = 24000
    output_format: str = "wav"  # wav, mp3, flac
    # ACX compliance settings
    target_lufs: float = -20.0  # -23 to -18 dB for ACX
    true_peak: float = -3.0  # Must be <= -3dB
    noise_floor: float = -60.0  # Must be <= -60dB
    # MP3 settings (if output_format is mp3)
    mp3_bitrate: str = "192k"


@dataclass
class ProcessingSettings:
    """Text and audio processing settings."""

    max_chunk_chars: int = 400  # Max characters per TTS chunk
    sentence_overlap: int = 0  # Sentences to overlap between chunks
    crossfade_ms: int = 50  # Crossfade between audio segments
    silence_padding_ms: int = 500  # Silence at chapter start/end (ACX requirement)
    batch_size: int = 10  # Chunks to process before saving progress
    scene_break_pause_ms: int = 2500  # Silence at scene breaks (* * *)
    paragraph_pause_ms: int = 400  # Silence between paragraphs


@dataclass
class ChapterAnnouncementSettings:
    """Settings for chapter title announcements."""

    enabled: bool = False  # Whether to announce chapter titles
    format_string: str = "Chapter {number}: {title}"  # Format for announcement
    pause_after_ms: int = 1000  # Pause after announcement before content


def _deep_merge(base: dict, override: dict) -> dict:
    """
    Recursively deep-merge override into base.

    - Dict values are merged recursively (override keys add to / replace base keys)
    - All other values are replaced by override
    - base is not mutated; returns a new dict

    Args:
        base: Base dictionary (defaults)
        override: Override dictionary (project-specific)

    Returns:
        New merged dictionary
    """
    merged = base.copy()
    for key, value in override.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(value, dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def _parse_model(model_name: str) -> TTSModel:
    """Parse a model name string into a TTSModel enum value."""
    model_name = model_name.upper()
    if model_name == "KOKORO":
        return TTSModel.KOKORO
    elif model_name == "DIA":
        return TTSModel.DIA
    elif model_name == "DIA_4BIT":
        return TTSModel.DIA_4BIT
    elif model_name == "CSM":
        return TTSModel.CSM
    elif model_name == "CHATTERBOX":
        return TTSModel.CHATTERBOX
    return TTSModel.KOKORO


def _load_defaults_data() -> dict:
    """Load the built-in defaults/voices.yaml as a dict."""
    defaults = importlib.resources.files("audiobook_tts.defaults")
    resource = defaults.joinpath("voices.yaml")
    text = resource.read_text(encoding="utf-8")
    return yaml.safe_load(text) or {}


def _build_config_from_data(data: dict, config_dir: Optional[Path] = None) -> "Config":
    """
    Build a Config instance from a raw YAML data dict.

    Args:
        data: Parsed YAML data
        config_dir: Directory to resolve relative ref_audio paths against.
                    If None, ref_audio paths are left as-is.

    Returns:
        Config instance
    """
    voices = {}
    for name, voice_data in data.get("voices", {}).items():
        model = _parse_model(voice_data.get("model", "kokoro"))

        ref_audio = voice_data.get("ref_audio")
        if ref_audio and config_dir:
            ref_path = Path(ref_audio)
            if not ref_path.is_absolute():
                ref_audio = str(config_dir / ref_path)

        voices[name] = VoiceProfile(
            name=name,
            model=model,
            voice_preset=voice_data.get("voice_preset", "af_bella"),
            speed=voice_data.get("speed", 1.0),
            lang_code=voice_data.get("lang_code", "a"),
            description=voice_data.get("description", ""),
            ref_audio=ref_audio,
            exaggeration=voice_data.get("exaggeration", 0.5),
            cfg_weight=voice_data.get("cfg_weight", 0.5),
            temperature=voice_data.get("temperature", 0.8),
        )

    audio_data = data.get("audio", {})
    audio = AudioSettings(
        sample_rate=audio_data.get("sample_rate", 24000),
        output_format=audio_data.get("output_format", "wav"),
        target_lufs=audio_data.get("target_lufs", -20.0),
        true_peak=audio_data.get("true_peak", -3.0),
        noise_floor=audio_data.get("noise_floor", -60.0),
        mp3_bitrate=audio_data.get("mp3_bitrate", "192k"),
    )

    proc_data = data.get("processing", {})
    processing = ProcessingSettings(
        max_chunk_chars=proc_data.get("max_chunk_chars", 400),
        sentence_overlap=proc_data.get("sentence_overlap", 0),
        crossfade_ms=proc_data.get("crossfade_ms", 50),
        silence_padding_ms=proc_data.get("silence_padding_ms", 500),
        batch_size=proc_data.get("batch_size", 10),
        scene_break_pause_ms=proc_data.get("scene_break_pause_ms", 2500),
        paragraph_pause_ms=proc_data.get("paragraph_pause_ms", 400),
    )

    output_dir = Path(data.get("output_dir", "./output"))
    cache_dir = Path(data.get("cache_dir", "./cache"))

    pov_voice_mapping = data.get("pov_voice_mapping", {})

    announce_data = data.get("chapter_announcement", {})
    chapter_announcement = ChapterAnnouncementSettings(
        enabled=announce_data.get("enabled", False),
        format_string=announce_data.get(
            "format_string", "Chapter {number}: {title}"
        ),
        pause_after_ms=announce_data.get("pause_after_ms", 1000),
    )

    return Config(
        voices=voices,
        audio=audio,
        processing=processing,
        output_dir=output_dir,
        cache_dir=cache_dir,
        pov_voice_mapping=pov_voice_mapping,
        chapter_announcement=chapter_announcement,
    )


@dataclass
class Config:
    """Main configuration container."""

    voices: dict[str, VoiceProfile] = field(default_factory=dict)
    audio: AudioSettings = field(default_factory=AudioSettings)
    processing: ProcessingSettings = field(default_factory=ProcessingSettings)
    output_dir: Path = field(default_factory=lambda: Path("./output"))
    cache_dir: Path = field(default_factory=lambda: Path("./cache"))
    pov_voice_mapping: dict[str, str] = field(default_factory=dict)
    chapter_announcement: ChapterAnnouncementSettings = field(
        default_factory=ChapterAnnouncementSettings
    )

    @classmethod
    def load(cls, config_path: Path) -> "Config":
        """Load configuration from a single YAML file.

        Args:
            config_path: Path to the YAML config file.
                         ref_audio paths are resolved relative to
                         the config file's parent directory.
        """
        with open(config_path) as f:
            data = yaml.safe_load(f)

        config_dir = config_path.resolve().parent
        return _build_config_from_data(data, config_dir=config_dir)

    @classmethod
    def load_merged(cls, project_config_path: Optional[Path] = None) -> "Config":
        """
        Load configuration with layered merge: defaults + project overrides.

        1. Loads the built-in defaults/voices.yaml from the package.
        2. If project_config_path is given and exists, deep-merges its
           contents on top (project voices ADD to defaults, scalars override).
        3. Resolves ref_audio paths relative to the project config file's
           directory (not CWD).

        Args:
            project_config_path: Optional path to a project voices.yaml.
                                 If None, returns defaults only.

        Returns:
            Merged Config instance
        """
        base_data = _load_defaults_data()

        config_dir = None
        if project_config_path and project_config_path.exists():
            with open(project_config_path) as f:
                project_data = yaml.safe_load(f) or {}
            base_data = _deep_merge(base_data, project_data)
            config_dir = project_config_path.resolve().parent

        return _build_config_from_data(base_data, config_dir=config_dir)

    @classmethod
    def default(cls) -> "Config":
        """Return default configuration from built-in defaults."""
        return cls.load_merged(None)

    def get_voice(self, name: str) -> VoiceProfile:
        """Get a voice profile by name, with fallback to default."""
        return self.voices.get(name, self.voices.get("narrator_female_us"))

    def get_voice_for_pov(
        self, pov_character: Optional[str], default_voice: str = "narrator_female_us"
    ) -> VoiceProfile:
        """
        Get the voice profile for a POV character.

        Args:
            pov_character: The POV character name, or None
            default_voice: Default voice name to use if no mapping exists

        Returns:
            VoiceProfile for the character, or default voice
        """
        if pov_character is None:
            return self.get_voice(default_voice)

        voice_name = self.pov_voice_mapping.get(pov_character)
        if voice_name:
            return self.get_voice(voice_name)

        return self.get_voice(default_voice)
