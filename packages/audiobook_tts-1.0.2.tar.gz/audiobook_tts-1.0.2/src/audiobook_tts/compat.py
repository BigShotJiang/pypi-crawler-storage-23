"""Runtime compatibility patches for misaki + phonemizer + espeak-ng.

Fixes two issues that cause misaki 0.9.x to crash on import:

1. misaki calls EspeakWrapper.set_data_path() which was removed in
   phonemizer >= 3.0 (replaced by a data_path property).

2. espeakng_loader's bundled libespeak-ng.dylib has hardcoded CI runner
   paths (/Users/runner/work/...) for its data files, which don't exist
   on end-user machines. We redirect to Homebrew's espeak-ng instead.

Call ensure_espeak_compat() BEFORE any mlx_audio or misaki import.
"""

import os

_patched = False


def ensure_espeak_compat():
    """Apply espeak compatibility patches (idempotent)."""
    global _patched
    if _patched:
        return

    from phonemizer.backend.espeak.wrapper import EspeakWrapper

    # Shim: add set_data_path() method missing in phonemizer >= 3.0
    if not hasattr(EspeakWrapper, "set_data_path"):

        @staticmethod
        def _set_data_path(path):
            EspeakWrapper.data_path = path

        EspeakWrapper.set_data_path = _set_data_path

    # Redirect espeakng_loader to Homebrew paths on macOS
    # The bundled dylib references /Users/runner/work/... which doesn't exist
    import espeakng_loader

    homebrew_lib = "/opt/homebrew/lib/libespeak-ng.dylib"
    homebrew_data = "/opt/homebrew/share/espeak-ng-data"

    if os.path.exists(homebrew_lib):
        espeakng_loader.get_library_path = lambda: homebrew_lib
    if os.path.exists(homebrew_data):
        espeakng_loader.get_data_path = lambda: homebrew_data

    _patched = True
