"""
Text processing for audiobook generation.

Handles:
- Sentence-boundary chunking (preserves prosody)
- Dialogue detection and parsing
- Speaker tag insertion for Dia
- Chapter extraction
"""

import re
from dataclasses import dataclass
from enum import Enum
from typing import Optional

import nltk
from nltk.tokenize import sent_tokenize

# Download required NLTK data on first import
try:
    nltk.data.find("tokenizers/punkt_tab")
except LookupError:
    nltk.download("punkt_tab", quiet=True)


class SegmentType(Enum):
    """Type of text segment."""

    NARRATION = "narration"
    DIALOGUE = "dialogue"


@dataclass
class TextChunk:
    """A chunk of text with an optional pause after it."""

    text: str
    pause_after_ms: int = 0  # Silence to insert after this chunk


@dataclass
class TextSegment:
    """A segment of text with associated metadata."""

    text: str
    segment_type: SegmentType
    speaker: Optional[str] = None  # Character name for dialogue
    chapter: Optional[int] = None
    index: int = 0  # Position in original text


class TextProcessor:
    """
    Process manuscript text for TTS generation.

    Features:
    - Smart chunking at sentence boundaries
    - Dialogue detection via quotation marks
    - Optional: Parse speaker attributions ("said John")
    - Chapter boundary detection
    """

    # Regex patterns
    CHAPTER_PATTERN = re.compile(
        r"^(?:#\s*)?(?:chapter|ch\.?)\s*(\d+|[ivxlcdm]+)",
        re.IGNORECASE | re.MULTILINE,
    )

    # Dialogue patterns - matches quoted speech
    DIALOGUE_PATTERN = re.compile(
        r'["""]([^"""]+)["""]',  # Matches "dialogue" or "dialogue" or "dialogue"
    )

    # Attribution patterns - "said John", "John said", etc.
    ATTRIBUTION_PATTERN = re.compile(
        r"(?:said|asked|replied|whispered|shouted|exclaimed|muttered)\s+([A-Z][a-z]+)|"
        r"([A-Z][a-z]+)\s+(?:said|asked|replied|whispered|shouted|exclaimed|muttered)",
        re.IGNORECASE,
    )

    def __init__(self, max_chunk_chars: int = 400):
        """
        Initialize text processor.

        Args:
            max_chunk_chars: Maximum characters per chunk (recommended: 300-500)
        """
        self.max_chunk_chars = max_chunk_chars

    def chunk_text(self, text: str) -> list[str]:
        """
        Split text into TTS-friendly chunks at sentence boundaries.

        Args:
            text: Input text to chunk

        Returns:
            List of text chunks, each <= max_chunk_chars

        Note:
            - Never splits mid-sentence
            - Preserves paragraph breaks where possible
        """
        # Clean up the text
        text = self._clean_text(text)

        sentences = sent_tokenize(text)
        chunks = []
        current_chunk = ""

        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue

            # Check if adding this sentence exceeds limit
            potential_chunk = f"{current_chunk} {sentence}".strip()

            if len(potential_chunk) <= self.max_chunk_chars:
                current_chunk = potential_chunk
            else:
                # Save current chunk and start new one
                if current_chunk:
                    chunks.append(current_chunk)
                current_chunk = sentence

                # Handle sentences longer than max_chunk_chars
                if len(sentence) > self.max_chunk_chars:
                    # Split at clause boundaries (commas, semicolons)
                    chunks.extend(self._split_long_sentence(sentence))
                    current_chunk = ""

        # Don't forget the last chunk
        if current_chunk:
            chunks.append(current_chunk)

        return chunks

    def _clean_text(self, text: str) -> str:
        """Clean text for TTS processing."""
        # Remove markdown headers
        text = re.sub(r"^#+\s+.*$", "", text, flags=re.MULTILINE)

        # Remove horizontal rules
        text = re.sub(r"^---+$", "", text, flags=re.MULTILINE)

        # Remove scene break markers (* * *)
        text = re.sub(r"^\*\s+\*\s+\*$", "", text, flags=re.MULTILINE)

        # Remove bold/italic markers
        text = re.sub(r"\*+([^*]+)\*+", r"\1", text)
        text = re.sub(r"_+([^_]+)_+", r"\1", text)

        # Normalize whitespace
        text = re.sub(r"\n{3,}", "\n\n", text)
        text = re.sub(r" {2,}", " ", text)

        return text.strip()

    def _clean_text_preserve_structure(self, text: str) -> str:
        """Clean text but preserve scene breaks and paragraph breaks."""
        # Remove markdown headers
        text = re.sub(r"^#+\s+.*$", "", text, flags=re.MULTILINE)

        # Remove horizontal rules (but not scene breaks)
        text = re.sub(r"^---+$", "", text, flags=re.MULTILINE)

        return text.strip()

    @staticmethod
    def _clean_inline_formatting(text: str) -> str:
        """Strip bold/italic markdown markers only."""
        text = re.sub(r"\*+([^*]+)\*+", r"\1", text)
        text = re.sub(r"_+([^_]+)_+", r"\1", text)
        return text

    def _chunk_sentences(self, text: str) -> list[str]:
        """Chunk a block of text at sentence boundaries. Core logic from chunk_text()."""
        sentences = sent_tokenize(text)
        chunks = []
        current_chunk = ""

        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue

            potential_chunk = f"{current_chunk} {sentence}".strip()

            if len(potential_chunk) <= self.max_chunk_chars:
                current_chunk = potential_chunk
            else:
                if current_chunk:
                    chunks.append(current_chunk)
                current_chunk = sentence

                if len(sentence) > self.max_chunk_chars:
                    chunks.extend(self._split_long_sentence(sentence))
                    current_chunk = ""

        if current_chunk:
            chunks.append(current_chunk)

        return chunks

    def chunk_text_structured(
        self,
        text: str,
        scene_break_pause_ms: int = 2500,
        paragraph_pause_ms: int = 400,
    ) -> list[TextChunk]:
        """
        Split text into TTS chunks with structural pause annotations.

        Preserves scene breaks (* * *) and paragraph breaks as pauses
        rather than stripping them.

        Args:
            text: Input text to chunk
            scene_break_pause_ms: Silence after scene breaks (ms)
            paragraph_pause_ms: Silence between paragraphs (ms)

        Returns:
            List of TextChunk objects with pause_after_ms set
        """
        # Clean headers/rules but keep structure
        text = self._clean_text_preserve_structure(text)

        # Split on scene breaks
        sections = re.split(r"^\*\s+\*\s+\*$", text, flags=re.MULTILINE)

        all_chunks: list[TextChunk] = []

        for section_idx, section in enumerate(sections):
            section = section.strip()
            if not section:
                continue

            # Split section into paragraphs
            paragraphs = re.split(r"\n\n+", section)

            for para_idx, paragraph in enumerate(paragraphs):
                paragraph = self._clean_inline_formatting(paragraph.strip())
                # Collapse internal newlines to spaces
                paragraph = re.sub(r"\n", " ", paragraph)
                paragraph = re.sub(r" {2,}", " ", paragraph)

                if not paragraph:
                    continue

                # Chunk this paragraph at sentence boundaries
                sentence_chunks = self._chunk_sentences(paragraph)

                for chunk_idx, chunk_text in enumerate(sentence_chunks):
                    is_last_in_paragraph = chunk_idx == len(sentence_chunks) - 1
                    is_last_in_section = is_last_in_paragraph and para_idx == len(paragraphs) - 1
                    is_not_last_section = section_idx < len(sections) - 1

                    # Determine pause
                    if is_last_in_section and is_not_last_section:
                        pause = scene_break_pause_ms
                    elif is_last_in_paragraph:
                        pause = paragraph_pause_ms
                    else:
                        pause = 0

                    all_chunks.append(TextChunk(text=chunk_text, pause_after_ms=pause))

        return all_chunks

    @staticmethod
    def prepare_for_chatterbox(text: str) -> str:
        """
        Pre-process text for Chatterbox TTS to preserve prosody cues.

        Chatterbox's punc_norm() converts em dashes to hyphens and ellipses
        to commas, destroying pause cues. This converts them to punctuation
        that produces better prosody through the model.

        Args:
            text: Input text

        Returns:
            Text with prosody-safe punctuation substitutions
        """
        # Em dashes → comma (produces natural pause)
        text = text.replace(" — ", ", ")

        # Ellipses at end of sentence → period
        text = re.sub(r"\.\.\.\s*$", ".", text)
        text = re.sub(r'\.\.\.(["\u201d]?\s*$)', r'.\1', text)

        # Ellipses mid-sentence → comma
        text = text.replace("...", ", ")

        return text

    def _split_long_sentence(self, sentence: str) -> list[str]:
        """Split a long sentence at clause boundaries."""
        # Split at commas, semicolons, or dashes
        parts = re.split(r"([,;—–-]\s*)", sentence)

        chunks = []
        current = ""

        for part in parts:
            if len(current) + len(part) <= self.max_chunk_chars:
                current += part
            else:
                if current.strip():
                    chunks.append(current.strip())
                current = part

        if current.strip():
            chunks.append(current.strip())

        return chunks

    def detect_dialogue(self, text: str) -> list[TextSegment]:
        """
        Parse text into narration and dialogue segments.

        Args:
            text: Input text with quoted dialogue

        Returns:
            List of TextSegment objects tagged as NARRATION or DIALOGUE
        """
        segments = []
        last_end = 0
        index = 0

        for match in self.DIALOGUE_PATTERN.finditer(text):
            # Add narration before this dialogue
            narration = text[last_end : match.start()].strip()
            if narration:
                segments.append(
                    TextSegment(
                        text=narration,
                        segment_type=SegmentType.NARRATION,
                        index=index,
                    )
                )
                index += 1

            # Add the dialogue
            dialogue_text = match.group(1).strip()

            # Try to find speaker attribution
            speaker = self._extract_speaker(text, match.start(), match.end())

            segments.append(
                TextSegment(
                    text=dialogue_text,
                    segment_type=SegmentType.DIALOGUE,
                    speaker=speaker,
                    index=index,
                )
            )
            index += 1

            last_end = match.end()

        # Add remaining narration
        remaining = text[last_end:].strip()
        if remaining:
            segments.append(
                TextSegment(
                    text=remaining,
                    segment_type=SegmentType.NARRATION,
                    index=index,
                )
            )

        return segments

    def _extract_speaker(
        self, text: str, dial_start: int, dial_end: int
    ) -> Optional[str]:
        """Extract speaker name from attribution near dialogue."""
        # Look in a window around the dialogue
        window_start = max(0, dial_start - 50)
        window_end = min(len(text), dial_end + 50)
        window = text[window_start:window_end]

        match = self.ATTRIBUTION_PATTERN.search(window)
        if match:
            return match.group(1) or match.group(2)
        return None

    def format_for_dia(
        self,
        segments: list[TextSegment],
        speaker_map: Optional[dict[str, str]] = None,
    ) -> str:
        """
        Convert segments to Dia-compatible format with speaker tags.

        Args:
            segments: List of TextSegment objects
            speaker_map: Optional mapping of character names to speaker tags
                        e.g., {"John": "S1", "Mary": "S2"}

        Returns:
            Text formatted with [S1], [S2] tags for Dia

        Example output:
            "[S1] The door creaked open. [S2] Who's there? (gasps) [S1] It's just me."
        """
        if speaker_map is None:
            speaker_map = {}

        # Auto-assign speakers if not mapped
        current_speaker_num = 1
        speaker_assignments = {}

        formatted_parts = []

        for segment in segments:
            if segment.segment_type == SegmentType.DIALOGUE:
                # Determine speaker tag
                if segment.speaker and segment.speaker in speaker_map:
                    tag = speaker_map[segment.speaker]
                elif segment.speaker:
                    if segment.speaker not in speaker_assignments:
                        speaker_assignments[segment.speaker] = f"S{current_speaker_num}"
                        current_speaker_num = min(
                            current_speaker_num + 1, 2
                        )  # Dia supports S1, S2
                    tag = speaker_assignments[segment.speaker]
                else:
                    tag = f"S{(len(formatted_parts) % 2) + 1}"  # Alternate

                formatted_parts.append(f"[{tag}] {segment.text}")
            else:
                # Narration - assign to S1 (narrator)
                formatted_parts.append(f"[S1] {segment.text}")

        return " ".join(formatted_parts)

    # Pattern for compiled manuscript headers: # Name — Title (with optional title)
    COMPILED_CHAPTER_PATTERN = re.compile(
        r"^#\s+(.+?)\s+—\s+(.+)$", re.MULTILINE
    )
    # Broader pattern to also catch bare headers like "# Cassieth"
    COMPILED_CHAPTER_PATTERN_BARE = re.compile(
        r"^#\s+([A-Z][a-zA-Z\s]+?)(?:\s+—\s+(.+))?$", re.MULTILINE
    )

    def extract_chapters(self, text: str) -> list[tuple[int, str, str]]:
        """
        Split text into chapters.

        Supports two formats:
        - Standard: # Chapter X: Title
        - Compiled: # CharacterName — Chapter Title

        Args:
            text: Full manuscript text

        Returns:
            List of (chapter_number, chapter_title, chapter_text) tuples.
            For compiled format, title is "CharacterName — Chapter Title".
        """
        # Pattern for markdown chapter headers: # Chapter X: Title
        chapter_header_pattern = re.compile(
            r"^#\s+Chapter\s+(\d+)(?::\s*(.+))?$", re.IGNORECASE | re.MULTILINE
        )

        # Try standard "# Chapter X: Title" format first
        matches = list(chapter_header_pattern.finditer(text))

        if matches:
            return self._extract_numbered_chapters(text, matches)

        # Try compiled manuscript format: # Name — Title
        compiled_matches = list(self.COMPILED_CHAPTER_PATTERN.finditer(text))

        if compiled_matches:
            # Use the broader pattern to also catch bare headers (e.g., "# Cassieth")
            all_matches = list(self.COMPILED_CHAPTER_PATTERN_BARE.finditer(text))
            return self._extract_compiled_chapters(text, all_matches)

        # Try simpler chapter pattern
        matches = list(self.CHAPTER_PATTERN.finditer(text))
        if matches:
            return self._extract_numbered_chapters(text, matches)

        # No chapter markers - return as single chapter
        return [(1, "Chapter 1", text)]

    def _extract_numbered_chapters(
        self, text: str, matches: list[re.Match]
    ) -> list[tuple[int, str, str]]:
        """Extract chapters from numbered header matches."""
        chapters = []

        for i, match in enumerate(matches):
            chapter_num = self._parse_chapter_number(match.group(1))

            # Try to get title if available
            title = match.group(2) if match.lastindex >= 2 and match.group(2) else None
            if not title:
                title = f"Chapter {chapter_num}"

            # Get text from this chapter to the next (or end)
            start = match.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)

            chapter_text = text[start:end].strip()
            if chapter_text:
                chapters.append((chapter_num, title.strip(), chapter_text))

        return chapters

    def _extract_compiled_chapters(
        self, text: str, matches: list[re.Match]
    ) -> list[tuple[int, str, str]]:
        """Extract chapters from compiled manuscript format (# Name — Title or # Name)."""
        chapters = []

        for i, match in enumerate(matches):
            chapter_num = i + 1
            character_name = match.group(1).strip()
            chapter_title = match.group(2).strip() if match.group(2) else character_name
            title = (
                f"{character_name} — {chapter_title}"
                if match.group(2)
                else character_name
            )

            # Get text from this chapter to the next (or end)
            start = match.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)

            chapter_text = text[start:end].strip()
            if chapter_text:
                chapters.append((chapter_num, title, chapter_text))

        return chapters

    def _parse_chapter_number(self, num_str: str) -> int:
        """Parse chapter number from string (handles Roman numerals)."""
        try:
            return int(num_str)
        except ValueError:
            # Try Roman numeral conversion
            roman_map = {
                "i": 1,
                "v": 5,
                "x": 10,
                "l": 50,
                "c": 100,
                "d": 500,
                "m": 1000,
            }
            num_str = num_str.lower()
            result = 0
            prev = 0
            for char in reversed(num_str):
                val = roman_map.get(char, 0)
                if val < prev:
                    result -= val
                else:
                    result += val
                prev = val
            return result if result > 0 else 1
