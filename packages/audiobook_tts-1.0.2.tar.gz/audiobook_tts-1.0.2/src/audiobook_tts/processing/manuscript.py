"""
Manuscript processing for audiobook generation.

Handles reading manuscript files and tracking progress.
"""

import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional


def extract_pov_from_text(text: str) -> Optional[str]:
    """
    Extract POV character name from chapter text.

    Looks for the pattern **POV**: CharacterName in the text.

    Args:
        text: Chapter text to search

    Returns:
        Character name if found, None otherwise
    """
    # Match **POV**: followed by character name (up to newline)
    match = re.search(r"\*\*POV\*\*:\s*(.+?)(?:\n|$)", text)
    if match:
        return match.group(1).strip()
    return None


def extract_pov_from_title(title: str) -> Optional[str]:
    """
    Extract POV character name from a compiled manuscript title.

    Handles "CharacterName — Chapter Title" and bare "CharacterName" formats.

    Args:
        title: Chapter title string

    Returns:
        Character name if found, None otherwise
    """
    match = re.match(r"^(.+?)\s+—\s+", title)
    if match:
        return match.group(1).strip()
    # Bare name (no em dash title) — return the whole title as the character name
    if re.match(r"^[A-Z][a-zA-Z\s]+$", title.strip()):
        return title.strip()
    return None


@dataclass
class Chapter:
    """Represents a chapter in the manuscript."""

    number: int
    title: str
    text: str
    source_file: Optional[Path] = None
    word_count: int = 0
    estimated_duration_minutes: float = 0.0
    pov_character: Optional[str] = None

    def __post_init__(self):
        """Calculate word count, estimated duration, and extract POV."""
        self.word_count = len(self.text.split())
        # Average speaking rate is ~150 words per minute
        self.estimated_duration_minutes = self.word_count / 150
        # Extract POV character if not already set
        if self.pov_character is None:
            self.pov_character = extract_pov_from_text(self.text)

    def get_clean_title(self) -> str:
        """
        Get the chapter title without the "Chapter X:" prefix.

        Returns:
            Clean title string without chapter prefix
        """
        # Match "Chapter X:" or "Chapter X." prefix (with optional quotes around title)
        match = re.match(
            r'^Chapter\s+\d+\s*[:.]\s*(.+)$',
            self.title,
            re.IGNORECASE
        )
        if match:
            return match.group(1).strip()
        return self.title

    def get_announcement_text(
        self, format_string: str = "Chapter {number}: {title}"
    ) -> str:
        """
        Get the text to announce for this chapter.

        Args:
            format_string: Format string with {number} and {title} placeholders

        Returns:
            Formatted announcement text
        """
        clean_title = self.get_clean_title()
        return format_string.format(number=self.number, title=clean_title)


@dataclass
class GenerationProgress:
    """Tracks progress of audiobook generation."""

    book_title: str
    total_chapters: int
    completed_chapters: list[int] = field(default_factory=list)
    current_chapter: Optional[int] = None
    current_chunk: int = 0
    total_chunks: int = 0
    started_at: Optional[str] = None
    last_updated: Optional[str] = None
    output_files: dict[int, str] = field(default_factory=dict)

    def save(self, path: Path) -> None:
        """Save progress to JSON file."""
        self.last_updated = datetime.now().isoformat()
        with open(path, "w") as f:
            json.dump(
                {
                    "book_title": self.book_title,
                    "total_chapters": self.total_chapters,
                    "completed_chapters": self.completed_chapters,
                    "current_chapter": self.current_chapter,
                    "current_chunk": self.current_chunk,
                    "total_chunks": self.total_chunks,
                    "started_at": self.started_at,
                    "last_updated": self.last_updated,
                    "output_files": self.output_files,
                },
                f,
                indent=2,
            )

    @classmethod
    def load(cls, path: Path) -> "GenerationProgress":
        """Load progress from JSON file."""
        with open(path) as f:
            data = json.load(f)
        return cls(**data)

    @property
    def is_complete(self) -> bool:
        """Check if all chapters are completed."""
        return len(self.completed_chapters) >= self.total_chapters


class ManuscriptProcessor:
    """
    Process manuscript files for audiobook generation.

    Supports:
    - Single compiled manuscript file
    - Directory of chapter files
    - Progress tracking and resume
    """

    def __init__(self, cache_dir: Optional[Path] = None):
        """
        Initialize manuscript processor.

        Args:
            cache_dir: Directory for storing progress files
        """
        self.cache_dir = cache_dir or Path("./cache")
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def load_compiled_manuscript(self, path: Path) -> list[Chapter]:
        """
        Load a compiled manuscript file (single markdown with all chapters).

        Args:
            path: Path to the compiled manuscript file

        Returns:
            List of Chapter objects
        """
        from .text_processor import TextProcessor

        text = path.read_text()
        processor = TextProcessor()

        chapters = []
        for num, title, chapter_text in processor.extract_chapters(text):
            chapter = Chapter(
                number=num,
                title=title,
                text=chapter_text,
                source_file=path,
            )
            # If POV wasn't found in text, try extracting from title
            # (compiled manuscripts use "Name — Title" format)
            if chapter.pov_character is None:
                chapter.pov_character = extract_pov_from_title(title)
            chapters.append(chapter)

        return chapters

    def load_chapter_directory(self, directory: Path) -> list[Chapter]:
        """
        Load chapters from a directory of markdown files.

        Args:
            directory: Path to directory containing chapter-XX.md files

        Returns:
            List of Chapter objects, sorted by chapter number
        """
        chapters = []
        chapter_pattern = re.compile(r"chapter-(\d+)\.md", re.IGNORECASE)

        for file_path in sorted(directory.glob("*.md")):
            match = chapter_pattern.match(file_path.name)
            if not match:
                continue

            chapter_num = int(match.group(1))
            text = file_path.read_text()

            # Try to extract title from first header
            title_match = re.search(r"^#\s+(.+)$", text, re.MULTILINE)
            title = title_match.group(1) if title_match else f"Chapter {chapter_num}"

            # Store original text for POV extraction before cleaning
            original_text = text

            # Clean up the text (remove headers, metadata)
            clean_text = self._clean_chapter_text(text)

            # Create chapter - POV will be extracted from original text
            chapter = Chapter(
                number=chapter_num,
                title=title,
                text=clean_text,
                source_file=file_path,
            )
            # Extract POV from original text (before metadata was stripped)
            chapter.pov_character = extract_pov_from_text(original_text)

            chapters.append(chapter)

        return sorted(chapters, key=lambda c: c.number)

    def _clean_chapter_text(self, text: str) -> str:
        """Remove metadata and headers from chapter text."""
        lines = text.split("\n")
        clean_lines = []
        in_metadata = False
        skip_next_blank = False

        for line in lines:
            # Skip YAML front matter
            if line.strip() == "---":
                in_metadata = not in_metadata
                continue

            if in_metadata:
                continue

            # Skip chapter header (first h1)
            if line.startswith("# Chapter") or line.startswith("# chapter"):
                skip_next_blank = True
                continue

            # Skip metadata lines
            if line.startswith("**POV**:") or line.startswith("**Timeline**:"):
                continue
            if line.startswith("**Location**:") or line.startswith("## Scene Goals"):
                continue

            # Skip scene goals list
            if line.startswith("- ["):
                continue

            if skip_next_blank and not line.strip():
                skip_next_blank = False
                continue

            clean_lines.append(line)

        return "\n".join(clean_lines).strip()

    def get_progress_file(self, book_name: str) -> Path:
        """Get path to progress file for a book."""
        safe_name = "".join(c if c.isalnum() else "_" for c in book_name)
        return self.cache_dir / f"{safe_name}_progress.json"

    def create_progress(
        self, book_title: str, chapters: list[Chapter]
    ) -> GenerationProgress:
        """Create a new progress tracker for a book."""
        return GenerationProgress(
            book_title=book_title,
            total_chapters=len(chapters),
            started_at=datetime.now().isoformat(),
        )

    def load_or_create_progress(
        self, book_title: str, chapters: list[Chapter]
    ) -> GenerationProgress:
        """Load existing progress or create new."""
        progress_file = self.get_progress_file(book_title)

        if progress_file.exists():
            return GenerationProgress.load(progress_file)

        return self.create_progress(book_title, chapters)

    def estimate_total_duration(self, chapters: list[Chapter]) -> float:
        """
        Estimate total audiobook duration in minutes.

        Args:
            chapters: List of chapters

        Returns:
            Estimated duration in minutes
        """
        return sum(c.estimated_duration_minutes for c in chapters)
