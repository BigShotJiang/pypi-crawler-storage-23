"""
Audio post-processing for audiobook generation.

Handles:
- Segment concatenation with crossfade
- Audio normalization (ACX compliance)
- Format conversion (WAV, MP3, FLAC)
- Silence padding
"""

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import soundfile as sf


class AudioConversionError(Exception):
    """Exception raised when audio conversion fails."""

    pass


def convert_wav_to_mp3(
    input_path: Path,
    output_path: Path,
    bitrate: str = "192k",
) -> Path:
    """
    Convert WAV file to MP3 using ffmpeg.

    Args:
        input_path: Path to input WAV file
        output_path: Path for output MP3 file
        bitrate: MP3 bitrate (default: 192k for ACX compliance)

    Returns:
        Path to converted MP3 file

    Raises:
        AudioConversionError: If ffmpeg conversion fails
    """
    cmd = [
        "ffmpeg",
        "-y",  # Overwrite output
        "-i",
        str(input_path),
        "-codec:a",
        "libmp3lame",
        "-b:a",
        bitrate,
        "-ar",
        "44100",  # ACX requires 44.1kHz
        str(output_path),
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        raise AudioConversionError(
            f"ffmpeg conversion failed: {result.stderr}"
        )

    return output_path


@dataclass
class AudioOutputSettings:
    """Settings for audio output."""

    sample_rate: int = 24000
    channels: int = 1  # Mono for audiobooks
    format: str = "wav"
    # ACX compliance
    target_lufs: float = -20.0
    true_peak: float = -3.0
    mp3_bitrate: str = "192k"


class AudioProcessor:
    """
    Process and normalize audio for audiobook distribution.

    ACX/Audible Requirements:
    - Sample rate: 44.1 kHz (MP3) - we upsample from 24kHz
    - Bit rate: 192 kbps CBR for MP3
    - Loudness: -23 to -18 dB RMS (we target -20 dB / LUFS)
    - Peak: <= -3 dB true peak
    - Noise floor: <= -60 dB
    - Format: MP3 or M4A
    """

    def __init__(self, settings: Optional[AudioOutputSettings] = None):
        self.settings = settings or AudioOutputSettings()

    def concatenate_segments(
        self,
        audio_segments: list[np.ndarray],
        crossfade_ms: int = 50,
        sample_rate: int = 24000,
    ) -> np.ndarray:
        """
        Concatenate audio segments with crossfade.

        Args:
            audio_segments: List of audio arrays
            crossfade_ms: Crossfade duration in milliseconds
            sample_rate: Audio sample rate

        Returns:
            Single concatenated audio array
        """
        if not audio_segments:
            return np.array([], dtype=np.float32)

        if len(audio_segments) == 1:
            return audio_segments[0]

        crossfade_samples = int(crossfade_ms * sample_rate / 1000)

        # Start with first segment
        result = audio_segments[0].astype(np.float32)

        for segment in audio_segments[1:]:
            segment = segment.astype(np.float32)

            if (
                crossfade_samples > 0
                and len(result) > crossfade_samples
                and len(segment) > crossfade_samples
            ):
                # Create crossfade
                fade_out = np.linspace(1, 0, crossfade_samples, dtype=np.float32)
                fade_in = np.linspace(0, 1, crossfade_samples, dtype=np.float32)

                # Apply fades
                result[-crossfade_samples:] *= fade_out
                segment_copy = segment.copy()
                segment_copy[:crossfade_samples] *= fade_in

                # Overlap and add
                result[-crossfade_samples:] += segment_copy[:crossfade_samples]
                result = np.concatenate([result, segment_copy[crossfade_samples:]])
            else:
                # No crossfade, just concatenate
                result = np.concatenate([result, segment])

        return result

    def add_silence_padding(
        self,
        audio: np.ndarray,
        start_ms: int = 500,
        end_ms: int = 500,
        sample_rate: int = 24000,
    ) -> np.ndarray:
        """
        Add silence padding to start and end (ACX requirement).

        Args:
            audio: Input audio array
            start_ms: Silence at start in milliseconds
            end_ms: Silence at end in milliseconds
            sample_rate: Audio sample rate

        Returns:
            Audio with silence padding
        """
        start_samples = int(start_ms * sample_rate / 1000)
        end_samples = int(end_ms * sample_rate / 1000)

        start_silence = np.zeros(start_samples, dtype=audio.dtype)
        end_silence = np.zeros(end_samples, dtype=audio.dtype)

        return np.concatenate([start_silence, audio, end_silence])

    def normalize_audio(
        self,
        input_path: Path,
        output_path: Path,
        target_lufs: Optional[float] = None,
        true_peak: Optional[float] = None,
    ) -> Path:
        """
        Normalize audio to ACX specifications using ffmpeg-normalize.

        Args:
            input_path: Path to input audio file
            output_path: Path for normalized output
            target_lufs: Target loudness in LUFS (default: -20)
            true_peak: Maximum true peak in dB (default: -3)

        Returns:
            Path to normalized audio file
        """
        target_lufs = target_lufs or self.settings.target_lufs
        true_peak = true_peak or self.settings.true_peak

        cmd = [
            "ffmpeg-normalize",
            str(input_path),
            "-o",
            str(output_path),
            "-t",
            str(target_lufs),
            "--tp",
            str(true_peak),
            "-ar",
            "44100",  # ACX requires 44.1kHz for MP3
            "-f",  # Force overwrite
        ]

        # Add format-specific options
        if output_path.suffix.lower() == ".mp3":
            cmd.extend(["-c:a", "libmp3lame", "-b:a", self.settings.mp3_bitrate])
        elif output_path.suffix.lower() == ".m4a":
            cmd.extend(["-c:a", "aac", "-b:a", "256k"])

        subprocess.run(cmd, check=True, capture_output=True)

        return output_path

    def save_audio(
        self,
        audio: np.ndarray,
        output_path: Path,
        sample_rate: int = 24000,
        normalize: bool = True,
    ) -> Path:
        """
        Save audio array to file with optional normalization.

        Args:
            audio: Audio data as numpy array
            output_path: Output file path
            sample_rate: Audio sample rate
            normalize: Whether to apply ACX normalization

        Returns:
            Path to saved (and optionally normalized) file
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Save raw audio first
        if normalize:
            temp_path = output_path.with_suffix(".temp.wav")
            sf.write(temp_path, audio, sample_rate)

            # Normalize to final output
            self.normalize_audio(temp_path, output_path)

            # Clean up temp file
            temp_path.unlink(missing_ok=True)
        else:
            sf.write(output_path, audio, sample_rate)

        return output_path

    def save_audio_raw(
        self,
        audio: np.ndarray,
        output_path: Path,
        sample_rate: int = 24000,
    ) -> Path:
        """
        Save audio without normalization (for intermediate files).

        Args:
            audio: Audio data as numpy array
            output_path: Output file path
            sample_rate: Audio sample rate

        Returns:
            Path to saved file
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        sf.write(output_path, audio, sample_rate)
        return output_path

    def convert_to_mp3(
        self,
        input_path: Path,
        output_path: Optional[Path] = None,
        bitrate: Optional[str] = None,
    ) -> Path:
        """
        Convert audio file to MP3 format.

        Args:
            input_path: Path to input audio file
            output_path: Path for output MP3 (default: same as input with .mp3 extension)
            bitrate: MP3 bitrate (default: from settings)

        Returns:
            Path to converted MP3 file

        Raises:
            AudioConversionError: If conversion fails
        """
        input_path = Path(input_path)
        output_path = output_path or input_path.with_suffix(".mp3")
        bitrate = bitrate or self.settings.mp3_bitrate

        return convert_wav_to_mp3(input_path, output_path, bitrate)

    def convert_format(
        self,
        input_path: Path,
        output_format: str,
    ) -> Path:
        """
        Convert audio to different format.

        Args:
            input_path: Path to input file
            output_format: Target format (mp3, wav, flac, m4a)

        Returns:
            Path to converted file
        """
        from pydub import AudioSegment as PydubSegment

        output_path = input_path.with_suffix(f".{output_format}")

        audio = PydubSegment.from_file(str(input_path))

        export_params = {}
        if output_format == "mp3":
            export_params = {"bitrate": self.settings.mp3_bitrate}

        audio.export(str(output_path), format=output_format, **export_params)

        return output_path

    def get_duration(self, audio: np.ndarray, sample_rate: int = 24000) -> float:
        """Get duration of audio in seconds."""
        return len(audio) / sample_rate

    def calculate_stats(
        self, audio: np.ndarray
    ) -> dict[str, float]:
        """
        Calculate audio statistics.

        Returns:
            Dictionary with peak, rms, and duration
        """
        peak = np.max(np.abs(audio))
        rms = np.sqrt(np.mean(audio**2))
        peak_db = 20 * np.log10(peak) if peak > 0 else -100
        rms_db = 20 * np.log10(rms) if rms > 0 else -100

        return {
            "peak": float(peak),
            "peak_db": float(peak_db),
            "rms": float(rms),
            "rms_db": float(rms_db),
            "samples": len(audio),
        }
