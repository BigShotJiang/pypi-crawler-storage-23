"""
Initialize a project directory for audiobook generation.

Creates the .audiobook/ directory structure with template configuration files.

Usage:
    audiobook-init
    audiobook-init --dir .audiobook
    audiobook-init --force
"""

import argparse
import importlib.resources
import shutil
import sys
from pathlib import Path


def init_project(target_dir: Path, force: bool = False) -> bool:
    """
    Initialize a project directory with audiobook configuration.

    Creates:
        target_dir/voices.yaml      - Voice profiles (from template)
        target_dir/series.yaml      - Series/book config (from template)
        target_dir/voice-refs/      - Directory for reference clips

    Args:
        target_dir: Directory to create (default: .audiobook/)
        force: Overwrite existing files if True

    Returns:
        True on success, False on failure
    """
    from rich.console import Console

    console = Console()

    if target_dir.exists() and not force:
        has_files = any(target_dir.iterdir())
        if has_files:
            console.print(
                f"[yellow]Directory {target_dir} already exists and is not empty.[/yellow]"
            )
            console.print("[yellow]Use --force to overwrite existing files.[/yellow]")
            return False

    target_dir.mkdir(parents=True, exist_ok=True)

    # Copy template files from package defaults
    defaults = importlib.resources.files("audiobook_tts.defaults")

    templates = {
        "voices.yaml.template": "voices.yaml",
        "series.yaml.template": "series.yaml",
    }

    for src_name, dst_name in templates.items():
        dst_path = target_dir / dst_name
        if dst_path.exists() and not force:
            console.print(f"  [dim]Skipping {dst_name} (already exists)[/dim]")
            continue

        src_resource = defaults.joinpath(src_name)
        content = src_resource.read_text(encoding="utf-8")
        dst_path.write_text(content, encoding="utf-8")
        console.print(f"  [green]Created {dst_name}[/green]")

    # Create voice-refs directory
    voice_refs_dir = target_dir / "voice-refs"
    voice_refs_dir.mkdir(exist_ok=True)
    console.print(f"  [green]Created voice-refs/[/green]")

    # Print next steps
    console.print(f"\n[bold green]Initialized audiobook project in {target_dir}/[/bold green]\n")
    console.print("[bold]Next steps:[/bold]")
    console.print(f"  1. Edit [cyan]{target_dir}/voices.yaml[/cyan] to define your voice profiles")
    console.print(f"  2. Edit [cyan]{target_dir}/series.yaml[/cyan] to map books to voices")
    console.print(
        f"  3. Run [cyan]audiobook-voice-ref --all --output-dir {target_dir}/voice-refs[/cyan] "
        "to generate Chatterbox reference clips"
    )
    console.print(
        "  4. Run [cyan]audiobook-generate --input your-manuscript.md "
        f"--series-config {target_dir}/series.yaml[/cyan]"
    )

    return True


def main():
    """Main entry point for audiobook-init CLI."""
    parser = argparse.ArgumentParser(
        description="Initialize a project directory for audiobook generation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Initialize with default directory (.audiobook/)
    audiobook-init

    # Initialize in a custom directory
    audiobook-init --dir my-audiobook-config

    # Overwrite existing files
    audiobook-init --force
        """,
    )

    parser.add_argument(
        "--dir",
        type=Path,
        default=Path(".audiobook"),
        help="Target directory (default: .audiobook)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite existing files",
    )

    args = parser.parse_args()

    success = init_project(args.dir, force=args.force)
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
