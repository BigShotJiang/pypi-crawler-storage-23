"""
FastAPI routes for audiobook TTS service.

Endpoints:
- POST /generate          - Generate audio from text
- POST /generate/chapter  - Generate full chapter audio
- POST /generate/dialogue - Generate multi-speaker dialogue
- GET  /voices            - List available voices
- GET  /status/{job_id}   - Check generation status
- GET  /health            - Health check
"""

from fastapi import APIRouter, BackgroundTasks, HTTPException
from fastapi.responses import FileResponse
from pathlib import Path
from typing import Optional
from uuid import uuid4

from .schemas import (
    ChapterRequest,
    DialogueRequest,
    GenerateRequest,
    GenerateResponse,
    JobStatus,
    VoiceListResponse,
)
from ..models.tts_engine import DiaEngine, KokoroEngine
from ..models.model_manager import ModelManager
from ..processing.text_processor import TextProcessor
from ..processing.audio_processor import AudioProcessor
from ..config import Config

router = APIRouter()

# Global instances (initialized on startup)
config: Optional[Config] = None
model_manager: Optional[ModelManager] = None
text_processor: Optional[TextProcessor] = None
audio_processor: Optional[AudioProcessor] = None

# Job tracking
jobs: dict[str, JobStatus] = {}


def init_engines(app_config: Config) -> None:
    """Initialize engines on startup."""
    global config, model_manager, text_processor, audio_processor

    config = app_config
    model_manager = ModelManager()
    text_processor = TextProcessor(max_chunk_chars=config.processing.max_chunk_chars)
    audio_processor = AudioProcessor()


@router.get("/health")
async def health_check():
    """Health check endpoint."""
    loaded = model_manager.loaded_models() if model_manager else []
    return {
        "status": "healthy",
        "models_loaded": [m.name for m in loaded],
    }


@router.get("/voices", response_model=VoiceListResponse)
async def list_voices():
    """List all available voice presets."""
    return VoiceListResponse(
        kokoro_voices=KokoroEngine.VOICES,
        dia_nonverbal_tags=DiaEngine.NONVERBAL_TAGS,
        configured_voices={
            name: {
                "model": v.model.value,
                "preset": v.voice_preset,
                "description": v.description,
            }
            for name, v in config.voices.items()
        }
        if config
        else {},
    )


@router.post("/generate", response_model=GenerateResponse)
async def generate_audio(request: GenerateRequest):
    """
    Generate audio from text using Kokoro (narration).

    For short text, returns audio directly.
    For long text, processes in chunks and concatenates.
    """
    if not config or not model_manager or not text_processor or not audio_processor:
        raise HTTPException(status_code=500, detail="Server not initialized")

    # Chunk text if needed
    chunks = text_processor.chunk_text(request.text)

    # Get voice config
    voice_config = config.get_voice(request.voice)

    # Get Kokoro engine
    kokoro = model_manager.get_kokoro()

    # Generate audio for each chunk
    audio_segments = []

    for chunk in chunks:
        for segment in kokoro.generate(
            text=chunk,
            voice=voice_config.voice_preset,
            speed=voice_config.speed,
            lang_code=voice_config.lang_code,
        ):
            audio_segments.append(segment.audio)

    # Concatenate and process
    combined = audio_processor.concatenate_segments(
        audio_segments,
        crossfade_ms=config.processing.crossfade_ms,
    )

    combined = audio_processor.add_silence_padding(
        combined,
        start_ms=config.processing.silence_padding_ms,
        end_ms=config.processing.silence_padding_ms,
    )

    # Save to file
    output_filename = f"{request.output_name or uuid4().hex}.wav"
    output_path = config.output_dir / output_filename

    audio_processor.save_audio(
        combined,
        output_path,
        normalize=request.normalize,
    )

    return GenerateResponse(
        success=True,
        output_path=str(output_path),
        duration_seconds=len(combined) / 24000,
    )


@router.post("/generate/dialogue", response_model=GenerateResponse)
async def generate_dialogue(request: DialogueRequest):
    """
    Generate multi-speaker dialogue using Dia.

    Input should use [S1], [S2] speaker tags.
    Supports non-verbal tags like (laughs), (sighs).
    """
    if not config or not model_manager or not audio_processor:
        raise HTTPException(status_code=500, detail="Server not initialized")

    # Validate speaker tags
    if "[S1]" not in request.text:
        raise HTTPException(
            status_code=400, detail="Dialogue must start with [S1] speaker tag"
        )

    # Get Dia engine
    dia = model_manager.get_dia()

    audio_segments = []

    for segment in dia.generate(text=request.text):
        audio_segments.append(segment.audio)

    combined = audio_processor.concatenate_segments(audio_segments)
    combined = audio_processor.add_silence_padding(combined)

    output_filename = f"dialogue_{request.output_name or uuid4().hex}.wav"
    output_path = config.output_dir / output_filename

    audio_processor.save_audio(combined, output_path, normalize=request.normalize)

    return GenerateResponse(
        success=True,
        output_path=str(output_path),
        duration_seconds=len(combined) / 24000,
    )


@router.post("/generate/chapter")
async def generate_chapter(
    request: ChapterRequest,
    background_tasks: BackgroundTasks,
):
    """
    Generate full chapter audio (long-running task).

    Returns job ID immediately, processes in background.
    Poll /status/{job_id} for progress.
    """
    job_id = uuid4().hex

    jobs[job_id] = JobStatus(
        job_id=job_id,
        status="queued",
        progress=0.0,
    )

    # Process in background
    background_tasks.add_task(
        _process_chapter,
        job_id,
        request,
    )

    return {"job_id": job_id, "status": "queued"}


async def _process_chapter(job_id: str, request: ChapterRequest):
    """Background task to process chapter."""
    jobs[job_id].status = "processing"

    try:
        chunks = text_processor.chunk_text(request.text)
        total_chunks = len(chunks)
        audio_segments = []

        voice_config = config.get_voice(request.voice)
        kokoro = model_manager.get_kokoro()

        for i, chunk in enumerate(chunks):
            for segment in kokoro.generate(
                text=chunk,
                voice=voice_config.voice_preset,
                speed=voice_config.speed,
                lang_code=voice_config.lang_code,
            ):
                audio_segments.append(segment.audio)

            jobs[job_id].progress = (i + 1) / total_chunks

        # Combine and save
        combined = audio_processor.concatenate_segments(audio_segments)
        combined = audio_processor.add_silence_padding(combined)

        output_filename = f"chapter_{request.chapter_number}_{job_id}.wav"
        output_path = config.output_dir / output_filename

        audio_processor.save_audio(combined, output_path, normalize=True)

        jobs[job_id].status = "completed"
        jobs[job_id].output_path = str(output_path)
        jobs[job_id].duration_seconds = len(combined) / 24000

    except Exception as e:
        jobs[job_id].status = "failed"
        jobs[job_id].error = str(e)


@router.get("/status/{job_id}")
async def get_job_status(job_id: str):
    """Get status of a generation job."""
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    return jobs[job_id]


@router.get("/download/{job_id}")
async def download_audio(job_id: str):
    """Download generated audio file."""
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")

    job = jobs[job_id]

    if job.status != "completed":
        raise HTTPException(
            status_code=400, detail=f"Job not completed: {job.status}"
        )

    if not job.output_path:
        raise HTTPException(status_code=500, detail="Output path not set")

    return FileResponse(
        job.output_path,
        media_type="audio/wav",
        filename=Path(job.output_path).name,
    )
