"""Pydantic models for API request/response validation."""

from pydantic import BaseModel, Field
from typing import Optional


class GenerateRequest(BaseModel):
    """Request for basic audio generation."""

    text: str = Field(..., description="Text to convert to speech")
    voice: str = Field(
        default="narrator_female_us", description="Voice profile name from config"
    )
    speed: float = Field(default=1.0, ge=0.5, le=2.0, description="Speech speed")
    normalize: bool = Field(default=True, description="Apply ACX normalization")
    output_name: Optional[str] = Field(
        None, description="Output filename (without extension)"
    )


class DialogueRequest(BaseModel):
    """Request for multi-speaker dialogue generation."""

    text: str = Field(
        ...,
        description="Text with [S1], [S2] speaker tags",
        examples=["[S1] Hello! [S2] Hi there. (laughs)"],
    )
    normalize: bool = Field(default=True)
    output_name: Optional[str] = None


class ChapterRequest(BaseModel):
    """Request for chapter generation."""

    text: str = Field(..., description="Full chapter text")
    chapter_number: int = Field(..., ge=1, description="Chapter number")
    voice: str = Field(default="narrator_female_us")
    normalize: bool = Field(default=True)


class GenerateResponse(BaseModel):
    """Response from generation endpoints."""

    success: bool
    output_path: str
    duration_seconds: float
    error: Optional[str] = None


class JobStatus(BaseModel):
    """Status of a background generation job."""

    job_id: str
    status: str  # queued, processing, completed, failed
    progress: float = Field(default=0.0, ge=0.0, le=1.0)
    output_path: Optional[str] = None
    duration_seconds: Optional[float] = None
    error: Optional[str] = None


class VoiceListResponse(BaseModel):
    """List of available voices."""

    kokoro_voices: dict[str, list[str]]
    dia_nonverbal_tags: list[str]
    configured_voices: dict[str, dict]
