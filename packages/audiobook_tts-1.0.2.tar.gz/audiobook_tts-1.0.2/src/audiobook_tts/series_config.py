"""
Series configuration module for audiobook TTS system.

Provides configuration management for multi-book series with:
- Book-specific voice configurations
- POV-to-voice mappings per book
- Chapter announcement settings per book
- Auto-detection of book from filename
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import yaml

from .config import ChapterAnnouncementSettings, Config


def _default_chapter_announcement() -> dict:
    """Return default chapter announcement settings as dict."""
    return {
        "enabled": False,
        "format_string": "Chapter {number}: {title}",
        "pause_after_ms": 1000,
    }


@dataclass
class BookConfig:
    """Configuration for a single book in a series."""

    book_id: str
    title: str
    default_voice: Optional[str] = None
    pov_voices: dict[str, str] = field(default_factory=dict)
    chapter_announcement: dict = field(default_factory=_default_chapter_announcement)


@dataclass
class SeriesConfig:
    """Configuration for an entire book series."""

    name: str
    default_voice: Optional[str] = None
    books: dict[str, BookConfig] = field(default_factory=dict)


def load_series_config(path: Path) -> SeriesConfig:
    """
    Load series configuration from a YAML file.

    Args:
        path: Path to the series configuration YAML file

    Returns:
        SeriesConfig instance

    Raises:
        FileNotFoundError: If the configuration file doesn't exist
    """
    if not path.exists():
        raise FileNotFoundError(f"Series configuration file not found: {path}")

    with open(path) as f:
        data = yaml.safe_load(f)

    series_data = data.get("series", {})
    books_data = data.get("books", {})

    # Parse book configurations
    books = {}
    for book_id, book_data in books_data.items():
        # Get chapter announcement settings with defaults
        announcement_data = book_data.get("chapter_announcement", {})
        chapter_announcement = {
            "enabled": announcement_data.get("enabled", False),
            "format_string": announcement_data.get(
                "format_string", "Chapter {number}: {title}"
            ),
            "pause_after_ms": announcement_data.get("pause_after_ms", 1000),
        }

        books[book_id] = BookConfig(
            book_id=book_id,
            title=book_data.get("title", book_id),
            default_voice=book_data.get("default_voice"),
            pov_voices=book_data.get("pov_voices", {}),
            chapter_announcement=chapter_announcement,
        )

    return SeriesConfig(
        name=series_data.get("name", "Unnamed Series"),
        default_voice=series_data.get("default_voice"),
        books=books,
    )


def get_book_config(series: SeriesConfig, book_id: str) -> Optional[BookConfig]:
    """
    Get book configuration by book_id, supporting partial matches.

    Args:
        series: SeriesConfig instance
        book_id: Book identifier (can be partial)

    Returns:
        BookConfig if found, None otherwise
    """
    # Try exact match first
    if book_id in series.books:
        return series.books[book_id]

    # Try partial match (case-insensitive)
    book_id_lower = book_id.lower()
    for key, book in series.books.items():
        if book_id_lower in key.lower():
            return book

    return None


def detect_book_from_filename(
    series: SeriesConfig, filepath: Path
) -> Optional[BookConfig]:
    """
    Detect which book a file belongs to based on its filename.

    Args:
        series: SeriesConfig instance
        filepath: Path to the file

    Returns:
        BookConfig if a match is found, None otherwise
    """
    filename = filepath.name.lower()

    for book_id, book in series.books.items():
        # Check if book_id appears in filename
        if book_id.lower() in filename:
            return book

        # Check for partial matches using key parts
        # e.g., "vessels-vestments" should match "2-vessels-and-vestments"
        key_parts = book_id.lower().replace("-", " ").split()
        # Check if significant parts of the book_id are in the filename
        matching_parts = sum(1 for part in key_parts if part in filename)
        # Require at least 2 matching parts or significant match ratio
        if matching_parts >= 2 or (
            len(key_parts) > 0 and matching_parts / len(key_parts) >= 0.5
        ):
            return book

    return None


def apply_book_config(
    config: Config,
    book_config: BookConfig,
    series_default_voice: Optional[str] = None,
) -> Config:
    """
    Apply book configuration to the main Config instance.

    Updates the Config with book-specific settings:
    - POV-to-voice mappings
    - Chapter announcement settings
    - Default voice (from book or series)

    Args:
        config: Main Config instance to modify
        book_config: BookConfig with book-specific settings
        series_default_voice: Optional series-level default voice

    Returns:
        The modified Config instance
    """
    # Apply POV voice mappings
    config.pov_voice_mapping = book_config.pov_voices.copy()

    # Apply chapter announcement settings
    announcement = book_config.chapter_announcement
    config.chapter_announcement = ChapterAnnouncementSettings(
        enabled=announcement.get("enabled", False),
        format_string=announcement.get("format_string", "Chapter {number}: {title}"),
        pause_after_ms=announcement.get("pause_after_ms", 1000),
    )

    return config
