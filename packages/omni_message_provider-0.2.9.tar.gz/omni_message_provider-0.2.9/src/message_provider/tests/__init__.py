"""Tests for message_provider package."""
