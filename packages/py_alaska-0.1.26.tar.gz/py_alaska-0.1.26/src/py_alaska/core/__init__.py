# Copyright (c) 2026 동일비전(Dongil Vision Korea). All Rights Reserved.
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  ALASKA v2.3 - core                                                          ║
║  Core Task Execution Framework Package                                       ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Version : 2.3.0                                                             ║
║  Date    : 2026-02-27                                                        ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Modules:                                                                    ║
║    task_manager     - Task 생명주기 관리 및 RMI 통신                        ║
║    task_signal      - Signal/Event Broker (QoS 포함)                        ║
║    task_decoration  - Task 등록 데코레이터                                   ║
║    task_error       - 에러 핸들링 및 예외 클래스                             ║
║    task_performance - 성능 메트릭 수집                                       ║
║    gconfig          - 글로벌 설정 관리 (Singleton)                          ║
║    task_log         - 중앙 로깅 시스템                                       ║
║    task_log_handler - 멀티프로세스 안전 파일 로깅                            ║
║    task_profiler    - 코드 블록 프로파일링                                   ║
║    task_banner      - 배너 출력 유틸리티                                     ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# Task Decorators & Validation
from .task_decoration import (
    rmi_run, rmi_signal, has_run_flag, get_signal_handlers,
    get_rmi_signal_forward, TaskValidator, task, rmi_task,
    _DEFAULT_RESTART_DELAY,
)

# Signal
from .task_signal import Signal, SignalBroker, SignalClient, PayloadTooLargeError, QoS, PriorityScheduler

# Task Error
from .task_error import (
    AlaskaError, TaskNotFoundError, SmBlockNotFoundError,
    RmiTimeoutError, TaskRemovedError, InjectionError,
    task_not_found_error, smblock_not_found_error, rmi_timeout_error,
    pickle_error, config_mandatory_field_error,
)

# Performance
from .task_performance import (
    MethodPerformance, TaskPerformance, SystemPerformance,
    TimingRecorder, PerformanceCollector,
)

# Task Manager
from .task_manager import TaskManager, TaskInfo, TaskRuntime, RmiClient, DirectClient

# Log
from .task_log import LogRecord, RmiLogger, LogTask

# Log Handler
from .task_log_handler import (
    SafeRotatingFileHandler, QueueFileHandler, QueueFileListener,
    create_safe_file_handler, setup_safe_logging,
)

# Config
from .gconfig import (
    gconfig, GConfig,
    ConfigError, ConfigFileNotFoundError, ConfigPathNotFoundError,
    ConfigLockTimeoutError, ConfigValidationError, ConfigParseError,
    ConfigIntegrityError, ConfigSecurityError, ConfigStaleLockError,
    ConfigMandatoryFieldError, ConfigRecoveryError,
)

# Profiler
from .task_profiler import task_profiler, TaskProfiler, LapRecord

# Banner
from .task_banner import banner

__all__ = [
    # Task Decorators
    "rmi_run", "rmi_signal", "task", "rmi_task", "has_run_flag",
    "get_signal_handlers", "get_rmi_signal_forward", "TaskValidator",
    "_DEFAULT_RESTART_DELAY",
    # Signal
    "Signal", "SignalBroker", "SignalClient", "PayloadTooLargeError", "QoS", "PriorityScheduler",
    # Error
    "AlaskaError", "TaskNotFoundError", "SmBlockNotFoundError",
    "RmiTimeoutError", "TaskRemovedError", "InjectionError",
    "task_not_found_error", "smblock_not_found_error", "rmi_timeout_error",
    "pickle_error", "config_mandatory_field_error",
    # Performance
    "MethodPerformance", "TaskPerformance", "SystemPerformance",
    "TimingRecorder", "PerformanceCollector",
    # Task Manager
    "TaskManager", "TaskInfo", "TaskRuntime", "RmiClient", "DirectClient",
    # Log
    "LogRecord", "RmiLogger", "LogTask",
    # Log Handler
    "SafeRotatingFileHandler", "QueueFileHandler", "QueueFileListener",
    "create_safe_file_handler", "setup_safe_logging",
    # Config
    "gconfig", "GConfig",
    "ConfigError", "ConfigFileNotFoundError", "ConfigPathNotFoundError",
    "ConfigLockTimeoutError", "ConfigValidationError", "ConfigParseError",
    "ConfigIntegrityError", "ConfigSecurityError", "ConfigStaleLockError",
    "ConfigMandatoryFieldError", "ConfigRecoveryError",
    # Profiler
    "task_profiler", "TaskProfiler", "LapRecord",
    # Banner
    "banner",
]
