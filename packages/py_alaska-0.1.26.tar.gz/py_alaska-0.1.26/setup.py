#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ALASKA - Multiprocess Task Management Framework

Backward compatibility setup script.
Configuration is in pyproject.toml (PEP 517/518).
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
