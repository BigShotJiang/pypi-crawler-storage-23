"""VIBE-X Layer 2: Living RAG Memory Engine.

코드베이스를 질문 가능한 지식 베이스로 전환한다.
"""
