"""VIBE-X Layer 3: Multi-Agent Quality Gate.

6-Gate 자율 검증 체인으로 AI 생성 코드의 품질을 보장한다.
"""
