"""VIBE-X Layer 4: Collaboration Orchestrator.

MCP 기반 팀 컨텍스트 동기화, 충돌 감지, 작업 영역 분리.
"""
