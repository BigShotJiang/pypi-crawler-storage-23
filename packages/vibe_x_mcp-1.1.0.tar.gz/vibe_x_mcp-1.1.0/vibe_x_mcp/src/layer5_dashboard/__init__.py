"""VIBE-X Layer 5: Team Intelligence Dashboard.

실시간 팀 인텔리전스 대시보드 - FastAPI + WebSocket.
"""
