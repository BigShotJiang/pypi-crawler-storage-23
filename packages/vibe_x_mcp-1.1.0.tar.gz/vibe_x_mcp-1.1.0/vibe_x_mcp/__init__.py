"""VIBE-X MCP Server — AI Code Quality & Team Collaboration."""

__version__ = "1.0.0"
