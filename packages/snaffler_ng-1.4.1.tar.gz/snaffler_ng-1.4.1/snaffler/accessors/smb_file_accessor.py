# snaffler/accessors/smb_file_accessor.py

import threading
from pathlib import Path
from typing import Optional

from impacket.smb import FILE_READ_DATA, FILE_READ_ATTRIBUTES, FILE_SHARE_READ

from snaffler.accessors.file_accessor import FileAccessor
from snaffler.transport.smb import SMBTransport
from snaffler.utils.path_utils import parse_unc_path


class SMBFileAccessor(FileAccessor):
    def __init__(self, cfg):
        self._transport = SMBTransport(cfg)
        self._thread_local = threading.local()
        self._max_file_bytes = cfg.scanning.max_file_bytes

    @staticmethod
    def _parse(file_path: str):
        """Parse a UNC path into (server, share, smb_path) or None."""
        parsed = parse_unc_path(file_path)
        if not parsed:
            return None
        server, share, smb_path, _name, _ext = parsed
        return server, share, smb_path

    def _get_smb(self, server: str):
        cache = getattr(self._thread_local, "smb_cache", {})
        self._thread_local.smb_cache = cache

        smb = cache.get(server)
        if smb:
            try:
                smb.getServerName()
                return smb
            except Exception:
                try:
                    smb.logoff()
                except Exception:
                    pass
                cache.pop(server, None)

        smb = self._transport.connect(server)
        cache[server] = smb
        return smb

    def read(self, file_path: str, max_bytes: Optional[int] = None) -> Optional[bytes]:
        parsed = self._parse(file_path)
        if not parsed:
            return None
        server, share, smb_path = parsed
        try:
            smb = self._get_smb(server)
            tid = smb.connectTree(share)
            try:
                fid = smb.openFile(
                    tid,
                    smb_path,
                    desiredAccess=FILE_READ_DATA | FILE_READ_ATTRIBUTES,
                    shareMode=FILE_SHARE_READ,
                )
                try:
                    data = smb.readFile(tid, fid, offset=0, bytesToRead=max_bytes or 0)
                    return data if data else b""
                finally:
                    smb.closeFile(tid, fid)
            finally:
                smb.disconnectTree(tid)
        except Exception:
            cache = getattr(self._thread_local, "smb_cache", None)
            if cache:
                cache.pop(server, None)
            return None

    def copy_to_local(self, file_path: str, dest_root) -> None:
        parsed = self._parse(file_path)
        if not parsed:
            return
        server, share, smb_path = parsed
        try:
            clean = smb_path.lstrip("\\/")
            local = (Path(dest_root) / server / share / clean).resolve()
            root = Path(dest_root).resolve()
            if not local.is_relative_to(root):
                return

            local.parent.mkdir(parents=True, exist_ok=True)

            data = self.read(file_path, max_bytes=self._max_file_bytes)
            if data:
                local.write_bytes(data)
        except Exception:
            pass
