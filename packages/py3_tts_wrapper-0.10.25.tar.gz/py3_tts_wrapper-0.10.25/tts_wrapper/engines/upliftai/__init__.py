"""UpliftAI TTS engine for tts-wrapper."""

from .client import UpliftAIClient

__all__ = ["UpliftAIClient"]
