"""ModelsLab TTS engine for tts-wrapper."""

from .client import ModelsLabClient

__all__ = ["ModelsLabClient"]
