from .client import MicrosoftClient
from .ssml import MicrosoftSSML

# For backward compatibility
MicrosoftTTS = MicrosoftClient
