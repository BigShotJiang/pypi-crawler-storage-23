from tts_wrapper.ssml import BaseSSMLRoot


class WatsonSSML(BaseSSMLRoot):
    def __init__(self) -> None:
        super().__init__()

    def clear_ssml(self) -> None:
        pass
