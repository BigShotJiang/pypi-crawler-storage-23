from .client import PollyClient
from .ssml import PollySSML

# For backward compatibility
PollyTTS = PollyClient
