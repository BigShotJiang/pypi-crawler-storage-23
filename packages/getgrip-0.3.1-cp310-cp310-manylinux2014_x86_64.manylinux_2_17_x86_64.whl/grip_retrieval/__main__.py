"""Allow running as: python -m grip_retrieval"""

import os
import sys


def main():
    # Add ~/.grip/packages/ to sys.path so pip-installed extras are importable
    grip_home = os.environ.get("GRIP_DATA_DIR") or os.path.join(
        os.path.expanduser("~"), ".grip"
    )
    pkg_dir = os.path.join(grip_home, "packages")
    if os.path.isdir(pkg_dir) and pkg_dir not in sys.path:
        sys.path.insert(0, pkg_dir)

    import uvicorn
    from .server import app  # noqa: F401
    uvicorn.run(app, host="0.0.0.0", port=7878)


if __name__ == "__main__":
    main()
