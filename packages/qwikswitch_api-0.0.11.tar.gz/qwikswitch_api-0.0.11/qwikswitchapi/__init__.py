"""QwikSwitch API client library."""

# SPDX-FileCopyrightText: 2024-present Riaan Hanekom <rhanekom@gmail.com>
#
# SPDX-License-Identifier: MIT
