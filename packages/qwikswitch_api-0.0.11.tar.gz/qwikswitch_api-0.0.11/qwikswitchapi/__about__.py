"""Package version information."""

# SPDX-FileCopyrightText: 2024-present Riaan Hanekom <riaan@hanekom.io>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.11"
