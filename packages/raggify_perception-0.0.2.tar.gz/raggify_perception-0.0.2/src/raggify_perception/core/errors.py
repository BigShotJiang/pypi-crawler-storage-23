from __future__ import annotations

from typing import Optional


class PerceptionError(Exception):
    """Represent a perception library runtime error.

    Args:
        message (str): Human readable message.
        code (str): Stable error code.
        cause (Optional[Exception], optional): Root exception. Defaults to None.

    """

    def __init__(
        self,
        message: str,
        code: str,
        cause: Optional[Exception] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.cause = cause
