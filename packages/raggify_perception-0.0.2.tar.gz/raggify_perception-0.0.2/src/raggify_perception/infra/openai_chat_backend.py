from __future__ import annotations

from typing import cast

from openai import AsyncOpenAI, OpenAI
from openai.types.chat import ChatCompletionMessageParam

from raggify_perception.core.constants import (
    EXTERNAL_API_ERROR_CODE,
    EXTERNAL_API_KEY_MISSING_CODE,
)
from raggify_perception.core.errors import PerceptionError
from raggify_perception.core.settings import Settings
from raggify_perception.domain.result_utils import extract_chat_text_content


class OpenAIChatBackend:
    """OpenAI-compatible backend for sync chat completion calls.

    Args:
        settings (Settings): Runtime settings.
    """

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        if settings.external_api_key is None:
            raise PerceptionError(
                "external_api_key is required.",
                EXTERNAL_API_KEY_MISSING_CODE,
            )
        self.client = OpenAI(
            api_key=settings.external_api_key,
            base_url=settings.external_api_base_url,
            timeout=float(settings.request_timeout_seconds),
        )

    def complete(
        self,
        model: str,
        messages: list[dict[str, object]],
        temperature: float,
    ) -> str:
        """Request chat completion.

        Args:
            model (str): External model name.
            messages (list[dict[str, object]]): OpenAI chat message payload.
            temperature (float): Sampling temperature.

        Raises:
            PerceptionError: If external call fails.

        Returns:
            str: Extracted text content.
        """

        payload_messages = cast(list[ChatCompletionMessageParam], messages)
        try:
            completion = self.client.chat.completions.create(
                model=model,
                messages=payload_messages,
                temperature=temperature,
            )
        except Exception as exc:
            raise PerceptionError(
                f"External chat completion failed: {exc}",
                EXTERNAL_API_ERROR_CODE,
                cause=exc,
            ) from exc

        if not completion.choices:
            return ""
        return extract_chat_text_content(completion.choices[0].message.content)


class AsyncOpenAIChatBackend:
    """OpenAI-compatible backend for async chat completion calls.

    Args:
        settings (Settings): Runtime settings.
    """

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        if settings.external_api_key is None:
            raise PerceptionError(
                "external_api_key is required.",
                EXTERNAL_API_KEY_MISSING_CODE,
            )
        self.client = AsyncOpenAI(
            api_key=settings.external_api_key,
            base_url=settings.external_api_base_url,
            timeout=float(settings.request_timeout_seconds),
        )

    async def complete(
        self,
        model: str,
        messages: list[dict[str, object]],
        temperature: float,
    ) -> str:
        """Request chat completion asynchronously.

        Args:
            model (str): External model name.
            messages (list[dict[str, object]]): OpenAI chat message payload.
            temperature (float): Sampling temperature.

        Raises:
            PerceptionError: If external call fails.

        Returns:
            str: Extracted text content.
        """

        payload_messages = cast(list[ChatCompletionMessageParam], messages)
        try:
            completion = await self.client.chat.completions.create(
                model=model,
                messages=payload_messages,
                temperature=temperature,
            )
        except Exception as exc:
            raise PerceptionError(
                f"External chat completion failed: {exc}",
                EXTERNAL_API_ERROR_CODE,
                cause=exc,
            ) from exc

        if not completion.choices:
            return ""
        return extract_chat_text_content(completion.choices[0].message.content)
