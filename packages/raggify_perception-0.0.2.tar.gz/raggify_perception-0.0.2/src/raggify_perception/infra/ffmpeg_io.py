from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

from raggify_perception.core.constants import (
    MEDIA_NORMALIZATION_FAILED_CODE,
    VIDEO_AUDIO_EXTRACTION_FAILED_CODE,
)
from raggify_perception.core.errors import PerceptionError

_FFMPEG_TIMEOUT_SECONDS = 120
_INPUT_FILE_NAME = "input.bin"
_OUTPUT_AUDIO_FILE_NAME = "output.mp3"
_OUTPUT_IMAGE_FILE_NAME = "output.png"
_OUTPUT_VIDEO_FILE_NAME = "output.mp4"


def _run_ffmpeg_command(
    command: list[str],
    error_prefix: str,
    error_code: str,
) -> None:
    """Run ffmpeg command and map failures to a perception error.

    Args:
        command (list[str]): ffmpeg command line.
        error_prefix (str): Prefix for user-facing error message.
        error_code (str): Stable error code.

    Raises:
        PerceptionError: If ffmpeg fails.
    """

    try:
        subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True,
            timeout=_FFMPEG_TIMEOUT_SECONDS,
        )
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        raise PerceptionError(
            f"{error_prefix}: {exc}",
            error_code,
            cause=exc,
        ) from exc


def _read_required_file(path: Path, message: str, code: str) -> bytes:
    """Read a required output file and reject empty output.

    Args:
        path (Path): Output file path.
        message (str): Error message for empty output.
        code (str): Stable error code.

    Raises:
        PerceptionError: If file does not exist or is empty.

    Returns:
        bytes: Output bytes.
    """

    payload = path.read_bytes() if path.exists() else b""
    if not payload:
        raise PerceptionError(message, code)
    return payload


def normalize_image_to_png_bytes(media_bytes: bytes, ffmpeg_bin: str) -> bytes:
    """Normalize image bytes to PNG bytes.

    Args:
        media_bytes (bytes): Input media bytes.
        ffmpeg_bin (str): ffmpeg executable path.

    Returns:
        bytes: Normalized PNG bytes.
    """

    with tempfile.TemporaryDirectory(prefix="raggify-perception-") as temp_dir:
        temp_path = Path(temp_dir)
        input_path = temp_path / _INPUT_FILE_NAME
        output_path = temp_path / _OUTPUT_IMAGE_FILE_NAME
        input_path.write_bytes(media_bytes)

        _run_ffmpeg_command(
            command=[
                ffmpeg_bin,
                "-y",
                "-i",
                str(input_path),
                "-frames:v",
                "1",
                str(output_path),
            ],
            error_prefix="Image normalization failed",
            error_code=MEDIA_NORMALIZATION_FAILED_CODE,
        )
        return _read_required_file(
            output_path,
            "Image normalization produced an empty output.",
            MEDIA_NORMALIZATION_FAILED_CODE,
        )


def normalize_audio_to_mp3_bytes(media_bytes: bytes, ffmpeg_bin: str) -> bytes:
    """Normalize audio bytes to MP3 bytes.

    Args:
        media_bytes (bytes): Input media bytes.
        ffmpeg_bin (str): ffmpeg executable path.

    Returns:
        bytes: Normalized MP3 bytes.
    """

    with tempfile.TemporaryDirectory(prefix="raggify-perception-") as temp_dir:
        temp_path = Path(temp_dir)
        input_path = temp_path / _INPUT_FILE_NAME
        output_path = temp_path / _OUTPUT_AUDIO_FILE_NAME
        input_path.write_bytes(media_bytes)

        _run_ffmpeg_command(
            command=[
                ffmpeg_bin,
                "-y",
                "-i",
                str(input_path),
                "-vn",
                "-acodec",
                "mp3",
                str(output_path),
            ],
            error_prefix="Audio normalization failed",
            error_code=MEDIA_NORMALIZATION_FAILED_CODE,
        )
        return _read_required_file(
            output_path,
            "Audio normalization produced an empty output.",
            MEDIA_NORMALIZATION_FAILED_CODE,
        )


def normalize_video_to_mp4_bytes(media_bytes: bytes, ffmpeg_bin: str) -> bytes:
    """Normalize video bytes to MP4 bytes.

    Args:
        media_bytes (bytes): Input media bytes.
        ffmpeg_bin (str): ffmpeg executable path.

    Returns:
        bytes: Normalized MP4 bytes.
    """

    with tempfile.TemporaryDirectory(prefix="raggify-perception-") as temp_dir:
        temp_path = Path(temp_dir)
        input_path = temp_path / _INPUT_FILE_NAME
        output_path = temp_path / _OUTPUT_VIDEO_FILE_NAME
        input_path.write_bytes(media_bytes)

        _run_ffmpeg_command(
            command=[
                ffmpeg_bin,
                "-y",
                "-i",
                str(input_path),
                "-c:v",
                "libx264",
                "-pix_fmt",
                "yuv420p",
                "-c:a",
                "aac",
                str(output_path),
            ],
            error_prefix="Video normalization failed",
            error_code=MEDIA_NORMALIZATION_FAILED_CODE,
        )
        return _read_required_file(
            output_path,
            "Video normalization produced an empty output.",
            MEDIA_NORMALIZATION_FAILED_CODE,
        )


def extract_audio_from_video_bytes(video_bytes: bytes, ffmpeg_bin: str) -> bytes:
    """Extract MP3 audio bytes from video bytes.

    Args:
        video_bytes (bytes): Video bytes.
        ffmpeg_bin (str): ffmpeg executable path.

    Returns:
        bytes: Extracted MP3 bytes.
    """

    with tempfile.TemporaryDirectory(prefix="raggify-perception-") as temp_dir:
        temp_path = Path(temp_dir)
        input_path = temp_path / "input.mp4"
        output_path = temp_path / _OUTPUT_AUDIO_FILE_NAME
        input_path.write_bytes(video_bytes)

        _run_ffmpeg_command(
            command=[
                ffmpeg_bin,
                "-y",
                "-i",
                str(input_path),
                "-vn",
                "-acodec",
                "mp3",
                str(output_path),
            ],
            error_prefix="Video audio extraction failed",
            error_code=VIDEO_AUDIO_EXTRACTION_FAILED_CODE,
        )
        return _read_required_file(
            output_path,
            "Video audio extraction produced an empty output.",
            VIDEO_AUDIO_EXTRACTION_FAILED_CODE,
        )
