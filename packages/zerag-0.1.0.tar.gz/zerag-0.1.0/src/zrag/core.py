"""Core engine for zrag — ZragStore with ingest, query, and graph."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

import zvec

from zrag.parsers import parse_file

# Chunking defaults
DEFAULT_CHUNK_SIZE = 512
DEFAULT_OVERLAP = 64
EMBEDDING_DIM = 384

SKIP_DIRS = {"node_modules", "__pycache__", ".venv", "venv"}


def _chunk_text(
    text: str, chunk_size: int = DEFAULT_CHUNK_SIZE, overlap: int = DEFAULT_OVERLAP
) -> list[str]:
    """Split text into overlapping chunks, preferring paragraph boundaries."""
    if not text.strip():
        return []
    if overlap >= chunk_size:
        raise ValueError(
            f"overlap ({overlap}) must be less than chunk_size ({chunk_size})"
        )

    step = chunk_size - overlap

    # Split on paragraph boundaries first
    paragraphs = text.split("\n\n")
    chunks: list[str] = []
    current = ""

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue

        if len(current) + len(para) + 2 <= chunk_size:
            current = f"{current}\n\n{para}" if current else para
        else:
            if current:
                chunks.append(current.strip())
            # If a single paragraph exceeds chunk_size, split it
            if len(para) > chunk_size:
                start = 0
                while start < len(para):
                    end = start + chunk_size
                    chunks.append(para[start:end].strip())
                    start += step
            else:
                current = para
                continue
            current = ""

    if current.strip():
        chunks.append(current.strip())

    # If no paragraph splitting happened, fall back to sliding window
    if not chunks and text.strip():
        start = 0
        while start < len(text):
            end = start + chunk_size
            chunks.append(text[start:end].strip())
            start += step

    return [c for c in chunks if c]


def _make_id(file_path: str, chunk_index: int) -> str:
    """Deterministic chunk ID from file path and index."""
    raw = f"{file_path}::{chunk_index}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _doc_to_dict(doc: zvec.Doc) -> dict[str, Any]:
    """Convert a zvec Doc to a plain dict."""
    return {
        "id": doc.id,
        "score": doc.score,
        "file_path": doc.field("file_path"),
        "chunk_index": doc.field("chunk_index"),
        "content": doc.field("content"),
        "file_type": doc.field("file_type"),
    }


class ZragStore:
    """Vector store with implicit knowledge graph semantics."""

    def __init__(self, path: str) -> None:
        self.path = Path(path)
        self._embedder = zvec.DefaultLocalDenseEmbedding()
        self._collection: zvec.Collection | None = None

    def __enter__(self) -> ZragStore:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def _is_existing_collection(self) -> bool:
        """Check if a zvec collection already exists at self.path."""
        if not self.path.exists():
            return False
        return any(f.name.startswith("manifest") for f in self.path.iterdir())

    def _get_collection(self) -> zvec.Collection:
        if self._collection is not None:
            return self._collection

        if self._is_existing_collection():
            self._collection = zvec.open(
                str(self.path),
                option=zvec.CollectionOption(read_only=False),
            )
        else:
            schema = zvec.CollectionSchema(
                name="zrag",
                fields=[
                    zvec.FieldSchema(
                        "file_path",
                        zvec.DataType.STRING,
                        index_param=zvec.InvertIndexParam(),
                    ),
                    zvec.FieldSchema("chunk_index", zvec.DataType.INT32),
                    zvec.FieldSchema("content", zvec.DataType.STRING),
                    zvec.FieldSchema(
                        "file_type",
                        zvec.DataType.STRING,
                        index_param=zvec.InvertIndexParam(),
                    ),
                ],
                vectors=[
                    zvec.VectorSchema(
                        "embedding",
                        data_type=zvec.DataType.VECTOR_FP32,
                        dimension=EMBEDDING_DIM,
                        index_param=zvec.HnswIndexParam(
                            metric_type=zvec.MetricType.COSINE,
                        ),
                    ),
                ],
            )
            # zvec creates the directory itself — ensure parent exists
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._collection = zvec.create_and_open(
                path=str(self.path), schema=schema
            )
        return self._collection

    def ingest(
        self,
        directory: str,
        chunk_size: int = DEFAULT_CHUNK_SIZE,
        overlap: int = DEFAULT_OVERLAP,
    ) -> dict[str, int]:
        """Ingest all files from a directory. Returns stats."""
        if chunk_size <= 0:
            raise ValueError(f"chunk_size must be positive, got {chunk_size}")
        if overlap < 0:
            raise ValueError(f"overlap must be non-negative, got {overlap}")
        if overlap >= chunk_size:
            raise ValueError(
                f"overlap ({overlap}) must be less than chunk_size ({chunk_size})"
            )

        dir_path = Path(directory).resolve()
        if not dir_path.is_dir():
            raise ValueError(f"Not a directory: {directory}")

        collection = self._get_collection()
        files_processed = 0
        chunks_stored = 0
        files_skipped = 0

        for file_path in sorted(dir_path.rglob("*")):
            if not file_path.is_file():
                continue
            # Skip hidden files and common non-content dirs
            parts = file_path.relative_to(dir_path).parts
            if any(p.startswith(".") for p in parts):
                continue
            if any(p in SKIP_DIRS for p in parts):
                continue

            result = parse_file(file_path)
            if result is None:
                files_skipped += 1
                continue

            text, meta = result
            rel_path = str(file_path.relative_to(dir_path))
            file_type = meta.get("file_type", file_path.suffix.lower())

            chunks = _chunk_text(text, chunk_size, overlap)
            if not chunks:
                files_skipped += 1
                continue

            docs = []
            for i, chunk in enumerate(chunks):
                doc_id = _make_id(rel_path, i)
                vec = self._embedder.embed(chunk)
                docs.append(
                    zvec.Doc(
                        id=doc_id,
                        vectors={"embedding": vec},
                        fields={
                            "file_path": rel_path,
                            "chunk_index": i,
                            "content": chunk,
                            "file_type": file_type,
                        },
                    )
                )
            collection.upsert(docs)
            files_processed += 1
            chunks_stored += len(docs)

        collection.flush()
        collection.optimize()

        return {
            "files_processed": files_processed,
            "chunks_stored": chunks_stored,
            "files_skipped": files_skipped,
        }

    def query(self, text: str, topk: int = 5) -> list[dict[str, Any]]:
        """Query the store and return ranked results."""
        collection = self._get_collection()
        query_vec = self._embedder.embed(text)

        results = collection.query(
            vectors=zvec.VectorQuery(field_name="embedding", vector=query_vec),
            topk=topk,
            output_fields=["file_path", "chunk_index", "content", "file_type"],
        )

        return [_doc_to_dict(doc) for doc in results]

    def graph(
        self,
        text: str,
        depth: int = 1,
        topk: int = 5,
        similarity_threshold: float = 0.5,
    ) -> dict[str, Any]:
        """Build an implicit knowledge graph around a query.

        Returns {"nodes": [...], "edges": [...]}.
        Edge types: same_file, adjacent, similar.
        """
        collection = self._get_collection()

        # Seed nodes from initial query
        seed_results = self.query(text, topk=topk)
        if not seed_results:
            return {"nodes": [], "edges": []}

        nodes: dict[str, dict[str, Any]] = {}
        edges: list[dict[str, Any]] = []
        seen_edges: set[tuple[str, str, str]] = set()

        def _add_node(result: dict[str, Any]) -> None:
            nodes[result["id"]] = result

        def _add_edge(
            src: str, dst: str, edge_type: str, weight: float = 1.0
        ) -> None:
            key = (min(src, dst), max(src, dst), edge_type)
            if key not in seen_edges:
                seen_edges.add(key)
                edges.append({
                    "source": src,
                    "target": dst,
                    "type": edge_type,
                    "weight": weight,
                })

        # Add seed nodes
        for r in seed_results:
            _add_node(r)

        # Expand graph for each depth level
        frontier = list(nodes.keys())
        for _ in range(depth):
            new_frontier: list[str] = []
            for node_id in frontier:
                node = nodes[node_id]
                fp = node["file_path"]
                ci = node["chunk_index"]

                # Embed once, reuse for both queries
                node_vec = self._embedder.embed(node["content"])

                # same_file + adjacent edges
                safe_fp = fp.replace("'", "''")
                same_file_results = collection.query(
                    vectors=zvec.VectorQuery(
                        field_name="embedding", vector=node_vec,
                    ),
                    topk=50,
                    filter=f"file_path = '{safe_fp}'",
                    output_fields=[
                        "file_path", "chunk_index", "content", "file_type",
                    ],
                )

                for doc in same_file_results:
                    r = _doc_to_dict(doc)
                    if r["id"] == node_id:
                        continue
                    is_new = r["id"] not in nodes
                    _add_node(r)
                    _add_edge(node_id, r["id"], "same_file")
                    if abs(r["chunk_index"] - ci) == 1:
                        _add_edge(node_id, r["id"], "adjacent")
                    if is_new:
                        new_frontier.append(r["id"])

                # similar edges: semantically similar chunks across files
                similar_results = collection.query(
                    vectors=zvec.VectorQuery(
                        field_name="embedding", vector=node_vec,
                    ),
                    topk=topk,
                    output_fields=[
                        "file_path", "chunk_index", "content", "file_type",
                    ],
                )

                for doc in similar_results:
                    if doc.score < similarity_threshold:
                        continue
                    r = _doc_to_dict(doc)
                    if r["id"] == node_id:
                        continue
                    is_new = r["id"] not in nodes
                    _add_node(r)
                    _add_edge(node_id, r["id"], "similar", weight=doc.score)
                    if is_new:
                        new_frontier.append(r["id"])

            frontier = new_frontier

        return {
            "nodes": list(nodes.values()),
            "edges": edges,
        }

    def stats(self) -> dict[str, Any]:
        """Return store statistics."""
        collection = self._get_collection()
        st = collection.stats
        return {
            "path": str(self.path),
            "total_docs": st.doc_count,
            "index_completeness": st.index_completeness,
        }

    def close(self) -> None:
        """Close the underlying collection."""
        if self._collection is not None:
            self._collection.flush()
            self._collection = None
