"""CLI for zrag — ingest, query, graph, stats."""

from __future__ import annotations

import json

import click

from zrag.core import DEFAULT_CHUNK_SIZE, DEFAULT_OVERLAP, ZragStore

DEFAULT_INDEX = ".zrag_index"


@click.group()
@click.option("--index", default=DEFAULT_INDEX, help="Path to the zrag index.")
@click.pass_context
def cli(ctx: click.Context, index: str) -> None:
    """zrag — Tiny RAG with implicit knowledge graph."""
    ctx.ensure_object(dict)
    ctx.obj["index"] = index


@cli.command()
@click.argument("directory")
@click.option("--chunk-size", default=DEFAULT_CHUNK_SIZE, help="Chunk size in chars.")
@click.option("--overlap", default=DEFAULT_OVERLAP, help="Overlap between chunks.")
@click.pass_context
def ingest(ctx: click.Context, directory: str, chunk_size: int, overlap: int) -> None:
    """Ingest files from a directory into the index."""
    with ZragStore(ctx.obj["index"]) as store:
        click.echo(f"Ingesting from {directory}...")
        result = store.ingest(directory, chunk_size=chunk_size, overlap=overlap)
        click.echo(
            f"Done: {result['files_processed']} files, "
            f"{result['chunks_stored']} chunks "
            f"({result['files_skipped']} skipped)"
        )


@cli.command()
@click.argument("text")
@click.option("--topk", default=5, help="Number of results.")
@click.pass_context
def query(ctx: click.Context, text: str, topk: int) -> None:
    """Query the index with natural language."""
    with ZragStore(ctx.obj["index"]) as store:
        results = store.query(text, topk=topk)

    if not results:
        click.echo("No results found.")
        return

    for i, r in enumerate(results, 1):
        score = r["score"]
        fp = r["file_path"]
        ci = r["chunk_index"]
        content = r["content"]
        preview = content[:200] + "..." if len(content) > 200 else content
        click.echo(f"\n[{i}] {fp} (chunk {ci}, score: {score:.4f})")
        click.echo(f"    {preview}")


@cli.command()
@click.argument("text")
@click.option("--depth", default=1, help="Graph expansion depth.")
@click.option("--topk", default=5, help="Number of seed results.")
@click.option("--threshold", default=0.5, help="Similarity threshold for edges.")
@click.pass_context
def graph(
    ctx: click.Context, text: str, depth: int, topk: int, threshold: float
) -> None:
    """Build an implicit knowledge graph around a query."""
    with ZragStore(ctx.obj["index"]) as store:
        result = store.graph(
            text, depth=depth, topk=topk, similarity_threshold=threshold
        )

    n_nodes = len(result["nodes"])
    n_edges = len(result["edges"])
    click.echo(f"Graph: {n_nodes} nodes, {n_edges} edges\n")

    click.echo("Nodes:")
    for node in result["nodes"]:
        click.echo(
            f"  - {node['file_path']}:{node['chunk_index']} ({node['id'][:8]})"
        )

    click.echo("\nEdges:")
    edge_types: dict[str, int] = {}
    for edge in result["edges"]:
        t = edge["type"]
        edge_types[t] = edge_types.get(t, 0) + 1
    for t, count in sorted(edge_types.items()):
        click.echo(f"  {t}: {count}")

    click.echo(f"\n--- JSON ---\n{json.dumps(result, indent=2, default=str)}")


@cli.command()
@click.pass_context
def stats(ctx: click.Context) -> None:
    """Show index statistics."""
    with ZragStore(ctx.obj["index"]) as store:
        s = store.stats()
    click.echo(f"Index path: {s['path']}")
    click.echo(f"Total chunks: {s['total_docs']}")
    click.echo(f"Index completeness: {s['index_completeness']}")
