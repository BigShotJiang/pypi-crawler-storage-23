"""File parsers for zrag — extension-based dispatch."""

from __future__ import annotations

import csv
import html
import io
import json
import re
from pathlib import Path
from typing import Any


def parse_file(path: Path) -> tuple[str, dict[str, Any]] | None:
    """Parse a file and return (text, metadata), or None if unparseable."""
    ext = path.suffix.lower()
    parser = _PARSERS.get(ext, _parse_text_fallback)
    try:
        return parser(path)
    except Exception:
        return None


def _parse_text(path: Path) -> tuple[str, dict[str, Any]]:
    text = path.read_text(encoding="utf-8")
    return text, {"file_type": path.suffix.lower()}


def _parse_json(path: Path) -> tuple[str, dict[str, Any]]:
    text = path.read_text(encoding="utf-8")
    # Validate it's real JSON, then store as pretty-printed text
    obj = json.loads(text)
    return json.dumps(obj, indent=2), {"file_type": ".json"}


def _parse_csv(path: Path) -> tuple[str, dict[str, Any]]:
    text = path.read_text(encoding="utf-8")
    reader = csv.reader(io.StringIO(text))
    rows = list(reader)
    # Convert to readable text: header + rows
    lines = []
    for row in rows:
        lines.append(" | ".join(row))
    return "\n".join(lines), {"file_type": ".csv"}


def _parse_html(path: Path) -> tuple[str, dict[str, Any]]:
    raw = path.read_text(encoding="utf-8")
    # Strip tags, decode entities
    clean = re.sub(r"<[^>]+>", " ", raw)
    clean = html.unescape(clean)
    clean = re.sub(r"\s+", " ", clean).strip()
    return clean, {"file_type": ".html"}


def _parse_pdf(path: Path) -> tuple[str, dict[str, Any]]:
    try:
        import pymupdf  # noqa: F811
    except ImportError:
        raise ImportError(
            "pymupdf is required for PDF parsing. "
            "Install with: pip install 'zrag[pdf]'"
        )
    with pymupdf.open(str(path)) as doc:
        pages = [page.get_text() for page in doc]
    return "\n\n".join(pages), {"file_type": ".pdf", "page_count": len(pages)}


def _parse_text_fallback(path: Path) -> tuple[str, dict[str, Any]] | None:
    """Try UTF-8 read; return None for binary files."""
    try:
        text = path.read_text(encoding="utf-8")
        # Quick binary check: if there are null bytes, skip it
        if "\x00" in text:
            return None
        return text, {"file_type": path.suffix.lower() or ".unknown"}
    except (UnicodeDecodeError, ValueError):
        return None


_PARSERS: dict[str, Any] = {
    ".md": _parse_text,
    ".txt": _parse_text,
    ".py": _parse_text,
    ".js": _parse_text,
    ".ts": _parse_text,
    ".tsx": _parse_text,
    ".jsx": _parse_text,
    ".yaml": _parse_text,
    ".yml": _parse_text,
    ".toml": _parse_text,
    ".rst": _parse_text,
    ".json": _parse_json,
    ".csv": _parse_csv,
    ".html": _parse_html,
    ".htm": _parse_html,
    ".pdf": _parse_pdf,
}

SUPPORTED_EXTENSIONS: set[str] = set(_PARSERS.keys())
