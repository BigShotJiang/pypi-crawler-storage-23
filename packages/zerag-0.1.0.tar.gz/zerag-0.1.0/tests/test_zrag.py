"""Tests for zrag."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from zrag.core import ZragStore, _chunk_text, _make_id
from zrag.parsers import SUPPORTED_EXTENSIONS, parse_file


# --- Parser tests ---


class TestParsers:
    def test_parse_markdown(self, tmp_path: Path) -> None:
        f = tmp_path / "test.md"
        f.write_text("# Hello\n\nWorld")
        result = parse_file(f)
        assert result is not None
        text, meta = result
        assert "Hello" in text
        assert meta["file_type"] == ".md"

    def test_parse_python(self, tmp_path: Path) -> None:
        f = tmp_path / "test.py"
        f.write_text("def hello():\n    return 'world'")
        result = parse_file(f)
        assert result is not None
        text, meta = result
        assert "def hello" in text
        assert meta["file_type"] == ".py"

    def test_parse_json(self, tmp_path: Path) -> None:
        f = tmp_path / "test.json"
        f.write_text('{"key": "value"}')
        result = parse_file(f)
        assert result is not None
        text, meta = result
        assert "key" in text
        assert meta["file_type"] == ".json"

    def test_parse_csv(self, tmp_path: Path) -> None:
        f = tmp_path / "test.csv"
        f.write_text("name,age\nAlice,30\nBob,25")
        result = parse_file(f)
        assert result is not None
        text, meta = result
        assert "Alice" in text
        assert " | " in text  # CSV columns joined with pipe

    def test_parse_html(self, tmp_path: Path) -> None:
        f = tmp_path / "test.html"
        f.write_text("<html><body><p>Hello &amp; world</p></body></html>")
        result = parse_file(f)
        assert result is not None
        text, meta = result
        assert "Hello & world" in text
        assert "<" not in text

    def test_parse_binary_returns_none(self, tmp_path: Path) -> None:
        f = tmp_path / "test.bin"
        f.write_bytes(b"\x00\x01\x02\x03")
        result = parse_file(f)
        assert result is None

    def test_parse_unknown_text_extension(self, tmp_path: Path) -> None:
        f = tmp_path / "test.cfg"
        f.write_text("some_key = some_value")
        result = parse_file(f)
        assert result is not None
        text, _ = result
        assert "some_key" in text

    def test_supported_extensions(self) -> None:
        assert ".md" in SUPPORTED_EXTENSIONS
        assert ".py" in SUPPORTED_EXTENSIONS
        assert ".json" in SUPPORTED_EXTENSIONS
        assert ".csv" in SUPPORTED_EXTENSIONS
        assert ".html" in SUPPORTED_EXTENSIONS
        assert ".pdf" in SUPPORTED_EXTENSIONS


# --- Chunking tests ---


class TestChunking:
    def test_basic_chunking(self) -> None:
        text = "A" * 1024
        chunks = _chunk_text(text, chunk_size=512, overlap=64)
        assert len(chunks) >= 2
        assert all(len(c) <= 512 for c in chunks)

    def test_paragraph_boundaries(self) -> None:
        text = "Para one.\n\nPara two.\n\nPara three."
        chunks = _chunk_text(text, chunk_size=512, overlap=64)
        assert len(chunks) == 1  # fits in one chunk
        assert "Para one." in chunks[0]

    def test_empty_text(self) -> None:
        assert _chunk_text("") == []
        assert _chunk_text("   ") == []

    def test_small_text(self) -> None:
        chunks = _chunk_text("hello", chunk_size=512, overlap=64)
        assert len(chunks) == 1
        assert chunks[0] == "hello"

    def test_deterministic_ids(self) -> None:
        id1 = _make_id("file.py", 0)
        id2 = _make_id("file.py", 0)
        id3 = _make_id("file.py", 1)
        assert id1 == id2
        assert id1 != id3


# --- Integration tests (require zvec + embeddings) ---


class TestZragStore:
    @pytest.fixture()
    def sample_dir(self, tmp_path: Path) -> Path:
        """Create a sample directory with test files."""
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "readme.md").write_text(
            "# My Project\n\n"
            "This is a sample project for testing zrag.\n\n"
            "## Features\n\n"
            "- Vector search\n"
            "- Knowledge graph\n"
            "- File parsing"
        )
        (docs / "config.json").write_text(
            json.dumps({"name": "test", "version": "1.0"})
        )
        sub = docs / "src"
        sub.mkdir()
        (sub / "main.py").write_text(
            "def main():\n"
            '    """Entry point for the application."""\n'
            '    print("Hello, world!")\n'
            "\n\n"
            "def helper():\n"
            '    """A helper function."""\n'
            "    return 42\n"
        )
        return docs

    @pytest.fixture()
    def store(self, tmp_path: Path) -> ZragStore:
        index_path = tmp_path / "test_index"
        return ZragStore(str(index_path))

    def test_ingest(self, store: ZragStore, sample_dir: Path) -> None:
        result = store.ingest(str(sample_dir))
        assert result["files_processed"] > 0
        assert result["chunks_stored"] > 0

    def test_query(self, store: ZragStore, sample_dir: Path) -> None:
        store.ingest(str(sample_dir))
        results = store.query("vector search", topk=3)
        assert len(results) > 0
        assert "content" in results[0]
        assert "file_path" in results[0]
        assert "score" in results[0]

    def test_graph(self, store: ZragStore, sample_dir: Path) -> None:
        store.ingest(str(sample_dir))
        g = store.graph("project features", depth=1, topk=3)
        assert "nodes" in g
        assert "edges" in g
        assert len(g["nodes"]) > 0

    def test_stats(self, store: ZragStore, sample_dir: Path) -> None:
        store.ingest(str(sample_dir))
        s = store.stats()
        assert s["total_docs"] > 0

    def test_ingest_nonexistent_dir(self, store: ZragStore) -> None:
        with pytest.raises(ValueError, match="Not a directory"):
            store.ingest("/nonexistent/path")

    def test_query_empty_store(self, store: ZragStore) -> None:
        results = store.query("anything")
        assert results == []

    def test_upsert_idempotent(self, store: ZragStore, sample_dir: Path) -> None:
        """Ingesting the same directory twice should not duplicate chunks."""
        store.ingest(str(sample_dir))
        stats1 = store.stats()
        store.ingest(str(sample_dir))
        stats2 = store.stats()
        assert stats1["total_docs"] == stats2["total_docs"]
