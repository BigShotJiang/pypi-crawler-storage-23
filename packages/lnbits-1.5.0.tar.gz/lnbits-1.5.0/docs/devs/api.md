---
layout: default
parent: For developers
title: API reference
nav_order: 3
---

# API reference

[Swagger Docs](https://demo.lnbits.com/docs)
