window.app.component('lnbits-drawer', {
  template: '#lnbits-drawer'
})
