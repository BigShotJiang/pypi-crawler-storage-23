window.app.component('lnbits-admin-server', {
  props: ['form-data'],
  template: '#lnbits-admin-server'
})
