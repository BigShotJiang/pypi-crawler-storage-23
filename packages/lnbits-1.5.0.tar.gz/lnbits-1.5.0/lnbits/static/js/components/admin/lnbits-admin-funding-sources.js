window.app.component('lnbits-admin-funding-sources', {
  template: '#lnbits-admin-funding-sources',
  props: ['form-data', 'allowed-funding-sources'],
  methods: {
    getFundingSourceLabel(item) {
      const fundingSource = this.rawFundingSources.find(
        fundingSource => fundingSource[0] === item
      )
      return fundingSource ? fundingSource[1] : item
    },
    showQRValue(value) {
      this.qrValue = value
      this.showQRDialog = true
    }
  },
  computed: {
    fundingSources() {
      let tmp = []
      for (const [key, _, obj] of this.rawFundingSources) {
        const tmpObj = {}
        if (obj !== null) {
          for (let [k, v] of Object.entries(obj)) {
            tmpObj[k] =
              typeof v === 'string' ? {label: v, value: null} : v || {}
          }
        }
        tmp.push([key, tmpObj])
      }
      return new Map(tmp)
    },
    sortedAllowedFundingSources() {
      return this.allowedFundingSources.sort()
    }
  },
  data() {
    return {
      hideInput: true,
      showQRDialog: false,
      qrValue: '',
      rawFundingSources: [
        ['VoidWallet', 'Void Wallet', null],
        [
          'FakeWallet',
          'Fake Wallet',
          {
            fake_wallet_secret: 'Secret',
            lnbits_denomination: '"sats" or 3 Letter Custom Denomination'
          }
        ],
        [
          'CLNRestWallet',
          'Core Lightning Rest (plugin)',
          {
            clnrest_url: 'Endpoint',
            clnrest_ca: 'ca.pem',
            clnrest_cert: 'server.pem',
            clnrest_readonly_rune: 'Rune used for readonly requests',
            clnrest_invoice_rune: 'Rune used for creating invoices',
            clnrest_pay_rune: 'Rune used for paying invoices using pay',
            clnrest_renepay_rune: 'Rune used for paying invoices using renepay',
            clnrest_last_pay_index:
              'Ignores any invoices paid prior to or including this index. 0 is equivalent to not specifying and negative value is invalid.',
            clnrest_nodeid: 'Node id'
          }
        ],
        [
          'CoreLightningWallet',
          'Core Lightning',
          {
            corelightning_rpc: 'Endpoint',
            corelightning_pay_command: 'Custom Pay Command'
          }
        ],
        [
          'CoreLightningRestWallet',
          'Core Lightning Rest (legacy)',
          {
            corelightning_rest_url: 'Endpoint',
            corelightning_rest_cert: 'Certificate',
            corelightning_rest_macaroon: 'Macaroon'
          }
        ],
        [
          'LndRestWallet',
          'Lightning Network Daemon (LND Rest)',
          {
            lnd_rest_endpoint: 'Endpoint',
            lnd_rest_cert: 'Certificate',
            lnd_rest_macaroon: 'Macaroon',
            lnd_rest_macaroon_encrypted: 'Encrypted Macaroon',
            lnd_rest_route_hints: {
              advanced: true,
              label: 'Enable Route Hints'
            },
            lnd_rest_allow_self_payment: {
              advanced: true,
              label: 'Allow Self Payment'
            }
          }
        ],
        [
          'LndWallet',
          'Lightning Network Daemon (LND)',
          {
            lnd_grpc_endpoint: 'Endpoint',
            lnd_grpc_cert: 'Certificate',
            lnd_grpc_port: 'Port',
            lnd_grpc_macaroon: 'GRPC Macaroon',
            lnd_grpc_invoice_macaroon: 'GRPC Invoice Macaroon',
            lnd_grpc_admin_macaroon: 'GRPC Admin Macaroon',
            lnd_grpc_macaroon_encrypted: 'Encrypted Macaroon'
          }
        ],
        [
          'LnTipsWallet',
          'LN.Tips',
          {
            lntips_api_endpoint: 'Endpoint',
            lntips_api_key: 'API Key'
          }
        ],
        [
          'LNPayWallet',
          'LN Pay',
          {
            lnpay_api_endpoint: 'Endpoint',
            lnpay_api_key: 'API Key',
            lnpay_wallet_key: 'Wallet Key'
          }
        ],
        [
          'EclairWallet',
          'Eclair (ACINQ)',
          {
            eclair_url: 'URL',
            eclair_pass: 'Password'
          }
        ],
        [
          'LNbitsWallet',
          'LNbits',
          {
            lnbits_endpoint: 'Endpoint',
            lnbits_key: 'Admin Key'
          }
        ],
        [
          'BlinkWallet',
          'Blink',
          {
            blink_api_endpoint: 'Endpoint',
            blink_ws_endpoint: 'WebSocket',
            blink_token: 'Key'
          }
        ],
        [
          'AlbyWallet',
          'Alby',
          {
            alby_api_endpoint: 'Endpoint',
            alby_access_token: 'Key'
          }
        ],
        [
          'BoltzWallet',
          'Boltz',
          {
            boltz_client_endpoint: {
              label: 'Boltz client endpoint',
              value: '127.0.0.1:9002'
            },
            boltz_client_macaroon: {
              label: 'Admin Macaroon path or hex',
              value: '/home/ubuntu/.boltz/macaroons/admin.macaroon'
            },
            boltz_client_cert: {
              label: 'Certificate path or hex',
              value: '/home/ubuntu/.boltz/tls.cert'
            },
            boltz_mnemonic: {
              label: 'Liquid seed phrase',
              hint: 'Boltz will fetch once connected, but you can change later (can be opened in a liquid wallet) ',
              copy: true,
              qrcode: true
            },
            boltz_client_password: {
              label: 'Wallet Password (optional)',
              advanced: true
            }
          }
        ],
        [
          'ZBDWallet',
          'ZBD',
          {
            zbd_api_endpoint: 'Endpoint',
            zbd_api_key: 'Key'
          }
        ],
        [
          'PhoenixdWallet',
          'Phoenixd',
          {
            phoenixd_api_endpoint: 'Endpoint',
            phoenixd_api_password: 'Key'
          }
        ],
        [
          'OpenNodeWallet',
          'OpenNode',
          {
            opennode_api_endpoint: 'Endpoint',
            opennode_key: 'Key'
          }
        ],
        [
          'ClicheWallet',
          'Cliche (NBD)',
          {
            cliche_endpoint: 'Endpoint'
          }
        ],
        [
          'SparkWallet',
          'Spark',
          {
            spark_url: 'Endpoint',
            spark_token: 'Token'
          }
        ],
        [
          'SparkL2Wallet',
          'Spark (L2)',
          {
            spark_l2_external_endpoint: {
              label: 'External Sidecar Endpoint',
              hint: 'If specified then this endpoint will be used instead of the internal sidecar. Make sure to also specify the API key if your sidecar requires authentication.',
              value: ''
            },
            spark_l2_external_api_key: {
              label: 'External Sidecar API Key',
              hint: 'API key for authenticating with the external sidecar if it requires authentication.',
              value: ''
            },
            spark_l2_network: {
              label: 'Network',
              value: 'MAINNET',
              hint: 'The network to use for the Spark wallet.',
              advanced: true
            },
            spark_l2_pay_wait_ms: {
              label: 'Payment Wait Time (ms)',
              hint: 'The time to wait for a payment to be processed before considering it failed.',
              advanced: true
            },
            spark_l2_pay_poll_ms: {
              label: 'Payment Poll Time (ms)',
              hint: 'The time to wait between polling for payment status updates.',
              advanced: true
            },
            spark_l2_stream_keepalive_ms: {
              label: 'Stream Keepalive Time (ms)',
              hint: 'The time to wait between sending keepalive messages to the Spark sidecar to keep the connection open.',
              advanced: true
            }
          }
        ],
        [
          'NWCWallet',
          'Nostr Wallet Connect',
          {
            nwc_pairing_url: 'Pairing URL'
          }
        ],
        [
          'BreezSdkWallet',
          'Breez SDK',
          {
            breez_api_key: 'Breez API Key',
            breez_greenlight_seed: 'Greenlight Seed',
            breez_greenlight_device_key: 'Greenlight Device Key',
            breez_greenlight_device_cert: 'Greenlight Device Cert',
            breez_greenlight_invite_code: 'Greenlight Invite Code'
          }
        ],
        [
          'StrikeWallet',
          'Strike (alpha)',
          {
            strike_api_endpoint: 'API Endpoint',
            strike_api_key: 'API Key'
          }
        ],
        [
          'BreezLiquidSdkWallet',
          'Breez Liquid SDK',
          {
            breez_liquid_api_key: 'Breez API Key (can be empty)',
            breez_liquid_seed: 'Liquid seed phrase',
            breez_liquid_fee_offset_sat:
              'Offset amount in sats to increase fee limit'
          }
        ]
      ]
    }
  }
})
