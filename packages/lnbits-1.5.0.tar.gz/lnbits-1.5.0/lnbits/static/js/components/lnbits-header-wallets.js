window.app.component('lnbits-header-wallets', {
  template: '#lnbits-header-wallets'
})
