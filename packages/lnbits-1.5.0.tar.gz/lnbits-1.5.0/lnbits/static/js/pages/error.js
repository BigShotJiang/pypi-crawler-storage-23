window.PageError = {
  template: '#page-error'
}
