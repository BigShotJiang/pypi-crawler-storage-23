from sites_conformes.config.settings import *  # NOSONAR # noqa: F401,F403

WHITENOISE_AUTOREFRESH = True
WHITENOISE_MANIFEST_STRICT = False

FORCE_SCRIPT_NAME = ""
WAGTAILADMIN_BASE_URL = "http://localhost"
