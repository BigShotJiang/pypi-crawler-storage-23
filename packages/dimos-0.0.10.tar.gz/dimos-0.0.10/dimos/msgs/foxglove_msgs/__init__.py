from dimos.msgs.foxglove_msgs.ImageAnnotations import ImageAnnotations

__all__ = ["ImageAnnotations"]
