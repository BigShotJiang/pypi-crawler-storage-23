# MoaT Source Code Management

% start synopsis
% start main

MoaT consists of a number of semi-independent modules which have
independent version numbers, dependencies, licenses, and whatnot.

The code in this module orchestrates building everything, keeping track of
submodule versions, etc..

% end synopsis
% end main
