"""Allow running instaharvest_v2 as a module: python -m instaharvest_v2"""
from .cli import main

if __name__ == "__main__":
    main()
