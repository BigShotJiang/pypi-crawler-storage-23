from plain.auth.views import LogoutView
from plain.urls import Router, include, path

from .builtin_views import (
    AdminIndexView,
    AdminSearchView,
    PinNavView,
    PreflightView,
    ReorderPinnedView,
    SettingDetailView,
    SettingsView,
    StyleGuideView,
    UnpinNavView,
)
from .impersonate.urls import ImpersonateRouter
from .views.registry import registry

__all__ = ["AdminRouter"]


class AdminRouter(Router):
    namespace = "admin"
    urls = [
        path("search/", AdminSearchView, name="search"),
        path("style/", StyleGuideView, name="style"),
        path("settings/", SettingsView, name="settings"),
        path("settings/<name>/", SettingDetailView, name="setting_detail"),
        path("preflight/", PreflightView, name="preflight"),
        path("logout/", LogoutView, name="logout"),
        path("_/pin/", PinNavView, name="pin"),
        path("_/unpin/", UnpinNavView, name="unpin"),
        path("_/reorder/", ReorderPinnedView, name="reorder"),
        include("impersonate/", ImpersonateRouter),
        include("", registry.get_urls()),
        path("", AdminIndexView, name="index"),
    ]
