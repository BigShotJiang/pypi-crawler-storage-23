"""Logging setup for worai CLI."""

from __future__ import annotations

import logging
import sys
from typing import Literal


LogFormat = Literal["text", "json"]


def setup_logging(level: str = "info", fmt: LogFormat = "text", quiet: bool = False) -> None:
    if quiet:
        level = "warning"
    level_value = getattr(logging, level.upper(), logging.INFO)
    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(level_value)
    if fmt != "json":
        handler.setFormatter(logging.Formatter("%(levelname)s %(name)s: %(message)s"))

    # Reconfigure root logging deterministically at CLI startup so third-party
    # logger setup cannot leak lower-severity messages through existing handlers.
    logging.basicConfig(level=level_value, handlers=[handler], force=True)
