"""spec-kitty-orchestrator: External orchestrator for the spec-kitty workflow system.

Interacts with spec-kitty exclusively via the versioned orchestrator-api CLI contract.
No direct file mutation; all state changes go through HostClient.
"""

__version__ = "0.1.0"
