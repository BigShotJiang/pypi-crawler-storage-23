"""
Comprehensive tests for PurgedTemporalCV.

UNIT TESTS: Use statsmodels AR processes for temporal autocorrelation.
INTEGRATION TESTS: Use cached Polygon fixtures (tests/fixtures/*.parquet).
"""

import numpy as np
import pandas as pd
import pytest
from pydantic_core import ValidationError
from statsmodels.tsa.arima_process import ArmaProcess

from boruta_quant.temporal.config import PurgedCVConfig
from boruta_quant.temporal.purged_cv import PurgedTemporalCV

# ============================================================================
# FIXTURES: Synthetic data with temporal autocorrelation (unit tests)
# ============================================================================


@pytest.fixture
def ar1_temporal_data() -> tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex]:
    """
    Generate synthetic temporal data with AR(1) autocorrelation.

    Uses statsmodels ArmaProcess for realistic temporal dependency.
    This is appropriate for UNIT TESTS verifying algorithmic correctness.
    """
    n_days = 500
    timestamps = pd.date_range("2020-01-01", periods=n_days, freq="B", tz="UTC")

    # AR(1) process: x[t] = 0.7 * x[t-1] + epsilon
    # Coefficients in statsmodels convention: [1, -ar_coef]
    ar_coef = 0.7
    ar = np.array([1, -ar_coef])
    ma = np.array([1])  # No MA component

    ar_process = ArmaProcess(ar, ma)
    np.random.seed(42)

    # Generate features with autocorrelation
    returns = ar_process.generate_sample(n_days, scale=0.01)  # ~1% daily vol

    X = pd.DataFrame(
        {
            "ret_1d": returns,
            "ret_5d": pd.Series(returns).rolling(5).sum().fillna(0).values,
            "vol_20d": pd.Series(returns).rolling(20).std().fillna(0.01).values,
            "momentum_20d": pd.Series(returns).rolling(20).mean().fillna(0).values,
            "noise": np.random.randn(n_days),  # Non-autocorrelated noise
        }
    )

    # Target: next-day return (realistic forward target)
    y = pd.Series(np.roll(returns, -1), name="target")
    y.iloc[-1] = 0  # No forward data for last day

    return X, y, timestamps


# Alias for backwards compatibility
@pytest.fixture
def spy_daily_data(
    ar1_temporal_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
) -> tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex]:
    """Alias for ar1_temporal_data - unit tests use synthetic AR(1) data."""
    return ar1_temporal_data


@pytest.fixture
def standard_config() -> PurgedCVConfig:
    """Standard test configuration."""
    return PurgedCVConfig(
        n_splits=5,
        purge_window_days=5,
        embargo_window_days=5,
        min_train_size=100,
        test_size_ratio=0.2,
    )


# ============================================================================
# CONFIG VALIDATION TESTS
# ============================================================================


class TestPurgedCVConfig:
    """Tests for PurgedCVConfig validation."""

    def test_valid_config_accepted(self) -> None:
        """Valid configuration should be accepted."""
        config = PurgedCVConfig(
            n_splits=5,
            purge_window_days=2,
            embargo_window_days=1,
            min_train_size=100,
            test_size_ratio=0.2,
        )
        assert config.n_splits == 5
        assert config.purge_window_days == 2

    def test_n_splits_less_than_2_crashes(self) -> None:
        """n_splits < 2 should crash."""
        with pytest.raises(ValidationError):
            PurgedCVConfig(
                n_splits=1,
                purge_window_days=2,
                embargo_window_days=1,
                min_train_size=100,
                test_size_ratio=0.2,
            )

    def test_n_splits_greater_than_20_crashes(self) -> None:
        """n_splits > 20 should crash."""
        with pytest.raises(ValidationError):
            PurgedCVConfig(
                n_splits=21,
                purge_window_days=2,
                embargo_window_days=1,
                min_train_size=100,
                test_size_ratio=0.2,
            )

    def test_negative_purge_window_crashes(self) -> None:
        """Negative purge_window_days should crash."""
        with pytest.raises(ValidationError):
            PurgedCVConfig(
                n_splits=5,
                purge_window_days=-1,
                embargo_window_days=1,
                min_train_size=100,
                test_size_ratio=0.2,
            )

    def test_negative_embargo_window_crashes(self) -> None:
        """Negative embargo_window_days should crash."""
        with pytest.raises(ValidationError):
            PurgedCVConfig(
                n_splits=5,
                purge_window_days=2,
                embargo_window_days=-1,
                min_train_size=100,
                test_size_ratio=0.2,
            )

    def test_zero_min_train_size_crashes(self) -> None:
        """min_train_size <= 0 should crash."""
        with pytest.raises(ValidationError):
            PurgedCVConfig(
                n_splits=5,
                purge_window_days=2,
                embargo_window_days=1,
                min_train_size=0,
                test_size_ratio=0.2,
            )

    def test_test_size_ratio_out_of_range_crashes(self) -> None:
        """test_size_ratio outside (0, 1) should crash."""
        with pytest.raises(ValidationError):
            PurgedCVConfig(
                n_splits=5,
                purge_window_days=2,
                embargo_window_days=1,
                min_train_size=100,
                test_size_ratio=1.5,
            )


# ============================================================================
# SPLIT INPUT VALIDATION TESTS
# ============================================================================


class TestPurgedTemporalCVInputValidation:
    """Tests for split() input validation."""

    def test_split_with_valid_data(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_config: PurgedCVConfig,
    ) -> None:
        """Valid data should produce splits."""
        X, y, timestamps = spy_daily_data
        cv = PurgedTemporalCV(standard_config)

        splits = list(cv.split(X, y, timestamps))

        assert len(splits) == 5

    def test_split_crashes_on_empty_data(self, standard_config: PurgedCVConfig) -> None:
        """Empty data should crash."""
        cv = PurgedTemporalCV(standard_config)

        with pytest.raises(AssertionError):
            list(
                cv.split(
                    pd.DataFrame(),
                    pd.Series(dtype=float),
                    pd.DatetimeIndex([]),
                )
            )

    def test_split_crashes_on_mismatched_lengths(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_config: PurgedCVConfig,
    ) -> None:
        """X, y, timestamps length mismatch should crash."""
        X, y, timestamps = spy_daily_data
        cv = PurgedTemporalCV(standard_config)

        with pytest.raises(AssertionError):
            list(cv.split(X, y.iloc[:100], timestamps))

    def test_split_crashes_on_unsorted_timestamps(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_config: PurgedCVConfig,
    ) -> None:
        """Unsorted timestamps should crash."""
        X, y, timestamps = spy_daily_data
        cv = PurgedTemporalCV(standard_config)

        shuffled_ts = timestamps[np.random.permutation(len(timestamps))]

        with pytest.raises(AssertionError):
            list(cv.split(X, y, shuffled_ts))

    def test_split_crashes_on_naive_timestamps(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_config: PurgedCVConfig,
    ) -> None:
        """Timezone-naive timestamps should crash."""
        X, y, _ = spy_daily_data
        cv = PurgedTemporalCV(standard_config)

        naive_ts = pd.date_range("2020-01-01", periods=len(X), freq="B")  # No tz

        with pytest.raises(AssertionError, match="timezone"):
            list(cv.split(X, y, naive_ts))


# ============================================================================
# TEMPORAL CONSISTENCY TESTS
# ============================================================================


class TestPurgedTemporalCVTemporalConsistency:
    """Tests for temporal consistency of splits."""

    def test_train_indices_before_val_indices(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_config: PurgedCVConfig,
    ) -> None:
        """All training data must precede validation data (accounting for purge)."""
        X, y, timestamps = spy_daily_data
        cv = PurgedTemporalCV(standard_config)

        for split in cv.split(X, y, timestamps):
            train_times = timestamps[split.train_indices]
            val_times = timestamps[split.val_indices]

            # Training data should be before purge window start
            purge_start = val_times.min() - pd.Timedelta(days=standard_config.purge_window_days)

            # All train times before purge start OR after embargo end
            embargo_end = val_times.max() + pd.Timedelta(days=standard_config.embargo_window_days)

            for t in train_times:
                assert t < purge_start or t > embargo_end, f"Training time {t} in forbidden zone"

    def test_no_overlap_between_train_and_val(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_config: PurgedCVConfig,
    ) -> None:
        """Train and validation indices must not overlap."""
        X, y, timestamps = spy_daily_data
        cv = PurgedTemporalCV(standard_config)

        for split in cv.split(X, y, timestamps):
            train_set = set(split.train_indices)
            val_set = set(split.val_indices)

            overlap = train_set & val_set
            assert len(overlap) == 0, f"Overlap: {overlap}"

    def test_purge_indices_not_in_training(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_config: PurgedCVConfig,
    ) -> None:
        """Purged indices must not appear in training set."""
        X, y, timestamps = spy_daily_data
        cv = PurgedTemporalCV(standard_config)

        for split in cv.split(X, y, timestamps):
            train_set = set(split.train_indices)
            purge_set = set(split.purge_indices)

            overlap = train_set & purge_set
            assert len(overlap) == 0, f"Purged data in training: {overlap}"

    def test_embargo_indices_not_in_training(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_config: PurgedCVConfig,
    ) -> None:
        """Embargoed indices must not appear in training set."""
        X, y, timestamps = spy_daily_data
        cv = PurgedTemporalCV(standard_config)

        for split in cv.split(X, y, timestamps):
            train_set = set(split.train_indices)
            embargo_set = set(split.embargo_indices)

            overlap = train_set & embargo_set
            assert len(overlap) == 0, f"Embargoed data in training: {overlap}"


# ============================================================================
# PURGE/EMBARGO LOGIC TESTS
# ============================================================================


class TestPurgedTemporalCVPurgeEmbargoLogic:
    """Tests for purge and embargo window logic."""

    def test_zero_purge_zero_embargo(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
    ) -> None:
        """Zero purge and embargo should have no excluded periods."""
        X, y, timestamps = spy_daily_data
        config = PurgedCVConfig(
            n_splits=3,
            purge_window_days=0,
            embargo_window_days=0,
            min_train_size=50,
            test_size_ratio=0.2,
        )
        cv = PurgedTemporalCV(config)

        for split in cv.split(X, y, timestamps):
            assert len(split.purge_indices) == 0
            assert len(split.embargo_indices) == 0

    def test_purge_only(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
    ) -> None:
        """Purge window only, no embargo."""
        X, y, timestamps = spy_daily_data
        config = PurgedCVConfig(
            n_splits=3,
            purge_window_days=5,
            embargo_window_days=0,
            min_train_size=50,
            test_size_ratio=0.2,
        )
        cv = PurgedTemporalCV(config)

        # At least one split should have purge indices (folds not at start of data)
        has_purge = False
        for split in cv.split(X, y, timestamps):
            if len(split.purge_indices) > 0:
                has_purge = True
            assert len(split.embargo_indices) == 0
        assert has_purge, "Expected at least one fold to have purge indices"

    def test_embargo_only(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
    ) -> None:
        """Embargo window only, no purge."""
        X, y, timestamps = spy_daily_data
        config = PurgedCVConfig(
            n_splits=3,
            purge_window_days=0,
            embargo_window_days=5,
            min_train_size=50,
            test_size_ratio=0.2,
        )
        cv = PurgedTemporalCV(config)

        for split in cv.split(X, y, timestamps):
            assert len(split.purge_indices) == 0
            assert len(split.embargo_indices) > 0

    def test_both_purge_and_embargo(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_config: PurgedCVConfig,
    ) -> None:
        """Both purge and embargo windows active."""
        X, y, timestamps = spy_daily_data
        cv = PurgedTemporalCV(standard_config)

        # At least one split should have purge indices (folds not at start of data)
        # At least one split should have embargo indices (folds not at end of data)
        has_purge = False
        has_embargo = False
        for split in cv.split(X, y, timestamps):
            if len(split.purge_indices) > 0:
                has_purge = True
            if len(split.embargo_indices) > 0:
                has_embargo = True
        assert has_purge, "Expected at least one fold to have purge indices"
        assert has_embargo, "Expected at least one fold to have embargo indices"

    @pytest.mark.parametrize("n_splits", [2, 5, 10])
    def test_varying_n_splits(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        n_splits: int,
    ) -> None:
        """Test with varying numbers of splits."""
        X, y, timestamps = spy_daily_data
        config = PurgedCVConfig(
            n_splits=n_splits,
            purge_window_days=3,
            embargo_window_days=3,
            min_train_size=50,
            test_size_ratio=0.15,
        )
        cv = PurgedTemporalCV(config)

        splits = list(cv.split(X, y, timestamps))

        # May have fewer splits if train size constraint not met
        assert len(splits) <= n_splits
        assert len(splits) > 0


# ============================================================================
# VALIDATION METHOD TESTS
# ============================================================================


class TestPurgedTemporalCVValidation:
    """Tests for validate_temporal_integrity method."""

    def test_validate_returns_true_for_valid_splits(
        self,
        spy_daily_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_config: PurgedCVConfig,
    ) -> None:
        """Validation should pass for properly constructed splits."""
        X, y, timestamps = spy_daily_data
        cv = PurgedTemporalCV(standard_config)

        result = cv.validate_temporal_integrity(X, y, timestamps)

        assert result is True

    def test_get_n_splits_returns_config_value(
        self,
        standard_config: PurgedCVConfig,
    ) -> None:
        """get_n_splits should return configured value."""
        cv = PurgedTemporalCV(standard_config)

        assert cv.get_n_splits() == standard_config.n_splits
