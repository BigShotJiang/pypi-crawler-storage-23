"""Tests for Rank IC metric."""

import numpy as np
import pytest

from boruta_quant.metrics.rank_ic import rank_ic, rank_ic_scorer


class TestRankIC:
    """Tests for rank_ic function."""

    def test_perfect_positive_correlation(self) -> None:
        """Test that identical rankings give IC = 1.0."""
        y_true = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        y_pred = np.array([10.0, 20.0, 30.0, 40.0, 50.0])

        ic = rank_ic(y_true, y_pred)

        assert ic == pytest.approx(1.0, abs=1e-10)

    def test_perfect_negative_correlation(self) -> None:
        """Test that opposite rankings give IC = -1.0."""
        y_true = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        y_pred = np.array([50.0, 40.0, 30.0, 20.0, 10.0])

        ic = rank_ic(y_true, y_pred)

        assert ic == pytest.approx(-1.0, abs=1e-10)

    def test_no_correlation(self) -> None:
        """Test uncorrelated data gives IC near 0."""
        np.random.seed(42)
        y_true = np.random.randn(1000)
        y_pred = np.random.randn(1000)

        ic = rank_ic(y_true, y_pred)

        # With 1000 samples, should be close to 0
        assert abs(ic) < 0.1

    def test_constant_y_true_returns_zero(self) -> None:
        """Test that constant y_true returns 0.0."""
        y_true = np.array([1.0, 1.0, 1.0, 1.0, 1.0])
        y_pred = np.array([1.0, 2.0, 3.0, 4.0, 5.0])

        ic = rank_ic(y_true, y_pred)

        assert ic == 0.0

    def test_constant_y_pred_returns_zero(self) -> None:
        """Test that constant y_pred returns 0.0."""
        y_true = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        y_pred = np.array([1.0, 1.0, 1.0, 1.0, 1.0])

        ic = rank_ic(y_true, y_pred)

        assert ic == 0.0

    def test_single_element_returns_zero(self) -> None:
        """Test that single element returns 0.0."""
        y_true = np.array([1.0])
        y_pred = np.array([2.0])

        ic = rank_ic(y_true, y_pred)

        assert ic == 0.0

    def test_returns_float(self) -> None:
        """Test that return type is float, not numpy scalar."""
        y_true = np.array([1.0, 2.0, 3.0])
        y_pred = np.array([1.0, 2.0, 3.0])

        ic = rank_ic(y_true, y_pred)

        assert isinstance(ic, float)


class TestRankICScorer:
    """Tests for sklearn-compatible rank_ic_scorer."""

    def test_scorer_callable(self) -> None:
        """Test that scorer is callable."""
        assert callable(rank_ic_scorer)

    def test_scorer_greater_is_better(self) -> None:
        """Test that scorer has greater_is_better=True."""
        # Access the _sign attribute that sklearn uses
        # For greater_is_better=True, _sign should be 1
        assert rank_ic_scorer._sign == 1
