"""Tests for scoring metrics."""
