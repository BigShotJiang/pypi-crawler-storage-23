"""Tests for directional_accuracy metric."""

import numpy as np
import pytest

from boruta_quant.metrics import directional_accuracy, directional_accuracy_scorer


class TestDirectionalAccuracyBasic:
    def test_perfect_prediction_returns_one(self) -> None:
        y_true = np.array([0.01, -0.02, 0.03, -0.01, 0.02])
        y_pred = np.array([0.5, -0.3, 0.8, -0.2, 0.4])
        assert directional_accuracy(y_true, y_pred) == 1.0

    def test_all_wrong_returns_zero(self) -> None:
        y_true = np.array([0.01, -0.02, 0.03, -0.01])
        y_pred = np.array([-0.5, 0.3, -0.8, 0.2])
        assert directional_accuracy(y_true, y_pred) == 0.0

    def test_half_correct_returns_half(self) -> None:
        y_true = np.array([0.01, -0.02, 0.03, -0.01])
        y_pred = np.array([0.5, 0.3, 0.8, -0.2])  # 1st, 3rd, 4th correct, 2nd wrong
        assert directional_accuracy(y_true, y_pred) == 0.75

    def test_single_sample(self) -> None:
        y_true = np.array([0.05])
        y_pred = np.array([0.1])
        assert directional_accuracy(y_true, y_pred) == 1.0

    def test_single_sample_wrong(self) -> None:
        y_true = np.array([0.05])
        y_pred = np.array([-0.1])
        assert directional_accuracy(y_true, y_pred) == 0.0


class TestDirectionalAccuracyZeroHandling:
    """Zero returns/predictions are ambiguous edge cases."""

    def test_both_zero_counts_as_correct(self) -> None:
        y_true = np.array([0.0, 0.01])
        y_pred = np.array([0.0, 0.05])
        assert directional_accuracy(y_true, y_pred) == 1.0

    def test_true_zero_pred_positive_counts_as_wrong(self) -> None:
        # sign(0) = 0, sign(0.1) = 1 → mismatch
        y_true = np.array([0.0])
        y_pred = np.array([0.1])
        assert directional_accuracy(y_true, y_pred) == 0.0

    def test_true_zero_pred_negative_counts_as_wrong(self) -> None:
        y_true = np.array([0.0])
        y_pred = np.array([-0.1])
        assert directional_accuracy(y_true, y_pred) == 0.0

    def test_true_positive_pred_zero_counts_as_wrong(self) -> None:
        y_true = np.array([0.01])
        y_pred = np.array([0.0])
        assert directional_accuracy(y_true, y_pred) == 0.0

    def test_all_zeros(self) -> None:
        y_true = np.array([0.0, 0.0, 0.0])
        y_pred = np.array([0.0, 0.0, 0.0])
        assert directional_accuracy(y_true, y_pred) == 1.0

    def test_mixed_with_zeros(self) -> None:
        y_true = np.array([0.01, 0.0, -0.02, 0.0])
        y_pred = np.array([0.05, 0.0, -0.10, 0.03])
        # correct: [True, True, True, False] → 0.75
        assert directional_accuracy(y_true, y_pred) == 0.75


class TestDirectionalAccuracyContractViolations:
    def test_empty_arrays_crash(self) -> None:
        with pytest.raises(AssertionError, match="at least 1"):
            directional_accuracy(np.array([]), np.array([]))

    def test_length_mismatch_crash(self) -> None:
        with pytest.raises(AssertionError, match="Length mismatch"):
            directional_accuracy(np.array([0.1, 0.2]), np.array([0.1]))


class TestDirectionalAccuracyReturnType:
    def test_returns_float(self) -> None:
        y_true = np.array([0.01, -0.02, 0.03])
        y_pred = np.array([0.5, -0.3, 0.8])
        result = directional_accuracy(y_true, y_pred)
        assert isinstance(result, float)

    def test_result_bounded_zero_to_one(self) -> None:
        rng = np.random.default_rng(42)
        y_true = rng.standard_normal(100)
        y_pred = rng.standard_normal(100)
        result = directional_accuracy(y_true, y_pred)
        assert 0.0 <= result <= 1.0


class TestDirectionalAccuracyLargeScale:
    def test_random_predictions_near_fifty_percent(self) -> None:
        """Random predictions should be ~50% directionally accurate."""
        rng = np.random.default_rng(42)
        y_true = rng.standard_normal(10_000)
        y_pred = rng.standard_normal(10_000)
        result = directional_accuracy(y_true, y_pred)
        assert 0.45 <= result <= 0.55

    def test_correlated_predictions_above_fifty(self) -> None:
        """Positively correlated predictions should beat 50%."""
        rng = np.random.default_rng(42)
        y_true = rng.standard_normal(10_000)
        y_pred = y_true + rng.standard_normal(10_000) * 0.5  # noisy but correlated
        result = directional_accuracy(y_true, y_pred)
        assert result > 0.6

    def test_negatively_correlated_below_fifty(self) -> None:
        """Negatively correlated predictions should be below 50%."""
        rng = np.random.default_rng(42)
        y_true = rng.standard_normal(10_000)
        y_pred = -y_true + rng.standard_normal(10_000) * 0.5
        result = directional_accuracy(y_true, y_pred)
        assert result < 0.4


class TestDirectionalAccuracyScorer:
    def test_scorer_exists(self) -> None:
        assert directional_accuracy_scorer is not None

    def test_scorer_is_callable(self) -> None:
        assert callable(directional_accuracy_scorer)
