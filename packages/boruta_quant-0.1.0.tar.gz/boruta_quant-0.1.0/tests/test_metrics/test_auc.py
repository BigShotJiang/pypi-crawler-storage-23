"""Tests for AUC metric."""

import numpy as np
import pytest
from sklearn.linear_model import LogisticRegression

from boruta_quant.metrics.auc import auc_score, auc_scorer


class TestAUCScore:
    """Tests for auc_score function."""

    def test_perfect_classification_returns_one(self) -> None:
        """Perfect predictions give AUC = 1.0."""
        y_true = np.array([0, 0, 0, 1, 1, 1])
        y_pred_proba = np.array([0.1, 0.2, 0.3, 0.7, 0.8, 0.9])

        auc = auc_score(y_true, y_pred_proba)

        assert auc == pytest.approx(1.0, abs=1e-10)

    def test_inverse_classification_returns_zero(self) -> None:
        """Perfectly wrong predictions give AUC = 0.0."""
        y_true = np.array([0, 0, 0, 1, 1, 1])
        y_pred_proba = np.array([0.9, 0.8, 0.7, 0.3, 0.2, 0.1])

        auc = auc_score(y_true, y_pred_proba)

        assert auc == pytest.approx(0.0, abs=1e-10)

    def test_random_classification_near_half(self) -> None:
        """Random predictions give AUC ≈ 0.5."""
        np.random.seed(42)
        y_true = np.random.randint(0, 2, 1000)
        y_pred_proba = np.random.rand(1000)

        auc = auc_score(y_true, y_pred_proba)

        assert 0.4 < auc < 0.6

    def test_single_class_returns_half(self) -> None:
        """Single class in y_true returns 0.5 (undefined AUC)."""
        y_true = np.array([1, 1, 1, 1, 1])
        y_pred_proba = np.array([0.1, 0.2, 0.3, 0.4, 0.5])

        auc = auc_score(y_true, y_pred_proba)

        assert auc == 0.5

    def test_length_mismatch_crashes(self) -> None:
        """Length mismatch should crash."""
        y_true = np.array([0, 1, 0])
        y_pred_proba = np.array([0.5, 0.5])

        with pytest.raises(AssertionError, match="Length mismatch"):
            auc_score(y_true, y_pred_proba)

    def test_single_sample_crashes(self) -> None:
        """Single sample should crash."""
        y_true = np.array([1])
        y_pred_proba = np.array([0.5])

        with pytest.raises(AssertionError, match="at least 2"):
            auc_score(y_true, y_pred_proba)

    def test_returns_float(self) -> None:
        """Return type is float, not numpy scalar."""
        y_true = np.array([0, 1])
        y_pred_proba = np.array([0.3, 0.7])

        auc = auc_score(y_true, y_pred_proba)

        assert isinstance(auc, float)


class TestAUCScorer:
    """Tests for sklearn-compatible auc_scorer."""

    def test_scorer_with_fitted_classifier(self) -> None:
        """auc_scorer works with fitted sklearn classifier."""
        np.random.seed(42)
        X = np.random.randn(100, 5)
        y = (X[:, 0] + X[:, 1] > 0).astype(int)

        clf = LogisticRegression(random_state=42)
        clf.fit(X, y)

        auc = auc_scorer(clf, X, y)

        assert 0.5 < auc <= 1.0  # Should be better than random

    def test_scorer_crashes_without_predict_proba(self) -> None:
        """Scorer crashes if estimator lacks predict_proba."""
        from sklearn.svm import LinearSVC

        np.random.seed(42)
        X = np.random.randn(50, 3)
        y = np.random.randint(0, 2, 50)

        clf = LinearSVC()
        clf.fit(X, y)

        with pytest.raises(AssertionError, match="predict_proba"):
            auc_scorer(clf, X, y)
