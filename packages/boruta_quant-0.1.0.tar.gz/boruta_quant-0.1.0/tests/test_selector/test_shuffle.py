"""
Tests for ShuffleMode enum and boundaries_to_eras helper.

MANDATORY: All tests use complete, working implementations.
MANDATORY: Enum comparisons use enum members, not string literals.
"""

import pandas as pd
import pytest

from boruta_quant.selector.shuffle import ShuffleMode, boundaries_to_eras


class TestShuffleModeEnum:
    """Test ShuffleMode enum definition and usage."""

    def test_enum_has_three_members(self) -> None:
        """ShuffleMode must have exactly 3 members."""
        members = list(ShuffleMode)
        assert len(members) == 3
        assert ShuffleMode.RANDOM in members
        assert ShuffleMode.BLOCK in members
        assert ShuffleMode.ERA in members

    def test_enum_members_are_distinct(self) -> None:
        """Each enum member must be unique."""
        assert ShuffleMode.RANDOM != ShuffleMode.BLOCK
        assert ShuffleMode.RANDOM != ShuffleMode.ERA
        assert ShuffleMode.BLOCK != ShuffleMode.ERA

    def test_enum_identity_comparison(self) -> None:
        """Enum members compare by identity, not string value."""
        mode = ShuffleMode.RANDOM
        assert mode is ShuffleMode.RANDOM
        assert mode == ShuffleMode.RANDOM

    def test_enum_iteration_order(self) -> None:
        """Enum iteration returns members in definition order."""
        modes = list(ShuffleMode)
        assert modes[0] is ShuffleMode.RANDOM
        assert modes[1] is ShuffleMode.BLOCK
        assert modes[2] is ShuffleMode.ERA


class TestBoundariesToErasBasicConversion:
    """Test basic era boundary conversion."""

    def test_single_era_covers_all_timestamps(self) -> None:
        """Single boundary covering all timestamps assigns era 0."""
        timestamps = pd.date_range("2020-01-01", periods=10, freq="D", tz="UTC")
        boundaries = [
            (
                pd.Timestamp("2020-01-01", tz="UTC"),
                pd.Timestamp("2020-01-15", tz="UTC"),
            ),
        ]

        eras = boundaries_to_eras(timestamps, boundaries)

        assert len(eras) == 10
        assert set(eras.unique()) == {0}
        assert (eras == 0).all()

    def test_two_eras_split_correctly(self) -> None:
        """Two non-overlapping boundaries assign eras 0 and 1."""
        timestamps = pd.date_range("2020-01-01", periods=10, freq="D", tz="UTC")
        # Era 0: Jan 1-5 (5 days), Era 1: Jan 6-10 (5 days)
        boundaries = [
            (
                pd.Timestamp("2020-01-01", tz="UTC"),
                pd.Timestamp("2020-01-06", tz="UTC"),
            ),
            (
                pd.Timestamp("2020-01-06", tz="UTC"),
                pd.Timestamp("2020-01-11", tz="UTC"),
            ),
        ]

        eras = boundaries_to_eras(timestamps, boundaries)

        assert set(eras.unique()) == {0, 1}
        assert (eras.iloc[:5] == 0).all()
        assert (eras.iloc[5:] == 1).all()

    def test_three_eras_with_unequal_sizes(self) -> None:
        """Multiple eras with different sizes are correctly assigned."""
        timestamps = pd.date_range("2020-01-01", periods=20, freq="D", tz="UTC")
        # Era 0: 5 days, Era 1: 10 days, Era 2: 5 days
        boundaries = [
            (
                pd.Timestamp("2020-01-01", tz="UTC"),
                pd.Timestamp("2020-01-06", tz="UTC"),
            ),
            (
                pd.Timestamp("2020-01-06", tz="UTC"),
                pd.Timestamp("2020-01-16", tz="UTC"),
            ),
            (
                pd.Timestamp("2020-01-16", tz="UTC"),
                pd.Timestamp("2020-01-21", tz="UTC"),
            ),
        ]

        eras = boundaries_to_eras(timestamps, boundaries)

        assert set(eras.unique()) == {0, 1, 2}
        assert (eras.iloc[:5] == 0).all()
        assert (eras.iloc[5:15] == 1).all()
        assert (eras.iloc[15:] == 2).all()


class TestBoundariesToErasEdgeCases:
    """Test edge cases and boundary conditions."""

    def test_boundary_start_is_inclusive(self) -> None:
        """Boundary start timestamp is included in the era."""
        timestamps = pd.DatetimeIndex([pd.Timestamp("2020-01-05", tz="UTC")], tz="UTC")
        boundaries = [
            (
                pd.Timestamp("2020-01-05", tz="UTC"),
                pd.Timestamp("2020-01-10", tz="UTC"),
            ),
        ]

        eras = boundaries_to_eras(timestamps, boundaries)

        assert eras.iloc[0] == 0

    def test_boundary_end_is_exclusive(self) -> None:
        """Boundary end timestamp is NOT included in the era."""
        timestamps = pd.DatetimeIndex(
            [
                pd.Timestamp("2020-01-04", tz="UTC"),  # In era 0
                pd.Timestamp("2020-01-05", tz="UTC"),  # In era 1 (boundary end is exclusive)
            ],
            tz="UTC",
        )
        boundaries = [
            (
                pd.Timestamp("2020-01-01", tz="UTC"),
                pd.Timestamp("2020-01-05", tz="UTC"),
            ),
            (
                pd.Timestamp("2020-01-05", tz="UTC"),
                pd.Timestamp("2020-01-10", tz="UTC"),
            ),
        ]

        eras = boundaries_to_eras(timestamps, boundaries)

        assert eras.iloc[0] == 0
        assert eras.iloc[1] == 1

    def test_eras_index_matches_input_timestamps(self) -> None:
        """Output Series must have same index as input timestamps."""
        timestamps = pd.date_range("2020-01-01", periods=5, freq="D", tz="UTC")
        boundaries = [
            (
                pd.Timestamp("2020-01-01", tz="UTC"),
                pd.Timestamp("2020-01-10", tz="UTC"),
            ),
        ]

        eras = boundaries_to_eras(timestamps, boundaries)

        pd.testing.assert_index_equal(eras.index, timestamps)


class TestBoundariesToErasFailFast:
    """Test fail-fast validation."""

    def test_crashes_on_empty_boundaries(self) -> None:
        """Empty boundaries list must crash."""
        timestamps = pd.date_range("2020-01-01", periods=5, freq="D", tz="UTC")

        with pytest.raises(AssertionError, match="cannot be empty"):
            boundaries_to_eras(timestamps, [])

    def test_crashes_on_uncovered_timestamp(self) -> None:
        """Timestamp outside all boundaries must crash."""
        timestamps = pd.date_range("2020-01-01", periods=10, freq="D", tz="UTC")
        # Only covers Jan 1-5, leaves Jan 6-10 uncovered
        boundaries = [
            (
                pd.Timestamp("2020-01-01", tz="UTC"),
                pd.Timestamp("2020-01-06", tz="UTC"),
            ),
        ]

        with pytest.raises(AssertionError, match="not covered"):
            boundaries_to_eras(timestamps, boundaries)

    def test_crashes_on_gap_between_boundaries(self) -> None:
        """Gap between boundaries leaving timestamps uncovered must crash."""
        timestamps = pd.date_range("2020-01-01", periods=10, freq="D", tz="UTC")
        # Gap: Jan 4-6 is not covered
        boundaries = [
            (
                pd.Timestamp("2020-01-01", tz="UTC"),
                pd.Timestamp("2020-01-04", tz="UTC"),
            ),
            (
                pd.Timestamp("2020-01-07", tz="UTC"),
                pd.Timestamp("2020-01-11", tz="UTC"),
            ),
        ]

        with pytest.raises(AssertionError, match="not covered"):
            boundaries_to_eras(timestamps, boundaries)

    def test_error_message_includes_count(self) -> None:
        """Error message must include number of uncovered timestamps."""
        timestamps = pd.date_range("2020-01-01", periods=10, freq="D", tz="UTC")
        # Covers only 3 days, leaves 7 uncovered
        boundaries = [
            (
                pd.Timestamp("2020-01-01", tz="UTC"),
                pd.Timestamp("2020-01-04", tz="UTC"),
            ),
        ]

        with pytest.raises(AssertionError, match="7 timestamps not covered"):
            boundaries_to_eras(timestamps, boundaries)
