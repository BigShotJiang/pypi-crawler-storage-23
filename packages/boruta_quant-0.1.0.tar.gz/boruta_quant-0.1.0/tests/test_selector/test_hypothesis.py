"""
Tests for Boruta hypothesis testing functions.

Tests cover:
1. calculate_hits - threshold computation and hit counting
2. binomial_test_features - statistical decision making
3. tentative_rough_fix - median-based resolution
"""

import numpy as np
import pytest

from boruta_quant.selector.hypothesis import (
    binomial_test_features,
    calculate_hits,
    tentative_rough_fix,
)


class TestCalculateHits:
    """Test hit calculation logic."""

    def test_all_features_beat_100th_percentile_threshold(self) -> None:
        """Features above max shadow should all get hits at percentile=100."""
        feature_importances = {"f1": 1.0, "f2": 0.8}
        shadow_importances = {"shadow_f1": 0.5, "shadow_f2": 0.3}

        hits = calculate_hits(feature_importances, shadow_importances, percentile=100)

        # Max shadow is 0.5, so f1 (1.0) beats it, f2 (0.8) beats it
        assert hits == {"f1": 1, "f2": 1}

    def test_no_features_beat_100th_percentile_threshold(self) -> None:
        """Features below max shadow should get no hits at percentile=100."""
        feature_importances = {"f1": 0.2, "f2": 0.3}
        shadow_importances = {"shadow_f1": 0.5, "shadow_f2": 0.7}

        hits = calculate_hits(feature_importances, shadow_importances, percentile=100)

        # Max shadow is 0.7, neither feature beats it
        assert hits == {"f1": 0, "f2": 0}

    def test_partial_hits_with_percentile(self) -> None:
        """Only features above threshold percentile should get hits."""
        feature_importances = {"f1": 0.6, "f2": 0.4, "f3": 0.2}
        shadow_importances = {"s1": 0.1, "s2": 0.3, "s3": 0.5}

        # 50th percentile of shadows = median = 0.3
        hits = calculate_hits(feature_importances, shadow_importances, percentile=50)

        assert hits["f1"] == 1  # 0.6 > 0.3
        assert hits["f2"] == 1  # 0.4 > 0.3
        assert hits["f3"] == 0  # 0.2 < 0.3

    def test_empty_shadow_importances_crashes(self) -> None:
        """Empty shadow importances should crash."""
        feature_importances = {"f1": 0.5}
        shadow_importances: dict[str, float] = {}

        with pytest.raises(AssertionError, match="No shadow importances"):
            calculate_hits(feature_importances, shadow_importances, percentile=100)

    @pytest.mark.parametrize("percentile", [1, 25, 50, 75, 100])
    def test_percentile_parameter_affects_threshold(self, percentile: int) -> None:
        """Different percentiles should produce different thresholds."""
        feature_importances = {"f1": 0.5}
        shadow_importances = {"s1": 0.1, "s2": 0.3, "s3": 0.5, "s4": 0.7, "s5": 0.9}

        hits = calculate_hits(feature_importances, shadow_importances, percentile)

        # f1=0.5 should beat lower percentiles but not higher ones
        # At percentile=50, threshold=0.5, and 0.5 is NOT > 0.5 (strict inequality)
        if percentile < 50:
            assert hits["f1"] == 1
        else:
            assert hits["f1"] == 0


class TestBinomialTestFeatures:
    """Test statistical feature classification."""

    def test_all_hits_means_acceptance(self) -> None:
        """Feature with 100% hit rate should be accepted."""
        cumulative_hits = {"f1": 20}  # 20/20 hits
        n_iterations = 20
        alpha = 0.05

        accepted, rejected, tentative = binomial_test_features(cumulative_hits, n_iterations, alpha)

        assert "f1" in accepted
        assert "f1" not in rejected
        assert "f1" not in tentative

    def test_no_hits_means_rejection(self) -> None:
        """Feature with 0% hit rate should be rejected."""
        cumulative_hits = {"f1": 0}  # 0/20 hits
        n_iterations = 20
        alpha = 0.05

        accepted, rejected, tentative = binomial_test_features(cumulative_hits, n_iterations, alpha)

        assert "f1" not in accepted
        assert "f1" in rejected
        assert "f1" not in tentative

    def test_half_hits_means_tentative(self) -> None:
        """Feature with ~50% hit rate should be tentative."""
        cumulative_hits = {"f1": 10}  # 10/20 hits
        n_iterations = 20
        alpha = 0.05

        accepted, rejected, tentative = binomial_test_features(cumulative_hits, n_iterations, alpha)

        assert "f1" not in accepted
        assert "f1" not in rejected
        assert "f1" in tentative

    def test_bonferroni_correction_applied(self) -> None:
        """Multiple features should have stricter significance threshold."""
        # With 10 features, alpha_corrected = 0.05/10 = 0.005
        cumulative_hits = {f"f{i}": 15 for i in range(10)}  # 15/20 = 75%
        n_iterations = 20
        alpha = 0.05

        accepted, rejected, tentative = binomial_test_features(cumulative_hits, n_iterations, alpha)

        # 75% hit rate with Bonferroni correction - may or may not be significant
        # depending on exact binomial p-value
        total_classified = len(accepted) + len(rejected) + len(tentative)
        assert total_classified == 10  # All features classified

    def test_crashes_on_zero_iterations(self) -> None:
        """Zero iterations should crash."""
        with pytest.raises(AssertionError, match="at least 1 iteration"):
            binomial_test_features({"f1": 0}, n_iterations=0, alpha=0.05)

    def test_crashes_on_invalid_alpha(self) -> None:
        """Alpha outside (0, 1) should crash."""
        with pytest.raises(AssertionError, match="Invalid alpha"):
            binomial_test_features({"f1": 5}, n_iterations=10, alpha=1.5)

    def test_crashes_on_no_features(self) -> None:
        """Empty feature dict should crash."""
        with pytest.raises(AssertionError, match="No features to test"):
            binomial_test_features({}, n_iterations=10, alpha=0.05)

    def test_no_overlap_between_categories(self) -> None:
        """Accepted, rejected, tentative must be mutually exclusive."""
        cumulative_hits = {"f1": 20, "f2": 0, "f3": 10, "f4": 15, "f5": 5}
        n_iterations = 20
        alpha = 0.05

        accepted, rejected, tentative = binomial_test_features(cumulative_hits, n_iterations, alpha)

        accepted_set = set(accepted)
        rejected_set = set(rejected)
        tentative_set = set(tentative)

        assert len(accepted_set & rejected_set) == 0
        assert len(accepted_set & tentative_set) == 0
        assert len(rejected_set & tentative_set) == 0

    def test_all_features_classified(self) -> None:
        """All input features must be classified."""
        cumulative_hits = {f"f{i}": i for i in range(10)}
        n_iterations = 10
        alpha = 0.05

        accepted, rejected, tentative = binomial_test_features(cumulative_hits, n_iterations, alpha)

        all_classified = set(accepted) | set(rejected) | set(tentative)
        assert all_classified == set(cumulative_hits.keys())


class TestTentativeRoughFix:
    """Test tentative feature resolution."""

    def test_empty_tentative_returns_empty(self) -> None:
        """No tentative features should return empty lists."""
        importance_history = np.array([[0.5, 0.3]])
        shadow_max_history = np.array([0.4])
        feature_names = ["f1", "f2"]

        newly_accepted, newly_rejected = tentative_rough_fix(
            tentative_features=[],
            importance_history=importance_history,
            shadow_max_history=shadow_max_history,
            feature_names=feature_names,
        )

        assert newly_accepted == []
        assert newly_rejected == []

    def test_feature_above_median_shadow_accepted(self) -> None:
        """Tentative feature with median > median_shadow_max should be accepted."""
        # Feature f1 has median importance 0.6
        # Shadow max history has median 0.4
        importance_history = np.array(
            [
                [0.5, 0.3],
                [0.7, 0.3],
                [0.6, 0.3],
            ]
        )
        shadow_max_history = np.array([0.3, 0.5, 0.4])  # median = 0.4
        feature_names = ["f1", "f2"]

        newly_accepted, newly_rejected = tentative_rough_fix(
            tentative_features=["f1"],
            importance_history=importance_history,
            shadow_max_history=shadow_max_history,
            feature_names=feature_names,
        )

        assert "f1" in newly_accepted
        assert "f1" not in newly_rejected

    def test_feature_below_median_shadow_rejected(self) -> None:
        """Tentative feature with median < median_shadow_max should be rejected."""
        # Feature f2 has median importance 0.3
        # Shadow max history has median 0.4
        importance_history = np.array(
            [
                [0.5, 0.3],
                [0.7, 0.3],
                [0.6, 0.3],
            ]
        )
        shadow_max_history = np.array([0.3, 0.5, 0.4])  # median = 0.4
        feature_names = ["f1", "f2"]

        newly_accepted, newly_rejected = tentative_rough_fix(
            tentative_features=["f2"],
            importance_history=importance_history,
            shadow_max_history=shadow_max_history,
            feature_names=feature_names,
        )

        assert "f2" not in newly_accepted
        assert "f2" in newly_rejected

    def test_multiple_tentative_features_resolved(self) -> None:
        """All tentative features should be resolved."""
        importance_history = np.array(
            [
                [0.6, 0.2, 0.5],
                [0.7, 0.3, 0.4],
                [0.5, 0.2, 0.6],
            ]
        )
        shadow_max_history = np.array([0.4, 0.45, 0.5])  # median = 0.45
        feature_names = ["f1", "f2", "f3"]

        newly_accepted, newly_rejected = tentative_rough_fix(
            tentative_features=["f1", "f2", "f3"],
            importance_history=importance_history,
            shadow_max_history=shadow_max_history,
            feature_names=feature_names,
        )

        # f1: median=0.6 > 0.45 -> accepted
        # f2: median=0.2 < 0.45 -> rejected
        # f3: median=0.5 > 0.45 -> accepted
        assert set(newly_accepted) == {"f1", "f3"}
        assert set(newly_rejected) == {"f2"}
