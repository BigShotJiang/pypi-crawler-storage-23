"""
Integration tests for BorutaSelector.

These tests verify end-to-end behavior using REAL objects:
- Real PermutationImportanceOracle (not mocked)
- Real PurgedTemporalCV (not mocked)
- Real RandomForestRegressor (not mocked)

MANDATORY: Tests verify informative features are selected over noise.
"""

import pandas as pd
import pytest
from sklearn.ensemble import RandomForestRegressor

from boruta_quant.oracle import PermutationImportanceOracle
from boruta_quant.profiling import ProfilingSession
from boruta_quant.selector import BorutaResult, BorutaSelector, BorutaSelectorConfig
from boruta_quant.selector.shuffle import ShuffleMode
from boruta_quant.temporal import PurgedCVConfig, PurgedTemporalCV


class TestBorutaSelectorProtocol:
    """Test BorutaSelector protocol and API."""

    def test_selector_has_fit_method(
        self,
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
    ) -> None:
        """Selector must have fit method."""
        cv = PurgedTemporalCV(standard_cv_config)
        selector = BorutaSelector(
            config=standard_selector_config,
            oracle=standard_oracle,
            cv=cv,
        )
        assert hasattr(selector, "fit")
        assert callable(selector.fit)

    def test_selector_has_result_property(
        self,
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
    ) -> None:
        """Selector must have result property defined."""
        cv = PurgedTemporalCV(standard_cv_config)
        selector = BorutaSelector(
            config=standard_selector_config,
            oracle=standard_oracle,
            cv=cv,
        )
        # Check result is defined as a property (not by calling it)
        assert "result" in dir(selector)
        assert isinstance(type(selector).result, property)

    def test_result_access_before_fit_crashes(
        self,
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
    ) -> None:
        """Accessing result before fit should crash."""
        cv = PurgedTemporalCV(standard_cv_config)
        selector = BorutaSelector(
            config=standard_selector_config,
            oracle=standard_oracle,
            cv=cv,
        )
        with pytest.raises(AssertionError, match="not fitted"):
            _ = selector.result


class TestBorutaSelectorFit:
    """Test fit() method behavior."""

    def test_fit_returns_boruta_result(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
        rf_model: RandomForestRegressor,
    ) -> None:
        """fit() must return BorutaResult."""
        X, y, timestamps = informative_regression_data
        cv = PurgedTemporalCV(standard_cv_config)
        selector = BorutaSelector(
            config=standard_selector_config,
            oracle=standard_oracle,
            cv=cv,
        )

        result = selector.fit(X, y, timestamps, rf_model)

        assert isinstance(result, BorutaResult)

    def test_result_property_matches_fit_return(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
        rf_model: RandomForestRegressor,
    ) -> None:
        """result property must match fit() return value."""
        X, y, timestamps = informative_regression_data
        cv = PurgedTemporalCV(standard_cv_config)
        selector = BorutaSelector(
            config=standard_selector_config,
            oracle=standard_oracle,
            cv=cv,
        )

        fit_result = selector.fit(X, y, timestamps, rf_model)

        assert selector.result is fit_result

    def test_all_features_classified(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
        rf_model: RandomForestRegressor,
    ) -> None:
        """All input features must appear in result."""
        X, y, timestamps = informative_regression_data
        cv = PurgedTemporalCV(standard_cv_config)
        selector = BorutaSelector(
            config=standard_selector_config,
            oracle=standard_oracle,
            cv=cv,
        )

        result = selector.fit(X, y, timestamps, rf_model)

        all_classified = (
            set(result.accepted_features)
            | set(result.rejected_features)
            | set(result.tentative_features)
        )
        assert all_classified == set(X.columns)

    def test_feature_hits_tracks_all_features(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
        rf_model: RandomForestRegressor,
    ) -> None:
        """feature_hits must contain all original features."""
        X, y, timestamps = informative_regression_data
        cv = PurgedTemporalCV(standard_cv_config)
        selector = BorutaSelector(
            config=standard_selector_config,
            oracle=standard_oracle,
            cv=cv,
        )

        result = selector.fit(X, y, timestamps, rf_model)

        assert set(result.feature_hits.keys()) == set(X.columns)


class TestBorutaSelectorInformativeVsNoise:
    """Test that selector identifies informative features over noise."""

    def test_informative_features_more_likely_accepted(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_cv_config: PurgedCVConfig,
        rf_model: RandomForestRegressor,
    ) -> None:
        """Informative features should be accepted more often than noise."""
        X, y, timestamps = informative_regression_data

        # Use more trials for statistical power
        config = BorutaSelectorConfig(
            n_trials=20,
            percentile=100,
            alpha=0.05,
            two_step=True,
            random_state=42,
        )
        cv = PurgedTemporalCV(standard_cv_config)
        oracle = PermutationImportanceOracle(n_repeats=10, random_state=42)
        selector = BorutaSelector(config=config, oracle=oracle, cv=cv)

        result = selector.fit(X, y, timestamps, rf_model)

        # Count informative in accepted vs noise in accepted
        informative_names = {f"f{i}" for i in range(5)}
        noise_names = {f"noise_{i}" for i in range(5)}

        informative_accepted = len(informative_names & set(result.accepted_features))
        noise_accepted = len(noise_names & set(result.accepted_features))

        # Informative should dominate accepted set
        assert informative_accepted >= noise_accepted, (
            f"Expected more informative ({informative_accepted}) than noise ({noise_accepted}) in accepted"
        )

    def test_noise_features_more_likely_rejected(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_cv_config: PurgedCVConfig,
        rf_model: RandomForestRegressor,
    ) -> None:
        """Noise features should be rejected more often than informative."""
        X, y, timestamps = informative_regression_data

        config = BorutaSelectorConfig(
            n_trials=20,
            percentile=100,
            alpha=0.05,
            two_step=True,
            random_state=42,
        )
        cv = PurgedTemporalCV(standard_cv_config)
        oracle = PermutationImportanceOracle(n_repeats=10, random_state=42)
        selector = BorutaSelector(config=config, oracle=oracle, cv=cv)

        result = selector.fit(X, y, timestamps, rf_model)

        informative_names = {f"f{i}" for i in range(5)}
        noise_names = {f"noise_{i}" for i in range(5)}

        informative_rejected = len(informative_names & set(result.rejected_features))
        noise_rejected = len(noise_names & set(result.rejected_features))

        # Noise should dominate rejected set
        assert noise_rejected >= informative_rejected, (
            f"Expected more noise ({noise_rejected}) than informative ({informative_rejected}) in rejected"
        )

    def test_at_least_one_informative_accepted(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_cv_config: PurgedCVConfig,
        rf_model: RandomForestRegressor,
    ) -> None:
        """At least one informative feature should be accepted."""
        X, y, timestamps = informative_regression_data

        config = BorutaSelectorConfig(
            n_trials=15,
            percentile=100,
            alpha=0.05,
            two_step=True,
            random_state=42,
        )
        cv = PurgedTemporalCV(standard_cv_config)
        oracle = PermutationImportanceOracle(n_repeats=10, random_state=42)
        selector = BorutaSelector(config=config, oracle=oracle, cv=cv)

        result = selector.fit(X, y, timestamps, rf_model)

        informative_names = {f"f{i}" for i in range(5)}
        informative_accepted = informative_names & set(result.accepted_features)

        assert len(informative_accepted) >= 1, (
            f"Expected at least 1 informative feature accepted, got {informative_accepted}"
        )


class TestBorutaSelectorReproducibility:
    """Test reproducibility with random state."""

    def test_same_random_state_same_result(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_cv_config: PurgedCVConfig,
        rf_model: RandomForestRegressor,
    ) -> None:
        """Same random_state should produce identical results."""
        X, y, timestamps = informative_regression_data

        config1 = BorutaSelectorConfig(
            n_trials=5, percentile=100, alpha=0.05, two_step=True, random_state=42
        )
        config2 = BorutaSelectorConfig(
            n_trials=5, percentile=100, alpha=0.05, two_step=True, random_state=42
        )

        oracle1 = PermutationImportanceOracle(n_repeats=3, random_state=42)
        oracle2 = PermutationImportanceOracle(n_repeats=3, random_state=42)

        cv1 = PurgedTemporalCV(standard_cv_config)
        cv2 = PurgedTemporalCV(standard_cv_config)

        selector1 = BorutaSelector(config=config1, oracle=oracle1, cv=cv1)
        selector2 = BorutaSelector(config=config2, oracle=oracle2, cv=cv2)

        result1 = selector1.fit(X, y, timestamps, rf_model)
        result2 = selector2.fit(X, y, timestamps, rf_model)

        assert result1.accepted_features == result2.accepted_features
        assert result1.rejected_features == result2.rejected_features
        assert result1.n_iterations == result2.n_iterations


class TestBorutaSelectorProfiling:
    """Test profiling integration."""

    def test_fit_accepts_profiling_session(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
        rf_model: RandomForestRegressor,
    ) -> None:
        """fit() should accept ProfilingSession without error."""
        X, y, timestamps = informative_regression_data
        cv = PurgedTemporalCV(standard_cv_config)
        selector = BorutaSelector(
            config=standard_selector_config,
            oracle=standard_oracle,
            cv=cv,
        )
        session = ProfilingSession()

        # Should not raise
        result = selector.fit(X, y, timestamps, rf_model, profiling_session=session)

        assert isinstance(result, BorutaResult)

    def test_profiling_session_records_operations(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
        rf_model: RandomForestRegressor,
    ) -> None:
        """ProfilingSession should record oracle operations."""
        X, y, timestamps = informative_regression_data
        cv = PurgedTemporalCV(standard_cv_config)
        selector = BorutaSelector(
            config=standard_selector_config,
            oracle=standard_oracle,
            cv=cv,
        )
        session = ProfilingSession()

        selector.fit(X, y, timestamps, rf_model, profiling_session=session)
        results = session.get_results()

        # Should have recorded at least one oracle operation
        assert len(results) > 0
        # Labels should contain "oracle"
        oracle_labels = [k for k in results if "oracle" in k]
        assert len(oracle_labels) > 0


class TestBorutaSelectorInputValidation:
    """Test input validation - fail-fast on bad inputs."""

    def test_crashes_on_naive_timestamps(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
        rf_model: RandomForestRegressor,
    ) -> None:
        """Timezone-naive timestamps should crash."""
        X, y, _ = informative_regression_data
        naive_timestamps = pd.date_range("2020-01-01", periods=len(X), freq="h")  # No tz

        cv = PurgedTemporalCV(standard_cv_config)
        selector = BorutaSelector(
            config=standard_selector_config,
            oracle=standard_oracle,
            cv=cv,
        )

        with pytest.raises(AssertionError, match="timezone"):
            selector.fit(X, y, naive_timestamps, rf_model)

    def test_crashes_on_length_mismatch(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
        rf_model: RandomForestRegressor,
    ) -> None:
        """X, y, timestamps length mismatch should crash."""
        X, y, timestamps = informative_regression_data

        cv = PurgedTemporalCV(standard_cv_config)
        selector = BorutaSelector(
            config=standard_selector_config,
            oracle=standard_oracle,
            cv=cv,
        )

        with pytest.raises(AssertionError):
            selector.fit(X, y.iloc[:100], timestamps, rf_model)


class TestBorutaSelectorTwoStep:
    """Test two_step parameter behavior."""

    def test_two_step_false_may_have_tentative(
        self,
        ar1_temporal_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_cv_config: PurgedCVConfig,
        rf_model: RandomForestRegressor,
    ) -> None:
        """two_step=False may leave features tentative."""
        X, y, timestamps = ar1_temporal_data

        config = BorutaSelectorConfig(
            n_trials=5,  # Few trials = more likely tentative
            percentile=100,
            alpha=0.05,
            two_step=False,  # Don't resolve tentative
            random_state=42,
        )
        cv = PurgedTemporalCV(standard_cv_config)
        oracle = PermutationImportanceOracle(n_repeats=3, random_state=42)
        selector = BorutaSelector(config=config, oracle=oracle, cv=cv)

        result = selector.fit(X, y, timestamps, rf_model)

        # With few trials, likely some tentative remain
        # (Not guaranteed, but likely with weak features)
        total = (
            len(result.accepted_features)
            + len(result.rejected_features)
            + len(result.tentative_features)
        )
        assert total == len(X.columns)

    def test_two_step_true_resolves_tentative(
        self,
        ar1_temporal_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_cv_config: PurgedCVConfig,
        rf_model: RandomForestRegressor,
    ) -> None:
        """two_step=True should reduce tentative count via TentativeRoughFix."""
        X, y, timestamps = ar1_temporal_data

        # Run with two_step=False
        config_false = BorutaSelectorConfig(
            n_trials=5, percentile=100, alpha=0.05, two_step=False, random_state=42
        )
        cv_false = PurgedTemporalCV(standard_cv_config)
        oracle_false = PermutationImportanceOracle(n_repeats=3, random_state=42)
        selector_false = BorutaSelector(config=config_false, oracle=oracle_false, cv=cv_false)
        result_false = selector_false.fit(X, y, timestamps, rf_model)

        # Run with two_step=True
        config_true = BorutaSelectorConfig(
            n_trials=5, percentile=100, alpha=0.05, two_step=True, random_state=42
        )
        cv_true = PurgedTemporalCV(standard_cv_config)
        oracle_true = PermutationImportanceOracle(n_repeats=3, random_state=42)
        selector_true = BorutaSelector(config=config_true, oracle=oracle_true, cv=cv_true)
        result_true = selector_true.fit(X, y, timestamps, rf_model)

        # two_step=True should have <= tentative than two_step=False
        assert len(result_true.tentative_features) <= len(result_false.tentative_features)


class TestSelectorEraIntegration:
    """Test BorutaSelector.fit() with era parameters."""

    def test_fit_accepts_eras_parameter(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
        rf_model: RandomForestRegressor,
    ) -> None:
        """fit() accepts eras parameter for ERA mode."""
        X, y, timestamps = informative_regression_data

        # Update config for ERA mode
        era_config = BorutaSelectorConfig(
            n_trials=standard_selector_config.n_trials,
            percentile=standard_selector_config.percentile,
            alpha=standard_selector_config.alpha,
            two_step=standard_selector_config.two_step,
            random_state=standard_selector_config.random_state,
            shadow_shuffle_mode=ShuffleMode.ERA,
        )

        selector = BorutaSelector(
            config=era_config,
            oracle=standard_oracle,
            cv=PurgedTemporalCV(standard_cv_config),
        )

        # Create era labels (10 eras of 100 samples each)
        eras = pd.Series([i // 100 for i in range(len(X))])

        result = selector.fit(X, y, timestamps, rf_model, eras=eras)

        assert result is not None
        assert isinstance(result.accepted_features, tuple)

    def test_fit_accepts_era_boundaries_parameter(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_selector_config: BorutaSelectorConfig,
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
        rf_model: RandomForestRegressor,
    ) -> None:
        """fit() accepts era_boundaries parameter for ERA mode."""
        X, y, timestamps = informative_regression_data

        # Update config for ERA mode
        era_config = BorutaSelectorConfig(
            n_trials=standard_selector_config.n_trials,
            percentile=standard_selector_config.percentile,
            alpha=standard_selector_config.alpha,
            two_step=standard_selector_config.two_step,
            random_state=standard_selector_config.random_state,
            shadow_shuffle_mode=ShuffleMode.ERA,
        )

        selector = BorutaSelector(
            config=era_config,
            oracle=standard_oracle,
            cv=PurgedTemporalCV(standard_cv_config),
        )

        # Create era boundaries covering all timestamps
        era_boundaries = [
            (timestamps[0], timestamps[500]),
            (timestamps[500], timestamps[-1] + pd.Timedelta(hours=1)),
        ]

        result = selector.fit(X, y, timestamps, rf_model, era_boundaries=era_boundaries)

        assert result is not None

    def test_fit_crashes_era_mode_without_eras_or_boundaries(
        self,
        informative_regression_data: tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex],
        standard_cv_config: PurgedCVConfig,
        standard_oracle: PermutationImportanceOracle,
        rf_model: RandomForestRegressor,
    ) -> None:
        """fit() crashes in ERA mode without eras or era_boundaries."""
        X, y, timestamps = informative_regression_data

        era_config = BorutaSelectorConfig(
            n_trials=5,
            percentile=100,
            alpha=0.05,
            two_step=True,
            random_state=42,
            shadow_shuffle_mode=ShuffleMode.ERA,
        )

        selector = BorutaSelector(
            config=era_config,
            oracle=standard_oracle,
            cv=PurgedTemporalCV(standard_cv_config),
        )

        with pytest.raises(AssertionError, match="ERA mode requires eras or era_boundaries"):
            selector.fit(X, y, timestamps, rf_model)
