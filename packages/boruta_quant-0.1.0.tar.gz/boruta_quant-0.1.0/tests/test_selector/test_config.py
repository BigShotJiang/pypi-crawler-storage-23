"""
Tests for BorutaSelectorConfig validation.

MANDATORY: All config fields are REQUIRED (no defaults).
MANDATORY: Validators use assert for fail-fast.
"""

import pytest
from pydantic import ValidationError

from boruta_quant.selector.config import BorutaSelectorConfig
from boruta_quant.selector.shuffle import ShuffleMode


class TestBorutaSelectorConfigValidation:
    """Test configuration validation rules."""

    def test_valid_config_with_all_required_fields(self) -> None:
        """Valid configuration with all fields should be accepted."""
        config = BorutaSelectorConfig(
            n_trials=20,
            percentile=100,
            alpha=0.05,
            two_step=True,
            random_state=42,
        )
        assert config.n_trials == 20
        assert config.percentile == 100
        assert config.alpha == 0.05
        assert config.two_step is True
        assert config.random_state == 42

    def test_random_state_none_accepted(self) -> None:
        """random_state=None should be accepted (explicit None required)."""
        config = BorutaSelectorConfig(
            n_trials=10,
            percentile=95,
            alpha=0.01,
            two_step=False,
            random_state=None,
        )
        assert config.random_state is None

    def test_missing_n_trials_crashes(self) -> None:
        """Missing n_trials should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                percentile=100,
                alpha=0.05,
                two_step=True,
                random_state=42,
            )  # type: ignore[call-arg]

    def test_missing_percentile_crashes(self) -> None:
        """Missing percentile should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=20,
                alpha=0.05,
                two_step=True,
                random_state=42,
            )  # type: ignore[call-arg]

    def test_missing_alpha_crashes(self) -> None:
        """Missing alpha should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=20,
                percentile=100,
                two_step=True,
                random_state=42,
            )  # type: ignore[call-arg]

    def test_missing_two_step_crashes(self) -> None:
        """Missing two_step should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=20,
                percentile=100,
                alpha=0.05,
                random_state=42,
            )  # type: ignore[call-arg]

    def test_missing_random_state_crashes(self) -> None:
        """Missing random_state should crash (None must be explicit)."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=20,
                percentile=100,
                alpha=0.05,
                two_step=True,
            )  # type: ignore[call-arg]


class TestBorutaSelectorConfigNTrialsValidation:
    """Test n_trials validation."""

    def test_n_trials_zero_crashes(self) -> None:
        """n_trials=0 should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=0,
                percentile=100,
                alpha=0.05,
                two_step=True,
                random_state=42,
            )

    def test_n_trials_negative_crashes(self) -> None:
        """n_trials < 0 should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=-5,
                percentile=100,
                alpha=0.05,
                two_step=True,
                random_state=42,
            )

    def test_n_trials_over_1000_crashes(self) -> None:
        """n_trials > 1000 should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=1001,
                percentile=100,
                alpha=0.05,
                two_step=True,
                random_state=42,
            )

    @pytest.mark.parametrize("n_trials", [1, 50, 100, 500, 1000])
    def test_valid_n_trials_range(self, n_trials: int) -> None:
        """Valid n_trials in range [1, 1000] should be accepted."""
        config = BorutaSelectorConfig(
            n_trials=n_trials,
            percentile=100,
            alpha=0.05,
            two_step=True,
            random_state=42,
        )
        assert config.n_trials == n_trials


class TestBorutaSelectorConfigPercentileValidation:
    """Test percentile validation."""

    def test_percentile_zero_crashes(self) -> None:
        """percentile=0 should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=20,
                percentile=0,
                alpha=0.05,
                two_step=True,
                random_state=42,
            )

    def test_percentile_over_100_crashes(self) -> None:
        """percentile > 100 should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=20,
                percentile=101,
                alpha=0.05,
                two_step=True,
                random_state=42,
            )

    @pytest.mark.parametrize("percentile", [1, 50, 75, 95, 100])
    def test_valid_percentile_range(self, percentile: int) -> None:
        """Valid percentile in range [1, 100] should be accepted."""
        config = BorutaSelectorConfig(
            n_trials=20,
            percentile=percentile,
            alpha=0.05,
            two_step=True,
            random_state=42,
        )
        assert config.percentile == percentile


class TestBorutaSelectorConfigAlphaValidation:
    """Test alpha validation."""

    def test_alpha_zero_crashes(self) -> None:
        """alpha=0 should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=20,
                percentile=100,
                alpha=0.0,
                two_step=True,
                random_state=42,
            )

    def test_alpha_one_crashes(self) -> None:
        """alpha=1 should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=20,
                percentile=100,
                alpha=1.0,
                two_step=True,
                random_state=42,
            )

    def test_alpha_negative_crashes(self) -> None:
        """alpha < 0 should crash."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=20,
                percentile=100,
                alpha=-0.05,
                two_step=True,
                random_state=42,
            )

    @pytest.mark.parametrize("alpha", [0.001, 0.01, 0.05, 0.1, 0.5, 0.99])
    def test_valid_alpha_range(self, alpha: float) -> None:
        """Valid alpha in range (0, 1) should be accepted."""
        config = BorutaSelectorConfig(
            n_trials=20,
            percentile=100,
            alpha=alpha,
            two_step=True,
            random_state=42,
        )
        assert config.alpha == alpha


class TestConfigShuffleModeValidation:
    """Test BorutaSelectorConfig shuffle mode validation."""

    def test_config_accepts_shuffle_mode_random(self) -> None:
        """Config accepts ShuffleMode.RANDOM."""
        config = BorutaSelectorConfig(
            n_trials=10,
            percentile=100,
            alpha=0.05,
            two_step=True,
            random_state=42,
            shadow_shuffle_mode=ShuffleMode.RANDOM,
        )
        assert config.shadow_shuffle_mode is ShuffleMode.RANDOM

    def test_config_accepts_shuffle_mode_block(self) -> None:
        """Config accepts ShuffleMode.BLOCK with block_size."""
        config = BorutaSelectorConfig(
            n_trials=10,
            percentile=100,
            alpha=0.05,
            two_step=True,
            random_state=42,
            shadow_shuffle_mode=ShuffleMode.BLOCK,
            shadow_block_size=20,
        )
        assert config.shadow_shuffle_mode is ShuffleMode.BLOCK
        assert config.shadow_block_size == 20

    def test_config_crashes_block_mode_without_block_size(self) -> None:
        """Config crashes when BLOCK mode specified without block_size."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=10,
                percentile=100,
                alpha=0.05,
                two_step=True,
                random_state=42,
                shadow_shuffle_mode=ShuffleMode.BLOCK,
                # shadow_block_size missing!
            )

    def test_config_crashes_block_mode_with_zero_block_size(self) -> None:
        """Config crashes when BLOCK mode has block_size=0."""
        with pytest.raises(ValidationError):
            BorutaSelectorConfig(
                n_trials=10,
                percentile=100,
                alpha=0.05,
                two_step=True,
                random_state=42,
                shadow_shuffle_mode=ShuffleMode.BLOCK,
                shadow_block_size=0,
            )

    def test_config_default_shuffle_mode_is_random(self) -> None:
        """Default shadow_shuffle_mode is RANDOM (backward compatible)."""
        config = BorutaSelectorConfig(
            n_trials=10,
            percentile=100,
            alpha=0.05,
            two_step=True,
            random_state=42,
        )
        assert config.shadow_shuffle_mode is ShuffleMode.RANDOM

    def test_config_accepts_shuffle_mode_era(self) -> None:
        """Config accepts ShuffleMode.ERA without block_size."""
        config = BorutaSelectorConfig(
            n_trials=10,
            percentile=100,
            alpha=0.05,
            two_step=True,
            random_state=42,
            shadow_shuffle_mode=ShuffleMode.ERA,
        )
        assert config.shadow_shuffle_mode is ShuffleMode.ERA
