"""
Tests for shadow feature generation.

Shadow features MUST:
1. Have same shape as input
2. Preserve marginal distributions
3. Destroy feature-target correlation (via permutation)
4. Use consistent naming convention
"""

import numpy as np
import pandas as pd
import pytest

from boruta_quant.selector.shadow import create_shadow_features
from boruta_quant.selector.shuffle import ShuffleMode


class TestShadowFeatureCreation:
    """Test shadow feature generation basics."""

    def test_shadow_shape_matches_input(self) -> None:
        """Shadow DataFrame must have same shape as input."""
        X = pd.DataFrame({"a": [1, 2, 3, 4, 5], "b": [10, 20, 30, 40, 50]})
        rng = np.random.default_rng(42)

        shadow_df, shadow_names = create_shadow_features(X, rng)

        assert shadow_df.shape == X.shape
        assert len(shadow_names) == len(X.columns)

    def test_shadow_names_follow_convention(self) -> None:
        """Shadow column names must follow 'shadow_{original}' convention."""
        X = pd.DataFrame({"feature_a": [1, 2, 3], "feature_b": [4, 5, 6]})
        rng = np.random.default_rng(42)

        shadow_df, shadow_names = create_shadow_features(X, rng)

        assert shadow_names == ["shadow_feature_a", "shadow_feature_b"]
        assert list(shadow_df.columns) == shadow_names

    def test_shadow_index_matches_input(self) -> None:
        """Shadow DataFrame must preserve original index."""
        X = pd.DataFrame({"a": [1, 2, 3]}, index=[10, 20, 30])
        rng = np.random.default_rng(42)

        shadow_df, _ = create_shadow_features(X, rng)

        assert list(shadow_df.index) == [10, 20, 30]

    def test_shadow_values_are_permutations(self) -> None:
        """Shadow column values must be permutations of originals."""
        X = pd.DataFrame({"a": [1, 2, 3, 4, 5]})
        rng = np.random.default_rng(42)

        shadow_df, _ = create_shadow_features(X, rng)

        # Same set of values (just reordered)
        assert set(shadow_df["shadow_a"].values) == set(X["a"].values)

        # But NOT in same order (with high probability for n=5)
        assert not np.array_equal(shadow_df["shadow_a"].values, X["a"].values)

    def test_shadow_preserves_marginal_distribution(self) -> None:
        """Shadow features must have identical marginal statistics."""
        np.random.seed(42)
        X = pd.DataFrame({"a": np.random.randn(1000)})
        rng = np.random.default_rng(42)

        shadow_df, _ = create_shadow_features(X, rng)

        # Same mean, std, min, max (permutation preserves these exactly)
        assert shadow_df["shadow_a"].mean() == pytest.approx(X["a"].mean())
        assert shadow_df["shadow_a"].std() == pytest.approx(X["a"].std())
        assert shadow_df["shadow_a"].min() == pytest.approx(X["a"].min())
        assert shadow_df["shadow_a"].max() == pytest.approx(X["a"].max())


class TestShadowFeatureReproducibility:
    """Test reproducibility with random state."""

    def test_same_rng_produces_same_shadows(self) -> None:
        """Same random generator state must produce identical shadows."""
        X = pd.DataFrame({"a": [1, 2, 3, 4, 5], "b": [10, 20, 30, 40, 50]})

        rng1 = np.random.default_rng(42)
        shadow1, _ = create_shadow_features(X, rng1)

        rng2 = np.random.default_rng(42)
        shadow2, _ = create_shadow_features(X, rng2)

        pd.testing.assert_frame_equal(shadow1, shadow2)

    def test_different_rng_produces_different_shadows(self) -> None:
        """Different random generator seeds must produce different shadows."""
        X = pd.DataFrame({"a": list(range(100))})

        rng1 = np.random.default_rng(42)
        shadow1, _ = create_shadow_features(X, rng1)

        rng2 = np.random.default_rng(123)
        shadow2, _ = create_shadow_features(X, rng2)

        # Highly unlikely to be equal with different seeds
        assert not np.array_equal(shadow1.values, shadow2.values)


class TestShadowFeatureInputValidation:
    """Test input validation - fail-fast on bad inputs."""

    def test_empty_dataframe_crashes(self) -> None:
        """Empty DataFrame should crash."""
        X = pd.DataFrame()
        rng = np.random.default_rng(42)

        with pytest.raises(AssertionError, match="empty DataFrame"):
            create_shadow_features(X, rng)

    def test_zero_columns_crashes(self) -> None:
        """DataFrame with no columns should crash."""
        X = pd.DataFrame(index=[0, 1, 2])
        rng = np.random.default_rng(42)

        with pytest.raises(AssertionError, match="no features"):
            create_shadow_features(X, rng)

    def test_zero_rows_crashes(self) -> None:
        """DataFrame with no rows should crash."""
        X = pd.DataFrame(columns=["a", "b"])
        rng = np.random.default_rng(42)

        with pytest.raises(AssertionError, match="empty DataFrame"):
            create_shadow_features(X, rng)


class TestShadowFeatureCorrelation:
    """Test that shadow features destroy correlation."""

    def test_shadow_destroys_target_correlation(self) -> None:
        """Shadow features must have ~0 correlation with target."""
        np.random.seed(42)
        n = 1000

        # Create feature with high target correlation
        X = pd.DataFrame({"a": np.random.randn(n)})
        y = X["a"] * 2 + np.random.randn(n) * 0.1  # r ≈ 0.99

        rng = np.random.default_rng(42)
        shadow_df, _ = create_shadow_features(X, rng)

        # Original correlation should be high
        orig_corr = np.corrcoef(X["a"], y)[0, 1]
        assert abs(orig_corr) > 0.9

        # Shadow correlation should be near zero
        shadow_corr = np.corrcoef(shadow_df["shadow_a"], y)[0, 1]
        assert abs(shadow_corr) < 0.1  # Should be close to 0


class TestShadowShuffleModes:
    """Test shuffle mode parameter for shadow feature creation."""

    def test_random_mode_is_default_behavior(self) -> None:
        """Default shuffle_mode=RANDOM produces permuted values."""
        X = pd.DataFrame({"f1": [1, 2, 3, 4, 5], "f2": [10, 20, 30, 40, 50]})
        rng = np.random.default_rng(42)

        shadow_df, shadow_names = create_shadow_features(X, rng)

        assert shadow_df.shape == X.shape
        assert len(shadow_names) == 2
        # Values are permuted (same set, different order)
        assert set(shadow_df["shadow_f1"].values) == set(X["f1"].values)

    def test_random_mode_explicit_matches_default(self) -> None:
        """Explicit shuffle_mode=RANDOM matches default behavior."""
        X = pd.DataFrame({"f1": list(range(100))})

        rng1 = np.random.default_rng(42)
        shadow1, _ = create_shadow_features(X, rng1)

        rng2 = np.random.default_rng(42)
        shadow2, _ = create_shadow_features(X, rng2, shuffle_mode=ShuffleMode.RANDOM)

        pd.testing.assert_frame_equal(shadow1, shadow2)


class TestShadowBlockMode:
    """Test BLOCK shuffle mode."""

    def test_block_mode_preserves_block_integrity(self) -> None:
        """BLOCK mode keeps consecutive values together."""
        # Values are [1,2,3] and [4,5,6] - each block should stay intact
        X = pd.DataFrame({"f1": [1, 2, 3, 4, 5, 6]})
        rng = np.random.default_rng(42)

        shadow_df, _ = create_shadow_features(X, rng, shuffle_mode=ShuffleMode.BLOCK, block_size=3)

        shadow_vals = shadow_df["shadow_f1"].values
        # Either [1,2,3,4,5,6] or [4,5,6,1,2,3] (blocks swapped but intact)
        block1 = list(shadow_vals[:3])
        block2 = list(shadow_vals[3:])

        # Each block must be one of the original blocks (order preserved within block)
        assert block1 in [[1, 2, 3], [4, 5, 6]]
        assert block2 in [[1, 2, 3], [4, 5, 6]]
        assert block1 != block2  # Different blocks

    def test_block_mode_handles_uneven_last_block(self) -> None:
        """BLOCK mode handles last block smaller than block_size."""
        X = pd.DataFrame({"f1": [1, 2, 3, 4, 5, 6, 7]})  # 7 values, block_size=3
        rng = np.random.default_rng(42)

        shadow_df, _ = create_shadow_features(X, rng, shuffle_mode=ShuffleMode.BLOCK, block_size=3)

        # Should have all 7 values
        assert len(shadow_df) == 7
        assert set(shadow_df["shadow_f1"].values) == {1, 2, 3, 4, 5, 6, 7}

    def test_block_mode_crashes_without_block_size(self) -> None:
        """BLOCK mode without block_size must crash."""
        X = pd.DataFrame({"f1": [1, 2, 3, 4, 5, 6]})
        rng = np.random.default_rng(42)

        with pytest.raises(AssertionError, match="block_size required"):
            create_shadow_features(X, rng, shuffle_mode=ShuffleMode.BLOCK)

    def test_block_mode_crashes_on_zero_block_size(self) -> None:
        """BLOCK mode with block_size=0 must crash."""
        X = pd.DataFrame({"f1": [1, 2, 3, 4, 5, 6]})
        rng = np.random.default_rng(42)

        with pytest.raises(AssertionError, match="block_size must be > 0"):
            create_shadow_features(X, rng, shuffle_mode=ShuffleMode.BLOCK, block_size=0)

    def test_block_mode_crashes_on_negative_block_size(self) -> None:
        """BLOCK mode with negative block_size must crash."""
        X = pd.DataFrame({"f1": [1, 2, 3]})
        rng = np.random.default_rng(42)

        with pytest.raises(AssertionError, match="block_size must be > 0"):
            create_shadow_features(X, rng, shuffle_mode=ShuffleMode.BLOCK, block_size=-5)


class TestShadowEraMode:
    """Test ERA shuffle mode."""

    def test_era_mode_shuffles_within_era_only(self) -> None:
        """ERA mode permutes values only within same era."""
        # Era 0 has values [1, 2], Era 1 has values [100, 200]
        X = pd.DataFrame({"f1": [1, 2, 100, 200]})
        eras = pd.Series([0, 0, 1, 1])
        rng = np.random.default_rng(42)

        shadow_df, _ = create_shadow_features(X, rng, shuffle_mode=ShuffleMode.ERA, eras=eras)

        # Era 0 positions can only have era 0 values
        era0_vals = set(shadow_df["shadow_f1"].iloc[:2].values)
        assert era0_vals <= {1, 2}

        # Era 1 positions can only have era 1 values
        era1_vals = set(shadow_df["shadow_f1"].iloc[2:].values)
        assert era1_vals <= {100, 200}

    def test_era_mode_preserves_all_values(self) -> None:
        """ERA mode preserves all original values (just reordered within eras)."""
        X = pd.DataFrame({"f1": [10, 20, 30, 40, 50, 60]})
        eras = pd.Series([0, 0, 0, 1, 1, 1])
        rng = np.random.default_rng(42)

        shadow_df, _ = create_shadow_features(X, rng, shuffle_mode=ShuffleMode.ERA, eras=eras)

        # Same multiset of values
        assert sorted(shadow_df["shadow_f1"].values) == [10, 20, 30, 40, 50, 60]

    def test_era_mode_with_many_eras(self) -> None:
        """ERA mode works with many distinct eras."""
        X = pd.DataFrame({"f1": list(range(100))})
        # 10 eras of 10 values each
        eras = pd.Series([i // 10 for i in range(100)])
        rng = np.random.default_rng(42)

        shadow_df, _ = create_shadow_features(X, rng, shuffle_mode=ShuffleMode.ERA, eras=eras)

        # Each era's positions should only have that era's values
        for era_id in range(10):
            era_mask = eras == era_id
            expected_values = set(X["f1"].loc[era_mask].values)
            actual_values = set(shadow_df["shadow_f1"].loc[era_mask].values)
            assert actual_values == expected_values

    def test_era_mode_crashes_without_eras(self) -> None:
        """ERA mode without eras parameter must crash."""
        X = pd.DataFrame({"f1": [1, 2, 3, 4]})
        rng = np.random.default_rng(42)

        with pytest.raises(AssertionError, match="eras required"):
            create_shadow_features(X, rng, shuffle_mode=ShuffleMode.ERA)

    def test_era_mode_crashes_on_length_mismatch(self) -> None:
        """ERA mode with eras length != X length must crash."""
        X = pd.DataFrame({"f1": [1, 2, 3, 4]})
        eras = pd.Series([0, 0, 1])  # Length 3, not 4
        rng = np.random.default_rng(42)

        with pytest.raises(AssertionError, match="eras length .* != X length"):
            create_shadow_features(X, rng, shuffle_mode=ShuffleMode.ERA, eras=eras)


class TestShadowShuffleModeReproducibility:
    """Test reproducibility across shuffle modes."""

    @pytest.mark.parametrize("shuffle_mode", list(ShuffleMode))
    def test_same_rng_produces_same_shadows(self, shuffle_mode: ShuffleMode) -> None:
        """Same RNG seed produces identical shadows for all modes."""
        X = pd.DataFrame({"f1": list(range(12))})
        eras = pd.Series([i // 4 for i in range(12)])

        kwargs: dict = {"shuffle_mode": shuffle_mode}
        if shuffle_mode == ShuffleMode.BLOCK:
            kwargs["block_size"] = 4
        elif shuffle_mode == ShuffleMode.ERA:
            kwargs["eras"] = eras

        rng1 = np.random.default_rng(42)
        shadow1, _ = create_shadow_features(X, rng1, **kwargs)

        rng2 = np.random.default_rng(42)
        shadow2, _ = create_shadow_features(X, rng2, **kwargs)

        pd.testing.assert_frame_equal(shadow1, shadow2)
