"""Shared fixtures for selector tests."""

import numpy as np
import pandas as pd
import pytest
from sklearn.datasets import make_regression
from sklearn.ensemble import RandomForestRegressor
from statsmodels.tsa.arima_process import ArmaProcess

from boruta_quant.oracle import PermutationImportanceOracle
from boruta_quant.selector.config import BorutaSelectorConfig
from boruta_quant.temporal import PurgedCVConfig


@pytest.fixture
def informative_regression_data() -> tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex]:
    """
    Create regression data with known informative features.

    Features f0-f4 are INFORMATIVE (correlated with target).
    Features noise_0-noise_4 are NOISE (random, uncorrelated).

    Uses make_regression which ensures:
    - Ground truth is known
    - Signal-to-noise ratio is controllable
    - Reproducible via random_state
    """
    n_informative = 5
    n_noise = 5
    n_samples = 1000

    X_array, y_array = make_regression(
        n_samples=n_samples,
        n_features=n_informative + n_noise,
        n_informative=n_informative,
        noise=0.5,
        random_state=42,
    )

    feature_names = [f"f{i}" for i in range(n_informative)] + [f"noise_{i}" for i in range(n_noise)]

    X = pd.DataFrame(X_array, columns=feature_names)
    y = pd.Series(y_array, name="target")

    # Create timezone-aware timestamps (required by PurgedTemporalCV)
    timestamps = pd.date_range("2020-01-01", periods=n_samples, freq="h", tz="UTC")

    return X, y, timestamps


@pytest.fixture
def ar1_temporal_data() -> tuple[pd.DataFrame, pd.Series, pd.DatetimeIndex]:
    """
    Generate synthetic temporal data with AR(1) autocorrelation.

    Uses statsmodels ArmaProcess for realistic temporal dependency.
    This tests temporal CV split behavior.
    """
    n_days = 500
    timestamps = pd.date_range("2020-01-01", periods=n_days, freq="B", tz="UTC")

    ar_coef = 0.7
    ar = np.array([1, -ar_coef])
    ma = np.array([1])

    ar_process = ArmaProcess(ar, ma)
    np.random.seed(42)

    returns = ar_process.generate_sample(n_days, scale=0.01)

    X = pd.DataFrame(
        {
            "ret_1d": returns,
            "ret_5d": pd.Series(returns).rolling(5).sum().fillna(0).values,
            "vol_20d": pd.Series(returns).rolling(20).std().fillna(0.01).values,
            "momentum_20d": pd.Series(returns).rolling(20).mean().fillna(0).values,
            "noise": np.random.randn(n_days),
        }
    )

    y = pd.Series(np.roll(returns, -1), name="target")
    y.iloc[-1] = 0

    return X, y, timestamps


@pytest.fixture
def standard_selector_config() -> BorutaSelectorConfig:
    """Standard configuration for selector tests."""
    return BorutaSelectorConfig(
        n_trials=10,
        percentile=100,
        alpha=0.05,
        two_step=True,
        random_state=42,
    )


@pytest.fixture
def standard_cv_config() -> PurgedCVConfig:
    """Standard CV configuration for selector tests."""
    return PurgedCVConfig(
        n_splits=3,
        purge_window_days=1,
        embargo_window_days=1,
        min_train_size=100,
        test_size_ratio=0.2,
    )


@pytest.fixture
def standard_oracle() -> PermutationImportanceOracle:
    """Standard oracle for selector tests."""
    return PermutationImportanceOracle(n_repeats=5, random_state=42)


@pytest.fixture
def rf_model() -> RandomForestRegressor:
    """Random Forest model for tests."""
    return RandomForestRegressor(n_estimators=20, max_depth=5, random_state=42, n_jobs=-1)
