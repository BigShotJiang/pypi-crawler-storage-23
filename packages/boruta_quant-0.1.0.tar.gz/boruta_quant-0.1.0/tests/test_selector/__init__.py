"""Tests for boruta_quant.selector module."""
