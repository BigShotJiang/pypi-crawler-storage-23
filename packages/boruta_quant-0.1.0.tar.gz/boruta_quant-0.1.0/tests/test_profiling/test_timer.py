"""
Unit tests for ComponentTimer.

Design by Contract testing:
- Test all contract violations crash immediately
- Test valid inputs produce expected outputs
"""

import time
import unittest.mock

import pytest

from boruta_quant.profiling import ComponentTimer


class TestComponentTimer:
    """Test ComponentTimer timing and memory tracking."""

    def test_tracks_positive_elapsed_time(self) -> None:
        """ComponentTimer measures positive elapsed time (P0 contract)."""
        with ComponentTimer(track_memory=False) as timer:
            time.sleep(0.05)

        assert timer.elapsed >= 0.05, f"Expected >=0.05s, got {timer.elapsed:.4f}s"
        assert timer.elapsed < 0.15, f"Expected <0.15s, got {timer.elapsed:.4f}s"

    def test_tracks_zero_elapsed_for_instant_operation(self) -> None:
        """ComponentTimer measures near-zero elapsed for instant operations."""
        with ComponentTimer(track_memory=False) as timer:
            pass

        assert timer.elapsed >= 0, f"Elapsed time negative: {timer.elapsed}"
        assert timer.elapsed < 0.01, f"Instant operation took {timer.elapsed}s"

    def test_memory_tracking_when_enabled(self) -> None:
        """ComponentTimer tracks memory delta when enabled (mandatory psutil)."""
        with ComponentTimer(track_memory=True) as timer:
            _data = [0] * 1_000_000

        assert timer.memory_delta != 0 or timer.peak_memory > 0, (
            "Memory tracking enabled but no metrics recorded"
        )
        assert timer.peak_memory >= 0, f"Peak memory negative: {timer.peak_memory}GB"
        assert 0 <= timer.system_memory_before <= 100
        assert 0 <= timer.system_memory_after <= 100

    def test_memory_tracking_disabled_sets_zero_metrics(self) -> None:
        """ComponentTimer sets zero memory metrics when tracking disabled."""
        with ComponentTimer(track_memory=False) as timer:
            _data = [0] * 1_000_000

        assert timer.memory_delta == 0.0
        assert timer.peak_memory == 0.0
        assert timer.system_memory_before == 0.0
        assert timer.system_memory_after == 0.0

    def test_negative_elapsed_time_crashes(self) -> None:
        """ComponentTimer crashes if elapsed time is negative (P1 fail-fast)."""
        timer = ComponentTimer(track_memory=False)
        timer.__enter__()

        with unittest.mock.patch("time.perf_counter") as mock_time:
            mock_time.return_value = 50.0
            timer._start_time = 100.0

            with pytest.raises(AssertionError, match="Elapsed time cannot be negative"):
                timer.__exit__(None, None, None)

    def test_context_manager_returns_self(self) -> None:
        """ComponentTimer __enter__ returns self for 'as' clause."""
        timer = ComponentTimer()
        result = timer.__enter__()
        assert result is timer
        timer.__exit__(None, None, None)

    def test_default_memory_tracking_enabled(self) -> None:
        """ComponentTimer has memory tracking enabled by default."""
        timer = ComponentTimer()
        assert timer.track_memory is True
