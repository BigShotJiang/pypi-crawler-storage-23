"""Tests for profile_operation helper."""

import time

from boruta_quant.profiling import ProfilingSession, profile_operation


class TestProfileOperation:
    """Test profile_operation context manager."""

    def test_auto_records_to_session(self) -> None:
        """profile_operation automatically records to session."""
        session = ProfilingSession()

        with profile_operation("Test Op", session, count=50):
            time.sleep(0.05)

        results = session.get_results()

        assert "Test Op" in results
        assert results["Test Op"]["total_count"] == 50
        assert results["Test Op"]["total_time"] >= 0.05

    def test_memory_tracking_enabled_by_default(self) -> None:
        """profile_operation enables memory tracking by default."""
        session = ProfilingSession()

        with profile_operation("Memory Op", session, count=10):
            _data = [0] * 1_000_000

        results = session.get_results()

        # Memory tracked when enabled
        assert "memory_delta" in results["Memory Op"] or "peak_memory" in results["Memory Op"]

    def test_yields_timer_for_inspection(self) -> None:
        """profile_operation yields ComponentTimer for inspection."""
        session = ProfilingSession()

        with profile_operation("Inspect Op", session) as timer:
            time.sleep(0.05)

        assert timer.elapsed >= 0.05

    def test_count_parameter_propagates(self) -> None:
        """count parameter propagates to session record."""
        session = ProfilingSession()

        with profile_operation("Counted Op", session, count=999):
            pass

        results = session.get_results()
        assert results["Counted Op"]["total_count"] == 999

    def test_track_memory_can_be_disabled(self) -> None:
        """track_memory=False disables memory tracking."""
        session = ProfilingSession()

        with profile_operation("No Memory", session, count=1, track_memory=False) as timer:
            pass

        assert timer.memory_delta == 0.0
        assert timer.peak_memory == 0.0
