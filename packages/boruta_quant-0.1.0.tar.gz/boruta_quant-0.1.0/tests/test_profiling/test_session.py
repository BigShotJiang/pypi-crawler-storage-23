"""
Unit tests for ProfilingSession.

Design by Contract testing:
- Test aggregation correctness
- Test thread safety
- Test serialization
"""

import json
import pickle
import threading
from pathlib import Path

import pytest

from boruta_quant.profiling import ProfilingSession


class TestProfilingSession:
    """Test ProfilingSession aggregation and reporting."""

    def test_single_record_stores_correctly(self) -> None:
        """ProfilingSession correctly stores single timing record."""
        session = ProfilingSession()
        session.record("Test Operation", elapsed=1.5, count=10)

        results = session.get_results()

        assert "Test Operation" in results
        assert results["Test Operation"]["total_time"] == 1.5
        assert results["Test Operation"]["total_count"] == 10
        assert results["Test Operation"]["throughput"] == pytest.approx(10 / 1.5)
        assert results["Test Operation"]["per_item_ms"] == pytest.approx(150.0)

    def test_multiple_records_aggregate_correctly(self) -> None:
        """ProfilingSession correctly sums multiple timing records."""
        session = ProfilingSession()
        session.record("Op", elapsed=1.0, count=10)
        session.record("Op", elapsed=2.0, count=20)

        results = session.get_results()

        assert results["Op"]["total_time"] == 3.0
        assert results["Op"]["total_count"] == 30
        assert results["Op"]["throughput"] == pytest.approx(10.0)

    def test_memory_metrics_aggregated_correctly(self) -> None:
        """ProfilingSession aggregates memory metrics across records."""
        session = ProfilingSession()
        session.record("Op", elapsed=1.0, count=5, memory_delta=0.5, peak_memory=2.0)
        session.record("Op", elapsed=2.0, count=10, memory_delta=1.0, peak_memory=3.0)

        results = session.get_results()

        assert results["Op"]["memory_delta"] == 1.5  # sum
        assert results["Op"]["peak_memory"] == 3.0  # max

    def test_zero_elapsed_time_handles_safely(self) -> None:
        """ProfilingSession handles zero elapsed time gracefully."""
        session = ProfilingSession()
        session.record("Instant", elapsed=0.0, count=100)

        results = session.get_results()

        assert results["Instant"]["throughput"] == 0

    def test_zero_count_handles_safely(self) -> None:
        """ProfilingSession handles zero count gracefully."""
        session = ProfilingSession()
        session.record("Empty", elapsed=1.0, count=0)

        results = session.get_results()

        assert results["Empty"]["per_item_ms"] == 0

    def test_negative_elapsed_crashes(self) -> None:
        """ProfilingSession crashes on negative elapsed time (P1 violation)."""
        session = ProfilingSession()

        with pytest.raises(AssertionError, match="non-negative"):
            session.record("Bad", elapsed=-1.0, count=10)

    def test_negative_count_crashes(self) -> None:
        """ProfilingSession crashes on negative count (P1 violation)."""
        session = ProfilingSession()

        with pytest.raises(AssertionError, match="non-negative"):
            session.record("Bad", elapsed=1.0, count=-5)

    def test_get_results_is_picklable(self) -> None:
        """ProfilingSession.get_results() returns picklable dict."""
        session = ProfilingSession()
        session.record("Op", elapsed=1.5, count=10, memory_delta=0.5, peak_memory=2.0)

        results = session.get_results()

        pickled = pickle.dumps(results)
        unpickled = pickle.loads(pickled)
        assert unpickled == results

    def test_session_itself_not_picklable(self) -> None:
        """ProfilingSession itself cannot be pickled (has threading.Lock)."""
        session = ProfilingSession()
        session.record("Op", elapsed=1.0, count=5)

        with pytest.raises(TypeError, match="cannot pickle.*lock"):
            pickle.dumps(session)

    def test_thread_safe_recording(self) -> None:
        """ProfilingSession handles concurrent record() calls."""
        session = ProfilingSession()

        def record_many() -> None:
            for _ in range(100):
                session.record(f"Op_{threading.current_thread().name}", elapsed=0.01, count=1)

        threads = [threading.Thread(target=record_many) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        session.get_results()
        total_records = sum(len(session.timings[k]) for k in session.timings)
        assert total_records == 400  # 4 threads * 100 records each

    def test_flush_to_file_writes_valid_json(self, tmp_path: Path) -> None:
        """flush_to_file() writes valid JSON checkpoint."""
        session = ProfilingSession()
        session.record("Op1", elapsed=1.5, count=100)
        session.record("Op2", elapsed=2.0, count=50, memory_delta=0.5)

        checkpoint_path = tmp_path / "checkpoint.json"
        session.flush_to_file(checkpoint_path)

        assert checkpoint_path.exists()
        with open(checkpoint_path) as f:
            data = json.load(f)
        assert "Op1" in data
        assert "Op2" in data
        assert data["Op1"]["total_time"] == 1.5

    def test_flush_to_file_creates_parent_directories(self, tmp_path: Path) -> None:
        """flush_to_file() creates parent directories if missing."""
        session = ProfilingSession()
        session.record("Op", elapsed=1.0, count=1)

        checkpoint_path = tmp_path / "nested" / "dirs" / "checkpoint.json"
        session.flush_to_file(checkpoint_path)

        assert checkpoint_path.exists()

    def test_print_summary_outputs_table(self, capsys: pytest.CaptureFixture[str]) -> None:
        """print_summary() produces formatted output."""
        session = ProfilingSession()
        session.record("Op1", elapsed=1.5, count=100, memory_delta=0.5, peak_memory=2.0)
        session.record("Op2", elapsed=2.5, count=50, memory_delta=1.0, peak_memory=3.0)

        session.print_summary("Test Results")

        captured = capsys.readouterr()
        assert "Test Results" in captured.out
        assert "Op1" in captured.out
        assert "Op2" in captured.out
        assert "TOTAL" in captured.out
