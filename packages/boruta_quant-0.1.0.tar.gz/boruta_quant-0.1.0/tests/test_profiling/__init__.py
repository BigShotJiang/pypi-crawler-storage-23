"""Tests for profiling infrastructure."""
