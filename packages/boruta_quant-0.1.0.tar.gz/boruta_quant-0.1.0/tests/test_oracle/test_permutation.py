"""
Tests for PermutationImportanceOracle.

UNIT TESTS: Use sklearn.datasets.make_regression for known informative/noise split.
This is appropriate because:
- Ground truth is known (which features are informative)
- No temporal component needed for testing importance ranking
- Fast and reproducible
"""

from unittest.mock import MagicMock, patch

import numpy as np
import pandas as pd
import pytest
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge

from boruta_quant.oracle.permutation import PermutationImportanceOracle

# ============================================================================
# FIXTURES: Now provided by conftest.py (DRY)
# ============================================================================
# informative_data - from conftest.py
# feature_names - from conftest.py


# ============================================================================
# PROTOCOL CONFORMANCE TESTS
# ============================================================================


class TestPermutationOracleProtocol:
    """Test ImportanceOracle protocol conformance."""

    def test_has_compute_importance_method(self) -> None:
        """Oracle must have compute_importance method."""
        oracle = PermutationImportanceOracle()
        assert hasattr(oracle, "compute_importance")
        assert callable(oracle.compute_importance)

    def test_returns_dict_with_all_features(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """compute_importance must return dict with all feature names."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = PermutationImportanceOracle(n_repeats=3, random_state=42)
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        assert isinstance(importances, dict)
        assert set(importances.keys()) == set(feature_names)

    def test_importance_values_are_floats(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """All importance values must be floats."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = PermutationImportanceOracle(n_repeats=3, random_state=42)
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        for name, value in importances.items():
            assert isinstance(value, float | np.floating), f"{name}: {type(value)}"


# ============================================================================
# OOS-ONLY COMPUTATION TESTS
# ============================================================================


class TestPermutationOracleOOSOnly:
    """Test that importance is computed on validation data only."""

    def test_importance_computed_on_validation_only(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Verify permutation_importance called with X_val, y_val."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = PermutationImportanceOracle(n_repeats=3, random_state=42)
        model = Ridge()

        with patch("boruta_quant.oracle.permutation.permutation_importance") as mock_perm:
            # Mock return value with spec
            mock_result = MagicMock(spec=["importances_mean", "importances_std"])
            mock_result.importances_mean = np.zeros(len(feature_names))
            mock_perm.return_value = mock_result

            oracle.compute_importance(model, X_train, y_train, X_val, y_val, feature_names)

            # Verify called with validation data
            call_args = mock_perm.call_args
            positional_args = call_args[0]

            # Second positional arg should be X_val
            passed_X = positional_args[1]
            passed_y = positional_args[2]

            pd.testing.assert_frame_equal(passed_X, X_val)
            pd.testing.assert_series_equal(passed_y, y_val)


# ============================================================================
# FEATURE RANKING TESTS
# ============================================================================


class TestPermutationOracleFeatureRanking:
    """Test that oracle correctly ranks informative vs noise features."""

    def test_informative_features_rank_higher_than_noise(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Informative features should have higher importance than noise."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = PermutationImportanceOracle(n_repeats=10, random_state=42)
        model = RandomForestRegressor(n_estimators=50, random_state=42)

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        # Get importances for informative and noise features
        informative_imp = [importances[f"f{i}"] for i in range(5)]
        noise_imp = [importances[f"noise_{i}"] for i in range(5)]

        # Average informative importance should be higher
        assert np.mean(informative_imp) > np.mean(noise_imp), (
            f"Informative: {np.mean(informative_imp):.4f}, Noise: {np.mean(noise_imp):.4f}"
        )

    def test_at_least_one_informative_in_top_5(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """At least one informative feature should be in top 5 by importance."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = PermutationImportanceOracle(n_repeats=10, random_state=42)
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        # Sort by importance descending
        sorted_features = sorted(importances.items(), key=lambda x: x[1], reverse=True)
        top_5 = [f[0] for f in sorted_features[:5]]

        # At least one informative feature (f0-f4) should be in top 5
        informative_in_top_5 = [f for f in top_5 if f.startswith("f")]
        assert len(informative_in_top_5) > 0, f"Top 5: {top_5}"


# ============================================================================
# CONFIGURATION TESTS
# ============================================================================


class TestPermutationOracleConfiguration:
    """Test oracle configuration options."""

    def test_custom_scoring_parameter(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Custom scoring parameter should be used."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = PermutationImportanceOracle(scoring="r2", n_repeats=3, random_state=42)
        model = Ridge()

        # Should not raise
        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        assert len(importances) == len(feature_names)

    def test_random_state_reproducibility(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Same random_state should produce same results."""
        X_train, y_train, X_val, y_val = informative_data
        oracle1 = PermutationImportanceOracle(n_repeats=5, random_state=42)
        oracle2 = PermutationImportanceOracle(n_repeats=5, random_state=42)
        model = Ridge()

        imp1 = oracle1.compute_importance(model, X_train, y_train, X_val, y_val, feature_names)
        imp2 = oracle2.compute_importance(model, X_train, y_train, X_val, y_val, feature_names)

        for name in feature_names:
            assert imp1[name] == pytest.approx(imp2[name])

    def test_n_repeats_parameter_affects_stability(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """More repeats should produce more stable results."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = PermutationImportanceOracle(n_repeats=20, random_state=42)
        model = Ridge()

        # Should not raise even with more repeats
        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        assert len(importances) == len(feature_names)


# ============================================================================
# INPUT VALIDATION TESTS
# ============================================================================


class TestPermutationOracleInputValidation:
    """Test input validation via validate_importance_inputs."""

    def test_crashes_on_empty_validation_data(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Empty validation data should crash."""
        X_train, y_train, _, _ = informative_data
        oracle = PermutationImportanceOracle(n_repeats=3, random_state=42)
        model = Ridge()

        X_val_empty = pd.DataFrame(columns=feature_names)
        y_val_empty = pd.Series(dtype=float, name="target")

        with pytest.raises(AssertionError, match="X_val is empty"):
            oracle.compute_importance(
                model, X_train, y_train, X_val_empty, y_val_empty, feature_names
            )

    def test_crashes_on_feature_name_mismatch(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
    ) -> None:
        """Mismatched feature names should crash."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = PermutationImportanceOracle(n_repeats=3, random_state=42)
        model = Ridge()

        wrong_names = ["wrong_" + str(i) for i in range(10)]

        with pytest.raises(AssertionError, match="columns don't match"):
            oracle.compute_importance(model, X_train, y_train, X_val, y_val, wrong_names)
