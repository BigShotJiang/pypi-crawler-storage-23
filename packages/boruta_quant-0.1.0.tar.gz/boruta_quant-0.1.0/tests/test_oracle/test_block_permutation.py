"""
Tests for BlockPermutationImportanceOracle.

Test Strategy:
- Protocol conformance: returns dict with all features, values are floats
- Feature ranking: informative features should rank higher than noise (on average)
- Input validation: crashes on invalid inputs (fail-fast)
- Reproducibility: same random_state produces same results
- Block logic: block indices cover all samples, permutation preserves block structure
"""

import numpy as np
import pandas as pd
import pytest
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge

from boruta_quant.oracle.block_permutation import BlockPermutationImportanceOracle

# ============================================================================
# PROTOCOL CONFORMANCE TESTS
# ============================================================================


class TestBlockPermutationOracleProtocol:
    """Test ImportanceOracle protocol conformance."""

    def test_has_compute_importance_method(self) -> None:
        """Oracle must have compute_importance method."""
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=3, random_state=42
        )
        assert hasattr(oracle, "compute_importance")
        assert callable(oracle.compute_importance)

    def test_returns_dict_with_all_features(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """compute_importance must return dict with all feature names."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=3, random_state=42
        )
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        assert isinstance(importances, dict)
        assert set(importances.keys()) == set(feature_names)

    def test_importance_values_are_floats(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """All importance values must be floats."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=3, random_state=42
        )
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        for name, value in importances.items():
            assert isinstance(value, float | np.floating), f"{name}: {type(value)}"


# ============================================================================
# FEATURE RANKING TESTS
# ============================================================================


class TestBlockPermutationOracleFeatureRanking:
    """Test that oracle correctly ranks informative vs noise features."""

    def test_informative_features_rank_higher_than_noise(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Informative features should have higher importance than noise on average."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=10, random_state=42
        )
        model = RandomForestRegressor(n_estimators=50, random_state=42)

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        informative_imp = [importances[f"f{i}"] for i in range(5)]
        noise_imp = [importances[f"noise_{i}"] for i in range(5)]

        assert np.mean(informative_imp) > np.mean(noise_imp), (
            f"Informative: {np.mean(informative_imp):.4f}, Noise: {np.mean(noise_imp):.4f}"
        )

    def test_at_least_one_informative_in_top_5(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """At least one informative feature should be in top 5 by importance."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=10, random_state=42
        )
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        sorted_features = sorted(importances.items(), key=lambda x: x[1], reverse=True)
        top_5 = [f[0] for f in sorted_features[:5]]

        informative_in_top_5 = [f for f in top_5 if f.startswith("f")]
        assert len(informative_in_top_5) > 0, f"Top 5: {top_5}"


# ============================================================================
# INPUT VALIDATION TESTS
# ============================================================================


class TestBlockPermutationOracleInputValidation:
    """Test input validation via validate_importance_inputs."""

    def test_crashes_on_empty_validation_data(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Empty validation data should crash (fail-fast)."""
        X_train, y_train, _, _ = informative_data
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=3, random_state=42
        )
        model = Ridge()

        X_val_empty = pd.DataFrame(columns=feature_names)
        y_val_empty = pd.Series(dtype=float, name="target")

        with pytest.raises(AssertionError, match="X_val is empty"):
            oracle.compute_importance(
                model, X_train, y_train, X_val_empty, y_val_empty, feature_names
            )

    def test_crashes_on_feature_name_mismatch(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
    ) -> None:
        """Mismatched feature names should crash (fail-fast)."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=3, random_state=42
        )
        model = Ridge()

        wrong_names = ["wrong_" + str(i) for i in range(10)]

        with pytest.raises(AssertionError, match="columns don't match"):
            oracle.compute_importance(model, X_train, y_train, X_val, y_val, wrong_names)

    def test_crashes_on_none_scoring(self) -> None:
        """None scoring should crash at init (fail-fast via beartype)."""
        from beartype.roar import BeartypeCallHintParamViolation

        with pytest.raises(BeartypeCallHintParamViolation):
            BlockPermutationImportanceOracle(
                scoring=None,
                block_size=10,  # type: ignore[arg-type]
            )

    def test_crashes_on_zero_block_size(self) -> None:
        """Zero block_size should crash at init (fail-fast)."""
        with pytest.raises(AssertionError, match="block_size must be > 0"):
            BlockPermutationImportanceOracle(scoring="r2", block_size=0)

    def test_crashes_on_negative_block_size(self) -> None:
        """Negative block_size should crash at init (fail-fast)."""
        with pytest.raises(AssertionError, match="block_size must be > 0"):
            BlockPermutationImportanceOracle(scoring="r2", block_size=-5)

    def test_crashes_on_zero_n_repeats(self) -> None:
        """Zero n_repeats should crash at init (fail-fast)."""
        with pytest.raises(AssertionError, match="n_repeats must be > 0"):
            BlockPermutationImportanceOracle(scoring="r2", block_size=10, n_repeats=0)

    def test_crashes_on_block_size_greater_than_validation(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """block_size > len(X_val) should crash at compute_importance (fail-fast)."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=500, n_repeats=3, random_state=42
        )
        model = Ridge()

        with pytest.raises(AssertionError, match="block_size.*> validation set size"):
            oracle.compute_importance(model, X_train, y_train, X_val, y_val, feature_names)


# ============================================================================
# REPRODUCIBILITY TESTS
# ============================================================================


class TestBlockPermutationOracleReproducibility:
    """Test reproducibility with random_state."""

    def test_same_random_state_same_results(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Same random_state should produce identical results."""
        X_train, y_train, X_val, y_val = informative_data
        oracle1 = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=5, random_state=42
        )
        oracle2 = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=5, random_state=42
        )
        model = Ridge()

        imp1 = oracle1.compute_importance(model, X_train, y_train, X_val, y_val, feature_names)
        imp2 = oracle2.compute_importance(model, X_train, y_train, X_val, y_val, feature_names)

        for name in feature_names:
            assert imp1[name] == pytest.approx(imp2[name])

    def test_different_random_state_different_results(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Different random_state should produce different results."""
        X_train, y_train, X_val, y_val = informative_data
        oracle1 = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=5, random_state=42
        )
        oracle2 = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=5, random_state=123
        )
        model = Ridge()

        imp1 = oracle1.compute_importance(model, X_train, y_train, X_val, y_val, feature_names)
        imp2 = oracle2.compute_importance(model, X_train, y_train, X_val, y_val, feature_names)

        # At least one feature should have different importance
        differences = [abs(imp1[n] - imp2[n]) for n in feature_names]
        assert max(differences) > 0.0001


# ============================================================================
# BLOCK LOGIC TESTS
# ============================================================================


class TestBlockPermutationOracleBlockLogic:
    """Test block computation and permutation logic."""

    def test_block_indices_cover_all_samples(self) -> None:
        """Block indices should cover all samples exactly once."""
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=10, n_repeats=3, random_state=42
        )

        # Test exact division
        blocks_100 = oracle._compute_block_indices(100)
        assert len(blocks_100) == 10
        covered = set()
        for start, end in blocks_100:
            for i in range(start, end):
                assert i not in covered, f"Index {i} covered multiple times"
                covered.add(i)
        assert covered == set(range(100))

        # Test non-exact division (last block smaller)
        blocks_95 = oracle._compute_block_indices(95)
        assert len(blocks_95) == 10
        assert blocks_95[-1] == (90, 95)  # Last block is smaller
        covered = set()
        for start, end in blocks_95:
            for i in range(start, end):
                assert i not in covered
                covered.add(i)
        assert covered == set(range(95))

    def test_permute_blocks_preserves_within_block_order(self) -> None:
        """Permuting blocks should preserve within-block value order."""
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=3, n_repeats=3, random_state=42
        )

        values = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
        block_indices = [(0, 3), (3, 6), (6, 9)]
        rng = np.random.default_rng(42)

        permuted = oracle._permute_blocks(values, block_indices, rng)

        # Extract blocks from permuted result
        permuted_blocks = [list(permuted[i : i + 3]) for i in range(0, 9, 3)]

        # Each permuted block should be one of the original blocks
        original_blocks = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
        for pblock in permuted_blocks:
            assert pblock in original_blocks, f"{pblock} not in original blocks"

    def test_block_size_1_degenerates_to_row_permutation(
        self,
        small_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        small_feature_names: list[str],
    ) -> None:
        """block_size=1 should work (degenerates to standard permutation)."""
        X_train, y_train, X_val, y_val = small_data
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=1, n_repeats=5, random_state=42
        )
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, small_feature_names
        )

        assert len(importances) == len(small_feature_names)


# ============================================================================
# CONFIGURATION TESTS
# ============================================================================


class TestBlockPermutationOracleConfiguration:
    """Test oracle configuration options."""

    def test_custom_scoring_string(
        self,
        small_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        small_feature_names: list[str],
    ) -> None:
        """Custom sklearn scorer string should work."""
        X_train, y_train, X_val, y_val = small_data
        oracle = BlockPermutationImportanceOracle(
            scoring="neg_mean_squared_error", block_size=5, n_repeats=3, random_state=42
        )
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, small_feature_names
        )

        assert len(importances) == len(small_feature_names)

    def test_custom_scoring_callable(
        self,
        small_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        small_feature_names: list[str],
    ) -> None:
        """Custom callable scorer should work."""
        X_train, y_train, X_val, y_val = small_data

        def custom_scorer(est: object, X: pd.DataFrame, y: pd.Series) -> float:
            return est.score(X, y)  # type: ignore[union-attr]

        oracle = BlockPermutationImportanceOracle(
            scoring=custom_scorer, block_size=5, n_repeats=3, random_state=42
        )
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, small_feature_names
        )

        assert len(importances) == len(small_feature_names)

    def test_n_repeats_affects_stability(
        self,
        small_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        small_feature_names: list[str],
    ) -> None:
        """More n_repeats should produce results (stability is statistical)."""
        X_train, y_train, X_val, y_val = small_data
        oracle = BlockPermutationImportanceOracle(
            scoring="r2", block_size=5, n_repeats=50, random_state=42
        )
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, small_feature_names
        )

        assert len(importances) == len(small_feature_names)
