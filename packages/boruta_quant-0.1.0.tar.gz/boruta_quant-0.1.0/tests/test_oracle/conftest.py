"""
Shared fixtures for oracle tests.

Uses sklearn.datasets.make_regression for ground truth:
- Features f0-f4 are INFORMATIVE (have non-zero coefficients)
- Features noise_0-noise_4 are NOISE (zero coefficients)
"""

import pandas as pd
import pytest
from sklearn.datasets import make_regression


@pytest.fixture
def informative_data() -> tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series]:
    """
    Create train/val data with known informative and noise features.

    Returns:
        (X_train, y_train, X_val, y_val) tuple with:
        - 500 training samples, 100 validation samples
        - 5 informative features (f0-f4)
        - 5 noise features (noise_0-noise_4)
    """
    n_informative = 5
    n_noise = 5
    n_train, n_val = 500, 100

    X_array, y_array = make_regression(
        n_samples=n_train + n_val,
        n_features=n_informative + n_noise,
        n_informative=n_informative,
        noise=0.5,
        random_state=42,
    )

    feature_names = [f"f{i}" for i in range(n_informative)] + [f"noise_{i}" for i in range(n_noise)]

    X = pd.DataFrame(X_array, columns=feature_names)
    y = pd.Series(y_array, name="target")

    X_train, X_val = X.iloc[:n_train], X.iloc[n_train:]
    y_train, y_val = y.iloc[:n_train], y.iloc[n_train:]

    return X_train, y_train, X_val, y_val


@pytest.fixture
def feature_names() -> list[str]:
    """Feature names matching informative_data fixture."""
    return [
        "f0",
        "f1",
        "f2",
        "f3",
        "f4",
        "noise_0",
        "noise_1",
        "noise_2",
        "noise_3",
        "noise_4",
    ]


@pytest.fixture
def small_data() -> tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series]:
    """
    Small dataset for edge case tests (50 train, 20 val).

    Returns:
        (X_train, y_train, X_val, y_val) tuple with 3 features.
    """
    n_train, n_val = 50, 20
    X_array, y_array = make_regression(
        n_samples=n_train + n_val,
        n_features=3,
        n_informative=2,
        noise=0.5,
        random_state=42,
    )

    feature_names = ["a", "b", "noise"]
    X = pd.DataFrame(X_array, columns=feature_names)
    y = pd.Series(y_array, name="target")

    return X.iloc[:n_train], y.iloc[:n_train], X.iloc[n_train:], y.iloc[n_train:]


@pytest.fixture
def small_feature_names() -> list[str]:
    """Feature names for small_data fixture."""
    return ["a", "b", "noise"]
