"""
Tests for DropColumnImportanceOracle.

Test Strategy:
- Protocol conformance: returns dict with all features, values are floats
- Feature ranking: informative features should rank higher than noise (on average)
- Input validation: crashes on invalid inputs (fail-fast)
- Reproducibility: same inputs produce same outputs (deterministic)
"""

import numpy as np
import pandas as pd
import pytest
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge

from boruta_quant.oracle.drop_column import DropColumnImportanceOracle

# ============================================================================
# PROTOCOL CONFORMANCE TESTS
# ============================================================================


class TestDropColumnOracleProtocol:
    """Test ImportanceOracle protocol conformance."""

    def test_has_compute_importance_method(self) -> None:
        """Oracle must have compute_importance method."""
        oracle = DropColumnImportanceOracle(scoring="r2")
        assert hasattr(oracle, "compute_importance")
        assert callable(oracle.compute_importance)

    def test_returns_dict_with_all_features(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """compute_importance must return dict with all feature names."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = DropColumnImportanceOracle(scoring="r2")
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        assert isinstance(importances, dict)
        assert set(importances.keys()) == set(feature_names)

    def test_importance_values_are_floats(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """All importance values must be floats."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = DropColumnImportanceOracle(scoring="r2")
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        for name, value in importances.items():
            assert isinstance(value, float | np.floating), f"{name}: {type(value)}"


# ============================================================================
# FEATURE RANKING TESTS
# ============================================================================


class TestDropColumnOracleFeatureRanking:
    """Test that oracle correctly ranks informative vs noise features."""

    def test_informative_features_rank_higher_than_noise(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Informative features should have higher importance than noise on average."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = DropColumnImportanceOracle(scoring="r2")
        model = RandomForestRegressor(n_estimators=50, random_state=42)

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        informative_imp = [importances[f"f{i}"] for i in range(5)]
        noise_imp = [importances[f"noise_{i}"] for i in range(5)]

        assert np.mean(informative_imp) > np.mean(noise_imp), (
            f"Informative: {np.mean(informative_imp):.4f}, Noise: {np.mean(noise_imp):.4f}"
        )

    def test_at_least_one_informative_in_top_5(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """At least one informative feature should be in top 5 by importance."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = DropColumnImportanceOracle(scoring="r2")
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, feature_names
        )

        sorted_features = sorted(importances.items(), key=lambda x: x[1], reverse=True)
        top_5 = [f[0] for f in sorted_features[:5]]

        informative_in_top_5 = [f for f in top_5 if f.startswith("f")]
        assert len(informative_in_top_5) > 0, f"Top 5: {top_5}"


# ============================================================================
# INPUT VALIDATION TESTS
# ============================================================================


class TestDropColumnOracleInputValidation:
    """Test input validation via validate_importance_inputs."""

    def test_crashes_on_empty_validation_data(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Empty validation data should crash (fail-fast)."""
        X_train, y_train, _, _ = informative_data
        oracle = DropColumnImportanceOracle(scoring="r2")
        model = Ridge()

        X_val_empty = pd.DataFrame(columns=feature_names)
        y_val_empty = pd.Series(dtype=float, name="target")

        with pytest.raises(AssertionError, match="X_val is empty"):
            oracle.compute_importance(
                model, X_train, y_train, X_val_empty, y_val_empty, feature_names
            )

    def test_crashes_on_feature_name_mismatch(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
    ) -> None:
        """Mismatched feature names should crash (fail-fast)."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = DropColumnImportanceOracle(scoring="r2")
        model = Ridge()

        wrong_names = ["wrong_" + str(i) for i in range(10)]

        with pytest.raises(AssertionError, match="columns don't match"):
            oracle.compute_importance(model, X_train, y_train, X_val, y_val, wrong_names)

    def test_crashes_on_none_scoring(self) -> None:
        """None scoring should crash at init (fail-fast via beartype)."""
        from beartype.roar import BeartypeCallHintParamViolation

        with pytest.raises(BeartypeCallHintParamViolation):
            DropColumnImportanceOracle(scoring=None)  # type: ignore[arg-type]


# ============================================================================
# CONFIGURATION TESTS
# ============================================================================


class TestDropColumnOracleConfiguration:
    """Test oracle configuration options."""

    def test_custom_scoring_string(
        self,
        small_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        small_feature_names: list[str],
    ) -> None:
        """Custom sklearn scorer string should work."""
        X_train, y_train, X_val, y_val = small_data
        oracle = DropColumnImportanceOracle(scoring="neg_mean_squared_error")
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, small_feature_names
        )

        assert len(importances) == len(small_feature_names)

    def test_custom_scoring_callable(
        self,
        small_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        small_feature_names: list[str],
    ) -> None:
        """Custom callable scorer should work."""
        X_train, y_train, X_val, y_val = small_data

        def custom_scorer(est: object, X: pd.DataFrame, y: pd.Series) -> float:
            return est.score(X, y)  # type: ignore[union-attr]

        oracle = DropColumnImportanceOracle(scoring=custom_scorer)
        model = Ridge()

        importances = oracle.compute_importance(
            model, X_train, y_train, X_val, y_val, small_feature_names
        )

        assert len(importances) == len(small_feature_names)

    def test_deterministic_results(
        self,
        informative_data: tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series],
        feature_names: list[str],
    ) -> None:
        """Same inputs should produce same outputs (deterministic models)."""
        X_train, y_train, X_val, y_val = informative_data
        oracle = DropColumnImportanceOracle(scoring="r2")
        model = Ridge()  # Ridge is deterministic

        imp1 = oracle.compute_importance(model, X_train, y_train, X_val, y_val, feature_names)
        imp2 = oracle.compute_importance(model, X_train, y_train, X_val, y_val, feature_names)

        for name in feature_names:
            assert imp1[name] == pytest.approx(imp2[name])
