# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-02-26

### Added
- **BorutaSelector**: Main feature selection class with configurable trials, alpha, percentile, and two-step tentative resolution
- **Importance Oracles**: Pluggable `ImportanceOracle` protocol with three implementations:
  - `PermutationOracle` (default) — OOS-safe permutation importance
  - `DropColumnOracle` — refit-based importance via column removal
  - `BlockPermutationOracle` — block-preserving permutation for autocorrelated data
- **Purged Temporal CV**: `PurgedTemporalCV` with configurable purge window, embargo window, and min train size to prevent lookahead bias
- **Shadow Features**: Shadow feature generation with three shuffle modes:
  - `RANDOM` — standard i.i.d. permutation (default)
  - `BLOCK` — block-preserving shuffle for serial correlation
  - `ERA` — within-era-only shuffle for regime-aware selection
- **Era Support**: `boundaries_to_eras()` utility for converting date boundaries to era labels
- **Statistical Testing**: Binomial hypothesis testing with Bonferroni correction and optional two-step rough fix for tentative features
- **Metrics**: `rank_ic` (Spearman correlation) and `auc_scorer` for alpha research evaluation
- **Profiling**: Built-in `ProfilingSession` integration for timing and memory tracking during `fit()`
- **Type Safety**: Full type hints with beartype runtime enforcement and Pyright strict mode
- **Pydantic Configs**: `BorutaSelectorConfig` and `PurgedCVConfig` with fail-fast validation
- 229 tests with 92% statement coverage
