# PREDICTION DOMAIN RULES

## 🎯 Prediction System Requirements

### Core Prediction Rules
1. **NEVER leak future data** - Temporal validation is mandatory
2. **ALWAYS use walk-forward validation** - No in-sample testing
3. **ENFORCE feature importance tracking** - Know what drives predictions
4. **REQUIRE experiment immutability** - Results never overwritten

### Model Development Requirements

```python
# ✅ REQUIRED - Temporal split validation
from sklearn.model_selection import TimeSeriesSplit

splitter = TimeSeriesSplit(n_splits=5, test_size=7*24)  # 7 days test
for train_idx, test_idx in splitter.split(X):
    assert max(train_idx) < min(test_idx), "Temporal leak detected"
```

### Feature Engineering Rules

| Requirement | Implementation | Validation |
|-------------|---------------|------------|
| Feature selection | BorutaShap or similar | Track importance scores |
| Lag features | Minimum 1 period lag | No same-period leakage |
| Rolling windows | Backward-looking only | Assert window < current_idx |
| Target encoding | Out-of-fold only | Never on test set |

### Experiment Tracking Requirements

```python
# Immutable experiment results
experiment_id = f"{model_name}_{timestamp}"
results_path = Path(f"experiments/{experiment_id}/")

# FORBIDDEN: Overwriting results
assert not results_path.exists(), "Experiment already exists"

# REQUIRED: Complete metadata
metadata = {
    "model_version": model.__version__,
    "feature_set": feature_names,
    "train_period": (train_start, train_end),
    "test_period": (test_start, test_end),
    "metrics": metrics_dict,
    "parameters": model.get_params()
}
```

### Backtesting Requirements

1. **Point-in-time data**: Only use data available at prediction time
2. **Transaction costs**: Include realistic fees/slippage
3. **Position limits**: Enforce realistic constraints
4. **Market impact**: Model large position effects

### Performance Validation

```python
# MANDATORY metrics for prediction systems
metrics = {
    "accuracy": accuracy_score(y_true, y_pred),
    "precision": precision_score(y_true, y_pred),
    "recall": recall_score(y_true, y_pred),
    "roi": calculate_roi(positions, outcomes),
    "sharpe": sharpe_ratio(returns),
    "max_drawdown": maximum_drawdown(equity_curve)
}

# REQUIRED: Statistical significance testing
from scipy.stats import binomtest
result = binomtest(wins, total, p=0.5, alternative='greater')
assert result.pvalue < 0.05, "Not statistically significant"
```

### Data Quality Rules

❌ **NEVER**:
- Use future information in features
- Overwrite experiment results
- Skip outlier detection
- Ignore missing data patterns
- Train on test data

✅ **ALWAYS**:
- Validate temporal ordering
- Track data lineage
- Document feature engineering
- Version datasets
- Archive raw predictions

### Production Deployment

```python
# REQUIRED: Model versioning
MODEL_REGISTRY = {
    "version": "2.3.1",
    "trained_date": "2025-11-13",
    "training_data": "dataset_v4.2",
    "performance": metrics,
    "git_commit": commit_hash
}

# REQUIRED: Fallback strategy
if not model.is_available():
    use_previous_version()
    alert_ops_team()
```

### Forbidden Patterns

| ❌ Forbidden | ✅ Required | Why |
|--------------|-------------|-----|
| Train on full dataset | TimeSeriesSplit | Prevents overfitting |
| Ignore failed predictions | Track all outcomes | Learn from failures |
| Static thresholds | Adaptive thresholds | Market regimes change |
| Single model dependency | Ensemble/fallback | Robustness |