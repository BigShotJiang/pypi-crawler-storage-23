# TRADING DOMAIN RULES

## 🏦 FINANCIAL SAFETY REQUIREMENTS

### Critical Trading Rules
1. **NEVER allow naked short exposure** - Unlimited loss potential
2. **ALWAYS validate strike distances** - Prevent unsafe trades
3. **ENFORCE position limits** - Risk management boundaries
4. **VERIFY margin requirements** - Prevent margin calls

### Data Validation Requirements

```python
# ✅ REQUIRED - Validate all financial data
@beartype
def validate_option_contract(contract: OptionContract):
    assert contract.strike > 0, f"Invalid strike: {contract.strike}"
    assert contract.expiration > datetime.now(), "Expired contract"
    assert contract.bid <= contract.ask, f"Inverted spread: {contract.bid} > {contract.ask}"
    assert contract.volume >= 0, "Negative volume"
```

### Position Management Rules

| Scenario | Required Check | Failure Mode |
|----------|---------------|--------------|
| Opening position | Margin verification | Reject trade |
| Rolling position | Strike distance check | Reject roll |
| Closing position | Order validation | Reject close |
| Position sizing | Risk limits | Scale down |

### Market Data Requirements

```python
# Timezone-aware timestamps REQUIRED
timestamp = pd.to_datetime(data['time'], utc=True)

# Decimal precision for prices
from decimal import Decimal
price = Decimal(str(raw_price))  # Never float

# Option Greeks validation
assert -1 <= delta <= 1, f"Invalid delta: {delta}"
assert theta <= 0, f"Positive theta impossible: {theta}"
```

### Testing Requirements

1. **Backtesting Coverage**: Test with 2+ years historical data
2. **Edge Cases**: Market close, holidays, halts, splits
3. **Failure Scenarios**: Connection loss, partial fills, rejections
4. **Position Types**: Test LONG_CALL, SHORT_CALL, LONG_PUT, SHORT_PUT

### Production Safeguards

```python
# MANDATORY - Circuit breakers
MAX_POSITION_SIZE = 100
MAX_DAILY_TRADES = 50
MAX_LOSS_PERCENT = 2.0

if daily_loss > MAX_LOSS_PERCENT:
    shutdown_trading()
```

### Forbidden Patterns

❌ **NEVER**:
- Use float for prices (use Decimal)
- Ignore timezone in timestamps
- Skip commission calculations
- Allow unlimited position sizes
- Trade without margin checks

✅ **ALWAYS**:
- Log every trade attempt
- Validate market hours
- Check pattern day trader rules
- Verify settlement dates
- Monitor Greeks boundaries