# PORTFOLIO DOMAIN RULES

## 💼 Portfolio Management Requirements

### Core Portfolio Rules
1. **NEVER exceed position limits** - Risk management is paramount
2. **ALWAYS maintain audit trail** - Every rebalance must be traceable
3. **ENFORCE factor attribution** - Know what drives returns
4. **REQUIRE transaction cost modeling** - Real costs in optimization

### Portfolio Construction Requirements

```python
# ✅ REQUIRED - Position limits enforcement
@beartype
def validate_weights(weights: np.ndarray, limits: PositionLimits):
    assert abs(weights.sum() - 1.0) < 1e-6, "Weights must sum to 1"
    assert (weights >= limits.min_weight).all(), f"Below minimum: {weights.min()}"
    assert (weights <= limits.max_weight).all(), f"Above maximum: {weights.max()}"
    assert weights[weights != 0].shape[0] <= limits.max_positions, "Too many positions"
```

### Risk Management Rules

| Metric | Required Check | Failure Action |
|--------|---------------|----------------|
| Portfolio VaR | < Risk budget | Scale positions down |
| Concentration | < 25% per position | Rebalance |
| Correlation | < 0.8 between positions | Diversify |
| Leverage | < Maximum allowed | Reduce exposure |

### Rebalancing Requirements

```python
# Event-driven rebalancing triggers
RebalanceTriggers = {
    "drift": 5.0,        # % drift from target
    "vol_spike": 2.0,    # Volatility multiplier
    "correlation": 0.85,  # Correlation threshold
    "calendar": 30,      # Days since last rebalance
}

# REQUIRED: Rebalancing audit
RebalanceAudit = {
    "timestamp": datetime.utcnow(),
    "trigger": trigger_reason,
    "weights_before": current_weights.copy(),
    "weights_after": new_weights.copy(),
    "turnover": calculate_turnover(current, new),
    "expected_cost": transaction_costs,
    "risk_metrics": calculate_risk_metrics(new)
}
```

### Factor Attribution Requirements

```python
# MANDATORY - Track factor exposures
@dataclass
class FactorExposure:
    market_beta: float
    size: float
    value: float
    momentum: float
    quality: float
    volatility: float

    def validate(self):
        assert -3 <= self.market_beta <= 3, "Unrealistic beta"
        total_exposure = abs(self.size) + abs(self.value) + abs(self.momentum)
        assert total_exposure > 0, "No factor exposure"
```

### Optimization Requirements

```python
# REQUIRED: Robust optimization
from scipy.optimize import minimize

def optimize_portfolio(
    expected_returns: np.ndarray,
    covariance: np.ndarray,
    constraints: list
):
    # MANDATORY: Regularization for numerical stability
    cov_regularized = covariance + np.eye(len(covariance)) * 1e-8

    # REQUIRED: Multiple objectives
    objectives = {
        "return": expected_returns,
        "risk": cov_regularized,
        "transaction_costs": cost_model
    }

    # FORBIDDEN: Unconstrained optimization
    assert len(constraints) > 0, "Must have constraints"
```

### Execution Requirements

```python
# Saga pattern for multi-step execution
@dataclass
class RebalanceSaga:
    saga_id: str
    steps: list[RebalanceStep]
    state: SagaState

    def execute(self):
        for step in self.steps:
            try:
                step.execute()
                self.checkpoint(step)
            except Exception as e:
                self.rollback(step)
                raise SagaFailure(f"Failed at {step}: {e}")
```

### Performance Attribution

| Component | Calculation | Required |
|-----------|------------|----------|
| Asset allocation | Benchmark vs actual weights | Yes |
| Security selection | Within-sector returns | Yes |
| Factor contribution | Factor return × exposure | Yes |
| Transaction costs | Explicit tracking | Yes |
| Timing | Entry/exit vs benchmark | Optional |

### Data Management

```python
# Zero-copy optimization for large portfolios
import pyarrow as pa

# REQUIRED: Efficient data structures
prices_table = pa.Table.from_pandas(prices_df)
returns_array = pa.compute.diff(prices_table['close'])

# FORBIDDEN: Repeated DataFrame copies
# ❌ df2 = df.copy(); df3 = df2.copy()
# ✅ Use views or Arrow tables
```

### Forbidden Patterns

| ❌ Forbidden | ✅ Required | Why |
|--------------|-------------|-----|
| Optimize without constraints | Constrained optimization | Prevents unrealistic portfolios |
| Ignore transaction costs | Explicit cost modeling | Real-world performance |
| Single-period optimization | Multi-period planning | Path dependency |
| Static risk limits | Dynamic risk budgeting | Market regime changes |
| Rebalance without audit | Complete audit trail | Regulatory compliance |

### Production Safety

```python
# MANDATORY: Pre-trade compliance checks
def pre_trade_compliance(orders: list[Order]) -> list[Order]:
    validated = []
    for order in orders:
        # Position limits
        assert check_position_limits(order), f"Position limit breach: {order}"
        # Risk limits
        assert check_risk_limits(order), f"Risk limit breach: {order}"
        # Regulatory
        assert check_regulatory(order), f"Regulatory violation: {order}"
        validated.append(order)
    return validated
```