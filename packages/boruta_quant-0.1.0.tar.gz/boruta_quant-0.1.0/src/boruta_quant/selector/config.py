"""
Configuration for BorutaSelector.

All fields are REQUIRED (no defaults) - this follows CLAUDE.md P1 rules.
Validators use assert for fail-fast behavior.
"""

from pydantic import BaseModel, Field, field_validator, model_validator

from .shuffle import ShuffleMode


class BorutaSelectorConfig(BaseModel):
    """Configuration for BorutaSelector - ALL required, no defaults."""

    n_trials: int = Field(..., description="Number of Boruta iterations")
    percentile: int = Field(..., description="Shadow threshold percentile (e.g., 100 = max)")
    alpha: float = Field(..., description="Significance level for hypothesis tests")
    two_step: bool = Field(..., description="Whether to apply TentativeRoughFix")
    random_state: int | None = Field(..., description="Random seed for reproducibility")
    shadow_shuffle_mode: ShuffleMode = Field(
        default=ShuffleMode.RANDOM,
        description="Shadow shuffle mode",
    )
    shadow_block_size: int | None = Field(
        default=None,
        description="Block size for BLOCK shuffle mode",
    )

    @field_validator("n_trials")
    @classmethod
    def validate_n_trials(cls, v: int) -> int:
        assert 1 <= v <= 1000, f"n_trials must be 1-1000, got {v}"
        return v

    @field_validator("percentile")
    @classmethod
    def validate_percentile(cls, v: int) -> int:
        assert 1 <= v <= 100, f"percentile must be 1-100, got {v}"
        return v

    @field_validator("alpha")
    @classmethod
    def validate_alpha(cls, v: float) -> float:
        assert 0 < v < 1, f"alpha must be (0, 1), got {v}"
        return v

    @model_validator(mode="after")
    def validate_shadow_block_size(self) -> "BorutaSelectorConfig":
        """Validate shadow_block_size is provided for BLOCK mode."""
        if self.shadow_shuffle_mode == ShuffleMode.BLOCK:
            assert self.shadow_block_size is not None, "shadow_block_size required for BLOCK mode"
            assert self.shadow_block_size > 0, (
                f"shadow_block_size must be > 0, got {self.shadow_block_size}"
            )
        return self
