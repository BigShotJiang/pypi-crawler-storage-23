"""
BorutaSelector - Temporal-aware Boruta feature selection with OOS-only importance.

This is the main class implementing the Boruta iteration loop with:
- Temporal CV integration via PurgedTemporalCV
- Shadow feature generation
- OOS-only importance computation via ImportanceOracle
- Binomial hypothesis testing with Bonferroni correction
- Optional TentativeRoughFix for undecided features
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from beartype import beartype

from boruta_quant.oracle import ImportanceOracle  # noqa: F401 - Protocol for docs
from boruta_quant.profiling import ProfilingSession, profile_operation
from boruta_quant.temporal import PurgedTemporalCV, validate_temporal_inputs

# Note: ImportanceOracle is a Protocol but not runtime_checkable, so we use Any
# for beartype compatibility. The oracle must still implement compute_importance().
from .config import BorutaSelectorConfig
from .hypothesis import binomial_test_features, calculate_hits, tentative_rough_fix
from .results import BorutaResult
from .shadow import create_shadow_features
from .shuffle import ShuffleMode, boundaries_to_eras


@beartype
class BorutaSelector:
    """
    Temporal-aware Boruta feature selection with OOS-only importance.

    Integrates with ImportanceOracle for pluggable importance computation
    and PurgedTemporalCV for temporal integrity.

    Algorithm:
    1. For each CV fold:
       a. Generate shadow features from training data
       b. Compute OOS importance on validation data
       c. Track hits (features beating shadow threshold)
    2. After all folds: test features via binomial hypothesis
    3. Repeat for n_trials iterations
    4. Classify features as accepted/rejected/tentative
    5. Optionally apply TentativeRoughFix

    Example:
        >>> from boruta_quant import BorutaSelector
        >>> from boruta_quant.metrics import rank_ic_scorer  # Quant finance scorer
        >>> from boruta_quant.oracle import PermutationImportanceOracle
        >>> from boruta_quant.temporal import PurgedTemporalCV, PurgedCVConfig
        >>>
        >>> config = BorutaSelectorConfig(
        ...     n_trials=20,
        ...     percentile=100,
        ...     alpha=0.05,
        ...     two_step=True,
        ...     random_state=42,
        ... )
        >>> cv_config = PurgedCVConfig(
        ...     n_splits=5,
        ...     purge_window_days=5,
        ...     embargo_window_days=5,
        ...     min_train_size=100,
        ...     test_size_ratio=0.2,
        ... )
        >>> # Use rank_ic_scorer for alpha signal evaluation
        >>> oracle = PermutationImportanceOracle(
        ...     scoring=rank_ic_scorer,  # Spearman correlation
        ...     n_repeats=10,
        ...     random_state=42,
        ... )
        >>> selector = BorutaSelector(
        ...     config=config,
        ...     oracle=oracle,
        ...     cv=PurgedTemporalCV(cv_config),
        ... )
        >>> result = selector.fit(X, y, timestamps, model)
        >>> print(result.accepted_features)
    """

    def __init__(
        self,
        config: BorutaSelectorConfig,
        oracle: Any,  # ImportanceOracle protocol - not runtime_checkable
        cv: PurgedTemporalCV,
    ) -> None:
        self.config = config
        self.oracle = oracle
        self.cv = cv

        # Random generator for reproducibility
        self._rng = np.random.default_rng(config.random_state)

        # State (populated after fit)
        self._result: BorutaResult | None = None

    @property
    def result(self) -> BorutaResult:
        """Access fit result. Raises if not fitted."""
        assert self._result is not None, "BorutaSelector not fitted. Call fit() first."
        return self._result

    def fit(
        self,
        X: pd.DataFrame,
        y: pd.Series,  # type: ignore[type-arg]
        timestamps: pd.DatetimeIndex,
        model: Any,
        profiling_session: ProfilingSession | None = None,
        eras: pd.Series | None = None,  # type: ignore[type-arg]
        era_boundaries: list[tuple[pd.Timestamp, pd.Timestamp]] | None = None,
    ) -> BorutaResult:
        """
        Fit Boruta selector to find all-relevant features.

        Args:
            X: Feature matrix (n_samples, n_features)
            y: Target variable (n_samples,)
            timestamps: Timezone-aware timestamps for temporal CV
            model: Unfitted sklearn-compatible model (will be cloned per fold)
            profiling_session: Optional profiling session for diagnostics
            eras: Optional era labels for ERA shuffle mode (aligned with X rows)
            era_boundaries: Optional date boundaries for ERA shuffle mode

        Returns:
            BorutaResult with accepted/rejected/tentative features
        """
        validate_temporal_inputs(X, y, timestamps)

        # Resolve eras from labels or boundaries
        resolved_eras: pd.Series | None = None  # type: ignore[type-arg]
        if self.config.shadow_shuffle_mode == ShuffleMode.ERA:
            if eras is not None:
                resolved_eras = eras
            elif era_boundaries is not None:
                resolved_eras = boundaries_to_eras(timestamps, era_boundaries)
            else:
                raise AssertionError("ERA mode requires eras or era_boundaries")
            assert len(resolved_eras) == len(X), (
                f"eras length {len(resolved_eras)} != X length {len(X)}"
            )

        original_features = list(X.columns)
        n_features = len(original_features)

        # Initialize tracking arrays
        cumulative_hits: dict[str, int] = dict.fromkeys(original_features, 0)
        importance_history: list[np.ndarray] = []  # type: ignore[type-arg]
        shadow_max_history: list[float] = []

        # Current feature set (shrinks as features are rejected)
        active_features = set(original_features)

        # Track accepted/rejected across trials
        all_accepted: set[str] = set()
        all_rejected: set[str] = set()

        actual_iterations = 0

        for trial in range(self.config.n_trials):
            if len(active_features) == 0:
                break  # Early stopping: all features decided

            # Run one Boruta trial across all CV folds
            trial_hits, trial_importances, trial_shadow_max = self._run_trial(
                X=X[list(active_features)],
                y=y,
                timestamps=timestamps,
                model=model,
                profiling_session=profiling_session,
                trial_id=trial,
                eras=resolved_eras,
            )

            # Accumulate hits
            for feature, hit in trial_hits.items():
                cumulative_hits[feature] += hit

            # Store history (padded to original feature count)
            padded_importances = np.zeros(n_features)
            for feature, importance in trial_importances.items():
                idx = original_features.index(feature)
                padded_importances[idx] = importance
            importance_history.append(padded_importances)
            shadow_max_history.append(trial_shadow_max)

            actual_iterations += 1

            # Test features after this trial
            accepted, rejected, _tentative = binomial_test_features(
                cumulative_hits={f: cumulative_hits[f] for f in active_features},
                n_iterations=actual_iterations,
                alpha=self.config.alpha,
            )

            # Update tracking
            all_accepted.update(accepted)
            all_rejected.update(rejected)

            # Remove rejected features from active set
            active_features -= set(rejected)

        # Final classification
        final_tentative = list(set(original_features) - all_accepted - all_rejected)

        # Optional: TentativeRoughFix
        if self.config.two_step and len(final_tentative) > 0:
            newly_accepted, newly_rejected = tentative_rough_fix(
                tentative_features=final_tentative,
                importance_history=np.array(importance_history),
                shadow_max_history=np.array(shadow_max_history),
                feature_names=original_features,
            )
            all_accepted.update(newly_accepted)
            all_rejected.update(newly_rejected)
            final_tentative = list(set(final_tentative) - set(newly_accepted) - set(newly_rejected))

        self._result = BorutaResult(
            accepted_features=tuple(sorted(all_accepted)),
            rejected_features=tuple(sorted(all_rejected)),
            tentative_features=tuple(sorted(final_tentative)),
            feature_hits=cumulative_hits,
            n_iterations=actual_iterations,
            importance_history=np.array(importance_history),
            shadow_max_history=np.array(shadow_max_history),
        )

        return self._result

    def _run_trial(
        self,
        X: pd.DataFrame,
        y: pd.Series,  # type: ignore[type-arg]
        timestamps: pd.DatetimeIndex,
        model: Any,
        profiling_session: ProfilingSession | None,
        trial_id: int,
        eras: pd.Series | None = None,  # type: ignore[type-arg]
    ) -> tuple[dict[str, int], dict[str, float], float]:
        """
        Run one Boruta trial across all CV folds.

        Returns:
            Tuple of (aggregated_hits, mean_importances, max_shadow_importance)
        """
        feature_names = list(X.columns)

        # Accumulators across folds
        fold_hits: list[dict[str, int]] = []
        fold_importances: list[dict[str, float]] = []
        fold_shadow_max: list[float] = []

        for split in self.cv.split(X, y, timestamps):
            # Extract train/val data
            X_train = X.iloc[split.train_indices]
            y_train = y.iloc[split.train_indices]
            X_val = X.iloc[split.val_indices]
            y_val = y.iloc[split.val_indices]

            # Extract eras for this fold if using ERA mode
            eras_train = eras.iloc[split.train_indices] if eras is not None else None
            eras_val = eras.iloc[split.val_indices] if eras is not None else None

            # Generate shadow features from training distribution
            shadow_df, shadow_names = create_shadow_features(
                X_train,
                self._rng,
                shuffle_mode=self.config.shadow_shuffle_mode,
                block_size=self.config.shadow_block_size,
                eras=eras_train,
            )

            # Combine real + shadow for training
            X_train_combined = pd.concat([X_train, shadow_df], axis=1)

            # Generate shadow features for validation (same permutation logic)
            shadow_val_df, _ = create_shadow_features(
                X_val,
                self._rng,
                shuffle_mode=self.config.shadow_shuffle_mode,
                block_size=self.config.shadow_block_size,
                eras=eras_val,
            )
            X_val_combined = pd.concat([X_val, shadow_val_df], axis=1)

            all_feature_names = feature_names + shadow_names

            # Compute OOS importance
            if profiling_session is not None:
                with profile_operation(
                    f"oracle_trial_{trial_id}_fold_{split.fold_id}",
                    profiling_session,
                    count=len(X_val),
                ):
                    importances = self.oracle.compute_importance(
                        model=model,
                        X_train=X_train_combined,
                        y_train=y_train,
                        X_val=X_val_combined,
                        y_val=y_val,
                        feature_names=all_feature_names,
                    )
            else:
                importances = self.oracle.compute_importance(
                    model=model,
                    X_train=X_train_combined,
                    y_train=y_train,
                    X_val=X_val_combined,
                    y_val=y_val,
                    feature_names=all_feature_names,
                )

            # Split importances: real vs shadow
            real_importances = {k: v for k, v in importances.items() if not k.startswith("shadow_")}
            shadow_importances = {k: v for k, v in importances.items() if k.startswith("shadow_")}

            # Calculate hits for this fold
            hits = calculate_hits(
                feature_importances=real_importances,
                shadow_importances=shadow_importances,
                percentile=self.config.percentile,
            )

            fold_hits.append(hits)
            fold_importances.append(real_importances)
            fold_shadow_max.append(max(shadow_importances.values()))

        # Aggregate across folds: sum hits, mean importances, max shadow
        aggregated_hits: dict[str, int] = dict.fromkeys(feature_names, 0)
        for hits in fold_hits:
            for feature, hit in hits.items():
                aggregated_hits[feature] += hit

        # Convert to binary: hit if majority of folds had hit
        n_folds = len(fold_hits)
        threshold = n_folds // 2 + 1
        binary_hits = {f: 1 if h >= threshold else 0 for f, h in aggregated_hits.items()}

        # Mean importance across folds
        mean_importances: dict[str, float] = dict.fromkeys(feature_names, 0.0)
        for imp in fold_importances:
            for feature, importance in imp.items():
                mean_importances[feature] += importance / n_folds

        # Max shadow importance across folds
        max_shadow = max(fold_shadow_max)

        return binary_hits, mean_importances, max_shadow
