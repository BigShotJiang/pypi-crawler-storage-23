"""Shuffle mode enum and era boundary conversion."""

from enum import Enum

import pandas as pd
from beartype import beartype


class ShuffleMode(Enum):
    """Shadow feature shuffle modes."""

    RANDOM = "random"  # Independent row shuffle (default)
    BLOCK = "block"  # Shuffle contiguous blocks
    ERA = "era"  # Shuffle within era labels


@beartype
def boundaries_to_eras(
    timestamps: pd.DatetimeIndex,
    boundaries: list[tuple[pd.Timestamp, pd.Timestamp]],
) -> pd.Series:  # type: ignore[type-arg]
    """
    Convert date boundaries to era labels.

    Args:
        timestamps: Timezone-aware timestamps aligned with data rows.
        boundaries: List of (start, end) tuples defining era ranges.
                   Each range is [start, end) - inclusive start, exclusive end.

    Returns:
        Series of integer era labels (0, 1, 2, ...).
        Timestamps not in any boundary raise AssertionError.

    Example:
        >>> boundaries = [
        ...     (pd.Timestamp("2020-01-01", tz="UTC"), pd.Timestamp("2020-03-01", tz="UTC")),
        ...     (pd.Timestamp("2020-03-01", tz="UTC"), pd.Timestamp("2020-06-01", tz="UTC")),
        ... ]
        >>> eras = boundaries_to_eras(timestamps, boundaries)
    """
    assert len(boundaries) > 0, "boundaries cannot be empty"

    eras = pd.Series(index=timestamps, data=-1, dtype=int)

    for era_id, (start, end) in enumerate(boundaries):
        mask = (timestamps >= start) & (timestamps < end)
        eras.loc[mask] = era_id

    # Fail-fast: all timestamps must be assigned
    unassigned = (eras == -1).sum()
    assert unassigned == 0, f"{unassigned} timestamps not covered by any era boundary"

    return eras
