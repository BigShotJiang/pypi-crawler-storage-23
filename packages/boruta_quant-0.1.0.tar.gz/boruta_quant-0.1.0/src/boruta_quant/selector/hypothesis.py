"""
Hypothesis testing functions for Boruta algorithm.

Provides:
- calculate_hits: Compare feature importance to shadow threshold
- binomial_test_features: Statistical feature classification with Bonferroni correction
- tentative_rough_fix: Median-based resolution of tentative features
"""

import numpy as np
from beartype import beartype
from scipy.stats import binomtest


@beartype
def calculate_hits(
    feature_importances: dict[str, float],
    shadow_importances: dict[str, float],
    percentile: int,
) -> dict[str, int]:
    """
    Calculate hits: which features beat the shadow threshold.

    Args:
        feature_importances: Real feature importance scores
        shadow_importances: Shadow feature importance scores
        percentile: Percentile of shadow distribution to use as threshold

    Returns:
        Dict mapping feature name to hit (1) or miss (0)
    """
    assert len(shadow_importances) > 0, "No shadow importances provided"

    shadow_values = np.array(list(shadow_importances.values()))
    threshold = float(np.percentile(shadow_values, percentile))

    hits: dict[str, int] = {}
    for feature, importance in feature_importances.items():
        hits[feature] = 1 if importance > threshold else 0

    return hits


@beartype
def binomial_test_features(
    cumulative_hits: dict[str, int],
    n_iterations: int,
    alpha: float,
) -> tuple[list[str], list[str], list[str]]:
    """
    Classify features using two-sided binomial test with Bonferroni correction.

    Args:
        cumulative_hits: Feature name -> total hits across iterations
        n_iterations: Number of completed iterations
        alpha: Significance level (e.g., 0.05)

    Returns:
        Tuple of (accepted, rejected, tentative) feature name lists

    Decision Logic:
    - Accepted: p-value for H1: p > 0.5 is significant after Bonferroni
    - Rejected: p-value for H1: p < 0.5 is significant after Bonferroni
    - Tentative: Neither significant
    """
    assert n_iterations > 0, "Need at least 1 iteration"
    assert 0 < alpha < 1, f"Invalid alpha: {alpha}"

    n_features = len(cumulative_hits)
    assert n_features > 0, "No features to test"

    # Bonferroni correction
    alpha_corrected = alpha / n_features

    accepted: list[str] = []
    rejected: list[str] = []
    tentative: list[str] = []

    for feature, hits in cumulative_hits.items():
        # Test for acceptance: H1: p > 0.5 (feature is better than random)
        accept_result = binomtest(hits, n=n_iterations, p=0.5, alternative="greater")

        # Test for rejection: H1: p < 0.5 (feature is worse than random)
        reject_result = binomtest(hits, n=n_iterations, p=0.5, alternative="less")

        if accept_result.pvalue < alpha_corrected:
            accepted.append(feature)
        elif reject_result.pvalue < alpha_corrected:
            rejected.append(feature)
        else:
            tentative.append(feature)

    return accepted, rejected, tentative


@beartype
def tentative_rough_fix(
    tentative_features: list[str],
    importance_history: np.ndarray,  # type: ignore[type-arg]
    shadow_max_history: np.ndarray,  # type: ignore[type-arg]
    feature_names: list[str],
) -> tuple[list[str], list[str]]:
    """
    Resolve tentative features by comparing median importance to median max shadow.

    Args:
        tentative_features: Features still undecided
        importance_history: Shape (n_iterations, n_features) - real feature importances
        shadow_max_history: Shape (n_iterations,) - max shadow importance per iteration
        feature_names: Original feature names in column order

    Returns:
        Tuple of (newly_accepted, newly_rejected) from tentative set
    """
    if len(tentative_features) == 0:
        return [], []

    median_shadow_max = float(np.median(shadow_max_history))

    newly_accepted: list[str] = []
    newly_rejected: list[str] = []

    for feature in tentative_features:
        feature_idx = feature_names.index(feature)
        median_importance = float(np.median(importance_history[:, feature_idx]))

        if median_importance > median_shadow_max:
            newly_accepted.append(feature)
        else:
            newly_rejected.append(feature)

    return newly_accepted, newly_rejected
