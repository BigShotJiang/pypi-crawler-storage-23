"""
Shadow feature generation for Boruta algorithm.

Shadow features destroy feature-target correlation while
maintaining marginal distributions via independent column permutation.
"""

import numpy as np
import pandas as pd
from beartype import beartype

from .shuffle import ShuffleMode


@beartype
def create_shadow_features(
    X: pd.DataFrame,
    random_state: np.random.Generator,
    shuffle_mode: ShuffleMode = ShuffleMode.RANDOM,
    block_size: int | None = None,
    eras: pd.Series | None = None,  # type: ignore[type-arg]
) -> tuple[pd.DataFrame, list[str]]:
    """
    Create shadow features by permuting columns.

    Args:
        X: Original feature matrix.
        random_state: NumPy random generator for reproducibility.
        shuffle_mode: ShuffleMode enum value.
        block_size: Required for BLOCK mode.
        eras: Required for ERA mode. Series of era labels.

    Returns:
        Tuple of (shadow_dataframe, shadow_column_names)

    Shadow features destroy feature-target correlation while
    maintaining marginal distributions.
    """
    assert len(X) > 0, "Cannot create shadows for empty DataFrame"
    assert len(X.columns) > 0, "Cannot create shadows with no features"

    # Validation
    if shuffle_mode == ShuffleMode.BLOCK:
        assert block_size is not None, "block_size required for BLOCK mode"
        assert block_size > 0, f"block_size must be > 0, got {block_size}"
    if shuffle_mode == ShuffleMode.ERA:
        assert eras is not None, "eras required for ERA mode"
        assert len(eras) == len(X), f"eras length {len(eras)} != X length {len(X)}"

    shadow_data: dict[str, np.ndarray] = {}  # type: ignore[type-arg]
    shadow_names: list[str] = []

    for col in X.columns:
        shadow_name = f"shadow_{col}"
        col_values = np.asarray(X[col].values)

        if shuffle_mode == ShuffleMode.RANDOM:
            shadow_data[shadow_name] = random_state.permutation(col_values)
        elif shuffle_mode == ShuffleMode.BLOCK:
            assert block_size is not None  # Type narrowing
            shadow_data[shadow_name] = _permute_blocks(col_values, block_size, random_state)
        elif shuffle_mode == ShuffleMode.ERA:
            assert eras is not None  # Type narrowing
            shadow_data[shadow_name] = _permute_within_eras(
                col_values, np.asarray(eras.values), random_state
            )

        shadow_names.append(shadow_name)

    return pd.DataFrame(shadow_data, index=X.index), shadow_names


def _permute_blocks(
    values: np.ndarray,  # type: ignore[type-arg]
    block_size: int,
    rng: np.random.Generator,
) -> np.ndarray:  # type: ignore[type-arg]
    """Shuffle blocks of consecutive values."""
    n = len(values)
    blocks = []
    for start in range(0, n, block_size):
        end = min(start + block_size, n)
        blocks.append(values[start:end].copy())
    rng.shuffle(blocks)
    return np.concatenate(blocks)


def _permute_within_eras(
    values: np.ndarray,  # type: ignore[type-arg]
    eras: np.ndarray,  # type: ignore[type-arg]
    rng: np.random.Generator,
) -> np.ndarray:  # type: ignore[type-arg]
    """Shuffle values only within same era."""
    result = values.copy()
    unique_eras = np.unique(eras)
    for era in unique_eras:
        mask = eras == era
        era_values = values[mask]
        result[mask] = rng.permutation(era_values)
    return result
