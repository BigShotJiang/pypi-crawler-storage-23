"""
BorutaResult - Immutable result of Boruta feature selection.

Uses frozen dataclass for immutability and __post_init__ for validation.
"""

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class BorutaResult:
    """Immutable result of Boruta feature selection."""

    accepted_features: tuple[str, ...]  # Confirmed important
    rejected_features: tuple[str, ...]  # Confirmed unimportant
    tentative_features: tuple[str, ...]  # Undecided (if two_step=False)

    # Hit statistics
    feature_hits: dict[str, int]  # feature_name -> cumulative hits
    n_iterations: int  # Actual iterations completed

    # Importance history (for diagnostics)
    importance_history: np.ndarray  # type: ignore[type-arg]  # Shape: (n_iterations, n_features)
    shadow_max_history: np.ndarray  # type: ignore[type-arg]  # Shape: (n_iterations,) - max shadow per iteration

    def __post_init__(self) -> None:
        """Validate result integrity."""
        all_features = (
            set(self.accepted_features) | set(self.rejected_features) | set(self.tentative_features)
        )
        assert len(all_features) == len(self.feature_hits), "Feature count mismatch"

        # No overlap between categories
        assert not (set(self.accepted_features) & set(self.rejected_features)), (
            "Accept/reject overlap"
        )
        assert not (set(self.accepted_features) & set(self.tentative_features)), (
            "Accept/tentative overlap"
        )
        assert not (set(self.rejected_features) & set(self.tentative_features)), (
            "Reject/tentative overlap"
        )
