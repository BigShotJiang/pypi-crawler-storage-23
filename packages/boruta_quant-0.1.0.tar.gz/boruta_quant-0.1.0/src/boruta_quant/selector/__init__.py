"""
Boruta feature selector for boruta-quant.

This module provides the BorutaSelector class for temporal-aware,
OOS-only Boruta feature selection.

Example:
    >>> from boruta_quant.selector import BorutaSelector, BorutaSelectorConfig
    >>> from boruta_quant.metrics import rank_ic_scorer  # Quant finance scorer
    >>> from boruta_quant.oracle import PermutationImportanceOracle
    >>> from boruta_quant.temporal import PurgedTemporalCV, PurgedCVConfig
    >>>
    >>> oracle = PermutationImportanceOracle(
    ...     scoring=rank_ic_scorer,  # Use Rank IC for alpha signals
    ...     n_repeats=10,
    ...     random_state=42,
    ... )
    >>> selector = BorutaSelector(
    ...     config=BorutaSelectorConfig(n_trials=20, percentile=100, alpha=0.05, two_step=True, random_state=42),
    ...     oracle=oracle,
    ...     cv=PurgedTemporalCV(PurgedCVConfig(...)),
    ... )
    >>> result = selector.fit(X, y, timestamps, model)
"""

from boruta_quant.selector.config import BorutaSelectorConfig
from boruta_quant.selector.hypothesis import (
    binomial_test_features,
    calculate_hits,
    tentative_rough_fix,
)
from boruta_quant.selector.results import BorutaResult
from boruta_quant.selector.selector import BorutaSelector
from boruta_quant.selector.shadow import create_shadow_features
from boruta_quant.selector.shuffle import ShuffleMode, boundaries_to_eras

__all__ = [
    "BorutaSelector",
    "BorutaSelectorConfig",
    "BorutaResult",
    "create_shadow_features",
    "calculate_hits",
    "binomial_test_features",
    "tentative_rough_fix",
    "ShuffleMode",
    "boundaries_to_eras",
]
