"""Immutable profiling result dataclasses."""

from dataclasses import dataclass


@dataclass(frozen=True)
class ComponentProfile:
    """Immutable profile for a single component."""

    component: str
    total_elapsed_sec: float
    total_count: int
    total_memory_delta_gb: float
    max_peak_memory_gb: float
    call_count: int

    @property
    def throughput_per_sec(self) -> float:
        if self.total_elapsed_sec == 0:
            return 0.0
        return self.total_count / self.total_elapsed_sec

    @property
    def avg_time_per_item_ms(self) -> float:
        if self.total_count == 0:
            return 0.0
        return (self.total_elapsed_sec * 1000) / self.total_count


@dataclass(frozen=True)
class ProfilingReport:
    """Complete profiling report for a Boruta run."""

    components: tuple[ComponentProfile, ...]
    total_elapsed_sec: float
    total_memory_delta_gb: float
    max_peak_memory_gb: float
