"""
Context manager for timing and memory tracking.

Design by Contract:
- elapsed >= 0 (crashes if negative - clock went backwards)
- peak_memory >= 0 always
- memory_delta can be negative (memory released)
"""

import time
from typing import Self

import psutil
from beartype import beartype


@beartype
class ComponentTimer:
    """Context manager for timing code blocks with automatic elapsed tracking."""

    def __init__(self, track_memory: bool = True) -> None:
        self.track_memory = track_memory
        self.elapsed: float = 0.0
        self.memory_delta: float = 0.0
        self.peak_memory: float = 0.0
        self.system_memory_before: float = 0.0
        self.system_memory_after: float = 0.0
        self._start_time: float = 0.0
        self._start_memory: float = 0.0

    def __enter__(self) -> Self:
        if self.track_memory:
            process = psutil.Process()
            self._start_memory = process.memory_info().rss / (1024**3)  # GB
            self.system_memory_before = psutil.virtual_memory().percent
        self._start_time = time.perf_counter()
        return self

    def __exit__(self, *args: object) -> None:
        self.elapsed = time.perf_counter() - self._start_time

        # P1 Design by Contract: Elapsed time MUST be non-negative
        assert self.elapsed >= 0, (
            f"Elapsed time cannot be negative: {self.elapsed:.6f}s. "
            f"System clock went backwards or timing bug."
        )

        if self.track_memory:
            process = psutil.Process()
            end_memory = process.memory_info().rss / (1024**3)
            self.system_memory_after = psutil.virtual_memory().percent
            self.memory_delta = end_memory - self._start_memory
            self.peak_memory = end_memory

            # P1 Design by Contract: Peak memory MUST be non-negative
            assert self.peak_memory >= 0, (
                f"Peak memory cannot be negative: {self.peak_memory:.2f}GB"
            )
