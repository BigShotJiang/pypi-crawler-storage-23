"""Context manager helper for profiling operations."""

from collections.abc import Iterator
from contextlib import contextmanager

from beartype import beartype

from .session import ProfilingSession
from .timer import ComponentTimer


@beartype
@contextmanager
def profile_operation(
    label: str,
    session: ProfilingSession,
    count: int = 1,
    track_memory: bool = True,
) -> Iterator[ComponentTimer]:
    """
    Context manager for profiling operations with automatic session recording.

    Args:
        label: Component name for profiling session
        session: ProfilingSession instance to record timing
        count: Number of items processed (default: 1)
        track_memory: Whether to track memory usage (default: True)

    Yields:
        ComponentTimer instance for accessing elapsed time
    """
    with ComponentTimer(track_memory=track_memory) as timer:
        yield timer
    session.record(
        label,
        timer.elapsed,
        count,
        memory_delta=timer.memory_delta,
        peak_memory=timer.peak_memory,
    )
