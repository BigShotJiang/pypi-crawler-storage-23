"""
Thread-safe aggregation of profiling data across components.

Design by Contract:
- All elapsed times MUST be >= 0
- All counts MUST be >= 0
- NOT picklable (has lock) - use get_results() for serialization
"""

import json
import threading
from collections import defaultdict
from pathlib import Path

from beartype import beartype


class ProfilingSession:
    """Accumulates timing data across multiple components with statistics."""

    def __init__(self) -> None:
        self.timings: dict[str, list[float]] = defaultdict(list)
        self.counts: dict[str, list[int]] = defaultdict(list)
        self.memory_deltas: dict[str, list[float]] = defaultdict(list)
        self.peak_memory: dict[str, list[float]] = defaultdict(list)
        self._lock = threading.Lock()

    @beartype
    def record(
        self,
        label: str,
        elapsed: float,
        count: int = 1,
        memory_delta: float = 0.0,
        peak_memory: float = 0.0,
    ) -> None:
        """Record timing for a component (thread-safe)."""
        # P1 Design by Contract: Fail-fast on violations
        assert elapsed >= 0, f"Elapsed time must be non-negative: {elapsed}"
        assert count >= 0, f"Count must be non-negative: {count}"

        with self._lock:
            self.timings[label].append(elapsed)
            self.counts[label].append(count)
            if memory_delta != 0.0:
                self.memory_deltas[label].append(memory_delta)
            if peak_memory != 0.0:
                self.peak_memory[label].append(peak_memory)

    @beartype
    def get_results(self) -> dict[str, dict[str, float]]:
        """Get aggregated timing results (picklable dict)."""
        results: dict[str, dict[str, float]] = {}
        for label in self.timings:
            total_time = sum(self.timings[label])
            total_count = sum(self.counts[label])

            result: dict[str, float] = {
                "total_time": total_time,
                "total_count": float(total_count),
                "throughput": total_count / total_time if total_time > 0 else 0,
                "per_item_ms": (total_time / total_count * 1000) if total_count > 0 else 0,
            }

            if label in self.memory_deltas and self.memory_deltas[label]:
                result["memory_delta"] = sum(self.memory_deltas[label])
            if label in self.peak_memory and self.peak_memory[label]:
                result["peak_memory"] = max(self.peak_memory[label])

            results[label] = result
        return results

    @beartype
    def print_summary(self, title: str = "Profiling Summary") -> None:
        """Pretty-print profiling results."""
        results = self.get_results()
        has_memory = any("memory_delta" in m or "peak_memory" in m for m in results.values())
        width = 120 if has_memory else 90

        print()
        print("=" * width)
        print(f"{title:^{width}}")
        print("=" * width)

        header = f"{'Component':<40} {'Time':>10} {'Count':>10} {'Throughput':>15} {'Per-Item':>10}"
        if has_memory:
            header += f" {'Mem Δ':>10} {'Peak':>10}"
        print(header)
        print("-" * width)

        total_time = 0.0
        for label, metrics in results.items():
            total_time += metrics["total_time"]
            throughput = metrics["throughput"]
            if throughput >= 1.0:
                throughput_str = f"{throughput:.1f} items/s"
            elif throughput >= 0.01:
                throughput_str = f"{throughput * 60:.1f} items/min"
            else:
                throughput_str = f"{throughput * 3600:.1f} items/hr"

            line = (
                f"{label:<40} "
                f"{metrics['total_time']:>9.2f}s "
                f"{int(metrics['total_count']):>10} "
                f"{throughput_str:>15} "
                f"{metrics['per_item_ms']:>9.1f}ms"
            )
            if has_memory:
                mem_delta = metrics.get("memory_delta", 0.0)
                peak_mem = metrics.get("peak_memory", 0.0)
                line += f" {mem_delta:>9.2f}G {peak_mem:>9.2f}G"
            print(line)

        print("=" * width)
        print(f"{'TOTAL':^40} {total_time:>9.2f}s")
        print("=" * width)
        print()

    @beartype
    def flush_to_file(self, path: Path) -> None:
        """Write current metrics to JSON checkpoint file (thread-safe)."""
        assert path is not None, "Checkpoint path cannot be None"
        with self._lock:
            results = self.get_results()
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, "w") as f:
                json.dump(results, f, indent=2, default=str)
