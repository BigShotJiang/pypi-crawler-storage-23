"""Version information for boruta-quant."""

__version__ = "0.1.0"
