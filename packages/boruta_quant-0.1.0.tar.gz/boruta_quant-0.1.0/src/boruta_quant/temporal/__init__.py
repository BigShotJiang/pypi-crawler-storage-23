"""
Temporal cross-validation for boruta-quant.

This module provides temporal-aware cross-validation strategies that maintain
the integrity of time series data by preventing future information leakage.

Available CV Strategies:
- PurgedTemporalCV: Walk-forward CV with purge and embargo windows.
- EraBasedCV: Split by discrete time periods (eras).

Key Concepts:
- Purge window: Gap between training and validation to prevent label leakage.
- Embargo window: Gap after validation to prevent information bleed.
- Era: Discrete time period for grouping observations.

Example:
    >>> from boruta_quant.temporal import PurgedTemporalCV
    >>>
    >>> cv = PurgedTemporalCV(
    ...     n_splits=5,
    ...     purge_days=5,
    ...     embargo_days=5,
    ...     test_size=0.2,
    ... )
    >>> for train_idx, val_idx in cv.split(X, y, timestamps):
    ...     X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
"""

from boruta_quant.temporal.config import PurgedCVConfig
from boruta_quant.temporal.cv import TemporalCVProtocol, validate_temporal_inputs
from boruta_quant.temporal.purged_cv import PurgedTemporalCV
from boruta_quant.temporal.split import PurgedCVSplit

__all__ = [
    "TemporalCVProtocol",
    "validate_temporal_inputs",
    "PurgedCVConfig",
    "PurgedCVSplit",
    "PurgedTemporalCV",
]
