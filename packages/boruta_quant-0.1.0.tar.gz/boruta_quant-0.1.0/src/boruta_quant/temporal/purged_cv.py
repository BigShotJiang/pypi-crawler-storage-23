"""
PurgedTemporalCV implementation following López de Prado methodology.

Eliminates temporal leakage through:
1. Purging: Remove overlapping samples between train/test
2. Embargo: Account for execution delays
3. Temporal ordering: Strict chronological separation
"""

from __future__ import annotations

from collections.abc import Iterator

import numpy as np
import pandas as pd
from beartype import beartype

from .config import PurgedCVConfig
from .cv import validate_temporal_inputs
from .split import PurgedCVSplit


@beartype
class PurgedTemporalCV:
    """Purged Cross-Validation with embargo windows."""

    def __init__(self, config: PurgedCVConfig) -> None:
        self.config = config

    def split(
        self,
        X: pd.DataFrame,
        y: pd.Series,  # type: ignore[type-arg]
        timestamps: pd.DatetimeIndex,
    ) -> Iterator[PurgedCVSplit]:
        """Generate purged CV splits."""
        validate_temporal_inputs(X, y, timestamps)

        total_size = len(X)
        test_size = int(total_size * self.config.test_size_ratio)

        min_total = self.config.min_train_size + test_size
        assert total_size >= min_total, f"Insufficient data: {total_size} < {min_total}"

        for fold in range(self.config.n_splits):
            test_start_idx = self._calculate_test_start(fold, total_size, test_size)
            test_end_idx = test_start_idx + test_size

            train_idx, val_idx, purge_idx, embargo_idx = self._apply_purge_embargo(
                timestamps, test_start_idx, test_end_idx
            )

            if len(train_idx) < self.config.min_train_size:
                continue

            yield PurgedCVSplit(
                train_indices=train_idx,
                val_indices=val_idx,
                purge_indices=purge_idx,
                embargo_indices=embargo_idx,
                fold_id=f"purged_cv_fold_{fold}",
                metadata={
                    "fold": fold,
                    "purge_window_days": self.config.purge_window_days,
                    "embargo_window_days": self.config.embargo_window_days,
                },
            )

    def _calculate_test_start(self, fold: int, total: int, test_size: int) -> int:
        """Calculate test start index for given fold."""
        available = total - test_size
        step = available // self.config.n_splits
        return min(fold * step, total - test_size)

    def _apply_purge_embargo(
        self,
        timestamps: pd.DatetimeIndex,
        test_start_idx: int,
        test_end_idx: int,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Apply purge and embargo logic to prevent temporal leakage."""
        test_start_time = timestamps[test_start_idx]
        test_end_time = timestamps[test_end_idx - 1]

        purge_window = pd.Timedelta(days=self.config.purge_window_days)
        purge_start_time = test_start_time - purge_window

        embargo_window = pd.Timedelta(days=self.config.embargo_window_days)
        embargo_end_time = test_end_time + embargo_window

        # Boolean masks
        train_mask = (timestamps < purge_start_time) | (timestamps > embargo_end_time)
        test_mask = (timestamps >= test_start_time) & (timestamps <= test_end_time)
        purge_mask = (timestamps >= purge_start_time) & (timestamps < test_start_time)
        embargo_mask = (timestamps > test_end_time) & (timestamps <= embargo_end_time)

        return (
            np.where(train_mask)[0],
            np.where(test_mask)[0],
            np.where(purge_mask)[0],
            np.where(embargo_mask)[0],
        )

    def get_n_splits(self) -> int:
        """Return number of splits."""
        return self.config.n_splits

    def validate_temporal_integrity(
        self,
        X: pd.DataFrame,
        y: pd.Series,  # type: ignore[type-arg]
        timestamps: pd.DatetimeIndex,
    ) -> bool:
        """Validate no temporal leakage in splits."""
        validate_temporal_inputs(X, y, timestamps)

        for split in self.split(X, y, timestamps):
            train_times = timestamps[split.train_indices]
            val_times = timestamps[split.val_indices]

            # Check 1: Training before purge window before test
            if len(train_times) > 0 and len(val_times) > 0:
                # Training data in purge window = leakage
                purge_start = val_times.min() - pd.Timedelta(days=self.config.purge_window_days)
                train_in_purge = train_times[
                    (train_times >= purge_start) & (train_times < val_times.min())
                ]
                if len(train_in_purge) > 0:
                    return False

            # Check 2: No overlap between segments
            all_idx = (
                set(split.train_indices)
                | set(split.val_indices)
                | set(split.purge_indices)
                | set(split.embargo_indices)
            )
            total_assigned = (
                len(split.train_indices)
                + len(split.val_indices)
                + len(split.purge_indices)
                + len(split.embargo_indices)
            )
            if len(all_idx) != total_assigned:
                return False

        return True
