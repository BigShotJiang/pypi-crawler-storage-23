"""Purged CV split result dataclass."""

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class PurgedCVSplit:
    """Result of a single purged CV split."""

    train_indices: np.ndarray
    val_indices: np.ndarray
    purge_indices: np.ndarray
    embargo_indices: np.ndarray
    fold_id: str
    metadata: dict[str, Any]

    def __post_init__(self) -> None:
        """Validate split integrity on construction."""
        assert len(self.train_indices) > 0, "Empty training set"
        assert len(self.val_indices) > 0, "Empty validation set"

        # No overlap between segments
        train_set = set(self.train_indices)
        val_set = set(self.val_indices)
        assert not train_set & val_set, "Train/val overlap detected"
