"""
Temporal cross-validation protocols and base implementations.

This module defines the protocol for temporal CV and provides the
PurgedTemporalCV implementation based on López de Prado's methodology.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Protocol

import numpy as np
import numpy.typing as npt
import pandas as pd
from beartype import beartype


class TemporalCVProtocol(Protocol):
    """
    Protocol for temporal cross-validation strategies.

    All implementations must generate train/validation splits that
    maintain temporal integrity:
    - Training data must precede validation data
    - No overlap between training and validation periods
    - Optional purge/embargo windows to prevent information leakage
    """

    def split(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        timestamps: pd.DatetimeIndex,
    ) -> Iterator[tuple[npt.NDArray[np.intp], npt.NDArray[np.intp]]]:
        """
        Generate train/validation indices with temporal integrity.

        Args:
            X: Feature matrix.
            y: Target variable.
            timestamps: Datetime index for temporal ordering.

        Yields:
            Tuple of (train_indices, validation_indices) as numpy arrays.

        Raises:
            AssertionError: If timestamps are not sorted or have wrong length.
        """
        ...

    def get_n_splits(self) -> int:
        """Return the number of splits."""
        ...


@beartype
def validate_temporal_inputs(
    X: pd.DataFrame,
    y: pd.Series,  # type: ignore[type-arg]
    timestamps: pd.DatetimeIndex,
) -> None:
    """
    Validate inputs for temporal cross-validation.

    Raises:
        AssertionError: If any validation fails.
    """
    assert len(X) == len(y), f"X and y length mismatch: {len(X)} vs {len(y)}"
    assert len(X) == len(timestamps), (
        f"X and timestamps length mismatch: {len(X)} vs {len(timestamps)}"
    )
    assert timestamps.is_monotonic_increasing, "Timestamps must be sorted ascending"
    assert timestamps.tz is not None, "Timestamps must be timezone-aware (UTC recommended)"
