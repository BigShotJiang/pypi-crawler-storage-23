"""Configuration for PurgedTemporalCV - ALL required, no defaults."""

from pydantic import BaseModel, Field, field_validator


class PurgedCVConfig(BaseModel):
    """Configuration for Purged Cross-Validation - ALL required."""

    n_splits: int = Field(..., description="Number of CV folds")
    purge_window_days: int = Field(..., description="Days to purge before test")
    embargo_window_days: int = Field(..., description="Days to embargo after test")
    min_train_size: int = Field(..., description="Minimum training samples")
    test_size_ratio: float = Field(..., description="Test set ratio")

    @field_validator("n_splits")
    @classmethod
    def validate_n_splits(cls, v: int) -> int:
        assert 2 <= v <= 20, f"n_splits must be 2-20, got {v}"
        return v

    @field_validator("purge_window_days", "embargo_window_days")
    @classmethod
    def validate_window_days(cls, v: int) -> int:
        assert 0 <= v <= 365, f"Window days must be 0-365, got {v}"
        return v

    @field_validator("min_train_size")
    @classmethod
    def validate_min_train_size(cls, v: int) -> int:
        assert v > 0, f"min_train_size must be positive, got {v}"
        return v

    @field_validator("test_size_ratio")
    @classmethod
    def validate_test_size_ratio(cls, v: float) -> float:
        assert 0 < v < 1, f"test_size_ratio must be (0, 1), got {v}"
        return v
