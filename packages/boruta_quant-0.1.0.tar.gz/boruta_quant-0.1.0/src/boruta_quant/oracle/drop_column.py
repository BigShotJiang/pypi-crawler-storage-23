"""
Drop-Column Importance Oracle - Ablation-based importance computation.

Importance is measured by removing each feature, refitting, and computing
the performance drop on validation data.

CRITICAL: Importance is ALWAYS computed on validation data, NEVER on training.
"""

from __future__ import annotations

from typing import Any

import pandas as pd
from beartype import beartype
from sklearn.base import clone

from .base import ScorerType, get_scorer_callable, validate_importance_inputs


@beartype
class DropColumnImportanceOracle:
    """
    Drop-column importance: retrain without each feature, measure degradation.

    This is computationally expensive (N model fits per feature) but provides
    a model-agnostic importance measure that accounts for feature interactions.

    Importance = baseline_score - reduced_score
    Higher values indicate more important features.
    """

    def __init__(
        self,
        scoring: ScorerType,
    ) -> None:
        """
        Initialize DropColumnImportanceOracle.

        Args:
            scoring: Sklearn scorer string (e.g., "r2", "neg_mean_squared_error")
                     or callable(estimator, X, y) -> float.

        Raises:
            AssertionError: If scoring is None.
        """
        assert scoring is not None, "scoring is required"
        self.scoring = scoring

    def compute_importance(
        self,
        model: Any,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series,
        feature_names: list[str],
    ) -> dict[str, float]:
        """
        Compute drop-column importance on VALIDATION data only.

        For each feature:
        1. Remove the feature from training and validation sets
        2. Clone and refit the model on reduced training data
        3. Score on reduced validation data
        4. Importance = baseline_score - reduced_score

        Args:
            model: Unfitted model instance (will be cloned for each feature).
            X_train: Training features (for fitting only).
            y_train: Training target (for fitting only).
            X_val: Validation features (importance computed HERE).
            y_val: Validation target (importance computed HERE).
            feature_names: List of feature names in X_train/X_val.

        Returns:
            Dict mapping feature name to importance score.
            Higher values indicate more important features.
        """
        validate_importance_inputs(X_train, y_train, X_val, y_val, feature_names)

        # DRY: Use shared scorer utility
        scorer = get_scorer_callable(self.scoring)

        # Baseline: fit on all features
        baseline_model = clone(model)
        baseline_model.fit(X_train, y_train)
        baseline_score = scorer(baseline_model, X_val, y_val)

        importances: dict[str, float] = {}

        for feature in feature_names:
            remaining = [f for f in feature_names if f != feature]
            reduced_model = clone(model)
            reduced_model.fit(X_train[remaining], y_train)
            reduced_score = scorer(reduced_model, X_val[remaining], y_val)
            importances[feature] = baseline_score - reduced_score

        return importances
