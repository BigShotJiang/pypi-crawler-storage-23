"""
Permutation Importance Oracle - OOS-only importance computation.

CRITICAL: Importance is ALWAYS computed on validation data, NEVER on training.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import pandas as pd
from beartype import beartype
from sklearn.base import clone
from sklearn.inspection import permutation_importance

from .base import validate_importance_inputs


@beartype
class PermutationImportanceOracle:
    """
    Permutation importance computed on validation data only.

    The model is fitted on training data, but importance is measured
    by permuting features in the validation set and measuring prediction
    degradation.
    """

    def __init__(
        self,
        scoring: str | Callable[[Any, Any, Any], float] = "neg_mean_squared_error",
        n_repeats: int = 10,
        random_state: int | None = None,
    ) -> None:
        self.scoring = scoring
        self.n_repeats = n_repeats
        self.random_state = random_state

    def compute_importance(
        self,
        model: Any,
        X_train: pd.DataFrame,
        y_train: pd.Series,  # type: ignore[type-arg]
        X_val: pd.DataFrame,
        y_val: pd.Series,  # type: ignore[type-arg]
        feature_names: list[str],
    ) -> dict[str, float]:
        """
        Compute permutation importance on VALIDATION data only.

        Args:
            model: Unfitted model instance (will be cloned and fitted).
            X_train: Training features (for fitting only).
            y_train: Training target (for fitting only).
            X_val: Validation features (importance computed HERE).
            y_val: Validation target (importance computed HERE).
            feature_names: Feature names in X_train/X_val.

        Returns:
            Dict mapping feature name to importance score.
        """
        # Validate inputs
        validate_importance_inputs(X_train, y_train, X_val, y_val, feature_names)

        # Clone and fit model on training data
        fitted_model = clone(model)
        fitted_model.fit(X_train, y_train)

        # Compute importance on VALIDATION data only
        result = permutation_importance(
            fitted_model,
            X_val,
            y_val,
            scoring=self._get_scorer(),
            n_repeats=self.n_repeats,
            random_state=self.random_state,
            n_jobs=-1,
        )

        return dict(zip(feature_names, result.importances_mean, strict=True))

    def _get_scorer(self) -> str | Callable[[Any, Any, Any], float]:
        """Get sklearn scorer."""
        return self.scoring
