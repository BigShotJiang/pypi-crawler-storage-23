"""
Base protocol for importance oracles.

All importance oracles must implement this protocol to ensure they compute
importance on validation data only, never on training data.
"""

from collections.abc import Callable
from typing import Any, Protocol

import numpy as np
import pandas as pd
from beartype import beartype
from sklearn.metrics import get_scorer

# Type alias for scorer callables (DRY: used by all oracles)
ScorerType = str | Callable[[Any, pd.DataFrame, pd.Series], float]
ScorerCallable = Callable[[Any, pd.DataFrame, pd.Series], float]

__all__ = [
    "ImportanceOracle",
    "validate_importance_inputs",
    "get_scorer_callable",
    "ScorerType",
    "ScorerCallable",
]


class ImportanceOracle(Protocol):
    """
    Protocol for pluggable importance computation.

    All implementations MUST compute importance on validation data only.
    This is the core contract that ensures temporal integrity in feature selection.

    The oracle is responsible for:
    1. Fitting the model on training data (X_train, y_train)
    2. Computing feature importance on validation data (X_val, y_val)
    3. Returning importance scores for all features

    CRITICAL: Importance MUST be computed on X_val, y_val only.
    Computing importance on training data causes look-ahead bias.
    """

    @beartype
    def compute_importance(
        self,
        model: Any,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series,
        feature_names: list[str],
    ) -> dict[str, float]:
        """
        Compute feature importance on VALIDATION data only.

        Args:
            model: Unfitted model instance (will be cloned and fitted internally).
            X_train: Training features (for fitting only).
            y_train: Training target (for fitting only).
            X_val: Validation features (importance computed HERE).
            y_val: Validation target (importance computed HERE).
            feature_names: List of feature names in X_train/X_val.

        Returns:
            Dict mapping feature name to importance score.
            Higher values indicate more important features.

        Raises:
            AssertionError: If validation data is empty or has wrong shape.
        """
        ...


@beartype
def validate_importance_inputs(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_val: pd.DataFrame,
    y_val: pd.Series,
    feature_names: list[str],
) -> None:
    """
    Validate inputs to importance computation.

    This is a helper function that all oracle implementations should call
    at the start of compute_importance().

    Raises:
        AssertionError: If any validation fails.
    """
    assert len(X_train) > 0, "X_train is empty"
    assert len(X_val) > 0, "X_val is empty - cannot compute OOS importance"
    assert len(y_train) == len(X_train), (
        f"y_train length mismatch: {len(y_train)} vs {len(X_train)}"
    )
    assert len(y_val) == len(X_val), f"y_val length mismatch: {len(y_val)} vs {len(X_val)}"
    assert list(X_train.columns) == feature_names, "X_train columns don't match feature_names"
    assert list(X_val.columns) == feature_names, "X_val columns don't match feature_names"
    assert not np.any(np.isnan(X_train.values)), "X_train contains NaN values"
    assert not np.any(np.isnan(X_val.values)), "X_val contains NaN values"


@beartype
def get_scorer_callable(
    scoring: ScorerType,
) -> ScorerCallable:
    """
    Convert scoring parameter to callable scorer function.

    DRY: Shared by all importance oracles that need custom scoring.

    Args:
        scoring: Sklearn scorer string (e.g., "r2", "neg_mean_squared_error")
                 or callable(estimator, X, y) -> float.

    Returns:
        Callable that takes (estimator, X, y) and returns score.
    """
    if callable(scoring):
        return scoring
    scorer = get_scorer(scoring)
    return lambda est, X, y: scorer(est, X, y)
