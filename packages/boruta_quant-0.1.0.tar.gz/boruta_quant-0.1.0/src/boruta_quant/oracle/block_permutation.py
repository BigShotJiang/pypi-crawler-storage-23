"""
Block Permutation Importance Oracle - Temporal-aware permutation importance.

Unlike standard permutation importance which shuffles individual rows,
this oracle shuffles contiguous blocks to preserve within-block temporal structure.
This is more appropriate for time-series data.

CRITICAL: Importance is ALWAYS computed on validation data, NEVER on training.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
from beartype import beartype
from sklearn.base import clone

from .base import ScorerType, get_scorer_callable, validate_importance_inputs


@beartype
class BlockPermutationImportanceOracle:
    """
    Block permutation importance: shuffle temporal blocks, not individual rows.

    For time-series data, shuffling individual rows destroys temporal patterns
    within blocks. Block permutation preserves within-block structure while
    breaking cross-block dependencies.

    Importance = baseline_score - mean(permuted_scores)
    Higher values indicate more important features.
    """

    def __init__(
        self,
        scoring: ScorerType,
        block_size: int,
        n_repeats: int = 10,
        random_state: int | None = None,
    ) -> None:
        """
        Initialize BlockPermutationImportanceOracle.

        Args:
            scoring: Sklearn scorer string or callable(estimator, X, y) -> float.
            block_size: Number of consecutive rows per block.
            n_repeats: Number of permutation repeats (default: 10).
            random_state: Seed for reproducibility (default: None).

        Raises:
            AssertionError: If scoring is None, block_size <= 0, or n_repeats <= 0.
        """
        assert scoring is not None, "scoring is required"
        assert block_size > 0, f"block_size must be > 0, got {block_size}"
        assert n_repeats > 0, f"n_repeats must be > 0, got {n_repeats}"

        self.scoring = scoring
        self.block_size = block_size
        self.n_repeats = n_repeats
        self.random_state = random_state

    def compute_importance(
        self,
        model: Any,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series,
        feature_names: list[str],
    ) -> dict[str, float]:
        """
        Compute block permutation importance on VALIDATION data only.

        For each feature:
        1. Divide validation data into blocks
        2. Shuffle the order of blocks (preserving within-block order)
        3. Score on shuffled data
        4. Repeat n_repeats times
        5. Importance = baseline_score - mean(permuted_scores)

        Args:
            model: Unfitted model instance (will be cloned and fitted once).
            X_train: Training features (for fitting only).
            y_train: Training target (for fitting only).
            X_val: Validation features (importance computed HERE).
            y_val: Validation target (importance computed HERE).
            feature_names: List of feature names in X_train/X_val.

        Returns:
            Dict mapping feature name to importance score.
        """
        validate_importance_inputs(X_train, y_train, X_val, y_val, feature_names)

        n_val = len(X_val)
        assert self.block_size <= n_val, (
            f"block_size ({self.block_size}) > validation set size ({n_val})"
        )

        rng = np.random.default_rng(self.random_state)
        # DRY: Use shared scorer utility
        scorer = get_scorer_callable(self.scoring)

        # Fit model once on training data
        fitted_model = clone(model)
        fitted_model.fit(X_train, y_train)
        baseline_score = scorer(fitted_model, X_val, y_val)

        block_indices = self._compute_block_indices(n_val)
        importances: dict[str, float] = {}

        for feature in feature_names:
            permuted_scores: list[float] = []

            for _ in range(self.n_repeats):
                X_permuted = X_val.copy()
                X_permuted[feature] = self._permute_blocks(
                    X_val[feature].values, block_indices, rng
                )
                score = scorer(fitted_model, X_permuted, y_val)
                permuted_scores.append(score)

            importances[feature] = baseline_score - float(np.mean(permuted_scores))

        return importances

    def _compute_block_indices(self, n_samples: int) -> list[tuple[int, int]]:
        """
        Compute block start/end indices.

        Args:
            n_samples: Total number of samples.

        Returns:
            List of (start, end) tuples for each block.
        """
        blocks: list[tuple[int, int]] = []
        start = 0
        while start < n_samples:
            end = min(start + self.block_size, n_samples)
            blocks.append((start, end))
            start = end
        return blocks

    def _permute_blocks(
        self,
        values: np.ndarray,
        block_indices: list[tuple[int, int]],
        rng: np.random.Generator,
    ) -> np.ndarray:
        """
        Permute values by shuffling blocks.

        Args:
            values: 1D array of feature values.
            block_indices: List of (start, end) tuples.
            rng: Numpy random generator.

        Returns:
            Permuted values with blocks shuffled but within-block order preserved.
        """
        blocks = [values[start:end].copy() for start, end in block_indices]
        rng.shuffle(blocks)
        return np.concatenate(blocks)
