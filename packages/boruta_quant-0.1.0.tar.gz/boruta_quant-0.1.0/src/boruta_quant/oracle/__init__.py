"""
Importance oracles for boruta-quant.

All oracles compute importance on VALIDATION data only (never training data).

Available Oracles:
- PermutationImportanceOracle: Default. OOS permutation importance.
- DropColumnImportanceOracle: Ablation-based importance (refit without feature).
- BlockPermutationImportanceOracle: Temporal-aware block permutation.

Example:
    >>> from boruta_quant.oracle import PermutationImportanceOracle
    >>>
    >>> oracle = PermutationImportanceOracle(
    ...     scoring="neg_mean_squared_error",
    ...     n_repeats=10,
    ...     random_state=42,
    ... )
"""

from boruta_quant.oracle.base import ImportanceOracle, validate_importance_inputs
from boruta_quant.oracle.block_permutation import BlockPermutationImportanceOracle
from boruta_quant.oracle.drop_column import DropColumnImportanceOracle
from boruta_quant.oracle.permutation import PermutationImportanceOracle

__all__ = [
    "ImportanceOracle",
    "validate_importance_inputs",
    "PermutationImportanceOracle",
    "DropColumnImportanceOracle",
    "BlockPermutationImportanceOracle",
]
