"""
boruta-quant: Temporal-aware Boruta feature selection for quantitative finance.

OOS-only importance computation with purged cross-validation,
for financial time series where temporal integrity is critical.

Example:
    >>> from boruta_quant import BorutaSelector, BorutaSelectorConfig
    >>> from boruta_quant.oracle import PermutationImportanceOracle
    >>> from boruta_quant.temporal import PurgedTemporalCV, PurgedCVConfig
    >>>
    >>> selector = BorutaSelector(
    ...     config=BorutaSelectorConfig(n_trials=20, percentile=100, alpha=0.05, two_step=True, random_state=42),
    ...     oracle=PermutationImportanceOracle(scoring="neg_mean_squared_error"),
    ...     cv=PurgedTemporalCV(PurgedCVConfig(n_splits=5, purge_window_days=5, embargo_window_days=5, min_train_size=100, test_size_ratio=0.2)),
    ... )
    >>> result = selector.fit(X, y, timestamps, model)
    >>> print(result.accepted_features)
"""

from boruta_quant._version import __version__
from boruta_quant.selector import BorutaResult, BorutaSelector, BorutaSelectorConfig

__all__ = [
    "__version__",
    "BorutaSelector",
    "BorutaSelectorConfig",
    "BorutaResult",
]
