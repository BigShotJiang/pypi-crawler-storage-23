"""
Rank Information Coefficient (IC) scoring metric.

The Rank IC is the standard metric in quantitative finance for evaluating
alpha signals. It measures the Spearman correlation between predicted
values and actual forward returns.

Why Rank IC?
- Robust to outliers (uses ranks, not raw values)
- Interpretable: -1 to +1 scale
- Industry standard for alpha research
- Works with continuous predictions
"""

from typing import Any

import numpy as np
import numpy.typing as npt
from beartype import beartype
from scipy.stats import spearmanr
from sklearn.metrics import make_scorer


@beartype
def rank_ic(y_true: npt.NDArray[Any], y_pred: npt.NDArray[Any]) -> float:
    """
    Compute Rank Information Coefficient (Spearman correlation).

    Args:
        y_true: Actual values (e.g., forward returns).
        y_pred: Predicted values (e.g., alpha signal).

    Returns:
        Spearman correlation coefficient in [-1, 1].
        Returns 0.0 if correlation cannot be computed (e.g., constant input).

    Example:
        >>> y_true = np.array([0.01, -0.02, 0.03, -0.01, 0.02])
        >>> y_pred = np.array([0.5, -0.3, 0.8, -0.2, 0.4])
        >>> ic = rank_ic(y_true, y_pred)
        >>> print(f"IC: {ic:.4f}")
    """
    if len(y_true) < 2:
        return 0.0

    # Handle constant arrays
    if np.std(y_true) == 0 or np.std(y_pred) == 0:
        return 0.0

    result = spearmanr(y_true, y_pred)
    # Use index access for type safety (result is SignificanceResult namedtuple)
    correlation: float = float(result[0])  # type: ignore[arg-type]

    # Handle NaN (can occur with insufficient variance)
    if np.isnan(correlation):
        return 0.0

    return correlation


# sklearn-compatible scorer for use with permutation_importance
rank_ic_scorer = make_scorer(rank_ic, greater_is_better=True)
"""
sklearn-compatible scorer for Rank IC.

Usage with PermutationImportanceOracle:
    >>> oracle = PermutationImportanceOracle(scoring=rank_ic_scorer)

Usage with sklearn cross_val_score:
    >>> from sklearn.model_selection import cross_val_score
    >>> scores = cross_val_score(model, X, y, cv=cv, scoring=rank_ic_scorer)
"""
