"""
AUC-ROC scorer for classification-based feature selection.

Use cases:
- Direction prediction (up/down)
- Regime classification
- Binary signal classification
"""

from __future__ import annotations

from typing import Any

import numpy as np
import numpy.typing as npt
from beartype import beartype
from sklearn.metrics import make_scorer, roc_auc_score


@beartype
def auc_score(
    y_true: npt.NDArray[Any],
    y_pred_proba: npt.NDArray[Any],
) -> float:
    """
    Compute AUC-ROC score for binary classification.

    Args:
        y_true: True binary labels (0 or 1)
        y_pred_proba: Predicted probabilities for positive class

    Returns:
        AUC-ROC score in [0, 1]. 0.5 = random, 1.0 = perfect.

    Raises:
        AssertionError: If inputs have wrong shape or values.
    """
    assert len(y_true) == len(y_pred_proba), "Length mismatch"
    assert len(y_true) >= 2, "Need at least 2 samples"

    # Handle edge case: single class in y_true
    unique_classes = np.unique(y_true)
    if len(unique_classes) == 1:
        return 0.5  # Undefined AUC, return random baseline

    return float(roc_auc_score(y_true, y_pred_proba))


@beartype
def auc_scorer(
    estimator: Any,
    X: npt.NDArray[Any],
    y_true: npt.NDArray[Any],
) -> float:
    """
    sklearn-compatible AUC scorer for use with permutation_importance.

    Args:
        estimator: Fitted classifier with predict_proba method
        X: Feature matrix
        y_true: True binary labels

    Returns:
        AUC-ROC score
    """
    assert hasattr(estimator, "predict_proba"), "Estimator must have predict_proba"

    y_pred_proba = estimator.predict_proba(X)[:, 1]
    return auc_score(y_true, y_pred_proba)


# sklearn make_scorer compatible version
auc_scorer_sklearn = make_scorer(roc_auc_score, needs_proba=True, response_method="predict_proba")
"""
sklearn-compatible scorer for AUC-ROC.

Usage with PermutationImportanceOracle:
    >>> oracle = PermutationImportanceOracle(scoring=auc_scorer_sklearn)

Usage with sklearn cross_val_score:
    >>> from sklearn.model_selection import cross_val_score
    >>> scores = cross_val_score(model, X, y, cv=cv, scoring=auc_scorer_sklearn)
"""
