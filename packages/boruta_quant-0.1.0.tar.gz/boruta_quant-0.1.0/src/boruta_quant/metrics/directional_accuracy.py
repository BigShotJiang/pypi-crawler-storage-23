"""
Directional Accuracy scoring metric.

Measures what fraction of predictions got the sign right (up vs down).
The most intuitive alpha signal metric — "did you predict the right direction?"

Why Directional Accuracy?
- Every PM understands it immediately
- Works with continuous return predictions
- Complementary to Rank IC (IC measures rank order, DA measures sign)
- Baseline is 50% (random guessing)
"""

from typing import Any

import numpy as np
import numpy.typing as npt
from beartype import beartype
from sklearn.metrics import make_scorer


@beartype
def directional_accuracy(
    y_true: npt.NDArray[Any],
    y_pred: npt.NDArray[Any],
) -> float:
    """
    Compute directional accuracy (fraction of correct sign predictions).

    Args:
        y_true: Actual values (e.g., forward returns).
        y_pred: Predicted values (e.g., alpha signal).

    Returns:
        Fraction of correct sign predictions in [0.0, 1.0].
        0.5 = random, 1.0 = perfect direction.

    Raises:
        AssertionError: If inputs are empty or mismatched length.

    Example:
        >>> y_true = np.array([0.01, -0.02, 0.03, -0.01, 0.02])
        >>> y_pred = np.array([0.5, -0.3, 0.8, 0.2, 0.4])
        >>> da = directional_accuracy(y_true, y_pred)
        >>> print(f"DA: {da:.2%}")  # 80.00% (4/5 correct)
    """
    assert len(y_true) == len(y_pred), (
        f"Length mismatch: y_true={len(y_true)}, y_pred={len(y_pred)}"
    )
    assert len(y_true) > 0, "Need at least 1 sample"

    true_signs = np.sign(y_true)
    pred_signs = np.sign(y_pred)

    # Zero returns/predictions are ambiguous — count as correct only if both zero
    correct = true_signs == pred_signs
    return float(np.mean(correct))


# sklearn-compatible scorer for use with permutation_importance
directional_accuracy_scorer = make_scorer(directional_accuracy, greater_is_better=True)
"""
sklearn-compatible scorer for Directional Accuracy.

Usage with PermutationImportanceOracle:
    >>> oracle = PermutationImportanceOracle(scoring=directional_accuracy_scorer)
"""
