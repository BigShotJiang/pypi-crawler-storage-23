"""
Scoring metrics for boruta-quant.

Available Metrics:
- rank_ic / rank_ic_scorer: Spearman correlation (rank information coefficient).
- directional_accuracy / directional_accuracy_scorer: Fraction of correct sign predictions.
- auc_score / auc_scorer: Area under ROC curve.

Example:
    >>> from boruta_quant.metrics import rank_ic_scorer, directional_accuracy_scorer
    >>> from boruta_quant.oracle import PermutationImportanceOracle
    >>>
    >>> oracle = PermutationImportanceOracle(scoring=rank_ic_scorer)
"""

from boruta_quant.metrics.auc import auc_score, auc_scorer, auc_scorer_sklearn
from boruta_quant.metrics.directional_accuracy import (
    directional_accuracy,
    directional_accuracy_scorer,
)
from boruta_quant.metrics.rank_ic import rank_ic, rank_ic_scorer

__all__ = [
    "rank_ic",
    "rank_ic_scorer",
    "directional_accuracy",
    "directional_accuracy_scorer",
    "auc_score",
    "auc_scorer",
    "auc_scorer_sklearn",
]
