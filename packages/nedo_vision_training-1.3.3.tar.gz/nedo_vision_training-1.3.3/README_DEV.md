## Generating Protobuf

`python -m grpc_tools.protoc --proto_path=. --python_out=. --grpc_python_out=. nedo_vision_training/protos/*.proto`

## Running

```
source /mnt/linux-data/nedo-vision/venv-training-agent/bin/activate

python3 -m nedo_vision_training.cli run --token a17fbcbfd72a48e2b1878ba32e6a916f --server-host be.vision.sindika.co.id --rest-api-port 80
```
