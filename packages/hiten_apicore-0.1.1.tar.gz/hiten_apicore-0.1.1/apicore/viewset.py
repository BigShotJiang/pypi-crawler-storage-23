from rest_framework import viewsets, status
from rest_framework.response import Response
from .response import ApiResponse
from .errors import ApiError


class BaseViewSet(viewsets.ModelViewSet):
    def create(self, request, *args, **kwargs):
        try:
            serializer = self.get_serializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            self.perform_create(serializer)
            return Response(
                ApiResponse.success(serializer.data, "Created successfully"),
                status=status.HTTP_201_CREATED
            )
        except ApiError as e:
            return Response(
                ApiResponse.error(e.message, e.error_code),
                status=e.status_code
            )

    def list(self, request, *args, **kwargs):
        try:
            queryset = self.filter_queryset(self.get_queryset())
            page = self.paginate_queryset(queryset)
            if page is not None:
                serializer = self.get_serializer(page, many=True)
                return self.get_paginated_response(serializer.data)
            serializer = self.get_serializer(queryset, many=True)
            return Response(ApiResponse.success(serializer.data))
        except ApiError as e:
            return Response(
                ApiResponse.error(e.message, e.error_code),
                status=e.status_code
            )

    def retrieve(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            serializer = self.get_serializer(instance)
            return Response(ApiResponse.success(serializer.data))
        except ApiError as e:
            return Response(
                ApiResponse.error(e.message, e.error_code),
                status=e.status_code
            )

    def update(self, request, *args, **kwargs):
        try:
            partial = kwargs.pop('partial', False)
            instance = self.get_object()
            serializer = self.get_serializer(instance, data=request.data, partial=partial)
            serializer.is_valid(raise_exception=True)
            self.perform_update(serializer)
            return Response(
                ApiResponse.success(serializer.data, "Updated successfully")
            )
        except ApiError as e:
            return Response(
                ApiResponse.error(e.message, e.error_code),
                status=e.status_code
            )

    def destroy(self, request, *args, **kwargs):
        try:
            instance = self.get_object()
            self.perform_destroy(instance)
            return Response(
                ApiResponse.success(None, "Deleted successfully"),
                status=status.HTTP_204_NO_CONTENT
            )
        except ApiError as e:
            return Response(
                ApiResponse.error(e.message, e.error_code),
                status=e.status_code
            )