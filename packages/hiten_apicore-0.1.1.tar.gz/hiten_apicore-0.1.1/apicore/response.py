class ApiResponse:
    @staticmethod
    def success(data=None, message=None, meta=None):
        response = {
            "status": "success",
            "data": data,
        }
        if message:
            response["message"] = message
        if meta:
            response["meta"] = meta
        return response

    @staticmethod
    def error(message, error_code=None, errors=None):
        response = {
            "status": "error",
            "message": message,
        }
        if error_code:
            response["error_code"] = error_code
        if errors:
            response["errors"] = errors
        return response