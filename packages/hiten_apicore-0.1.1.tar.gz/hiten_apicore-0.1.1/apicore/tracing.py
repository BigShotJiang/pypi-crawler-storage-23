import logging
import time
import uuid
from functools import wraps

logger = logging.getLogger(__name__)


def trace_request(func):
    @wraps(func)
    def wrapper(self, request, *args, **kwargs):
        request_id = str(uuid.uuid4())
        start_time = time.time()
        
        logger.info(f"[{request_id}] {request.method} {request.path}")
        
        try:
            response = func(self, request, *args, **kwargs)
            duration = time.time() - start_time
            logger.info(f"[{request_id}] Completed in {duration:.2f}s - Status: {response.status_code}")
            return response
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"[{request_id}] Failed in {duration:.2f}s - Error: {str(e)}")
            raise
    return wrapper
