__version__ = "0.1.0"

# Lazy imports to avoid Django configuration issues
__all__ = [
    "BaseModel",
    "IsOwner",
    "IsActiveUser",
    "ReadOnly",
    "BaseViewSet",
    "ApiResponse",
    "ApiError",
    "ValidationError",
    "NotFoundError",
    "UnauthorizedError",
    "ForbiddenError",
    "StandardPagination",
    "trace_request",
    "HTTP_STATUS_CODES",
    "ERROR_CODES",
    "DEFAULT_PAGE_SIZE",
    "MAX_PAGE_SIZE",
    "initialize_from_json",
    "initialize_from_dict",
    "DefaultDataInitializer",
]


def __getattr__(name):
    if name == "BaseModel":
        from .basemodel import BaseModel
        return BaseModel
    elif name in ["IsOwner", "IsActiveUser", "ReadOnly"]:
        from .permission import IsOwner, IsActiveUser, ReadOnly
        return {"IsOwner": IsOwner, "IsActiveUser": IsActiveUser, "ReadOnly": ReadOnly}[name]
    elif name == "BaseViewSet":
        from .viewset import BaseViewSet
        return BaseViewSet
    elif name == "ApiResponse":
        from .response import ApiResponse
        return ApiResponse
    elif name in ["ApiError", "ValidationError", "NotFoundError", "UnauthorizedError", "ForbiddenError"]:
        from .errors import ApiError, ValidationError, NotFoundError, UnauthorizedError, ForbiddenError
        return {"ApiError": ApiError, "ValidationError": ValidationError, "NotFoundError": NotFoundError, 
                "UnauthorizedError": UnauthorizedError, "ForbiddenError": ForbiddenError}[name]
    elif name == "StandardPagination":
        from .pagination import StandardPagination
        return StandardPagination
    elif name == "trace_request":
        from .tracing import trace_request
        return trace_request
    elif name in ["HTTP_STATUS_CODES", "ERROR_CODES", "DEFAULT_PAGE_SIZE", "MAX_PAGE_SIZE"]:
        from .constants import HTTP_STATUS_CODES, ERROR_CODES, DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE
        return {"HTTP_STATUS_CODES": HTTP_STATUS_CODES, "ERROR_CODES": ERROR_CODES, 
                "DEFAULT_PAGE_SIZE": DEFAULT_PAGE_SIZE, "MAX_PAGE_SIZE": MAX_PAGE_SIZE}[name]
    elif name in ["initialize_from_json", "initialize_from_dict", "DefaultDataInitializer"]:
        from .initialize_defaults import initialize_from_json, initialize_from_dict, DefaultDataInitializer
        return {"initialize_from_json": initialize_from_json, "initialize_from_dict": initialize_from_dict,
                "DefaultDataInitializer": DefaultDataInitializer}[name]
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")