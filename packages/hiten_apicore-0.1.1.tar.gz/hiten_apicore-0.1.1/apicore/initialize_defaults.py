import json
from django.apps import apps
from django.db import transaction
from pathlib import Path


class DefaultDataInitializer:
    """
    Initialize default data for multiple models from JSON configuration.
    
    JSON format:
    {
        "app_label.ModelName": {
            "lookup_fields": ["field1", "field2"],
            "data": [
                {"field1": "value1", "field2": "value2", ...},
                ...
            ]
        }
    }
    """
    
    def __init__(self, json_path=None, json_data=None):
        self.json_path = json_path
        self.json_data = json_data
        self.results = {}
    
    def load_data(self):
        if self.json_data:
            return self.json_data
        if self.json_path:
            with open(self.json_path, 'r') as f:
                return json.load(f)
        raise ValueError("Either json_path or json_data must be provided")
    
    @transaction.atomic
    def initialize(self):
        data = self.load_data()
        
        for model_path, config in data.items():
            app_label, model_name = model_path.split('.')
            model = apps.get_model(app_label, model_name)
            
            lookup_fields = config.get('lookup_fields', [])
            records = config.get('data', [])
            
            created_count = 0
            updated_count = 0
            
            for record in records:
                lookup_data = {field: record[field] for field in lookup_fields if field in record}
                defaults = {k: v for k, v in record.items() if k not in lookup_fields}
                
                obj, created = model.objects.get_or_create(**lookup_data, defaults=defaults)
                
                if created:
                    created_count += 1
                else:
                    updated_count += 1
            
            self.results[model_path] = {
                'created': created_count,
                'updated': updated_count,
                'total': len(records)
            }
        
        return self.results


def initialize_from_json(json_path):
    """Helper function to initialize data from JSON file path"""
    initializer = DefaultDataInitializer(json_path=json_path)
    return initializer.initialize()


def initialize_from_dict(data):
    """Helper function to initialize data from dictionary"""
    initializer = DefaultDataInitializer(json_data=data)
    return initializer.initialize()
