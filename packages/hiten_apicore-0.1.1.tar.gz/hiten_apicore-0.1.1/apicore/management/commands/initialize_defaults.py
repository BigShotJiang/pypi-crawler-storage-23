from django.core.management.base import BaseCommand
from apicore.initialize_defaults import initialize_from_json
import sys


class Command(BaseCommand):
    help = "Initialize default data from JSON file"
    
    def add_arguments(self, parser):
        parser.add_argument(
            'json_file',
            type=str,
            help='Path to JSON file containing default data'
        )
    
    def handle(self, *args, **options):
        json_file = options['json_file']
        
        self.stdout.write(self.style.NOTICE(f"Loading data from {json_file}..."))
        
        try:
            results = initialize_from_json(json_file)
            
            self.stdout.write(self.style.SUCCESS("\nInitialization completed:"))
            for model_path, stats in results.items():
                self.stdout.write(
                    f"  {model_path}: {stats['created']} created, "
                    f"{stats['updated']} existing, {stats['total']} total"
                )
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"Error: {str(e)}"))
            sys.exit(1)
