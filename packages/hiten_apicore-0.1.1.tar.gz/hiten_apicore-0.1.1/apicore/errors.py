class ApiError(Exception):
    def __init__(self, message, status_code=400, error_code=None):
        self.message = message
        self.status_code = status_code
        self.error_code = error_code
        super().__init__(message)


class ValidationError(ApiError):
    def __init__(self, message, errors=None):
        super().__init__(message, status_code=400, error_code="VALIDATION_ERROR")
        self.errors = errors


class NotFoundError(ApiError):
    def __init__(self, message="Resource not found"):
        super().__init__(message, status_code=404, error_code="NOT_FOUND")


class UnauthorizedError(ApiError):
    def __init__(self, message="Unauthorized access"):
        super().__init__(message, status_code=401, error_code="UNAUTHORIZED")


class ForbiddenError(ApiError):
    def __init__(self, message="Access forbidden"):
        super().__init__(message, status_code=403, error_code="FORBIDDEN")
