# Apicore

Lightweight API infrastructure toolkit for Django REST Framework providing standardized responses, errors, permissions, and CRUD operations.

## Features

- BaseModel with timestamps and soft delete
- Standardized API responses
- Custom exception classes
- Permission classes (IsOwner, IsActiveUser, ReadOnly)
- BaseViewSet with CRUD operations
- Pagination with metadata
- Request tracing decorator
- Common constants

## Installation

```bash
pip install apicore
```

## Usage

### BaseModel

```python
from apicore import BaseModel

class Product(BaseModel):
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
```

### BaseViewSet

```python
from apicore import BaseViewSet, StandardPagination
from rest_framework.permissions import IsAuthenticated

class ProductViewSet(BaseViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [IsAuthenticated]
    pagination_class = StandardPagination
```

### Permissions

```python
from apicore import IsOwner, IsActiveUser, ReadOnly

class MyViewSet(BaseViewSet):
    permission_classes = [IsActiveUser, IsOwner]
```

### Error Handling

```python
from apicore import NotFoundError, ValidationError

def my_view(request):
    if not obj:
        raise NotFoundError("Product not found")
    if not valid:
        raise ValidationError("Invalid data", errors={"field": "error"})
```

### Request Tracing

```python
from apicore import trace_request

class MyViewSet(BaseViewSet):
    @trace_request
    def list(self, request, *args, **kwargs):
        return super().list(request, *args, **kwargs)
```

## Response Format

Success:
```json
{
    "status": "success",
    "data": {...},
    "message": "Operation successful",
    "meta": {...}
}
```

Error:
```json
{
    "status": "error",
    "message": "Error message",
    "error_code": "ERROR_CODE",
    "errors": {...}
}
```

## License

MIT
