# Deployment Guide

## Build Package

```bash
python -m build
```

This creates `dist/` folder with:
- `hiten_apicore-0.1.0.tar.gz`
- `hiten_apicore-0.1.0-py3-none-any.whl`

## Upload to PyPI

### Test PyPI (recommended first)
```bash
python -m twine upload --repository testpypi dist/*
```

### Production PyPI
```bash
python -m twine upload dist/*
```

## Install from PyPI

```bash
pip install hiten-apicore
```

## Local Development Install

```bash
pip install -e .
```

## Usage in Django Project

1. Install package:
```bash
pip install hiten-apicore
```

2. Use in your Django app:
```python
from apicore import BaseModel, BaseViewSet, ApiResponse
```

That's it - no need to add to INSTALLED_APPS since it's a library, not a Django app.
