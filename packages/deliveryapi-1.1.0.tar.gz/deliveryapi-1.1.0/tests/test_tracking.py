import httpx
import pytest

from deliveryapi import ApiError, AuthenticationError, DeliveryAPIClient

from .conftest import API_KEY, SECRET_KEY

_TRACE_RESPONSE = {
    "isSuccess": True,
    "data": {
        "results": [
            {
                "success": True,
                "data": {
                    "trackingNumber": "1234567890",
                    "courierCode": "lotte",
                    "courierName": "롯데택배",
                    "deliveryStatus": "IN_TRANSIT",
                    "deliveryStatusText": "배송중",
                    "isDelivered": False,
                    "dateLastProgress": "2024-01-01 12:00:00",
                    "progresses": [],
                    "queriedAt": "2024-01-01T12:00:00Z",
                },
            }
        ],
        "summary": {"total": 1, "successful": 1, "failed": 0, "billable": 1},
    },
}

_COURIERS_RESPONSE = {
    "isSuccess": True,
    "data": {
        "couriers": [
            {"trackingApiCode": "lotte", "displayName": "롯데택배"},
            {"trackingApiCode": "cj", "displayName": "CJ대한통운"},
        ],
        "total": 2,
    },
}


def test_trace_success(mock_api):
    mock_api.post("/v1/tracking/trace").mock(
        return_value=httpx.Response(200, json=_TRACE_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    result = client.tracking.trace(
        items=[{"courierCode": "lotte", "trackingNumber": "1234567890"}]
    )
    assert result["summary"]["total"] == 1
    assert result["results"][0]["success"] is True
    assert result["results"][0]["data"]["deliveryStatus"] == "IN_TRANSIT"


def test_trace_multiple_items(mock_api):
    mock_api.post("/v1/tracking/trace").mock(
        return_value=httpx.Response(200, json=_TRACE_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    result = client.tracking.trace(
        items=[
            {"courierCode": "lotte", "trackingNumber": "1234567890"},
            {"courierCode": "cj", "trackingNumber": "9876543210"},
        ]
    )
    assert result["summary"]["successful"] == 1


def test_get_couriers(mock_api):
    mock_api.get("/v1/tracking/couriers").mock(
        return_value=httpx.Response(200, json=_COURIERS_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    result = client.tracking.get_couriers()
    assert result["total"] == 2
    assert result["couriers"][0]["trackingApiCode"] == "lotte"


def test_auth_error_raises(mock_api):
    mock_api.post("/v1/tracking/trace").mock(
        return_value=httpx.Response(
            401,
            json={"isSuccess": False, "errorCode": "UNAUTHORIZED", "message": "Unauthorized"},
        )
    )
    client = DeliveryAPIClient(api_key="bad", secret_key="bad")
    with pytest.raises(AuthenticationError):
        client.tracking.trace(items=[{"courierCode": "lotte", "trackingNumber": "1"}])


def test_api_error_fields(mock_api):
    mock_api.post("/v1/tracking/trace").mock(
        return_value=httpx.Response(
            429,
            json={
                "isSuccess": False,
                "errorCode": "RATE_LIMITED",
                "message": "Too many requests",
                "statusCode": 429,
            },
        )
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    with pytest.raises(ApiError) as exc_info:
        client.tracking.trace(items=[{"courierCode": "lotte", "trackingNumber": "1"}])
    err = exc_info.value
    assert err.code == "RATE_LIMITED"
    assert err.status == 429


def test_authorization_header_sent(mock_api):
    route = mock_api.post("/v1/tracking/trace").mock(
        return_value=httpx.Response(200, json=_TRACE_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    client.tracking.trace(items=[{"courierCode": "lotte", "trackingNumber": "1"}])
    assert route.called
    auth = route.calls[0].request.headers["authorization"]
    assert auth == f"Bearer {API_KEY}:{SECRET_KEY}"
