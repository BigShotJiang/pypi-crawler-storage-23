import httpx
import pytest
import respx

from deliveryapi import AsyncDeliveryAPIClient

from .conftest import API_KEY, BASE_URL, SECRET_KEY

_TRACE_RESPONSE = {
    "isSuccess": True,
    "data": {
        "results": [
            {
                "success": True,
                "data": {
                    "trackingNumber": "1234567890",
                    "courierCode": "lotte",
                    "courierName": "롯데택배",
                    "deliveryStatus": "DELIVERED",
                    "deliveryStatusText": "배송완료",
                    "isDelivered": True,
                    "dateLastProgress": "2024-01-02 15:30:00",
                    "progresses": [],
                    "queriedAt": "2024-01-02T15:30:00Z",
                },
            }
        ],
        "summary": {"total": 1, "successful": 1, "failed": 0, "billable": 1},
    },
}

_COURIERS_RESPONSE = {
    "isSuccess": True,
    "data": {
        "couriers": [{"trackingApiCode": "lotte", "displayName": "롯데택배"}],
        "total": 1,
    },
}


@pytest.mark.asyncio
async def test_async_trace():
    with respx.mock(base_url=BASE_URL, assert_all_called=False) as mock:
        mock.post("/v1/tracking/trace").mock(
            return_value=httpx.Response(200, json=_TRACE_RESPONSE)
        )
        async with AsyncDeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY) as client:
            result = await client.tracking.trace(
                items=[{"courierCode": "lotte", "trackingNumber": "1234567890"}]
            )
    assert result["results"][0]["data"]["isDelivered"] is True


@pytest.mark.asyncio
async def test_async_get_couriers():
    with respx.mock(base_url=BASE_URL, assert_all_called=False) as mock:
        mock.get("/v1/tracking/couriers").mock(
            return_value=httpx.Response(200, json=_COURIERS_RESPONSE)
        )
        async with AsyncDeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY) as client:
            result = await client.tracking.get_couriers()
    assert len(result["couriers"]) == 1
    assert result["couriers"][0]["trackingApiCode"] == "lotte"
