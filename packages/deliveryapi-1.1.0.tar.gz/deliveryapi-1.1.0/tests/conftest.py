import pytest
import respx

BASE_URL = "https://api.deliveryapi.co.kr"
API_KEY = "pk_test"
SECRET_KEY = "sk_test"


@pytest.fixture
def mock_api():
    """Mock all HTTP calls to the DeliveryAPI base URL."""
    with respx.mock(base_url=BASE_URL, assert_all_called=False) as transport:
        yield transport
