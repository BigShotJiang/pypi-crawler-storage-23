import httpx

from deliveryapi import DeliveryAPIClient

from .conftest import API_KEY, SECRET_KEY

_COURIERS_RESPONSE = {
    "isSuccess": True,
    "data": {
        "couriers": [
            {"trackingApiCode": "lotte", "displayName": "롯데택배"},
            {"trackingApiCode": "cj", "displayName": "CJ대한통운"},
        ],
        "total": 2,
    },
}


def test_get_couriers(mock_api):
    mock_api.get("/v1/tracking/couriers").mock(
        return_value=httpx.Response(200, json=_COURIERS_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    result = client.tracking.get_couriers()
    assert result["total"] == 2
    assert result["couriers"][0]["trackingApiCode"] == "lotte"
    assert result["couriers"][1]["displayName"] == "CJ대한통운"
