import httpx

from deliveryapi import DeliveryAPIClient

from .conftest import API_KEY, SECRET_KEY

_REGISTER_RESPONSE = {
    "isSuccess": True,
    "data": {
        "requestId": "req_test_123",
        "itemCount": 1,
        "recurring": True,
    },
}

_LIST_SUBSCRIPTIONS_RESPONSE = {
    "isSuccess": True,
    "data": {
        "subscriptions": [
            {
                "requestId": "req_test_123",
                "endpointId": "ep_test_123",
                "recurring": True,
                "isActive": True,
                "itemCount": 1,
                "summary": {"total": 1, "delivered": 0, "active": 1, "failed": 0},
                "dateCreated": "2024-01-01T00:00:00Z",
            }
        ],
        "total": 1,
    },
}

_GET_SUBSCRIPTION_RESPONSE = {
    "isSuccess": True,
    "data": {
        "requestId": "req_test_123",
        "recurring": True,
        "isActive": True,
        "itemCount": 1,
        "summary": {"total": 1, "delivered": 0, "active": 1, "failed": 0},
        "items": [
            {
                "courierCode": "lotte",
                "trackingNumber": "1234567890",
                "currentStatus": "IN_TRANSIT",
                "hasChanged": False,
                "isDelivered": False,
            }
        ],
        "dateCreated": "2024-01-01T00:00:00Z",
        "dateModified": "2024-01-01T00:00:00Z",
    },
}

_BATCH_RESULTS_RESPONSE = {
    "isSuccess": True,
    "data": {
        "results": [
            {
                "courierCode": "lotte",
                "trackingNumber": "1234567890",
                "requestId": "req_test_123",
                "currentStatus": "IN_TRANSIT",
                "isDelivered": False,
            }
        ],
        "total": 1,
    },
}


def test_register_subscription(mock_api):
    mock_api.post("/v1/webhooks/register").mock(
        return_value=httpx.Response(200, json=_REGISTER_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    result = client.webhooks.subscriptions.register(
        items=[{"courierCode": "lotte", "trackingNumber": "1234567890"}],
        recurring=True,
        endpoint_id="ep_test_123",
    )
    assert result["requestId"] == "req_test_123"
    assert result["recurring"] is True


def test_list_subscriptions(mock_api):
    mock_api.get("/v1/webhooks/subscriptions").mock(
        return_value=httpx.Response(200, json=_LIST_SUBSCRIPTIONS_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    result = client.webhooks.subscriptions.list()
    assert result["total"] == 1
    assert result["subscriptions"][0]["requestId"] == "req_test_123"


def test_get_subscription(mock_api):
    mock_api.get("/v1/webhooks/subscriptions/req_test_123").mock(
        return_value=httpx.Response(200, json=_GET_SUBSCRIPTION_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    result = client.webhooks.subscriptions.get("req_test_123")
    assert result["requestId"] == "req_test_123"
    assert result["items"][0]["currentStatus"] == "IN_TRANSIT"


def test_cancel_subscription(mock_api):
    mock_api.delete("/v1/webhooks/subscriptions/req_test_123").mock(
        return_value=httpx.Response(200, json={"isSuccess": True, "data": None})
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    # Should not raise
    client.webhooks.subscriptions.cancel("req_test_123")


def test_batch_results(mock_api):
    mock_api.post("/v1/webhooks/results").mock(
        return_value=httpx.Response(200, json=_BATCH_RESULTS_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    result = client.webhooks.subscriptions.batch_results(
        items=[{"courierCode": "lotte", "trackingNumber": "1234567890"}]
    )
    assert result["total"] == 1
    assert result["results"][0]["currentStatus"] == "IN_TRANSIT"
