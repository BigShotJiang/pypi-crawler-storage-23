import httpx
import pytest

from deliveryapi import DeliveryAPIClient, NotFoundError

from .conftest import API_KEY, SECRET_KEY

_CREATE_ENDPOINT_RESPONSE = {
    "isSuccess": True,
    "data": {
        "endpointId": "ep_test_123",
        "url": "https://example.com/webhook",
        "name": "Test endpoint",
        "webhookSecret": "whsec_testsecret",
        "dateCreated": "2024-01-01T00:00:00Z",
    },
}

_LIST_ENDPOINTS_RESPONSE = {
    "isSuccess": True,
    "data": {
        "endpoints": [
            {
                "endpointId": "ep_test_123",
                "url": "https://example.com/webhook",
                "name": "Test endpoint",
                "status": "active",
                "consecutiveFailures": 0,
                "dateCreated": "2024-01-01T00:00:00Z",
                "dateModified": "2024-01-01T00:00:00Z",
            }
        ],
        "total": 1,
    },
}

_ROTATE_SECRET_RESPONSE = {
    "isSuccess": True,
    "data": {
        "endpointId": "ep_test_123",
        "webhookSecret": "whsec_newsecret",
        "dateRotated": "2024-01-02T00:00:00Z",
    },
}


def test_create_endpoint(mock_api):
    mock_api.post("/v1/webhooks/endpoints").mock(
        return_value=httpx.Response(200, json=_CREATE_ENDPOINT_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    result = client.webhooks.endpoints.create(
        url="https://example.com/webhook",
        name="Test endpoint",
    )
    assert result["endpointId"] == "ep_test_123"
    assert result["webhookSecret"] == "whsec_testsecret"


def test_list_endpoints(mock_api):
    mock_api.get("/v1/webhooks/endpoints").mock(
        return_value=httpx.Response(200, json=_LIST_ENDPOINTS_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    result = client.webhooks.endpoints.list()
    assert result["total"] == 1
    assert result["endpoints"][0]["endpointId"] == "ep_test_123"


def test_update_endpoint(mock_api):
    mock_api.put("/v1/webhooks/endpoints/ep_test_123").mock(
        return_value=httpx.Response(200, json={"isSuccess": True, "data": None})
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    # Should not raise
    client.webhooks.endpoints.update("ep_test_123", name="Updated name")


def test_delete_endpoint(mock_api):
    mock_api.delete("/v1/webhooks/endpoints/ep_test_123").mock(
        return_value=httpx.Response(200, json={"isSuccess": True, "data": None})
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    # Should not raise
    client.webhooks.endpoints.delete("ep_test_123")


def test_rotate_secret(mock_api):
    mock_api.post("/v1/webhooks/endpoints/ep_test_123/rotate").mock(
        return_value=httpx.Response(200, json=_ROTATE_SECRET_RESPONSE)
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    result = client.webhooks.endpoints.rotate_secret("ep_test_123")
    assert result["webhookSecret"] == "whsec_newsecret"


def test_endpoint_not_found_raises(mock_api):
    mock_api.delete("/v1/webhooks/endpoints/ep_missing").mock(
        return_value=httpx.Response(
            404,
            json={
                "isSuccess": False,
                "errorCode": "NOT_FOUND",
                "message": "Endpoint not found",
            },
        )
    )
    client = DeliveryAPIClient(api_key=API_KEY, secret_key=SECRET_KEY)
    with pytest.raises(NotFoundError):
        client.webhooks.endpoints.delete("ep_missing")
