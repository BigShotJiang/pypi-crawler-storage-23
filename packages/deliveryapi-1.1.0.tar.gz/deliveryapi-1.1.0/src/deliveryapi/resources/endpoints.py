from __future__ import annotations

from typing import Any

from ._base import AsyncAPIResource, SyncAPIResource


class EndpointsResource(SyncAPIResource):
    """Webhook endpoint management.

    An endpoint is a URL that receives webhook events when delivery status
    changes.
    """

    def create(self, url: str, name: str, *, webhook_secret: str | None = None) -> Any:
        """Register a new webhook endpoint.

        The server sends a test POST request to the URL during registration
        to verify it is reachable. The ``webhookSecret`` in the response is
        **only available here** — store it securely. Use ``rotate_secret()``
        to generate a new one if lost.

        Args:
            url: Webhook receiver URL (must start with ``https://``).
            name: Display name for the endpoint.
            webhook_secret: Custom signing secret (optional, min 5 chars).
                If omitted the server generates one automatically.

        Returns:
            Dict with ``endpointId``, ``url``, ``name``, ``webhookSecret``,
            and ``dateCreated``.

        Raises:
            ApiError: ``WEBHOOK_ENDPOINT_LIMIT`` — max endpoints reached.
            ApiError: ``WEBHOOK_ENDPOINT_UNREACHABLE`` — URL verification failed.

        Example::

            endpoint = client.webhooks.endpoints.create(
                url="https://my.server/webhook",
                name="Production",
            )
            # Store endpoint["webhookSecret"] securely — not retrievable again!
            print(endpoint["endpointId"])
        """
        body: dict[str, Any] = {"url": url, "name": name}
        if webhook_secret is not None:
            body["webhookSecret"] = webhook_secret
        return self._http.post("/v1/webhooks/endpoints", json=body)

    def list(self) -> Any:
        """List all registered webhook endpoints.

        Example::

            result = client.webhooks.endpoints.list()
            for ep in result["endpoints"]:
                print(ep["endpointId"], ep["status"])
        """
        return self._http.get("/v1/webhooks/endpoints")

    def update(self, endpoint_id: str, *, name: str) -> None:
        """Update the endpoint name.

        URL cannot be changed. Delete and re-create if the URL needs to change.

        Args:
            endpoint_id: Endpoint ID (``ep_...``).
            name: New display name.

        Raises:
            ApiError: ``NOT_FOUND`` — endpoint does not exist.

        Example::

            client.webhooks.endpoints.update("ep_xxxx", name="Staging")
        """
        self._http.put(f"/v1/webhooks/endpoints/{endpoint_id}", json={"name": name})

    def delete(self, endpoint_id: str) -> None:
        """Delete a webhook endpoint.

        All subscriptions connected to this endpoint are also deleted (cascade).

        Args:
            endpoint_id: Endpoint ID (``ep_...``).

        Raises:
            ApiError: ``NOT_FOUND`` — endpoint does not exist.

        Example::

            client.webhooks.endpoints.delete("ep_xxxx")
        """
        self._http.delete(f"/v1/webhooks/endpoints/{endpoint_id}")

    def rotate_secret(self, endpoint_id: str, *, webhook_secret: str | None = None) -> Any:
        """Rotate (re-generate) the webhook signing secret.

        The old secret is immediately invalidated.
        The new secret is **only available in this response** — store it securely.

        Args:
            endpoint_id: Endpoint ID (``ep_...``).
            webhook_secret: Custom new secret (optional). If omitted the server
                generates one automatically.

        Returns:
            Dict with ``endpointId``, ``webhookSecret``, and ``dateRotated``.

        Raises:
            ApiError: ``NOT_FOUND`` — endpoint does not exist.

        Example::

            result = client.webhooks.endpoints.rotate_secret("ep_xxxx")
            # Store result["webhookSecret"] securely!
        """
        body: dict[str, Any] = {}
        if webhook_secret is not None:
            body["webhookSecret"] = webhook_secret
        return self._http.post(f"/v1/webhooks/endpoints/{endpoint_id}/rotate", json=body)


class AsyncEndpointsResource(AsyncAPIResource):
    """Webhook endpoint management (async)."""

    async def create(self, url: str, name: str, *, webhook_secret: str | None = None) -> Any:
        """Register a new webhook endpoint (async)."""
        body: dict[str, Any] = {"url": url, "name": name}
        if webhook_secret is not None:
            body["webhookSecret"] = webhook_secret
        return await self._http.post("/v1/webhooks/endpoints", json=body)

    async def list(self) -> Any:
        """List all registered webhook endpoints (async)."""
        return await self._http.get("/v1/webhooks/endpoints")

    async def update(self, endpoint_id: str, *, name: str) -> None:
        """Update the endpoint name (async)."""
        await self._http.put(f"/v1/webhooks/endpoints/{endpoint_id}", json={"name": name})

    async def delete(self, endpoint_id: str) -> None:
        """Delete a webhook endpoint (async)."""
        await self._http.delete(f"/v1/webhooks/endpoints/{endpoint_id}")

    async def rotate_secret(self, endpoint_id: str, *, webhook_secret: str | None = None) -> Any:
        """Rotate the webhook signing secret (async)."""
        body: dict[str, Any] = {}
        if webhook_secret is not None:
            body["webhookSecret"] = webhook_secret
        return await self._http.post(f"/v1/webhooks/endpoints/{endpoint_id}/rotate", json=body)
