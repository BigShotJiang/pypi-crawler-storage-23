from __future__ import annotations

from typing import Any

from ._base import AsyncAPIResource, SyncAPIResource


class TrackingResource(SyncAPIResource):
    """Courier tracking."""

    def get_couriers(self) -> Any:
        """List all supported couriers.

        Returns a list of couriers with their ``trackingApiCode`` (used in
        ``trace()``) and ``displayName``.

        Example::

            result = client.tracking.get_couriers()
            for c in result["couriers"]:
                print(c["trackingApiCode"], c["displayName"])
        """
        return self._http.get("/v1/tracking/couriers")

    def trace(
        self,
        items: list[dict[str, Any]],
        *,
        include_progresses: bool = True,
    ) -> Any:
        """Query shipping status for one or more tracking numbers.

        Args:
            items: List of tracking items. Each item must have ``courierCode``
                and ``trackingNumber``. Optional ``clientId`` is returned as-is.
            include_progresses: Include delivery progress history (default: True).
                Set to ``False`` to reduce response size when only the status is needed.

        Returns:
            Dict with ``results`` (per-item) and ``summary`` (aggregate counts).
            Individual items may fail without failing the whole request —
            check ``results[i]["success"]`` for each item.

        Raises:
            ApiError: Authentication failure, rate limit exceeded, etc.

        Example::

            result = client.tracking.trace(
                items=[
                    {"courierCode": "cj",    "trackingNumber": "1234567890", "clientId": "order_001"},
                    {"courierCode": "lotte", "trackingNumber": "9876543210"},
                ],
            )
            for r in result["results"]:
                if r["success"]:
                    print(r["data"]["deliveryStatus"])
                else:
                    print(r["error"]["code"])
        """
        return self._http.post("/v1/tracking/trace", json={
            "items": items,
            "includeProgresses": include_progresses,
        })


class AsyncTrackingResource(AsyncAPIResource):
    """Courier tracking (async)."""

    async def get_couriers(self) -> Any:
        """List all supported couriers (async)."""
        return await self._http.get("/v1/tracking/couriers")

    async def trace(
        self,
        items: list[dict[str, Any]],
        *,
        include_progresses: bool = True,
    ) -> Any:
        """Query shipping status for one or more tracking numbers (async)."""
        return await self._http.post("/v1/tracking/trace", json={
            "items": items,
            "includeProgresses": include_progresses,
        })
