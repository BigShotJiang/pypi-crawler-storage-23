from __future__ import annotations

from .._http import AsyncHttpClient, HttpClient


class SyncAPIResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http


class AsyncAPIResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http
