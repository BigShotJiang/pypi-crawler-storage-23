from __future__ import annotations

from .._http import AsyncHttpClient, HttpClient
from .endpoints import AsyncEndpointsResource, EndpointsResource
from .subscriptions import AsyncSubscriptionsResource, SubscriptionsResource


class WebhooksResource:
    """Webhook management.

    - ``endpoints`` — Register and manage webhook receiver URLs
    - ``subscriptions`` — Register and manage courier tracking subscriptions

    Example::

        # 1. Register an endpoint
        endpoint = client.webhooks.endpoints.create(
            url="https://my.server/webhook",
            name="Production",
        )
        # Store endpoint["webhookSecret"] — only available here!

        # 2. Subscribe to courier tracking
        sub = client.webhooks.subscriptions.register(
            items=[{"courierCode": "cj", "trackingNumber": "1234567890", "clientId": "order_001"}],
            recurring=True,
            endpoint_id=endpoint["endpointId"],
        )

        # 3. Check subscription status
        detail = client.webhooks.subscriptions.get(sub["requestId"])
        for item in detail["items"]:
            print(item["currentStatus"])
    """

    def __init__(self, http: HttpClient) -> None:
        self.endpoints = EndpointsResource(http)
        self.subscriptions = SubscriptionsResource(http)


class AsyncWebhooksResource:
    """Webhook management (async).

    Same interface as ``WebhooksResource`` but all methods are coroutines.
    """

    def __init__(self, http: AsyncHttpClient) -> None:
        self.endpoints = AsyncEndpointsResource(http)
        self.subscriptions = AsyncSubscriptionsResource(http)
