from __future__ import annotations

from typing import Any

from ._base import AsyncAPIResource, SyncAPIResource


class SubscriptionsResource(SyncAPIResource):
    """Tracking webhook subscriptions.

    A subscription watches one or more shipments and fires webhook events when
    delivery status changes.
    """

    def register(
        self,
        items: list[dict[str, Any]],
        *,
        recurring: bool,
        endpoint_id: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> Any:
        """Register a courier tracking subscription.

        Args:
            items: List of items to track. Each item requires ``courierCode``
                and ``trackingNumber``. Optional ``clientId`` is returned as-is
                in webhook payloads.
            recurring: If ``True``, polls until delivery or 14 days (recurring
                subscription). If ``False``, crawls once and stops.
            endpoint_id: Webhook endpoint ID. If provided, webhook events are
                sent on status change. If omitted, use ``get()`` to poll results.
            metadata: Arbitrary key-value pairs included in webhook payloads.

        Returns:
            Dict with ``requestId``, ``itemCount``, and ``recurring``.

        Example::

            # Recurring subscription with webhook
            sub = client.webhooks.subscriptions.register(
                items=[{"courierCode": "cj", "trackingNumber": "1234567890", "clientId": "order_001"}],
                recurring=True,
                endpoint_id="ep_xxxx",
                metadata={"orderId": "ORD-001"},
            )
            print(sub["requestId"])  # 'req_xxxx'
        """
        body: dict[str, Any] = {"items": items, "recurring": recurring}
        if endpoint_id is not None:
            body["endpointId"] = endpoint_id
        if metadata is not None:
            body["metadata"] = metadata
        return self._http.post("/v1/webhooks/register", json=body)

    def list(self, *, cursor: str | None = None, limit: int | None = None) -> Any:
        """List subscriptions (cursor-based pagination).

        Args:
            cursor: Pagination cursor from the previous response's ``nextCursor``.
            limit: Page size.

        Returns:
            Dict with ``subscriptions``, ``total``, and optional ``nextCursor``.

        Example::

            cursor = None
            while True:
                page = client.webhooks.subscriptions.list(cursor=cursor, limit=50)
                for sub in page["subscriptions"]:
                    print(sub["requestId"], sub["isActive"])
                cursor = page.get("nextCursor")
                if not cursor:
                    break
        """
        params: dict[str, str] = {}
        if cursor is not None:
            params["cursor"] = cursor
        if limit is not None:
            params["limit"] = str(limit)
        return self._http.get("/v1/webhooks/subscriptions", params=params or None)

    def get(self, request_id: str) -> Any:
        """Get detailed subscription information.

        Args:
            request_id: Subscription ID (``req_...``).

        Returns:
            Dict with ``requestId``, ``items`` (per-courier status), ``summary``,
            and polling schedule fields.

        Raises:
            ApiError: ``NOT_FOUND`` — subscription does not exist.

        Example::

            detail = client.webhooks.subscriptions.get("req_xxxx")
            for item in detail["items"]:
                print(item["trackingNumber"], item["currentStatus"])
        """
        return self._http.get(f"/v1/webhooks/subscriptions/{request_id}")

    def cancel(self, request_id: str) -> None:
        """Cancel an active subscription.

        Args:
            request_id: Subscription ID (``req_...``).

        Raises:
            ApiError: ``NOT_FOUND`` — subscription does not exist.

        Example::

            client.webhooks.subscriptions.cancel("req_xxxx")
        """
        self._http.delete(f"/v1/webhooks/subscriptions/{request_id}")

    def batch_results(self, items: list[dict[str, Any]]) -> Any:
        """Fetch the latest delivery status for multiple tracking numbers at once.

        Searches subscriptions registered under this account by
        (courierCode + trackingNumber).

        Args:
            items: List of dicts with ``courierCode`` and ``trackingNumber``.

        Returns:
            Dict with ``results`` and ``total``.

        Example::

            result = client.webhooks.subscriptions.batch_results(
                items=[
                    {"courierCode": "cj",    "trackingNumber": "1111111111"},
                    {"courierCode": "lotte", "trackingNumber": "2222222222"},
                ],
            )
            for r in result["results"]:
                print(r["currentStatus"], r["isDelivered"])
        """
        return self._http.post("/v1/webhooks/results", json={"items": items})


class AsyncSubscriptionsResource(AsyncAPIResource):
    """Tracking webhook subscriptions (async)."""

    async def register(
        self,
        items: list[dict[str, Any]],
        *,
        recurring: bool,
        endpoint_id: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> Any:
        """Register a courier tracking subscription (async)."""
        body: dict[str, Any] = {"items": items, "recurring": recurring}
        if endpoint_id is not None:
            body["endpointId"] = endpoint_id
        if metadata is not None:
            body["metadata"] = metadata
        return await self._http.post("/v1/webhooks/register", json=body)

    async def list(self, *, cursor: str | None = None, limit: int | None = None) -> Any:
        """List subscriptions (async)."""
        params: dict[str, str] = {}
        if cursor is not None:
            params["cursor"] = cursor
        if limit is not None:
            params["limit"] = str(limit)
        return await self._http.get("/v1/webhooks/subscriptions", params=params or None)

    async def get(self, request_id: str) -> Any:
        """Get detailed subscription information (async)."""
        return await self._http.get(f"/v1/webhooks/subscriptions/{request_id}")

    async def cancel(self, request_id: str) -> None:
        """Cancel an active subscription (async)."""
        await self._http.delete(f"/v1/webhooks/subscriptions/{request_id}")

    async def batch_results(self, items: list[dict[str, Any]]) -> Any:
        """Fetch latest delivery status for multiple tracking numbers (async)."""
        return await self._http.post("/v1/webhooks/results", json={"items": items})
