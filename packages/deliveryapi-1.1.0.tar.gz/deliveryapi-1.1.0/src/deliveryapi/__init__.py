"""DeliveryAPI Python SDK.

Quick start::

    from deliveryapi import DeliveryAPIClient

    client = DeliveryAPIClient(api_key="pk_...", secret_key="sk_...")

    # List couriers
    couriers = client.tracking.get_couriers()

    # Query tracking status
    result = client.tracking.trace(
        items=[{"courierCode": "cj", "trackingNumber": "1234567890"}]
    )
    print(result["results"][0]["data"]["deliveryStatus"])

    # Webhook management
    endpoint = client.webhooks.endpoints.create(
        url="https://my.server/webhook",
        name="Production",
    )
    sub = client.webhooks.subscriptions.register(
        items=[{"courierCode": "cj", "trackingNumber": "1234567890"}],
        recurring=True,
        endpoint_id=endpoint["endpointId"],
    )
"""
from __future__ import annotations

from ._client import AsyncDeliveryAPIClient, DeliveryAPIClient
from ._exceptions import ApiError, AuthenticationError, NotFoundError, RateLimitError
from ._webhook import WebhookSignatureError, verify_webhook_signature

__version__ = "1.1.0"

__all__ = [
    # Clients
    "DeliveryAPIClient",
    "AsyncDeliveryAPIClient",
    # Exceptions
    "ApiError",
    "AuthenticationError",
    "RateLimitError",
    "NotFoundError",
    # Webhook utils
    "verify_webhook_signature",
    "WebhookSignatureError",
]
