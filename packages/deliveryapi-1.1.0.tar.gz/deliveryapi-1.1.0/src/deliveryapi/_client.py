"""Main client classes for the DeliveryAPI."""
from __future__ import annotations

from ._http import DEFAULT_TIMEOUT, AsyncHttpClient, HttpClient
from .resources.tracking import AsyncTrackingResource, TrackingResource
from .resources.webhooks import AsyncWebhooksResource, WebhooksResource


class DeliveryAPIClient:
    """Synchronous DeliveryAPI client.

    Args:
        api_key: Your API key (``pk_live_...`` or ``pk_test_...``).
        secret_key: Your secret key (``sk_live_...`` or ``sk_test_...``).
        timeout: HTTP request timeout in seconds (default: 30).

    Example::

        from deliveryapi import DeliveryAPIClient

        client = DeliveryAPIClient(
            api_key="pk_live_...",
            secret_key="sk_live_...",
        )

        # List supported couriers
        couriers = client.tracking.get_couriers()

        # Query tracking status
        result = client.tracking.trace(
            items=[{"courierCode": "cj", "trackingNumber": "1234567890"}],
        )

        # Manage webhook endpoints
        endpoint = client.webhooks.endpoints.create(
            url="https://my.server/webhook",
            name="Production",
        )

        # Subscribe to courier tracking
        sub = client.webhooks.subscriptions.register(
            items=[{"courierCode": "cj", "trackingNumber": "1234567890"}],
            recurring=True,
            endpoint_id=endpoint["endpointId"],
        )

    Context manager::

        with DeliveryAPIClient(api_key="...", secret_key="...") as client:
            result = client.tracking.trace(items=[...])
    """

    def __init__(
        self,
        *,
        api_key: str,
        secret_key: str,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        http = HttpClient(api_key, secret_key, timeout)
        self.tracking = TrackingResource(http)
        self.webhooks = WebhooksResource(http)
        self._http = http

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._http.close()

    def __enter__(self) -> DeliveryAPIClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncDeliveryAPIClient:
    """Async DeliveryAPI client (requires asyncio).

    Args:
        api_key: Your API key (``pk_live_...`` or ``pk_test_...``).
        secret_key: Your secret key (``sk_live_...`` or ``sk_test_...``).
        timeout: HTTP request timeout in seconds (default: 30).

    Example::

        import asyncio
        from deliveryapi import AsyncDeliveryAPIClient

        async def main():
            async with AsyncDeliveryAPIClient(
                api_key="pk_live_...",
                secret_key="sk_live_...",
            ) as client:
                couriers = await client.tracking.get_couriers()
                result = await client.tracking.trace(
                    items=[{"courierCode": "cj", "trackingNumber": "1234567890"}],
                )

        asyncio.run(main())
    """

    def __init__(
        self,
        *,
        api_key: str,
        secret_key: str,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        http = AsyncHttpClient(api_key, secret_key, timeout)
        self.tracking = AsyncTrackingResource(http)
        self.webhooks = AsyncWebhooksResource(http)
        self._http = http

    async def aclose(self) -> None:
        """Close the underlying async HTTP connection pool."""
        await self._http.aclose()

    async def __aenter__(self) -> AsyncDeliveryAPIClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()
