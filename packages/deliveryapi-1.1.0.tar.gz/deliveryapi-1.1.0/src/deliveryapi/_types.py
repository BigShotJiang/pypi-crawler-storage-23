"""TypedDict definitions mirroring shared-types TypeScript interfaces."""
from __future__ import annotations

from typing import Literal, Optional
from typing_extensions import TypedDict, NotRequired

# ---------------------------------------------------------------------------
# Courier Delivery Status
# ---------------------------------------------------------------------------

CourierDeliveryStatus = Literal[
    "PENDING",
    "REGISTERED",
    "PICKUP_READY",
    "PICKED_UP",
    "IN_TRANSIT",
    "OUT_FOR_DELIVERY",
    "DELIVERED",
    "FAILED",
    "RETURNED",
    "CANCELLED",
    "HOLD",
    "UNKNOWN",
]

# ---------------------------------------------------------------------------
# Tracking
# ---------------------------------------------------------------------------


class TrackingItem(TypedDict):
    courierCode: str
    trackingNumber: str
    clientId: NotRequired[str]
    id: NotRequired[str]  # deprecated, use clientId


class TrackingProgress(TypedDict):
    dateTime: str
    location: str
    status: str
    statusCode: NotRequired[CourierDeliveryStatus]
    description: NotRequired[str]
    telno: NotRequired[str]
    telno2: NotRequired[str]


class UnifiedTrackingResponse(TypedDict):
    trackingNumber: str
    courierCode: str
    courierName: str
    deliveryStatus: CourierDeliveryStatus
    deliveryStatusText: str
    isDelivered: bool
    senderName: NotRequired[str]
    receiverName: NotRequired[str]
    receiverAddress: NotRequired[str]
    productName: NotRequired[str]
    productQuantity: NotRequired[int]
    dateDelivered: NotRequired[str]
    dateEstimated: NotRequired[str]
    dateLastProgress: str
    progresses: list[TrackingProgress]
    queriedAt: str


TrackingErrorCode = Literal[
    "MISSING_PARAMS",
    "INVALID_TRACKING_NUMBER",
    "UNSUPPORTED_COURIER",
    "NOT_FOUND",
    "TRACKING_FAILED",
]


class TrackingError(TypedDict):
    code: TrackingErrorCode
    message: str
    billable: bool
    courierCode: NotRequired[str]
    trackingNumber: NotRequired[str]


class TrackingCacheInfo(TypedDict):
    fromCache: bool
    cachedAt: NotRequired[str]


class TrackingResult(TypedDict):
    success: bool
    clientId: NotRequired[str]
    id: NotRequired[str]  # deprecated
    data: NotRequired[UnifiedTrackingResponse]
    error: NotRequired[TrackingError]
    cache: NotRequired[TrackingCacheInfo]


class TrackingSummary(TypedDict):
    total: int
    successful: int
    failed: int
    billable: int


class TrackingResponse(TypedDict):
    results: list[TrackingResult]
    summary: TrackingSummary


# ---------------------------------------------------------------------------
# Couriers
# ---------------------------------------------------------------------------


class CourierInfo(TypedDict):
    id: str
    displayName: str
    supportsTracking: bool
    supportsAccount: bool
    trackingUrl: NotRequired[str]
    customerServicePhone: NotRequired[str]


class CourierListResult(TypedDict):
    couriers: list[CourierInfo]


# ---------------------------------------------------------------------------
# Webhook Endpoints
# ---------------------------------------------------------------------------


class WebhookCreateInput(TypedDict):
    url: str
    name: NotRequired[str]


class WebhookEndpoint(TypedDict):
    id: str
    url: str
    name: NotRequired[str]
    status: Literal["active", "inactive"]
    dateCreated: str
    dateModified: str


class WebhookListResult(TypedDict):
    endpoints: list[WebhookEndpoint]
    total: int


class WebhookTestResult(TypedDict):
    success: bool
    statusCode: NotRequired[int]
    message: NotRequired[str]


# ---------------------------------------------------------------------------
# Subscriptions
# ---------------------------------------------------------------------------

SubscriptionStatus = Literal["active", "completed", "cancelled", "failed"]


class SubscriptionCreateInput(TypedDict):
    courierCode: str
    trackingNumber: str
    endpointId: str
    subscribedStatuses: NotRequired[list[CourierDeliveryStatus]]
    clientId: NotRequired[str]
    metadata: NotRequired[dict[str, str]]


class TrackingSubscription(TypedDict):
    id: str
    clientId: NotRequired[str]
    courierCode: str
    trackingNumber: str
    endpointId: str
    subscribedStatuses: list[CourierDeliveryStatus]
    currentStatus: CourierDeliveryStatus
    status: SubscriptionStatus
    failureCount: int
    metadata: NotRequired[dict[str, str]]
    dateCreated: str
    dateModified: str


class SubscriptionListResult(TypedDict):
    subscriptions: list[TrackingSubscription]
    total: int


# ---------------------------------------------------------------------------
# Webhook Payload (received by the user's endpoint)
# ---------------------------------------------------------------------------


class WebhookPayloadData(TypedDict):
    courierCode: str
    trackingNumber: str
    previousStatus: NotRequired[CourierDeliveryStatus]
    currentStatus: CourierDeliveryStatus
    tracking: UnifiedTrackingResponse


class WebhookPayload(TypedDict):
    event: Literal["tracking.status_changed"]
    subscriptionId: str
    timestamp: str  # ISO 8601
    data: WebhookPayloadData
    metadata: NotRequired[dict[str, str]]
