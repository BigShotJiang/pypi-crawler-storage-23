import asyncio
import importlib
from typing import Any, Dict, List

from agentic_builder.settings import MCPServerSettings
from langchain.tools import BaseTool
from langchain_core.messages import HumanMessage, ToolMessage
from langchain_core.messages.utils import AnyMessage
from langchain_mcp_adapters.client import MultiServerMCPClient

_mcp_tools_cache: Dict[str, List[BaseTool]] = {}
_mcp_tools_lock = asyncio.Lock()


def load_class(path: str) -> Any:
    module_path, class_name = path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def get_latest_human_question(messages: List[AnyMessage]) -> Any:
    for msg in reversed(messages):
        if isinstance(msg, HumanMessage):
            return msg.content
    raise ValueError("No HumanMessage found in messages")


def message_content_to_str(content: str | List[str | Dict[str, Any]]) -> str:
    """
    Normalize LangChain message content to a string.
    """
    if isinstance(content, str):
        return content

    parts: list[str] = []
    for item in content:
        if isinstance(item, str):
            parts.append(item)
        elif isinstance(item, dict):
            # Common LC formats: {"text": "..."} or tool payloads
            if "text" in item and isinstance(item["text"], str):
                parts.append(item["text"])
            else:
                parts.append(str(item))
    return "\n".join(parts)


def extract_retrieved_context(messages: List[AnyMessage]) -> str:
    """
    Collect ALL retrieved document contents from the conversation history.
    """
    contexts = []
    for msg in messages:
        # Tool-based retriever output
        if isinstance(msg, ToolMessage):
            contexts.append(message_content_to_str(msg.content))
    return "\n\n".join(c for c in contexts if c.strip())


async def _cached_mcp_tools(
    mcps_fingerprint: str,
    mcps_config: List[MCPServerSettings],
) -> List[BaseTool]:
    # Fast path (already cached)
    if mcps_fingerprint in _mcp_tools_cache:
        return _mcp_tools_cache[mcps_fingerprint]

    async with _mcp_tools_lock:
        # Double-check inside lock
        if mcps_fingerprint in _mcp_tools_cache:
            return _mcp_tools_cache[mcps_fingerprint]

        client = MultiServerMCPClient(
            {
                mcp.name: {  # type: ignore[misc]
                    "transport": "http",
                    "url": mcp.url,
                }
                for mcp in mcps_config
            }
        )

        tools = await client.get_tools()
        _mcp_tools_cache[mcps_fingerprint] = tools
        return tools


def get_context(documents: List[str]) -> str:
    return "\n\n".join(documents)
