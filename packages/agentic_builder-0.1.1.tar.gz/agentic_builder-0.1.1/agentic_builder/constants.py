from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Dict, Optional, Type, TypeVar, Union

from langchain_core.tools.base import BaseTool

if TYPE_CHECKING:

    from agentic_builder.settings import (
        AgentSettings,
        APIRunnerSettings,
        DeletionStrategySettings,
        FromConfigMixinSettings,
        LLMSettings,
    )

CONFIG_PATH = "/config/config.yaml"
# CONFIG_PATH = "/home/jalal/projects/arxiv-agent/configs/config_agentic_builder.yaml"

agentic_builder_ROOT = Path(__file__).resolve().parent
GRAPHS_DIR = agentic_builder_ROOT.parent.parent / "graphs"
GRAPHS_DIR.mkdir(parents=True, exist_ok=True)


TCAgentSettings = TypeVar("TCAgentSettings", bound="AgentSettings")
TCFromConfigMixin = TypeVar("TCFromConfigMixin", bound="FromConfigMixinSettings")
TCLLM = TypeVar("TCLLM", bound="LLMSettings")
TCAgent = TypeVar("TCAgent", bound="AgentSettings")
TCAPIRunner = TypeVar("TCAPIRunner", bound="APIRunnerSettings")
TCDeletionStrategy = TypeVar("TCDeletionStrategy", bound="DeletionStrategySettings")

TNode = TypeVar("TNode")


ToolLike = Union[Dict[str, Any], Type, Callable, BaseTool]
StructuredOutput = Optional[Union[Dict[str, Any], Type[Any]]]
