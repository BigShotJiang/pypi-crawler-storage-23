from typing import Dict, List, Literal, Optional, TypedDict

from langgraph.graph import MessagesState


class Query(TypedDict):
    content: str


class IsAnswerable(TypedDict):
    response: Literal["yes", "no"]


class AgentState(MessagesState):
    query: Optional[Query]
    documents: Optional[List[Dict[str, str]]]
    is_answerable: Optional[IsAnswerable]
