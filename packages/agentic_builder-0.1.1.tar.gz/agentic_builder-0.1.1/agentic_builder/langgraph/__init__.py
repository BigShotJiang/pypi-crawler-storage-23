import logging
from abc import ABC, abstractmethod
from typing import Any, Generic, List, Optional, Type, Union

from agentic_builder.constants import TCDeletionStrategy
from agentic_builder.mixins import FromConfigMixin
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, SystemMessage
from langchain_core.messages.utils import AnyMessage
from langchain_core.runnables import Runnable
from langgraph.graph._node import _Node
from langgraph.typing import NodeInputT_contra

logger = logging.getLogger(__name__)


class Prompt(ABC, Generic[NodeInputT_contra]):

    @classmethod
    @abstractmethod
    def _render(cls, state: NodeInputT_contra) -> str:
        raise NotImplementedError()

    @classmethod
    def render(cls, state: NodeInputT_contra) -> List[BaseMessage]:
        content = cls._render(state)
        return [
            *state["messages"],  # type: ignore[index]
            SystemMessage(content=content),
        ]


class SchemaBasedPrompt(Prompt[NodeInputT_contra], Generic[NodeInputT_contra]):

    @classmethod
    @abstractmethod
    def get_schema(cls) -> Any:
        raise NotImplementedError()


class DeletionStrategy(FromConfigMixin[TCDeletionStrategy], Generic[TCDeletionStrategy]):

    def __init__(self, config: TCDeletionStrategy) -> None:
        self.config = config

    def _delete(self, messages: List[AnyMessage]) -> List[AnyMessage]:
        raise NotImplementedError()

    def delete(self, messages: List[AnyMessage]) -> List[AnyMessage]:
        before_count = len(messages)
        logger.debug(
            f"DeletionStrategy.start | " f"strategy={self.__class__.__name__} | " f"messages_before={before_count}"
        )
        new_messages = self._delete(messages)
        after_count = len(new_messages)
        removed = before_count - after_count
        logger.info(
            f"DeletionStrategy.done | "
            f"strategy={self.__class__.__name__} | "
            f"removed={removed} | "
            f"remaining={after_count}"
        )
        return new_messages


class Node(_Node[NodeInputT_contra], Generic[NodeInputT_contra]):
    def __init__(self, name: str) -> None:
        self.name = name

    async def __call__(self, state: NodeInputT_contra) -> Any: ...


class RouterNode(Node[NodeInputT_contra], Generic[NodeInputT_contra]):
    def __init__(self, name: str) -> None:
        super().__init__(name)


class LLMNode(Node[NodeInputT_contra], Generic[NodeInputT_contra]):
    def __init__(
        self,
        name: str,
        model: BaseChatModel,
        prompt: Type[Prompt[NodeInputT_contra]],
        structured_output: Optional[Union[dict, type]],
    ):
        super().__init__(name)
        runnable: Runnable[Any, AIMessage] = model

        if structured_output:
            runnable = runnable.with_structured_output(structured_output)  # type: ignore[attr-defined]
        self.runnable = runnable
        self.prompt = prompt

    async def _ainvoke(self, state: NodeInputT_contra) -> AIMessage:
        messages = self.prompt.render(state)
        return await self.runnable.ainvoke(messages)
