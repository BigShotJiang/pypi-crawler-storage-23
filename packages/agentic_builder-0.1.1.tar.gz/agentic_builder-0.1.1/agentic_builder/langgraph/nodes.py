import json
from typing import Any

from agentic_builder.langgraph import LLMNode, Node, RouterNode
from agentic_builder.langgraph.prompts import (
    AnswerFailurePrompt,
    GenerateAnswerPrompt,
    GenerateQuerySchemaBasedPrompt,
    GraderSchemaBasedPrompt,
    IrrelevantQueryPrompt,
)
from agentic_builder.langgraph.states import AgentState
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.tools.base import BaseTool


class GenerateQueryLLMNode(LLMNode[AgentState]):
    def __init__(
        self,
        name: str,
        model: BaseChatModel,
    ):
        super().__init__(
            name=name,
            model=model,
            prompt=GenerateQuerySchemaBasedPrompt,
            structured_output=GenerateQuerySchemaBasedPrompt.get_schema(),
        )

    async def __call__(self, state: AgentState) -> Any:
        query = await self._ainvoke(state)
        return {"query": query}


class SearchDocumentsNode(Node[AgentState]):
    def __init__(self, name: str, retriever_tool: BaseTool):
        super().__init__(name=name)
        self.retriever_tool = retriever_tool

    async def __call__(self, state: AgentState) -> Any:
        if state["query"] is None:
            raise ValueError("key 'query' is None in the state dict")
        # Call the retriever tool asynchronously
        tool_result = (await self.retriever_tool.arun({"query": state["query"]["content"]}))[0]
        # Parse tool output
        payload = json.loads(tool_result["text"])
        evidence = payload["retrieval"]["evidence"]
        # Return state update
        return {"documents": evidence}


class GraderLLMNode(LLMNode[AgentState]):
    def __init__(
        self,
        name: str,
        model: BaseChatModel,
    ):
        super().__init__(
            name=name,
            model=model,
            prompt=GraderSchemaBasedPrompt,
            structured_output=GraderSchemaBasedPrompt.get_schema(),
        )

    async def __call__(self, state: AgentState) -> Any:
        return {"is_answerable": (await self._ainvoke(state))}


class GenerateAnswerLLMNode(LLMNode[AgentState]):
    def __init__(
        self,
        name: str,
        model: BaseChatModel,
    ):
        super().__init__(
            name=name,
            model=model,
            prompt=GenerateAnswerPrompt,
            structured_output=None,
        )

    async def __call__(self, state: AgentState) -> Any:
        response = await self._ainvoke(state)
        return {"messages": [response]}


class AnswerFailureLLMNode(LLMNode[AgentState]):
    def __init__(
        self,
        name: str,
        model: BaseChatModel,
    ):
        super().__init__(
            name=name,
            model=model,
            prompt=AnswerFailurePrompt,
            structured_output=None,
        )

    async def __call__(self, state: AgentState) -> Any:
        response = await self._ainvoke(state)
        return {"messages": [response]}


class IrrelevantQueryLLMNode(LLMNode[AgentState]):
    def __init__(
        self,
        name: str,
        model: BaseChatModel,
    ):
        super().__init__(
            name=name,
            model=model,
            prompt=IrrelevantQueryPrompt,
            structured_output=None,
        )

    async def __call__(self, state: AgentState) -> Any:
        response = await self._ainvoke(state)
        return {"messages": [response]}


class IsQueryRelevantRouterNode(RouterNode[AgentState]):
    def __init__(self, name: str) -> None:
        super().__init__(name=name)

    async def __call__(self, state: AgentState) -> Any:
        if state["query"]["content"] != "[NAN]":  # type: ignore[index]
            return "yes"
        return "no"


class IsDocumentRelevantRouterNode(RouterNode[AgentState]):
    def __init__(self, name: str) -> None:
        super().__init__(name=name)

    async def __call__(self, state: AgentState) -> Any:
        if state["is_answerable"]:
            return state["is_answerable"]["response"]
        raise ValueError("key 'is_answerable' is None in the state dict")
