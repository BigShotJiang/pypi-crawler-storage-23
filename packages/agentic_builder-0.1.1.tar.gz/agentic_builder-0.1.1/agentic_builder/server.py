# agentic_builder/server.py

import json
import logging
import time
from contextlib import asynccontextmanager
from typing import AsyncIterator, Dict, List, Never, Optional

import uvicorn
from agentic_builder import Agent, BaseAPIRunner
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import StreamingResponse

_logger = logging.getLogger(__name__)


# ------------------------------------------------------------------
# App Factory
# ------------------------------------------------------------------


def create_agent_app(
    api_runner: Optional[BaseAPIRunner] = None,
) -> FastAPI:
    """
    Factory that creates and configures the FastAPI app.
    Can be reused inside another project.
    """

    if api_runner is None:
        api_runner = BaseAPIRunner.from_settings()

    # --------------------------------------------------------------
    # Lifespan
    # --------------------------------------------------------------

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[Never]:
        _logger.info("Initializing agent (async)")
        await api_runner.init_agent()
        app.state.agent = api_runner.agent
        _logger.info("Agent ready")
        yield  # type: ignore[misc]
        _logger.info("Shutting down agent API")

    app = FastAPI(
        title="Agent API",
        version="1.0.0",
        lifespan=lifespan,
    )

    # --------------------------------------------------------------
    # Helpers
    # --------------------------------------------------------------

    def get_agent(request: Request) -> Agent:
        return request.app.state.agent  # type: ignore[no-any-return]

    # --------------------------------------------------------------
    # Routes
    # --------------------------------------------------------------

    @app.get("/health")
    async def health() -> Dict[str, str]:
        return {"status": "ok"}

    @app.post("/v1/chat/completions")
    async def openai_chat_completions(request: Request) -> StreamingResponse:
        body = await request.json()

        model: str = body.get("model", "local-agent")
        messages: List[Dict[str, str]] = body.get("messages", [])
        stream: bool = body.get("stream", True)

        if not stream:
            raise HTTPException(
                status_code=400,
                detail="This endpoint only supports streaming",
            )

        # Extract OpenAI-style prompt
        system_msg = next(
            (m["content"] for m in messages if m.get("role") == "system"),
            "",
        )
        user_msg = next(
            (m["content"] for m in reversed(messages) if m.get("role") == "user"),
            "",
        )

        prompt = f"{system_msg}\n\nUser: {user_msg}".strip()

        created = int(time.time())
        chat_id = f"chatcmpl-{created}"
        agent = get_agent(request)

        async def sse_generator() -> AsyncIterator[str]:

            # Initial role chunk
            yield "data: " + json.dumps(
                {
                    "id": chat_id,
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": model,
                    "choices": [
                        {
                            "index": 0,
                            "delta": {"role": "assistant"},
                            "finish_reason": None,
                        }
                    ],
                }
            ) + "\n\n"

            # Token streaming
            async for token in agent.astream_llm_tokens(prompt):
                yield "data: " + json.dumps(
                    {
                        "id": chat_id,
                        "object": "chat.completion.chunk",
                        "created": created,
                        "model": model,
                        "choices": [
                            {
                                "index": 0,
                                "delta": {"content": token},
                                "finish_reason": None,
                            }
                        ],
                    }
                ) + "\n\n"

            # Final chunk
            yield "data: " + json.dumps(
                {
                    "id": chat_id,
                    "object": "chat.completion.chunk",
                    "created": created,
                    "model": model,
                    "choices": [
                        {
                            "index": 0,
                            "delta": {},
                            "finish_reason": "stop",
                        }
                    ],
                }
            ) + "\n\n"

            yield "data: [DONE]\n\n"

        return StreamingResponse(
            sse_generator(),
            media_type="text/event-stream",
        )

    return app


# ------------------------------------------------------------------
# Runner
# ------------------------------------------------------------------


def run_agentic_builder(
    api_runner: Optional[BaseAPIRunner] = None,
) -> None:
    """
    Launch the agent API using uvicorn.
    """

    if api_runner is None:
        api_runner = BaseAPIRunner.from_settings()

    app = create_agent_app(api_runner)

    _logger.info(f"Starting Agent API on " f"{api_runner.config.api.host}:{api_runner.config.api.port}")

    uvicorn.run(
        app,
        host=api_runner.config.api.host,
        port=api_runner.config.api.port,
    )
