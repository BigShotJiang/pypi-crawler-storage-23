import logging
from abc import abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncGenerator, Generic, List, Optional

from agentic_builder.constants import GRAPHS_DIR, TCAgentSettings, TCAPIRunner
from agentic_builder.llm.factory import LLMFactory
from agentic_builder.mixins import FromConfigMixin
from agentic_builder.settings import BaseAPIRunnerSettings
from agentic_builder.utils import _cached_mcp_tools, load_class
from langchain.messages import AIMessageChunk
from langchain.tools import BaseTool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph.state import CompiledStateGraph
from openinference.instrumentation import TracerProvider
from phoenix.otel import register

_logger = logging.getLogger(__name__)


class Agent(FromConfigMixin[TCAgentSettings], Generic[TCAgentSettings]):
    """
    Initializes and runs a LangChain agent backed by VLLM and Qdrant embeddings.
    Minimal version: no exception catching, f-string logs only.
    """

    _tracer_provider: Optional[TracerProvider] = None
    _compiled_graph: Optional[CompiledStateGraph] = None

    def __init__(self, config: TCAgentSettings) -> None:
        self.config = config
        self.checkpointer = InMemorySaver()
        self.configurable = {"configurable": {"thread_id": "1"}}
        _logger.info("Agent initialized")

    @classmethod
    async def create(cls, config: TCAgentSettings) -> "Agent[TCAgentSettings]":
        self = cls(config)
        await self._init_components()
        _logger.info("Agent initialized")
        self.push()
        _logger.info("Graph saved locally")
        return self

    async def _load_tools(self) -> List[BaseTool]:
        fingerprint = ",".join(f"{mcp.name}:{mcp.url}" for mcp in self.config.mcps)
        tools = await _cached_mcp_tools(
            mcps_fingerprint=fingerprint,
            mcps_config=self.config.mcps,
        )

        _logger.info("Loaded %d MCP tools (cached)", len(tools))
        return tools

    def _load_tracer_provider(self) -> TracerProvider:
        if self.__class__._tracer_provider is None:
            _logger.info("Initializing OpenInference tracer provider")
            self.__class__._tracer_provider = register(
                endpoint=self.config.phoenix.collector_endpoint,
                project_name=self.config.phoenix.project_name,
                auto_instrument=True,
            )
        _logger.info("LangChain OpenInference instrumentation enabled")
        return self.__class__._tracer_provider

    async def _init_components(self) -> None:
        self.tracer_provider = self._load_tracer_provider()
        self.tools = await self._load_tools()
        self.llm_factory: LLMFactory = load_class(self.config.llm_factory.module_path)(self.config.llm_factory)
        if self.__class__._compiled_graph is None:
            self.__class__._compiled_graph = self.build_agent()
        self.agent: CompiledStateGraph = self.__class__._compiled_graph
        _logger.info(f"Agent created")

    @abstractmethod
    def build_agent(self) -> CompiledStateGraph:
        raise NotImplementedError()

    async def arun(self, query: str) -> str:
        chunks: List[str] = []
        async for event in self.agent.astream(
            {"messages": [{"role": "user", "content": query}]},
            stream_mode="messages",
        ):
            msg = event.get("messages", [None])[-1]
            if isinstance(msg, AIMessageChunk) and msg.text:
                chunks.append(msg.text)
        return "".join(chunks)

    async def astream_llm_tokens(self, query: str) -> AsyncGenerator[str, None]:
        """
        Stream ONLY LLM tokens (no tool messages, no updates).
        """
        _logger.info(f"Streaming agent (LLM-only): {query}")

        async for token, metadata in self.agent.astream(
            {"messages": [{"role": "user", "content": query}]},
            config=self.configurable,  # type: ignore[arg-type]
            stream_mode="messages",
        ):
            if isinstance(token, AIMessageChunk) and token.text:
                yield token.text

    async def render_steps(self, query: str) -> None:
        async for chunk in self.agent.astream(
            {
                "messages": [
                    {
                        "role": "user",
                        "content": query,
                    }
                ]
            },
            config=self.configurable,  # type: ignore[arg-type]
        ):
            for node, update in chunk.items():
                print("Update from node", node)
                print(update)
                if "messages" in update and update["messages"]:
                    update["messages"][-1].pretty_print()

    def push(self) -> None:
        # Timestamp: YYYYMMDD_HHMMSS
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

        # Optional: include agent name / class
        agent_name = self.__class__.__name__

        # Build filename
        filename = f"{agent_name}_graph_{timestamp}.png"

        # Full path
        path: Path = GRAPHS_DIR / filename

        # Draw + save
        png_bytes = self.agent.get_graph().draw_mermaid_png()
        path.write_bytes(png_bytes)
        _logger.info(f"Graph saved locally at {path}")


class APIRunner(FromConfigMixin[TCAPIRunner], Generic[TCAPIRunner]):

    def __init__(self, config: TCAPIRunner):
        self.config = config
        self.agent: Agent[Any]

    @classmethod
    async def create(cls, config: TCAPIRunner) -> "APIRunner[TCAPIRunner]":
        self = cls(config)
        self.agent = await load_class(self.config.agent.module_path).create(self.config.agent)
        _logger.info("APIRunner initialized")
        return self

    async def init_agent(self) -> None:
        self.agent = await load_class(self.config.agent.module_path).create(self.config.agent)


class BaseAPIRunner(APIRunner[BaseAPIRunnerSettings]):
    def __init__(self, config: BaseAPIRunnerSettings):
        super().__init__(config)
