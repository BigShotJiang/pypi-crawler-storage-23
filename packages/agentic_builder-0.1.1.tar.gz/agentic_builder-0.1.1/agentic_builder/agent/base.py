import logging

from agentic_builder import Agent
from agentic_builder.settings import BaseAgentSettings
from langchain.agents import create_agent
from langgraph.graph.state import CompiledStateGraph

_logger = logging.getLogger(__name__)


class BaseAgent(Agent[BaseAgentSettings]):

    def __init__(self, config: BaseAgentSettings) -> None:
        super().__init__(config)

    def build_agent(self) -> CompiledStateGraph:
        model = self.llm_factory.get("fast_latency").to_langchain()
        return create_agent(model=model, tools=self.tools, checkpointer=self.checkpointer)
