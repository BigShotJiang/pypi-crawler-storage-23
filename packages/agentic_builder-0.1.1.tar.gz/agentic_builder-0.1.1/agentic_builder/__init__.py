import logging
from typing import Any, Generic

from agentic_builder.agent import Agent
from agentic_builder.constants import TCAPIRunner
from agentic_builder.mixins import FromConfigMixin
from agentic_builder.settings import BaseAPIRunnerSettings
from agentic_builder.utils import load_class

_logger = logging.getLogger(__name__)


class APIRunner(FromConfigMixin[TCAPIRunner], Generic[TCAPIRunner]):

    def __init__(self, config: TCAPIRunner):
        self.config = config
        self.agent: Agent[Any]

    @classmethod
    async def create(cls, config: TCAPIRunner) -> "APIRunner[TCAPIRunner]":
        self = cls(config)
        self.agent = await load_class(self.config.agent.module_path).create(self.config.agent)
        _logger.info("APIRunner initialized")
        return self

    async def init_agent(self) -> None:
        self.agent = await load_class(self.config.agent.module_path).create(self.config.agent)


class BaseAPIRunner(APIRunner[BaseAPIRunnerSettings]):
    def __init__(self, config: BaseAPIRunnerSettings):
        super().__init__(config)
