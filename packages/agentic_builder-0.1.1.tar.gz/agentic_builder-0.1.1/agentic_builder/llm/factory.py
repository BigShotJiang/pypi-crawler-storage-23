import logging
from typing import Any, Dict

from agentic_builder.llm import LLM
from agentic_builder.mixins import FromConfigMixin
from agentic_builder.settings import LLMFactorySettings
from agentic_builder.utils import load_class

_logger = logging.getLogger(__name__)


class LLMFactory(FromConfigMixin[LLMFactorySettings]):

    def __init__(self, config: LLMFactorySettings):
        super().__init__(config)
        self._models: Dict[str, LLM[Any]] = {}
        _logger.info(f"LLMFactory initialized with roles: {list(self.config.roles.keys())}")

    def get(self, role: str) -> LLM[Any]:
        self._validate_role(role)
        if role in self._models:
            return self._models[role]
        model = self._build_model(role)
        self._models[role] = model
        _logger.info(f"LLMFactory initialized role '{role}' successfully")
        return model

    def _validate_role(self, role: str) -> None:
        if role not in self.config.roles:
            available = list(self.config.roles.keys())
            _logger.error(f"Invalid LLM role '{role}'. Available roles: {available}")
            raise ValueError(f"LLM role '{role}' not defined. Available roles: {available}")
        _logger.debug(f"Validated LLM role '{role}'")

    def _build_model(self, role: str) -> LLM[Any]:
        role_config = self.config.roles[role]
        llm_class = load_class(role_config.module_path)
        if not isinstance(llm_class, type) or not issubclass(llm_class, LLM):
            _logger.error(f"Loaded class '{role_config.module_path}' is not a subclass of LLM. Got: {llm_class}")
            raise TypeError(f"Loaded class '{role_config.module_path}' is not a subclass of LLM. Got: {llm_class}")
        llm_instance = llm_class.from_config(role_config)
        return llm_instance
