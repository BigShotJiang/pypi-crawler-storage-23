import logging
from abc import ABC, abstractmethod
from typing import Generic, Self

from agentic_builder.constants import TCLLM
from agentic_builder.mixins import FromConfigMixin
from langchain_core.language_models.chat_models import BaseChatModel

_logger = logging.getLogger(__name__)


class LLM(FromConfigMixin[TCLLM], ABC, Generic[TCLLM]):
    def __init__(self, config: TCLLM):
        super().__init__(config)

    @abstractmethod
    def to_langchain(self) -> BaseChatModel:
        raise NotImplementedError()

    def with_streaming(self, streaming: bool = True) -> Self:
        raise NotImplementedError()
