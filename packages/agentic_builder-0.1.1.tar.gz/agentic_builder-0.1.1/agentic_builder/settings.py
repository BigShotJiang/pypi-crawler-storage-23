from typing import Annotated, Any, Dict, Generic, List, Literal, Optional, Tuple, Union

from agentic_builder.constants import CONFIG_PATH, TCAgent
from pydantic import Field
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    YamlConfigSettingsSource,
)


class FromConfigMixinSettings(BaseSettings):
    module_path: str
    model_config = SettingsConfigDict(
        yaml_file=CONFIG_PATH,
        extra="ignore",
    )

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,
            YamlConfigSettingsSource(settings_cls),
            env_settings,
            dotenv_settings,
            file_secret_settings,
        )


class PhoenixSettings(BaseSettings):
    collector_endpoint: str
    project_name: str


class APISettings(BaseSettings):
    pass


class FastAPISettings(APISettings):
    host: str
    port: int


class MCPServerSettings(BaseSettings):
    name: str
    url: str


class LLMSettings(FromConfigMixinSettings):
    model: str


class OllamaLLMSettings(LLMSettings):
    kind: Literal["ollama"]
    base_url: str


class OpenRouterLLMSettings(LLMSettings):
    kind: Literal["openrouter"]
    model_kwargs: Dict[str, Any]
    provider: Optional[Dict[str, Any]]


AnyLLMSettings = Annotated[
    Union[OllamaLLMSettings, OpenRouterLLMSettings],
    Field(discriminator="kind"),
]


class LLMFactorySettings(FromConfigMixinSettings):
    roles: Dict[str, AnyLLMSettings]


class DeletionStrategySettings(FromConfigMixinSettings):
    pass


class TrimDeletionStrategySettings(DeletionStrategySettings):
    strategy: Literal["first", "last"]
    max_tokens: int
    start_on: str
    end_on: Tuple[str, str]


class AgentSettings(FromConfigMixinSettings):
    llm_factory: LLMFactorySettings
    mcps: List[MCPServerSettings]
    phoenix: PhoenixSettings


class BaseAgentSettings(AgentSettings):
    pass


class APIRunnerSettings(FromConfigMixinSettings, Generic[TCAgent]):
    api: FastAPISettings
    agent: TCAgent


class BaseAPIRunnerSettings(APIRunnerSettings[BaseAgentSettings]):
    pass
