"""Network throughput check."""

import time

import psutil

from .base import BaseCheck

SAMPLE_INTERVAL = 2  # seconds between samples


class NetworkCheck(BaseCheck):
    name = "network"

    def __init__(self, params: dict):
        super().__init__(params)
        self.threshold_kbps = params.get("threshold_kbps", 10)
        self.interface = params.get("interface")  # None = all non-loopback
        self._last_kbps: float | None = None

    def is_idle(self) -> bool:
        before = self._get_bytes()
        time.sleep(SAMPLE_INTERVAL)
        after = self._get_bytes()

        delta_bytes = after - before
        self._last_kbps = (delta_bytes / SAMPLE_INTERVAL) / 1024
        return self._last_kbps < self.threshold_kbps

    def describe(self) -> str:
        if self._last_kbps is None:
            return "network: not yet sampled"
        idle = self._last_kbps < self.threshold_kbps
        status = "idle" if idle else "active"
        iface = self.interface or "all"
        cmp = "<" if idle else ">="
        return f"network: {status} ({self._last_kbps:.1f} KB/s {cmp} {self.threshold_kbps} KB/s, {iface})"

    def _get_bytes(self) -> int:
        """Get total bytes (sent + recv) for the target interface(s)."""
        counters = psutil.net_io_counters(pernic=True)
        total = 0
        for iface, stats in counters.items():
            if iface == "lo":
                continue
            if self.interface and iface != self.interface:
                continue
            total += stats.bytes_sent + stats.bytes_recv
        return total
