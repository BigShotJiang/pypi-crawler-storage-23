"""Load average check."""

import psutil

from .base import BaseCheck


class LoadCheck(BaseCheck):
    name = "load"

    def __init__(self, params: dict):
        super().__init__(params)
        self.threshold = params.get("threshold", 0.3)
        self._last_load: float | None = None

    def is_idle(self) -> bool:
        self._last_load = psutil.getloadavg()[0]  # 1-minute load average
        return self._last_load < self.threshold

    def describe(self) -> str:
        if self._last_load is None:
            return "load: not yet sampled"
        idle = self._last_load < self.threshold
        status = "idle" if idle else "active"
        return f"load: {status} ({self._last_load:.2f} {'<' if idle else '>='} {self.threshold})"
