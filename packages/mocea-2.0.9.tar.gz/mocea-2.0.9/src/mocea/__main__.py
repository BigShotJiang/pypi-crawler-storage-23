"""Convenience wrapper so `python -m mocea` works."""

from mocea.cli import cli

if __name__ == "__main__":
    cli()
