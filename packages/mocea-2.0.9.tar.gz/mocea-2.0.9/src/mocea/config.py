"""Configuration loading for mocea.

Priority: CLI flags > environment variables > config file > defaults.
"""

import logging
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

log = logging.getLogger(__name__)

CONFIG_SEARCH_PATHS = [
    Path("/etc/mocea/config.toml"),
    Path.home() / ".config" / "mocea" / "config.toml",
]

DEFAULTS = {
    "idle_minutes": 30,
    "check_interval": 60,
    "min_uptime_minutes": 10,
    "checks": {
        "cpu": {"enabled": True, "threshold": 5.0},
        "process": {"enabled": True, "names": ["python", "ffmpeg", "jupyter"]},
        "ssh": {"enabled": True},
        "load": {"enabled": False, "threshold": 0.3},
        "network": {"enabled": False, "threshold_kbps": 10, "interface": None},
        "gpu": {"enabled": False, "threshold": 5.0},
        "heartbeat": {"enabled": False, "file": "/tmp/mocea-heartbeat", "stale_minutes": 15},
    },
    "action": {"type": "api"},
    "logging": {"level": "INFO", "file": None},
}


@dataclass
class CheckConfig:
    enabled: bool = False
    params: dict = field(default_factory=dict)


@dataclass
class Config:
    idle_minutes: int = 30
    check_interval: int = 60
    min_uptime_minutes: int = 10
    checks: dict[str, CheckConfig] = field(default_factory=dict)
    action_type: str = "api"
    action_params: dict = field(default_factory=dict)
    fallback_action_type: str | None = None
    log_level: str = "INFO"
    log_file: str | None = None
    dry_run: bool = False

    @classmethod
    def load(cls, config_path: str | None = None, **overrides) -> "Config":
        """Load config from file with overrides.

        Args:
            config_path: Explicit path to config file. If None, searches default locations.
            **overrides: CLI overrides (idle_minutes, dry_run, etc.)
        """
        raw = _deep_merge(DEFAULTS, {})

        # Load from file
        file_path = _find_config(config_path)
        if file_path:
            log.info("Loading config from %s", file_path)
            with open(file_path, "rb") as f:
                file_data = tomllib.load(f)
            raw = _deep_merge(raw, file_data)

        # Build Config object
        cfg = cls(
            idle_minutes=raw.get("idle_minutes", 30),
            check_interval=raw.get("check_interval", 60),
            min_uptime_minutes=raw.get("min_uptime_minutes", 10),
            action_type=raw.get("action", {}).get("type", "api"),
            action_params=raw.get("action", {}),
            fallback_action_type=raw.get("action", {}).get("fallback", None),
            log_level=raw.get("logging", {}).get("level", "INFO"),
            log_file=raw.get("logging", {}).get("file"),
        )

        # Parse checks
        for name, check_raw in raw.get("checks", {}).items():
            if isinstance(check_raw, dict):
                check_raw = dict(check_raw)  # copy to avoid mutating DEFAULTS
                enabled = check_raw.pop("enabled", False)
                cfg.checks[name] = CheckConfig(enabled=enabled, params=check_raw)

        # Apply CLI overrides
        if overrides.get("idle_minutes") is not None:
            cfg.idle_minutes = overrides["idle_minutes"]
        if overrides.get("dry_run") is not None:
            cfg.dry_run = overrides["dry_run"]

        return cfg

    def enabled_checks(self) -> dict[str, CheckConfig]:
        """Return only enabled checks."""
        return {name: cc for name, cc in self.checks.items() if cc.enabled}


def _find_config(explicit_path: str | None) -> Path | None:
    """Find config file: explicit path or search defaults."""
    if explicit_path:
        p = Path(explicit_path)
        if p.is_file():
            return p
        log.warning("Config file not found: %s", explicit_path)
        return None

    for p in CONFIG_SEARCH_PATHS:
        if p.is_file():
            return p
    return None


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base (returns new dict)."""
    result = base.copy()
    for key, val in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(val, dict):
            result[key] = _deep_merge(result[key], val)
        else:
            result[key] = val
    return result
