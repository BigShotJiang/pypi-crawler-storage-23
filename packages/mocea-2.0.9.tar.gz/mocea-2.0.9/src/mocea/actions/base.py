"""Abstract base class for actions."""

from abc import ABC, abstractmethod


class BaseAction(ABC):
    """Base class for actions executed when idle timeout is reached."""

    name: str

    def __init__(self, params: dict, dry_run: bool = False):
        self.params = params
        self.dry_run = dry_run

    def validate(self) -> list[str]:
        """Check prerequisites and return a list of warning strings.

        Default returns no warnings.  Subclasses override to report
        problems (e.g. missing binary, missing API token).
        """
        return []

    @abstractmethod
    def execute(self) -> None:
        """Execute the action (shutdown, terminate, etc.)."""
        ...
