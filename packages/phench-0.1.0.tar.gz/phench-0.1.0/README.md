# phench

Standalone control-plane repository for Phenotype project-state runtime orchestration.

- Materialized runtime root: `$HOME/CodeProjects/Phenotype/projects`
- Home mirror root: `~/phench`
- State metadata per target: `.phench/`

The initial command surface is implemented in `thegent` as `thegent phench ...`.
This repo is reserved for extraction of that surface into an independent CLI/TUI.
