"""Data models for the UK Carbon Intensity API."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class Intensity:
    """Carbon intensity values."""

    forecast: int
    index: str
    actual: int | None = None


@dataclass(frozen=True)
class GenerationFuel:
    """A single fuel type in the generation mix."""

    fuel: str
    perc: float


@dataclass(frozen=True)
class IntensityPeriod:
    """A single half-hour settlement period with intensity and generation mix."""

    from_time: datetime
    to_time: datetime
    intensity: Intensity
    generationmix: list[GenerationFuel]


@dataclass(frozen=True)
class RegionalData:
    """Regional carbon intensity data for a postcode."""

    regionid: int
    dnoregion: str
    shortname: str
    postcode: str
    periods: list[IntensityPeriod]


@dataclass(frozen=True)
class NationalIntensity:
    """National carbon intensity data."""

    from_time: datetime
    to_time: datetime
    intensity: Intensity


@dataclass(frozen=True)
class NationalGenerationMix:
    """National generation mix data."""

    from_time: datetime
    to_time: datetime
    generationmix: list[GenerationFuel]
