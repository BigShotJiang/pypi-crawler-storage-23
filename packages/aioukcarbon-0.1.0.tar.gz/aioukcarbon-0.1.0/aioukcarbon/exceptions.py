"""Exceptions for the UK Carbon Intensity API client."""


class CarbonIntensityError(Exception):
    """Base exception for Carbon Intensity API errors."""


class CarbonIntensityConnectionError(CarbonIntensityError):
    """Raised when unable to connect to the API."""


class CarbonIntensityTimeoutError(CarbonIntensityError):
    """Raised when a request to the API times out."""


class CarbonIntensityNoDataError(CarbonIntensityError):
    """Raised when the API returns no data for the given parameters."""
