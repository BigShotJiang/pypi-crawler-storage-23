'pytest 공통 fixtures - 9종 데이터 생성기'
from __future__ import annotations

import hashlib
import os
import random

import pytest


def gen_zeros(size: int) -> bytes:
    '전부 0x00'
    return b'\x00' * size


def gen_ones(size: int) -> bytes:
    '전부 0xFF'
    return b'\xff' * size


def gen_repeat(size: int) -> bytes:
    '반복 패턴 (ABCD...)'
    pattern = bytes(range(256))
    repeats = size // 256 + 1
    return (pattern * repeats)[:size]


def gen_random(size: int) -> bytes:
    '랜덤 데이터'
    return os.urandom(size)


def gen_text(size: int) -> bytes:
    '텍스트 유사 데이터 (ASCII 반복)'
    text = b'Hello World! This is mshzip compression test data. '
    repeats = size // len(text) + 1
    return (text * repeats)[:size]


def gen_binary(size: int) -> bytes:
    '바이너리 헤더 유사 데이터'
    header = bytes([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A])
    repeats = size // len(header) + 1
    return (header * repeats)[:size]


def gen_sparse(size: int) -> bytes:
    '희소 데이터 (대부분 0, 간헐적 값)'
    data = bytearray(size)
    for i in range(0, size, 64):
        if i < size:
            data[i] = (i // 64) & 0xFF
    return bytes(data)


def gen_high_entropy(size: int) -> bytes:
    '높은 엔트로피 (sha256 체인)'
    result = bytearray()
    seed = b'mshzip-high-entropy-seed'
    while len(result) < size:
        seed = hashlib.sha256(seed).digest()
        result.extend(seed)
    return bytes(result[:size])


def gen_single_byte(size: int) -> bytes:
    '단일 바이트 반복 (0x42)'
    return b'\x42' * size


DATA_GENERATORS = {
    'zeros': gen_zeros,
    'ones': gen_ones,
    'repeat': gen_repeat,
    'random': gen_random,
    'text': gen_text,
    'binary': gen_binary,
    'sparse': gen_sparse,
    'high_entropy': gen_high_entropy,
    'single_byte': gen_single_byte,
}

SIZES_SMALL = [0, 1, 7, 8, 64, 127, 128, 129, 256, 1024, 4096]
SIZES_MEDIUM = [10_000, 100_000, 1_000_000]
CHUNK_SIZES = [8, 16, 32, 64, 128, 256, 512, 1024]
