'Node.js ↔ Python 교차 호환성 테스트'
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest
import mshzip

# 경로 설정
SPEC_DIR = Path(__file__).parent.parent.parent / 'spec' / 'test-vectors'
NODEJS_CLI = Path(__file__).parent.parent.parent / 'nodejs' / 'cli.js'

VECTOR_NAMES = [
    'empty',
    'small-repeat',
    'boundary-127',
    'boundary-128',
    'boundary-129',
    'multi-frame',
    'crc32',
    'codec-none',
    'large-chunk',
    'text-data',
    'binary-random',
    'single-byte',
]


class TestNodeToPython:
    'Node.js로 생성한 .msh를 Python으로 해제.'

    @pytest.mark.parametrize('name', VECTOR_NAMES)
    def test_unpack(self, name):
        msh_file = SPEC_DIR / f'{name}.msh'
        bin_file = SPEC_DIR / f'{name}.bin'
        if not msh_file.exists():
            pytest.skip(f'테스트 벡터 없음: {name}')
        msh_data = msh_file.read_bytes()
        expected = bin_file.read_bytes()
        result = mshzip.unpack(msh_data)
        assert result == expected, f'{name}: Node.js→Python 해제 실패'


class TestPythonToNode:
    'Python으로 생성한 .msh를 Node.js로 해제.'

    @pytest.mark.parametrize('name', VECTOR_NAMES)
    def test_roundtrip_via_node(self, name, tmp_path):
        bin_file = SPEC_DIR / f'{name}.bin'
        if not bin_file.exists():
            pytest.skip(f'테스트 벡터 없음: {name}')

        original = bin_file.read_bytes()

        # Python으로 pack
        packed = mshzip.pack(original)
        msh_file = tmp_path / f'{name}.msh'
        msh_file.write_bytes(packed)

        # Node.js로 unpack
        out_file = tmp_path / f'{name}.bin'
        result = subprocess.run(
            ['node', str(NODEJS_CLI), 'unpack', '-i', str(msh_file), '-o', str(out_file)],
            capture_output=True,
            timeout=30,
        )
        assert result.returncode == 0, (
            f'{name}: Node.js unpack 실패: {result.stderr.decode()}'
        )
        restored = out_file.read_bytes()
        assert restored == original, f'{name}: Python→Node.js 해제 실패'


class TestBidirectional:
    '양방향 교차 검증: 다양한 옵션 조합.'

    @pytest.mark.parametrize('chunk_size', [8, 32, 128, 1024])
    def test_chunk_sizes(self, chunk_size, tmp_path):
        data = bytes(range(256)) * 4
        # Python pack → Node.js unpack
        packed = mshzip.pack(data, chunk_size=chunk_size)
        msh_file = tmp_path / 'test.msh'
        msh_file.write_bytes(packed)
        out_file = tmp_path / 'test.bin'
        result = subprocess.run(
            ['node', str(NODEJS_CLI), 'unpack', '-i', str(msh_file), '-o', str(out_file)],
            capture_output=True, timeout=30,
        )
        assert result.returncode == 0
        assert out_file.read_bytes() == data

    @pytest.mark.parametrize('codec', ['gzip', 'none'])
    @pytest.mark.parametrize('crc', [True, False])
    def test_codec_crc(self, codec, crc, tmp_path):
        data = b'codec crc test ' * 50
        packed = mshzip.pack(data, codec=codec, crc=crc)
        msh_file = tmp_path / 'test.msh'
        msh_file.write_bytes(packed)
        out_file = tmp_path / 'test.bin'
        result = subprocess.run(
            ['node', str(NODEJS_CLI), 'unpack', '-i', str(msh_file), '-o', str(out_file)],
            capture_output=True, timeout=30,
        )
        assert result.returncode == 0
        assert out_file.read_bytes() == data
