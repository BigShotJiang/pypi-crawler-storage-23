'unsigned varint (uvarint) 인코딩/디코딩 - protobuf LEB128 호환'
from __future__ import annotations


def encode(value: int) -> bytes:
    'uint32 값을 uvarint로 인코딩하여 bytes 반환.'
    result = bytearray()
    while value > 0x7F:
        result.append((value & 0x7F) | 0x80)
        value >>= 7
    result.append(value & 0x7F)
    return bytes(result)


def encode_array(values: list[int]) -> bytes:
    '여러 uint32 값을 연속 uvarint로 인코딩.'
    parts = bytearray()
    for v in values:
        parts.extend(encode(v))
    return bytes(parts)


def decode(buf: bytes | bytearray | memoryview, offset: int = 0) -> tuple[int, int]:
    '(value, bytes_read) 반환.'
    value = 0
    shift = 0
    bytes_read = 0
    pos = offset

    while pos < len(buf):
        b = buf[pos]
        value |= (b & 0x7F) << shift
        pos += 1
        bytes_read += 1
        if (b & 0x80) == 0:
            return (value & 0xFFFFFFFF, bytes_read)
        shift += 7
        if shift > 35:
            raise ValueError('varint 오버플로우: 값이 너무 큼')

    raise ValueError('varint 불완전: 데이터 부족')


def decode_array(
    buf: bytes | bytearray | memoryview,
    offset: int,
    count: int,
) -> tuple[list[int], int]:
    '(values, total_bytes_read) 반환.'
    values: list[int] = []
    total_read = 0

    for _ in range(count):
        value, bytes_read = decode(buf, offset + total_read)
        values.append(value)
        total_read += bytes_read

    return (values, total_read)
