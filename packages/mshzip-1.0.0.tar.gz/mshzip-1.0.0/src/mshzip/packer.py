'MSH 포맷 압축 (pack) - SHA-256 dedup + 엔트로피 압축'
from __future__ import annotations

import gzip
import hashlib
import struct
import zlib

from . import varint
from .constants import (
    MAGIC, VERSION, Codec, CODEC_NAME, Flag,
    FRAME_HEADER_SIZE,
    DEFAULT_CHUNK_SIZE, DEFAULT_FRAME_LIMIT, DEFAULT_CODEC,
    MIN_CHUNK_SIZE, MAX_CHUNK_SIZE,
    AUTO_DETECT_CANDIDATES, AUTO_DETECT_SAMPLE_LIMIT, AUTO_FALLBACK_CHUNK_SIZE,
)


class Packer:
    '파일/스트림을 MSH 포맷으로 압축.'

    def __init__(
        self,
        chunk_size: int | str = DEFAULT_CHUNK_SIZE,
        frame_limit: int = DEFAULT_FRAME_LIMIT,
        codec: str = DEFAULT_CODEC,
        crc: bool = False,
    ) -> None:
        self._auto_detect = (chunk_size == 'auto')
        self.chunk_size: int = AUTO_FALLBACK_CHUNK_SIZE if self._auto_detect else int(chunk_size)
        self.frame_limit = frame_limit
        self.codec_name = codec
        self.codec_id = CODEC_NAME.get(codec)
        self.use_crc = crc

        if not self._auto_detect:
            if not (MIN_CHUNK_SIZE <= self.chunk_size <= MAX_CHUNK_SIZE):
                raise ValueError(
                    f'청크 크기 범위 초과: {MIN_CHUNK_SIZE}~{MAX_CHUNK_SIZE}'
                )
        if self.codec_id is None:
            raise ValueError(f'지원하지 않는 코덱: {codec}')

        # 전역 사전: hash(str) -> 글로벌 인덱스(int)
        self.dict_index: dict[str, int] = {}
        # 전역 청크 배열: 인덱스 -> 청크 데이터(bytes)
        self.dict_chunks: list[bytes] = []

    def pack(self, data: bytes | bytearray | memoryview) -> bytes:
        'Buffer 입력을 MSH 포맷으로 압축.'
        if isinstance(data, memoryview):
            input_view = data
        else:
            input_view = memoryview(data) if data else memoryview(b'')

        # auto 모드: 첫 호출 시 최적 청크 크기 감지
        if self._auto_detect and len(input_view) > 0:
            self.chunk_size = self._detect_chunk_size(bytes(input_view))
            self._auto_detect = False
        frames: list[bytes] = []
        offset = 0
        total_len = len(input_view)

        while offset < total_len:
            frame_end = min(offset + self.frame_limit, total_len)
            frame = self._build_frame(input_view, offset, frame_end)
            frames.append(frame)
            offset = frame_end

        # 빈 입력도 하나의 빈 프레임 생성
        if not frames:
            frame = self._build_frame(memoryview(b''), 0, 0)
            frames.append(frame)

        return b''.join(frames)

    def _build_frame(
        self,
        data: memoryview | bytes | bytearray,
        start: int,
        end: int,
    ) -> bytes:
        '입력의 [start, end) 범위에 대한 프레임 생성.'
        orig_bytes = end - start
        new_chunks: list[bytes] = []
        seq_indices: list[int] = []

        # 청크 분할 + dedup
        pos = start
        while pos < end:
            chunk_end = min(pos + self.chunk_size, end)
            chunk = bytes(data[pos:chunk_end])

            # 마지막 청크가 chunk_size보다 작으면 0 패딩
            if len(chunk) < self.chunk_size:
                chunk = chunk + b'\x00' * (self.chunk_size - len(chunk))

            # SHA-256 해시로 중복 확인
            h = hashlib.sha256(chunk).hexdigest()

            idx = self.dict_index.get(h)
            if idx is None:
                idx = len(self.dict_chunks)
                self.dict_index[h] = idx
                self.dict_chunks.append(chunk)
                new_chunks.append(chunk)

            seq_indices.append(idx)
            pos = chunk_end

        dict_entries_in_frame = len(new_chunks)
        seq_count = len(seq_indices)

        # 페이로드 구성: [사전 섹션] + [시퀀스 섹션]
        dict_section = b''.join(new_chunks) if new_chunks else b''
        seq_section = varint.encode_array(seq_indices) if seq_indices else b''
        raw_payload = dict_section + seq_section

        # 엔트로피 압축
        compressed_payload = self._compress(raw_payload)

        # 프레임 헤더 생성 (32바이트)
        flags = Flag.CRC32 if self.use_crc else 0
        header = bytearray(FRAME_HEADER_SIZE)
        off = 0
        header[off:off + 4] = MAGIC; off += 4
        struct.pack_into('<H', header, off, VERSION); off += 2
        struct.pack_into('<H', header, off, flags); off += 2
        struct.pack_into('<I', header, off, self.chunk_size); off += 4
        header[off] = self.codec_id; off += 1
        off += 3  # 패딩
        struct.pack_into('<I', header, off, orig_bytes & 0xFFFFFFFF); off += 4
        struct.pack_into('<I', header, off, orig_bytes >> 32); off += 4
        struct.pack_into('<I', header, off, dict_entries_in_frame); off += 4
        struct.pack_into('<I', header, off, seq_count); off += 4

        header_bytes = bytes(header)

        # 압축 페이로드 크기 (4바이트 LE)
        payload_size_buf = struct.pack('<I', len(compressed_payload))

        parts = [header_bytes, payload_size_buf, compressed_payload]

        # CRC32 (선택)
        if self.use_crc:
            crc_data = header_bytes + payload_size_buf + compressed_payload
            crc_val = zlib.crc32(crc_data) & 0xFFFFFFFF
            parts.append(struct.pack('<I', crc_val))

        return b''.join(parts)

    def _detect_chunk_size(self, data: bytes) -> int:
        '데이터를 샘플링하여 최적 청크 크기를 자동 감지.'
        sample_end = min(len(data), AUTO_DETECT_SAMPLE_LIMIT)
        sample = data[:sample_end]

        best_cs = AUTO_FALLBACK_CHUNK_SIZE
        best_cost = float('inf')

        for cs in AUTO_DETECT_CANDIDATES:
            if cs > sample_end:
                continue

            hashes: set[str] = set()
            pos = 0
            total_chunks = 0

            while pos < sample_end:
                end = min(pos + cs, sample_end)
                chunk = sample[pos:end]

                if len(chunk) < cs:
                    chunk = chunk + b'\x00' * (cs - len(chunk))

                h = hashlib.sha256(chunk).hexdigest()
                hashes.add(h)
                total_chunks += 1
                pos += cs

            unique_count = len(hashes)
            dict_cost = unique_count * cs
            # varint 바이트 수 추정 (LEB128: 7비트 단위)
            varint_bytes = 1 if unique_count <= 127 else 2 if unique_count <= 16383 else 3
            seq_cost = total_chunks * varint_bytes
            total_cost = dict_cost + seq_cost

            if total_cost < best_cost:
                best_cost = total_cost
                best_cs = cs

        return best_cs

    def _compress(self, data: bytes) -> bytes:
        '페이로드 압축.'
        if not data:
            return data

        if self.codec_id == Codec.NONE:
            return data
        elif self.codec_id == Codec.GZIP:
            return gzip.compress(data, compresslevel=1)
        else:
            return data
