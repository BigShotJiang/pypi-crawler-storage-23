'MSH 포맷 복원 (unpack) - 프레임 파싱 + 사전 누적'
from __future__ import annotations

import gzip
import struct

from . import varint
from .constants import (
    MAGIC, Codec, Flag,
    FRAME_HEADER_SIZE,
)


class Unpacker:
    'MSH 포맷 데이터를 원본으로 복원.'

    def __init__(self) -> None:
        self.dict: list[bytes] = []

    def unpack(self, data: bytes | bytearray | memoryview) -> bytes:
        'MSH 데이터를 원본으로 복원.'
        if isinstance(data, memoryview):
            buf = data
        else:
            buf = memoryview(data) if data else memoryview(b'')
        parts: list[bytes] = []
        offset = 0

        while offset < len(buf):
            restored, bytes_consumed = self._read_frame(buf, offset)
            parts.append(restored)
            offset += bytes_consumed

        return b''.join(parts)

    def _read_frame(
        self,
        buf: memoryview | bytes | bytearray,
        offset: int,
    ) -> tuple[bytes, int]:
        '단일 프레임 읽기 및 복원. (data, bytes_consumed) 반환.'
        start_offset = offset

        if offset + FRAME_HEADER_SIZE > len(buf):
            raise ValueError(f'프레임 헤더 부족: offset={offset}')

        # 매직 넘버 확인
        magic = bytes(buf[offset:offset + 4])
        if magic != MAGIC:
            raise ValueError(f'잘못된 매직 넘버: {magic!r}')

        # 헤더 파싱 (수동 오프셋 - Node.js 원본과 1:1 매핑)
        off = offset + 4  # magic 이후
        version = struct.unpack_from('<H', buf, off)[0]; off += 2
        flags = struct.unpack_from('<H', buf, off)[0]; off += 2
        chunk_size = struct.unpack_from('<I', buf, off)[0]; off += 4
        codec_id = buf[off]; off += 1
        off += 3  # 패딩
        orig_bytes_lo = struct.unpack_from('<I', buf, off)[0]; off += 4
        orig_bytes_hi = struct.unpack_from('<I', buf, off)[0]; off += 4
        orig_bytes = orig_bytes_hi * 0x100000000 + orig_bytes_lo
        dict_entries = struct.unpack_from('<I', buf, off)[0]; off += 4
        seq_count = struct.unpack_from('<I', buf, off)[0]; off += 4

        # 압축 페이로드 크기
        payload_size = struct.unpack_from('<I', buf, off)[0]; off += 4

        # 압축 페이로드 읽기
        compressed_payload = bytes(buf[off:off + payload_size])
        off += payload_size

        # CRC32 확인
        has_crc = (flags & Flag.CRC32) != 0
        if has_crc:
            off += 4  # CRC 스킵 (Node.js 원본도 검증 스킵)

        # 페이로드 해제
        raw_payload = self._decompress(compressed_payload, codec_id)

        # 사전 섹션 파싱
        payload_off = 0
        for _ in range(dict_entries):
            chunk = bytes(raw_payload[payload_off:payload_off + chunk_size])
            self.dict.append(chunk)
            payload_off += chunk_size

        # 시퀀스 섹션 파싱
        if seq_count > 0 and orig_bytes > 0:
            indices, _ = varint.decode_array(raw_payload, payload_off, seq_count)

            chunks: list[bytes] = []
            for idx in indices:
                if idx >= len(self.dict):
                    raise ValueError(
                        f'사전 인덱스 범위 초과: {idx} >= {len(self.dict)}'
                    )
                chunks.append(self.dict[idx])

            full_data = b''.join(chunks)
            restored_data = full_data[:orig_bytes]
        else:
            restored_data = b''

        return (restored_data, off - start_offset)

    @staticmethod
    def _decompress(data: bytes, codec_id: int) -> bytes:
        '페이로드 해제.'
        if not data:
            return data

        if codec_id == Codec.NONE:
            return data
        elif codec_id == Codec.GZIP:
            return gzip.decompress(data)
        else:
            raise ValueError(f'지원하지 않는 코덱 ID: {codec_id}')
