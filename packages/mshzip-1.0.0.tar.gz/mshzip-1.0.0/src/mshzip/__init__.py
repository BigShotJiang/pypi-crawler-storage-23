'mshzip - 고정 청크 dedup + 엔트로피 압축'
from __future__ import annotations

from .packer import Packer
from .unpacker import Unpacker
from .stream import PackStream, UnpackStream, pack_stream, unpack_stream
from . import constants
from . import varint


def pack(data: bytes | bytearray, **opts) -> bytes:
    '데이터 압축 (간편 API).'
    packer = Packer(**opts)
    return packer.pack(data)


def unpack(data: bytes | bytearray) -> bytes:
    '데이터 해제 (간편 API).'
    unpacker = Unpacker()
    return unpacker.unpack(data)


__all__ = [
    'pack', 'unpack',
    'Packer', 'Unpacker',
    'PackStream', 'UnpackStream',
    'pack_stream', 'unpack_stream',
    'constants', 'varint',
]

__version__ = '1.0.0'
