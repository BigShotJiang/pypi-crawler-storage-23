'MSH 압축 포맷 상수 정의'
from __future__ import annotations

# 매직 넘버 (4바이트)
MAGIC: bytes = b'MSH1'

# 버전
VERSION: int = 1


# 코덱 ID
class Codec:
    NONE: int = 0
    GZIP: int = 1


# 코덱 이름 <-> ID 매핑
CODEC_NAME: dict[str, int] = {
    'none': Codec.NONE,
    'gzip': Codec.GZIP,
}

CODEC_ID_TO_NAME: dict[int, str] = {
    Codec.NONE: 'none',
    Codec.GZIP: 'gzip',
}


# 플래그 비트
class Flag:
    CRC32: int = 0x0001


# 프레임 헤더 크기 (고정 32바이트)
# magic(4) + version(2) + flags(2) + chunkSize(4) + codec(1) + pad(3)
# + origBytes(4+4) + dictEntries(4) + seqCount(4) = 32
FRAME_HEADER_SIZE: int = 32

# 기본값
DEFAULT_CHUNK_SIZE: int | str = 'auto'  # 자동 감지 (이전 기본값: 128)
DEFAULT_FRAME_LIMIT: int = 64 * 1024 * 1024  # 64MB
DEFAULT_CODEC: str = 'gzip'

# 청크 크기 범위
MIN_CHUNK_SIZE: int = 8
MAX_CHUNK_SIZE: int = 16 * 1024 * 1024  # 16MB

# 자동 청크 크기 감지
AUTO_DETECT_CANDIDATES: list[int] = [32, 64, 128, 256, 512, 1024, 2048, 4096]
AUTO_DETECT_SAMPLE_LIMIT: int = 1024 * 1024  # 1MB
AUTO_DETECT_STREAM_MIN: int = 64 * 1024  # 64KB (스트리밍 최소 샘플)
AUTO_FALLBACK_CHUNK_SIZE: int = 128  # auto 감지 실패 시 폴백
