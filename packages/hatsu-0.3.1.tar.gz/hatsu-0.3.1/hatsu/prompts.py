import json

def build_prompt(text: str, estimate_data: dict, mode: str) -> str:
    """
    入力テキストと感情推定データから、LLMに渡すプロンプトを構築します。
    """
    # LLMが構造を理解しやすいよう、辞書データをインデント付きのJSON文字列に変換
    estimate_str = json.dumps(estimate_data, ensure_ascii=False, indent=2)

    if mode == "plus":
        instruction = (
            "Based on the provided text and the estimated emotions, "
            "generate a comment that reinforces and amplifies the estimated emotions. "
            "The output MUST be in the same language as the input text."
        )
    elif mode == "minus":
        instruction = (
            "Based on the provided text and the estimated emotions, "
            "generate a comment that contradicts, opposes, or denies the estimated emotions. "
            "The output MUST be in the same language as the input text."
        )
    elif mode == "sync":
        instruction = (
            "You are an 'Intellectual Ally' who provides high-level validation and extension of the user's ideas. "
            "Based on the provided text and the estimated emotions, respond in a way that feels supportive and warm, "
            "while remaining sophisticated enough for a public (1:N) audience.\n\n"
            "Constraints:\n"
            "1. Gentle Intellectual Elevation: Maintain the respect of a trusted peer, but act as a slightly more experienced co-thinker. Subtly elevate the discourse without ever being patronizing.\n"
            "2. Mirroring Length: Match the response length to the input text (within ±20%).\n"
            "3. Density of Thought: Prioritize substance. Aim to be *one half-step ahead* of the user's intellectual weight. Introduce a slightly more refined vocabulary or a broader conceptual framework that elegantly sharpens their original point.\n"
            "4. Natural Flow: No headers or bullet points. Respond as a single, coherent piece of prose.\n"
            "5. Empathic Resonance: Stand *with* the user. Adjust your support based on the estimated emotions (e.g., share in their epiphany, or help organize the chaos of their frustration into a clear structural insight).\n"
            "6. The 'Intellectual Ally' Persona: Act as a mentor-like co-thinker. Tone: 'Warmed Intellectualism.' Professional yet genuinely kind.\n"
            "7. Benevolent Wit: Use subtle, clever humor or sharp observations that are *appreciative* rather than cynical.\n"
            "8. Public-Private Balance: Validate the user directly while maintaining the dignity of public discourse.\n"
            "9. Linguistic Refinement: Match the user's energy and basic formality, but subtly refine the articulation.\n"
            "10. No Cynicism: Strictly avoid irony or sarcasm that creates distance.\n\n"
            "The output MUST be in the same language as the input text."
        )
    else:
        # core.py側で弾いていますが、念のためのフェイルセーフ
        raise ValueError(f"Unknown mode: '{mode}'")

    # プロンプトの組み立て（見出しも英語で統一）
    prompt = f"""[Text]
{text}

[Estimated Emotions]
{estimate_str}

[Instruction]
{instruction}"""

    return prompt