from rest_framework import status
from rest_framework.response import Response
from ..services import EveUniverseSearchService
from rest_framework.views import APIView
from .parsers import PlainTextParser
from ..permissions import HasCompensationsPluginAccess

class FilterTermSearch(APIView):
    parser_classes = [PlainTextParser]
    permission_classes = [HasCompensationsPluginAccess]
    
    """API для поиска сущностей в EVE Universe по имени"""
    def post(self, request):
        search_term = request.data
        
        if not search_term:
            return Response({"error": "search_term is required"}, status=status.HTTP_400_BAD_REQUEST)
        
        # Декодируем байты в строку, если необходимо
        if isinstance(search_term, bytes):
            search_term = search_term.decode('utf-8').strip()
        
        if len(search_term.strip()) < 3:
            return Response({"error": "search_term must be at least 3 characters"}, status=status.HTTP_400_BAD_REQUEST)
        
        result = EveUniverseSearchService.search_by_name(search_term)
        return Response(status=200,data=result)
    