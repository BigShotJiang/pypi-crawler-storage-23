"""
Tests for BIRD (Buffer and Invocation Record Database) integration.

Tests the BIRD storage backend including:
- BirdStore initialization and schema creation
- Session management
- Invocation writing and querying
- Event writing
- Output/blob storage
- Integration with blq init --bird
- Integration with command execution
"""

from __future__ import annotations

import argparse
import os
import tempfile
import uuid
from datetime import datetime
from pathlib import Path

import pytest

from blq.bird import (
    BirdStore,
    InvocationRecord,
    write_bird_invocation,
)
from blq.commands.core import BlqConfig, write_run_parquet
from blq.commands.init_cmd import cmd_init
from blq.commands.migrate import _migrate_parquet_to_bird, cmd_migrate


@pytest.fixture
def temp_dir():
    """Create a temporary directory for tests."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def bird_store(temp_dir):
    """Create a BirdStore in a temporary directory."""
    lq_dir = temp_dir / ".lq"
    lq_dir.mkdir()
    (lq_dir / "blobs" / "content").mkdir(parents=True)

    store = BirdStore.open(lq_dir)
    yield store
    store.close()


@pytest.fixture
def bird_initialized_dir(temp_dir):
    """Initialize a directory with BIRD mode (default)."""
    original_cwd = os.getcwd()
    os.chdir(temp_dir)
    try:
        args = argparse.Namespace()
        args.mcp = False
        args.detect = False
        args.detect_mode = "none"
        args.yes = False
        args.force = False
        args.parquet = False  # BIRD is now default, parquet is opt-in
        args.namespace = "test"
        args.project = "bird-test"

        cmd_init(args)
        yield temp_dir
    finally:
        os.chdir(original_cwd)


class TestBirdStoreInit:
    """Tests for BirdStore initialization."""

    def test_open_creates_schema(self, temp_dir):
        """Opening a BirdStore creates the schema."""
        lq_dir = temp_dir / ".lq"
        lq_dir.mkdir()
        (lq_dir / "blobs" / "content").mkdir(parents=True)

        store = BirdStore.open(lq_dir)

        # Check tables exist
        tables = store.connection.execute(
            "SELECT table_name FROM information_schema.tables WHERE table_schema = 'main'"
        ).fetchall()
        table_names = {t[0] for t in tables}

        assert "sessions" in table_names
        assert "invocations" in table_names
        assert "outputs" in table_names
        assert "events" in table_names
        assert "blob_registry" in table_names
        assert "blq_metadata" in table_names

        store.close()

    def test_open_idempotent(self, temp_dir):
        """Opening a BirdStore multiple times doesn't fail."""
        lq_dir = temp_dir / ".lq"
        lq_dir.mkdir()
        (lq_dir / "blobs" / "content").mkdir(parents=True)

        # First open
        store1 = BirdStore.open(lq_dir)
        store1.close()

        # Second open should work
        store2 = BirdStore.open(lq_dir)
        assert store2.invocation_count() == 0
        store2.close()

    def test_context_manager(self, temp_dir):
        """BirdStore works as context manager."""
        lq_dir = temp_dir / ".lq"
        lq_dir.mkdir()
        (lq_dir / "blobs" / "content").mkdir(parents=True)

        with BirdStore.open(lq_dir) as store:
            assert store.invocation_count() == 0


class TestSessionManagement:
    """Tests for session management."""

    def test_ensure_session_creates(self, bird_store):
        """ensure_session creates a new session."""
        bird_store.ensure_session(
            session_id="test-session",
            client_id="blq-test",
            invoker="blq",
            invoker_type="cli",
            cwd="/tmp/test",
        )

        result = bird_store.connection.execute(
            "SELECT * FROM sessions WHERE session_id = 'test-session'"
        ).fetchone()

        assert result is not None
        assert result[1] == "blq-test"  # client_id

    def test_ensure_session_idempotent(self, bird_store):
        """ensure_session doesn't duplicate sessions."""
        bird_store.ensure_session(
            session_id="test-session",
            client_id="blq-test",
            invoker="blq",
            invoker_type="cli",
        )
        bird_store.ensure_session(
            session_id="test-session",
            client_id="blq-test",
            invoker="blq",
            invoker_type="cli",
        )

        count = bird_store.connection.execute(
            "SELECT COUNT(*) FROM sessions WHERE session_id = 'test-session'"
        ).fetchone()[0]

        assert count == 1


class TestInvocationManagement:
    """Tests for invocation writing and querying."""

    def test_write_invocation(self, bird_store):
        """write_invocation stores an invocation."""
        inv = InvocationRecord(
            id=str(uuid.uuid4()),
            session_id="test",
            cmd="echo hello",
            cwd="/tmp",
            exit_code=0,
            client_id="blq-test",
        )

        inv_id = bird_store.write_invocation(inv)

        assert inv_id == inv.id
        assert bird_store.invocation_count() == 1

    def test_write_invocation_with_metadata(self, bird_store):
        """write_invocation stores all metadata fields."""
        inv = InvocationRecord(
            id=str(uuid.uuid4()),
            session_id="test",
            cmd="pytest tests/",
            cwd="/home/user/project",
            exit_code=1,
            client_id="blq-shell",
            duration_ms=5000,
            executable="/usr/bin/pytest",
            format_hint="pytest_text",
            hostname="testhost",
            username="testuser",
            source_name="test",
            source_type="run",
            environment={"PATH": "/usr/bin", "PYTHONPATH": "/home/user"},
            platform="Linux",
            arch="x86_64",
            git_commit="abc123",
            git_branch="main",
            git_dirty=True,
            ci={"provider": "github", "run_id": "12345"},
        )

        bird_store.write_invocation(inv)

        result = bird_store.connection.execute(
            "SELECT source_name, hostname, git_branch FROM invocations"
        ).fetchone()

        assert result[0] == "test"
        assert result[1] == "testhost"
        assert result[2] == "main"

    def test_recent_invocations(self, bird_store):
        """recent_invocations returns invocations in order."""
        for i in range(5):
            inv = InvocationRecord(
                id=str(uuid.uuid4()),
                session_id="test",
                cmd=f"command-{i}",
                cwd="/tmp",
                exit_code=0,
                client_id="blq-test",
            )
            bird_store.write_invocation(inv)

        recent = bird_store.recent_invocations(3)

        assert len(recent) == 3
        # Most recent first
        assert recent[0]["cmd"] == "command-4"

    def test_invocation_count(self, bird_store):
        """invocation_count returns correct count."""
        assert bird_store.invocation_count() == 0

        for i in range(3):
            inv = InvocationRecord(
                id=str(uuid.uuid4()),
                session_id="test",
                cmd=f"cmd-{i}",
                cwd="/tmp",
                exit_code=0,
                client_id="blq-test",
            )
            bird_store.write_invocation(inv)

        assert bird_store.invocation_count() == 3


class TestEventManagement:
    """Tests for event writing."""

    def test_write_events(self, bird_store):
        """write_events stores parsed events."""
        inv = InvocationRecord(
            id=str(uuid.uuid4()),
            session_id="test",
            cmd="make",
            cwd="/tmp",
            exit_code=1,
            client_id="blq-test",
        )
        bird_store.write_invocation(inv)

        events = [
            {
                "event_id": 0,
                "severity": "error",
                "ref_file": "src/main.c",
                "ref_line": 10,
                "message": "undefined reference to 'foo'",
                "tool_name": "gcc",
            },
            {
                "event_id": 1,
                "severity": "warning",
                "ref_file": "src/util.c",
                "ref_line": 25,
                "message": "unused variable 'x'",
                "tool_name": "gcc",
            },
        ]

        count = bird_store.write_events(inv.id, events, client_id="blq-test", format_used="gcc")

        assert count == 2
        assert bird_store.event_count() == 2

    def test_write_events_empty(self, bird_store):
        """write_events handles empty event list."""
        inv = InvocationRecord(
            id=str(uuid.uuid4()),
            session_id="test",
            cmd="echo hello",
            cwd="/tmp",
            exit_code=0,
            client_id="blq-test",
        )
        bird_store.write_invocation(inv)

        count = bird_store.write_events(inv.id, [], client_id="blq-test")

        assert count == 0
        assert bird_store.event_count() == 0


class TestOutputManagement:
    """Tests for output/blob storage."""

    def test_write_output_inline(self, bird_store):
        """Small outputs are stored inline."""
        inv = InvocationRecord(
            id=str(uuid.uuid4()),
            session_id="test",
            cmd="echo hello",
            cwd="/tmp",
            exit_code=0,
            client_id="blq-test",
        )
        bird_store.write_invocation(inv)

        content = b"hello world\n"
        output = bird_store.write_output(inv.id, "combined", content)

        assert output.storage_type == "inline"
        assert output.storage_ref.startswith("data:")
        assert output.byte_length == len(content)

    def test_write_output_blob(self, bird_store):
        """Large outputs are stored as blobs."""
        inv = InvocationRecord(
            id=str(uuid.uuid4()),
            session_id="test",
            cmd="cat bigfile",
            cwd="/tmp",
            exit_code=0,
            client_id="blq-test",
        )
        bird_store.write_invocation(inv)

        # Create content larger than inline threshold (4KB)
        content = b"x" * 5000
        output = bird_store.write_output(inv.id, "combined", content)

        assert output.storage_type == "blob"
        assert output.storage_ref.startswith("file:")
        assert output.byte_length == len(content)

        # Check blob file exists
        blob_path = bird_store._blob_dir / output.storage_ref.replace("file:", "")
        assert blob_path.exists()

    def test_blob_deduplication(self, bird_store):
        """Identical content is deduplicated."""
        inv = InvocationRecord(
            id=str(uuid.uuid4()),
            session_id="test",
            cmd="cat bigfile",
            cwd="/tmp",
            exit_code=0,
            client_id="blq-test",
        )
        bird_store.write_invocation(inv)

        content = b"y" * 5000

        # Write same content twice
        output1 = bird_store.write_output(inv.id, "stdout", content)
        output2 = bird_store.write_output(inv.id, "stderr", content)

        # Same hash
        assert output1.content_hash == output2.content_hash

    def test_cleanup_orphaned_blobs(self, bird_store):
        """Orphaned blobs are cleaned up."""
        inv = InvocationRecord(
            id=str(uuid.uuid4()),
            session_id="test",
            cmd="cat bigfile",
            cwd="/tmp",
            exit_code=0,
            client_id="blq-test",
        )
        bird_store.write_invocation(inv)

        # Write a blob
        content = b"z" * 5000
        output = bird_store.write_output(inv.id, "combined", content)
        blob_path = bird_store._blob_dir / output.storage_ref.replace("file:", "")
        assert blob_path.exists()

        # Delete the output record (simulate prune)
        bird_store._conn.execute("DELETE FROM outputs WHERE invocation_id = ?", [inv.id])

        # Blob still exists (orphaned)
        assert blob_path.exists()

        # Cleanup orphaned blobs
        blobs_deleted, bytes_freed = bird_store.cleanup_orphaned_blobs()

        assert blobs_deleted == 1
        assert bytes_freed == len(content)
        assert not blob_path.exists()

        # Registry entry should be deleted too
        result = bird_store._conn.execute(
            "SELECT COUNT(*) FROM blob_registry WHERE content_hash = ?", [output.content_hash]
        ).fetchone()
        assert result[0] == 0


class TestWriteBirdInvocation:
    """Tests for the write_bird_invocation helper function."""

    def test_write_bird_invocation(self, temp_dir):
        """write_bird_invocation creates complete invocation."""
        lq_dir = temp_dir / ".lq"
        lq_dir.mkdir()
        (lq_dir / "blobs" / "content").mkdir(parents=True)

        # Initialize schema
        store = BirdStore.open(lq_dir)
        store.close()

        events = [
            {"severity": "error", "message": "test error", "ref_file": "test.py"},
        ]
        run_meta = {
            "source_name": "test",
            "source_type": "run",
            "command": "pytest",
            "started_at": datetime.now().isoformat(),
            "completed_at": datetime.now().isoformat(),
            "exit_code": 1,
            "cwd": str(temp_dir),
            "hostname": "testhost",
        }

        inv_id, db_path = write_bird_invocation(events, run_meta, lq_dir)

        assert inv_id is not None
        assert db_path.exists()

        # Verify data was written
        store = BirdStore.open(lq_dir)
        assert store.invocation_count() == 1
        assert store.event_count() == 1
        store.close()

    def test_write_bird_invocation_with_output(self, temp_dir):
        """write_bird_invocation stores output when provided."""
        lq_dir = temp_dir / ".lq"
        lq_dir.mkdir()
        (lq_dir / "blobs" / "content").mkdir(parents=True)

        store = BirdStore.open(lq_dir)
        store.close()

        run_meta = {
            "source_name": "test",
            "source_type": "run",
            "command": "echo hello",
            "started_at": datetime.now().isoformat(),
            "completed_at": datetime.now().isoformat(),
            "exit_code": 0,
            "cwd": str(temp_dir),
        }
        output = b"hello world\n"

        inv_id, _ = write_bird_invocation([], run_meta, lq_dir, output=output)

        # Verify output was written
        store = BirdStore.open(lq_dir)
        result = store.connection.execute(
            "SELECT COUNT(*) FROM outputs WHERE invocation_id = ?", [inv_id]
        ).fetchone()
        assert result[0] == 1
        store.close()

    def test_write_bird_invocation_sets_tag(self, temp_dir):
        """write_bird_invocation sets tag to source_name (logical command name)."""
        lq_dir = temp_dir / ".lq"
        lq_dir.mkdir()
        (lq_dir / "blobs" / "content").mkdir(parents=True)

        store = BirdStore.open(lq_dir)
        store.close()

        run_meta = {
            "source_name": "build",  # Logical command name
            "source_type": "run",
            "command": "make -j8 all",  # Actual shell command
            "started_at": datetime.now().isoformat(),
            "completed_at": datetime.now().isoformat(),
            "exit_code": 0,
            "cwd": str(temp_dir),
        }

        inv_id, _ = write_bird_invocation([], run_meta, lq_dir)

        # Verify tag was set to source_name
        store = BirdStore.open(lq_dir)
        result = store.connection.execute(
            "SELECT tag, source_name, cmd FROM invocations WHERE id = ?", [inv_id]
        ).fetchone()
        assert result[0] == "build"  # tag = source_name
        assert result[1] == "build"  # source_name
        assert result[2] == "make -j8 all"  # actual command
        store.close()


class TestBirdInit:
    """Tests for blq init (BIRD is default storage mode)."""

    def test_init_creates_bird_structure(self, bird_initialized_dir):
        """Default blq init creates BIRD directory structure."""
        lq_dir = bird_initialized_dir / ".lq"

        assert lq_dir.exists()
        assert (lq_dir / "blq.duckdb").exists()
        assert (lq_dir / "blobs" / "content").exists()
        assert (lq_dir / "schema.sql").exists()
        assert (lq_dir / "config.toml").exists()

    def test_init_sets_bird_storage_mode(self, bird_initialized_dir):
        """Default blq init sets storage mode to bird."""
        config = BlqConfig.load(bird_initialized_dir / ".lq")

        assert config.storage_mode == "bird"
        assert config.use_bird is True

    def test_init_bird_schema_works(self, bird_initialized_dir):
        """BIRD schema is functional after init."""
        lq_dir = bird_initialized_dir / ".lq"

        store = BirdStore.open(lq_dir)

        # Can write invocations
        inv = InvocationRecord(
            id=str(uuid.uuid4()),
            session_id="test",
            cmd="echo test",
            cwd=str(bird_initialized_dir),
            exit_code=0,
            client_id="blq-test",
        )
        store.write_invocation(inv)

        assert store.invocation_count() == 1
        store.close()

    def test_init_parquet_flag_uses_legacy_mode(self, temp_dir):
        """blq init --parquet creates legacy parquet structure."""
        original_cwd = os.getcwd()
        os.chdir(temp_dir)
        try:
            args = argparse.Namespace()
            args.mcp = False
            args.detect = False
            args.detect_mode = "none"
            args.yes = False
            args.force = False
            args.parquet = True  # Opt into legacy mode
            args.namespace = "test"
            args.project = "parquet-test"

            cmd_init(args)

            lq_dir = temp_dir / ".lq"
            assert lq_dir.exists()
            assert (lq_dir / "blq.duckdb").exists()
            assert (lq_dir / "logs").exists()  # Parquet uses logs dir
            assert not (lq_dir / "blobs").exists()  # No blobs in parquet mode

            config = BlqConfig.load(lq_dir)
            assert config.storage_mode == "parquet"
            assert config.use_bird is False
        finally:
            os.chdir(original_cwd)


class TestBirdCompatibilityViews:
    """Tests for backward compatibility views."""

    def test_blq_events_flat_view(self, bird_store):
        """blq_events_flat view provides v1-compatible schema."""
        # Create session, invocation, and events
        bird_store.ensure_session("test", "blq-test", "blq", "cli")

        inv = InvocationRecord(
            id=str(uuid.uuid4()),
            session_id="test",
            cmd="make build",
            cwd="/tmp",
            exit_code=1,
            client_id="blq-test",
            source_name="build",
            source_type="run",
            hostname="testhost",
        )
        bird_store.write_invocation(inv)

        events = [
            {
                "severity": "error",
                "ref_file": "src/main.c",
                "ref_line": 10,
                "message": "error message",
            },
        ]
        bird_store.write_events(inv.id, events, client_id="blq-test")

        # Query through compatibility view
        result = bird_store.connection.execute(
            "SELECT source_name, severity, ref_file, message FROM blq_events_flat"
        ).fetchone()

        assert result[0] == "build"
        assert result[1] == "error"
        assert result[2] == "src/main.c"

    def test_blq_load_events_macro(self, bird_store):
        """blq_load_events() macro works with BIRD schema."""
        bird_store.ensure_session("test", "blq-test", "blq", "cli")

        inv = InvocationRecord(
            id=str(uuid.uuid4()),
            session_id="test",
            cmd="pytest",
            cwd="/tmp",
            exit_code=0,
            client_id="blq-test",
            source_name="test",
        )
        bird_store.write_invocation(inv)

        # Use the macro
        result = bird_store.connection.execute("SELECT COUNT(*) FROM blq_load_events()").fetchone()

        # Should return 0 events (invocation exists but no events)
        assert result[0] == 0


class TestSQLSplitting:
    """Tests for SQL statement splitting."""

    def test_split_simple_statements(self):
        """Simple statements are split correctly."""
        sql = "SELECT 1; SELECT 2; SELECT 3;"
        statements = BirdStore._split_sql_statements(sql)

        assert len(statements) == 3
        assert statements[0] == "SELECT 1"
        assert statements[1] == "SELECT 2"
        assert statements[2] == "SELECT 3"

    def test_split_with_comments(self):
        """Comments are preserved but don't break splitting."""
        sql = """
        -- This is a comment
        SELECT 1;
        /* Block comment */
        SELECT 2;
        """
        statements = BirdStore._split_sql_statements(sql)

        assert len(statements) == 2

    def test_split_complex_macro(self):
        """Complex macros with semicolons in subqueries are handled."""
        sql = """
        CREATE MACRO test() AS TABLE
        SELECT * FROM (SELECT 1 AS a UNION SELECT 2);

        SELECT 'done';
        """
        statements = BirdStore._split_sql_statements(sql)

        assert len(statements) == 2
        assert "CREATE MACRO" in statements[0]
        assert "SELECT 'done'" in statements[1]


@pytest.fixture
def parquet_initialized_dir(temp_dir):
    """Initialize a directory with parquet (v1) mode and some test data."""
    original_cwd = os.getcwd()
    os.chdir(temp_dir)
    try:
        # Initialize without BIRD mode (parquet)
        args = argparse.Namespace()
        args.mcp = False
        args.detect = False
        args.detect_mode = "none"
        args.yes = False
        args.force = False
        args.parquet = True  # Explicitly use legacy parquet mode (not BIRD)
        args.namespace = "test"
        args.project = "parquet-test"

        cmd_init(args)

        # Write some test parquet data
        lq_dir = temp_dir / ".lq"
        events = [
            {
                "event_id": 0,
                "severity": "error",
                "ref_file": "src/main.c",
                "ref_line": 10,
                "message": "undefined reference",
                "tool_name": "gcc",
            },
            {
                "event_id": 1,
                "severity": "warning",
                "ref_file": "src/util.c",
                "ref_line": 25,
                "message": "unused variable",
                "tool_name": "gcc",
            },
        ]
        run_meta = {
            "run_id": 1,
            "source_name": "build",
            "source_type": "run",
            "command": "make build",
            "started_at": "2024-01-15T10:00:00",
            "completed_at": "2024-01-15T10:01:00",
            "exit_code": 1,
            "cwd": str(temp_dir),
            "hostname": "testhost",
            "platform": "Linux",
            "arch": "x86_64",
        }

        write_run_parquet(events, run_meta, lq_dir)

        # Write a second run with no events
        run_meta2 = {
            "run_id": 2,
            "source_name": "test",
            "source_type": "run",
            "command": "pytest",
            "started_at": "2024-01-15T11:00:00",
            "completed_at": "2024-01-15T11:02:00",
            "exit_code": 0,
            "cwd": str(temp_dir),
            "hostname": "testhost",
        }
        write_run_parquet([{}], run_meta2, lq_dir)

        yield temp_dir
    finally:
        os.chdir(original_cwd)


class TestMigration:
    """Tests for parquet to BIRD migration."""

    def test_migrate_dry_run(self, parquet_initialized_dir):
        """Dry run shows what would be migrated."""
        config = BlqConfig.load(parquet_initialized_dir / ".lq")

        invocations, events = _migrate_parquet_to_bird(config, dry_run=True, verbose=False)

        assert invocations == 2  # Two runs
        assert events == 2  # Two events (error + warning)

        # Config should not be changed
        assert config.storage_mode == "parquet"

    def test_migrate_actual(self, parquet_initialized_dir):
        """Migration converts parquet data to BIRD."""
        config = BlqConfig.load(parquet_initialized_dir / ".lq")
        lq_dir = parquet_initialized_dir / ".lq"

        invocations, events = _migrate_parquet_to_bird(config, dry_run=False, verbose=False)

        assert invocations == 2
        assert events == 2

        # Verify BIRD data
        store = BirdStore.open(lq_dir)
        assert store.invocation_count() == 2
        assert store.event_count() == 2

        # Check invocation details
        recent = store.recent_invocations(10)
        cmds = {r["cmd"] for r in recent}
        assert "make build" in cmds
        assert "pytest" in cmds

        store.close()

    def test_migrate_preserves_metadata(self, parquet_initialized_dir):
        """Migration preserves all metadata fields."""
        config = BlqConfig.load(parquet_initialized_dir / ".lq")
        lq_dir = parquet_initialized_dir / ".lq"

        _migrate_parquet_to_bird(config, dry_run=False, verbose=False)

        store = BirdStore.open(lq_dir)

        # Check that metadata was preserved
        result = store.connection.execute("""
            SELECT hostname, platform, source_name
            FROM invocations
            WHERE cmd = 'make build'
        """).fetchone()

        assert result[0] == "testhost"
        assert result[1] == "Linux"
        assert result[2] == "build"

        store.close()

    def test_cmd_migrate_to_bird(self, parquet_initialized_dir):
        """blq migrate --to-bird command works."""
        os.chdir(parquet_initialized_dir)

        args = argparse.Namespace()
        args.to_bird = True
        args.dry_run = False
        args.keep_parquet = True
        args.force = False
        args.verbose = False

        cmd_migrate(args)

        # Config should now be BIRD mode
        config = BlqConfig.load(parquet_initialized_dir / ".lq")
        assert config.storage_mode == "bird"

    def test_migrate_no_data(self, temp_dir):
        """Migration handles empty directory gracefully."""
        original_cwd = os.getcwd()
        os.chdir(temp_dir)
        try:
            # Initialize without BIRD mode but don't add data
            args = argparse.Namespace()
            args.mcp = False
            args.detect = False
            args.detect_mode = "none"
            args.yes = False
            args.force = False
            args.parquet = True  # Explicitly use legacy parquet mode (not BIRD)
            args.namespace = "test"
            args.project = "empty-test"

            cmd_init(args)

            config = BlqConfig.load(temp_dir / ".lq")
            invocations, events = _migrate_parquet_to_bird(config, dry_run=False, verbose=False)

            # Should handle gracefully with no data
            assert invocations == 0
            assert events == 0
        finally:
            os.chdir(original_cwd)


def _has_read_lines_extension() -> bool:
    """Check if read_lines extension is available."""
    import duckdb

    try:
        conn = duckdb.connect()
        conn.execute("LOAD read_lines")
        conn.close()
        return True
    except duckdb.Error:
        return False


@pytest.mark.skipif(not _has_read_lines_extension(), reason="read_lines extension not available")
class TestBlqReadLinesMacro:
    """Tests for blq_read_lines SQL macro."""

    @pytest.fixture
    def conn(self):
        """Create DuckDB connection with read_lines and macro loaded."""
        import duckdb

        conn = duckdb.connect()
        conn.execute("LOAD read_lines")
        # Define the macro
        conn.execute("""
            CREATE OR REPLACE MACRO blq_read_lines(content, lines_spec, marks := []) AS TABLE
            SELECT
                l.line_number,
                rtrim(l.content, chr(10) || chr(13)) AS line,
                coalesce(
                    (SELECT m.m.mark
                     FROM (SELECT unnest(marks) AS m) m
                     WHERE l.line_number >= m.m.start AND l.line_number <= m.m."end"
                     LIMIT 1),
                    ''
                ) AS mark
            FROM parse_lines(content, lines := lines_spec) l
            ORDER BY l.line_number
        """)
        yield conn
        conn.close()

    def test_basic_line_selection(self, conn):
        """Read lines without marks."""
        result = conn.execute("""
            SELECT * FROM blq_read_lines('line1
line2
line3', '1-3')
        """).fetchall()

        assert len(result) == 3
        assert result[0] == (1, "line1", "")
        assert result[1] == (2, "line2", "")
        assert result[2] == (3, "line3", "")

    def test_single_line_mark(self, conn):
        """Mark a single line."""
        result = conn.execute("""
            SELECT * FROM blq_read_lines(
                'line1
line2
line3',
                '1-3',
                [{start: 2, "end": 2, mark: '>>>'}]
            )
        """).fetchall()

        assert result[0] == (1, "line1", "")
        assert result[1] == (2, "line2", ">>>")
        assert result[2] == (3, "line3", "")

    def test_range_mark(self, conn):
        """Mark a range of lines."""
        result = conn.execute("""
            SELECT * FROM blq_read_lines(
                'line1
line2
line3
line4
line5',
                '1-5',
                [{start: 2, "end": 4, mark: '>>>'}]
            )
        """).fetchall()

        assert result[0][2] == ""  # line 1
        assert result[1][2] == ">>>"  # line 2
        assert result[2][2] == ">>>"  # line 3
        assert result[3][2] == ">>>"  # line 4
        assert result[4][2] == ""  # line 5

    def test_multiple_marks(self, conn):
        """Multiple mark ranges with different markers."""
        result = conn.execute("""
            SELECT * FROM blq_read_lines(
                'line1
line2
line3
line4
line5',
                '1-5',
                [
                    {start: 2, "end": 2, mark: '>>>'},
                    {start: 4, "end": 5, mark: '!!!'}
                ]
            )
        """).fetchall()

        assert result[0][2] == ""  # line 1
        assert result[1][2] == ">>>"  # line 2
        assert result[2][2] == ""  # line 3
        assert result[3][2] == "!!!"  # line 4
        assert result[4][2] == "!!!"  # line 5

    def test_context_line_spec(self, conn):
        """Use context-style line spec."""
        result = conn.execute("""
            SELECT * FROM blq_read_lines(
                'line1
line2
line3
line4
line5',
                '3 +/-1',
                [{start: 3, "end": 3, mark: '>>>'}]
            )
        """).fetchall()

        assert len(result) == 3
        assert result[0] == (2, "line2", "")
        assert result[1] == (3, "line3", ">>>")
        assert result[2] == (4, "line4", "")

    def test_empty_marks_list(self, conn):
        """Empty marks list works."""
        result = conn.execute("""
            SELECT * FROM blq_read_lines('line1
line2', '1-2', [])
        """).fetchall()

        assert len(result) == 2
        assert all(row[2] == "" for row in result)

    def test_custom_mark_strings(self, conn):
        """Custom marker strings."""
        result = conn.execute("""
            SELECT * FROM blq_read_lines(
                'line1
line2
line3',
                '1-3',
                [{start: 1, "end": 1, mark: 'ERR'},
                 {start: 3, "end": 3, mark: 'WRN'}]
            )
        """).fetchall()

        assert result[0][2] == "ERR"
        assert result[1][2] == ""
        assert result[2][2] == "WRN"


class TestSearchContent:
    """Tests for _search_content function (grep functionality)."""

    def test_basic_search(self, capsys):
        """Search finds matching lines."""
        from blq.commands.management import _search_content

        content = "line1\nline2 ERROR here\nline3\nline4 WARNING\nline5"
        _search_content(content, "ERROR", context=0)

        captured = capsys.readouterr()
        assert ">>> " in captured.out
        assert "ERROR" in captured.out
        assert "line1" not in captured.out  # No context

    def test_search_with_context(self, capsys):
        """Search includes context lines."""
        from blq.commands.management import _search_content

        content = "line1\nline2\nline3 ERROR\nline4\nline5"
        _search_content(content, "ERROR", context=1)

        captured = capsys.readouterr()
        assert "line2" in captured.out  # Before context
        assert "ERROR" in captured.out  # Match
        assert "line4" in captured.out  # After context
        assert "line1" not in captured.out  # Outside context

    def test_search_case_insensitive(self, capsys):
        """Search is case insensitive by default."""
        from blq.commands.management import _search_content

        content = "line1\nERROR here\nline3"
        _search_content(content, "error", context=0, case_insensitive=True)

        captured = capsys.readouterr()
        assert "ERROR" in captured.out

    def test_search_case_sensitive(self, capsys):
        """Search can be case sensitive."""
        from blq.commands.management import _search_content

        content = "line1\nERROR here\nline3"
        _search_content(content, "error", context=0, case_insensitive=False)

        captured = capsys.readouterr()
        assert "no matches" in captured.out

    def test_search_regex(self, capsys):
        """Search supports regex patterns."""
        from blq.commands.management import _search_content

        content = "line1\nERROR: something\nWARNING: other\nline4"
        _search_content(content, "ERROR|WARNING", context=0)

        captured = capsys.readouterr()
        assert "ERROR" in captured.out
        assert "WARNING" in captured.out

    def test_search_no_matches(self, capsys):
        """Search handles no matches gracefully."""
        from blq.commands.management import _search_content

        content = "line1\nline2\nline3"
        _search_content(content, "NOTFOUND", context=0)

        captured = capsys.readouterr()
        assert "no matches" in captured.out

    def test_search_marks_match_lines(self, capsys):
        """Matching lines are marked with >>>."""
        from blq.commands.management import _search_content

        content = "line1\nline2 MATCH\nline3"
        _search_content(content, "MATCH", context=1)

        captured = capsys.readouterr()
        lines = captured.out.strip().split("\n")
        # Find the MATCH line
        match_line = [ln for ln in lines if "MATCH" in ln][0]
        assert match_line.startswith(">>>")
