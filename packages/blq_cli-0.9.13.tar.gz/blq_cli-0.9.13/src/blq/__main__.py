"""Allow running blq as a module: python -m blq"""

from blq.cli import main

if __name__ == "__main__":
    main()
