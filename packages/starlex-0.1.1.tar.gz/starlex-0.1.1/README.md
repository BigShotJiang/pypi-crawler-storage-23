# Starlex Python SDK

Official Python SDK package for Starlex.

This release provides the initial SDK package scaffold and versioned distribution for Python consumers.

## Build

```bash
uv run --with build python -m build
```

## Publish

```bash
uv run --with twine python -m twine upload --non-interactive -u __token__ -p "$PYPI_API_TOKEN" dist/*
```
