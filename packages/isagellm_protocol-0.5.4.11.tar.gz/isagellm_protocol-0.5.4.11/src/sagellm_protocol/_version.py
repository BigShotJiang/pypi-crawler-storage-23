"""Version information for sagellm-protocol."""

__version__ = "0.5.4.11"
