To configure this module, you need to:

- Assign *Multi Operating Unit* group to user.
- Go to *Settings / Users & Companies / Operating Units* and create
  Operating Units.
