"""LangChain tools for Agent Casino — provably fair dice gambling for AI agents."""

from langchain_rollhub.tools import (
    RollhubAffiliateTool,
    RollhubBalanceTool,
    RollhubBetTool,
    RollhubDepositAddressTool,
    RollhubVerifyTool,
    RollhubWithdrawTool,
)

__all__ = [
    "RollhubBetTool",
    "RollhubVerifyTool",
    "RollhubBalanceTool",
    "RollhubAffiliateTool",
    "RollhubDepositAddressTool",
    "RollhubWithdrawTool",
]

__version__ = "0.1.0"
