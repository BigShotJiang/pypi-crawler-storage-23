# langchain-rollhub

LangChain tools for [Agent Casino](https://agent.rollhub.com) — provably fair dice gambling for AI agents.

## Installation

```bash
pip install langchain-rollhub
```

## Quick Start

```python
from langchain_rollhub import (
    RollhubBetTool,
    RollhubVerifyTool,
    RollhubBalanceTool,
    RollhubAffiliateTool,
    RollhubDepositAddressTool,
    RollhubWithdrawTool,
)

API_KEY = "rh_sk_..."

# Create tools
tools = [
    RollhubBetTool(api_key=API_KEY),
    RollhubVerifyTool(api_key=API_KEY),
    RollhubBalanceTool(api_key=API_KEY),
    RollhubAffiliateTool(api_key=API_KEY),
    RollhubDepositAddressTool(api_key=API_KEY),
    RollhubWithdrawTool(api_key=API_KEY),
]
```

### With a LangChain Agent

```python
from langchain_openai import ChatOpenAI
from langchain.agents import create_tool_calling_agent, AgentExecutor
from langchain_core.prompts import ChatPromptTemplate

llm = ChatOpenAI(model="gpt-4o")
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are an AI agent that can gamble on Agent Casino."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])

agent = create_tool_calling_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

# Example conversation
executor.invoke({"input": "Bet $5 on over 50, then verify the bet, then check my affiliate stats"})
```

## Available Tools

| Tool | Description |
|------|-------------|
| `RollhubBetTool` | Place a provably fair dice bet (target, direction, amount) |
| `RollhubVerifyTool` | Verify any past bet's provably fair proof |
| `RollhubBalanceTool` | Check current account balance |
| `RollhubAffiliateTool` | Check affiliate earnings and referral stats |
| `RollhubDepositAddressTool` | Get a crypto deposit address |
| `RollhubWithdrawTool` | Withdraw funds to an external wallet |

## API

All tools accept `api_key` (required) and `base_url` (optional, defaults to `https://agent.rollhub.com/api/v1`).

Get your API key at [agent.rollhub.com](https://agent.rollhub.com).
