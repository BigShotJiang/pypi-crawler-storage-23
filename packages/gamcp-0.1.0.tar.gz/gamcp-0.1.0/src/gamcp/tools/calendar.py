from gamcp.gam_runner import execute_gam

def register(mcp):

    @mcp.tool()
    def transfer_calendar_event(
        source_user_email: str,
        destination_user_email: str,
        event_id: str,
        confirmed: bool = False
    ) -> str:
        """
        Transfers a calendar event from one user to another.
        Note: GAM7 v7.31.03+ removed the direct calendar transfer command
        due to Calendar API changes. This tool will update the event's organizer field
        and add the destination user as an organizer-level attendee.
        
        WARNING: The Meet link may break if the original organizer leaves the org.
        
        Args:
            source_user_email: The original organizer of the event.
            destination_user_email: The new organizer for the event.
            event_id: The ID of the calendar event.
            confirmed: Must be True to execute. If False, returns a preview.
            
        GAM pattern:
            gam calendar <source_user_email> update event id <event_id>
                organizer <destination_user_email>
        """
        args = [
            "calendar", source_user_email, "update", "event", "id", event_id,
            "organizer", destination_user_email
        ]
        
        warning_msg = "WARNING: The Meet link may break if the original organizer leaves the org."
        if not confirmed:
            return f"{warning_msg}\\n\\nPREVIEW (not executed - run with confirmed=True):\\nCommand: gam {' '.join(args)}"
            
        result = execute_gam(args)
        return f"{warning_msg}\\n\\nResult:\\n{result}"
