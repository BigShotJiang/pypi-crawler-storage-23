import os
from typing import Literal

from gamcp.gam_runner import execute_gam

def register(mcp):
    
    @mcp.tool()
    def migrate_folder_to_shared_drive(
        owner_email: str,
        source_folder_id: str,
        destination_shared_drive_id: str,
        destination_parent_folder_id: str,
        copy_file_permissions: bool = True,
        confirmed: bool = False
    ) -> str:
        """
        Migrates a Google Drive folder to a Shared Drive.
        
        Args:
            owner_email: The email of the user who owns the source folder.
            source_folder_id: The ID of the folder to migrate.
            destination_shared_drive_id: The ID of the destination Shared Drive.
            destination_parent_folder_id: The ID of the destination parent folder within the Shared Drive.
            copy_file_permissions: Whether to copy file permissions. Defaults to True.
            confirmed: Must be True to execute. If False, returns a preview of the command.
            
        GAM pattern:
            gam user <owner_email> copy drivefile <source_folder_id>
                teamdriveid <destination_shared_drive_id>
                teamdriveparentid <destination_parent_folder_id>
                recursive mergewithparent
                copyfilepermissions <true/false> copyfilenoninheritedpermissions <true/false>
                copytopfoldernoninheritedpermissions always
                copysubfoldernoninheritedpermissions always
        """
        copy_perms = "true" if copy_file_permissions else "false"
        args = [
            "user", owner_email, "copy", "drivefile", source_folder_id,
            "teamdriveid", destination_shared_drive_id,
            "teamdriveparentid", destination_parent_folder_id,
            "recursive", "mergewithparent",
            "copyfilepermissions", copy_perms,
            "copyfilenoninheritedpermissions", copy_perms,
            "copytopfoldernoninheritedpermissions", "always",
            "copysubfoldernoninheritedpermissions", "always"
        ]
        
        if not confirmed:
            return f"PREVIEW (not executed - run with confirmed=True):\\nCommand: gam {' '.join(args)}"
            
        return execute_gam(args)

    @mcp.tool()
    def get_permissions_to_sheet(
        target_type: Literal["shared_drive", "file", "my_drive_folder"],
        resource_id: str,
        operator_email: str,
        output_sheet_id: str,
        output_sheet_name: str
    ) -> str:
        """
        Retrieves file/folder/shared drive permissions and writes them to a Google Sheet.
        
        Args:
            target_type: The type of resource ('shared_drive', 'file', 'my_drive_folder').
            resource_id: The ID of the resource.
            operator_email: The email of the admin/user executing the report (for file/folder).
            output_sheet_id: The ID of the Google Sheet to output results to.
            output_sheet_name: The sheet tab name to write to.
            
        GAM pattern (shared_drive): gam print teamdriveacls teamdrive <resource_id> todrive ...
        GAM pattern (file/folder):  gam user <operator_email> print drivefileacls <resource_id> todrive ...
        """
        if target_type == "shared_drive":
            args = ["print", "teamdriveacls", "teamdrive", resource_id]
        else:
            args = ["user", operator_email, "print", "drivefileacls", resource_id]
            
        args.extend([
            "todrive", "tdfileid", output_sheet_id, 
            "tdsheet", f'"{output_sheet_name}"', "tdupdatesheet"
        ])
        
        # This is a read-only tool, no confirmation guard needed.
        result = execute_gam(args)
        return f"Results written to Google Sheet ID: {output_sheet_id} (Sheet Name: {output_sheet_name})\\n\\n{result}"
