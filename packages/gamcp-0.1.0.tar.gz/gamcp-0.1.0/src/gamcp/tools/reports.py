from gamcp.gam_runner import execute_gam

def register(mcp):

    @mcp.tool()
    def get_gmail_log_events(
        actor_email: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        event_name: str | None = None,
        output_sheet_id: str | None = None,
        output_sheet_name: str = "Gmail Logs"
    ) -> str:
        """
        Retrieves Gmail log events and optionally writes them to a Google Sheet.
        
        Args:
            actor_email: Optional email to filter logs for a specific actor.
            start_date: Optional start date (YYYY-MM-DD).
            end_date: Optional end date (YYYY-MM-DD).
            event_name: Optional event name to filter.
            output_sheet_id: Optional Sheet ID for output. Strongly recommended.
            output_sheet_name: Tab name for sheet output.
            
        GAM pattern:
            gam report gmail [actor <actor_email>] [start <start_date>]
                [end <end_date>] [event <event_name>] [todrive ...]
        """
        args = ["report", "gmail"]
        if actor_email:
            args.extend(["actor", actor_email])
        if start_date:
            args.extend(["start", start_date])
        if end_date:
            args.extend(["end", end_date])
        if event_name:
            args.extend(["event", event_name])
            
        if output_sheet_id:
            args.extend([
                "todrive", "tdfileid", output_sheet_id, 
                "tdsheet", f'"{output_sheet_name}"', "tdupdatesheet"
            ])
            
        result = execute_gam(args)
        if output_sheet_id:
            return f"Results written to Google Sheet ID: {output_sheet_id} (Sheet Name: {output_sheet_name})\\n\\n{result}"
        else:
            return f"WARNING: No output_sheet_id provided. Results may be truncated.\\n\\n{result}"

    @mcp.tool()
    def get_user_email_count_to_sheet(
        user_emails: list[str],
        label: str = "INBOX",
        output_sheet_id: str | None = None,
        output_sheet_name: str = "Email Counts"
    ) -> str:
        """
        Retrieves email counts for specific labels across multiple users.
        Uses multiprocess redirect if outputting to a sheet.
        
        Args:
            user_emails: List of user emails to query.
            label: The Gmail label to count (e.g., 'INBOX', 'TRASH').
            output_sheet_id: Optional Sheet ID for output.
            output_sheet_name: Tab name for sheet output.
            
        GAM pattern:
            gam [redirect csv - multiprocess todrive ...]
            user <email1>,<email2> show messages label <label> countsonly
        """
        args = []
        if output_sheet_id:
            args.extend([
                "redirect", "csv", "-", "multiprocess",
                "todrive", "tdfileid", output_sheet_id,
                "tdsheet", f'"{output_sheet_name}"', "tdupdatesheet"
            ])
            
        users_str = ",".join(user_emails)
        args.extend(["user", users_str, "show", "messages", "label", label, "countsonly"])
        
        result = execute_gam(args)
        if output_sheet_id:
            return f"Results written to Google Sheet ID: {output_sheet_id} (Sheet Name: {output_sheet_name})\\n\\n{result}"
        return result
