import sys
import logging
import os
from pathlib import Path

# Add the 'src' directory to sys.path so 'gamcp' can be imported when running as a script
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from mcp.server.fastmcp import FastMCP

from gamcp.tools.core import register as register_core_tools
from gamcp.tools.drive import register as register_drive_tools
from gamcp.tools.calendar import register as register_calendar_tools
from gamcp.tools.groups import register as register_group_tools
from gamcp.tools.users import register as register_user_tools
from gamcp.tools.reports import register as register_report_tools
from gamcp.tools.bulk import register as register_bulk_tools
from gamcp.resources.bulk_processing import register as register_bulk_resources

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    stream=sys.stderr
)
logger = logging.getLogger("gamcp")

mcp = FastMCP("gam")

register_core_tools(mcp)
register_drive_tools(mcp)
register_calendar_tools(mcp)
register_group_tools(mcp)
register_user_tools(mcp)
register_report_tools(mcp)
register_bulk_tools(mcp)
register_bulk_resources(mcp)

def main():
    mcp.run(transport='stdio')

if __name__ == "__main__":
    main()
