# GAM MCP Server
![Python 3.13](https://img.shields.io/badge/Python-3.13-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54&style=plastic)
[![License](https://img.shields.io/badge/license-MIT-red?style=for-the-badge&logo=github&logoColor=white&style=plastic)](https://github.com/ktibbs9417/gamcp/blob/main/LICENSE)
[![PyPI version](https://img.shields.io/pypi/v/gamcp.svg?style=for-the-badge&logo=pypi&logoColor=green&style=plastic)](https://pypi.org/project/gamcp/)




This is a Model Context Protocol (MCP) server that empowers an AI IDE, terminal, or agent to perform administrative actions on Google Workspace using an existing local installation of [GAM7](https://github.com/GAM-team/GAM).

## Prerequisites
- **Python 3.10+** (managed via `uv` or installed globally)
- [**GAM7**](https://github.com/GAM-team/GAM): Installed and fully authenticated with a `client_secrets.json` and `oauth2.txt`/`oauth2service.json`.
- **uv**: The ultra-fast Python package installer and resolver.

## Environment Variables

The server relies on the following environment variables to locate and run your local GAM installation:

- `GAM_EXECUTABLE_PATH` (optional): The absolute path to your local `gam` executable. If `gam` is already in your `PATH`, you can leave this unset, and the server will execute `gam` directly.
- `GAM_CFG_DIR` (optional): The absolute path to the directory containing your GAM configuration and authentication files (e.g. `oauth2.txt`, `client_secrets.json`). If left unset, GAM will use its default configuration paths.

## Installation and Usage

To run the server with `uv`:

```bash
uv run src/gamcp/server.py
```

### Usage with Claude Desktop

Add the following to your `claude_desktop_config.json`:

> **Important:** Claude Desktop often does not inherit your full system path. If you used the standalone installer for `uv` (which places it in `~/.local/bin` or `~/.cargo/bin`), you will likely receive a *"Failed to spawn process"* error. To fix this, replace `"uv"` or `"uvx"` in the `command` field with the **absolute path** to the executable (e.g., `"/Users/YOUR_USER/.local/bin/uvx"` or `"/opt/homebrew/bin/uvx"`).

#### Running locally (Development & Cloning)
If you've cloned this repository locally, you can use `uv run`:

```json
{
  "mcpServers": {
    "gam": {
      "command": "/absolute/path/to/uv",
      "args": [
        "--directory",
        "/absolute/path/to/gamcp",
        "run",
        "src/gamcp/server.py"
      ]
    }
  }
}

```

#### Easy installation (Global standard)
If you have published this package to PyPI or installed it globally via `uv tool install`, you can use `uvx` directly, which runs isolated tools reliably.

```json
{
  "mcpServers": {
    "gam": {
      "command": "uvx",
      "args": [
        "gamcp"
      ]
    }
  }
}
```

*Note: In most cases, the MCP server will automatically detect the standard location `GAM` or `GAMADV-XTD3` installers place their configuration and executable files into. If you installed `GAM` in a non-standard location, you can additionally supply the `GAM_EXECUTABLE_PATH` or `GAM_CFG_DIR` variables in the `env` dictionary block.*

## Tools

The server exposes the following tools:

- `run_gam_command(args: list[str])`: Executes a GAM command. Provide the arguments as a list of strings. For example: `["info", "domain"]` will execute `gam info domain`. It returns the standard output and standard error from the execution.

## Acknowledgements

This project uses documentation derived from the
[GAM7 project](https://github.com/GAM-team/GAM),
which is licensed under the [Apache License 2.0](https://www.apache.org/licenses/LICENSE-2.0).
GAM MCP Server is not affiliated with or endorsed by the GAM-team.
