"""ctxmux - context multiplexer for MCP."""
___version___ = "0.0.1"
