# ctmux

Context multiplexer for MCP. Intelligent context paging for LLMs.

Work in progress.
