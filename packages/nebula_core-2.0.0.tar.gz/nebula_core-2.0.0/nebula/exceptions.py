class TemplateNotFound(BaseException):
    pass


class InvalidMethod(BaseException):
    pass
