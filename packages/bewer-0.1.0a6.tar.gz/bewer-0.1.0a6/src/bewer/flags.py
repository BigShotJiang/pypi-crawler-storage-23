TOKENIZERS = "tokenizers"
STANDARDIZERS = "standardizers"
NORMALIZERS = "normalizers"
DEFAULT = "default"
