"""Jinja2 templates for generating HTML reports."""
