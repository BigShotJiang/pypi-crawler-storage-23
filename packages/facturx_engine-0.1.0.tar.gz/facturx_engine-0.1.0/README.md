# facturx-engine

Python SDK for [Factur-X Engine](https://github.com/facturx-engine/facturx-engine) — generate and validate Factur-X, ZUGFeRD 2.x, and XRechnung invoices via a self-hosted Docker API.

## Install

```bash
pip install facturx-engine
```

## Usage

```python
from facturx_engine import FacturxEngine

client = FacturxEngine("http://localhost:8000")

# Generate EN 16931 CII XML
xml = client.generate_xml({
    "invoice_number": "INV-2025-001",
    "issue_date": "20250101",
    "seller": {"name": "My Company", "vat_number": "FR12345678901"},
    "buyer": {"name": "Customer GmbH"},
    "lines": [{"name": "Consulting", "net_price": 1000.0, "vat_rate": 20.0}],
    "amounts": {"grand_total": "1200.00"}
})

# Validate a Factur-X / ZUGFeRD / XRechnung file
result = client.validate("invoice.pdf")
print(result)
```

## Requirements

Requires a running [Factur-X Engine](https://hub.docker.com/r/facturxengine/facturx-engine) instance:

```bash
docker run -d -p 8000:8000 facturxengine/facturx-engine:latest
```

## License

MIT
