# Bundled public knowledge snapshot (Wikidata entities).
# Populated by: python -m smartmemory.grounding.snapshot --output smartmemory/data/public_knowledge/
