"""Redis Streams producers for background worker event dispatch (CORE-BG-1)."""
