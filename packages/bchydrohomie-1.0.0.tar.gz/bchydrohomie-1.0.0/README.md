# BCHydroHomie API

BCHydro Python API for extracting electricity usage statistics from your personal account.

This was taken up from Eric McNeice's work here: https://github.com/emcniece/bchydro

BC Hydro seems to be making changes to break these projects.

## Installation

Via [PyPi](https://pypi.org/project/bchydrohomie/):

```sh
pip install bchydrohomie
```

**That's it!** The appropriate Playwright browser will be installed automatically on first use:
- **macOS**: webkit (Safari-based)
- **Linux**: chromium
- **Windows**: chromium

**Note**: The first time you use the library (when you call a method that requires authentication), it will automatically download and install the browser binary (~100-300MB). This is a one-time download and will only take a minute. Subsequent uses will be instant.

If you prefer to pre-install the browser before using the library, you can run:

```sh
# macOS
playwright install webkit

# Linux/Windows
playwright install chromium
```

Via Github:

```sh
# Fetch the code
git clone https://github.com/rhude/bchydrohomie.git
cd bchydrohomie

# Set up environment
pip install -r requirements.txt
```

## Usage

Running the example script:

```sh
pip install bchydro

export BCH_USER=your.email@domain.com
export BCH_PASS=your-bch-password

python test.py
```

Using in a project:

```py
import asyncio
from bchydrohomie import BCHydroApiBrowser

async def main():
    bch = BCHydroApiBrowser("username", "password")

    # Asynchronous usage:
    print(await bch.get_usage())
    print(await bch.get_latest_point())
    print(await bch.get_latest_usage())
    print(await bch.get_latest_interval())
    print(await bch.get_latest_cost())

    # Mostly synchronous usage:
    await bch.refresh()
    print(bch.usage)
    print(bch.latest_point)
    print(bch.latest_usage)
    print(bch.latest_interval)
    print(bch.latest_cost)

asyncio.run(main())
```

#### ⚠ Read-Only Account Sharing

This project accesses your BCHydro account as would a human in a browser. It is recommended that a read-only account is set up for use with this project for more secure operation. Using this secondary account also enables backup access in the event of account lockout.

- Read-only accounts can be [configured here](https://app.bchydro.com/BCHCustomerPortal/web/accountAccessView.html) after logging in.


### Maintenance

Dependencies can be updated with [pip-tools](https://github.com/jazzband/pip-tools):

```sh
# Install pip-compile and pip-sync
pip install pip-tools

# Upgrade requirements
pip-compile --upgrade
```

## Disclaimer

This package has been developed without the express permission of BC Hydro. It accesses data by pretending to be a browser and downloading a CSV with usage data. I would be happy to work with BCHydro on a better option however they have actively been working against us, blocking previous projects. 
