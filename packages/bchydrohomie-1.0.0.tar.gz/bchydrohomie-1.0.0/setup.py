from os import path
from setuptools import setup
from setuptools.command.install import install
import subprocess
import sys
import platform


class PostInstallCommand(install):
    """Post-installation command to install Playwright browsers."""
    def run(self):
        install.run(self)

        # Detect OS and choose the best browser
        system = platform.system().lower()
        if system == "darwin":  # macOS
            browser = "webkit"
        elif system == "linux":
            browser = "chromium"
        elif system == "windows":
            browser = "chromium"
        else:
            # Fallback to chromium for unknown systems
            browser = "chromium"

        try:
            print(f"Detected OS: {system}")
            print(f"Installing Playwright {browser} browser...")
            subprocess.check_call([sys.executable, "-m", "playwright", "install", browser])
            print(f"Playwright {browser} browser installed successfully.")
        except subprocess.CalledProcessError as e:
            print(f"Warning: Failed to install Playwright browsers: {e}")
            print(f"You may need to run 'playwright install {browser}' manually.")


repo_url = "https://github.com/rhude/bchydrohomie"
pwd = path.abspath(path.dirname(__file__))

# Extract package version
with open(path.join(pwd, "VERSION"), encoding="utf-8") as f:
    version = f.read()

# Pull PyPi description from README.md
with open(path.join(pwd, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="bchydrohomie",
    packages=["bchydrohomie"],
    version=version,
    license="MIT",
    description="BCHydro API",
    long_description_content_type="text/markdown",
    long_description=long_description,
    author="Jeff Rhude",
    author_email="jeff@rhude.com",
    url=repo_url,
    download_url=f"{repo_url}/releases/latest/download/package.tar.gz",
    keywords=["bchydrohomie"],
    install_requires=[
        "playwright>=1.40.0",
    ],
    extras_require={
        "dev": [
            "pip-tools<=7.4.1",
        ],
    },
    cmdclass={
        'install': PostInstallCommand,
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Build Tools",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
    ],
)
