import csv
import logging
import os
import platform
import subprocess
import sys
from datetime import datetime, timedelta
from typing import Optional
import urllib.parse


from playwright.async_api import async_playwright


from .const import (
    DOWNLOAD_CENTER_PARAMS,
    URL_DOWNLOAD_CENTER_PAGE,
    URL_LOGIN_PAGE,
    DOWNLOAD_DIR,
    COLUMN_NAME_MAPPING
)

LOGLEVEL = os.environ.get("LOGLEVEL", "DEBUG").upper()
logger = logging.getLogger(__name__)
logger.setLevel(LOGLEVEL)


def _get_browser_name_for_os():
    """Determine the best browser for the current OS."""
    system = platform.system().lower()
    if system == "darwin":  # macOS
        return "webkit"
    else:  # Linux, Windows, and others
        return "chromium"


def _ensure_browser_installed():
    """Ensure the required Playwright browser is installed.

    This command is idempotent - if the browser is already installed,
    it will skip the download and exit quickly.
    """
    browser_name = _get_browser_name_for_os()

    try:
        logger.info(f"Ensuring Playwright {browser_name} browser is installed...")
        # Run playwright install - this is idempotent and safe to run multiple times
        subprocess.run(
            [sys.executable, "-m", "playwright", "install", browser_name],
            capture_output=True,
            text=True,
            check=True,
            timeout=300  # 5 minutes max for download
        )
        logger.info(f"Playwright {browser_name} browser is ready.")
    except subprocess.TimeoutExpired:
        logger.error(f"Browser installation timed out. Please run manually: playwright install {browser_name}")
        raise
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to install browser: {e.stderr}")
        logger.error(f"Please run manually: playwright install {browser_name}")
        raise
    except FileNotFoundError:
        logger.error("Playwright not found. Please ensure it's installed: pip install playwright")
        raise
    except Exception as e:
        logger.error(f"Unexpected error installing browser: {e}")
        raise


class BCHydroApiBrowser:
    def __init__(
        self, username: str, password: str, browser_exec_path: Optional[str] = None, headless_browser: bool = True
    ):
        """BC Hydro data accessor through headless browser.

        *Note* that username and password are stored in the object.
        Be sure you trust the environment where this object is created and instance is executed.

        Reduce your risks by creating a read-only BCHydro account following
        https://github.com/emcniece/bchydro?tab=readme-ov-file#-read-only-account-sharing.

        Args:
            username (str): BCHydro username
            password (str): BCHydro password
            browser_exec_path (str): Path to browser executable. Useful if browser is not in PATH.

        """
        self.page = None
        self.browser = None
        self.playwright = None
        self._username = username
        self._password = password
        self.browser_exec_path = browser_exec_path
        self.headless_browser = headless_browser
        self._browser_installed = False

    async def _sign_in(self, username, password, browser_exec_path):
        # Ensure browser is installed (only runs once)
        if not self._browser_installed:
            _ensure_browser_installed()
            self._browser_installed = True

        # Start playwright
        self.playwright = await async_playwright().start()

        # Get the appropriate browser for this OS
        browser_name = _get_browser_name_for_os()
        browser_type = getattr(self.playwright, browser_name)

        # Launch browser with appropriate type for OS
        launch_options = {
            "headless": self.headless_browser,
        }
        if browser_exec_path:
            launch_options["executable_path"] = browser_exec_path

        logger.debug(f"Launching {browser_name} browser...")
        self.browser = await browser_type.launch(**launch_options)

        # Create a new browser context
        context = await self.browser.new_context()

        # Create a new page
        page = await context.new_page()

        # Set up download behavior
        download_path = os.path.abspath(DOWNLOAD_DIR)
        if os.path.exists(DOWNLOAD_DIR):
            existing_files = os.listdir(DOWNLOAD_DIR)
            for file in existing_files:
                logger.debug(f"Removing existing download file: {file}")
                os.remove(os.path.join(DOWNLOAD_DIR, file))

        os.makedirs(download_path, exist_ok=True)

        logger.debug("Populating login form...")
        await page.goto(URL_LOGIN_PAGE)

        # Fill form fields using fill() method
        await page.fill("#email", username)
        await page.fill("#password", password)

        logger.debug("Clicking login button...")
        async with page.expect_navigation():
            await page.click("#submit-button")

        logger.info("Login successful.")
        return page

    def _authenticated(func):
        async def wrapper(self, *args, **kwargs):
            if self.page is None:
                self.page = await self._sign_in(
                    self._username, self._password, self.browser_exec_path
                )
            return await func(self, *args, **kwargs)

        return wrapper

    def __parse_consumption_table(self, csv_content: str) -> list:
        """Parse CSV content and return a list of dicts with simplified column names.
        Args:
            csv_content (str): Raw CSV content as a string
        Returns:
            list: List of dictionaries, each representing a row with simplified machine-readable column names as keys
        """
        lines = csv_content.strip().split('\n')
        csv_reader = csv.DictReader(lines)

        # Convert each row to a dict with simplified column names
        result = [{COLUMN_NAME_MAPPING.get(k, k): v for k, v in row.items()} for row in csv_reader]

        readings = []
        for reading in result:
            reading_obj = BCHydroReading(
                account_holder=reading["account_holder"],
                account_number=reading["account_number"],
                meter_number=reading["meter_number"],
                interval_start_datetime=datetime.strptime(reading["interval_start_datetime"], "%Y-%m-%d %H:%M"),
                net_consumption_kwh=float(reading["net_consumption_kwh"]),
                service_address=reading["service_address"],
                city=reading["city"]
            )
            readings.append(reading_obj)

        return readings
    
    def __buildURL(
        #https://app.bchydro.com/datadownload/web/download-centre.html?default=true&downloadType=CNSMPHSTRY&downloadFormat=CSVFILE&downloadInterval=DAILY&fromDate=Jan%209,%202026&toDate=Mar%2010,%202026
        self,
        default: bool = DOWNLOAD_CENTER_PARAMS.get("default"),
        download_type: str = DOWNLOAD_CENTER_PARAMS.get("downloadType"),
        download_format: str = DOWNLOAD_CENTER_PARAMS.get("downloadFormat"),
        download_interval: str = DOWNLOAD_CENTER_PARAMS.get("downloadInterval"),
        from_date: str = datetime.today() - timedelta(days=30),
        to_date: str = datetime.today()
    ):
        params = {
            "default": default,
            "downloadType": download_type,
            "downloadFormat": download_format,
            "downloadInterval": download_interval,
            "fromDate": from_date.strftime("%b %d, %Y"),
            "toDate": to_date.strftime("%b %d, %Y")
        }
        query_string = urllib.parse.urlencode(params)
        logger.debug(f"Built full query URL: {URL_DOWNLOAD_CENTER_PAGE}?{query_string}")
        return f"{URL_DOWNLOAD_CENTER_PAGE}?{query_string}"
    
    @_authenticated
    async def get_usage_table(self):
        download_center_url = self.__buildURL(from_date=datetime.today() - timedelta(days=30), to_date=datetime.today())
        logger.debug(f"Navigating to download center URL: {download_center_url}")

        await self.page.goto(download_center_url)
        await self.page.wait_for_selector("#btnExportData")
        logger.debug("Clicking export data button...")

        # Use Playwright's download handler
        async with self.page.expect_download() as download_info:
            await self.page.locator("#btnExportData").click()

        download = await download_info.value
        logger.debug(f"Download started: {download.suggested_filename}")

        # Save the download to the DOWNLOAD_DIR
        download_path = os.path.abspath(DOWNLOAD_DIR)
        os.makedirs(download_path, exist_ok=True)
        file_path = os.path.join(download_path, download.suggested_filename)
        await download.save_as(file_path)
        logger.debug(f"Download complete: {file_path}")

        # Read and parse the CSV file
        with open(file_path, "r") as f:
            csv_content = f.read()
        table = self.__parse_consumption_table(csv_content)

        return table

    async def close(self):
        """Close the browser and playwright resources."""
        if self.browser:
            await self.browser.close()
            logger.debug("Browser closed.")
        if self.playwright:
            await self.playwright.stop()
            logger.debug("Playwright stopped.")



class BCHydroReading:
    def __init__(
            self,
            account_holder: str,
            account_number: str,
            meter_number: str,
            interval_start_datetime: datetime,
            net_consumption_kwh: float,
            service_address: str,
            city: str
        ):

        self.account_holder = account_holder
        self.account_number = account_number
        self.meter_number = meter_number
        self.interval_start_datetime = interval_start_datetime
        self.net_consumption_kwh = net_consumption_kwh
        self.service_address = service_address
        self.city = city
