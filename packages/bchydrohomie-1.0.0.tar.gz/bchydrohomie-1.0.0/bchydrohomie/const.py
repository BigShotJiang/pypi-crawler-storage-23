"""BCHydro Constants"""

URL_LOGIN_PAGE = "https://app.bchydro.com/BCHCustomerPortal/web/login.html"

URL_DOWNLOAD_CENTER_PAGE = "https://app.bchydro.com/datadownload/web/download-centre.html" 
#https://app.bchydro.com/datadownload/web/download-centre.html?default=true&downloadType=CNSMPHSTRY&downloadFormat=CSVFILE&downloadInterval=DAILY&fromDate=Jan%209,%202026&toDate=Mar%2010,%202026

DOWNLOAD_CENTER_PARAMS = {
    "default": True,
    "downloadType": "CNSMPHSTRY",
    "downloadFormat": "CSVFILE",
    "downloadInterval": "HOURLY"
}

DOWNLOAD_DIR = "./downloads"

# Mapping from BC Hydro CSV column names to machine-readable format
COLUMN_NAME_MAPPING = {
    "Account Holder": "account_holder",
    "Account Number": "account_number",
    "Meter Number": "meter_number",
    "Interval Start Date/Time": "interval_start_datetime",
    "Time of Day Period": "time_of_day_period",
    "Inflow (kWh)": "inflow_kwh",
    "Outflow (kWh)": "outflow_kwh",
    "Net Consumption (kWh)": "net_consumption_kwh",
    "Peak Demand (kW)": "peak_demand_kw",
    "Power Factor (%)": "power_factor_percent",
    "Estimated Usage": "estimated_usage",
    "Service Address": "service_address",
    "City": "city",
}
