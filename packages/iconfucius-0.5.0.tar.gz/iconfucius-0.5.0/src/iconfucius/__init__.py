"""IConfucius | Wisdom for Bitcoin Markets"""

__version__ = "0.5.0"
