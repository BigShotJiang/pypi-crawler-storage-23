# Pattern Syntax

emend's `find`, `replace`, and `search` commands use a pattern language based on Python syntax extended with **metavariables**.

## Metavariables

A metavariable is a placeholder that matches any single expression or statement. They are written as `$NAME` where `NAME` is an uppercase identifier.

```bash
# $X matches any single expression
emend find 'print($X)' src/

# Multiple metavariables
emend find 'assertEqual($A, $B)' tests/
```

### Metavariable rules

- `$X` -- matches any single expression node
- `$_` -- wildcard that matches any expression and is not captured
- `$...ARGS` -- matches zero or more arguments in a call (variadic)

## Type constraints

Constrain what a metavariable can match by adding a type suffix:

```bash
# Match only when argument is a string literal
emend find 'print($X:str)' src/

# Match only when argument is an integer literal
emend find 'range($X:int)' src/
```

### Negated type constraints

Prefix the type with `!` to match anything *except* that type:

```bash
# Match range() calls with non-integer arguments
emend find 'range($X:!int)' src/

# Match addition where left side is NOT a function call
emend find '$A:!call + $B' src/
```

## Basic patterns

### Function calls

```bash
# Match any call to print() with one argument
emend find 'print($X)' src/

# Match any call to print() with two arguments
emend find 'print($A, $B)' src/

# Match any call to open() regardless of arguments
emend find 'open($...)' src/
```

### Assignments

```bash
# Match any simple assignment
emend find '$NAME = $VALUE' src/

# Match augmented assignment
emend find '$NAME += $VALUE' src/
```

### Attribute access

```bash
emend find '$OBJ.method($X)' src/
emend find 'self.$ATTR' src/
```

### Return statements

```bash
emend find 'return $X' src/
emend find 'return None' src/
```

### Raise statements

```bash
emend find 'raise $EXC($MSG)' src/
emend find 'raise ValueError($X)' src/
```

### Comparisons

```bash
emend find '$A == $B' src/
emend find '$X is None' src/
emend find '$X is not None' src/
```

## Compound statement patterns

Match compound statements by their header. The body is unconstrained unless explicitly specified.

### If statements

```bash
# Match any if statement with a specific condition pattern
emend find 'if $COND:' src/

# Match if-checks for None
emend find 'if $X is None:' src/
```

### For loops

```bash
# Match any for loop
emend find 'for $VAR in $ITER:' src/

# Match enumerate loops
emend find 'for $I, $V in enumerate($X):' src/
```

### While loops

```bash
emend find 'while $COND:' src/
emend find 'while True:' src/
```

### With statements

```bash
# With context and alias
emend find 'with $CTX as $VAR:' src/

# With just context (no alias)
emend find 'with $CTX:' src/
```

### Try/except statements

```bash
# Match any try block
emend find 'try:' src/

# Match except clauses
emend find 'except $EXC:' src/
emend find 'except $EXC as $VAR:' src/
```

### Async compound statements

```bash
# Match async for loops
emend find 'async for $VAR in $ITER:' src/

# Match async with statements
emend find 'async with $CTX as $VAR:' src/
emend find 'async with $CTX:' src/
```

## Decorator patterns

Match decorated function definitions using multi-line patterns:

```bash
# Find functions with any decorator
emend find '@$DEC\ndef $FUNC($...ARGS):' src/

# Find functions with a specific decorator
emend find '@property\ndef $FUNC($...ARGS):' src/

# Multiple decorators
emend find '@$DEC1\n@$DEC2\ndef $FUNC($...ARGS):' src/

# Async decorated functions
emend find '@$DEC\nasync def $FUNC($...ARGS):' src/
```

## Lambda patterns

Match lambda expressions:

```bash
# Match single-argument lambdas
emend find 'lambda $X: $EXPR' src/

# Match multi-argument lambdas
emend find 'lambda $X, $Y: $EXPR' src/

# Match lambdas with star args
emend find 'lambda *$ARGS: $EXPR' src/

# Match lambdas that return a specific pattern
emend find 'lambda $X: $X + 1' src/
```

## Star expression patterns

Match star and double-star unpacking expressions:

```bash
# Match star unpacking
emend find '*$X' src/

# Match double-star dict unpacking
emend find '**$X' src/

# Match function calls with star/double-star args
emend find 'func(*$ARGS, **$KWARGS)' src/
```

## Dict patterns

Match dictionary literals with specific keys:

```bash
# Exact dict match (all keys must be present, no extras)
emend find "{'name': \$NAME, 'age': \$AGE}" src/

# Partial dict match (extra keys allowed)
emend find "{'type': 'user', ...}" src/
```

## Chained comparison patterns

Match chained comparisons:

```bash
# Two-operator chain
emend find '$A < $B < $C' src/

# Mixed operators
emend find '$A <= $B < $C' src/
```

## Walrus operator patterns

Match walrus operator (`:=`) in various contexts:

```bash
# Walrus in if conditions
emend find 'if ($VAR := $EXPR):' src/

# Walrus in comprehension filters
emend find '[$X for $VAR in $ITER if ($TARGET := $EXPR)]' src/
```

## Replacements

In `replace`, the replacement string can reference captured metavariables:

```bash
# Replace print with logger.info
emend replace 'print($X)' 'logger.info($X)' src/ --apply

# Swap arguments
emend replace 'assertEqual($A, $B)' 'assertEqual($B, $A)' tests/ --apply

# Convert assert style
emend replace 'assertEqual($A, $B)' 'assert $A == $B' tests/ --apply

# Add a wrapper
emend replace 'open($PATH)' 'open($PATH, encoding="utf-8")' src/ --apply
```

## Scope constraints

### `--in SCOPE`

Restrict matches to within a named symbol:

```bash
# Only match inside the process_request function
emend find 'print($X)' app.py --in process_request

# Only match inside MyClass.method
emend find 'self.$ATTR' app.py --in MyClass.method
```

### `--where PATTERN` (alias for `--inside`)

Scope filtering using a pattern. Alias for `--inside` with pattern support:

```bash
# Only match inside async functions named fetch_*
emend find 'await $X' src/ --where 'async def fetch_*'
```

### `--scope-local`

Only match names that are locally defined (excludes imports):

```bash
# Find local variables named 'config', not imported ones
emend find 'config' src/ --scope-local
```

### `--inside STRUCTURE`

Only match inside a particular kind of block. Accepts both keywords and patterns:

| Structure | Matches |
|---|---|
| `def` | Any function definition |
| `class` | Any class definition |
| `for` | Any for loop |
| `while` | Any while loop |
| `if` | Any if/elif/else block |
| `try` | Any try/except block |
| `with` | Any with statement |

```bash
# Only inside functions (keyword)
emend find 'print($X)' src/ --inside def

# Only inside try blocks (keyword)
emend find 'raise $E' src/ --inside try

# Only inside functions matching a name pattern
emend find 'print($X)' src/ --inside 'def test_*'

# Only inside async functions
emend find 'await $X' src/ --inside 'async def fetch_*'
```

### `--not-inside STRUCTURE`

Only match outside a particular kind of block. Also accepts patterns:

```bash
# Not inside class bodies (keyword)
emend replace '$X = $Y' '$X: int = $Y' src/ --not-inside class --apply

# Not inside try blocks (pattern)
emend find 'open($PATH)' src/ --not-inside 'try:'

# Not inside test functions (name pattern)
emend find 'print($X)' src/ --not-inside 'def test_*'
```

### `--imported-from MODULE`

Only match when the root name in the pattern is imported from a specific module:

```bash
# Match json.loads() only when json is actually imported from the json module
emend find 'json.loads($X)' src/ --imported-from json

# Match datetime usage only when from the datetime module
emend find 'datetime.now()' src/ --imported-from datetime
```

## Multi-file search

The `PATH` argument accepts:

- A single file: `src/api.py`
- A glob: `src/**/*.py`
- A directory (searches all `.py` files recursively): `src/`

```bash
# Search all test files
emend find 'assertEqual($A, $B)' tests/

# Search with glob
emend find 'print($X)' 'src/**/*.py'
```

## JSON output

Use `--json` to get structured output including captured metavariables:

```bash
emend find 'raise $EXC($MSG)' src/ --json
```

Output:
```json
{
  "count": 3,
  "matches": [
    {
      "file": "src/api.py",
      "line": 42,
      "code": "raise ValueError(\"bad input\")",
      "captures": {
        "EXC": "ValueError",
        "MSG": "\"bad input\""
      }
    }
  ]
}
```

## Limitations

- Patterns match at the expression or statement level; they cannot span multiple statements
- `$X:stmt` type constraint is not yet fully implemented (see TODOS.md for details)
