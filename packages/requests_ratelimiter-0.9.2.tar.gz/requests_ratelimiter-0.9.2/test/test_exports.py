# ruff: noqa: F403
# Test pyrate-limiter classes exported from requests_ratelimiter namespace (only possible in module scope)
from requests_ratelimiter import *


# Stub for pytest collection
def test_exports():
    pass
