from setuptools import setup, find_packages

setup(
    name="nl-master-tool",
    version="8.5.0",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "colorama",
        "requests",
    ],
    entry_points={
        "console_scripts": [
            "nl-master=nl_master_tool.main:main",
        ],
    },
)
