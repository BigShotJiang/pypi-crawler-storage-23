# NL MASTER GENERATOR v8.5

Professional networking tool for IP generation, country-based CIDR extraction, and live host discovery.

## Features
- **Neon UI**: Multi-color RGB Banner.
- **ipverse Integration**: Fetch real-time IP blocks.
- **Deep Scan**: Global IP generation.
- **Fast Mapping**: Threaded ping verification.

## Installation
```bash
pip install nl-master-tool