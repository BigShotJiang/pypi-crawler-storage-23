// Compile with: gcc -fvisibility=hidden -shared -O3 -march=native -fPIC -o libsocketcantcp.so socketcan_tcp.c
#define _FUNC_VISIBILITY __attribute__((visibility("default")))
#ifdef __cplusplus
#define FUNCTION_EXPORT _FUNC_VISIBILITY extern "C"
#else
#define FUNCTION_EXPORT _FUNC_VISIBILITY
#endif

#include <pthread.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include "sct_error.h"

#include "sct_sockets.h"
#include "sct_write.h"
#include "sct_poll.h"
#include "sct_source_hash.h"
