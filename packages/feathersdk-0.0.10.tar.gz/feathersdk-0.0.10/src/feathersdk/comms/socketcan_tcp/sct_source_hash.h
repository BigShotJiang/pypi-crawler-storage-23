// DON'T MODIFY. Stores hash of current source code, auto-added on recompile
static const char* sct_source_hash_str __attribute__((used)) = "__FEATHER_SOURCE_HASH__1329033519570511733599200469283129659564__END_FEATHER_SOURCE_HASH__";
