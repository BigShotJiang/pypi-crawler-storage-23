

# Suppress all logging from canopen. TODO: Filter the messages to keep the ones we want to worry about.
# Note: there are no CRITICAL logging messages in canopen 2.4.1, so this should disable all sdo.client/server messages.
import logging
logging.getLogger("canopen.sdo.client").setLevel(logging.CRITICAL)
logging.getLogger("canopen.sdo.server").setLevel(logging.CRITICAL)