

class Motor:
    """Base class for all motors."""
    def __init__(self) -> None:
        pass