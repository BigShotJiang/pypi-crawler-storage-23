"""RH56DFTP Hand module for Inspire finger joints."""

from .rh56dftp_hand import InspireFingerJoint, create_finger_joints_from_config

__all__ = ['InspireFingerJoint', 'create_finger_joints_from_config']

