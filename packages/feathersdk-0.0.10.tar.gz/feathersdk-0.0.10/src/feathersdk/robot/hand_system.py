from .steppable_system import SteppableSystem
from .motors.motors_manager import MotorsManager, MotorMap


class HandSystem(SteppableSystem):
    def __init__(self, motors_manager: MotorsManager, motors_map: MotorMap, name: str):
        """Initialize HandSystem.
        
        Args:
            motors_manager: MotorsManager instance for managing motors.
            motors_map: Map of motor names to motor instances (for compatibility with existing systems).
            name: Name of the hand system.
        """
        self.motors_manager = motors_manager
        self.motors_manager.add_motors(motors_map, family_name=name)
        self.motors = motors_map
