def change_in_pos(v0: float, a0: float, jerk: float, t1: float, t2: float) -> float:
    """jerk = 0 if constant acceleration."""
    return v0 * (t2 - t1) + a0 * (t2 - t1)**2 / 2 + jerk * (t2 - t1)**3 / 6

def change_in_vel(a0: float, jerk: float, t1: float, t2: float) -> float:
    return a0 * (t2 - t1) + jerk * (t2 - t1)**2 / 2