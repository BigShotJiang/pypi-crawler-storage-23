import time
from feathersdk.utils.common import timediff, currtime

class PerfLogger:
    def __init__(self):
        # Use perf_counter for performance measurements - higher precision and not affected by system clock adjustments
        self.last_time = currtime()
    
    def log(self, msg=""):
        # Use perf_counter for performance measurements - higher precision and not affected by system clock adjustments
        delta = timediff(self.last_time)
        print(f"{msg} Δt: {delta:.6f}s")
        self.last_time = currtime()