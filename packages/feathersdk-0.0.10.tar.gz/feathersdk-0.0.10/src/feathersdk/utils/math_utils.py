import math

def degrees_to_radians(degrees: float) -> float:
    return degrees * math.pi / 180.0

def radians_to_degrees(radians: float) -> float:
    return radians * 180.0 / math.pi