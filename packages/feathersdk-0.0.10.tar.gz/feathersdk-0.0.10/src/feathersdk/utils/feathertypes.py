import sys
from typing import Union, TypedDict, Literal, Optional, Tuple, List, Dict, Any, TypeVar, Callable, Generic, TextIO, \
    Type, TYPE_CHECKING, Sequence, NamedTuple, Iterable, get_origin as get_type_origin, get_args as get_type_args
from typing_extensions import Self, ParamSpec, deprecated


def get_union_types(union: type) -> list[type]:
    """Get the types of a union.
    
    Normal isinstance() check doesn't work for unions in Python 3.9 and earlier, so we need to use this function.
    """
    return get_type_args(union) if sys.version_info < (3, 10) else union


# Explicit re-exports for mypy
__all__ = ["Any", "Callable", "Dict", "Generic", "Iterable", "List", "Literal", "NamedTuple", "Optional", "ParamSpec", 
           "Self", "Sequence", "TYPE_CHECKING", "TextIO", "Tuple", "Type", "TypedDict", "TypeVar", "Union", 
           "get_type_args", "get_type_origin", "deprecated", "get_union_types"]
