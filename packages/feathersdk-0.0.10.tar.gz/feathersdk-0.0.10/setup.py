from setuptools import setup

# All package metadata/configuration lives in `pyproject.toml` (PEP 621 + tool.setuptools).
# This file is kept only for compatibility with legacy tooling.
if __name__ == "__main__":
    setup()
