# Feather Python SDK Library

[![License: Apache 2.0](https://img.shields.io/badge/license-Apache%20License%202.0-blue)](https://www.apache.org/licenses/LICENSE-2.0)
[![PyPI](https://img.shields.io/pypi/v/feathersdk)](https://pypi.org/project/feathersdk/)
[![Supported Versions](https://img.shields.io/pypi/pyversions/feathersdk.svg)](https://pypi.org/project/feathersdk/)

## Installation

You can install with:

```bash
pip install feathersdk
```
