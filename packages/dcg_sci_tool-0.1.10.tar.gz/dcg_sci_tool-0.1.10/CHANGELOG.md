# Changelog

## [0.1.10] - 2026-03-04

### Added
- 新增 `get_reactants_ad_config` 方法

### Changed
- 修改detect_CO_coordinating_to_Pd函数，使之同时分析与Au配位的CO分子，并更名为detect_CO_coordinating_to_PdAu
- 修改create_filtered_structure函数，使入参包含old_indexes：要获得新序号的原始结构中原子的索引的列表，返回参数包含new_indexes：旧索引old_indexes对应的新的原子索引列表，并修改调用函数get_traj_focusing_reaction_site和get_traj_focusing_reaction_site_batches

## [0.1.9] - 2026-03-02

### Added
- 新增 `get_traj_focusing_reaction_site` 方法
- 新增 `parse_nebTraj_file_name` 方法
- 新增 `find_matching_files` 方法
- 新增 `get_traj_focusing_reaction_site_batches` 方法

### Changed
- 调整create_filtered_structure方法参数列表排序
- 建立specific文件夹，用于存放粒度较大的代码，并相应调整__init__.py文件
- __init__.py文件格式规范化



## [0.1.8] - 2026-03-02

### Added
- 新增 `get_pdau_cluster_center` 方法
- 新增 `indexes2expression` 方法
- 新增 `rotate_v1_around_p_to_v2` 方法
- 新增 `translate_structure_center` 方法
- 新增 `create_filtered_structure` 方法
- 新增 `get_struct_focusing_reaction_site` 方法

### Changed
- 将get_reaction_local_structure改名为get_reaction_local_atoms_list
- 将identify_gas_molecules_to_delete函数改名为detect_gas_molecules_for_deletion
- 将API html、deprecated文件夹（放一些可能有用的代码）放至.gitignore文件中

## [0.1.7] - 2026-03-01

### Added
- 新增 `identify_gas_molecules_to_delete` 方法
- 新增 `get_reaction_local_structure` 方法

### Changed
- 规范化各个库函数的解释文本

## [0.1.6] - 2026-03-01

### Added
- 新增 `detect_single_adsorbed_O` 方法


## [0.1.5] - 2026-02-28

### Added
- 新增 `detect_CO_coordinating_to_Pd` 方法

### Changed
- 恢复各函数返回分子元组的功能


## [0.1.4] - 2026-02-28

### Changed
- 删除相关函数冗余入参frame

## [0.1.3] - 2026-02-25

### Fixed
- 修复导出问题

## [0.1.2] - 2026-02-25

### Added
- 新增 `detect_O2_molecules` 方法
- 新增 `detect_CO_CO2_molecules` 方法

## [0.1.1] - 2026-02-24

### Added
- 新增 `extract_atom_types` 方法
- 新增 `sum_to_n` 方法