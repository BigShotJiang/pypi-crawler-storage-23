import os
import re
from typing import List

def find_matching_files(directory: str, pattern: str = None) -> List[str]:
    """
    查找目录下所有满足正则表达式的文件名（不搜索子目录）
    
    参数:
    ----------
    directory : str
        要搜索的目录路径
    pattern : str, 可选
        正则表达式模式，如果为None则使用默认模式
        
    返回:
    -------
    List[str]
        匹配的文件名列表
    """
    if pattern is None:
        # 您提供的正则表达式模式
        print("No pattern provided")
        return []
    
    # 编译正则表达式
    regex = re.compile(pattern)
    
    matching_files = []
    
    # 只搜索当前目录，不使用os.walk
    try:
        # 获取指定目录中的所有文件和子目录
        items = os.listdir(directory)
        
        for item in items:
            # 构建完整路径
            item_path = os.path.join(directory, item)
            
            # 检查是否是文件（不是目录）
            if os.path.isfile(item_path):
                # 检查文件名是否匹配正则表达式

                # 只包含纯净的文件名，不包含路径
                if regex.fullmatch(item):
                    matching_files.append(item)
    except FileNotFoundError:
        print(f"目录不存在: {directory}")
    except PermissionError:
        print(f"没有权限访问目录: {directory}")
    except Exception as e:
        print(f"读取目录时发生错误: {e}")
    
    return matching_files