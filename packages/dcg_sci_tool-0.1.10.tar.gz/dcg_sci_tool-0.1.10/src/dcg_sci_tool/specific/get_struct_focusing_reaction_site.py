from dcg_sci_tool import *
import numpy as np

def get_struct_focusing_reaction_site(data, type_names_order, c_index, o_index, cutoff=6.0, target_vector=None, new_cell=None):
    """
    输入原始MD-neb结构文件，输出经过处理后的结构文件，将反应局部结构聚焦到小晶胞中，
    并使ovito观察视线方向（Y轴）经过反应区域和团簇中心
    输出聚焦后的结构文件（ASE ATOMS类）
    
    参数:
    ----------
    data : ovito.data.DataCollection
       包含原子结构和相关数据的Ovito DataCollection对象
    type_names_order : list of str
       原子类型名称的顺序列表
    c_index : int
       反应物CO的C原子的索引
    o_index : int
       反应物O原子的索引
    cutoff : float
       截止距离，单位为Å，默认为6.0
    target_vector : np.ndarray 或 list/tuple
       目标向量，形状为(3,)，旋转后当前向量将与此向量同向
    new_cell : np.ndarray 或 list/tuple
       新的晶胞尺寸，形状为(3,)，如 [a, b, c]
    
    返回:
    ----------
       返回旋转并平移后的ASE Atoms对象
    rotated_translated_struct : Atoms
       旋转并平移后的ASE Atoms对象
    """
    # 获取PdAu簇中心
    cluster_center = get_pdau_cluster_center(data, type_names_order)
    # 获取反应局部结构的原子索引
    keep_indexes = get_reaction_local_atoms_list(data, type_names_order, c_index, o_index, cutoff)
    # 以目标C和目标O连线中点为旋转向量的终点
    vector_endpoint = (data.particles.positions[o_index] + data.particles.positions[c_index]) / 2


    # 创建新的结构对象，包含所有原子但只保留反应局部结构的原子类型
    filtered_struct = create_filtered_structure(data, type_names_order,keep_indexes)
    # 将结构旋转，使得目标向量与-Y轴同向
    rotated_struct = rotate_v1_around_p_to_v2(
        atoms=filtered_struct,
        rotation_center=cluster_center,
        vector_endpoint=vector_endpoint,  # Use first atom position as vector endpoint
        target_vector=target_vector
    )

    # 将旋转后的结构平移，使得簇中心位于新晶胞的中心
    rotated_struct.set_cell(new_cell)
    rotated_struct.set_pbc([True, True, True])
    rotated_translated_struct = translate_structure_center(rotated_struct, np.array(new_cell)/2)


    return rotated_translated_struct