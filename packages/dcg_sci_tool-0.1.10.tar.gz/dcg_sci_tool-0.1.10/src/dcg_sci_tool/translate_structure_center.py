import numpy as np
from ase import Atoms

def translate_structure_center(atoms, target_center):
    """
    将输入的ASE Atoms对象整体平移，使其中心平移到目标中心点
    
    参数:
    ----------
    atoms : Atoms
        输入的ASE原子结构对象
    target_center : np.ndarray 或 list/tuple
        目标中心点坐标，形状为(3,)，如 [x, y, z]
        
    返回:
    -------
    Atoms
        平移后的新Atoms对象
        
    异常:
    ------
    ValueError: 如果输入参数无效
    """
    
    # 输入验证
    if not isinstance(atoms, Atoms):
        raise ValueError(f"第一个参数必须是ASE Atoms对象，但得到类型: {type(atoms)}")
    
    if len(atoms) == 0:
        raise ValueError("输入的Atoms对象不包含任何原子")
    
    # 将目标中心转换为numpy数组
    target_center = np.asarray(target_center, dtype=float)
    
    if target_center.shape != (3,):
        raise ValueError(f"目标中心必须是3维坐标，但得到 shape={target_center.shape}")
    
    # 计算当前结构的中心

    current_center = np.mean(atoms.positions, axis=0)

    # 计算平移向量
    translation_vector = target_center - current_center
    
    # 创建原子的副本以避免修改原始对象
    translated_atoms = atoms.copy()
    
    # 应用平移
    translated_atoms.translate(translation_vector)
    
    return translated_atoms