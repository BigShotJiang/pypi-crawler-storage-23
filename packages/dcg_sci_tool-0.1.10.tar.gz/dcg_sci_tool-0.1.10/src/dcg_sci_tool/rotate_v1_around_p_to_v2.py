import numpy as np

def rotate_v1_around_p_to_v2(atoms, rotation_center, vector_endpoint, target_vector):
    """
    旋转结构中的所有原子，使从旋转中心到指定终点的向量与目标向量同向，这个函数会改变入参atoms的状态
    
    Args:

        atoms (Atoms): 包含原子结构的ASE Atoms对象

        rotation_center (np.ndarray 或 list/tuple): 
            旋转中心坐标，形状为(3,)，如 [x, y, z]

        vector_endpoint (np.ndarray 或 list/tuple): 
            要旋转的向量的终点坐标，形状为(3,)

        target_vector (np.ndarray 或 list/tuple): 
            目标向量，形状为(3,)，旋转后当前向量将与此向量同向

        
    Returns:

        atoms : Atoms
            旋转后的原子结构
    """
    
    
    # 将输入转换为numpy数组
    P = np.asarray(rotation_center, dtype=float)
    V1_end = np.asarray(vector_endpoint, dtype=float)
    V2 = np.asarray(target_vector, dtype=float)
    
    print(f"输入参数:")
    print(f"  旋转中心P: {P}")
    print(f"  向量终点V1_end: {V1_end}")
    print(f"  目标向量V2: {V2}")
    
    # 2. 计算要旋转的向量（从旋转中心到终点）
    V1 = V1_end - P
    print(f"\n要旋转的向量V1 (从P到V1_end): {V1}")
    
    # 3. 归一化向量
    v1_norm = np.linalg.norm(V1)
    v2_norm = np.linalg.norm(V2)
    
    if v1_norm < 1e-10:
        raise ValueError("旋转向量长度为零，无法计算旋转")
    if v2_norm < 1e-10:
        raise ValueError("目标向量长度为零，无效的目标方向")
    
    v1_normalized = V1 / v1_norm
    v2_normalized = V2 / v2_norm
    
    print(f"  归一化的V1: {v1_normalized}")
    print(f"  归一化的V2: {v2_normalized}")
    
    # 4. 计算旋转矩阵（使用Rodrigues旋转公式）
    # 计算点积
    dot_product = np.dot(v1_normalized, v2_normalized)
    
    if abs(dot_product - 1.0) < 1e-10:
        print("向量V1已经与V2同向，无需旋转")
        return atoms
    elif abs(dot_product + 1.0) < 1e-10:
        # 方向相反，旋转180度
        # 找到垂直轴
        if abs(v1_normalized[0]) < 0.9:
            axis = np.cross(v1_normalized, np.array([1.0, 0.0, 0.0]))
        else:
            axis = np.cross(v1_normalized, np.array([0.0, 1.0, 0.0]))
        axis = axis / np.linalg.norm(axis)
        angle = np.pi
    else:
        # 计算旋转轴和角度
        axis = np.cross(v1_normalized, v2_normalized)
        axis_norm = np.linalg.norm(axis)
        axis = axis / axis_norm
        angle = np.arccos(np.clip(dot_product, -1.0, 1.0))
    
    print(f"\n旋转信息:")
    print(f"  旋转轴: {axis}")
    print(f"  旋转角度: {np.degrees(angle):.2f}°")
    
    # 5. 创建旋转矩阵
    # 使用Rodrigues公式
    K = np.array([[0, -axis[2], axis[1]],
                  [axis[2], 0, -axis[0]],
                  [-axis[1], axis[0], 0]])
    
    rotation_matrix = np.eye(3) + np.sin(angle) * K + (1 - np.cos(angle)) * np.dot(K, K)
    
    print(f"  旋转矩阵:\n{rotation_matrix}")
    
    # 6. 创建绕指定中心点旋转的4x4变换矩阵
    def create_rotation_around_point(center, R):
        """创建绕点旋转的4x4变换矩阵"""
        transform = np.eye(4)
        transform[0:3, 0:3] = R
        # 平移部分：c - Rc
        rc = np.dot(R, center)
        transform[0:3, 3] = center - rc
        return transform
    
    # 创建旋转变换矩阵
    transform_matrix = create_rotation_around_point(P, rotation_matrix)
    
    # 7. 旋转结构中的所有原子
    print(f"\n应用旋转到 {len(atoms)} 个原子...")
    for i in range(len(atoms)):
        pos = atoms[i].position
        # 转换为齐次坐标
        pos_homogeneous = np.append(pos, 1.0)
        # 应用变换
        new_pos_homogeneous = np.dot(transform_matrix, pos_homogeneous)
        # 更新原子位置
        atoms[i].position = new_pos_homogeneous[0:3]
    
    return atoms