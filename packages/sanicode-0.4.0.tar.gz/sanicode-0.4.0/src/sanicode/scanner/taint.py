"""Intra- and inter-procedural taint propagation via reaching-definitions analysis.

Walks each function body in statement order, tracking which local variables
carry tainted data from external sources. When a tainted variable reaches a
sink call without passing through a sanitizer, a :class:`TaintPath` is emitted.

The intra-procedural pass is conservative:

* Python-only tree-sitter node types (``assignment``, ``augmented_assignment``,
  ``call``, ``return_statement``, ``pattern_list``).
* No control-flow sensitivity (``if``/``else``, loops, exceptions are ignored;
  taint set is the union across all paths).

The inter-procedural pass uses **function summaries** to propagate taint across
call boundaries within and across files. Each function is summarized once:
which parameters can reach a sink and which parameters flow to the return value.
Call sites in handler functions then use those summaries to emit cross-function
:class:`TaintPath` records.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from tree_sitter import Node

from sanicode.scanner.data_flow import EntryPointInfo, SanitizerInfo, SinkInfo

if TYPE_CHECKING:
    from sanicode.scanner.plugin import LanguagePlugin


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass
class TaintLabel:
    """Origin of a taint -- tracks where external data entered."""

    source_kind: str  # "http_handler", "env_var", "stdin", etc.
    source_name: str  # e.g. "request.args.get"
    file: Path
    line: int


@dataclass
class TaintPath:
    """A confirmed path from taint source to sink, optionally through sanitizers."""

    source: TaintLabel
    sink_name: str
    sink_kind: str
    sink_line: int
    sanitizers: list[str] = field(default_factory=list)
    is_sanitized: bool = False
    # When the path crosses a function boundary, record the intermediate call.
    via_call: str | None = None


@dataclass
class FunctionSummary:
    """Taint summary for a single function definition.

    Captures, per-parameter, whether taint arriving at that parameter can
    reach a sink and/or flows through to the return value. Used by the
    inter-procedural pass to propagate taint across call sites without
    re-analysing callee bodies.
    """

    func_name: str
    file: Path
    # param name -> list of SinkInfo reachable when that param is tainted
    tainted_params_to_sinks: dict[str, list[SinkInfo]] = field(default_factory=dict)
    # params whose taint propagates to the function's return value
    tainted_params_to_return: list[str] = field(default_factory=list)
    # True when the function itself introduces new taint (input(), environ.get, …)
    introduces_taint: bool = False


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _dotted_name(node: Node) -> str:
    """Build a dotted name from a tree-sitter node (identifier or attribute)."""
    if node.type == "identifier":
        return node.text.decode("utf-8") if node.text else ""
    if node.type == "attribute":
        obj = node.child_by_field_name("object")
        attr = node.child_by_field_name("attribute")
        if obj is None or attr is None:
            return ""
        prefix = _dotted_name(obj)
        suffix = attr.text.decode("utf-8") if attr.text else ""
        return f"{prefix}.{suffix}" if prefix else suffix
    return ""


def _identifiers_in(node: Node) -> set[str]:
    """Collect all identifier names referenced within *node* (recursive)."""
    names: set[str] = set()
    if node.type == "identifier" and node.text:
        names.add(node.text.decode("utf-8"))
    for child in node.children:
        names.update(_identifiers_in(child))
    return names


def _call_arg_identifiers(call_node: Node) -> set[str]:
    """Return identifiers used as arguments to a call node."""
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return set()
    ids: set[str] = set()
    for child in args_node.children:
        if child.type in ("(", ")", ",", "keyword_argument", "dictionary_splat", "list_splat"):
            continue
        ids.update(_identifiers_in(child))
    # Also check keyword argument values.
    for child in args_node.children:
        if child.type == "keyword_argument":
            val = child.child_by_field_name("value")
            if val is not None:
                ids.update(_identifiers_in(val))
    return ids


def _call_first_arg_identifiers(call_node: Node) -> set[str]:
    """Return identifiers in the first positional argument of a call."""
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return set()
    for child in args_node.children:
        if child.type in ("(", ")", ",", "keyword_argument", "dictionary_splat", "list_splat"):
            continue
        return _identifiers_in(child)
    return set()


def _node_line(node: Node) -> int:
    """Return the 1-based line number of a tree-sitter node."""
    return node.start_point.row + 1


# ---------------------------------------------------------------------------
# Taint state
# ---------------------------------------------------------------------------


@dataclass
class _TaintState:
    """Per-variable taint bookkeeping within a single function body."""

    # Maps variable name -> set of TaintLabels that contributed taint.
    tainted: dict[str, set[int]] = field(default_factory=dict)
    # All TaintLabel objects, indexed by integer ID for cheap set ops.
    labels: list[TaintLabel] = field(default_factory=list)
    # Variables that have been sanitized (maps var -> sanitizer names applied).
    sanitized_by: dict[str, list[str]] = field(default_factory=dict)

    def add_label(self, label: TaintLabel) -> int:
        idx = len(self.labels)
        self.labels.append(label)
        return idx

    def taint_var(self, var: str, label_ids: set[int]) -> None:
        if var not in self.tainted:
            self.tainted[var] = set()
        self.tainted[var].update(label_ids)
        # New taint assignment removes any prior sanitization.
        self.sanitized_by.pop(var, None)

    def clean_var(self, var: str, sanitizer_name: str) -> None:
        """Mark *var* as sanitized, preserving its taint labels for path reporting."""
        if var not in self.sanitized_by:
            self.sanitized_by[var] = []
        self.sanitized_by[var].append(sanitizer_name)

    def is_tainted(self, var: str) -> bool:
        return var in self.tainted and len(self.tainted[var]) > 0

    def var_is_sanitized(self, var: str) -> bool:
        return var in self.sanitized_by

    def labels_for(self, var: str) -> set[int]:
        return self.tainted.get(var, set())

    def sanitizers_for(self, var: str) -> list[str]:
        return self.sanitized_by.get(var, [])


# ---------------------------------------------------------------------------
# Core analysis
# ---------------------------------------------------------------------------


# Known taint source parameter names -- function parameters with these names
# are assumed to carry external data when the function is itself an entry point.
_TAINTED_PARAM_NAMES = frozenset({
    "request", "req", "data", "input", "body", "payload", "params",
})


class TaintAnalyzer:
    """Intra-procedural taint propagation using reaching definitions.

    Walks statement-by-statement through a function body, propagating taint
    from entry-point sources to sink calls.
    """

    def __init__(self, plugin: LanguagePlugin) -> None:
        self.plugin = plugin

    def analyze_function(
        self,
        func_node: Node,
        file_path: Path,
        entry_points: list[EntryPointInfo],
        sinks: list[SinkInfo],
        sanitizers: list[SanitizerInfo],
    ) -> list[TaintPath]:
        """Analyze taint flow within a single function body.

        Args:
            func_node: tree-sitter node for the ``function_definition``.
            file_path: Source file path.
            entry_points: Entry points detected in this file.
            sinks: Sinks detected in this file.
            sanitizers: Sanitizers detected in this file.

        Returns:
            List of confirmed taint paths from source to sink.
        """
        func_name_node = func_node.child_by_field_name("name")
        func_name = (
            func_name_node.text.decode("utf-8")
            if func_name_node and func_name_node.text
            else ""
        )

        # Build lookup sets for sinks and sanitizers within this function.
        sink_lookup = self._build_sink_lookup(sinks, func_name)
        sanitizer_lookup = self._build_sanitizer_lookup(sanitizers, func_name)

        # Build lookup for entry-point *calls* within this function.
        entry_call_lookup = self._build_entry_call_lookup(entry_points, func_name)

        state = _TaintState()

        # Seed taint from function parameters if this function is an entry point.
        self._seed_from_params(func_node, func_name, entry_points, file_path, state)

        # Walk the function body.
        body_node = func_node.child_by_field_name("body")
        if body_node is None:
            return []

        results: list[TaintPath] = []
        self._walk_block(
            body_node, file_path, state, sink_lookup, sanitizer_lookup,
            entry_call_lookup, results,
        )
        return results

    # ------------------------------------------------------------------
    # Lookup builders
    # ------------------------------------------------------------------

    @staticmethod
    def _build_sink_lookup(
        sinks: list[SinkInfo], func_name: str
    ) -> dict[int, SinkInfo]:
        """Build line -> SinkInfo map for sinks inside *func_name*."""
        return {
            s.line: s
            for s in sinks
            if s.function == func_name
        }

    @staticmethod
    def _build_sanitizer_lookup(
        sanitizers: list[SanitizerInfo], func_name: str
    ) -> dict[int, SanitizerInfo]:
        """Build line -> SanitizerInfo map for sanitizers inside *func_name*."""
        return {
            s.line: s
            for s in sanitizers
            if s.function == func_name
        }

    @staticmethod
    def _build_entry_call_lookup(
        entry_points: list[EntryPointInfo], func_name: str
    ) -> dict[int, EntryPointInfo]:
        """Build line -> EntryPointInfo for call-based entry points in *func_name*.

        These are entry points like ``os.environ.get()`` or ``input()`` that
        appear *within* the function body (as opposed to the function itself
        being an HTTP handler).
        """
        return {
            ep.line: ep
            for ep in entry_points
            if ep.function == func_name and ep.kind != "http_handler"
        }

    # ------------------------------------------------------------------
    # Parameter seeding
    # ------------------------------------------------------------------

    def _seed_from_params(
        self,
        func_node: Node,
        func_name: str,
        entry_points: list[EntryPointInfo],
        file_path: Path,
        state: _TaintState,
    ) -> None:
        """Seed taint state from function parameters when the function is an entry point."""
        # Is this function itself an entry point (e.g., HTTP handler)?
        is_entry_fn = any(
            ep.name == func_name and ep.kind == "http_handler"
            for ep in entry_points
        )
        if not is_entry_fn:
            return

        params_node = func_node.child_by_field_name("parameters")
        if params_node is None:
            return

        func_line = _node_line(func_node)
        for child in params_node.children:
            param_name = self._extract_param_name(child)
            if param_name and param_name in _TAINTED_PARAM_NAMES:
                label = TaintLabel(
                    source_kind="http_handler",
                    source_name=f"{func_name}.{param_name}",
                    file=file_path,
                    line=func_line,
                )
                lid = state.add_label(label)
                state.taint_var(param_name, {lid})

    @staticmethod
    def _extract_param_name(param_node: Node) -> str | None:
        """Extract the parameter name from various parameter node types."""
        if param_node.type == "identifier" and param_node.text:
            return param_node.text.decode("utf-8")
        if param_node.type in (
            "typed_parameter", "typed_default_parameter", "default_parameter"
        ):
            name_node = param_node.child_by_field_name("name")
            if name_node and name_node.text:
                return name_node.text.decode("utf-8")
        return None

    # ------------------------------------------------------------------
    # Block walking
    # ------------------------------------------------------------------

    def _walk_block(
        self,
        block_node: Node,
        file_path: Path,
        state: _TaintState,
        sink_lookup: dict[int, SinkInfo],
        sanitizer_lookup: dict[int, SanitizerInfo],
        entry_call_lookup: dict[int, EntryPointInfo],
        results: list[TaintPath],
    ) -> None:
        """Walk statements in a block, propagating taint forward."""
        for stmt in block_node.children:
            self._process_statement(
                stmt, file_path, state, sink_lookup, sanitizer_lookup,
                entry_call_lookup, results,
            )

    def _process_statement(
        self,
        stmt: Node,
        file_path: Path,
        state: _TaintState,
        sink_lookup: dict[int, SinkInfo],
        sanitizer_lookup: dict[int, SanitizerInfo],
        entry_call_lookup: dict[int, EntryPointInfo],
        results: list[TaintPath],
    ) -> None:
        """Dispatch a single statement node for taint processing."""
        if stmt.type == "assignment":
            self._handle_assignment(
                stmt, file_path, state, sink_lookup, sanitizer_lookup,
                entry_call_lookup, results,
            )
        elif stmt.type == "augmented_assignment":
            self._handle_augmented_assignment(stmt, state)
        elif stmt.type == "call":
            # Bare call expression (not assigned to anything).
            self._check_call_for_sink(
                stmt, file_path, state, sink_lookup, results,
            )
        elif stmt.type == "return_statement":
            # Check if return value involves a sink call.
            for child in stmt.children:
                if child.type == "call":
                    self._check_call_for_sink(
                        child, file_path, state, sink_lookup, results,
                    )
        elif stmt.type == "expression_statement":
            # Some tree-sitter versions wrap calls in expression_statement.
            for child in stmt.children:
                self._process_statement(
                    child, file_path, state, sink_lookup, sanitizer_lookup,
                    entry_call_lookup, results,
                )
        elif stmt.type in ("if_statement", "for_statement", "while_statement",
                           "with_statement", "try_statement"):
            # Conservative: walk nested blocks so we still catch sinks inside
            # control flow, but don't model branch-specific taint.
            self._walk_nested_blocks(
                stmt, file_path, state, sink_lookup, sanitizer_lookup,
                entry_call_lookup, results,
            )

    def _walk_nested_blocks(
        self,
        stmt: Node,
        file_path: Path,
        state: _TaintState,
        sink_lookup: dict[int, SinkInfo],
        sanitizer_lookup: dict[int, SanitizerInfo],
        entry_call_lookup: dict[int, EntryPointInfo],
        results: list[TaintPath],
    ) -> None:
        """Recursively walk blocks inside control-flow statements."""
        for child in stmt.children:
            if child.type == "block":
                self._walk_block(
                    child, file_path, state, sink_lookup, sanitizer_lookup,
                    entry_call_lookup, results,
                )
            elif child.type in ("elif_clause", "else_clause", "except_clause",
                                "finally_clause", "case_clause"):
                self._walk_nested_blocks(
                    child, file_path, state, sink_lookup, sanitizer_lookup,
                    entry_call_lookup, results,
                )

    # ------------------------------------------------------------------
    # Assignment handling
    # ------------------------------------------------------------------

    def _handle_assignment(
        self,
        stmt: Node,
        file_path: Path,
        state: _TaintState,
        sink_lookup: dict[int, SinkInfo],
        sanitizer_lookup: dict[int, SanitizerInfo],
        entry_call_lookup: dict[int, EntryPointInfo],
        results: list[TaintPath],
    ) -> None:
        """Process ``x = <rhs>`` or ``a, b = <rhs>``."""
        lhs = stmt.child_by_field_name("left")
        rhs = stmt.child_by_field_name("right")
        if lhs is None or rhs is None:
            return

        line = _node_line(stmt)

        # Check if the RHS is a sanitizer call.
        if rhs.type == "call" and line in sanitizer_lookup:
            san = sanitizer_lookup[line]
            # The sanitizer's first argument should be tainted for this to matter.
            first_arg_ids = _call_first_arg_identifiers(rhs)
            tainted_args = first_arg_ids & set(state.tainted.keys())
            if tainted_args:
                target_names = self._lhs_names(lhs)
                for name in target_names:
                    # Propagate the taint labels but mark as sanitized.
                    combined: set[int] = set()
                    for ta in tainted_args:
                        combined.update(state.labels_for(ta))
                    state.taint_var(name, combined)
                    state.clean_var(name, san.name)
                return

        # Check if the RHS is a call to an entry-point source.
        if rhs.type == "call" and line in entry_call_lookup:
            ep = entry_call_lookup[line]
            label = TaintLabel(
                source_kind=ep.kind,
                source_name=ep.name,
                file=file_path,
                line=line,
            )
            lid = state.add_label(label)
            target_names = self._lhs_names(lhs)
            for name in target_names:
                state.taint_var(name, {lid})
            return

        # Check if the RHS is a call to a sink (assigned sink -- unusual but possible).
        if rhs.type == "call":
            self._check_call_for_sink(rhs, file_path, state, sink_lookup, results)

        # General taint propagation: if RHS references any tainted variable,
        # propagate taint to LHS.
        rhs_ids = _identifiers_in(rhs)
        tainted_in_rhs = rhs_ids & set(state.tainted.keys())
        if tainted_in_rhs:
            combined_labels: set[int] = set()
            combined_sanitizers: list[str] = []
            all_sanitized = True
            for var in tainted_in_rhs:
                combined_labels.update(state.labels_for(var))
                if state.var_is_sanitized(var):
                    combined_sanitizers.extend(state.sanitizers_for(var))
                else:
                    all_sanitized = False

            target_names = self._lhs_names(lhs)
            for name in target_names:
                state.taint_var(name, combined_labels)
                if all_sanitized:
                    for san_name in combined_sanitizers:
                        state.clean_var(name, san_name)

    def _handle_augmented_assignment(
        self, stmt: Node, state: _TaintState
    ) -> None:
        """Process ``x += y`` — taint propagates if y is tainted."""
        lhs = stmt.child_by_field_name("left")
        rhs = stmt.child_by_field_name("right")
        if lhs is None or rhs is None:
            return

        rhs_ids = _identifiers_in(rhs)
        tainted_in_rhs = rhs_ids & set(state.tainted.keys())
        if tainted_in_rhs:
            combined: set[int] = set()
            for var in tainted_in_rhs:
                combined.update(state.labels_for(var))
            lhs_name = lhs.text.decode("utf-8") if lhs.text else ""
            if lhs_name:
                state.taint_var(lhs_name, combined)

    # ------------------------------------------------------------------
    # Sink checking
    # ------------------------------------------------------------------

    def _check_call_for_sink(
        self,
        call_node: Node,
        file_path: Path,
        state: _TaintState,
        sink_lookup: dict[int, SinkInfo],
        results: list[TaintPath],
    ) -> None:
        """Check if a call node hits a known sink with tainted arguments."""
        line = _node_line(call_node)
        sink = sink_lookup.get(line)
        if sink is None:
            return

        arg_ids = _call_arg_identifiers(call_node)
        tainted_args = arg_ids & set(state.tainted.keys())
        if not tainted_args:
            return

        # Build a TaintPath for each unique source label.
        seen_labels: set[int] = set()
        for var in tainted_args:
            for lid in state.labels_for(var):
                if lid in seen_labels:
                    continue
                seen_labels.add(lid)
                label = state.labels[lid]

                # Collect sanitizers from all tainted args reaching this sink.
                sanitizers: list[str] = []
                is_sanitized = True
                for tvar in tainted_args:
                    if lid in state.labels_for(tvar):
                        if state.var_is_sanitized(tvar):
                            sanitizers.extend(state.sanitizers_for(tvar))
                        else:
                            is_sanitized = False

                results.append(
                    TaintPath(
                        source=label,
                        sink_name=sink.name,
                        sink_kind=sink.kind,
                        sink_line=sink.line,
                        sanitizers=sanitizers,
                        is_sanitized=is_sanitized,
                    )
                )

    # ------------------------------------------------------------------
    # LHS name extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _lhs_names(lhs_node: Node) -> list[str]:
        """Extract variable names from the left side of an assignment.

        Handles simple identifiers and pattern_list (tuple unpacking).
        """
        if lhs_node.type == "identifier" and lhs_node.text:
            return [lhs_node.text.decode("utf-8")]
        if lhs_node.type == "pattern_list":
            names: list[str] = []
            for child in lhs_node.children:
                if child.type == "identifier" and child.text:
                    names.append(child.text.decode("utf-8"))
            return names
        return []

    # ------------------------------------------------------------------
    # Function summary (inter-procedural)
    # ------------------------------------------------------------------

    def summarize_function(
        self,
        func_node: Node,
        file_path: Path,
        entry_points: list[EntryPointInfo],
        sinks: list[SinkInfo],
        sanitizers: list[SanitizerInfo],
    ) -> FunctionSummary:
        """Build a taint summary for a single function.

        For each parameter, we seed taint from that parameter only (treating
        every parameter as hypothetically tainted) and run the intra-procedural
        analysis. This tells us:

        * Which sinks are reachable from each parameter (``tainted_params_to_sinks``).
        * Whether the return value carries taint from a given parameter
          (``tainted_params_to_return``).

        We also detect whether the function *introduces* its own taint by
        checking whether any ``http_handler`` entry-point calls appear within
        the body.
        """
        func_name_node = func_node.child_by_field_name("name")
        func_name = (
            func_name_node.text.decode("utf-8")
            if func_name_node and func_name_node.text
            else ""
        )

        params_node = func_node.child_by_field_name("parameters")
        body_node = func_node.child_by_field_name("body")

        summary = FunctionSummary(func_name=func_name, file=file_path)

        # Check whether this function itself introduces taint (has entry-point
        # calls inside it, e.g. os.environ.get).
        non_handler_eps = [
            ep for ep in entry_points
            if ep.function == func_name and ep.kind != "http_handler"
        ]
        if non_handler_eps:
            summary.introduces_taint = True

        if params_node is None or body_node is None:
            return summary

        # Collect parameter names.
        param_names: list[str] = []
        for child in params_node.children:
            name = self._extract_param_name(child)
            if name and name not in ("self", "cls"):
                param_names.append(name)

        # Build per-function lookups.
        sink_lookup = self._build_sink_lookup(sinks, func_name)
        sanitizer_lookup = self._build_sanitizer_lookup(sanitizers, func_name)
        entry_call_lookup = self._build_entry_call_lookup(entry_points, func_name)

        # For each parameter, run a mini taint analysis seeded only from that param.
        for param in param_names:
            state = _TaintState()
            label = TaintLabel(
                source_kind="parameter",
                source_name=param,
                file=file_path,
                line=_node_line(func_node),
            )
            lid = state.add_label(label)
            state.taint_var(param, {lid})

            paths: list[TaintPath] = []
            self._walk_block(
                body_node, file_path, state, sink_lookup, sanitizer_lookup,
                entry_call_lookup, paths,
            )

            if paths:
                reachable_sinks: list[SinkInfo] = []
                for tp in paths:
                    matching = [
                        s for s in sinks
                        if s.line == tp.sink_line and s.function == func_name
                    ]
                    reachable_sinks.extend(matching)
                if reachable_sinks:
                    summary.tainted_params_to_sinks[param] = reachable_sinks

            # Check whether any tainted variable is referenced in a return statement.
            if self._return_carries_taint(body_node, state):
                summary.tainted_params_to_return.append(param)

        return summary

    def _return_carries_taint(self, body_node: Node, state: _TaintState) -> bool:
        """Return True if any return statement in *body_node* returns a tainted var."""
        for node in _walk_nodes(body_node):
            if node.type == "return_statement":
                for child in node.children:
                    for ident in _identifiers_in(child):
                        if state.is_tainted(ident):
                            return True
        return False


# ---------------------------------------------------------------------------
# File-level integration
# ---------------------------------------------------------------------------


def analyze_file_taint(
    file_path: Path,
    tree: object,
    plugin: LanguagePlugin,
    entry_points: list[EntryPointInfo],
    sinks: list[SinkInfo],
    sanitizers: list[SanitizerInfo],
) -> list[TaintPath]:
    """Run taint analysis on all functions in a parsed file.

    Args:
        file_path: Path to the source file.
        tree: tree-sitter parse tree.
        plugin: Language plugin instance.
        entry_points: Entry points detected in this file.
        sinks: Sinks detected in this file.
        sanitizers: Sanitizers detected in this file.

    Returns:
        Aggregated list of taint paths across all functions in the file.
    """
    analyzer = TaintAnalyzer(plugin)
    results: list[TaintPath] = []

    root = tree.root_node  # type: ignore[attr-defined]

    for node in _walk_functions(root):
        paths = analyzer.analyze_function(
            node, file_path, entry_points, sinks, sanitizers,
        )
        results.extend(paths)

    return results


def _walk_functions(node: Node) -> list[Node]:
    """Collect all function_definition nodes in the tree (depth-first)."""
    funcs: list[Node] = []
    if node.type == "function_definition":
        funcs.append(node)
    for child in node.children:
        # Skip decorated_definition wrapper -- the function_definition inside
        # it will be visited directly.
        if child.type == "decorated_definition":
            for grandchild in child.children:
                funcs.extend(_walk_functions(grandchild))
        else:
            funcs.extend(_walk_functions(child))
    return funcs


def _walk_nodes(node: Node):
    """Yield every node in the subtree rooted at *node* (depth-first)."""
    yield node
    for child in node.children:
        yield from _walk_nodes(child)


# ---------------------------------------------------------------------------
# Inter-procedural analysis
# ---------------------------------------------------------------------------


def _build_summaries(
    file_trees: list[tuple[Path, Any]],
    registry: Any,
) -> dict[str, FunctionSummary]:
    """Build a FunctionSummary for every function across all files.

    Returns a dict keyed by function name (simple, unqualified). In the
    common case of same-file helpers this is sufficient; qualified names
    would be needed for true cross-package resolution but are out of scope.
    """
    summaries: dict[str, FunctionSummary] = {}

    for file_path, tree in file_trees:
        plugin = registry.for_extension(file_path.suffix)
        if plugin is None:
            continue

        entry_points = plugin.detect_entry_points(tree, file_path)
        sinks = plugin.detect_sinks(tree, file_path)
        sanitizers = plugin.detect_sanitizers(tree, file_path)

        analyzer = TaintAnalyzer(plugin)
        root = tree.root_node

        for func_node in _walk_functions(root):
            summary = analyzer.summarize_function(
                func_node, file_path, entry_points, sinks, sanitizers,
            )
            if summary.func_name:
                summaries[summary.func_name] = summary

    return summaries


def _collect_call_names_in_body(body_node: Node) -> list[tuple[str, Node]]:
    """Return (callee_name, call_node) pairs for every call in the body.

    Only returns simple name calls and attribute calls (e.g. ``helper(x)`` or
    ``obj.method(x)``); ignores more complex targets.
    """
    results: list[tuple[str, Node]] = []
    for node in _walk_nodes(body_node):
        if node.type == "call":
            func_part = node.child_by_field_name("function")
            if func_part is None:
                continue
            if func_part.type == "identifier" and func_part.text:
                results.append((func_part.text.decode("utf-8"), node))
            elif func_part.type == "attribute":
                # e.g. self.helper(...) — take just the attribute (method) name
                attr = func_part.child_by_field_name("attribute")
                if attr and attr.text:
                    results.append((attr.text.decode("utf-8"), node))
    return results


def analyze_interprocedural_taint(
    file_trees: list[tuple[Path, Any]],
    registry: Any,
) -> list[TaintPath]:
    """Run inter-procedural taint analysis across all files.

    Algorithm:
    1. Build a FunctionSummary for every function in the corpus.
    2. For each function that is itself an entry point (HTTP handler or has
       externally-tainted parameters), look at every call inside its body.
    3. If the callee has a summary showing that one of its parameters can
       reach a sink, and the argument passed at the call site is tainted,
       emit a cross-function TaintPath.
    4. Also handle the "return-carried taint" pattern: if a callee returns
       taint from a parameter and the caller assigns the result to a variable,
       propagate taint to that variable and continue checking downstream sinks.

    Returns cross-function TaintPath records that complement the intra-
    procedural results from analyze_file_taint.
    """
    summaries = _build_summaries(file_trees, registry)

    results: list[TaintPath] = []

    for file_path, tree in file_trees:
        plugin = registry.for_extension(file_path.suffix)
        if plugin is None:
            continue

        entry_points = plugin.detect_entry_points(tree, file_path)
        sinks = plugin.detect_sinks(tree, file_path)
        sanitizers = plugin.detect_sanitizers(tree, file_path)

        analyzer = TaintAnalyzer(plugin)
        root = tree.root_node

        for func_node in _walk_functions(root):
            func_name_node = func_node.child_by_field_name("name")
            if not func_name_node or not func_name_node.text:
                continue
            func_name = func_name_node.text.decode("utf-8")

            # Is this function an HTTP handler (i.e. a true entry point)?
            is_handler = any(
                ep.name == func_name and ep.kind == "http_handler"
                for ep in entry_points
            )
            if not is_handler:
                continue

            body_node = func_node.child_by_field_name("body")
            if body_node is None:
                continue

            # Seed taint from handler parameters, same logic as analyze_function.
            state = _TaintState()
            params_node = func_node.child_by_field_name("parameters")
            if params_node:
                func_line = _node_line(func_node)
                for child in params_node.children:
                    param_name = TaintAnalyzer._extract_param_name(child)
                    if param_name and param_name in _TAINTED_PARAM_NAMES:
                        label = TaintLabel(
                            source_kind="http_handler",
                            source_name=f"{func_name}.{param_name}",
                            file=file_path,
                            line=func_line,
                        )
                        lid = state.add_label(label)
                        state.taint_var(param_name, {lid})

            # Walk the body collecting assignments first so we can propagate
            # taint through them before checking cross-function calls.
            sink_lookup = TaintAnalyzer._build_sink_lookup(sinks, func_name)
            sanitizer_lookup = TaintAnalyzer._build_sanitizer_lookup(sanitizers, func_name)
            entry_call_lookup = TaintAnalyzer._build_entry_call_lookup(entry_points, func_name)

            # Run the standard intra-procedural walk to update state (do not
            # record findings here — that is handled by analyze_file_taint).
            _intra_walk_for_state(
                analyzer, body_node, file_path, state,
                sink_lookup, sanitizer_lookup, entry_call_lookup,
            )

            # Now scan every call site in the body for cross-function paths.
            for callee_name, call_node in _collect_call_names_in_body(body_node):
                callee_summary = summaries.get(callee_name)
                if callee_summary is None:
                    continue

                # Which arguments passed to this call are tainted?
                args_node = call_node.child_by_field_name("arguments")
                if args_node is None:
                    continue

                positional_args = [
                    child for child in args_node.children
                    if child.type not in ("(", ")", ",", "keyword_argument",
                                         "dictionary_splat", "list_splat")
                ]

                # Map positional arg index -> callee param name.
                callee_params_ordered = list(callee_summary.tainted_params_to_sinks.keys())
                # Also check return-taint params that may not hit sinks directly.
                all_callee_params = list(dict.fromkeys(
                    callee_params_ordered + callee_summary.tainted_params_to_return
                ))

                for idx, arg_node in enumerate(positional_args):
                    if idx >= len(all_callee_params):
                        break
                    callee_param = all_callee_params[idx]

                    # Collect identifiers in this argument.
                    arg_ids = _identifiers_in(arg_node)
                    tainted_arg_ids = arg_ids & set(state.tainted.keys())
                    if not tainted_arg_ids:
                        continue

                    # Collect all taint labels from tainted args.
                    source_labels: list[TaintLabel] = []
                    is_sanitized = True
                    active_sanitizers: list[str] = []
                    for var in tainted_arg_ids:
                        for lid in state.labels_for(var):
                            source_labels.append(state.labels[lid])
                        if state.var_is_sanitized(var):
                            active_sanitizers.extend(state.sanitizers_for(var))
                        else:
                            is_sanitized = False

                    # Check whether this callee param reaches a sink in the summary.
                    reachable_sinks = callee_summary.tainted_params_to_sinks.get(callee_param, [])
                    for sink_info in reachable_sinks:
                        for source_label in source_labels:
                            results.append(
                                TaintPath(
                                    source=source_label,
                                    sink_name=sink_info.name,
                                    sink_kind=sink_info.kind,
                                    sink_line=sink_info.line,
                                    sanitizers=list(active_sanitizers),
                                    is_sanitized=is_sanitized,
                                    via_call=callee_name,
                                )
                            )

    return results


def _intra_walk_for_state(
    analyzer: TaintAnalyzer,
    body_node: Node,
    file_path: Path,
    state: _TaintState,
    sink_lookup: dict[int, SinkInfo],
    sanitizer_lookup: dict[int, SanitizerInfo],
    entry_call_lookup: dict[int, EntryPointInfo],
) -> None:
    """Run the intra-procedural block walk purely to update *state*.

    The *results* list is a /dev/null — we only care about the propagated
    taint in ``state`` for downstream cross-function analysis.
    """
    _discard: list[TaintPath] = []
    analyzer._walk_block(
        body_node, file_path, state, sink_lookup, sanitizer_lookup,
        entry_call_lookup, _discard,
    )
