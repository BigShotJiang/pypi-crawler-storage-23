"""Cross-file call graph analysis — pure-logic helpers.

Defines the ``FunctionDefInfo`` and ``CallSiteInfo`` dataclasses, along with
the pure-logic helpers ``_module_name_from_path``, ``find_package_root``,
``_build_import_map``, and ``resolve_calls``.  Collection of definitions and
call sites from parse trees is handled by the language plugin implementations
(e.g. ``sanicode.scanner.languages.python``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from sanicode.scanner.imports import ImportInfo


@dataclass
class FunctionDefInfo:
    """A function or method definition found in the codebase."""

    name: str
    qualified_name: str  # "module.ClassName.method" or "module.func"
    params: list[str] = field(default_factory=list)
    file: Path = field(default_factory=Path)
    line: int = 0


@dataclass
class CallSiteInfo:
    """A function call site found in the codebase."""

    target: str          # dotted name of called function
    args: list[str] = field(default_factory=list)  # argument names/expressions (simplified)
    file: Path = field(default_factory=Path)
    line: int = 0
    caller: str = ""     # enclosing function name


def _module_name_from_path(file_path: Path, project_root: Path | None = None) -> str:
    """Derive a dotted module name from a file path.

    When *project_root* is provided, computes a fully-qualified dotted path
    relative to that root (e.g. ``sanicode.scanner.data_flow``).  Falls back
    to the file stem when *project_root* is ``None`` or the file is not
    relative to the given root.
    """
    if project_root is not None:
        try:
            rel = file_path.relative_to(project_root)
            parts = rel.with_suffix("").parts
            if parts and parts[-1] == "__init__":
                parts = parts[:-1]
            if parts:
                return ".".join(parts)
        except ValueError:
            pass  # file outside project_root — fall back to stem

    if file_path.stem == "__init__":
        return file_path.parent.name
    return file_path.stem


def find_package_root(file_path: Path) -> Path | None:
    """Walk up from file_path to find the directory above the top-level package.

    A directory is part of a package if it contains __init__.py.
    Returns the directory that CONTAINS the top-level package, i.e.,
    the correct root for relative_to() in module name derivation.

    For ``src/sanicode/scanner/data_flow.py``, this returns ``src/`` because
    ``sanicode/`` has ``__init__.py`` but ``src/`` does not.

    Returns None if no package hierarchy is found (standalone file).
    """
    current = file_path.parent
    root = None
    while (current / "__init__.py").exists():
        root = current.parent
        current = current.parent
    return root


def _build_import_map(imports: list[ImportInfo]) -> dict[str, str]:
    """Build a mapping from local names to fully-qualified module names.

    For ``from flask import request``, maps ``"request"`` -> ``"flask.request"``.
    For ``import os.path``, maps ``"os.path"`` -> ``"os.path"`` and ``"os"`` -> ``"os"``.
    For ``import numpy as np``, maps ``"np"`` -> ``"numpy"``.
    """
    name_map: dict[str, str] = {}
    for imp in imports:
        if imp.is_from:
            for name in imp.names:
                qualified = f"{imp.module}.{name}" if imp.module else name
                name_map[name] = qualified
            for alias, original in imp.aliases.items():
                qualified = f"{imp.module}.{original}" if imp.module else original
                name_map[alias] = qualified
        else:
            name_map[imp.module] = imp.module
            # Register aliases
            for alias, original in imp.aliases.items():
                name_map[alias] = original
    return name_map


def resolve_calls(
    definitions: dict[str, FunctionDefInfo],
    call_sites: list[CallSiteInfo],
    imports: list[ImportInfo],
) -> list[tuple[CallSiteInfo, FunctionDefInfo]]:
    """Resolve call sites to their target function definitions.

    Attempts to match each call site to a known definition using:

    1. Direct name match (same-file or short-name)
    2. Import-resolved qualified name match

    Args:
        definitions: Map of qualified name -> FunctionDefInfo.
        call_sites: All call sites found in the codebase.
        imports: All imports for name resolution.

    Returns:
        List of (call_site, resolved_definition) pairs for successful matches.
    """
    import_map = _build_import_map(imports)
    resolved: list[tuple[CallSiteInfo, FunctionDefInfo]] = []

    for site in call_sites:
        # Try direct match first
        if site.target in definitions:
            resolved.append((site, definitions[site.target]))
            continue

        # Try import-resolved match.
        # For "foo.bar()", resolve "foo" through imports, then try "resolved_foo.bar".
        parts = site.target.split(".")
        if parts[0] in import_map:
            resolved_target = import_map[parts[0]]
            if len(parts) > 1:
                resolved_target = f"{resolved_target}.{'.'.join(parts[1:])}"
            if resolved_target in definitions:
                resolved.append((site, definitions[resolved_target]))
                continue

        # Try just the final function name as fallback
        final_name = parts[-1]
        if final_name in definitions:
            resolved.append((site, definitions[final_name]))

    return resolved
