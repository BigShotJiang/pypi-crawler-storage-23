"""Tree-sitter-backed JavaScript/TypeScript language plugin for the sanicode scanner."""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.scanner.call_graph import (
    CallSiteInfo,
    FunctionDefInfo,
)
from sanicode.scanner.data_flow import EntryPointInfo, SanitizerInfo, SinkInfo
from sanicode.scanner.imports import FrameworkInfo, ImportInfo
from sanicode.scanner.languages.base import TreeSitterPlugin
from sanicode.scanner.patterns import Finding

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_HTTP_METHODS = frozenset(
    {"get", "post", "put", "delete", "patch", "head", "options", "all", "use"}
)

_EXEC_SINKS = frozenset(
    {
        "child_process.exec",
        "child_process.execSync",
        "child_process.spawn",
        "child_process.spawnSync",
        "exec",
        "execSync",
        "spawn",
        "spawnSync",
    }
)

_NETWORK_SINKS = frozenset(
    {
        "fetch",
        "axios.get",
        "axios.post",
        "axios.put",
        "axios.delete",
        "axios.patch",
        "http.get",
        "http.request",
        "https.get",
        "https.request",
    }
)

_TEMPLATE_SINKS = frozenset({"res.render", "res.send"})

_SANITIZER_CALLS: dict[str, str] = {
    "encodeURIComponent": "url_encode",
    "encodeURI": "url_encode",
    "DOMPurify.sanitize": "html_escape",
    "validator.escape": "html_escape",
    "xss": "html_escape",
}

_FRAMEWORK_MAP: dict[str, frozenset[str]] = {
    "express": frozenset({"express"}),
    "react": frozenset({"react"}),
    "next": frozenset({"next"}),
    "fastify": frozenset({"fastify"}),
    "koa": frozenset({"koa", "@koa/router"}),
    "hapi": frozenset({"@hapi/hapi", "hapi"}),
    "vue": frozenset({"vue"}),
    "angular": frozenset({"@angular/core"}),
}

# DOM XSS sink property names
_DOM_XSS_PROPS = frozenset({"innerHTML", "outerHTML", "document.write"})


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _dotted_name(node: Node) -> str:
    """Build a dotted name from a tree-sitter JS node.

    Handles ``identifier`` and ``member_expression`` (JS equivalent of Python's
    ``attribute``).
    """
    if node.type == "identifier":
        return node.text.decode("utf-8") if node.text else ""
    if node.type == "member_expression":
        obj = node.child_by_field_name("object")
        prop = node.child_by_field_name("property")
        if obj is None or prop is None:
            return ""
        prefix = _dotted_name(obj)
        suffix = prop.text.decode("utf-8") if prop.text else ""
        return f"{prefix}.{suffix}" if prefix else suffix
    return ""


def _enclosing_function(node: Node) -> str | None:
    """Walk the parent chain to find the nearest function name."""
    current = node.parent
    while current is not None:
        func_name = _function_name(current)
        if func_name is not None:
            return func_name
        current = current.parent
    return None


def _function_name(node: Node) -> str | None:
    """Return the name of a function node, or None if not a function node."""
    if node.type == "function_declaration":
        name_node = node.child_by_field_name("name")
        if name_node and name_node.text:
            return name_node.text.decode("utf-8")
    elif node.type == "method_definition":
        name_node = node.child_by_field_name("name")
        if name_node and name_node.text:
            return name_node.text.decode("utf-8")
    elif node.type in ("arrow_function", "function_expression"):
        # Named via variable_declarator: const foo = () => {}
        parent = node.parent
        if parent and parent.type == "variable_declarator":
            vname = parent.child_by_field_name("name")
            if vname and vname.text:
                return vname.text.decode("utf-8")
    return None


def _call_arguments(call_node: Node) -> list[Node]:
    """Return positional argument nodes from a call_expression."""
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return []
    results: list[Node] = []
    for child in args_node.children:
        if child.type in ("(", ")", ",", "spread_element"):
            continue
        results.append(child)
    return results


def _walk(node: Node) -> list[Node]:
    """Depth-first walk of all descendants, including node itself."""
    result: list[Node] = [node]
    for child in node.children:
        result.extend(_walk(child))
    return result


def _strip_string_quotes(s: str) -> str:
    """Strip surrounding quote characters from a JS string literal text."""
    for q in ('"""', "'''", '`', '"', "'"):
        if s.startswith(q) and s.endswith(q) and len(s) >= 2 * len(q):
            return s[len(q) : -len(q)]
    return s


def _string_value(node: Node) -> str:
    """Extract the unquoted string value from a tree-sitter string node."""
    if node.text is None:
        return ""
    raw = node.text.decode("utf-8")
    return _strip_string_quotes(raw)


def _param_names(formal_params_node: Node) -> list[str]:
    """Extract parameter names from a formal_parameters node."""
    params: list[str] = []
    for child in formal_params_node.children:
        if child.type == "identifier" and child.text:
            params.append(child.text.decode("utf-8"))
        elif child.type == "assignment_pattern":
            # default parameter: name = value
            left = child.child_by_field_name("left")
            if left and left.text:
                params.append(left.text.decode("utf-8"))
        elif child.type == "rest_pattern":
            # rest parameter: ...name
            for grandchild in child.children:
                if grandchild.type == "identifier" and grandchild.text:
                    params.append(grandchild.text.decode("utf-8"))
                    break
    return params


# ---------------------------------------------------------------------------
# JavaScriptPlugin
# ---------------------------------------------------------------------------


class JavaScriptPlugin(TreeSitterPlugin):
    """Tree-sitter-backed scanner plugin for JavaScript source files."""

    _language_name = "javascript"

    @property
    def name(self) -> str:
        return "javascript"

    @property
    def extensions(self) -> frozenset[str]:
        return frozenset({".js", ".mjs", ".cjs"})

    # ------------------------------------------------------------------
    # Pattern checks — delegates to rule registry
    # ------------------------------------------------------------------

    def check_patterns(self, tree: Tree, file_path: Path) -> list[Finding]:
        from sanicode.rules import get_rule_registry, init_rules

        init_rules()
        registry = get_rule_registry()
        findings: list[Finding] = []
        for rule in registry.rules_for("javascript"):
            findings.extend(rule.check(tree, file_path, self))
        return findings

    # ------------------------------------------------------------------
    # Import detection
    # ------------------------------------------------------------------

    def detect_imports(self, tree: Tree, file_path: Path) -> list[ImportInfo]:
        results: list[ImportInfo] = []
        root = tree.root_node

        for node in _walk(root):
            if node.type == "import_statement":
                results.extend(self._parse_import_statement(node, file_path))
            elif node.type == "call_expression":
                # require() calls
                func_node = node.child_by_field_name("function")
                if func_node and _dotted_name(func_node) == "require":
                    args = _call_arguments(node)
                    if args and args[0].type == "string":
                        module = _string_value(args[0])
                        line = self.start_position(node)[0]
                        results.append(
                            ImportInfo(
                                module=module,
                                names=[],
                                aliases={},
                                file=file_path,
                                line=line,
                                is_from=False,
                            )
                        )

        return results

    def _parse_import_statement(
        self, node: Node, file_path: Path
    ) -> list[ImportInfo]:
        """Parse ES6 import statements.

        Handles three forms:
          - ``import X from "module"``         (default import)
          - ``import { A, B as C } from "module"``  (named imports)
          - ``import * as X from "module"``    (namespace import)
        """
        line = self.start_position(node)[0]
        module = ""
        names: list[str] = []
        aliases: dict[str, str] = {}

        # The module path is in the 'source' field of the import_statement
        source_node = node.child_by_field_name("source")
        if source_node and source_node.type == "string":
            module = _string_value(source_node)

        # Walk into import_clause for names
        clause_node = node.child_by_field_name("import") or None
        # Fall back: scan direct children for import_clause
        for child in node.children:
            if child.type == "import_clause":
                clause_node = child
                break

        if clause_node is not None:
            for sub in clause_node.children:
                if sub.type == "identifier" and sub.text:
                    # Default import: import X from "..."
                    names.append(sub.text.decode("utf-8"))
                elif sub.type == "named_imports":
                    for spec in sub.children:
                        if spec.type == "import_specifier":
                            name_node = spec.child_by_field_name("name")
                            alias_node = spec.child_by_field_name("alias")
                            name = self.node_text(name_node) if name_node else ""
                            alias = self.node_text(alias_node) if alias_node else ""
                            if name:
                                names.append(name)
                            if alias and name:
                                aliases[alias] = name
                elif sub.type == "namespace_import":
                    # import * as X from "..."
                    names.append("*")
                    for nc in sub.children:
                        if nc.type == "identifier" and nc.text:
                            aliases[nc.text.decode("utf-8")] = "*"
                            break

        return [
            ImportInfo(
                module=module,
                names=names,
                aliases=aliases,
                file=file_path,
                line=line,
                is_from=True,
            )
        ]

    # ------------------------------------------------------------------
    # Framework detection
    # ------------------------------------------------------------------

    def detect_frameworks(self, imports: list[ImportInfo]) -> list[FrameworkInfo]:
        imported_modules: set[str] = set()
        for imp in imports:
            imported_modules.add(imp.module)
            # Also index scoped package root: @hapi/hapi -> @hapi
            if "/" in imp.module:
                imported_modules.add(imp.module.split("/")[0])

        results: list[FrameworkInfo] = []
        for fw_name, fw_modules in _FRAMEWORK_MAP.items():
            matched = fw_modules & imported_modules
            if matched:
                results.append(FrameworkInfo(name=fw_name, modules=sorted(matched)))
        return results

    # ------------------------------------------------------------------
    # Entry point detection
    # ------------------------------------------------------------------

    def detect_entry_points(
        self,
        tree: Tree,
        file_path: Path,
        frameworks: list[FrameworkInfo] | None = None,
    ) -> list[EntryPointInfo]:
        results: list[EntryPointInfo] = []
        root = tree.root_node

        for node in _walk(root):
            if node.type == "call_expression":
                self._check_call_entry_points(node, file_path, results)
            elif node.type == "member_expression":
                self._check_member_entry_points(node, file_path, results)

        return results

    def _check_call_entry_points(
        self,
        call_node: Node,
        file_path: Path,
        results: list[EntryPointInfo],
    ) -> None:
        func_node = call_node.child_by_field_name("function")
        if func_node is None:
            return

        dotted = _dotted_name(func_node)
        fn = _enclosing_function(call_node)
        line = self.start_position(call_node)[0]

        # Express/Fastify/Koa route handlers: app.get(), router.post(), etc.
        if func_node.type == "member_expression":
            prop = func_node.child_by_field_name("property")
            if prop and prop.text:
                method = prop.text.decode("utf-8")
                if method in _HTTP_METHODS:
                    results.append(
                        EntryPointInfo(
                            name=dotted,
                            kind="http_handler",
                            file=file_path,
                            line=line,
                            function=fn,
                        )
                    )

    def _check_member_entry_points(
        self,
        node: Node,
        file_path: Path,
        results: list[EntryPointInfo],
    ) -> None:
        dotted = _dotted_name(node)
        line = self.start_position(node)[0]
        fn = _enclosing_function(node)

        if dotted.startswith("process.env"):
            results.append(
                EntryPointInfo(
                    name=dotted,
                    kind="env_var",
                    file=file_path,
                    line=line,
                    function=fn,
                )
            )
        elif dotted == "process.argv":
            results.append(
                EntryPointInfo(
                    name="process.argv",
                    kind="cli_arg",
                    file=file_path,
                    line=line,
                    function=fn,
                )
            )
        elif dotted in ("req.body", "req.params", "req.query", "req.headers"):
            results.append(
                EntryPointInfo(
                    name=dotted,
                    kind="http_input",
                    file=file_path,
                    line=line,
                    function=fn,
                )
            )

    # ------------------------------------------------------------------
    # Sink detection
    # ------------------------------------------------------------------

    def detect_sinks(
        self,
        tree: Tree,
        file_path: Path,
        frameworks: list[FrameworkInfo] | None = None,
    ) -> list[SinkInfo]:
        results: list[SinkInfo] = []
        root = tree.root_node

        call_captures = self.captures("(call_expression) @call", root)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = _dotted_name(func_node)
            fn = _enclosing_function(call_node)
            line = self.start_position(call_node)[0]

            # eval()
            if func_node.type == "identifier" and dotted == "eval":
                results.append(
                    SinkInfo(
                        name="eval",
                        kind="eval",
                        file=file_path,
                        line=line,
                        function=fn,
                        cwe_id=94,
                    )
                )

            # new Function() — handled separately via new_expression below

            # child_process exec/spawn
            elif dotted in _EXEC_SINKS:
                results.append(
                    SinkInfo(
                        name=dotted,
                        kind="command",
                        file=file_path,
                        line=line,
                        function=fn,
                        cwe_id=78,
                    )
                )

            # Network sinks
            elif dotted in _NETWORK_SINKS:
                results.append(
                    SinkInfo(
                        name=dotted,
                        kind="network",
                        file=file_path,
                        line=line,
                        function=fn,
                        cwe_id=918,
                    )
                )

            # Template rendering
            elif dotted in _TEMPLATE_SINKS:
                results.append(
                    SinkInfo(
                        name=dotted,
                        kind="template",
                        file=file_path,
                        line=line,
                        function=fn,
                        cwe_id=79,
                    )
                )

            # SQL: db.query() with template literal argument
            elif func_node.type == "member_expression":
                prop = func_node.child_by_field_name("property")
                if prop and prop.text and prop.text.decode("utf-8") == "query":
                    args = _call_arguments(call_node)
                    if args and args[0].type == "template_string":
                        results.append(
                            SinkInfo(
                                name=dotted,
                                kind="sql",
                                file=file_path,
                                line=line,
                                function=fn,
                                cwe_id=89,
                            )
                        )

        # new Function() construction
        for node in _walk(root):
            if node.type == "new_expression":
                ctor = node.child_by_field_name("constructor")
                if ctor and ctor.type == "identifier" and ctor.text == b"Function":
                    results.append(
                        SinkInfo(
                            name="Function",
                            kind="eval",
                            file=file_path,
                            line=self.start_position(node)[0],
                            function=_enclosing_function(node),
                            cwe_id=94,
                        )
                    )

            # DOM XSS: el.innerHTML = ..., el.outerHTML = ...
            elif node.type == "assignment_expression":
                left = node.child_by_field_name("left")
                if left and left.type == "member_expression":
                    prop = left.child_by_field_name("property")
                    if prop and prop.text:
                        prop_name = prop.text.decode("utf-8")
                        if prop_name in ("innerHTML", "outerHTML"):
                            results.append(
                                SinkInfo(
                                    name=f".{prop_name}",
                                    kind="xss",
                                    file=file_path,
                                    line=self.start_position(node)[0],
                                    function=_enclosing_function(node),
                                    cwe_id=79,
                                )
                            )

            # document.write()
            elif node.type == "call_expression":
                func = node.child_by_field_name("function")
                if func and _dotted_name(func) == "document.write":
                    results.append(
                        SinkInfo(
                            name="document.write",
                            kind="xss",
                            file=file_path,
                            line=self.start_position(node)[0],
                            function=_enclosing_function(node),
                            cwe_id=79,
                        )
                    )

        return results

    # ------------------------------------------------------------------
    # Sanitizer detection
    # ------------------------------------------------------------------

    def detect_sanitizers(self, tree: Tree, file_path: Path) -> list[SanitizerInfo]:
        results: list[SanitizerInfo] = []
        root = tree.root_node

        call_captures = self.captures("(call_expression) @call", root)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = _dotted_name(func_node)
            fn = _enclosing_function(call_node)
            line = self.start_position(call_node)[0]

            kind = _SANITIZER_CALLS.get(dotted)
            if kind:
                results.append(
                    SanitizerInfo(
                        name=dotted,
                        kind=kind,
                        file=file_path,
                        line=line,
                        function=fn,
                    )
                )

        return results

    # ------------------------------------------------------------------
    # Call graph: definitions
    # ------------------------------------------------------------------

    def collect_definitions(
        self,
        file_trees: list[tuple[Path, Tree]],
        project_root: Path | None = None,
    ) -> dict[str, FunctionDefInfo]:
        defs: dict[str, FunctionDefInfo] = {}

        for file_path, tree in file_trees:
            module_name = file_path.stem
            root = tree.root_node
            self._collect_definitions_from_node(root, module_name, file_path, defs)

        return defs

    def _collect_definitions_from_node(
        self,
        root: Node,
        module_name: str,
        file_path: Path,
        defs: dict[str, FunctionDefInfo],
    ) -> None:
        for node in _walk(root):
            func_name = ""
            func_node = node
            params: list[str] = []

            if node.type == "function_declaration":
                name_node = node.child_by_field_name("name")
                func_name = self.node_text(name_node) if name_node else ""

            elif node.type == "method_definition":
                name_node = node.child_by_field_name("name")
                func_name = self.node_text(name_node) if name_node else ""

            elif node.type == "variable_declarator":
                # const foo = function() {} or const foo = () => {}
                name_node = node.child_by_field_name("name")
                value_node = node.child_by_field_name("value")
                if value_node and value_node.type in (
                    "function_expression",
                    "arrow_function",
                ):
                    func_name = self.node_text(name_node) if name_node else ""
                    func_node = value_node
                else:
                    continue

            else:
                continue

            if not func_name:
                continue

            # Extract parameter names from formal_parameters
            params_node = func_node.child_by_field_name("parameters")
            if params_node:
                params = _param_names(params_node)

            # Determine class scope via parent chain
            class_parts: list[str] = []
            parent = node.parent
            while parent is not None:
                if parent.type == "class_declaration":
                    cls_name = parent.child_by_field_name("name")
                    if cls_name and cls_name.text:
                        class_parts.insert(0, cls_name.text.decode("utf-8"))
                parent = parent.parent

            qualified = ".".join([module_name, *class_parts, func_name])
            line = self.start_position(func_node)[0]

            info = FunctionDefInfo(
                name=func_name,
                qualified_name=qualified,
                params=params,
                file=file_path,
                line=line,
            )
            defs[qualified] = info
            # Short name for quick lookup
            if func_name not in defs:
                defs[func_name] = info

    # ------------------------------------------------------------------
    # Call graph: call sites
    # ------------------------------------------------------------------

    def collect_call_sites(
        self, file_trees: list[tuple[Path, Tree]]
    ) -> list[CallSiteInfo]:
        sites: list[CallSiteInfo] = []

        for file_path, tree in file_trees:
            root = tree.root_node
            call_captures = self.captures("(call_expression) @call", root)

            for call_node in call_captures.get("call", []):
                func_node = call_node.child_by_field_name("function")
                if func_node is None:
                    continue

                target = _dotted_name(func_node)
                if not target:
                    continue

                args: list[str] = []
                for arg_node in _call_arguments(call_node):
                    if arg_node.type == "identifier" and arg_node.text:
                        args.append(arg_node.text.decode("utf-8"))
                    else:
                        args.append("<expr>")

                caller = _enclosing_function(call_node) or ""
                line = self.start_position(call_node)[0]

                sites.append(
                    CallSiteInfo(
                        target=target,
                        args=args,
                        file=file_path,
                        line=line,
                        caller=caller,
                    )
                )

        return sites

    # ------------------------------------------------------------------
    # Call resolution
    # ------------------------------------------------------------------

    def resolve_calls(
        self,
        definitions: dict[str, FunctionDefInfo],
        call_sites: list[CallSiteInfo],
        imports: list[ImportInfo],
    ) -> list[tuple[CallSiteInfo, FunctionDefInfo]]:
        """Simple name-based call resolution: exact qualified name then short name."""
        resolved = []
        for site in call_sites:
            if site.target in definitions:
                resolved.append((site, definitions[site.target]))
            else:
                # Try short name (last segment after '.')
                short = site.target.rsplit(".", 1)[-1]
                if short in definitions:
                    resolved.append((site, definitions[short]))
        return resolved

    # ------------------------------------------------------------------
    # Package root
    # ------------------------------------------------------------------

    def find_package_root(self, file_path: Path) -> Path | None:
        """Walk up the directory tree looking for package.json."""
        current = file_path.parent
        while current != current.parent:
            if (current / "package.json").exists():
                return current
            current = current.parent
        return None


# ---------------------------------------------------------------------------
# TypeScriptPlugin — thin subclass with the TypeScript grammar
# ---------------------------------------------------------------------------


class TypeScriptPlugin(JavaScriptPlugin):
    """Tree-sitter-backed scanner plugin for TypeScript source files.

    Reuses all JavaScript detection logic with the TypeScript tree-sitter
    grammar, which understands type annotations and TypeScript-specific syntax.
    """

    _language_name = "typescript"

    @property
    def name(self) -> str:
        return "typescript"

    @property
    def extensions(self) -> frozenset[str]:
        return frozenset({".ts", ".tsx"})
