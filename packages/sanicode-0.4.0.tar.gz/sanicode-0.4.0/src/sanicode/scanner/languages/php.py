"""Tree-sitter-backed PHP language plugin for the sanicode scanner."""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.scanner.call_graph import CallSiteInfo, FunctionDefInfo
from sanicode.scanner.data_flow import EntryPointInfo, SanitizerInfo, SinkInfo
from sanicode.scanner.imports import FrameworkInfo, ImportInfo
from sanicode.scanner.languages.base import TreeSitterPlugin
from sanicode.scanner.patterns import Finding

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_COMMAND_EXEC_FUNCS = frozenset({
    "system", "exec", "passthru", "shell_exec", "popen", "proc_open",
})

_SQL_FUNCS = frozenset({
    "mysql_query", "mysqli_query", "pg_query",
})

_SUPERGLOBALS = frozenset({
    "$_GET", "$_POST", "$_REQUEST", "$_COOKIE", "$_SERVER", "$_FILES",
})

_SANITIZER_FUNCS = frozenset({
    "htmlspecialchars", "htmlentities", "strip_tags",
    "addslashes", "mysqli_real_escape_string",
    "pg_escape_string", "intval", "floatval",
})

_FRAMEWORK_MAP = {
    "laravel": frozenset({"Illuminate"}),
    "symfony": frozenset({"Symfony"}),
    "wordpress": frozenset({"wp_"}),
    "codeigniter": frozenset({"CodeIgniter"}),
}


def _func_name(node: Node) -> str:
    """Extract function name from a PHP call's function node.

    The ``function`` field of ``function_call_expression`` resolves to a
    ``name`` node for simple calls.  ``qualified_name`` is used for
    namespaced calls (e.g. ``Foo\\bar()``).
    """
    if node.type in ("name", "qualified_name"):
        return node.text.decode("utf-8") if node.text else ""
    if node.type == "variable_name":
        return node.text.decode("utf-8") if node.text else ""
    return node.text.decode("utf-8") if node.text else ""


def _enclosing_function(node: Node) -> str | None:
    """Walk parent chain to find nearest function/method name."""
    current = node.parent
    while current is not None:
        if current.type in ("function_definition", "method_declaration"):
            name_node = current.child_by_field_name("name")
            if name_node and name_node.text:
                return name_node.text.decode("utf-8")
        current = current.parent
    return None


def _call_arguments(call_node: Node) -> list[Node]:
    """Extract positional argument value nodes from a PHP function call.

    Arguments in PHP tree-sitter are wrapped in ``argument`` nodes; this
    unwraps them to expose the actual value.
    """
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return []
    results: list[Node] = []
    for child in args_node.children:
        if child.type == "argument":
            # Unwrap: take the first non-punctuation child
            for inner in child.children:
                results.append(inner)
                break
        elif child.type not in ("(", ")", ","):
            results.append(child)
    return results


def _walk(node: Node) -> list[Node]:
    """Depth-first walk of *node* and all its descendants."""
    result: list[Node] = [node]
    for child in node.children:
        result.extend(_walk(child))
    return result


class PHPPlugin(TreeSitterPlugin):
    """Tree-sitter-backed scanner plugin for PHP source files."""

    _language_name = "php"

    @property
    def name(self) -> str:
        return "php"

    @property
    def extensions(self) -> frozenset[str]:
        return frozenset({".php"})

    # ------------------------------------------------------------------
    # Pattern checks — delegates to rule registry
    # ------------------------------------------------------------------

    def check_patterns(self, tree: Tree, file_path: Path) -> list[Finding]:
        from sanicode.rules import get_rule_registry, init_rules

        init_rules()
        registry = get_rule_registry()
        findings: list[Finding] = []
        for rule in registry.rules_for("php"):
            findings.extend(rule.check(tree, file_path, self))
        return findings

    # ------------------------------------------------------------------
    # Import detection
    # ------------------------------------------------------------------

    def detect_imports(self, tree: Tree, file_path: Path) -> list[ImportInfo]:
        results: list[ImportInfo] = []
        root = tree.root_node

        for node in _walk(root):
            line = self.start_position(node)[0]

            if node.type == "namespace_use_declaration":
                # use Namespace\Class;
                for child in node.children:
                    if child.type == "namespace_use_clause":
                        qname_node = child.children[0] if child.children else None
                        if qname_node and qname_node.text:
                            module = qname_node.text.decode("utf-8")
                            short = module.rsplit("\\", 1)[-1] if "\\" in module else module
                            results.append(
                                ImportInfo(
                                    module=module,
                                    names=[short],
                                    aliases={},
                                    file=file_path,
                                    line=line,
                                    is_from=True,
                                )
                            )
                        break

            elif node.type in (
                "include_expression",
                "include_once_expression",
                "require_expression",
                "require_once_expression",
            ):
                # include/require "file.php"
                for child in node.children:
                    if child.type == "encapsed_string" and child.text:
                        raw = child.text.decode("utf-8").strip('"\'')
                        results.append(
                            ImportInfo(
                                module=raw,
                                names=[],
                                aliases={},
                                file=file_path,
                                line=line,
                                is_from=False,
                            )
                        )
                        break

        return results

    # ------------------------------------------------------------------
    # Framework detection
    # ------------------------------------------------------------------

    def detect_frameworks(self, imports: list[ImportInfo]) -> list[FrameworkInfo]:
        results: list[FrameworkInfo] = []
        all_modules: set[str] = set()
        for imp in imports:
            all_modules.add(imp.module)
            all_modules.update(imp.names)

        for fw_name, indicators in _FRAMEWORK_MAP.items():
            for module in all_modules:
                if any(indicator in module for indicator in indicators):
                    results.append(FrameworkInfo(name=fw_name, modules=[module]))
                    break
        return results

    # ------------------------------------------------------------------
    # Entry point detection
    # ------------------------------------------------------------------

    def detect_entry_points(
        self,
        tree: Tree,
        file_path: Path,
        frameworks: list[FrameworkInfo] | None = None,
    ) -> list[EntryPointInfo]:
        results: list[EntryPointInfo] = []
        root = tree.root_node

        for node in _walk(root):
            # Superglobal access: $_GET, $_POST, etc.
            if node.type == "variable_name" and node.text:
                var = node.text.decode("utf-8")
                if var in _SUPERGLOBALS:
                    results.append(
                        EntryPointInfo(
                            name=var,
                            kind="http_input",
                            file=file_path,
                            line=self.start_position(node)[0],
                            function=_enclosing_function(node),
                        )
                    )

            elif node.type == "function_call_expression":
                func_node = node.child_by_field_name("function")
                if func_node is None:
                    continue
                name = _func_name(func_node)
                fn = _enclosing_function(node)
                line = self.start_position(node)[0]

                if name == "getenv":
                    results.append(
                        EntryPointInfo(
                            name="getenv",
                            kind="env_var",
                            file=file_path,
                            line=line,
                            function=fn,
                        )
                    )
                elif name in ("fgets", "fread", "file_get_contents"):
                    results.append(
                        EntryPointInfo(
                            name=name,
                            kind="file_read",
                            file=file_path,
                            line=line,
                            function=fn,
                        )
                    )

        return results

    # ------------------------------------------------------------------
    # Sink detection
    # ------------------------------------------------------------------

    def detect_sinks(
        self,
        tree: Tree,
        file_path: Path,
        frameworks: list[FrameworkInfo] | None = None,
    ) -> list[SinkInfo]:
        results: list[SinkInfo] = []
        root = tree.root_node

        for node in _walk(root):
            if node.type == "function_call_expression":
                func_node = node.child_by_field_name("function")
                if func_node is None:
                    continue

                name = _func_name(func_node)
                fn = _enclosing_function(node)
                line = self.start_position(node)[0]

                if name == "eval":
                    results.append(
                        SinkInfo(
                            name="eval",
                            kind="eval",
                            file=file_path,
                            line=line,
                            function=fn,
                            cwe_id=94,
                        )
                    )
                elif name in _COMMAND_EXEC_FUNCS:
                    results.append(
                        SinkInfo(
                            name=name,
                            kind="command",
                            file=file_path,
                            line=line,
                            function=fn,
                            cwe_id=78,
                        )
                    )
                elif name in _SQL_FUNCS:
                    results.append(
                        SinkInfo(
                            name=name,
                            kind="sql",
                            file=file_path,
                            line=line,
                            function=fn,
                            cwe_id=89,
                        )
                    )
                elif name in ("echo", "print"):
                    results.append(
                        SinkInfo(
                            name=name,
                            kind="xss",
                            file=file_path,
                            line=line,
                            function=fn,
                            cwe_id=79,
                        )
                    )
                elif name in ("file_put_contents", "fwrite"):
                    results.append(
                        SinkInfo(
                            name=name,
                            kind="file_write",
                            file=file_path,
                            line=line,
                            function=fn,
                            cwe_id=73,
                        )
                    )
                elif name == "unserialize":
                    results.append(
                        SinkInfo(
                            name="unserialize",
                            kind="eval",
                            file=file_path,
                            line=line,
                            function=fn,
                            cwe_id=502,
                        )
                    )
                elif name in ("header", "setcookie"):
                    results.append(
                        SinkInfo(
                            name=name,
                            kind="header",
                            file=file_path,
                            line=line,
                            function=fn,
                            cwe_id=113,
                        )
                    )
                elif name in ("curl_exec",):
                    results.append(
                        SinkInfo(
                            name=name,
                            kind="network",
                            file=file_path,
                            line=line,
                            function=fn,
                            cwe_id=918,
                        )
                    )

            # echo statement (not function call in PHP — it's a keyword statement)
            elif node.type == "echo_statement":
                fn = _enclosing_function(node)
                results.append(
                    SinkInfo(
                        name="echo",
                        kind="xss",
                        file=file_path,
                        line=self.start_position(node)[0],
                        function=fn,
                        cwe_id=79,
                    )
                )

        return results

    # ------------------------------------------------------------------
    # Sanitizer detection
    # ------------------------------------------------------------------

    def detect_sanitizers(self, tree: Tree, file_path: Path) -> list[SanitizerInfo]:
        results: list[SanitizerInfo] = []
        root = tree.root_node

        for node in _walk(root):
            if node.type != "function_call_expression":
                continue

            func_node = node.child_by_field_name("function")
            if func_node is None:
                continue

            name = _func_name(func_node)
            fn = _enclosing_function(node)
            line = self.start_position(node)[0]

            if name in ("htmlspecialchars", "htmlentities", "strip_tags"):
                results.append(
                    SanitizerInfo(
                    name=name,
                    kind="html_escape",
                    file=file_path,
                    line=line,
                    function=fn,
                )
                )
            elif name == "escapeshellarg":
                results.append(
                    SanitizerInfo(
                    name=name,
                    kind="shell_quote",
                    file=file_path,
                    line=line,
                    function=fn,
                )
                )
            elif name in ("addslashes", "mysqli_real_escape_string", "pg_escape_string"):
                results.append(
                    SanitizerInfo(
                    name=name,
                    kind="sql_escape",
                    file=file_path,
                    line=line,
                    function=fn,
                )
                )
            elif name in ("intval", "floatval"):
                results.append(
                    SanitizerInfo(
                    name=name,
                    kind="type_cast",
                    file=file_path,
                    line=line,
                    function=fn,
                )
                )
            elif name == "urlencode":
                results.append(
                    SanitizerInfo(
                    name=name,
                    kind="url_encode",
                    file=file_path,
                    line=line,
                    function=fn,
                )
                )

        return results

    # ------------------------------------------------------------------
    # Call graph: definitions
    # ------------------------------------------------------------------

    def collect_definitions(
        self,
        file_trees: list[tuple[Path, Tree]],
        project_root: Path | None = None,
    ) -> dict[str, FunctionDefInfo]:
        defs: dict[str, FunctionDefInfo] = {}

        for file_path, tree in file_trees:
            module_name = file_path.stem
            root = tree.root_node

            for node in _walk(root):
                if node.type not in ("function_definition", "method_declaration"):
                    continue

                name_node = node.child_by_field_name("name")
                func_name = self.node_text(name_node) if name_node else ""
                if not func_name:
                    continue

                # Extract parameter names — field is "parameters" (type: formal_parameters)
                params: list[str] = []
                params_node = node.child_by_field_name("parameters")
                if params_node:
                    for p in _walk(params_node):
                        if p.type == "variable_name" and p.parent and p.parent.type in (
                            "simple_parameter",
                            "variadic_parameter",
                            "property_promotion_parameter",
                        ):
                            params.append(self.node_text(p))

                # Collect enclosing class names
                class_parts: list[str] = []
                parent = node.parent
                while parent is not None:
                    if parent.type == "class_declaration":
                        cls_name = parent.child_by_field_name("name")
                        if cls_name:
                            class_parts.insert(0, self.node_text(cls_name))
                    parent = parent.parent

                qualified = ".".join([module_name, *class_parts, func_name])
                line = self.start_position(node)[0]

                info = FunctionDefInfo(
                    name=func_name,
                    qualified_name=qualified,
                    params=params,
                    file=file_path,
                    line=line,
                )
                defs[qualified] = info
                if func_name not in defs:
                    defs[func_name] = info

        return defs

    # ------------------------------------------------------------------
    # Call graph: call sites
    # ------------------------------------------------------------------

    def collect_call_sites(
        self, file_trees: list[tuple[Path, Tree]]
    ) -> list[CallSiteInfo]:
        sites: list[CallSiteInfo] = []

        for file_path, tree in file_trees:
            root = tree.root_node

            for node in _walk(root):
                if node.type != "function_call_expression":
                    continue

                func_node = node.child_by_field_name("function")
                if func_node is None:
                    continue

                target = _func_name(func_node)
                if not target:
                    continue

                args: list[str] = []
                for arg in _call_arguments(node):
                    if arg.type == "variable_name" and arg.text:
                        args.append(arg.text.decode("utf-8"))
                    else:
                        args.append("<expr>")

                caller = _enclosing_function(node) or ""
                line = self.start_position(node)[0]

                sites.append(
                    CallSiteInfo(
                        target=target,
                        args=args,
                        file=file_path,
                        line=line,
                        caller=caller,
                    )
                )

        return sites

    # ------------------------------------------------------------------
    # Call resolution
    # ------------------------------------------------------------------

    def resolve_calls(
        self,
        definitions: dict[str, FunctionDefInfo],
        call_sites: list[CallSiteInfo],
        imports: list[ImportInfo],
    ) -> list[tuple[CallSiteInfo, FunctionDefInfo]]:
        resolved = []
        for site in call_sites:
            if site.target in definitions:
                resolved.append((site, definitions[site.target]))
        return resolved

    # ------------------------------------------------------------------
    # Package root
    # ------------------------------------------------------------------

    def find_package_root(self, file_path: Path) -> Path | None:
        current = file_path.parent
        while current != current.parent:
            if (current / "composer.json").exists():
                return current
            current = current.parent
        return None
