"""Language plugin protocol for sanicode scanner backends.

Defines the structural interface that all language-specific scanner
implementations must satisfy. Use `isinstance(obj, LanguagePlugin)` to
validate at runtime thanks to `@runtime_checkable`.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from sanicode.scanner.call_graph import CallSiteInfo, FunctionDefInfo
from sanicode.scanner.data_flow import EntryPointInfo, SanitizerInfo, SinkInfo
from sanicode.scanner.imports import FrameworkInfo, ImportInfo
from sanicode.scanner.patterns import Finding

# Opaque parse tree type — ast.Module for Python, tree_sitter.Tree for others.
ParseTree = Any


@runtime_checkable
class LanguagePlugin(Protocol):
    """Structural protocol for a language-specific scanner backend."""

    @property
    def name(self) -> str:
        """Unique, human-readable language name (e.g. ``"python"``)."""
        ...

    @property
    def extensions(self) -> frozenset[str]:
        """File extensions handled by this plugin (e.g. ``frozenset({".py"})``)."""
        ...

    def parse_file(self, path: Path) -> ParseTree:
        """Parse *path* and return the language-specific parse tree."""
        ...

    def parse_source(self, source: bytes, filename: str = "<string>") -> ParseTree:
        """Parse raw *source* bytes and return the language-specific parse tree."""
        ...

    def check_patterns(self, tree: ParseTree, file_path: Path) -> list[Finding]:
        """Run pattern-based checks on *tree* and return raw findings."""
        ...

    def detect_entry_points(
        self,
        tree: ParseTree,
        file_path: Path,
        frameworks: list[FrameworkInfo] | None = None,
    ) -> list[EntryPointInfo]:
        """Identify external entry points (HTTP handlers, CLI commands, etc.)."""
        ...

    def detect_sinks(
        self,
        tree: ParseTree,
        file_path: Path,
        frameworks: list[FrameworkInfo] | None = None,
    ) -> list[SinkInfo]:
        """Identify dangerous sinks (SQL, shell exec, file writes, etc.)."""
        ...

    def detect_sanitizers(
        self,
        tree: ParseTree,
        file_path: Path,
    ) -> list[SanitizerInfo]:
        """Identify sanitization/validation call sites in *tree*."""
        ...

    def detect_imports(self, tree: ParseTree, file_path: Path) -> list[ImportInfo]:
        """Extract all import statements from *tree*."""
        ...

    def detect_frameworks(self, imports: list[ImportInfo]) -> list[FrameworkInfo]:
        """Infer active frameworks from the collected import list."""
        ...

    def collect_definitions(
        self,
        file_trees: list[tuple[Path, ParseTree]],
        project_root: Path | None = None,
    ) -> dict[str, FunctionDefInfo]:
        """Build a name → definition map for all functions across *file_trees*."""
        ...

    def collect_call_sites(
        self,
        file_trees: list[tuple[Path, ParseTree]],
    ) -> list[CallSiteInfo]:
        """Collect every function call site found across *file_trees*."""
        ...

    def resolve_calls(
        self,
        definitions: dict[str, FunctionDefInfo],
        call_sites: list[CallSiteInfo],
        imports: list[ImportInfo],
    ) -> list[tuple[CallSiteInfo, FunctionDefInfo]]:
        """Match call sites to their definitions using import context."""
        ...

    def find_package_root(self, file_path: Path) -> Path | None:
        """Return the package root for *file_path*, or ``None`` if not found."""
        ...
