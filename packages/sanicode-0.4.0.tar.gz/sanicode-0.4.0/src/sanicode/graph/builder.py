"""Knowledge graph construction for data flow analysis.

Graph model:
  Nodes: entry_point, sanitizer, sink, trust_boundary
  Edges: data_flow (directed, from source toward sink)

The LLM reasons over this graph to assess whether sanitization
actually covers identified threat paths.
"""

from __future__ import annotations

import warnings
from collections import defaultdict
from pathlib import Path
from typing import Any

import networkx as nx

from sanicode.scanner.registry import get_registry
from sanicode.scanner.taint import analyze_file_taint, analyze_interprocedural_taint


class KnowledgeGraph:
    """In-memory knowledge graph backed by NetworkX DiGraph."""

    def __init__(self) -> None:
        self._graph: nx.DiGraph = nx.DiGraph()
        self._node_counter: int = 0

    def _next_id(self, prefix: str) -> str:
        self._node_counter += 1
        return f"{prefix}_{self._node_counter}"

    def add_entry_point(
        self,
        label: str,
        file: Path | None = None,
        line: int | None = None,
        **attrs: Any,
    ) -> str:
        """Add an entry point node (e.g., an HTTP handler, CLI argument reader).

        Returns:
            The node ID assigned to this entry point.
        """
        node_id = self._next_id("entry")
        self._graph.add_node(
            node_id,
            kind="entry_point",
            label=label,
            file=str(file) if file else None,
            line=line,
            **attrs,
        )
        return node_id

    def add_sink(
        self,
        label: str,
        file: Path | None = None,
        line: int | None = None,
        cwe_id: int | None = None,
        **attrs: Any,
    ) -> str:
        """Add a sink node (e.g., SQL query, shell command, eval call).

        Returns:
            The node ID assigned to this sink.
        """
        node_id = self._next_id("sink")
        self._graph.add_node(
            node_id,
            kind="sink",
            label=label,
            file=str(file) if file else None,
            line=line,
            cwe_id=cwe_id,
            **attrs,
        )
        return node_id

    def add_sanitizer(
        self,
        label: str,
        file: Path | None = None,
        line: int | None = None,
        **attrs: Any,
    ) -> str:
        """Add a sanitizer node (e.g., html.escape, parameterized query wrapper).

        Returns:
            The node ID assigned to this sanitizer.
        """
        node_id = self._next_id("sanitizer")
        self._graph.add_node(
            node_id,
            kind="sanitizer",
            label=label,
            file=str(file) if file else None,
            line=line,
            **attrs,
        )
        return node_id

    def add_import(
        self,
        label: str,
        file: Path | None = None,
        line: int | None = None,
        **attrs: Any,
    ) -> str:
        """Add an import node to the graph.

        Returns:
            The node ID assigned to this import.
        """
        node_id = self._next_id("import")
        self._graph.add_node(
            node_id,
            kind="import",
            label=label,
            file=str(file) if file else None,
            line=line,
            **attrs,
        )
        return node_id

    def add_data_flow(self, from_node: str, to_node: str, **attrs: Any) -> None:
        """Add a directed data-flow edge between two graph nodes.

        Args:
            from_node: ID of the upstream node.
            to_node: ID of the downstream node.
        """
        if from_node not in self._graph:
            raise ValueError(f"Source node not in graph: {from_node!r}")
        if to_node not in self._graph:
            raise ValueError(f"Target node not in graph: {to_node!r}")
        self._graph.add_edge(from_node, to_node, kind="data_flow", **attrs)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the graph to a plain dict (JSON-serializable).

        Returns a node-link format compatible with NetworkX's
        node_link_data / node_link_graph round-trip.
        """
        return nx.node_link_data(self._graph, edges="links")

    def nodes_by_kind(self, kind: str) -> list[tuple[str, dict]]:
        """Return all nodes of a given kind.

        Args:
            kind: Node kind to filter by (e.g. "entry_point", "sink", "sanitizer").

        Returns:
            List of (node_id, attrs) tuples for nodes whose ``kind`` attribute
            matches the requested value.
        """
        return [
            (node_id, attrs)
            for node_id, attrs in self._graph.nodes(data=True)
            if attrs.get("kind") == kind
        ]

    def node_counts_by_kind(self) -> dict[str, int]:
        """Count nodes grouped by kind in a single pass.

        More efficient than calling nodes_by_kind() per kind when you
        only need the counts.

        Returns:
            Mapping from kind name to node count.
        """
        counts: dict[str, int] = {}
        for _node_id, attrs in self._graph.nodes(data=True):
            kind = attrs.get("kind", "unknown")
            counts[kind] = counts.get(kind, 0) + 1
        return counts

    @classmethod
    def from_parsed(
        cls, file_trees: list[tuple[Path, Any]]
    ) -> KnowledgeGraph:
        """Build a KnowledgeGraph from pre-parsed ASTs.

        Use this when the caller has already parsed the files (e.g., to also
        run pattern detection on the same trees without re-parsing).

        Args:
            file_trees: List of (file_path, parsed_ast) pairs.

        Returns:
            A populated KnowledgeGraph with heuristic data-flow edges.
        """
        kg = cls()
        kg._populate(file_trees)
        return kg

    @classmethod
    def from_source(cls, path: Path) -> KnowledgeGraph:
        """Build a KnowledgeGraph by scanning a source path.

        Parses one Python file or all ``.py`` files under a directory, runs the
        three data-flow detectors, adds the results as graph nodes, and then
        constructs heuristic data-flow edges within each enclosing function.

        Args:
            path: Path to a Python file or directory to scan.

        Returns:
            A populated KnowledgeGraph.

        Raises:
            FileNotFoundError: If ``path`` does not exist.
        """
        path = path.resolve()
        if not path.exists():
            raise FileNotFoundError(f"Path does not exist: {path}")

        registry = get_registry()
        file_trees: list[tuple[Path, Any]] = []

        if path.is_file():
            plugin = registry.for_extension(path.suffix)
            if plugin is not None:
                tree = plugin.parse_file(path)
                if tree.root_node.has_error:
                    warnings.warn(
                        f"Skipping {path}: syntax error — tree-sitter parse error",
                        stacklevel=2,
                    )
                else:
                    file_trees.append((path, tree))
        else:
            for src_file in sorted(path.rglob("*")):
                plugin = registry.for_extension(src_file.suffix)
                if plugin is None:
                    continue
                tree = plugin.parse_file(src_file)
                if tree.root_node.has_error:
                    warnings.warn(
                        f"Skipping {src_file}: syntax error — tree-sitter parse error",
                        stacklevel=2,
                    )
                else:
                    file_trees.append((src_file, tree))

        kg = cls()
        kg._populate(file_trees)
        return kg

    def _populate(self, file_trees: list[tuple[Path, Any]]) -> None:
        """Detect data-flow primitives and build heuristic edges.

        Args:
            file_trees: List of (file_path, parse_tree) pairs.
        """
        registry = get_registry()

        # First pass: imports and framework detection.
        all_imports = []
        for file_path, tree in file_trees:
            plugin = registry.for_extension(file_path.suffix)
            if plugin is None:
                continue
            file_imports = plugin.detect_imports(tree, file_path)
            all_imports.extend(file_imports)
            for imp in file_imports:
                self.add_import(
                    label=imp.module,
                    file=imp.file,
                    line=imp.line,
                    is_from=imp.is_from,
                    names=imp.names,
                )

        # Detect frameworks using the plugin for the first file (all same language for now).
        frameworks = []
        if file_trees:
            first_plugin = registry.for_extension(file_trees[0][0].suffix)
            if first_plugin is not None:
                frameworks = first_plugin.detect_frameworks(all_imports)
        self._graph.graph["frameworks"] = [
            {"name": fw.name, "modules": fw.modules} for fw in frameworks
        ]

        # Second pass: data-flow primitives with framework awareness.
        by_function: dict[str, dict[str, list[str]]] = defaultdict(
            lambda: {"entries": [], "sanitizers": [], "sinks": []}
        )

        # Index for looking up graph node IDs by (file, line, label).
        # Used by taint analysis to connect TaintPaths to existing nodes.
        _node_index: dict[tuple[str, int, str], str] = {}

        # Collect per-file primitives for the taint pass.
        file_primitives: list[tuple[Path, Any, Any, list, list, list]] = []

        for file_path, tree in file_trees:
            plugin = registry.for_extension(file_path.suffix)
            if plugin is None:
                continue

            entry_points = plugin.detect_entry_points(tree, file_path)
            sinks = plugin.detect_sinks(tree, file_path, frameworks=frameworks)
            sanitizers = plugin.detect_sanitizers(tree, file_path)

            file_primitives.append(
                (file_path, tree, plugin, entry_points, sinks, sanitizers)
            )

            for ep in entry_points:
                node_id = self.add_entry_point(
                    label=ep.name,
                    file=ep.file,
                    line=ep.line,
                    entry_kind=ep.kind,
                    function=ep.function,
                )
                _node_index[(str(ep.file), ep.line, ep.name)] = node_id
                if ep.function is not None:
                    by_function[ep.function]["entries"].append(node_id)
                elif ep.kind == "http_handler":
                    # The function IS the entry point.  Sinks/sanitizers detected
                    # inside it will have function=ep.name, so group this entry
                    # under that same key so heuristic edges can be built.
                    by_function[ep.name]["entries"].append(node_id)

            for si in sinks:
                node_id = self.add_sink(
                    label=si.name,
                    file=si.file,
                    line=si.line,
                    cwe_id=si.cwe_id,
                    sink_kind=si.kind,
                    function=si.function,
                )
                _node_index[(str(si.file), si.line, si.name)] = node_id
                if si.function is not None:
                    by_function[si.function]["sinks"].append(node_id)

            for san in sanitizers:
                node_id = self.add_sanitizer(
                    label=san.name,
                    file=san.file,
                    line=san.line,
                    sanitizer_kind=san.kind,
                    function=san.function,
                )
                _node_index[(str(san.file), san.line, san.name)] = node_id
                if san.function is not None:
                    by_function[san.function]["sanitizers"].append(node_id)

        # Taint analysis pass: intra-procedural reaching-definitions.
        #
        # Runs after all nodes are registered so we can look them up by
        # (file, line, label) and add taint-confirmed edges.
        for file_path, tree, plugin, eps, sks, sans in file_primitives:
            taint_paths = analyze_file_taint(
                file_path, tree, plugin, eps, sks, sans,
            )
            for tp in taint_paths:
                source_key = (str(tp.source.file), tp.source.line, tp.source.source_name)
                sink_key = (str(file_path), tp.sink_line, tp.sink_name)
                source_node = _node_index.get(source_key)
                sink_node = _node_index.get(sink_key)
                if source_node and sink_node and not self._graph.has_edge(source_node, sink_node):
                    self.add_data_flow(
                        source_node,
                        sink_node,
                        confidence="taint_analysis",
                        sanitized=tp.is_sanitized,
                        sanitizers=tp.sanitizers,
                    )

        # Inter-procedural taint analysis pass: function-summary-based propagation.
        #
        # Detects the common pattern where a handler calls a helper function
        # that uses a sink, or where a helper sanitizes data before the sink.
        # Only adds edges not already present from the intra-procedural pass.
        cross_fn_paths = analyze_interprocedural_taint(file_trees, registry)
        for tp in cross_fn_paths:
            source_key = (str(tp.source.file), tp.source.line, tp.source.source_name)
            # The sink may live in a different file from the source; search all files.
            sink_node = None
            for candidate_file, _, _, _, _candidate_sinks, _ in file_primitives:
                sink_key = (str(candidate_file), tp.sink_line, tp.sink_name)
                sink_node = _node_index.get(sink_key)
                if sink_node:
                    break
            source_node = _node_index.get(source_key)
            if source_node and sink_node and not self._graph.has_edge(source_node, sink_node):
                self.add_data_flow(
                    source_node,
                    sink_node,
                    confidence="interprocedural_taint",
                    sanitized=tp.is_sanitized,
                    sanitizers=tp.sanitizers,
                    via_call=tp.via_call,
                )

        # Heuristic intra-function edge construction.
        #
        # For each function that has both entry points and sinks, create a
        # data-flow path.  When sanitizers are also present in the same function
        # they are chained in sequence: entry → san1 → san2 → … → sink.
        for _fn_name, groups in by_function.items():
            entries = groups["entries"]
            sinks = groups["sinks"]
            sans = groups["sanitizers"]

            if not entries or not sinks:
                continue

            for entry_id in entries:
                for sink_id in sinks:
                    if sans:
                        chain = [entry_id, *sans, sink_id]
                        for upstream, downstream in zip(chain, chain[1:], strict=False):
                            self.add_data_flow(
                                upstream, downstream, confidence="heuristic"
                            )
                    else:
                        self.add_data_flow(entry_id, sink_id, confidence="heuristic")

        # Cross-function edge construction via call graph analysis.
        #
        # For each resolved call, if the caller function has entry-point data
        # and the callee function has a sink, add a cross-function data flow edge.
        #
        # Use the plugin from the first file for aggregate operations (all same
        # language for now).
        if not file_trees:
            return

        first_plugin = registry.for_extension(file_trees[0][0].suffix)
        if first_plugin is None:
            return

        project_root = first_plugin.find_package_root(file_trees[0][0])
        definitions = first_plugin.collect_definitions(file_trees, project_root=project_root)
        call_sites = first_plugin.collect_call_sites(file_trees)
        resolved = first_plugin.resolve_calls(definitions, call_sites, all_imports)

        for site, target_def in resolved:
            caller_fn = site.caller
            callee_fn = target_def.name

            caller_entries = by_function.get(caller_fn, {}).get("entries", [])
            callee_sinks = by_function.get(callee_fn, {}).get("sinks", [])
            callee_sans = by_function.get(callee_fn, {}).get("sanitizers", [])

            if not caller_entries or not callee_sinks:
                continue

            for entry_id in caller_entries:
                for sink_id in callee_sinks:
                    if callee_sans:
                        chain = [entry_id, *callee_sans, sink_id]
                        for upstream, downstream in zip(chain, chain[1:], strict=False):
                            if not self._graph.has_edge(upstream, downstream):
                                self.add_data_flow(
                                    upstream, downstream, confidence="call_graph"
                                )
                    else:
                        if not self._graph.has_edge(entry_id, sink_id):
                            self.add_data_flow(
                                entry_id, sink_id, confidence="call_graph"
                            )

    @property
    def detected_frameworks(self) -> list[dict[str, Any]]:
        """Frameworks detected during graph construction.

        Returns:
            List of dicts with "name" and "modules" keys.
        """
        return self._graph.graph.get("frameworks", [])

    @property
    def node_count(self) -> int:
        """Number of nodes in the graph."""
        return self._graph.number_of_nodes()

    @property
    def edge_count(self) -> int:
        """Number of edges in the graph."""
        return self._graph.number_of_edges()

    def __repr__(self) -> str:
        return (
            f"KnowledgeGraph(nodes={self.node_count}, edges={self.edge_count})"
        )
