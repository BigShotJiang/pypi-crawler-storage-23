"""Interactive HTML visualizer for sanicode knowledge graphs.

Generates a self-contained HTML file that renders the knowledge graph
using Cytoscape.js with a dagre (hierarchical) layout.  No additional
Python dependencies are required — the JavaScript libraries are loaded
from a CDN at view time.
"""

from __future__ import annotations

import json

# ---------------------------------------------------------------------------
# HTML template
#
# Uses str.format() (not an f-string) so that the abundant CSS/JS curly
# braces don't need to be doubled.  The only placeholder is {graph_json}.
# ---------------------------------------------------------------------------

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sanicode &mdash; Knowledge Graph</title>
<style>
  *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}

  body {{
    font-family: 'Segoe UI', system-ui, sans-serif;
    background: #1a1a2e;
    color: #e0e0e0;
    display: flex;
    flex-direction: column;
    height: 100vh;
    overflow: hidden;
  }}

  /* ── top bar ── */
  #topbar {{
    background: #16213e;
    border-bottom: 1px solid #0f3460;
    padding: 8px 16px;
    display: flex;
    align-items: center;
    gap: 24px;
    flex-wrap: wrap;
    flex-shrink: 0;
  }}

  #topbar h1 {{
    font-size: 1rem;
    font-weight: 600;
    color: #4A90D9;
    white-space: nowrap;
  }}

  #stats {{
    font-size: 0.78rem;
    color: #aaa;
    white-space: nowrap;
  }}

  #stats span {{
    margin-right: 12px;
  }}

  /* ── filter checkboxes ── */
  #filters {{
    display: flex;
    gap: 14px;
    flex-wrap: wrap;
    margin-left: auto;
  }}

  .filter-item {{
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 0.8rem;
    cursor: pointer;
    user-select: none;
  }}

  .filter-item input[type=checkbox] {{
    accent-color: #4A90D9;
    width: 14px;
    height: 14px;
    cursor: pointer;
  }}

  .dot {{
    width: 10px;
    height: 10px;
    border-radius: 50%;
    flex-shrink: 0;
  }}

  /* ── main area ── */
  #main {{
    display: flex;
    flex: 1;
    overflow: hidden;
  }}

  /* ── graph canvas ── */
  #cy {{
    flex: 1;
    background: #0d1117;
  }}

  /* ── sidebar ── */
  #sidebar {{
    width: 280px;
    background: #16213e;
    border-left: 1px solid #0f3460;
    padding: 16px;
    overflow-y: auto;
    flex-shrink: 0;
    display: none;
  }}

  #sidebar.visible {{
    display: block;
  }}

  #sidebar h2 {{
    font-size: 0.9rem;
    font-weight: 600;
    margin-bottom: 12px;
    color: #4A90D9;
    border-bottom: 1px solid #0f3460;
    padding-bottom: 6px;
  }}

  #sidebar-close {{
    float: right;
    background: none;
    border: none;
    color: #aaa;
    cursor: pointer;
    font-size: 1rem;
    line-height: 1;
    padding: 2px 4px;
  }}

  #sidebar-close:hover {{
    color: #fff;
  }}

  .attr-row {{
    margin-bottom: 8px;
    font-size: 0.78rem;
  }}

  .attr-key {{
    color: #4A90D9;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.7rem;
    letter-spacing: 0.05em;
    display: block;
    margin-bottom: 2px;
  }}

  .attr-val {{
    color: #e0e0e0;
    word-break: break-all;
  }}

  .attr-val.null {{
    color: #666;
    font-style: italic;
  }}

  /* ── no-data message ── */
  #empty-msg {{
    display: none;
    color: #aaa;
    font-size: 0.85rem;
    padding: 32px 16px;
    text-align: center;
  }}
</style>
</head>
<body>

<div id="topbar">
  <h1>Sanicode &mdash; Knowledge Graph</h1>

  <div id="stats">
    <span id="stat-nodes">Nodes: 0</span>
    <span id="stat-edges">Edges: 0</span>
    <span id="stat-entry">Entry points: 0</span>
    <span id="stat-sinks">Sinks: 0</span>
    <span id="stat-sanitizers">Sanitizers: 0</span>
    <span id="stat-imports">Imports: 0</span>
  </div>

  <div id="filters">
    <label class="filter-item">
      <input type="checkbox" id="chk-entry_point" checked>
      <span class="dot" style="background:#4A90D9"></span>
      Entry points
    </label>
    <label class="filter-item">
      <input type="checkbox" id="chk-sink" checked>
      <span class="dot" style="background:#D94A4A"></span>
      Sinks
    </label>
    <label class="filter-item">
      <input type="checkbox" id="chk-sanitizer" checked>
      <span class="dot" style="background:#4AD94A"></span>
      Sanitizers
    </label>
    <label class="filter-item">
      <!-- Imports hidden by default — real scans can have hundreds -->
      <input type="checkbox" id="chk-import">
      <span class="dot" style="background:#999"></span>
      Imports
    </label>
    <label class="filter-item">
      <input type="checkbox" id="chk-other" checked>
      <span class="dot" style="background:#666"></span>
      Other
    </label>
  </div>
</div>

<div id="main">
  <div id="cy">
    <div id="empty-msg">No nodes to display. Try enabling more filter categories.</div>
  </div>

  <div id="sidebar">
    <h2 id="sidebar-title">
      Details
      <button id="sidebar-close" title="Close">&times;</button>
    </h2>
    <div id="sidebar-content"></div>
  </div>
</div>

<!-- CDN scripts -->
<script src="https://unpkg.com/cytoscape/dist/cytoscape.min.js"></script>
<script src="https://unpkg.com/dagre/dist/dagre.min.js"></script>
<script src="https://unpkg.com/cytoscape-dagre/cytoscape-dagre.js"></script>

<script>
const graphData = {graph_json};

// ── visual config ────────────────────────────────────────────────────────
const KIND_STYLE = {{
  entry_point: {{ color: '#4A90D9', shape: 'ellipse',   size: 32 }},
  sink:        {{ color: '#D94A4A', shape: 'diamond',   size: 34 }},
  sanitizer:   {{ color: '#4AD94A', shape: 'hexagon',   size: 32 }},
  import:      {{ color: '#999999', shape: 'ellipse',   size: 18 }},
  other:       {{ color: '#666666', shape: 'ellipse',   size: 24 }},
}};

function kindStyle(kind) {{
  return KIND_STYLE[kind] || KIND_STYLE.other;
}}

// ── build Cytoscape elements ─────────────────────────────────────────────
function buildElements() {{
  const hidden = new Set();
  ['entry_point','sink','sanitizer','import','other'].forEach(k => {{
    const chk = document.getElementById('chk-' + k);
    if (chk && !chk.checked) hidden.add(k);
  }});

  const elements = [];

  (graphData.nodes || []).forEach(node => {{
    const kind = node.kind || 'other';
    const ks = kindStyle(kind);
    const label = node.label || node.id || '';
    elements.push({{
      group: 'nodes',
      data: {{ id: node.id, label: label, kind: kind, ...node }},
      classes: kind,
      style: {{
        'display': hidden.has(kind) ? 'none' : 'element',
      }},
    }});
  }});

  (graphData.links || []).forEach((edge, idx) => {{
    const conf = edge.confidence || 'heuristic';
    elements.push({{
      group: 'edges',
      data: {{
        id: edge.id || ('e_' + idx),
        source: edge.source,
        target: edge.target,
        confidence: conf,
        kind: edge.kind || 'data_flow',
      }},
    }});
  }});

  return elements;
}}

// ── Cytoscape stylesheet ─────────────────────────────────────────────────
const cyStylesheet = [
  {{
    selector: 'node',
    style: {{
      'label': 'data(label)',
      'width': 'data(size)',
      'height': 'data(size)',
      'background-color': '#666',
      'color': '#e0e0e0',
      'font-size': '9px',
      'text-valign': 'bottom',
      'text-halign': 'center',
      'text-margin-y': '4px',
      'text-wrap': 'ellipsis',
      'text-max-width': '80px',
      'border-width': 1,
      'border-color': '#333',
    }},
  }},
  // per-kind colours & shapes
  ...Object.entries(KIND_STYLE).map(([kind, s]) => ({{
    selector: 'node.' + kind,
    style: {{
      'background-color': s.color,
      'shape': s.shape,
      'width': s.size,
      'height': s.size,
    }},
  }})),
  // selected node highlight
  {{
    selector: 'node:selected',
    style: {{
      'border-width': 3,
      'border-color': '#fff',
      'overlay-opacity': 0.15,
    }},
  }},
  // edges
  {{
    selector: 'edge',
    style: {{
      'curve-style': 'bezier',
      'target-arrow-shape': 'triangle',
      'arrow-scale': 1.2,
      'line-color': '#555',
      'target-arrow-color': '#555',
      'width': 1.5,
      'opacity': 0.75,
    }},
  }},
  {{
    selector: 'edge[confidence = "call_graph"]',
    style: {{
      'line-color': '#333',
      'target-arrow-color': '#333',
      'width': 2.5,
      'opacity': 1,
    }},
  }},
  {{
    selector: 'edge[confidence = "heuristic"]',
    style: {{
      'line-color': '#666',
      'target-arrow-color': '#666',
      'width': 1,
      'opacity': 0.6,
      'line-style': 'dashed',
    }},
  }},
  {{
    selector: 'edge:selected',
    style: {{
      'line-color': '#4A90D9',
      'target-arrow-color': '#4A90D9',
      'width': 2.5,
      'opacity': 1,
    }},
  }},
];

// ── layout ───────────────────────────────────────────────────────────────
function makeLayout() {{
  const useDagre = typeof dagre !== 'undefined';
  if (useDagre) {{
    return {{
      name: 'dagre',
      rankDir: 'TB',
      nodeSep: 50,
      rankSep: 80,
      padding: 30,
      animate: false,
    }};
  }}
  return {{
    name: 'cose',
    animate: false,
    padding: 30,
  }};
}}

// ── update node sizes from style map ────────────────────────────────────
function applySizes(cy) {{
  cy.nodes().forEach(n => {{
    const s = kindStyle(n.data('kind'));
    n.style({{ width: s.size, height: s.size }});
  }});
}}

// ── initialise Cytoscape ─────────────────────────────────────────────────
let cy;

function initCy() {{
  // Register dagre layout if available
  if (typeof cytoscape !== 'undefined' && typeof cytoscapeDagre !== 'undefined') {{
    cytoscape.use(cytoscapeDagre);
  }}

  cy = cytoscape({{
    container: document.getElementById('cy'),
    elements: buildElements(),
    style: cyStylesheet,
    layout: makeLayout(),
    minZoom: 0.05,
    maxZoom: 5,
    wheelSensitivity: 0.3,
  }});

  applySizes(cy);
  updateStats();

  // ── node click → sidebar ──
  cy.on('tap', 'node', function(evt) {{
    const node = evt.target;
    const data = node.data();
    showSidebar('Node: ' + (data.label || data.id), data);
  }});

  // ── edge click → sidebar ──
  cy.on('tap', 'edge', function(evt) {{
    const edge = evt.target;
    const data = edge.data();
    showSidebar('Edge', {{
      source: data.source,
      target: data.target,
      confidence: data.confidence,
      kind: data.kind,
    }});
  }});

  // ── background tap → close sidebar ──
  cy.on('tap', function(evt) {{
    if (evt.target === cy) closeSidebar();
  }});
}}

// ── stats bar ────────────────────────────────────────────────────────────
function updateStats() {{
  const nodes = graphData.nodes || [];
  const links = graphData.links || [];
  const counts = {{}};
  nodes.forEach(n => {{
    const k = n.kind || 'other';
    counts[k] = (counts[k] || 0) + 1;
  }});
  document.getElementById('stat-nodes').textContent =
    'Nodes: ' + nodes.length;
  document.getElementById('stat-edges').textContent =
    'Edges: ' + links.length;
  document.getElementById('stat-entry').textContent =
    'Entry points: ' + (counts.entry_point || 0);
  document.getElementById('stat-sinks').textContent =
    'Sinks: ' + (counts.sink || 0);
  document.getElementById('stat-sanitizers').textContent =
    'Sanitizers: ' + (counts.sanitizer || 0);
  document.getElementById('stat-imports').textContent =
    'Imports: ' + (counts.import || 0);
}}

// ── filter checkboxes ────────────────────────────────────────────────────
function applyFilters() {{
  const hidden = new Set();
  ['entry_point','sink','sanitizer','import','other'].forEach(k => {{
    const chk = document.getElementById('chk-' + k);
    if (chk && !chk.checked) hidden.add(k);
  }});

  cy.nodes().forEach(node => {{
    const kind = node.data('kind') || 'other';
    node.style('display', hidden.has(kind) ? 'none' : 'element');
  }});

  // Show helper message when nothing is visible
  const visibleCount = cy.nodes().filter(n => n.style('display') !== 'none').length;
  document.getElementById('empty-msg').style.display =
    visibleCount === 0 ? 'block' : 'none';
}}

document.querySelectorAll('#filters input[type=checkbox]').forEach(chk => {{
  chk.addEventListener('change', applyFilters);
}});

// ── sidebar helpers ───────────────────────────────────────────────────────
function showSidebar(title, attrs) {{
  document.getElementById('sidebar-title').childNodes[0].textContent = title + ' ';
  const content = document.getElementById('sidebar-content');
  content.innerHTML = '';

  // Exclude internal Cytoscape keys and the label (already in title)
  const skip = new Set(['id']);
  Object.entries(attrs).forEach(([key, val]) => {{
    if (skip.has(key)) return;
    const row = document.createElement('div');
    row.className = 'attr-row';
    const keyEl = document.createElement('span');
    keyEl.className = 'attr-key';
    keyEl.textContent = key;
    const valEl = document.createElement('span');
    valEl.className = 'attr-val' + (val === null || val === undefined ? ' null' : '');
    valEl.textContent = (val === null || val === undefined) ? 'null' : String(val);
    row.appendChild(keyEl);
    row.appendChild(valEl);
    content.appendChild(row);
  }});

  document.getElementById('sidebar').classList.add('visible');
}}

function closeSidebar() {{
  document.getElementById('sidebar').classList.remove('visible');
  if (cy) cy.elements().unselect();
}}

document.getElementById('sidebar-close').addEventListener('click', closeSidebar);

// ── boot ─────────────────────────────────────────────────────────────────
window.addEventListener('load', initCy);
</script>
</body>
</html>
"""


def generate_html(graph_data: dict) -> str:
    """Generate a standalone HTML page visualizing a knowledge graph.

    Args:
        graph_data: Dict produced by ``KnowledgeGraph.to_dict()``
            (NetworkX node-link format with ``edges="links"``).

    Returns:
        A complete HTML document as a string.
    """
    graph_json = json.dumps(graph_data, indent=2, default=str)
    return _HTML_TEMPLATE.format(graph_json=graph_json)
