"""Compliance cross-reference data shipped with the sanicode package."""
