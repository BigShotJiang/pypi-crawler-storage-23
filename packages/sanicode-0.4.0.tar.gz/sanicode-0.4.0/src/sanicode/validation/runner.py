"""Validation runner — measure scan quality across LLM pipeline stages."""

from __future__ import annotations

import copy
import json
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path

from sanicode.config import LLMTierConfig, SanicodeConfig

_log = logging.getLogger(__name__)

# Line tolerance: a finding is a TP if it lands within ±LINE_WINDOW lines of
# any expected finding for the same CWE. Matches the benchmark runner.
LINE_WINDOW = 3

# Pass configurations — which tiers are enabled for each pass.
PASS_CONFIGS: dict[str, list[str]] = {
    "static": [],
    "classify": ["fast"],
    "analyze": ["fast", "analysis"],
    "full": ["fast", "analysis", "reasoning"],
}


@dataclass
class GroundTruthEntry:
    """Expected findings for a single corpus file."""

    expected_findings: list[dict]  # each: {cwe_id: int, line: int, rule_id: str}
    ground_truth_vulnerable: bool
    llm_should_filter: bool = False
    category: str = ""  # "false_positive", "true_positive", "context_dependent"
    tests_capability: str = ""  # "classify", "analyze", "reason", "all"


@dataclass
class PassResult:
    """Results from a single validation pass."""

    pass_name: str
    tiers_enabled: list[str]
    true_positives: int = 0
    false_positives: int = 0
    false_negatives: int = 0
    precision: float | None = None
    recall: float | None = None
    f1: float | None = None
    scan_time_seconds: float = 0.0
    file_count: int = 0
    error_count: int = 0


@dataclass
class ValidationResult:
    """Complete validation results across all passes."""

    passes: list[PassResult] = field(default_factory=list)
    quality_delta: dict = field(default_factory=dict)
    corpus_dir: str = ""
    corpus_file_count: int = 0


def _make_pass_config(base_cfg: SanicodeConfig, enabled_tiers: list[str]) -> SanicodeConfig:
    """Deep-copy config and blank out LLM tiers not in enabled_tiers."""
    cfg = copy.deepcopy(base_cfg)
    for tier_name in ("fast", "analysis", "reasoning"):
        if tier_name not in enabled_tiers:
            setattr(cfg.llm, tier_name, LLMTierConfig())
    return cfg


def load_ground_truth(path: Path) -> dict[str, GroundTruthEntry]:
    """Load ground truth JSON file.

    Args:
        path: Path to the ground_truth.json file.

    Returns:
        Dict mapping corpus-relative file paths to GroundTruthEntry objects.
    """
    raw = json.loads(path.read_text(encoding="utf-8"))
    result: dict[str, GroundTruthEntry] = {}
    for file_key, data in raw.items():
        result[file_key] = GroundTruthEntry(
            expected_findings=data.get("expected_static_findings", []),
            ground_truth_vulnerable=data["ground_truth_vulnerable"],
            llm_should_filter=data.get("llm_should_filter", False),
            category=data.get("category", ""),
            tests_capability=data.get("tests_capability", ""),
        )
    return result


def _score_file(
    scan_findings: list,
    expected: list[dict],
    ground_truth_vulnerable: bool,
) -> tuple[int, int, int]:
    """Score findings against ground truth for a single file.

    A finding is a TP if its CWE matches an expected entry and the line
    number is within LINE_WINDOW. Each expected entry can only be claimed once.

    If the file is not actually vulnerable, ALL scan findings are false positives
    regardless of what the static scanner found.

    Args:
        scan_findings: EnrichedFinding objects from the scanner.
        expected: List of expected finding dicts with cwe_id and optional line.
        ground_truth_vulnerable: Whether this file has a real vulnerability.

    Returns:
        Tuple of (true_positives, false_positives, false_negatives).
    """
    if not ground_truth_vulnerable:
        # Every scanner finding on a safe file is a FP.
        return 0, len(scan_findings), 0

    claimed: set[int] = set()
    tp = 0

    for finding in scan_findings:
        for i, exp in enumerate(expected):
            if i in claimed:
                continue
            if finding.cwe_id != exp["cwe_id"]:
                continue
            exp_line = exp.get("line")
            if exp_line is None or abs(finding.line - exp_line) <= LINE_WINDOW:
                tp += 1
                claimed.add(i)
                break

    fp = len(scan_findings) - tp
    fn = len(expected) - tp
    return tp, fp, fn


def run_validation_pass(
    corpus_dir: Path,
    ground_truth: dict[str, GroundTruthEntry],
    cfg: SanicodeConfig,
    pass_name: str,
    tiers_enabled: list[str],
) -> PassResult:
    """Run a single validation pass over the entire corpus.

    Args:
        corpus_dir: Root of the validation corpus.
        ground_truth: Loaded ground truth entries.
        cfg: Base configuration to derive per-pass config from.
        pass_name: Human-readable name for this pass.
        tiers_enabled: Which LLM tiers are active for this pass.

    Returns:
        PassResult with aggregated TP/FP/FN and derived metrics.
    """
    from sanicode.scanner.executor import run_scan

    pass_cfg = _make_pass_config(cfg, tiers_enabled)
    result = PassResult(pass_name=pass_name, tiers_enabled=tiers_enabled)

    start = time.monotonic()
    for file_key, gt_entry in ground_truth.items():
        file_path = corpus_dir / file_key
        if not file_path.exists():
            _log.warning("Corpus file not found: %s", file_path)
            result.error_count += 1
            continue

        try:
            output = run_scan(file_path, pass_cfg)
            tp, fp, fn = _score_file(
                output.enriched_findings,
                gt_entry.expected_findings,
                gt_entry.ground_truth_vulnerable,
            )
            result.true_positives += tp
            result.false_positives += fp
            result.false_negatives += fn
            result.file_count += 1
        except Exception as exc:
            _log.warning("Scan failed for %s: %s", file_key, exc)
            result.error_count += 1
            if gt_entry.ground_truth_vulnerable:
                result.false_negatives += len(gt_entry.expected_findings)

    result.scan_time_seconds = time.monotonic() - start
    _compute_pass_metrics(result)
    return result


def _compute_pass_metrics(result: PassResult) -> None:
    """Compute precision, recall, and F1 in-place on a PassResult."""
    tp = result.true_positives
    fp = result.false_positives
    fn = result.false_negatives

    result.precision = tp / (tp + fp) if (tp + fp) > 0 else None
    result.recall = tp / (tp + fn) if (tp + fn) > 0 else None

    if result.precision is not None and result.recall is not None:
        denom = result.precision + result.recall
        result.f1 = (2 * result.precision * result.recall / denom) if denom > 0 else 0.0
    else:
        result.f1 = None


def _compute_delta(first: PassResult, last: PassResult) -> dict:
    """Compute quality delta between first and last pass.

    Args:
        first: The static-only baseline pass.
        last: The final (full LLM) pass.

    Returns:
        Dict with fp_reduction_pct, f1_delta, and optionally tp_change_pct.
    """
    delta: dict = {}

    if first.false_positives > 0:
        delta["fp_reduction_pct"] = (
            (first.false_positives - last.false_positives) / first.false_positives
        ) * 100
    else:
        delta["fp_reduction_pct"] = 0.0

    if first.f1 is not None and last.f1 is not None:
        delta["f1_delta"] = last.f1 - first.f1

    if first.true_positives > 0 and last.true_positives >= 0:
        delta["tp_change_pct"] = (
            (last.true_positives - first.true_positives) / first.true_positives
        ) * 100

    return delta


def run_validation(
    corpus_dir: Path,
    ground_truth_path: Path,
    cfg: SanicodeConfig,
    passes: list[str] | None = None,
) -> ValidationResult:
    """Run full validation across multiple pipeline passes.

    Each pass runs the entire corpus with a different set of LLM tiers
    enabled, showing how each tier contributes to quality improvement.

    Args:
        corpus_dir: Root of the validation corpus.
        ground_truth_path: Path to the ground_truth.json file.
        cfg: Base configuration (LLM settings are overridden per pass).
        passes: Which passes to run. Defaults to all four: static, classify,
            analyze, full.

    Returns:
        ValidationResult with all pass results and computed quality delta.
    """
    ground_truth = load_ground_truth(ground_truth_path)

    if passes is None:
        passes = list(PASS_CONFIGS.keys())

    validation = ValidationResult(
        corpus_dir=str(corpus_dir),
        corpus_file_count=len(ground_truth),
    )

    for pass_name in passes:
        if pass_name not in PASS_CONFIGS:
            _log.warning("Unknown pass name: %s — skipping", pass_name)
            continue
        tiers = PASS_CONFIGS[pass_name]
        _log.info(
            "Running validation pass: %s (tiers: %s)",
            pass_name,
            tiers or "none",
        )
        pass_result = run_validation_pass(
            corpus_dir, ground_truth, cfg, pass_name, tiers
        )
        validation.passes.append(pass_result)

    if len(validation.passes) >= 2:
        validation.quality_delta = _compute_delta(
            validation.passes[0], validation.passes[-1]
        )

    return validation


def bundled_corpus_dir() -> Path:
    """Return the path to the bundled LLM validation corpus.

    Walks up from src/sanicode/validation/ (3 parents) to the repo root,
    then into benchmarks/llm_validation/corpus/.
    """
    return (
        Path(__file__).parent.parent.parent.parent
        / "benchmarks"
        / "llm_validation"
        / "corpus"
    )


def bundled_ground_truth_path() -> Path:
    """Return the path to the bundled LLM validation ground truth."""
    return (
        Path(__file__).parent.parent.parent.parent
        / "benchmarks"
        / "llm_validation"
        / "ground_truth.json"
    )


def check_minimum_bar(result: ValidationResult) -> bool:
    """Check if validation results meet the minimum quality bar.

    The bar is met if FP reduction >= 15% OR TP increase >= 10%.

    Args:
        result: The completed ValidationResult.

    Returns:
        True if the bar is met (LLM integration is providing value).
    """
    delta = result.quality_delta
    if not delta:
        return False
    fp_reduction = delta.get("fp_reduction_pct", 0.0)
    tp_change = delta.get("tp_change_pct", 0.0)
    return fp_reduction >= 15.0 or tp_change >= 10.0
