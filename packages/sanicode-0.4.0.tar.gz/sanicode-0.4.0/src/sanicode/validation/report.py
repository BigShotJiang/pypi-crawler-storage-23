"""Validation report formatting — tables and JSON output."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

from sanicode.validation.runner import ValidationResult


def format_table(result: ValidationResult) -> str:
    """Format validation results as a plain-text comparison table.

    Args:
        result: Completed ValidationResult from run_validation().

    Returns:
        Multi-line string with a formatted table and delta summary.
    """
    header = (
        f"{'Pipeline Stage':<20} {'TP':>4} {'FP':>4} {'FN':>4}"
        f" {'Precision':>10} {'Recall':>8} {'F1':>8} {'Time':>8}"
    )
    lines = [header, "-" * len(header)]

    for p in result.passes:
        prec = f"{p.precision:.3f}" if p.precision is not None else "—"
        rec = f"{p.recall:.3f}" if p.recall is not None else "—"
        f1 = f"{p.f1:.3f}" if p.f1 is not None else "—"
        name = p.pass_name if p.pass_name == "static" else f"+ {p.pass_name}"
        lines.append(
            f"{name:<20} {p.true_positives:>4} {p.false_positives:>4}"
            f" {p.false_negatives:>4} {prec:>10} {rec:>8} {f1:>8}"
            f" {p.scan_time_seconds:>7.1f}s"
        )

    if result.quality_delta:
        lines.append("")
        parts = []
        if "fp_reduction_pct" in result.quality_delta:
            parts.append(f"FP reduction {result.quality_delta['fp_reduction_pct']:.1f}%")
        if "f1_delta" in result.quality_delta:
            parts.append(f"F1 {result.quality_delta['f1_delta']:+.3f}")
        if parts:
            first_name = result.passes[0].pass_name if result.passes else "static"
            last_name = result.passes[-1].pass_name if result.passes else "full"
            lines.append(
                f"Delta ({last_name} vs {first_name}): {', '.join(parts)}"
            )

    return "\n".join(lines)


def format_markdown(result: ValidationResult) -> str:
    """Format validation results as a markdown report.

    Args:
        result: Completed ValidationResult from run_validation().

    Returns:
        Markdown-formatted string with table and delta summary.
    """
    lines = ["# LLM Validation Results", ""]
    lines.append(
        f"Corpus: {result.corpus_dir} ({result.corpus_file_count} files)"
    )
    lines.append("")

    lines.append("| Pipeline Stage | TP | FP | FN | Precision | Recall | F1 | Time |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|---:|")

    for p in result.passes:
        prec = f"{p.precision:.3f}" if p.precision is not None else "—"
        rec = f"{p.recall:.3f}" if p.recall is not None else "—"
        f1 = f"{p.f1:.3f}" if p.f1 is not None else "—"
        name = p.pass_name if p.pass_name == "static" else f"+ {p.pass_name}"
        lines.append(
            f"| {name} | {p.true_positives} | {p.false_positives} |"
            f" {p.false_negatives} | {prec} | {rec} | {f1}"
            f" | {p.scan_time_seconds:.1f}s |"
        )

    if result.quality_delta:
        lines.append("")
        lines.append("## Quality Delta")
        if "fp_reduction_pct" in result.quality_delta:
            lines.append(
                f"- FP reduction: {result.quality_delta['fp_reduction_pct']:.1f}%"
            )
        if "f1_delta" in result.quality_delta:
            lines.append(f"- F1 delta: {result.quality_delta['f1_delta']:+.3f}")
        if "tp_change_pct" in result.quality_delta:
            lines.append(
                f"- TP change: {result.quality_delta['tp_change_pct']:+.1f}%"
            )

    return "\n".join(lines)


def save_json(result: ValidationResult, path: Path) -> None:
    """Save validation results as JSON.

    Args:
        result: Completed ValidationResult.
        path: Destination file path.
    """
    path.write_text(json.dumps(asdict(result), indent=2), encoding="utf-8")
