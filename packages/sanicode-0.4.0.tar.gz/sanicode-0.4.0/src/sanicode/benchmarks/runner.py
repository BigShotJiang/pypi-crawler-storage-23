"""Benchmark runner for comparing sanicode against external security tools.

Supports sanicode (native), bandit, and semgrep. External tools are skipped
gracefully when not installed. Each tool is scored against the bundled corpus
using precision, recall, and F1.
"""

from __future__ import annotations

import json
import logging
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

_log = logging.getLogger(__name__)

# Line tolerance: a finding is a TP if it lands within ±WINDOW lines of any
# expected finding for the same file and CWE.
LINE_WINDOW = 3


@dataclass
class BenchmarkFinding:
    """A normalized finding from any tool."""

    cwe_id: int
    line: int | None
    severity: str
    file: str  # relative to corpus_dir


@dataclass
class BenchmarkResult:
    """Precision/recall metrics for one tool on one corpus file."""

    tool: str
    corpus_file: str
    true_positives: int
    false_positives: int
    false_negatives: int
    precision: float | None
    recall: float | None
    f1: float | None
    duration_ms: float


def _compute_metrics(tp: int, fp: int, fn: int) -> tuple[float | None, float | None, float | None]:
    precision = tp / (tp + fp) if (tp + fp) > 0 else None
    recall = tp / (tp + fn) if (tp + fn) > 0 else None
    f1 = None
    if precision is not None and recall is not None and (precision + recall) > 0:
        f1 = 2 * precision * recall / (precision + recall)
    return precision, recall, f1


def _score_findings(
    tool_findings: list[BenchmarkFinding],
    expected: list[dict],
    corpus_file: str,
) -> tuple[int, int, int]:
    """Score tool findings against expected findings for one file.

    Returns (tp, fp, fn). A finding is a TP if its CWE matches an expected
    entry and the line number is within LINE_WINDOW (or expected has no line).
    Each expected finding can only be claimed as TP once.
    """
    matched_expected: set[int] = set()
    tp = 0
    fp = 0

    for finding in tool_findings:
        matched = False
        for i, exp in enumerate(expected):
            if i in matched_expected:
                continue
            if finding.cwe_id != exp["cwe_id"]:
                continue
            # Line check: if the expected entry has a line, enforce the window.
            exp_line = exp.get("line")
            if exp_line is not None and finding.line is not None:
                if abs(finding.line - exp_line) > LINE_WINDOW:
                    continue
            matched_expected.add(i)
            matched = True
            break

        if matched:
            tp += 1
        else:
            fp += 1

    fn = len(expected) - len(matched_expected)
    return tp, fp, fn


def load_ground_truth(ground_truth_path: Path) -> dict[str, list[dict]]:
    """Load and parse the ground truth JSON file.

    Returns a dict mapping corpus-relative file path to list of expected
    finding dicts (each with cwe_id, optional line, severity).
    """
    with ground_truth_path.open(encoding="utf-8") as fh:
        raw: dict[str, Any] = json.load(fh)
    result: dict[str, list[dict]] = {}
    for rel_path, entry in raw.items():
        result[rel_path] = entry.get("expected_findings", [])
    return result


def run_sanicode_benchmark(
    corpus_dir: Path,
    ground_truth: dict[str, list[dict]],
) -> list[BenchmarkResult]:
    """Run sanicode against the benchmark corpus.

    Scans each corpus file individually and scores results against the
    provided ground truth.

    Args:
        corpus_dir: Root of the benchmark corpus.
        ground_truth: Mapping from corpus-relative path to expected findings.

    Returns:
        One BenchmarkResult per corpus file in the ground truth.
    """
    from sanicode.config import SanicodeConfig
    from sanicode.scanner.executor import run_scan

    cfg = SanicodeConfig()
    results: list[BenchmarkResult] = []

    for rel_path, expected in ground_truth.items():
        file_path = corpus_dir / rel_path
        if not file_path.exists():
            _log.warning("Corpus file missing, skipping: %s", file_path)
            continue

        start = time.monotonic()
        try:
            scan_output = run_scan(file_path, cfg)
        except Exception as exc:
            _log.warning("sanicode scan failed for %s: %s", rel_path, exc)
            duration_ms = (time.monotonic() - start) * 1000
            tp, fp, fn = 0, 0, len(expected)
            precision, recall, f1 = _compute_metrics(tp, fp, fn)
            results.append(BenchmarkResult(
                tool="sanicode",
                corpus_file=rel_path,
                true_positives=tp,
                false_positives=fp,
                false_negatives=fn,
                precision=precision,
                recall=recall,
                f1=f1,
                duration_ms=duration_ms,
            ))
            continue

        duration_ms = (time.monotonic() - start) * 1000

        tool_findings = [
            BenchmarkFinding(
                cwe_id=ef.cwe_id,
                line=ef.line,
                severity=(ef.derived_severity or ef.severity),
                file=rel_path,
            )
            for ef in scan_output.enriched_findings
        ]

        tp, fp, fn = _score_findings(tool_findings, expected, rel_path)
        precision, recall, f1 = _compute_metrics(tp, fp, fn)

        results.append(BenchmarkResult(
            tool="sanicode",
            corpus_file=rel_path,
            true_positives=tp,
            false_positives=fp,
            false_negatives=fn,
            precision=precision,
            recall=recall,
            f1=f1,
            duration_ms=duration_ms,
        ))

    return results


def _parse_bandit_output(raw: dict, corpus_dir: Path) -> list[BenchmarkFinding]:
    """Parse bandit JSON output into normalized BenchmarkFindings."""
    # Bandit CWE format: {"id": "CWE-89", "link": "...", "name": "..."}
    findings: list[BenchmarkFinding] = []
    for issue in raw.get("results", []):
        cwe_info = issue.get("issue_cwe", {})
        cwe_str = cwe_info.get("id", "")
        try:
            cwe_id = int(cwe_str.replace("CWE-", "").strip())
        except (ValueError, AttributeError):
            continue

        line = issue.get("line_number")
        severity = issue.get("issue_severity", "medium").lower()

        file_abs = Path(issue.get("filename", ""))
        try:
            rel = str(file_abs.relative_to(corpus_dir))
        except ValueError:
            rel = str(file_abs)

        findings.append(BenchmarkFinding(cwe_id=cwe_id, line=line, severity=severity, file=rel))
    return findings


def run_bandit_benchmark(
    corpus_dir: Path,
    ground_truth: dict[str, list[dict]],
) -> list[BenchmarkResult]:
    """Run bandit against the benchmark corpus.

    Silently skips if bandit is not installed. Bandit is invoked per-file
    with JSON output and results are scored against the ground truth.

    Args:
        corpus_dir: Root of the benchmark corpus.
        ground_truth: Mapping from corpus-relative path to expected findings.

    Returns:
        One BenchmarkResult per corpus file, or empty list if bandit is absent.
    """
    if not shutil.which("bandit"):
        _log.info("bandit not found in PATH — skipping bandit benchmark")
        return []

    results: list[BenchmarkResult] = []

    for rel_path, expected in ground_truth.items():
        file_path = corpus_dir / rel_path
        if not file_path.exists():
            _log.warning("Corpus file missing, skipping: %s", file_path)
            continue

        start = time.monotonic()
        try:
            proc = subprocess.run(
                ["bandit", "-f", "json", "-q", str(file_path)],
                capture_output=True,
                text=True,
                timeout=60,
            )
            # bandit exits with code 1 when it finds issues, which is normal.
            raw = json.loads(proc.stdout) if proc.stdout.strip() else {}
        except (subprocess.TimeoutExpired, json.JSONDecodeError, Exception) as exc:
            _log.warning("bandit run failed for %s: %s", rel_path, exc)
            raw = {}

        duration_ms = (time.monotonic() - start) * 1000
        tool_findings = _parse_bandit_output(raw, corpus_dir)

        # Re-attach relative path for findings that bandit returned
        for f in tool_findings:
            f.file = rel_path

        tp, fp, fn = _score_findings(tool_findings, expected, rel_path)
        precision, recall, f1 = _compute_metrics(tp, fp, fn)

        results.append(BenchmarkResult(
            tool="bandit",
            corpus_file=rel_path,
            true_positives=tp,
            false_positives=fp,
            false_negatives=fn,
            precision=precision,
            recall=recall,
            f1=f1,
            duration_ms=duration_ms,
        ))

    return results


def _parse_semgrep_output(raw: dict, corpus_dir: Path, rel_path: str) -> list[BenchmarkFinding]:
    """Parse semgrep JSON output into normalized BenchmarkFindings."""
    findings: list[BenchmarkFinding] = []
    for result in raw.get("results", []):
        # Semgrep doesn't emit CWE IDs natively — derive from metadata tags.
        metadata = result.get("extra", {}).get("metadata", {})
        cwe_tags = metadata.get("cwe", [])
        if isinstance(cwe_tags, str):
            cwe_tags = [cwe_tags]

        cwe_id = None
        for tag in cwe_tags:
            try:
                cwe_id = int(str(tag).replace("CWE-", "").split(":")[0].strip())
                break
            except (ValueError, AttributeError):
                continue

        if cwe_id is None:
            continue

        line = result.get("start", {}).get("line")
        severity = result.get("extra", {}).get("severity", "warning").lower()
        # Normalize semgrep severity to sanicode vocabulary.
        severity_map = {"error": "high", "warning": "medium", "info": "low"}
        severity = severity_map.get(severity, severity)

        findings.append(
            BenchmarkFinding(cwe_id=cwe_id, line=line, severity=severity, file=rel_path)
        )
    return findings


def run_semgrep_benchmark(
    corpus_dir: Path,
    ground_truth: dict[str, list[dict]],
) -> list[BenchmarkResult]:
    """Run semgrep against the benchmark corpus.

    Silently skips if semgrep is not installed. Uses the community Python
    ruleset (p/python) for detection.

    Args:
        corpus_dir: Root of the benchmark corpus.
        ground_truth: Mapping from corpus-relative path to expected findings.

    Returns:
        One BenchmarkResult per corpus file, or empty list if semgrep is absent.
    """
    if not shutil.which("semgrep"):
        _log.info("semgrep not found in PATH — skipping semgrep benchmark")
        return []

    results: list[BenchmarkResult] = []

    for rel_path, expected in ground_truth.items():
        file_path = corpus_dir / rel_path
        if not file_path.exists():
            _log.warning("Corpus file missing, skipping: %s", file_path)
            continue

        start = time.monotonic()
        try:
            proc = subprocess.run(
                ["semgrep", "--config", "p/python", "--json", "--quiet", str(file_path)],
                capture_output=True,
                text=True,
                timeout=120,
            )
            raw = json.loads(proc.stdout) if proc.stdout.strip() else {}
        except (subprocess.TimeoutExpired, json.JSONDecodeError, Exception) as exc:
            _log.warning("semgrep run failed for %s: %s", rel_path, exc)
            raw = {}

        duration_ms = (time.monotonic() - start) * 1000
        tool_findings = _parse_semgrep_output(raw, corpus_dir, rel_path)

        tp, fp, fn = _score_findings(tool_findings, expected, rel_path)
        precision, recall, f1 = _compute_metrics(tp, fp, fn)

        results.append(BenchmarkResult(
            tool="semgrep",
            corpus_file=rel_path,
            true_positives=tp,
            false_positives=fp,
            false_negatives=fn,
            precision=precision,
            recall=recall,
            f1=f1,
            duration_ms=duration_ms,
        ))

    return results


def aggregate_results(results: list[BenchmarkResult]) -> dict:
    """Aggregate TP/FP/FN and compute overall precision/recall/F1."""
    tp = sum(r.true_positives for r in results)
    fp = sum(r.false_positives for r in results)
    fn = sum(r.false_negatives for r in results)
    precision, recall, f1 = _compute_metrics(tp, fp, fn)
    total_ms = sum(r.duration_ms for r in results)
    return {
        "tp": tp, "fp": fp, "fn": fn,
        "precision": precision, "recall": recall, "f1": f1,
        "total_duration_ms": total_ms,
    }


def compare_results(all_results: dict[str, list[BenchmarkResult]]) -> str:
    """Generate a human-readable comparison table across tools.

    Args:
        all_results: Mapping from tool name to list of BenchmarkResults.

    Returns:
        Formatted text comparison.
    """
    lines = ["Benchmark Results", "=" * 60, ""]

    for tool, results in all_results.items():
        if not results:
            lines.append(f"{tool}: no results (tool not installed?)")
            lines.append("")
            continue

        agg = aggregate_results(results)
        precision = f"{agg['precision']:.3f}" if agg["precision"] is not None else "N/A"
        recall = f"{agg['recall']:.3f}" if agg["recall"] is not None else "N/A"
        f1 = f"{agg['f1']:.3f}" if agg["f1"] is not None else "N/A"
        duration_s = agg["total_duration_ms"] / 1000

        lines.append(f"Tool: {tool}")
        lines.append(f"  TP={agg['tp']}  FP={agg['fp']}  FN={agg['fn']}")
        lines.append(f"  Precision={precision}  Recall={recall}  F1={f1}")
        lines.append(f"  Total time: {duration_s:.2f}s")
        lines.append("")

        # Per-file breakdown
        lines.append("  Per-file:")
        for r in sorted(results, key=lambda x: x.corpus_file):
            f1_str = f"{r.f1:.2f}" if r.f1 is not None else " N/A"
            lines.append(
                f"    {r.corpus_file:<40} "
                f"TP={r.true_positives} FP={r.false_positives} FN={r.false_negatives} "
                f"F1={f1_str}"
            )
        lines.append("")

    return "\n".join(lines)


def bundled_corpus_dir() -> Path:
    """Return the path to the bundled benchmark corpus.

    Walks up from src/sanicode/benchmarks/ (3 parents) to the repo root,
    then into benchmarks/corpus/.
    """
    return Path(__file__).parent.parent.parent.parent / "benchmarks" / "corpus"


def bundled_ground_truth_path() -> Path:
    """Return the path to the bundled ground truth JSON."""
    return Path(__file__).parent.parent.parent.parent / "benchmarks" / "ground_truth.json"
