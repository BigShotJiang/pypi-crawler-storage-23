"""DISA STIG Viewer checklist (.ckl) and summary report generators.

Produces .ckl XML files compatible with DISA STIG Viewer 2.x for use in
ATO (Authority to Operate) packages. One VULN element is emitted per STIG
Rule_Ver (e.g., APSC-DV-002510), with multiple sanicode findings for the
same rule grouped into a single FINDING_DETAILS block.

Reference: DISA STIG Viewer 2.18 .ckl schema.
"""

from __future__ import annotations

import json
from pathlib import Path
from xml.etree.ElementTree import Element, SubElement, tostring

from sanicode.report.persist import ScanResult

# ---------------------------------------------------------------------------
# Metadata loading
# ---------------------------------------------------------------------------

_META_FILENAME = "stig_checklist_meta.json"


def _find_meta_path() -> Path | None:
    """Locate stig_checklist_meta.json using the same strategy as compliance_db.json."""
    # Editable install / development: data/ relative to project root
    project_root = Path(__file__).resolve().parent.parent.parent.parent
    dev_path = project_root / "data" / _META_FILENAME
    if dev_path.is_file():
        return dev_path

    # Package-internal: sanicode/data/ is a sibling of sanicode/report/
    pkg_path = Path(__file__).resolve().parent.parent / "data" / _META_FILENAME
    if pkg_path.is_file():
        return pkg_path

    return None


def _load_meta() -> dict:
    """Load STIG checklist metadata. Returns empty dict on failure."""
    meta_path = _find_meta_path()
    if meta_path is None:
        return {}
    with open(meta_path, encoding="utf-8") as fh:
        return json.load(fh)


# ---------------------------------------------------------------------------
# Grouping helpers
# ---------------------------------------------------------------------------


def _group_findings_by_stig(findings: list[dict]) -> dict[str, list[dict]]:
    """Map each STIG Rule_Ver to the list of findings that reference it.

    A finding may reference multiple STIG rules (via compliance.asd_stig);
    it is included in each rule's group.
    """
    grouped: dict[str, list[dict]] = {}
    for finding in findings:
        compliance = finding.get("compliance") or {}
        stig_entries = compliance.get("asd_stig") or []
        for entry in stig_entries:
            rule_ver = entry.get("id", "")
            if not rule_ver:
                continue
            grouped.setdefault(rule_ver, []).append(finding)
    return grouped


def _finding_detail_line(finding: dict) -> str:
    """Format a single finding as a one-line detail string."""
    file_path = finding.get("file", "")
    line = finding.get("line", "")
    cwe_id = finding.get("cwe_id")
    message = finding.get("message", "")
    remediation = finding.get("remediation") or (
        (finding.get("compliance") or {}).get("remediation", "")
    )

    parts = [f"{file_path}:{line}"]
    if cwe_id is not None:
        parts.append(f"CWE-{cwe_id}")
    parts.append(message)
    detail = " — ".join(parts)
    if remediation:
        detail += f"  [Remediation: {remediation}]"
    return detail


# ---------------------------------------------------------------------------
# XML construction
# ---------------------------------------------------------------------------


def _build_asset_element(asset_config: dict) -> Element:
    """Build the <ASSET> XML element from the provided configuration dict."""
    asset = Element("ASSET")

    def _field(tag: str, text: str) -> None:
        el = SubElement(asset, tag)
        el.text = text

    _field("ROLE", "None")
    _field("ASSET_TYPE", "Computing")
    _field("HOST_NAME", asset_config.get("hostname", ""))
    _field("HOST_IP", asset_config.get("host_ip", ""))
    _field("HOST_MAC", "")
    _field("HOST_FQDN", asset_config.get("host_fqdn", ""))
    _field(
        "TARGET_COMMENT",
        asset_config.get("target_comment", "Sanicode automated STIG assessment"),
    )
    _field("TECH_AREA", asset_config.get("tech_area", ""))
    _field("TARGET_KEY", "0")
    _field("WEB_OR_DATABASE", "false")
    _field("WEB_DB_SITE", "")
    _field("WEB_DB_INSTANCE", "")
    return asset


def _build_stig_info_element(meta: dict) -> Element:
    """Build the <STIG_INFO> XML element from metadata."""
    stig_info = Element("STIG_INFO")

    def _si_data(name: str, data: str) -> None:
        si = SubElement(stig_info, "SI_DATA")
        sid_name = SubElement(si, "SID_NAME")
        sid_name.text = name
        sid_data = SubElement(si, "SID_DATA")
        sid_data.text = data

    _si_data("version", meta.get("stig_version", "4"))
    _si_data("releaseinfo", f"Release: {meta.get('stig_release', '11')}")
    _si_data(
        "title",
        meta.get("stig_title", "Application Security and Development STIG"),
    )
    return stig_info


def _build_vuln_element(
    rule_ver: str,
    rule_meta: dict,
    findings_for_rule: list[dict],
    sanicode_version: str,
) -> Element:
    """Build a single <VULN> XML element for one STIG Rule_Ver."""
    vuln = Element("VULN")

    def _stig_data(attribute: str, data: str) -> None:
        sd = SubElement(vuln, "STIG_DATA")
        va = SubElement(sd, "VULN_ATTRIBUTE")
        va.text = attribute
        ad = SubElement(sd, "ATTRIBUTE_DATA")
        ad.text = data

    _stig_data("Vuln_Num", rule_meta.get("vuln_num", ""))
    _stig_data("Severity", rule_meta.get("severity", "medium"))
    _stig_data("Rule_ID", rule_meta.get("rule_id", ""))
    _stig_data("Rule_Ver", rule_ver)
    _stig_data("Rule_Title", rule_meta.get("title", ""))

    for cci in rule_meta.get("cci_refs", []):
        _stig_data("CCI_REF", cci)

    # STATUS: Open if there are matching findings, else Not_Reviewed
    status_el = SubElement(vuln, "STATUS")
    status_el.text = "Open" if findings_for_rule else "Not_Reviewed"

    # FINDING_DETAILS: one line per finding
    details_el = SubElement(vuln, "FINDING_DETAILS")
    if findings_for_rule:
        details_el.text = "\n".join(
            _finding_detail_line(f) for f in findings_for_rule
        )
    else:
        details_el.text = ""

    comments_el = SubElement(vuln, "COMMENTS")
    comments_el.text = f"Automated assessment by sanicode v{sanicode_version}"

    severity_override_el = SubElement(vuln, "SEVERITY_OVERRIDE")
    severity_override_el.text = ""

    severity_justification_el = SubElement(vuln, "SEVERITY_JUSTIFICATION")
    severity_justification_el.text = ""

    return vuln


def _indent_xml(element: Element, level: int = 0) -> None:
    """Add pretty-print whitespace to an ElementTree in-place."""
    indent = "\n" + "  " * level
    if len(element):
        if not element.text or not element.text.strip():
            element.text = indent + "  "
        if not element.tail or not element.tail.strip():
            element.tail = indent
        for child in element:
            _indent_xml(child, level + 1)
        # last child tail
        if not child.tail or not child.tail.strip():  # type: ignore[possibly-undefined]
            child.tail = indent  # type: ignore[possibly-undefined]
    else:
        if level and (not element.tail or not element.tail.strip()):
            element.tail = indent


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def generate_stig_checklist(
    result: ScanResult,
    asset_config: dict | None = None,
) -> str:
    """Generate a DISA STIG Viewer compatible .ckl XML string.

    One <VULN> is produced per STIG Rule_Ver defined in the metadata file.
    Rules with matching findings receive STATUS=Open; all others receive
    STATUS=Not_Reviewed.

    Args:
        result: A ScanResult from the scanner.
        asset_config: Optional dict with asset metadata fields:
            hostname, host_ip, host_fqdn, target_comment, tech_area.
            All fields default to empty strings.

    Returns:
        A UTF-8 encoded XML string compatible with STIG Viewer 2.x.
    """
    if asset_config is None:
        asset_config = {}

    meta = _load_meta()
    rules_meta: dict[str, dict] = meta.get("rules", {})

    # Group scan findings by STIG Rule_Ver
    grouped = _group_findings_by_stig(result.findings)

    # Build XML tree
    checklist = Element("CHECKLIST")

    checklist.append(_build_asset_element(asset_config))

    stigs = SubElement(checklist, "STIGS")
    istig = SubElement(stigs, "iSTIG")

    istig.append(_build_stig_info_element(meta))

    # Emit one VULN per rule defined in metadata, in stable order
    for rule_ver, rule_meta in rules_meta.items():
        findings_for_rule = grouped.get(rule_ver, [])
        vuln_el = _build_vuln_element(
            rule_ver,
            rule_meta,
            findings_for_rule,
            result.sanicode_version,
        )
        istig.append(vuln_el)

    _indent_xml(checklist)

    xml_bytes = tostring(checklist, encoding="unicode")
    header = "<?xml version='1.0' encoding='UTF-8'?>\n<!--DISA STIG Viewer :: 2.18-->\n"
    return header + xml_bytes


def generate_stig_summary(result: ScanResult) -> str:
    """Generate a Markdown summary table of STIG compliance status.

    Args:
        result: A ScanResult from the scanner.

    Returns:
        A Markdown string with a per-rule status table and aggregate counts.
    """
    meta = _load_meta()
    rules_meta: dict[str, dict] = meta.get("rules", {})

    grouped = _group_findings_by_stig(result.findings)

    # Map CAT Roman numeral back to display label
    _severity_to_cat = {"high": "I", "medium": "II", "low": "III"}

    rows: list[tuple[str, str, str, str, int]] = []
    open_count = 0
    not_reviewed_count = 0

    for rule_ver, rule_meta in rules_meta.items():
        findings_for_rule = grouped.get(rule_ver, [])
        status = "Open" if findings_for_rule else "Not_Reviewed"
        severity = rule_meta.get("severity", "medium")
        cat = _severity_to_cat.get(severity, "II")
        title = rule_meta.get("title", "")
        # Truncate long titles for table readability
        if len(title) > 72:
            title = title[:69] + "..."
        rows.append((rule_ver, cat, title, status, len(findings_for_rule)))

        if status == "Open":
            open_count += 1
        else:
            not_reviewed_count += 1

    lines: list[str] = [
        "# STIG Compliance Summary",
        "",
        f"**Scanned:** {result.scanned_path}  ",
        f"**Date:** {result.scan_timestamp}  ",
        f"**Sanicode Version:** {result.sanicode_version}",
        f"**STIG:** Application Security and Development STIG v{meta.get('stig_version', '4')} "
        f"r{meta.get('stig_release', '11')}",
        "",
        "| STIG Rule | CAT | Title | Status | Findings |",
        "|-----------|-----|-------|--------|:--------:|",
    ]

    for rule_ver, cat, title, status, count in rows:
        status_label = f"**{status}**" if status == "Open" else status
        lines.append(f"| {rule_ver} | {cat} | {title} | {status_label} | {count} |")

    lines += [
        "",
        f"**Open:** {open_count}  ",
        f"**Not Reviewed:** {not_reviewed_count}  ",
        "**Not Applicable:** 0",
        "",
    ]

    return "\n".join(lines)
