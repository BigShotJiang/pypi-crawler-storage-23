"""Report subpackage — output generation in Markdown, JSON, and SARIF formats."""
