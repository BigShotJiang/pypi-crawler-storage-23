"""Ground truth loaders for sanicode scoring.

Reads synthetic-ground-truth.yaml and real-repos-catalog.yaml from the
unsanitary-code-examples repository and exposes structured dataclasses for
use by the scoring harness.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class SyntheticVuln:
    vuln_id: str
    cwe_id: str       # e.g. "CWE-89"
    severity: str     # Critical, High, Medium, Low
    file: str         # relative to base_path
    line: int
    end_line: int
    description: str


@dataclass
class SyntheticProject:
    name: str
    id: str
    language: str
    base_path: str    # e.g. "synthetic/wp-plugin-developer-toolkit/unmarked"
    vulnerabilities: list[SyntheticVuln] = field(default_factory=list)


@dataclass
class RealRepo:
    name: str
    language: list[str]
    type: str         # deliberately-vulnerable, ctf, test-suite, poc, tool, reference, workshop
    vuln_categories: list[str]  # e.g. ["CWE-79", "CWE-89"]
    has_ground_truth: bool
    scorable: bool    # False for type in {tool, reference}


@dataclass
class GroundTruth:
    synthetic_projects: list[SyntheticProject]
    real_repos: list[RealRepo]


_NON_SCORABLE_TYPES = {"tool", "reference"}


def _load_synthetic(path: Path) -> list[SyntheticProject]:
    """Parse synthetic-ground-truth.yaml into a list of SyntheticProject."""
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    projects: list[SyntheticProject] = []

    for entry in raw.get("projects", []):
        proj_meta = entry.get("project", {})
        base_path = entry.get("base_path", "")
        raw_vulns = entry.get("vulnerabilities", [])

        vulns: list[SyntheticVuln] = []
        for v in raw_vulns:
            vulns.append(
                SyntheticVuln(
                    vuln_id=v["vuln_id"],
                    cwe_id=v["cwe_id"],
                    severity=v["severity"],
                    file=v["file"],
                    line=int(v["line"]),
                    end_line=int(v.get("end_line", v["line"])),
                    description=v.get("description", ""),
                )
            )

        projects.append(
            SyntheticProject(
                name=proj_meta.get("name", ""),
                id=proj_meta.get("id", ""),
                language=proj_meta.get("language", ""),
                base_path=base_path,
                vulnerabilities=vulns,
            )
        )

    return projects


def _load_real_repos(path: Path) -> list[RealRepo]:
    """Parse real-repos-catalog.yaml into a list of RealRepo."""
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    repos: list[RealRepo] = []

    for entry in raw.get("repositories", []):
        repo_type = entry.get("type", "")
        lang = entry.get("language", [])
        # Normalize language to list — catalog may store a single string.
        if isinstance(lang, str):
            lang = [lang]

        repos.append(
            RealRepo(
                name=entry["name"],
                language=lang,
                type=repo_type,
                vuln_categories=entry.get("vuln_categories", []),
                has_ground_truth=bool(entry.get("has_ground_truth", False)),
                scorable=repo_type not in _NON_SCORABLE_TYPES,
            )
        )

    return repos


def load_ground_truth(scoring_dir: Path) -> GroundTruth:
    """Load both ground truth files from the scoring data directory.

    Expects the following layout inside ``scoring_dir``:
        synthetic-ground-truth.yaml
        real-repos-catalog.yaml

    Args:
        scoring_dir: Directory containing the two YAML ground-truth files.

    Returns:
        A populated GroundTruth with all synthetic projects and real repos.

    Raises:
        FileNotFoundError: If either YAML file is missing.
    """
    synthetic_path = scoring_dir / "synthetic-ground-truth.yaml"
    real_repos_path = scoring_dir / "real-repos-catalog.yaml"

    if not synthetic_path.exists():
        raise FileNotFoundError(f"Ground truth file not found: {synthetic_path}")
    if not real_repos_path.exists():
        raise FileNotFoundError(f"Real repos catalog not found: {real_repos_path}")

    return GroundTruth(
        synthetic_projects=_load_synthetic(synthetic_path),
        real_repos=_load_real_repos(real_repos_path),
    )
