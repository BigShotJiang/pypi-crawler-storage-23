"""Scoring rubric — CWE alias matching, metrics, and grade computation.

Implements the two-tier scoring model:
  Tier 1 — exact-match scoring against synthetic ground-truth projects with
            known vulnerability locations.
  Tier 2 — category-match scoring against real repositories where only CWE
            category membership can be asserted.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sanicode.scoring.ground_truth import RealRepo, SyntheticProject

# ---------------------------------------------------------------------------
# CWE alias table
# ---------------------------------------------------------------------------

# Maps canonical CWE → all accepted equivalents (including the canonical itself).
CWE_ALIASES: dict[str, set[str]] = {
    "CWE-89":   {"CWE-89", "CWE-564", "SQLI", "sql-injection", "A03:2021"},
    "CWE-79":   {"CWE-79", "CWE-80", "CWE-83", "CWE-87", "XSS",
                 "cross-site-scripting", "A03:2021"},
    "CWE-352":  {"CWE-352", "csrf", "cross-site-request-forgery", "A01:2021"},
    "CWE-434":  {"CWE-434", "unrestricted-upload", "A04:2021"},
    "CWE-22":   {"CWE-22", "CWE-23", "CWE-36", "path-traversal",
                 "directory-traversal"},
    "CWE-78":   {"CWE-78", "CWE-88", "command-injection", "os-injection"},
    "CWE-798":  {"CWE-798", "CWE-259", "CWE-321", "hardcoded-creds",
                 "hardcoded-password"},
    "CWE-862":  {"CWE-862", "CWE-285", "CWE-863", "authorization-bypass",
                 "missing-authorization"},
    "CWE-306":  {"CWE-306", "CWE-287", "missing-authentication",
                 "unauthenticated"},
    "CWE-94":   {"CWE-94", "CWE-95", "CWE-96", "eval-injection",
                 "code-injection"},
    "CWE-200":  {"CWE-200", "CWE-209", "CWE-497", "information-disclosure"},
    "CWE-639":  {"CWE-639", "insecure-direct-object-reference", "idor"},
    "CWE-312":  {"CWE-312", "CWE-256", "CWE-313", "cleartext-storage",
                 "plaintext-credentials"},
    "CWE-287":  {"CWE-287", "CWE-306", "authentication-bypass"},
    "CWE-346":  {"CWE-346", "cross-site-websocket-hijacking",
                 "websocket-hijacking"},
    "CWE-799":  {"CWE-799", "CWE-770", "CWE-400", "no-rate-limit",
                 "rate-limit-missing"},
    "CWE-359":  {"CWE-359", "CWE-200", "pii-leak", "data-exposure"},
    "CWE-319":  {"CWE-319", "CWE-311", "insecure-transport", "http-not-https"},
    "CWE-1321": {"CWE-1321", "prototype-pollution"},
    "CWE-532":  {"CWE-532", "CWE-313", "sensitive-data-in-logs",
                 "credentials-in-logs"},
    "CWE-190":  {"CWE-190", "CWE-191", "CWE-680", "integer-overflow"},
    "CWE-457":  {"CWE-457", "uninitialized-variable", "use-before-init"},
    "CWE-120":  {"CWE-120", "CWE-121", "CWE-122", "CWE-125",
                 "buffer-overflow", "stack-overflow"},
    "CWE-732":  {"CWE-732", "CWE-276", "world-readable",
                 "insecure-file-permissions"},
    "CWE-367":  {"CWE-367", "race-condition", "toctou", "time-of-check"},
    "CWE-269":  {"CWE-269", "CWE-250", "privilege-escalation",
                 "excessive-privileges"},
    "CWE-668":  {"CWE-668", "CWE-200", "information-exposure",
                 "shared-resource"},
    "CWE-311":  {"CWE-311", "CWE-312", "CWE-326", "encryption-at-rest",
                 "unencrypted-storage"},
    "CWE-778":  {"CWE-778", "missing-audit-log", "insufficient-logging",
                 "A09:2021"},
    "CWE-203":  {"CWE-203", "CWE-200", "user-enumeration",
                 "timing-side-channel"},
    "CWE-250":  {"CWE-250", "CWE-269", "least-privilege", "overprivileged"},
}

# Reverse lookup: alias → set of canonical CWEs that include it.
_REVERSE_ALIASES: dict[str, set[str]] = {}
for _canonical, _aliases in CWE_ALIASES.items():
    for _alias in _aliases:
        _REVERSE_ALIASES.setdefault(_alias, set()).add(_canonical)


# ---------------------------------------------------------------------------
# CWE normalization and matching
# ---------------------------------------------------------------------------

def normalize_cwe(value: str) -> str:
    """Normalize CWE identifiers: strip whitespace, uppercase CWE prefix."""
    value = value.strip()
    if value.upper().startswith("CWE-"):
        return "CWE-" + value[4:]
    return value


def cwe_matches(reported: str, expected: str) -> bool:
    """Check if a reported CWE matches an expected CWE via the alias table.

    Matching is bidirectional: the reported value may be an alias for the
    expected canonical, or the expected value may be an alias for the
    reported canonical. Literal equality after normalization also matches.
    """
    r = normalize_cwe(reported)
    e = normalize_cwe(expected)

    if r == e:
        return True

    # Check if r is an alias that maps to the same canonical as e.
    r_canonicals = _REVERSE_ALIASES.get(r, set())
    e_canonicals = _REVERSE_ALIASES.get(e, set())

    if r_canonicals & e_canonicals:
        return True

    # Direct membership: e is in r's alias set, or r is in e's alias set.
    r_aliases = CWE_ALIASES.get(r, set())
    e_aliases = CWE_ALIASES.get(e, set())

    return e in r_aliases or r in e_aliases


# ---------------------------------------------------------------------------
# Severity helpers
# ---------------------------------------------------------------------------

SEVERITY_LEVELS: dict[str, int] = {
    "critical": 4,
    "high": 3,
    "medium": 2,
    "low": 1,
    "info": 0,
}


def severity_penalty(reported: str, expected: str) -> float:
    """Return 1.0 for exact match, 0.5 for one level off, 0.25 for two+ levels off."""
    r = SEVERITY_LEVELS.get(reported.lower(), -1)
    e = SEVERITY_LEVELS.get(expected.lower(), -1)
    if r < 0 or e < 0:
        return 0.25
    diff = abs(r - e)
    if diff == 0:
        return 1.0
    if diff == 1:
        return 0.5
    return 0.25


# ---------------------------------------------------------------------------
# Tier 1 scoring (synthetic ground truth)
# ---------------------------------------------------------------------------

_LINE_LOOSE = 5   # +/- lines for a TP match
_LINE_TIGHT = 2   # +/- lines for the "tight" accuracy window


@dataclass
class Tier1Match:
    vuln_id: str
    finding: dict               # the scanner finding dict that matched
    file_match: bool
    cwe_match: bool
    line_match: bool            # within [line-5, end_line+5]
    line_tight: bool            # within [line-2, end_line+2]
    severity_match: bool
    severity_penalty: float     # 1.0, 0.5, or 0.25


@dataclass
class Tier1Result:
    project_name: str
    project_id: str
    matches: list[Tier1Match] = field(default_factory=list)
    tp: int = 0
    fp: int = 0
    fn: int = 0
    precision: float | None = None
    recall: float | None = None
    f1: float | None = None
    line_accuracy_rate: float | None = None
    severity_accuracy_rate: float | None = None


def _normalize_path(p: str) -> str:
    """Normalize separators and strip leading ./ for consistent comparison."""
    return Path(p).as_posix().lstrip("./")


def score_tier1(
    findings: list[dict],
    project: SyntheticProject,
    repo_base: Path,
) -> Tier1Result:
    """Score scanner findings against a synthetic ground-truth project.

    Each ground-truth vulnerability is matched against the findings list using
    file path, CWE, and line proximity. Duplicate suppression ensures a single
    finding cannot satisfy multiple vulnerabilities.

    Args:
        findings: List of finding dicts from ScanResult.findings. Each dict is
            expected to have at minimum: ``file`` (str), ``line`` (int or None),
            ``cwe_id`` (int), ``severity`` (str).
        project: The SyntheticProject to score against.
        repo_base: Absolute path to the root of the scanned repository. Used to
            anchor the project's base_path for file comparisons.

    Returns:
        A populated Tier1Result with TP/FP/FN counts and derived metrics.
    """
    result = Tier1Result(project_name=project.name, project_id=project.id)

    # Pre-compute a normalized CWE string for each finding once.
    norm_findings = []
    for f in findings:
        raw_cwe = f.get("cwe_id")
        cwe_str = f"CWE-{raw_cwe}" if isinstance(raw_cwe, int) else str(raw_cwe or "")
        norm_findings.append(
            {
                **f,
                "_cwe_norm": normalize_cwe(cwe_str),
                "_file_norm": _normalize_path(f.get("file", "")),
            }
        )

    matched_finding_indices: set[int] = set()

    for vuln in project.vulnerabilities:
        vuln_file_norm = _normalize_path(
            str(Path(project.base_path) / vuln.file)
        )
        vuln_cwe_norm = normalize_cwe(vuln.cwe_id)

        best_idx: int | None = None
        best_line_match = False
        best_line_tight = False

        for idx, nf in enumerate(norm_findings):
            if idx in matched_finding_indices:
                continue

            file_ok = nf["_file_norm"] == vuln_file_norm
            cwe_ok = cwe_matches(nf["_cwe_norm"], vuln_cwe_norm)

            if not (file_ok and cwe_ok):
                continue

            finding_line = nf.get("line")
            if finding_line is None:
                # File + CWE match without a line is sufficient.
                line_ok = True
                tight_ok = False
            else:
                line_ok = (
                    vuln.line - _LINE_LOOSE <= finding_line <= vuln.end_line + _LINE_LOOSE
                )
                tight_ok = (
                    vuln.line - _LINE_TIGHT <= finding_line <= vuln.end_line + _LINE_TIGHT
                )

            if not line_ok:
                continue

            # Prefer tight matches; take first qualifying match.
            if best_idx is None or (tight_ok and not best_line_tight):
                best_idx = idx
                best_line_match = line_ok
                best_line_tight = tight_ok

        if best_idx is not None:
            nf = norm_findings[best_idx]
            matched_finding_indices.add(best_idx)
            sev_reported = nf.get("severity", "")
            sev_penalty = severity_penalty(sev_reported, vuln.severity)
            result.matches.append(
                Tier1Match(
                    vuln_id=vuln.vuln_id,
                    finding=findings[best_idx],
                    file_match=True,
                    cwe_match=True,
                    line_match=best_line_match,
                    line_tight=best_line_tight,
                    severity_match=(sev_penalty == 1.0),
                    severity_penalty=sev_penalty,
                )
            )
            result.tp += 1
        else:
            result.fn += 1

    # Findings that didn't match any vuln are FP.
    result.fp = len(findings) - len(matched_finding_indices)

    # Derived metrics.
    if result.tp + result.fp > 0:
        result.precision = result.tp / (result.tp + result.fp)
    if result.tp + result.fn > 0:
        result.recall = result.tp / (result.tp + result.fn)
    if result.precision is not None and result.recall is not None:
        p, r = result.precision, result.recall
        result.f1 = (2 * p * r / (p + r)) if (p + r) > 0 else 0.0

    if result.tp > 0:
        tight_count = sum(1 for m in result.matches if m.line_tight)
        result.line_accuracy_rate = tight_count / result.tp
        exact_sev_count = sum(1 for m in result.matches if m.severity_match)
        result.severity_accuracy_rate = exact_sev_count / result.tp

    return result


# ---------------------------------------------------------------------------
# Tier 2 scoring (real repositories)
# ---------------------------------------------------------------------------

VENDORED_DIRS: set[str] = {
    "node_modules", "vendor", ".git", "Pods", "build", "dist", "__pycache__",
}

NON_CODE_EXTENSIONS: set[str] = {
    ".md", ".txt", ".rst", ".json", ".yaml", ".yml",
    ".xml", ".csv", ".lock",
}


@dataclass
class Tier2Result:
    repo_name: str
    tp: int = 0
    fp: int = 0
    precision: float | None = None


def score_tier2(
    findings: list[dict],
    repo: RealRepo,
) -> Tier2Result:
    """Score scanner findings against a real repository's known CWE categories.

    Since real repositories don't provide line-level ground truth, this tier
    only measures whether each finding's CWE falls within a category that is
    known to be present in the repository. Precision is computed; recall is
    not meaningful here.

    Findings in vendored directories or non-code files are excluded before
    scoring to avoid inflating FP counts.

    Args:
        findings: List of finding dicts from ScanResult.findings.
        repo: The RealRepo to score against.

    Returns:
        A Tier2Result. If repo.scorable is False, returns a result with all
        zeros and no precision.
    """
    result = Tier2Result(repo_name=repo.name)

    if not repo.scorable:
        return result

    for finding in findings:
        file_path = finding.get("file", "")
        parts = Path(file_path).parts

        # Exclude vendored directories.
        if any(part in VENDORED_DIRS for part in parts):
            continue

        # Exclude non-code files.
        ext = Path(file_path).suffix.lower()
        if ext in NON_CODE_EXTENSIONS:
            continue

        raw_cwe = finding.get("cwe_id")
        cwe_str = f"CWE-{raw_cwe}" if isinstance(raw_cwe, int) else str(raw_cwe or "")
        cwe_norm = normalize_cwe(cwe_str)

        matched = any(
            cwe_matches(cwe_norm, normalize_cwe(cat))
            for cat in repo.vuln_categories
        )
        if matched:
            result.tp += 1
        else:
            result.fp += 1

    if result.tp + result.fp > 0:
        result.precision = result.tp / (result.tp + result.fp)

    return result


# ---------------------------------------------------------------------------
# Grade computation
# ---------------------------------------------------------------------------

def compute_grade(recall: float | None, precision: float | None) -> str:
    """Return A-F grade based on rubric thresholds.

    Grade scale:
        A: recall >= 0.85 and precision >= 0.80
        B: recall >= 0.70 and precision >= 0.70
        C: recall >= 0.55 and precision >= 0.60
        D: recall >= 0.40 and precision >= 0.50
        F: anything else (including None metrics)
    """
    if recall is None or precision is None:
        return "F"
    if recall >= 0.85 and precision >= 0.80:
        return "A"
    if recall >= 0.70 and precision >= 0.70:
        return "B"
    if recall >= 0.55 and precision >= 0.60:
        return "C"
    if recall >= 0.40 and precision >= 0.50:
        return "D"
    return "F"
