"""LLM-as-judge evaluation of scanner findings against ground truth.

If no LLM is configured, the judge step is skipped — mechanical scores
from rubric.py are still produced. This matches sanicode's degraded mode.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

from sanicode.llm.client import LLMClient, LLMNotConfiguredError
from sanicode.llm.prompts import render_prompt

if TYPE_CHECKING:
    from sanicode.scoring.ground_truth import RealRepo, SyntheticProject
    from sanicode.scoring.rubric import Tier1Result, Tier2Result

_log = logging.getLogger(__name__)


@dataclass
class JudgeAssessment:
    """Qualitative evaluation from the LLM judge for one repo."""

    repo_name: str
    finding_quality: str       # narrative on quality of descriptions
    severity_calibration: str  # narrative on severity accuracy
    coverage_assessment: str   # narrative on coverage gaps
    fp_analysis: str           # narrative on false positives
    grade_justification: str   # overall narrative summary
    raw_response: str = ""     # full LLM response for debugging


def judge_repo(
    llm: LLMClient,
    repo_name: str,
    ground_truth_summary: str,
    findings_summary: str,
    mechanical_score_summary: str,
) -> JudgeAssessment | None:
    """Ask the LLM to evaluate scanner findings against ground truth.

    Returns a JudgeAssessment if the reasoning tier is available, None otherwise.
    A None return is not an error — callers should treat it as "judge unavailable".
    """
    if not llm.has_tier("reasoning"):
        return None

    try:
        prompt = render_prompt(
            "score_judge",
            ground_truth=ground_truth_summary,
            findings=findings_summary,
            mechanical_score=mechanical_score_summary,
        )
        response = llm.reason(prompt)
    except LLMNotConfiguredError:
        return None
    except Exception as exc:
        _log.warning("LLM judge failed for %s: %s", repo_name, exc)
        return None

    raw = response.content
    try:
        data = json.loads(raw)
        return JudgeAssessment(
            repo_name=repo_name,
            finding_quality=data.get("finding_quality", ""),
            severity_calibration=data.get("severity_calibration", ""),
            coverage_assessment=data.get("coverage_assessment", ""),
            fp_analysis=data.get("fp_analysis", ""),
            grade_justification=data.get("grade_justification", ""),
            raw_response=raw,
        )
    except (json.JSONDecodeError, AttributeError):
        return JudgeAssessment(
            repo_name=repo_name,
            finding_quality="",
            severity_calibration="",
            coverage_assessment="",
            fp_analysis="",
            grade_justification=raw,
            raw_response=raw,
        )


def format_ground_truth_tier1(project: SyntheticProject) -> str:
    """Format a synthetic project's ground truth as a human-readable summary."""
    lines = [f"Project: {project.name} ({project.language})"]
    lines.append(f"Known vulnerabilities: {len(project.vulnerabilities)}")
    for v in project.vulnerabilities:
        lines.append(
            f"  {v.vuln_id}: {v.cwe_id} ({v.severity}) in {v.file}:{v.line}-{v.end_line}"
        )
        lines.append(f"    {v.description[:120]}")
    return "\n".join(lines)


def format_ground_truth_tier2(repo: RealRepo) -> str:
    """Format a real repo's known vulnerability categories as a human-readable summary."""
    lines = [f"Repository: {repo.name} ({', '.join(repo.language)})"]
    lines.append(f"Type: {repo.type}")
    lines.append(f"Known vulnerability categories: {', '.join(repo.vuln_categories)}")
    return "\n".join(lines)


def format_findings(findings: list[dict]) -> str:
    """Format scanner findings for the LLM judge prompt.

    Caps output at 30 findings to avoid exceeding model context limits.
    """
    if not findings:
        return "No findings reported."
    lines = [f"Total findings: {len(findings)}"]
    for f in findings[:30]:
        cwe = f.get("cwe_id", "?")
        sev = f.get("severity", "?")
        file = f.get("file", "?")
        line = f.get("line", "?")
        msg = f.get("message", "")[:100]
        lines.append(f"  CWE-{cwe} ({sev}) {file}:{line} — {msg}")
    if len(findings) > 30:
        lines.append(f"  ... and {len(findings) - 30} more findings")
    return "\n".join(lines)


def format_mechanical_score_tier1(result: Tier1Result) -> str:
    """Format Tier 1 mechanical scoring results for the judge prompt."""
    precision = f"{result.precision:.2f}" if result.precision is not None else "N/A"
    recall = f"{result.recall:.2f}" if result.recall is not None else "N/A"
    f1 = f"{result.f1:.2f}" if result.f1 is not None else "N/A"
    return "\n".join([
        f"True Positives: {result.tp}",
        f"False Positives: {result.fp}",
        f"False Negatives: {result.fn}",
        f"Precision: {precision}",
        f"Recall: {recall}",
        f"F1: {f1}",
    ])


def format_mechanical_score_tier2(result: Tier2Result) -> str:
    """Format Tier 2 mechanical scoring results for the judge prompt."""
    precision = f"{result.precision:.2f}" if result.precision is not None else "N/A"
    return "\n".join([
        f"True Positives: {result.tp}",
        f"False Positives: {result.fp}",
        f"Precision: {precision}",
    ])
