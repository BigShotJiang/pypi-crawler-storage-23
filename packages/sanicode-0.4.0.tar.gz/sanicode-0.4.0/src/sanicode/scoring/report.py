"""Report generation for scoring harness — JSON output and human-readable summary."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

from sanicode import __version__

if TYPE_CHECKING:
    from sanicode.scoring.judge import JudgeAssessment
    from sanicode.scoring.rubric import Tier1Result, Tier2Result


@dataclass
class RepoScore:
    """Scoring result for a single repo."""

    name: str
    tier: int  # 1 or 2
    had_scannable_files: bool
    findings_count: int
    tier1_result: Tier1Result | None = None
    tier2_result: Tier2Result | None = None
    judge_assessment: JudgeAssessment | None = None


@dataclass
class ScoringReport:
    """Aggregate scoring report across all repos."""

    repos_dir: str
    per_repo: list[RepoScore] = field(default_factory=list)

    @property
    def repos_scanned(self) -> int:
        return len(self.per_repo)

    @property
    def repos_with_findings(self) -> int:
        return sum(1 for r in self.per_repo if r.findings_count > 0)

    def aggregate_tier1(self) -> dict:
        """Aggregate TP/FP/FN and derived metrics across all Tier 1 projects."""
        tp = fp = fn = 0
        for r in self.per_repo:
            if r.tier1_result:
                tp += r.tier1_result.tp
                fp += r.tier1_result.fp
                fn += r.tier1_result.fn
        precision = tp / (tp + fp) if (tp + fp) > 0 else None
        recall = tp / (tp + fn) if (tp + fn) > 0 else None
        f1 = None
        if precision is not None and recall is not None and (precision + recall) > 0:
            f1 = 2 * precision * recall / (precision + recall)
        return {"tp": tp, "fp": fp, "fn": fn, "precision": precision, "recall": recall, "f1": f1}

    def aggregate_tier2(self) -> dict:
        """Aggregate TP/FP and precision across all Tier 2 repos."""
        tp = fp = 0
        for r in self.per_repo:
            if r.tier2_result:
                tp += r.tier2_result.tp
                fp += r.tier2_result.fp
        precision = tp / (tp + fp) if (tp + fp) > 0 else None
        return {"tp": tp, "fp": fp, "precision": precision}


def generate_json_report(report: ScoringReport) -> dict:
    """Build the full JSON scoring report dict."""
    from sanicode.scoring.rubric import compute_grade

    tier1_agg = report.aggregate_tier1()
    tier2_agg = report.aggregate_tier2()
    grade = compute_grade(tier1_agg.get("recall"), tier1_agg.get("precision"))

    per_repo_list = []
    for r in report.per_repo:
        entry: dict = {
            "name": r.name,
            "tier": r.tier,
            "had_scannable_files": r.had_scannable_files,
            "findings_count": r.findings_count,
        }
        if r.tier1_result:
            entry["tier1"] = {
                "tp": r.tier1_result.tp,
                "fp": r.tier1_result.fp,
                "fn": r.tier1_result.fn,
                "precision": r.tier1_result.precision,
                "recall": r.tier1_result.recall,
                "f1": r.tier1_result.f1,
                "line_accuracy_rate": r.tier1_result.line_accuracy_rate,
                "severity_accuracy_rate": r.tier1_result.severity_accuracy_rate,
            }
        if r.tier2_result:
            entry["tier2"] = {
                "tp": r.tier2_result.tp,
                "fp": r.tier2_result.fp,
                "precision": r.tier2_result.precision,
            }
        if r.judge_assessment:
            entry["llm_assessment"] = {
                "finding_quality": r.judge_assessment.finding_quality,
                "severity_calibration": r.judge_assessment.severity_calibration,
                "coverage_assessment": r.judge_assessment.coverage_assessment,
                "fp_analysis": r.judge_assessment.fp_analysis,
                "grade_justification": r.judge_assessment.grade_justification,
            }
        per_repo_list.append(entry)

    return {
        "sanicode_version": __version__,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "repos_dir": report.repos_dir,
        "aggregate": {
            "repos_scanned": report.repos_scanned,
            "repos_with_findings": report.repos_with_findings,
            "tier1": tier1_agg,
            "tier2": tier2_agg,
            "grade": grade,
        },
        "per_repo": per_repo_list,
    }


def generate_summary(report: ScoringReport) -> str:
    """Generate a human-readable summary for terminal output."""
    from sanicode.scoring.rubric import compute_grade

    tier1_agg = report.aggregate_tier1()
    tier2_agg = report.aggregate_tier2()
    grade = compute_grade(tier1_agg.get("recall"), tier1_agg.get("precision"))

    tier1_projects = sum(1 for r in report.per_repo if r.tier == 1)
    tier1_with_files = sum(1 for r in report.per_repo if r.tier == 1 and r.had_scannable_files)
    tier2_repos = sum(1 for r in report.per_repo if r.tier == 2)
    tier2_with_findings = sum(
        1 for r in report.per_repo if r.tier == 2 and r.findings_count > 0
    )

    tier1_tp = tier1_agg.get("tp", 0)
    tier1_fn = tier1_agg.get("fn", 0)
    total_vulns = tier1_tp + tier1_fn

    recall_str = (
        f"{tier1_agg['recall']:.2f}" if tier1_agg.get("recall") is not None else "N/A"
    )
    precision_t1 = (
        f"{tier1_agg['precision']:.2f}" if tier1_agg.get("precision") is not None else "N/A"
    )
    precision_t2 = (
        f"{tier2_agg['precision']:.2f}" if tier2_agg.get("precision") is not None else "N/A"
    )
    tier2_tp = tier2_agg.get("tp", 0)
    tier2_total = tier2_tp + tier2_agg.get("fp", 0)

    return "\n".join([
        f"Sanicode Scoring Report — v{__version__}",
        "=" * 50,
        "",
        "Tier 1 (Synthetic — line-level precision):",
        f"  Projects scanned: {tier1_projects} ({tier1_with_files} with scannable files)",
        f"  Recall: {recall_str} ({tier1_tp}/{total_vulns} vulns detected)",
        f"  Precision: {precision_t1}",
        "",
        "Tier 2 (Real repos — categorical):",
        f"  Repos scanned: {tier2_repos}",
        f"  Repos with findings: {tier2_with_findings}",
        f"  Precision: {precision_t2} ({tier2_tp} TP / {tier2_total} total findings)",
        "",
        f"Overall grade: {grade}",
    ])


def save_report(report: ScoringReport, output_dir: Path) -> Path:
    """Write the scoring report as JSON to output_dir/scoring-report.json.

    Args:
        report: The scoring report to serialize.
        output_dir: Destination directory (created if it does not exist).

    Returns:
        Path to the written JSON file.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    data = generate_json_report(report)
    out_path = output_dir / "scoring-report.json"
    out_path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
    return out_path
