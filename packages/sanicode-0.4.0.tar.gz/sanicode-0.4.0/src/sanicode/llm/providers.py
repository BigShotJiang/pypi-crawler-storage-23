"""Provider registry for sanicode LLM backends.

This is a pure data module with no sanicode imports. It defines the known
LLM providers, their LiteLLM prefixes, authentication requirements, and
suggested model assignments for each analysis tier (fast / analysis / reasoning).

Consumers (config wizard, CLI, client) import from here to drive provider
selection without duplicating the registry in multiple places.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TierSuggestion:
    """Suggested model for a single analysis tier."""

    tier: str   # "fast" | "analysis" | "reasoning"
    model: str


@dataclass(frozen=True)
class ProviderInfo:
    """Describes one LLM provider supported by sanicode."""

    name: str                           # sanicode key, e.g. "vllm"
    display_name: str                   # human-readable, e.g. "vLLM (self-hosted)"
    litellm_prefix: str                 # prefix used in LiteLLM model strings
    requires_endpoint: bool             # True for self-hosted providers
    needs_api_key: bool                 # True for cloud API providers
    auth_env_vars: tuple[str, ...]      # env var names shown in config hints
    suggestions: tuple[TierSuggestion, ...]  # default model suggestions per tier
    endpoint_hint: str = ""             # example URL shown in the config wizard


# ---------------------------------------------------------------------------
# Provider registry
# ---------------------------------------------------------------------------

PROVIDER_REGISTRY: dict[str, ProviderInfo] = {
    # ------------------------------------------------------------------
    # Cloud API providers
    # ------------------------------------------------------------------
    "anthropic": ProviderInfo(
        name="anthropic",
        display_name="Anthropic",
        litellm_prefix="anthropic",
        requires_endpoint=False,
        needs_api_key=True,
        auth_env_vars=("ANTHROPIC_API_KEY",),
        suggestions=(
            TierSuggestion("fast", "claude-haiku-4-5-20251001"),
            TierSuggestion("analysis", "claude-sonnet-4-6"),
            TierSuggestion("reasoning", "claude-sonnet-4-6"),
        ),
    ),
    "openai": ProviderInfo(
        name="openai",
        display_name="OpenAI",
        litellm_prefix="openai",
        requires_endpoint=False,
        needs_api_key=True,
        auth_env_vars=("OPENAI_API_KEY",),
        suggestions=(
            TierSuggestion("fast", "gpt-4o-mini"),
            TierSuggestion("analysis", "gpt-4o"),
            TierSuggestion("reasoning", "gpt-4o"),
        ),
    ),
    "azure": ProviderInfo(
        name="azure",
        display_name="Azure OpenAI",
        litellm_prefix="azure",
        requires_endpoint=False,
        needs_api_key=True,
        auth_env_vars=("AZURE_API_KEY", "AZURE_API_BASE", "AZURE_API_VERSION"),
        suggestions=(
            TierSuggestion("fast", "gpt-4o-mini"),
            TierSuggestion("analysis", "gpt-4o"),
            TierSuggestion("reasoning", "gpt-4o"),
        ),
    ),
    "bedrock": ProviderInfo(
        name="bedrock",
        display_name="AWS Bedrock",
        litellm_prefix="bedrock",
        requires_endpoint=False,
        needs_api_key=True,
        auth_env_vars=("AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_REGION_NAME"),
        suggestions=(
            TierSuggestion("fast", "anthropic.claude-3-haiku-20240307-v1:0"),
            TierSuggestion("analysis", "anthropic.claude-3-5-sonnet-20241022-v2:0"),
            TierSuggestion("reasoning", "anthropic.claude-3-5-sonnet-20241022-v2:0"),
        ),
    ),
    "gemini": ProviderInfo(
        name="gemini",
        display_name="Google Gemini",
        litellm_prefix="gemini",
        requires_endpoint=False,
        needs_api_key=True,
        auth_env_vars=("GEMINI_API_KEY",),
        suggestions=(
            TierSuggestion("fast", "gemini-2.0-flash"),
            TierSuggestion("analysis", "gemini-2.5-pro"),
            TierSuggestion("reasoning", "gemini-2.5-pro"),
        ),
    ),
    "mistral": ProviderInfo(
        name="mistral",
        display_name="Mistral AI",
        litellm_prefix="mistral",
        requires_endpoint=False,
        needs_api_key=True,
        auth_env_vars=("MISTRAL_API_KEY",),
        suggestions=(
            TierSuggestion("fast", "mistral-small-latest"),
            TierSuggestion("analysis", "mistral-large-latest"),
            TierSuggestion("reasoning", "mistral-large-latest"),
        ),
    ),
    "cohere": ProviderInfo(
        name="cohere",
        display_name="Cohere",
        litellm_prefix="cohere",
        requires_endpoint=False,
        needs_api_key=True,
        auth_env_vars=("COHERE_API_KEY",),
        suggestions=(
            TierSuggestion("fast", "command-r"),
            TierSuggestion("analysis", "command-r-plus"),
            TierSuggestion("reasoning", "command-r-plus"),
        ),
    ),
    "groq": ProviderInfo(
        name="groq",
        display_name="Groq",
        litellm_prefix="groq",
        requires_endpoint=False,
        needs_api_key=True,
        auth_env_vars=("GROQ_API_KEY",),
        suggestions=(
            TierSuggestion("fast", "llama-3.1-8b-instant"),
            TierSuggestion("analysis", "llama-3.3-70b-versatile"),
            TierSuggestion("reasoning", "llama-3.3-70b-versatile"),
        ),
    ),
    "together_ai": ProviderInfo(
        name="together_ai",
        display_name="Together AI",
        litellm_prefix="together_ai",
        requires_endpoint=False,
        needs_api_key=True,
        auth_env_vars=("TOGETHERAI_API_KEY",),
        suggestions=(
            TierSuggestion("fast", "meta-llama/Llama-3.1-8B-Instruct-Turbo"),
            TierSuggestion("analysis", "meta-llama/Llama-3.1-70B-Instruct-Turbo"),
            TierSuggestion("reasoning", "meta-llama/Llama-3.1-70B-Instruct-Turbo"),
        ),
    ),
    # ------------------------------------------------------------------
    # Self-hosted providers
    # ------------------------------------------------------------------
    "ollama": ProviderInfo(
        name="ollama",
        display_name="Ollama (self-hosted)",
        litellm_prefix="ollama",
        requires_endpoint=True,
        needs_api_key=False,
        auth_env_vars=(),
        endpoint_hint="http://localhost:11434/v1",
        suggestions=(
            TierSuggestion("fast", "granite3-dense:2b"),
            TierSuggestion("analysis", "granite-code:8b"),
            TierSuggestion("reasoning", "llama3.1:70b"),
        ),
    ),
    "vllm": ProviderInfo(
        name="vllm",
        display_name="vLLM (self-hosted)",
        litellm_prefix="openai",
        requires_endpoint=True,
        needs_api_key=False,
        auth_env_vars=(),
        endpoint_hint="http://localhost:8000/v1",
        suggestions=(
            TierSuggestion("fast", "granite-3.2-2b-instruct"),
            TierSuggestion("analysis", "granite-3.2-8b-instruct"),
            TierSuggestion("reasoning", "meta-llama/Llama-3.1-70B-Instruct"),
        ),
    ),
    "openshift_ai": ProviderInfo(
        name="openshift_ai",
        display_name="OpenShift AI",
        litellm_prefix="openai",
        requires_endpoint=True,
        needs_api_key=False,
        auth_env_vars=(),
        endpoint_hint="http://<model-name>.<namespace>.svc.cluster.local/v1",
        suggestions=(
            TierSuggestion("fast", "granite-3.2-2b-instruct"),
            TierSuggestion("analysis", "granite-code-8b-instruct"),
            TierSuggestion("reasoning", "llama-3.1-70b-instruct"),
        ),
    ),
}


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------

def get_provider(name: str) -> ProviderInfo | None:
    """Look up a provider by sanicode name. Returns None for unknown providers."""
    return PROVIDER_REGISTRY.get(name)


def list_providers() -> list[ProviderInfo]:
    """Return all registered providers."""
    return list(PROVIDER_REGISTRY.values())


def cloud_providers() -> list[ProviderInfo]:
    """Return providers that don't require an endpoint URL."""
    return [p for p in PROVIDER_REGISTRY.values() if not p.requires_endpoint]


def self_hosted_providers() -> list[ProviderInfo]:
    """Return providers that require an endpoint URL."""
    return [p for p in PROVIDER_REGISTRY.values() if p.requires_endpoint]
