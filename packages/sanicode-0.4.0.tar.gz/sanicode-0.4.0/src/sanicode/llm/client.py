"""LiteLLM-backed LLM client with tiered endpoint support.

Three tiers, each can point to a different model/endpoint:
  fast      — quick classification tasks (Granite Nano or similar)
  analysis  — data flow reasoning (Granite Code 8B or similar)
  reasoning — compliance mapping and report generation (Llama 3.1 70B or similar)

All tiers are optional. Sanicode operates in degraded mode when no LLM
is configured — AST patterns and graph analysis still run, LLM steps are skipped.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import litellm

from sanicode.config import LLMTierConfig
from sanicode.llm.providers import get_provider
from sanicode.metrics import (
    LLM_ERRORS_TOTAL,
    LLM_REQUEST_DURATION,
    LLM_REQUESTS_TOTAL,
    LLM_TOKENS_CONSUMED,
)


class LLMNotConfiguredError(RuntimeError):
    """Raised when an LLM operation is attempted with no endpoint configured."""


@dataclass
class LLMResponse:
    """Structured response from an LLM call."""

    content: str
    model: str
    tier: str
    usage: dict[str, int]


class LLMClient:
    """Multi-tier LLM client for Sanicode analysis tasks.

    Each method corresponds to a specific analysis tier. If the endpoint
    for a tier is not configured, LLMNotConfiguredError is raised with
    instructions for setting up the endpoint via sanicode.toml.
    """

    def __init__(
        self,
        fast: LLMTierConfig | None = None,
        analysis: LLMTierConfig | None = None,
        reasoning: LLMTierConfig | None = None,
    ) -> None:
        self._tiers: dict[str, LLMTierConfig | None] = {
            "fast": fast,
            "analysis": analysis,
            "reasoning": reasoning,
        }

    @classmethod
    def from_config(cls, config: Any) -> LLMClient:
        """Construct an LLMClient from a SanicodeConfig instance.

        Args:
            config: A SanicodeConfig (or any object with a .llm attribute).
        """
        llm_cfg = config.llm
        return cls(
            fast=llm_cfg.fast if llm_cfg.fast.model else None,
            analysis=llm_cfg.analysis if llm_cfg.analysis.model else None,
            reasoning=llm_cfg.reasoning if llm_cfg.reasoning.model else None,
        )

    def has_tier(self, tier_name: str) -> bool:
        """Check whether a tier is configured without raising.

        Args:
            tier_name: One of "fast", "analysis", "reasoning".

        Returns:
            True if the tier has a configured endpoint, False otherwise.
        """
        return self._tiers.get(tier_name) is not None

    def _require_tier(self, tier_name: str) -> LLMTierConfig:
        tier = self._tiers.get(tier_name)
        if tier is None:
            raise LLMNotConfiguredError(
                f"No LLM configured for the '{tier_name}' tier. "
                f"Add an [llm.{tier_name}] section to your sanicode.toml with "
                "a model field (and provider for cloud APIs, or endpoint for "
                "self-hosted), then run 'sanicode config --show' to verify."
            )
        return tier

    def _call_tier(self, tier_name: str, prompt: str, **kwargs: Any) -> LLMResponse:
        """Send a prompt to the specified tier's model via LiteLLM.

        Args:
            tier_name: One of "fast", "analysis", "reasoning".
            prompt: The prompt to send.
            **kwargs: Additional arguments forwarded to litellm.completion().

        Returns:
            An LLMResponse with the model's output.
        """
        tier = self._require_tier(tier_name)
        start = time.monotonic()
        try:
            provider_info = get_provider(tier.provider)
            litellm_prefix = provider_info.litellm_prefix if provider_info else tier.provider
            call_kwargs: dict[str, Any] = {
                "model": f"{litellm_prefix}/{tier.model}",
                "messages": [{"role": "user", "content": prompt}],
                "timeout": tier.timeout_seconds,
            }
            if tier.endpoint:
                call_kwargs["api_base"] = tier.endpoint
            if tier.api_key:
                call_kwargs["api_key"] = tier.api_key
            elif tier.endpoint:
                # Self-hosted or endpoint-based: only inject placeholder key
                # if the provider doesn't need real auth (e.g., vllm, ollama).
                # For providers that need auth even with an endpoint (e.g., Azure),
                # let LiteLLM pick up credentials from env vars.
                if provider_info is None or not provider_info.needs_api_key:
                    call_kwargs["api_key"] = "unused"
            call_kwargs.update(kwargs)
            response = litellm.completion(**call_kwargs)
            choice = response.choices[0]
            usage = response.usage

            LLM_REQUESTS_TOTAL.labels(model=tier.model, tier=tier_name).inc()
            LLM_REQUEST_DURATION.labels(tier=tier_name).observe(time.monotonic() - start)
            if usage:
                LLM_TOKENS_CONSUMED.labels(tier=tier_name, direction="prompt").inc(
                    usage.prompt_tokens or 0
                )
                LLM_TOKENS_CONSUMED.labels(tier=tier_name, direction="completion").inc(
                    usage.completion_tokens or 0
                )

            return LLMResponse(
                content=choice.message.content or "",
                model=response.model or tier.model,
                tier=tier_name,
                usage={
                    "prompt_tokens": usage.prompt_tokens if usage else 0,
                    "completion_tokens": usage.completion_tokens if usage else 0,
                    "total_tokens": usage.total_tokens if usage else 0,
                },
            )
        except Exception as exc:
            LLM_ERRORS_TOTAL.labels(model=tier.model, error_type=type(exc).__name__).inc()
            LLM_REQUEST_DURATION.labels(tier=tier_name).observe(time.monotonic() - start)
            raise

    def test_connection(self, tier_name: str) -> LLMResponse:
        """Send a minimal test prompt to verify connectivity.

        Args:
            tier_name: One of "fast", "analysis", "reasoning".

        Returns:
            An LLMResponse from the tier's model.

        Raises:
            LLMNotConfiguredError: If the tier is not configured.
        """
        return self._call_tier(tier_name, "Say 'ok'.", timeout=5)

    def classify(self, prompt: str, **kwargs: Any) -> LLMResponse:
        """Run a fast classification task using the 'fast' tier.

        Typical use: determine whether a detected pattern is a true positive.

        Args:
            prompt: The prompt to send to the model.

        Returns:
            An LLMResponse from the fast-tier model.
        """
        return self._call_tier("fast", prompt, **kwargs)

    def analyze(self, prompt: str, **kwargs: Any) -> LLMResponse:
        """Run a data flow analysis task using the 'analysis' tier.

        Typical use: assess whether data flow paths are sanitized end-to-end.

        Args:
            prompt: The prompt to send to the model.

        Returns:
            An LLMResponse from the analysis-tier model.
        """
        return self._call_tier("analysis", prompt, **kwargs)

    def reason(self, prompt: str, **kwargs: Any) -> LLMResponse:
        """Run compliance reasoning using the 'reasoning' tier.

        Typical use: generate compliance-mapped remediation recommendations.

        Args:
            prompt: The prompt to send to the model.

        Returns:
            An LLMResponse from the reasoning-tier model.
        """
        return self._call_tier("reasoning", prompt, **kwargs)
