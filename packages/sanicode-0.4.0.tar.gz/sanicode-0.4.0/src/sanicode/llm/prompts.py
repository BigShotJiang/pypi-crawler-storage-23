"""Prompt template loading and rendering for LLM integration.

Searches for YAML prompt templates in the prompts/ directory, both within
the installed package and in the current working directory.
"""

from __future__ import annotations

import importlib.resources
from pathlib import Path
from typing import Any

import yaml


def _find_prompt_file(name: str) -> Path | None:
    """Search for a prompt template file by name.

    Search order:
      1. prompts/{name}.yaml in the current working directory
      2. Bundled prompts inside the sanicode package (works when installed via pip)

    Args:
        name: Template name (without .yaml extension).

    Returns:
        Path to the template file, or None if not found.
    """
    # Check current working directory first (allows overriding bundled prompts)
    cwd_path = Path.cwd() / "prompts" / f"{name}.yaml"
    if cwd_path.exists():
        return cwd_path

    # Check bundled prompts inside the package
    try:
        pkg_prompts = importlib.resources.files("sanicode") / "prompts" / f"{name}.yaml"
        pkg_path = Path(str(pkg_prompts))
        if pkg_path.exists():
            return pkg_path
    except (TypeError, FileNotFoundError):
        pass

    # Fallback: check prompts/ as a peer of the package root (development checkout)
    try:
        pkg_root = importlib.resources.files("sanicode")
        project_root = Path(str(pkg_root)).parent.parent
        dev_path = project_root / "prompts" / f"{name}.yaml"
        if dev_path.exists():
            return dev_path
    except (TypeError, FileNotFoundError):
        pass

    return None


def load_prompt(name: str) -> dict[str, Any]:
    """Load a prompt template by name.

    Args:
        name: Template name (e.g., "classify", "analyze", "reason").

    Returns:
        Dictionary with template, variables, and metadata.

    Raises:
        FileNotFoundError: If the template file cannot be found.
    """
    path = _find_prompt_file(name)
    if path is None:
        raise FileNotFoundError(
            f"Prompt template '{name}' not found. "
            f"Searched: prompts/{name}.yaml in cwd and package root."
        )
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)


def render_prompt(name: str, **kwargs: Any) -> str:
    """Load a prompt template and render it with the given variables.

    Uses Python str.format_map() for {variable} substitution.

    Args:
        name: Template name.
        **kwargs: Variable values to substitute.

    Returns:
        The rendered prompt string.

    Raises:
        FileNotFoundError: If the template is not found.
        KeyError: If a required variable is missing.
    """
    data = load_prompt(name)
    template = data.get("template", "")

    # Validate required variables before rendering
    for var in data.get("variables", []):
        if var.get("required", False) and var["name"] not in kwargs:
            raise KeyError(
                f"Required variable '{var['name']}' not provided "
                f"for prompt template '{name}'."
            )

    return template.format_map(kwargs)
