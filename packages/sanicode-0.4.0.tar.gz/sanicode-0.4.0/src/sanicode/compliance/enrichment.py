"""Finding enrichment with compliance cross-reference data."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from sanicode.compliance.mapper import ComplianceMapper, ComplianceMapping, derive_severity
from sanicode.scanner.patterns import Finding, Severity


@dataclass
class EnrichedFinding:
    """A Finding augmented with compliance mapping data."""

    # Original Finding fields
    file: Path
    line: int
    column: int
    rule_id: str
    message: str
    severity: Severity
    cwe_id: int

    # Compliance fields
    cwe_name: str = ""
    compliance: ComplianceMapping | None = None
    derived_severity: str = ""  # severity derived from STIG category
    remediation: str = ""


def enrich_finding(finding: Finding, mapper: ComplianceMapper) -> EnrichedFinding:
    """Enrich a raw Finding with compliance cross-reference data.

    Maps the finding's CWE ID to compliance controls across OWASP ASVS,
    NIST 800-53, ASD STIG, and PCI DSS. Derives severity from the highest
    STIG category found for the CWE.

    Args:
        finding: The raw scanner finding to enrich.
        mapper: A ComplianceMapper instance (may be shared across calls).

    Returns:
        An EnrichedFinding with compliance fields populated.
    """
    mapping = mapper.map_cwe(finding.cwe_id)
    return EnrichedFinding(
        file=finding.file,
        line=finding.line,
        column=finding.column,
        rule_id=finding.rule_id,
        message=finding.message,
        severity=finding.severity,
        cwe_id=finding.cwe_id,
        cwe_name=mapping.cwe_name,
        compliance=mapping,
        derived_severity=derive_severity(mapping),
        remediation=mapping.remediation,
    )


def enrich_findings(
    findings: list[Finding], mapper: ComplianceMapper | None = None
) -> list[EnrichedFinding]:
    """Enrich a list of findings with compliance cross-reference data.

    Args:
        findings: Raw scanner findings to enrich.
        mapper: Optional ComplianceMapper; a default instance is created if
            not provided (loads the bundled compliance_db.json).

    Returns:
        List of EnrichedFinding objects in the same order as the input.
    """
    if mapper is None:
        mapper = ComplianceMapper()
    return [enrich_finding(f, mapper) for f in findings]


# Severity weights for compliance score calculation.
_SEVERITY_WEIGHTS = {
    "critical": 25,
    "high": 10,
    "medium": 3,
    "low": 1,
    "info": 0,
}


def compute_compliance_score(findings: list[EnrichedFinding], profile: str = "default") -> float:
    """Compute a compliance score from 0 to 100 based on finding severities.

    Higher is better.  Each finding reduces the score by a severity-dependent
    weight: critical=25, high=10, medium=3, low=1.

    Args:
        findings: Enriched findings from a scan.
        profile: Scan profile name (unused currently, reserved for
            per-profile weighting in Phase 3).

    Returns:
        A score in the range [0.0, 100.0].
    """
    penalty = 0
    for f in findings:
        sev = (f.derived_severity or f.severity).lower()
        penalty += _SEVERITY_WEIGHTS.get(sev, 1)
    return max(0.0, 100.0 - penalty)


def compute_control_status(
    findings: list[EnrichedFinding],
    mapper: ComplianceMapper,
) -> dict[str, dict[str, int]]:
    """Count passing and failing controls per compliance framework.

    A control is "failing" if any finding maps to it.  "Passing" is the
    total known controls in the mapper's DB minus the failing count.

    Args:
        findings: Enriched findings from a scan.
        mapper: ComplianceMapper to enumerate total controls.

    Returns:
        Dict keyed by framework name ("owasp_asvs", "nist_800_53",
        "asd_stig", "pci_dss") with values {"passing": N, "failing": M}.
    """
    frameworks = ("owasp_asvs", "nist_800_53", "asd_stig", "pci_dss")

    # Collect all controls referenced by findings.
    failing_controls: dict[str, set[str]] = {fw: set() for fw in frameworks}
    for f in findings:
        if f.compliance is None:
            continue
        for entry in f.compliance.owasp_asvs:
            ctrl_id = entry.get("id", "") if isinstance(entry, dict) else str(entry)
            failing_controls["owasp_asvs"].add(ctrl_id)
        for ctrl in f.compliance.nist_800_53:
            failing_controls["nist_800_53"].add(ctrl)
        for entry in f.compliance.asd_stig:
            ctrl_id = entry.get("id", "") if isinstance(entry, dict) else str(entry)
            failing_controls["asd_stig"].add(ctrl_id)
        for ctrl in f.compliance.pci_dss:
            failing_controls["pci_dss"].add(ctrl)

    # Count total known controls from the mapper's DB.
    all_controls: dict[str, set[str]] = {fw: set() for fw in frameworks}
    for _cwe_id, entry in mapper._db.items():
        for fw in frameworks:
            raw = entry.get(fw, [])
            for item in raw:
                if isinstance(item, dict):
                    ctrl_id = item.get("id", "")
                else:
                    ctrl_id = str(item)
                if ctrl_id:
                    all_controls[fw].add(ctrl_id)

    result: dict[str, dict[str, int]] = {}
    for fw in frameworks:
        total = len(all_controls[fw])
        failing = len(failing_controls[fw])
        result[fw] = {"passing": max(0, total - failing), "failing": failing}

    return result
