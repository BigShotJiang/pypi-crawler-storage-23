"""Enable running sanicode as a module: python -m sanicode"""

from sanicode.cli import main

if __name__ == "__main__":
    main()
