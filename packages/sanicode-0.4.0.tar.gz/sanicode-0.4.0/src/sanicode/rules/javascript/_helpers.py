"""Shared helpers for JavaScript rule modules.

These mirror the private helpers in ``scanner/languages/javascript.py`` but
are kept here so rule modules don't need to reach into scanner internals.
"""

from __future__ import annotations

from tree_sitter import Node


def js_dotted_name(node: Node) -> str:
    """Build a dotted name from a JS tree-sitter node.

    Handles ``identifier`` and ``member_expression`` (JS equivalent of
    Python's ``attribute``).
    """
    if node.type == "identifier":
        return node.text.decode("utf-8") if node.text else ""
    if node.type == "member_expression":
        obj = node.child_by_field_name("object")
        prop = node.child_by_field_name("property")
        if obj is None or prop is None:
            return ""
        prefix = js_dotted_name(obj)
        suffix = prop.text.decode("utf-8") if prop.text else ""
        return f"{prefix}.{suffix}" if prefix else suffix
    return ""


def js_call_arguments(call_node: Node) -> list[Node]:
    """Return positional argument nodes from a JS ``call_expression`` node."""
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return []
    results: list[Node] = []
    for child in args_node.children:
        if child.type in ("(", ")", ",", "spread_element"):
            continue
        results.append(child)
    return results
