"""JavaScript-specific pattern detection rules."""
