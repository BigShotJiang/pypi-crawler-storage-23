"""Cross-site scripting detection rules for JavaScript (CWE-79).

SC204 — innerHTML / outerHTML assignment    high  CWE-79
SC205 — document.write() / document.writeln high  CWE-79
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.javascript._helpers import js_dotted_name
from sanicode.scanner.patterns import Finding

_DOM_WRITE_PROPS = frozenset({"innerHTML", "outerHTML"})
_DOCUMENT_WRITE_FUNCS = frozenset({"document.write", "document.writeln"})


class JSInnerHtmlRule(Rule):
    """Detect assignment to innerHTML or outerHTML — DOM XSS sink."""

    rule_id = "SC204"
    cwe_id = 79
    severity = "high"
    language = "javascript"
    message = "Assignment to innerHTML/outerHTML — DOM XSS risk (CWE-79)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != "assignment_expression":
                continue
            left = node.child_by_field_name("left")
            if left is None or left.type != "member_expression":
                continue
            prop = left.child_by_field_name("property")
            if prop and plugin.node_text(prop) in _DOM_WRITE_PROPS:
                findings.append(self._make_finding(node, plugin, file_path))

        return findings


class JSDocumentWriteRule(Rule):
    """Detect document.write() and document.writeln() — DOM XSS sink."""

    rule_id = "SC205"
    cwe_id = 79
    severity = "high"
    language = "javascript"
    message = "Use of document.write() — DOM XSS risk (CWE-79)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if js_dotted_name(func_node) in _DOCUMENT_WRITE_FUNCS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
