"""YAML-based custom rule definitions.

Loads user-defined rules from YAML files and converts them to CallRule
instances that integrate with the existing rule registry.

YAML rule format::

    rules:
      - id: CUSTOM001
        cwe_id: 502
        severity: high
        language: python
        message: "Unsafe deserialization (CWE-502)"
        pattern:
          type: call
          targets:
            - "yaml.load"

Supported pattern types: ``call`` (maps to the existing ``CallRule`` logic).
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sanicode.rules.base import CallRule
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

_log = logging.getLogger(__name__)

_VALID_SEVERITIES: frozenset[str] = frozenset(
    {"critical", "high", "medium", "low", "info"}
)
_VALID_PATTERN_TYPES: frozenset[str] = frozenset({"call"})

# Standard locations searched by discover_yaml_rules()
_STANDARD_SEARCH_DIRS: list[Path] = [
    Path("rules"),
    Path.home() / ".config" / "sanicode" / "rules",
]


@dataclass
class YamlRuleSpec:
    """Parsed specification from a YAML rule definition."""

    id: str
    cwe_id: int
    severity: str
    language: str
    message: str
    targets: list[str]
    required_keywords: dict[str, str | None] = field(default_factory=dict)


def _parse_rule_spec(raw: dict[str, Any], source: Path | str = "<unknown>") -> YamlRuleSpec:
    """Parse and validate one rule entry from a YAML rules file.

    Args:
        raw: The raw dict for a single rule entry.
        source: File path or label used in error messages.

    Returns:
        A validated ``YamlRuleSpec``.

    Raises:
        ValueError: If required fields are missing or values are invalid.
    """
    rule_id = raw.get("id")
    if not rule_id or not isinstance(rule_id, str):
        raise ValueError(f"[{source}] Rule is missing a valid string 'id' field")

    cwe_raw = raw.get("cwe_id")
    if cwe_raw is None or not isinstance(cwe_raw, int):
        raise ValueError(
            f"[{source}] Rule '{rule_id}': 'cwe_id' must be an integer"
        )

    severity = raw.get("severity", "medium")
    if severity not in _VALID_SEVERITIES:
        raise ValueError(
            f"[{source}] Rule '{rule_id}': severity {severity!r} is not one of "
            f"{sorted(_VALID_SEVERITIES)}"
        )

    language = raw.get("language")
    if not language or not isinstance(language, str):
        raise ValueError(
            f"[{source}] Rule '{rule_id}': 'language' must be a non-empty string"
        )

    message = raw.get("message")
    if not message or not isinstance(message, str):
        raise ValueError(
            f"[{source}] Rule '{rule_id}': 'message' must be a non-empty string"
        )

    pattern = raw.get("pattern")
    if not isinstance(pattern, dict):
        raise ValueError(
            f"[{source}] Rule '{rule_id}': 'pattern' must be a mapping"
        )

    pattern_type = pattern.get("type")
    if pattern_type not in _VALID_PATTERN_TYPES:
        raise ValueError(
            f"[{source}] Rule '{rule_id}': pattern.type {pattern_type!r} is not one of "
            f"{sorted(_VALID_PATTERN_TYPES)}"
        )

    targets = pattern.get("targets")
    if not isinstance(targets, list) or not targets:
        raise ValueError(
            f"[{source}] Rule '{rule_id}': pattern.targets must be a non-empty list"
        )
    if not all(isinstance(t, str) for t in targets):
        raise ValueError(
            f"[{source}] Rule '{rule_id}': all pattern.targets must be strings"
        )

    required_keywords: dict[str, str | None] = {}
    raw_kw = pattern.get("required_keywords")
    if raw_kw is not None:
        if not isinstance(raw_kw, dict):
            raise ValueError(
                f"[{source}] Rule '{rule_id}': pattern.required_keywords must be a mapping"
            )
        for kw_name, kw_value in raw_kw.items():
            if not isinstance(kw_name, str):
                raise ValueError(
                    f"[{source}] Rule '{rule_id}': keyword argument name must be a string"
                )
            if kw_value is not None and not isinstance(kw_value, str):
                raise ValueError(
                    f"[{source}] Rule '{rule_id}': keyword argument value must be a string or null"
                )
            required_keywords[kw_name] = kw_value

    return YamlRuleSpec(
        id=rule_id,
        cwe_id=int(cwe_raw),
        severity=severity,
        language=language,
        message=message,
        targets=targets,
        required_keywords=required_keywords,
    )


def _spec_to_rule(spec: YamlRuleSpec) -> CallRule:
    """Convert a ``YamlRuleSpec`` to a live ``CallRule`` instance.

    Creates a new ``CallRule`` subclass dynamically, using the spec's
    ``targets`` list to populate either ``target_functions`` or
    ``dotted_targets`` (or both) depending on whether the target contains
    a dot.
    """
    # Deferred import to avoid circular dependency with sanicode.scanner.
    from sanicode.rules.base import CallRule  # noqa: PLC0415

    simple: set[str] = set()
    dotted: set[str] = set()
    for target in spec.targets:
        if "." in target:
            dotted.add(target)
        else:
            simple.add(target)

    # Build a concrete CallRule subclass with the spec's attributes baked in.
    cls = type(
        f"YamlCallRule_{spec.id}",
        (CallRule,),
        {
            "rule_id": spec.id,
            "cwe_id": spec.cwe_id,
            "severity": spec.severity,
            "language": spec.language,
            "message": spec.message,
            "target_functions": frozenset(simple),
            "dotted_targets": frozenset(dotted),
            "check_identifier_only": bool(simple and not dotted),
            "required_keywords": spec.required_keywords,
        },
    )
    return cls()


def load_yaml_rules(path: Path) -> list[CallRule]:
    """Load rules from a YAML file and return ``CallRule`` instances.

    Args:
        path: Path to a YAML rules file.

    Returns:
        A list of ``CallRule`` instances, one per valid rule entry.

    Raises:
        ValueError: If the file cannot be parsed or contains invalid rule specs.
        FileNotFoundError: If ``path`` does not exist.
    """
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        raise FileNotFoundError(f"YAML rules file not found: {path}") from None

    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ValueError(f"Failed to parse YAML file {path}: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError(
            f"{path}: top-level YAML value must be a mapping, got {type(data).__name__}"
        )

    raw_rules = data.get("rules")
    if raw_rules is None:
        raise ValueError(f"{path}: missing top-level 'rules' key")
    if not isinstance(raw_rules, list):
        raise ValueError(
            f"{path}: 'rules' must be a list, got {type(raw_rules).__name__}"
        )

    rules: list[CallRule] = []
    errors: list[str] = []

    for i, entry in enumerate(raw_rules):
        if not isinstance(entry, dict):
            errors.append(f"  rules[{i}]: expected a mapping, got {type(entry).__name__}")
            continue
        try:
            spec = _parse_rule_spec(entry, source=path)
            rules.append(_spec_to_rule(spec))
        except ValueError as exc:
            errors.append(f"  {exc}")

    if errors:
        raise ValueError(
            f"Found {len(errors)} error(s) in {path}:\n" + "\n".join(errors)
        )

    return rules


def discover_yaml_rules(search_dirs: list[Path] | None = None) -> list[CallRule]:
    """Discover and load YAML rules from standard locations.

    Searches each directory recursively for ``*.yaml`` and ``*.yml`` files
    under the given paths. Any file that fails to load is logged as a warning
    and skipped rather than aborting the entire discovery pass.

    Search order (when *search_dirs* is ``None``):

    1. ``rules/`` in the current working directory
    2. ``~/.config/sanicode/rules/``

    Args:
        search_dirs: Override the default search path. Pass an empty list to
            disable all discovery.

    Returns:
        A flat list of ``CallRule`` instances from all discovered files.
    """
    dirs = _STANDARD_SEARCH_DIRS if search_dirs is None else search_dirs

    found: list[CallRule] = []
    for base in dirs:
        if not base.is_dir():
            continue
        for yaml_path in sorted(base.rglob("*.yaml")) + sorted(base.rglob("*.yml")):
            try:
                rules = load_yaml_rules(yaml_path)
                _log.debug("Loaded %d rule(s) from %s", len(rules), yaml_path)
                found.extend(rules)
            except (ValueError, FileNotFoundError) as exc:
                _log.warning("Skipping %s: %s", yaml_path, exc)

    return found
