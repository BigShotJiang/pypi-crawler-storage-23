"""Hardcoded credential detection for PHP (CWE-798)."""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

_SECRET_PATTERN = re.compile(
    r"(password|passwd|secret|api_key|apikey|token|auth_token|"
    r"access_key|private_key|credentials?|db_pass)",
    re.IGNORECASE,
)

# Minimum length to reduce false positives from empty/placeholder strings.
_MIN_VALUE_LEN = 3


class PHPHardcodedCredentialRule(Rule):
    """Detect hardcoded credentials assigned to PHP variables (CWE-798)."""

    rule_id = "SC106"
    cwe_id = 798
    severity = "high"
    language = "php"
    message = "Hardcoded credential — secret value in PHP variable (CWE-798)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings = []
        root = tree.root_node

        for node in _walk(root):
            if node.type != "assignment_expression":
                continue

            left = node.child_by_field_name("left")
            right = node.child_by_field_name("right")
            if left is None or right is None:
                continue

            # Variable names come back as e.g. "$password"; strip the leading $
            var_name = plugin.node_text(left).lstrip("$")
            if not _SECRET_PATTERN.search(var_name):
                continue

            if right.type != "encapsed_string":
                continue

            value = plugin.node_text(right).strip("\"'")
            if len(value) < _MIN_VALUE_LEN:
                continue

            findings.append(self._make_finding(node, plugin, file_path))

        return findings
