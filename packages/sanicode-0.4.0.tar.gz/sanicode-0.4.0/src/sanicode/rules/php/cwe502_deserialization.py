"""Unsafe deserialization detection rules for PHP (CWE-502)."""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding


class PHPUnserializeRule(Rule):
    """Detect unserialize() in PHP (CWE-502)."""

    rule_id = "SC104"
    cwe_id = 502
    severity = "high"
    language = "php"
    message = "Use of unserialize() — deserialization of untrusted data (CWE-502)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings = []
        root = tree.root_node
        for node in _walk(root):
            if node.type != "function_call_expression":
                continue
            func_node = node.child_by_field_name("function")
            if func_node is None:
                continue
            name = func_node.text.decode("utf-8") if func_node.text else ""
            if name == "unserialize":
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
