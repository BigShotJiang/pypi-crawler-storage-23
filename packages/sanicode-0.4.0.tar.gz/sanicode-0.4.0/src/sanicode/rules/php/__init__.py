"""PHP-specific pattern detection rules."""
