"""Code injection detection rules (CWE-94).

Detects dynamic import via __import__().
"""

from sanicode.rules.base import CallRule


class DynamicImportRule(CallRule):
    rule_id = "SC007"
    cwe_id = 94
    severity = "medium"
    language = "python"
    message = "Use of __import__() \u2014 dynamic import from untrusted input (CWE-94)"
    target_functions = frozenset({"__import__"})
    check_identifier_only = True
