"""Deserialization detection rules (CWE-502).

Detects unsafe deserialization via pickle and yaml.load without Loader.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import CallRule, Rule, _dotted_name, _has_keyword
from sanicode.scanner.patterns import Finding


class PickleLoadsRule(CallRule):
    rule_id = "SC005"
    cwe_id = 502
    severity = "high"
    language = "python"
    message = "Use of pickle.loads() \u2014 deserialization of untrusted data (CWE-502)"
    dotted_targets = frozenset({"pickle.loads"})


class YamlLoadRule(Rule):
    """Detect yaml.load() without explicit Loader kwarg."""

    rule_id = "SC008"
    cwe_id = 502
    severity = "high"
    language = "python"
    message = "Use of yaml.load() without Loader \u2014 deserialization of untrusted data (CWE-502)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings = []
        root = tree.root_node
        call_captures = plugin.captures("(call) @call", root)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = _dotted_name(func_node)
            if dotted == "yaml.load" and not _has_keyword(call_node, "Loader"):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
