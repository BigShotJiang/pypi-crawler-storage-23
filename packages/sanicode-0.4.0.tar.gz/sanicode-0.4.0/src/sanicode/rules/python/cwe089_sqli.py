"""SQL injection detection rules (CWE-89).

Detects string formatting in SQL execution contexts.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _is_formatted_sql
from sanicode.scanner.patterns import Finding


class SqlFormattingRule(Rule):
    """Detect string formatting in .execute() calls."""

    rule_id = "SC006"
    cwe_id = 89
    severity = "high"
    language = "python"
    message = "String formatting in SQL context \u2014 potential SQL injection (CWE-89)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings = []
        root = tree.root_node
        call_captures = plugin.captures("(call) @call", root)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None or func_node.type != "attribute":
                continue

            attr = func_node.child_by_field_name("attribute")
            if (
                attr
                and attr.text
                and attr.text.decode("utf-8") == "execute"
                and _is_formatted_sql(call_node)
            ):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
