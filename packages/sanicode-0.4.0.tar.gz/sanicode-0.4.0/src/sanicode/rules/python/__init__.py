"""Python-specific pattern detection rules."""
