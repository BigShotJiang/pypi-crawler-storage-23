"""Server-Side Request Forgery detection rules (CWE-918).

Detects HTTP requests where the URL argument is not a string literal,
indicating potential attacker control over the request destination.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _call_arguments, _dotted_name
from sanicode.scanner.patterns import Finding

_NETWORK_FUNCS: frozenset[str] = frozenset(
    {
        "requests.get",
        "requests.post",
        "requests.put",
        "requests.delete",
        "requests.patch",
        "requests.head",
        "requests.options",
        "requests.request",
        "httpx.get",
        "httpx.post",
        "httpx.put",
        "httpx.delete",
        "httpx.patch",
        "httpx.request",
        "urllib.request.urlopen",
    }
)


class SsrfRule(Rule):
    """Detect HTTP requests with variable URL arguments.

    When a URL passed to an HTTP client is derived from user input rather
    than a hard-coded string literal, an attacker may direct the server to
    send requests to arbitrary internal or external endpoints.
    """

    rule_id = "SC015"
    cwe_id = 918
    severity = "high"
    language = "python"
    message = (
        "HTTP request with variable URL \u2014 potential SSRF (CWE-918)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        call_captures = plugin.captures("(call) @call", root)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            if _dotted_name(func_node) not in _NETWORK_FUNCS:
                continue

            args = _call_arguments(call_node)
            if not args:
                continue
            # String literal URLs are not flagged — they cannot be attacker-controlled
            if args[0].type == "string":
                continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
