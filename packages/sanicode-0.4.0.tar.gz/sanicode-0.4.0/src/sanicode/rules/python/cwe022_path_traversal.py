"""Path traversal detection rules (CWE-22).

Detects file operations with unsanitized path inputs.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _call_arguments, _dotted_name
from sanicode.scanner.patterns import Finding


class OpenVariablePathRule(Rule):
    """Detect open() with a non-literal file path.

    When the path passed to the built-in ``open()`` is derived from user
    input rather than a string literal, an attacker may be able to escape
    the intended directory via ``../`` sequences or absolute paths.
    """

    rule_id = "SC010"
    cwe_id = 22
    severity = "high"
    language = "python"
    message = (
        "open() with variable path \u2014 potential path traversal (CWE-22)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        call_captures = plugin.captures("(call) @call", root)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            # Only match the bare built-in open(), not e.g. pathlib.Path.open()
            if func_node.type != "identifier":
                continue
            if _dotted_name(func_node) != "open":
                continue

            args = _call_arguments(call_node)
            if not args:
                continue
            # String literal paths are safe for this rule
            if args[0].type == "string":
                continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class OsPathJoinRule(Rule):
    """Detect os.path.join() with variable path segments.

    ``os.path.join`` does not sanitize path components; an argument
    starting with ``/`` resets the entire path.  Any non-literal segment
    may contain attacker-controlled traversal sequences.
    """

    rule_id = "SC011"
    cwe_id = 22
    severity = "medium"
    language = "python"
    message = (
        "os.path.join() with variable segments \u2014 potential path traversal (CWE-22)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        call_captures = plugin.captures("(call) @call", root)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            if _dotted_name(func_node) != "os.path.join":
                continue

            args = _call_arguments(call_node)
            # Flag when any argument is not a string literal
            if any(a.type != "string" for a in args):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
