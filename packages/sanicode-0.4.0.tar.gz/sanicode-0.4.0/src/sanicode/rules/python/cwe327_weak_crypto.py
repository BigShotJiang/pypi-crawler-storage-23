"""Weak cryptography detection rules (CWE-327).

Detects use of broken or weak cryptographic hash algorithms.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _call_arguments, _dotted_name
from sanicode.scanner.patterns import Finding

# hashlib direct calls that use weak algorithms
_WEAK_DIRECT: frozenset[str] = frozenset({"hashlib.md5", "hashlib.sha1"})

# Algorithm name strings considered weak when passed to hashlib.new()
_WEAK_ALGO_NAMES: frozenset[str] = frozenset({"md5", "sha1", "sha-1"})


class WeakHashRule(Rule):
    """Detect use of MD5 or SHA1 via hashlib.

    MD5 and SHA1 are cryptographically broken and must not be used for
    security purposes such as password hashing, integrity verification, or
    digital signatures.  Use SHA-256 or stronger algorithms instead.

    Catches both direct calls (``hashlib.md5()``) and indirect calls via
    ``hashlib.new("md5")``.
    """

    rule_id = "SC013"
    cwe_id = 327
    severity = "medium"
    language = "python"
    message = (
        "Use of weak hash algorithm (MD5/SHA1) \u2014 "
        "unsuitable for security use (CWE-327)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        call_captures = plugin.captures("(call) @call", root)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = _dotted_name(func_node)

            # hashlib.md5() / hashlib.sha1()
            if dotted in _WEAK_DIRECT:
                findings.append(self._make_finding(call_node, plugin, file_path))
                continue

            # hashlib.new("md5") / hashlib.new("sha1")
            if dotted == "hashlib.new":
                args = _call_arguments(call_node)
                if args and args[0].type == "string":
                    algo = plugin.node_text(args[0]).strip("\"'").lower()
                    if algo in _WEAK_ALGO_NAMES:
                        findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
