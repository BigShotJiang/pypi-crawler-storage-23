# CI/CD Integration Guide

## Overview

Sanicode integrates with CI/CD pipelines through three primary mechanisms: SARIF output consumed by platform security dashboards, the `--fail-on` severity gate that controls exit codes, and platform-specific integrations including a native GitHub Action and a pre-commit hook. In degraded mode (no LLM configured), sanicode still produces useful output via AST pattern matching and rule-based detection, making it suitable for fast CI runs without inference infrastructure.

## Exit Codes

- `0` — Scan completed successfully. No findings at or above the `--fail-on` threshold (or `--fail-on` was not specified).
- `1` — Either findings were detected at or above the `--fail-on` threshold, or a fatal error occurred (invalid path, config error, etc.).

When `--fail-on` is not set, the exit code is always `0` regardless of findings. This lets you collect results without gating the pipeline.

## GitHub Actions

### Using the Sanicode Action

The `sanicode-security-scan` action wraps installation, scanning, SARIF upload, and artifact retention into a single step. It is a composite action defined in `action.yml` at the root of the sanicode repository.

#### Basic usage

```yaml
name: Security Scan

on:
  push:
    branches: [main]
  pull_request:

permissions:
  security-events: write  # Required for SARIF upload to Code Scanning
  contents: read

jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Run Sanicode
        uses: your-org/sanicode@main
```

#### With severity gating

Fail the job if any `high` or `critical` findings are detected:

```yaml
      - name: Run Sanicode
        uses: your-org/sanicode@main
        with:
          fail-on: high
```

Valid values for `fail-on`: `critical`, `high`, `medium`, `low`.

#### With SARIF upload to Code Scanning

SARIF upload is enabled by default (`upload-sarif: 'true'`). Results appear in the GitHub Security tab under Code Scanning. To disable upload (for example, in forks where `security-events: write` is unavailable):

```yaml
      - name: Run Sanicode
        uses: your-org/sanicode@main
        with:
          upload-sarif: 'false'
```

#### Multi-format output

Generate SARIF, Markdown, and JSON reports simultaneously. All formats are written to `sanicode-reports/` and uploaded as a workflow artifact (retained 30 days):

```yaml
      - name: Run Sanicode
        uses: your-org/sanicode@main
        with:
          format: sarif,markdown,json
          fail-on: high
```

#### Custom config file

Point the action at a project-specific `sanicode.toml`:

```yaml
      - name: Run Sanicode
        uses: your-org/sanicode@main
        with:
          config: ci/sanicode.toml
          fail-on: high
```

#### Scanning a subdirectory

```yaml
      - name: Run Sanicode
        uses: your-org/sanicode@main
        with:
          path: src/
          fail-on: high
```

#### Pinning a specific version

Pin to a specific release to avoid unexpected behavior from new releases:

```yaml
      - name: Run Sanicode
        uses: your-org/sanicode@v0.3.0
        with:
          version: '0.3.0'
          fail-on: high
```

#### Action inputs reference

| Input | Default | Description |
|-------|---------|-------------|
| `path` | `.` | Path to scan |
| `fail-on` | _(none)_ | Fail if findings at or above this severity |
| `format` | `sarif,markdown` | Comma-separated output formats: `markdown`, `json`, `sarif`, `html` |
| `config` | _(none)_ | Path to a `sanicode.toml` config file |
| `python-version` | `3.11` | Python version to install sanicode with |
| `upload-sarif` | `true` | Upload SARIF to GitHub Code Scanning |
| `version` | _(latest)_ | Sanicode version to install from PyPI |

#### Action outputs reference

| Output | Description |
|--------|-------------|
| `findings-count` | Total number of findings detected |
| `report-dir` | Path to the generated reports directory (`sanicode-reports`) |

### Manual Setup (without the Action)

For teams that prefer explicit control over each step:

```yaml
name: Security Scan

on:
  push:
    branches: [main]
  pull_request:

permissions:
  security-events: write
  contents: read

jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'

      - name: Install sanicode
        run: pip install sanicode

      - name: Scan
        run: |
          sanicode scan . \
            --format sarif \
            --format markdown \
            --fail-on high

      - name: Upload SARIF
        if: always()
        uses: github/codeql-action/upload-sarif@v3
        with:
          sarif_file: sanicode-reports/report.sarif
        continue-on-error: true

      - name: Upload reports
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: sanicode-reports
          path: sanicode-reports/
          retention-days: 30
```

`continue-on-error: true` on the SARIF upload step prevents the job from failing if Code Scanning is not enabled on the repository (for example, in personal or private repos without the Advanced Security license).

### LLM API keys in GitHub Actions

Store API keys as encrypted secrets and pass them as environment variables:

```yaml
      - name: Scan with LLM enrichment
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
        run: sanicode scan . --format sarif --fail-on high
```

For self-hosted OpenShift AI inference, configure via `sanicode.toml` committed to the repo (with the API key omitted) and pass the key at runtime:

```yaml
      - name: Scan with self-hosted LLM
        env:
          SANICODE_LLM_API_KEY: ${{ secrets.INFERENCE_API_KEY }}
        run: sanicode scan . --config ci/sanicode.toml --format sarif --fail-on high
```

## GitLab CI

### Basic scan stage

```yaml
# .gitlab-ci.yml

stages:
  - test
  - security

sanicode-scan:
  stage: security
  image: python:3.11-slim
  cache:
    key: sanicode-pip
    paths:
      - .pip-cache/
  before_script:
    - pip install --cache-dir .pip-cache sanicode
  script:
    - sanicode scan . --format sarif --format json --fail-on high
  artifacts:
    when: always
    paths:
      - sanicode-reports/
    expire_in: 30 days
    reports:
      sast: sanicode-reports/report.sarif
```

The `reports: sast:` key uploads the SARIF file to GitLab's Security Dashboard (requires GitLab Ultimate or a SAST-enabled tier). On lower tiers the artifact is still retained, just not surfaced in the dashboard.

### With severity gating and MR annotation

```yaml
sanicode-scan:
  stage: security
  image: python:3.11-slim
  before_script:
    - pip install sanicode
  script:
    - sanicode scan . --format sarif --format markdown --fail-on high
  artifacts:
    when: always
    reports:
      sast: sanicode-reports/report.sarif
    paths:
      - sanicode-reports/report.md
    expose_as: 'Sanicode Security Report'
    expire_in: 7 days
  allow_failure: false
```

### Caching pip packages

Caching the pip download cache significantly reduces job time after the first run:

```yaml
variables:
  PIP_CACHE_DIR: "$CI_PROJECT_DIR/.pip-cache"

cache:
  paths:
    - .pip-cache/
```

### LLM API keys in GitLab CI

Set `OPENAI_API_KEY` (or the appropriate provider variable) in **Settings > CI/CD > Variables** as a masked, protected variable, then reference it in the job:

```yaml
sanicode-scan:
  variables:
    OPENAI_API_KEY: $OPENAI_API_KEY
  script:
    - sanicode scan . --format sarif --fail-on high
```

## Jenkins

### Declarative pipeline

```groovy
pipeline {
    agent any

    stages {
        stage('Checkout') {
            steps {
                checkout scm
            }
        }

        stage('Security Scan') {
            steps {
                sh '''
                    python3 -m venv .venv
                    .venv/bin/pip install sanicode
                    .venv/bin/sanicode scan . \
                        --format sarif \
                        --format markdown \
                        --fail-on high
                '''
            }
            post {
                always {
                    archiveArtifacts artifacts: 'sanicode-reports/**', allowEmptyArchive: true
                }
            }
        }
    }
}
```

### Publishing SARIF in Jenkins

Jenkins does not natively render SARIF. Options:

- Archive the SARIF file as a build artifact and consume it downstream (Azure DevOps, GitHub Advanced Security, SonarQube with SARIF import plugin).
- Use the [Warnings Next Generation plugin](https://plugins.jenkins.io/warnings-ng/) which can parse SARIF files as a custom format.

```groovy
stage('Security Scan') {
    steps {
        sh '.venv/bin/sanicode scan . --format sarif --fail-on high || true'
    }
    post {
        always {
            recordIssues(
                tools: [sarif(pattern: 'sanicode-reports/report.sarif', id: 'sanicode')]
            )
        }
    }
}
```

The `|| true` on the scan command lets the `recordIssues` step always run; the pipeline can be failed explicitly afterwards based on the recorded issue count if needed.

### Scripted pipeline

```groovy
node {
    checkout scm

    stage('Security Scan') {
        try {
            sh '''
                python3 -m venv .venv
                .venv/bin/pip install sanicode
                .venv/bin/sanicode scan . --format sarif --fail-on high
            '''
        } finally {
            archiveArtifacts artifacts: 'sanicode-reports/**', allowEmptyArchive: true
        }
    }
}
```

### LLM API keys in Jenkins

Store API keys using Jenkins Credentials (Secret Text type) and inject via the `withCredentials` binding:

```groovy
withCredentials([string(credentialsId: 'openai-api-key', variable: 'OPENAI_API_KEY')]) {
    sh '.venv/bin/sanicode scan . --format sarif --fail-on high'
}
```

## Azure DevOps

### Basic pipeline

```yaml
# azure-pipelines.yml

trigger:
  branches:
    include:
      - main

pool:
  vmImage: ubuntu-latest

steps:
  - task: UsePythonVersion@0
    inputs:
      versionSpec: '3.11'

  - script: pip install sanicode
    displayName: Install sanicode

  - script: |
      sanicode scan . \
        --format sarif \
        --format markdown \
        --fail-on high
    displayName: Run Sanicode
    continueOnError: false

  - task: PublishBuildArtifacts@1
    condition: always()
    inputs:
      pathToPublish: sanicode-reports/
      artifactName: sanicode-reports
```

### Uploading SARIF to Azure DevOps Code Analysis

Azure DevOps supports SARIF via the Advanced Security add-on. With it enabled, publish the SARIF file as a code analysis result:

```yaml
  - task: PublishCodeAnalysisResult@1
    condition: always()
    inputs:
      analysisTool: sariF
      analysisResultsPath: sanicode-reports/report.sarif
```

Without Advanced Security, archive the SARIF as a build artifact and import it into other consumers (GitHub Code Scanning, SonarQube).

### Variable groups for API keys

Store LLM API keys in a Variable Group under **Pipelines > Library** and link it to the pipeline:

```yaml
variables:
  - group: sanicode-secrets

steps:
  - script: sanicode scan . --format sarif --fail-on high
    env:
      OPENAI_API_KEY: $(OPENAI_API_KEY)
    displayName: Run Sanicode
```

## Tekton

### Task definition

```yaml
apiVersion: tekton.dev/v1
kind: Task
metadata:
  name: sanicode-scan
spec:
  description: Run Sanicode security scanner and produce SARIF output.
  params:
    - name: path
      type: string
      default: "."
      description: Path to scan within the workspace.
    - name: fail-on
      type: string
      default: "high"
      description: Severity threshold for non-zero exit (critical, high, medium, low).
    - name: format
      type: string
      default: "sarif,markdown"
      description: Comma-separated output formats.
    - name: sanicode-version
      type: string
      default: ""
      description: Sanicode version to install. Empty installs latest.
  workspaces:
    - name: source
      description: Workspace containing the source code to scan.
    - name: reports
      description: Workspace where scan reports are written.
  results:
    - name: findings-count
      description: Number of findings detected.
  steps:
    - name: install
      image: python:3.11-slim
      script: |
        #!/usr/bin/env bash
        set -e
        if [ -n "$(params.sanicode-version)" ]; then
          pip install "sanicode==$(params.sanicode-version)"
        else
          pip install sanicode
        fi

    - name: scan
      image: python:3.11-slim
      workingDir: $(workspaces.source.path)
      script: |
        #!/usr/bin/env bash
        set -e

        FORMATS=""
        IFS=',' read -ra FMT_LIST <<< "$(params.format)"
        for fmt in "${FMT_LIST[@]}"; do
          FORMATS="$FORMATS --format ${fmt// /}"
        done

        sanicode scan $(params.path) \
          $FORMATS \
          --fail-on $(params.fail-on)

        # Copy reports to the reports workspace
        cp -r sanicode-reports/ $(workspaces.reports.path)/

        # Write findings count as a task result
        if [ -f sanicode-reports/scan-result.json ]; then
          COUNT=$(python3 -c "import json; d=json.load(open('sanicode-reports/scan-result.json')); print(len(d.get('findings', [])))")
          printf "%s" "$COUNT" > $(results.findings-count.path)
        else
          printf "0" > $(results.findings-count.path)
        fi
```

### Pipeline integrating sanicode with a build

```yaml
apiVersion: tekton.dev/v1
kind: Pipeline
metadata:
  name: build-and-scan
spec:
  workspaces:
    - name: source
    - name: reports
  params:
    - name: fail-on
      type: string
      default: high
  tasks:
    - name: clone
      taskRef:
        name: git-clone
      workspaces:
        - name: output
          workspace: source
      params:
        - name: url
          value: https://github.com/your-org/your-repo

    - name: security-scan
      runAfter: [clone]
      taskRef:
        name: sanicode-scan
      workspaces:
        - name: source
          workspace: source
        - name: reports
          workspace: reports
      params:
        - name: fail-on
          value: $(params.fail-on)
        - name: format
          value: sarif,markdown,json
```

### Passing LLM API keys to Tekton tasks

Create an OpenShift Secret and mount it as an environment variable in the task step:

```yaml
    - name: scan
      image: python:3.11-slim
      env:
        - name: OPENAI_API_KEY
          valueFrom:
            secretKeyRef:
              name: sanicode-llm-keys
              key: openai-api-key
```

## Pre-commit

### Basic hook setup

Add the following to `.pre-commit-config.yaml` to run sanicode on every commit:

```yaml
repos:
  - repo: https://github.com/your-org/sanicode
    rev: v0.3.0  # Pin to a specific release tag
    hooks:
      - id: sanicode
```

The hook is defined in `.pre-commit-hooks.yaml` at the repository root with these defaults:

- Entry point: `sanicode scan`
- File types: `python`, `javascript`, `ts`, `php`
- Default args: `--format sarif --fail-on high`
- Runs serially (not in parallel with other hooks)

### Customizing the severity threshold

Override the default `--fail-on high` by supplying `args`:

```yaml
repos:
  - repo: https://github.com/your-org/sanicode
    rev: v0.3.0
    hooks:
      - id: sanicode
        args: ['--format', 'sarif', '--fail-on', 'critical']
```

Note that when supplying `args`, they replace the defaults entirely. Always include `--format sarif` unless you want a different output format.

### Using a local install (faster, no git clone)

If sanicode is already installed in your environment (for example, via `pip install sanicode` in your project's dev dependencies), use the `local` repo type to skip the git clone:

```yaml
repos:
  - repo: local
    hooks:
      - id: sanicode-local
        name: Sanicode Security Scan
        entry: sanicode scan --format sarif --fail-on high
        language: system
        types_or: [python, javascript, ts, php]
        pass_filenames: false
        require_serial: true
```

`pass_filenames: false` is required because sanicode scans the entire target directory, not individual files passed by pre-commit. `require_serial: true` prevents concurrent invocations.

### Scanning only specific file types

Restrict the hook to Python files only:

```yaml
repos:
  - repo: https://github.com/your-org/sanicode
    rev: v0.3.0
    hooks:
      - id: sanicode
        types_or: [python]
```

## Configuration Tips

### Using sanicode.toml in CI/CD

Commit a `sanicode.toml` at the repository root (or in a `ci/` subdirectory) to standardize scan configuration across all environments. This avoids duplicating flags across multiple pipeline definitions.

```toml
[scan]
include_extensions = [".py", ".js", ".ts", ".php"]
exclude_patterns = ["tests/", "node_modules/", ".venv/"]

[output]
formats = ["sarif", "markdown"]
output_dir = "sanicode-reports"

[compliance]
profiles = ["owasp-asvs", "nist-800-53"]
```

Reference it in CI with `--config sanicode.toml` or set the path in the action's `config` input.

### Environment variables for LLM API keys

Sanicode passes API keys through to LiteLLM, which uses standard provider environment variables. Never commit API keys to `sanicode.toml`. Instead:

| Provider | Environment variable |
|----------|---------------------|
| OpenAI | `OPENAI_API_KEY` |
| Anthropic | `ANTHROPIC_API_KEY` |
| Azure OpenAI | `AZURE_API_KEY`, `AZURE_API_BASE` |
| OpenShift AI / vLLM | Configure endpoint in `sanicode.toml`; use `SANICODE_LLM_API_KEY` or the provider's variable |

### Running in degraded mode (no LLM) for fast CI

When no LLM is configured, sanicode runs in degraded mode using AST pattern matching and the built-in rule set. This is significantly faster and requires no external credentials, making it appropriate for pre-commit hooks and fast CI gates.

To explicitly configure a scan without LLM enrichment, omit the `[llm]` section from `sanicode.toml` or use a stripped-down config file:

```toml
# ci/sanicode-fast.toml — no LLM, fast scan

[scan]
include_extensions = [".py", ".js", ".ts", ".php"]

[output]
formats = ["sarif"]
output_dir = "sanicode-reports"
```

```bash
sanicode scan . --config ci/sanicode-fast.toml --fail-on high
```

### Output directory management

All reports are written to the directory specified by `output.output_dir` in config (default: `sanicode-reports/`). The directory is created automatically. In CI, always archive this directory as a build artifact before the job exits, even on failure, so reports are available for investigation regardless of whether the gate passed.

### Caching strategies

Sanicode itself is a pure Python package with no compiled artifacts. Standard pip caching applies:

- **GitHub Actions**: Use `actions/setup-python@v5` with `cache: 'pip'` for automatic pip cache management.
- **GitLab CI**: Cache the pip download cache directory (set via `PIP_CACHE_DIR`).
- **Jenkins**: Use the Jenkins pip cache or a shared virtualenv on the agent.
- **Tekton**: Pre-bake sanicode into a custom task image (`FROM python:3.11-slim && RUN pip install sanicode==x.y.z`) to eliminate installation time per run.

## SARIF Output

SARIF (Static Analysis Results Interchange Format) is the standard interchange format for static analysis results. Sanicode writes SARIF 2.1.0 to `sanicode-reports/report.sarif` when `--format sarif` is specified.

Each SARIF finding includes:

- Rule ID (e.g., `PY-SQL-INJECTION`)
- CWE identifier
- OWASP ASVS 5.0 mapping
- NIST 800-53 control
- ASD STIG check ID
- Severity level
- File path and line number
- Message describing the issue

### GitHub Code Scanning

Upload SARIF via the `github/codeql-action/upload-sarif@v3` action. Results appear in the **Security > Code Scanning** tab. The `security-events: write` permission is required:

```yaml
permissions:
  security-events: write
  contents: read
```

Pull request annotations are generated automatically from SARIF findings that touch changed lines.

### Azure DevOps

With the Azure DevOps Advanced Security add-on, publish SARIF using the `PublishCodeAnalysisResult` task. Without it, archive the SARIF file as a pipeline artifact for downstream consumption.

### VS Code

Install the [SARIF Viewer extension](https://marketplace.visualstudio.com/items?itemName=MS-SarifVSCode.sarif-viewer) and open `sanicode-reports/report.sarif` directly. Findings are overlaid on the source files in the editor.

### SonarQube

SonarQube can import SARIF files using the [Generic Issue Import](https://docs.sonarqube.org/latest/analyzing-source-code/importing-external-issues/generic-issue-import-format/) feature or the SARIF import plugin (available in SonarQube 10.x+). Configure the `sonar.sarifReportPaths` property to point to `sanicode-reports/report.sarif`.

### Consuming SARIF programmatically

The SARIF file is valid JSON and can be parsed by any JSON tool for custom reporting or integration. The top-level structure follows the [SARIF 2.1.0 schema](https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html):

```
sarif.runs[0].results[]          — individual findings
sarif.runs[0].tool.driver.rules  — rule definitions with CWE/compliance metadata
```
