"""SQL injection test cases — all vulnerable."""
import sqlite3


def search_users(name):
    conn = sqlite3.connect("db.sqlite")
    cursor = conn.cursor()
    # Vulnerable: string formatting in SQL
    cursor.execute(f"SELECT * FROM users WHERE name = '{name}'")
    return cursor.fetchall()


def search_by_id(user_id):
    conn = sqlite3.connect("db.sqlite")
    cursor = conn.cursor()
    # Vulnerable: % formatting
    cursor.execute("SELECT * FROM users WHERE id = %s" % user_id)
    return cursor.fetchall()
