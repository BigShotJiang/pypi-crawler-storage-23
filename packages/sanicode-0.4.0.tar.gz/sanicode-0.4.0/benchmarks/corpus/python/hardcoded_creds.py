"""Hardcoded credentials — vulnerable."""
API_KEY = "sk-abc123def456"
DATABASE_PASSWORD = "super_secret_password"
SECRET_KEY = "my-secret-key-do-not-share"
