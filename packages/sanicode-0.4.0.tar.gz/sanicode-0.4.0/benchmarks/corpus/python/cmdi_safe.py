"""Command injection test cases — all safe."""
import subprocess


def ping_host(host):
    # Safe: list form, no shell
    subprocess.run(["ping", "-c", "1", host], check=True)
