"""XSS test cases — vulnerable."""
from django.utils.safestring import mark_safe


def render_user_bio(bio):
    # Vulnerable: mark_safe with non-literal (user-controlled) argument
    return mark_safe(bio)


def render_comment(comment):
    # Vulnerable: Markup with a variable
    from markupsafe import Markup
    return Markup(comment)
