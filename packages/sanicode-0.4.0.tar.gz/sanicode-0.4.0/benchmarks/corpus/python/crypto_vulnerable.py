"""Weak crypto test cases — vulnerable."""
import hashlib
import random


def hash_password(password):
    # Vulnerable: MD5 for password hashing
    return hashlib.md5(password.encode()).hexdigest()


def generate_token():
    # Vulnerable: insecure random
    return str(random.randint(0, 999999))
