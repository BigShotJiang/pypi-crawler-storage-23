"""FP: requests.get() with a variable URL that is validated as internal-only."""
import requests


ALLOWED_HOSTS = {"localhost", "127.0.0.1", "internal.svc"}


def fetch_internal(host: str, path: str) -> dict:
    if host not in ALLOWED_HOSTS:
        raise ValueError(f"Blocked host: {host}")
    url = f"http://{host}{path}"
    return requests.get(url).json()
