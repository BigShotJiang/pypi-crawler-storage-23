"""FP: os.system() with a hardcoded literal ping — not user-controlled."""
import os


def check_loopback():
    os.system("ping -c 1 127.0.0.1")
