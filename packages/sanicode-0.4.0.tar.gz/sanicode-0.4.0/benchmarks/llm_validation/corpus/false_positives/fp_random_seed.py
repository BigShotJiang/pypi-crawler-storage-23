"""FP: random.randint() generating test fixture data — not a security token."""
import random


def generate_test_id():
    return random.randint(1000, 9999)


def generate_test_data(n=10):
    return [random.randint(0, 100) for _ in range(n)]
