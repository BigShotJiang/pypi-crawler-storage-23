"""FP: eval() with a constant math expression string — static value only."""
import math


def circle_area(radius):
    pi = eval("math.pi")
    return pi * radius ** 2
