"""FP: open() with a path derived from a fixed base directory and trusted input."""
from pathlib import Path

STATIC_DIR = Path("/var/app/static")


def serve_static(filename: str) -> bytes:
    safe_name = Path(filename).name
    path = STATIC_DIR / safe_name
    return open(path).read()
