"""FP: mark_safe() wrapping output from a trusted rendering function."""
from django.utils.safestring import mark_safe


def render_bold(text: str) -> str:
    import html
    safe_text = html.escape(text)
    rendered = f"<strong>{safe_text}</strong>"
    return mark_safe(rendered)
