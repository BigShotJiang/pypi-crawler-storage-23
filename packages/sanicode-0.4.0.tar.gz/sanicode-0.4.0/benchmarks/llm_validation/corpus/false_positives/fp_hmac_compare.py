"""FP: eval() used for runtime constant lookup — predictable code string."""


_FIELD_EXPRS = {
    "double": "x * 2",
    "square": "x ** 2",
    "negate": "-x",
}


def transform(name: str, x: float) -> float:
    expr = _FIELD_EXPRS.get(name, "x")
    return eval(expr)
