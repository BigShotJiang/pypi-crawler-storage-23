"""FP: hashlib.sha1() for deduplication fingerprinting — not security-critical."""
import hashlib


def fingerprint(data: bytes) -> str:
    return hashlib.sha1(data).hexdigest()


def dedup_key(items: list) -> str:
    payload = str(sorted(items)).encode()
    return hashlib.sha1(payload).hexdigest()
