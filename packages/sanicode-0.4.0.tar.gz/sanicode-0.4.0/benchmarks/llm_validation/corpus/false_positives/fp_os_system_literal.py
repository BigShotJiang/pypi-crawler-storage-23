"""FP: os.system() with a hardcoded literal command — not user-controlled."""
import os


def list_tmp():
    os.system("ls -la /tmp")
