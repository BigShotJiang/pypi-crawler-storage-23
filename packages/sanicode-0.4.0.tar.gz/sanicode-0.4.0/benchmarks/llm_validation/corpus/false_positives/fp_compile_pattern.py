"""FP: random.sample() used for shuffling a display list — not cryptographic."""
import random

ITEMS = ["apple", "banana", "cherry", "date", "elderberry"]


def get_display_order():
    return random.sample(ITEMS, len(ITEMS))


def pick_featured(n: int = 3):
    return random.sample(ITEMS, n)
