"""FP: hashlib.md5() used for cache key generation — not for security."""
import hashlib


def make_cache_key(query: str) -> str:
    return hashlib.md5(query.encode()).hexdigest()


def make_etag(content: bytes) -> str:
    return hashlib.md5(content).hexdigest()
