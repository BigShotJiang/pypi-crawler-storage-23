"""FP: exec() building a namedtuple-like class — compile-time constant code."""


def make_point_class():
    namespace = {}
    exec("class Point:\n    def __init__(self, x, y): self.x=x; self.y=y", namespace)
    return namespace["Point"]
