"""FP: API_KEY set to a test fixture value — not a real credential."""
import pytest

API_KEY = "test-key-fixture-not-real"
SECRET_TOKEN = "test-secret-do-not-use-in-production"


@pytest.fixture
def mock_client():
    return {"api_key": API_KEY, "token": SECRET_TOKEN}
