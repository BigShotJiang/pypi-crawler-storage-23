"""FP: random.choice() selecting a display color — not a security operation."""
import random

DISPLAY_COLORS = ["red", "blue", "green", "yellow", "purple"]


def get_random_color():
    return random.choice(DISPLAY_COLORS)


def get_random_avatar():
    return random.randint(1, 20)
