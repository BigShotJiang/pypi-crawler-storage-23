"""FP: hashlib.md5() for file integrity checksum — not password hashing."""
import hashlib


def checksum(data: bytes) -> str:
    return hashlib.md5(data).hexdigest()


def verify_download(expected_md5: str, data: bytes) -> bool:
    return hashlib.md5(data).hexdigest() == expected_md5
