"""FP: os.path.join() with a filename from an allowlist — traversal prevented."""
import os

ALLOWED_REPORTS = {"summary", "detail", "audit"}
BASE_DIR = "/var/app/reports"


def get_report_path(report_name: str) -> str:
    if report_name not in ALLOWED_REPORTS:
        raise ValueError(f"Unknown report: {report_name}")
    return os.path.join(BASE_DIR, report_name + ".pdf")
