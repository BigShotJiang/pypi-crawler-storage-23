"""FP: hashlib.sha1() for content-addressable storage — not for security."""
import hashlib


def content_hash(blob: bytes) -> str:
    header = f"blob {len(blob)}\0".encode()
    return hashlib.sha1(header + blob).hexdigest()
