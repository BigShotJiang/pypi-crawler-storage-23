"""FP: pickle.loads() from an internal in-memory cache — controlled source."""
import pickle

_cache = {}


def set_cache(key, value):
    _cache[key] = pickle.dumps(value)


def get_cache(key):
    data = _cache.get(key)
    if data is None:
        return None
    return pickle.loads(data)
