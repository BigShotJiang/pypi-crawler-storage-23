"""FP: pickle.loads() from a local config file the app controls — not user data."""
import pickle
from pathlib import Path

CONFIG_PATH = Path("/var/myapp/config.pkl")


def load_config():
    data = CONFIG_PATH.read_bytes()
    return pickle.loads(data)
