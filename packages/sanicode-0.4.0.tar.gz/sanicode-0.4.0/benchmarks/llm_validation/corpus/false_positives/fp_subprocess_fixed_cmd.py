"""FP: os.system() with a fully hardcoded git command — not user-controlled."""
import os


def check_git_status():
    os.system("git status --short")


def show_git_log():
    os.system("git log --oneline -10")
