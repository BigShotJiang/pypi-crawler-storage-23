"""FP: mark_safe() on a pre-escaped variable — safe because html.escape() is applied."""
from django.utils.safestring import mark_safe
import html


def render_username_badge(username: str) -> str:
    escaped = html.escape(username)
    return mark_safe(escaped)
