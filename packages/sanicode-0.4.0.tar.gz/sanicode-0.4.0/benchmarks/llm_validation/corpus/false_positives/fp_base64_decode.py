"""FP: random.uniform() for Monte Carlo simulation — not security use."""
import random


def monte_carlo_pi(n_samples: int = 10000) -> float:
    inside = 0
    for _ in range(n_samples):
        x = random.uniform(0, 1)
        y = random.uniform(0, 1)
        if x * x + y * y <= 1:
            inside += 1
    return 4 * inside / n_samples
