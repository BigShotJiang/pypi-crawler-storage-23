"""FP: pickle.loads() from an app-controlled serialized session in Redis."""
import pickle


class SessionStore:
    def __init__(self, redis_client):
        self._redis = redis_client

    def get_session(self, session_id: str):
        raw = self._redis.get(f"session:{session_id}")
        if raw is None:
            return {}
        return pickle.loads(raw)
