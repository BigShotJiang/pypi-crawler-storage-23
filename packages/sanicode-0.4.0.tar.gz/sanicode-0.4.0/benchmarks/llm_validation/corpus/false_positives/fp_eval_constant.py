"""FP: eval() with a compile-time constant string — no user input involved."""


def double(x):
    result = eval("x * 2")
    return result
