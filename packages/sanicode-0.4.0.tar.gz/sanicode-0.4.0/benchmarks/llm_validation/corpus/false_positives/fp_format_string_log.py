"""FP: exec() running a pre-built constant code string — no user input."""

_SETUP_CODE = """
import sys
sys.dont_write_bytecode = True
"""


def configure_runtime():
    exec(_SETUP_CODE)
