"""CD: random.randint() used to generate an API token — VULNERABLE (insecure PRNG)."""
import random
import time


def generate_api_token(user_id: int) -> str:
    nonce = random.randint(0, 2**32)
    return f"tok_{user_id}_{nonce}_{int(time.time())}"


def generate_csrf_token() -> str:
    return str(random.randint(10**15, 10**16 - 1))
