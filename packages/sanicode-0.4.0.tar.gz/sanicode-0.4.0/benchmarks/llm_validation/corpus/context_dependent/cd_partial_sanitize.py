"""CD: Only some code paths use parameterization — VULNERABLE overall."""
import sqlite3


def query_user(user_id, search_term=None):
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    if search_term:
        cursor.execute(f"SELECT * FROM users WHERE name LIKE '{search_term}%'")
    else:
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    return cursor.fetchall()
