"""CD: open() with path validated by decorator — NOT vulnerable (decorator guards)."""
ALLOWED = {"/data/report.csv", "/data/summary.txt", "/data/audit.log"}


def require_allowed_path(func):
    def wrapper(path, *args, **kwargs):
        if path not in ALLOWED:
            raise PermissionError(f"Access denied: {path}")
        return func(path, *args, **kwargs)
    return wrapper


@require_allowed_path
def read_file(path: str) -> str:
    with open(path) as f:
        return f.read()
