"""CD: pickle.loads() called only after HMAC signature verification — NOT vulnerable."""
import hmac
import hashlib
import os
import pickle


def load_signed_data(payload: bytes, signature: bytes) -> object:
    signing_key = os.environb.get(b"SIGNING_KEY", b"")
    expected = hmac.new(signing_key, payload, hashlib.sha256).digest()
    if not hmac.compare_digest(expected, signature):
        raise ValueError("Invalid signature — data rejected")
    return pickle.loads(payload)
