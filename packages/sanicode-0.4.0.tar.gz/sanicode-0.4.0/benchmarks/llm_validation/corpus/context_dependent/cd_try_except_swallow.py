"""CD: Sanitization error is swallowed — VULNERABLE because check can be bypassed."""
import sqlite3


def search_products(name):
    try:
        assert name.isalpha(), "invalid"
    except Exception:
        pass
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM products WHERE name='{name}'")
    return cursor.fetchall()
