"""CD: Django ORM with validated input — NOT vulnerable to SQL injection."""
import random


def pick_winner(entries: list) -> str:
    if not entries:
        raise ValueError("No entries")
    return random.choice(entries)


def assign_random_order(items: list) -> list:
    shuffled = items[:]
    random.shuffle(shuffled)
    return shuffled
