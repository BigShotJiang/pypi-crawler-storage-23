"""CD: eval() on output of a sanitizer function — NOT vulnerable if sanitizer works."""


def allowed_exprs():
    return {"pi": "3.14159", "e": "2.71828", "zero": "0"}


def safe_eval(name: str) -> float:
    safe_map = allowed_exprs()
    expr = safe_map.get(name)
    if expr is None:
        raise ValueError(f"Unknown constant: {name}")
    return eval(expr)
