"""CD: Validation depends on a config flag that can be disabled — VULNERABLE."""
import os

STRICT_MODE = False


def run_command(cmd: str) -> str:
    if STRICT_MODE:
        if not cmd.startswith("safe_"):
            raise ValueError("Command not allowed")
    os.system(cmd)
    return "done"
