"""CD: Cached result skips sanitization on cache hit — VULNERABLE path."""
import sqlite3

_cache = {}


def get_user(name: str):
    if name in _cache:
        return _cache[name]
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM users WHERE name='{name}'")
    result = cursor.fetchone()
    _cache[name] = result
    return result
