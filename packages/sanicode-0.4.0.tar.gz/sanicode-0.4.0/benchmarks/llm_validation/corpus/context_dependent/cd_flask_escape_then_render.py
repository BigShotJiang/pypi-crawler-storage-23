"""CD: mark_safe() after html.escape() — NOT vulnerable (escaping applied first)."""
from django.utils.safestring import mark_safe
import html


def safe_render(user_input: str) -> str:
    sanitized = html.escape(user_input, quote=True)
    return mark_safe(sanitized)
