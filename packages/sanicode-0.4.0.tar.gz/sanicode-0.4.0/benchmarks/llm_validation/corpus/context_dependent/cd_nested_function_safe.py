"""CD: mark_safe() receiving pre-escaped output from helper function — NOT vulnerable."""
from django.utils.safestring import mark_safe


def _escape_for_display(text: str) -> str:
    import html
    return html.escape(text, quote=True)


def render_title(raw_title: str) -> str:
    safe_title = _escape_for_display(raw_title)
    return mark_safe(safe_title)
