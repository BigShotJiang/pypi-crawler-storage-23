"""CD: SQL uses parameterized query — NOT vulnerable (no string formatting)."""
import sqlite3


def get_user_safe(user_id):
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    return cursor.fetchone()
