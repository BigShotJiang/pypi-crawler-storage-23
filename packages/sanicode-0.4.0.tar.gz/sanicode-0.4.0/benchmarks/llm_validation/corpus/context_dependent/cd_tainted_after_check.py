"""CD: Check passes but data is modified after — VULNERABLE (taint after validation)."""
import sqlite3


def get_item(name: str):
    assert name.isalnum()
    name = name + "'--"
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM items WHERE name='{name}'")
    return cursor.fetchone()
