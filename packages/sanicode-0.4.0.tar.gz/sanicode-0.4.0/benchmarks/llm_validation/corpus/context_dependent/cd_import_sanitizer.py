"""CD: open() called with path from validated file list — NOT vulnerable."""
import os

ALLOWED_FILES = frozenset(["report.txt", "summary.txt", "audit.log"])
DATA_DIR = "/var/data"


def read_report(filename: str) -> str:
    clean_name = os.path.basename(filename)
    if clean_name not in ALLOWED_FILES:
        raise PermissionError(f"Access denied: {clean_name}")
    full_path = os.path.join(DATA_DIR, clean_name)
    with open(full_path) as f:
        return f.read()
