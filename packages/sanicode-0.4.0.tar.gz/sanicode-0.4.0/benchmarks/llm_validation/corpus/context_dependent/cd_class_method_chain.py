"""CD: hashlib.md5() used as a cache key — NOT vulnerable (not security use)."""
import hashlib


class QueryCache:
    def __init__(self):
        self._store = {}

    def _key(self, query: str) -> str:
        return hashlib.md5(query.encode()).hexdigest()

    def get(self, query: str):
        return self._store.get(self._key(query))

    def set(self, query: str, result):
        self._store[self._key(query)] = result
