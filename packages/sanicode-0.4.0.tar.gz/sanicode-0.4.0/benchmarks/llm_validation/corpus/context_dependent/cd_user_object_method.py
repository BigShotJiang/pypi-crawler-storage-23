"""CD: open() with path from a trusted internal config object — NOT vulnerable."""


class AppConfig:
    _allowed_dirs = {"/var/data", "/var/reports"}

    def resolve_path(self, subdir: str, filename: str) -> str:
        import os
        if subdir not in self._allowed_dirs:
            raise PermissionError(f"Blocked: {subdir}")
        return os.path.join(subdir, os.path.basename(filename))


cfg = AppConfig()


def read_data(subdir: str, filename: str) -> str:
    path = cfg.resolve_path(subdir, filename)
    with open(path) as f:
        return f.read()
