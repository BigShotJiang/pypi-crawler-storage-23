"""CD: os.system() used conditionally — VULNERABLE on the user-input path."""
import os
import sys


def run_tool(tool_name, args=None):
    if tool_name == "ls":
        os.system("ls -la")
    else:
        os.system(tool_name)
