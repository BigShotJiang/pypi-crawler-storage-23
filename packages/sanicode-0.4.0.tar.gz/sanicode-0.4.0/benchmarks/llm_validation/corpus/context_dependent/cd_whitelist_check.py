"""CD: requests.get() with URL constrained to an allowlist prefix — NOT vulnerable."""
import requests

ALLOWED_BASE = "https://api.internal.example.com/"


def call_internal_api(endpoint: str) -> dict:
    if not endpoint.startswith(ALLOWED_BASE):
        raise ValueError(f"Blocked URL: {endpoint}")
    return requests.get(endpoint).json()
