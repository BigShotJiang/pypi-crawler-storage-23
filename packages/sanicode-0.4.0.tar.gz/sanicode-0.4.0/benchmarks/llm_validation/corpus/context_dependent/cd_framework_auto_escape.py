"""CD: requests.get() fetching a URL built from validated components — NOT SSRF."""
import requests

SAFE_DOMAINS = {"api.example.com", "metrics.example.com"}


def fetch_metric(domain: str, metric: str) -> dict:
    if domain not in SAFE_DOMAINS:
        raise ValueError(f"Blocked domain: {domain}")
    safe_metric = metric.replace("/", "").replace("..", "")
    url = f"https://{domain}/metrics/{safe_metric}"
    return requests.get(url).json()
