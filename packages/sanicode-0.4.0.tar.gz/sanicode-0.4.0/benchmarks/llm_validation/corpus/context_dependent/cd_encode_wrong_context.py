"""CD: SQL query uses HTML-escaped value — VULNERABLE (wrong encoding for SQL)."""
import html
import sqlite3


def search_items(name: str):
    escaped = html.escape(name)
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM items WHERE name='{escaped}'")
    return cursor.fetchall()
