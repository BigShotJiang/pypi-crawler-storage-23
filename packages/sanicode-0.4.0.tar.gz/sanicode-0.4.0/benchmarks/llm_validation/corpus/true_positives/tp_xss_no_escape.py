"""TP: mark_safe() with unsanitized comment body — reflected XSS."""
from django.utils.safestring import mark_safe


def render_comment(comment_text):
    wrapped = f"<p class='comment'>{comment_text}</p>"
    return mark_safe(wrapped)
