"""TP: Hardcoded live API key — exposed production credential."""

API_KEY = "sk-live-abc123def456ghi789"
SECRET = "prod-secret-xyz987wvu654"
