"""TP: requests.get() with user-provided URL — SSRF, allows internal probing."""
import requests
from flask import Flask, request

app = Flask(__name__)


@app.route("/fetch")
def fetch():
    url = request.args.get("url")
    return requests.get(url).text
