"""TP: exec() running user-supplied script code — arbitrary code execution."""
from flask import Flask, request

app = Flask(__name__)


@app.route("/script", methods=["POST"])
def run_script():
    script = request.form.get("script", "")
    namespace = {}
    exec(script, namespace)
    return str(namespace.get("result", ""))
