"""TP: SQL injection via % formatting in execute() — user input in query."""
import sqlite3


def get_record(table, record_id):
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM %s WHERE id = %d" % (table, record_id))
    return cursor.fetchall()
