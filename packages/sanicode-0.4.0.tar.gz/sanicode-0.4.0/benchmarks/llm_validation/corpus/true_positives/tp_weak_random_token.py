"""TP: random.randint() generating a session token — predictable, not secure."""
import random


def generate_session_token() -> str:
    token = random.randint(0, 999999)
    return str(token).zfill(6)


def generate_reset_code() -> int:
    return random.randint(100000, 999999)
