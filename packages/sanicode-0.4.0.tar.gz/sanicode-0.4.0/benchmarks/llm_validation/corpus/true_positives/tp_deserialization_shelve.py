"""TP: yaml.load() parsing user-uploaded YAML without safe Loader — code exec."""
import yaml
from flask import Flask, request

app = Flask(__name__)


@app.route("/import", methods=["POST"])
def import_data():
    raw = request.data.decode("utf-8")
    return str(yaml.load(raw))
