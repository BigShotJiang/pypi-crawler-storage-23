"""TP: mark_safe() wrapping unsanitized user bio — stored XSS."""
from django.utils.safestring import mark_safe


def render_user_bio(user_bio: str) -> str:
    return mark_safe(user_bio)
