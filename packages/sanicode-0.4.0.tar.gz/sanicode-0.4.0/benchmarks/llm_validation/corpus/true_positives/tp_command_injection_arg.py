"""TP: os.system() with user-controlled search pattern — command injection."""
import os


def grep_logs(pattern):
    os.system("grep " + pattern + " /var/log/app.log")
