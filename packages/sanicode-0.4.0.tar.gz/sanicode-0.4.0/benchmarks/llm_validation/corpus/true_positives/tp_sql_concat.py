"""TP: SQL injection via % formatting in INSERT execute() — user input in query."""
import sqlite3


def insert_log(conn, msg):
    cursor = conn.cursor()
    cursor.execute("INSERT INTO logs (message) VALUES ('%s')" % msg)
    conn.commit()
