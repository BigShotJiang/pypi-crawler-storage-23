"""TP: eval() parsing user-supplied arithmetic expression — code execution risk."""
from flask import Flask, request

app = Flask(__name__)


@app.route("/evaluate")
def evaluate():
    expression = request.args.get("expr", "0")
    return str(eval(expression))
