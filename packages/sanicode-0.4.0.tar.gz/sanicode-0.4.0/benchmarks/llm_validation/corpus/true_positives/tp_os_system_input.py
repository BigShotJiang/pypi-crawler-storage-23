"""TP: os.system() with user-controlled input — command injection."""
import os


def ping_host(user_input):
    os.system(f"ping -c 1 {user_input}")
