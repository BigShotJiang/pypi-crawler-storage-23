"""TP: yaml.load() without Loader — arbitrary Python object deserialization."""
import yaml


def parse_config(config_text: str) -> dict:
    return yaml.load(config_text)


def parse_user_upload(data: str) -> dict:
    return yaml.load(data)
