"""TP: subprocess.run() with shell=True and user-controlled path — injection risk."""
import subprocess


def search_files(path):
    result = subprocess.run(f"find {path} -name '*.log'", shell=True, capture_output=True)
    return result.stdout.decode()
