"""TP: open() with unsanitized user filename — path traversal risk."""
from flask import Flask, request

app = Flask(__name__)
UPLOAD_DIR = "/uploads/"


@app.route("/download")
def download():
    filename = request.args.get("file")
    filepath = UPLOAD_DIR + filename
    with open(filepath) as f:
        return f.read()
