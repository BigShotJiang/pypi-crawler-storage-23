"""TP: Hardcoded database password in source code — credential leak risk."""

DB_HOST = "db.internal"
DB_PASSWORD = "super_secret_123"
DB_USER = "admin"
