"""TP: requests.get() fetching user-provided URL without validation — SSRF."""
import requests
from flask import Flask, request

app = Flask(__name__)


@app.route("/proxy")
def proxy():
    target = request.args.get("target")
    response = requests.get(target)
    return response.content
