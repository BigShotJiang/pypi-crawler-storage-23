"""TP: eval() on user-provided form input — remote code execution."""
from flask import Flask, request

app = Flask(__name__)


@app.route("/calc", methods=["POST"])
def calculate():
    expr = request.form["expr"]
    result = eval(expr)
    return str(result)
