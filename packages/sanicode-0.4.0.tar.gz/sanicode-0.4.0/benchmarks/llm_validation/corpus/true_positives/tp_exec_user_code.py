"""TP: exec() on user-submitted JSON code — remote code execution."""
from flask import Flask, request

app = Flask(__name__)


@app.route("/run", methods=["POST"])
def run_code():
    code = request.json["code"]
    exec(code)
    return "done"
