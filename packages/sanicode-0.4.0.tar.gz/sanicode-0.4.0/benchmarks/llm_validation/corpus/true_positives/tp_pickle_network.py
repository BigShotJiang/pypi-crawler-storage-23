"""TP: pickle.loads() on data received from a network socket — untrusted source."""
import pickle
import socket


def receive_object(sock: socket.socket):
    data = sock.recv(4096)
    return pickle.loads(data)
