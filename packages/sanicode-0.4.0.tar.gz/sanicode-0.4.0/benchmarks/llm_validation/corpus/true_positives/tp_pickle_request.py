"""TP: pickle.loads() on raw HTTP request body — arbitrary code execution."""
import pickle
from flask import Flask, request

app = Flask(__name__)


@app.route("/load", methods=["POST"])
def load_data():
    obj = pickle.loads(request.data)
    return str(obj)
