"""TP: hashlib.sha1() for password storage — weak algorithm."""
import hashlib


def store_password(password: str) -> str:
    return hashlib.sha1(password.encode("utf-8")).hexdigest()


def check_password(password: str, hashed: str) -> bool:
    return hashlib.sha1(password.encode("utf-8")).hexdigest() == hashed
