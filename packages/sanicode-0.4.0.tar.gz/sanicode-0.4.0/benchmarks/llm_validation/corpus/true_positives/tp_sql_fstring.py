"""TP: SQL injection via f-string in execute() — user input directly in query."""
import sqlite3


def get_user(name):
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    cursor.execute(f"SELECT * FROM users WHERE name='{name}'")
    return cursor.fetchall()
