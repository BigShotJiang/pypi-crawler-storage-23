"""TP: random.choice() used to generate a one-time password — insecure PRNG."""
import random
import string


def generate_otp(length: int = 6) -> str:
    digits = string.digits
    return "".join(random.choice(digits) for _ in range(length))


def generate_temp_password(length: int = 8) -> str:
    chars = string.ascii_letters + string.digits
    return "".join(random.choice(chars) for _ in range(length))
