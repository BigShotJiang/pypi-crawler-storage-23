#!/usr/bin/env bash
# validate-granite.sh — Deployment validation for Granite Code 8B on OpenShift
#
# Usage:
#   GRANITE_ENDPOINT=http://host:port bash scripts/validate-granite.sh
#
# Default endpoint: http://granite-code-8b.granite-code.svc.cluster.local:8080

set -euo pipefail

ENDPOINT="${GRANITE_ENDPOINT:-http://granite-code-8b.granite-code.svc.cluster.local:8080}"
MODEL_NAME="${GRANITE_MODEL_NAME:-granite-code-8b}"
PASS=0
FAIL=0

log_pass() { echo "  PASS: $1"; PASS=$((PASS + 1)); }
log_fail() { echo "  FAIL: $1"; FAIL=$((FAIL + 1)); }

echo "Validating Granite Code 8B at ${ENDPOINT}"
echo "Model name: ${MODEL_NAME}"
echo "---"

# 1. Health check
echo "[1/5] Health endpoint..."
if curl -sf "${ENDPOINT}/health" -o /dev/null; then
    log_pass "/health returns 200"
else
    log_fail "/health is not reachable"
fi

# 2. Model listing
echo "[2/5] Model listing..."
MODELS_RESP=$(curl -sf "${ENDPOINT}/v1/models" 2>/dev/null || echo "")
if [ -z "$MODELS_RESP" ]; then
    log_fail "/v1/models is not reachable"
else
    if echo "$MODELS_RESP" | python3 -c "
import sys, json
data = json.load(sys.stdin)
ids = [m['id'] for m in data.get('data', [])]
if '${MODEL_NAME}' in ids:
    sys.exit(0)
else:
    print(f'  Available models: {ids}', file=sys.stderr)
    sys.exit(1)
" 2>&1; then
        log_pass "Model ${MODEL_NAME} found in /v1/models"
    else
        log_fail "Model ${MODEL_NAME} NOT found in /v1/models"
    fi
fi

# 3. Completion request
echo "[3/5] Test completion..."
COMPLETION_RESP=$(curl -sf "${ENDPOINT}/v1/completions" \
    -H "Content-Type: application/json" \
    -d '{
        "model": "'"${MODEL_NAME}"'",
        "prompt": "def hello():\n    return ",
        "max_tokens": 20,
        "temperature": 0.0
    }' 2>/dev/null || echo "")
if [ -z "$COMPLETION_RESP" ]; then
    log_fail "Completion request failed"
else
    HAS_CHOICES=$(echo "$COMPLETION_RESP" | python3 -c "
import sys, json
data = json.load(sys.stdin)
choices = data.get('choices', [])
if choices and choices[0].get('text', ''):
    print(choices[0]['text'][:60])
    sys.exit(0)
sys.exit(1)
" 2>&1 || echo "")
    if [ -n "$HAS_CHOICES" ]; then
        log_pass "Completion returned: ${HAS_CHOICES}"
    else
        log_fail "Completion response missing choices"
    fi
fi

# 4. Chat completion (classify prompt)
echo "[4/5] Classification prompt..."
CLASSIFY_RESP=$(curl -sf "${ENDPOINT}/v1/chat/completions" \
    -H "Content-Type: application/json" \
    -d '{
        "model": "'"${MODEL_NAME}"'",
        "messages": [
            {
                "role": "user",
                "content": "You are a code security classifier. Analyze: eval(user_input) at app.py:10. Respond ONLY with JSON: {\"is_true_positive\": true, \"confidence\": 0.95, \"reasoning\": \"eval on user input\"}"
            }
        ],
        "max_tokens": 200,
        "temperature": 0.0
    }' 2>/dev/null || echo "")
if [ -z "$CLASSIFY_RESP" ]; then
    log_fail "Chat completion request failed"
else
    CONTENT=$(echo "$CLASSIFY_RESP" | python3 -c "
import sys, json
data = json.load(sys.stdin)
choices = data.get('choices', [])
if choices:
    msg = choices[0].get('message', {}).get('content', '')
    if msg:
        print(msg[:120])
        sys.exit(0)
sys.exit(1)
" 2>&1 || echo "")
    if [ -n "$CONTENT" ]; then
        log_pass "Chat response: ${CONTENT}"
    else
        log_fail "Chat completion response missing content"
    fi
fi

# 5. Response contains JSON structure
echo "[5/5] JSON structure in classification response..."
if [ -n "$CLASSIFY_RESP" ]; then
    echo "$CLASSIFY_RESP" | python3 -c "
import sys, json
data = json.load(sys.stdin)
content = data.get('choices', [{}])[0].get('message', {}).get('content', '')
# Strip markdown fences if present
if content.strip().startswith('\`\`\`'):
    content = content.strip().split('\n', 1)[1].rsplit('\`\`\`', 1)[0].strip()
result = json.loads(content)
required = {'is_true_positive', 'confidence', 'reasoning'}
found = set(result.keys()) & required
if found == required:
    sys.exit(0)
else:
    print(f'  Missing keys: {required - found}', file=sys.stderr)
    sys.exit(1)
" 2>/dev/null
    if [ $? -eq 0 ]; then
        log_pass "Classification response contains valid JSON with required keys"
    else
        log_fail "Classification response does not contain expected JSON structure"
    fi
else
    log_fail "No classification response to validate"
fi

# Summary
echo ""
echo "=== Validation Summary ==="
echo "  Passed: ${PASS}"
echo "  Failed: ${FAIL}"
echo ""

if [ "$FAIL" -gt 0 ]; then
    echo "VERDICT: FAIL"
    exit 1
else
    echo "VERDICT: PASS"
    exit 0
fi
