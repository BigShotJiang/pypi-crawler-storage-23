#!/usr/bin/env bash
# Release automation for sanicode.
#
# Usage: ./scripts/release.sh <version> "<commit-message>"
# Example: ./scripts/release.sh 0.2.0 "Add API server and Prometheus metrics"
#
# What this script does:
#   1. Validates version format (x.y.z)
#   2. Checks for uncommitted changes
#   3. Updates version in version.py and pyproject.toml
#   4. Verifies both files match
#   5. Commits, tags (vx.y.z), and pushes to origin
#   6. GitHub Actions handles the rest (test → release → publish)

set -euo pipefail

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

VERSION="${1:-}"
MESSAGE="${2:-}"

# --- Validation ---

if [[ -z "$VERSION" || -z "$MESSAGE" ]]; then
    echo -e "${RED}Usage: $0 <version> \"<commit-message>\"${NC}"
    echo "Example: $0 0.2.0 \"Add API server and Prometheus metrics\""
    exit 1
fi

if ! [[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo -e "${RED}Error: Version must be in x.y.z format (got: $VERSION)${NC}"
    exit 1
fi

# Must be run from project root
if [[ ! -f "pyproject.toml" || ! -f "src/sanicode/version.py" ]]; then
    echo -e "${RED}Error: Must be run from the sanicode project root${NC}"
    exit 1
fi

# Check for uncommitted changes (allow version files and docs)
if ! git diff --quiet -- . ':!src/sanicode/version.py' ':!pyproject.toml' ':!PUBLISHING.md' ':!CLAUDE.md'; then
    echo -e "${RED}Error: Uncommitted changes detected. Commit or stash them first.${NC}"
    git status --short
    exit 1
fi

if ! git diff --cached --quiet; then
    echo -e "${RED}Error: Staged changes detected. Commit or unstage them first.${NC}"
    git status --short
    exit 1
fi

echo -e "${YELLOW}Releasing sanicode v${VERSION}${NC}"
echo ""

# --- Update version files ---

echo -e "${GREEN}Updating src/sanicode/version.py ...${NC}"
sed -i.bak "s/__version__ = \".*\"/__version__ = \"${VERSION}\"/" src/sanicode/version.py
rm -f src/sanicode/version.py.bak

echo -e "${GREEN}Updating pyproject.toml ...${NC}"
sed -i.bak "s/^version = \".*\"/version = \"${VERSION}\"/" pyproject.toml
rm -f pyproject.toml.bak

# --- Verify ---

PY_VERSION=$(grep '__version__' src/sanicode/version.py | cut -d'"' -f2)
TOML_VERSION=$(grep '^version = ' pyproject.toml | head -1 | cut -d'"' -f2)

if [[ "$PY_VERSION" != "$VERSION" ]]; then
    echo -e "${RED}Error: version.py has ${PY_VERSION}, expected ${VERSION}${NC}"
    exit 1
fi

if [[ "$TOML_VERSION" != "$VERSION" ]]; then
    echo -e "${RED}Error: pyproject.toml has ${TOML_VERSION}, expected ${VERSION}${NC}"
    exit 1
fi

echo -e "${GREEN}Both files now at v${VERSION}${NC}"
echo ""

# --- Show diff ---

git diff --stat
echo ""
git diff src/sanicode/version.py pyproject.toml
echo ""

# --- Commit, tag, push ---

echo -e "${YELLOW}Committing ...${NC}"
git add src/sanicode/version.py pyproject.toml
git commit -m "release: v${VERSION} — ${MESSAGE}"

echo -e "${YELLOW}Tagging v${VERSION} ...${NC}"
git tag -a "v${VERSION}" -m "v${VERSION}: ${MESSAGE}"

echo -e "${YELLOW}Pushing to origin ...${NC}"
git push origin main
git push origin "v${VERSION}"

echo ""
echo -e "${GREEN}Release v${VERSION} triggered.${NC}"
echo ""
echo "  Monitor CI:  https://github.com/rdwj/sanicode/actions"
echo "  Release:     https://github.com/rdwj/sanicode/releases/tag/v${VERSION}"
echo "  PyPI:        https://pypi.org/project/sanicode/${VERSION}/"
