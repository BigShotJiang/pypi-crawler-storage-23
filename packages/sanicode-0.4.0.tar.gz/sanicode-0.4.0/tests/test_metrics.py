"""Tests for the centralized metrics module."""

from __future__ import annotations

import pytest

from sanicode import metrics


class TestMetricDefinitions:
    """Verify all metrics import correctly and accept their labels."""

    def test_scans_total_labels(self):
        metrics.SCANS_TOTAL.labels(profile="default", status="submitted")

    def test_scan_duration_labels(self):
        metrics.SCAN_DURATION.labels(profile="default", llm_tier="fast")

    def test_active_scans_no_labels(self):
        # Gauge without labels — just verify it exists
        assert metrics.ACTIVE_SCANS._name == "sanicode_scans_in_progress"

    def test_findings_total_labels(self):
        metrics.FINDINGS_TOTAL.labels(severity="high", cwe_id="78", namespace="local")

    def test_findings_by_category_labels(self):
        metrics.FINDINGS_BY_CATEGORY.labels(category="injection", namespace="local")

    def test_compliance_score_labels(self):
        metrics.COMPLIANCE_SCORE.labels(profile="default", namespace="local")

    def test_controls_passing_labels(self):
        metrics.CONTROLS_PASSING.labels(framework="owasp_asvs")

    def test_controls_failing_labels(self):
        metrics.CONTROLS_FAILING.labels(framework="nist_800_53")

    def test_llm_requests_total_labels(self):
        metrics.LLM_REQUESTS_TOTAL.labels(model="granite-code-8b", tier="fast")

    def test_llm_request_duration_labels(self):
        metrics.LLM_REQUEST_DURATION.labels(tier="analysis")

    def test_llm_errors_total_labels(self):
        metrics.LLM_ERRORS_TOTAL.labels(model="granite-code-8b", error_type="TimeoutError")

    def test_llm_tokens_consumed_labels(self):
        metrics.LLM_TOKENS_CONSUMED.labels(tier="fast", direction="prompt")

    def test_graph_nodes_total_labels(self):
        metrics.GRAPH_NODES_TOTAL.labels(type="entry_point")

    def test_graph_edges_total_no_labels(self):
        assert metrics.GRAPH_EDGES_TOTAL._name == "sanicode_graph_edges_total"

    def test_graph_build_duration_no_labels(self):
        assert metrics.GRAPH_BUILD_DURATION._name == "sanicode_graph_build_duration_seconds"

    def test_analyze_total_no_labels(self):
        # prometheus_client strips the _total suffix from Counter._name
        assert metrics.ANALYZE_TOTAL._name == "sanicode_analyze"

    def test_phase3_placeholders_exist(self):
        """Phase 3 counters exist but don't need labels."""
        # prometheus_client strips _total from Counter._name; Gauge keeps full name
        assert metrics.FINDINGS_RESOLVED_TOTAL._name == "sanicode_findings_resolved"
        assert metrics.FINDINGS_REGRESSED_TOTAL._name == "sanicode_findings_regressed"
        assert metrics.EXCEPTIONS_ACTIVE._name == "sanicode_exceptions_active"


class TestMetricLabelErrors:
    """Verify that wrong labels raise ValueError."""

    def test_wrong_label_name_raises(self):
        with pytest.raises(ValueError):
            metrics.SCANS_TOTAL.labels(wrong_label="x")

    def test_missing_required_label_raises(self):
        # Providing only one of two required labels raises ValueError
        with pytest.raises(ValueError):
            metrics.SCANS_TOTAL.labels(profile="default")
