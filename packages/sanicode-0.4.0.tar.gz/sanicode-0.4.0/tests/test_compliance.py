"""Tests for compliance mapping and finding enrichment."""

from __future__ import annotations

from pathlib import Path

import pytest

from sanicode.compliance.enrichment import (
    EnrichedFinding,
    compute_compliance_score,
    compute_control_status,
    enrich_finding,
    enrich_findings,
)
from sanicode.compliance.mapper import (
    ComplianceMapper,
    ComplianceMapping,
    derive_severity,
)
from sanicode.scanner.patterns import Finding

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def mapper() -> ComplianceMapper:
    """Shared ComplianceMapper loaded once per test module."""
    return ComplianceMapper()


def _finding(cwe_id: int, rule_id: str = "SC001") -> Finding:
    """Build a minimal Finding for a given CWE ID."""
    return Finding(
        file=Path("example.py"),
        line=10,
        column=4,
        rule_id=rule_id,
        message="test finding",
        severity="high",
        cwe_id=cwe_id,
    )


# ---------------------------------------------------------------------------
# ComplianceMapper.map_cwe — known CWEs
# ---------------------------------------------------------------------------

ALL_KNOWN_CWES = [
    20, 22, 73, 77, 78, 79, 88, 89, 90, 94,
    113, 116, 120, 122, 125, 134, 190,
    200, 209, 250, 256, 269, 284, 287, 306, 311, 312, 319,
    326, 327, 328, 329, 330, 346, 352, 362,
    400, 416, 434, 476, 502, 532, 601, 611, 613, 732, 776, 787, 798,
    862, 916, 917, 918, 1333,
]


@pytest.mark.parametrize("cwe_id", ALL_KNOWN_CWES)
def test_map_cwe_returns_nonempty_asvs(mapper: ComplianceMapper, cwe_id: int) -> None:
    m = mapper.map_cwe(cwe_id)
    assert m.owasp_asvs, f"CWE-{cwe_id} should have at least one ASVS entry"


@pytest.mark.parametrize("cwe_id", ALL_KNOWN_CWES)
def test_map_cwe_returns_nonempty_nist(mapper: ComplianceMapper, cwe_id: int) -> None:
    m = mapper.map_cwe(cwe_id)
    assert m.nist_800_53, f"CWE-{cwe_id} should have at least one NIST 800-53 control"


@pytest.mark.parametrize("cwe_id", ALL_KNOWN_CWES)
def test_map_cwe_populates_cwe_name(mapper: ComplianceMapper, cwe_id: int) -> None:
    m = mapper.map_cwe(cwe_id)
    assert m.cwe_name, f"CWE-{cwe_id} should have a non-empty cwe_name"


@pytest.mark.parametrize("cwe_id", ALL_KNOWN_CWES)
def test_map_cwe_populates_asvs_level(mapper: ComplianceMapper, cwe_id: int) -> None:
    m = mapper.map_cwe(cwe_id)
    assert m.asvs_level in ("L1", "L2", "L3"), (
        f"CWE-{cwe_id} asvs_level should be L1/L2/L3, got '{m.asvs_level}'"
    )


# STIG category populated only for CWEs that have STIG entries
_CWES_WITH_STIG = [
    20, 22, 73, 77, 78, 79, 88, 89, 90, 94,
    113, 116, 120, 122, 125, 134,
    200, 209, 250, 256, 269, 284, 287, 306,
    346, 352, 416, 434, 502, 532, 601, 611, 613, 732, 776, 787, 798,
    862, 917,
]


@pytest.mark.parametrize("cwe_id", _CWES_WITH_STIG)
def test_map_cwe_populates_stig_category(mapper: ComplianceMapper, cwe_id: int) -> None:
    m = mapper.map_cwe(cwe_id)
    assert m.stig_category in ("CAT I", "CAT II", "CAT III"), (
        f"CWE-{cwe_id} stig_category should be CAT I/II/III, got '{m.stig_category}'"
    )


def test_map_cwe_unknown_returns_empty(mapper: ComplianceMapper) -> None:
    m = mapper.map_cwe(99999)
    assert m.cwe_id == 99999
    assert m.owasp_asvs == []
    assert m.nist_800_53 == []
    assert m.asd_stig == []
    assert m.pci_dss == []
    assert m.cwe_name == ""


def test_map_cwe_asvs_rich_format(mapper: ComplianceMapper) -> None:
    """ASVS entries should be dicts with id, title, and level keys."""
    m = mapper.map_cwe(78)
    for entry in m.owasp_asvs:
        assert "id" in entry, f"ASVS entry missing 'id': {entry}"
        assert "level" in entry, f"ASVS entry missing 'level': {entry}"


def test_map_cwe_stig_rich_format(mapper: ComplianceMapper) -> None:
    """STIG entries should be dicts with id, cat, and title keys."""
    m = mapper.map_cwe(78)
    for entry in m.asd_stig:
        assert "id" in entry, f"STIG entry missing 'id': {entry}"
        assert "cat" in entry, f"STIG entry missing 'cat': {entry}"


# ---------------------------------------------------------------------------
# derive_severity
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "stig_cat, expected_severity",
    [
        ("CAT I", "critical"),
        ("CAT II", "high"),
        ("CAT III", "medium"),
        ("", "medium"),
    ],
)
def test_derive_severity_from_stig_category(
    stig_cat: str, expected_severity: str
) -> None:
    mapping = ComplianceMapping(cwe_id=0, stig_category=stig_cat)
    assert derive_severity(mapping) == expected_severity


def test_derive_severity_no_stig_data() -> None:
    mapping = ComplianceMapping(cwe_id=1333)  # no STIG entries
    assert derive_severity(mapping) == "medium"


def test_derive_severity_reads_stig_entries_directly() -> None:
    """derive_severity falls through to entry-level cat when stig_category is empty."""
    mapping = ComplianceMapping(
        cwe_id=0,
        stig_category="",
        asd_stig=[{"id": "APSC-DV-002510", "cat": "I", "title": ""}],
    )
    assert derive_severity(mapping) == "critical"


# ---------------------------------------------------------------------------
# ComplianceMapper.map_control — reverse lookup
# ---------------------------------------------------------------------------


def test_map_control_nist_si10_returns_many(mapper: ComplianceMapper) -> None:
    """SI-10 is referenced by nearly every sanitization CWE."""
    results = mapper.map_control("nist_800_53", "SI-10")
    cwe_ids = {m.cwe_id for m in results}
    # At minimum the canonical set should be present
    assert {20, 78, 79, 89, 94}.issubset(cwe_ids), (
        f"Expected core CWEs in SI-10 reverse lookup, got {cwe_ids}"
    )


@pytest.mark.parametrize("expected_cwe", [77, 78, 94])
def test_map_control_stig_apsc_dv_002510(
    mapper: ComplianceMapper, expected_cwe: int
) -> None:
    """APSC-DV-002510 (CAT I injection) maps to the command/code injection family."""
    results = mapper.map_control("asd_stig", "APSC-DV-002510")
    cwe_ids = {m.cwe_id for m in results}
    assert expected_cwe in cwe_ids, (
        f"Expected CWE-{expected_cwe} in APSC-DV-002510 reverse lookup, got {cwe_ids}"
    )


def test_map_control_nonexistent_returns_empty(mapper: ComplianceMapper) -> None:
    results = mapper.map_control("nist_800_53", "NONEXISTENT-CONTROL")
    assert results == []


def test_map_control_owasp_asvs_lookup(mapper: ComplianceMapper) -> None:
    """Reverse lookup by ASVS requirement ID should work for rich-format entries."""
    results = mapper.map_control("owasp_asvs", "v5.0.0-V1-5.3.4")
    cwe_ids = {m.cwe_id for m in results}
    assert 89 in cwe_ids, f"Expected CWE-89 for ASVS v5.0.0-V1-5.3.4, got {cwe_ids}"


def test_map_control_pci_dss_lookup(mapper: ComplianceMapper) -> None:
    results = mapper.map_control("pci_dss", "6.2.4")
    cwe_ids = {m.cwe_id for m in results}
    assert {20, 78, 79, 89}.issubset(cwe_ids), (
        f"Expected injection CWEs in PCI 6.2.4 reverse lookup, got {cwe_ids}"
    )


# ---------------------------------------------------------------------------
# enrich_finding
# ---------------------------------------------------------------------------


def test_enrich_finding_known_cwe(mapper: ComplianceMapper) -> None:
    f = _finding(cwe_id=78)
    ef = enrich_finding(f, mapper)

    assert isinstance(ef, EnrichedFinding)
    assert ef.cwe_id == 78
    assert ef.cwe_name  # non-empty
    assert ef.compliance is not None
    assert ef.compliance.owasp_asvs  # has at least one ASVS entry
    assert ef.derived_severity == "critical"  # CWE-78 maps to CAT I
    assert ef.remediation  # non-empty


def test_enrich_finding_preserves_original_fields(mapper: ComplianceMapper) -> None:
    f = _finding(cwe_id=89, rule_id="SC006")
    ef = enrich_finding(f, mapper)

    assert ef.file == f.file
    assert ef.line == f.line
    assert ef.column == f.column
    assert ef.rule_id == f.rule_id
    assert ef.message == f.message
    assert ef.severity == f.severity


def test_enrich_finding_unknown_cwe(mapper: ComplianceMapper) -> None:
    f = _finding(cwe_id=99999)
    ef = enrich_finding(f, mapper)

    assert ef.cwe_id == 99999
    assert ef.cwe_name == ""
    assert ef.compliance is not None
    assert ef.compliance.owasp_asvs == []
    assert ef.derived_severity == "medium"  # fallback
    assert ef.remediation == ""


def test_enrich_finding_cwe798_critical(mapper: ComplianceMapper) -> None:
    """CWE-798 maps to STIG CAT I — derived severity should be critical."""
    f = _finding(cwe_id=798)
    ef = enrich_finding(f, mapper)
    assert ef.derived_severity == "critical", (
        f"CWE-798 (hardcoded credentials) should derive critical severity "
        f"from STIG CAT I, got '{ef.derived_severity}'"
    )


def test_enrich_finding_cwe22_high(mapper: ComplianceMapper) -> None:
    """CWE-22 maps to STIG CAT II — derived severity should be high."""
    f = _finding(cwe_id=22)
    ef = enrich_finding(f, mapper)
    assert ef.derived_severity == "high", (
        f"CWE-22 (path traversal) should derive high severity "
        f"from STIG CAT II, got '{ef.derived_severity}'"
    )


# ---------------------------------------------------------------------------
# enrich_findings
# ---------------------------------------------------------------------------


def test_enrich_findings_returns_correct_count(mapper: ComplianceMapper) -> None:
    findings = [_finding(cwe_id=cid) for cid in [78, 89, 502]]
    enriched = enrich_findings(findings, mapper)
    assert len(enriched) == 3


def test_enrich_findings_preserves_order(mapper: ComplianceMapper) -> None:
    cwe_ids = [79, 89, 1333, 20]
    findings = [_finding(cwe_id=cid) for cid in cwe_ids]
    enriched = enrich_findings(findings, mapper)
    assert [ef.cwe_id for ef in enriched] == cwe_ids


def test_enrich_findings_default_mapper() -> None:
    """enrich_findings creates its own mapper when none is provided."""
    findings = [_finding(cwe_id=78)]
    enriched = enrich_findings(findings)
    assert len(enriched) == 1
    assert enriched[0].cwe_name  # populated from the bundled DB


def test_enrich_findings_empty_list(mapper: ComplianceMapper) -> None:
    assert enrich_findings([], mapper) == []


# ---------------------------------------------------------------------------
# compute_compliance_score
# ---------------------------------------------------------------------------


class TestComputeComplianceScore:
    """Tests for compute_compliance_score."""

    def test_no_findings_returns_100(self):
        assert compute_compliance_score([]) == 100.0

    def test_one_critical_finding(self):
        finding = EnrichedFinding(
            file=Path("test.py"), line=1, column=0,
            rule_id="SC001", message="test", severity="high",
            cwe_id=94, derived_severity="critical",
        )
        assert compute_compliance_score([finding]) == 75.0

    def test_score_floors_at_zero(self):
        findings = [
            EnrichedFinding(
                file=Path("test.py"), line=i, column=0,
                rule_id="SC001", message="test", severity="high",
                cwe_id=94, derived_severity="critical",
            )
            for i in range(10)
        ]
        # 10 * 25 = 250 penalty, capped at 0
        assert compute_compliance_score(findings) == 0.0

    def test_info_severity_no_penalty(self):
        finding = EnrichedFinding(
            file=Path("test.py"), line=1, column=0,
            rule_id="SC001", message="test", severity="info",
            cwe_id=94, derived_severity="",
        )
        # derived_severity is empty, falls through to severity="info", weight=0
        assert compute_compliance_score([finding]) == 100.0

    def test_mixed_severities(self):
        findings = [
            EnrichedFinding(
                file=Path("test.py"), line=1, column=0,
                rule_id="SC001", message="test", severity="high",
                cwe_id=94, derived_severity="critical",
            ),
            EnrichedFinding(
                file=Path("test.py"), line=2, column=0,
                rule_id="SC003", message="test", severity="high",
                cwe_id=78, derived_severity="high",
            ),
            EnrichedFinding(
                file=Path("test.py"), line=3, column=0,
                rule_id="SC006", message="test", severity="medium",
                cwe_id=89, derived_severity="",
            ),
        ]
        # 25 + 10 + 3 = 38 penalty
        assert compute_compliance_score(findings) == 62.0


# ---------------------------------------------------------------------------
# compute_control_status
# ---------------------------------------------------------------------------


class TestComputeControlStatus:
    """Tests for compute_control_status."""

    def test_no_findings_all_passing(self, mapper: ComplianceMapper):
        result = compute_control_status([], mapper)
        for fw in ("owasp_asvs", "nist_800_53", "asd_stig", "pci_dss"):
            assert fw in result
            assert result[fw]["failing"] == 0
            assert result[fw]["passing"] >= 0

    def test_finding_increases_failing_count(self, mapper: ComplianceMapper):
        raw = Finding(
            file=Path("test.py"), line=1, column=0,
            rule_id="SC003", message="test", severity="high", cwe_id=78,
        )
        enriched = enrich_finding(raw, mapper)

        result_with = compute_control_status([enriched], mapper)
        result_without = compute_control_status([], mapper)

        # CWE-78 maps to NIST SI-10 and SI-15 — should increase failing count
        assert result_with["nist_800_53"]["failing"] > result_without["nist_800_53"]["failing"]

    def test_finding_with_no_compliance(self, mapper: ComplianceMapper):
        # Finding with no compliance mapping (unknown CWE)
        finding = EnrichedFinding(
            file=Path("test.py"), line=1, column=0,
            rule_id="SC999", message="test", severity="low",
            cwe_id=99999, derived_severity="",
        )
        result = compute_control_status([finding], mapper)
        # Should not crash; no controls should be failing
        for fw in ("owasp_asvs", "nist_800_53", "asd_stig", "pci_dss"):
            assert result[fw]["failing"] == 0
