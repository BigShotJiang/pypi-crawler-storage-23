"""Tests for the benchmark suite."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from sanicode.benchmarks.runner import (
    BenchmarkFinding,
    BenchmarkResult,
    _compute_metrics,
    _score_findings,
    aggregate_results,
    bundled_corpus_dir,
    bundled_ground_truth_path,
    compare_results,
    load_ground_truth,
    run_sanicode_benchmark,
)

# ---------------------------------------------------------------------------
# Unit tests for internal helpers
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "tp, fp, fn, exp_precision, exp_recall, exp_f1",
    [
        (2, 0, 0, 1.0, 1.0, 1.0),
        (1, 1, 1, 0.5, 0.5, 0.5),
        (0, 0, 2, None, 0.0, None),
        (0, 3, 0, 0.0, None, None),
        (0, 0, 0, None, None, None),
    ],
)
def test_compute_metrics(tp, fp, fn, exp_precision, exp_recall, exp_f1) -> None:
    precision, recall, f1 = _compute_metrics(tp, fp, fn)
    assert precision == exp_precision
    assert recall == exp_recall
    assert f1 == exp_f1


class TestScoreFindings:
    """Tests for the TP/FP/FN scoring logic."""

    def _finding(self, cwe_id: int, line: int) -> BenchmarkFinding:
        return BenchmarkFinding(cwe_id=cwe_id, line=line, severity="high", file="f.py")

    def test_exact_match(self) -> None:
        findings = [self._finding(89, 10)]
        expected = [{"cwe_id": 89, "line": 10, "severity": "critical"}]
        tp, fp, fn = _score_findings(findings, expected, "f.py")
        assert (tp, fp, fn) == (1, 0, 0)

    def test_within_window(self) -> None:
        findings = [self._finding(89, 12)]  # 2 lines off from expected 10
        expected = [{"cwe_id": 89, "line": 10, "severity": "critical"}]
        tp, fp, fn = _score_findings(findings, expected, "f.py")
        assert (tp, fp, fn) == (1, 0, 0)

    def test_outside_window(self) -> None:
        findings = [self._finding(89, 20)]  # 10 lines off — exceeds LINE_WINDOW
        expected = [{"cwe_id": 89, "line": 10, "severity": "critical"}]
        tp, fp, fn = _score_findings(findings, expected, "f.py")
        assert (tp, fp, fn) == (0, 1, 1)

    def test_wrong_cwe(self) -> None:
        findings = [self._finding(79, 10)]
        expected = [{"cwe_id": 89, "line": 10, "severity": "critical"}]
        tp, fp, fn = _score_findings(findings, expected, "f.py")
        assert (tp, fp, fn) == (0, 1, 1)

    def test_no_expected_is_all_fp(self) -> None:
        findings = [self._finding(89, 10), self._finding(78, 5)]
        expected: list = []
        tp, fp, fn = _score_findings(findings, expected, "f.py")
        assert (tp, fp, fn) == (0, 2, 0)

    def test_no_findings_all_fn(self) -> None:
        expected = [{"cwe_id": 89, "line": 10, "severity": "critical"}]
        tp, fp, fn = _score_findings([], expected, "f.py")
        assert (tp, fp, fn) == (0, 0, 1)

    def test_expected_without_line_matches_any_line(self) -> None:
        """When expected has no 'line', any finding with matching CWE is a TP."""
        findings = [self._finding(798, 99)]
        expected = [{"cwe_id": 798, "severity": "critical"}]
        tp, fp, fn = _score_findings(findings, expected, "f.py")
        assert (tp, fp, fn) == (1, 0, 0)

    def test_each_expected_matched_once(self) -> None:
        """Two findings matching the same expected item: one TP, one FP."""
        findings = [self._finding(89, 10), self._finding(89, 11)]
        expected = [{"cwe_id": 89, "line": 10, "severity": "critical"}]
        tp, fp, fn = _score_findings(findings, expected, "f.py")
        assert (tp, fp, fn) == (1, 1, 0)


# ---------------------------------------------------------------------------
# Ground truth loading
# ---------------------------------------------------------------------------


def test_ground_truth_valid() -> None:
    """Ground truth JSON is valid and references existing corpus files."""
    gt_path = bundled_ground_truth_path()
    assert gt_path.exists(), f"Ground truth not found: {gt_path}"

    corpus = bundled_corpus_dir()
    assert corpus.exists(), f"Corpus directory not found: {corpus}"

    ground_truth = load_ground_truth(gt_path)
    assert len(ground_truth) > 0, "Ground truth must not be empty"

    for rel_path, expected in ground_truth.items():
        corpus_file = corpus / rel_path
        assert corpus_file.exists(), (
            f"Ground truth references missing corpus file: {rel_path}"
        )
        for entry in expected:
            assert "cwe_id" in entry, f"Missing cwe_id in {rel_path}: {entry}"
            assert isinstance(entry["cwe_id"], int), (
                f"cwe_id must be int in {rel_path}: {entry}"
            )


def test_load_ground_truth_from_file(tmp_path: Path) -> None:
    """load_ground_truth correctly parses the JSON format."""
    gt = {
        "python/some_file.py": {
            "expected_findings": [
                {"cwe_id": 89, "line": 10, "severity": "critical"},
            ]
        },
        "python/safe_file.py": {
            "expected_findings": []
        },
    }
    gt_file = tmp_path / "ground_truth.json"
    gt_file.write_text(json.dumps(gt), encoding="utf-8")

    result = load_ground_truth(gt_file)
    assert "python/some_file.py" in result
    assert len(result["python/some_file.py"]) == 1
    assert result["python/some_file.py"][0]["cwe_id"] == 89
    assert result["python/safe_file.py"] == []


# ---------------------------------------------------------------------------
# Sanicode benchmark — integration
# ---------------------------------------------------------------------------


def test_sanicode_benchmark_runs() -> None:
    """Run sanicode benchmark against the bundled corpus without errors."""
    corpus = bundled_corpus_dir()
    ground_truth = load_ground_truth(bundled_ground_truth_path())

    results = run_sanicode_benchmark(corpus, ground_truth)

    assert len(results) == len(ground_truth), (
        f"Expected {len(ground_truth)} results, got {len(results)}"
    )
    for r in results:
        assert r.tool == "sanicode"
        assert r.true_positives >= 0
        assert r.false_positives >= 0
        assert r.false_negatives >= 0
        assert r.duration_ms >= 0


def test_benchmark_precision_recall() -> None:
    """Sanicode should achieve non-zero recall on the bundled corpus."""
    corpus = bundled_corpus_dir()
    ground_truth = load_ground_truth(bundled_ground_truth_path())

    results = run_sanicode_benchmark(corpus, ground_truth)
    agg = aggregate_results(results)

    assert agg["tp"] > 0, (
        f"Expected at least one true positive; got TP={agg['tp']} "
        f"FP={agg['fp']} FN={agg['fn']}"
    )
    assert agg["recall"] is not None and agg["recall"] > 0, (
        f"Expected non-zero recall; got {agg['recall']}"
    )


def test_safe_files_produce_no_false_positives() -> None:
    """Files marked as having no expected findings should produce zero FP findings."""
    corpus = bundled_corpus_dir()
    ground_truth = load_ground_truth(bundled_ground_truth_path())

    # Only benchmark the "safe" files.
    safe_ground_truth = {
        k: v for k, v in ground_truth.items() if not v
    }
    results = run_sanicode_benchmark(corpus, safe_ground_truth)

    for r in results:
        assert r.false_positives == 0, (
            f"Expected zero FP for safe file {r.corpus_file!r}, "
            f"got {r.false_positives}"
        )


# ---------------------------------------------------------------------------
# Aggregate and compare helpers
# ---------------------------------------------------------------------------


def test_aggregate_results() -> None:
    results = [
        BenchmarkResult(
            tool="sanicode", corpus_file="a.py",
            true_positives=2, false_positives=1, false_negatives=0,
            precision=2/3, recall=1.0, f1=0.8, duration_ms=50.0,
        ),
        BenchmarkResult(
            tool="sanicode", corpus_file="b.py",
            true_positives=1, false_positives=0, false_negatives=1,
            precision=1.0, recall=0.5, f1=0.667, duration_ms=30.0,
        ),
    ]
    agg = aggregate_results(results)
    assert agg["tp"] == 3
    assert agg["fp"] == 1
    assert agg["fn"] == 1
    assert agg["total_duration_ms"] == pytest.approx(80.0)
    assert agg["precision"] == pytest.approx(3 / 4)
    assert agg["recall"] == pytest.approx(3 / 4)


def test_compare_results_format() -> None:
    results = [
        BenchmarkResult(
            tool="sanicode", corpus_file="a.py",
            true_positives=1, false_positives=0, false_negatives=0,
            precision=1.0, recall=1.0, f1=1.0, duration_ms=10.0,
        ),
    ]
    report = compare_results({"sanicode": results})
    assert "sanicode" in report
    assert "TP=1" in report
    assert "Precision=1.000" in report


def test_compare_results_empty_tool() -> None:
    report = compare_results({"bandit": []})
    assert "bandit" in report
    assert "not installed" in report


# ---------------------------------------------------------------------------
# CLI integration
# ---------------------------------------------------------------------------


def test_benchmark_cli_sanicode(tmp_path: Path) -> None:
    """CLI benchmark command runs sanicode and produces output."""
    from typer.testing import CliRunner

    from sanicode.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["benchmark", "--tool", "sanicode"])

    assert result.exit_code == 0, (
        f"CLI exited with {result.exit_code}:\n{result.output}"
    )
    assert "sanicode" in result.output


def test_benchmark_cli_invalid_tool() -> None:
    """CLI benchmark rejects unknown tool names."""
    from typer.testing import CliRunner

    from sanicode.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["benchmark", "--tool", "nonexistent-tool"])

    assert result.exit_code != 0
    assert "Unknown tool" in result.output


def test_benchmark_cli_output_json(tmp_path: Path) -> None:
    """CLI benchmark saves JSON output when --output is given."""
    from typer.testing import CliRunner

    from sanicode.cli import app

    out_file = tmp_path / "results.json"
    runner = CliRunner()
    result = runner.invoke(app, [
        "benchmark", "--tool", "sanicode", "--output", str(out_file),
    ])

    assert result.exit_code == 0, (
        f"CLI exited with {result.exit_code}:\n{result.output}"
    )
    assert out_file.exists()
    data = json.loads(out_file.read_text(encoding="utf-8"))
    assert "sanicode" in data
    assert isinstance(data["sanicode"], list)
