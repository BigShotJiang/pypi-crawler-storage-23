"""Tests for the TreeSitterPlugin base class."""

from __future__ import annotations

from pathlib import Path

from sanicode.scanner.languages.base import TreeSitterPlugin


class PythonTestPlugin(TreeSitterPlugin):
    _language_name = "python"

    @property
    def name(self) -> str:
        return "python-test"

    @property
    def extensions(self) -> frozenset[str]:
        return frozenset({".py"})


class JavaScriptTestPlugin(TreeSitterPlugin):
    _language_name = "javascript"

    @property
    def name(self) -> str:
        return "javascript-test"

    @property
    def extensions(self) -> frozenset[str]:
        return frozenset({".js"})


class TestParseSource:
    def test_python_root_type(self):
        plugin = PythonTestPlugin()
        tree = plugin.parse_source(b"x = 1")
        assert tree.root_node.type == "module"

    def test_javascript_root_type(self):
        plugin = JavaScriptTestPlugin()
        tree = plugin.parse_source(b"const x = 1;")
        assert tree.root_node.type == "program"

    def test_malformed_source_has_error(self):
        plugin = PythonTestPlugin()
        tree = plugin.parse_source(b"def foo(:\n    pass")
        assert tree.root_node.has_error

    def test_valid_source_no_error(self):
        plugin = PythonTestPlugin()
        tree = plugin.parse_source(b"def foo():\n    pass\n")
        assert not tree.root_node.has_error


class TestParseFile:
    def test_parse_file_from_disk(self, tmp_path: Path):
        source = tmp_path / "example.py"
        source.write_text("x = 1\n", encoding="utf-8")
        plugin = PythonTestPlugin()
        tree = plugin.parse_file(source)
        assert tree.root_node.type == "module"
        assert not tree.root_node.has_error


class TestQueryHelpers:
    def test_captures(self):
        plugin = PythonTestPlugin()
        tree = plugin.parse_source(b"eval(x)")
        result = plugin.captures(
            "(call function: (identifier) @fn)", tree.root_node
        )
        # captures returns {capture_name: [nodes]}
        assert "fn" in result
        names = [plugin.node_text(n) for n in result["fn"]]
        assert "eval" in names

    def test_matches(self):
        plugin = PythonTestPlugin()
        tree = plugin.parse_source(b"eval(x)\nexec(y)")
        results = plugin.matches(
            "(call function: (identifier) @fn)", tree.root_node
        )
        # matches returns [(pattern_index, {capture_name: [nodes]})]
        assert len(results) >= 2


class TestNodeHelpers:
    def test_node_text(self):
        plugin = PythonTestPlugin()
        tree = plugin.parse_source(b"hello = 42")
        first_child = tree.root_node.children[0]
        text = plugin.node_text(first_child)
        assert "hello" in text
        assert "42" in text

    def test_start_position_one_based(self):
        plugin = PythonTestPlugin()
        tree = plugin.parse_source(b"# comment\nx = 1\n")
        # x = 1 is on line 2 (0-based row 1)
        assignment = tree.root_node.children[1]
        line, col = plugin.start_position(assignment)
        assert line == 2, f"Expected line 2, got {line}"
        assert col == 0

    def test_start_position_first_line(self):
        plugin = PythonTestPlugin()
        tree = plugin.parse_source(b"x = 1\n")
        assignment = tree.root_node.children[0]
        line, col = plugin.start_position(assignment)
        assert line == 1
