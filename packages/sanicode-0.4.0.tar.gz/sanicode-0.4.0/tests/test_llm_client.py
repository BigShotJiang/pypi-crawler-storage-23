"""Tests for LLM client, prompt loading, and pipeline integration."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from sanicode.config import LLMTierConfig, SanicodeConfig
from sanicode.llm.client import LLMClient, LLMNotConfiguredError, LLMResponse
from sanicode.llm.prompts import load_prompt, render_prompt


class TestLLMClientHasTier:
    """Test has_tier() convenience method."""

    def test_has_configured_tier(self):
        client = LLMClient(fast=LLMTierConfig(endpoint="http://localhost:8080/v1", model="test"))
        assert client.has_tier("fast") is True

    def test_missing_tier(self):
        client = LLMClient()
        assert client.has_tier("fast") is False

    def test_unknown_tier(self):
        client = LLMClient()
        assert client.has_tier("nonexistent") is False


class TestLLMClientFromConfig:
    """Test from_config class method."""

    def test_all_tiers_configured(self):
        cfg = SanicodeConfig()
        cfg.llm.fast = LLMTierConfig(endpoint="http://fast/v1", model="fast-model")
        cfg.llm.analysis = LLMTierConfig(endpoint="http://analysis/v1", model="analysis-model")
        cfg.llm.reasoning = LLMTierConfig(endpoint="http://reason/v1", model="reason-model")
        client = LLMClient.from_config(cfg)
        assert client.has_tier("fast")
        assert client.has_tier("analysis")
        assert client.has_tier("reasoning")

    def test_no_tiers_configured(self):
        cfg = SanicodeConfig()
        client = LLMClient.from_config(cfg)
        assert not client.has_tier("fast")
        assert not client.has_tier("analysis")
        assert not client.has_tier("reasoning")

    def test_partial_tiers(self):
        cfg = SanicodeConfig()
        cfg.llm.fast = LLMTierConfig(endpoint="http://fast/v1", model="fast-model")
        client = LLMClient.from_config(cfg)
        assert client.has_tier("fast")
        assert not client.has_tier("analysis")
        assert not client.has_tier("reasoning")

    def test_cloud_provider_tiers(self):
        cfg = SanicodeConfig()
        cfg.llm.fast = LLMTierConfig(provider="anthropic", model="claude-haiku-4-5-20251001")
        client = LLMClient.from_config(cfg)
        assert client.has_tier("fast")


class TestLLMClientCalls:
    """Test that LLM client methods call LiteLLM correctly."""

    def _make_client(self):
        return LLMClient(
            fast=LLMTierConfig(endpoint="http://localhost:8080/v1", model="test-model"),
            analysis=LLMTierConfig(endpoint="http://localhost:8080/v1", model="test-model"),
            reasoning=LLMTierConfig(endpoint="http://localhost:8080/v1", model="test-model"),
        )

    def _mock_response(self, content: str = "test response"):
        mock_resp = MagicMock()
        mock_resp.choices = [MagicMock()]
        mock_resp.choices[0].message.content = content
        mock_resp.model = "test-model"
        mock_resp.usage = MagicMock()
        mock_resp.usage.prompt_tokens = 10
        mock_resp.usage.completion_tokens = 20
        mock_resp.usage.total_tokens = 30
        return mock_resp

    @patch("sanicode.llm.client.litellm.completion")
    def test_classify_calls_litellm(self, mock_completion):
        mock_completion.return_value = self._mock_response()
        client = self._make_client()
        result = client.classify("test prompt")
        assert isinstance(result, LLMResponse)
        assert result.content == "test response"
        assert result.tier == "fast"
        mock_completion.assert_called_once()
        call_kwargs = mock_completion.call_args
        assert call_kwargs.kwargs["model"] == "openai/test-model"

    @patch("sanicode.llm.client.litellm.completion")
    def test_analyze_calls_litellm(self, mock_completion):
        mock_completion.return_value = self._mock_response()
        client = self._make_client()
        result = client.analyze("test prompt")
        assert result.tier == "analysis"

    @patch("sanicode.llm.client.litellm.completion")
    def test_reason_calls_litellm(self, mock_completion):
        mock_completion.return_value = self._mock_response()
        client = self._make_client()
        result = client.reason("test prompt")
        assert result.tier == "reasoning"

    def test_classify_raises_without_tier(self):
        client = LLMClient()
        with pytest.raises(LLMNotConfiguredError):
            client.classify("test")

    def test_analyze_raises_without_tier(self):
        client = LLMClient()
        with pytest.raises(LLMNotConfiguredError):
            client.analyze("test")

    def test_reason_raises_without_tier(self):
        client = LLMClient()
        with pytest.raises(LLMNotConfiguredError):
            client.reason("test")

    @patch("sanicode.llm.client.litellm.completion")
    def test_cloud_provider_omits_api_base(self, mock_completion):
        """Cloud provider (no endpoint) should not pass api_base or api_key."""
        mock_completion.return_value = self._mock_response()
        client = LLMClient(
            fast=LLMTierConfig(provider="anthropic", model="claude-haiku-4-5-20251001"),
        )
        client.classify("test prompt")
        call_kwargs = mock_completion.call_args.kwargs
        assert call_kwargs["model"] == "anthropic/claude-haiku-4-5-20251001"
        assert "api_base" not in call_kwargs
        assert "api_key" not in call_kwargs

    @patch("sanicode.llm.client.litellm.completion")
    def test_explicit_api_key_always_passed(self, mock_completion):
        """An explicit api_key in config is passed regardless of provider."""
        mock_completion.return_value = self._mock_response()
        client = LLMClient(
            fast=LLMTierConfig(
                provider="anthropic",
                model="claude-haiku-4-5-20251001",
                api_key="sk-my-key",
            ),
        )
        client.classify("test prompt")
        call_kwargs = mock_completion.call_args.kwargs
        assert call_kwargs["api_key"] == "sk-my-key"
        assert "api_base" not in call_kwargs

    @patch("sanicode.llm.client.litellm.completion")
    def test_self_hosted_passes_api_base(self, mock_completion):
        """Self-hosted endpoint passes api_base and api_key="unused"."""
        mock_completion.return_value = self._mock_response()
        client = LLMClient(
            fast=LLMTierConfig(
                provider="vllm",
                endpoint="http://localhost:8080/v1",
                model="test-model",
            ),
        )
        client.classify("test prompt")
        call_kwargs = mock_completion.call_args.kwargs
        assert call_kwargs["model"] == "openai/test-model"
        assert call_kwargs["api_base"] == "http://localhost:8080/v1"
        assert call_kwargs["api_key"] == "unused"

    @patch("sanicode.llm.client.litellm.completion")
    def test_usage_tracking(self, mock_completion):
        mock_completion.return_value = self._mock_response()
        client = self._make_client()
        result = client.classify("test")
        assert result.usage["prompt_tokens"] == 10
        assert result.usage["completion_tokens"] == 20
        assert result.usage["total_tokens"] == 30

    @patch("sanicode.llm.client.litellm.completion")
    def test_vllm_provider_with_endpoint(self, mock_completion):
        """vLLM is in registry with needs_api_key=False and litellm_prefix="openai"."""
        mock_completion.return_value = self._mock_response()
        client = LLMClient(
            fast=LLMTierConfig(
                provider="vllm",
                endpoint="http://localhost:8000/v1",
                model="granite-8b",
            ),
        )
        client.classify("test prompt")
        call_kwargs = mock_completion.call_args.kwargs
        assert call_kwargs["model"] == "openai/granite-8b"
        assert call_kwargs["api_base"] == "http://localhost:8000/v1"
        assert call_kwargs["api_key"] == "unused"

    @patch("sanicode.llm.client.litellm.completion")
    def test_azure_provider_with_endpoint_no_explicit_key(self, mock_completion):
        """Azure has needs_api_key=True, so no placeholder key is injected."""
        mock_completion.return_value = self._mock_response()
        client = LLMClient(
            fast=LLMTierConfig(
                provider="azure",
                endpoint="https://my-azure.openai.azure.com",
                model="gpt-4o",
            ),
        )
        client.classify("test prompt")
        call_kwargs = mock_completion.call_args.kwargs
        assert call_kwargs["model"] == "azure/gpt-4o"
        assert call_kwargs["api_base"] == "https://my-azure.openai.azure.com"
        assert "api_key" not in call_kwargs

    @patch("sanicode.llm.client.litellm.completion")
    def test_unknown_provider_with_endpoint(self, mock_completion):
        """Unknown provider (not in registry) falls back to api_key="unused"."""
        mock_completion.return_value = self._mock_response()
        client = LLMClient(
            fast=LLMTierConfig(
                provider="custom_provider",
                endpoint="http://custom:8080/v1",
                model="my-model",
            ),
        )
        client.classify("test prompt")
        call_kwargs = mock_completion.call_args.kwargs
        assert call_kwargs["model"] == "custom_provider/my-model"
        assert call_kwargs["api_base"] == "http://custom:8080/v1"
        assert call_kwargs["api_key"] == "unused"

    @patch("sanicode.llm.client.litellm.completion")
    def test_ollama_provider_resolves_prefix(self, mock_completion):
        """Ollama is in registry with litellm_prefix="ollama"."""
        mock_completion.return_value = self._mock_response()
        client = LLMClient(
            fast=LLMTierConfig(
                provider="ollama",
                endpoint="http://localhost:11434/v1",
                model="llama3.1:8b",
            ),
        )
        client.classify("test prompt")
        call_kwargs = mock_completion.call_args.kwargs
        assert call_kwargs["model"] == "ollama/llama3.1:8b"

    @patch("sanicode.llm.client.litellm.completion")
    def test_test_connection(self, mock_completion):
        """test_connection() sends a minimal prompt with timeout=5."""
        mock_completion.return_value = self._mock_response("ok")
        client = LLMClient(
            fast=LLMTierConfig(
                provider="vllm",
                endpoint="http://localhost:8000/v1",
                model="granite-8b",
            ),
        )
        result = client.test_connection("fast")
        assert isinstance(result, LLMResponse)
        call_kwargs = mock_completion.call_args.kwargs
        assert call_kwargs["timeout"] == 5
        messages = call_kwargs["messages"]
        assert any(m["content"] == "Say 'ok'." for m in messages)


class TestLLMMetrics:
    """Test that LLM calls update Prometheus metrics."""

    def _make_client(self):
        return LLMClient(
            fast=LLMTierConfig(endpoint="http://localhost:8080/v1", model="test-model"),
        )

    def _mock_response(self, content: str = "test response"):
        mock_resp = MagicMock()
        mock_resp.choices = [MagicMock()]
        mock_resp.choices[0].message.content = content
        mock_resp.model = "test-model"
        mock_resp.usage = MagicMock()
        mock_resp.usage.prompt_tokens = 10
        mock_resp.usage.completion_tokens = 20
        mock_resp.usage.total_tokens = 30
        return mock_resp

    @patch("sanicode.llm.client.litellm.completion")
    def test_successful_call_increments_request_counter(self, mock_completion):
        from sanicode.metrics import LLM_REQUESTS_TOTAL
        mock_completion.return_value = self._mock_response()
        client = self._make_client()
        before = LLM_REQUESTS_TOTAL.labels(model="test-model", tier="fast")._value.get()
        client.classify("test")
        after = LLM_REQUESTS_TOTAL.labels(model="test-model", tier="fast")._value.get()
        assert after == before + 1

    @patch("sanicode.llm.client.litellm.completion")
    def test_successful_call_records_tokens(self, mock_completion):
        from sanicode.metrics import LLM_TOKENS_CONSUMED
        mock_completion.return_value = self._mock_response()
        client = self._make_client()
        prompt_metric = LLM_TOKENS_CONSUMED.labels(tier="fast", direction="prompt")
        completion_metric = LLM_TOKENS_CONSUMED.labels(tier="fast", direction="completion")
        before_prompt = prompt_metric._value.get()
        before_completion = completion_metric._value.get()
        client.classify("test")
        after_prompt = prompt_metric._value.get()
        after_completion = completion_metric._value.get()
        assert after_prompt == before_prompt + 10
        assert after_completion == before_completion + 20

    @patch("sanicode.llm.client.litellm.completion")
    def test_failed_call_increments_error_counter(self, mock_completion):
        from sanicode.metrics import LLM_ERRORS_TOTAL
        mock_completion.side_effect = TimeoutError("connection timeout")
        client = self._make_client()
        before = LLM_ERRORS_TOTAL.labels(model="test-model", error_type="TimeoutError")._value.get()
        with pytest.raises(TimeoutError):
            client.classify("test")
        after = LLM_ERRORS_TOTAL.labels(model="test-model", error_type="TimeoutError")._value.get()
        assert after == before + 1


class TestPromptLoading:
    """Test prompt template loading and rendering."""

    def test_load_classify_prompt(self):
        data = load_prompt("classify")
        assert data["name"] == "Finding Classification"
        assert "{rule_id}" in data["template"]

    def test_load_analyze_prompt(self):
        data = load_prompt("analyze")
        assert data["name"] == "Data Flow Analysis"

    def test_load_reason_prompt(self):
        data = load_prompt("reason")
        assert data["name"] == "Compliance Reasoning"

    def test_load_nonexistent_raises(self):
        with pytest.raises(FileNotFoundError):
            load_prompt("nonexistent_prompt_xyz")

    def test_render_classify(self):
        rendered = render_prompt(
            "classify",
            rule_id="SC001",
            message="eval() call detected",
            file="app.py",
            line=10,
            severity="critical",
            cwe_id=94,
            code_snippet="eval(user_input)",
        )
        assert "SC001" in rendered
        assert "eval() call detected" in rendered

    def test_render_missing_required_variable(self):
        with pytest.raises(KeyError):
            render_prompt("classify", rule_id="SC001")


class TestDegradedMode:
    """Test that pipeline works without LLM configured."""

    def test_scan_without_llm(self, tmp_path):
        """Scan should complete normally without any LLM tiers configured."""
        test_file = tmp_path / "test.py"
        test_file.write_text("eval(input())\n")

        from sanicode.config import SanicodeConfig
        from sanicode.scanner.executor import run_scan

        cfg = SanicodeConfig()
        output = run_scan(test_file, cfg)
        # Should still find the eval() pattern
        assert len(output.enriched_findings) > 0
        assert any(f.rule_id == "SC001" for f in output.enriched_findings)
