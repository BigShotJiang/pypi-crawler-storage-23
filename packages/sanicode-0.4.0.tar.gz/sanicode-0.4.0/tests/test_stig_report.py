"""Tests for STIG checklist (.ckl) and summary report generation."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from pathlib import Path

import pytest

from sanicode.config import StigConfig
from sanicode.report.persist import ScanResult
from sanicode.report.stig import (
    _find_meta_path,
    _group_findings_by_stig,
    generate_stig_checklist,
    generate_stig_summary,
)

# ---------------------------------------------------------------------------
# Test-data helpers
# ---------------------------------------------------------------------------

_STIG_INJECTION = {"id": "APSC-DV-002510", "cat": "CAT I", "title": "Injection attacks"}
_STIG_XSS = {"id": "APSC-DV-002520", "cat": "CAT II", "title": "XSS"}
_STIG_INPUT = {"id": "APSC-DV-002530", "cat": "CAT II", "title": "Input validation"}


def _make_finding(
    file: str = "app.py",
    line: int = 10,
    cwe_id: int = 78,
    message: str = "dangerous call",
    stig_entries: list[dict] | None = None,
    remediation: str = "Use safe API",
) -> dict:
    """Build a minimal serialized finding dict matching the ScanResult format."""
    if stig_entries is None:
        stig_entries = [_STIG_INJECTION]
    return {
        "file": file,
        "line": line,
        "column": 4,
        "rule_id": "SC001",
        "message": message,
        "severity": "high",
        "cwe_id": cwe_id,
        "cwe_name": "OS Command Injection",
        "compliance": {
            "cwe_id": cwe_id,
            "cwe_name": "OS Command Injection",
            "asd_stig": stig_entries,
            "owasp_asvs": [{"id": "v5.0.0-V1-5.3.8", "title": "", "level": "L1"}],
            "nist_800_53": ["SI-10"],
            "pci_dss": ["6.2.4"],
            "asvs_level": "L1",
            "stig_category": "CAT I",
            "remediation": remediation,
            "description": "",
        },
        "derived_severity": "critical",
        "remediation": remediation,
    }


def _make_result(findings: list[dict] | None = None) -> ScanResult:
    """Build a minimal ScanResult for testing."""
    return ScanResult(
        sanicode_version="0.3.3",
        scan_id="20260101T000000Z",
        scanned_path="/app",
        scan_timestamp="2026-01-01T00:00:00+00:00",
        summary={"total_findings": len(findings or [])},
        findings=findings or [],
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _find_vuln(root: ET.Element, rule_ver: str) -> ET.Element | None:
    """Return the <VULN> element whose Rule_Ver matches rule_ver, or None."""
    for vuln in root.findall(".//VULN"):
        for sd in vuln.findall("STIG_DATA"):
            if (
                sd.findtext("VULN_ATTRIBUTE") == "Rule_Ver"
                and sd.findtext("ATTRIBUTE_DATA") == rule_ver
            ):
                return vuln
    return None


def _stig_attr(vuln: ET.Element, name: str) -> str | None:
    """Return ATTRIBUTE_DATA for a named VULN_ATTRIBUTE within a <VULN>."""
    for sd in vuln.findall("STIG_DATA"):
        if sd.findtext("VULN_ATTRIBUTE") == name:
            return sd.findtext("ATTRIBUTE_DATA")
    return None


# ---------------------------------------------------------------------------
# Metadata loading
# ---------------------------------------------------------------------------


def test_meta_path_found() -> None:
    """The metadata file must be discoverable from the installed package."""
    path = _find_meta_path()
    assert path is not None, "stig_checklist_meta.json was not found in any search location"
    assert path.is_file(), f"Discovered path is not a file: {path}"


# ---------------------------------------------------------------------------
# 1. XML validity
# ---------------------------------------------------------------------------


def test_xml_validity_no_findings() -> None:
    result = _make_result([])
    ckl = generate_stig_checklist(result, {})
    # Must parse without raising
    root = ET.fromstring(ckl.split("\n", 2)[-1])  # strip XML declaration lines
    assert root.tag == "CHECKLIST", f"Root tag is {root.tag!r}, expected 'CHECKLIST'"


def test_xml_validity_with_findings() -> None:
    findings = [_make_finding()]
    result = _make_result(findings)
    ckl = generate_stig_checklist(result)
    root = ET.fromstring(ckl.split("\n", 2)[-1])
    assert root.tag == "CHECKLIST"


def test_xml_declaration_present() -> None:
    result = _make_result([])
    ckl = generate_stig_checklist(result)
    assert ckl.startswith("<?xml version='1.0' encoding='UTF-8'?>"), (
        "XML declaration is missing or malformed"
    )


def test_stig_viewer_comment_present() -> None:
    result = _make_result([])
    ckl = generate_stig_checklist(result)
    assert "DISA STIG Viewer" in ckl


# ---------------------------------------------------------------------------
# 2. Asset metadata
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("field,value,xml_tag", [
    ("hostname", "myhost.example.com", "HOST_NAME"),
    ("host_ip", "10.0.0.42", "HOST_IP"),
    ("host_fqdn", "myhost.example.com", "HOST_FQDN"),
    ("target_comment", "Custom ATO comment", "TARGET_COMMENT"),
])
def test_asset_metadata_fields(field: str, value: str, xml_tag: str) -> None:
    result = _make_result([])
    asset_cfg = {field: value}
    ckl = generate_stig_checklist(result, asset_cfg)
    root = ET.fromstring(ckl.split("\n", 2)[-1])
    asset_el = root.find("ASSET")
    assert asset_el is not None, "<ASSET> element missing"
    field_el = asset_el.find(xml_tag)
    assert field_el is not None, f"<{xml_tag}> missing from <ASSET>"
    assert field_el.text == value, (
        f"<{xml_tag}> expected {value!r}, got {field_el.text!r}"
    )


# ---------------------------------------------------------------------------
# 3. Open status for rules with matching findings
# ---------------------------------------------------------------------------


def test_open_status_when_findings_present() -> None:
    findings = [_make_finding(stig_entries=[_STIG_INJECTION])]
    result = _make_result(findings)
    ckl = generate_stig_checklist(result)
    root = ET.fromstring(ckl.split("\n", 2)[-1])

    assert root.findall(".//VULN"), "No <VULN> elements found"
    target_vuln = _find_vuln(root, "APSC-DV-002510")
    assert target_vuln is not None, "VULN for APSC-DV-002510 not found"
    status = target_vuln.findtext("STATUS")
    assert status == "Open", f"Expected STATUS=Open, got {status!r}"


# ---------------------------------------------------------------------------
# 4. Not_Reviewed status for rules without findings
# ---------------------------------------------------------------------------


def test_not_reviewed_status_for_uncovered_rules() -> None:
    # Only inject APSC-DV-002510 finding; other rules should be Not_Reviewed
    findings = [_make_finding(stig_entries=[_STIG_INJECTION])]
    result = _make_result(findings)
    ckl = generate_stig_checklist(result)
    root = ET.fromstring(ckl.split("\n", 2)[-1])

    # APSC-DV-002520 (XSS) is not covered by our test finding
    xss_vuln = _find_vuln(root, "APSC-DV-002520")
    assert xss_vuln is not None, "VULN for APSC-DV-002520 not found"
    assert xss_vuln.findtext("STATUS") == "Not_Reviewed", (
        "APSC-DV-002520 should be Not_Reviewed"
    )


# ---------------------------------------------------------------------------
# 5. Finding grouping — multiple findings for the same rule in one VULN
# ---------------------------------------------------------------------------


def test_multiple_findings_grouped_in_one_vuln() -> None:
    findings = [
        _make_finding(file="a.py", line=10, message="first injection"),
        _make_finding(file="b.py", line=20, message="second injection"),
    ]
    result = _make_result(findings)
    ckl = generate_stig_checklist(result)
    root = ET.fromstring(ckl.split("\n", 2)[-1])

    injection_vuln = _find_vuln(root, "APSC-DV-002510")
    assert injection_vuln is not None, "VULN for APSC-DV-002510 not found"
    details = injection_vuln.findtext("FINDING_DETAILS") or ""
    assert "a.py:10" in details, f"Expected 'a.py:10' in FINDING_DETAILS: {details!r}"
    assert "b.py:20" in details, f"Expected 'b.py:20' in FINDING_DETAILS: {details!r}"


# ---------------------------------------------------------------------------
# 6. Finding details format: file:line, CWE, message
# ---------------------------------------------------------------------------


def test_finding_details_format() -> None:
    findings = [
        _make_finding(file="src/main.py", line=42, cwe_id=78, message="eval() detected")
    ]
    result = _make_result(findings)
    ckl = generate_stig_checklist(result)
    root = ET.fromstring(ckl.split("\n", 2)[-1])

    injection_vuln = _find_vuln(root, "APSC-DV-002510")
    assert injection_vuln is not None, "VULN for APSC-DV-002510 not found"
    details = injection_vuln.findtext("FINDING_DETAILS") or ""
    assert "src/main.py:42" in details, f"file:line missing in {details!r}"
    assert "CWE-78" in details, f"CWE missing in {details!r}"
    assert "eval() detected" in details, f"message missing in {details!r}"


# ---------------------------------------------------------------------------
# 7. VULN attributes match metadata file values
# ---------------------------------------------------------------------------


def test_vuln_num_and_rule_id_from_metadata() -> None:
    result = _make_result([])
    ckl = generate_stig_checklist(result)
    root = ET.fromstring(ckl.split("\n", 2)[-1])

    injection_vuln = _find_vuln(root, "APSC-DV-002510")
    assert injection_vuln is not None, "VULN for APSC-DV-002510 not found"

    assert _stig_attr(injection_vuln, "Vuln_Num") == "V-222602", (
        f"Vuln_Num mismatch: {_stig_attr(injection_vuln, 'Vuln_Num')!r}"
    )
    assert _stig_attr(injection_vuln, "Rule_ID") == "SV-222602r879887_rule", (
        f"Rule_ID mismatch: {_stig_attr(injection_vuln, 'Rule_ID')!r}"
    )
    cci = _stig_attr(injection_vuln, "CCI_REF")
    assert cci == "CCI-001310", f"CCI_REF mismatch: {cci!r}"


# ---------------------------------------------------------------------------
# 8. Summary table format
# ---------------------------------------------------------------------------


def test_summary_table_headers() -> None:
    result = _make_result([])
    summary = generate_stig_summary(result)
    assert "| STIG Rule |" in summary, "Summary table missing STIG Rule column"
    assert "| CAT |" in summary, "Summary table missing CAT column"
    assert "| Status |" in summary, "Summary table missing Status column"
    assert "| Findings |" in summary, "Summary table missing Findings column"


def test_summary_table_contains_all_rules() -> None:
    result = _make_result([])
    summary = generate_stig_summary(result)
    expected_rules = [
        "APSC-DV-000460",
        "APSC-DV-001460",
        "APSC-DV-002500",
        "APSC-DV-002510",
        "APSC-DV-002520",
        "APSC-DV-002530",
        "APSC-DV-002540",
        "APSC-DV-002550",
        "APSC-DV-002560",
        "APSC-DV-002570",
        "APSC-DV-002590",
    ]
    for rule in expected_rules:
        assert rule in summary, f"Rule {rule} missing from summary table"


def test_summary_open_count_reflects_findings() -> None:
    findings = [_make_finding(stig_entries=[_STIG_INJECTION])]
    result = _make_result(findings)
    summary = generate_stig_summary(result)
    assert "**Open:** 1" in summary, (
        f"Expected '**Open:** 1' in summary. Got:\n{summary}"
    )


def test_summary_shows_open_status_for_matched_rule() -> None:
    findings = [_make_finding(stig_entries=[_STIG_INJECTION])]
    result = _make_result(findings)
    summary = generate_stig_summary(result)
    # The row for APSC-DV-002510 should show **Open**
    assert "**Open**" in summary


def test_summary_includes_scan_metadata() -> None:
    result = _make_result([])
    summary = generate_stig_summary(result)
    assert result.scanned_path in summary
    assert result.sanicode_version in summary


# ---------------------------------------------------------------------------
# 9. Default asset config (None)
# ---------------------------------------------------------------------------


def test_default_asset_config_produces_valid_xml() -> None:
    result = _make_result([])
    # asset_config=None must not raise
    ckl = generate_stig_checklist(result, None)
    root = ET.fromstring(ckl.split("\n", 2)[-1])
    asset = root.find("ASSET")
    assert asset is not None
    # Default hostname should be empty string (not None or missing)
    host_name = asset.find("HOST_NAME")
    assert host_name is not None
    assert host_name.text == "" or host_name.text is None


# ---------------------------------------------------------------------------
# 10. StigConfig dataclass and TOML parsing
# ---------------------------------------------------------------------------


def test_stig_config_defaults() -> None:
    cfg = StigConfig()
    assert cfg.hostname == ""
    assert cfg.host_ip == ""
    assert cfg.host_fqdn == ""
    assert cfg.target_comment == "Sanicode automated STIG assessment"
    assert cfg.tech_area == ""


def test_stig_config_from_toml(tmp_path: Path) -> None:
    from sanicode.config import load_config

    toml_content = """\
[stig]
hostname = "app-server-01"
host_ip = "192.168.1.10"
host_fqdn = "app-server-01.example.com"
target_comment = "Production ATO scan"
tech_area = "Web Server"
"""
    config_file = tmp_path / "sanicode.toml"
    config_file.write_text(toml_content, encoding="utf-8")
    cfg = load_config(config_file)

    assert cfg.stig.hostname == "app-server-01", (
        f"hostname: {cfg.stig.hostname!r}"
    )
    assert cfg.stig.host_ip == "192.168.1.10", (
        f"host_ip: {cfg.stig.host_ip!r}"
    )
    assert cfg.stig.host_fqdn == "app-server-01.example.com", (
        f"host_fqdn: {cfg.stig.host_fqdn!r}"
    )
    assert cfg.stig.target_comment == "Production ATO scan", (
        f"target_comment: {cfg.stig.target_comment!r}"
    )
    assert cfg.stig.tech_area == "Web Server", (
        f"tech_area: {cfg.stig.tech_area!r}"
    )


def test_stig_config_absent_section_uses_defaults(tmp_path: Path) -> None:
    """When [stig] is absent from the TOML, StigConfig defaults apply."""
    from sanicode.config import load_config

    config_file = tmp_path / "sanicode.toml"
    config_file.write_text("[scan]\nmax_file_size_kb = 256\n", encoding="utf-8")
    cfg = load_config(config_file)

    assert cfg.stig.hostname == ""
    assert cfg.stig.target_comment == "Sanicode automated STIG assessment"


# ---------------------------------------------------------------------------
# Grouping helper unit tests
# ---------------------------------------------------------------------------


def test_group_findings_by_stig_empty() -> None:
    grouped = _group_findings_by_stig([])
    assert grouped == {}


def test_group_findings_by_stig_multiple_rules_per_finding() -> None:
    """A finding that maps to two STIG rules appears in both groups."""
    finding = _make_finding(stig_entries=[_STIG_INJECTION, _STIG_XSS])
    grouped = _group_findings_by_stig([finding])
    assert "APSC-DV-002510" in grouped, "Injection rule missing"
    assert "APSC-DV-002520" in grouped, "XSS rule missing"
    assert len(grouped["APSC-DV-002510"]) == 1
    assert len(grouped["APSC-DV-002520"]) == 1


def test_group_findings_by_stig_deduplicates_by_rule() -> None:
    """Two findings for the same rule both appear in that rule's group."""
    f1 = _make_finding(file="a.py", stig_entries=[_STIG_INJECTION])
    f2 = _make_finding(file="b.py", stig_entries=[_STIG_INJECTION])
    grouped = _group_findings_by_stig([f1, f2])
    assert len(grouped["APSC-DV-002510"]) == 2
