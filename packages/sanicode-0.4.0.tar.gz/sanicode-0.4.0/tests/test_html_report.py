"""Tests for the HTML dashboard generator (sanicode.report.html)."""

from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from sanicode.cli import app
from sanicode.compliance.enrichment import EnrichedFinding
from sanicode.compliance.mapper import ComplianceMapping
from sanicode.graph.builder import KnowledgeGraph
from sanicode.report.html import generate_html
from sanicode.report.persist import build_scan_result, save_scan_result

runner = CliRunner()

# ---------------------------------------------------------------------------
# Test data helpers
# ---------------------------------------------------------------------------


def _make_compliance(cwe_id: int) -> ComplianceMapping:
    return ComplianceMapping(
        cwe_id=cwe_id,
        cwe_name="OS Command Injection" if cwe_id == 78 else "SQL Injection",
        owasp_asvs=[{"id": "v5.0.0-V1-5.3.8", "title": "", "level": "L1"}],
        nist_800_53=["SI-10", "SI-15"],
        asd_stig=[{"id": "APSC-DV-002510", "cat": "CAT I", "title": ""}],
        pci_dss=["6.2.4"],
        asvs_level="L1",
        stig_category="CAT I",
        remediation="Use parameterized queries",
    )


def _make_findings(base_path: Path | None = None) -> list[EnrichedFinding]:
    root = base_path or Path("/app")
    return [
        EnrichedFinding(
            file=root / "app.py",
            line=42,
            column=8,
            rule_id="SC001",
            message="Use of eval()",
            severity="high",
            cwe_id=78,
            cwe_name="OS Command Injection",
            compliance=_make_compliance(78),
            derived_severity="critical",
            remediation="Use parameterized queries",
        ),
        EnrichedFinding(
            file=root / "db.py",
            line=17,
            column=4,
            rule_id="SC006",
            message="String formatting in SQL query",
            severity="medium",
            cwe_id=89,
            cwe_name="SQL Injection",
            compliance=_make_compliance(89),
            derived_severity="high",
            remediation="Use parameterized queries",
        ),
    ]


def _make_scan_result(tmp_path: Path):
    findings = _make_findings(base_path=tmp_path)
    kg = KnowledgeGraph()
    kg.add_entry_point("request_handler", file=tmp_path / "app.py", line=1)
    kg.add_sink("db_query", file=tmp_path / "db.py", line=17, cwe_id=89)
    return build_scan_result(findings, tmp_path, kg)


# ---------------------------------------------------------------------------
# HTML generator unit tests
# ---------------------------------------------------------------------------


class TestHtmlDashboardGenerator:
    def test_generate_html_returns_valid_html(self, tmp_path: Path) -> None:
        """Output contains DOCTYPE and basic HTML structure."""
        result = _make_scan_result(tmp_path)
        html = generate_html(result)
        assert "<!DOCTYPE html>" in html, "Expected DOCTYPE declaration"
        assert "<html" in html, "Expected opening <html> tag"
        assert "</html>" in html, "Expected closing </html> tag"

    def test_contains_chart_js_cdn(self, tmp_path: Path) -> None:
        """Chart.js CDN link should always be present."""
        result = _make_scan_result(tmp_path)
        html = generate_html(result)
        assert "cdn.jsdelivr.net/npm/chart.js" in html, (
            "Expected Chart.js CDN URL in output"
        )

    def test_contains_severity_data(self, tmp_path: Path) -> None:
        """Findings severity data should appear in the output."""
        result = _make_scan_result(tmp_path)
        html = generate_html(result)
        assert "critical" in html.lower(), (
            "Expected 'critical' severity to appear in HTML output"
        )

    def test_contains_cwe_references(self, tmp_path: Path) -> None:
        """CWE IDs from findings should appear in the dashboard JSON."""
        result = _make_scan_result(tmp_path)
        html = generate_html(result)
        # CWE IDs are present in the embedded JSON data; formatted by JavaScript
        assert '"cwe_id": 78' in html, "Expected CWE-78 (cwe_id: 78) in JSON data"
        assert '"cwe_id": 89' in html, "Expected CWE-89 (cwe_id: 89) in JSON data"

    def test_no_findings_shows_empty_state(self, tmp_path: Path) -> None:
        """Empty findings should produce a functioning dashboard with the title."""
        kg = KnowledgeGraph()
        result = build_scan_result([], tmp_path, kg)
        html = generate_html(result)
        assert "<!DOCTYPE html>" in html, "Expected DOCTYPE even with no findings"
        assert "Security Dashboard" in html, (
            "Expected 'Security Dashboard' in empty-state output"
        )

    def test_compliance_posture_present(self, tmp_path: Path) -> None:
        """Compliance posture section heading should be rendered."""
        result = _make_scan_result(tmp_path)
        html = generate_html(result)
        assert "Compliance" in html, "Expected 'Compliance' section in HTML output"

    def test_recommendations_present_when_findings_exist(self, tmp_path: Path) -> None:
        """Recommendations section should be present when findings exist."""
        result = _make_scan_result(tmp_path)
        html = generate_html(result)
        assert "Recommendation" in html, (
            "Expected 'Recommendation' section in HTML output when findings are present"
        )

    def test_graph_included_when_data_provided(self, tmp_path: Path) -> None:
        """When graph_data is provided, Cytoscape CDN and Knowledge Graph heading should appear."""
        result = _make_scan_result(tmp_path)
        graph_data = {
            "nodes": [
                {"id": "n1", "kind": "entry_point", "label": "handler"},
                {"id": "n2", "kind": "sink", "label": "db_query"},
            ],
            "links": [
                {"source": "n1", "target": "n2", "kind": "data_flow"},
            ],
        }
        html = generate_html(result, graph_data=graph_data)
        assert "<canvas" in html, (
            "Expected canvas element when graph_data is provided"
        )
        assert "Knowledge Graph" in html, (
            "Expected 'Knowledge Graph' section heading when graph_data is provided"
        )

    def test_graph_excluded_when_no_data(self, tmp_path: Path) -> None:
        """When graph_data is None, no Cytoscape CDN should appear in output."""
        result = _make_scan_result(tmp_path)
        html = generate_html(result, graph_data=None)
        assert 'id="graph-canvas"' not in html, (
            "Expected no graph canvas element when graph_data is None"
        )

    def test_scan_metadata_in_output(self, tmp_path: Path) -> None:
        """Scan ID and sanicode version should appear in the dashboard."""
        result = _make_scan_result(tmp_path)
        html = generate_html(result)
        assert result.scan_id in html, (
            f"Expected scan_id {result.scan_id!r} in HTML output"
        )
        assert result.sanicode_version in html, (
            f"Expected sanicode_version {result.sanicode_version!r} in HTML output"
        )

    def test_compliance_controls_in_output(self, tmp_path: Path) -> None:
        """Known compliance control IDs from test data should appear in the dashboard."""
        result = _make_scan_result(tmp_path)
        html = generate_html(result)
        # NIST control from _make_compliance
        assert "SI-10" in html, "Expected NIST control SI-10 in HTML output"

    def test_finding_without_compliance_data(self, tmp_path: Path) -> None:
        """A finding with compliance=None should not break the dashboard."""
        findings = [
            EnrichedFinding(
                file=tmp_path / "app.py", line=10, column=0,
                rule_id="SC099", message="Test finding without compliance",
                severity="medium", cwe_id=20,
                compliance=None, derived_severity="medium",
                remediation="Fix it",
            ),
        ]
        kg = KnowledgeGraph()
        result = build_scan_result(findings, tmp_path, kg)
        html = generate_html(result)
        assert "<!DOCTYPE html>" in html, "Expected valid HTML even without compliance data"
        assert "SC099" in html, "Expected rule_id in output"

    def test_empty_findings_hides_recommendations(self, tmp_path: Path) -> None:
        """With no findings, the recommendations section should be hidden via JS class."""
        kg = KnowledgeGraph()
        result = build_scan_result([], tmp_path, kg)
        html = generate_html(result)
        # The JS sets class="hidden" on recommendations-section when recs list is empty.
        # Check that the recommendations list would be empty — not that the section
        # is absent, since JS applies the class at runtime.
        assert "recommendations-section" in html, (
            "Expected recommendations-section element to exist in DOM even when empty"
        )


# ---------------------------------------------------------------------------
# CLI integration tests — depend on --format html being wired in cli.py
# ---------------------------------------------------------------------------


class TestHtmlFormatCli:
    def test_scan_html_format_creates_file(self, tmp_path: Path) -> None:
        """sanicode scan --format html should create report.html and mention it."""
        target = tmp_path / "sample"
        target.mkdir()
        (target / "app.py").write_text("import os\nos.system('ls')\n", encoding="utf-8")

        result = runner.invoke(app, ["scan", str(target), "--format", "html"])
        assert result.exit_code == 0, (
            f"Exit code {result.exit_code}:\n{result.output}"
        )
        assert "report.html" in result.output, (
            f"Expected 'report.html' in scan output:\n{result.output}"
        )

    def test_report_html_format_creates_file(self, tmp_path: Path) -> None:
        """sanicode report --format html should write report.html to the output dir."""
        result_obj = _make_scan_result(tmp_path)
        scan_result_path = save_scan_result(result_obj, tmp_path)
        out_dir = tmp_path / "reports"

        cli_result = runner.invoke(app, [
            "report", str(scan_result_path),
            "--format", "html",
            "--output-dir", str(out_dir),
        ])
        assert cli_result.exit_code == 0, (
            f"Exit code {cli_result.exit_code}:\n{cli_result.output}"
        )
        report_path = out_dir / "report.html"
        assert report_path.exists(), (
            f"Expected report.html to be created at {report_path}"
        )
        content = report_path.read_text(encoding="utf-8")
        assert "<!DOCTYPE html>" in content, (
            "Expected valid HTML in report.html (missing DOCTYPE)"
        )

    def test_report_html_content_includes_scan_id(self, tmp_path: Path) -> None:
        """The generated report.html should embed the original scan ID."""
        result_obj = _make_scan_result(tmp_path)
        scan_result_path = save_scan_result(result_obj, tmp_path)
        out_dir = tmp_path / "reports"

        cli_result = runner.invoke(app, [
            "report", str(scan_result_path),
            "--format", "html",
            "--output-dir", str(out_dir),
        ])
        assert cli_result.exit_code == 0, (
            f"Exit code {cli_result.exit_code}:\n{cli_result.output}"
        )
        content = (out_dir / "report.html").read_text(encoding="utf-8")
        assert result_obj.scan_id in content, (
            f"Expected scan_id {result_obj.scan_id!r} to appear in report.html"
        )
