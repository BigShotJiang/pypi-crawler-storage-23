"""Tests for the scoring engine — synthetic test data only, no repo scanning."""

from __future__ import annotations

from pathlib import Path

import pytest

from sanicode.scoring.ground_truth import (
    RealRepo,
    SyntheticProject,
    SyntheticVuln,
    load_ground_truth,
)
from sanicode.scoring.report import (
    RepoScore,
    ScoringReport,
    generate_json_report,
    generate_summary,
)
from sanicode.scoring.rubric import (
    Tier1Result,
    Tier2Result,
    compute_grade,
    cwe_matches,
    score_tier1,
    score_tier2,
    severity_penalty,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _finding(file: str, line: int, cwe_id: int, severity: str,
             rule_id: str = "SC000", message: str = "") -> dict:
    """Build a finding dict matching ScanResult.findings shape."""
    return {
        "file": file, "line": line, "cwe_id": cwe_id,
        "severity": severity, "rule_id": rule_id, "message": message,
    }


_BASE = "synthetic/test-proj/unmarked"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def sample_project() -> SyntheticProject:
    return SyntheticProject(
        name="Test Project",
        id="test-proj",
        language="Python",
        base_path="synthetic/test-proj/unmarked",
        vulnerabilities=[
            SyntheticVuln(
                vuln_id="TP-001",
                cwe_id="CWE-89",
                severity="Critical",
                file="app/db.py",
                line=50,
                end_line=52,
                description="SQL injection",
            ),
            SyntheticVuln(
                vuln_id="TP-002",
                cwe_id="CWE-79",
                severity="High",
                file="app/views.py",
                line=100,
                end_line=100,
                description="XSS",
            ),
            SyntheticVuln(
                vuln_id="TP-003",
                cwe_id="CWE-78",
                severity="Critical",
                file="app/utils.py",
                line=30,
                end_line=32,
                description="Command injection",
            ),
        ],
    )


@pytest.fixture
def sample_repo() -> RealRepo:
    return RealRepo(
        name="test-app",
        language=["Python"],
        type="deliberately-vulnerable",
        vuln_categories=["CWE-79", "CWE-89", "CWE-22"],
        has_ground_truth=False,
        scorable=True,
    )


# ---------------------------------------------------------------------------
# CWE alias matching
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "reported, expected, want",
    [
        ("CWE-89", "CWE-89", True),
        ("CWE-564", "CWE-89", True),
        ("CWE-89", "CWE-564", True),
        ("sql-injection", "CWE-89", True),
        ("CWE-79", "CWE-89", False),
        ("CWE-200", "CWE-359", True),
        ("cwe-89", "CWE-89", True),
        ("XSS", "CWE-79", True),
        ("CWE-79", "CWE-87", True),
        ("prototype-pollution", "CWE-1321", True),
        ("CWE-42", "CWE-99", False),  # both unknown
    ],
)
def test_cwe_matches(reported: str, expected: str, want: bool) -> None:
    assert cwe_matches(reported, expected) is want


# ---------------------------------------------------------------------------
# Severity penalty
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "reported, expected, want",
    [
        ("critical", "critical", 1.0),
        ("high", "critical", 0.5),
        ("medium", "critical", 0.25),
        ("low", "critical", 0.25),
        ("info", "high", 0.25),
        ("medium", "high", 0.5),
        ("High", "HIGH", 1.0),
    ],
)
def test_severity_penalty(reported: str, expected: str, want: float) -> None:
    assert severity_penalty(reported, expected) == want


# ---------------------------------------------------------------------------
# Grade computation
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "recall, precision, want",
    [
        (0.90, 0.85, "A"),
        (0.85, 0.80, "A"),
        (0.84, 0.80, "B"),
        (0.70, 0.70, "B"),
        (0.69, 0.70, "C"),
        (0.55, 0.60, "C"),
        (0.54, 0.60, "D"),
        (0.40, 0.50, "D"),
        (0.39, 0.50, "F"),
        (0.90, 0.49, "F"),
        (None, 0.80, "F"),
        (0.80, None, "F"),
        (None, None, "F"),
    ],
)
def test_compute_grade(
    recall: float | None, precision: float | None, want: str
) -> None:
    assert compute_grade(recall, precision) == want


# ---------------------------------------------------------------------------
# Tier 1 scoring
# ---------------------------------------------------------------------------


def test_tier1_perfect(sample_project: SyntheticProject, tmp_path: Path) -> None:
    findings = [
        _finding(f"{_BASE}/app/db.py", 51, 89, "critical"),
        _finding(f"{_BASE}/app/views.py", 100, 79, "high"),
        _finding(f"{_BASE}/app/utils.py", 31, 78, "critical"),
    ]
    result = score_tier1(findings, sample_project, tmp_path)
    assert result.tp == 3
    assert result.fp == 0
    assert result.fn == 0
    assert result.recall == 1.0
    assert result.precision == 1.0


def test_tier1_partial(sample_project: SyntheticProject, tmp_path: Path) -> None:
    """1 TP, 1 FP, 2 FN."""
    findings = [
        _finding(f"{_BASE}/app/db.py", 51, 89, "critical"),
        _finding(f"{_BASE}/app/other.py", 10, 200, "low"),
    ]
    result = score_tier1(findings, sample_project, tmp_path)
    assert result.tp == 1
    assert result.fp == 1
    assert result.fn == 2


def test_tier1_line_out_of_range(
    sample_project: SyntheticProject, tmp_path: Path
) -> None:
    """Finding at line 60 is outside the loose window [45, 57] for vuln at 50-52."""
    findings = [
        _finding(f"{_BASE}/app/db.py", 60, 89, "critical"),
    ]
    result = score_tier1(findings, sample_project, tmp_path)
    assert result.tp == 0
    assert result.fp == 1
    assert result.fn == 3


def test_tier1_duplicate_suppression(
    sample_project: SyntheticProject, tmp_path: Path
) -> None:
    """Two findings for the same vuln: only the first counts as TP."""
    findings = [
        _finding(f"{_BASE}/app/db.py", 50, 89, "critical", message="SQL injection 1"),
        _finding(f"{_BASE}/app/db.py", 51, 89, "critical", message="SQL injection 2"),
    ]
    result = score_tier1(findings, sample_project, tmp_path)
    assert result.tp == 1
    assert result.fp == 1
    assert result.fn == 2


def test_tier1_empty(sample_project: SyntheticProject, tmp_path: Path) -> None:
    result = score_tier1([], sample_project, tmp_path)
    assert result.tp == 0
    assert result.fp == 0
    assert result.fn == 3
    assert result.precision is None
    assert result.recall == 0.0


def test_tier1_severity_mismatch(
    sample_project: SyntheticProject, tmp_path: Path
) -> None:
    """Medium reported for a Critical vuln: severity_match=False, penalty=0.25."""
    findings = [
        _finding(f"{_BASE}/app/db.py", 51, 89, "medium"),
    ]
    result = score_tier1(findings, sample_project, tmp_path)
    assert result.tp == 1
    assert result.matches[0].severity_match is False
    assert result.matches[0].severity_penalty == 0.25
    assert result.severity_accuracy_rate == 0.0


def test_tier1_line_accuracy(
    sample_project: SyntheticProject, tmp_path: Path
) -> None:
    """Line 49 is within tight window [48, 54]; line 97 is outside tight [98, 102]."""
    findings = [
        _finding(f"{_BASE}/app/db.py", 49, 89, "critical"),
        _finding(f"{_BASE}/app/views.py", 97, 79, "high"),
    ]
    result = score_tier1(findings, sample_project, tmp_path)
    assert result.tp == 2
    assert result.line_accuracy_rate == 0.5


# ---------------------------------------------------------------------------
# Tier 2 scoring
# ---------------------------------------------------------------------------


def test_tier2_scoring(sample_repo: RealRepo) -> None:
    findings = [
        {"file": "app/views.py", "line": 10, "cwe_id": 79, "severity": "high"},
        {"file": "app/db.py", "line": 20, "cwe_id": 89, "severity": "critical"},
        {"file": "app/auth.py", "line": 5, "cwe_id": 798, "severity": "high"},  # FP
    ]
    result = score_tier2(findings, sample_repo)
    assert result.tp == 2
    assert result.fp == 1
    assert result.precision == pytest.approx(2 / 3)


def test_tier2_non_scorable() -> None:
    repo = RealRepo(
        name="tool-repo",
        language=["Python"],
        type="tool",
        vuln_categories=["CWE-79"],
        has_ground_truth=False,
        scorable=False,
    )
    result = score_tier2([{"file": "a.py", "cwe_id": 79, "severity": "high"}], repo)
    assert result.tp == 0
    assert result.fp == 0
    assert result.precision is None


def test_tier2_vendored_excluded(sample_repo: RealRepo) -> None:
    findings = [
        {"file": "node_modules/pkg/vuln.js", "line": 1, "cwe_id": 79, "severity": "high"},
        {"file": "app/views.py", "line": 10, "cwe_id": 79, "severity": "high"},
    ]
    result = score_tier2(findings, sample_repo)
    assert result.tp == 1
    assert result.fp == 0


def test_tier2_non_code_excluded(sample_repo: RealRepo) -> None:
    findings = [
        {"file": "docs/vulns.md", "line": 1, "cwe_id": 79, "severity": "high"},
    ]
    result = score_tier2(findings, sample_repo)
    assert result.tp == 0
    assert result.fp == 0


# ---------------------------------------------------------------------------
# Ground truth loading
# ---------------------------------------------------------------------------


def test_load_ground_truth(tmp_path: Path) -> None:
    synthetic = tmp_path / "synthetic-ground-truth.yaml"
    synthetic.write_text("""\
projects:
  - project:
      name: Test
      id: test-proj
      language: PHP
    base_path: synthetic/test-proj/unmarked
    vulnerabilities:
      - vuln_id: T-001
        cwe_id: CWE-89
        severity: Critical
        file: index.php
        line: 10
        end_line: 12
        description: SQL injection
""")

    catalog = tmp_path / "real-repos-catalog.yaml"
    catalog.write_text("""\
repositories:
  - name: juice-shop
    language: [JavaScript]
    type: deliberately-vulnerable
    vuln_categories: [CWE-79, CWE-89]
    has_ground_truth: true
  - name: gitleaks
    language: Go
    type: tool
    vuln_categories: []
    has_ground_truth: false
""")

    gt = load_ground_truth(tmp_path)

    assert len(gt.synthetic_projects) == 1
    assert gt.synthetic_projects[0].id == "test-proj"
    assert len(gt.synthetic_projects[0].vulnerabilities) == 1
    assert gt.synthetic_projects[0].vulnerabilities[0].cwe_id == "CWE-89"

    assert len(gt.real_repos) == 2
    juice = gt.real_repos[0]
    assert juice.name == "juice-shop"
    assert juice.scorable is True
    assert juice.language == ["JavaScript"]

    gitleaks = gt.real_repos[1]
    assert gitleaks.name == "gitleaks"
    assert gitleaks.scorable is False  # type=tool


def test_load_ground_truth_string_language(tmp_path: Path) -> None:
    """A single-string language value is normalized to a list."""
    (tmp_path / "synthetic-ground-truth.yaml").write_text("projects: []\n")
    (tmp_path / "real-repos-catalog.yaml").write_text("""\
repositories:
  - name: test
    language: Python
    type: deliberately-vulnerable
    vuln_categories: [CWE-79]
    has_ground_truth: false
""")
    gt = load_ground_truth(tmp_path)
    assert gt.real_repos[0].language == ["Python"]


def test_load_ground_truth_missing_file(tmp_path: Path) -> None:
    """Missing YAML files raise FileNotFoundError."""
    with pytest.raises(FileNotFoundError):
        load_ground_truth(tmp_path)


# ---------------------------------------------------------------------------
# Report generation
# ---------------------------------------------------------------------------


def test_generate_summary() -> None:
    report = ScoringReport(
        repos_dir="/tmp/repos",
        per_repo=[
            RepoScore(
                name="proj-a",
                tier=1,
                had_scannable_files=False,
                findings_count=0,
                tier1_result=Tier1Result(project_name="proj-a", project_id="pa", fn=15),
            ),
            RepoScore(
                name="repo-b",
                tier=2,
                had_scannable_files=True,
                findings_count=5,
                tier2_result=Tier2Result(repo_name="repo-b", tp=3, fp=2, precision=0.6),
            ),
        ],
    )
    text = generate_summary(report)
    assert "Tier 1" in text
    assert "Tier 2" in text
    assert "0/15 vulns detected" in text


def test_generate_json_report() -> None:
    report = ScoringReport(repos_dir="/tmp/repos")
    data = generate_json_report(report)
    assert "sanicode_version" in data
    assert "timestamp" in data
    assert data["aggregate"]["grade"] == "F"
    assert data["per_repo"] == []
