"""Tests for the PluginRegistry."""

from __future__ import annotations

import pytest

from sanicode.scanner.plugin import LanguagePlugin
from sanicode.scanner.registry import PluginRegistry


class MockPlugin:
    @property
    def name(self) -> str:
        return "mock"

    @property
    def extensions(self) -> frozenset[str]:
        return frozenset({".mock", ".mk"})

    def parse_file(self, path): return None
    def parse_source(self, source, filename="<string>"): return None
    def check_patterns(self, tree, file_path): return []
    def detect_entry_points(self, tree, file_path, frameworks=None): return []
    def detect_sinks(self, tree, file_path, frameworks=None): return []
    def detect_sanitizers(self, tree, file_path): return []
    def detect_imports(self, tree, file_path): return []
    def detect_frameworks(self, imports): return []
    def collect_definitions(self, file_trees, project_root=None): return {}
    def collect_call_sites(self, file_trees): return []
    def resolve_calls(self, definitions, call_sites, imports): return []
    def find_package_root(self, file_path): return None


class AnotherPlugin:
    @property
    def name(self) -> str:
        return "another"

    @property
    def extensions(self) -> frozenset[str]:
        return frozenset({".other"})

    def parse_file(self, path): return None
    def parse_source(self, source, filename="<string>"): return None
    def check_patterns(self, tree, file_path): return []
    def detect_entry_points(self, tree, file_path, frameworks=None): return []
    def detect_sinks(self, tree, file_path, frameworks=None): return []
    def detect_sanitizers(self, tree, file_path): return []
    def detect_imports(self, tree, file_path): return []
    def detect_frameworks(self, imports): return []
    def collect_definitions(self, file_trees, project_root=None): return {}
    def collect_call_sites(self, file_trees): return []
    def resolve_calls(self, definitions, call_sites, imports): return []
    def find_package_root(self, file_path): return None


class TestPluginRegistration:
    def test_register_and_lookup_by_name(self):
        reg = PluginRegistry()
        plugin = MockPlugin()
        reg.register(plugin)
        assert reg.for_language("mock") is plugin

    def test_lookup_by_extension(self):
        reg = PluginRegistry()
        plugin = MockPlugin()
        reg.register(plugin)
        assert reg.for_extension(".mock") is plugin
        assert reg.for_extension(".mk") is plugin

    @pytest.mark.parametrize("ext", [".mock", "mock"])
    def test_for_extension_normalizes_leading_dot(self, ext):
        reg = PluginRegistry()
        reg.register(MockPlugin())
        assert reg.for_extension(ext) is not None

    def test_for_extension_unknown_returns_none(self):
        reg = PluginRegistry()
        reg.register(MockPlugin())
        assert reg.for_extension(".xyz") is None

    def test_for_language_unknown_returns_none(self):
        reg = PluginRegistry()
        reg.register(MockPlugin())
        assert reg.for_language("cobol") is None

    def test_for_language_case_insensitive(self):
        reg = PluginRegistry()
        plugin = MockPlugin()
        reg.register(plugin)
        assert reg.for_language("MOCK") is plugin
        assert reg.for_language("Mock") is plugin
        assert reg.for_language("mock") is plugin

    def test_duplicate_extension_raises(self):
        class ConflictPlugin:
            @property
            def name(self): return "conflict"

            @property
            def extensions(self): return frozenset({".mock"})

            def parse_file(self, path): return None
            def parse_source(self, source, filename="<string>"): return None
            def check_patterns(self, tree, file_path): return []
            def detect_entry_points(self, tree, file_path, frameworks=None): return []
            def detect_sinks(self, tree, file_path, frameworks=None): return []
            def detect_sanitizers(self, tree, file_path): return []
            def detect_imports(self, tree, file_path): return []
            def detect_frameworks(self, imports): return []
            def collect_definitions(self, file_trees, project_root=None): return {}
            def collect_call_sites(self, file_trees): return []
            def resolve_calls(self, definitions, call_sites, imports): return []
            def find_package_root(self, file_path): return None

        reg = PluginRegistry()
        reg.register(MockPlugin())
        with pytest.raises(ValueError, match=r"\.mock"):
            reg.register(ConflictPlugin())

    def test_duplicate_language_raises(self):
        class DuplicateMock:
            @property
            def name(self): return "mock"

            @property
            def extensions(self): return frozenset({".xmock"})

            def parse_file(self, path): return None
            def parse_source(self, source, filename="<string>"): return None
            def check_patterns(self, tree, file_path): return []
            def detect_entry_points(self, tree, file_path, frameworks=None): return []
            def detect_sinks(self, tree, file_path, frameworks=None): return []
            def detect_sanitizers(self, tree, file_path): return []
            def detect_imports(self, tree, file_path): return []
            def detect_frameworks(self, imports): return []
            def collect_definitions(self, file_trees, project_root=None): return {}
            def collect_call_sites(self, file_trees): return []
            def resolve_calls(self, definitions, call_sites, imports): return []
            def find_package_root(self, file_path): return None

        reg = PluginRegistry()
        reg.register(MockPlugin())
        with pytest.raises(ValueError, match="mock"):
            reg.register(DuplicateMock())

    def test_supported_extensions_aggregates(self):
        reg = PluginRegistry()
        reg.register(MockPlugin())
        reg.register(AnotherPlugin())
        exts = reg.supported_extensions()
        assert ".mock" in exts
        assert ".mk" in exts
        assert ".other" in exts

    def test_registered_languages_sorted(self):
        reg = PluginRegistry()
        reg.register(MockPlugin())
        reg.register(AnotherPlugin())
        langs = reg.registered_languages()
        assert langs == sorted(langs)
        assert "mock" in langs
        assert "another" in langs

    def test_mock_plugin_satisfies_protocol(self):
        assert isinstance(MockPlugin(), LanguagePlugin)
