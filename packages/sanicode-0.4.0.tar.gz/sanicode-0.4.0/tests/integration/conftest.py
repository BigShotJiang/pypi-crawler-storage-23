"""Shared fixtures for integration tests requiring a live LLM endpoint."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from sanicode.config import LLMTierConfig, SanicodeConfig
from sanicode.llm.client import LLMClient


@pytest.fixture
def llm_provider() -> str:
    """LiteLLM provider prefix (default: openai)."""
    return os.environ.get("SANICODE_TEST_LLM_PROVIDER", "openai")


@pytest.fixture
def llm_endpoint(llm_provider: str) -> str | None:
    """LLM endpoint URL, or None for cloud providers.

    For self-hosted providers (openai), SANICODE_TEST_LLM_ENDPOINT must be set.
    For cloud providers (anthropic, etc.), the endpoint is not needed.
    """
    endpoint = os.environ.get("SANICODE_TEST_LLM_ENDPOINT")
    if not endpoint and llm_provider == "openai":
        pytest.skip(
            "SANICODE_TEST_LLM_ENDPOINT not set — skipping integration tests"
        )
    return endpoint or None


@pytest.fixture
def llm_model_name() -> str:
    """Model name served at the endpoint (default: granite-code-8b)."""
    return os.environ.get("SANICODE_TEST_LLM_MODEL", "granite-code-8b")


@pytest.fixture
def integration_config(
    llm_provider: str, llm_endpoint: str | None, llm_model_name: str,
) -> SanicodeConfig:
    """SanicodeConfig with all three LLM tiers pointed at the test endpoint."""
    cfg = SanicodeConfig()
    tier = LLMTierConfig(
        provider=llm_provider,
        model=llm_model_name,
        endpoint=llm_endpoint or "",
    )
    cfg.llm.fast = tier
    cfg.llm.analysis = tier
    cfg.llm.reasoning = tier
    return cfg


@pytest.fixture
def fixtures_dir() -> Path:
    """Path to the integration test fixtures directory."""
    return Path(__file__).parent / "fixtures"


@pytest.fixture
def llm_client(integration_config: SanicodeConfig) -> LLMClient:
    """LLMClient built from the integration config."""
    return LLMClient.from_config(integration_config)
