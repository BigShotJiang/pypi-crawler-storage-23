"""Vulnerable: SQL injection via string formatting (SC006 / CWE-89).

Expected: sanicode detects SC006, LLM retains as true positive.
"""

import sqlite3


def get_user(name):
    """Fetch user by name — VULNERABLE to SQL injection."""
    conn = sqlite3.connect(":memory:")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE name = '%s'" % name)  # noqa: UP031
    return cursor.fetchone()
