"""Safe: eval() on a constant expression (SC001 / CWE-94 false positive).

Static analysis flags eval() as SC001, but the argument is a compile-time
constant — no user input reaches it.  The LLM should classify this as a
false positive, demonstrating context-aware filtering.

Expected: sanicode detects SC001 statically, LLM filters it out.
"""

FORMULA = "2 + 2"


def compute():
    """Evaluate a hardcoded arithmetic expression — NOT vulnerable."""
    return eval(FORMULA)
