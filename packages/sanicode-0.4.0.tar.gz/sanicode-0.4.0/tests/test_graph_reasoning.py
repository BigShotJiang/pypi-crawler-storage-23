"""Tests for the graph reasoning module (src/sanicode/graph/reasoning.py)."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock

import pytest

from sanicode.graph.builder import KnowledgeGraph
from sanicode.graph.reasoning import (
    ThreatPath,
    _stub_assessments,
    assess_threat_paths,
    collect_code_snippets,
    extract_threat_paths,
    parse_assessment_response,
    serialize_path_for_llm,
)
from sanicode.llm.client import LLMNotConfiguredError, LLMResponse

# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------


def _make_kg() -> KnowledgeGraph:
    """Build a minimal KnowledgeGraph for testing (no file I/O required)."""
    return KnowledgeGraph()


def _llm_with_tier(tier: str = "reasoning") -> MagicMock:
    """Return a mock LLMClient that reports ``has_tier(tier)`` as True."""
    llm = MagicMock()
    llm.has_tier.side_effect = lambda t: t == tier
    return llm


def _llm_response(content: str) -> LLMResponse:
    return LLMResponse(content=content, model="test-model", tier="reasoning", usage={})


# ---------------------------------------------------------------------------
# extract_threat_paths
# ---------------------------------------------------------------------------


class TestExtractThreatPaths:
    def test_empty_graph_returns_no_paths(self) -> None:
        kg = _make_kg()
        assert extract_threat_paths(kg) == []

    def test_no_sinks_returns_no_paths(self) -> None:
        kg = _make_kg()
        kg.add_entry_point("request.args.get", file=Path("app.py"), line=5)
        assert extract_threat_paths(kg) == []

    def test_no_entries_returns_no_paths(self) -> None:
        kg = _make_kg()
        kg.add_sink("cursor.execute", file=Path("app.py"), line=10)
        assert extract_threat_paths(kg) == []

    def test_disconnected_entry_and_sink_returns_no_paths(self) -> None:
        kg = _make_kg()
        # Nodes exist but no edge connects them.
        kg.add_entry_point("request.args.get", file=Path("app.py"), line=5)
        kg.add_sink("cursor.execute", file=Path("app.py"), line=10)
        assert extract_threat_paths(kg) == []

    def test_simple_entry_to_sink(self) -> None:
        """Direct entry -> sink edge is extracted as a single ThreatPath."""
        kg = _make_kg()
        entry_id = kg.add_entry_point("request.args.get", file=Path("app.py"), line=5)
        sink_id = kg.add_sink("cursor.execute", file=Path("app.py"), line=10, cwe_id=89)
        kg.add_data_flow(entry_id, sink_id, confidence="taint_analysis", sanitized=False)

        paths = extract_threat_paths(kg)

        assert len(paths) == 1
        p = paths[0]
        assert p.path_id == "path_1"
        assert p.entry_node["label"] == "request.args.get"
        assert p.sink_node["label"] == "cursor.execute"
        assert p.intermediates == []
        assert p.edge_confidences == ["taint_analysis"]
        assert p.is_sanitized is False

    def test_path_through_sanitizer_is_marked_sanitized(self) -> None:
        """A path with an intermediate sanitizer node sets is_sanitized=True."""
        kg = _make_kg()
        entry_id = kg.add_entry_point("request.form.get", file=Path("app.py"), line=3)
        san_id = kg.add_sanitizer("html.escape", file=Path("app.py"), line=6)
        sink_id = kg.add_sink("render_template_string", file=Path("app.py"), line=9, cwe_id=79)

        kg.add_data_flow(entry_id, san_id, confidence="taint_analysis", sanitized=False)
        kg.add_data_flow(san_id, sink_id, confidence="taint_analysis", sanitized=True)

        paths = extract_threat_paths(kg)

        assert len(paths) == 1
        p = paths[0]
        assert p.is_sanitized is True
        assert len(p.intermediates) == 1
        assert p.intermediates[0]["kind"] == "sanitizer"

    def test_edge_sanitized_flag_marks_path_sanitized(self) -> None:
        """An edge with sanitized=True marks the path as sanitized even without a sanitizer node."""
        kg = _make_kg()
        entry_id = kg.add_entry_point("os.environ.get", file=Path("app.py"), line=2)
        sink_id = kg.add_sink("subprocess.run", file=Path("app.py"), line=8, cwe_id=78)
        kg.add_data_flow(entry_id, sink_id, confidence="taint_analysis", sanitized=True)

        paths = extract_threat_paths(kg)

        assert len(paths) == 1
        assert paths[0].is_sanitized is True

    def test_path_ids_are_unique_for_multiple_paths(self) -> None:
        """Each path gets a distinct path_id."""
        kg = _make_kg()
        e1 = kg.add_entry_point("input_a", file=Path("a.py"), line=1)
        e2 = kg.add_entry_point("input_b", file=Path("b.py"), line=1)
        s1 = kg.add_sink("sink_x", file=Path("a.py"), line=10, cwe_id=78)

        kg.add_data_flow(e1, s1, confidence="heuristic")
        kg.add_data_flow(e2, s1, confidence="heuristic")

        paths = extract_threat_paths(kg)
        ids = [p.path_id for p in paths]

        assert len(ids) == len(set(ids)), f"Duplicate path IDs: {ids}"

    def test_heuristic_edge_confidence_preserved(self) -> None:
        kg = _make_kg()
        e = kg.add_entry_point("request", file=Path("app.py"), line=1)
        s = kg.add_sink("eval", file=Path("app.py"), line=5, cwe_id=94)
        kg.add_data_flow(e, s, confidence="heuristic")

        paths = extract_threat_paths(kg)
        assert paths[0].edge_confidences == ["heuristic"]


# ---------------------------------------------------------------------------
# serialize_path_for_llm
# ---------------------------------------------------------------------------


class TestSerializePath:
    def _make_simple_path(self) -> ThreatPath:
        return ThreatPath(
            path_id="path_1",
            entry_node={
                "label": "request.args.get",
                "kind": "entry_point",
                "file": "/app/views.py",
                "line": 10,
                "function": "search",
            },
            sink_node={
                "label": "cursor.execute",
                "kind": "sink",
                "file": "/app/views.py",
                "line": 20,
                "function": "search",
                "cwe_id": 89,
            },
            intermediates=[],
            edge_confidences=["taint_analysis"],
            is_sanitized=False,
        )

    def test_path_id_appears_in_output(self) -> None:
        path = self._make_simple_path()
        output = serialize_path_for_llm(path)
        assert "path_1" in output

    def test_entry_and_sink_labels_appear(self) -> None:
        path = self._make_simple_path()
        output = serialize_path_for_llm(path)
        assert "request.args.get" in output
        assert "cursor.execute" in output

    def test_edge_confidence_appears(self) -> None:
        path = self._make_simple_path()
        output = serialize_path_for_llm(path)
        assert "taint_analysis" in output

    def test_sanitized_flag_reported(self) -> None:
        path = self._make_simple_path()
        path.is_sanitized = True
        output = serialize_path_for_llm(path)
        assert "Sanitized on path: YES" in output

    def test_unsanitized_flag_reported(self) -> None:
        path = self._make_simple_path()
        output = serialize_path_for_llm(path)
        assert "Sanitized on path: NO" in output

    def test_cwe_id_included_when_present(self) -> None:
        path = self._make_simple_path()
        output = serialize_path_for_llm(path)
        assert "89" in output

    def test_intermediate_node_appears(self) -> None:
        path = self._make_simple_path()
        path.intermediates = [
            {"label": "html.escape", "kind": "sanitizer", "file": "/app/views.py", "line": 15}
        ]
        path.edge_confidences = ["taint_analysis", "taint_analysis"]
        output = serialize_path_for_llm(path)
        assert "html.escape" in output

    def test_code_snippet_included_when_provided(self) -> None:
        path = self._make_simple_path()
        snippets = {"/app/views.py:10": "   10 | x = request.args.get('q')"}
        output = serialize_path_for_llm(path, code_snippets=snippets)
        assert "request.args.get('q')" in output

    def test_no_crash_with_missing_optional_attrs(self) -> None:
        """Nodes with minimal attributes should serialize without error."""
        path = ThreatPath(
            path_id="path_x",
            entry_node={"label": "entry", "kind": "entry_point"},
            sink_node={"label": "sink", "kind": "sink"},
            intermediates=[],
            edge_confidences=["heuristic"],
            is_sanitized=False,
        )
        output = serialize_path_for_llm(path)
        assert "path_x" in output
        assert "entry" in output


# ---------------------------------------------------------------------------
# parse_assessment_response
# ---------------------------------------------------------------------------


class TestParseAssessmentResponse:
    def test_parses_valid_json_array(self) -> None:
        response = (
            '[{"path_id": "path_1", "risk_level": "high", "is_exploitable": true,'
            ' "reasoning": "SQL injection",'
            ' "recommended_fix": "Use parameterized queries", "confidence": 0.9}]'
        )
        results = parse_assessment_response(response, ["path_1"])

        assert len(results) == 1
        a = results[0]
        assert a.path_id == "path_1"
        assert a.risk_level == "high"
        assert a.is_exploitable is True
        assert a.confidence == pytest.approx(0.9)
        assert "parameterized" in a.recommended_fix

    def test_strips_markdown_fences(self) -> None:
        response = (
            '```json\n[{"path_id": "p1", "risk_level": "low", "is_exploitable": false,'
            ' "reasoning": "safe", "recommended_fix": "", "confidence": 0.8}]\n```'
        )
        results = parse_assessment_response(response, ["p1"])

        assert len(results) == 1
        assert results[0].risk_level == "low"

    def test_malformed_json_returns_stubs(self) -> None:
        results = parse_assessment_response("this is not json at all", ["path_1", "path_2"])

        assert len(results) == 2
        assert all(r.risk_level == "review" for r in results)
        assert all(r.confidence == 0.0 for r in results)

    def test_non_array_response_returns_stubs(self) -> None:
        results = parse_assessment_response('{"path_id": "path_1"}', ["path_1"])

        assert len(results) == 1
        assert results[0].risk_level == "review"

    def test_invalid_risk_level_coerced_to_review(self) -> None:
        response = (
            '[{"path_id": "p1", "risk_level": "UNKNOWN", "is_exploitable": true,'
            ' "reasoning": "x", "recommended_fix": "", "confidence": 0.5}]'
        )
        results = parse_assessment_response(response, ["p1"])

        assert results[0].risk_level == "review"

    def test_confidence_clamped_to_0_1(self) -> None:
        response = (
            '[{"path_id": "p1", "risk_level": "high", "is_exploitable": true,'
            ' "reasoning": "x", "recommended_fix": "", "confidence": 5.0}]'
        )
        results = parse_assessment_response(response, ["p1"])

        assert results[0].confidence == pytest.approx(1.0)

    def test_multiple_assessments_parsed(self) -> None:
        response = (
            '[{"path_id": "path_1", "risk_level": "critical", "is_exploitable": true,'
            ' "reasoning": "a", "recommended_fix": "", "confidence": 0.95},'
            ' {"path_id": "path_2", "risk_level": "none", "is_exploitable": false,'
            ' "reasoning": "b", "recommended_fix": "", "confidence": 0.8}]'
        )
        results = parse_assessment_response(response, ["path_1", "path_2"])

        assert len(results) == 2
        assert results[0].risk_level == "critical"
        assert results[1].risk_level == "none"


# ---------------------------------------------------------------------------
# assess_threat_paths
# ---------------------------------------------------------------------------


class TestAssessThreatPaths:
    def test_skips_when_reasoning_tier_not_configured(self) -> None:
        llm = MagicMock()
        llm.has_tier.return_value = False

        result = assess_threat_paths(llm, [])
        assert result == []
        llm.reason.assert_not_called()

    def test_returns_empty_for_empty_paths_list(self) -> None:
        llm = _llm_with_tier("reasoning")
        result = assess_threat_paths(llm, [])
        assert result == []
        llm.reason.assert_not_called()

    def test_calls_llm_reason_with_serialized_paths(self) -> None:
        llm = _llm_with_tier("reasoning")
        llm.reason.return_value = _llm_response(
            '[{"path_id": "path_1", "risk_level": "high", "is_exploitable": true, '
            '"reasoning": "SQL injection", "recommended_fix": "Use params", "confidence": 0.9}]'
        )

        path = ThreatPath(
            path_id="path_1",
            entry_node={"label": "req", "kind": "entry_point"},
            sink_node={"label": "cursor.execute", "kind": "sink", "cwe_id": 89},
            edge_confidences=["taint_analysis"],
        )

        results = assess_threat_paths(llm, [path])

        llm.reason.assert_called_once()
        assert len(results) == 1
        assert results[0].path_id == "path_1"
        assert results[0].is_exploitable is True

    def test_handles_llm_exception_gracefully(self) -> None:
        llm = _llm_with_tier("reasoning")
        llm.reason.side_effect = RuntimeError("network failure")

        path = ThreatPath(
            path_id="path_1",
            entry_node={"label": "input", "kind": "entry_point"},
            sink_node={"label": "eval", "kind": "sink"},
            edge_confidences=["heuristic"],
        )

        # Should not raise; returns stub assessment instead.
        results = assess_threat_paths(llm, [path])

        assert len(results) == 1
        assert results[0].path_id == "path_1"
        assert results[0].risk_level == "review"
        assert results[0].confidence == 0.0

    def test_batches_paths_in_groups(self) -> None:
        """More than _BATCH_SIZE paths trigger multiple LLM calls."""
        from sanicode.graph.reasoning import _BATCH_SIZE

        llm = _llm_with_tier("reasoning")
        call_count = 0
        received_path_ids: list[str] = []

        def _side_effect(prompt: str) -> LLMResponse:
            nonlocal call_count
            call_count += 1
            # Extract path IDs from the section headers "--- path_N ---"
            import re
            ids = re.findall(r"--- (path_\d+) ---", prompt)
            received_path_ids.extend(ids)
            items = [
                f'{{"path_id": "{pid}", "risk_level": "low", "is_exploitable": false, '
                f'"reasoning": "ok", "recommended_fix": "", "confidence": 0.5}}'
                for pid in ids
            ]
            return _llm_response(f"[{', '.join(items)}]")

        llm.reason.side_effect = _side_effect

        n_paths = _BATCH_SIZE + 2
        paths = [
            ThreatPath(
                path_id=f"path_{i + 1}",
                entry_node={"label": f"entry_{i}", "kind": "entry_point"},
                sink_node={"label": f"sink_{i}", "kind": "sink"},
                edge_confidences=["heuristic"],
            )
            for i in range(n_paths)
        ]

        results = assess_threat_paths(llm, paths)

        assert call_count == 2, f"Expected 2 LLM calls for {n_paths} paths, got {call_count}"
        assert len(results) == n_paths, (
            f"Expected {n_paths} results, got {len(results)}: {[r.path_id for r in results]}"
        )

    def test_handles_llm_not_configured_error_mid_run(self) -> None:
        """LLMNotConfiguredError mid-run stops processing without raising."""
        llm = _llm_with_tier("reasoning")
        llm.reason.side_effect = LLMNotConfiguredError("gone")

        path = ThreatPath(
            path_id="path_1",
            entry_node={"label": "e", "kind": "entry_point"},
            sink_node={"label": "s", "kind": "sink"},
            edge_confidences=["heuristic"],
        )

        # Should not raise.
        results = assess_threat_paths(llm, [path])
        assert results == []


# ---------------------------------------------------------------------------
# collect_code_snippets
# ---------------------------------------------------------------------------


class TestCollectCodeSnippets:
    def test_reads_snippet_from_real_file(self, tmp_path: Path) -> None:
        src = tmp_path / "app.py"
        src.write_text("line1\nline2\nline3\nline4\nline5\n", encoding="utf-8")

        path = ThreatPath(
            path_id="p1",
            entry_node={"label": "x", "kind": "entry_point", "file": str(src), "line": 3},
            sink_node={"label": "y", "kind": "sink", "file": str(src), "line": 3},
            edge_confidences=[],
        )

        snippets = collect_code_snippets([path], context_lines=1)

        key = f"{src}:3"
        assert key in snippets
        assert "line3" in snippets[key]

    def test_missing_file_is_skipped_silently(self) -> None:
        path = ThreatPath(
            path_id="p1",
            entry_node={
                "label": "x", "kind": "entry_point",
                "file": "/nonexistent/file.py", "line": 1,
            },
            sink_node={"label": "y", "kind": "sink"},
            edge_confidences=[],
        )

        snippets = collect_code_snippets([path])
        assert snippets == {}

    def test_deduplicates_nodes_with_same_file_and_line(self, tmp_path: Path) -> None:
        """When entry and sink share the same file:line, only one read should occur."""
        src = tmp_path / "shared.py"
        src.write_text("shared line\n", encoding="utf-8")

        path = ThreatPath(
            path_id="p1",
            entry_node={"label": "x", "kind": "entry_point", "file": str(src), "line": 1},
            sink_node={"label": "y", "kind": "sink", "file": str(src), "line": 1},
            edge_confidences=[],
        )

        snippets = collect_code_snippets([path])
        assert len(snippets) == 1

    def test_nodes_without_file_or_line_are_skipped(self) -> None:
        path = ThreatPath(
            path_id="p1",
            entry_node={"label": "x", "kind": "entry_point"},  # no file/line
            sink_node={"label": "y", "kind": "sink"},
            edge_confidences=[],
        )
        snippets = collect_code_snippets([path])
        assert snippets == {}


# ---------------------------------------------------------------------------
# _stub_assessments (internal utility)
# ---------------------------------------------------------------------------


class TestStubAssessments:
    def test_produces_one_stub_per_path_id(self) -> None:
        stubs = _stub_assessments(["path_1", "path_2"], "test error")
        assert len(stubs) == 2
        assert stubs[0].path_id == "path_1"
        assert stubs[1].path_id == "path_2"

    def test_stubs_have_review_risk_level(self) -> None:
        stubs = _stub_assessments(["p1"], "err")
        assert stubs[0].risk_level == "review"
        assert stubs[0].is_exploitable is False
        assert stubs[0].confidence == 0.0

    def test_reason_appears_in_stub_reasoning(self) -> None:
        stubs = _stub_assessments(["p1"], "JSON parse error")
        assert "JSON parse error" in stubs[0].reasoning
