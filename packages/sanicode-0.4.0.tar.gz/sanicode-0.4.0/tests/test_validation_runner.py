"""Tests for the LLM validation runner and report modules."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from sanicode.compliance.enrichment import EnrichedFinding
from sanicode.config import SanicodeConfig
from sanicode.validation.report import format_markdown, format_table, save_json
from sanicode.validation.runner import (
    PassResult,
    ValidationResult,
    _compute_delta,
    _make_pass_config,
    _score_file,
    check_minimum_bar,
    load_ground_truth,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_finding(cwe_id: int, line: int, rule_id: str = "SC-TEST") -> EnrichedFinding:
    return EnrichedFinding(
        file=Path("test.py"),
        line=line,
        column=0,
        rule_id=rule_id,
        message="test finding",
        severity="high",
        cwe_id=cwe_id,
    )


def _make_pass(
    name: str,
    tp: int = 0,
    fp: int = 0,
    fn: int = 0,
    precision: float | None = None,
    recall: float | None = None,
    f1: float | None = None,
    scan_time: float = 1.0,
) -> PassResult:
    return PassResult(
        pass_name=name,
        tiers_enabled=[],
        true_positives=tp,
        false_positives=fp,
        false_negatives=fn,
        precision=precision,
        recall=recall,
        f1=f1,
        scan_time_seconds=scan_time,
    )


# ---------------------------------------------------------------------------
# _score_file tests
# ---------------------------------------------------------------------------


class TestScoreFile:
    def test_all_tp(self) -> None:
        findings = [_make_finding(89, 10), _make_finding(78, 20)]
        expected = [
            {"cwe_id": 89, "line": 10},
            {"cwe_id": 78, "line": 20},
        ]
        tp, fp, fn = _score_file(findings, expected, ground_truth_vulnerable=True)
        assert (tp, fp, fn) == (2, 0, 0), f"Expected (2,0,0) got ({tp},{fp},{fn})"

    def test_all_fp_on_safe_file(self) -> None:
        findings = [_make_finding(89, 10), _make_finding(78, 20)]
        expected: list[dict] = []
        tp, fp, fn = _score_file(findings, expected, ground_truth_vulnerable=False)
        assert tp == 0
        assert fp == 2
        assert fn == 0

    def test_fp_when_file_not_vulnerable(self) -> None:
        """Findings on a safe file are ALL FPs regardless of expected list."""
        findings = [_make_finding(89, 10)]
        expected = [{"cwe_id": 89, "line": 10}]
        tp, fp, fn = _score_file(findings, expected, ground_truth_vulnerable=False)
        assert tp == 0
        assert fp == 1
        assert fn == 0

    def test_mixed_findings(self) -> None:
        findings = [
            _make_finding(89, 10),   # TP
            _make_finding(78, 50),   # FP — no matching expected
        ]
        expected = [
            {"cwe_id": 89, "line": 10},
            {"cwe_id": 502, "line": 30},  # FN — no matching finding
        ]
        tp, fp, fn = _score_file(findings, expected, ground_truth_vulnerable=True)
        assert tp == 1, f"Expected tp=1 got {tp}"
        assert fp == 1, f"Expected fp=1 got {fp}"
        assert fn == 1, f"Expected fn=1 got {fn}"

    def test_line_window_within_tolerance(self) -> None:
        """Finding within LINE_WINDOW=3 of expected line is a TP."""
        findings = [_make_finding(89, 13)]  # 3 lines from expected 10
        expected = [{"cwe_id": 89, "line": 10}]
        tp, fp, fn = _score_file(findings, expected, ground_truth_vulnerable=True)
        assert tp == 1
        assert fp == 0

    def test_line_window_outside_tolerance(self) -> None:
        """Finding more than LINE_WINDOW from expected is NOT a TP."""
        findings = [_make_finding(89, 14)]  # 4 lines from expected 10
        expected = [{"cwe_id": 89, "line": 10}]
        tp, fp, fn = _score_file(findings, expected, ground_truth_vulnerable=True)
        assert tp == 0
        assert fp == 1
        assert fn == 1

    def test_empty_both(self) -> None:
        tp, fp, fn = _score_file([], [], ground_truth_vulnerable=True)
        assert (tp, fp, fn) == (0, 0, 0)

    def test_empty_findings_with_expected(self) -> None:
        """Scanner found nothing but expected — all FN."""
        tp, fp, fn = _score_file(
            [], [{"cwe_id": 89, "line": 5}], ground_truth_vulnerable=True
        )
        assert tp == 0
        assert fp == 0
        assert fn == 1

    def test_expected_without_line_always_matches_cwe(self) -> None:
        """When expected has no line number, any matching CWE is a TP."""
        findings = [_make_finding(89, 999)]
        expected = [{"cwe_id": 89}]
        tp, fp, fn = _score_file(findings, expected, ground_truth_vulnerable=True)
        assert tp == 1

    def test_each_expected_claimed_once(self) -> None:
        """Multiple findings matching the same expected entry — only one TP."""
        findings = [_make_finding(89, 10), _make_finding(89, 11)]
        expected = [{"cwe_id": 89, "line": 10}]
        tp, fp, fn = _score_file(findings, expected, ground_truth_vulnerable=True)
        assert tp == 1
        assert fp == 1


# ---------------------------------------------------------------------------
# Metric computation tests
# ---------------------------------------------------------------------------


class TestPassMetrics:
    def test_precision_recall_f1(self) -> None:
        """Verify metric formulae are applied correctly."""
        result = PassResult(pass_name="test", tiers_enabled=[])
        result.true_positives = 3
        result.false_positives = 1
        result.false_negatives = 1
        from sanicode.validation.runner import _compute_pass_metrics
        _compute_pass_metrics(result)
        assert result.precision == pytest.approx(0.75, rel=1e-6)
        assert result.recall == pytest.approx(0.75, rel=1e-6)
        assert result.f1 == pytest.approx(0.75, rel=1e-6)

    def test_zero_precision_when_all_fp(self) -> None:
        result = PassResult(pass_name="test", tiers_enabled=[])
        result.true_positives = 0
        result.false_positives = 5
        result.false_negatives = 0
        from sanicode.validation.runner import _compute_pass_metrics
        _compute_pass_metrics(result)
        assert result.precision == pytest.approx(0.0)
        assert result.recall is None
        assert result.f1 is None

    def test_none_metrics_when_all_zero(self) -> None:
        result = PassResult(pass_name="test", tiers_enabled=[])
        from sanicode.validation.runner import _compute_pass_metrics
        _compute_pass_metrics(result)
        assert result.precision is None
        assert result.recall is None
        assert result.f1 is None


# ---------------------------------------------------------------------------
# Delta computation tests
# ---------------------------------------------------------------------------


class TestComputeDelta:
    def test_fp_reduction(self) -> None:
        first = _make_pass("static", tp=10, fp=20, fn=2, f1=0.5)
        last = _make_pass("full", tp=10, fp=10, fn=2, f1=0.7)
        delta = _compute_delta(first, last)
        assert delta["fp_reduction_pct"] == pytest.approx(50.0)

    def test_f1_delta(self) -> None:
        first = _make_pass("static", tp=5, fp=5, fn=5, f1=0.5)
        last = _make_pass("full", tp=7, fp=2, fn=3, f1=0.7)
        delta = _compute_delta(first, last)
        assert delta["f1_delta"] == pytest.approx(0.2)

    def test_zero_fp_reduction(self) -> None:
        first = _make_pass("static", tp=5, fp=0, fn=0)
        last = _make_pass("full", tp=5, fp=0, fn=0)
        delta = _compute_delta(first, last)
        assert delta["fp_reduction_pct"] == pytest.approx(0.0)

    def test_tp_change_pct(self) -> None:
        first = _make_pass("static", tp=10, fp=5, fn=0)
        last = _make_pass("full", tp=12, fp=3, fn=0)
        delta = _compute_delta(first, last)
        assert delta["tp_change_pct"] == pytest.approx(20.0)


# ---------------------------------------------------------------------------
# Minimum bar tests
# ---------------------------------------------------------------------------


class TestCheckMinimumBar:
    def test_fp_reduction_meets_bar(self) -> None:
        result = ValidationResult()
        result.quality_delta = {"fp_reduction_pct": 20.0, "f1_delta": 0.05}
        assert check_minimum_bar(result) is True

    def test_tp_increase_meets_bar(self) -> None:
        result = ValidationResult()
        result.quality_delta = {"fp_reduction_pct": 5.0, "tp_change_pct": 15.0}
        assert check_minimum_bar(result) is True

    def test_below_bar(self) -> None:
        result = ValidationResult()
        result.quality_delta = {"fp_reduction_pct": 10.0, "tp_change_pct": 5.0}
        assert check_minimum_bar(result) is False

    def test_empty_delta_fails(self) -> None:
        result = ValidationResult()
        assert check_minimum_bar(result) is False

    def test_exact_threshold_passes(self) -> None:
        result = ValidationResult()
        result.quality_delta = {"fp_reduction_pct": 15.0}
        assert check_minimum_bar(result) is True


# ---------------------------------------------------------------------------
# Ground truth loading
# ---------------------------------------------------------------------------


class TestLoadGroundTruth:
    def test_load_and_parse(self, tmp_path: Path) -> None:
        data = {
            "fp/file.py": {
                "expected_static_findings": [{"cwe_id": 89, "line": 5, "rule_id": "SC006"}],
                "ground_truth_vulnerable": False,
                "llm_should_filter": True,
                "category": "false_positive",
                "tests_capability": "classify",
            },
            "tp/other.py": {
                "expected_static_findings": [{"cwe_id": 78, "line": 10}],
                "ground_truth_vulnerable": True,
                "llm_should_filter": False,
                "category": "true_positive",
                "tests_capability": "all",
            },
        }
        gt_file = tmp_path / "ground_truth.json"
        gt_file.write_text(json.dumps(data), encoding="utf-8")

        result = load_ground_truth(gt_file)

        assert len(result) == 2
        assert "fp/file.py" in result
        entry = result["fp/file.py"]
        assert entry.ground_truth_vulnerable is False
        assert entry.llm_should_filter is True
        assert entry.category == "false_positive"
        assert entry.expected_findings == [{"cwe_id": 89, "line": 5, "rule_id": "SC006"}]

    def test_missing_optional_fields_default(self, tmp_path: Path) -> None:
        data = {
            "file.py": {
                "expected_static_findings": [],
                "ground_truth_vulnerable": False,
            }
        }
        gt_file = tmp_path / "gt.json"
        gt_file.write_text(json.dumps(data), encoding="utf-8")
        result = load_ground_truth(gt_file)
        entry = result["file.py"]
        assert entry.llm_should_filter is False
        assert entry.category == ""
        assert entry.tests_capability == ""


# ---------------------------------------------------------------------------
# Pass config generation
# ---------------------------------------------------------------------------


class TestMakePassConfig:
    def test_static_blanks_all_tiers(self) -> None:
        base = SanicodeConfig()
        base.llm.fast.model = "fast-model"
        base.llm.analysis.model = "analysis-model"
        base.llm.reasoning.model = "reasoning-model"

        cfg = _make_pass_config(base, enabled_tiers=[])
        assert cfg.llm.fast.model == ""
        assert cfg.llm.analysis.model == ""
        assert cfg.llm.reasoning.model == ""

    def test_classify_keeps_only_fast(self) -> None:
        base = SanicodeConfig()
        base.llm.fast.model = "fast-model"
        base.llm.analysis.model = "analysis-model"
        base.llm.reasoning.model = "reasoning-model"

        cfg = _make_pass_config(base, enabled_tiers=["fast"])
        assert cfg.llm.fast.model == "fast-model"
        assert cfg.llm.analysis.model == ""
        assert cfg.llm.reasoning.model == ""

    def test_does_not_mutate_base(self) -> None:
        base = SanicodeConfig()
        base.llm.fast.model = "fast-model"

        _make_pass_config(base, enabled_tiers=[])
        # Base config must be unchanged.
        assert base.llm.fast.model == "fast-model"

    def test_full_pass_keeps_all_tiers(self) -> None:
        base = SanicodeConfig()
        base.llm.fast.model = "f"
        base.llm.analysis.model = "a"
        base.llm.reasoning.model = "r"

        cfg = _make_pass_config(base, enabled_tiers=["fast", "analysis", "reasoning"])
        assert cfg.llm.fast.model == "f"
        assert cfg.llm.analysis.model == "a"
        assert cfg.llm.reasoning.model == "r"


# ---------------------------------------------------------------------------
# Report formatting
# ---------------------------------------------------------------------------


class TestFormatTable:
    def _sample_result(self) -> ValidationResult:
        result = ValidationResult(corpus_dir="/tmp/corpus", corpus_file_count=10)
        result.passes = [
            _make_pass("static", tp=8, fp=12, fn=2, precision=0.4, recall=0.8, f1=0.533),
            _make_pass("full", tp=8, fp=4, fn=2, precision=0.667, recall=0.8, f1=0.727),
        ]
        result.quality_delta = {"fp_reduction_pct": 66.7, "f1_delta": 0.194}
        return result

    def test_contains_header(self) -> None:
        table = format_table(self._sample_result())
        assert "Pipeline Stage" in table
        assert "Precision" in table
        assert "Recall" in table
        assert "F1" in table

    def test_contains_pass_names(self) -> None:
        table = format_table(self._sample_result())
        assert "static" in table
        assert "full" in table

    def test_contains_metrics(self) -> None:
        table = format_table(self._sample_result())
        assert "0.400" in table or "0.667" in table

    def test_contains_delta(self) -> None:
        table = format_table(self._sample_result())
        assert "66.7%" in table or "Delta" in table

    def test_no_passes_returns_header_only(self) -> None:
        result = ValidationResult()
        table = format_table(result)
        assert "Pipeline Stage" in table


class TestFormatMarkdown:
    def _sample_result(self) -> ValidationResult:
        result = ValidationResult(corpus_dir="/tmp/corpus", corpus_file_count=5)
        result.passes = [
            _make_pass("static", tp=3, fp=5, fn=1, precision=0.375, recall=0.75, f1=0.5),
        ]
        result.quality_delta = {"fp_reduction_pct": 0.0}
        return result

    def test_is_markdown(self) -> None:
        md = format_markdown(self._sample_result())
        assert "# LLM Validation Results" in md
        assert "|" in md

    def test_contains_corpus_info(self) -> None:
        md = format_markdown(self._sample_result())
        assert "/tmp/corpus" in md
        assert "5 files" in md

    def test_contains_pass_row(self) -> None:
        md = format_markdown(self._sample_result())
        assert "static" in md


class TestSaveJson:
    def test_saves_and_loads(self, tmp_path: Path) -> None:
        result = ValidationResult(corpus_dir="/x", corpus_file_count=3)
        result.passes = [
            _make_pass("static", tp=1, fp=2, fn=0)
        ]
        result.quality_delta = {"fp_reduction_pct": 0.0}

        out = tmp_path / "out.json"
        save_json(result, out)

        loaded = json.loads(out.read_text())
        assert loaded["corpus_dir"] == "/x"
        assert loaded["corpus_file_count"] == 3
        assert len(loaded["passes"]) == 1
        assert loaded["passes"][0]["pass_name"] == "static"
