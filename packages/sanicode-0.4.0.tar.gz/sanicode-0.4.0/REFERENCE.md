# Sanicode Development Reference

## The Decision Filter

Every feature, PR, and roadmap item gets tested against one question:

> **Does this make sanicode more valuable to someone who cannot send their code to an external API?**

If the answer is no, it goes to the backlog. If the answer is "it makes us look good on a feature matrix but doesn't serve that user," it gets cut.

---

## Positioning (One Sentence)

Sanicode is the only SAST tool with LLM-powered security reasoning that runs entirely on-premises, produces federal/DoD compliance artifacts, and never sends code off-network.

---

## Why This Position Exists

After stress-testing every claimed differentiator against the market (Feb 2026), the honest finding was:

- The scanner is not differentiated (CodeQL, Semgrep, Bandit are all better at detection)
- The LLM integration is not differentiated as a concept (a dozen funded companies ship LLM+SAST)
- The knowledge graph is not differentiated (CodeQL's queryable DB and Qwiet's CPG are superior)
- The compliance data is narrowly differentiated (free machine-readable ASVS 5.0/NIST/STIG/PCI mapping doesn't exist elsewhere)

What IS structurally differentiated is an architectural gap in the market:

| Competitor | LLM Reasoning | Fully Self-Hosted | Model Class Available | Federal Compliance Artifacts |
|---|---|---|---|---|
| Semgrep Assistant | Yes | **No** (SaaS) | Proprietary (opaque) | No |
| Apiiro AI SAST | Yes | **No** (Cloud) | Proprietary (opaque) | No |
| Corgea | Yes | **No** (Cloud) | Proprietary (opaque) | No |
| ZeroPath | Yes | **No** (Cloud) | Proprietary (opaque) | No |
| Fortify Aviator | Yes | **No** (Fortify on Demand) | Proprietary (opaque) | Partial (STIG/OWASP) |
| SonarQube AI CodeFix | Yes | **No** (Cloud-connected) | Proprietary (opaque) | Enterprise Edition only |
| Datadog Bits AI | Yes | **No** (SaaS) | Proprietary (opaque) | No |
| CodeQL | No native LLM | Yes (CLI) | N/A | CWE only |
| Bandit | No | Yes | N/A | No |
| **Sanicode** | **Yes** | **Yes** (Ollama/vLLM/OpenShift AI) | **User's choice: 8B → 400B+ MoE** | **Yes** (STIG/NIST/ASVS/PCI) |

Every AI-powered SAST competitor requires sending code or analysis context to an external service — and locks users into whatever model the vendor chose. Sanicode is the only entry that combines LLM reasoning with fully air-gapped operation, operator-selected models (up to frontier-class 120B dense / 400B MoE), and compliance output for federal frameworks.

This inverts the usual dynamic. Normally, cloud services have better AI than on-prem tools. With open-weight frontier models (GPT-OSS-120B, Llama 4 Maverick, DeepSeek-R1), a well-resourced air-gapped environment can now match or exceed cloud AI quality. Sanicode is the pipeline that makes this possible for SAST. It's not a better mousetrap — it's a mousetrap that works in a room the other mousetraps can't enter, powered by an engine the operator controls.

---

## Target Users

**Primary: DoD Software Factories & Defense Contractors**

These are teams building on Platform One, Party Bus, Black Pearl, or custom software factories. They operate at IL4-IL6, often on OpenShift in disconnected or semi-connected environments. They need:

- SAST in CI/CD pipelines (Tekton, GitLab CI on-prem)
- Compliance evidence for continuous ATO (cATO)
- STIG findings mapped to ASD STIG v4r11 checklist items
- Tools available as hardened containers (ideally Iron Bank-approved)
- Zero external API calls from classified enclaves

Languages they write: Java (enterprise backends, Spring Boot), Python (data science, ML, automation), JavaScript/TypeScript (web frontends, React), Go (Kubernetes operators, CLI tools), and some C/C++ (embedded, legacy).

**Secondary: Federal Civilian Agencies Under FedRAMP/FISMA**

Similar constraints but less extreme. They need NIST 800-53 control mapping, may operate in FedRAMP-authorized cloud environments (AWS GovCloud, Azure Gov), and want compliance artifacts for their System Security Plans (SSPs). More likely to tolerate FedRAMP-authorized SaaS, but prefer on-prem for security tooling that touches source code.

**Tertiary: EU Sovereignty-Regulated Organizations**

GDPR and emerging EU sovereignty regulations create environments where sending source code to US-based cloud services is a legal risk. Organizations in defense, critical infrastructure, and government across EU member states face similar air-gapped or data-residency constraints. They need tools that run entirely within their jurisdiction.

---

## What We Must Prove First

The entire positioning rests on one unproven claim: **the LLM integration actually improves scan quality.** If it doesn't, sanicode is just a weaker Bandit with extra JSON files.

### Gate 0: LLM Validation (Do This Before Anything Else)

1. Run sanicode against a known benchmark (OWASP Benchmark Java subset adapted for Python, or a curated vulnerable app set)
2. Measure precision/recall/F1 in pattern-only mode (no LLM)
3. Measure precision/recall/F1 across a tiered model ladder — this is key because our target environments can host serious hardware:

| Tier | Example Models | Typical Hardware | Use Case |
|---|---|---|---|
| Small (≤14B) | Granite 3.1 8B, Llama 3.1 8B | 1x A100/H100, or CPU-only (llama.cpp) | Resource-constrained enclaves, edge deployments |
| Medium (14B–70B) | Granite 3.3 70B, Llama 3.3 70B, Qwen 2.5 72B | 2-4x A100/H100 | Standard DoD software factory GPU allocation |
| Large (70B+) | GPT-OSS-120B (dense 120B), Llama 4 Maverick (400B MoE), DeepSeek-R1 | 4-8x H100, multi-node | Well-resourced program offices, dedicated AI/ML infrastructure |

4. Publish the delta at each tier. The results table should show the quality curve: what do you gain going from pattern-only → 8B → 70B → 120B+ → 400B MoE?

This is a significant competitive advantage that the reference doc previously undersold. DoD and IC environments increasingly have substantial GPU infrastructure (JEDI/JWCC, GovCloud GPU instances, on-prem DGX systems). The assumption that air-gapped means resource-constrained is outdated. Many classified enclaves have more GPU capacity than commercial startups — they just can't connect to the internet.

This means sanicode's LLM reasoning quality ceiling is not limited to what a small model can do. A DoD software factory running Llama 4 Maverick on a DGX node behind an air gap gets frontier-class security reasoning that no cloud SAST vendor can match in that environment — because the cloud vendors literally cannot reach it.

**Minimum bar:** LLM reasoning must reduce false positives by ≥15% OR increase true positive rate by ≥10% on the benchmark at the Small tier (8B, single GPU). This is the floor. The expectation is that Medium and Large tier models will deliver substantially better results — and documenting that curve is itself a selling point.

**Stretch goal:** At the Large tier (120B+ / Maverick), demonstrate reasoning quality competitive with cloud-based AI-SAST services (Semgrep Assistant, Apiiro) that use proprietary frontier models. If a self-hosted Maverick or GPT-OSS-120B matches or approaches GPT-4-class reasoning on security findings, that's the entire pitch: *you get cloud-grade AI-SAST quality without cloud connectivity.*

---

## Development Priorities

### P0 — Existential (Without These, the Positioning Is Fiction)

**P0.1: Prove LLM integration works (Gate 0 above)**
- Create or curate a benchmark of 50-100 Python findings (mix of true/false positives)
- Run with and without LLM across the model ladder: Granite 8B → Llama 70B → GPT-OSS-120B / Maverick
- Publish results as a quality curve showing the precision/recall delta at each tier
- Include cost-performance analysis: what quality improvement does each step up the ladder buy, and what GPU resources does it require?
- Results go in repo README and as a reproducible `sanicode score` run
- Timeline: This blocks everything. Nothing else matters until this is done.

**P0.2: Disconnected OpenShift deployment that actually works**
- Helm chart must deploy on OpenShift 4.14+ in disconnected mode
- vLLM serving with configurable model and tensor parallelism:
  - Single GPU: Granite 8B (minimum viable)
  - Multi-GPU: Llama 70B, GPT-OSS-120B, Maverick (production-grade reasoning)
  - CPU-only: llama.cpp with 8B quantized (degraded but functional)
- Sanicode scanner + API server as a separate pod
- Model selection is a Helm values.yaml parameter, not a code change
- Tekton pipeline integration example (scan on PR, gate on severity)
- Test this on a real disconnected cluster, not just `kind` or `minikube`

**P0.3: STIG checklist output**
- Current state: findings have STIG metadata (CAT level, STIG ID) in JSON
- Needed: actual DISA STIG Checklist (.ckl) file generation, or at minimum a tabular report that maps directly to ASD STIG v4r11 checklist items
- A STIG assessor should be able to take sanicode output and directly populate their STIG Viewer entries
- Include: finding ID, CWE, STIG rule ID, CAT level, status (Open/Not a Finding/Not Applicable), supporting evidence (code location, taint path), remediation timeline

### P1 — Market Fit (Needed for Target Users to Adopt)

**P1.1: Java language support**
- This is the single most important language gap for the target market
- DoD backends are overwhelmingly Java (Spring Boot, Quarkus on OpenShift)
- Minimum viable: SQL injection, command injection, path traversal, XSS, deserialization, hardcoded credentials, XXE (CWE-611) — the OWASP Top 10 patterns
- Taint analysis must work for Java (tree-sitter-java is available)
- 10-15 rules targeting Spring Boot / Jakarta EE patterns specifically

**P1.2: SARIF ingestion for compliance enrichment**
- Accept SARIF output from Bandit, Semgrep, CodeQL, or any SAST tool
- Map their CWE findings through sanicode's compliance database
- Output: enriched SARIF with STIG/NIST/ASVS/PCI cross-references added
- Even if teams keep their existing scanner, sanicode adds the compliance layer they don't have
- Command: `sanicode enrich input.sarif --output enriched.sarif`

**P1.3: Expand compliance database to 100+ CWEs**
- Current 54 CWEs are thin for production use
- Priority additions: CWEs that appear in ASD STIG v4r11 and NIST 800-53 SI/SC control families
- Add: CMMC 2.0 mapping (required for defense contractors as of 2025)
- Add: FedRAMP control mapping (maps to NIST 800-53 but with FedRAMP-specific baselines)
- Each CWE entry must have: STIG rule IDs, NIST controls, ASVS requirements, PCI DSS requirements, remediation guidance, severity derived from STIG CAT

**P1.4: POA&M entry generation**
- Plan of Action and Milestones is a required artifact for every federal ATO
- Given scan findings, generate POA&M entries with: weakness description, point of contact placeholder, scheduled completion date (derived from CAT level: CAT I = 30 days, CAT II = 90 days, CAT III = 180 days), milestones with completion dates, source identifying vulnerability (sanicode scan), status
- Output: CSV or XLSX that can be imported into eMASS or XACTA
- This is an artifact nobody else auto-generates from SAST output

### P2 — Deepening (Strengthens Position After P0/P1)

**P2.1: Go language support**
- Kubernetes operators, CLI tools, infrastructure code
- Second most important language for the target market after Java
- Focus on: SQL injection, command injection, path traversal, hardcoded credentials, insecure TLS configuration

**P2.2: FIPS-aware configuration**
- Document which components need FIPS-validated crypto (hint: probably none for a SAST tool, but the deployment guide should address it)
- Ensure the container image uses FIPS-compliant base (Red Hat UBI with FIPS modules)
- vLLM / Ollama FIPS considerations documented
- This is mostly documentation, not code, but federal buyers ask about it

**P2.3: Iron Bank container image**
- DoD software factories pull containers from Iron Bank (repo1.dso.mil)
- Submitting sanicode's container image to Iron Bank means it passes DISA hardening requirements
- This is the distribution channel for the target market — if you're not in Iron Bank, you don't exist for many DoD teams

**P2.4: System Security Plan (SSP) evidence generation**
- Given a scan of a codebase, produce a section suitable for inclusion in an SSP
- Maps to NIST 800-53 controls: SI-10 (Input Validation), SI-15 (Information Output Filtering), SC-7 (Boundary Protection), SC-28 (Protection of Information at Rest)
- Shows which controls are addressed by the codebase and which have open findings
- Format: Markdown or OSCAL JSON (NIST's machine-readable SSP format)

**P2.5: Field sensitivity in taint analysis**
- Distinguish `request.args.get("user_id")` from `request.args.get("page")`
- Reduces false positives, which matters more in the LLM pipeline (cleaner input = better LLM reasoning)
- Lower priority than language expansion but improves scan quality

---

## What We Explicitly Deprioritize

These are things that feel productive but don't serve the positioning. Resist the pull.

| Item | Why It's Deprioritized |
|---|---|
| PHP language depth | DoD/federal shops don't write PHP. The 5 existing PHP rules are sufficient for demos. |
| Building Python rules that duplicate Bandit | Bandit is an optional integrated scanner (`--with bandit`). We write tree-sitter rules only for compliance-specific patterns Bandit doesn't cover. |
| Building a Semgrep-class rule DSL | Opengrep gives us the full Semgrep-compatible rule engine via integration. Our YAML CallRule format is sufficient for sanicode-specific compliance rules. |
| VS Code / IDE extension | Our users run scans in CI/CD pipelines on OpenShift, not in VS Code on their laptops. |
| Cytoscape.js graph visualization polish | A demo feature. Nobody in our target market makes security decisions by staring at a force-directed graph. |
| Community rule repository / marketplace | We don't have a community yet, and the target market doesn't contribute rules to public repos (they're writing classified code). |
| Broad OSS adoption metrics (stars, forks) | Our target users evaluate tools through DISA/NIST compliance checklists and internal pilots, not GitHub stars. |
| HIPAA / SOC 2 / ISO 27001 mapping | These are healthcare/commercial compliance frameworks. Our target market cares about STIG, NIST 800-53, CMMC, and FedRAMP. |
| C/C++ language support | Important for embedded DoD systems but extremely hard to do well with tree-sitter (no type system, preprocessor complexity). Java and Go deliver more value per effort. |

---

## Language Priority (Reordered for Target Market)

| Priority | Language | Why | Status |
|---|---|---|---|
| **Exists** | Python | Automation, ML/AI workloads, scripting | 10 rules, taint analysis working |
| **Exists** | JavaScript/TypeScript | Web frontends | 6 rules |
| **P1** | **Java** | **DoD enterprise backends (Spring Boot, Quarkus, Jakarta EE)** | **Not started — critical gap** |
| **P2** | **Go** | **Kubernetes operators, CLI tools, infrastructure** | **Not started** |
| Deprioritized | PHP | Not relevant for target market | 5 rules, sufficient |
| Deprioritized | C/C++ | Important but too hard to do well quickly | Not started |

---

## Compliance Framework Priority (Reordered for Target Market)

| Priority | Framework | Why | Status |
|---|---|---|---|
| **P0** | ASD STIG v4r11 | Required for DoD ATO. Must produce checklist-ready output. | Mapping exists, checklist output needed |
| **P0** | NIST 800-53 Rev 5 | Foundation of FedRAMP, FISMA, and CMMC. | Control IDs mapped, need expansion |
| **P1** | CMMC 2.0 | Required for all defense contractors handling CUI as of 2025. | **Not started — needed** |
| **P1** | FedRAMP Baselines | NIST 800-53 subset for cloud. Federal civilian agencies. | **Not started — maps from NIST 800-53** |
| Exists | OWASP ASVS 5.0 | Valuable for web app assessments. | Mapped |
| Exists | PCI DSS 4.0 | Relevant if target code handles payment data. | Mapped |
| Deprioritized | HIPAA | Healthcare, not our primary market. | Not started |
| Deprioritized | SOC 2 | Commercial SaaS compliance. | Not started |

---

## Deployment Architecture (Target State)

```
┌──────────────────────────────────────────────────────────┐
│              Disconnected OpenShift Cluster                │
│                                                            │
│  ┌─────────────────────────────┐                          │
│  │  vLLM Model Serving Pod(s)  │  Deployment options:     │
│  │                             │  • 1x GPU:  Granite 8B   │
│  │  InferenceService or        │  • 2-4x GPU: Llama 70B  │
│  │  plain Deployment           │  • 4-8x GPU: Maverick,  │
│  │  (tensor-parallel across    │    GPT-OSS-120B          │
│  │   available GPUs)           │  • CPU-only: llama.cpp   │
│  │                             │    (8B quantized, slow)  │
│  └──────────┬──────────────────┘                          │
│             │ OpenAI-compatible API (:8000)                │
│  ┌──────────▼──────────────────────────────────────────┐  │
│  │  Sanicode API Pod                                    │  │
│  │  FastAPI :8080                                       │  │
│  │  Orchestrator: built-in scanner + optional Opengrep  │  │
│  │  + detect-secrets + Grype → SARIF merge →            │  │
│  │  compliance enrichment → LLM reasoning (LiteLLM)     │  │
│  └──────────┬──────────────────────────────────────────┘  │
│             │                                              │
│  ┌──────────▼──────────────────────────────────────────┐  │
│  │  Tekton Pipeline                                     │  │
│  │  1. git-clone                                        │  │
│  │  2. sanicode scan --format sarif  (reads sanicode.toml│  │
│  │     for --with scanners, or pass explicitly)         │  │
│  │  3. sanicode enrich (if external SARIF also present) │  │
│  │  4. quality gate (fail on CAT I findings)            │  │
│  │  5. sanicode report --poam --stig-checklist          │  │
│  │  6. archive compliance artifacts to artifact store   │  │
│  └─────────────────────────────────────────────────────┘  │
│                                                            │
│  Network boundary: NOTHING leaves this cluster             │
│                                                            │
│  ┌─────────────────────────────────────────────────────┐  │
│  │  Config (sanicode.toml)                              │  │
│  │  [llm]                                               │  │
│  │  provider = "vllm"                                   │  │
│  │  base_url = "http://vllm-svc:8000/v1"               │  │
│  │  model = "ibm-granite/granite-3.1-8b-instruct"      │  │
│  │  # or: meta-llama/Llama-4-Maverick-17B-128E         │  │
│  │  # or: microsoft/gpt-oss-120b                       │  │
│  │  # Model choice is a deployment decision, not code   │  │
│  └─────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
```

Key requirements:
- Container images mirrored to internal registry (no pull from internet)
- Model weights pre-loaded into PVC (no download at runtime)
- All compliance data bundled in the container image
- vLLM serving with tensor parallelism for multi-GPU inference (Maverick, GPT-OSS-120B)
- Model choice is a deployment-time configuration decision, not a code change — sanicode talks to an OpenAI-compatible API and doesn't care what's behind it
- CPU-only fallback mode via llama.cpp for enclaves without GPUs (8B quantized, degraded quality accepted)
- Red Hat UBI 9 base image (FIPS-capable)

---

## Scanner Architecture: Orchestrate, Don't Reinvent

*Decision made Feb 2026 after competitive stress test and tooling landscape research.*

Sanicode is an **orchestrator with its own baseline scanner**, not a monolithic scanning engine. The core insight: building a scanner that competes with Bandit (46 rules), Semgrep (thousands of rules), or CodeQL (world-class taint analysis) is a multi-year effort that doesn't serve our positioning. What differentiates sanicode is compliance enrichment, LLM reasoning, and air-gapped operation — not detection breadth.

### The principle: always works alone, better with friends

`sanicode scan` must always produce useful output with zero external dependencies. Our tree-sitter scanner, taint analysis, and compliance mapping are the baseline that works everywhere, including environments where installing additional tools is impossible. External scanners are optional enhancers that add breadth.

```
sanicode scan                          # baseline: our tree-sitter rules + taint + compliance
sanicode scan --with opengrep          # + Opengrep's multi-language rules
sanicode scan --with detect-secrets    # + secrets scanning (28 detectors)
sanicode scan --with grype             # + dependency vulnerability scanning
sanicode scan --with opengrep,grype    # combine multiple
sanicode enrich bandit-output.sarif    # enrich any external SARIF with compliance metadata
```

### Integration boundaries

Each external scanner is invoked via **subprocess** and communicates via **SARIF**. No library imports, no API coupling, no shared state. If an external scanner is unavailable, sanicode logs a warning and continues with what it has.

| Scanner | License | What it adds | Integration |
|---------|---------|-------------|-------------|
| **Sanicode (built-in)** | Apache-2.0 | Compliance-specific tree-sitter rules, taint analysis, LLM reasoning | Always available |
| **Opengrep** | LGPL-2.1 | 30+ language support, intra-procedural taint, thousands of community rules | Optional, subprocess + SARIF |
| **detect-secrets** | Apache-2.0 | 28 secret pattern detectors, language-agnostic | Optional, Python API or subprocess |
| **Grype** | Apache-2.0 | Dependency vulnerability scanning against OSV/NVD | Optional, subprocess + SARIF (Go binary) |
| **Bandit** | Apache-2.0 | 46 Python-specific rules | Optional, subprocess + SARIF |

### What we build vs. what we delegate

**We build and maintain:**
- Tree-sitter rules for compliance-specific patterns no upstream tool covers (ASVS 5.0 checks, STIG-derived patterns)
- Our own taint analysis engine (reaching-definitions, with field sensitivity on the roadmap) — needed because the LLM reasoning pipeline requires access to taint graph internals, not just findings
- SARIF merge and compliance enrichment layer
- LLM reasoning pipeline (false-positive reduction, remediation guidance, taint path assessment)
- All compliance output formats (STIG checklist, POA&M, SARIF with taxonomies)

**We delegate to upstream tools:**
- Broad pattern-matching detection across many languages (Opengrep)
- Secrets scanning (detect-secrets)
- Dependency vulnerability scanning (Grype)
- General Python SAST patterns already covered by Bandit

**We deprioritize but don't rule out:**
- Building detection rules that duplicate what upstream tools already cover well
- If a compliance-specific gap exists that no upstream tool addresses, we add a tree-sitter rule for it

### Why Opengrep, not Semgrep

Semgrep's engine (LGPL-2.1) is technically usable, but their community rules were relicensed in Dec 2024 to the Semgrep Rules License v1.0, which restricts redistribution in competing products. Opengrep (forked Jan 2025 by Aikido, Jit, Amplify, Endor Labs, Orca) uses the same engine and rule format under LGPL, with a commitment to open rules.

Risk: Opengrep is young (est. Jan 2025). The loose coupling via subprocess + SARIF mitigates this — if Opengrep stalls, sanicode's baseline scanner still works, and we can swap in any other SARIF-producing tool.

### Coupling risk mitigation

The loose-coupling architecture is specifically designed so that **no external scanner is load-bearing**:
- Sanicode's test suite must pass with no external scanners installed
- The compliance enrichment layer works on any SARIF input, not just sanicode's own output
- External scanner integration is behind feature flags in `sanicode.toml`, not hardcoded
- We never stop investing in our own tree-sitter rules for compliance-specific detection

---

## Definition of "Good Enough" Scanner Quality

The scanner is NOT the product. The scanner is the vehicle that delivers compliance artifacts and LLM-enhanced reasoning. It needs to be credible, not best-in-class.

This bar applies to the **combined pipeline output** (built-in scanner + optional Opengrep/Bandit/detect-secrets), not just the built-in scanner alone. Without optional scanners, the built-in scanner must still clear the "doesn't embarrass itself" bar. With them, the combined output should be competitive with any single-tool SAST solution.

**Good enough means:**
- Finds the OWASP Top 10 vulnerability classes (injection, XSS, broken auth patterns, etc.) in the supported languages
- Taint analysis traces source→sink for the common web framework patterns (Flask, Django, Express, Spring Boot)
- False positive rate is acceptable when combined with LLM filtering (target: <30% FP rate after LLM triage)
- Produces valid SARIF output that other tools can consume
- Doesn't miss obvious, textbook vulnerabilities that would embarrass the tool in a pilot

**Good enough does NOT mean:**
- Catching every subtle vulnerability that CodeQL or Fortify would find
- Duplicating rules that Opengrep or Bandit already cover well
- Supporting every framework variant or library
- Zero false positives

The quality bar is: "Would a security engineer at a DoD software factory look at these results and say 'this is useful, even if I also run Semgrep'?" If yes, good enough.

---

## Key Milestones

| Milestone | Gate | What It Proves |
|---|---|---|
| **M0: LLM Validation** | Published benchmark with quality curve across model ladder (8B → 70B → 120B+ → Maverick) | The core thesis is real; operators can make informed model-vs-hardware tradeoffs |
| **M1: Disconnected Deploy** | Helm chart deploys on disconnected OpenShift with vLLM, tested at 8B (single GPU) and 70B+ (multi-GPU) | The air-gapped claim is real, and scales to frontier models |
| **M2: STIG Checklist Output** | Scan produces .ckl or tabular output a STIG assessor can use | The compliance artifact claim is real, not just JSON metadata |
| **M3: SARIF Enrichment** | `sanicode enrich` takes Bandit/Semgrep SARIF and adds compliance cross-refs | Sanicode works WITH existing tools, not instead of them |
| **M4: Java Support** | 10+ rules for Spring Boot with taint analysis | The target market's primary language is covered |
| **M5: POA&M Generation** | Scan findings produce importable POA&M entries | A compliance artifact nobody else auto-generates |
| **M6: Iron Bank Submission** | Container image submitted to repo1.dso.mil | The distribution channel for the target market |

Milestones M0-M2 are credibility gates. If any of them fails, the positioning needs to be revisited. M3-M6 are growth milestones that expand the addressable market within the position.

---

## What Success Looks Like

**In 6 months:** Sanicode has published benchmark results showing LLM reasoning quality across the model ladder (8B → 70B → 120B+). A Helm chart deploys it on disconnected OpenShift with vLLM serving operator-selected models. It produces STIG checklist output and POA&M entries. One DoD software factory has piloted it.

**In 12 months:** Java support is shipping. SARIF enrichment lets teams add compliance metadata to their existing Bandit/Semgrep/CodeQL output. The container image is in Iron Bank. Three DoD or federal teams use it in their CI/CD pipelines. At least one deployment runs a 70B+ model, demonstrating cloud-grade AI-SAST quality behind an air gap.

**What failure looks like:** The LLM integration doesn't measurably improve scan quality even with large models. The compliance artifacts are nice JSON but nobody actually uses them in an ATO package. The scanner quality is too low for security engineers to take seriously. We become a demo project that looks impressive in slides but nobody deploys.

The difference between success and failure is whether the artifacts this tool produces end up in real ATO packages, or just in conference talks.