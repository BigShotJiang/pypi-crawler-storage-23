<!-- mcp-name: com.olane/copass-local -->

# olane-copass-local

**Copass Local** — local encryption MCP plugin for [Copass / Twin Brain](https://olane.com). Runs on the user's machine via stdio transport — **keys never leave the local environment**.

Part of the **Olane** MCP suite (`com.olane/*`):
- **`com.olane/copass-local`** (this package) — Local encryption and session token generation
- **`com.olane/copass-remote`** — Knowledge graph ontology and context retrieval

## Tools

| Tool | Description |
|------|-------------|
| `generate_session_token` | Wrap DEK with access-token-derived key to produce an opaque session token |
| `encrypt_payload` | AES-256-GCM encrypt a text payload |
| `encrypt_file` | AES-256-GCM encrypt a file's contents |
| `setup_project` | Write hooks, scripts, config, and merge settings for a project |
| `update_auth_token` | Persist a fresh auth token to `.olane/config.json` |
| `set_copass_encryption_key` | Write a user-provided master key (migration/team sharing) |

## Installation

From PyPI:

```bash
pip install olane-copass-local
```

From source:

```bash
pip install -e .
```

## Configuration

### Claude Desktop / Claude Code

Add to your MCP settings:

```json
{
  "mcpServers": {
    "copass-local": {
      "command": "olane-copass-local",
      "transport": "stdio"
    }
  }
}
```

### VS Code (Copilot MCP)

Add to `.vscode/mcp.json`:

```json
{
  "servers": {
    "copass-local": {
      "command": "olane-copass-local",
      "transport": "stdio"
    }
  }
}
```

## Usage

The Copass Ontology MCP (remote) orchestrates calls to this local plugin:

1. **`generate_session_token`** — Called at session start with `master_key` and `access_token`. Returns an opaque session token.
2. **`encrypt_payload`** / **`encrypt_file`** — Called before each API request to encrypt data with AES-256-GCM.
3. The session token and encrypted payloads are forwarded to the Twin-Brain API.

## Development

```bash
# Install in editable mode
pip install -e .

# Run tests
pytest tests/ -v

# Run the server directly (waits for JSON-RPC on stdin)
python -m olane_copass_local
```

