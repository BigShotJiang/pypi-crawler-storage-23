"""Allow running as `python -m olane_copass_local`."""

from olane_copass_local.server import main

main()
