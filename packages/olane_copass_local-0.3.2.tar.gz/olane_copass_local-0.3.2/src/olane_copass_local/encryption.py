"""AES-256-GCM encryption helper."""

import base64
import os

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


def _encrypt_aes_gcm(plaintext: str, dek: bytes) -> dict:
    """Encrypt plaintext with AES-256-GCM, returning base64-encoded fields."""
    aesgcm = AESGCM(dek)
    iv = os.urandom(12)
    ciphertext_with_tag = aesgcm.encrypt(iv, plaintext.encode("utf-8"), None)
    ciphertext = ciphertext_with_tag[:-16]
    tag = ciphertext_with_tag[-16:]

    return {
        "encrypted_text": base64.b64encode(ciphertext).decode("ascii"),
        "encryption_iv": base64.b64encode(iv).decode("ascii"),
        "encryption_tag": base64.b64encode(tag).decode("ascii"),
    }
