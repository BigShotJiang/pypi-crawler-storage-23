"""
Shared cryptographic constants for session token wrapping and DEK derivation.

These values MUST match the server-side constants in frame_graph/crypto_constants.py
and the DEK derivation constants in olane_crypto.py. Any change here will break
session token wrapping/unwrapping.
"""

# Session token wrapping (access-token → wrap key)
WRAP_HKDF_SALT = b"olane-session-wrap-v1"
WRAP_HKDF_INFO = b"olane-wrap"

# DEK derivation (master key → data encryption key)
DEK_HKDF_SALT = b"olane-twin-brain-dek-v1"
DEK_HKDF_INFO = b"olane-dek"
