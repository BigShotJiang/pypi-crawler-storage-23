"""Project setup logic for Copass.

Writes hook scripts, indexing scripts, config, and merges settings into
.claude/settings.local.json. Runs locally via copass-local (stdio) — no
network calls needed.
"""

import json
import logging
import os
import re
import stat
from pathlib import Path

from olane_copass_local.config_project import ProjectConfig

logger = logging.getLogger(__name__)

SUPPORTED_AGENT_TYPES = {"claude_code"}

# Resolve template directory relative to this file
_TEMPLATES_DIR = Path(__file__).parent / "templates"


def _strip_claude_section(project_path: str) -> bool:
    """Remove existing <!-- Copass:START --> ... <!-- Copass:END --> block from CLAUDE.md.

    Returns True if a section was found and removed, False otherwise.
    """
    claude_md = Path(project_path) / "CLAUDE.md"
    if not claude_md.exists():
        return False

    content = claude_md.read_text(encoding="utf-8")
    pattern = r"\n*<!-- Copass:START -->.*?<!-- Copass:END -->\n*"
    new_content = re.sub(pattern, "\n", content, flags=re.DOTALL)

    if new_content == content:
        return False

    claude_md.write_text(new_content.rstrip() + "\n", encoding="utf-8")
    return True


def _merge_settings_hooks(project_path: str, settings_hooks: dict) -> None:
    """Merge settings_hooks into .claude/settings.local.json."""
    settings_dir = Path(project_path) / ".claude"
    settings_file = settings_dir / "settings.local.json"

    settings_dir.mkdir(parents=True, exist_ok=True)

    existing = {}
    if settings_file.exists():
        try:
            existing = json.loads(settings_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            existing = {}

    # Deep merge hooks: for each event type, append new hooks that aren't already present
    existing_hooks = existing.get("hooks", {})
    new_hooks = settings_hooks.get("hooks", {})

    for event_type, matchers in new_hooks.items():
        if event_type not in existing_hooks:
            existing_hooks[event_type] = matchers
        else:
            # Check if the hook command already exists to avoid duplicates
            existing_commands = set()
            for matcher in existing_hooks[event_type]:
                for hook in matcher.get("hooks", []):
                    existing_commands.add(hook.get("command", ""))

            for matcher in matchers:
                for hook in matcher.get("hooks", []):
                    if hook.get("command", "") not in existing_commands:
                        existing_hooks[event_type].append(matcher)
                        break

    existing["hooks"] = existing_hooks
    settings_file.write_text(json.dumps(existing, indent=2) + "\n", encoding="utf-8")


def write_setup_files(
    project_path: str,
    agent_type: str,
    user_id: str,
    api_url: str = None,
    auth_token: str = None,
    copass_encryption_key: str = None,
) -> dict:
    """Write all Copass setup files to the project.

    Creates hooks, scripts, config, and merges settings_hooks into
    .claude/settings.local.json. Strips any legacy Copass section from CLAUDE.md.

    Args:
        project_path: Absolute path to the project root directory.
        agent_type: Type of coding agent (e.g. "claude_code").
        user_id: Authenticated user ID.
        api_url: API URL (defaults to OLANE_API_URL env or http://localhost:8000).
        auth_token: Optional OAuth access token to store in config.
        copass_encryption_key: Optional master key to store in config.

    Returns:
        Dict with success, files_written (list of relative paths), and instructions.
    """
    if agent_type not in SUPPORTED_AGENT_TYPES:
        return {
            "success": False,
            "error": f"Unsupported agent_type: {agent_type}. Supported: {sorted(SUPPORTED_AGENT_TYPES)}",
        }

    project = Path(project_path)
    if not project.is_dir():
        return {
            "success": False,
            "error": f"project_path does not exist or is not a directory: {project_path}",
        }

    files_written = []
    effective_api_url = api_url or os.environ.get("OLANE_API_URL", "https://ai.copass.id")

    # ── Write hook scripts ──────────────────────────────────────────
    hooks_src = _TEMPLATES_DIR / agent_type / "hooks"
    hooks_dst = project / ".olane" / "hooks"
    hooks_dst.mkdir(parents=True, exist_ok=True)

    for hook_name in ("_common.sh", "post_tool_use.sh", "notification.sh", "stop.sh"):
        src = hooks_src / hook_name
        if not src.exists():
            return {"success": False, "error": f"Missing template: {hook_name}"}
        dst = hooks_dst / hook_name
        dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
        # Make executable
        dst.chmod(dst.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        files_written.append(f".olane/hooks/{hook_name}")

    # ── Write scripts ───────────────────────────────────────────────
    scripts_src = _TEMPLATES_DIR / agent_type / "scripts"
    scripts_dst = project / ".olane" / "scripts"
    scripts_dst.mkdir(parents=True, exist_ok=True)

    for script_name in ("index_project.py", "olane_crypto.py"):
        src = scripts_src / script_name
        if src.exists():
            dst = scripts_dst / script_name
            dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
            dst.chmod(dst.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
            files_written.append(f".olane/scripts/{script_name}")

    # ── Write .olane/config.json ────────────────────────────────────
    config_path = project / ".olane" / "config.json"
    existing_config = {}
    if config_path.exists():
        try:
            existing_config = json.loads(config_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            existing_config = {}

    # Start from defaults, merge existing, then overlay new values
    config_obj = ProjectConfig().model_dump()
    config_obj.update(existing_config)
    config_obj["api_url"] = effective_api_url
    config_obj["user_id"] = user_id
    if auth_token:
        config_obj["auth_token"] = auth_token
    if copass_encryption_key:
        config_obj["copass_encryption_key"] = copass_encryption_key

    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(config_obj, indent=2) + "\n", encoding="utf-8")
    files_written.append(".olane/config.json")

    # ── Merge settings_hooks into .claude/settings.local.json ───────
    settings_hooks_path = _TEMPLATES_DIR / agent_type / "settings_hooks.json"
    if settings_hooks_path.exists():
        settings_hooks = json.loads(settings_hooks_path.read_text(encoding="utf-8"))
        _merge_settings_hooks(project_path, settings_hooks)
        files_written.append(".claude/settings.local.json")

    # ── Strip legacy Copass section from CLAUDE.md (if present) ─────
    if _strip_claude_section(project_path):
        files_written.append("CLAUDE.md")

    # ── Create logs directory ───────────────────────────────────────
    logs_dir = project / ".olane" / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    return {
        "success": True,
        "files_written": files_written,
        "instructions": (
            "Copass setup complete. Next steps:\n"
            "1. Hooks require 'jq' for JSON parsing. Install via: brew install jq / apt-get install jq\n"
            "2. Run initial project index: python .olane/scripts/index_project.py --mode full\n"
            "   Options: --max-files N, --patterns '**/*.py', --dry-run, --verbose"
        ),
    }
