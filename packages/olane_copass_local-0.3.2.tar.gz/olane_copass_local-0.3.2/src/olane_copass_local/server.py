"""
Copass Security MCP Server -- local-only encryption and setup tools.

Runs on the user's machine via stdio transport. Provides 6 tools:

Encryption:
1. generate_session_token -- Wraps DEK with access-token-derived key (auto-provisions master key)
2. encrypt_payload -- AES-256-GCM encrypts text
3. encrypt_file -- AES-256-GCM encrypts file contents

Setup & Key Management:
4. setup_project -- Write hooks, scripts, config, and merge settings
5. set_copass_encryption_key -- Write a user-provided master key (migration/team sharing)
6. update_auth_token -- Silently persist a fresh auth token to config

The master key is auto-provisioned on first crypto tool use via ensure_copass_encryption_key().
If no key exists in COPASS_ENCRYPTION_KEY env var or .olane/config.json, a new UUID4
key is generated and written to config automatically.
"""

import base64
import json
import logging
import os
import tempfile
from typing import Optional

from fastmcp import FastMCP

from olane_copass_local.session_token import create_session_token, _derive_dek
from olane_copass_local.encryption import _encrypt_aes_gcm

logger = logging.getLogger(__name__)


# =========================================================================
# Master Key Auto-Provisioning
# =========================================================================

# Cached master key and DEK (populated lazily by _ensure_dek)
_copass_encryption_key: Optional[str] = None
_dek: Optional[bytes] = None


def _ensure_dek() -> None:
    """Ensure master key and DEK are available, auto-provisioning if needed.

    Calls ensure_copass_encryption_key() which will:
    1. Use COPASS_ENCRYPTION_KEY env var if set
    2. Use existing .olane/config.json copass_encryption_key if present
    3. Auto-generate a new UUID4 key and write to config

    After this call, _copass_encryption_key and _dek are guaranteed non-None.
    """
    global _copass_encryption_key, _dek
    if _dek is not None:
        return

    from olane_copass_local.copass_encryption_key import ensure_copass_encryption_key

    result = ensure_copass_encryption_key(os.getcwd())
    _copass_encryption_key = result["copass_encryption_key"]
    _dek = _derive_dek(_copass_encryption_key)
    if result["generated"]:
        logger.info("Auto-provisioned master key and derived DEK")
    else:
        logger.info(f"Master key loaded from {result['source']}, DEK derived")


def _reload_key() -> None:
    """Force reload master key and DEK (used after set_copass_encryption_key)."""
    global _copass_encryption_key, _dek
    _copass_encryption_key = None
    _dek = None
    _ensure_dek()


# =========================================================================
# FastMCP Server
# =========================================================================

mcp = FastMCP(
    "copass-local",
    instructions=(
        "Local encryption and setup plugin for copass-remote mcp.\n\n"
        "1st - check use check_project_status (copass-remote) to see if we are authenticated and what the project status is."
        "2nd - have copass-remote call `update_auth_token` with a fresh token. "
        "3rd - generate_session_token to get the encryption token for this session. Pass it to copass-remote MCP server for all subsequent calls.\n\n"
        "## Encryption\n\n"
        "The master key is auto-provisioned — no manual key setup needed.\n"
        "Pass the results as: `encryption_token` (from `generate_session_token`), "
        "`encrypted_text`, `encryption_iv`, `encryption_tag` (from `encrypt_payload`).\n\n"
        "## Setup\n\n"
        "`setup_project` writes hooks, scripts, config, and merges settings into "
        "`.claude/settings.local.json`. Call it when `check_project_status` (copass-remote) "
        "indicates hooks are not installed."
    ),
)


# =========================================================================
# Encryption Tools
# =========================================================================

@mcp.tool()
def generate_session_token(access_token: str) -> dict:
    """
    Generate a session token by wrapping the DEK with the access token.

    Call this at session start. The returned token is opaque and should be
    passed to the copass MCP server via the encryption_token parameter.
    The master key is loaded automatically — no need to provide it.

    Args:
        access_token: Supabase JWT access token

    Returns:
        Dict with session_token (base64 string) and expires_with note
    """
    _ensure_dek()
    token = create_session_token(_copass_encryption_key, access_token)
    return {
        "session_token": token,
        "expires_with": "access_token",
    }


@mcp.tool()
def encrypt_payload(text: str) -> dict:
    """
    Encrypt a text payload with AES-256-GCM.

    Returns base64-encoded encrypted fields suitable for passing to
    copass MCP server's ingest_text or ingest_code tools.
    The master key is loaded automatically — no need to provide it.

    Args:
        text: Plaintext to encrypt

    Returns:
        Dict with encrypted_text, encryption_iv, encryption_tag (all base64)
    """
    _ensure_dek()
    return _encrypt_aes_gcm(text, _dek)


@mcp.tool()
def encrypt_file(file_path: str) -> dict:
    """
    Encrypt a file's contents with AES-256-GCM.

    Reads the file, encrypts its contents, writes the encrypted data to a
    temporary file, and returns the path along with IV and tag.
    The master key is loaded automatically — no need to provide it.

    Args:
        file_path: Path to the file to encrypt

    Returns:
        Dict with encrypted_file_path, encryption_iv, encryption_tag
    """
    _ensure_dek()
    with open(file_path, "r", encoding="utf-8") as f:
        plaintext = f.read()

    result = _encrypt_aes_gcm(plaintext, _dek)

    # Write encrypted content to temp file
    fd, tmp_path = tempfile.mkstemp(prefix="olane_enc_", suffix=".bin")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(base64.b64decode(result["encrypted_text"]))
    except Exception:
        os.unlink(tmp_path)
        raise

    return {
        "encrypted_file_path": tmp_path,
        "encryption_iv": result["encryption_iv"],
        "encryption_tag": result["encryption_tag"],
    }


# =========================================================================
# Setup & Key Management Tools
# =========================================================================

@mcp.tool()
def update_auth_token(project_path: str, auth_token: str) -> dict:
    """
    Update the auth_token in .olane/config.json without exposing it to the user.

    Called during session initialization after check_project_status returns
    a fresh token. This avoids the Claude Code Edit/Write permission prompt
    which would display the token to the user.

    Args:
        project_path: Absolute path to the project root directory
        auth_token: Fresh access token to persist

    Returns:
        Dict with success (bool)
    """
    config_path = os.path.join(project_path, ".olane", "config.json")
    config = {}
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
        except (json.JSONDecodeError, OSError):
            config = {}

    config["auth_token"] = auth_token
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)
        f.write("\n")

    return {"success": True}


@mcp.tool()
def setup_project(
    project_path: str,
    agent_type: str,
    user_id: str,
    api_url: str = None,
    auth_token: str = None,
) -> dict:
    """
    Write all copass setup files to a project directory.

    Creates hooks, scripts, .olane/config.json, and merges settings into
    .claude/settings.local.json. Strips any legacy copass section from CLAUDE.md.

    Args:
        project_path: Absolute path to the project root directory
        agent_type: Type of coding agent (e.g. "claude_code")
        user_id: Authenticated user ID
        api_url: Optional API URL (defaults to OLANE_API_URL env or http://localhost:8000)
        auth_token: Optional OAuth access token to store in config

    Returns:
        Dict with success, files_written, and instructions
    """
    from olane_copass_local.setup import write_setup_files

    return write_setup_files(
        project_path=project_path,
        agent_type=agent_type,
        user_id=user_id,
        api_url=api_url,
        auth_token=auth_token,
        copass_encryption_key=_copass_encryption_key,
    )


@mcp.tool()
def set_copass_encryption_key(project_path: str, copass_encryption_key: str) -> dict:
    """
    Write a user-provided master key to .olane/config.json.

    Use this for migration or team key sharing — overwrites any existing key.
    Not needed for normal operation (keys are auto-provisioned).

    Args:
        project_path: Absolute path to the project root directory
        copass_encryption_key: The master key string to store

    Returns:
        Dict with success (bool) and source ("config")
    """
    from olane_copass_local.copass_encryption_key import set_copass_encryption_key as _set

    result = _set(project_path, copass_encryption_key)
    _reload_key()
    return result


def main():
    """Entry point for the MCP server (console script and python -m)."""
    logger.info("Starting Copass Local MCP server (stdio)")
    mcp.run()
