"""
olane-copass-local -- Local encryption and setup MCP plugin for copass / Twin Brain.

Provides session token generation, AES-256-GCM encryption, project setup,
and master key management tools that run on the user's machine via stdio transport.
"""

__version__ = "0.3.2"

from olane_copass_local.session_token import create_session_token, _derive_dek
from olane_copass_local.encryption import _encrypt_aes_gcm
from olane_copass_local.copass_encryption_key import check_copass_encryption_key, generate_copass_encryption_key, set_copass_encryption_key, ensure_copass_encryption_key
from olane_copass_local.setup import write_setup_files

__all__ = [
    "create_session_token",
    "_derive_dek",
    "_encrypt_aes_gcm",
    "check_copass_encryption_key",
    "generate_copass_encryption_key",
    "set_copass_encryption_key",
    "ensure_copass_encryption_key",
    "write_setup_files",
    "__version__",
]
