"""
Self-contained tests for olane-copass-local package.

No frame_graph imports — this test suite validates the standalone package
independently of the monorepo.
"""

import base64

import pytest
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from olane_copass_local.constants import (
    WRAP_HKDF_SALT,
    WRAP_HKDF_INFO,
    DEK_HKDF_SALT,
    DEK_HKDF_INFO,
)
from olane_copass_local.session_token import (
    create_session_token,
    _derive_dek,
    _derive_wrap_key,
)
from olane_copass_local.encryption import _encrypt_aes_gcm


copass_encryption_key = "test-master-key-standalone"
ACCESS_TOKEN = "eyJhbGciOiJFUzI1NiJ9.test-standalone-token"


def _decrypt_aes_gcm(encrypted_text_b64: str, iv_b64: str, tag_b64: str, dek: bytes) -> str:
    """Minimal decrypt helper for round-trip testing (NOT exported)."""
    ciphertext = base64.b64decode(encrypted_text_b64)
    iv = base64.b64decode(iv_b64)
    tag = base64.b64decode(tag_b64)
    aesgcm = AESGCM(dek)
    plaintext = aesgcm.decrypt(iv, ciphertext + tag, None)
    return plaintext.decode("utf-8")


class TestConstants:
    """Guard against accidental constant changes."""

    def test_wrap_hkdf_salt(self):
        assert WRAP_HKDF_SALT == b"olane-session-wrap-v1"

    def test_wrap_hkdf_info(self):
        assert WRAP_HKDF_INFO == b"olane-wrap"

    def test_dek_hkdf_salt(self):
        assert DEK_HKDF_SALT == b"olane-twin-brain-dek-v1"

    def test_dek_hkdf_info(self):
        assert DEK_HKDF_INFO == b"olane-dek"


class TestSessionToken:
    """Tests for session token creation."""

    def test_returns_base64_string(self):
        token = create_session_token(copass_encryption_key, ACCESS_TOKEN)
        assert isinstance(token, str)
        token_bytes = base64.b64decode(token)
        assert len(token_bytes) == 60  # iv(12) + encrypted_dek(32) + tag(16)

    def test_different_access_tokens_produce_different_tokens(self):
        t1 = create_session_token(copass_encryption_key, "token-a")
        t2 = create_session_token(copass_encryption_key, "token-b")
        assert t1 != t2

    def test_token_unwrap_round_trip(self):
        """Generate a token and verify the DEK can be recovered."""
        token = create_session_token(copass_encryption_key, ACCESS_TOKEN)
        token_bytes = base64.b64decode(token)

        iv = token_bytes[:12]
        encrypted_dek = token_bytes[12:44]
        tag = token_bytes[44:60]

        wrap_key = _derive_wrap_key(ACCESS_TOKEN)
        aesgcm = AESGCM(wrap_key)
        recovered_dek = aesgcm.decrypt(iv, encrypted_dek + tag, None)

        expected_dek = _derive_dek(copass_encryption_key)
        assert recovered_dek == expected_dek


class TestDekDerivation:
    """Tests for DEK derivation determinism."""

    def test_deterministic(self):
        dek1 = _derive_dek(copass_encryption_key)
        dek2 = _derive_dek(copass_encryption_key)
        assert dek1 == dek2

    def test_32_bytes(self):
        dek = _derive_dek(copass_encryption_key)
        assert len(dek) == 32

    def test_different_keys_produce_different_deks(self):
        dek1 = _derive_dek("key-a")
        dek2 = _derive_dek("key-b")
        assert dek1 != dek2


class TestEncryption:
    """Tests for AES-GCM encryption."""

    def test_returns_all_fields(self):
        dek = _derive_dek(copass_encryption_key)
        result = _encrypt_aes_gcm("hello world", dek)
        assert "encrypted_text" in result
        assert "encryption_iv" in result
        assert "encryption_tag" in result

    def test_fields_are_valid_base64(self):
        dek = _derive_dek(copass_encryption_key)
        result = _encrypt_aes_gcm("test", dek)
        base64.b64decode(result["encrypted_text"])
        base64.b64decode(result["encryption_iv"])
        base64.b64decode(result["encryption_tag"])

    def test_decrypt_round_trip(self):
        plaintext = "This is sensitive data for testing"
        dek = _derive_dek(copass_encryption_key)
        result = _encrypt_aes_gcm(plaintext, dek)
        decrypted = _decrypt_aes_gcm(
            result["encrypted_text"],
            result["encryption_iv"],
            result["encryption_tag"],
            dek,
        )
        assert decrypted == plaintext

    def test_different_encryptions_produce_different_output(self):
        """Each encryption uses a random IV, so outputs differ."""
        dek = _derive_dek(copass_encryption_key)
        r1 = _encrypt_aes_gcm("same text", dek)
        r2 = _encrypt_aes_gcm("same text", dek)
        assert r1["encrypted_text"] != r2["encrypted_text"]
        assert r1["encryption_iv"] != r2["encryption_iv"]
