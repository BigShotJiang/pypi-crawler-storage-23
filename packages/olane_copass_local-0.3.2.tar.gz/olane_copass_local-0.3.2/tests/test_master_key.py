"""Tests for ensure_copass_encryption_key() auto-provisioning logic."""

import json
import os

import pytest

from olane_copass_local.copass_encryption_key import ensure_copass_encryption_key


class TestEnsureMasterKey:
    """Tests for ensure_copass_encryption_key auto-provisioning."""

    def test_returns_env_key_when_set(self, tmp_path, monkeypatch):
        monkeypatch.setenv("COPASS_ENCRYPTION_KEY", "env-key-123")
        result = ensure_copass_encryption_key(str(tmp_path))
        assert result == {
            "copass_encryption_key": "env-key-123",
            "source": "environment",
            "generated": False,
        }

    def test_returns_config_key_when_exists(self, tmp_path, monkeypatch):
        monkeypatch.delenv("COPASS_ENCRYPTION_KEY", raising=False)
        config_dir = tmp_path / ".olane"
        config_dir.mkdir()
        (config_dir / "config.json").write_text(
            json.dumps({"copass_encryption_key": "config-key-456"})
        )
        result = ensure_copass_encryption_key(str(tmp_path))
        assert result == {
            "copass_encryption_key": "config-key-456",
            "source": "config",
            "generated": False,
        }

    def test_auto_generates_when_no_key_exists(self, tmp_path, monkeypatch):
        monkeypatch.delenv("COPASS_ENCRYPTION_KEY", raising=False)
        result = ensure_copass_encryption_key(str(tmp_path))
        assert result["source"] == "config"
        assert result["generated"] is True
        # Verify UUID4 format (8-4-4-4-12 hex)
        parts = result["copass_encryption_key"].split("-")
        assert len(parts) == 5
        assert [len(p) for p in parts] == [8, 4, 4, 4, 12]
        # Verify written to disk
        config = json.loads(
            (tmp_path / ".olane" / "config.json").read_text()
        )
        assert config["copass_encryption_key"] == result["copass_encryption_key"]

    def test_second_call_finds_existing_key(self, tmp_path, monkeypatch):
        monkeypatch.delenv("COPASS_ENCRYPTION_KEY", raising=False)
        first = ensure_copass_encryption_key(str(tmp_path))
        assert first["generated"] is True

        second = ensure_copass_encryption_key(str(tmp_path))
        assert second["generated"] is False
        assert second["copass_encryption_key"] == first["copass_encryption_key"]
        assert second["source"] == "config"

    def test_preserves_existing_config_fields(self, tmp_path, monkeypatch):
        monkeypatch.delenv("COPASS_ENCRYPTION_KEY", raising=False)
        config_dir = tmp_path / ".olane"
        config_dir.mkdir()
        (config_dir / "config.json").write_text(
            json.dumps({"user_id": "u-123", "auth_token": "tok-abc"})
        )
        result = ensure_copass_encryption_key(str(tmp_path))
        assert result["generated"] is True
        config = json.loads((config_dir / "config.json").read_text())
        assert config["user_id"] == "u-123"
        assert config["auth_token"] == "tok-abc"
        assert config["copass_encryption_key"] == result["copass_encryption_key"]

    def test_env_key_takes_priority_over_config(self, tmp_path, monkeypatch):
        monkeypatch.setenv("COPASS_ENCRYPTION_KEY", "env-wins")
        config_dir = tmp_path / ".olane"
        config_dir.mkdir()
        (config_dir / "config.json").write_text(
            json.dumps({"copass_encryption_key": "config-loses"})
        )
        result = ensure_copass_encryption_key(str(tmp_path))
        assert result["copass_encryption_key"] == "env-wins"
        assert result["source"] == "environment"
