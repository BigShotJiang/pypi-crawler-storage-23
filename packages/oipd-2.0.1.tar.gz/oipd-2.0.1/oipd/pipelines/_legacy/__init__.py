"""Legacy code kept for regression testing."""

from oipd.pipelines._legacy.estimator import ModelParams, RNDResult, _estimate

__all__ = ["ModelParams", "RNDResult", "_estimate"]
