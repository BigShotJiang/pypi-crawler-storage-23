"""Volatility fitting algorithm implementations (scaffolding)."""

__all__ = []
