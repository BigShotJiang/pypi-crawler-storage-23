"""Placeholder for dividend and discount-factor utilities."""

__all__ = []
