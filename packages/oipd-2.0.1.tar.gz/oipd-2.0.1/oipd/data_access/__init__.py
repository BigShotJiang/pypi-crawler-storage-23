"""Data access scaffolding package."""

from oipd.data_access import readers, vendors  # noqa: F401

__all__ = ["readers", "vendors"]
