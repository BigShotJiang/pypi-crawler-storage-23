from setuptools import setup, find_packages

setup(
    name="zachvit",
    version="1.1.4",   # ← bumped version

    author="Athanasios Angelakis",
    author_email="angelakis.athanasios@gmail.com",

    description=(
        "ZACH-ViT: compact permutation-invariant Vision Transformer "
        "(MedMNIST v3.0.2 edition, arXiv:2602.17929). "
        "Includes legacy SSDA lung ultrasound pipeline."
    ),

    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",

    url="https://github.com/Bluesman79/ZACH-ViT",

    project_urls={
        "Homepage": "https://github.com/Bluesman79/ZACH-ViT",
        "Paper (MedMNIST)": "https://arxiv.org/abs/2602.17929",
        "Legacy Paper (Ultrasound)": "https://arxiv.org/abs/2510.17650",
    },

    license="Apache-2.0",

    packages=find_packages(),

    install_requires=[
        "medmnist==3.0.2",
        "tensorflow==2.19.0",
        "keras==3.5.0",
        "numpy==1.26.4",
        "pandas==2.3.2",
        "matplotlib==3.10.5",
        "pydicom==3.0.1",
        "scikit-image==0.20.0",
        "Pillow==11.3.0",
        "scikit-learn==1.7.1",
        "IPython==8.20.0",
    ],

    entry_points={
        "console_scripts": [
            "zachvit-preprocess=scripts.preprocess_cli:main",
            "zachvit-train=scripts.train_zachvit_cli:main",
        ],
    },

    python_requires=">=3.10",

    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
        "Intended Audience :: Science/Research",
    ],

    keywords=[
        "medmnist",
        "medmnist v3.0.2",
        "vision transformer",
        "medical imaging",
        "medmnist",
        "transformer",
        "edge ai",
        "deep learning",
        "computer vision",
    ],
)

