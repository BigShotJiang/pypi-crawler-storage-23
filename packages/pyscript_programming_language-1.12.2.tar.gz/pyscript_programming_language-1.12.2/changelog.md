# Change Log

## [1.12.2] - 26/02/2026

### Fixed
- **Fixed some bugs**.
- Fixed some spelling errors.
- _etc._