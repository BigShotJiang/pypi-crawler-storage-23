from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.visual_encoding_config_colorby import VisualEncodingConfigColorby
from ..models.visual_encoding_config_style_palette_type_0_item import VisualEncodingConfigStylePaletteType0Item
from ..models.visual_encoding_config_styleby import VisualEncodingConfigStyleby
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.visual_encoding_config_color_map_type_0 import VisualEncodingConfigColorMapType0
    from ..models.visual_encoding_config_style_map_type_0 import VisualEncodingConfigStyleMapType0


T = TypeVar("T", bound="VisualEncodingConfig")


@_attrs_define
class VisualEncodingConfig:
    """Configuration for visual encoding of chart series.
    Maps semantic dimensions (metric, group) to visual channels (color, style).

        Attributes:
            color_by (VisualEncodingConfigColorby | Unset): Which dimension is encoded by color Default:
                VisualEncodingConfigColorby.METRIC.
            style_by (VisualEncodingConfigStyleby | Unset): Which dimension is encoded by line style (solid, dashed, dotted)
                Default: VisualEncodingConfigStyleby.GROUP.
            color_map (None | Unset | VisualEncodingConfigColorMapType0): Custom color mappings. Key: dimension value,
                Value: CSS color string
            style_map (None | Unset | VisualEncodingConfigStyleMapType0): Custom line style mappings. Key: dimension value,
                Value: line style
            color_palette (list[str] | None | Unset): Color palette for automatic color assignment
            style_palette (list[VisualEncodingConfigStylePaletteType0Item] | None | Unset): Line style palette for automatic
                style assignment
    """

    color_by: VisualEncodingConfigColorby | Unset = VisualEncodingConfigColorby.METRIC
    style_by: VisualEncodingConfigStyleby | Unset = VisualEncodingConfigStyleby.GROUP
    color_map: None | Unset | VisualEncodingConfigColorMapType0 = UNSET
    style_map: None | Unset | VisualEncodingConfigStyleMapType0 = UNSET
    color_palette: list[str] | None | Unset = UNSET
    style_palette: list[VisualEncodingConfigStylePaletteType0Item] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.visual_encoding_config_color_map_type_0 import VisualEncodingConfigColorMapType0
        from ..models.visual_encoding_config_style_map_type_0 import VisualEncodingConfigStyleMapType0

        color_by: str | Unset = UNSET
        if not isinstance(self.color_by, Unset):
            color_by = self.color_by.value

        style_by: str | Unset = UNSET
        if not isinstance(self.style_by, Unset):
            style_by = self.style_by.value

        color_map: dict[str, Any] | None | Unset
        if isinstance(self.color_map, Unset):
            color_map = UNSET
        elif isinstance(self.color_map, VisualEncodingConfigColorMapType0):
            color_map = self.color_map.to_dict()
        else:
            color_map = self.color_map

        style_map: dict[str, Any] | None | Unset
        if isinstance(self.style_map, Unset):
            style_map = UNSET
        elif isinstance(self.style_map, VisualEncodingConfigStyleMapType0):
            style_map = self.style_map.to_dict()
        else:
            style_map = self.style_map

        color_palette: list[str] | None | Unset
        if isinstance(self.color_palette, Unset):
            color_palette = UNSET
        elif isinstance(self.color_palette, list):
            color_palette = self.color_palette

        else:
            color_palette = self.color_palette

        style_palette: list[str] | None | Unset
        if isinstance(self.style_palette, Unset):
            style_palette = UNSET
        elif isinstance(self.style_palette, list):
            style_palette = []
            for style_palette_type_0_item_data in self.style_palette:
                style_palette_type_0_item = style_palette_type_0_item_data.value
                style_palette.append(style_palette_type_0_item)

        else:
            style_palette = self.style_palette

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if color_by is not UNSET:
            field_dict["colorBy"] = color_by
        if style_by is not UNSET:
            field_dict["styleBy"] = style_by
        if color_map is not UNSET:
            field_dict["colorMap"] = color_map
        if style_map is not UNSET:
            field_dict["styleMap"] = style_map
        if color_palette is not UNSET:
            field_dict["colorPalette"] = color_palette
        if style_palette is not UNSET:
            field_dict["stylePalette"] = style_palette

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.visual_encoding_config_color_map_type_0 import VisualEncodingConfigColorMapType0
        from ..models.visual_encoding_config_style_map_type_0 import VisualEncodingConfigStyleMapType0

        d = dict(src_dict)
        _color_by = d.pop("colorBy", UNSET)
        color_by: VisualEncodingConfigColorby | Unset
        if isinstance(_color_by, Unset):
            color_by = UNSET
        else:
            color_by = VisualEncodingConfigColorby(_color_by)

        _style_by = d.pop("styleBy", UNSET)
        style_by: VisualEncodingConfigStyleby | Unset
        if isinstance(_style_by, Unset):
            style_by = UNSET
        else:
            style_by = VisualEncodingConfigStyleby(_style_by)

        def _parse_color_map(data: object) -> None | Unset | VisualEncodingConfigColorMapType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                color_map_type_0 = VisualEncodingConfigColorMapType0.from_dict(data)

                return color_map_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | VisualEncodingConfigColorMapType0, data)

        color_map = _parse_color_map(d.pop("colorMap", UNSET))

        def _parse_style_map(data: object) -> None | Unset | VisualEncodingConfigStyleMapType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                style_map_type_0 = VisualEncodingConfigStyleMapType0.from_dict(data)

                return style_map_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | VisualEncodingConfigStyleMapType0, data)

        style_map = _parse_style_map(d.pop("styleMap", UNSET))

        def _parse_color_palette(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                color_palette_type_0 = cast(list[str], data)

                return color_palette_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        color_palette = _parse_color_palette(d.pop("colorPalette", UNSET))

        def _parse_style_palette(data: object) -> list[VisualEncodingConfigStylePaletteType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                style_palette_type_0 = []
                _style_palette_type_0 = data
                for style_palette_type_0_item_data in _style_palette_type_0:
                    style_palette_type_0_item = VisualEncodingConfigStylePaletteType0Item(
                        style_palette_type_0_item_data
                    )

                    style_palette_type_0.append(style_palette_type_0_item)

                return style_palette_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[VisualEncodingConfigStylePaletteType0Item] | None | Unset, data)

        style_palette = _parse_style_palette(d.pop("stylePalette", UNSET))

        visual_encoding_config = cls(
            color_by=color_by,
            style_by=style_by,
            color_map=color_map,
            style_map=style_map,
            color_palette=color_palette,
            style_palette=style_palette,
        )

        visual_encoding_config.additional_properties = d
        return visual_encoding_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
