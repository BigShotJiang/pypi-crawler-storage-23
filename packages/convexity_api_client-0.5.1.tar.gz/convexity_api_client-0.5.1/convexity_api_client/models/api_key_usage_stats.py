from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_key_usage_stats_top_endpoints_item import ApiKeyUsageStatsTopEndpointsItem


T = TypeVar("T", bound="ApiKeyUsageStats")


@_attrs_define
class ApiKeyUsageStats:
    """Usage statistics for an API key.

    Attributes:
        total_requests (int):
        last_24_h_requests (int):
        last_7_d_requests (int):
        avg_response_time_ms (float | None | Unset):
        top_endpoints (list[ApiKeyUsageStatsTopEndpointsItem] | Unset):
    """

    total_requests: int
    last_24_h_requests: int
    last_7_d_requests: int
    avg_response_time_ms: float | None | Unset = UNSET
    top_endpoints: list[ApiKeyUsageStatsTopEndpointsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total_requests = self.total_requests

        last_24_h_requests = self.last_24_h_requests

        last_7_d_requests = self.last_7_d_requests

        avg_response_time_ms: float | None | Unset
        if isinstance(self.avg_response_time_ms, Unset):
            avg_response_time_ms = UNSET
        else:
            avg_response_time_ms = self.avg_response_time_ms

        top_endpoints: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.top_endpoints, Unset):
            top_endpoints = []
            for top_endpoints_item_data in self.top_endpoints:
                top_endpoints_item = top_endpoints_item_data.to_dict()
                top_endpoints.append(top_endpoints_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "totalRequests": total_requests,
                "last24hRequests": last_24_h_requests,
                "last7dRequests": last_7_d_requests,
            }
        )
        if avg_response_time_ms is not UNSET:
            field_dict["avgResponseTimeMs"] = avg_response_time_ms
        if top_endpoints is not UNSET:
            field_dict["topEndpoints"] = top_endpoints

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key_usage_stats_top_endpoints_item import ApiKeyUsageStatsTopEndpointsItem

        d = dict(src_dict)
        total_requests = d.pop("totalRequests")

        last_24_h_requests = d.pop("last24hRequests")

        last_7_d_requests = d.pop("last7dRequests")

        def _parse_avg_response_time_ms(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        avg_response_time_ms = _parse_avg_response_time_ms(d.pop("avgResponseTimeMs", UNSET))

        _top_endpoints = d.pop("topEndpoints", UNSET)
        top_endpoints: list[ApiKeyUsageStatsTopEndpointsItem] | Unset = UNSET
        if _top_endpoints is not UNSET:
            top_endpoints = []
            for top_endpoints_item_data in _top_endpoints:
                top_endpoints_item = ApiKeyUsageStatsTopEndpointsItem.from_dict(top_endpoints_item_data)

                top_endpoints.append(top_endpoints_item)

        api_key_usage_stats = cls(
            total_requests=total_requests,
            last_24_h_requests=last_24_h_requests,
            last_7_d_requests=last_7_d_requests,
            avg_response_time_ms=avg_response_time_ms,
            top_endpoints=top_endpoints,
        )

        api_key_usage_stats.additional_properties = d
        return api_key_usage_stats

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
