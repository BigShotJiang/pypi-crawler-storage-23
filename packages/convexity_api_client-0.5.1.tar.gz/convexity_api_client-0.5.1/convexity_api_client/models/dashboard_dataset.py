from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.dashboard import Dashboard
    from ..models.dataset import Dataset


T = TypeVar("T", bound="DashboardDataset")


@_attrs_define
class DashboardDataset:
    """Represents a DashboardDataset record

    Attributes:
        id (str):
        dashboard_id (str):
        dataset_id (str):
        added_at (datetime.datetime):
        added_by (str):
        dashboard (Dashboard | None | Unset):
        dataset (Dataset | None | Unset):
    """

    id: str
    dashboard_id: str
    dataset_id: str
    added_at: datetime.datetime
    added_by: str
    dashboard: Dashboard | None | Unset = UNSET
    dataset: Dataset | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.dashboard import Dashboard
        from ..models.dataset import Dataset

        id = self.id

        dashboard_id = self.dashboard_id

        dataset_id = self.dataset_id

        added_at = self.added_at.isoformat()

        added_by = self.added_by

        dashboard: dict[str, Any] | None | Unset
        if isinstance(self.dashboard, Unset):
            dashboard = UNSET
        elif isinstance(self.dashboard, Dashboard):
            dashboard = self.dashboard.to_dict()
        else:
            dashboard = self.dashboard

        dataset: dict[str, Any] | None | Unset
        if isinstance(self.dataset, Unset):
            dataset = UNSET
        elif isinstance(self.dataset, Dataset):
            dataset = self.dataset.to_dict()
        else:
            dataset = self.dataset

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "dashboard_id": dashboard_id,
                "dataset_id": dataset_id,
                "added_at": added_at,
                "added_by": added_by,
            }
        )
        if dashboard is not UNSET:
            field_dict["dashboard"] = dashboard
        if dataset is not UNSET:
            field_dict["dataset"] = dataset

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dashboard import Dashboard
        from ..models.dataset import Dataset

        d = dict(src_dict)
        id = d.pop("id")

        dashboard_id = d.pop("dashboard_id")

        dataset_id = d.pop("dataset_id")

        added_at = isoparse(d.pop("added_at"))

        added_by = d.pop("added_by")

        def _parse_dashboard(data: object) -> Dashboard | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                dashboard_type_0 = Dashboard.from_dict(data)

                return dashboard_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Dashboard | None | Unset, data)

        dashboard = _parse_dashboard(d.pop("dashboard", UNSET))

        def _parse_dataset(data: object) -> Dataset | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                dataset_type_0 = Dataset.from_dict(data)

                return dataset_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Dataset | None | Unset, data)

        dataset = _parse_dataset(d.pop("dataset", UNSET))

        dashboard_dataset = cls(
            id=id,
            dashboard_id=dashboard_id,
            dataset_id=dataset_id,
            added_at=added_at,
            added_by=added_by,
            dashboard=dashboard,
            dataset=dataset,
        )

        dashboard_dataset.additional_properties = d
        return dashboard_dataset

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
