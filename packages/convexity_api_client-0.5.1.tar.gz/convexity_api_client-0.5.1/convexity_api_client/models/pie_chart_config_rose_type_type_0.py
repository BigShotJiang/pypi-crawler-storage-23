from enum import Enum


class PieChartConfigRoseTypeType0(str, Enum):
    AREA = "area"
    RADIUS = "radius"

    def __str__(self) -> str:
        return str(self.value)
