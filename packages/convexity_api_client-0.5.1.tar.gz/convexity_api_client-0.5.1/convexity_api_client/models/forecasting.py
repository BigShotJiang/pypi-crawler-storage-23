from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.profile import Profile


T = TypeVar("T", bound="Forecasting")


@_attrs_define
class Forecasting:
    """Represents a Forecasting record

    Attributes:
        id (str):
        name (str):
        created_at (datetime.datetime):
        user_id (str):
        workspace_id (str):
        problem (None | str | Unset):
        code (None | str | Unset):
        output (None | str | Unset):
        report (None | str | Unset):
        model_summary (None | str | Unset):
        target_column (None | str | Unset):
        forecast_horizon (int | None | Unset):
        feature_notes (None | str | Unset):
        training_notes (None | str | Unset):
        profile (None | Profile | Unset):
    """

    id: str
    name: str
    created_at: datetime.datetime
    user_id: str
    workspace_id: str
    problem: None | str | Unset = UNSET
    code: None | str | Unset = UNSET
    output: None | str | Unset = UNSET
    report: None | str | Unset = UNSET
    model_summary: None | str | Unset = UNSET
    target_column: None | str | Unset = UNSET
    forecast_horizon: int | None | Unset = UNSET
    feature_notes: None | str | Unset = UNSET
    training_notes: None | str | Unset = UNSET
    profile: None | Profile | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.profile import Profile

        id = self.id

        name = self.name

        created_at = self.created_at.isoformat()

        user_id = self.user_id

        workspace_id = self.workspace_id

        problem: None | str | Unset
        if isinstance(self.problem, Unset):
            problem = UNSET
        else:
            problem = self.problem

        code: None | str | Unset
        if isinstance(self.code, Unset):
            code = UNSET
        else:
            code = self.code

        output: None | str | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        else:
            output = self.output

        report: None | str | Unset
        if isinstance(self.report, Unset):
            report = UNSET
        else:
            report = self.report

        model_summary: None | str | Unset
        if isinstance(self.model_summary, Unset):
            model_summary = UNSET
        else:
            model_summary = self.model_summary

        target_column: None | str | Unset
        if isinstance(self.target_column, Unset):
            target_column = UNSET
        else:
            target_column = self.target_column

        forecast_horizon: int | None | Unset
        if isinstance(self.forecast_horizon, Unset):
            forecast_horizon = UNSET
        else:
            forecast_horizon = self.forecast_horizon

        feature_notes: None | str | Unset
        if isinstance(self.feature_notes, Unset):
            feature_notes = UNSET
        else:
            feature_notes = self.feature_notes

        training_notes: None | str | Unset
        if isinstance(self.training_notes, Unset):
            training_notes = UNSET
        else:
            training_notes = self.training_notes

        profile: dict[str, Any] | None | Unset
        if isinstance(self.profile, Unset):
            profile = UNSET
        elif isinstance(self.profile, Profile):
            profile = self.profile.to_dict()
        else:
            profile = self.profile

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "created_at": created_at,
                "user_id": user_id,
                "workspace_id": workspace_id,
            }
        )
        if problem is not UNSET:
            field_dict["problem"] = problem
        if code is not UNSET:
            field_dict["code"] = code
        if output is not UNSET:
            field_dict["output"] = output
        if report is not UNSET:
            field_dict["report"] = report
        if model_summary is not UNSET:
            field_dict["model_summary"] = model_summary
        if target_column is not UNSET:
            field_dict["target_column"] = target_column
        if forecast_horizon is not UNSET:
            field_dict["forecast_horizon"] = forecast_horizon
        if feature_notes is not UNSET:
            field_dict["feature_notes"] = feature_notes
        if training_notes is not UNSET:
            field_dict["training_notes"] = training_notes
        if profile is not UNSET:
            field_dict["profile"] = profile

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.profile import Profile

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        created_at = isoparse(d.pop("created_at"))

        user_id = d.pop("user_id")

        workspace_id = d.pop("workspace_id")

        def _parse_problem(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        problem = _parse_problem(d.pop("problem", UNSET))

        def _parse_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        code = _parse_code(d.pop("code", UNSET))

        def _parse_output(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        output = _parse_output(d.pop("output", UNSET))

        def _parse_report(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        report = _parse_report(d.pop("report", UNSET))

        def _parse_model_summary(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model_summary = _parse_model_summary(d.pop("model_summary", UNSET))

        def _parse_target_column(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        target_column = _parse_target_column(d.pop("target_column", UNSET))

        def _parse_forecast_horizon(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        forecast_horizon = _parse_forecast_horizon(d.pop("forecast_horizon", UNSET))

        def _parse_feature_notes(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        feature_notes = _parse_feature_notes(d.pop("feature_notes", UNSET))

        def _parse_training_notes(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        training_notes = _parse_training_notes(d.pop("training_notes", UNSET))

        def _parse_profile(data: object) -> None | Profile | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                profile_type_0 = Profile.from_dict(data)

                return profile_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Profile | Unset, data)

        profile = _parse_profile(d.pop("profile", UNSET))

        forecasting = cls(
            id=id,
            name=name,
            created_at=created_at,
            user_id=user_id,
            workspace_id=workspace_id,
            problem=problem,
            code=code,
            output=output,
            report=report,
            model_summary=model_summary,
            target_column=target_column,
            forecast_horizon=forecast_horizon,
            feature_notes=feature_notes,
            training_notes=training_notes,
            profile=profile,
        )

        forecasting.additional_properties = d
        return forecasting

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
