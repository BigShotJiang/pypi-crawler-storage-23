from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.kpi_chart_config_font_weight_type_0 import KpiChartConfigFontWeightType0
from ..models.kpi_chart_config_text_align_type_0 import KpiChartConfigTextAlignType0
from ..models.kpi_chart_config_trend_direction_type_0 import KpiChartConfigTrendDirectionType0
from ..models.kpi_chart_config_value_format_type_0 import KpiChartConfigValueFormatType0
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chart_field import ChartField
    from ..models.chart_filter import ChartFilter
    from ..models.kpi_chart_config_chart_padding_type_1 import KpiChartConfigChartPaddingType1
    from ..models.tooltip_config import TooltipConfig


T = TypeVar("T", bound="KpiChartConfig")


@_attrs_define
class KpiChartConfig:
    """Configuration for KPI/metric charts. Supports both numeric values and text/label display.

    Attributes:
        type_ (Literal['kpi'] | Unset):  Default: 'kpi'.
        value_field (ChartField | None | Unset): Primary value field configuration (for numeric display)
        comparison_field (ChartField | None | Unset): Comparison value field configuration
        trend_direction (KpiChartConfigTrendDirectionType0 | None | Unset): How to interpret trend direction Default:
            KpiChartConfigTrendDirectionType0.UP_GOOD.
        value_format (KpiChartConfigValueFormatType0 | None | Unset): Value format Default:
            KpiChartConfigValueFormatType0.NUMBER.
        prefix (None | str | Unset): Value prefix (e.g., '$')
        suffix (None | str | Unset): Value suffix (e.g., '%')
        decimal_places (int | None | Unset): Number of decimal places Default: 2.
        colors (list[str] | None | Unset): Custom colors [positive, negative]
        text_field (ChartField | None | Unset): Text field config (for text/label display)
        text_color (None | str | Unset): Text color (CSS color string)
        font_size (int | None | Unset): Font size in pixels
        text_align (KpiChartConfigTextAlignType0 | None | Unset): Text alignment Default:
            KpiChartConfigTextAlignType0.CENTER.
        font_weight (KpiChartConfigFontWeightType0 | None | Unset): Font weight Default:
            KpiChartConfigFontWeightType0.NORMAL.
        tooltip_config (None | TooltipConfig | Unset): Tooltip configuration
        filters (list[ChartFilter] | None | Unset): Chart-specific filters (applied before dashboard filters)
        chart_padding (int | KpiChartConfigChartPaddingType1 | None | Unset): Chart padding (space around the chart
            inside the widget). Can be a single number for all sides, or an object for individual sides
    """

    type_: Literal["kpi"] | Unset = "kpi"
    value_field: ChartField | None | Unset = UNSET
    comparison_field: ChartField | None | Unset = UNSET
    trend_direction: KpiChartConfigTrendDirectionType0 | None | Unset = KpiChartConfigTrendDirectionType0.UP_GOOD
    value_format: KpiChartConfigValueFormatType0 | None | Unset = KpiChartConfigValueFormatType0.NUMBER
    prefix: None | str | Unset = UNSET
    suffix: None | str | Unset = UNSET
    decimal_places: int | None | Unset = 2
    colors: list[str] | None | Unset = UNSET
    text_field: ChartField | None | Unset = UNSET
    text_color: None | str | Unset = UNSET
    font_size: int | None | Unset = UNSET
    text_align: KpiChartConfigTextAlignType0 | None | Unset = KpiChartConfigTextAlignType0.CENTER
    font_weight: KpiChartConfigFontWeightType0 | None | Unset = KpiChartConfigFontWeightType0.NORMAL
    tooltip_config: None | TooltipConfig | Unset = UNSET
    filters: list[ChartFilter] | None | Unset = UNSET
    chart_padding: int | KpiChartConfigChartPaddingType1 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.chart_field import ChartField
        from ..models.kpi_chart_config_chart_padding_type_1 import KpiChartConfigChartPaddingType1
        from ..models.tooltip_config import TooltipConfig

        type_ = self.type_

        value_field: dict[str, Any] | None | Unset
        if isinstance(self.value_field, Unset):
            value_field = UNSET
        elif isinstance(self.value_field, ChartField):
            value_field = self.value_field.to_dict()
        else:
            value_field = self.value_field

        comparison_field: dict[str, Any] | None | Unset
        if isinstance(self.comparison_field, Unset):
            comparison_field = UNSET
        elif isinstance(self.comparison_field, ChartField):
            comparison_field = self.comparison_field.to_dict()
        else:
            comparison_field = self.comparison_field

        trend_direction: None | str | Unset
        if isinstance(self.trend_direction, Unset):
            trend_direction = UNSET
        elif isinstance(self.trend_direction, KpiChartConfigTrendDirectionType0):
            trend_direction = self.trend_direction.value
        else:
            trend_direction = self.trend_direction

        value_format: None | str | Unset
        if isinstance(self.value_format, Unset):
            value_format = UNSET
        elif isinstance(self.value_format, KpiChartConfigValueFormatType0):
            value_format = self.value_format.value
        else:
            value_format = self.value_format

        prefix: None | str | Unset
        if isinstance(self.prefix, Unset):
            prefix = UNSET
        else:
            prefix = self.prefix

        suffix: None | str | Unset
        if isinstance(self.suffix, Unset):
            suffix = UNSET
        else:
            suffix = self.suffix

        decimal_places: int | None | Unset
        if isinstance(self.decimal_places, Unset):
            decimal_places = UNSET
        else:
            decimal_places = self.decimal_places

        colors: list[str] | None | Unset
        if isinstance(self.colors, Unset):
            colors = UNSET
        elif isinstance(self.colors, list):
            colors = self.colors

        else:
            colors = self.colors

        text_field: dict[str, Any] | None | Unset
        if isinstance(self.text_field, Unset):
            text_field = UNSET
        elif isinstance(self.text_field, ChartField):
            text_field = self.text_field.to_dict()
        else:
            text_field = self.text_field

        text_color: None | str | Unset
        if isinstance(self.text_color, Unset):
            text_color = UNSET
        else:
            text_color = self.text_color

        font_size: int | None | Unset
        if isinstance(self.font_size, Unset):
            font_size = UNSET
        else:
            font_size = self.font_size

        text_align: None | str | Unset
        if isinstance(self.text_align, Unset):
            text_align = UNSET
        elif isinstance(self.text_align, KpiChartConfigTextAlignType0):
            text_align = self.text_align.value
        else:
            text_align = self.text_align

        font_weight: None | str | Unset
        if isinstance(self.font_weight, Unset):
            font_weight = UNSET
        elif isinstance(self.font_weight, KpiChartConfigFontWeightType0):
            font_weight = self.font_weight.value
        else:
            font_weight = self.font_weight

        tooltip_config: dict[str, Any] | None | Unset
        if isinstance(self.tooltip_config, Unset):
            tooltip_config = UNSET
        elif isinstance(self.tooltip_config, TooltipConfig):
            tooltip_config = self.tooltip_config.to_dict()
        else:
            tooltip_config = self.tooltip_config

        filters: list[dict[str, Any]] | None | Unset
        if isinstance(self.filters, Unset):
            filters = UNSET
        elif isinstance(self.filters, list):
            filters = []
            for filters_type_0_item_data in self.filters:
                filters_type_0_item = filters_type_0_item_data.to_dict()
                filters.append(filters_type_0_item)

        else:
            filters = self.filters

        chart_padding: dict[str, Any] | int | None | Unset
        if isinstance(self.chart_padding, Unset):
            chart_padding = UNSET
        elif isinstance(self.chart_padding, KpiChartConfigChartPaddingType1):
            chart_padding = self.chart_padding.to_dict()
        else:
            chart_padding = self.chart_padding

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if value_field is not UNSET:
            field_dict["valueField"] = value_field
        if comparison_field is not UNSET:
            field_dict["comparisonField"] = comparison_field
        if trend_direction is not UNSET:
            field_dict["trendDirection"] = trend_direction
        if value_format is not UNSET:
            field_dict["valueFormat"] = value_format
        if prefix is not UNSET:
            field_dict["prefix"] = prefix
        if suffix is not UNSET:
            field_dict["suffix"] = suffix
        if decimal_places is not UNSET:
            field_dict["decimalPlaces"] = decimal_places
        if colors is not UNSET:
            field_dict["colors"] = colors
        if text_field is not UNSET:
            field_dict["textField"] = text_field
        if text_color is not UNSET:
            field_dict["textColor"] = text_color
        if font_size is not UNSET:
            field_dict["fontSize"] = font_size
        if text_align is not UNSET:
            field_dict["textAlign"] = text_align
        if font_weight is not UNSET:
            field_dict["fontWeight"] = font_weight
        if tooltip_config is not UNSET:
            field_dict["tooltipConfig"] = tooltip_config
        if filters is not UNSET:
            field_dict["filters"] = filters
        if chart_padding is not UNSET:
            field_dict["chartPadding"] = chart_padding

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chart_field import ChartField
        from ..models.chart_filter import ChartFilter
        from ..models.kpi_chart_config_chart_padding_type_1 import KpiChartConfigChartPaddingType1
        from ..models.tooltip_config import TooltipConfig

        d = dict(src_dict)
        type_ = cast(Literal["kpi"] | Unset, d.pop("type", UNSET))
        if type_ != "kpi" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'kpi', got '{type_}'")

        def _parse_value_field(data: object) -> ChartField | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                value_field_type_0 = ChartField.from_dict(data)

                return value_field_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartField | None | Unset, data)

        value_field = _parse_value_field(d.pop("valueField", UNSET))

        def _parse_comparison_field(data: object) -> ChartField | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                comparison_field_type_0 = ChartField.from_dict(data)

                return comparison_field_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartField | None | Unset, data)

        comparison_field = _parse_comparison_field(d.pop("comparisonField", UNSET))

        def _parse_trend_direction(data: object) -> KpiChartConfigTrendDirectionType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                trend_direction_type_0 = KpiChartConfigTrendDirectionType0(data)

                return trend_direction_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(KpiChartConfigTrendDirectionType0 | None | Unset, data)

        trend_direction = _parse_trend_direction(d.pop("trendDirection", UNSET))

        def _parse_value_format(data: object) -> KpiChartConfigValueFormatType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                value_format_type_0 = KpiChartConfigValueFormatType0(data)

                return value_format_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(KpiChartConfigValueFormatType0 | None | Unset, data)

        value_format = _parse_value_format(d.pop("valueFormat", UNSET))

        def _parse_prefix(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        prefix = _parse_prefix(d.pop("prefix", UNSET))

        def _parse_suffix(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        suffix = _parse_suffix(d.pop("suffix", UNSET))

        def _parse_decimal_places(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        decimal_places = _parse_decimal_places(d.pop("decimalPlaces", UNSET))

        def _parse_colors(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                colors_type_0 = cast(list[str], data)

                return colors_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        colors = _parse_colors(d.pop("colors", UNSET))

        def _parse_text_field(data: object) -> ChartField | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                text_field_type_0 = ChartField.from_dict(data)

                return text_field_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChartField | None | Unset, data)

        text_field = _parse_text_field(d.pop("textField", UNSET))

        def _parse_text_color(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        text_color = _parse_text_color(d.pop("textColor", UNSET))

        def _parse_font_size(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        font_size = _parse_font_size(d.pop("fontSize", UNSET))

        def _parse_text_align(data: object) -> KpiChartConfigTextAlignType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                text_align_type_0 = KpiChartConfigTextAlignType0(data)

                return text_align_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(KpiChartConfigTextAlignType0 | None | Unset, data)

        text_align = _parse_text_align(d.pop("textAlign", UNSET))

        def _parse_font_weight(data: object) -> KpiChartConfigFontWeightType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                font_weight_type_0 = KpiChartConfigFontWeightType0(data)

                return font_weight_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(KpiChartConfigFontWeightType0 | None | Unset, data)

        font_weight = _parse_font_weight(d.pop("fontWeight", UNSET))

        def _parse_tooltip_config(data: object) -> None | TooltipConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                tooltip_config_type_0 = TooltipConfig.from_dict(data)

                return tooltip_config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TooltipConfig | Unset, data)

        tooltip_config = _parse_tooltip_config(d.pop("tooltipConfig", UNSET))

        def _parse_filters(data: object) -> list[ChartFilter] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                filters_type_0 = []
                _filters_type_0 = data
                for filters_type_0_item_data in _filters_type_0:
                    filters_type_0_item = ChartFilter.from_dict(filters_type_0_item_data)

                    filters_type_0.append(filters_type_0_item)

                return filters_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ChartFilter] | None | Unset, data)

        filters = _parse_filters(d.pop("filters", UNSET))

        def _parse_chart_padding(data: object) -> int | KpiChartConfigChartPaddingType1 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                chart_padding_type_1 = KpiChartConfigChartPaddingType1.from_dict(data)

                return chart_padding_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(int | KpiChartConfigChartPaddingType1 | None | Unset, data)

        chart_padding = _parse_chart_padding(d.pop("chartPadding", UNSET))

        kpi_chart_config = cls(
            type_=type_,
            value_field=value_field,
            comparison_field=comparison_field,
            trend_direction=trend_direction,
            value_format=value_format,
            prefix=prefix,
            suffix=suffix,
            decimal_places=decimal_places,
            colors=colors,
            text_field=text_field,
            text_color=text_color,
            font_size=font_size,
            text_align=text_align,
            font_weight=font_weight,
            tooltip_config=tooltip_config,
            filters=filters,
            chart_padding=chart_padding,
        )

        kpi_chart_config.additional_properties = d
        return kpi_chart_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
