from enum import Enum


class SeriesStyleLineStyleType0(str, Enum):
    DASHED = "dashed"
    DOTTED = "dotted"
    SOLID = "solid"

    def __str__(self) -> str:
        return str(self.value)
