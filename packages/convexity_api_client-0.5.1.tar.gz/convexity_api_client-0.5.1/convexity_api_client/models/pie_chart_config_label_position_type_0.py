from enum import Enum


class PieChartConfigLabelPositionType0(str, Enum):
    INSIDE = "inside"
    OUTSIDE = "outside"

    def __str__(self) -> str:
        return str(self.value)
