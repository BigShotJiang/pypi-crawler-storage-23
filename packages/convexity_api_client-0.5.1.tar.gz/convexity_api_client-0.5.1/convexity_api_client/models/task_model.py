from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.task_scenario import TaskScenario
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.api_connection import ApiConnection
    from ..models.database_connection import DatabaseConnection
    from ..models.databricks_connection import DatabricksConnection
    from ..models.file_connection import FileConnection
    from ..models.notebook_document import NotebookDocument
    from ..models.run import Run
    from ..models.s3_connection import S3Connection
    from ..models.task_model_parameter_schema_type_0 import TaskModelParameterSchemaType0
    from ..models.webhook_connection import WebhookConnection


T = TypeVar("T", bound="TaskModel")


@_attrs_define
class TaskModel:
    """Task (Model) representation.

    Attributes:
        name (str): Name of the task/model
        project_id (str):
        user_id (str):
        scenario (TaskScenario):
        created_at (str):
        id (None | str | Unset): Unique identifier for the task/model
        description (None | str | Unset):
        updated_at (None | str | Unset):
        version (None | str | Unset):
        notebook (None | NotebookDocument | Unset):
        connections (list[ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection |
            WebhookConnection] | None | Unset):
        runs (list[Run] | None | Unset):
        parameter_schema (None | TaskModelParameterSchemaType0 | Unset):
    """

    name: str
    project_id: str
    user_id: str
    scenario: TaskScenario
    created_at: str
    id: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    updated_at: None | str | Unset = UNSET
    version: None | str | Unset = UNSET
    notebook: None | NotebookDocument | Unset = UNSET
    connections: (
        list[
            ApiConnection
            | DatabaseConnection
            | DatabricksConnection
            | FileConnection
            | S3Connection
            | WebhookConnection
        ]
        | None
        | Unset
    ) = UNSET
    runs: list[Run] | None | Unset = UNSET
    parameter_schema: None | TaskModelParameterSchemaType0 | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.api_connection import ApiConnection
        from ..models.database_connection import DatabaseConnection
        from ..models.file_connection import FileConnection
        from ..models.notebook_document import NotebookDocument
        from ..models.s3_connection import S3Connection
        from ..models.task_model_parameter_schema_type_0 import TaskModelParameterSchemaType0
        from ..models.webhook_connection import WebhookConnection

        name = self.name

        project_id = self.project_id

        user_id = self.user_id

        scenario = self.scenario.value

        created_at = self.created_at

        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = self.updated_at

        version: None | str | Unset
        if isinstance(self.version, Unset):
            version = UNSET
        else:
            version = self.version

        notebook: dict[str, Any] | None | Unset
        if isinstance(self.notebook, Unset):
            notebook = UNSET
        elif isinstance(self.notebook, NotebookDocument):
            notebook = self.notebook.to_dict()
        else:
            notebook = self.notebook

        connections: list[dict[str, Any]] | None | Unset
        if isinstance(self.connections, Unset):
            connections = UNSET
        elif isinstance(self.connections, list):
            connections = []
            for connections_type_0_item_data in self.connections:
                connections_type_0_item: dict[str, Any]
                if isinstance(connections_type_0_item_data, DatabaseConnection):
                    connections_type_0_item = connections_type_0_item_data.to_dict()
                elif isinstance(connections_type_0_item_data, S3Connection):
                    connections_type_0_item = connections_type_0_item_data.to_dict()
                elif isinstance(connections_type_0_item_data, ApiConnection):
                    connections_type_0_item = connections_type_0_item_data.to_dict()
                elif isinstance(connections_type_0_item_data, WebhookConnection):
                    connections_type_0_item = connections_type_0_item_data.to_dict()
                elif isinstance(connections_type_0_item_data, FileConnection):
                    connections_type_0_item = connections_type_0_item_data.to_dict()
                else:
                    connections_type_0_item = connections_type_0_item_data.to_dict()

                connections.append(connections_type_0_item)

        else:
            connections = self.connections

        runs: list[dict[str, Any]] | None | Unset
        if isinstance(self.runs, Unset):
            runs = UNSET
        elif isinstance(self.runs, list):
            runs = []
            for runs_type_0_item_data in self.runs:
                runs_type_0_item = runs_type_0_item_data.to_dict()
                runs.append(runs_type_0_item)

        else:
            runs = self.runs

        parameter_schema: dict[str, Any] | None | Unset
        if isinstance(self.parameter_schema, Unset):
            parameter_schema = UNSET
        elif isinstance(self.parameter_schema, TaskModelParameterSchemaType0):
            parameter_schema = self.parameter_schema.to_dict()
        else:
            parameter_schema = self.parameter_schema

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "projectId": project_id,
                "userId": user_id,
                "scenario": scenario,
                "created_at": created_at,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id
        if description is not UNSET:
            field_dict["description"] = description
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at
        if version is not UNSET:
            field_dict["version"] = version
        if notebook is not UNSET:
            field_dict["notebook"] = notebook
        if connections is not UNSET:
            field_dict["connections"] = connections
        if runs is not UNSET:
            field_dict["runs"] = runs
        if parameter_schema is not UNSET:
            field_dict["parameter_schema"] = parameter_schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_connection import ApiConnection
        from ..models.database_connection import DatabaseConnection
        from ..models.databricks_connection import DatabricksConnection
        from ..models.file_connection import FileConnection
        from ..models.notebook_document import NotebookDocument
        from ..models.run import Run
        from ..models.s3_connection import S3Connection
        from ..models.task_model_parameter_schema_type_0 import TaskModelParameterSchemaType0
        from ..models.webhook_connection import WebhookConnection

        d = dict(src_dict)
        name = d.pop("name")

        project_id = d.pop("projectId")

        user_id = d.pop("userId")

        scenario = TaskScenario(d.pop("scenario"))

        created_at = d.pop("created_at")

        def _parse_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_updated_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        updated_at = _parse_updated_at(d.pop("updated_at", UNSET))

        def _parse_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version = _parse_version(d.pop("version", UNSET))

        def _parse_notebook(data: object) -> None | NotebookDocument | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                notebook_type_0 = NotebookDocument.from_dict(data)

                return notebook_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | NotebookDocument | Unset, data)

        notebook = _parse_notebook(d.pop("notebook", UNSET))

        def _parse_connections(
            data: object,
        ) -> (
            list[
                ApiConnection
                | DatabaseConnection
                | DatabricksConnection
                | FileConnection
                | S3Connection
                | WebhookConnection
            ]
            | None
            | Unset
        ):
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                connections_type_0 = []
                _connections_type_0 = data
                for connections_type_0_item_data in _connections_type_0:

                    def _parse_connections_type_0_item(
                        data: object,
                    ) -> (
                        ApiConnection
                        | DatabaseConnection
                        | DatabricksConnection
                        | FileConnection
                        | S3Connection
                        | WebhookConnection
                    ):
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            connections_type_0_item_type_0 = DatabaseConnection.from_dict(data)

                            return connections_type_0_item_type_0
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            connections_type_0_item_type_1 = S3Connection.from_dict(data)

                            return connections_type_0_item_type_1
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            connections_type_0_item_type_2 = ApiConnection.from_dict(data)

                            return connections_type_0_item_type_2
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            connections_type_0_item_type_3 = WebhookConnection.from_dict(data)

                            return connections_type_0_item_type_3
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            connections_type_0_item_type_4 = FileConnection.from_dict(data)

                            return connections_type_0_item_type_4
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        if not isinstance(data, dict):
                            raise TypeError()
                        connections_type_0_item_type_5 = DatabricksConnection.from_dict(data)

                        return connections_type_0_item_type_5

                    connections_type_0_item = _parse_connections_type_0_item(connections_type_0_item_data)

                    connections_type_0.append(connections_type_0_item)

                return connections_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(
                list[
                    ApiConnection
                    | DatabaseConnection
                    | DatabricksConnection
                    | FileConnection
                    | S3Connection
                    | WebhookConnection
                ]
                | None
                | Unset,
                data,
            )

        connections = _parse_connections(d.pop("connections", UNSET))

        def _parse_runs(data: object) -> list[Run] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                runs_type_0 = []
                _runs_type_0 = data
                for runs_type_0_item_data in _runs_type_0:
                    runs_type_0_item = Run.from_dict(runs_type_0_item_data)

                    runs_type_0.append(runs_type_0_item)

                return runs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Run] | None | Unset, data)

        runs = _parse_runs(d.pop("runs", UNSET))

        def _parse_parameter_schema(data: object) -> None | TaskModelParameterSchemaType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                parameter_schema_type_0 = TaskModelParameterSchemaType0.from_dict(data)

                return parameter_schema_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TaskModelParameterSchemaType0 | Unset, data)

        parameter_schema = _parse_parameter_schema(d.pop("parameter_schema", UNSET))

        task_model = cls(
            name=name,
            project_id=project_id,
            user_id=user_id,
            scenario=scenario,
            created_at=created_at,
            id=id,
            description=description,
            updated_at=updated_at,
            version=version,
            notebook=notebook,
            connections=connections,
            runs=runs,
            parameter_schema=parameter_schema,
        )

        task_model.additional_properties = d
        return task_model

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
