from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.datalake_connection_info_backendtype import DatalakeConnectionInfoBackendtype
from ..types import UNSET, Unset

T = TypeVar("T", bound="DatalakeConnectionInfo")


@_attrs_define
class DatalakeConnectionInfo:
    """Connection information for a datalake backend.

    Frontend DuckDB WASM can use this to attach directly to the datalake.

    For DuckLake:
    ```sql
    INSTALL ducklake; LOAD ducklake;
    SET s3_access_key_id = '{s3_access_key_id}';
    SET s3_secret_access_key = '{s3_secret_access_key}';
    SET s3_endpoint = '{s3_endpoint}';
    ATTACH 'ducklake:{catalog_connection}' AS datalake (DATA_PATH '{data_path}');
    SELECT * FROM datalake.dataset_{dataset_id};
    ```

    For Parquet:
    ```sql
    SELECT * FROM read_parquet('{parquet_url}');
    ```

        Attributes:
            backend_type (DatalakeConnectionInfoBackendtype): Type of datalake backend
            catalog_connection (None | str | Unset): DuckLake catalog connection string (PostgreSQL)
            catalog_path (None | str | Unset): DuckLake catalog file path on S3 (read-only for browser)
            catalog_presigned_url (None | str | Unset): Pre-signed URL for catalog file (browser access)
            data_path (None | str | Unset): Path to Parquet data files
            ducklake_name (None | str | Unset): Name for the attached DuckLake database
            s_3_access_key_id (None | str | Unset): S3 access key ID
            s_3_secret_access_key (None | str | Unset): S3 secret access key
            s_3_endpoint (None | str | Unset): S3 endpoint URL
            s_3_region (None | str | Unset): S3 region
            parquet_url (None | str | Unset): Direct URL to Parquet file(s)
            project_id (None | str | Unset): Project ID for isolation
    """

    backend_type: DatalakeConnectionInfoBackendtype
    catalog_connection: None | str | Unset = UNSET
    catalog_path: None | str | Unset = UNSET
    catalog_presigned_url: None | str | Unset = UNSET
    data_path: None | str | Unset = UNSET
    ducklake_name: None | str | Unset = UNSET
    s_3_access_key_id: None | str | Unset = UNSET
    s_3_secret_access_key: None | str | Unset = UNSET
    s_3_endpoint: None | str | Unset = UNSET
    s_3_region: None | str | Unset = UNSET
    parquet_url: None | str | Unset = UNSET
    project_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        backend_type = self.backend_type.value

        catalog_connection: None | str | Unset
        if isinstance(self.catalog_connection, Unset):
            catalog_connection = UNSET
        else:
            catalog_connection = self.catalog_connection

        catalog_path: None | str | Unset
        if isinstance(self.catalog_path, Unset):
            catalog_path = UNSET
        else:
            catalog_path = self.catalog_path

        catalog_presigned_url: None | str | Unset
        if isinstance(self.catalog_presigned_url, Unset):
            catalog_presigned_url = UNSET
        else:
            catalog_presigned_url = self.catalog_presigned_url

        data_path: None | str | Unset
        if isinstance(self.data_path, Unset):
            data_path = UNSET
        else:
            data_path = self.data_path

        ducklake_name: None | str | Unset
        if isinstance(self.ducklake_name, Unset):
            ducklake_name = UNSET
        else:
            ducklake_name = self.ducklake_name

        s_3_access_key_id: None | str | Unset
        if isinstance(self.s_3_access_key_id, Unset):
            s_3_access_key_id = UNSET
        else:
            s_3_access_key_id = self.s_3_access_key_id

        s_3_secret_access_key: None | str | Unset
        if isinstance(self.s_3_secret_access_key, Unset):
            s_3_secret_access_key = UNSET
        else:
            s_3_secret_access_key = self.s_3_secret_access_key

        s_3_endpoint: None | str | Unset
        if isinstance(self.s_3_endpoint, Unset):
            s_3_endpoint = UNSET
        else:
            s_3_endpoint = self.s_3_endpoint

        s_3_region: None | str | Unset
        if isinstance(self.s_3_region, Unset):
            s_3_region = UNSET
        else:
            s_3_region = self.s_3_region

        parquet_url: None | str | Unset
        if isinstance(self.parquet_url, Unset):
            parquet_url = UNSET
        else:
            parquet_url = self.parquet_url

        project_id: None | str | Unset
        if isinstance(self.project_id, Unset):
            project_id = UNSET
        else:
            project_id = self.project_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "backendType": backend_type,
            }
        )
        if catalog_connection is not UNSET:
            field_dict["catalogConnection"] = catalog_connection
        if catalog_path is not UNSET:
            field_dict["catalogPath"] = catalog_path
        if catalog_presigned_url is not UNSET:
            field_dict["catalogPresignedUrl"] = catalog_presigned_url
        if data_path is not UNSET:
            field_dict["dataPath"] = data_path
        if ducklake_name is not UNSET:
            field_dict["ducklakeName"] = ducklake_name
        if s_3_access_key_id is not UNSET:
            field_dict["s3AccessKeyId"] = s_3_access_key_id
        if s_3_secret_access_key is not UNSET:
            field_dict["s3SecretAccessKey"] = s_3_secret_access_key
        if s_3_endpoint is not UNSET:
            field_dict["s3Endpoint"] = s_3_endpoint
        if s_3_region is not UNSET:
            field_dict["s3Region"] = s_3_region
        if parquet_url is not UNSET:
            field_dict["parquetUrl"] = parquet_url
        if project_id is not UNSET:
            field_dict["projectId"] = project_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        backend_type = DatalakeConnectionInfoBackendtype(d.pop("backendType"))

        def _parse_catalog_connection(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        catalog_connection = _parse_catalog_connection(d.pop("catalogConnection", UNSET))

        def _parse_catalog_path(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        catalog_path = _parse_catalog_path(d.pop("catalogPath", UNSET))

        def _parse_catalog_presigned_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        catalog_presigned_url = _parse_catalog_presigned_url(d.pop("catalogPresignedUrl", UNSET))

        def _parse_data_path(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        data_path = _parse_data_path(d.pop("dataPath", UNSET))

        def _parse_ducklake_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ducklake_name = _parse_ducklake_name(d.pop("ducklakeName", UNSET))

        def _parse_s_3_access_key_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        s_3_access_key_id = _parse_s_3_access_key_id(d.pop("s3AccessKeyId", UNSET))

        def _parse_s_3_secret_access_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        s_3_secret_access_key = _parse_s_3_secret_access_key(d.pop("s3SecretAccessKey", UNSET))

        def _parse_s_3_endpoint(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        s_3_endpoint = _parse_s_3_endpoint(d.pop("s3Endpoint", UNSET))

        def _parse_s_3_region(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        s_3_region = _parse_s_3_region(d.pop("s3Region", UNSET))

        def _parse_parquet_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parquet_url = _parse_parquet_url(d.pop("parquetUrl", UNSET))

        def _parse_project_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        project_id = _parse_project_id(d.pop("projectId", UNSET))

        datalake_connection_info = cls(
            backend_type=backend_type,
            catalog_connection=catalog_connection,
            catalog_path=catalog_path,
            catalog_presigned_url=catalog_presigned_url,
            data_path=data_path,
            ducklake_name=ducklake_name,
            s_3_access_key_id=s_3_access_key_id,
            s_3_secret_access_key=s_3_secret_access_key,
            s_3_endpoint=s_3_endpoint,
            s_3_region=s_3_region,
            parquet_url=parquet_url,
            project_id=project_id,
        )

        datalake_connection_info.additional_properties = d
        return datalake_connection_info

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
