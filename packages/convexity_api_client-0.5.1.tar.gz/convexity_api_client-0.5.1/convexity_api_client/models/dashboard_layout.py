from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.layout_item import LayoutItem


T = TypeVar("T", bound="DashboardLayout")


@_attrs_define
class DashboardLayout:
    """Dashboard layout configuration with grid settings.

    Attributes:
        type_ (Literal['dashboard_layout'] | Unset): Model type discriminator Default: 'dashboard_layout'.
        columns (int | Unset): Number of columns in the grid Default: 24.
        layouts (list[LayoutItem] | Unset): Widget layout items
    """

    type_: Literal["dashboard_layout"] | Unset = "dashboard_layout"
    columns: int | Unset = 24
    layouts: list[LayoutItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        columns = self.columns

        layouts: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.layouts, Unset):
            layouts = []
            for layouts_item_data in self.layouts:
                layouts_item = layouts_item_data.to_dict()
                layouts.append(layouts_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if columns is not UNSET:
            field_dict["columns"] = columns
        if layouts is not UNSET:
            field_dict["layouts"] = layouts

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.layout_item import LayoutItem

        d = dict(src_dict)
        type_ = cast(Literal["dashboard_layout"] | Unset, d.pop("type", UNSET))
        if type_ != "dashboard_layout" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'dashboard_layout', got '{type_}'")

        columns = d.pop("columns", UNSET)

        _layouts = d.pop("layouts", UNSET)
        layouts: list[LayoutItem] | Unset = UNSET
        if _layouts is not UNSET:
            layouts = []
            for layouts_item_data in _layouts:
                layouts_item = LayoutItem.from_dict(layouts_item_data)

                layouts.append(layouts_item)

        dashboard_layout = cls(
            type_=type_,
            columns=columns,
            layouts=layouts,
        )

        dashboard_layout.additional_properties = d
        return dashboard_layout

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
