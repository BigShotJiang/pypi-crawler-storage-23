from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="CleanupRunsResponse")


@_attrs_define
class CleanupRunsResponse:
    """Response model for cleanup operation.

    Attributes:
        success (bool):
        cleaned_up (int):
        message (str):
    """

    success: bool
    cleaned_up: int
    message: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        success = self.success

        cleaned_up = self.cleaned_up

        message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "success": success,
                "cleaned_up": cleaned_up,
                "message": message,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        success = d.pop("success")

        cleaned_up = d.pop("cleaned_up")

        message = d.pop("message")

        cleanup_runs_response = cls(
            success=success,
            cleaned_up=cleaned_up,
            message=message,
        )

        cleanup_runs_response.additional_properties = d
        return cleanup_runs_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
