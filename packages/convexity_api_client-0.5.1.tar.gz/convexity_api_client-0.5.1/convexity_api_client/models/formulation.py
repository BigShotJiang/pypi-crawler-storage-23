from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.profile import Profile


T = TypeVar("T", bound="Formulation")


@_attrs_define
class Formulation:
    """Represents a Formulation record

    Attributes:
        id (str):
        name (str):
        created_at (datetime.datetime):
        user_id (str):
        workspace_id (str):
        problem (None | str | Unset):
        objective (None | str | Unset):
        variables (None | str | Unset):
        parameters (None | str | Unset):
        constraints (None | str | Unset):
        dataset (None | str | Unset):
        code (None | str | Unset):
        output (None | str | Unset):
        error (None | str | Unset):
        report (None | str | Unset):
        profiles (None | Profile | Unset):
    """

    id: str
    name: str
    created_at: datetime.datetime
    user_id: str
    workspace_id: str
    problem: None | str | Unset = UNSET
    objective: None | str | Unset = UNSET
    variables: None | str | Unset = UNSET
    parameters: None | str | Unset = UNSET
    constraints: None | str | Unset = UNSET
    dataset: None | str | Unset = UNSET
    code: None | str | Unset = UNSET
    output: None | str | Unset = UNSET
    error: None | str | Unset = UNSET
    report: None | str | Unset = UNSET
    profiles: None | Profile | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.profile import Profile

        id = self.id

        name = self.name

        created_at = self.created_at.isoformat()

        user_id = self.user_id

        workspace_id = self.workspace_id

        problem: None | str | Unset
        if isinstance(self.problem, Unset):
            problem = UNSET
        else:
            problem = self.problem

        objective: None | str | Unset
        if isinstance(self.objective, Unset):
            objective = UNSET
        else:
            objective = self.objective

        variables: None | str | Unset
        if isinstance(self.variables, Unset):
            variables = UNSET
        else:
            variables = self.variables

        parameters: None | str | Unset
        if isinstance(self.parameters, Unset):
            parameters = UNSET
        else:
            parameters = self.parameters

        constraints: None | str | Unset
        if isinstance(self.constraints, Unset):
            constraints = UNSET
        else:
            constraints = self.constraints

        dataset: None | str | Unset
        if isinstance(self.dataset, Unset):
            dataset = UNSET
        else:
            dataset = self.dataset

        code: None | str | Unset
        if isinstance(self.code, Unset):
            code = UNSET
        else:
            code = self.code

        output: None | str | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        else:
            output = self.output

        error: None | str | Unset
        if isinstance(self.error, Unset):
            error = UNSET
        else:
            error = self.error

        report: None | str | Unset
        if isinstance(self.report, Unset):
            report = UNSET
        else:
            report = self.report

        profiles: dict[str, Any] | None | Unset
        if isinstance(self.profiles, Unset):
            profiles = UNSET
        elif isinstance(self.profiles, Profile):
            profiles = self.profiles.to_dict()
        else:
            profiles = self.profiles

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "created_at": created_at,
                "user_id": user_id,
                "workspace_id": workspace_id,
            }
        )
        if problem is not UNSET:
            field_dict["problem"] = problem
        if objective is not UNSET:
            field_dict["objective"] = objective
        if variables is not UNSET:
            field_dict["variables"] = variables
        if parameters is not UNSET:
            field_dict["parameters"] = parameters
        if constraints is not UNSET:
            field_dict["constraints"] = constraints
        if dataset is not UNSET:
            field_dict["dataset"] = dataset
        if code is not UNSET:
            field_dict["code"] = code
        if output is not UNSET:
            field_dict["output"] = output
        if error is not UNSET:
            field_dict["error"] = error
        if report is not UNSET:
            field_dict["report"] = report
        if profiles is not UNSET:
            field_dict["profiles"] = profiles

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.profile import Profile

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        created_at = isoparse(d.pop("created_at"))

        user_id = d.pop("user_id")

        workspace_id = d.pop("workspace_id")

        def _parse_problem(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        problem = _parse_problem(d.pop("problem", UNSET))

        def _parse_objective(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        objective = _parse_objective(d.pop("objective", UNSET))

        def _parse_variables(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        variables = _parse_variables(d.pop("variables", UNSET))

        def _parse_parameters(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parameters = _parse_parameters(d.pop("parameters", UNSET))

        def _parse_constraints(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        constraints = _parse_constraints(d.pop("constraints", UNSET))

        def _parse_dataset(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        dataset = _parse_dataset(d.pop("dataset", UNSET))

        def _parse_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        code = _parse_code(d.pop("code", UNSET))

        def _parse_output(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        output = _parse_output(d.pop("output", UNSET))

        def _parse_error(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error = _parse_error(d.pop("error", UNSET))

        def _parse_report(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        report = _parse_report(d.pop("report", UNSET))

        def _parse_profiles(data: object) -> None | Profile | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                profiles_type_0 = Profile.from_dict(data)

                return profiles_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Profile | Unset, data)

        profiles = _parse_profiles(d.pop("profiles", UNSET))

        formulation = cls(
            id=id,
            name=name,
            created_at=created_at,
            user_id=user_id,
            workspace_id=workspace_id,
            problem=problem,
            objective=objective,
            variables=variables,
            parameters=parameters,
            constraints=constraints,
            dataset=dataset,
            code=code,
            output=output,
            error=error,
            report=report,
            profiles=profiles,
        )

        formulation.additional_properties = d
        return formulation

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
