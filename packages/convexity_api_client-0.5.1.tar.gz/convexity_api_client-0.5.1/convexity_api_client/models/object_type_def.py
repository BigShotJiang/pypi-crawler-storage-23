from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.object_type_def_checksum_algorithm_item import ObjectTypeDefChecksumAlgorithmItem
from ..models.object_type_def_checksumtype import ObjectTypeDefChecksumtype
from ..models.object_type_def_storageclass import ObjectTypeDefStorageclass
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.owner_type_def import OwnerTypeDef
    from ..models.restore_status_type_def import RestoreStatusTypeDef


T = TypeVar("T", bound="ObjectTypeDef")


@_attrs_define
class ObjectTypeDef:
    """
    Attributes:
        key (str | Unset):
        last_modified (datetime.datetime | Unset):
        e_tag (str | Unset):
        checksum_algorithm (list[ObjectTypeDefChecksumAlgorithmItem] | Unset):
        checksum_type (ObjectTypeDefChecksumtype | Unset):
        size (int | Unset):
        storage_class (ObjectTypeDefStorageclass | Unset):
        owner (OwnerTypeDef | Unset):
        restore_status (RestoreStatusTypeDef | Unset):
    """

    key: str | Unset = UNSET
    last_modified: datetime.datetime | Unset = UNSET
    e_tag: str | Unset = UNSET
    checksum_algorithm: list[ObjectTypeDefChecksumAlgorithmItem] | Unset = UNSET
    checksum_type: ObjectTypeDefChecksumtype | Unset = UNSET
    size: int | Unset = UNSET
    storage_class: ObjectTypeDefStorageclass | Unset = UNSET
    owner: OwnerTypeDef | Unset = UNSET
    restore_status: RestoreStatusTypeDef | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        key = self.key

        last_modified: str | Unset = UNSET
        if not isinstance(self.last_modified, Unset):
            last_modified = self.last_modified.isoformat()

        e_tag = self.e_tag

        checksum_algorithm: list[str] | Unset = UNSET
        if not isinstance(self.checksum_algorithm, Unset):
            checksum_algorithm = []
            for checksum_algorithm_item_data in self.checksum_algorithm:
                checksum_algorithm_item = checksum_algorithm_item_data.value
                checksum_algorithm.append(checksum_algorithm_item)

        checksum_type: str | Unset = UNSET
        if not isinstance(self.checksum_type, Unset):
            checksum_type = self.checksum_type.value

        size = self.size

        storage_class: str | Unset = UNSET
        if not isinstance(self.storage_class, Unset):
            storage_class = self.storage_class.value

        owner: dict[str, Any] | Unset = UNSET
        if not isinstance(self.owner, Unset):
            owner = self.owner.to_dict()

        restore_status: dict[str, Any] | Unset = UNSET
        if not isinstance(self.restore_status, Unset):
            restore_status = self.restore_status.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if key is not UNSET:
            field_dict["Key"] = key
        if last_modified is not UNSET:
            field_dict["LastModified"] = last_modified
        if e_tag is not UNSET:
            field_dict["ETag"] = e_tag
        if checksum_algorithm is not UNSET:
            field_dict["ChecksumAlgorithm"] = checksum_algorithm
        if checksum_type is not UNSET:
            field_dict["ChecksumType"] = checksum_type
        if size is not UNSET:
            field_dict["Size"] = size
        if storage_class is not UNSET:
            field_dict["StorageClass"] = storage_class
        if owner is not UNSET:
            field_dict["Owner"] = owner
        if restore_status is not UNSET:
            field_dict["RestoreStatus"] = restore_status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.owner_type_def import OwnerTypeDef
        from ..models.restore_status_type_def import RestoreStatusTypeDef

        d = dict(src_dict)
        key = d.pop("Key", UNSET)

        _last_modified = d.pop("LastModified", UNSET)
        last_modified: datetime.datetime | Unset
        if isinstance(_last_modified, Unset):
            last_modified = UNSET
        else:
            last_modified = isoparse(_last_modified)

        e_tag = d.pop("ETag", UNSET)

        _checksum_algorithm = d.pop("ChecksumAlgorithm", UNSET)
        checksum_algorithm: list[ObjectTypeDefChecksumAlgorithmItem] | Unset = UNSET
        if _checksum_algorithm is not UNSET:
            checksum_algorithm = []
            for checksum_algorithm_item_data in _checksum_algorithm:
                checksum_algorithm_item = ObjectTypeDefChecksumAlgorithmItem(checksum_algorithm_item_data)

                checksum_algorithm.append(checksum_algorithm_item)

        _checksum_type = d.pop("ChecksumType", UNSET)
        checksum_type: ObjectTypeDefChecksumtype | Unset
        if isinstance(_checksum_type, Unset):
            checksum_type = UNSET
        else:
            checksum_type = ObjectTypeDefChecksumtype(_checksum_type)

        size = d.pop("Size", UNSET)

        _storage_class = d.pop("StorageClass", UNSET)
        storage_class: ObjectTypeDefStorageclass | Unset
        if isinstance(_storage_class, Unset):
            storage_class = UNSET
        else:
            storage_class = ObjectTypeDefStorageclass(_storage_class)

        _owner = d.pop("Owner", UNSET)
        owner: OwnerTypeDef | Unset
        if isinstance(_owner, Unset):
            owner = UNSET
        else:
            owner = OwnerTypeDef.from_dict(_owner)

        _restore_status = d.pop("RestoreStatus", UNSET)
        restore_status: RestoreStatusTypeDef | Unset
        if isinstance(_restore_status, Unset):
            restore_status = UNSET
        else:
            restore_status = RestoreStatusTypeDef.from_dict(_restore_status)

        object_type_def = cls(
            key=key,
            last_modified=last_modified,
            e_tag=e_tag,
            checksum_algorithm=checksum_algorithm,
            checksum_type=checksum_type,
            size=size,
            storage_class=storage_class,
            owner=owner,
            restore_status=restore_status,
        )

        object_type_def.additional_properties = d
        return object_type_def

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
