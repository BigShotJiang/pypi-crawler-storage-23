from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="BatchDeleteRunsResponse")


@_attrs_define
class BatchDeleteRunsResponse:
    """Response model for batch deleting runs.

    Attributes:
        success (bool):
        deleted_count (int):
        failed_count (int):
        failed_runs (list[str]):
        message (str):
    """

    success: bool
    deleted_count: int
    failed_count: int
    failed_runs: list[str]
    message: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        success = self.success

        deleted_count = self.deleted_count

        failed_count = self.failed_count

        failed_runs = self.failed_runs

        message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "success": success,
                "deleted_count": deleted_count,
                "failed_count": failed_count,
                "failed_runs": failed_runs,
                "message": message,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        success = d.pop("success")

        deleted_count = d.pop("deleted_count")

        failed_count = d.pop("failed_count")

        failed_runs = cast(list[str], d.pop("failed_runs"))

        message = d.pop("message")

        batch_delete_runs_response = cls(
            success=success,
            deleted_count=deleted_count,
            failed_count=failed_count,
            failed_runs=failed_runs,
            message=message,
        )

        batch_delete_runs_response.additional_properties = d
        return batch_delete_runs_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
