from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.notebook_cell import NotebookCell
    from ..models.notebook_document_metadata import NotebookDocumentMetadata


T = TypeVar("T", bound="NotebookDocument")


@_attrs_define
class NotebookDocument:
    """Notebook document with cells.

    Attributes:
        schema_version (int | Unset): Schema version for migration support Default: 1.
        cells (list[NotebookCell] | Unset):
        metadata (NotebookDocumentMetadata | Unset):
    """

    schema_version: int | Unset = 1
    cells: list[NotebookCell] | Unset = UNSET
    metadata: NotebookDocumentMetadata | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        schema_version = self.schema_version

        cells: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.cells, Unset):
            cells = []
            for cells_item_data in self.cells:
                cells_item = cells_item_data.to_dict()
                cells.append(cells_item)

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if schema_version is not UNSET:
            field_dict["schema_version"] = schema_version
        if cells is not UNSET:
            field_dict["cells"] = cells
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.notebook_cell import NotebookCell
        from ..models.notebook_document_metadata import NotebookDocumentMetadata

        d = dict(src_dict)
        schema_version = d.pop("schema_version", UNSET)

        _cells = d.pop("cells", UNSET)
        cells: list[NotebookCell] | Unset = UNSET
        if _cells is not UNSET:
            cells = []
            for cells_item_data in _cells:
                cells_item = NotebookCell.from_dict(cells_item_data)

                cells.append(cells_item)

        _metadata = d.pop("metadata", UNSET)
        metadata: NotebookDocumentMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = NotebookDocumentMetadata.from_dict(_metadata)

        notebook_document = cls(
            schema_version=schema_version,
            cells=cells,
            metadata=metadata,
        )

        notebook_document.additional_properties = d
        return notebook_document

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
