from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.connection_dto import ConnectionDTO
    from ..models.task_dto import TaskDTO


T = TypeVar("T", bound="TaskConnection")


@_attrs_define
class TaskConnection:
    """Represents a TaskConnection record

    Attributes:
        task_id (str):
        connection_id (str):
        created_at (datetime.datetime):
        purpose (None | str | Unset):
        task (None | TaskDTO | Unset):
        connection (ConnectionDTO | None | Unset):
    """

    task_id: str
    connection_id: str
    created_at: datetime.datetime
    purpose: None | str | Unset = UNSET
    task: None | TaskDTO | Unset = UNSET
    connection: ConnectionDTO | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.connection_dto import ConnectionDTO
        from ..models.task_dto import TaskDTO

        task_id = self.task_id

        connection_id = self.connection_id

        created_at = self.created_at.isoformat()

        purpose: None | str | Unset
        if isinstance(self.purpose, Unset):
            purpose = UNSET
        else:
            purpose = self.purpose

        task: dict[str, Any] | None | Unset
        if isinstance(self.task, Unset):
            task = UNSET
        elif isinstance(self.task, TaskDTO):
            task = self.task.to_dict()
        else:
            task = self.task

        connection: dict[str, Any] | None | Unset
        if isinstance(self.connection, Unset):
            connection = UNSET
        elif isinstance(self.connection, ConnectionDTO):
            connection = self.connection.to_dict()
        else:
            connection = self.connection

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "task_id": task_id,
                "connection_id": connection_id,
                "created_at": created_at,
            }
        )
        if purpose is not UNSET:
            field_dict["purpose"] = purpose
        if task is not UNSET:
            field_dict["task"] = task
        if connection is not UNSET:
            field_dict["connection"] = connection

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.connection_dto import ConnectionDTO
        from ..models.task_dto import TaskDTO

        d = dict(src_dict)
        task_id = d.pop("task_id")

        connection_id = d.pop("connection_id")

        created_at = isoparse(d.pop("created_at"))

        def _parse_purpose(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        purpose = _parse_purpose(d.pop("purpose", UNSET))

        def _parse_task(data: object) -> None | TaskDTO | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                task_type_0 = TaskDTO.from_dict(data)

                return task_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TaskDTO | Unset, data)

        task = _parse_task(d.pop("task", UNSET))

        def _parse_connection(data: object) -> ConnectionDTO | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                connection_type_0 = ConnectionDTO.from_dict(data)

                return connection_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ConnectionDTO | None | Unset, data)

        connection = _parse_connection(d.pop("connection", UNSET))

        task_connection = cls(
            task_id=task_id,
            connection_id=connection_id,
            created_at=created_at,
            purpose=purpose,
            task=task,
            connection=connection,
        )

        task_connection.additional_properties = d
        return task_connection

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
