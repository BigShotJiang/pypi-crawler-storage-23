from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.column import Column
    from ..models.sql_query_response_rows_item import SqlQueryResponseRowsItem


T = TypeVar("T", bound="SqlQueryResponse")


@_attrs_define
class SqlQueryResponse:
    """Result set returned from a SQL query.

    Attributes:
        columns (list[str]):
        rows (list[SqlQueryResponseRowsItem]):
        row_count (int):
        schema (list[Column] | None | Unset): Inferred column schema from data
    """

    columns: list[str]
    rows: list[SqlQueryResponseRowsItem]
    row_count: int
    schema: list[Column] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        columns = self.columns

        rows = []
        for rows_item_data in self.rows:
            rows_item = rows_item_data.to_dict()
            rows.append(rows_item)

        row_count = self.row_count

        schema: list[dict[str, Any]] | None | Unset
        if isinstance(self.schema, Unset):
            schema = UNSET
        elif isinstance(self.schema, list):
            schema = []
            for schema_type_0_item_data in self.schema:
                schema_type_0_item = schema_type_0_item_data.to_dict()
                schema.append(schema_type_0_item)

        else:
            schema = self.schema

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "columns": columns,
                "rows": rows,
                "rowCount": row_count,
            }
        )
        if schema is not UNSET:
            field_dict["schema"] = schema

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.column import Column
        from ..models.sql_query_response_rows_item import SqlQueryResponseRowsItem

        d = dict(src_dict)
        columns = cast(list[str], d.pop("columns"))

        rows = []
        _rows = d.pop("rows")
        for rows_item_data in _rows:
            rows_item = SqlQueryResponseRowsItem.from_dict(rows_item_data)

            rows.append(rows_item)

        row_count = d.pop("rowCount")

        def _parse_schema(data: object) -> list[Column] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                schema_type_0 = []
                _schema_type_0 = data
                for schema_type_0_item_data in _schema_type_0:
                    schema_type_0_item = Column.from_dict(schema_type_0_item_data)

                    schema_type_0.append(schema_type_0_item)

                return schema_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[Column] | None | Unset, data)

        schema = _parse_schema(d.pop("schema", UNSET))

        sql_query_response = cls(
            columns=columns,
            rows=rows,
            row_count=row_count,
            schema=schema,
        )

        sql_query_response.additional_properties = d
        return sql_query_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
