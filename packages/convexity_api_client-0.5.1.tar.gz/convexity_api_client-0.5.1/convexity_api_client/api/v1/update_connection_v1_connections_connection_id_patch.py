from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_connection import ApiConnection
from ...models.database_connection import DatabaseConnection
from ...models.databricks_connection import DatabricksConnection
from ...models.file_connection import FileConnection
from ...models.http_validation_error import HTTPValidationError
from ...models.s3_connection import S3Connection
from ...models.update_connection_request import UpdateConnectionRequest
from ...models.webhook_connection import WebhookConnection
from ...types import UNSET, Response


def _get_kwargs(
    connection_id: str,
    *,
    body: UpdateConnectionRequest,
    project_id: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/connections/{connection_id}".format(
            connection_id=quote(str(connection_id), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    ApiConnection
    | DatabaseConnection
    | DatabricksConnection
    | FileConnection
    | S3Connection
    | WebhookConnection
    | HTTPValidationError
    | None
):
    if response.status_code == 200:

        def _parse_response_200(
            data: object,
        ) -> (
            ApiConnection
            | DatabaseConnection
            | DatabricksConnection
            | FileConnection
            | S3Connection
            | WebhookConnection
        ):
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_0 = DatabaseConnection.from_dict(data)

                return response_200_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_1 = S3Connection.from_dict(data)

                return response_200_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_2 = ApiConnection.from_dict(data)

                return response_200_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_3 = WebhookConnection.from_dict(data)

                return response_200_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_200_type_4 = FileConnection.from_dict(data)

                return response_200_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_200_type_5 = DatabricksConnection.from_dict(data)

            return response_200_type_5

        response_200 = _parse_response_200(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    ApiConnection
    | DatabaseConnection
    | DatabricksConnection
    | FileConnection
    | S3Connection
    | WebhookConnection
    | HTTPValidationError
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConnectionRequest,
    project_id: str,
) -> Response[
    ApiConnection
    | DatabaseConnection
    | DatabricksConnection
    | FileConnection
    | S3Connection
    | WebhookConnection
    | HTTPValidationError
]:
    """Update Connection

     Update a connection's basic fields. Requires member role or above.

    This endpoint updates common fields (name, description) for any connection type.
    For type-specific fields, use the type-specific update endpoints.

    Args:
        connection_id (str):
        project_id (str):
        body (UpdateConnectionRequest): Generic connection update request for updating basic
            fields on any connection type.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection | WebhookConnection | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        body=body,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConnectionRequest,
    project_id: str,
) -> (
    ApiConnection
    | DatabaseConnection
    | DatabricksConnection
    | FileConnection
    | S3Connection
    | WebhookConnection
    | HTTPValidationError
    | None
):
    """Update Connection

     Update a connection's basic fields. Requires member role or above.

    This endpoint updates common fields (name, description) for any connection type.
    For type-specific fields, use the type-specific update endpoints.

    Args:
        connection_id (str):
        project_id (str):
        body (UpdateConnectionRequest): Generic connection update request for updating basic
            fields on any connection type.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection | WebhookConnection | HTTPValidationError
    """

    return sync_detailed(
        connection_id=connection_id,
        client=client,
        body=body,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConnectionRequest,
    project_id: str,
) -> Response[
    ApiConnection
    | DatabaseConnection
    | DatabricksConnection
    | FileConnection
    | S3Connection
    | WebhookConnection
    | HTTPValidationError
]:
    """Update Connection

     Update a connection's basic fields. Requires member role or above.

    This endpoint updates common fields (name, description) for any connection type.
    For type-specific fields, use the type-specific update endpoints.

    Args:
        connection_id (str):
        project_id (str):
        body (UpdateConnectionRequest): Generic connection update request for updating basic
            fields on any connection type.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection | WebhookConnection | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        connection_id=connection_id,
        body=body,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    connection_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateConnectionRequest,
    project_id: str,
) -> (
    ApiConnection
    | DatabaseConnection
    | DatabricksConnection
    | FileConnection
    | S3Connection
    | WebhookConnection
    | HTTPValidationError
    | None
):
    """Update Connection

     Update a connection's basic fields. Requires member role or above.

    This endpoint updates common fields (name, description) for any connection type.
    For type-specific fields, use the type-specific update endpoints.

    Args:
        connection_id (str):
        project_id (str):
        body (UpdateConnectionRequest): Generic connection update request for updating basic
            fields on any connection type.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ApiConnection | DatabaseConnection | DatabricksConnection | FileConnection | S3Connection | WebhookConnection | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            connection_id=connection_id,
            client=client,
            body=body,
            project_id=project_id,
        )
    ).parsed
