This addon allows to define analytic distribution models using
brands in their domains.
