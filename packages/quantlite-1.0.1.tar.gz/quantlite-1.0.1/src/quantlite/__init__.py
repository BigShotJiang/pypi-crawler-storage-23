"""QuantLite: a fat-tail-native quantitative finance toolkit.

Provides stochastic process generators, option and bond pricing,
risk metrics, extreme value theory, fat-tailed distributions,
portfolio optimisation, multi-asset backtesting, and
Stephen Few-inspired visualisation.
"""

__version__ = "1.0.1"

from .backtesting import (
    BacktestConfig,
    BacktestContext,
    BacktestResult,
    RiskLimits,
    SlippageModel,
    run_backtest,
)
from .data_generation import (
    correlated_gbm,
    geometric_brownian_motion,
    merton_jump_diffusion,
    ornstein_uhlenbeck,
)
from .instruments.bond_pricing import bond_price, bond_yield_to_maturity
from .instruments.option_pricing import (
    black_scholes_call,
    black_scholes_greeks,
    black_scholes_put,
)
from .metrics import annualised_return, annualised_volatility, max_drawdown, sharpe_ratio
from .visualisation import plot_time_series

__all__ = [
    # Data generation
    "geometric_brownian_motion",
    "correlated_gbm",
    "ornstein_uhlenbeck",
    "merton_jump_diffusion",
    # Instruments
    "black_scholes_call",
    "black_scholes_put",
    "black_scholes_greeks",
    "bond_price",
    "bond_yield_to_maturity",
    # Metrics
    "annualised_return",
    "annualised_volatility",
    "sharpe_ratio",
    "max_drawdown",
    # Backtesting
    "run_backtest",
    "BacktestConfig",
    "BacktestContext",
    "BacktestResult",
    "RiskLimits",
    "SlippageModel",
    # Visualisation
    "plot_time_series",
    # Ergodicity economics
    "ergodicity",
    # Antifragility framework
    "antifragile",
    # Scenario engine
    "scenarios",
    # Strategy forensics
    "forensics",
    # Overfitting detection
    "overfit",
    # Resampled backtesting
    "resample",
    # Contagion metrics
    "contagion",
    # Network risk
    "network",
    # Diversification analysis
    "diversification",
    # Crypto-native risk
    "crypto",
    # Fat-tail Monte Carlo simulation
    "simulation",
    # Regime-aware integration
    "regime_integration",
    # Dream API (pipeline)
    "fetch",
    "detect_regimes",
    "construct_portfolio",
    "backtest",
    "tearsheet",
]

from . import (  # noqa: E402
    antifragile,
    contagion,
    crypto,
    diversification,
    ergodicity,
    forensics,
    network,
    overfit,
    regime_integration,
    resample,
    scenarios,
    simulation,
)
from .pipeline import (  # noqa: E402
    backtest,
    construct_portfolio,
    detect_regimes,
    tearsheet,
)
from .pipeline import fetch as fetch  # noqa: E402
