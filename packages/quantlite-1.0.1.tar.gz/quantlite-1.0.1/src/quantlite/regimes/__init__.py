"""Regime detection: hidden Markov models, change points, and conditional metrics."""
