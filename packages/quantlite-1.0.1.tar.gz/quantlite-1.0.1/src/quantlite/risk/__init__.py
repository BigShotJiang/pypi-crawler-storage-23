"""Risk analytics: metrics, extreme value theory, and tail analysis."""
