# claude-relay (compatibility package)

Deprecated compatibility package. Install `agentrelay-cli` for canonical updates.
