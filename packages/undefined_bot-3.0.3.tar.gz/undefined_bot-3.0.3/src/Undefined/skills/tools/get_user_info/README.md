# get_user_info 工具

用于查询 QQ 用户的详细信息。

常用参数：
- `user_id`：要查询的 QQ 号
- `no_cache`：是否跳过缓存获取最新信息

目录结构：
- `config.json`：工具定义
- `handler.py`：执行逻辑
