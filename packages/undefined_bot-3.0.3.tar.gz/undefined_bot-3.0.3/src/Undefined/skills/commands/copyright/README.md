# /copyright 命令说明

## 功能
输出项目版权信息、开源协议与风险免责声明。

## 用法
- `/copyright`

## 示例
- `/copyright`
- `/license`
- `/about`
- `/cprt`

## 说明
- 命令内容来源于项目 `README.md` 的免责声明章节与仓库公开信息。
- 用于在群内快速查看项目合规提示与版权声明。
