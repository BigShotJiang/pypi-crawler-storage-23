# 源码目录

此目录包含项目的 Python 源码与主包。

- 主包路径：`src/Undefined/`
- 启动入口：`Undefined.main:run`
- 常用启动：`uv run -m Undefined`

源码内模块进一步说明见 `src/Undefined/README.md`。
