"""NeuroCore project scaffolding.

Templates and logic for `neurocore init` — generates a new
project with config, .env, logging, and directory structure.
"""
