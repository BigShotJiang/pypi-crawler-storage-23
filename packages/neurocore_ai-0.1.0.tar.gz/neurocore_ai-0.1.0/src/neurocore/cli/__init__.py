"""NeuroCore CLI.

Typer-based command-line interface providing:
- neurocore init     — scaffold a new project
- neurocore run      — execute a blueprint
- neurocore skill    — list/inspect discovered skills
- neurocore validate — validate a blueprint without executing
- neurocore version  — show version info
"""
