Tools intended for TA-Lib maintainers.

If you only want to install and use TA-Lib, there is nothing here for you... check instead the main README.md file.
