from enum import Enum

class ChargeStrategy(str, Enum):
    ABSORB = "absorb"
    PASS = "pass"
    SPLIT = "split"

class Currency(str, Enum):
    NGN = "NGN"
    GHS = "GHS"
    ZAR = "ZAR"
    KES = "KES"
    USD = "USD"

class RecipientType(str, Enum):
    NUBAN = "nuban"
    MOBILE_MONEY = "mobile_money"
    BASA = "basa"

class TransferSource(str, Enum):
    BALANCE = "balance"


class Interval(str, Enum):
    HOURLY = "hourly"
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    BIANNUALLY = "biannually"
    ANNUALLY = "annually"