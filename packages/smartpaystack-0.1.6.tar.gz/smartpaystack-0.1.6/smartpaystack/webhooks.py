import hmac
import hashlib
import json
from typing import Dict, Any
from .exceptions import WebhookVerificationError

class WebhookVerifier:
    """A framework-agnostic utility for validating Paystack webhook signatures."""
    
    def __init__(self, secret_key: str):
        self.secret_key = secret_key.encode("utf-8")

    def verify_and_parse(self, payload: bytes, signature: str) -> Dict[str, Any]:
        if not signature:
            raise WebhookVerificationError("Missing Paystack signature header")

        # Paystack uses HMAC SHA512 to sign webhooks
        hash_obj = hmac.new(self.secret_key, msg=payload, digestmod=hashlib.sha512)
        
        if not hmac.compare_digest(hash_obj.hexdigest(), signature):
            raise WebhookVerificationError("Invalid Paystack webhook signature")

        try:
            return json.loads(payload)
        except json.JSONDecodeError:
            raise WebhookVerificationError("Invalid JSON payload")