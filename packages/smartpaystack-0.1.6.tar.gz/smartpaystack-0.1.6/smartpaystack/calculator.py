from decimal import Decimal, ROUND_HALF_UP
from .enums import Currency
from .config import CURRENCY_RULES

class PaystackFeeCalculator:
    """Calculates Paystack transaction fees accurately to avoid floating-point errors."""
    
    @classmethod
    def calculate_fee(cls, amount: Decimal, currency: Currency = Currency.NGN) -> Decimal:
        rule = CURRENCY_RULES.get(currency, CURRENCY_RULES[Currency.NGN])
        amount = Decimal(str(amount))
        
        fee = amount * rule["percentage"]

        if rule["flat_fee"] > 0 and amount >= rule["threshold"]:
            fee += rule["flat_fee"]

        if rule["cap"] is not None:
            fee = min(fee, rule["cap"])

        return fee.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    @classmethod
    def gross_up_amount(cls, desired_amount: Decimal, currency: Currency = Currency.NGN) -> Decimal:
        """Calculates the exact amount to charge a customer so the merchant receives the `desired_amount`."""
        rule = CURRENCY_RULES.get(currency, CURRENCY_RULES[Currency.NGN])
        desired_amount = Decimal(str(desired_amount))
        
        gross = desired_amount / (Decimal("1") - rule["percentage"])
        
        if rule["flat_fee"] > 0 and gross >= rule["threshold"]:
            gross = (desired_amount + rule["flat_fee"]) / (Decimal("1") - rule["percentage"])
            
        if rule["cap"] is not None and (gross - desired_amount) > rule["cap"]:
            gross = desired_amount + rule["cap"]
            
        return gross.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)