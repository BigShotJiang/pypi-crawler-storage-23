from decimal import Decimal
from .enums import Currency

# Official Paystack fee structures per currency
CURRENCY_RULES = {
    Currency.NGN: {
        "percentage": Decimal("0.015"),
        "flat_fee": Decimal("100"),
        "threshold": Decimal("2500"),
        "cap": Decimal("2000"),
    },
    Currency.GHS: {
        "percentage": Decimal("0.0195"),
        "flat_fee": Decimal("0"),
        "threshold": Decimal("0"),
        "cap": None,
    },
    Currency.ZAR: {
        "percentage": Decimal("0.029"),
        "flat_fee": Decimal("1"),
        "threshold": Decimal("0"),
        "cap": None,
    },
    Currency.KES: {
        "percentage": Decimal("0.029"),
        "flat_fee": Decimal("0"),
        "threshold": Decimal("0"),
        "cap": None,
    },
}