#!moo verb desc*ribe --on "player class" --dspec any

# pylint: disable=return-outside-function,undefined-variable

print("Would describe an object here.")
