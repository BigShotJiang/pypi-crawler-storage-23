"""
Browser JavaScript Execution Example

This example demonstrates:
1. Executing JavaScript in browser context
2. Manipulating DOM elements
3. Extracting computed values
4. Handling JavaScript results
"""

import asyncio
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))))

from agentbay import AsyncAgentBay, CreateSessionParams
from agentbay import BrowserOption, ActOptions, ExtractOptions
from pydantic import BaseModel, Field


class TextContent(BaseModel):
    """Simple model to extract text content."""
    content: str = Field(description="The extracted text content")


async def main():
    """Demonstrate browser JavaScript execution."""
    print("=== Browser JavaScript Execution Example ===\n")

    # Initialize AgentBay client
    client = AsyncAgentBay()
    session = None

    try:
        # Create a session with browser enabled
        print("Creating session with browser...")
        session_result = await client.create(
            CreateSessionParams(image_id="browser_latest")
        )
        
        # Check if session creation was successful
        if not session_result.success or session_result.session is None:
            print(f"Failed to create session: {session_result.error_message}")
            return
            
        session = session_result.session
        print(f"Session created: {session.session_id}")

        # Initialize browser
        print("Initializing browser...")
        if not await session.browser.initialize(BrowserOption()):
            raise Exception("Failed to initialize browser")
        print("Browser initialized")

        # Navigate to a test page
        print("\n1. Navigating to example.com...")
        await session.browser.operator.navigate("https://example.com")

        # Execute simple JavaScript
        print("\n2. Executing JavaScript to get page title...")
        await session.browser.operator.act(ActOptions(action="Execute JavaScript: console.log(document.title)"))
        success, title_result = await session.browser.operator.extract(ExtractOptions(instruction="What is the document title?", schema=TextContent))
        if success:
            print(f"Page title: {title_result.content}")
        else:
            print("Failed to extract page title")

        # Get window dimensions
        print("\n3. Getting window dimensions via JavaScript...")
        await session.browser.operator.act(ActOptions(
            action="Execute JavaScript to log window dimensions: "
            "console.log('Width:', window.innerWidth, 'Height:', window.innerHeight)"
        ))

        # Manipulate DOM
        print("\n4. Manipulating DOM with JavaScript...")
        await session.browser.operator.act(ActOptions(
            action="Execute JavaScript to change the page background color to light blue"
        ))
        print("Background color changed")

        # Take screenshot to verify change
        print("\n5. Taking screenshot to verify DOM manipulation...")
        screenshot_path = await session.browser.operator.screenshot()
        print(f"Screenshot saved: {screenshot_path}")

        # Extract computed styles
        print("\n6. Extracting computed styles...")
        success, style_result = await session.browser.operator.extract(ExtractOptions(
            instruction="What is the background color of the page body?",
            schema=TextContent
        ))
        if success:
            print(f"Background color: {style_result.content}")
        else:
            print("Failed to extract background color")

        # Navigate to a page with more content
        print("\n7. Navigating to a page with more content...")
        await session.browser.operator.navigate("https://news.ycombinator.com")

        # Count elements using JavaScript
        print("\n8. Counting story elements...")
        await session.browser.operator.act(ActOptions(
            action="Execute JavaScript to count the number of story links on the page"
        ))
        success, count_result = await session.browser.operator.extract(ExtractOptions(
            instruction="How many story items are on the page?",
            schema=TextContent
        ))
        if success:
            print(f"Story count: {count_result.content}")
        else:
            print("Failed to extract story count")

        # Scroll page using JavaScript
        print("\n9. Scrolling page with JavaScript...")
        await session.browser.operator.act(ActOptions(action="Scroll down the page by 500 pixels"))
        print("Page scrolled")

        # Get scroll position
        print("\n10. Getting scroll position...")
        success, scroll_result = await session.browser.operator.extract(ExtractOptions(
            instruction="What is the current scroll position of the page?",
            schema=TextContent
        ))
        if success:
            print(f"Scroll position: {scroll_result.content}")
        else:
            print("Failed to extract scroll position")

        print("\n=== Example completed successfully ===")

    except Exception as e:
        print(f"\nError occurred: {str(e)}")
        raise

    finally:
        # Clean up
        if session:
            print("\nCleaning up session...")
            await client.delete(session)
            print("Session closed")


if __name__ == "__main__":
    asyncio.run(main())

