"""
Browser Multi-Tab Management Example

This example demonstrates:
1. Opening multiple tabs
2. Switching between tabs
3. Managing tab state
4. Coordinating actions across tabs
"""

import asyncio
import os
import sys

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))))

from agentbay import AsyncAgentBay, CreateSessionParams
from agentbay import BrowserOption
from agentbay import ExtractOptions, ActOptions
from pydantic import BaseModel, Field


class TextContent(BaseModel):
    """Simple model to extract text content."""
    content: str = Field(description="The extracted text content")


async def main():
    """Demonstrate browser multi-tab management."""
    print("=== Browser Multi-Tab Management Example ===\n")

    # Initialize AgentBay client
    client = AsyncAgentBay()
    session = None

    try:
        # Create a session with browser enabled
        print("Creating session with browser...")
        session_result = await client.create(
            CreateSessionParams(image_id="browser_latest")
        )
        
        # Check if session creation was successful
        if not session_result.success or session_result.session is None:
            print(f"Failed to create session: {session_result.error_message}")
            return
            
        session = session_result.session
        print(f"Session created: {session.session_id}")

        # Initialize browser
        print("Initializing browser...")
        if not await session.browser.initialize(BrowserOption()):
            raise Exception("Failed to initialize browser")
        print("Browser initialized")

        # Open first tab
        print("\n1. Opening first tab (example.com)...")
        await session.browser.operator.navigate("https://example.com")
        success, tab1_result = await session.browser.operator.extract(ExtractOptions(
            instruction="What is the page title?",
            schema=TextContent
        ))
        if success:
            print(f"Tab 1 title: {tab1_result.content}")
        else:
            print("Failed to extract tab 1 title")

        # Open second tab by navigating to a new URL
        print("\n2. Opening second tab (httpbin.org)...)")
        await session.browser.operator.act(ActOptions(action="Open a new tab and navigate to https://httpbin.org"))
        success, tab2_result = await session.browser.operator.extract(ExtractOptions(
            instruction="What is the page title?",
            schema=TextContent
        ))
        if success:
            print(f"Tab 2 title: {tab2_result.content}")
        else:
            print("Failed to extract tab 2 title")

        # Extract information from current tab
        print("\n3. Extracting information from current tab...")
        success, info_result = await session.browser.operator.extract(ExtractOptions(instruction="What HTTP testing endpoints are available?", schema=TextContent))
        if success:
            print(f"Available endpoints:\n{info_result.content}")
        else:
            print("Failed to extract endpoints")

        # Switch back to first tab
        print("\n4. Switching back to first tab...")
        await session.browser.operator.act(ActOptions(action="Switch to the first tab"))
        success, current_result = await session.browser.operator.extract(ExtractOptions(instruction="What is the current page URL?", schema=TextContent))
        if success:
            print(f"Current URL: {current_result.content}")
        else:
            print("Failed to extract current URL")

        # Open third tab - use a more reliable site
        print("\n5. Opening third tab (jsonplaceholder.typicode.com)...")
        await session.browser.operator.act(ActOptions(action="Open a new tab and navigate to https://jsonplaceholder.typicode.com"))
        success, tab3_result = await session.browser.operator.extract(ExtractOptions(instruction="What is the page title?", schema=TextContent))
        if success:
            print(f"Tab 3 title: {tab3_result.content}")
        else:
            print("Failed to extract tab 3 title")

        # List all tabs with timeout handling
        print("\n6. Listing all open tabs...")
        try:
            success, tabs_result = await asyncio.wait_for(
                session.browser.operator.extract(ExtractOptions(instruction="How many tabs are open and what are their URLs?", schema=TextContent)),
                timeout=30.0  # 30 second timeout
            )
            if success:
                print(f"Open tabs:\n{tabs_result.content}")
            else:
                print("Failed to extract tabs information")
        except asyncio.TimeoutError:
            print("Extract operation timed out after 30 seconds")

        # Close a specific tab
        print("\n7. Closing the second tab...")
        await session.browser.operator.act(ActOptions(action="Close the tab with httpbin.org"))
        success, remaining_result = await session.browser.operator.extract(ExtractOptions(instruction="How many tabs are now open?", schema=TextContent))
        if success:
            print(f"Remaining tabs: {remaining_result.content}")
        else:
            print("Failed to extract remaining tabs information")

        print("\n=== Example completed successfully ===")

    except Exception as e:
        print(f"\nError occurred: {str(e)}")
        raise

    finally:
        # Clean up
        if session:
            print("\nCleaning up session...")
            await client.delete(session)
            print("Session closed")


if __name__ == "__main__":
    asyncio.run(main())