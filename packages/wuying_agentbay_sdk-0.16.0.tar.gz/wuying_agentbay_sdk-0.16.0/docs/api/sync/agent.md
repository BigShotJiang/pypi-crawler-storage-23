# Agent API Reference

> **💡 Async Version**: This documentation covers the synchronous API. For async/await support, see [`AsyncAgent`](../async/async-agent.md) which provides the same functionality with async methods.

## 🤖 Related Tutorial

- [Agent Modules Guide](../../../../docs/guides/common-features/advanced/agent-modules.md) - Learn about agent modules and custom agents



## Agent

```python
class Agent(BaseService)
```

An Agent to manipulate applications to complete specific tasks.

> **⚠️ Note**: Currently, for agent services (including ComputerUseAgent, BrowserUseAgent, and MobileUseAgent), we do not provide services for overseas users registered with **alibabacloud.com**.

### __init__

```python
def __init__(self, session: "Session")
```

## Computer

```python
class Computer(_BaseTaskAgent)
```

An Agent to perform tasks on the computer.

> **⚠️ Note**: Currently, for agent services (including ComputerUseAgent, BrowserUseAgent, and MobileUseAgent), we do not provide services for overseas users registered with **alibabacloud.com**.

### __init__

```python
def __init__(self, session: "Session")
```

## Browser

```python
class Browser(_BaseTaskAgent)
```

> **⚠️ Note**: Currently, for agent services (including ComputerUseAgent, BrowserUseAgent, and MobileUseAgent), we do not provide services for overseas users registered with **alibabacloud.com**.

### __init__

```python
def __init__(self, session: "Session")
```

### initialize

```python
def initialize(option: Optional[BrowserOption] = None) -> bool
```

Initialize the browser on which the agent performs tasks.
You are supposed to call this API before executeTask is called, but it's not optional.
If you want perform a hybrid usage of browser, you must call this API before executeTask is called.

**Returns**:

    bool: True if the browser is successfully initialized, False otherwise.

### execute_task

```python
def execute_task(
        task: str,
        use_vision: bool = False,
        output_schema: Type[Schema] = None,
        full_page_screenshot: Optional[bool] = False) -> ExecutionResult
```

Execute a task described in human language on a browser without waiting for completion (non-blocking).

This is a fire-and-return interface that immediately provides a task ID.
Call get_task_status to check the task status. You can control the timeout
of the task execution in your own code by setting the frequency of calling
get_task_status.

**Arguments**:

    task: Task description in human language.
    use_vision: Whether to use vision to performe the task.
    output_schema: The schema of the structured output.
    full_page_screenshot: Whether to take a full page screenshot. This only works when use_vision is true.
  When use_vision is enabled, we need to provide a screenshot of the webpage to the LLM for grounding. There are two ways of screenshot:
  1. Full-page screenshot: Captures the entire webpage content, including parts not currently visible in the viewport.
  2. Viewport screenshot: Captures only the currently visible portion of the webpage.
  The first approach delivers all information to the LLM in one go, which can improve task success rates in certain information extraction scenarios. However, it also results in higher token consumption and increases the LLM's processing time.
  Therefore, we would like to give you the choice—you can decide whether to enable full-page screenshot based on your actual needs.

**Returns**:

    ExecutionResult: Result object containing success status, task ID,
  task status, and error message if any.
  

**Example**:

```python
session_result = agent_bay.create()
session = session_result.session
class WeatherSchema(BaseModel):
  city:str
  weather: str
result = session.agent.browser.execute_task(task="Query the weather in Shanghai",use_vision=False, output_schema=WeatherSchema, full_page_screenshot=True)
print(
  f"Task ID: {result.task_id}, Status: {result.task_status}")
status = session.agent.browser.get_task_status(result.task_id)
print(f"Task status: {status.task_status}")
session.delete()
```

### execute_task_and_wait

```python
def execute_task_and_wait(
        task: str,
        timeout: int,
        use_vision: bool = False,
        output_schema: Type[Schema] = None,
        full_page_screenshot: Optional[bool] = False) -> ExecutionResult
```

Execute a task described in human language on a browser synchronously.

This is a synchronous interface that blocks until the task is completed or
an error occurs, or timeout happens. The default polling interval is 3 seconds.

**Arguments**:

    task: Task description in human language.
    timeout: Maximum time to wait for task completion in seconds.
  Used to control how long to wait for task completion.
    use_vision: Whether to use vision to performe the task.
    output_schema: The schema of the structured output.
    full_page_screenshot: Whether to take a full page screenshot. This only works when use_vision is true.
  When use_vision is enabled, we need to provide a screenshot of the webpage to the LLM for grounding. There are two ways of screenshot:
  1. Full-page screenshot: Captures the entire webpage content, including parts not currently visible in the viewport.
  2. Viewport screenshot: Captures only the currently visible portion of the webpage.
  The first approach delivers all information to the LLM in one go, which can improve task success rates in certain information extraction scenarios. However, it also results in higher token consumption and increases the LLM's processing time.
  Therefore, we would like to give you the choice—you can decide whether to enable full-page screenshot based on your actual needs.
  

**Returns**:

    ExecutionResult: Result object containing success status, task ID,
  task status, and error message if any.
  

**Example**:

```python
session_result = agent_bay.create()
session = session_result.session
class WeatherSchema(BaseModel):
  city:str
  weather: str
result = session.agent.computer.execute_task_and_wait(task="Query the weather in Shanghai",timeout=60, use_vision=False, output_schema=WeatherSchema, full_page_screenshot=True)
print(f"Task result: {result.task_result}")
session.delete()
```

## Mobile

```python
class Mobile(_BaseTaskAgent)
```

An Agent to perform tasks on mobile devices.

> **⚠️ Note**: Currently, for agent services (including ComputerUseAgent, BrowserUseAgent, and MobileUseAgent), we do not provide services for overseas users registered with **alibabacloud.com**.

### __init__

```python
def __init__(self, session: "Session")
```

### execute_task

```python
def execute_task(task: str, max_steps: int = 50) -> ExecutionResult
```

Execute a task in human language without waiting for completion
(non-blocking).

This is a fire-and-return interface that immediately provides a task ID.
Call get_task_status to check the task status. You can control the timeout
of the task execution in your own code by setting the frequency of calling
get_task_status.

**Arguments**:

    task: Task description in human language.
    max_steps: Maximum number of steps (clicks/swipes/etc.) allowed.
  Used to prevent infinite loops or excessive resource consumption.
  Default is 50.
  

**Returns**:

    ExecutionResult: Result object containing success status, task ID,
  task status, and error message if any.
  

**Example**:

```python
session_result = agent_bay.create()
session = session_result.session
result = session.agent.mobile.execute_task(
  "Open WeChat app", max_steps=100
)
print(f"Task ID: {result.task_id}, Status: {result.task_status}")
status = session.agent.mobile.get_task_status(result.task_id)
print(f"Task status: {status.task_status}")
session.delete()
```

### execute_task_and_wait

```python
def execute_task_and_wait(task: str,
                          timeout: int,
                          max_steps: int = 50) -> ExecutionResult
```

Execute a specific task described in human language synchronously.

This is a synchronous interface that blocks until the task is
completed or an error occurs, or timeout happens. The default
polling interval is 3 seconds.

**Arguments**:

    task: Task description in human language.
    timeout: Maximum time to wait for task completion in seconds.
  Used to control how long to wait for task completion.
    max_steps: Maximum number of steps (clicks/swipes/etc.) allowed.
  Used to prevent infinite loops or excessive resource consumption.
  Default is 50.
  

**Returns**:

    ExecutionResult: Result object containing success status, task ID,
  task status, and error message if any.
  

**Example**:

```python
session_result = agent_bay.create()
session = session_result.session
result = session.agent.mobile.execute_task_and_wait(
  "Open WeChat app and send a message",
  timeout=180,
  max_steps=100
)
print(f"Task result: {result.task_result}")
session.delete()
```

### get_task_status

```python
def get_task_status(task_id: str) -> QueryResult
```

### terminate_task

```python
def terminate_task(task_id: str) -> ExecutionResult
```

## See Also

- [Synchronous vs Asynchronous API](../../../docs/guides/async-programming/sync-vs-async.md)

**Related APIs:**
- [Session API Reference](./session.md)

---

*Documentation generated automatically from source code using pydoc-markdown.*
