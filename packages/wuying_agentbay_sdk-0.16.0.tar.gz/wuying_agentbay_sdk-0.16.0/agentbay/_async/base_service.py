import asyncio
import json
import random
import string
import time
from typing import Any, Dict

import requests

from .._common.exceptions import AgentBayError
from .._common.logger import (
    _log_api_call,
    _log_api_response,
    _log_api_response_with_details,
    _log_code_execution_output,
    _log_operation_error,
    get_logger,
)
from .._common.models import OperationResult, extract_request_id
from ..api.models import CallMcpToolRequest

# Initialize _logger for this module
_logger = get_logger("base_service")


class AsyncBaseService:
    """
    Base service class that provides common functionality for all service classes.
    This class implements the common methods for calling MCP tools and parsing
    responses.
    """

    def __init__(self, session):
        """
        Initialize a BaseService object.

        Args:
            session: The Session instance that this service belongs to.
        """
        self.session = session

    def _handle_error(self, e):
        """
        Handle and convert exceptions. This method should be overridden by subclasses
        to provide specific error handling.

        Args:
            e (Exception): The exception to handle.

        Returns:
            Exception: The handled exception.
        """
        return e

    async def _call_mcp_tool(
        self,
        name: str,
        args: Dict[str, Any],
        read_timeout: int = None,
        connect_timeout: int = None,
        auto_gen_session: bool = False,
    ) -> OperationResult:
        """
        Internal helper to call MCP tool and handle errors.
        Now delegates to the Session's call_mcp_tool method to unify routing logic (LinkUrl, VPC, API).

        Args:
            name (str): The name of the tool to call.
            args (Dict[str, Any]): The arguments to pass to the tool.
            auto_gen_session (bool): Whether to automatically generate session if not exists.

        Returns:
            OperationResult: The response from the tool with request ID.
        """
        try:
            # Delegate to session's central call_mcp_tool which handles LinkUrl/VPC/API routing
            mcp_result = await self.session.call_mcp_tool(
                name,
                args,
                read_timeout=read_timeout,
                connect_timeout=connect_timeout,
                auto_gen_session=auto_gen_session,
            )

            # Convert McpToolResult to OperationResult
            return OperationResult(
                request_id=mcp_result.request_id,
                success=mcp_result.success,
                error_message=mcp_result.error_message,
                data=mcp_result.data,
            )
        except Exception as e:
            # Fallback error handling if session call fails unexpectedly
            sanitized_error = self._sanitize_error(str(e))
            _logger.exception(f"Unexpected error in _call_mcp_tool for {name}")
            return OperationResult(
                request_id="",
                success=False,
                error_message=f"Failed to call {name}: {sanitized_error}",
            )

    def _sanitize_error(self, error_msg: str) -> str:
        """
        Remove sensitive information from error messages.
        """
        if not error_msg:
            return error_msg

        # Mask API keys
        if "Authorization" in error_msg:
            return "Error contains sensitive information (Authorization header)"

        return error_msg