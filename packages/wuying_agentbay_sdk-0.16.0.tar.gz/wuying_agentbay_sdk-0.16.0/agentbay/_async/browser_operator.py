import asyncio
import json
import time
from typing import List, Dict, Union, Any, Optional, Tuple, TypeVar
from pydantic import BaseModel

from .._common.exceptions import AgentBayError, BrowserError
from .._common.logger import get_logger
from .._common.models import OperationResult
from .._common.models.browser_operator import (
    ActOptions,
    ActResult,
    ObserveOptions,
    ObserveResult,
    ExtractOptions,
)
from .base_service import AsyncBaseService as BaseService
from .._common.trace_manager import TraceManager

_logger = get_logger("browser_operator")

T = TypeVar("T", bound=BaseModel)

ERROR_ACT_START_FAIL = 9000
ERROR_ACT_TASK_FAILED = 9001
ERROR_ACT_TIMEOUT = 9002
ERROR_OBSERVE_FAIL = 9020
ERROR_EXTRACT_FAIL = 9040
ERROR_EXTRACT_START_FAIL = 9041
ERROR_EXTRACT_TIMEOUT = 9042


class AsyncBrowserOperator(BaseService):
    """
    BrowserOperator handles browser automation and small parts of agentic logic.

    > **⚠️ Note**: Currently, for agent services (including ComputerUseAgent, BrowserUseAgent, and MobileUseAgent), we do not provide services for overseas users registered with **alibabacloud.com**.
    """

    def __init__(self, session, browser):
        self.session = session
        self.browser = browser

    async def navigate(self, url: str) -> str:
        """
        Navigates a specific page to the given URL.

        Args:
            url: The URL to navigate to.

        Returns:
            A string indicating the result of the navigation.
        """
        if not self.browser.is_initialized():
            raise BrowserError("Browser must be initialized before calling navigate.")
        try:
            args = {"url": url}
            response = await self._call_mcp_tool_timeout("page_use_navigate", args)
            if response.success:
                return response.data
            else:
                return f"Navigation failed: {response.error_message}"
        except Exception as e:
            raise BrowserError(f"Failed to navigate: {e}") from e

    async def screenshot(
        self,
        page=None,
        full_page: bool = True,
        quality: int = 80,
        clip: Optional[Dict[str, float]] = None,
        timeout: Optional[int] = None,
    ) -> str:
        """
        Asynchronously takes a screenshot of the specified page.

        Args:
            page (Optional[Page]): The Playwright Page object to take a screenshot of. If None,
                                   the operator's currently focused page will be used.
            full_page (bool): Whether to capture the full scrollable page.
            quality (int): The quality of the image (0-100), for JPEG format.
            clip (Optional[Dict[str, float]]): An object specifying the clipping region {x, y, width, height}.
            timeout (Optional[int]): Custom timeout for the operation in seconds.

        Returns:
            str: A base64 encoded data URL of the screenshot, or an error message.
        """
        if not self.browser.is_initialized():
            raise BrowserError("Browser must be initialized before calling screenshot.")
        try:
            page_id, context_id = await self._get_page_and_context_index(page)
            return await self._execute_screenshot(
                context_id, page_id, full_page, quality, clip, timeout
            )
        except Exception as e:
            raise BrowserError(f"Failed to call screenshot: {e}") from e

    async def _execute_screenshot(
        self,
        context_id: int,
        page_id: Optional[str] = None,
        full_page: bool = True,
        quality: int = 80,
        clip: Optional[Dict[str, float]] = None,
        timeout: Optional[int] = None,
    ) -> str:
        _logger.debug(f"Screenshot page_id: {page_id}, context_id: {context_id}")
        args = {
            "context_id": context_id,
            "page_id": page_id,
            "full_page": full_page,
            "quality": quality,
            "clip": clip,
            "timeout": timeout,
        }
        args = {k: v for k, v in args.items() if v is not None}

        response = await self._call_mcp_tool_timeout("page_use_screenshot", args)
        if response.success:
            return response.data
        else:
            return f"Screenshot failed: {response.error_message}"

    async def close(self) -> bool:
        """
        Asynchronously closes the remote browser operator session.
        This will terminate the browser process managed by the operator.
        """
        try:
            response = await self._call_mcp_tool_timeout(
                "page_use_close_session", args={}
            )
            if response.success:
                _logger.info(f"Session close status: {response.data}")
                return True
            else:
                _logger.warning(f"Failed to close session: {response.error_message}")
                return False
        except Exception as e:
            raise BrowserError(f"Failed to call close: {e}") from e

    async def act(
        self,
        action_input: Union[ObserveResult, ActOptions],
        page=None,
    ) -> "ActResult":
        """
        Asynchronously perform an action on a web page.

        Args:
            page (Optional[Page]): The Playwright Page object to act on. If None, the operator's
                                   currently focused page will be used automatically.
            action_input (Union[ObserveResult, ActOptions]): The action to perform.

        Returns:
            ActResult: The result of the action.
        """
        if not self.browser.is_initialized():
            raise BrowserError("Browser must be initialized before calling act.")
        try:
            page_id, context_id = await self._get_page_and_context_index(page)
            return await self._execute_act(action_input, context_id, page_id)
        except Exception as e:
            raise BrowserError(f"Failed to act: {e}") from e

    async def _execute_act(
        self,
        action_input: Union[ObserveResult, ActOptions],
        context_id: int,
        page_id: Optional[str],
    ) -> "ActResult":
        # Initialize trace manager and send start trace
        trace_manager = TraceManager.get_instance()
        start_time = time.time()
        event_name = self._execute_act.__name__
        span_key = f"act.{event_name}"
        trace_extra = f"{context_id}_{page_id or 'default'}"
        
        # Determine task_name before using it
        task_name = "act"
        if isinstance(action_input, ActOptions):
            task_name = action_input.action
        elif isinstance(action_input, ObserveResult):
            task_name = action_input.method
        
        # Send start trace
        trace_manager.send_trace(
            owner="browser_agent",
            trace_data={
                "event": event_name,
                "context_id": str(context_id),
                "page_id": page_id or "default",
                "task_name": task_name,
                "status": "success",
            },
            span_key=span_key,
            biz_index=0,
            extra=trace_extra,
            is_start=True,
        )
        
        # Get trace_id from trace_manager
        trace_id = trace_manager.get_trace_id(0, trace_extra)
        _logger.info(f"trace id for act: {trace_id}")

        _logger.debug(f"Acting page_id: {page_id}, context_id: {context_id}")
        args = {
            "context_id": context_id,
            "page_id": page_id,
            "trace_id": trace_id,
        }
        if isinstance(action_input, ActOptions):
            args.update(
                {
                    "action": action_input.action,
                    "variables": action_input.variables,
                    "use_vision": action_input.use_vision,
                    "timeout": action_input.timeout,
                }
            )
        elif isinstance(action_input, ObserveResult):
            action_dict = {
                "method": action_input.method,
                "arguments": (
                    json.loads(action_input.arguments)
                    if isinstance(action_input.arguments, str)
                    else action_input.arguments
                ),
            }
            args["action"] = json.dumps(action_dict)
        args = {k: v for k, v in args.items() if v is not None}
        _logger.info(f"{task_name}")

        response = await self._call_mcp_tool_timeout("page_use_act_async", args)
        request_id = response.request_id if response else ""
        if not response.success:
            error_msg = response.error_message or "Failed to start act task"
            duration_ms = int((time.time() - start_time) * 1000)
            trace_manager.send_trace(
                owner="browser_agent",
                trace_data={
                    "event": event_name,
                    "context_id": str(context_id),
                    "page_id": page_id or "default",
                    "task_name": task_name,
                    "status": "error",
                    "duration_ms": str(duration_ms),
                    "errorCode": str(ERROR_ACT_START_FAIL),
                    "errorMessage": error_msg,
                    "request_id": request_id,
                },
                span_key=span_key,
                biz_index=0,
                extra=trace_extra,
                is_start=False,
            )
            raise BrowserError(error_msg)

        task_id = json.loads(response.data)["task_id"]
        poll_interval_sec = 5.0
        start_ts = time.monotonic()
        client_timeout: Optional[int] = None
        if isinstance(action_input, ActOptions):
            client_timeout = action_input.timeout

        while True:
            await asyncio.sleep(poll_interval_sec)
            if hasattr(self, "mcp_client") and self.mcp_client:
                result = await self._call_mcp_tool_async(
                    "page_use_get_act_result", {"task_id": task_id}
                )
            else:
                result = await self._call_mcp_tool_timeout(
                    "page_use_get_act_result", {"task_id": task_id}
                )
            if result.success and result.data:
                data = (
                    json.loads(result.data)
                    if isinstance(result.data, str)
                    else result.data
                )
                steps = data.get("steps", [])
                is_done = data.get("is_done", False)
                success = bool(data.get("success", False))
                no_action_msg = "No actions have been executed."
                if is_done:
                    if steps:
                        task_status = (
                            steps
                            if isinstance(steps, str)
                            else json.dumps(steps, ensure_ascii=False)
                        )
                    else:
                        task_status = no_action_msg
                    _logger.info(
                        f"Task {task_id}:{task_name} is done. Success: {success}. {task_status}"
                    )
                    duration_ms = int((time.time() - start_time) * 1000)
                    result_request_id = result.request_id if result else ""
                    trace_manager.send_trace(
                        owner="browser_agent",
                        trace_data={
                            "event": event_name,
                            "context_id": str(context_id),
                            "page_id": page_id or "default",
                            "task_id": task_id,
                            "task_name": task_name,
                            "status": "success" if success else "error",
                            "duration_ms": str(duration_ms),
                            "steps_count": str(len(steps) if steps else 0),
                            "request_id": result_request_id,
                            **({"errorCode": str(ERROR_ACT_TASK_FAILED), "errorMessage": task_status} if not success else {}),
                        },
                        span_key=span_key,
                        biz_index=0,
                        extra=trace_extra,
                        is_start=False,
                    )
                    return ActResult(success=success, message=task_status)
                task_status = (
                    f"{len(steps)} steps done. Details: {steps}"
                    if steps
                    else no_action_msg
                )
                _logger.info(f"Task {task_id}:{task_name} in progress. {task_status}")
            elapsed = time.monotonic() - start_ts
            timeout_s = client_timeout if client_timeout is not None else 300
            if elapsed >= timeout_s:
                error_msg = f"Task {task_id}:{task_name} timeout after {timeout_s}s"
                duration_ms = int((time.time() - start_time) * 1000)
                trace_manager.send_trace(
                    owner="browser_agent",
                    trace_data={
                        "event": event_name,
                        "context_id": str(context_id),
                        "page_id": page_id or "default",
                        "task_id": task_id,
                        "task_name": task_name,
                        "status": "error",
                        "duration_ms": str(duration_ms),
                        "errorCode": str(ERROR_ACT_TIMEOUT),
                        "errorMessage": error_msg,
                        "request_id": request_id,
                    },
                    span_key=span_key,
                    biz_index=0,
                    extra=trace_extra,
                    is_start=False,
                )
                raise BrowserError(error_msg)

    async def observe(
        self,
        options: ObserveOptions,
        page=None,
    ) -> Tuple[bool, List[ObserveResult]]:
        """
        Asynchronously observe elements or state on a web page.

        Args:
            page (Optional[Page]): The Playwright Page object to observe. If None, the operator's
                                   currently focused page will be used.
            options (ObserveOptions): Options to configure the observation behavior.

        Returns:
            Tuple[bool, List[ObserveResult]]: A tuple containing a success boolean and a list
                                              of observation results.
        """
        if not self.browser.is_initialized():
            raise BrowserError("Browser must be initialized before calling observe.")
        try:
            page_id, context_id = await self._get_page_and_context_index(page)
            return await self._execute_observe(options, context_id, page_id)
        except Exception as e:
            raise BrowserError(f"Failed to observe: {e}") from e

    async def _execute_observe(
        self,
        options: ObserveOptions,
        context_id: int,
        page_id: Optional[str],
    ) -> Tuple[bool, List[ObserveResult]]:
        # Initialize trace manager and send start trace
        trace_manager = TraceManager.get_instance()
        start_time = time.time()
        event_name = self._execute_observe.__name__
        span_key = f"observe.{event_name}"
        trace_extra = f"{context_id}_{page_id or 'default'}"
        
        # Send start trace
        trace_manager.send_trace(
            owner="browser_agent",
            trace_data={
                "event": event_name,
                "context_id": str(context_id),
                "page_id": page_id or "default",
                "instruction_preview": (options.instruction[:100] if options.instruction else ""),
                "iframes": str(getattr(options, 'iframes', None)) if getattr(options, 'iframes', None) is not None else "",
                "use_vision": str(options.use_vision) if options.use_vision is not None else "",
                "status": "success",
            },
            span_key=span_key,
            biz_index=0,
            extra=trace_extra,
            is_start=True,
        )
        
        # Get trace_id from trace_manager
        trace_id = trace_manager.get_trace_id(0, trace_extra)
        _logger.info(f"trace id for observe: {trace_id}")

        _logger.debug(f"Observing page_id: {page_id}, context_id: {context_id}")
        args = {
            "context_id": context_id,
            "page_id": page_id,
            "instruction": options.instruction,
            "use_vision": options.use_vision,
            "selector": options.selector,
            "trace_id": trace_id,
        }
        args = {k: v for k, v in args.items() if v is not None}
        response = await self._call_mcp_tool_timeout("page_use_observe_async", args)
        request_id = response.request_id if response else ""
        if not response.success:
            error_msg = response.error_message or "Failed to start observe task"
            duration_ms = int((time.time() - start_time) * 1000)
            trace_manager.send_trace(
                owner="browser_agent",
                trace_data={
                    "event": event_name,
                    "context_id": str(context_id),
                    "page_id": page_id or "default",
                    "status": "error",
                    "duration_ms": str(duration_ms),
                    "errorCode": str(ERROR_OBSERVE_FAIL),
                    "errorMessage": error_msg,
                    "request_id": request_id,
                },
                span_key=span_key,
                biz_index=0,
                extra=trace_extra,
                is_start=False,
            )
            raise BrowserError(error_msg)

        task_info = (
            json.loads(response.data)
            if isinstance(response.data, str)
            else response.data
        )
        task_id = task_info["task_id"]

        client_timeout: Optional[int] = options.timeout
        poll_interval_sec = 5.0
        start_ts = time.monotonic()

        while True:
            await asyncio.sleep(poll_interval_sec)
            if hasattr(self, "mcp_client") and self.mcp_client:
                result = await self._call_mcp_tool_async(
                    "page_use_get_observe_result", {"task_id": task_id}
                )
            else:
                result = await self._call_mcp_tool_timeout(
                    "page_use_get_observe_result", {"task_id": task_id}
                )
            if result.success and result.data:
                data = (
                    json.loads(result.data)
                    if isinstance(result.data, str)
                    else result.data
                )
                _logger.info(f"observe results: {data}")
                results: List[ObserveResult] = []
                for item in data:
                    selector = item.get("selector", "")
                    description = item.get("description", "")
                    method = item.get("method", "")
                    arguments_str = item.get("arguments", "{}")
                    try:
                        arguments_dict = json.loads(arguments_str)
                    except json.JSONDecodeError:
                        _logger.warning(
                            f"Warning: Could not parse arguments as JSON: {arguments_str}"
                        )
                        arguments_dict = arguments_str
                    results.append(
                        ObserveResult(selector, description, method, arguments_dict)
                    )

                duration_ms = int((time.time() - start_time) * 1000)
                result_request_id = result.request_id if result else ""
                trace_manager.send_trace(
                    owner="browser_agent",
                    trace_data={
                        "event": event_name,
                        "context_id": str(context_id),
                        "page_id": page_id or "default",
                        "status": "success",
                        "duration_ms": str(duration_ms),
                        "results_count": str(len(results)),
                        "request_id": result_request_id,
                    },
                    span_key=span_key,
                    biz_index=0,
                    extra=trace_extra,
                    is_start=False,
                )
                return True, results
            elapsed = time.monotonic() - start_ts
            _logger.debug(
                f"Task {task_id}: No observe result yet (elapsed={elapsed:.0f}s)"
            )
            timeout_s = client_timeout if client_timeout is not None else 300
            if elapsed >= timeout_s:
                error_msg = f"Task {task_id}: Observe timeout after {timeout_s}s"
                duration_ms = int((time.time() - start_time) * 1000)
                trace_manager.send_trace(
                    owner="browser_agent",
                    trace_data={
                        "event": event_name,
                        "context_id": str(context_id),
                        "page_id": page_id or "default",
                        "status": "error",
                        "duration_ms": str(duration_ms),
                        "errorCode": str(ERROR_OBSERVE_FAIL),
                        "errorMessage": error_msg,
                        "request_id": request_id,
                    },
                    span_key=span_key,
                    biz_index=0,
                    extra=trace_extra,
                    is_start=False,
                )
                raise BrowserError(error_msg)

    async def extract(
        self,
        options: ExtractOptions,
        page=None,
    ) -> Tuple[bool, T]:
        """
        Asynchronously extract information from a web page.

        Args:
            page (Optional[Page]): The Playwright Page object to extract from. If None, the operator's
                                   currently focused page will be used.
            options (ExtractOptions): Options to configure the extraction, including schema.

        Returns:
            Tuple[bool, T]: A tuple containing a success boolean and the extracted data as a
                            Pydantic model instance, or None on failure.
        """
        if not self.browser.is_initialized():
            raise BrowserError("Browser must be initialized before calling extract.")
        try:
            page_id, context_id = await self._get_page_and_context_index(page)
            return await self._execute_extract(options, context_id, page_id)
        except Exception as e:
            raise BrowserError(f"Failed to extract: {e}") from e

    async def _execute_extract(
        self,
        options: ExtractOptions,
        context_id: int,
        page_id: Optional[str],
    ) -> Tuple[bool, T]:
        # Initialize trace manager and send start trace
        trace_manager = TraceManager.get_instance()
        start_time = time.time()
        event_name = self._execute_extract.__name__
        span_key = f"extract.{event_name}"
        trace_extra = f"{context_id}_{page_id or 'default'}"
        
        # Send start trace
        trace_manager.send_trace(
            owner="browser_agent",
            trace_data={
                "event": event_name,
                "context_id": str(context_id),
                "page_id": page_id or "default",
                "instruction_preview": (options.instruction[:100] if options.instruction else ""),
                "use_text_extract": str(options.use_text_extract) if options.use_text_extract is not None else "",
                "use_vision": str(options.use_vision) if options.use_vision is not None else "",
                "selector": options.selector or "",
                "status": "success",
            },
            span_key=span_key,
            biz_index=0,
            extra=trace_extra,
            is_start=True,
        )
        
        # Get trace_id from trace_manager
        trace_id = trace_manager.get_trace_id(0, trace_extra)
        _logger.info(f"trace id for extract: {trace_id}")
        
        args = {
            "context_id": context_id,
            "page_id": page_id,
            "instruction": options.instruction,
            "field_schema": "schema: " + json.dumps(options.schema.model_json_schema()),
            "use_text_extract": options.use_text_extract,
            "use_vision": options.use_vision,
            "selector": options.selector,
            "max_page": options.max_page,
            "trace_id": trace_id,
        }
        args = {k: v for k, v in args.items() if v is not None}

        response = await self._call_mcp_tool_timeout("page_use_extract_async", args)
        request_id = response.request_id if response else ""
        if not response.success:
            error_msg = response.error_message or "Failed to start extraction task"
            duration_ms = int((time.time() - start_time) * 1000)
            trace_manager.send_trace(
                owner="browser_agent",
                trace_data={
                    "event": event_name,
                    "context_id": str(context_id),
                    "page_id": page_id or "default",
                    "status": "error",
                    "duration_ms": str(duration_ms),
                    "errorCode": str(ERROR_EXTRACT_START_FAIL),
                    "errorMessage": error_msg,
                    "request_id": request_id,
                },
                span_key=span_key,
                biz_index=0,
                extra=trace_extra,
                is_start=False,
            )
            raise BrowserError(error_msg)

        task_id = json.loads(response.data)["task_id"]
        client_timeout: Optional[int] = options.timeout
        poll_interval_sec = 8.0
        start_ts = time.monotonic()

        while True:
            await asyncio.sleep(poll_interval_sec)

            if hasattr(self, "mcp_client") and self.mcp_client:
                result = await self._call_mcp_tool_async(
                    "page_use_get_extract_result", {"task_id": task_id}
                )
            else:
                result = await self._call_mcp_tool_timeout(
                    "page_use_get_extract_result", {"task_id": task_id}
                )
            if result.success and result.data:
                extract_result = (
                    json.loads(result.data)
                    if isinstance(result.data, str)
                    else result.data
                )
                duration_ms = int((time.time() - start_time) * 1000)
                result_request_id = result.request_id if result else ""
                trace_manager.send_trace(
                    owner="browser_agent",
                    trace_data={
                        "event": event_name,
                        "context_id": str(context_id),
                        "page_id": page_id or "default",
                        "task_id": task_id,
                        "status": "success",
                        "duration_ms": str(duration_ms),
                        "result_length": str(len(str(extract_result))),
                        "request_id": result_request_id,
                    },
                    span_key=span_key,
                    biz_index=0,
                    extra=trace_extra,
                    is_start=False,
                )
                return True, options.schema.model_validate(extract_result)
            elapsed = time.monotonic() - start_ts
            _logger.debug(
                f"Task {task_id}: No extract result yet (elapsed={elapsed:.0f}s)"
            )
            timeout_s = client_timeout if client_timeout is not None else 300
            if elapsed >= timeout_s:
                error_msg = f"Task {task_id}: Extract timeout after {timeout_s}s"
                duration_ms = int((time.time() - start_time) * 1000)
                trace_manager.send_trace(
                    owner="browser_agent",
                    trace_data={
                        "event": event_name,
                        "context_id": str(context_id),
                        "page_id": page_id or "default",
                        "task_id": task_id,
                        "status": "error",
                        "duration_ms": str(duration_ms),
                        "errorCode": str(ERROR_EXTRACT_TIMEOUT),
                        "errorMessage": error_msg,
                        "request_id": request_id,
                    },
                    span_key=span_key,
                    biz_index=0,
                    extra=trace_extra,
                    is_start=False,
                )
                raise BrowserError(error_msg)

    async def login(
        self,
        login_config: str,
        page=None,
        use_vision: Optional[bool] = False,
    ) -> "ActResult":
        """
        Asynchronously perform a login operation on a web page.

        Args:
            login_config (str): A JSON string containing login configuration,
                               e.g., '{"api_key": "xxx", "skill_id": "yyy"}'
            page (Optional[Page]): The Playwright Page object to login on. If None,
                                   the agent's currently focused page will be used.
            use_vision (Optional[bool]): Whether to use vision-based capabilities during login.

        Returns:
            ActResult: The result of the login operation.
        """
        if not self.browser.is_initialized():
            raise BrowserError("Browser must be initialized before calling login.")
        try:
            page_id, context_id = await self._get_page_and_context_index(page)
            args = {
                "login_config": login_config,
                "context_id": context_id,
                "page_id": page_id,
                "use_vision": use_vision,
            }
            args = {k: v for k, v in args.items() if v is not None}
            _logger.info(f"login call: config={login_config[:25]}")
            response = await self._call_mcp_tool_timeout("page_use_login", args)

            if response.success:
                data = (
                    response.data
                    if isinstance(response.data, str)
                    else json.dumps(response.data, ensure_ascii=False)
                )
                _logger.info(f"login response data: {data}")
                return ActResult(success=True, message=data)
            else:
                return ActResult(success=False, message=response.error_message)
        except Exception as e:
            raise BrowserError(f"Failed to call login: {e}") from e

    async def _get_page_and_context_index(self, page):
        """
        Async version of _get_page_and_context_index for getting page and context indices asynchronously.
        Args:
            page: Playwright Page object
        Returns:
            (str, int): (page_index, context_index)
        Raises:
            BrowserError: If indices cannot be determined.
        """
        if page is None:
            return None, 0
        try:
            cdp_session = await page.context.new_cdp_session(page)
            target_info = await cdp_session.send("Target.getTargetInfo")
            page_index = target_info["targetInfo"]["targetId"]
            await cdp_session.detach()
            if hasattr(page.context.browser, "contexts"):
                context_index = page.context.browser.contexts.index(page.context)
            else:
                context_index = 0
            return page_index, context_index
        except Exception as e:
            raise BrowserError(f"Failed to get page/context index: {e}") from e

    def _handle_error(self, e):
        """
        Handle and convert exceptions. This method should be overridden by subclasses
        to provide specific error handling.

        Args:
            e (Exception): The exception to handle.

        Returns:
            Exception: The handled exception.
        """
        if isinstance(e, BrowserError):
            return e
        if isinstance(e, AgentBayError):
            return BrowserError(str(e))
        return e

    async def _call_mcp_tool_timeout(
        self, name: str, args: Dict[str, Any]
    ) -> OperationResult:
        """
        Call MCP tool with timeout.
        """
        # AsyncBaseService.session.call_mcp_tool is async
        return await self.session.call_mcp_tool(
            name,
            args,
            read_timeout=60000,
            connect_timeout=60000,
        )
