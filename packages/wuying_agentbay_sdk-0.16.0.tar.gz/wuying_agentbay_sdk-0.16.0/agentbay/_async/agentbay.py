import asyncio
import copy
import json
import os
import random
import string
import time
from enum import Enum
from threading import Lock
from typing import Any, Dict, Optional

from alibabacloud_tea_openapi import models as open_api_models
from alibabacloud_tea_openapi.exceptions._client import ClientException

from .._common.config import (
    Config as Config,
    _BROWSER_DATA_PATH,
    _MOBILE_INFO_DEFAULT_PATH,
    _load_config,
)
from .._common.logger import (
    _log_api_call,
    _log_api_response_with_details,
    _log_info_with_color,
    _log_operation_error,
    _log_operation_start,
    _log_operation_success,
    _log_warning,
    get_logger,
)
from .._common.models import (
    DeleteResult,
    GetSessionData,
    GetSessionResult,
    SessionListResult,
    SessionPauseResult,
    SessionResult,
    SessionResumeResult,
    extract_request_id,
)
from .._common.version import __is_release__, __version__
from .._common.enums import SessionStatus
from ..api.client import Client as mcp_client
from ..api.models import (
    CreateMcpSessionRequest,
    GetSessionRequest,
    ListSessionRequest,
    ResumeSessionAsyncRequest,
)
from .._common.models.mcp_tool import McpTool
from .context import AsyncContextService
from .beta_network import AsyncBetaNetworkService
from .beta import AsyncBetaNamespace
from .session import AsyncSession
from .._common.params.session_params import CreateSessionParams

# Initialize logger for this module
_logger = get_logger("agentbay")


class AsyncAgentBay:
    """
    AsyncAgentBay represents the main client for interacting with the AgentBay cloud runtime
    environment asynchronously.
    """

    def __init__(
        self,
        api_key: str = "",
        cfg: Optional[Config] = None,
        env_file: Optional[str] = None,
    ):
        """
        Initialize AsyncAgentBay client.

        Args:
            api_key: API key for authentication. If not provided, will read from AGENTBAY_API_KEY environment variable.
            cfg: Configuration object. If not provided, will load from environment variables and .env file.
            env_file: Custom path to .env file. If not provided, will search upward from current directory.
        """
        if not api_key:
            api_key = os.getenv("AGENTBAY_API_KEY") or ""
            if not api_key:
                raise ValueError(
                    "API key is required. Provide it as a parameter or set the "
                    "AGENTBAY_API_KEY environment variable"
                )

        # Load configuration with optional custom env file path
        config_data = _load_config(cfg, env_file)

        self.api_key = api_key
        self.region_id = config_data["region_id"]

        config = open_api_models.Config()
        config.endpoint = config_data["endpoint"]
        config.read_timeout = config_data["timeout_ms"]
        config.connect_timeout = config_data["timeout_ms"]

        self.client = mcp_client(config)
        self._sessions = {}
        self._lock = Lock()

        # Initialize context service
        self.context = AsyncContextService(self)
        self.beta_network = AsyncBetaNetworkService(self)
        self.beta = AsyncBetaNamespace(self)
        self._file_transfer_context: Optional[Any] = None

    def _safe_serialize(self, obj):
        """
        Helper function to serialize objects to JSON-compatible format.

        Args:
            obj: The object to serialize.

        Returns:
            JSON-serializable representation of the object.
        """
        try:
            if isinstance(obj, Enum):
                return obj.value
            elif hasattr(obj, "__dict__") and callable(obj.__dict__):
                return obj.__dict__()
            elif hasattr(obj, "__dict__"):
                return obj.__dict__
            elif hasattr(obj, "to_map"):
                return obj.to_map()
            elif hasattr(obj, "to_dict"):
                return obj.to_dict()
            else:
                return str(obj)
        except:
            return str(obj)

    def _parse_tool_list_to_mcp_tools(self, tool_list: Any) -> list[McpTool]:
        """
        Parse backend ToolList field into a list of McpTool objects.

        Backend may return ToolList as a JSON string or a list of dicts.
        """
        if not tool_list:
            return []

        items: Any = tool_list
        if isinstance(tool_list, str):
            try:
                items = json.loads(tool_list)
            except Exception as e:
                _logger.warning(f"Failed to parse ToolList JSON: {e}")
                return []

        if not isinstance(items, list):
            return []

        tools: list[McpTool] = []
        for item in items:
            if isinstance(item, McpTool):
                tools.append(item)
                continue
            if not isinstance(item, dict):
                continue
            tools.append(
                McpTool(
                    name=item.get("name", "") or item.get("Name", "") or "",
                    server=item.get("server", "") or item.get("serverName", "") or item.get("Server", "") or "",
                )
            )
        return tools

    async def _build_session_from_response(
        self,
        response_data: dict,
        params: CreateSessionParams,
    ) -> AsyncSession:
        """
        Build Session object from API response data.

        Args:
            response_data: Data field from API response
            params: Parameters for creating the session

        Returns:
            AsyncSession: Built Session object
        """
        session_id = response_data.get("SessionId")
        if not session_id:
            raise ValueError("SessionId not found in response data")

        resource_url = response_data.get("ResourceUrl", "")
        app_instance_id = response_data.get("AppInstanceId", "") or ""

        if app_instance_id:
            _logger.info(
                f"🆔 Session created: {session_id}, AppInstanceId: {app_instance_id}"
            )
        else:
            _logger.info(f"🆔 Session created: {session_id}")
        _logger.debug(f"🔗 Resource URL: {resource_url}")

        # Create Session object
        session = AsyncSession(self, session_id)

        # ToolList returned by backend for this session
        tool_list = response_data.get("ToolList")
        session.mcpTools = self._parse_tool_list_to_mcp_tools(tool_list)

        # Set ResourceUrl
        session.resource_url = resource_url

        # LinkUrl/token may be returned by the server for direct tool calls.
        if "Token" in response_data and response_data.get("Token") is not None:
            session.token = str(response_data.get("Token") or "")
        if "LinkUrl" in response_data and response_data.get("LinkUrl") is not None:
            session.link_url = str(response_data.get("LinkUrl") or "")

        # WS long-connection URL (optional, for streaming/push features).
        if "WsUrl" in response_data and response_data.get("WsUrl") is not None:
            session.ws_url = str(response_data.get("WsUrl") or "")
        elif "wsUrl" in response_data and response_data.get("wsUrl") is not None:
            session.ws_url = str(response_data.get("wsUrl") or "")

        # Set browser recording state (default to True if not explicitly set to False)
        session.enableBrowserReplay = params.enable_browser_replay if params.enable_browser_replay is not None else True

        # Store image_id used for this session
        setattr(session, "image_id", params.image_id)

        # Process mobile configuration if provided
        if (
            params.extra_configs
            and params.extra_configs.mobile
        ):
            await session.mobile.configure(params.extra_configs.mobile)

        # Store session in cache
        with self._lock:
            self._sessions[session_id] = session

        return session

    # NOTE: Do not fetch MCP tool list automatically for any session.

    async def _wait_for_context_synchronization(
        self,
        session: AsyncSession,
        wait_context_ids: Optional[set[str]] = None,
    ) -> None:
        """
        Wait for context synchronization to complete asynchronously.

        Uses exponential backoff to balance between quick response and server load:
        - Starts with short intervals (0.5s) for fast completion detection
        - Gradually increases intervals (up to 5s max) to reduce server load
        - Uses exponential backoff factor of 1.1

        Args:
            session: The session to wait for context synchronization
            wait_context_ids: If None, wait for all contexts (backward compatible).
                If empty set, return immediately. Otherwise, only wait for the specified
                context IDs to reach terminal status (Success/Failed).
        """
        _log_operation_start("Context synchronization", "Waiting for completion")

        if wait_context_ids is not None and len(wait_context_ids) == 0:
            _log_operation_success("Context synchronization")
            return

        # Exponential backoff configuration
        initial_interval = 0.5  # Start with 0.5 seconds for quick response
        max_interval = 5.0  # Maximum interval to avoid excessive delays
        backoff_factor = 1.1  # Multiply interval by this factor each retry
        max_retries = 50  # Maximum number of retries

        current_interval = initial_interval

        for retry in range(max_retries):
            # Get context status data
            try:
                info_result = await session.context.info()
            except Exception as e:
                _logger.error(f"Error getting context info on attempt {retry+1}: {e}")
                await asyncio.sleep(current_interval)
                current_interval = min(current_interval * backoff_factor, max_interval)
                continue

            if wait_context_ids is None:
                # Backward compatible behavior: wait for all contexts in status list.
                all_completed = True
                has_failure = False

                for item in info_result.context_status_data:
                    _logger.info(
                        f"📁 Context {item.context_id} status: {item.status}, path: {item.path}"
                    )

                    if item.status != "Success" and item.status != "Failed":
                        all_completed = False
                        break

                    if item.status == "Failed":
                        has_failure = True
                        _logger.error(
                            f"❌ Context synchronization failed for {item.context_id}: {item.error_message}"
                        )

                if all_completed or not info_result.context_status_data:
                    if has_failure:
                        _log_warning("Context synchronization completed with failures")
                    else:
                        _log_operation_success("Context synchronization")
                    break
            else:
                # Beta behavior: only wait for selected contexts to complete.
                has_failure = False
                status_by_context_id: dict[str, str] = {}

                for item in info_result.context_status_data:
                    if item.context_id not in wait_context_ids:
                        continue
                    status_by_context_id[item.context_id] = item.status
                    _logger.info(
                        f"📁 Context {item.context_id} status: {item.status}, path: {item.path}"
                    )
                    if item.status == "Failed":
                        has_failure = True
                        _logger.error(
                            f"❌ Context synchronization failed for {item.context_id}: {item.error_message}"
                        )

                all_completed = True
                for ctx_id in wait_context_ids:
                    status = status_by_context_id.get(ctx_id)
                    if status is None or (status != "Success" and status != "Failed"):
                        all_completed = False
                        break

                if all_completed:
                    if has_failure:
                        _log_warning("Context synchronization completed with failures")
                    else:
                        _log_operation_success("Context synchronization")
                    break

            _logger.debug(
                f"⏳ Waiting for context synchronization, attempt {retry+1}/{max_retries}, next interval: {current_interval:.2f}s"
            )
            await asyncio.sleep(current_interval)

            # Exponential backoff: increase interval for next retry, capped at max_interval
            current_interval = min(current_interval * backoff_factor, max_interval)

    async def _wait_for_mobile_simulate(
        self,
        session: AsyncSession,
        mobile_sim_path: str,
        mobile_sim_mode: Optional[str] = None,
    ) -> None:
        """
        Wait for mobile simulate command to complete asynchronously.

        Args:
            session: The session to wait for mobile simulate
            mobile_sim_path: The dev info path to the mobile simulate
            mobile_sim_mode: The mode of the mobile simulate
        """
        _logger.info("⏳ Mobile simulate: Waiting for completion")

        if not hasattr(session, "mobile"):
            _logger.info("Mobile module not found in session, skipping mobile simulate")
            return
        if not hasattr(session, "command"):
            _logger.info(
                "Command module not found in session, skipping mobile simulate"
            )
            return
        if not mobile_sim_path:
            _logger.info("Mobile simulate path is empty, skipping mobile simulate")
            return

        try:
            # Run mobile simulate command
            start_time = time.time()
            dev_info_file_path = f"{mobile_sim_path}/dev_info.json"
            wya_apply_option = ""

            if not mobile_sim_mode or mobile_sim_mode == "PropertiesOnly":
                wya_apply_option = ""
            elif mobile_sim_mode == "SensorsOnly":
                wya_apply_option = "-sensors"
            elif mobile_sim_mode == "PackagesOnly":
                wya_apply_option = "-packages"
            elif mobile_sim_mode == "ServicesOnly":
                wya_apply_option = "-services"
            elif mobile_sim_mode == "All":
                wya_apply_option = "-all"

            command = f"chmod -R a+rwx {mobile_sim_path}; wya apply {wya_apply_option} {dev_info_file_path}".strip()
            _logger.info(
                f"ℹ️  ⏳ Waiting for mobile simulate completion, command: {command}"
            )

            cmd_result = await session.command.execute_command(command)
            if cmd_result.success:
                end_time = time.time()
                consume_time = end_time - start_time
                _logger.info(
                    f"✅ Mobile simulate completed with mode: {mobile_sim_mode or 'PropertiesOnly'}, duration: {consume_time:.2f} seconds"
                )
                if cmd_result.output:
                    _logger.info(f"   Output: {cmd_result.output.strip()}")
            else:
                _logger.info(
                    f"Failed to execute mobile simulate command: {cmd_result.error_message}"
                )
        except Exception as e:
            _logger.info(f"Error executing mobile simulate command: {e}")

    def _log_request_debug_info(self, request: CreateMcpSessionRequest) -> None:
        """
        Log debug information for the request with masked authorization.

        Args:
            request: The request object to log
        """
        try:
            req_map = request.to_map()
            if "Authorization" in req_map and isinstance(req_map["Authorization"], str):
                auth = req_map["Authorization"]
                if len(auth) > 12:
                    req_map["Authorization"] = (
                        auth[:6] + "*" * (len(auth) - 10) + auth[-4:]
                    )
                else:
                    req_map["Authorization"] = auth[:2] + "****" + auth[-2:]
            request_body = json.dumps(req_map, ensure_ascii=False, indent=2)
            _logger.debug(f"📤 CreateMcpSessionRequest body:\n{request_body}")
        except Exception:
            _logger.debug(f"📤 CreateMcpSessionRequest: {request}")

    async def create(
        self, params: Optional[CreateSessionParams] = None
    ) -> SessionResult:
        """
        Create a new session in the AgentBay cloud environment asynchronously.

        Args:
            params (Optional[CreateSessionParams], optional): Parameters for creating the session.
                Defaults to None (uses default configuration).

        Returns:
            SessionResult: Result containing the created session and request ID.
                - success (bool): True if the operation succeeded
                - session (AsyncSession): The created session object (if success is True)
                - request_id (str): Unique identifier for this API request
                - error_message (str): Error description (if success is False)

        Raises:
            ValueError: If API key is not provided and AGENTBAY_API_KEY environment variable is not set.
            ClientException: If the API request fails due to network or authentication issues.

        Example:
            ```python
            result = await agent_bay.create()
            session = result.session
            info_result = await session.info()
            print(f"Session ID: {info_result.session_id}")
            await session.delete()
            ```
        """
        try:
            if params is None:
                params = CreateSessionParams()
            else:
                # Create a deep copy of params to avoid modifying the original object
                params = copy.deepcopy(params)

            # Add context syncs for mobile simulate if simulated_context_id is provided
            if hasattr(params, "extra_configs") and params.extra_configs:
                if params.extra_configs.mobile and params.extra_configs.mobile.simulate_config:
                    mobile_sim_context_id = params.extra_configs.mobile.simulate_config.simulated_context_id
                    if mobile_sim_context_id:
                        from .._common.params.context_sync import ContextSync

                        mobile_sim_context_sync = ContextSync(
                            context_id=mobile_sim_context_id,
                            path=_MOBILE_INFO_DEFAULT_PATH)
                        # params is already a copy, so we can safely modify it
                        if not hasattr(params, "context_syncs") or params.context_syncs is None:
                            params.context_syncs = []
                        _logger.info(
                            f"Adding context sync for mobile simulate: {mobile_sim_context_sync}"
                        )
                        params.context_syncs.append(mobile_sim_context_sync)

            request = CreateMcpSessionRequest(authorization=f"Bearer {self.api_key}")

            # browser replay is enabled by default, so if enable_browser_replay is explicitly False, set enable_record to False
            # Only set enable_record when explicitly False, not when None (which means use default behavior)
            if hasattr(params, "enable_browser_replay") and params.enable_browser_replay is False:
                request.enable_record = False
                _logger.info(f"enable_browser_replay is False, setting enable_record to False")

            # Add SDK stats for tracking
            framework = (
                params.framework if params and hasattr(params, "framework") else ""
            )
            sdk_stats_json = f'{{"source":"sdk","sdk_language":"python","sdk_version":"{__version__}","is_release":{str(__is_release__).lower()},"framework":"{framework}"}}'
            request.sdk_stats = sdk_stats_json

            # Add LoginRegionId if region_id is set
            if self.region_id:
                request.login_region_id = self.region_id

            # Add PolicyId if specified
            if hasattr(params, "policy_id") and params.policy_id:
                request.mcp_policy_id = params.policy_id

            # Beta: Add NetworkId if specified
            if hasattr(params, "beta_network_id") and params.beta_network_id:
                request.network_id = params.beta_network_id

            # SDK idle release timeout (seconds)
            if hasattr(params, "idle_release_timeout") and params.idle_release_timeout is not None:
                request.timeout = params.idle_release_timeout

            # Flag to indicate if we need to wait for context synchronization
            needs_context_sync = False

            # Add context_syncs if provided
            if hasattr(params, "context_syncs") and params.context_syncs:
                from ..api.models import CreateMcpSessionRequestPersistenceDataList

                persistence_data_list = []
                for cs in params.context_syncs:
                    policy_json = None
                    if cs.policy is not None:
                        # Serialize policy to JSON string
                        import json as _json

                        policy_json = _json.dumps(
                            cs.policy, default=self._safe_serialize, ensure_ascii=False
                        )
                    persistence_data_list.append(
                        CreateMcpSessionRequestPersistenceDataList(
                            context_id=cs.context_id, path=cs.path, policy=policy_json
                        )
                    )
                request.persistence_data_list = persistence_data_list
                needs_context_sync = len(persistence_data_list) > 0

            # Add BrowserContext as a ContextSync if provided
            if hasattr(params, "browser_context") and params.browser_context:
                from ..api.models import CreateMcpSessionRequestPersistenceDataList
                from .._common.params.context_sync import (
                    BWList,
                    RecyclePolicy,
                    SyncPolicy,
                    UploadPolicy,
                    WhiteList,
                )

                # Create a new SyncPolicy with default values for browser context
                upload_policy = UploadPolicy(
                    auto_upload=params.browser_context.auto_upload
                )

                # Create BWList with white lists for browser data paths
                white_lists = [
                    WhiteList(path="/Local State", exclude_paths=[]),
                    WhiteList(path="/Default/Cookies", exclude_paths=[]),
                    WhiteList(path="/Default/Cookies-journal", exclude_paths=[]),
                ]
                bw_list = BWList(white_lists=white_lists)

                # Use custom recycle_policy if provided, otherwise use default
                recycle_policy = RecyclePolicy.default()

                sync_policy = SyncPolicy(
                    upload_policy=upload_policy,
                    bw_list=bw_list,
                    recycle_policy=recycle_policy,
                )

                # Serialize policy to JSON string
                import json as _json

                policy_json = _json.dumps(
                    sync_policy, default=self._safe_serialize, ensure_ascii=False
                )

                # Create browser context sync item
                browser_context_sync = CreateMcpSessionRequestPersistenceDataList(
                    context_id=params.browser_context.context_id,
                    path=_BROWSER_DATA_PATH,  # Using a constant path for browser data
                    policy=policy_json,
                )

                # Add to persistence data list or create new one if not exists
                if (
                    not hasattr(request, "persistence_data_list")
                    or request.persistence_data_list is None
                ):
                    request.persistence_data_list = []
                request.persistence_data_list.append(browser_context_sync)
                _logger.info(
                    f"📋 Added browser context to persistence_data_list. Total items: {len(request.persistence_data_list)}"
                )
                for i, item in enumerate(request.persistence_data_list):
                    _logger.info(
                        f"📋 persistence_data_list[{i}]: context_id={item.context_id}, path={item.path}, policy_length={len(item.policy) if item.policy else 0}"
                    )
                    _logger.info(
                        f"📋 persistence_data_list[{i}] policy content: {item.policy}"
                    )

                needs_context_sync = True

            # Add labels if provided
            if params.labels:
                # Convert labels to JSON string
                request.labels = json.dumps(params.labels)

            if params.image_id:
                request.image_id = params.image_id

            # Add extra_configs if provided
            mobile_sim_path = None
            needs_mobile_sim = False
            mobile_sim_mode = None

            if hasattr(params, "extra_configs") and params.extra_configs:
                request.extra_configs = params.extra_configs

                # Check mobile simulate config
                if (
                    params.extra_configs.mobile
                    and hasattr(params.extra_configs.mobile, "simulate_config")
                    and params.extra_configs.mobile.simulate_config
                    and params.extra_configs.mobile.simulate_config.simulate
                ):
                    mobile_sim_path = (
                        params.extra_configs.mobile.simulate_config.simulate_path
                    )
                    if not mobile_sim_path:
                        _logger.info(
                            "mobile_sim_path is not set now, skip mobile simulate operation"
                        )
                    else:
                        needs_mobile_sim = True
                        mobile_sim_mode = (
                            params.extra_configs.mobile.simulate_config.simulate_mode
                        )

            self._log_request_debug_info(request)

            # Use async client method
            response = await self.client.create_mcp_session_async(request)

            # Extract request ID
            request_id = extract_request_id(response)

            try:
                response_body = json.dumps(
                    response.to_map().get("body", {}), ensure_ascii=False, indent=2
                )
            except Exception:
                response_body = str(response)

            session_data = response.to_map()

            if not isinstance(session_data, dict):
                return SessionResult(
                    request_id=request_id,
                    success=False,
                    error_message="Invalid response format: expected a dictionary",
                )

            body = session_data.get("body", {})
            if not isinstance(body, dict):
                return SessionResult(
                    request_id=request_id,
                    success=False,
                    error_message="Invalid response format: "
                    "'body' field is not a dictionary",
                )

            # Check for API-level errors
            if not body.get("Success", True) and body.get("Code"):
                code = body.get("Code", "Unknown")
                message = body.get("Message", "Unknown error")
                return SessionResult(
                    request_id=request_id,
                    success=False,
                    error_message=f"[{code}] {message}",
                )

            data = body.get("Data", {})
            if not isinstance(data, dict):
                return SessionResult(
                    request_id=request_id,
                    success=False,
                    error_message="Invalid response format: "
                    "'Data' field is not a dictionary",
                )

            # Check if the session creation was successful
            if data.get("Success") is False:
                error_msg = data.get("ErrMsg", "Session creation failed")
                return SessionResult(
                    request_id=request_id,
                    success=False,
                    error_message=error_msg,
                )

            session_id = data.get("SessionId")
            if not session_id:
                return SessionResult(
                    request_id=request_id,
                    success=False,
                    error_message="SessionId not found in response",
                )

            # Log API response with key details
            resource_url = data.get("ResourceUrl", "")
            app_instance_id = data.get("AppInstanceId", "") or ""
            key_fields = {"session_id": session_id, "resource_url": resource_url}
            if app_instance_id:
                key_fields["AppInstanceId"] = app_instance_id
            _log_api_response_with_details(
                api_name="CreateSession",
                request_id=request_id,
                success=True,
                key_fields=key_fields,
                full_response=response_body,
            )

            # Build Session object from response data
            session = await self._build_session_from_response(data, params)

            wait_context_ids: Optional[set[str]] = None
            if hasattr(params, "context_syncs") and params.context_syncs:
                wait_context_ids = set()
                for cs in params.context_syncs:
                    wait = getattr(cs, "beta_wait_for_completion", None)
                    if wait is None or wait:
                        wait_context_ids.add(cs.context_id)

            if hasattr(params, "browser_context") and params.browser_context:
                if wait_context_ids is None:
                    wait_context_ids = set()
                wait_context_ids.add(params.browser_context.context_id)

            if (
                hasattr(params, "extra_configs")
                and params.extra_configs
                and params.extra_configs.mobile
                and params.extra_configs.mobile.simulate_config
                and params.extra_configs.mobile.simulate_config.simulated_context_id
            ):
                if wait_context_ids is None:
                    wait_context_ids = set()
                wait_context_ids.add(params.extra_configs.mobile.simulate_config.simulated_context_id)

            # If we have persistence data, wait for context synchronization
            if needs_context_sync:
                await self._wait_for_context_synchronization(
                    session,
                    wait_context_ids=wait_context_ids,
                )

            # If we need to do mobile simulate by command, wait for it
            if needs_mobile_sim and mobile_sim_path:
                await self._wait_for_mobile_simulate(
                    session, mobile_sim_path, mobile_sim_mode
                )

            # Return SessionResult with request ID
            return SessionResult(request_id=request_id, success=True, session=session)

        except ClientException as e:
            _log_operation_error(
                "create_mcp_session - ClientException", str(e), exc_info=True
            )
            return SessionResult(
                request_id="",
                success=False,
                error_message=f"Failed to create session: {e}",
            )
        except Exception as e:
            _log_operation_error("create_mcp_session", str(e), exc_info=True)
            return SessionResult(
                request_id="",
                success=False,
                error_message=f"Unexpected error creating session: {e}",
            )

    async def list(
        self,
        labels: Optional[Dict[str, str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        status: Optional[str] = None,
    ) -> SessionListResult:
        """
        Returns paginated list of session IDs filtered by labels asynchronously.

        Args:
            labels (Optional[Dict[str, str]], optional): Labels to filter sessions.
                Defaults to None (returns all sessions).
            page (Optional[int], optional): Page number for pagination (starting from 1).
                Defaults to None (returns first page).
            limit (Optional[int], optional): Maximum number of items per page.
                Defaults to None (uses default of 10).
            status (Optional[str], optional): Status to filter sessions. Must be one of:
                RUNNING, PAUSING, PAUSED, RESUMING, DELETING, DELETED.
                Defaults to None (returns sessions with any status).

        Returns:
            SessionListResult: Paginated list of session IDs that match the filters.
        """
        try:
            # Set default values
            if labels is None:
                labels = {}
            if limit is None:
                limit = 10

            # Validate status parameter
            if status is not None:
                valid_statuses = [s.value for s in SessionStatus]
                if status not in valid_statuses:
                    return SessionListResult(
                        request_id="",
                        success=False,
                        error_message=f"Invalid status '{status}'. Must be one of: {', '.join(valid_statuses)}",
                        session_ids=[],
                        next_token="",
                        max_results=limit,
                        total_count=0,
                    )

            # Validate page number
            if page is not None and page < 1:
                return SessionListResult(
                    request_id="",
                    success=False,
                    error_message=f"Cannot reach page {page}: Page number must be >= 1",
                    session_ids=[],
                    next_token="",
                    max_results=limit,
                    total_count=0,
                )

            # Calculate next_token based on page number
            next_token = ""
            if page is not None and page > 1:
                # We need to fetch pages 1 through page-1 to get the next_token
                current_page = 1
                while current_page < page:
                    # Make API call to get next_token
                    labels_json = json.dumps(labels)
                    request = ListSessionRequest(
                        authorization=f"Bearer {self.api_key}",
                        labels=labels_json,
                        max_results=limit,
                        status=status,
                    )
                    if next_token:
                        request.next_token = next_token

                    # Async API call
                    response = await self.client.list_session_async(request)
                    request_id = extract_request_id(response)
                    response_map = response.to_map()
                    body = response_map.get("body", {})

                    if not body.get("Success", False):
                        error_message = body.get(
                            "Message", body.get("Code", "Unknown error")
                        )
                        return SessionListResult(
                            request_id=request_id,
                            success=False,
                            error_message=f"Cannot reach page {page}: {error_message}",
                            session_ids=[],
                            next_token="",
                            max_results=limit,
                            total_count=0,
                        )

                    next_token = body.get("NextToken", "")
                    if not next_token:
                        # No more pages available
                        return SessionListResult(
                            request_id=request_id,
                            success=False,
                            error_message=f"Cannot reach page {page}: No more pages available",
                            session_ids=[],
                            next_token="",
                            max_results=limit,
                            total_count=body.get("TotalCount", 0),
                        )
                    current_page += 1

            # Make the actual request for the desired page
            labels_json = json.dumps(labels)
            request = ListSessionRequest(
                authorization=f"Bearer {self.api_key}",
                labels=labels_json,
                max_results=limit,
                status=status,
            )
            if next_token:
                request.next_token = next_token

            request_details = f"Labels={labels_json}, MaxResults={limit}"
            if request.next_token:
                request_details += f", NextToken={request.next_token}"
            if status:
                request_details += f", Status={status}"
            _log_api_call("list_session", request_details)

            # Make the API call asynchronously
            response = await self.client.list_session_async(request)

            # Extract request ID
            request_id = extract_request_id(response)

            response_map = response.to_map()
            body = response_map.get("body", {})

            # Check for errors in the response
            if isinstance(body, dict) and body.get("Success") is False:
                error_message = body.get("Message", body.get("Code", "Unknown error"))
                return SessionListResult(
                    request_id=request_id,
                    success=False,
                    error_message=f"Failed to list sessions: {error_message}",
                    session_ids=[],
                    next_token="",
                    max_results=limit,
                    total_count=0,
                )

            session_ids = []
            next_token = ""
            max_results = limit  # Use the requested max_results
            total_count = 0

            try:
                response_body = json.dumps(body, ensure_ascii=False, indent=2)
            except Exception:
                response_body = str(body)

            # Extract pagination information
            if isinstance(body, dict):
                next_token = body.get("NextToken", "")
                # Use API response MaxResults if present, otherwise use requested value
                max_results = int(body.get("MaxResults", limit))
                total_count = int(body.get("TotalCount", 0))

            # Extract session data
            response_data = body.get("Data")
            _logger.info(f"  ✓ ListSession API call async successful{response_data}")
            # Handle both list and dict responses
            if isinstance(response_data, list):
                # Data is a list of session objects
                for session_data in response_data:
                    if isinstance(session_data, dict):
                        session_id = session_data.get("SessionId")
                        session_status = session_data.get("SessionStatus")
                        if session_id:
                            # Create a structured session object with both ID and status
                            session_info = {
                                "sessionId": session_id,
                                "sessionStatus": session_status if session_status else "UNKNOWN"
                            }
                            session_ids.append(session_info)

            # Log API response with key details
            _log_api_response_with_details(
                api_name="ListSession",
                request_id=request_id,
                success=True,
                key_fields={
                    "total_count": total_count,
                    "returned_count": len(session_ids),
                    "has_more": "yes" if next_token else "no",
                },
                full_response=response_body,
            )

            # Return SessionListResult with request ID and pagination info
            return SessionListResult(
                request_id=request_id,
                success=True,
                session_ids=session_ids,
                next_token=next_token,
                max_results=max_results,
                total_count=total_count,
            )

        except Exception as e:
            _log_operation_error("list_session", str(e), exc_info=True)
            return SessionListResult(
                request_id="",
                success=False,
                session_ids=[],
                error_message=f"Failed to list sessions: {e}",
            )

    async def delete(
        self, session: AsyncSession, sync_context: bool = False
    ) -> DeleteResult:
        """
        Delete a session by session object asynchronously.

        Args:
            session (AsyncSession): The session to delete.
            sync_context (bool): Whether to sync context data (trigger file uploads)
                before deleting the session. Defaults to False.

        Returns:
            DeleteResult: Result indicating success or failure and request ID.
        """
        try:
            # Delete the session and get the result
            delete_result = await session.delete(sync_context=sync_context)

            with self._lock:
                self._sessions.pop(session.session_id, None)

            # Return the DeleteResult obtained from session.delete()
            return delete_result

        except Exception as e:
            _log_operation_error("delete_session", str(e), exc_info=True)
            return DeleteResult(
                request_id="",
                success=False,
                error_message=f"Failed to delete session {session.session_id}: {e}",
            )

    async def _get_session(self, session_id: str) -> GetSessionResult:
        """
        Get session information by session ID asynchronously.

        This method retrieves detailed session metadata from the API. Unlike `get()`,
        this returns raw session data without creating a Session object.

        Args:
            session_id (str): The ID of the session to retrieve.

        Returns:
            GetSessionResult: Result containing session information.
        """
        try:
            _log_api_call("GetSession", f"SessionId={session_id}")
            request = GetSessionRequest(
                authorization=f"Bearer {self.api_key}", session_id=session_id
            )
            # Async API call
            response = await self.client.get_session_async(request)

            request_id = extract_request_id(response)

            try:
                response_body = json.dumps(
                    response.to_map().get("body", {}), ensure_ascii=False, indent=2
                )
            except Exception:
                response_body = str(response)

            try:
                response_map = response.to_map()
                body = response_map.get("body", {})
                http_status_code = body.get("HttpStatusCode", 0)
                code = body.get("Code", "")
                success = body.get("Success", False)
                message = body.get("Message", "")

                # Check for API-level errors
                if not success and code:
                    return GetSessionResult(
                        request_id=request_id,
                        http_status_code=http_status_code,
                        code=code,
                        success=False,
                        data=None,
                        error_message=f"[{code}] {message or 'Unknown error'}",
                    )

                data = None
                if body.get("Data"):
                    data_dict = body.get("Data", {})
                    _logger.info(f"  ✓ GetSession API call async successful{data_dict}")
                    data = GetSessionData(
                        app_instance_id=data_dict.get("AppInstanceId", ""),
                        resource_id=data_dict.get("ResourceId", ""),
                        session_id=data_dict.get("SessionId", ""),
                        success=data_dict.get("Success", False),
                        http_port=data_dict.get("HttpPort", ""),
                        network_interface_ip=data_dict.get("NetworkInterfaceIp", ""),
                        token=data_dict.get("Token", ""),
                        link_url=data_dict.get("LinkUrl", "") or "",
                        ws_url=data_dict.get("WsUrl", "") or data_dict.get("wsUrl", "") or "",
                        vpc_resource=data_dict.get("VpcResource", False),
                        resource_url=data_dict.get("ResourceUrl", ""),
                        status=data_dict.get("Status", ""),
                        tool_list=data_dict.get("ToolList", "") or "",
                    )

                # Log API response with key details
                key_fields = {}
                if data:
                    key_fields["session_id"] = data.session_id
                    key_fields["vpc_resource"] = "yes" if data.vpc_resource else "no"
                _log_api_response_with_details(
                    api_name="GetSession",
                    request_id=request_id,
                    success=success,
                    key_fields=key_fields,
                    full_response=response_body,
                )

                return GetSessionResult(
                    request_id=request_id,
                    http_status_code=http_status_code,
                    code=code,
                    success=success,
                    data=data,
                    error_message="",
                )

            except Exception as e:
                _logger.exception(f"Failed to parse response: {str(e)}")
                return GetSessionResult(
                    request_id=request_id,
                    success=False,
                    error_message=f"Failed to parse response: {str(e)}",
                )
        except ClientException as e:
            # Check if this is an expected business error (e.g., session not found)
            error_str = str(e)
            if "InvalidMcpSession.NotFound" in error_str or "NotFound" in error_str:
                # This is an expected error - session doesn't exist
                # Use info level logging without stack trace, but with red color for visibility
                _log_info_with_color(f"Session not found: {session_id}")
                _logger.debug(f"GetSession error details: {error_str}")
                return GetSessionResult(
                    request_id="",
                    success=False,
                    error_message=f"Session {session_id} not found",
                )
            else:
                # This is an unexpected error - log with stack trace
                _logger.error(f"Error calling GetSession: {e}")
                return GetSessionResult(
                    request_id="",
                    success=False,
                    error_message=f"Failed to get session {session_id}: {e}",
                )
        except Exception as e:
            # Unexpected system error - log with stack trace
            _logger.exception(f"Unexpected error calling GetSession: {e}")
            return GetSessionResult(
                request_id="",
                success=False,
                error_message=f"Failed to get session {session_id}: {e}",
            )

    async def get(self, session_id: str) -> SessionResult:
        """
        Get a session by its ID asynchronously.

        Args:
            session_id (str): The ID of the session to retrieve. Must be a non-empty string.

        Returns:
            SessionResult: Result containing the Session instance, request ID, and success status.
        """
        # Validate input
        if not session_id or (isinstance(session_id, str) and not session_id.strip()):
            return SessionResult(
                request_id="",
                success=False,
                error_message="session_id is required",
            )

        # Call GetSession API
        get_result = await self._get_session(session_id)

        # Check if the API call was successful
        if not get_result.success:
            error_msg = get_result.error_message or "Unknown error"
            return SessionResult(
                request_id=get_result.request_id,
                success=False,
                error_message=f"Failed to get session {session_id}: {error_msg}",
            )

        # Create the Session object
        session = AsyncSession(self, session_id)

        # Set ResourceUrl from GetSession response
        if get_result.data:
            session.resource_url = get_result.data.resource_url
            session.mcpTools = self._parse_tool_list_to_mcp_tools(get_result.data.tool_list)
            session.token = str(get_result.data.token or "")
            session.link_url = str(getattr(get_result.data, "link_url", "") or "")
            session.ws_url = str(getattr(get_result.data, "ws_url", "") or "")

        return SessionResult(
            request_id=get_result.request_id,
            success=True,
            session=session,
        )

    async def beta_pause(
        self, session: AsyncSession, timeout: int = 600, poll_interval: float = 2.0
    ) -> SessionPauseResult:
        """
        Asynchronously pause a session (beta), putting it into a dormant state.

        Note:
            This feature is currently in whitelist-only access.
            Contact agentbay_dev@alibabacloud.com to request access.
        """
        try:
            return await session.beta_pause(timeout, poll_interval)
        except Exception as e:
            _log_operation_error("beta_pause_session", str(e), exc_info=True)
            return SessionPauseResult(
                request_id="",
                success=False,
                error_message=f"Failed to pause session {session.session_id}: {e}",
            )

    async def beta_resume(
        self, session: AsyncSession, timeout: int = 600, poll_interval: float = 2.0
    ) -> SessionResumeResult:
        """
        Asynchronously resume a session (beta) from a paused state.
        """
        try:
            return await session.beta_resume(timeout, poll_interval)
        except Exception as e:
            _log_operation_error("beta_resume_session", str(e), exc_info=True)
            return SessionResumeResult(
                request_id="",
                success=False,
                error_message=f"Failed to resume session {session.session_id}: {e}",
            )

