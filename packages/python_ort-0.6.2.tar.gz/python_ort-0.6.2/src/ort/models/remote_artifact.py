# SPDX-FileCopyrightText: 2025 Helio Chissini de Castro <heliocastro@gmail.com>
# SPDX-License-Identifier: MIT


from pydantic import BaseModel, Field

from .hash import Hash


class RemoteArtifact(BaseModel):
    """
    Bundles information about a remote artifact.
    """

    url: str = Field(
        default_factory=str,
        description="The URL of the remote artifact.",
    )
    hash: Hash | None = Field(
        default=None,
        description="The hash of the remote artifact.",
    )
