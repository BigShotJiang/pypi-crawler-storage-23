"""Sun Hit Detector.

A deterministic geometric library that determines if direct sunlight
passes through windows and strikes a target region.
"""

__version__ = "0.1.0"
