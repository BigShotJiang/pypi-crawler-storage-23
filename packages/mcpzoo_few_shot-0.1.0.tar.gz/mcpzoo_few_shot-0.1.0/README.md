# mcpzoo-few-shot

> Few-shot 模板 — 生成 few-shot 学习的提示词模板

## Installation

```bash
uvx mcpzoo-few-shot
```

## uvx JSON

```json
{
  "mcpServers": {
    "few-shot": {
      "args": ["mcpzoo-few-shot"],
      "command": "uvx"
    }
  }
}
```
