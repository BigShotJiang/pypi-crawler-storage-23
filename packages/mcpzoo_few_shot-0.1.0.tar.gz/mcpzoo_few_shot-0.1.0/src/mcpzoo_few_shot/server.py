from mcp.server.fastmcp import FastMCP

mcp = FastMCP("few-shot")

@mcp.tool()
def gen_few_shot(task: str, examples: str, input_text: str = "{input}") -> str:
    """生成 few-shot (少量样本学习) 的提示词模板。
    
    examples 格式：用 '|' 分隔不同样例，用 '->' 分隔输入输出。
    例如：'好开心->正面|太难了->负面'
    """
    prompt = f"请执行以下任务：【{task}】\n\n"
    prompt += "下面是一些示例：\n\n"
    
    ex_list = examples.split("|")
    for i, ex in enumerate(ex_list, 1):
        if "->" in ex:
            inp, out = ex.split("->", 1)
            prompt += f"示例 {i}:\n输入: {inp.strip()}\n输出: {out.strip()}\n\n"
            
    prompt += "现在，请参考上述示例，处理我的输入：\n\n"
    prompt += f"输入: {input_text}\n输出: "
    
    return prompt

def main():
    mcp.run()

if __name__ == "__main__":
    main()
