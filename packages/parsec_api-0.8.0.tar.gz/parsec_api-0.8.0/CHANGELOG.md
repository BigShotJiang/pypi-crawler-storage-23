# Changelog

## 0.8.0 (2026-02-18)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/parsecular/sdk-python/compare/v0.7.0...v0.8.0)

### Features

* **api:** api update ([aebf341](https://github.com/parsecular/sdk-python/commit/aebf341783113c8101ce62cf57e13c7e7564ca5e))


### Bug Fixes

* **ws:** deterministic socket teardown and stronger contract checks ([21eead3](https://github.com/parsecular/sdk-python/commit/21eead31765bec3049d29906ae12941fce3b4c53))

## 0.7.0 (2026-02-18)

Full Changelog: [v0.6.0...v0.7.0](https://github.com/parsecular/sdk-python/compare/v0.6.0...v0.7.0)

### Features

* **api:** api update ([047ead2](https://github.com/parsecular/sdk-python/commit/047ead2398813972a84cef02818ca99fffb95f7e))
* **api:** api update ([0251820](https://github.com/parsecular/sdk-python/commit/0251820889990f62543235574369c225d747c4c2))


### Bug Fixes

* **py:** align exchange re-export aliases with lint rules ([ed3e89d](https://github.com/parsecular/sdk-python/commit/ed3e89dff5a795f06b6de8b3bd0f72be94bce59d))
* **py:** re-export exchange aliases without triggering F401 ([6c5bd24](https://github.com/parsecular/sdk-python/commit/6c5bd24b9485f873d8f78098e835b9b0781415d0))
* **py:** restore exchange type aliases after codegen rename ([05f02c8](https://github.com/parsecular/sdk-python/commit/05f02c81634c683bbd538576535ace87622399de))

## 0.6.0 (2026-02-17)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/parsecular/sdk-python/compare/v0.5.0...v0.6.0)

### Features

* **api:** 0.5.1 contract and execution-price update ([3a1493c](https://github.com/parsecular/sdk-python/commit/3a1493cc0d0a5342830865fdaca43a7ae482b0ea))


### Bug Fixes

* **pyright:** relax example typing and guard error-body casting ([c65f22f](https://github.com/parsecular/sdk-python/commit/c65f22fd68a8e2cb7ad912ecaef648b710805304))


### Styles

* fix lint failures ([26e987c](https://github.com/parsecular/sdk-python/commit/26e987c71c07e4ea464ca9392d9142323b702498))

## 0.5.0 (2026-02-16)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/parsecular/sdk-python/compare/v0.4.0...v0.5.0)

### Features

* **api:** api update ([d16f3d9](https://github.com/parsecular/sdk-python/commit/d16f3d999af934631f76a1ac593c6f38e49c7cdb))
* **api:** api update ([85a08f0](https://github.com/parsecular/sdk-python/commit/85a08f037f6e96dd6bfcafe69d0e4f88bc98dde4))


### Bug Fixes

* remove duplicate events resource properties from merge ([340fc15](https://github.com/parsecular/sdk-python/commit/340fc15ad7f95cae8bcda025ea45c136f072028e))

## 0.4.0 (2026-02-15)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/parsecular/sdk-python/compare/v0.3.0...v0.4.0)

### ⚠ BREAKING CHANGES

This release migrates the `Market` type to the new Silver layer schema. All field names have changed. See the **Migration Guide** below.

**Market field renames:**
* `id` has been renamed to `exchange_market_id`
* `title` has been renamed to `question`
* `volume` (integer) has been replaced by `volume_total` (number/float)
* `group_id` has been renamed to `exchange_group_id`
* `event_id` has been renamed to `parsec_group_id`
* `close_time` has been renamed to `end_date`
* `open_time` has been renamed to `event_start_time`
* `status` changed from enum (`active | closed | resolved`) to plain string

**Market field type changes:**
* `outcomes` changed from `list[str]` to `list[Outcome]` objects with `name`, `price`, and `token_id` attributes

**Removed Market fields:**
* `meta` (`ResponseMeta`) — removed from responses
* `outcome_tokens` — removed
* `token_id_yes` / `token_id_no` — removed (token IDs now inside `Outcome` objects)
* `outcome_prices` — removed
* `volume_1wk` / `volume_1mo` — removed

### Features

* **api:** add Events resource — `client.events.list()` for querying aggregated market groups
* **api:** new Market fields: `parsec_group_id`, `best_bid`, `best_ask`, `last_price`, `volume_24h`, `open_interest`, `created_at`, `updated_at`, `url`, `rules`, `group_title`, `outcome_count`, `xref`, `collection_date`, `last_collected`
* **ws:** add `get_book()` method to read current local orderbook state
* **ws:** add `off()` method to unregister event handlers

### Bug Fixes

* **ws:** add auth timeout — no longer hangs forever on unresponsive server
* **ws:** fix `connected` event firing before `auth_ok` received
* **ws:** callback exceptions are now logged instead of silently swallowed
* **ws:** WebSocket send failures are now logged

### Migration Guide

**Accessing market identity:**

```python
# v0.3.0
market_id = market.id
title = market.title

# v0.4.0
market_id = market.exchange_market_id
title = market.question
```

**Working with outcomes (most impactful change):**

```python
# v0.3.0
outcomes: list[str] = market.outcomes         # ["Yes", "No"]
yes_token = market.token_id_yes
no_token = market.token_id_no
prices = market.outcome_prices

# v0.4.0
outcomes: list[Outcome] = market.outcomes     # [Outcome(name="Yes", price=0.65, token_id="abc"), ...]
yes_outcome = next(o for o in outcomes if o.name == "Yes")
yes_token = yes_outcome.token_id
yes_price = yes_outcome.price
```

**Volume and timing fields:**

```python
# v0.3.0
vol = market.volume         # int
close = market.close_time
open_ = market.open_time

# v0.4.0
vol = market.volume_total   # float
close = market.end_date
open_ = market.event_start_time
# New volume field:
vol_24h = market.volume_24h
```

**Group and event references:**

```python
# v0.3.0
group_id = market.group_id
event_id = market.event_id

# v0.4.0
group_id = market.exchange_group_id
event_id = market.parsec_group_id
```

**Events (new resource):**

```python
events = client.events.list(exchange="polymarket")
for event in events.data:
    print(event.title, len(event.markets))
```

**WebSocket orderbook reading:**

```python
ws = client.ws(exchange="kalshi")
ws.subscribe("orderbook", parsec_id)

# Read current book state at any time
book = ws.get_book(parsec_id)

# Unregister a handler
def on_book(data):
    print(data)

ws.on("orderbook", on_book)
# Later:
ws.off("orderbook", on_book)
```

## 0.3.0 (2026-02-12)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/parsecular/sdk-python/compare/v0.2.0...v0.3.0)

### Features

* **api:** api update ([38ae803](https://github.com/parsecular/sdk-python/commit/38ae8035ade7defc4f477fbd2fb854184c54571d))

## 0.2.0 (2026-02-12)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/parsecular/sdk-python/compare/v0.1.0...v0.2.0)

### Features

* **api:** api update ([e888e12](https://github.com/parsecular/sdk-python/commit/e888e129d9c7d67a1ae70ea8f92627fea4edce4b))


### Bug Fixes

* use correct candle.timestamp field + resolve README merge conflict ([e7e6b54](https://github.com/parsecular/sdk-python/commit/e7e6b546de618727bcaf26587f42f90e0b1cce37))
* **ws:** add missing needs_refresh book state + fill activity tests ([16468a2](https://github.com/parsecular/sdk-python/commit/16468a2056173adc8bc799523070812063bfcfb5))


### Chores

* **internal:** fix lint error on Python 3.14 ([4e37033](https://github.com/parsecular/sdk-python/commit/4e370332461fdf2203a01a2ff290c6b02a90e333))


### Styles

* fix ruff import sorting in contract tests ([d48b74b](https://github.com/parsecular/sdk-python/commit/d48b74b05678dca25d7ada9749eca439d8838839))

## 0.1.0 (2026-02-12)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/parsecular/sdk-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([709899f](https://github.com/parsecular/sdk-python/commit/709899f73261abc6fde51b4655b520e64c507ad8))
* **api:** api update ([071add8](https://github.com/parsecular/sdk-python/commit/071add84db413b0d35c6f8a7912c8eb8dc548bca))
* **api:** api update ([14ef974](https://github.com/parsecular/sdk-python/commit/14ef9741162ba90c2c7e3d990b2d1a8b63aebee0))
* **ws:** add WebSocket streaming client with stateful orderbook ([6ef9e5d](https://github.com/parsecular/sdk-python/commit/6ef9e5dc1463409ef08b8f10cabf1386c8aa932c))


### Bug Fixes

* resolve pyright strict mode errors in streaming client ([9310dd7](https://github.com/parsecular/sdk-python/commit/9310dd7b51146c22b3aa2fa7cc5931ab7a6f133d))
* resolve pyright strict mode errors in streaming module ([a6e8811](https://github.com/parsecular/sdk-python/commit/a6e8811af6552331504a0e87042bc6357466c814))
* resolve remaining pyright unknown argument errors ([e31e1b1](https://github.com/parsecular/sdk-python/commit/e31e1b16c58cc1f9a3099c687e105c42c281b4c6))


### Styles

* fix ruff import sorting and remove unused math import ([59c32dc](https://github.com/parsecular/sdk-python/commit/59c32dc6b8b52664dfa1d650d54abf92569a8280))
* fix ruff import sorting in _client.py ([0023d5c](https://github.com/parsecular/sdk-python/commit/0023d5c3425fd13f30a6c6a46d9ede3118857d70))
* fix ruff import sorting in types ([fab7e60](https://github.com/parsecular/sdk-python/commit/fab7e604e6660defc53706d3c2a4701677dd47b3))
