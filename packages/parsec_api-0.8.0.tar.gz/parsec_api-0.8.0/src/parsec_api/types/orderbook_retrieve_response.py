# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from .._models import BaseModel

__all__ = ["OrderbookRetrieveResponse"]


class OrderbookRetrieveResponse(BaseModel):
    asks: List[List[float]]

    bids: List[List[float]]

    exchange: str

    market_id: str

    outcome: str

    parsec_id: str

    token_id: str

    min_order_size: Optional[float] = None
    """Minimum order size in contracts."""

    tick_size: Optional[float] = None
    """Minimum price increment for orders on this market."""

    timestamp: Optional[datetime] = None
