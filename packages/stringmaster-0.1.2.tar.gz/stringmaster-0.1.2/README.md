# stringmaster

A lightweight Python utility library for string operations and validation.

## Features

- Validate email, phone, and custom patterns
- String manipulations (uppercase, lowercase, trimming, etc.)
- Easy to integrate

## Installation

```bash
pip install stringmaster