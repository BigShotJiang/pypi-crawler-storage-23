# stringmaster/__init__.py

from .palindrome import is_palindrome
from .anagram import are_anagrams
from .validation import validate_email, validate_phone

# Now users can do:
# from stringmaster import is_palindrome, validate_email, etc.