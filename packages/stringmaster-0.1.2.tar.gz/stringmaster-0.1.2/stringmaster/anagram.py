def are_anagrams(word1, word2):
    """
    Determine whether two strings are anagrams of each other.
    """

    # Validate input types
    if not isinstance(word1, str) or not isinstance(word2, str):
        return False

    # Normalize input:
    # - Remove spaces
    # - Convert to lowercase for case-insensitive comparison
    word1 = word1.replace(" ", "").lower()
    word2 = word2.replace(" ", "").lower()

    # Compare sorted characters of both words
    # If identical, they are anagrams
    return sorted(word1) == sorted(word2)
