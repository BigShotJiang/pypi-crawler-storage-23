def is_palindrome(text):
    """
    Determine whether the given input is a palindrome.
    """

    # Convert input to string to ensure consistent comparison
    word = str(text)

    # Compare the string with its reversed version
    return word == word[::-1]