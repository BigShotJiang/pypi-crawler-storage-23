import string


def is_valid_email(email: str) -> bool:
    """
    Validate an email address based on basic structural rules.

    Rules:
    - Must be a string.
    - Must contain exactly one '@' symbol.
    - Username (before '@') cannot be empty.
    - Domain must contain at least one '.'.
    - Domain cannot start or end with a '.'.
    - Email must not contain blocked special characters or spaces.
    """

    # Ensure input type is string
    if not isinstance(email, str):
        return False

    # Email must contain exactly one '@'
    if email.count("@") != 1:
        return False

    # Split email into username and domain
    username, domain = email.split("@", 1)

    # Username must not be empty
    if not username:
        return False

    # Domain must contain at least one dot
    if "." not in domain:
        return False

    # Disallowed characters inside email
    blocked_chars = [
        "!", "#", "$", "%", "&", "'", "*", "/",
        "=", "?", "^", "`", "{", "|", "}", "~", " "
    ]

    # Domain cannot start or end with '.'
    if domain.startswith(".") or domain.endswith("."):
        return False

    # Ensure no blocked characters exist
    for ch in blocked_chars:
        if ch in email:
            return False

    return True


def is_strong_password(password):
    """
    Validate password strength.

    Rules:
    - Must be a string.
    - Minimum length: 8 characters.
    - Must contain at least one lowercase letter.
    - Must contain at least one uppercase letter.
    - Must contain at least one digit.
    - Must contain at least one special character.
    """

    # Ensure input type is string
    if not isinstance(password, str):
        return False, "Password must be a string"

    # Enforce minimum length requirement
    if len(password) < 8:
        return False, "Password must contain at least 8 characters"

    # Check for at least one lowercase character
    if not any(ch.islower() for ch in password):
        return False, "Password must contain at least one lowercase letter"

    # Check for at least one uppercase character
    if not any(ch.isupper() for ch in password):
        return False, "Password must contain at least one uppercase letter"

    # Check for at least one numeric digit
    if not any(ch.isdigit() for ch in password):
        return False, "Password must contain at least one digit"

    # Check for at least one special character
    if not any(ch in string.punctuation for ch in password):
        return False, "Password must contain at least one special character"

    return True, "Strong password"


def is_valid_phone_number(number: str):
    """
    Validate Indian mobile phone number.

    Rules:
    - Must be a string.
    - May optionally start with '+91' country code.
    - May optionally start with '0'.
    - After normalization, must contain exactly 10 digits.
    - Must start with 6, 7, 8, or 9.
    """

    # Ensure input type is string
    if not isinstance(number, str):
        return False, "Phone number must be a string"

    # Remove Indian country code if present
    if number.startswith("+91"):
        number = number[3:]

    # Remove leading zero if present
    if number.startswith("0"):
        number = number[1:]

    # Ensure all remaining characters are digits
    if not number.isdigit():
        return False, "Phone number must contain only digits"

    # Ensure length is exactly 10 digits
    if len(number) != 10:
        return False, "Phone number must contain exactly 10 digits"

    # Ensure number starts with valid Indian mobile prefix
    if number[0] not in "6789":
        return False, "Invalid Indian mobile number"

    return True, "Valid phone number"


print(is_valid_phone_number("9538978976"))