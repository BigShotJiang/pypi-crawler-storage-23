# Viethas Website Scan v1.6
## Tính năng mới
- fix lỗi còn frame-blank trong frame-repeat và xóa các đối tượng contact popup.