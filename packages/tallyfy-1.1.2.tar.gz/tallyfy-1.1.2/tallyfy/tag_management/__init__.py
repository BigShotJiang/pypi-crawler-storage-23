"""
Tag management module for Tallyfy SDK
"""

from .operations import TagManager

__all__ = ['TagManager']
