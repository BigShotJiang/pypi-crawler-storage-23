from ._dispatcher import fetch_marketplace

__all__ = ["fetch_marketplace"]
