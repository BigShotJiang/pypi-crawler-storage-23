---
name: minimal-agent
description: A minimal agent with no optional fields
tools: Read
---

A minimal agent for testing.
