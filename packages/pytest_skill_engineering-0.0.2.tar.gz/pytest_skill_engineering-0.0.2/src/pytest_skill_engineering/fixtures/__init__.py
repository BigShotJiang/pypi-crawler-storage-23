"""Pytest fixtures for pytest-skill-engineering.

This module re-exports all fixtures for pytest plugin registration.
"""

# Re-export fixtures for pytest plugin discovery
from pytest_skill_engineering.fixtures.factories import skill_factory
from pytest_skill_engineering.fixtures.iteration import _aitest_iteration
from pytest_skill_engineering.fixtures.llm_assert import llm_assert
from pytest_skill_engineering.fixtures.llm_assert_image import llm_assert_image
from pytest_skill_engineering.fixtures.llm_score import llm_score
from pytest_skill_engineering.fixtures.run import _aitest_auto_cleanup, eval_run

__all__ = [
    "_aitest_auto_cleanup",
    "_aitest_iteration",
    "eval_run",
    "llm_assert",
    "llm_assert_image",
    "llm_score",
    "skill_factory",
]

# Conditionally register copilot fixtures when the SDK is available
try:
    from pytest_skill_engineering.copilot.fixtures import ab_run, copilot_eval  # noqa: F401

    __all__ += ["copilot_eval", "ab_run"]
except ImportError:
    pass  # github-copilot-sdk not installed — copilot fixtures not available
