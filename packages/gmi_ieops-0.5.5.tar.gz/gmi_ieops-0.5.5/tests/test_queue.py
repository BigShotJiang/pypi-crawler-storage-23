"""Unit tests for utils/queue.py"""

from gmi_ieops.utils.queue import Node, LinkQueue, CLOSE


class TestLinkQueue:

    def test_basic_operations(self):
        q = LinkQueue()
        assert q.empty() and len(q) == 0
        assert q.get() is None

        q.put("a"); q.put("b"); q.put("c")
        assert len(q) == 3
        assert q.get() == "a"
        assert q.get() == "b"
        assert q.get() == "c"
        assert q.empty()

    def test_close_sentinel(self):
        q = LinkQueue()
        q.put("data"); q.close()
        assert q.get() == "data"
        assert q.get() == CLOSE

    def test_reuse_after_drain(self):
        q = LinkQueue()
        q.put(1); q.get()
        q.put(2)
        assert q.get() == 2

    def test_many_items(self):
        q = LinkQueue()
        for i in range(1000): q.put(i)
        assert len(q) == 1000
        for i in range(1000): assert q.get() == i
        assert q.empty()

    def test_str_and_mixed_types(self):
        q = LinkQueue()
        q.put(42); q.put("hi"); q.put([1])
        assert "42" in str(q) and "hi" in str(q)
        assert q.get() == 42


class TestNode:

    def test_init_and_setters(self):
        n2 = Node("tail")
        n1 = Node("head", n2)
        assert n1.value == "head" and n1.next is n2
        n1.set_value(99); n1.set_next(None)
        assert n1.value == 99 and n1.next is None
