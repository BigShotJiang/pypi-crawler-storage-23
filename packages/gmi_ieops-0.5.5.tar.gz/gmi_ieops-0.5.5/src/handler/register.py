"""
Register Module - Service registration to IEOPS proxy

Handles service registration, heartbeat, and graceful unregistration.
"""

import os
import asyncio
from typing import Optional, List

from ..utils.util import randstr, APP_ID, get_socket_path
from ..utils.log import uvicorn_logger
from ..config import env
from .client import (
    Payload,
    async_post,
    _CONNECTORS,
    _SYNC_SESSION,
)
from .metrics import get_metrics
from .load import get_load_calculator
from .billing import get_billing_tracker

APP_STATUS_HEALTHY = "healthy"
APP_STATUS_UNHEALTHY = "unhealthy"

class Register:
    """Service registration manager for IEOPS proxy"""
    
    def __init__(self):
        self._socket_path = get_socket_path()
        self._tokens = [randstr(8) for _ in range(env.model.concurrency)]
        
    async def _app_info(self):
        """Build app info with dynamic load value.
        
        This is async because get_metrics().export() may perform blocking I/O
        (fetching metrics from external endpoint), which would block the event loop.
        """
        # Get metrics safely in thread pool to avoid blocking the event loop
        try:
            # export() may call urllib.request.urlopen() which is blocking
            metrics = await asyncio.to_thread(get_metrics().export)
        except Exception as e:
            uvicorn_logger.debug(f"Failed to get metrics: {e}")
            metrics = []
        
        # Get load safely (usually fast, but run in thread for safety)
        try:
            load = await asyncio.to_thread(get_load_calculator().calculate)
        except Exception as e:
            uvicorn_logger.debug(f"Failed to calculate load: {e}")
            load = 0
        
        # Flush incremental billing data (thread-safe, fast)
        try:
            usage_report = await asyncio.to_thread(get_billing_tracker().flush)
        except Exception as e:
            uvicorn_logger.debug(f"Failed to flush billing data: {e}")
            usage_report = []
        
        info = {
            "id": APP_ID,
            "server_socket": self._socket_path,
            "max_concurrent_reqs": env.model.concurrency,
            "endpoint": env.app.name,
            "type": env.app.atype,
            "load": load,
            "status": APP_STATUS_HEALTHY,
            "metrics": metrics,
            "provider": env.register.provider,
        }
        # Only include usage_report when there is data to report
        if usage_report:
            info["usage_report"] = usage_report
        return info

    async def _unregister_old(self):
        """Unregister old registrations on startup, clean up possible zombie registrations
        Clean by socket directory to avoid affecting services with same endpoint but different pods
        """
        socket_path = get_socket_path()
        socket_dir = os.path.dirname(socket_path) or os.getcwd()
        uvicorn_logger.info("Unregistering old models in socket_dir {} from IEOPS proxy (if exists)...".format(socket_dir))
        # Cancel old registrations in the same directory (same pod restart has same directory but different socket ID)
        await async_post(Payload(path="api/model/unregister", payload={"socket_dir": socket_dir}), max_retries=0)

    async def _unregister(self):
        """Unregister current registration on stop"""
        uvicorn_logger.info("Unregistering {} from IEOPS proxy...".format(env.app.name))
        await async_post(Payload(path="api/model/unregister", payload={"id": APP_ID}), max_retries=1)

    async def register(self):
        if not env.register.enabled:
            uvicorn_logger.info("Register is disabled, skipping...")
            return
        uvicorn_logger.info("Registering {} to IEOPS proxy...".format(env.app.name))
        try:
            # Clean old registrations on startup
            await self._unregister_old()
            while True:
                try:
                    # Get fresh app info with current load on each heartbeat
                    app_info = await self._app_info()
                    resp = await async_post(
                        Payload(path="api/model/register", payload=app_info), 
                        timeout=1.8,  # Increased timeout for stability
                        max_retries=1
                    )
                    # Log successful registration periodically (debug level to avoid spam)
                    if resp and resp.data:
                        uvicorn_logger.debug(f"Heartbeat sent successfully: {resp.data}")
                except Exception as e:
                    # Log error but continue the loop
                    uvicorn_logger.warning(f"Register heartbeat failed: {e}")
                
                await asyncio.sleep(env.register.interval)
        except asyncio.CancelledError:
            uvicorn_logger.info("Register stopped")
            raise
        except Exception as e:
            # Unexpected error - log and re-raise to trigger cleanup
            uvicorn_logger.error(f"Register loop crashed: {e}")
            raise
        finally:
            # Unregister on stop
            try:
                await self._unregister()
            except Exception as e:
                uvicorn_logger.warning(f"Failed to unregister: {e}")
            # Close all connectors
            await cleanup_connectors()


async def cleanup_connectors():
    """Clean up all HTTP connectors"""
    for connector in _CONNECTORS.values():
        if connector is not None:
            await connector.close()
    if _SYNC_SESSION is not None:
        _SYNC_SESSION.close()
