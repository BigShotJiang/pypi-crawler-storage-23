"""Collection of utility functions."""

# standard library
from typing import Literal, overload

# third party
import matplotlib.pyplot as plt

# local
from .constants import AU, STYLE_PATH
from .errors import AxesLabelFromInInvalidInputError, AxesLabelInvalidCallSignatureError

__all__ = (
    "apply_gypt_style",
    "axes_label",
    "axes_label_from_in",
    "tex",
)


def apply_gypt_style() -> None:
    """Apply the GYPT-stylesheet."""
    plt.style.use(STYLE_PATH)


@overload
def axes_label(name: str, *, unit: str) -> str: ...
@overload
def axes_label(name: str, *, is_au: Literal[True]) -> str: ...


def axes_label(name: str, *, unit: str | None = None, is_au: bool = False) -> str:
    """
    Generate a label for an axes.

    Parameters
    ----------
    name : str
        The name of the variable/parameter.
    unit : str, optional
        The unit's name of the variable/parameter.
    is_au : bool
        Whether the unit of the variable/parameter is in arbitrary units.

    Returns
    -------
    str
        A formatted label containing the variable/parameter and unit for an axes.

    Raises
    ------
    AxesLabelInvalidCallSignatureError
        Is raised whenever an invalid call-signature is used (specifying both unit and is_au or neither).
    """
    if (unit is None and is_au is False) or (isinstance(unit, str) and is_au is True):
        raise AxesLabelInvalidCallSignatureError(unit=unit, is_au=is_au)

    if is_au:
        unit = AU
    return f"{tex(name)} in {tex(unit)}"  # ty:ignore[invalid-argument-type]


def axes_label_from_in(in_string: str, /) -> str:
    """
    Genrates a label for an axes based on a "X in Y"-string.

    Parameters
    ----------
    in_string : str
        The "X in Y"-string.

    Returns
    -------
    str
        A formatted label containing the variable/parameter and unit for an axes.

    Raises
    ------
    AxesLabelFromInInvalidInputError
        Is raised whenever there are more or less than one occurrence of " in " present.
    """
    seperator = " in "
    if (cnt := in_string.count(seperator)) != 1:
        raise AxesLabelFromInInvalidInputError(in_string=in_string, seperator=seperator, count=cnt)
    name, unit = in_string.split(seperator)
    return axes_label(name=name, unit=unit)


def tex(tex_string: str, /) -> str:
    r"""Wrap the given text to be rendered as \TeX."""
    return f"${tex_string}$"
