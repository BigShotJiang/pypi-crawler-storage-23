"""Brand strategy service — persistence, baseline tracking, and progress.

Stores brand analysis results, strategy plans, and action completion logs
using the existing settings key-value store.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from ..db.queries import get_setting, save_setting

logger = logging.getLogger(__name__)

# ── Settings keys ──

_KEY_ANALYSIS = "brand_analysis"
_KEY_PLAN = "brand_strategy"
_KEY_BASELINE = "brand_baseline"
_KEY_ACTIONS_LOG = "brand_actions_completed"


# ──────────────────────────────────────────────
# Analysis persistence
# ──────────────────────────────────────────────


def save_brand_analysis(analysis: dict[str, Any]) -> None:
    analysis["analyzed_at"] = int(time.time())
    save_setting(_KEY_ANALYSIS, analysis)


def load_brand_analysis() -> dict[str, Any] | None:
    return get_setting(_KEY_ANALYSIS)


# ──────────────────────────────────────────────
# Plan persistence
# ──────────────────────────────────────────────


def save_brand_plan(plan: dict[str, Any]) -> None:
    plan["created_at"] = int(time.time())
    save_setting(_KEY_PLAN, plan)


def load_brand_plan() -> dict[str, Any] | None:
    return get_setting(_KEY_PLAN)


# ──────────────────────────────────────────────
# Baseline
# ──────────────────────────────────────────────


def capture_baseline(
    profile: dict[str, Any],
    ssi_data: dict[str, Any],
    health_total: int,
    acceptance_rate: float,
) -> dict[str, Any]:
    return {
        "captured_at": int(time.time()),
        "ssi_score": ssi_data.get("score", 0),
        "ssi_pillars": ssi_data.get("pillars", []),
        "acceptance_rate": acceptance_rate,
        "headline": profile.get("headline", ""),
        "summary_length": len(profile.get("summary", "")),
        "connections": profile.get("connections", 0),
        "health_score": health_total,
    }


def save_brand_baseline(baseline: dict[str, Any]) -> None:
    save_setting(_KEY_BASELINE, baseline)


def load_brand_baseline() -> dict[str, Any] | None:
    return get_setting(_KEY_BASELINE)


# ──────────────────────────────────────────────
# Action tracking
# ──────────────────────────────────────────────


def get_next_pending_action(plan: dict[str, Any]) -> dict[str, Any] | None:
    """Find the next uncompleted action in the plan (week order)."""
    for week in plan.get("weeks", []):
        for action in week.get("actions", []):
            if action.get("status") == "pending":
                return action
    return None


def mark_action_completed(action_id: str, result: str = "") -> None:
    """Mark a plan action as completed and log it."""
    plan = load_brand_plan()
    if not plan:
        return

    # Update action status in the plan
    for week in plan.get("weeks", []):
        for action in week.get("actions", []):
            if action.get("id") == action_id:
                action["status"] = "completed"
                action["completed_at"] = int(time.time())
                break

    save_setting(_KEY_PLAN, plan)

    # Append to completed actions log
    log: list[dict] = get_setting(_KEY_ACTIONS_LOG, [])
    if not isinstance(log, list):
        log = []
    log.append({
        "action_id": action_id,
        "completed_at": int(time.time()),
        "result": result,
    })
    save_setting(_KEY_ACTIONS_LOG, log)


def count_plan_progress(plan: dict[str, Any]) -> tuple[int, int]:
    """Return (completed, total) action counts."""
    total = 0
    completed = 0
    for week in plan.get("weeks", []):
        for action in week.get("actions", []):
            total += 1
            if action.get("status") == "completed":
                completed += 1
    return completed, total


def compute_progress(
    baseline: dict[str, Any],
    current_ssi: dict[str, Any],
    current_acceptance: float,
    current_health: int,
    plan: dict[str, Any],
) -> dict[str, Any]:
    """Compare baseline to current metrics, count completed actions."""
    completed, total = count_plan_progress(plan)

    return {
        "ssi_before": baseline.get("ssi_score", 0),
        "ssi_now": current_ssi.get("score", 0),
        "ssi_change": current_ssi.get("score", 0) - baseline.get("ssi_score", 0),
        "acceptance_before": baseline.get("acceptance_rate", 0),
        "acceptance_now": current_acceptance,
        "acceptance_change": current_acceptance - baseline.get("acceptance_rate", 0),
        "health_before": baseline.get("health_score", 0),
        "health_now": current_health,
        "health_change": current_health - baseline.get("health_score", 0),
        "actions_completed": completed,
        "actions_total": total,
        "actions_remaining": total - completed,
        "days_since_start": (int(time.time()) - baseline.get("captured_at", int(time.time()))) // 86400,
    }
