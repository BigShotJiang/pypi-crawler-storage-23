
Django async tasks queue app.

### Installation

Install with pip:

```
pip install django-mp-async-tasks
```

Settings:
```
INSTALLED_APPS = [
    ...,
    'async_tasks'
]
```

Urls:
```
urlpatterns = [
    ...,
    path('async_tasks/', include('async_tasks.urls')),
]
```


Static files:
Add `async_tasks/static/js/AsyncTasksModal.js` to js files collection.
