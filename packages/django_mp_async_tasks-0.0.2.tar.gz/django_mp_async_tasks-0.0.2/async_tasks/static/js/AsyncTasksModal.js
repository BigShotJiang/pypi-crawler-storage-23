AsyncTasksModal = class {
    constructor({url}) {
        this._url = url;
        this._$modal = $("<div />");
        this._$modal.css({
            position: "absolute",
            top: window.innerHeight - 200,
            left: 10,
            width: 300,
            padding: 0,
            "max-height": 400,
            overflow: "auto"
        });
        this._$modal.draggable();
        $("body").append(this._$modal);
        setInterval(() => this._loadTasks(), 5000);
        this._loadTasks();
    }

    _loadTasks() {
        $.get(this._url, (response) => {
            if (!response) {
                this._$modal.hide();
                return;
            }
            this._$modal.html(response);
            this._$modal.show();
        })
    }
}
