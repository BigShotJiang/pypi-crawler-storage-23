from django.urls import path

from async_tasks import views

app_name = 'async-tasks'

urlpatterns = [

    path('active/', views.get_active_tasks, name='active'),

]
