from django import forms
from django.utils.translation import gettext_lazy as _
from multiupload.fields import MultiFileField


class AsyncTaskForm(forms.Form):
    files = MultiFileField(
        label=_("File"),
        min_num=1,
        max_num=200,
        max_file_size=1024 * 1024 * 500
    )
