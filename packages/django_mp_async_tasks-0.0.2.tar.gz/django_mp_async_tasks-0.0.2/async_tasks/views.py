from django.contrib.admin.views.decorators import staff_member_required
from django.http import HttpResponse
from django.shortcuts import render

from async_tasks.models import AsyncTask


@staff_member_required
def get_active_tasks(request):
    tasks = AsyncTask.objects.filter(status=AsyncTask.STATUS_PROCESSING)
    if not tasks:
        return HttpResponse("")
    return render(request, "async-tasks.html", {"tasks": tasks})
