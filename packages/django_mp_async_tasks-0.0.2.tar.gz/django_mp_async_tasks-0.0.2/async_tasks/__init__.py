from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class AsyncTasksAppConfig(AppConfig):
    name = 'async_tasks'
    verbose_name = _('Async tasks')


default_app_config = 'async_tasks.AsyncTasksAppConfig'
