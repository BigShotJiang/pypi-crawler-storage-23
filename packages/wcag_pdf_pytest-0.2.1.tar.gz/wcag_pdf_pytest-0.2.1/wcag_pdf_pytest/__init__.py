"""wcag_pdf_pytest: Pytest plugin and generated WCAG 2.1 criteria tests for PDFs."""

__all__ = ["plugin", "pdf_inspector"]
