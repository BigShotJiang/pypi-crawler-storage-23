import pytest

from wcag_pdf_pytest.pdf_inspector import SCResult, evaluate_sc

SC_NUM = "4.1.3"
SC_TITLE = "Status Messages"
SC_LEVEL = "AA"
SC_APPLICABILITY = "Depends"
SC_NOTES = "If the PDF uses scripted status messages, they must be programmatically determinable."


@pytest.mark.wcag21
@pytest.mark.AA
def test_sc_4_1_3_status_messages(wcag_pdf_paths, wcag_context):
    assert wcag_pdf_paths, "No --wcag-pdf provided."
    res = evaluate_sc(SC_NUM, SC_TITLE, SC_LEVEL, wcag_pdf_paths, SC_APPLICABILITY, SC_NOTES)
    assert isinstance(res, SCResult)
    assert res.passed, res.reason
