import pytest

from wcag_pdf_pytest.pdf_inspector import SCResult, evaluate_sc

SC_NUM = "1.2.5"
SC_TITLE = "Audio Description (Prerecorded)"
SC_LEVEL = "AA"
SC_APPLICABILITY = "Depends"
SC_NOTES = "Applies if the PDF embeds prerecorded video content."


@pytest.mark.wcag21
@pytest.mark.AA
def test_sc_1_2_5___(wcag_pdf_paths):
    """WCAG 2.1 SC 1.2.5: Audio Description (Prerecorded) (Level AA).
    This test uses a lightweight heuristic implementation:
      - 1.1.x: Passes if no images are present; if images exist, requires '/Alt' entries.
      - 1.2.x: Passes if no time-based media is present (N/A); otherwise fails.
    """
    assert wcag_pdf_paths, "No --wcag-pdf provided."
    res = evaluate_sc(SC_NUM, SC_TITLE, SC_LEVEL, wcag_pdf_paths, SC_APPLICABILITY, SC_NOTES)
    assert isinstance(res, SCResult)
    assert res.passed, res.reason
