# Projekt-Workflows

## Workflow: ClickUp-Projekt bei Deal-Beauftragung erstellen

**Trigger-Phrasen**: "Deal X beauftragen", "Projekt für Deal X erstellen", "ClickUp-Projekt für Deal X"

Wenn der User einen Pipedrive-Deal als "beauftragt" markieren oder ein ClickUp-Projekt dafür erstellen möchte, folge diesen Schritten:

### Schritt 1: Deal-Daten aus Pipedrive holen
- Nutze `get_deal` oder `search_deals` um Deal-Details abzurufen
- Benötigte Daten: **Org-Name**, **Deal-Titel**, **Deal-ID**, **Expected Close Date**, **Beschreibung/Notizen**
- Falls der Deal noch nicht auf "Beauftragt" steht → frage den User ob der Deal auf Stage "Beauftragt" (Stage ID `27`) gesetzt werden soll, dann `update_deal` mit `stage_id: 27`

### Schritt 2: ClickUp-Liste in 02_Upcoming erstellen
- Tool: `clickup_create_list_in_folder`
- **Folder ID**: `90157185312` (02_Upcoming im Space "Clients & Projects")
- **Listenname**: `[Block] {Organisation} - {Deal-Titel} ({Pipedrive Deal-ID})`
- **Content**: Zusammenfassung mit Deal-Infos und erwartetem Abschlussdatum
- **Listen-Status**: Nach Erstellung die Liste auf `status: "planned"` setzen via `clickup_update_list`

### Schritt 3: Template-Tasks erstellen
Erstelle in der neuen Liste alle folgenden Tasks. Nutze `clickup_create_task` für Parent-Tasks und `clickup_create_task` mit `parent`-Parameter für Subtasks.

**Ersetze in Event-Timeline-Subtasks**: `{Kundenname}` = Org-Name, `{Eventname}` = Deal-Titel

```
1. Projektinitiierung & Planung
   ├── Administrative Vorbereitungen
   └── Anforderungen und Timings finalisieren

2. Konzeption & Kreation
   ├── Kreation (Mockups und Design der User-Journey, Event-Template, etc.)
   ├── Feedback Design PM Review
   └── Feedback Design Client Review

3. Event-Timeline
   ├── [{Kundenname} - {Eventname}] – Eventdatum
   ├── [{Kundenname} - {Eventname}] – Datum Registrierung
   └── [{Kundenname} - {Eventname}] – Vor-Ort-Betreuung

4. Development
   ├── [DEV] Create Event-Template
   ├── [DEV] Create Custom Landingpage
   └── Testing & Abnahme (intern)

5. Live-Betrieb & Abstimmungen

6. Serviceleistungen

7. Nachbereitung & Abschluss
   └── Controlling & finale Abrechnung
```

Falls der Deal ein **due_date** hat, setze es als `due_date` auf dem Event-Timeline Parent-Task.

### Schritt 4: Bestätigung
- Zeige dem User den Link zur neuen ClickUp-Liste
- Zusammenfassung: Listenname, Anzahl erstellter Tasks, Deal-Status

### Referenz-IDs
| Element | ID |
|---|---|
| Space: Clients & Projects | `90154140029` |
| Folder: 02_Upcoming | `90157185312` |
| Pipedrive Stage "Beauftragt" | `27` |

---

## Hinweise für Pipedrive-Operationen

### Activity Types
Diese Pipedrive-Instance verwendet **Custom Activity Types**. Standard-Keys wie `call`, `meeting` etc. funktionieren NICHT.
- **Immer erst `list_activity_types` aufrufen**, um gültige `key_string`-Werte zu finden
- Den `key_string` (nicht den Namen) als `type`-Parameter in `create_activity` verwenden

### Filtern nach Mitarbeiter
Um Deals, Activities etc. nach einem bestimmten Team-Mitglied zu filtern:
1. `list_users` aufrufen → findet alle Mitarbeiter mit ihren IDs
2. Die `user_id` als `owner_id`-Parameter bei `list_deals`, `list_activities` etc. verwenden
