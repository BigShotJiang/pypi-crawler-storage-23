# Pipedrive Instructions for Claude

## Domain & Links
- **Domain**: `airlstgmbh.pipedrive.com`
- **Deal-Link**: `https://airlstgmbh.pipedrive.com/deal/{deal_id}`
- **Person-Link**: `https://airlstgmbh.pipedrive.com/person/{person_id}`
- Kein `/en` in URLs

---

## Aktive User (owner_id)

| Name | owner_id |
|---|---|
| Aljoscha Herter | 12814052 |
| Arnold Brunner | 23904106 |
| Bijan Kheiri | 24511152 |
| Jil Obermeier | 24604388 |
| Martin Prell | 12282810 |
| AirLST Guest Solutions | 21251115 |

---

## Pipelines

| ID | Name |
|---|---|
| 3 | AirLST 2026 |
| 4 | Partnership-Kampagne |
| 5 | Airport-Case |
| 6 | Immobilien-Makler Case |
| 7 | Fashion |
| 8 | Finance-Case |
| 9 | Firmenevent-Kampagne |
| 11 | Telekommunikation |
| 12 | Bijan's Pipeline |
| 13 | Josh Pipeline |
| 14 | AirLST 2024-2025 |

---

## Stages

### Pipeline 3 – AirLST 2026

| ID | Stage |
|---|---|
| 28 | ALT/Pausiert |
| 104 | Lost |
| 101 | Annahmen |
| 102 | Wiederkehrer |
| 24 | Neuanfragen (Unbearbeitet) |
| 25 | In Abstimmung |
| 30 | Grobkosten Versendet |
| 31 | Grobkosten inkl. OnSite |
| 26 | TROI Angebot verschickt |
| 27 | Beauftragt |

### Pipeline 4 – Partnership-Kampagne

| ID | Stage |
|---|---|
| 33 | Erstkontakt |
| 34 | Detailabstimmung |
| 38 | Vertrag versendet |
| 35 | Abgeschlossener Partner |
| 36 | Abgeschlossener Preferred Partner |
| 37 | DND |

### Pipeline 5 – Airport-Case

| ID | Stage |
|---|---|
| 40 | Erstansprache |
| 41 | In Kontakt |
| 42 | Demo geplant |
| 43 | Verhandlungen gestartet |
| 44 | Gewonnen |
| 45 | Verloren |

### Pipeline 6 – Immobilien-Makler Case

| ID | Stage |
|---|---|
| 46 | Erstkontakt |
| 47 | Im Austausch |
| 48 | Demo geplant |
| 49 | Angebot unterbreitet |
| 50 | Gewonnen |
| 51 | Verloren |

### Pipeline 7 – Fashion

| ID | Stage |
|---|---|
| 80 | Erstkontakt |
| 52 | OnHold |
| 53 | Im Austausch |
| 54 | Demo geplant |
| 72 | Angebot versendet |
| 55 | Abgeschlossen |
| 56 | Verloren |

### Pipeline 8 – Finance-Case

| ID | Stage |
|---|---|
| 57 | Erstkontakt |
| 58 | Im Austausch |
| 59 | Demo geplant |
| 79 | Angebot versendet |
| 60 | Beauftragt |
| 61 | Abgebrochen |

### Pipeline 9 – Firmenevent-Kampagne

| ID | Stage |
|---|---|
| 67 | Erstkontakt |
| 71 | OnHold |
| 81 | Im Austausch |
| 68 | Demo geplant |
| 69 | Beauftragt |
| 70 | Abgebrochen |

### Pipeline 11 – Telekommunikation

| ID | Stage |
|---|---|
| 82 | Erstkontakt |
| 83 | Im Austausch |
| 84 | Demo geplant |
| 85 | Angebot unterbreitet |
| 86 | Abgeschlossen |
| 87 | Abgebrochen |

### Pipeline 12 – Bijan's Pipeline

| ID | Stage |
|---|---|
| 93 | Open |
| 103 | BOE |
| 96 | Kein Interesse |
| 95 | Lizenz Renewal |
| 89 | Kontakt hergestellt |

### Pipeline 13 – Josh Pipeline

| ID | Stage |
|---|---|
| 97 | Erstkontakt |
| 98 | Detailaustausch |
| 99 | DND |
| 100 | Wiedervorlage |

### Pipeline 14 – AirLST 2024-2025

| ID | Stage |
|---|---|
| 107 | Alt/Pausiert |
| 105 | Verloren |
| 106 | Gewonnen & Abgerechnet |

---

## Verhaltensregeln für Claude

### Bestätigungen
- Bei allen Ja/Nein-Fragen immer `ask_user_input_v0` mit exakt zwei Optionen verwenden: `✅ Ja` und `❌ Nein`
- Vor jedem Create/Update/Delete eine Zusammenfassung zeigen und Freigabe einholen

### Aktivitätsübersichten
- Immer Deal-Name + klickbare Pipedrive-Links anzeigen (kein extra `get_person` oder `get_deal` Call)
- Format: `[🔖 Deal-Name](https://airlstgmbh.pipedrive.com/deal/{id})` · `[👤 Person-Name](https://airlstgmbh.pipedrive.com/person/{id})`

### Zeitzonen
- Pipedrive API arbeitet mit **UTC**
- Berlin = **UTC+1** (Winter) / **UTC+2** (Sommer)
- Immer 1h (Winter) bzw. 2h (Sommer) von der Berliner Zeit abziehen
- Beispiel: User sagt "11:00 Uhr" → API bekommt `"10:00"`

### Activity Types
- Diese Instanz verwendet **Custom Activity Types** – Standard-Keys können inaktiv sein
- Immer erst `list_activity_types` aufrufen um gültige `key_string`-Werte zu prüfen
- Aktive Types: `task`, `nachfassen1`, `angebot_erstellen1`, `linkedin_conversation`, `linkedin_conversation1`

### Organisations- & Personensuche
- Vor dem Erstellen eines Deals immer `search_organizations` aufrufen um bestehende Org-ID zu finden
- Owner-IDs sind bekannt – kein `list_users` Call nötig

### Notizen
- Notizen auf Deals via `create_note` mit `deal_id` anlegen
- Wichtige Notizen mit `pinned_to_deal_flag: true` anpinnen
- Vor dem Erstellen eines ClickUp-Projekts immer `list_notes` aufrufen und Inhalte im Pipedrive-Info-Task hinterlegen

### Activities
- Activity als erledigt markieren: `update_activity` mit `done: true`
- Activity updaten (Zeit, Beschreibung etc.): `update_activity` mit den gewünschten Feldern
- Uhrzeit immer als UTC übergeben (Berliner Zeit -1h im Winter, -2h im Sommer)

### Kontakte anlegen & verknüpfen
- Neuen Kontakt via `create_person` anlegen – immer `org_id` mitgeben um direkt mit Organisation zu verknüpfen
- Kontakt mit Deal verknüpfen: `update_deal` mit `person_id`
- Vor dem Anlegen eines neuen Kontakts immer `search_persons` aufrufen um Duplikate zu vermeiden

### Lead anlegen & konvertieren
- Lead anlegen via `create_lead` mit `title`, `owner_id`, `person_id`, `organization_id`, `value_amount`, `value_currency`
- Lead zu Deal konvertieren via `convert_lead_to_deal` mit `lead_id`, `pipeline_id`, `stage_id`
- **Standard-Pipeline für Konvertierung**: AirLST 2026 (Pipeline 3)
- **Standard-Stage**: immer kurz nachfragen – entweder Neuanfragen (24) oder In Abstimmung (25)

### Workflow: Deal auf "Gewonnen" setzen
- Nach dem Setzen auf `status: "won"` immer fragen ob der ClickUp-Projekt-Workflow ausgelöst werden soll
- Siehe `clickup_creation.md` für den vollständigen Workflow

### Workflow: Deal beauftragen + ClickUp-Projekt erstellen
Siehe `clickup_creation.md` für den vollständigen Workflow.
