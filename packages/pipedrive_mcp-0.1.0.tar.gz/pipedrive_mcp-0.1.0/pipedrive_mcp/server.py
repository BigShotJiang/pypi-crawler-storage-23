"""
Pipedrive MCP Server
====================
Connects Claude Desktop to Pipedrive so salespeople can manage
deals, contacts, persons and organizations via natural language.

Setup:
  1. pip3 install mcp requests
  2. Add to Claude Desktop config (see README_MCP.md)
  3. Set PIPEDRIVE_API_KEY in your environment
"""

import os
import json
import asyncio
from typing import Any

import mcp.server.stdio
import mcp.types as types
from mcp.server import Server

# Import our connector
from .pipedrive import Pipedrive, PipedriveError

# ---------------------------------------------------------------------------
# Init
# ---------------------------------------------------------------------------

server = Server("pipedrive")
pd: Pipedrive | None = None


def _init_client() -> Pipedrive:
    global pd
    if pd is None:
        api_key = os.environ.get("PIPEDRIVE_API_KEY", "")
        if not api_key:
            raise RuntimeError("PIPEDRIVE_API_KEY environment variable is not set.")
        pd = Pipedrive(api_key=api_key)
    return pd

# ---------------------------------------------------------------------------
# Tool definitions (what Claude sees)
# ---------------------------------------------------------------------------

@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [

        # ── DEALS ────────────────────────────────────────────────────────
        types.Tool(
            name="list_deals",
            description=(
                "List deals from Pipedrive. Use this to get an overview of deals, "
                "find specific deals, or generate summaries. Can filter by status "
                "(open/won/lost), pipeline, stage, owner, person, or organization."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "status": {
                        "type": "string",
                        "enum": ["open", "won", "lost", "deleted"],
                        "description": "Filter by deal status"
                    },
                    "pipeline_id": {"type": "integer", "description": "Filter by pipeline ID"},
                    "stage_id": {"type": "integer", "description": "Filter by stage ID"},
                    "owner_id": {"type": "integer", "description": "Filter by owner user ID"},
                    "person_id": {"type": "integer", "description": "Filter by linked person ID"},
                    "org_id": {"type": "integer", "description": "Filter by linked organization ID"},
                    "updated_since": {"type": "string", "description": "RFC3339 date, e.g. 2025-01-01T00:00:00Z"},
                    "limit": {"type": "integer", "description": "Max results (default 50)", "default": 50}
                }
            }
        ),

        types.Tool(
            name="get_deal",
            description="Get full details of a single deal by its ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "deal_id": {"type": "integer", "description": "The deal ID"}
                },
                "required": ["deal_id"]
            }
        ),

        types.Tool(
            name="search_deals",
            description=(
                "Search for deals by keyword. Use this when the salesperson mentions "
                "a company name, deal name, or partial term to look up."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "term": {"type": "string", "description": "Search term"},
                    "status": {"type": "string", "enum": ["open", "won", "lost"], "description": "Optional status filter"},
                    "limit": {"type": "integer", "default": 20}
                },
                "required": ["term"]
            }
        ),

        types.Tool(
            name="create_deal",
            description=(
                "Create a new deal in Pipedrive. Use when a salesperson wants to add "
                "a new opportunity or sale.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a clear summary of the deal "
                "to be created (title, value, pipeline, linked contacts) and wait for explicit "
                "user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "title": {"type": "string", "description": "Deal title (required)"},
                    "value": {"type": "number", "description": "Deal value"},
                    "currency": {"type": "string", "description": "Currency code e.g. EUR, USD"},
                    "status": {"type": "string", "enum": ["open", "won", "lost"], "description": "Deal status"},
                    "stage_id": {"type": "integer", "description": "Pipeline stage ID"},
                    "pipeline_id": {"type": "integer", "description": "Pipeline ID"},
                    "person_id": {"type": "integer", "description": "ID of linked contact/person"},
                    "org_id": {"type": "integer", "description": "ID of linked organization"},
                    "expected_close_date": {"type": "string", "description": "Expected close date YYYY-MM-DD"},
                    "probability": {"type": "number", "description": "Win probability 0-100"},
                    "lost_reason": {"type": "string", "description": "Reason for losing (only if status=lost)"},
                    "owner_id": {"type": "integer", "description": "User ID of the deal owner. Use list_users to find user IDs."},
                    "custom_fields": {"type": "object", "description": "Dict of custom field hash keys to values, e.g. {\"f691421d...\": \"2027-08-10\"}"}
                },
                "required": ["title"]
            }
        ),

        types.Tool(
            name="update_deal",
            description=(
                "Update an existing deal. Use to change status, value, stage, title, "
                "probability, or any other field. Requires the deal ID.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a clear summary of the "
                "changes (current vs. new values) and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "deal_id": {"type": "integer", "description": "The deal ID to update"},
                    "title": {"type": "string"},
                    "value": {"type": "number"},
                    "currency": {"type": "string"},
                    "status": {"type": "string", "enum": ["open", "won", "lost"]},
                    "stage_id": {"type": "integer"},
                    "pipeline_id": {"type": "integer"},
                    "person_id": {"type": "integer"},
                    "org_id": {"type": "integer"},
                    "expected_close_date": {"type": "string"},
                    "probability": {"type": "number"},
                    "lost_reason": {"type": "string"},
                    "custom_fields": {"type": "object", "description": "Dict of custom field hash keys to values, e.g. {\"f691421d...\": \"2027-08-10\"}"},
                    "owner_id": {"type": "integer", "description": "User ID of the deal owner. Use list_users to find user IDs."}
                },
                "required": ["deal_id"]
            }
        ),

        types.Tool(
            name="delete_deal",
            description=(
                "Delete (soft-delete) a deal by ID. Recoverable within 30 days.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, show the deal name/ID that will be "
                "deleted and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "deal_id": {"type": "integer", "description": "The deal ID to delete"}
                },
                "required": ["deal_id"]
            }
        ),

        # ── PERSONS ──────────────────────────────────────────────────────
        types.Tool(
            name="list_persons",
            description="List contacts/persons from Pipedrive. Can filter by organization or owner.",
            inputSchema={
                "type": "object",
                "properties": {
                    "org_id": {"type": "integer", "description": "Filter by organization ID"},
                    "owner_id": {"type": "integer", "description": "Filter by owner user ID"},
                    "limit": {"type": "integer", "default": 50}
                }
            }
        ),

        types.Tool(
            name="get_person",
            description="Get full details of a single contact/person by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "person_id": {"type": "integer", "description": "The person ID"}
                },
                "required": ["person_id"]
            }
        ),

        types.Tool(
            name="search_persons",
            description="Search for contacts/persons by name, email, phone, or keyword. Use exact_match=true to find exact duplicates before creating new persons.",
            inputSchema={
                "type": "object",
                "properties": {
                    "term": {"type": "string", "description": "Name, email, phone, or keyword to search"},
                    "fields": {"type": "string", "description": "Comma-separated fields to search: name, email, phone, notes, custom_fields. Defaults to all."},
                    "exact_match": {"type": "boolean", "description": "When true, only exact matches are returned (case-insensitive). Useful for duplicate detection."},
                    "org_id": {"type": "integer", "description": "Limit search to an organization"},
                    "limit": {"type": "integer", "default": 20}
                },
                "required": ["term"]
            }
        ),

        types.Tool(
            name="create_person",
            description=(
                "Create a new contact/person in Pipedrive.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a clear summary of the person "
                "to be created (name, email, phone, organization) and wait for explicit user "
                "confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Full name (required)"},
                    "org_id": {"type": "integer", "description": "Link to an organization"},
                    "email": {"type": "string", "description": "Primary email address"},
                    "phone": {"type": "string", "description": "Primary phone number"},
                    "owner_id": {"type": "integer"}
                },
                "required": ["name"]
            }
        ),

        types.Tool(
            name="update_person",
            description=(
                "Update an existing contact/person.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a clear summary of the "
                "changes (current vs. new values) and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "person_id": {"type": "integer", "description": "The person ID to update"},
                    "name": {"type": "string"},
                    "org_id": {"type": "integer"},
                    "email": {"type": "string"},
                    "phone": {"type": "string"},
                    "owner_id": {"type": "integer"}
                },
                "required": ["person_id"]
            }
        ),

        types.Tool(
            name="delete_person",
            description=(
                "Delete a contact/person by ID.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, show the person name/ID that will be "
                "deleted and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "person_id": {"type": "integer"}
                },
                "required": ["person_id"]
            }
        ),

        # ── ORGANIZATIONS ────────────────────────────────────────────────
        types.Tool(
            name="list_organizations",
            description="List companies/organizations from Pipedrive.",
            inputSchema={
                "type": "object",
                "properties": {
                    "owner_id": {"type": "integer"},
                    "limit": {"type": "integer", "default": 50}
                }
            }
        ),

        types.Tool(
            name="get_organization",
            description="Get full details of a single organization by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "org_id": {"type": "integer", "description": "The organization ID"}
                },
                "required": ["org_id"]
            }
        ),

        types.Tool(
            name="search_organizations",
            description="Search for companies/organizations by name or keyword. Use exact_match=true to find exact duplicates before creating new organizations.",
            inputSchema={
                "type": "object",
                "properties": {
                    "term": {"type": "string", "description": "Company name or keyword"},
                    "fields": {"type": "string", "description": "Comma-separated fields to search: name, address, notes, custom_fields. Defaults to all."},
                    "exact_match": {"type": "boolean", "description": "When true, only exact matches are returned (case-insensitive). Useful for duplicate detection."},
                    "limit": {"type": "integer", "default": 20}
                },
                "required": ["term"]
            }
        ),

        types.Tool(
            name="create_organization",
            description=(
                "Create a new company/organization in Pipedrive.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a clear summary of the "
                "organization to be created (name, owner) and wait for explicit user confirmation "
                "in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Company name (required)"},
                    "owner_id": {"type": "integer"}
                },
                "required": ["name"]
            }
        ),

        types.Tool(
            name="update_organization",
            description=(
                "Update an existing company/organization.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a clear summary of the "
                "changes (current vs. new values) and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "org_id": {"type": "integer", "description": "The organization ID to update"},
                    "name": {"type": "string"},
                    "owner_id": {"type": "integer"}
                },
                "required": ["org_id"]
            }
        ),

        types.Tool(
            name="delete_organization",
            description=(
                "Delete an organization by ID.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, show the organization name/ID that "
                "will be deleted and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "org_id": {"type": "integer"}
                },
                "required": ["org_id"]
            }
        ),

        # ── ACTIVITIES ──────────────────────────────────────────────────
        types.Tool(
            name="list_activities",
            description=(
                "List activities (calls, meetings, tasks) from Pipedrive. "
                "Can filter by owner, deal, person, organization, done status, or type."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "owner_id": {"type": "integer", "description": "Filter by owner user ID"},
                    "deal_id": {"type": "integer", "description": "Filter by linked deal ID"},
                    "person_id": {"type": "integer", "description": "Filter by linked person ID"},
                    "org_id": {"type": "integer", "description": "Filter by linked organization ID"},
                    "done": {"type": "boolean", "description": "Filter by completion: true=done, false=to-do"},
                    "type": {"type": "string", "description": "Filter by type: call, meeting, task, deadline, email, lunch"},
                    "limit": {"type": "integer", "default": 50}
                }
            }
        ),

        types.Tool(
            name="get_activity",
            description="Get full details of a single activity by its ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "activity_id": {"type": "integer", "description": "The activity ID"}
                },
                "required": ["activity_id"]
            }
        ),

        types.Tool(
            name="create_activity",
            description=(
                "Create a new activity (call, meeting, task, etc.) in Pipedrive.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a clear summary of the "
                "activity to be created (subject, type, date/time, linked deal/person) and wait "
                "for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "subject": {"type": "string", "description": "Activity title/subject (required)"},
                    "type": {"type": "string", "description": "Activity type key_string. REQUIRED — use list_activity_types first to find valid keys."},
                    "owner_id": {"type": "integer", "description": "User ID to assign the activity to. Use list_users to find user IDs."},
                    "due_date": {"type": "string", "description": "Due date YYYY-MM-DD"},
                    "due_time": {"type": "string", "description": "Due time HH:MM"},
                    "duration": {"type": "string", "description": "Duration HH:MM"},
                    "deal_id": {"type": "integer", "description": "Link to a deal"},
                    "person_id": {"type": "integer", "description": "Link to a person/contact"},
                    "org_id": {"type": "integer", "description": "Link to an organization"},
                    "note": {"type": "string", "description": "Additional notes"},
                    "done": {"type": "boolean", "description": "Mark as done immediately"},
                    "location": {"type": "string", "description": "Location of the activity"}
                },
                "required": ["subject"]
            }
        ),

        types.Tool(
            name="update_activity",
            description=(
                "Update an existing activity. Requires the activity ID.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a clear summary of the "
                "changes (current vs. new values) and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "activity_id": {"type": "integer", "description": "The activity ID to update"},
                    "subject": {"type": "string"},
                    "type": {"type": "string"},
                    "due_date": {"type": "string"},
                    "due_time": {"type": "string"},
                    "duration": {"type": "string"},
                    "deal_id": {"type": "integer"},
                    "person_id": {"type": "integer"},
                    "org_id": {"type": "integer"},
                    "note": {"type": "string"},
                    "done": {"type": "boolean"},
                    "location": {"type": "string"}
                },
                "required": ["activity_id"]
            }
        ),

        types.Tool(
            name="delete_activity",
            description=(
                "Delete an activity by ID.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, show the activity subject/ID that "
                "will be deleted and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "activity_id": {"type": "integer", "description": "The activity ID to delete"}
                },
                "required": ["activity_id"]
            }
        ),

        # ── ACTIVITY TYPES ──────────────────────────────────────────────
        types.Tool(
            name="list_activity_types",
            description=(
                "List all available activity types in this Pipedrive instance. "
                "Use this BEFORE creating activities to find valid type key_strings. "
                "Returns id, name, key_string, and icon_key for each type."
            ),
            inputSchema={"type": "object", "properties": {}}
        ),

        # ── USERS (TEAM MEMBERS) ───────────────────────────────────────
        types.Tool(
            name="list_users",
            description=(
                "List all users (team members) in Pipedrive. Use this to find "
                "owner_id values for filtering deals, activities, etc. by team member."
            ),
            inputSchema={"type": "object", "properties": {}}
        ),

        types.Tool(
            name="get_user",
            description="Get details of a single Pipedrive user (team member) by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "user_id": {"type": "integer", "description": "The user ID"}
                },
                "required": ["user_id"]
            }
        ),

        # ── DEAL FIELDS ────────────────────────────────────────────────
        types.Tool(
            name="list_deal_fields",
            description=(
                "List all deal field definitions including custom fields. "
                "Returns field_name, field_code (hash key), field_type, and options for each field. "
                "Use this to identify custom field hash keys (e.g. for Eventdatum, Abrechnungsdatum)."
            ),
            inputSchema={"type": "object", "properties": {}}
        ),

        # ── NOTES ───────────────────────────────────────────────────────
        types.Tool(
            name="list_notes",
            description=(
                "List notes from Pipedrive. Can filter by linked deal, person, or organization."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "deal_id": {"type": "integer", "description": "Filter by linked deal ID"},
                    "person_id": {"type": "integer", "description": "Filter by linked person ID"},
                    "org_id": {"type": "integer", "description": "Filter by linked organization ID"},
                    "limit": {"type": "integer", "default": 50}
                }
            }
        ),

        types.Tool(
            name="get_note",
            description="Get full details of a single note by its ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "note_id": {"type": "integer", "description": "The note ID"}
                },
                "required": ["note_id"]
            }
        ),

        types.Tool(
            name="create_note",
            description=(
                "Create a note attached to a deal, person, or organization in Pipedrive.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a summary of the note "
                "(content preview, linked entity) and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "content": {"type": "string", "description": "Note content (supports HTML)"},
                    "deal_id": {"type": "integer", "description": "Link to a deal"},
                    "person_id": {"type": "integer", "description": "Link to a person"},
                    "org_id": {"type": "integer", "description": "Link to an organization"},
                    "pinned_to_deal_flag": {"type": "boolean", "description": "Pin note to deal"},
                    "pinned_to_person_flag": {"type": "boolean", "description": "Pin note to person"},
                    "pinned_to_organization_flag": {"type": "boolean", "description": "Pin note to organization"}
                },
                "required": ["content"]
            }
        ),

        types.Tool(
            name="update_note",
            description=(
                "Update an existing note.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a summary of the changes "
                "and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "note_id": {"type": "integer", "description": "The note ID to update"},
                    "content": {"type": "string", "description": "New note content"},
                    "deal_id": {"type": "integer"},
                    "person_id": {"type": "integer"},
                    "org_id": {"type": "integer"},
                    "pinned_to_deal_flag": {"type": "boolean"},
                    "pinned_to_person_flag": {"type": "boolean"},
                    "pinned_to_organization_flag": {"type": "boolean"}
                },
                "required": ["note_id"]
            }
        ),

        types.Tool(
            name="delete_note",
            description=(
                "Delete a note by ID.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, show the note ID and a content "
                "preview that will be deleted and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "note_id": {"type": "integer", "description": "The note ID to delete"}
                },
                "required": ["note_id"]
            }
        ),

        # ── PIPELINES & STAGES ──────────────────────────────────────────
        types.Tool(
            name="list_pipelines",
            description="List all sales pipelines in Pipedrive.",
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "default": 50}
                }
            }
        ),

        types.Tool(
            name="get_pipeline",
            description="Get details of a single pipeline by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "pipeline_id": {"type": "integer", "description": "The pipeline ID"}
                },
                "required": ["pipeline_id"]
            }
        ),

        types.Tool(
            name="list_stages",
            description="List all stages, optionally filtered by pipeline. Use to see available stages for deal movements.",
            inputSchema={
                "type": "object",
                "properties": {
                    "pipeline_id": {"type": "integer", "description": "Filter stages by pipeline ID"},
                    "limit": {"type": "integer", "default": 50}
                }
            }
        ),

        types.Tool(
            name="get_stage",
            description="Get details of a single stage by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "stage_id": {"type": "integer", "description": "The stage ID"}
                },
                "required": ["stage_id"]
            }
        ),

        # ── LEADS ───────────────────────────────────────────────────────
        types.Tool(
            name="list_leads",
            description="List leads from Pipedrive. Can filter by owner, person, or organization.",
            inputSchema={
                "type": "object",
                "properties": {
                    "owner_id": {"type": "integer", "description": "Filter by owner user ID"},
                    "person_id": {"type": "integer", "description": "Filter by linked person ID"},
                    "organization_id": {"type": "integer", "description": "Filter by linked organization ID"},
                    "limit": {"type": "integer", "default": 50}
                }
            }
        ),

        types.Tool(
            name="get_lead",
            description="Get full details of a single lead by its UUID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "lead_id": {"type": "string", "description": "The lead UUID"}
                },
                "required": ["lead_id"]
            }
        ),

        types.Tool(
            name="search_leads",
            description="Search for leads by keyword.",
            inputSchema={
                "type": "object",
                "properties": {
                    "term": {"type": "string", "description": "Search term"},
                    "limit": {"type": "integer", "default": 20}
                },
                "required": ["term"]
            }
        ),

        types.Tool(
            name="create_lead",
            description=(
                "Create a new lead in Pipedrive.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a clear summary of the "
                "lead to be created (title, value, linked person/org) and wait for explicit "
                "user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "title": {"type": "string", "description": "Lead title (required)"},
                    "person_id": {"type": "integer", "description": "Link to a person/contact"},
                    "organization_id": {"type": "integer", "description": "Link to an organization"},
                    "value_amount": {"type": "number", "description": "Monetary value amount"},
                    "value_currency": {"type": "string", "description": "Currency code e.g. EUR, USD"},
                    "expected_close_date": {"type": "string", "description": "Expected close date YYYY-MM-DD"},
                    "owner_id": {"type": "integer", "description": "Owner user ID"}
                },
                "required": ["title"]
            }
        ),

        types.Tool(
            name="update_lead",
            description=(
                "Update an existing lead. Requires the lead UUID.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a clear summary of the "
                "changes and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "lead_id": {"type": "string", "description": "The lead UUID to update"},
                    "title": {"type": "string"},
                    "owner_id": {"type": "integer"},
                    "person_id": {"type": "integer"},
                    "organization_id": {"type": "integer"},
                    "value_amount": {"type": "number"},
                    "value_currency": {"type": "string"},
                    "expected_close_date": {"type": "string"},
                    "is_archived": {"type": "boolean", "description": "Archive the lead"}
                },
                "required": ["lead_id"]
            }
        ),

        types.Tool(
            name="delete_lead",
            description=(
                "Delete a lead by UUID.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, show the lead title/UUID that "
                "will be deleted and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "lead_id": {"type": "string", "description": "The lead UUID to delete"}
                },
                "required": ["lead_id"]
            }
        ),

        types.Tool(
            name="convert_lead_to_deal",
            description=(
                "Convert a lead into a deal. The lead will be archived and a new deal created.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present the lead title, target "
                "pipeline/stage, and confirm with the user before converting."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "lead_id": {"type": "string", "description": "The lead UUID to convert"},
                    "pipeline_id": {"type": "integer", "description": "Target pipeline ID"},
                    "stage_id": {"type": "integer", "description": "Target stage ID"}
                },
                "required": ["lead_id"]
            }
        ),

        # ── PRODUCTS ────────────────────────────────────────────────────
        types.Tool(
            name="list_products",
            description="List all products/services in Pipedrive.",
            inputSchema={
                "type": "object",
                "properties": {
                    "owner_id": {"type": "integer", "description": "Filter by owner user ID"},
                    "limit": {"type": "integer", "default": 50}
                }
            }
        ),

        types.Tool(
            name="get_product",
            description="Get full details of a single product by ID.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "integer", "description": "The product ID"}
                },
                "required": ["product_id"]
            }
        ),

        types.Tool(
            name="search_products",
            description="Search for products by name or keyword.",
            inputSchema={
                "type": "object",
                "properties": {
                    "term": {"type": "string", "description": "Search term"},
                    "limit": {"type": "integer", "default": 20}
                },
                "required": ["term"]
            }
        ),

        types.Tool(
            name="create_product",
            description=(
                "Create a new product/service in Pipedrive.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a summary of the product "
                "(name, price, unit) and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Product name (required)"},
                    "code": {"type": "string", "description": "Product code/SKU"},
                    "description": {"type": "string", "description": "Product description"},
                    "unit": {"type": "string", "description": "Unit (e.g. piece, hour, license)"},
                    "tax": {"type": "number", "description": "Tax percentage"},
                    "price": {"type": "number", "description": "Default price"},
                    "currency": {"type": "string", "description": "Currency code e.g. EUR"},
                    "cost": {"type": "number", "description": "Cost price"},
                    "owner_id": {"type": "integer"}
                },
                "required": ["name"]
            }
        ),

        types.Tool(
            name="update_product",
            description=(
                "Update an existing product.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present the changes and wait "
                "for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "integer", "description": "The product ID to update"},
                    "name": {"type": "string"},
                    "code": {"type": "string"},
                    "description": {"type": "string"},
                    "unit": {"type": "string"},
                    "tax": {"type": "number"},
                    "price": {"type": "number"},
                    "currency": {"type": "string"},
                    "cost": {"type": "number"}
                },
                "required": ["product_id"]
            }
        ),

        types.Tool(
            name="delete_product",
            description=(
                "Delete a product by ID.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, show the product name/ID that "
                "will be deleted and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "integer", "description": "The product ID to delete"}
                },
                "required": ["product_id"]
            }
        ),

        # ── DEAL-PRODUCTS ───────────────────────────────────────────────
        types.Tool(
            name="list_deal_products",
            description="List all products attached to a specific deal.",
            inputSchema={
                "type": "object",
                "properties": {
                    "deal_id": {"type": "integer", "description": "The deal ID"},
                    "limit": {"type": "integer", "default": 50}
                },
                "required": ["deal_id"]
            }
        ),

        types.Tool(
            name="add_product_to_deal",
            description=(
                "Attach a product to a deal with price and quantity.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present a summary (product, "
                "deal, price, quantity) and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "deal_id": {"type": "integer", "description": "The deal ID"},
                    "product_id": {"type": "integer", "description": "The product ID to attach"},
                    "item_price": {"type": "number", "description": "Price per item"},
                    "quantity": {"type": "integer", "description": "Quantity (default 1)", "default": 1},
                    "discount": {"type": "number", "description": "Discount amount or percentage"},
                    "discount_type": {"type": "string", "enum": ["percentage", "amount"], "description": "Discount type"},
                    "tax": {"type": "number", "description": "Tax percentage"},
                    "comments": {"type": "string", "description": "Comments about this line item"}
                },
                "required": ["deal_id", "product_id", "item_price"]
            }
        ),

        types.Tool(
            name="update_deal_product",
            description=(
                "Update a product attachment on a deal (price, quantity, discount, etc.).\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present the changes and wait "
                "for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "deal_id": {"type": "integer", "description": "The deal ID"},
                    "product_attachment_id": {"type": "integer", "description": "The deal-product attachment ID"},
                    "item_price": {"type": "number"},
                    "quantity": {"type": "integer"},
                    "discount": {"type": "number"},
                    "discount_type": {"type": "string", "enum": ["percentage", "amount"]},
                    "tax": {"type": "number"},
                    "comments": {"type": "string"}
                },
                "required": ["deal_id", "product_attachment_id"]
            }
        ),

        types.Tool(
            name="remove_product_from_deal",
            description=(
                "Remove a product from a deal.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, show which product will be "
                "removed from which deal and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "deal_id": {"type": "integer", "description": "The deal ID"},
                    "product_attachment_id": {"type": "integer", "description": "The deal-product attachment ID to remove"}
                },
                "required": ["deal_id", "product_attachment_id"]
            }
        ),

        # ── DEAL PARTICIPANTS ───────────────────────────────────────────
        types.Tool(
            name="list_deal_participants",
            description="List all participant contacts on a deal.",
            inputSchema={
                "type": "object",
                "properties": {
                    "deal_id": {"type": "integer", "description": "The deal ID"},
                    "limit": {"type": "integer", "default": 50}
                },
                "required": ["deal_id"]
            }
        ),

        types.Tool(
            name="add_deal_participant",
            description=(
                "Add a person/contact as participant to a deal.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, present the person name and "
                "deal name and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "deal_id": {"type": "integer", "description": "The deal ID"},
                    "person_id": {"type": "integer", "description": "The person ID to add as participant"}
                },
                "required": ["deal_id", "person_id"]
            }
        ),

        types.Tool(
            name="remove_deal_participant",
            description=(
                "Remove a participant from a deal.\n\n"
                "⚠️ CONFIRMATION REQUIRED: Before executing, show which person will be "
                "removed from which deal and wait for explicit user confirmation in the chat."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "deal_id": {"type": "integer", "description": "The deal ID"},
                    "person_id": {"type": "integer", "description": "The person ID to remove"}
                },
                "required": ["deal_id", "person_id"]
            }
        ),

        # ── ITEM SEARCH (UNIVERSAL) ────────────────────────────────────
        types.Tool(
            name="item_search",
            description=(
                "Universal search across all Pipedrive entities (deals, leads, persons, "
                "organizations, products). Use when the user says 'find everything about X' "
                "or wants to search across multiple entity types at once."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "term": {"type": "string", "description": "Search term (min 2 characters)"},
                    "item_types": {"type": "string", "description": "Comma-separated types to search: deal,lead,person,organization,product"},
                    "fields": {"type": "string", "description": "Restrict search to specific fields"},
                    "exact_match": {"type": "boolean", "description": "Require exact match", "default": False},
                    "limit": {"type": "integer", "default": 20}
                },
                "required": ["term"]
            }
        ),
    ]


# ---------------------------------------------------------------------------
# Tool execution
# ---------------------------------------------------------------------------

@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    pd = _init_client()

    def ok(data: Any) -> list[types.TextContent]:
        return [types.TextContent(type="text", text=json.dumps(data, indent=2, default=str))]

    def err(e: Exception) -> list[types.TextContent]:
        return [types.TextContent(type="text", text=f"Error: {e}")]

    try:
        # ── DEALS ────────────────────────────────────────────────────────
        if name == "list_deals":
            limit = arguments.pop("limit", 50)
            results = list(pd.deals.list(**arguments, limit=limit))
            summary = [{"id": d["id"], "title": d["title"], "status": d.get("status"),
                        "value": d.get("value"), "currency": d.get("currency"),
                        "stage_id": d.get("stage_id"), "org_id": d.get("org_id"),
                        "person_id": d.get("person_id"), "update_time": d.get("update_time")}
                       for d in results]
            return ok({"count": len(summary), "deals": summary})

        elif name == "get_deal":
            return ok(pd.deals.get(arguments["deal_id"]))

        elif name == "search_deals":
            limit = arguments.pop("limit", 20)
            results = list(pd.deals.search(limit=limit, **arguments))
            items = []
            for r in results:
                item = r.get("item", r) if isinstance(r, dict) else r
                org = item.get("organization")
                person = item.get("person")
                items.append({
                    "id": item.get("id"),
                    "title": item.get("title"),
                    "status": item.get("status"),
                    "value": item.get("value"),
                    "currency": item.get("currency"),
                    "org_id": org.get("id") if isinstance(org, dict) else item.get("org_id"),
                    "org_name": org.get("name") if isinstance(org, dict) else None,
                    "person_id": person.get("id") if isinstance(person, dict) else item.get("person_id"),
                    "person_name": person.get("name") if isinstance(person, dict) else None,
                    "result_score": r.get("result_score"),
                })
            return ok({"count": len(items), "deals": items})

        elif name == "create_deal":
            # Handle email/phone convenience fields
            title = arguments.pop("title")
            return ok(pd.deals.create(title, **arguments))

        elif name == "update_deal":
            deal_id = arguments.pop("deal_id")
            return ok(pd.deals.update(deal_id, **arguments))

        elif name == "delete_deal":
            return ok(pd.deals.delete(arguments["deal_id"]))

        # ── PERSONS ──────────────────────────────────────────────────────
        elif name == "list_persons":
            limit = arguments.pop("limit", 50)
            results = list(pd.persons.list(**arguments, limit=limit))
            summary = [{"id": p["id"], "name": p["name"],
                        "emails": [e["value"] for e in (p.get("emails") or [])],
                        "phones": [ph["value"] for ph in (p.get("phones") or [])],
                        "org_id": p.get("org_id")}
                       for p in results]
            return ok({"count": len(summary), "persons": summary})

        elif name == "get_person":
            return ok(pd.persons.get(arguments["person_id"]))

        elif name == "search_persons":
            limit = arguments.pop("limit", 20)
            results = list(pd.persons.search(limit=limit, **arguments))
            items = []
            for r in results:
                item = r.get("item", r) if isinstance(r, dict) else r
                org = item.get("organization")
                items.append({
                    "id": item.get("id"),
                    "name": item.get("name"),
                    "primary_email": item.get("primary_email"),
                    "phones": item.get("phones"),
                    "org_id": org.get("id") if isinstance(org, dict) else item.get("org_id"),
                    "org_name": org.get("name") if isinstance(org, dict) else None,
                    "result_score": r.get("result_score"),
                })
            return ok({"count": len(items), "persons": items})

        elif name == "create_person":
            name_val = arguments.pop("name")
            email = arguments.pop("email", None)
            phone = arguments.pop("phone", None)
            emails = [{"value": email, "primary": True, "label": "work"}] if email else None
            phones = [{"value": phone, "primary": True}] if phone else None
            return ok(pd.persons.create(name_val, emails=emails, phones=phones, **arguments))

        elif name == "update_person":
            person_id = arguments.pop("person_id")
            email = arguments.pop("email", None)
            phone = arguments.pop("phone", None)
            if email:
                arguments["emails"] = [{"value": email, "primary": True, "label": "work"}]
            if phone:
                arguments["phones"] = [{"value": phone, "primary": True}]
            return ok(pd.persons.update(person_id, **arguments))

        elif name == "delete_person":
            return ok(pd.persons.delete(arguments["person_id"]))

        # ── ORGANIZATIONS ────────────────────────────────────────────────
        elif name == "list_organizations":
            limit = arguments.pop("limit", 50)
            results = list(pd.organizations.list(**arguments, limit=limit))
            summary = [{"id": o["id"], "name": o["name"],
                        "owner_id": o.get("owner_id"), "update_time": o.get("update_time")}
                       for o in results]
            return ok({"count": len(summary), "organizations": summary})

        elif name == "get_organization":
            return ok(pd.organizations.get(arguments["org_id"]))

        elif name == "search_organizations":
            limit = arguments.pop("limit", 20)
            results = list(pd.organizations.search(limit=limit, **arguments))
            items = []
            for r in results:
                item = r.get("item", r) if isinstance(r, dict) else r
                items.append({
                    "id": item.get("id"),
                    "name": item.get("name"),
                    "address": item.get("address"),
                    "owner_id": item.get("owner", {}).get("id") if isinstance(item.get("owner"), dict) else item.get("owner_id"),
                    "result_score": r.get("result_score"),
                })
            return ok({"count": len(items), "organizations": items})

        elif name == "create_organization":
            name_val = arguments.pop("name")
            return ok(pd.organizations.create(name_val, **arguments))

        elif name == "update_organization":
            org_id = arguments.pop("org_id")
            return ok(pd.organizations.update(org_id, **arguments))

        elif name == "delete_organization":
            return ok(pd.organizations.delete(arguments["org_id"]))

        # ── ACTIVITIES ────────────────────────────────────────────────────
        elif name == "list_activities":
            limit = arguments.pop("limit", 50)
            results = list(pd.activities.list(**arguments, limit=limit))
            summary = [{"id": a["id"], "subject": a.get("subject"), "type": a.get("type"),
                        "due_date": a.get("due_date"), "due_time": a.get("due_time"),
                        "done": a.get("done"), "deal_id": a.get("deal_id"),
                        "person_id": a.get("person_id"), "org_id": a.get("org_id")}
                       for a in results]
            return ok({"count": len(summary), "activities": summary})

        elif name == "get_activity":
            return ok(pd.activities.get(arguments["activity_id"]))

        elif name == "create_activity":
            subject = arguments.pop("subject")
            act_type = arguments.pop("type", None)
            if not act_type:
                return err("Activity type is required. Use list_activity_types to find valid key_strings.")
            return ok(pd.activities.create(subject, act_type, **arguments))

        elif name == "update_activity":
            activity_id = arguments.pop("activity_id")
            return ok(pd.activities.update(activity_id, **arguments))

        elif name == "delete_activity":
            return ok(pd.activities.delete(arguments["activity_id"]))

        # ── ACTIVITY TYPES ───────────────────────────────────────────────
        elif name == "list_activity_types":
            types_list = pd.activity_types.list()
            summary = [{"id": t["id"], "name": t["name"], "key_string": t["key_string"],
                        "icon_key": t.get("icon_key"), "active_flag": t.get("active_flag")}
                       for t in types_list]
            return ok({"count": len(summary), "activity_types": summary})

        # ── USERS (TEAM MEMBERS) ─────────────────────────────────────────
        elif name == "list_users":
            users = pd.users.list()
            summary = [{"id": u["id"], "name": u["name"], "email": u["email"],
                        "active_flag": u.get("active_flag")} for u in users]
            return ok({"count": len(summary), "users": summary})

        elif name == "get_user":
            return ok(pd.users.get(arguments["user_id"]))

        # ── DEAL FIELDS ──────────────────────────────────────────────────
        elif name == "list_deal_fields":
            fields = list(pd.deal_fields.list())
            summary = [{"field_name": f.get("field_name"),
                        "field_code": f.get("field_code"),
                        "field_type": f.get("field_type"),
                        "is_custom_field": f.get("is_custom_field"),
                        "options": f.get("options")}
                       for f in fields]
            return ok({"count": len(summary), "fields": summary})

        # ── NOTES ─────────────────────────────────────────────────────────
        elif name == "list_notes":
            limit = arguments.pop("limit", 50)
            results = list(pd.notes.list(**arguments, limit=limit))
            summary = [{"id": n["id"], "content": (n.get("content") or "")[:200],
                        "deal_id": n.get("deal_id"), "person_id": n.get("person_id"),
                        "org_id": n.get("org_id"), "update_time": n.get("update_time")}
                       for n in results]
            return ok({"count": len(summary), "notes": summary})

        elif name == "get_note":
            return ok(pd.notes.get(arguments["note_id"]))

        elif name == "create_note":
            content = arguments.pop("content")
            return ok(pd.notes.create(content, **arguments))

        elif name == "update_note":
            note_id = arguments.pop("note_id")
            return ok(pd.notes.update(note_id, **arguments))

        elif name == "delete_note":
            return ok(pd.notes.delete(arguments["note_id"]))

        # ── PIPELINES & STAGES ────────────────────────────────────────────
        elif name == "list_pipelines":
            limit = arguments.pop("limit", 50)
            results = list(pd.pipelines.list(limit=limit))
            summary = [{"id": p["id"], "name": p["name"],
                        "deal_default_visibility": p.get("deal_default_visibility"),
                        "active": p.get("active"), "update_time": p.get("update_time")}
                       for p in results]
            return ok({"count": len(summary), "pipelines": summary})

        elif name == "get_pipeline":
            return ok(pd.pipelines.get(arguments["pipeline_id"]))

        elif name == "list_stages":
            limit = arguments.pop("limit", 50)
            pipeline_id = arguments.get("pipeline_id")
            results = list(pd.stages.list(pipeline_id=pipeline_id, limit=limit))
            summary = [{"id": s["id"], "name": s["name"], "pipeline_id": s.get("pipeline_id"),
                        "order_nr": s.get("order_nr"), "deal_probability": s.get("deal_probability")}
                       for s in results]
            return ok({"count": len(summary), "stages": summary})

        elif name == "get_stage":
            return ok(pd.stages.get(arguments["stage_id"]))

        # ── LEADS ─────────────────────────────────────────────────────────
        elif name == "list_leads":
            limit = arguments.pop("limit", 50)
            results = list(pd.leads.list(**arguments, limit=limit))
            summary = [{"id": l["id"], "title": l.get("title"),
                        "owner_id": l.get("owner_id"),
                        "person_id": l.get("person_id"),
                        "organization_id": l.get("organization_id"),
                        "value": l.get("value"),
                        "expected_close_date": l.get("expected_close_date"),
                        "update_time": l.get("update_time")}
                       for l in results]
            return ok({"count": len(summary), "leads": summary})

        elif name == "get_lead":
            return ok(pd.leads.get(arguments["lead_id"]))

        elif name == "search_leads":
            limit = arguments.pop("limit", 20)
            results = list(pd.leads.search(limit=limit, **arguments))
            items = []
            for r in results:
                item = r.get("item", r) if isinstance(r, dict) else r
                org = item.get("organization")
                person = item.get("person")
                items.append({
                    "id": item.get("id"),
                    "title": item.get("title"),
                    "value": item.get("value"),
                    "org_id": org.get("id") if isinstance(org, dict) else item.get("organization_id"),
                    "org_name": org.get("name") if isinstance(org, dict) else None,
                    "person_id": person.get("id") if isinstance(person, dict) else item.get("person_id"),
                    "person_name": person.get("name") if isinstance(person, dict) else None,
                    "result_score": r.get("result_score"),
                })
            return ok({"count": len(items), "leads": items})

        elif name == "create_lead":
            title = arguments.pop("title")
            amount = arguments.pop("value_amount", None)
            currency = arguments.pop("value_currency", None)
            if amount is not None:
                arguments["value"] = {"amount": amount, "currency": currency or "EUR"}
            return ok(pd.leads.create(title, **arguments))

        elif name == "update_lead":
            lead_id = arguments.pop("lead_id")
            amount = arguments.pop("value_amount", None)
            currency = arguments.pop("value_currency", None)
            if amount is not None:
                arguments["value"] = {"amount": amount, "currency": currency or "EUR"}
            return ok(pd.leads.update(lead_id, **arguments))

        elif name == "delete_lead":
            return ok(pd.leads.delete(arguments["lead_id"]))

        elif name == "convert_lead_to_deal":
            lead_id = arguments.pop("lead_id")
            return ok(pd.leads.convert_to_deal(lead_id, **arguments))

        # ── PRODUCTS ──────────────────────────────────────────────────────
        elif name == "list_products":
            limit = arguments.pop("limit", 50)
            results = list(pd.products.list(**arguments, limit=limit))
            summary = [{"id": p["id"], "name": p.get("name"), "code": p.get("code"),
                        "unit": p.get("unit"), "tax": p.get("tax"),
                        "owner_id": p.get("owner_id"), "prices": p.get("prices")}
                       for p in results]
            return ok({"count": len(summary), "products": summary})

        elif name == "get_product":
            return ok(pd.products.get(arguments["product_id"]))

        elif name == "search_products":
            limit = arguments.pop("limit", 20)
            results = list(pd.products.search(limit=limit, **arguments))
            items = []
            for r in results:
                item = r.get("item", r) if isinstance(r, dict) else r
                items.append({
                    "id": item.get("id"),
                    "name": item.get("name"),
                    "code": item.get("code"),
                    "price": item.get("price"),
                    "unit": item.get("unit"),
                    "result_score": r.get("result_score"),
                })
            return ok({"count": len(items), "products": items})

        elif name == "create_product":
            name_val = arguments.pop("name")
            price = arguments.pop("price", None)
            currency = arguments.pop("currency", None)
            cost = arguments.pop("cost", None)
            if price is not None:
                arguments["prices"] = [{"price": price, "currency": currency or "EUR",
                                        "cost": cost or 0}]
            return ok(pd.products.create(name_val, **arguments))

        elif name == "update_product":
            product_id = arguments.pop("product_id")
            price = arguments.pop("price", None)
            currency = arguments.pop("currency", None)
            cost = arguments.pop("cost", None)
            if price is not None:
                arguments["prices"] = [{"price": price, "currency": currency or "EUR",
                                        "cost": cost or 0}]
            return ok(pd.products.update(product_id, **arguments))

        elif name == "delete_product":
            return ok(pd.products.delete(arguments["product_id"]))

        # ── DEAL-PRODUCTS ─────────────────────────────────────────────────
        elif name == "list_deal_products":
            deal_id = arguments.pop("deal_id")
            limit = arguments.pop("limit", 50)
            results = list(pd.deal_products.list(deal_id, limit=limit))
            summary = [{"id": dp.get("id"), "product_id": dp.get("product_id"),
                        "name": dp.get("name"), "item_price": dp.get("item_price"),
                        "quantity": dp.get("quantity"), "sum": dp.get("sum"),
                        "discount": dp.get("discount"), "tax": dp.get("tax")}
                       for dp in results]
            return ok({"count": len(summary), "deal_products": summary})

        elif name == "add_product_to_deal":
            deal_id = arguments.pop("deal_id")
            product_id = arguments.pop("product_id")
            item_price = arguments.pop("item_price")
            quantity = arguments.pop("quantity", 1)
            return ok(pd.deal_products.add(deal_id, product_id, item_price, quantity, **arguments))

        elif name == "update_deal_product":
            deal_id = arguments.pop("deal_id")
            product_attachment_id = arguments.pop("product_attachment_id")
            return ok(pd.deal_products.update(deal_id, product_attachment_id, **arguments))

        elif name == "remove_product_from_deal":
            return ok(pd.deal_products.remove(arguments["deal_id"], arguments["product_attachment_id"]))

        # ── DEAL PARTICIPANTS ─────────────────────────────────────────────
        elif name == "list_deal_participants":
            deal_id = arguments.pop("deal_id")
            limit = arguments.pop("limit", 50)
            results = list(pd.deal_participants.list(deal_id, limit=limit))
            summary = [{"deal_participant_id": p.get("id"),
                        "person_id": p.get("person", {}).get("id") if isinstance(p.get("person"), dict) else p.get("person_id"),
                        "name": p.get("person", {}).get("name") if isinstance(p.get("person"), dict) else None,
                        "email": p.get("person", {}).get("email") if isinstance(p.get("person"), dict) else None,
                        "active_flag": p.get("active_flag")}
                       for p in results]
            return ok({"count": len(summary), "participants": summary})

        elif name == "add_deal_participant":
            return ok(pd.deal_participants.add(arguments["deal_id"], arguments["person_id"]))

        elif name == "remove_deal_participant":
            deal_id = arguments["deal_id"]
            person_id = arguments["person_id"]
            # Look up the deal_participant_id from person_id
            participants = list(pd.deal_participants.list(deal_id, limit=200))
            participant_id = None
            for p in participants:
                pid = p.get("person", {}).get("id") if isinstance(p.get("person"), dict) else p.get("person_id")
                if pid == person_id:
                    participant_id = p.get("id")
                    break
            if not participant_id:
                return err(f"Person {person_id} is not a participant on deal {deal_id}.")
            return ok(pd.deal_participants.remove(deal_id, participant_id))

        # ── ITEM SEARCH ───────────────────────────────────────────────────
        elif name == "item_search":
            limit = arguments.pop("limit", 20)
            results = list(pd.item_search.search(limit=limit, **arguments))
            items = []
            for r in results:
                item = r.get("item", r) if isinstance(r, dict) else r
                items.append({
                    "id": item.get("id"),
                    "type": item.get("type"),
                    "title": item.get("title") or item.get("name"),
                    "status": item.get("status"),
                    "result_score": r.get("result_score"),
                })
            return ok({"count": len(items), "results": items})

        else:
            return err(f"Unknown tool: {name}")

    except PipedriveError as e:
        return err(e)
    except Exception as e:
        return err(e)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    """Entry point for the pipedrive-mcp console script."""
    asyncio.run(_run())


async def _run():
    _init_client()  # fail fast if no API key
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream,
                         server.create_initialization_options())


if __name__ == "__main__":
    main()
