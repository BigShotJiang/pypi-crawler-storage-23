"""Pipedrive MCP Server - connects Claude Desktop to Pipedrive CRM."""

__version__ = "0.1.0"
