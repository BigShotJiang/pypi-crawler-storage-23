# Pipedrive MCP Server

A Python-based MCP (Model Context Protocol) server that connects Claude to the Pipedrive CRM API. It runs locally via stdio and provides **57 tools** for managing the full Pipedrive data model through natural language.

## Installation

```bash
pip install pipedrive-mcp
```

Or run directly without installing (recommended for Claude Desktop):

```bash
uvx pipedrive-mcp
```

## Project Structure

```
pipedrive_mcp/
├── __init__.py    ← Package version
├── pipedrive.py   ← Pipedrive API Connector (11 resource classes)
└── server.py      ← MCP Server (57 tools)
```

---

## Available Tools

**57 tools** across 12 categories:

| Category | Tools | Operations |
|---|---|---|
| Deals | 7 | list, get, search, create, update, delete, list_deal_fields |
| Persons | 6 | list, get, search, create, update, delete |
| Organizations | 6 | list, get, search, create, update, delete |
| Activities | 6 | list, get, create, update, delete, list_activity_types |
| Notes | 5 | list, get, create, update, delete |
| Leads | 7 | list, get, search, create, update, delete, convert_to_deal |
| Pipelines & Stages | 4 | list_pipelines, get_pipeline, list_stages, get_stage |
| Products | 6 | list, get, search, create, update, delete |
| Deal Products | 4 | list, add, update, remove |
| Deal Participants | 3 | list, add, remove |
| Users / Team | 2 | list, get |
| Search | 1 | item_search (universal cross-entity search) |

### Key Features

- **Owner assignment**: `create_deal` and `update_deal` support `owner_id` to assign deals to team members
- **Custom fields**: `create_deal` supports `custom_fields` parameter for setting custom field values
- **Search with data extraction**: All search handlers extract structured data (id, name, org, score) from Pipedrive's nested response format
- **Activity owner support**: Activities use the v1 API to properly support `user_id` for owner assignment
- **Timezone handling**: API expects UTC times — see `pipedrive_instructions_for_claude.md` for conversion rules

---

## Setup

### Claude Desktop Configuration

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "pipedrive": {
      "command": "uvx",
      "args": ["pipedrive-mcp"],
      "env": {
        "PIPEDRIVE_API_KEY": "YOUR_PIPEDRIVE_API_TOKEN"
      }
    }
  }
}
```

After changing the config: fully quit Claude Desktop (Cmd+Q) and restart.

### Project Instructions

For best results, add `pipedrive_instructions_for_claude.md` to your Claude project instructions. This includes:
- User/owner ID mappings
- Pipeline & stage reference IDs
- Custom field hash keys
- Timezone conversion rules (CET/CEST → UTC)
- Activity type guidelines
- Behavioral rules for smoother operation

---

## Workflows

### ClickUp Project Creation on Deal Commission

Automatically creates a ClickUp project (list + template tasks) when a Pipedrive deal is commissioned.

**Trigger phrases**: "Commission deal X", "Create project for deal X"

**Steps**:
1. Fetch deal data from Pipedrive (org, title, ID, close date)
2. Set deal stage to "Beauftragt" (Stage 27)
3. Create ClickUp list in `02_Upcoming`: `[Block] {Org} - {Title} ({Deal-ID})`
4. Create 7 task groups + 12 subtasks from the client project template

See `clickup_creation.md` for full details.

---

## Troubleshooting

- **MCP not visible?** → Fully quit Claude Desktop (Cmd+Q) and restart
- **API errors?** → Check your API key in the config
- **Module not found?** → `pip install pipedrive-mcp`

---

## Planned Enhancements

- [ ] Webhook endpoint in MCP server for automatic triggers on Pipedrive stage changes
- [ ] Troi time tracking integration
- [x] PyPI package for one-line installation via `uvx pipedrive-mcp`
