import pandas as pd

# pandas options
pd.set_option("future.no_silent_downcasting", True)


__all__ = []
