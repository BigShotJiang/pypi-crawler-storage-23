"""
RVCE Report MCP Server
A standalone FastMCP server for generating RVCE-format project reports.
"""
