"""
Style utilities for RVCE Report MCP Server.
Handles applying FormatProfile styles to paragraphs and computing column widths.
"""
from __future__ import annotations

from typing import Optional
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from rvce_report_mcp.core import ParagraphStyleProfile

_ALIGN_ENUM = {
    "LEFT": WD_ALIGN_PARAGRAPH.LEFT,
    "CENTER": WD_ALIGN_PARAGRAPH.CENTER,
    "RIGHT": WD_ALIGN_PARAGRAPH.RIGHT,
    "JUSTIFY": WD_ALIGN_PARAGRAPH.JUSTIFY,
}


def apply_paragraph_format(para, profile: ParagraphStyleProfile) -> None:
    """
    Apply a ParagraphStyleProfile to a paragraph.
    Alignment is always set at paragraph level.
    Font properties are applied to all runs; if no runs exist, sets style-level font.
    """
    pf = para.paragraph_format
    if profile.alignment and profile.alignment in _ALIGN_ENUM:
        pf.alignment = _ALIGN_ENUM[profile.alignment]
    if profile.space_before_pt is not None:
        pf.space_before = Pt(profile.space_before_pt)
    if profile.space_after_pt is not None:
        pf.space_after = Pt(profile.space_after_pt)
    if profile.line_spacing is not None:
        from docx.enum.text import WD_LINE_SPACING
        pf.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
        pf.line_spacing = profile.line_spacing

    # Apply font to existing runs
    for run in para.runs:
        _apply_run_font(run, profile)

    # If no runs, set via paragraph style font (best effort)
    if not para.runs and para.style:
        try:
            if profile.font_name:
                para.style.font.name = profile.font_name
            if profile.font_size_pt:
                para.style.font.size = Pt(profile.font_size_pt)
        except Exception:
            pass


def _apply_run_font(run, profile: ParagraphStyleProfile) -> None:
    if profile.font_name:
        run.font.name = profile.font_name
    if profile.font_size_pt:
        run.font.size = Pt(profile.font_size_pt)
    if profile.bold is not None:
        run.font.bold = profile.bold
    if profile.italic is not None:
        run.font.italic = profile.italic


def apply_run_highlight_yellow(run) -> None:
    """Apply yellow highlight to a run via OxmlElement (w:highlight w:val='yellow')."""
    rPr = run._element.get_or_add_rPr()
    # Remove existing highlight if any
    for old in rPr.findall(qn("w:highlight")):
        rPr.remove(old)
    highlight = OxmlElement("w:highlight")
    highlight.set(qn("w:val"), "yellow")
    rPr.append(highlight)


def add_bottom_border_to_para(para, val: str = "single", sz: str = "4") -> None:
    """Add a bottom border to a paragraph. val/sz control style and weight."""
    pPr = para._element.get_or_add_pPr()
    for old in pPr.findall(qn("w:pBdr")):
        pPr.remove(old)
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), val)
    bottom.set(qn("w:sz"), sz)
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), "auto")
    pBdr.append(bottom)
    pPr.append(pBdr)


def add_top_border_to_para(para) -> None:
    """Add a single top border to a paragraph (used for footer rule)."""
    pPr = para._element.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    top = OxmlElement("w:top")
    top.set(qn("w:val"), "single")
    top.set(qn("w:sz"), "4")
    top.set(qn("w:space"), "1")
    top.set(qn("w:color"), "auto")
    pBdr.append(top)
    pPr.append(pBdr)


def set_keep_together(para) -> None:
    """Set keepLines on a paragraph so it never splits across pages."""
    pPr = para._element.get_or_add_pPr()
    kl = OxmlElement("w:keepLines")
    pPr.append(kl)
    kt = OxmlElement("w:keepNext")
    pPr.append(kt)


def insert_page_number_field(para, alignment: str = "CENTER") -> None:
    """Insert a real PAGE field into a paragraph using three separate runs (begin/instrText/end)."""
    if alignment in _ALIGN_ENUM:
        para.paragraph_format.alignment = _ALIGN_ENUM[alignment]

    # Run 1: fldChar begin
    run_begin = para.add_run()
    fldChar_begin = OxmlElement("w:fldChar")
    fldChar_begin.set(qn("w:fldCharType"), "begin")
    run_begin._r.append(fldChar_begin)

    # Run 2: instrText
    run_instr = para.add_run()
    instrText = OxmlElement("w:instrText")
    instrText.text = " PAGE "
    instrText.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    run_instr._r.append(instrText)

    # Run 3: fldChar end
    run_end = para.add_run()
    fldChar_end = OxmlElement("w:fldChar")
    fldChar_end.set(qn("w:fldCharType"), "end")
    run_end._r.append(fldChar_end)


def set_cell_shading(cell, fill_hex: str = "D9D9D9") -> None:
    """Apply fill shading to a table cell."""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill_hex)
    tcPr.append(shd)


def compute_column_widths(
    headers: list[str],
    rows: list[list[str]],
    usable_width_cm: float,
    col_widths_pct: Optional[list[float]] = None,
) -> list[float]:
    """
    Compute column widths in cm.

    If col_widths_pct is provided (must sum to 100), use those percentages directly.
    Otherwise, auto-size based on content:
      1. Natural width = max char length across header + all rows
      2. Proportional share of usable_width
      3. Min clamp 1.2cm / max clamp 50% of usable_width
      4. Header-aware minimum (0.22cm per char at 12pt TNR)
      5. Long-cell minimum: any cell > 200 chars → column min 35% usable_width
      6. Redistribute leftover from clamped columns
      7. Final normalisation: last column absorbs rounding
    """
    n_cols = len(headers)
    if n_cols == 0:
        return []

    # User-specified percentages
    if col_widths_pct:
        return [usable_width_cm * (p / 100.0) for p in col_widths_pct]

    # Natural content widths
    natural = []
    for col_idx in range(n_cols):
        max_len = len(headers[col_idx]) if col_idx < len(headers) else 1
        for row in rows:
            if col_idx < len(row):
                max_len = max(max_len, len(str(row[col_idx])))
        natural.append(max(max_len, 1))

    total_natural = sum(natural)
    min_cm = 1.2
    max_cm = usable_width_cm * 0.5
    char_width_cm = 0.22  # approx for 12pt TNR

    # Proportional starting widths
    widths = [usable_width_cm * (n / total_natural) for n in natural]

    # Long-cell override
    for col_idx in range(n_cols):
        for row in rows:
            if col_idx < len(row) and len(str(row[col_idx])) > 200:
                widths[col_idx] = max(widths[col_idx], usable_width_cm * 0.35)
                break

    # Header-aware minimum
    for col_idx in range(n_cols):
        header_min = len(headers[col_idx]) * char_width_cm if col_idx < len(headers) else 0
        widths[col_idx] = max(widths[col_idx], header_min)

    # Clamp min/max
    clamped_low = [False] * n_cols
    clamped_high = [False] * n_cols
    for i in range(n_cols):
        if widths[i] < min_cm:
            widths[i] = min_cm
            clamped_low[i] = True
        elif widths[i] > max_cm:
            widths[i] = max_cm
            clamped_high[i] = True

    # Normalise to usable_width
    total = sum(widths)
    if total > 0:
        factor = usable_width_cm / total
        widths = [w * factor for w in widths]

    # Final normalisation: last column absorbs rounding difference
    diff = usable_width_cm - sum(widths[:-1])
    widths[-1] = max(min_cm, diff)

    return widths
