"""
Report tools — generate_pretoc_pages, create_rvce_report, get_rvce_format_profile, inspect_report.
"""
from __future__ import annotations

import datetime
import json
import os
import re
import shutil
import tempfile
import zipfile

from rvce_report_mcp.core import get_default_profile
from rvce_report_mcp.core.format_extractor import extract_format_profile, profile_to_dict
from rvce_report_mcp.core.report_builder import build_full_report
from rvce_report_mcp.utils.validator import validate_project_context
from rvce_report_mcp.core.token_extractor import preprocess_xml

# Default pretoc template location (bundled with the package)
_DEFAULT_PRETOC_TEMPLATE = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "assets", "pre_toc_template.docx")
)


def merge_split_runs(xml: str) -> str:
    """
    Merge text content split across adjacent w:r runs that share identical rPr formatting.
    Targets the specific case where a token like [usn_1] is split as:
    <w:r><w:rPr>...</w:rPr><w:t>[usn_1</w:t></w:r><w:r><w:rPr>...</w:rPr><w:t>]</w:t></w:r>
    Strategy: find all w:t content, if concatenating adjacent w:t values produces a complete
    [token] pattern, merge those runs into one.
    """
    # Simpler targeted approach: collapse run boundaries inside [ ] spans
    # Find pattern: <w:t ...>...[...</w:t></w:r> followed by <w:r>...<w:t>...]...</w:t>
    # Replace with merged single run keeping first run's rPr
    pattern = re.compile(
        r'(<w:r>(?:<w:rPr>.*?</w:rPr>)?<w:t[^>]*>)([^\[<]*\[[^\]<]*)'
        r'(</w:t></w:r>)'
        r'(?:<w:r>(?:<w:rPr>.*?</w:rPr>)?<w:t[^>]*>)'
        r'([^\]<]*\][^<]*)'
        r'(</w:t></w:r>)',
        re.DOTALL,
    )

    def _merge(m):
        return f'{m.group(1)}{m.group(2)}{m.group(4)}{m.group(3)}'

    # Apply repeatedly until no more merges possible
    prev = None
    while prev != xml:
        prev = xml
        xml = pattern.sub(_merge, xml)
    return xml


async def inspect_pretoc_template(template_path: str = None) -> dict:
    """
    Check which [token] placeholders exist in the pre-TOC template.

    Call this FIRST before generate_pretoc_pages. If status is "error",
    the template file is missing from assets/ and the user must place
    pre_toc_template.docx there before proceeding.
    """
    from rvce_report_mcp.core.token_extractor import extract_tokens
    if template_path is None:
        template_path = os.path.join(
            os.path.dirname(__file__), '..', 'assets', 'pre_toc_template.docx'
        )
    template_path = os.path.abspath(template_path)
    if not os.path.exists(template_path):
        return {'status': 'error', 'error': f'Template not found: {template_path}'}
    tokens = extract_tokens(template_path)
    return {'status': 'ok', 'template_path': template_path, 'tokens': tokens}


async def generate_pretoc_pages(
    output_path: str,
    project_context,
    template_path: str = None,
) -> str:
    """
    Fill the pre-TOC template (cover, certificate, declaration pages)
    with project details and save as a separate docx file.

    Call ORDER: inspect_pretoc_template → generate_pretoc_pages → create_rvce_report

    Required project_context fields:
      project_title, sdg_theme, academic_year, faculty_mentor.name,
      faculty_mentor.designation, faculty_mentor.department,
      team (list of {name, usn, dept, email}, max 5 members)

    Output: output/report_pretoc.docx — pages 1-3 of the final report.
    Never modifies the template file.

    Args:
        output_path:     Path for the output .docx file (relative paths resolved from cwd).
        project_context: dict (or JSON string) with the required fields listed above.
        template_path:   Optional path to a custom pre-TOC .docx template.
                         Defaults to assets/pre_toc_template.docx.

    Returns:
        JSON string with {status, output_path, tokens_replaced, warnings, note}
        or {status: "error", error: "..."} on failure.
    """
    # Normalise output path (accept relative paths)
    output_path = os.path.abspath(output_path)

    # Parse project_context if string
    try:
        if isinstance(project_context, str):
            data = json.loads(project_context)
        else:
            data = dict(project_context)
    except Exception as e:
        return json.dumps({"status": "error", "error": f"Invalid project_context: {e}"})

    # Locate template
    tpl = os.path.abspath(template_path) if template_path else _DEFAULT_PRETOC_TEMPLATE
    if not os.path.exists(tpl):
        return json.dumps({
            "status": "error",
            "error": (
                f"Pre-TOC template not found at {tpl}. "
                "Place your template DOCX at rvce_report_mcp/assets/pre_toc_template.docx "
                "or pass template_path explicitly."
            ),
        })

    # Build token map
    team = data.get("team", [])
    mentor = data.get("faculty_mentor", {})
    academic_year = data.get("academic_year", "2025-26")
    parts = academic_year.split("-")
    long_year = (
        f"{parts[0]}-20{parts[1]}"
        if len(parts) == 2 and len(parts[1]) == 2
        else academic_year
    )

    def team_name(i): return team[i]["name"] if i < len(team) else ""
    def team_usn(i):  return team[i]["usn"]  if i < len(team) else ""

    token_map = {
        '[theme]':              data.get('sdg_theme', ''),
        '[project_title]':      data.get('project_title', ''),
        '[team_member_name_1]': team_name(0),
        '[team_member_name_2]': team_name(1),
        '[team_member_name_3]': team_name(2),
        '[team_member_name_4]': team_name(3),
        '[team_member_name_5]': team_name(4),
        '[usn_1]':              team_usn(0),
        '[usn_2]':              team_usn(1),
        '[usn_3]':              team_usn(2),
        '[usn_4]':              team_usn(3),
        '[usn_5]':              team_usn(4),
        '[mentor_name]':        mentor.get('name', ''),
        '[mentor_designation]': mentor.get('designation', ''),
        '[mentor_dept]':        mentor.get('department', ''),
        '[today\u2019s date]':  datetime.date.today().strftime('%d %B %Y'),
        '2025-2026':            long_year,
        '2025-26':              academic_year,
    }

    # Copy template, replace tokens in word/document.xml, repack
    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_docx = os.path.join(tmpdir, "working.docx")
            shutil.copy2(tpl, tmp_docx)

            with zipfile.ZipFile(tmp_docx, "r") as z:
                all_names = z.namelist()
                doc_xml = z.read("word/document.xml").decode("utf-8")
                doc_xml = preprocess_xml(doc_xml)

            doc_xml = merge_split_runs(doc_xml)

            replaced_count = 0
            for token, value in token_map.items():
                count = doc_xml.count(token)
                if count:
                    doc_xml = doc_xml.replace(token, value)
                    replaced_count += count

            # Warn on any unresolved [tokens] (ignore [pg] which are page-number placeholders)
            remaining = re.findall(r"\[[^\]]{3,80}\]", doc_xml)
            warnings = [
                f"Unresolved token: {t}"
                for t in sorted(set(remaining))
                if not t.startswith("[pg")
            ]

            os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
            with zipfile.ZipFile(tmp_docx, "r") as zin, \
                 zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zout:
                for item in zin.infolist():
                    if item.filename == "word/document.xml":
                        zout.writestr(item, doc_xml.encode("utf-8"))
                    else:
                        zout.writestr(item, zin.read(item.filename))

        return json.dumps({
            "status": "ok",
            "output_path": output_path,
            "tokens_replaced": replaced_count,
            "warnings": warnings,
            "note": (
                "Pre-TOC file covers pages 1–3 (cover, certificate, declaration). "
                "Print this file first, then report_main.docx. "
                "Page numbers are independent across both files by design."
            ),
        }, indent=2)

    except Exception as e:
        import traceback
        return json.dumps({
            "status": "error",
            "error": str(e),
            "traceback": traceback.format_exc(),
        })



    """
    Return the built-in RVCE formatting defaults as a JSON FormatProfile.

    No template file required. Use this to inspect what the server will
    produce when create_rvce_report is called without a template_path.

    Args:
        report_type: "el_report" (Experiential Learning — flat numbered headings,
                     H1 left-aligned) or "project_report" (VTU thesis — CHAPTER
                     prefix, H1 centered). Defaults to "el_report".

    Returns:
        JSON string with the full FormatProfile.
    """
    if report_type not in ("el_report", "project_report"):
        return json.dumps({"error": f"Unknown report_type '{report_type}'. "
                                    f"Use 'el_report' or 'project_report'."})
    try:
        profile = get_default_profile(report_type)
        return json.dumps(profile_to_dict(profile), indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


async def create_rvce_report(
    output_path: str,
    project_context: str,
    template_path: str = None,
) -> str:
    """
    Generate the main RVCE EL report (abstract through references) as a docx.

    Call ORDER: inspect_pretoc_template → generate_pretoc_pages → create_rvce_report

    HOW TO USE:
    1. User attaches project folder and pastes desired TOC structure
    2. Read project files (README, docs/, report/, src/) to extract content
    3. Build project_context JSON following the schema below
    4. Call this tool — it validates, builds, and returns figure/table labels
    5. Tell user to press Ctrl+A then F9 in Word to update page numbers

    PROJECT_CONTEXT SCHEMA:
    {
      "report_type": "el_report",
      "project_title": "string — required",
      "sdg_theme": "string — required, e.g. SDG 9 - Industry, Innovation and Infrastructure",
      "college_name": "RV College of Engineering",
      "academic_year": "string — required, e.g. 2025-26",
      "semester": "string — e.g. V",
      "faculty_mentor": {
        "name": "string — required",
        "designation": "string",
        "department": "string"
      },
      "abstract": "string — 150-250 words",
      "team": [
        {"name": "string", "usn": "string", "dept": "string", "email": "string"}
      ],
      "chapters": [
        {
          "number": 1,
          "title": "string",
          "sections": [
            {
              "heading": "1.1 string",
              "paragraphs": [
                {"type": "body", "text": "string — min 40 words"},
                {"type": "bullet_list", "items": ["string"]},
                {"type": "numbered_list", "items": ["string"]},
                {"type": "figure", "id": "fig_unique", "caption": "string", "source": "screenshot"},
                {"type": "table", "id": "tbl_unique", "caption": "string",
                 "headers": ["col1", "col2"], "rows": [["val", "val"]]}
              ]
            }
          ]
        }
      ],
      "appendix": {
        "title": "Visuals",
        "paragraphs": [
          {"type": "figure", "id": "fig_unique", "caption": "string", "source": "screenshot"}
        ]
      },
      "references": ["1. IEEE format reference string"]
    }

    PARAGRAPH RULES:
    - Map user's pasted TOC exactly — do not add or remove sections
    - Every section needs min 2 body paragraphs (min 40 words each)
    - First and last paragraph of each section must be type body
    - figure and table IDs must be unique across the entire document
    - Table column count must match across headers and all rows
    - Never invent metadata (names, USNs, emails) — extract from project files only
    - Ask user if faculty_mentor or team details are missing
    - Appendix figures = visual outputs not already used in chapters
    - References in IEEE format, numbered from 1

    OUTPUT: output/report_main.docx — abstract through references.
    Pages 1-2 are blank placeholders (certificate, declaration).
    Page 3 onwards is abstract, TOC, chapters.

    Args:
        output_path: Path for the output .docx file (relative paths resolved from cwd).
        project_context: JSON string matching the project_context schema above.
        template_path: Optional path to a sample RVCE DOCX for style extraction.

    Returns:
        JSON string with {status, output_path, warnings, figures, tables}
        or {status: "error", errors: [...]} on validation failure.
    """
    # Parse project_context
    try:
        if isinstance(project_context, str):
            data = json.loads(project_context)
        else:
            data = project_context
    except json.JSONDecodeError as e:
        return json.dumps({"status": "error", "errors": [f"Invalid JSON: {str(e)}"]})

    # Validate
    is_valid, errors, warnings = validate_project_context(data)
    if not is_valid:
        return json.dumps({"status": "error", "errors": errors, "warnings": warnings})

    # Resolve FormatProfile
    report_type = data.get("report_type", "el_report")
    try:
        if template_path and os.path.exists(template_path):
            profile = extract_format_profile(template_path, report_type)
        else:
            profile = get_default_profile(report_type)
    except Exception as e:
        return json.dumps({"status": "error", "errors": [f"Failed to load template: {str(e)}"]})

    # Apply institution branding from project_context (overrides template/default)
    if "institution_name" in data:
        profile.institution_name = data["institution_name"]
    if "academic_year" in data:
        profile.academic_year = data["academic_year"]
    # Keep three-part footer texts in sync with (possibly updated) profile fields
    if profile.footer.three_part:
        if not profile.footer.left_text or "institution_name" in data:
            profile.footer.left_text = profile.institution_name
        if not profile.footer.center_text or "academic_year" in data:
            profile.footer.center_text = profile.academic_year

    # Patch header text from el_topic / title (EL report header: "EL Topic: <name>")
    el_topic = data.get("el_topic") or data.get("title", "")
    if profile.header.paragraphs:
        for php in profile.header.paragraphs:
            if not php.text and el_topic:
                php.text = f"EL Topic: {el_topic}"

    # Populate bold keywords from project_context
    raw_keywords = data.get("bold_keywords", [])
    if not raw_keywords and el_topic:
        # Auto-add the EL topic name as a bold keyword
        raw_keywords = [el_topic]
    profile.bold_keywords = [str(k).strip() for k in raw_keywords if str(k).strip()]

    # Ensure output path has .docx extension
    # Normalise output path (accept relative paths)
    output_path = os.path.abspath(output_path)
    if not output_path.endswith(".docx"):
        output_path += ".docx"

    # Build report
    try:
        result = build_full_report(output_path, data, profile)
        result["warnings"] = warnings + result.get("warnings", [])
        return json.dumps(result, indent=2)
    except Exception as e:
        import traceback
        return json.dumps({
            "status": "error",
            "errors": [f"Build failed: {str(e)}"],
            "traceback": traceback.format_exc()
        })


async def inspect_report(filename: str) -> str:
    """
    Return a paragraph-by-paragraph dump of a generated report DOCX.

    Use this after create_rvce_report to verify the output before
    presenting it to the user. Each entry shows index, style, and
    a text preview.

    Args:
        filename: Path to the generated .docx file.

    Returns:
        JSON array of paragraph descriptors.
    """
    from rvce_report_mcp.core.format_extractor import inspect_template_paragraphs

    if not filename.endswith(".docx"):
        filename += ".docx"

    if not os.path.exists(filename):
        return json.dumps({"error": f"File not found: {filename}"})

    try:
        paragraphs = inspect_template_paragraphs(filename)
        return json.dumps(paragraphs, indent=2)
    except Exception as e:
        return json.dumps({"error": f"Failed to inspect report: {str(e)}"})
