"""
Section tools for RVCE Report MCP Server.

Phase 1:
  add_report_section — replace a named section in an existing report

Phase 2 stubs (raise NotImplementedError — implementation deferred):
  set_title_page
  set_certificate
  set_acknowledgement
  set_abstract
"""
from __future__ import annotations

import json
import os
from typing import Optional

from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.oxml.ns import qn

from rvce_report_mcp.core import get_default_profile
from rvce_report_mcp.core.format_extractor import extract_format_profile
from rvce_report_mcp.core.cross_reference import FigureRegistry, TableRegistry
from rvce_report_mcp.core.report_builder import (
    build_chapter, build_references, build_appendix,
    build_abstract, build_acknowledgement_placeholder,
    _add_heading,
)
from rvce_report_mcp.utils.validator import validate_project_context
from rvce_report_mcp.utils.style_utils import apply_paragraph_format


# ---------------------------------------------------------------------------
# Phase 1 — add_report_section
# ---------------------------------------------------------------------------

async def add_report_section(
    filename: str,
    section_type: str,
    content_json: str,
    template_path: Optional[str] = None,
) -> str:
    """
    Replace or add a named section in an existing RVCE report .docx file.

    Valid section_type values:
      abstract        — replaces the abstract placeholder
      acknowledgement — replaces the acknowledgement placeholder
      chapter_N       — replaces/appends chapter N (e.g. "chapter_1", "chapter_3")
      references      — replaces the references section
      appendix        — replaces/appends an appendix section

    content_json schema:
      For abstract / acknowledgement:
        {"text": "Full text of the section..."}

      For chapter_N:
        Same as a single chapter object from project_context.chapters:
        {"number": N, "title": "...", "sections": [...]}

      For references:
        {"references": ["1. ...", "2. ..."]}

      For appendix:
        {"title": "Visuals", "paragraphs": [...]}

    Args:
        filename: Path to an existing .docx file.
        section_type: One of the valid section type strings above.
        content_json: JSON string with section content.
        template_path: Optional path to sample DOCX for format extraction.

    Returns:
        JSON string with {status, message} or {status: error, errors: [...]}.
    """
    valid_types = {"abstract", "acknowledgement", "references", "appendix"}
    is_chapter = section_type.startswith("chapter_")

    if section_type not in valid_types and not is_chapter:
        return json.dumps({
            "status": "error",
            "errors": [
                f"Unknown section_type '{section_type}'. "
                f"Valid values: abstract, acknowledgement, chapter_N, references, appendix."
            ]
        })

    if not filename.endswith(".docx"):
        filename += ".docx"
    if not os.path.exists(filename):
        return json.dumps({"status": "error", "errors": [f"File not found: {filename}"]})

    try:
        if isinstance(content_json, str):
            content = json.loads(content_json)
        else:
            content = content_json
    except json.JSONDecodeError as e:
        return json.dumps({"status": "error", "errors": [f"Invalid JSON: {str(e)}"]})

    report_type = content.get("report_type", "el_report")
    try:
        if template_path and os.path.exists(template_path):
            profile = extract_format_profile(template_path, report_type)
        else:
            profile = get_default_profile(report_type)
    except Exception as e:
        return json.dumps({"status": "error", "errors": [f"Failed to load template: {str(e)}"]})

    try:
        doc = Document(filename)
    except Exception as e:
        return json.dumps({"status": "error", "errors": [f"Failed to open document: {str(e)}"]})

    try:
        if section_type == "abstract":
            _replace_placeholder_section(doc, "ABSTRACT", content.get("text", ""), profile)

        elif section_type == "acknowledgement":
            _replace_placeholder_section(doc, "ACKNOWLEDGEMENT", content.get("text", ""), profile)

        elif is_chapter:
            # Validate chapter content before appending
            dummy_context = {
                "team": [{"name": "x", "usn": "x", "dept": "x", "email": "x"}],
                "chapters": [content],
                "references": ["1. A", "2. B", "3. C", "4. D", "5. E"],
                "report_type": report_type,
            }
            is_valid, errors, _ = validate_project_context(dummy_context)
            if not is_valid:
                return json.dumps({"status": "error", "errors": errors})

            fig_registry = FigureRegistry()
            tbl_registry = TableRegistry()
            build_chapter(doc, content, profile, fig_registry, tbl_registry)

        elif section_type == "references":
            refs = content.get("references", [])
            build_references(doc, refs, profile)

        elif section_type == "appendix":
            fig_registry = FigureRegistry()
            tbl_registry = TableRegistry()
            build_appendix(doc, content, profile, fig_registry, tbl_registry)

        doc.save(filename)
        return json.dumps({"status": "success", "message": f"Section '{section_type}' updated in {filename}."})

    except Exception as e:
        import traceback
        return json.dumps({
            "status": "error",
            "errors": [f"Failed to update section: {str(e)}"],
            "traceback": traceback.format_exc()
        })


def _replace_placeholder_section(doc: Document, section_label: str,
                                  new_text: str, profile) -> None:
    """
    Find the placeholder paragraph for a section and replace it with real content.
    Searches for the heading paragraph matching section_label, then replaces the
    placeholder paragraph immediately after it.
    """
    paras = doc.paragraphs
    for i, para in enumerate(paras):
        if para.text.strip().upper() == section_label.upper():
            # Found the heading; next paragraph should be the placeholder
            if i + 1 < len(paras):
                placeholder_para = paras[i + 1]
                # Clear placeholder text and write new content
                for run in placeholder_para.runs:
                    run.text = ""
                if placeholder_para.runs:
                    run = placeholder_para.runs[0]
                    run.text = new_text
                    run.font.name = profile.body.font_name
                    run.font.size = Pt(profile.body.font_size_pt)
                    run.font.bold = False
                    run.font.italic = False
                    run.font.color.rgb = RGBColor(0, 0, 0)
                    apply_paragraph_format(placeholder_para, profile.body)
            return


# ---------------------------------------------------------------------------
# Phase 2 stubs — NOT YET IMPLEMENTED
# ---------------------------------------------------------------------------

async def set_title_page(
    filename: str,
    college_name: str,
    affiliation: str,
    tagline: str,
    logo_path: str,
    report_type_label: str,
    sdg_theme: str,
    project_title: str,
    faculty_mentor: dict,
    academic_year: str,
) -> str:
    """
    Replace the cover page placeholder with a fully formatted RVCE cover page.

    Cover page paragraph sequence:
      1. college_name        — TNR 16pt Bold Centered
      2. affiliation         — TNR 11pt Italic Centered
      3. Logo image          — centered, from logo_path
      4. tagline             — TNR 11pt Italic Centered
      5. report_type_label   — TNR 14pt Bold Centered
      6. sdg_theme           — TNR 12pt Bold Centered
      7. project_title       — TNR 16pt Bold Centered
      8-12. faculty_mentor fields (name, designation, department, college, city)
      13. academic_year      — TNR 12pt Centered

    The cover page section has no header or footer.

    NOT YET IMPLEMENTED — Phase 2.
    """
    raise NotImplementedError(
        "set_title_page() is a Phase 2 tool and has not been implemented yet. "
        "The cover page currently contains a placeholder paragraph. "
        "Use create_rvce_report() to generate the rest of the report."
    )


async def set_certificate(
    filename: str,
    team: list,
    guide: str,
    co_guide: str = "",
    hod: str = "",
) -> str:
    """
    Replace the certificate placeholder with a filled Bonafide Certificate.

    NOT YET IMPLEMENTED — Phase 2.
    """
    raise NotImplementedError(
        "set_certificate() is a Phase 2 tool and has not been implemented yet."
    )


async def set_acknowledgement(filename: str, text: str) -> str:
    """
    Replace the acknowledgement placeholder with the provided text.

    This is a convenience wrapper around add_report_section with section_type='acknowledgement'.
    Alternatively, use add_report_section() directly.

    NOT YET IMPLEMENTED as a dedicated tool — use add_report_section() with
    section_type='acknowledgement' and content_json='{"text": "..."}' instead.
    """
    raise NotImplementedError(
        "set_acknowledgement() is a Phase 2 convenience tool. "
        "Use add_report_section(filename, 'acknowledgement', '{\"text\": \"...\"}') instead."
    )


async def set_abstract(filename: str, text: str) -> str:
    """
    Replace the abstract placeholder with the provided text.

    NOT YET IMPLEMENTED as a dedicated tool — use add_report_section() with
    section_type='abstract' and content_json='{"text": "..."}' instead.
    """
    raise NotImplementedError(
        "set_abstract() is a Phase 2 convenience tool. "
        "Use add_report_section(filename, 'abstract', '{\"text\": \"...\"}') instead."
    )
