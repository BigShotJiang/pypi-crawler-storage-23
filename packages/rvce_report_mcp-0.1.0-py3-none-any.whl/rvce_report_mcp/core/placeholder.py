"""
Figure/image placeholder builder for RVCE Report MCP Server.

source values:
  napkin      → grey placeholder box with napkin instructions
  draw.io     → grey placeholder box with draw.io instructions
  image_file  → grey placeholder box for generic image
  screenshot  → grey placeholder box for screenshot
  embed       → actual image embedded from file_path using add_picture()
"""
from __future__ import annotations

import os
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from rvce_report_mcp.core import FormatProfile
from rvce_report_mcp.utils.style_utils import set_cell_shading, set_keep_together, _ALIGN_ENUM


_SOURCE_INSTRUCTIONS = {
    "napkin": "[Napkin Diagram – export PNG/SVG and insert here]",
    "draw.io": "[draw.io Diagram – export and insert here]",
    "image_file": "[Insert image file here]",
    "screenshot": "[Insert screenshot here]",
    "default": "[Diagram / Image placeholder – insert here]",
}

_PLACEHOLDER_BOX_WIDTH_CM = 14.0
_PLACEHOLDER_BOX_HEIGHT_CM = 7.0


def add_figure(
    doc: Document,
    fig_id: str,
    caption: str,
    source: str,
    label: str,
    profile: FormatProfile,
    file_path: str = "",
    width_cm: float = 0.0,
) -> None:
    """
    Add a figure placeholder or embedded image to the document.

    Args:
        doc: Target Document
        fig_id: Figure identifier string
        caption: Figure caption text
        source: One of napkin/draw.io/image_file/screenshot/embed
        label: Resolved label string e.g. "Figure 2.3"
        profile: FormatProfile for fonts
        file_path: Required when source == "embed"
        width_cm: Override image width in cm (embed only); 0 = use usable_width
    """
    if source == "embed":
        _add_embedded_figure(doc, fig_id, caption, label, profile, file_path, width_cm)
    else:
        _add_placeholder_figure(doc, fig_id, caption, source, label, profile)


def _add_placeholder_figure(
    doc: Document,
    fig_id: str,
    caption: str,
    source: str,
    label: str,
    profile: FormatProfile,
) -> None:
    """Add a grey-shaded placeholder box followed by a caption."""
    instruction = _SOURCE_INSTRUCTIONS.get(source, _SOURCE_INSTRUCTIONS["default"])

    # Create a 1-cell table as the placeholder box
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"

    # Set table width to a reasonable fraction of usable_width
    box_width = min(_PLACEHOLDER_BOX_WIDTH_CM, profile.usable_width_cm)
    _set_table_width(table, Cm(box_width))

    cell = table.cell(0, 0)
    set_cell_shading(cell, "D9D9D9")

    # Set cell height via XML (minimum height)
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    trPr = table.rows[0]._tr.get_or_add_trPr()
    trHeight = OxmlElement("w:trHeight")
    trHeight.set(qn("w:val"), str(int(_PLACEHOLDER_BOX_HEIGHT_CM * 567)))  # twips
    trHeight.set(qn("w:hRule"), "atLeast")
    trPr.append(trHeight)

    # Centre-align cell content
    cell_para = cell.paragraphs[0]
    cell_para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = cell_para.add_run(instruction)
    run.font.name = profile.caption.font_name
    run.font.size = Pt(10)
    run.font.italic = True
    run.font.color.rgb = RGBColor(0x80, 0x80, 0x80)

    # Caption paragraph below table
    _add_caption_para(doc, label, caption, profile)


def _add_embedded_figure(
    doc: Document,
    fig_id: str,
    caption: str,
    label: str,
    profile: FormatProfile,
    file_path: str,
    width_cm: float,
) -> None:
    """Embed an actual image from file_path."""
    if not os.path.exists(file_path):
        # Fallback to placeholder if file missing at build time
        _add_placeholder_figure(doc, fig_id, caption, "image_file", label, profile)
        return

    effective_width = width_cm if width_cm > 0 else profile.usable_width_cm

    para = doc.add_paragraph()
    para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = para.add_run()
    try:
        run.add_picture(file_path, width=Cm(effective_width))
    except Exception:
        run.text = f"[Could not embed image: {file_path}]"
        run.font.italic = True

    set_keep_together(para)
    _add_caption_para(doc, label, caption, profile)


def _add_caption_para(doc: Document, label: str, caption: str, profile: FormatProfile) -> None:
    """Add a centered caption paragraph: 'Figure X.Y: caption text'"""
    para = doc.add_paragraph()
    para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    para.paragraph_format.space_before = Pt(profile.caption.space_before_pt)
    para.paragraph_format.space_after = Pt(profile.caption.space_after_pt)
    set_keep_together(para)

    run = para.add_run(f"{label}: {caption}")
    run.font.name = profile.caption.font_name
    run.font.size = Pt(profile.caption.font_size_pt)
    run.font.bold = True


def _set_table_width(table, width) -> None:
    """Set table total width via XML w:tblW."""
    tbl = table._tbl
    tblPr = tbl.find(qn("w:tblPr"))
    if tblPr is None:
        tblPr = OxmlElement("w:tblPr")
        tbl.insert(0, tblPr)
    tblW = tblPr.find(qn("w:tblW"))
    if tblW is None:
        tblW = OxmlElement("w:tblW")
        tblPr.append(tblW)
    tblW.set(qn("w:w"), str(int(width.cm * 567)))
    tblW.set(qn("w:type"), "dxa")
