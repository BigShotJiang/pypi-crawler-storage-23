import zipfile, re

def extract_tokens(docx_path: str) -> list[str]:
    """
    Extract all [token] placeholders from a docx file.
    Handles Word's run-splitting by stripping rsid attributes
    and merging adjacent runs before scanning.
    """
    with zipfile.ZipFile(docx_path, 'r') as z:
        xml = z.read('word/document.xml').decode('utf-8')
    xml = _strip_rsid_attrs(xml)
    xml = _merge_adjacent_runs(xml)
    plain = re.sub(r'<[^>]+>', '', xml)
    plain = re.sub(r'\s+', ' ', plain).strip()
    tokens = re.findall(r'\[[^\]]{1,120}\]', plain)
    return sorted(set(tokens))


def preprocess_xml(xml: str) -> str:
    """
    Prepare document XML for token replacement.
    Must be called before any str.replace() token substitution.
    """
    xml = _strip_rsid_attrs(xml)
    xml = _merge_adjacent_runs(xml)
    return xml


def _strip_rsid_attrs(xml: str) -> str:
    """Remove Word revision-tracking IDs that cause run splitting."""
    return re.sub(r'\s+w:rsid[RPDra-z]*="[A-F0-9]+"', '', xml)


def _merge_adjacent_runs(xml: str) -> str:
    """
    Merge consecutive w:r runs that have identical rPr formatting.
    Runs repeatedly until stable (handles 3+ run splits).

    Uses [^<]* for text content so the regex cannot cross XML tag
    boundaries and corrupt the document structure.
    """
    pattern = re.compile(
        r'(<w:r>(<w:rPr>.*?</w:rPr>)?<w:t[^>]*>)'  # open of run 1
        r'([^<]*)'                                    # text (no tags)
        r'(</w:t></w:r>)'                             # close of run 1
        r'\s*'
        r'<w:r>\2<w:t[^>]*>'                         # open of run 2 (same rPr)
        r'([^<]*)'                                    # text (no tags)
        r'</w:t></w:r>',                              # close of run 2
        re.DOTALL  # needed so rPr content matches across newlines
    )
    def _merge(m):
        return f'{m.group(1)}{m.group(3)}{m.group(5)}{m.group(4)}'
    prev = None
    while prev != xml:
        prev = xml
        xml = pattern.sub(_merge, xml)
    return xml