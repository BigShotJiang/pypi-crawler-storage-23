"""
Format extractor for RVCE Report MCP Server.

Reads a sample DOCX and extracts a FormatProfile by:
1. Parsing TOC 1/2/3 style paragraphs to establish heading hierarchy
2. Matching each level to body Heading N paragraphs for exact font/size/alignment
3. Walking style inheritance chain when paragraph.alignment is None
4. Extracting header/footer structure from doc.sections[0]
5. Falling back to report_type built-in defaults for any missing value
"""
from __future__ import annotations

import os
import re
from typing import Optional

from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

from rvce_report_mcp.core import (
    FormatProfile, ParagraphStyleProfile, HeaderProfile, FooterProfile,
    HeaderFooterParaProfile, TabStopProfile, get_default_profile
)


# Maps python-docx WD_ALIGN_PARAGRAPH values to string keys used in FormatProfile
_ALIGN_MAP = {
    WD_ALIGN_PARAGRAPH.LEFT: "LEFT",
    WD_ALIGN_PARAGRAPH.CENTER: "CENTER",
    WD_ALIGN_PARAGRAPH.RIGHT: "RIGHT",
    WD_ALIGN_PARAGRAPH.JUSTIFY: "JUSTIFY",
    None: None,
}

# Module-level cache: template_path -> FormatProfile
_profile_cache: dict[str, FormatProfile] = {}


def _pt_from_run(run) -> Optional[float]:
    """Return font size in pt from a run, or None if not set."""
    if run.font.size is not None:
        return run.font.size.pt
    return None


def _alignment_str(para, doc) -> Optional[str]:
    """
    Walk the paragraph → style → base_style chain to find an explicit alignment.
    Returns string key or None.
    """
    # Direct paragraph alignment
    align = para.paragraph_format.alignment
    if align is not None:
        return _ALIGN_MAP.get(align)

    # Walk style chain
    style = para.style
    while style is not None:
        align = style.paragraph_format.alignment
        if align is not None:
            return _ALIGN_MAP.get(align)
        style = style.base_style

    return None


def _extract_style_profile(para, doc, fallback: ParagraphStyleProfile) -> ParagraphStyleProfile:
    """
    Extract a ParagraphStyleProfile from a paragraph.
    Uses the first run for font attributes; falls back to style-level properties.
    """
    profile = ParagraphStyleProfile(
        font_name=fallback.font_name,
        font_size_pt=fallback.font_size_pt,
        bold=fallback.bold,
        italic=fallback.italic,
        alignment=fallback.alignment,
        space_before_pt=fallback.space_before_pt,
        space_after_pt=fallback.space_after_pt,
        line_spacing=fallback.line_spacing,
    )

    # Font attributes from first non-empty run
    for run in para.runs:
        if run.text.strip():
            if run.font.name:
                profile.font_name = run.font.name
            pt = _pt_from_run(run)
            if pt:
                profile.font_size_pt = pt
            if run.font.bold is not None:
                profile.bold = run.font.bold
            if run.font.italic is not None:
                profile.italic = run.font.italic
            break

    # Alignment (with inheritance walk)
    alignment = _alignment_str(para, doc)
    if alignment:
        profile.alignment = alignment

    # Spacing
    pf = para.paragraph_format
    if pf.space_before is not None:
        profile.space_before_pt = pf.space_before.pt
    if pf.space_after is not None:
        profile.space_after_pt = pf.space_after.pt

    # Line spacing (multiple)
    if pf.line_spacing is not None and pf.line_spacing_rule is not None:
        from docx.enum.text import WD_LINE_SPACING
        if pf.line_spacing_rule == WD_LINE_SPACING.MULTIPLE:
            try:
                profile.line_spacing = float(pf.line_spacing)
            except Exception:
                pass

    return profile


def _has_border_rule(para, side: str = "bottom") -> bool:
    """Check if a paragraph has a border on the given side via XML."""
    pPr = para._element.find(qn("w:pPr"))
    if pPr is None:
        return False
    pBdr = pPr.find(qn("w:pBdr"))
    if pBdr is None:
        return False
    return pBdr.find(qn(f"w:{side}")) is not None


def _has_page_number_field(para) -> bool:
    """Check if a paragraph contains a PAGE field (w:fldChar / w:instrText)."""
    for elem in para._element.iter():
        if elem.tag == qn("w:instrText"):
            if "PAGE" in (elem.text or ""):
                return True
    return False


def _page_number_position(footer_paragraphs: list) -> str:
    """Infer page number alignment from footer paragraphs."""
    for para in footer_paragraphs:
        if _has_page_number_field(para):
            align = _ALIGN_MAP.get(para.paragraph_format.alignment)
            if align == "LEFT":
                return "left"
            if align == "RIGHT":
                return "right"
            return "center"
    return "none"


def _extract_tab_stops(para) -> list[TabStopProfile]:
    """Extract tab stop positions from a paragraph."""
    stops = []
    try:
        for ts in para.paragraph_format.tab_stops:
            from docx.enum.text import WD_TAB_ALIGNMENT
            align_map = {
                WD_TAB_ALIGNMENT.LEFT: "LEFT",
                WD_TAB_ALIGNMENT.CENTER: "CENTER",
                WD_TAB_ALIGNMENT.RIGHT: "RIGHT",
            }
            stops.append(TabStopProfile(
                position_cm=ts.position.cm,
                alignment=align_map.get(ts.alignment, "LEFT"),
                leader="dots" if ts.leader else "none",
            ))
    except Exception:
        pass
    return stops


def _has_image_in_para(para) -> bool:
    """Check if a paragraph contains an inline image."""
    return para._element.find('.//' + qn("a:blip")) is not None


def _extract_header_profile(section) -> HeaderProfile:
    """Extract header structure from a document section."""
    hp = HeaderProfile()
    try:
        header = section.header
        if header is None or header.is_linked_to_previous:
            return hp
        for para in header.paragraphs:
            if _has_image_in_para(para):
                hp.has_image = True
            php = HeaderFooterParaProfile(
                text=para.text,
                font_name="Times New Roman",
                font_size_pt=10.0,
                alignment=_ALIGN_MAP.get(para.paragraph_format.alignment, "CENTER") or "CENTER",
                tab_stops=_extract_tab_stops(para),
                has_page_number_field=_has_page_number_field(para),
            )
            for run in para.runs:
                if run.text.strip():
                    if run.font.name:
                        php.font_name = run.font.name
                    pt = _pt_from_run(run)
                    if pt:
                        php.font_size_pt = pt
                    if run.font.bold is not None:
                        php.bold = run.font.bold
                    if run.font.italic is not None:
                        php.italic = run.font.italic
                    break
            hp.paragraphs.append(php)
        # Check for bottom border on last paragraph
        if header.paragraphs:
            hp.has_rule = _has_border_rule(header.paragraphs[-1], "bottom")
    except Exception:
        pass
    return hp


def _extract_footer_profile(section) -> FooterProfile:
    """Extract footer structure from a document section."""
    fp = FooterProfile()
    try:
        footer = section.footer
        if footer is None or footer.is_linked_to_previous:
            return fp
        for para in footer.paragraphs:
            php = HeaderFooterParaProfile(
                text=para.text,
                font_name="Times New Roman",
                font_size_pt=10.0,
                alignment=_ALIGN_MAP.get(para.paragraph_format.alignment, "CENTER") or "CENTER",
                tab_stops=_extract_tab_stops(para),
                has_page_number_field=_has_page_number_field(para),
            )
            for run in para.runs:
                if run.text.strip():
                    if run.font.name:
                        php.font_name = run.font.name
                    pt = _pt_from_run(run)
                    if pt:
                        php.font_size_pt = pt
                    break
            fp.paragraphs.append(php)

        fp.page_number_position = _page_number_position(footer.paragraphs)
        # Check for top border on first paragraph
        if footer.paragraphs:
            fp.has_rule = _has_border_rule(footer.paragraphs[0], "top")
    except Exception:
        pass
    return fp


def extract_format_profile(doc_path: str, report_type: str = "el_report") -> FormatProfile:
    """
    Extract a FormatProfile from a sample DOCX file.

    Strategy:
    1. Scan for TOC 1/2/3 paragraphs to confirm heading levels present
    2. For each confirmed level, find first Heading N body paragraph and extract style
    3. Fall back to built-in defaults for any missing level
    4. Extract header/footer from sections[0]
    """
    if doc_path in _profile_cache:
        return _profile_cache[doc_path]

    profile = get_default_profile(report_type)

    if not os.path.exists(doc_path):
        return profile

    try:
        doc = Document(doc_path)
    except Exception:
        return profile

    # Step 1 — discover which heading levels have TOC entries
    toc_levels_found = set()
    for para in doc.paragraphs:
        style_name = para.style.name if para.style else ""
        if style_name.startswith("TOC "):
            try:
                level = int(style_name.replace("TOC ", "").strip())
                toc_levels_found.add(level)
            except ValueError:
                pass

    # Step 2 — find body Heading paragraphs and extract style
    heading_paragraphs: dict[int, object] = {}
    for para in doc.paragraphs:
        style_name = para.style.name if para.style else ""
        if style_name.startswith("Heading "):
            try:
                level = int(style_name.replace("Heading ", "").strip())
                if level not in heading_paragraphs and para.text.strip():
                    heading_paragraphs[level] = para
            except ValueError:
                pass

    # Apply extracted heading styles to profile
    level_map = {1: (profile.h1, profile.h1), 2: (profile.h2, profile.h2), 3: (profile.h3, profile.h3)}
    for level, (target, fallback) in level_map.items():
        if level in heading_paragraphs:
            extracted = _extract_style_profile(heading_paragraphs[level], doc, fallback)
            # Replace in-place
            target.font_name = extracted.font_name
            target.font_size_pt = extracted.font_size_pt
            target.bold = extracted.bold
            target.italic = extracted.italic
            target.alignment = extracted.alignment
            target.space_before_pt = extracted.space_before_pt
            target.space_after_pt = extracted.space_after_pt

    # Step 3 — extract body (Normal) style
    for para in doc.paragraphs:
        style_name = para.style.name if para.style else ""
        if style_name == "Normal" and len(para.text.strip()) > 30:
            extracted = _extract_style_profile(para, doc, profile.body)
            profile.body = extracted
            break

    # Step 4 — page setup from first section
    try:
        section = doc.sections[0]
        profile.page_width_cm = section.page_width.cm
        profile.page_height_cm = section.page_height.cm
        profile.margin_left_cm = section.left_margin.cm
        profile.margin_right_cm = section.right_margin.cm
        profile.margin_top_cm = section.top_margin.cm
        profile.margin_bottom_cm = section.bottom_margin.cm
        if section.header_distance:
            profile.header_distance_cm = section.header_distance.cm
        if section.footer_distance:
            profile.footer_distance_cm = section.footer_distance.cm
        profile.different_first_page = section.different_first_page_header_footer

        # Header / footer
        profile.header = _extract_header_profile(section)
        profile.footer = _extract_footer_profile(section)

        if profile.different_first_page:
            profile.first_page_header = _extract_header_profile(section)  # first_page_header
            profile.first_page_footer = _extract_footer_profile(section)
    except Exception:
        pass

    _profile_cache[doc_path] = profile
    return profile


def profile_to_dict(profile: FormatProfile) -> dict:
    """Convert a FormatProfile to a JSON-serialisable dict."""
    def style_dict(s: ParagraphStyleProfile) -> dict:
        return {
            "font_name": s.font_name,
            "font_size_pt": s.font_size_pt,
            "bold": s.bold,
            "italic": s.italic,
            "alignment": s.alignment,
            "space_before_pt": s.space_before_pt,
            "space_after_pt": s.space_after_pt,
            "line_spacing": s.line_spacing,
        }

    def hfpara_dict(p: HeaderFooterParaProfile) -> dict:
        return {
            "text": p.text,
            "font_name": p.font_name,
            "font_size_pt": p.font_size_pt,
            "bold": p.bold,
            "italic": p.italic,
            "alignment": p.alignment,
            "has_page_number_field": p.has_page_number_field,
            "tab_stops": [{"position_cm": t.position_cm, "alignment": t.alignment} for t in p.tab_stops],
        }

    def header_dict(h: HeaderProfile) -> dict:
        return {
            "has_rule": h.has_rule,
            "has_image": h.has_image,
            "paragraphs": [hfpara_dict(p) for p in h.paragraphs],
        }

    def footer_dict(f: FooterProfile) -> dict:
        return {
            "has_rule": f.has_rule,
            "page_number_position": f.page_number_position,
            "paragraphs": [hfpara_dict(p) for p in f.paragraphs],
        }

    return {
        "report_type": profile.report_type,
        "page": {
            "width_cm": profile.page_width_cm,
            "height_cm": profile.page_height_cm,
            "margin_left_cm": profile.margin_left_cm,
            "margin_right_cm": profile.margin_right_cm,
            "margin_top_cm": profile.margin_top_cm,
            "margin_bottom_cm": profile.margin_bottom_cm,
            "usable_width_cm": profile.usable_width_cm,
        },
        "h1": style_dict(profile.h1),
        "h2": style_dict(profile.h2),
        "h3": style_dict(profile.h3),
        "body": style_dict(profile.body),
        "caption": style_dict(profile.caption),
        "reference": style_dict(profile.reference),
        "header": header_dict(profile.header),
        "footer": footer_dict(profile.footer),
        "different_first_page": profile.different_first_page,
    }


def inspect_template_paragraphs(doc_path: str) -> list[dict]:
    """
    Return a paragraph-by-paragraph dump of a DOCX file.
    Used by the inspect_template tool.
    """
    if not os.path.exists(doc_path):
        return [{"error": f"File not found: {doc_path}"}]

    try:
        doc = Document(doc_path)
    except Exception as e:
        return [{"error": str(e)}]

    result = []
    for i, para in enumerate(doc.paragraphs):
        style_name = para.style.name if para.style else "Unknown"
        font_name = ""
        font_size_pt = None
        bold = None
        for run in para.runs:
            if run.text.strip():
                font_name = run.font.name or ""
                pt = _pt_from_run(run)
                font_size_pt = pt
                bold = run.font.bold
                break
        alignment = _ALIGN_MAP.get(para.paragraph_format.alignment)
        result.append({
            "index": i,
            "style": style_name,
            "font_name": font_name,
            "font_size_pt": font_size_pt,
            "bold": bold,
            "alignment": alignment,
            "text_preview": para.text[:80] + ("..." if len(para.text) > 80 else ""),
        })
    return result
