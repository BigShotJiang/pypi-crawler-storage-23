# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import os
from typing import Optional, Tuple

import aiohttp
from simple_term_menu import TerminalMenu
import tarfile
import tempfile

from amesa_api.common import APIBase
from amesa_api.util.token import get_token_path


class APINoCode(APIBase):
    def __init__(self, base_url, use_license_key: Optional[str] = None):
        super().__init__(base_url)

        self.token = self._get_token(use_license_key=use_license_key)
        self.organizations = APINoCodeOrganizations(self)
        self.projects = APINoCodeProjects(self)
        self.sims = APINoCodeSims(self)
        self.jobs = APINoCodeJobs(self)
        self.asset_store = APIAssetStore(self)

    def _get_token(self, use_license_key: Optional[str] = None) -> str:
        """
        Get the token from the API
        """
        # Try to load the token from ~/.composabl/token
        token = None

        if use_license_key is not None:
            return use_license_key
        else:
            try:
                token_path = get_token_path()

                with open(token_path, "r") as f:
                    token = f.read()
            except FileNotFoundError:
                raise Exception("No token found. Please login first with `amesa login`")

            if token is None:
                raise Exception("No token found. Please login first with `amesa login`")

            return token


class APINoCodeOrganizations:
    def __init__(self, api):
        self.api = api

    async def list(self):
        """
        List all organizations
        """
        return await self.api.get("/organizations")

    async def get(self, organization_id: str):
        """
        Get an organization
        """
        return await self.api.get(f"/organizations/{organization_id}")

    async def cli_select(self) -> dict:
        """
        Select an organization through a CLI prompt

        Returns:
            dict: Organization
        """
        organizations = await self.list()
        organization_names = [
            f"{organization['name']} (uuid: {organization['uuid']})"
            for organization in organizations
        ]

        menu_organizations = TerminalMenu(
            organization_names, title="Select an Organization:"
        )
        selected_idx = menu_organizations.show()

        print("Selected organization:", organizations[selected_idx]["name"])

        return organizations[selected_idx]


class APINoCodeProjects:
    def __init__(self, api):
        self.api = api

        self.perceptors = APINoCodeProjectPerceptors(api)
        self.skills = APINoCodeProjectSkills(api)
        self.selectors = APINoCodeProjectSelectors(api)

    async def list(self, organization_uuid: str):
        """
        List all projects
        """
        return await self.api.get(f"/organizations/{organization_uuid}/projects/")

    async def get(self, organization_uuid: str, project_uuid: str):
        """
        Get a project
        """
        return await self.api.get(
            f"/organizations/{organization_uuid}/projects/{project_uuid}"
        )

    async def cli_select(self) -> dict:
        """
        Select a project through a CLI prompt

        Returns:
            dict: Project
        """
        organization = await self.api.organizations.cli_select()
        organization_uuid = organization.get("uuid", None)

        if organization_uuid is None:
            raise Exception("Organization ID not found")

        projects = await self.list(organization_uuid)
        project_names = [
            f"{project['name']} (uuid: {project['id']})" for project in projects
        ]

        menu_projects = TerminalMenu(project_names, title="Select a Project:")
        selected_idx = menu_projects.show()

        print("Selected project:", project_names[selected_idx])

        return projects[selected_idx]


class APINoCodeSims:
    def __init__(self, api):
        self.api = api

    async def list(self, organization_uuid: str):
        """
        List all simulators
        """
        return await self.api.get(f"/organizations/{organization_uuid}/simulators/")

    async def get(self, organization_uuid: str, sim_uuid: str):
        """
        Get a sim
        """
        return await self.api.get(
            f"/organizations/{organization_uuid}/simulators/{sim_uuid}"
        )

    async def get_by_name(self, organization_uuid: str, sim_name: str):
        """
        Get a sim by name
        """
        sims = await self.list(organization_uuid)
        for sim in sims:
            if sim["name"] == sim_name:
                return sim

        return None

    async def cli_select(self) -> dict:
        """
        Select a sim through a CLI prompt

        Returns:
            dict: Sim
        """
        organization = await self.api.organizations.cli_select()
        organization_uuid = organization.get("uuid", None)

        if organization_uuid is None:
            raise Exception("Organization ID not found")

        sims = await self.list(organization_uuid)
        sim_names = [f"{sim['name']} (uuid: {sim['id']})" for sim in sims]

        menu_sims = TerminalMenu(sim_names, title="Select a Sim:")
        selected_idx = menu_sims.show()

        print("Selected sim:", sim_names[selected_idx])

        return sims[selected_idx]

    async def delete(self, organization_uuid: str, sim_uuid: str):
        """
        Delete a sim
        """
        return await self.api.delete(
            f"/organizations/{organization_uuid}/simulators/{sim_uuid}"
        )

    async def create(self, organization_uuid: str, name: str, description: str = ""):
        """
        Create a sim
        """
        return await self.api.put(
            f"/organizations/{organization_uuid}/simulators/",
            data={"name": name, "description": description},
        )

    async def create_impl(
        self, organization_uuid: str, sim_uuid: str, file_path: str, type: str = "zip"
    ):
        """
        Attach code to a sim through multipart/form-data
        """
        with open(file_path, "rb") as f:
            data = aiohttp.FormData()
            data.add_field(
                "file",
                f,
                filename=os.path.basename(file_path),
                content_type="application/tar+gzip",
            )
            data.add_field("type", type)

            return await self.api.put(
                f"/organizations/{organization_uuid}/simulators/{sim_uuid}", data
            )


class APINoCodeProjectPerceptors:
    def __init__(self, api):
        self.api = api

    async def list(self, organization_uuid: str, project_uuid: str):
        """
        List all perceptors
        """
        return await self.api.get(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/perceptors/"
        )

    async def get(self, organization_uuid: str, project_uuid: str, perceptor_uuid: str):
        """
        Get a perceptor
        """
        return await self.api.get(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/perceptors/{perceptor_uuid}"
        )

    async def delete(
        self, organization_uuid: str, project_uuid: str, perceptor_uuid: str
    ):
        """
        Delete a perceptor
        """
        return await self.api.delete(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/perceptors/{perceptor_uuid}"
        )

    async def create(
        self,
        organization_uuid: str,
        project_uuid: str,
        name: str,
        description: str = "",
    ):
        """
        Create a perceptor and upload it through multipart/form-data
        """
        return await self.api.put(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/perceptors/",
            data={"name": name, "description": description},
        )

    async def create_impl(
        self,
        organization_uuid: str,
        project_uuid: str,
        perceptor_uuid: str,
        file_path: str,
    ):
        """
        Create a perceptor with implementation
        """
        with open(file_path, "rb") as f:
            data = aiohttp.FormData()
            data.add_field(
                "file",
                f,
                filename=os.path.basename(file_path),
                content_type="application/tar+gzip",
            )
            data.add_field("type", "normal")

            return await self.api.put(
                f"/organizations/{organization_uuid}/projects/{project_uuid}/perceptors/{perceptor_uuid}",
                data,
            )

    async def cli_select(self) -> Tuple[str, str, dict]:
        """
        Select a perceptor through a CLI prompt

        Returns:
            Tuple[str, str, dict]: Organization ID, Project ID, Perceptor
        """
        project = await self.api.projects.cli_select()
        org_id = project["organization_id"]
        proj_id = project["id"]

        perceptors = await self.list(org_id, proj_id)
        perceptor_names = [
            f"{perceptor['name']} (uuid: {perceptor['id']})" for perceptor in perceptors
        ]

        menu_perceptors = TerminalMenu(perceptor_names, title="Select a Perceptor:")
        selected_idx = menu_perceptors.show()

        print("Selected perceptor:", perceptor_names[selected_idx])

        return org_id, proj_id, perceptors[selected_idx]


class APINoCodeProjectSkills:
    def __init__(self, api):
        self.api = api

    async def list(self, organization_uuid: str, project_uuid: str):
        """
        List all skills
        """
        return await self.api.get(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/skills/"
        )

    async def get(self, organization_uuid: str, project_uuid: str, skill_uuid: str):
        """
        Get a skill
        """
        return await self.api.get(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/skills/{skill_uuid}"
        )

    async def delete(self, organization_uuid: str, project_uuid: str, skill_uuid: str):
        """
        Delete a skill
        """
        return await self.api.delete(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/skills/{skill_uuid}"
        )

    async def create(
        self,
        organization_uuid: str,
        project_uuid: str,
        name: str,
        description: str = "",
    ):
        """
        Create a skill and upload it through multipart/form-data
        """
        return await self.api.put(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/skills/",
            data={"name": name, "description": description},
        )

    async def create_impl(
        self,
        organization_uuid: str,
        project_uuid: str,
        skill_uuid: str,
        type: str,
        file_path: str,
    ):
        """
        Create a skill with implementation
        """
        with open(file_path, "rb") as f:
            data = aiohttp.FormData()
            data.add_field(
                "file",
                f,
                filename=os.path.basename(file_path),
                content_type="application/tar+gzip",
            )
            data.add_field("type", type)

            return await self.api.put(
                f"/organizations/{organization_uuid}/projects/{project_uuid}/skills/{skill_uuid}",
                data,
            )

    async def cli_select(self) -> Tuple[str, str, dict]:
        """
        Select a skill through a CLI prompt

        Returns:
            Tuple[str, str, dict]: Organization ID, Project ID, Skill
        """
        project = await self.api.projects.cli_select()
        org_id = project["organization_id"]
        proj_id = project["id"]

        skills = await self.list(org_id, proj_id)
        skill_names = [f"{skill['name']} (uuid: {skill['id']})" for skill in skills]

        menu_skills = TerminalMenu(skill_names, title="Select a Skill:")
        selected_idx = menu_skills.show()

        print("Selected skill:", skill_names[selected_idx])

        return org_id, proj_id, skills[selected_idx]


class APINoCodeProjectSelectors:
    def __init__(self, api):
        self.api = api

    async def list(self, organization_uuid: str, project_uuid: str):
        """
        List all selectors
        """
        return await self.api.get(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/selectors/"
        )

    async def get(self, organization_uuid: str, project_uuid: str, selector_uuid: str):
        """
        Get a selector
        """
        return await self.api.get(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/selectors/{selector_uuid}"
        )

    async def delete(
        self, organization_uuid: str, project_uuid: str, selector_uuid: str
    ):
        """
        Delete a selector
        """
        return await self.api.delete(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/selectors/{selector_uuid}"
        )

    async def create(
        self,
        organization_uuid: str,
        project_uuid: str,
        name: str,
        description: str = "",
    ):
        """
        Create a selector and upload it through multipart/form-data
        """
        return await self.api.put(
            f"/organizations/{organization_uuid}/projects/{project_uuid}/selectors/",
            data={"name": name, "description": description},
        )

    async def create_impl(
        self,
        organization_uuid: str,
        project_uuid: str,
        selector_uuid: str,
        type: str,
        file_path: str,
    ):
        """
        Create a selector with implementation
        """
        with open(file_path, "rb") as f:
            data = aiohttp.FormData()
            data.add_field(
                "file",
                f,
                filename=os.path.basename(file_path),
                content_type="application/tar+gzip",
            )
            data.add_field("type", type)

            return await self.api.put(
                f"/organizations/{organization_uuid}/projects/{project_uuid}/selectors/{selector_uuid}",
                data,
            )

    async def cli_select(self) -> Tuple[str, str, dict]:
        """
        Select a selector through a CLI prompt

        Returns:
            Tuple[str, str, dict]: Organization ID, Project ID, Selector
        """
        project = await self.api.projects.cli_select()
        org_id = project["organization_id"]
        proj_id = project["id"]

        selectors = await self.list(org_id, proj_id)
        selector_names = [
            f"{selector['name']} (uuid: {selector['id']})" for selector in selectors
        ]

        menu_selectors = TerminalMenu(selector_names, title="Select a Selector:")
        selected_idx = menu_selectors.show()

        print("Selected selector:", selector_names[selected_idx])

        return org_id, proj_id, selectors[selected_idx]


class APINoCodeJobs:
    def __init__(self, api):
        self.api: APINoCode = api

    async def submit_kubernetes(self, config, agent, training_cycles: int = 100):
        """
        Submit an agent to a custom cluster for training, based on the provided config
        """
        # TODO fully define once implemented on NC
        await self.api.post("/something", {})

    async def submit_amesa(self, config, agent, training_cycles: int = 100):
        """
        Submit an agent to the TaaS cluster for training, based on the provided config
        """
        # TODO fully define once implemented on NC
        await self.api.post("/something", {})

    async def list(self):
        """
        List all jobs with status < Stopped/Failed/Done
        """
        # TODO fully define once implemented on NC
        result = await self.api.get("/something")

        return result

    async def cancel(self, job_id):
        """
        Cancel a job on either custom cluster or TaaS
        """
        # TODO fully define once implemented on NC
        await self.api.post("/something", {})


class APIAssetStore:
    def __init__(self, api):
        self.api = api

    async def submit_directory(self, organization_uuid: str, project_uuid: str, directory_path: str, asset_key: str = "ray_checkpoint"):
        """
        Submit a directory to the asset store
        """
        if not os.path.isdir(directory_path):
            raise Exception(f"Directory {directory_path} does not exist")

        # Ensure the checkpoint directory exists
        if not os.path.exists(directory_path):
            return

        with tempfile.TemporaryDirectory() as temp_dir:
            with tarfile.open(temp_dir + "/checkpoint.tar.gz", "w:gz") as tar:
                tar.add(directory_path, arcname=os.path.basename(directory_path))

            data = aiohttp.FormData()
            data.add_field(
                "assetKey",
                asset_key,
                content_type="text/plain",
            )
            data.add_field(
                "type",
                "artifacts",
            )
            file_path = os.path.join(temp_dir, "checkpoint.tar.gz")
            data.add_field(
                "file",
                open(file_path, "rb"),
                filename=os.path.basename(file_path),
                content_type="application/tar+gzip",
            )
            return await self.api.post(
                f"/organizations/{organization_uuid}/projects/{project_uuid}/assets/",
                data,
            )
