# zalor-agents

Zalor tracing SDK for AI agents. Instruments your agent with OpenTelemetry and ships traces to the Zalor backend for automated evaluation.

## Installation

```bash
pip install zalor-agents           # core only
pip install zalor-agents[openai]   # with OpenAI instrumentation
```

## Quick Start

### Instrument an OpenAI agent and run a full test suite

```python
from zalor.agents import test_agent

def my_agent(user_input: str) -> str:
    # your OpenAI-based agent logic here
    ...

test_agent(
    agent_name="my-assistant",
    api_key="zal-...",
    run_agent=my_agent,
)
# Prints a link to view results in the Zalor dashboard
```

### Low-level: instrument and capture a trace manually

```python
from zalor.agents.openai import configure_openai

exporter = configure_openai(api_key="zal-...", endpoint="https://agents.zalor.ai")
my_agent("Hello")
print(exporter.trace_id)
```

## Requirements

Python >= 3.13
