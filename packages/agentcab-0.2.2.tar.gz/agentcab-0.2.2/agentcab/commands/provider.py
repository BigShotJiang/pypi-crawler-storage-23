"""Provider commands"""

import json
import click
from agentcab import ProviderClient, ProviderWorker
from agentcab.commands.auth import get_api_key, get_base_url


def require_auth(f):
    """Decorator to ensure API key is configured"""
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        api_key = get_api_key()
        if not api_key:
            click.echo(click.style("✗ Error: API key not configured", fg="red"))
            click.echo("  Run 'agentcab login' first to configure your API key")
            raise click.Abort()
        return f(*args, **kwargs)
    return wrapper


@click.group()
def provider():
    """Manage your APIs and run workers"""
    pass


@provider.command()
@click.option("--name", required=True, help="API name")
@click.option("--description", required=True, help="API description")
@click.option("--category", help="API category")
@click.option("--price", type=int, required=True, help="Price in credits")
@click.option("--max-workers", type=int, default=5, help="Max concurrent jobs")
@click.option("--input-schema", required=True, help="Input JSON schema (as JSON string)")
@click.option("--output-schema", required=True, help="Output JSON schema (as JSON string)")
@click.option("--tags", help="Comma-separated tags")
@require_auth
def create(name, description, category, price, max_workers, input_schema, output_schema, tags):
    """Create a new API

    Example:
        agentcab provider create \\
          --name "Translation API" \\
          --description "Translate English to Chinese" \\
          --category nlp \\
          --price 10 \\
          --input-schema '{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}' \\
          --output-schema '{"type":"object","properties":{"translation":{"type":"string"}}}'
    """
    try:
        input_schema_obj = json.loads(input_schema)
        output_schema_obj = json.loads(output_schema)
    except json.JSONDecodeError as e:
        click.echo(click.style(f"✗ Error: Invalid JSON schema: {e}", fg="red"))
        raise click.Abort()

    tags_list = [t.strip() for t in tags.split(",")] if tags else None

    client = ProviderClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        api = client.create_api(
            name=name,
            description=description,
            input_schema=input_schema_obj,
            output_schema=output_schema_obj,
            price_credits=price,
            category=category,
            tags=tags_list,
            max_concurrent_jobs=max_workers,
        )

        click.echo(click.style("✓ API created successfully!", fg="green"))
        click.echo(f"  ID: {api['id']}")
        click.echo(f"  Name: {api['name']}")
        click.echo(f"  Price: {api['price_credits']} credits")
        click.echo(f"\nStart worker with: agentcab provider start")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@provider.command()
@require_auth
def list():
    """List your APIs"""
    client = ProviderClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        apis = client.list_my_apis()

        if not apis:
            click.echo("No APIs found. Create one with 'agentcab provider create'")
            return

        click.echo(f"\n{'ID':<40} {'Name':<30} {'Price':<10} {'Status'}")
        click.echo("-" * 90)

        for api in apis:
            click.echo(
                f"{api['id']:<40} "
                f"{api['name']:<30} "
                f"{api['price_credits']:<10} "
                f"{api.get('status', 'active')}"
            )

        click.echo(f"\nTotal: {len(apis)} API(s)")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()


@provider.command()
@click.option("--command", help="Shell command to execute for each job")
@click.option("--agent-url", help="HTTP URL to forward jobs to")
@click.option("--poll-interval", type=int, default=5, help="Seconds between polling")
@click.option("--max-workers", type=int, default=1, help="Number of concurrent workers")
@click.option("--timeout", type=int, default=30, help="Request timeout in seconds")
@require_auth
def start(command, agent_url, poll_interval, max_workers, timeout):
    """Start worker to process jobs

    The worker will continuously poll for new jobs and process them.

    Examples:
        # Using shell command
        agentcab provider start --command "python my_agent.py"

        # Using HTTP endpoint
        agentcab provider start --agent-url "http://localhost:8000/process"

        # Multiple workers
        agentcab provider start --command "python my_agent.py" --max-workers 3
    """
    if not command and not agent_url:
        click.echo(click.style("✗ Error: Must provide --command or --agent-url", fg="red"))
        raise click.Abort()

    click.echo(click.style("Starting AgentCab worker...", fg="cyan"))
    click.echo(f"  Poll interval: {poll_interval}s")
    click.echo(f"  Max workers: {max_workers}")
    click.echo(f"  Timeout: {timeout}s")
    if command:
        click.echo(f"  Command: {command}")
    if agent_url:
        click.echo(f"  Agent URL: {agent_url}")
    click.echo("\nPress Ctrl+C to stop\n")

    try:
        worker = ProviderWorker(
            api_key=get_api_key(),
            base_url=get_base_url(),
            command=command,
            agent_url=agent_url,
            poll_interval=poll_interval,
            max_workers=max_workers,
            timeout=timeout,
        )
        worker.run()

    except KeyboardInterrupt:
        click.echo(click.style("\n\n✓ Worker stopped", fg="yellow"))
    except Exception as e:
        click.echo(click.style(f"\n✗ Error: {e}", fg="red"))
        raise click.Abort()
