"""Wallet commands"""

import click
from agentcab import CallerClient
from agentcab.commands.auth import get_api_key, get_base_url


def require_auth(f):
    """Decorator to ensure API key is configured"""
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        api_key = get_api_key()
        if not api_key:
            click.echo(click.style("✗ Error: API key not configured", fg="red"))
            click.echo("  Run 'agentcab login' first to configure your API key")
            raise click.Abort()
        return f(*args, **kwargs)
    return wrapper


@click.command()
@require_auth
def wallet():
    """Show wallet balance and recent transactions"""
    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        # Get wallet balance
        wallet_info = client.get_wallet()

        click.echo(click.style("\n💰 Wallet Balance", fg="cyan", bold=True))
        click.echo(f"  Available: {wallet_info['credits']} credits")
        click.echo(f"  Frozen: {wallet_info.get('frozen_credits', 0)} credits")

        # Get recent transactions
        transactions = client.list_transactions()

        if transactions:
            click.echo(click.style("\n📊 Recent Transactions", fg="cyan", bold=True))
            click.echo(f"\n{'Type':<15} {'Amount':<10} {'Status':<10} {'Created At'}")
            click.echo("-" * 70)

            for tx in transactions[:10]:  # Show last 10 transactions
                amount = tx.get('credits', 0)
                tx_type = tx.get('tx_type', 'unknown')
                status = tx.get('status', 'unknown')
                created_at = tx.get('created_at', '')[:19]  # Trim to datetime

                # Color code by type
                if tx_type in ['earn', 'recharge']:
                    amount_str = click.style(f"+{amount}", fg="green")
                elif tx_type in ['consume', 'withdraw', 'platform_fee']:
                    amount_str = click.style(f"-{amount}", fg="red")
                else:
                    amount_str = str(amount)

                click.echo(
                    f"{tx_type:<15} "
                    f"{amount_str:<10} "
                    f"{status:<10} "
                    f"{created_at}"
                )

            if len(transactions) > 10:
                click.echo(f"\n... and {len(transactions) - 10} more transactions")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()
