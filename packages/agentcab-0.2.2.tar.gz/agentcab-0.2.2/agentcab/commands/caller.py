"""Caller commands"""

import json
import click
from agentcab import CallerClient
from agentcab.commands.auth import get_api_key, get_base_url


def require_auth(f):
    """Decorator to ensure API key is configured"""
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        api_key = get_api_key()
        if not api_key:
            click.echo(click.style("✗ Error: API key not configured", fg="red"))
            click.echo("  Run 'agentcab login' first to configure your API key")
            raise click.Abort()
        return f(*args, **kwargs)
    return wrapper


@click.command()
@click.argument("api_id")
@click.option("--input", "input_data", required=True, help="Input data as JSON string")
@click.option("--wait/--no-wait", default=True, help="Wait for result (default: wait)")
@click.option("--timeout", type=int, default=60, help="Timeout in seconds")
@require_auth
def call(api_id, input_data, wait, timeout):
    """Call an API

    Examples:
        # Call API and wait for result
        agentcab call api_abc123 --input '{"text":"Hello world"}'

        # Call API without waiting
        agentcab call api_abc123 --input '{"text":"Hello"}' --no-wait
    """
    try:
        input_obj = json.loads(input_data)
    except json.JSONDecodeError as e:
        click.echo(click.style(f"✗ Error: Invalid JSON input: {e}", fg="red"))
        raise click.Abort()

    client = CallerClient(api_key=get_api_key(), base_url=get_base_url())

    try:
        if wait:
            click.echo(click.style("Calling API...", fg="cyan"))
            result = client.call_api_sync(api_id, input_obj, timeout=timeout)

            click.echo(click.style("\n✓ API call completed", fg="green"))
            click.echo(f"  Call ID: {result.get('id') or result.get('call_id')}")
            click.echo(f"  Status: {result['status']}")
            click.echo(f"  Duration: {result.get('duration_ms', 0)}ms")

            output = result.get("output_data") or result.get("output")
            if output:
                click.echo("\nOutput:")
                click.echo(json.dumps(output, indent=2, ensure_ascii=False))

            if result.get("error_message"):
                click.echo(click.style(f"\nError: {result['error_message']}", fg="red"))

        else:
            result = client.call_api(api_id, input_obj)
            click.echo(click.style("✓ API call submitted", fg="green"))
            click.echo(f"  Call ID: {result['call_id']}")
            click.echo(f"\nCheck status with: agentcab call status {result['call_id']}")

    except Exception as e:
        click.echo(click.style(f"✗ Error: {e}", fg="red"))
        raise click.Abort()
