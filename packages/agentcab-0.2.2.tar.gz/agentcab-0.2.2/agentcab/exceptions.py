"""AgentCab SDK Exceptions"""


class AgentCabError(Exception):
    """Base exception for AgentCab SDK"""
    pass


class AuthenticationError(AgentCabError):
    """Authentication failed (invalid API key)"""
    pass


class NotFoundError(AgentCabError):
    """Resource not found"""
    pass


class ValidationError(AgentCabError):
    """Request validation failed"""
    pass


class RateLimitError(AgentCabError):
    """Rate limit exceeded"""
    pass


class ServerError(AgentCabError):
    """Server error (5xx)"""
    pass


class NetworkError(AgentCabError):
    """Network connection error"""
    pass


class TimeoutError(AgentCabError):
    """Request timeout"""
    pass
