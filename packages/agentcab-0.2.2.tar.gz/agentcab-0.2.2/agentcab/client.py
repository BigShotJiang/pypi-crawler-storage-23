"""AgentCab Base HTTP Client"""

import requests
from typing import Optional, Dict, Any
from .exceptions import (
    AuthenticationError,
    NotFoundError,
    ValidationError,
    RateLimitError,
    ServerError,
    NetworkError,
    TimeoutError as SDKTimeoutError,
)


class BaseClient:
    """Base HTTP client for AgentCab API"""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://www.agentcab.ai/v1",
        timeout: int = 30,
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        })

    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """Handle API response and raise appropriate exceptions"""
        try:
            data = response.json()
        except ValueError:
            data = {"message": response.text}

        if response.status_code == 200:
            return data.get("data", data)
        elif response.status_code == 401:
            raise AuthenticationError(data.get("message", "Authentication failed"))
        elif response.status_code == 404:
            raise NotFoundError(data.get("message", "Resource not found"))
        elif response.status_code == 400:
            raise ValidationError(data.get("message", "Validation failed"))
        elif response.status_code == 429:
            raise RateLimitError(data.get("message", "Rate limit exceeded"))
        elif response.status_code >= 500:
            raise ServerError(data.get("message", f"Server error: {response.status_code}"))
        else:
            raise Exception(f"Unexpected status code: {response.status_code}")

    def get(self, path: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        """Make GET request"""
        url = f"{self.base_url}{path}"
        try:
            response = self.session.get(url, params=params, timeout=self.timeout)
            return self._handle_response(response)
        except requests.exceptions.Timeout:
            raise SDKTimeoutError(f"Request timeout: {url}")
        except requests.exceptions.ConnectionError as e:
            raise NetworkError(f"Connection error: {e}")

    def post(self, path: str, json: Optional[Dict] = None) -> Dict[str, Any]:
        """Make POST request"""
        url = f"{self.base_url}{path}"
        try:
            response = self.session.post(url, json=json, timeout=self.timeout)
            return self._handle_response(response)
        except requests.exceptions.Timeout:
            raise SDKTimeoutError(f"Request timeout: {url}")
        except requests.exceptions.ConnectionError as e:
            raise NetworkError(f"Connection error: {e}")

    def put(self, path: str, json: Optional[Dict] = None) -> Dict[str, Any]:
        """Make PUT request"""
        url = f"{self.base_url}{path}"
        try:
            response = self.session.put(url, json=json, timeout=self.timeout)
            return self._handle_response(response)
        except requests.exceptions.Timeout:
            raise SDKTimeoutError(f"Request timeout: {url}")
        except requests.exceptions.ConnectionError as e:
            raise NetworkError(f"Connection error: {e}")

    def delete(self, path: str) -> Dict[str, Any]:
        """Make DELETE request"""
        url = f"{self.base_url}{path}"
        try:
            response = self.session.delete(url, timeout=self.timeout)
            return self._handle_response(response)
        except requests.exceptions.Timeout:
            raise SDKTimeoutError(f"Request timeout: {url}")
        except requests.exceptions.ConnectionError as e:
            raise NetworkError(f"Connection error: {e}")

    def upload_file(self, path: str, file_path: str, params: Optional[Dict] = None) -> Dict[str, Any]:
        """Upload a file using multipart/form-data"""
        url = f"{self.base_url}{path}"
        try:
            # Create a new session without Content-Type header for multipart
            headers = {"Authorization": f"Bearer {self.api_key}"}
            with open(file_path, "rb") as f:
                files = {"file": f}
                response = requests.post(
                    url,
                    files=files,
                    params=params,
                    headers=headers,
                    timeout=self.timeout
                )
            return self._handle_response(response)
        except requests.exceptions.Timeout:
            raise SDKTimeoutError(f"Request timeout: {url}")
        except requests.exceptions.ConnectionError as e:
            raise NetworkError(f"Connection error: {e}")
        except FileNotFoundError:
            raise ValidationError(f"File not found: {file_path}")

    def download_file(self, path: str, save_path: str) -> str:
        """Download a file and save to disk"""
        url = f"{self.base_url}{path}"
        try:
            response = self.session.get(url, timeout=self.timeout, stream=True)
            if response.status_code != 200:
                self._handle_response(response)

            with open(save_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            return save_path
        except requests.exceptions.Timeout:
            raise SDKTimeoutError(f"Request timeout: {url}")
        except requests.exceptions.ConnectionError as e:
            raise NetworkError(f"Connection error: {e}")
