"""Hook system for Harness event lifecycle."""
