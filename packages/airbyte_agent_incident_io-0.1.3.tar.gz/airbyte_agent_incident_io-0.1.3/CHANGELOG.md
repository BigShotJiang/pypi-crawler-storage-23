# Incident Io changelog

## [0.1.3] - 2026-03-03
- Updated connector definition (YAML version 1.0.2)
- Source commit: 9808f8a1
- SDK version: 0.1.0

## [0.1.2] - 2026-03-03
- Updated connector definition (YAML version 1.0.2)
- Source commit: b90b5edf
- SDK version: 0.1.0

## [0.1.1] - 2026-03-03
- Updated connector definition (YAML version 1.0.1)
- Source commit: 258f32e0
- SDK version: 0.1.0

## [0.1.0] - 2026-02-27
- Updated connector definition (YAML version 1.0.1)
- Source commit: 7cd2cc4e
- SDK version: 0.1.0
