"""
Log :doc:`pattern matching </log-pattern-matching>` API.

.. seealso::

    See :doc:`/log-pattern-matching` usage guide.
"""

from __future__ import annotations

from logot._logged import critical as critical
from logot._logged import debug as debug
from logot._logged import error as error
from logot._logged import info as info
from logot._logged import log as log
from logot._logged import warning as warning
