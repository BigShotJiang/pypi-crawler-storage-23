"""
Integration API for :mod:`asyncio`.

.. seealso::

    See :ref:`index-testing-async` usage guide.
"""

from __future__ import annotations

from logot._asyncio import AsyncioWaiter as AsyncioWaiter
