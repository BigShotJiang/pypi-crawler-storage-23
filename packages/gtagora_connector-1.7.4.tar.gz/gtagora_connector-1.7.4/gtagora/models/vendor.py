from gtagora.models.base import BaseModel


class Vendor(BaseModel):
    BASE_URL = '/api/v1/scannervendor/'

    pass