def main():
    print('Sparrow Parse is a Python package for parsing and extracting information from documents.')


if __name__ == "__main__":
    main()