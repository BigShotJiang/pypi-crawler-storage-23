- Sylvain LE GAL (<https://twitter.com/legalsylvain>)

- Benoit GUILLOT (<benoit.guillot@akretion.com>)

- Stéphane Bidoul (<stephane.bidoul@acsone.eu>)

- [Tecnativa](https://www.tecnativa.com):

  > - Vicent Cubells
  > - Cristina Martin R.
  > - Carlos Roca
  > - Ernesto Tejeda
