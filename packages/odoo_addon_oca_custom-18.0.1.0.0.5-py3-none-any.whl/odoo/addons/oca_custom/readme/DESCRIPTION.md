Custom module for OCA Instance.
