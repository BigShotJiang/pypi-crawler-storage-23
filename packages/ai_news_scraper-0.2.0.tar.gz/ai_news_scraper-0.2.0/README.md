# AI News Scraper

A lightweight Python package to track AI developments, investments, and trends from The Verge and VentureBeat.

## Installation
```bash
pip install ai-news-scraper

```

## View News 

```bash 
ai-news

```

## Save News to JSON
```bash 
ai-news --save

```

## Save News with a specifc name 
```bash 
ai-news --save --filename morning_report.json

```