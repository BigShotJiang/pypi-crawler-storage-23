# TasksMind Python SDK

The official Python client for the [TasksMind API](https://tasksmind.com) — The AI Engineer for Developers on Call.

## Installation

```bash
pip install tasksmind
```

## Quick Start

```python
from tasksmind import TasksMind

client = TasksMind()  # reads TASKSMIND_API_KEY env var automatically

# Kick off a PR review
run = client.runs.create(
    repo_url="https://github.com/my-org/my-repo",
    repo_ref="main",
    payload={
        "intent": "review_pr",
        "target": {"pr_number": 42},
    },
)
print(f"Run started: {run.id}")

# Poll until complete (up to 10 minutes)
result = client.runs.wait(run.id, timeout_s=600)
if result.is_success():
    print(result.summary)
else:
    print(f"Run failed: {result.error}")
```

## Configuration

| Parameter | Env variable | Default |
|-----------|-------------|---------|
| `api_key` | `TASKSMIND_API_KEY` | — (required) |
| `base_url` | `TASKSMIND_API_BASE_URL` | `https://api.tasksmind.com` |
| `timeout` | — | `60` seconds |

## Available intents

Pass `intent` inside `payload`. Some intents need `target.pr_number` or `raw_text`.

| Intent | Required extras | Description |
|--------|-----------------|-------------|
| `summarize_repo` | — | Summarize the repository |
| `review_pr` | `target.pr_number` | Review a pull request |
| `status_pr` | `target.pr_number` | Get PR status / CI checks |
| `changes_pr` | `target.pr_number` | Describe what changed in a PR |
| `fix_bug` | `raw_text` | Investigate and fix a described bug |
| `fix_ci` | `target.pr_number` | Fix CI failures on a PR |
| `root_cause` | `target.pr_number` | Root-cause analysis |
| `implement_feature` | `raw_text` | Implement a described feature |

## `client.runs` methods

| Method | Description |
|--------|-------------|
| `runs.create(repo_url, repo_ref, payload)` | Create a new run |
| `runs.get(run_id)` | Fetch a run by ID |
| `runs.list(limit, offset, status)` | List runs for your account |
| `runs.wait(run_id, timeout_s, poll_s)` | Poll until terminal status |

## `Run` object

| Attribute | Type | Description |
|-----------|------|-------------|
| `.id` | `str` | Run UUID |
| `.status` | `str` | `queued`, `running`, `completed`, `failed`, `error`, `cancelled` |
| `.output` | `str` | Full output text from the run |
| `.summary` | `str \| None` | Short AI-generated summary |
| `.pr_url` | `str \| None` | Pull request URL if one was created |
| `.pr_number` | `int \| None` | Pull request number |
| `.error` | `str \| None` | Error message if run failed |
| `.is_success()` | `bool` | `True` when status is `completed` or `succeeded` |

## Error Handling

```python
from tasksmind import TasksMind, AuthError, NotFoundError, APIError, TimeoutError

client = TasksMind()

try:
    run = client.runs.create(repo_url="https://github.com/org/repo")
    result = client.runs.wait(run.id, timeout_s=300)
except AuthError:
    print("Invalid API key")
except TimeoutError:
    print("Run did not finish in time")
except APIError as e:
    print(f"API error {e.status_code}: {e.body}")
```

## Context Manager

```python
with TasksMind() as client:
    run = client.runs.create(repo_url="https://github.com/org/repo")
    result = client.runs.wait(run.id, timeout_s=300)
    print(result.summary)
```

## Requirements

- Python 3.9+
- `httpx >= 0.24`

## Links

- [Website](https://tasksmind.com)
- [Documentation](https://tasksmind.com/documentation)
- [API Reference](https://tasksmind.com/api-reference)
- [PyPI](https://pypi.org/project/tasksmind/)
