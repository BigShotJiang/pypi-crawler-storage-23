from .computer import ManyBodyComputer
