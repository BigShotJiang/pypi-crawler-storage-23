See [changelog in docs](docs/changelog.rst).
