=======
Results
=======

The QCManyBody package outputs many results from its analysis.

For the :doc:`core-interface`, the results are expected to be stored in a nested dictionary. For the
:doc:`high-level-interface`, the results are stored in a :class:`~qcmanybody.models.ManyBodyResult` object.

Fields
======

(Additional information about result fields will be documented here.)
