"""Headroom CLI - Command-line interface for memory and proxy management."""

from .main import main

__all__ = ["main"]
