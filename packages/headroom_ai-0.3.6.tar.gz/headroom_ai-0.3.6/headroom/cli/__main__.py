"""Allow running CLI with python -m headroom.cli."""

from .main import main

if __name__ == "__main__":
    main()
