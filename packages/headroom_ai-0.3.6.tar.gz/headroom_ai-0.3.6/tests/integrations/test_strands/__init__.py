"""Tests for Strands Agents SDK integration with Headroom."""
