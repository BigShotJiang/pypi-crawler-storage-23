"""Tests for Headroom storage implementations."""
