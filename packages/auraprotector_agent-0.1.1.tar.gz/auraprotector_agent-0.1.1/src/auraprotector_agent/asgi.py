"""Re-export for compatibility."""

from ultimateprotector_agent.asgi import *  # noqa: F403
