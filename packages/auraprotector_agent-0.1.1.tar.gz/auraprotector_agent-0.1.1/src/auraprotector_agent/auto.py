"""Re-export for compatibility."""

from ultimateprotector_agent.auto import *  # noqa: F403
