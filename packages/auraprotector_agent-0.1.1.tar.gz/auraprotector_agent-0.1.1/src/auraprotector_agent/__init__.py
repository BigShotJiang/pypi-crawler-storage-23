"""Compatibility import path.

The distribution name on PyPI is `auraprotector-agent`.

Historically the internal module path was `ultimateprotector_agent`.
To reduce confusion for new users, we provide `auraprotector_agent` as
an alias that re-exports the public API.

Both imports are supported:

    from auraprotector_agent.asgi import UltimateProtectorMiddleware
    from ultimateprotector_agent.asgi import UltimateProtectorMiddleware
"""

from ultimateprotector_agent.asgi import UltimateProtectorMiddleware
from ultimateprotector_agent.auto import config_from_env, wrap_asgi_app

__all__ = ["UltimateProtectorMiddleware", "config_from_env", "wrap_asgi_app"]
