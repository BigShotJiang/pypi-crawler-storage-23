# auraprotector-agent (Python)

Python in-process agent for ASGI runtimes (FastAPI/Starlette/etc).

## Install

```bash
pip install auraprotector-agent
```

## FastAPI usage

```py
from fastapi import FastAPI
from auraprotector_agent.asgi import UltimateProtectorMiddleware

app = FastAPI()

app.add_middleware(
    UltimateProtectorMiddleware,
    license_key="UP_LIVE_...",
    api_url="https://YOUR_CLOUD/api",
)

```

## Zero-code-ish usage (env wrapper)

If you can change *how* the app is created (but don't want to paste config into code),
wrap the ASGI app using env vars:

```py
import os
from fastapi import FastAPI
from auraprotector_agent import wrap_asgi_app

app = wrap_asgi_app(FastAPI())

# env:
# UP_LICENSE_KEY=UP_LIVE_...
# UP_API_URL=https://YOUR_CLOUD/api
```

### Optional: sitecustomize bootstrap

The platform can generate a `sitecustomize.py` helper inside the **Python auto bundle**.
If that file is on `PYTHONPATH`, Python auto-imports it on startup.
Set `UP_ASGI_APP="module:app"` and it will best-effort wrap that object automatically (fail-open).

## Notes

- PyPI distribution name: `auraprotector-agent`
- Import path: `auraprotector_agent` (recommended)
- Legacy import path still supported: `ultimateprotector_agent`


## Options

- `license_key` (required)
- `api_url` (required) e.g. `https://cloud.example/api`
- `sync_interval_seconds` (default: `60`)
- `allow_sample_rate` (default: `0.01`)
- `only_paths`: list[str] exact (`/checkout`) or prefix (`/product/*`)
- `except_paths`: list[str]
- `only_regex`: str (Python regex)
