import tempfile
from pathlib import Path as RealPath
from types import SimpleNamespace
from unittest.mock import patch

from autopkg_wrapper.models.recipe import Recipe
from autopkg_wrapper.utils.recipe_batching import (
    build_recipe_batches,
    describe_recipe_batches,
)


class TestAutopkgCommands:
    def test_verify_trust_info_uses_autopkg_bin_and_sets_verified_true(self):
        r = Recipe("Foo.download")
        args = SimpleNamespace(
            debug=False,
            autopkg_prefs=None,
            autopkg_bin="/custom/autopkg",
            dry_run=False,
        )

        with patch("autopkg_wrapper.models.recipe.subprocess.run") as run:
            run.return_value = SimpleNamespace(returncode=0, stderr="", stdout="")
            ok = r.verify_trust_info(args)

        assert ok is True
        called_cmd = run.call_args.args[0]
        assert called_cmd[0] == "/custom/autopkg"
        assert called_cmd[1] == "verify-trust-info"
        assert called_cmd[2] == "Foo.download"

    def test_verify_trust_info_failure_sets_message(self):
        r = Recipe("Foo.download")
        args = SimpleNamespace(
            debug=True,
            autopkg_prefs=None,
            autopkg_bin="/usr/local/bin/autopkg",
            dry_run=False,
        )

        with patch("autopkg_wrapper.models.recipe.subprocess.run") as run:
            run.return_value = SimpleNamespace(
                returncode=1, stderr="bad trust", stdout=""
            )
            ok = r.verify_trust_info(args)

        assert ok is False
        assert r.results["message"] == "bad trust"

    def test_update_trust_info_uses_autopkg_bin(self):
        r = Recipe("Foo.download")
        args = SimpleNamespace(
            autopkg_prefs=None, autopkg_bin="/custom/autopkg", dry_run=False
        )

        with patch("autopkg_wrapper.models.recipe.subprocess.check_call") as cc:
            r.update_trust_info(args)

        called_cmd = cc.call_args.args[0]
        assert called_cmd[0] == "/custom/autopkg"
        assert called_cmd[1] == "update-trust-info"
        assert called_cmd[2] == "Foo.download"

    def test_recipe_identifier_matches_filename(self):
        r = Recipe("Foo.upload.jamf")
        assert r.identifier == "Foo.upload.jamf"

    def test_run_uses_autopkg_bin_and_report_plist(self):
        r = Recipe("Foo.download")
        args = SimpleNamespace(
            debug=False,
            autopkg_prefs=None,
            autopkg_bin="/custom/autopkg",
            dry_run=False,
        )

        with tempfile.TemporaryDirectory() as td:

            def fake_path(arg):
                if arg == "/private/tmp/autopkg":
                    return RealPath(td)
                return RealPath(arg)

            with (
                patch("autopkg_wrapper.models.recipe.Path", side_effect=fake_path),
                patch("autopkg_wrapper.models.recipe.subprocess.run") as run,
                patch.object(
                    r,
                    "_parse_report",
                    return_value={"imported": [], "failed": []},
                ),
            ):
                run.return_value = SimpleNamespace(returncode=0, stderr="", stdout="")
                r.verified = True
                r.run(args)

        called_cmd = run.call_args.args[0]
        assert called_cmd[0] == "/custom/autopkg"
        assert called_cmd[1] == "run"
        assert "--report-plist" in called_cmd

    def test_build_recipe_batches_without_processing_order(self):
        recipes = [Recipe("Foo.upload.jamf"), Recipe("Foo.auto_install.jamf")]
        batches = build_recipe_batches(
            recipe_list=recipes, recipe_processing_order=None
        )
        assert len(batches) == 1
        assert [r.name for r in batches[0]] == [r.name for r in recipes]

    def test_build_recipe_batches_groups_by_type(self):
        recipes = [
            Recipe("Foo.upload.jamf"),
            Recipe("Bar.upload.jamf"),
            Recipe("Foo.auto_install.jamf"),
            Recipe("Foo.self_service.jamf"),
        ]
        batches = build_recipe_batches(
            recipe_list=recipes, recipe_processing_order=["upload", "auto_install"]
        )
        assert len(batches) == 3
        assert [r.name for r in batches[0]] == [
            "Foo.upload.jamf",
            "Bar.upload.jamf",
        ]
        assert [r.name for r in batches[1]] == ["Foo.auto_install.jamf"]
        assert [r.name for r in batches[2]] == ["Foo.self_service.jamf"]

    def test_describe_recipe_batches_uses_identifiers(self):
        recipes = [
            Recipe("Foo.upload.jamf"),
            Recipe("Bar.auto_install.jamf"),
        ]
        batches = build_recipe_batches(
            recipe_list=recipes, recipe_processing_order=["upload", "auto_install"]
        )
        descriptions = describe_recipe_batches(batches)
        assert descriptions == [
            {
                "type": "upload.jamf",
                "count": 1,
                "recipes": ["Foo.upload.jamf"],
            },
            {
                "type": "auto_install.jamf",
                "count": 1,
                "recipes": ["Bar.auto_install.jamf"],
            },
        ]
