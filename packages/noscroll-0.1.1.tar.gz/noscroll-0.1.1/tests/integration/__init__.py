"""Integration tests for NoScroll CLI."""
