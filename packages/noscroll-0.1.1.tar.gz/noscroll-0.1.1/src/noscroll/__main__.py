"""Support for python -m noscroll."""

from .cli import main

raise SystemExit(main())
