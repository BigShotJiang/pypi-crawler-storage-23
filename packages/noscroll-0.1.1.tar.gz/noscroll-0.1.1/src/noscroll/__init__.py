"""NoScroll - Pull, don't scroll. RSS aggregator with LLM-powered summarization."""

__version__ = "0.1.0"
