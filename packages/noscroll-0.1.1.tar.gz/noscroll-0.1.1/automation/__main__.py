"""Allow running automation as a module: python -m automation"""

from .loop import main

if __name__ == "__main__":
    main()
