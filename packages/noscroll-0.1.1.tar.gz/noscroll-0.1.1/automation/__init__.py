"""Automation harness for NoScroll using Claude Agent SDK.

This package provides an automated run → test → eval → fix loop.
"""
