"""Graph representation and optimization framework for hardware-aware computation."""

from __future__ import annotations

from sagellm_backend.graph.config import OptimizationConfig
from sagellm_backend.graph.graph import Graph, Node, OpType
from sagellm_backend.graph.optimizer import GraphOptimizer
from sagellm_backend.graph.pass_base import OptimizationPass, PassRegistry, PassResult

__all__ = [
    "Graph",
    "Node",
    "OpType",
    "GraphOptimizer",
    "OptimizationPass",
    "PassRegistry",
    "PassResult",
    "OptimizationConfig",
]
