"""CPU-specific optimization passes."""

from sagellm_backend.graph.passes.constant_folding import ConstantFoldingPass
from sagellm_backend.graph.passes.cuda_hardware_optimization import CUDAHardwareOptimizationPass
from sagellm_backend.graph.passes.data_format_selection import DataFormatSelectionPass
from sagellm_backend.graph.passes.dead_node_elimination import DeadNodeEliminationPass
from sagellm_backend.graph.passes.identity_elimination import IdentityEliminationPass
from sagellm_backend.graph.passes.layout_conversion import LayoutConversionPass
from sagellm_backend.graph.passes.memory_reuse_analysis import MemoryReuseAnalysisPass
from sagellm_backend.graph.passes.operator_fusion import OperatorFusionPass
from sagellm_backend.graph.passes.static_precompute import StaticPatternPrecomputePass

__all__ = [
    "ConstantFoldingPass",
    "CUDAHardwareOptimizationPass",
    "DataFormatSelectionPass",
    "DeadNodeEliminationPass",
    "IdentityEliminationPass",
    "LayoutConversionPass",
    "MemoryReuseAnalysisPass",
    "OperatorFusionPass",
    "StaticPatternPrecomputePass",
]
