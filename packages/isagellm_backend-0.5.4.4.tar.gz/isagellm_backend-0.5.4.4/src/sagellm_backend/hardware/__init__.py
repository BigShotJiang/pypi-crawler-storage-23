"""Hardware detection framework for sageLLM.

This module provides a structured approach to hardware detection across
multiple abstraction layers (L0-L3), enabling robust hardware-aware
ML workload scheduling.

Public API:
    - DetectionLevel: Enumeration of detection abstraction layers
    - HardwareProfile: Complete hardware detection result
    - LayerResult: Single-layer detection result
    - ProfileCache: Persistent caching of detection results
    - HardwareInspector: Abstract base class for hardware-specific inspectors

Example:
    ```python
    from sagellm_backend.hardware import (
        HardwareInspector,
        ProfileCache,
        DetectionLevel,
    )

    # Implement custom inspector
    class CUDAInspector(HardwareInspector):
        @property
        def hardware_type(self) -> str:
            return "cuda"

        def inspect_l0_physical(self) -> LayerResult:
            # Detection logic...
            pass

    # Run detection and cache results
    inspector = CUDAInspector()
    profile = inspector.get_profile(include_functional=True)

    cache = ProfileCache()
    cache.update("cuda", profile)

    # Later, retrieve from cache
    cached_profile = cache.get("cuda")
    if cached_profile and cached_profile.is_usable():
        print(f"CUDA available with {cached_profile.device_count} devices")
    ```
"""

from sagellm_backend.hardware.base import HardwareInspector
from sagellm_backend.hardware.cache import ProfileCache
from sagellm_backend.hardware.profile import (
    DetectionLevel,
    HardwareProfile,
    LayerResult,
)

__all__ = [
    "DetectionLevel",
    "HardwareProfile",
    "LayerResult",
    "ProfileCache",
    "HardwareInspector",
]
