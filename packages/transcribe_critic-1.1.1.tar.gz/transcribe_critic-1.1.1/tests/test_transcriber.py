"""Tests for transcriber.py — merge orchestration, cost estimation, and CLI logic."""

import re
import time
from unittest.mock import MagicMock, patch

import pytest

from transcribe_critic.shared import SpeechConfig, SpeechData, is_up_to_date
from transcribe_critic.merge import _format_structured_segments
from transcribe_critic.download import clean_vtt_captions
from transcribe_critic.output import generate_markdown
from transcribe_critic.transcriber import (
    _fetch_metadata,
    _hydrate_data,
    _load_external_transcript,
    _should_run_step,
    _slugify_title,
    _strip_structured_headers,
    analyze_source_survival,
    estimate_api_cost,
    merge_transcript_sources,
    print_cost_estimate,
)


# ---------------------------------------------------------------------------
# _slugify_title
# ---------------------------------------------------------------------------

class TestSlugifyTitle:
    def test_basic(self):
        assert _slugify_title("Hello World") == "hello-world"

    def test_strips_special_chars(self):
        assert _slugify_title("Anthropic's Chief on A.I.: 'We Don't Know'") == "anthropics-chief-on-ai-we-dont-know"

    def test_truncates_long_titles(self):
        result = _slugify_title("A" * 100)
        assert len(result) <= 50

    def test_empty_title(self):
        assert _slugify_title("") == ""

    def test_preserves_hyphens(self):
        assert _slugify_title("two-part title") == "two-part-title"


# ---------------------------------------------------------------------------
# _strip_structured_headers / roundtrip with _format_structured_segments
# ---------------------------------------------------------------------------

class TestStripStructuredHeaders:
    def test_strip_removes_headers_with_timestamp(self):
        text = "**Alice** (0:01:00)\n\nSome text.\n"
        stripped = _strip_structured_headers(text)
        assert "**Alice**" not in stripped
        assert "Some text." in stripped

    def test_strip_removes_headers_without_timestamp(self):
        text = "**Bob**\n\nHi.\n"
        stripped = _strip_structured_headers(text)
        assert "**Bob**" not in stripped
        assert "Hi." in stripped

    def test_strip_preserves_inline_bold(self):
        text = "This has **bold** in the middle.\n"
        stripped = _strip_structured_headers(text)
        assert "**bold**" in stripped

    def test_roundtrip(self):
        segs = [
            {"speaker": "Alice", "timestamp": "0:01:00", "text": "First."},
            {"speaker": "Bob", "timestamp": "0:02:00", "text": "Second."},
        ]
        formatted = _format_structured_segments(segs)
        stripped = _strip_structured_headers(formatted)
        assert "**Alice**" not in stripped
        assert "First." in stripped
        assert "Second." in stripped


# ---------------------------------------------------------------------------
# DAG integration: stage skip/run decisions
# ---------------------------------------------------------------------------

def _make_test_artefacts(tmp_path):
    """Create a minimal set of artefacts for testing stage skip/run logic."""
    whisper = tmp_path / "whisper_merged.txt"
    whisper.write_text("whisper transcript words " * 200)
    captions_vtt = tmp_path / "captions.en.vtt"
    captions_vtt.write_text(
        "WEBVTT\n\n"
        "00:00:01.000 --> 00:00:05.000\n"
        "caption transcript words " * 50 + "\n"
    )
    config = SpeechConfig(
        url="https://example.com/video",
        output_dir=tmp_path,
        skip_existing=True,
        merge_sources=True,
        no_llm=False,
        local=False,
        api_key="fake-key",
    )
    data = SpeechData(
        transcript_path=whisper,
        captions_path=captions_vtt,
    )
    return config, data


class TestDAGStageSkipping:
    """Test that pipeline stages correctly skip when artefacts are fresh."""

    def test_merge_skips_when_fresh(self, tmp_path, capsys):
        config, data = _make_test_artefacts(tmp_path)
        # Create a merged file newer than sources
        time.sleep(0.05)
        merged = tmp_path / "transcript_merged.txt"
        merged.write_text("already merged text")
        merge_transcript_sources(config, data)
        out = capsys.readouterr().out
        assert "Reusing: transcript_merged.txt" in out
        assert data.merged_transcript_path == merged

    def test_merge_runs_when_source_is_newer(self, tmp_path, capsys):
        config, data = _make_test_artefacts(tmp_path)
        merged = tmp_path / "transcript_merged.txt"
        merged.write_text("old merged text")
        time.sleep(0.05)
        # Touch a source to make merged stale
        data.transcript_path.write_text("updated whisper " * 200)
        # Will try to call API and fail — that's fine, we just want to see it didn't skip
        try:
            merge_transcript_sources(config, data)
        except Exception:
            pass
        out = capsys.readouterr().out
        assert "Reusing: transcript_merged.txt" not in out
        assert "Merging" in out

    def test_markdown_skips_when_fresh(self, tmp_path, capsys):
        config, data = _make_test_artefacts(tmp_path)
        merged = tmp_path / "transcript_merged.txt"
        merged.write_text("merged text for markdown")
        data.merged_transcript_path = merged
        time.sleep(0.05)
        md = tmp_path / "transcript.md"
        md.write_text("# existing markdown")
        generate_markdown(config, data)
        out = capsys.readouterr().out
        assert "Reusing: transcript.md" in out

    def test_markdown_regenerates_when_merged_is_newer(self, tmp_path, capsys):
        config, data = _make_test_artefacts(tmp_path)
        md = tmp_path / "transcript.md"
        md.write_text("# old markdown")
        time.sleep(0.05)
        merged = tmp_path / "transcript_merged.txt"
        merged.write_text("updated merged text")
        data.merged_transcript_path = merged
        generate_markdown(config, data)
        out = capsys.readouterr().out
        assert "Reusing: transcript.md" not in out
        assert "Markdown saved: transcript.md" in out

    def test_analysis_skips_when_fresh(self, tmp_path, capsys):
        config, data = _make_test_artefacts(tmp_path)
        merged = tmp_path / "transcript_merged.txt"
        merged.write_text("merged text")
        data.merged_transcript_path = merged
        time.sleep(0.05)
        analysis = tmp_path / "analysis.md"
        analysis.write_text("# existing analysis")
        analyze_source_survival(config, data)
        out = capsys.readouterr().out
        assert "Reusing: analysis.md" in out

    def test_analysis_runs_when_merged_is_newer(self, tmp_path, capsys):
        config, data = _make_test_artefacts(tmp_path)
        analysis = tmp_path / "analysis.md"
        analysis.write_text("# old analysis")
        time.sleep(0.05)
        merged = tmp_path / "transcript_merged.txt"
        merged.write_text("updated merged text " * 100)
        data.merged_transcript_path = merged
        analyze_source_survival(config, data)
        out = capsys.readouterr().out
        assert "analysis up to date" not in out

    def test_dry_run_skips_merge(self, tmp_path, capsys):
        config, data = _make_test_artefacts(tmp_path)
        config.dry_run = True
        merge_transcript_sources(config, data)
        out = capsys.readouterr().out
        assert "[dry-run] Would merge" in out

    def test_dry_run_analysis_when_no_merged(self, tmp_path, capsys):
        config, data = _make_test_artefacts(tmp_path)
        config.dry_run = True
        analyze_source_survival(config, data)
        out = capsys.readouterr().out
        assert "[dry-run] Would analyze" in out


# ---------------------------------------------------------------------------
# estimate_api_cost
# ---------------------------------------------------------------------------

class TestEstimateApiCost:
    def test_no_llm_returns_zero(self, tmp_path):
        config = SpeechConfig(url="x", output_dir=tmp_path, no_llm=True)
        costs = estimate_api_cost(config)
        assert costs["total"] == 0.0
        assert costs["details"] == []

    def test_merge_only(self, tmp_path):
        config = SpeechConfig(url="x", output_dir=tmp_path,
                              analyze_slides=False, whisper_models=["medium"])
        costs = estimate_api_cost(config, transcript_words=6000)
        assert costs["merge_sources"] > 0
        assert costs["analyze_slides"] == 0.0
        assert costs["ensemble_whisper"] == 0.0
        assert costs["total"] == costs["merge_sources"]
        assert len(costs["details"]) == 1

    def test_slides_only(self, tmp_path):
        config = SpeechConfig(url="x", output_dir=tmp_path,
                              analyze_slides=True, merge_sources=False,
                              whisper_models=["medium"])
        costs = estimate_api_cost(config, num_slides=10)
        assert costs["analyze_slides"] == pytest.approx(0.20)
        assert costs["merge_sources"] == 0.0
        assert costs["total"] == costs["analyze_slides"]

    def test_ensemble_requires_multiple_models(self, tmp_path):
        config = SpeechConfig(url="x", output_dir=tmp_path,
                              merge_sources=False, whisper_models=["medium"])
        costs = estimate_api_cost(config)
        assert costs["ensemble_whisper"] == 0.0

        config2 = SpeechConfig(url="x", output_dir=tmp_path,
                               merge_sources=False,
                               whisper_models=["small", "medium"])
        costs2 = estimate_api_cost(config2)
        assert costs2["ensemble_whisper"] > 0

    def test_external_transcript_adds_source(self, tmp_path):
        config2 = SpeechConfig(url="x", output_dir=tmp_path,
                               whisper_models=["medium"])
        config3 = SpeechConfig(url="x", output_dir=tmp_path,
                               whisper_models=["medium"],
                               external_transcript="http://example.com")
        cost2 = estimate_api_cost(config2, transcript_words=10000)
        cost3 = estimate_api_cost(config3, transcript_words=10000)
        # 3 sources should cost more than 2
        assert cost3["merge_sources"] > cost2["merge_sources"]

    def test_total_is_sum_of_parts(self, tmp_path):
        config = SpeechConfig(url="x", output_dir=tmp_path,
                              analyze_slides=True,
                              whisper_models=["small", "medium"])
        costs = estimate_api_cost(config, num_slides=20, transcript_words=5000)
        expected = costs["analyze_slides"] + costs["merge_sources"] + costs["ensemble_whisper"]
        assert costs["total"] == pytest.approx(expected)

    def test_opus_costs_more_than_sonnet(self, tmp_path):
        sonnet = SpeechConfig(url="x", output_dir=tmp_path,
                              claude_model="claude-sonnet-4-20250514",
                              whisper_models=["medium"])
        opus = SpeechConfig(url="x", output_dir=tmp_path,
                            claude_model="claude-opus-4-20250514",
                            whisper_models=["medium"])
        cost_s = estimate_api_cost(sonnet, transcript_words=5000)
        cost_o = estimate_api_cost(opus, transcript_words=5000)
        assert cost_o["merge_sources"] > cost_s["merge_sources"]

    def test_haiku_costs_less_than_sonnet(self, tmp_path):
        sonnet = SpeechConfig(url="x", output_dir=tmp_path,
                              claude_model="claude-sonnet-4-20250514",
                              whisper_models=["medium"])
        haiku = SpeechConfig(url="x", output_dir=tmp_path,
                             claude_model="claude-haiku-4-20250514",
                             whisper_models=["medium"])
        cost_s = estimate_api_cost(sonnet, transcript_words=5000)
        cost_h = estimate_api_cost(haiku, transcript_words=5000)
        assert cost_h["merge_sources"] < cost_s["merge_sources"]

    def test_unknown_model_uses_default_pricing(self, tmp_path):
        from transcribe_critic.transcriber import _get_model_pricing, DEFAULT_PRICING
        pricing = _get_model_pricing("some-unknown-model")
        assert pricing == DEFAULT_PRICING


# ---------------------------------------------------------------------------
# _load_external_transcript
# ---------------------------------------------------------------------------

class TestLoadExternalTranscript:
    def test_local_file_exists(self, tmp_path):
        f = tmp_path / "transcript.txt"
        f.write_text("  Hello world  ")
        config = SpeechConfig(url="x", output_dir=tmp_path,
                              external_transcript=str(f))
        text, label = _load_external_transcript(config)
        assert text == "Hello world"
        assert label == "transcript.txt"

    def test_local_file_missing(self, tmp_path):
        config = SpeechConfig(url="x", output_dir=tmp_path,
                              external_transcript=str(tmp_path / "nope.txt"))
        text, label = _load_external_transcript(config)
        assert text is None
        assert label == "nope.txt"

    @patch("urllib.request.urlopen")
    def test_url_plain_text(self, mock_urlopen, tmp_path):
        mock_response = MagicMock()
        mock_response.read.return_value = b"Plain transcript text"
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_response

        config = SpeechConfig(url="x", output_dir=tmp_path,
                              external_transcript="https://example.com/transcript.txt")
        text, label = _load_external_transcript(config)
        assert text == "Plain transcript text"
        assert label == "transcript.txt"

    @patch("transcribe_critic.transcriber._extract_text_from_html", return_value="Extracted text")
    @patch("urllib.request.urlopen")
    def test_url_html_calls_extract(self, mock_urlopen, mock_extract, tmp_path):
        mock_response = MagicMock()
        mock_response.read.return_value = b"<html><body>Some HTML</body></html>"
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_response

        config = SpeechConfig(url="x", output_dir=tmp_path,
                              external_transcript="https://example.com/page")
        text, label = _load_external_transcript(config)
        assert text == "Extracted text"
        mock_extract.assert_called_once()

    @patch("urllib.request.urlopen", side_effect=Exception("Connection refused"))
    def test_url_unreachable(self, mock_urlopen, tmp_path, capsys):
        config = SpeechConfig(url="x", output_dir=tmp_path,
                              external_transcript="https://example.com/bad")
        text, label = _load_external_transcript(config)
        assert text is None
        out = capsys.readouterr().out
        assert "Warning" in out

    @patch("urllib.request.urlopen")
    def test_url_source_label_from_path(self, mock_urlopen, tmp_path):
        mock_response = MagicMock()
        mock_response.read.return_value = b"text"
        mock_response.__enter__ = lambda s: s
        mock_response.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_response

        config = SpeechConfig(url="x", output_dir=tmp_path,
                              external_transcript="https://example.com/path/my_file.txt")
        _, label = _load_external_transcript(config)
        assert label == "my_file.txt"

    def test_local_source_label_is_filename(self, tmp_path):
        f = tmp_path / "my_notes.txt"
        f.write_text("notes")
        config = SpeechConfig(url="x", output_dir=tmp_path,
                              external_transcript=str(f))
        _, label = _load_external_transcript(config)
        assert label == "my_notes.txt"


# ---------------------------------------------------------------------------
# Dry-run end-to-end: full pipeline creates no files
# ---------------------------------------------------------------------------

class TestDryRunNoSideEffects:
    """Verify that dry-run mode follows the main code path but creates no files."""

    def test_full_pipeline_dry_run_creates_no_files(self, tmp_path, capsys):
        """Run all pipeline stages in dry-run mode and verify no files are created."""
        from transcribe_critic.download import download_media
        from transcribe_critic.transcription import transcribe_audio
        from transcribe_critic.slides import extract_slides, create_basic_slides_json
        from unittest.mock import patch, MagicMock
        import json

        # Mock yt-dlp to avoid network calls
        def mock_run_command(cmd, desc, verbose=False):
            if "--dump-json" in cmd:
                return MagicMock(stdout=json.dumps({
                    "title": "Test", "id": "t1", "duration": 60
                }))
            return MagicMock(stdout="", stderr="")

        config = SpeechConfig(url="https://example.com/v", output_dir=tmp_path,
                              dry_run=True, skip_existing=False)
        data = SpeechData()

        with patch("transcribe_critic.download.run_command", side_effect=mock_run_command):
            download_media(config, data)

        transcribe_audio(config, data)
        extract_slides(config, data)
        merge_transcript_sources(config, data)
        generate_markdown(config, data)
        analyze_source_survival(config, data)

        # Verify no files were created
        created_files = list(tmp_path.iterdir())
        assert created_files == [], f"Dry-run created files: {[f.name for f in created_files]}"

        # Verify all stages printed dry-run messages
        out = capsys.readouterr().out
        assert "[dry-run]" in out
        assert "Would download audio" in out
        assert "Would save metadata" in out


# ---------------------------------------------------------------------------
# Diarized skeleton merge routing
# ---------------------------------------------------------------------------

class TestDiarizedSkeletonRouting:
    """Test merge routing when diarized transcript provides structure."""

    def _make_diarized_artefacts(self, tmp_path, *, has_external=False, has_captions=False):
        """Create artefacts for diarized skeleton routing tests."""
        whisper = tmp_path / "whisper_merged.txt"
        whisper.write_text("Hello world this is a test transcript " * 30)

        diarized = tmp_path / "diarized.txt"
        diarized.write_text(
            "[0:00:00] Alice: Hello world this is a test transcript.\n"
            "[0:01:00] Bob: And here is more content for testing.\n"
        )

        config = SpeechConfig(
            url="https://example.com/video",
            output_dir=tmp_path,
            skip_existing=False,
            merge_sources=True,
            no_llm=False,
            local=False,
            api_key="fake-key",
            diarize=True,
        )
        data = SpeechData(
            transcript_path=whisper,
            diarization_path=diarized,
        )

        if has_captions:
            captions_vtt = tmp_path / "captions.en.vtt"
            captions_vtt.write_text(
                "WEBVTT\n\n"
                "00:00:01.000 --> 00:00:05.000\n"
                "Hello world this is a test transcript\n"
            )
            data.captions_path = captions_vtt

        if has_external:
            config.external_transcript = str(tmp_path / "external.txt")
            ext = tmp_path / "external.txt"
            ext.write_text(
                "Alice (0:00:00) Hello world this is a test transcript.\n"
                "Bob (0:01:00) And here is more content for testing.\n"
            )

        return config, data

    def test_diarized_only_whisper_skips_merge(self, tmp_path, capsys):
        """Diarized skeleton + only Whisper → uses diarized text directly."""
        config, data = self._make_diarized_artefacts(tmp_path)
        merge_transcript_sources(config, data)
        out = capsys.readouterr().out
        assert "Single source with diarized skeleton" in out
        assert data.merged_transcript_path is not None
        content = data.merged_transcript_path.read_text()
        assert "[0:00:00] Alice:" in content

    @patch("transcribe_critic.transcriber._merge_structured")
    def test_diarized_with_captions_calls_structured_merge(self, mock_merge, tmp_path, capsys):
        """Diarized skeleton + Whisper + captions → structured merge with 'Diarized Transcript'."""
        config, data = self._make_diarized_artefacts(tmp_path, has_captions=True)

        mock_merge.return_value = [
            {"speaker": "Alice", "timestamp": "0:00:00", "text": "Merged text one."},
            {"speaker": "Bob", "timestamp": "0:01:00", "text": "Merged text two."},
        ]

        merge_transcript_sources(config, data)

        mock_merge.assert_called_once()
        call_kwargs = mock_merge.call_args
        assert call_kwargs[1]["skeleton_source_name"] == "Diarized Transcript"

    @patch("transcribe_critic.transcriber._merge_structured")
    def test_external_takes_priority_over_diarized(self, mock_merge, tmp_path, capsys):
        """External transcript provides skeleton even when diarized exists."""
        config, data = self._make_diarized_artefacts(tmp_path, has_external=True)

        mock_merge.return_value = [
            {"speaker": "Alice", "timestamp": "0:00:00", "text": "From external."},
            {"speaker": "Bob", "timestamp": "0:01:00", "text": "Also from external."},
        ]

        merge_transcript_sources(config, data)

        mock_merge.assert_called_once()
        call_kwargs = mock_merge.call_args
        assert call_kwargs[1]["skeleton_source_name"] == "External Transcript"
        out = capsys.readouterr().out
        assert "external transcript provides structure" in out


# ---------------------------------------------------------------------------
# _should_run_step
# ---------------------------------------------------------------------------

class TestShouldRunStep:
    def test_no_steps_filter_runs_all(self, tmp_path):
        config = SpeechConfig(url="x", output_dir=tmp_path, steps=None)
        assert _should_run_step("download", config) is True
        assert _should_run_step("merge", config) is True
        assert _should_run_step("transcribe", config) is True

    def test_steps_filter_allows_listed(self, tmp_path):
        config = SpeechConfig(url="x", output_dir=tmp_path, steps=["merge", "markdown"])
        assert _should_run_step("merge", config) is True
        assert _should_run_step("markdown", config) is True

    def test_steps_filter_blocks_unlisted(self, tmp_path):
        config = SpeechConfig(url="x", output_dir=tmp_path, steps=["merge"])
        assert _should_run_step("download", config) is False
        assert _should_run_step("transcribe", config) is False
        assert _should_run_step("slides", config) is False

    def test_single_step(self, tmp_path):
        config = SpeechConfig(url="x", output_dir=tmp_path, steps=["transcribe"])
        assert _should_run_step("transcribe", config) is True
        assert _should_run_step("merge", config) is False


# ---------------------------------------------------------------------------
# _hydrate_data
# ---------------------------------------------------------------------------

class TestHydrateData:
    def test_finds_audio_mp3(self, tmp_path):
        (tmp_path / "audio.mp3").write_bytes(b"fake")
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        assert data.audio_path == tmp_path / "audio.mp3"

    def test_finds_audio_wav(self, tmp_path):
        (tmp_path / "audio.wav").write_bytes(b"fake")
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        assert data.audio_path == tmp_path / "audio.wav"

    def test_prefers_mp3_over_wav(self, tmp_path):
        (tmp_path / "audio.mp3").write_bytes(b"fake")
        (tmp_path / "audio.wav").write_bytes(b"fake")
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        assert data.audio_path == tmp_path / "audio.mp3"

    def test_finds_whisper_transcripts(self, tmp_path):
        (tmp_path / "whisper_small.txt").write_text("small text")
        (tmp_path / "whisper_small.json").write_text("{}")
        (tmp_path / "whisper_medium.txt").write_text("medium text")
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        assert "small" in data.whisper_transcripts
        assert "medium" in data.whisper_transcripts
        assert data.whisper_transcripts["small"]["txt"] == tmp_path / "whisper_small.txt"
        assert data.whisper_transcripts["small"]["json"] == tmp_path / "whisper_small.json"
        assert data.whisper_transcripts["medium"]["json"] is None

    def test_ignores_whisper_merged(self, tmp_path):
        (tmp_path / "whisper_merged.txt").write_text("merged text")
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        assert "merged" not in data.whisper_transcripts

    def test_ignores_whisper_merged_variants(self, tmp_path):
        """Backup files like whisper_merged_7b.txt should not be treated as model transcripts."""
        (tmp_path / "whisper_small.txt").write_text("small text")
        (tmp_path / "whisper_medium.txt").write_text("medium text")
        (tmp_path / "whisper_merged.txt").write_text("merged text")
        (tmp_path / "whisper_merged_7b.txt").write_text("old merged")
        (tmp_path / "whisper_merged_14b_buggy.txt").write_text("bad merged")
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        assert sorted(data.whisper_transcripts.keys()) == ["medium", "small"]

    def test_finds_whisper_merged_as_transcript(self, tmp_path):
        (tmp_path / "whisper_merged.txt").write_text("merged text")
        (tmp_path / "whisper_small.txt").write_text("small text")
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        assert data.transcript_path == tmp_path / "whisper_merged.txt"

    def test_falls_back_to_largest_model(self, tmp_path):
        (tmp_path / "whisper_small.txt").write_text("small text")
        (tmp_path / "whisper_medium.txt").write_text("medium text")
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        # medium is larger than small, so it becomes transcript_path
        assert data.transcript_path == tmp_path / "whisper_medium.txt"

    def test_finds_captions(self, tmp_path):
        (tmp_path / "captions.en.vtt").write_text("WEBVTT\n")
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        assert data.captions_path == tmp_path / "captions.en.vtt"

    def test_finds_diarization(self, tmp_path):
        (tmp_path / "diarized.txt").write_text("[0:00:00] Speaker: Hello")
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        assert data.diarization_path == tmp_path / "diarized.txt"

    def test_finds_merged_transcript(self, tmp_path):
        (tmp_path / "transcript_merged.txt").write_text("merged")
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        assert data.merged_transcript_path == tmp_path / "transcript_merged.txt"

    def test_empty_dir(self, tmp_path):
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        _hydrate_data(config, data)
        assert data.audio_path is None
        assert data.transcript_path is None
        assert data.whisper_transcripts == {}


# ---------------------------------------------------------------------------
# merge_transcript_sources — edge cases
# ---------------------------------------------------------------------------

class TestMergeTranscriptSourcesEdges:
    def test_skips_when_no_merge_flag(self, tmp_path, capsys):
        config = SpeechConfig(url="x", output_dir=tmp_path, merge_sources=False)
        data = SpeechData()
        merge_transcript_sources(config, data)
        out = capsys.readouterr().out
        assert "--no-merge" in out

    def test_skips_when_no_llm(self, tmp_path, capsys):
        config = SpeechConfig(url="x", output_dir=tmp_path, no_llm=True)
        data = SpeechData()
        merge_transcript_sources(config, data)
        out = capsys.readouterr().out
        assert "--no-llm" in out

    def test_skips_no_whisper_no_external(self, tmp_path, capsys):
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        merge_transcript_sources(config, data)
        out = capsys.readouterr().out
        assert "No Whisper transcript" in out

    def test_skips_single_source_no_diarized(self, tmp_path, capsys):
        """Only whisper, no captions/external/diarized → need at least 2 sources."""
        whisper = tmp_path / "whisper_merged.txt"
        whisper.write_text("hello world " * 50)
        config = SpeechConfig(url="x", output_dir=tmp_path, skip_existing=False)
        data = SpeechData(transcript_path=whisper)
        merge_transcript_sources(config, data)
        out = capsys.readouterr().out
        assert "No YouTube captions" in out

    @patch("transcribe_critic.transcriber._merge_multi_source", return_value="merged result text")
    def test_flat_merge_calls_multi_source(self, mock_merge, tmp_path, capsys):
        """Whisper + captions (no structure) → flat merge via _merge_multi_source."""
        whisper = tmp_path / "whisper_merged.txt"
        whisper.write_text("hello world test transcript " * 50)
        captions = tmp_path / "captions.en.vtt"
        captions.write_text("WEBVTT\n\n00:00:01.000 --> 00:00:05.000\nhello world\n")
        config = SpeechConfig(url="x", output_dir=tmp_path, skip_existing=False,
                              local=False, api_key="fake")
        data = SpeechData(transcript_path=whisper, captions_path=captions)
        merge_transcript_sources(config, data)
        mock_merge.assert_called_once()
        assert data.merged_transcript_path is not None


# ---------------------------------------------------------------------------
# analyze_source_survival
# ---------------------------------------------------------------------------

class TestAnalyzeSourceSurvival:
    def test_no_merged_transcript_skips(self, tmp_path, capsys):
        config = SpeechConfig(url="x", output_dir=tmp_path)
        data = SpeechData()
        analyze_source_survival(config, data)
        out = capsys.readouterr().out
        assert "No merged transcript" in out

    def test_no_sources_skips(self, tmp_path, capsys):
        merged = tmp_path / "transcript_merged.txt"
        merged.write_text("merged text here")
        config = SpeechConfig(url="x", output_dir=tmp_path, skip_existing=False)
        data = SpeechData()
        analyze_source_survival(config, data)
        out = capsys.readouterr().out
        assert "No source transcripts" in out

    def test_writes_analysis_md(self, tmp_path, capsys):
        """With whisper + captions + merged → writes analysis.md with table."""
        whisper = tmp_path / "whisper_merged.txt"
        whisper.write_text("the quick brown fox jumps over the lazy dog")
        captions = tmp_path / "captions.en.vtt"
        captions.write_text(
            "WEBVTT\n\n00:00:01.000 --> 00:00:05.000\n"
            "the quick brown fox jumps over the lazy dog\n"
        )
        merged = tmp_path / "transcript_merged.txt"
        merged.write_text("the quick brown fox jumps over the lazy dog")
        config = SpeechConfig(url="x", output_dir=tmp_path, skip_existing=False)
        data = SpeechData(
            transcript_path=whisper,
            captions_path=captions,
            merged_transcript_path=merged,
        )
        analyze_source_survival(config, data)
        analysis = tmp_path / "analysis.md"
        assert analysis.exists()
        content = analysis.read_text()
        assert "Source Survival Analysis" in content
        assert "Whisper" in content

    def test_finds_most_similar(self, tmp_path, capsys):
        whisper = tmp_path / "whisper_merged.txt"
        whisper.write_text("the quick brown fox jumps over the lazy dog")
        merged = tmp_path / "transcript_merged.txt"
        merged.write_text("the quick brown fox jumps over the lazy dog")
        config = SpeechConfig(url="x", output_dir=tmp_path, skip_existing=False)
        data = SpeechData(
            transcript_path=whisper,
            merged_transcript_path=merged,
        )
        analyze_source_survival(config, data)
        out = capsys.readouterr().out
        assert "most closely resembles" in out


# ---------------------------------------------------------------------------
# print_cost_estimate
# ---------------------------------------------------------------------------

class TestPrintCostEstimate:
    def test_zero_cost_prints_nothing(self, tmp_path, capsys):
        config = SpeechConfig(url="x", output_dir=tmp_path, no_llm=True)
        print_cost_estimate(config)
        out = capsys.readouterr().out
        assert "ESTIMATED" not in out

    def test_nonzero_prints_table(self, tmp_path, capsys):
        config = SpeechConfig(url="x", output_dir=tmp_path,
                              analyze_slides=True, whisper_models=["medium"])
        print_cost_estimate(config, num_slides=10, transcript_words=5000)
        out = capsys.readouterr().out
        assert "ESTIMATED API COSTS" in out
        assert "TOTAL" in out


# ---------------------------------------------------------------------------
# _fetch_metadata
# ---------------------------------------------------------------------------

class TestFetchMetadata:
    @patch("transcribe_critic.shared.subprocess.run")
    def test_returns_parsed_json(self, mock_run):
        import json
        mock_run.return_value = MagicMock(
            stdout=json.dumps({"title": "Test Video", "id": "abc"}),
            returncode=0,
        )
        result = _fetch_metadata("https://example.com/v")
        assert result["title"] == "Test Video"

    @patch("transcribe_critic.shared.subprocess.run",
           side_effect=Exception("not found"))
    def test_propagates_error(self, mock_run):
        with pytest.raises(Exception, match="not found"):
            _fetch_metadata("https://example.com/bad")


# ---------------------------------------------------------------------------
# main() CLI validation
# ---------------------------------------------------------------------------

class TestMainCLI:
    def test_missing_url_exits(self):
        """No positional arg → SystemExit."""
        import sys
        from transcribe_critic.transcriber import main
        with patch.object(sys, "argv", ["transcribe-critic"]):
            with pytest.raises(SystemExit):
                main()

    def test_invalid_model_exits(self):
        import sys
        from transcribe_critic.transcriber import main
        with patch.object(sys, "argv",
                          ["transcribe-critic", "https://example.com/v",
                           "--whisper-models", "bogus"]):
            with pytest.raises(SystemExit):
                main()

    @patch.dict("os.environ", {}, clear=True)
    def test_api_no_key_exits(self):
        import sys
        from transcribe_critic.transcriber import main
        with patch.object(sys, "argv",
                          ["transcribe-critic", "https://example.com/v", "--api"]):
            # Remove ANTHROPIC_API_KEY if set
            with patch.dict("os.environ", {"ANTHROPIC_API_KEY": ""}, clear=False):
                with pytest.raises(SystemExit):
                    main()
