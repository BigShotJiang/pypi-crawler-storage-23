"""Core shared utilities."""
