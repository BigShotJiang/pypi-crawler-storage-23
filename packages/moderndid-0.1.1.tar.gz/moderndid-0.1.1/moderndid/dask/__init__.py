"""Dask distributed backend for moderndid estimators."""
