"""PySpark distributed backend for moderndid estimators."""
