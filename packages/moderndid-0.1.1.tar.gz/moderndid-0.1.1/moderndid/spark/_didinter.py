"""Entry point for distributed intertemporal DiD estimation via Spark."""

from __future__ import annotations

import logging

import polars as pl

from ._utils import get_or_create_spark, validate_spark_input


def spark_did_multiplegt(
    data,
    yname,
    tname,
    idname,
    dname,
    spark=None,
    cluster=None,
    weightsname=None,
    xformla="~1",
    effects=1,
    placebo=0,
    normalized=False,
    effects_equal=False,
    predict_het=None,
    switchers="",
    only_never_switchers=False,
    same_switchers=False,
    same_switchers_pl=False,
    trends_lin=False,
    trends_nonparam=None,
    continuous=0,
    ci_level=95.0,
    less_conservative_se=False,
    keep_bidirectional_switchers=False,
    drop_missing_preswitch=False,
    boot=False,
    biters=1000,
    random_state=None,
    n_partitions=None,
):
    r"""Compute distributed intertemporal treatment effects via Spark.

    Distributed implementation of the intertemporal DiD estimator from [1]_
    for datasets that exceed single-machine memory. This function accepts a
    Spark DataFrame, collects it to the driver, and runs the full estimation
    pipeline.

    Parameters
    ----------
    data : pyspark.sql.DataFrame
        Data in long format as a Spark DataFrame.
    yname : str
        Name of the outcome variable.
    tname : str
        Name of the time period variable.
    idname : str
        Name of the unit identifier variable.
    dname : str
        Name of the treatment variable.
    spark : pyspark.sql.SparkSession, optional
        Spark session. If None, an active session is used or created.
    cluster : str, optional
        Cluster variable for standard errors.
    effects : int, default=1
        Number of post-treatment horizons.
    placebo : int, default=0
        Number of pre-treatment placebo horizons.
    normalized : bool, default=False
        If True, normalize by cumulative treatment change.
    boot : bool, default=False
        Whether to use bootstrap inference.
    biters : int, default=1000
        Number of bootstrap iterations.
    random_state : int, optional
        Random seed.
    n_partitions : int, optional
        Not used for didinter (reserved for API consistency).

    Returns
    -------
    DIDInterResult
        Treatment effect results.

    See Also
    --------
    did_multiplegt : Local (non-distributed) intertemporal DiD estimator.

    References
    ----------

    .. [1] de Chaisemartin, C., & D'Haultfoeuille, X. (2024). Difference-in-
           Differences Estimators of Intertemporal Treatment Effects.
           *Review of Economics and Statistics*, 106(6), 1723-1736.
           https://doi.org/10.1162/rest_a_01414
    """
    spark = get_or_create_spark(spark)
    logging.getLogger("py4j").setLevel(logging.ERROR)

    from pyspark.sql import DataFrame as SparkDataFrame

    is_spark = isinstance(data, SparkDataFrame)

    if not is_spark:
        if isinstance(data, pl.DataFrame):
            pdf = data.to_pandas()
            sdf = spark.createDataFrame(pdf)
        else:
            sdf = spark.createDataFrame(data)
    else:
        sdf = data

    required_cols = [yname, tname, idname, dname]
    if cluster is not None:
        required_cols.append(cluster)
    if weightsname is not None:
        required_cols.append(weightsname)
    validate_spark_input(sdf, required_cols)

    from ._didinter_mp import spark_did_multiplegt_mp

    return spark_did_multiplegt_mp(
        spark=spark,
        data=sdf,
        yname=yname,
        tname=tname,
        idname=idname,
        dname=dname,
        cluster=cluster,
        weightsname=weightsname,
        xformla=xformla,
        effects=effects,
        placebo=placebo,
        normalized=normalized,
        effects_equal=effects_equal,
        predict_het=predict_het,
        switchers=switchers,
        only_never_switchers=only_never_switchers,
        same_switchers=same_switchers,
        same_switchers_pl=same_switchers_pl,
        trends_lin=trends_lin,
        trends_nonparam=trends_nonparam,
        continuous=continuous,
        ci_level=ci_level,
        less_conservative_se=less_conservative_se,
        keep_bidirectional_switchers=keep_bidirectional_switchers,
        drop_missing_preswitch=drop_missing_preswitch,
        boot=boot,
        biters=biters,
        random_state=random_state,
    )
