"""Plotting functions for sensitivity analysis."""

from moderndid.didhonest.plots.core import plot_sensitivity

__all__ = [
    "plot_sensitivity",
]
