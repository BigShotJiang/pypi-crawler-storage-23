"""Two-stage difference-in-differences."""
