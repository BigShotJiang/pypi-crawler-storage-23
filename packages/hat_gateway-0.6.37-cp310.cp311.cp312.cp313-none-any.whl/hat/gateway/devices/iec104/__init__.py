"""IEC 60870-5-104 devices"""
