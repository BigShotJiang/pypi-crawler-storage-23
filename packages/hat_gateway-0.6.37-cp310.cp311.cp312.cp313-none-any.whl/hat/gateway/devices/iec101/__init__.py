"""IEC 60870-5-101 devices"""
