"""SNMP devices"""
