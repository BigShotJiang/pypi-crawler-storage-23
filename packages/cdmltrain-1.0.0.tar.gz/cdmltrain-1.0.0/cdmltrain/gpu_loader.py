"""
CDML Tier 3: GPU Direct Loader
Transfers decompressed data directly to GPU VRAM using PyTorch pinned memory
and async CUDA transfers, bypassing the normal CPU copy overhead.

Architecture:
  ZIP/ZSTD → C++ Engine → CPU Pinned Memory → CUDA Async Transfer → GPU VRAM

Fallback: If no CUDA GPU is detected, runs entirely on CPU (no errors).

Requirements:
 - torch (with CUDA support for GPU acceleration)
 - NVIDIA GPU with CUDA-enabled drivers
"""

import torch
import threading
import io
import time


class GPUDirectLoader:
    """
    High-performance data loader that transfers compressed archive data
    directly to GPU VRAM using CUDA pinned memory.
    
    Features:
    - Async prefetch: loads next batch while GPU trains on current batch
    - Pinned memory: enables zero-copy DMA transfers to GPU
    - Graceful fallback: works on CPU-only machines without errors
    """

    def __init__(self, dataset, batch_size: int = 32, device: str = "auto"):
        """
        Args:
            dataset: A CDMLStreamDataset or ZSTDStreamEngine backed dataset
            batch_size (int): Number of items per batch
            device (str): "cuda", "cpu", or "auto" (auto-detects GPU)
        """
        self.dataset = dataset
        self.batch_size = batch_size

        # Auto-detect device
        if device == "auto":
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = torch.device(device)

        self.has_gpu = self.device.type == "cuda"
        self._prefetch_buffer = None
        self._prefetch_thread = None
        self._lock = threading.Lock()

        if self.has_gpu:
            gpu_name = torch.cuda.get_device_name(0)
            gpu_mem_gb = torch.cuda.get_device_properties(0).total_memory / 1e9
            print(f"[GPU Direct] CUDA GPU detected: {gpu_name} ({gpu_mem_gb:.1f} GB VRAM)")
            print(f"[GPU Direct] Using CUDA pinned memory + async transfers ⚡")
        else:
            print(f"[GPU Direct] No CUDA GPU found. Running on CPU.")
            print(f"[GPU Direct] (Install CUDA + nvidia drivers to unlock GPU acceleration)")

    def _bytes_to_tensor(self, raw_bytes: bytes) -> torch.Tensor:
        """Convert raw bytes to a uint8 tensor."""
        arr = torch.frombuffer(bytearray(raw_bytes), dtype=torch.uint8)
        return arr

    def _load_batch_to_pinned(self, indices):
        """
        Loads a batch of items into CPU pinned memory so CUDA can DMA-transfer
        them to GPU VRAM without an extra CPU copy step.
        """
        tensors = []
        for idx in indices:
            try:
                raw = self.dataset[idx]
                if isinstance(raw, bytes):
                    t = self._bytes_to_tensor(raw)
                elif isinstance(raw, torch.Tensor):
                    t = raw
                else:
                    import numpy as np
                    # Handle PIL Images
                    if hasattr(raw, 'convert'): 
                        t = torch.from_numpy(np.array(raw))
                    else:
                        t = torch.tensor(list(raw), dtype=torch.uint8)
                tensors.append(t)
            except Exception:
                pass # skip invalid files/folders

        if not tensors:
            return None

        # Pad tensors to same length for stacking (only needed for raw bytes, images are usually same size)
        max_len = max(t.shape[0] if len(t.shape) == 1 else 0 for t in tensors)
        if max_len > 0:
            padded = [torch.nn.functional.pad(t, (0, max_len - t.shape[0])) for t in tensors]
            batch = torch.stack(padded)
        else:
            batch = torch.stack(tensors)

        if self.has_gpu:
            # Pin memory — allows async DMA to GPU VRAM
            batch = batch.pin_memory()

        return batch

    def load_batch_to_gpu(self, indices) -> torch.Tensor:
        """
        Main entry point. Loads a batch and transfers it to GPU (or CPU).
        
        Returns:
            torch.Tensor on self.device (CUDA VRAM or CPU RAM)
        """
        batch = self._load_batch_to_pinned(indices)

        if self.has_gpu:
            # non_blocking=True means CPU doesn't wait for GPU copy to finish
            # This allows CPU to start fetching next batch immediately!
            batch = batch.to(self.device, non_blocking=True)

        return batch

    def prefetch_next_batch(self, next_indices):
        """
        Async prefetch: starts loading the NEXT batch in background
        while the GPU is still training on the CURRENT batch.
        """
        def _worker():
            with self._lock:
                self._prefetch_buffer = self._load_batch_to_pinned(next_indices)

        self._prefetch_thread = threading.Thread(target=_worker, daemon=True)
        self._prefetch_thread.start()

    def get_prefetched(self) -> torch.Tensor:
        """Returns the previously prefetched batch (blocks until ready)."""
        if self._prefetch_thread:
            self._prefetch_thread.join()
        
        with self._lock:
            batch = self._prefetch_buffer
            self._prefetch_buffer = None

        if batch is not None and self.has_gpu:
            batch = batch.to(self.device, non_blocking=True)

        return batch

    def __iter__(self):
        """Makes GPUDirectLoader iterable — yields batches to training loop."""
        n = len(self.dataset)
        all_indices = list(range(n))

        for start in range(0, n, self.batch_size):
            indices = all_indices[start:start + self.batch_size]
            batch = self.load_batch_to_gpu(indices)
            yield batch

    def benchmark(self, num_batches: int = 5):
        """Quick benchmark to measure batch loading speed."""
        print(f"\n[GPU Direct] Benchmark: {num_batches} batches of {self.batch_size} items")
        times = []

        for i, batch in enumerate(self):
            if i == 0:
                start = time.perf_counter()
            if i >= num_batches:
                break
            elapsed = time.perf_counter() - start
            times.append(elapsed)
            print(f"  Batch {i+1}: shape={batch.shape}, device={batch.device}, time={elapsed:.4f}s")
            start = time.perf_counter()

        avg = sum(times) / len(times) if times else 0
        print(f"\n  Avg batch load time: {avg:.4f}s")
        throughput = self.batch_size / avg if avg > 0 else float('inf')
        print(f"  Throughput: ~{throughput:.0f} items/sec on {self.device}")
