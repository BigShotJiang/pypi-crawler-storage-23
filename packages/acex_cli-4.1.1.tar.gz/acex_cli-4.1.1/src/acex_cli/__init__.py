"""ACE-X CLI - Command-line interface for ACE-X."""

__version__ = "0.2.0"
