"""Configuration loading for the Golomt Bank payment SDK."""

from __future__ import annotations

import os

from .types import GolomtConfig


def load_config_from_env() -> GolomtConfig:
    """Load Golomt Bank configuration from environment variables.

    Required environment variables:
        - ``GOLOMT_ENDPOINT``    -- Base URL of the Golomt Bank API
        - ``GOLOMT_SECRET``      -- HMAC-SHA256 secret key
        - ``GOLOMT_BEARER_TOKEN`` -- Bearer token for Authorization header

    Returns:
        A :class:`GolomtConfig` populated from the environment.

    Raises:
        ValueError: If any required variable is missing.
    """
    endpoint = os.environ.get("GOLOMT_ENDPOINT")
    secret = os.environ.get("GOLOMT_SECRET")
    bearer_token = os.environ.get("GOLOMT_BEARER_TOKEN")

    if not endpoint:
        raise ValueError("Missing environment variable: GOLOMT_ENDPOINT")
    if not secret:
        raise ValueError("Missing environment variable: GOLOMT_SECRET")
    if not bearer_token:
        raise ValueError("Missing environment variable: GOLOMT_BEARER_TOKEN")

    return GolomtConfig(
        endpoint=endpoint,
        secret=secret,
        bearer_token=bearer_token,
    )
