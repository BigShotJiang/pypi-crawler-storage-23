"""Golomt Bank ecommerce payment clients (sync and async)."""

from __future__ import annotations

import hashlib
import hmac
from typing import Any, Dict

import httpx

from .errors import GolomtError
from .types import (
    ByTokenResponse,
    CreateInvoiceInput,
    CreateInvoiceResponse,
    GolomtConfig,
    InquiryResponse,
    Lang,
    PaymentMethod,
)


class GolomtClient:
    """Synchronous Golomt Bank ecommerce payment client.

    Handles HMAC-SHA256 checksum generation, request formatting, and
    communication with the Golomt Bank API.

    Example::

        client = GolomtClient(GolomtConfig(
            endpoint="https://ecommerce.golomtbank.com",
            secret="your-hmac-secret",
            bearer_token="your-bearer-token",
        ))

        invoice = client.create_invoice(CreateInvoiceInput(
            amount=1000,
            transaction_id="txn-001",
            return_type="POST",
            callback="https://yoursite.com/callback",
            get_token=False,
            social_deeplink=False,
        ))
    """

    def __init__(self, config: GolomtConfig) -> None:
        self._config = config
        self._client = httpx.Client()

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "GolomtClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── Private helpers ──

    def _hmac(self, data: str) -> str:
        """Compute an HMAC-SHA256 hex digest.

        The data string is a direct concatenation of values with no separator,
        matching the Go SDK's ``AppendAsString`` behavior.
        """
        return hmac.new(
            self._config.secret.encode("utf-8"),
            data.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    def _format_amount(self, amount: float) -> str:
        """Format a number as a two-decimal-place string (e.g. 1000 -> '1000.00')."""
        return f"{amount:.2f}"

    def _post(self, path: str, body: Dict[str, Any]) -> Any:
        """Send a POST request to the Golomt Bank API."""
        url = f"{self._config.endpoint}{path}"

        response = self._client.post(
            url,
            json=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._config.bearer_token}",
            },
        )

        try:
            response_body = response.json()
        except Exception:
            raise GolomtError(
                f"Golomt API returned non-JSON response (HTTP {response.status_code})",
                response.status_code,
            )

        if response.status_code < 200 or response.status_code >= 300:
            msg = (
                str(response_body.get("message"))
                if isinstance(response_body, dict) and "message" in response_body
                else f"Golomt API error (HTTP {response.status_code})"
            )
            raise GolomtError(msg, response.status_code, response_body)

        return response_body

    # ── Public API ──

    def create_invoice(self, input: CreateInvoiceInput) -> CreateInvoiceResponse:
        """Create a payment invoice.

        Automatically computes the HMAC-SHA256 checksum from:
        ``transactionId + amount + returnType + callback``

        Converts boolean fields (``get_token``, ``social_deeplink``) to ``"Y"`` / ``"N"``.

        Args:
            input: Invoice creation parameters.

        Returns:
            The API response containing the invoice ID and metadata.
        """
        amount = self._format_amount(input.amount)
        checksum = self._hmac(
            input.transaction_id + amount + input.return_type + input.callback
        )

        body = {
            "amount": amount,
            "checksum": checksum,
            "transactionId": input.transaction_id,
            "returnType": input.return_type,
            "callback": input.callback,
            "genToken": "Y" if input.get_token else "N",
            "socialDeeplink": "Y" if input.social_deeplink else "N",
        }

        data = self._post("/api/invoice", body)
        return CreateInvoiceResponse(
            invoice=data.get("invoice", ""),
            checksum=data.get("checksum", ""),
            transaction_id=data.get("transactionId", ""),
            timestamp=data.get("timestamp", ""),
            status=data.get("status", 0),
            error=data.get("error", ""),
            message=data.get("message", ""),
            path=data.get("path", ""),
            social_deeplink=data.get("socialDeeplink", ""),
        )

    def inquiry(self, transaction_id: str) -> InquiryResponse:
        """Inquire about a transaction's status.

        Automatically computes the HMAC-SHA256 checksum from:
        ``transactionId + transactionId`` (same value concatenated twice).

        Args:
            transaction_id: The transaction to inquire about.

        Returns:
            The API response with transaction details.
        """
        checksum = self._hmac(transaction_id + transaction_id)

        body = {
            "checksum": checksum,
            "transactionId": transaction_id,
        }

        data = self._post("/api/inquiry", body)
        return InquiryResponse(
            amount=data.get("amount", ""),
            bank=data.get("bank", ""),
            status=data.get("status", ""),
            error_desc=data.get("errorDesc", ""),
            error_code=data.get("errorCode", ""),
            card_holder=data.get("cardHolder", ""),
            card_number=data.get("cardNumber", ""),
            transaction_id=data.get("transactionId", ""),
            token=data.get("token", ""),
        )

    def pay_by_token(
        self,
        amount: float,
        token: str,
        transaction_id: str,
        lang: str = Lang.MN,
    ) -> ByTokenResponse:
        """Pay using a previously generated token.

        Automatically computes the HMAC-SHA256 checksum from:
        ``amount + transactionId + token``

        Args:
            amount: Payment amount.
            token: Payment token from a prior invoice with ``get_token=True``.
            transaction_id: Unique transaction identifier.
            lang: Language code (defaults to ``"MN"``).

        Returns:
            The API response with payment result.
        """
        amount_str = self._format_amount(amount)
        checksum = self._hmac(amount_str + transaction_id + token)

        body = {
            "amount": amount_str,
            "invoice": "",
            "checksum": checksum,
            "transactionId": transaction_id,
            "token": token,
            "lang": lang,
        }

        data = self._post("/api/pay", body)
        return ByTokenResponse(
            amount=data.get("amount", ""),
            error_desc=data.get("errorDesc", ""),
            error_code=data.get("errorCode", ""),
            transaction_id=data.get("transactionId", ""),
            checksum=data.get("checksum", ""),
            card_number=data.get("cardNumber", ""),
        )

    def get_payment_url(
        self,
        invoice: str,
        lang: str = Lang.MN,
        payment_method: str = PaymentMethod.PAYMENT,
    ) -> str:
        """Build a payment URL for redirecting the user to the Golomt payment page.

        Args:
            invoice: Invoice identifier returned from :meth:`create_invoice`.
            lang: Language: ``"MN"`` (Mongolian) or ``"EN"`` (English). Defaults to ``"MN"``.
            payment_method: Payment method: ``"payment"`` (card) or ``"socialpay"``. Defaults to ``"payment"``.

        Returns:
            The full payment URL string.
        """
        return f"{self._config.endpoint}/{payment_method}/{lang}/{invoice}"


class AsyncGolomtClient:
    """Asynchronous Golomt Bank ecommerce payment client.

    Identical API to :class:`GolomtClient` but uses ``httpx.AsyncClient``
    and ``async/await``.

    Example::

        async with AsyncGolomtClient(GolomtConfig(
            endpoint="https://ecommerce.golomtbank.com",
            secret="your-hmac-secret",
            bearer_token="your-bearer-token",
        )) as client:
            invoice = await client.create_invoice(CreateInvoiceInput(
                amount=1000,
                transaction_id="txn-001",
                return_type="POST",
                callback="https://yoursite.com/callback",
                get_token=False,
                social_deeplink=False,
            ))
    """

    def __init__(self, config: GolomtConfig) -> None:
        self._config = config
        self._client = httpx.AsyncClient()

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncGolomtClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    # ── Private helpers ──

    def _hmac(self, data: str) -> str:
        """Compute an HMAC-SHA256 hex digest."""
        return hmac.new(
            self._config.secret.encode("utf-8"),
            data.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()

    def _format_amount(self, amount: float) -> str:
        """Format a number as a two-decimal-place string."""
        return f"{amount:.2f}"

    async def _post(self, path: str, body: Dict[str, Any]) -> Any:
        """Send a POST request to the Golomt Bank API."""
        url = f"{self._config.endpoint}{path}"

        response = await self._client.post(
            url,
            json=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self._config.bearer_token}",
            },
        )

        try:
            response_body = response.json()
        except Exception:
            raise GolomtError(
                f"Golomt API returned non-JSON response (HTTP {response.status_code})",
                response.status_code,
            )

        if response.status_code < 200 or response.status_code >= 300:
            msg = (
                str(response_body.get("message"))
                if isinstance(response_body, dict) and "message" in response_body
                else f"Golomt API error (HTTP {response.status_code})"
            )
            raise GolomtError(msg, response.status_code, response_body)

        return response_body

    # ── Public API ──

    async def create_invoice(
        self, input: CreateInvoiceInput
    ) -> CreateInvoiceResponse:
        """Create a payment invoice.

        See :meth:`GolomtClient.create_invoice` for full documentation.
        """
        amount = self._format_amount(input.amount)
        checksum = self._hmac(
            input.transaction_id + amount + input.return_type + input.callback
        )

        body = {
            "amount": amount,
            "checksum": checksum,
            "transactionId": input.transaction_id,
            "returnType": input.return_type,
            "callback": input.callback,
            "genToken": "Y" if input.get_token else "N",
            "socialDeeplink": "Y" if input.social_deeplink else "N",
        }

        data = await self._post("/api/invoice", body)
        return CreateInvoiceResponse(
            invoice=data.get("invoice", ""),
            checksum=data.get("checksum", ""),
            transaction_id=data.get("transactionId", ""),
            timestamp=data.get("timestamp", ""),
            status=data.get("status", 0),
            error=data.get("error", ""),
            message=data.get("message", ""),
            path=data.get("path", ""),
            social_deeplink=data.get("socialDeeplink", ""),
        )

    async def inquiry(self, transaction_id: str) -> InquiryResponse:
        """Inquire about a transaction's status.

        See :meth:`GolomtClient.inquiry` for full documentation.
        """
        checksum = self._hmac(transaction_id + transaction_id)

        body = {
            "checksum": checksum,
            "transactionId": transaction_id,
        }

        data = await self._post("/api/inquiry", body)
        return InquiryResponse(
            amount=data.get("amount", ""),
            bank=data.get("bank", ""),
            status=data.get("status", ""),
            error_desc=data.get("errorDesc", ""),
            error_code=data.get("errorCode", ""),
            card_holder=data.get("cardHolder", ""),
            card_number=data.get("cardNumber", ""),
            transaction_id=data.get("transactionId", ""),
            token=data.get("token", ""),
        )

    async def pay_by_token(
        self,
        amount: float,
        token: str,
        transaction_id: str,
        lang: str = Lang.MN,
    ) -> ByTokenResponse:
        """Pay using a previously generated token.

        See :meth:`GolomtClient.pay_by_token` for full documentation.
        """
        amount_str = self._format_amount(amount)
        checksum = self._hmac(amount_str + transaction_id + token)

        body = {
            "amount": amount_str,
            "invoice": "",
            "checksum": checksum,
            "transactionId": transaction_id,
            "token": token,
            "lang": lang,
        }

        data = await self._post("/api/pay", body)
        return ByTokenResponse(
            amount=data.get("amount", ""),
            error_desc=data.get("errorDesc", ""),
            error_code=data.get("errorCode", ""),
            transaction_id=data.get("transactionId", ""),
            checksum=data.get("checksum", ""),
            card_number=data.get("cardNumber", ""),
        )

    def get_payment_url(
        self,
        invoice: str,
        lang: str = Lang.MN,
        payment_method: str = PaymentMethod.PAYMENT,
    ) -> str:
        """Build a payment URL for redirecting the user to the Golomt payment page.

        See :meth:`GolomtClient.get_payment_url` for full documentation.
        """
        return f"{self._config.endpoint}/{payment_method}/{lang}/{invoice}"
