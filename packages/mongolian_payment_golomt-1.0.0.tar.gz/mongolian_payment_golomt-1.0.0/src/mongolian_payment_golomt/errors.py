"""Custom error classes for the Golomt Bank payment SDK."""

from __future__ import annotations

from typing import Any, Optional


class GolomtError(Exception):
    """Custom error for Golomt Bank API errors.

    Includes the HTTP status code and raw response body when available.

    Attributes:
        message: Human-readable error description.
        status_code: HTTP status code from the API response.
        response: Raw response body, if available.
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response

    def __repr__(self) -> str:
        return f"GolomtError({self.message!r}, status_code={self.status_code})"
