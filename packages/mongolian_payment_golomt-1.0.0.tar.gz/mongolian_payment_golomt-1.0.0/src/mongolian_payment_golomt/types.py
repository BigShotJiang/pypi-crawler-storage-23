"""Type definitions for the Golomt Bank payment SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


# ── Constants ──


class Lang:
    """Supported languages for payment URL."""

    MN = "MN"
    EN = "EN"


class PaymentMethod:
    """Payment method for URL builder."""

    PAYMENT = "payment"
    SOCIALPAY = "socialpay"


class ReturnType:
    """Return type for invoice callback."""

    POST = "POST"
    GET = "GET"
    MOBILE = "MOBILE"


# ── Configuration ──


@dataclass
class GolomtConfig:
    """Configuration for the GolomtClient.

    Attributes:
        endpoint: Base URL of the Golomt Bank API.
        secret: HMAC-SHA256 secret key for checksum generation.
        bearer_token: Bearer token for Authorization header.
    """

    endpoint: str
    secret: str
    bearer_token: str


# ── SDK Input Types ──


@dataclass
class CreateInvoiceInput:
    """Input for creating an invoice (SDK-facing).

    Attributes:
        amount: Payment amount.
        transaction_id: Unique transaction identifier.
        return_type: How the callback result is returned.
        callback: Callback URL for payment result.
        get_token: Whether to generate a reusable payment token.
        social_deeplink: Whether to generate a SocialPay deeplink.
    """

    amount: float
    transaction_id: str
    return_type: str
    callback: str
    get_token: bool
    social_deeplink: bool


# ── Response Types ──


@dataclass
class CreateInvoiceResponse:
    """Response from creating an invoice.

    Attributes:
        invoice: Generated invoice identifier.
        checksum: Server-computed checksum.
        transaction_id: Transaction identifier echoed back.
        timestamp: Server timestamp.
        status: HTTP-like status code.
        error: Error identifier (empty on success).
        message: Human-readable message.
        path: Request path.
        social_deeplink: SocialPay deeplink URL (if requested).
    """

    invoice: str
    checksum: str
    transaction_id: str
    timestamp: str
    status: int
    error: str
    message: str
    path: str
    social_deeplink: str


@dataclass
class InquiryResponse:
    """Response from a transaction inquiry.

    Attributes:
        amount: Transaction amount.
        bank: Bank name.
        status: Transaction status.
        error_desc: Error description (empty on success).
        error_code: Error code (empty on success).
        card_holder: Cardholder name.
        card_number: Masked card number.
        transaction_id: Transaction identifier.
        token: Payment token (if token was generated).
    """

    amount: str
    bank: str
    status: str
    error_desc: str
    error_code: str
    card_holder: str
    card_number: str
    transaction_id: str
    token: str


@dataclass
class ByTokenResponse:
    """Response from a pay-by-token request.

    Attributes:
        amount: Transaction amount.
        error_desc: Error description (empty on success).
        error_code: Error code (empty on success).
        transaction_id: Transaction identifier.
        checksum: Server-computed checksum.
        card_number: Masked card number.
    """

    amount: str
    error_desc: str
    error_code: str
    transaction_id: str
    checksum: str
    card_number: str
