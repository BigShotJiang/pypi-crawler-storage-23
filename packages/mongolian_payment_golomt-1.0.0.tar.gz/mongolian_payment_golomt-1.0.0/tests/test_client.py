"""Tests for the Golomt Bank payment SDK."""

from __future__ import annotations

import hashlib
import hmac as hmac_mod
from unittest.mock import patch

import httpx
import pytest
import pytest_asyncio

from mongolian_payment_golomt import (
    AsyncGolomtClient,
    CreateInvoiceInput,
    CreateInvoiceResponse,
    GolomtClient,
    GolomtConfig,
    GolomtError,
    InquiryResponse,
    Lang,
    PaymentMethod,
    ReturnType,
    load_config_from_env,
)


# ── Fixtures ──

TEST_CONFIG = GolomtConfig(
    endpoint="https://test.golomtbank.com",
    secret="test-secret-key",
    bearer_token="test-bearer-token",
)


def _hmac(secret: str, data: str) -> str:
    """Compute HMAC-SHA256 hex digest, mirroring the SDK."""
    return hmac_mod.new(
        secret.encode("utf-8"),
        data.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


# ── HMAC checksum tests ──


class TestHmacChecksum:
    def test_create_invoice_checksum(self) -> None:
        client = GolomtClient(TEST_CONFIG)
        amount = "1000.00"
        transaction_id = "txn-001"
        return_type = "POST"
        callback = "https://example.com/callback"

        expected = _hmac(
            TEST_CONFIG.secret,
            transaction_id + amount + return_type + callback,
        )
        actual = client._hmac(
            transaction_id + amount + return_type + callback
        )
        assert actual == expected
        client.close()

    def test_inquiry_checksum(self) -> None:
        client = GolomtClient(TEST_CONFIG)
        transaction_id = "txn-001"

        expected = _hmac(
            TEST_CONFIG.secret,
            transaction_id + transaction_id,
        )
        actual = client._hmac(transaction_id + transaction_id)
        assert actual == expected
        client.close()

    def test_pay_by_token_checksum(self) -> None:
        client = GolomtClient(TEST_CONFIG)
        amount_str = "500.00"
        transaction_id = "txn-002"
        token = "tok-abc"

        expected = _hmac(
            TEST_CONFIG.secret,
            amount_str + transaction_id + token,
        )
        actual = client._hmac(amount_str + transaction_id + token)
        assert actual == expected
        client.close()


# ── Amount formatting tests ──


class TestFormatAmount:
    def test_integer_amount(self) -> None:
        client = GolomtClient(TEST_CONFIG)
        assert client._format_amount(1000) == "1000.00"
        client.close()

    def test_float_amount(self) -> None:
        client = GolomtClient(TEST_CONFIG)
        assert client._format_amount(99.5) == "99.50"
        client.close()

    def test_zero_amount(self) -> None:
        client = GolomtClient(TEST_CONFIG)
        assert client._format_amount(0) == "0.00"
        client.close()


# ── Payment URL tests ──


class TestGetPaymentUrl:
    def test_default_params(self) -> None:
        client = GolomtClient(TEST_CONFIG)
        url = client.get_payment_url("inv-123")
        assert url == "https://test.golomtbank.com/payment/MN/inv-123"
        client.close()

    def test_english_socialpay(self) -> None:
        client = GolomtClient(TEST_CONFIG)
        url = client.get_payment_url("inv-456", lang=Lang.EN, payment_method=PaymentMethod.SOCIALPAY)
        assert url == "https://test.golomtbank.com/socialpay/EN/inv-456"
        client.close()


# ── Sync client tests ──


class TestGolomtClientCreateInvoice:
    def test_create_invoice_success(self) -> None:
        mock_response_data = {
            "invoice": "inv-12345",
            "checksum": "server-checksum",
            "transactionId": "txn-001",
            "timestamp": "2026-01-01T00:00:00Z",
            "status": 200,
            "error": "",
            "message": "success",
            "path": "/api/invoice",
            "socialDeeplink": "",
        }

        mock_response = httpx.Response(
            200,
            json=mock_response_data,
            request=httpx.Request("POST", "https://test.golomtbank.com/api/invoice"),
        )

        with patch.object(httpx.Client, "post", return_value=mock_response) as mock_post:
            client = GolomtClient(TEST_CONFIG)
            result = client.create_invoice(
                CreateInvoiceInput(
                    amount=1000,
                    transaction_id="txn-001",
                    return_type=ReturnType.POST,
                    callback="https://example.com/callback",
                    get_token=False,
                    social_deeplink=False,
                )
            )

            assert isinstance(result, CreateInvoiceResponse)
            assert result.invoice == "inv-12345"
            assert result.transaction_id == "txn-001"
            assert result.status == 200
            assert result.message == "success"

            # Verify the request body
            call_kwargs = mock_post.call_args
            body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
            assert body["amount"] == "1000.00"
            assert body["transactionId"] == "txn-001"
            assert body["returnType"] == "POST"
            assert body["genToken"] == "N"
            assert body["socialDeeplink"] == "N"
            assert "checksum" in body

            client.close()

    def test_create_invoice_with_token(self) -> None:
        mock_response = httpx.Response(
            200,
            json={
                "invoice": "inv-99",
                "checksum": "cs",
                "transactionId": "txn-t",
                "timestamp": "",
                "status": 200,
                "error": "",
                "message": "",
                "path": "",
                "socialDeeplink": "",
            },
            request=httpx.Request("POST", "https://test.golomtbank.com/api/invoice"),
        )

        with patch.object(httpx.Client, "post", return_value=mock_response):
            client = GolomtClient(TEST_CONFIG)
            result = client.create_invoice(
                CreateInvoiceInput(
                    amount=500,
                    transaction_id="txn-t",
                    return_type=ReturnType.GET,
                    callback="https://example.com/cb",
                    get_token=True,
                    social_deeplink=True,
                )
            )
            assert result.invoice == "inv-99"
            client.close()


class TestGolomtClientInquiry:
    def test_inquiry_success(self) -> None:
        mock_response_data = {
            "amount": "1000.00",
            "bank": "Golomt",
            "status": "PAID",
            "errorDesc": "",
            "errorCode": "",
            "cardHolder": "John Doe",
            "cardNumber": "4111****1111",
            "transactionId": "txn-001",
            "token": "",
        }

        mock_response = httpx.Response(
            200,
            json=mock_response_data,
            request=httpx.Request("POST", "https://test.golomtbank.com/api/inquiry"),
        )

        with patch.object(httpx.Client, "post", return_value=mock_response):
            client = GolomtClient(TEST_CONFIG)
            result = client.inquiry("txn-001")

            assert isinstance(result, InquiryResponse)
            assert result.amount == "1000.00"
            assert result.bank == "Golomt"
            assert result.status == "PAID"
            assert result.card_holder == "John Doe"
            assert result.transaction_id == "txn-001"
            client.close()


class TestGolomtClientPayByToken:
    def test_pay_by_token_success(self) -> None:
        mock_response_data = {
            "amount": "500.00",
            "errorDesc": "",
            "errorCode": "",
            "transactionId": "txn-002",
            "checksum": "resp-checksum",
            "cardNumber": "4111****1111",
        }

        mock_response = httpx.Response(
            200,
            json=mock_response_data,
            request=httpx.Request("POST", "https://test.golomtbank.com/api/pay"),
        )

        with patch.object(httpx.Client, "post", return_value=mock_response):
            client = GolomtClient(TEST_CONFIG)
            result = client.pay_by_token(
                amount=500,
                token="tok-abc",
                transaction_id="txn-002",
            )

            assert result.amount == "500.00"
            assert result.transaction_id == "txn-002"
            assert result.card_number == "4111****1111"
            client.close()


class TestGolomtClientErrors:
    def test_api_error_with_message(self) -> None:
        mock_response = httpx.Response(
            400,
            json={"message": "Invalid transaction"},
            request=httpx.Request("POST", "https://test.golomtbank.com/api/invoice"),
        )

        with patch.object(httpx.Client, "post", return_value=mock_response):
            client = GolomtClient(TEST_CONFIG)
            with pytest.raises(GolomtError) as exc_info:
                client.create_invoice(
                    CreateInvoiceInput(
                        amount=100,
                        transaction_id="bad-txn",
                        return_type="POST",
                        callback="https://example.com",
                        get_token=False,
                        social_deeplink=False,
                    )
                )
            assert exc_info.value.status_code == 400
            assert "Invalid transaction" in str(exc_info.value)
            client.close()

    def test_api_error_without_message(self) -> None:
        mock_response = httpx.Response(
            500,
            json={"code": "INTERNAL"},
            request=httpx.Request("POST", "https://test.golomtbank.com/api/invoice"),
        )

        with patch.object(httpx.Client, "post", return_value=mock_response):
            client = GolomtClient(TEST_CONFIG)
            with pytest.raises(GolomtError) as exc_info:
                client.create_invoice(
                    CreateInvoiceInput(
                        amount=100,
                        transaction_id="err-txn",
                        return_type="POST",
                        callback="https://example.com",
                        get_token=False,
                        social_deeplink=False,
                    )
                )
            assert exc_info.value.status_code == 500
            assert "HTTP 500" in str(exc_info.value)
            client.close()


# ── Async client tests ──


class TestAsyncGolomtClient:
    @pytest.mark.asyncio
    async def test_create_invoice_async(self) -> None:
        mock_response_data = {
            "invoice": "inv-async",
            "checksum": "cs",
            "transactionId": "txn-async",
            "timestamp": "",
            "status": 200,
            "error": "",
            "message": "ok",
            "path": "/api/invoice",
            "socialDeeplink": "",
        }

        mock_response = httpx.Response(
            200,
            json=mock_response_data,
            request=httpx.Request("POST", "https://test.golomtbank.com/api/invoice"),
        )

        with patch.object(httpx.AsyncClient, "post", return_value=mock_response):
            async with AsyncGolomtClient(TEST_CONFIG) as client:
                result = await client.create_invoice(
                    CreateInvoiceInput(
                        amount=2000,
                        transaction_id="txn-async",
                        return_type=ReturnType.POST,
                        callback="https://example.com/async",
                        get_token=False,
                        social_deeplink=False,
                    )
                )
                assert result.invoice == "inv-async"
                assert result.transaction_id == "txn-async"

    @pytest.mark.asyncio
    async def test_inquiry_async(self) -> None:
        mock_response = httpx.Response(
            200,
            json={
                "amount": "300.00",
                "bank": "Golomt",
                "status": "PAID",
                "errorDesc": "",
                "errorCode": "",
                "cardHolder": "Jane",
                "cardNumber": "5555****4444",
                "transactionId": "txn-inq",
                "token": "tok-xyz",
            },
            request=httpx.Request("POST", "https://test.golomtbank.com/api/inquiry"),
        )

        with patch.object(httpx.AsyncClient, "post", return_value=mock_response):
            async with AsyncGolomtClient(TEST_CONFIG) as client:
                result = await client.inquiry("txn-inq")
                assert result.status == "PAID"
                assert result.token == "tok-xyz"

    @pytest.mark.asyncio
    async def test_pay_by_token_async(self) -> None:
        mock_response = httpx.Response(
            200,
            json={
                "amount": "750.00",
                "errorDesc": "",
                "errorCode": "",
                "transactionId": "txn-pay",
                "checksum": "cs",
                "cardNumber": "4222****2222",
            },
            request=httpx.Request("POST", "https://test.golomtbank.com/api/pay"),
        )

        with patch.object(httpx.AsyncClient, "post", return_value=mock_response):
            async with AsyncGolomtClient(TEST_CONFIG) as client:
                result = await client.pay_by_token(
                    amount=750,
                    token="tok-pay",
                    transaction_id="txn-pay",
                    lang=Lang.EN,
                )
                assert result.amount == "750.00"
                assert result.transaction_id == "txn-pay"

    def test_get_payment_url_async(self) -> None:
        client = AsyncGolomtClient(TEST_CONFIG)
        url = client.get_payment_url("inv-async", lang=Lang.MN)
        assert url == "https://test.golomtbank.com/payment/MN/inv-async"


# ── Config tests ──


class TestConfig:
    def test_load_config_from_env(self) -> None:
        env = {
            "GOLOMT_ENDPOINT": "https://api.golomt.com",
            "GOLOMT_SECRET": "secret123",
            "GOLOMT_BEARER_TOKEN": "bearer456",
        }
        with patch.dict("os.environ", env, clear=False):
            config = load_config_from_env()
            assert config.endpoint == "https://api.golomt.com"
            assert config.secret == "secret123"
            assert config.bearer_token == "bearer456"

    def test_load_config_missing_endpoint(self) -> None:
        env = {
            "GOLOMT_SECRET": "secret123",
            "GOLOMT_BEARER_TOKEN": "bearer456",
        }
        with patch.dict("os.environ", env, clear=True):
            with pytest.raises(ValueError, match="GOLOMT_ENDPOINT"):
                load_config_from_env()

    def test_load_config_missing_secret(self) -> None:
        env = {
            "GOLOMT_ENDPOINT": "https://api.golomt.com",
            "GOLOMT_BEARER_TOKEN": "bearer456",
        }
        with patch.dict("os.environ", env, clear=True):
            with pytest.raises(ValueError, match="GOLOMT_SECRET"):
                load_config_from_env()

    def test_load_config_missing_bearer_token(self) -> None:
        env = {
            "GOLOMT_ENDPOINT": "https://api.golomt.com",
            "GOLOMT_SECRET": "secret123",
        }
        with patch.dict("os.environ", env, clear=True):
            with pytest.raises(ValueError, match="GOLOMT_BEARER_TOKEN"):
                load_config_from_env()


# ── Constants tests ──


class TestConstants:
    def test_lang_values(self) -> None:
        assert Lang.MN == "MN"
        assert Lang.EN == "EN"

    def test_payment_method_values(self) -> None:
        assert PaymentMethod.PAYMENT == "payment"
        assert PaymentMethod.SOCIALPAY == "socialpay"

    def test_return_type_values(self) -> None:
        assert ReturnType.POST == "POST"
        assert ReturnType.GET == "GET"
        assert ReturnType.MOBILE == "MOBILE"


# ── Context manager tests ──


class TestContextManager:
    def test_sync_context_manager(self) -> None:
        with GolomtClient(TEST_CONFIG) as client:
            url = client.get_payment_url("inv-ctx")
            assert "inv-ctx" in url

    @pytest.mark.asyncio
    async def test_async_context_manager(self) -> None:
        async with AsyncGolomtClient(TEST_CONFIG) as client:
            url = client.get_payment_url("inv-actx")
            assert "inv-actx" in url
