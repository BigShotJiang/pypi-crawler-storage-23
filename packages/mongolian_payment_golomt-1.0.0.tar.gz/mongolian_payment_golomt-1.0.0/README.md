# mongolian-payment-golomt

Golomt Bank payment gateway SDK for Python.

Provides both synchronous and asynchronous clients for the Golomt Bank ecommerce payment API, with automatic HMAC-SHA256 checksum generation and bearer token authentication.

## Installation

```bash
pip install mongolian-payment-golomt
```

## Quick Start

### Synchronous

```python
from mongolian_payment_golomt import GolomtClient, GolomtConfig, CreateInvoiceInput

client = GolomtClient(GolomtConfig(
    endpoint="https://ecommerce.golomtbank.com",
    secret="your-hmac-secret",
    bearer_token="your-bearer-token",
))

# Create an invoice
invoice = client.create_invoice(CreateInvoiceInput(
    amount=1000,
    transaction_id="txn-001",
    return_type="POST",
    callback="https://yoursite.com/callback",
    get_token=False,
    social_deeplink=False,
))

# Get payment URL
url = client.get_payment_url(invoice.invoice)
print(url)

# Check transaction status
status = client.inquiry("txn-001")
print(status.status)

client.close()
```

### Asynchronous

```python
import asyncio
from mongolian_payment_golomt import AsyncGolomtClient, GolomtConfig, CreateInvoiceInput

async def main():
    async with AsyncGolomtClient(GolomtConfig(
        endpoint="https://ecommerce.golomtbank.com",
        secret="your-hmac-secret",
        bearer_token="your-bearer-token",
    )) as client:
        invoice = await client.create_invoice(CreateInvoiceInput(
            amount=1000,
            transaction_id="txn-001",
            return_type="POST",
            callback="https://yoursite.com/callback",
            get_token=False,
            social_deeplink=False,
        ))
        print(invoice.invoice)

asyncio.run(main())
```

### Load Config from Environment

```python
from mongolian_payment_golomt import GolomtClient, load_config_from_env

config = load_config_from_env()
client = GolomtClient(config)
```

Required environment variables:

| Variable | Description |
|---|---|
| `GOLOMT_ENDPOINT` | Base URL of the Golomt Bank API |
| `GOLOMT_SECRET` | HMAC-SHA256 secret key |
| `GOLOMT_BEARER_TOKEN` | Bearer token for Authorization header |

## API Reference

### `GolomtClient` / `AsyncGolomtClient`

| Method | Description |
|---|---|
| `create_invoice(input)` | Create a payment invoice |
| `inquiry(transaction_id)` | Check transaction status |
| `pay_by_token(amount, token, transaction_id, lang)` | Pay using a saved token |
| `get_payment_url(invoice, lang, payment_method)` | Build payment redirect URL |

### Constants

| Class | Values |
|---|---|
| `Lang` | `MN`, `EN` |
| `PaymentMethod` | `PAYMENT`, `SOCIALPAY` |
| `ReturnType` | `POST`, `GET`, `MOBILE` |

## License

MIT
