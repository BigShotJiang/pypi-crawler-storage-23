- Reuse existing factor and modify them instead of always creating new
  ones.
