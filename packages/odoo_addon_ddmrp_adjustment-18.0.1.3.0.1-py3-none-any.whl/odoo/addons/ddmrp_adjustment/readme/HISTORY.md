Follow the history of changes in [GitHub Pull Requests](https://github.com/OCA/ddmrp/pulls?q=is%3Apr+ddmrp_adjustment+is%3Aclosed).
