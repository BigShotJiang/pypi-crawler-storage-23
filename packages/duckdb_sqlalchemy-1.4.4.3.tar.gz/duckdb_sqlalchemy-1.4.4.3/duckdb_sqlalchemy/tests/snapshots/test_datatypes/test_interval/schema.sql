CREATE TABLE test_table (
	duration INTERVAL
)
