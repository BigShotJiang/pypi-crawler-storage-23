from sqlalchemy.testing.requirements import SuiteRequirements


class Requirements(SuiteRequirements):
    pass
