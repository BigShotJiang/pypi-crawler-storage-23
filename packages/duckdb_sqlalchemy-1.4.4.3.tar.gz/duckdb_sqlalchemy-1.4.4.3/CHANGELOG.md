# Changelog

This repository is a fork of https://github.com/Mause/duckdb_engine.
Entries from v0.18.0 onward are maintained in this fork; earlier entries are
preserved from the upstream project for historical context.

## Maintained in this fork

## [1.4.4.3](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v1.4.4.2...v1.4.4.3) (2026-02-21)

### Bug Fixes

* fix `USMALLINT` max range handling to cover the full `0..65535` domain
* preserve `NULL` MAP values as `None` in Python instead of coercing to an empty dict

### Tooling

* add `.codex/environments/environment.toml` with local test/lint/type-check actions

## [1.4.4.2](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v1.4.4...v1.4.4.2) (2026-02-05)

### Security

* validate config keys before `SET` statements to block SQL injection payloads
* validate preload extension names before `LOAD`
* validate COPY helper table/column/option identifiers and reject SQL fragments

### Testing

* gate pandas tests on supported pandas/SQLAlchemy combinations
* pin `pandas<2.2` in `nox` SQLAlchemy 1.x sessions for stable matrix runs

### Typing

* align SQLAlchemy compatibility shims and test typing to satisfy `ty`

## [1.4.4.1](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v1.4.4...v1.4.4.1) (2026-02-05)

### Documentation

* document DuckDB multiprocessing fork-safety caveat and `spawn`/`forkserver` workaround

## [1.4.4](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v1.4.3...v1.4.4) (2026-02-03)

### Versioning

* align package version with supported DuckDB version (1.4.4)
* update test matrix and lockfile to DuckDB 1.4.4
* this release contains no functional changes from 1.4.3

## [1.4.3](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.19.3...v1.4.3) (2026-01-15)

### Versioning

* align package version with supported DuckDB version (1.4.x)
* this release contains no functional changes from 0.19.3

## [0.19.3](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.19.2...v0.19.3) (2025-12-28)

### Documentation

* publish GitHub Pages docs site with Jekyll config and navigation
* add overview, getting started, migration guide, and SEO checklist
* add llms.txt and strengthen README/docs discoverability links

### Metadata

* expand PyPI metadata (keywords, classifiers, documentation URL)

## [0.19.2](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.19.0...v0.19.2) (2025-12-28)

### Documentation

* expand docs guides with additional examples and configuration notes
* refine README wording for a more professional tone

### Bug Fixes

* default empty database URLs to `:memory:` for DuckDB connections

### Miscellaneous Chores

* bump package version to 0.19.2

## [0.19.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.18.0...v0.19.0) (2025-12-24)

### Documentation

* overhaul README with long-term support positioning, expanded quick starts, and URL/pooling guidance
* add CI and license badges plus clearer compatibility and support policy sections
* reorganize docs/examples pointers for faster onboarding

### Miscellaneous Chores

* bump package version to 0.19.0 for the documentation release

### Notes

* no runtime code changes in this release

## [0.18.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.17.0...v0.18.0) (2025-12-24)

### ⚠ BREAKING CHANGES

* rename package to `duckdb-sqlalchemy` and module to `duckdb_sqlalchemy` ([#2](https://github.com/leonardovida/duckdb-sqlalchemy/pull/2))

### Documentation

* refresh README branding and fork attribution ([#2](https://github.com/leonardovida/duckdb-sqlalchemy/pull/2))

### Miscellaneous Chores

* update release/publish tooling and metadata for new package name ([#2](https://github.com/leonardovida/duckdb-sqlalchemy/pull/2))

## Upstream history (from Mause/duckdb_engine)

## [0.17.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.16.0...v0.17.0) (2025-03-29)


### Features

* register filesystems ([9f7c796](https://github.com/leonardovida/duckdb-sqlalchemy/commit/9f7c79675345ddad0a3691a40c104fb8229eabfc))

## [0.16.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.15.1...v0.16.0) (2025-03-29)


### ⚠ BREAKING CHANGES

* drop python 3.8

### Bug Fixes

* drop python 3.8 ([1acd720](https://github.com/leonardovida/duckdb-sqlalchemy/commit/1acd720ca91d1438405f848c80425d5cbc715762))

## [0.15.1](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.15.0...v0.15.1) (2025-03-29)


### Bug Fixes

* panics in multi-threaded environments ([694d227](https://github.com/leonardovida/duckdb-sqlalchemy/commit/694d2276a619256643b045ba9568d00ac0e6f9ef))
* panics in multi-threaded environments ([d42c977](https://github.com/leonardovida/duckdb-sqlalchemy/commit/d42c977c5db98a023984c7aed986b702e4228035)), closes [#1190](https://github.com/leonardovida/duckdb-sqlalchemy/issues/1190)

## [0.15.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.14.2...v0.15.0) (2025-01-16)


### Features

* Add supported MotherDuck connection string parameters ([c57f024](https://github.com/leonardovida/duckdb-sqlalchemy/commit/c57f0249573abe65d15e93a605299e3d453e1d11))

## [0.14.2](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.14.1...v0.14.2) (2025-01-10)


### Bug Fixes

* use full list of reserved words ([6dbadf1](https://github.com/leonardovida/duckdb-sqlalchemy/commit/6dbadf1edfe6fd6f0c698b6dc12debb654dde8bc))

## [0.14.1](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.14.0...v0.14.1) (2025-01-10)


### Bug Fixes

* set div_is_floordiv to False to avoid bad casts ([dfbed6d](https://github.com/leonardovida/duckdb-sqlalchemy/commit/dfbed6df21470192551636cefa6ff7386d2cf6ae))

## [0.14.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.13.7-pre0...v0.14.0) (2024-12-16)


### Features

* reexport postgresql insert function ([51dbb18](https://github.com/leonardovida/duckdb-sqlalchemy/commit/51dbb186cff25c340c8395ef660cd6485923ec04))


### Miscellaneous Chores

* release 0.14.0 ([b07a965](https://github.com/leonardovida/duckdb-sqlalchemy/commit/b07a9650f698001fa5a845d193402fddddefceb3))

## [0.13.7-pre0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.13.6...v0.13.7-pre0) (2024-11-24)


### Miscellaneous Chores

* release 0.13.7-pre0 ([b31083b](https://github.com/leonardovida/duckdb-sqlalchemy/commit/b31083b094065f874e58fe7709a83a7f492f982b))

## [0.13.6](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.13.5...v0.13.6) (2024-11-24)


### Bug Fixes

* avoid mutating caller's connect args (don't accumulate user_agents) ([8f39aca](https://github.com/leonardovida/duckdb-sqlalchemy/commit/8f39aca57a3f64ac02dc2766a48f74ec37201203))
* **deps:** update dependency packaging to v24.2 ([f5daa5a](https://github.com/leonardovida/duckdb-sqlalchemy/commit/f5daa5a0599bfb7e00702bf29cae2fcc8f8f3aa8))

## [0.13.5](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.13.4...v0.13.5) (2024-11-07)


### Bug Fixes

* **deps:** update dependency duckdb to v1.1.3 ([3152ddb](https://github.com/leonardovida/duckdb-sqlalchemy/commit/3152ddbf02c16cfb4bcdc1f56174be0473dc5bbd))
* **nightly:** fix default connection references for nightly ([c0848d2](https://github.com/leonardovida/duckdb-sqlalchemy/commit/c0848d270a08981a2bdcae8bddd1ecafafd9b6ca))
* **reflection bug:** Fixed bug causing TypeError when using metadata.reflect() ([b96c1d2](https://github.com/leonardovida/duckdb-sqlalchemy/commit/b96c1d2eccf362f12b67adde6203d49214ee47f3))
* **sqlalchemy versions:** Added statement to apply changes only for sqlalchemy version 2.0.36 and above ([d6fcd32](https://github.com/leonardovida/duckdb-sqlalchemy/commit/d6fcd32461f69d348a55401cc3b8d5c737eb54ab))

## [0.13.4](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.13.3...v0.13.4) (2024-10-22)


### Bug Fixes

* **deps:** update dependency duckdb to v1.1.2 ([d363897](https://github.com/leonardovida/duckdb-sqlalchemy/commit/d363897bc63bb7814f48e454d2afc3c633073205))
* propagate kwargs through compilation nodes ([95d8cef](https://github.com/leonardovida/duckdb-sqlalchemy/commit/95d8cef236629815027b26cbb66a87069a5ccddc))

## [0.13.3](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.13.2...v0.13.3) (2024-10-21)


### Bug Fixes

* add varint type ([220c18f](https://github.com/leonardovida/duckdb-sqlalchemy/commit/220c18f310d113bbfffa9c82379eca6c7cf7f95b))
* restrict varint to supported versions ([ccdbc06](https://github.com/leonardovida/duckdb-sqlalchemy/commit/ccdbc06c7fd07eba02e91cecdefe54b4ea6ea44b))
* update Map type for 1.0+ ([7574837](https://github.com/leonardovida/duckdb-sqlalchemy/commit/757483786a1eba7a606de90c665dcd86dd00dcec))

## [0.13.2](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.13.1...v0.13.2) (2024-09-04)


### Bug Fixes

* **get_view_names:** Use proper schema ([#1082](https://github.com/leonardovida/duckdb-sqlalchemy/issues/1082)) ([d5319c8](https://github.com/leonardovida/duckdb-sqlalchemy/commit/d5319c80d3883425734062640ebd8562cf8525fb))


### Documentation

* use `read_only=False` so that example doesn't raise an exception. ([#1079](https://github.com/leonardovida/duckdb-sqlalchemy/issues/1079)) ([d0688b4](https://github.com/leonardovida/duckdb-sqlalchemy/commit/d0688b4b3e740fb357b6862ebe1ac698506f6488))

## [0.13.1](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.13.0...v0.13.1) (2024-07-29)


### Bug Fixes

* fix: Pass user config option via database name #1064

## [0.13.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.12.1...v0.13.0) (2024-06-02)


### Features

* first class interval support ([286abb5](https://github.com/leonardovida/duckdb-sqlalchemy/commit/286abb585227455b4237147327cdfb5a8e90f938))


### Bug Fixes

* **deps:** update dependency duckdb to v0.10.3 ([7b5249a](https://github.com/leonardovida/duckdb-sqlalchemy/commit/7b5249a8a22e748614ab24d91f0ed8124345591a))

## [0.12.1](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.12.0...v0.12.1) (2024-05-24)


### Bug Fixes

* add new types names for 0.10.3 ([8e0ca8e](https://github.com/leonardovida/duckdb-sqlalchemy/commit/8e0ca8ee2f6d8341ea8274b465259ac4b54d312c))

## [0.12.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.12.0-rc0...v0.12.0) (2024-04-21)


### Miscellaneous Chores

* release 0.12.0 (same as rc0) ([7842f2c](https://github.com/leonardovida/duckdb-sqlalchemy/commit/7842f2c0ad12ae9dadbbc8145ef910cb4c4d1fee))

## [0.12.0-rc0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.11.5...v0.12.0-rc0) (2024-04-18)


### Bug Fixes

* allow connections to be properly closed ([0e57a64](https://github.com/leonardovida/duckdb-sqlalchemy/commit/0e57a645f4dbdddde6ffc9a274ba104ea0070147))

### Miscellaneous Chores

* release 0.12.0-rc0 ([dc71073](https://github.com/leonardovida/duckdb-sqlalchemy/commit/dc7107338c6b212ca6cccc7bcec398c378bd1a15))

## [0.11.5](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.11.4...v0.11.5) (2024-04-16)


### Miscellaneous Chores

* loosen packaging pin

## [0.11.4](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.11.3...v0.11.4) (2024-04-09)


### Bug Fixes

* drop python 3.7 support ([9acdd66](https://github.com/leonardovida/duckdb-sqlalchemy/commit/9acdd660f9f50f120393128f06c12da7e89dfefd))

## [0.11.3](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.11.2...v0.11.3) (2024-04-07)


### Bug Fixes

* _loads_domains in SQLA2 ([4c67e26](https://github.com/leonardovida/duckdb-sqlalchemy/commit/4c67e2616a1b5e1d86eac895ad188bafbbd1a190))
* allow parsing json in dynamic queries ([895685e](https://github.com/leonardovida/duckdb-sqlalchemy/commit/895685e95cab1e9c5f6d3b9cd5f5f763bac9d8d1))

## [0.11.2](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.11.1...v0.11.2) (2024-03-01)


### Bug Fixes

* support views in has_table ([52d6a43](https://github.com/leonardovida/duckdb-sqlalchemy/commit/52d6a43146518af85d5513c4d663ec3a8bc59bda))

## [0.11.1](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.11.0...v0.11.1) (2024-02-06)


### Miscellaneous Chores

* Add duckdb-sqlalchemy/sqlalchemy version info to DuckDB user_agent

## [0.11.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.10.0...v0.11.0) (2024-02-04)


### Features

* comment support ([6a00ec0](https://github.com/leonardovida/duckdb-sqlalchemy/commit/6a00ec0614e02191ee5a2d104f1fe288ea6b0d27))

## [0.10.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.9.5...v0.10.0) (2023-12-24)


### Features

* add new uhugeint type ([4e01db8](https://github.com/leonardovida/duckdb-sqlalchemy/commit/4e01db8101121c6ee3909949ff4dcace91385e51))


### Bug Fixes

* remove packaging requirement ([5b9cafb](https://github.com/leonardovida/duckdb-sqlalchemy/commit/5b9cafb289ad7bc391e3bac3f31fe276618deddf))

## [0.9.5](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.9.4...v0.9.5) (2023-12-21)


### Bug Fixes

* fix: support getting table properties using schema with db name prefix ([#848](https://github.com/leonardovida/duckdb-sqlalchemy/pull/848))

## [0.9.4](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.9.3...v0.9.4) (2023-12-09)


### Bug Fixes

* fix: Support fetching multiple databases and schemas and their associated tables

## [0.9.3](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.9.2...v0.9.3) (2023-12-05)


### Bug Fixes

* use numeric_dollar where available ([f51ee7f](https://github.com/leonardovida/duckdb-sqlalchemy/commit/f51ee7fb481f6e41e9d6636356edb81ee5e424cd))


### Documentation

* add directions for `alembic` support ([d549ba4](https://github.com/leonardovida/duckdb-sqlalchemy/commit/d549ba497b1830b73b54dda4cd983ddb3114c150))
* update autoloading docs ([b782994](https://github.com/leonardovida/duckdb-sqlalchemy/commit/b7829948114fb391918795a932564da2bbbb16db))
* update register docs ([9081ef7](https://github.com/leonardovida/duckdb-sqlalchemy/commit/9081ef76cac0dd80b3922cc2b290724db17aa28e))
* update toc ([abcb158](https://github.com/leonardovida/duckdb-sqlalchemy/commit/abcb158c42b734514028fbb9741c7c7dfa04f985))
* update toc ([#785](https://github.com/leonardovida/duckdb-sqlalchemy/issues/785)) ([234a8b8](https://github.com/leonardovida/duckdb-sqlalchemy/commit/234a8b801ffe4d236c8a790b880bc81207f37266))

## [0.9.2](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.9.1...v0.9.2) (2023-07-23)


### Bug Fixes

* **types:** map `uinteger` to correct type ([405769a](https://github.com/leonardovida/duckdb-sqlalchemy/commit/405769a3b4146cb751e64d4965e94c760934b974))

## [0.9.1](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.9.0...v0.9.1) (2023-07-14)


### Bug Fixes

* move numpy to dev dependencies ([368c55c](https://github.com/leonardovida/duckdb-sqlalchemy/commit/368c55cd41ceb97d4e8dc2971a100b088d2305da))

## [0.9.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.8.0...v0.9.0) (2023-06-21)


### Features

* added support for try_cast operator ([c4318ef](https://github.com/leonardovida/duckdb-sqlalchemy/commit/c4318ef636b5a88a1cb8eccef827183884022a7b)) (see [SQLAlchemy docs](https://docs.sqlalchemy.org/en/20/core/sqlelement.html#sqlalchemy.sql.expression.try_cast) for more information)

## [0.8.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.7.3...v0.8.0) (2023-06-20)


### Features

* nested types (Struct, Map, Union) ([5c16863](https://github.com/leonardovida/duckdb-sqlalchemy/commit/5c16863fce86a11f5bef64449f453dd8b0ef8167))
* passing config via query parameters in the url ([6907041](https://github.com/leonardovida/duckdb-sqlalchemy/pull/675/commits/690704175dc5d61530dc3fd74b0526a638010ba6)

### Bug Fixes

* allow passing motherduck_token as a config parameter ([b944405](https://github.com/leonardovida/duckdb-sqlalchemy/commit/b9444054260eb10c7d473dc55cb7cd7e8a0e84b6))

## [0.7.3](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.7.2...v0.7.3) (2023-05-19)


### Bug Fixes

* don't reflect nested types for now ([3a01f9d](https://github.com/leonardovida/duckdb-sqlalchemy/commit/3a01f9d9d8d459c7b185b8c95f0eabe6ae21c56e))

## [0.7.2](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.7.1...v0.7.2) (2023-05-17)


### Bug Fixes

* add missing ischema_names entries ([20e30cf](https://github.com/leonardovida/duckdb-sqlalchemy/commit/20e30cf4062cf3927b6dab86b0e609ca1e3d4d68))

## [0.7.1](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.7.0...v0.7.1) (2023-05-09)


### Bug Fixes

* reuse base dialect colspecs ([faba775](https://github.com/leonardovida/duckdb-sqlalchemy/commit/faba77590690cd026384a1e310373661554b903a)), closes [#632](https://github.com/leonardovida/duckdb-sqlalchemy/issues/632)


### Dependencies

* raise sqlalchemy lower bound to fix [#609](https://github.com/leonardovida/duckdb-sqlalchemy/issues/609) ([16cc7d8](https://github.com/leonardovida/duckdb-sqlalchemy/commit/16cc7d88f6982d572648c142a25a9e8681bb46f2))

## [0.7.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.7.0-rc1...v0.7.0) (2023-03-16)


### Miscellaneous Chores

* release 0.7.0 ([c790424](https://github.com/leonardovida/duckdb-sqlalchemy/commit/c790424aee5f2bfcfe589ad7f27b4f2e18b4d1e2))

## [0.7.0-rc1](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.6.9...v0.7.0-rc1) (2023-03-07)


### Features

* support sqlalchemy 2.0 ([fe6be80](https://github.com/leonardovida/duckdb-sqlalchemy/commit/fe6be8034aa0d3cdfce03f67cf885eafe3dd9d64))


### Miscellaneous Chores

* release 0.7.0-rc1 ([691fdf9](https://github.com/leonardovida/duckdb-sqlalchemy/commit/691fdf918ff3caee21395ab35a1a7840a8a7f833))

## [0.6.9](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.6.8...v0.6.9) (2023-03-01)


### Bug Fixes

* properly support UUID type ([b138b85](https://github.com/leonardovida/duckdb-sqlalchemy/commit/b138b8512b972c8b8ec9c229d86ae18706c8b18e)), closes [#530](https://github.com/leonardovida/duckdb-sqlalchemy/issues/530)


### Documentation

* update README toc ([42a0192](https://github.com/leonardovida/duckdb-sqlalchemy/commit/42a0192b8f948b610303a63f1a490c4ffe1ead95))
* update readme with link to duckdb's docs ([4fcb730](https://github.com/leonardovida/duckdb-sqlalchemy/commit/4fcb730c9f87d2d3ebd383717fb90b329fd50708))

## [0.6.8](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.6.7...v0.6.8) (2023-01-08)


### Bug Fixes

* correct json type mapping ([7bf8753](https://github.com/leonardovida/duckdb-sqlalchemy/commit/7bf8753f79aac22e2e133fd1b916950c32b0facf))

## [0.6.7](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.6.6...v0.6.7) (2023-01-07)


### Bug Fixes

* correct attribute reference ([d2a2577](https://github.com/leonardovida/duckdb-sqlalchemy/commit/d2a2577cded6e6e9282efab5370b15bbe4423a40))

## [0.6.6](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.6.5...v0.6.6) (2022-12-17)


### Bug Fixes

* add missing data types ([92cef1b](https://github.com/leonardovida/duckdb-sqlalchemy/commit/92cef1bf8f7fb12786675c450f8d134f9ed9104b))
* add missing integer data types ([c7e9ccf](https://github.com/leonardovida/duckdb-sqlalchemy/commit/c7e9ccf70a3f6baeca40909e18dfc628fa2401b1))
* disable server side cursors ([bae0a1c](https://github.com/leonardovida/duckdb-sqlalchemy/commit/bae0a1c23879fac3d6bf910979a2923531128f83))

## [0.6.5](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.6.4...v0.6.5) (2022-11-22)


### ⚠ BREAKING CHANGES

* drop python 3.6 support

### Documentation

* add note regarding fetchmany support in duckdb=&gt;0.5.0 ([7ccbaa9](https://github.com/leonardovida/duckdb-sqlalchemy/commit/7ccbaa9873d14a21e2fb54a20931c29fe991b370))


### Dependencies

* add snapshottest ([0b18f47](https://github.com/leonardovida/duckdb-sqlalchemy/commit/0b18f47b43fd5e34689a555b6f7706fbe6162d21))
* bump tested duckdb to 0.5.1 in tox.ini ([da71828](https://github.com/leonardovida/duckdb-sqlalchemy/commit/da718286e99be27f754ddc467d2b9bc137e88f8a))
* declare shared test dependencies ([e43823c](https://github.com/leonardovida/duckdb-sqlalchemy/commit/e43823ca29c9c75772612bf59812335ddb721790))
* fix requirement declaration ([e3923ee](https://github.com/leonardovida/duckdb-sqlalchemy/commit/e3923ee693a2bba455708787666652985b972b9f))
* test against 0.5.1 ([0aca52e](https://github.com/leonardovida/duckdb-sqlalchemy/commit/0aca52e21f2f2d4d2e5e847b5002a715b83dd5d2))


### Code Refactoring

* drop python 3.6 support ([0d81998](https://github.com/leonardovida/duckdb-sqlalchemy/commit/0d81998caafee51d86f1692cd73867561b0ce576))


### Miscellaneous Chores

* release 0.6.5 ([52eca6f](https://github.com/leonardovida/duckdb-sqlalchemy/commit/52eca6fce78319893dd6ba9de1e193d920e03c78))

## [0.6.4](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.6.3...v0.6.4) (2022-09-11)


### Bug Fixes

* stub out Dialect#get_indexes for now ([1d450ab](https://github.com/leonardovida/duckdb-sqlalchemy/commit/1d450abd21afeff61f355ac2b94b0d7d80adac36))
* use real fetchmany now it's available ([06400b4](https://github.com/leonardovida/duckdb-sqlalchemy/commit/06400b464c100dedf43960b9e89470f8f53b7f70))


### Dependencies

* bump locked duckdb version ([1a83643](https://github.com/leonardovida/duckdb-sqlalchemy/commit/1a8364309ee89db614d3dd7caafda5ba1ca51786))

## [0.6.3](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.6.2...v0.6.3) (2022-09-08)


### Bug Fixes

* add schema support to get_view_names ([b58bf32](https://github.com/leonardovida/duckdb-sqlalchemy/commit/b58bf3234b77e26871fb4373358d4b55627eae8b))
* correct get_view_names for older sqlalchemy ([b58bf32](https://github.com/leonardovida/duckdb-sqlalchemy/commit/b58bf3234b77e26871fb4373358d4b55627eae8b))
* repin duckdb & poetry ([#400](https://github.com/leonardovida/duckdb-sqlalchemy/issues/400)) ([4586852](https://github.com/leonardovida/duckdb-sqlalchemy/commit/4586852eae2b49241e32b02a40d16eefa7d809c1))

## [0.6.2](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.6.1...v0.6.2) (2022-08-25)


### Bug Fixes

* fix bleeding edge duckdb for exceptions changes ([f955264](https://github.com/leonardovida/duckdb-sqlalchemy/commit/f9552642fe212d114a3670068dc73243594a0cec))

## [0.6.1](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.6.0...v0.6.1) (2022-08-23)


### Bug Fixes

* support boolean and integer config values ([4a2c639](https://github.com/leonardovida/duckdb-sqlalchemy/commit/4a2c6399175fc35e071319b193f3b5de0c3c0878))

## [0.6.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.5.0...v0.6.0) (2022-08-21)


### Features

* allow preloading of extensions ([13a92e1](https://github.com/leonardovida/duckdb-sqlalchemy/commit/13a92e1fa7d6bdb5777b46c234cb00a150978e9c))


### Documentation

* document preload_extensions config parameter ([c0f2a99](https://github.com/leonardovida/duckdb-sqlalchemy/commit/c0f2a993ee826fa91cab2add7321c52e437bb5a8))
* link to example of IPython-SQL usage ([96e8bdf](https://github.com/leonardovida/duckdb-sqlalchemy/commit/96e8bdf3aa8e0d645534bd19188d086d234e606e))

## [0.5.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.4.0...v0.5.0) (2022-08-19)


### Features

* support unsigned integer types ([a69a35b](https://github.com/leonardovida/duckdb-sqlalchemy/commit/a69a35bdfbfc9b992bc31dfb0f31f1097458d741))


### Bug Fixes

* try to fix poetry installation in workflow ([db21892](https://github.com/leonardovida/duckdb-sqlalchemy/commit/db2189296782ecee0c83d9b2e8a91f6a4c0dd3bb))


### Documentation

* mention unsigned integer support in README ([4e403cb](https://github.com/leonardovida/duckdb-sqlalchemy/commit/4e403cb89c32031c5966725427d14162b4ceceab))

## [0.4.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.3.4...v0.4.0) (2022-08-15)


### Features

* switch to first party sqlalchemy stubs ([cf9f626](https://github.com/leonardovida/duckdb-sqlalchemy/commit/cf9f6268bc1da8418e7188e37fe6c0c20cb2a05e))


### Bug Fixes

* support ping on latest sqlalchemy ([bd63122](https://github.com/leonardovida/duckdb-sqlalchemy/commit/bd631226f03f28c5fa2532b9ddd20a69c70a49e0))

## [0.3.4](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.3.3...v0.3.4) (2022-08-12)


### Bug Fixes

* disable comments in dialect ([96cca1c](https://github.com/leonardovida/duckdb-sqlalchemy/commit/96cca1c6bd4c10a0c8f70fbd695fa8434c94358f))
* restore mypy checking to github builds ([b252679](https://github.com/leonardovida/duckdb-sqlalchemy/commit/b252679ed4da3477cd39bd37825639f03d5ded5a))

## [0.3.3](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.3.2...v0.3.3) (2022-08-06)


### Bug Fixes

* add code coverage reporting ([019b61c](https://github.com/leonardovida/duckdb-sqlalchemy/commit/019b61ca21a9f47467b2f01acdecf275fe658aec))
* add documentation and test for duckdb config ([f3e577a](https://github.com/leonardovida/duckdb-sqlalchemy/commit/f3e577a8fcdd9b00db0e0ea8002bc3d574003e02))
* correct dialect error lookup for bleeding edge ([0e04d02](https://github.com/leonardovida/duckdb-sqlalchemy/commit/0e04d02d86c4f3e8d4ff3cf8d147e0707faedff9))

## [0.3.2](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.3.1...v0.3.2) (2022-08-05)


### Bug Fixes

* unpin numpy for python 3.6 ([3e87509](https://github.com/leonardovida/duckdb-sqlalchemy/commit/3e875091164c018db6ccfa4e1dd2fd5e6238979c))

## [0.3.1](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.3.0...v0.3.1) (2022-08-05)


### Bug Fixes

* add py.typed file ([99e39e4](https://github.com/leonardovida/duckdb-sqlalchemy/commit/99e39e4184d3ec5a48cf1eac65641035f5fb79a8))
* update test for bleeding edge ([ec63594](https://github.com/leonardovida/duckdb-sqlalchemy/commit/ec63594dbe99c58ac88870de8d3daea847970302))

## [0.3.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.2.0...v0.3.0) (2022-08-02)


### Features

* use SingletonThreadPool for :memory: connections ([58ef77a](https://github.com/leonardovida/duckdb-sqlalchemy/commit/58ef77acb55f3bfbe8be511f79a151a25f54a374))

## [0.2.0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.1.12...v0.2.0) (2022-07-03)


### Features

* add missing apilevel and threadsafety attributes on duckdb DBAPI ([bc413a3](https://github.com/leonardovida/duckdb-sqlalchemy/commit/bc413a3df1579f32dbff48069da8ae338f21854c))
* add release-please config ([6e9a2d7](https://github.com/leonardovida/duckdb-sqlalchemy/commit/6e9a2d70ae666f6c488afa984f72b8a8a1528f75))
* add support for Binary ([8235377](https://github.com/leonardovida/duckdb-sqlalchemy/commit/82353778ab8c50804e42b21049eb58c626c51b8f))
* enable relationship integrity ([f41bd10](https://github.com/leonardovida/duckdb-sqlalchemy/commit/f41bd1030c0c9e5406ff76da7f9a3ef716c311c7))
* improve release script ([bcb17bf](https://github.com/leonardovida/duckdb-sqlalchemy/commit/bcb17bf05667b539e56fa83ece9bdf57dde9918a))
* override driver name ([1a7bb4e](https://github.com/leonardovida/duckdb-sqlalchemy/commit/1a7bb4e4b558dac6bf5f0e07d697789b1f83b0dc))
* strip comments from generated sql ([66265a2](https://github.com/leonardovida/duckdb-sqlalchemy/commit/66265a2a0755fabb7d2e847d5a75ac182fc81714))
* warn when we find comments in the ddl ([5b27a7f](https://github.com/leonardovida/duckdb-sqlalchemy/commit/5b27a7f374bf58023629c0576b85ae4323ec5fb2))


### Bug Fixes

* enable updating of existing models ([14a4d5f](https://github.com/leonardovida/duckdb-sqlalchemy/commit/14a4d5f68ed60e4fa81c9ba60c1c906ffb538998))

## [0.1.12a0](https://github.com/leonardovida/duckdb-sqlalchemy/compare/v0.1.11...v0.1.12a0) (2022-06-23)


### Features
* feat: enable interval support by @Mause in https://github.com/leonardovida/duckdb-sqlalchemy/pull/278
* fix: use modern dialect registration by @Mause in https://github.com/leonardovida/duckdb-sqlalchemy/pull/280

### Chores
* chore: add release script by @Mause in https://github.com/leonardovida/duckdb-sqlalchemy/pull/276
* Update and rename release.ps1 to release.sh by @Mause in https://github.com/leonardovida/duckdb-sqlalchemy/pull/287
* feat: add duckdb_version test decorator by @Mause in https://github.com/leonardovida/duckdb-sqlalchemy/pull/272
* chore: add links to bug tracker and changelog by @Mause in https://github.com/leonardovida/duckdb-sqlalchemy/pull/282
* feature/bug report template by @Mause in https://github.com/leonardovida/duckdb-sqlalchemy/pull/285
* feat: Create CODE_OF_CONDUCT.md by @Mause in https://github.com/leonardovida/duckdb-sqlalchemy/pull/284

### Version bumps
* chore(deps): bump duckdb from 0.3.4 to 0.4.0 by @dependabot in https://github.com/leonardovida/duckdb-sqlalchemy/pull/273
* chore(deps): update github/codeql-action action to v1.1.13 by @renovate in https://github.com/leonardovida/duckdb-sqlalchemy/pull/279
* chore(deps): update github/codeql-action action to v1.1.14 by @renovate in https://github.com/leonardovida/duckdb-sqlalchemy/pull/286
