"""Generic scraper registry and factory.

The registry is a simple name-to-class mapping that supports both imperative
registration and a decorator-based approach.

Example::

    from scraper_framework import BaseScraper, ScraperResult
    from scraper_framework.registry import ScraperRegistry

    registry = ScraperRegistry()

    @registry.register("my-source")
    class MyScraper(BaseScraper):
        source = "my-source"
        id_prefix = "ms"

        def _run(self) -> ScraperResult:
            ...

    # Later
    scraper = registry.get("my-source")
    result = scraper.run()
"""

from __future__ import annotations

from typing import Any

from scraper_framework.base import BaseScraper


class ScraperRegistry:
    """Thread-safe registry mapping scraper names to their classes.

    Supports two registration styles:

    1. **Imperative** -- ``registry.add("name", MyScraperClass)``
    2. **Decorator** -- ``@registry.register("name")``

    Retrieval always returns a *new instance* via :meth:`get`.
    """

    def __init__(self) -> None:
        self._registry: dict[str, type[BaseScraper]] = {}

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def add(self, name: str, cls: type[BaseScraper]) -> None:
        """Register a scraper class under *name*.

        Args:
            name: Unique identifier (e.g. ``"greenhouse"``).
            cls: A concrete subclass of :class:`BaseScraper`.

        Raises:
            TypeError: If *cls* is not a subclass of ``BaseScraper``.
            ValueError: If *name* is already registered.
        """
        if not (isinstance(cls, type) and issubclass(cls, BaseScraper)):
            msg = f"Expected a BaseScraper subclass, got {cls!r}"
            raise TypeError(msg)
        if name in self._registry:
            msg = f"Scraper '{name}' is already registered"
            raise ValueError(msg)
        self._registry[name] = cls

    def register(self, name: str):
        """Decorator that registers a scraper class.

        Usage::

            @registry.register("my-source")
            class MyScraper(BaseScraper):
                ...
        """

        def decorator[T: type[BaseScraper]](cls: T) -> T:
            self.add(name, cls)  # type: ignore[arg-type]
            return cls

        return decorator

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------

    def get(self, name: str, *, config: dict[str, Any] | None = None) -> BaseScraper:
        """Instantiate and return a scraper by name.

        Args:
            name: The registered scraper name.
            config: Optional config dict passed to the scraper constructor.

        Raises:
            KeyError: If *name* is not registered.
        """
        cls = self._registry.get(name)
        if cls is None:
            available = ", ".join(sorted(self._registry)) or "(none)"
            msg = f"Unknown scraper: '{name}'. Available: {available}"
            raise KeyError(msg)
        return cls(config=config)

    def list_names(self) -> list[str]:
        """Return a sorted list of all registered scraper names."""
        return sorted(self._registry)

    def __contains__(self, name: str) -> bool:
        return name in self._registry

    def __len__(self) -> int:
        return len(self._registry)

    def __repr__(self) -> str:
        names = ", ".join(sorted(self._registry))
        return f"ScraperRegistry([{names}])"
