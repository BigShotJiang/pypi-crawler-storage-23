"""Rate limiting utilities for scrapers."""

from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class RateLimiter:
    """Configurable rate limiter with jittered sleep.

    Supports both synchronous and asynchronous usage. The sleep duration is
    uniformly sampled from ``[min_seconds, max_seconds]`` to avoid
    thundering-herd patterns.

    Example::

        limiter = RateLimiter(min_seconds=1.0, max_seconds=3.0)
        for url in urls:
            fetch(url)
            limiter.wait()

    Async usage::

        limiter = RateLimiter(min_seconds=0.5, max_seconds=1.5)
        for url in urls:
            await fetch(url)
            await limiter.async_wait()
    """

    min_seconds: float = 2.0
    max_seconds: float = 5.0
    _request_count: int = field(default=0, init=False, repr=False)
    _last_request_at: datetime | None = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        if self.min_seconds < 0:
            msg = f"min_seconds must be >= 0, got {self.min_seconds}"
            raise ValueError(msg)
        if self.max_seconds < self.min_seconds:
            msg = (
                f"max_seconds ({self.max_seconds}) must be >= "
                f"min_seconds ({self.min_seconds})"
            )
            raise ValueError(msg)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @property
    def request_count(self) -> int:
        """Number of waits performed."""
        return self._request_count

    @property
    def last_request_at(self) -> datetime | None:
        """Timestamp of the most recent wait."""
        return self._last_request_at

    def wait(self, override: tuple[float, float] | None = None) -> float:
        """Block the current thread for a jittered duration.

        Args:
            override: Optional ``(min, max)`` tuple to use instead of the
                instance defaults.

        Returns:
            The actual number of seconds slept.
        """
        duration = self._pick_duration(override)
        time.sleep(duration)
        self._record()
        return duration

    async def async_wait(self, override: tuple[float, float] | None = None) -> float:
        """Async version of :meth:`wait`.

        Args:
            override: Optional ``(min, max)`` tuple to use instead of the
                instance defaults.

        Returns:
            The actual number of seconds slept.
        """
        duration = self._pick_duration(override)
        await asyncio.sleep(duration)
        self._record()
        return duration

    def reset(self) -> None:
        """Reset the internal counters."""
        self._request_count = 0
        self._last_request_at = None

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _pick_duration(self, override: tuple[float, float] | None) -> float:
        lo, hi = override or (self.min_seconds, self.max_seconds)
        return random.uniform(lo, hi)

    def _record(self) -> None:
        self._request_count += 1
        self._last_request_at = datetime.now(timezone.utc)
