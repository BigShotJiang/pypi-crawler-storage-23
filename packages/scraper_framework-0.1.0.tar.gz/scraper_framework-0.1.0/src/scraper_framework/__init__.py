"""scraper-framework: Generic web scraper framework with registry, rate limiting, and filters.

Usage::

    from scraper_framework import BaseScraper, ScraperResult, ScraperRegistry

    registry = ScraperRegistry()

    @registry.register("example")
    class ExampleScraper(BaseScraper):
        source = "example"
        id_prefix = "ex"

        def _run(self) -> ScraperResult:
            with self.make_client() as client:
                resp = client.get("https://example.com/api")
                self.result.total_fetched += len(resp.json())
                self.sleep()
            return self.result

    scraper = registry.get("example")
    result = scraper.run()
    print(result.to_dict())
"""

from scraper_framework.base import BaseScraper
from scraper_framework.filters import (
    all_match,
    any_match,
    keyword_filter,
    length_filter,
    negate,
    none_match,
    regex_filter,
)
from scraper_framework.rate_limiter import RateLimiter
from scraper_framework.registry import ScraperRegistry
from scraper_framework.result import ScraperResult

__all__ = [
    "BaseScraper",
    "RateLimiter",
    "ScraperRegistry",
    "ScraperResult",
    "all_match",
    "any_match",
    "keyword_filter",
    "length_filter",
    "negate",
    "none_match",
    "regex_filter",
]
