"""Scraper result tracking."""

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class ScraperResult:
    """Accumulated result from a single scraper run.

    Tracks fetch counts, insert counts, errors, and timing automatically.
    Call ``finish()`` or rely on ``BaseScraper.run()`` to close the timer.

    Example::

        result = ScraperResult(source="my-source")
        result.total_fetched += 10
        result.new_inserted += 3
        result.finish()
        print(result.to_dict())
    """

    source: str
    total_fetched: int = 0
    new_inserted: int = 0
    errors: int = 0
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    finished_at: datetime | None = None
    metadata: dict[str, object] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def finish(self) -> None:
        """Mark the run as finished with the current UTC timestamp."""
        self.finished_at = datetime.now(timezone.utc)

    @property
    def duration_seconds(self) -> float:
        """Elapsed seconds between start and finish (or now if still running)."""
        end = self.finished_at or datetime.now(timezone.utc)
        return round((end - self.started_at).total_seconds(), 1)

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict[str, object]:
        """Return a JSON-safe dictionary of the result."""
        return {
            "source": self.source,
            "total_fetched": self.total_fetched,
            "new_inserted": self.new_inserted,
            "errors": self.errors,
            "duration_seconds": self.duration_seconds,
            "metadata": self.metadata,
        }
