"""Composable filter functions for scraper pipelines.

Filters are plain functions with the signature ``(text: str) -> bool`` so they
can be combined freely with :func:`all_match`, :func:`any_match`, and
:func:`none_match`.

Example::

    from scraper_framework.filters import (
        regex_filter, keyword_filter, all_match, none_match,
    )

    is_senior = keyword_filter({"senior", "staff", "lead"})
    not_excluded = none_match(keyword_filter({"intern", "junior"}))
    has_python = regex_filter(r"\\bpython\\b")

    title = "Senior Python Engineer"
    if is_senior(title) and not_excluded(title) and has_python(title):
        print("Relevant!")
"""

from __future__ import annotations

import re
from collections.abc import Callable

type TextFilter = Callable[[str], bool]


# ---------------------------------------------------------------------------
# Primitive filter builders
# ---------------------------------------------------------------------------


def keyword_filter(
    keywords: set[str],
    *,
    case_sensitive: bool = False,
) -> TextFilter:
    """Return a filter that matches if *any* keyword appears in the text.

    Keywords are matched as substrings. For word-boundary matching use
    :func:`regex_filter` instead.

    Args:
        keywords: Set of keywords to look for.
        case_sensitive: Whether matching is case-sensitive.
    """
    if not case_sensitive:
        normalised = {k.lower() for k in keywords}

        def _match(text: str) -> bool:
            lowered = text.lower()
            return any(kw in lowered for kw in normalised)
    else:

        def _match(text: str) -> bool:
            return any(kw in text for kw in keywords)

    return _match


def regex_filter(pattern: str, *, flags: int = re.IGNORECASE) -> TextFilter:
    """Return a filter that matches if the compiled regex finds a match.

    Args:
        pattern: A regular expression string.
        flags: Regex flags (default: ``re.IGNORECASE``).
    """
    compiled = re.compile(pattern, flags)

    def _match(text: str) -> bool:
        return compiled.search(text) is not None

    return _match


def length_filter(*, min_length: int = 0, max_length: int | None = None) -> TextFilter:
    """Return a filter that checks text length.

    Args:
        min_length: Minimum number of characters.
        max_length: Maximum number of characters (``None`` for unlimited).
    """

    def _match(text: str) -> bool:
        n = len(text)
        if n < min_length:
            return False
        if max_length is not None and n > max_length:
            return False
        return True

    return _match


# ---------------------------------------------------------------------------
# Combinators
# ---------------------------------------------------------------------------


def all_match(*filters: TextFilter) -> TextFilter:
    """Return a filter that passes only if **all** sub-filters pass."""

    def _match(text: str) -> bool:
        return all(f(text) for f in filters)

    return _match


def any_match(*filters: TextFilter) -> TextFilter:
    """Return a filter that passes if **any** sub-filter passes."""

    def _match(text: str) -> bool:
        return any(f(text) for f in filters)

    return _match


def none_match(*filters: TextFilter) -> TextFilter:
    """Return a filter that passes only if **no** sub-filter passes."""

    def _match(text: str) -> bool:
        return not any(f(text) for f in filters)

    return _match


def negate(f: TextFilter) -> TextFilter:
    """Return a filter that inverts the result of *f*."""

    def _match(text: str) -> bool:
        return not f(text)

    return _match
