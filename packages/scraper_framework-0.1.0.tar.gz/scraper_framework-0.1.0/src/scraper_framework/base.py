"""Generic base scraper class.

Provides the abstract skeleton that concrete scrapers implement. Handles
lifecycle (setup, run, teardown), HTTP client creation, rate limiting, and
result tracking.

Example subclass::

    from scraper_framework import BaseScraper, ScraperResult

    class MyScraper(BaseScraper):
        source = "my-source"
        id_prefix = "ms"

        def _run(self) -> ScraperResult:
            with self.make_client() as client:
                resp = client.get("https://example.com/api/items")
                items = resp.json()
                self.result.total_fetched += len(items)
                # ... process items ...
                self.sleep()
            return self.result
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from collections.abc import Callable
from datetime import datetime, timezone
from typing import Any

import httpx

from scraper_framework.rate_limiter import RateLimiter
from scraper_framework.result import ScraperResult


class BaseScraper(ABC):
    """Abstract base class for all scrapers.

    Subclasses **must** set ``source`` and implement :meth:`_run`.

    Class attributes:
        source: Identifier for this scraper (e.g. ``"greenhouse"``).
        id_prefix: Short prefix for generated record IDs (e.g. ``"gh"``).
        rate_limit_range: Default ``(min, max)`` seconds between requests.
    """

    source: str = ""
    id_prefix: str = ""
    rate_limit_range: tuple[float, float] = (2.0, 5.0)

    def __init__(self, *, config: dict[str, Any] | None = None) -> None:
        self.config: dict[str, Any] = config or {}
        self.result = ScraperResult(source=self.source)
        self.rate_limiter = RateLimiter(
            min_seconds=self.rate_limit_range[0],
            max_seconds=self.rate_limit_range[1],
        )
        self.log = logging.getLogger(f"scraper.{self.source}")

    # ------------------------------------------------------------------
    # Lifecycle hooks (override in subclasses if needed)
    # ------------------------------------------------------------------

    def setup(self) -> None:
        """Called before :meth:`_run`. Override for one-time initialisation."""

    def teardown(self) -> None:
        """Called after :meth:`_run` completes (even on error). Override for cleanup."""

    # ------------------------------------------------------------------
    # Abstract
    # ------------------------------------------------------------------

    @abstractmethod
    def _run(self) -> ScraperResult:
        """Execute the scraping logic.

        Must populate ``self.result`` and return it. Implementations should
        call ``self.sleep()`` between HTTP requests to respect rate limits.
        """
        ...

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def run(
        self,
        *,
        on_before: Callable[["BaseScraper"], None] | None = None,
        on_after: Callable[["BaseScraper", ScraperResult], None] | None = None,
    ) -> ScraperResult:
        """Public entry point: setup, run scraper, teardown, finalize result.

        Args:
            on_before: Optional callback invoked after :meth:`setup` but
                before :meth:`_run`.
            on_after: Optional callback invoked after :meth:`_run` with the
                result.

        Returns:
            The populated :class:`ScraperResult`.
        """
        self.setup()
        if on_before:
            on_before(self)
        try:
            self._run()
        except Exception:
            self.result.errors += 1
            self.log.exception("Scraper %s failed", self.source)
            raise
        finally:
            self.teardown()
            self.result.finish()
        if on_after:
            on_after(self, self.result)
        return self.result

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def sleep(self, range_override: tuple[float, float] | None = None) -> float:
        """Rate-limiting sleep between requests.

        Args:
            range_override: Optional ``(min, max)`` seconds to override the
                default rate limit range.

        Returns:
            Actual seconds slept.
        """
        return self.rate_limiter.wait(override=range_override)

    def make_client(self, **kwargs: Any) -> httpx.Client:
        """Create an :class:`httpx.Client` with sensible defaults.

        Defaults:
            - ``timeout``: 30 seconds
            - ``follow_redirects``: True

        All keyword arguments are forwarded to ``httpx.Client``, overriding
        the defaults.
        """
        defaults: dict[str, Any] = {"timeout": 30.0, "follow_redirects": True}
        defaults.update(kwargs)
        return httpx.Client(**defaults)

    def make_async_client(self, **kwargs: Any) -> httpx.AsyncClient:
        """Create an :class:`httpx.AsyncClient` with sensible defaults.

        Same defaults as :meth:`make_client`.
        """
        defaults: dict[str, Any] = {"timeout": 30.0, "follow_redirects": True}
        defaults.update(kwargs)
        return httpx.AsyncClient(**defaults)

    @staticmethod
    def now_iso() -> str:
        """Current UTC timestamp in ISO-8601 format."""
        return datetime.now(timezone.utc).isoformat()
