"""Tests for the scraper framework core components."""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

from scraper_framework import (
    BaseScraper,
    RateLimiter,
    ScraperRegistry,
    ScraperResult,
    all_match,
    any_match,
    keyword_filter,
    length_filter,
    negate,
    none_match,
    regex_filter,
)


# =========================================================================
# Fixtures
# =========================================================================


class StubScraper(BaseScraper):
    """Minimal concrete scraper for testing."""

    source = "stub"
    id_prefix = "st"
    rate_limit_range = (0.0, 0.0)  # No delay in tests

    def _run(self) -> ScraperResult:
        self.result.total_fetched = 5
        self.result.new_inserted = 3
        return self.result


class FailingScraper(BaseScraper):
    """Scraper that raises during _run."""

    source = "failing"
    id_prefix = "fl"
    rate_limit_range = (0.0, 0.0)

    def _run(self) -> ScraperResult:
        msg = "connection refused"
        raise ConnectionError(msg)


# =========================================================================
# ScraperResult
# =========================================================================


class TestScraperResult:
    def test_defaults(self) -> None:
        result = ScraperResult(source="test")
        assert result.source == "test"
        assert result.total_fetched == 0
        assert result.new_inserted == 0
        assert result.errors == 0
        assert result.finished_at is None
        assert isinstance(result.started_at, datetime)

    def test_finish(self) -> None:
        result = ScraperResult(source="test")
        result.finish()
        assert result.finished_at is not None
        assert result.finished_at >= result.started_at

    def test_duration_seconds_running(self) -> None:
        result = ScraperResult(source="test")
        duration = result.duration_seconds
        assert duration >= 0.0

    def test_duration_seconds_finished(self) -> None:
        result = ScraperResult(source="test")
        result.finish()
        duration = result.duration_seconds
        assert duration >= 0.0

    def test_to_dict(self) -> None:
        result = ScraperResult(source="test")
        result.total_fetched = 10
        result.new_inserted = 4
        result.errors = 1
        result.metadata["custom"] = "value"
        result.finish()

        d = result.to_dict()
        assert d["source"] == "test"
        assert d["total_fetched"] == 10
        assert d["new_inserted"] == 4
        assert d["errors"] == 1
        assert isinstance(d["duration_seconds"], float)
        assert d["metadata"] == {"custom": "value"}

    def test_metadata_isolation(self) -> None:
        r1 = ScraperResult(source="a")
        r2 = ScraperResult(source="b")
        r1.metadata["key"] = 1
        assert "key" not in r2.metadata


# =========================================================================
# BaseScraper
# =========================================================================


class TestBaseScraper:
    def test_run_lifecycle(self) -> None:
        scraper = StubScraper()
        result = scraper.run()
        assert result.total_fetched == 5
        assert result.new_inserted == 3
        assert result.finished_at is not None

    def test_run_with_config(self) -> None:
        scraper = StubScraper(config={"key": "value"})
        assert scraper.config == {"key": "value"}

    def test_run_calls_setup_and_teardown(self) -> None:
        scraper = StubScraper()
        scraper.setup = MagicMock()  # type: ignore[method-assign]
        scraper.teardown = MagicMock()  # type: ignore[method-assign]

        scraper.run()

        scraper.setup.assert_called_once()
        scraper.teardown.assert_called_once()

    def test_run_on_before_callback(self) -> None:
        scraper = StubScraper()
        callback = MagicMock()

        scraper.run(on_before=callback)

        callback.assert_called_once_with(scraper)

    def test_run_on_after_callback(self) -> None:
        scraper = StubScraper()
        callback = MagicMock()

        result = scraper.run(on_after=callback)

        callback.assert_called_once_with(scraper, result)

    def test_failing_scraper_increments_errors_and_raises(self) -> None:
        scraper = FailingScraper()
        with pytest.raises(ConnectionError, match="connection refused"):
            scraper.run()
        assert scraper.result.errors == 1
        # teardown is still called and result is finished
        assert scraper.result.finished_at is not None

    def test_teardown_called_on_failure(self) -> None:
        scraper = FailingScraper()
        scraper.teardown = MagicMock()  # type: ignore[method-assign]

        with pytest.raises(ConnectionError):
            scraper.run()

        scraper.teardown.assert_called_once()

    def test_sleep_delegates_to_rate_limiter(self) -> None:
        scraper = StubScraper()
        with patch.object(scraper.rate_limiter, "wait", return_value=0.0) as mock_wait:
            scraper.sleep()
            mock_wait.assert_called_once_with(override=None)

    def test_sleep_with_override(self) -> None:
        scraper = StubScraper()
        with patch.object(scraper.rate_limiter, "wait", return_value=0.0) as mock_wait:
            scraper.sleep(range_override=(1.0, 2.0))
            mock_wait.assert_called_once_with(override=(1.0, 2.0))

    def test_make_client(self) -> None:
        scraper = StubScraper()
        client = scraper.make_client()
        assert client.timeout.read == 30.0
        assert client.follow_redirects is True
        client.close()

    def test_make_client_custom_timeout(self) -> None:
        scraper = StubScraper()
        client = scraper.make_client(timeout=60.0)
        assert client.timeout.read == 60.0
        client.close()

    def test_make_async_client(self) -> None:
        scraper = StubScraper()
        client = scraper.make_async_client()
        assert client.timeout.read == 30.0
        assert client.follow_redirects is True

    def test_now_iso(self) -> None:
        ts = StubScraper.now_iso()
        parsed = datetime.fromisoformat(ts)
        assert parsed.tzinfo == timezone.utc

    def test_logger_name(self) -> None:
        scraper = StubScraper()
        assert scraper.log.name == "scraper.stub"


# =========================================================================
# RateLimiter
# =========================================================================


class TestRateLimiter:
    def test_defaults(self) -> None:
        limiter = RateLimiter()
        assert limiter.min_seconds == 2.0
        assert limiter.max_seconds == 5.0
        assert limiter.request_count == 0
        assert limiter.last_request_at is None

    def test_wait_records_count(self) -> None:
        limiter = RateLimiter(min_seconds=0.0, max_seconds=0.0)
        limiter.wait()
        limiter.wait()
        assert limiter.request_count == 2
        assert limiter.last_request_at is not None

    def test_wait_with_override(self) -> None:
        limiter = RateLimiter(min_seconds=10.0, max_seconds=20.0)
        duration = limiter.wait(override=(0.0, 0.0))
        assert duration == 0.0

    def test_reset(self) -> None:
        limiter = RateLimiter(min_seconds=0.0, max_seconds=0.0)
        limiter.wait()
        limiter.reset()
        assert limiter.request_count == 0
        assert limiter.last_request_at is None

    def test_invalid_min_seconds(self) -> None:
        with pytest.raises(ValueError, match="min_seconds must be >= 0"):
            RateLimiter(min_seconds=-1.0)

    def test_max_less_than_min(self) -> None:
        with pytest.raises(ValueError, match="max_seconds"):
            RateLimiter(min_seconds=5.0, max_seconds=1.0)

    @pytest.mark.asyncio
    async def test_async_wait(self) -> None:
        limiter = RateLimiter(min_seconds=0.0, max_seconds=0.0)
        duration = await limiter.async_wait()
        assert duration == 0.0
        assert limiter.request_count == 1


# =========================================================================
# ScraperRegistry
# =========================================================================


class TestScraperRegistry:
    def test_add_and_get(self) -> None:
        registry = ScraperRegistry()
        registry.add("stub", StubScraper)
        scraper = registry.get("stub")
        assert isinstance(scraper, StubScraper)

    def test_get_with_config(self) -> None:
        registry = ScraperRegistry()
        registry.add("stub", StubScraper)
        scraper = registry.get("stub", config={"key": "val"})
        assert scraper.config == {"key": "val"}

    def test_register_decorator(self) -> None:
        registry = ScraperRegistry()

        @registry.register("decorated")
        class DecoratedScraper(StubScraper):
            source = "decorated"

        assert "decorated" in registry
        scraper = registry.get("decorated")
        assert isinstance(scraper, DecoratedScraper)

    def test_get_unknown_raises(self) -> None:
        registry = ScraperRegistry()
        with pytest.raises(KeyError, match="Unknown scraper: 'nope'"):
            registry.get("nope")

    def test_duplicate_add_raises(self) -> None:
        registry = ScraperRegistry()
        registry.add("stub", StubScraper)
        with pytest.raises(ValueError, match="already registered"):
            registry.add("stub", StubScraper)

    def test_add_non_scraper_raises(self) -> None:
        registry = ScraperRegistry()
        with pytest.raises(TypeError, match="Expected a BaseScraper subclass"):
            registry.add("bad", dict)  # type: ignore[arg-type]

    def test_list_names(self) -> None:
        registry = ScraperRegistry()
        registry.add("beta", StubScraper)

        class AnotherScraper(StubScraper):
            source = "alpha"

        registry.add("alpha", AnotherScraper)
        assert registry.list_names() == ["alpha", "beta"]

    def test_contains(self) -> None:
        registry = ScraperRegistry()
        registry.add("stub", StubScraper)
        assert "stub" in registry
        assert "missing" not in registry

    def test_len(self) -> None:
        registry = ScraperRegistry()
        assert len(registry) == 0
        registry.add("stub", StubScraper)
        assert len(registry) == 1

    def test_repr(self) -> None:
        registry = ScraperRegistry()
        registry.add("b", StubScraper)

        class A(StubScraper):
            source = "a"

        registry.add("a", A)
        assert repr(registry) == "ScraperRegistry([a, b])"


# =========================================================================
# Filters
# =========================================================================


class TestFilters:
    def test_keyword_filter_case_insensitive(self) -> None:
        f = keyword_filter({"senior", "staff"})
        assert f("Senior Engineer") is True
        assert f("STAFF developer") is True
        assert f("Junior Developer") is False

    def test_keyword_filter_case_sensitive(self) -> None:
        f = keyword_filter({"Senior"}, case_sensitive=True)
        assert f("Senior Engineer") is True
        assert f("senior engineer") is False

    def test_regex_filter(self) -> None:
        f = regex_filter(r"\bpython\b")
        assert f("Python Developer") is True
        assert f("pythonic code") is False  # word boundary
        assert f("Java Engineer") is False

    def test_length_filter(self) -> None:
        f = length_filter(min_length=3, max_length=10)
        assert f("ab") is False
        assert f("abc") is True
        assert f("0123456789") is True
        assert f("01234567890") is False

    def test_length_filter_no_max(self) -> None:
        f = length_filter(min_length=1)
        assert f("") is False
        assert f("x" * 10000) is True

    def test_all_match(self) -> None:
        f = all_match(
            keyword_filter({"senior"}),
            regex_filter(r"\bpython\b"),
        )
        assert f("Senior Python Developer") is True
        assert f("Senior Java Developer") is False
        assert f("Junior Python Developer") is False

    def test_any_match(self) -> None:
        f = any_match(
            keyword_filter({"python"}),
            keyword_filter({"rust"}),
        )
        assert f("Python Dev") is True
        assert f("Rust Dev") is True
        assert f("Java Dev") is False

    def test_none_match(self) -> None:
        f = none_match(keyword_filter({"intern", "junior"}))
        assert f("Senior Engineer") is True
        assert f("Junior Developer") is False
        assert f("Intern position") is False

    def test_negate(self) -> None:
        f = negate(keyword_filter({"intern"}))
        assert f("Senior Engineer") is True
        assert f("Summer Intern") is False

    def test_composable_pipeline(self) -> None:
        """Full pipeline: senior + skills, no exclusions."""
        is_senior = keyword_filter({"senior", "staff", "lead"})
        not_excluded = none_match(keyword_filter({"intern", "junior"}))
        has_tech = regex_filter(r"\b(python|typescript|react)\b")

        pipeline = all_match(is_senior, not_excluded, has_tech)

        assert pipeline("Senior Python Engineer") is True
        assert pipeline("Lead React Developer") is True
        assert pipeline("Junior Python Developer") is False
        assert pipeline("Senior Marketing Manager") is False
        assert pipeline("Staff Intern Program") is False
