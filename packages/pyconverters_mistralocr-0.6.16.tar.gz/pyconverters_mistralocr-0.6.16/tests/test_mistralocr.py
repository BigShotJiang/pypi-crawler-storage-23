from pathlib import Path

import pytest
from pymultirole_plugins.v1.schema import Document
from starlette.datastructures import Headers, UploadFile

from pyconverters_mistralocr.mistralocr import MistralOCRConverter, MistralOCRParameters


@pytest.mark.skip(reason="Needs an API key")
def test_mistralocr_pdf():
    converter = MistralOCRConverter()
    parameters = MistralOCRParameters(
        max_pages_split=10,
        include_image_base64_as_links=False,
        include_image_base64_as_altTexts=True,
    )
    # parameters = MistralOCRParameters(segment=True)
    testdir = Path(__file__).parent
    source = Path(testdir, "data/ENG product fact files_general offer_2025_30pages.pdf")
    with source.open("rb") as fin:
        upload = UploadFile(file=fin, filename=source.name, headers=Headers({"content-type": "application/pdf"}))
        docs: list[Document] = converter.convert(upload, parameters)
    assert len(docs) == 1
    assert docs[0].identifier == "ENG product fact files_general offer_2025_30pages.pdf"
    assert docs[0].title == "ENG product fact files_general offer_2025_30pages.pdf"

    json_file = source.with_suffix(".json")
    with json_file.open("w") as fout:
        print(docs[0].model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


@pytest.mark.skip(reason="Needs an API key")
def test_mistralocr_pdf_no_latex():
    converter = MistralOCRConverter()
    parameters = MistralOCRParameters(segment=True)
    testdir = Path(__file__).parent
    source = Path(testdir, "data/ijms-22-07070-v2.pdf")
    with source.open("rb") as fin:
        upload = UploadFile(file=fin, filename=source.name, headers=Headers({"content-type": "application/pdf"}))
        docs: list[Document] = converter.convert(upload, parameters)
    assert len(docs) == 1
    assert docs[0].identifier == "ijms-22-07070-v2.pdf"
    assert "$" not in docs[0].text

    json_file = source.with_suffix(".json")
    with json_file.open("w") as fout:
        print(docs[0].model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


@pytest.mark.skip(reason="Needs an API key")
def test_mistralocr_dir():
    converter = MistralOCRConverter()
    parameters = MistralOCRParameters(segment=True)
    testdir = Path(__file__).parent
    datadir = Path(testdir, "data")
    for pdf_file in datadir.glob("*.pdf"):
        with pdf_file.open("rb") as fin:
            upload = UploadFile(file=fin, filename=pdf_file.name, headers=Headers({"content-type": "application/pdf"}))
            docs: list[Document] = converter.convert(upload, parameters)
            doc = docs[0]
            # Add additional metadata
            doc.metadata = {"foo": "bar"}
            json_file = pdf_file.with_suffix(".json")
            with json_file.open("w") as fout:
                print(docs[0].model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)
