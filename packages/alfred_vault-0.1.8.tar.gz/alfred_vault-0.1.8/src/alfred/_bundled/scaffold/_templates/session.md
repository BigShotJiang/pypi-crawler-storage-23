---
type: session
status: active # active | completed
name:
description:
intent: # What this session is for
project: # Link to Project (or process:)
process: # Link to Process (or project:)
participants: [] # Links to Person records
outputs: [] # Links to records created during session
related: []
relationships: []
created: "{{date}}"
tags: []
---

# {{title}}

## Intent

What this session is for.

## Related
![[related.base#All]]

## Outcome

Filled in on close — what was accomplished.
