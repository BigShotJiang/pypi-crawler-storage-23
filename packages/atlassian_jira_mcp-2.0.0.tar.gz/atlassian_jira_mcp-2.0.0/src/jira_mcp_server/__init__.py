__version__ = "2.0.0"
__author__ = "Troy Larson"
__license__ = "MIT"
