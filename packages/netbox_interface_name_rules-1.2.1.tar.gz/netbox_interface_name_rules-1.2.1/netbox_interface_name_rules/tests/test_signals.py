# SPDX-License-Identifier: Apache-2.0
# Copyright (C) 2025 Marcin Zieba <marcinpsk@gmail.com>
"""Tests for Django signal handlers: module post_save and device VC membership changes."""

from dcim.models import (
    Device,
    DeviceRole,
    DeviceType,
    Interface,
    Manufacturer,
    Module,
    ModuleBay,
    ModuleBayTemplate,
    ModuleType,
    Site,
    VirtualChassis,
)
from django.test import TestCase

from netbox_interface_name_rules.models import InterfaceNameRule
from netbox_interface_name_rules.signals import (
    _apply_rules_deferred,
    _apply_rules_for_device_deferred,
    on_device_pre_save,
    on_device_saved,
    on_module_pre_save,
    on_module_saved,
)


class SignalModuleHandlerTest(TestCase):
    """Test the module post_save signal handler and deferred rename helper."""

    @classmethod
    def setUpTestData(cls):
        """Create basic fixture for module signal tests."""
        manufacturer = Manufacturer.objects.create(name="SigMfg", slug="sigmfg")
        cls.device_type = DeviceType.objects.create(manufacturer=manufacturer, model="SIG-Dev", slug="sig-dev")
        cls.module_type = ModuleType.objects.create(manufacturer=manufacturer, model="SIG-SFP", part_number="SIG-SFP")
        cls.module_type2 = ModuleType.objects.create(
            manufacturer=manufacturer, model="SIG-QSFP", part_number="SIG-QSFP"
        )
        ModuleBayTemplate.objects.create(device_type=cls.device_type, name="SigBay 0", position="0")
        ModuleBayTemplate.objects.create(device_type=cls.device_type, name="SigBay 1", position="1")
        role = DeviceRole.objects.create(name="SigRole", slug="sigrole")
        site = Site.objects.create(name="SigSite", slug="sigsite")
        cls.device = Device.objects.create(name="sig-test-01", device_type=cls.device_type, role=role, site=site)
        cls.bay0 = ModuleBay.objects.get(device=cls.device, name="SigBay 0")
        cls.bay1 = ModuleBay.objects.get(device=cls.device, name="SigBay 1")

    # ------------------------------------------------------------------
    # _apply_rules_deferred
    # ------------------------------------------------------------------

    def test_deferred_apply_renames_interface(self):
        """_apply_rules_deferred calls apply_interface_name_rules and renames."""
        InterfaceNameRule.objects.create(
            module_type=self.module_type,
            name_template="et-0/0/{bay_position}",
        )
        module = Module.objects.create(device=self.device, module_bay=self.bay0, module_type=self.module_type)
        iface = Interface.objects.create(device=self.device, module=module, name="0", type="10gbase-x-sfpp")

        _apply_rules_deferred(module.pk, self.bay0.pk)

        iface.refresh_from_db()
        self.assertEqual(iface.name, "et-0/0/0")

    def test_deferred_apply_missing_module_no_error(self):
        """_apply_rules_deferred handles Module.DoesNotExist gracefully."""
        _apply_rules_deferred(999999, 999999)  # Non-existent PKs — should not raise

    def test_deferred_apply_no_rule_no_rename(self):
        """_apply_rules_deferred leaves interface unchanged when no rule matches."""
        module = Module.objects.create(device=self.device, module_bay=self.bay1, module_type=self.module_type)
        iface = Interface.objects.create(device=self.device, module=module, name="1", type="10gbase-x-sfpp")

        _apply_rules_deferred(module.pk, self.bay1.pk)

        iface.refresh_from_db()
        self.assertEqual(iface.name, "1")

    def test_deferred_apply_with_force_reapply(self):
        """_apply_rules_deferred with force_reapply=True re-applies rules."""
        InterfaceNameRule.objects.create(
            module_type=self.module_type,
            name_template="et-0/0/{bay_position}",
        )
        module = Module.objects.create(device=self.device, module_bay=self.bay0, module_type=self.module_type)
        # Interface with non-raw name — won't be renamed without force_reapply
        iface = Interface.objects.create(device=self.device, module=module, name="old-et", type="10gbase-x-sfpp")

        _apply_rules_deferred(module.pk, self.bay0.pk, force_reapply=True)

        iface.refresh_from_db()
        self.assertEqual(iface.name, "et-0/0/0")

    # ------------------------------------------------------------------
    # on_module_pre_save
    # ------------------------------------------------------------------

    def test_pre_save_new_module_sets_none(self):
        """on_module_pre_save sets _prev_module_type_id=None for new (unsaved) module."""
        module = Module(device=self.device, module_bay=self.bay0, module_type=self.module_type)
        on_module_pre_save(Module, module)
        self.assertIsNone(module._prev_module_type_id)

    def test_pre_save_existing_module_captures_type(self):
        """on_module_pre_save captures existing module_type_id for saved module."""
        module = Module.objects.create(device=self.device, module_bay=self.bay0, module_type=self.module_type)
        on_module_pre_save(Module, module)
        self.assertEqual(module._prev_module_type_id, self.module_type.pk)

    # ------------------------------------------------------------------
    # on_module_saved
    # ------------------------------------------------------------------

    def test_module_saved_created_returns_early(self):
        """on_module_saved with created=True schedules deferred callback (no error)."""
        module = Module.objects.create(device=self.device, module_bay=self.bay1, module_type=self.module_type)
        # created=True path schedules on_commit; we verify no exception is raised
        on_module_saved(Module, module, created=True)

    def test_module_saved_no_bay_returns_early(self):
        """on_module_saved with no module_bay exits cleanly."""
        module = Module(device=self.device, module_type=self.module_type)
        module.module_bay = None
        on_module_saved(Module, module, created=False)  # Should not raise

    def test_module_saved_type_unchanged_returns_early(self):
        """on_module_saved skips re-apply when module_type is unchanged."""
        module = Module.objects.create(device=self.device, module_bay=self.bay0, module_type=self.module_type)
        module._prev_module_type_id = module.module_type_id  # Same type
        on_module_saved(Module, module, created=False)  # Should not raise or rename

    def test_module_saved_type_changed_schedules_reapply(self):
        """on_module_saved schedules deferred reapply when module type changes."""
        module = Module.objects.create(device=self.device, module_bay=self.bay0, module_type=self.module_type)
        module._prev_module_type_id = self.module_type2.pk  # Different type
        # Should schedule on_commit callback — no error raised
        on_module_saved(Module, module, created=False)


class SignalDeviceHandlerTest(TestCase):
    """Test the device VC change signal handler and deferred rename helper."""

    @classmethod
    def setUpTestData(cls):
        """Create device with VC and module + interface for device signal tests."""
        manufacturer = Manufacturer.objects.create(name="SigDevMfg", slug="sigdevmfg")
        device_type = DeviceType.objects.create(manufacturer=manufacturer, model="SigDev-Switch", slug="sigdev-switch")
        ModuleBayTemplate.objects.create(device_type=device_type, name="SDBay 0", position="0")
        cls.module_type = ModuleType.objects.create(
            manufacturer=manufacturer, model="SigDev-SFP", part_number="SigDev-SFP"
        )
        role = DeviceRole.objects.create(name="SigDevRole", slug="sigdevrole")
        site = Site.objects.create(name="SigDevSite", slug="sigdevsite")

        cls.vc = VirtualChassis.objects.create(name="sigdev-vc")
        cls.device = Device.objects.create(
            name="sigdev-sw1",
            device_type=device_type,
            role=role,
            site=site,
            virtual_chassis=cls.vc,
            vc_position=1,
        )
        cls.bay = ModuleBay.objects.get(device=cls.device, name="SDBay 0")
        cls.module = Module.objects.create(device=cls.device, module_bay=cls.bay, module_type=cls.module_type)

    # ------------------------------------------------------------------
    # on_device_pre_save
    # ------------------------------------------------------------------

    def test_pre_save_new_device_sets_none(self):
        """on_device_pre_save stores None for a brand-new unsaved device."""
        new_dev = Device(name="new-dev")
        on_device_pre_save(Device, new_dev)
        self.assertIsNone(new_dev._prev_virtual_chassis_id)
        self.assertIsNone(new_dev._prev_vc_position)

    def test_pre_save_existing_device_captures_values(self):
        """on_device_pre_save captures virtual_chassis_id and vc_position from DB."""
        on_device_pre_save(Device, self.device)
        self.assertEqual(self.device._prev_virtual_chassis_id, self.vc.pk)
        self.assertEqual(self.device._prev_vc_position, 1)

    # ------------------------------------------------------------------
    # on_device_saved
    # ------------------------------------------------------------------

    def test_device_saved_created_returns_early(self):
        """on_device_saved with created=True exits immediately."""
        self.device._prev_virtual_chassis_id = None
        on_device_saved(Device, self.device, created=True)  # No error

    def test_device_saved_no_change_returns_early(self):
        """on_device_saved when VC and position are unchanged does nothing."""
        self.device._prev_virtual_chassis_id = self.vc.pk
        self.device._prev_vc_position = 1
        on_device_saved(Device, self.device, created=False)  # No error

    def test_device_saved_removed_from_vc_returns_early(self):
        """on_device_saved when device leaves VC (new_vc=None) does not schedule rename."""
        self.device._prev_virtual_chassis_id = self.vc.pk
        self.device._prev_vc_position = 1
        # Simulate device removed from VC
        self.device.virtual_chassis = None
        self.device.virtual_chassis_id = None
        on_device_saved(Device, self.device, created=False)  # No error, no rename scheduled
        # Restore for other tests
        self.device.virtual_chassis = self.vc
        self.device.virtual_chassis_id = self.vc.pk

    def test_device_saved_vc_position_change_schedules_rename(self):
        """on_device_saved when vc_position changes schedules deferred rename."""
        self.device._prev_virtual_chassis_id = self.vc.pk
        self.device._prev_vc_position = 99  # Was 99, now 1
        # Should schedule on_commit — no error raised
        on_device_saved(Device, self.device, created=False)

    # ------------------------------------------------------------------
    # _apply_rules_for_device_deferred
    # ------------------------------------------------------------------

    def test_deferred_device_missing_no_error(self):
        """_apply_rules_for_device_deferred handles Device.DoesNotExist gracefully."""
        _apply_rules_for_device_deferred(999999)  # Non-existent PK — should not raise

    def test_deferred_device_module_rules_applied(self):
        """_apply_rules_for_device_deferred re-applies module rules with force_reapply."""
        InterfaceNameRule.objects.create(
            module_type=self.module_type,
            name_template="et-0/0/{bay_position}",
        )
        iface = Interface.objects.create(device=self.device, module=self.module, name="old-sig", type="10gbase-x-sfpp")

        _apply_rules_for_device_deferred(self.device.pk)

        iface.refresh_from_db()
        self.assertEqual(iface.name, "et-0/0/0")

    def test_deferred_device_no_modules_no_error(self):
        """_apply_rules_for_device_deferred with device having no modules runs without error."""
        manufacturer = Manufacturer.objects.create(name="SigDevMfg2", slug="sigdevmfg2")
        dt = DeviceType.objects.create(manufacturer=manufacturer, model="SD2-Switch", slug="sd2-switch")
        role = DeviceRole.objects.create(name="SD2Role", slug="sd2role")
        site = Site.objects.create(name="SD2Site", slug="sd2site")
        vc = VirtualChassis.objects.create(name="sd2-vc")
        device_no_modules = Device.objects.create(
            name="sd2-sw-nomod",
            device_type=dt,
            role=role,
            site=site,
            virtual_chassis=vc,
            vc_position=2,
        )
        _apply_rules_for_device_deferred(device_no_modules.pk)  # Should not raise
