"""Run the SDGym benchmark on cloud instances."""
