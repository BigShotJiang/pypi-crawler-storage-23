"""Version information for gac package."""

__version__ = "3.13.0"
