"""
简化 API 示例 - 展示 EventSystem 的用法

Simple API Demo - Demonstrates EventSystem usage
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import time
from efr.simple import EventSystem, PrioritizedEventSystem


def basic_example():
    """基础示例 - Basic example"""
    print("\n" + "=" * 60)
    print("Simple API - Basic Example")
    print("=" * 60)
    
    # 创建事件系统
    events = EventSystem()
    
    # 存储结果
    notifications = []
    
    # 注册监听器
    def on_user_login(data):
        msg = f"User '{data['user']}' logged in from {data['ip']}"
        print(f"  [Login Handler] {msg}")
        notifications.append(msg)
    
    def on_user_logout(data):
        msg = f"User '{data['user']}' logged out"
        print(f"  [Logout Handler] {msg}")
        notifications.append(msg)
    
    # 监听事件
    events.listenFor("user_login", on_user_login)
    events.listenFor("user_logout", on_user_logout)
    
    # 推送事件
    print("\n[1] Pushing events...")
    events.pushEvent("user_login", {"user": "alice", "ip": "192.168.1.100"})
    events.pushEvent("user_login", {"user": "bob", "ip": "192.168.1.101"})
    events.pushEvent("user_logout", {"user": "alice"})
    
    # 等待处理
    time.sleep(0.5)
    
    print(f"\n[2] Total notifications: {len(notifications)}")
    
    # 停止系统
    events.stop()
    print("✓ Example completed!")


def source_filtering_example():
    """源过滤示例 - Source filtering example"""
    print("\n" + "=" * 60)
    print("Simple API - Source Filtering Example")
    print("=" * 60)
    
    events = EventSystem()
    
    # 只接收来自 "auth_service" 的事件
    def on_auth_event(data):
        print(f"  [Auth Handler] Received: {data}")
    
    events.listenFor("security_event", on_auth_event, "auth_service")
    
    print("\n[1] Pushing from auth_service (should be received)...")
    events.pushEvent("security_event", {"source": "auth_service", "action": "login_attempt"})
    
    print("\n[2] Pushing from other_service (should be ignored)...")
    events.pushEvent("security_event", {"source": "other_service", "action": "suspicious"})
    
    time.sleep(0.3)
    events.stop()
    print("✓ Example completed!")


def priority_example():
    """优先级示例 - Priority example"""
    print("\n" + "=" * 60)
    print("Simple API - Priority Example")
    print("=" * 60)
    
    events = PrioritizedEventSystem()
    
    execution_order = []
    
    def high_priority_handler(data):
        execution_order.append("HIGH")
        print("  [HIGH Priority] Executed first!")
    
    def medium_priority_handler(data):
        execution_order.append("MEDIUM")
        print("  [MEDIUM Priority] Executed second!")
    
    def low_priority_handler(data):
        execution_order.append("LOW")
        print("  [LOW Priority] Executed last!")
    
    # 注册不同优先级的监听器（数值越高越优先）
    events.listenFor("test_event", low_priority_handler, priority=1)
    events.listenFor("test_event", high_priority_handler, priority=10)
    events.listenFor("test_event", medium_priority_handler, priority=5)
    
    print("\n[1] Pushing event...")
    events.pushEvent("test_event", {"message": "Hello"})
    
    time.sleep(0.3)
    
    print(f"\n[2] Execution order: {' -> '.join(execution_order)}")
    
    events.stop()
    print("✓ Example completed!")


def method_chaining_example():
    """方法链式调用示例 - Method chaining example"""
    print("\n" + "=" * 60)
    print("Simple API - Method Chaining Example")
    print("=" * 60)
    
    events = EventSystem()
    
    # 链式调用注册多个监听器
    (events
        .listenFor("event1", lambda d: print(f"  [Handler 1] {d}"))
        .listenFor("event2", lambda d: print(f"  [Handler 2] {d}"))
        .listenFor("event3", lambda d: print(f"  [Handler 3] {d}")))
    
    print("\n[1] Pushing events using method chaining...")
    events.pushEvent("event1", "Data 1")
    events.pushEvent("event2", "Data 2")
    events.pushEvent("event3", "Data 3")
    
    time.sleep(0.3)
    
    events.stop()
    print("✓ Example completed!")


def main():
    """运行所有示例 - Run all examples"""
    print("\n" + "=" * 60)
    print("efr Simple API - Usage Examples")
    print("=" * 60)
    
    basic_example()
    source_filtering_example()
    priority_example()
    method_chaining_example()
    
    print("\n" + "=" * 60)
    print("All examples completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    main()
