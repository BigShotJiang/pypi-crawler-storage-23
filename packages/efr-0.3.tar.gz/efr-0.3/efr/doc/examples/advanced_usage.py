"""
高级用法示例 - 展示 efr 框架的高级功能

Advanced Usage Example - Demonstrates advanced features
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import time
import threading
from efr import EventFramework, Event, EventStation, EventState


def parallel_execution_example():
    """并行执行示例 - Parallel execution example"""
    print("\n" + "=" * 60)
    print("Advanced - Parallel Execution Example")
    print("=" * 60)
    
    results = []
    
    def background_task():
        results.append(1)
        print(f"  [Parallel Task] Executed ({len(results)} times)")
    
    print("\n[1] Starting parallel task (5 times, 0.2s interval)...")
    worker = EventFramework.parallel(
        background_task,
        delta=0.2,
        count=5
    )
    
    # 等待任务完成
    time.sleep(1.5)
    worker.stop()
    
    print(f"\n[2] Task executed {len(results)} times")
    print("✓ Example completed!")


def event_result_collection_example():
    """事件结果收集示例 - Event result collection"""
    print("\n" + "=" * 60)
    print("Advanced - Event Result Collection")
    print("=" * 60)
    
    framework = EventFramework(name="result_collection")
    
    # 多个处理器
    def validator(event):
        print("  [Validator] Validating...")
        return {"valid": True, "checked_by": "validator"}
    
    def enricher(event):
        print("  [Enricher] Enriching data...")
        return {"enriched": True, "processed_by": "enricher"}
    
    def notifier(event):
        print("  [Notifier] Sending notification...")
        return {"notified": True, "sent_by": "notifier"}
    
    # 创建工作站
    v_station = EventStation(key="validator", respond_fn=validator, level=30)
    e_station = EventStation(key="enricher", respond_fn=enricher, level=20)
    n_station = EventStation(key="notifier", respond_fn=notifier, level=10)
    
    # 添加工作线程
    framework.add_worker("validator_worker", timedt=0.05)
    framework.add_worker("enricher_worker", timedt=0.05)
    framework.add_worker("notifier_worker", timedt=0.05)
    
    # 注册工作站
    framework.login(v_station)
    framework.login(e_station)
    framework.login(n_station)
    
    framework.start()
    
    # 推送事件
    print("\n[1] Pushing event...")
    event = Event(
        task={"user_id": "U123", "action": "purchase"},
        times_left=0  # 0 表示所有工作站都处理
    )
    framework.push(event)
    
    # 等待处理完成
    print("\n[2] Waiting for all stations to process...")
    success = event.wait_for(EventState.RETIRED, timeout=3.0)
    
    if success:
        print("\n[3] Results from all stations:")
        for station_key, result in event.result.items():
            print(f"  - {station_key}: {result}")
    else:
        print("  Timeout waiting for processing")
    
    framework.quit()
    print("✓ Example completed!")


def concurrent_event_processing_example():
    """并发事件处理示例 - Concurrent event processing"""
    print("\n" + "=" * 60)
    print("Advanced - Concurrent Event Processing")
    print("=" * 60)
    
    framework = EventFramework(name="concurrent_test")
    results = []
    lock = threading.Lock()
    
    def processor(event):
        # 模拟处理时间
        time.sleep(0.1)
        with lock:
            results.append(event.task)
        return "processed"
    
    station = EventStation(key="concurrent_processor", respond_fn=processor)
    worker = framework.add_worker("processor", timedt=0.01)
    framework.login(station, worker)
    framework.start()
    
    print("\n[1] Pushing 20 events concurrently...")
    threads = []
    for i in range(20):
        t = threading.Thread(
            target=lambda n: framework.push(Event(task=f"job_{n}", dest="concurrent_processor")),
            args=(i,)
        )
        threads.append(t)
        t.start()
    
    # 等待所有推送完成
    for t in threads:
        t.join()
    
    print("\n[2] Waiting for processing...")
    time.sleep(3.0)
    
    print(f"\n[3] Processed {len(results)} events")
    
    framework.quit()
    print("✓ Example completed!")


def custom_filter_example():
    """自定义过滤器示例 - Custom filter example"""
    print("\n" + "=" * 60)
    print("Advanced - Custom Filter Example")
    print("=" * 60)
    
    framework = EventFramework(name="filter_test")
    
    # 只处理金额大于 100 的订单
    def high_value_filter(event):
        amount = event.task.get("amount", 0)
        return amount > 100
    
    def high_value_handler(event):
        order_id = event.task.get("order_id")
        amount = event.task.get("amount")
        print(f"  [High Value] Processing order {order_id} with amount ${amount}")
        return "high_value_processed"
    
    # 只处理紧急事件
    def urgent_filter(event):
        return "urgent" in event.tags
    
    def urgent_handler(event):
        print(f"  [Urgent] Handling urgent event: {event.task}")
        return "urgent_processed"
    
    # 创建工作站
    high_value_station = EventStation(
        key="high_value_processor",
        filter_fn=high_value_filter,
        respond_fn=high_value_handler
    )
    
    urgent_station = EventStation(
        key="urgent_processor",
        filter_fn=urgent_filter,
        respond_fn=urgent_handler
    )
    
    framework.login(high_value_station)
    framework.login(urgent_station)
    framework.start()
    
    print("\n[1] Pushing various events...")
    
    # 高价值订单
    framework.push(Event(task={"order_id": "ORD-001", "amount": 150.0}, dest="high_value_processor"))
    framework.push(Event(task={"order_id": "ORD-002", "amount": 50.0}, dest="high_value_processor"))  # 会被过滤
    framework.push(Event(task={"order_id": "ORD-003", "amount": 500.0}, dest="high_value_processor"))
    
    # 紧急事件
    framework.push(Event(task="System alert", tags={"urgent"}, dest="urgent_processor"))
    framework.push(Event(task="Regular notification", tags={"info"}, dest="urgent_processor"))  # 会被过滤
    
    time.sleep(1.0)
    
    framework.quit()
    print("✓ Example completed!")


def main():
    """运行所有高级示例"""
    print("\n" + "=" * 60)
    print("efr Framework - Advanced Usage Examples")
    print("=" * 60)
    
    parallel_execution_example()
    event_result_collection_example()
    concurrent_event_processing_example()
    custom_filter_example()
    
    print("\n" + "=" * 60)
    print("All advanced examples completed successfully!")
    print("=" * 60)


if __name__ == "__main__":
    main()
