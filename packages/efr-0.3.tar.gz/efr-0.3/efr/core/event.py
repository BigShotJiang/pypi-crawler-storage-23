"""
Event Module - Core event class and state definitions for the efr library.

事件模块 - efr库的核心事件类和状态定义。
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Set, TypeVar, Generic, Union


class EventState(Enum):
    """
    Event lifecycle states enumeration.
    
    事件生命周期状态枚举。
    
    Attributes:
        OFFLINE: Event is created but not yet in queue
        JUNIOR: Event is in queue waiting for processing
        URGENT: Event is being processed
        FINISH: Event has been successfully processed at least once
        RETIRED: Event has been processed by all stations
        EXCEPT: Event processing encountered an exception
    """
    OFFLINE = auto()
    JUNIOR = auto()
    URGENT = auto()
    FINISH = auto()
    RETIRED = auto()
    EXCEPT = auto()

    def __str__(self) -> str:
        return self.name.lower()

    def __repr__(self) -> str:
        return f"EventState.{self.name}"


T = TypeVar('T')
R = TypeVar('R')


@dataclass
class Event(Generic[T, R]):
    """
    Core Event class representing a unit of work in the event framework.
    
    核心事件类，表示事件框架中的工作单元。
    
    Type Parameters:
        T: The type of the task payload
        R: The type of the result
    
    Attributes:
        trace: Unique identifier for tracking
        task: The actual task/payload to be processed
        result: Dictionary storing processing results
        source: Source component that created the event
        dest: Destination component for processing
        tags: Set of tags for categorization
        state: Current lifecycle state
        times: Dictionary of timestamps
        links: Reference count for tracking processing completion
        times_left: How many more stations should process this event
        priority: Priority level (higher = more urgent)
        error: Error message if state is EXCEPT
    """
    
    # Core attributes
    trace: str = field(default_factory=lambda: str(uuid.uuid4()))
    task: Optional[T] = None
    result: Dict[str, Any] = field(default_factory=dict)
    
    # Routing attributes
    source: Optional[str] = None
    dest: Optional[str] = None
    
    # Categorization
    tags: Set[str] = field(default_factory=set)
    
    # State management
    state: EventState = field(default=EventState.OFFLINE)
    
    # Timing tracking
    times: Dict[str, float] = field(default_factory=lambda: {"created": time.time()})
    
    # Processing tracking
    links: int = field(default=0)
    times_left: int = field(default=0)
    
    # Priority level
    priority: int = field(default=0)
    
    # Error information
    error: Optional[str] = None
    
    def __post_init__(self) -> None:
        """Post-initialization to ensure proper setup."""
        if isinstance(self.tags, (list, tuple)):
            object.__setattr__(self, 'tags', set(self.tags))
        if 'created' not in self.times:
            self.times['created'] = time.time()
    
    def set_state(self, state: EventState) -> None:
        """Update the event state and record timestamp."""
        self.state = state
        self.times[state.name.lower()] = time.time()
    
    def add_tag(self, tag: str) -> None:
        """Add a tag to the event."""
        self.tags.add(tag)
    
    def remove_tag(self, tag: str) -> None:
        """Remove a tag from the event."""
        self.tags.discard(tag)
    
    def has_tag(self, tag: str) -> bool:
        """Check if event has a specific tag."""
        return tag in self.tags
    
    def add_result(self, key: str, value: Any) -> None:
        """Add a result entry to the event."""
        self.result[key] = value
    
    def get_result(self, key: Optional[str] = None, default: Any = None) -> Any:
        """
        Get a result value by key.
        
        Args:
            key: The result key, if None returns first result
            default: Default value if key not found
            
        Returns:
            The result value or default
        """
        if key is not None:
            return self.result.get(key, default)
        else:
            values = list(self.result.values())
            return values[0] if values else default
    
    def set_error(self, error_msg: str) -> None:
        """Set error state with message."""
        self.error = error_msg
        self.set_state(EventState.EXCEPT)
    
    def is_offline(self) -> bool:
        """Check if event is in OFFLINE state."""
        return self.state == EventState.OFFLINE
    
    def is_junior(self) -> bool:
        """Check if event is in JUNIOR or URGENT state."""
        return self.state in (EventState.JUNIOR, EventState.URGENT)
    
    def is_urgent(self) -> bool:
        """Check if event is in URGENT state."""
        return self.state == EventState.URGENT
    
    def is_finish(self) -> bool:
        """Check if event is in FINISH or RETIRED state."""
        return self.state in (EventState.FINISH, EventState.RETIRED)
    
    def is_retired(self) -> bool:
        """Check if event is in RETIRED state."""
        return self.state == EventState.RETIRED
    
    def is_except(self) -> bool:
        """Check if event is in EXCEPT state."""
        return self.state == EventState.EXCEPT
    
    def wait_for(self, state: EventState, timeout: Optional[float] = None, interval: float = 0.01) -> bool:
        """
        Wait for event to reach specified state.
        
        Args:
            state: Target state to wait for
            timeout: Maximum time to wait (None = infinite)
            interval: Polling interval in seconds
            
        Returns:
            True if state reached, False if timeout
        """
        start = time.time()
        while self.state != state:
            if timeout is not None and time.time() - start > timeout:
                return False
            time.sleep(interval)
        return True
    
    def __str__(self) -> str:
        return f"Event[trace={self.trace[:8]}..., state={self.state}, source={self.source}, dest={self.dest}]"
    
    def __repr__(self) -> str:
        return (f"Event(trace='{self.trace}', state={self.state}, "
                f"source={self.source}, dest={self.dest}, task={self.task})")
