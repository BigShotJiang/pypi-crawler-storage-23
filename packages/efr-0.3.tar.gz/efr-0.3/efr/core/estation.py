"""
Event Station Module - Event processing station.

事件站点模块 - 事件处理站点。
"""

from __future__ import annotations

import threading
import traceback
from typing import Any, Callable, List, Optional, TypeVar, Generic

from efr.core.event import Event, EventState
from efr.core.equeue import EventQueue
from efr.core.eerrors import SolutionMissing


T = TypeVar('T')
R = TypeVar('R')

# Type aliases for filter and responder functions
EventFilter = Callable[[Event[T, R]], bool]
EventResponder = Callable[[Event[T, R]], Any]


class EventStation(EventQueue[T, R]):
    """
    Event processing station with filtering and response capabilities.
    
    具有过滤和响应功能的事件处理站点。
    
    Type Parameters:
        T: The type of the task payload
        R: The type of the result
    
    Attributes:
        key: Station identifier
        level: Priority level (higher = processed first)
    """
    
    def __init__(
        self,
        key: Optional[str] = None,
        filter_fn: Optional[EventFilter] = None,
        respond_fn: Optional[EventResponder] = None,
        level: int = 0,
        step: Optional[int] = None,
        timeout: Optional[float] = None,
        capacity: int = 0
    ) -> None:
        """
        Initialize the event station.
        
        Args:
            key: Station identifier (default: class name)
            filter_fn: Filter function (event) -> bool
            respond_fn: Responder function (event) -> result
            level: Priority level (higher = more important)
            step: Max events to process per update
            timeout: Timeout for event retrieval
            capacity: Queue capacity (0 = unlimited)
        """
        super().__init__(capacity=capacity, name=key)
        
        self.key: str = key or self.__class__.__name__
        self.level: int = level
        self.step: Optional[int] = step
        self.timeout: Optional[float] = timeout
        
        self._filter_fn: Optional[EventFilter] = filter_fn
        self._respond_fn: Optional[EventResponder] = respond_fn
        
        self._worker: Any = None
        self._task: Any = None
        self._lock: threading.Lock = threading.Lock()
    
    def filter(self, event: Event[T, R]) -> bool:
        """
        Filter events to determine if this station should process them.
        
        Default filter checks if event.dest matches station.key.
        
        Args:
            event: The event to filter
            
        Returns:
            True if station should process this event
        """
        if self._filter_fn:
            return self._filter_fn(event)
        return self.key == event.dest
    
    def respond(self, event: Event[T, R]) -> Any:
        """
        Process the event and return result.
        
        Args:
            event: The event to process
            
        Returns:
            Processing result
        """
        if self._respond_fn:
            return self._respond_fn(event)
        return None
    
    def push(self, event: Event[T, R], timeout: Optional[float] = None) -> bool:
        """
        Push an event to this station.
        
        Args:
            event: The event to push
            timeout: Maximum time to wait
            
        Returns:
            True if successful
        """
        result = super().push(event, timeout)
        if result:
            # Initialize result slot for this station
            event.result[self.key] = None
            if event.is_junior():
                event.set_state(EventState.URGENT)
            event.links += 1
            return True
        return False
    
    def update(self) -> None:
        """
        Process pending events.
        Called by worker thread.
        """
        events = self.release(self.step, self.timeout)
        
        for event in events:
            if event.is_except():
                continue
            
            try:
                result = self.respond(event)
            except Exception as err:
                event.set_error(str(err))
                err.trace = traceback.format_exc()  # type: ignore
                # Log error through framework if available
                if self._efr and hasattr(self._efr, '_log'):
                    self._efr._log(f"Error processing event {event.trace}: {err}")
                continue
            
            if not event.is_except():
                event.result[self.key] = result
                event.links -= 1
                if event.links <= 0:
                    event.set_state(EventState.RETIRED)
                else:
                    event.set_state(EventState.FINISH)
    
    def __eq__(self, other: object) -> bool:
        """Check equality based on key and functions."""
        if not isinstance(other, EventStation):
            return NotImplemented
        return (self.key == other.key and 
                self._filter_fn == other._filter_fn and 
                self._respond_fn == other._respond_fn)
    
    def __hash__(self) -> int:
        """Hash based on key."""
        return hash(self.key)
    
    def __str__(self) -> str:
        return f"EventStation[{self.key}](level={self.level}, size={self.qsize()})"
    
    def __repr__(self) -> str:
        return self.__str__()
