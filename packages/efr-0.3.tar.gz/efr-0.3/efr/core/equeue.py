"""
Event Queue Module - Thread-safe event queue implementation.

事件队列模块 - 线程安全的事件队列实现。
"""

from __future__ import annotations

import threading
from queue import Queue, Empty, Full
from typing import Any, List, Optional, TypeVar, Generic

from efr.core.event import Event, EventState


T = TypeVar('T')
R = TypeVar('R')


class EventQueue(Generic[T, R]):
    """
    Thread-safe event queue with capacity support.
    
    具有容量支持的线程安全事件队列。
    
    Type Parameters:
        T: The type of the task payload
        R: The type of the result
    
    Attributes:
        capacity: Maximum number of events (0 = unlimited)
        name: Optional name for the queue
    """
    
    def __init__(self, capacity: int = 0, name: Optional[str] = None) -> None:
        """
        Initialize the event queue.
        
        Args:
            capacity: Maximum queue capacity (0 = unlimited)
            name: Optional queue name
        """
        self._capacity: int = max(0, capacity)
        self._name: Optional[str] = name
        self._queue: Queue = Queue(maxsize=capacity if capacity > 0 else 0)
        self._lock: threading.Lock = threading.Lock()
        self._efr: Any = None
    
    @property
    def efr(self) -> Any:
        """Get the associated EventFramework."""
        return self._efr
    
    @efr.setter
    def efr(self, value: Any) -> None:
        """Set the associated EventFramework."""
        self._efr = value
    
    def push(self, event: Event[T, R], timeout: Optional[float] = None) -> Optional[Event[T, R]]:
        """
        Push an event into the queue.
        
        Args:
            event: The event to push
            timeout: Maximum time to wait if queue is full
            
        Returns:
            The event if successful, None if failed
        """
        try:
            self._queue.put(event, block=True, timeout=timeout)
            event.efr = self._efr
            if event.is_offline():
                event.set_state(EventState.JUNIOR)
            return event
        except Full:
            return None
    
    def get(self, timeout: Optional[float] = None) -> Optional[Event[T, R]]:
        """
        Get an event from the queue.
        
        Args:
            timeout: Maximum time to wait if queue is empty
            
        Returns:
            The event if available, None if timeout
        """
        try:
            return self._queue.get(block=True, timeout=timeout)
        except Empty:
            return None
    
    def release(self, num: Optional[int] = None, timeout: Optional[float] = None) -> List[Event[T, R]]:
        """
        Get multiple events from the queue.
        
        Args:
            num: Maximum number of events to get (None = all available)
            timeout: Maximum time to wait for first event
            
        Returns:
            List of retrieved events
        """
        events: List[Event[T, R]] = []
        
        # Get first event with timeout
        first = self.get(timeout=timeout)
        if first is None:
            return events
        events.append(first)
        
        # Get remaining events without blocking
        if num is None:
            num = float('inf')  # type: ignore
        while len(events) < num:
            event = self.get(timeout=0)
            if event is None:
                break
            events.append(event)
        
        return events
    
    def qsize(self) -> int:
        """Get current queue size."""
        return self._queue.qsize()
    
    def empty(self) -> bool:
        """Check if queue is empty."""
        return self._queue.empty()
    
    def full(self) -> bool:
        """Check if queue is full."""
        return self._queue.full()
    
    @property
    def capacity(self) -> int:
        """Get queue capacity (0 = unlimited)."""
        return self._capacity
    
    def __len__(self) -> int:
        """Return queue size."""
        return self.qsize()
    
    def __bool__(self) -> bool:
        """Return True if queue has items."""
        return not self.empty()
    
    def __str__(self) -> str:
        name = f"'{self._name}'" if self._name else "unnamed"
        return f"EventQueue[{name}](size={self.qsize()}, capacity={self._capacity or 'unlimited'})"
    
    def __repr__(self) -> str:
        return self.__str__()
