"""
Event Framework Module - Main framework integrating all components.

事件框架模块 - 整合所有组件的主框架。
"""

from __future__ import annotations

import time
from math import inf
from typing import Any, Callable, List, Optional, TypeVar, Union

from loguru import logger

from efr.core.event import Event, EventState
from efr.core.equeue import EventQueue
from efr.core.estation import EventStation
from efr.core.ealloter import EventAlloter
from efr.utils.task import Task, ONCE, CIRCLE
from efr.utils.worker import Worker


T = TypeVar('T')
R = TypeVar('R')


class _ParamNone:
    """Sentinel class for distinguishing None from unset parameter."""
    pass


PARAM_NONE = _ParamNone()


class EventFramework:
    """
    Main event-driven framework integrating all components.
    
    主事件驱动框架，整合所有组件。
    
    The framework provides:
    - Event queue management
    - Station registration and management
    - Worker thread pool
    - Event distribution and processing
    - Logging support
    
    Example:
        >>> efr = EventFramework(name="my_app")
        >>> station = EventStation(key="processor", respond_fn=process_event)
        >>> efr.login(station)
        >>> efr.push(Event(task="data", dest="processor"))
        >>> efr.start()
        >>> time.sleep(10)
        >>> efr.quit()
    """
    
    def __init__(
        self,
        name: Optional[str] = None,
        capacity: Optional[int] = None,
        step: Optional[int] = None,
        timeout: Optional[float] = None,
        timedt: float = 0.1,
        log_path: Optional[str] = None,
        log_level: str = "INFO",
        log_immediate: bool = True,
        log_format: Optional[str] = None
    ) -> None:
        """
        Initialize the event framework.
        
        Args:
            name: Framework name (None = auto-generated)
            capacity: Event queue capacity (None = unlimited)
            step: Events to process per update (None = unlimited)
            timeout: Event retrieval timeout (None = infinite)
            timedt: Worker loop interval in seconds
            log_path: Log file path (None = no logging)
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            log_immediate: Write logs immediately vs batch
            log_format: Log message format (None = use default)
        """
        from efr.utils.id_generator import NewRandomID
        
        self.name: str = name or f"efr_{NewRandomID(8)}"
        self.timedt: float = timedt
        self.log_path: Optional[str] = log_path
        self.log_level: str = log_level.upper()
        self.log_immediate: bool = log_immediate
        
        self._start_flag: bool = False
        self._worker_id: int = 0
        self._quit_logs: List[Any] = []
        
        # Initialize logger
        self._logger = logger.bind(framework=self.name)
        self._init_logger(log_format)
        
        # Create components
        self._equeue: EventQueue = EventQueue(capacity=capacity or 0)
        self._ealloter: EventAlloter = EventAlloter(self._equeue, step, timeout)
        
        # Link components to framework
        self._equeue.efr = self
        self._ealloter.efr = self
        
        # Workers
        self._workers: List[Worker] = []
        self._default_worker: Worker = self.add_worker('default_worker')
        self._default_worker.add_task(Task(self.update, times=CIRCLE))
    
    def _init_logger(self, log_format: Optional[str] = None) -> None:
        """Initialize logging configuration with loguru."""
        # Remove existing handlers for this framework
        self._logger = logger.bind(framework=self.name)
        
        if self.log_path:
            # Clear log file
            open(self.log_path, 'w').close()
            
            # Add file handler with loguru
            fmt = log_format or "{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}"
            logger.add(
                self.log_path,
                level=self.log_level,
                format=fmt,
                filter=lambda record: record["extra"].get("framework") == self.name,
                enqueue=True
            )
    
    def _log(self, item: Any, level: str = "INFO") -> None:
        """Log an item immediately or queue for batch logging."""
        if self.log_path or self.log_immediate:
            if isinstance(item, Exception):
                self._logger.exception(item)
            elif isinstance(item, Warning):
                self._logger.warning(str(item))
            else:
                self._logger.log(level, str(item))
        else:
            self._quit_logs.append((item, level))
    
    def _output_logs(self) -> None:
        """Output all queued logs."""
        for log, level in self._quit_logs:
            if isinstance(log, Exception):
                self._logger.exception(log)
            elif isinstance(log, Warning):
                self._logger.warning(str(log))
            else:
                self._logger.log(level, str(log))
        self._quit_logs.clear()
    
    def _new_worker(self, name: Optional[str] = None, timedt: Optional[float] = None) -> Worker:
        """Create a new worker instance."""
        self._worker_id += 1
        worker_name = name or f"worker_{self._worker_id - 1}_of_{self.name}"
        worker = Worker(name=worker_name, mindt=timedt or self.timedt)
        if self._start_flag:
            worker.start()
        return worker
    
    @property
    def stations(self) -> List[EventStation]:
        """Get all registered stations."""
        return self._ealloter.stations
    
    def start(self) -> None:
        """Start the event framework and all workers."""
        self._log(f"{self.name} starting...")
        self._start_flag = True
        for worker in self._workers:
            if not worker.is_alive():
                worker.start()
        self._log(f"{self.name} started")
    
    def quit(self) -> None:
        """Stop the event framework and all workers."""
        self._log(f"{self.name} quitting...")
        self._start_flag = False
        for worker in self._workers:
            worker.stop()
        self._output_logs()
        self._log(f"{self.name} quit")
    
    def login(self, station: EventStation, worker: Optional[Worker] = None) -> bool:
        """
        Register a station with the framework.
        
        Args:
            station: The station to register
            worker: Optional worker to assign for processing
            
        Returns:
            True if registered successfully
        """
        result = self._ealloter.login(station)
        if result and worker:
            self.assign(worker, station)
        return result
    
    def logoff(self, station: EventStation) -> bool:
        """
        Unregister a station from the framework.
        
        Args:
            station: The station to unregister
            
        Returns:
            True if unregistered
        """
        result = self._ealloter.logoff(station)
        if result:
            self.assign(None, station)
        return result
    
    def push(self, event: Event[T, R], timeout: Optional[float] = None) -> Optional[Event[T, R]]:
        """
        Push an event into the framework.
        
        Args:
            event: The event to push
            timeout: Maximum time to wait if queue is full
            
        Returns:
            The event if successful, None if failed
        """
        return self._equeue.push(event, timeout)
    
    def config(
        self,
        step: Union[int, _ParamNone] = PARAM_NONE,
        timeout: Union[float, _ParamNone] = PARAM_NONE,
        log_path: Union[str, _ParamNone] = PARAM_NONE,
        log_immediate: Union[bool, _ParamNone] = PARAM_NONE,
        log_format: Union[str, _ParamNone] = PARAM_NONE,
        log_level: Union[str, _ParamNone] = PARAM_NONE
    ) -> None:
        """
        Configure framework parameters.
        
        Args:
            step: Events to process per update
            timeout: Event retrieval timeout
            log_path: Log file path
            log_immediate: Write logs immediately
            log_format: Log message format
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        """
        if not isinstance(step, _ParamNone):
            self._ealloter.step = step
        if not isinstance(timeout, _ParamNone):
            self._ealloter.timeout = timeout
        if not isinstance(log_path, _ParamNone):
            self.log_path = log_path
            self._init_logger()
        if not isinstance(log_immediate, _ParamNone):
            if not self.log_immediate and log_immediate:
                self._output_logs()
            self.log_immediate = log_immediate
        if not isinstance(log_format, _ParamNone):
            self.log_format = log_format
            self._init_logger()
        if not isinstance(log_level, _ParamNone):
            self.log_level = log_level.upper()
            self._init_logger()
    
    def assign(self, worker: Optional[Worker], station: EventStation) -> bool:
        """
        Assign a worker to a station.
        
        Args:
            worker: The worker to assign (None to unassign)
            station: The station to assign to
            
        Returns:
            True if assignment successful
        """
        if worker is None:
            # Unassign worker
            if station._worker:
                station._worker.remove_task(station._task)
                station._worker = None
                station._task = None
            return True
        else:
            # Assign worker
            if station not in self._ealloter.stations:
                self.login(station)
            station._worker = worker
            station._task = Task(station.update, times=CIRCLE)
            return worker.add_task(station._task)
    
    def add_worker(self, name: Optional[str] = None, timedt: Optional[float] = None) -> Worker:
        """
        Add a new worker to the framework.
        
        Args:
            name: Worker name
            timedt: Worker loop interval
            
        Returns:
            The created worker
        """
        worker = self._new_worker(name, timedt)
        self._workers.append(worker)
        return worker
    
    def remove_worker(self, worker: Worker) -> bool:
        """
        Remove a worker from the framework.
        
        Args:
            worker: The worker to remove
            
        Returns:
            True if removed
        """
        try:
            self._workers.remove(worker)
            worker.stop()
            return True
        except ValueError:
            return False
    
    def update(self) -> None:
        """Update the framework - process events."""
        self._ealloter.update()
    
    @staticmethod
    def parallel(
        task: Union[Task, Callable],
        *fn_args: Any,
        delta: float = 0.5,
        count: int = 1,
        **fn_kwgs: Any
    ) -> Worker:
        """
        Execute a task in parallel using a temporary worker.
        
        Args:
            task: Task or callable to execute
            fn_args: Arguments for callable
            delta: Worker interval
            count: Execution count (for callables)
            fn_kwgs: Keyword arguments for callable
            
        Returns:
            The worker executing the task
        """
        worker = Worker(mindt=delta, always=False)
        
        if isinstance(task, Task):
            worker.add_task(task)
        else:
            t = Task(task, fn_args, fn_kwgs, times=count)
            worker.add_task(t)
        
        worker.start()
        return worker
    
    def __str__(self) -> str:
        return f"EventFramework[{self.name}](workers={len(self._workers)}, stations={len(self.stations)})"
    
    def __repr__(self) -> str:
        return self.__str__()


# Convenience alias
Parallel = EventFramework.parallel
