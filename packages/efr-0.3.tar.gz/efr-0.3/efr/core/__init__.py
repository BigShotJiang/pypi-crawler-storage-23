"""
efr.core - Core event system components

This module provides the fundamental components of the event-driven framework:
- Event: Event class with lifecycle states
- EventQueue: Thread-safe event queue
- EventStation: Event processing station
- EventAlloter: Event allocator for distributing events
- EventFramework: Main framework integrating all components
"""

from efr.core.event import Event, EventState
from efr.core.equeue import EventQueue
from efr.core.estation import EventStation
from efr.core.ealloter import EventAlloter
from efr.core.eframework import EventFramework
from efr.core.eerrors import SolutionMissing, WorkerError, TaskError, FrameworkError

__all__ = [
    "Event",
    "EventState", 
    "EventQueue",
    "EventStation",
    "EventAlloter",
    "EventFramework",
    "SolutionMissing",
    "WorkerError",
    "TaskError",
    "FrameworkError",
]
