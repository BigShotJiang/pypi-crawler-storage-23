"""
Error Classes Module - Custom exceptions for efr core.

错误类模块 - efr核心的自定义异常。
"""

from __future__ import annotations

from typing import Any, Optional


class FrameworkError(Exception):
    """Base exception for framework errors."""
    pass


class SolutionMissing(FrameworkError):
    """
    Exception raised when an event is refused by all stations.
    
    当事件被所有站点拒绝时引发的异常。
    """
    
    def __init__(self, *args: Any, event: Optional[Any] = None) -> None:
        super().__init__(*args)
        self.event = event
    
    def __str__(self) -> str:
        txt = '\n[SolutionMissing]: Event refused by all stations.\n'
        if self.event:
            txt += f"\tEvent: {self.event}\n"
        if self.args:
            txt += "\tDetails:"
            for info in self.args:
                txt += f"\n\t\t{info}"
        return txt


class WorkerError(FrameworkError):
    """Exception raised for worker-related errors."""
    pass


class TaskError(FrameworkError):
    """Exception raised for task-related errors."""
    pass


class StationError(FrameworkError):
    """Exception raised for station-related errors."""
    pass


class QueueError(FrameworkError):
    """Exception raised for queue-related errors."""
    pass
