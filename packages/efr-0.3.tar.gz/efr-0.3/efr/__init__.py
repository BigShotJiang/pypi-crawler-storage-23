"""
efr - Efficient Event-Driven Framework for Python 3.14+

efr是一个高效的事件驱动框架，提供了完整的事件处理、工作站管理和线程安全的事件分配机制。

主要组件:
- Event: 事件类，表示事件驱动框架中的工作单元
- EventQueue: 线程安全的事件队列
- EventStation: 事件工作站，处理特定类型的事件
- EventAlloter: 事件分配器，将事件分发到相应的工作站
- EventFramework: 主框架，整合所有组件

简化API:
- EventSystem: 简化的事件系统，提供发布-订阅模式
- PrioritizedEventSystem: 支持优先级的简化事件系统

工具模块:
- Worker: 工作线程，循环执行任务
- Task: 任务类，表示可执行单元
- Trace: 错误追踪工具
- IdGenerator: ID生成器

Usage:
    # 使用核心框架
    from efr import EventFramework, Event, EventStation
    
    efr = EventFramework(name="my_framework")
    station = EventStation(name="processor")
    efr.login(station)
    efr.push(Event(task="hello", dest="processor"))
    
    # 使用简化API
    from efr.simple import EventSystem
    
    events = EventSystem()
    events.listenFor("event_name", callback_func)
    events.pushEvent("event_name", data)
"""

from __future__ import annotations

# Core components
from efr.core.event import Event, EventState
from efr.core.equeue import EventQueue
from efr.core.estation import EventStation
from efr.core.ealloter import EventAlloter
from efr.core.eframework import EventFramework
from efr.core.eerrors import SolutionMissing, WorkerError, TaskError, FrameworkError

# Utilities
from efr.utils.functions import singleton, EmptyFunction
from efr.utils.id_generator import NewRandom, NewRandomID
from efr.utils.task import Task, ONCE, CIRCLE
from efr.utils.worker import Worker
from efr.utils.trace import Trace
from efr.utils.exceptions import (
    SolutionMissing as UtilsSolutionMissing,
    WorkerError as UtilsWorkerError,
    TaskError as UtilsTaskError,
    TraceError,
    IDGenerationError
)

# Version info
__version__ = "2.0.0"
__author__ = "efr Team"
__all__ = [
    # Core
    "Event",
    "EventState",
    "EventQueue",
    "EventStation",
    "EventAlloter",
    "EventFramework",
    # Errors
    "SolutionMissing",
    "WorkerError",
    "TaskError",
    "FrameworkError",
    # Utils
    "singleton",
    "EmptyFunction",
    "NewRandom",
    "NewRandomID",
    "Task",
    "ONCE",
    "CIRCLE",
    "Worker",
    "Trace",
]
