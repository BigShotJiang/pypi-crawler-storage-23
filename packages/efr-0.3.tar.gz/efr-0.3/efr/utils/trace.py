"""
Trace Module - Error tracing utility.

追踪模块 - 错误追踪工具。
"""

from __future__ import annotations

import traceback
from typing import Any, List, Optional


class Trace:
    """
    Error tracing utility for tracking exceptions.
    
    错误追踪工具，用于跟踪异常。
    
    Captures stack trace information and collects errors for later analysis.
    
    Attributes:
        caller: Name of the direct caller
        initial: Name of the initial caller
        errors: List of captured errors
    """
    
    def __init__(self) -> None:
        """Initialize trace and capture stack information."""
        stack = traceback.extract_stack()
        # Stack[-1] is __init__, stack[-2] is caller, stack[-3] is initial
        self.caller: str = stack[-2][2] if len(stack) >= 2 else "unknown"
        self.initial: str = stack[-3][2] if len(stack) >= 3 else "unknown"
        self._errors: List[Exception] = []
    
    @property
    def reason(self) -> List[Exception]:
        """Get list of captured errors."""
        return self._errors.copy()
    
    def update(self, err: Optional[Exception] = None, efr: Optional[Any] = None) -> None:
        """
        Update trace with an error.
        
        Args:
            err: The exception to record
            efr: Optional framework for logging
        """
        if err:
            self._errors.append(err)
            if efr and hasattr(efr, 'log_immediate'):
                if efr.log_immediate and hasattr(efr, '_logger'):
                    efr._logger.error(self.str_error(err))
                elif hasattr(efr, '_quit_logs'):
                    efr._quit_logs.append(err)
    
    @staticmethod
    def str_error(error: Exception) -> str:
        """
        Format an exception as a string.
        
        Args:
            error: The exception to format
            
        Returns:
            Formatted error string with traceback
        """
        if not isinstance(error, Exception):
            return str(error)
        
        # Check if error already has trace
        if hasattr(error, 'trace'):
            return str(error.trace)
        
        # Format traceback
        tb = error.__traceback__
        if tb is None:
            return f"{error.__class__.__name__}: {error}"
        
        lines = traceback.format_exception(type(error), error, tb)
        return ''.join(lines)
    
    def __str__(self) -> str:
        return f"Trace[caller={self.caller}, errors={len(self._errors)}]"
    
    def __repr__(self) -> str:
        return self.__str__()
