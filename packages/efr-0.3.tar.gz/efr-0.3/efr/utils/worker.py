"""
Worker Module - Thread-based task executor.

工作线程模块 - 基于线程的任务执行器。
"""

from __future__ import annotations

import threading
import time
from typing import Any, List, Optional

from efr.utils.task import Task, STOPTASK


class Worker(threading.Thread):
    """
    Worker thread that executes tasks in a loop.
    
    工作线程，循环执行任务。
    
    The worker runs in a loop, executing all pending tasks each iteration.
    It can be configured to run continuously or stop when tasks are empty.
    
    Attributes:
        mindt: Minimum loop interval in seconds
        always: Whether to keep running when no tasks
        alive: Whether the worker should continue running
    
    Example:
        >>> def work():
        ...     print("Working...")
        >>> worker = Worker(mindt=1.0)
        >>> worker.add_task(Task(work, times=Task.CIRCLE))
        >>> worker.start()
        >>> time.sleep(5)
        >>> worker.stop()
    """
    
    def __init__(
        self,
        name: Optional[str] = None,
        daemon: bool = True,
        mindt: float = 0.5,
        always: bool = True
    ) -> None:
        """
        Initialize the worker.
        
        Args:
            name: Worker thread name
            daemon: Whether to run as daemon thread
            mindt: Minimum loop interval
            always: Keep running even when no tasks
        """
        super().__init__(name=name, daemon=daemon)
        self.mindt: float = mindt
        self.always: bool = always
        self.alive: bool = True
        self._tasks: List[Task] = []
        self._lock: threading.Lock = threading.Lock()
    
    def run(self) -> None:
        """Main worker loop."""
        while self.alive:
            next_time = time.time() + self.mindt
            
            # Execute all pending tasks
            with self._lock:
                tasks = self._tasks.copy()
            
            remaining: List[Task] = []
            for task in tasks:
                try:
                    task()
                except Exception as e:
                    # Log error but continue
                    print(f"Task error: {e}")
                
                if task.left > 0:
                    remaining.append(task)
                
                if not self.alive:
                    break
            
            with self._lock:
                self._tasks = remaining
            
            # Auto-stop if not always and no tasks
            if not self.always and not self._tasks:
                self.alive = False
                break
            
            # Sleep until next iteration
            sleep_time = next_time - time.time()
            if sleep_time > 0:
                time.sleep(sleep_time)
    
    def add_task(self, task: Task) -> bool:
        """
        Add a task to the worker.
        
        Args:
            task: The task to add
            
        Returns:
            True if added successfully
        """
        with self._lock:
            self._tasks.append(task)
        return True
    
    def remove_task(self, task: Task) -> bool:
        """
        Remove a task from the worker.
        
        Args:
            task: The task to remove
            
        Returns:
            True if removed
        """
        with self._lock:
            try:
                self._tasks.remove(task)
                return True
            except ValueError:
                return False
    
    def stop(self) -> None:
        """Signal the worker to stop."""
        self.alive = False
    
    def has_tasks(self) -> bool:
        """Check if worker has pending tasks."""
        with self._lock:
            return len(self._tasks) > 0
    
    def task_count(self) -> int:
        """Get number of pending tasks."""
        with self._lock:
            return len(self._tasks)
    
    def __str__(self) -> str:
        return f"Worker[{self.name}](tasks={self.task_count()}, alive={self.alive})"
    
    def __repr__(self) -> str:
        return self.__str__()
