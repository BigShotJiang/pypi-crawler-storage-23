"""
Utility Functions Module - General utility functions.

通用工具函数模块。
"""

from __future__ import annotations

import threading
from functools import wraps
from typing import Any, Callable, Dict, TypeVar


F = TypeVar('F', bound=Callable[..., Any])


def singleton(cls: F) -> F:
    """
    Singleton decorator - ensures only one instance of a class exists.
    
    单例装饰器 - 确保类只有一个实例。
    
    Thread-safe implementation using double-checked locking.
    
    Args:
        cls: The class to make singleton
        
    Returns:
        The singleton class wrapper
        
    Example:
        >>> @singleton
        ... class MyClass:
        ...     pass
        >>> a = MyClass()
        >>> b = MyClass()
        >>> a is b
        True
    """
    instances: Dict[type, Any] = {}
    lock = threading.Lock()
    
    @wraps(cls)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        if cls not in instances:
            with lock:
                if cls not in instances:
                    instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    
    return wrapper


def EmptyFunction(*args: Any, **kwargs: Any) -> None:
    """
    A function that does nothing and returns None.
    
    一个什么都不做并返回None的函数。
    
    Useful as a default callback or placeholder.
    """
    pass


def identity(x: Any) -> Any:
    """Return the input unchanged."""
    return x


def constant(value: Any) -> Callable[..., Any]:
    """Create a function that always returns the given value."""
    def _const(*args: Any, **kwargs: Any) -> Any:
        return value
    return _const
