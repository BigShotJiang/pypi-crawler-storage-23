"""
Exceptions Module - Custom exceptions for efr utils.

异常模块 - efr工具的自定义异常。
"""

from __future__ import annotations

from typing import Any, Optional


class EFRUtilError(Exception):
    """Base exception for efr utility errors."""
    pass


class SolutionMissing(EFRUtilError):
    """Exception raised when no solution is found."""
    
    def __init__(self, *args: Any, event: Optional[Any] = None) -> None:
        super().__init__(*args)
        self.event = event
    
    def __str__(self) -> str:
        txt = '\n[SolutionMissing]: No solution found.\n'
        if self.event:
            txt += f"\tEvent: {self.event}\n"
        if self.args:
            txt += "\tDetails:"
            for info in self.args:
                txt += f"\n\t\t{info}"
        return txt


class WorkerError(EFRUtilError):
    """Exception raised for worker-related errors."""
    pass


class TaskError(EFRUtilError):
    """Exception raised for task-related errors."""
    pass


class TraceError(EFRUtilError):
    """Exception raised for tracing-related errors."""
    pass


class IDGenerationError(EFRUtilError):
    """Exception raised for ID generation errors."""
    pass
