"""
efr.simple - Simplified event API for the efr library.

This module provides a simplified publish-subscribe API built on top of
the core efr components. It's designed for ease of use while maintaining
the power and flexibility of the underlying framework.

简化的事件API模块，基于efr核心组件构建。提供易于使用的发布-订阅模式。

Example:
    >>> from efr.simple import EventSystem
    
    >>> events = EventSystem()
    >>> events.listenFor("user_login", on_login, "auth_service")
    >>> events.pushEvent("user_login", {"user": "alice"})
    
    >>> # With priority
    >>> from efr.simple import PrioritizedEventSystem
    >>> events = PrioritizedEventSystem()
    >>> events.listenFor("critical", handle_critical, priority=10)
"""

from efr.simple.api import EventListener, EventSystem, PrioritizedEventSystem

__all__ = [
    "EventListener",
    "EventSystem",
    "PrioritizedEventSystem",
]
