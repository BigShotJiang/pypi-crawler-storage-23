"""
Simple API Module - Simplified event system API.

简化API模块 - 简化的事件系统API。
"""

from __future__ import annotations

import threading
import traceback
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set, FrozenSet

from efr.core.event import Event, EventState
from efr.core.estation import EventStation
from efr.core.eframework import EventFramework
from efr.utils.worker import Worker


# Type alias for callbacks
EventCallback = Callable[[Any], Any]


@dataclass(frozen=True)
class EventListener:
    """
    Immutable event listener representation.
    
    不可变的事件监听器表示。
    
    Attributes:
        callback: The callback function
        sources: Set of source filters
    """
    callback: EventCallback
    sources: FrozenSet[str] = field(default_factory=frozenset)
    
    def __hash__(self) -> int:
        return hash((id(self.callback), self.sources))
    
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, EventListener):
            return NotImplemented
        return self.callback == other.callback and self.sources == other.sources


class EventSystem:
    """
    Simplified event system with publish-subscribe pattern.
    
    简化的发布-订阅事件系统。
    
    Built on top of efr core components while providing a cleaner API.
    
    Example:
        >>> events = EventSystem()
        >>> events.listenFor("data", process_data, "source1")
        >>> events.pushEvent("data", {"key": "value"})
    """
    
    def __init__(self) -> None:
        """Initialize the event system."""
        # Internal framework
        self._framework: EventFramework = EventFramework(
            name=f"simple_events_{id(self)}",
            log_immediate=False
        )
        
        # Event name -> listeners mapping
        self._listeners: Dict[str, Set[EventListener]] = defaultdict(set)
        
        # Event name -> station mapping
        self._stations: Dict[str, EventStation] = {}
        
        # Lock for thread safety
        self._lock: threading.Lock = threading.Lock()
        
        # Start framework
        self._framework.start()
    
    def listenFor(
        self,
        event: str,
        callback: EventCallback,
        *sources: str
    ) -> EventSystem:
        """
        Register a listener for an event.

        Args:
            event: Event name to listen for
            callback: Function to call when event is received
            *sources: Optional source filters

        Returns:
            self for method chaining
        """
        with self._lock:
            listener = EventListener(
                callback=callback,
                sources=frozenset(sources) if sources else frozenset()
            )
            self._listeners[event].add(listener)

            # Create station if not exists
            if event not in self._stations:
                station = EventStation(
                    key=event,
                    respond_fn=self._create_responder(event)
                )
                self._stations[event] = station
                self._framework.login(station)

        return self

    def listen(
        self,
        event: str,
        *sources: str
    ) -> Callable[[EventCallback], EventCallback]:
        """
        Decorator to register a listener for an event.

        装饰器语法糖，用于注册事件监听器。

        Args:
            event: Event name to listen for
            *sources: Optional source filters

        Returns:
            Decorator function that registers the callback and returns it unchanged

        Example:
            >>> events = EventSystem()
            >>> @events.listen("user_login")
            ... def on_login(data):
            ...     print(f"User logged in: {data}")
            >>> @events.listen("security_alert", "auth_service")
            ... def on_security(data):
            ...     print(f"Security alert: {data}")
        """
        def decorator(callback: EventCallback) -> EventCallback:
            self.listenFor(event, callback, *sources)
            return callback
        return decorator
    
    def pushEvent(
        self,
        event: str,
        data: Any = None,
        *targets: str
    ) -> int:
        """
        Push an event to all matching listeners.
        
        Args:
            event: Event name to push
            data: Data to pass to listeners
            *targets: Optional target filters
            
        Returns:
            Number of listeners that received the event
        """
        with self._lock:
            if event not in self._listeners:
                return 0
            
            listeners = self._listeners[event].copy()
        
        delivered = 0
        
        for listener in listeners:
            # Check source filtering
            if listener.sources:
                event_sources = self._extract_sources(data)
                if event_sources and not listener.sources.intersection(event_sources):
                    continue
            
            # Check target filtering
            if targets:
                callback_name = getattr(listener.callback, '__name__', '')
                if not any(t in callback_name for t in targets):
                    continue
            
            # Deliver event
            try:
                listener.callback(data)
                delivered += 1
            except Exception as e:
                self._handle_delivery_error(event, listener, e)
        
        return delivered
    
    def cancelListen(
        self,
        event: str,
        callback: Optional[EventCallback] = None
    ) -> bool:
        """
        Cancel listening to an event.
        
        Args:
            event: Event name to stop listening for
            callback: Specific callback to remove (None = all)
            
        Returns:
            True if any listeners were removed
        """
        with self._lock:
            if event not in self._listeners:
                return False
            
            if callback is None:
                # Remove all listeners for this event
                removed = len(self._listeners[event]) > 0
                del self._listeners[event]
                if event in self._stations:
                    self._framework.logoff(self._stations[event])
                    del self._stations[event]
                return removed
            
            # Find and remove specific callback
            to_remove = None
            for listener in self._listeners[event]:
                if listener.callback == callback:
                    to_remove = listener
                    break
            
            if to_remove:
                self._listeners[event].discard(to_remove)
                if not self._listeners[event]:
                    del self._listeners[event]
                    if event in self._stations:
                        self._framework.logoff(self._stations[event])
                        del self._stations[event]
                return True
            
            return False
    
    def hasListeners(self, event: str) -> bool:
        """Check if there are any listeners for an event."""
        with self._lock:
            return event in self._listeners and len(self._listeners[event]) > 0
    
    def getListenerCount(self, event: str) -> int:
        """Get the number of listeners for an event."""
        with self._lock:
            return len(self._listeners.get(event, set()))
    
    def getEvents(self) -> List[str]:
        """Get a list of all events with listeners."""
        with self._lock:
            return list(self._listeners.keys())
    
    def clear(self) -> None:
        """Remove all listeners."""
        with self._lock:
            for event in list(self._stations.keys()):
                self._framework.logoff(self._stations[event])
            self._listeners.clear()
            self._stations.clear()
    
    def stop(self) -> None:
        """Stop the event system."""
        self._framework.quit()
    
    def _create_responder(self, event_name: str) -> Callable[[Event], Any]:
        """Create a responder function for a station."""
        def responder(event: Event) -> Any:
            # This is called by the framework
            # The actual delivery happens in pushEvent
            pass
        return responder
    
    def _extract_sources(self, data: Any) -> Optional[Set[str]]:
        """Extract source information from event data."""
        if data is None:
            return None
        
        # Handle dict
        if isinstance(data, dict):
            if 'source' in data:
                return {data['source']}
            if 'sources' in data:
                sources = data['sources']
                if isinstance(sources, (list, tuple, set)):
                    return set(sources)
                return {sources}
        
        # Handle object with attributes
        if hasattr(data, 'source'):
            return {data.source}
        if hasattr(data, 'sources'):
            sources = data.sources
            if isinstance(sources, (list, tuple, set)):
                return set(sources)
            return {sources}
        
        # Handle string
        if isinstance(data, str):
            return {data}
        
        return None
    
    def _handle_delivery_error(
        self,
        event: str,
        listener: EventListener,
        error: Exception
    ) -> None:
        """Handle errors during event delivery."""
        # Default: silently ignore
        pass
    
    def __repr__(self) -> str:
        with self._lock:
            total = sum(len(v) for v in self._listeners.values())
            return f"EventSystem(events={len(self._listeners)}, listeners={total})"
    
    def __len__(self) -> int:
        """Return total number of listeners."""
        with self._lock:
            return sum(len(v) for v in self._listeners.values())


@dataclass(order=True)
class _PrioritizedListener:
    """Internal prioritized listener wrapper."""
    priority: int
    listener: EventListener = field(compare=False)


class PrioritizedEventSystem(EventSystem):
    """
    Event system with priority-based delivery.
    
    基于优先级的发布-订阅事件系统。
    
    Listeners can be registered with priority (higher = earlier delivery).
    
    Example:
        >>> events = PrioritizedEventSystem()
        >>> events.listenFor("event", handler1, priority=5)
        >>> events.listenFor("event", handler2, priority=10)  # Delivered first
    """
    
    def __init__(self) -> None:
        """Initialize the prioritized event system."""
        super().__init__()
        self._prioritized: Dict[str, List[_PrioritizedListener]] = defaultdict(list)
    
    def listenFor(
        self,
        event: str,
        callback: EventCallback,
        *sources: str,
        priority: int = 0
    ) -> PrioritizedEventSystem:
        """
        Register a listener with optional priority.

        Args:
            event: Event name to listen for
            callback: Function to call when event is received
            *sources: Optional source filters
            priority: Priority level (higher = earlier delivery)

        Returns:
            self for method chaining
        """
        with self._lock:
            listener = EventListener(
                callback=callback,
                sources=frozenset(sources) if sources else frozenset()
            )

            pl = _PrioritizedListener(priority=priority, listener=listener)
            self._prioritized[event].append(pl)
            # Sort by priority (descending)
            self._prioritized[event].sort(key=lambda x: x.priority, reverse=True)

            # Also add to base listeners
            self._listeners[event].add(listener)

            # Create station if not exists
            if event not in self._stations:
                station = EventStation(
                    key=event,
                    respond_fn=self._create_responder(event)
                )
                self._stations[event] = station
                self._framework.login(station)

        return self

    def listen(
        self,
        event: str,
        *sources: str,
        priority: int = 0
    ) -> Callable[[EventCallback], EventCallback]:
        """
        Decorator to register a listener with optional priority.

        装饰器语法糖，用于注册带优先级的事件监听器。

        Args:
            event: Event name to listen for
            *sources: Optional source filters
            priority: Priority level (higher = earlier delivery)

        Returns:
            Decorator function that registers the callback and returns it unchanged

        Example:
            >>> events = PrioritizedEventSystem()
            >>> @events.listen("critical_event", priority=10)
            ... def handle_critical(data):
            ...     print(f"Critical: {data}")
            >>> @events.listen("normal_event", "auth_service", priority=5)
            ... def handle_normal(data):
            ...     print(f"Normal: {data}")
        """
        def decorator(callback: EventCallback) -> EventCallback:
            self.listenFor(event, callback, *sources, priority=priority)
            return callback
        return decorator
    
    def pushEvent(
        self,
        event: str,
        data: Any = None,
        *targets: str
    ) -> int:
        """
        Push event with priority-ordered delivery.
        
        Args:
            event: Event name to push
            data: Data to pass to listeners
            *targets: Optional target filters
            
        Returns:
            Number of listeners that received the event
        """
        with self._lock:
            if event not in self._prioritized:
                return 0
            
            prioritized_list = self._prioritized[event].copy()
        
        delivered = 0
        
        for pl in prioritized_list:
            listener = pl.listener
            
            # Check source filtering
            if listener.sources:
                event_sources = self._extract_sources(data)
                if event_sources and not listener.sources.intersection(event_sources):
                    continue
            
            # Check target filtering
            if targets:
                callback_name = getattr(listener.callback, '__name__', '')
                if not any(t in callback_name for t in targets):
                    continue
            
            # Deliver event
            try:
                listener.callback(data)
                delivered += 1
            except Exception as e:
                self._handle_delivery_error(event, listener, e)
        
        return delivered
    
    def cancelListen(
        self,
        event: str,
        callback: Optional[EventCallback] = None
    ) -> bool:
        """
        Cancel listening with priority-aware removal.
        
        Args:
            event: Event name to stop listening for
            callback: Specific callback to remove (None = all)
            
        Returns:
            True if any listeners were removed
        """
        with self._lock:
            if event not in self._prioritized:
                return False
            
            if callback is None:
                # Remove all
                removed = len(self._prioritized[event]) > 0
                del self._prioritized[event]
                if event in self._listeners:
                    del self._listeners[event]
                if event in self._stations:
                    self._framework.logoff(self._stations[event])
                    del self._stations[event]
                return removed
            
            # Remove specific callback
            original_len = len(self._prioritized[event])
            self._prioritized[event] = [
                pl for pl in self._prioritized[event]
                if pl.listener.callback != callback
            ]
            
            if len(self._prioritized[event]) < original_len:
                # Also remove from base listeners
                for listener in list(self._listeners.get(event, set())):
                    if listener.callback == callback:
                        self._listeners[event].discard(listener)
                        break
                
                if not self._prioritized[event]:
                    del self._prioritized[event]
                    if event in self._listeners:
                        del self._listeners[event]
                    if event in self._stations:
                        self._framework.logoff(self._stations[event])
                        del self._stations[event]
                return True
            
            return False
    
    def clear(self) -> None:
        """Remove all listeners."""
        with self._lock:
            self._prioritized.clear()
            super().clear()
    
    def __repr__(self) -> str:
        with self._lock:
            total = sum(len(v) for v in self._prioritized.values())
            return f"PrioritizedEventSystem(events={len(self._prioritized)}, listeners={total})"
