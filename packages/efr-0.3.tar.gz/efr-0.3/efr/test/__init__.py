"""
efr.test - Test suite for the efr library.

This module provides comprehensive tests for all efr components.
Run with: python -m unittest discover -s efr.test
"""

# Test modules are imported automatically by unittest
