"""
Test Worker Module - Tests for Worker class.

测试工作线程模块 - Worker类的测试。
"""

import unittest
import time
from efr.utils.worker import Worker
from efr.utils.task import Task, ONCE, CIRCLE


class TestWorker(unittest.TestCase):
    """Test cases for Worker class."""
    
    def test_worker_creation(self) -> None:
        """Test basic worker creation."""
        worker = Worker(name="test_worker")
        self.assertEqual(worker.name, "test_worker")
        self.assertTrue(worker.daemon)
        self.assertTrue(worker.alive)
        self.assertEqual(worker.task_count(), 0)
    
    def test_add_task(self) -> None:
        """Test adding tasks to worker."""
        worker = Worker()
        task = Task(target=lambda: None, times=ONCE)
        
        result = worker.add_task(task)
        self.assertTrue(result)
        self.assertEqual(worker.task_count(), 1)
    
    def test_remove_task(self) -> None:
        """Test removing tasks from worker."""
        worker = Worker()
        task = Task(target=lambda: None, times=ONCE)
        
        worker.add_task(task)
        self.assertEqual(worker.task_count(), 1)
        
        result = worker.remove_task(task)
        self.assertTrue(result)
        self.assertEqual(worker.task_count(), 0)
    
    def test_task_execution(self) -> None:
        """Test task execution."""
        results = []
        
        def work():
            results.append(1)
        
        worker = Worker(mindt=0.01)
        task = Task(target=work, times=ONCE)
        
        worker.add_task(task)
        worker.start()
        
        time.sleep(0.1)
        worker.stop()
        worker.join()
        
        self.assertEqual(len(results), 1)
    
    def test_circular_task(self) -> None:
        """Test circular (infinite) task."""
        results = []
        
        def work():
            results.append(1)
            if len(results) >= 5:
                worker.stop()
        
        worker = Worker(mindt=0.01, always=True)
        task = Task(target=work, times=CIRCLE)
        
        worker.add_task(task)
        worker.start()
        worker.join(timeout=1.0)
        
        self.assertGreaterEqual(len(results), 5)
    
    def test_auto_stop(self) -> None:
        """Test auto-stop when tasks empty and always=False."""
        results = []
        
        def work():
            results.append(1)
        
        worker = Worker(mindt=0.01, always=False)
        task = Task(target=work, times=ONCE)
        
        worker.add_task(task)
        worker.start()
        worker.join(timeout=1.0)
        
        self.assertEqual(len(results), 1)
        self.assertFalse(worker.is_alive())
    
    def test_stop(self) -> None:
        """Test stopping worker."""
        worker = Worker()
        worker.start()
        self.assertTrue(worker.is_alive())
        
        worker.stop()
        worker.join(timeout=1.0)
        self.assertFalse(worker.is_alive())
    
    def test_multiple_tasks(self) -> None:
        """Test multiple tasks execution."""
        results = []
        
        def work1(): results.append("work1")
        def work2(): results.append("work2")
        
        worker = Worker(mindt=0.01)
        worker.add_task(Task(target=work1, times=ONCE))
        worker.add_task(Task(target=work2, times=ONCE))
        
        worker.start()
        time.sleep(0.1)
        worker.stop()
        worker.join()
        
        self.assertIn("work1", results)
        self.assertIn("work2", results)


if __name__ == '__main__':
    unittest.main()
