"""
Test Event Module - Tests for Event class.

测试事件模块 - Event类的测试。
"""

import unittest
import time
from efr.core.event import Event, EventState


class TestEvent(unittest.TestCase):
    """Test cases for Event class."""
    
    def test_event_creation(self) -> None:
        """Test basic event creation."""
        event = Event()
        self.assertIsNotNone(event.trace)
        self.assertEqual(event.state, EventState.OFFLINE)
        self.assertEqual(event.links, 0)
        self.assertEqual(event.priority, 0)
    
    def test_event_with_params(self) -> None:
        """Test event creation with parameters."""
        event = Event(
            task="test_task",
            source="test_source",
            dest="test_dest",
            tags={"tag1", "tag2"},
            priority=5
        )
        self.assertEqual(event.task, "test_task")
        self.assertEqual(event.source, "test_source")
        self.assertEqual(event.dest, "test_dest")
        self.assertEqual(event.tags, {"tag1", "tag2"})
        self.assertEqual(event.priority, 5)
    
    def test_state_transitions(self) -> None:
        """Test state transitions."""
        event = Event()
        self.assertTrue(event.is_offline())
        
        event.set_state(EventState.JUNIOR)
        self.assertEqual(event.state, EventState.JUNIOR)
        self.assertTrue(event.is_junior())
        
        event.set_state(EventState.URGENT)
        self.assertEqual(event.state, EventState.URGENT)
        self.assertTrue(event.is_urgent())
        
        event.set_state(EventState.FINISH)
        self.assertEqual(event.state, EventState.FINISH)
        self.assertTrue(event.is_finish())
        
        event.set_state(EventState.RETIRED)
        self.assertEqual(event.state, EventState.RETIRED)
        self.assertTrue(event.is_retired())
    
    def test_error_state(self) -> None:
        """Test error state handling."""
        event = Event()
        event.set_error("Test error")
        self.assertEqual(event.state, EventState.EXCEPT)
        self.assertEqual(event.error, "Test error")
        self.assertTrue(event.is_except())
    
    def test_tag_management(self) -> None:
        """Test tag add/remove/has operations."""
        event = Event()
        event.add_tag("tag1")
        self.assertIn("tag1", event.tags)
        self.assertTrue(event.has_tag("tag1"))
        
        event.remove_tag("tag1")
        self.assertNotIn("tag1", event.tags)
        self.assertFalse(event.has_tag("tag1"))
    
    def test_result_management(self) -> None:
        """Test result storage and retrieval."""
        event = Event()
        event.add_result("key1", "value1")
        event.add_result("key2", 42)
        
        self.assertEqual(event.get_result("key1"), "value1")
        self.assertEqual(event.get_result("key2"), 42)
        self.assertIsNone(event.get_result("nonexistent"))
        self.assertEqual(event.get_result("nonexistent", "default"), "default")
    
    def test_wait_for(self) -> None:
        """Test wait_for functionality."""
        event = Event()
        
        # Test timeout
        result = event.wait_for(EventState.JUNIOR, timeout=0.01)
        self.assertFalse(result)
        
        # Test successful wait
        event.set_state(EventState.JUNIOR)
        result = event.wait_for(EventState.JUNIOR, timeout=0.1)
        self.assertTrue(result)
    
    def test_event_str(self) -> None:
        """Test string representation."""
        event = Event(source="src", dest="dst")
        str_repr = str(event)
        self.assertIn("Event", str_repr)
        self.assertIn("src", str_repr)
        self.assertIn("dst", str_repr)


if __name__ == '__main__':
    unittest.main()
