"""
Test Simple API Module - Tests for EventSystem and PrioritizedEventSystem.

测试简化API模块 - EventSystem和PrioritizedEventSystem的测试。
"""

import unittest
import time
from efr.simple import EventSystem, PrioritizedEventSystem


class TestEventSystem(unittest.TestCase):
    """Test cases for EventSystem class."""
    
    def setUp(self) -> None:
        """Set up test fixtures."""
        self.events = EventSystem()
    
    def tearDown(self) -> None:
        """Clean up after tests."""
        self.events.stop()
    
    def test_listen_and_push(self) -> None:
        """Test basic listen and push."""
        results = []
        
        def callback(data):
            results.append(data)
        
        self.events.listenFor("test_event", callback)
        count = self.events.pushEvent("test_event", "hello")
        
        self.assertEqual(count, 1)
        self.assertEqual(results, ["hello"])
    
    def test_multiple_listeners(self) -> None:
        """Test multiple listeners for same event."""
        results1 = []
        results2 = []
        
        self.events.listenFor("event", lambda d: results1.append(d))
        self.events.listenFor("event", lambda d: results2.append(d))
        
        count = self.events.pushEvent("event", "data")
        
        self.assertEqual(count, 2)
        self.assertEqual(results1, ["data"])
        self.assertEqual(results2, ["data"])
    
    def test_source_filtering(self) -> None:
        """Test source filtering."""
        results = []
        
        def callback(data):
            results.append(data)
        
        # Listen only for events from "source1"
        self.events.listenFor("event", callback, "source1")
        
        # Push with matching source
        count1 = self.events.pushEvent("event", {"source": "source1", "data": 1})
        self.assertEqual(count1, 1)
        
        # Push with non-matching source
        count2 = self.events.pushEvent("event", {"source": "source2", "data": 2})
        self.assertEqual(count2, 0)
    
    def test_cancel_listen(self) -> None:
        """Test canceling listeners."""
        results = []
        
        def callback(data):
            results.append(data)
        
        self.events.listenFor("event", callback)
        self.events.pushEvent("event", "first")
        self.assertEqual(len(results), 1)
        
        # Cancel specific callback
        self.events.cancelListen("event", callback)
        self.events.pushEvent("event", "second")
        self.assertEqual(len(results), 1)  # No change
    
    def test_cancel_all(self) -> None:
        """Test canceling all listeners for an event."""
        self.events.listenFor("event", lambda d: None)
        self.events.listenFor("event", lambda d: None)
        
        self.assertEqual(self.events.getListenerCount("event"), 2)
        
        self.events.cancelListen("event")
        
        self.assertEqual(self.events.getListenerCount("event"), 0)
    
    def test_has_listeners(self) -> None:
        """Test hasListeners method."""
        self.assertFalse(self.events.hasListeners("event"))
        
        self.events.listenFor("event", lambda d: None)
        self.assertTrue(self.events.hasListeners("event"))
    
    def test_get_events(self) -> None:
        """Test getEvents method."""
        self.events.listenFor("event1", lambda d: None)
        self.events.listenFor("event2", lambda d: None)
        
        events = self.events.getEvents()
        self.assertIn("event1", events)
        self.assertIn("event2", events)
    
    def test_clear(self) -> None:
        """Test clear method."""
        self.events.listenFor("event1", lambda d: None)
        self.events.listenFor("event2", lambda d: None)
        
        self.assertEqual(len(self.events), 2)
        
        self.events.clear()
        
        self.assertEqual(len(self.events), 0)
        self.assertFalse(self.events.hasListeners("event1"))
    
    def test_method_chaining(self) -> None:
        """Test method chaining."""
        result = (self.events
            .listenFor("event1", lambda d: None)
            .listenFor("event2", lambda d: None))

        self.assertIs(result, self.events)

    def test_listen_decorator(self) -> None:
        """Test @events.listen() decorator."""
        results = []

        @self.events.listen("test_event")
        def on_test(data):
            results.append(data)

        count = self.events.pushEvent("test_event", "decorator_test")

        self.assertEqual(count, 1)
        self.assertEqual(results, ["decorator_test"])

    def test_listen_decorator_with_source(self) -> None:
        """Test @events.listen() decorator with source filtering."""
        results = []

        @self.events.listen("alert", "security")
        def on_security_alert(data):
            results.append(data)

        # Should receive - matching source
        count1 = self.events.pushEvent("alert", {"source": "security", "msg": "breach"})
        self.assertEqual(count1, 1)

        # Should not receive - non-matching source
        count2 = self.events.pushEvent("alert", {"source": "system", "msg": "info"})
        self.assertEqual(count2, 0)

        self.assertEqual(len(results), 1)


class TestPrioritizedEventSystem(unittest.TestCase):
    """Test cases for PrioritizedEventSystem class."""
    
    def setUp(self) -> None:
        """Set up test fixtures."""
        self.events = PrioritizedEventSystem()
    
    def tearDown(self) -> None:
        """Clean up after tests."""
        self.events.stop()
    
    def test_priority_ordering(self) -> None:
        """Test priority-based delivery order."""
        results = []
        
        def high_priority(d): results.append("high")
        def low_priority(d): results.append("low")
        
        # Register low priority first
        self.events.listenFor("event", low_priority, priority=1)
        # Then high priority
        self.events.listenFor("event", high_priority, priority=10)
        
        self.events.pushEvent("event", None)
        
        # High priority should be delivered first
        self.assertEqual(results, ["high", "low"])
    
    def test_same_priority(self) -> None:
        """Test same priority delivery."""
        results = []

        self.events.listenFor("event", lambda d: results.append(1), priority=5)
        self.events.listenFor("event", lambda d: results.append(2), priority=5)

        self.events.pushEvent("event", None)

        # Both should be delivered
        self.assertEqual(len(results), 2)

    def test_listen_decorator_with_priority(self) -> None:
        """Test @events.listen() decorator with priority."""
        results = []

        @self.events.listen("event", priority=1)
        def low_priority(d):
            results.append("low")

        @self.events.listen("event", priority=10)
        def high_priority(d):
            results.append("high")

        self.events.pushEvent("event", None)

        # High priority should be delivered first
        self.assertEqual(results, ["high", "low"])

    def test_listen_decorator_with_priority_and_source(self) -> None:
        """Test @events.listen() decorator with both priority and source."""
        results = []

        @self.events.listen("alert", "security", priority=5)
        def on_security(d):
            results.append("security")

        @self.events.listen("alert", "firewall", priority=10)
        def on_firewall(d):
            results.append("firewall")

        # Firewall has higher priority
        self.events.pushEvent("alert", {"source": "firewall"})
        self.assertEqual(results, ["firewall"])

        results.clear()

        # Both should fire, firewall first due to priority
        self.events.pushEvent("alert", {"source": "security"})
        self.assertEqual(results, ["security"])


if __name__ == '__main__':
    unittest.main()
