"""
Integration Tests - End-to-end tests for the efr library.

集成测试 - efr库的端到端测试。
"""

import unittest
import time
import threading
from efr import EventFramework, Event, EventStation
from efr.simple import EventSystem


class TestIntegration(unittest.TestCase):
    """Integration test cases."""
    
    def test_end_to_end_event_flow(self) -> None:
        """Test complete event flow through the framework."""
        results = []
        
        def respond(event):
            results.append(event.task)
            return f"processed_{event.task}"
        
        # Create framework
        framework = EventFramework(name="integration_test")
        
        # Create and register station with worker
        station = EventStation(key="processor", respond_fn=respond)
        worker = framework.add_worker("processor_worker", timedt=0.05)
        framework.login(station, worker)
        
        # Start framework
        framework.start()
        
        # Push events
        for i in range(5):
            framework.push(Event(task=f"job_{i}", dest="processor"))
        
        # Wait for processing (longer time for CI environments)
        time.sleep(1.0)
        
        # Verify results
        self.assertEqual(len(results), 5)
        for i in range(5):
            self.assertIn(f"job_{i}", results)
        
        framework.quit()
    
    def test_multiple_stations(self) -> None:
        """Test multiple stations processing different events."""
        processor_results = []
        logger_results = []
        
        def processor_respond(event):
            processor_results.append(event.task)
            return "processed"
        
        def logger_respond(event):
            logger_results.append(event.task)
            return "logged"
        
        framework = EventFramework(name="multi_station_test")
        
        processor = EventStation(key="processor", respond_fn=processor_respond)
        logger = EventStation(key="logger", respond_fn=logger_respond)
        
        # Create workers for stations
        processor_worker = framework.add_worker("processor_worker", timedt=0.05)
        logger_worker = framework.add_worker("logger_worker", timedt=0.05)
        
        framework.login(processor, processor_worker)
        framework.login(logger, logger_worker)
        framework.start()
        
        # Push to processor
        framework.push(Event(task="job1", dest="processor"))
        # Push to logger
        framework.push(Event(task="job2", dest="logger"))
        
        time.sleep(1.0)
        
        self.assertEqual(processor_results, ["job1"])
        self.assertEqual(logger_results, ["job2"])
        
        framework.quit()
    
    def test_concurrent_event_processing(self) -> None:
        """Test concurrent event processing."""
        results = []
        lock = threading.Lock()
        
        def respond(event):
            time.sleep(0.05)  # Simulate work
            with lock:
                results.append(event.task)
            return "done"
        
        framework = EventFramework(name="concurrent_test")
        station = EventStation(key="worker", respond_fn=respond)
        worker = framework.add_worker("concurrent_worker", timedt=0.05)
        framework.login(station, worker)
        framework.start()
        
        # Push events concurrently
        threads = []
        for i in range(10):
            t = threading.Thread(
                target=lambda n: framework.push(Event(task=f"job_{n}", dest="worker")),
                args=(i,)
            )
            threads.append(t)
            t.start()
        
        for t in threads:
            t.join()
        
        # Wait for processing
        time.sleep(1.0)
        
        self.assertEqual(len(results), 10)
        
        framework.quit()
    
    def test_error_handling(self) -> None:
        """Test error handling in event processing."""
        def failing_respond(event):
            raise ValueError("Test error")
        
        framework = EventFramework(name="error_test")
        station = EventStation(key="failing", respond_fn=failing_respond)
        worker = framework.add_worker("error_worker", timedt=0.05)
        framework.login(station, worker)
        framework.start()
        
        event = Event(task="test", dest="failing")
        framework.push(event)
        
        time.sleep(0.5)
        
        # Event should be in EXCEPT state
        self.assertTrue(event.is_except())
        self.assertIsNotNone(event.error)
        
        framework.quit()
    
    def test_simple_api_integration(self) -> None:
        """Test simple API with core framework."""
        results = []
        
        events = EventSystem()
        events.listenFor("user_action", lambda d: results.append(d))
        
        events.pushEvent("user_action", {"user": "alice", "action": "click"})
        events.pushEvent("user_action", {"user": "bob", "action": "scroll"})
        
        time.sleep(0.2)
        
        self.assertEqual(len(results), 2)
        
        events.stop()
    
    def test_event_lifecycle(self) -> None:
        """Test complete event lifecycle."""
        framework = EventFramework(name="lifecycle_test")
        
        def respond(event):
            return "result"
        
        station = EventStation(key="test", respond_fn=respond)
        worker = framework.add_worker("lifecycle_worker", timedt=0.05)
        framework.login(station, worker)
        framework.start()
        
        # Create and push event
        event = Event(task="test_task", dest="test")
        
        self.assertTrue(event.is_offline())
        
        framework.push(event)
        self.assertTrue(event.is_junior())
        
        # Wait for processing
        time.sleep(0.5)
        
        # Event should be retired (processed by all stations)
        self.assertTrue(event.is_retired() or event.is_finish())
        self.assertIn("test", event.result)
        
        framework.quit()


if __name__ == '__main__':
    unittest.main()
