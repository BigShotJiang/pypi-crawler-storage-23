"""
Test EventStation Module - Tests for EventStation class.

测试事件站点模块 - EventStation类的测试。
"""

import unittest
import time
from efr.core.event import Event, EventState
from efr.core.estation import EventStation


class TestEventStation(unittest.TestCase):
    """Test cases for EventStation class."""
    
    def test_station_creation(self) -> None:
        """Test basic station creation."""
        station = EventStation(key="test_station")
        self.assertEqual(station.key, "test_station")
        self.assertEqual(station.level, 0)
        self.assertEqual(station.qsize(), 0)
    
    def test_station_with_params(self) -> None:
        """Test station creation with parameters."""
        def filter_fn(e): return True
        def respond_fn(e): return "result"
        
        station = EventStation(
            key="custom",
            filter_fn=filter_fn,
            respond_fn=respond_fn,
            level=5,
            capacity=10
        )
        self.assertEqual(station.key, "custom")
        self.assertEqual(station.level, 5)
    
    def test_default_filter(self) -> None:
        """Test default filter (key matching)."""
        station = EventStation(key="target")
        
        # Event with matching dest
        event_match = Event(dest="target")
        self.assertTrue(station.filter(event_match))
        
        # Event with non-matching dest
        event_no_match = Event(dest="other")
        self.assertFalse(station.filter(event_no_match))
    
    def test_custom_filter(self) -> None:
        """Test custom filter function."""
        station = EventStation(
            key="test",
            filter_fn=lambda e: "important" in e.tags
        )
        
        event_match = Event(tags={"important"})
        self.assertTrue(station.filter(event_match))
        
        event_no_match = Event(tags={"other"})
        self.assertFalse(station.filter(event_no_match))
    
    def test_push_updates_state(self) -> None:
        """Test that push updates event state."""
        station = EventStation(key="test")
        event = Event()
        
        self.assertTrue(event.is_offline())
        station.push(event)
        self.assertTrue(event.is_urgent())
        self.assertEqual(event.links, 1)
    
    def test_respond_execution(self) -> None:
        """Test respond function execution."""
        results = []
        
        def respond_fn(event):
            results.append(event.task)
            return f"processed_{event.task}"
        
        station = EventStation(key="test", respond_fn=respond_fn)
        
        event = Event(task="job1", dest="test")
        station.push(event)
        station.update()
        
        # Give time for processing
        time.sleep(0.1)
        
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0], "job1")
        self.assertEqual(event.result["test"], "processed_job1")
    
    def test_station_equality(self) -> None:
        """Test station equality comparison."""
        station1 = EventStation(key="test")
        station2 = EventStation(key="test")
        station3 = EventStation(key="other")
        
        self.assertEqual(station1, station2)
        self.assertNotEqual(station1, station3)
    
    def test_station_str(self) -> None:
        """Test string representation."""
        station = EventStation(key="my_station", level=3)
        str_repr = str(station)
        self.assertIn("my_station", str_repr)
        self.assertIn("3", str_repr)


if __name__ == '__main__':
    unittest.main()
