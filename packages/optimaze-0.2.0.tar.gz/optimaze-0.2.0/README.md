# Optimaze

AI-powered optimization model tuning. Automatically improves your Gurobi models.

## Installation

```bash
pip install optimaze
```

## Usage

```bash
optimaze optimize model.py --repo https://github.com/you/repo --key YOUR_KEY
```

## What it does

1. Runs your optimization model
2. Analyzes solver logs
3. Commits parameter improvements to your repo
4. Repeats until no more improvements found

Typical speedup: **20-50%**

## Example

```
============================================================
  OPTIMAZE
  AI-powered optimization tuning
============================================================

Script:     /path/to/model.py
Repo:       https://github.com/you/repo

[Iteration 0] Running model...
  Runtime: 18.25s
  (baseline)

[Iteration 1] Running model...
  Runtime: 13.10s
  Improvement: 28.2% faster

RESULTS
----------------------------------------
Baseline:  18.25s
Best:      13.10s
Speedup:   +28.2%

To apply:
  git merge agent/optimize-sess_xxxxx
```

## Requirements

- Python 3.10+
- Gurobi installed with valid license
- Git configured for your repo

## Environment Variables

- `OPTIMAZE_KEY`: Your license key
- `OPTIMAZE_SERVER`: Custom server URL (optional)

## License

MIT
