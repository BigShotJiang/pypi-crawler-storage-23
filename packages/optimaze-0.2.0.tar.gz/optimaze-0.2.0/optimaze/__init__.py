"""Optimaze - AI-powered optimization model tuning."""

__version__ = "0.2.0"
