"""
Optimaze CLI - AI-powered optimization model tuning.

Runs your model, analyzes solver logs, commits improvements to your repo.

Usage:
    optimaze optimize model.py --repo https://github.com/you/repo --key YOUR_KEY
"""

import sys
import typer
import subprocess
import time
from pathlib import Path
import httpx

app = typer.Typer(
    name="optimaze",
    help="AI-powered optimization. Runs your model, analyzes logs, commits improvements.",
    add_completion=False,
)

# Default server URL
DEFAULT_SERVER = "https://beautiful-victory-production-de1e.up.railway.app"


def print_banner():
    """Print the CLI banner."""
    typer.echo("")
    typer.echo("=" * 60)
    typer.echo("  OPTIMAZE")
    typer.echo("  AI-powered optimization tuning")
    typer.echo("=" * 60)
    typer.echo("")


def run_model(script_path: Path, timeout: float = 300.0) -> tuple[bool, float, str]:
    """Run the customer's model script via subprocess."""
    start_time = time.time()

    try:
        result = subprocess.run(
            [sys.executable, str(script_path)],
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=script_path.parent,
        )
        runtime = time.time() - start_time
        output = result.stdout + "\n" + result.stderr
        return result.returncode == 0, runtime, output

    except subprocess.TimeoutExpired:
        return False, timeout, "Timeout expired"
    except Exception as e:
        return False, 0.0, str(e)


def read_log_file(log_path: Path) -> str:
    """Read the solver log file."""
    if not log_path.exists():
        return ""
    return log_path.read_text()


def git_pull(branch: str, repo_dir: Path) -> bool:
    """Pull the latest changes from the branch."""
    try:
        subprocess.run(
            ["git", "fetch", "origin", branch],
            cwd=repo_dir,
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "checkout", branch],
            cwd=repo_dir,
            capture_output=True,
            check=True,
        )
        subprocess.run(
            ["git", "pull", "origin", branch],
            cwd=repo_dir,
            capture_output=True,
            check=True,
        )
        return True
    except subprocess.CalledProcessError as e:
        typer.secho(f"Git error: {e}", fg=typer.colors.RED)
        return False


@app.command()
def optimize(
    script_path: Path = typer.Argument(
        ...,
        help="Path to your optimization model script (e.g., model.py)",
        exists=True,
        readable=True,
    ),
    repo: str = typer.Option(
        ...,
        "--repo", "-r",
        help="GitHub repo URL (e.g., https://github.com/you/repo)",
    ),
    key: str = typer.Option(
        ...,
        "--key", "-k",
        help="Your Optimaze license key",
        envvar="OPTIMAZE_KEY",
    ),
    log_file: str = typer.Option(
        "gurobi.log",
        "--log-file", "-l",
        help="Path to solver log file (relative to script)",
    ),
    max_iterations: int = typer.Option(
        5,
        "--max-iterations", "-n",
        help="Maximum optimization iterations",
    ),
    timeout: float = typer.Option(
        300.0,
        "--timeout", "-t",
        help="Timeout per run in seconds",
    ),
    server: str = typer.Option(
        DEFAULT_SERVER,
        "--server", "-s",
        help="API server URL",
        envvar="OPTIMAZE_SERVER",
    ),
):
    """
    Optimize your model automatically.

    Runs your model, analyzes solver logs, and commits improvements to your repo.
    The loop continues until no more improvements are found or max iterations reached.

    Example:
        optimaze optimize model.py --repo https://github.com/you/repo --key YOUR_KEY
    """
    print_banner()

    script_path = script_path.resolve()
    repo_dir = script_path.parent
    log_path = repo_dir / log_file

    typer.echo(f"Script:     {script_path}")
    typer.echo(f"Repo:       {repo}")
    typer.echo(f"Log file:   {log_path}")
    typer.echo("")

    # Create session
    typer.echo("Creating optimization session...")

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.post(
                f"{server}/sessions",
                json={
                    "repo_url": repo,
                    "entry_file": script_path.name,
                    "log_file": log_file,
                },
                headers={"X-License-Key": key},
            )

        if response.status_code == 401:
            typer.secho("Error: Invalid license key", fg=typer.colors.RED)
            raise typer.Exit(1)

        if response.status_code != 200:
            typer.secho(f"Error: {response.text}", fg=typer.colors.RED)
            raise typer.Exit(1)

        session = response.json()
        session_id = session["session_id"]
        branch = session["branch"]

    except httpx.ConnectError:
        typer.secho(f"Error: Could not connect to server", fg=typer.colors.RED)
        raise typer.Exit(1)

    typer.secho(f"Session:    {session_id}", fg=typer.colors.GREEN)
    typer.secho(f"Branch:     {branch}", fg=typer.colors.GREEN)
    typer.echo("")

    # Results tracking
    results = []
    baseline_runtime = None

    # Main optimization loop
    for iteration in range(max_iterations):
        typer.echo("-" * 60)
        typer.echo(f"[Iteration {iteration}] Running model...")

        success, runtime, output = run_model(script_path, timeout)

        if not success:
            typer.secho(f"  Model failed: {output[:200]}", fg=typer.colors.RED)
            break

        typer.echo(f"  Runtime: {runtime:.2f}s")

        if iteration == 0:
            baseline_runtime = runtime
            typer.echo(f"  (baseline)")
        else:
            improvement = ((baseline_runtime - runtime) / baseline_runtime) * 100
            if improvement > 0:
                typer.secho(f"  Improvement: {improvement:.1f}% faster", fg=typer.colors.GREEN)
            else:
                typer.echo(f"  Improvement: {improvement:.1f}%")

        # Read log file
        logs = read_log_file(log_path)
        if not logs:
            if iteration == 0:
                typer.echo("  (Using stdout - agent will enable logging)")
            logs = output

        typer.echo("  Analyzing...")

        try:
            with httpx.Client(timeout=60.0) as client:
                response = client.post(
                    f"{server}/sessions/{session_id}/logs",
                    json={
                        "logs": logs,
                        "runtime": runtime,
                        "iteration": iteration,
                    },
                    headers={"X-License-Key": key},
                )

            if response.status_code != 200:
                typer.secho(f"  Error: {response.text}", fg=typer.colors.RED)
                break

            result = response.json()

        except httpx.ConnectError:
            typer.secho("  Error: Lost connection to server", fg=typer.colors.RED)
            break

        results.append({
            "commit": result.get("commit"),
            "runtime": runtime,
            "iteration": iteration,
        })

        if result["action"] == "done":
            typer.echo("")
            typer.secho("No more improvements to try.", fg=typer.colors.YELLOW)
            break

        typer.secho(f"  Committed: \"{result.get('message', 'improvement')}\"",
                   fg=typer.colors.CYAN)
        typer.echo("  Pulling changes...")

        if not git_pull(branch, repo_dir):
            typer.secho("  Failed to pull changes", fg=typer.colors.RED)
            break

        typer.echo("")

    # Complete session
    typer.echo("")
    typer.echo("=" * 60)

    if not results:
        typer.secho("No results to report.", fg=typer.colors.YELLOW)
        raise typer.Exit(1)

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.post(
                f"{server}/sessions/{session_id}/complete",
                json={"results": results},
                headers={"X-License-Key": key},
            )

        if response.status_code == 200:
            final = response.json()

            typer.echo("")
            typer.secho("RESULTS", fg=typer.colors.GREEN, bold=True)
            typer.echo("-" * 40)
            typer.echo(f"Baseline:  {final['baseline_runtime']:.2f}s")
            typer.echo(f"Best:      {final['best_runtime']:.2f}s")

            if final['speedup'] > 0:
                typer.secho(f"Speedup:   +{final['speedup']:.1f}%",
                           fg=typer.colors.GREEN, bold=True)
            else:
                typer.echo(f"Speedup:   {final['speedup']:.1f}%")

            typer.echo("")

            # Show PR URL if created
            if final.get('pr_url'):
                typer.secho("Pull Request created!", fg=typer.colors.GREEN)
                typer.echo(f"  {final['pr_url']}")
            else:
                typer.echo(f"Branch: {branch}")
                typer.echo("")
                typer.echo("To apply:")
                typer.echo(f"  git merge {branch}")

    except Exception as e:
        typer.secho(f"Error: {e}", fg=typer.colors.RED)

    typer.echo("")


@app.command()
def version():
    """Show version."""
    from . import __version__
    typer.echo(f"optimaze {__version__}")


@app.command()
def health(
    server: str = typer.Option(
        DEFAULT_SERVER,
        "--server", "-s",
        help="API server URL",
    ),
):
    """Check server status."""
    try:
        with httpx.Client(timeout=5.0) as client:
            response = client.get(f"{server}/health")

        if response.status_code == 200:
            typer.secho("Server is healthy", fg=typer.colors.GREEN)
        else:
            typer.secho(f"Server error: {response.status_code}", fg=typer.colors.RED)
            raise typer.Exit(1)

    except httpx.ConnectError:
        typer.secho("Cannot connect to server", fg=typer.colors.RED)
        raise typer.Exit(1)


def main():
    """Entry point."""
    app()


if __name__ == "__main__":
    main()
