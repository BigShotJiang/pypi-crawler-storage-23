"""Code that isn't closely related to the core functionality of the application"""
