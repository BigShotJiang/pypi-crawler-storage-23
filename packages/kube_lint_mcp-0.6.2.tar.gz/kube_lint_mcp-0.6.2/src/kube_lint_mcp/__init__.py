"""MCP server for Kubernetes manifest and Helm chart validation."""

__version__ = "0.1.0"
