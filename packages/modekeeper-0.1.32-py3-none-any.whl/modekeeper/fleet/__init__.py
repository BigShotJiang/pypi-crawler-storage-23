"""Fleet inventory helpers."""

