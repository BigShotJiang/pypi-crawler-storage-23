# Supplemental error codes
# Error values must be less than 1000


class SupErrors(object):
    error_codes = {
        "SUCCEEDE": 0,
        "INVALID_BATCH_ID": 1,
        "WORKER_ALREADY_DONE": 2,
    }
