from pandacommon.pandalogger import logger_utils
from pandacommon.pandamsgbkr import msg_processor
from pandaserver.config import panda_config


# Main message processing agent
class MsgProcAgent(msg_processor.MsgProcAgentBase):
    pass
