"""
Inheritance structure:

Base -> Entity, Metrics -> TaskEvent -> JobComplex -> DBProxy
Base -> Entity          -> Worker    -> JobComplex -> DBProxy
Base -> JobStandalone, MiscStandalone              -> DBProxy
"""
