#include <pebble.h>
#include "${project_name}.h"

bool ${project_name_c}_find_truth(void) {
    return true;
}
