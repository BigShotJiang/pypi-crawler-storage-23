#include <pebble_worker.h>

int main(void) {
  worker_event_loop();
}
