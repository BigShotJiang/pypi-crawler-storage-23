"""google-drive-cli-for-agents package."""

__version__ = "0.1.1"
