features and use-cases
**********************

the portions of this namespace are simplifying your Python application or service in the areas/domains::

    * ...


examples
********

