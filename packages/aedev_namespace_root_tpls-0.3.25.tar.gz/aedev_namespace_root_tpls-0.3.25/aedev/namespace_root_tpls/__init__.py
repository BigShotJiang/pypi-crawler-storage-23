""" templates (managed files) for namespace root projects. """

__version__ = '0.3.25'
