# SPDX-License-Identifier: MIT
# Copyright (C) 2025 ComfyUI-DynamicWidgets Contributors

"""
Node Scanner - Introspects ComfyUI nodes to extract visible_when and
visible_when_connected metadata.

Output format (v2, widget-centric rules with AND logic):
{
    "NodeClassName": {
        "selectors": ["backend", "output_dim", "size_mode"],
        "rules": {
            "widget_name": {"backend": ["GMSH"], "output_dim": ["3D Volume"]},
            ...
        },
        "connections": { ... }
    }
}

Multiple keys in a rule = AND (widget visible when ALL conditions pass).
Multiple values per key = OR (condition passes if current value matches ANY).
"""

from typing import Any


def scan_all_nodes() -> dict[str, dict]:
    """
    Scan all registered ComfyUI nodes and extract visible_when metadata.

    Returns:
        dict: Mapping of node_class -> visibility configuration
    """
    try:
        import nodes
    except ImportError:
        print("[DynamicWidgets] Warning: Could not import ComfyUI nodes module")
        return {}

    # Get the node class mappings from ComfyUI
    node_mappings = getattr(nodes, "NODE_CLASS_MAPPINGS", {})

    return scan_specific_nodes(node_mappings)


def scan_specific_nodes(node_mappings: dict[str, type]) -> dict[str, dict]:
    """
    Scan specific node classes for visible_when metadata.

    Args:
        node_mappings: Dict mapping node names to node classes
                       (same format as NODE_CLASS_MAPPINGS)

    Returns:
        dict: Mapping of node_class -> visibility configuration
    """
    results = {}

    for node_name, node_class in node_mappings.items():
        config = _scan_node_class(node_name, node_class)
        if config:
            results[node_name] = config

    return results


def _scan_node_class(node_name: str, node_class: type) -> dict | None:
    """
    Scan a single node class for visible_when metadata.

    Args:
        node_name: The registered name of the node
        node_class: The node class to scan

    Returns:
        dict or None: Visibility configuration if any visible_when found
    """
    # Get INPUT_TYPES - it's typically a classmethod
    if not hasattr(node_class, "INPUT_TYPES"):
        return None

    try:
        input_types = node_class.INPUT_TYPES()
    except Exception as e:
        print(f"[DynamicWidgets] Warning: Failed to call INPUT_TYPES for {node_name}: {e}")
        return None

    if not isinstance(input_types, dict):
        return None

    # Widget-centric rules: widget_name -> {selector: [values], ...}
    rules: dict[str, dict[str, list[str]]] = {}
    # Set of all selector names referenced in rules
    selector_names: set[str] = set()
    # Connection-based visibility (unchanged)
    connections: dict[str, dict] = {}

    # Scan both required and optional inputs
    for section in ["required", "optional"]:
        section_inputs = input_types.get(section, {})
        if not isinstance(section_inputs, dict):
            continue

        for widget_name, widget_def in section_inputs.items():
            visible_when = _extract_visible_when(widget_def)
            if visible_when:
                _add_rule(rules, selector_names, widget_name, visible_when)

            vwc = _extract_visible_when_connected(widget_def)
            if vwc:
                _add_to_connections(connections, widget_name, vwc)

    if not rules and not connections:
        return None

    result = {}
    if rules:
        result["selectors"] = sorted(selector_names)
        result["rules"] = rules
    if connections:
        result["connections"] = connections
    return result


def _extract_visible_when(widget_def: Any) -> dict | None:
    """
    Extract visible_when metadata from a widget definition.

    Widget definitions are typically tuples like:
        ("FLOAT", {"default": 0.1, "visible_when": {"backend": ["blender_voxel"]}})

    Multi-selector AND is supported:
        ("FLOAT", {"visible_when": {"backend": ["GMSH"], "output_dim": ["3D Volume"]}})

    Args:
        widget_def: The widget definition tuple/list

    Returns:
        dict or None: The visible_when dict if present
    """
    if not isinstance(widget_def, (tuple, list)):
        return None

    if len(widget_def) < 2:
        return None

    # Second element should be the options dict
    options = widget_def[1]
    if not isinstance(options, dict):
        return None

    visible_when = options.get("visible_when")
    if not isinstance(visible_when, dict):
        return None

    return visible_when


def _add_rule(
    rules: dict[str, dict[str, list[str]]],
    selector_names: set[str],
    widget_name: str,
    visible_when: dict
) -> None:
    """
    Add a widget visibility rule (supports multi-selector AND).

    Args:
        rules: The rules dict to update (widget_name -> conditions)
        selector_names: Set of selector names to update
        widget_name: The name of the widget with visible_when
        visible_when: The visible_when dict,
            e.g. {"backend": ["GMSH"], "output_dim": ["3D Volume"]}
    """
    rule = {}
    for selector_name, selector_values in visible_when.items():
        if not isinstance(selector_values, list):
            # Allow single value without list wrapper
            selector_values = [selector_values]

        selector_names.add(selector_name)
        # Normalize: JS String(true)="true", String(false)="false"
        rule[selector_name] = [
            str(v).lower() if isinstance(v, bool) else str(v)
            for v in selector_values
        ]

    if rule:
        rules[widget_name] = rule


def _extract_visible_when_connected(widget_def: Any) -> dict | None:
    """
    Extract visible_when_connected metadata from a widget definition.

    Widget definitions are typically tuples like:
        ("CAMERA_PARAMS", {
            "visible_when_connected": {
                "input": "da3_model",
                "source_widget": "model",
                "contains": ["da3_small", "nested"],
            }
        })

    Args:
        widget_def: The widget definition tuple/list

    Returns:
        dict or None: The visible_when_connected dict if present and valid
    """
    if not isinstance(widget_def, (tuple, list)):
        return None

    if len(widget_def) < 2:
        return None

    options = widget_def[1]
    if not isinstance(options, dict):
        return None

    vwc = options.get("visible_when_connected")
    if not isinstance(vwc, dict):
        return None

    # Validate required fields
    if "input" not in vwc or "source_widget" not in vwc:
        return None
    if "contains" not in vwc:
        return None

    return vwc


def _add_to_connections(
    connections: dict[str, dict],
    widget_name: str,
    vwc: dict
) -> None:
    """
    Add connection-based visibility rules to the connections structure.

    Args:
        connections: The connections dict to update
        widget_name: The name of the widget/input with visible_when_connected
        vwc: The visible_when_connected dict
    """
    input_name = vwc["input"]
    source_widget = vwc["source_widget"]

    if input_name not in connections:
        connections[input_name] = {
            "source_widget": source_widget,
            "contains": {},
        }

    patterns = vwc["contains"]
    if not isinstance(patterns, list):
        patterns = [patterns]

    connections[input_name]["contains"][widget_name] = [str(p) for p in patterns]
