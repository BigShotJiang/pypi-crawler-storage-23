"""Map SVD files to memory map."""

import argparse
import logging
from collections.abc import Callable, Iterable, Mapping
from inspect import getdoc, signature

from .actions import (
    collapse,
    distinguish,
    equivalence,
    import_map,
    reduce,
    unzero,
    visualize,
)
from .actions.rank import (
    rank_dice_bytes,
    rank_dice_total,
    rank_dice_words,
    rank_intersection,
    rank_jaccard_bytes,
    rank_jaccard_total,
    rank_jaccard_words,
    rank_naive,
    rank_shadow_jaccard,
)


def _add_subparsers(
    parser: argparse.ArgumentParser,
    funcs: Iterable[Callable[..., None]],
    default_args: Mapping[str, type] | None = None,
) -> None:
    if default_args is None:
        default_args = {}

    subparsers = parser.add_subparsers(required=True)
    for func in funcs:
        subparser = subparsers.add_parser(func.__name__, help=getdoc(func))
        subparser.set_defaults(func=func)

        params = dict(signature(func, eval_str=True).parameters)
        for arg, typ in default_args.items():
            assert arg in params, f"function {func.__name__} has no parameter {arg}"
            assert params[arg].annotation == typ, (
                f"parameter {arg} of {func.__name__} "
                f"has wrong type {params[arg].annotation!r} != {typ!r}"
            )
            del params[arg]

        for param in params.values():
            assert (
                param.annotation != param.empty
            ), f"{param.name} has no type annotation"
            if param.default == param.empty:
                subparser.add_argument(param.name, type=param.annotation)
                continue
            subparser.add_argument(
                param.name, type=param.annotation, default=param.default, nargs="?"
            )


def main() -> None:
    """main routine"""

    parser = argparse.ArgumentParser(
        description="Identify connected device by its register reset values."
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true", help="verbose output", default=False
    )
    _add_subparsers(
        parser,
        [
            collapse,
            distinguish,
            equivalence,
            import_map,
            rank_dice_bytes,
            rank_dice_total,
            rank_dice_words,
            rank_intersection,
            rank_jaccard_bytes,
            rank_jaccard_total,
            rank_jaccard_words,
            rank_shadow_jaccard,
            rank_naive,
            reduce,
            unzero,
            visualize,
        ],
    )

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO, format=f"{args.func.__name__} %(asctime)s %(message)s"
    )

    params = vars(args).copy()
    del params["func"]
    del params["verbose"]
    args.func(**params)


main()
