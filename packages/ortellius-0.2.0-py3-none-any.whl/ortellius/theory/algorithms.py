"""Algorithms from the theory."""

# pylint: disable=non-ascii-name

from .definitions import DeviceSet, RestrictedDeviceUniverse


def build_equivalence_classes(Δ: RestrictedDeviceUniverse) -> set[DeviceSet]:
    """Build equivalence classes."""

    Δs: set[DeviceSet] = set()
    for δ in Δ:
        εp = DeviceSet({δ})
        for ε in Δs:
            d = ε.pick()
            if d @ δ:
                εp = εp | ε
                Δs = Δs - {ε}
                break
        Δs = Δs | {εp}

    return Δs
