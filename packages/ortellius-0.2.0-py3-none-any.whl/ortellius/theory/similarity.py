"""Similarity functions for devices."""

from collections.abc import Callable, Iterable
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from logging import debug, warning

from ..implementation.domain import SetDomain
from .definitions import Device, Domain

type SimilarityFunction = Callable[[Device, Device], float]


def σ(d_1: Device, d_2: Device) -> int:
    """Naïve similarity."""

    return len({a for a in d_1.domain & d_2.domain if d_1(a) == d_2(a)})


def σ_s(d_1: Device, d_2: Device) -> float:
    """Intersection-normalized similarity."""
    if not d_1.domain & d_2.domain:
        return -1
    return σ(d_1, d_2) / len(d_1.domain & d_2.domain)


def _dice_inner(d_1: Device, d_2: Device, dom: Iterable[int]) -> int:
    # calculate domains outside of loop
    intersection = 0
    for a in dom:
        v_1 = d_1(a)
        v_2 = d_2(a)

        intersection += (
            v_1 ^ v_2 ^ 0xFF
        ).bit_count()  # number of bits with equal value
    return intersection


def dice_similarity(
    d_1: Device,
    d_2: Device,
    dom: Domain,
    *,
    batchsize: int = 10000,  # optimizable parameter
) -> float:
    """Sørensen-Dice similarity on device bitmaps."""
    if not dom:
        warning("Empty domain intersection between %s and %s", d_1, d_2)
        return 0

    assert dom <= d_1.domain | d_2.domain, "Domain must be a subset of union of domains"

    intersection = 0
    common = dom & d_1.domain & d_2.domain

    debug("Processing batches in parallel.")
    with ThreadPoolExecutor() as executor:
        for i in executor.map(partial(_dice_inner, d_1, d_2), common.batch(batchsize)):
            intersection += i

    return 2 * intersection / (len(d_1.domain) + len(d_2.domain))


def _jaccard_inner(d_1: Device, d_2: Device, dom: Iterable[int]) -> tuple[int, int]:
    intersection = 0
    union = 0
    for a in dom:
        v_1 = d_1(a)
        v_2 = d_2(a)

        intersection += (
            v_1 ^ v_2 ^ 0xFF
        ).bit_count()  # number of bits with equal value
        union += 8 + (v_1 ^ v_2).bit_count()  # bits with different value count twice
    return intersection, union


def jaccard_similarity(
    d_1: Device,
    d_2: Device,
    dom: Domain,
    *,
    batchsize: int = 10000,  # optimizable parameter
) -> float:
    """Jaccard similarity on device bitmaps."""
    if not dom:
        warning("Empty domain intersection between %s and %s", d_1, d_2)
        return 0

    assert dom <= d_1.domain | d_2.domain, "Domain must be a subset of union of domains"

    intersection = 0
    union = 0

    debug(
        "Processing symmetric difference. (Saves time if domains are very different.)"
    )
    # 1) dom(d_1) ∩ dom(d_2)
    common = dom & d_1.domain & d_2.domain
    # 2) |dom(d_1) Δ dom(d_2)| = |dom(d_1) ∪ dom(d_2)| - |dom(d_1) ∩ dom(d_2)|
    union += 8 * len(dom & (d_1.domain | d_2.domain)) - len(common)

    debug("Processing batches in parallel.")
    with ThreadPoolExecutor() as executor:
        for i, u in executor.map(
            partial(_jaccard_inner, d_1, d_2), common.batch(batchsize)
        ):
            intersection += i
            union += u

    return intersection / union


def jaccard_total(d_1: Device, d_2: Device) -> float:
    """
    Compute the Jaccard index between two devices over their complete memory.
    """
    return jaccard_similarity(d_1, d_2, d_1.domain | d_2.domain)


def jaccard_bytes(d_1: Device, d_2: Device) -> float:
    """
    Compute the Jaccard index between two devices over the bytes they have in common.
    """
    return jaccard_similarity(d_1, d_2, d_1.domain & d_2.domain)


def jaccard_words(d_1: Device, d_2: Device) -> float:
    """
    Compute the Jaccard index between two devices over the words they have in common.
    """
    return jaccard_similarity(
        d_1,
        d_2,
        SetDomain((a & ~0x3) + i for a in d_1.domain & d_2.domain for i in range(4)),
    )


def dice_total(d_1: Device, d_2: Device) -> float:
    """
    Compute the Sørensen-Dice index between two devices over their complete memory.
    """
    return dice_similarity(d_1, d_2, d_1.domain | d_2.domain)


def dice_bytes(d_1: Device, d_2: Device) -> float:
    """
    Compute the Sørensen-Dice index between two devices over the bytes they have in
    common.
    """
    return dice_similarity(d_1, d_2, d_1.domain & d_2.domain)


def dice_words(d_1: Device, d_2: Device) -> float:
    """
    Compute the Sørensen-Dice index between two devices over the words they have in
    common.
    """
    return dice_similarity(
        d_1,
        d_2,
        SetDomain((a & ~0x3) + i for a in d_1.domain & d_2.domain for i in range(4)),
    )
