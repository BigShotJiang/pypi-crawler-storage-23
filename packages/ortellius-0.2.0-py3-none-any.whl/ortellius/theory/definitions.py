"""Implementation of the theory of devices."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterable, Iterator, Set
from types import NotImplementedType
from typing import overload

from serstor.abstract import ExtendedSerializable, NativeSerializable

from ..typing import is_set


class TheoryError(Exception):
    """Base class for theory errors."""


class Domain(Set[int], ABC):
    """Set of addresses, which a device can map to a value."""

    def pick(self) -> int:
        """Pick an arbitrary element from this domain."""
        return next(iter(self))

    @abstractmethod
    def batch(self, batchsize: int) -> Iterable[Domain]:
        """Split this domain into batches."""

    @abstractmethod
    def __sub__(self, other: Set[object]) -> Domain: ...

    @abstractmethod
    def __and__(self, other: Set[object]) -> Domain: ...

    @overload
    def __or__[_T](self, other: Domain) -> Domain: ...
    @overload
    def __or__[_T](self, other: Set[_T]) -> Set[int | _T]: ...
    @abstractmethod
    def __or__[_T](self, other: Set[_T]) -> Set[int | _T]: ...

    def __repr__(self) -> str:
        return set(self).__repr__()


class Device(ABC, ExtendedSerializable):
    """Abstract base class for devices with operator definitions."""

    __hash: int | None

    def __init__(self) -> None:
        self.__hash = None

    @property
    @abstractmethod
    def domain(self) -> Domain:
        """
        Set of addresses, which this device maps to a value. Domain can be
        narrowed by assigning a value to this property.
        """

    @property
    @abstractmethod
    def name(self) -> str:
        """Name of this device."""

    @name.setter
    @abstractmethod
    def name(self, value: str) -> None:
        """Set name of this device."""

    @abstractmethod
    def narrow_domain(self, new_domain: Set[int]) -> Device:
        """
        Return a new device with domain narrowed to intersection with
        `new_domain`.
        """

    @abstractmethod
    def unzero(self) -> Device:
        """
        Return a new device without any registers resetting to 0.
        """

    @abstractmethod
    def apply(self, a: int) -> int:
        """Return the value at address `a`. Raise DomainError if `a` not in
        domain."""

    @abstractmethod
    def asdict(
        self, from_address: int = 0, to_address: int | None = None
    ) -> dict[int, int]:
        """
        Return a dictionary mapping addresses to values.
        """

    def serialize(self) -> NativeSerializable:
        return {
            "name": self.name,
            "values": {f"{a:#010x}": self(a) for a in self.domain},
        }

    def __call__(self, a: int) -> int:
        return self.apply(a)

    def __matmul__(self, other: object) -> bool | NotImplementedType:
        if not isinstance(other, Device):
            return NotImplemented

        return (self, other) in E

    def __or__(self, other: object) -> bool | NotImplementedType:
        if not isinstance(other, Device | DeviceSet):
            return NotImplemented

        if isinstance(other, DeviceSet):
            return all(self | d for d in other)
        return (self, other) in I

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Device):
            return False
        return self is other or (
            self.domain == other.domain
            and all(self(a) == other(a) for a in self.domain)
        )

    def __gt__(self, other: object) -> bool | NotImplementedType:
        if not isinstance(other, Device):
            return NotImplemented
        return (self, other) in D

    def __ge__(self, other: object) -> bool | NotImplementedType:
        if not isinstance(other, Device):
            return NotImplemented

        return (self, other) in C

    def __hash__(self) -> int:
        """
        Horribly slow for large devices. Overriding encouraged.
        """

        if self.__hash is None:
            self.__hash = hash(frozenset((a, self(a)) for a in self.domain))
        return self.__hash

    def __repr__(self) -> str:
        return f"Device: [{self.name}: {self.domain}]"


class DomainError(TheoryError):
    """Raised when a device is applied to an argument not in its domain."""

    def __init__(self, device: Device, argument: int) -> None:
        super().__init__(
            f"Device {device} applied to argument {argument} not in domain "
            "{device.domain}."
        )


class EmptySetError(TheoryError):
    """
    Raised when a set operation that is meaningless on an empty set is attempted on an
    empty set.
    """


class DeviceSet(Set[Device]):
    """A set of devices."""

    __devices: set[Device]

    def __init__(self, contents: Iterable[Device] | None = None) -> None:
        self.__devices = set(contents) if contents else set()

    def get_devices(self) -> Iterable[Device]:
        """Return all devices in this set."""
        return self.__devices

    def pick(self) -> Device:
        """Pick a device from this set."""

        if not self.__devices:
            raise EmptySetError("Cannot pick a device from an empty device set.")
        return next(iter(self))

    def difference(self, other: Set[Device]) -> DeviceSet:
        """Return the difference of two sets."""

        return DeviceSet(self - other)

    def __iter__(self) -> Iterator[Device]:
        seen: set[Device] = set()
        for d in self.get_devices():
            if d in seen:  # check is needed to ensure subclass conformity
                raise ValueError(f"Device {d} present multiple times in set {self}.")
            seen.add(d)
            yield d

    def __contains__(self, x: object) -> bool:
        return x in self.__devices

    def __len__(self) -> int:
        return len(self.__devices)

    @overload
    def __or__(self, other: DeviceSet) -> DeviceSet: ...
    @overload
    def __or__[T](self, other: Set[T]) -> Set[Device | T]: ...

    def __or__[T](self, other: Set[T]) -> Set[Device | T]:
        if is_set(other, Device):  # type: ignore[type-abstract]
            return DeviceSet(self.__devices | other)
        return self.__devices | other

    def __eq__(self, other: object) -> bool | NotImplementedType:
        if isinstance(other, DeviceSet):
            return set(self) == set(other)
        return NotImplemented

    def __hash__(self) -> int:
        return hash(frozenset(self))

    def __repr__(self) -> str:
        return f"DeviceSet({self.__devices})"


class DuplicateInSetError(TheoryError):
    """Raised when a device is present multiple times in a set."""

    def __init__(self, s: DeviceSet, device: Device) -> None:
        super().__init__(f"Device {device} present multiple times in set {s}.")


class DeviceUniverse(DeviceSet):
    """All possible devices."""

    def get_devices(self) -> Iterable[Device]:
        raise NotImplementedError("Cannot enumerate all possible devices yet.")

    def __contains__(self, d: object) -> bool | NotImplementedType:
        return isinstance(d, Device) or NotImplemented


DD = DeviceUniverse()


class Relation(ABC):
    """A relation on devices."""

    universe: DeviceUniverse

    def __init__(self, universe: DeviceUniverse | None = None) -> None:
        self.universe = universe or DD

    @classmethod
    @abstractmethod
    def _relate(cls, d_1: Device, d_2: Device) -> bool:
        """Return whether the pair is in the relation."""

    def __contains__(self, pair: tuple[Device, Device]) -> bool:
        """Return whether the pair is in the relation."""
        return all(d in self.universe for d in pair) and self._relate(*pair)


class RestrictedDeviceUniverse(DeviceUniverse):
    """A restricted universe of devices."""

    devices: set[Device] | None

    def __init__(self) -> None:
        super().__init__()
        self.devices = None

    def restrict(self, devices: set[Device]) -> None:
        """Restrict the universe to the given set of devices."""

        self.devices = devices.copy()

    def get_devices(self) -> Iterable[Device]:
        if self.devices is None:
            return DD.get_devices()
        return iter(self.devices)

    def __contains__(self, d: object) -> bool | NotImplementedType:
        if self.devices is None:
            return d in DD
        return d in self.devices


class Indistinguishability(Relation):
    """Indistinguishability relation between devices."""

    @classmethod
    def _relate(cls, d_1: Device, d_2: Device) -> bool:
        dom = d_1.domain & d_2.domain
        if not dom:
            return True
        mindom, maxdom = min(dom), max(dom)
        img_1 = d_1.asdict(mindom, maxdom)
        img_2 = d_2.asdict(mindom, maxdom)
        return all(img_1[a] == img_2[a] for a in dom)


class Neighborhood(DeviceSet):
    """Neighborhood of a device."""

    universe: DeviceUniverse
    center: Device

    def __init__(self, center: Device, universe: DeviceUniverse | None = None):
        self.universe = universe or DD
        self.center = center
        super().__init__()

    def get_devices(self) -> Iterable[Device]:
        return iter(d for d in self.universe if d | self.center)


class NeighborhoodMeta:
    """Neighborhood factory."""

    universe: DeviceUniverse

    def __init__(self, universe: DeviceUniverse | None = None):
        self.universe = universe or DD

    def __getitem__(self, d: Device) -> Neighborhood:
        return Neighborhood(d, universe=self.universe)


Δ = RestrictedDeviceUniverse()
N = NeighborhoodMeta(Δ)


class Coverage(Relation):
    """Coverage relation."""

    @classmethod
    def _relate(cls, d_1: Device, d_2: Device) -> bool:
        return d_1 | N[d_2]


class Equivalence(Relation):
    """Equivalence relation."""

    @classmethod
    def _relate(cls, d_1: Device, d_2: Device) -> bool:
        return d_1 >= d_2 >= d_1


class Dominance(Relation):
    """Dominance relation."""

    @classmethod
    def _relate(cls, d_1: Device, d_2: Device) -> bool:
        return d_1 >= d_2 and not d_2 >= d_1


class Conflict:
    """Conflict function."""

    devices: DeviceSet

    def __init__(self, devices: DeviceSet):
        self.devices = devices

    def __call__(self, a: int) -> int:
        n: dict[int, int] = {}
        for d in self.devices:
            n[d(a)] = n.get(d(a), 0) + 1
        return len(self.devices) ** 2 - sum(nv**2 for nv in n.values())


class ConflictSet:
    """Conflict set."""

    def __call__(self, devices: DeviceSet) -> set[int]:
        domain: set[int] = set()
        for d in devices:
            domain.update(d.domain)
        return {a for a in domain if κ[devices](a) > 0}

    def __getitem__(self, devices: DeviceSet) -> Conflict:
        return Conflict(devices)


I = Indistinguishability(Δ)
C = Coverage(Δ)
E = Equivalence(Δ)
D = Dominance(Δ)
κ = ConflictSet()
