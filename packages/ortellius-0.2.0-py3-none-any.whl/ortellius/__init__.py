"""
Ortellius is a tool for analyzing and comparing SVD files for ARM Cortex-M
microcontrollers.
"""

import sys

if sys._is_gil_enabled():  # pylint: disable=protected-access
    raise RuntimeError("Ortellius requires the GIL to be disabled")

# def build_tree(
#        treefile: Path,
#        fingerprint_db: Path,) -> None:
#    """
#    Build a decision tree from the fingerprints in the specified directory and
#    save it to the treefile.
#    """
#
#    storage = Storage(fingerprint_db)
#    D = DeviceSet(ImportedDevice.from_storage(storage))
#
#    tree = DecisionTree.from_set(D)
#    tree.to_json(treefile)

# def detect(treefile: Path, rsp: bool = True) -> None:
#    """
#    Detect the connected device using the decision tree in the specified file.
#    """
#
#    tree = DecisionTree.from_json(treefile)
#    cur = tree.root
#    while isinstance(cur, DecisionBranch):
#        print(f"Current node: {cur}")
#        value_str = input(f"Enter value @ {cur.distinguisher:#010x}: ")
#        value = int(value_str, 16)
#        if value not in cur:
#            print("No such value in the tree.")
#            return
#        cur = cur[value]
#    print(f"Device is one of: {cur.equivalence_class}")
#
#    if rsp:
#        with RSPClient(
#            socket.create_connection(('localhost', 3333))
#        ) as client:
#            def rsp_query_func(o: int) -> int:
#                return int.from_bytes(client.read_memory(o, 4), 'little')
#            result = tree.detect(rsp_query_func)
#            print(f"Device is one of: {result}")
#            return
#
#    def default_query_func(o: int) -> int:
#        return int(input(f"Enter value @ {o:#010x}: "), 0)
#    result = tree.detect(default_query_func)
#    print(f"Device is one of: {result}")

# def check_decisiontree(treefile: Path, fingerprint_db: Path) -> None:
#    """
#    Check the decision tree for consistency.
#    """
#
#    tree = DecisionTree.from_json(treefile)
#    db = FingerprintStorage(fingerprint_db)
#
#    conflicts: list[tuple[str, str]] = []
#
#    for leaf in tree.iter_leaves():
#        print('|', end="", flush=True)
#        with ProcessPoolExecutor() as executor:
#            for future, fp1, fp2 in [
#                (executor.submit(
#                    eq, db[fp1], db[fp2]), fp1, fp2) for (
#                    fp1, fp2) in combinations(
#                    leaf.equivalence_class, 2)]:
#                if future.result():
#                    print(".", end="", flush=True)
#                else:
#                    print("X", end="", flush=True)
#                    conflicts.append((fp1, fp2))
#        print()
#
#    for fp1, fp2 in conflicts:
#        if db[fp1] != db[fp2]:
#            print(f"Conflict between {fp1} and {fp2}.")
#
#    if not conflicts:
#        print("Leaves are valid equivalence groups.")
