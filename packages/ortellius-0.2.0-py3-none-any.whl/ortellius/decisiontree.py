"""
Decision tree for distinguishing between fingerprints.
"""

# from __future__ import annotations
#
# from collections.abc import Callable, Iterator
# from dataclasses import dataclass
# import json
# from pathlib import Path
# from typing import Literal, Self, TypedDict
#
# from .theory.definitions import DeviceSet
#
#
# @dataclass
# class DecisionLeaf:
#    """A leaf node in the decision tree."""
#    equivalence_class: set[str]
#
#    class Dict(TypedDict):
#        """Dictionary representation of a leaf node."""
#        _type: Literal["leaf"]
#        equivalence_class: list[str]
#
#    def to_dict(self) -> Dict:
#        """Convert the leaf to a dictionary."""
#
#        return {
#            "_type": "leaf",
#            "equivalence_class": sorted(
#                self.equivalence_class)}
#
#    @classmethod
#    def from_dict(cls, data: Dict) -> Self:
#        """Create a leaf from a dictionary."""
#
#        return cls(set(data["equivalence_class"]))
#
#
# @dataclass
# class DecisionBranch:
#    """A node in the decision tree."""
#    distinguisher: int
#    _children: dict[int, DecisionNode]
#
#    def __contains__(self, value: int) -> bool:
#        return value in self._children
#
#    def __getitem__(self, value: int) -> DecisionNode:
#        return self._children[value]
#
#    def __iter__(self) -> Iterator[DecisionNode]:
#        return iter(self._children.values())
#
#    def __str__(self) -> str:
#        return f"Branch @ {
#            self.distinguisher:#010x
#        } with {
#            len(self._children)
#        } children: {
#            list(f"{k:#010x}" for k in self._children.keys())
#        }"
#
#    class Dict(TypedDict):
#        """Dictionary representation of a branch node."""
#        _type: Literal["branch"]
#        addr_distinguisher: int
#        children: dict[str, DecisionNodeDict]
#
#    def to_dict(self) -> Dict:
#        """Convert the branch to a dictionary."""
#        return {
#            "_type": "branch",
#            "addr_distinguisher": self.distinguisher,
#            "children": {
#                f"{k:#010x}": v.to_dict()
#                for k, v in self._children.items()
#            }
#        }
#
#    @classmethod
#    def from_dict(cls, data: Dict) -> Self:
#        """Create a branch from a dictionary."""
#        return cls(data["addr_distinguisher"], {
#            int(k, 16): _decision_node_from_dict(v)
#            for k, v in data["children"].items()
#        })
#
#
# type DecisionNode = DecisionLeaf | DecisionBranch
# type DecisionNodeDict = DecisionLeaf.Dict | DecisionBranch.Dict
#
#
# def _decision_node_from_set(D: FingerprintSet) -> DecisionNode:
#    """Build a decision tree from a fingerprint set."""
#    if len(D) == 0:
#        raise ValueError("Cannot build decision tree from empty set.")
#
#    if (a := D.best_distinguisher) is None:
#        return DecisionLeaf({d.name for d in D})
#
#    return DecisionBranch(a, {
#        value: _decision_node_from_set(
#            FingerprintSet(d for d in D if a in d.domain and d(a) == value)
#        ) for value in D.superimage_at(a)
#    })
#
#
# def _decision_node_from_dict(data: DecisionNodeDict) -> DecisionNode:
#    """Deserialize a decision tree from a dictionary."""
#    if data["_type"] == "branch":
#        return DecisionBranch.from_dict(data)
#    if data["_type"] == "leaf":
#        return DecisionLeaf.from_dict(data)
#    raise ValueError(f"Unknown node type: {data['type']}")
#
#
# class DecisionTree:
#    """A decision tree for distinguishing between fingerprints."""
#
#    root: DecisionNode
#
#    _num_leaves: int
#    _num_branches: int
#    _max_depth: int
#
#    def _count_nodes(self) -> None:
#        """Count the number of leaves and branches in the tree."""
#        self._num_leaves = 0
#        self._num_branches = 0
#        self._max_depth = 0
#
#        for node, depth in self.walk():
#            if isinstance(node, DecisionLeaf):
#                self._num_leaves += 1
#            else:
#                self._num_branches += 1
#            self._max_depth = max(depth, self._max_depth)
#
#    @property
#    def num_leaves(self) -> int:
#        """The number of leaf nodes in the tree."""
#        if hasattr(self, '_num_leaves'):
#            return self._num_leaves
#        self._count_nodes()
#        return self._num_leaves
#
#    @property
#    def num_branches(self) -> int:
#        """The number of branch nodes in the tree."""
#        if hasattr(self, '_num_branches'):
#            return self._num_branches
#        self._count_nodes()
#        return self._num_branches
#
#    @property
#    def max_depth(self) -> int:
#        """The maximum depth of the tree."""
#        if hasattr(self, '_max_depth'):
#            return self._max_depth
#        self._count_nodes()
#        return self._max_depth
#
#    def __str__(self) -> str:
#        return f"DecisionTree ({
#            self.num_leaves} leaves, {
#            self.num_branches} branches, {
#            self.max_depth} deep)"
#
#    def __init__(self, root: DecisionNode) -> None:
#        self.root = root
#
#    def walk(self) -> Iterator[tuple[DecisionNode, int]]:
#        """Walk the tree depth-first, yielding (node, depth) tuples."""
#
#        stack = [(self.root, 0)]
#        while stack:
#            node, depth = stack.pop()
#            yield node, depth
#            if isinstance(node, DecisionBranch):
#                for child in node:
#                    stack.append((child, depth + 1))
#
#    def iter_leaves(self) -> Iterator[DecisionLeaf]:
#        """Iterate over all leaves in the tree."""
#
#        for node, _ in self.walk():
#            if isinstance(node, DecisionLeaf):
#                yield node
#
#    def detect(self, query_func: Callable[[int], int]) -> DecisionLeaf:
#        """Detect the device using the tree and the given query function."""
#        cur = self.root
#        while isinstance(cur, DecisionBranch):
#            print(f"Querying: {cur.distinguisher:#010x}")
#            value = query_func(cur.distinguisher)
#            print(
#                f"At offset {
#                    cur.distinguisher:#010x}, got value {
#                    value:#010x}")
#            if value not in cur:
#                print(f"Unexpected value {value} at offset {
#                    cur.distinguisher:#010x}")
#                raise ValueError(
#                    f"Unexpected value {value} at offset {
#                        cur.distinguisher:#010x}")
#            print("next_val")
#            cur = cur[value]
#        print("done")
#        return cur
#
#    @classmethod
#    def from_set(cls, D: DeviceSet) -> Self:
#        """Build a decision tree from a fingerprint matrix."""
#        return cls(_decision_node_from_set(D))
#
#    class Dict(TypedDict):
#        """Type hint for the JSON representation of a decision tree."""
#        root: DecisionNodeDict
#
#    @classmethod
#    def from_dict(cls, data: Dict) -> Self:
#        """Load a decision tree from a dictionary."""
#        return cls(_decision_node_from_dict(data['root']))
#
#    def to_dict(self) -> Dict:
#        """Serialize the decision tree to a dictionary."""
#        return {'root': self.root.to_dict()}
#
#    @classmethod
#    def from_json(cls, file: Path) -> Self:
#        """Load a decision tree from a JSON file."""
#
#        with open(file, 'r', encoding='utf-8') as f:
#            data = json.load(f)
#        return cls.from_dict(data)
#
#    def to_json(self, file: Path) -> None:
#        """Save the decision tree to a JSON file."""
#        with open(file, 'w', encoding='utf-8') as f:
#            json.dump(self.to_dict(), f, indent=2, sort_keys=True)
#
