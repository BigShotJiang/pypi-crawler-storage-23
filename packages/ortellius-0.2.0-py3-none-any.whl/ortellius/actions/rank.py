"""Rank devices by similarity."""

from concurrent.futures import ThreadPoolExecutor
from functools import partial
from logging import info
from math import exp
from pathlib import Path

from serstor import Storage
from svdmap.model import Shadow

from ..implementation.device import FileDevice
from ..imported_models import AnalysisResult
from ..theory.definitions import Device
from ..theory.similarity import (
    SimilarityFunction,
    dice_bytes,
    dice_total,
    dice_words,
    jaccard_bytes,
    jaccard_total,
    jaccard_words,
    σ,
    σ_s,
)
from .impl.common import load_devices


def _rank_by_similarity(device_map: Path, dump: Path, func: SimilarityFunction) -> None:
    """
    Rank all known devices by similarity to the given memory dump.
    """

    info("Loading device set...")
    Δ = load_devices(device_map)

    info("Loading dump...")
    d = FileDevice(dump)

    info("Calculating similarity.")

    ranks: dict[Device, float] = {}
    with ThreadPoolExecutor() as executor:
        for δ, s in zip(Δ, executor.map(partial(func, d), Δ)):
            ranks[δ] = s

    info("Sorting by similarity...")
    ranking = sorted(ranks.items(), key=lambda x: x[1], reverse=True)
    for δ, s in ranking:
        print(f"{s}\t{len(d.domain & δ.domain)}\t{δ}")


def rank_naive(device_map: Path, dump: Path) -> None:
    """
    Rank all known devices by naïve similarity to the given memory dump.
    """

    _rank_by_similarity(device_map, dump, σ)


def rank_intersection(device_map: Path, dump: Path) -> None:
    """
    Rank all known devices by naïve similarity to the given memory dump.
    """

    _rank_by_similarity(device_map, dump, σ_s)


def rank_jaccard_total(device_map: Path, dump: Path) -> None:
    """
    Rank all known devices by Jaccard total similarity to the given memory dump.
    """
    _rank_by_similarity(device_map, dump, jaccard_total)


def rank_jaccard_bytes(device_map: Path, dump: Path) -> None:
    """
    Rank all known devices by Jaccard bytes similarity to the given memory dump.
    """
    _rank_by_similarity(device_map, dump, jaccard_bytes)


def rank_jaccard_words(device_map: Path, dump: Path) -> None:
    """
    Rank all known devices by Jaccard words similarity to the given memory dump.
    """
    _rank_by_similarity(device_map, dump, jaccard_words)


def rank_dice_total(device_map: Path, dump: Path) -> None:
    """
    Rank all known devices by Jaccard total similarity to the given memory dump.
    """
    _rank_by_similarity(device_map, dump, dice_total)


def rank_dice_bytes(device_map: Path, dump: Path) -> None:
    """
    Rank all known devices by Jaccard bytes similarity to the given memory dump.
    """
    _rank_by_similarity(device_map, dump, dice_bytes)


def rank_dice_words(device_map: Path, dump: Path) -> None:
    """
    Rank all known devices by Jaccard words similarity to the given memory dump.
    """
    _rank_by_similarity(device_map, dump, dice_words)


def _print_ranking(ranking: list[tuple[str, float]]) -> None:
    last_score = None
    rank = 1
    with_this_rank = 0
    for name, s in ranking:
        if s != last_score:
            last_score = s
            if with_this_rank > 0:
                print(f"{with_this_rank} devices with rank #{rank-1}")
            print(f"Rank #{rank}: (score {s}, normalized score {s/ranking[0][1]})")
            rank += 1
            with_this_rank = 0
        with_this_rank += 1

        print(f"\t{name}")

    if with_this_rank > 0:
        print(f"{with_this_rank} devices with rank #{rank}")


def rank_shadow_jaccard(device_shadow: Path, firmware_shadow: Path) -> None:
    """
    Rank all known devices by Shadow Jaccard similarity to the given memory dump.
    """
    with Storage(device_shadow) as storage:
        shadow_base = [storage.get_and_unserialize(name, Shadow) for name in storage]
    firmware = AnalysisResult.model_validate_json(firmware_shadow.read_text())

    ranks: dict[str, float] = {}
    for shadow in shadow_base:
        if shadow.name.startswith("svds/cmsis/"):
            continue
        elif not shadow.name.startswith("svds/keil/"):
            raise ValueError(f"unexpected shadow name {shadow.name!r}")

        intersection = len(shadow.read & firmware.read)
        union = len(shadow.read | firmware.read)
        similarity = intersection / union if union > 0 else 0.0
        ranks[shadow.name] = similarity

    info("Sorting by similarity...")
    ranking = sorted(ranks.items(), key=lambda x: x[1], reverse=True)
    _print_ranking(ranking)
