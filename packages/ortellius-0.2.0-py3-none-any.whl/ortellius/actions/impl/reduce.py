"""Support functions for reduce action."""

from collections.abc import Collection, Mapping, Sequence
from concurrent.futures import ThreadPoolExecutor
from sys import getrecursionlimit, setrecursionlimit

from ...theory.definitions import Device


def _find_address_values_inner(Δ: Sequence[Device]) -> dict[int, set[int]]:
    if not Δ:
        return {}
    if len(Δ) == 1:
        [δ] = Δ
        return {a: {δ(a)} for a in δ.domain}

    mid = len(Δ) // 2
    with ThreadPoolExecutor() as executor:
        m1, m2 = executor.map(_find_address_values_inner, [Δ[:mid], Δ[mid:]])
    for k, v in m2.items():
        m1.setdefault(k, set()).update(v)
    return m1


def find_address_values(Δ: Collection[Device]) -> Mapping[int, set[int]]:
    """Find all possible values for each address in the given devices."""
    depth = len(Δ).bit_length() + 20
    orig_depth = getrecursionlimit()
    if depth > orig_depth:
        setrecursionlimit(depth)
    try:
        return _find_address_values_inner(list(Δ))
    finally:
        setrecursionlimit(orig_depth)


def narrow_domain(d: Device, new_domain: set[int]) -> Device:
    """Narrow the domain of a device to the given set of addresses."""
    return d.narrow_domain(new_domain)
