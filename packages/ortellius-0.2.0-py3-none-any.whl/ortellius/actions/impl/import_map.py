"""Functions for importing data from svdmap."""

from collections.abc import Iterator
from concurrent.futures import ThreadPoolExecutor
from logging import debug, info

from serstor import Storage
from serstor.abstract import NativeSerializable
from svdmap.model import Address, MemoryMap
from svdmap.parallelization import Result

from ...implementation.device import StaticDevice


def _device_from_svdmap_memory_map(
    name: str,
    memory_map: MemoryMap,
) -> StaticDevice:
    """
    Create a static device from a memory map.
    """

    filtered: dict[int, int] = {}
    total = 0
    skipped = 0
    for value in memory_map.values:
        total += 1
        if value.reset_value == "CONFLICT":
            skipped += 1
            continue
        if value.location.size.bit_offset != 0:
            skipped += 1
            continue
        while value.location.size > Address(0, 0):
            assert value.reset_value != "CONFLICT"  # type: ignore
            filtered[value.location.start.byte_offset] = value.reset_value & 0xFF
            value >>= 8
        assert value.location.size == Address(0, 0)

    if skipped > 0:
        debug("Skipped %d/%d registers due to conflicts or bit-offsets", skipped, total)

    return StaticDevice(name, filtered)


def _device_from_svdmap_result(serialized: NativeSerializable) -> StaticDevice | None:
    """
    Create a device from a serialized result.
    Return None, if result is not successful.
    """

    result = Result[MemoryMap].unserialize(serialized, MemoryMap)
    if result.error is not None:
        return None
    assert result.returned is not None
    dev = _device_from_svdmap_memory_map(str(result.args[0]), result.returned)
    hash(dev)  # precalculate hash, so adding to sets is faster
    return dev


def devices_from_svdmap(storage: Storage) -> Iterator[StaticDevice]:
    """Create imported devices from SVD storage."""

    info("Loading results into memory.")

    info("Converting results to devices.")
    with ThreadPoolExecutor() as executor:
        for dev in executor.map(_device_from_svdmap_result, storage.values()):
            if dev is not None:
                yield dev
