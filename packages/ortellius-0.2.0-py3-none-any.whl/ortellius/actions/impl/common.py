"""
Common functionality for actions.
"""

from collections.abc import Iterable
from pathlib import Path

from serstor import Storage

from ...implementation.device import StaticDevice
from ...theory.definitions import Device, DeviceSet


def load_devices(storage: Storage | Path) -> DeviceSet:
    """
    Load a set of serialized devices.
    """
    if isinstance(storage, Path):
        with Storage(storage) as s:
            return load_devices(s)

    return DeviceSet(StaticDevice.unserialize(d) for d in storage.values())


def save_devices(storage: Storage | Path, devices: Iterable[Device]) -> None:
    """
    Serialize and save a set of devices.
    """

    if isinstance(storage, Path):
        with Storage(storage) as s:
            save_devices(s, devices)
            return

    for device in devices:
        storage[device.name] = device
