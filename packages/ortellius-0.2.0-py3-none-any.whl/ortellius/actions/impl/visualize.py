"""Support functions for visualize action"""

from logging import info
from math import floor
from pathlib import Path

from PIL import Image

from ...theory.definitions import Device

IMAGE_DIMENSIONS = (0x100, 0x100)
ADDRESS_DIMENSIONS = (0x10000, 0x10000)


def visualize_device(i: int, δ: Device, graph_output: Path) -> None:
    """Visualize a device."""

    if i % 1000 == 0:
        info("Visualizing device %d...", i)

    buckets = dict[tuple[int, int], int]()
    x_scale = IMAGE_DIMENSIONS[0] / ADDRESS_DIMENSIONS[0]
    y_scale = IMAGE_DIMENSIONS[1] / ADDRESS_DIMENSIONS[1]
    for a in δ.domain:
        x = floor(a % ADDRESS_DIMENSIONS[0] * x_scale)
        y = floor(a // ADDRESS_DIMENSIONS[0] * y_scale)
        buckets[(x, y)] = buckets.get((x, y), 0) + 1

    img = Image.new("1", IMAGE_DIMENSIONS, 1)
    for (x, y), _count in buckets.items():
        img.putpixel((x, y), 0)
    img.save(graph_output / f"{δ.name.replace('/','_')}.png")
    img.close()
