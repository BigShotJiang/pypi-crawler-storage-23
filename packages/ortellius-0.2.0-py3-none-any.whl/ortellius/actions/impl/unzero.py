"""Support functions for unzero action."""

from ...theory.definitions import Device


def unzero_device(δ: Device) -> Device:
    """
    Remove all addresses from device domain that map to zero.
    """
    return δ.unzero()
