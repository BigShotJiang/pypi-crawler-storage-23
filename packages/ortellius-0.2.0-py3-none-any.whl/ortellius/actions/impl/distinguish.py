"""Support functions for distinguish action."""

from collections.abc import Iterable

from ...theory.definitions import Device


def devs_indistinguishable(batch: Iterable[tuple[Device, Device]]) -> list[bool]:
    """
    Calculate the indistinguishability of a batch of device pairs.
    """

    return [δ1 | δ2 for δ1, δ2 in batch]
