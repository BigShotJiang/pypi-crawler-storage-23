"""Support functions for writing and reading relations from files."""

from logging import info
from pathlib import Path


class UnrelatedRelationFileError(Exception):
    """Error raised when an unrelated relation file is loaded."""

    file_source: str
    expected_source: str

    def __init__(self, file_source: str, expected_source: str) -> None:
        self.file_source = file_source
        self.expected_source = expected_source

    def __str__(self) -> str:
        return (
            f"Tried to load relation file describing {self.file_source} while "
            f"dealing with devices from {self.expected_source}."
        )


def write_indistinguishability_file(
    indistinguishability_file: Path, devs_file: Path, data: set[tuple[str, str]]
) -> None:
    """Write indistinguishability relation to file"""

    info("Writing indistinguishability relation to %s...", indistinguishability_file)
    with indistinguishability_file.open("w") as f:
        f.write(f"indistinguishability\n{devs_file}\n")
        for δ1, δ2 in data:
            f.write(f"{δ1}\t{δ2}\n")


def read_indistinguishability_file(
    indistinguishability_file: Path, devs_file: Path
) -> set[tuple[str, str]]:
    """Read indistinguishability relation from file."""

    info("Reading indistinguishability file...")
    with indistinguishability_file.open("r", encoding="utf-8") as f:
        lines = f.readlines()
    assert (
        lines[0].strip() == "indistinguishability"
    ), "indistinguishability file must begin with 'indistinguishability'"
    if lines[1].strip() != str(devs_file):
        raise UnrelatedRelationFileError(lines[1].strip(), str(devs_file))
    return {((l := line.strip().split("\t"))[0], l[1]) for line in lines[2:]}


def write_equivalence_file(
    equivalence_file: Path, devs_file: Path, classes: set[frozenset[str]]
) -> None:
    """Write equivalence classes to file."""

    info("Writing equivalence file...")
    with equivalence_file.open("w", encoding="utf-8") as f:
        f.write(f"equivalence\n{devs_file}\n")
        for eq in classes:
            f.write("\t".join(sorted(eq)) + "\n")


def read_equivalence_file(equivalence_file: Path, devs_file: Path) -> list[set[str]]:
    """Read equivalence classes from file"""

    with equivalence_file.open("r", encoding="utf-8") as f:
        lines = f.readlines()
    assert (
        lines[0].strip() == "equivalence"
    ), "equivalence file must start with the line 'equivalence'"
    if lines[1].strip() != str(devs_file):
        raise UnrelatedRelationFileError(lines[1].strip(), str(devs_file))
    return [set(line.strip().split("\t")) for line in lines[2:] if line.strip()]
