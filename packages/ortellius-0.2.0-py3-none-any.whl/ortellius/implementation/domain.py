"""Concrete implementations of domains."""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Set
from itertools import batched
from logging import warning
from typing import Any

from ..theory.definitions import Domain


class SetDomain(Domain):
    """
    A domain backed by a set.
    """

    __set: set[int]

    def __init__(self, addresses: Iterable[int] | None = None) -> None:
        if addresses is None:
            self.__set = set()
            return
        self.__set = set(addresses)

    def batch(self, batchsize: int) -> Iterator[Domain]:
        for batch in batched(self.__set, batchsize):
            yield SetDomain(batch)

    def __iter__(self) -> Iterator[int]:
        yield from self.__set

    def __contains__(self, x: object) -> bool:
        return isinstance(x, int) and x in self.__set

    def __len__(self) -> int:
        return len(self.__set)

    def __sub__(self, other: Set[object]) -> Domain:
        return SetDomain(a for a in self if a not in other)

    def __and__(self, other: Set[object]) -> Domain:
        return SetDomain(a for a in self if a in other)

    def __or__[_T](self, other: Set[_T]) -> Domain:
        if not isinstance(other, Domain):
            warning("Mixing domains with non-domains is not recommended.")
            return NotImplemented
        if isinstance(other, RangeDomain):
            return other.__or__(self)
        return SetDomain(self.__set | other)


class RangeDomain(Domain):
    """An efficient implementation of a set of consecutive integers."""

    start: int
    stop: int

    def __init__(self, start: int, stop: int) -> None:
        self.start = start
        self.stop = stop

    @classmethod
    def _from_iterable(cls, it: Iterable[int]) -> SetDomain:
        return SetDomain(it)

    def isdisjoint(self, other: Iterable[Any]) -> bool:
        if isinstance(other, RangeDomain):
            return self.stop <= other.start or other.stop <= self.start
        return super().isdisjoint(other)

    def batch(self, batchsize: int) -> Iterable[Domain]:
        for div in range(self.start, self.stop, batchsize):
            yield RangeDomain(div, min(div + batchsize, self.stop))

    def __iter__(self) -> Iterator[int]:
        return iter(range(self.start, self.stop))

    def __contains__(self, x: object) -> bool:
        return isinstance(x, int) and self.start <= x < self.stop

    def __len__(self) -> int:
        return self.stop - self.start

    def __sub__(self, other: Set[Any]) -> Domain:
        if isinstance(other, RangeDomain):
            if self.isdisjoint(other):
                return self
            return RangeDomain(self.start, other.start) | RangeDomain(
                other.stop, self.stop
            )
        warning("Subtracting non-range domain from range domain.")
        return SetDomain(a for a in self if a not in other)

    def __and__(self, other: Set[object]) -> Domain:
        if isinstance(other, RangeDomain):
            return RangeDomain(max(self.start, other.start), min(self.stop, other.stop))
        return SetDomain(a for a in other if isinstance(a, int) if a in self)

    def __or__[_T](self, other: Set[_T]) -> Domain:
        if not isinstance(other, Domain):
            warning("Mixing domain with non-domain.")
            return NotImplemented
        if isinstance(other, RangeDomain):
            if self.isdisjoint(other):
                warning(
                    "Range domains are disjoint. Converting to SetDomain. "
                    "This may be slow."
                )
                return SetDomain(self) | other
            return RangeDomain(min(self.start, other.start), max(self.stop, other.stop))
        if other <= self:
            return self
        warning(
            f"Mixing range domain {self} with non-range domain contaning "
            f"{(other - self).pick():#010x}. This may be slow."
        )
        return SetDomain(self) | other

    def __le__(self, other: Set[Any]) -> bool:
        if isinstance(other, RangeDomain):
            return self.start >= other.start and self.stop <= other.stop
        return super().__le__(other)

    def __ge__(self, other: Set[Any]) -> bool:
        if isinstance(other, RangeDomain):
            return self.start <= other.start and self.stop >= other.stop
        return super().__ge__(other)

    def __str__(self) -> str:
        return f"[{self.start:#010x}, {self.stop:#010x})"
