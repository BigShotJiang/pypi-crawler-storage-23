"""
Implementations of the Device interface for various backends.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence, Set
from logging import warning
from pathlib import Path
from typing import Never, Self

from serstor.abstract import NativeSerializable, Serializable

from ..theory.definitions import Device, DomainError
from .domain import RangeDomain, SetDomain


class StaticDevice(Device):
    """
    A byte-addressable backed by a mapping.
    """

    __name: str
    data: Mapping[int, int]
    __hash: int | None

    def __init__(self, name: str, data: Mapping[int, int]):
        super().__init__()

        self.__name = name
        self.data = data
        self.__hash = None

    @property
    def domain(self) -> SetDomain:
        return SetDomain(int(k) for k in self.data)

    @property
    def name(self) -> str:
        return self.__name

    @name.setter
    def name(self, value: str) -> None:
        self.__name = value

    def apply(self, a: int) -> int:
        try:
            return self.data[a]
        except KeyError as err:
            raise DomainError(self, a) from err

    def asdict(
        self, from_address: int = 0, to_address: int | None = None
    ) -> dict[int, int]:
        if to_address is None:
            to_address = max(self.domain)
        return {k: v for k, v in self.data.items() if from_address <= k <= to_address}

    def narrow_domain(self, new_domain: Set[int]) -> StaticDevice:
        return StaticDevice(
            self.__name, {k: self.data[k] for k in new_domain & self.domain}
        )

    def unzero(self) -> StaticDevice:
        return StaticDevice(
            self.__name,
            {k: v for k, v in self.data.items() if v != 0},
        )

    @classmethod
    def unserialize(cls, data: Serializable, hint: None = None) -> Self:

        if not isinstance(data, dict):
            raise TypeError("expected dict")
        name = data["name"]
        if not isinstance(name, str):
            raise TypeError("expected key 'name' with string value")
        values = data["values"]
        if not isinstance(values, dict):
            raise TypeError("expected key 'values' with dict value")
        memory: dict[int, int] = {}
        for k, v in values.items():
            if not isinstance(v, int):
                raise TypeError("expected register values to be integers")
            memory[int(k, 16)] = v

        return cls(name, memory)

    def __hash__(self) -> int:
        if self.__hash is None:
            self.__hash = hash(frozenset(self.data.items()))
        return self.__hash

    def __str__(self) -> str:
        return f"StaticDevice: {self.__name}"


class FileDevice(Device):
    """A device based on a memory dump."""

    __data: Sequence[int]
    __name: str

    def __init__(self, file: Path) -> None:
        super().__init__()

        with file.open("rb") as f:
            data = f.read()

        self.__data = data
        self.__name = str(file)

    @property
    def domain(self) -> RangeDomain:
        return RangeDomain(0, len(self.__data))

    @property
    def name(self) -> str:
        return self.__name

    @name.setter
    def name(self, value: str) -> None:
        self.__name = value

    def asdict(
        self, from_address: int = 0, to_address: int | None = None
    ) -> dict[int, int]:
        warning("Turning a file device into a dict. This may be slow.")
        if to_address is None:
            to_address = len(self.__data)
        return {a: self.__data[a] for a in range(from_address, to_address)}

    def apply(self, a: int) -> int:
        try:
            return self.__data[a]
        except IndexError as err:
            raise DomainError(self, a) from err

    def narrow_domain(self, new_domain: Set[int]) -> StaticDevice:
        return StaticDevice(
            self.__name,
            {a: self.__data[a] for a in new_domain & self.domain},
        )

    def unzero(self) -> Device:
        return StaticDevice(
            self.__name, {a: v for a, v in enumerate(self.__data) if v != 0}
        )

    @classmethod
    def unserialize(cls, data: NativeSerializable, hint: None = None) -> Never:
        raise NotImplementedError("Serialization not implemented for FileDevice")

    def __hash__(self) -> int:
        return hash(self.__name)
