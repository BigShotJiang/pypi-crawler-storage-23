"""typeguards and stuff"""

from collections.abc import Set
from typing import Any, TypeGuard, cast, overload


@overload
def is_set[T](x: Any, t: type[T]) -> TypeGuard[Set[T]]: ...
@overload
def is_set(x: Any) -> TypeGuard[Set[object]]: ...
def is_set(x: Any, t: type[object] = object) -> bool:
    """Check if a set is a set of a certain type."""

    if not isinstance(x, Set):
        return False
    if t is object:
        return True

    s = cast(Set[object], x)
    return all(isinstance(y, t) for y in s)
