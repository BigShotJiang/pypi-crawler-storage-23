"""
Models defined in other projects that are not yet importable via pip.
"""

from typing import TypeIs, cast
from pydantic import BaseModel, field_serializer, field_validator


# from ikea_firmware
def is_set_of_ints(value: object) -> TypeIs[set[int]]:
    """Type narrowing function."""
    return isinstance(value, set) and all(
        isinstance(i, int) for i in cast(set[object], value)
    )


def is_list_of_strs(value: object) -> TypeIs[list[str]]:
    """Type narrowing function."""
    return isinstance(value, list) and all(
        isinstance(i, str) for i in cast(list[object], value)
    )


class AnalysisResult(BaseModel):
    """Serializable result of an analysis."""

    read: set[int]
    write: set[int]

    @field_serializer("read", "write")
    def serialize_read(self, value: list[int]) -> list[str]:
        """serialize hexadecimally"""
        return [f"{addr:08x}" for addr in sorted(value)]

    @field_validator("read", "write", mode="before")
    @classmethod
    def validate_from_hex(cls, value: object) -> set[int]:
        """unserialize from hex"""

        if is_set_of_ints(value):
            return value

        if is_list_of_strs(value):
            return {int(v, 16) for v in value}

        raise ValueError("Unexpected type.")
