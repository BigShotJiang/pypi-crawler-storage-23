"""
Test ortellius.
"""

import unittest
from pathlib import Path
from shutil import rmtree
from tempfile import mkdtemp

from ..actions import collapse, distinguish, equivalence, reduce, unzero
from ..actions.impl.common import load_devices, save_devices
from ..actions.impl.relation_files import (
    UnrelatedRelationFileError,
    read_equivalence_file,
    read_indistinguishability_file,
)
from ..implementation.device import StaticDevice


class TestUserCommands(unittest.TestCase):
    """Test CLI commands."""

    tempdir: Path

    def setUp(self) -> None:
        self.tempdir = Path(mkdtemp())
        self.addCleanup(lambda: rmtree(self.tempdir))

        Δ = {
            StaticDevice("d0", {0: 0}),
            StaticDevice("d1", {1: 1, 100: 0, 101: 0}),
            StaticDevice("d2", {2: 2, 100: 1}),
            StaticDevice("d3", {3: 3, 101: 1}),
            StaticDevice("d4", {4: 4, 100: 2}),
            StaticDevice("d5", {5: 5, 100: 3, 101: 2}),
            StaticDevice("d6", {6: 6, 100: 3, 101: 2}),
            StaticDevice("d7", {7: 7, 100: 3, 101: 3}),
            StaticDevice("d8", {8: 8, 100: 3, 101: 3}),
            StaticDevice("d9", {9: 9, 100: 3, 101: 3}),
        }
        save_devices(self.tempdir / "devs", Δ)

    def test_collapse(self) -> None:
        """Test command: collapse."""

        distinguish(self.tempdir / "devs", self.tempdir / "dist")
        equivalence(
            self.tempdir / "dist",
            self.tempdir / "equiv",
            self.tempdir / "devs",
        )
        collapse(
            self.tempdir / "devs",
            self.tempdir / "equiv",
            self.tempdir / "coll",
        )

        devs = load_devices(self.tempdir / "coll")
        self.assertSetEqual(
            devs,
            {
                StaticDevice("d0", {0: 0}),
                StaticDevice("d1", {1: 1, 100: 0, 101: 0}),
                StaticDevice("d2", {2: 2, 100: 1}),
                StaticDevice("d3", {3: 3, 101: 1}),
                StaticDevice("d4", {4: 4, 100: 2}),
                StaticDevice("d5 (collapsed 2)", {100: 3, 101: 2}),
                StaticDevice("d7 (collapsed 3)", {100: 3, 101: 3}),
            },
        )

    def test_distinguish(self) -> None:
        """Test command: distinguish."""

        distinguish(self.tempdir / "devs", self.tempdir / "dist")

        relation = {
            frozenset(t)
            for t in read_indistinguishability_file(
                self.tempdir / "dist", self.tempdir / "devs"
            )
        }
        self.assertSetEqual(
            relation,
            {
                frozenset({"d0", "d1"}),
                frozenset({"d0", "d2"}),
                frozenset({"d0", "d3"}),
                frozenset({"d0", "d4"}),
                frozenset({"d0", "d5"}),
                frozenset({"d0", "d6"}),
                frozenset({"d0", "d7"}),
                frozenset({"d0", "d8"}),
                frozenset({"d0", "d9"}),
                frozenset({"d2", "d3"}),
                frozenset({"d3", "d4"}),
                frozenset({"d5", "d6"}),
                frozenset({"d7", "d8"}),
                frozenset({"d7", "d9"}),
                frozenset({"d8", "d9"}),
            },
        )

    def test_equivalence(self) -> None:
        """Test command: equivalence."""

        distinguish(self.tempdir / "devs", self.tempdir / "dist")
        equivalence(
            self.tempdir / "dist",
            self.tempdir / "equiv",
            self.tempdir / "devs",
        )

        classes = {
            frozenset(eq)
            for eq in read_equivalence_file(
                self.tempdir / "equiv", self.tempdir / "devs"
            )
        }

        self.assertSetEqual(
            classes,
            {
                frozenset({"d0"}),
                frozenset({"d1"}),
                frozenset({"d2"}),
                frozenset({"d3"}),
                frozenset({"d4"}),
                frozenset({"d5", "d6"}),
                frozenset({"d7", "d8", "d9"}),
            },
        )

    def test_reduce(self) -> None:
        """Test reduce action."""

        reduce(self.tempdir / "devs", self.tempdir / "red", 2)

        devs = load_devices(self.tempdir / "red")
        self.assertSetEqual(
            devs,
            {
                StaticDevice("d0", {}),
                StaticDevice("d1", {100: 0, 101: 0}),
                StaticDevice("d2", {100: 1}),
                StaticDevice("d3", {101: 1}),
                StaticDevice("d4", {100: 2}),
                StaticDevice("d5", {100: 3, 101: 2}),
                StaticDevice("d6", {100: 3, 101: 2}),
                StaticDevice("d7", {100: 3, 101: 3}),
                StaticDevice("d8", {100: 3, 101: 3}),
                StaticDevice("d9", {100: 3, 101: 3}),
            },
        )

    def test_unzero(self) -> None:
        """Test unzero action"""

        unzero(self.tempdir / "devs", self.tempdir / "unzero")

        devs = load_devices(self.tempdir / "unzero")
        self.assertSetEqual(
            devs,
            {
                StaticDevice("d0", {}),
                StaticDevice("d1", {1: 1}),
                StaticDevice("d2", {2: 2, 100: 1}),
                StaticDevice("d3", {3: 3, 101: 1}),
                StaticDevice("d4", {4: 4, 100: 2}),
                StaticDevice("d5", {5: 5, 100: 3, 101: 2}),
                StaticDevice("d6", {6: 6, 100: 3, 101: 2}),
                StaticDevice("d7", {7: 7, 100: 3, 101: 3}),
                StaticDevice("d8", {8: 8, 100: 3, 101: 3}),
                StaticDevice("d9", {9: 9, 100: 3, 101: 3}),
            },
        )

    def test_unzero_collapse(self) -> None:
        """Test collapsing devices after unzeroing them."""

        distinguish(self.tempdir / "devs", self.tempdir / "dist")
        equivalence(
            self.tempdir / "dist",
            self.tempdir / "equiv",
            self.tempdir / "devs",
        )
        unzero(self.tempdir / "devs", self.tempdir / "unzero")
        distinguish(self.tempdir / "unzero", self.tempdir / "dist")
        equivalence(
            self.tempdir / "dist",
            self.tempdir / "equiv",
            self.tempdir / "unzero",
        )
        collapse(
            self.tempdir / "unzero",
            self.tempdir / "equiv",
            self.tempdir / "coll",
        )

        devs = load_devices(self.tempdir / "coll")
        self.assertSetEqual(
            devs,
            {
                StaticDevice("d0 (collapsed 2)", {}),
                StaticDevice("d2", {2: 2, 100: 1}),
                StaticDevice("d3", {3: 3, 101: 1}),
                StaticDevice("d4", {4: 4, 100: 2}),
                StaticDevice("d5 (collapsed 2)", {100: 3, 101: 2}),
                StaticDevice("d7 (collapsed 3)", {100: 3, 101: 3}),
            },
        )

    def test_collapse_using_unrelated_indistinguishability_file(self) -> None:
        """Test collapse action with an unrelated indistinguishability file."""

        distinguish(self.tempdir / "devs", self.tempdir / "dist")
        equivalence(
            self.tempdir / "dist",
            self.tempdir / "equiv",
            self.tempdir / "devs",
        )
        reduce(self.tempdir / "devs", self.tempdir / "red", 2)
        with self.assertRaises(UnrelatedRelationFileError):
            collapse(
                self.tempdir / "red",
                self.tempdir / "equiv",
                self.tempdir / "coll",
            )

    def test_reduce_collapse(self) -> None:
        """Test reduce action followed by collapse."""

        distinguish(self.tempdir / "devs", self.tempdir / "dist")
        equivalence(
            self.tempdir / "dist",
            self.tempdir / "equiv",
            self.tempdir / "devs",
        )
        reduce(self.tempdir / "devs", self.tempdir / "red", 2)

        distinguish(self.tempdir / "red", self.tempdir / "dist")
        equivalence(
            self.tempdir / "dist",
            self.tempdir / "equiv",
            self.tempdir / "red",
        )
        collapse(
            self.tempdir / "red",
            self.tempdir / "equiv",
            self.tempdir / "coll",
        )

        devs = load_devices(self.tempdir / "coll")
        self.assertSetEqual(
            devs,
            {
                StaticDevice("d0", {}),
                StaticDevice("d1", {100: 0, 101: 0}),
                StaticDevice("d2", {100: 1}),
                StaticDevice("d3", {101: 1}),
                StaticDevice("d4", {100: 2}),
                StaticDevice("d5 (collapsed 2)", {100: 3, 101: 2}),
                StaticDevice("d7 (collapsed 3)", {100: 3, 101: 3}),
            },
        )
