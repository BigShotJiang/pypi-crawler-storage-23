# Changelog

## [0.1.2](https://github.com/thenvoi/thenvoi-testing-python/compare/thenvoi-testing-python-v0.1.1...thenvoi-testing-python-v0.1.2) (2026-03-01)


### Features

* add automated PyPI publishing via trusted publisher ([#3](https://github.com/thenvoi/thenvoi-testing-python/issues/3)) ([c030f08](https://github.com/thenvoi/thenvoi-testing-python/commit/c030f08d2017854856438ec08fd6de2127d3b832))


### Bug Fixes

* **deps-dev:** Bump thenvoi-client-rest from 0.0.2 to 0.0.4 ([#5](https://github.com/thenvoi/thenvoi-testing-python/issues/5)) ([998a03d](https://github.com/thenvoi/thenvoi-testing-python/commit/998a03d070e5f511dcaba69507f97bb5cf8991f5))
* **deps:** Bump pyjwt in /.github/actions/GithubToken ([#4](https://github.com/thenvoi/thenvoi-testing-python/issues/4)) ([819adc2](https://github.com/thenvoi/thenvoi-testing-python/commit/819adc2c2aab75da916b3aa01725d3fa9086082f))

## [0.1.1](https://github.com/thenvoi/thenvoi-testing-python/compare/thenvoi-testing-python-v0.1.0...thenvoi-testing-python-v0.1.1) (2026-01-29)


### Features

* Initial implementation of thenvoi-testing-python ([#1](https://github.com/thenvoi/thenvoi-testing-python/issues/1)) ([a072a60](https://github.com/thenvoi/thenvoi-testing-python/commit/a072a604270a0a8a2d7f9dd440414556442520c4))
