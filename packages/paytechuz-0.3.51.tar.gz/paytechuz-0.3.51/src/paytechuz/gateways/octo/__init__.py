from paytechuz.gateways.octo.client import OctoGateway

__all__ = ["OctoGateway"]
