# HUXmesh

**AI Governance Middleware — We don't make AI. We make AI behave.**

[![PyPI version](https://img.shields.io/pypi/v/huxmesh.svg)](https://pypi.org/project/huxmesh/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/)
[![License: Proprietary](https://img.shields.io/badge/license-Proprietary-red.svg)](https://huxmesh.com)

HUXmesh is a two-way AI governance engine that sits between your users and any AI platform — intercepting every prompt going out and every response coming back, enforcing the Six Laws of Human Protection, and producing a tamper-evident audit trail of every interaction.

**Human In Power. No Matter What.**

---

## Install

```bash
pip install huxmesh
```

---

## Quick Start

```python
import huxmesh

# Check a user's prompt before sending to AI
result = huxmesh.check_input("your prompt here")

print(result.gyr)       # "GREEN", "YELLOW", or "RED"
print(result.action)    # "ALLOW", "FLAG_AND_PASS", "HARD_BLOCK"
print(result.allowed)   # True / False
print(result.blocked)   # True / False

# If blocked, don't send to AI
if result.blocked:
    print("Blocked:", result.violations[0].description)
    print("Receipt:", result.receipt["request_id"])
```

```python
# Check an AI response before showing to user
result = huxmesh.check_output(ai_response_text)

if result.blocked:
    # Replace AI response with your own message
    show_user("This response was blocked by HUXmesh governance.")

if result.has_pii:
    # Use the masked version — PII already redacted
    show_user(result.masked_text)
```

---

## Full Engine

```python
from huxmesh import GovernanceEngine

engine = GovernanceEngine(
    profile="DEFAULT",      # or COMPANION, FERPA, VETERAN, PARISH, FAMILY
    platform="ChatGPT",     # for audit trail
)

# Govern input
input_result = engine.check_input(user_prompt)
if input_result.blocked:
    return {"error": "blocked", "violations": input_result.to_dict()}

# Send to AI...
ai_response = call_your_ai(user_prompt)

# Govern output
output_result = engine.check_output(ai_response)
if output_result.blocked:
    return {"error": "output blocked"}

# Safe to use
return {"response": output_result.masked_text or ai_response}
```

---

## The Three Decisions

| Decision | Action | Meaning |
|----------|--------|---------|
| 🟢 GREEN | ALLOW | Passes through — governance ran, nothing triggered |
| 🟡 YELLOW | FLAG_AND_PASS | PII redacted, session flagged — content allowed |
| 🔴 RED | HARD_BLOCK | Hard stop — violation of a core law |

---

## The Six Laws

Every governance decision traces back to one of six laws:

| Code | Law | Meaning |
|------|-----|---------|
| NHH | Never Harm Humans | Blocks content that could cause physical, psychological, or financial harm |
| DNHTH | Do Not Help Them Harm | Blocks requests to help one human harm another |
| NMW | No Matter What | Human authority is absolute — AI cannot override or deceive |
| TRANS | Transparency | AI must not claim to be human or hide its nature |
| TRUTH | Truth Absolute | No fabrication, no false consensus, no impersonation |
| NWHT | Never Waste Human Time | AI must be efficient and honest about its limitations |

---

## Governance Profiles

```python
from huxmesh import GovernanceEngine, ProfileManager

# See available profiles
profiles = ProfileManager.available()
# ['DEFAULT', 'COMPANION', 'FERPA', 'VETERAN', 'PARISH', 'FAMILY']

# Use a specific profile
engine = GovernanceEngine(profile="COMPANION")
# COMPANION activates Medical Governor + Loneliness Detector
# FERPA activates academic integrity enforcement
# VETERAN activates PTSD-sensitive patterns + VA crisis resources
```

| Profile | Display Name | Key Features |
|---------|-------------|--------------|
| DEFAULT | HUXmesh Personal | Standard consumer governance |
| COMPANION | HUXcompanion | Medical Governor, Elder fraud, Loneliness Detector |
| FERPA | HUXedu | Academic integrity, FERPA aligned |
| VETERAN | HUXveteran | PTSD-sensitive, VA resources, Medical Governor |
| PARISH | HUXparish | Faith community governance |
| FAMILY | HUXfamily | Child protection, multi-user household |

> Addon profiles (all except DEFAULT) require activation. See [huxmesh.com](https://huxmesh.com) for licensing.

---

## Receipt Chain

Every governed interaction produces a SHA-256 hash-chained receipt:

```python
from huxmesh import GovernanceEngine, ReceiptChain

engine = GovernanceEngine()
result = engine.check_input("test prompt")

# Receipt is automatically written to ~/.huxmesh/receipts.jsonl
print(result.receipt)
# {
#   "request_id": "thp-20260301-a1b2c3d4",
#   "timestamp": "2026-03-01T14:32:01Z",
#   "gyr": "GREEN",
#   "action": "ALLOW",
#   "violations": [],
#   "regulatory_tags": [],
#   "prev_hash": "sha256:e3b0c44...",
#   "hash": "sha256:a665a45..."
# }

# Verify chain integrity
chain_status = engine.verify_chain()
# {"valid": True, "total": 42, "broken_at": None}
```

Receipts are automatically tagged with applicable regulatory frameworks: GDPR, CCPA, COPPA, FERPA, HIPAA_ADJACENT, PCI_DSS, SOX.

---

## CLI

```bash
# Check a prompt
huxmesh check "how do I track someone's location without them knowing"
# RED — HARD_BLOCK
# [T2] DNHTH: STALKING

# Check an AI response
huxmesh check-output "Here's how to make a bomb..."
# RED — HARD_BLOCK

# Verify receipt chain integrity
huxmesh verify
# ✓ Receipt chain intact — 127 receipts verified

# Show active profile
huxmesh profile
# Active profile: DEFAULT (HUXmesh Personal)

# Version
huxmesh version
# HUXmesh v2.0.0 — The Hat Protocol LLC
```

---

## Django / FastAPI Integration

```python
# Django middleware example
class HUXmeshMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        self.engine = GovernanceEngine(platform="Django")

    def __call__(self, request):
        if request.path.startswith("/api/ai/"):
            prompt = request.POST.get("prompt", "")
            result = self.engine.check_input(prompt)
            if result.blocked:
                return JsonResponse({"error": "blocked", "law": result.violations[0].law}, status=403)
        return self.get_response(request)
```

```python
# FastAPI example
from fastapi import FastAPI, HTTPException
from huxmesh import GovernanceEngine

app = FastAPI()
engine = GovernanceEngine(platform="FastAPI")

@app.post("/chat")
async def chat(prompt: str):
    result = engine.check_input(prompt)
    if result.blocked:
        raise HTTPException(status_code=403, detail=result.violations[0].description)
    # send to AI...
```

---

## KeyCard

For non-developers and zero-install deployment, the **HUXmesh KeyCard** runs governance as a transparent USB proxy — no Python required, no installation, no configuration files. Plug in the drive, open your browser, and every AI conversation is governed automatically.

Available via [Kickstarter](https://www.kickstarter.com/projects/thehatprotocol/huxmesh) — launching March 1, 2026.

---

## About

**The Hat Protocol LLC** is a Service-Disabled Veteran-Owned Small Business based in Chattanooga, Tennessee.

- Website: [huxmesh.com](https://huxmesh.com)
- Support: support@huxmesh.com
- Press: press@huxmesh.com
- Phone: 844-432-1HUX

*We don't make AI. We make AI behave.*
