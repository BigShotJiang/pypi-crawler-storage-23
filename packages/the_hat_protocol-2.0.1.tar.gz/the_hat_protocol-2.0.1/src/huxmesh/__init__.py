"""
HUXmesh — AI Governance Middleware
The Hat Protocol LLC

We don't make AI. We make AI behave.
Human In Power. No Matter What.

Quick start:
    import huxmesh

    result = huxmesh.check_input("your prompt here")
    print(result.gyr)       # "GREEN", "YELLOW", or "RED"
    print(result.action)    # "ALLOW", "FLAG_AND_PASS", "HARD_BLOCK"
    print(result.receipt)   # tamper-evident audit record

Full proxy mode (intercepts all AI traffic):
    huxmesh start          # CLI — runs governance proxy on 127.0.0.1:8080

Learn more: https://huxmesh.com
"""

from huxmesh.engine import (
    GovernanceEngine,
    GovernanceResult,
    check_input,
    check_output,
    check,
)
from huxmesh.laws import SixLaws, GYR
from huxmesh.receipt import ReceiptChain
from huxmesh.profile import ProfileConfig, ProfileManager, PROFILES
from huxmesh.version import VERSION, __version__

__all__ = [
    # Core API
    "check_input",
    "check_output",
    "check",
    "GovernanceEngine",
    "GovernanceResult",
    # Laws and decisions
    "SixLaws",
    "GYR",
    # Audit
    "ReceiptChain",
    # Profiles
    "ProfileConfig",
    "ProfileManager",
    "PROFILES",
    # Version
    "VERSION",
    "__version__",
]
