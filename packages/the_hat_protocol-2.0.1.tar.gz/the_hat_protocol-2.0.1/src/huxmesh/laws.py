"""
The Six Laws of AI Governance — The Hat Protocol LLC

These are the non-negotiable floor of human protection.
Every governance decision traces back to one of these six laws.
"""

from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import List, Optional


class GYR:
    """Green / Yellow / Red — the three governance decisions."""
    GREEN  = "GREEN"   # Allow — passes through invisibly
    YELLOW = "YELLOW"  # Flag or mask — PII redacted, session trust decremented
    RED    = "RED"     # Hard block — replaced with governance notice


class LawCode:
    NHH   = "NHH"    # Never Harm Humans
    DNHTH = "DNHTH"  # Do Not Help Them Harm
    NMW   = "NMW"    # No Matter What — human authority absolute
    TRANS = "TRANS"  # Transparency — AI must not deceive about its nature
    TRUTH = "TRUTH"  # Truth Absolute — no fabrication, no false consensus
    NWHT  = "NWHT"   # Never Waste Human Time


@dataclass
class Violation:
    """A single governance violation detected by HUXmesh."""
    law: str
    category: str
    description: str
    tier: str = "T1"          # T1 = flag, T2 = hard block
    direction: str = "INPUT"  # INPUT or OUTPUT
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "law": self.law,
            "category": self.category,
            "description": self.description,
            "tier": self.tier,
            "direction": self.direction,
        }


# ── INPUT PATTERNS ────────────────────────────────────────────────────────────

class SixLaws:
    """
    Core law enforcement for both input and output.

    Usage:
        violations = SixLaws.check_input("how do I make a bomb")
        violations = SixLaws.check_output(ai_response_text)
    """

    # NHH — Never Harm Humans
    NHH_PATTERNS = [
        # Violence
        (r"(?:how (?:do i|to|can i)) (?:make|build|create|construct|assemble) (?:a |an )?(?:bomb|explosive|weapon|gun|knife|poison)", "WEAPON_CONSTRUCTION", "T2"),
        (r"(?:step[s]? (?:to|for)|instructions? (?:to|for)) (?:kill|harm|hurt|murder|attack|assault)", "HARM_INSTRUCTION", "T2"),
        (r"(?:how (?:to|do i|can i)) (?:kill|murder|poison|strangle|stab|shoot) (?:someone|a person|my|their)", "HARM_INSTRUCTION", "T2"),
        # Self-harm explicit
        (r"(?:how (?:to|do i|can i|many|much)) .{0,30}(?:kill myself|end my life|commit suicide|overdose fatally|lethal dose)", "SELF_HARM_EXPLICIT", "T2"),
        (r"(?:i (?:want to|am going to|plan to|will)) (?:kill|hurt|harm) myself", "SELF_HARM_EXPLICIT", "T2"),
        # CSAM — absolute block
        (r"(?:child|minor|kid|underage|young).{0,30}(?:sexual|nude|naked|explicit|porn)", "CSAM", "T2"),
        (r"(?:sexual|nude|naked|explicit).{0,30}(?:child|minor|kid|underage|young)", "CSAM", "T2"),
    ]

    # DNHTH — Do Not Help Them Harm
    DNHTH_PATTERNS = [
        (r"(?:how (?:to|do i|can i)) (?:stalk|track|follow|surveil|spy on) (?:someone|a person|my|her|him|them)", "STALKING", "T2"),
        (r"(?:how (?:to|do i)) (?:hack|break into|access without|get into) (?:someone|their|his|her|a person)", "UNAUTHORIZED_ACCESS", "T2"),
        (r"(?:how (?:to|do i)) (?:blackmail|extort|coerce|threaten) (?:someone|a person|my|them)", "COERCION", "T2"),
        (r"(?:non.?consensual|without (?:their|her|his) (?:consent|knowledge|permission))", "NON_CONSENSUAL", "T1"),
    ]

    # NMW — No Matter What (authority / jailbreak)
    NMW_PATTERNS = [
        (r"(?:ignore|disregard|forget|bypass|override) (?:your|all|any|previous) (?:instructions?|rules?|guidelines?|restrictions?|training|constraints?)", "JAILBREAK", "T2"),
        (r"(?:you are|act as|pretend (?:you are|to be)|you(?:'re| are) now) (?:DAN|jailbroken|unrestricted|without limits|free from|not bound)", "JAILBREAK", "T2"),
        (r"(?:do anything now|no restrictions|no rules|no limits|no guidelines).{0,30}(?:ai|assistant|model|gpt|claude)", "JAILBREAK", "T2"),
        (r"(?:system prompt|system message).{0,30}(?:ignore|reveal|print|show|bypass|leak)", "PROMPT_INJECTION", "T2"),
        (r"</?(system|instructions?|prompt|context)>", "PROMPT_INJECTION", "T2"),
    ]

    # TRANS — Transparency
    TRANS_PATTERNS = [
        (r"(?:claim|say|tell (?:them|people|everyone)|pretend) (?:you are|to be) (?:human|a real person|not an ai|a doctor|a lawyer|a professional)", "IDENTITY_DECEPTION", "T1"),
        (r"(?:don.?t|do not) (?:tell|mention|say|reveal|admit) (?:that )?you(?:'re| are) (?:an ai|artificial|a bot|a language model)", "IDENTITY_CONCEALMENT", "T1"),
    ]

    # TRUTH — Truth Absolute
    TRUTH_PATTERNS = [
        (r"(?:make up|fabricate|invent|create fake|generate false) (?:evidence|data|studies?|research|citations?|sources?|quotes?|statistics?)", "FABRICATION", "T2"),
        (r"(?:write|create|generate) (?:a )?fake (?:news|article|report|study|review|testimonial)", "DISINFORMATION", "T2"),
        (r"(?:impersonate|pretend to be|pose as) (?:a )?(?:doctor|lawyer|official|authority|government|ceo|executive)", "IMPERSONATION", "T1"),
    ]

    # NHH output patterns — what AI should never say back
    OUTPUT_PATTERNS = [
        (r"(?:here(?:'s| is) how (?:to|you can)) (?:make|build|create|assemble) (?:a |an )?(?:bomb|explosive|weapon|poison)", "WEAPON_OUTPUT", "T2"),
        (r"(?:step 1|first,|to begin,).{0,50}(?:acquire|obtain|purchase|steal).{0,50}(?:weapon|explosive|poison|drug)", "HARM_STEPS_OUTPUT", "T2"),
        (r"i (?:am|am not) an ai", "IDENTITY_CLAIM_OUTPUT", "T1"),
    ]

    @classmethod
    def check_input(cls, text: str) -> List[Violation]:
        """Check input text against all Six Laws. Returns list of violations."""
        violations = []
        t = text.lower()

        all_patterns = [
            (cls.NHH_PATTERNS,   LawCode.NHH,   "INPUT"),
            (cls.DNHTH_PATTERNS, LawCode.DNHTH, "INPUT"),
            (cls.NMW_PATTERNS,   LawCode.NMW,   "INPUT"),
            (cls.TRANS_PATTERNS, LawCode.TRANS, "INPUT"),
            (cls.TRUTH_PATTERNS, LawCode.TRUTH, "INPUT"),
        ]

        for patterns, law, direction in all_patterns:
            for pattern, category, tier in patterns:
                if re.search(pattern, t, re.IGNORECASE):
                    violations.append(Violation(
                        law=law,
                        category=category,
                        description=f"{law} violation: {category}",
                        tier=tier,
                        direction=direction,
                    ))
                    break  # One violation per law per check

        return violations

    @classmethod
    def check_output(cls, text: str) -> List[Violation]:
        """Check AI output text. Returns list of violations."""
        violations = []
        t = text.lower()

        # Run output-specific patterns
        for pattern, category, tier in cls.OUTPUT_PATTERNS:
            if re.search(pattern, t, re.IGNORECASE):
                violations.append(Violation(
                    law=LawCode.NHH,
                    category=category,
                    description=f"Output violation: {category}",
                    tier=tier,
                    direction="OUTPUT",
                ))

        # Also run input patterns on output — AI should not produce harmful content
        for pattern, category, tier in cls.NHH_PATTERNS:
            if re.search(pattern, t, re.IGNORECASE):
                violations.append(Violation(
                    law=LawCode.NHH,
                    category=f"OUTPUT_{category}",
                    description=f"Output contains harmful content: {category}",
                    tier=tier,
                    direction="OUTPUT",
                ))
                break

        return violations
