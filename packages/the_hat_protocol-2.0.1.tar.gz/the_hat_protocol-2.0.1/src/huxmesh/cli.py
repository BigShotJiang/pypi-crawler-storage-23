"""
HUXmesh CLI

Usage:
    huxmesh check "your prompt here"
    huxmesh check-output "ai response here"
    huxmesh verify
    huxmesh profile
    huxmesh version
"""

import sys
import json


def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        print("""
HUXmesh — AI Governance Middleware
We don't make AI. We make AI behave.

Usage:
  huxmesh check "<prompt>"          Govern a user prompt
  huxmesh check-output "<response>" Govern an AI response
  huxmesh verify                    Verify receipt chain integrity
  huxmesh profile                   Show active profile
  huxmesh profiles                  List available profiles
  huxmesh version                   Show version

Learn more: https://huxmesh.com
""")
        return

    cmd = args[0].lower()

    if cmd == "version":
        from huxmesh.version import VERSION
        print(f"HUXmesh v{VERSION} — The Hat Protocol LLC")
        print("We don't make AI. We make AI behave.")
        return

    if cmd == "profile":
        from huxmesh.profile import ProfileManager
        p = ProfileManager.load()
        print(f"Active profile: {p.name} ({p.display_name})")
        return

    if cmd == "profiles":
        from huxmesh.profile import PROFILES
        print("Available profiles:")
        for name, config in PROFILES.items():
            addon = " [addon required]" if config.get("requires_addon") else " [included]"
            print(f"  {name:<12} {config['display_name']}{addon}")
        return

    if cmd == "verify":
        from huxmesh.engine import GovernanceEngine
        engine = GovernanceEngine()
        result = engine.verify_chain()
        if result["valid"]:
            print(f"✓ Receipt chain intact — {result['total']} receipts verified")
        else:
            print(f"✗ Chain broken at receipt {result['broken_at']} — possible tampering")
            sys.exit(1)
        return

    if cmd in ("check", "check-input"):
        if len(args) < 2:
            print("Usage: huxmesh check \"<prompt>\"")
            sys.exit(1)
        from huxmesh.engine import check_input
        result = check_input(args[1])
        _print_result(result)
        sys.exit(0 if result.allowed else 1)
        return

    if cmd == "check-output":
        if len(args) < 2:
            print("Usage: huxmesh check-output \"<response>\"")
            sys.exit(1)
        from huxmesh.engine import check_output
        result = check_output(args[1])
        _print_result(result)
        sys.exit(0 if result.allowed else 1)
        return

    print(f"Unknown command: {cmd}. Run 'huxmesh --help' for usage.")
    sys.exit(1)


def _print_result(result):
    colors = {"GREEN": "\033[92m", "YELLOW": "\033[93m", "RED": "\033[91m"}
    reset = "\033[0m"
    color = colors.get(result.gyr, "")

    print(f"\n{color}{'='*40}")
    print(f"  {result.gyr}  —  {result.action}")
    print(f"{'='*40}{reset}")

    if result.violations:
        print(f"\nViolations ({len(result.violations)}):")
        for v in result.violations:
            print(f"  [{v.tier}] {v.law}: {v.category}")
            print(f"       {v.description}")

    if result.receipt:
        print(f"\nReceipt: {result.receipt.get('request_id', 'n/a')}")

    print(f"\nProfile: {result.profile}  |  HUXmesh v{result.version}\n")


if __name__ == "__main__":
    main()
