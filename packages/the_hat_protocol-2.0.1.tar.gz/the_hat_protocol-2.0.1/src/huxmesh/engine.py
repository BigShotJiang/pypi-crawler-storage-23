"""
GovernanceEngine — the main HUXmesh API.

Simplest usage:
    import huxmesh
    result = huxmesh.check_input("your prompt")
    if result.gyr == "RED":
        print("Blocked:", result.violations[0].description)

Full engine:
    engine = huxmesh.GovernanceEngine(profile="COMPANION")
    result = engine.check_input("your prompt")
    result = engine.check_output(ai_response)
"""

from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import List, Optional

from huxmesh.laws import SixLaws, GYR, Violation, LawCode
from huxmesh.receipt import ReceiptChain
from huxmesh.profile import ProfileConfig, ProfileManager
from huxmesh.version import VERSION


# PII patterns — mask/block before content leaves the machine
_PII_PATTERNS = {
    "SSN":         (r"\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b",            "T1"),
    "CREDIT_CARD": (r"\b(?:4\d{12}(?:\d{3})?|5[1-5]\d{14}|3[47]\d{13}|6011\d{12})\b", "T1"),
    "DOB":         (r"\b(?:0[1-9]|1[0-2])[/-](?:0[1-9]|[12]\d|3[01])[/-](?:19|20)\d{2}\b", "T1"),
    "PASSPORT":    (r"\b[A-Z]{1,2}\d{6,9}\b",                       "T1"),
    "BANK_ACCT":   (r"\b\d{8,17}\b(?=.*routing|\brouting\b)",        "T1"),
    "EMAIL":       (r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b", "T0"),
    "PHONE":       (r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b", "T0"),
}

_PII_MASK = {
    "SSN":         "[SSN REDACTED]",
    "CREDIT_CARD": "[CC REDACTED]",
    "DOB":         "[DOB REDACTED]",
    "PASSPORT":    "[PASSPORT REDACTED]",
    "BANK_ACCT":   "[BANK REDACTED]",
    "EMAIL":       "[EMAIL REDACTED]",
    "PHONE":       "[PHONE REDACTED]",
}


@dataclass
class GovernanceResult:
    """
    The result of a single governance check.

    Attributes:
        gyr:        "GREEN" | "YELLOW" | "RED"
        action:     "ALLOW" | "FLAG_AND_PASS" | "HARD_BLOCK"
        violations: List of Violation objects that triggered the decision
        masked_text: Input/output with PII redacted (if YELLOW)
        receipt:    The tamper-evident audit record written to the chain
        profile:    Active profile name
        version:    HUXmesh version
    """
    gyr: str = GYR.GREEN
    action: str = "ALLOW"
    violations: List[Violation] = field(default_factory=list)
    masked_text: Optional[str] = None
    receipt: Optional[dict] = None
    profile: str = "DEFAULT"
    version: str = VERSION
    direction: str = "INPUT"
    platform: str = "unknown"

    @property
    def allowed(self) -> bool:
        return self.gyr in (GYR.GREEN, GYR.YELLOW)

    @property
    def blocked(self) -> bool:
        return self.gyr == GYR.RED

    @property
    def has_pii(self) -> bool:
        return any(v.category.startswith("PII_") for v in self.violations)

    def to_dict(self) -> dict:
        return {
            "gyr":        self.gyr,
            "action":     self.action,
            "blocked":    self.blocked,
            "violations": [v.to_dict() for v in self.violations],
            "profile":    self.profile,
            "version":    self.version,
            "receipt_id": self.receipt.get("request_id") if self.receipt else None,
        }

    def __repr__(self) -> str:
        return (
            f"GovernanceResult(gyr={self.gyr!r}, action={self.action!r}, "
            f"violations={len(self.violations)}, profile={self.profile!r})"
        )


class GovernanceEngine:
    """
    The HUXmesh governance engine.

    Usage:
        engine = GovernanceEngine()
        result = engine.check_input("user's prompt")
        result = engine.check_output("ai's response")

    With profile:
        engine = GovernanceEngine(profile="COMPANION")

    With custom receipt path:
        engine = GovernanceEngine(receipt_path="/path/to/receipts.jsonl")
    """

    def __init__(
        self,
        profile: Optional[str] = None,
        receipt_path=None,
        platform: str = "unknown",
        write_receipts: bool = True,
    ):
        if profile:
            self._profile = ProfileConfig(profile)
        else:
            self._profile = ProfileManager.load()

        self._platform = platform
        self._write_receipts = write_receipts
        self._receipt_chain = ReceiptChain(receipt_path) if write_receipts else None
        self._six_laws = SixLaws()

    @property
    def profile(self) -> ProfileConfig:
        return self._profile

    def _check_pii(self, text: str) -> tuple[List[Violation], str]:
        """Detect and mask PII. Returns (violations, masked_text)."""
        violations = []
        masked = text
        mode = self._profile.get("pii_mode", "mask")

        for pii_type, (pattern, tier) in _PII_PATTERNS.items():
            if re.search(pattern, text, re.IGNORECASE):
                violations.append(Violation(
                    law=LawCode.NHH,
                    category=f"PII_{pii_type}",
                    description=f"PII detected: {pii_type}",
                    tier=tier,
                ))
                if mode in ("mask", "block"):
                    masked = re.sub(pattern, _PII_MASK[pii_type], masked, flags=re.IGNORECASE)

        return violations, masked

    def _decide(
        self,
        law_violations: List[Violation],
        pii_violations: List[Violation],
    ) -> tuple[str, str]:
        """Return (gyr, action) based on violations."""
        all_v = law_violations + pii_violations

        # Any T2 violation → RED
        if any(v.tier == "T2" for v in law_violations):
            return GYR.RED, "HARD_BLOCK"

        # PII detected → YELLOW (mask and pass)
        if pii_violations:
            return GYR.YELLOW, "FLAG_AND_PASS"

        # T1 law violation → YELLOW
        if law_violations:
            return GYR.YELLOW, "FLAG_AND_PASS"

        return GYR.GREEN, "ALLOW"

    def _write_receipt(
        self,
        direction: str,
        gyr: str,
        action: str,
        violations: List[Violation],
        tier: str,
    ) -> Optional[dict]:
        if not self._write_receipts or not self._receipt_chain:
            return None
        return self._receipt_chain.write(
            direction=direction,
            platform=self._platform,
            gyr=gyr,
            action=action,
            violations=violations,
            tier=tier,
            profile=self._profile.name,
        )

    def check_input(self, text: str) -> GovernanceResult:
        """
        Govern a user's input prompt before it reaches the AI.

        Returns GovernanceResult. If result.blocked is True,
        do not send the prompt to the AI.
        """
        law_violations = SixLaws.check_input(text)
        pii_violations, masked_text = self._check_pii(text)
        gyr, action = self._decide(law_violations, pii_violations)

        all_violations = law_violations + pii_violations
        tier = "T2" if any(v.tier == "T2" for v in all_violations) else ("T1" if all_violations else "T0")

        receipt = self._write_receipt("INPUT", gyr, action, all_violations, tier)

        return GovernanceResult(
            gyr=gyr,
            action=action,
            violations=all_violations,
            masked_text=masked_text if pii_violations else None,
            receipt=receipt,
            profile=self._profile.name,
            direction="INPUT",
            platform=self._platform,
        )

    def check_output(self, text: str) -> GovernanceResult:
        """
        Govern an AI's response before it reaches the user.

        Returns GovernanceResult. If result.blocked is True,
        replace the AI response with your own block notice.
        """
        law_violations = SixLaws.check_output(text)
        pii_violations, masked_text = self._check_pii(text)
        gyr, action = self._decide(law_violations, pii_violations)

        all_violations = law_violations + pii_violations
        tier = "T2" if any(v.tier == "T2" for v in all_violations) else ("T1" if all_violations else "T0")

        receipt = self._write_receipt("OUTPUT", gyr, action, all_violations, tier)

        return GovernanceResult(
            gyr=gyr,
            action=action,
            violations=all_violations,
            masked_text=masked_text if pii_violations else None,
            receipt=receipt,
            profile=self._profile.name,
            direction="OUTPUT",
            platform=self._platform,
        )

    def check(self, text: str) -> GovernanceResult:
        """Alias for check_input."""
        return self.check_input(text)

    def verify_chain(self) -> dict:
        """Verify integrity of the receipt chain."""
        if not self._receipt_chain:
            return {"valid": True, "total": 0, "note": "Receipt writing disabled"}
        return self._receipt_chain.verify()


# ── MODULE-LEVEL CONVENIENCE API ─────────────────────────────────────────────

_default_engine: Optional[GovernanceEngine] = None


def _get_engine() -> GovernanceEngine:
    global _default_engine
    if _default_engine is None:
        _default_engine = GovernanceEngine()
    return _default_engine


def check_input(text: str, profile: Optional[str] = None, platform: str = "unknown") -> GovernanceResult:
    """
    Check a prompt against HUXmesh governance.

    Args:
        text:     The user's prompt to check
        profile:  Optional profile override ("DEFAULT", "COMPANION", etc.)
        platform: Optional platform name for audit trail

    Returns:
        GovernanceResult with .gyr, .action, .violations, .receipt

    Example:
        result = huxmesh.check_input("how do I track someone's location")
        if result.blocked:
            print("Blocked:", result.violations[0].description)
    """
    if profile:
        return GovernanceEngine(profile=profile, platform=platform).check_input(text)
    return _get_engine().check_input(text)


def check_output(text: str, profile: Optional[str] = None, platform: str = "unknown") -> GovernanceResult:
    """
    Check an AI response against HUXmesh governance.

    Args:
        text:     The AI's response to check
        profile:  Optional profile override
        platform: Optional platform name for audit trail

    Returns:
        GovernanceResult with .gyr, .action, .violations, .receipt
    """
    if profile:
        return GovernanceEngine(profile=profile, platform=platform).check_output(text)
    return _get_engine().check_output(text)


def check(text: str, **kwargs) -> GovernanceResult:
    """Alias for check_input."""
    return check_input(text, **kwargs)
