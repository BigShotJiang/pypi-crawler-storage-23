"""
Profile system — governance configuration per deployment context.
DEFAULT is always available. All others require addon activation.
"""

from __future__ import annotations
import json
from pathlib import Path
from typing import Optional

_PROFILE_PATH = Path.home() / ".huxmesh" / "profile.json"

PROFILES = {
    "DEFAULT": {
        "display_name": "HUXmesh Personal",
        "description": "General consumer governance — balanced protection",
        "grace_interactions": 20,
        "dependency_threshold": 3,
        "pii_mode": "mask",
        "medical_governor": False,
        "loneliness_detector": False,
        "block_page_style": "standard",
        "requires_addon": False,
    },
    "COMPANION": {
        "display_name": "HUXcompanion",
        "description": "Governance for elderly, at-risk, and isolated users",
        "grace_interactions": 50,
        "dependency_threshold": 2,
        "pii_mode": "block",
        "medical_governor": True,
        "loneliness_detector": True,
        "block_page_style": "warm",
        "requires_addon": True,
        "elder_fraud_priority": True,
    },
    "FERPA": {
        "display_name": "HUXedu",
        "description": "Academic integrity governance — FERPA aligned",
        "grace_interactions": 10,
        "dependency_threshold": 5,
        "pii_mode": "block",
        "medical_governor": False,
        "loneliness_detector": False,
        "block_page_style": "academic",
        "requires_addon": True,
        "academic_integrity_strict": True,
    },
    "VETERAN": {
        "display_name": "HUXveteran",
        "description": "Veteran-aware governance — PTSD sensitive, VA resources",
        "grace_interactions": 30,
        "dependency_threshold": 2,
        "pii_mode": "mask",
        "medical_governor": True,
        "loneliness_detector": True,
        "block_page_style": "veteran",
        "requires_addon": True,
        "veteran_crisis_resources": True,
    },
    "PARISH": {
        "display_name": "HUXparish",
        "description": "Faith community governance",
        "grace_interactions": 25,
        "dependency_threshold": 3,
        "pii_mode": "mask",
        "medical_governor": False,
        "loneliness_detector": True,
        "block_page_style": "warm",
        "requires_addon": True,
    },
    "FAMILY": {
        "display_name": "HUXfamily",
        "description": "Family governance — 6F aligned, multi-user household",
        "grace_interactions": 20,
        "dependency_threshold": 2,
        "pii_mode": "block",
        "medical_governor": False,
        "loneliness_detector": True,
        "block_page_style": "warm",
        "requires_addon": True,
        "child_protection_strict": True,
    },
}


class ProfileConfig:
    """Active profile configuration."""

    def __init__(self, profile_name: str = "DEFAULT"):
        self.name = profile_name.upper()
        if self.name not in PROFILES:
            self.name = "DEFAULT"
        self._config = PROFILES[self.name]

    @property
    def display_name(self) -> str:
        return self._config["display_name"]

    @property
    def grace_interactions(self) -> int:
        return self._config["grace_interactions"]

    @property
    def requires_medical_governor(self) -> bool:
        return self._config.get("medical_governor", False)

    @property
    def requires_loneliness_detector(self) -> bool:
        return self._config.get("loneliness_detector", False)

    @property
    def requires_addon(self) -> bool:
        return self._config.get("requires_addon", False)

    @property
    def block_page_style(self) -> str:
        return self._config.get("block_page_style", "standard")

    def get(self, key: str, default=None):
        return self._config.get(key, default)

    def to_dict(self) -> dict:
        return {"name": self.name, **self._config}


class ProfileManager:
    """Load and save the active profile."""

    PROFILE_PATH = _PROFILE_PATH

    @classmethod
    def load(cls) -> ProfileConfig:
        """Load profile from disk. Defaults to DEFAULT."""
        if cls.PROFILE_PATH.exists():
            try:
                data = json.loads(cls.PROFILE_PATH.read_text(encoding="utf-8"))
                return ProfileConfig(data.get("profile", "DEFAULT"))
            except Exception:
                pass
        return ProfileConfig("DEFAULT")

    @classmethod
    def save(cls, profile_name: str) -> bool:
        """Save profile selection to disk."""
        try:
            cls.PROFILE_PATH.parent.mkdir(parents=True, exist_ok=True)
            cls.PROFILE_PATH.write_text(
                json.dumps({"profile": profile_name.upper()}),
                encoding="utf-8"
            )
            return True
        except Exception:
            return False

    @classmethod
    def available(cls) -> list:
        return list(PROFILES.keys())
