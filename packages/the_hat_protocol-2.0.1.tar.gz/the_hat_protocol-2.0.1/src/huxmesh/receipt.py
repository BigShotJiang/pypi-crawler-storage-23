"""
ReceiptChain — SHA-256 hash-chained tamper-evident audit trail.
Every governed interaction produces a receipt.
Receipts are chained — altering any receipt breaks all subsequent hashes.
"""

from __future__ import annotations
import hashlib
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional


_DEFAULT_RECEIPT_PATH = Path.home() / ".huxmesh" / "receipts.jsonl"

# Regulatory framework tags applied per violation category
REGULATORY_TAGS = {
    "CSAM":               ["COPPA", "CSAM_PROTOCOL"],
    "SELF_HARM_EXPLICIT": ["CRISIS_PROTOCOL"],
    "SELF_HARM_INDIRECT": ["CRISIS_PROTOCOL"],
    "GROOMING":           ["COPPA", "CRISIS_PROTOCOL"],
    "PII_SSN":            ["GDPR", "CCPA", "HIPAA_ADJACENT"],
    "PII_CREDIT_CARD":    ["PCI_DSS", "GDPR", "CCPA"],
    "PII_MEDICAL":        ["HIPAA_ADJACENT", "GDPR"],
    "ACADEMIC_INTEGRITY": ["FERPA"],
    "WEAPON_CONSTRUCTION":["SOX"],
    "FABRICATION":        ["SOX", "GDPR"],
}


class ReceiptChain:
    """
    Append-only hash-chained audit ledger.

    Usage:
        chain = ReceiptChain()
        receipt = chain.write(
            direction="INPUT",
            platform="ChatGPT",
            gyr="RED",
            action="HARD_BLOCK",
            violations=[v.to_dict() for v in violations],
        )
    """

    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else _DEFAULT_RECEIPT_PATH
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._last_hash = self._load_last_hash()

    def _load_last_hash(self) -> str:
        """Load the hash of the most recent receipt, or genesis hash."""
        genesis = "sha256:" + hashlib.sha256(b"HUXmesh Genesis Block - Human In Power. No Matter What.").hexdigest()
        if not self.path.exists():
            return genesis
        try:
            lines = self.path.read_text(encoding="utf-8").strip().splitlines()
            if lines:
                last = json.loads(lines[-1])
                return last.get("hash", genesis)
        except Exception:
            pass
        return genesis

    @staticmethod
    def _hash_receipt(receipt: dict) -> str:
        """SHA-256 hash of canonical JSON representation."""
        canonical = json.dumps(receipt, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    @staticmethod
    def _regulatory_tags(violations: list) -> List[str]:
        """Map violation categories to regulatory framework tags."""
        tags = set()
        for v in violations:
            cat = v.get("category", "") if isinstance(v, dict) else getattr(v, "category", "")
            for key, tag_list in REGULATORY_TAGS.items():
                if key in cat:
                    tags.update(tag_list)
        return sorted(tags)

    def write(
        self,
        direction: str = "INPUT",
        platform: str = "unknown",
        gyr: str = "GREEN",
        action: str = "ALLOW",
        violations: Optional[list] = None,
        tier: str = "T0",
        profile: str = "DEFAULT",
        metadata: Optional[dict] = None,
    ) -> dict:
        """Write a governance receipt to the chain. Returns the receipt dict."""
        violations = violations or []
        request_id = f"thp-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{uuid.uuid4().hex[:8]}"

        receipt = {
            "request_id":      request_id,
            "timestamp":       datetime.now(timezone.utc).isoformat(),
            "direction":       direction,
            "platform":        platform,
            "profile":         profile,
            "gyr":             gyr,
            "action":          action,
            "tier":            tier,
            "violations":      [v if isinstance(v, dict) else v.to_dict() for v in violations],
            "regulatory_tags": self._regulatory_tags(violations),
            "prev_hash":       self._last_hash,
        }

        if metadata:
            receipt["metadata"] = metadata

        receipt["hash"] = self._hash_receipt(receipt)
        self._last_hash = receipt["hash"]

        try:
            with self.path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(receipt) + "\n")
        except Exception:
            pass  # Never crash governance over a write failure

        return receipt

    def verify(self) -> dict:
        """
        Verify the integrity of the entire receipt chain.
        Returns {"valid": bool, "total": int, "broken_at": Optional[int]}
        """
        if not self.path.exists():
            return {"valid": True, "total": 0, "broken_at": None}

        lines = self.path.read_text(encoding="utf-8").strip().splitlines()
        if not lines:
            return {"valid": True, "total": 0, "broken_at": None}

        for i, line in enumerate(lines):
            try:
                receipt = json.loads(line)
                stored_hash = receipt.pop("hash", "")
                computed = self._hash_receipt(receipt)
                if stored_hash != computed:
                    return {"valid": False, "total": len(lines), "broken_at": i + 1}
                receipt["hash"] = stored_hash  # restore
            except Exception:
                return {"valid": False, "total": len(lines), "broken_at": i + 1}

        return {"valid": True, "total": len(lines), "broken_at": None}

    def export(self, limit: int = 100) -> List[dict]:
        """Return the most recent receipts."""
        if not self.path.exists():
            return []
        try:
            lines = self.path.read_text(encoding="utf-8").strip().splitlines()
            return [json.loads(l) for l in lines[-limit:]]
        except Exception:
            return []
