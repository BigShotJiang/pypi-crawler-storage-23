import asyncio
import base64
from contextlib import asynccontextmanager
from io import BytesIO

import numpy as np
from lxml import etree as ET
from lxml.etree import _Element
from PIL import Image

from pantoqa_bridge.server_synced_models.misc import Coord, distance_from_point, sort_by_distance
from pantoqa_bridge.server_synced_models.node_element import NodeElement, NodeElements
from pantoqa_bridge.utils.service_manager import get_adb_service


@asynccontextmanager
async def verify_change(
  device_serial_no: str | None,
  x: int,
  y: int,
  check_delay: float = 0.5,
  check_lens_size: int = 100,
  similarity_percentage: float = 100.0,
):
  srv_manager = get_adb_service(device_serial_no)

  # Capture screenshot before action
  ss_before_action_b64 = srv_manager.srv.take_screenshot()
  ss_before_action_img = Image.open(BytesIO(base64.b64decode(ss_before_action_b64)))

  async def is_changed() -> tuple[bool, str, str]:
    await asyncio.sleep(check_delay)
    ss_after_action_b64 = srv_manager.srv.take_screenshot()
    ss_after_action_img = Image.open(BytesIO(base64.b64decode(ss_after_action_b64)))
    ss_before_cropped = crop_rectangle_full_width(ss_before_action_img, y, size=check_lens_size)
    ss_after_cropped = crop_rectangle_full_width(ss_after_action_img, y, size=check_lens_size)

    return not is_similar_image(
      ss_before_cropped,
      ss_after_cropped,
      similarity_percentage=similarity_percentage,
    ), ss_before_action_b64, ss_after_action_b64

  yield is_changed


def find_element_by_coordinates(xml_content: str | ET._Element,
                                x: int,
                                y: int,
                                parent_dist_threshold: int = 100) -> NodeElement | None:
  if not xml_content:
    return None

  xml_root = ET.fromstring(xml_content.encode('utf-8')) if isinstance(xml_content,
                                                                      str) else xml_content

  candidates: NodeElements = []

  for node in xml_root.iter():
    if not isinstance(node, _Element):
      continue
    elem = NodeElement.from_xml_node(node)
    if not elem.bounds:
      continue
    x1, y1, x2, y2 = elem.parsed_bounds
    if x1 <= x <= x2 and y1 <= y <= y2:
      candidates.append(elem)

  if not candidates:
    return None

  sorted_candidates = sort_by_distance(candidates, Coord(x=x, y=y))
  if len(sorted_candidates) == 1:
    return sorted_candidates[0]

  filtered_candidates = [
    elem for elem in sorted_candidates
    if distance_from_point(elem.coord, Coord(x=x, y=y)) <= parent_dist_threshold and (
      elem.text or elem.content_desc or elem.resource_id)
  ]

  if not filtered_candidates and sorted_candidates:
    return sorted_candidates[0]

  return filtered_candidates[0]


def is_similar_image(
  image1: Image.Image,
  image2: Image.Image,
  similarity_percentage: float,
) -> bool:

  def hist(img: Image.Image):
    arr = np.array(img.convert("RGB"))
    hists = []
    for i in range(3):
      h, _ = np.histogram(
        arr[:, :, i],
        bins=32,
        range=(0, 256),  # fixed range
      )
      hists.append(h)
    hist = np.concatenate(hists).astype(float)
    # normalize → probability distribution
    hist /= hist.sum()
    return hist

  hist1 = hist(image1)
  hist2 = hist(image2)
  hdist = np.linalg.norm(hist1 - hist2)

  # matched = hdist <= threshold
  similarity = (1 - hdist / np.sqrt(2)) * 100
  return similarity >= similarity_percentage


def crop_around(
  img: Image.Image,
  x: int,
  y: int,
  size: int = 100,
) -> Image.Image:
  left = max(x - size // 2, 0)
  upper = max(y - size // 2, 0)
  right = min(x + size // 2, img.width)
  lower = min(y + size // 2, img.height)
  cropped = img.crop((left, upper, right, lower))
  return cropped


def crop_rectangle_full_width(
  img: Image.Image,
  p: int,
  size: int = 100,
) -> Image.Image:
  left = 0
  upper = max(p - size // 2, 0)
  right = img.width
  lower = min(p + size // 2, img.height)
  cropped = img.crop((left, upper, right, lower))
  return cropped
