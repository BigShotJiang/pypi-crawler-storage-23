# Decisions Template

Use one ADR-lite entry per durable decision.

## Entry Format

- Date: YYYY-MM-DD
- Decision: Short statement
- Rationale: Why this choice was made
- Alternatives: Options considered and why they were not selected

## Entries
