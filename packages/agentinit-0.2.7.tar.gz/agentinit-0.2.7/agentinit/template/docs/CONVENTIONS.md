# Conventions

## Style

- **Formatting standard:** TBD
- **Documentation tone/language:** English
- **Commenting expectations:** TBD

## Naming

- **Files/directories:** TBD
- **Variables/functions/types:** TBD
- **Branch naming:** TBD

## Testing

- **Required test types:** TBD
- **Minimum coverage/gates:** TBD
- **Test data/fixtures:** TBD

## Git Workflow

- **Commit message format:** TBD
- **PR requirements/reviews:** TBD
- **Merge strategy:** TBD
