# Autourgos LLM Agent Kit

**Autourgos LLM Agent Kit** is a powerful, lightweight framework for building advanced AI agents. It supports both **ReAct (Reasoning + Acting)** and **Tool Calling** paradigms, allowing developers to create intelligent agents that can reason through complex problems and execute tools effectively.

## Features

-   **ReAct Agent:** Implements the reasoning-trace loop (Thought → Action → Observation) for complex problem-solving.
-   **Tool Calling Agent:** Optimized for sequential tool execution without explicit reasoning overhead.
-   **Autourgos Core:** A robust tool management system with the `@tool` decorator for easy function-to-tool conversion.
-   **Memory Integration:** Optional conversation memory support.
-   **Customizable Prompts:** Easily modify agent behavior with custom prompt templates.
-   **Verbose Logging:** Detailed colored terminal output for debugging and monitoring agent thought processes.

## Installation

Install via pip:

```bash
pip install autourgos-llmagentkit
```

## Quick Start

### 1. Define Tools

Use the `@tool` decorator from `autourgos.core` to turn Python functions into tools.

```python
from autourgos.core import tool

@tool
def calculate(expression: str) -> str:
    """Evaluates a mathematical expression."""
    return str(eval(expression))

@tool
def search(query: str) -> str:
    """Searches for information about the query."""
    return f"Results for: {query}"
```

### 2. Create a ReAct Agent

The ReAct agent reasons about the user's request and decides which tools to call.

```python
from autourgos.llmagentkit import Create_ReAct_Agent

# Initialize your LLM client (must implement generate_response method)
# llm = MyLLMClient(...)

agent = Create_ReAct_Agent(llm=llm, verbose=True)
agent.add_tools(calculate, search)

response = agent.invoke("What is the calculation for 25 * 4 and search for its significance?")
print(response)
```

### 3. Create a Tool Calling Agent

For more direct tasks where explicit reasoning steps are less critical.

```python
from autourgos.llmagentkit import Create_ToolCalling_Agent

agent = Create_ToolCalling_Agent(llm=llm, verbose=True)
agent.add_tools(calculate)

response = agent.invoke("Calculate 100 / 5")
print(response)
```

## Project Structure

-   `autourgos.llmagentkit`: Core agent implementations (ReAct, Tool Calling).
-   `autourgos.core`: Tool management and decorators.

## License

This project is licensed under a proprietary license. See the `LICENSE` file for details.
Not for resale or commercial use without permission.
