"""Autodesk Platform Services: shared HTTP client utilities for Kiota-based SDKs."""

from autodesk_common_httpclient.access_token_provider import AccessTokenProviderCallback
from autodesk_common_httpclient.http_client_factory import HttpClientFactory
from autodesk_common_httpclient.middleware import (
    ErrorContext,
    ErrorHandler,
    QueryParameterHandler,
    RateLimitingHandler,
)
from autodesk_common_httpclient.middleware.options import (
    ErrorHandlerOption,
    QueryParameterHandlerOption,
    RateLimitingHandlerOption,
)

__all__ = [
    "AccessTokenProviderCallback",
    "ErrorContext",
    "ErrorHandler",
    "ErrorHandlerOption",
    "HttpClientFactory",
    "QueryParameterHandler",
    "QueryParameterHandlerOption",
    "RateLimitingHandler",
    "RateLimitingHandlerOption",
]
__version__ = "0.1.0"
