"""Middleware that raises on non-success HTTP responses.

Python equivalent of the C# ``Autodesk.Common.HttpClientLibrary.Middleware.ErrorHandler``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import httpx
from kiota_http.middleware.middleware import BaseMiddleware

from autodesk_common_httpclient.middleware.options.error_handler_option import ErrorHandlerOption


@dataclass
class ErrorContext:
    """Contains context information about a failed HTTP request."""

    request_url: Optional[str] = None
    request_method: Optional[str] = None
    request_headers: dict[str, str] = field(default_factory=dict)
    request_content: Optional[bytes] = None
    response_headers: dict[str, str] = field(default_factory=dict)
    response_content: Optional[bytes] = None


class ErrorHandler(BaseMiddleware):
    """Raises an :class:`httpx.HTTPStatusError` when the response status is not successful.

    The error includes an :class:`ErrorContext` attached via the ``context`` attribute
    on the exception, containing the full request/response details for debugging.
    This mirrors the C# ``ErrorHandler`` which throws ``HttpRequestException``
    with the response attached in ``Data["context"]``.

    Args:
        options: Configuration controlling whether the handler is active.
    """

    def __init__(self, options: ErrorHandlerOption | None = None) -> None:
        super().__init__()
        self.options = options or ErrorHandlerOption(enabled=True)

    async def send(
        self, request: httpx.Request, transport: httpx.AsyncBaseTransport
    ) -> httpx.Response:
        """Send the request, raising on non-2xx responses if enabled."""
        # Buffer the request content before sending so it's available in the
        # error context even after the request completes
        request_content = request.content if request.content else None

        response = await super().send(request, transport)

        current_options = self._get_current_options(request)

        if current_options.enabled and response.status_code >= 400:
            # Read/buffer the response body so it remains readable after the
            # exception propagates
            response_body = response.text
            response_content = response.content

            error_context = ErrorContext(
                request_url=str(request.url),
                request_method=request.method,
                request_headers=dict(request.headers),
                request_content=request_content,
                response_headers=dict(response.headers),
                response_content=response_content,
            )

            error = httpx.HTTPStatusError(
                message=(
                    f"Request to '{request.url}' failed with status code "
                    f"'{response.status_code}'. Response body: {response_body}"
                ),
                request=request,
                response=response,
            )
            error.context = error_context  # type: ignore[attr-defined]
            raise error

        return response

    def _get_current_options(self, request: httpx.Request) -> ErrorHandlerOption:
        """Return per-request options if set, otherwise fall back to defaults."""
        request_options = getattr(request, "options", None)
        if request_options:
            return request_options.get(ErrorHandlerOption.get_key(), self.options)
        return self.options
