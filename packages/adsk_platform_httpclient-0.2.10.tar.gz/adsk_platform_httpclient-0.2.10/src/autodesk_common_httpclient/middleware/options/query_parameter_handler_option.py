"""Option class for the QueryParameterHandler middleware."""
from kiota_abstractions.request_option import RequestOption


class QueryParameterHandlerOption(RequestOption):
    """Configuration for the :class:`~autodesk_common_httpclient.middleware.QueryParameterHandler`.

    Attributes:
        query_parameters: A dict of query parameter key-value pairs to append
            or overwrite on every outgoing request.
    """

    QUERY_PARAMETER_HANDLER_OPTION_KEY = "QueryParameterHandlerOption"

    def __init__(self, query_parameters: dict[str, str] | None = None) -> None:
        self.query_parameters: dict[str, str] = query_parameters or {}

    @staticmethod
    def get_key() -> str:
        return QueryParameterHandlerOption.QUERY_PARAMETER_HANDLER_OPTION_KEY
