"""Option class for the RateLimitingHandler middleware."""
from __future__ import annotations

from kiota_abstractions.request_option import RequestOption


class RateLimitingHandlerOption(RequestOption):
    """Configuration for the :class:`~autodesk_common_httpclient.middleware.RateLimitingHandler`.

    Disabled by default. Call :meth:`set_rate_limit` to enable.
    """

    RATE_LIMITING_HANDLER_OPTION_KEY = "RateLimitingHandlerOption"

    def __init__(self) -> None:
        self._max_requests: int = 0
        self._time_window_seconds: float = 0.0

    def set_rate_limit(self, max_requests: int, time_window_seconds: float) -> None:
        """Enable rate limiting.

        Args:
            max_requests: Maximum number of requests allowed within the time window.
                Must be greater than zero.
            time_window_seconds: Duration of the sliding window in seconds.
                Must be greater than zero.

        Raises:
            ValueError: If either argument is not positive.
        """
        if max_requests <= 0:
            raise ValueError("max_requests must be greater than zero.")
        if time_window_seconds <= 0:
            raise ValueError("time_window_seconds must be greater than zero.")
        self._max_requests = max_requests
        self._time_window_seconds = time_window_seconds

    def get_rate_limit(self) -> tuple[int, float] | None:
        """Return the current rate limit, or ``None`` if disabled.

        Returns:
            A ``(max_requests, time_window_seconds)`` tuple, or ``None``.
        """
        if self._max_requests == 0 or self._time_window_seconds == 0.0:
            return None
        return (self._max_requests, self._time_window_seconds)

    def disable(self) -> None:
        """Disable rate limiting."""
        self._max_requests = 0
        self._time_window_seconds = 0.0

    @staticmethod
    def get_key() -> str:
        return RateLimitingHandlerOption.RATE_LIMITING_HANDLER_OPTION_KEY
