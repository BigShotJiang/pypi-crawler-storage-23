"""Option class for the ErrorHandler middleware."""
from kiota_abstractions.request_option import RequestOption


class ErrorHandlerOption(RequestOption):
    """Configuration for the :class:`~autodesk_common_httpclient.middleware.ErrorHandler`.

    Attributes:
        enabled: If ``True``, the handler raises on non-success HTTP responses.
    """

    ERROR_HANDLER_OPTION_KEY = "ErrorHandlerOption"

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled

    @staticmethod
    def get_key() -> str:
        return ErrorHandlerOption.ERROR_HANDLER_OPTION_KEY
