"""Middleware that appends or overwrites query parameters on outgoing requests.

Python equivalent of the C# ``Autodesk.Common.HttpClientLibrary.Middleware.QueryParameterHandler``.
"""
from __future__ import annotations

from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

import httpx
from kiota_http.middleware.middleware import BaseMiddleware

from autodesk_common_httpclient.middleware.options.query_parameter_handler_option import (
    QueryParameterHandlerOption,
)


class QueryParameterHandler(BaseMiddleware):
    """Injects additional query parameters into every outgoing request URL.

    Useful for injecting common parameters like API versions, region codes,
    or tracking identifiers across all API calls.

    Args:
        options: Configuration containing the query parameters to inject.
    """

    def __init__(self, options: QueryParameterHandlerOption | None = None) -> None:
        super().__init__()
        self.options = options or QueryParameterHandlerOption()

    async def send(
        self, request: httpx.Request, transport: httpx.AsyncBaseTransport
    ) -> httpx.Response:
        """Merge configured query parameters into the request URL, then forward."""
        current_options = self._get_current_options(request)

        if current_options.query_parameters:
            parsed = urlparse(str(request.url))
            # Parse existing query string (keep values as flat strings)
            existing_params = parse_qs(parsed.query, keep_blank_values=True)
            # Overwrite / add new parameters
            for key, value in current_options.query_parameters.items():
                existing_params[key] = [value]
            new_query = urlencode(existing_params, doseq=True)
            new_url = urlunparse(parsed._replace(query=new_query))
            request = httpx.Request(
                method=request.method,
                url=new_url,
                headers=request.headers,
                content=request.content,
                extensions=request.extensions,
            )
            # Preserve options attribute if present
            if hasattr(request, "options"):
                pass  # httpx.Request is immutable; options are already on the original

        return await super().send(request, transport)

    def _get_current_options(self, request: httpx.Request) -> QueryParameterHandlerOption:
        """Return per-request options if set, otherwise fall back to defaults."""
        request_options = getattr(request, "options", None)
        if request_options:
            return request_options.get(QueryParameterHandlerOption.get_key(), self.options)
        return self.options
