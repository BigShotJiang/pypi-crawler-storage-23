"""Middleware that limits concurrent requests per endpoint using a sliding window.

Python equivalent of the C# ``Autodesk.Common.HttpClientLibrary.Middleware.RateLimitingHandler``.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone

import httpx
from kiota_http.middleware.middleware import BaseMiddleware

from autodesk_common_httpclient.middleware.options.rate_limiting_handler_option import (
    RateLimitingHandlerOption,
)


class _RateLimiter:
    """Per-endpoint sliding-window rate limiter (async-safe)."""

    def __init__(self, max_requests: int, time_window_seconds: float) -> None:
        self._max_requests = max_requests
        self._time_window_seconds = time_window_seconds
        self._request_count = 0
        self._reset_time = datetime.now(timezone.utc).timestamp() + time_window_seconds
        self._lock = asyncio.Lock()

    async def wait_for_availability(self) -> None:
        """Block until a request slot becomes available in the current window."""
        async with self._lock:
            now = datetime.now(timezone.utc).timestamp()

            if now >= self._reset_time:
                self._request_count = 0
                self._reset_time = now + self._time_window_seconds

            if self._request_count >= self._max_requests:
                delay = self._reset_time - now
                if delay > 0:
                    await asyncio.sleep(delay)
                self._request_count = 0
                self._reset_time = datetime.now(timezone.utc).timestamp() + self._time_window_seconds

            self._request_count += 1


class RateLimitingHandler(BaseMiddleware):
    """Limits the number of concurrent requests per endpoint within a time window.

    Endpoints are identified by ``METHOD|path`` (query string excluded) to avoid
    counting different query parameter combinations as separate endpoints.

    Args:
        options: Rate limiting configuration. Disabled by default.
    """

    def __init__(self, options: RateLimitingHandlerOption | None = None) -> None:
        super().__init__()
        self.options = options or RateLimitingHandlerOption()
        self._rate_limiters: dict[str, _RateLimiter] = {}

    async def send(
        self, request: httpx.Request, transport: httpx.AsyncBaseTransport
    ) -> httpx.Response:
        """Wait for an available rate-limit slot, then forward the request."""
        current_options = self._get_current_options(request)
        rate_limit = current_options.get_rate_limit()

        if rate_limit is not None:
            max_requests, time_window_seconds = rate_limit
            endpoint = self._get_endpoint(request)
            if endpoint not in self._rate_limiters:
                self._rate_limiters[endpoint] = _RateLimiter(max_requests, time_window_seconds)
            await self._rate_limiters[endpoint].wait_for_availability()

        return await super().send(request, transport)

    @staticmethod
    def _get_endpoint(request: httpx.Request) -> str:
        """Derive a stable endpoint key from the request (method + path, no query)."""
        url = request.url
        return f"{request.method}|{url.scheme}://{url.host}{url.path}"

    def _get_current_options(self, request: httpx.Request) -> RateLimitingHandlerOption:
        """Return per-request options if set, otherwise fall back to defaults."""
        request_options = getattr(request, "options", None)
        if request_options:
            return request_options.get(RateLimitingHandlerOption.get_key(), self.options)
        return self.options
