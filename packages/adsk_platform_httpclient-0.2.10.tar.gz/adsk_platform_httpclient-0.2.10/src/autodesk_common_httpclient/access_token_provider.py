"""Access token provider that wraps an async callback for Kiota authentication."""
from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from kiota_abstractions.authentication import (
    AccessTokenProvider,
    AllowedHostsValidator,
)


class AccessTokenProviderCallback(AccessTokenProvider):
    """Wraps an async callback into a Kiota-compatible :class:`AccessTokenProvider`.

    This is the Python equivalent of the C# ``AccessTokenProvider`` class that wraps
    a ``Func<Task<string>>`` delegate.

    Args:
        get_access_token: An async callable that returns a valid access token string.

    Example::

        async def my_token_provider() -> str:
            return "my-access-token"

        provider = AccessTokenProviderCallback(my_token_provider)
    """

    def __init__(self, get_access_token: Callable[[], Awaitable[str]]) -> None:
        self._get_access_token = get_access_token

    async def get_authorization_token(
        self, uri: str, additional_authentication_context: dict[str, Any] = {}
    ) -> str:
        """Return the access token by invoking the wrapped callback.

        Args:
            uri: The target URI (ignored — the same token is used for all hosts).
            additional_authentication_context: Additional context (ignored).

        Returns:
            The access token string.
        """
        return await self._get_access_token()

    def get_allowed_hosts_validator(self) -> AllowedHostsValidator:
        """Return an :class:`AllowedHostsValidator` that allows all hosts."""
        return AllowedHostsValidator([])
