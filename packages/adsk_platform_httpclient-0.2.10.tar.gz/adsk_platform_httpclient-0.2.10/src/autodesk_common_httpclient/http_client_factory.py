"""Factory for creating Kiota request adapters with Autodesk authentication and middleware.

This is the Python equivalent of the C# ``Autodesk.Common.HttpClientLibrary.HttpClientFactory``.
"""
from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Optional

import httpx
from kiota_abstractions.authentication import BaseBearerTokenAuthenticationProvider
from kiota_abstractions.request_option import RequestOption
from kiota_http.httpx_request_adapter import HttpxRequestAdapter
from kiota_http.kiota_client_factory import KiotaClientFactory
from kiota_http.middleware.middleware import BaseMiddleware

from autodesk_common_httpclient.access_token_provider import AccessTokenProviderCallback
from autodesk_common_httpclient.middleware.error_handler import ErrorHandler
from autodesk_common_httpclient.middleware.options.error_handler_option import ErrorHandlerOption
from autodesk_common_httpclient.middleware.options.query_parameter_handler_option import (
    QueryParameterHandlerOption,
)
from autodesk_common_httpclient.middleware.options.rate_limiting_handler_option import (
    RateLimitingHandlerOption,
)
from autodesk_common_httpclient.middleware.query_parameter_handler import QueryParameterHandler
from autodesk_common_httpclient.middleware.rate_limiting_handler import RateLimitingHandler


class HttpClientFactory:
    """Creates pre-configured HTTP clients and Kiota request adapters.

    This mirrors the C# ``HttpClientFactory`` from ``Autodesk.Common.HttpClientLibrary``,
    including the custom middleware pipeline:

    1. Kiota default handlers (redirect, retry, parameters name decoding, etc.)
    2. **RateLimitingHandler** — per-endpoint sliding-window rate limiter
    3. **QueryParameterHandler** — injects additional query parameters
    4. **ErrorHandler** — raises on non-success HTTP responses
    """

    @staticmethod
    def create(
        http_client: Optional[httpx.AsyncClient] = None,
        options: Optional[dict[str, RequestOption]] = None,
    ) -> httpx.AsyncClient:
        """Create an ``httpx.AsyncClient`` with Kiota default + Autodesk custom middleware.

        Args:
            http_client: An existing client to wrap. If ``None``, a new client
                is created.
            options: Optional dict of :class:`RequestOption` keyed by option key.
                Recognised keys: ``RateLimitingHandlerOption``,
                ``QueryParameterHandlerOption``, ``ErrorHandlerOption``.

        Returns:
            A configured :class:`httpx.AsyncClient` with the full middleware pipeline.
        """
        # Resolve options (fall back to defaults)
        rate_limit_option = RateLimitingHandlerOption()
        query_param_option = QueryParameterHandlerOption()
        error_option = ErrorHandlerOption()

        if options:
            opt = options.get(RateLimitingHandlerOption.get_key())
            if isinstance(opt, RateLimitingHandlerOption):
                rate_limit_option = opt

            opt = options.get(QueryParameterHandlerOption.get_key())
            if isinstance(opt, QueryParameterHandlerOption):
                query_param_option = opt

            opt = options.get(ErrorHandlerOption.get_key())
            if isinstance(opt, ErrorHandlerOption):
                error_option = opt

        # Build the middleware list: Kiota defaults + custom handlers
        middleware = KiotaClientFactory.get_default_middleware(options)
        middleware.extend([
            RateLimitingHandler(rate_limit_option),
            QueryParameterHandler(query_param_option),
            ErrorHandler(error_option),
        ])

        client = http_client or KiotaClientFactory.get_default_client()
        return KiotaClientFactory.create_with_custom_middleware(middleware, client)

    @staticmethod
    def create_with_rate_limit(
        max_requests: int,
        time_window_seconds: float,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> httpx.AsyncClient:
        """Create an ``httpx.AsyncClient`` with rate limiting enabled.

        Args:
            max_requests: Maximum requests per endpoint within the time window.
            time_window_seconds: Duration of the sliding window in seconds.
            http_client: Optional existing client to wrap.

        Returns:
            A configured :class:`httpx.AsyncClient`.
        """
        rate_option = RateLimitingHandlerOption()
        rate_option.set_rate_limit(max_requests, time_window_seconds)
        return HttpClientFactory.create(
            http_client,
            options={RateLimitingHandlerOption.get_key(): rate_option},
        )

    @staticmethod
    def create_adapter(
        get_access_token: Callable[[], Awaitable[str]],
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> HttpxRequestAdapter:
        """Create a :class:`HttpxRequestAdapter` with bearer-token auth and custom middleware.

        This is the Python equivalent of the C#
        ``HttpClientFactory.CreateAdapter(Func<Task<string>>, HttpClient?)``.

        Args:
            get_access_token: An async callable returning an access token string.
            http_client: Optional :class:`httpx.AsyncClient`. If ``None``, a new
                client with the full middleware pipeline is created.

        Returns:
            A ready-to-use :class:`HttpxRequestAdapter`.
        """
        auth = BaseBearerTokenAuthenticationProvider(
            AccessTokenProviderCallback(get_access_token)
        )
        client = HttpClientFactory.create(http_client)
        return HttpxRequestAdapter(auth, http_client=client)

    @staticmethod
    def get_default_middleware(
        options: Optional[dict[str, RequestOption]] = None,
    ) -> list[BaseMiddleware]:
        """Return the full middleware list (Kiota defaults + Autodesk custom).

        Args:
            options: Optional dict of request options.

        Returns:
            Ordered list of middleware handlers.
        """
        rate_limit_option = RateLimitingHandlerOption()
        query_param_option = QueryParameterHandlerOption()
        error_option = ErrorHandlerOption()

        if options:
            opt = options.get(RateLimitingHandlerOption.get_key())
            if isinstance(opt, RateLimitingHandlerOption):
                rate_limit_option = opt

            opt = options.get(QueryParameterHandlerOption.get_key())
            if isinstance(opt, QueryParameterHandlerOption):
                query_param_option = opt

            opt = options.get(ErrorHandlerOption.get_key())
            if isinstance(opt, ErrorHandlerOption):
                error_option = opt

        middleware = KiotaClientFactory.get_default_middleware(options)
        middleware.extend([
            RateLimitingHandler(rate_limit_option),
            QueryParameterHandler(query_param_option),
            ErrorHandler(error_option),
        ])
        return middleware
