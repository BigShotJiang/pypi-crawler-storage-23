from __future__ import annotations

from pinger.cli import cli

if __name__ == "__main__":
    cli()
