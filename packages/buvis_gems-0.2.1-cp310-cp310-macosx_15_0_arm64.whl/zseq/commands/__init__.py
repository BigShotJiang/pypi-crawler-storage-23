from __future__ import annotations

from .get_last.get_last import CommandGetLast as CommandGetLast
