from __future__ import annotations

from .shell import ShellAdapter

__all__ = ["ShellAdapter"]
