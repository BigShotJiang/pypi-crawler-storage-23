from __future__ import annotations

from fctracker.cli import cli

if __name__ == "__main__":
    cli()
