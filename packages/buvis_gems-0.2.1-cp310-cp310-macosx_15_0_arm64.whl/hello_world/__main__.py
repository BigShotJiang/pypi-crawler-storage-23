from __future__ import annotations

from hello_world.cli import cli

if __name__ == "__main__":
    cli()
