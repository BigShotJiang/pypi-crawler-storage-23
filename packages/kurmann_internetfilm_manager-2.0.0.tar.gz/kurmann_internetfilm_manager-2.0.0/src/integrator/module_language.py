from integrator.config import CONFIG, get_model_name
from integrator.claude_helper import _get_json_response

import anthropic

def detect_language_from_text(title, description, channel):
    """
    Analysiert Metadaten für ALLE Sprachen.
    Liefert direkt den ISO 639-2 (3-Letter) Code für FFmpeg.
    """
    api_key = CONFIG.get("claude_key")
    if not api_key: return "und", "Unknown"

    client = anthropic.Anthropic(api_key=api_key)
    model_name = get_model_name(light=True)

    # System message (static, will be cached)
    system_message = """Du bist ein Sprach-Experte für die Analyse von Video-Metadaten.

AUFGABE:
1. Bestimme die HAUPTSPRACHE (Primary Language) basierend auf Titel, Kanal und Beschreibung.
2. Gib den ISO 639-2 Code (3-Letter!) zurück (z.B. "eng", "deu", "fra", "ita", "pol", "rus", "spa").
   - Wenn unsicher oder gemischt: Nimm die Sprache des Titels.

FORMAT (JSON):
{{
    "iso_code_3": "eng", 
    "language_name": "English"
}}"""

    # User message (video-specific, dynamic)
    user_prompt = f"""Analysiere die Sprache dieses Videos:

Titel: "{title}"
Kanal: "{channel}"
Beschreibung: "{description[:1000]}"
"""
    
    data = _get_json_response(client, model_name, user_prompt, max_tokens=256, system=system_message)
    if data:
        # Fallback, falls Claude doch 2-Letter schickt ("en" -> "eng")
        iso = data.get("iso_code_3", "und").lower()
        if len(iso) == 2:
            # Kleines Mini-Fixing für die gängigsten, falls Claude stolpert
            mapping = {"en": "eng", "de": "deu", "fr": "fra", "it": "ita", "es": "spa", "ru": "rus", "pl": "pol"}
            iso = mapping.get(iso, iso)
        return iso, data.get("language_name", "Unknown")

    return "eng", "English" # Default