from integrator.config import CONFIG
from integrator.claude_helper import _get_json_response
from integrator.module_subtitles import parse_vtt_text

import anthropic
import os

def generate_chapters(vtt_path, language_name="Unknown"):
    # Check if chapters are enabled
    if not CONFIG.get("chapters_enabled", True):
        print("   ℹ️  Kapitel-Erstellung ist deaktiviert (Einstellungen).")
        return None
    
    # Identisch zu vorher, nur Prompt leicht angepasst für Global
    api_key = CONFIG.get("claude_key")
    if not api_key or not os.path.exists(vtt_path): return None
    transcript_with_times = parse_vtt_text(vtt_path, with_timestamps=True)
    if not transcript_with_times: return None

    print(f"   🤖 Generiere Kapitel ({language_name})...")
    client = anthropic.Anthropic(api_key=api_key)
    model_name = CONFIG.get("claude_model", "claude-sonnet-4-20250514")

    # System message (static, will be cached)
    system_message = f"""Du bist ein Experte für die Erstellung von Video-Kapiteln.

AUFGABE:
Erstelle eine Kapitel-Liste (Timestamps) für dieses Video basierend auf dem Transkript.

WICHTIGE REGELN:
1. Erstelle NUR 5 bis MAXIMAL 15 logische Kapitel.
2. Fasse lange Abschnitte zusammen. Kopiere NICHT das Transkript Zeile für Zeile!
3. Die Originalsprache des Videos ist: {language_name}
4. Erstelle die Kapiteltitel AUSSCHLIESSLICH in dieser Sprache: {language_name}

REGELN FÜR SCHREIBWEISE (TITEL):
- Englisch: "Title Case" (z.B. "The History of AI").
- Deutsch: Normale Rechtschreibung (Satzanfang & Nomen groß). KEIN "alles klein" und KEIN "Alles Groß".
  (Richtig: "Die Analyse der Serie", Falsch: "die analyse der serie", Falsch: "Die Analyse Der Serie")
- Andere Sprachen: Folge den üblichen Rechtschreibregeln der jeweiligen Sprache.

FORMAT (JSON):
[
  {{ "start": "00:00:00", "title": "Einleitung" }},
  {{ "start": "00:05:30", "title": "Thema X" }}
]"""

    # User message (transcript-specific, dynamic)
    user_prompt = f"""TRANSKRIPT (Ausschnitt):
{transcript_with_times[:40000]}
"""
    
    return _get_json_response(client, model_name, user_prompt, max_tokens=4096, system=system_message)