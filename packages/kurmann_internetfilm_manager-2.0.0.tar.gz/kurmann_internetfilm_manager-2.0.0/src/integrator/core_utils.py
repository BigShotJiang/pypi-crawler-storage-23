# FACADE PATTERN
# Diese Datei dient nur noch als Schnittstelle.

# RELATIVE IMPORTS
from .module_archive import build_master
from .config import CONFIG
from .utils import run_shell, save_state, get_state
from .phase_fetch import fetch_video
from .phase_curate import interactive_curation
from .phase_build import build_dist
from .phase_deploy import deploy