"""
Module for deleting videos from target and archive.

Allows searching for videos by title or ID and deleting them completely:
- M4V file from target directory (rclone)
- DMG archive from master directory (rclone)
- Entry from metadata CSV index
"""

import os
import csv
import subprocess
import traceback
from typing import List, Dict, Any, Optional, Tuple
from .config import CONFIG
from .module_search import check_csv_exists, search_videos
from .module_index import (
    extract_video_id_from_comment, 
    match_dmg_to_video, 
    list_all_dmg_archives_on_server,
    index_server_videos
)


def search_video_for_deletion(search_term: str) -> List[Dict[str, Any]]:
    """
    Search for videos by title or ID.
    
    Args:
        search_term: Title fragment or video ID (e.g., 'xYz123' or full 'youtube_xYz123')
    
    Returns:
        List of matching videos with metadata
    """
    csv_path = check_csv_exists()
    if not csv_path:
        raise FileNotFoundError("CSV-Datei nicht gefunden. Bitte führe zuerst eine Metadata-Indexierung durch.")
    
    # Search in both title and comment (which contains platform_id)
    results = search_videos(
        search_term,
        search_fields=['title', 'comment'],
        csv_path=csv_path,
        case_sensitive=False
    )
    
    return results


def delete_video_file(filepath: str) -> bool:
    """
    Delete a video file from rclone target.
    
    Args:
        filepath: Full rclone path to the video file
    
    Returns:
        True if successful, False otherwise
    """
    if not filepath:
        print("❌ Fehler: Kein Dateipfad angegeben.")
        return False
    
    print(f"   🗑️  Lösche Video-Datei: {filepath}")
    
    try:
        cmd = ["rclone", "deletefile", filepath]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        print("   ✅ Video-Datei gelöscht")
        return True
    
    except subprocess.CalledProcessError as e:
        print(f"   ❌ Fehler beim Löschen der Video-Datei: {e}")
        if e.stderr:
            print(f"   Fehlerdetails: {e.stderr}")
        return False
    except Exception as e:
        print(f"   ❌ Unerwarteter Fehler: {e}")
        return False


def delete_dmg_archive(video_id: Optional[str]) -> Tuple[bool, Optional[str]]:
    """
    Delete the DMG archive associated with a video.
    
    Args:
        video_id: Video ID in format "platform_id" (e.g., "youtube_abc123")
    
    Returns:
        Tuple of (success: bool, dmg_path: Optional[str])
        - success: True if deleted successfully or no DMG found
        - dmg_path: Path to the deleted DMG (if found and deleted)
    """
    if not video_id:
        print("   ℹ️  Keine Video-ID gefunden - überspringe DMG-Löschung")
        return True, None
    
    rclone_master_root = CONFIG.get("rclone_master_root")
    if not rclone_master_root:
        print("   ⚠️  rclone_master_root nicht konfiguriert - überspringe DMG-Löschung")
        return True, None
    
    # Find the DMG file
    print(f"   🔍 Suche nach DMG-Archiv für ID: {video_id}")
    
    try:
        dmg_files = list_all_dmg_archives_on_server()
        matched_dmg = match_dmg_to_video(video_id, dmg_files)
        
        if not matched_dmg:
            print(f"   ℹ️  Kein DMG-Archiv gefunden für ID: {video_id}")
            return True, None
        
        # Build full rclone path
        dmg_path = f"{rclone_master_root}/{matched_dmg}"
        
        print(f"   🗑️  Lösche DMG-Archiv: {dmg_path}")
        
        cmd = ["rclone", "deletefile", dmg_path]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        print("   ✅ DMG-Archiv gelöscht")
        return True, dmg_path
    
    except subprocess.CalledProcessError as e:
        print(f"   ❌ Fehler beim Löschen des DMG-Archivs: {e}")
        if e.stderr:
            print(f"   Fehlerdetails: {e.stderr}")
        return False, None
    except Exception as e:
        print(f"   ❌ Unerwarteter Fehler beim DMG-Löschen: {e}")
        if CONFIG.get('debug_mode', False):
            traceback.print_exc()
        return False, None


def remove_video_from_csv(filepath: str, csv_path: Optional[str] = None) -> bool:
    """
    Remove a video entry from the CSV index.
    
    Uses a temporary file for safe atomic replacement to avoid corruption.
    
    Args:
        filepath: Full rclone path to the video file
        csv_path: Optional path to CSV file. Uses default location if not provided.
    
    Returns:
        True if successful, False otherwise
    """
    if not csv_path:
        csv_path = check_csv_exists()
    
    if not csv_path or not os.path.exists(csv_path):
        print("   ⚠️  CSV-Datei nicht gefunden - überspringe CSV-Update")
        return True
    
    print(f"   📝 Entferne Eintrag aus CSV-Index...")
    
    try:
        # Read all rows except the one to delete
        rows_to_keep = []
        removed = False
        
        with open(csv_path, 'r', newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            fieldnames = reader.fieldnames
            
            for row in reader:
                if row.get('filepath') != filepath:
                    rows_to_keep.append(row)
                else:
                    removed = True
        
        if not removed:
            print("   ℹ️  Video nicht in CSV gefunden")
            return True
        
        # Write to temporary file first for atomic replacement
        temp_path = csv_path + '.tmp'
        try:
            with open(temp_path, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(rows_to_keep)
            
            # Atomic replacement
            os.replace(temp_path, csv_path)
        finally:
            # Cleanup temp file if it still exists
            if os.path.exists(temp_path):
                try:
                    os.unlink(temp_path)
                except:
                    pass
        
        print("   ✅ CSV-Index aktualisiert")
        return True
    
    except Exception as e:
        print(f"   ❌ Fehler beim Aktualisieren der CSV: {e}")
        if CONFIG.get('debug_mode', False):
            traceback.print_exc()
        return False


def delete_video_complete(video_metadata: Dict[str, Any]) -> bool:
    """
    Delete a video completely: M4V file, DMG archive, and CSV entry.
    
    Args:
        video_metadata: Video metadata dictionary with filepath and comment fields
    
    Returns:
        True if all deletions successful, False if any failed
    """
    filepath = video_metadata.get('filepath', '')
    if not filepath:
        print("❌ Fehler: Kein Dateipfad gefunden.")
        return False
    
    # Extract video ID for DMG lookup
    comment = video_metadata.get('comment', '')
    video_id = extract_video_id_from_comment(comment)
    
    print("\n" + "=" * 80)
    print("🗑️  LÖSCHE VIDEO")
    print("=" * 80)
    print(f"Titel:     {video_metadata.get('title', 'Unbekannt')}")
    print(f"Pfad:      {filepath}")
    if video_id:
        print(f"Video-ID:  {video_id}")
    print("=" * 80)
    
    success = True
    
    # Step 1: Delete M4V file
    print("\n[1/3] Lösche M4V-Datei...")
    if not delete_video_file(filepath):
        success = False
        print("⚠️  Video-Datei konnte nicht gelöscht werden")
    
    # Step 2: Delete DMG archive (if exists)
    print("\n[2/3] Lösche DMG-Archiv...")
    dmg_success, dmg_path = delete_dmg_archive(video_id)
    if not dmg_success:
        success = False
        print("⚠️  DMG-Archiv konnte nicht gelöscht werden")
    
    # Step 3: Remove from CSV index
    print("\n[3/3] Aktualisiere CSV-Index...")
    if not remove_video_from_csv(filepath):
        success = False
        print("⚠️  CSV-Index konnte nicht aktualisiert werden")
    
    print("\n" + "=" * 80)
    if success:
        print("✅ Video vollständig gelöscht!")
    else:
        print("⚠️  Video teilweise gelöscht - einige Fehler aufgetreten")
    print("=" * 80)
    
    return success


def interactive_video_deletion() -> None:
    """
    Interactive menu for deleting videos.
    """
    print("\n" + "=" * 80)
    print("🗑️  VIDEO LÖSCHEN")
    print("=" * 80)
    print("\nSuche nach Titel oder ID, um ein Video zu löschen.")
    print("⚠️  WARNUNG: Das Löschen entfernt:")
    print("   • Die M4V-Datei vom Media-Server")
    print("   • Das DMG-Archiv (falls vorhanden)")
    print("   • Den Eintrag aus dem CSV-Index")
    print()
    
    # Check if CSV exists
    csv_path = check_csv_exists()
    if not csv_path:
        print("⚠️  CSV-Datei nicht gefunden.")
        print("Möchtest du jetzt eine Indexierung durchführen?")
        
        confirm = input("Indexierung starten? [Y/n]: ").strip().lower()
        
        if confirm in ['', 'y', 'j', 'ja', 'yes']:
            print("\n🔄 Starte Indexierung...")
            try:
                csv_path = index_server_videos()
                if not csv_path:
                    print("\n❌ Indexierung fehlgeschlagen.")
                    return
                print(f"\n✅ Indexierung erfolgreich: {csv_path}")
            except Exception as e:
                print(f"\n❌ Fehler bei Indexierung: {e}")
                return
        else:
            print("\n⚠️  Abgebrochen. Video-Löschung nicht möglich ohne CSV-Datei.")
            return
    
    # Main loop
    while True:
        print("\n" + "-" * 80)
        search_term = input("\nSuchbegriff (Titel oder ID) oder 'z' für Zurück: ").strip()
        
        if search_term.lower() == 'z':
            break
        
        if not search_term:
            print("⚠️  Kein Suchbegriff eingegeben.")
            continue
        
        try:
            # Search for videos
            print(f"\n🔍 Suche nach '{search_term}'...")
            results = search_video_for_deletion(search_term)
            
            if not results:
                print("❌ Keine Videos gefunden.")
                continue
            
            if len(results) > 1:
                print(f"\n⚠️  {len(results)} Videos gefunden. Bitte wähle eines aus:")
                for i, video in enumerate(results[:10], 1):
                    print(f"   {i}. {video.get('title', 'Unbekannt')}")
                    print(f"      Pfad: {video.get('filepath', 'N/A')}")
                
                if len(results) > 10:
                    print(f"   ... und {len(results) - 10} weitere")
                
                # Allow user to select one
                selection = input("\nWähle eine Nummer (1-10) oder 'z' für neue Suche: ").strip()
                
                if selection.lower() == 'z':
                    continue
                
                try:
                    idx = int(selection) - 1
                    if 0 <= idx < min(10, len(results)):
                        video = results[idx]
                    else:
                        print("⚠️  Ungültige Auswahl.")
                        continue
                except ValueError:
                    print("⚠️  Ungültige Eingabe.")
                    continue
            else:
                video = results[0]
            
            # Display video details
            print("\n" + "=" * 80)
            print(f"📹 Video gefunden:")
            print(f"   Titel:        {video.get('title', 'Unbekannt')}")
            print(f"   Künstler:     {video.get('artist', 'Unbekannt')}")
            print(f"   Genre:        {video.get('genre', 'Unbekannt')}")
            print(f"   Pfad:         {video.get('filepath', 'Unbekannt')}")
            
            # Extract video ID
            comment = video.get('comment', '')
            video_id = extract_video_id_from_comment(comment)
            if video_id:
                print(f"   Video-ID:     {video_id}")
            
            print("=" * 80)
            
            # Confirm deletion
            print("\n⚠️  ACHTUNG: Diese Aktion kann nicht rückgängig gemacht werden!")
            print("Das Video wird von allen Speicherorten gelöscht.")
            confirm = input("\nVideo wirklich löschen? [y/N]: ").strip().lower()
            
            if confirm not in ['y', 'j', 'ja', 'yes']:
                print("   Abgebrochen.")
                continue
            
            # Double confirmation
            double_confirm = input("Bist du sicher? Gib 'LÖSCHEN' ein zum Bestätigen: ").strip()
            
            if double_confirm != 'LÖSCHEN':
                print("   Abgebrochen.")
                continue
            
            # Perform the deletion
            success = delete_video_complete(video)
            
            if success:
                print(f"\n✅ Video erfolgreich gelöscht: {video.get('title', 'Video')}")
            else:
                print(f"\n⚠️  Video-Löschung teilweise fehlgeschlagen.")
                print("   Bitte überprüfe die Fehlermeldungen oben.")
            
            # Ask if user wants to delete another video
            another = input("\nWeiteres Video löschen? [y/N]: ").strip().lower()
            if another not in ['y', 'j', 'ja', 'yes']:
                break
        
        except FileNotFoundError as e:
            print(f"\n❌ {e}")
            break
        
        except Exception as e:
            print(f"\n❌ Fehler: {e}")
            if CONFIG.get('debug_mode', False):
                traceback.print_exc()
