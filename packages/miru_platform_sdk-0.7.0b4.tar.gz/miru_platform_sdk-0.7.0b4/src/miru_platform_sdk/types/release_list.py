# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List

from .shared.paginated_list import PaginatedList

__all__ = ["ReleaseList"]


class ReleaseList(PaginatedList):
    data: List["Release"]
    """The list of releases."""


from .release import Release
