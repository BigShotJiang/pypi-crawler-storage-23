"""
agentcents router.py — Phase 8
Auto-routing: warn or swap to cheaper same-family models when budget runs low.

Downgrade chains loaded from (in priority order):
  1. ~/.agentcents/chains.json       (auto-updated by agentcents sync)
  2. <package>/data/chains.json      (bundled fallback)

This means chains update without recompiling the binary.

Config in ~/.agentcents.toml:
  [routing]
  mode           = "warn"   # "warn" (default) or "swap"
  threshold_pct  = 80       # trigger at 80% of daily budget used
  skip_tool_use  = true     # never swap if request contains tool_use
"""

import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger("agentcents.router")

# Paths
LOCAL_CHAINS_PATH   = Path.home() / ".agentcents" / "chains.json"
BUNDLED_CHAINS_PATH = Path(__file__).parent / "data" / "chains.json"

# Cache loaded chains in memory (reload on each proxy restart)
_chains_cache: Optional[dict] = None


# ---------------------------------------------------------------------------
# Chains loader
# ---------------------------------------------------------------------------

def _load_chains() -> dict:
    """Load downgrade chains from local file, falling back to bundled."""
    global _chains_cache
    if _chains_cache is not None:
        return _chains_cache

    for path in [LOCAL_CHAINS_PATH, BUNDLED_CHAINS_PATH]:
        try:
            if path.exists():
                with open(path) as f:
                    data = json.load(f)
                _chains_cache = data
                logger.info(f"Loaded chains from {path} (v{data.get('_version', '?')})")
                return _chains_cache
        except Exception as e:
            logger.warning(f"Could not load chains from {path}: {e}")

    # Hard fallback — empty chains
    logger.warning("No chains.json found — routing disabled")
    _chains_cache = {"downgrade_chains": {}, "never_swap": []}
    return _chains_cache


def reload_chains():
    """Force reload chains from disk — call after agentcents sync."""
    global _chains_cache
    _chains_cache = None
    return _load_chains()


def get_downgrade_chains() -> dict:
    return _load_chains().get("downgrade_chains", {})


def get_never_swap() -> set:
    return set(_load_chains().get("never_swap", []))


# ---------------------------------------------------------------------------
# Chains update from server
# ---------------------------------------------------------------------------

def sync_chains():
    """
    Fetch latest chains.json from Labham server.
    Called by `agentcents sync`.
    """
    import httpx
    CHAINS_URL = "https://labham-agentcents.github.io/api/chains.json"
    try:
        r = httpx.get(CHAINS_URL, timeout=10)
        r.raise_for_status()
        data = r.json()
        LOCAL_CHAINS_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(LOCAL_CHAINS_PATH, "w") as f:
            json.dump(data, f, indent=2)
        reload_chains()
        logger.info(f"Chains updated to v{data.get('_version', '?')}")
        return True
    except Exception as e:
        logger.warning(f"Chains sync failed: {e}")
        return False


# ---------------------------------------------------------------------------
# Main routing check
# ---------------------------------------------------------------------------

def check_routing(
    model_id: str,
    body_json: dict,
    tag: str,
) -> dict:
    """
    Check if routing should trigger for this request.

    Returns:
        {
            "action":      "none" | "warn" | "swap",
            "original":    model_id,
            "suggested":   cheaper_model_id or None,
            "reason":      human-readable reason,
            "savings_pct": int (0-100),
        }
    """
    result = {
        "action":      "none",
        "original":    model_id,
        "suggested":   None,
        "reason":      "",
        "savings_pct": 0,
    }

    # -- Load config --------------------------------------------------------
    try:
        from agentcents.config import load as load_config
        cfg        = load_config()
        routing    = cfg.get("routing", {})
        mode       = routing.get("mode", "warn")
        thresh     = routing.get("threshold_pct", 80) / 100.0
        skip_tools = routing.get("skip_tool_use", True)
    except Exception:
        return result

    if mode == "off":
        return result

    # -- Never swap these models --------------------------------------------
    normalized = _normalize(model_id)
    if normalized in get_never_swap():
        return result

    # -- Skip if request uses tools -----------------------------------------
    if skip_tools and _has_tools(body_json):
        return result

    # -- Check budget threshold ---------------------------------------------
    budget_pct = _budget_usage_pct(tag)
    if budget_pct < thresh:
        return result

    # -- Find cheaper alternative -------------------------------------------
    suggested = get_downgrade_chains().get(normalized)
    if not suggested:
        return result

    # -- Calculate savings --------------------------------------------------
    savings_pct = _calc_savings_pct(normalized, suggested)
    if savings_pct <= 0:
        return result

    # -- Determine action (warn vs swap) ------------------------------------
    action = "warn"
    if mode == "swap":
        try:
            from agentcents.license import is_premium
            if is_premium():
                action = "swap"
        except Exception:
            action = "warn"

    reason = (
        f"Budget {int(budget_pct * 100)}% used "
        f"(threshold {int(thresh * 100)}%) — "
        f"{normalized} → {suggested} saves {savings_pct}%"
    )

    result.update({
        "action":      action,
        "suggested":   suggested,
        "reason":      reason,
        "savings_pct": savings_pct,
    })
    return result


def apply_routing(body_json: dict, suggested_model: str) -> dict:
    """Return a copy of body_json with the model swapped."""
    import copy
    new_body       = copy.deepcopy(body_json)
    bare           = suggested_model.split("/")[-1]
    new_body["model"] = bare
    return new_body


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _normalize(model_id: str) -> str:
    if "/" in model_id:
        return model_id
    try:
        from agentcents.catalog import normalize_model_id
        return normalize_model_id(model_id)
    except Exception:
        return model_id


def _has_tools(body_json: dict) -> bool:
    if not body_json:
        return False
    return bool(body_json.get("tools") or body_json.get("tool_choice"))


def _budget_usage_pct(tag: str) -> float:
    import time
    import sqlite3
    try:
        from agentcents.config import load as load_config
        cfg           = load_config()
        budgets       = cfg.get("budgets", {})
        tag_budget    = budgets.get("tags", {}).get(tag, {}).get("daily")
        global_budget = budgets.get("daily")

        db = Path(__file__).parent / "data" / "ledger.db"
        if not db.exists():
            return 0.0

        since = time.time() - 86400
        conn  = sqlite3.connect(db)

        if tag_budget:
            row   = conn.execute(
                "SELECT SUM(cost_usd) FROM calls WHERE ts >= ? AND tag = ? AND cost_usd IS NOT NULL",
                (since, tag)
            ).fetchone()
            spent = row[0] or 0.0
            conn.close()
            return spent / tag_budget

        if global_budget:
            row   = conn.execute(
                "SELECT SUM(cost_usd) FROM calls WHERE ts >= ? AND cost_usd IS NOT NULL",
                (since,)
            ).fetchone()
            spent = row[0] or 0.0
            conn.close()
            return spent / global_budget

        conn.close()
    except Exception:
        pass
    return 0.0


def _calc_savings_pct(original: str, suggested: str) -> int:
    try:
        from agentcents.catalog import get_model_price
        orig_price = get_model_price(original)
        sugg_price = get_model_price(suggested)
        if not orig_price or not sugg_price:
            return 0
        if orig_price["input"] <= 0:
            return 0
        saving = (orig_price["input"] - sugg_price["input"]) / orig_price["input"]
        return max(0, int(saving * 100))
    except Exception:
        return 0
