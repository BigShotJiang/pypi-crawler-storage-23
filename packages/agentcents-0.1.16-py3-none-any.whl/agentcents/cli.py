import os
import time
import argparse
import datetime
from agentcents.catalog import sync_catalog, get_model_price
from agentcents.db import get_connection
from agentcents.ledger import summary, recent as ledger_recent

def cmd_local(args):
    """Show local model usage and power costs."""
    from agentcents.ledger import summary
    import datetime

    hours = args.hours
    rows  = summary(since_hours=hours)

    # Filter local (ollama) calls
    local_rows = [r for r in rows if (r["model_id"] or "").startswith("ollama/")]
    cloud_rows = [r for r in rows if not (r["model_id"] or "").startswith("ollama/")]

    print(f"\nLocal vs Cloud — last {hours}h\n")

    if local_rows:
        print("  LOCAL (GPU power cost)")
        print(f"  {'MODEL':<35} {'CALLS':>6} {'IN':>8} {'OUT':>8} {'POWER $':>10} {'AVG LAT':>9}")
        print("  " + "-" * 82)
        for r in local_rows:
            model = (r["model_id"] or "")[:34]
            print(
                f"  {model:<35} {r['calls']:>6} "
                f"{(r['total_prompt'] or 0):>8,} "
                f"{(r['total_completion'] or 0):>8,} "
                f"{(r['total_cost'] or 0):>10.6f} "
                f"{(r['avg_latency'] or 0):>8.2f}s"
            )
        local_total = sum(r["total_cost"] or 0 for r in local_rows)
        print(f"\n  Local total power cost: ${local_total:.6f}\n")

    if cloud_rows:
        print("  CLOUD (API cost)")
        print(f"  {'MODEL':<35} {'CALLS':>6} {'IN':>8} {'OUT':>8} {'COST $':>10} {'AVG LAT':>9}")
        print("  " + "-" * 82)
        for r in cloud_rows:
            model = (r["model_id"] or "")[:34]
            print(
                f"  {model:<35} {r['calls']:>6} "
                f"{(r['total_prompt'] or 0):>8,} "
                f"{(r['total_completion'] or 0):>8,} "
                f"{(r['total_cost'] or 0):>10.6f} "
                f"{(r['avg_latency'] or 0):>8.2f}s"
            )
        cloud_total = sum(r["total_cost"] or 0 for r in cloud_rows)
        print(f"\n  Cloud total API cost: ${cloud_total:.6f}\n")

    if not local_rows and not cloud_rows:
        print("  No calls recorded yet.\n")


async def cmd_local_models(args):
    """List locally available Ollama models."""
    import asyncio
    from agentcents.local import list_local_models

    models = await list_local_models()
    if not models:
        print("\n  No Ollama models found — is Ollama running?\n")
        return
    print(f"\nLocal Ollama models\n")
    for m in models:
        print(f"  {m}")
    print()


def cmd_train(args):
    try:
        from agentcents.features import gate; gate("predictor")
        from agentcents.predictor import train, prediction_report
        print("Training cost predictor on ledger data...")
        ok = train(force=True)
        if ok:
            prediction_report()
        else:
            print("  Not enough data yet — need 20+ calls with cost data.\n")
    except PermissionError as e:
        print(e)

def cmd_activate(args):
    from agentcents.license import activate
    result = activate(args.key)
    print(f"\n  {result['message']}\n")


def cmd_deactivate(args):
    from agentcents.license import deactivate
    deactivate()


def cmd_features(args):
    from agentcents.features import print_feature_table
    print_feature_table()

def cmd_models(args):
    sync_catalog()
    conn = get_connection()

    sort = getattr(args, 'sort', 'provider')
    if sort == 'cost':
        order = "ORDER BY input_price DESC"
    elif sort == 'name':
        order = "ORDER BY model_id"
    else:  # provider (default)
        order = "ORDER BY provider, input_price DESC"

    rows = conn.execute(f"""
        SELECT model_id, display_name, input_price, output_price, source
        FROM models
        {order}
    """).fetchall()
    conn.close()

    print(f"\n{'MODEL':<45} {'INPUT $/M':>10} {'OUTPUT $/M':>11} {'SOURCE':<12}")
    print("-" * 82)
    for r in rows:
        print(f"{r['model_id']:<45} {r['input_price']:>10.4f} {r['output_price']:>11.4f} {r['source']:<12}")
    print(f"\n{len(rows)} models loaded.\n")

def cmd_sync(args):
    print("Syncing pricing catalog...")
    sync_catalog()
    from agentcents.router import sync_chains
    sync_chains()
    print("Done.")
    from agentcents.config import write_default as write_default_config
    write_default_config()


def cmd_usage(args):
    rows = summary(tag=args.tag, since_hours=args.hours)

    period    = f"last {args.hours}h"
    tag_label = f" [{args.tag}]" if args.tag else ""
    print(f"\nCost summary — {period}{tag_label}\n")

    if not rows:
        print("  No calls recorded yet.\n")
        return

    print(f"{'MODEL':<45} {'TAG':<15} {'CALLS':>6} {'IN TOK':>9} {'OUT TOK':>9} {'COST $':>10} {'AVG LAT':>9} {'ERR':>5}")
    print("-" * 115)

    total_cost = 0.0
    for r in rows:
        cost    = r["total_cost"]        or 0.0
        in_tok  = r["total_prompt"]      or 0
        out_tok = r["total_completion"]  or 0
        lat     = r["avg_latency"]       or 0.0
        errors  = r["errors"]            or 0
        total_cost += cost
        print(
            f"{(r['model_id'] or 'unknown'):<45} "
            f"{(r['tag'] or ''):<15} "
            f"{r['calls']:>6} "
            f"{in_tok:>9,} "
            f"{out_tok:>9,} "
            f"{cost:>10.6f} "
            f"{lat:>8.2f}s "
            f"{errors:>5}"
        )

    print("-" * 115)
    print(f"{'TOTAL':<45} {'':>15} {'':>6} {'':>9} {'':>9} {total_cost:>10.6f}\n")


def cmd_recent(args):
    rows = ledger_recent(n=args.n)

    if not rows:
        print("\n  No calls recorded yet.\n")
        return

    print(f"\nLast {len(rows)} calls\n")
    print(f"{'TIME':<20} {'MODEL':<40} {'TAG':<15} {'IN':>7} {'OUT':>7} {'COST $':>10} {'LAT':>7} {'ST':>4}")
    print("-" * 115)
    for r in rows:
        ts   = datetime.datetime.fromtimestamp(r["ts"]).strftime("%Y-%m-%d %H:%M:%S")
        cost = r["cost_usd"] or 0.0
        inp  = r["prompt_tokens"]     or "-"
        out  = r["completion_tokens"] or "-"
        lat  = f"{r['elapsed_s']:.2f}s" if r["elapsed_s"] else "-"
        print(
            f"{ts:<20} "
            f"{(r['model_id'] or 'unknown'):<40} "
            f"{(r['tag'] or ''):<15} "
            f"{str(inp):>7} "
            f"{str(out):>7} "
            f"{cost:>10.6f} "
            f"{lat:>7} "
            f"{r['status']:>4}"
        )
    print()


def cmd_watch(args):
    try:
        from agentcents.features import gate; gate("multi_agent")
    except PermissionError as e:
        print(e)
        return

    poll     = args.poll
    seen_ids = set()

    def render():
        rows     = ledger_recent(n=50)
        new_rows = [r for r in rows if r['id'] not in seen_ids]
        for r in new_rows:
            seen_ids.add(r['id'])

        os.system('clear')
        now = datetime.datetime.now().strftime("%H:%M:%S")
        print(f"\033[32magentcents watch\033[0m  \033[90m{now} — refreshing every {poll}s  (ctrl+c to quit)\033[0m\n")
        print(f"\033[90m{'TIME':<20} {'MODEL':<40} {'TAG':<14} {'IN':>7} {'OUT':>7} {'COST $':>11} {'LAT':>7} {'ST':>4}\033[0m")
        print("\033[90m" + "─" * 112 + "\033[0m")

        for r in rows[:30]:
            ts    = datetime.datetime.fromtimestamp(r['ts']).strftime("%H:%M:%S %m/%d")
            model = (r['model_id'] or 'unknown')[:39]
            tag   = (r['tag'] or '')[:13]
            inp   = str(r['prompt_tokens'])     if r['prompt_tokens']     is not None else '—'
            out   = str(r['completion_tokens']) if r['completion_tokens'] is not None else '—'
            cost  = f"${r['cost_usd']:.6f}"    if r['cost_usd']          is not None else '—'
            lat   = f"{r['elapsed_s']:.2f}s"   if r['elapsed_s']         is not None else '—'
            st    = str(r['status'] or '—')

            new_marker = "\033[32m" if r in new_rows else "\033[0m"
            reset      = "\033[0m"
            st_color   = "\033[32m" if str(r['status']).startswith('2') else "\033[31m"

            print(f"{new_marker}{ts:<20} \033[36m{model:<40}\033[0m {tag:<14} {inp:>7} {out:>7} \033[32m{cost:>11}{reset} {lat:>7} {st_color}{st:>4}{reset}")

        if new_rows:
            total_new_cost = sum(r['cost_usd'] or 0 for r in new_rows)
            print(f"\n\033[32m  ↑ {len(new_rows)} new call(s)  +${total_new_cost:.6f}\033[0m")

        total = sum(r['cost_usd'] or 0 for r in rows)
        print(f"\n\033[90m  total visible: ${total:.6f}  │  dashboard: http://localhost:8082/dashboard\033[0m")

    try:
        while True:
            render()
            time.sleep(poll)
    except KeyboardInterrupt:
        print("\n\033[90magentcents watch stopped.\033[0m")


def cmd_suggest(args):
    try:
        from agentcents.features import gate; gate("advisor")
        from agentcents.advisor import print_suggestions
        print_suggestions(since_hours=args.hours)
    except PermissionError as e:
        print(e)


def cmd_alerts(args):
    from agentcents.alerts import get_recent_alerts
    rows = get_recent_alerts(n=args.n)
    print(f"\nBudget alerts (last {args.n})\n")
    if not rows:
        print("  No alerts — budgets are clear.\n")
        return
    print(f"{'TIME':<20} {'LEVEL':<10} {'SCOPE':<20} {'MESSAGE'}")
    print("-" * 90)
    for r in rows:
        ts    = datetime.datetime.fromtimestamp(r["ts"]).strftime("%Y-%m-%d %H:%M:%S")
        level = r["level"].upper()
        color = "\033[33m" if r["level"] == "warn" else "\033[31m"
        reset = "\033[0m"
        print(f"{ts:<20} {color}{level:<10}{reset} {r['scope']:<20} {r['message']}")
    print()


def cmd_rolling(args):
    from agentcents.ledger import rolling_spend, rolling_summary
    from agentcents.config import load as load_config

    days   = args.days
    spent  = rolling_spend(days=days)
    cfg    = load_config()
    budget = cfg.get("budgets", {}).get("monthly")
    rows   = rolling_summary(days=days)

    print(f"\nRolling {days}-day spend\n")
    if budget:
        pct   = (spent / budget) * 100
        bar   = "█" * int(pct / 5)
        color = "\033[31m" if pct >= 100 else "\033[33m" if pct >= 80 else "\033[32m"
        reset = "\033[0m"
        print(f"  {color}${spent:.6f} of ${budget:.2f} ({pct:.0f}%)  {bar}{reset}\n")
    else:
        print(f"  Total: ${spent:.6f}  (no monthly budget set)\n")

    if rows:
        print(f"  {'DAY':<12} {'CALLS':>6} {'COST $':>12}")
        print("  " + "-" * 32)
        for r in rows:
            print(f"  {r['day']:<12} {r['calls']:>6} {(r['total_cost'] or 0):>12.6f}")
    print()


def cmd_agents(args):
    from agentcents.ledger import agent_summary

    rows = agent_summary(since_hours=args.hours)
    print(f"\nAgents — last {args.hours}h\n")

    if not rows:
        print("  No agent activity recorded.\n")
        return

    print(f"  {'SESSION':<22} {'TAG':<14} {'CALLS':>6} {'IN':>8} {'OUT':>8} {'COST $':>12} {'LAT':>7} {'ERR':>5}")
    print("  " + "-" * 90)
    for r in rows:
        sid = (r["session_id"] or "default")[:21]
        tag = (r["tag"]        or "")[:13]
        print(
            f"  {sid:<22} {tag:<14} "
            f"{r['calls']:>6} "
            f"{(r['total_prompt'] or 0):>8,} "
            f"{(r['total_completion'] or 0):>8,} "
            f"{(r['total_cost'] or 0):>12.6f} "
            f"{(r['avg_latency'] or 0):>6.2f}s "
            f"{(r['errors'] or 0):>5}"
        )
    print()


def cmd_dashboard(args):
    try:
        from agentcents.features import gate; gate("multi_agent")
    except PermissionError as e:
        print(e)
        return
    except ImportError as e:
        print(f"\n  Missing dependency: {e}\n  Run: pip install 'agentcents[pro]'\n")
        return
    try:
        from agentcents.tui import launch
        launch()
    except ImportError:
        print("\n  Textual not installed — run: pip install 'agentcents[pro]'\n")


def cmd_start(args):
    try:
        import uvicorn
    except ImportError:
        print("\n  uvicorn not installed — run: pip install uvicorn\n")
        return

    host = args.host
    port = args.port

    print(f"\n  \033[32magentcents proxy\033[0m  listening on http://{host}:{port}")
    print(f"  dashboard:  http://{host}:{port}/dashboard")
    print(f"  health:     http://{host}:{port}/health")
    print(f"\n  Point your LLM client at http://{host}:{port}")
    print(f"  and add:    X-Agentcents-Target: https://api.openai.com")
    print(f"\n  \033[90mctrl+c to stop\033[0m\n")

    uvicorn.run(
        "agentcents.proxy:app",
        host=host,
        port=port,
        reload=args.reload,
        log_level="warning",  # agentcents has its own logging; suppress uvicorn noise
    )


def main():
    from agentcents import __version__
    parser = argparse.ArgumentParser(prog="agentcents")
    parser.add_argument("--version", action="version", version=f"agentcents {__version__}")
    sub = parser.add_subparsers(dest="command")

    # Proxy server
    p_start = sub.add_parser("start", help="Start the agentcents proxy server")
    p_start.add_argument("--host",   default="127.0.0.1",  help="Bind host (default: 127.0.0.1)")
    p_start.add_argument("--port",   default=8082, type=int, help="Port (default: 8082)")
    p_start.add_argument("--reload", action="store_true",   help="Auto-reload on code changes (dev)")

    # Account
    p_activate = sub.add_parser("activate",   help="Activate agentcents Pro license")
    p_activate.add_argument("key", type=str,  help="License key from Gumroad")
    sub.add_parser("deactivate", help="Remove Pro license (revert to free tier)")
    sub.add_parser("features",   help="Show available features for current tier")

    # Catalog
    p_models = sub.add_parser("models", help="List all models and current pricing")
    p_models.add_argument("--sort", choices=["cost", "provider", "name"], default="provider", help="Sort by: cost, provider, name")
    sub.add_parser("sync",   help="Force sync pricing catalog")

    # Cost reporting
    p_usage = sub.add_parser("usage", help="Cost summary by model and tag")
    p_usage.add_argument("--hours", type=float, default=24)
    p_usage.add_argument("--tag",   type=str,   default=None)

    p_recent = sub.add_parser("recent", help="Show recent individual calls")
    p_recent.add_argument("--n", type=int, default=20)

    p_rolling = sub.add_parser("rolling", help="Rolling 30-day spend")
    p_rolling.add_argument("--days", type=int, default=30)

    p_agents = sub.add_parser("agents", help="Per-agent cost breakdown")
    p_agents.add_argument("--hours", type=float, default=24)

    # Live views
    p_watch = sub.add_parser("watch", help="Live tail of API calls and costs")
    p_watch.add_argument("--poll", type=float, default=2.0)

    sub.add_parser("dashboard", help="Launch TUI dashboard")

    # Intelligence
    p_suggest = sub.add_parser("suggest", help="Model swap suggestions (Pro)")
    p_suggest.add_argument("--hours", type=float, default=168)

    p_alerts = sub.add_parser("alerts", help="Show budget alerts")
    p_alerts.add_argument("--n", type=int, default=20)

    sub.add_parser("train", help="Train XGBoost cost predictor (Pro)")


    p_local = sub.add_parser("local", help="Local vs cloud cost comparison")
    p_local.add_argument("--hours", type=float, default=24)
 
    sub.add_parser("local-models", help="List available Ollama models")

    args = parser.parse_args()

    if   args.command == "start":      cmd_start(args)
    elif args.command == "activate":   cmd_activate(args)
    elif args.command == "deactivate": cmd_deactivate(args)
    elif args.command == "features":   cmd_features(args)
    elif args.command == "models":     cmd_models(args)
    elif args.command == "sync":       cmd_sync(args)
    elif args.command == "usage":      cmd_usage(args)
    elif args.command == "recent":     cmd_recent(args)
    elif args.command == "rolling":    cmd_rolling(args)
    elif args.command == "agents":     cmd_agents(args)
    elif args.command == "watch":      cmd_watch(args)
    elif args.command == "dashboard":  cmd_dashboard(args)
    elif args.command == "suggest":    cmd_suggest(args)
    elif args.command == "alerts":     cmd_alerts(args)
    elif args.command == "train":      cmd_train(args)
    elif args.command == "local":      cmd_local(args)
    elif args.command == "local-models": import asyncio; asyncio.run(cmd_local_models(args))
    else:                              parser.print_help()


if __name__ == "__main__":
    main()
