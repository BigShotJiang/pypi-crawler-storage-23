"""
agentcents advisor.py — Phase 5
Analyzes actual usage from ledger and suggests cheaper alternatives.
"""

import sqlite3
import time
from pathlib import Path
from typing import Optional

from agentcents.config import load as load_config

DB_PATH = Path(__file__).parent / "data" / "ledger.db"

# ---------------------------------------------------------------------------
# Model alternatives map
# Ordered by quality tier — suggests next tier down that saves meaningfully
# ---------------------------------------------------------------------------

ALTERNATIVES = {
    # Anthropic
    "anthropic/claude-opus-4":       ["anthropic/claude-sonnet-4", "anthropic/claude-3.5-sonnet"],
    "anthropic/claude-sonnet-4":     ["anthropic/claude-3.5-sonnet", "anthropic/claude-3-haiku", "google/gemini-2.0-flash"],
    "anthropic/claude-3.5-sonnet":   ["anthropic/claude-3-haiku", "google/gemini-2.0-flash"],
    "anthropic/claude-3-haiku":      ["google/gemini-2.0-flash", "mistral/mistral-small"],
    # OpenAI
    "openai/o3":                     ["openai/gpt-4o", "anthropic/claude-sonnet-4"],
    "openai/gpt-4o":                 ["openai/gpt-4o-mini", "anthropic/claude-3-haiku", "google/gemini-2.0-flash"],
    "openai/gpt-4o-mini":            ["google/gemini-2.0-flash", "mistral/mistral-small"],
    # Google
    "google/gemini-2.5-pro":         ["google/gemini-2.0-flash", "openai/gpt-4o-mini"],
    # xAI
    "xai/grok-3":                    ["anthropic/claude-sonnet-4", "openai/gpt-4o"],
    # Cohere
    "cohere/command-r-plus":         ["openai/gpt-4o-mini", "anthropic/claude-3-haiku"],
    # Mistral
    "mistral/mistral-large":         ["mistral/mistral-small", "google/gemini-2.0-flash"],
}


def _conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _get_price(model_id: str) -> dict:
    from agentcents.catalog import get_model_price
    return get_model_price(model_id)


def _get_usage_summary(since_hours: float = 168) -> list:
    """Get per-model usage for the last N hours (default 7 days)."""
    since = time.time() - since_hours * 3600
    with _conn() as conn:
        rows = conn.execute("""
            SELECT
                model_id,
                COUNT(*) as calls,
                SUM(prompt_tokens) as total_in,
                SUM(completion_tokens) as total_out,
                SUM(cost_usd) as total_cost,
                AVG(prompt_tokens) as avg_in,
                AVG(completion_tokens) as avg_out
            FROM calls
            WHERE ts >= ? AND cost_usd > 0
            GROUP BY model_id
            ORDER BY total_cost DESC
        """, (since,)).fetchall()
    return [dict(r) for r in rows]


def get_suggestions(since_hours: float = 168) -> list:
    """
    Analyze usage and return swap suggestions with projected savings.
    """
    cfg = load_config()
    min_saving_pct = cfg.get("advisor", {}).get("min_saving_pct", 20)

    usage = _get_usage_summary(since_hours)
    suggestions = []

    for u in usage:
        model_id = u["model_id"]
        if not model_id or not u["total_cost"]:
            continue

        # Normalize to catalog ID
        from agentcents.catalog import normalize_model_id
        normalized = normalize_model_id(model_id)
        alts = ALTERNATIVES.get(normalized, [])

        current_price = _get_price(normalized)
        avg_in  = u["avg_in"]  or 0
        avg_out = u["avg_out"] or 0
        calls   = u["calls"]

        if not avg_in and not avg_out:
            continue

        for alt_id in alts:
            alt_price = _get_price(alt_id)

            # Skip if no price data
            if alt_price["input"] == 0 and alt_price["output"] == 0:
                continue

            # Project cost if same token usage on alt model
            current_per_call = (
                (avg_in  / 1_000_000) * current_price["input"] +
                (avg_out / 1_000_000) * current_price["output"]
            )
            alt_per_call = (
                (avg_in  / 1_000_000) * alt_price["input"] +
                (avg_out / 1_000_000) * alt_price["output"]
            )

            if current_per_call == 0:
                continue

            saving_pct = ((current_per_call - alt_per_call) / current_per_call) * 100
            if saving_pct < min_saving_pct:
                continue

            projected_saving = (current_per_call - alt_per_call) * calls
            projected_period = f"{int(since_hours // 24)}d" if since_hours >= 24 else f"{int(since_hours)}h"

            suggestions.append({
                "current_model":     model_id,
                "alt_model":         alt_id,
                "calls":             calls,
                "current_cost":      u["total_cost"],
                "projected_cost":    alt_per_call * calls,
                "projected_saving":  projected_saving,
                "saving_pct":        saving_pct,
                "current_input_price":  current_price["input"],
                "current_output_price": current_price["output"],
                "alt_input_price":      alt_price["input"],
                "alt_output_price":     alt_price["output"],
                "period":            projected_period,
                "avg_in":            avg_in,
                "avg_out":           avg_out,
            })
            break  # only suggest the best alternative per model

    suggestions.sort(key=lambda x: x["projected_saving"], reverse=True)
    return suggestions


def print_suggestions(since_hours: float = 168):
    suggestions = get_suggestions(since_hours)
    period = f"{int(since_hours // 24)} days" if since_hours >= 24 else f"{int(since_hours)} hours"

    print(f"\nagentcents advisor — based on last {period} of usage\n")

    if not suggestions:
        print("  No suggestions — either usage is too low or you're already on optimal models.\n")
        return

    for s in suggestions:
        saving_pct = s["saving_pct"]
        bar = "█" * int(saving_pct / 5)  # visual bar up to 20 blocks

        print(f"  \033[33m{s['current_model']}\033[0m")
        print(f"    → switch to  \033[32m{s['alt_model']}\033[0m")
        print(f"    pricing:     ${s['current_input_price']:.4f}/${s['current_output_price']:.4f} per M  →  ${s['alt_input_price']:.4f}/${s['alt_output_price']:.4f} per M  (in/out)")
        print(f"    usage:       {s['calls']} calls, avg {int(s['avg_in'])} in / {int(s['avg_out'])} out tokens")
        print(f"    actual cost: \033[33m${s['current_cost']:.6f}\033[0m  →  projected \033[32m${s['projected_cost']:.6f}\033[0m")
        print(f"    saving:      \033[32m${s['projected_saving']:.6f}  ({saving_pct:.0f}% cheaper)  {bar}\033[0m")
        print()
