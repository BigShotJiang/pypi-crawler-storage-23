"""
agentcents license.py — Phase 5
Client-side license management.

  agentcents activate <key>   — validate key against Worker, save locally
  agentcents deactivate       — remove local license

Feature gating:
  from agentcents.license import require_premium, is_premium
  if is_premium():
      ...
"""

import json
import time
import uuid
import hashlib
import logging
import platform
from pathlib import Path
from typing import Optional

logger = logging.getLogger("agentcents.license")

LICENSE_PATH    = Path.home() / ".agentcents.license"
WORKER_BASE_URL = "https://agentcents-license.labham.workers.dev"
VALIDATE_URL    = f"{WORKER_BASE_URL}/validate"

# Cache validation result in memory for the process lifetime
_license_cache: Optional[dict] = None
_cache_ts: float = 0
CACHE_TTL = 3600  # re-validate against Worker once per hour


# ---------------------------------------------------------------------------
# Machine ID (stable anonymous identifier, no PII)
# ---------------------------------------------------------------------------

def _machine_id() -> str:
    """Stable hash of machine hostname + platform. Not reversible."""
    raw = f"{platform.node()}-{platform.machine()}-{platform.system()}"
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Local license file
# ---------------------------------------------------------------------------

def _load_local() -> Optional[dict]:
    if not LICENSE_PATH.exists():
        return None
    try:
        return json.loads(LICENSE_PATH.read_text())
    except Exception:
        return None


def _save_local(data: dict):
    LICENSE_PATH.write_text(json.dumps(data, indent=2))
    LICENSE_PATH.chmod(0o600)  # owner read/write only


def _clear_local():
    if LICENSE_PATH.exists():
        LICENSE_PATH.unlink()


# ---------------------------------------------------------------------------
# Remote validation
# ---------------------------------------------------------------------------

def _validate_remote(key: str) -> dict:
    """Call the Cloudflare Worker to validate the key."""
    try:
        import httpx
        resp = httpx.post(
            VALIDATE_URL,
            json={"key": key, "machine_id": _machine_id()},
            timeout=10,
        )
        return resp.json()
    except Exception as e:
        logger.warning(f"License validation network error: {e}")
        return {"valid": None, "reason": "network_error"}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def activate(key: str) -> dict:
    """
    Validate key against Worker and save locally if valid.
    Returns {"success": True/False, "message": "..."}
    """
    key = key.strip().upper()
    result = _validate_remote(key)

    if result.get("valid") is True:
        record = {
            "key":          key,
            "tier":         result.get("tier", "pro"),
            "email":        result.get("email", ""),
            "activated_at": result.get("activated_at", ""),
            "validated_at": time.time(),
        }
        _save_local(record)
        global _license_cache, _cache_ts
        _license_cache = record
        _cache_ts = time.time()
        return {"success": True, "message": f"✓ agentcents Pro activated  ({result.get('email', '')})"}

    elif result.get("valid") is False:
        reason = result.get("reason", "invalid")
        msg = {
            "key_not_found": "Key not found. Check your Gumroad receipt for the correct key.",
            "key_revoked":   "This key has been revoked. Contact support@labham.com",
        }.get(reason, f"Activation failed: {reason}")
        return {"success": False, "message": msg}

    else:
        # Network error — if they already have a local license, keep it
        local = _load_local()
        if local:
            return {"success": True, "message": "⚠ Could not reach license server — using cached license"}
        return {"success": False, "message": "Could not reach license server. Check your internet connection."}


def deactivate():
    """Remove local license."""
    _clear_local()
    global _license_cache
    _license_cache = None
    print("License removed. You're now on the free tier.")


def _get_license() -> Optional[dict]:
    """Return current license, re-validating remotely if cache is stale."""
    global _license_cache, _cache_ts

    # Use in-memory cache first
    if _license_cache and (time.time() - _cache_ts) < CACHE_TTL:
        return _license_cache

    # Load from disk
    local = _load_local()
    if not local:
        return None

    # Re-validate remotely if more than 1 hour old
    if time.time() - local.get("validated_at", 0) > CACHE_TTL:
        result = _validate_remote(local["key"])
        if result.get("valid") is False:
            # Key was revoked — clear local
            _clear_local()
            _license_cache = None
            logger.warning("License key revoked — reverting to free tier")
            return None
        if result.get("valid") is True:
            local["validated_at"] = time.time()
            _save_local(local)

    _license_cache = local
    _cache_ts = time.time()
    return local


def is_premium() -> bool:
    """Returns True if user has a valid Pro license."""
    return _get_license() is not None


def require_premium(feature: str = "this feature"):
    """
    Raise if not premium.
    Call at the top of any premium-only function.
    """
    if not is_premium():
        raise PermissionError(
            f"\n  {feature} is a agentcents Pro feature.\n"
            f"  Get your license at: https://labham.gumroad.com/l/agentcents-pro\n"
            f"  Then run: agentcents activate <your-key>\n"
        )


def license_info() -> dict:
    """Return current license info for display."""
    local = _get_license()
    if not local:
        return {"tier": "free", "active": False}
    return {
        "tier":         local.get("tier", "pro"),
        "email":        local.get("email", ""),
        "activated_at": local.get("activated_at", ""),
        "active":       True,
    }
