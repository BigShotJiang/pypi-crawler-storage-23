class IncompleteArgumentsError(Exception):
    pass

class AuthorizationError(Exception):
    pass