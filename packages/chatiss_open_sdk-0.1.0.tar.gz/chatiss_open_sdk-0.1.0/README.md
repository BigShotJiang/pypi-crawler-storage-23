﻿# Chatiss Open SDK（内部仓库文档）

本文件用于仓库维护和发布操作说明。

## 1. 项目结构

```text
src/chatiss_open_sdk/
  clients/      # 业务客户端（同步/异步）
  core/         # HTTP、SSE、Token、协议解析
  exceptions.py # 异常定义
  types.py      # 数据结构
test/           # 单元测试
```

## 2. 本地开发环境

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install -U pip
python -m pip install -e .
python -m pip install pytest pytest-asyncio build twine
```

## 3. 测试

```bash
python -m pytest -q
```

说明：
- 当前测试应保持为离线单测，不依赖真实 AK/SK。
- 新增接口时必须补充同步/异步路径的单元测试。

## 4. 版本管理

发布前同步更新：
- `pyproject.toml` 的 `project.version`
- `src/chatiss_open_sdk/_version.py` 的 `__version__`

## 5. 构建

```bash
python -m build
```

构建产物位于 `dist/`，包含：
- `*.whl`
- `*.tar.gz`

## 6. 发包前校验

```bash
python -m twine check dist/*
```

## 7. 上传到 PyPI（可选）

```bash
python -m twine upload dist/*
```

## 8. 发布后验证

```bash
pip install -U chatiss-open-sdk
python -c "import chatiss_open_sdk; print(chatiss_open_sdk.__version__)"
```

## 9. 文档约定

- 仓库文档：`README.md`（本文档）
- PyPI 展示文档：`README.pypi.md`
- PyPI 中文文档（备用）：`README.pypi.zh-CN.md`
- 开源协议文件：`LICENSE`
- `pyproject.toml` 的 `project.readme` 固定指向 `README.pypi.md`
