import httpx
import pytest

from chatiss_open_sdk import OpenAPIClient, SDKConfig
from chatiss_open_sdk.exceptions import NetworkError


def _make_config() -> SDKConfig:
    return SDKConfig(
        access_key_id="test-ak",
        access_key_secret="test-sk",
    )


def test_get_jwt_token_fail_returns_api_response(monkeypatch):
    client = OpenAPIClient(_make_config())

    def fake_request(*args, **kwargs):
        return {"status": "FAIL", "code": 1001, "msg": "invalid ak/sk", "result": None}

    monkeypatch.setattr(client, "_request", fake_request)
    try:
        response = client.get_jwt_token()
    finally:
        client.close()

    assert response.status == "FAIL"
    assert response.code == 1001
    assert response.msg == "invalid ak/sk"
    assert response.result is None


def test_sync_client_supports_context_manager():
    with OpenAPIClient(_make_config()) as client:
        assert client._http.is_closed is False
    assert client._http.is_closed is True


def test_stream_sse_maps_request_error_to_network_error(monkeypatch):
    client = OpenAPIClient(_make_config())

    def fake_connect_sse(*args, **kwargs):
        request = httpx.Request("POST", "https://devopenapi.chatiss.com/tongue/create/")
        raise httpx.ConnectError("boom", request=request)

    monkeypatch.setattr("chatiss_open_sdk.core.base.connect_sse", fake_connect_sse)

    with pytest.raises(NetworkError):
        list(client._stream_sse("POST", "/tongue/create/", json_body={}, auth=False))

    client.close()
