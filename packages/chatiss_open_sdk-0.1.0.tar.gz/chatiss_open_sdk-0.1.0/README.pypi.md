﻿# Chatiss Open SDK

Official Python SDK for Chatiss Open Platform.

## Features

- Sync client: `OpenAPIClient`
- Async client: `AsyncOpenAPIClient`
- Automatic JWT token acquisition and refresh
- Structured API response models
- Unified exception model
- SSE stream support for tongue analysis API

## Installation

```bash
pip install chatiss-open-sdk
```

## Quick Start (Sync)

```python
from chatiss_open_sdk import SDKConfig, OpenAPIClient
from chatiss_open_sdk.types import TongueCreateRequest

config = SDKConfig(
    access_key_id="your_access_key_id",
    access_key_secret="your_access_key_secret",
)

with OpenAPIClient(config) as client:
    token_resp = client.get_jwt_token()
    print(token_resp.status)

    req = TongueCreateRequest(
        original_img="https://example.com/original.png",
        skin_img="https://example.com/skin.png",
        gender=1,
        birthday="1990-01-01",
        use_flash=True,
    )
    for event in client.tongue_create(req):
        print(event.event, event.data.status)
```

## Quick Start (Async)

```python
import asyncio
from chatiss_open_sdk import SDKConfig, AsyncOpenAPIClient
from chatiss_open_sdk.types import TongueCreateRequest


async def main():
    config = SDKConfig(
        access_key_id="your_access_key_id",
        access_key_secret="your_access_key_secret",
    )

    async with AsyncOpenAPIClient(config) as client:
        req = TongueCreateRequest(
            original_img="https://example.com/original.png",
            skin_img="https://example.com/skin.png",
            gender=1,
            birthday="1990-01-01",
            use_flash=True,
        )
        async for event in client.tongue_create(req):
            print(event.event, event.data.status)


asyncio.run(main())
```

## Error Handling

- Business failures (`status == "FAIL"`) are returned in `APIResponse`
- Network failures raise `NetworkError`
- Auth failures raise `AuthError`
- Protocol/schema failures raise `ProtocolError`
- SSE interruption raises `SSEStreamError`

## License

MIT
See `LICENSE` for the full text.
