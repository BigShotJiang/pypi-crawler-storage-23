# src/chatiss_open_sdk/core/format_response.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, cast

from .time import parse_iso_z
from ..exceptions import ProtocolError
from ..types import APIStatus, TokenResult, APIResponse, TongueEventResult


@dataclass(frozen=True)
class Envelope:
    status: APIStatus
    code: Optional[int]
    msg: Optional[str]
    result: Any


def parse_envelope(*, method: str, endpoint: str, data: Any) -> Envelope:
    """Parse unified API envelope. FAIL is not an exception; only schema violations raise ProtocolError."""
    if not isinstance(data, dict):
        raise ProtocolError(
            message=f"Invalid response type, expected object(dict) but got {type(data).__name__}",
            method=method,
            endpoint=endpoint,
            body=data,
        )

    status_raw = data.get("status")
    if status_raw not in ("SUCCESS", "FAIL"):
        raise ProtocolError(
            message=f"Invalid status value: {status_raw!r}",
            method=method,
            endpoint=endpoint,
            body=data,
        )
    status = cast(APIStatus, status_raw)

    code_raw = data.get("code")
    if code_raw is None:
        code = None
    else:
        try:
            code = int(code_raw)
        except Exception as e:
            raise ProtocolError(
                message=f"Invalid code type/value: {code_raw!r}",
                method=method,
                endpoint=endpoint,
                body=data,
            ) from e

    msg_raw = data.get("msg")
    msg = str(msg_raw) if msg_raw is not None else None

    return Envelope(status=status, code=code, msg=msg, result=data.get("result"))


def require_dict_result(*, method: str, endpoint: str, env: Envelope) -> dict[str, Any]:
    """On SUCCESS, ensure env.result is a dict."""
    if env.status != "SUCCESS":
        return {}
    if not isinstance(env.result, dict):
        raise ProtocolError(
            message=f"Invalid result type, expected object(dict) but got {type(env.result).__name__}",
            method=method,
            endpoint=endpoint,
            body=env.result,
        )
    return env.result


def format_response_get_jwt_token(*, method: str, endpoint: str, data: Any) -> APIResponse[TokenResult]:
    env = parse_envelope(method=method, endpoint=endpoint, data=data)

    token_result: TokenResult | None = None
    if env.status == "SUCCESS":
        raw = require_dict_result(method=method, endpoint=endpoint, env=env)

        token = raw.get("token")
        expiration = raw.get("expiration")
        if not token or not expiration:
            raise ProtocolError(
                message=f"Missing required fields in result: token/expiration, result={raw!r}",
                method=method,
                endpoint=endpoint,
                body=raw,
            )

        try:
            token_result = TokenResult(
                token=str(token),
                expiration=parse_iso_z(str(expiration)),
            )
        except Exception as e:
            raise ProtocolError(
                message=f"Failed to parse token result: {e}",
                method=method,
                endpoint=endpoint,
                body=raw,
            ) from e

    return APIResponse(
        status=env.status,
        result=token_result,
        code=env.code,
        msg=env.msg,
    )


def format_response_tongue_create(*, method: str, endpoint: str, evt: Any) -> tuple[str, TongueEventResult]:
    event_name = str(evt.get("event", ""))
    raw = evt.get("data")

    if event_name == "done":
        event_result = TongueEventResult(
            status="SUCCESS",
            result={"raw": raw},
            code=None,
            msg=None,
        )
        return event_name, event_result

    env = parse_envelope(method=method, endpoint=endpoint, data=raw)

    event_result = TongueEventResult(
        status=env.status,
        result=env.result,
        code=env.code,
        msg=env.msg,
    )

    return event_name, event_result
