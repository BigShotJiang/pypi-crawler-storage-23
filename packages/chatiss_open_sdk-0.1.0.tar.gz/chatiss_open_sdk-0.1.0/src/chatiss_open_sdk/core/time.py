# src/chatiss_open_sdk/core/time.py
from __future__ import annotations

from datetime import datetime, timezone


def parse_iso_z(dt_str: str) -> datetime:
    s = (dt_str or "").strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)

