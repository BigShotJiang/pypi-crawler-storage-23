# src/chatiss_open_sdk/config.py
from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar


@dataclass(frozen=True)
class SDKConfig:
    access_key_id: str
    access_key_secret: str

    _BASE_URL: ClassVar[str] = "https://openapi.chatiss.com"
    timeout: float = 30.0
    refresh_skew_seconds: int = 60  # token 到期前多少秒刷新

    def validate(self) -> None:
        if not self.access_key_id:
            raise ValueError("access_key_id is required")
        if not self.access_key_secret:
            raise ValueError("access_key_secret is required")

    @property
    def base_url(self) -> str:
        return self._BASE_URL

    @base_url.setter
    def base_url(self, value: str) -> None:
        raise AttributeError("此属性为只读，无法修改。")
