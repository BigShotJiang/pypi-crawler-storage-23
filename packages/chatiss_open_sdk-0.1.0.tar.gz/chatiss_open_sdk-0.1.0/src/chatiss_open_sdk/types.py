# src/chatiss_open_sdk/types.py
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Optional, TypeVar, Literal, Generic

T = TypeVar("T")

APIStatus = Literal["SUCCESS", "FAIL"]


@dataclass
class SuccessResponse(Generic[T]):
    status: Literal["SUCCESS"]
    result: T


@dataclass
class FailResponse:
    status: Literal["FAIL"]
    code: int
    msg: str


@dataclass
class TokenResult:
    token: str
    expiration: datetime


@dataclass
class APIResponse(Generic[T]):
    status: APIStatus
    result: Optional[T] = None
    code: Optional[int] = None
    msg: Optional[str] = None


@dataclass
class TongueCreateRequest:
    original_img: str
    skin_img: str
    gender: int
    birthday: str
    use_flash: bool


@dataclass
class TongueEventResult:
    status: APIStatus
    result: Any = None
    code: Optional[int] = None
    msg: Optional[str] = None


@dataclass
class TongueSSEEvent:
    event: str
    data: TongueEventResult
