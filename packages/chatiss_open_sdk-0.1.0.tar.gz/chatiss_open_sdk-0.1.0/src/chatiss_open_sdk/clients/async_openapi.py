# src/chatiss_open_sdk/clients/async_openapi.py
from __future__ import annotations

from typing import AsyncIterator, Optional, Any

from .common import build_tongue_payload, wrap_stream_error
from ..core.async_base import AsyncBaseClient
from ..core.format_response import format_response_get_jwt_token, format_response_tongue_create
from ..exceptions import SSEStreamError
from ..types import TokenResult, TongueCreateRequest, TongueSSEEvent, APIResponse


class AsyncOpenAPIClient(AsyncBaseClient):
    _AUTH_TOKEN_ENDPOINT = "/auth/token/"
    _TONGUE_CREATE_ENDPOINT = "/tongue/create/"

    async def get_jwt_token(self) -> APIResponse[TokenResult]:
        method = "POST"
        endpoint = self._AUTH_TOKEN_ENDPOINT

        data = await self._request(
            method,
            endpoint,
            json_body={
                "access_key_id": self._config.access_key_id,
                "access_key_secret": self._config.access_key_secret,
            },
            auth=False,
        )
        result = format_response_get_jwt_token(method=method, endpoint=endpoint, data=data)
        return result

    async def tongue_create(self, request: TongueCreateRequest) -> AsyncIterator[TongueSSEEvent]:
        method = "POST"
        endpoint = self._TONGUE_CREATE_ENDPOINT
        payload = build_tongue_payload(request)

        last_event: Optional[str] = None
        last_data: Any = None

        try:
            async for evt in self._stream_sse(method, endpoint, json_body=payload, auth=True):
                last_event = str(evt.get("event", ""))
                last_data = evt.get("data")
                event_name, event_result = format_response_tongue_create(method=method, endpoint=endpoint, evt=evt)
                yield TongueSSEEvent(event=event_name, data=event_result)

        except SSEStreamError:
            raise
        except Exception as e:
            raise wrap_stream_error(
                e,
                method=method,
                endpoint=endpoint,
                last_event=last_event,
                last_data=last_data,
            ) from e
