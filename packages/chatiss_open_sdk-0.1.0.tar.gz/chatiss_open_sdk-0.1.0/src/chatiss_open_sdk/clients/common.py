from __future__ import annotations

from typing import Any, Optional

from ..exceptions import ProtocolError, SSEStreamError
from ..types import TongueCreateRequest


def build_tongue_payload(request: TongueCreateRequest) -> dict[str, Any]:
    return {
        "original_img": request.original_img,
        "skin_img": request.skin_img,
        "gender": request.gender,
        "birthday": request.birthday,
        "use_flash": request.use_flash,
    }


def wrap_stream_error(
    exc: Exception,
    *,
    method: str,
    endpoint: str,
    last_event: Optional[str],
    last_data: Any,
) -> SSEStreamError:
    if isinstance(exc, ProtocolError):
        message = str(exc)
    else:
        message = f"Stream interrupted: {exc}"

    return SSEStreamError(
        message=message,
        method=method,
        endpoint=endpoint,
        last_event=last_event,
        last_data=last_data,
    )
