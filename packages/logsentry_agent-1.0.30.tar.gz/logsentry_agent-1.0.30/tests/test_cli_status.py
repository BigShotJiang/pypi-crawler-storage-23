import sys
from pathlib import Path

import pytest
from logsentry_agent import cli
from logsentry_agent.state import AgentState


def _write_config(path: Path, *, state_path: Path) -> None:
    path.write_text(
        f'''
agent_id: "agent-123"
shared_secret: "secret-123"
endpoint: "http://localhost:8002/v1/ingest"
state_path: "{state_path}"
sources:
  - windows_eventlog
'''.strip(),
        encoding="utf-8",
    )


@pytest.fixture(autouse=True)
def _isolate_env_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    env_path = tmp_path / "logsentry-agent.env"
    env_path.write_text("", encoding="utf-8")
    monkeypatch.setenv("LOGSENTRY_ENV_FILE", str(env_path))
    monkeypatch.delenv("LOGSENTRY_AGENT_ID", raising=False)
    monkeypatch.delenv("LOGSENTRY_AGENT_SECRET", raising=False)
    monkeypatch.delenv("LOGSENTRY_AGENT_SECRET_FILE", raising=False)
    monkeypatch.delenv("LOGSENTRY_ENDPOINT", raising=False)


def test_status_includes_state_json_details(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
):
    config_path = tmp_path / "agent.yml"
    state_path = tmp_path / "state.json"
    _write_config(config_path, state_path=state_path)

    state = AgentState(path=state_path)
    state.audit.update(
        {
            "last_endpoint": "https://collector.example/v1/ingest",
            "last_agent_version": "1.2.3",
            "last_config_hash": "abc123",
        }
    )
    state.update_stats(
        "agent",
        {
            "uptime_seconds": 12,
            "last_send_status": "ok",
            "spool_depth": 1,
            "last_successful_send": "2099-01-01T00:00:00+00:00",
        },
    )
    state.update_stats("windows_eventlog", {"last_poll": "2099-01-01T00:00:00+00:00"})
    state.update_checkpoint("Security", 456, "2099-01-01T00:00:00+00:00")
    state.save()

    monkeypatch.setattr(
        sys,
        "argv",
        ["logsentry-agent", "--config", str(config_path), "status"],
    )

    with pytest.raises(SystemExit) as exc:
        cli.main()

    assert exc.value.code == 0
    output = capsys.readouterr().out
    assert f"State path: {state_path}" in output
    assert "State corrupted: false" in output
    assert "Envelope sequence: 0" in output
    assert "Last agent version: 1.2.3" in output
    assert "Last config hash: abc123" in output
    assert "Checkpoint count: 1" in output
    assert "Checkpoint Security: record=456, timestamp=2099-01-01T00:00:00+00:00" in output
    assert "Sources in state: windows_eventlog" in output
