from __future__ import annotations

import random
import string
from pathlib import Path

from logsentry_agent.collectors.apache import parse_line as parse_apache
from logsentry_agent.collectors.docker import parse_line as parse_docker
from logsentry_agent.collectors.nginx import parse_line as parse_nginx
from logsentry_agent.collectors.ssh import parse_line as parse_ssh

FIXTURES = Path(__file__).parent / "fixtures"


def _random_line(length: int) -> str:
    alphabet = string.ascii_letters + string.digits + "-_/[]{}:;,." * 2
    return "".join(random.choice(alphabet) for _ in range(length))


def test_parsers_handle_random_input():
    random.seed(42)
    for _ in range(250):
        line = _random_line(512)

        nginx = parse_nginx(line)
        assert nginx is None or isinstance(nginx, dict)

        apache = parse_apache(line)
        assert apache is None or isinstance(apache, dict)

        ssh = parse_ssh(line)
        assert ssh is None or isinstance(ssh, dict)

        docker = parse_docker(line, container="fuzz")
        assert docker is None or isinstance(docker, (dict, list))


def test_nginx_long_path_fixture():
    weird_lines = (
        (FIXTURES / "nginx" / "weird_lines.input.log").read_text(encoding="utf-8").splitlines()
    )
    long_line = max(weird_lines, key=len)
    parsed = parse_nginx(long_line)
    assert parsed is None or isinstance(parsed, dict)
