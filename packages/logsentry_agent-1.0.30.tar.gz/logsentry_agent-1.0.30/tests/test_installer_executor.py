import grp
import os
import pwd
from pathlib import Path

from logsentry_agent.installer.install import ActionExecutor


def _current_owner_group() -> tuple[str, str]:
    return pwd.getpwuid(os.getuid()).pw_name, grp.getgrgid(os.getgid()).gr_name


def test_executor_write_file_force_creates_backup(tmp_path: Path):
    target = tmp_path / "example.txt"
    target.write_text("old", encoding="utf-8")

    owner, group = _current_owner_group()
    executor = ActionExecutor(dry_run=False)
    executor.write_file(target, "new", owner=owner, group=group, mode=0o644, force=True)

    assert target.read_text(encoding="utf-8") == "new"
    backups = list(tmp_path.glob("example.txt.bak-*"))
    assert len(backups) == 1


def test_executor_dry_run_does_not_mutate_files(tmp_path: Path):
    target = tmp_path / "dryrun.txt"

    owner, group = _current_owner_group()
    executor = ActionExecutor(dry_run=True)
    executor.write_file(target, "new", owner=owner, group=group, mode=0o640, force=True)

    assert not target.exists()
    assert any("write file" in change for change in executor.changes)
