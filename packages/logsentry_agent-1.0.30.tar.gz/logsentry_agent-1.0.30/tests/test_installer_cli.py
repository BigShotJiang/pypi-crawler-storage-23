import sys

import pytest
from logsentry_agent import cli


def _run_help(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    *args: str,
) -> str:
    monkeypatch.setattr(sys, "argv", ["logsentry-agent", *args, "--help"])

    with pytest.raises(SystemExit) as exc:
        cli.main()

    assert exc.value.code == 0
    return capsys.readouterr().out


def test_root_help_lists_global_options_and_subcommands(
    monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
):
    output = _run_help(monkeypatch, capsys)

    for option in ["--config", "--version"]:
        assert option in output

    for command in [
        "test-send",
        "send-health",
        "drain-spool",
        "run",
        "doctor",
        "identity",
        "status",
        "install",
        "uninstall",
    ]:
        assert command in output


@pytest.mark.parametrize(
    ("command", "expected_options"),
    [
        ("test-send", ["--counter-check"]),
        ("send-health", []),
        ("drain-spool", ["--percent", "--clear-spool"]),
        ("run", ["--once", "--debug", "--print-identity"]),
        ("doctor", ["--counter-check"]),
        ("identity", []),
        ("status", []),
        (
            "install",
            [
                "--agent-id",
                "--agent-secret",
                "--endpoint",
                "--config-path",
                "--env-path",
                "--state-dir",
                "--venv-dir",
                "--service-name",
                "--user",
                "--group",
                "--enable",
                "--no-enable",
                "--start",
                "--no-start",
                "--test-send",
                "--no-test-send",
                "--force",
                "--dry-run",
                "--log-access",
                "--add-group",
                "--source",
                "--file-path",
            ],
        ),
        (
            "uninstall",
            [
                "--config-path",
                "--env-path",
                "--state-dir",
                "--venv-dir",
                "--service-name",
                "--user",
                "--group",
                "--keep-data",
                "--keep-config",
                "--remove-user",
                "--dry-run",
            ],
        ),
    ],
)
def test_subcommand_help_lists_all_parameters(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    command: str,
    expected_options: list[str],
):
    output = _run_help(monkeypatch, capsys, command)

    for option in expected_options:
        assert option in output
