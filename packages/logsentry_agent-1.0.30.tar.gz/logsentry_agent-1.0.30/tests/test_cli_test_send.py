from argparse import Namespace
from pathlib import Path

from logsentry_agent.cli import cmd_test_send
from logsentry_agent.http import SendResult


class FakeResponse:
    def __init__(self, status_code: int, text: str = "", headers: dict[str, str] | None = None):
        self.status_code = status_code
        self.text = text
        self.headers = headers or {}

    def json(self):
        import json

        if not self.text:
            raise ValueError("No JSON body")
        return json.loads(self.text)


def _write_config(path: Path, spool_path: Path, state_path: Path) -> None:
    path.write_text(
        (
            'agent_id: "agent"\n'
            'shared_secret: "secret"\n'
            'endpoint: "http://localhost:8002/v1/ingest"\n'
            f'spool_path: "{spool_path}"\n'
            f'state_path: "{state_path}"\n'
        ),
        encoding="utf-8",
    )


def test_test_send_reports_auth_failure_detail(monkeypatch, tmp_path: Path, capsys):
    config_path = tmp_path / "agent.yml"
    _write_config(config_path, tmp_path / "spool.db", tmp_path / "state.json")

    def fake_send_payload(**kwargs):  # noqa: ANN003, ANN001
        return SendResult(
            status="fatal",
            response=FakeResponse(403, text="invalid agent signature"),
            auth_failed=True,
            error="invalid agent signature",
            status_code=403,
        )

    monkeypatch.setattr("logsentry_agent.cli.send_payload", fake_send_payload)

    rc = cmd_test_send(Namespace(config=config_path, command="test-send", counter_check=False))
    output = capsys.readouterr().out

    assert rc == 1
    assert "authentication failed; check agent_id/shared_secret" in output
    assert "invalid agent signature" in output


def test_test_send_reports_network_error(monkeypatch, tmp_path: Path, capsys):
    config_path = tmp_path / "agent.yml"
    _write_config(config_path, tmp_path / "spool.db", tmp_path / "state.json")

    def fake_send_payload(**kwargs):  # noqa: ANN003, ANN001
        return SendResult(status="retry", error="Connection refused")

    monkeypatch.setattr("logsentry_agent.cli.send_payload", fake_send_payload)

    rc = cmd_test_send(Namespace(config=config_path, command="test-send", counter_check=True))
    output = capsys.readouterr().out

    assert rc == 1
    assert "Counter check — no backend response received." in output
    assert "Backend rejected (error: Connection refused); event spooled." in output


def test_test_send_404_includes_endpoint_hint(monkeypatch, tmp_path: Path, capsys):
    config_path = tmp_path / "agent.yml"
    _write_config(config_path, tmp_path / "spool.db", tmp_path / "state.json")

    def fake_send_payload(**kwargs):  # noqa: ANN003, ANN001
        return SendResult(status="fatal", response=FakeResponse(404), status_code=404)

    monkeypatch.setattr("logsentry_agent.cli.send_payload", fake_send_payload)

    rc = cmd_test_send(Namespace(config=config_path, command="test-send", counter_check=True))
    output = capsys.readouterr().out

    assert rc == 1
    assert "Counter check — backend did not return X-Resolved-Agent-Id header (HTTP 404)." in output
    assert "Verify endpoint path (expected /v1/ingest)." in output
