from pathlib import Path

from logsentry_agent.config import load_config


def test_nullable_source_lists_do_not_crash(tmp_path: Path):
    config_path = tmp_path / "agent.yml"
    config_path.write_text(
        """
agent_id: "agent"
shared_secret: "secret"
endpoint: "http://localhost:8002/v1/ingest"
windows_eventlog:
  event_id_allow:
  provider_allow:
nginx:
  error_log_paths:
apache:
  error_log_paths:
ssh:
  auth_log_paths:
docker:
  paths:
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_path)

    assert config.windows_eventlog is not None
    assert config.windows_eventlog.event_id_allow == []
    assert config.windows_eventlog.provider_allow == []
    assert config.nginx is not None
    assert config.nginx.error_log_paths == []
    assert config.apache is not None
    assert config.apache.error_log_paths == []
    assert config.ssh is not None
    assert len(config.ssh.auth_log_paths) > 0
    assert config.docker is not None
    assert config.docker.paths == []
