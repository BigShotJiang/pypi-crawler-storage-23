from pathlib import Path

from logsentry_agent.config import load_config


def test_env_file_is_loaded_for_env_expansion(monkeypatch, tmp_path: Path):
    env_path = tmp_path / "logsentry-agent.env"
    env_path.write_text(
        "LOGSENTRY_AGENT_ID=env-file-id\n"
        "LOGSENTRY_AGENT_SECRET=env-file-secret\n"
        "LOGSENTRY_ENDPOINT=https://example.com/v1/ingest\n",
        encoding="utf-8",
    )
    monkeypatch.setenv("LOGSENTRY_ENV_FILE", str(env_path))
    config_path = tmp_path / "agent.yml"
    config_path.write_text(
        """
agent_id: "${LOGSENTRY_AGENT_ID}"
shared_secret: "${LOGSENTRY_AGENT_SECRET}"
endpoint: "${LOGSENTRY_ENDPOINT}"
""".strip(),
        encoding="utf-8",
    )

    config = load_config(config_path)

    assert config.agent_id == "env-file-id"
    assert config.shared_secret == "env-file-secret"
    assert config.endpoint == "https://example.com/v1/ingest"
