from __future__ import annotations

from pathlib import Path

from .templates import render_systemd_unit


def write_systemd_unit(
    *,
    executor,
    service_name: str,
    service_path: Path,
    user: str,
    group: str,
    env_path: Path,
    config_path: Path,
    venv_dir: Path,
    working_dir: Path,
    force: bool,
) -> None:
    content = render_systemd_unit(
        service_name=service_name,
        user=user,
        group=group,
        env_path=env_path,
        config_path=config_path,
        venv_dir=venv_dir,
        working_dir=working_dir,
    )
    executor.write_file(
        service_path,
        content,
        owner="root",
        group="root",
        mode=0o644,
        force=force,
    )
