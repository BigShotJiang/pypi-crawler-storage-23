"""The main package."""

from importlib import metadata

__project__ = "Venver"
__distribution__ = "venver"
__version__ = metadata.version("venver")
__authors__ = ["Narvin Singh"]
