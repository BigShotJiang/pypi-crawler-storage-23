"""Web GUI for DaMiao motors."""

from . import web_gui

__all__ = ["web_gui"]
