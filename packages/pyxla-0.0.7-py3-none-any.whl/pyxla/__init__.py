"""The core functions of the library are defined here."""

import matplotlib.axes
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import statistics
import scipy
from scipy.stats import spearmanr
from scipy.spatial.distance import pdist
from typing import Tuple
import matplotlib
import math
from typing import Callable, Union, List, Iterable, Any, Literal
from tqdm.auto import tqdm
import logging
import itertools
from sklearn.linear_model import Ridge, LassoLars, Lars, Lasso
from sklearn.model_selection import train_test_split
from sklearn.inspection import permutation_importance

from . import util

logging.basicConfig(level=logging.INFO)

# allow importing `load_data` immediately from `pyxla`
from .util import load_data

# definition of the sample structure
# (the data files should include the global optima if known)
sample = {
    "name": None,
    "size": 0,
    # variable space
    "X": None,  # dataframe
    #'Xd':   0,      # int
    "Xcsv": None,  # str
    # objective space
    "F": None,
    #'Fd':   0,
    "Fcsv": None,
    "numF": 0,
    "max": False,  # we minimize by default
    # violation space
    "V": None,
    #'Vd':   0,
    "Vcsv": None,
    "numV": 0,
    # neighborhood
    "N": None,
    "Ncsv": None,
    # distance
    "D": None,
    "Dcsv": None,
    "representation": "continuous",  # by default
    "d_metric_func": None,  # distance metric function of the form dist(X1, X2) -> d
    "neighbourhood_func": None,  # of the form f(X1, X2) -> bool
    "p": 2,  # Euclidean distance by default
}


def descriptive_stats(data, name):
    result = dict()
    result[str(name + "_min")] = min(data)
    result[str(name + "_max")] = max(data)
    result[str(name + "_mean")] = statistics.mean(data)
    result[str(name + "_med")] = statistics.median(data)
    result[str(name + "_q1")] = statistics.quantiles(data, n=4)[0]
    result[str(name + "_q3")] = statistics.quantiles(data, n=4)[2]
    result[str(name + "_sd")] = statistics.stdev(data)
    result[str(name + "_skew")] = scipy.stats.skew(data).item()
    result[str(name + "_kurt")] = scipy.stats.kurtosis(data).item()
    return result


def distr_f(sample: dict, bins: int = "auto") -> Tuple[dict, matplotlib.figure.Figure]:
    """Computes the distribution of objectives (fitness values).

    The ``distr_f`` feature visualises the spread of objective values and computes
    some descriptive statistics of the objective values. Alongside a histogram of
    objective values and a histogram of their dense ranking, various descriptive statistics
    are computed, including: minimum, maximum, mean, median, quartiles (Q1, Q3),
    standard deviation, skewness, and kurtosis. Dense ranking is a ranking method
    provided by the `pandas <https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.rank.html#pandas-dataframe-rank>`__ package, which entails
    assigning to a group of equally valued solutions the least rank in the group
    and ensuring that rank increases by 1 from group to group.


    Parameters
    ----------
    sample : dict
        A sample containing the various input files i.e ``F``, ``V``.

    Returns
    -------
    dict
        Descriptive statistics of objective values.
    matplotlib.figure.Figure
        Histograms of objective values and or ranks of objective values.

    Examples
    --------
    >>> from pyxla import util, distr_f
    >>> import matplotlib
    >>> sample = util.load_sample('ackley8d_F1_V0', test=True)
    >>> feat, plot = distr_f(sample)
    >>> type(feat)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """

    F = sample["F"]
    numF = sample["numF"]
    R = pd.DataFrame()

    for col in F:
        R[f"{col}_rank"] = (
            F[col].rank(ascending=not sample["max"], method="min").astype(int)
        )

    feat = dict()
    for i in range(0, len(F.columns)):
        feat.update(descriptive_stats(F.iloc[:, i], F.columns[i]))
        feat.update(descriptive_stats(R.iloc[:, i], R.columns[i]))

    # plots
    ncols = numF + (numF > 1)
    nrows = 2
    fig, axs = plt.subplots(ncols=ncols, nrows=nrows, figsize=(3 * ncols, 3 * nrows))
    palette = sns.color_palette()[-numF:]  # pick last n colors in palette

    ax = lambda i, j: axs[i, j] if numF > 1 else axs[i]
    for i, col in enumerate(F):
        sns.histplot(F[col], ax=ax(0, i), color=palette[i], bins=bins)
        sns.histplot(R[f"{col}_rank"], ax=ax(1, i), color=palette[i])

    # blend plots
    if numF > 1:
        sns.histplot(F, ax=ax(0, numF), palette=palette)
        sns.histplot(R, ax=ax(1, numF), palette=palette)

    fig.suptitle("Distribution of objective values/ranks")
    plt.tight_layout()

    return feat, fig


def distr_v(sample: dict) -> Tuple[dict, matplotlib.figure.Figure]:
    """Computes the distribution of violation values.

    The ``distr_v`` feature visualises the spread of violation values and
    computes some descriptive statistics of the violation values.
    Alongside a histogram of violation values and a histogram of their
    `dense ranking <https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.rank.html#pandas-dataframe-rank>`__, descriptive statistics are computed, including:
    minimum, maximum, mean, median, quartiles (Q1, Q3), standard deviation,
    skewness, and kurtosis. Additionally, the feasibility rate is computed
    per violation, and the overall feasibility, taking all constraints into
    account, is computed. Feasibility rate refers to the proportion of solutions
    that are feasible with respect to a constraint.

    Parameters
    ----------
    sample : dict
        A sample containing the various input files i.e ``F``, ``V``.

    Returns
    -------
    dict
        Descriptive statistics of violation values.
    matplotlib.figure.Figure
        Histograms of violation values and ranks of violation values.
    
    Examples
    --------
    >>> from pyxla import util, distr_v
    >>> import matplotlib
    >>> sample = util.load_sample('cec2010_c01_2d_F1_V2', test=True)
    >>> feat, plot = distr_v(sample)
    >>> type(feat)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """
    V = sample["V"]
    if V is None:
        raise ValueError("V is absent in the sample. Please provide input V first.")

    V_ = V.drop("feasible", axis=1)
    numV = sample["numV"]

    R = pd.DataFrame()

    for col in V_:
        R[f"{col}_rank"] = V[col].rank(ascending=True, method="min").astype(int)

    # features
    feat = dict()
    # exclude column 'feasible'
    for i, col in enumerate(V_):
        feat.update(descriptive_stats(V.iloc[:, i], col))
        # feasibility rate per constraint
        feat[f"{col}_feas_rate"] = (V.iloc[:, i] == 0).mean().item()
    feat[f"overall_feas_rate"] = V["feasible"].mean().item()

    # plots
    ncols = numV + (numV > 1)
    nrows = 2
    fig, axs = plt.subplots(ncols=ncols, nrows=nrows, figsize=(3 * ncols, 3 * nrows))
    palette = sns.color_palette()[-numV:]  # pick last n colors in palette

    ax = lambda i, j: axs[i, j] if numV > 1 else axs[i]

    for i, col in enumerate(V_):
        sns.histplot(V[col], ax=ax(0, i), color=palette[i])
        sns.histplot(R[f"{col}_rank"], ax=ax(1, i), color=palette[i])

    # blend plots
    if numV > 1:
        sns.histplot(V_, ax=ax(0, numV), palette=palette)
        sns.histplot(R, ax=ax(1, numV), palette=palette)

    fig.suptitle("Distribution of violation values/ranks")
    plt.tight_layout()

    return feat, fig


def distr_Par(sample: dict) -> Tuple[dict, matplotlib.figure.Figure]:
    """Computes distribution of Pareto ranks.

    The ``distr_Par`` feature produces a histogram of Pareto ranks and
    descriptive statistics on the ranks. This feature is applicable when
    there are at least two objectives or at least one constraint.
    Constraints are treated as objectives to be minimised in the Pareto
    ranking. The `moocore <https://multi-objective.github.io/moocore/r/>`__
    package was used to compute Pareto rankings.
    Pareto ranking assigns ranks to solutions based on Pareto dominance.
    The solutions that are not dominated by any other solution are assigned
    rank 0. Ranking proceeds by excluding the first Pareto front and
    determining the next Pareto front, whose solutions will be given the
    next best rank. This proceeds till all the solutions have been ranked.

    Parameters
    ----------
    sample : dict
        A sample containing the various input files i.e ``F``, ``V``

    Returns
    -------
    dict
        Descriptive statistics of Pareto ranks
    matplotlib.figure.Figure
        Histogram(s) of Pareto ranks

    Raises
    ------
    Exception
        Raises an exception if a Pareto rank is not possible for the provided
        sample. The sample must have at least two objectives or at least one
        objective and constraint.
    
    Examples
    --------
    >>> from pyxla import util, distr_Par
    >>> import matplotlib
    >>> sample = util.load_sample('cec2010_c01_2d_F1_V2', test=True)
    >>> feat, plot = distr_Par(sample)
    >>> type(feat)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """

    Par = sample["R"].filter(like="pareto")
    numPar = len(Par.columns)
    if not numPar:
        raise Exception("Pareto rank is not possible for this sample.")

    feat = dict()

    for i in range(0, numPar):
        feat.update(descriptive_stats(Par.iloc[:, i], Par.columns[i]))

    # plots
    ncols = numPar
    fig, axs = plt.subplots(ncols=ncols, figsize=(3 * ncols, 3))
    palette = sns.color_palette()[-numPar:]  # pick last n colors in palette

    ax = lambda i: axs[i] if numPar > 1 else axs

    for i, col in enumerate(Par):
        sns.histplot(Par[col], ax=ax(i), color=palette[i])

    fig.suptitle("Distribution of Pareto ranks")
    plt.tight_layout()

    return feat, fig


def distr_Deb(sample: dict) -> Tuple[dict, sns.axisgrid.FacetGrid]:
    """Computes Deb's Feasibility Rule Ranking Distribution.

    Solutions were ranked following Deb's feasibility rule ranking
    where solutions are ranked based on three criteria: (1) feasible
    solutions are ranked as better than infeasible solutions, (2) among
    two feasible solutions, the one with a better objective value is
    ranked better, and (3) among infeasible solutions, solutions with
    lower violation values are ranked better :cite:p:`deb2000efficient`. This was implemented by
    summing up scaled objective ranks with violation ranks and ranking
    solutions based on the result of summation using dense ranking. The
    objective ranks are scaled to the range [0, 1] by dividing each rank
    by the maximum rank plus 1, resulting in a real value below 1. Thus,
    for each solution, the violation ranks with respect to each violation
    and the scaled objective rank are summed. Additionally, descriptive
    statistics for the computed ranks are calculated.

    Parameters
    ----------
    sample : dict
        A sample containing the various input files i.e ``F``, ``V``

    Returns
    -------
    dict
        Descriptive statistics of Pareto ranks
    sns.axisgrid.FacetGrid
        Histogram of Deb's feasibility rule ranks
    
    Examples
    --------
    >>> from pyxla import util, distr_Deb
    >>> import seaborn
    >>> sample = util.load_sample('cec2010_c01_2d_F1_V2', test=True)
    >>> feat, plot = distr_Deb(sample)
    >>> type(feat)
    <class 'dict'>
    >>> isinstance(plot, seaborn.axisgrid.FacetGrid)
    True
    """

    if "Deb" not in sample["R"]:
        raise Exception(
            "Deb's feasibility rule ranking is not possible for this sample."
        )
    deb_ranks = sample["R"]["Deb"]
    plot = sns.displot(deb_ranks)
    plot.set(title=f"Deb's feasibility rule ranking distribution {sample['name']}")
    feat = dict()
    feat.update(descriptive_stats(deb_ranks, "Deb"))

    return feat, plot


def annotate_with_corr_coefs_(
    x: Any, y: Any, label: str = None, color: str = None, **kwargs
) -> None:
    """Annotates a pair grid with correlation coefficient values.

    This is a helper functions that helps to annotate a pair grid plot
    with correlation coefficient values.

    Parameters
    ----------
    x : Any
        Array like
    y : Any
        Array like
    label : str, optional
        Label for each subplot, by default None
    color : str, optional
        color for each series, by default None
    """
    ax = plt.gca()
    cor, _ = spearmanr(x, y)
    cor = "undefined" if math.isnan(cor) else f"{cor:.2f}"
    # if sample has V file
    if label != None:
        feasibility = "feasible" if label else "infeasible"
        kwargs["feat"].update({f"{x.name}_{y.name} ({feasibility})": cor})
        pos = (0.5, 0.5) if label else (0.5, 0.25)
        ax.annotate(
            f"corr = {cor} ({feasibility})",
            xy=pos,
            xycoords="axes fraction",
            ha="center",
            color=color,
        )
    # else if no V file
    else:
        kwargs["feat"].update({f"{x.name}_{y.name}": cor})
        pos = (0.5, 0.5)
        ax.annotate(
            f"corr = {cor}", xy=pos, xycoords="axes fraction", ha="center", color=color
        )
    ax.set_axis_off()


def corr(sample: dict) -> Tuple[dict, sns.PairGrid]:
    """Computes correlation of values.

    This feature creates a scatter plot for all pair combinations of objectives and violations. For each pair, the Spearman's correlation coefficient is calculated. Concretely, for a problem with one objective and two constraints, this feature creates a scatter plot of the objective values against violation values of the first constraint, another scatter plot of objective values against violation values of the second constraint, and finally a scatter plot of violation values of the first constraint against those of the second constraint. For each of these scatter plots the Spearman's correlation is calculated as numerical output. Further, the scatter plots and correlation calculations are split by feasibility. Correlations involving feasible solutions are undefined, as all violation values are zero.

    Parameters
    ----------
    sample : dict
        A sample containing the various input files i.e ``F``, ``V``.

    Returns
    -------
    dict
        Spearman's correlation coefficients for all pairs of sets of
        values split by feasibility
    sns.PairGrid
        Grid of scatter plots of all objectives and violations against
        each other, with feasibility indicated per solution.

    Examples
    --------
    >>> from pyxla import util, corr
    >>> import seaborn
    >>> sample = util.load_sample('cec2010_c01_2d_F1_V2', test=True)
    >>> feat, plot = corr(sample)
    >>> type(feat)
    <class 'dict'>
    >>> isinstance(plot, seaborn.PairGrid)
    True
    """
    if util.present(sample, "V"):
        FV = pd.merge(sample["F"], sample["V"], left_index=True, right_index=True)
        g = sns.PairGrid(FV, hue="feasible", hue_order=[True, False])
    else:
        FV = sample["F"]
        if sample["numF"] == 1:
            logging.warning(
                "The sample has a single objective with no constraint, therefore this feature is meaningless."
            )
        g = sns.PairGrid(FV)
    # diagonal
    g.map_diag(sns.histplot)
    # lower triangle
    g.map_lower(sns.scatterplot, alpha=0.5)
    g.map_lower(sns.regplot, scatter=False)
    # upper triangle
    feat = {}
    g.map_upper(annotate_with_corr_coefs_, feat=feat)
    # legend
    g.add_legend()
    violation_txt = " and violations" if util.present(sample, "V") else ""
    g.figure.suptitle(f"Correlation of objectives{violation_txt}")
    return feat, g


def corr_ranks(sample: dict) -> Tuple[dict, sns.PairGrid]:
    """Computes correlation of ranks.

    This feature creates scatter plots and calculates Spearman's correlation values for all pairs of ranks objectives and violations, Pareto ranks, and Deb's ranks. For instance, violation ranks can be plotted against objective ranks. Similarly, the scatter plots and correlation calculations are split by feasibility. Correlation involving feasible solutions may be undefined since these solutions tend to have the same violation value ranks and Pareto ranks involving constraints, hence such sets have zero standard deviation. Consequently, for feasible solutions, Spearman's correlation coefficient is undefined.

    Parameters
    ----------
    sample : dict
        A sample containing the various input files i.e ``F``, ``V``

    Returns
    -------
    sns.PairGrid
        Grid of scatter plots of all objective, violation, Pareto and Deb's
        ranks against each other, with feasibility indicated per solution
    dict
        Spearman's correlation coefficients for all pairs of sets of ranks
        split by feasibility

    Examples
    --------
    >>> from pyxla import util, corr_ranks
    >>> import seaborn
    >>> sample = util.load_sample('cec2010_c01_2d_F1_V2', test=True)
    >>> feat, plot = corr_ranks(sample)
    >>> type(feat)
    <class 'dict'>
    >>> isinstance(plot, seaborn.PairGrid)
    True
    """

    if util.present(sample, "V"):
        g = sns.PairGrid(sample["R"], hue="feasible", hue_order=[True, False])
    else:
        g = sns.PairGrid(sample["R"])
        if sample["numF"] == 1:
            logging.warning(
                "The sample has a single objective with no constraint, therefore this feature is meaningless."
            )

    g.map_diag(sns.histplot)
    # diagonal
    g.map_diag(sns.histplot)
    # lower triangle
    g.map_lower(sns.scatterplot, alpha=0.5)
    g.map_lower(sns.regplot, scatter=False)
    # upper triangle
    feat = {}
    g.map_upper(annotate_with_corr_coefs_, feat=feat)
    # legend
    g.add_legend()
    g.figure.suptitle("Correlation of ranks")
    g.figure.tight_layout()
    return feat, g


def pw_dist_(sample: dict, id_a: int, id_b: int, metric=None) -> float:
    """Calculates the distance between 2 solutions given their indices.

    Parameters
    ----------
    sample : dict
        A sample containing the various input files i.e ``F``, ``V``.
    id_a : int
        Index of solution `a`
    id_b : int
        Index of solution `b`

    Returns
    -------
    float
        Distance between solution `a` and `b` as a float
    """

    if id_a == id_b:
        return 0
    else:
        d = None
        D = sample["D"]
        # check if D file is provided
        if isinstance(D, pd.DataFrame):
            if id_a < id_b:
                d = D.loc[(id_a, id_b), "d"]
            else:
                d = D.loc[(id_b, id_a), "d"]
        # if D not provided calculate d's
        else:
            # if no metric specific use default metrics
            if not metric:
                metric = (
                    "euclidean"
                    if sample["representation"] == "continuous"
                    else "hamming"
                )

            if "X" not in sample:
                raise ValueError("Please provide either an X input file.")
            X = sample["X"]
            a = X.iloc[id_a].to_numpy()
            b = X.iloc[id_b].to_numpy()
            d = pdist([a, b], metric=metric)
        return d


def fdc(
    sample: dict, compute_D_file: bool = True
) -> Tuple[dict, matplotlib.figure.Figure]:
    """Computes objective (fitness) distance correlation (``FDC``).

    This feature is an implementation of the method proposed by Jones and Forrest :cite:p:`jones1995fitness`. For each set of objective values :math:`F_i`, a pair :math:`(f_i, d_i)` is generated for each solution, where :math:`f_i` is the fitness of solution :math:`i`, and :math:`d_i \\in D_i` is the distance between solution :math:`i` and the nearest best solution. This feature produces, as visual output, a scatter plot of fitness (:math:`F_i`) against distance (:math:`D_i`) and calculates Spearman's correlation coefficient between :math:`F_i` and :math:`D_i` as the corresponding numerical output for each objective for feasible and infeasible solutions separately.

    Parameters
    ----------
    sample : dict
        A sample containing the various input files i.e ```F```, ```V```.
    compute_D_file : bool, optional
        By default ```True```; when there is no D file in the sample, if
        ```compute_D_file``` is set to ```True```, the whole D file is
        calculated. Calculating the whole D file will eliminate redundant
        distance calculations in the future, but it can be time consuming.
        To speed up calculation of ``fdc``, set ```compute_D_file``` to
        ```False``` so that only the required distances are calculated.

    Returns
    -------
    dict
        Dictionary containing Spearman's correlation coefficients
        objective-distance correlation per objective.
    matplotlib.figure.Figure
        ``matplotlib`` axes containing scatter plots of objective
        values against distance to the nearest best solution in
        sample per objective, for all solutions or for feasible
        solutions only.

    Raises
    ------
    Exception
        Raises an exception if both D and X inputs are absent. One of D
        or X is needed to compute distances between solution.
    
    Examples
    --------
    >>> from pyxla import util, fdc
    >>> import matplotlib
    >>> sample = util.load_sample('sphere', test=True)
    >>> feat, plot = fdc(sample)
    >>> type(feat)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """

    util.handle_missing_D_file(sample, compute_D_file)

    sample["FDC"] = pd.DataFrame()
    FDC = sample["FDC"]
    F = sample["F"]
    R = sample["R"]
    corr = {}

    fig, axs = plt.subplots(ncols=len(F.columns), figsize=(5 * len(F.columns), 5))
    for i, col in enumerate(F.columns):
        FDC[col] = F[col]
        FDC["distance"] = 0.0
        # pick F with rank 1,
        bestF = R.query(f"{col} == 1")
        # for rank 1 solution set distance to 0
        FDC.loc[bestF.index, "distance"] = 0.0
        # compute distance only for non-rank-1 solutions
        for t_idx in FDC[~FDC.index.isin(bestF.index)].index:
            d_nearest_best_f = pw_dist_(sample, t_idx, bestF.index[0])
            # check for the nearest among all bestFs
            for b_idx in bestF[1:].index:
                d = pw_dist_(sample, t_idx, b_idx)
                if d < d_nearest_best_f:
                    d_nearest_best_f = d
            FDC.loc[t_idx, "distance"] = d_nearest_best_f

        r, _ = scipy.stats.spearmanr(FDC[col], FDC["distance"])
        corr.update({f"fdc_{col}": r})

        ax = axs[i] if len(F.columns) > 1 else axs
        sns.scatterplot(data=FDC, x="distance", y=col, ax=ax)
        sns.regplot(data=FDC, x="distance", y=col, ax=ax, scatter=False)
        ax.set_title(f"FDC (corr = {r:.2f})")

    fig.tight_layout()

    return corr, fig


def vdc(
    sample: dict, compute_D_file: bool = True
) -> Tuple[dict, matplotlib.figure.Figure]:
    """Calculates violation distance correlation (``VDC``).

    This feature was implemented by extending the objective-distance correlation feature (:func:`pyxla.fdc`) to violation values. For each set of violation values :math:`V_i` and for infeasible solutions only, a pair :math:`(v_i, d_i)` is generated where :math:`v_i` is the violation value of solution :math:`i`, and :math:`d_i \\in D_i` is the distance between solution :math:`i` and the nearest feasible solution. This feature produces, as visual output, a scatter plot of violation (:math:`V_i`) against distance (:math:`D_i`) and calculates Spearman's correlation coefficient between :math:`V_i` and :math:`D_i` as the corresponding numerical output for each constraint. This feature is only applicable to constrained problems. The feature is applied to infeasible solutions only because all feasible solutions have a violation value of zero.

    Parameters
    ----------
    sample : dict
        A sample containing the at least input files V and D.
    compute_D_file : bool, optional
        By default ``True``; when there is no D file in the sample, if
        ``compute_D_file`` is set to ``True``, the whole D file is
        calculated. Calculating the whole D file will eliminate redundant
        distance calculations in the future, but it can be time consuming.
        To speed up calculation of `fdc`, set ``compute_D_file`` to
        ``False`` so that only the required distances are calculated.

    Returns
    -------
    dict
        Dictionary containing correlation between constraints and
        distance to the nearest feasible solution.
    matplotlib.figure.Figure
        ```matplotlib``` axes containing a scatter plot of violation
        values against distance to the nearest feasible solution.

    Examples
    --------
    >>> from pyxla import util, vdc
    >>> import matplotlib
    >>> sample = util.load_sample('cec2010_c01_2d_F1_V2', test=True)
    >>> corr, plot = vdc(sample)
    >>> type(corr)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """
    if not util.present(sample, "V"):
        raise Exception("V is required. Please provide V.")

    util.handle_missing_D_file(sample, compute_D_file)

    V = sample["V"]

    if V[V["feasible"] == True].empty:
        raise Exception("VDC is undefined as there is no feasible solution.")

    corr = {}
    fig, axs = plt.subplots(
        ncols=len(V.columns[:-1]), figsize=(5 * len(V.columns[:-1]), 5)
    )

    for i, col in tqdm(
        enumerate(V.columns[:-1]), total=sample["numV"]
    ):  # exclude col 'feasible'
        sample[f"VDC_{col}"] = pd.DataFrame()
        VDC = sample[f"VDC_{col}"]
        # separate feasible and infeasible solutions.
        feas_v, infeas_v = V.query(f"{col} == 0"), V.query(f"{col} != 0")

        VDC[col] = infeas_v[col]
        # for each infeasible solution:
        for infeas_idx in infeas_v.index:
            d_nearest_feas = pw_dist_(sample, infeas_idx, feas_v.index[0])
            # compute dist to all feas. solutions
            for feas_idx in feas_v.iloc[1:].index:
                d = pw_dist_(sample, infeas_idx, feas_idx)
                if d < d_nearest_feas:
                    # look for the nearest feas. solution
                    d_nearest_feas = d
            VDC.loc[infeas_idx, "distance"] = d_nearest_feas
        # no existing infeasible solutions
        if infeas_v.empty:
            VDC["distance"] = 0

        r, _ = scipy.stats.spearmanr(VDC[col], VDC["distance"])
        corr.update({f"vdc_{col}": r})

        ax = axs[i] if len(V.columns[:-1]) > 1 else axs
        # use uniform color for infeasible solutions
        color = sns.color_palette()[1]
        sns.scatterplot(
            data=sample[f"VDC_{col}"], x="distance", y=col, ax=ax, color=color
        )
        ax.set_title(f"VDC (corr = {r:.2f})")

    return corr, fig


def rdc(
    sample: dict, compute_D_file: bool = True
) -> Tuple[dict, matplotlib.figure.Figure]:
    """Computes rank distance correlation (``RDC``).

    This feature was implemented by extending the objective-distance correlation feature (:func:`pyxla.fdc`) to ranks. For each rank :math:`R_i`, a pair :math:`(r_i, d_i)` is generated for each solution, where :math:`r_i` is the rank of solution :math:`i`, and :math:`d_i \\in D_i` is the distance between solution :math:`i` and the nearest best solution. The visual output is a scatter plot of ranks (:math:`R_i`) against distances (:math:`D_i`), and calculates Spearman's correlation coefficient between :math:`R_i` and :math:`D_i` as the corresponding numerical output for each rank.

    Parameters
    ----------
    sample : dict
        A sample containing the at least input files V and D.
    compute_D_file : bool, optional
        By default ``True``; when there is no D file in the sample, if
        ``compute_D_file`` is set to ``True``, the whole D file is
        calculated. Calculating the whole D file will eliminate redundant
        distance calculations in the future, but it can be time consuming.
        To speed up calculation of `fdc`, set ``compute_D_file`` to
        ``False`` so that only the required distances are calculated.

    Returns
    -------
    dict
        Dictionary containing correlation between ranks and
        distance to the nearest best solution.
    matplotlib.figure.Figure
        ``matplotlib`` axes containing a scatter plot of ranks
        against distance to the nearest best solution.
    
    Examples
    --------
    >>> from pyxla import util, rdc
    >>> import matplotlib
    >>> sample = util.load_sample('cec2010_c01_2d_F1_V2', test=True)
    >>> feat, plot = rdc(sample)
    >>> type(feat)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """

    R: pd.DataFrame = sample["R"]
    corrs = {}
    numR = sample["numR"]
    ncols = numR
    # nrows = math.ceil(numR / ncols)
    fig, axs = plt.subplots(ncols=ncols, nrows=1, figsize=(5 * ncols, 5 * 1))
    # for each rank...
    axs = axs.ravel()
    for i, col in tqdm(enumerate(R.columns[:-1]), total=numR):  # exclude col 'feasible'
        sample[f"RDC_{col}"] = pd.DataFrame()
        RDC: pd.DataFrame = sample[f"RDC_{col}"]
        RDC[col] = R[col]
        # check if col is a V
        if col in sample["V"].columns:
            # determine feasibility per constraint
            RDC["feasible"] = sample["V"][col] = 0
        else:
            RDC["feasible"] = R["feasible"]
        RDC["distance"] = None
        # get solutions with rank == 1
        best = R.query(f"{col} == 1")
        # for rank 1 solution set distance to 0
        RDC.loc[best.index, "distance"] = 0
        # compute distance only for non-rank-1 solutions
        for t_idx in RDC.query("distance.isna()").index:
            d_nearest_best = pw_dist_(sample, t_idx, best.index[0])
            for b_idx in best[1:].index:
                d = pw_dist_(sample, t_idx, b_idx)
                if d < d_nearest_best:
                    d_nearest_best = d
            RDC.loc[t_idx, "distance"] = d_nearest_best

        sp_corr, _ = scipy.stats.spearmanr(RDC[col], RDC["distance"])
        corrs.update({f"rdc_{col}": sp_corr})

        ax = axs[i] if numR > 1 else axs
        sns.scatterplot(
            data=sample[f"RDC_{col}"],
            x="distance",
            y=col,
            hue="feasible",
            hue_order=[True, False],
            ax=ax,
        )
        ax.set_title(f"RDC (corr = {sp_corr:.2f})")

    # if i + 1 < ncols * nrows:
    #     for unused_ax in axs[i + 1:]: unused_ax.set_axis_off()
    return corrs, fig


def pdc(
    sample: dict, metric: Union[Callable, str] = "euclidean"
) -> Tuple[dict, matplotlib.figure.Figure]:
    """Computes pairwise distance correlation (``PDC``).

    This feature is based on Mantel's standardised test :cite:p:`diniz2013mantel`, which was applied in population genetics to determine whether and to what extent geographic distance influences genetic distance. The PDC| feature applies Mantel's standardised test to analyse the relationship between pairwise distance on the solution space and pairwise distance on the objective space (all objectives), violation space (all violations), and for each objective, violation, and rank independently. The `scipy <https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.distance.pdist.html>`__ package was used to efficiently compute pairwise distances. The feature produces scatter plots of pairwise distance on the solution space against pairwise distance on the objective space (all objectives), violation space (all violations), and against each objective, violation, and rank. The corresponding numerical outputs are the Spearman's correlation coefficients between each set of pairwise distances.

    Parameters
    ----------
    sample : dict
        A sample containing the at least input files V and D.
    metric : Callable or str, optional
        A metric function or the name of a distance metric as listed
        ``scipy``'s `pdist
        <https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.distance.pdist.html>`__ function.
        If a metric function is defined it must take two solutions and computes distance
        between them of the form ``dist(Xa, Xb) -> d`` where ``Xa`` and ``Xb``
        are ``pandas`` Series representing solutions, by default ``None``.
        For example: ``lambda Xa, Xb: abs(Xa.sum() - Xb.sum())``.

    Returns
    -------
    dict
        Dictionary containing correlation between pairwise distance on the
        solution space and pairwise distance on the objective space, on
        the violation space, and on each objective, violation and rank
        individually.
    matplotlib.figure.Figure
        ``matplotlib`` axes containing a scatter plot of pairwise distance
        on the solution space against pairwise distance on the objective
        space, on the violation space, and on each objective, violation
        and rank individually.

    Examples
    --------
    >>> from pyxla import util, pdc
    >>> import matplotlib
    >>> sample = util.load_sample('cec2010_c01_2d_F1_V2', test=True)
    >>> corr, plot = pdc(sample)
    >>> type(corr)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """
    util.handle_missing_D_file(sample, True, warn=False)

    F = sample["F"]
    V = sample["V"]
    D = sample["D"]
    # using errors='ignore' as the `feasible` column is only present when we have V
    R = sample["R"].drop("feasible", axis=1, errors="ignore")
    PD = pd.DataFrame()

    PD["Xd"] = D["d"]

    corrs = {}
    rows = []

    # objective space
    row1 = [{"x": F, "name": "F"}]

    # violation space
    if util.present(sample, "V"):
        V = V.drop("feasible", axis=1)
        row1.append({"x": V, "name": "V"})

    rows.extend(row1)

    # objectives
    if sample["numF"] > 1:
        rows.extend([{"x": F[col], "name": col} for col in F.columns])

    # violations
    if sample["numV"] > 1:
        rows.extend([{"x": V[col], "name": col} for col in V])

    # ranks
    rows.extend([{"x": R[col], "name": f"{col}-rank"} for col in R])

    # prepare figure
    ncols = min(3, len(rows))
    nrows = math.ceil(len(rows) / ncols)
    fig, axs = plt.subplots(ncols=ncols, nrows=nrows, figsize=(5 * ncols, 5 * nrows))
    color = sns.color_palette()[2]
    axs = axs.ravel()
    unused_axs = []

    for i, plot in enumerate(rows):
        ax_lbl = f"{plot['name']}_d"
        PD[ax_lbl] = util.calc_pairwise_dist(
            plot["x"], metric=metric, representation=sample["representation"]
        )
        corr, _ = scipy.stats.spearmanr(PD["Xd"], PD[ax_lbl])
        corrs.update({f"pdc_{plot['name']}": corr})  # fix .item()

        ax = sns.scatterplot(x=PD["Xd"], y=PD[ax_lbl], ax=axs[i], color=color)
        ax.set(title=f"X_d vs {plot['name']}_d (corr = {corr:.2f})")

    # turn off unused axes
    if i + 1 < ncols * nrows:
        for unused_ax in axs[i + 1 :]:
            unused_ax.set_axis_off()

    fig.suptitle(f"PDC for {sample['name']}", y=1.04)
    plt.tight_layout()

    return corrs, fig


def nfc(sample: dict) -> Tuple[dict, matplotlib.figure.Figure]:
    """Computes neighbouring solutions' objective values (fitness) correlation (``NFC``).

    This feature is implemented following the fitness cloud technique proposed by Verel et al. :cite:p:`verel2003bottlenecks`. Verel et al. proposed the technique to analyse the correlation between objective values of parents and offspring in the context of evolutionary computing.

    The fitness cloud technique was applied to analyse the correlation of fitness values between pairs of neighbours in a sample. Therefore, a neighbourhood file ``N`` is required. Considering each objective, for all pairs of neighbours, the corresponding objective values for each pair are plotted against each other in a scatter plot to produce a fitness cloud :cite:p:`vanneschi2004fitness`. A regression line is overlaid on the scatter plot. Further, a dotted identity line is plotted such that, assuming minimisation, points above it indicate deteriorating neighbours, those below it are improving neighbours, and those on the line are neutral neighbours. This procedure is done considering all solutions, and then considering feasible solutions only. The result is a pair of scatter plots for each objective. The numerical output of ``NFC`` is the Spearman's correlation coefficient between fitness values of solutions on the :math:`x`-axis and those on the :math:`y`-axis. Similarly, correlation is calculated considering all solutions and for feasible solutions only. ``NFC`` highlights the level of evolvability of fitness of a search space. Evolvability of a search space can be defined as the level of likelihood that a search reaches an area of better fitness in a landscape.

    Parameters
    ----------
    sample : dict
        A sample containing input files i.e ``F``, ``N``.

    Returns
    -------
    dict
        Dictionary containing correlation between objective values of
        solutions and the objective values of their neighbours, for all
        solutions and for feasible solutions only.
    matplotlib.axes.Axes
        ``matplotlib`` axes each containing a scatter plot of objective
        values of solutions against the objective values of their
        neighbours, for all solutions and for feasible solutions only.

    Raises
    ------
    Exception
        Raised if both N and X inputs are absent, as neighbourhood
        cannot be determined without having either.

    Examples
    --------
    >>> from pyxla import util, nfc
    >>> import matplotlib
    >>> sample = util.load_sample('nk_n14_k2_id5_F1_V1', test=True)
    >>> corrs, plot = nfc(sample)
    >>> type(corrs)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """

    util.handle_missing_N_file(sample, True, warn=False)

    F = sample["F"]
    numF = sample["numF"]
    V = sample["V"]
    N = sample["N"]

    corrs = {}
    rows = []

    rows.append({"name": "all", "nfc": N})

    # for feasible solutions only
    if util.present(sample, "V"):
        N_indexed = N.set_index("id1", drop=False)
        V = V.loc[N_indexed.index]
        feas_idxs = V[V["feasible"] == True].index
        # add plot data to rows only if there are feasible solutions
        if len(feas_idxs) > 0:
            feas_N = N_indexed.loc[feas_idxs]
            feas_N.reset_index(drop=True, inplace=True)
            rows.append({"name": "feas.", "nfc": feas_N})

    ncols = sample["numF"]
    nrows = len(rows)
    fig, axs = plt.subplots(ncols=ncols, nrows=nrows, figsize=(5 * ncols, 5 * nrows))

    # change color palette
    sns.set_palette("deep")
    sns.set_palette(reversed(sns.color_palette()), 10)
    palette = sns.color_palette()

    for row, data in enumerate(rows):
        NFC = data["nfc"]
        for col, f in enumerate(tqdm(F.columns)):
            x, y = f"{f}", f"neighbour {f}"
            # collate fitness values pairs for neighbour pairs
            NFC[x] = F[f].loc[NFC["id1"]].tolist()
            NFC[y] = F[f].loc[NFC["id2"]].tolist()

            corr, _ = scipy.stats.spearmanr(NFC[x], NFC[y])
            corr = corr if isinstance(corr, float) else corr.item()
            corrs.update({f"nfc_{data['name']}_X_for_{f}": corr})

            # determine axis coords.
            if len(rows) > 1:
                ax = axs[row, col] if numF > 1 else axs[row]
            else:
                ax = axs[col] if numF > 1 else axs

            ax = sns.scatterplot(x=NFC[x], y=NFC[y], ax=ax, color=palette[0])
            ax.set(title=f"NFC for {f} {data['name']} X (corr = {corr:.2f})")
            sns.regplot(x=NFC[x], y=NFC[y], ax=ax, scatter=False, color=palette[1])

            limits = [
                np.min([ax.get_xlim(), ax.get_ylim()]),
                np.max([ax.get_xlim(), ax.get_ylim()]),
            ]

            # plot diagonal line
            ax.plot(limits, limits, "--k")

            util.equalize_axes_(ax)

    fig.suptitle(f"NFC for {sample['name']}", y=1.04)
    plt.tight_layout()
    return corrs, fig


def nvc(sample: dict) -> Tuple[dict, matplotlib.figure.Figure]:
    """Computes neighbouring solutions' violation values correlation (``NVC``)

    This feature was implemented by extending the fitness cloud technique of :func:`pyxla.nfc` to the violation values. Considering infeasible solutions only with respect to each constraint, for all pairs of neighbours, the corresponding violation values are plotted against each other in a scatter plot. Similarly, a regression line is overlaid on the scatter plot. Further, a dotted identity line is plotted such that points above it indicate deteriorating neighbours, those below it are improving neighbours, and those on the line are neutral neighbours. The result is a scatter plot for each constraint. The corresponding numerical output for each plot is Spearman's correlation coefficient between violation values on the :math:`x`-axis and those on the :math:`y`-axis. Only infeasible solutions are considered, because feasible solutions have a violation value of zero. ``NVC`` indicates the level of searchability with respect to violation values; it quantifies how likely it is for a search to reach an area of the search space of lower constraint violation.

    Parameters
    ----------
    sample : dict
        A sample containing input files i.e ``V``, ``N``.

    Returns
    -------
    dict
        Dictionary containing correlation between violation values of
        solutions and the violation values of their neighbours, for
        infeasible solutions only.
    matplotlib.axes.Axes
        ``matplotlib`` axes each containing a scatter plot of violation
        values of solutions against the violation values of their
        neighbours for infeasible solutions only.

    Examples
    --------
    >>> from pyxla import util, nvc
    >>> import matplotlib
    >>> sample = util.load_sample('nk_n14_k2_id5_F3_V2', test=True)
    >>> corrs, plot = nvc(sample)
    >>> type(corrs)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """

    if not util.present(sample, "V"):
        raise Exception("V is required. Please provide V.")

    util.handle_missing_N_file(sample, True, warn=False)

    V = sample["V"].drop("feasible", axis=1)
    numV = sample["numV"]
    N = sample["N"]
    N_indexed = N.set_index("id1")

    # get all solutions represented in N file
    X_in_N_id1 = N["id1"].unique()
    X_in_N_id2 = N["id2"].unique()
    X_in_N = np.unique(np.concat([X_in_N_id1, X_in_N_id2]))
    # filter V to only have Xs in N
    V = V.loc[X_in_N]
    assert len(V) == len(X_in_N)

    corrs = {}
    fig, axs = plt.subplots(ncols=numV, figsize=(5 * numV, 5))

    # change color palette
    sns.set_palette("deep")
    sns.set_palette(reversed(sns.color_palette()), 10)
    palette = sns.color_palette()

    for i, v in enumerate(tqdm(V.columns)):
        NVC = pd.DataFrame()
        infeas = V.loc[X_in_N_id1].query(f"{v} != 0").index.to_numpy()
        # reduce N to have `id1's` that are infeasible
        N_filtered = N_indexed.loc[infeas]
        N_filtered = N_filtered.reset_index()
        x, y = f"{v}", f"neighbour {v}"
        NVC[x] = V.loc[N_filtered["id1"].to_numpy()][v].to_numpy()
        NVC[y] = V.loc[N_filtered["id2"].to_numpy()][v].to_numpy()
        assert len(NVC[x]) == len(NVC[y]) == len(N_filtered)

        corr, _ = scipy.stats.spearmanr(NVC[x], NVC[y])
        corr = corr if isinstance(corr, float) else corr.item()
        corrs.update({f"NVC_for_{v}": f"{corr:.4f}"})

        ax = axs[i] if numV > 1 else axs

        ax = sns.scatterplot(x=NVC[x], y=NVC[y], ax=ax, color=palette[0])
        ax.set(title=f"NVC for {v} (corr = {corr:.2f})")
        sns.regplot(x=NVC[x], y=NVC[y], ax=ax, scatter=False, color=palette[1])

        # plot diagonal line
        limits = [
            np.min([ax.get_xlim(), ax.get_ylim()]),
            np.max([ax.get_xlim(), ax.get_ylim()]),
        ]
        ax.plot(limits, limits, "--k")

        util.equalize_axes_(ax)

    fig.suptitle(f"NVC for {sample['name']}", y=1.04)
    plt.tight_layout()

    return corrs, fig


def nrc(sample: dict) -> Tuple[dict, matplotlib.figure.Figure]:
    """Computes neighbouring solutions' ranks correlation (``NRC``).

    This feature was implemented by extending the fitness cloud technique of :func:`pyxla.nfc` to ranks, such that fitness values are substituted with ranks. Considering each rank, for all pairs of neighbours, the corresponding ranks are plotted against each other in a scatter plot. A regression line is overlaid on the scatter plot. Further, a dotted identity line is plotted such that points above it indicate improving neighbours, those below it are deteriorating neighbours, and those on the line are neutral neighbours. The result is a scatter plot for each rank. The corresponding numerical output for each plot is Spearman's correlation coefficient between rank values on the :math:`x`-axis and those on the :math:`y`-axis. Similarly, ``NRC`` indicates searchability with regard to the various ranks.

    Parameters
    ----------
    sample : dict
        A sample containing input files i.e ``F``, ``N``.

    Returns
    -------
    dict
        Dictionary containing correlation between ranks of
        solutions and the ranks of their neighbours.
    matplotlib.axes.Axes
        ``matplotlib`` axes each containing a scatter plot of ranks of solutions against the ranks of their neighbours.

    Examples
    --------
    >>> from pyxla import util, nrc
    >>> import matplotlib
    >>> sample = util.load_sample('nk_n14_k2_id5_F3_V2', test=True)
    >>> corrs, plot = nrc(sample)
    >>> type(corrs)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """

    util.handle_missing_N_file(sample, True, warn=False)

    R = sample["R"]
    R = R if not util.present(sample, "V") else R.drop("feasible", axis=1)
    numR = sample["numR"]
    N = sample["N"]

    # get all solutions represented in N file
    X_in_N_id1 = N["id1"].unique()
    X_in_N_id2 = N["id2"].unique()
    X_in_N = np.unique(np.concat([X_in_N_id1, X_in_N_id2]))
    # filter R to only have Xs in N
    R = R.loc[X_in_N]
    assert len(R) == len(X_in_N)

    corrs = {}
    ncols = min(3, numR)
    nrows = math.ceil(numR / ncols)
    fig, axs = plt.subplots(ncols=ncols, nrows=nrows, figsize=(5 * ncols, 5 * nrows))
    axs = axs.ravel() if numR > 1 else axs
    # change color palette
    sns.set_palette("deep")
    sns.set_palette(reversed(sns.color_palette()), 10)
    palette = sns.color_palette()

    for i, r in enumerate(tqdm(R.columns)):
        NRC = pd.DataFrame()
        x, y = f"{r} rank", f"neighbour {r} rank"
        NRC[x] = R.loc[N["id1"].to_numpy()][r].to_numpy()
        NRC[y] = R.loc[N["id2"].to_numpy()][r].to_numpy()

        corr, _ = scipy.stats.spearmanr(NRC[x], NRC[y])
        corr = corr if isinstance(corr, float) else corr.item()
        corrs.update({f"NRC_for_{r}_ranks": f"{corr:.4f}"})
        ax = axs[i] if numR > 1 else axs

        ax = sns.scatterplot(x=NRC[x], y=NRC[y], ax=ax, color=palette[0])
        ax.set(title=f"NRC for {r} ranks (corr = {corr:.2f})")
        sns.regplot(x=NRC[x], y=NRC[y], ax=ax, scatter=False, color=palette[1])

        # plot diagonal line
        limits = [
            np.min([ax.get_xlim(), ax.get_ylim()]),
            np.max([ax.get_xlim(), ax.get_ylim()]),
        ]
        ax.plot(limits, limits, "--k")

        util.equalize_axes_(ax)

    fig.suptitle(f"NRC for {sample['name']}", y=1.04)

    plt.tight_layout()

    return corrs, fig


def ncf(sample: dict) -> Tuple[dict, matplotlib.axes.Axes]:
    """Computes neighbouring change in feasibility (``NΔFeas``).

    The ``NΔFeas`` feature was implemented as an algorithm that uses a neighbourhood file, ``N``, to compute the proportion of transitions from one solution to another that result in a change in feasibility and the proportion of transitions that do not result in a change in feasibility. The numerical output produced is a set of proportions, while the visual output is a bar chart of the proportions. This feature shows the extent to which regions of infeasible or feasible solutions are contiguous. The level of contiguousness is indicative of the evolvability of the landscape with regard to feasibility.

    Parameters
    ----------
    sample : dict
        A sample containing input files i.e ``F``, ``N``.

    Returns
    -------
    proportions : dict
        Dictionary containing the numerical proportions as defined above.
    matplotlib.axes.Axes
        ``matplotlib`` figure with the bar chart visually illustrating the proportions defined above.

    Raises
    ------
    Exception
        Raises an exception if no V file is provided as feasibility is
        undefined without the V file.
    Exception
        Raises an exception if the sample only has solutions belong to
        only one class of feasibility i.e if all solutions are infeasible
        or if all solutions are feasible.
    Exception
        Raised if both N and X inputs are absent, as neighbourhood
        cannot be determined without having either.

    Examples
    --------
    >>> from pyxla import util, ncf
    >>> sample = util.load_sample('nk_n14_k2_id5_F1_V1', test=True)
    >>> proportions, fig = ncf(sample)
    >>> proportions # doctest: +SKIP
    """

    if not util.present(sample, "V"):
        raise Exception("V is required. Please provide V.")

    util.handle_missing_N_file(sample, True, warn=False)

    proportions = {}

    V = sample["V"]

    N = sample["N"]
    N["id1_feasible"] = V.loc[N["id1"]]["feasible"].to_numpy()
    N["id2_feasible"] = V.loc[N["id2"]]["feasible"].to_numpy()

    inversions = (N["id1_feasible"] ^ N["id2_feasible"]).sum()

    proportions["discontiguous feasbility"] = inversions / len(N)
    proportions["contiguous feasibility"] = 1 - proportions["discontiguous feasbility"]

    fig = sns.barplot(
        x=proportions.keys(), y=proportions.values(), hue=proportions.keys()
    )
    fig.set_title(f"NΔFeas for {sample['name']}")
    fig.set_ylim(0, 1)
    fig.set_ylabel("proportion")

    for container in fig.containers:
        fig.bar_label(container, label_type="center", padding=5)

    plt.tight_layout()

    return proportions, fig


def disp_best(
    sample: dict, init_percentage: int = 10, growth_factor: int = 2
) -> Tuple[dict, matplotlib.figure.Figure]:
    """Computes dispersion of best solutions (``disp_best``).

    The implementation of the ``disp_best`` feature is based on the dispersion metric proposed by Lunacek and Whitley :cite:p:`lunacek2006dispersion`. Initially, the overall sample of solutions is sorted according to some rank. Subsamples of the :math:`n` best solutions are obtained from that sample where :math:`n` increases according to a specified geometric growth factor. For each subsample, the pairwise distance among the contained solutions is calculated. The visual output of ``disp_best`` is a scatter plot of sample size against pairwise distances. The corresponding numerical output is the dispersion metric computed by subtracting the average of pairwise distances (dispersion) of the largest subsample from the average of pairwise distances of the smallest subsample. Lower dispersion metric values indicate the presence of a global structure, while higher values indicate the presence of funnels. Thus, ``disp_best`` indicates the presence (and the extent thereof) or the absence of multimodality.

    Parameters
    ----------
    sample : dict
        A sample containing input files i.e ``F``, ``N``.
    init_percentage : int, optional
        Intial subsample size in percentage, by default 10
    growth_factor : int, optional
        Defines how to successively increase sample size, by default 2

    Returns
    -------
    dict
        Dictionary containing dispersion metrics for each subsample size.
    matplotlib.figure.Figure
        ``matplotlib`` scatter plots of subsample size against pairwise distances.

    Raises
    ------
    Exception
        Raised if initial percentage size of a subsample is :math:`\\geq100%`.
    
    Examples
    --------
    >>> from pyxla import util, disp_best
    >>> import matplotlib
    >>> sample = util.load_sample('sphere', test=True)
    >>> feat, plot = disp_best(sample)
    >>> type(feat)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """

    if init_percentage >= 100:
        raise Exception("Initial percentage for sub-sampling must be less than 100%.")

    util.handle_missing_D_file(sample, True, warn=False)

    D = sample["D"]
    R: pd.DataFrame = sample["R"]
    numR = sample["numR"]
    R = R if not util.present(sample, "V") else R.drop("feasible", axis=1)

    disp_metrics = {}
    ncols = min(3, numR)
    nrows = math.ceil(numR / ncols)
    fig, axs = plt.subplots(ncols=ncols, nrows=nrows, figsize=(ncols * 5, nrows * 5))
    axs = axs.ravel() if numR > 1 else axs

    sample_sizes = [init_percentage]
    i = 0
    while sample_sizes[i] * growth_factor < 100:
        sample_sizes.append(sample_sizes[i] * growth_factor)
        i += 1

    for i, r in enumerate(R.columns):
        sorted = R.sort_values(by=r)
        pw_distances_avgs = []
        plot_data = pd.DataFrame(columns=["pairwise distances", "sample size"])

        for n in sample_sizes:
            nth = int(n / 100 * len(R))
            best_n = sorted[:nth].index.sort_values()
            pairs = itertools.combinations(best_n, 2)
            pw_distances = D.loc[pairs]["d"].to_numpy()

            data = pd.DataFrame()
            data["pairwise distances"] = pw_distances
            data["sample size"] = n
            plot_data = data if plot_data.empty else pd.concat([plot_data, data])

            pw_distances_avgs.append(pw_distances.mean())

        # dispersion metrics
        disp_metric = pw_distances_avgs[0] - pw_distances_avgs[-1]
        disp_metrics.update({r: disp_metric})

        # plot
        ax = axs[i] if numR > 1 else axs
        sns.scatterplot(
            x=plot_data["sample size"], y=plot_data["pairwise distances"], ax=ax
        )
        ax.set(title=f"disp_best for {r} (metric = {disp_metric:.4f})")

        # custom function scale matching growth factor
        forward = lambda x: np.log(x / init_percentage) / np.log(growth_factor)
        inverse = lambda x: init_percentage * (growth_factor**x)
        ax.set_xscale("function", functions=(forward, inverse))

        # set ticks manually
        ax.set_xticks(sample_sizes)
        ax.set_xticklabels([str(t) for t in sample_sizes])

    # turn off unused axes
    if i + 1 < ncols * nrows:
        for unused_ax in axs[i + 1 :]:
            unused_ax.set_axis_off()

    fig.suptitle(f"disp_best for {sample['name']}", y=1.04)

    plt.tight_layout()

    return disp_metrics, fig


def X_imp(
    sample: dict,
    binary: bool = False,
    n_repeats: int = 10,
    train_proportion: int = 0.7,
    estimator: Literal["ridge", "lasso", "lars"] = "lasso",
    alpha: float = 1,
    seed: float = None,
) -> Tuple[pd.DataFrame, dict, matplotlib.figure.Figure]:
    """
    Computes variable importance (``X_imp``)

    The implementation of the ``X_imp`` feature produces a bar chart of correlation values between each decision variable in the ``X`` file and each objective in the ``F`` file. Correlation is calculated as Spearman's correlation coefficient except for problems where a decision variable is binary, in which case the point-biserial correlation coefficient is calculated instead. Additionally, a linear regression model is fitted on ``X`` as features and ``F`` as the output. The `scikit-learn <https://scikit-learn.org/stable/api/sklearn.linear_model.html>`__ is utilised for this.
    The feature allows the desired regression model to be specified as a parameter, i.e., Ridge or Lasso.
    The features are scaled to values between 0 and 1 to ensure all features contribute equally. The linear model is used to carry out permutation variable importance using a function provided by the `scikit-learn <https://scikit-learn.org/stable/modules/permutation_importance.html>`__ package. Each variable is permuted to random values, and the effect on the predicted objective value is quantified over a number of repetitions.

    Parameters
    ----------
    sample : dict
        A sample containing input files i.e ``F``, ``X``.
    binary : bool, optional
        Set to ``True`` if the sample involves variables from a discrete domain, by default ``False``
    n_repeats : int, optional
        The number of time to repeat permutation for variable importance testing, by default 10
    train_proportion : float, optional
        Proportion of sample to be used to fit a linear regression model, by default 0.7
    estimator : Literal['ridge', 'lasso', 'lars'], optional
        The type of linear model to be used to fit ``X``, ``F``, by default 'lasso'
    alpha : float, optional
        Constant that controls the regularisation strength of the Ridge and Lasso estimators, by default 1
    seed : float, optional
        Random number generator seed value for reproducibility, by default None

    Returns
    -------
    pd.DataFrame
        A correlation matrix with correlation coefficients between variables and objectives.
    dict
        Dictionary with importance scores, score standard deviation and ranks for each variable with respect to each objective.
    matplotlib.figure.Figure
        Bar plot(s) showing importance for each variable with respect to each objective.

    Raises
    ------
    Exception
        Raised if the sample does not have an ``X`` file.
    Exception
        Raised if an incorrect ``estimator`` type is specified.
    
    Examples
    --------
    >>> from pyxla import util, X_imp
    >>> import matplotlib
    >>> sample = util.load_sample('nk_n14_k2_id5_F1_V1', test=True)
    >>> corr_matrix, x_imp_ranks, plot = X_imp(sample, alpha=0.001)
    >>> type(x_imp_ranks)
    <class 'dict'>
    >>> isinstance(plot, matplotlib.figure.Figure)
    True
    """

    if not util.present(sample, "X"):
        raise Exception("X is required. Please provide an X file.")

    X: pd.DataFrame = sample["X"]
    F = sample["F"]
    numF = sample["numF"]

    x_imp_ranks = {}

    # add the objectives to the X file
    for f in F.columns:
        X[f] = F[f]

    pointbiserialr = lambda x, y: scipy.stats.pointbiserialr(y, x)[0]
    spearmanr = lambda x, y: scipy.stats.spearmanr(y, x)[0]

    corr_matrix = X.corr(method=pointbiserialr if binary else spearmanr)

    # remove F cols from X file
    X.drop(F.columns, axis=1, inplace=True)

    corr_matrix = corr_matrix.drop(index=X.columns).drop(columns=F.columns)

    fig, axs = plt.subplots(ncols=numF, nrows=2, figsize=(numF * 5, 10))

    for i, f in enumerate(F.columns):
        ax = axs[0, i] if numF > 1 else axs[i]
        ax = sns.barplot(corr_matrix.loc[f], ax=ax)
        ax.set(title=f"Correlation of X and {f}")

    for i, f in enumerate(F.columns):
        x_imp = pd.DataFrame()

        # normalize
        X = (X - X.min(axis=0)) / (X.max(axis=0) - X.min(axis=0))

        X_train, X_test, y_train, y_test = train_test_split(
            X, F[f], train_size=train_proportion, random_state=seed
        )

        model = None

        match estimator:
            case "ridge":
                model = Ridge(alpha=alpha).fit(X_train, y_train)
            case "lasso":
                model = Lasso(alpha=alpha).fit(X_train, y_train)
            case "lars":
                model = Lars().fit(X_train, y_train)
            case _:
                raise Exception(
                    "Invalid estimator specified chose one of: `ridge`, `lasso`, `lars`."
                )

        r2 = model.score(X_test, y_test)

        imp = permutation_importance(
            model, X_test, y_test, n_repeats=n_repeats, random_state=seed, scoring="r2"
        )
        # sort importance means desc.
        imp_idxs = imp.importances_mean.argsort()[::-1]

        x_imp["X"] = X.columns[imp_idxs]
        x_imp["importance"] = imp.importances_mean[imp_idxs]
        x_imp["std"] = imp.importances_std[imp_idxs]
        x_imp["rank"] = x_imp.index.to_numpy() + 1
        x_imp_ranks[f] = x_imp

        ax = sns.barplot(
            x_imp, x="X", y="importance", ax=axs[1, i] if numF > 1 else axs[1]
        )
        ax.errorbar(
            x=range(len(x_imp)),
            y=x_imp["importance"],
            yerr=x_imp["std"],
            fmt="none",
            c="black",
        )
        ax.set(title=f"X_imp for {f} (Validation {r"$R^2$"} = {r2:.4f})")

    fig.suptitle(f"X_imp for {sample['name']}")

    plt.tight_layout()

    return corr_matrix, x_imp_ranks, fig
