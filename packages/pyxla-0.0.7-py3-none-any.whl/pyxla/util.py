"""Utility functions.

A set of utility functions that are not meant to be part of
pyXla.

"""

from collections import defaultdict
import moocore
import os
import json
import pandas as pd
import random
import numpy as np
import scipy
from tqdm.auto import tqdm
import inspect
import logging
from typing import List, Generator, Callable, Union
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import MaxNLocator
import math

logging.basicConfig(level=logging.INFO)

# load all CSV files provided by the user and update th structure
def load_data(sample, sep = ' '):
    # read F (required)
    if 'F' not in sample:
        sample['F'] = pd.read_csv(sample['Fcsv'], sep = sep).drop(columns=['id'], errors='ignore')
    sample['size'] = len(sample['F'])
    sample['numF'] = len(sample['F'].columns)
    if not 'max' in sample:
        sample['max'] = False   # we minimize by default
    # read X (optional)
    if 'X' not in sample:
        sample['X'] = None
    if 'Xcsv' in sample:
        sample['X'] = pd.read_csv(sample['Xcsv'], sep = sep).drop(columns=['id'], errors='ignore')
        assert sample['size'] == len(sample['X'])
    # read V (optional)
    if not present(sample, 'V'):
        sample['V'] = None
        sample['numV'] = 0
    else: 
        V = sample['V']
        sample['numV'] = len(V.loc[:, V.columns != 'feasible'].columns)
    if 'Vcsv' in sample:
        sample['V'] = pd.read_csv(sample['Vcsv'], sep = sep)
        assert sample['size'] == len(sample['V'])
        sample['numV'] = len(sample['V'].columns)
    if sample['V'] is not None:
        # sample['V']['feasible'] = sample['V'].iloc[:,1:].sum(axis = 1) == 0 
        # removed from above `.iloc[:,1:]` as starting from the 2nd column (index 1) 
        #   assumes `id` column is present, but it is not
        sample['V']['feasible'] = sample['V'].sum(axis = 1) == 0
    # read N (optional)
    if 'N' not in sample:
        sample['N'] = None
    if 'Ncsv' in sample:
        sample['N'] = pd.read_csv(sample['Ncsv'], sep = sep)
    # read D (optional)
    if 'D' not in sample:
        sample['D'] = None
    else: sample['D'].set_index(['id1', 'id2'], inplace=True)
    if 'Dcsv' in sample:
        sample['D'] = pd.read_csv(sample['Dcsv'], sep = sep)
        # use multi-indexing to improve lookup
        sample['D'].set_index(['id1', 'id2'], inplace=True)
    # distance metric: euclidean distance by default
    if not 'p' in sample:
        sample['p'] = 2
    if 'representation' not in sample:
        sample['representation'] = 'continuous'
    if 'd_metric_func' not in sample:
        sample['d_metric_func'] = None
    if 'neighbourhood_func' not in sample:
        sample['neighbourhood_func'] = None
   
    compute_R(sample)

def to_sample(dict: dict) -> dict:
    """Convert a dictionary to a pyxla sample dictionary.

    Parameters
    ----------
    dict : dict
        Dictionary with input files.

    Returns
    -------
    dict
        A pyxla dictionary fit for use with pyxla features.
    """
    load_data(dict)
    return dict

def compute_R(sample):
    sample['R'] = pd.DataFrame()
    R = sample['R']
    F = sample['F']
    V = sample['V']
    # objective-wise rank
    for col in F.columns:
        # use dense ranking: https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.rank.html
        R[col] = F[col].rank(ascending = not sample['max'], method = 'dense').astype(int)

    # Pareto rank on objectives
    R['paretoF'] = moocore.pareto_rank(F, maximise = sample['max'])

    if present(sample, 'V'):
        # violation-wise rank
        for col in V.loc[:, V.columns != 'feasible']:
            # use dense ranking
            R[col] = V[col].rank(ascending = True, method = 'dense').astype(int)

        # Pareto rank on violations
        R['paretoV'] = moocore.pareto_rank(V.loc[:, V.columns != 'feasible'], maximise = False)

        # feasibility rules from Deb
        div = max(R['paretoF']) + 1
        R['tmp'] = R['paretoF'] / div + R['paretoV'] # summing up violation ranks (as integers) and f-ranks (as real numbers lower than 1)
        # use dense ranking
        R['Deb'] = R['tmp'].rank(ascending=True, method = 'dense').astype(int)
        R.drop('tmp', axis = 1, inplace = True)
        # Pareto rank on objectives AND violations
        FV = pd.merge(F, V.loc[:, V.columns != 'feasible'], left_index = True, right_index = True)
        # specify whether or not to maximize the columns (objectives and violation)
        maximise_F = [sample['max']] * sample['numF']
        maximise_V = [False] * sample['numV']
        R['paretoFV'] = moocore.pareto_rank(FV, maximise=(maximise_F + maximise_V))
        R['feasible'] = V['feasible']
    # Pareto rank on F && V: iff 2+
    numR = sample['numF'] + sample['numV'] + 4
    if sample['numF'] <= 1:
        R.drop('paretoF', axis = 1, inplace = True)
        numR -= 1
    if sample['numV'] <= 1:
        R.drop('paretoV', axis = 1, inplace = True, errors='ignore')
        numR -= 1
    if sample['numF'] == 0 or sample['numV'] == 0:
        R.drop('paretoFV', axis = 1, inplace = True, errors='ignore')
        R.drop('Deb', axis = 1, inplace = True, errors='ignore')
        numR -= 2
    sample['numR'] = numR

def present(sample: dict, input: str) -> bool:
    """Check presence of a given input file in a sample.

    An input is considered present if there is a pandas.Dataframe
    associated to the a key corresponding to the input file.

    Parameters
    ----------
    sample : dict
        A loaded sample containing input files.
    input : str
        A character representing an input file type i.e. 'X' or 'F'
    
    Returns
    -------
    bool
        `True` if the input file is present and `False` otherwise.
    """
    if input not in sample: return False
    return True if isinstance(sample[input], pd.DataFrame) else False

def list_samples(test: bool = False) -> list[str]:
    path = f"../data/{'test_' if test else ''}samples"
    samples = os.listdir(path)
    if '.gitkeep' in samples: samples.remove('.gitkeep')
    return samples

def load_samples_with(input: str, test: bool = False) -> Generator:
    for name in list_samples(test=test):
        s = load_sample(name, test=test)
        if present(s, input): yield s

def load_samples_without(input: str, test: bool = False) -> Generator:
    for name in list_samples(test=test):
        s = load_sample(name, test=test)
        if not present(s, input): yield s

def load_sample(name: str, test=False, exclude=[]):
    """Load an example dataset.

    pyXla provided a few example datasets that can be used
    to try out the framework.

    Parameters
    ----------
    name : str
        Name of the dataset. [@todo: include link to folder of datasets]
    test : bool, optional
        If `True`, a lightweight test version of the sample is loaded.
        If `False`, the whole dataset is loaded. 
    exclude: list[str], optional
        Selectively load input files to reduce memory footprint. This is 
        useful where some input files are not needed for the desired 
        operation.

    Returns
    -------
    sample : dict
        A dictionary with the input files of a problem sample i.e. F or V files.
    
    Examples
    --------
    >>> from pyxla.util import load_sample
    >>> import pandas as pd
    >>> sample = load_sample('cec2010_c18_2d_F1_V2')
    >>> type(sample)
    <class 'dict'>
    """
    # sample = {'name': name}
    dir = f"../data/{'test_' if test else ''}samples"
    return load_sample_from(dir, name, exclude=exclude)

def load_sample_from(dir: str, name: str, exclude=[]):
    sample = {'name': name}
    path = os.path.join(dir, name)
    for f in os.listdir(path):
        # get the input type i.e X or F
        if f == "metadata.json":
            with open(f'{path}/{f}', 'r') as file:
                metadata = json.load(file)
                for k, v in metadata.items():
                    sample[k] = v
        else:
            input = f[-5:-4]
            if input in exclude: continue
            sample[f'{input}csv'] = f"{path}/{f}"
    load_data(sample)
    return sample

def compute_D(sample: dict, 
              metric: Union[Callable, str] = None,
              representation: str = None,
              force: bool = False) -> pd.DataFrame:
    """Compute a D file containing pairwise distance between solutions.

    Parameters
    ----------
    sample : dict
        _description_
    metric : Callable or str, optional
        A metric function or the name of a distance metric as listed 
        `scipy`'s `pdist function 
        <https://docs.scipy.org/doc/scipy/reference/generated/scipy.spatial.distance.pdist.html>`_.
        If a metric function is defined it must take two solutions and computes distance
        between them of the form dist(Xa, Xb) -> d where Xa and Xb
        are `pandas` Series representing solutions, by default `None`.
        For example: `lambda Xa, Xb: abs(Xa.sum() - Xb.sum())`.
    representation : {'continuous', 'binary'}, optional
        Representation of the data i.e. continuous or discrete, by 
        default `None`.
    force : bool, optional
        If set to True, the D file is recomputed even if there is an 
        existing D file, by default `False`.

    Returns
    -------
    pandas.DataFrame
        Returns a dataframe of pairwise distances.

    es
    ------
    ValueError
        Raised if no X file is in the sample. It is also raised if there
        is an attempt to compute a D file when one is already present and
        `force` is set to `False`.
    ExceptionRais
        Raised if neither a metric function nor a representation category
        is specified.
    """
    if not force and present(sample, 'D'):
        raise ValueError('A D file already exists. Are you sure you want to recompute it? To recompute it retry with `force=True`.')
    if not present(sample, 'X'): 
        raise ValueError('An X file is required to compute a D file.')
    if not metric and not representation:
        raise Exception('Neither a metric function nor representation specified. Please specify a metric function or representation i.e. `continuous`, `discrete`.')
    
    X = sample['X']
    D = pd.DataFrame(columns=['id1', 'id2', 'd'])

    # efficiently generate columns `id1` and `id2`
    a, b = np.triu_indices(len(X), k=1)
    D['id1'] = a
    D['id2'] = b

    D['d'] = calc_pairwise_dist(X, metric=metric, representation=representation)
    
    return D

def calc_pairwise_dist(X, 
                       metric: Union[Callable, str] = None, 
                       representation: str = None,) -> pd.DataFrame:
    
    if isinstance(metric, Callable): check_metric_func(X, metric)

    if not metric:
        # euclidean distance if continuous, hamming if binary
        metric = 'euclidean' if representation == 'continuous' else 'hamming'
    
    X = X.to_numpy()
    
    # reshape X if it does not have 2 dim.
    if len(X.shape) < 2: X = X.reshape(-1, 1)
    
    return scipy.spatial.distance.pdist(X, metric)

def check_metric_func(nd_array_like, metric_func: callable):
    sig = inspect.signature(metric_func)
    if len(sig.parameters) != 2: 
        raise Exception('A metric function must take exactly two arguments.')
    
    if isinstance(nd_array_like, pd.DataFrame):
        a, b = nd_array_like.iloc[0], nd_array_like.iloc[1]
    else:
        a, b = nd_array_like[0], nd_array_like[1]
        
    if metric_func(a, b) == None:
        raise Exception('A metric function must return a value.')
    return True

def save_input_file(sample: dict, 
                    input: str, 
                    dir: str = None, 
                    sep: str = ' ', 
                    index: bool = False) -> str:
    """Save input file currently in memory to storage.
    
    Parameters
    ----------
    sample : dict
        A sample containing the various input files i.e `F`, `V`.
    input : {'F', 'X', 'V', 'D', 'N'}
        A single character string indicating the type of input.
    dir : str, optional
        Path to the directory where the file should be saved. 
        If `None` the file is save in the current working directory.

    Returns
    -------
    str
        Path to the saved input file.
    
    """
    if not present(sample, input): return
    
    path = f"{dir if dir else '.'}/{sample['name']}_{input}.csv"
    sample[input].to_csv(path, sep=sep, index=index)
    return path

def sample_test_X(sample: dict, num_x: int = 10) -> list[int]:
    """Samples a few solutions from large sample.

    Sample a list of length `num_x` of

    Parameters
    ----------
    sample : dict
        A sample containing the various input files i.e `F`, `V`.
    num_x : int, optional
        Number of samples to generate, by default 10.

    Returns
    -------
    list[int]
        List of indices of sampled solutions.
    """
    X_idx = defaultdict()
    V = sample['V'][:-1]
    for v in V:
        feas_v, infeas_v = V.query(f'{v} == 0'), V.query(f'{v} != 0')
        if not feas_v.empty: X_idx[feas_v.index[0].item()] = None
        if not len(infeas_v) < 2: 
            X_idx[infeas_v.index[0].item()] = None
            X_idx[infeas_v.index[1].item()] = None

    while len(X_idx) != num_x:
        X_idx[random.choice([i for i in range(len(V))])] = None
    return list(X_idx.keys())

def gen_test_samples(num_x: int = 10):
    """Generate small test samples for use in tests.

    The samples are generated from the samples provided by the
    pyXla core team.

    Parameters
    ----------
    num_x : int, optional
        Number of solutions to include in the test sample.

    Returns
    -------
    test_samples: list
        List of lightweight samples of size `num_x`
    """
    inputs = ["F", "X", "V"]
    test_samples = []
    samples = os.listdir('../data/samples')
    for s in samples:
        sample = load_sample(s, exclude=['D'])
        # drop feasible column in V
        if present(sample, 'V'): 
            X_idx = sample_test_X(sample, num_x=num_x)
            sample['V'].drop(columns=['feasible'], inplace=True)
        else: X_idx = [i for i in range(num_x)]
        for i in inputs:
            if not present(sample, i): continue
            # pick the first 10 solutions
            sample[i] = sample[i].loc[X_idx]
        if present(sample, 'D'):
            D = compute_D(sample, representation='continuous', force=True)
            # load D file into the sample
            sample['D'] = D
        if present(sample, 'N') and present(sample, 'X'):
            N = compute_N(sample, neighbourhood_func=lambda x, y: random.choice([True, False]), force=True)
            # load N file into the sample
            sample['N'] = N
        if present(sample, 'N') and not present(sample, 'X'):
            # Remove N file
            sample.pop('N')
        test_samples.append(sample)
    return test_samples

def save_test_samples(samples: list[dict]):
    """Save samples to file system
    
    The function saves the samples generated by `gen_test_samples`.

    Parameters
    ----------
    sample : dict
        A sample containing the various input files i.e `F`, `V`.
    """
    inputs = ["F", "X", "V", "D", "N"]
    for s in samples:
        s_dir = f"../data/test_samples/{s["name"]}"
        os.makedirs(s_dir, exist_ok=True)
        # for each input present
        for i in inputs:
            if not present(s, i): continue
            path = f"{s_dir}/{s["name"]}_{i}.csv"
            s[i].to_csv(path, sep=' ', index=False)


def generate_D_file(sample, dir: str = None) -> str:
    metric_func = None if not 'd_metric_func' in sample else sample['d_metric_func']
    representation = None if not 'representation' in sample else sample['representation']
    D = compute_D(sample, metric=metric_func, representation=representation)
    # load D file into the sample
    sample['D'] = D
    path = save_input_file(sample, 'D', dir=dir)
    # index D file, for efficient lookup
    D.set_index(['id1', 'id2'], inplace=True)
    return path

def generate_N_file(sample, dir: str = None) -> str:
    N = compute_N(sample, neighbourhood_func=sample['neighbourhood_func'])
    # load N file into the sample
    sample['N'] = N
    path = save_input_file(sample, 'N', dir=dir)
    return path

def compute_N(sample: dict, 
              neighbourhood_func: Callable = None, 
              force=False) -> pd.DataFrame:
    if not force and present(sample, 'N'):
        raise ValueError('A N file already exists. Are you sure you want to recompute it? To recompute it retry with `force=True`.')
    if not present(sample, 'X'): 
        raise ValueError('An X file is required to compute a N file.')
    n_func = sample['neighbourhood_func'] if sample['neighbourhood_func'] else neighbourhood_func
    if not n_func:
        raise Exception('No neighbourhood function specified. Please specify a neighbourhood function of the form form f(X1, X2) -> bool.')
    
    X = sample['X']
    N = pd.DataFrame(columns=['id1', 'id2', 'n'])

    # efficiently generate columns `id1` and `id2`
    a, b = np.triu_indices(len([i for i in range(len(X))]), k=1)
    N['id1'] = list(a)
    N['id2'] = list(b)

    N['n'] = calc_pairwise_dist(X, metric=n_func)

    # filter to retain only if n(neighbour) == True
    N = N[N['n'] == True]
    
    return N.drop('n', axis=1)

def handle_missing_D_file(sample: dict, compute_D_file: bool, warn: bool = True):
    if not present(sample, 'D') and not present(sample, 'X'): raise Exception('Both D and X are absent. Please provide either D or X.')

    if not present(sample, 'D') and compute_D_file:
        if warn: logging.warning('No D file is present, thus, computing the D file... Computing an entire D file can be time consuming. Instead, you can call the function with the keyword argument `compute_D_file` set to `False` to speed up computation, as only the required distances will be calculated.')
        path = generate_D_file(sample)
        logging.info(f'D file has been loaded to the current sample and is saved to {path}')

def handle_missing_N_file(sample: dict, compute_N_file: bool, warn: bool = True):
    """Handles scenarios where a required N file is missing.

    This function abstracts away the checking of the presence an N
    file when it is required. It handles computation of the neighbourhood
    when the N file is absent.

    Parameters
    ----------
    sample : dict
        A sample containing the at least input i.e `F`, `N`.
    compute_N_file : bool
        Determine whether the missing N file should be computed.
    warn : bool, optional
        Whether to ignore warning that computing N file can take a while.
        It is by default, `True`.

    Raises
    ------
    Exception
        Raised if both N and X inputs are absent, as neighbourhood
        cannot be determined without having either.
    """
    if not present(sample, 'N') and not present(sample, 'X'): raise Exception('Both N and X are absent. Please provide either N or X.')

    if not present(sample, 'N') and compute_N_file:
        if warn: logging.warning('No N file is present, thus, computing the N file... Computing an entire N file can be time consuming. Instead, you can call the function with the keyword argument `compute_N_file` set to `False` to speed up computation, as only the required distances will be calculated.')
        path = generate_N_file(sample)
        logging.info(f'N file has been loaded to the current sample and is saved to {path}')

def equalize_axes_(ax: matplotlib.axes.Axes):
    limits = [
        np.min([ax.get_xlim(), ax.get_ylim()]),  
        np.max([ax.get_xlim(), ax.get_ylim()]), 
    ]

    ax.set_xlim(*limits)
    ax.set_ylim(*limits)

    # make plot aspect ratio square
    ax.set_aspect('equal', adjustable='box')
    
    x_ticks = ax.get_xticks()
    x_ticks = x_ticks[(x_ticks >= limits[0]) & (x_ticks <= limits[1])]

    y_ticks = ax.get_yticks()
    y_ticks = y_ticks[(y_ticks >= limits[0]) & (y_ticks <= limits[1])]
    
    tick_count = min(len(x_ticks), len(y_ticks))
    ax.xaxis.set_major_locator(MaxNLocator(nbins=tick_count))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=tick_count))


def plot_3d_(x, y, z, ax=None):
    if not ax: ax = plt.figure().add_subplot(projection='3d')
    ax.plot_trisurf(x, y, z, cmap=cm.coolwarm)

def save_ax_(i: int, from_fig: matplotlib.figure.Figure, filename: str = 'fig.png', area=(1.25, 1.25)):
    """
    Extract an axis from a figure and save it. This function is only used
    for writing Hons research report, it should be removed in future.
    """
    axs = from_fig.get_axes()

    if i > len(axs) - 1: raise Exception('Axis index out of bounds.')

    ax = axs[i]
    ax.set_title('')
    extent = ax.get_window_extent().transformed(from_fig.dpi_scale_trans.inverted())
    from_fig.savefig(filename, bbox_inches=extent.expanded(*area), dpi=300)