"""Shared modules used by both capture and validate commands."""
