"""
SQL template renderer.

Takes a ``run`` template produced by ``scai test seed`` and substitutes the
positional placeholders (``{0}``, ``{1}``, …) with SQL-safe literal values
from a test case array.

The literal formatter can be overridden per-dialect via the
:class:`~test_runner.common.database_executor.DatabaseExecutorFactory`.
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from .models import ValidationSteps


def build_parameters(
    parameter_names: list[str],
    test_case: list[Any],
) -> dict[str, Any]:
    """Build a parameter name -> value mapping from names and a test-case array.

    When *parameter_names* aligns 1-to-1 with *test_case*, the dict keys
    are the parameter names.  Otherwise falls back to ``param_0``, ``param_1``, etc.
    """
    if parameter_names and len(parameter_names) == len(test_case):
        return dict(zip(parameter_names, test_case))
    return {f"param_{i}": v for i, v in enumerate(test_case)}


def format_sql_literal(value: Any) -> str:
    """Default SQL literal formatter (T-SQL compatible).

    Used as the fallback when no dialect-specific formatter is provided.

    >>> format_sql_literal(None)
    'NULL'
    >>> format_sql_literal(42)
    '42'
    >>> format_sql_literal(3.14)
    '3.14'
    >>> format_sql_literal("hello")
    "'hello'"
    >>> format_sql_literal("it's")
    "'it''s'"
    >>> format_sql_literal(True)
    '1'
    """
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, str):
        escaped = value.replace("'", "''")
        return f"'{escaped}'"
    # Fallback -- convert to quoted string
    escaped = str(value).replace("'", "''")
    return f"'{escaped}'"


def render_template(
    run_template: str,
    test_case: list[Any],
    formatter: Callable[[Any], str] = format_sql_literal,
) -> str:
    """Replace positional placeholders in *run_template* with formatted values.

    Args:
        run_template: SQL string with ``{0}``, ``{1}`` … placeholders.
        test_case: Ordered list of values to substitute.
        formatter: Callable that converts a Python value to a SQL literal string.
            Defaults to :func:`format_sql_literal`.

    Returns:
        The fully rendered SQL string ready for execution.

    Raises:
        IndexError: If a placeholder index is out of range of *test_case*.
    """
    literals = [formatter(v) for v in test_case]
    return run_template.format(*literals)


def render_full_sql(
    steps: ValidationSteps,
    test_case: list[Any],
    formatter: Callable[[Any], str] = format_sql_literal,
) -> str:
    """Render the complete SQL to execute for a single test case.

    Combines ``pre_execute`` (if any) with the rendered ``run`` template.

    Args:
        steps: The validation steps from the test YAML.
        test_case: Ordered list of values to substitute.
        formatter: Callable that converts a Python value to a SQL literal string.

    Returns:
        Complete SQL string (may contain multiple statements separated by ``\\n``).
    """
    parts: list[str] = []

    if steps.pre_execute:
        parts.append(steps.pre_execute.strip())

    rendered_run = render_template(steps.run, test_case, formatter)
    parts.append(rendered_run.strip())

    return "\n".join(parts)


def render_capture_statements(
    steps: ValidationSteps,
    test_case: list[Any],
    formatter: Callable[[Any], str] = format_sql_literal,
) -> list[str]:
    """Render positional placeholders in capture statements.

    Capture statements may contain ``{0}``, ``{1}`` placeholders (just like
    the ``run`` template) as well as ``{OUT:param}`` placeholders that are
    resolved at execution time.  This function only resolves the positional
    ones; ``{OUT:...}`` tokens are left for the executor.

    Returns an empty list when *steps* has no capture statements.
    """
    if not steps.capture:
        return []

    literals = [formatter(v) for v in test_case]
    rendered: list[str] = []
    for stmt in steps.capture:
        # Only substitute numeric placeholders ({0}, {1}, ...);
        # leave {OUT:...} tokens intact.
        result = stmt
        for idx, lit in enumerate(literals):
            result = result.replace(f"{{{idx}}}", lit)
        rendered.append(result)
    return rendered
