"""Summary statistics for capture and validate runs."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class TestCaseStats:
    """Summary statistics for a full capture run."""

    total: int = 0
    """Total number of test cases processed."""

    succeeded: int = 0
    """Number of test cases that executed successfully on SQL Server."""

    failed: int = 0
    """Number of test cases where SQL Server execution raised an error."""

    baseline_files: list[str] = field(default_factory=list)
    """Paths to all baseline files written."""


@dataclass
class ValidationStats:
    """Summary statistics for a full validation run."""

    total: int = 0
    """Total number of test cases validated."""

    passed: int = 0
    """Number of test cases that passed validation."""

    failed: int = 0
    """Number of test cases that failed validation."""

    errors: int = 0
    """Number of test cases with execution errors."""

    no_baseline: int = 0
    """Number of test cases with no matching baseline."""
