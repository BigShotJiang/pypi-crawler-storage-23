"""Result of executing a test case."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class TestCaseResult:
    """Result of executing a single test case."""

    result_sets: list[list[dict[str, Any]]] = field(default_factory=list)
    """List of result sets; each is a list of row dicts."""

    row_counts: list[int] = field(default_factory=list)
    """Row count for each result set."""

    column_types: list[dict[str, str]] = field(default_factory=list)
    """Column types per result set (``COLUMN_NAME`` -> canonical type label).

    Populated at capture time from live Python values so the types survive
    JSON serialization.  Used by the validate step for schema comparison.
    """

    success: bool = True
    """Whether the execution completed without error."""

    error: Optional[str] = None
    """Error message if execution failed."""
