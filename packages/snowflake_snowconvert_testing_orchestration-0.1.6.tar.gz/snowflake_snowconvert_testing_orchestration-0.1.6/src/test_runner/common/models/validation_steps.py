"""SQL validation steps for a single dialect."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class ValidationSteps:
    """SQL validation steps for a specific dialect (source or target)."""

    run: str
    """SQL template with {0}, {1} positional placeholders."""

    pre_execute: Optional[str] = None
    """Optional SQL to run before the main command (e.g. DECLARE statements)."""

    capture: Optional[list[str]] = None
    """Optional output variables to capture after execution."""
