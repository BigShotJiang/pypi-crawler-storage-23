"""Parsed test YAML file produced by ``scai test seed``."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from .validation_steps import ValidationSteps


@dataclass
class TestFile:
    """A parsed test YAML file produced by ``scai test seed``."""

    file_path: str
    """Absolute path to the YAML file on disk."""

    source: ValidationSteps
    """Source-side execution steps (used by capture)."""

    test_cases: list[list[Any]]
    """List of test cases; each is an array of positional values."""

    target: Optional[ValidationSteps] = None
    """Target-side execution steps (used by validate). Optional."""

    procedure_name: str = ""
    """Procedure name extracted from the source ``run`` template."""

    parameter_names: list[str] = field(default_factory=list)
    """Parameter names extracted from the source ``run`` template."""

    modifies_data: Optional[bool] = None
    """Override flag indicating this procedure modifies data."""

    affected_tables: Optional[list[str]] = None
    """Override list of affected tables."""

    ignore_return_value: bool = False
    """When True, strip the procedure's return-value row (result_sets[0])
    from captured baselines.  Useful for INOUT REFCURSOR procedures where
    result_sets[0] is just the cursor/table name and the real data is in
    the capture result sets."""
