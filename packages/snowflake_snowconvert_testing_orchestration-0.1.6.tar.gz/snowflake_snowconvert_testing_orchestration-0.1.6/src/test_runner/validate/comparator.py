"""
Result comparison logic for validation -- Snowflake-native comparison.

Materializes both baseline and actual result sets into Snowflake transient tables,
then uses the data-validation framework's native ``MetadataExtractorSnowflake``
and ``SyncValidationExecutor`` to run schema, metrics, and row validation
entirely via SQL.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase
from snowflake.snowflake_data_validation.executer.sync_validation_executor import (
    SyncValidationExecutor,
)
from snowflake.snowflake_data_validation.snowflake.extractor.metadata_extractor_snowflake import (
    MetadataExtractorSnowflake,
)
from snowflake.snowflake_data_validation.snowflake.query.query_generator_snowflake import (
    QueryGeneratorSnowflake,
)
from snowflake.snowflake_data_validation.utils.constants import ValidationLevel
from snowflake.snowflake_data_validation.validation.validation_database_manager import (
    ValidationDatabaseManager,
)

from test_runner.common.config import TestRunnerConfig, ValidationConfiguration
from test_runner.validate.in_memory_comparator import InMemoryResultComparator

from .adapters.context_factory import build_context
from .adapters.model_factory import (
    build_table_column_metadata,
    build_table_configuration,
)
from .adapters.output_handler import LoggingOutputHandler
from .transient_table_manager import (
    materialize_baseline_transient_table,
    materialize_actual_transient_table,
    drop_transient_tables,
)


LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result comparator (Snowflake-native)
# ---------------------------------------------------------------------------

class ResultComparator:
    """Compare baseline and actual result sets using Snowflake-native validation.

    Materializes both sides into transient tables and delegates to
    ``SyncValidationExecutor`` for schema, metrics, and row comparison via SQL.
    """

    def __init__(
        self,
        config: TestRunnerConfig,
        connector: ConnectorBase,
        procedure_name: str = "",
    ) -> None:
        self._config = config
        self._connector = connector
        self._procedure_name = procedure_name
        self._database = config.validation_database
        self._context = build_context(config)

        vc = config.validation_configuration or ValidationConfiguration()
        self._table_config = build_table_configuration(
            procedure_name,
            schema_validation=False,
            metrics_validation=vc.metrics_validation,
            row_validation=vc.row_validation,
            max_failed_rows_number=vc.max_failed_rows_number,
        )

    def compare(
        self,
        rendered_sql: str,
        params_hash: str,
        capture_stmts: list[str] | None = None,
    ) -> dict[str, Any]:
        """Run the comparison using Snowflake temp tables.

        The baseline is read directly from the staged JSON files via
        ``LATERAL FLATTEN``.  The actual result is captured via
        ``RESULT_SCAN``.

        Args:
            rendered_sql: The rendered SQL to execute on Snowflake (CALL statement).
            params_hash: Hash of the parameters (for temp table naming).
            capture_stmts: Optional pre-rendered capture SQL statements.
                When provided, the CALL is executed first, then each capture
                statement is run and the last one's result is materialized.

        Returns:
            Dict with ``match``, ``match_level``, ``match_type``, ``differences``.
        """
        source_table = None
        target_table = None

        try:
            # Materialize the target (actual) table FIRST so we can read
            # its column types and use them when casting the baseline.
            target_table = materialize_actual_transient_table(
                self._connector,
                self._database,
                rendered_sql,
                self._procedure_name,
                params_hash,
                capture_stmts=capture_stmts,
            )

            target_col_types_precise = self._get_column_types_from_table(
                target_table, include_precision=True,
            )

            # Materialize the baseline, casting to the target's precise types
            source_table = materialize_baseline_transient_table(
                self._connector,
                self._database,
                self._procedure_name,
                params_hash,
                target_col_types=target_col_types_precise,
            )

            query_generator = QueryGeneratorSnowflake()

            source_extractor = MetadataExtractorSnowflake(
                connector=self._connector,
                query_generator=query_generator,
            )
            target_extractor = MetadataExtractorSnowflake(
                connector=self._connector,
                query_generator=query_generator,
            )

            source_col_types = self._get_column_types_from_table(source_table)
            target_col_types = self._get_column_types_from_table(target_table)

            all_columns = list(source_col_types.keys())
            index_columns = all_columns[:1] if all_columns else []

            source_row_count = self._get_row_count(source_table)
            target_row_count = self._get_row_count(target_table)

            source_metadata = build_table_column_metadata(
                source_col_types,
                source_row_count,
                self._procedure_name,
            )
            target_metadata = build_table_column_metadata(
                target_col_types,
                target_row_count,
                self._procedure_name,
            )

            table_config = build_table_configuration(
                self._procedure_name,
                schema_validation=self._table_config.validation_configuration.schema_validation,
                metrics_validation=self._table_config.validation_configuration.metrics_validation,
                row_validation=self._table_config.validation_configuration.row_validation,
                source_table=source_table,
                target_table=target_table,
                database=self._database,
                index_column_list=index_columns,
                max_failed_rows_number=self._table_config.max_failed_rows_number or 100,
                column_selection_list=all_columns,
            )

            executor = SyncValidationExecutor(
                source_extractor=source_extractor,
                target_extractor=target_extractor,
                context=self._context,
                db_manager=ValidationDatabaseManager(),
            )

            executor.execute_validation_levels(
                validation_config=table_config.validation_configuration,
                table_configuration=table_config,
                source_table_column_metadata=source_metadata,
                target_table_column_metadata=target_metadata,
            )

            return self._collect_result()

        except Exception as exc:
            LOGGER.warning("Comparison failed: %s", exc)
            return {
                "match": False,
                "match_level": "",
                "match_type": "error",
                "differences": [{"type": "ERROR", "detail": str(exc)[:500]}],
            }
        finally:
            if source_table or target_table:
                drop_transient_tables(
                    self._connector,
                    *[t for t in (source_table, target_table) if t],
                )

    def _get_column_types_from_table(
        self, table_name: str, *, include_precision: bool = False,
    ) -> dict[str, str]:
        """Query INFORMATION_SCHEMA.COLUMNS for the temp table's column types.

        When *include_precision* is True, NUMBER columns include precision
        and scale (e.g. ``NUMBER(12,2)``) — useful for casting.
        When False (default), returns bare type names that the validation
        framework expects.
        """
        parts = table_name.split(".")
        db_name = parts[-3] if len(parts) >= 3 else self._database
        schema_name = parts[-2].upper() if len(parts) >= 2 else "VALIDATION"
        tbl_name = parts[-1].upper()

        try:
            rows = self._connector.execute_query(f"""\
SELECT COLUMN_NAME, DATA_TYPE, NUMERIC_PRECISION, NUMERIC_SCALE
FROM {db_name}.INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = '{tbl_name}'
  AND TABLE_SCHEMA = '{schema_name}'
ORDER BY ORDINAL_POSITION""")
            result = {}
            for row in rows:
                values = list(row.values())
                col_name = values[0].upper()
                data_type = values[1].upper()
                if include_precision:
                    precision = values[2]
                    scale = values[3]
                    if data_type == "NUMBER" and precision is not None and scale is not None:
                        data_type = f"NUMBER({precision},{scale})"
                result[col_name] = data_type
            return result
        except Exception:
            return {}

    def _get_row_count(self, table_name: str) -> int:
        """Get the row count of a temp table."""
        try:
            rows = self._connector.execute_query(
                f"SELECT COUNT(*) FROM {table_name}"
            )
            if rows:
                row = rows[0]
                return int(list(row.values())[0])
            return 0
        except Exception:
            return 0

    def _collect_result(self) -> dict[str, Any]:
        """Collect validation results from the context's output handler."""
        handler = self._context.output_handler
        if isinstance(handler, LoggingOutputHandler) and handler.has_failures:
            result = {
                "match": False,
                "match_level": handler.failed_level or "",
                "match_type": _match_type_from_level(handler.failed_level),
                "differences": handler.differences[:10],
            }
            return result

        return {
            "match": True,
            "match_level": ValidationLevel.ROW_VALIDATION.value,
            "match_type": "data_match",
            "differences": [],
        }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def compare_results(
    config: TestRunnerConfig,
    connector: ConnectorBase,
    rendered_sql: str,
    params_hash: str,
    procedure_name: str,
    baseline: Optional[Any] = None,
    dump_baseline_and_actual: bool = False,
    capture_stmts: list[str] | None = None,
) -> dict[str, Any]:
    """Compare baseline and actual result sets.

    Routes to ``InMemoryResultComparator`` when the baseline row count is within
    ``in_memory_row_threshold``; otherwise uses the Snowflake transient-table path.
    """
    threshold = 0
    vc = config.validation_configuration
    if vc is not None:
        threshold = vc.in_memory_row_threshold

    row_count: Optional[int] = None
    if baseline is not None and getattr(baseline, "row_counts", None):
        row_count = baseline.row_counts[0]

    if threshold > 0 and row_count is not None and row_count <= threshold:
        LOGGER.info(
            "Using in-memory comparator for %s (row_count=%d, threshold=%d)",
            procedure_name, row_count, threshold,
        )
        comparator = InMemoryResultComparator(config, connector, procedure_name)
        return comparator.compare(rendered_sql, params_hash,
                                   dump_baseline_and_actual=dump_baseline_and_actual,
                                   capture_stmts=capture_stmts)

    comparator = ResultComparator(config, connector, procedure_name)
    return comparator.compare(rendered_sql, params_hash, capture_stmts=capture_stmts)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _match_type_from_level(level: str | None) -> str:
    if level == ValidationLevel.SCHEMA_VALIDATION.value:
        return "schema_mismatch"
    if level == ValidationLevel.METRICS_VALIDATION.value:
        return "metrics_mismatch"
    if level == ValidationLevel.ROW_VALIDATION.value:
        return "data_mismatch"
    return "unknown"


def errors_match(baseline_error: str, actual_error: str) -> bool:
    """Check whether two error messages represent the same error type."""
    if not baseline_error or not actual_error:
        return baseline_error == actual_error
    b_prefix = baseline_error.strip().upper().split(":")[0]
    a_prefix = actual_error.strip().upper().split(":")[0]
    return b_prefix == a_prefix
