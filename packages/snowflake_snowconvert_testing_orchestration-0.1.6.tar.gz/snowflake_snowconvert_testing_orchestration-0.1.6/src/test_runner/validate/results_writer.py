"""
Write validation results to Snowflake or a local directory.

Handles:
- Schema / table / view creation (``--create-schema``)
- Inserting individual validation results into ``VALIDATION.RESULTS``
- Writing results to local JSON/CSV files when ``--output-dir`` is supplied.

The database name is derived from the project folder name (e.g.
``MY_PROJECT.VALIDATION.RESULTS``).
"""

from __future__ import annotations

import json
import logging
import shutil
from pathlib import Path
from typing import Any

LOGGER = logging.getLogger(__name__)

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase


_SCHEMA = "VALIDATION"


# ---------------------------------------------------------------------------
# DDL templates
# ---------------------------------------------------------------------------

def _ddl_statements(db: str) -> list[str]:
    """Return all DDL statements needed for the validation schema."""
    fq = f"{db}.{_SCHEMA}"
    return [
        f"CREATE DATABASE IF NOT EXISTS {db}",
        f"CREATE SCHEMA IF NOT EXISTS {fq}",
        f"CREATE FILE FORMAT IF NOT EXISTS {fq}.JSON_FORMAT TYPE = 'JSON'",
        f"CREATE STAGE IF NOT EXISTS {fq}.BASELINES COMMENT = 'Baseline JSON files'",
        f"""\
CREATE TABLE IF NOT EXISTS {fq}.RESULTS (
    id NUMBER AUTOINCREMENT PRIMARY KEY,
    procedure_name VARCHAR(500) NOT NULL,
    params_hash VARCHAR(8) NOT NULL,
    parameters VARIANT NOT NULL,
    status VARCHAR(20) NOT NULL,
    baseline_rows NUMBER DEFAULT 0,
    actual_rows NUMBER DEFAULT 0,
    match_type VARCHAR(30),
    match_level VARCHAR(30),
    error_message VARCHAR(2000),
    differences VARIANT,
    executed_at TIMESTAMP_TZ NOT NULL,
    inserted_at TIMESTAMP_TZ DEFAULT CURRENT_TIMESTAMP()
)""",
        f"""\
CREATE TABLE IF NOT EXISTS {fq}.BASELINE_ROWS (
    id NUMBER AUTOINCREMENT PRIMARY KEY,
    procedure_name VARCHAR(500) NOT NULL,
    params_hash VARCHAR(8) NOT NULL,
    result_set_index NUMBER DEFAULT 0,
    row_index NUMBER NOT NULL,
    row_data VARIANT NOT NULL,
    column_types VARIANT,
    success BOOLEAN DEFAULT TRUE,
    error_message VARCHAR(2000),
    captured_at TIMESTAMP_TZ NOT NULL,
    inserted_at TIMESTAMP_TZ DEFAULT CURRENT_TIMESTAMP()
)""",
        f"""\
CREATE OR REPLACE VIEW {fq}.SUMMARY AS
SELECT
    procedure_name,
    COUNT(*) AS total_cases,
    SUM(CASE WHEN status = 'PASS' THEN 1 ELSE 0 END) AS passed,
    SUM(CASE WHEN status = 'FAIL' THEN 1 ELSE 0 END) AS failed,
    SUM(CASE WHEN status = 'ERROR' THEN 1 ELSE 0 END) AS errors,
    SUM(CASE WHEN status = 'NO_BASELINE' THEN 1 ELSE 0 END) AS no_baseline,
    ROUND(SUM(CASE WHEN status = 'PASS' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS pass_rate,
    MAX(executed_at) AS last_run
FROM {fq}.RESULTS
GROUP BY procedure_name
ORDER BY procedure_name""",
        f"""\
CREATE OR REPLACE VIEW {fq}.LATEST AS
SELECT *
FROM {fq}.RESULTS
WHERE (procedure_name, params_hash, executed_at) IN (
    SELECT procedure_name, params_hash, MAX(executed_at)
    FROM {fq}.RESULTS
    GROUP BY procedure_name, params_hash
)
ORDER BY procedure_name, params_hash""",
        f"""\
CREATE OR REPLACE VIEW {fq}.FAILURES AS
SELECT
    procedure_name, params_hash, parameters, status,
    baseline_rows, actual_rows, error_message, differences, executed_at
FROM {fq}.RESULTS
WHERE status IN ('FAIL', 'ERROR')
ORDER BY executed_at DESC, procedure_name""",
    ]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def create_validation_schema(connector: ConnectorBase, database: str) -> None:
    """Create the validation database, schema, tables, stage, and views. Idempotent."""
    for sql in _ddl_statements(database):
        try:
            connector.execute_statement(sql)
        except Exception as exc:
            LOGGER.warning("DDL statement failed (continuing): %s", exc)


_PRIVATE_KEYS = ("_baseline_rows", "_actual_rows")


def write_results_batch(
    connector: ConnectorBase,
    results: list[dict[str, Any]],
    database: str,
) -> None:
    """Insert multiple validation results in a single statement."""
    if not results:
        return

    # Strip debug-only keys that must not be sent to Snowflake
    for r in results:
        for k in _PRIVATE_KEYS:
            r.pop(k, None)

    fq = f"{database}.{_SCHEMA}"
    rows = []
    for r in results:
        params_json = json.dumps(r.get("params", {}), default=str).replace("'", "''")
        diffs_json = json.dumps(r.get("differences", []), default=str).replace("\\", "\\\\").replace("'", "''").replace("\n", "\\n")
        error = (r.get("error", "") or "").replace("'", "''").replace("\n", " ")

        rows.append(f"""\
SELECT
    '{r["procedure"]}' AS procedure_name,
    '{r["params_hash"]}' AS params_hash,
    PARSE_JSON('{params_json}') AS parameters,
    '{r["status"]}' AS status,
    {r.get("baseline_rows", 0)} AS baseline_rows,
    {r.get("actual_rows", 0)} AS actual_rows,
    '{r.get("match_type", "")}' AS match_type,
    '{r.get("match_level", "")}' AS match_level,
    '{error}' AS error_message,
    PARSE_JSON('{diffs_json}') AS differences,
    '{r["executed_at"]}'::TIMESTAMP_TZ AS executed_at""")

    sql = f"""\
INSERT INTO {fq}.RESULTS (
    procedure_name, params_hash, parameters, status,
    baseline_rows, actual_rows, match_type, match_level,
    error_message, differences, executed_at
)
{' UNION ALL '.join(rows)}"""
    connector.execute_statement(sql)


def write_results_local(results: list[dict[str, Any]], output_dir: Path) -> None:
    """Write validation results to *output_dir* as JSON and per-case row dumps.

    Clears *output_dir* first (removes and recreates) so each run starts fresh.

    Writes:
    - ``results.json`` — full result list including ``in_memory_diff``.
    - ``{params_hash}_baseline.json`` — baseline rows for each in-memory case.
    - ``{params_hash}_actual.json``   — actual rows returned by Snowflake.

    Args:
        results: List of result dicts as returned by the validation pipeline.
        output_dir: Directory path to write output files into.
    """
    output_dir = Path(output_dir)
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True)

    # Write per-case row dumps before stripping private keys
    for r in results:
        h = r.get("params_hash", "unknown")
        for side in ("baseline", "actual"):
            key = f"_{side}_rows"
            rows = r.pop(key, None)
            if rows is not None:
                row_path = output_dir / f"{h}_{side}.json"
                row_path.write_text(
                    json.dumps(rows, indent=2, default=str), encoding="utf-8"
                )
                LOGGER.info("Wrote %d %s row(s) to %s", len(rows), side, row_path)

    json_path = output_dir / "results.json"
    json_path.write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")
    LOGGER.info("Wrote %d result(s) to %s", len(results), json_path)
