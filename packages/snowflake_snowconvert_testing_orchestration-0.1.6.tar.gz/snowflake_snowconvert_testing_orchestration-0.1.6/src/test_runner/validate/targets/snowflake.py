"""
Snowflake executor factory.

Wraps the ``ConnectorSnowflake`` from ``snowflake-data-validation`` to provide
connection management, SQL literal formatting, and stored-procedure execution.

Column types are captured from ``cursor.description`` using the Snowflake
connector's built-in ``FIELD_ID_TO_NAME`` mapping.

When ``steps.capture`` is provided, the executor runs the CALL, collects the
OUT-parameter row, then executes each capture statement (resolving any
``{OUT:<param>}`` placeholders from the OUT row) and appends each result set.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime
from decimal import Decimal
from typing import Any, Optional, Sequence

from snowflake.connector.constants import FIELD_ID_TO_NAME
from snowflake.connector.cursor import DictCursor
from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase
from snowflake.snowflake_data_validation.snowflake.connector.connector_snowflake import (
    ConnectorSnowflake,
)
from snowflake.snowflake_data_validation.snowflake.connector.connector_factory_snowflake import (
    SnowflakeConnectorFactory,
)
from snowflake.snowflake_data_validation.snowflake.model.snowflake_named_connection import (
    SnowflakeNamedConnection,
)

from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import (
    DatabaseExecutor,
    DatabaseExecutorFactory,
    LiteralFormatter,
)
from test_runner.common.models import TestCaseResult


LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _describe_to_column_types(
    cursor_description: Sequence[Any],
) -> dict[str, str]:
    """Map Snowflake ``cursor.description`` to ``{COLUMN_NAME: type_name}``.

    Uses the connector's built-in ``FIELD_ID_TO_NAME`` mapping which
    translates integer type codes to Snowflake type names.
    """
    return {
        desc[0].upper(): FIELD_ID_TO_NAME.get(desc[1], "VARCHAR")
        for desc in cursor_description
    }


# ---------------------------------------------------------------------------
# Literal formatter (SRP: separated from factory)
# ---------------------------------------------------------------------------

class SnowflakeLiteralFormatter(LiteralFormatter):
    """Snowflake SQL literal formatting: TRUE/FALSE for bools."""

    def format_literal(self, value: Any) -> str:
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, (int, float, Decimal)):
            return str(value)
        if isinstance(value, datetime):
            return f"'{value.isoformat()}'"
        escaped = str(value).replace("'", "''")
        return f"'{escaped}'"


# ---------------------------------------------------------------------------
# Executor
# ---------------------------------------------------------------------------

class SnowflakeExecutor(DatabaseExecutor):
    """Executes SQL on Snowflake via the data-validation ``ConnectorSnowflake``.

    Captures column types from ``cursor.description`` using the Snowflake
    connector's integer type codes mapped to type names.

    When ``steps.capture`` is provided, the executor:

    1. Executes the ``run`` SQL (the CALL)
    2. Fetches the OUT-parameter row -> ``result_sets[0]``
    3. For each capture statement, resolves ``{OUT:param}`` placeholders
       from the OUT row, executes the SQL, and appends the result set
    """

    # Pattern for {OUT:param_name} placeholders in capture SQL.
    _OUT_PLACEHOLDER_RE = re.compile(r"\{OUT:(\w+)\}")

    def __init__(self, connector: ConnectorBase) -> None:
        self._connector = connector

    @property
    def connector(self) -> ConnectorBase:
        return self._connector

    def close(self) -> None:
        self._connector.close()

    def execute(self, sql: str, steps=None) -> TestCaseResult:
        capture_stmts: list[str] = []
        if steps is not None and steps.capture:
            capture_stmts = list(steps.capture)

        result = TestCaseResult()
        try:
            import snowflake.connector as sf_connector

            cursor = self._connector.connection.cursor(sf_connector.DictCursor)
            try:
                cursor.execute(sql)

                if capture_stmts:
                    out_row = self._fetch_out_row(cursor)
                    self._append_out_row(result, out_row)
                    for stmt in capture_stmts:
                        resolved = self._resolve_placeholders(stmt, out_row)
                        cursor.execute(resolved)
                        self._append_result_set(cursor, result)
                else:
                    self._append_result_set(cursor, result)
            finally:
                cursor.close()
        except Exception as exc:
            result.success = False
            result.error = str(exc)
        return result

    def execute_statement(self, sql: str) -> None:
        self._connector.execute_statement(sql)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _append_result_set(cursor: DictCursor, result: TestCaseResult) -> None:
        """Read the current cursor result set and append it to *result*."""
        description = cursor.description
        if description is None:
            result.result_sets.append([])
            result.row_counts.append(0)
            result.column_types.append({})
            return

        rows = cursor.fetchall()
        result.result_sets.append(rows)
        result.row_counts.append(len(rows))
        result.column_types.append(_describe_to_column_types(description))

    @staticmethod
    def _append_out_row(
        result: TestCaseResult,
        out_row: tuple[dict[str, Any], dict[str, str]] | None,
    ) -> None:
        """Append the OUT-parameter row (or an empty set) to *result*."""
        if out_row is not None:
            row_dict, col_types = out_row
            result.result_sets.append([row_dict])
            result.row_counts.append(1)
            result.column_types.append(col_types)
        else:
            result.result_sets.append([])
            result.row_counts.append(0)
            result.column_types.append({})

    @staticmethod
    def _fetch_out_row(
        cursor: DictCursor,
    ) -> tuple[dict[str, Any], dict[str, str]] | None:
        """Fetch the single OUT-parameter row after a CALL, if any.

        Returns ``(row_dict, column_types)`` or ``None`` when the
        statement produced no result set (e.g. DML procedures).
        """
        description = cursor.description
        if description is None:
            return None

        row = cursor.fetchone()
        if row is None:
            return None

        # DictCursor returns dicts already
        if isinstance(row, dict):
            row_dict = row
        else:
            column_names = [desc[0] for desc in description]
            row_dict = dict(zip(column_names, row))

        col_types = _describe_to_column_types(description)
        return row_dict, col_types

    @classmethod
    def _resolve_placeholders(
        cls,
        capture_sql: str,
        out_row: tuple[dict[str, Any], dict[str, str]] | None,
    ) -> str:
        """Replace ``{OUT:param_name}`` tokens with values from the OUT row.

        If the resolved value contains characters that are not valid in a
        bare SQL identifier, it is double-quoted.
        """
        if out_row is None:
            return capture_sql

        row_dict, _ = out_row

        def _replacer(match: re.Match) -> str:
            param_name = match.group(1)
            # Case-insensitive lookup against column names
            value = None
            for col_name, col_value in row_dict.items():
                if col_name.lower() == param_name.lower():
                    value = col_value
                    break
            if value is None:
                LOGGER.warning(
                    "Capture placeholder {OUT:%s} not found in OUT row "
                    "columns: %s",
                    param_name,
                    list(row_dict.keys()),
                )
                return match.group(0)  # leave unresolved

            str_value = str(value)
            # Double-quote values that aren't safe bare identifiers
            if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_.]*$", str_value):
                str_value = f'"{str_value}"'
            return str_value

        return cls._OUT_PLACEHOLDER_RE.sub(_replacer, capture_sql)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

class SnowflakeExecutorFactory(DatabaseExecutorFactory):
    """Factory for Snowflake executors backed by data-validation connectors."""

    @property
    def dialect(self) -> DatabaseDialect:
        return DatabaseDialect.SNOWFLAKE

    def build_config(self, raw: dict[str, Any]) -> SnowflakeNamedConnection:
        mode = raw.get("mode", "name")
        return SnowflakeNamedConnection(
            mode=mode,
            name=raw.get("name", ""),
        )

    def create_literal_formatter(self) -> SnowflakeLiteralFormatter:
        return SnowflakeLiteralFormatter()

    def create_executor(self, config: Any) -> SnowflakeExecutor:
        connector = SnowflakeConnectorFactory.create_connector(config)
        return SnowflakeExecutor(connector)
