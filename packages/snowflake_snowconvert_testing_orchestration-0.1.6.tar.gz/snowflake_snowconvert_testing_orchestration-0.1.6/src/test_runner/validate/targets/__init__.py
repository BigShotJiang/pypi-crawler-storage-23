"""Built-in target executor factories."""
