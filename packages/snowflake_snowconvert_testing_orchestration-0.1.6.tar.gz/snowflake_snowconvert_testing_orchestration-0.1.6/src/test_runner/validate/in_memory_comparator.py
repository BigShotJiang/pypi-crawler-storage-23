"""In-memory validation using DuckDB.

Compares baseline and actual result sets in three levels:
row counts → per-column summary stats → cell-level diffs.
Results are plain dicts suitable for JSON serialization.
"""

from __future__ import annotations

import logging
import time
from typing import Any

import duckdb
import pandas as pd

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase

from test_runner.common.config import TestRunnerConfig, ValidationConfiguration
from test_runner.validate.transient_table_manager import (
    fetch_baseline_rows,
    is_numeric_type,
    execute_with_capture,
)

LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _load_duckdb(
    baseline_rows: list[dict],
    actual_rows: list[dict],
    col_types: dict[str, str],
) -> tuple[duckdb.DuckDBPyConnection, list[str]]:
    """Register baseline and actual rows as DuckDB tables; return ``(conn, columns)``."""
    columns = list(col_types.keys()) if col_types else (
        list(baseline_rows[0].keys()) if baseline_rows else
        list(actual_rows[0].keys()) if actual_rows else []
    )

    conn = duckdb.connect()

    def _register(name: str, rows: list[dict]) -> None:
        if rows:
            df = pd.DataFrame(rows, columns=columns)
        else:
            df = pd.DataFrame(columns=columns)
        # Assign sequential 1-based row numbers for join-based cell diff
        df.insert(0, "_row", range(1, len(df) + 1))
        conn.register(name, df)

    _register("baseline", baseline_rows)
    _register("actual", actual_rows)
    return conn, columns


def _row_count_diff(conn: duckdb.DuckDBPyConnection, columns: list[str]) -> dict[str, Any]:
    """Return a row-counts section with baseline/actual counts."""
    b_count = conn.execute("SELECT COUNT(*) FROM baseline").fetchone()[0]
    a_count = conn.execute("SELECT COUNT(*) FROM actual").fetchone()[0]
    return {
        "baseline": b_count,
        "actual": a_count,
        "match": b_count == a_count,
    }


def _summary_stats_diff(
    conn: duckdb.DuckDBPyConnection,
    columns: list[str],
    col_types: dict[str, str] | None = None,
    *,
    tolerance: float,
) -> dict[str, Any]:
    """Return per-column summary stat mismatches for numeric columns.

    Non-numeric columns are skipped (handled by cell-level diff).
    Each mismatch: ``{"column": ..., "metrics": {"sum": {"baseline": x, "actual": y}, ...}}``.
    """
    mismatches: list[dict] = []

    # col_types maps column name -> Snowflake SQL type (e.g. "NUMBER", "VARCHAR").
    # is_numeric_type checks the type string against known numeric type prefixes
    # (_NUMERIC_TYPE_PREFIXES in transient_table_manager) so only numeric columns
    # get aggregate stats; text/date columns are handled by cell-level diff instead.
    for col in columns:
        if col_types and not is_numeric_type(col_types.get(col, "")):
            continue  # skip VARCHAR, DATE, BOOLEAN, etc.
        quoted = f'"{col}"'
        try:
            b_stats = conn.execute(
                f"SELECT COUNT(*) - COUNT({quoted}) AS null_count,"
                f" MIN(TRY_CAST({quoted} AS DOUBLE)) AS min_val,"
                f" MAX(TRY_CAST({quoted} AS DOUBLE)) AS max_val,"
                f" AVG(TRY_CAST({quoted} AS DOUBLE)) AS avg_val,"
                f" SUM(TRY_CAST({quoted} AS DOUBLE)) AS sum_val"
                f" FROM baseline"
            ).fetchone()
            a_stats = conn.execute(
                f"SELECT COUNT(*) - COUNT({quoted}) AS null_count,"
                f" MIN(TRY_CAST({quoted} AS DOUBLE)) AS min_val,"
                f" MAX(TRY_CAST({quoted} AS DOUBLE)) AS max_val,"
                f" AVG(TRY_CAST({quoted} AS DOUBLE)) AS avg_val,"
                f" SUM(TRY_CAST({quoted} AS DOUBLE)) AS sum_val"
                f" FROM actual"
            ).fetchone()
        except Exception as exc:  # noqa: BLE001
            LOGGER.debug("Stats computation skipped for column %r: %s", col, exc)
            continue

        b_null, b_min, b_max, b_avg, b_sum = b_stats
        a_null, a_min, a_max, a_avg, a_sum = a_stats

        # All numeric metrics use tolerance-aware float comparison.
        # Both-None means TRY_CAST failed on both sides (text column) → equal.
        candidates = [
            ("null_count", b_null, a_null),
            ("min", b_min, a_min),
            ("max", b_max, a_max),
            ("avg", b_avg, a_avg),
            ("sum", b_sum, a_sum),
        ]
        metric_diffs = {}
        for metric, b_val, a_val in candidates:
            if metric == "null_count":
                if b_val != a_val:
                    metric_diffs[metric] = {"baseline": b_val, "actual": a_val}
            else:
                if b_val is None and a_val is None:
                    continue  # both non-numeric (text col) — skip
                if b_val is None or a_val is None or abs(b_val - a_val) > tolerance:
                    metric_diffs[metric] = {"baseline": b_val, "actual": a_val}

        if metric_diffs:
            mismatches.append({"column": col, "metrics": metric_diffs})

    return {
        "match": len(mismatches) == 0,
        "mismatches": mismatches,
    }


def _cell_diffs(
    conn: duckdb.DuckDBPyConnection,
    columns: list[str],
    col_types: dict[str, str] | None = None,
    *,
    tolerance: float,
    max_cell_diffs: int,
) -> list[dict]:
    """Return up to *max_cell_diffs* differing cells, joined on row position."""
    diffs: list[dict] = []

    for col in columns:
        if len(diffs) >= max_cell_diffs:
            break
        quoted = f'"{col}"'
        # Numeric columns use tolerance-aware comparison; others use exact equality.
        is_numeric = col_types and is_numeric_type(col_types.get(col, ""))
        if is_numeric:
            where_clause = (
                f"(b.{quoted} IS DISTINCT FROM a.{quoted}) AND "
                f"NOT (b.{quoted} IS NULL AND a.{quoted} IS NULL) AND "
                f"(b.{quoted} IS NULL OR a.{quoted} IS NULL OR "
                f"ABS(TRY_CAST(b.{quoted} AS DOUBLE) - TRY_CAST(a.{quoted} AS DOUBLE)) > {tolerance})"
            )
        else:
            where_clause = f"b.{quoted} IS DISTINCT FROM a.{quoted}"
        try:
            rows = conn.execute(f"""\
SELECT b._row, b.{quoted} AS baseline_val, a.{quoted} AS actual_val
FROM baseline b
JOIN actual a ON b._row = a._row
WHERE {where_clause}
LIMIT {max_cell_diffs - len(diffs)}
""").fetchall()
        except Exception as exc:  # noqa: BLE001
            LOGGER.debug("Cell diff skipped for column %r: %s", col, exc)
            continue

        for row_num, bv, av in rows:
            diffs.append({
                "row": int(row_num),
                "column": col,
                "baseline": bv,
                "actual": av,
            })

    return diffs


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def compare_in_memory(
    baseline_rows: list[dict],
    actual_rows: list[dict],
    col_types: dict[str, str],
    tolerance: float = ValidationConfiguration().tolerance,
    max_cell_diffs: int = ValidationConfiguration().max_cell_diffs,
) -> dict[str, Any]:
    """Compare two result sets in memory using DuckDB.

    Returns a dict with ``match``, ``row_counts``, ``summary_stats``, and ``cell_diffs``.
    """
    conn, columns = _load_duckdb(baseline_rows, actual_rows, col_types)

    try:
        rc = _row_count_diff(conn, columns)
        ss = _summary_stats_diff(conn, columns, col_types=col_types, tolerance=tolerance)
        cd: list[dict] = []
        if rc["match"]:
            cd = _cell_diffs(conn, columns, col_types=col_types,
                             tolerance=tolerance, max_cell_diffs=max_cell_diffs)
        else:
            LOGGER.warning(
                "Row count mismatch (baseline=%d, actual=%d); skipping cell-level diff.",
                rc["baseline"], rc["actual"],
            )
    finally:
        conn.close()

    overall_match = rc["match"] and ss["match"] and len(cd) == 0
    return {
        "match": overall_match,
        "row_counts": rc,
        "summary_stats": ss,
        "cell_diffs": cd,
    }


class InMemoryResultComparator:
    """Orchestrates in-memory comparison for a single test case.

    Fetches the baseline from the Snowflake stage, executes the procedure,
    and delegates to :func:`compare_in_memory`.
    """

    def __init__(self, config: TestRunnerConfig, connector: ConnectorBase, procedure_name: str) -> None:
        self._config = config
        self._connector = connector
        self._procedure_name = procedure_name

    def compare(
        self,
        rendered_sql: str,
        params_hash: str,
        dump_baseline_and_actual: bool = False,
        capture_stmts: list[str] | None = None,
    ) -> dict[str, Any]:
        """Fetch baseline from stage, execute *rendered_sql*, and compare in memory.

        When *capture_stmts* is provided, the CALL is executed first, its
        OUT row is used to resolve ``{OUT:param}`` placeholders, then each
        capture statement is executed and the **last** one's result set
        becomes the actual rows for comparison.

        When *dump_baseline_and_actual* is True, attaches ``_baseline_rows`` and
        ``_actual_rows`` to the result for ``write_results_local`` to persist.
        """
        database: str = self._config.validation_database or ""

        t0 = time.monotonic()
        baseline_rows, col_types = fetch_baseline_rows(
            self._connector, database, params_hash
        )
        LOGGER.info(
            "[timing] fetch_baseline_rows (%d rows): %.3fs",
            len(baseline_rows), time.monotonic() - t0,
        )

        cursor = self._connector.connection.cursor()
        try:
            t1 = time.monotonic()
            cursor.execute(f"USE DATABASE {database}")
            execute_with_capture(cursor, rendered_sql, capture_stmts)

            col_names = (
                [d[0] for d in cursor.description] if cursor.description else list(col_types.keys())
            )
            raw_rows = cursor.fetchall() or []
            actual_rows = [dict(zip(col_names, r)) for r in raw_rows]
            LOGGER.info(
                "[timing] execute CALL + fetchall (%d rows): %.3fs",
                len(actual_rows), time.monotonic() - t1,
            )
        except Exception as exc:
            LOGGER.warning("In-memory comparison failed during execution: %s", exc)
            return {
                "match": False,
                "match_type": "error",
                "match_level": "in_memory",
                "differences": [{"type": "ERROR", "detail": str(exc)[:500]}],
            }
        finally:
            cursor.close()

        vc = self._config.validation_configuration or ValidationConfiguration()
        tolerance: float = vc.tolerance
        max_cell_diffs: int = vc.max_cell_diffs

        t2 = time.monotonic()
        diff = compare_in_memory(
            baseline_rows, actual_rows, col_types,
            tolerance=tolerance, max_cell_diffs=max_cell_diffs,
        )
        LOGGER.info("[timing] compare_in_memory (duckdb): %.3fs", time.monotonic() - t2)

        human_diffs: list = []
        if not diff["match"]:
            rc = diff["row_counts"]
            if not rc["match"]:
                human_diffs.append(
                    f"row_counts: baseline={rc['baseline']} actual={rc['actual']}"
                )
            for m in diff["summary_stats"]["mismatches"]:
                for metric, vals in m["metrics"].items():
                    human_diffs.append(
                        f"column={m['column']}  metric={metric}"
                        f"  baseline={vals['baseline']}  actual={vals['actual']}"
                    )
            for d in diff["cell_diffs"][:10]:
                human_diffs.append(
                    f"cell diff row={d['row']} col={d['column']} "
                    f"baseline={d['baseline']!r} actual={d['actual']!r}"
                )

        match_type = "data_match" if diff["match"] else (
            "row_count_mismatch" if not diff["row_counts"]["match"] else
            "metrics_mismatch" if diff["summary_stats"]["mismatches"] else
            "data_mismatch"
        )

        result: dict[str, Any] = {
            "match": diff["match"],
            "match_type": match_type,
            "match_level": "in_memory",
            "differences": human_diffs,
            "in_memory_diff": diff,
        }
        if dump_baseline_and_actual:
            result["_baseline_rows"] = baseline_rows
            result["_actual_rows"] = actual_rows
        return result
