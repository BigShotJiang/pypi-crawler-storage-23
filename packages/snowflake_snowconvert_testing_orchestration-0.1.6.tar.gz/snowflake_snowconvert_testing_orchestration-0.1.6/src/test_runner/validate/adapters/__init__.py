"""Adapter layer bridging test-runner in-memory data to data-validation models."""
