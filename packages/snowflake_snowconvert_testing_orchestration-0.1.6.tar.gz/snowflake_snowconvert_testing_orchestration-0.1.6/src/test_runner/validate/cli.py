"""CLI entry point for ``test-runner validate``."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="test-validate",
        description="Validate Snowflake procedures against captured baselines.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("-c", "--connection", type=str, default=None, dest="snowflake_connection")
    parser.add_argument("--baseline-dir", type=Path, default=None)
    parser.add_argument("--baseline-stage", type=str, default=None)
    parser.add_argument("--pattern", type=str, default=".*")
    parser.add_argument("--create-schema", action="store_true", default=False)
    parser.add_argument("-w", "--watch", action="store_true", default=False)
    parser.add_argument("-q", "--quiet", action="store_true", default=False)
    return parser


def main(argv: list[str] | None = None) -> None:
    from test_runner.common.container import create_container
    from .runner import run_validate

    parser = _build_parser()
    args = parser.parse_args(argv)

    try:
        container = create_container(str(args.project_root))
        stats = run_validate(
            config=container.config(),
            factory_registry=container.factory_registry(),
            project_root=args.project_root,
            snowflake_connection=args.snowflake_connection,
            baseline_dir=args.baseline_dir,
            baseline_stage=args.baseline_stage,
            pattern=args.pattern,
            create_schema=args.create_schema,
        )
    except (FileNotFoundError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    sys.exit(stats.failed + stats.errors)


if __name__ == "__main__":
    main()
