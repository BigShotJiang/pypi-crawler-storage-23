"""
Unified CLI entry point for ``test-runner``.

Creates the DI container and dispatches to ``capture`` or ``validate``.

Usage::

    test-runner capture [OPTIONS]
    test-runner validate [OPTIONS]
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path


def _configure_logging(level_name: str) -> None:
    level = getattr(logging, level_name.upper(), logging.WARNING)
    logging.basicConfig(
        level=level,
        format="%(asctime)s.%(msecs)03d  %(levelname)-8s  %(name)s  %(message)s",
        datefmt="%H:%M:%S",
    )


def main(argv: list[str] | None = None) -> None:
    """Unified CLI entry point with subcommands."""
    parser = argparse.ArgumentParser(
        prog="test-runner",
        description="SCAI Code Verification -- capture and validate stored procedure baselines.",
    )
    parser.add_argument(
        "--log-level",
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Set logging verbosity (default: WARNING)",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    capture_parser = subparsers.add_parser("capture", help="Execute procedures on source and save baselines")
    _add_capture_args(capture_parser)

    validate_parser = subparsers.add_parser("validate", help="Execute procedures on Snowflake and compare against baselines")
    _add_validate_args(validate_parser)

    args = parser.parse_args(argv)
    _configure_logging(args.log_level)

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    if args.command == "capture":
        _run_capture(args)
    elif args.command == "validate":
        _run_validate(args)


# ---------------------------------------------------------------------------
# Capture
# ---------------------------------------------------------------------------

def _add_capture_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("--source-connection", type=str, default=None)
    parser.add_argument("--baseline-dir", type=Path, default=None)
    parser.add_argument("-c", "--connection", type=str, default=None, dest="snowflake_connection")
    parser.add_argument("-w", "--watch", action="store_true", default=False)
    parser.add_argument("-q", "--quiet", action="store_true", default=False)


def _run_capture(args: argparse.Namespace) -> None:
    from test_runner.common.container import create_container
    from test_runner.capture.runner import run_capture

    try:
        container = create_container(
            str(args.project_root),
            source_connection=args.source_connection,
        )
        stats = run_capture(
            config=container.config(),
            factory_registry=container.factory_registry(),
            project_root=args.project_root,
            baseline_dir=args.baseline_dir,
            snowflake_connection=args.snowflake_connection,
        )
    except (FileNotFoundError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    sys.exit(stats.failed)


# ---------------------------------------------------------------------------
# Validate
# ---------------------------------------------------------------------------

def _add_validate_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    parser.add_argument("-c", "--connection", type=str, default=None, dest="snowflake_connection")
    parser.add_argument("--baseline-dir", type=Path, default=None)
    parser.add_argument("--baseline-stage", type=str, default=None)
    parser.add_argument("--pattern", type=str, default=".*")
    parser.add_argument("--create-schema", action="store_true", default=False)
    parser.add_argument("-w", "--watch", action="store_true", default=False)
    parser.add_argument("-q", "--quiet", action="store_true", default=False)
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument(
        "--dump-baseline-and-actual", action="store_true", default=False,
        help="Write baseline and actual rows as JSON files inside --output-dir (default: off)",
    )


def _run_validate(args: argparse.Namespace) -> None:
    from test_runner.common.container import create_container
    from test_runner.validate.runner import run_validate

    try:
        container = create_container(str(args.project_root))
        stats = run_validate(
            config=container.config(),
            factory_registry=container.factory_registry(),
            project_root=args.project_root,
            snowflake_connection=args.snowflake_connection,
            baseline_dir=args.baseline_dir,
            baseline_stage=args.baseline_stage,
            pattern=args.pattern,
            create_schema=args.create_schema,
            output_dir=args.output_dir,
            dump_baseline_and_actual=args.dump_baseline_and_actual,
        )
    except (FileNotFoundError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    sys.exit(stats.failed + stats.errors)


if __name__ == "__main__":
    main()
