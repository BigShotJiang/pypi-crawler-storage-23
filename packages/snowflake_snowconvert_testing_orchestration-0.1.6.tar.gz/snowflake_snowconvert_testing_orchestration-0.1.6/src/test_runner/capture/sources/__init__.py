"""Built-in source executor factories."""
