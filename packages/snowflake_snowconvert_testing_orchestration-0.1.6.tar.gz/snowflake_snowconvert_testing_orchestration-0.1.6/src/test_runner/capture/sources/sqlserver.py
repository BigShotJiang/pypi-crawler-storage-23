"""
SQL Server executor factory.

Wraps the ``ConnectorSqlServer`` from ``snowflake-data-validation`` to provide
connection management, SQL literal formatting, and stored-procedure execution.

Column types are captured via ``sp_describe_first_result_set`` which returns
the real SQL Server type names.  These are then mapped to Snowflake types
through the framework's YAML type-mapping templates.
"""

from __future__ import annotations

import logging
from typing import Any, Sequence

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase
from snowflake.snowflake_data_validation.sqlserver.model.sqlserver_credentials_connection import (
    SqlServerCredentialsConnection,
)
from snowflake.snowflake_data_validation.sqlserver.connector.connector_factory_sql_server import (
    SqlServerConnectorFactory,
)
from snowflake.snowflake_data_validation.utils.constants import Platform

from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import (
    DatabaseExecutor,
    DatabaseExecutorFactory,
    LiteralFormatter,
)
from test_runner.common.models import TestCaseResult
from test_runner.common.type_mapping import base_type_name, load_datatypes_mapping


LOGGER = logging.getLogger(__name__)


def _parse_sp_describe_rows(
    meta_rows: Sequence[Any],
    datatypes_mappings: dict[str, str] | None = None,
) -> dict[str, str]:
    """Build column types from ``sp_describe_first_result_set`` output.

    Each row contains the column name at index 2 and the SQL Server type
    name (e.g. ``"int"``, ``"nvarchar(100)"``) at index 5.  The base type
    name is looked up in *datatypes_mappings* to produce the Snowflake type.

    The base type name is looked up in *datatypes_mappings* to produce
    the Snowflake type.
    """
    column_types: dict[str, str] = {}
    for row in meta_rows:
        col_name: str = row[2]
        system_type_name: str = row[5]
        base_type = base_type_name(system_type_name)
        if datatypes_mappings:
            snowflake_type = datatypes_mappings.get(base_type, base_type)
        else:
            snowflake_type = base_type
        column_types[col_name.upper()] = snowflake_type
    return column_types


# ---------------------------------------------------------------------------
# Literal formatter (SRP: separated from factory)
# ---------------------------------------------------------------------------

class SqlServerLiteralFormatter(LiteralFormatter):
    """T-SQL literal formatting: 1/0 for bools, single-quoted strings."""

    def format_literal(self, value: Any) -> str:
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "1" if value else "0"
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, str):
            escaped = value.replace("'", "''")
            return f"'{escaped}'"
        escaped = str(value).replace("'", "''")
        return f"'{escaped}'"


# ---------------------------------------------------------------------------
# Executor
# ---------------------------------------------------------------------------

class SqlServerExecutor(DatabaseExecutor):
    """Executes SQL on SQL Server via the data-validation ``ConnectorSqlServer``.

    Uses the raw pyodbc connection to execute queries and captures real
    column type names via ``sp_describe_first_result_set``.
    """

    def __init__(
        self,
        connector: ConnectorBase,
        datatypes_mappings: dict[str, str] | None = None,
    ) -> None:
        self._connector = connector
        self._datatypes_mappings = datatypes_mappings

    @property
    def connector(self) -> ConnectorBase:
        return self._connector

    def close(self) -> None:
        self._connector.close()

    def execute(self, sql: str, steps=None) -> TestCaseResult:
        result = TestCaseResult()
        try:
            with self._connector.connection.cursor() as cursor:
                cursor.execute(sql)
                column_names = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()

            row_dicts = [dict(zip(column_names, row)) for row in rows]
            result.result_sets = [row_dicts]
            result.row_counts = [len(row_dicts)]
            result.column_types = [self._describe_types(sql)]
        except Exception as exc:
            result.success = False
            result.error = str(exc)
        return result

    def _describe_types(self, sql: str) -> dict[str, str]:
        """Get real column type names via ``sp_describe_first_result_set``."""
        try:
            with self._connector.connection.cursor() as cursor:
                cursor.execute(
                    "EXEC sp_describe_first_result_set @tsql = ?", sql,
                )
                meta_rows = cursor.fetchall()
            return _parse_sp_describe_rows(meta_rows, self._datatypes_mappings)
        except Exception as exc:
            LOGGER.warning("sp_describe_first_result_set failed: %s", exc)
            return {}


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

class SqlServerExecutorFactory(DatabaseExecutorFactory):
    """Factory for SQL Server executors backed by data-validation connectors."""

    @property
    def dialect(self) -> DatabaseDialect:
        return DatabaseDialect.SQL_SERVER

    @staticmethod
    def _to_yes_no(value: Any, default: str) -> str:
        """Normalise bool/string values to the 'yes'/'no' expected by ODBC Driver 18."""
        if isinstance(value, bool):
            return "yes" if value else "no"
        if isinstance(value, str):
            return "yes" if value.lower() in ("yes", "true", "1") else "no"
        return default

    def build_config(self, raw: dict[str, Any]) -> SqlServerCredentialsConnection:
        # Accept both SCAI-generated keys (server_url, user, auth_method) and
        # the canonical test-runner keys (host, username, mode).
        # SCAI uses auth_method="standard" which maps to sql_auth.
        _AUTH_METHOD_MAP = {"standard": "sql_auth", "credentials": "sql_auth"}
        raw_mode = raw.get("mode") or raw.get("auth_method", "sql_auth")
        mode = _AUTH_METHOD_MAP.get(raw_mode, raw_mode)
        return SqlServerCredentialsConnection(
            mode=mode,
            host=raw.get("host") or raw.get("server_url", "localhost"),
            port=int(raw.get("port", 1433)),
            database=raw.get("database", ""),
            username=raw.get("username") or raw.get("user"),
            password=raw.get("password"),
            client_id=raw.get("client_id"),
            client_secret=raw.get("client_secret"),
            tenant_id=raw.get("tenant_id"),
            trust_server_certificate=self._to_yes_no(
                raw.get("trust_server_certificate"), "no"
            ),
            encrypt=self._to_yes_no(raw.get("encrypt"), "yes"),
        )

    def create_literal_formatter(self) -> SqlServerLiteralFormatter:
        return SqlServerLiteralFormatter()

    def create_executor(self, config: Any) -> SqlServerExecutor:
        connector = SqlServerConnectorFactory.create_connector(config)
        datatypes_mappings = _load_datatypes_mapping()
        return SqlServerExecutor(connector, datatypes_mappings)
