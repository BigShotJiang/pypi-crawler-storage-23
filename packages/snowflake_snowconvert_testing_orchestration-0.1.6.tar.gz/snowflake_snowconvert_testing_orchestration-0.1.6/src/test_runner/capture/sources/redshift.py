"""
Redshift executor factory.

Wraps the ``ConnectorRedshift`` from ``snowflake-data-validation`` to provide
connection management, SQL literal formatting, and stored-procedure execution.

Column types are captured from ``cursor.description`` and mapped to Snowflake
types through the framework's YAML type-mapping templates.
"""

from __future__ import annotations

import logging
import re
from typing import Any

from snowflake.snowflake_data_validation.connector.connector_base import ConnectorBase
from snowflake.snowflake_data_validation.redshift.model.redshift_credentials_connection import (
    RedshiftCredentialsConnection,
)
from snowflake.snowflake_data_validation.redshift.connector.connector_factory_redshift import (
    RedshiftConnectorFactory,
)
from snowflake.snowflake_data_validation.utils.constants import Platform

from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import (
    DatabaseExecutor,
    DatabaseExecutorFactory,
    LiteralFormatter,
)
from test_runner.common.models import TestCaseResult
from test_runner.common.type_mapping import base_type_name, load_datatypes_mapping


LOGGER = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Literal formatter
# ---------------------------------------------------------------------------

class RedshiftLiteralFormatter(LiteralFormatter):
    """PostgreSQL/Redshift literal formatting: TRUE/FALSE for bools, single-quoted strings."""

    def format_literal(self, value: Any) -> str:
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, str):
            escaped = value.replace("'", "''")
            return f"'{escaped}'"
        escaped = str(value).replace("'", "''")
        return f"'{escaped}'"


# ---------------------------------------------------------------------------
# Executor
# ---------------------------------------------------------------------------

class RedshiftExecutor(DatabaseExecutor):
    """Executes SQL on Redshift via the data-validation ``ConnectorRedshift``.

    Uses the raw ``redshift_connector`` connection to execute queries and
    captures column type names from ``cursor.description``.

    Every execution is wrapped in a transaction (``BEGIN`` / ``ROLLBACK``).
    When ``steps.capture`` is provided, the OUT-parameter row from the
    CALL is collected first, then each capture statement is executed
    within the same transaction so that cursors remain accessible for
    ``FETCH``.  Placeholders of the form ``{OUT:<param_name>}`` in
    capture statements are resolved from the OUT-parameter result row.
    """

    # Pattern for {OUT:param_name} placeholders in capture SQL.
    _OUT_PLACEHOLDER_RE = re.compile(r"\{OUT:(\w+)\}")

    def __init__(
        self,
        connector: ConnectorBase,
        datatypes_mappings: dict[str, str] | None = None,
    ) -> None:
        self._connector = connector
        self._datatypes_mappings = datatypes_mappings
        # Enable autocommit so a failed statement doesn't poison subsequent
        # executions with "current transaction is aborted" errors.
        try:
            self._connector.connection.autocommit = True
        except Exception:
            pass

    @property
    def connector(self) -> ConnectorBase:
        return self._connector

    def close(self) -> None:
        self._connector.close()

    def execute(self, sql: str, steps=None) -> TestCaseResult:
        capture_stmts: list[str] = []
        if steps is not None and steps.capture:
            capture_stmts = list(steps.capture)

        result = TestCaseResult()
        conn = self._connector.connection
        saved_autocommit = conn.autocommit

        conn.autocommit = False
        cursor = conn.cursor()
        try:
            cursor.execute("BEGIN")
            cursor.execute(sql)

            if capture_stmts:
                out_row = self._fetch_out_row(cursor)
                self._append_out_row(result, out_row)
                for stmt in capture_stmts:
                    resolved = self._resolve_placeholders(stmt, out_row)
                    cursor.execute(resolved)
                    self._append_result_set(cursor, result)
            else:
                self._append_result_set(cursor, result)

            cursor.execute("ROLLBACK")
        except Exception as exc:
            self._try_rollback(cursor)
            result.success = False
            result.error = str(exc)
        finally:
            cursor.close()
            self._try_restore_autocommit(conn, saved_autocommit)

        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _append_result_set(self, cursor: Any, result: TestCaseResult) -> None:
        """Read the current cursor result set and append it to *result*."""
        description = cursor.description
        if description is None:
            result.result_sets.append([])
            result.row_counts.append(0)
            result.column_types.append({})
            return

        column_names = [desc[0] for desc in description]
        rows = cursor.fetchall()
        row_dicts = [dict(zip(column_names, row)) for row in rows]
        result.result_sets.append(row_dicts)
        result.row_counts.append(len(row_dicts))
        result.column_types.append(self._describe_types(cursor))

    @staticmethod
    def _append_out_row(
        result: TestCaseResult,
        out_row: tuple[dict[str, Any], dict[str, str]] | None,
    ) -> None:
        """Append the OUT-parameter row (or an empty set) to *result*."""
        if out_row is not None:
            row_dict, col_types = out_row
            result.result_sets.append([row_dict])
            result.row_counts.append(1)
            result.column_types.append(col_types)
        else:
            result.result_sets.append([])
            result.row_counts.append(0)
            result.column_types.append({})

    def _fetch_out_row(
        self, cursor: Any,
    ) -> tuple[dict[str, Any], dict[str, str]] | None:
        """Fetch the single OUT-parameter row after a CALL, if any.

        Returns ``(row_dict, column_types)`` or ``None`` when the
        statement produced no result set (e.g. DML procedures).
        """
        description = cursor.description
        if description is None:
            return None

        column_names = [desc[0] for desc in description]
        row = cursor.fetchone()
        if row is None:
            return None

        row_dict = dict(zip(column_names, row))
        col_types = self._describe_types(cursor)
        return row_dict, col_types

    def _resolve_placeholders(
        self,
        capture_sql: str,
        out_row: tuple[dict[str, Any], dict[str, str]] | None,
    ) -> str:
        """Replace ``{OUT:param_name}`` tokens with values from the OUT row.

        If the resolved value contains characters that are not valid in a
        bare SQL identifier (e.g. ``<unnamed portal 1>``), it is
        double-quoted so that ``FETCH ALL FROM "<unnamed portal 1>"``
        works correctly.
        """
        if out_row is None:
            return capture_sql

        row_dict, _ = out_row

        def _replacer(match: re.Match) -> str:
            param_name = match.group(1)
            # Case-insensitive lookup against column names
            value = None
            for col_name, col_value in row_dict.items():
                if col_name.lower() == param_name.lower():
                    value = col_value
                    break
            if value is None:
                LOGGER.warning(
                    "Capture placeholder {OUT:%s} not found in OUT row "
                    "columns: %s",
                    param_name,
                    list(row_dict.keys()),
                )
                return match.group(0)  # leave unresolved

            str_value = str(value)
            # Double-quote values that aren't safe bare identifiers
            if not re.match(r"^[a-zA-Z_][a-zA-Z0-9_.]*$", str_value):
                str_value = f'"{str_value}"'
            return str_value

        return self._OUT_PLACEHOLDER_RE.sub(_replacer, capture_sql)

    @staticmethod
    def _try_rollback(cursor: Any) -> None:
        try:
            cursor.execute("ROLLBACK")
        except Exception:
            pass

    @staticmethod
    def _try_restore_autocommit(conn: Any, saved: bool) -> None:
        try:
            conn.autocommit = saved
        except Exception:
            pass

    def _describe_types(
        self, cursor: Any,
    ) -> dict[str, str]:
        """Map column OIDs to Snowflake type names via ``pg_catalog.pg_type``.

        Uses a separate cursor to query the catalog, matching the pattern
        used by the SQL Server executor (which queries
        ``sp_describe_first_result_set``).
        """
        description = cursor.description
        if not description:
            return {}

        oid_to_col: dict[int, list[str]] = {}
        for desc in description:
            col_name = desc[0].upper()
            type_code = desc[1]
            oid_to_col.setdefault(type_code, []).append(col_name)

        unique_oids = list(oid_to_col.keys())
        oid_list = ", ".join(str(o) for o in unique_oids)

        oid_name_map: dict[int, str] = {}
        try:
            meta_cursor = self._connector.connection.cursor()
            try:
                meta_cursor.execute(
                    f"SELECT oid, typname FROM pg_catalog.pg_type "
                    f"WHERE oid IN ({oid_list})"
                )
                for row in meta_cursor.fetchall():
                    oid_name_map[int(row[0])] = str(row[1])
            finally:
                meta_cursor.close()
        except Exception as exc:
            LOGGER.warning("pg_catalog.pg_type lookup failed: %s", exc)

        column_types: dict[str, str] = {}
        for desc in description:
            col_name = desc[0].upper()
            type_code = desc[1]
            type_name = oid_name_map.get(type_code, str(type_code))
            base_type = base_type_name(type_name)
            if self._datatypes_mappings:
                snowflake_type = self._datatypes_mappings.get(base_type, base_type)
            else:
                snowflake_type = base_type
            column_types[col_name] = snowflake_type
        return column_types


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

class RedshiftExecutorFactory(DatabaseExecutorFactory):
    """Factory for Redshift executors backed by data-validation connectors."""

    @property
    def dialect(self) -> DatabaseDialect:
        return DatabaseDialect.REDSHIFT

    def build_config(self, raw: dict[str, Any]) -> RedshiftCredentialsConnection:
        return RedshiftCredentialsConnection(
            mode=raw.get("mode", "credentials"),
            host=raw.get("host", "localhost"),
            port=int(raw.get("port", 5439)),
            database=raw.get("database", ""),
            username=raw.get("username", ""),
            password=raw.get("password", ""),
        )

    def create_literal_formatter(self) -> RedshiftLiteralFormatter:
        return RedshiftLiteralFormatter()

    def create_executor(self, config: Any) -> RedshiftExecutor:
        connector = RedshiftConnectorFactory.create_connector(config)
        datatypes_mappings = load_datatypes_mapping(Platform.REDSHIFT)
        return RedshiftExecutor(connector, datatypes_mappings)
