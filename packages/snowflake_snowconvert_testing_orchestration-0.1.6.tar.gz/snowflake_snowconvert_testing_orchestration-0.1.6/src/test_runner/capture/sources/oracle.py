"""
Oracle executor factory (stub).

Provides the factory structure for Oracle PL/SQL sources. The executor
itself raises ``NotImplementedError`` until ``oracledb`` support is added.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from test_runner.common.models import TestCaseResult
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import (
    DatabaseExecutor,
    DatabaseExecutorFactory,
    LiteralFormatter,
)


# ---------------------------------------------------------------------------
# Connection config
# ---------------------------------------------------------------------------

@dataclass
class OracleConnectionConfig:
    """Oracle connection parameters."""

    host: str = "localhost"
    port: int = 1521
    service_name: str = ""
    sid: str = ""
    username: str = ""
    password: str = ""


# ---------------------------------------------------------------------------
# Literal formatter
# ---------------------------------------------------------------------------

class OracleLiteralFormatter(LiteralFormatter):
    """Oracle PL/SQL literal formatting."""

    def format_literal(self, value: Any) -> str:
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "'TRUE'" if value else "'FALSE'"
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, str):
            escaped = value.replace("'", "''")
            return f"'{escaped}'"
        escaped = str(value).replace("'", "''")
        return f"'{escaped}'"


# ---------------------------------------------------------------------------
# Executor (stub)
# ---------------------------------------------------------------------------

class OracleExecutor(DatabaseExecutor):
    """Placeholder executor for Oracle -- not yet implemented."""

    def __init__(self, config: OracleConnectionConfig) -> None:
        self._config = config

    def close(self) -> None:
        pass

    def execute(self, sql: str, steps=None) -> TestCaseResult:
        raise NotImplementedError("Oracle executor is not yet implemented.")


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

class OracleExecutorFactory(DatabaseExecutorFactory):
    """Factory for Oracle executors."""

    @property
    def dialect(self) -> DatabaseDialect:
        return DatabaseDialect.ORACLE

    def build_config(self, raw: dict[str, Any]) -> OracleConnectionConfig:
        return OracleConnectionConfig(
            host=raw.get("host", "localhost"),
            port=int(raw.get("port", 1521)),
            service_name=raw.get("service_name", ""),
            sid=raw.get("sid", ""),
            username=raw.get("username", ""),
            password=raw.get("password", ""),
        )

    def create_literal_formatter(self) -> OracleLiteralFormatter:
        return OracleLiteralFormatter()

    def create_executor(self, config: Any) -> OracleExecutor:
        return OracleExecutor(config)
