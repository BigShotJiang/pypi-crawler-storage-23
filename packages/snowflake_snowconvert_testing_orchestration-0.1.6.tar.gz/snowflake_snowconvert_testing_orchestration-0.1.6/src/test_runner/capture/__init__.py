"""Capture command -- execute test cases on source and save baselines."""
