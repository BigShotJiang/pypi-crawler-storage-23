# Code Review — In-Memory Validation Changes

## 1. Configuration & Wiring

| # | Feedback | Done |
|---|----------|------|
| 1.1 | `tolerance` and in-memory threshold should be driven by `test_config` | ✅ |
| 1.2 | Make `epsilon` / `tolerance` a config-level param | ✅ |
| 1.3 | Make `max_cell_diffs` a config param | ✅ |

---

## 2. Code Design & Structure

| # | Feedback | Done |
|---|----------|------|
| 2.1 | Why choose module + methods rather than class structure? (`in_memory_comparator`) | ☐ |
| 2.2 | `InMemoryResultComparator` inherits from `object`? (redundant base class) | ☐ |
| 2.3 | Why do we need `_drain_report_buffer_failures`? (`comparator.py`) | ☐ |
| 2.4 | Why use CSV file format type for Snowflake stage? | ☐ |
| 2.5 | Why use CSV output in `results_writer`? | ☐ |

---

## 3. Code Simplification & Cleanup

| # | Feedback | Done |
|---|----------|------|
| 3.1 | Can we simplify row count logic in `baseline_loader`? | ☐ |
| 3.2 | Make `duckdb` a mandatory dependency — remove local import | ☐ |
| 3.3 | `rm validate_output` dir if it is already present | ☐ |
| 3.4 | Fix Python formatting | ☐ |

---

## 4. Type Annotations & Return Types

| # | Feedback | Done |
|---|----------|------|
| 4.1 | Return type for `_load_duckdb` is missing / wrong | ☐ |
| 4.2 | How does it know that a column is numeric? (type detection logic clarity) | ☐ |

---

## 5. Documentation

| # | Feedback | Done |
|---|----------|------|
| 5.1 | Make `fetch_baseline_rows` docstring concise | ☐ |
| 5.2 | Make `in_memory_comparator` module / function docstrings concise | ☐ |

---

## 6. Test Coverage & Quality

| # | Feedback | Done |
|---|----------|------|
| 6.1 | Did we add tests for all new code? | ☐ |
| 6.2 | Do the changes pass lint? | ☐ |
