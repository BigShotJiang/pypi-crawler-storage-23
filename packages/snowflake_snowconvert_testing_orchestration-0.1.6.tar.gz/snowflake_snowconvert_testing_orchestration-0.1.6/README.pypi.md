# snowflake-snowconvert-testing-orchestration

Capture and validate stored procedure baselines during database migrations to Snowflake. Part of the [SnowConvert](https://www.snowflake.com/en/data-cloud/snowconvert/) migration toolchain.

## What it does

When migrating stored procedures from SQL Server, Oracle, or other platforms to Snowflake, this tool automates the verification process:

1. **Capture** -- Execute stored procedures on the source database and save their results as baseline files.
2. **Validate** -- Execute the same procedures on Snowflake and compare the results against the captured baselines.
3. **Report** -- Generate detailed validation reports covering schema, metrics, and row-level comparisons.

## Installation

```bash
pip install snowflake-snowconvert-testing-orchestration
```

## Quick start

### Capture baselines from source

```bash
test-runner capture --project-root /path/to/project
```

### Validate on Snowflake

```bash
test-runner validate --project-root /path/to/project -c my_snowflake_connection
```

## Configuration

Create a `settings/test_config.yaml` in your project directory:

```yaml
source_platform: sqlserver
target_platform: snowflake

source_connection:
  mode: credentials
  host: 127.0.0.1
  port: 1433
  database: testdb
  username: sa
  password: "your-password"

target_connection:
  mode: name
  name: your_snowflake_connection

validation_configuration:
  schema_validation: true
  metrics_validation: true
  row_validation: true
```

Define test cases for each procedure in `artifacts/<database>/<schema>/procedure/<Name>/test/<name>.yml`:

```yaml
validation:
  source:
    steps:
      run: |-
        EXECUTE testdb.dbo.GetAllProducts
  target:
    steps:
      run: |-
        CALL TESTDB.DBO.GETALLPRODUCTS()
  test_cases:
    - []
```

## Library usage

```python
from test_runner import create_container, run_capture, run_validate

container = create_container("my_project")
config = container.config()
registry = container.factory_registry()

capture_stats = run_capture(config=config, factory_registry=registry, project_root="my_project")
validate_stats = run_validate(config=config, factory_registry=registry, project_root="my_project")
```

## Requirements

- Python >= 3.10
- Access to a source database (SQL Server, Oracle, etc.)
- A Snowflake account with SnowSQL or connector configuration

## Related packages

- [snowflake-data-validation](https://pypi.org/project/snowflake-data-validation/) -- Data validation framework for Snowflake migrations

## License

Snowflake Conversion Software Terms
