"""Shared fixtures for test-runner tests."""

from __future__ import annotations

import shutil
import textwrap
from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture()
def tmp_project(tmp_path: Path) -> Path:
    """Create a minimal SCAI project directory tree in *tmp_path*.

    Layout::

        tmp_path/
            settings/test_config.yaml
            artifacts/master/dbo/procedure/GetProducts/test/getproducts.a1b2c3d4.yml
            artifacts/master/dbo/procedure/GetCustomerOrders/test/getcustomerorders.b2c3d4e5.yml
    """
    # settings
    settings_dir = tmp_path / "settings"
    settings_dir.mkdir()
    (settings_dir / "test_config.yaml").write_text(textwrap.dedent("""\
        source_platform: sqlserver
        target_platform: snowflake

        source_connection:
          mode: credentials
          host: localhost
          port: 1433
          database: TestDB
          schema: dbo
          username: sa
          password: secret

        target_connection:
          mode: name
          name: my-snowflake
          database: TestDB
    """))

    # artifacts -- simple procedure
    simple_dir = tmp_path / "artifacts" / "master" / "dbo" / "procedure" / "GetProducts" / "test"
    simple_dir.mkdir(parents=True)
    shutil.copy(FIXTURES_DIR / "simple_procedure.yml", simple_dir / "getproducts.a1b2c3d4.yml")

    # artifacts -- parameterized procedure
    param_dir = tmp_path / "artifacts" / "master" / "dbo" / "procedure" / "GetCustomerOrders" / "test"
    param_dir.mkdir(parents=True)
    shutil.copy(FIXTURES_DIR / "parameterized_procedure.yml", param_dir / "getcustomerorders.b2c3d4e5.yml")

    return tmp_path


@pytest.fixture()
def tmp_project_with_rpt(tmp_project: Path) -> Path:
    """Extend *tmp_project* with an RPT-schema test YAML file."""
    rpt_dir = tmp_project / "artifacts" / "master" / "rpt" / "procedure" / "GetProducts" / "test"
    rpt_dir.mkdir(parents=True)
    shutil.copy(FIXTURES_DIR / "rpt_procedure.yml", rpt_dir / "getproducts.c3d4e5f6.yml")
    return tmp_project
