"""Tests for test_runner.common.connection_reader."""

from __future__ import annotations

from pathlib import Path

import pytest

from test_runner.common.connection_reader import (
    load_connections_toml,
    resolve_named_connection,
)


SAMPLE_TOML = """\
[connections.default]
host = "127.0.0.1"
port = 1433
database = "testdb"
username = "sa"
password = "secret"
trust_server_certificate = "yes"
encrypt = "no"

[connections.staging]
host = "staging-host"
port = 1433
database = "staging_db"
username = "app_user"
password = "staging_pw"
"""


@pytest.fixture()
def toml_project(tmp_path: Path) -> Path:
    """Create a project-level .snowflake/snowct/sqlserver.toml."""
    toml_dir = tmp_path / ".snowflake" / "snowct"
    toml_dir.mkdir(parents=True)
    (toml_dir / "sqlserver.toml").write_text(SAMPLE_TOML)
    return tmp_path


@pytest.fixture()
def toml_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Patch Path.home() and create user-level sqlserver.toml."""
    home = tmp_path / "fake_home"
    toml_dir = home / ".snowflake" / "snowct"
    toml_dir.mkdir(parents=True)
    (toml_dir / "sqlserver.toml").write_text(SAMPLE_TOML)
    monkeypatch.setattr(Path, "home", staticmethod(lambda: home))
    return home


# ---------------------------------------------------------------------------
# load_connections_toml
# ---------------------------------------------------------------------------

class TestLoadConnectionsToml:
    def test_loads_from_project_root(self, toml_project: Path):
        conns = load_connections_toml("sqlserver.toml", toml_project)
        assert "default" in conns
        assert conns["default"]["host"] == "127.0.0.1"
        assert conns["default"]["port"] == 1433

    def test_loads_from_home_fallback(self, toml_home: Path):
        conns = load_connections_toml("sqlserver.toml", project_root=None)
        assert "default" in conns
        assert conns["default"]["database"] == "testdb"

    def test_project_takes_priority_over_home(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ):
        home = tmp_path / "home"
        home_dir = home / ".snowflake" / "snowct"
        home_dir.mkdir(parents=True)
        (home_dir / "sqlserver.toml").write_text(
            '[connections.default]\nhost = "home-host"\n'
        )
        monkeypatch.setattr(Path, "home", staticmethod(lambda: home))

        proj = tmp_path / "proj"
        proj_dir = proj / ".snowflake" / "snowct"
        proj_dir.mkdir(parents=True)
        (proj_dir / "sqlserver.toml").write_text(
            '[connections.default]\nhost = "project-host"\n'
        )

        conns = load_connections_toml("sqlserver.toml", project_root=proj)
        assert conns["default"]["host"] == "project-host"

    def test_returns_empty_when_no_file(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setattr(Path, "home", staticmethod(lambda: tmp_path / "nope"))
        conns = load_connections_toml("sqlserver.toml", project_root=tmp_path)
        assert conns == {}

    def test_multiple_connections(self, toml_project: Path):
        conns = load_connections_toml("sqlserver.toml", toml_project)
        assert "default" in conns
        assert "staging" in conns
        assert conns["staging"]["host"] == "staging-host"


# ---------------------------------------------------------------------------
# resolve_named_connection
# ---------------------------------------------------------------------------

class TestResolveNamedConnection:
    def test_resolves_default(self, toml_project: Path):
        result = resolve_named_connection("default", "sqlserver.toml", toml_project)
        assert result["host"] == "127.0.0.1"
        assert result["database"] == "testdb"
        assert result["username"] == "sa"

    def test_resolves_staging(self, toml_project: Path):
        result = resolve_named_connection("staging", "sqlserver.toml", toml_project)
        assert result["host"] == "staging-host"
        assert result["database"] == "staging_db"

    def test_raises_key_error_for_missing_name(self, toml_project: Path):
        with pytest.raises(KeyError, match="nonexistent"):
            resolve_named_connection("nonexistent", "sqlserver.toml", toml_project)

    def test_error_message_lists_available(self, toml_project: Path):
        with pytest.raises(KeyError, match="default"):
            resolve_named_connection("nope", "sqlserver.toml", toml_project)

    def test_returns_plain_dict(self, toml_project: Path):
        result = resolve_named_connection("default", "sqlserver.toml", toml_project)
        assert isinstance(result, dict)

    def test_home_fallback(self, toml_home: Path):
        result = resolve_named_connection("default", "sqlserver.toml")
        assert result["host"] == "127.0.0.1"
