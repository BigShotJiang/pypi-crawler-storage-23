"""Tests for test_runner.common.type_mapping."""

from __future__ import annotations

import pytest

from test_runner.common.type_mapping import base_type_name


# ---------------------------------------------------------------------------
# base_type_name
# ---------------------------------------------------------------------------

class TestBaseTypeName:
    def test_simple_type(self):
        assert base_type_name("integer") == "INTEGER"

    def test_type_with_precision(self):
        assert base_type_name("nvarchar(100)") == "NVARCHAR"

    def test_type_with_precision_and_scale(self):
        assert base_type_name("decimal(18,2)") == "DECIMAL"

    def test_character_varying(self):
        assert base_type_name("character varying(256)") == "CHARACTER"

    def test_int_identity(self):
        assert base_type_name("int identity") == "INT"

    def test_uppercase_input(self):
        assert base_type_name("VARCHAR") == "VARCHAR"

    def test_mixed_case(self):
        assert base_type_name("Decimal(10,2)") == "DECIMAL"

    def test_leading_whitespace_stripped(self):
        assert base_type_name("  varchar(50)") == "VARCHAR"

    def test_trailing_whitespace_stripped(self):
        assert base_type_name("int  ") == "INT"

    def test_underscore_in_type(self):
        assert base_type_name("timestamp_ntz") == "TIMESTAMP_NTZ"

    def test_empty_string(self):
        assert base_type_name("") == ""

    def test_numeric_only_input(self):
        assert base_type_name("123") == "123"

    def test_bool(self):
        assert base_type_name("bool") == "BOOL"

    def test_float8(self):
        assert base_type_name("float8") == "FLOAT8"

    def test_int4(self):
        assert base_type_name("int4") == "INT4"

    def test_bpchar(self):
        assert base_type_name("bpchar") == "BPCHAR"
