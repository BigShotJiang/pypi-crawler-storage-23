"""Tests for named connection resolution in test_runner.common.config."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from test_runner.common.config import load_config, ValidationConfiguration
from test_runner.common.database_dialect import DatabaseDialect


SQLSERVER_TOML = """\
[connections.default]
host = "toml-host"
port = 1433
database = "toml_db"
username = "toml_user"
password = "toml_pw"
trust_server_certificate = "yes"
encrypt = "no"

[connections.staging]
host = "staging-host"
port = 2433
database = "staging_db"
username = "stg_user"
password = "stg_pw"
"""


def _write_config(project: Path, yaml_text: str) -> None:
    settings = project / "settings"
    settings.mkdir(parents=True, exist_ok=True)
    (settings / "test_config.yaml").write_text(textwrap.dedent(yaml_text))


def _write_toml(project: Path, content: str = SQLSERVER_TOML) -> None:
    toml_dir = project / ".snowflake" / "snowct"
    toml_dir.mkdir(parents=True, exist_ok=True)
    (toml_dir / "sqlserver.toml").write_text(content)


# ---------------------------------------------------------------------------
# YAML mode: name  ->  resolves from .snowflake/snowct/sqlserver.toml
# ---------------------------------------------------------------------------

class TestNamedSourceConnection:
    def test_mode_name_resolves_from_toml(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: name
              name: default
        """)
        _write_toml(tmp_path)

        cfg = load_config(tmp_path)
        assert cfg.source_connection_raw["host"] == "toml-host"
        assert cfg.source_connection_raw["database"] == "toml_db"
        assert cfg.source_connection_raw["username"] == "toml_user"

    def test_mode_name_selects_correct_connection(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: name
              name: staging
        """)
        _write_toml(tmp_path)

        cfg = load_config(tmp_path)
        assert cfg.source_connection_raw["host"] == "staging-host"
        assert cfg.source_connection_raw["port"] == 2433

    def test_yaml_overrides_take_precedence(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: name
              name: default
              database: override_db
        """)
        _write_toml(tmp_path)

        cfg = load_config(tmp_path)
        assert cfg.source_connection_raw["host"] == "toml-host"
        assert cfg.source_connection_raw["database"] == "override_db"

    def test_missing_connection_raises(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: name
              name: nonexistent
        """)
        _write_toml(tmp_path)

        with pytest.raises(KeyError, match="nonexistent"):
            load_config(tmp_path)

    def test_credentials_mode_unchanged(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: credentials
              host: direct-host
              database: direct_db
              username: direct_user
              password: direct_pw
        """)

        cfg = load_config(tmp_path)
        assert cfg.source_connection_raw["host"] == "direct-host"
        assert cfg.source_connection_raw["mode"] == "credentials"


# ---------------------------------------------------------------------------
# CLI --source-connection override
# ---------------------------------------------------------------------------

class TestSourceConnectionOverride:
    def test_cli_override_resolves_named_connection(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: credentials
              host: yaml-host
        """)
        _write_toml(tmp_path)

        cfg = load_config(tmp_path, source_connection="default")
        assert cfg.source_connection_raw["host"] == "toml-host"
        assert cfg.source_connection_raw["database"] == "toml_db"

    def test_cli_override_replaces_yaml_connection(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            source_connection:
              mode: credentials
              host: yaml-host
              database: yaml_db
        """)
        _write_toml(tmp_path)

        cfg = load_config(tmp_path, source_connection="staging")
        assert cfg.source_connection_raw["host"] == "staging-host"
        assert cfg.source_connection_raw["database"] == "staging_db"


# ---------------------------------------------------------------------------
# in_memory_row_threshold
# ---------------------------------------------------------------------------

class TestInMemoryThreshold:
    def test_default_threshold_is_10000(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            validation_configuration:
              schema_validation: false
        """)
        cfg = load_config(tmp_path)
        assert cfg.validation_configuration is not None
        assert cfg.validation_configuration.in_memory_row_threshold == 10_000

    def test_custom_threshold_parsed(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            validation_configuration:
              in_memory_row_threshold: 500
        """)
        cfg = load_config(tmp_path)
        assert cfg.validation_configuration.in_memory_row_threshold == 500

    def test_zero_threshold_disables_in_memory(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            validation_configuration:
              in_memory_row_threshold: 0
        """)
        cfg = load_config(tmp_path)
        assert cfg.validation_configuration.in_memory_row_threshold == 0

    def test_default_on_dataclass_without_yaml(self):
        vc = ValidationConfiguration()
        assert vc.in_memory_row_threshold == 10_000


# ---------------------------------------------------------------------------
# tolerance and max_cell_diffs inside validation_configuration
# ---------------------------------------------------------------------------

class TestComparisonFields:
    def test_tolerance_default(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            validation_configuration:
              schema_validation: false
        """)
        cfg = load_config(tmp_path)
        assert cfg.validation_configuration.tolerance == 0.001

    def test_max_cell_diffs_default(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            validation_configuration:
              schema_validation: false
        """)
        cfg = load_config(tmp_path)
        assert cfg.validation_configuration.max_cell_diffs == 1_000

    def test_tolerance_parsed(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            validation_configuration:
              tolerance: 0.01
        """)
        cfg = load_config(tmp_path)
        assert cfg.validation_configuration.tolerance == 0.01

    def test_max_cell_diffs_parsed(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            validation_configuration:
              max_cell_diffs: 50
        """)
        cfg = load_config(tmp_path)
        assert cfg.validation_configuration.max_cell_diffs == 50

    def test_both_fields_parsed_together(self, tmp_path: Path):
        _write_config(tmp_path, """\
            source_platform: sqlserver
            validation_configuration:
              tolerance: 0.005
              max_cell_diffs: 200
        """)
        cfg = load_config(tmp_path)
        assert cfg.validation_configuration.tolerance == 0.005
        assert cfg.validation_configuration.max_cell_diffs == 200

    def test_defaults_on_dataclass(self):
        vc = ValidationConfiguration()
        assert vc.tolerance == 0.001
        assert vc.max_cell_diffs == 1_000
