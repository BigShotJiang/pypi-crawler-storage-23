"""Tests for test_runner.template."""

from __future__ import annotations

import pytest

from test_runner.common.models import ValidationSteps
from test_runner.common.template import (
    format_sql_literal,
    render_capture_statements,
    render_full_sql,
    render_template,
)


# ---------------------------------------------------------------------------
# format_sql_literal
# ---------------------------------------------------------------------------


class TestFormatSqlLiteral:
    def test_none(self):
        assert format_sql_literal(None) == "NULL"

    def test_int(self):
        assert format_sql_literal(42) == "42"

    def test_float(self):
        assert format_sql_literal(3.14) == "3.14"

    def test_string(self):
        assert format_sql_literal("hello") == "'hello'"

    def test_string_with_quotes(self):
        assert format_sql_literal("it's") == "'it''s'"

    def test_bool_true(self):
        assert format_sql_literal(True) == "1"

    def test_bool_false(self):
        assert format_sql_literal(False) == "0"

    def test_date_string(self):
        assert format_sql_literal("2025-12-09") == "'2025-12-09'"


# ---------------------------------------------------------------------------
# render_template
# ---------------------------------------------------------------------------


class TestRenderTemplate:
    def test_basic_substitution(self):
        template = "EXEC dbo.P @a = {0}, @b = {1}"
        result = render_template(template, [42, "hello"])
        assert result == "EXEC dbo.P @a = 42, @b = 'hello'"

    def test_null_value(self):
        template = "EXEC dbo.P @a = {0}"
        result = render_template(template, [None])
        assert result == "EXEC dbo.P @a = NULL"

    def test_index_out_of_range(self):
        template = "EXEC dbo.P @a = {0}, @b = {1}"
        with pytest.raises(IndexError, match="index 1"):
            render_template(template, [42])

    def test_no_placeholders(self):
        template = "EXECUTE master.dbo.GetProducts"
        result = render_template(template, [])
        assert result == "EXECUTE master.dbo.GetProducts"

    def test_string_escaping(self):
        template = "EXEC dbo.P @name = {0}"
        result = render_template(template, ["O'Brien"])
        assert result == "EXEC dbo.P @name = 'O''Brien'"


# ---------------------------------------------------------------------------
# render_full_sql
# ---------------------------------------------------------------------------


class TestRenderFullSql:
    def test_run_only(self):
        steps = ValidationSteps(run="EXEC dbo.P @a = {0}")
        result = render_full_sql(steps, [1])
        assert result == "EXEC dbo.P @a = 1"

    def test_with_pre_execute(self):
        steps = ValidationSteps(
            run="EXEC dbo.P @a = {0}",
            pre_execute="DECLARE @Out INT;",
        )
        result = render_full_sql(steps, [1])
        assert "DECLARE @Out INT;" in result
        assert "EXEC dbo.P @a = 1" in result
        lines = result.split("\n")
        assert lines[0] == "DECLARE @Out INT;"
        assert lines[1] == "EXEC dbo.P @a = 1"

    def test_empty_pre_execute_ignored(self):
        steps = ValidationSteps(run="EXEC dbo.P @a = {0}", pre_execute="")
        result = render_full_sql(steps, [1])
        assert result == "EXEC dbo.P @a = 1"


# ---------------------------------------------------------------------------
# render_capture_statements
# ---------------------------------------------------------------------------


class TestRenderCaptureStatements:
    def test_no_capture_returns_empty(self):
        steps = ValidationSteps(run="CALL sp()")
        assert render_capture_statements(steps, []) == []

    def test_none_capture_returns_empty(self):
        steps = ValidationSteps(run="CALL sp()", capture=None)
        assert render_capture_statements(steps, []) == []

    def test_positional_placeholders_rendered(self):
        """Positional placeholders are replaced with formatted literals.

        Note: the formatter wraps strings in single quotes, so a capture
        template like ``IDENTIFIER('{1}')`` produces double-quoting
        (``IDENTIFIER(''my_table'')``).  This mirrors how ``render_template``
        works for the ``run`` statement and is the expected behavior.
        """
        steps = ValidationSteps(
            run="CALL sp({0}, '{1}')",
            capture=["SELECT * FROM IDENTIFIER({1})"],
        )
        result = render_capture_statements(steps, [10, "my_table"])
        assert result == ["SELECT * FROM IDENTIFIER('my_table')"]

    def test_out_placeholders_preserved(self):
        steps = ValidationSteps(
            run="CALL sp()",
            capture=["SELECT * FROM {OUT:result_table} ORDER BY id"],
        )
        result = render_capture_statements(steps, [])
        assert result == ["SELECT * FROM {OUT:result_table} ORDER BY id"]

    def test_mixed_positional_and_out_placeholders(self):
        steps = ValidationSteps(
            run="CALL sp({0})",
            capture=["SELECT * FROM {OUT:tbl} WHERE category = {0}"],
        )
        result = render_capture_statements(steps, ["VIP"])
        assert result == ["SELECT * FROM {OUT:tbl} WHERE category = 'VIP'"]

    def test_multiple_capture_statements(self):
        """Multiple capture statements each get placeholders resolved.

        Like ``test_positional_placeholders_rendered``, templates should
        use bare ``{0}`` (not ``'{0}'``) because the formatter adds quotes.
        """
        steps = ValidationSteps(
            run="CALL sp({0})",
            capture=[
                "SELECT * FROM IDENTIFIER({0})",
                "SELECT COUNT(*) FROM IDENTIFIER({0})",
            ],
        )
        result = render_capture_statements(steps, ["temp_tbl"])
        assert result == [
            "SELECT * FROM IDENTIFIER('temp_tbl')",
            "SELECT COUNT(*) FROM IDENTIFIER('temp_tbl')",
        ]
