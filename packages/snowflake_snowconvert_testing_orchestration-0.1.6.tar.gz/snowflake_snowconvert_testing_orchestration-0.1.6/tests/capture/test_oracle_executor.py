"""Tests for test_runner.capture.sources.oracle (stub executor)."""

from __future__ import annotations

import pytest

from test_runner.capture.sources.oracle import (
    OracleConnectionConfig,
    OracleExecutor,
    OracleExecutorFactory,
    OracleLiteralFormatter,
)
from test_runner.common.database_dialect import DatabaseDialect


# ---------------------------------------------------------------------------
# OracleConnectionConfig
# ---------------------------------------------------------------------------

class TestOracleConnectionConfig:
    def test_defaults(self):
        cfg = OracleConnectionConfig()
        assert cfg.host == "localhost"
        assert cfg.port == 1521
        assert cfg.service_name == ""
        assert cfg.sid == ""
        assert cfg.username == ""
        assert cfg.password == ""

    def test_custom_values(self):
        cfg = OracleConnectionConfig(
            host="ora-host",
            port=2521,
            service_name="ORCL",
            sid="orcl",
            username="admin",
            password="pass",
        )
        assert cfg.host == "ora-host"
        assert cfg.port == 2521
        assert cfg.service_name == "ORCL"
        assert cfg.sid == "orcl"


# ---------------------------------------------------------------------------
# OracleLiteralFormatter
# ---------------------------------------------------------------------------

class TestOracleLiteralFormatter:
    def test_null(self):
        fmt = OracleLiteralFormatter()
        assert fmt.format_literal(None) == "NULL"

    def test_bool_true(self):
        fmt = OracleLiteralFormatter()
        assert fmt.format_literal(True) == "'TRUE'"

    def test_bool_false(self):
        fmt = OracleLiteralFormatter()
        assert fmt.format_literal(False) == "'FALSE'"

    def test_integer(self):
        fmt = OracleLiteralFormatter()
        assert fmt.format_literal(42) == "42"

    def test_float(self):
        fmt = OracleLiteralFormatter()
        assert fmt.format_literal(3.14) == "3.14"

    def test_string(self):
        fmt = OracleLiteralFormatter()
        assert fmt.format_literal("hello") == "'hello'"

    def test_string_with_single_quotes(self):
        fmt = OracleLiteralFormatter()
        assert fmt.format_literal("it's") == "'it''s'"

    def test_non_string_non_numeric_value(self):
        fmt = OracleLiteralFormatter()
        from datetime import date
        result = fmt.format_literal(date(2026, 1, 1))
        assert result == "'2026-01-01'"


# ---------------------------------------------------------------------------
# OracleExecutorFactory
# ---------------------------------------------------------------------------

class TestOracleExecutorFactory:
    def test_dialect(self):
        factory = OracleExecutorFactory()
        assert factory.dialect == DatabaseDialect.ORACLE

    def test_build_config_defaults(self):
        factory = OracleExecutorFactory()
        cfg = factory.build_config({})
        assert isinstance(cfg, OracleConnectionConfig)
        assert cfg.host == "localhost"
        assert cfg.port == 1521

    def test_build_config_custom(self):
        factory = OracleExecutorFactory()
        cfg = factory.build_config({
            "host": "oracle-host",
            "port": "2521",
            "service_name": "ORCL",
            "sid": "orcl",
            "username": "admin",
            "password": "secret",
        })
        assert cfg.host == "oracle-host"
        assert cfg.port == 2521
        assert cfg.service_name == "ORCL"
        assert cfg.sid == "orcl"
        assert cfg.username == "admin"
        assert cfg.password == "secret"

    def test_create_literal_formatter(self):
        factory = OracleExecutorFactory()
        fmt = factory.create_literal_formatter()
        assert isinstance(fmt, OracleLiteralFormatter)

    def test_create_executor_returns_oracle_executor(self):
        factory = OracleExecutorFactory()
        cfg = factory.build_config({})
        executor = factory.create_executor(cfg)
        assert isinstance(executor, OracleExecutor)


# ---------------------------------------------------------------------------
# OracleExecutor (stub)
# ---------------------------------------------------------------------------

class TestOracleExecutor:
    def test_execute_raises_not_implemented(self):
        cfg = OracleConnectionConfig()
        executor = OracleExecutor(cfg)
        with pytest.raises(NotImplementedError, match="not yet implemented"):
            executor.execute("SELECT 1")

    def test_close_does_not_raise(self):
        cfg = OracleConnectionConfig()
        executor = OracleExecutor(cfg)
        executor.close()

    def test_connector_property_returns_none_by_default(self):
        cfg = OracleConnectionConfig()
        executor = OracleExecutor(cfg)
        assert executor.connector is None
