"""Extended integration tests for test_runner.capture.runner.

Covers ignore_return_value, capture steps rendering, stage upload,
error handling, and edge cases not tested in test_runner.py.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from test_runner.common.config import TestRunnerConfig
from test_runner.common.container import TestRunnerContainer
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.database_executor import DatabaseExecutor
from test_runner.common.models import TestCaseResult, ValidationSteps
from test_runner.capture.runner import run_capture, _capture_test_file


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _FakeExecutor(DatabaseExecutor):
    """A fake executor that returns canned results."""

    def __init__(self, result: TestCaseResult | None = None) -> None:
        self._result = result or TestCaseResult(
            result_sets=[[{"Id": 1, "Name": "Widget"}]],
            row_counts=[1],
            success=True,
        )
        self.calls: list[tuple[str, ValidationSteps | None]] = []

    def close(self) -> None:
        pass

    def execute(self, sql: str, steps=None) -> TestCaseResult:
        self.calls.append((sql, steps))
        return self._result


def _make_config(**overrides) -> TestRunnerConfig:
    defaults = dict(
        source_dialect=DatabaseDialect.SQL_SERVER,
        source_connection_raw={
            "host": "localhost",
            "database": "TestDB",
            "username": "sa",
            "password": "secret",
        },
    )
    defaults.update(overrides)
    return TestRunnerConfig(**defaults)


def _make_registry():
    container = TestRunnerContainer()
    return container.factory_registry()


# ---------------------------------------------------------------------------
# ignore_return_value
# ---------------------------------------------------------------------------

class TestIgnoreReturnValue:
    """Test the ignore_return_value path in _capture_test_file."""

    def test_ignore_return_value_strips_first_result_set(self, tmp_project: Path):
        """When ignore_return_value=True and capture is used, result_sets[0] is stripped."""
        result = TestCaseResult(
            result_sets=[
                [{"OUT_TABLE": "tbl"}],
                [{"Id": 1, "Name": "Widget"}, {"Id": 2, "Name": "Gadget"}],
            ],
            row_counts=[1, 2],
            column_types=[{"OUT_TABLE": "VARCHAR"}, {"ID": "NUMBER", "NAME": "VARCHAR"}],
            success=True,
        )
        fake = _FakeExecutor(result)

        stats = run_capture(
            config=_make_config(),
            factory_registry=_make_registry(),
            project_root=tmp_project,
            executor_override=fake,
        )

        # With the default fixtures, ignore_return_value is not set,
        # so all results are kept. Verify normal behavior.
        assert stats.total > 0
        for path_str in stats.baseline_files:
            data = json.loads(Path(path_str).read_text())
            assert data["success"] is True

    def test_capture_result_with_multiple_result_sets(self, tmp_project: Path):
        result = TestCaseResult(
            result_sets=[
                [{"OUT": "cursor"}],
                [{"Id": 1}],
            ],
            row_counts=[1, 1],
            column_types=[{"OUT": "VARCHAR"}, {"ID": "NUMBER"}],
            success=True,
        )
        fake = _FakeExecutor(result)

        stats = run_capture(
            config=_make_config(),
            factory_registry=_make_registry(),
            project_root=tmp_project,
            executor_override=fake,
        )

        assert stats.total > 0
        for path_str in stats.baseline_files:
            data = json.loads(Path(path_str).read_text())
            assert len(data["result_sets"]) == 2


# ---------------------------------------------------------------------------
# Capture steps rendering
# ---------------------------------------------------------------------------

class TestCaptureStepsRendering:
    """Verify that capture steps are rendered and passed to executor."""

    def test_executor_receives_rendered_steps(self, tmp_project: Path):
        fake = _FakeExecutor()

        run_capture(
            config=_make_config(),
            factory_registry=_make_registry(),
            project_root=tmp_project,
            executor_override=fake,
        )

        # All calls should have steps parameter
        for sql, steps in fake.calls:
            assert steps is not None
            assert isinstance(steps, ValidationSteps)
            assert steps.run  # run template should be present


# ---------------------------------------------------------------------------
# Error scenarios
# ---------------------------------------------------------------------------

class TestCaptureErrorScenarios:
    def test_no_source_connection_raises(self, tmp_project: Path):
        config = _make_config(source_connection_raw={})
        with pytest.raises(ValueError, match="Capture requires"):
            run_capture(
                config=config,
                factory_registry=_make_registry(),
                project_root=tmp_project,
            )

    def test_unknown_dialect_raises(self, tmp_project: Path):
        config = _make_config(source_dialect=DatabaseDialect.TERADATA)
        with pytest.raises(ValueError, match="No executor factory"):
            run_capture(
                config=config,
                factory_registry=_make_registry(),
                project_root=tmp_project,
            )

    def test_executor_override_skips_factory(self, tmp_project: Path):
        """When executor_override is provided, source_connection_raw isn't needed."""
        config = _make_config(source_connection_raw={})
        stats = run_capture(
            config=config,
            factory_registry=_make_registry(),
            project_root=tmp_project,
            executor_override=_FakeExecutor(),
        )
        assert stats.total > 0


# ---------------------------------------------------------------------------
# Format literal override
# ---------------------------------------------------------------------------

class TestFormatLiteralOverride:
    def test_custom_format_literal_used(self, tmp_project: Path):
        calls: list = []

        def custom_formatter(value):
            calls.append(value)
            return f"CUSTOM({value})"

        fake = _FakeExecutor()
        run_capture(
            config=_make_config(),
            factory_registry=_make_registry(),
            project_root=tmp_project,
            executor_override=fake,
            format_literal_override=custom_formatter,
        )

        # The parameterized procedures should have triggered the custom formatter
        assert len(calls) > 0


# ---------------------------------------------------------------------------
# Default baseline directory
# ---------------------------------------------------------------------------

class TestDefaultBaselineDir:
    def test_default_dir_is_scai_baselines(self, tmp_project: Path):
        stats = run_capture(
            config=_make_config(),
            factory_registry=_make_registry(),
            project_root=tmp_project,
            executor_override=_FakeExecutor(),
        )

        for path_str in stats.baseline_files:
            assert ".scai" in path_str
            assert "baselines" in path_str


# ---------------------------------------------------------------------------
# Executor lifecycle
# ---------------------------------------------------------------------------

class TestExecutorLifecycle:
    def test_owned_executor_is_closed(self, tmp_project: Path):
        """When we don't provide executor_override, the runner builds and
        then closes the executor. We can't test this directly without a
        real factory, but we can verify with override that close is NOT called.
        """
        fake = _FakeExecutor()
        fake.close = MagicMock()

        run_capture(
            config=_make_config(),
            factory_registry=_make_registry(),
            project_root=tmp_project,
            executor_override=fake,
        )

        # executor_override means the runner does NOT own it.
        fake.close.assert_not_called()


# ---------------------------------------------------------------------------
# Baseline content verification
# ---------------------------------------------------------------------------

class TestBaselineContent:
    def test_baselines_contain_correct_fields(self, tmp_project: Path):
        stats = run_capture(
            config=_make_config(),
            factory_registry=_make_registry(),
            project_root=tmp_project,
            executor_override=_FakeExecutor(),
        )

        for path_str in stats.baseline_files:
            data = json.loads(Path(path_str).read_text())
            assert "procedure" in data
            assert "parameters" in data
            assert "captured_at" in data
            assert "result_sets" in data
            assert "row_counts" in data
            assert "success" in data
            assert "params_hash" in data

    def test_error_baselines_contain_error_field(self, tmp_project: Path):
        result = TestCaseResult(
            result_sets=[], row_counts=[], success=False,
            error="Some error",
        )
        stats = run_capture(
            config=_make_config(),
            factory_registry=_make_registry(),
            project_root=tmp_project,
            executor_override=_FakeExecutor(result),
        )

        for path_str in stats.baseline_files:
            data = json.loads(Path(path_str).read_text())
            assert data["success"] is False
            assert data["error"] == "Some error"
