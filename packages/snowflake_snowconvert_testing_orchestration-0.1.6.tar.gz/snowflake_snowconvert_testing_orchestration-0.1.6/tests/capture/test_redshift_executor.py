"""Tests for test_runner.capture.sources.redshift (mocked connector)."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, PropertyMock, call, patch

import pytest

from test_runner.capture.sources.redshift import (
    RedshiftExecutor,
    RedshiftExecutorFactory,
    RedshiftLiteralFormatter,
)
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.models import ValidationSteps


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_YAML_MAPPING = {
    "INT4": "NUMBER",
    "INT8": "NUMBER",
    "VARCHAR": "VARCHAR",
    "NUMERIC": "NUMBER",
    "FLOAT8": "FLOAT",
    "BOOL": "BOOLEAN",
    "DATE": "DATE",
    "TIMESTAMP": "TIMESTAMP_NTZ",
    "BPCHAR": "VARCHAR",
}


def _make_mock_connector(
    query_description: list[tuple] | None,
    query_rows: list[tuple],
    pg_type_rows: list[tuple] | None = None,
    *,
    fetchone_value: tuple | None = None,
) -> MagicMock:
    """Create a mock Redshift connector.

    The main cursor handles the CALL + result reads.
    A second cursor handles pg_catalog.pg_type lookups.
    """
    main_cursor = MagicMock()
    main_cursor.description = query_description
    main_cursor.fetchall.return_value = query_rows
    main_cursor.fetchone.return_value = fetchone_value

    meta_cursor = MagicMock()
    if pg_type_rows is not None:
        meta_cursor.fetchall.return_value = pg_type_rows
    else:
        meta_cursor.fetchall.return_value = []

    connection = MagicMock()
    connection.cursor.side_effect = [main_cursor, meta_cursor]
    connection.autocommit = True

    connector = MagicMock()
    connector.connection = connection
    return connector


def _make_multi_step_connector(
    steps: list[dict],
    pg_type_rows: list[tuple] | None = None,
) -> tuple[MagicMock, MagicMock]:
    """Create a mock connector where sequential cursor.execute calls
    change description/rows per *steps*.  Also provides a meta cursor
    for pg_type lookups.
    """
    call_idx = {"i": 0}
    main_cursor = MagicMock()

    def _execute_side_effect(sql):
        idx = call_idx["i"]
        if idx < len(steps):
            step = steps[idx]
            main_cursor.description = step.get("description")
            main_cursor.fetchall.return_value = step.get("rows", [])
            main_cursor.fetchone.return_value = (
                step["rows"][0] if step.get("rows") else None
            )
        else:
            main_cursor.description = None
            main_cursor.fetchall.return_value = []
            main_cursor.fetchone.return_value = None
        call_idx["i"] += 1

    main_cursor.execute = MagicMock(side_effect=_execute_side_effect)
    main_cursor.close = MagicMock()

    meta_cursor = MagicMock()
    meta_cursor.fetchall.return_value = pg_type_rows or []

    connection = MagicMock()
    connection.cursor.return_value = main_cursor
    connection.autocommit = True

    connector = MagicMock()
    connector.connection = connection
    return connector, main_cursor


# ---------------------------------------------------------------------------
# RedshiftLiteralFormatter
# ---------------------------------------------------------------------------

class TestRedshiftLiteralFormatter:
    def test_null(self):
        fmt = RedshiftLiteralFormatter()
        assert fmt.format_literal(None) == "NULL"

    def test_bool_true(self):
        fmt = RedshiftLiteralFormatter()
        assert fmt.format_literal(True) == "TRUE"

    def test_bool_false(self):
        fmt = RedshiftLiteralFormatter()
        assert fmt.format_literal(False) == "FALSE"

    def test_integer(self):
        fmt = RedshiftLiteralFormatter()
        assert fmt.format_literal(42) == "42"

    def test_float(self):
        fmt = RedshiftLiteralFormatter()
        assert fmt.format_literal(3.14) == "3.14"

    def test_string(self):
        fmt = RedshiftLiteralFormatter()
        assert fmt.format_literal("hello") == "'hello'"

    def test_string_with_single_quotes(self):
        fmt = RedshiftLiteralFormatter()
        assert fmt.format_literal("it's") == "'it''s'"

    def test_non_string_non_numeric_value(self):
        fmt = RedshiftLiteralFormatter()
        from datetime import date
        result = fmt.format_literal(date(2026, 1, 1))
        assert result == "'2026-01-01'"


# ---------------------------------------------------------------------------
# RedshiftExecutorFactory
# ---------------------------------------------------------------------------

class TestRedshiftExecutorFactory:
    def test_dialect(self):
        factory = RedshiftExecutorFactory()
        assert factory.dialect == DatabaseDialect.REDSHIFT

    def test_build_config_defaults(self):
        factory = RedshiftExecutorFactory()
        cfg = factory.build_config({})
        assert cfg.host == "localhost"
        assert cfg.port == 5439

    def test_build_config_custom(self):
        factory = RedshiftExecutorFactory()
        cfg = factory.build_config({
            "host": "my-cluster.redshift.amazonaws.com",
            "port": "5440",
            "database": "mydb",
            "username": "admin",
            "password": "s3cret",
        })
        assert cfg.host == "my-cluster.redshift.amazonaws.com"
        assert cfg.port == 5440
        assert cfg.database == "mydb"
        assert cfg.username == "admin"
        assert cfg.password == "s3cret"

    def test_create_literal_formatter_returns_redshift_formatter(self):
        factory = RedshiftExecutorFactory()
        fmt = factory.create_literal_formatter()
        assert isinstance(fmt, RedshiftLiteralFormatter)


# ---------------------------------------------------------------------------
# RedshiftExecutor - basic execution
# ---------------------------------------------------------------------------

class TestRedshiftExecutor:
    def test_execute_returns_rows(self):
        desc = [("id", 23, None, None, None, None), ("name", 1043, None, None, None, None)]
        rows = [(1, "Widget"), (2, "Gadget")]
        pg_types = [(23, "int4"), (1043, "varchar")]
        connector = _make_mock_connector(desc, rows, pg_types)

        executor = RedshiftExecutor(connector, _YAML_MAPPING)
        result = executor.execute("CALL dbo.GetProducts()")

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == [
            {"id": 1, "name": "Widget"},
            {"id": 2, "name": "Gadget"},
        ]
        assert result.row_counts == [2]

    def test_execute_returns_column_types_via_pg_type(self):
        desc = [("id", 23, None, None, None, None), ("name", 1043, None, None, None, None)]
        rows = [(1, "Widget")]
        pg_types = [(23, "int4"), (1043, "varchar")]
        connector = _make_mock_connector(desc, rows, pg_types)

        executor = RedshiftExecutor(connector, _YAML_MAPPING)
        result = executor.execute("SELECT 1")

        assert result.column_types[0]["ID"] == "NUMBER"
        assert result.column_types[0]["NAME"] == "VARCHAR"

    def test_execute_empty_result(self):
        desc = [("status", 1043, None, None, None, None)]
        pg_types = [(1043, "varchar")]
        connector = _make_mock_connector(desc, [], pg_types)

        executor = RedshiftExecutor(connector, _YAML_MAPPING)
        result = executor.execute("CALL dbo.EmptyProc()")

        assert result.success is True
        assert result.result_sets == [[]]
        assert result.row_counts == [0]

    def test_execute_handles_error(self):
        connector = MagicMock()
        connection = MagicMock()
        connection.autocommit = True
        cursor = MagicMock()
        cursor.execute.side_effect = RuntimeError("Connection refused")
        connection.cursor.return_value = cursor
        connector.connection = connection

        executor = RedshiftExecutor(connector, _YAML_MAPPING)
        result = executor.execute("CALL boom()")

        assert result.success is False
        assert "Connection refused" in result.error

    def test_execute_no_description_returns_empty(self):
        connector, main_cursor = _make_multi_step_connector([
            {"description": None, "rows": []},  # BEGIN
            {"description": None, "rows": []},  # CALL (no result)
            {"description": None, "rows": []},  # ROLLBACK
        ])

        executor = RedshiftExecutor(connector)
        result = executor.execute("CALL dml_proc()")

        assert result.success is True
        assert result.result_sets[0] == []
        assert result.row_counts[0] == 0

    def test_close_delegates_to_connector(self):
        connector = MagicMock()
        connector.connection.autocommit = True
        executor = RedshiftExecutor(connector)
        executor.close()
        connector.close.assert_called_once()

    def test_connector_property(self):
        connector = MagicMock()
        connector.connection.autocommit = True
        executor = RedshiftExecutor(connector)
        assert executor.connector is connector

    def test_autocommit_set_on_init(self):
        connector = MagicMock()
        connector.connection.autocommit = False
        RedshiftExecutor(connector)
        assert connector.connection.autocommit is True

    def test_autocommit_failure_is_silent(self):
        connector = MagicMock()
        type(connector.connection).autocommit = PropertyMock(side_effect=Exception("nope"))
        # Should not raise
        RedshiftExecutor(connector)

    def test_unmapped_types_use_base_type_name(self):
        desc = [("col", 1700, None, None, None, None)]
        rows = [(42,)]
        pg_types = [(1700, "numeric")]
        connector = _make_mock_connector(desc, rows, pg_types)

        executor = RedshiftExecutor(connector, _YAML_MAPPING)
        result = executor.execute("SELECT 42")
        assert result.column_types[0]["COL"] == "NUMBER"

    def test_no_datatypes_mapping_uses_raw_base_type(self):
        desc = [("col", 23, None, None, None, None)]
        rows = [(1,)]
        pg_types = [(23, "int4")]
        connector = _make_mock_connector(desc, rows, pg_types)

        executor = RedshiftExecutor(connector, datatypes_mappings=None)
        result = executor.execute("SELECT 1")
        assert result.column_types[0]["COL"] == "INT4"


# ---------------------------------------------------------------------------
# RedshiftExecutor - capture support
# ---------------------------------------------------------------------------

class TestRedshiftExecutorCapture:
    def test_capture_basic_flow(self):
        """Capture with no OUT placeholders appends OUT row + capture result."""
        connector, main_cursor = _make_multi_step_connector([
            {"description": None, "rows": []},  # BEGIN
            {  # CALL: OUT row
                "description": [("result_table", 1043, None, None, None, None)],
                "rows": [("my_table",)],
            },
            {  # Capture: data
                "description": [("id", 23, None, None, None, None)],
                "rows": [(1,), (2,)],
            },
            {"description": None, "rows": []},  # ROLLBACK
        ])

        steps = ValidationSteps(
            run="CALL sp_proc()",
            capture=["SELECT * FROM my_table"],
        )
        executor = RedshiftExecutor(connector)
        result = executor.execute("CALL sp_proc()", steps=steps)

        assert result.success is True
        assert len(result.result_sets) == 2

    def test_capture_out_placeholder_resolution(self):
        """OUT:param tokens are resolved from the OUT row."""
        connector, main_cursor = _make_multi_step_connector([
            {"description": None, "rows": []},  # BEGIN
            {  # CALL: OUT row
                "description": [("OUTPUT_TABLE", 1043, None, None, None, None)],
                "rows": [("analytics.customer_segments",)],
            },
            {  # Capture: data
                "description": [("id", 23, None, None, None, None)],
                "rows": [(42,)],
            },
            {"description": None, "rows": []},  # ROLLBACK
        ])

        steps = ValidationSteps(
            run="CALL sp_segments()",
            capture=["SELECT * FROM {OUT:output_table}"],
        )
        executor = RedshiftExecutor(connector)
        result = executor.execute("CALL sp_segments()", steps=steps)

        assert result.success is True
        executed_sqls = [c.args[0] for c in main_cursor.execute.call_args_list]
        assert any("analytics.customer_segments" in sql for sql in executed_sqls)

    def test_capture_out_placeholder_special_chars_quoted(self):
        """Values with special characters get double-quoted."""
        connector, main_cursor = _make_multi_step_connector([
            {"description": None, "rows": []},  # BEGIN
            {  # CALL: OUT row with special char value
                "description": [("RS_OUT", 1043, None, None, None, None)],
                "rows": [("<unnamed portal 1>",)],
            },
            {  # FETCH result
                "description": [("id", 23, None, None, None, None)],
                "rows": [(7,)],
            },
            {"description": None, "rows": []},  # ROLLBACK
        ])

        steps = ValidationSteps(
            run="CALL sp_cursor()",
            capture=["FETCH ALL FROM {OUT:rs_out}"],
        )
        executor = RedshiftExecutor(connector)
        result = executor.execute("CALL sp_cursor()", steps=steps)

        assert result.success is True
        executed_sqls = [c.args[0] for c in main_cursor.execute.call_args_list]
        assert any('"<unnamed portal 1>"' in sql for sql in executed_sqls)

    def test_capture_with_no_out_row(self):
        """DML procedure with capture but no OUT row (description=None after CALL)."""
        connector, main_cursor = _make_multi_step_connector([
            {"description": None, "rows": []},  # BEGIN
            {"description": None, "rows": []},  # CALL: no result
            {  # Capture
                "description": [("cnt", 23, None, None, None, None)],
                "rows": [(5,)],
            },
            {"description": None, "rows": []},  # ROLLBACK
        ])

        steps = ValidationSteps(
            run="CALL sp_dml()",
            capture=["SELECT COUNT(*) AS cnt FROM some_table"],
        )
        executor = RedshiftExecutor(connector)
        result = executor.execute("CALL sp_dml()", steps=steps)

        assert result.success is True
        assert len(result.result_sets) == 2
        assert result.result_sets[0] == []
        assert result.row_counts[0] == 0

    def test_no_capture_unchanged_behavior(self):
        """Without capture, behavior is identical to the non-capture path."""
        connector, _ = _make_multi_step_connector([
            {"description": None, "rows": []},  # BEGIN
            {
                "description": [("total", 23, None, None, None, None)],
                "rows": [(100,)],
            },
            {"description": None, "rows": []},  # ROLLBACK
        ])

        executor = RedshiftExecutor(connector)
        result = executor.execute("SELECT COUNT(*) AS total")

        assert result.success is True
        assert len(result.result_sets) == 1


    def test_resolve_placeholders_unresolved_left_as_is(self):
        """Unresolved {OUT:x} placeholders are left in the SQL string."""
        executor = RedshiftExecutor.__new__(RedshiftExecutor)
        out_row = ({"COL_A": "value_a"}, {"COL_A": "VARCHAR"})
        result = executor._resolve_placeholders(
            "SELECT * FROM {OUT:missing_col}", out_row
        )
        assert "{OUT:missing_col}" in result

    def test_resolve_placeholders_none_out_row(self):
        """When out_row is None, the SQL is returned unchanged."""
        executor = RedshiftExecutor.__new__(RedshiftExecutor)
        sql = "SELECT * FROM {OUT:x}"
        assert executor._resolve_placeholders(sql, None) == sql
