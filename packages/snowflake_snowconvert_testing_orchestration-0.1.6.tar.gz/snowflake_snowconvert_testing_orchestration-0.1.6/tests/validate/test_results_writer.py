"""Tests for test_runner.validate.results_writer.write_results_local."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from test_runner.validate.results_writer import write_results_local


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _result(
    procedure: str = "dbo.GetProducts",
    params_hash: str = "abc123",
    status: str = "PASS",
    match_type: str = "data_match",
    baseline_rows: int = 10,
    actual_rows: int = 10,
    error: str = "",
    executed_at: str = "2026-01-01T00:00:00Z",
    **extra,
) -> dict:
    r = dict(
        procedure=procedure,
        params_hash=params_hash,
        status=status,
        match_type=match_type,
        baseline_rows=baseline_rows,
        actual_rows=actual_rows,
        error=error,
        executed_at=executed_at,
    )
    r.update(extra)
    return r


# ---------------------------------------------------------------------------
# TestWriteResultsLocal
# ---------------------------------------------------------------------------

class TestWriteResultsLocal:
    def test_creates_output_dir_if_missing(self, tmp_path: Path):
        target = tmp_path / "new" / "nested" / "dir"
        write_results_local([_result()], target)
        assert target.is_dir()

    def test_writes_json_file(self, tmp_path: Path):
        write_results_local([_result(status="PASS"), _result(status="FAIL")], tmp_path)
        json_file = tmp_path / "results.json"
        assert json_file.exists()
        data = json.loads(json_file.read_text())
        assert len(data) == 2
        assert data[0]["status"] == "PASS"

    def test_json_includes_in_memory_diff(self, tmp_path: Path):
        diff = {"match": False, "row_counts": {"baseline": 5, "actual": 3}}
        r = _result(status="FAIL", in_memory_diff=diff)
        write_results_local([r], tmp_path)
        data = json.loads((tmp_path / "results.json").read_text())
        assert data[0]["in_memory_diff"]["row_counts"]["baseline"] == 5

    def test_empty_results_writes_empty_json_array(self, tmp_path: Path):
        write_results_local([], tmp_path)
        data = json.loads((tmp_path / "results.json").read_text())
        assert data == []

    def test_idempotent_overwrites_previous_output(self, tmp_path: Path):
        write_results_local([_result(status="PASS")], tmp_path)
        write_results_local([_result(status="FAIL")], tmp_path)
        data = json.loads((tmp_path / "results.json").read_text())
        assert data[0]["status"] == "FAIL"

    def test_non_serialisable_values_handled(self, tmp_path: Path):
        from datetime import datetime
        r = _result(executed_at=datetime(2026, 1, 1))
        write_results_local([r], tmp_path)
        data = json.loads((tmp_path / "results.json").read_text())
        assert "2026" in data[0]["executed_at"]

    def test_row_dumps_written_when_present(self, tmp_path: Path):
        baseline = [{"Col": "a"}, {"Col": "b"}]
        actual   = [{"Col": "a"}, {"Col": "x"}]
        r = _result(params_hash="deadbeef",
                    **{"_baseline_rows": baseline, "_actual_rows": actual})
        write_results_local([r], tmp_path)
        b_path = tmp_path / "deadbeef_baseline.json"
        a_path = tmp_path / "deadbeef_actual.json"
        assert b_path.exists()
        assert a_path.exists()
        assert json.loads(b_path.read_text()) == baseline
        assert json.loads(a_path.read_text()) == actual

    def test_private_keys_stripped_from_results_json(self, tmp_path: Path):
        r = _result(params_hash="abc",
                    **{"_baseline_rows": [{"X": 1}], "_actual_rows": [{"X": 2}]})
        write_results_local([r], tmp_path)
        data = json.loads((tmp_path / "results.json").read_text())
        assert "_baseline_rows" not in data[0]
        assert "_actual_rows" not in data[0]

    def test_no_row_dumps_when_absent(self, tmp_path: Path):
        write_results_local([_result(params_hash="nohash")], tmp_path)
        assert not list(tmp_path.glob("*_baseline.json"))
        assert not list(tmp_path.glob("*_actual.json"))
