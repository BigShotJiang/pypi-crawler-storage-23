"""Tests for test_runner.validate.targets.snowflake (mocked connector)."""

from __future__ import annotations

from unittest.mock import MagicMock, call, patch

import pytest

from test_runner.validate.targets.snowflake import (
    SnowflakeExecutor,
    SnowflakeExecutorFactory,
)
from test_runner.common.database_dialect import DatabaseDialect
from test_runner.common.models import ValidationSteps


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _sf_desc(name: str, type_code: int):
    """Build a single Snowflake cursor.description tuple."""
    return (name, type_code, None, None, None, None, True)


def _make_sf_mock_connector(
    description: list[tuple],
    rows: list[dict],
) -> MagicMock:
    """Create a mock Snowflake connector with cursor-based execution."""
    mock_cursor = MagicMock()
    mock_cursor.description = description
    mock_cursor.fetchall.return_value = rows
    mock_cursor.close = MagicMock()

    mock_connection = MagicMock()
    mock_connection.cursor.return_value = mock_cursor

    connector = MagicMock()
    connector.connection = mock_connection
    return connector


# ---------------------------------------------------------------------------
# SnowflakeExecutorFactory
# ---------------------------------------------------------------------------

class TestSnowflakeExecutorFactory:
    def test_dialect(self):
        factory = SnowflakeExecutorFactory()
        assert factory.dialect == DatabaseDialect.SNOWFLAKE

    def test_build_config(self):
        factory = SnowflakeExecutorFactory()
        cfg = factory.build_config({"name": "my-conn", "mode": "name"})
        assert cfg.name == "my-conn"

    def test_format_literal_null(self):
        fmt = SnowflakeExecutorFactory().create_literal_formatter()
        assert fmt.format_literal(None) == "NULL"

    def test_format_literal_bool_true(self):
        fmt = SnowflakeExecutorFactory().create_literal_formatter()
        assert fmt.format_literal(True) == "TRUE"

    def test_format_literal_bool_false(self):
        fmt = SnowflakeExecutorFactory().create_literal_formatter()
        assert fmt.format_literal(False) == "FALSE"

    def test_format_literal_int(self):
        fmt = SnowflakeExecutorFactory().create_literal_formatter()
        assert fmt.format_literal(42) == "42"

    def test_format_literal_string(self):
        fmt = SnowflakeExecutorFactory().create_literal_formatter()
        assert fmt.format_literal("hello") == "'hello'"

    def test_format_literal_string_with_quotes(self):
        fmt = SnowflakeExecutorFactory().create_literal_formatter()
        assert fmt.format_literal("it's") == "'it''s'"


# ---------------------------------------------------------------------------
# SnowflakeExecutor
# ---------------------------------------------------------------------------

class TestSnowflakeExecutor:
    @patch("test_runner.validate.targets.snowflake.sf_connector", create=True)
    def test_execute_returns_rows_with_types(self, _mock_sf):
        desc = [
            _sf_desc("Id", 0),     # FIXED -> NUMBER(38,18)
            _sf_desc("Name", 2),   # TEXT
        ]
        rows = [{"Id": 1, "Name": "Widget"}, {"Id": 2, "Name": "Gadget"}]
        mock = _make_sf_mock_connector(desc, rows)

        executor = SnowflakeExecutor(mock)
        result = executor.execute("CALL dbo.GetProducts()")

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == rows
        assert result.column_types[0] == {"ID": "FIXED", "NAME": "TEXT"}

    @patch("test_runner.validate.targets.snowflake.sf_connector", create=True)
    def test_execute_captures_all_common_types(self, _mock_sf):
        desc = [
            _sf_desc("amount", 0),    # FIXED -> NUMBER(38,18)
            _sf_desc("label", 2),     # TEXT
            _sf_desc("active", 13),   # BOOLEAN
            _sf_desc("created", 8),   # TIMESTAMP_NTZ
            _sf_desc("bday", 3),      # DATE
            _sf_desc("data", 11),     # BINARY
            _sf_desc("ratio", 1),     # REAL
            _sf_desc("ts_tz", 7),     # TIMESTAMP_TZ
            _sf_desc("clock", 12),    # TIME
            _sf_desc("payload", 5),   # VARIANT
        ]
        mock = _make_sf_mock_connector(desc, [])

        executor = SnowflakeExecutor(mock)
        result = executor.execute("SELECT 1")

        types = result.column_types[0]
        assert types == {
            "AMOUNT": "FIXED",
            "LABEL": "TEXT",
            "ACTIVE": "BOOLEAN",
            "CREATED": "TIMESTAMP_NTZ",
            "BDAY": "DATE",
            "DATA": "BINARY",
            "RATIO": "REAL",
            "TS_TZ": "TIMESTAMP_TZ",
            "CLOCK": "TIME",
            "PAYLOAD": "VARIANT",
        }

    def test_execute_handles_error(self):
        connector = MagicMock()
        connector.connection.cursor.side_effect = RuntimeError("Connection failed")

        executor = SnowflakeExecutor(connector)
        result = executor.execute("CALL dbo.P()")

        assert result.success is False
        assert "Connection failed" in result.error

    @patch("test_runner.validate.targets.snowflake.sf_connector", create=True)
    def test_execute_empty_result(self, _mock_sf):
        desc = [_sf_desc("Status", 2)]
        mock = _make_sf_mock_connector(desc, [])

        executor = SnowflakeExecutor(mock)
        result = executor.execute("CALL dbo.P()")

        assert result.success is True
        assert result.result_sets == [[]]
        assert result.column_types[0] == {"STATUS": "TEXT"}

    def test_close_delegates(self):
        mock = MagicMock()
        executor = SnowflakeExecutor(mock)
        executor.close()
        mock.close.assert_called_once()


# ---------------------------------------------------------------------------
# SnowflakeExecutor -- capture support
# ---------------------------------------------------------------------------

def _make_multi_step_mock_connector(
    steps: list[dict],
) -> MagicMock:
    """Create a mock connector where each ``cursor.execute`` call returns
    different description/rows based on call order.

    *steps* is a list of dicts with keys ``description`` and ``rows``.
    The first call to ``execute`` uses ``steps[0]``, the second uses
    ``steps[1]``, etc.
    """
    call_idx = {"i": 0}
    mock_cursor = MagicMock()

    def _execute_side_effect(sql):
        idx = call_idx["i"]
        if idx < len(steps):
            step = steps[idx]
            mock_cursor.description = step["description"]
            mock_cursor.fetchall.return_value = step["rows"]
            mock_cursor.fetchone.return_value = (
                step["rows"][0] if step["rows"] else None
            )
        else:
            mock_cursor.description = None
            mock_cursor.fetchall.return_value = []
            mock_cursor.fetchone.return_value = None
        call_idx["i"] += 1

    mock_cursor.execute = MagicMock(side_effect=_execute_side_effect)
    mock_cursor.close = MagicMock()

    mock_connection = MagicMock()
    mock_connection.cursor.return_value = mock_cursor

    connector = MagicMock()
    connector.connection = mock_connection
    return connector, mock_cursor


class TestSnowflakeExecutorCapture:
    """Tests for capture (multi-result-set) support."""

    @patch("test_runner.validate.targets.snowflake.sf_connector", create=True)
    def test_capture_positional_placeholder(self, _mock_sf):
        """INOUT table name pattern: capture has no {OUT:x}, just plain SQL."""
        out_desc = [_sf_desc("rs_out", 2)]
        out_rows = [{"rs_out": "top_products_cur"}]
        data_desc = [_sf_desc("product_id", 0), _sf_desc("name", 2)]
        data_rows = [
            {"product_id": 1, "name": "Widget"},
            {"product_id": 2, "name": "Gadget"},
        ]

        connector, mock_cursor = _make_multi_step_mock_connector([
            {"description": out_desc, "rows": out_rows},       # CALL
            {"description": data_desc, "rows": data_rows},      # capture
        ])

        steps = ValidationSteps(
            run="CALL sp_top_products(10, 'top_products_cur')",
            capture=["SELECT * FROM IDENTIFIER('top_products_cur')"],
        )
        executor = SnowflakeExecutor(connector)
        result = executor.execute(
            "CALL sp_top_products(10, 'top_products_cur')", steps=steps,
        )

        assert result.success is True
        assert len(result.result_sets) == 2
        # result_sets[0] = OUT row
        assert result.result_sets[0] == [{"rs_out": "top_products_cur"}]
        # result_sets[1] = data from capture
        assert result.result_sets[1] == data_rows
        assert result.row_counts == [1, 2]

    @patch("test_runner.validate.targets.snowflake.sf_connector", create=True)
    def test_capture_out_placeholder_resolution(self, _mock_sf):
        """OUT VARCHAR table name pattern: {OUT:result_table} resolved at runtime."""
        out_desc = [_sf_desc("RESULT_TABLE", 2)]
        out_rows = [{"RESULT_TABLE": "ecommerce_analytics.customer_segments"}]
        data_desc = [_sf_desc("customer_id", 0), _sf_desc("segment", 2)]
        data_rows = [{"customer_id": 1, "segment": "VIP"}]

        connector, mock_cursor = _make_multi_step_mock_connector([
            {"description": out_desc, "rows": out_rows},
            {"description": data_desc, "rows": data_rows},
        ])

        steps = ValidationSteps(
            run="CALL sp_calculate_customer_segments()",
            capture=["SELECT * FROM {OUT:result_table} ORDER BY customer_id"],
        )
        executor = SnowflakeExecutor(connector)
        result = executor.execute(
            "CALL sp_calculate_customer_segments()", steps=steps,
        )

        assert result.success is True
        assert len(result.result_sets) == 2
        assert result.result_sets[0] == [
            {"RESULT_TABLE": "ecommerce_analytics.customer_segments"}
        ]
        assert result.result_sets[1] == data_rows

        # Verify the capture SQL was resolved correctly
        executed_sqls = [c.args[0] for c in mock_cursor.execute.call_args_list]
        assert executed_sqls[1] == (
            "SELECT * FROM ecommerce_analytics.customer_segments ORDER BY customer_id"
        )

    @patch("test_runner.validate.targets.snowflake.sf_connector", create=True)
    def test_capture_out_placeholder_special_chars_quoted(self, _mock_sf):
        """Values with special characters get double-quoted."""
        out_desc = [_sf_desc("RS_OUT", 2)]
        out_rows = [{"RS_OUT": "<unnamed portal 1>"}]
        data_desc = [_sf_desc("id", 0)]
        data_rows = [{"id": 42}]

        connector, mock_cursor = _make_multi_step_mock_connector([
            {"description": out_desc, "rows": out_rows},
            {"description": data_desc, "rows": data_rows},
        ])

        steps = ValidationSteps(
            run="CALL sp_out_cursor(7)",
            capture=["FETCH ALL FROM {OUT:rs_out}"],
        )
        executor = SnowflakeExecutor(connector)
        result = executor.execute("CALL sp_out_cursor(7)", steps=steps)

        assert result.success is True
        executed_sqls = [c.args[0] for c in mock_cursor.execute.call_args_list]
        assert executed_sqls[1] == 'FETCH ALL FROM "<unnamed portal 1>"'

    @patch("test_runner.validate.targets.snowflake.sf_connector", create=True)
    def test_no_capture_unchanged_behavior(self, _mock_sf):
        """Without capture, behavior is identical to original."""
        desc = [_sf_desc("total", 0)]
        rows = [{"total": 100}]
        connector, _ = _make_multi_step_mock_connector([
            {"description": desc, "rows": rows},
        ])

        executor = SnowflakeExecutor(connector)
        result = executor.execute("SELECT COUNT(*) AS total")

        assert result.success is True
        assert len(result.result_sets) == 1
        assert result.result_sets[0] == rows

    @patch("test_runner.validate.targets.snowflake.sf_connector", create=True)
    def test_capture_with_no_out_row(self, _mock_sf):
        """DML procedure with capture but no OUT row (description=None after CALL)."""
        connector, mock_cursor = _make_multi_step_mock_connector([
            {"description": None, "rows": []},              # CALL (DML, no result)
            {"description": [_sf_desc("cnt", 0)], "rows": [{"cnt": 5}]},  # capture
        ])

        steps = ValidationSteps(
            run="CALL sp_dml()",
            capture=["SELECT COUNT(*) AS cnt FROM some_table"],
        )
        executor = SnowflakeExecutor(connector)
        result = executor.execute("CALL sp_dml()", steps=steps)

        assert result.success is True
        assert len(result.result_sets) == 2
        # OUT row is empty
        assert result.result_sets[0] == []
        assert result.row_counts[0] == 0
        # Capture result present
        assert result.result_sets[1] == [{"cnt": 5}]

    @patch("test_runner.validate.targets.snowflake.sf_connector", create=True)
    def test_capture_error_during_capture_statement(self, _mock_sf):
        """Error during a capture statement is reported."""
        out_desc = [_sf_desc("tbl", 2)]
        out_rows = [{"tbl": "nonexistent_table"}]

        connector, mock_cursor = _make_multi_step_mock_connector([
            {"description": out_desc, "rows": out_rows},
        ])
        # Make the second execute (capture) raise an error
        original_side_effect = mock_cursor.execute.side_effect
        call_count = {"i": 0}

        def _error_on_second(sql):
            call_count["i"] += 1
            if call_count["i"] == 2:
                raise RuntimeError("Object 'nonexistent_table' does not exist")
            return original_side_effect(sql)

        mock_cursor.execute.side_effect = _error_on_second

        steps = ValidationSteps(
            run="CALL sp_seg()",
            capture=["SELECT * FROM {OUT:tbl}"],
        )
        executor = SnowflakeExecutor(connector)
        result = executor.execute("CALL sp_seg()", steps=steps)

        assert result.success is False
        assert "does not exist" in result.error
