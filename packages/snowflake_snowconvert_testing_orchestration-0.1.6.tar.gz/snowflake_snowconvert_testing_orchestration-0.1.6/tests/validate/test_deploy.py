"""Tests for test_runner.validate.deploy."""

from __future__ import annotations

import zipfile
from pathlib import Path

import pytest

from test_runner.validate.deploy import (
    create_package_zip,
    _CREATE_VALIDATE_BATCH_SQL,
    _CREATE_VALIDATE_SINGLE_SQL,
)


class TestCreatePackageZip:
    def test_creates_zip_file(self, tmp_path: Path):
        zip_path = tmp_path / "snowpark_validator.zip"
        result = create_package_zip(zip_path)
        assert result == zip_path
        assert zip_path.exists()

    def test_zip_contains_package_structure(self, tmp_path: Path):
        zip_path = tmp_path / "snowpark_validator.zip"
        create_package_zip(zip_path)

        with zipfile.ZipFile(zip_path, "r") as zf:
            names = zf.namelist()
            # Must contain the package directory with __init__.py and main.py
            assert "snowpark_validator/__init__.py" in names
            assert "snowpark_validator/main.py" in names

    def test_main_py_contains_validate_functions(self, tmp_path: Path):
        zip_path = tmp_path / "snowpark_validator.zip"
        create_package_zip(zip_path)

        with zipfile.ZipFile(zip_path, "r") as zf:
            main_content = zf.read("snowpark_validator/main.py").decode("utf-8")
            assert "def validate_single(" in main_content
            assert "def validate_batch(" in main_content
            assert "def _compare_results(" in main_content
            assert "def _execute_procedure(" in main_content

    def test_zip_is_valid(self, tmp_path: Path):
        zip_path = tmp_path / "snowpark_validator.zip"
        create_package_zip(zip_path)
        assert zipfile.is_zipfile(zip_path)


class TestSqlTemplates:
    _FMT = {"stage": "@MY_DB.MY_SCHEMA.MY_STAGE", "database": "MY_DB"}

    def test_batch_sql_has_stage_placeholder(self):
        sql = _CREATE_VALIDATE_BATCH_SQL.format(**self._FMT)
        assert "@MY_DB.MY_SCHEMA.MY_STAGE/snowpark_validator.zip" in sql
        assert "VALIDATE_BATCH" in sql
        assert "HANDLER = 'run_batch'" in sql

    def test_single_sql_has_stage_placeholder(self):
        sql = _CREATE_VALIDATE_SINGLE_SQL.format(**self._FMT)
        assert "@MY_DB.MY_SCHEMA.MY_STAGE/snowpark_validator.zip" in sql
        assert "VALIDATE_SINGLE" in sql
        assert "HANDLER = 'run_single'" in sql

    def test_batch_sql_imports_from_snowpark_validator(self):
        sql = _CREATE_VALIDATE_BATCH_SQL.format(stage="@STAGE", database="DB")
        assert "from snowpark_validator.main import validate_batch" in sql

    def test_single_sql_imports_from_snowpark_validator(self):
        sql = _CREATE_VALIDATE_SINGLE_SQL.format(stage="@STAGE", database="DB")
        assert "from snowpark_validator.main import validate_single" in sql

    def test_both_use_python_310(self):
        for sql_template in [_CREATE_VALIDATE_BATCH_SQL, _CREATE_VALIDATE_SINGLE_SQL]:
            sql = sql_template.format(stage="@S", database="DB")
            assert "RUNTIME_VERSION = '3.10'" in sql

    def test_both_execute_as_caller(self):
        for sql_template in [_CREATE_VALIDATE_BATCH_SQL, _CREATE_VALIDATE_SINGLE_SQL]:
            sql = sql_template.format(stage="@S", database="DB")
            assert "EXECUTE AS CALLER" in sql
