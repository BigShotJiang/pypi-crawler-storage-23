"""jvim: JSON editor with vim-style keybindings."""

from .widget import EditorMode, JsonEditor

__all__ = ["EditorMode", "JsonEditor"]
__version__ = "0.7.1"
