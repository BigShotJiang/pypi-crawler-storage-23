"""Allow running with `python -m jvim`."""

from .editor import main

main()
