"""Demo application for the JSON editor."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Button, Header, Static

from .widget import JsonEditor

# Data directory path
_DATA_DIR = Path(__file__).parent / "data"
# Config directory and history file
_CONFIG_DIR = Path.home() / ".jvim"
_HISTORY_FILE = _CONFIG_DIR / "history.json"


def _load_data(filename: str) -> str:
    """Load content from data directory."""
    return (_DATA_DIR / filename).read_text(encoding="utf-8")


def _load_history() -> dict:
    """Load command/search history from file."""
    try:
        if _HISTORY_FILE.exists():
            return json.loads(_HISTORY_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        pass
    return {}


def _save_history(history: dict) -> None:
    """Save command/search history to file."""
    try:
        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        _HISTORY_FILE.write_text(
            json.dumps(history, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except OSError:
        pass  # Silently fail if we can't write history


def _detect_jsonl(content: str) -> bool:
    """내용 기반 JSONL 감지. 2개 이상의 독립 JSON 값이 줄 단위로 존재하면 True."""
    lines = [ln for ln in content.splitlines() if ln.strip()]
    if len(lines) < 2:
        return False
    # 전체가 유효한 단일 JSON이면 JSONL이 아님
    try:
        json.loads(content)
        return False
    except json.JSONDecodeError:
        pass
    # 각 줄이 유효한 JSON인지 확인
    valid = 0
    for line in lines:
        try:
            json.loads(line)
            valid += 1
        except json.JSONDecodeError:
            return False
    return valid >= 2


class JsonEditorApp(App):
    """TUI app that wraps the JsonEditor widget."""

    CSS_PATH = "styles/editor.tcss"
    TITLE = "JSON Editor"
    BINDINGS = []
    ENABLE_COMMAND_PALETTE = False

    def __init__(
        self,
        file_path: str = "",
        initial_content: str = "",
        read_only: bool = False,
        jsonl: bool = False,
        file_list: list[str] | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.file_path = file_path
        self.initial_content = initial_content
        self.read_only = read_only
        self.jsonl = jsonl
        # Multi-file navigation
        self.file_list: list[str] = file_list or ([file_path] if file_path else [])
        self.file_index: int = 0
        self._alternate_file: str = ""
        # Embedded edit state - stack of (row, col_start, col_end, parent_content, original_content)
        self._ej_stack: list[tuple[int, int, int, str, str]] = []
        self._main_was_read_only: bool = False
        self._main_scroll_top: int = 0

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield JsonEditor(
            self.initial_content,
            read_only=self.read_only,
            jsonl=self.jsonl,
            id="editor",
        )
        with Vertical(id="help-panel"):
            with Horizontal(id="help-header"):
                yield Static("[b]Help[/b]", id="help-title")
                yield Button("\u2715", id="help-close", variant="error")
            yield JsonEditor(_load_data("help.json"), read_only=True, id="help-editor")
        with Vertical(id="ej-panel"):
            with Horizontal(id="ej-header"):
                yield Static("[b]Edit Embedded JSON[/b]", id="ej-title")
                yield Button("\u2715", id="ej-close", variant="error")
            yield JsonEditor("", id="ej-editor")

    def on_mount(self) -> None:
        self._update_title()
        # Load history
        editor = self.query_one("#editor", JsonEditor)
        history = _load_history()
        editor.set_history(history)
        editor.focus()

    def _update_title(self) -> None:
        ro = " [RO]" if self.read_only else ""
        idx = ""
        if len(self.file_list) > 1:
            idx = f" [{self.file_index + 1}/{len(self.file_list)}]"
        if self.file_path:
            self.sub_title = self.file_path + ro + idx
        else:
            self.sub_title = "[new]" + ro

    def _open_file(self, path: str) -> bool:
        """파일 읽기 + 에디터 교체 공통 로직. 성공 시 True 반환."""
        try:
            content = Path(path).read_text(encoding="utf-8")
        except FileNotFoundError:
            self.notify(f"File not found: {path}", severity="error", timeout=6)
            return False
        except UnicodeDecodeError:
            self.notify(f"Binary file: {path}", severity="error", timeout=6)
            return False
        except OSError as exc:
            self.notify(f"Cannot open: {exc}", severity="error", timeout=6)
            return False
        if "\x00" in content:
            self.notify(f"Binary file: {path}", severity="error", timeout=6)
            return False

        editor = self.query_one("#editor", JsonEditor)
        self.jsonl = path.lower().endswith(".jsonl") or _detect_jsonl(content)
        editor.jsonl = self.jsonl
        editor.set_content(content)
        prev_file = self.file_path
        self.file_path = path
        self._update_title()
        self.notify(f"Opened: {path}", severity="information")
        if prev_file and prev_file != path:
            self._alternate_file = prev_file
        return True

    def _navigate_file(self, offset: int) -> None:
        """:n(+1) / :N(-1) 처리. 범위 밖이면 notify."""
        if not self.file_list:
            self.notify("No file list", severity="warning")
            return
        new_index = self.file_index + offset
        if new_index < 0:
            self.notify("Already at first file", severity="warning")
            return
        if new_index >= len(self.file_list):
            self.notify("Already at last file", severity="warning")
            return
        path = self.file_list[new_index]
        if self._open_file(path):
            self.file_index = new_index

    def _save_and_exit(self) -> None:
        """Save history and exit the app."""
        editor = self.query_one("#editor", JsonEditor)
        _save_history(editor.get_history())
        self.exit()

    # -- Event handlers ----------------------------------------------------

    def _is_help_editor_focused(self) -> bool:
        focused = self.focused
        return focused is not None and focused.id == "help-editor"

    def _is_ej_editor_focused(self) -> bool:
        focused = self.focused
        return focused is not None and focused.id == "ej-editor"

    def on_key(self) -> None:
        """Update ej title on key press to reflect modified state."""
        if self._is_ej_editor_focused() and self._ej_stack:
            self._update_ej_title()

    def on_json_editor_quit(self, event: JsonEditor.Quit) -> None:
        if self._is_help_editor_focused():
            self.query_one("#help-panel").remove_class("visible")
            self.query_one("#editor").focus()
        elif self._is_ej_editor_focused():
            if self._ej_has_unsaved_changes():
                self.notify(
                    "Unsaved changes! Use :w to save or :q! to discard",
                    severity="warning",
                )
            else:
                self._close_ej_panel()
        else:
            self._save_and_exit()

    def on_json_editor_force_quit(self, event: JsonEditor.ForceQuit) -> None:
        """Handle :q! to discard changes."""
        if self._is_help_editor_focused():
            self.query_one("#help-panel").remove_class("visible")
            self.query_one("#editor").focus()
        elif self._is_ej_editor_focused():
            self._close_ej_panel()
        else:
            self._save_and_exit()

    def on_json_editor_json_validated(self, event: JsonEditor.JsonValidated) -> None:
        if event.valid:
            self.notify("JSON is valid", severity="information")
        else:
            self.notify(f"Invalid JSON: {event.error}", severity="error", timeout=6)

    def on_json_editor_file_save_requested(
        self, event: JsonEditor.FileSaveRequested
    ) -> None:
        # Help editor is read-only, so this shouldn't happen, but just in case
        if self._is_help_editor_focused():
            return

        # EJ editor: 부모 문서 갱신
        if self._is_ej_editor_focused() and self._ej_stack:
            row, col_start, col_end, prev_content, _ = self._ej_stack[-1]
            try:
                parsed = json.loads(event.content)
                minified = json.dumps(parsed, ensure_ascii=False)
            except json.JSONDecodeError:
                self.notify("Invalid JSON", severity="error")
                return

            escaped = json.dumps(minified, ensure_ascii=False)
            new_col_end = col_start + len(escaped)

            if event.quit_after:
                # :wq — pop 후 상위 레벨 복원 또는 패널 닫기
                self._ej_stack.pop()
                if self._ej_stack:
                    ej_editor = self.query_one("#ej-editor", JsonEditor)
                    lines = prev_content.split("\n")
                    lines[row] = lines[row][:col_start] + escaped + lines[row][col_end:]
                    ej_editor.set_content("\n".join(lines))
                    self._update_ej_title()
                else:
                    main_editor = self.query_one("#editor", JsonEditor)
                    main_editor.read_only = self._main_was_read_only
                    main_editor.update_embedded_string(
                        row, col_start, col_end, minified
                    )
                    self.query_one("#ej-panel").remove_class("visible")
                    main_editor._scroll_top = self._main_scroll_top
                    main_editor.focus()
            else:
                # :w — 부모 갱신 후 패널 유지 (스택 pop 안 함)
                if len(self._ej_stack) > 1:
                    lines = prev_content.split("\n")
                    lines[row] = lines[row][:col_start] + escaped + lines[row][col_end:]
                    new_prev = "\n".join(lines)
                    self._ej_stack[-1] = (
                        row,
                        col_start,
                        new_col_end,
                        new_prev,
                        event.content,
                    )
                else:
                    main_editor = self.query_one("#editor", JsonEditor)
                    main_editor.update_embedded_string(
                        row, col_start, col_end, minified
                    )
                    self._ej_stack[-1] = (
                        row,
                        col_start,
                        new_col_end,
                        prev_content,
                        event.content,
                    )
                self._update_ej_title()

            self.notify("Embedded JSON saved", severity="information")
            return

        target = event.file_path or self.file_path
        if not target:
            self.notify("No file name — use :w <file>", severity="warning")
            return

        try:
            path = Path(target)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(event.content, encoding="utf-8")
            self.file_path = str(path)
            self._update_title()
            self.notify(f"Saved: {self.file_path}", severity="information")
            if event.quit_after:
                self._save_and_exit()
        except OSError as exc:
            self.notify(f"Save failed: {exc}", severity="error", timeout=6)

    def on_json_editor_file_open_requested(
        self, event: JsonEditor.FileOpenRequested
    ) -> None:
        self._open_file(event.file_path)

    def on_json_editor_file_navigate_requested(
        self, event: JsonEditor.FileNavigateRequested
    ) -> None:
        if event.action == "next":
            self._navigate_file(1)
        elif event.action == "prev":
            self._navigate_file(-1)
        elif event.action == "alternate":
            if not self._alternate_file:
                self.notify("No alternate file", severity="warning")
            else:
                self._open_file(self._alternate_file)

    def on_json_editor_help_toggle_requested(self) -> None:
        help_panel = self.query_one("#help-panel")
        help_panel.toggle_class("visible")
        if help_panel.has_class("visible"):
            self.query_one("#help-editor").focus()
        else:
            self.query_one("#editor").focus()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "help-close":
            self.query_one("#help-panel").remove_class("visible")
            self.query_one("#editor").focus()
        elif event.button.id == "ej-close":
            self._close_ej_panel()

    def _ej_has_unsaved_changes(self) -> bool:
        """Check if current ej content differs from original."""
        if not self._ej_stack:
            return False
        ej_editor = self.query_one("#ej-editor", JsonEditor)
        current = ej_editor.get_content()
        _, _, _, _, original = self._ej_stack[-1]
        return current != original

    def _update_ej_title(self) -> None:
        """Update ej panel title with current nesting level and modified indicator."""
        level = len(self._ej_stack)
        title = self.query_one("#ej-title", Static)
        modified = " [+]" if self._ej_has_unsaved_changes() else ""
        title.update(f"[b]Edit Embedded JSON[/b] [dim](level {level}){modified}[/dim]")

    def _close_ej_panel(self) -> None:
        """Close or pop one level of ej editing."""
        if not self._ej_stack:
            self.query_one("#ej-panel").remove_class("visible")
            main_editor = self.query_one("#editor", JsonEditor)
            main_editor.read_only = self._main_was_read_only
            main_editor._scroll_top = self._main_scroll_top
            main_editor.focus()
            return

        # Pop current level and get content to restore
        _, _, _, restore_content, _ = self._ej_stack.pop()

        if self._ej_stack:
            # Restore previous level content
            ej_editor = self.query_one("#ej-editor", JsonEditor)
            ej_editor.set_content(restore_content)
            self._update_ej_title()
        else:
            # No more levels, close panel and restore main editor state
            self.query_one("#ej-panel").remove_class("visible")
            main_editor = self.query_one("#editor", JsonEditor)
            main_editor.read_only = self._main_was_read_only
            main_editor._scroll_top = self._main_scroll_top
            main_editor.focus()

    def on_json_editor_embedded_edit_requested(
        self, event: JsonEditor.EmbeddedEditRequested
    ) -> None:
        ej_editor = self.query_one("#ej-editor", JsonEditor)

        if self._is_ej_editor_focused():
            # Nested ej from ej panel - push to stack
            current_content = ej_editor.get_content()
            self._ej_stack.append(
                (
                    event.source_row,
                    event.source_col_start,
                    event.source_col_end,
                    current_content,
                    event.content,  # original content for change detection
                )
            )
        else:
            # From main editor - reset stack to level 1
            main_editor = self.query_one("#editor", JsonEditor)
            self._main_was_read_only = main_editor.read_only
            self._main_scroll_top = main_editor._scroll_top
            main_editor.read_only = True
            self._ej_stack = [
                (
                    event.source_row,
                    event.source_col_start,
                    event.source_col_end,
                    "",  # No previous ej content
                    event.content,  # original content for change detection
                )
            ]

        # Set content and show panel
        ej_editor.set_content(event.content)
        self._update_ej_title()
        self.query_one("#ej-panel").add_class("visible")
        ej_editor.focus()


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="jvim",
        description="JSON editor with vim-style keybindings",
    )
    parser.add_argument(
        "file",
        nargs="*",
        default=[],
        help="JSON file(s) to open",
    )
    parser.add_argument(
        "-R",
        "--read-only",
        action="store_true",
        default=False,
        help="open in read-only mode",
    )
    args = parser.parse_args()

    file_list: list[str] = args.file
    file_path: str = file_list[0] if file_list else ""
    initial_content: str = _load_data("sample.json")
    jsonl: bool = file_path.lower().endswith(".jsonl") if file_path else False

    if file_path:
        path = Path(file_path)
        try:
            if path.exists():
                initial_content = path.read_text(encoding="utf-8")
                if "\x00" in initial_content:
                    print(f"jvim: binary file: {file_path}", file=sys.stderr)
                    sys.exit(1)
                if not jsonl:
                    jsonl = _detect_jsonl(initial_content)
            else:
                # New file — start with empty object / empty line
                initial_content = "" if jsonl else "{}"
        except UnicodeDecodeError:
            print(f"jvim: binary file: {file_path}", file=sys.stderr)
            sys.exit(1)
        except PermissionError as exc:
            print(f"jvim: {exc}", file=sys.stderr)
            sys.exit(1)

    app = JsonEditorApp(
        file_path=file_path,
        initial_content=initial_content,
        read_only=args.read_only,
        jsonl=jsonl,
        file_list=file_list,
    )
    app.run()


if __name__ == "__main__":
    main()
