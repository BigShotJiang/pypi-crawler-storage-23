# Lessons Learned

## 2026-03-01: f-string 동적 format specifier 음수값 버그

### 문제
`render.py:623` — `f"{'~':>{prefix_w - 1}} \n"`에서 `prefix_w=0`일 때 음수 format specifier → "Sign not allowed in string format specifier" 크래시.

### 근본 원인
`differ.py`에서 `right_editor._show_line_number = False` 설정 → `_gutter_widths()`가 `prefix_w=0` 반환. render 코드는 `prefix_w >= 1`을 암묵적으로 가정하고 있었음.

### 교훈
1. **f-string에 변수 기반 format specifier 사용 시 반드시 0/음수 방어** — `f"{val:>{width}}"` 패턴에서 `width`가 0 이하가 될 수 있는지 항상 확인
2. **내부 속성 직접 변경은 불변 조건(invariant)을 깨뜨릴 수 있음** — `differ.py`가 `_show_line_number`를 직접 바꾸면서, `render.py`가 전제하는 `prefix_w >= 1` 불변 조건이 깨짐
3. **코드 경로 분석 시 "이 값이 0이 될 수 있는가?"를 반드시 검증** — 특히 width, height, count 같은 비음수 정수 변수

### 전수 조사 결과 (동일 패턴)
- `ln_width`: 항상 >= 3 (안전)
- `rec_width`: JSONL에서만 사용, 항상 >= 2 + 가드 조건 있음 (안전)
- `prefix_w`: 0이 되는 유일한 경로가 보고된 버그. 수정 완료
- medium 위험: `differ.py`의 fold 동기화 시 양쪽 구조 불일치 가능성 (#686-688, #91-97)
