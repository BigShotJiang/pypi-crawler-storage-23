__version__ = "1.0.3"

import cvxpylayers._quad_form_dpp  # noqa: F401  # apply monkey-patches at import time
