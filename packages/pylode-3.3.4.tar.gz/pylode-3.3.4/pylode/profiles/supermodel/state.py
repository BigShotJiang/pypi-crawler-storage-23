figure_count = 0
