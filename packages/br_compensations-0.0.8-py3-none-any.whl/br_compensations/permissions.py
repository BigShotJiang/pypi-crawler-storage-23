from allianceauth.authentication.admin import Permission
from django.db import models


PERMISSION_CAN_MANAGE = 'can_manage'

PLUGIN_PERMISSIONS = [
    PERMISSION_CAN_MANAGE
]

class HasCompensationsPluginAccess():
    def has_permission(self, request, view):
        if not request.user.is_authenticated:
            return False
        elif request.user.has_perm(f'br_compensations.{PERMISSION_CAN_MANAGE}'):
            return True
    def has_object_permission(self, request,view, obj):
        if not request.user.is_authenticated:
            return False
        elif request.user.has_perm(f'br_compensations.{PERMISSION_CAN_MANAGE}'):
            return True
    
class General(models.Model):
    """Meta model for app permissions"""

    class Meta:
        """Meta definitions"""
        managed = False
        default_permissions = ()
        permissions = ((PERMISSION_CAN_MANAGE, "Can access plugin"),)    