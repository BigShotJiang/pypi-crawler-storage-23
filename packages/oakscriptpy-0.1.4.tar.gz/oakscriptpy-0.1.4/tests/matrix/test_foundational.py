"""Tests for matrix foundational functions — ported from foundational.test.ts."""

import pytest

from oakscriptpy import matrix


# ==========================================
# matrix.new_matrix
# ==========================================


class TestNewMatrix:
    def test_should_create_a_matrix_with_specified_dimensions(self):
        m = matrix.new_matrix(2, 3, 0)
        assert m.rows == 2
        assert m.columns == 3
        assert len(m.data) == 2
        assert len(m.data[0]) == 3

    def test_should_fill_all_elements_with_initial_value(self):
        m = matrix.new_matrix(2, 2, 5)
        assert m.data == [[5, 5], [5, 5]]

    def test_should_handle_none_initial_value(self):
        m = matrix.new_matrix(2, 2)
        assert m.data == [[None, None], [None, None]]

    def test_should_create_empty_matrix_with_0_rows(self):
        m = matrix.new_matrix(0, 3, 1)
        assert m.rows == 0
        assert m.columns == 3
        assert m.data == []

    def test_should_work_with_string_values(self):
        m = matrix.new_matrix(2, 2, "test")
        assert m.data == [["test", "test"], ["test", "test"]]


# ==========================================
# matrix.get
# ==========================================


class TestGet:
    def test_should_return_element_at_position(self):
        m = matrix.new_matrix(2, 3, 0)
        m.data[0][0] = 1
        m.data[0][1] = 2
        m.data[1][2] = 9

        assert matrix.get(m, 0, 0) == 1
        assert matrix.get(m, 0, 1) == 2
        assert matrix.get(m, 0, 2) == 0
        assert matrix.get(m, 1, 2) == 9

    def test_should_work_with_index_starting_at_0(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 100)
        assert matrix.get(m, 0, 0) == 100


# ==========================================
# matrix.set
# ==========================================


class TestSet:
    def test_should_set_element_at_position(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 10)
        matrix.set(m, 1, 2, 20)

        assert m.data[0][0] == 10
        assert m.data[1][2] == 20

    def test_should_overwrite_existing_value(self):
        m = matrix.new_matrix(2, 2, 5)
        assert matrix.get(m, 0, 0) == 5

        matrix.set(m, 0, 0, 99)
        assert matrix.get(m, 0, 0) == 99

    def test_should_work_with_different_types(self):
        m = matrix.new_matrix(2, 2, "a")
        matrix.set(m, 0, 0, "changed")
        assert matrix.get(m, 0, 0) == "changed"


# ==========================================
# matrix.rows
# ==========================================


class TestRows:
    def test_should_return_number_of_rows(self):
        m = matrix.new_matrix(2, 6, 0)
        assert matrix.rows(m) == 2

    def test_should_return_0_for_empty_matrix(self):
        m = matrix.new_matrix(0, 5, 0)
        assert matrix.rows(m) == 0

    def test_should_return_correct_value_for_square_matrix(self):
        m = matrix.new_matrix(5, 5, 0)
        assert matrix.rows(m) == 5


# ==========================================
# matrix.columns
# ==========================================


class TestColumns:
    def test_should_return_number_of_columns(self):
        m = matrix.new_matrix(2, 6, 0)
        assert matrix.columns(m) == 6

    def test_should_return_correct_value_for_empty_matrix(self):
        m = matrix.new_matrix(0, 5, 0)
        assert matrix.columns(m) == 5

    def test_should_return_correct_value_for_square_matrix(self):
        m = matrix.new_matrix(5, 5, 0)
        assert matrix.columns(m) == 5


# ==========================================
# matrix.elements_count
# ==========================================


class TestElementsCount:
    def test_should_return_total_element_count(self):
        m = matrix.new_matrix(3, 4, 0)
        assert matrix.elements_count(m) == 12

    def test_should_return_0_for_empty_matrix(self):
        m = matrix.new_matrix(0, 5, 0)
        assert matrix.elements_count(m) == 0

    def test_should_return_correct_count_for_single_element_matrix(self):
        m = matrix.new_matrix(1, 1, 0)
        assert matrix.elements_count(m) == 1

    def test_should_match_rows_times_columns(self):
        m = matrix.new_matrix(7, 11, 0)
        assert matrix.elements_count(m) == matrix.rows(m) * matrix.columns(m)


# ==========================================
# matrix.row
# ==========================================


class TestRow:
    def test_should_return_row_as_list(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)

        r = matrix.row(m, 0)
        assert r == [1, 2, 3]

    def test_should_return_a_copy_not_reference(self):
        m = matrix.new_matrix(2, 2, 5)
        r = matrix.row(m, 0)
        r[0] = 999

        assert matrix.get(m, 0, 0) == 5

    def test_should_work_with_index_0(self):
        m = matrix.new_matrix(3, 2, 0)
        matrix.set(m, 0, 0, 10)
        matrix.set(m, 0, 1, 20)

        assert matrix.row(m, 0) == [10, 20]

    def test_should_work_with_last_row(self):
        m = matrix.new_matrix(3, 2, 0)
        matrix.set(m, 2, 0, 100)
        matrix.set(m, 2, 1, 200)

        assert matrix.row(m, 2) == [100, 200]


# ==========================================
# matrix.col
# ==========================================


class TestCol:
    def test_should_return_column_as_list(self):
        m = matrix.new_matrix(3, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 0, 2)
        matrix.set(m, 2, 0, 3)

        c = matrix.col(m, 0)
        assert c == [1, 2, 3]

    def test_should_return_a_copy_not_reference(self):
        m = matrix.new_matrix(2, 2, 5)
        c = matrix.col(m, 0)
        c[0] = 999

        assert matrix.get(m, 0, 0) == 5

    def test_should_work_with_index_0(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 10)
        matrix.set(m, 1, 0, 20)

        assert matrix.col(m, 0) == [10, 20]

    def test_should_work_with_last_column(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 2, 100)
        matrix.set(m, 1, 2, 200)

        assert matrix.col(m, 2) == [100, 200]


# ==========================================
# matrix.copy_matrix
# ==========================================


class TestCopyMatrix:
    def test_should_create_a_deep_copy(self):
        m1 = matrix.new_matrix(2, 3, 1)
        m2 = matrix.copy_matrix(m1)

        assert m2.rows == m1.rows
        assert m2.columns == m1.columns
        assert m2.data == m1.data

    def test_should_not_share_references(self):
        m1 = matrix.new_matrix(2, 2, 1)
        m2 = matrix.copy_matrix(m1)

        matrix.set(m2, 0, 0, 99)

        assert matrix.get(m1, 0, 0) == 1
        assert matrix.get(m2, 0, 0) == 99

    def test_should_handle_empty_matrix(self):
        m1 = matrix.new_matrix(0, 2, 0)
        m2 = matrix.copy_matrix(m1)

        assert m2.rows == 0
        assert m2.columns == 2
        assert m2.data == []

    def test_should_work_with_different_data_types(self):
        m1 = matrix.new_matrix(2, 2, "test")
        m2 = matrix.copy_matrix(m1)

        assert m2.data == [["test", "test"], ["test", "test"]]


# ==========================================
# matrix.fill
# ==========================================


class TestFill:
    def test_should_fill_entire_matrix_by_default(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.fill(m, 9)

        assert m.data == [[9, 9, 9], [9, 9, 9]]

    def test_should_fill_specified_range(self):
        m = matrix.new_matrix(4, 5, 0)
        matrix.fill(m, 9, 0, 2, 1, 3)

        assert matrix.get(m, 0, 0) == 0
        assert matrix.get(m, 0, 1) == 9
        assert matrix.get(m, 0, 2) == 9
        assert matrix.get(m, 0, 3) == 0
        assert matrix.get(m, 1, 1) == 9
        assert matrix.get(m, 1, 2) == 9
        assert matrix.get(m, 2, 1) == 0

    def test_should_fill_with_from_row_only(self):
        m = matrix.new_matrix(3, 2, 0)
        matrix.fill(m, 5, 1)

        assert m.data[0] == [0, 0]
        assert m.data[1] == [5, 5]
        assert m.data[2] == [5, 5]

    def test_should_fill_with_from_column_only(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.fill(m, 7, 0, None, 1)

        assert m.data == [[0, 7, 7], [0, 7, 7]]

    def test_should_handle_empty_range(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.fill(m, 9, 0, 0, 0, 0)

        assert m.data == [[0, 0], [0, 0]]


# ==========================================
# matrix.is_square
# ==========================================


class TestIsSquare:
    def test_should_return_true_for_square_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        assert matrix.is_square(m) is True

    def test_should_return_false_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 0)
        assert matrix.is_square(m) is False

    def test_should_return_true_for_1x1_matrix(self):
        m = matrix.new_matrix(1, 1, 0)
        assert matrix.is_square(m) is True

    def test_should_handle_empty_matrix_0x0(self):
        m = matrix.new_matrix(0, 0, 0)
        assert matrix.is_square(m) is True

    def test_should_return_false_for_1x2_matrix(self):
        m = matrix.new_matrix(1, 2, 0)
        assert matrix.is_square(m) is False


# ==========================================
# matrix.is_zero
# ==========================================


class TestIsZero:
    def test_should_return_true_for_zero_matrix(self):
        m = matrix.new_matrix(2, 2, 0)
        assert matrix.is_zero(m) is True

    def test_should_return_false_if_any_element_is_non_zero(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        assert matrix.is_zero(m) is False

    def test_should_return_true_for_empty_matrix(self):
        m = matrix.new_matrix(0, 2, 0)
        assert matrix.is_zero(m) is True

    def test_should_handle_negative_numbers(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, -1)
        assert matrix.is_zero(m) is False

    def test_should_handle_decimal_numbers(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 0.001)
        assert matrix.is_zero(m) is False

    def test_should_work_with_larger_matrices(self):
        m = matrix.new_matrix(10, 10, 0)
        assert matrix.is_zero(m) is True

        matrix.set(m, 9, 9, 1)
        assert matrix.is_zero(m) is False


# ==========================================
# matrix.is_binary
# ==========================================


class TestIsBinary:
    def test_should_return_true_for_matrix_with_only_0s_and_1s(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 1)
        assert matrix.is_binary(m) is True

    def test_should_return_false_for_matrix_with_other_values(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 2)
        assert matrix.is_binary(m) is False

    def test_should_return_true_for_zero_matrix(self):
        m = matrix.new_matrix(2, 2, 0)
        assert matrix.is_binary(m) is True

    def test_should_return_true_for_ones_matrix(self):
        m = matrix.new_matrix(2, 2, 1)
        assert matrix.is_binary(m) is True

    def test_should_return_true_for_empty_matrix(self):
        m = matrix.new_matrix(0, 2, 0)
        assert matrix.is_binary(m) is True

    def test_should_handle_negative_numbers(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, -1)
        assert matrix.is_binary(m) is False

    def test_should_handle_decimal_1(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1.0)
        assert matrix.is_binary(m) is True

    def test_should_reject_decimal_values_other_than_1_0(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 0.5)
        assert matrix.is_binary(m) is False


# ==========================================
# Integration Tests
# ==========================================


class TestFoundationalIntegration:
    def test_should_work_with_complete_workflow(self):
        # Create a 3x3 matrix
        m = matrix.new_matrix(3, 3, 0)

        # Check dimensions
        assert matrix.rows(m) == 3
        assert matrix.columns(m) == 3
        assert matrix.elements_count(m) == 9
        assert matrix.is_square(m) is True
        assert matrix.is_zero(m) is True
        assert matrix.is_binary(m) is True

        # Set some values
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 1)
        matrix.set(m, 2, 2, 1)

        # Check properties changed
        assert matrix.is_zero(m) is False
        assert matrix.is_binary(m) is True

        # Get rows and columns
        assert matrix.row(m, 0) == [1, 0, 0]
        assert matrix.row(m, 1) == [0, 1, 0]
        assert matrix.col(m, 0) == [1, 0, 0]
        assert matrix.col(m, 2) == [0, 0, 1]

        # Copy and modify
        m2 = matrix.copy_matrix(m)
        matrix.set(m2, 0, 0, 5)
        assert matrix.get(m, 0, 0) == 1
        assert matrix.get(m2, 0, 0) == 5
        assert matrix.is_binary(m2) is False

    def test_should_work_with_fill_in_a_range(self):
        # Create a 4x4 matrix
        m = matrix.new_matrix(4, 4, 0)

        # Fill center 2x2 with 1s
        matrix.fill(m, 1, 1, 3, 1, 3)

        assert matrix.row(m, 0) == [0, 0, 0, 0]
        assert matrix.row(m, 1) == [0, 1, 1, 0]
        assert matrix.row(m, 2) == [0, 1, 1, 0]
        assert matrix.row(m, 3) == [0, 0, 0, 0]

        assert matrix.is_binary(m) is True
        assert matrix.is_zero(m) is False


# ==========================================
# Bounds Checking
# ==========================================


class TestBoundsCheckingGet:
    def test_should_raise_error_for_row_out_of_bounds(self):
        m = matrix.new_matrix(2, 3, 0)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.get(m, 5, 0)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.get(m, -1, 0)

    def test_should_raise_error_for_column_out_of_bounds(self):
        m = matrix.new_matrix(2, 3, 0)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.get(m, 0, 5)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.get(m, 0, -1)


class TestBoundsCheckingSet:
    def test_should_raise_error_for_row_out_of_bounds(self):
        m = matrix.new_matrix(2, 3, 0)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.set(m, 5, 0, 1)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.set(m, -1, 0, 1)

    def test_should_raise_error_for_column_out_of_bounds(self):
        m = matrix.new_matrix(2, 3, 0)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.set(m, 0, 5, 1)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.set(m, 0, -1, 1)


class TestBoundsCheckingRow:
    def test_should_raise_error_for_row_out_of_bounds(self):
        m = matrix.new_matrix(2, 3, 0)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.row(m, 5)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.row(m, -1)


class TestBoundsCheckingCol:
    def test_should_raise_error_for_column_out_of_bounds(self):
        m = matrix.new_matrix(2, 3, 0)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.col(m, 5)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.col(m, -1)
