"""Tests for matrix linear algebra functions — ported from linear-algebra.test.ts."""

import math

import pytest

from oakscriptpy import matrix
from oakscriptpy._types import PineMatrix


# ==========================================
# matrix.mult
# ==========================================


class TestMultMatrixMatrix:
    def test_should_multiply_two_square_matrices(self):
        # [[1, 2], [3, 4]] x [[5, 6], [7, 8]] = [[19, 22], [43, 50]]
        m1 = matrix.new_matrix(2, 2, 0)
        matrix.set(m1, 0, 0, 1)
        matrix.set(m1, 0, 1, 2)
        matrix.set(m1, 1, 0, 3)
        matrix.set(m1, 1, 1, 4)

        m2 = matrix.new_matrix(2, 2, 0)
        matrix.set(m2, 0, 0, 5)
        matrix.set(m2, 0, 1, 6)
        matrix.set(m2, 1, 0, 7)
        matrix.set(m2, 1, 1, 8)

        result = matrix.mult(m1, m2)
        assert isinstance(result, PineMatrix)
        assert matrix.get(result, 0, 0) == 19
        assert matrix.get(result, 0, 1) == 22
        assert matrix.get(result, 1, 0) == 43
        assert matrix.get(result, 1, 1) == 50

    def test_should_multiply_non_square_matrices(self):
        # 6x2 matrix x 2x3 matrix = 6x3 matrix
        m1 = matrix.new_matrix(6, 2, 5)
        m2 = matrix.new_matrix(2, 3, 4)

        result = matrix.mult(m1, m2)
        assert isinstance(result, PineMatrix)
        assert matrix.rows(result) == 6
        assert matrix.columns(result) == 3
        # Each element should be 5*4 + 5*4 = 40
        assert matrix.get(result, 0, 0) == 40

    def test_should_raise_error_for_dimension_mismatch(self):
        m1 = matrix.new_matrix(2, 3, 1)
        m2 = matrix.new_matrix(4, 2, 1)

        with pytest.raises(ValueError, match="dimension mismatch"):
            matrix.mult(m1, m2)

    def test_should_handle_identity_matrix_multiplication(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 0, 4)
        matrix.set(m, 1, 1, 5)
        matrix.set(m, 1, 2, 6)
        matrix.set(m, 2, 0, 7)
        matrix.set(m, 2, 1, 8)
        matrix.set(m, 2, 2, 9)

        identity = matrix.new_matrix(3, 3, 0)
        matrix.set(identity, 0, 0, 1)
        matrix.set(identity, 1, 1, 1)
        matrix.set(identity, 2, 2, 1)

        result = matrix.mult(m, identity)
        assert isinstance(result, PineMatrix)
        assert matrix.get(result, 0, 0) == 1
        assert matrix.get(result, 1, 1) == 5
        assert matrix.get(result, 2, 2) == 9


class TestMultMatrixScalar:
    def test_should_multiply_matrix_by_scalar(self):
        m = matrix.new_matrix(2, 3, 4)
        result = matrix.mult(m, 5)
        assert isinstance(result, PineMatrix)

        assert matrix.rows(result) == 2
        assert matrix.columns(result) == 3
        assert matrix.get(result, 0, 0) == 20
        assert matrix.get(result, 1, 2) == 20

    def test_should_handle_zero_scalar(self):
        m = matrix.new_matrix(2, 2, 5)
        result = matrix.mult(m, 0)
        assert isinstance(result, PineMatrix)

        assert matrix.is_zero(result) is True

    def test_should_handle_negative_scalar(self):
        m = matrix.new_matrix(2, 2, 3)
        result = matrix.mult(m, -2)
        assert isinstance(result, PineMatrix)

        assert matrix.get(result, 0, 0) == -6


class TestMultMatrixVector:
    def test_should_multiply_matrix_by_vector(self):
        m = matrix.new_matrix(2, 3, 4)
        vec = [1, 1, 1]

        result = matrix.mult(m, vec)
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0] == 12
        assert result[1] == 12

    def test_should_raise_error_for_vector_dimension_mismatch(self):
        m = matrix.new_matrix(2, 3, 1)
        vec = [1, 2]  # Wrong size

        with pytest.raises(ValueError, match="must equal"):
            matrix.mult(m, vec)


# ==========================================
# matrix.pow
# ==========================================


class TestPow:
    def test_should_compute_matrix_power(self):
        m = matrix.new_matrix(2, 2, 2)
        result = matrix.pow(m, 2)

        # [[2,2],[2,2]]^2 = [[8,8],[8,8]]
        assert matrix.get(result, 0, 0) == 8
        assert matrix.get(result, 0, 1) == 8

    def test_should_return_identity_for_power_0(self):
        m = matrix.new_matrix(3, 3, 5)
        result = matrix.pow(m, 0)

        assert matrix.is_identity(result) is True

    def test_should_return_original_matrix_for_power_1(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        result = matrix.pow(m, 1)

        assert matrix.get(result, 0, 0) == 1
        assert matrix.get(result, 0, 1) == 2
        assert matrix.get(result, 1, 0) == 3
        assert matrix.get(result, 1, 1) == 4

    def test_should_compute_power_of_3(self):
        m = matrix.new_matrix(2, 2, 2)
        result = matrix.pow(m, 3)

        # [[2,2],[2,2]]^3 = [[32,32],[32,32]]
        assert matrix.get(result, 0, 0) == 32

    def test_should_raise_error_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 1)

        with pytest.raises(ValueError, match="must be square"):
            matrix.pow(m, 2)

    def test_should_handle_negative_power(self):
        # [[1, 2], [3, 4]] has inverse [[-2, 1], [1.5, -0.5]]
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        result = matrix.pow(m, -1)

        assert matrix.get(result, 0, 0) == pytest.approx(-2, abs=1e-6)
        assert matrix.get(result, 0, 1) == pytest.approx(1, abs=1e-6)
        assert matrix.get(result, 1, 0) == pytest.approx(1.5, abs=1e-6)
        assert matrix.get(result, 1, 1) == pytest.approx(-0.5, abs=1e-6)


# ==========================================
# matrix.det
# ==========================================


class TestDet:
    def test_should_compute_determinant_of_2x2_matrix(self):
        # det([[3, 7], [1, -4]]) = 3*(-4) - 7*1 = -19
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 3)
        matrix.set(m, 0, 1, 7)
        matrix.set(m, 1, 0, 1)
        matrix.set(m, 1, 1, -4)

        assert matrix.det(m) == -19

    def test_should_compute_determinant_of_3x3_matrix(self):
        # [[1, 2, 3], [4, 5, 6], [7, 8, 10]]
        # det = 1*(50-48) - 2*(40-42) + 3*(32-35) = 2+4-9 = -3
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 0, 4)
        matrix.set(m, 1, 1, 5)
        matrix.set(m, 1, 2, 6)
        matrix.set(m, 2, 0, 7)
        matrix.set(m, 2, 1, 8)
        matrix.set(m, 2, 2, 10)

        assert matrix.det(m) == pytest.approx(-3, abs=1e-6)

    def test_should_return_1_for_identity_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 1)
        matrix.set(m, 2, 2, 1)

        assert matrix.det(m) == pytest.approx(1, abs=1e-6)

    def test_should_return_0_for_singular_matrix(self):
        # [[1, 2], [2, 4]] is singular
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 2)
        matrix.set(m, 1, 1, 4)

        assert matrix.det(m) == pytest.approx(0, abs=1e-6)

    def test_should_return_element_value_for_1x1_matrix(self):
        m = matrix.new_matrix(1, 1, 5)
        assert matrix.det(m) == 5

    def test_should_return_1_for_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)
        assert matrix.det(m) == 1

    def test_should_raise_error_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 1)
        with pytest.raises(ValueError, match="must be square"):
            matrix.det(m)


# ==========================================
# matrix.inv
# ==========================================


class TestInv:
    def test_should_compute_inverse_of_2x2_matrix(self):
        # [[1, 2], [3, 4]] has inverse [[-2, 1], [1.5, -0.5]]
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        result = matrix.inv(m)
        assert result is not None

        assert matrix.get(result, 0, 0) == pytest.approx(-2, abs=1e-6)
        assert matrix.get(result, 0, 1) == pytest.approx(1, abs=1e-6)
        assert matrix.get(result, 1, 0) == pytest.approx(1.5, abs=1e-6)
        assert matrix.get(result, 1, 1) == pytest.approx(-0.5, abs=1e-6)

    def test_should_return_identity_when_multiplied_with_original(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 0, 0)
        matrix.set(m, 1, 1, 1)
        matrix.set(m, 1, 2, 4)
        matrix.set(m, 2, 0, 5)
        matrix.set(m, 2, 1, 6)
        matrix.set(m, 2, 2, 0)

        inv_m = matrix.inv(m)
        assert inv_m is not None

        product = matrix.mult(m, inv_m)
        assert isinstance(product, PineMatrix)

        # Should be close to identity
        assert matrix.get(product, 0, 0) == pytest.approx(1, abs=1e-5)
        assert matrix.get(product, 1, 1) == pytest.approx(1, abs=1e-5)
        assert matrix.get(product, 2, 2) == pytest.approx(1, abs=1e-5)
        assert matrix.get(product, 0, 1) == pytest.approx(0, abs=1e-5)

    def test_should_return_none_for_singular_matrix(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 2)
        matrix.set(m, 1, 1, 4)

        assert matrix.inv(m) is None

    def test_should_return_identity_inverse_as_identity(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 1)
        matrix.set(m, 2, 2, 1)

        result = matrix.inv(m)
        assert result is not None
        assert matrix.is_identity(result) is True

    def test_should_raise_error_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 1)
        with pytest.raises(ValueError, match="must be square"):
            matrix.inv(m)

    def test_should_handle_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)
        result = matrix.inv(m)
        assert result is not None
        assert matrix.rows(result) == 0


# ==========================================
# matrix.pinv
# ==========================================


class TestPinv:
    def test_should_compute_pseudo_inverse_of_square_non_singular_matrix(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        result = matrix.pinv(m)

        # Should be same as regular inverse
        assert matrix.get(result, 0, 0) == pytest.approx(-2, abs=1e-6)
        assert matrix.get(result, 0, 1) == pytest.approx(1, abs=1e-6)

    def test_should_compute_pseudo_inverse_of_tall_matrix(self):
        # 3x2 matrix with full column rank
        m = matrix.new_matrix(3, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 0)
        matrix.set(m, 1, 0, 0)
        matrix.set(m, 1, 1, 1)
        matrix.set(m, 2, 0, 1)
        matrix.set(m, 2, 1, 1)

        result = matrix.pinv(m)

        # Pseudo-inverse should be 2x3
        assert matrix.rows(result) == 2
        assert matrix.columns(result) == 3

    def test_should_compute_pseudo_inverse_of_wide_matrix(self):
        # 2x3 matrix
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 0, 4)
        matrix.set(m, 1, 1, 5)
        matrix.set(m, 1, 2, 6)

        result = matrix.pinv(m)

        # Pseudo-inverse should be 3x2
        assert matrix.rows(result) == 3
        assert matrix.columns(result) == 2

    def test_should_satisfy_a_times_a_pinv_times_a_approx_a(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 0, 4)
        matrix.set(m, 1, 1, 5)
        matrix.set(m, 1, 2, 6)

        pinv_m = matrix.pinv(m)
        temp = matrix.mult(m, pinv_m)
        assert isinstance(temp, PineMatrix)
        result = matrix.mult(temp, m)
        assert isinstance(result, PineMatrix)

        # A x A+ x A should approximately equal A
        assert matrix.get(result, 0, 0) == pytest.approx(1, abs=1e-3)
        assert matrix.get(result, 0, 1) == pytest.approx(2, abs=1e-3)
        assert matrix.get(result, 1, 2) == pytest.approx(6, abs=1e-3)

    def test_should_handle_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)
        result = matrix.pinv(m)
        assert matrix.rows(result) == 0
        assert matrix.columns(result) == 0


# ==========================================
# matrix.rank
# ==========================================


class TestRank:
    def test_should_return_full_rank_for_identity_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 1)
        matrix.set(m, 2, 2, 1)

        assert matrix.rank(m) == 3

    def test_should_return_2_for_rank_2_3x3_matrix(self):
        # [[1, 2, 3], [4, 5, 6], [7, 8, 9]] has rank 2
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 0, 4)
        matrix.set(m, 1, 1, 5)
        matrix.set(m, 1, 2, 6)
        matrix.set(m, 2, 0, 7)
        matrix.set(m, 2, 1, 8)
        matrix.set(m, 2, 2, 9)

        assert matrix.rank(m) == 2

    def test_should_return_0_for_zero_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        assert matrix.rank(m) == 0

    def test_should_return_1_for_matrix_with_one_non_zero_row(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)

        assert matrix.rank(m) == 1

    def test_should_handle_non_square_matrices(self):
        # 2x3 matrix with rank 2
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 0)
        matrix.set(m, 0, 2, 1)
        matrix.set(m, 1, 0, 0)
        matrix.set(m, 1, 1, 1)
        matrix.set(m, 1, 2, 1)

        assert matrix.rank(m) == 2

    def test_should_return_0_for_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)
        assert matrix.rank(m) == 0


# ==========================================
# matrix.eigenvalues
# ==========================================


class TestEigenvalues:
    def test_should_compute_eigenvalues_of_2x2_matrix(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 2)
        matrix.set(m, 0, 1, 4)
        matrix.set(m, 1, 0, 6)
        matrix.set(m, 1, 1, 8)

        ev = matrix.eigenvalues(m)

        assert len(ev) == 2
        # Check that sum of eigenvalues equals trace
        assert ev[0] + ev[1] == pytest.approx(10, abs=1e-3)
        # Check that product of eigenvalues equals determinant
        assert ev[0] * ev[1] == pytest.approx(2 * 8 - 4 * 6, abs=1e-3)

    def test_should_compute_eigenvalues_of_diagonal_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 2)
        matrix.set(m, 1, 1, 5)
        matrix.set(m, 2, 2, 8)

        ev = matrix.eigenvalues(m)

        assert len(ev) == 3
        # Eigenvalues of diagonal matrix are the diagonal elements
        assert sorted(ev, reverse=True) == [8, 5, 2]

    def test_should_compute_eigenvalues_of_identity_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 1)
        matrix.set(m, 2, 2, 1)

        ev = matrix.eigenvalues(m)

        assert len(ev) == 3
        for e in ev:
            assert e == pytest.approx(1, abs=1e-5)

    def test_should_return_single_eigenvalue_for_1x1_matrix(self):
        m = matrix.new_matrix(1, 1, 7)
        ev = matrix.eigenvalues(m)

        assert len(ev) == 1
        assert ev[0] == 7

    def test_should_return_empty_list_for_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)
        ev = matrix.eigenvalues(m)

        assert len(ev) == 0

    def test_should_raise_error_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 1)
        with pytest.raises(ValueError, match="must be square"):
            matrix.eigenvalues(m)


# ==========================================
# matrix.eigenvectors
# ==========================================


class TestEigenvectors:
    def test_should_compute_eigenvectors_of_2x2_matrix(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 2)
        matrix.set(m, 0, 1, 4)
        matrix.set(m, 1, 0, 6)
        matrix.set(m, 1, 1, 8)

        evecs = matrix.eigenvectors(m)

        assert matrix.rows(evecs) == 2
        assert matrix.columns(evecs) == 2

    def test_should_produce_eigenvectors_as_normalized_unit_vectors(self):
        # Simple 2x2 matrix
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 4)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 1)
        matrix.set(m, 1, 1, 3)

        evecs = matrix.eigenvectors(m)

        # For each eigenvector, verify it's approximately unit length
        for i in range(matrix.columns(evecs)):
            v = matrix.col(evecs, i)

            # Compute norm
            norm = math.sqrt(v[0] * v[0] + v[1] * v[1])

            # Should be approximately 1 (unit vector)
            assert norm == pytest.approx(1, abs=1e-3)

    def test_should_compute_eigenvectors_of_identity_matrix(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 1)

        evecs = matrix.eigenvectors(m)

        assert matrix.rows(evecs) == 2
        assert matrix.columns(evecs) == 2

    def test_should_return_empty_matrix_for_empty_input(self):
        m = matrix.new_matrix(0, 0, 0)
        evecs = matrix.eigenvectors(m)

        assert matrix.rows(evecs) == 0

    def test_should_raise_error_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 1)
        with pytest.raises(ValueError, match="must be square"):
            matrix.eigenvectors(m)


# ==========================================
# matrix.kron
# ==========================================


class TestKron:
    def test_should_compute_kronecker_product_of_two_2x2_matrices(self):
        m1 = matrix.new_matrix(2, 2, 1)
        m2 = matrix.new_matrix(2, 2, 2)

        result = matrix.kron(m1, m2)

        # Result should be 4x4
        assert matrix.rows(result) == 4
        assert matrix.columns(result) == 4

        # All elements should be 1*2 = 2
        assert matrix.get(result, 0, 0) == 2
        assert matrix.get(result, 3, 3) == 2

    def test_should_compute_kronecker_product_correctly(self):
        # [[1, 2], [3, 4]] kron [[0, 5], [6, 7]]
        m1 = matrix.new_matrix(2, 2, 0)
        matrix.set(m1, 0, 0, 1)
        matrix.set(m1, 0, 1, 2)
        matrix.set(m1, 1, 0, 3)
        matrix.set(m1, 1, 1, 4)

        m2 = matrix.new_matrix(2, 2, 0)
        matrix.set(m2, 0, 0, 0)
        matrix.set(m2, 0, 1, 5)
        matrix.set(m2, 1, 0, 6)
        matrix.set(m2, 1, 1, 7)

        result = matrix.kron(m1, m2)

        # Block (0,0) = 1 * m2 = [[0, 5], [6, 7]]
        assert matrix.get(result, 0, 0) == 0
        assert matrix.get(result, 0, 1) == 5
        assert matrix.get(result, 1, 0) == 6
        assert matrix.get(result, 1, 1) == 7

        # Block (0,1) = 2 * m2 = [[0, 10], [12, 14]]
        assert matrix.get(result, 0, 2) == 0
        assert matrix.get(result, 0, 3) == 10

        # Block (1,0) = 3 * m2 = [[0, 15], [18, 21]]
        assert matrix.get(result, 2, 0) == 0
        assert matrix.get(result, 2, 1) == 15

    def test_should_handle_non_square_matrices(self):
        m1 = matrix.new_matrix(2, 3, 1)
        m2 = matrix.new_matrix(3, 2, 2)

        result = matrix.kron(m1, m2)

        assert matrix.rows(result) == 6  # 2 * 3
        assert matrix.columns(result) == 6  # 3 * 2

    def test_should_handle_empty_matrices(self):
        m1 = matrix.new_matrix(0, 0, 1)
        m2 = matrix.new_matrix(2, 2, 2)

        result = matrix.kron(m1, m2)

        assert matrix.rows(result) == 0
        assert matrix.columns(result) == 0

    def test_should_satisfy_kronecker_product_associativity(self):
        # (A kron B) kron C = A kron (B kron C) for associativity
        a = matrix.new_matrix(2, 2, 1)
        b = matrix.new_matrix(2, 2, 2)
        c = matrix.new_matrix(2, 2, 3)

        left = matrix.kron(matrix.kron(a, b), c)
        right = matrix.kron(a, matrix.kron(b, c))

        assert matrix.rows(left) == matrix.rows(right)
        assert matrix.columns(left) == matrix.columns(right)

        # Check some elements
        assert matrix.get(left, 0, 0) == matrix.get(right, 0, 0)
        assert matrix.get(left, 7, 7) == matrix.get(right, 7, 7)


# ==========================================
# matrix.newtype
# ==========================================


class TestNewtype:
    def test_should_create_matrix_with_custom_type(self):
        default_point = {"x": 0, "y": 0}
        m = matrix.newtype(2, 2, default_point)

        assert matrix.rows(m) == 2
        assert matrix.columns(m) == 2
        assert matrix.get(m, 0, 0) == {"x": 0, "y": 0}

    def test_should_handle_default_values(self):
        m = matrix.newtype(3, 3)

        assert matrix.rows(m) == 3
        assert matrix.columns(m) == 3

    def test_should_handle_zero_dimensions(self):
        m = matrix.newtype(0, 0)

        assert matrix.rows(m) == 0
        assert matrix.columns(m) == 0

    def test_should_work_with_string_types(self):
        m = matrix.newtype(2, 2, "test")

        assert matrix.get(m, 0, 0) == "test"
        assert matrix.get(m, 1, 1) == "test"


# ==========================================
# Integration Tests
# ==========================================


class TestLinearAlgebraIntegration:
    def test_should_verify_a_times_a_inv_equals_identity(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 0, 0)
        matrix.set(m, 1, 1, 1)
        matrix.set(m, 1, 2, 4)
        matrix.set(m, 2, 0, 5)
        matrix.set(m, 2, 1, 6)
        matrix.set(m, 2, 2, 0)

        inv_m = matrix.inv(m)
        assert inv_m is not None

        product = matrix.mult(m, inv_m)
        assert isinstance(product, PineMatrix)

        # Should be close to identity
        for i in range(3):
            for j in range(3):
                expected = 1 if i == j else 0
                assert matrix.get(product, i, j) == pytest.approx(expected, abs=1e-5)

    def test_should_verify_det_ab_equals_det_a_times_det_b(self):
        a = matrix.new_matrix(2, 2, 0)
        matrix.set(a, 0, 0, 1)
        matrix.set(a, 0, 1, 2)
        matrix.set(a, 1, 0, 3)
        matrix.set(a, 1, 1, 4)

        b = matrix.new_matrix(2, 2, 0)
        matrix.set(b, 0, 0, 5)
        matrix.set(b, 0, 1, 6)
        matrix.set(b, 1, 0, 7)
        matrix.set(b, 1, 1, 8)

        ab = matrix.mult(a, b)
        assert isinstance(ab, PineMatrix)

        det_a = matrix.det(a)
        det_b = matrix.det(b)
        det_ab = matrix.det(ab)

        assert det_ab == pytest.approx(det_a * det_b, abs=1e-5)

    def test_should_verify_rank_plus_nullity_equals_columns(self):
        m = matrix.new_matrix(3, 4, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 1)
        matrix.set(m, 0, 3, 0)
        matrix.set(m, 1, 0, 0)
        matrix.set(m, 1, 1, 1)
        matrix.set(m, 1, 2, 1)
        matrix.set(m, 1, 3, 0)
        matrix.set(m, 2, 0, 1)
        matrix.set(m, 2, 1, 3)
        matrix.set(m, 2, 2, 2)
        matrix.set(m, 2, 3, 0)

        r = matrix.rank(m)
        # Rank-nullity theorem: rank + nullity = number of columns
        # nullity = columns - rank
        nullity = matrix.columns(m) - r

        assert r + nullity == matrix.columns(m)

    def test_should_verify_eigenvalue_decomposition_for_symmetric_matrix(self):
        # Symmetric matrix has real eigenvalues and orthogonal eigenvectors
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 4)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 2)
        matrix.set(m, 1, 1, 4)

        evals = matrix.eigenvalues(m)

        # Eigenvalues of symmetric matrix should be real
        # For [[4, 2], [2, 4]]: eigenvalues are 6 and 2
        sorted_evals = sorted(evals, reverse=True)
        assert sorted_evals[0] == pytest.approx(6, abs=1e-3)
        assert sorted_evals[1] == pytest.approx(2, abs=1e-3)


# ==========================================
# Edge Cases & Numerical Stability
# ==========================================


class TestNumericalStability:
    def test_should_handle_near_singular_matrices_in_inv(self):
        # Matrix with condition number close to machine epsilon boundary
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 1)
        matrix.set(m, 1, 0, 1)
        matrix.set(m, 1, 1, 1.0000001)

        result = matrix.inv(m)
        # Should still compute inverse for slightly perturbed singular matrix
        assert result is not None

    def test_should_handle_large_values_in_det(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1e8)
        matrix.set(m, 0, 1, 2e8)
        matrix.set(m, 1, 0, 3e8)
        matrix.set(m, 1, 1, 4e8)

        d = matrix.det(m)
        # det = 4e16 - 6e16 = -2e16
        assert d == pytest.approx(-2e16, rel=1e-6)

    def test_should_handle_small_values_in_rank(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1e-6)
        matrix.set(m, 0, 1, 2e-6)
        matrix.set(m, 1, 0, 3e-6)
        matrix.set(m, 1, 1, 4e-6)

        # Small but above epsilon values should still have correct rank
        r = matrix.rank(m)
        assert r == 2
