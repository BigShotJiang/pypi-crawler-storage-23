"""Tests for array percentile functions.

Ported from oakscriptJS/tests/array/percentile.test.ts
"""

import math

import pytest

from oakscriptpy import array


# ---------------------------------------------------------------------------
# array.percentile_linear_interpolation
# ---------------------------------------------------------------------------

class TestPercentileLinearInterpolation:
    def test_calculate_50th_percentile_median(self):
        arr = [1, 2, 3, 4, 5]
        p50 = array.percentile_linear_interpolation(arr, 50)
        assert p50 == 3

    def test_use_linear_interpolation_for_non_exact_positions(self):
        arr = [1, 2, 3, 4]
        p50 = array.percentile_linear_interpolation(arr, 50)
        assert p50 == 2.5

    def test_calculate_25th_percentile(self):
        arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        p25 = array.percentile_linear_interpolation(arr, 25)
        assert p25 == pytest.approx(3.25)

    def test_calculate_75th_percentile(self):
        arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        p75 = array.percentile_linear_interpolation(arr, 75)
        assert p75 == pytest.approx(7.75)

    def test_handle_0th_percentile(self):
        arr = [1, 2, 3, 4, 5]
        p0 = array.percentile_linear_interpolation(arr, 0)
        assert p0 == 1

    def test_handle_100th_percentile(self):
        arr = [1, 2, 3, 4, 5]
        p100 = array.percentile_linear_interpolation(arr, 100)
        assert p100 == 5

    def test_return_nan_for_empty_array(self):
        arr: list[float] = []
        result = array.percentile_linear_interpolation(arr, 50)
        assert math.isnan(result)

    def test_return_nan_if_array_contains_nan(self):
        arr = [1, 2, float("nan"), 4, 5]
        result = array.percentile_linear_interpolation(arr, 50)
        assert math.isnan(result)

    def test_work_with_negative_numbers(self):
        arr = [-5, -3, -1, 1, 3, 5]
        p50 = array.percentile_linear_interpolation(arr, 50)
        assert p50 == pytest.approx(0)

    def test_work_with_decimal_values(self):
        arr = [1.1, 2.2, 3.3, 4.4, 5.5]
        p50 = array.percentile_linear_interpolation(arr, 50)
        assert p50 == pytest.approx(3.3)

    def test_handle_single_element(self):
        arr = [42]
        p50 = array.percentile_linear_interpolation(arr, 50)
        assert p50 == 42


# ---------------------------------------------------------------------------
# array.percentile_nearest_rank
# ---------------------------------------------------------------------------

class TestPercentileNearestRank:
    def test_calculate_50th_percentile_median(self):
        arr = [1, 2, 3, 4, 5]
        p50 = array.percentile_nearest_rank(arr, 50)
        assert p50 == 3

    def test_always_return_a_member_of_the_array(self):
        arr = [1, 2, 3, 4]
        p50 = array.percentile_nearest_rank(arr, 50)
        assert p50 in [2, 3]

    def test_calculate_25th_percentile(self):
        arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        p25 = array.percentile_nearest_rank(arr, 25)
        assert p25 in [3, 4]

    def test_calculate_75th_percentile(self):
        arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        p75 = array.percentile_nearest_rank(arr, 75)
        assert p75 in [7, 8]

    def test_handle_0th_percentile(self):
        arr = [1, 2, 3, 4, 5]
        p0 = array.percentile_nearest_rank(arr, 0)
        assert p0 in arr

    def test_handle_100th_percentile_as_largest_value(self):
        arr = [1, 2, 3, 4, 5]
        p100 = array.percentile_nearest_rank(arr, 100)
        assert p100 == 5

    def test_return_nan_for_empty_array(self):
        arr: list[float] = []
        result = array.percentile_nearest_rank(arr, 50)
        assert math.isnan(result)

    def test_ignore_nan_values(self):
        arr = [1, float("nan"), 2, 3, float("nan"), 4, 5]
        result = array.percentile_nearest_rank(arr, 50)
        assert not math.isnan(result)
        assert result in [2, 3, 4]

    def test_work_with_negative_numbers(self):
        arr = [-5, -3, -1, 1, 3, 5]
        p50 = array.percentile_nearest_rank(arr, 50)
        assert p50 in [-1, 1]

    def test_work_with_decimal_values(self):
        arr = [1.1, 2.2, 3.3, 4.4, 5.5]
        p50 = array.percentile_nearest_rank(arr, 50)
        assert p50 in arr

    def test_handle_single_element(self):
        arr = [42]
        p50 = array.percentile_nearest_rank(arr, 50)
        assert p50 == 42

    def test_demonstrate_difference_from_linear_interpolation(self):
        arr = [1, 2, 3, 4]

        linear = array.percentile_linear_interpolation(arr, 50)
        nearest = array.percentile_nearest_rank(arr, 50)

        assert linear == 2.5  # Interpolated
        assert nearest in [2, 3]  # Member of array
        assert nearest != linear


# ---------------------------------------------------------------------------
# array.percentrank
# ---------------------------------------------------------------------------

class TestPercentrank:
    def test_return_percentile_rank_of_element_at_index(self):
        arr = [1, 2, 3, 4, 5]
        rank = array.percentrank(arr, 2)  # Value 3 at index 2
        # 3 values <= 3: [1, 2, 3] = 60%
        assert rank == 60

    def test_return_100_for_maximum_value(self):
        arr = [1, 2, 3, 4, 5]
        rank = array.percentrank(arr, 4)  # Value 5 at index 4
        assert rank == 100

    def test_return_20_for_minimum_value(self):
        arr = [1, 2, 3, 4, 5]
        rank = array.percentrank(arr, 0)  # Value 1 at index 0
        assert rank == 20

    def test_handle_duplicate_values(self):
        arr = [1, 2, 3, 3, 3, 4, 5]
        rank = array.percentrank(arr, 2)  # Value 3 at index 2
        # 5 values <= 3: [1, 2, 3, 3, 3] = 5/7 ~ 71.4%
        assert rank == pytest.approx(71.43, abs=0.1)

    def test_handle_all_identical_values(self):
        arr = [5, 5, 5, 5, 5]
        rank = array.percentrank(arr, 2)
        assert rank == 100  # All values <= 5

    def test_return_nan_for_empty_array(self):
        arr: list[float] = []
        rank = array.percentrank(arr, 0)
        assert math.isnan(rank)

    def test_return_nan_for_out_of_bounds_index(self):
        arr = [1, 2, 3]
        assert math.isnan(array.percentrank(arr, -1))
        assert math.isnan(array.percentrank(arr, 3))
        assert math.isnan(array.percentrank(arr, 10))

    def test_return_nan_if_value_at_index_is_nan(self):
        arr = [1, 2, float("nan"), 4, 5]
        rank = array.percentrank(arr, 2)
        assert math.isnan(rank)

    def test_ignore_nan_values_when_counting(self):
        arr = [1, float("nan"), 2, 3, float("nan"), 4, 5]
        rank = array.percentrank(arr, 3)  # Value 3 at index 3
        # Count includes NaN positions: 3/7 ~ 42.86%
        assert rank == pytest.approx(42.86, abs=0.1)

    def test_work_with_negative_numbers(self):
        arr = [-5, -3, -1, 1, 3]
        rank = array.percentrank(arr, 2)  # Value -1 at index 2
        # 3 values <= -1: [-5, -3, -1] = 60%
        assert rank == 60

    def test_work_with_decimal_values(self):
        arr = [1.1, 2.2, 3.3, 4.4, 5.5]
        rank = array.percentrank(arr, 2)  # Value 3.3
        assert rank == 60

    def test_handle_unsorted_arrays(self):
        arr = [5, 1, 3, 2, 4]
        rank = array.percentrank(arr, 2)  # Value 3 at index 2
        # 3 values <= 3: [1, 2, 3] = 60%
        assert rank == 60

    def test_demonstrate_percentrank_vs_percentile(self):
        arr = [10, 20, 30, 40, 50]

        # Percentrank: what percent of values are <= value at index 2 (30)?
        rank = array.percentrank(arr, 2)
        assert rank == 60  # 60% of values <= 30

        # Percentile: what value has 60% of values <= it?
        p60 = array.percentile_nearest_rank(arr, 60)
        assert p60 == 30  # Value at 60th percentile is 30


# ---------------------------------------------------------------------------
# Percentile functions comparison
# ---------------------------------------------------------------------------

class TestPercentileFunctionsComparison:
    def test_demonstrate_all_three_functions_on_same_data(self):
        arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

        p_linear = array.percentile_linear_interpolation(arr, 50)
        p_nearest = array.percentile_nearest_rank(arr, 50)

        assert p_linear == pytest.approx(5.5)  # Interpolated
        assert p_nearest == 5  # Nearest member

        # What percentile is the value at index 4 (value 5)?
        rank = array.percentrank(arr, 4)
        assert rank == 50  # 50% of values <= 5

    def test_handle_edge_case_with_two_elements(self):
        arr = [1, 10]

        p50_linear = array.percentile_linear_interpolation(arr, 50)
        p50_nearest = array.percentile_nearest_rank(arr, 50)

        assert p50_linear == pytest.approx(5.5)  # Midpoint
        assert p50_nearest in [1, 10]  # One of the values

        rank0 = array.percentrank(arr, 0)
        rank1 = array.percentrank(arr, 1)

        assert rank0 == 50   # 50% <= 1
        assert rank1 == 100  # 100% <= 10
