"""Tests for the box namespace — ported from box.test.ts."""

from oakscriptpy import box


# --- box.new ---

class TestBoxNew:
    def test_create_box_with_required_parameters(self):
        b = box.new(10, 105, 20, 100)

        assert b.left == 10
        assert b.top == 105
        assert b.right == 20
        assert b.bottom == 100
        assert b.xloc == "bar_index"
        assert b.extend == "none"
        assert b.border_width == 1
        assert b.border_style == "solid"

    def test_create_box_with_custom_xloc_and_extend(self):
        b = box.new(10, 105, 20, 100, "bar_index", "right")

        assert b.xloc == "bar_index"
        assert b.extend == "right"

    def test_create_box_with_border_styling(self):
        b = box.new(10, 105, 20, 100, "bar_index", "none", "#FF0000", 2, "dashed")

        assert b.border_color == "#FF0000"
        assert b.border_width == 2
        assert b.border_style == "dashed"

    def test_create_box_with_background_color(self):
        b = box.new(10, 105, 20, 100, bgcolor="#00FF00")

        assert b.bgcolor == "#00FF00"

    def test_create_box_with_text_content(self):
        b = box.new(
            10, 105, 20, 100,
            text="Gap", text_size="auto", text_color="#000000",
            text_halign="center", text_valign="center",
        )

        assert b.text == "Gap"
        assert b.text_size == "auto"
        assert b.text_color == "#000000"
        assert b.text_halign == "center"
        assert b.text_valign == "center"


# --- box.get_left ---

class TestBoxGetLeft:
    def test_return_left_border_coordinate(self):
        b = box.new(10, 105, 20, 100)
        assert box.get_left(b) == 10

    def test_work_with_negative_bar_indices(self):
        b = box.new(-5, 105, 20, 100)
        assert box.get_left(b) == -5


# --- box.get_right ---

class TestBoxGetRight:
    def test_return_right_border_coordinate(self):
        b = box.new(10, 105, 20, 100)
        assert box.get_right(b) == 20


# --- box.get_top ---

class TestBoxGetTop:
    def test_return_top_border_price(self):
        b = box.new(10, 105, 20, 100)
        assert box.get_top(b) == 105

    def test_work_with_decimal_prices(self):
        b = box.new(10, 105.75, 20, 100.25)
        assert box.get_top(b) == 105.75


# --- box.get_bottom ---

class TestBoxGetBottom:
    def test_return_bottom_border_price(self):
        b = box.new(10, 105, 20, 100)
        assert box.get_bottom(b) == 100


# --- Box computational use cases ---

class TestGapDetectionAndTracking:
    def test_detect_when_price_enters_gap_from_above(self):
        gap = box.new(10, 105, 20, 100)

        high = 104
        low = 101

        entered_gap = high < box.get_top(gap) and low > box.get_bottom(gap)
        assert entered_gap is True

    def test_detect_when_gap_is_completely_filled(self):
        gap = box.new(10, 105, 20, 100)

        high = 106

        gap_filled = high > box.get_top(gap)
        assert gap_filled is True

    def test_detect_partial_gap_fill(self):
        gap = box.new(10, 155, 20, 150)

        low = 152
        high = 158

        partially_filled = low < box.get_top(gap) and high > box.get_bottom(gap)
        assert partially_filled is True

    def test_calculate_gap_duration(self):
        gap = box.new(10, 105, 20, 100)
        current_bar = 50

        duration = current_bar - box.get_left(gap)
        assert duration == 40

        max_duration = 30
        assert duration > max_duration

    def test_calculate_gap_width(self):
        gap = box.new(10, 105, 20, 100)

        gap_width = box.get_top(gap) - box.get_bottom(gap)
        assert gap_width == 5

    def test_gap_tracking_logic(self):
        gaps = []

        gap = box.new(10, 105, 20, 100)
        gaps.append({"box": gap, "is_active": True, "is_bull": False})

        high = 106
        # low = 99  # not used for bearish gap close logic

        if gaps[0]["is_active"]:
            active_box = gaps[0]["box"]
            top = box.get_top(active_box)

            if high > top and not gaps[0]["is_bull"]:
                gaps[0]["is_active"] = False
                assert gaps[0]["is_active"] is False


class TestRangeBreakoutDetection:
    def test_detect_breakout_above_range(self):
        range_box = box.new(100, 155, 150, 145)

        close = 157

        breakout_above = close > box.get_top(range_box)
        assert breakout_above is True

    def test_detect_breakout_below_range(self):
        range_box = box.new(100, 155, 150, 145)

        close = 143

        breakout_below = close < box.get_bottom(range_box)
        assert breakout_below is True

    def test_detect_price_inside_range(self):
        range_box = box.new(100, 155, 150, 145)

        close = 150

        inside_range = close >= box.get_bottom(range_box) and close <= box.get_top(range_box)
        assert inside_range is True

    def test_calculate_range_width(self):
        range_box = box.new(100, 155, 150, 145)

        range_width = box.get_top(range_box) - box.get_bottom(range_box)
        assert range_width == 10

        min_width = 5
        assert range_width > min_width

    def test_calculate_range_duration(self):
        range_box = box.new(100, 155, 150, 145)

        range_duration = box.get_right(range_box) - box.get_left(range_box)
        assert range_duration == 50


class TestRectanglePatternRecognition:
    def test_identify_valid_rectangle_pattern(self):
        rectangle = box.new(50, 110, 100, 100)

        height = box.get_top(rectangle) - box.get_bottom(rectangle)
        width = box.get_right(rectangle) - box.get_left(rectangle)

        is_valid_rectangle = width > 20 and height > 5 and height < 20
        assert is_valid_rectangle is True

    def test_validate_box_boundaries(self):
        b = box.new(10, 105, 20, 100)

        assert box.get_top(b) > box.get_bottom(b)
        assert box.get_right(b) > box.get_left(b)


class TestDynamicSupportResistance:
    def test_use_box_top_as_resistance_level(self):
        resistance_box = box.new(0, 155, 100, 150)
        resistance = box.get_top(resistance_box)

        current_price = 154
        distance_to_resistance = resistance - current_price

        assert distance_to_resistance == 1
        assert current_price < resistance

    def test_use_box_bottom_as_support_level(self):
        support_box = box.new(0, 105, 100, 100)
        support = box.get_bottom(support_box)

        current_price = 102
        distance_to_support = current_price - support

        assert distance_to_support == 2
        assert current_price > support


# --- box.copy ---

class TestBoxCopy:
    def test_create_independent_copy(self):
        original = box.new(10, 105, 20, 100, "bar_index", "none", "#FF0000")
        copied = box.copy(original)

        assert copied.left == original.left
        assert copied.top == original.top
        assert copied.right == original.right
        assert copied.bottom == original.bottom
        assert copied.border_color == original.border_color

    def test_not_modify_original_when_copy_is_changed(self):
        original = box.new(10, 105, 20, 100)
        copied = box.copy(original)

        copied.top = 110

        assert original.top == 105
        assert copied.top == 110


# --- box.delete ---

class TestBoxDelete:
    def test_exists_for_api_compatibility(self):
        b = box.new(10, 105, 20, 100)

        # Should not raise
        box.delete(b)


# --- Edge cases ---

class TestBoxEdgeCases:
    def test_handle_inverted_box(self):
        b = box.new(10, 100, 20, 105)

        assert box.get_top(b) == 100
        assert box.get_bottom(b) == 105

    def test_handle_zero_height_box(self):
        b = box.new(10, 100, 20, 100)

        assert box.get_top(b) == box.get_bottom(b)

    def test_handle_zero_width_box(self):
        b = box.new(15, 105, 15, 100)

        assert box.get_left(b) == box.get_right(b)

    def test_handle_negative_prices(self):
        b = box.new(10, -50, 20, -60)

        assert box.get_top(b) == -50
        assert box.get_bottom(b) == -60
