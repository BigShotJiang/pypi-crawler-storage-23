"""Tests for the label namespace — ported from label.test.ts."""

from oakscriptpy import label


# --- label.new ---

class TestLabelNew:
    def test_create_label_with_required_parameters(self):
        lbl = label.new(50, 155.5)

        assert lbl.x == 50
        assert lbl.y == 155.5
        assert lbl.xloc == "bar_index"
        assert lbl.yloc == "price"
        assert lbl.text is None

    def test_create_label_with_text(self):
        lbl = label.new(50, 155.5, "Pivot High")

        assert lbl.text == "Pivot High"

    def test_create_label_with_all_parameters(self):
        lbl = label.new(
            50, 155.5, "Pivot",
            "bar_index", "price",
            "#FF0000", "label_down",
            "#FFFFFF", "large", "center",
            "Resistance level", "monospace",
        )

        assert lbl.x == 50
        assert lbl.y == 155.5
        assert lbl.text == "Pivot"
        assert lbl.color == "#FF0000"
        assert lbl.style == "label_down"
        assert lbl.textcolor == "#FFFFFF"
        assert lbl.size == "large"
        assert lbl.textalign == "center"
        assert lbl.tooltip == "Resistance level"
        assert lbl.text_font_family == "monospace"

    def test_support_different_yloc_modes(self):
        price_label = label.new(50, 155.5, "Price", "bar_index", "price")
        above_label = label.new(50, 0, "Above", "bar_index", "abovebar")
        below_label = label.new(50, 0, "Below", "bar_index", "belowbar")

        assert price_label.yloc == "price"
        assert above_label.yloc == "abovebar"
        assert below_label.yloc == "belowbar"

    def test_support_different_label_styles(self):
        styles = [
            "label_up", "label_down", "arrowup", "arrowdown",
            "circle", "square", "diamond", "triangleup", "triangledown",
        ]

        for style in styles:
            lbl = label.new(50, 155.5, "Test", "bar_index", "price", None, style)
            assert lbl.style == style

    def test_support_bar_time_xloc(self):
        lbl = label.new(1609459200000, 155.5, "Pivot", "bar_time")

        assert lbl.xloc == "bar_time"
        assert lbl.x == 1609459200000


# --- label.get_x ---

class TestLabelGetX:
    def test_return_x_coordinate(self):
        lbl = label.new(50, 155.5)
        assert label.get_x(lbl) == 50

    def test_work_with_timestamp(self):
        lbl = label.new(1609459200000, 155.5, "Test", "bar_time")
        assert label.get_x(lbl) == 1609459200000


# --- label.get_y ---

class TestLabelGetY:
    def test_return_y_coordinate(self):
        lbl = label.new(50, 155.5)
        assert label.get_y(lbl) == 155.5

    def test_work_with_decimal_prices(self):
        lbl = label.new(50, 123.456)
        assert label.get_y(lbl) == 123.456


# --- label.get_text ---

class TestLabelGetText:
    def test_return_text_content(self):
        lbl = label.new(50, 155.5, "Pivot High")
        assert label.get_text(lbl) == "Pivot High"

    def test_return_none_if_no_text(self):
        lbl = label.new(50, 155.5)
        assert label.get_text(lbl) is None


# --- label.copy ---

class TestLabelCopy:
    def test_create_independent_copy(self):
        original = label.new(50, 155.5, "Pivot", "bar_index", "price", "#FF0000")
        copied = label.copy(original)

        assert copied.x == original.x
        assert copied.y == original.y
        assert copied.text == original.text
        assert copied.color == original.color

    def test_not_modify_original_when_copy_is_changed(self):
        original = label.new(50, 155.5, "Pivot")
        copied = label.copy(original)

        copied.text = "Modified"
        copied.x = 60

        assert original.text == "Pivot"
        assert original.x == 50
        assert copied.text == "Modified"
        assert copied.x == 60


# --- Position setters ---

class TestLabelPositionSetters:
    def test_set_x_coordinate(self):
        lbl = label.new(50, 155.5)
        label.set_x(lbl, 60)

        assert lbl.x == 60

    def test_set_y_coordinate(self):
        lbl = label.new(50, 155.5)
        label.set_y(lbl, 160)

        assert lbl.y == 160

    def test_set_both_x_and_y_coordinates(self):
        lbl = label.new(50, 155.5)
        label.set_xy(lbl, 60, 160)

        assert lbl.x == 60
        assert lbl.y == 160

    def test_set_xloc_and_x_coordinate(self):
        lbl = label.new(50, 155.5)
        label.set_xloc(lbl, 1609459200000, "bar_time")

        assert lbl.x == 1609459200000
        assert lbl.xloc == "bar_time"

    def test_set_yloc_and_y_coordinate(self):
        lbl = label.new(50, 155.5)
        label.set_yloc(lbl, 0, "abovebar")

        assert lbl.y == 0
        assert lbl.yloc == "abovebar"


# --- Content setters ---

class TestLabelContentSetters:
    def test_set_text(self):
        lbl = label.new(50, 155.5)
        label.set_text(lbl, "Updated Text")

        assert lbl.text == "Updated Text"

    def test_set_tooltip(self):
        lbl = label.new(50, 155.5)
        label.set_tooltip(lbl, "Resistance level")

        assert lbl.tooltip == "Resistance level"


# --- Styling setters ---

class TestLabelStylingSetters:
    def test_set_color(self):
        lbl = label.new(50, 155.5)
        label.set_color(lbl, "#FF0000")

        assert lbl.color == "#FF0000"

    def test_set_text_color(self):
        lbl = label.new(50, 155.5)
        label.set_textcolor(lbl, "#FFFFFF")

        assert lbl.textcolor == "#FFFFFF"

    def test_set_style(self):
        lbl = label.new(50, 155.5)
        label.set_style(lbl, "label_down")

        assert lbl.style == "label_down"

    def test_set_size(self):
        lbl = label.new(50, 155.5)
        label.set_size(lbl, "large")

        assert lbl.size == "large"

    def test_set_text_align(self):
        lbl = label.new(50, 155.5)
        label.set_textalign(lbl, "center")

        assert lbl.textalign == "center"

    def test_set_text_font_family(self):
        lbl = label.new(50, 155.5)
        label.set_text_font_family(lbl, "monospace")

        assert lbl.text_font_family == "monospace"


# --- Method chaining ---

class TestLabelMethodChaining:
    def test_allow_chaining_setters(self):
        lbl = label.new(50, 155.5)

        label.set_text(lbl, "Pivot")
        label.set_color(lbl, "#FF0000")
        label.set_textcolor(lbl, "#FFFFFF")
        label.set_size(lbl, "large")

        assert lbl.text == "Pivot"
        assert lbl.color == "#FF0000"
        assert lbl.textcolor == "#FFFFFF"
        assert lbl.size == "large"


# --- Real-world use cases ---

class TestLabelRealWorld:
    def test_mark_pivot_points(self):
        pivot_high = label.new(50, 155.5, "H", "bar_index", "abovebar", "#FF0000", "label_down")

        assert label.get_x(pivot_high) == 50
        assert label.get_y(pivot_high) == 155.5
        assert label.get_text(pivot_high) == "H"
        assert pivot_high.yloc == "abovebar"

    def test_annotate_breakouts(self):
        breakout = label.new(100, 160, "Breakout!", "bar_index", "price", "#00FF00", "arrowup")

        assert breakout.text == "Breakout!"
        assert breakout.style == "arrowup"
        assert breakout.color == "#00FF00"

    def test_display_price_levels(self):
        support = label.new(0, 100, "100 Support", "bar_index", "price")
        label.set_tooltip(support, "Strong support level established")

        assert label.get_text(support) == "100 Support"
        assert support.tooltip == "Strong support level established"

    def test_update_dynamically(self):
        dynamic_label = label.new(50, 155.5, "Forming...")

        label.set_text(dynamic_label, "Confirmed!")
        label.set_color(dynamic_label, "#00FF00")
        label.set_style(dynamic_label, "circle")

        assert dynamic_label.text == "Confirmed!"
        assert dynamic_label.color == "#00FF00"
        assert dynamic_label.style == "circle"


# --- label.delete ---

class TestLabelDelete:
    def test_exists_for_api_compatibility(self):
        lbl = label.new(50, 155.5)

        # Should not raise
        label.delete(lbl)


# --- Edge cases ---

class TestLabelEdgeCases:
    def test_handle_negative_coordinates(self):
        lbl = label.new(-10, -50.5, "Negative")

        assert lbl.x == -10
        assert lbl.y == -50.5

    def test_handle_zero_coordinates(self):
        lbl = label.new(0, 0)

        assert lbl.x == 0
        assert lbl.y == 0

    def test_handle_empty_text(self):
        lbl = label.new(50, 155.5, "")

        assert lbl.text == ""

    def test_handle_very_large_coordinates(self):
        lbl = label.new(1000000, 999999.99)

        assert lbl.x == 1000000
        assert lbl.y == 999999.99
