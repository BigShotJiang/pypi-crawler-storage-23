"""Tests for the chartpoint namespace — ported from chartpoint.test.ts."""

from oakscriptpy import chartpoint


# --- chartpoint.new ---

class TestChartPointNew:
    def test_create_point_with_all_coordinates(self):
        point = chartpoint.new(1609459200000, 100, 150.5)

        assert point.time == 1609459200000
        assert point.index == 100
        assert point.price == 150.5

    def test_create_point_with_only_index(self):
        point = chartpoint.new(None, 50, 200)

        assert point.time is None
        assert point.index == 50
        assert point.price == 200

    def test_create_point_with_only_time(self):
        point = chartpoint.new(1609459200000, None, 175)

        assert point.time == 1609459200000
        assert point.index is None
        assert point.price == 175

    def test_create_point_with_both_null(self):
        point = chartpoint.new(None, None, 100)

        assert point.time is None
        assert point.index is None
        assert point.price == 100

    def test_handle_negative_price_values(self):
        point = chartpoint.new(None, 10, -50.25)

        assert point.price == -50.25

    def test_handle_zero_values(self):
        point = chartpoint.new(0, 0, 0)

        assert point.time == 0
        assert point.index == 0
        assert point.price == 0


# --- chartpoint.from_time ---

class TestChartPointFromTime:
    def test_create_point_from_time_and_price(self):
        point = chartpoint.from_time(1609459200000, 150.5)

        assert point.time == 1609459200000
        assert point.index is None
        assert point.price == 150.5

    def test_handle_various_timestamps(self):
        point1 = chartpoint.from_time(0, 100)
        point2 = chartpoint.from_time(1700000000000, 200)

        assert point1.time == 0
        assert point2.time == 1700000000000


# --- chartpoint.from_index ---

class TestChartPointFromIndex:
    def test_create_point_from_index_and_price(self):
        point = chartpoint.from_index(50, 150.5)

        assert point.time is None
        assert point.index == 50
        assert point.price == 150.5

    def test_handle_negative_bar_indices(self):
        point = chartpoint.from_index(-10, 100)

        assert point.index == -10

    def test_handle_zero_index(self):
        point = chartpoint.from_index(0, 100)

        assert point.index == 0


# --- chartpoint.copy ---

class TestChartPointCopy:
    def test_create_independent_copy(self):
        original = chartpoint.from_index(10, 100)
        copied = chartpoint.copy(original)

        assert copied.time == original.time
        assert copied.index == original.index
        assert copied.price == original.price

    def test_copy_point_with_all_coordinates(self):
        original = chartpoint.new(1609459200000, 50, 150)
        copied = chartpoint.copy(original)

        assert copied.time == 1609459200000
        assert copied.index == 50
        assert copied.price == 150

    def test_create_separate_object(self):
        original = chartpoint.from_index(10, 100)
        copied = chartpoint.copy(original)

        assert copied is not original


# --- ChartPoint immutability ---

class TestChartPointImmutability:
    def test_has_expected_properties(self):
        point = chartpoint.from_index(10, 100)

        assert point.time is None
        assert point.index == 10
        assert point.price == 100


# --- Real-world use cases ---

class TestChartPointRealWorld:
    def test_create_points_for_trend_line(self):
        points = [
            chartpoint.from_index(0, 100),
            chartpoint.from_index(10, 120),
            chartpoint.from_index(20, 110),
            chartpoint.from_index(30, 130),
        ]

        assert len(points) == 4
        assert points[0].index == 0
        assert points[0].price == 100
        assert points[3].index == 30
        assert points[3].price == 130

    def test_create_points_using_timestamps(self):
        base_time = 1609459200000  # 2021-01-01
        hour_ms = 3600000

        points = [
            chartpoint.from_time(base_time, 100),
            chartpoint.from_time(base_time + hour_ms, 105),
            chartpoint.from_time(base_time + 2 * hour_ms, 110),
        ]

        assert len(points) == 3
        assert points[0].time == base_time
        assert points[1].time == base_time + hour_ms
        assert points[2].time == base_time + 2 * hour_ms
