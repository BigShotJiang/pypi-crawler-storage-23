"""Tests for the line namespace — ported from line.test.ts."""

import math

import pytest

from oakscriptpy import line


# --- line.new ---

class TestLineNew:
    def test_create_line_with_required_parameters(self):
        l = line.new(0, 100, 50, 150)

        assert l.x1 == 0
        assert l.y1 == 100
        assert l.x2 == 50
        assert l.y2 == 150
        assert l.xloc == "bar_index"
        assert l.extend == "none"
        assert l.style == "solid"
        assert l.width == 1

    def test_create_line_with_custom_xloc_and_extend(self):
        l = line.new(0, 100, 50, 150, "bar_index", "right")

        assert l.xloc == "bar_index"
        assert l.extend == "right"

    def test_create_line_with_styling_options(self):
        l = line.new(0, 100, 50, 150, "bar_index", "none", "#FF0000", "dashed", 2)

        assert l.color == "#FF0000"
        assert l.style == "dashed"
        assert l.width == 2

    def test_handle_bar_time_xloc(self):
        l = line.new(1609459200000, 100, 1609545600000, 150, "bar_time")

        assert l.xloc == "bar_time"


# --- line.get_price — Basic interpolation ---

class TestLineGetPriceBasic:
    def test_calculate_price_at_midpoint(self):
        l = line.new(0, 100, 50, 150)
        price = line.get_price(l, 25)

        assert price == pytest.approx(125)

    def test_calculate_price_at_any_point_in_segment(self):
        l = line.new(0, 100, 50, 150)

        assert line.get_price(l, 0) == pytest.approx(100)
        assert line.get_price(l, 10) == pytest.approx(110)
        assert line.get_price(l, 25) == pytest.approx(125)
        assert line.get_price(l, 40) == pytest.approx(140)
        assert line.get_price(l, 50) == pytest.approx(150)

    def test_handle_negative_slope(self):
        l = line.new(0, 150, 50, 100)

        assert line.get_price(l, 0) == pytest.approx(150)
        assert line.get_price(l, 25) == pytest.approx(125)
        assert line.get_price(l, 50) == pytest.approx(100)

    def test_handle_horizontal_line(self):
        l = line.new(0, 100, 50, 100)

        assert line.get_price(l, 0) == pytest.approx(100)
        assert line.get_price(l, 25) == pytest.approx(100)
        assert line.get_price(l, 50) == pytest.approx(100)

    def test_return_nan_for_vertical_line(self):
        l = line.new(25, 100, 25, 150)

        assert math.isnan(line.get_price(l, 25))


# --- line.get_price — Extension modes ---

class TestLineGetPriceExtension:
    def test_return_nan_outside_bounds_when_extend_none(self):
        l = line.new(10, 100, 50, 150, "bar_index", "none")

        # Within bounds
        assert line.get_price(l, 30) == pytest.approx(125)

        # Outside bounds
        assert math.isnan(line.get_price(l, 5))
        assert math.isnan(line.get_price(l, 60))

    def test_extend_to_left(self):
        l = line.new(10, 100, 50, 150, "bar_index", "left")

        # Left extension
        assert line.get_price(l, 0) == pytest.approx(87.5)
        assert line.get_price(l, 5) == pytest.approx(93.75)

        # Within bounds
        assert line.get_price(l, 30) == pytest.approx(125)

        # Right side not extended
        assert math.isnan(line.get_price(l, 60))

    def test_extend_to_right(self):
        l = line.new(10, 100, 50, 150, "bar_index", "right")

        # Left side not extended
        assert math.isnan(line.get_price(l, 5))

        # Within bounds
        assert line.get_price(l, 30) == pytest.approx(125)

        # Right extension
        assert line.get_price(l, 60) == pytest.approx(162.5)
        assert line.get_price(l, 100) == pytest.approx(212.5)

    def test_extend_both_directions(self):
        l = line.new(10, 100, 50, 150, "bar_index", "both")

        # Left extension
        assert line.get_price(l, 0) == pytest.approx(87.5)

        # Within bounds
        assert line.get_price(l, 30) == pytest.approx(125)

        # Right extension
        assert line.get_price(l, 100) == pytest.approx(212.5)


# --- line.get_price — Real-world use cases ---

class TestLineGetPriceRealWorld:
    def test_detect_trend_line_breakout(self):
        trend_line = line.new(0, 100, 50, 150, "bar_index", "right")

        expected_price = line.get_price(trend_line, 75)
        assert expected_price == pytest.approx(175)

        current_price = 180
        assert current_price > expected_price

    def test_calculate_support_resistance_levels(self):
        support = line.new(0, 100, 100, 100, "bar_index", "both")

        assert line.get_price(support, 50) == 100
        assert line.get_price(support, 100) == 100
        assert line.get_price(support, 150) == 100

    def test_work_with_decimal_prices_and_bars(self):
        l = line.new(0, 100.5, 50, 150.75)

        assert line.get_price(l, 25) == pytest.approx(125.625)

    def test_handle_very_steep_slopes(self):
        l = line.new(0, 100, 10, 1000)

        assert line.get_price(l, 5) == pytest.approx(550)
        assert line.get_price(l, 10) == pytest.approx(1000)


# --- line.get_price — Edge cases ---

class TestLineGetPriceEdgeCases:
    def test_handle_negative_bar_indices(self):
        l = line.new(-10, 100, 10, 120, "bar_index", "both")

        assert line.get_price(l, -10) == pytest.approx(100)
        assert line.get_price(l, 0) == pytest.approx(110)
        assert line.get_price(l, 10) == pytest.approx(120)

    def test_handle_negative_prices(self):
        l = line.new(0, -100, 50, -50)

        assert line.get_price(l, 25) == pytest.approx(-75)

    def test_handle_reversed_x_coordinates(self):
        l = line.new(50, 150, 0, 100)

        assert line.get_price(l, 25) == pytest.approx(125)

    def test_raise_error_for_bar_time_xloc(self):
        l = line.new(1609459200000, 100, 1609545600000, 150, "bar_time")

        with pytest.raises(ValueError, match="line.get_price\\(\\) only works with xloc.bar_index lines"):
            line.get_price(l, 1609502400000)


# --- line.get_x1/x2/y1/y2 ---

class TestLineGetCoordinates:
    def test_return_correct_coordinates(self):
        l = line.new(10, 100, 50, 150)

        assert line.get_x1(l) == 10
        assert line.get_y1(l) == 100
        assert line.get_x2(l) == 50
        assert line.get_y2(l) == 150

    def test_calculate_line_slope(self):
        l = line.new(0, 100, 50, 150)

        dx = line.get_x2(l) - line.get_x1(l)
        dy = line.get_y2(l) - line.get_y1(l)
        slope = dy / dx

        assert slope == pytest.approx(1.0)

    def test_calculate_line_offset(self):
        line1 = line.new(0, 100, 50, 150)
        line2 = line.new(10, 120, 60, 170)

        offset = line.get_y1(line1) - line.get_y2(line2)
        assert offset == -70


# --- line.copy ---

class TestLineCopy:
    def test_create_independent_copy(self):
        original = line.new(0, 100, 50, 150, "bar_index", "right", "#FF0000")
        copied = line.copy(original)

        assert copied.x1 == original.x1
        assert copied.y1 == original.y1
        assert copied.x2 == original.x2
        assert copied.y2 == original.y2
        assert copied.extend == original.extend
        assert copied.color == original.color

    def test_not_modify_original_when_copy_is_changed(self):
        original = line.new(0, 100, 50, 150)
        copied = line.copy(original)

        copied.y2 = 200

        assert original.y2 == 150
        assert copied.y2 == 200


# --- line.delete ---

class TestLineDelete:
    def test_exists_for_api_compatibility(self):
        l = line.new(0, 100, 50, 150)

        # Should not raise
        line.delete(l)
