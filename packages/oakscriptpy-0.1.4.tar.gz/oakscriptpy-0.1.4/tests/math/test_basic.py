"""Tests for basic math functions: abs, ceil, floor, round, max, min, avg, sum."""

import math as pymath

import pytest

from oakscriptpy import math_ as math


# --- math.abs ---

class TestAbs:
    def test_positive_numbers(self):
        assert math.abs(5) == 5
        assert math.abs(100) == 100
        assert math.abs(0.5) == 0.5

    def test_negative_numbers(self):
        assert math.abs(-5) == 5
        assert math.abs(-100) == 100
        assert math.abs(-0.5) == 0.5

    def test_zero(self):
        assert math.abs(0) == 0
        assert math.abs(-0) == 0

    def test_very_large_numbers(self):
        assert math.abs(-1000000) == 1000000
        assert math.abs(1000000) == 1000000


# --- math.ceil ---

class TestCeil:
    def test_positive_decimals(self):
        assert math.ceil(4.2) == 5
        assert math.ceil(4.8) == 5
        assert math.ceil(0.1) == 1

    def test_negative_decimals_towards_zero(self):
        assert math.ceil(-4.2) == -4
        assert math.ceil(-4.8) == -4
        assert math.ceil(-0.1) == 0

    def test_integers_unchanged(self):
        assert math.ceil(5) == 5
        assert math.ceil(-5) == -5
        assert math.ceil(0) == 0

    def test_edge_cases(self):
        assert math.ceil(4.999999) == 5
        assert math.ceil(5.000001) == 6


# --- math.floor ---

class TestFloor:
    def test_positive_decimals(self):
        assert math.floor(4.2) == 4
        assert math.floor(4.8) == 4
        assert math.floor(0.9) == 0

    def test_negative_decimals_away_from_zero(self):
        assert math.floor(-4.2) == -5
        assert math.floor(-4.8) == -5
        assert math.floor(-0.1) == -1

    def test_integers_unchanged(self):
        assert math.floor(5) == 5
        assert math.floor(-5) == -5
        assert math.floor(0) == 0

    def test_edge_cases(self):
        assert math.floor(4.000001) == 4
        assert math.floor(4.999999) == 4


# --- math.round ---

class TestRound:
    def test_nearest_integer_by_default(self):
        assert math.round(4.2) == 4
        assert math.round(4.5) == 4  # Python uses banker's rounding
        assert math.round(4.8) == 5

    def test_negative_numbers(self):
        assert math.round(-4.2) == -4
        assert math.round(-4.5) == -4  # Python banker's rounding
        assert math.round(-4.8) == -5

    def test_specified_precision(self):
        assert math.round(4.567, 2) == pytest.approx(4.57)
        assert math.round(4.567, 1) == pytest.approx(4.6)
        assert math.round(4.567, 0) == 5

    def test_zero_precision(self):
        assert math.round(4.5, 0) == 4  # Python banker's rounding: 4.5 -> 4
        assert math.round(3.14159, 0) == 3

    def test_more_precision(self):
        assert math.round(123.456, 2) == pytest.approx(123.46)
        # 0.005 in float is slightly less than 0.005 due to IEEE 754, so rounds to 0.0
        assert math.round(0.005, 2) == pytest.approx(0.0)


# --- math.max ---

class TestMax:
    def test_two_numbers(self):
        assert math.max(1, 2) == 2
        assert math.max(5, 3) == 5
        assert math.max(-1, -5) == -1

    def test_multiple_numbers(self):
        assert math.max(1, 2, 3) == 3
        assert math.max(5, 10, 3, 8) == 10
        assert math.max(-1, -5, -2, -10) == -1

    def test_single_argument(self):
        assert math.max(10) == 10
        assert math.max(-5) == -5

    def test_mixed_positive_and_negative(self):
        assert math.max(-5, 0, 5) == 5
        assert math.max(-10, -20, -5) == -5

    def test_decimal_numbers(self):
        assert math.max(1.5, 2.3, 1.9) == 2.3
        assert math.max(0.1, 0.2, 0.15) == 0.2


# --- math.min ---

class TestMin:
    def test_two_numbers(self):
        assert math.min(1, 2) == 1
        assert math.min(5, 3) == 3
        assert math.min(-1, -5) == -5

    def test_multiple_numbers(self):
        assert math.min(1, 2, 3) == 1
        assert math.min(5, 10, 3, 8) == 3
        assert math.min(-1, -5, -2, -10) == -10

    def test_single_argument(self):
        assert math.min(10) == 10
        assert math.min(-5) == -5

    def test_mixed_positive_and_negative(self):
        assert math.min(-5, 0, 5) == -5
        assert math.min(10, 20, 5) == 5

    def test_decimal_numbers(self):
        assert math.min(1.5, 2.3, 1.9) == 1.5
        assert math.min(0.1, 0.2, 0.15) == 0.1


# --- math.avg ---

class TestAvg:
    def test_two_numbers(self):
        assert math.avg(1, 2) == 1.5
        assert math.avg(10, 20) == 15

    def test_multiple_numbers(self):
        assert math.avg(1, 2, 3) == 2
        assert math.avg(1, 2, 3, 4, 5) == 3
        assert math.avg(10, 20, 30) == 20

    def test_single_number(self):
        assert math.avg(5) == 5
        assert math.avg(100) == 100

    def test_negative_numbers(self):
        assert math.avg(-1, -2, -3) == -2
        assert math.avg(-5, 5) == 0

    def test_decimal_results(self):
        assert math.avg(1, 2) == 1.5
        assert math.avg(1, 2, 3, 4) == 2.5


# --- math.sum ---

class TestSum:
    def test_rolling_sum_over_window(self):
        result = math.sum([1, 2, 3, 4, 5], 3)
        assert pymath.isnan(result[0])
        assert pymath.isnan(result[1])
        assert result[2] == 6   # 1+2+3
        assert result[3] == 9   # 2+3+4
        assert result[4] == 12  # 3+4+5

    def test_window_size_of_1(self):
        result = math.sum([1, 2, 3], 1)
        assert result[0] == 1
        assert result[1] == 2
        assert result[2] == 3

    def test_window_size_equal_to_array_length(self):
        result = math.sum([1, 2, 3, 4], 4)
        assert pymath.isnan(result[0])
        assert pymath.isnan(result[1])
        assert pymath.isnan(result[2])
        assert result[3] == 10  # 1+2+3+4

    def test_window_size_of_2(self):
        result = math.sum([5, 10, 15, 20], 2)
        assert pymath.isnan(result[0])
        assert result[1] == 15  # 5+10
        assert result[2] == 25  # 10+15
        assert result[3] == 35  # 15+20

    def test_negative_numbers(self):
        result = math.sum([-1, -2, -3], 2)
        assert pymath.isnan(result[0])
        assert result[1] == -3  # -1+-2
        assert result[2] == -5  # -2+-3

    def test_decimal_numbers(self):
        result = math.sum([1.5, 2.5, 3.5], 2)
        assert pymath.isnan(result[0])
        assert result[1] == 4
        assert result[2] == 6
