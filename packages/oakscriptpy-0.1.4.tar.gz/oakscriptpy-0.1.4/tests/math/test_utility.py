"""Tests for utility math functions: toradians, todegrees, random, sign."""

import math as pymath

import pytest

from oakscriptpy import math_ as math


# --- math.toradians ---

class TestToradians:
    def test_common_degree_values(self):
        assert math.toradians(0) == 0
        assert math.toradians(90) == pytest.approx(pymath.pi / 2)
        assert math.toradians(180) == pytest.approx(pymath.pi)
        assert math.toradians(360) == pytest.approx(2 * pymath.pi)

    def test_special_degree_values(self):
        assert math.toradians(45) == pytest.approx(pymath.pi / 4)
        assert math.toradians(30) == pytest.approx(pymath.pi / 6)
        assert math.toradians(60) == pytest.approx(pymath.pi / 3)

    def test_negative_degrees(self):
        assert math.toradians(-90) == pytest.approx(-pymath.pi / 2)
        assert math.toradians(-180) == pytest.approx(-pymath.pi)

    def test_decimal_degrees(self):
        assert math.toradians(22.5) == pytest.approx(pymath.pi / 8)
        assert math.toradians(135) == pytest.approx(3 * pymath.pi / 4)

    def test_round_trip_with_todegrees(self):
        degrees = 72
        assert math.todegrees(math.toradians(degrees)) == pytest.approx(degrees)

    def test_large_degree_values(self):
        assert math.toradians(720) == pytest.approx(4 * pymath.pi)
        assert math.toradians(1080) == pytest.approx(6 * pymath.pi)


# --- math.todegrees ---

class TestTodegrees:
    def test_common_radian_values(self):
        assert math.todegrees(0) == 0
        assert math.todegrees(pymath.pi / 2) == pytest.approx(90)
        assert math.todegrees(pymath.pi) == pytest.approx(180)
        assert math.todegrees(2 * pymath.pi) == pytest.approx(360)

    def test_special_radian_values(self):
        assert math.todegrees(pymath.pi / 4) == pytest.approx(45)
        assert math.todegrees(pymath.pi / 6) == pytest.approx(30)
        assert math.todegrees(pymath.pi / 3) == pytest.approx(60)

    def test_negative_radians(self):
        assert math.todegrees(-pymath.pi / 2) == pytest.approx(-90)
        assert math.todegrees(-pymath.pi) == pytest.approx(-180)

    def test_decimal_radians(self):
        assert math.todegrees(1) == pytest.approx(57.29577, abs=1e-4)
        assert math.todegrees(2) == pytest.approx(114.59155, abs=1e-4)

    def test_round_trip_with_toradians(self):
        radians = 1.5
        assert math.toradians(math.todegrees(radians)) == pytest.approx(radians)

    def test_large_radian_values(self):
        assert math.todegrees(4 * pymath.pi) == pytest.approx(720)
        assert math.todegrees(6 * pymath.pi) == pytest.approx(1080)


# --- math.random ---

class TestRandom:
    def test_no_arguments_between_0_and_1(self):
        for _ in range(10):
            result = math.random()
            assert 0 <= result < 1

    def test_specified_range(self):
        for _ in range(10):
            result = math.random(0, 10)
            assert 0 <= result < 10

    def test_negative_ranges(self):
        for _ in range(10):
            result = math.random(-10, -5)
            assert -10 <= result < -5

    def test_mixed_positive_negative_ranges(self):
        for _ in range(10):
            result = math.random(-5, 5)
            assert -5 <= result < 5

    def test_decimal_ranges(self):
        for _ in range(10):
            result = math.random(1.5, 2.5)
            assert 1.5 <= result < 2.5

    def test_produces_different_values(self):
        results = set()
        for _ in range(100):
            results.add(math.random())
        # Should have many unique values
        assert len(results) > 90

    def test_zero_width_range(self):
        result = math.random(5, 5)
        assert result == 5


# --- math.sign ---

class TestSign:
    def test_positive_numbers(self):
        assert math.sign(5) == 1
        assert math.sign(100) == 1
        assert math.sign(0.1) == 1
        assert math.sign(0.001) == 1

    def test_negative_numbers(self):
        assert math.sign(-5) == -1
        assert math.sign(-100) == -1
        assert math.sign(-0.1) == -1
        assert math.sign(-0.001) == -1

    def test_zero(self):
        assert math.sign(0) == 0
        assert math.sign(-0) == 0

    def test_very_large_numbers(self):
        assert math.sign(1e10) == 1
        assert math.sign(-1e10) == -1

    def test_very_small_numbers(self):
        assert math.sign(1e-10) == 1
        assert math.sign(-1e-10) == -1

    def test_direction_determination(self):
        change = 5 - 10  # -5
        assert math.sign(change) == -1

        increase = 10 - 5  # 5
        assert math.sign(increase) == 1

    def test_sign_times_abs_equals_x(self):
        values = [5, -3, 10, -100, 0.5, -0.5]
        for x in values:
            if x != 0:
                assert math.sign(x) * math.abs(x) == pytest.approx(x)
