"""Tests for math.sum with Series input.

All tests in this file are skipped because the Python math_.py module
is currently scalar-only (no Series support for sum yet).
The array-based sum tests are in test_basic.py.
"""

import pytest

pytestmark = pytest.mark.skip(reason="math_.py is scalar-only; Series support not yet implemented")


class TestSumSeries:
    def test_series_input_returns_series(self):
        pass

    def test_array_input_returns_array(self):
        pass

    def test_same_results_for_series_and_array(self):
        pass
