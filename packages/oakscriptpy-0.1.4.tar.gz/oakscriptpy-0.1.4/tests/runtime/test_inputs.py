"""Tests for idempotent input registration functions.

Ported from: D:/WebstormProjects/oakscriptJS/tests/runtime/inputs.test.ts
"""

import pytest

from oakscriptpy.inputs import (
    input_int,
    input_float,
    input_bool,
    input_string,
    input_source,
    reset_inputs,
)
from oakscriptpy.runtime import set_context, clear_context
from oakscriptpy.runtime_types import OakScriptContext, OhlcvData
from oakscriptpy.adapters.simple_input import SimpleInputAdapter


# ---------------------------------------------------------------------------
# Mock helpers
# ---------------------------------------------------------------------------

class MockSeriesHandle:
    def set_data(self, data):
        pass


class MockChartAdapter:
    def add_series(self, type_: str, options=None):
        return MockSeriesHandle()

    def remove_series(self, series):
        pass


def create_mock_context():
    return OakScriptContext(
        chart=MockChartAdapter(),
        inputs=SimpleInputAdapter(),
        ohlcv=OhlcvData(
            time=[1000, 2000, 3000, 4000, 5000],
            open=[100, 101, 102, 103, 104],
            high=[105, 106, 107, 108, 109],
            low=[95, 96, 97, 98, 99],
            close=[102, 103, 104, 105, 106],
            volume=[1000, 1100, 1200, 1300, 1400],
        ),
        bar_index=4,
    )


# ---------------------------------------------------------------------------
# Fixture: clean up before and after each test
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _cleanup():
    clear_context()
    reset_inputs()
    yield
    clear_context()
    reset_inputs()


# ===========================================================================
# input_int
# ===========================================================================

class TestInputInt:
    def test_should_return_default_value_when_no_context_is_set(self):
        value = input_int(14, "Length")
        assert value == 14

    def test_should_floor_the_default_value(self):
        value = input_int(14.7, "Length")
        assert value == 14

    def test_should_register_input_and_return_default_value_on_first_call(self):
        ctx = create_mock_context()
        set_context(ctx)

        value = input_int(14, "Length")
        assert value == 14

    def test_should_be_idempotent(self):
        ctx = create_mock_context()
        set_context(ctx)

        value1 = input_int(14, "Length")
        value2 = input_int(14, "Length")
        value3 = input_int(14, "Length")

        assert value1 == 14
        assert value2 == 14
        assert value3 == 14

    def test_should_return_updated_value_after_user_changes_it(self):
        ctx = create_mock_context()
        set_context(ctx)

        input_int(14, "Length")

        # Simulate user changing the value
        ctx.inputs.set_value("Length", 20)

        # Subsequent call should return updated value
        value = input_int(14, "Length")
        assert value == 20

    def test_should_pass_options_to_input_config(self):
        ctx = create_mock_context()
        set_context(ctx)

        input_int(14, "Length", min=1, max=100, step=1)

        inputs = ctx.inputs.get_all_inputs()
        length_input = inputs.get("Length")
        assert length_input["config"].min == 1
        assert length_input["config"].max == 100
        assert length_input["config"].step == 1


# ===========================================================================
# input_float
# ===========================================================================

class TestInputFloat:
    def test_should_return_default_value_when_no_context_is_set(self):
        value = input_float(2.5, "Factor")
        assert value == 2.5

    def test_should_register_input_and_return_default_value_on_first_call(self):
        ctx = create_mock_context()
        set_context(ctx)

        value = input_float(2.5, "Factor")
        assert value == 2.5

    def test_should_be_idempotent(self):
        ctx = create_mock_context()
        set_context(ctx)

        value1 = input_float(2.5, "Factor")
        value2 = input_float(2.5, "Factor")

        assert value1 == 2.5
        assert value2 == 2.5

    def test_should_return_updated_value_after_user_changes_it(self):
        ctx = create_mock_context()
        set_context(ctx)

        input_float(2.5, "Factor")
        ctx.inputs.set_value("Factor", 3.0)

        value = input_float(2.5, "Factor")
        assert value == 3.0


# ===========================================================================
# input_bool
# ===========================================================================

class TestInputBool:
    def test_should_return_default_value_when_no_context_is_set(self):
        value = input_bool(True, "Show Labels")
        assert value is True

    def test_should_register_input_and_return_default_value_on_first_call(self):
        ctx = create_mock_context()
        set_context(ctx)

        value = input_bool(True, "Show Labels")
        assert value is True

    def test_should_be_idempotent(self):
        ctx = create_mock_context()
        set_context(ctx)

        value1 = input_bool(True, "Show Labels")
        value2 = input_bool(True, "Show Labels")

        assert value1 is True
        assert value2 is True

    def test_should_return_updated_value_after_user_changes_it(self):
        ctx = create_mock_context()
        set_context(ctx)

        input_bool(True, "Show Labels")
        ctx.inputs.set_value("Show_Labels", False)

        value = input_bool(True, "Show Labels")
        assert value is False


# ===========================================================================
# input_string
# ===========================================================================

class TestInputString:
    def test_should_return_default_value_when_no_context_is_set(self):
        value = input_string("SMA", "MA Type")
        assert value == "SMA"

    def test_should_register_input_and_return_default_value_on_first_call(self):
        ctx = create_mock_context()
        set_context(ctx)

        value = input_string("SMA", "MA Type", options=["SMA", "EMA", "WMA"])
        assert value == "SMA"

    def test_should_be_idempotent(self):
        ctx = create_mock_context()
        set_context(ctx)

        value1 = input_string("SMA", "MA Type")
        value2 = input_string("SMA", "MA Type")

        assert value1 == "SMA"
        assert value2 == "SMA"

    def test_should_return_updated_value_after_user_changes_it(self):
        ctx = create_mock_context()
        set_context(ctx)

        input_string("SMA", "MA Type", options=["SMA", "EMA", "WMA"])
        ctx.inputs.set_value("MA_Type", "EMA")

        value = input_string("SMA", "MA Type")
        assert value == "EMA"


# ===========================================================================
# input_source
# ===========================================================================

class TestInputSource:
    def test_should_return_empty_list_when_no_context_is_set(self):
        value = input_source("close", "Source")
        assert value == []

    def test_should_return_close_data_by_default(self):
        ctx = create_mock_context()
        set_context(ctx)

        value = input_source("close", "Source")
        assert value == [102, 103, 104, 105, 106]

    def test_should_return_open_data_when_selected(self):
        ctx = create_mock_context()
        set_context(ctx)

        input_source("open", "Source")
        value = input_source("open", "Source")
        assert value == [100, 101, 102, 103, 104]

    def test_should_return_high_data(self):
        ctx = create_mock_context()
        set_context(ctx)

        value = input_source("high", "Source")
        assert value == [105, 106, 107, 108, 109]

    def test_should_return_low_data(self):
        ctx = create_mock_context()
        set_context(ctx)

        value = input_source("low", "Source")
        assert value == [95, 96, 97, 98, 99]

    def test_should_return_volume_data(self):
        ctx = create_mock_context()
        set_context(ctx)

        value = input_source("volume", "Source")
        assert value == [1000, 1100, 1200, 1300, 1400]

    def test_should_calculate_hl2(self):
        ctx = create_mock_context()
        set_context(ctx)

        value = input_source("hl2", "Source")
        # hl2 = (high + low) / 2
        assert value == [100, 101, 102, 103, 104]

    def test_should_calculate_hlc3(self):
        ctx = create_mock_context()
        set_context(ctx)

        value = input_source("hlc3", "Source")
        # hlc3 = (high + low + close) / 3
        # For first bar: (105 + 95 + 102) / 3 = 100.67
        assert value[0] == pytest.approx(100.67, abs=0.01)

    def test_should_calculate_ohlc4(self):
        ctx = create_mock_context()
        set_context(ctx)

        value = input_source("ohlc4", "Source")
        # ohlc4 = (open + high + low + close) / 4
        # For first bar: (100 + 105 + 95 + 102) / 4 = 100.5
        assert value[0] == pytest.approx(100.5, abs=0.01)

    def test_should_return_updated_source_after_user_changes_it(self):
        ctx = create_mock_context()
        set_context(ctx)

        input_source("close", "Source")
        ctx.inputs.set_value("Source", "open")

        value = input_source("close", "Source")
        assert value == [100, 101, 102, 103, 104]

    def test_should_be_idempotent(self):
        ctx = create_mock_context()
        set_context(ctx)

        value1 = input_source("close", "Source")
        value2 = input_source("close", "Source")

        assert value1 == [102, 103, 104, 105, 106]
        assert value2 == [102, 103, 104, 105, 106]


# ===========================================================================
# reset_inputs
# ===========================================================================

class TestResetInputs:
    def test_should_clear_registered_inputs(self):
        ctx = create_mock_context()
        set_context(ctx)

        input_int(14, "Length")

        # Update value
        ctx.inputs.set_value("Length", 20)
        assert input_int(14, "Length") == 20

        # Reset inputs
        reset_inputs()
        clear_context()

        # Create new context
        ctx2 = create_mock_context()
        set_context(ctx2)

        # Should register again with default
        assert input_int(14, "Length") == 14
