"""Tests for Series class: BarData versioning, cache invalidation, materialize().

Ported from: D:/WebstormProjects/oakscriptJS/tests/runtime/series.test.ts
"""

import math

import pytest

from oakscriptpy.series import Series, BarData
from oakscriptpy._types import Bar


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_bars_3() -> list[Bar]:
    return [
        Bar(time=1, open=100, high=110, low=90, close=105, volume=1000),
        Bar(time=2, open=105, high=115, low=95, close=110, volume=1100),
        Bar(time=3, open=110, high=120, low=100, close=115, volume=1200),
    ]


def make_bars_5() -> list[Bar]:
    return [
        Bar(time=1, open=100, high=110, low=90, close=105, volume=1000),
        Bar(time=2, open=105, high=115, low=95, close=110, volume=1100),
        Bar(time=3, open=110, high=120, low=100, close=115, volume=1200),
        Bar(time=4, open=115, high=125, low=105, close=120, volume=1300),
        Bar(time=5, open=120, high=130, low=110, close=125, volume=1400),
    ]


# ===========================================================================
# BarData class
# ===========================================================================

class TestBarData:
    def test_should_initialize_with_bars_and_version_0(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        assert bar_data.length == 3
        assert bar_data.version == 0
        assert bar_data.bars == bars

    def test_should_increment_version_on_push(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        initial_version = bar_data.version
        new_bar = Bar(time=4, open=115, high=125, low=105, close=120, volume=1300)

        bar_data.push(new_bar)

        assert bar_data.length == 4
        assert bar_data.version == initial_version + 1
        assert bar_data.at(3) == new_bar

    def test_should_increment_version_on_pop(self):
        bars = list(make_bars_3())
        bar_data = BarData(bars)
        initial_version = bar_data.version
        expected_popped = bar_data.bars[2]

        popped = bar_data.pop()

        assert popped == expected_popped
        assert bar_data.length == 2
        assert bar_data.version == initial_version + 1

    def test_should_not_increment_version_on_pop_from_empty_array(self):
        bar_data = BarData([])
        initial_version = bar_data.version

        popped = bar_data.pop()

        assert popped is None
        assert bar_data.version == initial_version

    def test_should_increment_version_on_set(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        initial_version = bar_data.version
        updated_bar = Bar(time=2, open=106, high=116, low=96, close=111, volume=1150)

        bar_data.set(1, updated_bar)

        assert bar_data.at(1) == updated_bar
        assert bar_data.version == initial_version + 1

    def test_should_not_increment_version_on_invalid_set_index(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        initial_version = bar_data.version
        updated_bar = Bar(time=10, open=106, high=116, low=96, close=111, volume=1150)

        bar_data.set(10, updated_bar)
        bar_data.set(-1, updated_bar)

        assert bar_data.version == initial_version

    def test_should_increment_version_on_update_last(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        initial_version = bar_data.version
        updated_bar = Bar(time=3, open=111, high=121, low=101, close=116, volume=1250)

        bar_data.update_last(updated_bar)

        assert bar_data.at(2) == updated_bar
        assert bar_data.version == initial_version + 1

    def test_should_not_increment_version_on_update_last_for_empty_array(self):
        bar_data = BarData([])
        initial_version = bar_data.version
        updated_bar = Bar(time=1, open=100, high=110, low=90, close=105, volume=1000)

        bar_data.update_last(updated_bar)

        assert bar_data.version == initial_version

    def test_should_increment_version_on_set_all(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        initial_version = bar_data.version
        new_bars = [
            Bar(time=10, open=200, high=210, low=190, close=205, volume=2000),
        ]

        bar_data.set_all(new_bars)

        assert bar_data.length == 1
        assert bar_data.bars == new_bars
        assert bar_data.version == initial_version + 1

    def test_should_increment_version_on_manual_invalidate(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        initial_version = bar_data.version

        bar_data.invalidate()

        assert bar_data.version == initial_version + 1

    def test_should_support_creating_from_existing_array(self):
        bars = make_bars_3()
        created = BarData.from_bars(bars)

        assert created.length == 3
        assert created.bars == bars
        assert created.version == 0


# ===========================================================================
# Series automatic cache invalidation
# ===========================================================================

class TestSeriesCacheInvalidation:
    def test_should_cache_values_on_first_to_array_call(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        close = Series.from_bars(bar_data, "close")

        values1 = close.to_array()
        values2 = close.to_array()  # Should return cached

        assert values1 == [105, 110, 115]
        assert values2 is values1  # Same reference = cached

    def test_should_invalidate_cache_when_new_bar_is_pushed(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        close = Series.from_bars(bar_data, "close")

        values1 = close.to_array()
        assert values1 == [105, 110, 115]

        # Add new bar
        bar_data.push(Bar(time=4, open=115, high=125, low=105, close=120, volume=1300))

        values2 = close.to_array()
        assert values2 == [105, 110, 115, 120]
        assert values2 is not values1  # Different reference = recomputed

    def test_should_invalidate_cache_when_bar_is_updated(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        close = Series.from_bars(bar_data, "close")

        values1 = close.to_array()
        assert values1[1] == 110

        # Update a bar
        bar_data.set(1, Bar(time=2, open=105, high=115, low=95, close=112, volume=1100))

        values2 = close.to_array()
        assert values2[1] == 112
        assert values2 is not values1  # Recomputed

    def test_should_invalidate_cache_when_last_bar_is_updated(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        close = Series.from_bars(bar_data, "close")

        values1 = close.to_array()
        assert values1[2] == 115

        # Update last bar (simulating real-time update)
        bar_data.update_last(Bar(time=3, open=110, high=120, low=100, close=118, volume=1250))

        values2 = close.to_array()
        assert values2[2] == 118
        assert values2 is not values1

    def test_should_invalidate_derived_series_when_underlying_data_changes(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        close = Series.from_bars(bar_data, "close")
        open_ = Series.from_bars(bar_data, "open")
        range_ = close - open_

        values1 = range_.to_array()
        assert values1 == [5, 5, 5]  # 105-100, 110-105, 115-110

        # Update data
        bar_data.push(Bar(time=4, open=115, high=125, low=105, close=125, volume=1300))

        values2 = range_.to_array()
        assert values2 == [5, 5, 5, 10]  # New: 125-115

    def test_should_work_with_manual_invalidation_for_backward_compatibility(self):
        bars = make_bars_3()
        bar_data = BarData(bars)
        close = Series.from_bars(bar_data, "close")

        values1 = close.to_array()
        assert values1 == [105, 110, 115]

        # Manually invalidate (old API)
        close._invalidate()

        # Even though data hasn't changed, cache should be cleared
        values2 = close.to_array()
        assert values2 == [105, 110, 115]
        assert values2 is not values1  # Recomputed


# ===========================================================================
# Series backward compatibility with Bar[]
# ===========================================================================

class TestSeriesBackwardCompatibility:
    def test_should_work_with_bar_list_no_bar_data(self):
        bars = make_bars_3()
        close = Series.from_bars(bars, "close")

        values = close.to_array()
        assert values == [105, 110, 115]

    def test_should_automatically_wrap_bar_list_in_bar_data(self):
        bars = make_bars_3()
        close = Series.from_bars(bars, "close")

        assert isinstance(close.bar_data, BarData)
        assert close.bar_data.bars == bars

    def test_should_cache_when_using_bar_list_directly(self):
        bars = make_bars_3()
        close = Series.from_bars(bars, "close")

        values1 = close.to_array()
        values2 = close.to_array()

        assert values2 is values1  # Cached

    def test_should_work_with_series_operations_using_bar_list(self):
        bars = make_bars_3()
        close = Series.from_bars(bars, "close")
        open_ = Series.from_bars(bars, "open")
        range_ = close - open_

        values = range_.to_array()
        assert values == [5, 5, 5]


# ===========================================================================
# Series materialize() for memory management
# ===========================================================================

class TestMaterialize:
    @pytest.fixture(autouse=True)
    def _bars(self):
        self.bars = make_bars_5()

    def test_should_compute_and_return_correct_values(self):
        close = Series.from_bars(self.bars, "close")
        doubled = close * 2

        materialized = doubled.materialize()

        assert materialized.to_array() == [210, 220, 230, 240, 250]

    def test_should_create_a_new_series_instance(self):
        close = Series.from_bars(self.bars, "close")
        doubled = close * 2

        materialized = doubled.materialize()

        assert isinstance(materialized, Series)
        assert materialized is not doubled

    def test_should_allow_further_operations_on_materialized_series(self):
        close = Series.from_bars(self.bars, "close")
        complex_ = (close + 10) * 2

        materialized = complex_.materialize()
        result = materialized - 20

        assert result.to_array() == [210, 220, 230, 240, 250]
        # (105+10)*2 - 20 = 210, etc.

    def test_should_work_with_long_operation_chains(self):
        a = Series.from_bars(self.bars, "close")
        b = Series.from_bars(self.bars, "open")
        c = Series.constant(self.bars, 10)

        # Long chain: (close - open + 10) * 2 / 5
        complex_ = (a - b + c) * 2 / 5
        materialized = complex_.materialize()

        # close - open = [5, 5, 5, 5, 5]
        # + 10 = [15, 15, 15, 15, 15]
        # * 2 = [30, 30, 30, 30, 30]
        # / 5 = [6, 6, 6, 6, 6]
        assert materialized.to_array() == [6, 6, 6, 6, 6]

    def test_should_cache_materialized_values(self):
        close = Series.from_bars(self.bars, "close")
        materialized = (close * 2).materialize()

        values1 = materialized.to_array()
        values2 = materialized.to_array()

        assert values2 is values1  # Same reference = cached

    def test_should_respect_bar_data_versioning_after_materialization(self):
        bar_data = BarData(self.bars)
        close = Series.from_bars(bar_data, "close")
        doubled = close * 2

        values1 = doubled.to_array()
        assert values1 == [210, 220, 230, 240, 250]

        # Add new bar
        bar_data.push(Bar(time=6, open=125, high=135, low=115, close=130, volume=1500))

        values2 = doubled.to_array()
        assert values2 == [210, 220, 230, 240, 250, 260]

        # Materialize after the data change
        materialized = doubled.materialize()
        assert materialized.to_array() == [210, 220, 230, 240, 250, 260]

    def test_should_handle_nan_values_correctly(self):
        values = Series.from_array(self.bars, [1, float("nan"), 3, 4, 5])
        materialized = (values * 2).materialize()

        result = materialized.to_array()
        assert result[0] == 2
        assert math.isnan(result[1])
        assert result[2] == 6
        assert result[3] == 8
        assert result[4] == 10

    def test_should_work_with_all_arithmetic_operations(self):
        a = Series.from_array(self.bars, [10, 20, 30, 40, 50])
        b = Series.from_array(self.bars, [2, 4, 6, 8, 10])

        add = (a + b).materialize()
        assert add.to_array() == [12, 24, 36, 48, 60]

        sub = (a - b).materialize()
        assert sub.to_array() == [8, 16, 24, 32, 40]

        mul = (a * b).materialize()
        assert mul.to_array() == [20, 80, 180, 320, 500]

        div = (a / b).materialize()
        assert div.to_array() == [5, 5, 5, 5, 5]

    def test_should_work_with_comparison_operations(self):
        a = Series.from_array(self.bars, [10, 20, 30, 40, 50])
        b = Series.from_array(self.bars, [15, 15, 30, 45, 40])

        gt = (a > b).materialize()
        assert gt.to_array() == [0, 1, 0, 0, 1]

        lt = (a < b).materialize()
        assert lt.to_array() == [1, 0, 0, 1, 0]

        eq = a.eq(b).materialize()
        assert eq.to_array() == [0, 0, 1, 0, 0]

    def test_should_work_with_offset_operations(self):
        close = Series.from_bars(self.bars, "close")
        prev = close.offset(1)

        materialized = prev.materialize()
        values = materialized.to_array()

        assert math.isnan(values[0])  # No previous value
        assert values[1] == 105
        assert values[2] == 110
        assert values[3] == 115
        assert values[4] == 120


# ===========================================================================
# Series integration tests
# ===========================================================================

class TestSeriesIntegration:
    def test_moving_average_streaming_scenario(self):
        bar_data = BarData([
            Bar(time=1, open=100, high=110, low=90, close=105, volume=1000),
            Bar(time=2, open=105, high=115, low=95, close=110, volume=1100),
            Bar(time=3, open=110, high=120, low=100, close=115, volume=1200),
            Bar(time=4, open=115, high=125, low=105, close=120, volume=1300),
            Bar(time=5, open=120, high=130, low=110, close=125, volume=1400),
        ])

        close = Series.from_bars(bar_data, "close")

        # Simulate adding new bar (streaming)
        values1 = close.to_array()
        assert values1 == [105, 110, 115, 120, 125]

        bar_data.push(Bar(time=6, open=125, high=135, low=115, close=130, volume=1500))

        values2 = close.to_array()
        assert values2 == [105, 110, 115, 120, 125, 130]

        # Simulate updating last bar (real-time tick)
        bar_data.update_last(Bar(time=6, open=125, high=135, low=115, close=132, volume=1550))

        values3 = close.to_array()
        assert values3 == [105, 110, 115, 120, 125, 132]

    def test_memory_efficient_complex_indicator_chain(self):
        bars = [
            Bar(time=1, open=100, high=110, low=90, close=105, volume=1000),
            Bar(time=2, open=105, high=115, low=95, close=110, volume=1100),
            Bar(time=3, open=110, high=120, low=100, close=115, volume=1200),
        ]

        close = Series.from_bars(bars, "close")
        open_ = Series.from_bars(bars, "open")
        high = Series.from_bars(bars, "high")
        low = Series.from_bars(bars, "low")

        # Complex calculation: typical price = (high + low + close) / 3
        typical_price = (high + low + close) / 3

        # Materialize to break closure chain before further operations
        materialized = typical_price.materialize()

        # Further calculations
        range_ = high - low
        result = materialized * range_

        values = result.to_array()
        # typical[0] = (110 + 90 + 105) / 3 = 101.6666..., range[0] = 20
        # result[0] = 101.6666... * 20 = 2033.333...
        assert values[0] == pytest.approx(2033.33, abs=0.1)
