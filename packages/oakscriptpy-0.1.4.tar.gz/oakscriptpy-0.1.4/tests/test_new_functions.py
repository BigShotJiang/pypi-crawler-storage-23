"""Tests for new functions: color.new alias, str.replace_all, str.format_time."""

import calendar

import pytest

from oakscriptpy import color
from oakscriptpy import str_ as str_mod


# --- color.new (alias for new_color) ---

class TestColorNewAlias:
    def test_works_as_alias(self):
        red_color = color.rgb(255, 0, 0)
        transparent_red = color.new(red_color, 50)

        assert "rgba" in transparent_red
        assert "255" in transparent_red
        assert "0.5" in transparent_red  # 50% transparency = 0.5 alpha

    def test_fully_transparent(self):
        blue_color = color.rgb(0, 0, 255)
        invisible = color.new(blue_color, 100)

        assert "0)" in invisible  # alpha = 0

    def test_fully_opaque(self):
        green_color = color.rgb(0, 255, 0)
        opaque = color.new(green_color, 0)

        assert opaque == "rgb(0, 255, 0)"  # No alpha channel


# --- str.replace_all ---

class TestReplaceAll:
    def test_replace_all_occurrences(self):
        result = str_mod.replace_all("hello world hello", "hello", "hi")
        assert result == "hi world hi"

    def test_replace_special_characters(self):
        result = str_mod.replace_all("a-b-c-d", "-", "_")
        assert result == "a_b_c_d"

    def test_no_match(self):
        result = str_mod.replace_all("test", "x", "y")
        assert result == "test"

    def test_empty_replacement(self):
        result = str_mod.replace_all("a1b2c3", "1", "")
        assert result == "ab2c3"  # Only removes '1'


# --- str.format_time ---

class TestFormatTime:
    def test_format_dd_mmm_yyyy(self):
        timestamp = _utc_ms(2021, 1, 1, 0, 0, 0)  # Jan 1, 2021
        result = str_mod.format_time(timestamp, "dd MMM yyyy")
        assert result == "01 Jan 2021"

    def test_format_full_datetime(self):
        timestamp = _utc_ms(2021, 1, 1, 15, 30, 45)  # Jan 1, 2021 15:30:45
        result = str_mod.format_time(timestamp, "yyyy-MM-dd HH:mm:ss")
        assert result == "2021-01-01 15:30:45"

    def test_format_with_month_names(self):
        timestamp = _utc_ms(2021, 3, 15)  # March 15, 2021
        result = str_mod.format_time(timestamp, "MMM d, yyyy")
        assert result == "Mar 15, 2021"

    def test_format_full_month_name(self):
        timestamp = _utc_ms(2021, 12, 25)  # December 25, 2021
        result = str_mod.format_time(timestamp, "MMMM dd, yyyy")
        assert result == "December 25, 2021"

    def test_format_12_hour_with_ampm(self):
        timestamp1 = _utc_ms(2021, 1, 1, 9, 15, 0)  # 9:15 AM
        result1 = str_mod.format_time(timestamp1, "hh:mm a")
        assert result1 == "09:15 AM"

        timestamp2 = _utc_ms(2021, 1, 1, 21, 30, 0)  # 9:30 PM
        result2 = str_mod.format_time(timestamp2, "hh:mm a")
        assert result2 == "09:30 PM"

    def test_format_24_hour(self):
        timestamp = _utc_ms(2021, 1, 1, 23, 59, 59)
        result = str_mod.format_time(timestamp, "HH:mm:ss")
        assert result == "23:59:59"

    def test_2_digit_year(self):
        timestamp = _utc_ms(2024, 6, 10)  # June 10, 2024
        result = str_mod.format_time(timestamp, "MM/dd/yy")
        assert result == "06/10/24"

    def test_single_digit_formats(self):
        timestamp = _utc_ms(2021, 1, 5, 7, 8, 9)  # Jan 5, 2021 07:08:09
        result = str_mod.format_time(timestamp, "M/d/yyyy H:m:s")
        assert result == "1/5/2021 7:8:9"


def _utc_ms(year: int, month: int, day: int, hour: int = 0, minute: int = 0, second: int = 0) -> int:
    """Create a UTC timestamp in milliseconds, matching JS Date.UTC() behavior."""
    import datetime
    dt = datetime.datetime(year, month, day, hour, minute, second, tzinfo=datetime.timezone.utc)
    return int(dt.timestamp() * 1000)
