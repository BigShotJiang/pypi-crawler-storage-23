"""Tests for color component extraction functions: r, g, b, t."""

import pytest

from oakscriptpy import color


# --- color.r ---

class TestR:
    def test_red_from_rgb(self):
        assert color.r(color.rgb(255, 0, 0)) == 255
        assert color.r(color.rgb(128, 0, 0)) == 128
        assert color.r(color.rgb(0, 0, 0)) == 0
        assert color.r(color.rgb(255, 128, 64)) == 255

    def test_red_from_rgba(self):
        assert color.r(color.rgb(255, 0, 0, 50)) == 255
        assert color.r(color.rgb(128, 128, 128, 75)) == 128

    def test_red_from_hex(self):
        assert color.r(color.from_hex("#FF0000")) == 255
        assert color.r(color.from_hex("#800000")) == 128
        assert color.r(color.from_hex("#FFA500")) == 255  # orange

    def test_edge_cases(self):
        assert color.r(color.rgb(0, 255, 255)) == 0
        assert color.r(color.rgb(255, 255, 255)) == 255


# --- color.g ---

class TestG:
    def test_green_from_rgb(self):
        assert color.g(color.rgb(0, 255, 0)) == 255
        assert color.g(color.rgb(0, 128, 0)) == 128
        assert color.g(color.rgb(0, 0, 0)) == 0
        assert color.g(color.rgb(64, 128, 255)) == 128

    def test_green_from_rgba(self):
        assert color.g(color.rgb(0, 255, 0, 50)) == 255
        assert color.g(color.rgb(128, 128, 128, 75)) == 128

    def test_green_from_hex(self):
        assert color.g(color.from_hex("#00FF00")) == 255
        assert color.g(color.from_hex("#008000")) == 128
        assert color.g(color.from_hex("#FFA500")) == 165  # orange

    def test_edge_cases(self):
        assert color.g(color.rgb(255, 0, 255)) == 0
        assert color.g(color.rgb(255, 255, 255)) == 255


# --- color.b ---

class TestB:
    def test_blue_from_rgb(self):
        assert color.b(color.rgb(0, 0, 255)) == 255
        assert color.b(color.rgb(0, 0, 128)) == 128
        assert color.b(color.rgb(0, 0, 0)) == 0
        assert color.b(color.rgb(255, 64, 128)) == 128

    def test_blue_from_rgba(self):
        assert color.b(color.rgb(0, 0, 255, 50)) == 255
        assert color.b(color.rgb(128, 128, 128, 75)) == 128

    def test_blue_from_hex(self):
        assert color.b(color.from_hex("#0000FF")) == 255
        assert color.b(color.from_hex("#000080")) == 128
        assert color.b(color.from_hex("#FFA500")) == 0  # orange

    def test_edge_cases(self):
        assert color.b(color.rgb(255, 255, 0)) == 0
        assert color.b(color.rgb(255, 255, 255)) == 255


# --- color.t ---

class TestT:
    def test_opaque_rgb_returns_0(self):
        assert color.t(color.rgb(255, 0, 0)) == 0
        assert color.t(color.rgb(0, 255, 0)) == 0
        assert color.t(color.rgb(0, 0, 255)) == 0

    def test_transparency_value_for_rgba(self):
        assert color.t(color.rgb(255, 0, 0, 50)) == pytest.approx(50, abs=1)
        assert color.t(color.rgb(0, 255, 0, 25)) == pytest.approx(25, abs=1)
        assert color.t(color.rgb(0, 0, 255, 75)) == pytest.approx(75, abs=1)

    def test_0_percent_transparency(self):
        assert color.t(color.rgb(255, 0, 0, 0)) == 0

    def test_100_percent_transparency(self):
        assert color.t(color.rgb(255, 0, 0, 100)) == pytest.approx(100, abs=1)

    def test_hex_with_transparency(self):
        assert color.t(color.from_hex("#FF0000", 50)) == pytest.approx(50, abs=1)
        assert color.t(color.from_hex("#00FF00", 0)) == 0

    def test_after_new_color(self):
        base_color = color.rgb(255, 0, 0)
        new_clr = color.new_color(base_color, 33)
        assert color.t(new_clr) == pytest.approx(33, abs=1)

    def test_various_transparency_levels(self):
        assert color.t(color.rgb(0, 0, 0, 10)) == pytest.approx(10, abs=1)
        assert color.t(color.rgb(0, 0, 0, 90)) == pytest.approx(90, abs=1)


# --- Integration tests ---

class TestComponentsIntegration:
    def test_extract_all_components(self):
        clr = color.rgb(255, 128, 64, 30)
        assert color.r(clr) == 255
        assert color.g(clr) == 128
        assert color.b(clr) == 64
        assert color.t(clr) == pytest.approx(30, abs=1)

    def test_extract_from_hex(self):
        clr = color.from_hex("#FFA500", 40)  # orange with transparency
        assert color.r(clr) == 255
        assert color.g(clr) == 165
        assert color.b(clr) == 0
        assert color.t(clr) == pytest.approx(40, abs=1)

    def test_common_colors(self):
        red = color.rgb(255, 0, 0)
        assert color.r(red) == 255
        assert color.g(red) == 0
        assert color.b(red) == 0
        assert color.t(red) == 0

        green = color.rgb(0, 255, 0)
        assert color.r(green) == 0
        assert color.g(green) == 255
        assert color.b(green) == 0
        assert color.t(green) == 0

        blue = color.rgb(0, 0, 255)
        assert color.r(blue) == 0
        assert color.g(blue) == 0
        assert color.b(blue) == 255
        assert color.t(blue) == 0

    def test_black_and_white(self):
        black = color.rgb(0, 0, 0)
        assert color.r(black) == 0
        assert color.g(black) == 0
        assert color.b(black) == 0
        assert color.t(black) == 0

        white = color.rgb(255, 255, 255)
        assert color.r(white) == 255
        assert color.g(white) == 255
        assert color.b(white) == 255
        assert color.t(white) == 0

    def test_reconstruct_color_from_components(self):
        original = color.rgb(123, 45, 67, 20)

        r = color.r(original)
        g = color.g(original)
        b = color.b(original)
        t = color.t(original)

        reconstructed = color.rgb(r, g, b, t)

        assert color.r(reconstructed) == 123
        assert color.g(reconstructed) == 45
        assert color.b(reconstructed) == 67
        assert color.t(reconstructed) == pytest.approx(20, abs=1)
