"""Tests for color creation functions: rgb, from_hex."""

from oakscriptpy import color


# --- color.rgb ---

class TestRgb:
    def test_create_rgb_without_transparency(self):
        assert color.rgb(255, 0, 0) == "rgb(255, 0, 0)"
        assert color.rgb(0, 255, 0) == "rgb(0, 255, 0)"
        assert color.rgb(0, 0, 255) == "rgb(0, 0, 255)"
        assert color.rgb(128, 128, 128) == "rgb(128, 128, 128)"

    def test_create_rgba_with_transparency(self):
        assert color.rgb(255, 0, 0, 50) == "rgba(255, 0, 0, 0.5)"
        assert color.rgb(0, 255, 0, 25) == "rgba(0, 255, 0, 0.75)"
        assert color.rgb(0, 0, 255, 75) == "rgba(0, 0, 255, 0.25)"
        # Python formats 0 as 0.0 for float alpha
        assert color.rgb(128, 128, 128, 100) == "rgba(128, 128, 128, 0.0)"

    def test_create_rgb_when_transparency_is_0(self):
        assert color.rgb(255, 0, 0, 0) == "rgb(255, 0, 0)"
        assert color.rgb(0, 255, 0, 0) == "rgb(0, 255, 0)"

    def test_clamp_values_to_valid_range(self):
        assert color.rgb(300, 0, 0) == "rgb(255, 0, 0)"
        assert color.rgb(-10, 0, 0) == "rgb(0, 0, 0)"
        assert color.rgb(0, 300, -10) == "rgb(0, 255, 0)"
        assert color.rgb(256, 256, 256) == "rgb(255, 255, 255)"

    def test_black(self):
        assert color.rgb(0, 0, 0) == "rgb(0, 0, 0)"
        assert color.rgb(0, 0, 0, 0) == "rgb(0, 0, 0)"

    def test_white(self):
        assert color.rgb(255, 255, 255) == "rgb(255, 255, 255)"
        assert color.rgb(255, 255, 255, 0) == "rgb(255, 255, 255)"

    def test_edge_transparency_values(self):
        assert color.rgb(255, 0, 0, 0) == "rgb(255, 0, 0)"         # fully opaque
        assert color.rgb(255, 0, 0, 100) == "rgba(255, 0, 0, 0.0)"  # fully transparent
        assert color.rgb(255, 0, 0, 50) == "rgba(255, 0, 0, 0.5)"

    def test_decimal_transparency_values(self):
        result1 = color.rgb(255, 0, 0, 33.33)
        assert "rgba(255, 0, 0," in result1
        result2 = color.rgb(0, 255, 0, 66.67)
        assert "rgba(0, 255, 0," in result2

    def test_common_colors(self):
        assert color.rgb(255, 0, 0) == "rgb(255, 0, 0)"      # red
        assert color.rgb(0, 255, 0) == "rgb(0, 255, 0)"      # green
        assert color.rgb(0, 0, 255) == "rgb(0, 0, 255)"      # blue
        assert color.rgb(255, 255, 0) == "rgb(255, 255, 0)"  # yellow
        assert color.rgb(255, 0, 255) == "rgb(255, 0, 255)"  # magenta
        assert color.rgb(0, 255, 255) == "rgb(0, 255, 255)"  # cyan


# --- color.from_hex ---

class TestFromHex:
    def test_hex_with_hash(self):
        assert color.from_hex("#FF0000") == "rgb(255, 0, 0)"
        assert color.from_hex("#00FF00") == "rgb(0, 255, 0)"
        assert color.from_hex("#0000FF") == "rgb(0, 0, 255)"

    def test_hex_without_hash(self):
        assert color.from_hex("FF0000") == "rgb(255, 0, 0)"
        assert color.from_hex("00FF00") == "rgb(0, 255, 0)"
        assert color.from_hex("0000FF") == "rgb(0, 0, 255)"

    def test_hex_with_transparency(self):
        assert color.from_hex("#FF0000", 50) == "rgba(255, 0, 0, 0.5)"
        assert color.from_hex("00FF00", 25) == "rgba(0, 255, 0, 0.75)"
        assert color.from_hex("#0000FF", 75) == "rgba(0, 0, 255, 0.25)"

    def test_black_and_white(self):
        assert color.from_hex("#000000") == "rgb(0, 0, 0)"
        assert color.from_hex("#FFFFFF") == "rgb(255, 255, 255)"
        assert color.from_hex("000000") == "rgb(0, 0, 0)"
        assert color.from_hex("FFFFFF") == "rgb(255, 255, 255)"

    def test_lowercase_hex(self):
        assert color.from_hex("#ff0000") == "rgb(255, 0, 0)"
        assert color.from_hex("00ff00") == "rgb(0, 255, 0)"
        assert color.from_hex("#0000ff") == "rgb(0, 0, 255)"

    def test_mixed_case_hex(self):
        assert color.from_hex("#Ff0000") == "rgb(255, 0, 0)"
        assert color.from_hex("00Ff00") == "rgb(0, 255, 0)"
        assert color.from_hex("#0000fF") == "rgb(0, 0, 255)"

    def test_common_colors(self):
        assert color.from_hex("#FF0000") == "rgb(255, 0, 0)"      # red
        assert color.from_hex("#00FF00") == "rgb(0, 255, 0)"      # green
        assert color.from_hex("#0000FF") == "rgb(0, 0, 255)"      # blue
        assert color.from_hex("#FFFF00") == "rgb(255, 255, 0)"    # yellow
        assert color.from_hex("#FF00FF") == "rgb(255, 0, 255)"    # magenta
        assert color.from_hex("#00FFFF") == "rgb(0, 255, 255)"    # cyan

    def test_various_color_values(self):
        assert color.from_hex("#FFA500") == "rgb(255, 165, 0)"    # orange
        assert color.from_hex("#800080") == "rgb(128, 0, 128)"    # purple
        assert color.from_hex("#808080") == "rgb(128, 128, 128)"  # gray
        assert color.from_hex("#C0C0C0") == "rgb(192, 192, 192)"  # silver

    def test_combine_with_transparency(self):
        assert color.from_hex("#FF0000", 0) == "rgb(255, 0, 0)"
        assert color.from_hex("#FF0000", 100) == "rgba(255, 0, 0, 0.0)"
