"""Tests for string formatting functions: split, concat, format."""

from oakscriptpy import str_ as str_mod


# --- str.split ---

class TestSplit:
    def test_split_by_separator(self):
        assert str_mod.split("hello world", " ") == ["hello", "world"]
        assert str_mod.split("a,b,c", ",") == ["a", "b", "c"]
        assert str_mod.split("one-two-three", "-") == ["one", "two", "three"]

    def test_empty_separator(self):
        # Python's str.split('') raises ValueError, unlike JS which splits chars.
        # This tests the actual Python behavior.
        import pytest
        with pytest.raises(ValueError):
            str_mod.split("abc", "")

    def test_separator_not_in_string(self):
        assert str_mod.split("hello", ",") == ["hello"]
        assert str_mod.split("test", "|") == ["test"]

    def test_empty_string(self):
        assert str_mod.split("", ",") == [""]

    def test_multiple_consecutive_separators(self):
        assert str_mod.split("a,,b", ",") == ["a", "", "b"]
        assert str_mod.split("hello  world", " ") == ["hello", "", "world"]

    def test_separator_at_start_or_end(self):
        assert str_mod.split(",a,b,", ",") == ["", "a", "b", ""]
        assert str_mod.split(" hello ", " ") == ["", "hello", ""]

    def test_multi_character_separator(self):
        assert str_mod.split("hello::world", "::") == ["hello", "world"]
        assert str_mod.split("a<->b<->c", "<->") == ["a", "b", "c"]


# --- str.concat ---

class TestConcat:
    def test_two_strings(self):
        assert str_mod.concat("hello", "world") == "helloworld"
        assert str_mod.concat("test", "123") == "test123"

    def test_multiple_strings(self):
        assert str_mod.concat("a", "b", "c") == "abc"
        assert str_mod.concat("hello", " ", "world") == "hello world"
        assert str_mod.concat("one", "two", "three", "four") == "onetwothreefour"

    def test_empty_strings(self):
        assert str_mod.concat("", "") == ""
        assert str_mod.concat("hello", "") == "hello"
        assert str_mod.concat("", "world") == "world"
        assert str_mod.concat("", "hello", "") == "hello"

    def test_single_string(self):
        assert str_mod.concat("hello") == "hello"
        assert str_mod.concat("") == ""

    def test_special_characters(self):
        assert str_mod.concat("hello", "@", "world") == "hello@world"
        assert str_mod.concat("$", "100") == "$100"
        assert str_mod.concat("a", "-", "b", "-", "c") == "a-b-c"


# --- str.format ---

class TestFormat:
    def test_single_placeholder(self):
        assert str_mod.format("Hello {0}", "world") == "Hello world"
        assert str_mod.format("Test {0}", "123") == "Test 123"

    def test_multiple_placeholders(self):
        assert str_mod.format("{0} {1}", "hello", "world") == "hello world"
        assert str_mod.format("{0} + {1} = {2}", "1", "2", "3") == "1 + 2 = 3"
        assert str_mod.format("{0}, {1}, {2}", "a", "b", "c") == "a, b, c"

    def test_placeholders_any_order(self):
        assert str_mod.format("{1} {0}", "world", "hello") == "hello world"
        assert str_mod.format("{2} {1} {0}", "a", "b", "c") == "c b a"

    def test_repeated_placeholders(self):
        assert str_mod.format("{0} {0} {0}", "test") == "test test test"
        assert str_mod.format("{0} and {1} and {0}", "A", "B") == "A and B and A"

    def test_missing_arguments(self):
        assert str_mod.format("{0} {1}", "hello") == "hello {1}"
        assert str_mod.format("{0} {1} {2}", "a", "b") == "a b {2}"

    def test_no_placeholders(self):
        assert str_mod.format("hello world", "test") == "hello world"
        assert str_mod.format("no placeholders", "a", "b") == "no placeholders"

    def test_non_string_arguments(self):
        assert str_mod.format("Value: {0}", 123) == "Value: 123"
        assert str_mod.format("Flag: {0}", True) == "Flag: True"
        assert str_mod.format("{0} + {1}", 1, 2) == "1 + 2"

    def test_empty_format_string(self):
        assert str_mod.format("", "test") == ""
        assert str_mod.format("", "a", "b", "c") == ""

    def test_special_characters_in_arguments(self):
        assert str_mod.format("Email: {0}", "test@example.com") == "Email: test@example.com"
        assert str_mod.format("Price: {0}", "$100") == "Price: $100"
