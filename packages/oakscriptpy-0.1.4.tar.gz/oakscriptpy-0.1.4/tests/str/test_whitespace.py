"""Tests for string whitespace and matching functions: trim, trimLeft, trimRight, match."""

from oakscriptpy import str_ as str_mod


# --- str.trim ---

class TestTrim:
    def test_trim_both_ends(self):
        assert str_mod.trim("  hello  ") == "hello"
        assert str_mod.trim("  world  ") == "world"
        assert str_mod.trim("\ttest\t") == "test"
        assert str_mod.trim("\n\nhello\n\n") == "hello"

    def test_no_whitespace(self):
        assert str_mod.trim("hello") == "hello"
        assert str_mod.trim("world") == "world"

    def test_only_leading(self):
        assert str_mod.trim("  hello") == "hello"
        assert str_mod.trim("\tworld") == "world"

    def test_only_trailing(self):
        assert str_mod.trim("hello  ") == "hello"
        assert str_mod.trim("world\t") == "world"

    def test_empty_string(self):
        assert str_mod.trim("") == ""

    def test_only_whitespace(self):
        assert str_mod.trim("   ") == ""
        assert str_mod.trim("\t\t\t") == ""
        assert str_mod.trim("\n\n\n") == ""
        assert str_mod.trim("  \t\n  ") == ""

    def test_preserve_internal_whitespace(self):
        assert str_mod.trim("  hello world  ") == "hello world"
        assert str_mod.trim("  a  b  c  ") == "a  b  c"

    def test_mixed_whitespace(self):
        assert str_mod.trim(" \t\nhello\n\t ") == "hello"
        assert str_mod.trim("\r\n\tworld\t\n\r") == "world"


# --- str.trim_left (JS: str.trimLeft) ---

class TestTrimLeft:
    def test_trim_left_only(self):
        assert str_mod.trim_left("  hello") == "hello"
        assert str_mod.trim_left("  world  ") == "world  "
        assert str_mod.trim_left("\ttest") == "test"
        assert str_mod.trim_left("\n\nhello\n\n") == "hello\n\n"

    def test_no_leading_whitespace(self):
        assert str_mod.trim_left("hello") == "hello"
        assert str_mod.trim_left("hello  ") == "hello  "

    def test_empty_string(self):
        assert str_mod.trim_left("") == ""

    def test_only_whitespace(self):
        assert str_mod.trim_left("   ") == ""
        assert str_mod.trim_left("\t\t\t") == ""
        assert str_mod.trim_left("\n\n\n") == ""

    def test_preserve_internal_and_trailing(self):
        assert str_mod.trim_left("  hello world  ") == "hello world  "
        assert str_mod.trim_left("  a  b  c") == "a  b  c"

    def test_mixed_whitespace(self):
        assert str_mod.trim_left(" \t\nhello") == "hello"
        assert str_mod.trim_left("\r\n\tworld\t\n\r") == "world\t\n\r"


# --- str.trim_right (JS: str.trimRight) ---

class TestTrimRight:
    def test_trim_right_only(self):
        assert str_mod.trim_right("hello  ") == "hello"
        assert str_mod.trim_right("  world  ") == "  world"
        assert str_mod.trim_right("test\t") == "test"
        assert str_mod.trim_right("\n\nhello\n\n") == "\n\nhello"

    def test_no_trailing_whitespace(self):
        assert str_mod.trim_right("hello") == "hello"
        assert str_mod.trim_right("  hello") == "  hello"

    def test_empty_string(self):
        assert str_mod.trim_right("") == ""

    def test_only_whitespace(self):
        assert str_mod.trim_right("   ") == ""
        assert str_mod.trim_right("\t\t\t") == ""
        assert str_mod.trim_right("\n\n\n") == ""

    def test_preserve_leading_and_internal(self):
        assert str_mod.trim_right("  hello world  ") == "  hello world"
        assert str_mod.trim_right("a  b  c  ") == "a  b  c"

    def test_mixed_whitespace(self):
        assert str_mod.trim_right("hello \t\n") == "hello"
        assert str_mod.trim_right("\r\n\tworld\t\n\r") == "\r\n\tworld"


# --- str.match ---

class TestMatch:
    def test_simple_patterns(self):
        assert str_mod.match("hello", "hello") is True
        assert str_mod.match("test123", "test") is True
        assert str_mod.match("world", "world") is True

    def test_regex_patterns(self):
        assert str_mod.match("hello123", "\\d+") is True
        assert str_mod.match("test", "[a-z]+") is True
        assert str_mod.match("ABC", "[A-Z]+") is True

    def test_non_matches(self):
        assert str_mod.match("hello", "world") is False
        assert str_mod.match("test", "\\d+") is False
        assert str_mod.match("abc", "[A-Z]+") is False

    def test_special_regex_characters(self):
        assert str_mod.match("hello.world", "\\.") is True
        assert str_mod.match("test@example.com", "@") is True
        assert str_mod.match("$100", "\\$") is True

    def test_complex_patterns(self):
        assert str_mod.match("test@example.com", "^[a-z]+@[a-z]+\\.[a-z]+$") is True
        assert str_mod.match("123-456-7890", "^\\d{3}-\\d{3}-\\d{4}$") is True
        assert str_mod.match("hello world", "^hello\\s+world$") is True

    def test_empty_string(self):
        assert str_mod.match("", "") is True
        assert str_mod.match("", "test") is False

    def test_anchors(self):
        assert str_mod.match("hello", "^hello$") is True
        assert str_mod.match("hello world", "^hello") is True
        assert str_mod.match("hello world", "world$") is True
        assert str_mod.match("hello", "^world$") is False

    def test_character_classes(self):
        assert str_mod.match("hello", "[helo]+") is True
        assert str_mod.match("123", "[0-9]+") is True
        assert str_mod.match("ABC", "[^a-z]+") is True

    def test_quantifiers(self):
        assert str_mod.match("hello", "l{2}") is True
        assert str_mod.match("test", "t.*t") is True
        assert str_mod.match("123", "\\d+") is True
        assert str_mod.match("abc", "[a-z]{3}") is True

    def test_case_sensitive(self):
        assert str_mod.match("hello", "HELLO") is False
        assert str_mod.match("HELLO", "hello") is False
        assert str_mod.match("hello", "hello") is True
