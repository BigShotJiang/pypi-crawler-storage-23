"""Tests for string manipulation functions: substring, upper, lower."""

from oakscriptpy import str_ as str_mod


# --- str.substring ---

class TestSubstring:
    def test_extract_with_begin_and_end(self):
        assert str_mod.substring("hello world", 0, 5) == "hello"
        assert str_mod.substring("hello world", 6, 11) == "world"
        assert str_mod.substring("test", 1, 3) == "es"

    def test_from_begin_to_end_when_end_omitted(self):
        assert str_mod.substring("hello world", 6) == "world"
        assert str_mod.substring("test", 2) == "st"
        assert str_mod.substring("hello", 0) == "hello"

    def test_edge_cases(self):
        assert str_mod.substring("test", 0, 0) == ""
        assert str_mod.substring("test", 4) == ""
        # Python slicing returns "" for out-of-range start
        assert str_mod.substring("test", 10) == ""

    def test_negative_indices(self):
        # Python slicing behavior differs from JS substring:
        # Python s[-1:3] = '' for 'hello', JS substring(-1, 3) treats -1 as 0 => 'hel'
        # Python s[1:-1] = 'ell' for 'hello', JS substring(1, -1) treats -1 as 0 => 'h'
        assert str_mod.substring("hello", -1, 3) == ""
        assert str_mod.substring("hello", 1, -1) == "ell"

    def test_begin_greater_than_end(self):
        # Python slicing returns "" when begin > end, unlike JS which swaps
        assert str_mod.substring("hello", 3, 1) == ""


# --- str.upper ---

class TestUpper:
    def test_lowercase_to_uppercase(self):
        assert str_mod.upper("hello") == "HELLO"
        assert str_mod.upper("world") == "WORLD"
        assert str_mod.upper("test") == "TEST"

    def test_already_uppercase(self):
        assert str_mod.upper("HELLO") == "HELLO"
        assert str_mod.upper("WORLD") == "WORLD"

    def test_mixed_case(self):
        assert str_mod.upper("Hello World") == "HELLO WORLD"
        assert str_mod.upper("TeSt") == "TEST"

    def test_empty_string(self):
        assert str_mod.upper("") == ""

    def test_numbers_and_special_characters(self):
        assert str_mod.upper("hello123") == "HELLO123"
        assert str_mod.upper("test@example.com") == "TEST@EXAMPLE.COM"
        assert str_mod.upper("a-b-c") == "A-B-C"

    def test_unicode_characters(self):
        assert str_mod.upper("cafe\u0301") == "CAFE\u0301"
        assert str_mod.upper("na\u00efve") == "NA\u00cfVE"


# --- str.lower ---

class TestLower:
    def test_uppercase_to_lowercase(self):
        assert str_mod.lower("HELLO") == "hello"
        assert str_mod.lower("WORLD") == "world"
        assert str_mod.lower("TEST") == "test"

    def test_already_lowercase(self):
        assert str_mod.lower("hello") == "hello"
        assert str_mod.lower("world") == "world"

    def test_mixed_case(self):
        assert str_mod.lower("Hello World") == "hello world"
        assert str_mod.lower("TeSt") == "test"

    def test_empty_string(self):
        assert str_mod.lower("") == ""

    def test_numbers_and_special_characters(self):
        assert str_mod.lower("HELLO123") == "hello123"
        assert str_mod.lower("TEST@EXAMPLE.COM") == "test@example.com"
        assert str_mod.lower("A-B-C") == "a-b-c"

    def test_unicode_characters(self):
        assert str_mod.lower("CAFE\u0301") == "cafe\u0301"
        assert str_mod.lower("NA\u00cfVE") == "na\u00efve"
