"""Tests for ta.rma, ta.wma, ta.highest, ta.lowest, ta.cum, ta.cross,
ta.rising, ta.falling — ported from new_functions.test.ts."""

import math

import pytest

from oakscriptpy import ta_core


class TestRma:
    def test_should_calculate_relative_moving_average_correctly(self):
        source = [10, 12, 11, 13, 14, 12, 15, 16]
        rma5 = ta_core.rma(source, 5)

        assert len(rma5) == len(source)
        assert math.isnan(rma5[0])
        assert math.isnan(rma5[3])
        # Index 4 should be SMA of first 5 values: (10+12+11+13+14)/5 = 12
        assert rma5[4] == pytest.approx(12, abs=0.1)
        # Index 5: 0.2*12 + 0.8*12 = 12
        assert rma5[5] == pytest.approx(12, abs=0.1)

    def test_should_use_alpha_1_over_length(self):
        source = [100, 110, 105, 115, 120]
        length = 3
        rma3 = ta_core.rma(source, length)

        assert math.isnan(rma3[0])
        assert math.isnan(rma3[1])
        expected_first = (100 + 110 + 105) / 3
        assert rma3[2] == pytest.approx(expected_first, abs=0.01)

    def test_should_handle_insufficient_data(self):
        source = [42]
        rma5 = ta_core.rma(source, 5)

        assert len(rma5) == 1
        assert math.isnan(rma5[0])


class TestWma:
    def test_should_calculate_weighted_moving_average_correctly(self):
        source = [1, 2, 3, 4, 5]
        wma3 = ta_core.wma(source, 3)

        assert len(wma3) == 5
        assert math.isnan(wma3[0])
        assert math.isnan(wma3[1])

        # WMA(3) at index 2: (3*3 + 2*2 + 1*1) / (3+2+1) = (9+4+1)/6 = 14/6 = 2.333
        assert wma3[2] == pytest.approx(2.333, abs=0.01)

    def test_should_give_more_weight_to_recent_values(self):
        source = [10, 10, 10, 10, 20]  # Spike at end
        wma3 = ta_core.wma(source, 3)
        sma3 = ta_core.sma(source, 3)

        assert wma3[4] > sma3[4]

    def test_should_handle_length_of_1(self):
        source = [5, 10, 15]
        wma1 = ta_core.wma(source, 1)

        assert wma1 == source


class TestHighest:
    def test_should_find_highest_value_over_period(self):
        source = [5, 12, 8, 15, 10, 20, 18]
        highest3 = ta_core.highest(source, 3)

        assert highest3[0] == 5   # max(5) expanding window
        assert highest3[1] == 12  # max(5, 12) expanding window
        assert highest3[2] == 12  # max(5, 12, 8)
        assert highest3[3] == 15  # max(12, 8, 15)
        assert highest3[4] == 15  # max(8, 15, 10)
        assert highest3[5] == 20  # max(15, 10, 20)
        assert highest3[6] == 20  # max(10, 20, 18)

    def test_should_handle_all_equal_values(self):
        source = [5, 5, 5, 5, 5]
        highest3 = ta_core.highest(source, 3)

        assert highest3[2] == 5
        assert highest3[4] == 5

    def test_should_ignore_nan_values(self):
        source = [10, float('nan'), 15, 12]
        highest3 = ta_core.highest(source, 3)

        assert highest3[2] == 15  # max(10, NaN, 15) = 15


class TestLowest:
    def test_should_find_lowest_value_over_period(self):
        source = [15, 12, 8, 5, 10, 3, 18]
        lowest3 = ta_core.lowest(source, 3)

        assert lowest3[0] == 15  # min(15) expanding window
        assert lowest3[1] == 12  # min(15, 12) expanding window
        assert lowest3[2] == 8   # min(15, 12, 8)
        assert lowest3[3] == 5   # min(12, 8, 5)
        assert lowest3[4] == 5   # min(8, 5, 10)
        assert lowest3[5] == 3   # min(5, 10, 3)
        assert lowest3[6] == 3   # min(10, 3, 18)

    def test_should_handle_negative_values(self):
        source = [-5, -12, -8, -15]
        lowest3 = ta_core.lowest(source, 3)

        assert lowest3[2] == -12  # min(-5, -12, -8)

    def test_should_ignore_nan_values(self):
        source = [10, float('nan'), 5, 12]
        lowest3 = ta_core.lowest(source, 3)

        assert lowest3[2] == 5  # min(10, NaN, 5) = 5


class TestCum:
    def test_should_calculate_cumulative_sum(self):
        source = [1, 2, 3, 4, 5]
        cum_sum = ta_core.cum(source)

        assert cum_sum == [1, 3, 6, 10, 15]

    def test_should_handle_negative_values(self):
        source = [10, -5, 3, -2]
        cum_sum = ta_core.cum(source)

        assert cum_sum == [10, 5, 8, 6]

    def test_should_handle_single_value(self):
        source = [42]
        cum_sum = ta_core.cum(source)

        assert cum_sum == [42]

    def test_should_handle_decimals(self):
        source = [1.5, 2.5, 3.0]
        cum_sum = ta_core.cum(source)

        assert cum_sum[0] == 1.5
        assert cum_sum[1] == 4.0
        assert cum_sum[2] == 7.0


class TestCross:
    def test_should_detect_upward_cross(self):
        series1 = [1, 2, 3.1, 4, 5]
        series2 = [5, 4, 3, 2, 1]
        crossed = ta_core.cross(series1, series2)

        assert crossed[0] is False
        assert crossed[1] is False
        assert crossed[2] is True   # 3.1 > 3 and 2 <= 4 (crossed up)
        assert crossed[3] is False
        assert crossed[4] is False

    def test_should_detect_downward_cross(self):
        series1 = [5, 4, 2.9, 2, 1]
        series2 = [1, 2, 3, 4, 5]
        crossed = ta_core.cross(series1, series2)

        assert crossed[2] is True  # 2.9 < 3 and 4 >= 2 (crossed down)

    def test_should_not_detect_when_parallel(self):
        series1 = [1, 2, 3, 4, 5]
        series2 = [2, 3, 4, 5, 6]
        crossed = ta_core.cross(series1, series2)

        assert all(v is False for v in crossed)


class TestRising:
    def test_should_detect_rising_values(self):
        source = [1, 2, 3, 4, 5]
        rising3 = ta_core.rising(source, 3)

        assert rising3[0] is False
        assert rising3[1] is False
        assert rising3[2] is False
        assert rising3[3] is True   # 2->3->4 is rising
        assert rising3[4] is True   # 3->4->5 is rising

    def test_should_detect_when_not_rising(self):
        source = [1, 2, 3, 3, 4]  # Flat at index 3
        rising3 = ta_core.rising(source, 3)

        assert rising3[3] is False  # 2->3->3 is not rising (flat)
        assert rising3[4] is False  # 3->3->4 is not rising (had flat)

    def test_should_handle_declining_values(self):
        source = [5, 4, 3, 2, 1]
        rising3 = ta_core.rising(source, 3)

        assert all(v is False for v in rising3)


class TestFalling:
    def test_should_detect_falling_values(self):
        source = [5, 4, 3, 2, 1]
        falling3 = ta_core.falling(source, 3)

        assert falling3[0] is False
        assert falling3[1] is False
        assert falling3[2] is False
        assert falling3[3] is True   # 4->3->2 is falling
        assert falling3[4] is True   # 3->2->1 is falling

    def test_should_detect_when_not_falling(self):
        source = [5, 4, 3, 3, 2]  # Flat at index 3
        falling3 = ta_core.falling(source, 3)

        assert falling3[3] is False  # 4->3->3 is not falling (flat)
        assert falling3[4] is False  # 3->3->2 is not falling (had flat)

    def test_should_handle_rising_values(self):
        source = [1, 2, 3, 4, 5]
        falling3 = ta_core.falling(source, 3)

        assert all(v is False for v in falling3)
