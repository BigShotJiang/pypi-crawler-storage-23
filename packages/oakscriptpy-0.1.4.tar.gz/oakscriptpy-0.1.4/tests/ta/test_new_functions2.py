"""Tests for ta.roc, ta.mom, ta.dev, ta.variance, ta.median — ported from new_functions2.test.ts."""

import math

import pytest

from oakscriptpy import ta_core


class TestRoc:
    def test_should_calculate_rate_of_change_as_percentage(self):
        source = [100, 105, 110, 115, 120]
        roc1 = ta_core.roc(source, 1)

        assert math.isnan(roc1[0])
        assert roc1[1] == pytest.approx(5.0, abs=0.01)      # (105-100)/100 * 100 = 5%
        assert roc1[2] == pytest.approx(4.76, abs=0.01)    # (110-105)/105 * 100 = 4.76%
        assert roc1[3] == pytest.approx(4.55, abs=0.01)    # (115-110)/110 * 100 = 4.55%
        assert roc1[4] == pytest.approx(4.35, abs=0.01)    # (120-115)/115 * 100 = 4.35%

    def test_should_handle_negative_roc(self):
        source = [120, 115, 110, 105, 100]
        roc1 = ta_core.roc(source, 1)

        assert roc1[1] == pytest.approx(-4.17, abs=0.01)   # (115-120)/120 * 100 = -4.17%
        assert roc1[2] == pytest.approx(-4.35, abs=0.01)   # (110-115)/115 * 100 = -4.35%

    def test_should_handle_longer_periods(self):
        source = [100, 105, 110, 115, 120, 125, 130]
        roc3 = ta_core.roc(source, 3)

        assert math.isnan(roc3[0])
        assert math.isnan(roc3[1])
        assert math.isnan(roc3[2])
        assert roc3[3] == pytest.approx(15.0, abs=0.01)    # (115-100)/100 * 100 = 15%
        assert roc3[4] == pytest.approx(14.29, abs=0.01)   # (120-105)/105 * 100 = 14.29%

    def test_should_return_nan_for_division_by_zero(self):
        source = [0, 10, 20]
        roc1 = ta_core.roc(source, 1)

        assert math.isnan(roc1[1])  # oldValue is 0

    def test_should_handle_nan_values(self):
        source = [100, float('nan'), 110]
        roc1 = ta_core.roc(source, 1)

        assert math.isnan(roc1[1])
        assert math.isnan(roc1[2])  # oldValue is NaN


class TestMom:
    def test_should_calculate_momentum_correctly(self):
        source = [100, 105, 110, 115, 120]
        mom1 = ta_core.mom(source, 1)

        assert math.isnan(mom1[0])
        assert mom1[1] == 5    # 105 - 100
        assert mom1[2] == 5    # 110 - 105
        assert mom1[3] == 5    # 115 - 110
        assert mom1[4] == 5    # 120 - 115

    def test_should_handle_negative_momentum(self):
        source = [120, 115, 110, 105, 100]
        mom1 = ta_core.mom(source, 1)

        assert mom1[1] == -5   # 115 - 120
        assert mom1[2] == -5   # 110 - 115

    def test_should_handle_longer_periods(self):
        source = [100, 105, 110, 115, 120, 125, 130]
        mom3 = ta_core.mom(source, 3)

        assert math.isnan(mom3[0])
        assert math.isnan(mom3[1])
        assert math.isnan(mom3[2])
        assert mom3[3] == 15   # 115 - 100
        assert mom3[4] == 15   # 120 - 105
        assert mom3[5] == 15   # 125 - 110

    def test_should_handle_nan_values(self):
        source = [100, float('nan'), 110]
        mom1 = ta_core.mom(source, 1)

        assert math.isnan(mom1[1])
        assert math.isnan(mom1[2])

    def test_should_be_equivalent_to_change(self):
        source = [100, 105, 110, 115, 120]
        mom2 = ta_core.mom(source, 2)
        change2 = ta_core.change(source, 2)

        assert len(mom2) == len(change2)
        for a, b in zip(mom2, change2):
            if math.isnan(a):
                assert math.isnan(b)
            else:
                assert a == b


class TestDev:
    def test_should_calculate_mean_absolute_deviation(self):
        source = [10, 12, 10, 8, 10]  # Mean = 10, deviations: 0, 2, 0, 2, 0
        dev5 = ta_core.dev(source, 5)

        assert math.isnan(dev5[0])
        assert math.isnan(dev5[1])
        assert math.isnan(dev5[2])
        assert math.isnan(dev5[3])
        assert dev5[4] == pytest.approx(0.8, abs=0.01)  # (0+2+0+2+0)/5 = 0.8

    def test_should_handle_varying_values(self):
        source = [1, 2, 3, 4, 5]
        dev3 = ta_core.dev(source, 3)

        assert math.isnan(dev3[0])
        assert math.isnan(dev3[1])
        # At index 2: values are [1,2,3], mean=2, deviations=[1,0,1], dev=0.667
        assert dev3[2] == pytest.approx(0.667, abs=0.01)
        # At index 3: values are [2,3,4], mean=3, deviations=[1,0,1], dev=0.667
        assert dev3[3] == pytest.approx(0.667, abs=0.01)

    def test_should_return_0_for_constant_values(self):
        source = [10, 10, 10, 10, 10]
        dev3 = ta_core.dev(source, 3)

        assert dev3[2] == 0
        assert dev3[4] == 0

    def test_should_handle_nan_values(self):
        source = [10, float('nan'), 12, 10]
        dev3 = ta_core.dev(source, 3)

        # Should calculate based on non-NaN values
        assert dev3[2] is not None


class TestVariance:
    def test_should_calculate_biased_variance_population(self):
        source = [2, 4, 4, 4, 5, 5, 7, 9]  # Mean = 5
        variance8 = ta_core.variance(source, 8, True)

        # Variance = 32/8 = 4
        assert variance8[7] == pytest.approx(4, abs=0.01)

    def test_should_calculate_unbiased_variance_sample(self):
        source = [2, 4, 4, 4, 5, 5, 7, 9]
        variance8 = ta_core.variance(source, 8, False)

        # Sample variance = 32 / 7 = 4.571
        assert variance8[7] == pytest.approx(4.571, abs=0.01)

    def test_should_default_to_biased_variance(self):
        source = [1, 2, 3, 4, 5]
        variance_biased = ta_core.variance(source, 5, True)
        variance_default = ta_core.variance(source, 5)

        assert variance_default[4] == variance_biased[4]

    def test_should_handle_constant_values(self):
        source = [5, 5, 5, 5, 5]
        variance3 = ta_core.variance(source, 3)

        assert variance3[2] == 0
        assert variance3[4] == 0

    def test_should_relate_to_standard_deviation(self):
        source = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        variance5 = ta_core.variance(source, 5)
        stdev5 = ta_core.stdev(source, 5)

        for i in range(4, len(source)):
            if not math.isnan(variance5[i]) and not math.isnan(stdev5[i]):
                assert math.sqrt(variance5[i]) == pytest.approx(stdev5[i], abs=0.01)


class TestMedian:
    def test_should_find_median_of_odd_length_series(self):
        source = [1, 3, 5, 7, 9]
        median5 = ta_core.median(source, 5)

        assert median5[4] == 5  # Middle value of [1,3,5,7,9]

    def test_should_find_median_of_even_length_series(self):
        source = [1, 2, 3, 4]
        median4 = ta_core.median(source, 4)

        assert median4[3] == 2.5  # Average of 2 and 3

    def test_should_handle_unsorted_input(self):
        source = [5, 1, 9, 3, 7]
        median5 = ta_core.median(source, 5)

        # Sorted: [1,3,5,7,9], median = 5
        assert median5[4] == 5

    def test_should_return_median_over_rolling_window(self):
        source = [1, 2, 3, 4, 5, 6, 7]
        median3 = ta_core.median(source, 3)

        assert math.isnan(median3[0])
        assert math.isnan(median3[1])
        assert median3[2] == 2  # Median of [1,2,3]
        assert median3[3] == 3  # Median of [2,3,4]
        assert median3[4] == 4  # Median of [3,4,5]

    def test_should_ignore_nan_values(self):
        source = [1, float('nan'), 3, 5, 7]
        median3 = ta_core.median(source, 3)

        # At index 4: [3, 5, 7]
        assert median3[4] == 5

    def test_should_be_more_robust_than_mean(self):
        normal = [10, 10, 10, 10, 10]
        with_outlier = [10, 10, 10, 10, 100]

        median_normal = ta_core.median(normal, 5)
        median_outlier = ta_core.median(with_outlier, 5)
        sma_normal = ta_core.sma(normal, 5)
        sma_outlier = ta_core.sma(with_outlier, 5)

        assert median_normal[4] == 10
        assert median_outlier[4] == 10  # Still 10
        assert sma_outlier[4] == 28     # Heavily affected: (10+10+10+10+100)/5 = 28
