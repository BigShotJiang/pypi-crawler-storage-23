"""Tests for ta.mode, ta.percentile_linear_interpolation, ta.percentile_nearest_rank,
ta.rci, ta.pivot_point_levels — ported from new_ta_functions.test.ts."""

import math

import pytest

from oakscriptpy import ta_core


class TestMode:
    def test_should_return_the_most_frequent_value(self):
        values = [1, 2, 2, 3, 3, 3, 4, 4, 5]
        result = ta_core.mode(values, len(values))
        assert result[len(values) - 1] == 3

    def test_should_return_smallest_value_when_multiple_modes_exist(self):
        values = [1, 1, 2, 2, 3, 3]
        result = ta_core.mode(values, len(values))
        assert result[len(values) - 1] == 1

    def test_should_handle_rolling_window(self):
        values = [1, 2, 3, 3, 3, 4, 5, 5, 5, 5]
        result = ta_core.mode(values, 4)
        assert result[6] == 3  # Window [3,3,4,5] -> mode is 3
        assert result[9] == 5  # Window [5,5,5,5] -> mode is 5

    def test_should_ignore_nan_values(self):
        values = [1, float('nan'), 2, 2, float('nan'), 3]
        result = ta_core.mode(values, len(values))
        assert result[len(values) - 1] == 2


class TestPercentileLinearInterpolation:
    def test_should_calculate_50th_percentile_median(self):
        values = [1, 2, 3, 4, 5]
        result = ta_core.percentile_linear_interpolation(values, len(values), 50)
        assert result[len(values) - 1] == 3

    def test_should_use_linear_interpolation(self):
        values = [1, 2, 3, 4]
        result = ta_core.percentile_linear_interpolation(values, len(values), 50)
        # 50th percentile of [1,2,3,4] = 2.5 (interpolated between 2 and 3)
        assert result[len(values) - 1] == 2.5

    def test_should_handle_25th_and_75th_percentiles(self):
        values = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        p25 = ta_core.percentile_linear_interpolation(values, len(values), 25)
        p75 = ta_core.percentile_linear_interpolation(values, len(values), 75)
        assert p25[len(values) - 1] == pytest.approx(3.25)
        assert p75[len(values) - 1] == pytest.approx(7.75)

    def test_should_return_nan_if_any_value_is_nan(self):
        values = [1, 2, float('nan'), 4, 5]
        result = ta_core.percentile_linear_interpolation(values, len(values), 50)
        assert math.isnan(result[len(values) - 1])


class TestPercentileNearestRank:
    def test_should_calculate_50th_percentile(self):
        values = [1, 2, 3, 4, 5]
        result = ta_core.percentile_nearest_rank(values, len(values), 50)
        assert result[len(values) - 1] == 3

    def test_should_always_return_a_member_of_input_data(self):
        values = [1, 2, 3, 4]
        result = ta_core.percentile_nearest_rank(values, len(values), 50)
        # Should be 2 or 3, not 2.5
        assert result[len(values) - 1] in [2, 3]

    def test_should_handle_100th_percentile_as_largest_value(self):
        values = [1, 2, 3, 4, 5]
        result = ta_core.percentile_nearest_rank(values, len(values), 100)
        assert result[len(values) - 1] == 5

    def test_should_ignore_nan_values(self):
        values = [1, float('nan'), 2, 3, float('nan'), 4, 5]
        result = ta_core.percentile_nearest_rank(values, len(values), 50)
        assert result[len(values) - 1] == 3


class TestRci:
    def test_should_return_100_for_perfectly_increasing_series(self):
        values = [1, 2, 3, 4, 5]
        result = ta_core.rci(values, len(values))
        assert result[len(values) - 1] == pytest.approx(100, abs=1e-5)

    def test_should_return_minus_100_for_perfectly_decreasing_series(self):
        values = [5, 4, 3, 2, 1]
        result = ta_core.rci(values, len(values))
        assert result[len(values) - 1] == pytest.approx(-100, abs=1e-5)

    def test_should_return_value_between_minus_100_and_100_for_mixed_data(self):
        values = [1, 5, 2, 4, 3]
        result = ta_core.rci(values, len(values))
        assert result[len(values) - 1] > -100
        assert result[len(values) - 1] < 100

    def test_should_handle_rolling_window(self):
        values = [1, 2, 3, 4, 5, 4, 3, 2, 1]
        result = ta_core.rci(values, 5)
        assert result[4] == pytest.approx(100, abs=1e-5)   # [1,2,3,4,5]
        assert result[8] == pytest.approx(-100, abs=1e-5)   # [5,4,3,2,1]

    def test_should_return_nan_if_any_value_is_nan(self):
        values = [1, 2, float('nan'), 4, 5]
        result = ta_core.rci(values, len(values))
        assert math.isnan(result[len(values) - 1])


class TestPivotPointLevels:
    def test_should_calculate_traditional_pivot_points(self):
        high = [100, 105, 110, 108, 112]
        low = [95, 100, 105, 103, 107]
        close = [98, 103, 108, 106, 110]
        anchor = [True, False, False, False, False]

        pivots = ta_core.pivot_point_levels('Traditional', anchor, False, high, low, close)

        # P = (H + L + C) / 3 = (100 + 95 + 98) / 3 = 97.67
        p = pivots[0][4]
        assert p == pytest.approx(97.67, abs=0.01)

        # R1 = 2*P - L = 2*97.67 - 95 = 100.33
        r1 = pivots[1][4]
        assert r1 == pytest.approx(100.33, abs=0.01)

        # S1 = 2*P - H = 2*97.67 - 100 = 95.33
        s1 = pivots[2][4]
        assert s1 == pytest.approx(95.33, abs=0.01)

    def test_should_calculate_fibonacci_pivot_points(self):
        high = [100, 105]
        low = [90, 95]
        close = [95, 100]
        anchor = [True, False]

        pivots = ta_core.pivot_point_levels('Fibonacci', anchor, False, high, low, close)

        # P = (100 + 90 + 95) / 3 = 95
        assert pivots[0][1] == pytest.approx(95, abs=0.01)

        # R1 = P + 0.382 * (H - L) = 95 + 0.382 * 10 = 98.82
        assert pivots[1][1] == pytest.approx(98.82, abs=0.01)

    def test_should_calculate_dm_pivot_points_with_only_p_r1_s1(self):
        high = [100]
        low = [90]
        close = [95]
        open_ = [92]
        anchor = [True]

        pivots = ta_core.pivot_point_levels('DM', anchor, False, high, low, close, open_)

        # DM formula: x = H + L + 2C + O
        x = 100 + 90 + (2 * 95) + 92  # 472
        assert pivots[0][0] == pytest.approx(x / 5, abs=0.01)    # P = 94.4
        assert pivots[1][0] == pytest.approx(x / 2 - 90, abs=0.01)   # R1 = 146
        assert pivots[2][0] == pytest.approx(x / 2 - 100, abs=0.01)  # S1 = 136

        # R2-R5, S2-S5 should be NaN
        assert math.isnan(pivots[3][0])
        assert math.isnan(pivots[4][0])

    def test_should_throw_error_for_woodie_with_developing_true(self):
        high = [100]
        low = [90]
        close = [95]
        anchor = [True]

        with pytest.raises(ValueError, match='Woodie type cannot use developing=True'):
            ta_core.pivot_point_levels('Woodie', anchor, True, high, low, close)

    def test_should_handle_developing_mode(self):
        high = [100, 105, 110]
        low = [90, 95, 100]
        close = [95, 100, 105]
        anchor = [True, False, False]

        pivots_developing = ta_core.pivot_point_levels('Traditional', anchor, True, high, low, close)
        pivots_non_developing = ta_core.pivot_point_levels('Traditional', anchor, False, high, low, close)

        # Developing should recalculate with max/min since anchor
        # Non-developing should use values at anchor point
        assert pivots_developing[0][2] != pivots_non_developing[0][2]
