"""Tests for ta.ichimoku — ported from ichimoku.test.ts."""

import math

from oakscriptpy import ta_core


# Sample OHLC data for testing
HIGH = [
    110, 112, 115, 114, 116, 118, 120, 119, 121, 123,
    125, 124, 126, 128, 130, 129, 131, 133, 135, 134,
    136, 138, 140, 139, 141, 143, 145, 144, 146, 148,
    150, 149, 151, 153, 155, 154, 156, 158, 160, 159,
    161, 163, 165, 164, 166, 168, 170, 169, 171, 173,
    175, 174, 176, 178, 180, 179, 181, 183, 185, 184,
]

LOW = [
    100, 102, 105, 104, 106, 108, 110, 109, 111, 113,
    115, 114, 116, 118, 120, 119, 121, 123, 125, 124,
    126, 128, 130, 129, 131, 133, 135, 134, 136, 138,
    140, 139, 141, 143, 145, 144, 146, 148, 150, 149,
    151, 153, 155, 154, 156, 158, 160, 159, 161, 163,
    165, 164, 166, 168, 170, 169, 171, 173, 175, 174,
]

CLOSE = [
    105, 107, 110, 109, 111, 113, 115, 114, 116, 118,
    120, 119, 121, 123, 125, 124, 126, 128, 130, 129,
    131, 133, 135, 134, 136, 138, 140, 139, 141, 143,
    145, 144, 146, 148, 150, 149, 151, 153, 155, 154,
    156, 158, 160, 159, 161, 163, 165, 164, 166, 168,
    170, 169, 171, 173, 175, 174, 176, 178, 180, 179,
]


class TestIchimoku:
    def test_should_return_5_series_with_correct_length(self):
        tenkan, kijun, senkou_a, senkou_b, chikou = ta_core.ichimoku(9, 26, 52, 26, HIGH, LOW, CLOSE)

        assert len(tenkan) == 60
        assert len(kijun) == 60
        assert len(senkou_a) == 60
        assert len(senkou_b) == 60
        assert len(chikou) == 60

    def test_should_calculate_tenkan_sen_correctly(self):
        tenkan, *_ = ta_core.ichimoku(9, 26, 52, 26, HIGH, LOW, CLOSE)

        # With expanding window, tenkan has values from bar 0
        # Bar 0: (110 + 100) / 2 = 105
        assert tenkan[0] == 105

        # At index 8 (full window): max(HIGH[0..8])=121, min(LOW[0..8])=100
        # Tenkan = (121 + 100) / 2 = 110.5
        assert tenkan[8] == 110.5

    def test_should_calculate_kijun_sen_correctly(self):
        _, kijun, *_ = ta_core.ichimoku(9, 26, 52, 26, HIGH, LOW, CLOSE)

        # With expanding window, kijun has values from bar 0
        # Bar 0: (110 + 100) / 2 = 105
        assert kijun[0] == 105

        # At index 25 (full window): highest high in bars 0-25 = 143, lowest low = 100
        # Kijun = (143 + 100) / 2 = 121.5
        assert kijun[25] == 121.5

    def test_should_calculate_senkou_span_a_with_correct_displacement(self):
        tenkan, kijun, senkou_a, *_ = ta_core.ichimoku(9, 26, 52, 26, HIGH, LOW, CLOSE)

        # First 26 values should be NaN (displaced forward)
        for i in range(26):
            assert math.isnan(senkou_a[i])

        # Senkou Span A at index 51 uses tenkan[25] and kijun[25]
        source_index = 51 - 26  # = 25
        if not math.isnan(tenkan[source_index]) and not math.isnan(kijun[source_index]):
            assert senkou_a[51] == (tenkan[source_index] + kijun[source_index]) / 2

    def test_should_calculate_senkou_span_b_with_correct_displacement(self):
        _, _, _, senkou_b, _ = ta_core.ichimoku(9, 26, 52, 26, HIGH, LOW, CLOSE)

        # First 26 values should be NaN (displacement)
        for i in range(26):
            assert math.isnan(senkou_b[i])

    def test_should_calculate_chikou_span_with_correct_backward_offset(self):
        _, _, _, _, chikou = ta_core.ichimoku(9, 26, 52, 26, HIGH, LOW, CLOSE)

        # Last 26 values should be NaN
        for i in range(60 - 26, 60):
            assert math.isnan(chikou[i])

        # At index 0, chikou should equal close[26]
        assert chikou[0] == CLOSE[26]

        # At index 10, chikou should equal close[36]
        assert chikou[10] == CLOSE[36]

    def test_should_handle_default_parameters(self):
        tenkan, kijun, senkou_a, senkou_b, chikou = ta_core.ichimoku(9, 26, 52, 26, HIGH, LOW, CLOSE)

        assert len(tenkan) == len(HIGH)
        assert len(kijun) == len(HIGH)
        assert len(senkou_a) == len(HIGH)
        assert len(senkou_b) == len(HIGH)
        assert len(chikou) == len(HIGH)

        valid_tenkan = [v for v in tenkan if not math.isnan(v)]
        valid_kijun = [v for v in kijun if not math.isnan(v)]
        assert len(valid_tenkan) > 0
        assert len(valid_kijun) > 0

    def test_should_return_nan_for_insufficient_data_periods(self):
        short_high = [110, 112, 115, 114, 116, 118, 120, 119, 121, 123]
        short_low = [100, 102, 105, 104, 106, 108, 110, 109, 111, 113]
        short_close = [105, 107, 110, 109, 111, 113, 115, 114, 116, 118]

        tenkan, kijun, senkou_a, senkou_b, chikou = ta_core.ichimoku(9, 26, 52, 26, short_high, short_low, short_close)

        # With expanding window, tenkan and kijun have values even with short data
        assert not math.isnan(tenkan[8])
        assert not math.isnan(tenkan[9])
        assert not math.isnan(kijun[0])

        # All senkouA should be NaN (displacement 26 > data length 10)
        for v in senkou_a:
            assert math.isnan(v)

        # All senkouB should be NaN
        for v in senkou_b:
            assert math.isnan(v)

    def test_should_handle_edge_cases_with_short_data_arrays(self):
        short_high = [110, 112, 115]
        short_low = [100, 102, 105]
        short_close = [105, 107, 110]

        tenkan, kijun, senkou_a, senkou_b, chikou = ta_core.ichimoku(9, 26, 52, 26, short_high, short_low, short_close)

        # With expanding window, tenkan and kijun have values
        assert tenkan[0] == (110 + 100) / 2
        assert kijun[0] == (110 + 100) / 2

        # senkou_a/b still NaN (displacement 26 > data length 3)
        for v in senkou_a:
            assert math.isnan(v)
        for v in senkou_b:
            assert math.isnan(v)
        # chikou still NaN (offset 26 > data length 3)
        for v in chikou:
            assert math.isnan(v)

    def test_should_work_with_custom_parameters(self):
        tenkan, kijun, senkou_a, senkou_b, chikou = ta_core.ichimoku(5, 10, 20, 10, HIGH, LOW, CLOSE)

        # With period 5, tenkan should have valid values from index 4
        assert not math.isnan(tenkan[4])

        # With period 10, kijun should have valid values from index 9
        assert not math.isnan(kijun[9])

        # At index 19, senkouA uses tenkan[9] and kijun[9]
        assert not math.isnan(senkou_a[19])

        # Chikou with displacement 10 should have NaN in last 10 values
        assert not math.isnan(chikou[49])  # close[59]
        assert math.isnan(chikou[50])  # would need close[60]

    def test_should_produce_consistent_results_across_calls(self):
        result1 = ta_core.ichimoku(9, 26, 52, 26, HIGH, LOW, CLOSE)
        result2 = ta_core.ichimoku(9, 26, 52, 26, HIGH, LOW, CLOSE)

        for i in range(5):
            for j in range(len(result1[i])):
                if math.isnan(result1[i][j]):
                    assert math.isnan(result2[i][j])
                else:
                    assert result1[i][j] == result2[i][j]

    def test_should_handle_empty_arrays(self):
        tenkan, kijun, senkou_a, senkou_b, chikou = ta_core.ichimoku(9, 26, 52, 26, [], [], [])

        assert len(tenkan) == 0
        assert len(kijun) == 0
        assert len(senkou_a) == 0
        assert len(senkou_b) == 0
        assert len(chikou) == 0

    def test_should_calculate_donchian_channel_midpoint_correctly(self):
        simple_high = [10, 12, 11, 13, 15, 14, 16, 18, 17, 19]
        simple_low = [8, 9, 8, 10, 12, 11, 13, 15, 14, 16]
        simple_close = [9, 11, 10, 12, 14, 13, 15, 17, 16, 18]

        tenkan, *_ = ta_core.ichimoku(3, 5, 10, 5, simple_high, simple_low, simple_close)

        # At index 2: max(10, 12, 11)=12, min(8, 9, 8)=8, tenkan=(12+8)/2=10
        assert tenkan[2] == 10

        # At index 5: max(13, 15, 14)=15, min(10, 12, 11)=10, tenkan=(15+10)/2=12.5
        assert tenkan[5] == 12.5
