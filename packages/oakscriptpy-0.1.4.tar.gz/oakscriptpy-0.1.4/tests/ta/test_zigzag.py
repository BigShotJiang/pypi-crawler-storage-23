"""Tests for ta.zigzag — ported from zigzag.test.ts."""

import math

import pytest

from oakscriptpy import ta_core


class TestZigzagBasicFunctionality:
    def test_should_identify_pivot_highs_correctly(self):
        high = [100, 105, 110, 115, 120, 118, 115, 112, 110, 115, 120, 125, 130]
        low = [98, 103, 108, 113, 118, 116, 113, 110, 108, 113, 118, 123, 128]

        zigzag, direction, is_pivot = ta_core.zigzag(5, 3, 2, None, high, low)

        assert len(zigzag) == len(high)
        assert len(direction) == len(high)
        assert len(is_pivot) == len(high)

        pivot_count = sum(1 for p in is_pivot if p)
        assert pivot_count > 0

    def test_should_identify_pivot_lows_correctly(self):
        high = [120, 115, 110, 105, 100, 105, 110, 115, 120, 115, 110, 105, 100]
        low = [118, 113, 108, 103, 98, 103, 108, 113, 118, 113, 108, 103, 98]

        zigzag, direction, is_pivot = ta_core.zigzag(5, 3, 2, None, high, low)

        pivot_count = sum(1 for p in is_pivot if p)
        assert pivot_count > 0

    def test_should_respect_minimum_deviation_threshold(self):
        high = [100, 101, 102, 103, 104, 103, 102, 101, 100, 101, 102, 103, 104]
        low = [99, 100, 101, 102, 103, 102, 101, 100, 99, 100, 101, 102, 103]

        zigzag, _, is_pivot = ta_core.zigzag(10, 3, 2, None, high, low)

        non_nan_count = sum(1 for v in zigzag if not math.isnan(v))
        assert non_nan_count <= 3

    def test_should_respect_minimum_depth_between_pivots(self):
        high = [100, 120, 100, 120, 100, 120, 100, 120]
        low = [90, 110, 90, 110, 90, 110, 90, 110]

        _, _, is_pivot = ta_core.zigzag(5, 5, 2, None, high, low)

        pivot_indices = [i for i, p in enumerate(is_pivot) if p]

        if len(pivot_indices) > 1:
            for i in range(1, len(pivot_indices)):
                spacing = pivot_indices[i] - pivot_indices[i - 1]
                assert spacing >= 1

    def test_should_return_nan_for_non_pivot_bars(self):
        high = [100, 110, 120, 115, 105, 100, 110, 120, 125, 130]
        low = [95, 105, 115, 110, 100, 95, 105, 115, 120, 125]

        zigzag, *_ = ta_core.zigzag(5, 3, 2, None, high, low)

        nan_count = sum(1 for v in zigzag if math.isnan(v))
        assert nan_count > len(zigzag) / 2


class TestZigzagDeviationCalculation:
    def test_should_filter_out_small_price_movements(self):
        high = [100, 102, 100, 102, 100, 102, 100, 102, 100, 102]
        low = [99, 101, 99, 101, 99, 101, 99, 101, 99, 101]

        zigzag, *_ = ta_core.zigzag(5, 3, 2, None, high, low)

        non_nan_count = sum(1 for v in zigzag if not math.isnan(v))
        assert non_nan_count <= 2

    def test_should_detect_pivots_when_deviation_exceeds_threshold(self):
        high = [100, 105, 110, 108, 105, 100, 105, 110, 115, 120]
        low = [95, 100, 105, 103, 100, 95, 100, 105, 110, 115]

        _, _, is_pivot = ta_core.zigzag(5, 2, 1, None, high, low)

        pivot_count = sum(1 for p in is_pivot if p)
        assert pivot_count >= 1

    def test_should_calculate_percentage_deviation_correctly(self):
        high = [100, 103, 106, 109, 112, 109, 106, 103, 100, 103, 106, 109, 112]
        low = [98, 101, 104, 107, 110, 107, 104, 101, 98, 101, 104, 107, 110]

        zigzag10, *_ = ta_core.zigzag(15, 3, 2, None, high, low)
        zigzag5, *_ = ta_core.zigzag(5, 3, 2, None, high, low)

        pivots10 = sum(1 for v in zigzag10 if not math.isnan(v))
        pivots5 = sum(1 for v in zigzag5 if not math.isnan(v))

        assert pivots5 >= pivots10


class TestZigzagDirectionTracking:
    def test_should_return_1_for_uptrend(self):
        high = [100, 105, 110, 115, 120, 125, 130, 135, 140, 145]
        low = [95, 100, 105, 110, 115, 120, 125, 130, 135, 140]

        _, direction, _ = ta_core.zigzag(5, 2, 1, None, high, low)

        last_direction = direction[-1]
        assert last_direction == 1

    def test_should_return_minus_1_for_downtrend(self):
        high = [145, 140, 135, 130, 125, 120, 115, 110, 105, 100]
        low = [140, 135, 130, 125, 120, 115, 110, 105, 100, 95]

        _, direction, _ = ta_core.zigzag(5, 2, 1, None, high, low)

        last_direction = direction[-1]
        assert last_direction == -1

    def test_should_switch_direction_at_confirmed_pivots(self):
        high = [120, 115, 110, 105, 100, 105, 110, 115, 120, 125]
        low = [115, 110, 105, 100, 95, 100, 105, 110, 115, 120]

        _, direction, is_pivot = ta_core.zigzag(5, 2, 1, None, high, low)

        last_pivot_direction = 0
        for i in range(len(is_pivot)):
            if is_pivot[i]:
                if last_pivot_direction != 0:
                    assert direction[i] != 0
                last_pivot_direction = direction[i]


class TestZigzagRepaintBehavior:
    def test_should_update_last_pivot_when_higher_high_forms(self):
        high1 = [100, 105, 110, 115, 120, 115, 125, 120, 115, 110]
        low1 = [95, 100, 105, 110, 115, 110, 120, 115, 110, 105]

        zigzag1, *_ = ta_core.zigzag(5, 2, 1, None, high1, low1)

        pivot_indices = [i for i, v in enumerate(zigzag1) if not math.isnan(v)]
        assert len(pivot_indices) > 0

    def test_should_update_last_pivot_when_lower_low_forms(self):
        high = [120, 115, 110, 105, 100, 105, 95, 100, 105, 110]
        low = [115, 110, 105, 100, 95, 100, 90, 95, 100, 105]

        zigzag, *_ = ta_core.zigzag(5, 2, 1, None, high, low)

        pivot_indices = [i for i, v in enumerate(zigzag) if not math.isnan(v)]
        assert len(pivot_indices) > 0


class TestZigzagEdgeCases:
    def test_should_handle_insufficient_data(self):
        high = [100, 110]
        low = [95, 105]

        zigzag, direction, is_pivot = ta_core.zigzag(5, 10, 3, None, high, low)

        assert len(zigzag) == len(high)
        assert len(direction) == len(high)
        assert len(is_pivot) == len(high)

    def test_should_handle_flat_prices(self):
        high = [100, 100, 100, 100, 100, 100, 100, 100, 100, 100]
        low = [100, 100, 100, 100, 100, 100, 100, 100, 100, 100]

        zigzag, *_ = ta_core.zigzag(5, 3, 2, None, high, low)

        pivot_count = sum(1 for v in zigzag if not math.isnan(v))
        assert pivot_count <= 1

    def test_should_handle_monotonically_increasing_prices(self):
        high = [100, 105, 110, 115, 120, 125, 130, 135, 140, 145, 150, 155, 160]
        low = [95, 100, 105, 110, 115, 120, 125, 130, 135, 140, 145, 150, 155]

        zigzag, direction, _ = ta_core.zigzag(5, 2, 1, None, high, low)

        assert len(zigzag) == len(high)
        last_dir = direction[-1]
        assert last_dir == 1

    def test_should_handle_monotonically_decreasing_prices(self):
        high = [160, 155, 150, 145, 140, 135, 130, 125, 120, 115, 110, 105, 100]
        low = [155, 150, 145, 140, 135, 130, 125, 120, 115, 110, 105, 100, 95]

        zigzag, direction, _ = ta_core.zigzag(5, 2, 1, None, high, low)

        assert len(zigzag) == len(high)
        last_dir = direction[-1]
        assert last_dir == -1

    def test_should_handle_single_source_mode(self):
        source = [100, 110, 105, 115, 108, 120, 112, 125, 118, 130]

        zigzag, direction, is_pivot = ta_core.zigzag(5, 2, 1, source)

        assert len(zigzag) == len(source)
        assert len(direction) == len(source)
        assert len(is_pivot) == len(source)

    def test_should_handle_high_low_source_mode(self):
        high = [105, 115, 110, 120, 115, 125, 120, 130, 125, 135]
        low = [95, 105, 100, 110, 105, 115, 110, 120, 115, 125]

        zigzag, direction, is_pivot = ta_core.zigzag(5, 2, 1, None, high, low)

        assert len(zigzag) == len(high)
        assert len(direction) == len(high)
        assert len(is_pivot) == len(high)


class TestZigzagParameterValidation:
    def test_should_use_default_values_when_not_provided(self):
        high = [100, 110, 120, 115, 105, 100, 110, 120, 130, 140, 135, 125, 115, 105, 100]
        low = [95, 105, 115, 110, 100, 95, 105, 115, 125, 135, 130, 120, 110, 100, 95]

        zigzag, *_ = ta_core.zigzag(high=high, low=low)

        assert len(zigzag) == len(high)

    def test_should_handle_deviation_0(self):
        high = [100, 101, 100, 101, 100, 101, 100, 101, 100, 101]
        low = [99, 100, 99, 100, 99, 100, 99, 100, 99, 100]

        zigzag0, *_ = ta_core.zigzag(0, 2, 1, None, high, low)
        zigzag5, *_ = ta_core.zigzag(5, 2, 1, None, high, low)

        pivots0 = sum(1 for v in zigzag0 if not math.isnan(v))
        pivots5 = sum(1 for v in zigzag5 if not math.isnan(v))
        assert pivots0 >= pivots5

    def test_should_handle_very_large_deviation_values(self):
        high = [100, 150, 100, 150, 100, 150, 100, 150, 100, 150]
        low = [50, 100, 50, 100, 50, 100, 50, 100, 50, 100]

        zigzag, *_ = ta_core.zigzag(100, 2, 1, None, high, low)

        pivot_count = sum(1 for v in zigzag if not math.isnan(v))
        assert pivot_count <= 2

    def test_should_throw_error_when_no_source_provided(self):
        with pytest.raises(ValueError):
            ta_core.zigzag(5, 10, 3)

    def test_should_throw_error_when_high_low_lengths_mismatch(self):
        high = [100, 110, 120]
        low = [95, 105]

        with pytest.raises(ValueError):
            ta_core.zigzag(5, 3, 2, None, high, low)


class TestZigzagRealWorldScenarios:
    def test_should_identify_w_bottom_pattern(self):
        high = [120, 115, 110, 105, 110, 115, 110, 105, 110, 115, 120, 125, 130]
        low = [115, 110, 105, 100, 105, 110, 105, 100, 105, 110, 115, 120, 125]

        _, _, is_pivot = ta_core.zigzag(5, 2, 1, None, high, low)

        pivot_count = sum(1 for p in is_pivot if p)
        assert pivot_count >= 2

    def test_should_identify_m_top_pattern(self):
        high = [100, 105, 110, 115, 120, 115, 110, 115, 120, 115, 110, 105, 100]
        low = [95, 100, 105, 110, 115, 110, 105, 110, 115, 110, 105, 100, 95]

        _, _, is_pivot = ta_core.zigzag(5, 2, 1, None, high, low)

        pivot_count = sum(1 for p in is_pivot if p)
        assert pivot_count >= 2

    def test_should_handle_volatile_price_action(self):
        high = [100, 120, 95, 130, 90, 140, 85, 150, 80, 160]
        low = [90, 100, 85, 110, 80, 120, 75, 130, 70, 140]

        zigzag, direction, is_pivot = ta_core.zigzag(10, 2, 1, None, high, low)

        assert len(zigzag) == len(high)
        assert len(direction) == len(high)
        assert len(is_pivot) == len(high)

        pivot_count = sum(1 for p in is_pivot if p)
        assert pivot_count > 0
