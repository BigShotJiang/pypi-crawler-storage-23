"""Tests for ta.rsi — ported from rsi.test.ts."""

import math

from oakscriptpy import ta_core


class TestRsi:
    def test_should_calculate_rsi_correctly_for_basic_data(self):
        source = [44, 44.34, 44.09, 43.61, 44.33, 44.83, 45.10, 45.42, 45.84, 46.08,
                  45.89, 46.03, 45.61, 46.28, 46.28, 46.00, 46.03, 46.41, 46.22, 45.64]
        rsi14 = ta_core.rsi(source, 14)

        assert len(rsi14) == len(source)

        # First value should be NaN (no previous value to calculate change)
        assert math.isnan(rsi14[0])

        # RSI values should be between 0 and 100
        for i in range(14, len(rsi14)):
            if not math.isnan(rsi14[i]):
                assert rsi14[i] >= 0
                assert rsi14[i] <= 100

    def test_should_return_100_for_all_gains_no_losses(self):
        source = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25]
        rsi14 = ta_core.rsi(source, 14)

        assert rsi14[15] > 90

    def test_should_return_low_rsi_for_all_losses_no_gains(self):
        source = [25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10]
        rsi14 = ta_core.rsi(source, 14)

        assert rsi14[15] < 10

    def test_should_handle_constant_values_no_losses_rsi_100(self):
        source = [50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50]
        rsi14 = ta_core.rsi(source, 14)

        # Per PineScript v6: when avgLosses = 0, RSI = 100
        assert rsi14[15] == 100

    def test_should_work_with_different_periods(self):
        source = [10, 12, 11, 13, 14, 12, 15, 16, 14, 17, 18, 16, 19, 20]

        rsi5 = ta_core.rsi(source, 5)
        rsi10 = ta_core.rsi(source, 10)

        assert len(rsi5) == len(source)
        assert len(rsi10) == len(source)

        # Shorter period RSI should be more volatile (different values)
        assert rsi5[13] != rsi10[13]

    def test_should_handle_typical_trading_data(self):
        source = [100, 102, 101, 103, 102, 104, 106, 105, 107, 109,
                  108, 110, 109, 111, 110, 112, 111, 113, 112, 114]
        rsi14 = ta_core.rsi(source, 14)

        assert math.isnan(rsi14[0])
        assert not math.isnan(rsi14[15])

        # For this uptrend data, RSI should be above 50
        assert rsi14[19] > 50

    def test_should_use_rma_for_smoothing(self):
        source = [44, 44.34, 44.09, 43.61, 44.33, 44.83, 45.10, 45.42,
                  45.84, 46.08, 45.89, 46.03, 45.61, 46.28, 46.28]
        rsi14 = ta_core.rsi(source, 14)

        assert len(rsi14) == len(source)
        for i in range(14, len(rsi14)):
            if not math.isnan(rsi14[i]):
                assert rsi14[i] >= 0
                assert rsi14[i] <= 100

    def test_should_handle_nan_values_in_source(self):
        source = [10, 11, float('nan'), 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25]
        rsi14 = ta_core.rsi(source, 14)

        assert len(rsi14) == len(source)

    def test_should_match_pinescript_v6_rsi_formula(self):
        source = [10, 11, 12, 11, 12, 13, 12, 13, 14, 13, 14, 15, 14, 15, 16]
        rsi14 = ta_core.rsi(source, 14)

        assert math.isnan(rsi14[0])
        assert rsi14[14] > 50
        assert rsi14[14] < 100

    def test_should_handle_short_data_series(self):
        source = [10, 11, 12]
        rsi5 = ta_core.rsi(source, 5)

        assert len(rsi5) == 3
        assert math.isnan(rsi5[0])

    def test_should_handle_oscillating_values(self):
        source = [10, 12, 10, 12, 10, 12, 10, 12, 10, 12,
                  10, 12, 10, 12, 10, 12, 10, 12, 10, 12]
        rsi14 = ta_core.rsi(source, 14)

        assert rsi14[19] > 40
        assert rsi14[19] < 60

    def test_should_identify_overbought_conditions(self):
        source = [100, 102, 104, 106, 108, 110, 112, 114, 116, 118,
                  120, 122, 124, 126, 128, 130, 132, 134, 136, 138]
        rsi14 = ta_core.rsi(source, 14)

        assert rsi14[19] > 70

    def test_should_identify_oversold_conditions(self):
        source = [140, 138, 136, 134, 132, 130, 128, 126, 124, 122,
                  120, 118, 116, 114, 112, 110, 108, 106, 104, 102]
        rsi14 = ta_core.rsi(source, 14)

        assert rsi14[19] < 30

    def test_should_handle_single_large_spike(self):
        source = [100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
                  100, 100, 100, 100, 150, 100, 100, 100, 100, 100]
        rsi14 = ta_core.rsi(source, 14)

        assert rsi14[14] > 50
        assert rsi14[19] < rsi14[14]

    def test_should_handle_length_of_1(self):
        source = [10, 11, 12, 13, 14]
        rsi1 = ta_core.rsi(source, 1)

        assert len(rsi1) == 5
        assert math.isnan(rsi1[0])

    def test_should_produce_smooth_values_with_rma_smoothing(self):
        source = [100, 102, 101, 103, 102, 104, 103, 105, 104, 106,
                  105, 107, 106, 108, 107, 109, 108, 110, 109, 111]
        rsi14 = ta_core.rsi(source, 14)

        max_change = 0
        for i in range(16, len(rsi14)):
            if not math.isnan(rsi14[i]) and not math.isnan(rsi14[i - 1]):
                change = abs(rsi14[i] - rsi14[i - 1])
                max_change = max(max_change, change)

        assert max_change < 30
