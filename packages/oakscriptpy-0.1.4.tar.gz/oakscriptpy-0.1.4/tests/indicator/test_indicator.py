"""Tests for the indicator function and related utilities.

Ported from: D:/WebstormProjects/oakscriptJS/tests/indicator/indicator.test.ts
"""

import math

import pytest

from oakscriptpy.indicator import (
    indicator,
    IndicatorMetadataConfig,
    IndicatorContext,
    IndicatorInstance,
)
from oakscriptpy.input_ import int_ as input_int, float_ as input_float, source as input_source, bool_ as input_bool, string as input_string
from oakscriptpy.plot_ import plot, create_plot
from oakscriptpy._types import Bar


# ---------------------------------------------------------------------------
# Sample bar data
# ---------------------------------------------------------------------------

SAMPLE_BARS: list[Bar] = [
    Bar(time=1000, open=100, high=105, low=95, close=102, volume=1000),
    Bar(time=2000, open=102, high=108, low=100, close=107, volume=1200),
    Bar(time=3000, open=107, high=110, low=104, close=105, volume=800),
    Bar(time=4000, open=105, high=109, low=103, close=108, volume=1500),
    Bar(time=5000, open=108, high=112, low=106, close=110, volume=1100),
]


# ===========================================================================
# indicator function
# ===========================================================================

class TestIndicatorMetadata:
    def test_should_use_provided_metadata(self):
        test_indicator = indicator(
            IndicatorMetadataConfig(
                title="Test Indicator",
                short_title="TEST",
                overlay=True,
                format="price",
                precision=4,
            ),
            lambda ctx: None,
        )

        instance = test_indicator()
        assert instance.metadata.title == "Test Indicator"
        assert instance.metadata.short_title == "TEST"
        assert instance.metadata.overlay is True
        assert instance.metadata.format == "price"
        assert instance.metadata.precision == 4

    def test_should_use_default_values_for_optional_metadata(self):
        test_indicator = indicator(
            IndicatorMetadataConfig(title="Simple Test"),
            lambda ctx: None,
        )

        instance = test_indicator()
        assert instance.metadata.title == "Simple Test"
        assert instance.metadata.short_title == "Simple Test"
        assert instance.metadata.overlay is False
        assert instance.metadata.format == "price"
        assert instance.metadata.precision == 2


class TestOverlayAndPaneManagement:
    def test_should_return_pane_index_0_for_overlay_indicators(self):
        overlay_indicator = indicator(
            IndicatorMetadataConfig(title="Overlay", overlay=True),
            lambda ctx: None,
        )

        instance = overlay_indicator()
        assert instance.is_overlay() is True
        assert instance.pane_index == 0

    def test_should_return_pane_index_gt_0_for_non_overlay_indicators(self):
        separate_indicator = indicator(
            IndicatorMetadataConfig(title="Separate Pane", overlay=False),
            lambda ctx: None,
        )

        instance = separate_indicator()
        assert instance.is_overlay() is False
        assert instance.pane_index == 1

    def test_should_default_to_non_overlay(self):
        default_indicator = indicator(
            IndicatorMetadataConfig(title="Default"),
            lambda ctx: None,
        )

        instance = default_indicator()
        assert instance.is_overlay() is False
        assert instance.pane_index == 1


class TestCalculateFunction:
    def test_should_call_setup_function_with_correct_context(self):
        captured_ctx = [None]

        test_indicator = indicator(
            IndicatorMetadataConfig(title="Context Test"),
            lambda ctx: captured_ctx.__setitem__(0, ctx),
        )

        instance = test_indicator()
        instance.calculate(SAMPLE_BARS)

        ctx = captured_ctx[0]
        assert ctx is not None
        assert ctx.data == SAMPLE_BARS
        assert ctx.open == [100, 102, 107, 105, 108]
        assert ctx.high == [105, 108, 110, 109, 112]
        assert ctx.low == [95, 100, 104, 103, 106]
        assert ctx.close == [102, 107, 105, 108, 110]
        assert ctx.volume == [1000, 1200, 800, 1500, 1100]
        assert ctx.time == [1000, 2000, 3000, 4000, 5000]

    def test_should_provide_correct_pane_index_in_context(self):
        overlay_pane_index = [None]
        separate_pane_index = [None]

        overlay_ind = indicator(
            IndicatorMetadataConfig(title="Overlay", overlay=True),
            lambda ctx: overlay_pane_index.__setitem__(0, ctx.pane_index),
        )

        separate_ind = indicator(
            IndicatorMetadataConfig(title="Separate", overlay=False),
            lambda ctx: separate_pane_index.__setitem__(0, ctx.pane_index),
        )

        overlay_ind().calculate(SAMPLE_BARS)
        separate_ind().calculate(SAMPLE_BARS)

        assert overlay_pane_index[0] == 0
        assert separate_pane_index[0] == 1


class TestInputManagement:
    def test_should_update_and_get_input_values(self):
        test_indicator = indicator(
            IndicatorMetadataConfig(title="Test"),
            lambda ctx: None,
        )

        instance = test_indicator()
        instance.update_inputs({"length": 14, "source": "close"})

        values = instance.get_input_values()
        assert values["length"] == 14
        assert values["source"] == "close"

    def test_should_merge_input_values_on_update(self):
        test_indicator = indicator(
            IndicatorMetadataConfig(title="Test"),
            lambda ctx: None,
        )

        instance = test_indicator()
        instance.update_inputs({"length": 14})
        instance.update_inputs({"source": "high"})

        values = instance.get_input_values()
        assert values["length"] == 14
        assert values["source"] == "high"


# ===========================================================================
# input helpers
# ===========================================================================

class TestInputIntHelper:
    def test_should_create_integer_input_with_defaults(self):
        inp = input_int(14)
        assert inp.type == "int"
        assert inp.default_value == 14
        assert inp.value == 14
        assert inp.step == 1

    def test_should_accept_options(self):
        inp = input_int(10, min=1, max=100, step=5, title="Length")
        assert inp.min == 1
        assert inp.max == 100
        assert inp.step == 5
        assert inp.title == "Length"


class TestInputFloatHelper:
    def test_should_create_float_input_with_defaults(self):
        inp = input_float(2.5)
        assert inp.type == "float"
        assert inp.default_value == 2.5
        assert inp.value == 2.5
        assert inp.step == 0.1

    def test_should_accept_options(self):
        inp = input_float(1.0, min=0.1, max=10, step=0.5, title="Multiplier")
        assert inp.min == 0.1
        assert inp.max == 10
        assert inp.step == 0.5
        assert inp.title == "Multiplier"


class TestInputSourceHelper:
    def test_should_create_source_input_with_default_close(self):
        inp = input_source()
        assert inp.type == "source"
        assert inp.default_value == "close"
        assert inp.value == "close"
        assert "close" in inp.options
        assert "high" in inp.options
        assert "low" in inp.options

    def test_should_accept_different_default_source(self):
        inp = input_source("high", title="Price Source")
        assert inp.default_value == "high"
        assert inp.value == "high"
        assert inp.title == "Price Source"


class TestInputBoolHelper:
    def test_should_create_boolean_input(self):
        inp = input_bool(True)
        assert inp.type == "bool"
        assert inp.default_value is True
        assert inp.value is True

    def test_should_accept_title_option(self):
        inp = input_bool(False, title="Show Signal")
        assert inp.value is False
        assert inp.title == "Show Signal"


class TestInputStringHelper:
    def test_should_create_string_input(self):
        inp = input_string("SMA")
        assert inp.type == "string"
        assert inp.default_value == "SMA"
        assert inp.value == "SMA"

    def test_should_accept_options_for_dropdown(self):
        inp = input_string("SMA", title="MA Type", options=["SMA", "EMA", "WMA"])
        assert inp.options == ["SMA", "EMA", "WMA"]
        assert inp.title == "MA Type"


# ===========================================================================
# plot helpers
# ===========================================================================

class TestPlotFunction:
    def test_should_convert_values_and_times_to_time_value_pairs(self):
        times = [1000, 2000, 3000, 4000, 5000]
        values = [10, 20, 30, 40, 50]
        result = plot(values, times)

        assert len(result) == 5
        assert result[0].time == 1000
        assert result[0].value == 10
        assert result[4].time == 5000
        assert result[4].value == 50

    def test_should_filter_out_none_values(self):
        times = [1000, 2000, 3000, 4000, 5000]
        values = [10, None, 30, None, 50]
        result = plot(values, times)

        assert len(result) == 3
        assert [r.value for r in result] == [10, 30, 50]

    def test_should_filter_out_nan_values(self):
        times = [1000, 2000, 3000, 4000, 5000]
        values = [10, float("nan"), 30, float("nan"), 50]
        result = plot(values, times)

        assert len(result) == 3
        assert [r.value for r in result] == [10, 30, 50]

    def test_should_handle_empty_arrays(self):
        result = plot([], [])
        assert result == []

    def test_should_handle_offset(self):
        times = [1000, 2000, 3000, 4000, 5000]
        values = [10, 20, 30]
        result = plot(values, times, offset=1)

        assert len(result) == 3
        assert result[0].time == 2000
        assert result[0].value == 10
        assert result[2].time == 4000
        assert result[2].value == 30

    def test_should_skip_values_with_out_of_bounds_time_indices(self):
        times = [1000, 2000, 3000, 4000, 5000]
        values = [10, 20, 30, 40, 50, 60, 70]  # More values than times
        result = plot(values, times)

        assert len(result) == 5  # Only 5 time points available

    def test_should_handle_negative_offset(self):
        times = [1000, 2000, 3000, 4000, 5000]
        values = [10, 20, 30, 40, 50]
        result = plot(values, times, offset=-1)

        # First value (index 0 + offset -1 = -1) should be skipped
        assert len(result) == 4
        assert result[0].time == 1000  # value at index 1, time at index 0
        assert result[0].value == 20


class TestCreatePlotFunction:
    def test_should_create_a_named_plot_result(self):
        times = [1000, 2000, 3000]
        values = [10, 20, 30]
        result = create_plot("sma", values, times, color="#FF0000")

        assert result.id == "sma"
        assert len(result.data) == 3
        assert result.options["color"] == "#FF0000"

    def test_should_include_all_plot_data(self):
        times = [1000, 2000, 3000, 4000, 5000]
        values = [10, 20, 30, 40, 50]
        result = create_plot(
            "test", values, times,
            color="#2196F3", title="Test Plot", line_width=2,
        )

        assert result.id == "test"
        assert len(result.data) == 5
        assert result.options == {
            "color": "#2196F3",
            "title": "Test Plot",
            "line_width": 2,
        }


# ===========================================================================
# Integration: indicator with inputs and plot
# ===========================================================================

class TestIntegrationIndicatorWithInputsAndPlot:
    def test_should_create_a_functional_indicator(self):
        calculated_values = []

        def setup(ctx: IndicatorContext):
            nonlocal calculated_values
            length_input = input_int(3, min=1, title="Length")
            length = length_input.value

            # Simple SMA calculation
            calculated_values = []
            for i in range(len(ctx.close)):
                if i < length - 1:
                    calculated_values.append(float("nan"))
                else:
                    s = sum(ctx.close[i - j] for j in range(length))
                    calculated_values.append(s / length)

        sma_indicator = indicator(
            IndicatorMetadataConfig(
                title="Simple Moving Average",
                short_title="SMA",
                overlay=True,
            ),
            setup,
        )

        instance = sma_indicator()
        instance.calculate(SAMPLE_BARS)

        # With length 3: NaN, NaN, avg(102,107,105), avg(107,105,108), avg(105,108,110)
        assert len(calculated_values) == 5
        assert math.isnan(calculated_values[0])
        assert math.isnan(calculated_values[1])
        assert calculated_values[2] == pytest.approx((102 + 107 + 105) / 3)
        assert calculated_values[3] == pytest.approx((107 + 105 + 108) / 3)
        assert calculated_values[4] == pytest.approx((105 + 108 + 110) / 3)
