"""Tests for the polyline namespace — ported from polyline.test.ts."""

import warnings

import pytest

from oakscriptpy import chartpoint, polyline
from oakscriptpy._types import xloc


@pytest.fixture(autouse=True)
def _reset_polyline_state():
    """Reset polyline state before each test."""
    polyline.clear_all()
    polyline.reset_id_counter()


# --- polyline.new ---

class TestPolylineNew:
    def test_create_basic_polyline_with_points(self):
        points = [
            chartpoint.from_index(0, 100),
            chartpoint.from_index(10, 120),
            chartpoint.from_index(20, 110),
        ]

        pl = polyline.new(points)

        assert pl.id == "polyline_1"
        assert len(pl.points) == 3
        assert pl.curved is False
        assert pl.closed is False
        assert pl.xloc == "bar_index"
        assert pl.line_color == "#2196F3"
        assert pl.fill_color is None
        assert pl.line_style == "solid"
        assert pl.line_width == 1
        assert pl.force_overlay is False

    def test_create_closed_polyline(self):
        points = [
            chartpoint.from_index(0, 100),
            chartpoint.from_index(10, 120),
            chartpoint.from_index(20, 110),
        ]

        pl = polyline.new(points, closed=True)

        assert pl.closed is True

    def test_create_polyline_with_custom_styling(self):
        points = [
            chartpoint.from_index(0, 100),
            chartpoint.from_index(10, 120),
        ]

        pl = polyline.new(
            points,
            curved=False,
            closed=True,
            xloc="bar_index",
            line_color="#FF5722",
            fill_color="rgba(255, 87, 34, 0.3)",
            line_style="dashed",
            line_width=2,
            force_overlay=True,
        )

        assert pl.line_color == "#FF5722"
        assert pl.fill_color == "rgba(255, 87, 34, 0.3)"
        assert pl.line_style == "dashed"
        assert pl.line_width == 2
        assert pl.force_overlay is True

    def test_use_xloc_bar_time_mode(self):
        points = [
            chartpoint.from_time(1609459200000, 100),
            chartpoint.from_time(1609545600000, 120),
        ]

        pl = polyline.new(points, xloc="bar_time")

        assert pl.xloc == "bar_time"

    def test_use_xloc_constants(self):
        points = [
            chartpoint.from_index(0, 100),
            chartpoint.from_index(10, 120),
        ]

        pl1 = polyline.new(points, xloc=xloc.bar_index)
        pl2 = polyline.new(points, xloc=xloc.bar_time)

        assert pl1.xloc == "bar_index"
        assert pl2.xloc == "bar_time"

    def test_handle_empty_points_array(self):
        pl = polyline.new([])

        assert len(pl.points) == 0

    def test_handle_single_point(self):
        points = [chartpoint.from_index(0, 100)]

        pl = polyline.new(points)

        assert len(pl.points) == 1

    def test_create_independent_copy_of_points_array(self):
        points = [
            chartpoint.from_index(0, 100),
            chartpoint.from_index(10, 120),
        ]

        pl = polyline.new(points)

        # Modify original list
        points.append(chartpoint.from_index(20, 140))

        # Polyline should not be affected
        assert len(pl.points) == 2

    def test_generate_unique_ids(self):
        points = [chartpoint.from_index(0, 100)]

        pl1 = polyline.new(points)
        pl2 = polyline.new(points)
        pl3 = polyline.new(points)

        assert pl1.id == "polyline_1"
        assert pl2.id == "polyline_2"
        assert pl3.id == "polyline_3"

    def test_warn_about_curved_polylines(self):
        points = [
            chartpoint.from_index(0, 100),
            chartpoint.from_index(10, 120),
        ]

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            pl = polyline.new(points, curved=True)

            assert len(w) == 1
            assert "curved polylines" in str(w[0].message).lower()

        assert pl.curved is True

    def test_handle_line_width_less_than_1(self):
        points = [chartpoint.from_index(0, 100)]

        pl = polyline.new(points, line_width=0)

        assert pl.line_width == 1

    def test_support_dotted_line_style(self):
        points = [chartpoint.from_index(0, 100)]

        pl = polyline.new(points, line_style="dotted")

        assert pl.line_style == "dotted"


# --- polyline.get_all ---

class TestPolylineGetAll:
    def test_return_empty_list_initially(self):
        assert len(polyline.get_all()) == 0

    def test_track_created_polylines(self):
        points = [chartpoint.from_index(0, 100)]

        polyline.new(points)
        polyline.new(points)
        polyline.new(points)

        assert len(polyline.get_all()) == 3

    def test_return_copy_of_list(self):
        points = [chartpoint.from_index(0, 100)]

        polyline.new(points)

        all1 = polyline.get_all()
        all2 = polyline.get_all()

        assert all1 is not all2

        assert len(all1) == len(all2)
        assert all1[0].id == all2[0].id


# --- polyline.delete ---

class TestPolylineDelete:
    def test_delete_a_polyline(self):
        points = [chartpoint.from_index(0, 100)]

        pl1 = polyline.new(points)
        pl2 = polyline.new(points)

        assert len(polyline.get_all()) == 2

        polyline.delete(pl1)

        assert len(polyline.get_all()) == 1
        assert polyline.get_all()[0].id == pl2.id

    def test_handle_deleting_non_existent_polyline(self):
        points = [chartpoint.from_index(0, 100)]

        pl = polyline.new(points)
        polyline.delete(pl)

        # Delete again — should not raise
        polyline.delete(pl)

    def test_not_affect_other_polylines(self):
        points = [chartpoint.from_index(0, 100)]

        pl1 = polyline.new(points)
        pl2 = polyline.new(points)
        pl3 = polyline.new(points)

        polyline.delete(pl2)

        all_pl = polyline.get_all()
        assert len(all_pl) == 2
        ids = [p.id for p in all_pl]
        assert pl1.id in ids
        assert pl3.id in ids
        assert pl2.id not in ids


# --- polyline.clear_all ---

class TestPolylineClearAll:
    def test_clear_all_polylines(self):
        points = [chartpoint.from_index(0, 100)]

        polyline.new(points)
        polyline.new(points)
        polyline.new(points)

        assert len(polyline.get_all()) == 3

        polyline.clear_all()

        assert len(polyline.get_all()) == 0


# --- Real-world use cases ---

class TestPolylineRealWorld:
    def test_create_trend_channel(self):
        upper_points = [
            chartpoint.from_index(0, 110),
            chartpoint.from_index(50, 160),
        ]

        lower_points = [
            chartpoint.from_index(0, 90),
            chartpoint.from_index(50, 140),
        ]

        upper_line = polyline.new(upper_points, line_color="#2196F3")
        lower_line = polyline.new(lower_points, line_color="#2196F3")

        assert upper_line.points[0].price == 110
        assert lower_line.points[0].price == 90

    def test_create_closed_polygon_with_fill(self):
        points = [
            chartpoint.from_index(0, 100),
            chartpoint.from_index(10, 120),
            chartpoint.from_index(20, 120),
            chartpoint.from_index(30, 100),
        ]

        polygon = polyline.new(
            points,
            closed=True,
            line_color="#4CAF50",
            fill_color="rgba(76, 175, 80, 0.2)",
        )

        assert polygon.closed is True
        assert polygon.fill_color == "rgba(76, 175, 80, 0.2)"

    def test_create_triangle_pattern(self):
        points = [
            chartpoint.from_index(0, 100),
            chartpoint.from_index(10, 130),
            chartpoint.from_index(20, 100),
        ]

        triangle = polyline.new(
            points,
            closed=True,
            line_color="#E91E63",
            fill_color="rgba(233, 30, 99, 0.1)",
        )

        assert len(triangle.points) == 3
        assert triangle.closed is True


# --- Polyline structure ---

class TestPolylineStructure:
    def test_has_expected_properties(self):
        points = [chartpoint.from_index(0, 100)]
        pl = polyline.new(points)

        assert pl.id is not None
        assert pl.points is not None
        assert isinstance(pl.points, list)
