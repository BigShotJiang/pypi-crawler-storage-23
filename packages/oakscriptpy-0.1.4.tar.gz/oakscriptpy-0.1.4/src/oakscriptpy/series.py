"""Series + BarData classes — lazy time-series computation with cache invalidation."""

from __future__ import annotations

import math
from typing import Any, Callable

from ._types import Bar

SeriesExtractor = Callable[[Bar, int, list[Bar]], float]


class BarData:
    """Versioned wrapper around list[Bar] for cache invalidation.

    Tracks a version number that increments whenever the data is mutated.
    Series objects reference this to detect when cached values need recomputation.
    """

    __slots__ = ("_bars", "_version")

    def __init__(self, bars: list[Bar] | None = None) -> None:
        self._bars: list[Bar] = bars if bars is not None else []
        self._version: int = 0

    @property
    def version(self) -> int:
        return self._version

    @property
    def bars(self) -> list[Bar]:
        return self._bars

    @property
    def length(self) -> int:
        return len(self._bars)

    def push(self, bar: Bar) -> None:
        self._bars.append(bar)
        self._version += 1

    def pop(self) -> Bar | None:
        if self._bars:
            bar = self._bars.pop()
            self._version += 1
            return bar
        return None

    def set(self, index: int, bar: Bar) -> None:
        if 0 <= index < len(self._bars):
            self._bars[index] = bar
            self._version += 1

    def update_last(self, bar: Bar) -> None:
        if self._bars:
            self._bars[-1] = bar
            self._version += 1

    def set_all(self, bars: list[Bar]) -> None:
        self._bars = bars
        self._version += 1

    def invalidate(self) -> None:
        self._version += 1

    def at(self, index: int) -> Bar | None:
        if 0 <= index < len(self._bars):
            return self._bars[index]
        return None

    @staticmethod
    def from_bars(bars: list[Bar]) -> BarData:
        return BarData(bars)


class Series:
    """Lazy time-series with operator overloading and automatic cache invalidation.

    Operations on Series return new Series with composed extractors.
    Values are only computed when to_array() or get() is called.
    """

    __slots__ = ("_extractor", "_data_source", "_cached", "_cached_version")

    def __init__(self, data: list[Bar] | BarData, extractor: SeriesExtractor) -> None:
        self._data_source: BarData = data if isinstance(data, BarData) else BarData(data)
        self._extractor: SeriesExtractor = extractor
        self._cached: list[float] | None = None
        self._cached_version: int = -1

    @property
    def bars(self) -> list[Bar]:
        return self._data_source.bars

    @property
    def bar_data(self) -> BarData:
        return self._data_source

    # --- Factory Methods ---

    @staticmethod
    def from_bars(bars: list[Bar] | BarData, field: str) -> Series:
        def extractor(bar: Bar, _i: int, _data: list[Bar]) -> float:
            v = getattr(bar, field, None)
            return float("nan") if v is None else float(v)
        return Series(bars, extractor)

    @staticmethod
    def constant(bars: list[Bar] | BarData, value: float) -> Series:
        return Series(bars, lambda _b, _i, _d: value)

    @staticmethod
    def from_array(bars: list[Bar] | BarData, values: list[float]) -> Series:
        def extractor(_b: Bar, i: int, _d: list[Bar]) -> float:
            return values[i] if i < len(values) else float("nan")
        return Series(bars, extractor)

    # --- Arithmetic (Python operator overloading) ---

    def _binop(self, other: Series | float | int, op: Callable[[float, float], float]) -> Series:
        if isinstance(other, Series):
            ext = self._extractor
            other_ext = other._extractor
            return Series(self._data_source, lambda b, i, d: op(ext(b, i, d), other_ext(b, i, d)))
        else:
            val = float(other)
            ext = self._extractor
            return Series(self._data_source, lambda b, i, d: op(ext(b, i, d), val))

    def _rbinop(self, other: float | int, op: Callable[[float, float], float]) -> Series:
        val = float(other)
        ext = self._extractor
        return Series(self._data_source, lambda b, i, d: op(val, ext(b, i, d)))

    def __add__(self, other: Series | float | int) -> Series:
        return self._binop(other, lambda a, b: a + b)

    def __radd__(self, other: float | int) -> Series:
        return self._rbinop(other, lambda a, b: a + b)

    def __sub__(self, other: Series | float | int) -> Series:
        return self._binop(other, lambda a, b: a - b)

    def __rsub__(self, other: float | int) -> Series:
        return self._rbinop(other, lambda a, b: a - b)

    def __mul__(self, other: Series | float | int) -> Series:
        return self._binop(other, lambda a, b: a * b)

    def __rmul__(self, other: float | int) -> Series:
        return self._rbinop(other, lambda a, b: a * b)

    def __truediv__(self, other: Series | float | int) -> Series:
        return self._binop(other, lambda a, b: a / b if b != 0 else float("nan"))

    def __rtruediv__(self, other: float | int) -> Series:
        return self._rbinop(other, lambda a, b: a / b if b != 0 else float("nan"))

    def __mod__(self, other: Series | float | int) -> Series:
        return self._binop(other, lambda a, b: a % b if b != 0 else float("nan"))

    def __rmod__(self, other: float | int) -> Series:
        return self._rbinop(other, lambda a, b: a % b if b != 0 else float("nan"))

    def __neg__(self) -> Series:
        ext = self._extractor
        return Series(self._data_source, lambda b, i, d: -ext(b, i, d))

    def __abs__(self) -> Series:
        ext = self._extractor
        return Series(self._data_source, lambda b, i, d: abs(ext(b, i, d)))

    # --- Comparison (return Series with 1/0) ---

    def __gt__(self, other: Series | float | int) -> Series:  # type: ignore[override]
        return self._binop(other, lambda a, b: 1.0 if a > b else 0.0)

    def __ge__(self, other: Series | float | int) -> Series:  # type: ignore[override]
        return self._binop(other, lambda a, b: 1.0 if a >= b else 0.0)

    def __lt__(self, other: Series | float | int) -> Series:  # type: ignore[override]
        return self._binop(other, lambda a, b: 1.0 if a < b else 0.0)

    def __le__(self, other: Series | float | int) -> Series:  # type: ignore[override]
        return self._binop(other, lambda a, b: 1.0 if a <= b else 0.0)

    def eq(self, other: Series | float | int) -> Series:
        return self._binop(other, lambda a, b: 1.0 if a == b else 0.0)

    def neq(self, other: Series | float | int) -> Series:
        return self._binop(other, lambda a, b: 1.0 if a != b else 0.0)

    # --- Logical (keywords in Python, so use methods) ---

    def and_(self, other: Series | float | int) -> Series:
        if isinstance(other, Series):
            ext = self._extractor
            other_ext = other._extractor
            return Series(self._data_source, lambda b, i, d: 1.0 if ext(b, i, d) and other_ext(b, i, d) else 0.0)
        else:
            val = float(other)
            ext = self._extractor
            return Series(self._data_source, lambda b, i, d: 1.0 if ext(b, i, d) and val else 0.0)

    def or_(self, other: Series | float | int) -> Series:
        if isinstance(other, Series):
            ext = self._extractor
            other_ext = other._extractor
            return Series(self._data_source, lambda b, i, d: 1.0 if ext(b, i, d) or other_ext(b, i, d) else 0.0)
        else:
            val = float(other)
            ext = self._extractor
            return Series(self._data_source, lambda b, i, d: 1.0 if ext(b, i, d) or val else 0.0)

    def not_(self) -> Series:
        ext = self._extractor
        return Series(self._data_source, lambda b, i, d: 1.0 if not ext(b, i, d) else 0.0)

    # --- Conditional Selection ---

    def iff(self, true_value: Series | float | int, false_value: Series | float | int) -> Series:
        """Bar-by-bar conditional selection (ternary operator for Series)."""
        ext = self._extractor
        tv_is_series = isinstance(true_value, Series)
        fv_is_series = isinstance(false_value, Series)
        tv_ext = true_value._extractor if tv_is_series else None
        fv_ext = false_value._extractor if fv_is_series else None
        tv_num = 0.0 if tv_is_series else float(true_value)
        fv_num = 0.0 if fv_is_series else float(false_value)

        def _iff(b: Bar, i: int, d: list[Bar]) -> float:
            cond = ext(b, i, d)
            is_truthy = cond != 0 and not math.isnan(cond)
            if is_truthy:
                return tv_ext(b, i, d) if tv_ext is not None else tv_num
            else:
                return fv_ext(b, i, d) if fv_ext is not None else fv_num

        return Series(self._data_source, _iff)

    # --- Offset/History ---

    def offset(self, n: int) -> Series:
        """Access previous bars (like close[1] in PineScript)."""
        ext = self._extractor

        def _offset(_b: Bar, i: int, d: list[Bar]) -> float:
            target = i - n
            if target < 0 or target >= len(d):
                return float("nan")
            return ext(d[target], target, d)

        return Series(self._data_source, _offset)

    # --- Computation & Access ---

    def to_array(self) -> list[float]:
        if self._cached is not None and self._cached_version == self._data_source.version:
            return self._cached
        bars = self._data_source.bars
        self._cached = [self._extractor(bar, i, bars) for i, bar in enumerate(bars)]
        self._cached_version = self._data_source.version
        return self._cached

    def materialize(self) -> Series:
        """Eagerly compute values and break closure chain for memory efficiency."""
        values = list(self.to_array())
        return Series.from_array(self._data_source, values)

    def _invalidate(self) -> None:
        self._cached = None
        self._cached_version = -1

    def get(self, index: int) -> float:
        values = self.to_array()
        return values[index] if 0 <= index < len(values) else float("nan")

    def last(self) -> float:
        values = self.to_array()
        return values[-1] if values else float("nan")

    def length(self) -> int:
        return self._data_source.length

    def to_time_value_pairs(self) -> list[dict[str, Any]]:
        values = self.to_array()
        bars = self._data_source.bars
        return [
            {"time": bar.time, "value": v}
            for bar, v in zip(bars, values)
            if not math.isnan(v)
        ]
