"""Label namespace — mirrors PineScript label.* functions."""

from __future__ import annotations

import copy as _copy

from ._types import Label


def new(
    x: float, y: float, text: str | None = None,
    xloc: str = "bar_index", yloc: str = "price",
    color: str | int | None = None, style: str | None = None,
    textcolor: str | int | None = None, size: str | int | None = None,
    textalign: str | None = None, tooltip: str | None = None,
    text_font_family: str | None = None,
) -> Label:
    return Label(
        x=x, y=y, xloc=xloc, yloc=yloc, text=text, tooltip=tooltip,
        color=color, style=style, textcolor=textcolor, size=size,
        textalign=textalign, text_font_family=text_font_family,
    )


def get_x(id: Label) -> float:
    return id.x


def get_y(id: Label) -> float:
    return id.y


def get_text(id: Label) -> str | None:
    return id.text


def copy(id: Label) -> Label:
    return _copy.copy(id)


def set_x(id: Label, x: float) -> Label:
    id.x = x
    return id


def set_y(id: Label, y: float) -> Label:
    id.y = y
    return id


def set_xy(id: Label, x: float, y: float) -> Label:
    id.x = x
    id.y = y
    return id


def set_xloc(id: Label, x: float, xloc: str) -> Label:
    id.x = x
    id.xloc = xloc
    return id


def set_yloc(id: Label, y: float, yloc: str) -> Label:
    id.y = y
    id.yloc = yloc
    return id


def set_text(id: Label, text: str) -> Label:
    id.text = text
    return id


def set_tooltip(id: Label, tooltip: str) -> Label:
    id.tooltip = tooltip
    return id


def set_color(id: Label, color: str | int) -> Label:
    id.color = color
    return id


def set_textcolor(id: Label, color: str | int) -> Label:
    id.textcolor = color
    return id


def set_style(id: Label, style: str) -> Label:
    id.style = style
    return id


def set_size(id: Label, size: str | int) -> Label:
    id.size = size
    return id


def set_textalign(id: Label, align: str) -> Label:
    id.textalign = align
    return id


def set_text_font_family(id: Label, font: str) -> Label:
    id.text_font_family = font
    return id


def delete(id: Label) -> None:
    pass
