"""ChartPoint namespace — mirrors PineScript chart.point.* functions."""

from __future__ import annotations

from ._types import ChartPoint


def new(time: float | None, index: int | None, price: float) -> ChartPoint:
    return ChartPoint(time=time, index=index, price=price)


def from_time(time: float, price: float) -> ChartPoint:
    return ChartPoint(time=time, index=None, price=price)


def from_index(index: int, price: float) -> ChartPoint:
    return ChartPoint(time=None, index=index, price=price)


def copy(point: ChartPoint) -> ChartPoint:
    return ChartPoint(time=point.time, index=point.index, price=point.price)
