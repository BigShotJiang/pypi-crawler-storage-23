"""Input functions — mirrors PineScript input.* with idempotent semantics."""

from __future__ import annotations

import math
from typing import Any

from .runtime import get_context, recalculate
from .runtime_types import InputConfig

_registered_inputs: dict[str, bool] = {}
_auto_recalculate_enabled: bool = False
_input_counter: int = 0


def enable_auto_recalculate() -> None:
    global _auto_recalculate_enabled
    _auto_recalculate_enabled = True


def disable_auto_recalculate() -> None:
    global _auto_recalculate_enabled
    _auto_recalculate_enabled = False


def reset_inputs() -> None:
    global _input_counter
    _registered_inputs.clear()
    _input_counter = 0


def _generate_input_id(title: str | None, defval: Any, type_: str) -> str:
    global _input_counter
    if title:
        return title.replace(" ", "_")
    id_ = f"{type_}_{_input_counter}_{defval}"
    _input_counter += 1
    return id_


def input_int(
    defval: int, title: str | None = None,
    min: int | None = None, max: int | None = None, step: int = 1,
) -> int:
    ctx = get_context()
    if ctx is None:
        return int(defval)

    id_ = _generate_input_id(title, defval, "int")
    config = InputConfig(
        id=id_, type="int", defval=int(defval), title=title,
        min=float(min) if min is not None else None,
        max=float(max) if max is not None else None,
        step=float(step),
    )

    if id_ not in _registered_inputs:
        ctx.inputs.register_input(config)
        _registered_inputs[id_] = True
        if _auto_recalculate_enabled:
            ctx.inputs.on_input_change(lambda cid, _v: recalculate() if cid == id_ else None)

    value = ctx.inputs.get_value(id_)
    return int(value) if isinstance(value, (int, float)) else int(defval)


def input_float(
    defval: float, title: str | None = None,
    min: float | None = None, max: float | None = None, step: float = 0.1,
) -> float:
    ctx = get_context()
    if ctx is None:
        return defval

    id_ = _generate_input_id(title, defval, "float")
    config = InputConfig(
        id=id_, type="float", defval=defval, title=title,
        min=min, max=max, step=step,
    )

    if id_ not in _registered_inputs:
        ctx.inputs.register_input(config)
        _registered_inputs[id_] = True
        if _auto_recalculate_enabled:
            ctx.inputs.on_input_change(lambda cid, _v: recalculate() if cid == id_ else None)

    value = ctx.inputs.get_value(id_)
    return float(value) if isinstance(value, (int, float)) else defval


def input_bool(defval: bool, title: str | None = None) -> bool:
    ctx = get_context()
    if ctx is None:
        return defval

    id_ = _generate_input_id(title, defval, "bool")
    config = InputConfig(id=id_, type="bool", defval=defval, title=title)

    if id_ not in _registered_inputs:
        ctx.inputs.register_input(config)
        _registered_inputs[id_] = True
        if _auto_recalculate_enabled:
            ctx.inputs.on_input_change(lambda cid, _v: recalculate() if cid == id_ else None)

    value = ctx.inputs.get_value(id_)
    return bool(value) if isinstance(value, bool) else defval


def input_string(
    defval: str, title: str | None = None, options: list[str] | None = None,
) -> str:
    ctx = get_context()
    if ctx is None:
        return defval

    id_ = _generate_input_id(title, defval, "string")
    config = InputConfig(id=id_, type="string", defval=defval, title=title, options=options)

    if id_ not in _registered_inputs:
        ctx.inputs.register_input(config)
        _registered_inputs[id_] = True
        if _auto_recalculate_enabled:
            ctx.inputs.on_input_change(lambda cid, _v: recalculate() if cid == id_ else None)

    value = ctx.inputs.get_value(id_)
    return str(value) if isinstance(value, str) else defval


def input_source(defval: str = "close", title: str | None = None) -> list[float]:
    ctx = get_context()
    if ctx is None:
        return []

    id_ = _generate_input_id(title, defval, "source")
    config = InputConfig(
        id=id_, type="source", defval=defval, title=title,
        options=["open", "high", "low", "close", "volume", "hl2", "hlc3", "ohlc4"],
    )

    if id_ not in _registered_inputs:
        ctx.inputs.register_input(config)
        _registered_inputs[id_] = True
        if _auto_recalculate_enabled:
            ctx.inputs.on_input_change(lambda cid, _v: recalculate() if cid == id_ else None)

    source_name = ctx.inputs.get_value(id_)
    if not isinstance(source_name, str):
        source_name = defval

    return _get_source_data(ctx.ohlcv, source_name)


def _get_source_data(ohlcv: Any, source_name: str) -> list[float]:
    if source_name == "open":
        return ohlcv.open
    if source_name == "high":
        return ohlcv.high
    if source_name == "low":
        return ohlcv.low
    if source_name == "close":
        return ohlcv.close
    if source_name == "volume":
        return ohlcv.volume
    if source_name == "hl2":
        return [(h + l) / 2 for h, l in zip(ohlcv.high, ohlcv.low)]
    if source_name == "hlc3":
        return [(h + l + c) / 3 for h, l, c in zip(ohlcv.high, ohlcv.low, ohlcv.close)]
    if source_name == "ohlc4":
        return [(o + h + l + c) / 4 for o, h, l, c in zip(ohlcv.open, ohlcv.high, ohlcv.low, ohlcv.close)]
    return ohlcv.close
