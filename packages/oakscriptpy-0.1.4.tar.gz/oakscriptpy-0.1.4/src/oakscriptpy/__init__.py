"""OakScriptPy — PineScript-like API for technical analysis in Python."""
from __future__ import annotations

# Core namespaces (array-based functions)
from . import ta as ta_core
from . import math_ as math
from . import array
from . import str_ as str
from . import color
from . import time_ as time
from . import matrix

# Drawing object namespaces
from . import line
from . import box
from . import label
from . import linefill
from . import chartpoint as chart_point
from . import polyline

# Series class (self-contained, no context)
from .series import Series, BarData

# TA-Series namespace (Series-based wrappers)
from . import ta_series as ta

# Types
from ._types import (
    Bar, Line as LineType, Box as BoxType, Label as LabelType,
    Linefill as LinefillType, ChartPoint, Polyline as PolylineType,
    Table, TableCell, Plot, HLine, OHLC, PineMatrix,
    series_float, series_int, series_bool, series_string,
    Source, color as color_type, na, xloc,
)

# Metadata types
from ._metadata import (
    PlotOptions, HLineOptions, FillOptions, InputMetadata,
    PlotMetadata, IndicatorMetadata, TimeValue, PlotData,
    HLineData, FillData, IndicatorResult,
)

# Utilities
from ._utils import is_na, nz, ohlc_from_bars, get_close, get_high, get_low, get_open, get_source

# Runtime
from .runtime import (
    set_context, clear_context, get_context,
    register_calculate, recalculate,
    plot, hline, clear_plots, get_active_plots,
)
from .runtime_types import OakScriptContext, OhlcvData, InputConfig

# Inputs
from .inputs import (
    input_int, input_float, input_bool, input_string, input_source,
    enable_auto_recalculate, disable_auto_recalculate, reset_inputs,
)

# Indicator infrastructure
from .indicator import indicator, IndicatorMetadataConfig, IndicatorContext, IndicatorInstance

# Input helper
from . import input_ as input

# Plot helper
from .plot_ import plot as plot_helper, create_plot, TimeValuePair, PlotResult

# Adapters
from .adapters import SimpleInputAdapter

# Libraries
from .lib import ZigZag, calculate_zigzag


def alertcondition(_condition: object = None, _title: str | None = None, _message: str | None = None) -> None:
    """No-op stub for PineScript alertcondition() compatibility."""
    pass


VERSION = "0.1.4"

info = {
    "name": "OakScriptPy",
    "version": VERSION,
    "description": "PineScript-like API for technical analysis in Python",
    "namespaces": {
        "core": ["ta", "math", "array", "str", "color", "time", "matrix"],
        "drawing": ["line", "box", "label", "linefill", "chart_point", "polyline"],
        "runtime": ["set_context", "plot", "hline", "input_*"],
        "indicator": ["indicator", "input", "plot_helper", "create_plot"],
    },
}
