"""Polyline namespace — mirrors PineScript polyline.* functions."""

from __future__ import annotations

import warnings

from ._types import ChartPoint, Polyline

_polyline_id_counter = 0
_all_polylines: list[Polyline] = []


def _generate_id() -> str:
    global _polyline_id_counter
    _polyline_id_counter += 1
    return f"polyline_{_polyline_id_counter}"


def new(
    points: list[ChartPoint],
    curved: bool = False,
    closed: bool = False,
    xloc: str = "bar_index",
    line_color: str | int = "#2196F3",
    fill_color: str | int | None = None,
    line_style: str = "solid",
    line_width: int = 1,
    force_overlay: bool = False,
) -> Polyline:
    if curved:
        warnings.warn("polyline.new(): curved polylines not yet supported. Using straight lines.")
    if line_width < 1:
        line_width = 1
    pl = Polyline(
        id=_generate_id(), points=list(points), curved=curved, closed=closed,
        xloc=xloc, line_color=line_color, fill_color=fill_color,
        line_style=line_style, line_width=line_width, force_overlay=force_overlay,
    )
    _all_polylines.append(pl)
    return pl


def delete(id: Polyline) -> None:
    for i, p in enumerate(_all_polylines):
        if p.id == id.id:
            _all_polylines.pop(i)
            return


def get_all() -> list[Polyline]:
    return list(_all_polylines)


def clear_all() -> None:
    _all_polylines.clear()


def reset_id_counter() -> None:
    global _polyline_id_counter
    _polyline_id_counter = 0
