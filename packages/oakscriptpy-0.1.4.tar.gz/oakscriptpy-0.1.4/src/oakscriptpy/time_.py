"""Time namespace — mirrors PineScript time functions."""

from __future__ import annotations

import time as _time
from datetime import datetime


def now() -> int:
    return int(_time.time() * 1000)


def timestamp(
    year: int,
    month: int,
    day: int,
    hour: int = 0,
    minute: int = 0,
    second: int = 0,
) -> int:
    dt = datetime(year, month, day, hour, minute, second)
    return int(dt.timestamp() * 1000)
