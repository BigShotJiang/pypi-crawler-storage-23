"""Matrix namespace — mirrors PineScript matrix.* functions."""

from __future__ import annotations

import builtins as _builtins
import math
from typing import Any

from ._types import PineMatrix

builtins_max = _builtins.max
builtins_min = _builtins.min

EPSILON = 1e-10


def new_matrix(rows: int = 0, columns: int = 0, initial_value: Any = None) -> PineMatrix:
    data: list[list[Any]] = []
    for i in range(rows):
        row: list[Any] = []
        for j in range(columns):
            row.append(initial_value)
        data.append(row)
    return PineMatrix(rows=rows, columns=columns, data=data)


def get(id: PineMatrix, row: int, column: int) -> Any:
    if row < 0 or row >= id.rows or column < 0 or column >= id.columns:
        raise ValueError(f"Matrix index out of bounds: [{row}, {column}] for matrix of size [{id.rows}, {id.columns}]")
    return id.data[row][column]


def set(id: PineMatrix, row: int, column: int, value: Any) -> None:
    if row < 0 or row >= id.rows or column < 0 or column >= id.columns:
        raise ValueError(f"Matrix index out of bounds: [{row}, {column}] for matrix of size [{id.rows}, {id.columns}]")
    id.data[row][column] = value


def rows(id: PineMatrix) -> int:
    return id.rows


def columns(id: PineMatrix) -> int:
    return id.columns


def elements_count(id: PineMatrix) -> int:
    return id.rows * id.columns


def row(id: PineMatrix, row_index: int) -> list[Any]:
    if row_index < 0 or row_index >= id.rows:
        raise ValueError(f"Row index out of bounds: {row_index} for matrix with {id.rows} rows")
    return list(id.data[row_index])


def col(id: PineMatrix, column_index: int) -> list[Any]:
    if column_index < 0 or column_index >= id.columns:
        raise ValueError(f"Column index out of bounds: {column_index} for matrix with {id.columns} columns")
    return [r[column_index] for r in id.data]


def copy_matrix(id: PineMatrix) -> PineMatrix:
    new_data = [list(r) for r in id.data]
    return PineMatrix(rows=id.rows, columns=id.columns, data=new_data)


def fill(
    id: PineMatrix,
    value: Any,
    from_row: int = 0,
    to_row: int | None = None,
    from_column: int = 0,
    to_column: int | None = None,
) -> None:
    end_row = to_row if to_row is not None else id.rows
    end_col = to_column if to_column is not None else id.columns
    for i in range(from_row, end_row):
        for j in range(from_column, end_col):
            id.data[i][j] = value


def is_square(id: PineMatrix) -> bool:
    return id.rows == id.columns


def is_zero(id: PineMatrix) -> bool:
    for i in range(id.rows):
        for j in range(id.columns):
            if id.data[i][j] != 0:
                return False
    return True


def is_binary(id: PineMatrix) -> bool:
    for i in range(id.rows):
        for j in range(id.columns):
            val = id.data[i][j]
            if val != 0 and val != 1:
                return False
    return True


# ==========================================
# Row/Column Operations
# ==========================================


def add_row(id: PineMatrix, row_idx: int | None = None, array_id: list[Any] | None = None) -> None:
    insert_index = row_idx if row_idx is not None else id.rows

    if insert_index < 0 or insert_index > id.rows:
        raise ValueError(f"Row index out of bounds: {insert_index} for matrix with {id.rows} rows")

    if array_id is not None:
        if id.columns > 0 and len(array_id) != id.columns:
            raise ValueError(f"Array size {len(array_id)} does not match matrix columns {id.columns}")
        new_row = list(array_id)
        if id.rows == 0 and id.columns == 0:
            id.columns = len(array_id)
    else:
        new_row = [None] * id.columns

    id.data.insert(insert_index, new_row)
    id.rows += 1


def add_col(id: PineMatrix, column: int | None = None, array_id: list[Any] | None = None) -> None:
    insert_index = column if column is not None else id.columns

    if insert_index < 0 or insert_index > id.columns:
        raise ValueError(f"Column index out of bounds: {insert_index} for matrix with {id.columns} columns")

    if array_id is not None:
        if id.rows > 0 and len(array_id) != id.rows:
            raise ValueError(f"Array size {len(array_id)} does not match matrix rows {id.rows}")
        if id.rows == 0 and id.columns == 0:
            id.rows = len(array_id)
            for i in range(len(array_id)):
                id.data.append([])
        for i in range(id.rows):
            id.data[i].insert(insert_index, array_id[i])
    else:
        for i in range(id.rows):
            id.data[i].insert(insert_index, None)

    id.columns += 1


def remove_row(id: PineMatrix, row_idx: int | None = None) -> list[Any]:
    remove_index = row_idx if row_idx is not None else (id.rows - 1)

    if remove_index < 0 or remove_index >= id.rows:
        raise ValueError(f"Row index out of bounds: {remove_index} for matrix with {id.rows} rows")

    removed_row = id.data.pop(remove_index)
    id.rows -= 1
    return removed_row


def remove_col(id: PineMatrix, column: int | None = None) -> list[Any]:
    remove_index = column if column is not None else (id.columns - 1)

    if remove_index < 0 or remove_index >= id.columns:
        raise ValueError(f"Column index out of bounds: {remove_index} for matrix with {id.columns} columns")

    removed_col: list[Any] = []
    for i in range(id.rows):
        removed_col.append(id.data[i].pop(remove_index))
    id.columns -= 1
    return removed_col


def swap_rows(id: PineMatrix, row1: int, row2: int) -> None:
    if row1 < 0 or row1 >= id.rows:
        raise ValueError(f"Row1 index out of bounds: {row1} for matrix with {id.rows} rows")
    if row2 < 0 or row2 >= id.rows:
        raise ValueError(f"Row2 index out of bounds: {row2} for matrix with {id.rows} rows")
    id.data[row1], id.data[row2] = id.data[row2], id.data[row1]


def swap_columns(id: PineMatrix, column1: int, column2: int) -> None:
    if column1 < 0 or column1 >= id.columns:
        raise ValueError(f"Column1 index out of bounds: {column1} for matrix with {id.columns} columns")
    if column2 < 0 or column2 >= id.columns:
        raise ValueError(f"Column2 index out of bounds: {column2} for matrix with {id.columns} columns")
    for i in range(id.rows):
        id.data[i][column1], id.data[i][column2] = id.data[i][column2], id.data[i][column1]


# ==========================================
# Matrix Transformations
# ==========================================


def transpose(id: PineMatrix) -> PineMatrix:
    new_data: list[list[Any]] = []
    for j in range(id.columns):
        new_row: list[Any] = []
        for i in range(id.rows):
            new_row.append(id.data[i][j])
        new_data.append(new_row)
    return PineMatrix(rows=id.columns, columns=id.rows, data=new_data)


def concat(id1: PineMatrix, id2: PineMatrix) -> PineMatrix:
    if id1.columns != id2.columns:
        raise ValueError(f"Column count mismatch: {id1.columns} vs {id2.columns}")
    for i in range(id2.rows):
        id1.data.append(list(id2.data[i]))
    id1.rows += id2.rows
    return id1


def submatrix(
    id: PineMatrix,
    from_row: int = 0,
    to_row: int | None = None,
    from_column: int = 0,
    to_column: int | None = None,
) -> PineMatrix:
    end_row = to_row if to_row is not None else id.rows
    end_col = to_column if to_column is not None else id.columns

    if from_row < 0 or from_row > id.rows:
        raise ValueError(f"from_row index out of bounds: {from_row}")
    if end_row < 0 or end_row > id.rows:
        raise ValueError(f"to_row index out of bounds: {end_row}")
    if from_column < 0 or from_column > id.columns:
        raise ValueError(f"from_column index out of bounds: {from_column}")
    if end_col < 0 or end_col > id.columns:
        raise ValueError(f"to_column index out of bounds: {end_col}")

    new_rows = end_row - from_row
    new_cols = end_col - from_column
    new_data: list[list[Any]] = []

    for i in range(from_row, end_row):
        new_row: list[Any] = []
        for j in range(from_column, end_col):
            new_row.append(id.data[i][j])
        new_data.append(new_row)

    return PineMatrix(rows=new_rows, columns=new_cols, data=new_data)


def reshape(id: PineMatrix, rows_count: int, columns_count: int) -> None:
    total_elements = id.rows * id.columns
    new_total_elements = rows_count * columns_count

    if total_elements != new_total_elements:
        raise ValueError(
            f"Cannot reshape {id.rows}x{id.columns} ({total_elements} elements) "
            f"to {rows_count}x{columns_count} ({new_total_elements} elements)"
        )

    flat: list[Any] = []
    for i in range(id.rows):
        for j in range(id.columns):
            flat.append(id.data[i][j])

    new_data: list[list[Any]] = []
    index = 0
    for i in range(rows_count):
        new_row: list[Any] = []
        for j in range(columns_count):
            new_row.append(flat[index])
            index += 1
        new_data.append(new_row)

    id.rows = rows_count
    id.columns = columns_count
    id.data = new_data


def reverse(id: PineMatrix) -> None:
    id.data.reverse()
    for i in range(id.rows):
        id.data[i].reverse()


def sort(id: PineMatrix, column: int = 0, order: str = "ascending") -> None:
    if column < 0 or column >= id.columns:
        raise ValueError(f"Column index out of bounds: {column} for matrix with {id.columns} columns")

    def sort_key(a_row: list[Any]) -> Any:
        val = a_row[column]
        if isinstance(val, (int, float)):
            return val
        return val

    reverse_flag = order == "descending"
    id.data.sort(key=sort_key, reverse=reverse_flag)


# ==========================================
# Element-wise Arithmetic
# ==========================================


def sum(id1: PineMatrix, id2: PineMatrix | float | int) -> PineMatrix:
    new_data: list[list[float]] = []

    if isinstance(id2, (int, float)):
        for i in range(id1.rows):
            new_row: list[float] = []
            for j in range(id1.columns):
                new_row.append(id1.data[i][j] + id2)
            new_data.append(new_row)
        return PineMatrix(rows=id1.rows, columns=id1.columns, data=new_data)
    else:
        if id1.rows != id2.rows or id1.columns != id2.columns:
            raise ValueError(
                f"Matrix dimensions must match: {id1.rows}x{id1.columns} vs {id2.rows}x{id2.columns}"
            )
        for i in range(id1.rows):
            new_row = []
            for j in range(id1.columns):
                new_row.append(id1.data[i][j] + id2.data[i][j])
            new_data.append(new_row)
        return PineMatrix(rows=id1.rows, columns=id1.columns, data=new_data)


def diff(id1: PineMatrix, id2: PineMatrix | float | int) -> PineMatrix:
    new_data: list[list[float]] = []

    if isinstance(id2, (int, float)):
        for i in range(id1.rows):
            new_row: list[float] = []
            for j in range(id1.columns):
                new_row.append(id1.data[i][j] - id2)
            new_data.append(new_row)
        return PineMatrix(rows=id1.rows, columns=id1.columns, data=new_data)
    else:
        if id1.rows != id2.rows or id1.columns != id2.columns:
            raise ValueError(
                f"Matrix dimensions must match: {id1.rows}x{id1.columns} vs {id2.rows}x{id2.columns}"
            )
        for i in range(id1.rows):
            new_row = []
            for j in range(id1.columns):
                new_row.append(id1.data[i][j] - id2.data[i][j])
            new_data.append(new_row)
        return PineMatrix(rows=id1.rows, columns=id1.columns, data=new_data)


# ==========================================
# Statistical Functions
# ==========================================


def _is_valid_number(val: Any) -> bool:
    if val is None:
        return False
    if isinstance(val, float) and math.isnan(val):
        return False
    return isinstance(val, (int, float))


def avg(id: PineMatrix) -> float:
    if id.rows == 0 or id.columns == 0:
        return float("nan")

    total = 0.0
    count = 0
    for i in range(id.rows):
        for j in range(id.columns):
            val = id.data[i][j]
            if _is_valid_number(val):
                total += val
                count += 1

    return float("nan") if count == 0 else total / count


def min(id: PineMatrix) -> float:
    if id.rows == 0 or id.columns == 0:
        return float("nan")

    min_val = float("inf")
    for i in range(id.rows):
        for j in range(id.columns):
            val = id.data[i][j]
            if _is_valid_number(val) and val < min_val:
                min_val = val

    return float("nan") if min_val == float("inf") else min_val


def max(id: PineMatrix) -> float:
    if id.rows == 0 or id.columns == 0:
        return float("nan")

    max_val = float("-inf")
    for i in range(id.rows):
        for j in range(id.columns):
            val = id.data[i][j]
            if _is_valid_number(val) and val > max_val:
                max_val = val

    return float("nan") if max_val == float("-inf") else max_val


def median(id: PineMatrix) -> float:
    if id.rows == 0 or id.columns == 0:
        return float("nan")

    values: list[float] = []
    for i in range(id.rows):
        for j in range(id.columns):
            val = id.data[i][j]
            if _is_valid_number(val):
                values.append(val)

    if len(values) == 0:
        return float("nan")

    values.sort()
    mid = len(values) // 2

    if len(values) % 2 == 0:
        return (values[mid - 1] + values[mid]) / 2
    else:
        return values[mid]


def mode(id: PineMatrix) -> float:
    if id.rows == 0 or id.columns == 0:
        return float("nan")

    frequency: dict[float, int] = {}
    max_freq = 0
    mode_value = float("nan")

    for i in range(id.rows):
        for j in range(id.columns):
            val = id.data[i][j]
            if _is_valid_number(val):
                freq = frequency.get(val, 0) + 1
                frequency[val] = freq
                if freq > max_freq or (freq == max_freq and (math.isnan(mode_value) or val < mode_value)):
                    max_freq = freq
                    mode_value = val

    return mode_value


def trace(id: PineMatrix) -> float:
    if not is_square(id):
        raise ValueError(f"Matrix must be square for trace calculation: {id.rows}x{id.columns}")

    if id.rows == 0:
        return 0.0

    total = 0.0
    for i in range(id.rows):
        val = id.data[i][i]
        if _is_valid_number(val):
            total += val

    return total


# ==========================================
# Boolean Checks
# ==========================================


def is_diagonal(id: PineMatrix) -> bool:
    if not is_square(id):
        return False

    for i in range(id.rows):
        for j in range(id.columns):
            if i != j and id.data[i][j] != 0:
                return False

    return True


def is_identity(id: PineMatrix) -> bool:
    if not is_square(id):
        return False

    for i in range(id.rows):
        for j in range(id.columns):
            val = id.data[i][j]
            if i == j:
                if val != 1:
                    return False
            else:
                if val != 0:
                    return False

    return True


def is_symmetric(id: PineMatrix) -> bool:
    if not is_square(id):
        return False

    for i in range(id.rows):
        for j in range(i + 1, id.columns):
            if id.data[i][j] != id.data[j][i]:
                return False

    return True


def is_antisymmetric(id: PineMatrix) -> bool:
    if not is_square(id):
        return False

    for i in range(id.rows):
        if id.data[i][i] != 0:
            return False
        for j in range(i + 1, id.columns):
            upper_val = id.data[i][j]
            lower_val = id.data[j][i]
            if upper_val != -lower_val:
                return False

    return True


def is_triangular(id: PineMatrix) -> bool:
    if not is_square(id):
        return False

    is_upper = True
    for i in range(1, id.rows):
        if not is_upper:
            break
        for j in range(0, i):
            if id.data[i][j] != 0:
                is_upper = False
                break

    if is_upper:
        return True

    is_lower = True
    for i in range(0, id.rows - 1):
        if not is_lower:
            break
        for j in range(i + 1, id.columns):
            if id.data[i][j] != 0:
                is_lower = False
                break

    return is_lower


def is_antidiagonal(id: PineMatrix) -> bool:
    if not is_square(id):
        return False

    n = id.rows
    for i in range(n):
        for j in range(n):
            is_anti_diag = (i + j == n - 1)
            if not is_anti_diag and id.data[i][j] != 0:
                return False

    return True


def is_stochastic(id: PineMatrix) -> bool:
    if id.rows == 0 or id.columns == 0:
        return False

    tolerance = 1e-10

    for i in range(id.rows):
        row_sum = 0.0
        for j in range(id.columns):
            val = id.data[i][j]
            if val < 0:
                return False
            row_sum += val
        if abs(row_sum - 1) > tolerance:
            return False

    return True


# ==========================================
# Linear Algebra Functions
# ==========================================


def _create_identity(n: int) -> PineMatrix:
    m = new_matrix(n, n, 0.0)
    for i in range(n):
        m.data[i][i] = 1.0
    return m


def mult(id1: PineMatrix, id2: PineMatrix | float | int | list[float]) -> PineMatrix | list[float]:
    if isinstance(id2, (int, float)):
        new_data: list[list[float]] = []
        for i in range(id1.rows):
            new_row: list[float] = []
            for j in range(id1.columns):
                new_row.append(id1.data[i][j] * id2)
            new_data.append(new_row)
        return PineMatrix(rows=id1.rows, columns=id1.columns, data=new_data)

    if isinstance(id2, list):
        vec = id2
        if len(vec) != id1.columns:
            raise ValueError(f"Vector length {len(vec)} must equal matrix columns {id1.columns}")
        result: list[float] = []
        for i in range(id1.rows):
            s = 0.0
            for j in range(id1.columns):
                s += id1.data[i][j] * vec[j]
            result.append(s)
        return result

    m2 = id2
    if id1.columns != m2.rows:
        raise ValueError(
            f"Matrix multiplication dimension mismatch: {id1.rows}x{id1.columns} x {m2.rows}x{m2.columns}. "
            f"First matrix columns ({id1.columns}) must equal second matrix rows ({m2.rows})"
        )

    new_rows = id1.rows
    new_cols = m2.columns
    new_data_m: list[list[float]] = []

    for i in range(new_rows):
        new_row_m: list[float] = []
        for j in range(new_cols):
            s = 0.0
            for k in range(id1.columns):
                s += id1.data[i][k] * m2.data[k][j]
            new_row_m.append(s)
        new_data_m.append(new_row_m)

    return PineMatrix(rows=new_rows, columns=new_cols, data=new_data_m)


def pow(id: PineMatrix, power: int) -> PineMatrix:
    if not is_square(id):
        raise ValueError(f"Matrix must be square for power calculation: {id.rows}x{id.columns}")

    n = id.rows

    if power == 0:
        return _create_identity(n)

    if power < 0:
        inverse = inv(id)
        if inverse is None:
            raise ValueError("Cannot compute negative power of singular matrix")
        base = inverse
        p = -power
    else:
        base = copy_matrix(id)
        p = power

    result = _create_identity(n)

    while p > 0:
        if p % 2 == 1:
            result = mult(result, base)  # type: ignore[assignment]
        base = mult(base, base)  # type: ignore[assignment]
        p = p // 2

    return result  # type: ignore[return-value]


def det(id: PineMatrix) -> float:
    if not is_square(id):
        raise ValueError(f"Matrix must be square for determinant calculation: {id.rows}x{id.columns}")

    n = id.rows

    if n == 0:
        return 1.0

    if n == 1:
        return float(id.data[0][0])

    if n == 2:
        return float(id.data[0][0] * id.data[1][1] - id.data[0][1] * id.data[1][0])

    a: list[list[float]] = [list(r) for r in id.data]
    determinant = 1.0
    swap_count = 0

    for col_idx in range(n):
        max_row = col_idx
        max_val = abs(a[col_idx][col_idx])
        for row_idx in range(col_idx + 1, n):
            abs_val = abs(a[row_idx][col_idx])
            if abs_val > max_val:
                max_val = abs_val
                max_row = row_idx

        if max_row != col_idx:
            a[col_idx], a[max_row] = a[max_row], a[col_idx]
            swap_count += 1

        pivot = a[col_idx][col_idx]
        if abs(pivot) < EPSILON:
            return 0.0

        determinant *= pivot

        for row_idx in range(col_idx + 1, n):
            factor = a[row_idx][col_idx] / pivot
            for j in range(col_idx, n):
                a[row_idx][j] = a[row_idx][j] - factor * a[col_idx][j]

    if swap_count % 2 == 1:
        determinant = -determinant

    return determinant


def inv(id: PineMatrix) -> PineMatrix | None:
    if not is_square(id):
        raise ValueError(f"Matrix must be square for inverse calculation: {id.rows}x{id.columns}")

    n = id.rows

    if n == 0:
        return new_matrix(0, 0, 0.0)

    aug: list[list[float]] = []
    for i in range(n):
        row_data: list[float] = []
        for j in range(n):
            row_data.append(float(id.data[i][j]))
        for j in range(n):
            row_data.append(1.0 if i == j else 0.0)
        aug.append(row_data)

    for col_idx in range(n):
        max_row = col_idx
        max_val = abs(aug[col_idx][col_idx])
        for row_idx in range(col_idx + 1, n):
            abs_val = abs(aug[row_idx][col_idx])
            if abs_val > max_val:
                max_val = abs_val
                max_row = row_idx

        if max_row != col_idx:
            aug[col_idx], aug[max_row] = aug[max_row], aug[col_idx]

        pivot = aug[col_idx][col_idx]
        if abs(pivot) < EPSILON:
            return None

        for j in range(2 * n):
            aug[col_idx][j] = aug[col_idx][j] / pivot

        for row_idx in range(n):
            if row_idx != col_idx:
                factor = aug[row_idx][col_idx]
                for j in range(2 * n):
                    aug[row_idx][j] = aug[row_idx][j] - factor * aug[col_idx][j]

    inverse_data: list[list[float]] = []
    for i in range(n):
        row_data = []
        for j in range(n):
            row_data.append(aug[i][n + j])
        inverse_data.append(row_data)

    return PineMatrix(rows=n, columns=n, data=inverse_data)


def pinv(id: PineMatrix) -> PineMatrix:
    m = id.rows
    n = id.columns

    if m == 0 or n == 0:
        return new_matrix(n, m, 0.0)

    if m == n:
        inverse = inv(id)
        if inverse is not None:
            return inverse

    at = transpose(id)

    if m >= n:
        ata = mult(at, id)
        ata_inv = inv(ata)  # type: ignore[arg-type]
        if ata_inv is not None:
            return mult(ata_inv, at)  # type: ignore[return-value]

    aat = mult(id, at)
    aat_inv = inv(aat)  # type: ignore[arg-type]
    if aat_inv is not None:
        return mult(at, aat_inv)  # type: ignore[return-value]

    lam = 1e-10
    ata = mult(at, id)
    for i in range(ata.rows):  # type: ignore[union-attr]
        ata.data[i][i] = ata.data[i][i] + lam  # type: ignore[union-attr]

    ata_inv = inv(ata)  # type: ignore[arg-type]
    if ata_inv is not None:
        return mult(ata_inv, at)  # type: ignore[return-value]

    return new_matrix(n, m, 0.0)


def rank(id: PineMatrix) -> int:
    if id.rows == 0 or id.columns == 0:
        return 0

    a: list[list[float]] = [list(r) for r in id.data]
    m = id.rows
    n = id.columns

    r = 0

    for col_idx in range(n):
        if r >= m:
            break

        max_row = r
        max_val = abs(a[r][col_idx])
        for row_idx in range(r + 1, m):
            abs_val = abs(a[row_idx][col_idx])
            if abs_val > max_val:
                max_val = abs_val
                max_row = row_idx

        if max_val < EPSILON:
            continue

        if max_row != r:
            a[r], a[max_row] = a[max_row], a[r]

        pivot = a[r][col_idx]
        for row_idx in range(r + 1, m):
            factor = a[row_idx][col_idx] / pivot
            for j in range(col_idx, n):
                a[row_idx][j] = a[row_idx][j] - factor * a[r][j]

        r += 1

    return r


def eigenvalues(id: PineMatrix) -> list[float]:
    if not is_square(id):
        raise ValueError(f"Matrix must be square for eigenvalue calculation: {id.rows}x{id.columns}")

    n = id.rows

    if n == 0:
        return []

    if n == 1:
        return [float(id.data[0][0])]

    if n == 2:
        a = id.data[0][0]
        b = id.data[0][1]
        c = id.data[1][0]
        d = id.data[1][1]

        tr = a + d
        determinant = a * d - b * c
        discriminant = tr * tr - 4 * determinant

        if discriminant >= 0:
            sqrt_disc = math.sqrt(discriminant)
            return [(tr + sqrt_disc) / 2, (tr - sqrt_disc) / 2]
        else:
            return [tr / 2, tr / 2]

    h = _to_hessenberg(id)
    result = _qr_algorithm(h, 100)
    return result


def _to_hessenberg(m: PineMatrix) -> PineMatrix:
    n = m.rows
    h: list[list[float]] = [list(r) for r in m.data]

    for k in range(n - 2):
        max_val = 0.0
        for i in range(k + 1, n):
            max_val = builtins_max(max_val, abs(h[i][k]))

        if max_val < EPSILON:
            continue

        sigma = 0.0
        for i in range(k + 1, n):
            sigma += h[i][k] * h[i][k]
        sigma = math.sqrt(sigma)

        if h[k + 1][k] < 0:
            sigma = -sigma

        u: list[float] = [0.0] * n
        u[k + 1] = h[k + 1][k] + sigma
        for i in range(k + 2, n):
            u[i] = h[i][k]

        u_tu = 0.0
        for i in range(k + 1, n):
            u_tu += u[i] * u[i]

        if u_tu < EPSILON:
            continue

        for j in range(k, n):
            dot = 0.0
            for i in range(k + 1, n):
                dot += u[i] * h[i][j]
            factor = 2 * dot / u_tu
            for i in range(k + 1, n):
                h[i][j] = h[i][j] - factor * u[i]

        for i in range(n):
            dot = 0.0
            for j in range(k + 1, n):
                dot += h[i][j] * u[j]
            factor = 2 * dot / u_tu
            for j in range(k + 1, n):
                h[i][j] = h[i][j] - factor * u[j]

    return PineMatrix(rows=n, columns=n, data=h)


def _qr_algorithm(h: PineMatrix, max_iter: int) -> list[float]:
    n = h.rows
    a: list[list[float]] = [list(r) for r in h.data]
    eigenvals: list[float] = []

    remaining = n

    for _iter in range(max_iter):
        if remaining <= 1:
            break

        converged = False
        for i in range(remaining - 1, 0, -1):
            if abs(a[i][i - 1]) < EPSILON * (abs(a[i - 1][i - 1]) + abs(a[i][i])):
                a[i][i - 1] = 0.0
                if i == remaining - 1:
                    eigenvals.append(a[remaining - 1][remaining - 1])
                    remaining -= 1
                    converged = True
                    break

        if converged:
            continue
        if remaining <= 1:
            break

        d = (a[remaining - 2][remaining - 2] - a[remaining - 1][remaining - 1]) / 2
        sign = 1 if d >= 0 else -1
        sub_diag_sq = a[remaining - 1][remaining - 2] * a[remaining - 1][remaining - 2]
        mu = a[remaining - 1][remaining - 1] - sign * sub_diag_sq / (abs(d) + math.sqrt(d * d + sub_diag_sq))

        x = a[0][0] - mu
        z = a[1][0]

        for k in range(remaining - 1):
            r = math.sqrt(x * x + z * z)
            if r < EPSILON:
                r = EPSILON
            c = x / r
            s = z / r

            for j in range(builtins_max(0, k - 1), remaining):
                temp = c * a[k][j] + s * a[k + 1][j]
                a[k + 1][j] = -s * a[k][j] + c * a[k + 1][j]
                a[k][j] = temp

            for i in range(builtins_min(k + 3, remaining)):
                temp = c * a[i][k] + s * a[i][k + 1]
                a[i][k + 1] = -s * a[i][k] + c * a[i][k + 1]
                a[i][k] = temp

            if k < remaining - 2:
                x = a[k + 1][k]
                z = a[k + 2][k]

    for i in range(remaining):
        eigenvals.append(a[i][i])

    eigenvals.sort(key=lambda v: abs(v), reverse=True)
    return eigenvals


def eigenvectors(id: PineMatrix) -> PineMatrix:
    if not is_square(id):
        raise ValueError(f"Matrix must be square for eigenvector calculation: {id.rows}x{id.columns}")

    n = id.rows

    if n == 0:
        return new_matrix(0, 0, 0.0)

    evals = eigenvalues(id)

    vectors: list[list[float]] = []
    for i in range(n):
        lam = evals[i]
        vec = _inverse_iteration(id, lam)
        vectors.append(vec)

    result_data: list[list[float]] = []
    for i in range(n):
        row_data: list[float] = []
        for j in range(n):
            row_data.append(vectors[j][i])
        result_data.append(row_data)

    return PineMatrix(rows=n, columns=n, data=result_data)


def _inverse_iteration(m: PineMatrix, lam: float) -> list[float]:
    n = m.rows

    shifted: list[list[float]] = []
    for i in range(n):
        row_data: list[float] = []
        for j in range(n):
            val = m.data[i][j]
            if i == j:
                val = val - lam
            row_data.append(float(val))
        shifted.append(row_data)

    for i in range(n):
        if abs(shifted[i][i]) < EPSILON:
            shifted[i][i] = EPSILON

    v: list[float] = [1.0] * n

    for _iter in range(50):
        w = _solve_linear_system(shifted, v)

        norm = 0.0
        for i in range(n):
            norm += w[i] * w[i]
        norm = math.sqrt(norm)

        if norm < EPSILON:
            return v

        new_v: list[float] = []
        for i in range(n):
            new_v.append(w[i] / norm)

        diff_val = 0.0
        for i in range(n):
            diff_val += abs(abs(new_v[i]) - abs(v[i]))

        v = new_v

        if diff_val < EPSILON:
            break

    return v


def _solve_linear_system(a: list[list[float]], b: list[float]) -> list[float]:
    n = len(a)

    aug: list[list[float]] = []
    for i in range(n):
        aug.append(list(a[i]) + [b[i]])

    for col_idx in range(n):
        max_row = col_idx
        max_val = abs(aug[col_idx][col_idx])
        for row_idx in range(col_idx + 1, n):
            abs_val = abs(aug[row_idx][col_idx])
            if abs_val > max_val:
                max_val = abs_val
                max_row = row_idx

        if max_row != col_idx:
            aug[col_idx], aug[max_row] = aug[max_row], aug[col_idx]

        pivot = aug[col_idx][col_idx]
        if abs(pivot) < EPSILON:
            continue

        for row_idx in range(col_idx + 1, n):
            factor = aug[row_idx][col_idx] / pivot
            for j in range(col_idx, n + 1):
                aug[row_idx][j] = aug[row_idx][j] - factor * aug[col_idx][j]

    x: list[float] = [0.0] * n
    for i in range(n - 1, -1, -1):
        s = aug[i][n]
        for j in range(i + 1, n):
            s -= aug[i][j] * x[j]
        diag = aug[i][i]
        x[i] = 0.0 if abs(diag) < EPSILON else s / diag

    return x


def kron(id1: PineMatrix, id2: PineMatrix) -> PineMatrix:
    m1 = id1.rows
    n1 = id1.columns
    m2 = id2.rows
    n2 = id2.columns

    result_rows = m1 * m2
    result_cols = n1 * n2
    data: list[list[float]] = []

    for i in range(result_rows):
        data.append([0.0] * result_cols)

    for i1 in range(m1):
        for j1 in range(n1):
            a = id1.data[i1][j1]
            for i2 in range(m2):
                for j2 in range(n2):
                    r = i1 * m2 + i2
                    c = j1 * n2 + j2
                    data[r][c] = a * id2.data[i2][j2]

    return PineMatrix(rows=result_rows, columns=result_cols, data=data)


def newtype(rows_count: int = 0, columns_count: int = 0, initial_value: Any = None) -> PineMatrix:
    return new_matrix(rows_count, columns_count, initial_value)
