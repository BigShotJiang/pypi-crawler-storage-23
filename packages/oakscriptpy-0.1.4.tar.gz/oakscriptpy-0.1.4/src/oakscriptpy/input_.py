"""Input helper — creates InputValue dataclass instances."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class InputValue:
    type: str
    default_value: Any
    value: Any
    title: str | None = None
    min: float | None = None
    max: float | None = None
    step: float | None = None
    options: list[str] | None = None


def int_(default_value: int, title: str | None = None, min: int | None = None, max: int | None = None, step: int = 1) -> InputValue:
    return InputValue(type="int", default_value=default_value, value=default_value, title=title, min=float(min) if min is not None else None, max=float(max) if max is not None else None, step=float(step))


def float_(default_value: float, title: str | None = None, min: float | None = None, max: float | None = None, step: float = 0.1) -> InputValue:
    return InputValue(type="float", default_value=default_value, value=default_value, title=title, min=min, max=max, step=step)


def source(default_value: str = "close", title: str | None = None) -> InputValue:
    return InputValue(type="source", default_value=default_value, value=default_value, title=title, options=["open", "high", "low", "close", "hl2", "hlc3", "ohlc4", "hlcc4"])


def bool_(default_value: bool, title: str | None = None) -> InputValue:
    return InputValue(type="bool", default_value=default_value, value=default_value, title=title)


def string(default_value: str, title: str | None = None, options: list[str] | None = None) -> InputValue:
    return InputValue(type="string", default_value=default_value, value=default_value, title=title, options=options)
