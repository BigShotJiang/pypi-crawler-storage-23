"""Simple in-memory input adapter for demos and testing."""

from __future__ import annotations

import math
from typing import Any, Callable

from ..runtime_types import InputConfig


class SimpleInputAdapter:
    """Stores input configurations and values in memory."""

    def __init__(self) -> None:
        self._inputs: dict[str, dict[str, Any]] = {}
        self._change_callbacks: list[Callable[[str, Any], None]] = []

    def register_input(self, config: InputConfig) -> Any:
        if config.id not in self._inputs:
            self._inputs[config.id] = {"config": config, "value": config.defval}
        return self._inputs[config.id]["value"]

    def get_value(self, id: str) -> Any:
        entry = self._inputs.get(id)
        return entry["value"] if entry is not None else None

    def set_value(self, id: str, value: Any) -> None:
        entry = self._inputs.get(id)
        if entry is None:
            return

        config: InputConfig = entry["config"]
        validated = value

        if config.type in ("int", "float") and isinstance(value, (int, float)):
            if config.min is not None and value < config.min:
                validated = config.min
            if config.max is not None and value > config.max:
                validated = config.max
            if config.type == "int":
                validated = int(validated)

        if config.type == "string" and config.options and isinstance(value, str):
            if value not in config.options:
                return

        if config.type == "source" and config.options and isinstance(value, str):
            if value not in config.options:
                return

        entry["value"] = validated
        for cb in self._change_callbacks:
            cb(id, validated)

    def on_input_change(self, callback: Callable[[str, Any], None]) -> None:
        self._change_callbacks.append(callback)

    def get_all_inputs(self) -> dict[str, dict[str, Any]]:
        return dict(self._inputs)

    def clear(self) -> None:
        self._inputs.clear()
        self._change_callbacks.clear()
