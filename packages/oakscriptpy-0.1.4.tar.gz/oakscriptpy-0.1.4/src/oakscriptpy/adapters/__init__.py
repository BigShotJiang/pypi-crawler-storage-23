"""Adapter implementations."""

from .simple_input import SimpleInputAdapter

__all__ = ["SimpleInputAdapter"]
