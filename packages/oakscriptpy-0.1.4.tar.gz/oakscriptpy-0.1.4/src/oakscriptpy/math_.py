"""Math namespace — mirrors PineScript math.* functions (scalar-only initially)."""

from __future__ import annotations

import math as _math
import random as _random

pi = _math.pi
e = _math.e
phi = 1.618033988749895
rphi = 0.618033988749895


def abs(value: float) -> float:
    return _math.fabs(value)


def ceil(value: float) -> int:
    return _math.ceil(value)


def floor(value: float) -> int:
    return _math.floor(value)


def round(value: float, precision: int | None = None) -> float:
    if precision is None:
        return builtins_round(value)
    multiplier = 10 ** precision
    return builtins_round(value * multiplier) / multiplier


builtins_round = __builtins__["round"] if isinstance(__builtins__, dict) else getattr(__builtins__, "round")


def max(*values: float) -> float:
    return builtins_max(values)


builtins_max = __builtins__["max"] if isinstance(__builtins__, dict) else getattr(__builtins__, "max")


def min(*values: float) -> float:
    return builtins_min(values)


builtins_min = __builtins__["min"] if isinstance(__builtins__, dict) else getattr(__builtins__, "min")


def avg(*values: float) -> float:
    return builtins_sum(values) / len(values)


builtins_sum = __builtins__["sum"] if isinstance(__builtins__, dict) else getattr(__builtins__, "sum")


def sum(source: list[float], length: int) -> list[float]:
    result: list[float] = []
    for i in range(len(source)):
        if i < length - 1:
            result.append(float("nan"))
        else:
            total = 0.0
            for j in range(length):
                total += source[i - j]
            result.append(total)
    return result


def sqrt(value: float) -> float:
    return _math.sqrt(value)


def pow(base: float, exponent: float) -> float:
    return base ** exponent


def exp(value: float) -> float:
    return _math.exp(value)


def log(value: float) -> float:
    return _math.log(value)


def log10(value: float) -> float:
    return _math.log10(value)


def log2(value: float) -> float:
    return _math.log2(value)


def sin(value: float) -> float:
    return _math.sin(value)


def cos(value: float) -> float:
    return _math.cos(value)


def tan(value: float) -> float:
    return _math.tan(value)


def asin(value: float) -> float:
    return _math.asin(value)


def acos(value: float) -> float:
    return _math.acos(value)


def atan(value: float) -> float:
    return _math.atan(value)


def atan2(y: float, x: float) -> float:
    return _math.atan2(y, x)


def sinh(value: float) -> float:
    return _math.sinh(value)


def cosh(value: float) -> float:
    return _math.cosh(value)


def tanh(value: float) -> float:
    return _math.tanh(value)


def toradians(degrees: float) -> float:
    return degrees * (_math.pi / 180)


def todegrees(radians: float) -> float:
    return radians * (180 / _math.pi)


def random(min_val: float | None = None, max_val: float | None = None, _seed: int | None = None) -> float:
    rand = _random.random()
    if min_val is not None and max_val is not None:
        return min_val + rand * (max_val - min_val)
    return rand


def sign(value: float) -> int:
    if value > 0:
        return 1
    if value < 0:
        return -1
    return 0


def round_to_mintick(number: float, mintick: float | None = None) -> float:
    if _math.isnan(number):
        return float("nan")
    if mintick is None:
        raise ValueError("math.round_to_mintick() requires mintick value.")
    if mintick == 0:
        return number
    return builtins_round(number / mintick) * mintick


def factorial(n: int) -> int:
    return _math.factorial(n)


def combination(n: int, k: int) -> int:
    return _math.comb(n, k)


def permutation(n: int, k: int) -> int:
    return _math.perm(n, k)


def gcd(a: int, b: int) -> int:
    return _math.gcd(a, b)


def lcm(a: int, b: int) -> int:
    return _math.lcm(a, b)
