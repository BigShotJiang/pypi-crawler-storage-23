"""Array namespace — mirrors PineScript array.* functions."""

from __future__ import annotations

import math
from typing import Any, Callable, TypeVar

T = TypeVar("T")


def new_array(size: int = 0, initial_value: Any = None) -> list:
    return [initial_value] * size


def size(id: list) -> int:
    return len(id)


def get(id: list, index: int) -> Any:
    return id[index]


def set(id: list, index: int, value: Any) -> None:
    id[index] = value


def push(id: list, value: Any) -> None:
    id.append(value)


def pop(id: list) -> Any:
    return id.pop()


def unshift(id: list, value: Any) -> None:
    id.insert(0, value)


def shift(id: list) -> Any:
    return id.pop(0)


def clear(id: list) -> None:
    id.clear()


def insert(id: list, index: int, value: Any) -> None:
    id.insert(index, value)


def remove(id: list, index: int) -> Any:
    return id.pop(index)


def includes(id: list, value: Any) -> bool:
    return value in id


def indexof(id: list, value: Any) -> int:
    try:
        return id.index(value)
    except ValueError:
        return -1


def lastindexof(id: list, value: Any) -> int:
    for i in range(len(id) - 1, -1, -1):
        if id[i] == value:
            return i
    return -1


def copy(id: list) -> list:
    return id[:]


def concat(id1: list, id2: list) -> list:
    return id1 + id2


def join(id: list, separator: str = ",") -> str:
    return separator.join(str(x) for x in id)


def reverse(id: list) -> None:
    id.reverse()


def slice(id: list, index_from: int, index_to: int | None = None) -> list:
    return id[index_from:index_to]


def sort(id: list, order: str = "asc") -> None:
    id.sort(reverse=(order == "desc"))


def sum(id: list[float]) -> float:
    return builtins_sum(id)


builtins_sum = __builtins__["sum"] if isinstance(__builtins__, dict) else getattr(__builtins__, "sum")


def avg(id: list[float]) -> float:
    return sum(id) / len(id)


def min(id: list[float]) -> float:
    return builtins_min(id)


builtins_min = __builtins__["min"] if isinstance(__builtins__, dict) else getattr(__builtins__, "min")


def max(id: list[float]) -> float:
    return builtins_max(id)


builtins_max = __builtins__["max"] if isinstance(__builtins__, dict) else getattr(__builtins__, "max")


def median(id: list[float]) -> float:
    sorted_arr = sorted(id)
    mid = len(sorted_arr) // 2
    if len(sorted_arr) % 2 == 0:
        return (sorted_arr[mid - 1] + sorted_arr[mid]) / 2
    return sorted_arr[mid]


def mode(id: list[float]) -> float:
    frequency: dict[float, int] = {}
    max_freq = 0
    result = id[0]
    for val in id:
        freq = frequency.get(val, 0) + 1
        frequency[val] = freq
        if freq > max_freq:
            max_freq = freq
            result = val
    return result


def stdev(id: list[float]) -> float:
    mean = avg(id)
    square_diffs = [(v - mean) ** 2 for v in id]
    return math.sqrt(builtins_sum(square_diffs) / len(id))


def variance(id: list[float]) -> float:
    mean = avg(id)
    square_diffs = [(v - mean) ** 2 for v in id]
    return builtins_sum(square_diffs) / len(id)


def fill(id: list, value: Any, index_from: int = 0, index_to: int | None = None) -> None:
    end = index_to if index_to is not None else len(id)
    for i in range(index_from, end):
        id[i] = value


def from_array(id: list) -> list:
    return copy(id)


def first(id: list) -> Any:
    return id[0]


def last(id: list) -> Any:
    return id[-1]


def some(id: list, predicate: Callable) -> bool:
    return any(predicate(x) for x in id)


def every(id: list, predicate: Callable) -> bool:
    return all(predicate(x) for x in id)


def new_bool(size: int = 0, initial_value: bool = False) -> list[bool]:
    return new_array(size, initial_value)


def new_float(size: int = 0, initial_value: float = float("nan")) -> list[float]:
    return new_array(size, initial_value)


def new_int(size: int = 0, initial_value: int | float = float("nan")) -> list:
    return new_array(size, initial_value)


def new_string(size: int = 0, initial_value: str | None = None) -> list:
    return new_array(size, initial_value)


def new_color(size: int = 0, initial_value: Any = None) -> list:
    return new_array(size, initial_value)


def new_line(size: int = 0, initial_value: Any = None) -> list:
    return new_array(size, initial_value)


def new_box(size: int = 0, initial_value: Any = None) -> list:
    return new_array(size, initial_value)


def new_label(size: int = 0, initial_value: Any = None) -> list:
    return new_array(size, initial_value)


def new_linefill(size: int = 0, initial_value: Any = None) -> list:
    return new_array(size, initial_value)


def abs(id: list[float]) -> list[float]:
    return [builtins_abs(x) for x in id]


builtins_abs = __builtins__["abs"] if isinstance(__builtins__, dict) else getattr(__builtins__, "abs")


def range(id: list[float]) -> float:
    if len(id) == 0:
        return float("nan")
    return max(id) - min(id)


def binary_search(id: list[float], val: float) -> int:
    left, right = 0, len(id) - 1
    while left <= right:
        mid = (left + right) // 2
        if id[mid] == val:
            return mid
        if id[mid] < val:
            left = mid + 1
        else:
            right = mid - 1
    return -1


def binary_search_leftmost(id: list[float], val: float) -> int:
    left, right = 0, len(id) - 1
    result = -1
    found = False
    while left <= right:
        mid = (left + right) // 2
        if id[mid] < val:
            if not found:
                result = mid
            left = mid + 1
        elif id[mid] == val:
            result = mid
            found = True
            right = mid - 1
        else:
            right = mid - 1
    return result


def binary_search_rightmost(id: list[float], val: float) -> int:
    left, right = 0, len(id) - 1
    result = -1
    found = False
    while left <= right:
        mid = (left + right) // 2
        if id[mid] <= val:
            if id[mid] == val:
                result = mid
                found = True
            left = mid + 1
        else:
            if not found:
                result = mid
            right = mid - 1
    return result


def covariance(id1: list[float], id2: list[float], biased: bool = True) -> float:
    if not id1 or not id2 or len(id1) != len(id2):
        return float("nan")
    n = len(id1)
    mean1 = avg(id1)
    mean2 = avg(id2)
    total = builtins_sum((id1[i] - mean1) * (id2[i] - mean2) for i in builtins_range(n))
    divisor = n if biased else n - 1
    return total / divisor


builtins_range = __builtins__["range"] if isinstance(__builtins__, dict) else getattr(__builtins__, "range")


def percentile_linear_interpolation(id: list[float], percentage: float) -> float:
    if not id:
        return float("nan")
    sorted_arr = sorted(id)
    n = len(sorted_arr)
    rank = (percentage / 100) * (n - 1)
    lower_idx = int(rank)
    upper_idx = builtins_min(lower_idx + 1, n - 1)
    frac = rank - lower_idx
    return sorted_arr[lower_idx] + frac * (sorted_arr[upper_idx] - sorted_arr[lower_idx])


def percentile_nearest_rank(id: list[float], percentage: float) -> float:
    if not id:
        return float("nan")
    sorted_arr = sorted(id)
    n = len(sorted_arr)
    rank = int(math.ceil((percentage / 100) * n)) - 1
    rank = builtins_max(0, builtins_min(rank, n - 1))
    return sorted_arr[rank]


builtins_max = __builtins__["max"] if isinstance(__builtins__, dict) else getattr(__builtins__, "max")


def percentrank(id: list[float], index: int) -> float:
    if not id or index < 0 or index >= len(id):
        return float("nan")
    value = id[index]
    if math.isnan(value):
        return float("nan")
    count = builtins_sum(1 for v in id if not math.isnan(v) and v <= value)
    return (count / len(id)) * 100


def sort_indices(id: list[float], order: str = "asc") -> list[int]:
    indices = list(builtins_range(len(id)))
    indices.sort(key=lambda i: id[i], reverse=(order == "desc"))
    return indices


def standardize(id: list[float]) -> list[float]:
    if not id:
        return []
    mean = avg(id)
    std_dev = stdev(id)
    if std_dev == 0:
        return [float("nan")] * len(id)
    return [(v - mean) / std_dev for v in id]
