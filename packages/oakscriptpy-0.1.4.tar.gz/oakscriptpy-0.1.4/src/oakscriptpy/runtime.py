"""Runtime module — global context management, plot, and hline."""

from __future__ import annotations

import math
import re
from typing import Any, Callable

from .runtime_types import OakScriptContext

_context: OakScriptContext | None = None
_calculate_fn: Callable[[], None] | None = None
_active_plots: list[dict[str, Any]] = []
_plot_counter: int = 0


def set_context(ctx: OakScriptContext) -> None:
    global _context, _plot_counter
    _context = ctx
    _plot_counter = 0
    clear_plots()


def clear_context() -> None:
    global _context, _calculate_fn, _plot_counter
    clear_plots()
    _context = None
    _calculate_fn = None
    _plot_counter = 0


def get_context() -> OakScriptContext | None:
    return _context


def register_calculate(fn: Callable[[], None]) -> None:
    global _calculate_fn
    _calculate_fn = fn


def recalculate() -> None:
    global _plot_counter
    if _calculate_fn is not None:
        clear_plots()
        _plot_counter = 0
        _calculate_fn()


def clear_plots() -> None:
    if _context is not None:
        for p in _active_plots:
            try:
                _context.chart.remove_series(p["series"])
            except Exception:
                pass
    _active_plots.clear()


def _get_series_type(style: str | None) -> str:
    if style in ("histogram", "columns"):
        return "histogram"
    if style in ("area", "areabr"):
        return "area"
    return "line"


def _get_line_style(style: str | None) -> int:
    if style == "dotted":
        return 1
    if style == "dashed":
        return 2
    return 0


def plot(
    series: list[float],
    title: str | None = None,
    color: str | None = None,
    linewidth: int | None = None,
    style: str | None = None,
    colors: list[str] | None = None,
) -> str:
    global _plot_counter
    if _context is None:
        raise RuntimeError("OakScript context not set. Call set_context() before plotting.")

    suffix = ""
    if title:
        suffix = "_" + re.sub(r"\s+", "_", title)
    plot_id = f"plot_{_plot_counter}{suffix}"
    _plot_counter += 1

    series_type = _get_series_type(style)
    options: dict[str, Any] = {}
    if color is not None:
        options["color"] = color
    if linewidth is not None:
        options["lineWidth"] = linewidth
    options["lineStyle"] = _get_line_style(style)

    series_handle = _context.chart.add_series(series_type, options)

    data: list[dict[str, Any]] = []
    times = _context.ohlcv.time
    for i, value in enumerate(series):
        if i < len(times) and not math.isnan(value):
            point: dict[str, Any] = {"time": times[i], "value": value}
            if colors and i < len(colors) and colors[i]:
                point["color"] = colors[i]
            data.append(point)

    series_handle.set_data(data)
    _active_plots.append({"id": plot_id, "series": series_handle})
    return plot_id


def hline(
    price: float,
    title: str | None = None,
    color: str | None = None,
    linestyle: str | None = None,
    linewidth: int | None = None,
) -> str:
    global _plot_counter
    if _context is None:
        raise RuntimeError("OakScript context not set. Call set_context() before creating hlines.")

    suffix = ""
    if title:
        suffix = "_" + re.sub(r"\s+", "_", title)
    hline_id = f"hline_{_plot_counter}{suffix}"
    _plot_counter += 1

    options: dict[str, Any] = {}
    if color is not None:
        options["color"] = color
    if linewidth is not None:
        options["lineWidth"] = linewidth
    options["lineStyle"] = _get_line_style(linestyle)

    series_handle = _context.chart.add_series("line", options)
    data = [{"time": t, "value": price} for t in _context.ohlcv.time]
    series_handle.set_data(data)

    _active_plots.append({"id": hline_id, "series": series_handle})
    return hline_id


def get_active_plots() -> list[dict[str, Any]]:
    return list(_active_plots)
