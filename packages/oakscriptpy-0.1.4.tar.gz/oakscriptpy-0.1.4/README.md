<p align="center">
  <img src="./logo.png" width="150" />
</p>

<h1 align="center">OakScriptPy</h1>

<p align="center">
  PineScript-like API for technical analysis in Python. Pure Python, zero dependencies.
</p>

---

## Install

```bash
pip install oakscriptpy
```

## Quick Start

```python
from oakscriptpy import ta, math, color, Series
from oakscriptpy._types import Bar

# Create bars
bars = [
    Bar(time=1, open=10.0, high=12.0, low=9.0, close=11.0, volume=100.0),
    Bar(time=2, open=11.0, high=13.0, low=10.0, close=12.0, volume=110.0),
    Bar(time=3, open=12.0, high=14.0, low=11.0, close=13.0, volume=120.0),
    # ...
]

# Array-based TA
closes = [b.close for b in bars]
sma_values = ta.sma(closes, 3)
ema_values = ta.ema(closes, 3)
rsi_values = ta.rsi(closes, 14)

# Series-based TA (with operator overloading)
from oakscriptpy import ta as ta_series
close_series = Series.from_bars(bars, lambda b: b.close)
sma_series = ta_series.sma(close_series, 3)
ema_series = ta_series.ema(close_series, 3)

# Series arithmetic
spread = close_series - sma_series
doubled = close_series * 2
above_sma = close_series > sma_series
```

## Namespaces

| Namespace | Functions | Description |
|-----------|-----------|-------------|
| `ta` | 64 | Technical analysis (SMA, EMA, RSI, MACD, Bollinger Bands, Ichimoku, SuperTrend, ZigZag, etc.) |
| `math` | 26 | Mathematical functions (abs, ceil, floor, sqrt, pow, trig, etc.) |
| `array` | 42+ | Array manipulation (push, pop, sort, slice, binary_search, percentile, etc.) |
| `color` | 14 + 17 constants | Color creation and manipulation (rgb, from_hex, new_color, named constants) |
| `str` | 20+ | String functions (split, replace, substring, contains, match, etc.) |
| `time` | 2 | Time utilities (format_time) |
| `matrix` | 43 | Matrix operations (add, mult, det, inv, eigenvalues, eigenvectors, etc.) |
| `line` | 10 | Line drawing objects |
| `box` | 12 | Box drawing objects |
| `label` | 10 | Label drawing objects |
| `linefill` | 4 | Linefill functions |
| `chart_point` | 3 | Chart point functions |
| `polyline` | 5 | Polyline functions |

## Series

The `Series` class provides lazy evaluation with Python operator overloading:

```python
a = Series.from_bars(bars, lambda b: b.close)
b = Series.from_bars(bars, lambda b: b.open)

# Arithmetic: +, -, *, /, %
spread = a - b

# Comparison: >, >=, <, <=, eq(), neq()
bullish = a > b

# Logical: and_(), or_(), not_()
signal = bullish.and_(a > sma_series)

# History access
prev_close = a.offset(1)
```

## Tests

```bash
uv run pytest
# 1,224 passed, 56 skipped
```

## License

MIT
