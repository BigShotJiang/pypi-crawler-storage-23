"""Orchestrator adapter selection."""

from phlo.orchestrators.selection import get_active_orchestrator

__all__ = ["get_active_orchestrator"]
