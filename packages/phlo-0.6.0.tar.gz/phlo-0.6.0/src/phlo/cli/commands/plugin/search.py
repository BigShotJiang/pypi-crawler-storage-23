"""Plugin search command."""

from __future__ import annotations

import json
import sys

import click
from rich.table import Table

from phlo.cli.commands.plugin.utils import (
    INTERNAL_TO_REGISTRY_TYPE,
    PLUGIN_TYPE_CHOICES,
    console,
    registry_plugin_to_dict,
)
from phlo.logging import get_logger
from phlo.plugins.registry_client import search_plugins

logger = get_logger(__name__)


@click.command(name="search")
@click.argument("query", required=False)
@click.option(
    "--type",
    "plugin_type",
    type=click.Choice(PLUGIN_TYPE_CHOICES),
    help="Filter by plugin type",
)
@click.option(
    "--tag",
    "tags",
    multiple=True,
    help="Filter by one or more tags",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    default=False,
    help="Output as JSON",
)
def search_cmd(
    query: str | None, plugin_type: str | None, tags: tuple[str, ...], output_json: bool
):
    """Search plugin registry."""
    try:
        logger.info(
            "plugin_search_started",
            has_query=query is not None,
            plugin_type=plugin_type,
            tag_count=len(tags),
            output_json=output_json,
        )
        if plugin_type:
            plugin_type = INTERNAL_TO_REGISTRY_TYPE.get(plugin_type, plugin_type)
        results = search_plugins(
            query=query,
            plugin_type=plugin_type,
            tags=list(tags) if tags else None,
        )

        output = [registry_plugin_to_dict(plugin) for plugin in results]

        if output_json:
            console.print(json.dumps(output, indent=2))
            logger.info("plugin_search_succeeded", result_count=len(output), output_json=True)
            return

        if not output:
            console.print("No plugins found.")
            logger.info("plugin_search_succeeded", result_count=0, output_json=False)
            return

        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Name", style="cyan")
        table.add_column("Type", style="green")
        table.add_column("Version", style="yellow")
        table.add_column("Package", style="white")
        table.add_column("Verified", style="blue")

        for plugin in output:
            table.add_row(
                plugin["name"],
                plugin["type"],
                plugin["version"],
                plugin["package"],
                "yes" if plugin["verified"] else "no",
            )

        console.print(table)
        logger.info("plugin_search_succeeded", result_count=len(output), output_json=False)

    except Exception as e:
        logger.exception(
            "plugin_search_failed",
            has_query=query is not None,
            plugin_type=plugin_type,
            tag_count=len(tags),
            output_json=output_json,
        )
        console.print(f"[red]Error searching registry: {e}[/red]")
        sys.exit(1)
