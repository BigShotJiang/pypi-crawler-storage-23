"""
Provider plugin classes.

This module defines plugin types that provide asset and resource specifications.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Iterable

from phlo.capabilities.specs import (
    AssetCheckSpec,
    AssetSpec,
    CatalogSpec,
    DataMigrationSourceSpec,
    GovernanceBackendSpec,
    LineageSinkSpec,
    MetadataCatalogSpec,
    QualityBackendSpec,
    QueryEngineSpec,
    ResourceSpec,
    SchemaMigrationSpec,
    SecretBackendSpec,
    TableStoreSpec,
)
from phlo.plugins.base.plugin import Plugin


class AssetProviderPlugin(Plugin, ABC):
    """Base class for capability plugins that provide asset specs."""

    @property
    def requires_capabilities(self) -> list[str]:
        """Return required capabilities for this provider."""
        return list(self.metadata.requires_capabilities)

    @property
    def optional_capabilities(self) -> list[str]:
        """Return optional capabilities for this provider."""
        return list(self.metadata.optional_capabilities)

    @abstractmethod
    def get_assets(self) -> Iterable[AssetSpec]:
        """Return asset specifications exposed by this plugin.

        Returns:
            Iterable of asset specifications.
        """

        raise NotImplementedError

    def get_checks(self) -> Iterable[AssetCheckSpec]:
        """Return asset check specifications exposed by this plugin.

        Returns:
            Iterable of asset check specifications.
        """

        return []


class ResourceProviderPlugin(Plugin, ABC):
    """Base class for plugins that provide resource specs."""

    @property
    def requires_capabilities(self) -> list[str]:
        """Return required capabilities for this provider."""
        return list(self.metadata.requires_capabilities)

    @property
    def optional_capabilities(self) -> list[str]:
        """Return optional capabilities for this provider."""
        return list(self.metadata.optional_capabilities)

    @abstractmethod
    def get_resources(self) -> Iterable[ResourceSpec]:
        """Return resource specifications exposed by this plugin.

        Returns:
            Iterable of resource specifications.
        """

        raise NotImplementedError

    def get_table_stores(self) -> Iterable[TableStoreSpec]:
        """Return table store capability specs exposed by this plugin."""
        return []

    def get_catalogs(self) -> Iterable[CatalogSpec]:
        """Return catalog capability specs exposed by this plugin."""
        return []

    def get_query_engines(self) -> Iterable[QueryEngineSpec]:
        """Return query engine capability specs exposed by this plugin."""
        return []

    def get_quality_backends(self) -> Iterable[QualityBackendSpec]:
        """Return quality backend capability specs exposed by this plugin."""
        return []

    def get_metadata_catalogs(self) -> Iterable[MetadataCatalogSpec]:
        """Return metadata catalog capability specs exposed by this plugin."""
        return []

    def get_lineage_sinks(self) -> Iterable[LineageSinkSpec]:
        """Return lineage sink capability specs exposed by this plugin."""
        return []

    def get_governance_backends(self) -> Iterable[GovernanceBackendSpec]:
        """Return governance backend capability specs exposed by this plugin."""
        return []

    def get_secret_backends(self) -> Iterable[SecretBackendSpec]:
        """Return secret backend capability specs exposed by this plugin."""
        return []

    def get_schema_migrators(self) -> Iterable[SchemaMigrationSpec]:
        """Return schema migrator capability specs exposed by this plugin."""
        return []

    def get_data_migration_sources(self) -> Iterable[DataMigrationSourceSpec]:
        """Return data migration source adapter specs exposed by this plugin."""
        return []
