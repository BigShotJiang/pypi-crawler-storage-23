import json

from click.testing import CliRunner

from corp_names.commands import main


def test_normalize_command():
    runner = CliRunner()
    result = runner.invoke(main, ["normalize", "Dr. Bob Smith Jr."])
    assert result.exit_code == 0
    assert "robert smith" in result.output
    assert "Prefix:     dr" in result.output
    assert "Suffix:     jr" in result.output
    assert "resolved to canonical form" in result.output


def test_normalize_json():
    runner = CliRunner()
    result = runner.invoke(main, ["normalize", "Dr. Bob Smith Jr.", "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["normalized"] == "robert smith"
    assert data["prefix"] == "dr"
    assert data["suffix"] == "jr"
    assert data["nickname_resolved"] is True


def test_normalize_no_prefix_suffix():
    runner = CliRunner()
    result = runner.invoke(main, ["normalize", "John Smith"])
    assert result.exit_code == 0
    assert "Prefix:" not in result.output
    assert "Suffix:" not in result.output
