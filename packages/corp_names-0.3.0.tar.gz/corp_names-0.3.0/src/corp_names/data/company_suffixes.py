"""Company legal suffix data loaded from company_suffixes.json.

Each entry maps a lowercase suffix (dots stripped) to:
- type: entity type classification (e.g. "Corporation", "Limited")
- jurisdictions: list of countries where the suffix is used
"""

import json
from importlib.resources import files

_data_dir = files("corp_names.data")

# suffix → {"type": str, "jurisdictions": list[str]}
COMPANY_SUFFIXES: dict[str, dict] = json.loads(
    (_data_dir / "company_suffixes.json").read_text(encoding="utf-8")
)

# Set of all known suffixes for fast lookup
COMPANY_SUFFIX_SET: frozenset[str] = frozenset(COMPANY_SUFFIXES.keys())

# Multi-word suffixes sorted longest first for greedy matching
MULTI_WORD_SUFFIXES: list[str] = sorted(
    [s for s in COMPANY_SUFFIXES if " " in s],
    key=lambda s: len(s.split()),
    reverse=True,
)
