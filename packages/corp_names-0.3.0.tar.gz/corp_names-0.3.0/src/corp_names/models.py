from pydantic import BaseModel


class NormalizedName(BaseModel):
    original: str
    normalized: str
    first: str
    last: str
    prefix: str
    suffix: str
    nickname_resolved: bool


class NormalizedCompany(BaseModel):
    original: str
    normalized: str
    suffix: str
    entity_type: str
    the_prefix_stripped: bool
