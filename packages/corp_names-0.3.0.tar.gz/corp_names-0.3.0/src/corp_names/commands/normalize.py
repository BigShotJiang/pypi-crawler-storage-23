import json

import click

from corp_names.normalizer import normalize_name


@click.command()
@click.argument("name")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
@click.option(
    "--level",
    type=click.Choice(["common", "international", "all"]),
    default="all",
    help="Nickname resolution level (default: all)",
)
def normalize(name: str, as_json: bool, level: str) -> None:
    """Normalize a person name."""
    result = normalize_name(name, level=level)

    if as_json:
        click.echo(result.model_dump_json(indent=2))
    else:
        click.echo(f"Original:   {result.original}")
        click.echo(f"Normalized: {result.normalized}")
        click.echo(f"First:      {result.first}")
        click.echo(f"Last:       {result.last}")
        if result.prefix:
            click.echo(f"Prefix:     {result.prefix}")
        if result.suffix:
            click.echo(f"Suffix:     {result.suffix}")
        if result.nickname_resolved:
            click.echo("Nickname:   resolved to canonical form")
