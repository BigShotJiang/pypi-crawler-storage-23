import click

from corp_names.commands.normalize import normalize
from corp_names.commands.normalize_company import normalize_company_cmd


@click.group()
def main() -> None:
    """Name normalization CLI."""
    pass


main.add_command(normalize)
main.add_command(normalize_company_cmd)
