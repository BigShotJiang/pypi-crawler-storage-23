"""
The FRANKENSTEIN is an architecture for language models that combines various submodels of different architectures
so that they can work together in order to deliver responses that are more accurate and better suited to the user's needs. Both local models and external models via API can be combined,
or even a combination of the two. These capabilities allow FRANKENSTEIN to infer both models with the proprietary architectures of Sapiens Technology®️,
as well as models with third-party architectures if there is such a need. The submodels are grouped into a classes structure capable of selecting one or more of them depending on the needs of the prompt.
When compiling the FRANKENSTEIN structure, a single model will be created through the result of the weights of all the local submodels contained in the architecture,
enabling packaging and distribution with a single file. Unlike what happens in a conventional MoE (Mixture of Experts),
FRANKENSTEIN does not need to load all submodels at once into memory and does not depend on all submodels belonging to the same architecture,
making it lighter and more flexible than a MoE and allowing it to run on more modest hardware.

Any alteration, copying, sharing, posting, or public comment about the technologies presented here without the prior authorization of Sapiens Technology®️ is strictly prohibited,
and failure to comply with these rules will result in legal proceedings initiated by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from .FRANKENSTEIN_MODEL import *
"""
The FRANKENSTEIN is an architecture for language models that combines various submodels of different architectures
so that they can work together in order to deliver responses that are more accurate and better suited to the user's needs. Both local models and external models via API can be combined,
or even a combination of the two. These capabilities allow FRANKENSTEIN to infer both models with the proprietary architectures of Sapiens Technology®️,
as well as models with third-party architectures if there is such a need. The submodels are grouped into a classes structure capable of selecting one or more of them depending on the needs of the prompt.
When compiling the FRANKENSTEIN structure, a single model will be created through the result of the weights of all the local submodels contained in the architecture,
enabling packaging and distribution with a single file. Unlike what happens in a conventional MoE (Mixture of Experts),
FRANKENSTEIN does not need to load all submodels at once into memory and does not depend on all submodels belonging to the same architecture,
making it lighter and more flexible than a MoE and allowing it to run on more modest hardware.

Any alteration, copying, sharing, posting, or public comment about the technologies presented here without the prior authorization of Sapiens Technology®️ is strictly prohibited,
and failure to comply with these rules will result in legal proceedings initiated by our team of lawyers.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
