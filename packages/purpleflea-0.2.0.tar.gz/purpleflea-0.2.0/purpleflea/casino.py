"""Client for the Purple Flea Casino API (/api/v1/)."""

from __future__ import annotations

from typing import Any

from .client import PurpleFleaClient


class CasinoClient:
    """High-level wrapper around the Purple Flea Casino service.

    All routes are prefixed with ``/api/v1/``.
    """

    PREFIX = "/api/v1"
    DEFAULT_BASE_URL = "http://80.78.27.26:3000"

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        self._http = PurpleFleaClient(
            api_key,
            base_url=base_url or self.DEFAULT_BASE_URL,
            timeout=timeout,
        )

    def _path(self, route: str) -> str:
        return f"{self.PREFIX}/{route.lstrip('/')}"

    # -- auth / account ------------------------------------------------------

    def register(self, username: str, email: str, **extra: Any) -> dict[str, Any]:
        """Register a new casino player account."""
        return self._http.post(self._path("register"), username=username, email=email, **extra)

    def get_account(self) -> dict[str, Any]:
        """Retrieve the authenticated player's account details."""
        return self._http.get(self._path("account"))

    # -- wallet --------------------------------------------------------------

    def deposit(self, amount: float, currency: str = "USD", **extra: Any) -> dict[str, Any]:
        """Deposit funds into the casino wallet."""
        return self._http.post(self._path("wallet/deposit"), amount=amount, currency=currency, **extra)

    def withdraw(self, amount: float, currency: str = "USD", **extra: Any) -> dict[str, Any]:
        """Withdraw funds from the casino wallet."""
        return self._http.post(self._path("wallet/withdraw"), amount=amount, currency=currency, **extra)

    def get_balance(self) -> dict[str, Any]:
        """Get current wallet balance."""
        return self._http.get(self._path("wallet/balance"))

    # -- games ---------------------------------------------------------------

    def list_games(self, **filters: Any) -> dict[str, Any]:
        """List available casino games."""
        return self._http.get(self._path("games"), **filters)

    def get_game(self, game_id: str) -> dict[str, Any]:
        """Get details for a specific game."""
        return self._http.get(self._path(f"games/{game_id}"))

    def play(self, game_id: str, bet_amount: float, **options: Any) -> dict[str, Any]:
        """Place a bet and play a round."""
        return self._http.post(self._path(f"games/{game_id}/play"), bet_amount=bet_amount, **options)

    def get_game_history(self, **filters: Any) -> dict[str, Any]:
        """Retrieve past game results."""
        return self._http.get(self._path("games/history"), **filters)

    # -- referrals -----------------------------------------------------------

    def create_referral(self) -> dict[str, Any]:
        """Generate a new referral code."""
        return self._http.post(self._path("referrals"))

    def list_referrals(self) -> dict[str, Any]:
        """List all referrals and their status."""
        return self._http.get(self._path("referrals"))

    def redeem_referral(self, code: str) -> dict[str, Any]:
        """Redeem a referral code."""
        return self._http.post(self._path("referrals/redeem"), code=code)

    # -- lifecycle -----------------------------------------------------------

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> CasinoClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
