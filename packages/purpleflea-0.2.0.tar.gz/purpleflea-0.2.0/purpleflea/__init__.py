"""Purple Flea Python SDK."""

from .casino import CasinoClient
from .client import APIError, PurpleFleaClient
from .trading import TradingClient
from .wallet import WalletClient

__all__ = [
    "APIError",
    "CasinoClient",
    "PurpleFleaClient",
    "TradingClient",
    "WalletClient",
]

__version__ = "0.2.0"
