"""Tests for the CasinoClient."""

import responses

from purpleflea.casino import CasinoClient


BASE = "https://api.purpleflea.com"
PREFIX = "/api/v1"


def _url(path: str) -> str:
    return f"{BASE}{PREFIX}/{path.lstrip('/')}"


@responses.activate
def test_register():
    responses.post(_url("register"), json={"user_id": "u1"})
    with CasinoClient("key") as c:
        result = c.register("alice", "alice@example.com")
    assert result == {"user_id": "u1"}


@responses.activate
def test_get_account():
    responses.get(_url("account"), json={"username": "alice"})
    with CasinoClient("key") as c:
        result = c.get_account()
    assert result["username"] == "alice"


@responses.activate
def test_deposit():
    responses.post(_url("wallet/deposit"), json={"balance": 100.0})
    with CasinoClient("key") as c:
        result = c.deposit(100.0, currency="USD")
    assert result["balance"] == 100.0


@responses.activate
def test_withdraw():
    responses.post(_url("wallet/withdraw"), json={"balance": 50.0})
    with CasinoClient("key") as c:
        result = c.withdraw(50.0)
    assert result["balance"] == 50.0


@responses.activate
def test_get_balance():
    responses.get(_url("wallet/balance"), json={"balance": 75.0})
    with CasinoClient("key") as c:
        result = c.get_balance()
    assert result["balance"] == 75.0


@responses.activate
def test_list_games():
    responses.get(_url("games"), json={"games": [{"id": "g1"}]})
    with CasinoClient("key") as c:
        result = c.list_games()
    assert len(result["games"]) == 1


@responses.activate
def test_get_game():
    responses.get(_url("games/g1"), json={"id": "g1", "name": "Slots"})
    with CasinoClient("key") as c:
        result = c.get_game("g1")
    assert result["name"] == "Slots"


@responses.activate
def test_play():
    responses.post(_url("games/g1/play"), json={"result": "win", "payout": 200.0})
    with CasinoClient("key") as c:
        result = c.play("g1", 10.0)
    assert result["result"] == "win"


@responses.activate
def test_game_history():
    responses.get(_url("games/history"), json={"history": []})
    with CasinoClient("key") as c:
        result = c.get_game_history()
    assert result["history"] == []


@responses.activate
def test_create_referral():
    responses.post(_url("referrals"), json={"code": "REF123"})
    with CasinoClient("key") as c:
        result = c.create_referral()
    assert result["code"] == "REF123"


@responses.activate
def test_list_referrals():
    responses.get(_url("referrals"), json={"referrals": []})
    with CasinoClient("key") as c:
        result = c.list_referrals()
    assert "referrals" in result


@responses.activate
def test_redeem_referral():
    responses.post(_url("referrals/redeem"), json={"redeemed": True})
    with CasinoClient("key") as c:
        result = c.redeem_referral("REF123")
    assert result["redeemed"] is True
