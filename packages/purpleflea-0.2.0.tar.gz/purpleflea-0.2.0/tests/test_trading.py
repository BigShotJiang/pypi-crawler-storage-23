"""Tests for the TradingClient."""

import responses

from purpleflea.trading import TradingClient


BASE = "https://api.purpleflea.com"
PREFIX = "/v1"


def _url(path: str) -> str:
    return f"{BASE}{PREFIX}/{path.lstrip('/')}"


@responses.activate
def test_register():
    responses.post(_url("register"), json={"user_id": "t1"})
    with TradingClient("key") as c:
        result = c.register("bob", "bob@example.com")
    assert result == {"user_id": "t1"}


@responses.activate
def test_get_account():
    responses.get(_url("account"), json={"username": "bob"})
    with TradingClient("key") as c:
        result = c.get_account()
    assert result["username"] == "bob"


@responses.activate
def test_list_markets():
    responses.get(_url("markets"), json={"markets": [{"id": "BTC-USD"}]})
    with TradingClient("key") as c:
        result = c.list_markets()
    assert len(result["markets"]) == 1


@responses.activate
def test_get_market():
    responses.get(_url("markets/BTC-USD"), json={"id": "BTC-USD", "price": 50000})
    with TradingClient("key") as c:
        result = c.get_market("BTC-USD")
    assert result["price"] == 50000


@responses.activate
def test_get_orderbook():
    responses.get(_url("markets/BTC-USD/orderbook"), json={"bids": [], "asks": []})
    with TradingClient("key") as c:
        result = c.get_orderbook("BTC-USD")
    assert "bids" in result


@responses.activate
def test_open_position():
    responses.post(_url("positions"), json={"position_id": "p1", "status": "open"})
    with TradingClient("key") as c:
        result = c.open_position("BTC-USD", "long", 0.5)
    assert result["status"] == "open"


@responses.activate
def test_close_position():
    responses.post(_url("positions/p1/close"), json={"position_id": "p1", "status": "closed"})
    with TradingClient("key") as c:
        result = c.close_position("p1")
    assert result["status"] == "closed"


@responses.activate
def test_get_position():
    responses.get(_url("positions/p1"), json={"position_id": "p1", "pnl": 150.0})
    with TradingClient("key") as c:
        result = c.get_position("p1")
    assert result["pnl"] == 150.0


@responses.activate
def test_list_positions():
    responses.get(_url("positions"), json={"positions": []})
    with TradingClient("key") as c:
        result = c.list_positions()
    assert result["positions"] == []


@responses.activate
def test_create_referral():
    responses.post(_url("referrals"), json={"code": "TREF1"})
    with TradingClient("key") as c:
        result = c.create_referral()
    assert result["code"] == "TREF1"


@responses.activate
def test_list_referrals():
    responses.get(_url("referrals"), json={"referrals": []})
    with TradingClient("key") as c:
        result = c.list_referrals()
    assert "referrals" in result


@responses.activate
def test_redeem_referral():
    responses.post(_url("referrals/redeem"), json={"redeemed": True})
    with TradingClient("key") as c:
        result = c.redeem_referral("TREF1")
    assert result["redeemed"] is True
