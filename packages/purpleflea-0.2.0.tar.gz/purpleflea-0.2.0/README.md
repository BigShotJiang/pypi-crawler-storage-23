# purpleflea

Python SDK for the [Purple Flea](https://purpleflea.com) Casino, Trading & Wallet APIs.

## Installation

```bash
pip install purpleflea
```

## Quick Start

### Casino

```python
from purpleflea import CasinoClient

# Defaults to http://80.78.27.26:3000
casino = CasinoClient("your-api-key")

# Register a new account
casino.register("alice", "alice@example.com")

# Deposit funds
casino.deposit(100.0, currency="USDC")

# List available games
games = casino.list_games()

# Play a round
result = casino.play("dice", bet_amount=5.0)

# Check balance & withdraw
balance = casino.get_balance()
casino.withdraw(50.0)

# Referrals
ref = casino.create_referral()
casino.redeem_referral("REF123")

casino.close()
```

### Trading

```python
from purpleflea import TradingClient

# Defaults to http://80.78.27.26:3003
trading = TradingClient("your-api-key")

# Register a new account
trading.register("bob", "bob@example.com")

# Browse markets
markets = trading.list_markets()
btc = trading.get_market("BTC-USD")
book = trading.get_orderbook("BTC-USD")

# Open a long position
pos = trading.open_position("BTC-USD", side="long", size=0.5)

# Check position and close
details = trading.get_position(pos["position_id"])
trading.close_position(pos["position_id"])

# Referrals
trading.create_referral()
trading.redeem_referral("TREF1")

trading.close()
```

### Wallet

```python
from purpleflea import WalletClient

# Defaults to http://80.78.27.26:3000
wallet = WalletClient("your-api-key")

# Get balance
balance = wallet.get_balance()

# Get deposit address for BTC
addr = wallet.get_address("BTC")

# Deposit USDC
wallet.deposit(500.0, currency="USDC")

# Withdraw to external address
wallet.withdraw(100.0, address="0xYourAddress", currency="USDC")

# Transaction history
txns = wallet.list_transactions(limit=20)

# Transfer between accounts
wallet.transfer(to_account="carol", amount=25.0)

wallet.close()
```

### Context Manager

All clients support context managers for automatic cleanup:

```python
from purpleflea import CasinoClient

with CasinoClient("your-api-key") as casino:
    casino.deposit(50.0)
    result = casino.play("dice", bet_amount=10.0)
```

### Custom Base URL

```python
from purpleflea import CasinoClient, TradingClient

casino = CasinoClient("your-api-key", base_url="http://80.78.27.26:3000")
trading = TradingClient("your-api-key", base_url="http://80.78.27.26:3003")
```

### Error Handling

```python
from purpleflea import CasinoClient, APIError

try:
    with CasinoClient("your-api-key") as casino:
        casino.play("invalid-game", bet_amount=10.0)
except APIError as e:
    print(f"API error {e.status_code}: {e.message}")
```

## API Reference

### `CasinoClient(api_key, base_url=None, timeout=30.0)`

Default base URL: `http://80.78.27.26:3000`. Routes use the `/api/v1/` prefix.

| Method | Description |
|---|---|
| `register(username, email)` | Register a new player |
| `get_account()` | Get account details |
| `deposit(amount, currency="USDC")` | Deposit funds |
| `withdraw(amount, currency="USDC")` | Withdraw funds |
| `get_balance()` | Get wallet balance |
| `list_games()` | List available games |
| `get_game(game_id)` | Get game details |
| `play(game_id, bet_amount)` | Play a round |
| `get_game_history()` | Get past results |
| `create_referral()` | Generate referral code |
| `list_referrals()` | List referrals |
| `redeem_referral(code)` | Redeem a referral code |

### `TradingClient(api_key, base_url=None, timeout=30.0)`

Default base URL: `http://80.78.27.26:3003`. Routes use the `/v1/` prefix.

| Method | Description |
|---|---|
| `register(username, email)` | Register a new trader |
| `get_account()` | Get account details |
| `list_markets()` | List available markets |
| `get_market(market_id)` | Get market details |
| `get_orderbook(market_id)` | Get order book |
| `open_position(market_id, side, size)` | Open a position |
| `close_position(position_id)` | Close a position |
| `get_position(position_id)` | Get position details |
| `list_positions()` | List open positions |
| `create_referral()` | Generate referral code |
| `list_referrals()` | List referrals |
| `redeem_referral(code)` | Redeem a referral code |

### `WalletClient(api_key, base_url=None, timeout=30.0)`

Default base URL: `http://80.78.27.26:3000`. Routes use the `/api/v1/wallet/` prefix.

| Method | Description |
|---|---|
| `get_balance()` | Get balance across all currencies |
| `get_address(currency)` | Get deposit address for a currency |
| `deposit(amount, currency="USDC")` | Initiate a deposit |
| `get_deposit(deposit_id)` | Get deposit status |
| `list_deposits()` | List all deposits |
| `withdraw(amount, address, currency="USDC")` | Withdraw to external address |
| `get_withdrawal(withdrawal_id)` | Get withdrawal status |
| `list_withdrawals()` | List all withdrawals |
| `list_transactions(limit=50)` | List all transactions |
| `get_transaction(transaction_id)` | Get transaction details |
| `transfer(to_account, amount, currency="USDC")` | Transfer to another account |

## Changelog

### 0.2.0
- Added `WalletClient` with full deposit/withdrawal/transfer support
- Set correct default base URLs: casino `http://80.78.27.26:3000`, trading `http://80.78.27.26:3003`
- Promoted to Beta status

### 0.1.0
- Initial release with `CasinoClient` and `TradingClient`

## Development

```bash
git clone https://github.com/Purple-flea/python-sdk.git
cd python-sdk
pip install -e ".[dev]"
pytest
```

## License

MIT
