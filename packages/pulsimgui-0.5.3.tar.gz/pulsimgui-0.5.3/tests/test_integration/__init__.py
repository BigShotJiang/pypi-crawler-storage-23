"""Integration tests for full simulation workflows."""
