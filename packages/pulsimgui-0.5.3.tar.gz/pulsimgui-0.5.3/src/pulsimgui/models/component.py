"""Component model for circuit elements."""

from copy import deepcopy
from dataclasses import dataclass, field
from enum import Enum, auto
import math
from typing import Any
from uuid import UUID, uuid4


class ComponentType(Enum):
    """Types of circuit components."""

    # Basic passive components
    RESISTOR = auto()
    CAPACITOR = auto()
    INDUCTOR = auto()

    # Sources
    VOLTAGE_SOURCE = auto()
    CURRENT_SOURCE = auto()
    GROUND = auto()

    # Semiconductors - diodes
    DIODE = auto()
    ZENER_DIODE = auto()
    LED = auto()

    # Semiconductors - transistors
    MOSFET_N = auto()
    MOSFET_P = auto()
    IGBT = auto()
    BJT_NPN = auto()
    BJT_PNP = auto()
    THYRISTOR = auto()
    TRIAC = auto()

    # Switching
    SWITCH = auto()

    # Transformers
    TRANSFORMER = auto()

    # Analog
    OP_AMP = auto()
    COMPARATOR = auto()

    # Protection
    RELAY = auto()
    FUSE = auto()
    CIRCUIT_BREAKER = auto()

    # Control blocks - basic
    PI_CONTROLLER = auto()
    PID_CONTROLLER = auto()
    MATH_BLOCK = auto()
    PWM_GENERATOR = auto()
    GAIN = auto()
    SUM = auto()
    SUBTRACTOR = auto()
    CONSTANT = auto()

    # Control blocks - signal processing
    INTEGRATOR = auto()
    DIFFERENTIATOR = auto()
    LIMITER = auto()
    RATE_LIMITER = auto()
    HYSTERESIS = auto()

    # Control blocks - advanced
    LOOKUP_TABLE = auto()
    TRANSFER_FUNCTION = auto()
    DELAY_BLOCK = auto()
    SAMPLE_HOLD = auto()
    STATE_MACHINE = auto()

    # Measurement
    VOLTAGE_PROBE = auto()
    CURRENT_PROBE = auto()
    POWER_PROBE = auto()

    # Scopes
    ELECTRICAL_SCOPE = auto()
    THERMAL_SCOPE = auto()

    # Signal routing
    SIGNAL_MUX = auto()
    SIGNAL_DEMUX = auto()

    # Magnetic
    SATURABLE_INDUCTOR = auto()
    COUPLED_INDUCTOR = auto()

    # Pre-configured networks
    SNUBBER_RC = auto()

    # Hierarchical
    SUBCIRCUIT = auto()


@dataclass
class Pin:
    """A connection point on a component."""

    index: int
    name: str
    x: float  # Relative to component origin
    y: float

    def to_dict(self) -> dict:
        """Serialize pin to dictionary."""
        return {"index": self.index, "name": self.name, "x": self.x, "y": self.y}

    @classmethod
    def from_dict(cls, data: dict) -> "Pin":
        """Deserialize pin from dictionary."""
        return cls(
            index=data["index"],
            name=data["name"],
            x=data["x"],
            y=data["y"],
        )


PIN_GRID_STEP = 20.0


def _snap_to_pin_grid(value: float) -> float:
    """Snap a coordinate to the pin grid step using half-away-from-zero rounding."""
    step = PIN_GRID_STEP
    value = float(value)
    if value >= 0:
        return math.floor((value + step / 2.0) / step) * step
    return math.ceil((value - step / 2.0) / step) * step


def _snap_pin_layout(pins: list[Pin]) -> list[Pin]:
    """Return a copy of pins with coordinates aligned to the pin grid."""
    return [
        Pin(pin.index, pin.name, _snap_to_pin_grid(pin.x), _snap_to_pin_grid(pin.y))
        for pin in pins
    ]


def _snap_component_pins_to_grid(component: "Component") -> None:
    """Mutate component pin coordinates so every pin lands on the wiring grid."""
    component.pins = _snap_pin_layout(component.pins)


def _generate_stacked_pins(
    count: int,
    x: float,
    name_prefix: str,
    start_index: int = 0,
) -> list[Pin]:
    """Create evenly spaced pins stacked vertically."""

    if count <= 0:
        return []

    spacing = PIN_GRID_STEP
    pins: list[Pin] = []
    for idx in range(count):
        if count % 2 == 1:
            y = (idx - (count // 2)) * spacing
        else:
            lower_half = count // 2
            if idx < lower_half:
                y = (idx - lower_half) * spacing
            else:
                y = (idx - lower_half + 1) * spacing
        pins.append(
            Pin(
                start_index + idx,
                f"{name_prefix}{idx + 1}",
                _snap_to_pin_grid(x),
                y,
            )
        )
    return pins


def _default_scope_pins(channel_count: int) -> list[Pin]:
    """Create default pins for scope components."""

    return _generate_stacked_pins(channel_count, -40, "CH")


def _default_mux_pins(input_count: int) -> list[Pin]:
    """Create default pins for mux blocks."""

    pins = _generate_stacked_pins(input_count, -20, "IN")
    pins.append(Pin(len(pins), "OUT", 20, 0))
    return pins


def _default_demux_pins(output_count: int) -> list[Pin]:
    """Create default pins for demux blocks."""

    pins = [Pin(0, "IN", -20, 0)]
    pins.extend(
        _generate_stacked_pins(output_count, 20, "OUT", start_index=1)
    )
    return pins


def _default_unary_block_pins() -> list[Pin]:
    """Create IN/OUT pin pair for unary signal blocks."""
    return [Pin(0, "IN", -35, 0), Pin(1, "OUT", 35, 0)]


def _default_sum_pins(input_count: int) -> list[Pin]:
    """Create stacked input pins plus single output pin for sum/sub blocks."""
    pins = _generate_stacked_pins(input_count, -35, "IN")
    pins.append(Pin(len(pins), "OUT", 35, 0))
    return pins


def _scope_label_prefix(comp_type: ComponentType) -> str:
    """Get default label prefix for scope channels based on component type."""

    return "CH" if comp_type == ComponentType.ELECTRICAL_SCOPE else "T"


THERMAL_PORT_PARAMETER = "enable_thermal_port"
THERMAL_PORT_PIN_NAME = "TH"
VOLTAGE_PROBE_OUTPUT_PIN_NAME = "OUT"
CURRENT_PROBE_OUTPUT_PIN_NAME = "MEAS"
THERMAL_PORT_SUPPORTED_TYPES: set[ComponentType] = {
    ComponentType.RESISTOR,
    ComponentType.CAPACITOR,
    ComponentType.INDUCTOR,
    ComponentType.VOLTAGE_SOURCE,
    ComponentType.CURRENT_SOURCE,
    ComponentType.DIODE,
    ComponentType.ZENER_DIODE,
    ComponentType.LED,
    ComponentType.MOSFET_N,
    ComponentType.MOSFET_P,
    ComponentType.IGBT,
    ComponentType.BJT_NPN,
    ComponentType.BJT_PNP,
    ComponentType.THYRISTOR,
    ComponentType.TRIAC,
    ComponentType.SWITCH,
    ComponentType.TRANSFORMER,
    ComponentType.RELAY,
    ComponentType.FUSE,
    ComponentType.CIRCUIT_BREAKER,
    ComponentType.SATURABLE_INDUCTOR,
    ComponentType.COUPLED_INDUCTOR,
    ComponentType.SNUBBER_RC,
}


def supports_thermal_port(component_type: ComponentType) -> bool:
    """Return True when component type can expose a thermal measurement port."""

    return component_type in THERMAL_PORT_SUPPORTED_TYPES


def _pin_name(component: "Component", pin_index: int) -> str:
    if 0 <= pin_index < len(component.pins):
        return component.pins[pin_index].name
    return ""


def is_scope_input_pin(component: "Component", pin_index: int) -> bool:
    """Return True when pin belongs to an electrical or thermal scope input."""
    if pin_index < 0 or pin_index >= len(component.pins):
        return False
    return component.type in (ComponentType.ELECTRICAL_SCOPE, ComponentType.THERMAL_SCOPE)


def is_voltage_probe_output_pin(component: "Component", pin_index: int) -> bool:
    """Return True when pin is the scope-facing output of a voltage probe."""
    if component.type != ComponentType.VOLTAGE_PROBE:
        return False
    return _pin_name(component, pin_index) == VOLTAGE_PROBE_OUTPUT_PIN_NAME


def is_current_probe_output_pin(component: "Component", pin_index: int) -> bool:
    """Return True when pin is the scope-facing output of a current probe."""
    if component.type != ComponentType.CURRENT_PROBE:
        return False
    return _pin_name(component, pin_index) == CURRENT_PROBE_OUTPUT_PIN_NAME


def is_thermal_output_pin(component: "Component", pin_index: int) -> bool:
    """Return True for optional thermal output pins exposed by components."""
    if is_scope_input_pin(component, pin_index):
        return False
    return _pin_name(component, pin_index) == THERMAL_PORT_PIN_NAME


def is_electrical_probe_output_pin(component: "Component", pin_index: int) -> bool:
    """Return True for any electrical probe output that can feed electrical scopes."""
    return is_voltage_probe_output_pin(component, pin_index) or is_current_probe_output_pin(component, pin_index)


def is_restricted_measurement_pin(component: "Component", pin_index: int) -> bool:
    """Return True when a pin has dedicated measurement-routing rules."""
    return (
        is_scope_input_pin(component, pin_index)
        or is_electrical_probe_output_pin(component, pin_index)
        or is_thermal_output_pin(component, pin_index)
    )


def can_connect_measurement_pins(
    left_component: "Component",
    left_pin_index: int,
    right_component: "Component",
    right_pin_index: int,
) -> bool:
    """Validate dedicated scope/probe/thermal routing compatibility."""
    left_is_e_scope = left_component.type == ComponentType.ELECTRICAL_SCOPE
    right_is_e_scope = right_component.type == ComponentType.ELECTRICAL_SCOPE
    left_is_t_scope = left_component.type == ComponentType.THERMAL_SCOPE
    right_is_t_scope = right_component.type == ComponentType.THERMAL_SCOPE

    left_is_e_probe_out = is_electrical_probe_output_pin(left_component, left_pin_index)
    right_is_e_probe_out = is_electrical_probe_output_pin(right_component, right_pin_index)
    left_is_t_out = is_thermal_output_pin(left_component, left_pin_index)
    right_is_t_out = is_thermal_output_pin(right_component, right_pin_index)

    electrical_group = left_is_e_scope or right_is_e_scope or left_is_e_probe_out or right_is_e_probe_out
    if electrical_group:
        return (left_is_e_scope and right_is_e_probe_out) or (right_is_e_scope and left_is_e_probe_out)

    thermal_group = left_is_t_scope or right_is_t_scope or left_is_t_out or right_is_t_out
    if thermal_group:
        return (left_is_t_scope and right_is_t_out) or (right_is_t_scope and left_is_t_out)

    return True


CONNECTION_DOMAIN_CIRCUIT = "circuit"
CONNECTION_DOMAIN_SIGNAL = "signal"
CONNECTION_DOMAIN_THERMAL = "thermal"

# Map switching-device component types to their gate/base/control pin indices.
# These pins accept signal-domain connections (e.g. PWM output).
_CONTROL_PIN_INDICES: dict[ComponentType, set[int]] = {
    ComponentType.MOSFET_N:  {1},   # G
    ComponentType.MOSFET_P:  {1},   # G
    ComponentType.IGBT:      {1},   # G
    ComponentType.BJT_NPN:   {1},   # B
    ComponentType.BJT_PNP:   {1},   # B
    ComponentType.THYRISTOR: {2},   # G
    ComponentType.TRIAC:     {2},   # G
    ComponentType.SWITCH:    {2},   # CTL
}

SIGNAL_DOMAIN_COMPONENT_TYPES: set[ComponentType] = {
    ComponentType.ELECTRICAL_SCOPE,
    ComponentType.VOLTAGE_PROBE,
    ComponentType.CURRENT_PROBE,
    ComponentType.POWER_PROBE,
    ComponentType.SIGNAL_MUX,
    ComponentType.SIGNAL_DEMUX,
    ComponentType.PI_CONTROLLER,
    ComponentType.PID_CONTROLLER,
    ComponentType.MATH_BLOCK,
    ComponentType.PWM_GENERATOR,
    ComponentType.GAIN,
    ComponentType.SUM,
    ComponentType.SUBTRACTOR,
    ComponentType.CONSTANT,
    ComponentType.INTEGRATOR,
    ComponentType.DIFFERENTIATOR,
    ComponentType.LIMITER,
    ComponentType.RATE_LIMITER,
    ComponentType.HYSTERESIS,
    ComponentType.LOOKUP_TABLE,
    ComponentType.TRANSFER_FUNCTION,
    ComponentType.DELAY_BLOCK,
    ComponentType.SAMPLE_HOLD,
    ComponentType.STATE_MACHINE,
    ComponentType.OP_AMP,
    ComponentType.COMPARATOR,
}

THERMAL_DOMAIN_COMPONENT_TYPES: set[ComponentType] = {
    ComponentType.THERMAL_SCOPE,
}


def component_connection_domain(component_type: ComponentType) -> str:
    """Return the default wiring domain used by a component family."""
    if component_type in THERMAL_DOMAIN_COMPONENT_TYPES:
        return CONNECTION_DOMAIN_THERMAL
    if component_type in SIGNAL_DOMAIN_COMPONENT_TYPES:
        return CONNECTION_DOMAIN_SIGNAL
    return CONNECTION_DOMAIN_CIRCUIT


def pin_connection_domain(component: "Component", pin_index: int) -> str:
    """Return the effective connection domain for a specific pin."""
    if component.type == ComponentType.THERMAL_SCOPE:
        return CONNECTION_DOMAIN_THERMAL
    if is_thermal_output_pin(component, pin_index):
        return CONNECTION_DOMAIN_THERMAL

    if component.type == ComponentType.VOLTAGE_PROBE:
        return (
            CONNECTION_DOMAIN_SIGNAL
            if is_voltage_probe_output_pin(component, pin_index)
            else CONNECTION_DOMAIN_CIRCUIT
        )

    if component.type == ComponentType.CURRENT_PROBE:
        return (
            CONNECTION_DOMAIN_SIGNAL
            if is_current_probe_output_pin(component, pin_index)
            else CONNECTION_DOMAIN_CIRCUIT
        )

    if is_scope_input_pin(component, pin_index):
        return CONNECTION_DOMAIN_SIGNAL
    if is_electrical_probe_output_pin(component, pin_index):
        return CONNECTION_DOMAIN_SIGNAL

    # Gate / base / control pins of switching devices accept signal-domain drives.
    if pin_index in _CONTROL_PIN_INDICES.get(component.type, set()):
        return CONNECTION_DOMAIN_SIGNAL

    return component_connection_domain(component.type)


# Default pin configurations for each component type
DEFAULT_PINS: dict[ComponentType, list[Pin]] = {
    # Basic passive
    ComponentType.RESISTOR: [Pin(0, "1", -30, 0), Pin(1, "2", 30, 0)],
    ComponentType.CAPACITOR: [Pin(0, "+", -20, 0), Pin(1, "-", 20, 0)],
    ComponentType.INDUCTOR: [Pin(0, "1", -30, 0), Pin(1, "2", 30, 0)],

    # Sources
    ComponentType.VOLTAGE_SOURCE: [Pin(0, "+", 0, -25), Pin(1, "-", 0, 25)],
    ComponentType.CURRENT_SOURCE: [Pin(0, "+", 0, -25), Pin(1, "-", 0, 25)],
    ComponentType.GROUND: [Pin(0, "gnd", 0, -10)],

    # Diodes
    ComponentType.DIODE: [Pin(0, "A", -20, 0), Pin(1, "K", 20, 0)],
    ComponentType.ZENER_DIODE: [Pin(0, "A", -20, 0), Pin(1, "K", 20, 0)],
    ComponentType.LED: [Pin(0, "A", -20, 0), Pin(1, "K", 20, 0)],

    # Transistors
    ComponentType.MOSFET_N: [Pin(0, "D", 20, -20), Pin(1, "G", -20, 0), Pin(2, "S", 20, 20)],
    ComponentType.MOSFET_P: [Pin(0, "D", 20, 20), Pin(1, "G", -20, 0), Pin(2, "S", 20, -20)],
    ComponentType.IGBT: [Pin(0, "C", 20, -20), Pin(1, "G", -20, 0), Pin(2, "E", 20, 20)],
    ComponentType.BJT_NPN: [Pin(0, "C", 20, -20), Pin(1, "B", -20, 0), Pin(2, "E", 20, 20)],
    ComponentType.BJT_PNP: [Pin(0, "C", 20, 20), Pin(1, "B", -20, 0), Pin(2, "E", 20, -20)],
    ComponentType.THYRISTOR: [Pin(0, "A", 0, -20), Pin(1, "K", 0, 20), Pin(2, "G", -20, 10)],
    ComponentType.TRIAC: [Pin(0, "MT1", 0, -20), Pin(1, "MT2", 0, 20), Pin(2, "G", -20, 10)],

    # Switching
    ComponentType.SWITCH: [Pin(0, "1", -20, 0), Pin(1, "2", 20, 0), Pin(2, "CTL", 0, -20)],

    # Transformer
    ComponentType.TRANSFORMER: [
        Pin(0, "P1", -30, -15),
        Pin(1, "P2", -30, 15),
        Pin(2, "S1", 30, -15),
        Pin(3, "S2", 30, 15),
    ],

    # Analog
    ComponentType.OP_AMP: [
        Pin(0, "IN+", -35, -12),
        Pin(1, "IN-", -35, 12),
        Pin(2, "OUT", 35, 0),
        Pin(3, "V+", 0, -25),
        Pin(4, "V-", 0, 25),
    ],
    ComponentType.COMPARATOR: [
        Pin(0, "IN+", -35, -12),
        Pin(1, "IN-", -35, 12),
        Pin(2, "OUT", 35, 0),
        Pin(3, "V+", 0, -25),
        Pin(4, "V-", 0, 25),
    ],

    # Protection
    ComponentType.RELAY: [
        Pin(0, "COIL+", -35, -15),
        Pin(1, "COIL-", -35, 15),
        Pin(2, "COM", 35, 0),
        Pin(3, "NO", 35, -15),
        Pin(4, "NC", 35, 15),
    ],
    ComponentType.FUSE: [Pin(0, "1", -20, 0), Pin(1, "2", 20, 0)],
    ComponentType.CIRCUIT_BREAKER: [Pin(0, "LINE", -20, 0), Pin(1, "LOAD", 20, 0)],

    # Control blocks - basic
    ComponentType.PI_CONTROLLER: [
        Pin(0, "IN", -35, 0),
        Pin(1, "OUT", 35, 0),
    ],
    ComponentType.PID_CONTROLLER: [
        Pin(0, "IN", -35, -12),
        Pin(1, "FB", -35, 12),
        Pin(2, "OUT", 35, 0),
    ],
    ComponentType.MATH_BLOCK: [
        Pin(0, "A", -35, -12),
        Pin(1, "B", -35, 12),
        Pin(2, "OUT", 35, 0),
    ],
    ComponentType.PWM_GENERATOR: [
        Pin(0, "OUT", 35, 0),
        Pin(1, "DUTY_IN", -35, 20),
    ],
    ComponentType.GAIN: _default_unary_block_pins(),
    ComponentType.SUM: _default_sum_pins(2),
    ComponentType.SUBTRACTOR: _default_sum_pins(2),
    ComponentType.CONSTANT: [Pin(0, "OUT", 40, 0)],

    # Control blocks - signal processing
    ComponentType.INTEGRATOR: [Pin(0, "IN", -35, 0), Pin(1, "OUT", 35, 0)],
    ComponentType.DIFFERENTIATOR: [Pin(0, "IN", -35, 0), Pin(1, "OUT", 35, 0)],
    ComponentType.LIMITER: [Pin(0, "IN", -35, 0), Pin(1, "OUT", 35, 0)],
    ComponentType.RATE_LIMITER: [Pin(0, "IN", -35, 0), Pin(1, "OUT", 35, 0)],
    ComponentType.HYSTERESIS: [Pin(0, "IN", -35, 0), Pin(1, "OUT", 35, 0)],

    # Control blocks - advanced
    ComponentType.LOOKUP_TABLE: [Pin(0, "IN", -35, 0), Pin(1, "OUT", 35, 0)],
    ComponentType.TRANSFER_FUNCTION: [Pin(0, "IN", -35, 0), Pin(1, "OUT", 35, 0)],
    ComponentType.DELAY_BLOCK: [Pin(0, "IN", -35, 0), Pin(1, "OUT", 35, 0)],
    ComponentType.SAMPLE_HOLD: [
        Pin(0, "IN", -35, -10),
        Pin(1, "TRIG", -35, 10),
        Pin(2, "OUT", 35, 0),
    ],
    ComponentType.STATE_MACHINE: [
        Pin(0, "IN1", -35, -12),
        Pin(1, "IN2", -35, 12),
        Pin(2, "OUT", 35, 0),
    ],

    # Measurement
    ComponentType.VOLTAGE_PROBE: [
        Pin(0, "+", 0, -20),
        Pin(1, "-", 0, 20),
        Pin(2, VOLTAGE_PROBE_OUTPUT_PIN_NAME, 25, 0),
    ],
    ComponentType.CURRENT_PROBE: [
        Pin(0, "IN", -20, 0),
        Pin(1, "OUT", 20, 0),
        Pin(2, CURRENT_PROBE_OUTPUT_PIN_NAME, 0, -20),
    ],
    ComponentType.POWER_PROBE: [
        Pin(0, "V+", -25, -15),
        Pin(1, "V-", -25, 15),
        Pin(2, "I+", 25, -15),
        Pin(3, "I-", 25, 15),
    ],

    # Scopes
    ComponentType.ELECTRICAL_SCOPE: _default_scope_pins(2),
    ComponentType.THERMAL_SCOPE: _default_scope_pins(2),

    # Signal routing
    ComponentType.SIGNAL_MUX: _default_mux_pins(4),
    ComponentType.SIGNAL_DEMUX: _default_demux_pins(4),

    # Magnetic
    ComponentType.SATURABLE_INDUCTOR: [Pin(0, "1", -30, 0), Pin(1, "2", 30, 0)],
    ComponentType.COUPLED_INDUCTOR: [
        Pin(0, "L1_1", -30, -15),
        Pin(1, "L1_2", -30, 15),
        Pin(2, "L2_1", 30, -15),
        Pin(3, "L2_2", 30, 15),
    ],

    # Pre-configured networks
    ComponentType.SNUBBER_RC: [Pin(0, "1", -25, 0), Pin(1, "2", 25, 0)],
}


def _normalize_default_pin_map() -> None:
    """Normalize every default pin layout to the global pin grid."""
    for comp_type, pins in list(DEFAULT_PINS.items()):
        DEFAULT_PINS[comp_type] = _snap_pin_layout(pins)


_normalize_default_pin_map()


# Default parameter templates for each component type
DEFAULT_PARAMETERS: dict[ComponentType, dict[str, Any]] = {
    # Basic passive
    ComponentType.RESISTOR: {"resistance": 1000.0},
    ComponentType.CAPACITOR: {"capacitance": 1e-6, "initial_voltage": 0.0},
    ComponentType.INDUCTOR: {"inductance": 1e-3, "initial_current": 0.0},

    # Sources
    ComponentType.VOLTAGE_SOURCE: {"waveform": {"type": "dc", "value": 5.0}},
    ComponentType.CURRENT_SOURCE: {"waveform": {"type": "dc", "value": 1.0}},
    ComponentType.GROUND: {},

    # Diodes
    ComponentType.DIODE: {"is_": 1e-14, "n": 1.0, "rs": 0.0},
    ComponentType.ZENER_DIODE: {"vz": 5.1, "iz_test": 0.02, "zz": 5.0, "is_": 1e-14},
    ComponentType.LED: {"vf": 2.0, "color": "red", "wavelength": 620},

    # Transistors
    ComponentType.MOSFET_N: {"vth": 2.0, "kp": 0.1, "lambda_": 0.0, "rds_on": 0.01},
    ComponentType.MOSFET_P: {"vth": -2.0, "kp": 0.1, "lambda_": 0.0, "rds_on": 0.01},
    ComponentType.IGBT: {"vth": 3.0, "vce_sat": 2.0},
    ComponentType.BJT_NPN: {"beta": 100.0, "vbe_sat": 0.7, "vce_sat": 0.2, "is_": 1e-14},
    ComponentType.BJT_PNP: {"beta": 100.0, "vbe_sat": -0.7, "vce_sat": -0.2, "is_": 1e-14},
    ComponentType.THYRISTOR: {"vgt": 1.0, "igt": 0.03, "holding_current": 0.05, "vf": 1.5},
    ComponentType.TRIAC: {"vgt": 1.5, "igt": 0.05, "holding_current": 0.05, "vf": 1.5},

    # Switching
    ComponentType.SWITCH: {"ron": 0.001, "roff": 1e9, "initial_state": False},

    # Transformer
    ComponentType.TRANSFORMER: {"turns_ratio": 1.0, "lm": 1e-3},

    # Analog
    ComponentType.OP_AMP: {
        "gain": 1e5,
        "gbw": 1e6,
        "slew_rate": 1e6,
        "vos": 0.0,
        "rail_to_rail": False,
    },
    ComponentType.COMPARATOR: {
        "vos": 0.0,
        "hysteresis": 0.0,
        "response_time": 1e-6,
    },

    # Protection
    ComponentType.RELAY: {
        "coil_voltage": 12.0,
        "coil_resistance": 400.0,
        "contact_rating": 10.0,
        "ron": 0.01,
        "roff": 1e9,
    },
    ComponentType.FUSE: {
        "rating": 1.0,
        "blow_i2t": 1.0,
    },
    ComponentType.CIRCUIT_BREAKER: {
        "trip_current": 10.0,
        "trip_time": 0.01,
        "ron": 0.001,
    },

    # Control blocks - basic
    ComponentType.PI_CONTROLLER: {
        "kp": 1.0,
        "ki": 100.0,
        "output_min": -1.0,
        "output_max": 1.0,
    },
    ComponentType.PID_CONTROLLER: {
        "kp": 1.0,
        "ki": 100.0,
        "kd": 0.01,
        "output_min": -1.0,
        "output_max": 1.0,
    },
    ComponentType.MATH_BLOCK: {
        "operation": "sum",
        "gain": 1.0,
    },
    ComponentType.PWM_GENERATOR: {
        "frequency": 10000.0,
        "duty_cycle": 0.5,
        "carrier": "sawtooth",
        "amplitude": 20.0,
    },
    ComponentType.GAIN: {
        "gain": 1.0,
    },
    ComponentType.SUM: {
        "input_count": 2,
        "signs": ["+", "+"],
    },
    ComponentType.SUBTRACTOR: {
        "input_count": 2,
        "signs": ["+", "-"],
    },
    ComponentType.CONSTANT: {
        "value": 0.0,
    },

    # Control blocks - signal processing
    ComponentType.INTEGRATOR: {
        "gain": 1.0,
        "initial_value": 0.0,
        "output_min": -1e6,
        "output_max": 1e6,
    },
    ComponentType.DIFFERENTIATOR: {
        "gain": 1.0,
        "filter_tau": 1e-6,
    },
    ComponentType.LIMITER: {
        "lower_limit": -1.0,
        "upper_limit": 1.0,
    },
    ComponentType.RATE_LIMITER: {
        "rising_rate": 1e6,
        "falling_rate": -1e6,
    },
    ComponentType.HYSTERESIS: {
        "upper_threshold": 0.5,
        "lower_threshold": -0.5,
        "output_high": 1.0,
        "output_low": 0.0,
    },

    # Control blocks - advanced
    ComponentType.LOOKUP_TABLE: {
        "table_x": [0.0, 0.5, 1.0],
        "table_y": [0.0, 0.25, 1.0],
        "interpolation": "linear",
    },
    ComponentType.TRANSFER_FUNCTION: {
        "numerator": [1.0],
        "denominator": [1.0, 1.0],
    },
    ComponentType.DELAY_BLOCK: {
        "delay_time": 1e-3,
    },
    ComponentType.SAMPLE_HOLD: {
        "sample_time": 1e-4,
    },
    ComponentType.STATE_MACHINE: {
        "states": ["S0", "S1"],
        "initial_state": "S0",
        "transitions": [],
    },

    # Measurement
    ComponentType.VOLTAGE_PROBE: {
        "display_name": "V",
        "scale": 1.0,
    },
    ComponentType.CURRENT_PROBE: {
        "display_name": "I",
        "scale": 1.0,
    },
    ComponentType.POWER_PROBE: {
        "display_name": "P",
        "scale": 1.0,
    },

    # Scopes
    ComponentType.ELECTRICAL_SCOPE: {
        "channel_count": 2,
        "channels": [
            {"label": "CH1", "overlay": False},
            {"label": "CH2", "overlay": False},
        ],
    },
    ComponentType.THERMAL_SCOPE: {
        "channel_count": 2,
        "channels": [
            {"label": "T1", "overlay": False},
            {"label": "T2", "overlay": False},
        ],
    },

    # Signal routing
    ComponentType.SIGNAL_MUX: {
        "input_count": 4,
        "channel_labels": ["Ch1", "Ch2", "Ch3", "Ch4"],
        "ordering": [0, 1, 2, 3],
    },
    ComponentType.SIGNAL_DEMUX: {
        "output_count": 4,
        "channel_labels": ["Ch1", "Ch2", "Ch3", "Ch4"],
        "ordering": [0, 1, 2, 3],
    },

    # Magnetic
    ComponentType.SATURABLE_INDUCTOR: {
        "inductance": 1e-3,
        "saturation_current": 10.0,
        "saturation_inductance": 1e-6,
    },
    ComponentType.COUPLED_INDUCTOR: {
        "l1": 1e-3,
        "l2": 1e-3,
        "mutual_inductance": 0.9e-3,
        "coupling_coefficient": 0.9,
    },

    # Pre-configured networks
    ComponentType.SNUBBER_RC: {
        "resistance": 100.0,
        "capacitance": 100e-9,
    },
}

# Parameters that are intentionally hidden from the default properties UI.
# They keep their default values unless the user edits the .pulsim file directly.
# RATIONALE - PWM amplitude: all supported switching devices (MOSFET, IGBT,
# VoltageControlledSwitch) operate correctly with the 20 V default. Exposing
# the amplitude invites users to lower it below the device threshold, breaking
# simulation convergence without obvious explanation.
HIDDEN_PARAMS: dict[ComponentType, frozenset[str]] = {
    ComponentType.PWM_GENERATOR: frozenset({"amplitude"}),
}


@dataclass
class Component:
    """A circuit component with position, parameters, and connections."""

    id: UUID = field(default_factory=uuid4)
    type: ComponentType = ComponentType.RESISTOR
    name: str = ""
    x: float = 0.0
    y: float = 0.0
    rotation: int = 0  # Degrees, multiples of 90
    mirrored_h: bool = False
    mirrored_v: bool = False
    parameters: dict[str, Any] = field(default_factory=dict)
    pins: list[Pin] = field(default_factory=list)

    def __post_init__(self):
        """Initialize default pins and parameters if not provided."""
        if not self.pins and self.type in DEFAULT_PINS:
            self.pins = [
                Pin(p.index, p.name, p.x, p.y) for p in DEFAULT_PINS[self.type]
            ]
        if not self.parameters and self.type in DEFAULT_PARAMETERS:
            self.parameters = deepcopy(DEFAULT_PARAMETERS[self.type])

        _synchronize_special_component(self)
        _snap_component_pins_to_grid(self)

    def get_pin_position(self, pin_index: int) -> tuple[float, float]:
        """Get absolute position of a pin, accounting for rotation and mirroring."""
        if pin_index >= len(self.pins):
            raise IndexError(f"Pin index {pin_index} out of range")

        pin = self.pins[pin_index]
        px, py = pin.x, pin.y

        # Apply mirroring
        if self.mirrored_h:
            px = -px
        if self.mirrored_v:
            py = -py

        # Apply rotation (in 90-degree increments)
        for _ in range((self.rotation // 90) % 4):
            px, py = -py, px

        return self.x + px, self.y + py

    def to_dict(self) -> dict:
        """Serialize component to dictionary."""
        return {
            "id": str(self.id),
            "type": self.type.name,
            "name": self.name,
            "x": self.x,
            "y": self.y,
            "rotation": self.rotation,
            "mirrored_h": self.mirrored_h,
            "mirrored_v": self.mirrored_v,
            "parameters": self.parameters,
            "pins": [p.to_dict() for p in self.pins],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Component":
        """Deserialize component from dictionary."""
        comp_type = ComponentType[data["type"]]
        if comp_type == ComponentType.SUBCIRCUIT:
            from pulsimgui.models.subcircuit import SubcircuitInstance

            return SubcircuitInstance.from_dict(data)

        return cls(
            id=UUID(data["id"]),
            type=comp_type,
            name=data["name"],
            x=data["x"],
            y=data["y"],
            rotation=data.get("rotation", 0),
            mirrored_h=data.get("mirrored_h", False),
            mirrored_v=data.get("mirrored_v", False),
            parameters=data.get("parameters", {}),
            pins=[Pin.from_dict(p) for p in data.get("pins", [])],
        )


SCOPE_CHANNEL_LIMITS = (1, 8)
MUX_CHANNEL_LIMITS = (2, 16)
SUM_INPUT_LIMITS = (2, 16)


def _clamp(value: int, min_value: int, max_value: int) -> int:
    return max(min_value, min(max_value, value))


def _synchronize_special_component(component: Component) -> None:
    if component.type in (ComponentType.ELECTRICAL_SCOPE, ComponentType.THERMAL_SCOPE):
        _synchronize_scope(component)
    elif component.type == ComponentType.SIGNAL_MUX:
        _synchronize_mux(component)
    elif component.type == ComponentType.SIGNAL_DEMUX:
        _synchronize_demux(component)
    elif component.type in (ComponentType.SUM, ComponentType.SUBTRACTOR):
        _synchronize_sum_like_block(component)
    elif component.type in (ComponentType.PI_CONTROLLER, ComponentType.PWM_GENERATOR, ComponentType.GAIN):
        _synchronize_default_pin_layout(component)
    elif component.type in (ComponentType.VOLTAGE_PROBE, ComponentType.CURRENT_PROBE):
        _synchronize_measurement_probe_pins(component)
    else:
        _synchronize_thermal_port(component)


def _synchronize_default_pin_layout(component: Component) -> None:
    """Synchronize components that always follow their default pin map."""
    default_pins = DEFAULT_PINS.get(component.type, [])
    if not default_pins:
        return
    if len(component.pins) == len(default_pins):
        names_match = all(component.pins[idx].name == default_pins[idx].name for idx in range(len(default_pins)))
        coords_match = all(
            abs(component.pins[idx].x - default_pins[idx].x) < 0.1
            and abs(component.pins[idx].y - default_pins[idx].y) < 0.1
            for idx in range(len(default_pins))
        )
        if names_match and coords_match:
            return
    component.pins = _snap_pin_layout([Pin(pin.index, pin.name, pin.x, pin.y) for pin in default_pins])


def _synchronize_measurement_probe_pins(component: Component) -> None:
    """Synchronize probe pin layout after schema changes."""
    default_pins = DEFAULT_PINS.get(component.type, [])
    if not default_pins:
        return
    if len(component.pins) == len(default_pins):
        names_match = all(component.pins[idx].name == default_pins[idx].name for idx in range(len(default_pins)))
        coords_match = all(
            abs(component.pins[idx].x - default_pins[idx].x) < 0.1
            and abs(component.pins[idx].y - default_pins[idx].y) < 0.1
            for idx in range(len(default_pins))
        )
        if names_match and coords_match:
            return
    component.pins = _snap_pin_layout([Pin(pin.index, pin.name, pin.x, pin.y) for pin in default_pins])


def _synchronize_sum_like_block(component: Component, force_count: int | None = None) -> None:
    """Synchronize SUM/SUBTRACTOR pin layout and signs list."""
    params = component.parameters
    requested = force_count or params.get("input_count") or 2
    input_count = _clamp(int(requested), *SUM_INPUT_LIMITS)
    params["input_count"] = input_count

    if component.type == ComponentType.SUBTRACTOR:
        default_signs = ["+"] + ["-"] * max(input_count - 1, 0)
    else:
        default_signs = ["+"] * input_count

    signs = list(params.get("signs") or [])
    if not signs:
        signs = default_signs
    while len(signs) < input_count:
        signs.append(default_signs[len(signs)])
    if len(signs) > input_count:
        del signs[input_count:]
    params["signs"] = signs

    component.pins = _snap_pin_layout(_default_sum_pins(input_count))


def _synchronize_thermal_port(component: Component) -> None:
    """Synchronize optional thermal measurement pin on supported components."""
    if not supports_thermal_port(component.type):
        component.parameters.pop(THERMAL_PORT_PARAMETER, None)
        return

    enabled = bool(component.parameters.get(THERMAL_PORT_PARAMETER, False))
    component.parameters[THERMAL_PORT_PARAMETER] = enabled

    base_pins = DEFAULT_PINS.get(component.type, [])
    if not base_pins:
        return

    # Keep the current electrical pin map stable and reserve TH as optional last pin.
    # This preserves extended pin layouts (for example, a controlled switch with 3 pins).
    pins = [Pin(pin.index, pin.name, pin.x, pin.y) for pin in component.pins if pin.name != THERMAL_PORT_PIN_NAME]
    if len(pins) < len(base_pins):
        pins = [Pin(pin.index, pin.name, pin.x, pin.y) for pin in base_pins]

    if enabled:
        pins.append(Pin(index=len(pins), name=THERMAL_PORT_PIN_NAME, x=0.0, y=PIN_GRID_STEP))

    for index, pin in enumerate(pins):
        pin.index = index
    component.pins = _snap_pin_layout(pins)


def _synchronize_scope(component: Component, force_count: int | None = None) -> None:
    params = component.parameters
    requested = force_count or params.get("channel_count") or len(params.get("channels", [])) or 1
    channel_count = _clamp(int(requested), *SCOPE_CHANNEL_LIMITS)
    params["channel_count"] = channel_count

    channels = params.setdefault("channels", [])
    prefix = _scope_label_prefix(component.type)

    while len(channels) < channel_count:
        channels.append({"label": f"{prefix}{len(channels) + 1}", "overlay": False})
    if len(channels) > channel_count:
        del channels[channel_count:]

    for idx, channel in enumerate(channels):
        channel.setdefault("label", f"{prefix}{idx + 1}")
        channel.setdefault("overlay", False)

    component.pins = _snap_pin_layout(_default_scope_pins(channel_count))


def _synchronize_mux(component: Component, force_count: int | None = None) -> None:
    params = component.parameters
    requested = force_count or params.get("input_count") or len(params.get("channel_labels", [])) or 2
    input_count = _clamp(int(requested), *MUX_CHANNEL_LIMITS)
    params["input_count"] = input_count

    labels = params.setdefault("channel_labels", [])
    while len(labels) < input_count:
        labels.append(f"Ch{len(labels) + 1}")
    if len(labels) > input_count:
        del labels[input_count:]

    ordering = params.setdefault("ordering", list(range(input_count)))
    ordering = [int(idx) for idx in ordering[:input_count]]
    while len(ordering) < input_count:
        ordering.append(len(ordering))
    params["ordering"] = [
        max(0, min(input_count - 1, idx)) for idx in ordering
    ]

    component.pins = _snap_pin_layout(_default_mux_pins(input_count))


def _synchronize_demux(component: Component, force_count: int | None = None) -> None:
    params = component.parameters
    requested = force_count or params.get("output_count") or len(params.get("channel_labels", [])) or 2
    output_count = _clamp(int(requested), *MUX_CHANNEL_LIMITS)
    params["output_count"] = output_count

    labels = params.setdefault("channel_labels", [])
    while len(labels) < output_count:
        labels.append(f"Ch{len(labels) + 1}")
    if len(labels) > output_count:
        del labels[output_count:]

    ordering = params.setdefault("ordering", list(range(output_count)))
    ordering = [int(idx) for idx in ordering[:output_count]]
    while len(ordering) < output_count:
        ordering.append(len(ordering))
    params["ordering"] = [
        max(0, min(output_count - 1, idx)) for idx in ordering
    ]

    component.pins = _snap_pin_layout(_default_demux_pins(output_count))


def set_scope_channel_count(component: Component, count: int) -> None:
    """Update a scope component to use the provided channel count."""

    _synchronize_scope(component, force_count=count)


def set_mux_input_count(component: Component, count: int) -> None:
    """Update a mux component's input count and pin layout."""

    _synchronize_mux(component, force_count=count)


def set_demux_output_count(component: Component, count: int) -> None:
    """Update a demux component's output count and pin layout."""

    _synchronize_demux(component, force_count=count)


def set_sum_input_count(component: Component, count: int) -> None:
    """Update SUM/SUBTRACTOR input count and pin layout."""

    if component.type not in (ComponentType.SUM, ComponentType.SUBTRACTOR):
        return
    _synchronize_sum_like_block(component, force_count=count)


def set_thermal_port_enabled(component: Component, enabled: bool) -> None:
    """Enable or disable thermal measurement pin for compatible components."""

    component.parameters[THERMAL_PORT_PARAMETER] = bool(enabled)
    _synchronize_special_component(component)
