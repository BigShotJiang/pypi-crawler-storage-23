"""Waveform viewer views."""

from pulsimgui.views.waveform.waveform_viewer import WaveformViewer

__all__ = ["WaveformViewer"]
