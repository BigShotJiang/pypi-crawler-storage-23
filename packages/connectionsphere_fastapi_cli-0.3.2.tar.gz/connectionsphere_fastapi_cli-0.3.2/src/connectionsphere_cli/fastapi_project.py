import os
import shutil
from pathlib import Path

import typer
from jinja2 import Environment, FileSystemLoader

TEMPLATE_DIR = Path(__file__).parent / "templates"


def create_fastapi_project(project_name: str, add_redis: bool, add_postgres: bool):
    if os.path.exists(project_name):
        raise typer.BadParameter(f"Directory '{project_name}' already exists")

    env = Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)))

    # Create directory structure
    dirs = [
        f"{project_name}/app",
        f"{project_name}/app/api/v1",
        f"{project_name}/app/core",
        f"{project_name}/app/models",
        f"{project_name}/app/services",
        f"{project_name}/app/schemas",
        f"{project_name}/tests",
        f"{project_name}/alembic",
        f"{project_name}/alembic/versions",
    ]

    for d in dirs:
        os.makedirs(d, exist_ok=True)

    # Common files
    files = {
        "app/__init__.py": "",
        "app/main.py": "main.py.j2",
        "app/api/v1/__init__.py": "",
        "app/api/v1/endpoints.py": "endpoints.py.j2",
        "app/core/config.py": "config.py.j2",
        "app/core/security.py": "security.py.j2",
        "app/models/__init__.py": "",
        "tests/__init__.py": "",
        "tests/conftest.py": "conftest.py.j2",
        ".gitignore": "gitignore.j2",
        "tests/test_main.py": "test_main.py.j2",
        ".env": "env.j2",
        "alembic.ini": "alembic.ini.j2",
        "pyproject.toml": "pyproject.toml.j2",
        "docker-compose.yml": "docker-compose.yml.j2",
        ".pre-commit-config.yaml": ".pre-commit-config.yaml",
        ".github/workflows/ci.yml": "fastapi_ci.yml.j2",
        "app/schemas/__init__.py": "",
    }

    context = {
        "project_name": project_name,
        "add_redis": add_redis,
        "add_postgres": add_postgres,
    }

    for dest, template in files.items():
        dest_path = Path(project_name) / dest
        if template:
            template = env.get_template(template)
            content = template.render(**context)
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            dest_path.write_text(content)
        else:
            dest_path.touch()

    # Create security files
    (Path(project_name) / "app/core/security.py").write_text(
        env.get_template("security.py.j2").render()
    )

    typer.echo(
        f"""
    Project structure created:
    {project_name}/
    ├── app/
    │   ├── api/v1/endpoints.py    # Versioned API endpoints
    │   ├── core/                  # Config, security, and middleware
    │   ├── models/                # Database (SQLModel/SQLAlchemy) models
    │   ├── schemas/               # Pydantic schemas (request/response models)
    │   ├── services/              # Business logic/services layer
    │   └── main.py                # FastAPI app instance
    ├── tests/                     # pytest tests
    ├── .github/workflows/ci.yml   # CI/CD pipeline
    ├── docker-compose.yml         # Redis/Postgres services
    ├── pyproject.toml             # Project config
    └── .pre-commit-config.yaml    # Code quality hooks
    
    Next steps:
    1. cd {project_name}
    2. uv pip install -r requirements.txt
    3. pre-commit install
    4. docker-compose up -d  # If using Redis/Postgres
    5. uvicorn app.main:app --reload
    """
    )
