import os
import typer
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, TemplateNotFound


def generate_github_actions(project_name: str):
    """
    Generate GitHub Actions workflow file in the project directory.
    """
    # Define paths
    project_dir = project_name
    workflows_dir = os.path.join(project_dir, ".github", "workflows")
    workflow_file = os.path.join(workflows_dir, "main.yml")

    # Create .github/workflows directory
    try:
        os.makedirs(workflows_dir, exist_ok=True)
        typer.echo(f"📁 Created directory: .github/workflows")
    except OSError as e:
        typer.echo(f"❌ Error creating workflows directory: {e}")
        raise typer.Exit(code=1)

    # Set up Jinja2 environment
    TEMPLATE_DIR = Path(__file__).parent / "templates"
    env = Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)))

    try:
        template = env.get_template("github_actions.yml.j2")
    except TemplateNotFound:
        typer.echo(
            "❌ GitHub Actions template not found. Please ensure 'templates/github_actions.yml.j2' exists."
        )
        raise typer.Exit(code=1)

    # Template variables
    template_vars = {
        "project_name": project_name,
        "uv_version": "0.7.12",  # Pin to stable version
        "python_version": "3.11",  # Default Python version
    }

    # Render and write the workflow file
    try:
        workflow_content = template.render(**template_vars)
        with open(workflow_file, "w") as f:
            f.write(workflow_content)
        typer.echo(f"✅ Created GitHub Actions workflow: .github/workflows/main.yml")
    except Exception as e:
        typer.echo(f"❌ Error generating workflow file: {e}")
        raise typer.Exit(code=1)


def add_precommit_config(project_name: str):
    """
    Add pre-commit configuration file to the project.
    """
    precommit_config = """repos:
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.11.13
    hooks:
      # Run the linter with autofix
      - id: ruff
        args: [--fix]
      # Run the formatter
      - id: ruff-format

  - repo: https://github.com/psf/black
    rev: 24.3.0
    hooks:
      - id: black
"""

    precommit_file = os.path.join(project_name, ".pre-commit-config.yaml")

    try:
        with open(precommit_file, "w") as f:
            f.write(precommit_config)
        typer.echo("✅ Created .pre-commit-config.yaml with Ruff and Black")
    except Exception as e:
        typer.echo(f"❌ Error creating pre-commit config: {e}")
        raise typer.Exit(code=1)
