import os
import subprocess
import typer

def create_uv_project(project_name: str):
    """
    Create a new project directory, scaffold full FastAPI structure,
    initialize a UV Python environment, create a virtual environment,
    add core dependencies, and setup pre-commit.
    """
    if os.path.exists(project_name):
        typer.echo(f"❌ Directory '{project_name}' already exists.")
        raise typer.Exit(code=1)

    # --- 1. Scaffold the directory structure ---
    dirs = [
        f"{project_name}/app/api",
        f"{project_name}/app/core",
        f"{project_name}/app/models",
        f"{project_name}/app/schemas",
        f"{project_name}/app/services",
        f"{project_name}/tests",
        f"{project_name}/alembic/versions",
        f"{project_name}/.github/workflows",
    ]
    for d in dirs:
        os.makedirs(d, exist_ok=True)
    # Touch __init__.py files
    for d in [
        f"{project_name}/app",
        f"{project_name}/app/api",
        f"{project_name}/app/core",
        f"{project_name}/app/models",
        f"{project_name}/app/schemas",
        f"{project_name}/app/services",
        f"{project_name}/tests",
    ]:
        with open(os.path.join(d, "__init__.py"), "w") as f:
            pass

    # --- 2. Create minimal main.py and other starter files ---
    main_py = os.path.join(project_name, "app", "main.py")
    if not os.path.exists(main_py):
        with open(main_py, "w") as f:
            f.write(
                "from fastapi import FastAPI\n\napp = FastAPI()\n\n"
                "@app.get('/')\ndef root():\n    return {'message': 'Hello, world!'}\n"
            )

    # --- 3. Create basic config files if not present ---
    files_content = {
        ".env": "",
        ".gitignore": ".venv/\n__pycache__/\n*.pyc\n.env\n",
        "docker-compose.yml": "# Add your docker-compose config here\n",
        "alembic.ini": "# Alembic configuration\n",
        "pyproject.toml": (
            '[project]\n'
            f'name = "{project_name}"\n'
            'version = "0.1.0"\n'
            'description = "FastAPI project scaffolded with ConnectionSphere CLI"\n'
        ),
    }
    for fname, content in files_content.items():
        fpath = os.path.join(project_name, fname)
        if not os.path.exists(fpath):
            with open(fpath, "w") as f:
                f.write(content)

    # --- 4. Initialize UV and venv ---
    try:
        subprocess.run(["uv", "init", "--no-workspace"], cwd=project_name, check=True)
        typer.echo(f"✅ Initialized UV environment in '{project_name}'.")
    except FileNotFoundError:
        typer.echo("❌ 'uv' is not installed or not found in PATH. Please install UV.")
        raise typer.Exit(code=1)
    except subprocess.CalledProcessError as e:
        typer.echo(f"❌ Error running 'uv init': {e}")
        raise typer.Exit(code=1)

    try:
        subprocess.run(["uv", "venv"], cwd=project_name, check=True)
        typer.echo(f"✅ Created virtual environment in '{project_name}/.venv'.")
    except subprocess.CalledProcessError as e:
        typer.echo(f"❌ Error creating virtual environment: {e}")
        raise typer.Exit(code=1)

    # --- 5. Add core dependencies ---
    try:
        subprocess.run(
            ["uv", "add", "fastapi", "uvicorn", "black", "pre-commit"],
            cwd=project_name,
            check=True
        )
        typer.echo(f"✅ Added core dependencies to '{project_name}'.")
    except subprocess.CalledProcessError as e:
        typer.echo(f"❌ Error adding dependencies: {e}")
        raise typer.Exit(code=1)

    # --- 6. Create .pre-commit-config.yaml ---
    precommit_config = '''repos:
  - repo: https://github.com/psf/black
    rev: 24.3.0
    hooks:
      - id: black
        language_version: python3.11

  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.11.13
    hooks:
      - id: ruff
        args: [--fix]
      - id: ruff-format

  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.4.0
    hooks:
      - id: trailing-whitespace
      - id: end-of-file-fixer
      - id: check-yaml
'''
    precommit_path = os.path.join(project_name, ".pre-commit-config.yaml")
    try:
        with open(precommit_path, "w") as f:
            f.write(precommit_config)
        typer.echo(f"✅ Created .pre-commit-config.yaml in '{project_name}'.")
    except Exception as e:
        typer.echo(f"❌ Error writing pre-commit config: {e}")
        raise typer.Exit(code=1)

    # --- 7. Install pre-commit hooks ---
    try:
        subprocess.run(["pre-commit", "install"], cwd=project_name, check=True)
        typer.echo(f"✅ Installed pre-commit hooks in '{project_name}'.")
    except subprocess.CalledProcessError as e:
        typer.echo(f"❌ Error installing pre-commit hooks: {e}")
        raise typer.Exit(code=1)

    typer.echo(f"\n✅ Project '{project_name}' fully initialized with structure, UV venv, dependencies, and pre-commit.")
