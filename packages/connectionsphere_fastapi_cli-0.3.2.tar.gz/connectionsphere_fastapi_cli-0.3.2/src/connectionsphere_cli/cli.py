import os
import subprocess
import typer
from rich.console import Console
from rich.panel import Panel

from connectionsphere_cli.fastapi_project import create_fastapi_project
from connectionsphere_cli.uv_project import create_uv_project
from connectionsphere_cli.github_actions import generate_github_actions

app = typer.Typer(
    help="""
ConnectionSphere CLI

A tool to scaffold production-ready FastAPI projects with UV, set up
GitHub Actions CI/CD, and enforce code quality with pre-commit hooks.

Common workflow:
  1. Scaffold a new FastAPI project:
     $ fastapi-cli fastapi-scaffold my-api

  2. Or initialise a plain UV project:
     $ fastapi-cli init myproject

  3. Push to GitHub:
     $ fastapi-cli create-github myproject --private

Documentation: https://github.com/ConnectSphere/connectionsphere-fastapi-cli
""",
    no_args_is_help=True,
)


# ──────────────────────────────────────────────────────────────────────────────
# Reference guides
# ──────────────────────────────────────────────────────────────────────────────

@app.command("pseudocode-guide")
def pseudocode_guide():
    """Display a guide for writing pseudocode for DSA problems."""
    console = Console()
    steps = [
        ("Understand the Problem", "Read the question carefully",
         "Identify inputs, expected outputs, and constraints."),
        ("Define the Algorithm Header", "Start your pseudocode",
         "Write FUNCTION <AlgorithmName>(parameters) and describe its purpose."),
        ("Declare Variables and Data Structures", "Inside the function",
         "INITIALIZE variables and data structures as needed."),
        ("Outline the Main Steps", "Inside the function",
         "Use SEQUENCE, IF/ELSE, FOR, WHILE as appropriate."),
        ("Use Proper Constructs", "Throughout pseudocode",
         "End blocks with ENDIF, ENDFOR, ENDWHILE, etc."),
        ("Handle Edge Cases", "Inside logic",
         "Check for empty lists, invalid inputs, or special cases."),
        ("Return or Output the Result", "At the end",
         "RETURN the final answer or data structure."),
        ("Test and Refine", "After writing pseudocode",
         "Walk through your steps with sample inputs and refine."),
    ]
    for step, where, cmd in steps:
        console.print(Panel(
            f"[bold yellow]Step:[/bold yellow] {step}\n"
            f"[green]Where:[/green] {where}\n"
            f"[white]Action:[/white] {cmd}",
            expand=False,
        ))
    console.print(
        "\n[bold green]Conventions:[/bold green]\n"
        "- Capitalize keywords: IF, FOR, WHILE, ENDIF\n"
        "- Indent to show hierarchy\n"
        "- One statement per line\n"
        "- Stay language-agnostic\n"
    )


@app.command("git-cheat-sheet")
def git_cheat_sheet():
    """Display a Git cheat sheet."""
    console = Console()
    sections = [
        ("Setup",
         "git config --global user.name \"Your Name\"\n"
         "git config --global user.email \"your@email.com\""),
        ("Start a Project",
         "git init <directory>\ngit clone <url>"),
        ("Make a Change",
         "git add <file>  |  git add .\n"
         "git commit -m \"message\"\n"
         "git commit -am \"message\""),
        ("Branches",
         "git branch              # list\n"
         "git checkout -b <name>  # create & switch\n"
         "git branch -d <name>    # delete"),
        ("Merging",
         "git merge <branch>\ngit merge --squash <branch>"),
        ("Rebasing",
         "git rebase main\ngit rebase -i HEAD~3"),
        ("Undoing",
         "git reset <file>          # unstage\n"
         "git revert <commit_ID>\n"
         "git reset --hard <commit_ID>"),
        ("Review",
         "git status\ngit log --oneline\ngit diff"),
        ("Stashing",
         "git stash          # save\n"
         "git stash list\n"
         "git stash apply\n"
         "git stash drop stash@{1}"),
        ("Synchronizing",
         "git remote add <alias> <url>\n"
         "git fetch <alias>\n"
         "git pull  |  git push <alias> <branch>"),
    ]
    for title, content in sections:
        console.print(Panel(f"[bold]{title}[/bold]\n{content}", expand=False))


@app.command("git-refactor-workflow")
def git_refactor_workflow():
    """Display a Git workflow for refactoring a legacy app."""
    console = Console()
    steps = [
        ("Preparation", "Read docs, run the app, write regression/unit tests."),
        ("Create Refactor Branch",
         "git checkout main && git pull origin main\n"
         "git checkout -b refactor/modernize-app"),
        ("Incremental Refactoring",
         "Refactor small sections. After each change:\n"
         "git add . && git commit -m \"Refactor: [describe change]\""),
        ("Push & PR", "git push origin refactor/modernize-app\nOpen a PR for review."),
        ("Feature Branches Off Refactor",
         "git checkout -b feature/new-api-endpoint"),
        ("Final Merge to Main",
         "git checkout main && git pull origin main\n"
         "git merge refactor/modernize-app && git push origin main"),
    ]
    for title, content in steps:
        console.print(Panel(f"[bold]{title}[/bold]\n{content}", expand=False))
    console.print(
        "\n[bold green]Best Practices:[/bold green]\n"
        "- Feature branches for all changes\n"
        "- Test frequently\n"
        "- PRs for code review\n"
        "- Refactor incrementally\n"
    )


# ──────────────────────────────────────────────────────────────────────────────
# Project commands
# ──────────────────────────────────────────────────────────────────────────────

@app.command("init")
def init(
    project_name: str = typer.Argument(..., help="Name of the new project directory"),
):
    """
    Initialise a new UV Python project with structure, venv,
    core dependencies, pre-commit hooks, and GitHub Actions.
    """
    create_uv_project(project_name)
    generate_github_actions(project_name)
    typer.echo(
        f"✅ Project '{project_name}' initialised with UV, venv, "
        f"dependencies, pre-commit, and GitHub Actions!"
    )


@app.command("create-github")
def create_github_repo(
    project_dir: str = typer.Argument(..., help="Local project directory to publish"),
    repo_name: str = typer.Option(
        None, help="GitHub repo name (defaults to project directory name)"
    ),
    private: bool = typer.Option(False, help="Create a private repo (default: public)"),
):
    """
    Create a GitHub repository from the local project and push all files.
    Requires the GitHub CLI (gh) and git.
    """
    if not os.path.isdir(project_dir):
        typer.echo(f"❌ Directory '{project_dir}' does not exist.")
        raise typer.Exit(1)

    repo_name = repo_name or os.path.basename(os.path.abspath(project_dir))
    visibility = "--private" if private else "--public"

    if not os.path.isdir(os.path.join(project_dir, ".git")):
        subprocess.run(["git", "init"], cwd=project_dir, check=True)
        typer.echo("✅ Initialised git repository.")

    subprocess.run(["git", "add", "."], cwd=project_dir, check=True)
    result = subprocess.run(
        ["git", "rev-parse", "--quiet", "--verify", "HEAD"], cwd=project_dir
    )
    if result.returncode != 0:
        subprocess.run(
            ["git", "commit", "-m", "Initial commit"], cwd=project_dir, check=True
        )
        typer.echo("✅ Created initial commit.")

    gh_cmd = [
        "gh", "repo", "create", repo_name, visibility,
        "--source", ".", "--remote", "origin", "--push",
    ]
    try:
        subprocess.run(gh_cmd, cwd=project_dir, check=True)
        typer.echo(f"🚀 Repo '{repo_name}' created on GitHub and code pushed!")
    except subprocess.CalledProcessError as e:
        typer.echo(f"❌ Failed to create/push repo: {e}")
        raise typer.Exit(1)


@app.command("fastapi-scaffold")
def fastapi_scaffold(
    project_name: str = typer.Argument(..., help="Name of the FastAPI project"),
    add_redis: bool = typer.Option(False, "--redis", help="Include Redis integration"),
    add_postgres: bool = typer.Option(
        False, "--postgres", help="Include Postgres integration"
    ),
):
    """Scaffold a production-ready FastAPI project with best practices."""
    create_fastapi_project(project_name, add_redis, add_postgres)
    typer.echo(
        f"✅ FastAPI project '{project_name}' created with security, testing, and CI/CD"
    )


if __name__ == "__main__":
    app()
