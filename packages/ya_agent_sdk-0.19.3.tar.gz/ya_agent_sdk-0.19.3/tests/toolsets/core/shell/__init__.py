"""Tests for shell toolset."""
