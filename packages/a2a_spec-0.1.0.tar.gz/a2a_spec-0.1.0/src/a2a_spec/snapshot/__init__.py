"""Snapshot recording, storage, and replay."""
