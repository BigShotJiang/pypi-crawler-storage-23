"""Structural and semantic diff engines."""
