"""Pipeline DAG building, execution, and tracing."""
