"""Semantic embedding and similarity infrastructure."""
