"""Internal utilities for a2a-spec. Not part of the public API."""
