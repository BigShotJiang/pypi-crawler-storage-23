"""Agent adapters for wrapping different agent types."""
