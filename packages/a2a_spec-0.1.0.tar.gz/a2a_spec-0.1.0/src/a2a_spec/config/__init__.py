"""Project configuration loading and management."""
