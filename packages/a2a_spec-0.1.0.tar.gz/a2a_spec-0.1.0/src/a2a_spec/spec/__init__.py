"""Spec definition, loading, and validation."""
