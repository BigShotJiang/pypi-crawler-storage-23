"""Report generation for CLI and CI."""
