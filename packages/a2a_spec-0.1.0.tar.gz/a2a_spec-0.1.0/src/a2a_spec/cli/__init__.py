"""CLI commands for a2a-spec."""
