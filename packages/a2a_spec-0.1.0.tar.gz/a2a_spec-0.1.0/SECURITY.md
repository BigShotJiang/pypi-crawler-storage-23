# Security Policy

## Supported Versions

| Version | Supported |
| ------- | --------- |
| 0.1.x   | Yes       |

## Reporting a Vulnerability

Please **do not** open a public issue for security vulnerabilities.

Use GitHub's private vulnerability reporting instead:
https://github.com/padobrik/a2a-spec/security/advisories/new

You can expect an acknowledgement within 48 hours and a resolution or
mitigation plan within 14 days.
