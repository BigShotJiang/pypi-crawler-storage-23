"""Tests for a2a-spec."""
