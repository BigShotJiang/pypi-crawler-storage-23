## Summary

<!-- What does this PR do? One paragraph is enough. -->

## Changes

<!-- Bullet list of the concrete changes made. -->

-

## Test plan

<!-- How was this tested? Check all that apply. -->

- [ ] Added / updated unit tests
- [ ] All existing tests pass (`pytest tests/`)
- [ ] Lint and format clean (`ruff check src/ tests/ && ruff format --check src/ tests/`)
- [ ] Type check passes (`mypy src/`)

## Related issues

<!-- Fixes #N  /  Related to #N  /  N/A -->
