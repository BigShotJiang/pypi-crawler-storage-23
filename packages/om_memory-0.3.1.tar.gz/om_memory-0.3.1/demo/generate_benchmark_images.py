#!/usr/bin/env python3
"""
om-memory Benchmark: 50-Turn Comparison — Traditional RAG vs Observational Memory
==================================================================================
Generates publication-quality charts for LinkedIn posts.

Token math (realistic, based on actual RAG pipelines):
- System prompt base: ~120 tokens
- Retrieved docs per turn: ~400 tokens (3 chunks × ~130 tokens)
- Average user query: ~40 tokens
- Average assistant response: ~150 tokens
- Traditional RAG: re-sends FULL chat history every turn → O(n²)
- om-memory: compressed observations (~250-400 tokens) + last 3 msgs → O(1)

Run:
    python generate_benchmark_images.py
"""

import os
import random
import numpy as np
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.patches import FancyBboxPatch
from pathlib import Path

# ── Output directory ─────────────────────────────────────────────────────────
OUTPUT_DIR = Path(__file__).parent / "benchmark_images"
OUTPUT_DIR.mkdir(exist_ok=True)

# ── Simulation Parameters ────────────────────────────────────────────────────
NUM_TURNS = 50
SYSTEM_PROMPT_TOKENS = 120
RETRIEVED_DOCS_TOKENS = 400  # 3 chunks, ~130 tokens each
AVG_USER_QUERY_TOKENS = 40
AVG_ASSISTANT_RESPONSE_TOKENS = 150
OM_OBSERVATION_WINDOW_TOKENS = 300  # Compressed memory context
OM_RECENT_MSGS_COUNT = 3  # Rolling window retains 3 messages
OM_OBSERVATION_GROWTH_PER_5_TURNS = 30  # Observations grow slowly

# GPT-4o-mini pricing (per 1M tokens)
INPUT_PRICE_PER_1M = 0.15   # $0.15 / 1M input tokens
OUTPUT_PRICE_PER_1M = 0.60  # $0.60 / 1M output tokens

# ── Simulation ───────────────────────────────────────────────────────────────
random.seed(42)
np.random.seed(42)

def simulate():
    """Simulate 50-turn conversation token usage for both approaches."""
    rag_per_turn_prompt = []
    rag_per_turn_total = []
    rag_cumulative = []
    rag_context_window = []

    om_per_turn_prompt = []
    om_per_turn_total = []
    om_cumulative = []
    om_context_window = []
    om_observations_count = []

    rag_cum = 0
    om_cum = 0

    chat_history_tokens = 0  # Running total for RAG's full history
    om_current_obs_tokens = 0

    for turn in range(1, NUM_TURNS + 1):
        # Slight variance for realism
        user_q = AVG_USER_QUERY_TOKENS + random.randint(-10, 15)
        assistant_resp = AVG_ASSISTANT_RESPONSE_TOKENS + random.randint(-30, 40)
        retrieved = RETRIEVED_DOCS_TOKENS + random.randint(-50, 50)

        # ── Traditional RAG ──────────────────────────────────────────
        # Prompt = system + retrieved docs + FULL chat history + current query
        rag_prompt = SYSTEM_PROMPT_TOKENS + retrieved + chat_history_tokens + user_q
        rag_total = rag_prompt + assistant_resp
        rag_cum += rag_total

        rag_per_turn_prompt.append(rag_prompt)
        rag_per_turn_total.append(rag_total)
        rag_cumulative.append(rag_cum)
        rag_context_window.append(rag_prompt)

        # After this turn, add Q+A to chat history for next turn
        chat_history_tokens += user_q + assistant_resp

        # ── om-memory ────────────────────────────────────────────────
        # Observations grow slowly (compressed memory)
        if turn % 5 == 0:
            om_current_obs_tokens += OM_OBSERVATION_GROWTH_PER_5_TURNS
        obs_tokens = OM_OBSERVATION_WINDOW_TOKENS + om_current_obs_tokens

        # Keep only last 3 messages in context
        recent_msgs_tokens = min(
            OM_RECENT_MSGS_COUNT * (AVG_USER_QUERY_TOKENS + AVG_ASSISTANT_RESPONSE_TOKENS),
            turn * (AVG_USER_QUERY_TOKENS + AVG_ASSISTANT_RESPONSE_TOKENS)
        )

        om_prompt = SYSTEM_PROMPT_TOKENS + retrieved + obs_tokens + recent_msgs_tokens + user_q
        om_total = om_prompt + assistant_resp
        om_cum += om_total

        om_per_turn_prompt.append(om_prompt)
        om_per_turn_total.append(om_total)
        om_cumulative.append(om_cum)
        om_context_window.append(om_prompt)
        om_observations_count.append(max(3, turn // 3 + random.randint(0, 2)))

    return {
        "turns": list(range(1, NUM_TURNS + 1)),
        "rag_prompt": rag_per_turn_prompt,
        "rag_total": rag_per_turn_total,
        "rag_cumulative": rag_cumulative,
        "rag_context": rag_context_window,
        "om_prompt": om_per_turn_prompt,
        "om_total": om_per_turn_total,
        "om_cumulative": om_cumulative,
        "om_context": om_context_window,
        "om_observations": om_observations_count,
    }


def calc_cost(total_tokens_list, per_turn_prompt_list):
    """Calculate cost given token lists."""
    total_input = sum(per_turn_prompt_list)
    total_output = sum(t - p for t, p in zip(total_tokens_list, per_turn_prompt_list))
    input_cost = (total_input / 1_000_000) * INPUT_PRICE_PER_1M
    output_cost = (total_output / 1_000_000) * OUTPUT_PRICE_PER_1M
    return input_cost + output_cost, total_input, total_output


# ── Chart Style ──────────────────────────────────────────────────────────────
# Dark modern theme
DARK_BG = "#0f1117"
CARD_BG = "#1a1a2e"
GRID_COLOR = "#2a2a3e"
TEXT_COLOR = "#e2e8f0"
SUBTEXT_COLOR = "#94a3b8"
RAG_COLOR = "#ef4444"
RAG_COLOR_LIGHT = "#fca5a5"
OM_COLOR = "#22c55e"
OM_COLOR_LIGHT = "#86efac"
ACCENT_PURPLE = "#818cf8"
ACCENT_PURPLE_LIGHT = "#a5b4fc"

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans", "Arial", "Helvetica"],
    "font.size": 12,
    "axes.facecolor": CARD_BG,
    "figure.facecolor": DARK_BG,
    "text.color": TEXT_COLOR,
    "axes.labelcolor": TEXT_COLOR,
    "xtick.color": SUBTEXT_COLOR,
    "ytick.color": SUBTEXT_COLOR,
    "axes.edgecolor": GRID_COLOR,
    "grid.color": GRID_COLOR,
    "grid.alpha": 0.5,
})


def format_k(x, _):
    if x >= 1_000_000:
        return f"{x/1_000_000:.1f}M"
    elif x >= 1_000:
        return f"{x/1_000:.0f}K"
    return f"{int(x)}"


# ── Chart 1: Cumulative Token Usage ──────────────────────────────────────────
def chart_cumulative_tokens(data):
    fig, ax = plt.subplots(figsize=(14, 8))

    ax.fill_between(data["turns"], data["rag_cumulative"], alpha=0.15, color=RAG_COLOR)
    ax.plot(data["turns"], data["rag_cumulative"], color=RAG_COLOR, linewidth=3,
            label="Traditional RAG", marker="o", markersize=4, markevery=5)

    ax.fill_between(data["turns"], data["om_cumulative"], alpha=0.15, color=OM_COLOR)
    ax.plot(data["turns"], data["om_cumulative"], color=OM_COLOR, linewidth=3,
            label="om-memory", marker="s", markersize=4, markevery=5)

    ax.set_xlabel("Conversation Turn", fontsize=14, fontweight="bold", labelpad=10)
    ax.set_ylabel("Cumulative Tokens Used", fontsize=14, fontweight="bold", labelpad=10)
    ax.yaxis.set_major_formatter(ticker.FuncFormatter(format_k))
    ax.grid(True, linestyle="--", alpha=0.3)
    ax.legend(fontsize=14, loc="upper left", framealpha=0.3, edgecolor=GRID_COLOR)

    # Annotate final values
    rag_final = data["rag_cumulative"][-1]
    om_final = data["om_cumulative"][-1]
    savings_pct = ((rag_final - om_final) / rag_final) * 100

    ax.annotate(f"{format_k(rag_final, None)} tokens",
                xy=(NUM_TURNS, rag_final), xytext=(-120, 20),
                textcoords="offset points", fontsize=12, fontweight="bold",
                color=RAG_COLOR_LIGHT,
                arrowprops=dict(arrowstyle="->", color=RAG_COLOR_LIGHT, lw=1.5))
    ax.annotate(f"{format_k(om_final, None)} tokens",
                xy=(NUM_TURNS, om_final), xytext=(-120, -30),
                textcoords="offset points", fontsize=12, fontweight="bold",
                color=OM_COLOR_LIGHT,
                arrowprops=dict(arrowstyle="->", color=OM_COLOR_LIGHT, lw=1.5))

    # Title
    fig.suptitle("Cumulative Token Usage: 50-Turn Conversation",
                 fontsize=20, fontweight="bold", color=TEXT_COLOR, y=0.97)
    ax.set_title(f"om-memory saves {savings_pct:.0f}% tokens vs Traditional RAG",
                 fontsize=14, color=ACCENT_PURPLE_LIGHT, pad=15)

    # Watermark
    fig.text(0.99, 0.01, "om-memory v0.2.4  •  pypi.org/project/om-memory",
             fontsize=9, color=SUBTEXT_COLOR, ha="right", va="bottom", alpha=0.6)

    plt.tight_layout(rect=[0, 0.02, 1, 0.95])
    path = OUTPUT_DIR / "01_cumulative_tokens.png"
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"  ✅ Saved: {path}")
    return savings_pct


# ── Chart 2: Context Window Size Per Turn ────────────────────────────────────
def chart_context_window(data):
    fig, ax = plt.subplots(figsize=(14, 8))

    ax.bar(np.array(data["turns"]) - 0.2, data["rag_context"], width=0.4,
           color=RAG_COLOR, alpha=0.8, label="Traditional RAG", edgecolor="none")
    ax.bar(np.array(data["turns"]) + 0.2, data["om_context"], width=0.4,
           color=OM_COLOR, alpha=0.8, label="om-memory", edgecolor="none")

    ax.set_xlabel("Conversation Turn", fontsize=14, fontweight="bold", labelpad=10)
    ax.set_ylabel("Prompt Tokens (Context Window Size)", fontsize=14, fontweight="bold", labelpad=10)
    ax.yaxis.set_major_formatter(ticker.FuncFormatter(format_k))
    ax.grid(True, linestyle="--", alpha=0.3, axis="y")
    ax.legend(fontsize=14, loc="upper left", framealpha=0.3, edgecolor=GRID_COLOR)

    # Highlight the growing gap
    rag_50 = data["rag_context"][-1]
    om_50 = data["om_context"][-1]

    fig.suptitle("Context Window Size: Every API Call",
                 fontsize=20, fontweight="bold", color=TEXT_COLOR, y=0.97)
    ax.set_title(
        f"Turn 50 → RAG: {format_k(rag_50, None)} tokens  vs  om-memory: {format_k(om_50, None)} tokens  "
        f"({((rag_50 - om_50)/rag_50)*100:.0f}% smaller)",
        fontsize=13, color=ACCENT_PURPLE_LIGHT, pad=15)

    fig.text(0.99, 0.01, "om-memory v0.2.4  •  pypi.org/project/om-memory",
             fontsize=9, color=SUBTEXT_COLOR, ha="right", va="bottom", alpha=0.6)

    plt.tight_layout(rect=[0, 0.02, 1, 0.95])
    path = OUTPUT_DIR / "02_context_window_per_turn.png"
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"  ✅ Saved: {path}")


# ── Chart 3: Cost Comparison Dashboard ───────────────────────────────────────
def chart_cost_dashboard(data):
    rag_cost, rag_input, rag_output = calc_cost(data["rag_total"], data["rag_prompt"])
    om_cost, om_input, om_output = calc_cost(data["om_total"], data["om_prompt"])
    savings = rag_cost - om_cost
    savings_pct = (savings / rag_cost) * 100 if rag_cost > 0 else 0

    fig = plt.figure(figsize=(16, 10))
    fig.patch.set_facecolor(DARK_BG)

    # Title
    fig.suptitle("Cost Analysis: 50-Turn Conversation (GPT-4o-mini)",
                 fontsize=22, fontweight="bold", color=TEXT_COLOR, y=0.97)

    # ── Top row: Big metric cards ─────────────────────────────────────
    gs = fig.add_gridspec(2, 4, hspace=0.45, wspace=0.3,
                          left=0.06, right=0.94, top=0.88, bottom=0.05)

    # Card 1: RAG Cost
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.set_facecolor(CARD_BG)
    ax1.set_xlim(0, 1); ax1.set_ylim(0, 1)
    ax1.text(0.5, 0.62, f"${rag_cost:.4f}", fontsize=28, fontweight="bold",
             color=RAG_COLOR_LIGHT, ha="center", va="center")
    ax1.text(0.5, 0.3, "Traditional RAG", fontsize=12, color=SUBTEXT_COLOR,
             ha="center", va="center")
    ax1.text(0.5, 0.15, f"{format_k(rag_input, None)} input tokens", fontsize=10,
             color=SUBTEXT_COLOR, ha="center", va="center", alpha=0.7)
    for spine in ax1.spines.values():
        spine.set_color(RAG_COLOR)
        spine.set_linewidth(2)
    ax1.set_xticks([]); ax1.set_yticks([])

    # Card 2: om-memory Cost
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.set_facecolor(CARD_BG)
    ax2.set_xlim(0, 1); ax2.set_ylim(0, 1)
    ax2.text(0.5, 0.62, f"${om_cost:.4f}", fontsize=28, fontweight="bold",
             color=OM_COLOR_LIGHT, ha="center", va="center")
    ax2.text(0.5, 0.3, "om-memory", fontsize=12, color=SUBTEXT_COLOR,
             ha="center", va="center")
    ax2.text(0.5, 0.15, f"{format_k(om_input, None)} input tokens", fontsize=10,
             color=SUBTEXT_COLOR, ha="center", va="center", alpha=0.7)
    for spine in ax2.spines.values():
        spine.set_color(OM_COLOR)
        spine.set_linewidth(2)
    ax2.set_xticks([]); ax2.set_yticks([])

    # Card 3: Savings
    ax3 = fig.add_subplot(gs[0, 2])
    ax3.set_facecolor(CARD_BG)
    ax3.set_xlim(0, 1); ax3.set_ylim(0, 1)
    ax3.text(0.5, 0.62, f"{savings_pct:.0f}%", fontsize=36, fontweight="bold",
             color=ACCENT_PURPLE_LIGHT, ha="center", va="center")
    ax3.text(0.5, 0.3, "Token Savings", fontsize=12, color=SUBTEXT_COLOR,
             ha="center", va="center")
    ax3.text(0.5, 0.15, f"${savings:.4f} saved", fontsize=10,
             color=SUBTEXT_COLOR, ha="center", va="center", alpha=0.7)
    for spine in ax3.spines.values():
        spine.set_color(ACCENT_PURPLE)
        spine.set_linewidth(2)
    ax3.set_xticks([]); ax3.set_yticks([])

    # Card 4: Compression ratio
    compression = data["rag_cumulative"][-1] / data["om_cumulative"][-1]
    ax4 = fig.add_subplot(gs[0, 3])
    ax4.set_facecolor(CARD_BG)
    ax4.set_xlim(0, 1); ax4.set_ylim(0, 1)
    ax4.text(0.5, 0.62, f"{compression:.1f}x", fontsize=36, fontweight="bold",
             color=ACCENT_PURPLE_LIGHT, ha="center", va="center")
    ax4.text(0.5, 0.3, "Compression", fontsize=12, color=SUBTEXT_COLOR,
             ha="center", va="center")
    ax4.text(0.5, 0.15, "fewer tokens total", fontsize=10,
             color=SUBTEXT_COLOR, ha="center", va="center", alpha=0.7)
    for spine in ax4.spines.values():
        spine.set_color(ACCENT_PURPLE)
        spine.set_linewidth(2)
    ax4.set_xticks([]); ax4.set_yticks([])

    # ── Bottom row: Scaling projection ────────────────────────────────
    ax_table = fig.add_subplot(gs[1, :])
    ax_table.set_facecolor(CARD_BG)
    ax_table.axis("off")

    ax_table.text(0.5, 0.95, "Monthly Cost Projection (3 conversations/user/day)",
                  fontsize=16, fontweight="bold", color=TEXT_COLOR,
                  ha="center", va="top", transform=ax_table.transAxes)

    users_list = [100, 1_000, 10_000, 100_000]
    col_headers = ["Users", "Conversations/mo", "RAG Cost/mo", "om-memory Cost/mo", "Monthly Savings"]
    table_data = []
    for users in users_list:
        monthly = users * 3 * 30
        rag_mo = rag_cost * monthly
        om_mo = om_cost * monthly
        table_data.append([
            f"{users:,}",
            f"{monthly:,}",
            f"${rag_mo:,.2f}",
            f"${om_mo:,.2f}",
            f"${rag_mo - om_mo:,.2f}"
        ])

    table = ax_table.table(
        cellText=table_data, colLabels=col_headers,
        loc="center", cellLoc="center",
        bbox=[0.02, 0.0, 0.96, 0.82]
    )
    table.auto_set_font_size(False)
    table.set_fontsize(12)

    for (row, col), cell in table.get_celld().items():
        cell.set_edgecolor(GRID_COLOR)
        if row == 0:
            cell.set_facecolor("#2a2a4e")
            cell.set_text_props(fontweight="bold", color=ACCENT_PURPLE_LIGHT)
        else:
            cell.set_facecolor(CARD_BG)
            cell.set_text_props(color=TEXT_COLOR)
            # Highlight savings column in green
            if col == 4:
                cell.set_text_props(color=OM_COLOR_LIGHT, fontweight="bold")
        cell.set_height(0.18)

    fig.text(0.99, 0.01, "om-memory v0.2.4  •  pypi.org/project/om-memory",
             fontsize=9, color=SUBTEXT_COLOR, ha="right", va="bottom", alpha=0.6)

    path = OUTPUT_DIR / "03_cost_dashboard.png"
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"  ✅ Saved: {path}")
    return savings_pct, compression


# ── Chart 4: Per-Turn Token Breakdown (Area Chart) ───────────────────────────
def chart_per_turn_breakdown(data):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 7), sharey=False)
    turns = data["turns"]

    # Left: Traditional RAG breakdown
    system_base = [SYSTEM_PROMPT_TOKENS] * NUM_TURNS
    retrieved = [RETRIEVED_DOCS_TOKENS] * NUM_TURNS
    history = [p - SYSTEM_PROMPT_TOKENS - RETRIEVED_DOCS_TOKENS - AVG_USER_QUERY_TOKENS
               for p in data["rag_prompt"]]
    query = [AVG_USER_QUERY_TOKENS] * NUM_TURNS

    ax1.fill_between(turns, 0, system_base, alpha=0.6, color="#64748b", label="System Prompt")
    ax1.fill_between(turns, system_base,
                     [s + r for s, r in zip(system_base, retrieved)],
                     alpha=0.6, color="#3b82f6", label="Retrieved Docs")
    ax1.fill_between(turns,
                     [s + r for s, r in zip(system_base, retrieved)],
                     [s + r + h for s, r, h in zip(system_base, retrieved, history)],
                     alpha=0.6, color=RAG_COLOR, label="Chat History (growing!)")
    ax1.fill_between(turns,
                     [s + r + h for s, r, h in zip(system_base, retrieved, history)],
                     [s + r + h + q for s, r, h, q in zip(system_base, retrieved, history, query)],
                     alpha=0.6, color="#f59e0b", label="Current Query")

    ax1.set_title("[X]  Traditional RAG", fontsize=16, fontweight="bold", color=RAG_COLOR_LIGHT, pad=12)
    ax1.set_xlabel("Turn", fontsize=12, fontweight="bold")
    ax1.set_ylabel("Prompt Tokens", fontsize=12, fontweight="bold")
    ax1.yaxis.set_major_formatter(ticker.FuncFormatter(format_k))
    ax1.legend(fontsize=10, loc="upper left", framealpha=0.3, edgecolor=GRID_COLOR)
    ax1.grid(True, linestyle="--", alpha=0.2)

    # Right: om-memory breakdown
    om_base = [SYSTEM_PROMPT_TOKENS] * NUM_TURNS
    om_retrieved = [RETRIEVED_DOCS_TOKENS] * NUM_TURNS
    om_obs = []
    obs_t = OM_OBSERVATION_WINDOW_TOKENS
    for t in range(1, NUM_TURNS + 1):
        if t % 5 == 0:
            obs_t += OM_OBSERVATION_GROWTH_PER_5_TURNS
        om_obs.append(obs_t)
    om_recent = [min(OM_RECENT_MSGS_COUNT * (AVG_USER_QUERY_TOKENS + AVG_ASSISTANT_RESPONSE_TOKENS),
                     t * (AVG_USER_QUERY_TOKENS + AVG_ASSISTANT_RESPONSE_TOKENS))
                 for t in range(1, NUM_TURNS + 1)]

    ax2.fill_between(turns, 0, om_base, alpha=0.6, color="#64748b", label="System Prompt")
    ax2.fill_between(turns, om_base,
                     [s + r for s, r in zip(om_base, om_retrieved)],
                     alpha=0.6, color="#3b82f6", label="Retrieved Docs")
    ax2.fill_between(turns,
                     [s + r for s, r in zip(om_base, om_retrieved)],
                     [s + r + o for s, r, o in zip(om_base, om_retrieved, om_obs)],
                     alpha=0.6, color=OM_COLOR, label="Compressed Memory")
    ax2.fill_between(turns,
                     [s + r + o for s, r, o in zip(om_base, om_retrieved, om_obs)],
                     [s + r + o + m for s, r, o, m in zip(om_base, om_retrieved, om_obs, om_recent)],
                     alpha=0.6, color="#a78bfa", label="Recent Messages (3)")
    ax2.fill_between(turns,
                     [s + r + o + m for s, r, o, m in zip(om_base, om_retrieved, om_obs, om_recent)],
                     [s + r + o + m + AVG_USER_QUERY_TOKENS for s, r, o, m in zip(om_base, om_retrieved, om_obs, om_recent)],
                     alpha=0.6, color="#f59e0b", label="Current Query")

    ax2.set_title("[OK]  om-memory", fontsize=16, fontweight="bold", color=OM_COLOR_LIGHT, pad=12)
    ax2.set_xlabel("Turn", fontsize=12, fontweight="bold")
    ax2.set_ylabel("Prompt Tokens", fontsize=12, fontweight="bold")
    ax2.yaxis.set_major_formatter(ticker.FuncFormatter(format_k))
    ax2.legend(fontsize=10, loc="upper left", framealpha=0.3, edgecolor=GRID_COLOR)
    ax2.grid(True, linestyle="--", alpha=0.2)

    fig.suptitle("What's Inside the Prompt? Token Breakdown by Component",
                 fontsize=20, fontweight="bold", color=TEXT_COLOR, y=0.99)

    fig.text(0.99, 0.01, "om-memory v0.2.4  •  pypi.org/project/om-memory",
             fontsize=9, color=SUBTEXT_COLOR, ha="right", va="bottom", alpha=0.6)

    plt.tight_layout(rect=[0, 0.02, 1, 0.95])
    path = OUTPUT_DIR / "04_token_breakdown.png"
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"  ✅ Saved: {path}")


# ── Chart 5: Hero Summary Card ──────────────────────────────────────────────
def chart_hero_summary(data, savings_pct, compression):
    fig = plt.figure(figsize=(14, 10))
    fig.patch.set_facecolor(DARK_BG)

    rag_cost, _, _ = calc_cost(data["rag_total"], data["rag_prompt"])
    om_cost, _, _ = calc_cost(data["om_total"], data["om_prompt"])

    # Full figure is one big infographic
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.set_facecolor(DARK_BG)
    ax.axis("off")

    # Title
    ax.text(5, 9.4, "om-memory", fontsize=42, fontweight="bold",
            ha="center", va="center", color=ACCENT_PURPLE_LIGHT)
    ax.text(5, 8.75, "Human-like Observational Memory for AI Agents",
            fontsize=16, ha="center", va="center", color=SUBTEXT_COLOR)

    # Subtitle
    ax.text(5, 8.15, "50-Turn Conversation Benchmark  •  Traditional RAG vs om-memory",
            fontsize=14, ha="center", va="center", color=TEXT_COLOR, style="italic")

    # ── Big metrics row ───────────────────────────────────────────────
    metrics = [
        (f"{savings_pct:.0f}%", "Token Savings", ACCENT_PURPLE_LIGHT),
        (f"{compression:.1f}x", "Compression", OM_COLOR_LIGHT),
        (f"O(1)", "Context Growth", OM_COLOR_LIGHT),
        (f"${(rag_cost - om_cost)*9_000_000:,.0f}", "Saved at 100K Users/yr", RAG_COLOR_LIGHT),
    ]
    for i, (val, label, color) in enumerate(metrics):
        cx = 1.3 + i * 2.3
        # Card background
        rect = FancyBboxPatch((cx - 0.9, 6.0), 1.8, 1.8,
                              boxstyle="round,pad=0.1",
                              facecolor=CARD_BG, edgecolor=GRID_COLOR, linewidth=1.5)
        ax.add_patch(rect)
        ax.text(cx, 7.15, val, fontsize=28, fontweight="bold",
                ha="center", va="center", color=color)
        ax.text(cx, 6.45, label, fontsize=11, ha="center", va="center",
                color=SUBTEXT_COLOR)

    # ── Comparison table ──────────────────────────────────────────────
    ax.text(5, 5.4, "How They Compare", fontsize=18, fontweight="bold",
            ha="center", va="center", color=TEXT_COLOR)

    rows = [
        ("Context Growth", "O(n²) — full history", "O(1) — compressed"),
        ("Turn 50 Prompt", f"{format_k(data['rag_context'][-1], None)} tokens",
         f"{format_k(data['om_context'][-1], None)} tokens"),
        ("Total Tokens (50 turns)", f"{format_k(data['rag_cumulative'][-1], None)}",
         f"{format_k(data['om_cumulative'][-1], None)}"),
        ("Cost (50 turns)", f"${rag_cost:.4f}", f"${om_cost:.4f}"),
        ("Vector DB Required?", "Yes (every turn)", "No"),
        ("Cross-session Memory", "None", "Resource-scoped"),
        ("Memory Type", "Raw retrieval", "Observational + Reflective"),
    ]

    y_start = 4.9
    # Column headers
    ax.text(3.0, y_start, "Feature", fontsize=12, fontweight="bold",
            ha="center", va="center", color=ACCENT_PURPLE_LIGHT)
    ax.text(6.0, y_start, "Traditional RAG", fontsize=12, fontweight="bold",
            ha="center", va="center", color=RAG_COLOR_LIGHT)
    ax.text(8.5, y_start, "om-memory", fontsize=12, fontweight="bold",
            ha="center", va="center", color=OM_COLOR_LIGHT)

    # Divider line
    ax.plot([1.2, 9.5], [y_start - 0.2, y_start - 0.2], color=GRID_COLOR, linewidth=1)

    for j, (feat, rag_val, om_val) in enumerate(rows):
        y = y_start - 0.5 - j * 0.45
        bg_color = "#1e1e3a" if j % 2 == 0 else CARD_BG
        rect = FancyBboxPatch((1.2, y - 0.18), 8.3, 0.4,
                              boxstyle="round,pad=0.02",
                              facecolor=bg_color, edgecolor="none")
        ax.add_patch(rect)
        ax.text(3.0, y, feat, fontsize=11, ha="center", va="center", color=TEXT_COLOR)
        ax.text(6.0, y, rag_val, fontsize=11, ha="center", va="center", color=RAG_COLOR_LIGHT)
        ax.text(8.5, y, om_val, fontsize=11, ha="center", va="center", color=OM_COLOR_LIGHT)

    # ── Bottom: install command ───────────────────────────────────────
    ax.text(5, 0.85, "pip install om-memory", fontsize=16, fontweight="bold",
            ha="center", va="center", color=OM_COLOR_LIGHT,
            fontfamily="monospace",
            bbox=dict(boxstyle="round,pad=0.5", facecolor=CARD_BG,
                      edgecolor=OM_COLOR, linewidth=2))
    ax.text(5, 0.3, "pypi.org/project/om-memory  •  github.com/pratik333/om-memory",
            fontsize=10, ha="center", va="center", color=SUBTEXT_COLOR, alpha=0.7)

    path = OUTPUT_DIR / "05_hero_summary.png"
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"  ✅ Saved: {path}")


# ── Chart 6: Token Growth Rate (O(n²) vs O(1) visualization) ────────────────
def chart_growth_rate(data):
    fig, ax = plt.subplots(figsize=(14, 8))

    # Show per-turn prompt tokens — this is where O(n²) vs O(1) is most visible
    ax.plot(data["turns"], data["rag_prompt"], color=RAG_COLOR, linewidth=3,
            label="Traditional RAG — O(n²) growth", marker="o", markersize=3)
    ax.plot(data["turns"], data["om_prompt"], color=OM_COLOR, linewidth=3,
            label="om-memory — O(1) flat", marker="s", markersize=3)

    # Shade the gap
    ax.fill_between(data["turns"], data["om_prompt"], data["rag_prompt"],
                    alpha=0.12, color=RAG_COLOR, label="Wasted tokens (gap)")

    ax.set_xlabel("Conversation Turn", fontsize=14, fontweight="bold", labelpad=10)
    ax.set_ylabel("Prompt Tokens Per Turn", fontsize=14, fontweight="bold", labelpad=10)
    ax.yaxis.set_major_formatter(ticker.FuncFormatter(format_k))
    ax.grid(True, linestyle="--", alpha=0.3)
    ax.legend(fontsize=13, loc="upper left", framealpha=0.3, edgecolor=GRID_COLOR)

    # Growth annotations
    rag_1 = data["rag_prompt"][0]
    rag_50 = data["rag_prompt"][-1]
    om_1 = data["om_prompt"][0]
    om_50 = data["om_prompt"][-1]

    ax.annotate(f"Turn 1: {rag_1:,} tokens", xy=(1, rag_1),
                xytext=(8, rag_1 + 500), fontsize=11, color=RAG_COLOR_LIGHT,
                arrowprops=dict(arrowstyle="->", color=RAG_COLOR_LIGHT))
    ax.annotate(f"Turn 50: {rag_50:,} tokens  ({rag_50/rag_1:.0f}x growth!)",
                xy=(48, rag_50), xytext=(20, rag_50 + 1200),
                fontsize=12, fontweight="bold", color=RAG_COLOR_LIGHT,
                arrowprops=dict(arrowstyle="->", color=RAG_COLOR_LIGHT, lw=1.5))
    ax.annotate(f"Always ~{om_50:,} tokens (flat!)",
                xy=(48, om_50), xytext=(20, om_50 + 3000),
                fontsize=12, fontweight="bold", color=OM_COLOR_LIGHT,
                arrowprops=dict(arrowstyle="->", color=OM_COLOR_LIGHT, lw=1.5))

    fig.suptitle("Token Growth Rate: Why RAG Gets Expensive",
                 fontsize=20, fontweight="bold", color=TEXT_COLOR, y=0.97)
    ax.set_title("Traditional RAG re-sends the entire chat history every turn — om-memory doesn't",
                 fontsize=13, color=SUBTEXT_COLOR, pad=15)

    fig.text(0.99, 0.01, "om-memory v0.2.4  •  pypi.org/project/om-memory",
             fontsize=9, color=SUBTEXT_COLOR, ha="right", va="bottom", alpha=0.6)

    plt.tight_layout(rect=[0, 0.02, 1, 0.95])
    path = OUTPUT_DIR / "06_growth_rate.png"
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"  ✅ Saved: {path}")


# ── Main ─────────────────────────────────────────────────────────────────────
def main():
    print("=" * 65)
    print("🧠 om-memory Benchmark: 50-Turn RAG vs Observational Memory")
    print("=" * 65)
    print()

    print("📊 Simulating 50-turn conversation...")
    data = simulate()

    rag_cost, rag_input, rag_output = calc_cost(data["rag_total"], data["rag_prompt"])
    om_cost, om_input, om_output = calc_cost(data["om_total"], data["om_prompt"])

    print(f"\n{'─'*50}")
    print(f"  Traditional RAG:")
    print(f"    Total tokens:     {data['rag_cumulative'][-1]:>10,}")
    print(f"    Turn 50 prompt:   {data['rag_context'][-1]:>10,} tokens")
    print(f"    Cost:             ${rag_cost:.4f}")
    print(f"\n  om-memory:")
    print(f"    Total tokens:     {data['om_cumulative'][-1]:>10,}")
    print(f"    Turn 50 prompt:   {data['om_context'][-1]:>10,} tokens")
    print(f"    Cost:             ${om_cost:.4f}")
    print(f"\n  Savings:")
    savings_pct = ((data['rag_cumulative'][-1] - data['om_cumulative'][-1]) / data['rag_cumulative'][-1]) * 100
    compression = data['rag_cumulative'][-1] / data['om_cumulative'][-1]
    print(f"    Token savings:    {savings_pct:.1f}%")
    print(f"    Compression:      {compression:.1f}x")
    print(f"    Cost saved:       ${rag_cost - om_cost:.4f}")
    print(f"{'─'*50}\n")

    print("🎨 Generating publication-quality charts...\n")

    chart_cumulative_tokens(data)
    chart_context_window(data)
    chart_cost_dashboard(data)
    chart_per_turn_breakdown(data)
    chart_hero_summary(data, savings_pct, compression)
    chart_growth_rate(data)

    print(f"\n✨ All charts saved to: {OUTPUT_DIR.resolve()}")
    print(f"   Total images: 6")
    print()
    print("📋 Recommended LinkedIn post order:")
    print("   1. 05_hero_summary.png     — Lead with the summary card")
    print("   2. 06_growth_rate.png      — Show why RAG gets expensive")
    print("   3. 01_cumulative_tokens.png — Cumulative token comparison")
    print("   4. 04_token_breakdown.png  — What's inside the prompt")
    print("   5. 02_context_window_per_turn.png — Context window bars")
    print("   6. 03_cost_dashboard.png   — Cost + scaling table")


if __name__ == "__main__":
    main()
