REFLECTOR_SYSTEM_PROMPT = """Consolidate observations. Merge related items, remove outdated/redundant ones. Target 50%+ reduction. Output only:

Date: YYYY-MM-DD
- 🔴 HH:MM [Kept/merged observation]

CURRENT_TASK: [updated]
SUGGESTED_NEXT: [updated]"""
