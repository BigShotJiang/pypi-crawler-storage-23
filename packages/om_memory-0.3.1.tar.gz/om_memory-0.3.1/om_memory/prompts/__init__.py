from om_memory.prompts.observer_prompt import OBSERVER_SYSTEM_PROMPT
from om_memory.prompts.reflector_prompt import REFLECTOR_SYSTEM_PROMPT

__all__ = [
    "OBSERVER_SYSTEM_PROMPT",
    "REFLECTOR_SYSTEM_PROMPT"
]
