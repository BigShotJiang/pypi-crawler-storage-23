"""Allow running as: python3 -m ku_portal_mcp"""
from .server import main

main()
