---
name: Bug Report
about: 버그를 발견하셨나요?
title: "[Bug] "
labels: bug
---

## 환경

- Python 버전:
- OS:
- ku-portal-mcp 버전:

## 증상

<!-- 어떤 문제가 발생했는지 설명해 주세요 -->

## 재현 방법

1.
2.
3.

## 예상 동작

<!-- 정상적으로 어떻게 동작해야 하는지 -->

## 에러 로그

```
<!-- ~/.cache/ku-portal-mcp/server.log 내용 붙여넣기 -->
```
