import setuptools

setuptools.setup(
            name='python-markdown-secrets',
            install_requires=['markdown>=3'],
            tests_require=['mkdocs'],
            py_modules=['mkdsecrets']
            )
