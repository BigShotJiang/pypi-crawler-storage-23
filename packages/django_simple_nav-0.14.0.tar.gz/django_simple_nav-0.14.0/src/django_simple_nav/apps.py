from __future__ import annotations

from django.apps import AppConfig


class DjangoSimpleNavConfig(AppConfig):
    name = "django_simple_nav"
