"""Exception classes for Coda API errors."""

import requests


class CodaAPIError(Exception):
    """Base exception for Coda API errors.

    Attributes:
        status_code: HTTP status code
        response: The full requests.Response object
        endpoint: The API endpoint that was called
    """

    def __init__(self, message: str, status_code: int, response: requests.Response, endpoint: str):
        self.status_code = status_code
        self.response = response
        self.endpoint = endpoint
        super().__init__(message)


class CodaAuthenticationError(CodaAPIError):
    """401 Unauthorized - Invalid or expired API token."""
    pass


class CodaForbiddenError(CodaAPIError):
    """403 Forbidden - Insufficient permissions for this resource."""
    pass


class CodaBadRequestError(CodaAPIError):
    """400 Bad Request - Invalid request payload or parameters."""
    pass


class CodaNotFoundError(CodaAPIError):
    """404 Not Found - Resource does not exist."""
    pass


class CodaClientError(CodaAPIError):
    """4XX Client Error (other than 400, 401, 403, 404)."""
    pass


class CodaServerError(CodaAPIError):
    """5XX Server Error - Coda API server error."""
    pass
