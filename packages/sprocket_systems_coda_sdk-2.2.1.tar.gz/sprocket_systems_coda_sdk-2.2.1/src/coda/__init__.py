# The versions below will be replaced automatically in CI.
# You do not need to modify any of the versions below.
__version__ = "2.2.1"
CODA_APP_SUITE_CONTAINER_VERSION= "+coda-0.0.0"
FINAL_VERSION = __version__ + CODA_APP_SUITE_CONTAINER_VERSION
