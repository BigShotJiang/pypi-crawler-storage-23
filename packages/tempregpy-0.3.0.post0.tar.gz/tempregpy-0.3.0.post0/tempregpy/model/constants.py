CF_PER_AF = 43560.02
CFS_TO_AFH = 3600 / CF_PER_AF  # Convert cubic feet per second to acre-feet per hour
# CFS_TO_AF = 1 / 12.1