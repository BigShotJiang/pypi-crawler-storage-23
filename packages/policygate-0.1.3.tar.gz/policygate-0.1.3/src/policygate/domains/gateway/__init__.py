"""Gateway domain package."""
