"""Repository infrastructure adapters."""
