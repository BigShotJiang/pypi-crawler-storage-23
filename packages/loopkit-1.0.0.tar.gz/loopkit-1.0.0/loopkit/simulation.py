# BSD 3-Clause License

# Copyright (c) 2025, Miguel Dovale

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:

# 1. Redistributions of source code must retain the above copyright notice, this
#    list of conditions and the following disclaimer.

# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.

# 3. Neither the name of the copyright holder nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

# This software may be subject to U.S. export control laws. By accepting this
# software, the user agrees to comply with all applicable U.S. export laws and
# regulations. User has the responsibility to obtain export licenses, or other
# export authority as may be required before exporting such information to
# foreign countries or providing access to foreign persons.
#
from __future__ import annotations

import copy
import logging
import warnings
from contextlib import contextmanager
from typing import Any, Dict, Iterator, Literal, Optional, Sequence, Tuple, Union

import numpy as np
from numpy.typing import ArrayLike, NDArray
from joblib import Parallel, delayed
from joblib.parallel import BatchCompletionCallBack
from scipy.optimize import minimize, OptimizeResult
from tqdm.auto import tqdm

import loopkit.loopmath as lm
from loopkit.component import Component
import loopkit.components as lc
from loopkit.loop import LOOP

logger = logging.getLogger(__name__)

# --- Parallel Progress Bar Utility ---


@contextmanager
def tqdm_joblib(tqdm_object: tqdm) -> Iterator[tqdm]:
    """
    Context manager to patch joblib to report progress into a tqdm bar.
    Note: Newer versions of joblib may have built-in support for tqdm,
    but this remains a reliable method.
    """
    class TqdmBatchCompletionCallback(BatchCompletionCallBack):
        def __call__(self, *args: Any, **kwargs: Any) -> Any:
            tqdm_object.update(n=self.batch_size)
            return super().__call__(*args, **kwargs)

    old_callback = Parallel.__init__.__globals__["BatchCompletionCallBack"]
    Parallel.__init__.__globals__["BatchCompletionCallBack"] = TqdmBatchCompletionCallback
    try:
        yield tqdm_object
    finally:
        Parallel.__init__.__globals__["BatchCompletionCallBack"] = old_callback
        tqdm_object.close()


# --- Core Sweep Logic ---

def _calculate_point(
    loop_prototype: LOOP,
    params_to_set: Dict[str, Any],
    frequencies: np.ndarray,
    deg: bool,
    unwrap_phase: bool,
    interpolate: bool,
) -> Tuple[float, float, NDArray[np.floating[Any]], NDArray[np.floating[Any]]]:
    """
    Worker function for parallel sweep. Calculates metrics for one parameter point.

    This function creates a local, independent copy of the loop object to
    ensure thread/process safety.
    """
    loop = copy.deepcopy(loop_prototype)

    for name, val in params_to_set.items():
        setattr(loop, name, val)

    tf = loop.Gf(frequencies)
    mag = np.abs(tf)
    phase_rad = np.angle(tf, deg=False)
    if unwrap_phase:
        phase_rad = np.unwrap(phase_rad)

    phase = np.rad2deg(phase_rad) if deg else phase_rad

    ugf, pm = lm.get_margin(
        tf, frequencies, deg=deg, unwrap_phase=unwrap_phase, interpolate=interpolate
    )

    return ugf, pm, mag, phase

# --- Modern Parameter Sweep Functions ---

def parameter_sweep_nd(
    loop: LOOP,
    param_grid: Dict[str, Sequence],
    frequencies: Sequence,
    deg: bool = True,
    unwrap_phase: bool = False,
    interpolate: bool = False,
    n_jobs: int = -1,
) -> Dict[str, Any]:
    """
    Performs an N-dimensional parameter sweep in parallel.

    This function can be used to analyze loop stability and performance over a
    grid of parameters, using joblib for parallel computation (cloudpickle
    serialization supports loop objects with lambdas).

    Parameters
    ----------
    loop : LOOP
        The loop object to use as a template. It is NOT modified in-place.
    param_grid : dict
        Maps property names (str) to arrays of values to sweep.
    frequencies : array_like
        Frequencies (Hz) for evaluating the loop's transfer function.
    deg : bool, optional
        If True, compute phase and margin in degrees. Defaults to True.
    unwrap_phase : bool, optional
        If True, unwrap phase before computing margin. Defaults to False.
    interpolate : bool, optional
        If True, interpolate TF to refine margin calculations. Defaults to False.
    n_jobs : int, optional
        Number of parallel jobs. -1 uses all cores. 1 disables parallelism.
        Defaults to -1.

    Returns
    -------
    dict
        A dictionary containing the sweep results, including parameter grids,
        frequencies, and calculated metrics (UGF, phase margin, magnitude, phase).
    
    Raises
    ------
    ValueError
        If a parameter name in `param_grid` is not a valid property of the loop.
    """
    # Input validation
    if not param_grid:
        raise ValueError("param_grid must not be empty.")
    for name in param_grid.keys():
        if not hasattr(loop, name):
            raise ValueError(f"Property '{name}' not found on the provided loop object.")
    freqs_arr = np.asarray(frequencies, dtype=np.float64)
    if freqs_arr.size == 0:
        raise ValueError("frequencies must not be empty.")
    if np.any(freqs_arr <= 0):
        raise ValueError("frequencies must be positive.")
    if n_jobs == 0:
        raise ValueError("n_jobs must not be zero.")

    param_names = list(param_grid.keys())
    sweep_axes = [np.asarray(param_grid[k]) for k in param_names]
    mesh = np.meshgrid(*sweep_axes, indexing="ij")
    shape = mesh[0].shape
    num_freqs = len(freqs_arr)
    total_points = np.prod(shape)

    # Create a flat list of tasks (dictionaries of parameter settings)
    param_values_flat = [m.flatten() for m in mesh]
    tasks = [dict(zip(param_names, p_set)) for p_set in zip(*param_values_flat)]
    
    cores_str = "all available" if n_jobs == -1 else n_jobs
    logger.info(
        f"Starting parallel sweep over {total_points} points using {cores_str} cores."
    )

    # Run tasks in parallel with a progress bar.
    # joblib uses loky/cloudpickle by default, which can serialize loop objects
    # containing lambdas (unlike stdlib pickle used by ProcessPoolExecutor).
    with tqdm_joblib(tqdm(total=total_points, desc="Sweeping Parameters")):
        results = Parallel(n_jobs=n_jobs, verbose=0)(
            delayed(_calculate_point)(
                loop, params, freqs_arr, deg, unwrap_phase, interpolate
            )
            for params in tasks
        )

    # --- Collect and reshape results ---
    ugf_flat, pm_flat, mag_flat, phase_flat = zip(*results)

    # Reshape scalar metrics to the N-D grid shape
    ugf_arr = np.array(ugf_flat).reshape(shape)
    pm_arr = np.array(pm_flat).reshape(shape)
    
    # Reshape vector metrics (per frequency) to N-D grid shape + frequency dim
    mag_arr = np.array(mag_flat).reshape(shape + (num_freqs,))
    phase_arr = np.array(phase_flat).reshape(shape + (num_freqs,))

    return {
        "parameter_names": tuple(param_names),
        "parameter_grid": {name: np.copy(mesh[i]) for i, name in enumerate(param_names)},
        "frequencies": np.copy(freqs_arr),
        "metrics": {
            "ugf": np.copy(ugf_arr),
            "phase_margin": np.copy(pm_arr),
        },
        "open_loop": {
            "magnitude": np.copy(mag_arr),
            "phase": np.copy(phase_arr),
        },
    }


def parameter_sweep_1d(
    loop: LOOP,
    prop_name: str,
    values: Sequence,
    frequencies: Sequence,
    deg: bool = True,
    unwrap_phase: bool = False,
    interpolate: bool = False
) -> Dict[str, Any]:
    """
    Sweeps a single parameter and computes stability metrics.

    This is a convenience wrapper around `parameter_sweep_nd` for 1D sweeps.

    Parameters
    ----------
    loop : LOOP
        The loop object to analyze. It is NOT modified in-place.
    prop_name : str
        Name of the property to sweep.
    values : array_like
        Values to assign to the property.
    frequencies : array_like
        Frequencies (Hz) for evaluation.
    deg : bool, optional
        If True, use degrees for phase. Defaults to True.
    unwrap_phase : bool, optional
        If True, unwrap phase. Defaults to False.
    interpolate : bool, optional
        If True, interpolate for margin calculation. Defaults to False.

    Returns
    -------
    dict
        A dictionary with sweep results in a 1D-friendly format.
    """
    if not prop_name or not isinstance(prop_name, str):
        raise ValueError("prop_name must be a non-empty string.")
    if not hasattr(loop, prop_name):
        raise ValueError(f"Property '{prop_name}' not found on the provided loop object.")
    values_arr = np.asarray(values)
    if values_arr.size == 0:
        raise ValueError("values must not be empty.")

    param_grid = {prop_name: values}

    # Run the N-D sweep with n_jobs=1 (sequential) for a single-threaded 1D sweep
    results_nd = parameter_sweep_nd(
        loop, param_grid, frequencies, deg, unwrap_phase, interpolate, n_jobs=1
    )

    # Unpack and format results for the 1D case
    return {
        "parameter_name": prop_name,
        "parameter_values": np.copy(values_arr),
        "frequencies": results_nd["frequencies"],
        "metrics": {
            "ugf": results_nd["metrics"]["ugf"],
            "phase_margin": results_nd["metrics"]["phase_margin"],
        },
        "open_loop": {
            "magnitude": results_nd["open_loop"]["magnitude"],
            "phase": results_nd["open_loop"]["phase"],
        },
    }

# --- Deprecated and Legacy Functions ---

def old_parameter_sweep_1d(
    loop: LOOP,
    frfr: Sequence,
    noise: Sequence,
    comp: str,
    sweep: str,
    space: Sequence,
    tf_from: str,
    tf_to: str,
    isTF: bool = True
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    [DEPRECATED] Sweep a component parameter and evaluate loop error and performance.

    This function is preserved for legacy use cases but `parameter_sweep_1d` or
    `parameter_sweep_nd` are recommended for new development.

    This sweep is inefficient and uses an outdated, error-prone API.
    """
    warnings.warn(
        "`old_parameter_sweep_1d` is deprecated. Use `parameter_sweep_1d` or "
        "`parameter_sweep_nd` for better performance and a cleaner API.",
        DeprecationWarning,
        stacklevel=2,
    )
    
    _loop = copy.deepcopy(loop)
    
    if comp not in _loop.components_dict:
        raise ValueError(f"Component '{comp}' not found in the loop.")
    component = _loop.components_dict[comp]
    if sweep not in component.properties:
        raise ValueError(f"Property '{sweep}' not found in component '{comp}'.")
    if tf_from not in _loop.components_dict:
        raise ValueError(f"Component '{tf_from}' not found in the loop.")
    if tf_to not in _loop.components_dict:
        raise ValueError(f"Component '{tf_to}' not found in the loop.")

    fsweep = component.properties[sweep][1]
    
    # Pre-allocate arrays for efficiency
    N = len(space)
    F = len(frfr)
    ugf = np.empty(N)
    margin = np.empty(N)
    rms = np.empty(N)
    asd = np.empty((F, N))  # Shape (freqs, params) for direct column assignment
    
    freq_arr = np.asarray(frfr)

    for i, p in enumerate(tqdm(space, desc=f"Sweeping {comp}.{sweep}")):
        fsweep(p)
        if isTF:
            tf = _loop.Gf(f=freq_arr)
            ugf_tmp, margin_tmp = lm.get_margin(tf, freq_arr, deg=True)
        else:
            _, ugf_tmp, margin_tmp = _loop.Gc.bode(2 * np.pi * freq_arr)
        
        asd_tmp, _, _, rms_tmp = _loop.noise_propagation_asd(
            freq_arr, noise, _from=tf_from, _to=tf_to, isTF=isTF, view=False
        )
        
        ugf[i] = ugf_tmp
        margin[i] = margin_tmp
        rms[i] = rms_tmp
        asd[:, i] = asd_tmp

    return ugf, margin, rms, asd


def loop_crossover_optimizer(
    loop1: LOOP,
    loop2: LOOP,
    frfr: Sequence,
    desired_f_cross: float,
    meta: Dict[str, Tuple[float, float, float, bool]],
    method: str = "Nelder-Mead",
    options: Optional[Dict[str, Any]] = None,
) -> Tuple[OptimizeResult, LOOP]:
    """
    Optimizes `loop1` parameters to match the crossover frequency of `loop2`.

    Parameters
    ----------
    loop1 : LOOP
        The loop to optimize. A deep copy is used, so the original is not modified.
    loop2 : LOOP
        The reference loop for crossover comparison.
    frfr : array_like
        Frequency grid (Hz) for evaluation.
    desired_f_cross : float
        Target crossover frequency (Hz).
    meta : dict
        Parameter specification: {name: (min, max, initial_guess, is_int), ...}
    method : str, optional
        Solver for `scipy.optimize.minimize`. Defaults to "Nelder-Mead".
    options : dict, optional
        Solver options. Defaults to {"maxiter": 1000}.

    Returns
    -------
    Tuple[scipy.optimize.OptimizeResult, LOOP]
        A tuple containing the optimization result object and the optimized loop copy.
    """
    # Input validation
    if desired_f_cross <= 0:
        raise ValueError("desired_f_cross must be positive.")
    if not meta:
        raise ValueError("meta must not be empty.")
    for name, spec in meta.items():
        if len(spec) != 4:
            raise ValueError(
                f"meta['{name}'] must be (min, max, initial, is_int), got length {len(spec)}."
            )
        if not hasattr(loop1, name):
            raise ValueError(f"Parameter '{name}' not found on loop1.")

    opts = options if options is not None else {"maxiter": 1000}
    _loop_1 = copy.deepcopy(loop1)
    freq_arr = np.asarray(frfr, dtype=np.float64)

    def cost_function(
        x: np.ndarray,
        desired: float,
        meta_spec: Dict[str, Tuple[float, float, float, bool]],
        loop_to_opt: LOOP,
        ref_loop: LOOP,
    ) -> float:
        for i, (attr, spec) in enumerate(meta_spec.items()):
            is_integer = spec[3]
            value = int(x[i]) if is_integer else x[i]
            setattr(loop_to_opt, attr, value)

        f_cross = lm.loop_crossover(loop_to_opt, ref_loop, freq_arr)
        return (f_cross - desired)**2

    x0 = [m[2] for m in meta.values()]
    bounds = [(m[0], m[1]) for m in meta.values()]

    logger.info("# ===== Optimization start ==========")
    logger.info(f"    x0 = {x0}")
    logger.info(f"    bounds = {bounds}")

    popt = minimize(
        fun=cost_function, 
        x0=x0, 
        bounds=bounds, 
        args=(desired_f_cross, meta, _loop_1, loop2), 
        method=method,
        options=opts,
    )
    
    # Apply final optimized parameters to the loop copy
    for i, (attr, spec) in enumerate(meta.items()):
        is_integer = spec[3]
        value = int(popt.x[i]) if is_integer else popt.x[i]
        setattr(_loop_1, attr, value)

    final_f_cross = lm.loop_crossover(_loop_1, loop2, freq_arr)

    # Log results for user feedback
    logger.info("# ===== Optimization result ==========")
    for i, attr in enumerate(meta):
        is_integer = meta[attr][3]
        value = int(popt.x[i]) if is_integer else popt.x[i]
        logger.info(f"    Optimized {attr} = {value}")
    logger.info(f"    Achieved f_cross (Hz) = {final_f_cross:.4g}")
    logger.info(f"    Success = {popt.success}")
    logger.info(f"    Message = {popt.message}")

    return popt, _loop_1


def fit_delay(
    obj: Union[Component, LOOP],
    measurement_frfr: ArrayLike,
    measurement_phase: ArrayLike,
    units: Literal["rad", "deg"] = "rad",
) -> float:
    """
    Estimate the number of DSP delay samples that best aligns a model phase response
    with measured phase data, by minimizing mean squared phase error.

    This is useful when modeling systems that include a known (but uncertain) digital
    delay, such as a Moku:Pro filter pipeline. The delay is modeled as a z-domain 
    delay component and applied multiplicatively to the system's frequency response.

    Parameters
    ----------
    obj : Component or LOOP
        The system model object whose transfer function will be used. Must define
        a callable `.TF(freqs)` (for Component) or `.Gf(freqs)` (for LOOP).

    measurement_frfr : array_like
        Frequency points (in Hz) at which the phase data is measured.

    measurement_phase : array_like
        Phase response of the measured system, either in radians or degrees.
        Must match `measurement_frfr` in shape.

    units : {'rad', 'deg'}, optional
        Units of the `measurement_phase`. If 'deg', it will be unwrapped with a 360° period
        and converted to radians before comparison. Default is 'rad'.

    Returns
    -------
    best_delay_samples : int
        The estimated number of delay samples (can be fractional internally,
        but result is rounded to nearest integer) that minimizes the phase error
        between model and measurement.

    Notes
    -----
    The function uses `loopkit.components.DSPDelayComponent` to model the digital delay
    and `scipy.optimize.minimize_scalar` to find the best delay value that aligns
    the phase of the model with the measured phase data. The model phase is computed
    using `np.angle(...)` and unwrapped before comparison.

    Phase alignment is performed in radians internally for consistency.

    Examples
    --------
    >>> delay = fit_delay(loop_model, freqs, measured_phase, units='deg')
    >>> print(f"Best-fit delay: {delay} samples")
    """
    from scipy.optimize import minimize_scalar

    # Input validation
    if units not in ("rad", "deg"):
        raise ValueError(
            f"units must be 'rad' or 'deg', got {units!r}."
        )
    frfr = np.atleast_1d(np.asarray(measurement_frfr, dtype=np.float64))
    phase_arr = np.atleast_1d(np.asarray(measurement_phase, dtype=np.float64))
    if frfr.size != phase_arr.size:
        raise ValueError(
            f"measurement_frfr and measurement_phase must have same length, "
            f"got {frfr.size} and {phase_arr.size}."
        )
    if frfr.size == 0:
        raise ValueError("measurement_frfr and measurement_phase must not be empty.")

    if isinstance(obj, Component):
        tf_func = obj.TF
    elif isinstance(obj, LOOP):
        tf_func = obj.Gf
    else:
        raise NotImplementedError(f"fit_delay: {obj!r} object not recognized.")

    def phase_error(delay_samples: float) -> float:
        c_delay = lc.DSPDelayComponent("_", sps=obj.sps, n_reg=delay_samples)
        tf_delay = c_delay.TF

        tf_model = tf_func(frfr) * tf_delay(frfr)
        x = np.unwrap(np.angle(tf_model))

        if units == "rad":
            u = np.unwrap(phase_arr)
        elif units == "deg":
            u = np.unwrap(phase_arr, period=360)
            u = np.pi * u / 180.0
        else:
            raise ValueError(
                f"units must be 'rad' or 'deg', got {units!r}."
            )

        return float(np.mean((u - x) ** 2))

    result = minimize_scalar(phase_error, bounds=(0, 1000), method="bounded")

    return float(result.x)
