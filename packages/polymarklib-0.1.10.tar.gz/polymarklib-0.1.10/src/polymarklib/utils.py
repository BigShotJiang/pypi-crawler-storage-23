import datetime as dt

def date_to_ms(date: str):
    """
    Converts a "2026-02-21T08:35:00Z" date to ms
    :param date: string in the form "2026-02-21T08:35:00Z"
    :return: ms since 1970 jan 1
    """
    date_formatted = date.replace("Z", "+00:00")
    date_datetime = dt.datetime.fromisoformat(date_formatted)
    date_ms = int(dt.datetime.timestamp(date_datetime)) * 1000

    return date_ms