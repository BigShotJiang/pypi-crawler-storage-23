from .image import ProcessResult

__all__ = ('ProcessResult',)
