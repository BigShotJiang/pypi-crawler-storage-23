"""
Web automation module for downloading invoices and documents.
"""

# from .web_marionette import download_techem_invoice, download_kfw_invoices
# from .models import DownloadResult

# __all__ = ['download_techem_invoice', 'download_kfw_invoices', 'DownloadResult']
