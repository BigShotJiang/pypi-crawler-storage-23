"""Simulated span generation with realistic attributes."""

from datetime import datetime, timedelta
import random
import math

from lumenova_beacon.tracing.span import Span
from lumenova_beacon.types import SpanType, SpanKind, StatusCode
from lumenova_beacon.utils import generate_span_id, generate_trace_id

from generators.timestamps import HistoricalTimestampGenerator
from config.models import (
    MODELS,
    ModelProfile,
    SAMPLE_PROMPTS,
    TOOL_NAMES,
    ERROR_MESSAGES,
)


class SimulatedSpanBuilder:
    """Builds simulated spans with historical timestamps and realistic attributes."""

    # Mapping from span type string to SpanType enum
    TYPE_MAP = {
        "span": SpanType.SPAN,
        "generation": SpanType.GENERATION,
        "chain": SpanType.CHAIN,
        "tool": SpanType.TOOL,
        "retrieval": SpanType.RETRIEVAL,
        "agent": SpanType.AGENT,
        "function": SpanType.FUNCTION,
        "request": SpanType.REQUEST,
        "server": SpanType.SERVER,
        "task": SpanType.TASK,
        "cache": SpanType.CACHE,
        "embedding": SpanType.EMBEDDING,
    }

    # Mapping from span type to appropriate span kind
    KIND_MAP = {
        SpanType.GENERATION: SpanKind.CLIENT,
        SpanType.SERVER: SpanKind.SERVER,
        SpanType.REQUEST: SpanKind.CLIENT,
        SpanType.RETRIEVAL: SpanKind.CLIENT,
        SpanType.EMBEDDING: SpanKind.CLIENT,
        SpanType.CHAIN: SpanKind.INTERNAL,
        SpanType.AGENT: SpanKind.INTERNAL,
        SpanType.TOOL: SpanKind.INTERNAL,
        SpanType.FUNCTION: SpanKind.INTERNAL,
        SpanType.TASK: SpanKind.INTERNAL,
        SpanType.CACHE: SpanKind.INTERNAL,
        SpanType.SPAN: SpanKind.INTERNAL,
    }

    # Base durations for span types (in milliseconds)
    BASE_DURATIONS = {
        SpanType.GENERATION: 800,
        SpanType.EMBEDDING: 100,
        SpanType.RETRIEVAL: 150,
        SpanType.CACHE: 5,
        SpanType.TOOL: 200,
        SpanType.FUNCTION: 50,
        SpanType.REQUEST: 300,
        SpanType.SERVER: 1000,
        SpanType.CHAIN: 1500,
        SpanType.AGENT: 3000,
        SpanType.TASK: 2000,
        SpanType.SPAN: 100,
    }

    def __init__(
        self,
        models: dict[str, ModelProfile] | None = None,
        agent_names: list[str] | None = None,
        environments: list[str] | None = None,
    ):
        """Initialize the span builder.

        Args:
            models: Model profiles dictionary
            agent_names: List of agent names to use
            environments: List of environments to use
        """
        self.models = models or MODELS
        self.agent_names = agent_names or []
        self.environments = environments or []

    def build_span(
        self,
        span_type_str: str,
        span_name: str,
        start_time: datetime,
        parent_span: Span | None = None,
        trace_id: str | None = None,
        model_id: str | None = None,
        environment: str | None = None,
        agent_name: str | None = None,
        error: bool = False,
        session_id: str | None = None,
    ) -> tuple[Span, datetime]:
        """Build a complete simulated span.

        Args:
            span_type_str: Type of span as string
            span_name: Name for the span
            start_time: When the span starts
            parent_span: Optional parent span
            trace_id: Trace ID (generated if not provided)
            model_id: Model ID for generation spans
            environment: Deployment environment
            agent_name: Agent name
            error: Whether this span should have an error
            session_id: Session ID for the trace

        Returns:
            Tuple of (span, end_time) where end_time can be used for child timing.
        """
        # Convert type string to enum
        span_type = self.TYPE_MAP.get(span_type_str, SpanType.SPAN)

        # Generate IDs
        if trace_id is None:
            trace_id = generate_trace_id()
        span_id = generate_span_id()
        parent_id = parent_span.span_id if parent_span else None

        # Determine span kind based on type
        kind = self.KIND_MAP.get(span_type, SpanKind.INTERNAL)

        # Create span
        span = Span(
            name=span_name,
            trace_id=trace_id,
            span_id=span_id,
            parent_id=parent_id,
            kind=kind,
            span_type=span_type,
            session_id=session_id,
        )

        # Calculate duration and set timestamps
        duration_ms = self._calculate_duration(span_type, model_id)
        end_time = start_time + timedelta(milliseconds=duration_ms)

        span.start_time = HistoricalTimestampGenerator.to_iso8601(start_time)
        span.end_time = HistoricalTimestampGenerator.to_iso8601(end_time)

        # Set attributes based on span type
        self._set_span_attributes(
            span, span_type, model_id, environment, agent_name, span_name
        )

        # Handle errors
        if error:
            self._set_error_status(span, span_type)
        else:
            span.status_code = StatusCode.OK

        return span, end_time

    def _calculate_duration(
        self, span_type: SpanType, model_id: str | None
    ) -> float:
        """Calculate realistic duration in milliseconds.

        Args:
            span_type: Type of span
            model_id: Model ID for generation spans

        Returns:
            Duration in milliseconds.
        """
        base = self.BASE_DURATIONS.get(span_type, 100)

        # Apply model-specific latency for generation spans
        if span_type == SpanType.GENERATION and model_id and model_id in self.models:
            model = self.models[model_id]
            base = model.avg_latency_ms
            std = model.latency_std_ms
            base = max(50, self._normal_bounded(base, std, 50, base * 3))

        # Add random variation (10-30%)
        variation = random.uniform(0.9, 1.3)
        return base * variation

    def _normal_bounded(
        self, mean: float, std: float, min_val: float, max_val: float
    ) -> float:
        """Generate a normally distributed value bounded to a range."""
        u1 = random.random()
        u2 = random.random()
        z = math.sqrt(-2 * math.log(u1)) * math.cos(2 * math.pi * u2)
        value = mean + z * std
        return max(min_val, min(max_val, value))

    def _set_span_attributes(
        self,
        span: Span,
        span_type: SpanType,
        model_id: str | None,
        environment: str | None,
        agent_name: str | None,
        span_name: str,
    ) -> None:
        """Set appropriate attributes based on span type.

        Args:
            span: The span to set attributes on
            span_type: Type of span
            model_id: Model ID for generation spans
            environment: Deployment environment
            agent_name: Agent name
            span_name: Name of the span
        """
        # Environment
        if environment:
            span.set_attribute("deployment.environment.name", environment)

        # Agent name for agent spans
        if agent_name and span_type == SpanType.AGENT:
            span.set_attribute("gen_ai.agent.name", agent_name)
            span.set_attribute("gen_ai.agent.id", f"agent-{random.randint(1000, 9999)}")

        # Model-specific attributes for generation spans
        if span_type == SpanType.GENERATION and model_id:
            model = self.models.get(model_id)
            if model:
                span.set_attribute("gen_ai.provider.name", model.provider)
                span.set_attribute("gen_ai.request.model", model.model_id)

                # Simulated token usage
                input_tokens = random.randint(50, 500)
                output_tokens = random.randint(20, 300)
                span.set_attribute("gen_ai.usage.input_tokens", input_tokens)
                span.set_attribute("gen_ai.usage.output_tokens", output_tokens)

                # Simulated prompt and completion
                prompt = random.choice(SAMPLE_PROMPTS)
                span.set_input({"messages": [{"role": "user", "content": prompt}]})
                span.set_output(
                    {"content": f"Simulated response for: {prompt[:50]}..."}
                )

                # Temperature and other params
                span.set_attribute("gen_ai.request.temperature", random.choice([0, 0.3, 0.5, 0.7, 1.0]))
                span.set_attribute("gen_ai.request.max_tokens", random.choice([256, 512, 1024, 2048]))

        # Type-specific attributes
        if span_type == SpanType.RETRIEVAL:
            doc_count = random.randint(1, 10)
            span.set_attribute("retriever.document_count", doc_count)
            span.set_attribute("retriever.query", random.choice(SAMPLE_PROMPTS))
            span.set_input({"query": random.choice(SAMPLE_PROMPTS)})
            span.set_output({"documents": [f"Document {i+1}" for i in range(doc_count)]})

        elif span_type == SpanType.CACHE:
            cache_hit = random.random() > 0.3  # 70% hit rate
            span.set_attribute("cache.hit", cache_hit)
            span.set_attribute("cache.key", f"cache_key_{random.randint(1, 1000)}")
            span.set_output({"hit": cache_hit})

        elif span_type == SpanType.EMBEDDING:
            span.set_attribute("embedding.dimension", 1536)
            span.set_attribute("embedding.model", "text-embedding-3-small")
            span.set_input({"text": random.choice(SAMPLE_PROMPTS)[:100]})
            span.set_output({"dimensions": 1536, "tokens": random.randint(10, 100)})

        elif span_type == SpanType.TOOL:
            tool_name = random.choice(TOOL_NAMES)
            span.set_attribute("tool.name", tool_name)
            span.set_input({"tool": tool_name, "args": {"query": "sample input"}})
            span.set_output({"result": f"Result from {tool_name}"})

        elif span_type == SpanType.FUNCTION:
            span.set_attribute("code.function", span_name)
            span.set_attribute("code.namespace", "seeding.generators")
            span.set_input({"args": [], "kwargs": {}})
            span.set_output({"result": "success"})

        elif span_type == SpanType.REQUEST:
            span.set_attribute("http.method", random.choice(["GET", "POST"]))
            span.set_attribute("http.status_code", 200)
            span.set_attribute("http.url", f"https://api.example.com/v1/{span_name}")

        elif span_type == SpanType.SERVER:
            span.set_attribute("http.method", random.choice(["GET", "POST", "PUT"]))
            span.set_attribute("http.route", f"/api/v1/{span_name}")
            span.set_attribute("http.status_code", 200)

        elif span_type == SpanType.TASK:
            span.set_attribute("task.id", f"task-{random.randint(10000, 99999)}")
            span.set_attribute("task.type", random.choice(["batch", "scheduled", "manual"]))
            span.set_input({"task_type": "background_processing"})

        elif span_type == SpanType.CHAIN:
            span.set_attribute("langchain.component_type", "chain")
            span.set_input({"input": random.choice(SAMPLE_PROMPTS)})

        elif span_type == SpanType.AGENT:
            span.set_attribute("langchain.component_type", "agent")

    def _set_error_status(self, span: Span, span_type: SpanType) -> None:
        """Set error status and attributes on a span.

        Args:
            span: The span to set error on
            span_type: Type of span (affects error message)
        """
        error_message = random.choice(ERROR_MESSAGES)
        span.status_code = StatusCode.ERROR
        span.status_description = error_message
        span.set_attribute("exception.type", "RuntimeError")
        span.set_attribute("exception.message", error_message)

        # Update output to reflect error
        span.set_output({"error": error_message})
