"""Tests for agent handoff trace separation."""

import pytest
from unittest.mock import MagicMock, patch

from lumenova_beacon import BeaconClient
from lumenova_beacon.tracing.span import Span, SpanLink
from lumenova_beacon.types import SpanType, StatusCode


@pytest.fixture
def client():
    """Create a BeaconClient with OTEL disabled for unit tests."""
    return BeaconClient(
        endpoint="https://api.test.com",
        api_key="test-key",
        auto_instrument_opentelemetry=False,
    )


class TestSpanLink:
    """Tests for the SpanLink dataclass."""

    def test_span_link_creation(self):
        link = SpanLink(trace_id="aabb", span_id="ccdd")
        assert link.trace_id == "aabb"
        assert link.span_id == "ccdd"
        assert link.attributes == {}

    def test_span_link_with_attributes(self):
        link = SpanLink(
            trace_id="aabb",
            span_id="ccdd",
            attributes={"link.type": "child_trace"},
        )
        assert link.attributes == {"link.type": "child_trace"}


class TestSpanAddLink:
    """Tests for Span.add_link()."""

    def test_add_link(self):
        span = Span(name="test")
        span.add_link("trace-aaa", "span-bbb")
        assert len(span.links) == 1
        assert span.links[0].trace_id == "trace-aaa"
        assert span.links[0].span_id == "span-bbb"
        assert span.links[0].attributes == {}

    def test_add_link_with_attributes(self):
        span = Span(name="test")
        span.add_link("trace-aaa", "span-bbb", {"link.type": "child_trace"})
        assert span.links[0].attributes == {"link.type": "child_trace"}

    def test_add_link_returns_self(self):
        span = Span(name="test")
        result = span.add_link("trace-aaa", "span-bbb")
        assert result is span

    def test_add_multiple_links(self):
        span = Span(name="test")
        span.add_link("trace-1", "span-1")
        span.add_link("trace-2", "span-2")
        assert len(span.links) == 2

    def test_links_empty_by_default(self):
        span = Span(name="test")
        assert span.links == []


class TestSpanToDict:
    """Tests for Span.to_dict() with links."""

    def test_to_dict_without_links(self):
        span = Span(name="test")
        span.start()
        span.end()
        d = span.to_dict()
        assert "links" not in d

    def test_to_dict_with_links(self):
        span = Span(name="test")
        span.add_link("trace-aaa", "span-bbb", {"link.type": "child_trace"})
        span.start()
        span.end()
        d = span.to_dict()
        assert "links" in d
        assert len(d["links"]) == 1
        assert d["links"][0] == {
            "context": {"trace_id": "trace-aaa", "span_id": "span-bbb"},
            "attributes": {"link.type": "child_trace"},
        }


class TestSpanToOtelSpanLinks:
    """Tests for Span.to_otel_span() with links."""

    def test_otel_span_empty_links(self):
        span = Span(
            name="test",
            trace_id="a" * 32,
            span_id="b" * 16,
        )
        span.start()
        span.end()
        otel_span = span.to_otel_span()
        assert otel_span.links == ()

    def test_otel_span_with_links(self):
        span = Span(
            name="test",
            trace_id="a" * 32,
            span_id="b" * 16,
        )
        span.add_link("c" * 32, "d" * 16, {"link.type": "child_trace"})
        span.start()
        span.end()
        otel_span = span.to_otel_span()
        assert len(otel_span.links) == 1

        link = otel_span.links[0]
        assert link.context.trace_id == int("c" * 32, 16)
        assert link.context.span_id == int("d" * 16, 16)
        assert link.context.is_remote is True
        assert link.attributes == {"link.type": "child_trace"}


class TestHandlerHandoffContext:
    """Tests for BeaconCallbackHandler.handoff_context() state swap."""

    @pytest.fixture
    def handler(self):
        """Create a BeaconCallbackHandler for testing."""
        from lumenova_beacon.tracing.integrations.langchain import BeaconCallbackHandler
        return BeaconCallbackHandler(agent_name="Orchestrator")

    def test_handoff_span_in_parent_trace(self, handler):
        """HANDOFF span should use the handler's current trace_id."""
        # Simulate handler having an active trace
        handler._current_trace_id = "parent_trace_aaa"
        handler._root_span_id = "root_span_bbb"

        with handler.handoff_context("Math Agent") as ctx:
            assert ctx.handoff_span.trace_id == "parent_trace_aaa"
            assert ctx.handoff_span.span_type == SpanType.HANDOFF
            assert ctx.handoff_span.name == "handoff:Math Agent"

    def test_handoff_span_parented_under_active_tool(self, handler):
        """HANDOFF span parent_id should be the active tool span."""
        handler._current_trace_id = "parent_trace"
        # Simulate an active tool span
        tool_span = Span(name="handoff_to_math_agent", trace_id="parent_trace")
        handler._runs = {"tool-run-1": {"span": tool_span}}
        handler._active_tool_run_ids = ["tool-run-1"]

        with handler.handoff_context("Math Agent") as ctx:
            assert ctx.handoff_span.parent_id == tool_span.span_id

    def test_state_swapped_for_child(self, handler):
        """After entering, handler state should be set for child trace."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "parent_root"
        handler._runs = {"run-1": {"span": Span(name="test")}}
        handler._active_tool_run_ids = ["run-1"]

        with handler.handoff_context("Math Agent") as ctx:
            assert handler._current_trace_id == ctx.trace_id
            assert handler._root_span_id == ctx.root_span_id
            assert handler._runs == {}
            assert handler._active_tool_run_ids == []

    def test_backlink_params_set_for_child(self, handler):
        """Handler's back-link params should point to parent handoff span."""
        handler._current_trace_id = "parent_trace"
        handler._parent_handoff_trace_id = None
        handler._parent_handoff_span_id = None

        with handler.handoff_context("Math Agent") as ctx:
            assert handler._parent_handoff_trace_id == "parent_trace"
            assert handler._parent_handoff_span_id == ctx.handoff_span.span_id

    def test_restores_state_on_exit(self, handler):
        """All parent state should be restored after the block."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "parent_root"
        original_runs = {"run-1": {"span": Span(name="test")}}
        handler._runs = original_runs
        handler._active_tool_run_ids = ["run-1"]
        handler._agent_name = "Orchestrator"

        with handler.handoff_context("Math Agent"):
            pass

        assert handler._current_trace_id == "parent_trace"
        assert handler._root_span_id == "parent_root"
        assert handler._runs is original_runs
        assert handler._active_tool_run_ids == ["run-1"]
        assert handler._agent_name == "Orchestrator"

    def test_restores_state_on_exception(self, handler):
        """Parent state should be restored even on exception."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "parent_root"

        try:
            with handler.handoff_context("Math Agent"):
                raise ValueError("child failed")
        except ValueError:
            pass

        assert handler._current_trace_id == "parent_trace"
        assert handler._root_span_id == "parent_root"

    def test_handoff_span_has_child_trace_link(self, handler):
        """HANDOFF span should have OTEL link to the child root span."""
        handler._current_trace_id = "parent_trace"

        with handler.handoff_context("Math Agent") as ctx:
            assert len(ctx.handoff_span.links) == 1
            link = ctx.handoff_span.links[0]
            assert link.trace_id == ctx.trace_id
            assert link.span_id == ctx.root_span_id
            assert link.attributes == {"link.type": "child_trace"}

    def test_handoff_span_attributes(self, handler):
        """HANDOFF span should carry target info in attributes."""
        handler._current_trace_id = "parent_trace"

        with handler.handoff_context("Math Agent") as ctx:
            attrs = ctx.handoff_span.attributes
            assert attrs["handoff.target_agent"] == "Math Agent"
            assert attrs["handoff.target_trace_id"] == ctx.trace_id
            assert attrs["handoff.target_root_span_id"] == ctx.root_span_id

    def test_handoff_span_exported(self, handler):
        """HANDOFF span should be exported on exit."""
        handler._current_trace_id = "parent_trace"

        with patch.object(handler.client, "export_span") as mock_export:
            with handler.handoff_context("Math Agent") as ctx:
                pass
            mock_export.assert_called_once_with(ctx.handoff_span)

    def test_handoff_span_records_exception(self, handler):
        """HANDOFF span should record child exceptions."""
        handler._current_trace_id = "parent_trace"

        try:
            with handler.handoff_context("Math Agent") as ctx:
                raise RuntimeError("child crashed")
        except RuntimeError:
            pass

        assert ctx.handoff_span.status_code == StatusCode.ERROR

    def test_agent_name_set_to_target(self, handler):
        """target_agent should set handler._agent_name during handoff."""
        handler._current_trace_id = "parent_trace"
        handler._agent_name = "Orchestrator"

        with handler.handoff_context("Math Agent"):
            assert handler._agent_name == "Math Agent"

        assert handler._agent_name == "Orchestrator"

    def test_sequential_handoffs(self, handler):
        """Multiple sequential handoffs should each work independently."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "parent_root"

        with handler.handoff_context("Agent A") as ctx_a:
            trace_a = ctx_a.trace_id

        with handler.handoff_context("Agent B") as ctx_b:
            trace_b = ctx_b.trace_id

        assert trace_a != trace_b
        assert handler._current_trace_id == "parent_trace"

    @pytest.mark.asyncio
    async def test_async_handoff_context(self, handler):
        """Async handoff_context should work identically."""
        handler._current_trace_id = "parent_trace"
        handler._root_span_id = "parent_root"

        async with handler.handoff_context("Math Agent") as ctx:
            assert handler._current_trace_id == ctx.trace_id
            assert ctx.handoff_span.trace_id == "parent_trace"

        assert handler._current_trace_id == "parent_trace"


class TestGetBeaconHandler:
    """Tests for get_beacon_handler() utility."""

    def test_from_list(self):
        from lumenova_beacon.tracing.integrations.langchain import (
            BeaconCallbackHandler,
            get_beacon_handler,
        )
        handler = BeaconCallbackHandler(agent_name="Test")
        config = {"callbacks": [handler]}
        assert get_beacon_handler(config) is handler

    def test_from_callback_manager(self):
        from lumenova_beacon.tracing.integrations.langchain import (
            BeaconCallbackHandler,
            get_beacon_handler,
        )
        handler = BeaconCallbackHandler(agent_name="Test")
        # Simulate a CallbackManager with .handlers attribute
        manager = MagicMock()
        manager.handlers = [handler]
        config = {"callbacks": manager}
        assert get_beacon_handler(config) is handler

    def test_returns_none_when_absent(self):
        from lumenova_beacon.tracing.integrations.langchain import get_beacon_handler
        config = {"callbacks": [MagicMock()]}
        assert get_beacon_handler(config) is None

    def test_returns_none_when_callbacks_none(self):
        from lumenova_beacon.tracing.integrations.langchain import get_beacon_handler
        config = {"callbacks": None}
        assert get_beacon_handler(config) is None

    def test_returns_none_when_no_callbacks_key(self):
        from lumenova_beacon.tracing.integrations.langchain import get_beacon_handler
        config = {}
        assert get_beacon_handler(config) is None


class TestHandoffSpanType:
    """Tests for the HANDOFF SpanType."""

    def test_handoff_enum_value(self):
        assert SpanType.HANDOFF == "handoff"
        assert SpanType.HANDOFF.value == "handoff"

    def test_create_span_with_handoff_type(self, client):
        span = client.create_span("test", span_type=SpanType.HANDOFF)
        assert span.span_type == SpanType.HANDOFF
        assert span.attributes["span.type"] == "handoff"
