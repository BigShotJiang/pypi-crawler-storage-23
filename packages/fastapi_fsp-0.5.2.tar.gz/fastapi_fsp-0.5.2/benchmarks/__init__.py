"""Benchmark utilities for fastapi-fsp package."""
