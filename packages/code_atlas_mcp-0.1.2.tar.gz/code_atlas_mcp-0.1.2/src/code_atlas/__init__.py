"""Code Atlas — code intelligence graph for AI coding agents."""

__version__ = "0.1.0"
