# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Code Atlas is a code intelligence graph system that indexes codebases and exposes them via MCP tools for AI coding agents. It combines graph traversal, semantic search, and BM25 keyword search using Memgraph as the unified backend.

Python with tree-sitter C extension for AST parsing, called in-process via py-tree-sitter.

## Commands

```bash
# Install dependencies
uv sync                          # Runtime dependencies
uv sync --group dev              # Include dev dependencies

# Run tests
uv run pytest                    # All tests
uv run pytest -m "not slow"      # Skip slow tests
uv run pytest -m integration     # Integration tests only (requires Memgraph)
uv run pytest tests/test_foo.py::test_bar  # Single test

# Lint and format
uv run ruff check .              # Lint
uv run ruff check . --fix        # Lint with auto-fix
uv run ruff format .             # Format
uv run ty check                  # Type check

# Pre-commit
uv run pre-commit install        # Install hooks
uv run pre-commit run --all-files  # Run all hooks manually

# Infrastructure
docker compose up -d             # Start Memgraph + Valkey
docker compose --profile tei up -d  # Include local embeddings (TEI)
docker compose down              # Stop services

# CLI
atlas index /path/to/project     # Index a codebase
atlas search "query"             # Hybrid search
atlas status                     # Check index status
atlas mcp                        # Start MCP server
atlas daemon start               # Start indexing daemon (watcher + pipeline)
```

## Architecture

```
src/code_atlas/
├── __init__.py          # __version__ only
├── schema.py            # Graph schema (labels, relationships, DDL generators)
├── settings.py          # Pydantic configuration (atlas.toml + env vars)
├── events.py            # Event types (FileChanged, ASTDirty, EmbedDirty) + Valkey Streams EventBus
├── telemetry.py         # OpenTelemetry integration
├── cli.py               # Typer CLI entrypoint (index, search, status, mcp, daemon commands)
│
├── parsing/
│   ├── ast.py           # Tree-sitter AST parser (py-tree-sitter, in-process)
│   └── detectors.py     # Pluggable pattern detectors (routes, test mappings, overrides)
│
├── graph/
│   └── client.py        # Async Memgraph client (schema, upsert, search)
│
├── search/
│   ├── engine.py        # Hybrid search — RRF fusion across graph/vector/BM25
│   ├── embeddings.py    # Embedding client (litellm) + Valkey cache
│   └── guidance.py      # Cypher validation + search strategy for AI agents
│
├── indexing/
│   ├── orchestrator.py  # Full-index, monorepo detection, staleness checking
│   ├── consumers.py     # Tier 1/2/3 event consumers (batch-pull pattern)
│   ├── watcher.py       # Filesystem watcher (watchfiles + hybrid debounce)
│   └── daemon.py        # Daemon lifecycle manager (watcher + pipeline)
│
└── server/
    ├── mcp.py           # FastMCP server (tools for AI coding agents)
    └── health.py        # Infrastructure health checks + diagnostics
```

**Event Pipeline:** File Watcher → Valkey Streams → Tier 1 (graph metadata) → Tier 2 (AST diff + gate) → Tier 3 (embeddings) → Memgraph

**Query Pipeline:** MCP Server → Query Router → [Graph Search | Vector Search | BM25 Search] → RRF Fusion → Results

**Deployment:** Daemon (`atlas daemon start`) for indexing + MCP (`atlas mcp`) per agent session, decoupled via Valkey + Memgraph

**Infrastructure:** Memgraph (graph DB, port 7687), TEI (embeddings, port 8080), Valkey (event bus, port 6379)

## Code Style

- Python 3.14+, line length 120
- Ruff for linting/formatting, ty for type checking
- Known first-party import: `code_atlas`
- Conventional commits: `feat`, `fix`, `docs`, `style`, `refactor`, `perf`, `test`, `build`, `ci`, `chore`, `revert`

## Development Rules

**Code changes:**

- When integrating new behavior that replaces old behavior, remove the old code paths — don't leave dead artifacts
- When removing code unrelated to the current task, ask before deleting
- Edit existing files — search before writing new code
- Integrate, don't isolate — add to existing modules, not new files
- Generate conservatively — only what's explicitly needed
- No speculative code — no "nice to have" features or premature abstractions

**Planning approach:**

- Plan-first for non-trivial tasks: research the codebase to understand:
  - Where the new functionality integrates (callers, config, CLI, exports, tests)
  - What existing behavior it replaces or extends
  - What old code paths should be removed
- Plan must cover both implementation and integration — no dead code

**Working style:**

- Be honest about uncertainty — if unsure about a domain, library, or implementation approach, say so and ask to research first. Don't guess.
- Use subagents to orchestrate complex/large tasks
- Subagents must NOT commit unless explicitly instructed — the parent agent controls commits

## Testing

- Tests in `tests/` directory, async-first with pytest-asyncio (auto mode)
- Markers: `@pytest.mark.slow`, `@pytest.mark.integration`
- Fixtures centralized in `conftest.py`
- **High gear (default):** Integration tests exercising full workflows and public APIs
- **Low gear (selective):** Unit tests only for complex algorithms or edge cases unreachable via integration
- Don't test every function. Test system behavior.

## Commits

- Use [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/) format: `<type>(<scope>): <description>`
- Commit immediately when task is done
- Amend for feedback: `git add . && git commit --amend --no-edit`
- New commit only for genuinely separate work
- Never unstage changes that would cause data loss (e.g., don't `git reset` if it would discard changes)

**Version bumping (semantic versioning)**

## Configuration

- `atlas.toml` - Project configuration (scope, embeddings, search settings, detectors)
- `.atlasignore` - Gitignore-style exclusion patterns for indexing
- Environment variables: `ATLAS_*` prefix with double-underscore nesting (e.g., `ATLAS_EMBEDDINGS__MODEL`)
