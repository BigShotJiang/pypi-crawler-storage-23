"""Confirmation dialog screen."""

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Label


class ConfirmExitScreen(ModalScreen[bool]):
    """Modal screen for confirming destructive actions."""

    DEFAULT_CSS = """
        ConfirmExitScreen {
            align: center middle;
        }

        ConfirmExitScreen > Vertical {
            width: 50%;
            height: auto;
            border: solid $primary;
            align: center middle;
        }

        ConfirmExitScreen > Vertical > Label {
            height: 5;
            width: 1fr;
            column-span: 2;
            content-align: center middle;
            text-align: center;
            color: $error;
        }

        ConfirmExitScreen > Vertical > Horizontal {
            height: auto;
            align: center middle;
        }

        ConfirmExitScreen > Vertical > Horizontal > Button {
            margin: 0 1 1 1;
        }
    """

    BINDINGS = [Binding("escape", "dismiss", "Dismiss", show=False)]

    def __init__(self, message: str, action_label: str) -> None:
        """Initialize the confirmation screen.

        Args:
            message: The confirmation message to display
            action_label: Label for the action button (e.g., "Delete")
        """
        super().__init__()
        self.message = message
        self.action_label = action_label

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Label(self.message, id="confirm-exit")
            with Horizontal(classes="button-container"):
                yield Button("Back", id="cancel")
                yield Button(self.action_label, id="action", variant="error")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press."""
        action = event.button.id == "action"
        self.dismiss(action)
