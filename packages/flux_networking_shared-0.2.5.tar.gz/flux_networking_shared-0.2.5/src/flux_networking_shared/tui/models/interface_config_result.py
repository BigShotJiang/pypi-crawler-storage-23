"""Interface configuration result model."""

from __future__ import annotations

from dataclasses import KW_ONLY, dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from flux_networking_shared.tui.widgets import Interface


@dataclass
class InterfaceShapingPolicy:
    """Traffic shaping policy for an interface."""

    is_shaped: bool = False
    rate: Literal[35, 75, 135, 250] | None = None


@dataclass
class InterfaceConfigResult:
    """Result of interface configuration modal.

    Contains the interface being configured and information about
    what changes were made.
    """

    interface: Interface
    change_type: Literal["add", "remove", "change", "none"] = "none"
    _: KW_ONLY
    delete: bool = False
    vlan: str | None = None
    bandwidth_limit: Literal[35, 75, 135, 250] | None = None
    bandwidth_changed: bool = False

    @property
    def changes(self) -> bool:
        """Check if any changes were made."""
        return self.change_type != "none"
