# Dummy probert module for macOS development
# This allows flux_networking_shared to be installed on macOS
# without the actual probert dependency which is Linux-only
