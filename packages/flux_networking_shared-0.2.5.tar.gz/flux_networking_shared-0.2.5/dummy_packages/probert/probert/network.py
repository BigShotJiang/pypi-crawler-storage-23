# Dummy probert.network module for macOS development
# Provides stub classes that network_observer.py imports


class Link:
    """Stub for probert Link class."""

    def __init__(self):
        self.type = ""
        self.name = ""
        self.flags = 0

    def serialize(self) -> dict:
        return {}


class NetworkEventReceiver:
    """Stub for probert NetworkEventReceiver class."""

    def new_link(self, ifindex: int, link: Link):
        pass

    def update_link(self, ifindex: int):
        pass

    def del_link(self, ifindex: int):
        pass

    def route_change(self, action: str, data):
        pass


class UdevObserver:
    """Stub for probert UdevObserver class."""

    def __init__(self, receiver: NetworkEventReceiver):
        self.receiver = receiver

    def start(self) -> list[int]:
        return []

    def data_ready(self, fd: int):
        pass
