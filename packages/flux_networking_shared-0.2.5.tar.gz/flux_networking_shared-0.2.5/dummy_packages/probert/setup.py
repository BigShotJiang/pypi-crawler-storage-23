from setuptools import setup, find_packages

setup(
    name="probert",
    version="0.0.18",
    description="Dummy probert package for macOS development",
    packages=find_packages(),
    py_modules=["probert"],
)
