from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from typing import Any, AsyncIterator, Dict, List, Mapping, Optional, Union, cast

import requests


class QrustyClient:
    """
    Python client for the qrusty priority queue API.

    Example usage:
        client = QrustyClient(base_url="http://localhost:6784")
        client.create_queue(name="orders", ordering="MaxFirst", allow_duplicates=True)
        client.publish(queue="orders", priority=100, payload={"order_id": 123})
        message = client.consume(queue="orders", consumer_id="worker-1")
        if message is not None:
            client.ack(queue="orders", message_id=message["id"], consumer_id="worker-1")
    """

    def __init__(self, base_url: str):
        """
        Initialize the client with the base URL of the qrusty API server.
        :param base_url: Base URL of the qrusty server (e.g., http://localhost:6784)
        """
        self.base_url = base_url.rstrip("/")

    def health(self) -> str:
        """Check server health."""
        resp = requests.get(f"{self.base_url}/health", timeout=10)
        resp.raise_for_status()
        return resp.text

    def create_queue(
        self,
        name: str,
        ordering: str = "MaxFirst",
        allow_duplicates: bool = True,
    ) -> None:
        """Create a new queue. Raises an error if the queue already exists."""
        data: Dict[str, Any] = {
            "name": name,
            "config": {"ordering": ordering, "allow_duplicates": allow_duplicates},
        }
        resp = requests.post(f"{self.base_url}/create-queue", json=data, timeout=10)
        resp.raise_for_status()

    def update_queue(
        self,
        name: str,
        new_name: Optional[str] = None,
        allow_duplicates: Optional[bool] = None,
    ) -> None:
        """Update queue configuration (name and/or allow_duplicates)."""
        config: Dict[str, Any] = {}
        if new_name is not None:
            config["name"] = new_name
        if allow_duplicates is not None:
            config["allow_duplicates"] = allow_duplicates

        if not config:
            raise ValueError(
                "At least one of new_name or allow_duplicates must be specified"
            )

        data: Dict[str, Any] = {"name": name, "config": config}
        resp = requests.post(f"{self.base_url}/update-queue", json=data, timeout=10)
        resp.raise_for_status()

    def delete_queue(self, queue: str) -> Dict[str, Any]:
        """Delete a queue and all of its messages."""
        resp = requests.delete(f"{self.base_url}/delete-queue/{queue}", timeout=10)
        resp.raise_for_status()
        return cast(Dict[str, Any], resp.json())

    def publish(
        self,
        queue: str,
        priority: int,
        payload: Union[Mapping[str, Any], str],
        max_retries: int = 3,
    ) -> Dict[str, Any]:
        """
        Publish a message to a queue.
        :param queue: Queue name
        :param priority: Message priority
        :param payload: Message payload (dict or a pre-serialized JSON string)
        :param max_retries: Maximum retry count
        :return: Response JSON from server
        """
        payload_str = payload if isinstance(payload, str) else json.dumps(dict(payload))
        data: dict[str, Any] = {
            "queue": queue,
            "priority": priority,
            "payload": payload_str,
            "max_retries": max_retries,
        }
        resp = requests.post(f"{self.base_url}/publish", json=data, timeout=10)
        resp.raise_for_status()
        return cast(Dict[str, Any], resp.json())

    def consume(
        self, queue: str, consumer_id: str, timeout_seconds: int = 30
    ) -> Optional[Dict[str, Any]]:
        """
        Consume a message from a queue.
        :param queue: Queue name
        :param consumer_id: Consumer identifier
        :param timeout_seconds: Lock timeout in seconds
        :return: Message JSON from server, or None if the queue is empty
        """
        data: Dict[str, Any] = {
            "consumer_id": consumer_id,
            "timeout_seconds": timeout_seconds,
        }
        resp = requests.post(f"{self.base_url}/consume/{queue}", json=data, timeout=10)
        resp.raise_for_status()
        return cast(Optional[Dict[str, Any]], resp.json())

    def ack(self, queue: str, message_id: str, consumer_id: str) -> bool:
        """
        Acknowledge a message as processed.
        :param queue: Queue name
        :param message_id: Message ID
        :param consumer_id: Consumer identifier
        :return: True if acked, False if not found/not locked by this consumer
        """
        data: Dict[str, Any] = {"consumer_id": consumer_id}
        resp = requests.post(
            f"{self.base_url}/ack/{queue}/{message_id}", json=data, timeout=10
        )
        if resp.status_code == 200:
            return True
        if resp.status_code == 404:
            return False
        resp.raise_for_status()
        return False

    def nack(self, queue: str, message_id: str, consumer_id: str) -> bool:
        """Negative-acknowledge a message."""
        data: Dict[str, Any] = {"consumer_id": consumer_id}
        resp = requests.post(
            f"{self.base_url}/nack/{queue}/{message_id}", json=data, timeout=10
        )
        if resp.status_code == 200:
            return True
        if resp.status_code == 404:
            return False
        resp.raise_for_status()
        return False

    def purge(self, queue: str) -> dict[str, Any]:
        """
        Purge all messages from a queue.
        :param queue: Queue name
        :return: Response JSON from server
        """
        resp = requests.post(f"{self.base_url}/purge-queue/{queue}", timeout=10)
        resp.raise_for_status()
        return cast(Dict[str, Any], resp.json())

    def stats(self) -> dict[str, Any]:
        """
        Get statistics for all queues.
        :return: Stats JSON from server
        """
        resp = requests.get(f"{self.base_url}/stats", timeout=10)
        resp.raise_for_status()
        return cast(Dict[str, Any], resp.json())

    def queue_stats(self, queue: str) -> Dict[str, Any]:
        """Get statistics for a specific queue."""
        resp = requests.get(f"{self.base_url}/queue-stats/{queue}", timeout=10)
        resp.raise_for_status()
        return cast(Dict[str, Any], resp.json())

    def queue_metrics(self, queue: str) -> Dict[str, Any]:
        """Get time-series metrics for a queue."""
        resp = requests.get(f"{self.base_url}/queues/{queue}/metrics", timeout=10)
        resp.raise_for_status()
        return cast(Dict[str, Any], resp.json())

    def list_queues(self) -> list[str]:
        """
        List all active queue names.
        :return: List of queue names
        """
        resp = requests.get(f"{self.base_url}/queues", timeout=10)
        resp.raise_for_status()
        return cast(List[str], resp.json())


# ---------------------------------------------------------------------------
# Implements: WS-0018
# WsSession – WebSocket client (WS-0018)
# ---------------------------------------------------------------------------


@dataclass
class DeliveredMessage:
    """A message delivered by the server over a WebSocket subscription."""

    queue: str
    id: str
    payload: str
    priority: int
    created_at: str


class WsSession:
    """
    Async WebSocket session for the Qrusty priority queue server.

    Usage::

        async with WsSession("ws://localhost:6784") as session:
            msg_id = await session.publish("orders", "hello", priority=10)
            async for msg in session.subscribe("orders"):
                print(msg.payload)
                await session.ack(msg.queue, msg.id)
                break

    Requires the ``websockets`` package::

        pip install websockets
    """

    def __init__(self, addr: str) -> None:
        """
        :param addr: Server WebSocket base URL, e.g. ``ws://localhost:6784``.
        """
        self._addr = addr.rstrip("/")
        self._ws: Any = None
        self._req_counter = 0
        self._pending: Dict[str, asyncio.Future[Any]] = {}
        self._deliver_queues: Dict[str, asyncio.Queue[DeliveredMessage]] = {}
        self._reader_task: Optional[asyncio.Task[None]] = None

    async def __aenter__(self) -> "WsSession":
        import websockets  # type: ignore[import-not-found]

        self._ws = await websockets.connect(f"{self._addr}/ws")
        self._reader_task = asyncio.create_task(self._reader())
        return self

    async def __aexit__(self, *exc: Any) -> None:
        if self._reader_task:
            self._reader_task.cancel()
        if self._ws:
            await self._ws.close()

    # -----------------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------------

    def _next_req_id(self) -> str:
        self._req_counter += 1
        return f"req-{self._req_counter}"

    async def _reader(self) -> None:
        """Background task: routes inbound frames to pending requests or delivery queues."""
        try:
            async for raw in self._ws:
                frame = json.loads(raw)
                req_id = frame.get("req_id")
                if req_id and req_id in self._pending:
                    self._pending[req_id].set_result(frame)
                elif frame.get("type") == "deliver":
                    queue = frame.get("queue", "")
                    if queue in self._deliver_queues:
                        msg = DeliveredMessage(
                            queue=queue,
                            id=frame["id"],
                            payload=frame["payload"],
                            priority=int(frame.get("priority", 0)),
                            created_at=frame.get("created_at", ""),
                        )
                        await self._deliver_queues[queue].put(msg)
        except Exception:
            pass
        finally:
            # Wake all pending requests with an error so callers unblock.
            for fut in self._pending.values():
                if not fut.done():
                    fut.set_exception(ConnectionError("connection closed"))
            self._pending.clear()
            # Put a sentinel into each delivery queue so subscriber generators
            # stop iterating instead of waiting forever.
            for q in self._deliver_queues.values():
                q.put_nowait(None)  # type: ignore[arg-type]
            self._deliver_queues.clear()

    async def _request(self, frame: Dict[str, Any]) -> Dict[str, Any]:
        req_id = self._next_req_id()
        frame["req_id"] = req_id
        loop = asyncio.get_event_loop()
        fut: asyncio.Future[Any] = loop.create_future()
        self._pending[req_id] = fut
        try:
            await self._ws.send(json.dumps(frame))
            resp = await asyncio.wait_for(fut, timeout=30)
        finally:
            self._pending.pop(req_id, None)

        if resp.get("type") == "error":
            raise RuntimeError(
                f"server error [{resp.get('code')}]: {resp.get('message')}"
            )
        return cast(Dict[str, Any], resp)

    # -----------------------------------------------------------------------
    # Public API (WS-0018)
    # -----------------------------------------------------------------------

    async def publish(self, queue: str, payload: str, *, priority: int = 0) -> str:
        """Publish a message; returns the assigned message id."""
        resp = await self._request(
            {
                "type": "publish",
                "queue": queue,
                "payload": payload,
                "priority": priority,
            }
        )
        return str(resp["id"])

    async def subscribe(self, queue: str) -> AsyncIterator[DeliveredMessage]:
        """
        Subscribe to *queue* and return an async iterator of :class:`DeliveredMessage`.

        Usage::

            async for msg in session.subscribe("orders"):
                ...
        """
        await self._request({"type": "subscribe", "queue": queue})
        self._deliver_queues.setdefault(queue, asyncio.Queue())

        async def _gen() -> AsyncIterator[DeliveredMessage]:
            q = self._deliver_queues[queue]
            while True:
                msg = await q.get()
                if msg is None:
                    return
                yield msg

        return _gen()

    async def unsubscribe(self, queue: str) -> None:
        """Unsubscribe from *queue*."""
        await self._request({"type": "unsubscribe", "queue": queue})
        self._deliver_queues.pop(queue, None)

    async def ack(self, queue: str, id: str) -> None:
        """Acknowledge message *id* on *queue*."""
        await self._request({"type": "ack", "queue": queue, "id": id})

    async def nack(self, queue: str, id: str) -> None:
        """Negative-acknowledge message *id* on *queue*."""
        await self._request({"type": "nack", "queue": queue, "id": id})

    async def batch_ack(self, queue: str, ids: list[str]) -> int:
        """Batch-acknowledge *ids*; returns the count of acked messages."""
        resp = await self._request({"type": "batch-ack", "queue": queue, "ids": ids})
        return int(resp.get("acked", 0))

    async def batch_nack(self, queue: str, ids: list[str]) -> tuple[int, int]:
        """Batch-negative-acknowledge *ids*; returns ``(unlocked, dropped)``."""
        resp = await self._request({"type": "batch-nack", "queue": queue, "ids": ids})
        return int(resp.get("unlocked", 0)), int(resp.get("dropped", 0))
