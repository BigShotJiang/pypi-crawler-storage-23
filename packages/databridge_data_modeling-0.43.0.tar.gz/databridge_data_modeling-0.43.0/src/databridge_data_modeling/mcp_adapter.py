"""Package-backed MCP adapter for data modeling tools."""

from src.data_modeling.mcp_impl import (
    register_data_modeling_tools,
    _discover_data_model,
)

__all__ = ["register_data_modeling_tools", "_discover_data_model"]
