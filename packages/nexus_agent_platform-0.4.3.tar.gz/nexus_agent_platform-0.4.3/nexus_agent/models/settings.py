from typing import Optional
from pydantic import BaseModel

from nexus_agent.models.memory import MemorySettings


class LLMSettings(BaseModel):
    model: str = "gemini/gemini-3-flash-preview"
    api_base: Optional[str] = None
    api_key: Optional[str] = None  # override, 미설정 시 env GOOGLE_API_KEY 사용
    temperature: float = 0.7
    max_tokens: int = 4096
    system_prompt: str = ""


class ProfileSettings(BaseModel):
    name: str = ""
    avatar: str = ""  # base64 data URI
    platform_name: str = "Track Platform"
    platform_subtitle: str = "Nexus System"
    bot_name: str = "Nexus Platform Core"
    bot_avatar: str = ""  # base64 data URI


class ThemeSettings(BaseModel):
    accent_color: str = "amber"
    mode: str = "dark"
    tone: str = "default"
    show_blobs: bool = True
    chat_bg_image: str = "/rubber-track.png"
    chat_bg_opacity: float = 0.3
    chat_bg_scale: float = 1.1
    chat_bg_position_x: float = 50
    chat_bg_position_y: float = 50


class AppSettings(BaseModel):
    llm: LLMSettings = LLMSettings()
    memory: MemorySettings = MemorySettings()
    profile: ProfileSettings = ProfileSettings()
    theme: ThemeSettings = ThemeSettings()


class UpdateLLMRequest(BaseModel):
    model: Optional[str] = None
    api_base: Optional[str] = None
    api_key: Optional[str] = None
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    system_prompt: Optional[str] = None


class UpdateMemorySettingsRequest(BaseModel):
    enabled: Optional[bool] = None
    max_memories: Optional[int] = None
    max_injection_tokens: Optional[int] = None
    compression_threshold: Optional[float] = None


class UpdateProfileRequest(BaseModel):
    name: Optional[str] = None
    avatar: Optional[str] = None
    platform_name: Optional[str] = None
    platform_subtitle: Optional[str] = None
    bot_name: Optional[str] = None
    bot_avatar: Optional[str] = None


class UpdateThemeRequest(BaseModel):
    accent_color: Optional[str] = None
    mode: Optional[str] = None
    tone: Optional[str] = None
    show_blobs: Optional[bool] = None
    chat_bg_image: Optional[str] = None
    chat_bg_opacity: Optional[float] = None
    chat_bg_scale: Optional[float] = None
    chat_bg_position_x: Optional[float] = None
    chat_bg_position_y: Optional[float] = None
