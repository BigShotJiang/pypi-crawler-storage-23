#!/usr/bin/env python3
"""Cross-platform build script for Nexus Agent."""
import shutil
import subprocess
import sys
from pathlib import Path


def run(cmd: list[str], cwd: Path | None = None) -> None:
    print(f"  $ {' '.join(cmd)}")
    subprocess.run(cmd, cwd=cwd, check=True)


def main():
    root = Path(__file__).resolve().parent.parent
    frontend = root / "frontend"
    static = root / "nexus_agent" / "static"

    print("=== Building frontend ===")
    run(["pnpm", "install"], cwd=frontend)
    run(["pnpm", "build"], cwd=frontend)

    print("=== Copying static files ===")
    if static.exists():
        shutil.rmtree(static)
    shutil.copytree(frontend / "out", static)

    print("=== Building Python wheel ===")
    run(["uv", "build"], cwd=root)

    print("=== Done ===")
    for f in sorted((root / "dist").glob("*")):
        print(f"  {f.name}  ({f.stat().st_size:,} bytes)")


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as e:
        print(f"Error: command failed with exit code {e.returncode}", file=sys.stderr)
        sys.exit(1)
