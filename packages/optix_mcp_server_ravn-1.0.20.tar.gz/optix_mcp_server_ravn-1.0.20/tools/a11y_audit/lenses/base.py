"""Base lens class and data structures for Accessibility Audit lenses."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional

from tools.a11y_audit.domains import A11yLens, AccessibilityStepDomain


@dataclass
class LensRule:
    """A single accessibility audit rule within a lens.

    Attributes:
        id: Unique rule identifier (e.g., "SR-001")
        domain: Which accessibility step domain this rule applies to
        name: Short name for the rule
        description: Detailed description of what this rule checks
        wcag_criterion: WCAG success criterion (e.g., "1.1.1")
        wcag_level: WCAG conformance level (A, AA, AAA)
        severity_default: Default severity level for findings
        check_guidance: List of specific checks to perform
    """

    id: str
    domain: AccessibilityStepDomain
    name: str
    description: str
    wcag_criterion: str
    wcag_level: str
    severity_default: str
    check_guidance: list[str] = field(default_factory=list)


@dataclass
class LensConfig:
    """Configuration for an accessibility audit lens.

    Contains all rules organized by accessibility step domain.
    """

    lens: A11yLens
    display_name: str
    description: str
    structure_rules: list[LensRule] = field(default_factory=list)
    aria_rules: list[LensRule] = field(default_factory=list)
    keyboard_rules: list[LensRule] = field(default_factory=list)
    focus_rules: list[LensRule] = field(default_factory=list)
    color_rules: list[LensRule] = field(default_factory=list)
    semantic_rules: list[LensRule] = field(default_factory=list)

    def get_rules_for_domain(self, domain: AccessibilityStepDomain) -> list[LensRule]:
        """Get all rules applicable to a specific accessibility domain.

        Args:
            domain: The accessibility step domain

        Returns:
            List of rules for that domain
        """
        mapping = {
            AccessibilityStepDomain.STRUCTURE: self.structure_rules,
            AccessibilityStepDomain.ARIA_LABELS: self.aria_rules,
            AccessibilityStepDomain.KEYBOARD_NAV: self.keyboard_rules,
            AccessibilityStepDomain.FOCUS_MANAGEMENT: self.focus_rules,
            AccessibilityStepDomain.COLOR_CONTRAST: self.color_rules,
            AccessibilityStepDomain.SEMANTIC_HTML: self.semantic_rules,
        }
        return mapping.get(domain, [])

    def get_all_rules(self) -> list[LensRule]:
        """Get all rules across all domains.

        Returns:
            List of all rules in this lens configuration
        """
        return (
            self.structure_rules
            + self.aria_rules
            + self.keyboard_rules
            + self.focus_rules
            + self.color_rules
            + self.semantic_rules
        )

    def get_rule_ids(self) -> list[str]:
        """Get all rule IDs in this lens.

        Returns:
            List of rule ID strings
        """
        return [rule.id for rule in self.get_all_rules()]


class BaseLens(ABC):
    """Abstract base class for Accessibility Audit lenses.

    Each lens provides a specialized perspective on accessibility analysis.
    Subclasses must implement lens_type and get_config methods.
    """

    @property
    @abstractmethod
    def lens_type(self) -> A11yLens:
        """Return the lens type enum value."""
        ...

    @abstractmethod
    def get_config(self) -> LensConfig:
        """Return the lens configuration with all rules."""
        ...

    def get_required_actions(self, domain: AccessibilityStepDomain) -> list[str]:
        """Get required actions for a specific domain based on lens rules.

        Args:
            domain: The accessibility step domain

        Returns:
            List of required action strings
        """
        config = self.get_config()
        rules = config.get_rules_for_domain(domain)

        actions = []
        for rule in rules:
            actions.extend(rule.check_guidance)

        return actions if actions else [f"Analyze {domain.description()}"]

    def get_rule_summary(self) -> dict[str, int]:
        """Get a summary of rules by domain.

        Returns:
            Dictionary mapping domain names to rule counts
        """
        config = self.get_config()
        return {
            "structure": len(config.structure_rules),
            "aria": len(config.aria_rules),
            "keyboard": len(config.keyboard_rules),
            "focus": len(config.focus_rules),
            "color": len(config.color_rules),
            "semantic": len(config.semantic_rules),
            "total": len(config.get_all_rules()),
        }
