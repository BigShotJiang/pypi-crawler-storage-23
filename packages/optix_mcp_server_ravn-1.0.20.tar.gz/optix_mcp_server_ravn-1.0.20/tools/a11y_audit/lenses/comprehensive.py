"""Comprehensive lens for Accessibility Audit.

Combines the most important rules from all specialized lenses to provide
a complete accessibility review covering all user needs.
"""

from tools.a11y_audit.domains import A11yLens, AccessibilityStepDomain
from tools.a11y_audit.lenses.base import BaseLens, LensConfig, LensRule


class ComprehensiveLens(BaseLens):
    """Comprehensive accessibility perspective.

    Combines key rules from Screen Reader, Keyboard, Visual, and WCAG
    lenses to provide a full accessibility review.
    """

    @property
    def lens_type(self) -> A11yLens:
        return A11yLens.COMPREHENSIVE

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=A11yLens.COMPREHENSIVE,
            display_name="Comprehensive",
            description="Full accessibility review covering all user needs",
            structure_rules=[
                LensRule(
                    id="COMP-S001",
                    domain=AccessibilityStepDomain.STRUCTURE,
                    name="Page Structure",
                    description="Complete structural analysis",
                    wcag_criterion="1.3.1",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Verify heading hierarchy (h1 through h6)",
                        "Check landmark regions (main, nav, header, footer)",
                        "Verify logical DOM order",
                        "Check responsive layout at various sizes",
                    ],
                ),
            ],
            aria_rules=[
                LensRule(
                    id="COMP-A001",
                    domain=AccessibilityStepDomain.ARIA_LABELS,
                    name="Interactive Element Labels",
                    description="All interactive elements have accessible names",
                    wcag_criterion="4.1.2",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Check all buttons have visible or aria labels",
                        "Verify form inputs have associated labels",
                        "Check links describe their destination",
                        "Verify icon buttons have accessible names",
                    ],
                ),
                LensRule(
                    id="COMP-A002",
                    domain=AccessibilityStepDomain.ARIA_LABELS,
                    name="ARIA Usage",
                    description="Correct ARIA role and property usage",
                    wcag_criterion="4.1.2",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Verify appropriate role usage",
                        "Check aria-live for dynamic content",
                        "Verify required ARIA attributes",
                    ],
                ),
            ],
            keyboard_rules=[
                LensRule(
                    id="COMP-K001",
                    domain=AccessibilityStepDomain.KEYBOARD_NAV,
                    name="Keyboard Accessibility",
                    description="All functionality available via keyboard",
                    wcag_criterion="2.1.1",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Verify all interactive elements are focusable",
                        "Check no keyboard traps exist",
                        "Verify tab order is logical",
                        "Check skip links are present",
                    ],
                ),
            ],
            focus_rules=[
                LensRule(
                    id="COMP-F001",
                    domain=AccessibilityStepDomain.FOCUS_MANAGEMENT,
                    name="Focus Management",
                    description="Focus visibility and management",
                    wcag_criterion="2.4.7",
                    wcag_level="AA",
                    severity_default="critical",
                    check_guidance=[
                        "Verify visible focus indicators on all elements",
                        "Check focus moves properly for dialogs",
                        "Verify focus returns when dialogs close",
                        "Check focus management for SPAs",
                    ],
                ),
            ],
            color_rules=[
                LensRule(
                    id="COMP-C001",
                    domain=AccessibilityStepDomain.COLOR_CONTRAST,
                    name="Color Contrast",
                    description="Text and UI contrast requirements",
                    wcag_criterion="1.4.3",
                    wcag_level="AA",
                    severity_default="critical",
                    check_guidance=[
                        "Check text contrast 4.5:1 minimum",
                        "Check large text contrast 3:1 minimum",
                        "Verify UI component contrast 3:1",
                        "Check color is not sole information method",
                    ],
                ),
            ],
            semantic_rules=[
                LensRule(
                    id="COMP-SM001",
                    domain=AccessibilityStepDomain.SEMANTIC_HTML,
                    name="Semantic HTML",
                    description="Proper semantic markup usage",
                    wcag_criterion="1.3.1",
                    wcag_level="A",
                    severity_default="high",
                    check_guidance=[
                        "Verify images have alt text",
                        "Check tables have proper headers",
                        "Verify forms use semantic elements",
                        "Check page has lang attribute",
                    ],
                ),
                LensRule(
                    id="COMP-SM002",
                    domain=AccessibilityStepDomain.SEMANTIC_HTML,
                    name="Text Alternatives",
                    description="All content has text alternatives",
                    wcag_criterion="1.1.1",
                    wcag_level="A",
                    severity_default="critical",
                    check_guidance=[
                        "Check all images have appropriate alt",
                        "Verify video has captions",
                        "Check audio has transcripts",
                    ],
                ),
            ],
        )
