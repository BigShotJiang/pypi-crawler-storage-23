"""Workspace setup for Notion Security Hub databases."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from tools.notion_hub.client import NotionClient

logger = logging.getLogger(__name__)

AUDIT_DB_PROPERTIES: dict[str, Any] = {
    "Name": {"title": {}},
    "Audit Type": {
        "select": {
            "options": [
                {"name": "Security", "color": "red"},
                {"name": "Accessibility", "color": "blue"},
                {"name": "DevOps", "color": "orange"},
                {"name": "Principal", "color": "purple"},
                {"name": "Team Analytics", "color": "green"},
            ]
        }
    },
    "Lens": {
        "select": {
            "options": [
                {"name": "Comprehensive", "color": "default"},
                {"name": "Backend", "color": "blue"},
                {"name": "Frontend", "color": "purple"},
                {"name": "DevSecOps", "color": "orange"},
                {"name": "Compliance", "color": "red"},
            ]
        }
    },
    "Status": {
        "select": {
            "options": [
                {"name": "Completed", "color": "green"},
                {"name": "In Progress", "color": "yellow"},
                {"name": "Failed", "color": "red"},
            ]
        }
    },
    "Total Findings": {"number": {"format": "number"}},
    "Critical": {"number": {"format": "number"}},
    "High": {"number": {"format": "number"}},
    "Medium": {"number": {"format": "number"}},
    "Low": {"number": {"format": "number"}},
    "Files Examined": {"number": {"format": "number"}},
    "Date": {"date": {}},
    "Project": {"rich_text": {}},
    "Audit ID": {"rich_text": {}},
}

KNOWLEDGE_DB_PROPERTIES: dict[str, Any] = {
    "Pattern Name": {"title": {}},
    "CWE ID": {"rich_text": {}},
    "Category": {
        "select": {
            "options": [
                {"name": "Injection", "color": "red"},
                {"name": "Authentication", "color": "orange"},
                {"name": "Authorization", "color": "yellow"},
                {"name": "Cryptography", "color": "blue"},
                {"name": "Configuration", "color": "purple"},
                {"name": "Input Validation", "color": "pink"},
                {"name": "Error Handling", "color": "gray"},
                {"name": "Code Quality", "color": "green"},
                {"name": "Dependencies", "color": "brown"},
                {"name": "Other", "color": "default"},
            ]
        }
    },
    "Severity": {
        "select": {
            "options": [
                {"name": "Critical", "color": "red"},
                {"name": "High", "color": "orange"},
                {"name": "Medium", "color": "yellow"},
                {"name": "Low", "color": "green"},
                {"name": "Info", "color": "blue"},
            ]
        }
    },
    "Frequency": {"number": {"format": "number"}},
    "Last Seen": {"date": {}},
    "First Seen": {"date": {}},
    "Affected Audits": {"number": {"format": "number"}},
    "Description": {"rich_text": {}},
    "Remediation": {"rich_text": {}},
}

COMPLIANCE_DB_PROPERTIES: dict[str, Any] = {
    "Control ID": {"title": {}},
    "Framework": {
        "select": {
            "options": [
                {"name": "SOC2", "color": "blue"},
                {"name": "PCI-DSS", "color": "red"},
                {"name": "HIPAA", "color": "green"},
                {"name": "OWASP", "color": "orange"},
                {"name": "GDPR", "color": "purple"},
            ]
        }
    },
    "Control Name": {"rich_text": {}},
    "Status": {
        "select": {
            "options": [
                {"name": "Passing", "color": "green"},
                {"name": "At Risk", "color": "yellow"},
                {"name": "Failing", "color": "red"},
                {"name": "Not Assessed", "color": "gray"},
            ]
        }
    },
    "Related CWEs": {"rich_text": {}},
    "Open Findings": {"number": {"format": "number"}},
    "Last Updated": {"date": {}},
    "Notes": {"rich_text": {}},
}


@dataclass
class WorkspaceSetupResult:
    """Result of workspace setup."""

    success: bool
    audit_db_id: str | None = None
    knowledge_db_id: str | None = None
    compliance_db_id: str | None = None
    audit_db_url: str | None = None
    knowledge_db_url: str | None = None
    compliance_db_url: str | None = None
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "audit_db_id": self.audit_db_id,
            "knowledge_db_id": self.knowledge_db_id,
            "compliance_db_id": self.compliance_db_id,
            "audit_db_url": self.audit_db_url,
            "knowledge_db_url": self.knowledge_db_url,
            "compliance_db_url": self.compliance_db_url,
            "error": self.error,
        }


def setup_workspace(
    client: NotionClient,
    parent_page_id: str,
) -> WorkspaceSetupResult:
    """Create all three databases for Notion Security Hub.

    Args:
        client: Notion API client
        parent_page_id: ID of the parent page where databases will be created

    Returns:
        WorkspaceSetupResult with database IDs and URLs
    """
    try:
        logger.info(f"Creating Optix databases in parent page: {parent_page_id}")

        audit_db = client.create_database(
            parent_page_id=parent_page_id,
            title="Optix Audit Reports",
            properties=AUDIT_DB_PROPERTIES,
            icon="🔍",
        )
        audit_db_id = audit_db["id"]
        audit_db_url = audit_db.get("url", "")
        logger.info(f"Created Audit Reports database: {audit_db_id}")

        knowledge_db = client.create_database(
            parent_page_id=parent_page_id,
            title="Optix Knowledge Base",
            properties=KNOWLEDGE_DB_PROPERTIES,
            icon="📚",
        )
        knowledge_db_id = knowledge_db["id"]
        knowledge_db_url = knowledge_db.get("url", "")
        logger.info(f"Created Knowledge Base database: {knowledge_db_id}")

        compliance_db = client.create_database(
            parent_page_id=parent_page_id,
            title="Optix Compliance Controls",
            properties=COMPLIANCE_DB_PROPERTIES,
            icon="✅",
        )
        compliance_db_id = compliance_db["id"]
        compliance_db_url = compliance_db.get("url", "")
        logger.info(f"Created Compliance Controls database: {compliance_db_id}")

        return WorkspaceSetupResult(
            success=True,
            audit_db_id=audit_db_id,
            knowledge_db_id=knowledge_db_id,
            compliance_db_id=compliance_db_id,
            audit_db_url=audit_db_url,
            knowledge_db_url=knowledge_db_url,
            compliance_db_url=compliance_db_url,
        )

    except Exception as e:
        logger.error(f"Failed to setup workspace: {e}")
        return WorkspaceSetupResult(
            success=False,
            error=str(e),
        )


def get_env_config_snippet(result: WorkspaceSetupResult) -> str:
    """Generate .env configuration snippet from setup result."""
    if not result.success:
        return f"# Setup failed: {result.error}"

    lines = [
        "# Notion Security Hub Configuration",
        "# Add these to your .env file or agent configuration:",
        "",
        f"OPTIX_NOTION_AUDIT_DB_ID={result.audit_db_id}",
        f"OPTIX_NOTION_KNOWLEDGE_DB_ID={result.knowledge_db_id}",
        f"OPTIX_NOTION_COMPLIANCE_DB_ID={result.compliance_db_id}",
        "",
        "# Database URLs:",
        f"# Audit Reports: {result.audit_db_url}",
        f"# Knowledge Base: {result.knowledge_db_url}",
        f"# Compliance Controls: {result.compliance_db_url}",
    ]
    return "\n".join(lines)
