"""MCP tool implementation for Notion Security Intelligence Hub."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from tools.notion_hub.client import NotionClient, NotionAPIError
from tools.notion_hub.config import NotionHubConfig, NotionConfig
from tools.notion_hub.formatter import AuditFormatter
from tools.notion_hub.patterns import PatternExtractor
from tools.notion_hub.compliance_map import (
    get_all_controls_for_findings,
    ComplianceControl,
)
from tools.notion_hub.sync_status import SyncStatus
from tools.notion_hub.workspace_setup import (
    setup_workspace as do_setup_workspace,
    get_env_config_snippet,
    WorkspaceSetupResult,
)

logger = logging.getLogger(__name__)

HISTORY_DIR = ".optix/history"


@dataclass
class StepResult:
    """Result of a single sync step."""

    step: str
    success: bool
    message: str = ""
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class NotionHubResponse:
    """Response from hub operations."""

    success: bool
    action: str
    audit_id: str | None = None
    notion_page_url: str | None = None
    items_processed: int = 0
    errors: list[str] = field(default_factory=list)
    steps: list[StepResult] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "success": self.success,
            "action": self.action,
            "audit_id": self.audit_id,
            "notion_page_url": self.notion_page_url,
            "items_processed": self.items_processed,
            "errors": self.errors,
            "steps": [
                {
                    "step": s.step,
                    "success": s.success,
                    "message": s.message,
                    **s.data,
                }
                for s in self.steps
            ],
        }


class NotionHubTool:
    """MCP tool for Notion Security Intelligence Hub."""

    def __init__(self, config: NotionHubConfig | None = None) -> None:
        self.config = config or NotionHubConfig.from_env()
        self.client: NotionClient | None = None

        if self.config:
            self.client = NotionClient(self.config)

    def _ensure_configured(self) -> None:
        """Ensure the tool is properly configured."""
        if not self.config:
            raise ValueError(
                "Notion not configured. Set OPTIX_NOTION_API_KEY environment variable."
            )
        errors = self.config.validate()
        if errors:
            raise ValueError(f"Configuration errors: {', '.join(errors)}")

    def _get_latest_audit(self) -> tuple[str, dict[str, Any]] | None:
        """Get the most recent audit from history."""
        history_path = Path(HISTORY_DIR)
        if not history_path.exists():
            return None

        audit_dirs = sorted(
            [d for d in history_path.iterdir() if d.is_dir()],
            key=lambda d: d.name,
            reverse=True,
        )

        if not audit_dirs:
            return None

        latest = audit_dirs[0]
        return self._load_audit(latest.name)

    def _load_audit(self, audit_id: str) -> tuple[str, dict[str, Any]] | None:
        """Load audit data from history."""
        audit_path = Path(HISTORY_DIR) / audit_id

        if not audit_path.exists():
            return None

        audit_data: dict[str, Any] = {"id": audit_id}

        metadata_path = audit_path / "metadata.json"
        if metadata_path.exists():
            with open(metadata_path, "r", encoding="utf-8") as f:
                audit_data["metadata"] = json.load(f)

        findings_path = audit_path / "findings.json"
        if findings_path.exists():
            with open(findings_path, "r", encoding="utf-8") as f:
                audit_data["findings"] = json.load(f)
        else:
            audit_data["findings"] = []

        return audit_id, audit_data

    def _load_all_audits(self) -> list[dict[str, Any]]:
        """Load all audits from history."""
        history_path = Path(HISTORY_DIR)
        if not history_path.exists():
            return []

        audits = []
        for audit_dir in history_path.iterdir():
            if audit_dir.is_dir():
                result = self._load_audit(audit_dir.name)
                if result:
                    _, audit_data = result
                    audits.append(audit_data)

        return audits

    def publish_audit(
        self,
        audit_dir_name: str | None = None,
    ) -> NotionHubResponse:
        """Publish an audit report to Notion."""
        self._ensure_configured()

        if audit_dir_name:
            result = self._load_audit(audit_dir_name)
        else:
            result = self._get_latest_audit()

        if not result:
            return NotionHubResponse(
                success=False,
                action="publish_audit",
                errors=["No audit found to publish"],
            )

        audit_id, audit_data = result
        metadata = audit_data.get("metadata", {})
        findings = audit_data.get("findings", [])

        sync_status = SyncStatus.get_or_create(audit_id)
        sync_status.mark_in_progress()

        try:
            formatter = AuditFormatter(
                audit_type=metadata.get("audit_type", metadata.get("workflow_type", "security")),
                lens=metadata.get("lens", "comprehensive"),
                timestamp=metadata.get("timestamp", datetime.now().isoformat()),
                findings=findings,
                metadata=metadata,
            )

            properties = formatter.format_page_properties()
            properties["Optix Audit ID"] = {
                "rich_text": [{"text": {"content": audit_id}}]
            }

            content = formatter.format_page_content(detailed=True)

            if not self.client:
                raise ValueError("NotionClient not initialized")

            page = self.client.create_page(
                database_id=self.config.audit_database_id,
                properties=properties,
                children=content,
            )

            page_url = page.get("url", "")
            page_id = page.get("id", "")

            sync_status.mark_success(page_id=page_id, page_url=page_url)
            sync_status.add_completed_step("publish")

            logger.info(f"published_audit audit_id={audit_id} page_id={page_id}")

            return NotionHubResponse(
                success=True,
                action="publish_audit",
                audit_id=audit_id,
                notion_page_url=page_url,
                items_processed=len(findings),
            )

        except NotionAPIError as e:
            sync_status.mark_failed(str(e))
            logger.error(f"publish_failed audit_id={audit_id} error={e}")
            return NotionHubResponse(
                success=False,
                action="publish_audit",
                audit_id=audit_id,
                errors=[str(e)],
            )

    def sync_patterns(self) -> NotionHubResponse:
        """Sync vulnerability patterns to Knowledge Base."""
        self._ensure_configured()

        audits = self._load_all_audits()
        if not audits:
            return NotionHubResponse(
                success=False,
                action="sync_patterns",
                errors=["No audits found in history"],
            )

        extractor = PatternExtractor()
        extractor.process_multiple_audits(audits)

        if not extractor.patterns:
            return NotionHubResponse(
                success=True,
                action="sync_patterns",
                items_processed=0,
            )

        if not self.client:
            raise ValueError("NotionClient not initialized")

        try:
            existing = self.client.query_database(
                database_id=self.config.knowledge_database_id,
            )
            existing_patterns: dict[str, str] = {}
            for page in existing.get("results", []):
                title_prop = page.get("properties", {}).get("Title", {})
                title_arr = title_prop.get("title", [])
                if title_arr:
                    title = title_arr[0].get("plain_text", "")
                    existing_patterns[title.lower()] = page["id"]

            created = 0
            updated = 0

            for pattern in extractor.patterns.values():
                properties = pattern.to_notion_properties()
                pattern_key = pattern.pattern_name.lower()

                if pattern_key in existing_patterns:
                    page_id = existing_patterns[pattern_key]
                    self.client.update_page(page_id, properties)
                    updated += 1
                else:
                    self.client.create_page(
                        database_id=self.config.knowledge_database_id,
                        properties=properties,
                    )
                    created += 1

            logger.info(f"synced_patterns created={created} updated={updated}")

            return NotionHubResponse(
                success=True,
                action="sync_patterns",
                items_processed=created + updated,
                steps=[
                    StepResult(
                        step="patterns",
                        success=True,
                        data={"created": created, "updated": updated},
                    )
                ],
            )

        except NotionAPIError as e:
            logger.error(f"sync_patterns_failed error={e}")
            return NotionHubResponse(
                success=False,
                action="sync_patterns",
                errors=[str(e)],
            )

    def update_compliance(self) -> NotionHubResponse:
        """Update compliance control status based on findings."""
        self._ensure_configured()

        audits = self._load_all_audits()
        all_findings = []
        for audit in audits:
            all_findings.extend(audit.get("findings", []))

        if not all_findings:
            return NotionHubResponse(
                success=True,
                action="update_compliance",
                items_processed=0,
            )

        controls = get_all_controls_for_findings(all_findings)

        if not controls:
            return NotionHubResponse(
                success=True,
                action="update_compliance",
                items_processed=0,
            )

        if not self.client:
            raise ValueError("NotionClient not initialized")

        try:
            existing = self.client.query_database(
                database_id=self.config.compliance_database_id,
            )
            existing_controls: dict[str, str] = {}
            for page in existing.get("results", []):
                title_prop = page.get("properties", {}).get("Title", {})
                title_arr = title_prop.get("title", [])
                if title_arr:
                    title = title_arr[0].get("plain_text", "")
                    existing_controls[title.lower()] = page["id"]

            updated = 0
            created = 0

            for key, control in controls.items():
                related_findings = [
                    f for f in all_findings
                    if f.get("cwe_id", f.get("cwe", "")) in (control.related_cwes or [])
                    or any(
                        cwe in (control.related_cwes or [])
                        for cwe in self._get_cwes_for_finding(f)
                    )
                ]
                control.status = control.calculate_status(related_findings)

                control_title = f"{control.framework} {control.control_id}"
                properties = {
                    "Title": {"title": [{"text": {"content": control_title}}]},
                    "Framework": {"select": {"name": control.framework}},
                    "Control ID": {"rich_text": [{"text": {"content": control.control_id}}]},
                    "Description": {"rich_text": [{"text": {"content": control.description}}]},
                    "Status": {"select": {"name": control.status}},
                    "Last Review": {"date": {"start": datetime.now().strftime("%Y-%m-%d")}},
                }

                control_key = control_title.lower()
                if control_key in existing_controls:
                    page_id = existing_controls[control_key]
                    self.client.update_page(page_id, properties)
                    updated += 1
                else:
                    self.client.create_page(
                        database_id=self.config.compliance_database_id,
                        properties=properties,
                    )
                    created += 1

            logger.info(f"updated_compliance created={created} updated={updated}")

            return NotionHubResponse(
                success=True,
                action="update_compliance",
                items_processed=created + updated,
                steps=[
                    StepResult(
                        step="compliance",
                        success=True,
                        data={"created": created, "updated": updated},
                    )
                ],
            )

        except NotionAPIError as e:
            logger.error(f"update_compliance_failed error={e}")
            return NotionHubResponse(
                success=False,
                action="update_compliance",
                errors=[str(e)],
            )

    def _get_cwes_for_finding(self, finding: dict[str, Any]) -> list[str]:
        """Get CWE IDs for a finding based on its category."""
        from tools.notion_hub.compliance_map import get_cwes_for_category

        cwe_id = finding.get("cwe_id", finding.get("cwe", ""))
        if cwe_id:
            return [cwe_id]

        category = finding.get("category", "")
        if category:
            return get_cwes_for_category(category)

        return []

    def full_sync(
        self,
        audit_dir_name: str | None = None,
    ) -> NotionHubResponse:
        """Execute full sync: publish → patterns → compliance."""
        self._ensure_configured()

        response = NotionHubResponse(
            success=True,
            action="full_sync",
            audit_id=audit_dir_name,
        )

        publish_result = self.publish_audit(audit_dir_name)
        response.steps.append(
            StepResult(
                step="publish_audit",
                success=publish_result.success,
                message=publish_result.errors[0] if publish_result.errors else "",
                data={
                    "page_url": publish_result.notion_page_url,
                    "findings_count": publish_result.items_processed,
                },
            )
        )
        if publish_result.notion_page_url:
            response.notion_page_url = publish_result.notion_page_url
        if publish_result.audit_id:
            response.audit_id = publish_result.audit_id

        patterns_result = self.sync_patterns()
        response.steps.append(
            StepResult(
                step="sync_patterns",
                success=patterns_result.success,
                message=patterns_result.errors[0] if patterns_result.errors else "",
                data={"patterns_processed": patterns_result.items_processed},
            )
        )

        compliance_result = self.update_compliance()
        response.steps.append(
            StepResult(
                step="update_compliance",
                success=compliance_result.success,
                message=compliance_result.errors[0] if compliance_result.errors else "",
                data={"controls_processed": compliance_result.items_processed},
            )
        )

        response.success = all(step.success for step in response.steps)
        response.items_processed = sum(
            step.data.get("findings_count", 0) +
            step.data.get("patterns_processed", 0) +
            step.data.get("controls_processed", 0)
            for step in response.steps
        )

        if not response.success:
            response.errors = [
                step.message for step in response.steps
                if not step.success and step.message
            ]

        if response.audit_id:
            sync_status = SyncStatus.get_or_create(response.audit_id)
            if response.success:
                sync_status.mark_success(
                    page_url=response.notion_page_url,
                )
                sync_status.steps_completed = ["publish", "patterns", "compliance"]
                sync_status.save()
            else:
                sync_status.mark_failed("; ".join(response.errors))

        return response

    def setup_workspace(
        self,
        parent_page_id: str,
    ) -> NotionHubResponse:
        """Create the three databases for Notion Security Hub.

        This creates:
        - Optix Audit Reports (for published audits)
        - Optix Knowledge Base (for vulnerability patterns)
        - Optix Compliance Controls (for compliance tracking)

        Args:
            parent_page_id: ID of the Notion page where databases will be created.
                           Get this from the page URL: notion.so/workspace/<PAGE_ID>

        Returns:
            NotionHubResponse with database IDs and URLs
        """
        if not self.config or not self.config.api_key:
            return NotionHubResponse(
                success=False,
                action="setup_workspace",
                errors=["OPTIX_NOTION_API_KEY is required for setup"],
            )

        client = NotionClient(NotionConfig(api_key=self.config.api_key))

        try:
            result = do_setup_workspace(client, parent_page_id)

            if result.success:
                saved, config_path = NotionHubConfig.save_database_ids(
                    audit_db_id=result.audit_db_id or "",
                    knowledge_db_id=result.knowledge_db_id or "",
                    compliance_db_id=result.compliance_db_id or "",
                )

                config_message = (
                    f"Created 3 databases. Configuration saved to {config_path}"
                    if saved else
                    f"Created 3 databases. {config_path}"
                )

                return NotionHubResponse(
                    success=True,
                    action="setup_workspace",
                    items_processed=3,
                    steps=[
                        StepResult(
                            step="create_databases",
                            success=True,
                            message=config_message,
                            data={
                                "audit_db_id": result.audit_db_id,
                                "knowledge_db_id": result.knowledge_db_id,
                                "compliance_db_id": result.compliance_db_id,
                                "audit_db_url": result.audit_db_url,
                                "knowledge_db_url": result.knowledge_db_url,
                                "compliance_db_url": result.compliance_db_url,
                                "config_saved": saved,
                                "config_path": config_path if saved else None,
                            },
                        )
                    ],
                )
            else:
                return NotionHubResponse(
                    success=False,
                    action="setup_workspace",
                    errors=[result.error or "Unknown error"],
                )

        except NotionAPIError as e:
            logger.error(f"setup_workspace_failed error={e}")
            return NotionHubResponse(
                success=False,
                action="setup_workspace",
                errors=[str(e)],
            )


def notion_security_hub(
    action: str,
    audit_dir_name: str | None = None,
    parent_page_id: str | None = None,
) -> str:
    """MCP tool entry point for Notion Security Intelligence Hub.

    Args:
        action: Action to perform:
            - setup_workspace: Create databases (requires parent_page_id)
            - publish_audit: Publish audit to Notion
            - sync_patterns: Sync patterns to knowledge base
            - update_compliance: Update compliance controls
            - full_sync: Execute all sync actions
        audit_dir_name: Optional audit directory name to process
        parent_page_id: Required for setup_workspace - the Notion page ID
            where databases will be created

    Returns:
        JSON string with operation result
    """
    tool = NotionHubTool()

    if action == "setup_workspace":
        if not parent_page_id:
            return json.dumps({
                "success": False,
                "action": "setup_workspace",
                "error": "parent_page_id is required. Get it from your Notion page URL: "
                         "notion.so/workspace/<PAGE_ID>",
            })
        try:
            response = tool.setup_workspace(parent_page_id)
            return json.dumps(response.to_dict(), indent=2)
        except Exception as e:
            logger.error(f"setup_workspace_error error={e}")
            return json.dumps({
                "success": False,
                "action": "setup_workspace",
                "error": str(e),
            })

    actions = {
        "publish_audit": lambda: tool.publish_audit(audit_dir_name),
        "sync_patterns": lambda: tool.sync_patterns(),
        "update_compliance": lambda: tool.update_compliance(),
        "full_sync": lambda: tool.full_sync(audit_dir_name),
    }

    if action not in actions:
        valid_actions = ["setup_workspace"] + list(actions.keys())
        return json.dumps({
            "success": False,
            "error": f"Unknown action: {action}. Valid actions: {valid_actions}",
        })

    try:
        response = actions[action]()
        return json.dumps(response.to_dict(), indent=2)
    except ValueError as e:
        return json.dumps({
            "success": False,
            "action": action,
            "error": str(e),
        })
    except Exception as e:
        logger.error(f"notion_security_hub_error action={action} error={e}")
        return json.dumps({
            "success": False,
            "action": action,
            "error": f"Unexpected error: {e}",
        })
