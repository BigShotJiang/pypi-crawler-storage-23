"""Formatter for converting audit data to Notion blocks."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


SEVERITY_COLORS = {
    "critical": "red_background",
    "high": "orange_background",
    "medium": "yellow_background",
    "low": "green_background",
    "info": "blue_background",
}

SEVERITY_ICONS = {
    "critical": "\U0001F534",  # Red circle
    "high": "\U0001F7E0",  # Orange circle
    "medium": "\U0001F7E1",  # Yellow circle
    "low": "\U0001F7E2",  # Green circle
    "info": "\U0001F535",  # Blue circle
}

AUDIT_TYPE_CONFIG = {
    "security": {
        "icon": "\U0001F6E1\ufe0f",  # Shield
        "title_prefix": "Security Audit",
        "finding_label": "Vulnerability",
        "extra_fields": ["cwe_id", "owasp_category"],
    },
    "a11y": {
        "icon": "\u267f",  # Wheelchair symbol
        "title_prefix": "Accessibility Audit",
        "finding_label": "Accessibility Issue",
        "extra_fields": ["wcag_criterion", "wcag_level"],
    },
    "accessibility": {
        "icon": "\u267f",
        "title_prefix": "Accessibility Audit",
        "finding_label": "Accessibility Issue",
        "extra_fields": ["wcag_criterion", "wcag_level"],
    },
    "devops": {
        "icon": "\u2699\ufe0f",  # Gear
        "title_prefix": "DevOps Audit",
        "finding_label": "Infrastructure Issue",
        "extra_fields": ["pipeline", "artifact_type"],
    },
    "principal": {
        "icon": "\U0001F4CA",  # Bar chart
        "title_prefix": "Code Quality Audit",
        "finding_label": "Code Smell",
        "extra_fields": ["complexity_score", "coupling_metrics"],
    },
    "team_analytics": {
        "icon": "\U0001F465",  # People silhouette
        "title_prefix": "Team Analytics",
        "finding_label": "Metric",
        "extra_fields": ["author", "period"],
    },
}


@dataclass
class RichText:
    """Represents formatted text within blocks."""

    content: str
    bold: bool = False
    italic: bool = False
    code: bool = False
    color: str = "default"
    link: str | None = None

    def to_api_format(self) -> dict[str, Any]:
        """Convert to Notion API format."""
        text_obj: dict[str, Any] = {"content": self.content}

        if self.link:
            text_obj["link"] = {"url": self.link}

        result: dict[str, Any] = {"type": "text", "text": text_obj}

        annotations: dict[str, Any] = {}
        if self.bold:
            annotations["bold"] = True
        if self.italic:
            annotations["italic"] = True
        if self.code:
            annotations["code"] = True
        if self.color != "default":
            annotations["color"] = self.color

        if annotations:
            result["annotations"] = annotations

        return result


@dataclass
class NotionBlock:
    """Represents a Notion content block."""

    block_type: str
    content: dict[str, Any] = field(default_factory=dict)
    children: list[NotionBlock] = field(default_factory=list)

    def to_api_format(self) -> dict[str, Any]:
        """Convert to Notion API format."""
        result: dict[str, Any] = {
            "object": "block",
            "type": self.block_type,
            self.block_type: self.content,
        }

        if self.children:
            result[self.block_type]["children"] = [
                child.to_api_format() for child in self.children
            ]

        return result

    @classmethod
    def heading_1(cls, text: str) -> NotionBlock:
        """Create a heading_1 block."""
        return cls(
            block_type="heading_1",
            content={"rich_text": [RichText(text).to_api_format()]},
        )

    @classmethod
    def heading_2(cls, text: str) -> NotionBlock:
        """Create a heading_2 block."""
        return cls(
            block_type="heading_2",
            content={"rich_text": [RichText(text).to_api_format()]},
        )

    @classmethod
    def heading_3(cls, text: str) -> NotionBlock:
        """Create a heading_3 block."""
        return cls(
            block_type="heading_3",
            content={"rich_text": [RichText(text).to_api_format()]},
        )

    @classmethod
    def paragraph(cls, text: str, rich_texts: list[RichText] | None = None) -> NotionBlock:
        """Create a paragraph block."""
        if rich_texts:
            content = {"rich_text": [rt.to_api_format() for rt in rich_texts]}
        else:
            content = {"rich_text": [RichText(text).to_api_format()]}
        return cls(block_type="paragraph", content=content)

    @classmethod
    def code(cls, code: str, language: str = "plain text") -> NotionBlock:
        """Create a code block."""
        return cls(
            block_type="code",
            content={
                "rich_text": [RichText(code).to_api_format()],
                "language": language,
            },
        )

    @classmethod
    def callout(
        cls,
        text: str,
        icon: str = "\u2139\ufe0f",
        color: str = "gray_background",
    ) -> NotionBlock:
        """Create a callout block."""
        return cls(
            block_type="callout",
            content={
                "rich_text": [RichText(text).to_api_format()],
                "icon": {"type": "emoji", "emoji": icon},
                "color": color,
            },
        )

    @classmethod
    def bulleted_list_item(cls, text: str) -> NotionBlock:
        """Create a bulleted list item block."""
        return cls(
            block_type="bulleted_list_item",
            content={"rich_text": [RichText(text).to_api_format()]},
        )

    @classmethod
    def divider(cls) -> NotionBlock:
        """Create a divider block."""
        return cls(block_type="divider", content={})

    @classmethod
    def table(
        cls,
        rows: list[list[str]],
        has_column_header: bool = True,
        has_row_header: bool = False,
    ) -> NotionBlock:
        """Create a table block with rows."""
        if not rows:
            return cls(block_type="paragraph", content={"rich_text": []})

        table_width = len(rows[0]) if rows else 0

        table_rows = []
        for row in rows:
            cells = []
            for cell in row:
                cells.append([RichText(str(cell)).to_api_format()])
            table_rows.append(
                NotionBlock(
                    block_type="table_row",
                    content={"cells": cells},
                )
            )

        return cls(
            block_type="table",
            content={
                "table_width": table_width,
                "has_column_header": has_column_header,
                "has_row_header": has_row_header,
            },
            children=table_rows,
        )


@dataclass
class AuditFormatter:
    """Converts audit data to Notion blocks."""

    audit_type: str
    lens: str
    timestamp: str
    findings: list[dict[str, Any]]
    metadata: dict[str, Any] = field(default_factory=dict)

    def _count_by_severity(self) -> dict[str, int]:
        """Count findings by severity."""
        counts: dict[str, int] = {
            "critical": 0,
            "high": 0,
            "medium": 0,
            "low": 0,
            "info": 0,
        }
        for finding in self.findings:
            severity = finding.get("severity", "info").lower()
            if severity in counts:
                counts[severity] += 1
        return counts

    def _format_severity_summary(self) -> list[NotionBlock]:
        """Create severity summary callouts."""
        counts = self._count_by_severity()
        blocks = []

        for severity in ["critical", "high", "medium", "low", "info"]:
            count = counts.get(severity, 0)
            if count > 0:
                icon = SEVERITY_ICONS.get(severity, "\u2139\ufe0f")
                color = SEVERITY_COLORS.get(severity, "gray_background")
                text = f"{count} {severity.capitalize()} finding{'s' if count != 1 else ''}"
                blocks.append(NotionBlock.callout(text, icon, color))

        return blocks

    def _format_findings_table(self) -> NotionBlock:
        """Create findings summary table."""
        headers = ["Finding", "Severity", "File", "Line"]
        rows = [headers]

        for finding in self.findings[:50]:
            row = [
                finding.get("description", finding.get("category", "Unknown"))[:50],
                finding.get("severity", "info").capitalize(),
                finding.get("file", finding.get("affected_files", [""])[0] if finding.get("affected_files") else "")[:30],
                str(finding.get("line", finding.get("line_start", ""))),
            ]
            rows.append(row)

        return NotionBlock.table(rows)

    def _format_finding_detail(self, finding: dict[str, Any]) -> list[NotionBlock]:
        """Format a single finding with details."""
        blocks = []

        title = finding.get("description", finding.get("category", "Finding"))
        file_info = finding.get("file", "")
        line_info = finding.get("line", finding.get("line_start", ""))
        if file_info and line_info:
            title = f"{title} in {file_info}:{line_info}"
        elif file_info:
            title = f"{title} in {file_info}"

        blocks.append(NotionBlock.heading_3(title[:100]))

        severity = finding.get("severity", "info").lower()
        icon = SEVERITY_ICONS.get(severity, "\u2139\ufe0f")
        color = SEVERITY_COLORS.get(severity, "gray_background")
        blocks.append(NotionBlock.callout(f"Severity: {severity.capitalize()}", icon, color))

        if finding.get("description"):
            blocks.append(NotionBlock.paragraph(finding["description"]))

        code_snippet = finding.get("code_snippet", finding.get("affected_code", ""))
        if code_snippet:
            language = finding.get("language", "plain text")
            blocks.append(NotionBlock.code(code_snippet, language))

        remediation = finding.get("remediation", "")
        if remediation:
            blocks.append(NotionBlock.callout(f"Remediation: {remediation}", "\U0001F4A1", "blue_background"))

        return blocks

    def _group_findings_by_category(self) -> dict[str, list[dict[str, Any]]]:
        """Group findings by category."""
        grouped: dict[str, list[dict[str, Any]]] = {}
        for finding in self.findings:
            category = finding.get("category", "Other")
            if category not in grouped:
                grouped[category] = []
            grouped[category].append(finding)
        return grouped

    def _get_audit_config(self) -> dict[str, Any]:
        """Get configuration for this audit type."""
        audit_key = self.audit_type.lower().replace(" ", "_")
        return AUDIT_TYPE_CONFIG.get(audit_key, {
            "icon": "\U0001F50D",  # Magnifying glass
            "title_prefix": f"{self.audit_type.capitalize()} Audit",
            "finding_label": "Finding",
            "extra_fields": [],
        })

    def format_page_properties(self) -> dict[str, Any]:
        """Create page properties for database entry."""
        counts = self._count_by_severity()
        total = sum(counts.values())
        config = self._get_audit_config()

        date_str = self.timestamp
        if isinstance(self.timestamp, datetime):
            date_str = self.timestamp.strftime("%Y-%m-%d")
        elif "T" in str(self.timestamp):
            date_str = str(self.timestamp).split("T")[0]

        title = f"{config['title_prefix']} - {date_str}"

        return {
            "Title": {"title": [{"text": {"content": title}}]},
            "Audit Type": {"select": {"name": self.audit_type}},
            "Lens": {"select": {"name": self.lens}},
            "Date": {"date": {"start": date_str}},
            "Total Findings": {"number": total},
            "Critical": {"number": counts.get("critical", 0)},
            "High": {"number": counts.get("high", 0)},
            "Medium": {"number": counts.get("medium", 0)},
            "Low": {"number": counts.get("low", 0)},
        }

    def format_page_content(self, detailed: bool = True) -> list[dict[str, Any]]:
        """Create page content blocks."""
        blocks: list[NotionBlock] = []
        config = self._get_audit_config()

        blocks.append(NotionBlock.heading_1(f"{config['icon']} Executive Summary"))
        blocks.extend(self._format_severity_summary())
        blocks.append(NotionBlock.divider())

        blocks.append(NotionBlock.heading_1("Findings Overview"))
        blocks.append(self._format_findings_table())
        blocks.append(NotionBlock.divider())

        if detailed and self.findings:
            blocks.append(NotionBlock.heading_1("Detailed Findings"))

            grouped = self._group_findings_by_category()
            for category, category_findings in grouped.items():
                blocks.append(NotionBlock.heading_2(f"{category} ({len(category_findings)} findings)"))

                for finding in category_findings[:10]:
                    blocks.extend(self._format_finding_detail(finding))

                if len(category_findings) > 10:
                    blocks.append(
                        NotionBlock.paragraph(
                            f"... and {len(category_findings) - 10} more {category} findings"
                        )
                    )

        return [block.to_api_format() for block in blocks]
