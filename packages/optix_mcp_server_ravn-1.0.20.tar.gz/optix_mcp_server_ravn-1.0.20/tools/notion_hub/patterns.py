"""Pattern extraction and knowledge base management."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class PatternMatch:
    """Represents a matched vulnerability pattern."""

    pattern_name: str
    category: str
    cwe_id: str | None = None
    frequency: int = 1
    severity_distribution: dict[str, int] = field(default_factory=dict)
    related_audit_ids: list[str] = field(default_factory=list)
    remediation_template: str | None = None
    last_seen: datetime | None = None

    def to_notion_properties(
        self,
        audit_page_ids: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Convert to Notion page properties.

        Args:
            audit_page_ids: Mapping of audit_id -> Notion page_id for relations
        """
        properties: dict[str, Any] = {
            "Title": {"title": [{"text": {"content": self.pattern_name}}]},
            "Category": {"select": {"name": self.category}},
            "Frequency": {"number": self.frequency},
        }

        if self.cwe_id:
            properties["CWE ID"] = {"rich_text": [{"text": {"content": self.cwe_id}}]}

        if self.last_seen:
            date_str = self.last_seen.strftime("%Y-%m-%d")
            properties["Last Seen"] = {"date": {"start": date_str}}

        if self.severity_distribution:
            severity_text = ", ".join(
                f"{sev}: {count}" for sev, count in self.severity_distribution.items()
            )
            properties["Severity Distribution"] = {
                "rich_text": [{"text": {"content": severity_text}}]
            }

        if audit_page_ids and self.related_audit_ids:
            relation_ids = []
            for audit_id in self.related_audit_ids:
                if audit_id in audit_page_ids:
                    relation_ids.append({"id": audit_page_ids[audit_id]})
            if relation_ids:
                properties["Related Audits"] = {"relation": relation_ids}

        return properties

    def merge(self, other: PatternMatch) -> None:
        """Merge another pattern match into this one."""
        self.frequency += other.frequency

        for severity, count in other.severity_distribution.items():
            self.severity_distribution[severity] = (
                self.severity_distribution.get(severity, 0) + count
            )

        for audit_id in other.related_audit_ids:
            if audit_id not in self.related_audit_ids:
                self.related_audit_ids.append(audit_id)

        if other.remediation_template and not self.remediation_template:
            self.remediation_template = other.remediation_template

        if other.last_seen:
            if not self.last_seen or other.last_seen > self.last_seen:
                self.last_seen = other.last_seen


class PatternExtractor:
    """Extracts vulnerability patterns from audit findings."""

    def __init__(self) -> None:
        self.patterns: dict[str, PatternMatch] = {}

    def _normalize_pattern_name(self, finding: dict[str, Any]) -> str:
        """Generate a normalized pattern name from a finding."""
        category = finding.get("category", "Unknown")
        cwe_id = finding.get("cwe_id", finding.get("cwe", ""))

        if cwe_id:
            return f"{category} ({cwe_id})"
        return category

    def _get_pattern_key(self, finding: dict[str, Any]) -> str:
        """Generate a unique key for pattern matching."""
        cwe_id = finding.get("cwe_id", finding.get("cwe", ""))
        category = finding.get("category", "Unknown")

        if cwe_id:
            return cwe_id.upper()
        return category.lower().replace(" ", "_")

    def extract_from_finding(
        self,
        finding: dict[str, Any],
        audit_id: str,
    ) -> PatternMatch:
        """Extract a pattern from a single finding."""
        pattern_name = self._normalize_pattern_name(finding)
        category = finding.get("category", "Unknown")
        cwe_id = finding.get("cwe_id", finding.get("cwe"))
        severity = finding.get("severity", "info").lower()
        remediation = finding.get("remediation", "")

        return PatternMatch(
            pattern_name=pattern_name,
            category=category,
            cwe_id=cwe_id,
            frequency=1,
            severity_distribution={severity: 1},
            related_audit_ids=[audit_id],
            remediation_template=remediation if remediation else None,
            last_seen=datetime.now(),
        )

    def process_findings(
        self,
        findings: list[dict[str, Any]],
        audit_id: str,
    ) -> dict[str, PatternMatch]:
        """Process all findings from an audit and extract patterns."""
        for finding in findings:
            pattern = self.extract_from_finding(finding, audit_id)
            key = self._get_pattern_key(finding)

            if key in self.patterns:
                self.patterns[key].merge(pattern)
            else:
                self.patterns[key] = pattern

        return self.patterns

    def process_multiple_audits(
        self,
        audits: list[dict[str, Any]],
    ) -> dict[str, PatternMatch]:
        """Process findings from multiple audits."""
        for audit in audits:
            audit_id = audit.get("id", audit.get("audit_id", "unknown"))
            findings = audit.get("findings", [])
            self.process_findings(findings, audit_id)

        return self.patterns

    def get_top_patterns(self, limit: int = 10) -> list[PatternMatch]:
        """Get top patterns by frequency."""
        sorted_patterns = sorted(
            self.patterns.values(),
            key=lambda p: p.frequency,
            reverse=True,
        )
        return sorted_patterns[:limit]

    def get_patterns_by_severity(self, severity: str) -> list[PatternMatch]:
        """Get patterns that have findings of a specific severity."""
        result = []
        for pattern in self.patterns.values():
            if severity.lower() in pattern.severity_distribution:
                result.append(pattern)
        return sorted(result, key=lambda p: p.frequency, reverse=True)

    def clear(self) -> None:
        """Clear all extracted patterns."""
        self.patterns.clear()
