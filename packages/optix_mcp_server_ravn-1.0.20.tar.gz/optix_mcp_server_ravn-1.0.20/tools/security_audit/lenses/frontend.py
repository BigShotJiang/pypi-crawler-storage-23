"""Frontend Engineer lens for Security Audit.

Focuses on client-side security concerns from a senior frontend engineer's perspective:
- Cross-Site Scripting (XSS) vulnerabilities
- Cross-Site Request Forgery (CSRF) protection
- DOM manipulation security
- Client-side storage security
- Third-party script risks
"""

from tools.security_audit.domains import SecurityLens, SecurityStepDomain
from tools.security_audit.lenses.base import BaseLens, LensConfig, LensRule


class FrontendLens(BaseLens):
    """Frontend Engineer security perspective.

    Examines code from the viewpoint of a senior frontend engineer
    concerned with client-side security, XSS prevention, and secure data handling.
    """

    @property
    def lens_type(self) -> SecurityLens:
        return SecurityLens.FRONTEND

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=SecurityLens.FRONTEND,
            display_name="Frontend Engineer",
            description="Client-side security: XSS, CSRF, DOM security, client storage, JS bundles",
            reconnaissance_rules=[
                LensRule(
                    id="FE-R001",
                    domain=SecurityStepDomain.RECONNAISSANCE,
                    name="Frontend Framework Detection",
                    description="Identify frontend framework and rendering patterns",
                    severity_default="info",
                    check_guidance=[
                        "Identify frontend framework (React, Vue, Angular, etc.)",
                        "Determine rendering mode (CSR, SSR, SSG)",
                        "Map component structure and data flow",
                        "Identify third-party libraries and CDN usage",
                    ],
                ),
                LensRule(
                    id="FE-R002",
                    domain=SecurityStepDomain.RECONNAISSANCE,
                    name="Client-Side Data Flow",
                    description="Map data flow in the frontend application",
                    severity_default="info",
                    check_guidance=[
                        "Trace user input through components",
                        "Identify state management patterns",
                        "Map API communication points",
                    ],
                ),
            ],
            auth_rules=[
                LensRule(
                    id="FE-A001",
                    domain=SecurityStepDomain.AUTH_AUTHZ,
                    name="Token Storage Security",
                    description="Review client-side token storage practices",
                    severity_default="high",
                    check_guidance=[
                        "Check if tokens are stored in localStorage (vulnerable to XSS)",
                        "Verify httpOnly cookie usage for sensitive tokens",
                        "Review token refresh mechanisms",
                        "Check for tokens in URL parameters",
                    ],
                ),
                LensRule(
                    id="FE-A002",
                    domain=SecurityStepDomain.AUTH_AUTHZ,
                    name="Client-Side Auth Checks",
                    description="Review client-side authorization implementations",
                    severity_default="medium",
                    check_guidance=[
                        "Verify that client-side auth is backed by server validation",
                        "Check for sensitive data exposed in client bundles",
                        "Review route protection implementations",
                    ],
                ),
            ],
            input_rules=[
                LensRule(
                    id="FE-I001",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="Reflected XSS",
                    description="Detect reflected XSS vulnerabilities",
                    severity_default="critical",
                    check_guidance=[
                        "Check URL parameter handling and rendering",
                        "Review search functionality for reflection",
                        "Verify query string sanitization",
                    ],
                ),
                LensRule(
                    id="FE-I002",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="Stored XSS",
                    description="Detect stored XSS vulnerabilities",
                    severity_default="critical",
                    check_guidance=[
                        "Review user-generated content rendering",
                        "Check for dangerouslySetInnerHTML/v-html usage",
                        "Verify sanitization of stored content before display",
                    ],
                ),
                LensRule(
                    id="FE-I003",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="DOM-based XSS",
                    description="Detect DOM-based XSS vulnerabilities",
                    severity_default="critical",
                    check_guidance=[
                        "Search for document.write, innerHTML, eval usage",
                        "Check for jQuery html() with user input",
                        "Review dynamic script/style injection",
                        "Check location.hash and location.search handling",
                    ],
                ),
                LensRule(
                    id="FE-I004",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="Client-Side Validation Bypass",
                    description="Check for reliance on client-side only validation",
                    severity_default="medium",
                    check_guidance=[
                        "Verify server-side validation for all inputs",
                        "Check if validation can be bypassed via dev tools",
                        "Review form submission handling",
                    ],
                ),
            ],
            owasp_rules=[
                LensRule(
                    id="FE-O001",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="CSRF Protection",
                    description="Verify CSRF protection mechanisms",
                    severity_default="high",
                    check_guidance=[
                        "Check for CSRF token implementation",
                        "Verify SameSite cookie attributes",
                        "Review state-changing request protections",
                    ],
                ),
                LensRule(
                    id="FE-O002",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="Sensitive Data Exposure",
                    description="Check for sensitive data in client bundles",
                    severity_default="high",
                    check_guidance=[
                        "Search for API keys in JavaScript bundles",
                        "Check for hardcoded credentials",
                        "Review environment variable usage in client code",
                        "Check for sensitive data in console.log statements",
                    ],
                ),
                LensRule(
                    id="FE-O003",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="Clickjacking Protection",
                    description="Verify clickjacking protections",
                    severity_default="medium",
                    check_guidance=[
                        "Check for X-Frame-Options or CSP frame-ancestors",
                        "Review iframe usage and sandboxing",
                    ],
                ),
            ],
            dependency_rules=[
                LensRule(
                    id="FE-D001",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Frontend Dependency Vulnerabilities",
                    description="Check frontend dependencies for known CVEs",
                    severity_default="high",
                    check_guidance=[
                        "Review npm/yarn dependencies for vulnerabilities",
                        "Check for outdated frontend packages",
                        "Verify CDN-loaded libraries versions",
                    ],
                ),
                LensRule(
                    id="FE-D002",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Third-Party Script Security",
                    description="Review third-party script inclusions",
                    severity_default="medium",
                    check_guidance=[
                        "Audit third-party scripts and analytics",
                        "Check for Subresource Integrity (SRI) usage",
                        "Review postMessage handlers for origin validation",
                    ],
                ),
            ],
            compliance_rules=[
                LensRule(
                    id="FE-C001",
                    domain=SecurityStepDomain.COMPLIANCE,
                    name="Client-Side Data Handling",
                    description="Review client-side data protection",
                    severity_default="medium",
                    check_guidance=[
                        "Check for PII in browser storage",
                        "Verify consent mechanisms",
                        "Review data exposure in error messages",
                    ],
                ),
            ],
        )
