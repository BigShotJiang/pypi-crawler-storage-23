"""Backend Engineer lens for Security Audit.

Focuses on server-side security concerns from a senior backend engineer's perspective:
- SQL/NoSQL injection vulnerabilities
- Authentication and authorization flaws
- API security issues
- Business logic vulnerabilities
- Server-side request forgery
"""

from tools.security_audit.domains import SecurityLens, SecurityStepDomain
from tools.security_audit.lenses.base import BaseLens, LensConfig, LensRule


class BackendLens(BaseLens):
    """Backend Engineer security perspective.

    Examines code from the viewpoint of a senior backend engineer
    concerned with server-side security, data protection, and API hardening.
    """

    @property
    def lens_type(self) -> SecurityLens:
        return SecurityLens.BACKEND

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=SecurityLens.BACKEND,
            display_name="Backend Engineer",
            description="Server-side security: SQL injection, auth flaws, API security, business logic",
            reconnaissance_rules=[
                LensRule(
                    id="BE-R001",
                    domain=SecurityStepDomain.RECONNAISSANCE,
                    name="Backend Architecture Mapping",
                    description="Identify backend frameworks, ORMs, and data flow patterns",
                    severity_default="info",
                    check_guidance=[
                        "Identify backend framework (Express, Django, Spring, etc.)",
                        "Map database connections and ORM usage",
                        "Document API endpoints and their handlers",
                        "Identify data validation layers",
                    ],
                ),
                LensRule(
                    id="BE-R002",
                    domain=SecurityStepDomain.RECONNAISSANCE,
                    name="Data Flow Analysis",
                    description="Trace data flow from input to storage",
                    severity_default="info",
                    check_guidance=[
                        "Trace user input from request to database",
                        "Identify all database write operations",
                        "Map file upload and processing paths",
                    ],
                ),
            ],
            auth_rules=[
                LensRule(
                    id="BE-A001",
                    domain=SecurityStepDomain.AUTH_AUTHZ,
                    name="Authentication Bypass",
                    description="Check for authentication bypass vulnerabilities",
                    severity_default="critical",
                    check_guidance=[
                        "Review authentication middleware implementation",
                        "Check for routes missing authentication",
                        "Verify JWT/session validation on all protected endpoints",
                        "Look for hardcoded credentials or backdoors",
                    ],
                ),
                LensRule(
                    id="BE-A002",
                    domain=SecurityStepDomain.AUTH_AUTHZ,
                    name="Authorization Flaws",
                    description="Check for authorization and privilege escalation issues",
                    severity_default="critical",
                    check_guidance=[
                        "Verify role-based access control implementation",
                        "Check for IDOR (Insecure Direct Object References)",
                        "Test horizontal privilege escalation paths",
                        "Review admin endpoint protection",
                    ],
                ),
                LensRule(
                    id="BE-A003",
                    domain=SecurityStepDomain.AUTH_AUTHZ,
                    name="Session Management",
                    description="Review session handling security",
                    severity_default="high",
                    check_guidance=[
                        "Check session token generation (entropy, predictability)",
                        "Verify session expiration and invalidation",
                        "Review session fixation protections",
                        "Check for session data exposure",
                    ],
                ),
            ],
            input_rules=[
                LensRule(
                    id="BE-I001",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="SQL Injection",
                    description="Detect SQL injection vulnerabilities",
                    severity_default="critical",
                    check_guidance=[
                        "Search for raw SQL queries with string concatenation",
                        "Verify parameterized queries are used consistently",
                        "Check ORM usage for raw query methods",
                        "Review stored procedures for injection points",
                    ],
                ),
                LensRule(
                    id="BE-I002",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="NoSQL Injection",
                    description="Detect NoSQL injection vulnerabilities",
                    severity_default="critical",
                    check_guidance=[
                        "Check MongoDB query construction",
                        "Look for $where clauses with user input",
                        "Review operator injection possibilities",
                    ],
                ),
                LensRule(
                    id="BE-I003",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="Command Injection",
                    description="Detect OS command injection vulnerabilities",
                    severity_default="critical",
                    check_guidance=[
                        "Search for exec, spawn, system calls with user input",
                        "Check shell command construction",
                        "Review file path manipulation",
                    ],
                ),
                LensRule(
                    id="BE-I004",
                    domain=SecurityStepDomain.INPUT_VALIDATION,
                    name="Server-Side Request Forgery",
                    description="Detect SSRF vulnerabilities",
                    severity_default="high",
                    check_guidance=[
                        "Find URL fetching functions with user-controlled URLs",
                        "Check for internal network access restrictions",
                        "Review webhook implementations",
                    ],
                ),
            ],
            owasp_rules=[
                LensRule(
                    id="BE-O001",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="Broken Access Control (A01)",
                    description="OWASP A01 - Broken Access Control",
                    severity_default="critical",
                    check_guidance=[
                        "Verify access control on all API endpoints",
                        "Check for missing function-level access control",
                        "Review metadata manipulation possibilities",
                    ],
                ),
                LensRule(
                    id="BE-O002",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="Cryptographic Failures (A02)",
                    description="OWASP A02 - Cryptographic Failures",
                    severity_default="high",
                    check_guidance=[
                        "Review password hashing algorithms",
                        "Check for weak encryption methods",
                        "Verify TLS configuration",
                        "Check for sensitive data in logs",
                    ],
                ),
                LensRule(
                    id="BE-O003",
                    domain=SecurityStepDomain.OWASP_TOP_10,
                    name="Insecure Design (A04)",
                    description="OWASP A04 - Insecure Design patterns",
                    severity_default="medium",
                    check_guidance=[
                        "Review business logic for abuse scenarios",
                        "Check rate limiting implementation",
                        "Verify transaction handling integrity",
                    ],
                ),
            ],
            dependency_rules=[
                LensRule(
                    id="BE-D001",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Backend Dependency Vulnerabilities",
                    description="Check backend dependencies for known CVEs",
                    severity_default="high",
                    check_guidance=[
                        "Review package.json/requirements.txt/pom.xml for outdated packages",
                        "Check for dependencies with known CVEs",
                        "Verify lockfile presence and usage",
                    ],
                ),
                LensRule(
                    id="BE-D002",
                    domain=SecurityStepDomain.DEPENDENCIES,
                    name="Database Configuration",
                    description="Review database security configuration",
                    severity_default="high",
                    check_guidance=[
                        "Check database connection security",
                        "Verify credentials are not hardcoded",
                        "Review database user privileges",
                    ],
                ),
            ],
            compliance_rules=[
                LensRule(
                    id="BE-C001",
                    domain=SecurityStepDomain.COMPLIANCE,
                    name="Data Protection",
                    description="Verify data protection practices",
                    severity_default="high",
                    check_guidance=[
                        "Review data encryption at rest",
                        "Check backup security",
                        "Verify data retention policies in code",
                    ],
                ),
            ],
        )
