"""Slack notification service for audit findings."""

import json
import logging
import time
import urllib.request
from typing import Any

from config.defaults import SlackConfig
from tools.slack.formatter import SlackMessageFormatter

logger = logging.getLogger(__name__)


class SlackNotifier:
    """Send audit findings to Slack channels."""

    SLACK_API_URL = "https://slack.com/api/chat.postMessage"

    def __init__(self, config: SlackConfig):
        self._config = config
        self._last_send_time: float = 0.0

    def is_enabled(self) -> bool:
        """Check if Slack is properly configured and enabled."""
        return (
            self._config.enabled
            and bool(self._config.bot_token)
            and bool(self._config.channel_id)
        )

    def notify(
        self,
        tool_name: str,
        consolidated: Any,
        lens: str | None
    ) -> bool:
        """Send audit notification to Slack.

        Args:
            tool_name: Audit tool name (e.g., "security_audit")
            consolidated: ConsolidatedFindings object with issues_found list
            lens: Audit lens used (e.g., "backend", "comprehensive")

        Returns:
            True if notification sent successfully, False otherwise
        """
        if not self.is_enabled():
            logger.debug("Slack notifications disabled or not configured")
            return False

        if not consolidated or not hasattr(consolidated, "issues_found"):
            logger.debug("No findings to send to Slack")
            return False

        filtered_findings = self._filter_by_severity(consolidated.issues_found)

        if not filtered_findings:
            logger.debug("No findings matching severity filter")
            return False

        findings_by_severity = self._group_by_severity(filtered_findings)
        severity_counts = {
            severity: len(findings)
            for severity, findings in findings_by_severity.items()
        }

        files_examined = len(getattr(consolidated, "files_examined", []))

        payload = SlackMessageFormatter.format_audit_notification(
            tool_name=tool_name,
            findings_by_severity=findings_by_severity,
            severity_counts=severity_counts,
            total_findings=len(filtered_findings),
            files_examined=files_examined,
            lens=lens,
        )

        payload["channel"] = self._config.channel_id

        return self._send_to_slack(payload)

    def _filter_by_severity(self, findings: list[dict]) -> list[dict]:
        """Filter findings by configured severity levels."""
        return [
            f for f in findings
            if f.get("severity", "").lower() in self._config.severity_filter
        ]

    def _group_by_severity(self, findings: list[dict]) -> dict[str, list[dict]]:
        """Group findings by severity level."""
        groups: dict[str, list[dict]] = {}
        for finding in findings:
            severity = finding.get("severity", "").lower()
            if severity not in groups:
                groups[severity] = []
            groups[severity].append(finding)
        return groups

    def _send_to_slack(self, payload: dict) -> bool:
        """Send payload to Slack API with rate limiting and retry logic."""
        self._apply_rate_limit()

        try:
            return self._post_message(payload)
        except Exception as e:
            logger.error(f"Slack notification failed: error={e}")
            return False

    def _apply_rate_limit(self) -> None:
        """Enforce 1-second minimum gap between messages."""
        if self._last_send_time > 0:
            elapsed = time.time() - self._last_send_time
            if elapsed < 1.0:
                time.sleep(1.0 - elapsed)

    def _post_message(self, payload: dict) -> bool:
        """Post message to Slack API with retry on 429."""
        headers = {
            "Content-Type": "application/json; charset=utf-8",
            "Authorization": f"Bearer {self._config.bot_token}",
        }

        data = json.dumps(payload).encode("utf-8")
        request = urllib.request.Request(
            self.SLACK_API_URL,
            data=data,
            headers=headers,
            method="POST"
        )

        try:
            with urllib.request.urlopen(request, timeout=10) as response:
                self._last_send_time = time.time()
                response_data = json.loads(response.read().decode("utf-8"))

                if not response_data.get("ok"):
                    error = response_data.get("error", "unknown")
                    logger.error(f"Slack API error: error={error}")
                    return False

                logger.debug("Slack notification sent successfully")
                return True

        except urllib.error.HTTPError as e:
            if e.code == 429:
                return self._retry_after_rate_limit(e, payload)

            logger.error(f"Slack HTTP error: status={e.code}")
            return False

        except Exception as e:
            logger.error(f"Slack request failed: error={e}")
            return False

    def _retry_after_rate_limit(
        self,
        error: urllib.error.HTTPError,
        payload: dict
    ) -> bool:
        """Retry request after rate limit with Retry-After header."""
        retry_after = int(error.headers.get("Retry-After", 1))
        logger.debug(f"Rate limited, retrying after {retry_after}s")

        time.sleep(retry_after)

        try:
            headers = {
                "Content-Type": "application/json; charset=utf-8",
                "Authorization": f"Bearer {self._config.bot_token}",
            }
            data = json.dumps(payload).encode("utf-8")
            request = urllib.request.Request(
                self.SLACK_API_URL,
                data=data,
                headers=headers,
                method="POST"
            )

            with urllib.request.urlopen(request, timeout=10) as response:
                self._last_send_time = time.time()
                response_data = json.loads(response.read().decode("utf-8"))

                if not response_data.get("ok"):
                    error_msg = response_data.get("error", "unknown")
                    logger.error(f"Slack API error on retry: error={error_msg}")
                    return False

                logger.debug("Slack notification sent after retry")
                return True

        except Exception as e:
            logger.error(f"Slack retry failed: error={e}")
            return False
