"""Unit tests for NotionConfig and NotionHubConfig."""

import os
import pytest
from unittest.mock import patch

from tools.notion_hub.config import NotionConfig, NotionHubConfig


class TestNotionConfig:
    """Tests for NotionConfig."""

    def test_from_env_with_valid_key(self) -> None:
        """Test creating config from environment with valid API key."""
        with patch.dict(os.environ, {"OPTIX_NOTION_API_KEY": "ntn_test123"}):
            config = NotionConfig.from_env()
            assert config is not None
            assert config.api_key == "ntn_test123"

    def test_from_env_without_key(self) -> None:
        """Test creating config from environment without API key."""
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("OPTIX_NOTION_API_KEY", None)
            config = NotionConfig.from_env()
            assert config is None

    def test_is_configured_true(self) -> None:
        """Test is_configured returns True when key is set."""
        with patch.dict(os.environ, {"OPTIX_NOTION_API_KEY": "ntn_test123"}):
            assert NotionConfig.is_configured() is True

    def test_is_configured_false(self) -> None:
        """Test is_configured returns False when key is not set."""
        with patch.dict(os.environ, {}, clear=True):
            os.environ.pop("OPTIX_NOTION_API_KEY", None)
            assert NotionConfig.is_configured() is False

    def test_validate_valid_ntn_key(self) -> None:
        """Test validation passes for ntn_ prefixed key."""
        config = NotionConfig(api_key="ntn_abc123")
        errors = config.validate()
        assert errors == []

    def test_validate_valid_secret_key(self) -> None:
        """Test validation passes for secret_ prefixed key."""
        config = NotionConfig(api_key="secret_abc123")
        errors = config.validate()
        assert errors == []

    def test_validate_empty_key(self) -> None:
        """Test validation fails for empty key."""
        config = NotionConfig(api_key="")
        errors = config.validate()
        assert len(errors) == 1
        assert "required" in errors[0].lower()

    def test_validate_invalid_prefix(self) -> None:
        """Test validation warns for invalid prefix."""
        config = NotionConfig(api_key="invalid_key_format")
        errors = config.validate()
        assert len(errors) == 1
        assert "ntn_" in errors[0] or "secret_" in errors[0]


class TestNotionHubConfig:
    """Tests for NotionHubConfig."""

    def test_from_env_with_all_values(self) -> None:
        """Test creating hub config from environment with all values."""
        env = {
            "OPTIX_NOTION_API_KEY": "ntn_test123",
            "OPTIX_NOTION_AUDIT_DB_ID": "a" * 32,
            "OPTIX_NOTION_KNOWLEDGE_DB_ID": "b" * 32,
            "OPTIX_NOTION_COMPLIANCE_DB_ID": "c" * 32,
        }
        with patch.dict(os.environ, env):
            config = NotionHubConfig.from_env()
            assert config is not None
            assert config.api_key == "ntn_test123"
            assert config.audit_database_id == "a" * 32
            assert config.knowledge_database_id == "b" * 32
            assert config.compliance_database_id == "c" * 32

    def test_from_env_without_api_key(self) -> None:
        """Test creating hub config without API key returns None."""
        env = {
            "OPTIX_NOTION_AUDIT_DB_ID": "a" * 32,
            "OPTIX_NOTION_KNOWLEDGE_DB_ID": "b" * 32,
            "OPTIX_NOTION_COMPLIANCE_DB_ID": "c" * 32,
        }
        with patch.dict(os.environ, env, clear=True):
            os.environ.pop("OPTIX_NOTION_API_KEY", None)
            config = NotionHubConfig.from_env()
            assert config is None

    def test_is_hub_configured_true(self) -> None:
        """Test is_hub_configured returns True when all values are set."""
        env = {
            "OPTIX_NOTION_API_KEY": "ntn_test123",
            "OPTIX_NOTION_AUDIT_DB_ID": "a" * 32,
            "OPTIX_NOTION_KNOWLEDGE_DB_ID": "b" * 32,
            "OPTIX_NOTION_COMPLIANCE_DB_ID": "c" * 32,
        }
        with patch.dict(os.environ, env):
            assert NotionHubConfig.is_hub_configured() is True

    def test_is_hub_configured_false_missing_db(self) -> None:
        """Test is_hub_configured returns False when DB ID is missing."""
        env = {
            "OPTIX_NOTION_API_KEY": "ntn_test123",
            "OPTIX_NOTION_AUDIT_DB_ID": "a" * 32,
        }
        with patch.dict(os.environ, env, clear=True):
            os.environ.pop("OPTIX_NOTION_KNOWLEDGE_DB_ID", None)
            os.environ.pop("OPTIX_NOTION_COMPLIANCE_DB_ID", None)
            assert NotionHubConfig.is_hub_configured() is False

    def test_validate_all_valid(self) -> None:
        """Test validation passes for valid config."""
        config = NotionHubConfig(
            api_key="ntn_test123",
            audit_database_id="a" * 32,
            knowledge_database_id="b" * 32,
            compliance_database_id="c" * 32,
        )
        errors = config.validate()
        assert errors == []

    def test_validate_with_dashes_in_uuid(self) -> None:
        """Test validation passes for UUID with dashes."""
        config = NotionHubConfig(
            api_key="ntn_test123",
            audit_database_id="12345678-1234-1234-1234-123456789abc",
            knowledge_database_id="b" * 32,
            compliance_database_id="c" * 32,
        )
        errors = config.validate()
        assert errors == []

    def test_validate_missing_audit_db(self) -> None:
        """Test validation fails for missing audit DB ID."""
        config = NotionHubConfig(
            api_key="ntn_test123",
            audit_database_id="",
            knowledge_database_id="b" * 32,
            compliance_database_id="c" * 32,
        )
        errors = config.validate()
        assert any("AUDIT_DB_ID" in e for e in errors)

    def test_validate_invalid_db_id_format(self) -> None:
        """Test validation fails for invalid DB ID format."""
        config = NotionHubConfig(
            api_key="ntn_test123",
            audit_database_id="invalid",
            knowledge_database_id="b" * 32,
            compliance_database_id="c" * 32,
        )
        errors = config.validate()
        assert any("valid Notion database ID" in e for e in errors)
