"""Unit tests for NotionBlock, RichText, and AuditFormatter."""

import pytest
from datetime import datetime

from tools.notion_hub.formatter import (
    RichText,
    NotionBlock,
    AuditFormatter,
    SEVERITY_COLORS,
    SEVERITY_ICONS,
)


class TestRichText:
    """Tests for RichText."""

    def test_basic_text(self) -> None:
        """Test basic text conversion."""
        rt = RichText(content="Hello World")
        result = rt.to_api_format()

        assert result["type"] == "text"
        assert result["text"]["content"] == "Hello World"
        assert "annotations" not in result

    def test_text_with_bold(self) -> None:
        """Test bold text."""
        rt = RichText(content="Bold", bold=True)
        result = rt.to_api_format()

        assert result["annotations"]["bold"] is True

    def test_text_with_link(self) -> None:
        """Test text with link."""
        rt = RichText(content="Click here", link="https://example.com")
        result = rt.to_api_format()

        assert result["text"]["link"]["url"] == "https://example.com"

    def test_text_with_multiple_annotations(self) -> None:
        """Test text with multiple annotations."""
        rt = RichText(content="Code", bold=True, code=True, color="red")
        result = rt.to_api_format()

        assert result["annotations"]["bold"] is True
        assert result["annotations"]["code"] is True
        assert result["annotations"]["color"] == "red"


class TestNotionBlock:
    """Tests for NotionBlock."""

    def test_heading_1(self) -> None:
        """Test heading_1 block creation."""
        block = NotionBlock.heading_1("Title")
        result = block.to_api_format()

        assert result["type"] == "heading_1"
        assert result["heading_1"]["rich_text"][0]["text"]["content"] == "Title"

    def test_heading_2(self) -> None:
        """Test heading_2 block creation."""
        block = NotionBlock.heading_2("Subtitle")
        result = block.to_api_format()

        assert result["type"] == "heading_2"

    def test_paragraph(self) -> None:
        """Test paragraph block creation."""
        block = NotionBlock.paragraph("Some text")
        result = block.to_api_format()

        assert result["type"] == "paragraph"
        assert result["paragraph"]["rich_text"][0]["text"]["content"] == "Some text"

    def test_code_block(self) -> None:
        """Test code block creation."""
        block = NotionBlock.code("print('hello')", language="python")
        result = block.to_api_format()

        assert result["type"] == "code"
        assert result["code"]["language"] == "python"
        assert result["code"]["rich_text"][0]["text"]["content"] == "print('hello')"

    def test_callout(self) -> None:
        """Test callout block creation."""
        block = NotionBlock.callout("Warning!", icon="\u26a0\ufe0f", color="yellow_background")
        result = block.to_api_format()

        assert result["type"] == "callout"
        assert result["callout"]["icon"]["emoji"] == "\u26a0\ufe0f"
        assert result["callout"]["color"] == "yellow_background"

    def test_bulleted_list_item(self) -> None:
        """Test bulleted list item creation."""
        block = NotionBlock.bulleted_list_item("List item")
        result = block.to_api_format()

        assert result["type"] == "bulleted_list_item"

    def test_divider(self) -> None:
        """Test divider block creation."""
        block = NotionBlock.divider()
        result = block.to_api_format()

        assert result["type"] == "divider"

    def test_table(self) -> None:
        """Test table block creation."""
        rows = [
            ["Name", "Age"],
            ["Alice", "30"],
            ["Bob", "25"],
        ]
        block = NotionBlock.table(rows)
        result = block.to_api_format()

        assert result["type"] == "table"
        assert result["table"]["table_width"] == 2
        assert result["table"]["has_column_header"] is True

    def test_table_with_children(self) -> None:
        """Test table has children blocks."""
        rows = [["A", "B"], ["1", "2"]]
        block = NotionBlock.table(rows)

        assert len(block.children) == 2
        assert block.children[0].block_type == "table_row"


class TestAuditFormatter:
    """Tests for AuditFormatter."""

    @pytest.fixture
    def sample_findings(self) -> list:
        """Create sample findings for testing."""
        return [
            {
                "description": "SQL Injection vulnerability",
                "category": "Injection",
                "severity": "critical",
                "file": "auth/login.py",
                "line": 45,
                "cwe_id": "CWE-89",
                "remediation": "Use parameterized queries",
            },
            {
                "description": "XSS in template",
                "category": "XSS",
                "severity": "high",
                "file": "templates/profile.html",
                "line": 23,
                "cwe_id": "CWE-79",
            },
            {
                "description": "Missing CSRF token",
                "category": "CSRF",
                "severity": "medium",
                "file": "forms/submit.py",
                "line": 10,
            },
        ]

    @pytest.fixture
    def formatter(self, sample_findings: list) -> AuditFormatter:
        """Create an AuditFormatter for testing."""
        return AuditFormatter(
            audit_type="security",
            lens="comprehensive",
            timestamp="2026-02-25",
            findings=sample_findings,
        )

    def test_count_by_severity(self, formatter: AuditFormatter) -> None:
        """Test severity counting."""
        counts = formatter._count_by_severity()

        assert counts["critical"] == 1
        assert counts["high"] == 1
        assert counts["medium"] == 1
        assert counts["low"] == 0
        assert counts["info"] == 0

    def test_format_page_properties(self, formatter: AuditFormatter) -> None:
        """Test page properties formatting."""
        props = formatter.format_page_properties()

        assert "Title" in props
        assert props["Title"]["title"][0]["text"]["content"] == "Security Audit - 2026-02-25"
        assert props["Audit Type"]["select"]["name"] == "security"
        assert props["Lens"]["select"]["name"] == "comprehensive"
        assert props["Total Findings"]["number"] == 3
        assert props["Critical"]["number"] == 1
        assert props["High"]["number"] == 1
        assert props["Medium"]["number"] == 1

    def test_format_page_content(self, formatter: AuditFormatter) -> None:
        """Test page content formatting."""
        content = formatter.format_page_content()

        assert len(content) > 0
        assert any(
            block.get("type") == "heading_1"
            for block in content
        )

    def test_format_severity_summary(self, formatter: AuditFormatter) -> None:
        """Test severity summary callouts."""
        summary = formatter._format_severity_summary()

        assert len(summary) == 3
        assert all(block.block_type == "callout" for block in summary)

    def test_format_findings_table(self, formatter: AuditFormatter) -> None:
        """Test findings table formatting."""
        table = formatter._format_findings_table()

        assert table.block_type == "table"
        assert len(table.children) == 4

    def test_group_findings_by_category(self, formatter: AuditFormatter) -> None:
        """Test findings grouping by category."""
        grouped = formatter._group_findings_by_category()

        assert "Injection" in grouped
        assert "XSS" in grouped
        assert "CSRF" in grouped
        assert len(grouped["Injection"]) == 1

    def test_format_finding_detail(self, formatter: AuditFormatter, sample_findings: list) -> None:
        """Test individual finding formatting."""
        finding = sample_findings[0]
        blocks = formatter._format_finding_detail(finding)

        assert len(blocks) > 0
        assert any(
            block.block_type == "heading_3"
            for block in blocks
        )
        assert any(
            block.block_type == "callout"
            for block in blocks
        )

    def test_severity_colors_defined(self) -> None:
        """Test all severity colors are defined."""
        for severity in ["critical", "high", "medium", "low", "info"]:
            assert severity in SEVERITY_COLORS
            assert severity in SEVERITY_ICONS
