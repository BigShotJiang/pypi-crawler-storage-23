"""Unit tests for CWE to Compliance mapping."""

import pytest

from tools.notion_hub.compliance_map import (
    CWE_COMPLIANCE_MAP,
    CATEGORY_TO_CWE,
    FRAMEWORKS,
    ComplianceControl,
    get_compliance_controls_for_cwe,
    get_cwes_for_category,
    get_all_controls_for_findings,
)


class TestCWEComplianceMap:
    """Tests for CWE compliance mapping data."""

    def test_common_cwes_mapped(self) -> None:
        """Test common CWEs are in the map."""
        common_cwes = ["CWE-89", "CWE-79", "CWE-78", "CWE-287", "CWE-798"]
        for cwe in common_cwes:
            assert cwe in CWE_COMPLIANCE_MAP, f"{cwe} should be mapped"

    def test_all_frameworks_covered(self) -> None:
        """Test all frameworks appear in mappings."""
        all_frameworks_in_map = set()
        for mapping in CWE_COMPLIANCE_MAP.values():
            all_frameworks_in_map.update(mapping.keys())

        for framework in FRAMEWORKS:
            assert framework in all_frameworks_in_map

    def test_sql_injection_mappings(self) -> None:
        """Test SQL injection CWE-89 has correct mappings."""
        mapping = CWE_COMPLIANCE_MAP["CWE-89"]

        assert "SOC2" in mapping
        assert "CC6.1" in mapping["SOC2"]
        assert "PCI-DSS" in mapping
        assert "6.5.1" in mapping["PCI-DSS"]
        assert "OWASP" in mapping
        assert "A03:2021" in mapping["OWASP"]


class TestCategoryToCWE:
    """Tests for category to CWE mapping."""

    def test_common_categories_mapped(self) -> None:
        """Test common vulnerability categories are mapped."""
        categories = [
            "SQL Injection",
            "XSS",
            "Authentication",
            "Authorization",
            "Cryptography",
        ]
        for cat in categories:
            assert cat in CATEGORY_TO_CWE, f"{cat} should be mapped"

    def test_injection_category(self) -> None:
        """Test Injection category has expected CWEs."""
        cwes = CATEGORY_TO_CWE["Injection"]
        assert "CWE-89" in cwes
        assert "CWE-78" in cwes


class TestComplianceControl:
    """Tests for ComplianceControl class."""

    def test_from_cwe(self) -> None:
        """Test creating control from CWE."""
        control = ComplianceControl.from_cwe("CWE-89", "SOC2", "CC6.1")

        assert control.control_id == "CC6.1"
        assert control.framework == "SOC2"
        assert control.related_cwes == ["CWE-89"]
        assert control.description != ""

    def test_calculate_status_passing(self) -> None:
        """Test status is Passing with no findings."""
        control = ComplianceControl(
            control_id="CC6.1",
            framework="SOC2",
            description="Test",
        )

        status = control.calculate_status([])
        assert status == "Passing"

    def test_calculate_status_failing_critical(self) -> None:
        """Test status is Failing with critical findings."""
        control = ComplianceControl(
            control_id="CC6.1",
            framework="SOC2",
            description="Test",
        )

        findings = [{"severity": "critical"}]
        status = control.calculate_status(findings)
        assert status == "Failing"

    def test_calculate_status_failing_high(self) -> None:
        """Test status is Failing with high findings."""
        control = ComplianceControl(
            control_id="CC6.1",
            framework="SOC2",
            description="Test",
        )

        findings = [{"severity": "high"}]
        status = control.calculate_status(findings)
        assert status == "Failing"

    def test_calculate_status_at_risk_medium(self) -> None:
        """Test status is At Risk with medium findings."""
        control = ComplianceControl(
            control_id="CC6.1",
            framework="SOC2",
            description="Test",
        )

        findings = [{"severity": "medium"}]
        status = control.calculate_status(findings)
        assert status == "At Risk"

    def test_calculate_status_at_risk_low(self) -> None:
        """Test status is At Risk with low findings."""
        control = ComplianceControl(
            control_id="CC6.1",
            framework="SOC2",
            description="Test",
        )

        findings = [{"severity": "low"}]
        status = control.calculate_status(findings)
        assert status == "At Risk"


class TestGetComplianceControlsForCWE:
    """Tests for get_compliance_controls_for_cwe function."""

    def test_get_controls_for_sql_injection(self) -> None:
        """Test getting controls for SQL injection."""
        controls = get_compliance_controls_for_cwe("CWE-89")

        assert len(controls) > 0
        frameworks = {c.framework for c in controls}
        assert "SOC2" in frameworks
        assert "PCI-DSS" in frameworks
        assert "OWASP" in frameworks

    def test_get_controls_normalizes_cwe(self) -> None:
        """Test CWE ID is normalized."""
        controls1 = get_compliance_controls_for_cwe("CWE-89")
        controls2 = get_compliance_controls_for_cwe("cwe-89")
        controls3 = get_compliance_controls_for_cwe("89")

        assert len(controls1) == len(controls2) == len(controls3)

    def test_get_controls_unknown_cwe(self) -> None:
        """Test getting controls for unknown CWE returns empty."""
        controls = get_compliance_controls_for_cwe("CWE-99999")
        assert controls == []


class TestGetCWEsForCategory:
    """Tests for get_cwes_for_category function."""

    def test_exact_match(self) -> None:
        """Test exact category match."""
        cwes = get_cwes_for_category("SQL Injection")
        assert "CWE-89" in cwes

    def test_case_insensitive(self) -> None:
        """Test case insensitive matching."""
        cwes1 = get_cwes_for_category("SQL Injection")
        cwes2 = get_cwes_for_category("sql injection")

        assert cwes1 == cwes2

    def test_partial_match(self) -> None:
        """Test partial category matching."""
        cwes = get_cwes_for_category("Injection")
        assert "CWE-89" in cwes
        assert "CWE-78" in cwes

    def test_unknown_category(self) -> None:
        """Test unknown category returns empty."""
        cwes = get_cwes_for_category("Unknown Category XYZ")
        assert cwes == []


class TestGetAllControlsForFindings:
    """Tests for get_all_controls_for_findings function."""

    def test_controls_from_cwe(self) -> None:
        """Test getting controls from findings with CWE."""
        findings = [{"cwe_id": "CWE-89", "severity": "high"}]
        controls = get_all_controls_for_findings(findings)

        assert len(controls) > 0
        assert any("SOC2" in key for key in controls.keys())

    def test_controls_from_category(self) -> None:
        """Test getting controls from findings with category."""
        findings = [{"category": "SQL Injection", "severity": "high"}]
        controls = get_all_controls_for_findings(findings)

        assert len(controls) > 0

    def test_multiple_findings_dedupe(self) -> None:
        """Test multiple findings don't create duplicate controls."""
        findings = [
            {"cwe_id": "CWE-89", "severity": "high"},
            {"cwe_id": "CWE-89", "severity": "medium"},
        ]
        controls = get_all_controls_for_findings(findings)

        control_keys = list(controls.keys())
        assert len(control_keys) == len(set(control_keys))

    def test_empty_findings(self) -> None:
        """Test empty findings returns empty controls."""
        controls = get_all_controls_for_findings([])
        assert controls == {}
