"""Unit tests for PatternExtractor and PatternMatch."""

import pytest
from datetime import datetime

from tools.notion_hub.patterns import PatternMatch, PatternExtractor


class TestPatternMatch:
    """Tests for PatternMatch."""

    def test_to_notion_properties(self) -> None:
        """Test converting to Notion properties."""
        pattern = PatternMatch(
            pattern_name="SQL Injection (CWE-89)",
            category="Injection",
            cwe_id="CWE-89",
            frequency=5,
            last_seen=datetime(2026, 2, 25),
        )

        props = pattern.to_notion_properties()

        assert props["Title"]["title"][0]["text"]["content"] == "SQL Injection (CWE-89)"
        assert props["Category"]["select"]["name"] == "Injection"
        assert props["Frequency"]["number"] == 5
        assert props["CWE ID"]["rich_text"][0]["text"]["content"] == "CWE-89"
        assert props["Last Seen"]["date"]["start"] == "2026-02-25"

    def test_to_notion_properties_without_cwe(self) -> None:
        """Test converting to Notion properties without CWE."""
        pattern = PatternMatch(
            pattern_name="Missing CSRF Token",
            category="CSRF",
            frequency=3,
        )

        props = pattern.to_notion_properties()

        assert "CWE ID" not in props
        assert "Last Seen" not in props

    def test_merge_patterns(self) -> None:
        """Test merging two patterns."""
        pattern1 = PatternMatch(
            pattern_name="SQL Injection",
            category="Injection",
            cwe_id="CWE-89",
            frequency=3,
            severity_distribution={"critical": 1, "high": 2},
            related_audit_ids=["audit1", "audit2"],
            last_seen=datetime(2026, 2, 20),
        )

        pattern2 = PatternMatch(
            pattern_name="SQL Injection",
            category="Injection",
            cwe_id="CWE-89",
            frequency=2,
            severity_distribution={"critical": 1, "medium": 1},
            related_audit_ids=["audit3"],
            remediation_template="Use parameterized queries",
            last_seen=datetime(2026, 2, 25),
        )

        pattern1.merge(pattern2)

        assert pattern1.frequency == 5
        assert pattern1.severity_distribution["critical"] == 2
        assert pattern1.severity_distribution["high"] == 2
        assert pattern1.severity_distribution["medium"] == 1
        assert "audit3" in pattern1.related_audit_ids
        assert pattern1.remediation_template == "Use parameterized queries"
        assert pattern1.last_seen == datetime(2026, 2, 25)

    def test_merge_doesnt_duplicate_audit_ids(self) -> None:
        """Test merging doesn't duplicate audit IDs."""
        pattern1 = PatternMatch(
            pattern_name="Test",
            category="Test",
            related_audit_ids=["audit1", "audit2"],
        )

        pattern2 = PatternMatch(
            pattern_name="Test",
            category="Test",
            related_audit_ids=["audit2", "audit3"],
        )

        pattern1.merge(pattern2)

        assert pattern1.related_audit_ids == ["audit1", "audit2", "audit3"]


class TestPatternExtractor:
    """Tests for PatternExtractor."""

    @pytest.fixture
    def extractor(self) -> PatternExtractor:
        """Create a PatternExtractor for testing."""
        return PatternExtractor()

    @pytest.fixture
    def sample_findings(self) -> list:
        """Create sample findings."""
        return [
            {
                "description": "SQL Injection in login",
                "category": "Injection",
                "cwe_id": "CWE-89",
                "severity": "critical",
                "remediation": "Use parameterized queries",
            },
            {
                "description": "SQL Injection in search",
                "category": "Injection",
                "cwe_id": "CWE-89",
                "severity": "high",
            },
            {
                "description": "XSS in profile page",
                "category": "XSS",
                "cwe_id": "CWE-79",
                "severity": "high",
            },
        ]

    def test_extract_from_finding(self, extractor: PatternExtractor) -> None:
        """Test extracting pattern from single finding."""
        finding = {
            "description": "SQL Injection",
            "category": "Injection",
            "cwe_id": "CWE-89",
            "severity": "high",
            "remediation": "Fix it",
        }

        pattern = extractor.extract_from_finding(finding, "audit1")

        assert pattern.pattern_name == "Injection (CWE-89)"
        assert pattern.category == "Injection"
        assert pattern.cwe_id == "CWE-89"
        assert pattern.frequency == 1
        assert pattern.severity_distribution == {"high": 1}
        assert pattern.related_audit_ids == ["audit1"]
        assert pattern.remediation_template == "Fix it"

    def test_normalize_pattern_name_with_cwe(self, extractor: PatternExtractor) -> None:
        """Test pattern name normalization with CWE."""
        finding = {"category": "SQL Injection", "cwe_id": "CWE-89"}
        name = extractor._normalize_pattern_name(finding)
        assert name == "SQL Injection (CWE-89)"

    def test_normalize_pattern_name_without_cwe(self, extractor: PatternExtractor) -> None:
        """Test pattern name normalization without CWE."""
        finding = {"category": "Configuration Issue"}
        name = extractor._normalize_pattern_name(finding)
        assert name == "Configuration Issue"

    def test_get_pattern_key_with_cwe(self, extractor: PatternExtractor) -> None:
        """Test pattern key generation with CWE."""
        finding = {"category": "Injection", "cwe_id": "cwe-89"}
        key = extractor._get_pattern_key(finding)
        assert key == "CWE-89"

    def test_get_pattern_key_without_cwe(self, extractor: PatternExtractor) -> None:
        """Test pattern key generation without CWE."""
        finding = {"category": "Missing Auth"}
        key = extractor._get_pattern_key(finding)
        assert key == "missing_auth"

    def test_process_findings(
        self,
        extractor: PatternExtractor,
        sample_findings: list,
    ) -> None:
        """Test processing multiple findings."""
        patterns = extractor.process_findings(sample_findings, "audit1")

        assert len(patterns) == 2
        assert "CWE-89" in patterns
        assert "CWE-79" in patterns

        sql_pattern = patterns["CWE-89"]
        assert sql_pattern.frequency == 2
        assert sql_pattern.severity_distribution["critical"] == 1
        assert sql_pattern.severity_distribution["high"] == 1

    def test_process_multiple_audits(self, extractor: PatternExtractor) -> None:
        """Test processing findings from multiple audits."""
        audits = [
            {
                "id": "audit1",
                "findings": [
                    {"category": "Injection", "cwe_id": "CWE-89", "severity": "high"},
                ],
            },
            {
                "id": "audit2",
                "findings": [
                    {"category": "Injection", "cwe_id": "CWE-89", "severity": "critical"},
                    {"category": "XSS", "cwe_id": "CWE-79", "severity": "medium"},
                ],
            },
        ]

        patterns = extractor.process_multiple_audits(audits)

        assert "CWE-89" in patterns
        assert patterns["CWE-89"].frequency == 2
        assert "audit1" in patterns["CWE-89"].related_audit_ids
        assert "audit2" in patterns["CWE-89"].related_audit_ids

    def test_get_top_patterns(
        self,
        extractor: PatternExtractor,
        sample_findings: list,
    ) -> None:
        """Test getting top patterns by frequency."""
        extractor.process_findings(sample_findings, "audit1")
        top = extractor.get_top_patterns(limit=1)

        assert len(top) == 1
        assert top[0].cwe_id == "CWE-89"

    def test_get_patterns_by_severity(
        self,
        extractor: PatternExtractor,
        sample_findings: list,
    ) -> None:
        """Test getting patterns by severity."""
        extractor.process_findings(sample_findings, "audit1")
        critical = extractor.get_patterns_by_severity("critical")

        assert len(critical) == 1
        assert critical[0].cwe_id == "CWE-89"

    def test_clear(
        self,
        extractor: PatternExtractor,
        sample_findings: list,
    ) -> None:
        """Test clearing patterns."""
        extractor.process_findings(sample_findings, "audit1")
        assert len(extractor.patterns) > 0

        extractor.clear()
        assert len(extractor.patterns) == 0
