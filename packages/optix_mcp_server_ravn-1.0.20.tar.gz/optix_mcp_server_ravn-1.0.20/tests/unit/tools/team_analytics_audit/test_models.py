from datetime import datetime
import pytest
from tools.team_analytics_audit.models import (
    AuditStepResult,
    AreaHealth,
    CollaborationData,
    ComparisonDelta,
    ContributorProfile,
    FileChange,
    FileWriteInstructions,
    QualitySignals,
    RawCommit,
    SustainabilitySignals,
    TeamAuditResponse,
    TeamHealthDiagnostic,
    VelocityTrend,
)


class TestFileChange:
    def test_creation(self):
        fc = FileChange(file_path="src/main.py", additions=10, deletions=5)
        assert fc.file_path == "src/main.py"
        assert fc.additions == 10
        assert fc.deletions == 5
        assert fc.is_binary is False

    def test_binary_file(self):
        fc = FileChange(file_path="assets/logo.png", additions=0, deletions=0, is_binary=True)
        assert fc.is_binary is True


class TestRawCommit:
    def test_creation(self):
        ts = datetime(2026, 1, 15, 10, 0, 0)
        commit = RawCommit(
            hash="abc123",
            author_name="Alice",
            author_email="alice@example.com",
            timestamp=ts,
            subject="feat: add feature",
            parent_hashes=["parent1"],
            files_changed=[],
            is_merge=False,
        )
        assert commit.hash == "abc123"
        assert commit.is_merge is False
        assert commit.co_authors == []

    def test_merge_commit(self):
        ts = datetime(2026, 1, 15, 10, 0, 0)
        commit = RawCommit(
            hash="merge1",
            author_name="Bob",
            author_email="bob@example.com",
            timestamp=ts,
            subject="Merge branch main",
            parent_hashes=["p1", "p2"],
            files_changed=[],
            is_merge=True,
        )
        assert commit.is_merge is True

    def test_co_authors(self):
        ts = datetime(2026, 1, 15, 10, 0, 0)
        commit = RawCommit(
            hash="co1",
            author_name="Alice",
            author_email="alice@example.com",
            timestamp=ts,
            subject="feat: pair programming",
            parent_hashes=["p1"],
            files_changed=[],
            is_merge=False,
            co_authors=["Bob <bob@example.com>"],
        )
        assert len(commit.co_authors) == 1


class TestAuditStepResult:
    def test_to_dict_executed(self):
        step = AuditStepResult(
            name="Collect",
            status="executed",
            skip_reason=None,
            duration_ms=150,
        )
        result = step.to_dict()
        assert result == {
            "name": "Collect",
            "status": "executed",
            "skip_reason": None,
            "duration_ms": 150,
        }

    def test_to_dict_skipped(self):
        step = AuditStepResult(
            name="Compare",
            status="skipped",
            skip_reason="no compare_period provided",
            duration_ms=0,
        )
        result = step.to_dict()
        assert result["status"] == "skipped"
        assert result["skip_reason"] == "no compare_period provided"


class TestAreaHealth:
    def test_knowledge_silo(self):
        area = AreaHealth(
            path="src/auth",
            bus_factor=1,
            primary_owner="Alice",
            owner_percentage=1.0,
            total_commits=50,
            contributors=["Alice"],
            is_knowledge_silo=True,
        )
        assert area.is_knowledge_silo is True
        assert area.bus_factor == 1

    def test_healthy_area(self):
        area = AreaHealth(
            path="src/api",
            bus_factor=3,
            primary_owner="Bob",
            owner_percentage=0.4,
            total_commits=100,
            contributors=["Bob", "Alice", "Charlie"],
            is_knowledge_silo=False,
        )
        assert area.is_knowledge_silo is False
        assert area.bus_factor == 3


class TestTeamAuditResponse:
    def test_to_dict(self):
        step = AuditStepResult(name="Collect", status="executed", skip_reason=None, duration_ms=100)
        instructions = FileWriteInstructions(
            target_path="/repo/TEAM_AUDIT_REPORT.md",
            content="# Report",
            create_directory=True,
            overwrite_strategy="overwrite",
        )
        response = TeamAuditResponse(
            report_content="# Report",
            report_path="/repo/TEAM_AUDIT_REPORT.md",
            file_write_instructions=instructions,
            consolidated_summary={"total_commits": 10},
            steps_executed=[step],
        )
        result = response.to_dict()
        assert result["report_content"] == "# Report"
        assert result["report_path"] == "/repo/TEAM_AUDIT_REPORT.md"
        assert result["consolidated_summary"]["total_commits"] == 10
        assert len(result["steps_executed"]) == 1
        assert result["file_write_instructions"]["overwrite_strategy"] == "overwrite"


class TestFileWriteInstructions:
    def test_to_dict(self):
        instructions = FileWriteInstructions(
            target_path="/repo/TEAM_AUDIT_REPORT.md",
            content="# Report content",
            create_directory=True,
            overwrite_strategy="overwrite",
        )
        result = instructions.to_dict()
        assert result["target_path"] == "/repo/TEAM_AUDIT_REPORT.md"
        assert result["create_directory"] is True
        assert result["overwrite_strategy"] == "overwrite"
