"""Terminal UI components for the installation wizard."""

import socket
from dataclasses import dataclass

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
import questionary
from questionary import Style

OPTIX_HEADER = """
   ██████╗ ██████╗ ████████╗██╗██╗  ██╗
  ██╔═══██╗██╔══██╗╚══██╔══╝██║╚██╗██╔╝
  ██║   ██║██████╔╝   ██║   ██║ ╚███╔╝
  ██║   ██║██╔═══╝    ██║   ██║ ██╔██╗
  ╚██████╔╝██║        ██║   ██║██╔╝ ██╗
   ╚═════╝ ╚═╝        ╚═╝   ╚═╝╚═╝  ╚═╝

  MCP Server Installation Wizard
"""

OPTIX_DESCRIPTION = """AI-powered MCP server for comprehensive code analysis.

  Audit Tools:
    • Security Audit - Vulnerability detection and security analysis
    • Accessibility Audit - WCAG 2.1/2.2 compliance checks
    • DevOps Audit - Docker, CI/CD, and dependency analysis
    • Principal Audit - Code quality, complexity, and coupling metrics
    • Team Analytics Audit - Git contribution patterns and team health

  Supporting Features:
    • Report Generation - Standardized audit reports
    • Dashboard UI - Real-time audit monitoring
    • PR Comments - Post findings to GitHub PRs
    • Expert Analysis - AI-enhanced insights"""

QUESTIONARY_STYLE = Style([
    ("qmark", "fg:cyan bold"),
    ("question", "bold"),
    ("answer", "fg:cyan bold"),
    ("pointer", "fg:cyan bold"),
    ("highlighted", "fg:cyan"),
    ("selected", "fg:cyan bold"),
    ("separator", "fg:gray"),
    ("instruction", "fg:gray"),
])


@dataclass
class AgentChoice:
    """Represents an agent selection choice."""
    name: str
    label: str
    checked: bool = False


@dataclass
class LensChoice:
    """Represents a lens selection choice."""
    id: str
    display_name: str
    description: str


AUDIT_LENSES = {
    "security": [
        LensChoice("comprehensive", "Comprehensive", "Full security review (default)"),
        LensChoice("backend", "Backend Developer", "SQL injection, auth, API security"),
        LensChoice("frontend", "Frontend Developer", "XSS, CSRF, DOM security"),
        LensChoice("devsecops", "DevSecOps Engineer", "Secrets, dependencies, CI/CD"),
        LensChoice("compliance", "Compliance Auditor", "GDPR, HIPAA, PCI-DSS"),
    ],
    "a11y": [
        LensChoice("comprehensive", "Comprehensive", "Full accessibility review (default)"),
        LensChoice("screenreader", "Screen Reader User", "ARIA, semantics, alt text"),
        LensChoice("keyboard", "Keyboard-Only User", "Tab order, focus, traps"),
        LensChoice("visual", "Visual Accessibility", "Contrast, sizing, colors"),
        LensChoice("wcag", "WCAG Compliance", "Success criteria verification"),
    ],
    "devops": [
        LensChoice("comprehensive", "Comprehensive", "Full DevOps review (default)"),
        LensChoice("security", "Security-First", "Secrets, supply chain, CVEs"),
        LensChoice("performance", "Performance & Cost", "Build times, caching, costs"),
        LensChoice("compliance", "Compliance", "SOC2, PCI-DSS, audit trails"),
        LensChoice("multicloud", "Multi-Cloud", "AWS/Azure/GCP patterns"),
        LensChoice("startup", "Startup/Agile", "Quick wins, pragmatic defaults"),
    ],
    "principal": [
        LensChoice("comprehensive", "Comprehensive", "Full code quality review (default)"),
        LensChoice("frontend", "Frontend Developer", "Components, state, rendering"),
        LensChoice("backend", "Backend Developer", "Services, APIs, data access"),
        LensChoice("performance", "Performance Engineer", "Algorithms, bottlenecks"),
        LensChoice("techlead", "Tech Lead", "Architecture, patterns, conventions"),
    ],
}


class ConsoleUI:
    """Terminal UI handler using rich and questionary."""

    def __init__(self, quiet: bool = False, verbose: bool = False):
        self.console = Console()
        self.quiet = quiet
        self.verbose = verbose

    def show_header(self) -> None:
        if self.quiet:
            return
        self.console.print(Text(OPTIX_HEADER, style="cyan"))
        self.console.print(
            Panel(
                OPTIX_DESCRIPTION,
                border_style="cyan",
                padding=(0, 1),
            )
        )
        self.console.print()

    def info(self, message: str) -> None:
        if self.quiet:
            return
        self.console.print(f"[blue]ℹ[/blue] {message}")

    def success(self, message: str) -> None:
        if self.quiet:
            return
        self.console.print(f"[green]✓[/green] {message}")

    def warn(self, message: str) -> None:
        self.console.print(f"[yellow]⚠[/yellow] {message}")

    def error(self, message: str) -> None:
        self.console.print(f"[red]✗[/red] {message}", style="red")

    def debug(self, message: str) -> None:
        if self.verbose:
            self.console.print(f"[cyan]→[/cyan] {message}")

    def newline(self) -> None:
        if not self.quiet:
            self.console.print()

    def select_agents(self, choices: list[AgentChoice]) -> list[str]:
        """Multi-select agent checkboxes using native checkbox widget."""
        checkbox_choices = [
            questionary.Choice(
                title=choice.label,
                value=choice.name,
                checked=choice.checked,
            )
            for choice in choices
        ]

        result = questionary.checkbox(
            "Select AI agents to configure:",
            choices=checkbox_choices,
            style=QUESTIONARY_STYLE,
            instruction="(Space to toggle, Enter to submit)",
        ).ask()

        if result is None:
            raise KeyboardInterrupt()

        if not result:
            self.warn("Please select at least one agent")
            return self.select_agents(choices)

        return result

    def select_scope(self) -> str:
        """Single select for installation scope."""
        choices = [
            questionary.Choice(title="Global (user-wide)", value="global"),
            questionary.Choice(title="Local (current project)", value="local"),
        ]

        selected = questionary.select(
            "Select installation scope:",
            choices=choices,
            style=QUESTIONARY_STYLE,
        ).ask()

        if selected is None:
            raise KeyboardInterrupt()

        return selected

    def confirm(self, message: str, default: bool = False) -> bool:
        """Ask for confirmation."""
        result = questionary.confirm(
            message,
            default=default,
            style=QUESTIONARY_STYLE,
        ).ask()

        if result is None:
            raise KeyboardInterrupt()

        return result

    def prompt_password(self, message: str) -> str:
        """Prompt for password/secret input (hidden)."""
        result = questionary.password(
            message,
            style=QUESTIONARY_STYLE,
        ).ask()

        if result is None:
            raise KeyboardInterrupt()

        return result or ""

    def prompt_text(self, message: str, default: str = "") -> str:
        """Prompt for text input."""
        result = questionary.text(
            message,
            default=default,
            style=QUESTIONARY_STYLE,
        ).ask()

        if result is None:
            raise KeyboardInterrupt()

        return result or ""

    def select_severity_filter(self) -> list[str]:
        """Select severity levels for Slack notifications."""
        preset_choices = [
            questionary.Choice(title="All findings", value="all"),
            questionary.Choice(title="Critical only", value="critical"),
            questionary.Choice(title="Critical and High", value="critical,high"),
            questionary.Choice(title="Custom selection...", value="custom"),
        ]

        preset = questionary.select(
            "Which severity levels should trigger notifications?",
            choices=preset_choices,
            style=QUESTIONARY_STYLE,
        ).ask()

        if preset is None:
            raise KeyboardInterrupt()

        if preset == "all":
            return ["critical", "high", "medium", "low", "info"]
        if preset == "critical":
            return ["critical"]
        if preset == "critical,high":
            return ["critical", "high"]

        checkbox_choices = [
            questionary.Choice(title="Critical", value="critical", checked=True),
            questionary.Choice(title="High", value="high", checked=True),
            questionary.Choice(title="Medium", value="medium", checked=False),
            questionary.Choice(title="Low", value="low", checked=False),
            questionary.Choice(title="Info", value="info", checked=False),
        ]

        result = questionary.checkbox(
            "Select severity levels:",
            choices=checkbox_choices,
            style=QUESTIONARY_STYLE,
            instruction="(Space to toggle, Enter to submit)",
        ).ask()

        if result is None:
            raise KeyboardInterrupt()

        if not result:
            self.warn("Please select at least one severity level")
            return self.select_severity_filter()

        return result

    def show_completion(
        self,
        agents: list[str],
        scope: str,
        expert_enabled: bool,
        dashboard_enabled: bool = False,
        dashboard_port: int = 24282,
        default_lenses: dict[str, str] | None = None,
        linear_enabled: bool = False,
        jira_enabled: bool = False,
        notion_enabled: bool = False,
        slack_enabled: bool = False,
        slack_channel_id: str = "",
        slack_severity_filter: list[str] | None = None,
    ) -> None:
        """Show final completion panel."""
        self.newline()

        agent_list = "\n".join(f"    • {agent}" for agent in agents)
        expert_status = "[cyan]enabled[/cyan]" if expert_enabled else "disabled"
        dashboard_status = f"[cyan]enabled[/cyan] (port {dashboard_port})" if dashboard_enabled else "disabled"

        if slack_enabled and slack_severity_filter:
            severity_display = ", ".join(slack_severity_filter)
            slack_status = f"[cyan]enabled[/cyan] (channel: {slack_channel_id}, filter: {severity_display})"
        else:
            slack_status = "disabled"

        lens_info = ""
        if default_lenses:
            audit_labels = {
                "security": "Security",
                "a11y": "Accessibility",
                "devops": "DevOps",
                "principal": "Principal",
            }
            lens_lines = []
            for audit_type, lens_id in default_lenses.items():
                label = audit_labels.get(audit_type, audit_type)
                lens_display = next(
                    (l.display_name for l in AUDIT_LENSES.get(audit_type, []) if l.id == lens_id),
                    lens_id
                )
                lens_lines.append(f"    • {label}: [cyan]{lens_display}[/cyan]")
            lens_info = "\n\n[bold]Default lenses:[/bold]\n" + "\n".join(lens_lines)

        ticket_integrations = []
        if linear_enabled:
            ticket_integrations.append("Linear")
        if jira_enabled:
            ticket_integrations.append("Jira")
        if notion_enabled:
            ticket_integrations.append("Notion")
        ticket_status = ", ".join(f"[cyan]{t}[/cyan]" for t in ticket_integrations) if ticket_integrations else "disabled"

        content = f"""[bold]Configured agents:[/bold]
{agent_list}

[bold]Scope:[/bold] {scope}
[bold]Expert analysis:[/bold] {expert_status}
[bold]Dashboard UI:[/bold] {dashboard_status}
[bold]Ticket integrations:[/bold] {ticket_status}
[bold]Slack notifications:[/bold] {slack_status}{lens_info}

[bold]Next steps:[/bold]
  1. Restart your AI agent application
  2. Verify installation with: health_check tool
  3. Run your first audit: security_audit tool
  4. Analyze team contributions: team_analytics_audit tool

[bold]Documentation:[/bold]
  https://github.com/ravnhq/ravn-labs-optix-2#readme"""

        panel = Panel(
            content,
            title="[cyan]Installation Complete![/cyan]",
            border_style="cyan",
        )
        self.console.print(panel)

    def select_yes_no(self, message: str, default: bool = False) -> bool:
        """Yes/No selection with immediate selection on Enter."""
        choices = [
            questionary.Choice(title="Yes", value=True),
            questionary.Choice(title="No", value=False),
        ]

        result = questionary.select(
            message,
            choices=choices,
            style=QUESTIONARY_STYLE,
        ).ask()

        if result is None:
            raise KeyboardInterrupt()

        return result

    def validate_port(self, port_str: str) -> tuple[bool, int, str]:
        """Validate port number.

        Returns: (is_valid, port_number, error_message)
        """
        try:
            port = int(port_str)
        except ValueError:
            return False, 0, "Invalid port number - must be an integer"

        if port < 1024:
            return False, 0, "Ports 1-1023 are reserved and require admin privileges"

        if port > 65535:
            return False, 0, "Port must be between 1024 and 65535"

        if self._is_port_in_use(port):
            return False, 0, f"Port {port} is already in use"

        return True, port, ""

    def _is_port_in_use(self, port: int) -> bool:
        """Check if a port is currently in use."""
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            return s.connect_ex(("localhost", port)) == 0

    def prompt_port(self, message: str, default: int = 24282) -> int:
        """Prompt for port number with validation."""
        while True:
            result = questionary.text(
                message,
                default=str(default),
                style=QUESTIONARY_STYLE,
            ).ask()

            if result is None:
                raise KeyboardInterrupt()

            is_valid, port, error = self.validate_port(result)
            if is_valid:
                return port

            self.warn(error)

    def select_lens(self, audit_type: str, audit_label: str) -> str:
        """Select a lens for a specific audit type.

        Args:
            audit_type: The audit type key (security, a11y, devops, principal)
            audit_label: Human-readable audit name for display

        Returns:
            Selected lens ID
        """
        lenses = AUDIT_LENSES.get(audit_type, [])
        if not lenses:
            return "comprehensive"

        choices = [
            questionary.Choice(
                title=f"{lens.display_name} - {lens.description}",
                value=lens.id,
            )
            for lens in lenses
        ]

        result = questionary.select(
            f"Default lens for {audit_label}:",
            choices=choices,
            style=QUESTIONARY_STYLE,
        ).ask()

        if result is None:
            raise KeyboardInterrupt()

        return result

    def show_lens_summary(self, lenses: dict[str, str]) -> None:
        """Show summary of selected lenses."""
        audit_labels = {
            "security": "Security Audit",
            "a11y": "Accessibility Audit",
            "devops": "DevOps Audit",
            "principal": "Principal Audit",
        }

        self.console.print("\n[bold]Selected default lenses:[/bold]")
        for audit_type, lens_id in lenses.items():
            label = audit_labels.get(audit_type, audit_type)
            lens_info = next(
                (l for l in AUDIT_LENSES.get(audit_type, []) if l.id == lens_id),
                None
            )
            lens_name = lens_info.display_name if lens_info else lens_id
            self.console.print(f"    • {label}: [cyan]{lens_name}[/cyan]")
