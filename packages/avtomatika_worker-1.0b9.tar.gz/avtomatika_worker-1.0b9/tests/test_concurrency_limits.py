# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.
#
# Copyright (c) 2026 Dmitrii Gagarin aka madgagarin

from avtomatika_worker.config import WorkerConfig
from avtomatika_worker.worker import Worker


def test_task_registration_with_type():
    """Tests that the @worker.skill decorator correctly registers a task with a type."""
    worker = Worker(skill_type_limits={"video": 1})

    @worker.skill("process_video", type="video")
    async def my_handler(params: dict):
        return {"status": "success"}

    assert "process_video" in worker._skill_handlers
    assert worker._skill_handlers["process_video"]["type"] == "video"
    assert worker._skill_handlers["process_video"]["func"] == my_handler


def test_get_current_state_initial():
    """Tests the initial state of the worker."""
    mock_config = WorkerConfig()
    mock_config.MAX_CONCURRENT_TASKS = 5  # Set initial limit
    mock_config.ORCHESTRATORS = [{"url": "http://test", "weight": 1}]  # Needs to be defined

    worker = Worker(config=mock_config, skill_type_limits={"video": 1, "audio": 2})

    @worker.skill("process_video", type="video")
    async def video_handler(params: dict): ...

    @worker.skill("process_audio", type="audio")
    async def audio_handler(params: dict): ...

    @worker.skill("unlimited_task")
    async def unlimited_handler(params: dict): ...

    state = worker._get_current_state()
    assert state["status"] == "idle"
    skill_names = {s.name for s in state["supported_skills"]}
    assert skill_names == {
        "process_video",
        "process_audio",
        "unlimited_task",
    }


def test_get_current_state_global_limit_reached():
    """Tests that the worker becomes busy when the global concurrency limit is reached."""
    # Create a mock config to ensure MAX_CONCURRENT_TASKS is controlled
    mock_config = WorkerConfig()
    mock_config.MAX_CONCURRENT_TASKS = 1

    worker = Worker(config=mock_config)  # Pass the mock config
    worker._current_load = 1

    @worker.skill("some_task")
    async def some_task(params: dict): ...

    state = worker._get_current_state()
    assert state["status"] == "busy"
    assert state["supported_skills"] == []


def test_get_current_state_type_limit_reached():
    """Tests that a task type is unavailable when its limit is reached."""
    worker = Worker(max_concurrent_tasks=5, skill_type_limits={"video": 1})
    worker._current_load = 1
    worker._current_load_by_type["video"] = 1

    @worker.skill("process_video", type="video")
    async def video_handler(params: dict): ...

    @worker.skill("process_audio", type="audio")
    async def audio_handler(params: dict): ...

    state = worker._get_current_state()
    assert state["status"] == "idle"
    skill_names = {s.name for s in state["supported_skills"]}
    assert skill_names == {"process_audio"}


def test_get_current_state_all_type_limits_reached():
    """Tests that the worker becomes busy when all type limits are reached,
    even if the global limit is not."""
    worker = Worker(max_concurrent_tasks=5, skill_type_limits={"video": 1, "audio": 1})
    worker._current_load = 2
    worker._current_load_by_type["video"] = 1
    worker._current_load_by_type["audio"] = 1

    @worker.skill("process_video", type="video")
    async def video_handler(params: dict): ...

    @worker.skill("process_audio", type="audio")
    async def audio_handler(params: dict): ...

    state = worker._get_current_state()
    assert state["status"] == "busy"
    assert state["supported_skills"] == []
