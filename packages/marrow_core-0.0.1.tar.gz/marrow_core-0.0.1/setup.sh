#!/bin/bash
# marrow-core setup: clone, install, link agents, start daemons.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
source "${SCRIPT_DIR}/lib.sh"

# --- Repository ---
if [[ ! -d "${CORE_DIR}/.git" ]]; then
  sudo git clone --branch main --single-branch "$REPO_URL" "$CORE_DIR"
else
  sudo git -C "$CORE_DIR" pull --ff-only origin main
fi

# --- Venv ---
sudo bash -lc "source '${CORE_DIR}/lib.sh' && ensure_venv"

# --- Workspace dirs & agent symlinks ---
ensure_workspace_dirs
link_agents

# --- Copy default context providers (agent-owned, modifiable) ---
for ctx_script in "${CORE_DIR}"/context.d/*; do
  [[ -f "$ctx_script" ]] || continue
  name=$(basename "$ctx_script")
  dst="${WORKSPACE}/context.d/${name}"
  if [[ ! -f "$dst" ]]; then
    sudo -u marrow cp "$ctx_script" "$dst"
    sudo -u marrow chmod +x "$dst"
  fi
done
sudo -u marrow chmod +x "${WORKSPACE}"/context.d/* 2>/dev/null || true

# --- Install & start daemons ---
for name in "${PLISTS[@]}"; do
  install_daemon "$name"
done

echo "[marrow] Setup complete."
launchctl list | grep com.marrow.heart || true
