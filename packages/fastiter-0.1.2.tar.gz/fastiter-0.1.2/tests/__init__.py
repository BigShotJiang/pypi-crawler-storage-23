"""Tests for FastIter."""
