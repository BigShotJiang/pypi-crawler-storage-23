
# Scholarmis Apps

## Quick start

1. Add `scholarmis.apps` to your INSTALLED_APPS setting like this::

```python 

    INSTALLED_APPS = [
        ...,
        "scholarmis.apps",
    ]

```


