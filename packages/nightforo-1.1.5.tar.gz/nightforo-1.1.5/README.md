# NightForo
API wrapper for Arizona Guard written in Python

## Установка

### Установка через pip
```bash
pip install nightforo
```

### Установка через uv
```bash
uv add nightforo
```

## Примеры использования

Примеры кода находятся в директории [examples](https://github.com/nightcore-team/NightForo/tree/main/examples)