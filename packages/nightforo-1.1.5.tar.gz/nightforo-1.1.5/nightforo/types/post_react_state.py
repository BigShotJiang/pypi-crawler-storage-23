from enum import Enum

__all__ = ("PostReactStateEnum",)


class PostReactStateEnum(Enum):
    INSERT = "insert"
    DELETE = "delete"
