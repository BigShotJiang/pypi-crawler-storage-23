from enum import Enum

__all__ = ("DirectionTypeEnum",)


class DirectionTypeEnum(Enum):
    ASC = "asc"
    DESC = "desc"
