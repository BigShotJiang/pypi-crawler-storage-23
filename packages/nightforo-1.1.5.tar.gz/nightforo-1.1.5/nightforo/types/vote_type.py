from enum import Enum

__all__ = ("VoteTypeEnum",)


class VoteTypeEnum(Enum):
    UP = "up"
    DOWN = "down"
