"""Shared utilities for the Dolphin KB package."""
