"""AST cache for parsed source files.

This module provides caching of tree-sitter ASTs to avoid re-parsing unchanged
files, resulting in 40%+ parse time reduction on incremental indexing.
"""

from __future__ import annotations

import logging
import pickle
import threading
from collections import OrderedDict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ..chunkers.types import Chunk

_logger = logging.getLogger(__name__)


@dataclass
class CachedAST:
    """Cached AST data for a file."""

    file_path: str
    content_hash: str
    chunks: list[Chunk]
    language: str
    timestamp: float


class ASTCache:
    """LRU cache for parsed ASTs with persistence support.

    This cache stores parsed chunks (which represent the AST in chunked form)
    indexed by (file_path, content_hash) to enable fast incremental parsing.
    """

    def __init__(
        self,
        max_size: int = 1000,
        persist_path: Path | None = None,
    ):
        """Initialize AST cache.

        Args:
            max_size: Maximum number of files to cache (default: 1000)
            persist_path: Optional path to persist cache to disk
        """
        self.max_size = max_size
        self.persist_path = persist_path
        self._cache: OrderedDict[str, CachedAST] = OrderedDict()
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0

        # Load persisted cache if available
        if persist_path and persist_path.exists():
            self._load_from_disk()

    def _make_key(self, file_path: str, content_hash: str) -> str:
        """Create cache key from file path and content hash."""
        return f"{file_path}:{content_hash}"

    def get(
        self,
        file_path: str,
        content_hash: str,
    ) -> list[Chunk] | None:
        """Get cached chunks for a file (thread-safe).

        Args:
            file_path: Path to the file
            content_hash: SHA256 hash of file content

        Returns:
            List of cached chunks or None if not found
        """
        key = self._make_key(file_path, content_hash)

        with self._lock:
            if key in self._cache:
                self._hits += 1
                # Move to end (most recently used)
                self._cache.move_to_end(key)
                return self._cache[key].chunks

            self._misses += 1
            return None

    def put(
        self,
        file_path: str,
        content_hash: str,
        chunks: list[Chunk],
        language: str,
    ) -> None:
        """Store chunks in cache.

        Args:
            file_path: Path to the file
            content_hash: SHA256 hash of file content
            chunks: List of chunks to cache
            language: Programming language of the file
        """
        import time

        key = self._make_key(file_path, content_hash)
        cached_ast = CachedAST(
            file_path=file_path,
            content_hash=content_hash,
            chunks=chunks,
            language=language,
            timestamp=time.time(),
        )

        with self._lock:
            # Remove oldest if at capacity
            if len(self._cache) >= self.max_size and key not in self._cache:
                self._cache.popitem(last=False)  # Remove oldest (FIFO)

            self._cache[key] = cached_ast
            self._cache.move_to_end(key)  # Mark as most recently used

    def invalidate(self, file_path: str) -> None:
        """Invalidate all cache entries for a file path (thread-safe).

        Args:
            file_path: Path to the file
        """
        with self._lock:
            keys_to_remove = [key for key in self._cache if key.startswith(f"{file_path}:")]
            for key in keys_to_remove:
                del self._cache[key]

    def clear(self) -> None:
        """Clear all cached ASTs (thread-safe)."""
        with self._lock:
            self._cache.clear()
            self._hits = 0
            self._misses = 0

    def size(self) -> int:
        """Get current cache size."""
        with self._lock:
            return len(self._cache)

    def _hit_rate_unlocked(self) -> float:
        """Calculate cache hit rate (caller must hold self._lock)."""
        total = self._hits + self._misses
        if total == 0:
            return 0.0
        return self._hits / total

    def hit_rate(self) -> float:
        """Calculate cache hit rate.

        Returns:
            Hit rate as a fraction (0.0–1.0), consistent with
            ``ParallelChunkCache.hit_rate()``.

        .. versionchanged:: 0.2.4
            Previously returned a percentage (0–100); now returns a
            fraction (0.0–1.0) for consistency across cache classes.
        """
        with self._lock:
            return self._hit_rate_unlocked()

    def stats(self) -> dict[str, Any]:
        """Get cache statistics.

        Returns:
            Dictionary with cache stats
        """
        with self._lock:
            return {
                "size": len(self._cache),
                "max_size": self.max_size,
                "hits": self._hits,
                "misses": self._misses,
                "hit_rate": self._hit_rate_unlocked(),
                "total_requests": self._hits + self._misses,
            }

    def _save_to_disk(self) -> None:
        """Persist cache to disk."""
        if not self.persist_path:
            return

        try:
            self.persist_path.parent.mkdir(parents=True, exist_ok=True)

            with self._lock:
                snapshot = {
                    "cache": dict(self._cache),
                    "hits": self._hits,
                    "misses": self._misses,
                }

            with open(self.persist_path, "wb") as f:
                pickle.dump(snapshot, f, protocol=pickle.HIGHEST_PROTOCOL)
        except Exception as e:
            _logger.warning("Failed to save AST cache to disk: %s", e)

    def _load_from_disk(self) -> None:
        """Load cache from disk."""
        if not self.persist_path or not self.persist_path.exists():
            return

        try:
            with open(self.persist_path, "rb") as f:
                data = pickle.load(f)

            with self._lock:
                self._cache = OrderedDict(data.get("cache", {}))
                self._hits = data.get("hits", 0)
                self._misses = data.get("misses", 0)

                # Enforce max size
                while len(self._cache) > self.max_size:
                    self._cache.popitem(last=False)

        except Exception as e:
            _logger.warning("Failed to load AST cache from disk: %s", e)
            with self._lock:
                self._cache.clear()

    def __del__(self):
        """Save cache to disk on destruction."""
        if self.persist_path:
            try:
                self._save_to_disk()
            except Exception:
                pass  # Suppress errors during GC


# Global cache instance
_ast_cache: ASTCache | None = None
_ast_cache_lock = threading.Lock()


def get_ast_cache(
    max_size: int = 1000,
    persist_path: Path | None = None,
) -> ASTCache:
    """Get or create the global AST cache instance (thread-safe).

    Args:
        max_size: Maximum cache size (default: 1000)
        persist_path: Optional persistence path

    Returns:
        Global ASTCache instance
    """
    global _ast_cache

    with _ast_cache_lock:
        if _ast_cache is None:
            _ast_cache = ASTCache(max_size=max_size, persist_path=persist_path)
        return _ast_cache


def clear_ast_cache() -> None:
    """Clear the global AST cache."""
    global _ast_cache
    with _ast_cache_lock:
        if _ast_cache is not None:
            _ast_cache.clear()
