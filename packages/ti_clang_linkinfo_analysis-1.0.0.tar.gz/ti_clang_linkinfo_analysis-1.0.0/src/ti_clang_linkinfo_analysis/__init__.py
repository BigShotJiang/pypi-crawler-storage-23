"""TI Clang linkinfo analysis package."""

from .analyzer import LinkInfoAnalyzer

__all__ = ["LinkInfoAnalyzer"]

__version__ = "0.1.0"
