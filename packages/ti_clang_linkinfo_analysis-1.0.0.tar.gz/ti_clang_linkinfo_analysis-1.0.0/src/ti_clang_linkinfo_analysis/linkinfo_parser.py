"""Legacy module removed.

Use `LinkInfoAnalyzer` from the package root instead.
"""

raise ImportError(
    "linkinfo_parser legacy API was removed. "
    "Use ti_clang_linkinfo_analysis.LinkInfoAnalyzer instead."
)
