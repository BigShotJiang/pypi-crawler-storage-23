"""
API module for Vercel serverless function deployment.
"""
