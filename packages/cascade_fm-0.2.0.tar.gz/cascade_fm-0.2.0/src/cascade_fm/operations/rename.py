"""Rename planning operations."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from cascade_fm.core.cache.cache_none import NoCacheMixin
from cascade_fm.core.i18n import t
from cascade_fm.operations.base import CommitIntent, Operation

_VALID_MODES = ("plain", "find_replace", "regex")


class Rename(NoCacheMixin, Operation):
    """Plan file renaming using a template or search-and-replace.

    Three modes are available:

    - ``plain``:        Template-based rename.  Supports ``{name}``, ``{ext}``,
                        and ``{index}`` placeholders.
    - ``find_replace``: Literal text find-and-replace inside the filename.
    - ``regex``:        Regular-expression find-and-replace.  The replace
                        string accepts ``$1`` / ``${group}`` back-references.
    """

    @property
    def name(self) -> str:
        return "rename"

    @property
    def label(self) -> str:
        return t("op.rename.label")

    @property
    def description(self) -> str:
        return "Rename files using a template or search-and-replace"

    def _can_execute_without_params(self) -> bool:
        return True

    @property
    def commit_intent(self) -> CommitIntent:
        """Rename is virtual and commits via planned output names."""
        return CommitIntent.PLANNED_OUTPUT_NAMES

    def _execute_impl(self, files: list[Path], **params: Any) -> list[Path]:
        mode = str(params.get("mode", "plain"))
        planned_paths: list[Path] = []

        if mode == "plain":
            template = str(params.get("template", "{name}"))
            for index, file_path in enumerate(files, start=1):
                stem = file_path.stem
                ext = file_path.suffix.lstrip(".")
                rendered = template.format(name=stem, ext=ext, index=index)
                if file_path.suffix and "." not in Path(rendered).name:
                    rendered = f"{rendered}{file_path.suffix}"
                planned_paths.append(file_path.parent / rendered)
        else:
            find = str(params.get("find", ""))
            replace = str(params.get("replace", ""))
            for file_path in files:
                new_name = _apply_search_replace(file_path.name, mode, find, replace)
                planned_paths.append(file_path.parent / new_name)

        return planned_paths

    def validate_params(self, **params: Any) -> tuple[bool, str | None]:
        mode = params.get("mode", "plain")

        if mode not in _VALID_MODES:
            return False, f"mode must be one of {_VALID_MODES}, got {mode!r}"

        if mode == "plain":
            template = params.get("template", "{name}")
            if not isinstance(template, str):
                return False, "template must be a string"
            try:
                template.format(name="example", ext="txt", index=1)
            except Exception as error:
                return False, f"Invalid template: {error}"
        else:
            find = params.get("find", "")
            replace = params.get("replace", "")
            if not isinstance(find, str):
                return False, "find must be a string"
            if not isinstance(replace, str):
                return False, "replace must be a string"
            if mode == "regex" and find:
                try:
                    re.compile(find)
                except re.error as e:
                    return False, f"Invalid regex: {e}"

        return True, None


def _apply_search_replace(filename: str, mode: str, find: str, replace: str) -> str:
    """Apply a find-and-replace transformation to a single filename.

    Args:
        filename: The full filename including extension.
        mode: ``'find_replace'`` for literal replacement, ``'regex'`` for regex.
        find: The text or pattern to search for.  Returns original when empty.
        replace: The replacement string.  Supports ``$1`` / ``${name}``
            back-reference syntax in regex mode.

    Returns:
        The transformed filename, or the original when *find* is empty or an
        error occurs.
    """
    if not find:
        return filename

    if mode == "regex":
        # Convert VS-Code-style back-references ($1, ${name}) to Python syntax
        py_replace = re.sub(r"\$\{(\w+)\}", r"\\g<\1>", replace)
        py_replace = re.sub(r"\$(\d+)", r"\\\1", py_replace)
        try:
            return re.sub(find, py_replace, filename)
        except re.error:
            return filename

    return filename.replace(find, replace)
