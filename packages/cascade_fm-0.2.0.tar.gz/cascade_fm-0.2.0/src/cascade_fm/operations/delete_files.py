"""Permanently delete input files from disk."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

from cascade_fm.core.cache.cache_none import NoCacheMixin
from cascade_fm.core.i18n import t
from cascade_fm.operations.base import Operation


class DeleteFiles(NoCacheMixin, Operation):
    """Permanently delete the input files from disk.

    This operation has no output: once executed, the files are gone.
    The UI must obtain explicit user confirmation before execution.
    """

    @property
    def name(self) -> str:
        return "delete_files"

    @property
    def label(self) -> str:
        return t("op.delete_files.label")

    @property
    def description(self) -> str:
        return "Permanently delete the selected files from disk"

    @property
    def accepts(self) -> list[str]:
        return ["*/*"]

    def _execute_impl(self, files: list[Path], **params: Any) -> list[Path]:
        total = len(files)
        for index, path in enumerate(files, start=1):
            self.report_progress(index - 1, total, f"Deleting {path.name}")
            if not path.exists():
                continue
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
            self.report_progress(index, total, f"Deleted {path.name}")

        if total > 0:
            self.report_progress(total, total, "Delete complete")

        return []

    def validate_params(self, **params: Any) -> tuple[bool, str | None]:
        return True, None
