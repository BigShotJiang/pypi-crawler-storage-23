"""Theme constants and shared UI helpers for cascade's PySide6 UI."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtGui import QColor, QPalette

from cascade_fm.core.filetypes import classify_file_type, detect_mime_type
from cascade_fm.operations.registry import get_operation_group_label

# ── Colors ────────────────────────────────────────────────────────────────────

C_BG = QColor(42, 42, 42)
C_BG_DARK = QColor(26, 26, 26)
C_BG_PANE = QColor(34, 34, 34)
C_BASE = QColor(30, 30, 30)
C_TEXT = QColor(229, 229, 229)
C_TEXT_DIM = QColor(136, 136, 136)
C_ACCENT = QColor(48, 112, 160)
C_SUCCESS = QColor(50, 170, 80)
C_ERROR = QColor(210, 60, 50)
C_WARNING = QColor(200, 160, 30)
C_BUTTON = QColor(55, 55, 55)
C_SIDEBAR = QColor(24, 24, 24)

DEFAULT_RESTORE_MAX_AGE_SECONDS = 24 * 60 * 60

# ── Sort options ──────────────────────────────────────────────────────────────

# Each entry is (sort_key, direction).  Use sort_option_label() for display text.
SORT_OPTIONS: list[tuple[str, str]] = [
    ("name", "asc"),
    ("name", "desc"),
    ("created", "asc"),
    ("created", "desc"),
    ("modified", "asc"),
    ("modified", "desc"),
    ("type", "asc"),
    ("type", "desc"),
    ("size", "asc"),
    ("size", "desc"),
]


def sort_option_label(key: str, direction: str) -> str:
    """Return the translated display label for a sort option.

    Args:
        key: Sort key, e.g. ``"name"``, ``"size"``.
        direction: ``"asc"`` or ``"desc"``.
    """
    from cascade_fm.core.i18n import t  # local import — avoids circular at module load

    arrow = "↑" if direction == "asc" else "↓"
    return f"{arrow} {t(f'sort.key.{key}')}"

# ── Helpers ───────────────────────────────────────────────────────────────────


def icon_for_entry(entry: Path) -> str:
    """Return an emoji icon for a path based on its detected MIME type."""
    file_type = classify_file_type(detect_mime_type(entry))
    if file_type == "directory":
        return "📁"
    if file_type == "image":
        return "🖼️"
    if file_type == "video":
        return "🎬"
    if file_type == "audio":
        return "🎵"
    if file_type in {"text", "document"}:
        return "📄"
    return "📦" if entry.suffix.lower() in {".zip", ".tar", ".gz", ".rar"} else "📄"


def group_operations(operations: list[str]) -> dict[str, list[str]]:
    """Group operation names by their MIME-type category label."""
    grouped: dict[str, list[str]] = {}
    for op_name in operations:
        group = get_operation_group_label(op_name)
        grouped.setdefault(group, []).append(op_name)
    return dict(sorted(grouped.items()))


def make_dark_palette() -> QPalette:
    """Build a dark QPalette for the Fusion style."""
    p = QPalette()
    p.setColor(QPalette.ColorRole.Window, C_BG)
    p.setColor(QPalette.ColorRole.WindowText, C_TEXT)
    p.setColor(QPalette.ColorRole.Base, C_BASE)
    p.setColor(QPalette.ColorRole.AlternateBase, QColor(50, 50, 50))
    p.setColor(QPalette.ColorRole.Text, C_TEXT)
    p.setColor(QPalette.ColorRole.BrightText, C_TEXT)
    p.setColor(QPalette.ColorRole.Button, C_BUTTON)
    p.setColor(QPalette.ColorRole.ButtonText, C_TEXT)
    p.setColor(QPalette.ColorRole.Highlight, C_ACCENT)
    p.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
    p.setColor(QPalette.ColorRole.Link, QColor(100, 160, 220))
    p.setColor(QPalette.ColorRole.ToolTipBase, C_BG_DARK)
    p.setColor(QPalette.ColorRole.ToolTipText, C_TEXT)
    p.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.WindowText, C_TEXT_DIM)
    p.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text, C_TEXT_DIM)
    p.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, C_TEXT_DIM)
    return p


def sort_key_for_path(path: Path, key: str) -> tuple:
    """Build a sort key tuple for the given path and sort criterion."""
    is_file = int(not path.is_dir())
    try:
        stat = path.stat()
    except OSError:
        # Fallback must use the same type as the normal branch so that Python
        # can compare keys from different paths without a TypeError.
        match key:
            case "created" | "modified":
                return (is_file, 0.0)
            case "size":
                return (is_file, 0)
            case "type":
                return (is_file, "", "")
            case _:
                return (is_file, "")
    match key:
        case "name":
            return (is_file, path.name.lower())
        case "created":
            created = getattr(stat, "st_birthtime", stat.st_ctime)
            return (is_file, created)
        case "modified":
            return (is_file, stat.st_mtime)
        case "type":
            return (is_file, path.suffix.lower(), path.name.lower())
        case "size":
            size = stat.st_size if path.is_file() else 0
            return (is_file, size)
        case _:
            return (is_file, path.name.lower())


def default_bookmark_folders() -> list[Path]:
    """Return home subdirectories whose names start with an uppercase letter."""
    home = Path.home()
    try:
        return sorted(
            (p for p in home.iterdir() if p.is_dir() and p.name[:1].isupper()),
            key=lambda p: p.name.lower(),
        )
    except OSError:
        return []
