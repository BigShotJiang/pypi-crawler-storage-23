"""Pipeline widget — horizontal container orchestrating browser and operation panes."""

from __future__ import annotations

import re
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path

from PySide6.QtCore import QTimer, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from cascade_fm.core.api import CascadeAPI
from cascade_fm.core.i18n import t
from cascade_fm.core.pipeline import Pipeline
from cascade_fm.core.types import PaneStatus
from cascade_fm.operations.registry import (
    UI_BROWSER_ONLY_OPERATIONS,
    get_operation_info,
    list_operations_for_ui,
)

from .browser_pane import BrowserPane
from .operation_bar import OperationBar
from .operation_pane import OperationPane
from .theme import (
    C_BG_DARK,
    C_ERROR,
    C_SUCCESS,
    C_TEXT,
    C_TEXT_DIM,
)


# ── Pipeline widget ───────────────────────────────────────────────────────────
class PipelineWidget(QWidget):
    """Horizontal container managing the browser + alternating pane/bar layout."""

    _pane_update_requested = Signal(str)
    _pipeline_action_failed = Signal(str)

    def __init__(self, api: CascadeAPI, pipeline: Pipeline, parent=None) -> None:
        """Initialize pipeline widget.

        Args:
            api: Application API instance.
            pipeline: Pipeline state manager.
        """
        super().__init__(parent)
        self.api = api
        self.pipeline = pipeline
        self._show_hidden: bool = False
        self._pipeline_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="cascade")

        self._layout = QHBoxLayout(self)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(0)

        self.browser_pane: BrowserPane | None = None
        self.pane_widgets: dict[str, OperationPane] = {}
        self._pane_selected_files: dict[str, list[Path]] = {}
        self.operation_bars: list[OperationBar] = []
        self._is_restoring = False

        self._pane_update_requested.connect(self._update_pane_display)
        self._pipeline_action_failed.connect(self._handle_pipeline_action_failed)
        self.pipeline.on_pane_updated = self._pane_update_requested.emit
        self._create_browser_pane()

    # ── Pipeline callbacks ────────────────────────────────────────────────────

    def _submit_pipeline_action(self, action) -> None:
        """Run a pipeline mutation in the background worker."""
        future: Future[None] = self._pipeline_executor.submit(action)
        future.add_done_callback(self._on_pipeline_action_done)

    def _on_pipeline_action_done(self, future: Future[None]) -> None:
        """Forward background pipeline errors back to the UI thread."""
        error = future.exception()
        if error is None:
            return
        self._pipeline_action_failed.emit(str(error))

    def _handle_pipeline_action_failed(self, error: str) -> None:
        """Display pipeline worker errors in the browser status area."""
        if self.browser_pane is not None:
            self.browser_pane.set_status_text(t("status.pipeline_error", error=error), C_ERROR)

    def _update_pane_display(self, pane_id: str) -> None:
        """Refresh a pane's status and file list after pipeline execution."""
        if pane_id not in self.pane_widgets:
            return
        pane_widget = self.pane_widgets[pane_id]
        try:
            pane = self.pipeline.get_pane(pane_id)
        except ValueError:
            return
        pane_widget.update_status(pane.status, pane.error)
        if pane.status == PaneStatus.EXECUTING:
            pane_widget.update_progress(
                pane.operation.progress_current,
                pane.operation.progress_total,
                pane.operation.progress_message,
            )
        # When the pane hasn't executed yet, show what will be processed.
        files_to_show = (
            pane.operation.input_files
            if pane.status == PaneStatus.CONFIGURED
            else pane.output_files
        )
        pane_widget.update_files(files_to_show)
        self._refresh_operation_bars()
        # Operations that physically remove or relocate files from the browser's
        # current directory need the file list to be reloaded so deleted / moved
        # files disappear immediately.  Defer with QTimer so this runs after the
        # current update cycle completes (avoids stale operation-bar state).
        _MODIFIES_SOURCE = {"delete_files", "move_to", "save_to"}
        if (
            pane.status == PaneStatus.DONE
            and pane.operation.name in _MODIFIES_SOURCE
            and self.browser_pane is not None
        ):
            browser = self.browser_pane
            QTimer.singleShot(0, browser.refresh)

    # ── Browser pane ──────────────────────────────────────────────────────────

    def _create_browser_pane(self) -> None:
        """Create the file browser as the first (fixed) pane."""
        pane = BrowserPane(on_selection_changed=self._on_browser_selection_changed)
        self.browser_pane = pane
        self._layout.addWidget(pane, 1)
        self._add_operation_bar()

    def _on_browser_selection_changed(self, selected: list[Path]) -> None:
        """Handle file browser selection changes."""
        self._refresh_operation_bars()
        self._submit_pipeline_action(lambda: self.pipeline.update_browser_files(selected))

    # ── Operation bars ────────────────────────────────────────────────────────

    def _add_operation_bar(self) -> None:
        """Append a new operation bar to the right end of the pipeline."""
        bar_index = len(self.operation_bars)
        bar = OperationBar(
            bar_index=bar_index,
            on_operation_selected=self._on_operation_selected,
        )
        bar.update_operations(self._ops_for_bar(bar_index))
        bar.set_hidden_operations_button(self._hidden_ops_for_bar(bar_index))
        self.operation_bars.append(bar)
        self._layout.addWidget(bar, 0)

    def _ops_for_bar(self, bar_index: int) -> list[str]:
        """Return compatible operations for a bar based on upstream output types."""
        if bar_index == 0 and self.browser_pane is not None:
            selected_files = self.browser_pane.selected_files()
            if not selected_files:
                return []
            return list_operations_for_ui(selected_files)

        if bar_index >= len(self.pipeline.panes):
            return []

        source_pane = self.pipeline.panes[bar_index]
        selected_files = self._pane_selected_files.get(source_pane.id, [])
        source_files = selected_files if selected_files else source_pane.output_files
        if not source_files:
            return []
        return [
            op
            for op in list_operations_for_ui(source_files)
            if op not in UI_BROWSER_ONLY_OPERATIONS
        ]

    def _hidden_ops_for_bar(self, bar_index: int) -> list[str]:
        """Return incompatible operations for a bar's 'More…' button."""
        return []

    def _refresh_operation_bars(self) -> None:
        """Refresh all operation bars' button lists."""
        for bar in self.operation_bars:
            bar.update_operations(self._ops_for_bar(bar.bar_index))
            bar.set_hidden_operations_button(self._hidden_ops_for_bar(bar.bar_index))

    # ── Operation selection ───────────────────────────────────────────────────

    def _on_operation_selected(self, bar_index: int, operation: str) -> None:
        """Handle user selecting an operation from a bar."""
        target_pane_index = bar_index + 1  # browser is pane_0
        has_downstream = len(self.pipeline.panes) > (target_pane_index + 1)
        if has_downstream and not self._confirm_switch_with_downstream_loss():
            return

        self._remove_panes_from(bar_index + 1)
        self._remove_bars_from(bar_index + 1)

        pane_id = self.pipeline.switch_operation_at_bar(bar_index, operation)

        # Snapshot the correct upstream files right now in the main thread.
        # For bar 0, that's the browser selection; for later bars it's the
        # output of the upstream operation pane (pane at bar_index in the
        # pipeline, which is already at index bar_index because the browser is
        # pane_0 and operation panes start at pane_1).
        if bar_index == 0:
            input_snapshot: list[Path] = (
                list(self.browser_pane.selected_files()) if self.browser_pane else []
            )
        else:
            # bar_index corresponds to panes[bar_index] (pane_0 is the browser)
            try:
                upstream = self.pipeline.panes[bar_index]
                sel = self._pane_selected_files.get(upstream.id, [])
                input_snapshot = list(sel) if sel else list(upstream.output_files)
            except IndexError:
                input_snapshot = []

        operation_label = operation.replace("_", " ").title()
        try:
            operation_label = get_operation_info(operation)["label"]
        except Exception:
            pass

        op_pane = OperationPane(
            pane_id=pane_id,
            operation_name=operation_label,
            on_selection_changed=lambda selected, pid=pane_id: (
                self._on_operation_pane_selection_changed(pid, selected)
            ),
        )
        op_pane.set_show_hidden(self._show_hidden)
        self._attach_param_input(op_pane, pane_id, operation)
        self.pane_widgets[pane_id] = op_pane
        self._layout.addWidget(op_pane, 1)

        # Pre-populate the file list so the pane shows files immediately:
        # - Non-auto-executing ops (delete, save_to…) before the user clicks Execute
        # - Auto-executing ops get the correct files shown before the async exec completes
        if input_snapshot:
            op_pane.update_files(input_snapshot)
        else:
            try:
                _pane = self.pipeline.get_pane(pane_id)
                op_pane.update_files(_pane.operation.input_files)
            except ValueError:
                pass

        if not self._is_restoring and self._should_auto_execute_operation(operation):
            QTimer.singleShot(
                0,
                lambda pid=pane_id, snap=input_snapshot: self._execute_pane(pid, snap),
            )

        self._add_operation_bar()
        self._refresh_operation_bars()

    def _on_operation_pane_selection_changed(self, pane_id: str, selected: list[Path]) -> None:
        """Track operation-pane selections so downstream operation lists follow selection."""
        self._pane_selected_files[pane_id] = selected
        self._refresh_operation_bars()

    def _confirm_switch_with_downstream_loss(self) -> bool:
        """Ask user confirmation before removing downstream pipeline steps."""
        result = QMessageBox.warning(
            self,
            t("pipeline.replace.title"),
            t("pipeline.replace.message"),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        return result == QMessageBox.StandardButton.Yes

    def _remove_panes_from(self, target_pane_index: int) -> None:
        """Remove all operation pane widgets starting from a pipeline index."""
        panes_to_remove: list[str] = []
        for pane_id in self.pane_widgets:
            try:
                pane_index = int(pane_id.split("_", maxsplit=1)[1])
            except (IndexError, ValueError):
                continue
            if pane_index >= target_pane_index:
                panes_to_remove.append(pane_id)

        for pane_id in panes_to_remove:
            if pane_id in self.pane_widgets:
                widget = self.pane_widgets.pop(pane_id)
                self._pane_selected_files.pop(pane_id, None)
                self._layout.removeWidget(widget)
                widget.deleteLater()

    def _remove_bars_from(self, bar_index: int) -> None:
        """Remove all operation bars starting from a given index."""
        for bar in self.operation_bars[bar_index:]:
            self._layout.removeWidget(bar)
            bar.deleteLater()
        self.operation_bars = self.operation_bars[:bar_index]

    def _should_auto_execute_operation(self, operation_name: str) -> bool:
        """Return whether a newly added operation should execute immediately."""
        # save_to / move_to need explicit user input (destination path + confirmation).
        # rename / delete_files are destructive and must not fire automatically.
        return operation_name not in {"rename", "delete_files", "save_to", "move_to"}

    # ── Parameter input ───────────────────────────────────────────────────────

    def _attach_param_input(self, pane: OperationPane, pane_id: str, operation: str) -> None:
        """Wire an operation-specific input into the pane dialogue section."""
        if operation not in {
            "save_to",
            "move_to",
            "image_transform",
            "create_archive",
            "unarchive",
            "rename",
            "delete_files",
        }:
            return

        if operation == "rename":
            self._attach_rename_controls(pane, pane_id)
            return

        if operation == "image_transform":
            self._attach_image_transform_controls(pane, pane_id)
            return

        if operation == "create_archive":
            self._attach_create_archive_controls(pane, pane_id)
            return

        if operation == "unarchive":
            self._attach_unarchive_controls(pane, pane_id)
            return

        if operation == "delete_files":
            self._attach_delete_controls(pane, pane_id)
            return

        row = QWidget()
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        lbl = QLabel(t("param.target.label"))
        lbl.setFixedWidth(78)
        lbl.setStyleSheet(f"color: {C_TEXT.name()};")
        row_layout.addWidget(lbl)

        inp = QLineEdit("")
        inp.setPlaceholderText(t("param.target.placeholder"))
        row_layout.addWidget(inp)

        pane.add_dialogue_widget(row)
        pane.param_input = inp

        if operation in {"save_to", "move_to"}:
            if self.browser_pane is not None:
                inp.setText(str(self.browser_pane.current_path()))

            pick_btn = QPushButton("…")
            pick_btn.setFixedWidth(34)
            pick_btn.setToolTip(t("param.target.tooltip"))
            row_layout.addWidget(pick_btn)
            pick_btn.clicked.connect(lambda: self._select_target_directory(inp))

            policy_row = QWidget()
            policy_layout = QHBoxLayout(policy_row)
            policy_layout.setContentsMargins(0, 0, 0, 0)
            policy_label = QLabel(t("param.conflict.label"))
            policy_label.setFixedWidth(78)
            policy_label.setStyleSheet(f"color: {C_TEXT.name()};")
            policy_layout.addWidget(policy_label)

            policy_combo = QComboBox()
            policy_combo.addItem(t("param.conflict.overwrite"), "overwrite")
            policy_combo.addItem(t("param.conflict.skip"), "skip")
            policy_combo.addItem(t("param.conflict.fail"), "fail")
            policy_combo.setCurrentIndex(1)
            policy_layout.addWidget(policy_combo)
            pane.add_dialogue_widget(policy_row)
            pane.save_conflict_policy_combo = policy_combo

            btn_label = t("action.move") if operation == "move_to" else t("action.save")
            action_btn = QPushButton(btn_label)
            action_btn.setStyleSheet(
                f"QPushButton {{ background-color: {C_SUCCESS.darker(150).name()}; "
                f"border: 1px solid {C_SUCCESS.darker(120).name()}; border-radius: 3px; "
                f"color: {C_TEXT.name()}; font-weight: bold; padding: 6px 10px; }}"
                f"QPushButton:hover {{ background-color: {C_SUCCESS.darker(120).name()}; }}"
            )
            action_btn.clicked.connect(lambda: self._execute_pane(pane_id))
            pane.add_dialogue_widget(action_btn)
            pane.save_button = action_btn
            return

        inp.returnPressed.connect(lambda: self._execute_pane(pane_id))
        inp.editingFinished.connect(lambda: self._execute_pane(pane_id))

    def _attach_rename_controls(self, pane: OperationPane, pane_id: str) -> None:
        """Attach mode, template/find/replace controls for the rename operation."""
        # ── Mode row ──
        mode_row = QWidget()
        mode_layout = QHBoxLayout(mode_row)
        mode_layout.setContentsMargins(0, 0, 0, 0)
        mode_lbl = QLabel(t("rename.mode.label"))
        mode_lbl.setFixedWidth(78)
        mode_lbl.setStyleSheet(f"color: {C_TEXT.name()};")
        mode_layout.addWidget(mode_lbl)
        mode_combo = QComboBox()
        mode_combo.addItem(t("rename.mode.plain"), "plain")
        mode_combo.addItem(t("rename.mode.find_replace"), "find_replace")
        mode_combo.addItem(t("rename.mode.regex"), "regex")
        mode_layout.addWidget(mode_combo)
        pane.add_dialogue_widget(mode_row)
        pane.rename_mode_combo = mode_combo

        # ── Template row (plain mode only) ──
        template_row = QWidget()
        template_layout = QHBoxLayout(template_row)
        template_layout.setContentsMargins(0, 0, 0, 0)
        template_lbl = QLabel(t("rename.template.label"))
        template_lbl.setFixedWidth(78)
        template_lbl.setStyleSheet(f"color: {C_TEXT.name()};")
        template_layout.addWidget(template_lbl)
        template_input = QLineEdit("{name}")
        template_input.setPlaceholderText("{name}  {ext}  {index}")
        template_layout.addWidget(template_input)
        pane.add_dialogue_widget(template_row)
        pane.rename_template_input = template_input
        pane.rename_template_row = template_row

        plain_hint = QLabel("{name}  ·  {ext}  ·  {index}")
        plain_hint.setStyleSheet(
            f"color: {C_TEXT_DIM.name()}; font-size: 10px; font-family: monospace;"
        )
        pane.add_dialogue_widget(plain_hint)
        pane.rename_plain_hint = plain_hint

        # ── Find row (search & replace / regex modes) ──
        find_row = QWidget()
        find_layout = QHBoxLayout(find_row)
        find_layout.setContentsMargins(0, 0, 0, 0)
        find_lbl = QLabel(t("rename.find.label"))
        find_lbl.setFixedWidth(78)
        find_lbl.setStyleSheet(f"color: {C_TEXT.name()};")
        find_layout.addWidget(find_lbl)
        find_input = QLineEdit()
        find_input.setPlaceholderText(t("rename.find.placeholder"))
        find_layout.addWidget(find_input)
        find_row.setVisible(False)
        pane.add_dialogue_widget(find_row)
        pane.rename_find_input = find_input
        pane.rename_find_row = find_row

        # ── Replace row (search & replace / regex modes) ──
        replace_row = QWidget()
        replace_layout = QHBoxLayout(replace_row)
        replace_layout.setContentsMargins(0, 0, 0, 0)
        replace_lbl = QLabel(t("rename.replace.label"))
        replace_lbl.setFixedWidth(78)
        replace_lbl.setStyleSheet(f"color: {C_TEXT.name()};")
        replace_layout.addWidget(replace_lbl)
        replace_input = QLineEdit()
        replace_input.setPlaceholderText(t("rename.replace.placeholder"))
        replace_layout.addWidget(replace_input)
        replace_row.setVisible(False)
        pane.add_dialogue_widget(replace_row)
        pane.rename_replace_input = replace_input
        pane.rename_replace_row = replace_row

        # ── Regex helper panel (hidden until regex mode is active) ──
        regex_panel = QWidget()
        regex_panel_layout = QVBoxLayout(regex_panel)
        regex_panel_layout.setContentsMargins(0, 4, 0, 0)
        regex_panel_layout.setSpacing(0)
        regex_lbl = QLabel()
        regex_lbl.setWordWrap(True)
        regex_lbl.setStyleSheet(
            f"color: {C_TEXT_DIM.name()}; font-size: 10px; "
            "font-family: monospace; padding: 4px 6px; "
            f"background: {C_BG_DARK.name()}; border-radius: 3px;"
        )
        regex_panel_layout.addWidget(regex_lbl)
        regex_panel.setVisible(False)
        pane.add_dialogue_widget(regex_panel)
        pane.rename_regex_panel = regex_panel
        pane.rename_regex_label = regex_lbl

        # ── Wire signals ──
        def _on_execute() -> None:
            self._execute_pane(pane_id)

        def _update_visibility() -> None:
            mode = mode_combo.currentData()
            is_plain = mode == "plain"
            template_row.setVisible(is_plain)
            plain_hint.setVisible(is_plain)
            find_row.setVisible(not is_plain)
            replace_row.setVisible(not is_plain)
            if mode == "regex":
                replace_input.setPlaceholderText(t("rename.replace.regex_placeholder"))
            else:
                replace_input.setPlaceholderText(t("rename.replace.placeholder"))
            if mode != "regex":
                regex_panel.setVisible(False)

        def _on_mode_changed() -> None:
            _update_visibility()
            if mode_combo.currentData() == "regex":
                _update_regex_helper()
            _on_execute()

        def _update_regex_helper() -> None:
            if mode_combo.currentData() != "regex":
                return
            try:
                pane_obj = self.pipeline.get_pane(pane_id)
                samples = [p.name for p in pane_obj.operation.input_files[:3]]
            except (ValueError, AttributeError):
                samples = []
            explanation = _explain_regex_pattern(find_input.text(), samples)
            regex_lbl.setText(explanation)
            regex_panel.setVisible(bool(explanation))

        mode_combo.currentIndexChanged.connect(_on_mode_changed)
        find_input.textChanged.connect(_update_regex_helper)
        find_input.returnPressed.connect(_on_execute)
        find_input.editingFinished.connect(_on_execute)
        replace_input.returnPressed.connect(_on_execute)
        replace_input.editingFinished.connect(_on_execute)
        template_input.returnPressed.connect(_on_execute)
        template_input.editingFinished.connect(_on_execute)

    def _attach_image_transform_controls(self, pane: OperationPane, pane_id: str) -> None:
        """Attach action + value controls for unified image transform operation."""
        action_row = QWidget()
        action_layout = QHBoxLayout(action_row)
        action_layout.setContentsMargins(0, 0, 0, 0)

        action_lbl = QLabel(t("image.action.label"))
        action_lbl.setFixedWidth(78)
        action_lbl.setStyleSheet(f"color: {C_TEXT.name()};")
        action_layout.addWidget(action_lbl)

        action_combo = QComboBox()
        for action in ["resize", "convert", "rotate", "compress", "strip_exif"]:
            action_combo.addItem(action, action)
        action_layout.addWidget(action_combo)
        pane.add_dialogue_widget(action_row)

        value_row = QWidget()
        value_layout = QHBoxLayout(value_row)
        value_layout.setContentsMargins(0, 0, 0, 0)

        value_lbl = QLabel(t("image.value.label"))
        value_lbl.setFixedWidth(78)
        value_lbl.setStyleSheet(f"color: {C_TEXT.name()};")
        value_layout.addWidget(value_lbl)

        value_input = QLineEdit("1920")
        value_layout.addWidget(value_input)
        pane.add_dialogue_widget(value_row)
        pane.param_input = value_input

        pane.transform_action_combo = action_combo
        pane.transform_value_input = value_input

        def _on_action_changed() -> None:
            action = str(action_combo.currentData())
            defaults = {
                "resize": ("1920", "width or widthxheight"),
                "convert": ("PNG", "PNG, JPEG, WEBP"),
                "rotate": ("90", "90, 180, 270"),
                "compress": ("80", "1-100"),
                "strip_exif": ("", "no value needed"),
            }
            default_value, placeholder = defaults[action]
            value_input.setPlaceholderText(placeholder)
            value_input.setText(default_value)

        _on_action_changed()
        action_combo.currentIndexChanged.connect(_on_action_changed)
        action_combo.currentIndexChanged.connect(lambda: self._execute_pane(pane_id))
        value_input.returnPressed.connect(lambda: self._execute_pane(pane_id))
        value_input.editingFinished.connect(lambda: self._execute_pane(pane_id))

    def _attach_unarchive_controls(self, pane: OperationPane, pane_id: str) -> None:
        """Attach controls for unarchive operation options."""
        checkbox = QCheckBox(t("unarchive.flatten.label"))
        checkbox.setChecked(True)
        checkbox.setStyleSheet(f"color: {C_TEXT.name()};")
        checkbox.toggled.connect(lambda: self._execute_pane(pane_id))
        pane.add_dialogue_widget(checkbox)
        pane.unarchive_flatten_checkbox = checkbox

        hint = QLabel(t("unarchive.flatten.hint"))
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {C_TEXT_DIM.name()}; font-size: 10px;")
        pane.add_dialogue_widget(hint)

    def _attach_delete_controls(self, pane: OperationPane, pane_id: str) -> None:
        """Attach a danger-styled delete button that confirms before executing."""
        warning = QLabel(t("delete.warning"))
        warning.setWordWrap(True)
        warning.setStyleSheet(f"color: {C_ERROR.name()}; font-size: 11px;")
        pane.add_dialogue_widget(warning)

        btn = QPushButton(t("action.delete"))
        btn.setStyleSheet(
            f"QPushButton {{ background-color: {C_ERROR.darker(150).name()}; "
            f"border: 1px solid {C_ERROR.darker(120).name()}; border-radius: 3px; "
            f"color: {C_TEXT.name()}; font-weight: bold; padding: 6px 10px; }}"
            f"QPushButton:hover {{ background-color: {C_ERROR.darker(120).name()}; }}"
        )

        def _on_delete_clicked() -> None:
            try:
                pane_obj = self.pipeline.get_pane(pane_id)
                files = list(pane_obj.operation.input_files)
            except (ValueError, AttributeError):
                files = []

            if not files:
                from PySide6.QtWidgets import QMessageBox

                QMessageBox.information(self, t("delete.empty.title"), t("delete.empty.message"))
                return

            names = "\n".join(f"  {p.name}" for p in files[:20])
            if len(files) > 20:
                names += f"\n  … and {len(files) - 20} more"

            from PySide6.QtWidgets import QMessageBox

            result = QMessageBox.warning(
                self,
                t("delete.confirm.title"),
                t("delete.confirm.message", n=len(files), names=names),
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Cancel,
            )
            if result == QMessageBox.StandardButton.Yes:
                self._execute_pane(pane_id)

        btn.clicked.connect(_on_delete_clicked)
        pane.add_dialogue_widget(btn)

    def _attach_create_archive_controls(self, pane: OperationPane, pane_id: str) -> None:
        """Attach controls for create_archive operation options."""
        name_row = QWidget()
        name_layout = QHBoxLayout(name_row)
        name_layout.setContentsMargins(0, 0, 0, 0)

        name_label = QLabel(t("archive.name.label"))
        name_label.setFixedWidth(78)
        name_label.setStyleSheet(f"color: {C_TEXT.name()};")
        name_layout.addWidget(name_label)

        name_input = QLineEdit(t("archive.name.default"))
        name_input.setPlaceholderText(t("archive.name.placeholder"))
        name_layout.addWidget(name_input)
        pane.add_dialogue_widget(name_row)

        format_row = QWidget()
        format_layout = QHBoxLayout(format_row)
        format_layout.setContentsMargins(0, 0, 0, 0)

        format_label = QLabel(t("archive.format.label"))
        format_label.setFixedWidth(78)
        format_label.setStyleSheet(f"color: {C_TEXT.name()};")
        format_layout.addWidget(format_label)

        format_combo = QComboBox()
        format_combo.addItem("zip", "zip")
        format_combo.addItem("tar", "tar")
        format_combo.addItem("tar.gz", "gztar")
        format_combo.addItem("tar.bz2", "bztar")
        format_combo.addItem("tar.xz", "xztar")
        format_layout.addWidget(format_combo)
        pane.add_dialogue_widget(format_row)

        pane.archive_name_input = name_input
        pane.archive_format_combo = format_combo
        name_input.returnPressed.connect(lambda: self._execute_pane(pane_id))
        name_input.editingFinished.connect(lambda: self._execute_pane(pane_id))
        format_combo.currentIndexChanged.connect(lambda: self._execute_pane(pane_id))

    def _select_target_directory(self, input_widget: QLineEdit) -> None:
        """Open directory picker and populate target folder field."""
        current = input_widget.text().strip()
        start_dir = current if current else str(Path.home())
        selected = QFileDialog.getExistingDirectory(self, t("pipeline.select_folder"), start_dir)
        if not selected:
            return
        input_widget.setText(selected)

    # ── Execution ─────────────────────────────────────────────────────────────

    def _resolve_input_override(
        self, pane_id: str, input_snapshot: list[Path] | None
    ) -> list[Path] | None:
        """Return the input file list to use for executing a pane.

        Args:
            pane_id: Pane being executed.
            input_snapshot: Pre-captured snapshot from click time, or None for
                a live read (e.g. explicit button presses).

        Returns:
            File list to pass as ``set_input_files``, or None to leave the
            operation's existing ``input_files`` unchanged.
        """
        if input_snapshot is not None:
            return input_snapshot or None
        previous_pane = self.pipeline.get_previous_pane(pane_id)
        if previous_pane is None:
            return None
        if previous_pane.id == "pane_0" and self.browser_pane is not None:
            selected = self.browser_pane.selected_files()
        else:
            selected = self._pane_selected_files.get(previous_pane.id, [])
        return list(selected) if selected else None

    def _execute_pane(self, pane_id: str, input_snapshot: list[Path] | None = None) -> None:
        """Extract UI params and trigger operation execution via pipeline.

        Args:
            pane_id: Pane to execute.
            input_snapshot: Pre-captured input file list (taken at click time) to
                use instead of re-reading the live browser/pane selection.  When
                None the live selection is read at call time (e.g. explicit
                button presses by the user).
        """
        if pane_id not in self.pane_widgets:
            return
        params = self._extract_pane_params(pane_id)
        if params is None:
            return
        try:
            pane = self.pipeline.get_pane(pane_id)
        except ValueError:
            return

        selected_override = self._resolve_input_override(pane_id, input_snapshot)

        self.pane_widgets[pane_id].update_status(PaneStatus.EXECUTING)

        def _apply_execution() -> None:
            if selected_override is not None:
                pane.operation.set_input_files(selected_override)
            self.pipeline.set_pane_params(pane.id, params)

        self._submit_pipeline_action(_apply_execution)

    def _extract_pane_params(self, pane_id: str) -> dict | None:
        """Build a params dict from the pane's UI input widget."""
        pane_widget = self.pane_widgets.get(pane_id)
        if pane_widget is None:
            return None

        try:
            pane = self.pipeline.get_pane(pane_id)
        except ValueError:
            return None

        if pane.operation.name == "unarchive":
            return self._extract_unarchive_params(pane_widget)

        if pane.operation.name == "delete_files":
            return {}

        if pane.operation.name == "rename":
            return self._extract_rename_params(pane_widget)

        if not hasattr(pane_widget, "param_input") or pane_widget.param_input is None:
            return {}

        val = pane_widget.param_input.text().strip()

        if pane.operation.name in {"save_to", "move_to"}:
            return self._extract_save_to_params(pane_widget, pane_id, val)

        if pane.operation.name == "image_transform":
            return self._extract_image_transform_params(pane_widget)

        if pane.operation.name == "create_archive":
            return self._extract_create_archive_params(pane_widget)

        return _parse_param_value(pane.operation.name, val)

    def _extract_rename_params(self, pane_widget: OperationPane) -> dict:
        """Extract rename-specific params from the pane widget."""
        mode_combo = pane_widget.rename_mode_combo
        mode = mode_combo.currentData() if mode_combo is not None else "plain"

        if mode == "plain":
            template_input = pane_widget.rename_template_input
            template = template_input.text() if template_input is not None else "{name}"
            return {"mode": "plain", "template": template}

        find_input = pane_widget.rename_find_input
        replace_input = pane_widget.rename_replace_input
        find = find_input.text().strip() if find_input is not None else ""
        replace = replace_input.text() if replace_input is not None else ""
        return {"mode": mode, "find": find, "replace": replace}

    def _extract_unarchive_params(self, pane_widget: OperationPane) -> dict:
        """Extract unarchive-specific params from the pane widget."""
        flatten_single_root = True
        checkbox = getattr(pane_widget, "unarchive_flatten_checkbox", None)
        if checkbox is not None:
            flatten_single_root = bool(checkbox.isChecked())
        return {"flatten_single_root": flatten_single_root}

    def _extract_save_to_params(
        self,
        pane_widget: OperationPane,
        pane_id: str,
        target_dir: str,
    ) -> dict:
        """Extract save_to-specific params from the pane widget and upstream pane."""
        conflict_policy = "skip"
        policy_combo = getattr(pane_widget, "save_conflict_policy_combo", None)
        if policy_combo is not None:
            current = policy_combo.currentData()
            if isinstance(current, str):
                conflict_policy = current
        if not target_dir:
            return {}

        params: dict[str, object] = {
            "target_dir": target_dir,
            "conflict_policy": conflict_policy,
        }

        previous_pane = self.pipeline.get_previous_pane(pane_id)
        if previous_pane and previous_pane.operation.name == "rename":
            params["planned_source_files"] = [
                str(path) for path in previous_pane.operation.input_files
            ]
            params["planned_output_names"] = [str(path.name) for path in previous_pane.output_files]

        return params

    def _extract_image_transform_params(self, pane_widget: OperationPane) -> dict | None:
        """Extract image_transform-specific params from the pane widget."""
        action_combo = getattr(pane_widget, "transform_action_combo", None)
        value_input = getattr(pane_widget, "transform_value_input", None)
        if action_combo is None or value_input is None:
            return None

        action = str(action_combo.currentData())
        value = value_input.text().strip()
        return _parse_image_transform_params(action, value)

    def _extract_create_archive_params(self, pane_widget: OperationPane) -> dict | None:
        """Extract create_archive-specific params from the pane widget."""
        name_input = getattr(pane_widget, "archive_name_input", None)
        format_combo = getattr(pane_widget, "archive_format_combo", None)
        if name_input is None or format_combo is None:
            return None

        archive_name = name_input.text().strip() or "archive"
        archive_format_data = format_combo.currentData()
        archive_format = archive_format_data if isinstance(archive_format_data, str) else "zip"
        return {
            "archive_name": archive_name,
            "format": archive_format,
        }

    def set_show_hidden(self, show_hidden: bool) -> None:
        """Set hidden-file visibility across browser and all operation panes."""
        self._show_hidden = show_hidden
        if self.browser_pane is not None:
            self.browser_pane.set_show_hidden(show_hidden)
        for pane_widget in self.pane_widgets.values():
            pane_widget.set_show_hidden(show_hidden)

    def cancel_workflow(self) -> None:
        """Remove all configured operation steps and keep only browser state."""
        selected_files: list[Path] = []
        if self.browser_pane is not None:
            selected_files = self.browser_pane.selected_files()

        for pane_id in list(self.pane_widgets.keys()):
            widget = self.pane_widgets.pop(pane_id)
            self._pane_selected_files.pop(pane_id, None)
            self._layout.removeWidget(widget)
            widget.deleteLater()

        self._remove_bars_from(0)
        self.pipeline.panes = []
        self.pipeline.update_browser_files(selected_files)
        self._add_operation_bar()
        self._refresh_operation_bars()

    def snapshot_pipeline(self) -> dict[str, object]:
        """Serialize current operation pipeline for workflow/session persistence."""
        panes_payload: list[dict[str, object]] = []
        for pane in self.pipeline.panes:
            operation_name = pane.operation.name
            if operation_name == "browse_files":
                continue
            panes_payload.append(
                {
                    "id": pane.id,
                    "operation": operation_name,
                    "params": dict(pane.operation.params),
                }
            )

        browser_state = self._snapshot_browser_state()

        return {
            "id": "session",
            "browser": browser_state,
            "panes": panes_payload,
        }

    def _snapshot_browser_state(self) -> dict[str, object]:
        """Serialize browser context using pipeline state as primary source for selection."""
        if self.browser_pane is None:
            return {}

        selected_files: list[Path] = []
        if self.pipeline.panes and self.pipeline.panes[0].operation.name == "browse_files":
            selected_files = list(self.pipeline.panes[0].operation.output_files)
        if not selected_files:
            selected_files = self.browser_pane.selected_files()

        return {
            "path": str(self.browser_pane.current_path()),
            "selected_files": [str(path) for path in selected_files],
        }

    def restore_pipeline(self, snapshot: dict[str, object]) -> bool:
        """Restore operation panes from a serialized workflow/session snapshot."""
        raw_panes = snapshot.get("panes")
        if not isinstance(raw_panes, list):
            return False

        self.cancel_workflow()

        pending_browser_selection = self._restore_browser_snapshot(snapshot)
        restored_any = self._restore_operation_panes(raw_panes)

        if pending_browser_selection and self.browser_pane is not None:
            self.browser_pane.select_files(pending_browser_selection)
            self._submit_pipeline_action(
                lambda files=list(pending_browser_selection): self.pipeline.update_browser_files(
                    files
                )
            )

        return restored_any

    def _restore_browser_snapshot(self, snapshot: dict[str, object]) -> list[Path]:
        """Restore browser path context and return pending file selection to re-apply."""
        browser_payload = snapshot.get("browser")
        if not isinstance(browser_payload, dict) or self.browser_pane is None:
            return []

        path_value = browser_payload.get("path")
        if isinstance(path_value, str) and path_value:
            self.browser_pane.navigate(Path(path_value), add_to_history=True)

        selected = browser_payload.get("selected_files")
        if not isinstance(selected, list):
            return []

        return [Path(value) for value in selected if isinstance(value, str)]

    def _restore_operation_panes(self, raw_panes: list[object]) -> bool:
        """Restore operation panes and params from serialized payload list."""
        restored_any = False
        target_bar_index = 0
        self._is_restoring = True
        try:
            for pane_payload in raw_panes:
                if not isinstance(pane_payload, dict):
                    continue

                operation_name = pane_payload.get("operation")
                if not isinstance(operation_name, str) or not operation_name:
                    continue

                self._on_operation_selected(target_bar_index, operation_name)
                pane_id = f"pane_{target_bar_index + 1}"
                pane_widget = self.pane_widgets.get(pane_id)

                params = pane_payload.get("params")
                if isinstance(params, dict):
                    if pane_widget is not None:
                        self._apply_params_to_pane_widgets(pane_widget, operation_name, params)
                    self._submit_pipeline_action(
                        lambda pid=pane_id, payload=dict(params): self.pipeline.set_pane_params(
                            pid, payload
                        )
                    )

                restored_any = True
                target_bar_index += 1
        finally:
            self._is_restoring = False

        return restored_any

    def _apply_params_to_pane_widgets(
        self,
        pane_widget: OperationPane,
        operation_name: str,
        params: dict[str, object],
    ) -> None:
        """Apply restored operation params into pane input widgets."""
        if operation_name == "rename":
            self._apply_rename_params(pane_widget, params)
            return

        if operation_name in {"save_to", "move_to"}:
            self._apply_save_to_params(pane_widget, params)
            return

        if operation_name == "image_transform":
            self._apply_image_transform_params(pane_widget, params)
            return

        if operation_name == "create_archive":
            self._apply_create_archive_params(pane_widget, params)
            return

        if operation_name == "unarchive":
            self._apply_unarchive_params(pane_widget, params)

    def _apply_rename_params(self, pane_widget: OperationPane, params: dict[str, object]) -> None:  # noqa: C901
        """Apply restore payload for rename inputs."""
        mode_combo = pane_widget.rename_mode_combo
        mode = params.get("mode", "plain")
        if mode_combo is not None and isinstance(mode, str):
            index = mode_combo.findData(mode)
            if index >= 0:
                mode_combo.blockSignals(True)
                mode_combo.setCurrentIndex(index)
                mode_combo.blockSignals(False)

        is_plain = mode == "plain"
        template_row = pane_widget.rename_template_row
        plain_hint = pane_widget.rename_plain_hint
        find_row = pane_widget.rename_find_row
        replace_row = pane_widget.rename_replace_row
        if template_row is not None:
            template_row.setVisible(is_plain)
        if plain_hint is not None:
            plain_hint.setVisible(is_plain)
        if find_row is not None:
            find_row.setVisible(not is_plain)
        if replace_row is not None:
            replace_row.setVisible(not is_plain)

        if is_plain:
            template = params.get("template", "{name}")
            template_input = pane_widget.rename_template_input
            if template_input is not None and isinstance(template, str):
                template_input.setText(template)
        else:
            find = params.get("find", "")
            replace = params.get("replace", "")
            find_input = pane_widget.rename_find_input
            replace_input = pane_widget.rename_replace_input
            if find_input is not None and isinstance(find, str):
                find_input.setText(find)
            if replace_input is not None and isinstance(replace, str):
                replace_input.setText(replace)

    def _apply_save_to_params(self, pane_widget: OperationPane, params: dict[str, object]) -> None:
        """Apply restore payload for save_to inputs."""
        input_widget = pane_widget.param_input
        target_dir = params.get("target_dir")
        if input_widget is not None and isinstance(target_dir, str):
            input_widget.setText(target_dir)

        policy_combo = pane_widget.save_conflict_policy_combo
        conflict_policy = params.get("conflict_policy")
        if policy_combo is not None and isinstance(conflict_policy, str):
            index = policy_combo.findData(conflict_policy)
            if index >= 0:
                policy_combo.setCurrentIndex(index)

    def _apply_image_transform_params(
        self,
        pane_widget: OperationPane,
        params: dict[str, object],
    ) -> None:
        """Apply restore payload for image_transform controls."""
        action_combo = pane_widget.transform_action_combo
        value_input = pane_widget.transform_value_input
        action = params.get("action")

        if action_combo is not None and isinstance(action, str):
            action_combo.blockSignals(True)
            index = action_combo.findData(action)
            if index >= 0:
                action_combo.setCurrentIndex(index)
            action_combo.blockSignals(False)

        if value_input is None or not isinstance(action, str):
            return

        value = self._image_transform_value_from_params(action, params)
        if value is not None:
            value_input.setText(value)

    def _image_transform_value_from_params(
        self,
        action: str,
        params: dict[str, object],
    ) -> str | None:
        """Build image-transform value field text from restored params."""
        if action == "resize":
            width = params.get("width")
            height = params.get("height")
            if isinstance(width, int) and isinstance(height, int):
                return f"{width}x{height}"
            if isinstance(width, int):
                return str(width)
            return None

        if action == "convert":
            image_format = params.get("format")
            return image_format if isinstance(image_format, str) else None

        if action == "rotate":
            angle = params.get("angle")
            return str(angle) if isinstance(angle, int) else None

        if action == "compress":
            quality = params.get("quality")
            return str(quality) if isinstance(quality, int) else None

        if action == "strip_exif":
            return ""

        return None

    def _apply_create_archive_params(
        self,
        pane_widget: OperationPane,
        params: dict[str, object],
    ) -> None:
        """Apply restore payload for create_archive controls."""
        name_input = pane_widget.archive_name_input
        archive_name = params.get("archive_name")
        if name_input is not None and isinstance(archive_name, str):
            name_input.setText(archive_name)

        format_combo = pane_widget.archive_format_combo
        archive_format = params.get("format")
        if format_combo is not None and isinstance(archive_format, str):
            index = format_combo.findData(archive_format)
            if index >= 0:
                format_combo.setCurrentIndex(index)

    def _apply_unarchive_params(
        self, pane_widget: OperationPane, params: dict[str, object]
    ) -> None:
        """Apply restore payload for unarchive controls."""
        checkbox = pane_widget.unarchive_flatten_checkbox
        flatten = params.get("flatten_single_root")
        if checkbox is not None and isinstance(flatten, bool):
            checkbox.setChecked(flatten)


# ── Module-level param helpers ────────────────────────────────────────────────


def _parse_param_value(operation_name: str, val: str) -> dict:
    """Parse a raw text input value into an operation params dict.

    Args:
        operation_name: Name of the operation whose param is being parsed.
        val: Raw string from the UI input field.

    Returns:
        Dictionary of parsed parameter values, or empty dict if input is blank.
    """
    return {}


def _parse_image_transform_params(action: str, value: str) -> dict:
    """Parse params for image_transform action/value controls."""
    if action == "resize":
        if not value:
            return {"action": "resize", "width": 1920}
        if "x" in value.lower():
            left, right = value.lower().split("x", maxsplit=1)
            if left.strip().isdigit() and right.strip().isdigit():
                return {
                    "action": "resize",
                    "width": int(left.strip()),
                    "height": int(right.strip()),
                }
            return {"action": "resize"}
        return (
            {"action": "resize", "width": int(value)} if value.isdigit() else {"action": "resize"}
        )

    if action == "convert":
        return (
            {"action": "convert", "format": value.upper()}
            if value
            else {"action": "convert", "format": "PNG"}
        )

    if action == "rotate":
        return (
            {"action": "rotate", "angle": int(value)} if value.isdigit() else {"action": "rotate"}
        )

    if action == "compress":
        return (
            {"action": "compress", "quality": int(value)}
            if value.isdigit()
            else {"action": "compress"}
        )

    if action == "strip_exif":
        return {"action": "strip_exif"}

    return {"action": action}


# ── Regex explanation helpers ─────────────────────────────────────────────────


def _explain_regex_pattern(pattern: str, sample_filenames: list[str] | None = None) -> str:  # noqa: C901
    """Return a human-readable explanation of a regex pattern for inline display.

    Args:
        pattern: The raw regex string entered by the user.
        sample_filenames: Up to 3 filenames from the current pane to match against.

    Returns:
        A multi-line string with validity, live match preview, capture-group
        references, and a token-by-token breakdown.  Empty string when *pattern*
        is blank.
    """
    if not pattern.strip():
        return ""

    try:
        compiled = re.compile(pattern)
    except re.error as e:
        return f"\u2717  Invalid:  {e}"

    sections: list[str] = []

    # ── 1. Live match preview ──
    if sample_filenames:
        preview_lines: list[str] = []
        for name in sample_filenames:
            m = compiled.search(name)
            if m:
                groups = m.groups()
                if groups:
                    captured = "  ".join(
                        f'${i + 1}="{g}"' for i, g in enumerate(groups) if g is not None
                    )
                    preview_lines.append(f"  ✓  {name!r}  →  {captured}")
                else:
                    preview_lines.append(f"  ✓  {name!r}  →  matches")
            else:
                preview_lines.append(f"  ✗  {name!r}  →  no match")
        sections.append("Match preview:\n" + "\n".join(preview_lines))

    # ── 2. Capture-group reference table ──
    num_groups = compiled.groups
    named_groups = compiled.groupindex
    reverse_named = {v: k for k, v in named_groups.items()}
    if num_groups:
        noun = "Capture group" if num_groups == 1 else "Capture groups"
        ref_lines = [f"{noun}  (use in Replace as $1, $2 …):"]
        for i in range(1, num_groups + 1):
            gname = reverse_named.get(i)
            if gname:
                ref_lines.append(f"  ${i}  or  ${{{gname}}}  →  group {i}  (named '{gname}')")
            else:
                ref_lines.append(f"  ${i}  →  group {i}")
        sections.append("\n".join(ref_lines))
    elif not sample_filenames:
        sections.append("No capture groups  —  wrap  ( )  around parts to reuse them in Replace")

    # ── 3. Token breakdown ──
    token_lines = _describe_regex_tokens(pattern)
    if token_lines:
        sections.append("Pattern tokens:\n" + "\n".join(f"  {t}" for t in token_lines))

    return "\n\n".join(sections)


_REGEX_TOKEN_RE = re.compile(
    r"(?P<named_group>\(\?P<(?P<gname>\w+)>)"
    r"|(?P<nc_group>\(\?:)"
    r"|(?P<group_open>\()"
    r"|(?P<group_close>\)(?P<gq>[+*?]?(?:\?)?)?)"
    r"|(?P<anchor_start>\^)"
    r"|(?P<anchor_end>\$)"
    r"|(?P<shorthand>\\(?P<sh>[dDwWsS])(?P<shq>[+*?](?:\?)?)?)"
    r"|(?P<escaped>\\(?P<ec>.)(?P<escq>[+*?](?:\?)?)?)"
    r"|(?P<char_class>\[(?P<cc>[^\]]+)\](?P<ccq>[+*?](?:\?)?)?)"
    r"|(?P<dot_q>\.(?P<dq>[+*?](?:\?)?))"
    r"|(?P<dot>\.)"
    r"|(?P<literal>[^\\^$.()?*+\[\]{}|]+)(?P<litq>[+*?](?:\?)?)?"
)

_SHORTHAND_NAMES: dict[str, str] = {
    "d": "digit (0-9)",
    "D": "non-digit",
    "w": "word char (letter, digit, _)",
    "W": "non-word char",
    "s": "whitespace",
    "S": "non-whitespace",
}

_QUANT_LABELS: dict[str, str] = {
    "+": "1 or more",
    "+?": "1 or more (lazy)",
    "*": "0 or more",
    "*?": "0 or more (lazy)",
    "?": "optional",
    "??": "optional (lazy)",
}


def _quant(q: str | None) -> str:
    return f"  [{_QUANT_LABELS.get(q, q)}]" if q else ""


def _describe_regex_tokens(pattern: str) -> list[str]:  # noqa: C901
    """Return a list of human-readable token descriptions for *pattern*."""
    lines: list[str] = []
    group_counter = 0
    pos = 0
    while pos < len(pattern):
        m = _REGEX_TOKEN_RE.match(pattern, pos)
        if m is None:
            pos += 1
            continue
        pos = m.end()
        kind = m.lastgroup
        if kind is None:
            continue

        if kind == "named_group":
            group_counter += 1
            gname = m.group("gname")
            lines.append(f"(?P<{gname}>  start capture group ${group_counter} named '{gname}'")
        elif kind == "nc_group":
            lines.append("(?:  start non-capturing group  (not referenceable)")
        elif kind == "group_open":
            group_counter += 1
            lines.append(f"(   start capture group ${group_counter}")
        elif kind == "group_close":
            q = m.group("gq") or ""
            lines.append(f")   end group{_quant(q)}")
        elif kind == "anchor_start":
            lines.append("^   start of filename")
        elif kind == "anchor_end":
            lines.append("$   end of filename")
        elif kind == "shorthand":
            sh = m.group("sh")
            q = m.group("shq") or ""
            desc = _SHORTHAND_NAMES.get(sh, sh)
            lines.append(f"\\{sh}  {desc}{_quant(q)}")
        elif kind == "escaped":
            ec = m.group("ec")
            q = m.group("escq") or ""
            lines.append(f"\\{ec}  literal '{ec}'{_quant(q)}")
        elif kind == "char_class":
            cc = m.group("cc")
            q = m.group("ccq") or ""
            neg = cc.startswith("^")
            label = f"any char {'not' if neg else ''} in [{cc}]".strip()
            lines.append(f"[{cc}]  {label}{_quant(q)}")
        elif kind == "dot_q":
            q = m.group("dq")
            lines.append(f".{q}  any character{_quant(q)}")
        elif kind == "dot":
            lines.append(".   any single character")
        elif kind == "literal":
            lit = m.group(0)
            litq = m.group("litq") or ""
            if litq:
                lit = lit[: -len(litq)]
            if len(lit) == 1:
                lines.append(f"'{lit}'  literal character{_quant(litq)}")
            elif lit:
                lines.append(f"'{lit}'  literal text{_quant(litq)}")
    return lines
