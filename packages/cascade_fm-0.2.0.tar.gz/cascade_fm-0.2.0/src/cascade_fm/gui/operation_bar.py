"""Operation bar widget — narrow vertical strip of operation buttons between panes."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QPalette
from PySide6.QtWidgets import (
    QFrame,
    QLabel,
    QMenu,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from cascade_fm.core.i18n import t
from cascade_fm.operations.registry import get_operation_info

from .theme import C_ACCENT, C_TEXT, C_TEXT_DIM, group_operations


class OperationBar(QWidget):
    """Narrow vertical bar with operation buttons between panes."""

    def __init__(self, bar_index: int, on_operation_selected, parent=None) -> None:
        """Initialize operation bar.

        Args:
            bar_index: Position index of this bar in the pipeline.
            on_operation_selected: Callback(bar_index, operation_name).
        """
        super().__init__(parent)
        self.bar_index = bar_index
        self._on_operation_selected = on_operation_selected
        self._more_btn: QPushButton | None = None

        self.setFixedWidth(115)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        self.setAutoFillBackground(True)
        pal = self.palette()
        pal.setColor(QPalette.ColorRole.Window, C_TEXT_DIM.darker(600))
        self.setPalette(pal)

        self._outer = QVBoxLayout(self)
        self._outer.setContentsMargins(4, 8, 4, 8)
        self._outer.setSpacing(4)

        hdr = QLabel(t("op.bar.header"))
        hdr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hdr.setStyleSheet(f"color: {C_TEXT_DIM.name()}; font-size: 10px; font-weight: bold;")
        self._outer.addWidget(hdr)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._btn_widget = QWidget()
        self._btn_layout = QVBoxLayout(self._btn_widget)
        self._btn_layout.setContentsMargins(0, 0, 0, 0)
        self._btn_layout.setSpacing(3)
        scroll.setWidget(self._btn_widget)
        self._outer.addWidget(scroll)

    def update_operations(self, operation_names: list[str]) -> None:
        """Rebuild the operation button list."""
        while self._btn_layout.count():
            item = self._btn_layout.takeAt(0)
            if item is None:
                continue
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        grouped = group_operations(operation_names)
        for group_name, ops in grouped.items():
            lbl = QLabel(group_name)
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl.setWordWrap(True)
            lbl.setStyleSheet(f"color: {C_TEXT_DIM.name()}; font-size: 10px;")
            self._btn_layout.addWidget(lbl)
            for op_name in ops:
                self._add_operation_button(op_name)

        if not operation_names:
            lbl = QLabel(t("op.bar.none"))
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl.setStyleSheet(f"color: {C_TEXT_DIM.name()};")
            self._btn_layout.addWidget(lbl)

        self._btn_layout.addStretch()

    def _add_operation_button(self, op_name: str) -> None:
        """Add a single operation button to the button list."""
        try:
            display = get_operation_info(op_name)["label"]
        except KeyError:
            display = op_name.replace("_", " ").title()
        btn = QPushButton(display)
        btn.setFixedHeight(40)
        btn.setStyleSheet(
            f"QPushButton {{ background-color: {C_ACCENT.darker(120).name()}; "
            f"border: 1px solid {C_ACCENT.name()}; border-radius: 3px; "
            f"color: {C_TEXT.name()}; font-size: 10px; }}"
            f"QPushButton:hover {{ background-color: {C_ACCENT.name()}; }}"
        )
        btn.clicked.connect(
            lambda _checked, op=op_name: self._on_operation_selected(self.bar_index, op)
        )
        self._btn_layout.addWidget(btn)

    def set_hidden_operations_button(self, hidden_operations: list[str]) -> None:
        """Show or remove the 'More…' overflow button."""
        if self._more_btn is not None:
            self._outer.removeWidget(self._more_btn)
            self._more_btn.deleteLater()
            self._more_btn = None

        if not hidden_operations:
            return

        btn = QPushButton("More…")
        btn.setFixedHeight(30)
        btn.clicked.connect(lambda: self._show_more_menu(hidden_operations, btn))
        self._more_btn = btn
        self._outer.addWidget(btn)

    def _show_more_menu(self, hidden_operations: list[str], anchor: QWidget) -> None:
        """Show a popup menu listing hidden (incompatible) operations."""
        menu = QMenu(self)
        for group_name, ops in group_operations(hidden_operations).items():
            menu.addSection(group_name)
            for op_name in ops:
                display = op_name.replace("_", " ").title()
                action = menu.addAction(display)
                action.triggered.connect(
                    lambda _checked, op=op_name: self._on_operation_selected(self.bar_index, op)
                )
        menu.exec(anchor.mapToGlobal(anchor.rect().bottomLeft()))
