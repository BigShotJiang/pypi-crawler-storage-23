"""Main window and application entry point for the cascade desktop application."""

from __future__ import annotations

import importlib.resources
import os
import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QCloseEvent, QIcon, QPainter, QPalette, QPixmap
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from cascade_fm.core.api import CascadeAPI
from cascade_fm.core.config import ensure_config_initialized, save_config
from cascade_fm.core.i18n import set_language, t
from cascade_fm.core.pipeline import Pipeline
from cascade_fm.core.temp_session import cleanup_temp_session, init_temp_session

from .config_dialog import ConfigDialog
from .pipeline_widget import PipelineWidget
from .theme import (
    C_ACCENT,
    C_SIDEBAR,
    C_TEXT,
    C_TEXT_DIM,
    DEFAULT_RESTORE_MAX_AGE_SECONDS,
    default_bookmark_folders,
    make_dark_palette,
)


class CascadeWindow(QMainWindow):
    """Main application window."""

    def __init__(self) -> None:
        """Initialize the main window with pipeline widget."""
        super().__init__()
        self.resize(1300, 750)
        self.setMinimumSize(800, 500)

        self.api = CascadeAPI()
        self._config = ensure_config_initialized()
        set_language(self._config.language)
        self._restore_max_age_seconds = self._read_restore_max_age_seconds()
        pipeline = Pipeline()

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        self.setWindowTitle(t("app.title"))

        # Narrow sidebar
        sidebar = QWidget()
        sidebar.setFixedWidth(140)
        sidebar.setAutoFillBackground(True)
        pal = sidebar.palette()
        pal.setColor(QPalette.ColorRole.Window, C_SIDEBAR)
        sidebar.setPalette(pal)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(6, 6, 6, 6)
        sidebar_layout.setSpacing(3)

        # Action buttons row
        action_row = QHBoxLayout()
        action_row.setSpacing(3)
        self._hidden_btn = QPushButton("👁")
        self._hidden_btn.setFixedWidth(30)
        self._hidden_btn.setFixedHeight(30)
        self._hidden_btn.setCheckable(True)
        self._hidden_btn.setToolTip(t("sidebar.show_hidden.tooltip"))
        action_row.addWidget(self._hidden_btn)
        cancel_btn = QPushButton("✕")
        cancel_btn.setFixedWidth(30)
        cancel_btn.setFixedHeight(30)
        cancel_btn.setToolTip(t("sidebar.cancel.tooltip"))
        action_row.addWidget(cancel_btn)
        settings_btn = QPushButton("⚙")
        settings_btn.setFixedWidth(30)
        settings_btn.setFixedHeight(30)
        settings_btn.setToolTip(t("sidebar.preferences.tooltip"))
        action_row.addWidget(settings_btn)
        sidebar_layout.addLayout(action_row)

        # Separator
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFixedHeight(1)
        sep.setStyleSheet(f"background-color: {C_TEXT_DIM.darker(150).name()}; border: none;")
        sidebar_layout.addWidget(sep)

        # Bookmarks label
        bm_lbl = QLabel(t("sidebar.bookmarks"))
        bm_lbl.setStyleSheet(f"color: {C_TEXT_DIM.name()}; font-size: 10px; font-weight: bold;")
        sidebar_layout.addWidget(bm_lbl)

        # Scrollable bookmark buttons
        bm_scroll = QScrollArea()
        bm_scroll.setWidgetResizable(True)
        bm_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        bm_scroll.setFrameShape(QFrame.Shape.NoFrame)
        bm_widget = QWidget()
        self._bm_layout = QVBoxLayout(bm_widget)
        self._bm_layout.setContentsMargins(0, 0, 0, 0)
        self._bm_layout.setSpacing(2)
        bm_layout = self._bm_layout
        _bm_btn_style = (
            f"QPushButton {{ background-color: transparent; border: none; "
            f"border-radius: 3px; color: {C_TEXT_DIM.name()}; "
            f"font-size: 11px; text-align: left; padding: 0 4px; }}"
            f"QPushButton:hover {{ background-color: {C_ACCENT.darker(140).name()}; "
            f"color: {C_TEXT.name()}; }}"
        )
        home_bm_btn = QPushButton("🏠  Home")
        home_bm_btn.setFixedHeight(26)
        home_bm_btn.setToolTip(str(Path.home()))
        home_bm_btn.setStyleSheet(_bm_btn_style)
        bm_layout.addWidget(home_bm_btn)
        bm_scroll.setWidget(bm_widget)
        sidebar_layout.addWidget(bm_scroll)
        main_layout.addWidget(sidebar)

        # Horizontal-scrolling pipeline area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setFrameShape(QFrame.Shape.NoFrame)

        self.pipeline_widget = PipelineWidget(api=self.api, pipeline=pipeline)
        self.pipeline_widget.setSizePolicy(
            QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Expanding
        )
        scroll.setWidget(self.pipeline_widget)
        main_layout.addWidget(scroll)

        self._hidden_btn.toggled.connect(self._on_toggle_hidden_files)
        cancel_btn.clicked.connect(self._on_cancel_workflow)
        settings_btn.clicked.connect(self._open_config_dialog)

        # Wire home + bookmark buttons to the browser pane
        browser = self.pipeline_widget.browser_pane
        if browser is not None:
            home_bm_btn.clicked.connect(lambda: browser.navigate(Path.home()))
            self._rebuild_bookmarks()

            # Apply config defaults
            browser.set_sort(self._config.default_sort_key, self._config.default_sort_direction)
            start = self._config.start_dir_path()
            if start != Path.home() and start.exists():
                browser.navigate(start)

        # Apply hidden-files default (triggers toggle handler via signal)
        if self._config.show_hidden_files:
            self._hidden_btn.setChecked(True)

        self._maybe_restore_last_session()

    def _on_toggle_hidden_files(self, checked: bool) -> None:
        """Handle sidebar hidden-files toggle."""
        self.pipeline_widget.set_show_hidden(checked)

    def _on_cancel_workflow(self) -> None:
        """Handle sidebar cancel workflow action."""
        self.pipeline_widget.cancel_workflow()
        self.api.delete_workflow("__last_session__")

    def _maybe_restore_last_session(self) -> None:
        """Restore last saved session according to the session-restore config."""
        if self._config.session_restore == "disabled":
            return

        age_seconds = self.api.get_workflow_age_seconds("__last_session__")
        if age_seconds is None:
            return
        if age_seconds > self._restore_max_age_seconds:
            browser_pane = self.pipeline_widget.browser_pane
            if browser_pane is not None:
                hours = age_seconds / 3600
                browser_pane.set_status_text(
                    t("session.restore.skipped", hours=f"{hours:.1f}"),
                    C_TEXT_DIM,
                )
            return

        loaded = self.api.load_workflow("__last_session__")
        panes = loaded.get("panes")
        if not isinstance(panes, list) or not panes:
            return

        if self._config.session_restore == "auto":
            self.pipeline_widget.restore_pipeline(loaded)
            return

        # "prompt" — ask the user
        result = QMessageBox.question(
            self,
            t("session.restore.title"),
            t("session.restore.message"),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )
        if result != QMessageBox.StandardButton.Yes:
            self.api.delete_workflow("__last_session__")
            return

        self.pipeline_widget.restore_pipeline(loaded)

    def closeEvent(self, event: QCloseEvent) -> None:
        """Persist last session snapshot when the main window closes."""
        snapshot = self.pipeline_widget.snapshot_pipeline()
        self.api.save_workflow("__last_session__", snapshot)
        super().closeEvent(event)

    def _read_restore_max_age_seconds(self) -> float:
        """Determine max restore age: env var overrides config, falling back to default."""
        raw_value = os.getenv("CASCADE_RESTORE_MAX_AGE_SECONDS", "")
        if raw_value:
            try:
                return max(0.0, float(raw_value))
            except ValueError:
                pass
        if hasattr(self, "_config"):
            return self._config.session_restore_max_age_seconds()
        return float(DEFAULT_RESTORE_MAX_AGE_SECONDS)

    def _rebuild_bookmarks(self) -> None:
        """Clear and repopulate the sidebar bookmark buttons from current config."""
        browser = self.pipeline_widget.browser_pane

        # Remove all widgets except the Home button (index 0) and the stretch
        while self._bm_layout.count() > 1:
            item = self._bm_layout.takeAt(1)
            if item is not None:
                w = item.widget()
                if w is not None:
                    w.deleteLater()

        bm_style = (
            f"QPushButton {{ background-color: transparent; border: none; "
            f"border-radius: 3px; color: {C_TEXT_DIM.name()}; "
            f"font-size: 11px; text-align: left; padding: 0 4px; }}"
            f"QPushButton:hover {{ background-color: {C_ACCENT.darker(140).name()}; "
            f"color: {C_TEXT.name()}; }}"
        )

        if self._config.bookmarks is not None:
            folders = [Path(b) for b in self._config.bookmarks]
        else:
            folders = default_bookmark_folders()

        for folder in folders:
            btn = QPushButton(folder.name)
            btn.setFixedHeight(26)
            btn.setToolTip(str(folder))
            btn.setStyleSheet(bm_style)
            if browser is not None:
                btn.clicked.connect(lambda _c, p=folder: browser.navigate(p))
            self._bm_layout.addWidget(btn)

        self._bm_layout.addStretch()

    def _open_config_dialog(self) -> None:
        """Open the preferences dialogue and apply changes on accept."""
        dialog = ConfigDialog(self._config, parent=self)
        if dialog.exec() != ConfigDialog.DialogCode.Accepted:
            return

        self._config = dialog.get_config()
        save_config(self._config)

        # Apply settings that take effect immediately
        browser = self.pipeline_widget.browser_pane
        if browser is not None:
            browser.set_sort(self._config.default_sort_key, self._config.default_sort_direction)
        self._hidden_btn.setChecked(self._config.show_hidden_files)
        self._restore_max_age_seconds = self._read_restore_max_age_seconds()
        self._rebuild_bookmarks()


# ── Entry point ───────────────────────────────────────────────────────────────


def launch() -> int:
    """Launch the cascade PySide6 desktop application.

    Returns:
        Application exit code.
    """
    app_instance = QApplication.instance()
    app = app_instance if isinstance(app_instance, QApplication) else QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setPalette(make_dark_palette())
    app.setApplicationName("cascade")
    app.setDesktopFileName("cascade")

    icon_path = importlib.resources.files("cascade_fm.assets").joinpath("icon.svg")
    with importlib.resources.as_file(icon_path) as icon_file:
        renderer = QSvgRenderer(str(icon_file))
        pixmap = QPixmap(256, 256)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        renderer.render(painter)
        painter.end()
    app_icon = QIcon(pixmap)
    app.setWindowIcon(app_icon)

    init_temp_session()
    app.aboutToQuit.connect(cleanup_temp_session)

    window = CascadeWindow()
    window.setWindowIcon(app_icon)
    window.show()
    return app.exec()
