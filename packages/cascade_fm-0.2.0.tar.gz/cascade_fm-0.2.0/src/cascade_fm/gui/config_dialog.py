"""Configuration dialog for cascade application preferences."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QPushButton,
    QRadioButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from cascade_fm.core.config import AppConfig
from cascade_fm.core.i18n import available_languages, t

from .theme import C_TEXT, C_TEXT_DIM, default_bookmark_folders


class ConfigDialog(QDialog):
    """Modal settings dialogue with tabs for General, Session, and Bookmarks."""

    def __init__(self, config: AppConfig, parent: QWidget | None = None) -> None:
        """Initialise the config dialog with the current application config.

        Args:
            config: Current config object (not mutated; a copy is returned on accept).
            parent: Optional parent widget.
        """
        super().__init__(parent)
        self.setWindowTitle(t("prefs.title"))
        self.setMinimumWidth(480)
        self.setMinimumHeight(360)
        self.setModal(True)

        self._config = config

        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.setSpacing(8)

        tabs = QTabWidget()
        tabs.addTab(self._build_general_tab(config), t("prefs.tab.general"))
        tabs.addTab(self._build_session_tab(config), t("prefs.tab.session"))
        tabs.addTab(self._build_bookmarks_tab(config), t("prefs.tab.bookmarks"))
        outer.addWidget(tabs)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color: {C_TEXT_DIM.name()};")
        outer.addWidget(sep)

        btn_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btn_box.accepted.connect(self.accept)
        btn_box.rejected.connect(self.reject)
        outer.addWidget(btn_box)

    # ── Tab builders ──────────────────────────────────────────────────────────

    def _build_general_tab(self, config: AppConfig) -> QWidget:
        """Build the General preferences tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(8, 12, 8, 8)
        layout.setSpacing(10)

        # Start directory
        layout.addWidget(_section_label(t("prefs.general.start_dir")))
        start_row = QHBoxLayout()
        self._start_dir_input = _line_edit_styled(str(config.start_dir))
        start_row.addWidget(self._start_dir_input)
        browse_btn = QPushButton("…")
        browse_btn.setFixedWidth(32)
        browse_btn.setToolTip(t("prefs.general.start_dir.browse.tooltip"))
        browse_btn.clicked.connect(self._browse_start_dir)
        start_row.addWidget(browse_btn)
        layout.addLayout(start_row)

        # Default sort
        layout.addWidget(_section_label(t("prefs.general.sort")))
        sort_row = QHBoxLayout()
        self._sort_key_combo = QComboBox()
        for key in ("name", "created", "modified", "type", "size"):
            self._sort_key_combo.addItem(t(f"sort.key.{key}"), key)
        _select_combo_data(self._sort_key_combo, config.default_sort_key)
        sort_row.addWidget(self._sort_key_combo)

        self._sort_dir_combo = QComboBox()
        self._sort_dir_combo.addItem(t("prefs.general.sort.asc"), "asc")
        self._sort_dir_combo.addItem(t("prefs.general.sort.desc"), "desc")
        _select_combo_data(self._sort_dir_combo, config.default_sort_direction)
        sort_row.addWidget(self._sort_dir_combo)
        sort_row.addStretch()
        layout.addLayout(sort_row)

        # Show hidden files
        self._show_hidden_cb = QCheckBox(t("prefs.general.show_hidden"))
        self._show_hidden_cb.setChecked(config.show_hidden_files)
        layout.addWidget(self._show_hidden_cb)

        # Language
        lang_row = QHBoxLayout()
        lang_lbl = QLabel(t("prefs.general.language"))
        lang_lbl.setStyleSheet(f"color: {C_TEXT.name()};")
        lang_row.addWidget(lang_lbl)
        self._lang_combo = QComboBox()
        for code, display in available_languages():
            self._lang_combo.addItem(display, code)
        _select_combo_data(self._lang_combo, config.language)
        lang_row.addWidget(self._lang_combo)
        lang_row.addStretch()
        layout.addLayout(lang_row)

        restart_note = QLabel(t("prefs.general.language_restart"))
        restart_note.setStyleSheet(f"color: {C_TEXT_DIM.name()}; font-size: 11px;")
        restart_note.setWordWrap(True)
        layout.addWidget(restart_note)

        layout.addStretch()
        return widget

    def _build_session_tab(self, config: AppConfig) -> QWidget:
        """Build the Session restore tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(8, 12, 8, 8)
        layout.setSpacing(8)

        layout.addWidget(_section_label(t("prefs.session.restore")))

        self._restore_prompt_radio = QRadioButton(t("prefs.session.restore.prompt"))
        self._restore_auto_radio = QRadioButton(t("prefs.session.restore.auto"))
        self._restore_off_radio = QRadioButton(t("prefs.session.restore.disabled"))

        _group = QButtonGroup(widget)
        for rb in (self._restore_prompt_radio, self._restore_auto_radio, self._restore_off_radio):
            _group.addButton(rb)
            layout.addWidget(rb)

        {
            "prompt": self._restore_prompt_radio,
            "auto": self._restore_auto_radio,
            "disabled": self._restore_off_radio,
        }.get(config.session_restore, self._restore_prompt_radio).setChecked(True)

        # Age limit row
        age_row = QHBoxLayout()
        age_lbl = QLabel(t("prefs.session.age"))
        age_lbl.setStyleSheet(f"color: {C_TEXT_DIM.name()};")
        age_row.addWidget(age_lbl)

        self._age_spinbox = QDoubleSpinBox()
        self._age_spinbox.setRange(0.0, 8760.0)  # up to 1 year
        self._age_spinbox.setSingleStep(1.0)
        self._age_spinbox.setDecimals(1)
        self._age_spinbox.setValue(config.session_restore_max_age_hours)
        self._age_spinbox.setFixedWidth(90)
        age_row.addWidget(self._age_spinbox)
        age_row.addStretch()
        layout.addLayout(age_row)

        # Hide age row when session restore is disabled
        def _update_age_visibility() -> None:
            enabled = not self._restore_off_radio.isChecked()
            age_lbl.setEnabled(enabled)
            self._age_spinbox.setEnabled(enabled)

        _update_age_visibility()
        self._restore_off_radio.toggled.connect(lambda _: _update_age_visibility())
        self._restore_auto_radio.toggled.connect(lambda _: _update_age_visibility())
        self._restore_prompt_radio.toggled.connect(lambda _: _update_age_visibility())

        layout.addStretch()
        return widget

    def _build_bookmarks_tab(self, config: AppConfig) -> QWidget:
        """Build the Bookmarks management tab."""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(8, 12, 8, 8)
        layout.setSpacing(6)

        layout.addWidget(_section_label(t("prefs.bookmarks.title")))
        hint = QLabel(t("prefs.bookmarks.hint"))
        hint.setStyleSheet(f"color: {C_TEXT_DIM.name()}; font-size: 11px;")
        hint.setWordWrap(True)
        layout.addWidget(hint)

        self._bm_list = QListWidget()
        layout.addWidget(self._bm_list)

        # Always show an explicit list — fall back to auto-detected defaults
        entries = (
            config.bookmarks
            if config.bookmarks is not None
            else [str(f) for f in default_bookmark_folders()]
        )
        for bm in entries:
            self._bm_list.addItem(bm)

        btn_row = QHBoxLayout()
        add_btn = QPushButton(t("prefs.bookmarks.add"))
        add_btn.clicked.connect(self._add_bookmark)
        btn_row.addWidget(add_btn)

        remove_btn = QPushButton(t("prefs.bookmarks.remove"))
        remove_btn.clicked.connect(self._remove_bookmark)
        btn_row.addWidget(remove_btn)

        up_btn = QPushButton(t("prefs.bookmarks.up"))
        up_btn.clicked.connect(self._move_bookmark_up)
        btn_row.addWidget(up_btn)

        down_btn = QPushButton(t("prefs.bookmarks.down"))
        down_btn.clicked.connect(self._move_bookmark_down)
        btn_row.addWidget(down_btn)

        btn_row.addStretch()

        reset_btn = QPushButton(t("prefs.bookmarks.reset"))
        reset_btn.setToolTip(t("prefs.bookmarks.reset.tooltip"))
        reset_btn.clicked.connect(self._reset_bookmarks)
        btn_row.addWidget(reset_btn)

        layout.addLayout(btn_row)
        return widget

    # ── Actions ───────────────────────────────────────────────────────────────

    def _browse_start_dir(self) -> None:
        """Open a directory picker and fill the start-dir input."""
        current = Path(self._start_dir_input.text()).expanduser()
        if not current.exists():
            current = Path.home()
        chosen = QFileDialog.getExistingDirectory(
            self, t("prefs.general.start_dir.dialog"), str(current)
        )
        if chosen:
            self._start_dir_input.setText(chosen)

    def _add_bookmark(self) -> None:
        """Open a directory picker and add it to the bookmarks list."""
        chosen = QFileDialog.getExistingDirectory(
            self, t("prefs.bookmarks.add.dialog"), str(Path.home())
        )
        if chosen and not self._bm_list.findItems(chosen, Qt.MatchFlag.MatchExactly):
            self._bm_list.addItem(chosen)

    def _remove_bookmark(self) -> None:
        """Remove the selected bookmark from the list."""
        row = self._bm_list.currentRow()
        if row >= 0:
            self._bm_list.takeItem(row)

    def _move_bookmark_up(self) -> None:
        """Move the selected bookmark one position up."""
        row = self._bm_list.currentRow()
        if row > 0:
            item = self._bm_list.takeItem(row)
            self._bm_list.insertItem(row - 1, item)
            self._bm_list.setCurrentRow(row - 1)

    def _move_bookmark_down(self) -> None:
        """Move the selected bookmark one position down."""
        row = self._bm_list.currentRow()
        if row < self._bm_list.count() - 1:
            item = self._bm_list.takeItem(row)
            self._bm_list.insertItem(row + 1, item)
            self._bm_list.setCurrentRow(row + 1)

    def _reset_bookmarks(self) -> None:
        """Repopulate the bookmarks list with auto-detected home sub-folders."""
        self._bm_list.clear()
        for folder in default_bookmark_folders():
            self._bm_list.addItem(str(folder))

    # ── Result ────────────────────────────────────────────────────────────────

    def get_config(self) -> AppConfig:
        """Return an ``AppConfig`` reflecting the dialog's current values.

        Call this after the dialog has been accepted.
        """
        session_restore = "prompt"
        if self._restore_auto_radio.isChecked():
            session_restore = "auto"
        elif self._restore_off_radio.isChecked():
            session_restore = "disabled"

        bm_count = self._bm_list.count()
        bookmarks = [self._bm_list.item(i).text() for i in range(bm_count)]

        return AppConfig(
            start_dir=self._start_dir_input.text().strip() or "~",
            default_sort_key=self._sort_key_combo.currentData() or "name",
            default_sort_direction=self._sort_dir_combo.currentData() or "asc",
            show_hidden_files=self._show_hidden_cb.isChecked(),
            session_restore=session_restore,
            session_restore_max_age_hours=self._age_spinbox.value(),
            bookmarks=bookmarks,
            language=self._lang_combo.currentData() or "en",
        )


# ── Helpers ───────────────────────────────────────────────────────────────────


def _section_label(text: str) -> QLabel:
    """Return a styled section-header label."""
    lbl = QLabel(text)
    lbl.setStyleSheet(f"color: {C_TEXT.name()}; font-weight: bold; font-size: 12px;")
    return lbl


def _line_edit_styled(text: str) -> QLineEdit:
    return QLineEdit(text)


def _select_combo_data(combo: QComboBox, data: str) -> None:
    """Select the item in *combo* whose user data matches *data*."""
    for i in range(combo.count()):
        if combo.itemData(i) == data:
            combo.setCurrentIndex(i)
            return
