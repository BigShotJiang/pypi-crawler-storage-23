"""Backward-compatible entry point — imports from reorganised modules."""

from .main_window import CascadeWindow, launch  # noqa: F401

__all__ = ["CascadeWindow", "launch"]
