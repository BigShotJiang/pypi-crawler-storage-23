"""Browser pane widget — filesystem navigator, always first in the pipeline."""

from __future__ import annotations

from fnmatch import fnmatch
from pathlib import Path

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QColor, QDesktopServices, QPalette
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from cascade_fm.core.filetypes import classify_file_type, detect_mime_type, summarize_file_types
from cascade_fm.core.i18n import t
from cascade_fm.core.system_open import open_in_default_app

from .theme import (
    C_ACCENT,
    C_BG_PANE,
    C_ERROR,
    C_SUCCESS,
    C_TEXT,
    C_TEXT_DIM,
    SORT_OPTIONS,
    icon_for_entry,
    sort_key_for_path,
    sort_option_label,
)


class BrowserPane(QFrame):
    """File-system browser pane (always the first pane in the pipeline UI)."""

    def __init__(self, on_selection_changed, parent=None) -> None:
        """Initialize browser pane.

        Args:
            on_selection_changed: Callback(list[Path]) called when selection changes.
        """
        super().__init__(parent)
        self._on_selection_changed = on_selection_changed
        self._current_path: Path = Path.home()
        self._entries: list[Path] = []
        self._show_hidden: bool = False
        self._history: list[Path] = []
        self._history_index: int = -1
        self._name_filter: str = ""
        self._type_filter: str = "all"
        self._sort_key: str = "name"
        self._sort_direction: str = "asc"
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setAutoFillBackground(True)
        pal = self.palette()
        pal.setColor(QPalette.ColorRole.Window, C_BG_PANE)
        self.setPalette(pal)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.setSpacing(4)

        hdr = QLabel(t("browser.title"))
        hdr.setStyleSheet(f"color: {C_TEXT.name()}; font-weight: bold; font-size: 13px;")
        layout.addWidget(hdr)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFixedHeight(2)
        sep.setStyleSheet(f"background-color: {C_ACCENT.name()}; border: none;")
        layout.addWidget(sep)

        # Path bar
        path_row = QHBoxLayout()
        self._path_input = QLineEdit(str(Path.home()))
        self._path_input.returnPressed.connect(self._on_path_entered)
        path_row.addWidget(self._path_input)
        layout.addLayout(path_row)

        # Toolbar row
        toolbar = QHBoxLayout()
        self._back_btn = QPushButton("←")
        self._back_btn.setFixedWidth(36)
        self._back_btn.setToolTip(t("browser.back.tooltip"))
        self._back_btn.clicked.connect(self._go_back)
        toolbar.addWidget(self._back_btn)

        self._forward_btn = QPushButton("→")
        self._forward_btn.setFixedWidth(36)
        self._forward_btn.setToolTip(t("browser.forward.tooltip"))
        self._forward_btn.clicked.connect(self._go_forward)
        toolbar.addWidget(self._forward_btn)

        up_btn = QPushButton("↑")
        up_btn.setFixedWidth(36)
        up_btn.setToolTip(t("browser.up.tooltip"))
        up_btn.clicked.connect(self._go_up)
        toolbar.addWidget(up_btn)

        select_all_btn = QPushButton(t("browser.select_all"))
        select_all_btn.clicked.connect(self._select_all)
        toolbar.addWidget(select_all_btn)

        toolbar.addStretch()

        self._sort_btn = QPushButton("↑ Name ▾")
        self._sort_btn.setFixedWidth(95)
        self._sort_btn.setToolTip(t("browser.sort.tooltip"))
        self._sort_btn.clicked.connect(lambda: self._show_sort_menu(self._sort_btn))
        toolbar.addWidget(self._sort_btn)

        layout.addLayout(toolbar)

        filter_row = QHBoxLayout()
        self._name_filter_input = QLineEdit()
        self._name_filter_input.setPlaceholderText(t("browser.filter.name.placeholder"))
        self._name_filter_input.textChanged.connect(self._on_filter_changed)
        filter_row.addWidget(self._name_filter_input)

        self._type_filter_combo = QComboBox()
        self._type_filter_combo.setFixedWidth(180)
        self._type_filter_combo.addItem(t("filetype.all"), "all")
        self._type_filter_combo.addItem(t("filetype.directory"), "directory")
        self._type_filter_combo.addItem(t("filetype.image"), "image")
        self._type_filter_combo.addItem(t("filetype.video"), "video")
        self._type_filter_combo.addItem(t("filetype.audio"), "audio")
        self._type_filter_combo.addItem(t("filetype.text"), "text")
        self._type_filter_combo.addItem(t("filetype.document"), "document")
        self._type_filter_combo.addItem(t("filetype.other"), "other")
        self._type_filter_combo.currentIndexChanged.connect(self._on_filter_changed)
        filter_row.addWidget(self._type_filter_combo)
        layout.addLayout(filter_row)

        # Status
        self._status = QLabel(t("status.ready"))
        self._status.setStyleSheet(f"color: {C_TEXT_DIM.name()}; font-size: 11px;")
        layout.addWidget(self._status)

        # File list — native multi-select, double-click to navigate
        self._list = QListWidget()
        self._list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self._list.setAlternatingRowColors(True)
        self._list.itemDoubleClicked.connect(self._on_double_clicked)
        self._list.itemSelectionChanged.connect(self._on_selection_changed_internal)
        layout.addWidget(self._list)

        self._count = QLabel(t("browser.count_selected", n=0))
        self._count.setStyleSheet(f"color: {C_TEXT_DIM.name()}; font-size: 10px;")
        layout.addWidget(self._count)

        self.navigate(Path.home(), add_to_history=True)

    def navigate(self, path: Path, add_to_history: bool = True) -> None:
        """Navigate to a directory, populating the file list.

        Args:
            path: Directory path to navigate to.
        """
        target = path.expanduser()
        if not target.exists() or not target.is_dir():
            self._set_status(t("browser.invalid_path", path=path), C_ERROR)
            return

        self._current_path = target
        self._path_input.setText(str(target))

        self._entries = self._apply_sort(list(target.iterdir()))
        if not self._show_hidden:
            self._entries = [entry for entry in self._entries if not entry.name.startswith(".")]
        self._entries = self._apply_filters(self._entries)

        if add_to_history:
            if self._history_index < len(self._history) - 1:
                self._history = self._history[: self._history_index + 1]
            if not self._history or self._history[-1] != target:
                self._history.append(target)
                self._history_index = len(self._history) - 1

        self._list.blockSignals(True)
        self._list.clear()
        for entry in self._entries:
            icon = icon_for_entry(entry)
            name = f"{entry.name}/" if entry.is_dir() else entry.name
            item = QListWidgetItem(f"{icon}  {name}")
            item.setData(Qt.ItemDataRole.UserRole, entry)
            self._list.addItem(item)
        self._list.blockSignals(False)

        self._set_status(t("status.ready"), C_TEXT_DIM)
        self._count.setText(t("browser.count_selected", n=0))
        self._update_nav_buttons()

    def refresh(self) -> None:
        """Re-read the current directory, reflecting any filesystem changes.

        Preserves any files that are still present in the updated listing.
        If the surviving selection differs from the original, notifies the
        pipeline via the selection-changed callback.
        """
        previously_selected: set[Path] = set(self.selected_files())
        self.navigate(self._current_path, add_to_history=False)
        # Re-select files that still exist in the updated listing.
        surviving = [p for p in self._entries if p in previously_selected]
        if surviving:
            self.select_files(surviving)  # fires _on_selection_changed_internal
        elif previously_selected:
            # All selected files are gone (deleted/moved); clear pipeline state.
            self._on_selection_changed_internal()

    def current_path(self) -> Path:
        """Return the currently displayed directory path."""
        return self._current_path

    def selected_files(self) -> list[Path]:
        """Return currently selected entries in the browser list."""
        return [item.data(Qt.ItemDataRole.UserRole) for item in self._list.selectedItems()]

    def select_files(self, files: list[Path]) -> None:
        """Select specific entries in the current list by absolute path."""
        wanted: set[str] = set()
        for path in files:
            wanted.add(str(path))
            try:
                wanted.add(str(path.resolve()))
            except OSError:
                pass

        self._list.blockSignals(True)
        self._list.clearSelection()
        for index in range(self._list.count()):
            item = self._list.item(index)
            path = item.data(Qt.ItemDataRole.UserRole)
            if not isinstance(path, Path):
                continue
            candidates = {str(path)}
            try:
                candidates.add(str(path.resolve()))
            except OSError:
                pass
            if candidates & wanted:
                item.setSelected(True)
        self._list.blockSignals(False)
        self._on_selection_changed_internal()

    def _on_path_entered(self) -> None:
        """Handle manual path entry."""
        path = Path(self._path_input.text()).expanduser()
        if path.exists() and path.is_dir():
            self.navigate(path, add_to_history=True)
        else:
            self._path_input.setText(str(self._current_path))
            self._set_status(t("browser.invalid_path_short"), C_ERROR)

    def _select_all(self) -> None:
        """Select all entries in the current directory listing."""
        self._list.selectAll()

    def set_show_hidden(self, show_hidden: bool) -> None:
        """Set hidden-file visibility and refresh the current directory."""
        self._show_hidden = show_hidden
        self.navigate(self._current_path, add_to_history=False)

    def set_sort(self, key: str, direction: str) -> None:
        """Apply sort order and re-render the file list.

        Args:
            key: Sort key, one of ``name``, ``created``, ``modified``, ``type``, ``size``.
            direction: ``"asc"`` or ``"desc"``.
        """
        label = sort_option_label(key, direction)
        self._set_sort(key, direction, label)

    def _on_filter_changed(self) -> None:
        """Handle filter input updates and refresh current listing."""
        self._name_filter = self._name_filter_input.text().strip()
        current_type = self._type_filter_combo.currentData()
        self._type_filter = current_type if isinstance(current_type, str) else "all"
        self.navigate(self._current_path, add_to_history=False)

    def _apply_filters(self, entries: list[Path]) -> list[Path]:
        """Apply name and extension filters to a list of entries."""
        filtered = entries
        if self._name_filter:
            pattern = self._name_filter
            filtered = [entry for entry in filtered if fnmatch(entry.name, pattern)]
        if self._type_filter != "all":
            filtered = [
                entry
                for entry in filtered
                if classify_file_type(detect_mime_type(entry)) == self._type_filter
            ]
        return filtered

    def _go_up(self) -> None:
        """Navigate to parent directory."""
        parent = self._current_path.parent
        if parent == self._current_path:
            return
        self.navigate(parent, add_to_history=True)

    def _go_back(self) -> None:
        """Navigate to previous directory in history."""
        if self._history_index <= 0:
            return
        self._history_index -= 1
        self.navigate(self._history[self._history_index], add_to_history=False)

    def _go_forward(self) -> None:
        """Navigate to next directory in history."""
        if self._history_index >= len(self._history) - 1:
            return
        self._history_index += 1
        self.navigate(self._history[self._history_index], add_to_history=False)

    def _apply_sort(self, entries: list[Path]) -> list[Path]:
        """Sort entries using current sort key and direction."""
        reverse = self._sort_direction == "desc"
        return sorted(entries, key=lambda p: sort_key_for_path(p, self._sort_key), reverse=reverse)

    def _set_sort(self, key: str, direction: str, label: str) -> None:
        """Update sort settings and refresh the directory listing."""
        self._sort_key = key
        self._sort_direction = direction
        self._sort_btn.setText(f"{label} ▾")
        self.navigate(self._current_path, add_to_history=False)

    def _show_sort_menu(self, anchor: QWidget) -> None:
        """Show a popup menu with all sort options."""
        menu = QMenu(self)
        for key, direction in SORT_OPTIONS:
            label = sort_option_label(key, direction)
            action = menu.addAction(label)
            if key == self._sort_key and direction == self._sort_direction:
                action.setCheckable(True)
                action.setChecked(True)
            action.triggered.connect(
                lambda _c, k=key, d=direction, lbl=label: self._set_sort(k, d, lbl)
            )
        menu.exec(anchor.mapToGlobal(anchor.rect().bottomLeft()))

    def _update_nav_buttons(self) -> None:
        """Enable or disable back/forward navigation buttons."""
        self._back_btn.setEnabled(self._history_index > 0)
        self._forward_btn.setEnabled(self._history_index < len(self._history) - 1)

    def _on_double_clicked(self, item: QListWidgetItem) -> None:
        """Navigate into directory or open file on double-click."""
        path: Path = item.data(Qt.ItemDataRole.UserRole)
        if path.is_dir():
            self.navigate(path, add_to_history=True)
        else:
            self._open_file(path)

    def _open_file(self, path: Path) -> None:
        """Open a file in the system default application."""
        try:
            opened = QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
            if not opened:
                open_in_default_app(path)
            self._set_status(t("status.opened", name=path.name), C_SUCCESS)
        except Exception as error:
            self._set_status(t("status.open_failed", error=error), C_ERROR)

    def _on_selection_changed_internal(self) -> None:
        """Handle list selection change and propagate to pipeline."""
        selected: list[Path] = [
            item.data(Qt.ItemDataRole.UserRole) for item in self._list.selectedItems()
        ]
        self._count.setText(t("browser.count_selected", n=len(selected)))

        if selected:
            type_summary = summarize_file_types(selected)
            msg = t("browser.count_selected_msg", n=len(selected))
            if type_summary:
                msg += f" ({type_summary})"
            self._set_status(msg, C_SUCCESS)
        else:
            self._set_status(t("status.ready"), C_TEXT_DIM)

        self._on_selection_changed(selected)

    def _set_status(self, text: str, color: QColor) -> None:
        """Update the status label with text and color."""
        self._status.setText(text)
        self._status.setStyleSheet(f"color: {color.name()}; font-size: 11px;")

    def set_status_text(self, text: str, color: QColor) -> None:
        """Public status setter for external callers."""
        self._set_status(text, color)
