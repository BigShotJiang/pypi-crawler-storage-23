"""Operation pane widget — results viewer and parameter controls for a pipeline step."""

from __future__ import annotations

from fnmatch import fnmatch
from pathlib import Path

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QColor, QDesktopServices, QPalette
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QProgressBar,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from cascade_fm.core.filetypes import classify_file_type, detect_mime_type
from cascade_fm.core.i18n import t
from cascade_fm.core.system_open import open_in_default_app
from cascade_fm.core.types import PaneStatus

from .theme import (
    C_ACCENT,
    C_BG_DARK,
    C_BG_PANE,
    C_ERROR,
    C_SUCCESS,
    C_TEXT,
    C_TEXT_DIM,
    C_WARNING,
    SORT_OPTIONS,
    icon_for_entry,
    sort_key_for_path,
    sort_option_label,
)


class OperationPane(QFrame):
    """Pane showing an operation's parameter input and output file list."""

    def __init__(
        self,
        pane_id: str,
        operation_name: str,
        on_selection_changed=None,
        parent=None,
    ) -> None:
        """Initialize operation pane.

        Args:
            pane_id: Unique pipeline pane identifier.
            operation_name: Human-readable name shown in the header.
        """
        super().__init__(parent)
        self.pane_id = pane_id
        self.param_input: QLineEdit | None = None
        self.save_conflict_policy_combo: QComboBox | None = None
        self.save_button: QPushButton | None = None
        self.transform_action_combo: QComboBox | None = None
        self.transform_value_input: QLineEdit | None = None
        self.archive_name_input: QLineEdit | None = None
        self.archive_format_combo: QComboBox | None = None
        self.unarchive_flatten_checkbox: QCheckBox | None = None
        self.rename_mode_combo: QComboBox | None = None
        self.rename_template_input: QLineEdit | None = None
        self.rename_template_row: QWidget | None = None
        self.rename_plain_hint: QLabel | None = None
        self.rename_find_input: QLineEdit | None = None
        self.rename_find_row: QWidget | None = None
        self.rename_replace_input: QLineEdit | None = None
        self.rename_replace_row: QWidget | None = None
        self.rename_regex_panel: QWidget | None = None
        self.rename_regex_label: QLabel | None = None
        self._sort_key: str = "name"
        self._sort_direction: str = "asc"
        self._show_hidden: bool = False
        self._all_files: list[Path] = []
        self._name_filter: str = ""
        self._type_filter: str = "all"
        self._drilldown_stack: list[Path] = []
        self._on_selection_changed = on_selection_changed

        self.setMinimumWidth(320)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setAutoFillBackground(True)
        pal = self.palette()
        pal.setColor(QPalette.ColorRole.Window, C_BG_PANE)
        self.setPalette(pal)

        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(6, 6, 6, 6)
        self._layout.setSpacing(4)

        hdr = QLabel(operation_name)
        hdr.setStyleSheet(f"color: {C_TEXT.name()}; font-weight: bold; font-size: 13px;")
        self._layout.addWidget(hdr)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFixedHeight(2)
        sep.setStyleSheet(f"background-color: {C_ACCENT.name()}; border: none;")
        self._layout.addWidget(sep)

        # Dialogue section (parameter widgets inserted here)
        self._dialogue = QVBoxLayout()
        self._dialogue.setContentsMargins(0, 0, 0, 0)
        self._dialogue.setSpacing(4)
        self._layout.addLayout(self._dialogue)

        # Status
        self._status = QLabel(t("status.ready"))
        self._status.setStyleSheet(f"color: {C_TEXT_DIM.name()}; font-size: 11px;")
        self._layout.addWidget(self._status)

        self._busy_indicator = QProgressBar()
        self._busy_indicator.setRange(0, 0)
        self._busy_indicator.setTextVisible(True)
        self._busy_indicator.setFormat(t("status.working"))
        self._busy_indicator.setFixedHeight(12)
        self._busy_indicator.setStyleSheet(
            "QProgressBar {"
            f" background-color: {C_BG_DARK.name()};"
            f" border: 1px solid {C_TEXT_DIM.name()};"
            " border-radius: 3px;"
            f" color: {C_TEXT.name()};"
            " text-align: center;"
            " font-size: 10px;"
            "}"
            "QProgressBar::chunk {"
            f" background-color: {C_ACCENT.name()};"
            " border-radius: 2px;"
            "}"
        )
        self._busy_indicator.setVisible(False)
        self._layout.addWidget(self._busy_indicator)

        filter_row = QHBoxLayout()
        self._name_filter_input = QLineEdit()
        self._name_filter_input.setPlaceholderText(t("opane.filter.name.placeholder"))
        self._name_filter_input.textChanged.connect(self._on_filter_changed)
        filter_row.addWidget(self._name_filter_input)

        self._type_filter_combo = QComboBox()
        self._type_filter_combo.setFixedWidth(170)
        self._type_filter_combo.addItem(t("filetype.all"), "all")
        self._type_filter_combo.addItem(t("filetype.directory"), "directory")
        self._type_filter_combo.addItem(t("filetype.image"), "image")
        self._type_filter_combo.addItem(t("filetype.video"), "video")
        self._type_filter_combo.addItem(t("filetype.audio"), "audio")
        self._type_filter_combo.addItem(t("filetype.text"), "text")
        self._type_filter_combo.addItem(t("filetype.document"), "document")
        self._type_filter_combo.addItem(t("filetype.other"), "other")
        self._type_filter_combo.currentIndexChanged.connect(self._on_filter_changed)
        filter_row.addWidget(self._type_filter_combo)

        self._sort_btn = QPushButton("↑ Name ▾")
        self._sort_btn.setFixedWidth(90)
        self._sort_btn.setToolTip(t("browser.sort.tooltip"))
        self._sort_btn.setStyleSheet(
            f"QPushButton {{ background-color: transparent; border: 1px solid {C_TEXT_DIM.name()}; "
            f"border-radius: 3px; color: {C_TEXT_DIM.name()}; font-size: 10px; padding: 2px 4px; }}"
            f"QPushButton:hover {{ border-color: {C_TEXT.name()}; color: {C_TEXT.name()}; }}"
        )
        self._sort_btn.clicked.connect(lambda: self._show_sort_menu(self._sort_btn))
        filter_row.addWidget(self._sort_btn)

        self._layout.addLayout(filter_row)

        # Drill-down breadcrumb bar (hidden unless browsing inside a subdirectory)
        drilldown_row = QHBoxLayout()
        drilldown_row.setContentsMargins(0, 0, 0, 0)
        drilldown_row.setSpacing(4)
        self._drill_back_btn = QPushButton(t("opane.drill_back"))
        self._drill_back_btn.setFixedWidth(66)
        self._drill_back_btn.setToolTip(t("opane.drill_back.tooltip"))
        self._drill_back_btn.setStyleSheet(
            f"QPushButton {{ background-color: transparent; border: 1px solid {C_ACCENT.name()}; "
            f"border-radius: 3px; color: {C_ACCENT.name()}; font-size: 10px; padding: 2px 4px; }}"
            f"QPushButton:hover {{ background-color: {C_ACCENT.name()}; color: {C_BG_DARK.name()}; }}"
        )
        self._drill_back_btn.clicked.connect(self._drill_back)
        drilldown_row.addWidget(self._drill_back_btn)
        self._drill_path_label = QLabel("")
        self._drill_path_label.setStyleSheet(f"color: {C_TEXT_DIM.name()}; font-size: 10px;")
        drilldown_row.addWidget(self._drill_path_label)
        drilldown_row.addStretch()
        self._drilldown_bar = QWidget()
        self._drilldown_bar.setLayout(drilldown_row)
        self._drilldown_bar.setVisible(False)
        self._layout.addWidget(self._drilldown_bar)

        # Output file list
        self._file_list = QListWidget()
        self._file_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self._file_list.itemDoubleClicked.connect(self._on_double_clicked)
        self._file_list.itemSelectionChanged.connect(self._on_selection_changed_internal)
        self._layout.addWidget(self._file_list)

        # Count
        self._count = QLabel(t("opane.count_files", n=0))
        self._count.setStyleSheet(f"color: {C_TEXT_DIM.name()}; font-size: 10px;")
        self._layout.addWidget(self._count)

    def add_dialogue_widget(self, widget: QWidget) -> None:
        """Add a widget to the parameter/dialogue section."""
        self._dialogue.addWidget(widget)

    def update_status(self, status: PaneStatus, error: str | None = None) -> None:
        """Update the status label to reflect current pane state.

        Args:
            status: Current execution state of the pane.
            error: Optional error message shown in error state.
        """
        if status == PaneStatus.DONE:
            text, color = t("status.complete"), C_SUCCESS
            self._busy_indicator.setVisible(False)
            self._busy_indicator.setRange(0, 0)
            self._busy_indicator.setFormat(t("status.working"))
        elif status == PaneStatus.ERROR:
            text, color = (
                (t("status.error", error=error) if error else t("status.error_short")),
                C_ERROR,
            )
            self._busy_indicator.setVisible(False)
            self._busy_indicator.setRange(0, 0)
            self._busy_indicator.setFormat(t("status.working"))
        elif status == PaneStatus.EXECUTING:
            text, color = t("status.executing"), C_ACCENT
            self._busy_indicator.setVisible(True)
            self._busy_indicator.setRange(0, 0)
            self._busy_indicator.setValue(0)
            self._busy_indicator.setFormat(t("status.working"))
        else:
            if status == PaneStatus.STALE:
                text, color = t("status.stale"), C_WARNING
            else:
                text, color = t("status.configured"), C_TEXT_DIM
            self._busy_indicator.setVisible(False)
            self._busy_indicator.setRange(0, 0)
            self._busy_indicator.setFormat(t("status.working"))
        self._set_status(text, color)

    def update_progress(
        self,
        current: int | None,
        total: int | None,
        message: str | None,
    ) -> None:
        """Update execution progress UI for this pane."""
        self._busy_indicator.setVisible(True)
        if total is None or current is None or total <= 0:
            self._busy_indicator.setRange(0, 0)
            self._busy_indicator.setFormat(t("status.working"))
            if message:
                self._set_status(f"⏳ {message}", C_ACCENT)
            return

        self._busy_indicator.setRange(0, total)
        self._busy_indicator.setValue(max(0, min(current, total)))
        self._busy_indicator.setFormat(f"{current}/{total}")
        if message:
            self._set_status(f"⏳ {message} ({current}/{total})", C_ACCENT)
        else:
            self._set_status(t("status.executing_progress", current=current, total=total), C_ACCENT)

    def update_files(self, files: list[Path]) -> None:
        """Repopulate the output file list.

        Args:
            files: Paths to display.
        """
        self._all_files = files
        self._drilldown_stack = []
        self._drilldown_bar.setVisible(False)
        self._render_files()

    def set_show_hidden(self, show_hidden: bool) -> None:
        """Set hidden-file visibility for this pane's file list."""
        self._show_hidden = show_hidden
        self._render_files()

    def _render_files(self) -> None:
        """Render file list honoring hidden-file visibility settings."""
        if self._drilldown_stack:
            try:
                raw = list(self._drilldown_stack[-1].iterdir())
            except OSError:
                raw = []
        else:
            raw = self._all_files

        if not self._show_hidden:
            raw = [p for p in raw if not p.name.startswith(".")]
        files_to_show = self._apply_filters(raw)
        files_to_show = self._apply_sort(files_to_show)

        self._file_list.clear()
        for fp in files_to_show:
            item = QListWidgetItem(f"{icon_for_entry(fp)}  {fp.name}")
            item.setData(Qt.ItemDataRole.UserRole, fp)
            self._file_list.addItem(item)
        self._count.setText(t("opane.count_files", n=len(files_to_show)))

    def selected_files(self) -> list[Path]:
        """Return currently selected entries in this pane."""
        return [item.data(Qt.ItemDataRole.UserRole) for item in self._file_list.selectedItems()]

    def _on_filter_changed(self) -> None:
        """Handle operation-pane filter input changes."""
        self._name_filter = self._name_filter_input.text().strip()
        current_type = self._type_filter_combo.currentData()
        self._type_filter = current_type if isinstance(current_type, str) else "all"
        self._render_files()

    def _apply_filters(self, files: list[Path]) -> list[Path]:
        """Apply name and extension filters to pane files."""
        filtered = files
        if self._name_filter:
            filtered = [
                file_path for file_path in filtered if fnmatch(file_path.name, self._name_filter)
            ]
        if self._type_filter != "all":
            filtered = [
                file_path
                for file_path in filtered
                if classify_file_type(detect_mime_type(file_path)) == self._type_filter
            ]
        return filtered

    def _apply_sort(self, files: list[Path]) -> list[Path]:
        """Sort files using current sort key and direction."""
        reverse = self._sort_direction == "desc"
        return sorted(files, key=lambda p: sort_key_for_path(p, self._sort_key), reverse=reverse)

    def _set_sort(self, key: str, direction: str, label: str) -> None:
        """Update sort settings and refresh the file list."""
        self._sort_key = key
        self._sort_direction = direction
        self._sort_btn.setText(f"{label} ▾")
        self._render_files()

    def _show_sort_menu(self, anchor: QWidget) -> None:
        """Show a popup menu with all sort options."""
        menu = QMenu(self)
        for key, direction in SORT_OPTIONS:
            label = sort_option_label(key, direction)
            action = menu.addAction(label)
            if key == self._sort_key and direction == self._sort_direction:
                action.setCheckable(True)
                action.setChecked(True)
            action.triggered.connect(
                lambda _c, k=key, d=direction, lbl=label: self._set_sort(k, d, lbl)
            )
        menu.exec(anchor.mapToGlobal(anchor.rect().bottomLeft()))

    def _drill_into(self, path: Path) -> None:
        """Drill down into a subdirectory (preview only; root output unchanged)."""
        self._drilldown_stack.append(path)
        self._update_drilldown_bar()
        self._render_files()

    def _drill_back(self) -> None:
        """Go up one level in the drilldown view."""
        if len(self._drilldown_stack) > 1:
            self._drilldown_stack.pop()
            self._update_drilldown_bar()
            self._render_files()

    def _update_drilldown_bar(self) -> None:
        """Refresh drilldown breadcrumb label and back-button state."""
        visible = bool(self._drilldown_stack)
        self._drilldown_bar.setVisible(visible)
        if visible:
            label = " / ".join(p.name for p in self._drilldown_stack)
            self._drill_path_label.setText(label)
            at_root = len(self._drilldown_stack) == 1
            self._drill_back_btn.setEnabled(not at_root)
            self._drill_back_btn.setStyleSheet(
                f"QPushButton {{ background-color: transparent; "
                f"border: 1px solid {(C_TEXT_DIM if at_root else C_ACCENT).name()}; "
                f"border-radius: 3px; color: {(C_TEXT_DIM if at_root else C_ACCENT).name()}; "
                f"font-size: 10px; padding: 2px 4px; }}"
                + (
                    f"QPushButton:hover {{ background-color: {C_ACCENT.name()}; "
                    f"color: {C_BG_DARK.name()}; }}"
                    if not at_root
                    else ""
                )
            )

    def _on_double_clicked(self, item: QListWidgetItem) -> None:
        """Drill into a directory or open a file from an operation pane."""
        path: Path | None = item.data(Qt.ItemDataRole.UserRole)
        if path is None:
            return
        if path.is_dir():
            self._drill_into(path)
        else:
            self._open_path(path)

    def _on_selection_changed_internal(self) -> None:
        """Propagate operation-pane selection changes to the parent widget."""
        if self._on_selection_changed is None:
            return
        self._on_selection_changed(self.selected_files())

    def _open_path(self, path: Path) -> None:
        """Open a path in the system default application."""
        try:
            opened = QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
            if not opened:
                open_in_default_app(path)
            self._set_status(t("status.opened", name=path.name), C_SUCCESS)
        except Exception as error:
            self._set_status(t("status.open_failed", error=error), C_ERROR)

    def set_status_text(self, text: str, color: QColor) -> None:
        """Set status label text and color directly.

        Args:
            text: Status message to display.
            color: Display color for the message.
        """
        self._set_status(text, color)

    def _set_status(self, text: str, color: QColor) -> None:
        self._status.setText(text)
        self._status.setStyleSheet(f"color: {color.name()}; font-size: 11px;")
