"""Application configuration — loaded from and saved to ~/.cascade/config.json."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

_CONFIG_PATH = Path.home() / ".cascade" / "config.json"

_VALID_SORT_KEYS = {"name", "created", "modified", "type", "size"}
_VALID_SORT_DIRECTIONS = {"asc", "desc"}
_VALID_SESSION_RESTORE = {"prompt", "auto", "disabled"}


def _default_bookmark_paths() -> list[str]:
    """Return capitalised home subdirectories as path strings (first-run default)."""
    home = Path.home()
    try:
        return sorted(str(p) for p in home.iterdir() if p.is_dir() and p.name[:1].isupper())
    except OSError:
        return []


@dataclass
class AppConfig:
    """User-editable application preferences."""

    # General
    start_dir: str = "~"
    default_sort_key: str = "name"
    default_sort_direction: str = "asc"
    show_hidden_files: bool = False

    # Session restore
    session_restore: str = "prompt"  # "prompt" | "auto" | "disabled"
    session_restore_max_age_hours: float = 24.0

    # Bookmarks — None means "auto-detect uppercase home subdirectories"
    bookmarks: list[str] | None = None

    # UI language (must match a translation file code, e.g. "en", "de")
    language: str = "en"

    def start_dir_path(self) -> Path:
        """Return the expanded start directory as a Path."""
        return Path(self.start_dir).expanduser()

    def session_restore_max_age_seconds(self) -> float:
        """Return session restore max age converted to seconds."""
        return max(0.0, self.session_restore_max_age_hours * 3600.0)


def load_config(config_path: Path | None = None) -> AppConfig:  # noqa: C901
    """Load application config from disk, returning defaults if missing or invalid.

    Args:
        config_path: Override path — defaults to ``~/.cascade/config.json``.

    Returns:
        Populated ``AppConfig``, with any missing keys filled in with defaults.
    """
    path = config_path or _CONFIG_PATH
    if not path.exists():
        return AppConfig()

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return AppConfig()

    if not isinstance(raw, dict):
        return AppConfig()

    cfg = AppConfig()

    if isinstance(raw.get("start_dir"), str):
        cfg.start_dir = raw["start_dir"]

    sort_key = raw.get("default_sort_key")
    if isinstance(sort_key, str) and sort_key in _VALID_SORT_KEYS:
        cfg.default_sort_key = sort_key

    sort_dir = raw.get("default_sort_direction")
    if isinstance(sort_dir, str) and sort_dir in _VALID_SORT_DIRECTIONS:
        cfg.default_sort_direction = sort_dir

    if isinstance(raw.get("show_hidden_files"), bool):
        cfg.show_hidden_files = raw["show_hidden_files"]

    session_restore = raw.get("session_restore")
    if isinstance(session_restore, str) and session_restore in _VALID_SESSION_RESTORE:
        cfg.session_restore = session_restore

    age = raw.get("session_restore_max_age_hours")
    if isinstance(age, (int, float)) and age >= 0:
        cfg.session_restore_max_age_hours = float(age)

    bookmarks = raw.get("bookmarks")
    if bookmarks is None or isinstance(bookmarks, list):
        if isinstance(bookmarks, list):
            cfg.bookmarks = [b for b in bookmarks if isinstance(b, str)]
        else:
            cfg.bookmarks = None

    lang = raw.get("language")
    if isinstance(lang, str) and lang.strip():
        cfg.language = lang.strip()

    return cfg


def save_config(config: AppConfig, config_path: Path | None = None) -> None:
    """Persist application config to disk.

    Args:
        config: Config to save.
        config_path: Override path — defaults to ``~/.cascade/config.json``.
    """
    path = config_path or _CONFIG_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    data = asdict(config)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def ensure_config_initialized(config_path: Path | None = None) -> AppConfig:
    """Load config, creating it with detected bookmarks on the very first run.

    If the config file does not yet exist, an ``AppConfig`` with ``bookmarks``
    set to the auto-detected capitalised home subdirectories is written to disk
    and returned.  Subsequent calls simply delegate to :func:`load_config`.

    Args:
        config_path: Override path — defaults to ``~/.cascade/config.json``.

    Returns:
        The loaded (or freshly created) ``AppConfig``.
    """
    path = config_path or _CONFIG_PATH
    if not path.exists():
        cfg = AppConfig(bookmarks=_default_bookmark_paths())
        save_config(cfg, path)
        return cfg
    return load_config(path)
