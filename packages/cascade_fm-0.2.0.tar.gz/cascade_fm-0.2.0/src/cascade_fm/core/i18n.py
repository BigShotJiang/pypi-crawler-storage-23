"""Translation engine for cascade.

Look-up order (highest to lowest priority):

1. User file: ``~/.cascade/translations/<lang>.json``
2. Built-in file: ``cascade_fm/assets/translations/<lang>.json``
3. English fall-back: built-in ``en.json``
4. Raw key (returned unchanged if nothing matched)

Usage::

    from cascade_fm.core.i18n import t, set_language, available_languages

    set_language("de")
    print(t("browser.title"))          # → "Dateien durchsuchen"
    print(t("browser.count_selected", n=5))  # → "5 ausgewählt"

Custom languages
----------------
Drop a ``<lang-code>.json`` file into ``~/.cascade/translations/``.
Optionally include a ``"name"`` key with the display name of the language:
``{"name": "Español", "browser.title": "Explorar archivos", ...}``

Built-in languages: ``en`` (English), ``de`` (Deutsch).
"""

from __future__ import annotations

import importlib.resources
import json
from pathlib import Path
from typing import Any

_USER_TRANSLATIONS_DIR = Path.home() / ".cascade" / "translations"

# Display names for built-in language codes
_BUILTIN_LANG_NAMES: dict[str, str] = {
    "en": "English",
    "de": "Deutsch",
}


class I18n:
    """Singleton translation engine."""

    def __init__(self) -> None:
        self._translations: dict[str, str] = {}
        self._lang: str = "en"
        self._reload("en")

    def set_language(self, lang: str) -> None:
        """Load translations for *lang*, overlaying on the English baseline.

        Args:
            lang: Language code, e.g. ``"en"`` or ``"de"``.
        """
        self._translations.clear()
        self._reload(lang)
        self._lang = lang

    @property
    def language(self) -> str:
        """Currently active language code."""
        return self._lang

    def t(self, key: str, **kwargs: Any) -> str:  # noqa: ANN401
        """Look up *key* and interpolate any keyword arguments.

        Falls back to the raw key if no translation is found.

        Args:
            key: Dot-separated translation key, e.g. ``"browser.title"``.
            **kwargs: Format arguments interpolated into ``{placeholder}`` slots.

        Returns:
            Translated and interpolated string, or *key* on missing translation.
        """
        text = self._translations.get(key, key)
        if kwargs:
            try:
                return text.format(**kwargs)
            except (KeyError, ValueError):
                return text
        return text

    def available_languages(self) -> list[tuple[str, str]]:
        """Return all discoverable languages as ``(code, display_name)`` pairs.

        Scans both the built-in assets directory and the user translations
        directory.  User languages not present in the built-in list use the
        ``"name"`` key from their JSON file, or the bare code as a fallback.

        Returns:
            Sorted list of ``(code, display_name)`` tuples.
        """
        langs: dict[str, str] = {}

        # Built-in translations
        try:
            pkg = importlib.resources.files("cascade_fm.assets").joinpath("translations")
            for item in pkg.iterdir():
                name = getattr(item, "name", "")
                if name.endswith(".json"):
                    code = name[:-5]
                    langs[code] = _BUILTIN_LANG_NAMES.get(code, code)
        except (FileNotFoundError, NotADirectoryError, OSError):
            pass

        # User translations
        if _USER_TRANSLATIONS_DIR.exists():
            for p in sorted(_USER_TRANSLATIONS_DIR.glob("*.json")):
                code = p.stem
                if code in langs:
                    continue
                try:
                    data = json.loads(p.read_text(encoding="utf-8"))
                    display = data.get("name", code) if isinstance(data, dict) else code
                except (json.JSONDecodeError, OSError):
                    display = code
                langs[code] = str(display)

        return sorted(langs.items())

    # ── Private helpers ───────────────────────────────────────────────────────

    def _reload(self, lang: str) -> None:
        """Reload translations for *lang* on top of the English baseline."""
        # 1. English baseline (always)
        self._load_file(self._builtin_path("en"))
        # 2. Overlay the requested language (no-op when lang == "en")
        if lang != "en":
            self._load_file(self._builtin_path(lang))
        # 3. User customisation (highest priority)
        self._load_file(_USER_TRANSLATIONS_DIR / f"{lang}.json")

    def _load_file(self, path: Any) -> None:  # noqa: ANN401
        """Read *path* (Path or importlib Traversable) and overlay translations."""
        try:
            text = path.read_text(encoding="utf-8")
            data = json.loads(text)
            if isinstance(data, dict):
                self._translations.update(
                    {k: v for k, v in data.items() if isinstance(k, str) and isinstance(v, str)}
                )
        except (FileNotFoundError, AttributeError, json.JSONDecodeError, OSError):
            pass

    @staticmethod
    def _builtin_path(lang: str) -> Any:  # noqa: ANN401
        """Return an importlib Traversable for a built-in language file."""
        return (
            importlib.resources.files("cascade_fm.assets")
            .joinpath("translations")
            .joinpath(f"{lang}.json")
        )


# ── Module-level singleton and convenience aliases ────────────────────────────

_i18n = I18n()

#: Translate a key: ``t("browser.title")`` → ``"Browse Files"``
t = _i18n.t

#: Set the active language: ``set_language("de")``
set_language = _i18n.set_language

#: Return available languages as ``[(code, display_name), ...]``
available_languages = _i18n.available_languages
