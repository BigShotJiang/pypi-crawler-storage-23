"""Unit tests for cascade_fm.core.i18n."""

from cascade_fm.core.i18n import I18n


def _make_i18n() -> I18n:
    """Return a fresh I18n instance (isolated from the module-level singleton)."""
    return I18n()


class TestTranslate:
    def test_returns_key_when_missing(self):
        i18n = _make_i18n()
        assert i18n.t("nonexistent.key") == "nonexistent.key"

    def test_english_baseline_loaded_by_default(self):
        i18n = _make_i18n()
        result = i18n.t("app.title")
        assert "cascade" in result.lower()

    def test_interpolation(self):
        i18n = _make_i18n()
        result = i18n.t("status.error", error="oops")
        assert "oops" in result

    def test_interpolation_missing_placeholder_returns_string(self):
        i18n = _make_i18n()
        # Passing no kwargs should return the raw template (no crash)
        result = i18n.t("status.error")
        assert isinstance(result, str)

    def test_set_language_german(self):
        i18n = _make_i18n()
        i18n.set_language("de")
        result = i18n.t("app.title")
        assert isinstance(result, str)
        assert result != "app.title"

    def test_german_prefs_title(self):
        i18n = _make_i18n()
        i18n.set_language("de")
        assert i18n.t("prefs.title") == "Einstellungen"

    def test_reset_to_english(self):
        i18n = _make_i18n()
        i18n.set_language("de")
        i18n.set_language("en")
        assert i18n.t("prefs.title") == "Preferences"

    def test_unknown_language_falls_back_to_english(self):
        i18n = _make_i18n()
        i18n.set_language("xx")
        # Should still return English baseline (not crash)
        result = i18n.t("app.title")
        assert "cascade" in result.lower()


class TestAvailableLanguages:
    def test_includes_english_and_german(self):
        i18n = _make_i18n()
        languages = i18n.available_languages()
        codes = [code for code, _ in languages]
        assert "en" in codes
        assert "de" in codes

    def test_returns_list_of_tuples(self):
        i18n = _make_i18n()
        langs = i18n.available_languages()
        assert isinstance(langs, list)
        assert all(isinstance(pair, tuple) and len(pair) == 2 for pair in langs)

    def test_display_names_are_strings(self):
        i18n = _make_i18n()
        for code, name in i18n.available_languages():
            assert isinstance(code, str) and code
            assert isinstance(name, str) and name

    def test_english_display_name(self):
        i18n = _make_i18n()
        langs = dict(i18n.available_languages())
        assert langs["en"] == "English"

    def test_german_display_name(self):
        i18n = _make_i18n()
        langs = dict(i18n.available_languages())
        assert langs["de"] == "Deutsch"


class TestModuleLevelAliases:
    def test_module_t_function(self):
        from cascade_fm.core.i18n import t

        result = t("app.title")
        assert isinstance(result, str)
        assert result != "app.title"

    def test_module_available_languages(self):
        from cascade_fm.core.i18n import available_languages

        langs = available_languages()
        assert len(langs) >= 2

    def test_module_set_language(self):
        from cascade_fm.core.i18n import set_language, t

        set_language("de")
        assert t("prefs.title") == "Einstellungen"
        set_language("en")  # restore for other tests
        assert t("prefs.title") == "Preferences"
