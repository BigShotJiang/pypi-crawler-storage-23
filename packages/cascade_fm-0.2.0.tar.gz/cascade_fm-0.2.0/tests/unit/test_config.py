"""Unit tests for cascade_fm.core.config."""

from __future__ import annotations

import json
from pathlib import Path

from cascade_fm.core.config import AppConfig, ensure_config_initialized, load_config, save_config

# ── Default values ────────────────────────────────────────────────────────────


def test_default_start_dir() -> None:
    assert AppConfig().start_dir == "~"


def test_default_sort_key() -> None:
    assert AppConfig().default_sort_key == "name"


def test_default_sort_direction() -> None:
    assert AppConfig().default_sort_direction == "asc"


def test_default_show_hidden_files() -> None:
    assert AppConfig().show_hidden_files is False


def test_default_session_restore() -> None:
    assert AppConfig().session_restore == "prompt"


def test_default_session_restore_max_age_hours() -> None:
    assert AppConfig().session_restore_max_age_hours == 24.0


def test_default_bookmarks_is_none() -> None:
    assert AppConfig().bookmarks is None


# ── Derived helpers ───────────────────────────────────────────────────────────


def test_start_dir_path_expands_tilde() -> None:
    cfg = AppConfig(start_dir="~")
    assert cfg.start_dir_path() == Path.home()


def test_start_dir_path_absolute() -> None:
    cfg = AppConfig(start_dir="/tmp/mydir")
    assert cfg.start_dir_path() == Path("/tmp/mydir")


def test_session_restore_max_age_seconds_converts_hours() -> None:
    cfg = AppConfig(session_restore_max_age_hours=2.0)
    assert cfg.session_restore_max_age_seconds() == 7200.0


def test_session_restore_max_age_zero() -> None:
    cfg = AppConfig(session_restore_max_age_hours=0.0)
    assert cfg.session_restore_max_age_seconds() == 0.0


# ── load_config — missing file returns defaults ───────────────────────────────


def test_load_config_missing_file(tmp_path: Path) -> None:
    cfg = load_config(tmp_path / "nonexistent.json")
    assert cfg == AppConfig()


def test_load_config_corrupt_json(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    p.write_text("{ not valid json }", encoding="utf-8")
    cfg = load_config(p)
    assert cfg == AppConfig()


def test_load_config_non_dict_json(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    p.write_text("[1, 2, 3]", encoding="utf-8")
    cfg = load_config(p)
    assert cfg == AppConfig()


# ── load_config — field validation ───────────────────────────────────────────


def test_load_config_valid_fields(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    p.write_text(
        json.dumps(
            {
                "start_dir": "/tmp",
                "default_sort_key": "size",
                "default_sort_direction": "desc",
                "show_hidden_files": True,
                "session_restore": "auto",
                "session_restore_max_age_hours": 48.0,
                "bookmarks": ["/tmp", "/var"],
            }
        ),
        encoding="utf-8",
    )
    cfg = load_config(p)
    assert cfg.start_dir == "/tmp"
    assert cfg.default_sort_key == "size"
    assert cfg.default_sort_direction == "desc"
    assert cfg.show_hidden_files is True
    assert cfg.session_restore == "auto"
    assert cfg.session_restore_max_age_hours == 48.0
    assert cfg.bookmarks == ["/tmp", "/var"]


def test_load_config_invalid_sort_key_falls_back(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"default_sort_key": "banana"}), encoding="utf-8")
    cfg = load_config(p)
    assert cfg.default_sort_key == "name"


def test_load_config_invalid_sort_dir_falls_back(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"default_sort_direction": "sideways"}), encoding="utf-8")
    cfg = load_config(p)
    assert cfg.default_sort_direction == "asc"


def test_load_config_invalid_session_restore_falls_back(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"session_restore": "whenever"}), encoding="utf-8")
    cfg = load_config(p)
    assert cfg.session_restore == "prompt"


def test_load_config_invalid_age_falls_back(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"session_restore_max_age_hours": "twelve"}), encoding="utf-8")
    cfg = load_config(p)
    assert cfg.session_restore_max_age_hours == 24.0


def test_load_config_bookmarks_none_explicit(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"bookmarks": None}), encoding="utf-8")
    cfg = load_config(p)
    assert cfg.bookmarks is None


def test_load_config_bookmarks_filters_non_strings(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    p.write_text(json.dumps({"bookmarks": ["/tmp", 42, None, "/var"]}), encoding="utf-8")
    cfg = load_config(p)
    assert cfg.bookmarks == ["/tmp", "/var"]


# ── save_config / round-trip ──────────────────────────────────────────────────


def test_save_creates_parent_dirs(tmp_path: Path) -> None:
    p = tmp_path / "a" / "b" / "config.json"
    save_config(AppConfig(), p)
    assert p.exists()


def test_save_load_roundtrip(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    original = AppConfig(
        start_dir="/tmp",
        default_sort_key="modified",
        default_sort_direction="desc",
        show_hidden_files=True,
        session_restore="disabled",
        session_restore_max_age_hours=12.5,
        bookmarks=["/tmp", "/home"],
    )
    save_config(original, p)
    loaded = load_config(p)
    assert loaded == original


def test_save_bookmarks_none_roundtrip(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    original = AppConfig(bookmarks=None)
    save_config(original, p)
    loaded = load_config(p)
    assert loaded.bookmarks is None


def test_save_is_valid_json(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    save_config(AppConfig(), p)
    data = json.loads(p.read_text(encoding="utf-8"))
    assert isinstance(data, dict)
    assert "start_dir" in data


# ── ensure_config_initialized ─────────────────────────────────────────────


def test_ensure_creates_file_on_first_run(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    cfg = ensure_config_initialized(p)
    assert p.exists()
    assert isinstance(cfg, AppConfig)


def test_ensure_bookmarks_explicit_on_first_run(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    cfg = ensure_config_initialized(p)
    # bookmarks must be an explicit list, not None, after first-run init
    assert cfg.bookmarks is not None
    assert isinstance(cfg.bookmarks, list)


def test_ensure_second_call_loads_existing(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    first = ensure_config_initialized(p)
    first.start_dir = "/tmp"
    save_config(first, p)
    second = ensure_config_initialized(p)
    assert second.start_dir == "/tmp"


def test_ensure_does_not_overwrite_existing_file(tmp_path: Path) -> None:
    p = tmp_path / "config.json"
    # Write a custom config first
    save_config(AppConfig(default_sort_key="size"), p)
    cfg = ensure_config_initialized(p)
    assert cfg.default_sort_key == "size"
