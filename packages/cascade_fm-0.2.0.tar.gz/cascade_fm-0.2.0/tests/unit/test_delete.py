"""Unit tests for the delete_files operation."""

from __future__ import annotations

from pathlib import Path

import pytest

from cascade_fm.operations.delete_files import DeleteFiles


@pytest.fixture()
def operation():
    return DeleteFiles()


@pytest.fixture()
def tmp_files(tmp_path: Path) -> list[Path]:
    files = [tmp_path / f"file_{i}.txt" for i in range(3)]
    for f in files:
        f.write_text("content")
    return files


@pytest.fixture()
def tmp_dir_tree(tmp_path: Path) -> Path:
    d = tmp_path / "subdir"
    d.mkdir()
    (d / "nested.txt").write_text("hello")
    return d


def _run(operation: DeleteFiles, files: list[Path]) -> list[Path]:
    """Helper: set inputs, set params (triggers execution), return output_files."""
    operation.set_input_files(files)
    operation.set_params({})  # no params required; this triggers execute()
    return operation.output_files


class TestDeleteFilesMetadata:
    def test_name(self, operation: DeleteFiles) -> None:
        assert operation.name == "delete_files"

    def test_label(self, operation: DeleteFiles) -> None:
        assert operation.label == "Delete"

    def test_accepts_all(self, operation: DeleteFiles) -> None:
        assert operation.accepts == ["*/*"]

    def test_validate_params_always_valid(self, operation: DeleteFiles) -> None:
        ok, msg = operation.validate_params()
        assert ok is True
        assert msg is None


class TestDeleteFilesExecution:
    def test_deletes_files(self, operation: DeleteFiles, tmp_files: list[Path]) -> None:
        result = _run(operation, tmp_files)
        assert result == []
        for f in tmp_files:
            assert not f.exists()

    def test_deletes_directory_recursively(
        self, operation: DeleteFiles, tmp_dir_tree: Path
    ) -> None:
        result = _run(operation, [tmp_dir_tree])
        assert result == []
        assert not tmp_dir_tree.exists()

    def test_returns_empty_list(self, operation: DeleteFiles, tmp_files: list[Path]) -> None:
        result = _run(operation, tmp_files)
        assert result == []

    def test_skips_nonexistent_paths(self, operation: DeleteFiles, tmp_path: Path) -> None:
        ghost = tmp_path / "does_not_exist.txt"
        result = _run(operation, [ghost])
        assert result == []

    def test_mixed_existing_and_missing(
        self, operation: DeleteFiles, tmp_files: list[Path], tmp_path: Path
    ) -> None:
        ghost = tmp_path / "ghost.txt"
        result = _run(operation, [tmp_files[0], ghost, tmp_files[1]])
        assert result == []
        assert not tmp_files[0].exists()
        assert not tmp_files[1].exists()
        assert tmp_files[2].exists()  # not in list, untouched

    def test_empty_input(self, tmp_path: Path) -> None:
        # An operation with no input files should produce no output and no crash.
        # set_params without prior set_input_files won't trigger execute()
        # because input_files is empty, so output_files stays the initial [].
        op = DeleteFiles()
        op.set_params({})
        assert op.output_files == []


class TestDeleteFilesRegistry:
    def test_registered(self) -> None:
        from cascade_fm.operations.registry import OPERATION_FACTORIES

        assert "delete_files" in OPERATION_FACTORIES

    def test_browser_only(self) -> None:
        from cascade_fm.operations.registry import UI_BROWSER_ONLY_OPERATIONS

        assert "delete_files" in UI_BROWSER_ONLY_OPERATIONS

    def test_not_in_hidden_operations(self) -> None:
        from cascade_fm.operations.registry import UI_HIDDEN_OPERATIONS

        assert "delete_files" not in UI_HIDDEN_OPERATIONS

    def test_appears_in_list_operations_for_ui(self, tmp_files: list[Path]) -> None:
        from cascade_fm.operations.registry import list_operations_for_ui

        ops = list_operations_for_ui(tmp_files)
        assert "delete_files" in ops
