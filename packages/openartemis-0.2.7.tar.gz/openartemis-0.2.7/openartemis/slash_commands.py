"""Extensible slash-command registry for OpenArtemis chat. Register handlers with register_slash_command(cmd, handler)."""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

import typer
from rich.markdown import Markdown
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

# Handler signature: (ctx: dict) -> None. Context has user_input, session, user, is_admin, mode_state, console,
# run_agent, run_research, run_agent_status, and optional extras.
SLASH_REGISTRY: dict[str, Callable[[dict[str, Any]], None]] = {}


def register_slash_command(cmd: str, handler: Callable[[dict[str, Any]], None]) -> None:
    """Register a slash command (e.g. '/help'). Overwrites if cmd already registered."""
    SLASH_REGISTRY[cmd] = handler


def _handle_help(ctx: dict[str, Any]) -> None:
    c = ctx["console"]
    c.print(Panel(
        "[bold]Commands[/bold]\n\n"
        "[cyan]/history[/cyan] — See your recent chats\n"
        "[cyan]/load <number>[/cyan] — Open a previous chat\n"
        "[cyan]/research <query>[/cyan] — Ask Artemis to research something in depth\n"
        "[cyan]/agent[/cyan] — Agent Mode (Plan, Agent, Ask)\n"
        "[cyan]/agent-status[/cyan] — Live agent run status\n"
        "[cyan]/model[/cyan] — Change model (Artemis-1 or Artemis-1-Mini)\n"
        "[cyan]/save[/cyan] — Save chat to a file\n"
        "[cyan]/export[/cyan] — Export chat as markdown\n"
        "[cyan]/logout[/cyan] — Sign out\n"
        "[cyan]/exit[/cyan] — Quit\n\n"
        "[dim]Just type your question to chat with Artemis.[/dim]",
        title="Help",
        border_style="cyan",
    ))
    c.print()


def _handle_exit(ctx: dict[str, Any]) -> None:
    ctx["console"].print("[yellow]Bye.[/yellow]")
    raise typer.Exit(0)


def _handle_logout(ctx: dict[str, Any]) -> None:
    from openartemis.auth import revoke_session
    revoke_session()
    ctx["console"].print("[green]Logged out.[/green]\n")
    raise typer.Exit(0)


def _handle_history(ctx: dict[str, Any]) -> None:
    from openartemis.auth import get_chat_sessions
    c = ctx["console"]
    sessions_list = get_chat_sessions(ctx["user"]["id"], limit=15)
    if not sessions_list:
        c.print("[dim]No chat history.[/dim]\n")
    else:
        for s in sessions_list:
            title = (s.get("title") or "(no title)")[:50]
            c.print(f"  [{s['id']}] {title} — {s.get('updated_at', '')[:16]}")
        c.print("[dim]Use /load <number> to open a chat.[/dim]\n")


def _handle_load(ctx: dict[str, Any]) -> None:
    from openartemis.auth import get_chat_sessions, get_chat_messages
    user_input = ctx["user_input"]
    parts = user_input.strip().split(maxsplit=1)
    sid_str = parts[1].strip() if len(parts) > 1 else ""
    c = ctx["console"]
    if sid_str.isdigit():
        sid = int(sid_str)
        sessions_list = get_chat_sessions(ctx["user"]["id"], limit=100)
        if any(s["id"] == sid for s in sessions_list):
            session = ctx["session"]
            session.session_id = sid
            msgs = get_chat_messages(sid)
            session.messages = [{"role": "system", "content": session.messages[0]["content"]}]
            for m in msgs:
                msg = {"role": m["role"], "content": m.get("content", "")}
                if m.get("tool_calls"):
                    msg["tool_calls"] = m["tool_calls"]
                session.messages.append(msg)
            session._last_persisted = len(session.messages)
            c.print(f"[green]Loaded chat {sid}.[/green]\n")
        else:
            c.print("[yellow]Chat not found.[/yellow]\n")
    else:
        c.print("[yellow]Usage: /load <number>[/yellow]\n")


def _handle_save(ctx: dict[str, Any]) -> None:
    session = ctx["session"]
    save_dir = Path.home() / ".openartemis"
    save_dir.mkdir(parents=True, exist_ok=True)
    save_path = save_dir / "session.json"
    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(session.messages, f, indent=2, ensure_ascii=False)
    ctx["console"].print(f"[green]Chat saved to {save_path}[/green]\n")


def _handle_export(ctx: dict[str, Any]) -> None:
    session = ctx["session"]
    export_dir = Path("./detective_output")
    export_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d_%H-%M")
    export_path = export_dir / f"chat_export_{ts}.md"
    lines = ["# Chat Export\n"]
    for m in session.messages:
        role = m.get("role", "unknown")
        content = m.get("content", "")
        if role == "system":
            continue
        if role == "user":
            lines.append(f"\n## You\n\n{content}\n")
        elif role == "assistant":
            lines.append(f"\n## Artemis\n\n{content}\n")
        elif role == "tool":
            lines.append("\n*[Tool result]*\n")
    export_path.write_text("\n".join(lines), encoding="utf-8")
    ctx["console"].print(f"[green]Exported to {export_path}[/green]\n")


def _handle_harvest(ctx: dict[str, Any]) -> None:
    user_input = ctx["user_input"]
    parts = user_input.strip().split(maxsplit=1)
    url = parts[1].strip() if len(parts) > 1 else ""
    c = ctx["console"]
    if not url:
        c.print("[yellow]/harvest requires a YouTube URL. Example: /harvest https://youtube.com/watch?v=xxx[/yellow]\n")
        return
    session = ctx["session"]
    is_admin = ctx["is_admin"]
    try:
        with Progress(SpinnerColumn(), TextColumn("[dim]Harvesting...[/dim]"), console=c) as progress:
            progress.add_task("", total=None)
            result = session.agent.harvest_url(url)
    except Exception as e:
        c.print(f"[red]Harvest failed: {e}[/red]\n")
        return
    if result.get("harvested_count") and not is_admin:
        session.credits_used += 1
        from openartemis.auth.db import log_usage
        log_usage(ctx["user"]["id"], 1, "harvest")
    if result.get("harvested_count"):
        c.print(f"[green]Harvested transcript: {result.get('title', '')}[/green]")
        c.print(f"  [dim]Saved to {result.get('out_dir', '')}[/dim]")
    else:
        c.print(f"[red]{result.get('error', 'Harvest failed')}[/red]")
    if session.credits_used > 0 and not is_admin:
        c.print(f"  [dim][Credits used: {session.credits_used}][/dim]")
    c.print()


def _handle_summarize(ctx: dict[str, Any]) -> None:
    c = ctx["console"]
    session = ctx["session"]
    c.print(Panel("Summarize your last response in 2-3 sentences.", title="[cyan]You[/cyan]", border_style="cyan"))
    try:
        with Progress(SpinnerColumn(), TextColumn("[dim]Artemis is thinking...[/dim]"), console=c) as progress:
            progress.add_task("", total=None)
            response = session.send("Summarize your last response in 2-3 sentences.")
    except Exception as e:
        c.print(f"[red]Error: {e}[/red]\n")
        return
    c.print(Panel(Markdown(response or "(no response)"), title="[green]Artemis[/green]", border_style="green"))
    if session.credits_used > 0:
        c.print(f"  [dim][Credits used: {session.credits_used}][/dim]")
    c.print()


def _handle_model(ctx: dict[str, Any]) -> None:
    from openartemis.config import resolve_artemis_model
    user_input = ctx["user_input"]
    parts = user_input.strip().split(maxsplit=1)
    new_model = parts[1].strip() if len(parts) > 1 else ""
    c = ctx["console"]
    session = ctx["session"]
    if new_model:
        alias = new_model.strip().lower()
        if alias in ("artemis-1", "artemis-1-mini"):
            session.model_display = "Artemis-1" if alias == "artemis-1" else "Artemis-1-Mini"
            session.model = resolve_artemis_model(session.model_display)
            c.print(f"[green]Model set to {session.model_display}[/green]\n")
        else:
            c.print("[yellow]Use Artemis-1 or Artemis-1-Mini[/yellow]\n")
    else:
        c.print(f"[dim]Current model: {session.model_display}[/dim]")
        c.print("[dim]Usage: /model Artemis-1 or /model Artemis-1-Mini[/dim]\n")


def _handle_agent(ctx: dict[str, Any]) -> None:
    ctx["run_agent"]()


def _handle_agent_status(ctx: dict[str, Any]) -> None:
    ctx["console"].print("[dim]Checking agent status...[/dim]\n")
    ctx["run_agent_status"]()


def _handle_research(ctx: dict[str, Any]) -> None:
    user_input = ctx["user_input"]
    parts = user_input.strip().split(maxsplit=1)
    query = parts[1].strip() if len(parts) > 1 else ""
    c = ctx["console"]
    if not query:
        c.print("[yellow]/research requires a query. Example: /research Find out about recent AI developments[/yellow]\n")
        return
    ctx["run_research"](query)


def _register_builtins() -> None:
    """Register all built-in slash commands. Called on first use."""
    if _register_builtins._done:
        return
    _register_builtins._done = True

    register_slash_command("/help", _handle_help)
    register_slash_command("/?", _handle_help)
    for c in ("/exit", "/quit", "/q"):
        register_slash_command(c, _handle_exit)
    register_slash_command("/logout", _handle_logout)
    register_slash_command("/history", _handle_history)
    register_slash_command("/load", _handle_load)
    register_slash_command("/save", _handle_save)
    register_slash_command("/export", _handle_export)
    register_slash_command("/harvest", _handle_harvest)
    register_slash_command("/summarize", _handle_summarize)
    register_slash_command("/model", _handle_model)
    register_slash_command("/agent", _handle_agent)
    register_slash_command("/agent-status", _handle_agent_status)
    register_slash_command("/research", _handle_research)


_register_builtins._done = False  # type: ignore[attr-defined]
