"""Multi-agent research pipeline — orchestrator, workers, synthesis."""

from openartemis.agent.detective import DetectiveAgent, TOOLS
from openartemis.agent.orchestrator import create_plan
from openartemis.agent.worker import run_worker
from openartemis.agent.pipeline import ResearchPipeline

__all__ = ["DetectiveAgent", "TOOLS", "create_plan", "run_worker", "ResearchPipeline"]
