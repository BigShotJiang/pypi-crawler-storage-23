"""YouTube harvester: TranscriptAPI / Google Data API search + TranscriptAPI / ScrapingDog / youtube-transcript-api or yt-dlp + Whisper."""

import logging
import re
import time
import tempfile
from pathlib import Path
from typing import Any, Iterator

import requests
from youtube_transcript_api import YouTubeTranscriptApi
from youtube_transcript_api._errors import TranscriptsDisabled, VideoUnavailable

from openartemis.harvesters.base import Harvester
from openartemis.output import write_post
from openartemis.transcription import transcribe_audio

logger = logging.getLogger(__name__)

SCRAPINGDOG_URL = "https://api.scrapingdog.com/youtube/transcripts/"
TRANSCRIPTAPI_BASE = "https://transcriptapi.com/api/v2"


class TranscriptAPIInsufficientCreditsError(Exception):
    """Raised when TranscriptAPI returns 402 (insufficient credits)."""


# Match youtube.com/watch?v=ID or youtu.be/ID
YT_VIDEO_ID_RE = re.compile(
    r"(?:youtube\.com/watch\?v=|youtu\.be/)([a-zA-Z0-9_-]{11})"
)


def extract_youtube_video_id(url: str) -> str | None:
    """Extract YouTube video ID from URL. Returns None if not a valid YouTube URL."""
    m = YT_VIDEO_ID_RE.search(url)
    return m.group(1) if m else None


class YouTubeHarvester(Harvester):
    """Harvest YouTube transcripts. Uses TranscriptAPI.com (search+transcript) or Google Data API + captions/Whisper."""

    def __init__(
        self,
        api_key: str | None = None,
        scrapingdog_api_key: str | None = None,
        transcriptapi_api_key: str | None = None,
    ):
        self.api_key = api_key
        self.scrapingdog_api_key = scrapingdog_api_key
        self.transcriptapi_api_key = transcriptapi_api_key
        self._youtube_build = None
        if api_key:
            from googleapiclient.discovery import build
            self._youtube_build = build("youtube", "v3", developerKey=api_key)

    def harvest_url(
        self,
        url: str,
        out_dir: Path,
        whisper_model: str = "base",
    ) -> dict[str, Any] | None:
        """Harvest transcript for a single YouTube URL. Returns transcript data or None."""
        video_id = extract_youtube_video_id(url)
        if not video_id:
            return None
        full_url = f"https://www.youtube.com/watch?v={video_id}"
        try:
            data = self._get_transcript(
                video_id=video_id,
                title="",
                channel="",
                published_at="",
                whisper_model=whisper_model,
                scrapingdog_api_key=self.scrapingdog_api_key,
                transcriptapi_api_key=self.transcriptapi_api_key,
            )
            if data:
                write_post(out_dir, "youtube", video_id, data)
                return data
        except Exception as e:
            logger.warning("Harvest URL failed for %s: %s", url, e)
        return None

    def harvest(
        self,
        query: str,
        max_results: int,
        out_dir: Path,
        whisper_model: str = "base",
    ) -> Iterator[dict[str, Any]]:
        # TranscriptAPI.com: search + transcript (no Google API needed)
        if self.transcriptapi_api_key:
            for data in self._harvest_via_transcriptapi(query, max_results, out_dir, whisper_model):
                if data:
                    yield data
            return

        # Google YouTube Data API for search
        if not self._youtube_build:
            logger.error("Need YOUTUBE_API_KEY (Google) or TRANSCRIPTAPI_API_KEY")
            return
        try:
            search_response = self._youtube_build.search().list(
                q=query,
                type="video",
                part="snippet",
                maxResults=max_results,
            ).execute()
        except Exception as e:
            logger.error("YouTube API error: %s", e)
            return

        for item in search_response.get("items", []):
            video_id = item.get("id", {}).get("videoId")
            if not video_id:
                continue
            snippet = item.get("snippet", {})
            title = snippet.get("title", "")
            channel = snippet.get("channelTitle", "")
            published_at = snippet.get("publishedAt", "")

            try:
                data = self._get_transcript(
                    video_id=video_id,
                    title=title,
                    channel=channel,
                    published_at=published_at,
                    whisper_model=whisper_model,
                    scrapingdog_api_key=self.scrapingdog_api_key,
                    transcriptapi_api_key=self.transcriptapi_api_key,
                )
                if data:
                    write_post(out_dir, "youtube", video_id, data)
                    yield data
            except Exception as e:
                logger.warning("Skipping video %s: %s", video_id, e)
                continue

    def _harvest_via_transcriptapi(
        self,
        query: str,
        max_results: int,
        out_dir: Path,
        whisper_model: str,
    ) -> Iterator[dict[str, Any]]:
        """Harvest using TranscriptAPI.com for both search and transcripts."""
        try:
            resp = requests.get(
                f"{TRANSCRIPTAPI_BASE}/youtube/search",
                params={"q": query, "type": "video", "limit": min(max_results, 50)},
                headers={"Authorization": f"Bearer {self.transcriptapi_api_key}"},
                timeout=30,
            )
            if resp.status_code == 402:
                raise TranscriptAPIInsufficientCreditsError(
                    "Insufficient TranscriptAPI credits. Top up at transcriptapi.com"
                )
            if resp.status_code != 200:
                logger.error("TranscriptAPI search failed: %s", resp.status_code)
                return
            data = resp.json()
        except Exception as e:
            logger.error("TranscriptAPI search error: %s", e)
            return

        for item in data.get("results", []):
            video_id = item.get("videoId")
            if not video_id:
                continue
            title = item.get("title", "")
            channel = item.get("channelTitle", "")
            published_at = item.get("publishedTimeText", "")

            try:
                transcript_data = self._fetch_transcriptapi(
                    video_id,
                    f"https://www.youtube.com/watch?v={video_id}",
                    title,
                    channel,
                    published_at,
                )
                if transcript_data:
                    write_post(out_dir, "youtube", video_id, transcript_data)
                    yield transcript_data
            except Exception as e:
                logger.warning("Skipping video %s: %s", video_id, e)

    def _fetch_transcriptapi(
        self,
        video_id: str,
        url: str,
        title: str,
        channel: str,
        published_at: str,
        api_key: str | None = None,
    ) -> dict[str, Any] | None:
        """Fetch transcript via TranscriptAPI.com. Retries once with 1s backoff on failure."""
        key = api_key or self.transcriptapi_api_key
        if not key:
            return None
        for attempt in range(2):
            try:
                resp = requests.get(
                    f"{TRANSCRIPTAPI_BASE}/youtube/transcript",
                    params={"video_url": video_id, "send_metadata": "true"},
                    headers={"Authorization": f"Bearer {key}"},
                    timeout=60,
                )
                if resp.status_code == 402:
                    raise TranscriptAPIInsufficientCreditsError(
                        "Insufficient TranscriptAPI credits. Top up at transcriptapi.com"
                    )
                if resp.status_code != 200:
                    if attempt == 0:
                        time.sleep(1)
                        continue
                    return None
                data = resp.json()
                raw = data.get("transcript") or []
                meta = data.get("metadata") or {}
                title = meta.get("title") or title
                channel = meta.get("author_name") or channel

                segments = []
                full_parts = []
                for seg in raw:
                    start = seg.get("start", 0)
                    duration = seg.get("duration", 0)
                    text = seg.get("text", "").strip()
                    segments.append({
                        "start": start,
                        "end": start + duration,
                        "duration": duration,
                        "text": text,
                    })
                    full_parts.append(text)
                return {
                    "url": url,
                    "platform": "youtube",
                    "title": title,
                    "channel": channel,
                    "published_at": published_at,
                    "source": "captions",
                    "segments": segments,
                    "full_text": " ".join(full_parts),
                }
            except TranscriptAPIInsufficientCreditsError:
                raise
            except Exception as e:
                if attempt == 0:
                    time.sleep(1)
                    continue
                logger.debug("TranscriptAPI transcript failed for %s: %s", video_id, e)
                return None
        return None

    def _get_transcript(
        self,
        video_id: str,
        title: str,
        channel: str,
        published_at: str,
        whisper_model: str,
        scrapingdog_api_key: str | None = None,
        transcriptapi_api_key: str | None = None,
    ) -> dict[str, Any] | None:
        url = f"https://www.youtube.com/watch?v={video_id}"

        # 1. Try TranscriptAPI.com first (when key is set)
        if transcriptapi_api_key:
            data = self._fetch_transcriptapi(video_id, url, title, channel, published_at, api_key=transcriptapi_api_key)
            if data:
                return data

        # 2. Try ScrapingDog API (when key is set)
        if scrapingdog_api_key:
            data = self._fetch_scrapingdog(video_id, url, title, channel, published_at, scrapingdog_api_key)
            if data:
                return data

        # 3. Try youtube-transcript-api (no API key)
        try:
            transcript_list = YouTubeTranscriptApi.get_transcript(video_id)
            segments = []
            full_parts = []
            for seg in transcript_list:
                start = seg["start"]
                duration = seg.get("duration", 0)
                text = seg.get("text", "").strip()
                segments.append({
                    "start": start,
                    "end": start + duration,
                    "duration": duration,
                    "text": text,
                })
                full_parts.append(text)
            full_text = " ".join(full_parts)

            return {
                "url": url,
                "platform": "youtube",
                "title": title,
                "channel": channel,
                "published_at": published_at,
                "source": "captions",
                "segments": segments,
                "full_text": full_text,
            }
        except (TranscriptsDisabled, VideoUnavailable):
            pass
        except Exception as e:
            logger.debug("Captions failed for %s: %s", video_id, e)

        # 4. Fallback: download audio and transcribe with Whisper
        return self._download_and_transcribe(
            video_id=video_id,
            url=url,
            title=title,
            channel=channel,
            published_at=published_at,
            whisper_model=whisper_model,
        )

    def _fetch_scrapingdog(
        self,
        video_id: str,
        url: str,
        title: str,
        channel: str,
        published_at: str,
        api_key: str,
    ) -> dict[str, Any] | None:
        """Fetch transcript via ScrapingDog API."""
        try:
            resp = requests.get(
                SCRAPINGDOG_URL,
                params={"api_key": api_key, "v": video_id},
                timeout=30,
            )
            if resp.status_code != 200:
                return None
            data = resp.json()
            raw = data.get("transcripts") or data.get("transcript") or []
            if not raw:
                return None
            segments = []
            full_parts = []
            for seg in raw:
                start = seg.get("start", 0)
                duration = seg.get("duration", 0)
                text = seg.get("text", "").strip()
                segments.append({
                    "start": start,
                    "end": start + duration,
                    "duration": duration,
                    "text": text,
                })
                full_parts.append(text)
            return {
                "url": url,
                "platform": "youtube",
                "title": title,
                "channel": channel,
                "published_at": published_at,
                "source": "captions",
                "segments": segments,
                "full_text": " ".join(full_parts),
            }
        except Exception as e:
            logger.debug("ScrapingDog failed for %s: %s", video_id, e)
            return None

    def _download_and_transcribe(
        self,
        video_id: str,
        url: str,
        title: str,
        channel: str,
        published_at: str,
        whisper_model: str,
    ) -> dict[str, Any] | None:
        import yt_dlp

        with tempfile.TemporaryDirectory() as tmpdir:
            out_tmpl = str(Path(tmpdir) / "audio.%(ext)s")
            ydl_opts = {
                "format": "bestaudio/best",
                "postprocessors": [{
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": "wav",
                }],
                "outtmpl": out_tmpl,
                "quiet": True,
            }
            try:
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    ydl.download([url])
            except Exception as e:
                logger.warning("yt-dlp failed for %s: %s", video_id, e)
                return None

            audio_path = Path(tmpdir) / "audio.wav"
            if not audio_path.exists():
                # yt-dlp may use different extension
                audios = list(Path(tmpdir).glob("audio.*"))
                if not audios:
                    return None
                audio_path = audios[0]

            result = transcribe_audio(str(audio_path), whisper_model)
            return {
                "url": url,
                "platform": "youtube",
                "title": title,
                "channel": channel,
                "published_at": published_at,
                "source": "whisper",
                "segments": result["segments"],
                "full_text": result["text"],
            }
