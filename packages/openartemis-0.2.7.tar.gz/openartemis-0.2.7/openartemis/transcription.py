"""Whisper transcription and segment-to-SRT conversion."""

import tempfile
from pathlib import Path
from typing import Any

import whisper


def transcribe_audio(audio_path: str | Path, model_name: str = "base") -> dict[str, Any]:
    """
    Transcribe audio file with Whisper.
    Returns {segments: [{start, end, text}], text: str}.
    """
    model = whisper.load_model(model_name)
    result = model.transcribe(str(audio_path), fp16=False)

    segments = []
    for s in result.get("segments", []):
        segments.append({
            "start": s["start"],
            "end": s["end"],
            "duration": s["end"] - s["start"],
            "text": s.get("text", "").strip(),
        })

    return {
        "segments": segments,
        "text": result.get("text", "").strip(),
    }


def transcribe_from_path(audio_path: str | Path, model_name: str = "base") -> dict[str, Any]:
    """Transcribe from an existing audio file path."""
    return transcribe_audio(audio_path, model_name)
