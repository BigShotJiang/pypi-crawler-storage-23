"""API version for the REST API.

This version is independent from the library release version.
Manage it via `make update-api-version WEBAPISEM=vX.Y.Z`.
"""

__api_version__ = "2.9.5"
