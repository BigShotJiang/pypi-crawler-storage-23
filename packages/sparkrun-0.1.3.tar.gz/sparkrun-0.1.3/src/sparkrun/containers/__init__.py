"""Container image management."""
