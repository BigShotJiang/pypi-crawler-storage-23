
- add icons per activity
- optionally use osmand-specific tags in route description (eg. color per grade, etc.)
- optionally embedd images inside the description
- improve description format (tables for pitches description, ...)
- add tests and testing pipeline
- add format and type checking commit hooks
- setup package building pipeline

In the far future :
- run this as the backend of a web page (eg. using https://streamlit.io/)
- design a front end and host it somewhere (service: paste your camptocamp search url, download your gpx)
