"""smarts-bio — Official Python SDK for the smarts.bio bioinformatics platform."""

from ._client import SmartsBio, SmartsBioAsync
from ._errors import (
    APIError,
    AuthenticationError,
    PermissionDeniedError,
    RateLimitError,
    WorkspaceAccessDeniedError,
)
from ._types import (
    Workspace,
    QueryResponse,
    StreamChunk,
    Conversation,
    ConversationDetail,
    Tool,
    FileMetadata,
    Pipeline,
    ViewerUrlResult,
    RenderJob,
)

__all__ = [
    "SmartsBio",
    "SmartsBioAsync",
    "APIError",
    "AuthenticationError",
    "PermissionDeniedError",
    "RateLimitError",
    "WorkspaceAccessDeniedError",
    "Workspace",
    "QueryResponse",
    "StreamChunk",
    "Conversation",
    "ConversationDetail",
    "Tool",
    "FileMetadata",
    "Pipeline",
    "ViewerUrlResult",
    "RenderJob",
]

__version__ = "0.1.0"
