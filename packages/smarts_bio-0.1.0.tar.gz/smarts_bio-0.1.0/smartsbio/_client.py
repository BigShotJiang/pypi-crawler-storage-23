from __future__ import annotations

import os
from typing import Optional

from ._http import SyncHTTP, AsyncHTTP, DEFAULT_BASE_URL, DEFAULT_TIMEOUT, DEFAULT_MAX_RETRIES
from .resources.workspaces import WorkspacesResource, AsyncWorkspacesResource
from .resources.query import QueryResource
from .resources.query_async import AsyncQueryResource
from .resources.conversations import ConversationsResource, AsyncConversationsResource
from .resources.tools import ToolsResource, AsyncToolsResource
from .resources.files import FilesResource, AsyncFilesResource
from .resources.pipelines import PipelinesResource, AsyncPipelinesResource
from .resources.visualizations import VisualizationsResource, AsyncVisualizationsResource


class SmartsBio:
    """Synchronous smarts.bio API client."""

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        resolved_key = api_key or os.environ.get("SMARTSBIO_API_KEY")
        if not resolved_key:
            raise ValueError(
                "API key is required. Pass api_key= or set the SMARTSBIO_API_KEY environment variable."
            )

        self._http = SyncHTTP(resolved_key, base_url=base_url, timeout=timeout, max_retries=max_retries)
        self.workspaces = WorkspacesResource(self._http)
        self.query = QueryResource(self._http)
        self.conversations = ConversationsResource(self._http)
        self.tools = ToolsResource(self._http)
        self.files = FilesResource(self._http)
        self.pipelines = PipelinesResource(self._http)
        self.visualizations = VisualizationsResource(self._http)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "SmartsBio":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class SmartsBioAsync:
    """Asynchronous smarts.bio API client. Use as an async context manager."""

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        resolved_key = api_key or os.environ.get("SMARTSBIO_API_KEY")
        if not resolved_key:
            raise ValueError(
                "API key is required. Pass api_key= or set the SMARTSBIO_API_KEY environment variable."
            )

        self._http = AsyncHTTP(resolved_key, base_url=base_url, timeout=timeout, max_retries=max_retries)
        self.workspaces = AsyncWorkspacesResource(self._http)
        self.query = AsyncQueryResource(self._http)
        self.conversations = AsyncConversationsResource(self._http)
        self.tools = AsyncToolsResource(self._http)
        self.files = AsyncFilesResource(self._http)
        self.pipelines = AsyncPipelinesResource(self._http)
        self.visualizations = AsyncVisualizationsResource(self._http)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "SmartsBioAsync":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.aclose()
