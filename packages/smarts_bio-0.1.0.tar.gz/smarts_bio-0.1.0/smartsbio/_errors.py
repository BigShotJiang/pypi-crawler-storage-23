from __future__ import annotations


class APIError(Exception):
    """Base exception for all smarts.bio API errors."""

    def __init__(self, status: int, error_code: str, message: str) -> None:
        super().__init__(message)
        self.status = status
        self.error_code = error_code
        self.message = message

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(status={self.status}, error_code={self.error_code!r}, message={self.message!r})"


class AuthenticationError(APIError):
    """Raised when the API key is invalid, revoked, or expired (HTTP 401)."""

    def __init__(self, message: str = "Invalid or revoked API key") -> None:
        super().__init__(401, "auth_required", message)


class PermissionDeniedError(APIError):
    """Raised when the API key lacks the required scope (HTTP 403)."""

    def __init__(self, message: str = "Insufficient scope", required_scope: str | None = None) -> None:
        super().__init__(403, "insufficient_scope", message)
        self.required_scope = required_scope


class WorkspaceAccessDeniedError(APIError):
    """Raised when the API key is not scoped to the requested workspace (HTTP 403)."""

    def __init__(self, message: str = "API key is not scoped to this workspace") -> None:
        super().__init__(403, "workspace_access_denied", message)


class RateLimitError(APIError):
    """Raised when the API rate limit is exceeded (HTTP 429)."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: float | None = None) -> None:
        super().__init__(429, "rate_limit_exceeded", message)
        self.retry_after = retry_after
