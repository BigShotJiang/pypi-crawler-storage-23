from __future__ import annotations

import time
from typing import Any, Dict, Optional

import httpx

from ._errors import APIError, AuthenticationError, PermissionDeniedError, RateLimitError, WorkspaceAccessDeniedError

DEFAULT_BASE_URL = "https://api.smarts.bio"
DEFAULT_TIMEOUT = 120.0
DEFAULT_MAX_RETRIES = 3


def _map_error(response: httpx.Response) -> None:
    """Raise a typed error based on the HTTP response status."""
    try:
        body = response.json()
    except Exception:
        body = {}

    msg: str = body.get("message") or response.reason_phrase or "Unknown error"
    code: str = body.get("error") or "unknown_error"

    if response.status_code == 401:
        raise AuthenticationError(msg)
    if response.status_code == 403:
        if code == "workspace_access_denied":
            raise WorkspaceAccessDeniedError(msg)
        raise PermissionDeniedError(msg)
    if response.status_code == 429:
        retry_after_raw = response.headers.get("retry-after")
        retry_after = float(retry_after_raw) if retry_after_raw else None
        raise RateLimitError(msg, retry_after)
    raise APIError(response.status_code, code, msg)


class SyncHTTP:
    """Thin synchronous HTTP client wrapping httpx.Client."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client = httpx.Client(
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    def close(self) -> None:
        self._client.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Any] = None,
        data: Optional[Any] = None,
        files: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
        stream: bool = False,
    ) -> httpx.Response:
        url = f"{self._base_url}{path}"
        req_headers = dict(headers or {})
        # Remove Content-Type for multipart so httpx sets it with boundary
        if files is not None:
            req_headers.pop("Content-Type", None)

        for attempt in range(self._max_retries + 1):
            try:
                if stream:
                    return self._client.send(
                        self._client.build_request(
                            method, url, params=params, json=json, data=data, files=files, headers=req_headers
                        ),
                        stream=True,
                    )
                response = self._client.request(
                    method, url, params=params, json=json, data=data, files=files, headers=req_headers
                )
                if response.is_success:
                    return response
                if response.status_code not in (429,) and 400 <= response.status_code < 500:
                    _map_error(response)
                if attempt < self._max_retries:
                    retry_after = response.headers.get("retry-after")
                    time.sleep(float(retry_after) if retry_after else 2 ** attempt * 0.5)
                    continue
                _map_error(response)
            except (AuthenticationError, PermissionDeniedError, WorkspaceAccessDeniedError, RateLimitError, APIError):
                raise
            except httpx.TimeoutException as exc:
                if attempt >= self._max_retries:
                    raise APIError(0, "timeout", str(exc)) from exc
                time.sleep(2 ** attempt * 0.5)

        raise APIError(0, "max_retries_exceeded", "Request failed after maximum retries")


class AsyncHTTP:
    """Thin asynchronous HTTP client wrapping httpx.AsyncClient."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            timeout=timeout,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Any] = None,
        data: Optional[Any] = None,
        files: Optional[Any] = None,
        headers: Optional[Dict[str, str]] = None,
        stream: bool = False,
    ) -> httpx.Response:
        url = f"{self._base_url}{path}"
        req_headers = dict(headers or {})
        if files is not None:
            req_headers.pop("Content-Type", None)

        import asyncio

        for attempt in range(self._max_retries + 1):
            try:
                if stream:
                    req = self._client.build_request(
                        method, url, params=params, json=json, data=data, files=files, headers=req_headers
                    )
                    return await self._client.send(req, stream=True)
                response = await self._client.request(
                    method, url, params=params, json=json, data=data, files=files, headers=req_headers
                )
                if response.is_success:
                    return response
                if response.status_code not in (429,) and 400 <= response.status_code < 500:
                    _map_error(response)
                if attempt < self._max_retries:
                    retry_after = response.headers.get("retry-after")
                    await asyncio.sleep(float(retry_after) if retry_after else 2 ** attempt * 0.5)
                    continue
                _map_error(response)
            except (AuthenticationError, PermissionDeniedError, WorkspaceAccessDeniedError, RateLimitError, APIError):
                raise
            except httpx.TimeoutException as exc:
                if attempt >= self._max_retries:
                    raise APIError(0, "timeout", str(exc)) from exc
                await asyncio.sleep(2 ** attempt * 0.5)

        raise APIError(0, "max_retries_exceeded", "Request failed after maximum retries")
