from __future__ import annotations

import json
from typing import AsyncIterator, Iterator

import httpx

from ._types import StreamChunk


def parse_sse(response: httpx.Response) -> Iterator[StreamChunk]:
    """Parse a synchronous SSE stream from an httpx Response."""
    buffer = ""
    for chunk in response.iter_text():
        buffer += chunk
        while "\n\n" in buffer:
            event, buffer = buffer.split("\n\n", 1)
            data = _extract_data(event)
            if data and data != "[DONE]":
                try:
                    yield _to_chunk(json.loads(data))
                except (json.JSONDecodeError, KeyError):
                    pass


async def parse_sse_async(response: httpx.Response) -> AsyncIterator[StreamChunk]:
    """Parse an asynchronous SSE stream from an httpx Response."""
    buffer = ""
    async for chunk in response.aiter_text():
        buffer += chunk
        while "\n\n" in buffer:
            event, buffer = buffer.split("\n\n", 1)
            data = _extract_data(event)
            if data and data != "[DONE]":
                try:
                    yield _to_chunk(json.loads(data))
                except (json.JSONDecodeError, KeyError):
                    pass


def _extract_data(event_block: str) -> str | None:
    for line in event_block.splitlines():
        if line.startswith("data: "):
            return line[6:].strip()
    return None


def _to_chunk(obj: dict) -> StreamChunk:
    return StreamChunk(
        type=obj.get("type", "content"),
        content=obj.get("content"),
        status=obj.get("status"),
        tool=obj.get("tool"),
        error=obj.get("error"),
    )
