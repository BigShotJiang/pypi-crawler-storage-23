from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional


# ── Workspaces ────────────────────────────────────────────────────────────────

@dataclass
class Workspace:
    id: str
    name: str
    description: Optional[str] = None
    created_at: Optional[str] = None


# ── Query ─────────────────────────────────────────────────────────────────────

@dataclass
class QueryResponse:
    answer: str
    conversation_id: Optional[str] = None


StreamChunkType = Literal["status", "content", "tool_call", "done", "error"]


@dataclass
class StreamChunk:
    type: StreamChunkType
    content: Optional[str] = None
    status: Optional[str] = None
    tool: Optional[str] = None
    error: Optional[str] = None


# ── Conversations ─────────────────────────────────────────────────────────────

@dataclass
class ConversationMessage:
    role: str
    content: str
    created_at: Optional[str] = None


@dataclass
class Conversation:
    id: str
    workspace_id: str
    title: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class ConversationDetail(Conversation):
    messages: List[ConversationMessage] = field(default_factory=list)


# ── Tools ─────────────────────────────────────────────────────────────────────

@dataclass
class Tool:
    id: str
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = None


# ── Files ─────────────────────────────────────────────────────────────────────

@dataclass
class FileMetadata:
    key: str
    name: str
    size: int
    content_type: Optional[str] = None
    file_id: Optional[str] = None
    created_at: Optional[str] = None


@dataclass
class PresignedUploadResult:
    upload_url: str
    file_key: str
    expires_in: int


# ── Pipelines ─────────────────────────────────────────────────────────────────

PipelineStatus = Literal["queued", "running", "completed", "failed", "cancelled"]


@dataclass
class Pipeline:
    id: str
    status: str
    progress_pct: Optional[int] = None
    current_step: Optional[str] = None
    output_paths: Optional[List[str]] = None
    logs_path: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    error: Optional[str] = None


# ── Visualizations ────────────────────────────────────────────────────────────

@dataclass
class ViewerUrlResult:
    viewer_url: str
    format: str
    expires_in: int
    expires_at: str


@dataclass
class RenderJob:
    job_id: str
    status: str
    output_path: Optional[str] = None
    preview_url: Optional[str] = None
