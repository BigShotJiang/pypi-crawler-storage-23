from __future__ import annotations

from typing import Any, Dict, List, Optional

from .._http import SyncHTTP, AsyncHTTP
from .._types import Tool


def _parse(item: dict) -> Tool:
    return Tool(
        id=item.get("id", ""),
        name=item.get("name", ""),
        description=item.get("description"),
        category=item.get("category"),
        parameters=item.get("parameters"),
    )


class ToolsResource:
    def __init__(self, http: SyncHTTP) -> None:
        self._http = http

    def list(self) -> List[Tool]:
        res = self._http.request("GET", "/v1/tools")
        data = res.json()
        items = data.get("tools", data) if isinstance(data, dict) else data
        return [_parse(t) for t in items]

    def run(self, tool_id: str, input: Dict[str, Any], *, workspace_id: Optional[str] = None) -> Any:
        body: dict = {"input": input}
        if workspace_id:
            body["workspace_id"] = workspace_id
        res = self._http.request("POST", f"/v1/tools/{tool_id}/run", json=body)
        return res.json()


class AsyncToolsResource:
    def __init__(self, http: AsyncHTTP) -> None:
        self._http = http

    async def list(self) -> List[Tool]:
        res = await self._http.request("GET", "/v1/tools")
        data = res.json()
        items = data.get("tools", data) if isinstance(data, dict) else data
        return [_parse(t) for t in items]

    async def run(self, tool_id: str, input: Dict[str, Any], *, workspace_id: Optional[str] = None) -> Any:
        body: dict = {"input": input}
        if workspace_id:
            body["workspace_id"] = workspace_id
        res = await self._http.request("POST", f"/v1/tools/{tool_id}/run", json=body)
        return res.json()
