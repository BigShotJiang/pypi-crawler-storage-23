from __future__ import annotations

from typing import List, Optional

from .._http import SyncHTTP, AsyncHTTP
from .._types import Conversation, ConversationDetail, ConversationMessage


def _parse(item: dict) -> Conversation:
    return Conversation(
        id=item.get("id", ""),
        workspace_id=item.get("workspaceId") or item.get("workspace_id", ""),
        title=item.get("title"),
        created_at=item.get("createdAt") or item.get("created_at"),
        updated_at=item.get("updatedAt") or item.get("updated_at"),
    )


def _parse_detail(item: dict) -> ConversationDetail:
    base = _parse(item)
    messages = [
        ConversationMessage(
            role=m.get("role", ""),
            content=m.get("content", ""),
            created_at=m.get("createdAt") or m.get("created_at"),
        )
        for m in item.get("messages", [])
    ]
    return ConversationDetail(**{**base.__dict__, "messages": messages})


class ConversationsResource:
    def __init__(self, http: SyncHTTP) -> None:
        self._http = http

    def list(
        self,
        workspace_id: str,
        *,
        limit: int = 20,
        before: Optional[str] = None,
    ) -> List[Conversation]:
        params: dict = {"workspace_id": workspace_id, "limit": limit}
        if before:
            params["before"] = before
        res = self._http.request("GET", "/v1/conversations", params=params)
        data = res.json()
        items = data.get("data", data) if isinstance(data, dict) else data
        return [_parse(c) for c in items]

    def get(self, id: str, workspace_id: str) -> ConversationDetail:
        res = self._http.request("GET", f"/v1/conversations/{id}", params={"workspace_id": workspace_id})
        return _parse_detail(res.json())


class AsyncConversationsResource:
    def __init__(self, http: AsyncHTTP) -> None:
        self._http = http

    async def list(self, workspace_id: str, *, limit: int = 20, before: Optional[str] = None) -> List[Conversation]:
        params: dict = {"workspace_id": workspace_id, "limit": limit}
        if before:
            params["before"] = before
        res = await self._http.request("GET", "/v1/conversations", params=params)
        data = res.json()
        items = data.get("data", data) if isinstance(data, dict) else data
        return [_parse(c) for c in items]

    async def get(self, id: str, workspace_id: str) -> ConversationDetail:
        res = await self._http.request("GET", f"/v1/conversations/{id}", params={"workspace_id": workspace_id})
        return _parse_detail(res.json())
