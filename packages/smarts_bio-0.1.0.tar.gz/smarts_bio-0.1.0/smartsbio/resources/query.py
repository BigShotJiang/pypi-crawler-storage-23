from __future__ import annotations

from typing import Iterator, Optional

from .._http import SyncHTTP
from .._streaming import parse_sse
from .._types import QueryResponse, StreamChunk


class QueryResource:
    def __init__(self, http: SyncHTTP) -> None:
        self._http = http

    def run(
        self,
        prompt: str,
        *,
        workspace_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
    ) -> QueryResponse:
        body = {"prompt": prompt}
        if workspace_id:
            body["workspace_id"] = workspace_id
        if conversation_id:
            body["conversation_id"] = conversation_id

        res = self._http.request("POST", "/v1/query", json=body)
        data = res.json()
        return QueryResponse(
            answer=data.get("result") or data.get("answer") or "",
            conversation_id=data.get("sessionId") or data.get("conversationId") or data.get("conversation_id"),
        )

    def stream(
        self,
        prompt: str,
        *,
        workspace_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
    ) -> Iterator[StreamChunk]:
        body = {"prompt": prompt}
        if workspace_id:
            body["workspace_id"] = workspace_id
        if conversation_id:
            body["conversation_id"] = conversation_id

        with self._http.request(
            "POST",
            "/v1/query/stream",
            json=body,
            headers={"Accept": "text/event-stream"},
            stream=True,
        ) as res:
            yield from parse_sse(res)
