from __future__ import annotations

from typing import List

from .._http import SyncHTTP, AsyncHTTP
from .._types import Workspace


def _parse(item: dict) -> Workspace:
    return Workspace(
        id=item.get("id", ""),
        name=item.get("name", ""),
        description=item.get("description"),
        created_at=item.get("createdAt"),
    )


class WorkspacesResource:
    def __init__(self, http: SyncHTTP) -> None:
        self._http = http

    def list(self) -> List[Workspace]:
        res = self._http.request("GET", "/v1/workspaces")
        data = res.json()
        items = data.get("data", data) if isinstance(data, dict) else data
        return [_parse(w) for w in items]


class AsyncWorkspacesResource:
    def __init__(self, http: AsyncHTTP) -> None:
        self._http = http

    async def list(self) -> List[Workspace]:
        res = await self._http.request("GET", "/v1/workspaces")
        data = res.json()
        items = data.get("data", data) if isinstance(data, dict) else data
        return [_parse(w) for w in items]
