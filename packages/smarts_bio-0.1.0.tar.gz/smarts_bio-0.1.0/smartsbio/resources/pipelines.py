from __future__ import annotations

import time
from typing import Any, Callable, Dict, List, Optional

from .._errors import APIError
from .._http import SyncHTTP, AsyncHTTP
from .._types import Pipeline


def _parse(item: dict) -> Pipeline:
    return Pipeline(
        id=item.get("id", ""),
        status=item.get("status", ""),
        progress_pct=item.get("progressPct") or item.get("progress_pct"),
        current_step=item.get("currentStep") or item.get("current_step"),
        output_paths=item.get("outputPaths") or item.get("output_paths"),
        logs_path=item.get("logsPath") or item.get("logs_path"),
        created_at=item.get("createdAt") or item.get("created_at"),
        updated_at=item.get("updatedAt") or item.get("updated_at"),
        error=item.get("error"),
    )


_TERMINAL = {"completed", "failed", "cancelled"}


class PipelinesResource:
    def __init__(self, http: SyncHTTP) -> None:
        self._http = http

    def create(
        self,
        workspace_id: str,
        input: Dict[str, Any],
        *,
        pipeline_id: Optional[str] = None,
        tool_id: Optional[str] = None,
    ) -> Pipeline:
        body: dict = {"workspace_id": workspace_id, "input": input}
        if pipeline_id:
            body["pipeline_id"] = pipeline_id
        if tool_id:
            body["tool_id"] = tool_id
        res = self._http.request("POST", "/v1/pipelines", json=body)
        return _parse(res.json())

    def list(self, workspace_id: str, *, status: Optional[str] = None, limit: Optional[int] = None) -> List[Pipeline]:
        params: dict = {"workspace_id": workspace_id}
        if status:
            params["status"] = status
        if limit is not None:
            params["limit"] = limit
        res = self._http.request("GET", "/v1/pipelines", params=params)
        data = res.json()
        items = data.get("data", data) if isinstance(data, dict) else data
        return [_parse(p) for p in items]

    def get(self, id: str, workspace_id: str) -> Pipeline:
        res = self._http.request("GET", f"/v1/pipelines/{id}", params={"workspace_id": workspace_id})
        return _parse(res.json())

    def cancel(self, id: str, workspace_id: str) -> None:
        self._http.request("DELETE", f"/v1/pipelines/{id}", params={"workspace_id": workspace_id})

    def wait(
        self,
        id: str,
        workspace_id: str,
        *,
        poll_interval: float = 10.0,
        on_progress: Optional[Callable[[Pipeline], None]] = None,
    ) -> Pipeline:
        while True:
            pipeline = self.get(id, workspace_id)
            if on_progress:
                on_progress(pipeline)
            if pipeline.status in _TERMINAL:
                if pipeline.status == "failed":
                    raise APIError(500, "pipeline_failed", pipeline.error or "Pipeline failed")
                return pipeline
            time.sleep(poll_interval)


class AsyncPipelinesResource:
    def __init__(self, http: AsyncHTTP) -> None:
        self._http = http

    async def create(self, workspace_id: str, input: Dict[str, Any], *, pipeline_id: Optional[str] = None, tool_id: Optional[str] = None) -> Pipeline:
        body: dict = {"workspace_id": workspace_id, "input": input}
        if pipeline_id:
            body["pipeline_id"] = pipeline_id
        if tool_id:
            body["tool_id"] = tool_id
        res = await self._http.request("POST", "/v1/pipelines", json=body)
        return _parse(res.json())

    async def list(self, workspace_id: str, *, status: Optional[str] = None) -> List[Pipeline]:
        params: dict = {"workspace_id": workspace_id}
        if status:
            params["status"] = status
        res = await self._http.request("GET", "/v1/pipelines", params=params)
        data = res.json()
        items = data.get("data", data) if isinstance(data, dict) else data
        return [_parse(p) for p in items]

    async def get(self, id: str, workspace_id: str) -> Pipeline:
        res = await self._http.request("GET", f"/v1/pipelines/{id}", params={"workspace_id": workspace_id})
        return _parse(res.json())

    async def cancel(self, id: str, workspace_id: str) -> None:
        await self._http.request("DELETE", f"/v1/pipelines/{id}", params={"workspace_id": workspace_id})

    async def wait(self, id: str, workspace_id: str, *, poll_interval: float = 10.0, on_progress=None) -> Pipeline:
        import asyncio
        while True:
            pipeline = await self.get(id, workspace_id)
            if on_progress:
                on_progress(pipeline)
            if pipeline.status in _TERMINAL:
                if pipeline.status == "failed":
                    raise APIError(500, "pipeline_failed", pipeline.error or "Pipeline failed")
                return pipeline
            await asyncio.sleep(poll_interval)
