from __future__ import annotations

import io
from pathlib import Path
from typing import BinaryIO, List, Optional, Union

from .._http import SyncHTTP, AsyncHTTP
from .._types import FileMetadata, PresignedUploadResult


def _parse(item: dict) -> FileMetadata:
    return FileMetadata(
        key=item.get("key", ""),
        name=item.get("name", ""),
        size=item.get("size", 0),
        content_type=item.get("contentType") or item.get("content_type"),
        file_id=item.get("fileId") or item.get("file_id"),
        created_at=item.get("createdAt") or item.get("created_at"),
    )


class FilesResource:
    def __init__(self, http: SyncHTTP) -> None:
        self._http = http

    def list(
        self,
        workspace_id: str,
        *,
        prefix: Optional[str] = None,
        limit: Optional[int] = None,
        after: Optional[str] = None,
    ) -> List[FileMetadata]:
        params: dict = {"workspace_id": workspace_id}
        if prefix:
            params["prefix"] = prefix
        if limit is not None:
            params["limit"] = limit
        if after:
            params["after"] = after
        res = self._http.request("GET", "/v1/files", params=params)
        data = res.json()
        items = data.get("data", data) if isinstance(data, dict) else data
        return [_parse(f) for f in items]

    def upload(
        self,
        file: Union[str, Path, BinaryIO],
        workspace_id: str,
        *,
        path: Optional[str] = None,
        description: Optional[str] = None,
    ) -> FileMetadata:
        if isinstance(file, (str, Path)):
            p = Path(file)
            filename = p.name
            file_obj: BinaryIO = open(p, "rb")
            close_after = True
        else:
            filename = getattr(file, "name", "upload")
            if isinstance(filename, str):
                filename = Path(filename).name
            file_obj = file
            close_after = False

        try:
            data: dict = {"workspace_id": workspace_id}
            if path:
                data["path"] = path
            if description:
                data["description"] = description
            files = {"file": (filename, file_obj)}
            res = self._http.request("POST", "/v1/files/upload", data=data, files=files)
        finally:
            if close_after:
                file_obj.close()

        return _parse(res.json())

    def get_download_url(self, key: str, workspace_id: str) -> str:
        res = self._http.request("GET", "/v1/files/download", params={"workspace_id": workspace_id, "key": key})
        data = res.json()
        return data.get("url") or data.get("downloadUrl", "")

    def download(self, key: str, workspace_id: str, *, dest: Union[str, Path]) -> Path:
        """Download a file to a local path. Returns the Path where it was saved."""
        import httpx

        url = self.get_download_url(key, workspace_id)
        dest_path = Path(dest)
        with httpx.stream("GET", url) as response:
            response.raise_for_status()
            with open(dest_path, "wb") as f:
                for chunk in response.iter_bytes():
                    f.write(chunk)
        return dest_path

    def delete(self, key: str, workspace_id: str) -> None:
        self._http.request("DELETE", "/v1/files", params={"workspace_id": workspace_id, "key": key})

    def get_upload_url(
        self,
        workspace_id: str,
        filename: str,
        content_type: str,
        size: int,
        *,
        path: Optional[str] = None,
    ) -> PresignedUploadResult:
        body = {"workspace_id": workspace_id, "filename": filename, "contentType": content_type, "size": size}
        if path:
            body["path"] = path
        res = self._http.request("POST", "/v1/files/upload-url", json=body)
        data = res.json()
        return PresignedUploadResult(
            upload_url=data.get("uploadUrl", ""),
            file_key=data.get("fileKey", ""),
            expires_in=data.get("expiresIn", 3600),
        )

    def confirm_upload(
        self,
        workspace_id: str,
        file_key: str,
        filename: str,
        size: int,
        content_type: str,
    ) -> FileMetadata:
        body = {
            "workspace_id": workspace_id,
            "fileKey": file_key,
            "filename": filename,
            "size": size,
            "contentType": content_type,
        }
        res = self._http.request("POST", "/v1/files/upload-confirm", json=body)
        return _parse(res.json())


class AsyncFilesResource:
    def __init__(self, http: AsyncHTTP) -> None:
        self._http = http

    async def list(self, workspace_id: str, *, prefix: Optional[str] = None, limit: Optional[int] = None) -> List[FileMetadata]:
        params: dict = {"workspace_id": workspace_id}
        if prefix:
            params["prefix"] = prefix
        if limit is not None:
            params["limit"] = limit
        res = await self._http.request("GET", "/v1/files", params=params)
        data = res.json()
        items = data.get("data", data) if isinstance(data, dict) else data
        return [_parse(f) for f in items]

    async def upload(self, file: Union[str, Path, BinaryIO], workspace_id: str, *, path: Optional[str] = None) -> FileMetadata:
        if isinstance(file, (str, Path)):
            p = Path(file)
            data_bytes = p.read_bytes()
            filename = p.name
            file_obj: BinaryIO = io.BytesIO(data_bytes)
        else:
            filename = getattr(file, "name", "upload")
            if isinstance(filename, str):
                filename = Path(filename).name
            file_obj = file

        form_data: dict = {"workspace_id": workspace_id}
        if path:
            form_data["path"] = path
        files = {"file": (filename, file_obj)}
        res = await self._http.request("POST", "/v1/files/upload", data=form_data, files=files)
        return _parse(res.json())

    async def get_download_url(self, key: str, workspace_id: str) -> str:
        res = await self._http.request("GET", "/v1/files/download", params={"workspace_id": workspace_id, "key": key})
        data = res.json()
        return data.get("url") or data.get("downloadUrl", "")

    async def delete(self, key: str, workspace_id: str) -> None:
        await self._http.request("DELETE", "/v1/files", params={"workspace_id": workspace_id, "key": key})
