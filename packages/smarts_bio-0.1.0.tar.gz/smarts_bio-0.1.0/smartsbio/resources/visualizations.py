from __future__ import annotations

from typing import Any, Dict, Optional

from .._http import SyncHTTP, AsyncHTTP
from .._types import RenderJob, ViewerUrlResult


class VisualizationsResource:
    def __init__(self, http: SyncHTTP) -> None:
        self._http = http

    def viewer_url(
        self,
        file_path: str,
        workspace_id: str,
        *,
        expires_in: int = 3600,
    ) -> ViewerUrlResult:
        body = {"file_path": file_path, "workspace_id": workspace_id, "expires_in": expires_in}
        res = self._http.request("POST", "/v1/visualizations/viewer-url", json=body)
        data = res.json()
        return ViewerUrlResult(
            viewer_url=data.get("viewerUrl") or data.get("viewer_url", ""),
            format=data.get("format", ""),
            expires_in=data.get("expiresIn") or data.get("expires_in", expires_in),
            expires_at=data.get("expiresAt") or data.get("expires_at", ""),
        )

    def render(
        self,
        type: str,
        file_path: str,
        workspace_id: str,
        *,
        options: Optional[Dict[str, Any]] = None,
        output_format: str = "png",
        output_path: Optional[str] = None,
    ) -> RenderJob:
        body: dict = {
            "type": type,
            "file_key": file_path,
            "workspace_id": workspace_id,
            "output_format": output_format,
        }
        if options:
            body["options"] = options
        if output_path:
            body["output_path"] = output_path
        res = self._http.request("POST", "/v1/visualizations/render", json=body)
        data = res.json()
        return RenderJob(
            job_id=data.get("jobId") or data.get("job_id", ""),
            status=data.get("status", "queued"),
        )

    def get_render_status(self, job_id: str) -> RenderJob:
        res = self._http.request("GET", f"/v1/visualizations/{job_id}")
        data = res.json()
        return RenderJob(
            job_id=data.get("jobId") or data.get("job_id", job_id),
            status=data.get("status", ""),
            output_path=data.get("outputPath") or data.get("output_path"),
            preview_url=data.get("previewUrl") or data.get("preview_url"),
        )


class AsyncVisualizationsResource:
    def __init__(self, http: AsyncHTTP) -> None:
        self._http = http

    async def viewer_url(self, file_path: str, workspace_id: str, *, expires_in: int = 3600) -> ViewerUrlResult:
        body = {"file_path": file_path, "workspace_id": workspace_id, "expires_in": expires_in}
        res = await self._http.request("POST", "/v1/visualizations/viewer-url", json=body)
        data = res.json()
        return ViewerUrlResult(
            viewer_url=data.get("viewerUrl") or data.get("viewer_url", ""),
            format=data.get("format", ""),
            expires_in=data.get("expiresIn") or data.get("expires_in", expires_in),
            expires_at=data.get("expiresAt") or data.get("expires_at", ""),
        )

    async def get_render_status(self, job_id: str) -> RenderJob:
        res = await self._http.request("GET", f"/v1/visualizations/{job_id}")
        data = res.json()
        return RenderJob(
            job_id=data.get("jobId") or data.get("job_id", job_id),
            status=data.get("status", ""),
            output_path=data.get("outputPath") or data.get("output_path"),
            preview_url=data.get("previewUrl") or data.get("preview_url"),
        )
