from __future__ import annotations

from typing import AsyncIterator, Optional

from .._http import AsyncHTTP
from .._streaming import parse_sse_async
from .._types import QueryResponse, StreamChunk


class AsyncQueryResource:
    def __init__(self, http: AsyncHTTP) -> None:
        self._http = http

    async def run(
        self,
        prompt: str,
        *,
        workspace_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
    ) -> QueryResponse:
        body = {"prompt": prompt}
        if workspace_id:
            body["workspace_id"] = workspace_id
        if conversation_id:
            body["conversation_id"] = conversation_id

        res = await self._http.request("POST", "/v1/query", json=body)
        data = res.json()
        return QueryResponse(
            answer=data.get("result") or data.get("answer") or "",
            conversation_id=data.get("sessionId") or data.get("conversationId") or data.get("conversation_id"),
        )

    async def stream(
        self,
        prompt: str,
        *,
        workspace_id: Optional[str] = None,
        conversation_id: Optional[str] = None,
    ) -> AsyncIterator[StreamChunk]:
        body = {"prompt": prompt}
        if workspace_id:
            body["workspace_id"] = workspace_id
        if conversation_id:
            body["conversation_id"] = conversation_id

        async with await self._http.request(
            "POST",
            "/v1/query/stream",
            json=body,
            headers={"Accept": "text/event-stream"},
            stream=True,
        ) as res:
            async for chunk in parse_sse_async(res):
                yield chunk
