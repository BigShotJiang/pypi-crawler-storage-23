from yc_bench.cli import app_main

app_main()
