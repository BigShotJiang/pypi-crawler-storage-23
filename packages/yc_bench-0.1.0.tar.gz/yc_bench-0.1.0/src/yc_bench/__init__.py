"""YC-Bench: long-horizon deterministic benchmark for LLM agents."""

__version__ = "0.1.0"
