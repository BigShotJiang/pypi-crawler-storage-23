#!/usr/bin/env python3

"""R5py-specific warnings."""


class R5pyWarning(RuntimeWarning):
    """Generic base warning for r5py errors."""
