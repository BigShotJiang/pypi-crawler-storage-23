#!/usr/bin/env python3

"""Test the r5py package."""
