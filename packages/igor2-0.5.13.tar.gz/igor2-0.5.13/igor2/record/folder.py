from .base import TextRecord


class FolderStartRecord (TextRecord):
    pass


class FolderEndRecord (TextRecord):
    pass
