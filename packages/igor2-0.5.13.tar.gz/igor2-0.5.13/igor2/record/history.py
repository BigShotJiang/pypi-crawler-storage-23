from .base import TextRecord


class HistoryRecord (TextRecord):
    pass


class RecreationRecord (TextRecord):
    pass


class GetHistoryRecord (TextRecord):
    pass
