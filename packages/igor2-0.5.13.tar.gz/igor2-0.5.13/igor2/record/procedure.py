from .base import TextRecord


class ProcedureRecord (TextRecord):
    pass
