from .base import Record


class PackedFileRecord (Record):
    pass
