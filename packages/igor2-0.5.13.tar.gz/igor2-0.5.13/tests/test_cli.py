"""Test the CLI entry points."""
# from igor2.cli.igorbinarywave import WaveScript
# from igor2.cli.igorpackedexperiment import PackedScript


def test_wavescript(capsys):
    """Test the WaveScript class entry point."""


def test_packetscript(capsys):
    """Test the PackedScript class entry point."""
