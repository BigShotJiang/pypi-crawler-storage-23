#! /usr/bin/env bash

function test_bluer_ai_web_diagnose() {
    local options=$1

    bluer_ai web diagnose
}
