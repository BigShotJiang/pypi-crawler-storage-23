# Deprecated

This file has been replaced by the CLImax skill at [`skill/SKILL.md`](skill/SKILL.md).

The skill provides comprehensive instructions for LLMs to generate CLImax YAML configs, including schema reference, naming rules, argument mapping patterns, and a validation checklist.
