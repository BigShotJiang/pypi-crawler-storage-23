# DiscoverAgentsJobSpec


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**job_type** | **str** |  | [optional] [default to 'discover_agents']
**workspace_id** | **str** | The ID of the workspace to discover agents for. | 
**data_plane_id** | **str** | The ID of the data plane to scan for agents. | 
**project_id** | **str** |  | [optional] 
**lookback_hours** | **int** | Number of hours to look back in trace history (default: 720 hours &#x3D; 30 days). | [optional] [default to 720]

## Example

```python
from arthur_client.api_bindings.models.discover_agents_job_spec import DiscoverAgentsJobSpec

# TODO update the JSON string below
json = "{}"
# create an instance of DiscoverAgentsJobSpec from a JSON string
discover_agents_job_spec_instance = DiscoverAgentsJobSpec.from_json(json)
# print the JSON string representation of the object
print(DiscoverAgentsJobSpec.to_json())

# convert the object into a dict
discover_agents_job_spec_dict = discover_agents_job_spec_instance.to_dict()
# create an instance of DiscoverAgentsJobSpec from a dict
discover_agents_job_spec_from_dict = DiscoverAgentsJobSpec.from_dict(discover_agents_job_spec_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


