# AgentCreationSource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] [default to 'GCP']
**gcp_project_id** | **str** | GCP project ID | 
**gcp_region** | **str** | GCP region | 
**gcp_reasoning_engine_id** | **str** | GCP Vertex AI Reasoning Engine ID | 
**service_names** | **List[str]** | Service names associated with this agent | [optional] 

## Example

```python
from arthur_client.api_bindings.models.agent_creation_source import AgentCreationSource

# TODO update the JSON string below
json = "{}"
# create an instance of AgentCreationSource from a JSON string
agent_creation_source_instance = AgentCreationSource.from_json(json)
# print the JSON string representation of the object
print(AgentCreationSource.to_json())

# convert the object into a dict
agent_creation_source_dict = agent_creation_source_instance.to_dict()
# create an instance of AgentCreationSource from a dict
agent_creation_source_from_dict = AgentCreationSource.from_dict(agent_creation_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


