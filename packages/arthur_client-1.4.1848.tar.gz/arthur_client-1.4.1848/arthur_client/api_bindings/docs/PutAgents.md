# PutAgents

Request body for creating or updating agents.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agents** | [**List[Agent]**](Agent.md) | List of agents to create or update. | 

## Example

```python
from arthur_client.api_bindings.models.put_agents import PutAgents

# TODO update the JSON string below
json = "{}"
# create an instance of PutAgents from a JSON string
put_agents_instance = PutAgents.from_json(json)
# print the JSON string representation of the object
print(PutAgents.to_json())

# convert the object into a dict
put_agents_dict = put_agents_instance.to_dict()
# create an instance of PutAgents from a dict
put_agents_from_dict = PutAgents.from_dict(put_agents_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


