# 🎙️ mohini-voice-emotion

> **Voice emotion analysis engine for Darshan's AI assistant, Mohini.**  
> Detects emotional state from voice audio so Mohini can calibrate her responses perfectly.

---

## What It Does

Mohini receives voice notes from Darshan. Before she responds, she analyzes the audio to detect his emotional state — then adjusts her tone, verbosity, and approach accordingly.

**Example:** Darshan sends a stressed voice note at 2 AM about a broken deployment.  
Mohini detects `ANGRY` → skips pleasantries → delivers a concrete fix immediately. No excuses.

---

## Emotion Taxonomy

| Emotion     | Acoustic Signature                                | Mohini's Response Mode                                                 |
|-------------|---------------------------------------------------|------------------------------------------------------------------------|
| 🚨 ANGRY    | High F0, high pitch variance, loud, fast ZCR       | Immediate action. Brief ack → concrete fix → no excuses. Zero fluff.  |
| ⚠️ STRESSED | Elevated F0 variance, faster rate, raised energy  | Efficient, solution-first. Skip pleasantries. Deliver results.        |
| 💬 NEUTRAL  | Mid-range F0 + energy, low variance               | Normal helpful conversation. Competent, clear.                        |
| 😊 HAPPY    | Melodic F0 variance, warm energy, rising intonation | Warm, collaborative, slightly more expressive.                      |
| 🪷 CALM     | Low pitch std, consistent low energy, slow ZCR    | Detailed work mode — longer responses, thorough explanations welcome. |

---

## Acoustic Features Extracted

| Feature              | Description                                                |
|----------------------|------------------------------------------------------------|
| `pitch_mean`         | Mean fundamental frequency (F0) in Hz — voice height       |
| `pitch_std`          | F0 standard deviation — melodic/erratic variance           |
| `pitch_range`        | Peak-to-peak F0 range — expressiveness breadth             |
| `pitch_slope`        | Intonation trend over time (rising vs. falling)            |
| `energy_mean`        | Mean RMS amplitude — overall loudness                      |
| `energy_max`         | Peak RMS — presence of shouting / emphasis                 |
| `speech_rate`        | Zero-crossing rate proxy — speaking pace indicator         |
| `mfcc_mean/std`      | Mel-frequency cepstral coefficients — timbre/voice quality |
| `spectral_centroid`  | "Brightness" of the voice — harsh vs. warm                 |
| `spectral_rolloff`   | Frequency below which 85% of energy lies                   |
| `spectral_contrast`  | Harmonic-to-noise ratio proxy                              |
| `tempo`              | Estimated speech tempo in BPM                              |
| `voiced_ratio`       | Fraction of frames with detected voicing                   |

**Scientific basis:** Murray & Arnott (1993), Schuller et al. (2011), Zeng et al. (2009)

---

## Installation

```bash
pip install librosa scipy
```

**Clone:**
```bash
git clone https://github.com/darshjme-codes/mohini-voice-emotion.git
cd mohini-voice-emotion
```

**Optional (for running tests):**
```bash
pip install pytest soundfile
```

---

## Usage

### Python API

```python
from src.emotion_analyzer import analyze_audio

result = analyze_audio("darshan_voice_note.ogg")
print(result["emotion"])          # "angry" | "stressed" | "neutral" | "happy" | "calm"
print(result["confidence"])       # 0.0 – 1.0
print(result["mohini_guidance"])  # What Mohini should do
```

### Full Object API

```python
from src.emotion_analyzer import VoiceEmotionAnalyzer

analyzer = VoiceEmotionAnalyzer()
result = analyzer.analyze("voice.wav")

print(result.emotion.value)      # "stressed"
print(result.confidence)         # 0.72
print(result.mohini_guidance)    # "⚠️ Darshan sounds stressed..."
print(result.features)           # full acoustic feature dict
print(result.scores)             # per-emotion classification scores
```

### CLI

```bash
python src/emotion_analyzer.py path/to/audio.ogg
```

Output:
```json
{
  "emotion": "angry",
  "confidence": 0.84,
  "mohini_guidance": "🚨 DARSHAN IS ANGRY. Respond immediately with: 1) Brief acknowledgment  2) Concrete fix  3) No excuses. Do NOT be verbose. Fix the problem NOW.",
  "features": {
    "pitch_mean": 198.3,
    "pitch_std": 37.2,
    "energy_mean": 0.14,
    ...
  },
  "scores": {
    "angry": 8.5,
    "stressed": 1.5,
    "neutral": 0.0,
    "happy": 0.0,
    "calm": 0.0
  }
}
```

### Mohini Integration (Quick Check)

```bash
python /root/.openclaw/workspace/voice_emotion_check.py /path/to/voice_note.ogg
```

---

## How Mohini Uses This

1. **Voice note arrives** → WhatsApp audio saved as `.ogg`
2. **`voice_emotion_check.py`** runs → JSON result in < 2 seconds
3. **Mohini reads `mohini_guidance`** → calibrates response tone before generating reply
4. **Response delivered** — perfectly tuned to Darshan's current emotional state

### Response Calibration Matrix

```
ANGRY    → Ultra-brief. Action-first. No padding. Fix NOW.
STRESSED → Efficient. Cut to solution. Minimal preamble.
NEUTRAL  → Standard helpfulness. Clear and complete.
HAPPY    → Warmer. Slightly more conversational.
CALM     → Can go deep. Detailed analysis welcome.
```

---

## Project Structure

```
mohini-voice-emotion/
├── src/
│   ├── __init__.py
│   └── emotion_analyzer.py      # Core library
├── tests/
│   └── test_emotion_analyzer.py # 15+ tests
├── README.md
├── requirements.txt
└── setup.py
```

---

## Running Tests

```bash
pytest tests/ -v
```

Expected: **15+ tests, all passing.**

---

## Extending

The classifier uses a transparent rule-based scoring system (`_classify` method).  
To improve accuracy with Darshan-specific data:

1. Collect labeled voice samples (5–10 per emotion)
2. Print `result.features` for each
3. Tune thresholds in `_classify` to match Darshan's vocal profile
4. Consider training a lightweight ML model (SVM or RandomForest) on the feature vectors

---

## Author

Built for **Darshan Joshi** by **Mohini** — his AI assistant.  
Emotion intelligence for a more responsive AI.

---

*"She doesn't just hear what you say. She hears how you feel."*
