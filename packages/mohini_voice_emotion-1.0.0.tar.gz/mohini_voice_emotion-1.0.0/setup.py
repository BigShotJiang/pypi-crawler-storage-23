from setuptools import setup, find_packages

setup(
    name="mohini-voice-emotion",
    version="1.0.0",
    description="Voice emotion analysis engine — detect emotional state from audio for AI response calibration",
    author="Darshan Joshi",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    install_requires=[
        "librosa>=0.10.0",
        "scipy>=1.10.0",
        "numpy>=1.24.0",
    ],
    python_requires=">=3.10",
    entry_points={
        "console_scripts": [
            "mohini-emotion=emotion_analyzer:analyze_audio",
        ],
    },
)
