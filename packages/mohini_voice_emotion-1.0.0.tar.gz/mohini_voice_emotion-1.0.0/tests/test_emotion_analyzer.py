#!/usr/bin/env python3
"""
Tests for Mohini Voice Emotion Analyzer
========================================
15+ tests covering:
  - Feature extraction on synthetic audio
  - Classification logic with mocked features
  - Edge cases: silence, very short clips, high energy
  - Public API contract
"""

import sys
import json
import math
import tempfile
import os
import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from emotion_analyzer import (
    Emotion,
    EmotionResult,
    VoiceEmotionAnalyzer,
    analyze_audio,
)

# ── Fixtures ───────────────────────────────────────────────────────────────────

SR = 22050  # Default sample rate


def make_tone(freq: float = 220.0, duration: float = 1.0, amplitude: float = 0.5) -> np.ndarray:
    """Generate a pure sinusoidal tone."""
    t = np.linspace(0, duration, int(SR * duration), endpoint=False)
    return (amplitude * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def make_silence(duration: float = 1.0) -> np.ndarray:
    """Generate silence."""
    return np.zeros(int(SR * duration), dtype=np.float32)


def make_noise(duration: float = 1.0, amplitude: float = 0.5) -> np.ndarray:
    """Generate white noise (high energy, high ZCR — anger-proxy)."""
    rng = np.random.default_rng(42)
    return (amplitude * rng.standard_normal(int(SR * duration))).astype(np.float32)


@pytest.fixture
def analyzer():
    return VoiceEmotionAnalyzer()


# ── Test 1: Instantiation ──────────────────────────────────────────────────────

class TestInstantiation:
    def test_default_sample_rate(self, analyzer):
        assert analyzer.sr == 22050

    def test_custom_sample_rate(self):
        a = VoiceEmotionAnalyzer(sample_rate=16000)
        assert a.sr == 16000


# ── Test 2: Feature Extraction ─────────────────────────────────────────────────

class TestFeatureExtraction:
    def test_feature_keys_present(self, analyzer):
        """All expected feature keys must be returned."""
        y = make_tone(220.0, 1.0)
        features = analyzer._extract_features(y, SR)
        expected_keys = {
            "pitch_mean", "pitch_std", "pitch_range", "pitch_slope",
            "energy_mean", "energy_std", "energy_max", "speech_rate",
            "mfcc_mean", "mfcc_std", "spectral_centroid", "spectral_rolloff",
            "spectral_contrast", "tempo", "duration", "voiced_ratio",
        }
        assert set(features.keys()) == expected_keys

    def test_feature_values_are_floats(self, analyzer):
        """Every feature must be a Python float."""
        y = make_tone(220.0, 1.0)
        features = analyzer._extract_features(y, SR)
        for k, v in features.items():
            assert isinstance(v, float), f"{k} is not float: {type(v)}"

    def test_duration_correct(self, analyzer):
        """Duration feature must match the audio length."""
        duration = 2.0
        y = make_tone(duration=duration)
        features = analyzer._extract_features(y, SR)
        assert abs(features["duration"] - duration) < 0.02

    def test_silence_energy_near_zero(self, analyzer):
        """Silent audio should have near-zero RMS energy."""
        y = make_silence(1.0)
        features = analyzer._extract_features(y, SR)
        assert features["energy_mean"] < 1e-4
        assert features["energy_max"] < 1e-4

    def test_high_amplitude_has_high_energy(self, analyzer):
        """Louder audio must yield higher energy than quiet audio."""
        loud = make_tone(220.0, 1.0, amplitude=0.9)
        quiet = make_tone(220.0, 1.0, amplitude=0.05)
        f_loud  = analyzer._extract_features(loud,  SR)
        f_quiet = analyzer._extract_features(quiet, SR)
        assert f_loud["energy_mean"] > f_quiet["energy_mean"]

    def test_noise_has_high_zcr(self, analyzer):
        """White noise should produce a higher ZCR than a pure tone."""
        tone  = make_tone(220.0, 1.0)
        noise = make_noise(1.0, 0.3)
        f_tone  = analyzer._extract_features(tone,  SR)
        f_noise = analyzer._extract_features(noise, SR)
        assert f_noise["speech_rate"] > f_tone["speech_rate"]

    def test_voiced_ratio_in_range(self, analyzer):
        """Voiced ratio must be between 0 and 1."""
        y = make_tone(220.0, 1.0)
        features = analyzer._extract_features(y, SR)
        assert 0.0 <= features["voiced_ratio"] <= 1.0

    def test_silence_pitched_features_are_zero(self, analyzer):
        """Silent audio — no voiced frames → pitch features should be 0."""
        y = make_silence(1.0)
        features = analyzer._extract_features(y, SR)
        assert features["pitch_mean"] == 0.0
        assert features["pitch_std"] == 0.0


# ── Test 3: Classification Logic ───────────────────────────────────────────────

class TestClassification:
    """Drive classification with hand-crafted feature dicts."""

    def _classify(self, analyzer, **overrides):
        base = {
            "pitch_mean": 120.0, "pitch_std": 10.0, "pitch_range": 30.0,
            "pitch_slope": 0.0,  "energy_mean": 0.04, "energy_std": 0.01,
            "energy_max": 0.1,   "speech_rate": 0.04, "mfcc_mean": -200.0,
            "mfcc_std": 20.0,    "spectral_centroid": 800.0,
            "spectral_rolloff": 2000.0, "spectral_contrast": 20.0,
            "tempo": 100.0,      "duration": 3.0, "voiced_ratio": 0.7,
        }
        base.update(overrides)
        emotion, confidence, scores = analyzer._classify(base)
        return emotion, confidence, scores

    def test_angry_high_pitch_high_energy(self, analyzer):
        emotion, _, _ = self._classify(
            analyzer, pitch_mean=200.0, pitch_std=35.0,
            energy_mean=0.15, energy_max=0.45, speech_rate=0.10,
        )
        assert emotion == Emotion.ANGRY

    def test_stressed_moderate_high_pitch_std(self, analyzer):
        emotion, _, _ = self._classify(
            analyzer, pitch_mean=170.0, pitch_std=25.0, energy_mean=0.08,
        )
        assert emotion == Emotion.STRESSED

    def test_happy_melodic_mid_pitch(self, analyzer):
        emotion, _, _ = self._classify(
            analyzer, pitch_mean=145.0, pitch_std=20.0, energy_mean=0.055,
        )
        assert emotion == Emotion.HAPPY

    def test_calm_low_std_low_energy(self, analyzer):
        emotion, _, _ = self._classify(
            analyzer, pitch_mean=110.0, pitch_std=8.0,
            energy_mean=0.03, speech_rate=0.03,
        )
        assert emotion == Emotion.CALM

    def test_neutral_mid_range_everything(self, analyzer):
        emotion, _, _ = self._classify(
            analyzer, pitch_mean=130.0, pitch_std=12.0, energy_mean=0.05,
        )
        assert emotion == Emotion.NEUTRAL

    def test_confidence_in_valid_range(self, analyzer):
        """Confidence must always be in [0.3, 0.95]."""
        _, confidence, _ = self._classify(
            analyzer, pitch_mean=200.0, pitch_std=40.0, energy_mean=0.2,
        )
        assert 0.3 <= confidence <= 0.95

    def test_scores_dict_has_all_emotions(self, analyzer):
        """Raw scores dict must include all 5 emotions."""
        _, _, scores = self._classify(analyzer)
        for e in Emotion:
            assert e in scores


# ── Test 4: Mohini Guidance ────────────────────────────────────────────────────

class TestMohiniGuidance:
    def test_angry_guidance_has_critical_alert(self, analyzer):
        guidance = analyzer._get_mohini_guidance(Emotion.ANGRY)
        assert "ANGRY" in guidance or "🚨" in guidance

    def test_stressed_guidance_efficiency_keywords(self, analyzer):
        guidance = analyzer._get_mohini_guidance(Emotion.STRESSED)
        assert "stressed" in guidance.lower() or "⚠️" in guidance

    def test_all_emotions_have_guidance(self, analyzer):
        """Every emotion must have a non-empty guidance string."""
        for emotion in Emotion:
            guidance = analyzer._get_mohini_guidance(emotion)
            assert isinstance(guidance, str) and len(guidance) > 10


# ── Test 5: analyze_array API ──────────────────────────────────────────────────

class TestAnalyzeArray:
    def test_returns_emotion_result(self, analyzer):
        y = make_tone(220.0, 1.0)
        result = analyzer.analyze_array(y, SR)
        assert isinstance(result, EmotionResult)

    def test_result_emotion_is_enum(self, analyzer):
        y = make_tone(220.0, 1.0)
        result = analyzer.analyze_array(y, SR)
        assert isinstance(result.emotion, Emotion)

    def test_result_has_all_fields(self, analyzer):
        y = make_tone(220.0, 1.0)
        result = analyzer.analyze_array(y, SR)
        assert result.emotion is not None
        assert isinstance(result.confidence, float)
        assert isinstance(result.features, dict)
        assert isinstance(result.mohini_guidance, str)
        assert isinstance(result.scores, dict)


# ── Test 6: analyze_audio (file-based) ─────────────────────────────────────────

class TestAnalyzeAudioFile:
    def test_analyze_audio_returns_dict(self):
        """analyze_audio must return a JSON-serialisable dict."""
        import soundfile as sf
        y = make_tone(220.0, 2.0)
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            path = f.name
        try:
            sf.write(path, y, SR)
            result = analyze_audio(path)
            assert isinstance(result, dict)
            assert "emotion" in result
            assert "confidence" in result
            assert "mohini_guidance" in result
            assert "features" in result
        finally:
            os.unlink(path)

    def test_analyze_audio_emotion_is_valid_string(self):
        import soundfile as sf
        y = make_tone(440.0, 1.0)
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            path = f.name
        try:
            sf.write(path, y, SR)
            result = analyze_audio(path)
            valid_emotions = {e.value for e in Emotion}
            assert result["emotion"] in valid_emotions
        finally:
            os.unlink(path)

    def test_analyze_audio_json_serialisable(self):
        import soundfile as sf
        y = make_tone(300.0, 1.5)
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            path = f.name
        try:
            sf.write(path, y, SR)
            result = analyze_audio(path)
            # Must not raise
            json_str = json.dumps(result)
            assert len(json_str) > 0
        finally:
            os.unlink(path)


# ── Test 7: Edge Cases ─────────────────────────────────────────────────────────

class TestEdgeCases:
    def test_very_short_clip(self, analyzer):
        """0.1-second clip must not crash."""
        y = make_tone(220.0, 0.1)
        result = analyzer.analyze_array(y, SR)
        assert isinstance(result.emotion, Emotion)

    def test_silence_does_not_crash(self, analyzer):
        """Pure silence must return a valid emotion (likely calm)."""
        y = make_silence(1.0)
        result = analyzer.analyze_array(y, SR)
        assert isinstance(result.emotion, Emotion)

    def test_high_energy_loud_noise(self, analyzer):
        """Clipping-level amplitude noise should survive analysis."""
        y = make_noise(1.0, amplitude=0.99)
        result = analyzer.analyze_array(y, SR)
        assert result.confidence >= 0.3

    def test_zero_scores_fallback_confidence(self, analyzer):
        """If all scores are zero, confidence must still be 0.5 (fallback)."""
        # Manufacture a feature set that scores 0 for everything
        features = {
            "pitch_mean": 0.0, "pitch_std": 0.0, "pitch_range": 0.0,
            "pitch_slope": 0.0, "energy_mean": 0.0, "energy_std": 0.0,
            "energy_max": 0.0, "speech_rate": 0.0, "mfcc_mean": 0.0,
            "mfcc_std": 0.0, "spectral_centroid": 0.0, "spectral_rolloff": 0.0,
            "spectral_contrast": 0.0, "tempo": 0.0, "duration": 1.0,
            "voiced_ratio": 0.0,
        }
        _, confidence, _ = analyzer._classify(features)
        # With p_std < 15 → CALM gets 2 pts and energy < 0.05 → +1.5, zcr < 0.05 → +1
        # So total won't be 0; but confidence must be in range regardless
        assert 0.3 <= confidence <= 0.95
