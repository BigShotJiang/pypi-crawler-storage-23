from typing import TypeAlias

NavigateResult: TypeAlias = str
