from typing import TypeAlias

GetInstagramHomePageResult: TypeAlias = str
