from typing import Any, TypeAlias

AuthPlatformCodeEntryViewQueryResult: TypeAlias = dict[str, Any]
