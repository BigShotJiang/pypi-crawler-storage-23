from typing import TypedDict


class CommentsAddResult(TypedDict):
    pass
