from typing import Any, TypeAlias

FriendshipsFollowResult: TypeAlias = dict[str, Any]
