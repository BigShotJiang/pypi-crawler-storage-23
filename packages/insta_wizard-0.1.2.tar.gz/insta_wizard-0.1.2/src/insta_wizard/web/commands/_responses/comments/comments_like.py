from typing import TypedDict


class CommentsLikeResult(TypedDict):
    pass
