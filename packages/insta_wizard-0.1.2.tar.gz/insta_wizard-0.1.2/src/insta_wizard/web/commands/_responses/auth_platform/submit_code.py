from typing import Any, TypeAlias

UseAuthPlatformSubmitCodeMutationResult: TypeAlias = dict[str, Any]
