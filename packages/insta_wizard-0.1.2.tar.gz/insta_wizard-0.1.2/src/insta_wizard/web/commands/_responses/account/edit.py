from typing import TypedDict


class AccountsEditResult(TypedDict):
    pass
