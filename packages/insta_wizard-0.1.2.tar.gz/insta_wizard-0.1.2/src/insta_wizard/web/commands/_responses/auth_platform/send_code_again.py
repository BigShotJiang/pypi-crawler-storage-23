from typing import Any, TypeAlias

UseAuthPlatformSendCodeAgainMutationResult: TypeAlias = dict[str, Any]
