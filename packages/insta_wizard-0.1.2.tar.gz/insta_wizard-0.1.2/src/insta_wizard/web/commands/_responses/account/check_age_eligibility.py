from typing import Any, TypeAlias

CheckAgeEligibilityResult: TypeAlias = dict[str, Any]
