from typing import TypedDict


class FriendshipsDestroyResult(TypedDict):
    pass
