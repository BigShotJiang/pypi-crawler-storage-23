from typing import Any, TypeAlias

AccountsEditWebFormDataResult: TypeAlias = dict[str, Any]
