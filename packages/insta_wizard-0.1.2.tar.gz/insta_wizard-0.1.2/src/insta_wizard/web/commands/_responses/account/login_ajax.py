from typing import Any, TypeAlias

AccountsLoginAjaxResult: TypeAlias = dict[str, Any]
