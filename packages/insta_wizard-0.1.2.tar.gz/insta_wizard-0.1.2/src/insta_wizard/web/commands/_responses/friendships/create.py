from typing import Any, TypeAlias

FriendshipsCreateResult: TypeAlias = dict[str, Any]
