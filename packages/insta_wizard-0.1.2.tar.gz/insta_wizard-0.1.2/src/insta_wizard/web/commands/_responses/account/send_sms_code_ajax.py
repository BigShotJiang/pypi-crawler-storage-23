from typing import Any, TypeAlias

SendSignupSmsCodeAjaxResult: TypeAlias = dict[str, Any]
