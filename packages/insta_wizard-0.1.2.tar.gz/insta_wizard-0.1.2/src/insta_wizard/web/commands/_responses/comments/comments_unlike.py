from typing import TypedDict


class CommentsUnlikeResult(TypedDict):
    pass
