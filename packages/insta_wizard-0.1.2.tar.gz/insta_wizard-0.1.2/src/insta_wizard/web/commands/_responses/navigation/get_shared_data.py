from typing import Any, TypeAlias

GetSharedDataResult: TypeAlias = dict[str, Any]
