from typing import TypedDict


class LikesUnlikeResult(TypedDict):
    pass
