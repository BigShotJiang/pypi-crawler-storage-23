from typing import TypedDict


class LikesLikeResult(TypedDict):
    pass
