from typing import Any, TypeAlias

WebCreateAjaxResult: TypeAlias = dict[str, Any]
