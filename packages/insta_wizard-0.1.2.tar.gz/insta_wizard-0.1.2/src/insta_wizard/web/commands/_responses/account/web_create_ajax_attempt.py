from typing import Any, TypeAlias

WebCreateAjaxAttemptResult: TypeAlias = dict[str, Any]
