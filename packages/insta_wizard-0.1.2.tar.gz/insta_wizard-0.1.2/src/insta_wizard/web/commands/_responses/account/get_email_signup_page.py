from typing import TypeAlias

GetEmailSignupPageResult: TypeAlias = str
