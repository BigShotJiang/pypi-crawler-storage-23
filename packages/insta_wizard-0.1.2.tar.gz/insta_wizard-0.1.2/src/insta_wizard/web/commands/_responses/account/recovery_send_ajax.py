from typing import Any, TypeAlias

AccountRecoverySendAjaxResult: TypeAlias = dict[str, Any]
