from typing import Any, TypeAlias

PolarisSearchBoxRefetchableQueryResult: TypeAlias = dict[str, Any]
