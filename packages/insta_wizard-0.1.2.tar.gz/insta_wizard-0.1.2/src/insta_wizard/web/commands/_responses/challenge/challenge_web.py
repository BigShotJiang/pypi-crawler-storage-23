from typing import Any, TypeAlias

ChallengeWebResult: TypeAlias = dict[str, Any]
