from typing import TypeAlias

GetWebMidResult: TypeAlias = str
