from typing import TypedDict


class DirectV2GetPendingRequestsPreviewResponse(TypedDict):
    pass
