from typing import TypedDict


class AttestationCreateAndroidKeystoreBApiResponse(TypedDict):
    pass
