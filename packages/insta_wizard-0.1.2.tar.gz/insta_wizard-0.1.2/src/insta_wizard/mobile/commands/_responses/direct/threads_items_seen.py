from typing import TypedDict


class DirectV2ThreadsItemsSeenResponse(TypedDict):
    pass
