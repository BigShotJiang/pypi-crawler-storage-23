from typing import TypedDict


class UserAccountDetailsResponse(TypedDict):
    pass
