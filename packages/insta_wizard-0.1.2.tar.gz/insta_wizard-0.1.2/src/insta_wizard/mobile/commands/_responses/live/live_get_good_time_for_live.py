from typing import TypedDict


class LiveGetGoodTimeForLiveResponse(TypedDict):
    pass
