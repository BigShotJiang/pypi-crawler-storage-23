from typing import TypedDict


class DirectV2CreateGroupThreadResponse(TypedDict):
    pass
