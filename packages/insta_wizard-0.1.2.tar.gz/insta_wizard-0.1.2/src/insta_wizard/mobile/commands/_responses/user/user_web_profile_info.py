from typing import TypedDict


class UserWebProfileInfoResponse(TypedDict):
    pass
