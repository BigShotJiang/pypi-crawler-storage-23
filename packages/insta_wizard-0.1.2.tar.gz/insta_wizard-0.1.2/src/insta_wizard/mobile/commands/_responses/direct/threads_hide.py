from typing import TypedDict


class DirectV2ThreadsHideResponse(TypedDict):
    pass
