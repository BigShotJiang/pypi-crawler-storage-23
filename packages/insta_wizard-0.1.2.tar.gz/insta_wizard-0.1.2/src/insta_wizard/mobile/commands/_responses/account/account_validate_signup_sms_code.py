from typing import TypedDict


class AccountValidateSignupSmsCodeResponse(TypedDict):
    pass
