from typing import TypedDict


class DirectV2GetPresenceResponse(TypedDict):
    pass
