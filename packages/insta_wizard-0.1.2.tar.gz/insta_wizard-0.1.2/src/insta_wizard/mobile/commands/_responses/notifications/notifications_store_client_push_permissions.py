from typing import TypedDict


class NotificationsStoreClientPushPermissionsResponse(TypedDict):
    pass
