from typing import TypedDict


class ChallengeGetChallengeInfoResponse(TypedDict):
    pass
