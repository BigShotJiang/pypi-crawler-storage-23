from typing import TypedDict


class AttestationCreateAndroidPlayIntegrityResponse(TypedDict):
    pass
