from typing import TypedDict


class ZrDualTokensResponse(TypedDict):
    pass
