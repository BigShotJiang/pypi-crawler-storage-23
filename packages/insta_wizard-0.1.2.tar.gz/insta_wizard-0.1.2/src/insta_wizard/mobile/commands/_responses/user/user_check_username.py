from typing import TypedDict


class UsersCheckUsernameResponse(TypedDict):
    pass
