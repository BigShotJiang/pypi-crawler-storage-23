from typing import TypedDict


class NewsInboxResponse(TypedDict):
    pass
