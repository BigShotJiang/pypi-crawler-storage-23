from typing import TypedDict


class AccountGetPresenceDisabledResponse(TypedDict):
    pass
