from typing import TypedDict


class MultipleAcountsGetAccountFamilyResponse(TypedDict):
    pass
