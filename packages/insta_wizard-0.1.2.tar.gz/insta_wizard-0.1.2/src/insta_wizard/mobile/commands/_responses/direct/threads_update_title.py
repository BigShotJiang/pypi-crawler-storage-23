from typing import TypedDict


class DirectV2ThreadsUpdateTitleResponse(TypedDict):
    pass
