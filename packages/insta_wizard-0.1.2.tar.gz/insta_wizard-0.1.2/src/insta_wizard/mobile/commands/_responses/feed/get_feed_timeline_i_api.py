from typing import TypedDict


class FeedGetFeedTimelineIApiResponse(TypedDict):
    pass
