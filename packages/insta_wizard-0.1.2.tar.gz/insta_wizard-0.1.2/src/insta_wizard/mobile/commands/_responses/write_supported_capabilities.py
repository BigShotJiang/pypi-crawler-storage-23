from typing import TypedDict


class CreativesWriteSupportedCapabilitiesResponse(TypedDict):
    pass
