from typing import TypedDict


class AccountUpdateProfileNameResponse(TypedDict):
    pass
