from typing import TypedDict, Any


class DirectV2ThreadsDeleteItemsLocallyResponse(TypedDict):
    status: str
    status_code: str
