from typing import TypedDict


class ConsentGetSignupConfigResponse(TypedDict):
    pass
