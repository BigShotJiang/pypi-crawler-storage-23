from typing import TypedDict


class LoomFetchConfigResponse(TypedDict):
    pass
