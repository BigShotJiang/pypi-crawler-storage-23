from typing import TypedDict


class UserGetLimitedInteractionsReminderResponse(TypedDict):
    pass
