from typing import TypedDict


class AccountEditProfileResponse(TypedDict):
    pass
