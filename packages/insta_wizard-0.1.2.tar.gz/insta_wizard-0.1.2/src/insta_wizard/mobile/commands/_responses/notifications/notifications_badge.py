from typing import TypedDict


class NotificationsBadgeResponse(TypedDict):
    pass
