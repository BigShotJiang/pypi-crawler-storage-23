from typing import TypedDict


class LauncherMobileConfigBApiResponse(TypedDict):
    pass
