from typing import TypedDict


class AndroidModulesDownloadBApiResponse(TypedDict):
    pass
