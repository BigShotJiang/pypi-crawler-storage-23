from typing import TypedDict


class DirectV2AsyncGetPendingRequestsPreviewResponse(TypedDict):
    pass
