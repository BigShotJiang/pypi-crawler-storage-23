from typing import TypedDict


class AccountCreateValidatedResponse(TypedDict):
    pass
