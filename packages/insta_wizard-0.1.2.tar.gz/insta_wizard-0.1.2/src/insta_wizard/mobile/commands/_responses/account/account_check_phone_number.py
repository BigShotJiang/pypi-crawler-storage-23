from typing import TypedDict


class AccountCheckPhoneNumberResponse(TypedDict):
    pass
