from typing import TypedDict


class AccountLoginResponse(TypedDict):
    pass
