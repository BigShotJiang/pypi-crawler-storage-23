from typing import TypedDict


class AccountSetBiographyResponse(TypedDict):
    pass
