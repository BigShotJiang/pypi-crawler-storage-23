from typing import TypedDict


class DirectV2ThreadsDeclineResponse(TypedDict):
    pass
