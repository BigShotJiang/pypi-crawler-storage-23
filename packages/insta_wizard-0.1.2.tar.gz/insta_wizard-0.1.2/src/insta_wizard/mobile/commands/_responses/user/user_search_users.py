from typing import TypedDict


class UserSearchUsersResponse(TypedDict):
    pass
