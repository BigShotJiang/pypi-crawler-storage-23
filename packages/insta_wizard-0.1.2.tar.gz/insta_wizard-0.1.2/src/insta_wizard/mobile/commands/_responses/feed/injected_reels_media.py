from typing import TypedDict


class FeedInjectedReelsMediaResponse(TypedDict):
    pass
