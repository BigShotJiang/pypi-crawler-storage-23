from typing import TypedDict


class DirectV2ThreadsApproveResponse(TypedDict):
    pass
