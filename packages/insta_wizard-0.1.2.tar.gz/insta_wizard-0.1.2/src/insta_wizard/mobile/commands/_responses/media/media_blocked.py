from typing import TypedDict


class MediaBlockedResponse(TypedDict):
    pass
