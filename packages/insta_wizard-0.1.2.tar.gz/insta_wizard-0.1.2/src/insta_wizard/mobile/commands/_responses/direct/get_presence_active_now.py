from typing import TypedDict


class DirectV2GetPresenceActiveNowResponse(TypedDict):
    pass
