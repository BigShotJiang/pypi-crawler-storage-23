from typing import TypedDict


class DirectV2ThreadsDeclineMultipleResponse(TypedDict):
    pass
