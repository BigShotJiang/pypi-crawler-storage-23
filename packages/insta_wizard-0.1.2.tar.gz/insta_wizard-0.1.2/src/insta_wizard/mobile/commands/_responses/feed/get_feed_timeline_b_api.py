from typing import TypedDict


class FeedGetFeedTimelineBApiResponse(TypedDict):
    pass
