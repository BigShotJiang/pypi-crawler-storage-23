from typing import TypedDict


class LauncherMobileConfigResponse(TypedDict):
    pass
