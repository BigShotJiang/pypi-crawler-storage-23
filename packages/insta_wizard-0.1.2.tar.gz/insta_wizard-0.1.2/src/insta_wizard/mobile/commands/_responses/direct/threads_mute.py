from typing import TypedDict


class DirectV2ThreadsMuteResponse(TypedDict):
    pass
