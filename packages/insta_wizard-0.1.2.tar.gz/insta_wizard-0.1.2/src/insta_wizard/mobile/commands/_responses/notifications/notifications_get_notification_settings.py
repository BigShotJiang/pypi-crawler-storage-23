from typing import TypedDict


class NotificationsGetNotificationSettingsResponse(TypedDict):
    pass
