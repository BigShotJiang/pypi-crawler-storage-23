from typing import TypedDict


class BloksYouthRegulationDeletePregentResponse(TypedDict):
    pass
