from typing import TypedDict


class ClipsUserShareToFbConfigResponse(TypedDict):
    pass
