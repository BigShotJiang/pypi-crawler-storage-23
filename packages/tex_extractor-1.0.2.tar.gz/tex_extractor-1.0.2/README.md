# TeX Extractor

A CLI tool to extract specific sections from a TeX document and format them as a new document.

# Installation

Available from PyPi, you can install by running:

```
pip install tex_extractor
```

# Example Use Case

Let's say we have taken notes for a particular subject in a document `measure-theory/measure-theory.tex`. You may want to revise all of the definitions for the course, so you can run

```bash
texextract measure-theory measure-definitions --section definition --title "Measure Theory Definitions"
```

This will output a document `measure-definitions/measure-definitions.tex` which contains only the definitions.

You can specify multiple sections, e.g.

```bash
texextract measure-theory measure-theorems --section theorem --section lemma --section proposition --title "Measure Theory Theorems"
```

# API Reference

```shell
╰─❯ texextract --help

 Usage: texextract [OPTIONS] [INPUT] [OUTPUT]

╭─ Arguments ───────────────────────────────────────────────────────────────────────────────────╮
│   input       [INPUT]   Path to input .tex file or to its parent folder                       │
│   output      [OUTPUT]  Output file path. This can be a path to a .tex file, or a folder      │
│                         name. The output is a folder unless --file-only is passed.            │
╰───────────────────────────────────────────────────────────────────────────────────────────────╯
╭─ Options ─────────────────────────────────────────────────────────────────────────────────────╮
│ --title               -t      TEXT  If given, overrides the title of the input document.      │
│ --author              -a      TEXT  If given, overrides the author of the input document.     │
│ --section             -s      TEXT  Name of the environment to be picked out. Can be given    │
│                                     multiple times.                                           │
│ --file-only           -F            The output .tex file is not wrapped in a folder.          │
│ --strict              -S            Do not tolerate invalid .tex input.                       │
│ --force               -f            Ovewrite an existing .tex file.                           │
│ --install-completion                Install completion for the current shell.                 │
│ --show-completion                   Show completion for the current shell, to copy it or      │
│                                     customize the installation.                               │
│ --help                              Show this message and exit.                               │
╰───────────────────────────────────────────────────────────────────────────────────────────────╯
```
