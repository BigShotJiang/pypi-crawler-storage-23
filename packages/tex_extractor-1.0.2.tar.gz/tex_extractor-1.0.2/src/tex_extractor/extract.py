import typer
from typing_extensions import Annotated

from tex_extractor.extractor import Extractor


def texextract(
    input: Annotated[str, typer.Argument(
        help="Path to input .tex file or to its parent folder")] = "",
    output: Annotated[str, typer.Argument(
        help="Output file path. This can be a path to a .tex file, or a folder name. The output is a folder unless --file-only is passed.")] = "",
    title: Annotated[str, typer.Option(
        "--title", "-t", help="If given, overrides the title of the input document.")] = "",
    author: Annotated[str, typer.Option(
        "--author", "-a", help="If given, overrides the author of the input document.")] = "",
    sections: Annotated[list[str], typer.Option(
        "--section", "-s", help="Name of the environment to be picked out. Can be given multiple times.")] = [],
    file_only: Annotated[bool, typer.Option(
        "--file-only", "-F", help="The output .tex file is not wrapped in a folder.")] = False,
    strict_mode: Annotated[bool, typer.Option(
        "--strict", "-S", help="Do not tolerate invalid .tex input."
    )] = False,
    force: Annotated[bool, typer.Option(
        "--force", "-f", help="Ovewrite an existing .tex file."
    )] = False
):
    extractor = Extractor()
    try:  # CLI error boundary
        extractor.extract(input, output, title, author,
                          sections, file_only, strict_mode, force)
    except Exception as e:
        print(f"Error: {e}")
