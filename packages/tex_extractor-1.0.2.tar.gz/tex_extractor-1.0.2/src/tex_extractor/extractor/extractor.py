from tex_extractor.parser import Parser
from tex_extractor.filter import Filter
from tex_extractor.writer import Writer


class Extractor():
    def __init__(self) -> None:
        self._parser = Parser()
        self._filter = Filter()
        self._writer = Writer()

    def extract(self,
                input: str,
                output: str,
                title: str,
                author: str,
                sections: list[str],
                file_only: bool,
                strict_mode: bool,
                force: bool
                ):
        soup = self._parser.parse(input, strict_mode)
        self._filter.filter(soup, title, author, sections)
        self._writer.write(soup, output, file_only, force)
