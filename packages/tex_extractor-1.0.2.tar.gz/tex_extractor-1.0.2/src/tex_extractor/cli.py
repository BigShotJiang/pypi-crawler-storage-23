import typer

from .extract import texextract


app = typer.Typer()
app.command()(texextract)


if __name__ == "__main__":
    app()
