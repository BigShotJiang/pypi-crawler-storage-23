A new list is created as a slice of another one containing functions.
