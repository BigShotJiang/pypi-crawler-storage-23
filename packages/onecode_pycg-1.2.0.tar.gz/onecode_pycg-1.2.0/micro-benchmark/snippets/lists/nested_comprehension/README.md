A nested comprehension.
