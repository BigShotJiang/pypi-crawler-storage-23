Functions are assigned as elements of a list and then called.
