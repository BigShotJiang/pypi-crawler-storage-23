from ext import key

def func1():
    pass

def func2():
    pass

ls = [func1, func2]

ls[key]()
