Lists containing lists that contain functions.
