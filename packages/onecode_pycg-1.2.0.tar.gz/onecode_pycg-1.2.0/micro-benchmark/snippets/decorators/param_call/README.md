The decorator calls the func assigned to it.
