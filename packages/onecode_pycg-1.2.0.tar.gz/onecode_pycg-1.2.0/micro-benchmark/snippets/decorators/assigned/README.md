We use as a decorator a variable that has been assigned to function(s).
