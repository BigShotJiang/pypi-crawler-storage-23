def dec(f):
    return f

@dec
def func():
    pass

func()
