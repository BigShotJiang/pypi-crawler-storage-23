Assign a function to a variable and then do a direct call to its return.
