Pass a function as a parameter to a direct call to the return value of a
function.
