from to_import import func

func()()
