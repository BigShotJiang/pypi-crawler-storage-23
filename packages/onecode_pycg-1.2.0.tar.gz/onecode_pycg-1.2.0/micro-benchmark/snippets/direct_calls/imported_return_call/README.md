Import a function from another module, call it, and call the function it returns.
