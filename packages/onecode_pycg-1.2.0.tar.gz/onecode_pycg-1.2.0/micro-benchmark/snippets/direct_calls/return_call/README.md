A function `func` is called and returns a function `return_func` which is later called directly in the form func()().
