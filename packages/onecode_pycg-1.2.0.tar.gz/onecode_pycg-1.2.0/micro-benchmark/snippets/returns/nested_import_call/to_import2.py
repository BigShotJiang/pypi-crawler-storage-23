def return_func():
    pass
