from to_import2 import return_func

def func():
    return return_func
