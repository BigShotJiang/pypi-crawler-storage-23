A function that returns an addition.
