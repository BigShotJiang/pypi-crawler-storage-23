from to_import import func

a = func()
a()
