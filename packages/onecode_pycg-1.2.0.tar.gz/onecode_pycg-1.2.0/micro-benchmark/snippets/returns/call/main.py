def return_func():
    pass

def func():
    return return_func

a = func()
a()
