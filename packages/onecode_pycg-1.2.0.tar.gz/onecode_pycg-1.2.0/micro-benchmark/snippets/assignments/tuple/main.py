def func1():
    pass

def func2():
    pass

def func3():
    pass

a, b = func1, func2
a()
b()

c, d, e = func1, func2, func3

c()
d()
e()
