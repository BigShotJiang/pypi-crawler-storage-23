Define function with defaults being other functions.
Then call these functions, passing different functions
as keyword arguments.
