Call a function with keyword arguments.
