Give as a kwarg a variable previously assigned to a function.
