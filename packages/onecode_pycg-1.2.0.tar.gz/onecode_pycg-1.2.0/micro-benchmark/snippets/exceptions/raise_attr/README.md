An attribute exception is raised.
