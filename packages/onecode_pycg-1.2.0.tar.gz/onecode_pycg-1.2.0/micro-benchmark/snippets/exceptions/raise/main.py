class A(Exception):
    def __init__(self):
        pass

raise A
