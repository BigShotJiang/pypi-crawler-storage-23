An assigned exception is raised.
