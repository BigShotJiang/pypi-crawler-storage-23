from nested.to_import import func1

func1()
