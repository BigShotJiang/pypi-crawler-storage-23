from .relative import func2

def func1():
    func2()
