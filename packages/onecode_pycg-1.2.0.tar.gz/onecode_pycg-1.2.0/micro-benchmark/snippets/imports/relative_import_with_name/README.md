Same as `relative_import` but the import is of the form `from .to_import2 import func2`
