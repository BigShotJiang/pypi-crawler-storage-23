The `main` module imports `func` from `from_module` which defines a function. This function is then called by `main`
