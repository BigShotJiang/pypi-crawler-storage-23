from from_module import func

func()
