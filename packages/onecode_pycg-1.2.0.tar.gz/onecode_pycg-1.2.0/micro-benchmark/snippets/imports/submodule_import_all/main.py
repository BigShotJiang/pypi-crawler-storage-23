from from_module.nested_module import *

func1()
func2()
