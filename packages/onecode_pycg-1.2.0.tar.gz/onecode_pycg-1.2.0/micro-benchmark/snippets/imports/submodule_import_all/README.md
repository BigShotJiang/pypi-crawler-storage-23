Same concept as `import_all` but with a submodule
