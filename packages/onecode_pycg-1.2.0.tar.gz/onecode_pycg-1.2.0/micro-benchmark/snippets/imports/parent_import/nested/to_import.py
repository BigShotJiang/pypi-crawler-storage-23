import to_import2

def func():
    pass
