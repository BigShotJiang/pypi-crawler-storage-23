The `main` module imports `nested.to_import` module and this module in turn imports `to_import2` via the command `from .. import to_import2`
