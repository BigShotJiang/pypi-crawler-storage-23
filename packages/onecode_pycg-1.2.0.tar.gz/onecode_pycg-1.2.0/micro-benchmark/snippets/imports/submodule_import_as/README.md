Same concept as with `import_as` but with a submodule
