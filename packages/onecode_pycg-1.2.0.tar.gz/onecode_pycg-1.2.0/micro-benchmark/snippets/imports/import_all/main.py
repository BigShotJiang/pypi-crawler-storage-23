from from_module import *

func1()
func2()
