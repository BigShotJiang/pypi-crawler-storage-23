def func1():
    pass

def func2():
    pass
