Structure: The `main` module imports all functions of `from_module`, in this case `func1` and `func2`. These functions are called by `main`.
