from chained_import import func1

def func2():
    func1()
