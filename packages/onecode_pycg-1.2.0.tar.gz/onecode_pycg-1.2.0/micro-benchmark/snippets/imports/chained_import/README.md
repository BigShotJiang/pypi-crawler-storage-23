Structure: The `main` module imports `to_import` module which imports the `chained_import` module, which defines a function `func1`.
`to_import` defines a function `func2` that calls `func1` and then `main` calls `func2`.
