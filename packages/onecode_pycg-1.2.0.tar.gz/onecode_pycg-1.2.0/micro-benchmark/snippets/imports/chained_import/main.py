from from_import import func2

func2()
