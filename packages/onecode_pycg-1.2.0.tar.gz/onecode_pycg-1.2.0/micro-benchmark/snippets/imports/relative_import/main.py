import to_import

def func():
    pass
