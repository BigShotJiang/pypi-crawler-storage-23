The `main` module imports `to_import` module. `to_import` module defines a function which is called.
