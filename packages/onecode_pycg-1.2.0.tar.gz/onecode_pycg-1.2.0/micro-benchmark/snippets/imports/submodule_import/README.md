The `main` module imports `to_import.to_import` module.
`to_import` module has an `__init__` file which defines and calls a function.
`to_import.to_import` module defines and calls a function too.
