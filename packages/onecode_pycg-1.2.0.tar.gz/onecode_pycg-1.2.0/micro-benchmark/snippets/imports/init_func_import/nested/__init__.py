from .mod import func2

def func():
    pass
