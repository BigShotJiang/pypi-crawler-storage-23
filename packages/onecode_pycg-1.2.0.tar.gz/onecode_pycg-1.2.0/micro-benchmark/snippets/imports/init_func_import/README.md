A function is defined inside an init file.
