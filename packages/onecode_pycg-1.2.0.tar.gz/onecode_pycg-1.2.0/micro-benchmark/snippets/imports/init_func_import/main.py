from nested import func, func2

func()
func2()
