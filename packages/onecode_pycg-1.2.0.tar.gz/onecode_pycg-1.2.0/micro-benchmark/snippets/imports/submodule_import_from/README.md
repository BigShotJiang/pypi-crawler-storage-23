Same concept as `import_from` but with a submodule.
