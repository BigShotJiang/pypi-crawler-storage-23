import to_import as as_to_import

def func():
    pass
