The `main` module imports `to_import` as `as_import_name`. `to_import` defines a function.
