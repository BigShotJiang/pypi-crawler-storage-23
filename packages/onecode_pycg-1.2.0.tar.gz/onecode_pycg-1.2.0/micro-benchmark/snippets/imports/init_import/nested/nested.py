class Smth:
    def func(self):
        pass

smth = Smth()
