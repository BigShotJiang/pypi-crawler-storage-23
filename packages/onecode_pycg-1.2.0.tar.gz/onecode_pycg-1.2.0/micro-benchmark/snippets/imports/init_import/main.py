from nested import smth

smth.func()
