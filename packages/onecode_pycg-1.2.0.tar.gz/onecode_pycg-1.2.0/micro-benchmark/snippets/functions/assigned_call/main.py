def func():
    pass

a = func
a()
