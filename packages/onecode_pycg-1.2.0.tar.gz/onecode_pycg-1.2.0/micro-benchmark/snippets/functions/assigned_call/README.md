A function is defined, assigned to a variable and called via that variable.
