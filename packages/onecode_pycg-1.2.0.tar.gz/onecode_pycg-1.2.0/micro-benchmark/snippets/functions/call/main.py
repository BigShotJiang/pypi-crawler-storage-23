def func():
    pass

func()
