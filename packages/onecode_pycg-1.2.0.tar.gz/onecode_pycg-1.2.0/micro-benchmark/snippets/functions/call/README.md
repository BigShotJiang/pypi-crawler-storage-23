A function is defined and called.
