Call a function assigned to a variable with a literal parameter.
