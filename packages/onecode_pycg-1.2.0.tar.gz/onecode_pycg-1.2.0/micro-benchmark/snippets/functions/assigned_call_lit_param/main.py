def func(x):
    return x

x = func
x(1)
x("y")
