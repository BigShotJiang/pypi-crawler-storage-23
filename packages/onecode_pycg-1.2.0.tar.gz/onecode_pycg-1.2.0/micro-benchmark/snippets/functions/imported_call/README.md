Import a function from another module and call it
