class A:
    def __init__(self):
        pass

class B(A):
    def func(self):
        pass

b = B()
b.func()
