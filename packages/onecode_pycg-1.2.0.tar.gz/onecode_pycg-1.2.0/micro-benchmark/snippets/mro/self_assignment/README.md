A function is assigned as an attribute to self.
