class A:
    def func(self):
        pass

class B(A):
    pass

b = B()
b.func()
