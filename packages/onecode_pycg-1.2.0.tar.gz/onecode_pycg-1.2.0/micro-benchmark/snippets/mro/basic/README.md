A simple inheritance scheme.
