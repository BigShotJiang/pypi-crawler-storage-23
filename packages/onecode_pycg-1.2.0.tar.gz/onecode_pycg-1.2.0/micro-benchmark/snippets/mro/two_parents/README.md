A class is defined with two parents. The correct ordering must be preserved
when calling a parent function.
