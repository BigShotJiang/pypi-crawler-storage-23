Follow the inheritance chain by calling super.
