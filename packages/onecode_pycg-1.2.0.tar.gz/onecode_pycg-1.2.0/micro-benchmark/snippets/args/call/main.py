def param_func():
    pass

def func(a):
    a()

func(param_func)
