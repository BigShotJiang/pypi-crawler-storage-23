A function `func` is defined which takes as a parameter a function which it later calls.
