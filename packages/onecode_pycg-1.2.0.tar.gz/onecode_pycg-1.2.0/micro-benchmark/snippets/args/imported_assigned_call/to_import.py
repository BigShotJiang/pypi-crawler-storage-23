def func(a):
    a()
