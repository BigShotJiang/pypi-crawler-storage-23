from to_import import func

def param_func():
    pass

a = param_func
func(a)
