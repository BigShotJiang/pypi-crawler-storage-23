Import a function from another module and call it with a function parameter which as been assigned to a variable.
