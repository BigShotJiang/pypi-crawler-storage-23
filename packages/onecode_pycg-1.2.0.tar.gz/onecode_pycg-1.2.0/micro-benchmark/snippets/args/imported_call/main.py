from to_import import func

def param_func():
    pass

func(param_func)
