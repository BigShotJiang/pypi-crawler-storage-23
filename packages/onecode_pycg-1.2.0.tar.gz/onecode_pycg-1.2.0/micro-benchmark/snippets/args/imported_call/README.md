Import a function from another module and call it with a function parameter
