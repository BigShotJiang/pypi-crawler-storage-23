def param_func():
    pass

def func(a):
    a()

b = param_func
func(b)
