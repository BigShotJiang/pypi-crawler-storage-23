A function `func` is defined which takes as a parameter a variable which has a function assigned to it which it later calls.
