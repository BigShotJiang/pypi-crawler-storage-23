Now the parameter function calls a nested function.
