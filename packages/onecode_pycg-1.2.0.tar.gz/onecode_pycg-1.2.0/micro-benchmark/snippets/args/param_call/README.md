A parameter is passed as the return value of a different function call.
