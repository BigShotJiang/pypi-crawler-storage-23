def func():
    pass

eval("func()")
