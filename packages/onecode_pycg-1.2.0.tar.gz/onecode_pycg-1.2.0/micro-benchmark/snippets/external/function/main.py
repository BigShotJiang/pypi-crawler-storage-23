from ext import function

function()
