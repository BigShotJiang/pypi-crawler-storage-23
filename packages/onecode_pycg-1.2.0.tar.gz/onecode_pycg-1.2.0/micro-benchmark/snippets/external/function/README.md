A call on an externally imported function.
