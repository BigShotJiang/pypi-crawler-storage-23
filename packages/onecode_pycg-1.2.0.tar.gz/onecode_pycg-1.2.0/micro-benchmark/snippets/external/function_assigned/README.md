A call on a variable assigned on an externally imported function.
