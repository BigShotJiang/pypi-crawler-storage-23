from ext import function

a = function

a()
