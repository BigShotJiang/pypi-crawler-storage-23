Call on variable assigned to an attribute of an externally imported class.
