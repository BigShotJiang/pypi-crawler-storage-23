A `self` call to a function defined inside an external parent.
