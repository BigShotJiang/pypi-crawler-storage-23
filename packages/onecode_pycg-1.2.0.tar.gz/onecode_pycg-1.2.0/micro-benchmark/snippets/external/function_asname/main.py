from ext import function as fn

fn()
