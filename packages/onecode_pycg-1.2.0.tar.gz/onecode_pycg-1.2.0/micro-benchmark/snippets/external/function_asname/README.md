A call on an externally imported function using `as <name>`.
