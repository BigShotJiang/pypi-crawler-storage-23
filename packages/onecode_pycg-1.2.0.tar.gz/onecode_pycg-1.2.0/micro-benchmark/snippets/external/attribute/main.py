from ext import Cls

a = Cls()
a.fun()
