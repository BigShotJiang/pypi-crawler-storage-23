Attribute call on an externally imported class.
