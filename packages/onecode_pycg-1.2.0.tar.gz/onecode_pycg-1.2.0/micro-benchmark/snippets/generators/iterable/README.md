Test that all the methods of a generator are called.
