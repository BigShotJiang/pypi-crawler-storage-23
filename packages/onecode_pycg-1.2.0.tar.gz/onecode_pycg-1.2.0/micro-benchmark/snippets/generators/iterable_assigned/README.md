A generator is assigned to a variable and then itered.
