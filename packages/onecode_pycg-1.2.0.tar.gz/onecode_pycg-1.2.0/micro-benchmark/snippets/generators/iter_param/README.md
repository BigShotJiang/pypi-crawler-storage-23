A generator is passed as a parameter.
