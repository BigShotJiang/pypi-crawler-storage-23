A generator returns a function which is called.
