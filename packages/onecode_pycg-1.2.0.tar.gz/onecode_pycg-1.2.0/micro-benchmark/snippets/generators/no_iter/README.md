A generator is initialized but never itered. 
