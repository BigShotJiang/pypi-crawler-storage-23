Call of a function which was yielded.
