A class is assigned as a self item to a class.
