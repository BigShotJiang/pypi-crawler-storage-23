A nested import is made and the function defined in the imported module is
called as the module's attribute.
