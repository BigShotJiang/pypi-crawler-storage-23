from nest import imported

imported.func()
