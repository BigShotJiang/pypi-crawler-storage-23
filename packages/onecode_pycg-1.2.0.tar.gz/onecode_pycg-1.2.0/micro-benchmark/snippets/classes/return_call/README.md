A class method returns a different class method. 
