A static method is called.
