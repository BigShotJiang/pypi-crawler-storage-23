class MyClass:
    @staticmethod
    def func():
        pass

MyClass.func()
