class MyClass:
    def func(self):
        pass

a = MyClass()
b = a.func
b()
