A class is instantiated and we assign one of its functions to a variable and
then call that variable.
