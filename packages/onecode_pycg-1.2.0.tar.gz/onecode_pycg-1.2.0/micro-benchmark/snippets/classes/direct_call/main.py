class MyClass:
    def __init__(self):
        pass

    def func(self):
        pass

MyClass().func()
