class MyClass:
    def func(self):
        pass

a = MyClass()
a.func()
