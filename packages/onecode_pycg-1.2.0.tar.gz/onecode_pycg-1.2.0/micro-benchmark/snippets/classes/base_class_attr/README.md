A class has a base that is an attribute.
