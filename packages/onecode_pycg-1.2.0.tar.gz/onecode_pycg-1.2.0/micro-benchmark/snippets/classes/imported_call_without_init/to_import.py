class MyClass:
    def func(self):
        pass
