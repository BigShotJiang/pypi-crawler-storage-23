A class is imported and instantiated and then a function it defines is called.
The class doesn't define an __init__ function.
