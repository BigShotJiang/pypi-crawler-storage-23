import to_import

to_import.func()
