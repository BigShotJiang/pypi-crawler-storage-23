We initialize classes with self parameters in a nested manner.
