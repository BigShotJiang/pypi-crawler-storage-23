A lambda is created and called.
