A lambda is returned from a function and then called.
