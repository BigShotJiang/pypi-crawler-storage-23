def func1():
    pass

def func2():
    pass

x = lambda x: x()

x(func1)
x(func2)
