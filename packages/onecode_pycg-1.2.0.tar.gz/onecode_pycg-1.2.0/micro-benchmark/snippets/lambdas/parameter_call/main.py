def func(a):
    a()

y = lambda x: x + 1

func(y)
