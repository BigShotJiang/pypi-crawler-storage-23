" ".join(["1", "2", "3"])

"a b c".split(" ")

d = {"a": 1}

d.items()
