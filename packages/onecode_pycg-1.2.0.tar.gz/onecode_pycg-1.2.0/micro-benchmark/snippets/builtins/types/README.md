Calling of builtin functions of types.
