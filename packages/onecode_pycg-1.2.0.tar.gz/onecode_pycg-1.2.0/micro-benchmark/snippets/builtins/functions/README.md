A builtin function is called.
