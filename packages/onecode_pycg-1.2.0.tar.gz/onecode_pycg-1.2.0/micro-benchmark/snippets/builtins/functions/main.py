array = [1, 2, 3]
len(array)
