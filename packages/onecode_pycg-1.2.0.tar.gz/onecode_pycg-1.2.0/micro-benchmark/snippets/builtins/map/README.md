A function is applied to elements of a list via map.
