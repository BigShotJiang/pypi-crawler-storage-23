The key of a dictionary is passed as a function parameter.
