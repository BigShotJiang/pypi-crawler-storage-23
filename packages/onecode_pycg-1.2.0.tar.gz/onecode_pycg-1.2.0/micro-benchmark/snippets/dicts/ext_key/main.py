from ext import key

def func():
    pass

d = {"a": func}

d[key]()
