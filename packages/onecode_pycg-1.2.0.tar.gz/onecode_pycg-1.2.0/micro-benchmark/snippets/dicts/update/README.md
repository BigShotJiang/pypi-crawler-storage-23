The update method of dictionaries is used.
