A dictionary key is assigned to the returned value of a function.
