A dictionary is passed as a parameter.
