A dictionary key is assigned to a function.
