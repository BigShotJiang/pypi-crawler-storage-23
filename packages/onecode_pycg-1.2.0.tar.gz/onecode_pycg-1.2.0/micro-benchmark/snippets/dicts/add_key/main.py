def func():
    pass

d = {}

d["b"] = func
d["b"]()
