A new key is added to the dictionary.
