A dictionary containing functions as values is created.
