Use a nested dictionary and assign a value to it.
