A new key is added to a dictionary using the parameter of a function as a key.
