d = {"a": "ab", "c": "ca"}

a, (b, c) = "a", ("b", "c")

d[a]
d[b]
d[c]
