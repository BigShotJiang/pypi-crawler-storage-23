d = {"a": "ab"}

a = b = "b"

d[a]
d[b]
