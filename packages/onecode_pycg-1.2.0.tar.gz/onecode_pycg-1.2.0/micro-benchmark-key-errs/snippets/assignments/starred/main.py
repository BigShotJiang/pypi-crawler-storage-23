d = {"a": "ab", "d": "hi"}

a, *b, c = "a", "b", "c", "d"

d[a]
d[b[0]]
d[b[1]]
d[c]
