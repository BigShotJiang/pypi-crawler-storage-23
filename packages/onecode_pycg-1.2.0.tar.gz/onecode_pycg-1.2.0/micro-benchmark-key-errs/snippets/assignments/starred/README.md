A starred assignment.
