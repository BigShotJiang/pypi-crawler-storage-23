A dictionary is accessed through the `self` attribute of the class.
