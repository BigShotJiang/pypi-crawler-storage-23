class Cls:
    d = {"a": "ab"}
    def func(self, d):
        self.d["b"]

cl = Cls()
cls.fun(d)
