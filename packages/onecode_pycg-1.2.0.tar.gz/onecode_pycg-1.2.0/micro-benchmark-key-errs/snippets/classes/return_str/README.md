A class defines a function that returns a string. That string is used to access
a dictionary.
