A constant is accessed through the `self` attribute of the class.
