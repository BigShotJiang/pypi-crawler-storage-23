A class that defines a constant is instantiated, the constant is then changed
and the dictionary is accessed with that constant through the class attribute.
