class Cls:
    x = "b"

d = {"a": "ab"}

cl = Cls()
d[cl.x]
