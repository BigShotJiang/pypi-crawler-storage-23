A constant defined in the base class is accessed through the `self` attribute of the class.
