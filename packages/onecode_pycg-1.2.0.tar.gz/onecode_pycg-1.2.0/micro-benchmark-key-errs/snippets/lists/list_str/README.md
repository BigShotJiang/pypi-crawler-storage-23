Store strings in list and use them to access dictionary.
