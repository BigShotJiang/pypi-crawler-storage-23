d = {"a": "ab"}

lst = ["a", "b"]
d[lst[0]]
d[lst[1]]
