d = {"a": "ab"}

[d["b"] for b in [1,2,3]]
