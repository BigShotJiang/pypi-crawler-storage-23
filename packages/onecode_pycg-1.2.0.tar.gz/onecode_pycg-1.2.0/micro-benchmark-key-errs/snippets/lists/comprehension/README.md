Dictionary access inside comprehension.
