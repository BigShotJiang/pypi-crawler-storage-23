def func(dct, key):
    dct[key]

d = {"a": "ab"}
d["a"]

func(d, key="b")
