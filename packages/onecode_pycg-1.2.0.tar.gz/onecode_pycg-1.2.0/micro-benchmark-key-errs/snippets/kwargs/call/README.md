A string is passed as an argument to a function that does an invalid dictionary
access.
