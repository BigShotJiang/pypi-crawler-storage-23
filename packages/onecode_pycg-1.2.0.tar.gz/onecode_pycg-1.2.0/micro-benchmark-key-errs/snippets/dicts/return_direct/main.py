def func():
    d = {"a": "ab"}
    return d

func()["b"]
