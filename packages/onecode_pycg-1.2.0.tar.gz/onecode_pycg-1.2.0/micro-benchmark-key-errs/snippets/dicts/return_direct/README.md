A function defines and returns a dictionary which is directly accessed.
