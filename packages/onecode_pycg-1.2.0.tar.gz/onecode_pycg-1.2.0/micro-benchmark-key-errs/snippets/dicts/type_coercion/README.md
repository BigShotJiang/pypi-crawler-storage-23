Check that integer and string keys are separated.
