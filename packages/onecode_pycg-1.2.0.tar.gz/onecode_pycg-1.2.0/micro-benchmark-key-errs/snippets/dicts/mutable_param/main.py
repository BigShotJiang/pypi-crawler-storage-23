def func(d):
    d["a"] = "val"

dct = {}
func(dct)
dct["a"]
dct["b"]
