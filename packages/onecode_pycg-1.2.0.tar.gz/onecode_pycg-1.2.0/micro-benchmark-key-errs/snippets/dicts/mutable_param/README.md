A function takes as a parameter a dictionary and adds a key to it. The
dictionary should be updated.
