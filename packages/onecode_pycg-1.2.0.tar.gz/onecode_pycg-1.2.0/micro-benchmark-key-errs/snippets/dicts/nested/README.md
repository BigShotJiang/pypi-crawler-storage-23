Accessing elements of nested dictionaries.
