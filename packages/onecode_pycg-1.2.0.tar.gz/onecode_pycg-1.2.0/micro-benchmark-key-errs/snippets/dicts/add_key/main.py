d = {"a": "ab"}
d["a"]
d["b"] = "hi"
d["b"]
d["c"]
