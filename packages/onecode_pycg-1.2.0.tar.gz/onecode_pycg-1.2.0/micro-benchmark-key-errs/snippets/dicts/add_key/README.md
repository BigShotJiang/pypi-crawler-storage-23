Accessing a newly added key should not lead to a key error.
