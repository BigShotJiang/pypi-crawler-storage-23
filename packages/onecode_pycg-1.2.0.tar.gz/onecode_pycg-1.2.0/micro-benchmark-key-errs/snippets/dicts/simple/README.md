A simple invalid dictionary access.
