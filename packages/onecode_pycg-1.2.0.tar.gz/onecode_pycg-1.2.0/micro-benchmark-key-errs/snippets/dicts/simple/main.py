d = {"a": "ab"}
d["a"]
d["b"]
