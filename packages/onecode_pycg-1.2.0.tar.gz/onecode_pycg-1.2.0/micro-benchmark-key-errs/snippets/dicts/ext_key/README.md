A constant key is defined in another module and used to access a dictionary.
