from ext import const

d = {"a": "ab"}
d[const]
