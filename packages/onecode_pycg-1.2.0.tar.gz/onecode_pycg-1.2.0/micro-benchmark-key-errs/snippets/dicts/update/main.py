d = {}
d.update({"a": "b"})
d["a"]
