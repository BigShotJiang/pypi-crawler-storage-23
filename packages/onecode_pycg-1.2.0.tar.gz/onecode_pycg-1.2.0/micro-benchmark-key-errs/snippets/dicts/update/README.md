The `update` function adds elements to a dictionary.
