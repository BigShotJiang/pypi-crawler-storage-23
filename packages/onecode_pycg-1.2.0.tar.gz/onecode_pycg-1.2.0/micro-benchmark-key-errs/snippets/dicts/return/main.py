def func():
    d = {"a": "ab"}
    return d

b = func()
b["b"]
