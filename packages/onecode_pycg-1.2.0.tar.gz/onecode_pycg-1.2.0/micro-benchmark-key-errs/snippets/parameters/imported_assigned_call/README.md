A constant is imported from another file and assigned to a variable.
