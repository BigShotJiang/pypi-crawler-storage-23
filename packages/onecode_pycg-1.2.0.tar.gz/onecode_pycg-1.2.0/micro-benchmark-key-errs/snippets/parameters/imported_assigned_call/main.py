from to_import import const1, const2

def func(dct, key):
    dct[key]

d = {"a": "ab"}

a = const1
b = const2
func(d, a)
func(d, b)
