class PluginNotIncludedInUserLicenseError(NotImplementedError):
    pass
