class TemplateError(RuntimeError):
    """
    Error thrown on a programming error from the user
    """
