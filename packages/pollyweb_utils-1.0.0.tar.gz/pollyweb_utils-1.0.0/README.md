# pollyweb-utils

Description...

## Installation

```bash
pip install pollyweb-utils
```

## Git Push Protection

Enable the repository pre-push hook (blocks pushes when security checks or tests fail):

```bash
./scripts/install-git-hooks.sh
```

What it does:
- Runs `scripts/check-security.sh` on every `git push`.
- `check-security.sh` runs:
  - `pip-audit` to detect vulnerable dependencies.
  - `bandit -q -r src` to detect source security issues.
- Runs `.venv/bin/python -m pytest -q` (or `python3 -m pytest -q` if no venv).
- Rejects the push if any security issues or test failures are found.

Install security tools in your active Python environment:

```bash
python3 -m pip install pip-audit "bandit[toml]"
```
