from os.path import dirname, basename, isfile, join, abspath
from importlib import import_module
import sys
import glob
from functools import reduce

from hestia_earth.models.log import debugValues, logShouldRun
from .. import MODEL as PARENT_MODEL

CURRENT_DIR = dirname(abspath(__file__)) + "/"
sys.path.append(CURRENT_DIR)
MODEL = "completeness"
PKG = ".".join(["hestia_earth", "models", PARENT_MODEL, MODEL])
modules = glob.glob(join(dirname(__file__), "*.py"))
modules = [
    basename(f)[:-3] for f in modules if isfile(f) and not f.endswith("__init__.py")
]
MODELS = list(
    map(
        lambda m: {
            "key": m,
            "run": getattr(import_module(f".{m}", package=PKG), "run"),
        },
        modules,
    )
)


def _run_model(cycle: dict):
    def process(completeness: dict, model: dict):
        key = model.get("key")
        result = model.get("run")(cycle)
        logShouldRun(cycle, MODEL, None, result, key=key)
        completeness[key] = result or False
        return completeness

    return process


def _run(cycle: dict):
    completeness = cycle.get("completeness", {})

    # find the keys that are False
    keys = [
        model.get("key") for model in MODELS if not completeness.get(model.get("key"))
    ]
    debugValues(cycle, model=MODEL, keys=";".join(keys))

    return reduce(
        _run_model(cycle),
        # only run the models that are incomplete
        [m for m in MODELS if m.get("key") in keys],
        completeness,
    )


def run(cycle: dict):
    return _run(cycle)
