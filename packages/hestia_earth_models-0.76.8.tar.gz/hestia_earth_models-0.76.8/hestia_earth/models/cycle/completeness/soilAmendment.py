from hestia_earth.utils.blank_node import get_node_value
from hestia_earth.models.log import logRequirements
from hestia_earth.models.utils.measurement import most_relevant_measurement_by_term_id
from . import MODEL

REQUIREMENTS = {
    "Cycle": {
        "completeness.soilAmendment": "False",
        "endDate": "",
        "site": {
            "@type": "Site",
            "measurements": [
                {
                    "@type": "Measurement",
                    "value": "",
                    "term.@id": "soilPh",
                    "methodClassification": [
                        "geospatial dataset",
                        "regional statistical data",
                        "country-level statistical data",
                    ],
                }
            ],
        },
    }
}
RETURNS = {"Completeness": {"soilAmendment": ""}}
MODEL_KEY = "soilAmendment"
_METHOD_CLASSIFICATIONS = REQUIREMENTS["Cycle"]["site"]["measurements"][0][
    "methodClassification"
]


def run(cycle: dict):
    end_date = cycle.get("endDate")
    measurements = cycle.get("site", {}).get("measurements", [])
    soilPh_measurement = most_relevant_measurement_by_term_id(
        measurements, "soilPh", end_date
    )
    soilPh = get_node_value(soilPh_measurement, default=None)
    method_classification = (soilPh_measurement or {}).get("methodClassification")
    is_country_data = method_classification in _METHOD_CLASSIFICATIONS
    soilPh_above_6_5 = soilPh is not None and soilPh > 6.5

    logRequirements(
        cycle,
        model=MODEL,
        term=None,
        key=MODEL_KEY,
        is_country_data=is_country_data,
        soilPh_above_6_5=soilPh_above_6_5,
    )

    return all([is_country_data, soilPh_above_6_5])
