from hestia_earth.schema import SiteSiteType
from hestia_earth.utils.lookup import download_lookup, get_table_value
from hestia_earth.utils.tools import safe_parse_float

from hestia_earth.models.log import (
    logRequirements,
    debugMissingLookup,
    logShouldRun,
    log_as_table,
)
from hestia_earth.models.utils import sum_values, multiply_values
from hestia_earth.models.utils.constant import DEFAULT_COUNTRY_ID
from hestia_earth.models.utils.indicator import _new_indicator
from hestia_earth.models.utils.impact_assessment import (
    get_site,
    get_region_id,
)
from hestia_earth.models.utils.lookup import get_region_lookup_value
from . import MODEL

REQUIREMENTS = {
    "ImpactAssessment": {
        "site": {
            "@type": "Site",
            "or": {
                "awareWaterBasinId": "",
                "country": {"@type": "Term", "termType": "region"},
            },
        },
        "emissionsResourceUse": [
            {
                "@type": "Indicator",
                "term.@id": "freshwaterWithdrawalsDuringCycle",
                "value": "",
            }
        ],
        "optional": {
            "emissionsResourceUse": [
                {
                    "@type": "Indicator",
                    "term.@id": "freshwaterWithdrawalsInputsProduction",
                    "value": "",
                }
            ]
        },
    }
}
RETURNS = {"Indicator": [{"value": ""}]}
LOOKUPS = {
    "@doc": "Different lookup files are used depending on the situation",
    "awareWaterBasinId-2-0": ["CFs_agri", "CFs_nonagri", "CFs_unspecified"],
    "region-aware-2-0-factors": ["CFs_agri", "CFs_nonagri", "CFs_unspecified"],
}
TERM_ID = "scarcityWeightedWaterUse"
AWARE_KEY = "awareWaterBasinId"
AGRI_SITE_TYPES = [
    SiteSiteType.CROPLAND.value,
    SiteSiteType.GLASS_OR_HIGH_ACCESSIBLE_COVER.value,
    SiteSiteType.PERMANENT_PASTURE.value,
]
_REGION_LOOKUP = "region-aware-2-0-factors.csv"
_AWARE_LOOKUP = "awareWaterBasinId-2-0.csv"


def _lookup_column(site: dict):
    site_type = site.get("siteType")
    return (
        "CFs_unspecified"
        if not site_type
        else "CFs_agri" if site_type in AGRI_SITE_TYPES else "CFs_nonagri"
    )


def _get_factor_from_basinId(site: dict, aware_id: str) -> float:
    lookup_col = _lookup_column(site)
    lookup = download_lookup(_AWARE_LOOKUP)
    value = get_table_value(lookup, AWARE_KEY, int(aware_id), lookup_col)
    debugMissingLookup(
        _AWARE_LOOKUP, AWARE_KEY, aware_id, lookup_col, value, model=MODEL, term=TERM_ID
    )
    return safe_parse_float(value, default=None)


def _get_factor_from_region(region_id: str, site: dict):
    lookup_col = _lookup_column(site)
    value = get_region_lookup_value(
        _REGION_LOOKUP, region_id, lookup_col, model=MODEL, term=TERM_ID
    )
    return safe_parse_float(value, default=None)


def _get_data(impact_assessment: dict):
    site = get_site(impact_assessment)
    aware_id = site.get(AWARE_KEY)
    aware_factor_from_basinId = (
        _get_factor_from_basinId(site, aware_id) if aware_id else None
    )

    def get_data(blank_node: dict):
        term_id = blank_node.get("term", {}).get("@id")
        is_during_cycle = term_id.endswith("DuringCycle")
        value = blank_node.get("value")

        country_id = blank_node.get("country", {}).get("@id") or (
            get_region_id(impact_assessment) if is_during_cycle else DEFAULT_COUNTRY_ID
        )
        aware_factor = (
            aware_factor_from_basinId if is_during_cycle else None
        ) or _get_factor_from_region(country_id, site if is_during_cycle else {})

        return {
            "term-id": term_id,
            "aware-id": aware_id,
            "aware-factor": aware_factor,
            "input-value": value,
            "country-id": country_id,
            "is-valid": all([value is not None, aware_factor is not None]),
        }

    return get_data


def run(impact_assessment: dict):
    resource_uses = [
        v
        for v in impact_assessment.get("emissionsResourceUse", [])
        if v.get("term", {}).get("@id", "").startswith("freshwaterWithdrawals")
    ]
    resource_uses = list(map(_get_data(impact_assessment), resource_uses))

    has_during_cycle_value = any(
        [
            value["term-id"].endswith("DuringCycle")
            for value in resource_uses
            if value.get("is-valid")
        ]
    )

    value = sum_values(
        [
            multiply_values([value.get("input-value"), value.get("aware-factor")])
            for value in resource_uses
            if value.get("is-valid")
        ]
    )

    logRequirements(
        impact_assessment,
        model=MODEL,
        term=TERM_ID,
        has_during_cycle_value=has_during_cycle_value,
        values=log_as_table(resource_uses),
        total_value=value,
    )

    should_run = all([has_during_cycle_value, value is not None])
    logShouldRun(impact_assessment, MODEL, TERM_ID, should_run)

    return (
        [_new_indicator(term=TERM_ID, model=MODEL, value=value)] if should_run else []
    )
