LOOKUP_MAPPING_KEY = "ecoalimMapping"
LOOKUP_NAME_PREFIX = "ecoalim-"
LOOKUP_INDEX_KEY = "ecoalimMappingName"
