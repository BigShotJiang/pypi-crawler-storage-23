from hestia_earth.models.utils.landCover import get_pef_grouping
from hestia_earth.models.utils.lookup import get_region_lookup_value
from hestia_earth.models.utils.impact_assessment import get_country_id
from hestia_earth.models.utils.landOccupation import run as run_landOccupation
from . import MODEL

REQUIREMENTS = {
    "ImpactAssessment": {
        "optional": {"country": {"@type": "Term", "termType": "region"}},
        "emissionsResourceUse": [
            {
                "@type": "Indicator",
                "term.@id": [
                    "landOccupationInputsProduction",
                    "landOccupationDuringCycle",
                ],
                "value": "",
                "landCover": {"@type": "Term", "term.termType": "landCover"},
            }
        ],
    }
}

LOOKUPS = {
    "@doc": "Performs lookup on landCover.csv for column headers and region-pefTermGrouping-landOccupation.csv for CFs",
    "region-pefTermGrouping-landOccupation": "",
    "landCover": "pefTermGrouping",
}

RETURNS = {"Indicator": {"value": ""}}
TERM_ID = "soilQualityIndexLandOccupation"
LOOKUP = f"{list(LOOKUPS.keys())[1]}.csv"


def _extend_indicator_data(impact_assessment: dict, indicator: dict) -> dict:
    country_id = get_country_id(impact_assessment, blank_node=indicator)
    grouping = get_pef_grouping(indicator.get("landCover", {}).get("@id"))
    coefficient = get_region_lookup_value(
        model=MODEL,
        term=TERM_ID,
        lookup_name=LOOKUP,
        term_id=country_id,
        column=grouping,
        fallback_world=True,
    )
    return {
        "country-id": country_id,
        "pef-grouping": grouping,
        "coefficient": coefficient,
    }


def run(impact_assessment: dict):
    return run_landOccupation(
        model=MODEL,
        term_id=TERM_ID,
        impact_assessment=impact_assessment,
        extend_indicator_data_func=_extend_indicator_data,
    )
