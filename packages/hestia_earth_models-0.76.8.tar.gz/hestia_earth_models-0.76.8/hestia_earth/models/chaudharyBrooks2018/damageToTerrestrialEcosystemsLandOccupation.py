from hestia_earth.models.utils.landOccupation import run as run_landOccupation
from .utils import get_region_factor
from . import MODEL

REQUIREMENTS = {
    "ImpactAssessment": {
        "site": {
            "@type": "Site",
            "or": {"ecoregion": "", "country": {"@type": "Term", "termType": "region"}},
        },
        "emissionsResourceUse": [
            {
                "@type": "Indicator",
                "term.@id": [
                    "landOccupationInputsProduction",
                    "landOccupationDuringCycle",
                ],
                "value": "",
                "landCover": {"@type": "Term", "term.termType": "landCover"},
                "optional": {"country": {"@type": "Term", "termType": "region"}},
            }
        ],
    }
}
RETURNS = {"Indicator": {"value": ""}}
LOOKUPS = {
    "@doc": "Different lookup files are used depending on the situation",
    "ecoregion-landCover-LandOccupationChaudaryBrooks2018CF": "",
    "region-landCover-LandOccupationChaudaryBrooks2018CF": "",
    "landCover": "landOccupationLandTransformationTermId",
}
TERM_ID = "damageToTerrestrialEcosystemsLandOccupation"
_LOOKUP_SUFFIX = "LandOccupationChaudaryBrooks2018CF"


def _extend_indicator_data(impact_assessment: dict, indicator: dict) -> dict:
    factor = get_region_factor(
        TERM_ID, impact_assessment, _LOOKUP_SUFFIX, "medium_intensity", indicator
    )
    return {"coefficient": factor}


def run(impact_assessment: dict):
    return run_landOccupation(
        model=MODEL,
        term_id=TERM_ID,
        impact_assessment=impact_assessment,
        extend_indicator_data_func=_extend_indicator_data,
    )
