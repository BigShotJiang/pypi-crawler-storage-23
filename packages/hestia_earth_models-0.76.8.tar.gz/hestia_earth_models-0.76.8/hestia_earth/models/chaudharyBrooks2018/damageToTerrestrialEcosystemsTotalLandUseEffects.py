from hestia_earth.utils.tools import list_sum, non_empty_list
from hestia_earth.utils.model import find_term_match

from hestia_earth.models.log import logRequirements, logShouldRun, log_as_table
from hestia_earth.models.utils.indicator import _new_indicator
from . import MODEL

REQUIREMENTS = {
    "ImpactAssessment": {
        "impacts": [
            {
                "@type": "Indicator",
                "value": "",
                "term.@id": "damageToTerrestrialEcosystemsLandOccupation",
            },
            {
                "@type": "Indicator",
                "value": "",
                "term.@id": "damageToTerrestrialEcosystemsLandTransformation",
            },
        ],
    }
}
RETURNS = {"Indicator": {"value": ""}}
TERM_ID = "damageToTerrestrialEcosystemsTotalLandUseEffects"
_BIODIVERSITY_TERM_IDS = [
    i["term.@id"] for i in REQUIREMENTS["ImpactAssessment"]["impacts"]
]


def run(impact_assessment: dict):
    impacts = [
        {
            "impact-id": term_id,
            "value": find_term_match(impact_assessment.get("impacts", []), term_id).get(
                "value"
            ),
        }
        for term_id in _BIODIVERSITY_TERM_IDS
    ]
    impacts_value = list_sum(
        non_empty_list(map(lambda i: i.get("value"), impacts)),
        None,
    )
    has_all_values = all([i["value"] is not None for i in impacts])

    logRequirements(
        impact_assessment,
        model=MODEL,
        term=TERM_ID,
        has_all_values=has_all_values,
        impacts=log_as_table(impacts),
    )

    should_run = all([has_all_values, impacts_value is not None])
    logShouldRun(impact_assessment, MODEL, TERM_ID, should_run)
    return (
        _new_indicator(term=TERM_ID, model=MODEL, value=impacts_value)
        if should_run
        else None
    )
