from hestia_earth.models.utils.landTransformation import run as run_landTransformation
from .utils import get_region_factor
from . import MODEL

REQUIREMENTS = {
    "ImpactAssessment": {
        "site": {
            "@type": "Site",
            "or": {"ecoregion": "", "country": {"@type": "Term", "termType": "region"}},
        },
        "emissionsResourceUse": [
            {
                "@type": "Indicator",
                "term.@id": [
                    "landTransformation20YearAverageDuringCycle",
                    "landTransformation20YearAverageInputsProduction",
                ],
                "value": "",
                "landCover": {"@type": "Term", "term.termType": "landCover"},
                "previousLandCover": {
                    "@type": "Term",
                    "term.@id": "forest",
                    "term.termType": "landCover",
                },
                "optional": {"country": {"@type": "Term", "termType": "region"}},
            }
        ],
    }
}
RETURNS = {"Indicator": {"value": ""}}
LOOKUPS = {
    "@doc": "Different lookup files are used depending on the situation",
    "ecoregion-landCover-LandTransformationFromForestChaudaryBrooks2018CF": "",
    "region-landCover-LandTransformationFromForestChaudaryBrooks2018CF": "",
    "landCover": "landOccupationLandTransformationTermId",
}
TERM_ID = "damageToTerrestrialEcosystemsLandTransformation"

_LOOKUP_SUFFIX = "LandTransformationFromForestChaudaryBrooks2018CF"


def _extend_indicator_data(impact_assessment: dict, indicator: dict) -> dict:
    factor = get_region_factor(
        TERM_ID, impact_assessment, _LOOKUP_SUFFIX, "medium_intensity", indicator
    )
    return {"coefficient": factor}


def _filter_forest(indicator: dict):
    return indicator.get("previousLandCover", {}).get("@id") == "forest"


def run(impact_assessment: dict):
    return run_landTransformation(
        model=MODEL,
        term_id=TERM_ID,
        period=20,
        impact_assessment=impact_assessment,
        extend_indicator_data_func=_extend_indicator_data,
        filter_indicator_func=_filter_forest,
    )
