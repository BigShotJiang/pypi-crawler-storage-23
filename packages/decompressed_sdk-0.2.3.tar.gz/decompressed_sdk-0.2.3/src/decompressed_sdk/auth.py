from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Protocol


class AuthStrategy(Protocol):
    def headers(self) -> Dict[str, str]:
        ...


@dataclass(frozen=True)
class ApiKeyAuth:
    api_key: str

    def __post_init__(self) -> None:
        if not self.api_key:
            raise ValueError("API key is required")

    def headers(self) -> Dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}"}


@dataclass(frozen=True)
class JwtAuth:
    jwt: str

    def __post_init__(self) -> None:
        if not self.jwt:
            raise ValueError("JWT is required")

    def headers(self) -> Dict[str, str]:
        return {"Authorization": f"Bearer {self.jwt}"}
