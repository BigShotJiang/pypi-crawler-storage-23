"""Version-first type definitions for Snowflake-like semantics.

Core mental model:
- Dataset = history (immutable log of versions)
- Version = reality (the thing you operate on)

Nothing meaningful happens without a version.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..resources.versions import CommittedVersion, DraftVersion


class VersionStatus(str, Enum):
    """Status of a version in its lifecycle."""
    DRAFT = "draft"        # Mutable, not yet committed
    COMMITTED = "committed"  # Immutable, addressable forever
    ARCHIVED = "archived"   # Soft-deleted, can be restored


@dataclass
class Dataset:
    """
    A dataset is history - an immutable log of versions.
    
    Datasets don't hold vectors directly. They hold versions, and versions
    hold vectors. This is the "Snowflake moment" - treating embedding data
    like code: versioned, testable, and safe to deploy.
    
    Example:
        dataset = dc.datasets.get("support-docs")
        
        # Create a new version (staging area)
        v = dataset.new_version(description="Add Feb tickets")
        
        # Mutate ONLY the version
        v.add_vectors(vectors, metadata)
        v.remove(filter={"source": "old_import"})
        
        # Lock it in
        v.commit()
        
        # Promote to a named ref
        v.promote("main")
    """
    id: str
    name: str
    current_version: int
    num_vectors: Optional[int] = None
    dimensions: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    
    # Named refs (e.g., "main", "prod", "staging")
    refs: Optional[Dict[str, int]] = None
    
    # Internal: client reference for making API calls
    _client: Any = field(default=None, repr=False)
    
    def new_version(
        self,
        description: Optional[str] = None,
        parent: Optional[int] = None,
    ) -> "DraftVersion":
        """
        Create a new draft version (staging area).
        
        The draft is mutable until you call commit(). After commit,
        it becomes immutable and addressable forever.
        
        Args:
            description: Human-readable description of what this version contains
            parent: Parent version to base this on (default: current version)
            
        Returns:
            DraftVersion that you can mutate before committing
        """
        if self._client is None:
            raise RuntimeError("Dataset not bound to client")
        from ..resources.versions import DraftVersion
        return DraftVersion._create(
            self._client,
            self.id,
            parent_version=parent or self.current_version,
            description=description,
        )
    
    def version(self, v: int) -> "CommittedVersion":
        """
        Get a specific committed version by number.
        
        Args:
            v: Version number
            
        Returns:
            CommittedVersion (immutable, addressable)
        """
        if self._client is None:
            raise RuntimeError("Dataset not bound to client")
        from ..resources.versions import CommittedVersion
        return CommittedVersion(self._client, self.id, v)
    
    def ref(self, name: str = "main") -> "CommittedVersion":
        """
        Get the version at a named ref.
        
        Named refs are like git branches - they point to a specific version
        and can be updated via promote().
        
        Args:
            name: Ref name (default: "main")
            
        Returns:
            CommittedVersion at that ref
        """
        if self._client is None:
            raise RuntimeError("Dataset not bound to client")
        from ..resources.versions import CommittedVersion
        return CommittedVersion._from_ref(self._client, self.id, name)
    
    def at(self, timestamp: str) -> "CommittedVersion":
        """
        Get the version that was current at a specific timestamp.
        
        Enables time-travel queries for reproducibility.
        
        Args:
            timestamp: ISO 8601 timestamp (e.g., "2024-01-28T00:00:00Z")
            
        Returns:
            CommittedVersion that was current at that time
        """
        if self._client is None:
            raise RuntimeError("Dataset not bound to client")
        from ..resources.versions import CommittedVersion
        return CommittedVersion._from_timestamp(self._client, self.id, timestamp)
    
    def latest(self) -> "CommittedVersion":
        """
        Get the latest (current) version.
        
        Shorthand for dataset.version(dataset.current_version).
        
        Returns:
            CommittedVersion for the current version
        """
        return self.version(self.current_version)
    
    def history(self, limit: int = 50) -> List["VersionInfo"]:
        """
        Get the version history for this dataset.
        
        Returns versions in reverse chronological order (newest first).
        """
        if self._client is None:
            raise RuntimeError("Dataset not bound to client")
        from urllib.parse import quote
        path = f"/api/v1/datasets/{quote(self.id)}/versions?limit={limit}"
        data = self._client.request("GET", path)
        return [VersionInfo(**v) for v in data.get("versions", [])]


# Keep DatasetRef as alias for backward compatibility
DatasetRef = Dataset


@dataclass
class VersionedDataset:
    """
    A dataset pinned to a specific version.
    
    All query/search/export operations on this object use the pinned version,
    ensuring reproducible results.
    """
    dataset_id: str
    version: int
    num_vectors: int
    num_blocks: int
    dimension: Optional[int] = None
    compression: Optional[str] = None
    created_at: Optional[str] = None
    changelog: Optional[Dict[str, Any]] = None


@dataclass
class VersionInfo:
    """Detailed information about a specific version."""
    version: int
    num_vectors: int
    num_blocks: int
    total_size_bytes: Optional[int] = None
    metadata_path: Optional[str] = None
    created_at: Optional[str] = None
    created_by: Optional[str] = None
    changelog: Optional[Dict[str, Any]] = None


@dataclass
class DatasetEvent:
    """
    An event in the dataset's activity history.
    
    Events track all significant actions on a dataset:
    - Uploads, appends, deletes
    - Materializations
    - Sync jobs
    - Metadata updates
    """
    id: str
    dataset_id: str
    event_type: str
    created_at: str
    actor_type: Optional[str] = None  # 'user', 'api_key', 'system'
    actor_id: Optional[str] = None
    status: Optional[str] = None  # 'started', 'succeeded', 'failed'
    message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    version_before: Optional[int] = None
    version_after: Optional[int] = None


@dataclass
class VersionComparison:
    """
    Comparison between two versions of a dataset.
    
    Useful for LLM regression testing and understanding changes.
    """
    dataset_id: str
    version_a: int
    version_b: int
    vectors_added: int = 0
    vectors_removed: int = 0
    vectors_modified: int = 0
    blocks_added: int = 0
    blocks_removed: int = 0
    metadata_changes: Optional[Dict[str, Any]] = None
