"""Materialization type definitions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional

MaterializationType = Literal["index", "export", "view"]
MaterializationStatus = Literal["pending", "building", "ready", "failed"]


@dataclass
class Materialization:
    """A materialization of a dataset (recompressed or alternate representation)."""
    id: str
    dataset_id: str
    name: str
    type: MaterializationType
    config: Dict[str, Any]
    source_version: int
    status: MaterializationStatus
    storage_path: Optional[str] = None
    progress: Optional[int] = None
    progress_details: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    created_at: Optional[str] = None
    created_by: Optional[str] = None


@dataclass
class CreateMaterializationResponse:
    """Response from creating a materialization."""
    materialization_id: str
    dataset_id: str
    job_id: str
    status: str
    message: Optional[str] = None


@dataclass
class MaterializationEstimate:
    """Estimate for building a materialization."""
    estimated_size_bytes: int
    estimated_build_time_seconds: int
    num_blocks: int


@dataclass
class MaterializationDownloadFile:
    """A file available for download from a materialization."""
    file_name: str
    file_path: str
    url: str
    size_bytes: int
    type: str  # 'block' or 'index'


@dataclass
class MaterializationDownloadResponse:
    """Response from downloading a materialization."""
    materialization_id: str
    storage_path: str
    urls: List[MaterializationDownloadFile]
    expires_in: int
    file_count: int
