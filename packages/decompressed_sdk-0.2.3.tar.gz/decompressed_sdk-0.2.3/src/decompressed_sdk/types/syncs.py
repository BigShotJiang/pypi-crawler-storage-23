"""Sync job type definitions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class SyncJob:
    """A sync job that uploads vectors to a connector."""
    id: str
    dataset_id: str
    connector_id: str
    status: str
    config: Optional[Dict[str, Any]] = None
    filters: Optional[Dict[str, Any]] = None
    source_version: Optional[int] = None  # NEW: Version pinning for reproducibility
    total_vectors: Optional[int] = None
    vectors_synced: int = 0
    total_batches: Optional[int] = None
    batches_completed: int = 0
    batches_failed: int = 0
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    duration_seconds: Optional[int] = None
    vectors_per_second: Optional[float] = None
    error_message: Optional[str] = None
    created_at: Optional[str] = None


@dataclass
class SyncResult:
    """Result of creating a sync job."""
    sync_job_id: str
    dataset_id: str
    job_id: str
    status: str
    source_version: Optional[int] = None  # NEW: Version that will be synced
    message: Optional[str] = None


@dataclass
class SyncValidation:
    """Result of validating a sync before execution."""
    can_proceed: bool
    connection_test: Optional[Dict[str, Any]] = None
    metadata_validation: Optional[Dict[str, Any]] = None
    dataset_info: Optional[Dict[str, Any]] = None
    errors: Optional[List[Dict[str, Any]]] = None


@dataclass
class SyncState:
    """Sync state between a dataset and connector."""
    connector_id: str
    connector_name: str
    connector_type: str
    sync_status: str
    last_synced_version: Optional[int] = None
    last_synced_at: Optional[str] = None
    vectors_in_destination: Optional[int] = None
    auto_sync_enabled: bool = False
    versions_behind: int = 0
