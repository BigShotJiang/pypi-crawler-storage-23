"""Embedding type definitions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class SourceReference:
    """A typed reference to external content."""
    id: str
    source_type: str
    uri: str
    checksum: Optional[str] = None
    content_type: Optional[str] = None
    filename: Optional[str] = None
    created_at: Optional[str] = None


@dataclass
class EmbeddingJob:
    """An embedding generation job."""
    id: str
    job_id: Optional[str] = None
    dataset_id: Optional[str] = None
    dataset_name: Optional[str] = None
    model: Optional[str] = None
    status: str = "pending"
    progress: int = 0
    total_sources: int = 0
    processed_sources: int = 0
    total_chunks: int = 0
    processed_chunks: int = 0
    created_at: Optional[str] = None
    error_message: Optional[str] = None


@dataclass
class EmbeddingJobStatus:
    """Detailed status of an embedding job."""
    id: str
    status: str = "pending"
    progress: int = 0
    total_sources: int = 0
    processed_sources: int = 0
    total_chunks: int = 0
    processed_chunks: int = 0
    total_tokens_used: int = 0
    dataset_id: Optional[str] = None
    dataset_name: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    duration_seconds: Optional[float] = None
    error_message: Optional[str] = None
    estimated_cost_usd: Optional[float] = None
    actual_cost_usd: Optional[float] = None


@dataclass
class EmbeddingResult:
    """Result of creating an embedding job."""
    id: str
    job_id: str
    status: str
