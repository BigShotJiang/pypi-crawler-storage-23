"""Connector type definitions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class Connector:
    """A configured connector to an external service (vector DB, etc.)."""
    id: str
    name: str
    connector_type: str
    is_active: Optional[bool] = None
    last_tested_at: Optional[str] = None
    last_test_status: Optional[str] = None
    created_at: Optional[str] = None
