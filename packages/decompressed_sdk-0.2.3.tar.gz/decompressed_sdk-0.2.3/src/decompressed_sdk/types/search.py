"""Search type definitions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class SearchMatch:
    """A single search match result."""
    rank: int
    vector_index: int
    distance: float
    score: float
    block_id: Optional[str] = None
    block_offset: Optional[int] = None
    metadata: Optional[dict] = None


@dataclass
class SearchResponse:
    """Response from vector search."""
    matches: List[SearchMatch]
    num_queries: int
    search_method: str
    num_vectors_searched: Optional[int] = None
    metric: Optional[str] = None
    materialization_id: Optional[str] = None
    message: Optional[str] = None
    warning: Optional[str] = None
    version: Optional[int] = None  # NEW: Version that was searched
