"""Import job type definitions for pulling vectors from external databases."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class ImportSession:
    """An import session for pulling vectors from an external database."""
    import_session_id: str
    dataset_id: str
    connector_type: str
    estimated_vectors: int
    dimension: int


@dataclass
class ImportJob:
    """Status of an import job."""
    import_session_id: str
    dataset_id: Optional[str]
    status: str
    job_id: Optional[str] = None
    job_status: Optional[str] = None
    progress: Optional[int] = None
    error_message: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class ImportResult:
    """Result of starting an import job."""
    import_session_id: str
    job_id: str
    status: str
    message: Optional[str] = None
