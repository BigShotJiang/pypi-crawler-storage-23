"""Decompressed SDK type definitions."""

from .base import MetadataFilterValue, MetadataFilters
from .datasets import (
    Dataset,
    DatasetInfo,
    DatasetQueryResponse,
    DatasetVersion,
    UploadSession,
    AppendSession,
    JobStatus,
    UploadResult,
    AppendResult,
)
from .versions import (
    Dataset,
    DatasetRef,  # Alias for Dataset (backward compat)
    VersionedDataset,
    VersionStatus,
    DatasetEvent,
    VersionInfo,
    VersionComparison,
)
from .materializations import (
    Materialization,
    MaterializationType,
    MaterializationStatus,
    CreateMaterializationResponse,
    MaterializationEstimate,
    MaterializationDownloadFile,
    MaterializationDownloadResponse,
)
from .connectors import Connector
from .syncs import (
    SyncJob,
    SyncResult,
    SyncValidation,
    SyncState,
)
from .embeddings import (
    SourceReference,
    EmbeddingJob,
    EmbeddingJobStatus,
    EmbeddingResult,
)
from .search import SearchMatch, SearchResponse
from .imports import ImportSession, ImportJob, ImportResult

__all__ = [
    # Base
    "MetadataFilterValue",
    "MetadataFilters",
    # Datasets
    "Dataset",
    "DatasetInfo",
    "DatasetQueryResponse",
    "DatasetVersion",
    "UploadSession",
    "AppendSession",
    "JobStatus",
    "UploadResult",
    "AppendResult",
    # Versions (Version-First)
    "Dataset",
    "DatasetRef",
    "VersionedDataset",
    "VersionStatus",
    "DatasetEvent",
    "VersionInfo",
    "VersionComparison",
    # Materializations
    "Materialization",
    "MaterializationType",
    "MaterializationStatus",
    "CreateMaterializationResponse",
    "MaterializationEstimate",
    "MaterializationDownloadFile",
    "MaterializationDownloadResponse",
    # Connectors
    "Connector",
    # Syncs
    "SyncJob",
    "SyncResult",
    "SyncValidation",
    "SyncState",
    # Embeddings
    "SourceReference",
    "EmbeddingJob",
    "EmbeddingJobStatus",
    "EmbeddingResult",
    # Search
    "SearchMatch",
    "SearchResponse",
    # Imports
    "ImportSession",
    "ImportJob",
    "ImportResult",
]
