"""Base type definitions shared across the SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Union

# Metadata filter types
MetadataFilterValue = Union[
    str,
    int,
    float,
    bool,
    List[str],
    List[int],
    List[float],
    Dict[str, Any],  # For operators like {"$gt": 10}
]

MetadataFilters = Dict[str, MetadataFilterValue]
