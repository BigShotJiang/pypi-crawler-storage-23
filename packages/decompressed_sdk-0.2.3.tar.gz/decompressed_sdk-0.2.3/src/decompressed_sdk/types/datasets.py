"""Dataset-related type definitions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class Dataset:
    """A dataset record from the API."""
    id: str
    name: str
    storage_type: Optional[str] = None
    current_version: Optional[int] = None
    block_storage_prefix: Optional[str] = None
    num_vectors: Optional[int] = None
    dimensions: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class DatasetVersion:
    """A specific version of a dataset."""
    version: int
    num_vectors: int
    num_blocks: int
    changelog: Optional[Dict[str, Any]] = None
    created_at: Optional[str] = None


@dataclass
class DatasetInfo:
    """Detailed info about a dataset at a specific version."""
    dataset_id: str
    version: int
    available_versions: List[int]
    num_blocks: int
    num_vectors: int
    dimension: Optional[int] = None
    compression: Optional[str] = None
    columns: Optional[List[str]] = None
    columns_info: Optional[Dict[str, Any]] = None
    storage_info: Optional[Dict[str, Any]] = None
    block_storage_prefix: Optional[str] = None


@dataclass
class DatasetQueryResponse:
    """Response from querying dataset metadata."""
    dataset_id: str
    matched_vectors: int = 0
    blocks_required: int = 0
    version: Optional[int] = None
    total_blocks: Optional[int] = None
    efficiency_percent: Optional[float] = None
    vectors: Optional[List[Dict[str, Any]]] = None


@dataclass
class UploadSession:
    """An upload session for async uploads."""
    upload_session_id: str
    upload_url: str
    dataset_id: Optional[str] = None


@dataclass
class AppendSession:
    """An append session for async appends."""
    append_session_id: str
    upload_url: str
    dataset_id: Optional[str] = None


@dataclass
class JobStatus:
    """Status of an async job."""
    job_id: str
    job_status: str
    progress: Optional[int] = None
    error_message: Optional[str] = None
    result: Optional[Dict[str, Any]] = None


@dataclass
class UploadResult:
    """Result of a completed upload."""
    dataset_id: str
    job_id: str
    upload_session_id: str


@dataclass
class AppendResult:
    """Result of a completed append."""
    dataset_id: str
    job_id: str
    append_session_id: str
    previous_version: Optional[int] = None
    new_version: Optional[int] = None


@dataclass
class BlockData:
    """A single block of vectors for ML training iteration."""
    block_id: str
    vectors: Any  # numpy array
    metadata: List[Dict[str, Any]]
    num_vectors: int
    block_index: int
    total_blocks: int
