"""Decompressed SDK resource modules.

Version-first design:
- DraftVersion: Mutable staging area before commit
- CommittedVersion: Immutable, addressable forever
"""

from .datasets import DatasetsResource
from .versions import DraftVersion, CommittedVersion, VersionedDatasetResource
from .materializations import MaterializationsResource
from .connectors import ConnectorsResource
from .syncs import SyncsResource
from .embeddings import EmbeddingsResource
from .imports import ImportsResource

__all__ = [
    "DatasetsResource",
    "DraftVersion",
    "CommittedVersion",
    "VersionedDatasetResource",  # Backward compat alias
    "MaterializationsResource",
    "ConnectorsResource",
    "SyncsResource",
    "EmbeddingsResource",
    "ImportsResource",
]
