"""Embeddings resource."""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import DecompressedClient

from ..errors import raise_for_status
from ..types.embeddings import SourceReference, EmbeddingJob, EmbeddingJobStatus


def _filter_dataclass_kwargs(model: type, data: Dict[str, Any]) -> Dict[str, Any]:
    """Filter dict to only include fields defined in the dataclass."""
    allowed = getattr(model, "__dataclass_fields__", None)
    if not allowed:
        return data
    return {k: v for k, v in data.items() if k in allowed}


class EmbeddingsResource:
    """Resource for embedding generation from documents."""
    
    def __init__(self, client: "DecompressedClient") -> None:
        self._client = client
    
    def create_source(
        self,
        source_type: str,
        uri: str,
        *,
        checksum: Optional[str] = None,
        content_type: Optional[str] = None,
        filename: Optional[str] = None,
        source_metadata: Optional[Dict[str, Any]] = None,
    ) -> SourceReference:
        """
        Create a typed source reference.
        
        Source references point to external content without storing raw data.
        
        Args:
            source_type: Type of source (s3, gcs, http, github, notion, etc.)
            uri: Full URI to the source
            checksum: Optional SHA256 checksum for verification
            content_type: MIME type
            filename: Original filename
            source_metadata: Additional source-specific metadata
        """
        data = {
            "source_type": source_type,
            "uri": uri,
            "checksum": checksum,
            "content_type": content_type,
            "filename": filename,
            "source_metadata": source_metadata or {},
        }
        resp = self._client.request("POST", "/api/v1/embeddings/sources", json=data)
        return SourceReference(**_filter_dataclass_kwargs(SourceReference, resp))
    
    def list_sources(
        self,
        source_type: Optional[str] = None,
        limit: int = 100,
    ) -> List[SourceReference]:
        """List source references."""
        params = []
        if source_type:
            params.append(f"source_type={source_type}")
        if limit != 100:
            params.append(f"limit={limit}")
        
        query = f"?{'&'.join(params)}" if params else ""
        resp = self._client.request("GET", f"/api/v1/embeddings/sources{query}")
        return [SourceReference(**_filter_dataclass_kwargs(SourceReference, s)) for s in resp]
    
    def get_source(self, source_id: str) -> SourceReference:
        """Get a specific source reference."""
        resp = self._client.request("GET", f"/api/v1/embeddings/sources/{source_id}")
        return SourceReference(**_filter_dataclass_kwargs(SourceReference, resp))
    
    def delete_source(self, source_id: str) -> None:
        """Delete a source reference."""
        self._client.request("DELETE", f"/api/v1/embeddings/sources/{source_id}")
    
    def create_job(
        self,
        source_ids: List[str],
        *,
        dataset_id: Optional[str] = None,
        dataset_name: Optional[str] = None,
        model: str = "text-embedding-004",
        dimensions: Optional[int] = None,
        chunk_size: int = 512,
        chunk_overlap: int = 50,
        chunking_strategy: str = "recursive",
    ) -> EmbeddingJob:
        """
        Create an embedding job to generate vectors from sources.
        
        Args:
            source_ids: List of source reference IDs to process
            dataset_id: Existing dataset ID to append to (optional)
            dataset_name: Name for new dataset (if dataset_id not provided)
            model: Embedding model (default: text-embedding-004)
            dimensions: Output dimensions (model default if not specified)
            chunk_size: Characters per chunk
            chunk_overlap: Overlap between chunks
            chunking_strategy: recursive, semantic, fixed, sentence, paragraph, page, none
        """
        data = {
            "source_ids": source_ids,
            "dataset_id": dataset_id,
            "dataset_name": dataset_name,
            "model": model,
            "dimensions": dimensions,
            "chunking": {
                "strategy": chunking_strategy,
                "chunk_size": chunk_size,
                "chunk_overlap": chunk_overlap,
            },
        }
        resp = self._client.request("POST", "/api/v1/embeddings/jobs", json=data)
        return EmbeddingJob(**_filter_dataclass_kwargs(EmbeddingJob, resp))
    
    def list_jobs(
        self,
        status: Optional[str] = None,
        dataset_id: Optional[str] = None,
        limit: int = 50,
    ) -> List[EmbeddingJob]:
        """List embedding jobs."""
        params = []
        if status:
            params.append(f"status_filter={status}")
        if dataset_id:
            params.append(f"dataset_id={dataset_id}")
        if limit != 50:
            params.append(f"limit={limit}")
        
        query = f"?{'&'.join(params)}" if params else ""
        resp = self._client.request("GET", f"/api/v1/embeddings/jobs{query}")
        return [EmbeddingJob(**_filter_dataclass_kwargs(EmbeddingJob, j)) for j in resp]
    
    def get_job(self, job_id: str) -> EmbeddingJobStatus:
        """Get detailed status of an embedding job."""
        resp = self._client.request("GET", f"/api/v1/embeddings/jobs/{job_id}")
        return EmbeddingJobStatus(**_filter_dataclass_kwargs(EmbeddingJobStatus, resp))
    
    def cancel_job(self, job_id: str) -> Dict[str, Any]:
        """Cancel a pending or processing embedding job."""
        return self._client.request("POST", f"/api/v1/embeddings/jobs/{job_id}/cancel")
    
    def upload_and_embed(
        self,
        file_path: Path,
        *,
        dataset_name: Optional[str] = None,
        model: str = "text-embedding-004",
        chunk_size: int = 512,
        chunk_overlap: int = 50,
        poll_interval: float = 2.0,
        max_wait: float = 300.0,
    ) -> EmbeddingJobStatus:
        """
        Upload a file and generate embeddings in one step.
        
        For files <10MB. Blocks until complete or timeout.
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Upload via multipart form
        with open(file_path, "rb") as f:
            files = {"file": (file_path.name, f)}
            data = {
                "dataset_name": dataset_name or file_path.name,
                "model": model,
                "chunk_size": str(chunk_size),
                "chunk_overlap": str(chunk_overlap),
            }
            
            headers = {}
            if self._client._auth:
                headers.update(self._client._auth.headers())
            
            resp = self._client._session.post(
                f"{self._client._base_url}/api/v1/embeddings/upload",
                files=files,
                data=data,
                headers=headers,
                timeout=self._client._timeout_seconds,
            )
            
            if resp.status_code >= 400:
                raise_for_status(resp.status_code, resp.json(), resp.headers.get("x-request-id"))
            
            job_data = resp.json()
        
        # Poll for completion
        job_id = job_data["id"]
        start_time = time.time()
        
        while time.time() - start_time < max_wait:
            status = self.get_job(job_id)
            if status.status in ["completed", "failed", "cancelled"]:
                return status
            time.sleep(poll_interval)
        
        raise TimeoutError(f"Embedding job {job_id} did not complete within {max_wait}s")
    
    def append_with_embedding(
        self,
        dataset_id: str,
        file_path: Path,
        *,
        model: str = "text-embedding-004",
        chunk_size: int = 512,
        chunk_overlap: int = 50,
        poll_interval: float = 2.0,
        max_wait: float = 300.0,
    ) -> EmbeddingJobStatus:
        """
        Upload a file and append generated embeddings to an existing dataset.
        
        The embedding dimensions will be automatically matched to the dataset's dimension.
        For files <10MB. Blocks until complete or timeout.
        
        Args:
            dataset_id: ID of the dataset to append to
            file_path: Path to the document file (PDF, DOCX, TXT, etc.)
            model: Embedding model (must support dataset's dimension)
            chunk_size: Characters per chunk
            chunk_overlap: Overlap between chunks
            poll_interval: Seconds between status checks
            max_wait: Maximum seconds to wait for completion
            
        Returns:
            EmbeddingJobStatus with final job state
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Upload via multipart form to append endpoint
        with open(file_path, "rb") as f:
            files = {"file": (file_path.name, f)}
            data = {
                "model": model,
                "chunk_size": str(chunk_size),
                "chunk_overlap": str(chunk_overlap),
            }
            
            headers = {}
            if self._client._auth:
                headers.update(self._client._auth.headers())
            
            resp = self._client._session.post(
                f"{self._client._base_url}/api/v1/embeddings/datasets/{dataset_id}/append",
                files=files,
                data=data,
                headers=headers,
                timeout=self._client._timeout_seconds,
            )
            
            if resp.status_code >= 400:
                raise_for_status(resp.status_code, resp.json(), resp.headers.get("x-request-id"))
            
            job_data = resp.json()
        
        # Poll for completion
        job_id = job_data["id"]
        start_time = time.time()
        
        while time.time() - start_time < max_wait:
            status = self.get_job(job_id)
            if status.status in ["completed", "failed", "cancelled"]:
                return status
            time.sleep(poll_interval)
        
        raise TimeoutError(f"Embedding append job {job_id} did not complete within {max_wait}s")
