"""Syncs resource with version-first design.

Syncs are always tied to a specific version for reproducibility.
Use sync.from_version(v) to create a sync from a CommittedVersion.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import DecompressedClient
    from .versions import CommittedVersion

from ..types.syncs import SyncJob, SyncResult, SyncValidation


def _filter_dataclass_kwargs(model: type, data: Dict[str, Any]) -> Dict[str, Any]:
    """Filter dict to only include fields defined in the dataclass."""
    allowed = getattr(model, "__dataclass_fields__", None)
    if not allowed:
        return data
    return {k: v for k, v in data.items() if k in allowed}


class SyncsResource:
    """
    Manage sync jobs to upload vectors to external services.
    
    Version-first design: syncs are always tied to a specific version.
    
    Example:
        # Sync from a specific version
        v = dataset.version(3)
        sync = client.syncs.from_version(v, connector_id="pinecone-prod")
        
        # Or auto-sync from "main" ref
        client.syncs.auto(
            source="dataset:main",
            destination="pinecone-prod"
        )
    """
    
    def __init__(self, client: "DecompressedClient") -> None:
        self._client = client
    
    def from_version(
        self,
        version: "CommittedVersion",
        connector_id: str,
        *,
        filters: Optional[Dict[str, Any]] = None,
        batch_size: int = 100,
        config: Optional[Dict[str, Any]] = None,
    ) -> SyncResult:
        """
        Create a sync job from a specific version.
        
        This is the preferred way to create syncs - it ensures the sync
        is tied to a specific, immutable version for reproducibility.
        
        Args:
            version: CommittedVersion to sync from
            connector_id: Connector ID to sync to
            filters: Optional metadata filters
            batch_size: Number of vectors per batch
            config: Additional sync configuration
            
        Returns:
            SyncResult with sync_job_id and source_version
        """
        return self.create(
            dataset_id=version.dataset_id,
            connector_id=connector_id,
            version=version.version,
            filters=filters,
            batch_size=batch_size,
            config=config,
        )

    def list(
        self,
        *,
        dataset_id: Optional[str] = None,
        connector_id: Optional[str] = None,
        status: Optional[str] = None,
    ) -> List[SyncJob]:
        """
        List sync jobs with optional filters.
        
        Args:
            dataset_id: Filter by dataset
            connector_id: Filter by connector
            status: Filter by status (pending, running, completed, failed, cancelled)
        """
        params = []
        if dataset_id:
            params.append(f"dataset_id={dataset_id}")
        if connector_id:
            params.append(f"connector_id={connector_id}")
        if status:
            params.append(f"status={status}")
        
        path = "/api/v1/syncs"
        if params:
            path = f"{path}?{'&'.join(params)}"
        
        data = self._client.request("GET", path)
        return [SyncJob(**_filter_dataclass_kwargs(SyncJob, item)) for item in data]

    def get(self, sync_job_id: str) -> SyncJob:
        """Get a sync job by ID."""
        data = self._client.request("GET", f"/api/v1/syncs/{sync_job_id}")
        return SyncJob(**_filter_dataclass_kwargs(SyncJob, data))

    def create(
        self,
        dataset_id: str,
        connector_id: str,
        *,
        version: Optional[int] = None,
        filters: Optional[Dict[str, Any]] = None,
        batch_size: int = 100,
        config: Optional[Dict[str, Any]] = None,
    ) -> SyncResult:
        """
        Create a sync job to upload vectors to a connector.
        
        Args:
            dataset_id: Dataset ID to sync from
            connector_id: Connector ID to sync to
            version: Specific version to sync (default: current version)
            filters: Optional metadata filters
            batch_size: Number of vectors per batch (default: 100)
            config: Additional sync configuration
            
        Returns:
            SyncResult with sync_job_id and source_version
        """
        payload: Dict[str, Any] = {
            "dataset_id": dataset_id,
            "connector_id": connector_id,
            "config": {"batch_size": batch_size, **(config or {})},
        }
        if version is not None:
            payload["source_version"] = version
        if filters:
            payload["filters"] = filters
        
        data = self._client.request("POST", "/api/v1/syncs", json=payload)
        return SyncResult(**_filter_dataclass_kwargs(SyncResult, data))

    def validate(
        self,
        dataset_id: str,
        connector_id: str,
        *,
        exclude_columns: Optional[List[str]] = None,
    ) -> SyncValidation:
        """
        Validate a sync before starting.
        
        Checks connection, dimension compatibility, and metadata validation.
        """
        payload = {
            "dataset_id": dataset_id,
            "connector_id": connector_id,
            "exclude_columns": exclude_columns or [],
        }
        data = self._client.request("POST", "/api/v1/syncs/validate", json=payload)
        return SyncValidation(**_filter_dataclass_kwargs(SyncValidation, data))

    def cancel(self, sync_job_id: str) -> Dict[str, Any]:
        """Cancel a running or pending sync job."""
        return self._client.request("POST", f"/api/v1/syncs/{sync_job_id}/cancel")

    def delete(self, sync_job_id: str) -> None:
        """Delete a completed/failed sync job."""
        self._client.request("DELETE", f"/api/v1/syncs/{sync_job_id}")

    def get_state(self, dataset_id: str) -> Dict[str, Any]:
        """Get sync state for all connectors linked to a dataset."""
        return self._client.request("GET", f"/api/v1/syncs/state/{dataset_id}")

    def set_auto_sync(
        self,
        dataset_id: str,
        connector_id: str,
        enabled: bool,
    ) -> Dict[str, Any]:
        """Enable or disable auto-sync for a dataset-connector pair."""
        return self._client.request(
            "PATCH",
            f"/api/v1/syncs/state/{dataset_id}/{connector_id}",
            json={"auto_sync_enabled": enabled},
        )
