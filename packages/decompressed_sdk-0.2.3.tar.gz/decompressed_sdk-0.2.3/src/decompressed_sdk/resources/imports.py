"""Imports resource for pulling vectors from external databases.

Supports importing vectors from Pinecone, Qdrant, and other vector databases
into Decompressed datasets.
"""

from __future__ import annotations

import time
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import DecompressedClient

from ..types.imports import ImportSession, ImportJob, ImportResult


def _filter_dataclass_kwargs(model: type, data: Dict[str, Any]) -> Dict[str, Any]:
    """Filter dict to only include fields defined in the dataclass."""
    allowed = getattr(model, "__dataclass_fields__", None)
    if not allowed:
        return data
    return {k: v for k, v in data.items() if k in allowed}


class ImportsResource:
    """
    Import vectors from external vector databases into Decompressed.
    
    Supports pulling from Pinecone, Qdrant, and other connectors.
    
    Example:
        # Import from Pinecone to new dataset
        session = client.imports.init(
            connector_id="pinecone-prod",
            dataset_name="imported-vectors"
        )
        print(f"Found {session.estimated_vectors} vectors")
        
        # Start the import
        result = client.imports.start(session.import_session_id)
        
        # Wait for completion
        final = client.imports.wait(session.import_session_id)
        print(f"Imported to dataset: {final.dataset_id}")
    """
    
    def __init__(self, client: "DecompressedClient") -> None:
        self._client = client

    def init(
        self,
        connector_id: str,
        dataset_name: str,
        *,
        project: Optional[str] = None,
        storage_config_id: Optional[str] = None,
        include_metadata: bool = True,
        batch_size: int = 100,
    ) -> ImportSession:
        """
        Initialize an import from an external vector database.
        
        Tests the connection and returns estimated vector count.
        
        Args:
            connector_id: Connector ID or name to import from
            dataset_name: Name for the new dataset
            project: Project name or ID (optional)
            storage_config_id: Storage config ID (optional, uses default)
            include_metadata: Whether to import metadata (default: True)
            batch_size: Vectors per batch during import (default: 100)
            
        Returns:
            ImportSession with session ID and estimated vectors
            
        Raises:
            ValidationError: If connector not found or connection fails
        """
        payload: Dict[str, Any] = {
            "connector_id": connector_id,
            "dataset_name": dataset_name,
            "include_metadata": include_metadata,
            "batch_size": batch_size,
        }
        if project:
            payload["project"] = project
        if storage_config_id:
            payload["storage_config_id"] = storage_config_id
        
        data = self._client.request("POST", "/api/v1/imports/init", json=payload)
        return ImportSession(**_filter_dataclass_kwargs(ImportSession, data))

    def init_append(
        self,
        connector_id: str,
        dataset_id: str,
        *,
        include_metadata: bool = True,
        batch_size: int = 100,
    ) -> ImportSession:
        """
        Initialize an import to append to an existing dataset.
        
        Args:
            connector_id: Connector ID or name to import from
            dataset_id: Existing dataset ID to append to
            include_metadata: Whether to import metadata (default: True)
            batch_size: Vectors per batch during import (default: 100)
            
        Returns:
            ImportSession with session ID and estimated vectors
            
        Raises:
            ValidationError: If dimension mismatch or connection fails
        """
        payload = {
            "connector_id": connector_id,
            "dataset_id": dataset_id,
            "include_metadata": include_metadata,
            "batch_size": batch_size,
        }
        
        data = self._client.request("POST", "/api/v1/imports/append/init", json=payload)
        return ImportSession(**_filter_dataclass_kwargs(ImportSession, data))

    def start(self, import_session_id: str) -> ImportResult:
        """
        Start the import job.
        
        Returns immediately with job ID. Use `status()` or `wait()` to track.
        
        Args:
            import_session_id: Session ID from init()
            
        Returns:
            ImportResult with job_id for tracking
        """
        data = self._client.request(
            "POST", 
            f"/api/v1/imports/{import_session_id}/complete",
            json={}
        )
        return ImportResult(**_filter_dataclass_kwargs(ImportResult, data))

    def status(self, import_session_id: str) -> ImportJob:
        """
        Get current status of an import job.
        
        Args:
            import_session_id: Session ID from init()
            
        Returns:
            ImportJob with current status and progress
        """
        data = self._client.request("GET", f"/api/v1/imports/{import_session_id}")
        return ImportJob(**_filter_dataclass_kwargs(ImportJob, data))

    def wait(
        self,
        import_session_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: Optional[float] = None,
        progress_callback: Optional[callable] = None,
    ) -> ImportJob:
        """
        Wait for an import job to complete.
        
        Args:
            import_session_id: Session ID from init()
            poll_interval: Seconds between status checks (default: 2)
            timeout: Maximum seconds to wait (optional)
            progress_callback: Called with ImportJob on each poll (optional)
            
        Returns:
            Final ImportJob status
            
        Raises:
            TimeoutError: If timeout exceeded
            DecompressedError: If import fails
        """
        start_time = time.time()
        
        while True:
            job = self.status(import_session_id)
            
            if progress_callback:
                progress_callback(job)
            
            if job.status in ("completed", "failed"):
                if job.status == "failed":
                    from ..errors import DecompressedError
                    raise DecompressedError(
                        f"Import failed: {job.error_message or 'Unknown error'}",
                        status_code=500
                    )
                return job
            
            if timeout and (time.time() - start_time) > timeout:
                raise TimeoutError(f"Import did not complete within {timeout} seconds")
            
            time.sleep(poll_interval)

    def from_connector(
        self,
        connector_id: str,
        dataset_name: str,
        *,
        project: Optional[str] = None,
        include_metadata: bool = True,
        wait: bool = True,
        progress_callback: Optional[callable] = None,
    ) -> ImportJob:
        """
        Convenience method: import from connector and optionally wait.
        
        Args:
            connector_id: Connector ID or name
            dataset_name: Name for new dataset
            project: Project name or ID (optional)
            include_metadata: Import metadata (default: True)
            wait: Wait for completion (default: True)
            progress_callback: Progress callback if waiting
            
        Returns:
            Final ImportJob status
            
        Example:
            job = client.imports.from_connector(
                "pinecone-prod",
                "backup-2024-01",
                wait=True
            )
            print(f"Imported {job.dataset_id}")
        """
        session = self.init(
            connector_id=connector_id,
            dataset_name=dataset_name,
            project=project,
            include_metadata=include_metadata,
        )
        
        self.start(session.import_session_id)
        
        if wait:
            return self.wait(
                session.import_session_id,
                progress_callback=progress_callback,
            )
        
        return self.status(session.import_session_id)
