"""Version-first dataset operations resource.

Core mental model:
- Dataset = history (immutable log of versions)
- Version = reality (the thing you operate on)

Two version types:
- DraftVersion: Mutable staging area before commit
- CommittedVersion: Immutable, addressable forever
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, TYPE_CHECKING
from urllib.parse import quote

if TYPE_CHECKING:
    from ..client import DecompressedClient

from ..types.datasets import DatasetInfo, DatasetQueryResponse
from ..types.search import SearchMatch, SearchResponse
from ..types.versions import VersionInfo, VersionComparison


def _filter_dataclass_kwargs(model: type, data: Dict[str, Any]) -> Dict[str, Any]:
    """Filter dict to only include fields defined in the dataclass."""
    allowed = getattr(model, "__dataclass_fields__", None)
    if not allowed:
        return data
    return {k: v for k, v in data.items() if k in allowed}


class DraftVersion:
    """
    A mutable draft version (staging area).
    
    Drafts can be mutated with add_vectors(), remove(), etc.
    Once you call commit(), the draft becomes a CommittedVersion
    and is immutable forever.
    
    Example:
        v = dataset.new_version(description="Add Feb tickets")
        v.add_vectors(vectors, metadata)
        v.remove(filter={"source": "old_import"})
        committed = v.commit()
        committed.promote("main")
    """
    
    def __init__(
        self,
        client: "DecompressedClient",
        dataset_id: str,
        draft_id: str,
        parent_version: int,
        description: Optional[str] = None,
    ) -> None:
        self._client = client
        self._dataset_id = dataset_id
        self._draft_id = draft_id
        self._parent_version = parent_version
        self._description = description
        self._committed = False
        self._committed_version: Optional[int] = None
    
    @classmethod
    def _create(
        cls,
        client: "DecompressedClient",
        dataset_id: str,
        parent_version: int,
        description: Optional[str] = None,
    ) -> "DraftVersion":
        """Create a new draft version via API."""
        path = f"/api/v1/datasets/{quote(dataset_id)}/versions/draft"
        data = client.request("POST", path, json={
            "parent_version": parent_version,
            "description": description,
        })
        return cls(
            client=client,
            dataset_id=dataset_id,
            draft_id=data["draft_id"],
            parent_version=parent_version,
            description=description,
        )
    
    @property
    def draft_id(self) -> str:
        return self._draft_id
    
    @property
    def parent_version(self) -> int:
        return self._parent_version
    
    def add_vectors(
        self,
        vectors: List[List[float]],
        metadata: Optional[List[Dict[str, Any]]] = None,
        ids: Optional[List[str]] = None,
    ) -> "DraftVersion":
        """Add vectors to this draft version. Returns self for chaining."""
        if self._committed:
            raise RuntimeError("Cannot modify a committed version")
        
        path = f"/api/v1/datasets/{quote(self._dataset_id)}/versions/draft/{quote(self._draft_id)}/vectors"
        self._client.request("POST", path, json={
            "vectors": vectors,
            "metadata": metadata,
            "ids": ids,
        })
        return self
    
    def remove(
        self,
        filter: Optional[Dict[str, Any]] = None,
        ids: Optional[List[str]] = None,
    ) -> "DraftVersion":
        """Remove vectors from this draft version. Returns self for chaining."""
        if self._committed:
            raise RuntimeError("Cannot modify a committed version")
        if not filter and not ids:
            raise ValueError("Must provide either filter or ids")
        
        path = f"/api/v1/datasets/{quote(self._dataset_id)}/versions/draft/{quote(self._draft_id)}/vectors"
        self._client.request("DELETE", path, json={"filter": filter, "ids": ids})
        return self
    
    def commit(self, description: Optional[str] = None) -> "CommittedVersion":
        """Commit this draft, making it immutable forever."""
        if self._committed:
            raise RuntimeError("Already committed")
        
        path = f"/api/v1/datasets/{quote(self._dataset_id)}/versions/draft/{quote(self._draft_id)}/commit"
        data = self._client.request("POST", path, json={
            "description": description or self._description,
        })
        
        self._committed = True
        self._committed_version = data["version"]
        
        return CommittedVersion(self._client, self._dataset_id, self._committed_version)
    
    def discard(self) -> None:
        """Discard this draft without committing."""
        if self._committed:
            raise RuntimeError("Cannot discard a committed version")
        path = f"/api/v1/datasets/{quote(self._dataset_id)}/versions/draft/{quote(self._draft_id)}"
        self._client.request("DELETE", path)
    
    def __repr__(self) -> str:
        status = "committed" if self._committed else "draft"
        return f"DraftVersion(dataset={self._dataset_id!r}, draft_id={self._draft_id!r}, status={status})"


class CommittedVersion:
    """
    An immutable committed version.
    
    All query/search/export operations use this specific version,
    ensuring reproducible results.
    
    Example:
        v = dataset.version(3)
        info = v.info()
        results = v.search([[0.1, 0.2, 0.3]], top_k=10)
        v.promote("main")
    """
    
    def __init__(
        self,
        client: "DecompressedClient",
        dataset_id: str,
        version: int,
    ) -> None:
        self._client = client
        self._dataset_id = dataset_id
        self._version = version
    
    @classmethod
    def _from_ref(cls, client: "DecompressedClient", dataset_id: str, ref_name: str) -> "CommittedVersion":
        """Get version from a named ref."""
        path = f"/api/v1/datasets/{quote(dataset_id)}/refs/{quote(ref_name)}"
        data = client.request("GET", path)
        return cls(client, dataset_id, data["version"])
    
    @classmethod
    def _from_timestamp(cls, client: "DecompressedClient", dataset_id: str, timestamp: str) -> "CommittedVersion":
        """Get version at a specific timestamp."""
        path = f"/api/v1/datasets/{quote(dataset_id)}/at?timestamp={quote(timestamp)}"
        data = client.request("GET", path)
        return cls(client, dataset_id, data["version"])
    
    @property
    def version(self) -> int:
        return self._version
    
    @property
    def dataset_id(self) -> str:
        return self._dataset_id
    
    def info(self) -> DatasetInfo:
        """Get detailed info about this version."""
        path = f"/api/v1/datasets/{quote(self._dataset_id)}/info?version={self._version}"
        data = self._client.request("GET", path)
        return DatasetInfo(**_filter_dataclass_kwargs(DatasetInfo, data))
    
    def query(
        self,
        filters: Optional[Dict[str, Any]] = None,
        *,
        load_vectors: bool = False,
    ) -> DatasetQueryResponse:
        """Query metadata for vectors matching filters at this version."""
        path = f"/api/v1/datasets/{quote(self._dataset_id)}/query?version={self._version}"
        if load_vectors:
            path += "&load_vectors=true"
        data = self._client.request("POST", path, json=filters)
        return DatasetQueryResponse(**_filter_dataclass_kwargs(DatasetQueryResponse, data))
    
    def search(
        self,
        query_vectors: List[List[float]],
        *,
        top_k: int = 10,
        filters: Optional[Dict[str, Any]] = None,
        materialization_id: Optional[str] = None,
        metric: str = "cosine",
    ) -> SearchResponse:
        """Search for similar vectors at this version."""
        path = f"/api/v1/datasets/{quote(self._dataset_id)}/search"
        body = {
            "query_vectors": query_vectors,
            "top_k": top_k,
            "metric": metric,
            "version": self._version,
        }
        if filters:
            body["filters"] = filters
        if materialization_id:
            body["materialization_id"] = materialization_id
        
        data = self._client.request("POST", path, json=body)
        
        raw_matches = data.get("matches", [])
        if raw_matches and isinstance(raw_matches[0], dict):
            matches = [SearchMatch(**_filter_dataclass_kwargs(SearchMatch, m)) for m in raw_matches]
        else:
            matches = []
            for query_matches in raw_matches:
                matches.extend([SearchMatch(**_filter_dataclass_kwargs(SearchMatch, m)) for m in query_matches])
        
        return SearchResponse(
            matches=matches,
            num_queries=data.get("num_queries", 1),
            search_method=data.get("search_method", "unknown"),
            num_vectors_searched=data.get("num_vectors_searched"),
            metric=data.get("metric"),
            materialization_id=data.get("materialization_id"),
            message=data.get("message"),
            warning=data.get("warning"),
            version=self._version,
        )
    
    def version_info(self) -> VersionInfo:
        """Get detailed information about this specific version."""
        path = f"/api/v1/datasets/{quote(self._dataset_id)}/versions/{self._version}"
        data = self._client.request("GET", path)
        return VersionInfo(**_filter_dataclass_kwargs(VersionInfo, data))
    
    def compare_to(self, other_version: int) -> VersionComparison:
        """Compare this version to another version."""
        path = f"/api/v1/datasets/{quote(self._dataset_id)}/versions/compare"
        body = {"version_a": self._version, "version_b": other_version}
        data = self._client.request("POST", path, json=body)
        return VersionComparison(**_filter_dataclass_kwargs(VersionComparison, data))
    
    def promote(self, ref: str = "main") -> None:
        """
        Promote this version to a named ref.
        
        Named refs are like git branches - they point to a specific version.
        Common refs: "main", "prod", "staging"
        """
        path = f"/api/v1/datasets/{quote(self._dataset_id)}/refs/{quote(ref)}"
        self._client.request("PUT", path, json={"version": self._version})
    
    def rollback(self, description: Optional[str] = None) -> "DraftVersion":
        """
        Create a new draft version that reverts to this version's state.
        
        This doesn't modify history - it creates a new version based on this one.
        """
        from ..types.versions import Dataset
        # Get the dataset to access new_version
        path = f"/api/v1/datasets/{quote(self._dataset_id)}"
        data = self._client.request("GET", path)
        
        # Create draft based on this version
        draft_path = f"/api/v1/datasets/{quote(self._dataset_id)}/versions/draft"
        draft_data = self._client.request("POST", draft_path, json={
            "parent_version": self._version,
            "description": description or f"Rollback to v{self._version}",
        })
        
        return DraftVersion(
            client=self._client,
            dataset_id=self._dataset_id,
            draft_id=draft_data["draft_id"],
            parent_version=self._version,
            description=description,
        )
    
    def materialize(
        self,
        name: str,
        type: str,
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Create a materialization of this version.
        
        Materializations are immutable views tied to this specific version.
        
        Args:
            name: Unique name for this materialization
            type: 'index', 'export', or 'view'
            config: Materialization config (e.g., {"compression": "int8"})
        """
        path = f"/api/v1/datasets/{quote(self._dataset_id)}/materializations"
        return self._client.request("POST", path, json={
            "name": name,
            "type": type,
            "config": config,
            "source_version": self._version,
        })
    
    def __repr__(self) -> str:
        return f"CommittedVersion(dataset={self._dataset_id!r}, version={self._version})"


# Backward compatibility alias
VersionedDatasetResource = CommittedVersion
