"""Connectors resource."""

from __future__ import annotations

from typing import Any, Dict, List, TYPE_CHECKING

if TYPE_CHECKING:
    from ..client import DecompressedClient

from ..types.connectors import Connector


def _filter_dataclass_kwargs(model: type, data: Dict[str, Any]) -> Dict[str, Any]:
    """Filter dict to only include fields defined in the dataclass."""
    allowed = getattr(model, "__dataclass_fields__", None)
    if not allowed:
        return data
    return {k: v for k, v in data.items() if k in allowed}


class ConnectorsResource:
    """Manage connectors (vector databases, external services)."""
    
    def __init__(self, client: "DecompressedClient") -> None:
        self._client = client

    def list(self) -> List[Connector]:
        """List all connectors."""
        data = self._client.request("GET", "/api/v1/connectors")
        return [Connector(**_filter_dataclass_kwargs(Connector, item)) for item in data]

    def get(self, connector_id: str) -> Connector:
        """Get a connector by ID."""
        data = self._client.request("GET", f"/api/v1/connectors/{connector_id}")
        return Connector(**_filter_dataclass_kwargs(Connector, data))

    def test(self, connector_id: str) -> Dict[str, Any]:
        """Test a connector's connection."""
        return self._client.request("POST", f"/api/v1/connectors/{connector_id}/test")
