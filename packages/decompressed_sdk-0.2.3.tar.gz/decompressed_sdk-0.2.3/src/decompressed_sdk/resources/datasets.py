"""Datasets resource with version-first design.

Core mental model:
- Dataset = history (immutable log of versions)
- Version = reality (the thing you operate on)

Nothing meaningful happens without a version.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, TYPE_CHECKING
from urllib.parse import quote

import requests

if TYPE_CHECKING:
    from ..client import DecompressedClient

from ..types.datasets import (
    DatasetInfo,
    DatasetQueryResponse,
    UploadSession,
    AppendSession,
    JobStatus,
    UploadResult,
    AppendResult,
)
from ..types.versions import Dataset, DatasetEvent
from .versions import CommittedVersion, DraftVersion


def _filter_dataclass_kwargs(model: type, data: Dict[str, Any]) -> Dict[str, Any]:
    """Filter dict to only include fields defined in the dataclass."""
    allowed = getattr(model, "__dataclass_fields__", None)
    if not allowed:
        return data
    return {k: v for k, v in data.items() if k in allowed}


class DatasetsResource:
    """
    Datasets resource with version-first design.
    
    A dataset is history - an immutable log of versions.
    Use dataset.new_version() to create a draft, mutate it, then commit().
    
    Example:
        # Get dataset (history)
        dataset = dc.datasets.get("support-docs")
        
        # Create a new version (staging area)
        v = dataset.new_version(description="Add Feb tickets")
        v.add_vectors(vectors, metadata)
        v.remove(filter={"source": "old_import"})
        committed = v.commit()
        
        # Promote to a named ref
        committed.promote("main")
        
        # Query at a specific version
        v3 = dataset.version(3)
        results = v3.search([[0.1, 0.2, 0.3]])
    """
    
    def __init__(self, client: "DecompressedClient") -> None:
        self._client = client
    
    def list(self) -> List[Dataset]:
        """List all datasets for the current user."""
        data = self._client.request("GET", "/api/v1/datasets")
        datasets = []
        for item in data:
            ds = Dataset(
                id=item["id"],
                name=item["name"],
                current_version=item.get("current_version", 1),
                num_vectors=item.get("num_vectors"),
                dimensions=item.get("dimensions") or item.get("dimension"),
                created_at=item.get("created_at"),
                updated_at=item.get("updated_at"),
            )
            ds._client = self._client
            datasets.append(ds)
        return datasets
    
    def get(self, dataset: str, *, project: Optional[str] = None) -> Dataset:
        """
        Get a dataset by name or ID.
        
        A dataset is history - use .new_version() to create changes,
        or .version(n) / .ref("main") to query at a specific version.
        
        Args:
            dataset: Dataset name or ID
            project: Project name or ID (required if name is ambiguous)
            
        Returns:
            Dataset for version-first operations
            
        Example:
            dataset = dc.datasets.get("support-docs")
            v = dataset.new_version(description="Add Feb tickets")
            v.add_vectors(vectors, metadata)
            committed = v.commit()
            committed.promote("main")
        """
        path = f"/api/v1/datasets/{quote(dataset)}"
        if project:
            path = f"{path}?project={quote(project)}"
        data = self._client.request("GET", path)
        
        ds = Dataset(
            id=data["id"],
            name=data["name"],
            current_version=data.get("current_version", 1),
            num_vectors=data.get("num_vectors"),
            dimensions=data.get("dimensions") or data.get("dimension"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )
        ds._client = self._client
        return ds
    
    def delete(
        self,
        dataset: str,
        *,
        project: Optional[str] = None,
        delete_file: bool = False,
    ) -> None:
        """Delete dataset by name or ID."""
        path = f"/api/v1/datasets/{quote(dataset)}"
        params = []
        if project:
            params.append(f"project={quote(project)}")
        if delete_file:
            params.append("delete_file=true")
        if params:
            path = f"{path}?{'&'.join(params)}"
        self._client.request("DELETE", path)
    
    def history(
        self,
        dataset: str,
        *,
        limit: int = 50,
        cursor: Optional[str] = None,
    ) -> List[DatasetEvent]:
        """
        Get activity history for a dataset.
        
        Returns events in reverse chronological order (newest first).
        
        Args:
            dataset: Dataset name or ID
            limit: Maximum events to return
            cursor: Pagination cursor
            
        Returns:
            List of DatasetEvent objects
        """
        path = f"/api/v1/datasets/{quote(dataset)}/history?limit={limit}"
        if cursor:
            path = f"{path}&cursor={quote(cursor)}"
        data = self._client.request("GET", path)
        events = data.get("events", [])
        return [DatasetEvent(**_filter_dataclass_kwargs(DatasetEvent, e)) for e in events]
    
    def upload(
        self,
        file_path: Union[str, Path],
        name: str,
        *,
        project: Optional[str] = None,
        compression: Optional[str] = None,
        block_size: int = 100_000,
        user_metadata: Optional[Dict[str, Any]] = None,
        storage_config_id: Optional[str] = None,
        poll_interval: float = 2.0,
        max_wait: float = 600.0,
    ) -> UploadResult:
        """
        Upload a new dataset file.
        
        Args:
            file_path: Path to the file to upload
            name: Name for the dataset
            project: Project name or ID
            compression: Compression type (fp16, int8, binary, etc.)
            block_size: Number of vectors per block
            user_metadata: Optional metadata dict
            storage_config_id: Optional storage config ID
            poll_interval: Seconds between status polls
            max_wait: Maximum seconds to wait for completion
            
        Returns:
            UploadResult with dataset_id, job_id, and upload_session_id
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        file_size = file_path.stat().st_size
        file_extension = file_path.suffix.lstrip('.')
        
        # Step 1: Initialize upload session
        init_payload: Dict[str, Any] = {
            "name": name,
            "file_extension": file_extension,
            "file_size_bytes": file_size,
            "block_size": block_size,
        }
        if project:
            init_payload["project"] = project
        if compression:
            init_payload["compression"] = compression
        if user_metadata:
            init_payload["user_metadata"] = user_metadata
        if storage_config_id:
            init_payload["storage_config_id"] = storage_config_id
        
        init_data = self._client.request("POST", "/api/v1/datasets/uploads/init", json=init_payload)
        session = UploadSession(**_filter_dataclass_kwargs(UploadSession, init_data))
        
        # Step 2: Upload file to presigned URL
        with open(file_path, 'rb') as f:
            upload_response = requests.put(
                session.upload_url,
                data=f,
                headers={"Content-Type": "application/octet-stream"},
            )
            upload_response.raise_for_status()
        
        # Step 3: Mark upload complete
        complete_data = self._client.request(
            "POST",
            f"/api/v1/datasets/uploads/{session.upload_session_id}/complete",
            json={},
        )
        job_id = complete_data["job_id"]
        
        # Step 4: Poll for completion
        start_time = time.time()
        while time.time() - start_time < max_wait:
            status_data = self._client.request(
                "GET",
                f"/api/v1/datasets/uploads/{session.upload_session_id}",
            )
            status = JobStatus(**_filter_dataclass_kwargs(JobStatus, status_data))
            
            if status.job_status == "succeeded":
                return UploadResult(
                    dataset_id=session.dataset_id or (status.result or {}).get("dataset_id", ""),
                    job_id=job_id,
                    upload_session_id=session.upload_session_id,
                )
            
            if status.job_status == "failed":
                raise RuntimeError(f"Upload failed: {status.error_message}")
            
            time.sleep(poll_interval)
        
        raise TimeoutError(f"Upload did not complete within {max_wait} seconds")
    
    def append(
        self,
        dataset: str,
        file_path: Union[str, Path],
        *,
        project: Optional[str] = None,
        compression: Optional[str] = None,
        block_size: int = 100_000,
        user_metadata: Optional[Dict[str, Any]] = None,
        description: Optional[str] = None,
        poll_interval: float = 2.0,
        max_wait: float = 600.0,
    ) -> AppendResult:
        """
        Append vectors to an existing dataset.
        
        Creates a new version of the dataset.
        
        Args:
            dataset: Dataset name or ID
            file_path: Path to the file to append
            project: Project name or ID
            compression: Compression type
            block_size: Number of vectors per block
            user_metadata: Optional metadata dict
            description: Commit message for this version (shown in version history)
            poll_interval: Seconds between status polls
            max_wait: Maximum seconds to wait for completion
            
        Returns:
            AppendResult with version info
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        file_size = file_path.stat().st_size
        file_extension = file_path.suffix.lstrip('.')
        
        # Step 1: Initialize append session
        init_payload: Dict[str, Any] = {
            "dataset": dataset,
            "file_extension": file_extension,
            "file_size_bytes": file_size,
            "block_size": block_size,
        }
        if project:
            init_payload["project"] = project
        if compression:
            init_payload["compression"] = compression
        if user_metadata:
            init_payload["user_metadata"] = user_metadata
        if description:
            init_payload["description"] = description
        
        init_data = self._client.request(
            "POST",
            f"/api/v1/datasets/{quote(dataset)}/append/init",
            json=init_payload,
        )
        session = AppendSession(**_filter_dataclass_kwargs(AppendSession, init_data))
        dataset_id = session.dataset_id or dataset
        
        # Step 2: Upload file to presigned URL
        with open(file_path, 'rb') as f:
            upload_response = requests.put(
                session.upload_url,
                data=f,
                headers={"Content-Type": "application/octet-stream"},
            )
            upload_response.raise_for_status()
        
        # Step 3: Mark append complete
        complete_data = self._client.request(
            "POST",
            f"/api/v1/datasets/{quote(dataset)}/append/{session.append_session_id}/complete",
            json={},
        )
        job_id = complete_data["job_id"]
        
        # Step 4: Poll for completion
        start_time = time.time()
        while time.time() - start_time < max_wait:
            status_data = self._client.request(
                "GET",
                f"/api/v1/datasets/{quote(dataset)}/append/{session.append_session_id}",
            )
            status = JobStatus(**_filter_dataclass_kwargs(JobStatus, status_data))
            
            if status.job_status == "succeeded":
                result = status.result or {}
                return AppendResult(
                    dataset_id=dataset_id,
                    job_id=job_id,
                    append_session_id=session.append_session_id,
                    previous_version=result.get("previous_version"),
                    new_version=result.get("new_version"),
                )
            
            if status.job_status == "failed":
                raise RuntimeError(f"Append failed: {status.error_message}")
            
            time.sleep(poll_interval)
        
        raise TimeoutError(f"Append did not complete within {max_wait} seconds")
    
    def update_vectors(
        self,
        dataset: str,
        vector_ids: List[int],
        new_metadata: Dict[str, Any],
        *,
        project: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Update metadata for specific vectors in a dataset.
        
        Args:
            dataset: Dataset name or ID
            vector_ids: List of vector IDs to update (max 1000)
            new_metadata: New metadata values to set
            project: Project name or ID
            
        Returns:
            Dict with affected_vectors, modified_blocks, operation_id
            
        Example:
            result = client.datasets.update_vectors(
                "my-dataset",
                vector_ids=[1, 2, 3],
                new_metadata={"category": "updated", "reviewed": True}
            )
            print(f"Updated {result['affected_vectors']} vectors")
        """
        if len(vector_ids) > 1000:
            raise ValueError("Maximum 1000 vectors per update request")
        
        path = f"/api/v1/datasets/{quote(dataset)}/vectors/update"
        if project:
            path += f"?project={quote(project)}"
        
        payload = {
            "vector_ids": vector_ids,
            "new_metadata": new_metadata,
            "operation_type": "metadata_only"
        }
        
        return self._client.request("PATCH", path, json=payload)
    
    def delete_vectors(
        self,
        dataset: str,
        vector_ids: List[int],
        *,
        project: Optional[str] = None,
        confirm: bool = False,
    ) -> Dict[str, Any]:
        """
        Permanently delete vectors from a dataset.
        
        WARNING: This action cannot be undone. Vectors are immediately removed.
        
        Args:
            dataset: Dataset name or ID
            vector_ids: List of vector IDs to delete (max 5000)
            project: Project name or ID
            confirm: Must be True to proceed (safety check)
            
        Returns:
            Dict with deleted_vectors, storage_freed_mb, operation_id
            
        Example:
            result = client.datasets.delete_vectors(
                "my-dataset",
                vector_ids=[1, 2, 3],
                confirm=True
            )
            print(f"Deleted {result['deleted_vectors']} vectors")
        """
        if not confirm:
            raise ValueError("Must set confirm=True to delete vectors. This action cannot be undone.")
        
        if len(vector_ids) > 5000:
            raise ValueError("Maximum 5000 vectors per delete request")
        
        path = f"/api/v1/datasets/{quote(dataset)}/vectors/delete"
        if project:
            path += f"?project={quote(project)}"
        
        payload = {
            "vector_ids": vector_ids,
            "confirmation": "DELETE"
        }
        
        return self._client.request("DELETE", path, json=payload)
    
    def iter_blocks(
        self,
        dataset: str,
        *,
        project: Optional[str] = None,
        version: Optional[int] = None,
        shuffle: bool = False,
        include_metadata: bool = True,
        prefetch: bool = True,
    ):
        """
        Iterate through dataset blocks for ML training.
        
        Yields blocks one at a time, suitable for large datasets that don't fit in memory.
        Each block contains ~100K vectors.
        
        Args:
            dataset: Dataset name or ID
            project: Project name or ID
            version: Specific version (default: latest)
            shuffle: Shuffle block order (useful for training)
            include_metadata: Include per-vector metadata
            prefetch: Prefetch next block while processing current (faster but uses more memory)
            
        Yields:
            BlockData objects with .vectors (numpy array) and .metadata (list of dicts)
            
        Example:
            # Basic iteration
            for block in client.datasets.iter_blocks("my-dataset"):
                print(f"Block {block.block_id}: {len(block.vectors)} vectors")
                
            # With PyTorch DataLoader
            for block in client.datasets.iter_blocks("my-dataset", shuffle=True):
                loader = DataLoader(block.vectors, batch_size=32)
                for batch in loader:
                    train_step(batch)
        """
        from ..types.datasets import BlockData
        import random
        import numpy as np
        from concurrent.futures import ThreadPoolExecutor
        from io import BytesIO
        
        # Get block list
        path = f"/api/v1/datasets/{quote(dataset)}/blocks"
        params = []
        if project:
            params.append(f"project={quote(project)}")
        if version:
            params.append(f"version={version}")
        if params:
            path = f"{path}?{'&'.join(params)}"
        
        data = self._client.request("GET", path)
        blocks = data.get("blocks", [])
        
        if not blocks:
            return
        
        # Shuffle if requested
        if shuffle:
            blocks = blocks.copy()
            random.shuffle(blocks)
        
        def fetch_block(block_info: dict) -> tuple:
            """Fetch block vectors and optionally metadata."""
            block_id = block_info["block_id"]
            
            # Download vectors
            download_path = f"/api/v1/datasets/{quote(dataset)}/blocks/{block_id}/download?format=npy"
            if project:
                download_path += f"&project={quote(project)}"
            
            response = self._client.request_raw("GET", download_path)
            vectors = np.load(BytesIO(response.content))
            
            # Download metadata if requested
            metadata = None
            if include_metadata:
                try:
                    meta_path = f"/api/v1/datasets/{quote(dataset)}/blocks/{block_id}/metadata"
                    if project:
                        meta_path += f"?project={quote(project)}"
                    if version:
                        meta_path += f"{'&' if project else '?'}version={version}"
                    meta_data = self._client.request("GET", meta_path)
                    metadata = meta_data.get("metadata", [])
                except Exception:
                    metadata = [{} for _ in range(len(vectors))]
            else:
                metadata = [{} for _ in range(len(vectors))]
            
            return block_id, vectors, metadata
        
        if prefetch and len(blocks) > 1:
            # Prefetch next block while processing current
            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(fetch_block, blocks[0])
                
                for i, block_info in enumerate(blocks):
                    # Get current block (from prefetch or direct)
                    block_id, vectors, metadata = future.result()
                    
                    # Start prefetching next block
                    if i + 1 < len(blocks):
                        future = executor.submit(fetch_block, blocks[i + 1])
                    
                    yield BlockData(
                        block_id=block_id,
                        vectors=vectors,
                        metadata=metadata,
                        num_vectors=len(vectors),
                        block_index=i,
                        total_blocks=len(blocks),
                    )
        else:
            # Simple sequential iteration
            for i, block_info in enumerate(blocks):
                block_id, vectors, metadata = fetch_block(block_info)
                yield BlockData(
                    block_id=block_id,
                    vectors=vectors,
                    metadata=metadata,
                    num_vectors=len(vectors),
                    block_index=i,
                    total_blocks=len(blocks),
                )
