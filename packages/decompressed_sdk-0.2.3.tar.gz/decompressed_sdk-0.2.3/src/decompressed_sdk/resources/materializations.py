"""Materializations resource."""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, TYPE_CHECKING
from urllib.parse import quote

if TYPE_CHECKING:
    from ..client import DecompressedClient

from ..types.materializations import (
    Materialization,
    CreateMaterializationResponse,
    MaterializationEstimate,
    MaterializationDownloadFile,
    MaterializationDownloadResponse,
)


def _filter_dataclass_kwargs(model: type, data: Dict[str, Any]) -> Dict[str, Any]:
    """Filter dict to only include fields defined in the dataclass."""
    allowed = getattr(model, "__dataclass_fields__", None)
    if not allowed:
        return data
    return {k: v for k, v in data.items() if k in allowed}


class MaterializationsResource:
    """Manage materializations for a specific dataset."""

    def __init__(self, client: "DecompressedClient", dataset_id: str) -> None:
        self._client = client
        self._dataset_id = dataset_id

    def _path(self, suffix: str = "") -> str:
        return f"/api/v1/datasets/{quote(self._dataset_id)}/materializations{suffix}"

    def list(self) -> List[Materialization]:
        """List all materializations for this dataset."""
        data = self._client.request("GET", self._path())
        return [Materialization(**_filter_dataclass_kwargs(Materialization, m)) for m in data]

    def get(self, materialization_id: str) -> Materialization:
        """Get a specific materialization by ID."""
        data = self._client.request("GET", self._path(f"/{quote(materialization_id)}"))
        return Materialization(**_filter_dataclass_kwargs(Materialization, data))

    def create(
        self,
        name: str,
        type: str,
        config: Dict[str, Any],
        *,
        poll_interval: float = 2.0,
        max_wait: float = 600.0,
    ) -> Materialization:
        """
        Create a materialization and poll until ready.

        Args:
            name: Unique name for this materialization
            type: One of 'index', 'export', 'view'
            config: Materialization config (e.g. {"compression": "int8"})
            poll_interval: Seconds between status polls
            max_wait: Maximum seconds to wait for completion

        Returns:
            Materialization object with status 'ready'

        Raises:
            RuntimeError: If materialization fails
            TimeoutError: If materialization doesn't complete in time
        """
        payload = {"name": name, "type": type, "config": config}
        resp = self._client.request("POST", self._path(), json=payload)
        response = CreateMaterializationResponse(
            **_filter_dataclass_kwargs(CreateMaterializationResponse, resp)
        )

        # Poll until ready or failed
        start_time = time.time()
        while time.time() - start_time < max_wait:
            mat = self.get(response.materialization_id)
            if mat.status == "ready":
                return mat
            if mat.status == "failed":
                raise RuntimeError(f"Materialization failed: {mat.error}")
            time.sleep(poll_interval)

        raise TimeoutError(f"Materialization did not complete within {max_wait} seconds")

    def delete(self, materialization_id: str) -> None:
        """Delete a materialization."""
        self._client.request("DELETE", self._path(f"/{quote(materialization_id)}"))

    def estimate(self, config: Dict[str, Any]) -> MaterializationEstimate:
        """
        Estimate size and build time for a materialization.

        Args:
            config: Materialization config (e.g. {"compression": "int8"})

        Returns:
            MaterializationEstimate with size and time estimates
        """
        data = self._client.request("POST", self._path("/estimate"), json=config)
        return MaterializationEstimate(**_filter_dataclass_kwargs(MaterializationEstimate, data))

    def download(
        self,
        materialization_id: str,
        file_type: str = "blocks"
    ) -> MaterializationDownloadResponse:
        """
        Get download URLs for a materialization.

        Args:
            materialization_id: The materialization ID
            file_type: Type of files ('blocks', 'index', or 'all')

        Returns:
            MaterializationDownloadResponse with presigned URLs
        """
        data = self._client.request(
            "GET",
            self._path(f"/{quote(materialization_id)}/download?file_type={file_type}")
        )
        urls = [
            MaterializationDownloadFile(**_filter_dataclass_kwargs(MaterializationDownloadFile, u))
            for u in data.get("urls", [])
        ]
        return MaterializationDownloadResponse(
            materialization_id=data["materialization_id"],
            storage_path=data["storage_path"],
            urls=urls,
            expires_in=data["expires_in"],
            file_count=data["file_count"]
        )
