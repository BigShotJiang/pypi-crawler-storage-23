from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class DecompressedError(Exception):
    message: str
    status: Optional[int] = None
    request_id: Optional[str] = None
    details: Any = None

    def __str__(self) -> str:
        return self.message


class AuthenticationError(DecompressedError):
    pass


class PermissionError(DecompressedError):
    pass


class NotFoundError(DecompressedError):
    pass


class ValidationError(DecompressedError):
    pass


class RateLimitError(DecompressedError):
    pass


class ServerError(DecompressedError):
    pass


def raise_for_status(status: int, body: Any, request_id: Optional[str]) -> None:
    message = None
    if isinstance(body, dict):
        message = body.get("detail") or body.get("message")
    if not message:
        message = f"HTTP {status}"

    if status == 401:
        raise AuthenticationError(message, status=status, request_id=request_id, details=body)
    if status == 403:
        raise PermissionError(message, status=status, request_id=request_id, details=body)
    if status == 404:
        raise NotFoundError(message, status=status, request_id=request_id, details=body)
    if status == 422:
        raise ValidationError(message, status=status, request_id=request_id, details=body)
    if status == 429:
        raise RateLimitError(message, status=status, request_id=request_id, details=body)
    if status >= 500:
        raise ServerError(message, status=status, request_id=request_id, details=body)

    raise DecompressedError(message, status=status, request_id=request_id, details=body)
