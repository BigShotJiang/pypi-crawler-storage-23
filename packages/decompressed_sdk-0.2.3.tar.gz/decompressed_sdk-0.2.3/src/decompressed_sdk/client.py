"""
Decompressed SDK Client - Version-First Design.

This client implements "Snowflake for vectors" semantics where datasets
are version-aware and all operations require explicit version pinning.

Example:
    from decompressed_sdk import DecompressedClient
    
    client = DecompressedClient(api_key="dck_your_key_here")
    
    # Get dataset reference
    dataset = client.datasets.get("my-dataset")
    
    # Pin to specific version for reproducible operations
    v1 = dataset.version(1)
    info = v1.info()
    results = v1.search([[0.1, 0.2, 0.3]], top_k=10)
    
    # Or use latest explicitly
    latest = dataset.latest()
    
    # Time travel to a specific point
    yesterday = dataset.at("2024-01-28T00:00:00Z")
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import requests

from .auth import ApiKeyAuth, AuthStrategy, JwtAuth
from .errors import raise_for_status
from .resources.datasets import DatasetsResource
from .resources.materializations import MaterializationsResource
from .resources.connectors import ConnectorsResource
from .resources.syncs import SyncsResource
from .resources.embeddings import EmbeddingsResource
from .resources.imports import ImportsResource


class DecompressedClient:
    """
    Decompressed SDK client with version-first design.
    
    All dataset operations require explicit version pinning to ensure
    reproducibility and auditability.
    
    Args:
        api_key: API key for authentication (starts with dck_)
        base_url: API base URL (optional, defaults to production)
        jwt: JWT token for authentication (alternative to api_key)
        session: Optional requests.Session for connection pooling
        timeout_seconds: Request timeout in seconds
        
    Example:
        client = DecompressedClient(api_key="dck_your_key_here")
        
        # Get dataset and pin to version
        dataset = client.datasets.get("embeddings-v2")
        v3 = dataset.version(3)
        
        # All operations use version 3
        info = v3.info()
        results = v3.search([[0.1, 0.2, 0.3]])
    """
    
    # Default production API URL
    DEFAULT_BASE_URL = "https://decompressed-api-14213868466.us-central1.run.app"
    
    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        jwt: Optional[str] = None,
        session: Optional[requests.Session] = None,
        timeout_seconds: float = 60.0,
    ) -> None:
        if api_key and jwt:
            raise ValueError("Provide only one of api_key or jwt")

        self._base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self._timeout_seconds = timeout_seconds

        self._auth: Optional[AuthStrategy] = None
        if api_key:
            self._auth = ApiKeyAuth(api_key)
        if jwt:
            self._auth = JwtAuth(jwt)

        self._session = session or requests.Session()

        # Resource accessors
        self.datasets = DatasetsResource(self)
        self.connectors = ConnectorsResource(self)
        self.syncs = SyncsResource(self)
        self.embeddings = EmbeddingsResource(self)
        self.imports = ImportsResource(self)

    def materializations(self, dataset_id: str) -> MaterializationsResource:
        """
        Get a MaterializationsResource for managing materializations of a dataset.

        Args:
            dataset_id: The dataset ID or name

        Returns:
            MaterializationsResource for the dataset
        """
        return MaterializationsResource(self, dataset_id)

    def request(self, method: str, path: str, json: Any = None) -> Any:
        """Make an authenticated request to the API."""
        headers: Dict[str, str] = {"Accept": "application/json"}
        if self._auth:
            headers.update(self._auth.headers())

        url = f"{self._base_url}{path}"
        resp = self._session.request(
            method=method,
            url=url,
            headers=headers,
            json=json,
            timeout=self._timeout_seconds,
        )

        if resp.status_code >= 400:
            request_id = resp.headers.get("x-request-id")
            try:
                body = resp.json()
            except Exception:
                body = resp.text
            raise_for_status(resp.status_code, body, request_id)

        if resp.status_code == 204:
            return None

        return resp.json()

    def request_raw(self, method: str, path: str) -> requests.Response:
        """Make an authenticated request and return raw response (for binary data)."""
        headers: Dict[str, str] = {}
        if self._auth:
            headers.update(self._auth.headers())

        url = f"{self._base_url}{path}"
        resp = self._session.request(
            method=method,
            url=url,
            headers=headers,
            timeout=self._timeout_seconds,
        )

        if resp.status_code >= 400:
            request_id = resp.headers.get("x-request-id")
            try:
                body = resp.json()
            except Exception:
                body = resp.text
            raise_for_status(resp.status_code, body, request_id)

        return resp
