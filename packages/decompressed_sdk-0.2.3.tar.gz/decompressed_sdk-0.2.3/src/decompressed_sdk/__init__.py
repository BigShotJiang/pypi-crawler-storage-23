"""
Decompressed SDK - Version-First Vector Data Platform.

This SDK implements "Snowflake for vectors" semantics where datasets
are version-aware and all operations require explicit version pinning.

Example:
    from decompressed_sdk import DecompressedClient
    
    client = DecompressedClient(
        base_url="https://api.decompressed.io",
        api_key="your-api-key"
    )
    
    # Get dataset reference
    dataset = client.datasets.get("my-dataset")
    
    # Pin to specific version for reproducible operations
    v1 = dataset.version(1)
    info = v1.info()
    results = v1.search([[0.1, 0.2, 0.3]], top_k=10)
    
    # Compare versions (LLM regression testing)
    diff = v1.compare_to(2)
    
    # Time travel
    yesterday = dataset.at("2024-01-28T00:00:00Z")
"""

from .client import DecompressedClient
from .auth import ApiKeyAuth, JwtAuth, AuthStrategy
from .errors import (
    DecompressedError,
    AuthenticationError,
    NotFoundError,
    ValidationError,
    RateLimitError,
    ServerError,
)

# Re-export types for convenience
from .types import (
    # Datasets
    Dataset,
    DatasetInfo,
    DatasetQueryResponse,
    DatasetVersion,
    UploadSession,
    AppendSession,
    JobStatus,
    UploadResult,
    AppendResult,
    # Versions (NEW - core of version-first design)
    DatasetRef,
    VersionedDataset,
    DatasetEvent,
    VersionInfo,
    VersionComparison,
    # Materializations
    Materialization,
    MaterializationType,
    MaterializationStatus,
    CreateMaterializationResponse,
    MaterializationEstimate,
    MaterializationDownloadFile,
    MaterializationDownloadResponse,
    # Connectors
    Connector,
    # Syncs
    SyncJob,
    SyncResult,
    SyncValidation,
    SyncState,
    # Embeddings
    SourceReference,
    EmbeddingJob,
    EmbeddingJobStatus,
    EmbeddingResult,
    # Search
    SearchMatch,
    SearchResponse,
    # Imports
    ImportSession,
    ImportJob,
    ImportResult,
)

__version__ = "0.2.0"

__all__ = [
    # Client
    "DecompressedClient",
    # Auth
    "ApiKeyAuth",
    "JwtAuth",
    "AuthStrategy",
    # Errors
    "DecompressedError",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    # Types - Datasets
    "Dataset",
    "DatasetInfo",
    "DatasetQueryResponse",
    "DatasetVersion",
    "UploadSession",
    "AppendSession",
    "JobStatus",
    "UploadResult",
    "AppendResult",
    # Types - Versions (NEW)
    "DatasetRef",
    "VersionedDataset",
    "DatasetEvent",
    "VersionInfo",
    "VersionComparison",
    # Types - Materializations
    "Materialization",
    "MaterializationType",
    "MaterializationStatus",
    "CreateMaterializationResponse",
    "MaterializationEstimate",
    "MaterializationDownloadFile",
    "MaterializationDownloadResponse",
    # Types - Connectors
    "Connector",
    # Types - Syncs
    "SyncJob",
    "SyncResult",
    "SyncValidation",
    "SyncState",
    # Types - Embeddings
    "SourceReference",
    "EmbeddingJob",
    "EmbeddingJobStatus",
    "EmbeddingResult",
    # Types - Search
    "SearchMatch",
    "SearchResponse",
    # Types - Imports
    "ImportSession",
    "ImportJob",
    "ImportResult",
]
