# decompressed-sdk

Public Python SDK for Decompressed.

## Install

```bash
pip install decompressed-sdk
```

## Usage

```python
from decompressed_sdk import DecompressedClient

client = DecompressedClient(
    base_url="https://api.decompressed.ai",
    api_key="dsk_test_123",
)

datasets = client.datasets.list()
```
