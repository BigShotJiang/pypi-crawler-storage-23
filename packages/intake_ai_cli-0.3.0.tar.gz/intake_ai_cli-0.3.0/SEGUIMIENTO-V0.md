# intake — Seguimiento de Implementación

> Tracking detallado del progreso de implementación.
> Actualizado: 2026-03-04 (v0.3.0 — Connectors + Exporters + Feedback + Enterprise Docs)

---

## Estado General

| Versión | Fase | Estado | Tests |
|---------|------|--------|-------|
| **v0.1.0** | Week 1: Scaffolding + Parsers | **Completada** | 135/135 |
| **v0.1.0** | Week 2: LLM Analysis + Generation | **Completada** | 217/217 |
| **v0.1.0** | Week 3: Verification + Export + Features | **Completada** | 289/289 |
| **v0.1.0** | Week 4: Documentation + Polish | **Completada** | 313/313 |
| **v0.2.0** | Phase 1: Plugin System + Refactor | **Completada** | 492/492 |
| **v0.2.0** | QA Audit Phase 1 | **Aprobada** | 492/492 (86% cov, 0 mypy, 0 ruff) |
| **v0.2.0** | Phase 2: Connectors + Exporters + Feedback | **Completada** | 673/673 |
| **v0.3.0** | Enterprise Docs + SECURITY.md + Version Bump | **Completada** | 673/673 |
| **v0.3.0** | QA Audit Phase 2 | **Aprobada** | 673/673 (86% cov, 0 mypy, 0 ruff) |

---

## Week 1 — Scaffolding + Parsers

### Day 1: Scaffolding + Doctor ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| pyproject.toml | `pyproject.toml` | ✅ | PEP 621, hatchling, todas las deps definidas |
| Package init | `src/intake/__init__.py` | ✅ | `__version__ = "0.1.0"` |
| Module runner | `src/intake/__main__.py` | ✅ | `python -m intake` funciona |
| Config schema | `src/intake/config/schema.py` | ✅ | 6 modelos Pydantic v2: LLM, Project, Spec, Verification, Export, Security |
| Config defaults | `src/intake/config/defaults.py` | ✅ | Constantes centralizadas, sin magic strings |
| Config presets | `src/intake/config/presets.py` | ✅ | minimal / standard / enterprise |
| Config loader | `src/intake/config/loader.py` | ✅ | Merge 4 capas: defaults → preset → .intake.yaml → CLI flags |
| CLI principal | `src/intake/cli.py` | ✅ | 8 comandos Click: init, add, verify, export, show, list, diff, doctor |
| Doctor checks | `src/intake/doctor/checks.py` | ✅ | Python version, API keys, deps opcionales, config YAML |
| Logging setup | `src/intake/utils/logging.py` | ✅ | structlog con ConsoleRenderer/JSONRenderer |
| `pip install -e .` | — | ✅ | Instalación en modo desarrollo funciona |
| `intake --version` | — | ✅ | Responde `intake, version 0.1.0` |
| `intake doctor` | — | ✅ | Tabla Rich con 9 checks, exit code semántico |

### Day 2: Parser Base + Text Parsers ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| ParsedContent | `src/intake/ingest/base.py` | ✅ | 100% | Dataclass con text, format, source, metadata, sections, relations |
| Parser Protocol | `src/intake/ingest/base.py` | ✅ | 100% | `@runtime_checkable`, can_parse + parse |
| Exceptions | `src/intake/ingest/base.py` | ✅ | 100% | IngestError, ParseError, UnsupportedFormatError |
| ParserRegistry | `src/intake/ingest/registry.py` | ✅ | 92% | Auto-detección por extensión + contenido |
| MarkdownParser | `src/intake/ingest/markdown.py` | ✅ | 92% | Soporta front matter YAML, extrae secciones por headings |
| PlaintextParser | `src/intake/ingest/plaintext.py` | ✅ | 97% | Soporta .txt, stdin ('-'), extrae párrafos |
| YamlInputParser | `src/intake/ingest/yaml_input.py` | ✅ | 96% | Soporta .yaml/.yml/.json, secciones por top-level keys |

### Day 3: PDF + DOCX Parsers ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| PdfParser | `src/intake/ingest/pdf.py` | ✅ | 14%* | pdfplumber, extrae texto + tablas como Markdown |
| DocxParser | `src/intake/ingest/docx.py` | ✅ | 12%* | python-docx, extrae texto + tablas + metadata + secciones por headings |

> *Coverage bajo porque faltan fixtures reales (.pdf y .docx). El código está completo y probado manualmente.

### Day 4: Jira + Confluence Parsers ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| JiraParser | `src/intake/ingest/jira.py` | ✅ | 86% | Soporta formato API `{"issues":[...]}` y formato lista `[{"key":...}]` |
| ConfluenceParser | `src/intake/ingest/confluence.py` | ✅ | 81% | BS4 + markdownify, detecta Confluence por markers en HTML |

**Datos extraídos por JiraParser:**
- Summary, description, priority, status, labels
- Comments (últimos 5 por issue, truncados a 500 chars)
- Issue links (blocks, depends on, relates to)
- Soporte para ADF (Atlassian Document Format) en comments

**Datos extraídos por ConfluenceParser:**
- Texto limpio convertido a Markdown
- Secciones por headings
- Tablas HTML → Markdown
- Metadata de la página (title, author, date)

### Day 5: Image Parser + Auto-detection avanzada ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| ImageParser | `src/intake/ingest/image.py` | ✅ | 100% | Stub con VisionCallable inyectable, base64 encoding |
| JSON subtype detection | `src/intake/ingest/registry.py` | ✅ | 92% | Detecta Jira vs JSON genérico |
| HTML subtype detection | `src/intake/ingest/registry.py` | ✅ | 92% | Detecta Confluence vs HTML genérico |
| Default registry | `src/intake/ingest/registry.py` | ✅ | 92% | `create_default_registry()` con 8 parsers |

### Utils implementados ✅

| Componente | Archivo | Estado | Coverage |
|------------|---------|--------|----------|
| file_detect | `src/intake/utils/file_detect.py` | ✅ | 100% |
| project_detect | `src/intake/utils/project_detect.py` | ✅ | 93% |
| cost tracker | `src/intake/utils/cost.py` | ✅ | 100% |
| logging | `src/intake/utils/logging.py` | ✅ | 100% |

### Tests y Fixtures ✅

**135 tests, 0 failures, 79% coverage global**

| Test file | Tests | Estado |
|-----------|-------|--------|
| `tests/test_cli.py` | 7 | ✅ |
| `tests/test_config/test_schema.py` | 7 | ✅ |
| `tests/test_config/test_presets.py` | 6 | ✅ |
| `tests/test_config/test_loader.py` | 8 | ✅ |
| `tests/test_doctor/test_checks.py` | 9 | ✅ |
| `tests/test_ingest/test_markdown.py` | 10 | ✅ |
| `tests/test_ingest/test_plaintext.py` | 8 | ✅ |
| `tests/test_ingest/test_yaml_input.py` | 8 | ✅ |
| `tests/test_ingest/test_jira.py` | 10 | ✅ |
| `tests/test_ingest/test_confluence.py` | 8 | ✅ |
| `tests/test_ingest/test_image.py` | 8 | ✅ |
| `tests/test_ingest/test_registry.py` | 17 | ✅ |
| `tests/test_utils/test_file_detect.py` | 16 | ✅ |
| `tests/test_utils/test_project_detect.py` | 8 | ✅ |
| `tests/test_utils/test_cost.py` | 5 | ✅ |

**Fixtures creados:**

| Fixture | Formato | Propósito |
|---------|---------|-----------|
| `simple_spec.md` | Markdown | Spec OAuth2 con front matter YAML, headings, requirements |
| `slack_thread.txt` | Plaintext | Thread de Slack sobre password reset (multi-persona) |
| `structured_reqs.yaml` | YAML | Requirements estructurados con IDs, prioridades, acceptance criteria |
| `jira_export.json` | Jira JSON (API) | 3 issues con comments, links, labels, priorities |
| `jira_export_multi.json` | Jira JSON (list) | 2 issues en formato lista |
| `confluence_page.html` | Confluence HTML | RFC con tablas, headings, metadata, markers de Confluence |
| `wireframe.png` | Image | PNG mínimo para tests de ImageParser |

---

## Week 2 — LLM Analysis + Generation ✅

### Day 6: LLM Adapter ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| LLMAdapter | `src/intake/llm/adapter.py` | ✅ | 90% | Async completion, retry con backoff exponencial, cost tracking, budget enforcement |
| LLMError | `src/intake/llm/adapter.py` | ✅ | 90% | Excepciones con reason + suggestion |
| CostLimitError | `src/intake/llm/adapter.py` | ✅ | 90% | Acumulado vs límite, mensaje descriptivo |
| APIKeyMissingError | `src/intake/llm/adapter.py` | ✅ | 90% | Indica qué env var falta y cómo setearla |

### Day 7: Analysis Pipeline Core ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| Data models (10) | `src/intake/analyze/models.py` | ✅ | 100% | Requirement, Conflict, OpenQuestion, RiskItem, TechDecision, TaskItem, FileAction, AcceptanceCheck, DesignResult, AnalysisResult |
| System prompts (3) | `src/intake/analyze/prompts.py` | ✅ | 100% | EXTRACTION_PROMPT, RISK_ASSESSMENT_PROMPT, DESIGN_PROMPT |
| Extraction parser | `src/intake/analyze/extraction.py` | ✅ | 97% | JSON → typed AnalysisResult |
| Analyzer orchestrator | `src/intake/analyze/analyzer.py` | ✅ | 100% | Extraction → dedup → validate → risk → design |

### Day 8: Advanced Analysis ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| Deduplication | `src/intake/analyze/dedup.py` | ✅ | 98% | Jaccard word similarity, threshold 0.75 |
| Conflict validation | `src/intake/analyze/conflicts.py` | ✅ | 100% | Filtra conflictos incompletos |
| Questions validation | `src/intake/analyze/questions.py` | ✅ | 80% | Filtra preguntas incompletas |
| Risk assessment | `src/intake/analyze/risks.py` | ✅ | 93% | Parsea JSON de riesgos a RiskItem |
| Design parser | `src/intake/analyze/design.py` | ✅ | 97% | JSON → DesignResult con tasks y checks |

### Day 9-10: Generate Module + Templates ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| SpecBuilder | `src/intake/generate/spec_builder.py` | ✅ | 88% | Orquesta 6 templates + lock |
| SpecLock | `src/intake/generate/lock.py` | ✅ | 98% | SHA-256 hashing, staleness detection, YAML I/O |
| requirements.md.j2 | `src/intake/templates/` | ✅ | — | FR, NFR, conflicts, open questions |
| design.md.j2 | `src/intake/templates/` | ✅ | — | Components, files, tech decisions |
| tasks.md.j2 | `src/intake/templates/` | ✅ | — | Summary table + detailed task sections |
| acceptance.yaml.j2 | `src/intake/templates/` | ✅ | — | Checks por tipo: command, files_exist, pattern_* |
| context.md.j2 | `src/intake/templates/` | ✅ | — | Project info, stack, risks summary |
| sources.md.j2 | `src/intake/templates/` | ✅ | — | Source list + requirement traceability |

### Tests Week 2 ✅

**82 tests nuevos, 217 total, 0 failures, 85% coverage global**

| Test file | Tests | Estado |
|-----------|-------|--------|
| `tests/test_analyze/test_analyzer.py` | 7 | ✅ |
| `tests/test_analyze/test_extraction.py` | 9 | ✅ |
| `tests/test_analyze/test_dedup.py` | 14 | ✅ |
| `tests/test_analyze/test_conflicts.py` | 7 | ✅ |
| `tests/test_analyze/test_design.py` | 9 | ✅ |
| `tests/test_analyze/test_risks.py` | 7 | ✅ |
| `tests/test_analyze/test_llm_adapter.py` | 8 | ✅ |
| `tests/test_generate/test_spec_builder.py` | 11 | ✅ |
| `tests/test_generate/test_lock.py` | 10 | ✅ |

### Coverage por módulo (acumulado Week 1 + Week 2)

| Módulo | Stmts | Miss | Coverage |
|--------|-------|------|----------|
| `analyze/` | 283 | 8 | **97%** |
| `config/` | 152 | 8 | **95%** |
| `generate/` | 110 | 7 | **94%** |
| `llm/` | 101 | 10 | **90%** |
| `doctor/` | 64 | 3 | **95%** |
| `ingest/` | 576 | 188 | **67%** |
| `utils/` | 88 | 2 | **98%** |
| `cli.py` | 101 | 15 | **85%** |
| **TOTAL** | **1657** | **255** | **85%** |

> Nota: `ingest/pdf.py` (14%) y `ingest/docx.py` (12%) bajan el promedio de ingest porque requieren fixtures binarios reales (.pdf, .docx) que no se han generado aún.

---

## Week 3 — Verification + Export + Features ✅

### Day 11: Verification Engine ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| VerificationEngine | `src/intake/verify/engine.py` | ✅ | 88% | 4 check types: command, files_exist, pattern_present, pattern_absent |
| CheckResult | `src/intake/verify/engine.py` | ✅ | 88% | Dataclass con id, name, passed, required, output, error, duration_ms |
| VerificationReport | `src/intake/verify/engine.py` | ✅ | 88% | Aggregated results + exit_code property (0/1) |
| VerifyError | `src/intake/verify/engine.py` | ✅ | 88% | Custom exception con reason + suggestion |

### Day 12: Reporters + Exporters ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| TerminalReporter | `src/intake/verify/reporter.py` | ✅ | 95% | Rich table con colores |
| JsonReporter | `src/intake/verify/reporter.py` | ✅ | 95% | JSON machine-readable |
| JunitReporter | `src/intake/verify/reporter.py` | ✅ | 95% | JUnit XML para CI |
| Reporter Protocol | `src/intake/verify/reporter.py` | ✅ | 95% | `@runtime_checkable` |
| Exporter Protocol | `src/intake/export/base.py` | ✅ | 100% | `@runtime_checkable` |
| ExporterRegistry | `src/intake/export/registry.py` | ✅ | 100% | Format-based dispatch |
| ArchitectExporter | `src/intake/export/architect.py` | ✅ | 93% | pipeline.yaml + spec copy |
| GenericExporter | `src/intake/export/generic.py` | ✅ | 95% | SPEC.md + verify.sh + spec copy |

### Day 13: CLI Complete ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| `init` command | `src/intake/cli.py` | ✅ | 66% | Full pipeline: ingest → analyze → generate → export |
| `add` command | `src/intake/cli.py` | ✅ | 66% | Incremental source addition |
| `verify` command | `src/intake/cli.py` | ✅ | 66% | Runs acceptance checks, semantic exit codes |
| `export` command | `src/intake/cli.py` | ✅ | 66% | Exports to architect/generic format |
| `show` command | `src/intake/cli.py` | ✅ | 66% | Spec summary from lock file |
| `list` command | `src/intake/cli.py` | ✅ | 66% | Lists all specs in directory |
| `diff` command | `src/intake/cli.py` | ✅ | 66% | Compares two spec versions |
| `_slugify` helper | `src/intake/cli.py` | ✅ | 66% | Description → directory name |

### Day 14: Spec Differ ✅

| Componente | Archivo | Estado | Coverage | Notas |
|------------|---------|--------|----------|-------|
| SpecDiffer | `src/intake/diff/differ.py` | ✅ | 95% | Compares requirements, tasks, acceptance by ID |
| DiffEntry | `src/intake/diff/differ.py` | ✅ | 95% | section, change_type, item_id, old/new values |
| SpecDiff | `src/intake/diff/differ.py` | ✅ | 95% | Properties: added, removed, modified, has_changes |
| DiffError | `src/intake/diff/differ.py` | ✅ | 95% | Custom exception con reason + suggestion |

### Tests Week 3 ✅

**72 tests nuevos, 289 total, 0 failures, 84% coverage global**

| Test file | Tests | Estado |
|-----------|-------|--------|
| `tests/test_verify/test_engine.py` | 15 | ✅ |
| `tests/test_verify/test_reporter.py` | 11 | ✅ |
| `tests/test_export/test_architect.py` | 8 | ✅ |
| `tests/test_export/test_generic.py` | 8 | ✅ |
| `tests/test_export/test_registry.py` | 6 | ✅ |
| `tests/test_diff/test_differ.py` | 12 | ✅ |
| `tests/test_cli.py` | 19 (+12) | ✅ |

### Coverage por módulo (acumulado Week 1 + 2 + 3)

| Módulo | Stmts | Miss | Coverage |
|--------|-------|------|----------|
| `verify/` | 213 | 21 | **90%** |
| `export/` | 192 | 9 | **95%** |
| `diff/` | 114 | 5 | **96%** |
| `analyze/` | 283 | 8 | **97%** |
| `config/` | 152 | 8 | **95%** |
| `generate/` | 110 | 7 | **94%** |
| `llm/` | 101 | 10 | **90%** |
| `doctor/` | 64 | 3 | **95%** |
| `ingest/` | 576 | 188 | **67%** |
| `utils/` | 89 | 2 | **98%** |
| `cli.py` | 325 | 110 | **66%** |
| **TOTAL** | **2397** | **382** | **84%** |

> Nota: `cli.py` tiene 66% porque `init` y `add` requieren LLM mock completo. `ingest/pdf.py` (14%) y `ingest/docx.py` (12%) bajan el promedio de ingest porque requieren fixtures binarios reales.

## Week 4 — Polish + Release ✅

### .intake.yaml.example ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| Config example | `.intake.yaml.example` | ✅ | Documentado con todas las opciones, comentarios en inglés |

### Examples Directory ✅

| Componente | Directorio | Estado | Notas |
|------------|------------|--------|-------|
| From Markdown | `examples/from-markdown/` | ✅ | README + requirements.md (OAuth2 spec) |
| From Jira | `examples/from-jira/` | ✅ | README + jira-export.json (3 issues) |
| From Scratch | `examples/from-scratch/` | ✅ | README + free-text notes |
| Multi-source | `examples/multi-source/` | ✅ | README + 3 source files (Markdown + JSON + text) |

### Error Hardening ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| EmptySourceError | `src/intake/ingest/base.py` | ✅ | Excepción específica para archivos vacíos |
| FileTooLargeError | `src/intake/ingest/base.py` | ✅ | Excepción con límite configurable (50MB default) |
| validate_file_readable | `src/intake/ingest/base.py` | ✅ | Valida existencia, tamaño, no-directorio |
| read_text_safe | `src/intake/ingest/base.py` | ✅ | UTF-8 → latin-1 fallback, empty check |
| 8 parsers actualizados | `src/intake/ingest/*.py` | ✅ | Todos usan validate_file_readable + read_text_safe |
| Hardening tests | `tests/test_ingest/test_hardening.py` | ✅ | 16 tests: empty files, encoding, size limits, directories |

### Doctor --fix ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| fix() method | `src/intake/doctor/checks.py` | ✅ | Auto-instala paquetes faltantes, crea config |
| FixResult | `src/intake/doctor/checks.py` | ✅ | Dataclass con name, success, message |
| _find_pip() | `src/intake/doctor/checks.py` | ✅ | Detecta pip3.12, pip3, o pip |
| IMPORT_TO_PIP | `src/intake/doctor/checks.py` | ✅ | Mapeo de imports a nombres de paquetes PyPI |
| CLI --fix flag | `src/intake/cli.py` | ✅ | Wired con display de resultados Rich |
| Fix tests | `tests/test_doctor/test_checks.py` | ✅ | 8 tests nuevos (17 total en el archivo) |

### Ruff Lint Fixes ✅

| Categoría | Cantidad | Notas |
|-----------|----------|-------|
| Auto-fixed (--unsafe-fixes) | 68 issues | TC001/TC003, F401, I001, SIM103, RUF022 |
| Manual fixes (E501) | ~12 | Líneas largas en tests y analyzer |
| Manual fixes (SIM117) | ~4 | Parenthesized context managers en test_llm_adapter |
| Manual fixes (RUF043) | ~4 | Raw regex strings en tests |
| **Total** | **0 errors** | `ruff check src/ tests/` → All checks passed! |

### Mypy Strict Fixes ✅

| Archivo | Errores | Fix aplicado |
|---------|---------|--------------|
| `analyze/extraction.py` | 3 | `_get_list` filtra isinstance(dict), nuevo `_get_str_list` |
| `analyze/design.py` | 4 | isinstance guards para int() overloads, `_get_list` fix |
| `analyze/conflicts.py` | 1 | `return bool(...)` en vez de `return str.strip()` |
| `analyze/risks.py` | 2 | bool return fix + `_get_list` fix |
| `analyze/questions.py` | 1 | bool return fix |
| `analyze/analyzer.py` | 5 | Return types, isinstance guards, DesignResult import |
| `ingest/jira.py` | 2 | isinstance narrowing, removed type: ignore |
| `ingest/docx.py` | 3 | `Any` types, removed isinstance(doc, Document) guards |
| `ingest/confluence.py` | 1 | `attrs=selector` en vez de `**kwargs` para bs4 |
| `ingest/pdf.py` | 2 | `Any` types, row variable fix |
| `llm/adapter.py` | 1 | Removed unused type: ignore |
| `verify/engine.py` | 1 | isinstance narrowing for tags and patterns |
| **Total** | **26 → 0** | `mypy src/ --strict` → Success: 51 source files |

### Tests Week 4 ✅

**24 tests nuevos, 313 total, 0 failures, 83% coverage global**

| Test file | Tests | Estado |
|-----------|-------|--------|
| `tests/test_ingest/test_hardening.py` | 16 | ✅ (nuevo) |
| `tests/test_doctor/test_checks.py` | 17 (+8) | ✅ |

### Coverage por módulo (acumulado Week 1 + 2 + 3 + 4)

| Módulo | Stmts | Miss | Coverage |
|--------|-------|------|----------|
| `verify/` | 221 | 22 | **90%** |
| `export/` | 192 | 9 | **95%** |
| `diff/` | 114 | 5 | **96%** |
| `analyze/` | 286 | 8 | **97%** |
| `config/` | 151 | 8 | **95%** |
| `generate/` | 110 | 7 | **94%** |
| `llm/` | 98 | 9 | **91%** |
| `doctor/` | 125 | 21 | **83%** |
| `ingest/` | 638 | 195 | **69%** |
| `utils/` | 89 | 2 | **98%** |
| `cli.py` | 394 | 130 | **67%** |
| **TOTAL** | **2518** | **416** | **83%** |

> Nota: `ingest/pdf.py` (15%) e `ingest/docx.py` (14%) bajan el promedio de ingest porque requieren fixtures binarios reales. `cli.py` tiene 67% porque `init` y `add` requieren LLM mock completo.

### Quality Gates Week 4 ✅

| Gate | Estado | Resultado |
|------|--------|-----------|
| `python3.12 -m pytest tests/ -q` | ✅ | 313 passed in 20s |
| `python3.12 -m ruff check src/ tests/` | ✅ | All checks passed! |
| `python3.12 -m mypy src/ --strict` | ✅ | Success: no issues found in 51 source files |

### Quality Gates Phase 1 (Post-QA) ✅

| Gate | Estado | Resultado |
|------|--------|-----------|
| `python3.12 -m pytest tests/` | ✅ | 492 passed in 23s |
| `ruff check src/ tests/` | ✅ | All checks passed! |
| `ruff format --check src/ tests/` | ✅ | 119 files already formatted |
| `mypy src/intake/ --strict` | ✅ | Success: no issues found in 64 source files |
| Coverage global | ✅ | 86% (target: 65%) |
| `intake --version` | ✅ | 0.2.0 |
| `intake plugins list` | ✅ | 13 plugins descubiertos |
| `intake plugins check` | ✅ | All 13 compatible |
| PyPI release | ⬜ | Controlado por el usuario |

---

## Decisiones Técnicas Tomadas

1. **structlog en tests**: Se usa `JSONRenderer` + `_NullWriter` custom sink con `cache_logger_on_first_use=False`. Se descartó `StringIO` y `os.devnull` porque ambos se corrompen al interactuar con `CliRunner` de Click.

2. **ImageParser desacoplado del LLM**: Acepta un `VisionCallable` inyectable en lugar de importar directamente de `llm/`. Stub por defecto retorna placeholder.

3. **JiraParser soporta ADF**: Extrae texto plano de Atlassian Document Format (JSON anidado) en comments.

4. **Registry fallback a plaintext**: Si no hay parser para un formato detectado pero existe un parser `plaintext` registrado, se usa como fallback con un warning.

5. **Config merge con `model_copy(update=...)`**: Se usa el método nativo de Pydantic v2 para merges inmutables en cada capa de configuración.

6. **LLM lazy import**: `litellm.acompletion` se importa dentro de `_call_llm()` (no a nivel de módulo) para permitir que los tests parcheen sin problemas y para evitar cargar litellm cuando no se necesita.

7. **Dedup threshold a 0.75**: Jaccard word similarity con threshold de 0.85 era demasiado estricto para comparaciones a nivel de palabras. Se bajó a 0.75 que es más práctico para títulos cortos de requirements.

8. **Templates Jinja2 con lstrip/trim**: Se usan `trim_blocks=True` y `lstrip_blocks=True` en el Environment de Jinja2 para evitar líneas en blanco innecesarias en el output.

9. **Protocol over ABC para exporters**: Tanto `Exporter` como `Reporter` usan `typing.Protocol` con `@runtime_checkable`, igual que `Parser`. Esto permite structural subtyping sin herencia.

10. **Verify check pattern**: El engine procesa 4 tipos de checks (command, files_exist, pattern_present, pattern_absent) con timeout configurable. `pattern_present/absent` verifican ALL matching files, no any.

11. **Generic exporter con verify.sh**: Genera un script bash ejecutable con `set -euo pipefail` y función `check()` reutilizable. Hace `chmod +x` automático.

12. **Architect pipeline con final-verification**: El step final agrupa todos los command checks required de acceptance.yaml como verificación integral.

13. **CLI _slugify**: Convierte descripciones a slugs para nombres de directorio (lowercase, hyphens, max 50 chars).

14. **setup_logging con cache_logger_on_first_use=False**: Cambiado de `True` a `False` para compatibilidad con tests. Los module-level loggers necesitan reconfigurarse entre tests.

---

## Phase 1 — Plugin System + Refactor (v0.2.0) ✅

> Implementada: 2026-03-03
> Objetivo: Transformar la arquitectura hardcodeada en un sistema extensible con plugins via entry_points (PEP 621).

### Step 1: Plugin Protocols ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| PluginMeta | `src/intake/plugins/protocols.py` | ✅ | Dataclass: name, version, description, author |
| ExportResult | `src/intake/plugins/protocols.py` | ✅ | Dataclass: files_created, primary_file, instructions |
| FetchedSource | `src/intake/plugins/protocols.py` | ✅ | Dataclass: local_path, original_uri, format_hint, metadata |
| ParserPlugin | `src/intake/plugins/protocols.py` | ✅ | Protocol V2: meta, supported_extensions, confidence, can_parse, parse |
| ExporterPlugin | `src/intake/plugins/protocols.py` | ✅ | Protocol V2: meta, supported_agents, export → ExportResult |
| ConnectorPlugin | `src/intake/plugins/protocols.py` | ✅ | Protocol V2: meta, uri_schemes, can_handle, fetch (async), validate_config |
| PluginError | `src/intake/plugins/protocols.py` | ✅ | Base exception |
| PluginLoadError | `src/intake/plugins/protocols.py` | ✅ | Load-time error con plugin_name + group |

### Step 2: Plugin Discovery ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| PluginInfo | `src/intake/plugins/discovery.py` | ✅ | Dataclass: name, group, module, distribution, version, is_builtin, is_v2, load_error |
| PluginRegistry | `src/intake/plugins/discovery.py` | ✅ | discover_all, discover_group, get_parsers, get_exporters, get_connectors, list_plugins, check_compatibility |
| create_registry | `src/intake/plugins/discovery.py` | ✅ | Factory function |
| Entry point groups | — | ✅ | intake.parsers, intake.exporters, intake.connectors |

### Step 3-4: Hooks + __init__ ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| HookEvent | `src/intake/plugins/hooks.py` | ✅ | Dataclass: name, data dict |
| HookManager | `src/intake/plugins/hooks.py` | ✅ | register, emit, registered_events |
| __init__.py | `src/intake/plugins/__init__.py` | ✅ | Exporta PluginRegistry, PluginInfo, PluginMeta, HookManager, etc. |

### Step 5: Source URI Parsing ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| SourceURI | `src/intake/utils/source_uri.py` | ✅ | Dataclass: type, raw, path, params |
| parse_source | `src/intake/utils/source_uri.py` | ✅ | stdin → schemes → http(s) → file → text |
| SCHEME_PATTERNS | `src/intake/utils/source_uri.py` | ✅ | Regex compilados para jira://, confluence://, github:// |

### Step 6-7: Connector Infrastructure ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| ConnectorError | `src/intake/connectors/base.py` | ✅ | Exception con reason + suggestion |
| ConnectorNotFoundError | `src/intake/connectors/base.py` | ✅ | Exception con uri |
| ConnectorRegistry | `src/intake/connectors/base.py` | ✅ | register, find_for_uri, fetch (async), validate_all, available_schemes |
| __init__.py | `src/intake/connectors/__init__.py` | ✅ | Exporta ConnectorRegistry, ConnectorError, ConnectorNotFoundError |

### Step 8-9: Registry Refactoring ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| ParserRegistry plugin support | `src/intake/ingest/registry.py` | ✅ | Optional plugin_registry param, discover_parsers() |
| JSON subtype: Slack | `src/intake/ingest/registry.py` | ✅ | type:"message" + ts → slack |
| JSON subtype: GitHub Issues | `src/intake/ingest/registry.py` | ✅ | number + html_url → github_issues |
| Detection priority | `src/intake/ingest/registry.py` | ✅ | Jira > GitHub Issues > Slack > YAML |
| ExporterRegistry plugin support | `src/intake/export/registry.py` | ✅ | Optional plugin_registry param, discover_exporters() |
| Plugin-first create_default | Ambos registries | ✅ | Intenta plugins primero, fallback a manual |

### Step 10: pyproject.toml ✅

| Componente | Estado | Notas |
|------------|--------|-------|
| Version bump | ✅ | 0.1.0 → 0.2.0 |
| intake.parsers entry points | ✅ | 11 parsers registrados |
| intake.exporters entry points | ✅ | 2 exporters registrados |
| intake.connectors entry points | ✅ | Grupo vacío (Phase 2) |
| Optional deps: connectors | ✅ | atlassian-python-api, PyGithub |
| Optional deps: watch | ✅ | watchfiles |
| Optional deps: mcp | ✅ | mcp |
| Dev deps: respx | ✅ | respx>=0.21 para HTTP mocking |

### Step 11-13: 3 Nuevos Parsers ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| UrlParser | `src/intake/ingest/url.py` | ✅ | httpx + BS4 + markdownify, detecta tipo de fuente |
| SlackParser | `src/intake/ingest/slack.py` | ✅ | Threads, decisions, action items |
| GithubIssuesParser | `src/intake/ingest/github_issues.py` | ✅ | Labels, comments, cross-refs, single + array |
| sample_webpage.html | `tests/fixtures/` | ✅ | HTML con título, headings, párrafos |
| slack_export.json | `tests/fixtures/` | ✅ | 7 mensajes con threads, reactions, decisions |
| github_issues.json | `tests/fixtures/` | ✅ | 3 issues con labels, comments, milestones |

### Step 14-15: Complexity + Adaptive Generation ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| ComplexityAssessment | `src/intake/analyze/complexity.py` | ✅ | mode, total_words, source_count, confidence, reason |
| classify_complexity | `src/intake/analyze/complexity.py` | ✅ | quick (<500w, 1 source), enterprise (4+ sources / >5000w), standard (default) |
| STRUCTURED_FORMATS | `src/intake/analyze/complexity.py` | ✅ | jira, confluence, yaml, github_issues, slack |
| GenerationPlan | `src/intake/generate/adaptive.py` | ✅ | mode, files_to_generate, design_depth, task_granularity, include_risks |
| create_generation_plan | `src/intake/generate/adaptive.py` | ✅ | Respeta config overrides del usuario |
| AdaptiveSpecBuilder | `src/intake/generate/adaptive.py` | ✅ | Wraps SpecBuilder, filtra archivos por modo |
| QUICK_FILES | `src/intake/generate/adaptive.py` | ✅ | context.md + tasks.md |
| STANDARD_FILES | `src/intake/generate/adaptive.py` | ✅ | Los 6 archivos |

### Step 16: Task State Tracking ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| TaskItem.status | `src/intake/analyze/models.py` | ✅ | Campo `status: str = "pending"` |
| tasks.md.j2 Status column | `src/intake/templates/tasks.md.j2` | ✅ | Columna Status en tabla + **Status:** en detalle |
| TaskStatus | `src/intake/utils/task_state.py` | ✅ | Dataclass: id, title, status, description |
| TaskStateManager | `src/intake/utils/task_state.py` | ✅ | list_tasks, get_task, update_task |
| TaskStateError | `src/intake/utils/task_state.py` | ✅ | Exception con reason + suggestion |
| VALID_STATUSES | `src/intake/utils/task_state.py` | ✅ | pending, in_progress, done, blocked |

### Step 17: CLI Commands ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| `intake plugins list` | `src/intake/cli.py` | ✅ | Tabla Rich con plugins, verbose mode |
| `intake plugins check` | `src/intake/cli.py` | ✅ | Valida compatibilidad, OK/FAIL por plugin |
| `intake task list` | `src/intake/cli.py` | ✅ | Tabla con status, filtro --status |
| `intake task update` | `src/intake/cli.py` | ✅ | Actualiza status, soporta --note |
| `init --mode` option | `src/intake/cli.py` | ✅ | quick \| standard \| enterprise |
| init: source URI parsing | `src/intake/cli.py` | ✅ | _resolve_and_parse_sources con parse_source() |
| init: scheme URI warnings | `src/intake/cli.py` | ✅ | jira://, confluence://, github:// → "connector not available" |
| init: complexity auto-detect | `src/intake/cli.py` | ✅ | classify_complexity cuando auto_mode=True |
| init: AdaptiveSpecBuilder | `src/intake/cli.py` | ✅ | _generate_spec usa AdaptiveSpecBuilder |

### Step 18: Config Schema ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| SpecConfig.auto_mode | `src/intake/config/schema.py` | ✅ | `auto_mode: bool = True` |
| JiraConnectorConfig | `src/intake/config/schema.py` | ✅ | url, email, api_token_env |
| ConfluenceConnectorConfig | `src/intake/config/schema.py` | ✅ | url, email, api_token_env |
| GithubConnectorConfig | `src/intake/config/schema.py` | ✅ | token_env |
| ConnectorsConfig | `src/intake/config/schema.py` | ✅ | jira, confluence, github sub-models |
| IntakeConfig.connectors | `src/intake/config/schema.py` | ✅ | Campo añadido |

### Step 19: Version + Exports ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| __version__ | `src/intake/__init__.py` | ✅ | "0.2.0" |
| ingest __init__ | `src/intake/ingest/__init__.py` | ✅ | Exporta IngestError, UnsupportedFormatError |
| export __init__ | `src/intake/export/__init__.py` | ✅ | Exporta ExportResult |

### Tests Phase 1 ✅

**179 tests nuevos, 492 total, 0 failures**

| Test file | Tests | Estado |
|-----------|-------|--------|
| `tests/test_plugins/test_protocols.py` | 14 | ✅ |
| `tests/test_plugins/test_discovery.py` | 12 | ✅ |
| `tests/test_plugins/test_hooks.py` | 8 | ✅ |
| `tests/test_connectors/test_base.py` | 11 | ✅ |
| `tests/test_utils/test_source_uri.py` | 17 | ✅ |
| `tests/test_utils/test_task_state.py` | 17 | ✅ |
| `tests/test_ingest/test_url.py` | 14 | ✅ |
| `tests/test_ingest/test_slack.py` | 13 | ✅ |
| `tests/test_ingest/test_github_issues.py` | 16 | ✅ |
| `tests/test_analyze/test_complexity.py` | 16 | ✅ |
| `tests/test_generate/test_adaptive.py` | 16 | ✅ |
| `tests/test_ingest/test_registry.py` | +8 | ✅ (plugin discovery + JSON subtypes) |
| `tests/test_export/test_registry.py` | +3 | ✅ (plugin discovery) |
| `tests/test_cli.py` | +14 | ✅ (plugins, task, init --mode) |

### Verificación Final ✅

| Gate | Estado | Resultado |
|------|--------|-----------|
| `python3.12 -m pytest tests/` | ✅ | 492 passed |
| `intake --version` | ✅ | 0.2.0 |
| `intake plugins list` | ✅ | 13 plugins (11 parsers + 2 exporters) |
| `intake plugins check` | ✅ | All 13 compatible |
| Entry point discovery | ✅ | Todos los parsers y exporters descubiertos |

### Decisiones Técnicas Phase 1

15. **V1 parsers no migrados a V2**: Los 8 parsers existentes mantienen el protocolo V1 (can_parse + parse). El protocolo V2 (ParserPlugin) es un superset. Los registries detectan y manejan ambos. Evita reescribir 8 parsers + tests sin beneficio al usuario.

16. **AdaptiveSpecBuilder wraps SpecBuilder**: No reemplaza. Composición sobre herencia. Independientemente testeable.

17. **Connectors solo infraestructura en Phase 1**: ConnectorRegistry + ConnectorPlugin protocol existen, pero no hay connectors concretos. Los scheme URIs (jira://, confluence://, github://) muestran warning "connector not available yet".

18. **structlog `event` keyword reservado**: `logger.debug("hook_registered", event=event_name)` causa `TypeError` porque `event` es keyword reservado del bound logger de structlog. Fix: usar `event_name=` en su lugar.

19. **Plugin discovery graceful fallback**: Si `importlib.metadata.entry_points()` falla o no encuentra plugins (e.g., running from source sin `pip install`), el fallback automático a registro manual garantiza que todo sigue funcionando.

20. **JSON subtype detection ordering**: Jira (más específico: "issues" key o "key"+"fields") > GitHub Issues ("number"+"html_url") > Slack (type:"message"+"ts") > genérico YAML. El orden importa para evitar falsos positivos.

---

## QA Audit — Phase 1 (v0.2.0) ✅

> Ejecutada: 2026-03-03
> Resultado: **APROBADA PARA RELEASE**

### Resumen

| Métrica | Resultado |
|---------|-----------|
| Tests | **492 passed**, 0 failed, 0 errors |
| Coverage | **86%** global (target: 65%) |
| mypy --strict | **0 errors** (64 source files) |
| ruff check | **0 warnings** |
| ruff format | **0 issues** (119 archivos formateados) |
| CLI commands | Todos funcionando (`--version`, `plugins list`, `plugins check`) |
| Entry points | 13 plugins descubiertos (11 parsers + 2 exporters) |
| Seguridad | Sin credenciales ni datos sensibles en logs |

### Issues Encontrados y Corregidos (105 total)

| # | Categoría | Cantidad | Detalle |
|---|-----------|----------|---------|
| 1 | ruff (TC001) | 8 | Imports de aplicación movidos a bloques `TYPE_CHECKING` |
| 2 | ruff (RUF002) | 2 | EN DASH ambiguo (`–`) reemplazado por HYPHEN-MINUS (`-`) |
| 3 | ruff (N817) | 2 | `PluginRegistry as PR` renombrado a `PluginRegistry as PluginReg` |
| 4 | ruff (E501) | 4 | Líneas largas divididas en multilínea |
| 5 | ruff (F841) | 2 | Variables no usadas eliminadas |
| 6 | ruff (TC003) | 2 | `Path` movido a bloques `TYPE_CHECKING` en tests |
| 7 | ruff (F401/I001) | 30 | Imports no usados + ordenamiento (auto-fix) |
| 8 | ruff format | 54 | Formateo inconsistente (auto-fix) |
| 9 | mypy | 1 | `Returning Any` en `github_issues.py` → wrapped con `str()` |
| 10 | mypy | 1 | `type: ignore` innecesario en `discovery.py` → eliminado |
| 11 | mypy | 2 | `list[object]` vs `list[ParsedContent]` en `cli.py` → tipos corregidos |

### Coverage por Módulo

| Módulo | Coverage | Target | Estado |
|--------|----------|--------|--------|
| `ingest/` | 81-96%* | >80% | ✅ PASS |
| `verify/` | 88-95% | >80% | ✅ PASS |
| `config/` | 88-100% | >80% | ✅ PASS |
| `diff/` | 95% | >70% | ✅ PASS |
| `doctor/` | 83% | >70% | ✅ PASS |
| `analyze/` | 83-100% | >60% | ✅ PASS |
| `generate/` | 87-100% | >60% | ✅ PASS |
| `export/` | 93-100% | >60% | ✅ PASS |
| `plugins/` | 86-100% | — | ✅ PASS |
| `connectors/` | 100% | — | ✅ PASS |
| `utils/` | 93-100% | — | ✅ PASS |

> *`ingest/docx.py` (14%) e `ingest/pdf.py` (15%) requieren fixtures binarios reales. No es regresión de Phase 1.

### Distribución de Tests (492 total)

| Área | Tests |
|------|-------|
| CLI | 33 |
| Config | 21 |
| Ingest (parsers + registry) | 156 |
| Analyze | 77 |
| Generate | 37 |
| Export | 25 |
| Verify | 26 |
| Diff | 12 |
| Doctor | 17 |
| Plugins | 34 |
| Connectors | 11 |
| Utils | 43 |

### Phase Sign-off

- [x] All tests pass (492/492)
- [x] Coverage targets met (86% overall)
- [x] mypy strict: zero errors (64 files)
- [x] ruff check: zero warnings
- [x] ruff format: zero issues
- [x] No regression in v0.1.0 tests
- [x] All new Phase 1 features covered by tests
- [x] CLI commands functional
- [x] No security issues found
- [x] Documentation updated

### Recomendaciones para Siguiente Fase

1. **Coverage docx/pdf**: Agregar fixtures binarios reales con tests dedicados
2. **Integration test end-to-end**: `init` con fuentes reales (requiere LLM mock completo)
3. **V2 protocol adoption**: Migrar parsers V1 existentes a V2 para confidence scoring

---

## Phase 2 — Connectors + Exporters + Feedback Loop (v0.2.0) ✅

> Implementada: 2026-03-04
> Objetivo: Conectores concretos (Jira/Confluence/GitHub APIs), 4 nuevos exporters (Claude Code, Cursor, Kiro, Copilot), y módulo de feedback loop (análisis de fallos de verificación + sugerencias + enmiendas al spec).

### Step 1: Config Schema Updates ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| JiraConfig (expandida) | `src/intake/config/schema.py` | ✅ | auth_type, token_env, email_env, default_project, include_comments, max_comments, fields |
| ConfluenceConfig (expandida) | `src/intake/config/schema.py` | ✅ | auth_type, token_env, email_env, default_space, include_child_pages, max_depth |
| GithubConfig (expandida) | `src/intake/config/schema.py` | ✅ | token_env, default_repo |
| FeedbackConfig (nueva) | `src/intake/config/schema.py` | ✅ | auto_amend_spec, max_suggestions, include_code_snippets |
| ExportConfig (ampliada) | `src/intake/config/schema.py` | ✅ | claude_code_task_dir, cursor_rules_dir, copilot format |
| IntakeConfig.feedback | `src/intake/config/schema.py` | ✅ | Campo añadido |

### Step 2: Jira API Connector ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| JiraConnector | `src/intake/connectors/jira_api.py` | ✅ | ConnectorPlugin protocol, lazy import atlassian-python-api |
| URI patterns | — | ✅ | `jira://PROJ-123`, `jira://PROJ-1,PROJ-2`, `jira://PROJ?jql=...`, `jira://PROJ/sprint/42` |
| Config injection | `src/intake/cli.py` | ✅ | `_inject_connector_config()` inyecta JiraConfig desde .intake.yaml |
| Tests | `tests/test_connectors/test_jira_api.py` | ✅ | Mock atlassian.Jira, 15 tests |

### Step 3: Confluence API Connector ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| ConfluenceConnector | `src/intake/connectors/confluence_api.py` | ✅ | ConnectorPlugin protocol, lazy import atlassian-python-api |
| URI patterns | — | ✅ | `confluence://page/123456`, `confluence://SPACE/Title`, `confluence://search?cql=...` |
| Tests | `tests/test_connectors/test_confluence_api.py` | ✅ | Mock atlassian.Confluence, 14 tests |

### Step 4: GitHub API Connector ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| GithubConnector | `src/intake/connectors/github_api.py` | ✅ | ConnectorPlugin protocol, lazy import PyGithub |
| URI patterns | — | ✅ | `github://org/repo/issues/42`, `github://org/repo/issues/1,2,3`, `github://org/repo/issues?labels=bug&state=open` |
| MAX_ISSUES / MAX_COMMENTS_PER_ISSUE | — | ✅ | 50 / 10 limits |
| Tests | `tests/test_connectors/test_github_api.py` | ✅ | Mock github.Github, 13 tests |

### Step 5: Connectors Wired into CLI + Plugins ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| Connector exports | `src/intake/connectors/__init__.py` | ✅ | JiraConnector, ConfluenceConnector, GithubConnector |
| Entry points | `pyproject.toml` | ✅ | 3 connector entry points: jira, confluence, github |
| CLI connector wiring | `src/intake/cli.py` | ✅ | `_fetch_connector_source()` usa `get_connectors()` + `_inject_connector_config()` |
| Doctor checks | `src/intake/doctor/checks.py` | ✅ | `_check_connectors()` valida credenciales cuando connectors están configurados |

### Step 6: Export Helpers + Claude Code Exporter ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| _helpers.py | `src/intake/export/_helpers.py` | ✅ | read_spec_file, parse_tasks, load_acceptance_checks, summarize_content, count_requirements |
| ClaudeCodeExporter | `src/intake/export/claude_code.py` | ✅ | V2 ExporterPlugin: meta, supported_agents, export → ExportResult |
| claude_md.j2 | `src/intake/templates/` | ✅ | Sección `## intake Spec` con tasks, checks, spec files |
| claude_task.md.j2 | `src/intake/templates/` | ✅ | Un archivo por task con descripción, checks, contexto |
| verify_sh.j2 | `src/intake/templates/` | ✅ | Script bash con check() y conteo de resultados |
| Tests helpers | `tests/test_export/test_helpers.py` | ✅ | 11 tests |
| Tests claude-code | `tests/test_export/test_claude_code.py` | ✅ | 16 tests (6 clases) |

**Archivos generados por ClaudeCodeExporter:**
- `CLAUDE.md` — Append/replace sección `## intake Spec` (regex inteligente)
- `.intake/tasks/TASK-NNN.md` — Un archivo por task
- `.intake/verify.sh` — Script verificación (chmod +x automático)
- `.intake/spec-summary.md` — Resumen rápido
- `.intake/spec/` — Copia de los 6 spec files

### Step 7: Cursor Exporter ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| CursorExporter | `src/intake/export/cursor.py` | ✅ | V2 ExporterPlugin: meta, supported_agents |
| cursor_rules.mdc.j2 | `src/intake/templates/` | ✅ | YAML frontmatter (`alwaysApply: true`) + Markdown |
| Tests | `tests/test_export/test_cursor.py` | ✅ | 9 tests |

**Archivos generados:** `.cursor/rules/intake-spec.mdc`, `.intake/spec/`

### Step 8: Kiro Exporter ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| KiroExporter | `src/intake/export/kiro.py` | ✅ | V2 ExporterPlugin: meta, supported_agents |
| kiro_requirements.md.j2 | `src/intake/templates/` | ✅ | Requirements con `- [ ]` acceptance criteria |
| kiro_design.md.j2 | `src/intake/templates/` | ✅ | Diseño en formato Kiro |
| kiro_tasks.md.j2 | `src/intake/templates/` | ✅ | Tasks con status y checkboxes de verificación |
| Tests | `tests/test_export/test_kiro.py` | ✅ | 13 tests |

**Archivos generados:** `requirements.md`, `design.md`, `tasks.md`, `.intake/spec/`

### Step 9: Copilot Exporter ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| CopilotExporter | `src/intake/export/copilot.py` | ✅ | V2 ExporterPlugin: meta, supported_agents |
| copilot_instructions.md.j2 | `src/intake/templates/` | ✅ | Instrucciones con contexto, tasks, checks |
| Tests | `tests/test_export/test_copilot.py` | ✅ | 11 tests |

**Archivos generados:** `.github/copilot-instructions.md`, `.intake/spec/`

### Step 10: Registro de Nuevos Exporters ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| Entry points | `pyproject.toml` | ✅ | 4 nuevos: claude-code, cursor, kiro, copilot (6 total) |
| Manual fallback | `src/intake/export/registry.py` | ✅ | 6 exporters registrados |
| Exports | `src/intake/export/__init__.py` | ✅ | ClaudeCodeExporter, CursorExporter, KiroExporter, CopilotExporter, ExportResult |
| CLI V2 handling | `src/intake/cli.py` | ✅ | `isinstance(result, ExportResult)` para V1/V2 dual support |
| Format choices | `src/intake/cli.py` | ✅ | architect, claude-code, cursor, kiro, copilot, generic |

### Step 11: Módulo Feedback ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| FeedbackError | `src/intake/feedback/analyzer.py` | ✅ | Exception con reason + suggestion |
| SpecAmendment | `src/intake/feedback/analyzer.py` | ✅ | Dataclass: target_file, section, action, content |
| FailureAnalysis | `src/intake/feedback/analyzer.py` | ✅ | Dataclass: check_name, root_cause, suggestion, category, severity, affected_tasks, spec_amendment |
| FeedbackResult | `src/intake/feedback/analyzer.py` | ✅ | Dataclass: failures, summary, estimated_effort, total_cost + amendment_count/critical_count properties |
| FeedbackAnalyzer | `src/intake/feedback/analyzer.py` | ✅ | async analyze() con LLM, _extract_failures, _build_context, _parse_response. Usa max_suggestions + include_code_snippets de FeedbackConfig |
| FEEDBACK_ANALYSIS_PROMPT | `src/intake/feedback/prompts.py` | ✅ | Prompt con {language}, analiza root_cause, suggestion, category, severity, spec_amendment |
| SuggestionFormatter | `src/intake/feedback/suggestions.py` | ✅ | format() (Jinja2: generic/claude-code/cursor) + format_terminal() (Rich con colores por severity) |
| SpecUpdater | `src/intake/feedback/spec_updater.py` | ✅ | preview() + apply(). Soporta add/modify/remove en secciones Markdown. Regex: `_section_pattern()` con negative lookahead |
| AmendmentPreview | `src/intake/feedback/spec_updater.py` | ✅ | Dataclass: amendment, current_content, proposed_content, applicable, reason |
| ApplyResult | `src/intake/feedback/spec_updater.py` | ✅ | Dataclass: applied, skipped, details |
| feedback.md.j2 | `src/intake/templates/` | ✅ | Template con rendering agent_format-específico |
| __init__.py | `src/intake/feedback/__init__.py` | ✅ | Exporta 10 clases/tipos públicos |
| Tests analyzer | `tests/test_feedback/test_analyzer.py` | ✅ | 10 tests con mock LLM |
| Tests suggestions | `tests/test_feedback/test_suggestions.py` | ✅ | 9 tests (generic/claude-code/cursor/terminal) |
| Tests spec_updater | `tests/test_feedback/test_spec_updater.py` | ✅ | 12 tests (preview/apply: add/modify/remove) |
| Fixture | `tests/fixtures/verify_report_failed.json` | ✅ | 2 pass + 2 fail checks |

### Step 12: Comando CLI Feedback ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| `intake feedback` | `src/intake/cli.py` | ✅ | Options: --verify-report, --project-dir, --apply, --agent-format, --verbose |
| Auto-verify | — | ✅ | Si no se da --verify-report, ejecuta VerificationEngine primero |
| auto_amend_spec | — | ✅ | Config field cableado: auto-activa --apply si habilitado |
| include_code_snippets | — | ✅ | Añade instrucción al LLM para incluir snippets en sugerencias |
| Tests CLI | `tests/test_cli.py` | ✅ | 5 tests: help, missing dir, all-passed, invalid JSON, format choices |

### Step 13: Doctor Updates ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| _check_connectors() | `src/intake/doctor/checks.py` | ✅ | Lee .intake.yaml, valida credenciales Jira/Confluence/GitHub |
| Tests | `tests/test_doctor/test_checks.py` | ✅ | 8 tests para connector credentials |

### Step 14: Protocol Conformance + Integration ✅

| Componente | Archivo | Estado | Notas |
|------------|---------|--------|-------|
| Exporter conformance | `tests/test_export/test_protocol_conformance.py` | ✅ | 20 tests parametrizados: meta, supported_agents, export, isinstance para 4 exporters |
| Connector conformance | `tests/test_export/test_protocol_conformance.py` | ✅ | 3 tests: Jira, Confluence, GitHub satisfacen ConnectorPlugin |
| CLI export formats | `tests/test_cli.py` | ✅ | 4 tests: claude-code, cursor, kiro, copilot via CLI |

### Resumen de Archivos Phase 2

**Archivos nuevos (39):**

| # | Archivo | Propósito |
|---|--------|-----------|
| 1 | `src/intake/connectors/jira_api.py` | Conector Jira API |
| 2 | `src/intake/connectors/confluence_api.py` | Conector Confluence API |
| 3 | `src/intake/connectors/github_api.py` | Conector GitHub API |
| 4 | `src/intake/export/_helpers.py` | Utilidades compartidas exporters |
| 5 | `src/intake/export/claude_code.py` | Exporter Claude Code |
| 6 | `src/intake/export/cursor.py` | Exporter Cursor |
| 7 | `src/intake/export/kiro.py` | Exporter Kiro |
| 8 | `src/intake/export/copilot.py` | Exporter Copilot |
| 9 | `src/intake/feedback/__init__.py` | Módulo feedback init |
| 10 | `src/intake/feedback/analyzer.py` | Analizador feedback + dataclasses |
| 11 | `src/intake/feedback/prompts.py` | Prompts LLM para feedback |
| 12 | `src/intake/feedback/suggestions.py` | Formateador de sugerencias |
| 13 | `src/intake/feedback/spec_updater.py` | Aplicador de enmiendas al spec |
| 14-21 | `src/intake/templates/*.j2` | 8 templates Jinja2 |
| 22-24 | `tests/test_connectors/test_*.py` | 3 test files conectores |
| 25-29 | `tests/test_export/test_*.py` | 5 test files exporters |
| 30-33 | `tests/test_feedback/test_*.py` + `__init__.py` | 4 test files feedback |
| 34 | `tests/fixtures/verify_report_failed.json` | Fixture reporte fallido |

**Archivos modificados (10):**

| Archivo | Cambios |
|---------|---------|
| `src/intake/config/schema.py` | Configs expandidas + FeedbackConfig |
| `src/intake/connectors/__init__.py` | Exports nuevos conectores |
| `src/intake/export/__init__.py` | Exports nuevos exporters |
| `src/intake/export/registry.py` | Manual fallback con 6 exporters |
| `src/intake/cli.py` | Connector wiring, feedback cmd, V2 export handling, config injection |
| `src/intake/doctor/checks.py` | _check_connectors() |
| `pyproject.toml` | 7 nuevos entry points (4 exporters + 3 connectors) |
| `tests/test_export/test_registry.py` | Assertion actualizada a 6 exporters |
| `tests/test_doctor/test_checks.py` | Tests credenciales conectores |
| `tests/test_cli.py` | Tests feedback cmd, export nuevos formatos |

### Tests Phase 2 ✅

**181 tests nuevos, 673 total, 0 failures**

| Test file | Tests | Estado |
|-----------|-------|--------|
| `tests/test_connectors/test_jira_api.py` | 15 | ✅ |
| `tests/test_connectors/test_confluence_api.py` | 14 | ✅ |
| `tests/test_connectors/test_github_api.py` | 13 | ✅ |
| `tests/test_export/test_helpers.py` | 11 | ✅ |
| `tests/test_export/test_claude_code.py` | 16 | ✅ |
| `tests/test_export/test_cursor.py` | 9 | ✅ |
| `tests/test_export/test_kiro.py` | 13 | ✅ |
| `tests/test_export/test_copilot.py` | 11 | ✅ |
| `tests/test_export/test_protocol_conformance.py` | 23 | ✅ |
| `tests/test_feedback/test_analyzer.py` | 10 | ✅ |
| `tests/test_feedback/test_suggestions.py` | 9 | ✅ |
| `tests/test_feedback/test_spec_updater.py` | 12 | ✅ |
| `tests/test_doctor/test_checks.py` | +8 | ✅ |
| `tests/test_cli.py` | +17 | ✅ (feedback cmd, new formats, protocol) |

### Quality Gates Phase 2 ✅

| Gate | Estado | Resultado |
|------|--------|-----------|
| `python3.12 -m pytest tests/` | ✅ | 673 passed in 33s |
| `ruff check src/ tests/` | ✅ | All checks passed! |
| All 4 V2 exporters: ExporterPlugin conformance | ✅ | meta, supported_agents, export → ExportResult |
| All 3 connectors: ConnectorPlugin conformance | ✅ | meta, uri_schemes, can_handle, fetch, validate_config |
| FeedbackConfig fields wired | ✅ | auto_amend_spec, max_suggestions, include_code_snippets |

### Decisiones Técnicas Phase 2

21. **Shared export helpers**: `_helpers.py` con read_spec_file, parse_tasks, load_acceptance_checks, summarize_content, count_requirements. Evita duplicación entre 6 exporters.

22. **CLAUDE.md append/replace**: Regex `r"^## intake Spec\b.*?(?=^## (?!intake Spec)|\Z)"` con MULTILINE|DOTALL. Permite que CLAUDE.md existente mantenga otras secciones intactas.

23. **spec_updater section matching**: Regex con negative lookahead `(?:(?!^#{2,3}\s).*\n?)*` para delimitar secciones Markdown sin ser greedy. Corregido de una versión inicial que era demasiado greedy y eliminaba secciones adyacentes.

24. **V1/V2 export dual handling**: `isinstance(result, ExportResult)` en CLI para manejar ambos return types (V1 retorna `list[str]`, V2 retorna `ExportResult`).

25. **Connector config injection**: `_inject_connector_config()` mapea nombres de conector a sus secciones de config y setea `_config` en la instancia. Separa descubrimiento de plugins (entry points) de configuración (`.intake.yaml`).

26. **Feedback usa LLM**: Excepción documentada a la regla de que solo `analyze/` habla con el LLM. El módulo `feedback/` analiza fallos de verificación, no requirements. Usa `FEEDBACK_ANALYSIS_PROMPT` con `{language}` placeholder.

27. **Jinja2 templates para todos los exporters**: Incluso los simples (Copilot). Mantiene consistencia y permite personalización sin tocar código Python.
