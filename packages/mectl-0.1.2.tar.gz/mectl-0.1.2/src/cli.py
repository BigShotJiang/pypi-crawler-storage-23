import os
import sys
import json
from minio import Minio
from minio.error import S3Error
from urllib.parse import urlparse
import subprocess
import click
import requests  # 新增requests库用于HTTP请求


def load_node_config(config_path=None):
    if config_path:
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"配置文件不存在: {config_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"配置文件格式错误: {config_path} - {e}")
    else:
        node_config_str = os.getenv('NODE_CONFIG')
        if not node_config_str:
            raise ValueError("请通过 --config 指定配置文件，或设置 NODE_CONFIG 环境变量")
        try:
            return json.loads(node_config_str)
        except json.JSONDecodeError as e:
            raise ValueError(f"环境变量 NODE_CONFIG 格式错误: {e}")


def parse_minio_url(endpoint):
    if not endpoint.startswith(('http://', 'https://')):
        endpoint = 'http://' + endpoint
    parsed = urlparse(endpoint)
    secure = parsed.scheme == 'https'
    host = parsed.hostname
    if not host:
        # 如果hostname为None，尝试从netloc中提取（不包含端口）
        host = parsed.netloc.split(':')[0] if parsed.netloc else None
    if not host:
        raise ValueError(f"无法从endpoint中解析主机名: {endpoint}")
    
    port = parsed.port
    
    if port:
        host = f"{host}:{port}"
    elif not port and parsed.scheme == 'https':
        host = f"{host}:443"
    elif not port:
        host = f"{host}:9000"  # MinIO默认端口是9000，不是80
        
    return host, secure


def ask_overwrite(file_path):
    """询问用户是否覆盖已存在的文件"""
    if os.path.exists(file_path):
        response = input(f"文件 {file_path} 已存在，是否覆盖？[y/N]: ").strip().lower()
        return response in ['y', 'yes', '是']
    return True


def extract_filename_from_key(file_key):
    """从file_key中提取文件名"""
    # 获取key的最后一部分作为文件名
    return os.path.basename(file_key)


def ask_unzip(file_path):
    """询问用户是否需要解压ZIP文件"""
    response = input(f"检测到文件 {file_path} 是ZIP格式，是否需要解压？[y/N]: ").strip().lower()
    return response in ['y', 'yes', '是']


def unzip_file(file_path):
    """解压ZIP文件"""
    try:
        # 获取文件所在目录
        dir_path = os.path.dirname(file_path)
        if not dir_path:
            dir_path = '.'
        
        # 检查是否有同名解压目录，询问是否覆盖
        extract_dir = os.path.splitext(file_path)[0]  # 去掉.zip后缀作为解压目录
        if os.path.exists(extract_dir):
            if not ask_overwrite(extract_dir):
                print(f"跳过解压: {file_path}")
                return False
        
        # 使用unzip命令解压
        result = subprocess.run(['unzip', '-o', file_path, '-d', dir_path], 
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        
        if result.returncode == 0:
            print(f"✅ 已解压: {file_path}")
            return True
        else:
            print(f"❌ 解压失败: {result.stderr}")
            return False
    except FileNotFoundError:
        print("❌ 系统未找到unzip命令，请安装unzip后再试")
        return False
    except Exception as e:
        print(f"❌ 解压过程中出现错误: {e}")
        return False


def download_file(file_key, output_path, config_path=None, bucket_name="suanpan"):
    """实际的下载函数，供命令行工具调用"""
    try:
        config = load_node_config(config_path)
        oss = config.get('oss', {})
        
        if not oss:
            print("❌ 配置文件中未找到 'oss' 配置项", file=sys.stderr)
            sys.exit(1)
            
        if 'internalEndpoint' not in oss:
            print("❌ 配置文件中缺少 'internalEndpoint' 配置项", file=sys.stderr)
            sys.exit(1)
            
        if 'accessKey' not in oss or 'accessSecret' not in oss:
            print("❌ 配置文件中缺少 'accessKey' 或 'accessSecret' 配置项", file=sys.stderr)
            sys.exit(1)

        endpoint, secure = parse_minio_url(oss['internalEndpoint'])
        client = Minio(
            endpoint,
            access_key=oss['accessKey'],
            secret_key=oss['accessSecret'],
            secure=secure
        )

        # 检查输出路径是否已存在，询问是否覆盖
        if not ask_overwrite(output_path):
            print(f"跳过下载: {file_key}")
            return None
        
        # 确保输出目录存在
        output_dir = os.path.dirname(os.path.abspath(output_path))
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        
        # 下载文件
        client.fget_object(bucket_name, file_key, output_path)
        print(f"✅ 已下载: {file_key} → {output_path}")
        return output_path
        
    except S3Error as e:
        print(f"❌ MinIO 错误: {e}", file=sys.stderr)
        sys.exit(1)
    except (FileNotFoundError, ValueError) as e:
        print(f"❌ {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"❌ 错误: {e}", file=sys.stderr)
        sys.exit(1)


def download_file_with_cli(file_key, output_path=None, config_path=None, bucket_name="suanpan"):
    """命令行接口的下载函数"""
    # 如果未指定输出路径，则从file_key中提取文件名
    if not output_path:
        filename = extract_filename_from_key(file_key)
        output_path = os.path.join("./", filename)
    
    # 执行下载
    downloaded_path = download_file(file_key, output_path, config_path, bucket_name)
    
    # 检查下载是否被跳过（用户选择不覆盖）
    if downloaded_path is None:
        return
    
    # 检查是否为zip文件，如果是则询问是否需要解压
    if downloaded_path.lower().endswith('.zip'):
        if ask_unzip(downloaded_path):
            unzip_file(downloaded_path)


@click.group()
@click.version_option(version='1.0.0')
def cli():
    """MindEdge模型工具命令行"""
    pass


@cli.command()
@click.argument('file_key')
@click.option('-o', '--output', default=None, help='本地保存路径')
@click.option('-c', '--config', help='配置文件路径（JSON，含 oss.accessKey 等）')
@click.option('-b', '--bucket', default='suanpan', help='MinIO 存储桶名称，默认为 \'suanpan\'')
def get(file_key, output, config, bucket):
    """下载MinIO中的文件"""
    download_file_with_cli(file_key, output, config, bucket)


def upload_file_to_oss(file_path, config_path=None, bucket_name="suanpan", model_id=None, version=None):
    """
    上传文件到 OSS。
    若提供 model_id 与 version，对象路径为: studio/{user_id}/model/{model_id}/{version}/{filename}
    """
    try:
        config = load_node_config(config_path)
        oss = config.get('oss', {})
        
        if not oss:
            print("❌ 配置文件中未找到 'oss' 配置项", file=sys.stderr)
            sys.exit(1)
            
        if 'internalEndpoint' not in oss:
            print("❌ 配置文件中缺少 'internalEndpoint' 配置项", file=sys.stderr)
            sys.exit(1)
            
        if 'accessKey' not in oss or 'accessSecret' not in oss:
            print("❌ 配置文件中缺少 'accessKey' 或 'accessSecret' 配置项", file=sys.stderr)
            sys.exit(1)

        endpoint, secure = parse_minio_url(oss['internalEndpoint'])
        client = Minio(
            endpoint,
            access_key=oss['accessKey'],
            secret_key=oss['accessSecret'],
            secure=secure
        )

        # 检查文件是否存在
        if not os.path.isfile(file_path):
            print(f"❌ 文件不存在: {file_path}", file=sys.stderr)
            sys.exit(1)
        
        # 获取用户ID
        user_id = os.getenv('SP_USER_ID')
        if not user_id:
            print("❌ 请设置环境变量 SP_USER_ID", file=sys.stderr)
            sys.exit(1)
        
        filename = os.path.basename(file_path)
        if model_id is not None and version is not None:
            object_key = f"studio/{user_id}/model/{model_id}/{version}/{filename}"
        else:
            object_key = f"studio/{user_id}/models/{filename}"
        
        client.fput_object(bucket_name, object_key, file_path)
        print(f"✅ 已上传: {file_path} → {object_key}")
        
        return object_key
        
    except S3Error as e:
        print(f"❌ MinIO 错误: {e}", file=sys.stderr)
        sys.exit(1)
    except (FileNotFoundError, ValueError) as e:
        print(f"❌ {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"❌ 错误: {e}", file=sys.stderr)
        sys.exit(1)


def get_api_host():
    """获取 API 主机地址"""
    host = os.getenv('SP_API_HOST')
    if not host:
        print("❌ 请设置环境变量 SP_API_HOST", file=sys.stderr)
        sys.exit(1)
    return host


def list_models():
    """查询已有模型列表，返回模型列表或 None（失败时退出）"""
    host = get_api_host()
    url = f"http://{host}/servicestack/model/models/query"
    try:
        response = requests.post(url, data={})
        if response.status_code != 200:
            print(f"❌ 获取模型列表失败: {response.status_code} - {response.text}", file=sys.stderr)
            sys.exit(1)
        body = response.json()
        if not body.get('success'):
            print(f"❌ 获取模型列表失败: {body.get('msg', response.text)}", file=sys.stderr)
            sys.exit(1)
        return body.get('data') or []
    except requests.exceptions.RequestException as e:
        print(f"❌ 请求失败: {e}", file=sys.stderr)
        sys.exit(1)
    except (ValueError, KeyError) as e:
        print(f"❌ 解析响应失败: {e}", file=sys.stderr)
        sys.exit(1)


def validate_version(model_id, version):
    """校验版本是否可用，返回 (is_valid, message)"""
    host = get_api_host()
    url = f"http://{host}/servicestack/model/models/validate-version"
    try:
        response = requests.post(url, json={"modelId": model_id, "version": version})
        if response.status_code != 200:
            return False, f"请求失败: {response.status_code}"
        body = response.json()
        if not body.get('success'):
            return False, body.get('msg', '未知错误')
        return body.get('data', {}).get('isValid', False), body.get('msg', '')
    except requests.exceptions.RequestException as e:
        return False, str(e)
    except (ValueError, KeyError):
        return False, "解析响应失败"


def create_model_name_only(name):
    """仅创建模型（仅传 name），返回新模型的 model_id"""
    host = get_api_host()
    url = f"http://{host}/servicestack/model/models/create"
    try:
        response = requests.post(url, json={"name": name})
        if response.status_code != 200:
            print(f"❌ 创建模型失败: {response.status_code} - {response.text}", file=sys.stderr)
            sys.exit(1)
        body = response.json()
        if not body.get('success'):
            print(f"❌ 创建模型失败: {body.get('msg', response.text)}", file=sys.stderr)
            sys.exit(1)
        data = body.get('data') or {}
        model_id = data.get('id') or data.get('modelId') or data.get('_id') or ''
        if not model_id:
            print("❌ 服务未返回新模型 id", file=sys.stderr)
            sys.exit(1)
        return model_id
    except requests.exceptions.RequestException as e:
        print(f"❌ 请求失败: {e}", file=sys.stderr)
        sys.exit(1)


def add_model_version(model_id, version, file_key, description=None):
    """为已有模型添加版本（传入 modelId、version、fileKey，description 可选）"""
    host = get_api_host()
    url = f"http://{host}/servicestack/model/models/create"
    data = {"id": model_id, "version": version, "fileKey": file_key}
    if description:
        data["description"] = description
    try:
        response = requests.post(url, json=data)
        if response.status_code != 200:
            print(f"❌ 添加版本失败: {response.status_code} - {response.text}", file=sys.stderr)
            sys.exit(1)
        body = response.json()
        if not body.get('success'):
            print(f"❌ 添加版本失败: {body.get('msg', response.text)}", file=sys.stderr)
            sys.exit(1)
        print(f"✅ {body.get('msg', '操作成功')}")
    except requests.exceptions.RequestException as e:
        print(f"❌ 请求失败: {e}", file=sys.stderr)
        sys.exit(1)


def _resolve_model_id(selected):
    """从列表项中解析 model_id"""
    return selected.get('id') or selected.get('modelId') or selected.get('_id') or ''


def put_flow(file_path, config_path, bucket_name):
    """
    上传并关联模型：先选择「创建新模型」或「为已有模型添加版本」，
    收集模型名/模型 id、版本号、描述后，按 studio/{user_id}/model/{model_id}/{version}/{filename} 上传，
    再调用添加版本接口。
    """
    if not os.path.isfile(file_path):
        print(f"❌ 文件不存在: {file_path}", file=sys.stderr)
        sys.exit(1)
    print("\n请选择操作：")
    print("  1) 创建新模型（并添加首版）")
    print("  2) 为已有模型添加版本")
    choice = input("请输入 1 或 2: ").strip()
    if choice not in ('1', '2'):
        print("❌ 无效选择，请输入 1 或 2", file=sys.stderr)
        sys.exit(1)

    if choice == '1':
        model_name = input("请输入模型名称: ").strip()
        if not model_name:
            print("❌ 模型名称不能为空", file=sys.stderr)
            sys.exit(1)
        model_id = create_model_name_only(model_name)
        print(f"✅ 模型已创建，id: {model_id}")
    else:
        models = list_models()
        if not models:
            print("❌ 当前没有已有模型，请先选择「创建新模型」", file=sys.stderr)
            sys.exit(1)
        print("\n已有模型列表：")
        for i, m in enumerate(models, 1):
            mid = _resolve_model_id(m)
            name = m.get('name', '')
            print(f"  {i}) {name} (id: {mid})")
        idx_str = input("请选择要添加版本的模型（输入序号）: ").strip()
        try:
            idx = int(idx_str)
            if idx < 1 or idx > len(models):
                raise ValueError("序号超出范围")
        except ValueError as e:
            print(f"❌ 无效序号: {e}", file=sys.stderr)
            sys.exit(1)
        model_id = _resolve_model_id(models[idx - 1])
        if not model_id:
            print("❌ 无法获取该模型的 id", file=sys.stderr)
            sys.exit(1)

    while True:
        version = input("请输入版本号（如 0.0.1 或 1.0.0）: ").strip()
        if not version:
            print("❌ 版本号不能为空，请重新输入。", file=sys.stderr)
            continue
        is_valid, msg = validate_version(model_id, version)
        if is_valid:
            break
        print(f"❌ 版本校验未通过: {msg}，请重新输入。", file=sys.stderr)
    description = input("请输入版本描述（可选，直接回车跳过）: ").strip()

    object_key = upload_file_to_oss(file_path, config_path, bucket_name, model_id=model_id, version=version)
    add_model_version(model_id, version, object_key, description=description or None)


@cli.command()
@click.argument('file_path')
@click.option('-c', '--config', help='配置文件路径（JSON，含 oss.accessKey 等）')
@click.option('-b', '--bucket', default='suanpan', help='MinIO 存储桶名称，默认为 \'suanpan\'')
def put(file_path, config, bucket):
    """上传文件到 MinIO 并创建/更新模型记录（先选操作，再填版本与描述，再上传）"""
    put_flow(file_path, config, bucket)


def main():
    cli()


if __name__ == "__main__":
    main()