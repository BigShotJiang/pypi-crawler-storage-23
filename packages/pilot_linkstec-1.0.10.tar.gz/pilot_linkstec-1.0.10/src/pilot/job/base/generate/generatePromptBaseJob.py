import json
import os

from pilot.file_tool.create_prompt_file import process_file
from pilot.job.impl.base_job import BaseJob

class GeneratePromptBaseJob(BaseJob):
    prompt_file_path: str = None
    template_file_path:list = []
    prompt_content: str
    result_content: str
    result_file_path: str
    replace_map  = {
    }

    def run(self):
        if self.prompt_file_path is None:
            self.prompt_file_path = self.get_new_extension_file_path(self.file_path, 'prompt')
        cwd = os.getcwd()
        self.template_file_path.insert(0, cwd)
        template = os.path.join(*self.template_file_path)
        process_file(template, self.prompt_file_path, self.replace_map)
        super().run()