# pyinstaller-plus

`pyinstaller-plus` is a PyInstaller-compatible wrapper that keeps your existing
PyInstaller workflow and then runs DistroMate packaging or publishing.

## Features

- Compatible with standard PyInstaller arguments
- Runs `distromate package` after a successful PyInstaller build
- Supports publish mode (`distromate publish`)
- Works on Windows, macOS, and Linux
- Auto-detects DistroMate CLI and falls back to installer scripts when needed

## Install

```bash
pip install pyinstaller-plus
```

## Quick Start

1. Log in to DistroMate:

```bash
distromate login
```

2. Create a `distromate.yml` in your project root.

3. Build and package:

```bash
pyinstaller-plus --dm-version 1.2.3 your.spec
```

4. Build and publish:

```bash
pyinstaller-plus --publish --dm-version 1.2.3 your.spec
```

## CLI Behavior

`pyinstaller-plus` executes this flow:

1. Run `python -m PyInstaller ...`
2. Resolve DistroMate CLI from:
   - `PATH`
   - bundled binary in this package
   - OS-specific installer fallback
3. Resolve release version from:
   - `--dm-version`
   - `pyproject.toml` -> `project.version`
4. Run one of:
   - `distromate package -v <version>`
   - `distromate publish -v <version>`

### Extra Arguments

- `--publish` / `--dm-publish`: publish mode
- `-p`: publish shorthand when used as a standalone flag
- `--dm-version <version>`: release version passed to DistroMate

Note: `-p <path>` is still treated as the original PyInstaller `-p` option.
Use `--publish` if you want unambiguous publish mode.

## Example `distromate.yml`

```yaml
appid: your_appid
name: MyApp
description: My desktop app

package:
  name: myapp
  executable: dist/myapp.exe
  target: dist
  publisher: MyApp Publisher
  language: english

preservePaths:
  - config
  - data

ignores:
  - "*.log"
  - temp/
  - "__pycache__/"
  - "*.pyc"
```

## Multi-Platform Distribution (Maintainers)

This repository builds platform-specific wheels via GitHub Actions:

- Workflow: `.github/workflows/build-distributions.yml`
- Tool: `cibuildwheel`
- Outputs:
  - `py3-none-win_amd64.whl`
  - `py3-none-macosx_*.whl`
  - `py3-none-linux_*.whl`
  - source distribution (`sdist`)

Before wheel build, CI runs `scripts/prepare_distromate_binary.py`.

Optional environment variables:

- `DISTROMATE_CLI_PATH`: local distromate executable path
- `DISTROMATE_CLI_URL`: shared download URL for all platforms
- `DISTROMATE_CLI_VERSION`: auto-generate platform download URL in CI
- `DISTROMATE_CLI_BASE_URL`: base URL for versioned downloads (default: `https://static.distromate.net/distromate-cli`)
- `DISTROMATE_CLI_OS`: optional OS override for versioned download URL
- `DISTROMATE_CLI_ARCH`: optional arch override (`x64` / `arm64`)
- `DISTROMATE_WINDOWS_URL`: Windows-specific download URL
- `DISTROMATE_MACOS_URL`: macOS-specific download URL
- `DISTROMATE_LINUX_URL`: Linux-specific download URL
- `DISTROMATE_SKIP_AUTO_INSTALL=1`: disable installer fallback
- `DISTROMATE_STRICT_BUNDLE=1`: fail build when bundling is unavailable

If `DISTROMATE_CLI_VERSION` is set (and no explicit URL env is provided), the CI helper tries versioned paths like:

`<base>/<version>/<os>/<arch-dir>/distromate-<os-or-darwin>-<arch>[.exe]`

- `arch-dir` defaults to `x64` / `arm64`
- for x64, filename arch fallback is `amd64` then `x64`
- on macOS, filename prefix fallback is `darwin` then `macos`

Example (`version=ci-20260226-44d0c86`, `os=windows`, `arch-dir=x64`):

`https://static.distromate.net/distromate-cli/ci-20260226-44d0c86/windows/x64/distromate-windows-amd64.exe`

## Automatic PyPI Publish

The same workflow can publish to PyPI automatically.

Trigger rules:

- Push a tag that matches `v*` (recommended for releases)
- Or run `build-distributions` manually with `publish=true`

Authentication options:

- `PYPI_API_TOKEN` repository secret (token upload)
- Trusted Publishing (OIDC) if no token is provided

Published files include all wheel artifacts and the sdist.

## Local Build for This Package

Use the helper script:

```powershell
./build.ps1
```

It can clean, build, run `twine check`, and upload.
