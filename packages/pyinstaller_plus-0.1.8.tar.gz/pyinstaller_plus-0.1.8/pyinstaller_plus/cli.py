from __future__ import annotations

import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Iterable

from .distromate import bundled_distromate_path

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - Python <3.11
    tomllib = None  # type: ignore[assignment]

WINDOWS_INSTALL_URL = "https://api.distromate.net/install.ps1"
UNIX_INSTALL_URL = "https://api.distromate.net/install.sh"


def _split_dm_args(
    argv: Iterable[str],
) -> tuple[list[str], bool, str | None]:
    py_args: list[str] = []
    publish = False
    dm_version: str | None = None

    args = list(argv)
    i = 0
    while i < len(args):
        arg = args[i]

        if arg == "--":
            py_args.extend(args[i + 1 :])
            break

        if arg in {"--publish", "--dm-publish"}:
            publish = True
            i += 1
            continue

        if arg == "-p":
            next_arg = args[i + 1] if i + 1 < len(args) else None
            if next_arg and not next_arg.startswith("-"):
                py_args.extend([arg, next_arg])
                i += 2
            else:
                publish = True
                i += 1
            continue

        if arg.startswith("--dm-version="):
            dm_version = arg.split("=", 1)[1]
            i += 1
            continue

        if arg == "--dm-version":
            if i + 1 >= len(args):
                raise SystemExit("Missing value for --dm-version.")
            dm_version = args[i + 1]
            i += 2
            continue

        py_args.append(arg)
        i += 1

    return py_args, publish, dm_version


def _read_pyproject_version(start_dir: Path) -> str | None:
    if tomllib is None:
        return None

    for current in [start_dir, *start_dir.parents]:
        pyproject = current / "pyproject.toml"
        if not pyproject.is_file():
            continue
        try:
            data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        except Exception:
            return None
        return data.get("project", {}).get("version")

    return None


def _run_command(cmd: list[str]) -> int:
    print(f"[pyinstaller-plus] $ {' '.join(cmd)}")
    try:
        completed = subprocess.run(cmd, check=False)
    except FileNotFoundError:
        print(f"[pyinstaller-plus] Command not found: {cmd[0]}")
        return 127
    return completed.returncode


def _default_install_url() -> str:
    if os.name == "nt":
        return WINDOWS_INSTALL_URL
    return UNIX_INSTALL_URL


def _install_hint(url: str) -> str:
    if os.name == "nt":
        return f"powershell -Command \"irm {url} | iex\""
    return f"curl -fsSL {shlex.quote(url)} | sh"


def _install_distromate(url: str) -> bool:
    if os.name == "nt":
        cmd = [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            f"irm {url} | iex",
        ]
        return _run_command(cmd) == 0

    shell = shutil.which("sh")
    if not shell:
        print("[pyinstaller-plus] shell not found (missing 'sh').")
        return False

    if shutil.which("curl"):
        cmd = [shell, "-c", f"curl -fsSL {shlex.quote(url)} | sh"]
        return _run_command(cmd) == 0

    if shutil.which("wget"):
        cmd = [shell, "-c", f"wget -qO- {shlex.quote(url)} | sh"]
        return _run_command(cmd) == 0

    print("[pyinstaller-plus] curl/wget not found, cannot run install script.")
    return False


def _find_distromate() -> str | None:
    path = shutil.which("distromate")
    if path:
        return path
    return bundled_distromate_path()


def _is_distromate_available(cmd: str) -> bool:
    try:
        completed = subprocess.run(
            [cmd, "--version"],
            check=False,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except OSError:
        return False
    return completed.returncode == 0


def _ensure_distromate(install_url: str | None = None) -> str | None:
    install_url = install_url or _default_install_url()
    found = _find_distromate()
    if found and _is_distromate_available(found):
        return found
    if found:
        print("[pyinstaller-plus] found distromate command, but it is not available.")

    print("[pyinstaller-plus] distromate CLI not found. Installing...")
    if not _install_distromate(install_url):
        print(f"[pyinstaller-plus] Install it with: {_install_hint(install_url)}")
        return None

    found = _find_distromate()
    if not found or not _is_distromate_available(found):
        print("[pyinstaller-plus] distromate install finished, but CLI is unavailable.")
        return None
    return found


def main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    py_args, publish, dm_version = _split_dm_args(args)

    if not py_args:
        py_args = ["-h"]

    pyinstaller_cmd = [sys.executable, "-m", "PyInstaller", *py_args]
    rc = _run_command(pyinstaller_cmd)
    if rc != 0:
        return rc
    if len(py_args) == 1 and py_args[0] in {"-h", "--help", "--version"}:
        return 0

    distromate_cmd = _ensure_distromate()
    if not distromate_cmd:
        return 127

    if dm_version is None:
        dm_version = _read_pyproject_version(Path(os.getcwd()))
    if not dm_version:
        print(
            "[pyinstaller-plus] distromate version not specified. "
            "Use --dm-version <version> to continue."
        )
        return 2

    dm_cmd = [distromate_cmd, "publish" if publish else "package", "-v", dm_version]
    return _run_command(dm_cmd)


if __name__ == "__main__":
    raise SystemExit(main())
