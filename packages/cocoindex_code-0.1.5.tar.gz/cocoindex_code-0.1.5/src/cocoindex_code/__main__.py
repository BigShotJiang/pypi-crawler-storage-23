"""Entry point for `python -m cocoindex_code`."""

from .server import main

if __name__ == "__main__":
    main()
