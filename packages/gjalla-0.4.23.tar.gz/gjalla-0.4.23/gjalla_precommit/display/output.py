"""Output formatting and display."""

from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown


console = Console()


def success(message: str) -> None:
    """Display success message."""
    console.print(f"[green]✓[/green] {message}")


def error(message: str) -> None:
    """Display error message."""
    console.print(f"[red]✗[/red] {message}")


def warning(message: str) -> None:
    """Display warning message."""
    console.print(f"[yellow]![/yellow] {message}")


def info(message: str) -> None:
    """Display info message."""
    console.print(f"[blue]i[/blue] {message}")


def panel(content: str, title: str | None = None) -> None:
    """Display content in a panel."""
    console.print(Panel(content, title=title))


BRIDGE_ART = (
    "      [bold]▄▄▄▄▄▄▄[/bold]\n"
    "    [bold]▄▀[/bold]  [purple]▴[/purple]    [bold]▀▄[/bold]\n"
    "   [bold]██[/bold]  [purple]✦✦✦[/purple]    [bold]██[/bold]\n"
    "   [bold]██[/bold]   [purple]▾[/purple]  [blue]▴[/blue]  [bold]██[/bold]\n"
    "   [bold]██[/bold]     [blue]✧✧✧[/blue] [bold]██[/bold]\n"
    "   [bold]██[/bold]      [blue]▾[/blue]  [bold]██[/bold]\n"
    "   [bold]▀▀[/bold]         [bold]▀▀[/bold]\n"
)


def bridge_banner(target: Console | None = None) -> None:
    """Print the gjalla bridge ASCII art."""
    c = target or console
    c.print()
    c.print(BRIDGE_ART)
    c.print()


def section_header(title: str, color: str = "purple") -> None:
    """Print bridge art followed by a styled section title."""
    bridge_banner()
    console.print(f"  [{color} bold]{title}[/{color} bold]")
    console.print()


def markdown(content: str) -> None:
    """Display markdown content."""
    console.print(Markdown(content))
