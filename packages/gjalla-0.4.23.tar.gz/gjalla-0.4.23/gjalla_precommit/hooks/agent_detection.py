"""Shared constants for agent environment detection."""

import os

# Environment variables that indicate an AI coding agent is running.
# Used by check.py (Python) and the bash pre-commit script template (scripts.py).
# If you add a new agent env var here, also update the bash template in scripts.py.
AGENT_ENV_VARS: tuple[str, ...] = (
    "CLAUDE_CODE",
    "CURSOR_SESSION_ID",
    "AIDER_MODEL",
    "CODEX_ENV",
    "GEMINI_CLI",
)


def is_agent_environment() -> bool:
    """Return True if any known agent env var is set."""
    return any(os.environ.get(v) for v in AGENT_ENV_VARS)
