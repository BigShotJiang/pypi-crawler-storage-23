# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["LibraryScreenListResponse", "Error", "Progress"]


class Error(BaseModel):
    code: str
    """Machine-readable error code"""

    message: str
    """Human-readable error message"""

    details: Optional[object] = None
    """Additional error details"""


class Progress(BaseModel):
    num_molecules_screened: int
    """Number of molecules screened so far"""

    total_molecules_to_screen: int
    """Total number of molecules in the library"""

    latest_result_id: Optional[str] = None
    """ID of the most recently screened result"""


class LibraryScreenListResponse(BaseModel):
    """Summary of a small molecule library screening engine run (excludes input)"""

    id: str
    """Unique SmScreenSummary identifier"""

    completed_at: Optional[datetime] = None

    created_at: datetime

    data_deleted_at: Optional[datetime] = None
    """When the input, output, and result data was permanently deleted.

    Null if data has not been deleted.
    """

    engine: Literal["boltz-sm-screen"]
    """Engine used for small molecule library screen"""

    engine_version: str
    """Engine version used for small molecule library screen"""

    error: Optional[Error] = None

    livemode: bool
    """Whether this resource was created with a live API key."""

    progress: Optional[Progress] = None

    started_at: Optional[datetime] = None

    status: Literal["pending", "running", "succeeded", "failed", "stopped"]

    stopped_at: Optional[datetime] = None

    workspace_id: str
    """Workspace ID"""

    idempotency_key: Optional[str] = None
    """Client-provided idempotency key"""
