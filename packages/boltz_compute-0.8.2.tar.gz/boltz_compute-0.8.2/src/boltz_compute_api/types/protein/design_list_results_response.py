# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Union, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from ..._models import BaseModel

__all__ = [
    "DesignListResultsResponse",
    "Artifacts",
    "ArtifactsArchive",
    "ArtifactsStructure",
    "Entity",
    "EntityProteinEntity",
    "EntityProteinEntityModification",
    "EntityProteinEntityModificationCcdModification",
    "EntityProteinEntityModificationSmilesModification",
    "EntityRnaEntity",
    "EntityRnaEntityModification",
    "EntityRnaEntityModificationCcdModification",
    "EntityRnaEntityModificationSmilesModification",
    "EntityDnaEntity",
    "EntityDnaEntityModification",
    "EntityDnaEntityModificationCcdModification",
    "EntityDnaEntityModificationSmilesModification",
    "EntityLigandCcdEntity",
    "EntityLigandSmilesEntity",
    "Metrics",
    "Warning",
]


class ArtifactsArchive(BaseModel):
    url: str
    """URL to download the file"""

    url_expires_at: datetime
    """When the presigned URL expires"""


class ArtifactsStructure(BaseModel):
    url: str
    """URL to download the file"""

    url_expires_at: datetime
    """When the presigned URL expires"""


class Artifacts(BaseModel):
    archive: ArtifactsArchive

    structure: Optional[ArtifactsStructure] = None


class EntityProteinEntityModificationCcdModification(BaseModel):
    residue_index: int
    """0-based index of the residue to modify"""

    type: Literal["ccd"]

    value: str
    """CCD code from RCSB PDB (e.g.

    'MSE' for selenomethionine, 'SEP' for phosphoserine)
    """


class EntityProteinEntityModificationSmilesModification(BaseModel):
    residue_index: int
    """0-based index of the residue to modify"""

    type: Literal["smiles"]

    value: str
    """SMILES string for the modification"""


EntityProteinEntityModification: TypeAlias = Union[
    EntityProteinEntityModificationCcdModification, EntityProteinEntityModificationSmilesModification
]


class EntityProteinEntity(BaseModel):
    chain_ids: List[str]
    """Chain IDs for this entity"""

    modifications: List[EntityProteinEntityModification]
    """Post-translational modifications"""

    type: Literal["protein"]

    value: str
    """Amino acid sequence (one-letter codes)"""

    cyclic: Optional[bool] = None
    """Whether the sequence is cyclic"""


class EntityRnaEntityModificationCcdModification(BaseModel):
    residue_index: int
    """0-based index of the residue to modify"""

    type: Literal["ccd"]

    value: str
    """CCD code from RCSB PDB (e.g.

    'MSE' for selenomethionine, 'SEP' for phosphoserine)
    """


class EntityRnaEntityModificationSmilesModification(BaseModel):
    residue_index: int
    """0-based index of the residue to modify"""

    type: Literal["smiles"]

    value: str
    """SMILES string for the modification"""


EntityRnaEntityModification: TypeAlias = Union[
    EntityRnaEntityModificationCcdModification, EntityRnaEntityModificationSmilesModification
]


class EntityRnaEntity(BaseModel):
    chain_ids: List[str]
    """Chain IDs for this entity"""

    modifications: List[EntityRnaEntityModification]
    """Chemical modifications"""

    type: Literal["rna"]

    value: str
    """RNA nucleotide sequence (A, C, G, U, N)"""

    cyclic: Optional[bool] = None
    """Whether the sequence is cyclic"""


class EntityDnaEntityModificationCcdModification(BaseModel):
    residue_index: int
    """0-based index of the residue to modify"""

    type: Literal["ccd"]

    value: str
    """CCD code from RCSB PDB (e.g.

    'MSE' for selenomethionine, 'SEP' for phosphoserine)
    """


class EntityDnaEntityModificationSmilesModification(BaseModel):
    residue_index: int
    """0-based index of the residue to modify"""

    type: Literal["smiles"]

    value: str
    """SMILES string for the modification"""


EntityDnaEntityModification: TypeAlias = Union[
    EntityDnaEntityModificationCcdModification, EntityDnaEntityModificationSmilesModification
]


class EntityDnaEntity(BaseModel):
    chain_ids: List[str]
    """Chain IDs for this entity"""

    modifications: List[EntityDnaEntityModification]
    """Chemical modifications"""

    type: Literal["dna"]

    value: str
    """DNA nucleotide sequence (A, C, G, T, N)"""

    cyclic: Optional[bool] = None
    """Whether the sequence is cyclic"""


class EntityLigandCcdEntity(BaseModel):
    chain_ids: List[str]
    """Chain IDs for this ligand"""

    type: Literal["ligand_ccd"]

    value: str
    """CCD code (e.g., ATP, ADP)"""


class EntityLigandSmilesEntity(BaseModel):
    chain_ids: List[str]
    """Chain IDs for this ligand"""

    type: Literal["ligand_smiles"]

    value: str
    """SMILES string representing the ligand"""


Entity: TypeAlias = Union[
    EntityProteinEntity, EntityRnaEntity, EntityDnaEntity, EntityLigandCcdEntity, EntityLigandSmilesEntity
]


class Metrics(BaseModel):
    """Structural and binding quality metrics for a designed protein binder"""

    binding_confidence: float
    """Confidence that the designed binder binds the target (0-1).

    Primary metric for hit discovery.
    """

    helix_fraction: float
    """Fraction of the designed sequence forming alpha helices (0-1)."""

    iptm: float
    """Interface predicted TM score (0-1).

    Confidence in the protein-protein interface.
    """

    loop_fraction: float
    """Fraction of the designed sequence in coil/loop regions (0-1)."""

    min_interaction_pae: float
    """Minimum predicted aligned error at the interface (Angstroms).

    Lower values indicate higher confidence.
    """

    sheet_fraction: float
    """Fraction of the designed sequence forming beta sheets (0-1)."""

    structure_confidence: float
    """Confidence in the predicted 3D structure (0-1)."""


class Warning(BaseModel):
    """A warning about a potential quality issue with a result"""

    code: str
    """Machine-readable warning code (e.g. "low_confidence", "unusual_geometry")"""

    message: str
    """Human-readable description of the warning"""


class DesignListResultsResponse(BaseModel):
    """A single generated protein design"""

    id: str
    """Unique result ID"""

    artifacts: Artifacts

    created_at: datetime

    entities: List[Entity]
    """Entities of the designed binder complex.

    Includes both designed entities and fixed entities from the input.
    """

    metrics: Metrics
    """Structural and binding quality metrics for a designed protein binder"""

    warnings: Optional[List[Warning]] = None
    """Warnings about potential quality issues with this result."""
