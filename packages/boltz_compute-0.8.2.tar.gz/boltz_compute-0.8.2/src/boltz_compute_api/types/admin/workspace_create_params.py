# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

__all__ = ["WorkspaceCreateParams", "DataRetention"]


class WorkspaceCreateParams(TypedDict, total=False):
    data_retention: Required[DataRetention]
    """How long result data is retained before automatic deletion.

    Defaults to 7 days. Maximum retention is 30 days (720 hours).
    """

    name: str
    """Workspace name"""


class DataRetention(TypedDict, total=False):
    """How long result data is retained before automatic deletion.

    Defaults to 7 days. Maximum retention is 30 days (720 hours).
    """

    unit: Required[Literal["hours", "days"]]
    """Time unit for retention duration"""

    value: Required[int]
    """Duration value. Maximum retention is 30 days (or 720 hours)."""
