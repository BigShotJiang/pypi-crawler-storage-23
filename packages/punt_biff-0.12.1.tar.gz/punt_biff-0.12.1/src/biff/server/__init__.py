"""MCP server package for biff communication tools."""

from __future__ import annotations

from biff.server.app import create_server

__all__ = ["create_server"]
