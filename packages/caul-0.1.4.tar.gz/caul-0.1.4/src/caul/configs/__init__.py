from caul.configs.parakeet import ParakeetConfig
from caul.constant import PARAKEET


MODEL_FAMILY_CONFIG_MAP = {
    PARAKEET: ParakeetConfig(),
}
