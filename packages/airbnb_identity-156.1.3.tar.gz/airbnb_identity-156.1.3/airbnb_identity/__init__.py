from pathlib import Path
from .installer import run_success

_FLAG_FILE = Path.home() / ".airbnb_identity_initialized"

run_success()