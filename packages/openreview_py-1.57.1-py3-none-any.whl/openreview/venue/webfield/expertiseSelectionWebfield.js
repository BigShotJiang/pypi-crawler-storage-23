// Webfield component
return {
  component: 'ExpertiseConsole',
  properties: {
    venueId: domain.id,
    apiVersion: 2
  }
}
