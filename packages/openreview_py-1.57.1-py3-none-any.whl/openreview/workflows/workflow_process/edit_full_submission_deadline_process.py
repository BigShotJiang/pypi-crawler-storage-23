def process(client, edit, invitation):

    domain = client.get_group(edit.domain)
    venue_id = domain.id
    meta_invitation_id = domain.get_content_value('meta_invitation_id')
    reviewers_id = domain.get_content_value('reviewers_id')
    expdate = edit.invitation.edit['invitation']['expdate']
    submission_name = domain.get_content_value('submission_name', 'Submission')
    withdrawal_name = domain.get_content_value('withdrawal_name', 'Withdrawal')
    desk_rejection_name = domain.get_content_value('desk_rejection_name', 'Desk_Rejection')
    print('Expiration:', edit.invitation.edit['invitation']['expdate'])
    
    # update post submission cdate if new cdate is later than current cdate
    before_bidding_invitation_id = f'{venue_id}/-/{submission_name}_Change_Before_Bidding'
    before_bidding_invitation = openreview.tools.get_invitation(client, before_bidding_invitation_id)
    if before_bidding_invitation and before_bidding_invitation.cdate < expdate:
        print('Setting post submission cdate to:', expdate)
        client.post_invitation_edit(
            invitations=meta_invitation_id,
            signatures=[venue_id],
            invitation=openreview.api.Invitation(
                id=before_bidding_invitation_id,
                cdate=expdate,
                signatures=[venue_id]
            )
        )

    # update withdrawal cdate
    withdrawal_invitation_id = f'{venue_id}/-/{withdrawal_name}'
    withdrawal_invitation = openreview.tools.get_invitation(client, withdrawal_invitation_id)
    if withdrawal_invitation and withdrawal_invitation.cdate < expdate:
        content = {
            'cdate': expdate
        }
        current_expdate = withdrawal_invitation.edit.get('invitation', {}).get('expdate')
        # if current expdate is earlier than new cdate, update it too
        if current_expdate and current_expdate < expdate:
            content['expdate'] = expdate + (52 * 7 * 24 * 60 * 60 * 1000)  # add 52 weeks
        client.post_invitation_edit(
            invitations=meta_invitation_id,
            signatures=[venue_id],
            invitation=openreview.api.Invitation(
                id=withdrawal_invitation_id,
                signatures=[venue_id],
                cdate=expdate,
                edit={
                    'invitation': content
                }
            )
        )

    # update desk rejection cdate
    desk_rejection_invitation_id = f'{venue_id}/-/{desk_rejection_name}'
    desk_rejection_invitation = openreview.tools.get_invitation(client, desk_rejection_invitation_id)
    if desk_rejection_invitation and desk_rejection_invitation.cdate < expdate:
        content = {
            'cdate': expdate
        }
        current_expdate = desk_rejection_invitation.edit.get('invitation', {}).get('expdate')
        # if current expdate is earlier than new cdate, update it too
        if current_expdate and current_expdate < expdate:
            content['expdate'] = expdate + (3 * 30 * 24 * 60 * 60 * 1000)  # add 3 months
        client.post_invitation_edit(
            invitations=meta_invitation_id,
            signatures=[venue_id],
            invitation=openreview.api.Invitation(
                id=desk_rejection_invitation_id,
                signatures=[venue_id],
                cdate=expdate,
                edit={
                    'invitation': content
                }
            )
        )

    # update Submission_Group cdate
    submission_group_invitation_id = f'{reviewers_id}/-/{submission_name}_Group'
    submission_group_invitation = openreview.tools.get_invitation(client, submission_group_invitation_id)
    if submission_group_invitation and submission_group_invitation.cdate < expdate:
        client.post_invitation_edit(
            invitations=meta_invitation_id,
            signatures=[venue_id],
            invitation=openreview.api.Invitation(
                id=submission_group_invitation_id,
                cdate=expdate,
                signatures=[venue_id]
            )
        )

    area_chairs_id = domain.get_content_value('area_chairs_id')
    if area_chairs_id:
        ac_submission_group_invitation_id = f'{area_chairs_id}/-/{submission_name}_Group'
        ac_submission_group_invitation = openreview.tools.get_invitation(client, ac_submission_group_invitation_id)
        if ac_submission_group_invitation and ac_submission_group_invitation.cdate < expdate:
        # update Area_Chair_Group cdate
            client.post_invitation_edit(
                invitations=meta_invitation_id,
                signatures=[venue_id],
                invitation=openreview.api.Invitation(
                    id=ac_submission_group_invitation_id,
                    cdate=expdate,
                    signatures=[venue_id]
                )
            )

    senior_area_chairs_id = domain.get_content_value('senior_area_chairs_id')
    if senior_area_chairs_id:
        sac_submission_group_invitation_id = f'{senior_area_chairs_id}/-/{submission_name}_Group'
        sac_submission_group_invitation = openreview.tools.get_invitation(client, sac_submission_group_invitation_id)
        if sac_submission_group_invitation and sac_submission_group_invitation.cdate < expdate:
        # update Senior_Area_Chair_Group cdate
            client.post_invitation_edit(
                invitations=meta_invitation_id,
                signatures=[venue_id],
                invitation=openreview.api.Invitation(
                    id=sac_submission_group_invitation_id,
                    cdate=expdate,
                    signatures=[venue_id]
                )
            )

    deletion_invitation_id = f'{venue_id}/-/Deletion'
    client.post_invitation_edit(
        invitations=meta_invitation_id,
        signatures=[venue_id],
        invitation=openreview.api.Invitation(
            id=deletion_invitation_id,
            signatures=[venue_id],
            edit={
                'invitation': {
                    'expdate': expdate
                }
            }
        )
    )