"""Core utilities for main."""


def main():
    """Run main."""

    print("Hello from grilly!")


if __name__ == "__main__":
    main()
