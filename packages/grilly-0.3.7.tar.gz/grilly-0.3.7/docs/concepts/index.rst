Concepts
========

This section explains the framework design in depth. Read these pages in order
for a complete mental model of Grilly.

.. toctree::
   :maxdepth: 2

   architecture_and_runtime
   design_choices
   tensor_model_and_shapes
   module_system_and_functional_api
   training_and_optimization
   attention_transformers_and_decoding
   convolution_pooling_and_normalization
   spiking_neural_networks
   memory_retrieval_and_faiss
   multimodal_capsule_and_vlm
   lora_and_adapter_finetuning
   experimental_language_and_cognition
   stable_hashing_and_ingestion_checkpoints
   specialized_operations
   compatibility_and_integrations
   performance_debugging_and_testing
