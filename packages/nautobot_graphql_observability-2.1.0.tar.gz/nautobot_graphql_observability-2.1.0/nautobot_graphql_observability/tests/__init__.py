"""Unit tests for nautobot_graphql_observability app."""

from nautobot_graphql_observability.tests.test_middleware import *  # noqa: F401,F403
from nautobot_graphql_observability.tests.test_utils import *  # noqa: F401,F403
