"""Views for the nautobot_graphql_observability app."""
