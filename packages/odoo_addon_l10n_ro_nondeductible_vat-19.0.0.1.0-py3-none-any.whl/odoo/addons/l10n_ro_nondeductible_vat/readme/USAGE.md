Select the nondeductible tax on invoice line, consume stock move or
minus inventory.
