from .main import Libib

__version__ = "0.0.1"

