#!/usr/bin/python
# coding: utf-8

from gitlab_api.mcp import gitlab_mcp

if __name__ == "__main__":
    gitlab_mcp()
