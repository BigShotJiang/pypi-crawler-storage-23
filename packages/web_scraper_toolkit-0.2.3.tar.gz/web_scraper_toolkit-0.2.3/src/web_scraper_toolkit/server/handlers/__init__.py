# ./src/web_scraper_toolkit/server/handlers/__init__.py
"""
MCP Server Tools
================

Modular tools for the MCP Server.
"""
