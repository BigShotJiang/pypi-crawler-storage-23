from __future__ import annotations

from pymatgen.io.vasp import Xdatcar
from pymatgen.core.structure import Structure
from polyhedral_analysis.configuration import Configuration
from polyhedral_analysis.utils import flatten
from polyhedral_analysis.polyhedra_recipe import PolyhedraRecipe
from polyhedral_analysis.configuration import Configuration
import re
import copy
from monty.io import zopen # type: ignore
import pickle
import multiprocessing
from tqdm import tqdm
from tqdm.notebook import tqdm as tqdm_notebook
from functools import partial
from collections.abc import Callable, Iterator
from typing import Any, TypeVar

T = TypeVar('T')
ProgressBarType = Callable[[Iterator[T]], Iterator[T]]

def get_progress_bar(progress: bool | str) -> ProgressBarType:
    if progress == 'notebook':
        return lambda x: tqdm_notebook(x)  # type: ignore
    elif progress:
        return lambda x: tqdm(x)  # type: ignore
    else:
        return iter

class Trajectory:

    def __init__(self,
                 structures: list[Structure],
                 configurations: list[Configuration]) -> None:
        """TODO"""
        for s in structures:
            if not isinstance( s, Structure ):
                raise TypeError( "structures argument should contain pymatgen Structure objects" )
        for c in configurations:
            if not isinstance( c, Configuration ):
                raise TypeError( "configurations argument should contain Configuration objects" )
        self._structures = structures
        self._configurations = configurations

    @classmethod
    def _get_configuration(cls,
                           args: dict[str, Any]) -> Configuration:
         return Configuration(structure=args['structure'], 
                              recipes=args['recipes'])
    
    @classmethod
    def from_structures(cls,
                        structures: list[Structure],
                        recipes: list[PolyhedraRecipe],
                        verbose: bool = False,
                        ncores: int | None = None,
                        progress: bool | str = False) -> Trajectory:
        """
        Generate a :obj:`Trajectory` object by applying one or more polyhedral recipes to
        a series of `pymatgen` :obj:`Structure` objects.,

        Args:
            structures (list(:obj:`pymatgen.Structure`)): A list of `pymatgen` 
                :obj:`Structure`` objects.
            recipes (list(PolyhedraRecipe): List of `PolyhedraRecipe` recipes, where each recipe
                defines how to construct a set of `CoordinationPolyhedra` for each configuration.
            verbose (:obj:`bool`, optional): verbose output while parsing the input structures.
                Default is False.
            ncores (:obj:`int`, optional): TODO.
            progress (:obj:`str`, optional): Show a progress bar.
               Setting to ``True`` gives a simple progress bar.
               Setting to ``"notebook"`` gives a Jupyter notebook compatible progress bar.
               Default is ``False``.

        Returns:
            None
        """
        args = [{'structure': structure, 
                 'recipes': recipes} for structure in structures]
        progress_bar = get_progress_bar(progress)
        progress_kwargs: dict[str, Any] = {}
        if progress:
            progress_kwargs = {'total': len(args),
                               'unit': ' configurations'}

        # generate polyhedra configurations
        if ncores:
            with multiprocessing.Pool(ncores) as p:
                configurations = list(progress_bar(p.imap(cls._get_configuration, args), 
                                                   **progress_kwargs))
        else:
            configurations = list(progress_bar(map(cls._get_configuration, args),
                                               **progress_kwargs))
        return cls(structures=structures, 
                   configurations=configurations)

    def extend(self, 
               other: Trajectory,
               offset: int = 0) -> None:
        """
        Extend this Trajectory with the data from another Trajectory.

        Args:
            other (`Trajectory`): The trajectory to be appended.
            offset (int): Offset to apply to the frame numbers.

        Returns:
            None
        """
        extended_configurations = copy.deepcopy(other.configurations)
        self.configurations.extend(extended_configurations)

    def __add__(self, other: object) -> Trajectory:
        """TODO"""
        if not isinstance(other, Trajectory):
            return NotImplemented
        summed_structures = self.structures + other.structures
        summed_configurations = self.configurations + other.configurations
        new_trajectory = Trajectory(summed_structures, summed_configurations)
        return new_trajectory

    @property
    def structures(self) -> list[Structure]:
        return self._structures

    @property
    def configurations(self) -> list[Configuration]:
        return self._configurations

    @classmethod
    def from_xdatcar(cls,
                     filename: str,
                     recipes: list[PolyhedraRecipe],
                     verbose: bool = False,
                     progress: str | bool = False,
                     ncores: int | None = None) -> Trajectory:
        """
        Args:
            filename (str): Filename for a VASP XDATCAR file.
            recipes (list(:obj:`PolyhedraRecipe`): List of `PolyhedraRecipe` recipes, 
                where each recipe defines how to construct a set of `CoordinationPolyhedra` 
                for each configuration.

        Returns:
            (:obj:`Trajectory`): a :obj:`Trajectory` object.

        """
        xdatcar = Xdatcar( filename )
        structures = xdatcar.structures
        return cls.from_structures(structures, recipes, verbose=verbose, progress=progress,
                                    ncores=ncores)

    @classmethod
    def from_xdatcars(cls,
                      filenames: list[str],
                      recipes: list[PolyhedraRecipe],
                      verbose: bool = False,
                      ncores: int | None = None,
                      progress: bool | str = False) -> Trajectory:
        """
        TODO
        """
        if ncores and len(filenames) > 1:
            with multiprocessing.Pool(ncores) as p:
                xdatcars = p.map(_get_xdatcar, filenames)
        else:
            xdatcars = [Xdatcar(f) for f in filenames]
        structures = flatten([x.structures for x in xdatcars])
        return cls.from_structures(structures,
                                   recipes,
                                   verbose,
                                   ncores=ncores,
                                   progress=progress) 

    def __len__(self) -> int:
        return len(self.structures)

def _get_xdatcar(filename: str) -> Xdatcar:
    """
    Internal method to support multiprocessing.
    """
    return Xdatcar(filename)

