# Integration Docs Scope

This folder keeps **library usage guides** for platform adapters.

## Kept in this repo (core library guidance)

- `integration-guide.md`
- `api-reference.md`
- `api-cheat-sheet.md`
- `decisions.md`

## Moved out of this repo (adapter implementation docs)

The following Home Assistant adapter implementation docs were removed from the core repo and belong in the integration adapter repository:

- `ha-sync-services.md`
- `ui-design.md`
- `integrity-validation.md`

See ADR-027 in `docs/adr-log.md` for the boundary decision.
