"""
Comprehensive tests for LocationManager with extensive logging.

These tests verify:
- Location creation and hierarchy management
- Entity-to-location mappings
- Module configuration storage and retrieval
- Graph queries (parent, children, ancestors, descendants)
- Error handling and edge cases
"""

import logging

import pytest

from home_topology import LocationManager

# Configure logging for verbose test output
logging.basicConfig(
    level=logging.DEBUG, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)

logger = logging.getLogger(__name__)


class TestLocationManagerCreation:
    """Test suite for location creation."""

    def test_create_root_location(self):
        """Test creating a root location (no parent)."""
        logger.info("=" * 80)
        logger.info("TEST: Create root location")
        logger.info("=" * 80)

        mgr = LocationManager()
        logger.debug("Created LocationManager instance")

        logger.info("Creating root location: 'house'")
        house = mgr.create_location(id="house", name="My House")

        logger.info(f"✓ Created location: {house.id} - {house.name}")
        logger.debug(f"  parent_id: {house.parent_id}")
        logger.debug(f"  entity_ids: {house.entity_ids}")
        logger.debug(f"  modules: {house.modules}")

        assert house.id == "house"
        assert house.name == "My House"
        assert house.parent_id is None
        logger.info("✓ Root location created successfully")

    def test_create_child_location(self):
        """Test creating a child location."""
        logger.info("=" * 80)
        logger.info("TEST: Create child location")
        logger.info("=" * 80)

        mgr = LocationManager()
        logger.debug("Created LocationManager instance")

        logger.info("Step 1: Create root location 'house'")
        house = mgr.create_location(id="house", name="House")
        logger.info(f"✓ Created: {house.id}")

        logger.info("Step 2: Create child location 'main_floor'")
        main_floor = mgr.create_location(id="main_floor", name="Main Floor", parent_id="house")
        logger.info(f"✓ Created: {main_floor.id} (parent: {main_floor.parent_id})")

        assert main_floor.parent_id == "house"
        logger.info("✓ Child location created successfully with correct parent")

    def test_create_complex_hierarchy(self):
        """Test creating a multi-level hierarchy."""
        logger.info("=" * 80)
        logger.info("TEST: Create complex location hierarchy")
        logger.info("=" * 80)

        mgr = LocationManager()
        logger.info("Building hierarchy: house -> main_floor -> kitchen")

        # Level 0: Root
        logger.info("Level 0: Creating root 'house'")
        house = mgr.create_location(id="house", name="House")
        logger.debug(f"  Created: {house.id}")

        # Level 1: Floor
        logger.info("Level 1: Creating 'main_floor' under 'house'")
        main_floor = mgr.create_location(id="main_floor", name="Main Floor", parent_id="house")
        logger.debug(f"  Created: {main_floor.id} -> parent: {main_floor.parent_id}")

        # Level 2: Room
        logger.info("Level 2: Creating 'kitchen' under 'main_floor'")
        kitchen = mgr.create_location(id="kitchen", name="Kitchen", parent_id="main_floor")
        logger.debug(f"  Created: {kitchen.id} -> parent: {kitchen.parent_id}")

        logger.info("Verifying hierarchy...")
        all_locs = mgr.all_locations()
        logger.info(f"Total locations: {len(all_locs)}")
        for loc in all_locs:
            logger.debug(f"  - {loc.id} (parent: {loc.parent_id or 'None'})")

        assert len(all_locs) == 3
        logger.info("✓ Complex hierarchy created successfully")

    def test_duplicate_location_error(self):
        """Test that duplicate location IDs are rejected."""
        logger.info("=" * 80)
        logger.info("TEST: Duplicate location ID error handling")
        logger.info("=" * 80)

        mgr = LocationManager()

        logger.info("Step 1: Create location 'kitchen'")
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("✓ First 'kitchen' created")

        logger.info("Step 2: Attempt to create duplicate 'kitchen'")
        try:
            mgr.create_location(id="kitchen", name="Another Kitchen")
            logger.error("✗ Expected ValueError but none was raised!")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            logger.info(f"✓ Correctly raised ValueError: {e}")
            assert "already exists" in str(e)

    def test_invalid_parent_error(self):
        """Test that invalid parent IDs are rejected."""
        logger.info("=" * 80)
        logger.info("TEST: Invalid parent ID error handling")
        logger.info("=" * 80)

        mgr = LocationManager()

        logger.info("Attempting to create location with non-existent parent")
        try:
            mgr.create_location(id="kitchen", name="Kitchen", parent_id="nonexistent")
            logger.error("✗ Expected ValueError but none was raised!")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            logger.info(f"✓ Correctly raised ValueError: {e}")
            assert "does not exist" in str(e)


class TestLocationManagerHierarchyQueries:
    """Test suite for hierarchy graph queries."""

    @pytest.fixture
    def simple_hierarchy(self):
        """Create a simple 3-level hierarchy for testing."""
        logger.info("Setting up simple hierarchy fixture")
        mgr = LocationManager()
        mgr.create_location(id="house", name="House")
        mgr.create_location(id="main_floor", name="Main Floor", parent_id="house")
        mgr.create_location(id="kitchen", name="Kitchen", parent_id="main_floor")
        logger.debug("Hierarchy: house -> main_floor -> kitchen")
        return mgr

    def test_parent_of(self, simple_hierarchy):
        """Test parent_of query."""
        logger.info("=" * 80)
        logger.info("TEST: parent_of() query")
        logger.info("=" * 80)

        mgr = simple_hierarchy

        logger.info("Query: parent_of('kitchen')")
        parent = mgr.parent_of("kitchen")
        logger.info(f"Result: {parent.id if parent else 'None'}")
        assert parent.id == "main_floor"
        logger.info("✓ Correct parent found")

        logger.info("Query: parent_of('main_floor')")
        parent = mgr.parent_of("main_floor")
        logger.info(f"Result: {parent.id if parent else 'None'}")
        assert parent.id == "house"
        logger.info("✓ Correct parent found")

        logger.info("Query: parent_of('house')")
        parent = mgr.parent_of("house")
        logger.info(f"Result: {parent.id if parent else 'None'}")
        assert parent is None
        logger.info("✓ Root has no parent")

    def test_children_of(self, simple_hierarchy):
        """Test children_of query."""
        logger.info("=" * 80)
        logger.info("TEST: children_of() query")
        logger.info("=" * 80)

        mgr = simple_hierarchy

        logger.info("Query: children_of('house')")
        children = mgr.children_of("house")
        logger.info(f"Found {len(children)} children")
        for child in children:
            logger.debug(f"  - {child.id}")
        assert len(children) == 1
        assert children[0].id == "main_floor"
        logger.info("✓ Correct children found")

        logger.info("Query: children_of('main_floor')")
        children = mgr.children_of("main_floor")
        logger.info(f"Found {len(children)} children")
        for child in children:
            logger.debug(f"  - {child.id}")
        assert len(children) == 1
        assert children[0].id == "kitchen"
        logger.info("✓ Correct children found")

        logger.info("Query: children_of('kitchen')")
        children = mgr.children_of("kitchen")
        logger.info(f"Found {len(children)} children")
        assert len(children) == 0
        logger.info("✓ Leaf node has no children")

    def test_ancestors_of(self, simple_hierarchy):
        """Test ancestors_of query."""
        logger.info("=" * 80)
        logger.info("TEST: ancestors_of() query")
        logger.info("=" * 80)

        mgr = simple_hierarchy

        logger.info("Query: ancestors_of('kitchen')")
        ancestors = mgr.ancestors_of("kitchen")
        logger.info(f"Found {len(ancestors)} ancestors")
        for i, ancestor in enumerate(ancestors):
            logger.debug(f"  {i}: {ancestor.id}")

        assert len(ancestors) == 2
        assert ancestors[0].id == "main_floor"  # Direct parent
        assert ancestors[1].id == "house"  # Grandparent
        logger.info("✓ All ancestors found in correct order (parent to root)")

    def test_descendants_of(self, simple_hierarchy):
        """Test descendants_of query."""
        logger.info("=" * 80)
        logger.info("TEST: descendants_of() query")
        logger.info("=" * 80)

        mgr = simple_hierarchy

        logger.info("Query: descendants_of('house')")
        descendants = mgr.descendants_of("house")
        logger.info(f"Found {len(descendants)} descendants")
        descendant_ids = {d.id for d in descendants}
        for desc_id in descendant_ids:
            logger.debug(f"  - {desc_id}")

        assert len(descendants) == 2
        assert "main_floor" in descendant_ids
        assert "kitchen" in descendant_ids
        logger.info("✓ All descendants found")


class TestLocationManagerEntityMapping:
    """Test suite for entity-to-location mapping."""

    def test_add_entity_to_location(self):
        """Test mapping entities to locations."""
        logger.info("=" * 80)
        logger.info("TEST: Add entity to location")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created location: kitchen")

        logger.info("Adding entity: binary_sensor.kitchen_motion")
        mgr.add_entity_to_location("binary_sensor.kitchen_motion", "kitchen")
        logger.info("✓ Entity added")

        logger.info("Verifying entity mapping...")
        location_id = mgr.get_entity_location("binary_sensor.kitchen_motion")
        logger.info(f"Entity location: {location_id}")
        assert location_id == "kitchen"

        logger.info("Verifying entity appears in location's entity_ids...")
        kitchen = mgr.get_location("kitchen")
        logger.debug(f"Kitchen entity_ids: {kitchen.entity_ids}")
        assert "binary_sensor.kitchen_motion" in kitchen.entity_ids
        logger.info("✓ Entity successfully mapped to location")

    def test_move_entity_between_locations(self):
        """Test moving an entity from one location to another."""
        logger.info("=" * 80)
        logger.info("TEST: Move entity between locations")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        mgr.create_location(id="living_room", name="Living Room")
        logger.info("Created locations: kitchen, living_room")

        entity = "sensor.temp_sensor"

        logger.info(f"Step 1: Add {entity} to kitchen")
        mgr.add_entity_to_location(entity, "kitchen")
        logger.info(f"✓ {entity} -> kitchen")
        logger.debug(f"Kitchen entities: {mgr.get_location('kitchen').entity_ids}")

        logger.info(f"Step 2: Move {entity} to living_room")
        mgr.add_entity_to_location(entity, "living_room")
        logger.info(f"✓ {entity} -> living_room")

        logger.info("Verifying entity removed from kitchen...")
        kitchen = mgr.get_location("kitchen")
        logger.debug(f"Kitchen entities: {kitchen.entity_ids}")
        assert entity not in kitchen.entity_ids
        logger.info("✓ Entity removed from old location")

        logger.info("Verifying entity added to living_room...")
        living_room = mgr.get_location("living_room")
        logger.debug(f"Living room entities: {living_room.entity_ids}")
        assert entity in living_room.entity_ids
        logger.info("✓ Entity added to new location")

        logger.info("Verifying entity mapping updated...")
        location_id = mgr.get_entity_location(entity)
        logger.debug(f"Entity location: {location_id}")
        assert location_id == "living_room"
        logger.info("✓ Entity successfully moved")

    def test_add_entity_to_invalid_location(self):
        """Test that adding entity to invalid location raises error."""
        logger.info("=" * 80)
        logger.info("TEST: Add entity to invalid location")
        logger.info("=" * 80)

        mgr = LocationManager()

        logger.info("Attempting to add entity to non-existent location")
        try:
            mgr.add_entity_to_location("sensor.test", "nonexistent")
            logger.error("✗ Expected ValueError but none was raised!")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            logger.info(f"✓ Correctly raised ValueError: {e}")
            assert "does not exist" in str(e)


class TestLocationManagerModuleConfig:
    """Test suite for module configuration storage."""

    def test_set_and_get_module_config(self):
        """Test storing and retrieving module configuration."""
        logger.info("=" * 80)
        logger.info("TEST: Set and get module configuration")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created location: kitchen")

        config = {
            "version": 1,
            "enabled": True,
            "timeouts": {
                "motion": 300,
                "presence": 600,
            },
        }

        logger.info("Setting module config for 'occupancy' on kitchen")
        logger.debug(f"Config: {config}")
        mgr.set_module_config("kitchen", "occupancy", config)
        logger.info("✓ Config stored")

        logger.info("Retrieving module config...")
        retrieved = mgr.get_module_config("kitchen", "occupancy")
        logger.debug(f"Retrieved: {retrieved}")

        assert retrieved == config
        assert retrieved["timeouts"]["motion"] == 300
        logger.info("✓ Config retrieved successfully")

    def test_multiple_module_configs(self):
        """Test storing multiple module configurations."""
        logger.info("=" * 80)
        logger.info("TEST: Multiple module configurations")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created location: kitchen")

        logger.info("Setting config for 'occupancy' module")
        occupancy_config = {"enabled": True, "timeout": 300}
        mgr.set_module_config("kitchen", "occupancy", occupancy_config)
        logger.debug(f"Occupancy config: {occupancy_config}")

        logger.info("Setting config for 'energy' module")
        energy_config = {"track_power": True}
        mgr.set_module_config("kitchen", "energy", energy_config)
        logger.debug(f"Energy config: {energy_config}")

        logger.info("Verifying both configs are stored independently...")
        occ_retrieved = mgr.get_module_config("kitchen", "occupancy")
        energy_retrieved = mgr.get_module_config("kitchen", "energy")

        logger.debug(f"Occupancy retrieved: {occ_retrieved}")
        logger.debug(f"Energy retrieved: {energy_retrieved}")

        assert occ_retrieved == occupancy_config
        assert energy_retrieved == energy_config
        logger.info("✓ Multiple module configs stored successfully")

    def test_get_nonexistent_module_config(self):
        """Test getting config for non-existent module."""
        logger.info("=" * 80)
        logger.info("TEST: Get non-existent module config")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created location: kitchen")

        logger.info("Attempting to get config for non-existent module")
        config = mgr.get_module_config("kitchen", "nonexistent")
        logger.info(f"Result: {config}")

        assert config is None
        logger.info("✓ Returns None for non-existent module")


class TestLocationManagerComplexScenarios:
    """Test suite for complex real-world scenarios."""

    def test_full_house_topology(self):
        """Test creating a realistic house topology."""
        logger.info("=" * 80)
        logger.info("TEST: Full house topology")
        logger.info("=" * 80)

        mgr = LocationManager()

        logger.info("Building realistic house topology...")
        logger.info("Level 0: House")
        mgr.create_location(id="house", name="House")

        logger.info("Level 1: Floors")
        mgr.create_location(id="main_floor", name="Main Floor", parent_id="house")
        mgr.create_location(id="upper_floor", name="Upper Floor", parent_id="house")
        mgr.create_location(id="basement", name="Basement", parent_id="house")

        logger.info("Level 2: Rooms on main floor")
        mgr.create_location(id="kitchen", name="Kitchen", parent_id="main_floor")
        mgr.create_location(id="living_room", name="Living Room", parent_id="main_floor")
        mgr.create_location(id="dining_room", name="Dining Room", parent_id="main_floor")

        logger.info("Level 2: Rooms on upper floor")
        mgr.create_location(id="master_bedroom", name="Master Bedroom", parent_id="upper_floor")
        mgr.create_location(id="bedroom_2", name="Bedroom 2", parent_id="upper_floor")

        logger.info("Level 2: Basement areas")
        mgr.create_location(id="garage", name="Garage", parent_id="basement")

        all_locs = mgr.all_locations()
        logger.info(f"Total locations created: {len(all_locs)}")

        logger.info("Topology structure:")
        for loc in all_locs:
            parent_name = ""
            if loc.parent_id:
                parent = mgr.get_location(loc.parent_id)
                parent_name = f" (parent: {parent.name})"
            logger.debug(f"  - {loc.name}{parent_name}")

        assert len(all_locs) == 10
        logger.info("✓ Full house topology created successfully")

        logger.info("Testing descendant query on 'house'...")
        house_descendants = mgr.descendants_of("house")
        logger.info(f"House has {len(house_descendants)} descendants")
        assert len(house_descendants) == 9
        logger.info("✓ All descendants found")

        logger.info("Testing children query on 'main_floor'...")
        main_floor_children = mgr.children_of("main_floor")
        logger.info(f"Main floor has {len(main_floor_children)} children")
        child_names = [c.name for c in main_floor_children]
        logger.debug(f"Children: {', '.join(child_names)}")
        assert len(main_floor_children) == 3
        logger.info("✓ Main floor children correct")


class TestLocationManagerAliases:
    """Test suite for location alias management."""

    def test_create_location_with_aliases(self):
        """Test creating a location with initial aliases."""
        logger.info("=" * 80)
        logger.info("TEST: Create location with aliases")
        logger.info("=" * 80)

        mgr = LocationManager()
        logger.info("Creating location with aliases")

        kitchen = mgr.create_location(
            id="kitchen",
            name="Kitchen",
            aliases=["Cuisine", "Cooking Area", "Chef's Domain"],
        )

        logger.info(f"✓ Created location: {kitchen.name}")
        logger.debug(f"  Aliases: {kitchen.aliases}")

        assert len(kitchen.aliases) == 3
        assert "Cuisine" in kitchen.aliases
        assert "Cooking Area" in kitchen.aliases
        assert "Chef's Domain" in kitchen.aliases
        logger.info("✓ Aliases set correctly")

    def test_add_single_alias(self):
        """Test adding a single alias to a location."""
        logger.info("=" * 80)
        logger.info("TEST: Add single alias")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="living_room", name="Living Room")
        logger.info("Created location: living_room")

        logger.info("Adding alias: 'Lounge'")
        mgr.add_alias("living_room", "Lounge")
        logger.info("✓ Alias added")

        location = mgr.get_location("living_room")
        logger.debug(f"Aliases: {location.aliases}")
        assert "Lounge" in location.aliases
        logger.info("✓ Alias successfully added")

    def test_add_multiple_aliases(self):
        """Test adding multiple aliases at once."""
        logger.info("=" * 80)
        logger.info("TEST: Add multiple aliases")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="living_room", name="Living Room")
        logger.info("Created location: living_room")

        aliases = ["Lounge", "TV Room", "Front Room"]
        logger.info(f"Adding aliases: {aliases}")
        mgr.add_aliases("living_room", aliases)
        logger.info("✓ Aliases added")

        location = mgr.get_location("living_room")
        logger.debug(f"Aliases: {location.aliases}")
        assert len(location.aliases) == 3
        for alias in aliases:
            assert alias in location.aliases
        logger.info("✓ All aliases successfully added")

    def test_add_duplicate_alias(self):
        """Test that duplicate aliases are ignored."""
        logger.info("=" * 80)
        logger.info("TEST: Add duplicate alias")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="living_room", name="Living Room")
        logger.info("Created location: living_room")

        logger.info("Adding alias: 'Lounge'")
        mgr.add_alias("living_room", "Lounge")
        logger.info("✓ First 'Lounge' added")

        logger.info("Adding duplicate alias: 'Lounge'")
        mgr.add_alias("living_room", "Lounge")
        logger.info("✓ Duplicate ignored")

        location = mgr.get_location("living_room")
        logger.debug(f"Aliases: {location.aliases}")
        assert location.aliases.count("Lounge") == 1
        logger.info("✓ Duplicate alias correctly ignored")

    def test_remove_alias(self):
        """Test removing an alias from a location."""
        logger.info("=" * 80)
        logger.info("TEST: Remove alias")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="living_room", name="Living Room", aliases=["Lounge", "TV Room"])
        logger.info("Created location with aliases")

        logger.info("Removing alias: 'Lounge'")
        mgr.remove_alias("living_room", "Lounge")
        logger.info("✓ Alias removed")

        location = mgr.get_location("living_room")
        logger.debug(f"Remaining aliases: {location.aliases}")
        assert "Lounge" not in location.aliases
        assert "TV Room" in location.aliases
        logger.info("✓ Alias successfully removed, others preserved")

    def test_remove_nonexistent_alias(self):
        """Test that removing non-existent alias is a no-op."""
        logger.info("=" * 80)
        logger.info("TEST: Remove non-existent alias")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="living_room", name="Living Room", aliases=["Lounge"])
        logger.info("Created location with one alias")

        logger.info("Removing non-existent alias: 'TV Room'")
        mgr.remove_alias("living_room", "TV Room")
        logger.info("✓ No error raised")

        location = mgr.get_location("living_room")
        logger.debug(f"Aliases: {location.aliases}")
        assert location.aliases == ["Lounge"]
        logger.info("✓ Existing aliases unchanged")

    def test_set_aliases(self):
        """Test replacing all aliases at once."""
        logger.info("=" * 80)
        logger.info("TEST: Set (replace) aliases")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="living_room", name="Living Room", aliases=["Old1", "Old2"])
        logger.info("Created location with old aliases")

        new_aliases = ["New1", "New2", "New3"]
        logger.info(f"Setting new aliases: {new_aliases}")
        mgr.set_aliases("living_room", new_aliases)
        logger.info("✓ Aliases replaced")

        location = mgr.get_location("living_room")
        logger.debug(f"Aliases: {location.aliases}")
        assert location.aliases == new_aliases
        assert "Old1" not in location.aliases
        logger.info("✓ All aliases replaced successfully")

    def test_find_by_alias(self):
        """Test finding a location by alias."""
        logger.info("=" * 80)
        logger.info("TEST: Find location by alias")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="living_room", name="Living Room", aliases=["Lounge", "TV Room"])
        mgr.create_location(id="kitchen", name="Kitchen", aliases=["Cuisine"])
        logger.info("Created two locations with aliases")

        logger.info("Finding location by alias: 'Lounge'")
        location = mgr.find_by_alias("Lounge")
        logger.info(f"Found: {location.name if location else 'None'}")
        assert location is not None
        assert location.id == "living_room"
        logger.info("✓ Location found by alias")

        logger.info("Finding location by alias: 'Cuisine'")
        location = mgr.find_by_alias("Cuisine")
        logger.info(f"Found: {location.name if location else 'None'}")
        assert location is not None
        assert location.id == "kitchen"
        logger.info("✓ Location found by alias")

        logger.info("Finding location by non-existent alias")
        location = mgr.find_by_alias("NonExistent")
        logger.info(f"Found: {location.name if location else 'None'}")
        assert location is None
        logger.info("✓ Returns None for non-existent alias")

    def test_get_location_by_name(self):
        """Test finding a location by name."""
        logger.info("=" * 80)
        logger.info("TEST: Get location by name")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="living_room", name="Living Room")
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created two locations")

        logger.info("Finding location by name: 'Kitchen'")
        location = mgr.get_location_by_name("Kitchen")
        logger.info(f"Found: {location.name if location else 'None'}")
        assert location is not None
        assert location.id == "kitchen"
        logger.info("✓ Location found by name")

        logger.info("Finding location by non-existent name")
        location = mgr.get_location_by_name("NonExistent")
        logger.info(f"Found: {location.name if location else 'None'}")
        assert location is None
        logger.info("✓ Returns None for non-existent name")

    def test_alias_invalid_location(self):
        """Test that alias operations on invalid location raise error."""
        logger.info("=" * 80)
        logger.info("TEST: Alias operations on invalid location")
        logger.info("=" * 80)

        mgr = LocationManager()

        logger.info("Attempting to add alias to non-existent location")
        try:
            mgr.add_alias("nonexistent", "Alias")
            logger.error("✗ Expected ValueError but none was raised!")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            logger.info(f"✓ Correctly raised ValueError: {e}")


class TestLocationManagerBatchOperations:
    """Test suite for batch entity operations."""

    def test_add_entities_to_location(self):
        """Test adding multiple entities at once."""
        logger.info("=" * 80)
        logger.info("TEST: Add multiple entities to location")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created location: kitchen")

        entities = [
            "light.kitchen_main",
            "light.kitchen_under_cabinet",
            "binary_sensor.kitchen_motion",
        ]
        logger.info(f"Adding {len(entities)} entities")
        mgr.add_entities_to_location(entities, "kitchen")
        logger.info("✓ Entities added")

        kitchen = mgr.get_location("kitchen")
        logger.debug(f"Kitchen entities: {kitchen.entity_ids}")
        assert len(kitchen.entity_ids) == 3
        for entity in entities:
            assert entity in kitchen.entity_ids
        logger.info("✓ All entities successfully added")

    def test_remove_entities_from_location(self):
        """Test removing multiple entities from their locations."""
        logger.info("=" * 80)
        logger.info("TEST: Remove multiple entities from location")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        mgr.create_location(id="living_room", name="Living Room")
        logger.info("Created two locations")

        # Add entities to different locations
        mgr.add_entity_to_location("light.kitchen_1", "kitchen")
        mgr.add_entity_to_location("light.kitchen_2", "kitchen")
        mgr.add_entity_to_location("light.living_1", "living_room")
        logger.info("Added entities to locations")

        # Remove multiple entities
        entities_to_remove = ["light.kitchen_1", "light.living_1"]
        logger.info(f"Removing entities: {entities_to_remove}")
        mgr.remove_entities_from_location(entities_to_remove)
        logger.info("✓ Entities removed")

        # Verify removals
        kitchen = mgr.get_location("kitchen")
        living_room = mgr.get_location("living_room")
        logger.debug(f"Kitchen entities: {kitchen.entity_ids}")
        logger.debug(f"Living room entities: {living_room.entity_ids}")

        assert "light.kitchen_1" not in kitchen.entity_ids
        assert "light.kitchen_2" in kitchen.entity_ids  # Should still be there
        assert "light.living_1" not in living_room.entity_ids
        logger.info("✓ Entities successfully removed from their locations")

    def test_remove_nonexistent_entity(self):
        """Test that removing non-existent entity is a no-op."""
        logger.info("=" * 80)
        logger.info("TEST: Remove non-existent entity")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created location")

        logger.info("Removing non-existent entity")
        mgr.remove_entities_from_location(["nonexistent.entity"])
        logger.info("✓ No error raised")

    def test_move_entities(self):
        """Test moving multiple entities between locations."""
        logger.info("=" * 80)
        logger.info("TEST: Move multiple entities between locations")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        mgr.create_location(id="dining_room", name="Dining Room")
        logger.info("Created two locations")

        # Add entities to kitchen
        entities = ["light.1", "light.2", "light.3"]
        mgr.add_entities_to_location(entities, "kitchen")
        logger.info(f"Added {len(entities)} entities to kitchen")

        # Move two entities to dining room
        entities_to_move = ["light.1", "light.2"]
        logger.info(f"Moving {len(entities_to_move)} entities to dining_room")
        mgr.move_entities(entities_to_move, "dining_room")
        logger.info("✓ Entities moved")

        # Verify
        kitchen = mgr.get_location("kitchen")
        dining_room = mgr.get_location("dining_room")
        logger.debug(f"Kitchen entities: {kitchen.entity_ids}")
        logger.debug(f"Dining room entities: {dining_room.entity_ids}")

        assert "light.1" not in kitchen.entity_ids
        assert "light.2" not in kitchen.entity_ids
        assert "light.3" in kitchen.entity_ids  # Should still be there

        assert "light.1" in dining_room.entity_ids
        assert "light.2" in dining_room.entity_ids
        logger.info("✓ Entities successfully moved")

    def test_move_entities_to_invalid_location(self):
        """Test that moving entities to invalid location raises error."""
        logger.info("=" * 80)
        logger.info("TEST: Move entities to invalid location")
        logger.info("=" * 80)

        mgr = LocationManager()

        logger.info("Attempting to move entities to non-existent location")
        try:
            mgr.move_entities(["light.1"], "nonexistent")
            logger.error("✗ Expected ValueError but none was raised!")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            logger.info(f"✓ Correctly raised ValueError: {e}")

    def test_batch_operations_empty_list(self):
        """Test batch operations with empty lists."""
        logger.info("=" * 80)
        logger.info("TEST: Batch operations with empty lists")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created location")

        logger.info("Adding empty list of entities")
        mgr.add_entities_to_location([], "kitchen")
        logger.info("✓ No error raised")

        logger.info("Removing empty list of entities")
        mgr.remove_entities_from_location([])
        logger.info("✓ No error raised")

        logger.info("Moving empty list of entities")
        mgr.move_entities([], "kitchen")
        logger.info("✓ No error raised")


class TestLocationManagerUpdate:
    """Test suite for location updates."""

    def test_update_location_name(self):
        """Test updating a location's name."""
        logger.info("=" * 80)
        logger.info("TEST: Update location name")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created location")

        logger.info("Updating name to 'Updated Kitchen'")
        updated = mgr.update_location("kitchen", name="Updated Kitchen")
        logger.info(f"✓ Updated: {updated.name}")

        location = mgr.get_location("kitchen")
        assert location.name == "Updated Kitchen"
        logger.info("✓ Name updated successfully")

    def test_update_location_parent(self):
        """Test reparenting a location."""
        logger.info("=" * 80)
        logger.info("TEST: Update location parent")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="house", name="House")
        mgr.create_location(id="floor1", name="Floor 1", parent_id="house")
        mgr.create_location(id="floor2", name="Floor 2", parent_id="house")
        mgr.create_location(id="kitchen", name="Kitchen", parent_id="floor1")
        logger.info("Created hierarchy: house -> [floor1, floor2], floor1 -> kitchen")

        logger.info("Moving kitchen from floor1 to floor2")
        updated = mgr.update_location("kitchen", parent_id="floor2")
        logger.info(f"✓ Updated parent: {updated.parent_id}")

        location = mgr.get_location("kitchen")
        assert location.parent_id == "floor2"
        assert "kitchen" in [c.id for c in mgr.children_of("floor2")]
        assert "kitchen" not in [c.id for c in mgr.children_of("floor1")]
        logger.info("✓ Parent updated successfully")

    def test_update_location_clear_parent(self):
        """Test clearing a location's parent (move to Inbox)."""
        logger.info("=" * 80)
        logger.info("TEST: Clear location parent")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="house", name="House")
        mgr.create_location(id="kitchen", name="Kitchen", parent_id="house")
        logger.info("Created location with parent")

        logger.info("Clearing parent (moving to Inbox)")
        updated = mgr.update_location("kitchen", parent_id="")
        logger.info(f"✓ Updated parent: {updated.parent_id}")

        location = mgr.get_location("kitchen")
        assert location.parent_id is None
        assert location.is_explicit_root is False  # Should be in Inbox
        logger.info("✓ Parent cleared successfully")

    def test_update_location_aliases(self):
        """Test updating location aliases."""
        logger.info("=" * 80)
        logger.info("TEST: Update location aliases")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen", aliases=["cooking area"])
        logger.info("Created location with aliases")

        logger.info("Updating aliases")
        updated = mgr.update_location("kitchen", aliases=["cooking room", "food prep"])
        logger.info(f"✓ Updated aliases: {updated.aliases}")

        location = mgr.get_location("kitchen")
        assert location.aliases == ["cooking room", "food prep"]
        logger.info("✓ Aliases updated successfully")

    def test_update_location_multiple_fields(self):
        """Test updating multiple fields at once."""
        logger.info("=" * 80)
        logger.info("TEST: Update multiple location fields")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created location")

        logger.info("Updating name, aliases, and ha_area_id")
        updated = mgr.update_location(
            "kitchen",
            name="Updated Kitchen",
            aliases=["cooking area"],
            ha_area_id="area_123",
        )
        logger.info(f"✓ Updated: {updated.name}, {updated.aliases}, {updated.ha_area_id}")

        location = mgr.get_location("kitchen")
        assert location.name == "Updated Kitchen"
        assert location.aliases == ["cooking area"]
        assert location.ha_area_id == "area_123"
        logger.info("✓ Multiple fields updated successfully")

    def test_update_nonexistent_location(self):
        """Test that updating non-existent location raises error."""
        logger.info("=" * 80)
        logger.info("TEST: Update non-existent location")
        logger.info("=" * 80)

        mgr = LocationManager()
        logger.info("Attempting to update non-existent location")
        try:
            mgr.update_location("nonexistent", name="New Name")
            logger.error("✗ Expected ValueError but none was raised!")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            logger.info(f"✓ Correctly raised ValueError: {e}")

    def test_update_location_invalid_parent(self):
        """Test that updating to invalid parent raises error."""
        logger.info("=" * 80)
        logger.info("TEST: Update location with invalid parent")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created location")

        logger.info("Attempting to set invalid parent")
        try:
            mgr.update_location("kitchen", parent_id="nonexistent")
            logger.error("✗ Expected ValueError but none was raised!")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            logger.info(f"✓ Correctly raised ValueError: {e}")

    def test_update_location_cycle_prevention(self):
        """Test that updating parent to create cycle raises error."""
        logger.info("=" * 80)
        logger.info("TEST: Prevent cycle when updating parent")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="house", name="House")
        mgr.create_location(id="floor1", name="Floor 1", parent_id="house")
        mgr.create_location(id="kitchen", name="Kitchen", parent_id="floor1")
        logger.info("Created hierarchy: house -> floor1 -> kitchen")

        logger.info("Attempting to make house a child of kitchen (would create cycle)")
        try:
            mgr.update_location("house", parent_id="kitchen")
            logger.error("✗ Expected ValueError but none was raised!")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            logger.info(f"✓ Correctly raised ValueError: {e}")

    def test_update_location_self_parent(self):
        """Test that location cannot be its own parent."""
        logger.info("=" * 80)
        logger.info("TEST: Prevent location being its own parent")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        logger.info("Created location")

        logger.info("Attempting to set location as its own parent")
        try:
            mgr.update_location("kitchen", parent_id="kitchen")
            logger.error("✗ Expected ValueError but none was raised!")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            logger.info(f"✓ Correctly raised ValueError: {e}")


class TestLocationManagerDelete:
    """Test suite for location deletion."""

    def test_delete_leaf_location(self):
        """Test deleting a location with no children."""
        logger.info("=" * 80)
        logger.info("TEST: Delete leaf location (no children)")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="house", name="House")
        mgr.create_location(id="kitchen", name="Kitchen", parent_id="house")
        mgr.add_entity_to_location("light.kitchen", "kitchen")
        logger.info("Created location with entity mapping")

        logger.info("Deleting kitchen location")
        deleted_ids = mgr.delete_location("kitchen")
        logger.info(f"✓ Deleted: {deleted_ids}")

        assert "kitchen" not in [loc.id for loc in mgr.all_locations()]
        assert mgr.get_location("kitchen") is None
        assert mgr.get_entity_location("light.kitchen") is None
        logger.info("✓ Location and entity mappings deleted successfully")

    def test_delete_location_with_children_prevent(self):
        """Test that deleting location with children raises error by default."""
        logger.info("=" * 80)
        logger.info("TEST: Prevent deletion of location with children")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="house", name="House")
        mgr.create_location(id="floor1", name="Floor 1", parent_id="house")
        mgr.create_location(id="kitchen", name="Kitchen", parent_id="floor1")
        logger.info("Created hierarchy: house -> floor1 -> kitchen")

        logger.info("Attempting to delete floor1 (has children)")
        try:
            mgr.delete_location("floor1")
            logger.error("✗ Expected ValueError but none was raised!")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            logger.info(f"✓ Correctly raised ValueError: {e}")

        # Verify nothing was deleted
        assert mgr.get_location("floor1") is not None
        assert mgr.get_location("kitchen") is not None
        logger.info("✓ Location and children preserved")

    def test_delete_location_cascade(self):
        """Test cascade deletion (delete location and all descendants)."""
        logger.info("=" * 80)
        logger.info("TEST: Cascade delete location and descendants")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="house", name="House")
        mgr.create_location(id="floor1", name="Floor 1", parent_id="house")
        mgr.create_location(id="kitchen", name="Kitchen", parent_id="floor1")
        mgr.create_location(id="bedroom", name="Bedroom", parent_id="floor1")
        logger.info("Created hierarchy: house -> floor1 -> [kitchen, bedroom]")

        logger.info("Deleting floor1 with cascade=True")
        deleted_ids = mgr.delete_location("floor1", cascade=True)
        logger.info(f"✓ Deleted locations: {deleted_ids}")

        assert "floor1" in deleted_ids
        assert "kitchen" in deleted_ids
        assert "bedroom" in deleted_ids
        assert len(deleted_ids) == 3

        assert mgr.get_location("floor1") is None
        assert mgr.get_location("kitchen") is None
        assert mgr.get_location("bedroom") is None
        assert mgr.get_location("house") is not None  # Parent should remain
        logger.info("✓ Cascade deletion successful")

    def test_delete_location_orphan_children(self):
        """Test orphan children option (move children to Inbox)."""
        logger.info("=" * 80)
        logger.info("TEST: Orphan children when deleting location")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="house", name="House")
        mgr.create_location(id="floor1", name="Floor 1", parent_id="house")
        mgr.create_location(id="kitchen", name="Kitchen", parent_id="floor1")
        logger.info("Created hierarchy: house -> floor1 -> kitchen")

        logger.info("Deleting floor1 with orphan_children=True")
        deleted_ids = mgr.delete_location("floor1", orphan_children=True)
        logger.info(f"✓ Deleted: {deleted_ids}")

        assert "floor1" in deleted_ids
        assert len(deleted_ids) == 1  # Only floor1 deleted

        assert mgr.get_location("floor1") is None
        kitchen = mgr.get_location("kitchen")
        assert kitchen is not None
        assert kitchen.parent_id is None  # Orphaned
        assert kitchen.is_explicit_root is False  # In Inbox
        logger.info("✓ Children orphaned successfully")

    def test_delete_location_entity_cleanup(self):
        """Test that entities are unmapped when location is deleted."""
        logger.info("=" * 80)
        logger.info("TEST: Entity cleanup on location deletion")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        mgr.add_entity_to_location("light.kitchen", "kitchen")
        mgr.add_entity_to_location("sensor.motion", "kitchen")
        logger.info("Created location with 2 entities")

        logger.info("Deleting location")
        deleted_ids = mgr.delete_location("kitchen")
        logger.info(f"✓ Deleted: {deleted_ids}")

        assert mgr.get_entity_location("light.kitchen") is None
        assert mgr.get_entity_location("sensor.motion") is None
        logger.info("✓ Entities unmapped successfully")

    def test_delete_location_module_config_cleanup(self):
        """Test that module configs are deleted with location."""
        logger.info("=" * 80)
        logger.info("TEST: Module config cleanup on location deletion")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="kitchen", name="Kitchen")
        mgr.set_module_config("kitchen", "occupancy", {"enabled": True})
        mgr.set_module_config("kitchen", "automation", {"rules": []})
        logger.info("Created location with module configs")

        logger.info("Deleting location")
        deleted_ids = mgr.delete_location("kitchen")
        logger.info(f"✓ Deleted: {deleted_ids}")

        # Configs are part of Location object, so deleted automatically
        location = mgr.get_location("kitchen")
        assert location is None
        logger.info("✓ Module configs deleted with location")

    def test_delete_nonexistent_location(self):
        """Test that deleting non-existent location raises error."""
        logger.info("=" * 80)
        logger.info("TEST: Delete non-existent location")
        logger.info("=" * 80)

        mgr = LocationManager()
        logger.info("Attempting to delete non-existent location")
        try:
            mgr.delete_location("nonexistent")
            logger.error("✗ Expected ValueError but none was raised!")
            assert False, "Should have raised ValueError"
        except ValueError as e:
            logger.info(f"✓ Correctly raised ValueError: {e}")

    def test_delete_location_cascade_complex_hierarchy(self):
        """Test cascade deletion on complex multi-level hierarchy."""
        logger.info("=" * 80)
        logger.info("TEST: Cascade delete complex hierarchy")
        logger.info("=" * 80)

        mgr = LocationManager()
        mgr.create_location(id="house", name="House")
        mgr.create_location(id="floor1", name="Floor 1", parent_id="house")
        mgr.create_location(id="floor2", name="Floor 2", parent_id="house")
        mgr.create_location(id="kitchen", name="Kitchen", parent_id="floor1")
        mgr.create_location(id="bedroom", name="Bedroom", parent_id="floor1")
        mgr.create_location(id="bathroom", name="Bathroom", parent_id="floor1")
        logger.info("Created: house -> [floor1, floor2], floor1 -> [kitchen, bedroom, bathroom]")

        logger.info("Deleting floor1 with cascade=True")
        deleted_ids = mgr.delete_location("floor1", cascade=True)
        logger.info(f"✓ Deleted: {deleted_ids}")

        assert len(deleted_ids) == 4  # floor1 + 3 children
        assert "floor1" in deleted_ids
        assert "kitchen" in deleted_ids
        assert "bedroom" in deleted_ids
        assert "bathroom" in deleted_ids

        # Verify all deleted
        for loc_id in deleted_ids:
            assert mgr.get_location(loc_id) is None

        # Verify floor2 and house remain
        assert mgr.get_location("floor2") is not None
        assert mgr.get_location("house") is not None
        logger.info("✓ Complex cascade deletion successful")


if __name__ == "__main__":
    # Enable running tests directly
    pytest.main([__file__, "-v", "-s"])
