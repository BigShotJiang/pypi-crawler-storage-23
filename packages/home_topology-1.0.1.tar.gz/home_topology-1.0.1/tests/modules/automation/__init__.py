"""Tests for the automation module."""
