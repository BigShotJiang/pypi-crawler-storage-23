"""Tests for the lighting module."""
