class DocumentParser:
    """Base class for all Parsers"""

    def parse(self):
        raise NotImplementedError
