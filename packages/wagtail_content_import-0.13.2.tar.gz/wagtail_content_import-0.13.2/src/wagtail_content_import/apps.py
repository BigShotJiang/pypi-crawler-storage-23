from django.apps import AppConfig


class WagtailContentImportAppConfig(AppConfig):
    name = "wagtail_content_import"
    label = "wagtail_content_import"
    verbose_name = "Wagtail Content Import"
