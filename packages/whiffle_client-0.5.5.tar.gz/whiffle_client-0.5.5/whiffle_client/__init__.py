from importlib.metadata import version

from whiffle_client.client import CONFIG_FILE_PATH_LOCATIONS, Client

__version__ = version("whiffle_client")

__all__ = [Client, CONFIG_FILE_PATH_LOCATIONS]
