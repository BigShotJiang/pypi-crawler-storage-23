from dataclasses import dataclass, field

from whiffle_client.common.components.base import BaseComponent
from whiffle_client.wind.components.organization import Organization


@dataclass
class CurrentUser(BaseComponent):
    email: str = field(default=None)
    role: str = field(default=None)
    zitadel_id: str = field(default=None)
    organization: Organization = field(default=None)
