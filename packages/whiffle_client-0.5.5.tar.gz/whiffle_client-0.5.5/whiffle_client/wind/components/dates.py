import datetime
from dataclasses import dataclass, field


@dataclass
class Dates:
    start: datetime.datetime = field(default=None)
    end: datetime.datetime = field(default=None)
