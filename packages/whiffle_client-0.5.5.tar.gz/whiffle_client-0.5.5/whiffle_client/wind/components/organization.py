from dataclasses import dataclass, field

from whiffle_client.common.components.base import BaseComponent


@dataclass
class Organization(BaseComponent):
    id: int = field(default=None)
    name: str = field(default=None)
    credits_left: float = field(default=None)
    credits_purchased: float = field(default=None)
    credits_free: float = field(default=None)
