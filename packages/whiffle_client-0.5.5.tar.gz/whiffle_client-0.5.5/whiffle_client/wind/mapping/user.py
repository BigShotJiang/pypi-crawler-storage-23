from whiffle_client.common.mapping.base import BaseMapping
from whiffle_client.wind.components.user import CurrentUser


class UserEndpoints(BaseMapping):
    URL = "/api/v1/users"

    def get_current(self) -> CurrentUser:
        """Get current user information

        Returns
        -------
        CurrentUser
            Current user information
        """
        return CurrentUser.from_dict(self.session.get_request(f"{self.session.server_url}{self.URL}/current").json())
