# simpleworkernet/__version__.py
__version__ = "0.0.3b32"
__author__ = "Andrey Litvinov"
__email__ = "busybeaver.bb@gmail.com"
__license__ = "MIT"