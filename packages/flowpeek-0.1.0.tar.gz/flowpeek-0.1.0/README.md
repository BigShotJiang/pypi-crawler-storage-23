# flowpeek

Simple flow visualization preview tool.

```bash
pip install flowpeek