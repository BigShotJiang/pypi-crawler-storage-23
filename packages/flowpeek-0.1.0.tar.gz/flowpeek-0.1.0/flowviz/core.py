import os
import sys
import subprocess
from pathlib import Path
from importlib.resources import files   # modern, reliable way

def flow_preview():
    """
    Preview internal flow visualization asset (bundled with the package).
    Opens the image in your default viewer if available.
    """
    try:
        # Preferred: importlib.resources (works in zip eggs, editable installs, etc.)
        img_path = files("flowviz") / "preview.png"
        img_bytes = img_path.read_bytes()  # confirm it exists
        path = Path(img_path)              # for opening
    except Exception:
        # Fallback if needed (usually not required)
        path = Path(__file__).parent / "preview.png"

    if not path.exists():
        return  # silent fail

    # Platform-specific open
    if sys.platform.startswith('win'):
        os.startfile(str(path))
    elif sys.platform == 'darwin':
        subprocess.call(['open', str(path)])
    else:
        try:
            subprocess.call(['xdg-open', str(path)])
        except:
            pass  # silent