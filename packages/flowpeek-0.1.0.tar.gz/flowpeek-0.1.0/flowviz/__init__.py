from .core import flow_preview

# Optional: alias for easier use
preview_flow = flow_preview