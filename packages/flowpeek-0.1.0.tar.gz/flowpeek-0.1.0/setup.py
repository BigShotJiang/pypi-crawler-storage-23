from setuptools import setup, find_packages

setup(
    name='flowfix',
    version='0.1.0',
    packages=find_packages(),
    include_package_data=True,
    description='Simple flow control optimizer',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='spinalgd',
    author_email='gordonsmith@gmail.com',
    license='MIT',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
    python_requires='>=3.7',
)