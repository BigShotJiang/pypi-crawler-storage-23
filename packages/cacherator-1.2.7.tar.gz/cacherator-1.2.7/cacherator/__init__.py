from .cacherator import JSONCache, Cached

__version__ = "1.2.7"
__all__ = ["JSONCache", "Cached"]