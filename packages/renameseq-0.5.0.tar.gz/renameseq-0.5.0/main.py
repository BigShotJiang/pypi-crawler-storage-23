import sys
import typer
from typer.main import Typer
from typing import Annotated
from pathlib import Path
from src.renameseq.console import console
from src.renameseq.check_filetype import check_filetype
from src.renameseq.check_map import check_map
from src.renameseq.check_answer import check_answer
from src.renameseq.create_rename_dir import create_renamed_dir
from src.renameseq.rename_files import rename_files
from src.renameseq.save_fasta import save_fasta
from src.renameseq.validade_renamed_files import validade_renamed_files

app: Typer = typer.Typer()

@app.command()
def main(
    plate_map: Annotated[Path,
    typer.Argument(help="Path to CSV file containing the plate map.")],
    sep: Annotated[str,
    typer.Argument(help="Delimiter of CSV entries.")] = ";"
) -> None:
    """
    Replace names of ABI sequencing result files with
    those defined by the user.

    This program comes with ABSOLUTELY NO WARRANTY.
    Use it at your own risk.
    """
    
    with console.status(
        status="[bold]Starting rename process![/bold]"
        ) as status:
        console.print("Checking files.")
        _ = check_filetype(dir=plate_map.parent)
        console.print("Checking names.")
        status.stop()
        df, table = check_map(plate_map, sep)
        console.print(table)
        check_answer(
            question="Is this plate map correct [yes/no]? ",
            bad=("Application closed."
                " Review your map and files."
                " No changes were made.")
            )
        status.start()
        console.print("Creating destination directory.")
        create_renamed_dir(working_dir=plate_map.parent)
        console.print("Renaming files.")
        rename_files(df, working_dir=plate_map.parent)
        console.print("Saving sequences as fasta.")
        save_fasta(df, working_dir=plate_map.parent)
        console.print("Validating renamed files.")
        bad_hases: list[str] = validade_renamed_files(
            df, working_dir=plate_map.parent
            )
    if not bad_hases:
        console.print("[bold green]Process finished successfully![/bold green]")
    else:
        console.print(
            "[bold yellow]Processes completed with some [/bold yellow]",
            "[bold yellow]bad files. Look at them carefully.[/bold yellow]"
        )


if __name__ == '__main__':
    try:
        app()
    except KeyboardInterrupt:
        console.print(
            "[bold red]Execution interrupted by the user.[/bold red]"
            )
        sys.exit(1)
