import sys
from pathlib import Path
from src.renameseq.console import console

def check_filetype(dir:Path) -> list[Path]:
    """
    Check if files inside target folder
    are in Applied Biosystems Inc. Format
    based on their header bytes.
    """

    file: Path = Path()
    files_list: list[Path] = []
    try:
        for file in Path(dir).glob(pattern="*.ab1"):
            if file.is_file():
                with open(file, mode='rb') as f:
                    header: bytes = f.read(128)
                    if header.startswith(b'ABIF'):
                        files_list.append(Path(file))
        if not files_list:
            console.print(
                "[bold yellow]No files to rename.[/bold yellow]"
            )
            sys.exit(0)
        console.print(
            f"[bold green]{len(files_list)} ABI sequence[/bold green]",
            f"[bold green]files in {dir} folder.[/bold green]"
            )
        return files_list
    except FileNotFoundError:
        console.print(
            f"[bold red]Could not find {file}.[/bold red]"
            )
        sys.exit(1)
    except PermissionError:
        console.print(
            f"[bold red]Could not access {file}.[/bold red]"
            )
        sys.exit(1)
    except Exception as e:
        console.print(
            f"[bold red]{e}[/bold red]"
            )
        sys.exit(1)
