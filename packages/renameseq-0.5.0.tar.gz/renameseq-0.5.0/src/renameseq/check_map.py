import contextlib
import sys
import csv
from typing import Any
from rich.table import Table
from rich import box
from rich.errors import NotRenderableError
from pathlib import Path
from src.renameseq.console import console

def check_map(plate_map:Path, sep:str) -> tuple[dict[str, str], Table]:
    """
    Opens and reads plate map, returning it and
    presenting it to user on the terminal.
    """

    well:list[str] = []
    new_name:list[str] = []

    try:
        with open(file=plate_map, mode="rt") as file:
            df: Any = csv.reader(  # pyright: ignore[reportExplicitAny]
                file,
                delimiter=sep
                )
            for row in df:  # pyright: ignore[reportAny]
                well.append(row[0]) # pyright: ignore[reportAny]
                new_name.append(row[1])  # pyright: ignore[reportAny]
            if not (len(set[str](new_name)) == len(new_name)):
                console.print(
                    "[bold red]There are repeated new names[/bold red]",
                    "[bold red]in your map, please make[/bold red]",
                    "[bold red]new names unique.[/bold red]",
                )
                sys.exit(1)
        table: Table = Table(
            title="Renaming Map",
            box=box.MINIMAL
        )
        table.add_column(header="Well")
        table.add_column(header="New Name")
        for i in range(len(well)):
            with contextlib.suppress(NotRenderableError):
                table.add_row(well[i], new_name[i])
        plate_dict: dict[str, str] = {
            well[i]: new_name[i] for i in range(len(well))
            }
        return plate_dict, table
    except FileNotFoundError:
        console.print(
            "[bold red]Map file not found.[/bold red]",
            "[bold red]Check filename and path.[/bold red]"
        )
        sys.exit(1)
    except PermissionError:
        console.print(
            "[bold red]Error accessing the map file.[/bold red]",
            "[bold red]Check file permissions.[/bold red]"
        )
        sys.exit(1)
