import sys
from src.renameseq.console import console
from rich.prompt import Confirm

yes_choices: list[str] = ['yes', 'y']
no_choices: list[str] = ['no', 'n']

def check_answer(question:str, bad:str) -> None:
    """
    Evaluates user answer and proceeds accordingly.
    """
    
    user_input: bool = Confirm.ask(question)
        
    if user_input:
        console.print(
            "[bold green]Nice! Let's continue...[/bold green]"
            )
    else:
        console.print(
            f"[bold red]{bad}[/bold red]"
            )
        sys.exit(0)
