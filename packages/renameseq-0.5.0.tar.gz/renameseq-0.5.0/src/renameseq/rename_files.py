import sys
import shutil
from pathlib import Path
from src.renameseq.console import console

def rename_files(df:dict[str, str], working_dir:Path) -> None:
    """
    Create a copy of original files
    with new names defined by the user in
    plate map.
    """

    for well, new_name in df.items():
        try:
            _ = shutil.copy2(
                f"{working_dir.joinpath(well + '.ab1')}",
                f"{working_dir.joinpath('renamed', new_name + '.ab1')}"
            )
        except FileNotFoundError:
            console.print(
                f"[bold red]'{well}.ab1' file not found.[/bold red]"
            )
            sys.exit(1)
        except PermissionError:
            console.print(
                f"[bold red]Could not access destination path.[/bold red]"
            )
            sys.exit(1)
        except Exception as e:
            console.print(
                f"[bold red]{e}[/bold red]"
            )
            sys.exit(1)
