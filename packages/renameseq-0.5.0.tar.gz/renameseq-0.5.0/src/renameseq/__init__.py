# SPDX-FileCopyrightText: 2026-present R. Aluizio <r.aluizio@gmail.com>
#
# SPDX-License-Identifier: LGPL-3.0-or-later
