import sys
from hashlib import sha3_512
from _hashlib import HASH
from pathlib import Path
from src.renameseq.console import console

def validade_renamed_files(df:dict[str, str], working_dir:Path) -> list[str]:
    """
    Compare SHA3-512 hashed of original and
    renamed files to ensure data fidelity.
    """

    bad_hashes: list[str] = []

    try:
        for well, new_name in df.items():
            with open(
                file=f"{working_dir.joinpath(well + '.ab1')}",
                mode='rb'
                ) as original, open(
                file=f"{working_dir.joinpath('renamed',
                new_name + '.ab1')}", mode="rb"
            ) as destination:
                original_hash: HASH = sha3_512(data=original.read())
                destination_hash: HASH = sha3_512(data=destination.read())
            if not original_hash.hexdigest() == destination_hash.hexdigest():
                bad_hashes.append(destination.name)
        if bad_hashes:
            console.print(
                "[bold red]The following files do not match:[/bold red]"
            )
            for bad in bad_hashes:
                console.print(
                    f"[red]\t \u2022 {bad}[/red]"
                )
            console.print(
                "[bold red]Ignore those files copies.[/bold red]",
                "[bold red]Delete them.[/bold red]",
                "[bold red]They are junk.[/bold red]"
            )
        return bad_hashes
    except Exception as e:
            console.print(
                f"[bold red]Validation Module error: {e}[/bold red]"
            )
            sys.exit(1)
