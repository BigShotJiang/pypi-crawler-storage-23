import sys
from pathlib import Path
from src.renameseq.console import console

def create_renamed_dir(working_dir: Path) -> None:
    """
    Create folder to store the renamed ABI files
    and fasta sequences.
    """

    renamed: Path = Path(working_dir, "renamed")

    try:
        if not renamed.is_dir():
            renamed.mkdir()
    except PermissionError:
        console.print(
            f"[bold red]Could not create {renamed}.[/bold red]",
            "[bold red]Permission denied.[/bold red]"
        )
        sys.exit(1)
    except Exception as e:
        console.print(
            f"[bold red]{e}[/bold red]"
        )
        sys.exit(1)