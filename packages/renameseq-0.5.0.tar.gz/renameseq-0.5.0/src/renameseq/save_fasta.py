import sys
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from pathlib import Path
from src.renameseq.console import console

def save_fasta(df:dict[str, str], working_dir:Path) -> None:
    """
    Using data from ab1 file, generates a fasta file
    containing the sequence.
    """

    for well, new_name in df.items():
        try:
            with open(
                file=f"{working_dir.joinpath(well + '.ab1')}",
                mode='rb'
                ) as input, open(
                file=f"{working_dir.joinpath(
                    'renamed',
                    new_name + '.fasta')}",
                    mode="wt") as output:
                seq: SeqRecord = SeqIO.read(handle=input, format='abi')  # pyright: ignore[reportUnknownMemberType]
                _ = SeqIO.write(sequences=seq, handle=output, format="fasta")  # pyright: ignore[reportUnknownMemberType]
        except FileNotFoundError:
            console.print(
                f"[bold red]Original ab1 file or[/bold red]",
                f"[bold red]fasta destination file not found.[/bold red]"
            )
            sys.exit(1)
        except PermissionError:
            console.print(
                f"[bold red]Could not access ab1 original[/bold red]",
                f"[bold red]file or fasta destination file.[/bold red]"
            )
            sys.exit(1)
        except Exception as e:
            console.print(
                f"[bold red]{e}[/bold red]"
            )
            sys.exit(1)
