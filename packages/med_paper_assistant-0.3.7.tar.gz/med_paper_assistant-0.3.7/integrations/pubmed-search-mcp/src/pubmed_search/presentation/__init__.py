"""
Presentation Layer - User Interface and External APIs

Contains:
- mcp_server: Model Context Protocol server and tools
- api: REST API (for Copilot Studio)
"""

from __future__ import annotations

from .mcp_server import create_server, main

# Alias for consistency
create_mcp_server = create_server

__all__ = [
    "create_mcp_server",
    "create_server",
    "main",
]
