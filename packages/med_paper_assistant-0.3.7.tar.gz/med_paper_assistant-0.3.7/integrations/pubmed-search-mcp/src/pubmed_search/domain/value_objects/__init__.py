"""Domain Value Objects."""
