---
name: pubmed-mcp-tools-reference
description: Complete reference for all 39 PubMed Search MCP tools. Triggers: 工具列表, all tools, 完整功能, tool reference, 有哪些工具
---

# PubMed Search MCP 工具完整參考

## 描述
所有 39 個 MCP 工具的完整參考，包含參數說明和使用範例。

> **⚠️ 注意**：此文件由 `scripts/count_mcp_tools.py --update-docs` 自動生成。
> 手動修改會在下次執行時被覆蓋。

---

## 工具分類總覽

| 類別 | 工具數 | 主要用途 |
|------|--------|----------|
| 搜尋工具 | 1 | 文獻搜索入口 |
| 查詢智能 | 3 | MeSH 擴展、PICO 解析 |
| 文章探索 | 5 | 相關文章、引用網路 |
| 全文工具 | 2 | 全文取得與文本挖掘 |
| NCBI 延伸 | 7 | Gene, PubChem, ClinVar |
| 引用網絡 | 1 | 引用樹建構與探索 |
| 匯出工具 | 1 | 引用格式匯出 |
| Session 管理 | 3 | PMID 暫存與歷史 |
| 機構訂閱 | 4 | OpenURL Link Resolver |
| 視覺搜索 | 1 | 圖片分析與搜索 (實驗性) |
| ICD 轉換 | 1 | ICD-10 與 MeSH 轉換 |
| 研究時間軸 | 3 | 研究演化追蹤與里程碑偵測 |
| 圖片搜尋 | 1 | 生物醫學圖片搜尋 |
| Pipeline 管理 | 6 | Pipeline 持久化、載入、排程 |

---

## 搜尋工具
*文獻搜索入口*

| 工具 | 說明 |
|------|------|
| `unified_search` | Unified Search - Single entry point for multi-source academic search. |

## 查詢智能
*MeSH 擴展、PICO 解析*

| 工具 | 說明 |
|------|------|
| `parse_pico` | Parse a clinical question into PICO elements OR accept pre-parsed PICO. |
| `generate_search_queries` | Gather search intelligence for a topic - returns RAW MATERIALS for Agent to decide. |
| `analyze_search_query` | Analyze a search query without executing the search. |

## 文章探索
*相關文章、引用網路*

| 工具 | 說明 |
|------|------|
| `fetch_article_details` | Fetch detailed information for one or more PubMed articles. |
| `find_related_articles` | Find articles related to a given PubMed article. |
| `find_citing_articles` | Find articles that cite a given PubMed article. |
| `get_article_references` | Get the references (bibliography) of a PubMed article. |
| `get_citation_metrics` | Get citation metrics from NIH iCite for articles. |

## 全文工具
*全文取得與文本挖掘*

| 工具 | 說明 |
|------|------|
| `get_fulltext` | Enhanced multi-source fulltext retrieval. |
| `get_text_mined_terms` | Get text-mined annotations from Europe PMC. |

## NCBI 延伸
*Gene, PubChem, ClinVar*

| 工具 | 說明 |
|------|------|
| `search_gene` | Search NCBI Gene database for gene information. |
| `get_gene_details` | Get detailed information about a gene by NCBI Gene ID. |
| `get_gene_literature` | Get PubMed articles linked to a gene. |
| `search_compound` | Search PubChem for chemical compounds. |
| `get_compound_details` | Get detailed information about a compound by PubChem CID. |
| `get_compound_literature` | Get PubMed articles linked to a compound. |
| `search_clinvar` | Search ClinVar for clinical variants. |

## 引用網絡
*引用樹建構與探索*

| 工具 | 說明 |
|------|------|
| `build_citation_tree` | Build a citation tree (network) from a single article. |

## 匯出工具
*引用格式匯出*

| 工具 | 說明 |
|------|------|
| `prepare_export` | Export citations to reference manager formats. |

## Session 管理
*PMID 暫存與歷史*

| 工具 | 說明 |
|------|------|
| `get_session_pmids` | 取得 session 中暫存的 PMID 列表。 |
| `get_cached_article` | 從 session 快取取得文章詳情。 |
| `get_session_summary` | 取得當前 session 的摘要資訊。 |

## 機構訂閱
*OpenURL Link Resolver*

| 工具 | 說明 |
|------|------|
| `configure_institutional_access` | Configure your institution's link resolver for full-text access. |
| `get_institutional_link` | Generate institutional access link (OpenURL) for an article. |
| `list_resolver_presets` | List available institutional link resolver presets. |
| `test_institutional_access` | Test your institutional link resolver configuration. |

## 視覺搜索
*圖片分析與搜索 (實驗性)*

| 工具 | 說明 |
|------|------|
| `analyze_figure_for_search` | Analyze a scientific figure or image for literature search. |

## ICD 轉換
*ICD-10 與 MeSH 轉換*

| 工具 | 說明 |
|------|------|
| `convert_icd_mesh` | Convert between ICD codes and MeSH terms (bidirectional). |

## 研究時間軸
*研究演化追蹤與里程碑偵測*

| 工具 | 說明 |
|------|------|
| `build_research_timeline` | Build a research timeline for a topic OR specific PMIDs. |
| `analyze_timeline_milestones` | Analyze milestone distribution for a research topic. |
| `compare_timelines` | Compare research timelines of multiple topics. |

## 圖片搜尋
*生物醫學圖片搜尋*

| 工具 | 說明 |
|------|------|
| `search_biomedical_images` | Search biomedical images across Open-i and Europe PMC. |

## Pipeline 管理
*Pipeline 持久化、載入、排程*

| 工具 | 說明 |
|------|------|
| `save_pipeline` | Save a pipeline configuration for later reuse. |
| `list_pipelines` | List all saved pipeline configurations. |
| `load_pipeline` | Load a pipeline configuration for review or editing. |
| `delete_pipeline` | Delete a saved pipeline configuration and its execution history. |
| `get_pipeline_history` | Get execution history for a saved pipeline. |
| `schedule_pipeline` | Schedule a saved pipeline for periodic execution. |

---

## 常用工作流程

### 快速搜尋
```
unified_search → fetch_article_details → prepare_export
```

### 系統性搜尋
```
generate_search_queries → unified_search × N → merge results
```

### PICO 搜尋
```
parse_pico → generate_search_queries × 4 → unified_search → merge results
```

### 論文探索
```
fetch_article_details → find_related_articles + find_citing_articles + build_citation_tree
```

### 全文取得
```
get_fulltext (自動嘗試 Europe PMC / CORE / CrossRef)
```

---

*Total: 39 tools in 14 categories*
*Auto-generated by `scripts/count_mcp_tools.py --update-docs`*
