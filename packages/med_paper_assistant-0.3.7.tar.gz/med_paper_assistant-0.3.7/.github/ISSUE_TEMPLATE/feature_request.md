---
name: Feature Request 功能請求
about: Suggest a new feature or enhancement
title: "[FEATURE] "
labels: enhancement
assignees: ""
---

## Problem 問題

What problem does this solve?

## Proposed Solution 建議方案

Describe the feature you'd like.

## Alternatives 替代方案

Any alternative approaches considered.

## Additional Context 附加資訊

Any other context, mockups, or references.
