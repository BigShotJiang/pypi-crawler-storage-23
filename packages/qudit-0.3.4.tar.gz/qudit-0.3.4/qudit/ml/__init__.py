from torch import nn

Hybrid = nn.Module
