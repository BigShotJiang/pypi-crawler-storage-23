from contextlib import contextmanager
import logging

dotpy = '.py'
inf = float('inf')
null_exc_info = None, None, None

class Forkable:

    @classmethod
    def _of(cls, *args, **kwargs):
        return cls(*args, **kwargs)

def initlogging():
    'Initialise the logging module to send debug (and higher levels) to stderr.'
    logging.basicConfig(format = "%(asctime)s %(levelname)s %(message)s", level = logging.DEBUG)

class Proxy:

    def __getattr__(self, name):
        try:
            return getattr(self._enclosinginstance, name)
        except AttributeError:
            superclass = super()
            try:
                supergetattr = superclass.__getattr__
            except AttributeError:
                raise AttributeError("'%s' object has no attribute '%s'" % (type(self).__name__, name))
            return supergetattr(name)

class InnerMeta(type):

    def __get__(self, enclosinginstance, owner):
        return self if enclosinginstance is None else type(self.__name__, (Proxy, self), dict(_enclosinginstance = enclosinginstance))

def innerclass(cls):
    'An instance of the decorated class may access its enclosing instance via `self`.'
    return InnerMeta(cls.__name__, (cls,), {})

def _rootcontext(e):
    while True:
        c = getattr(e, '__context__', None)
        if c is None:
            return e
        e = c

def invokeall(callables):
    '''Invoke every callable, even if one or more of them fail. This is mostly useful for synchronising with futures.
    If all succeeded return their return values as a list, otherwise raise all exceptions thrown as a chain.'''
    values = []
    failure = None
    for c in callables:
        try:
            obj = c()
        except Exception as e:
            _rootcontext(e).__context__ = failure
            failure = e
        else:
            values.append(obj)
    if failure is None:
        return values
    raise failure

@contextmanager
def onerror(f):
    '''Context manager that runs the given function if an exception happens, like `finally` excluding the happy path.
    Return a true value from `f` to declare the exception was handled i.e. prevent it from being re-raised.'''
    try:
        yield
    except:
        if not f():
            raise

def rmsuffix(text, suffix):
    'Return text with suffix removed, or `None` if text does not end with suffix.'
    if text.endswith(suffix):
        return text[:-len(suffix)]

def singleton(t):
    '''The decorated class is replaced with a no-arg instance.
    Can also be used to replace a factory function with its result.'''
    return t()

def solo(v):
    'Assert exactly one object in the given sequence and return it.'
    x, = v
    return x
