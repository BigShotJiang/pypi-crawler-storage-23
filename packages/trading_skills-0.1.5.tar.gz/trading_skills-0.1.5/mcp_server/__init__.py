# ABOUTME: MCP server package for trading analysis tools.
# ABOUTME: Run with: uv run python -m mcp_server.server
