# ABOUTME: Trading analysis library for market data, options, and portfolio management.
# ABOUTME: Provides unified API for Yahoo Finance and Interactive Brokers data.

__version__ = "0.1.0"
