---
title: Publish documentation and agent onboarding guides
type: change
authors:
- codex
created: 2025-10-21
---

Ship README, development, and user guides alongside AI agent context so contributors have a single place to learn the workflows and expectations for `tenzir-changelog`.
