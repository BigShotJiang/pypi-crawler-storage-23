---
title: Capture entries with a guided CLI flow
type: feature
authors:
- codex
created: 2025-10-21
---

Introduce the `tenzir-changelog add` workflow that gathers authors, pull requests, and entry types from the terminal, opens an editor for the body, and writes structured Markdown entries without manual file wrangling.
