---
title: Add --description-file option to add command
type: feature
author: mavam
component: cli
created: 2025-12-05T07:10:56.943326Z
---

The `add` command now accepts `--description-file` to read description content from a file. Use `-` to read from stdin, enabling piped input workflows.
