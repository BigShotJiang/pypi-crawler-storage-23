---
title: Refine compact Markdown exports
type: change
authors:
- codex
created: 2025-10-23
---

Compact Markdown exports now reuse the entry excerpt as the bullet text instead
of repeating the title, keep author and PR bylines inline with GitHub handles
prefixed by `@`, and end bullets with concise `(By … in #123)` annotations.
