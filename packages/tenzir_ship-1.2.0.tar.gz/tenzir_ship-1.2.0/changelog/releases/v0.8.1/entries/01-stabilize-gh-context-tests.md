---
title: Stabilize gh context tests
type: bugfix
authors:
- codex
created: 2025-11-10
---

Ensure CI test invocations clear GitHub actor environment variables so mocked gh responses win consistently.
