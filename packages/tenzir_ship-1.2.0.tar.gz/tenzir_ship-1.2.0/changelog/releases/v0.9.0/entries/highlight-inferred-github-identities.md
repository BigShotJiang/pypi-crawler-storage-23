---
title: Highlight inferred GitHub identities
type: change
authors:
- codex
- mavam
component: cli
created: 2025-11-10
---

GitHub login and pull request detection logs now render the inferred identifiers
in bold so they stand out without relying on prefixed punctuation.
