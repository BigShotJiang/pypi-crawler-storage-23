---
title: Simplify changelog configuration
type: change
authors:
- mavam
- codex
created: 2025-10-21
---

Drop the workspace section from `config.yaml` in favor of top-level project
metadata and update tooling, docs, and samples accordingly.
