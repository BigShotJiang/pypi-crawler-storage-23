---
title: Compact export output
type: feature
authors:
- mavam
- codex
created: 2025-10-21
---

Add an optional compact export mode that renders bullet lists with bold titles and first-paragraph excerpts for Markdown and JSON outputs.
