# fengkx_beancount_plugins

Beancount plugins packaged for installation via PyPI-compatible tooling.

Currently included:

- `check_non_negative`: enforce non-negative balances for selected accounts from a configured date.

## Installation

```bash
pip install fengkx_beancount_plugins
```

Or with `uv`:

```bash
uv add fengkx_beancount_plugins
```

## Beancount Usage

Add the plugin to your ledger:

```beancount
plugin "fengkx_beancount_plugins.check_non_negative"
```

Configure an account with `Open` metadata:

```beancount
2024-01-01 open Assets:Checking USD
  non_negative_from: 2024-01-01
```

When the running balance for that account becomes negative on or after the date,
the plugin reports a loader error.

## Development

```bash
uv sync --group dev
uv run ruff check .
uv run pytest
uv build
uv run twine check dist/*
```
