"""
Beancount plugin: enforce that specified accounts have non-negative balance
from a given date onward. Configuration is via Open directive meta:
  non_negative_from: 2024-01-01

Checks after every transaction (running balance like Fava's account journal).
Uses beancount.ops.pad + same summation as balance_by_account so balance matches Fava.
"""

from __future__ import annotations

import datetime
from collections import defaultdict

from beancount.core import data
from beancount.core.inventory import Inventory
from beancount.loader import LoadError
from beancount.ops import pad as pad_ops

__plugins__ = ["check_non_negative"]


def _parse_date(value: str | datetime.date) -> datetime.date | None:
    """Parse meta value to date. Accepts date or ISO string."""
    if isinstance(value, datetime.date):
        return value
    if isinstance(value, str):
        try:
            return datetime.date.fromisoformat(value.strip())
        except ValueError:
            return None
    return None


def check_non_negative(
    entries: list[data.Directive], options_map: dict
) -> tuple[list[data.Directive], list]:
    """
    Check that accounts with meta 'non_negative_from' never have negative
    balance on or after that date. Returns (entries, errors).
    Checks after every transaction (like Fava journal running balance).
    """
    errors: list[LoadError] = []

    # 1. Collect monitored accounts from Open entries (later overwrites earlier)
    monitored: dict[str, datetime.date] = {}
    for entry in entries:
        if not isinstance(entry, data.Open):
            continue
        val = entry.meta.get("non_negative_from") if entry.meta else None
        if val is None:
            continue
        parsed_date = _parse_date(val)
        if parsed_date is None:
            errors.append(
                LoadError(
                    entry.meta,
                    f"Invalid non_negative_from value for {entry.account}: {val!r} "
                    "(use YYYY-MM-DD)",
                    entry,
                )
            )
            continue
        monitored[entry.account] = parsed_date

    if not monitored:
        return entries, errors

    # 2. Get entries with Pad applied (same as loader → same as Fava)
    padded_entries, _ = pad_ops.pad(entries, options_map)

    # 3. Run through transactions in order; report at every transaction that
    # causes a transition from non-negative to negative (each "negative streak"),
    # so errors match Fava's journal 1:1.
    balances: dict[str, Inventory] = defaultdict(Inventory)
    was_negative_before: dict[str, bool] = {}
    causing_errors: list[tuple[str, data.Transaction, object]] = []

    for entry in padded_entries:
        if not isinstance(entry, data.Transaction):
            continue

        for account in monitored:
            if entry.date >= monitored[account]:
                was_negative_before[account] = any(
                    pos.units.number < 0 for pos in balances[account]
                )
            else:
                was_negative_before[account] = False

        for posting in entry.postings:
            if posting.account not in monitored or posting.units is None:
                continue
            try:
                balances[posting.account].add_position(posting)
            except Exception:
                continue

        for account, from_date in monitored.items():
            if entry.date < from_date:
                continue
            if was_negative_before[account]:
                continue
            inventory = balances[account]
            for pos in inventory:
                if pos.units.number < 0:
                    causing_errors.append((account, entry, pos))
                    break

    for account, entry, pos in causing_errors:
        from_date = monitored[account]
        errors.append(
            LoadError(
                entry.meta,
                f"Account {account} must not have negative balance from {from_date}: "
                f"end-of-day balance on {entry.date} was {pos.units.number} "
                f"{pos.units.currency}",
                entry,
            )
        )

    return entries, errors
