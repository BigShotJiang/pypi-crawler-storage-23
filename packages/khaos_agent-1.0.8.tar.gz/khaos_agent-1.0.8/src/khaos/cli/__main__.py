"""Entry point for running the CLI as a module."""

from khaos.cli import app

if __name__ == "__main__":
    app()
