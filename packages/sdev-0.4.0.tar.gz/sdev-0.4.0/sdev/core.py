"""
串口设备核心：连接、后台按行读、发送、按 flag 扫描/回显、清空缓存。
跨进程串口互斥：同一 port 的 connect 通过 fcntl.flock 阻塞等待，依次执行。

高层功能（shell、check_alive 等）放在上层模块中实现，例如 `sdev.demoboard.functional`。
"""

import fcntl
import os
import queue
import re
import threading
import time
from typing import Generator, Iterable, Literal, Optional

from loguru import logger
import serial

CTRL_C = "\x03"


def _port_lock_path(port: str) -> str:
    """锁文件路径：XDG_RUNTIME_DIR/sdev 或 ~/.cache/sdev，避免 /tmp。"""
    base = os.environ.get("XDG_RUNTIME_DIR") or os.path.join(os.path.expanduser("~"), ".cache")
    lock_dir = os.path.join(base, "sdev")
    os.makedirs(lock_dir, mode=0o700, exist_ok=True)
    safe = re.sub(r"[^a-zA-Z0-9_.-]", "_", os.path.basename(port))
    return os.path.join(lock_dir, f"port_{safe}.lock")


def _acquire_port_lock(port: str):
    """
    对 port 持有跨进程排他锁（阻塞直到拿到），返回打开的 fd，调用方负责 close。

    注意：这里是 sdev 的全局锁机制入口，请不要在上层重复实现文件锁。
    """
    path = _port_lock_path(port)
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    start = time.monotonic()
    last_log = start
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            now = time.monotonic()
            if now - last_log >= 5.0:
                waited = now - start
                logger.warning(
                    f"Waiting for cross-process serial lock on {port} "
                    f"for {waited:.1f} seconds; another sdev instance may be using this port."
                )
                last_log = now
            time.sleep(0.1)
    return fd


def _release_port_lock(fd: Optional[int]) -> None:
    if fd is None:
        return
    try:
        fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        try:
            os.close(fd)
        except OSError:
            pass


def _content_contains_ctrl_c(text: str) -> bool:
    """是否包含设备回显的 Ctrl+C（\\x03 或 ^C、^C\\x00 等）。"""
    n = text.replace("\x00", "")
    return CTRL_C in n or "^C" in n


def _line_matches_flag(line: str, flag: str) -> bool:
    """行（rstrip 后）是否以 flag 结尾；CTRL_C 兼容 \\x03 / \"^C\" 等回显形式。"""
    stripped = line.rstrip()
    if flag != CTRL_C:
        return stripped.endswith(flag)
    normalized = stripped.strip().replace("\x00", "")
    return normalized == CTRL_C or normalized == "^C" or normalized.endswith("^C") or stripped.endswith(flag)


_GREY = "\033[90m"
_SENT = "\033[36m"
_GREEN = "\033[32m"
_RESET = "\033[0m"

# 匹配已有的 ANSI 颜色转义，用于在高亮模式下去掉原始颜色
_ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-9;]*m")


class SerialDevice:
    STABLE_FLAG = " #"

    def __init__(self, port: str, baudrate: int = 115200):
        self.port = port
        self.baudrate = baudrate
        self._serial: Optional[serial.Serial] = None
        self._buffer: queue.Queue = queue.Queue()
        self._reader_thread: Optional[threading.Thread] = None
        self._is_connected = False
        self._stop_reading = False
        self._display = True
        # 跨进程串口锁 fd，connect 时持锁，disconnect 时释放
        self._lock_fd: Optional[int] = None

        # 扫描相关通用参数
        self._scan_timeout = 0.1
        self._max_lines_per_prompt = 4

    def _serial_reader(self) -> None:
        """
        后台 daemon：readline → UTF-8 解码 → put(line)；
        解码失败则跳过该行。disconnect 时 _stop_reading + put(None) 唤醒阻塞 get()。
        """
        while not self._stop_reading and self._serial is not None and self._serial.is_open:
            raw = self._serial.readline()
            if raw:
                try:
                    line = raw.decode("utf-8")
                    if line:
                        self._buffer.put(line)
                except UnicodeDecodeError:
                    continue

    def connect(self) -> None:
        """
        打开串口并启动后台读取线程；已连接则直接 return。
        同一 port 的多次 connect 会因跨进程锁而阻塞排队。
        """
        if self._is_connected:
            return
        self._lock_fd = _acquire_port_lock(self.port)  # 阻塞直到拿到串口锁
        try:
            self._serial = serial.Serial(self.port, self.baudrate, timeout=self._scan_timeout)
            if not self._serial.is_open:
                raise RuntimeError(f"无法打开串口 {self.port}")
            self._stop_reading = False
            self._reader_thread = threading.Thread(target=self._serial_reader, daemon=True)
            self._reader_thread.start()
            self._is_connected = True
        except Exception:
            _release_port_lock(self._lock_fd)
            self._lock_fd = None
            raise

    def disconnect(self) -> None:
        """
        关闭串口并停止后台线程；幂等。
        """
        if not self._is_connected:
            return
        self._stop_reading = True
        # 唤醒可能阻塞在 _buffer.get() 的 scan() 调用
        self._buffer.put(None)
        if self._reader_thread is not None and self._reader_thread.is_alive():
            self._reader_thread.join()
        self._reader_thread = None
        if self._serial is not None and self._serial.is_open:
            self._serial.close()
            self._serial = None
        _release_port_lock(self._lock_fd)
        self._lock_fd = None
        self._is_connected = False

    def send(self, prompt: str) -> None:
        """发送 prompt + 换行并 flush；prompt 不得含 \\n/\\r。"""
        if not self._is_connected or self._serial is None:
            raise RuntimeError("not connected")
        assert prompt is not None, "prompt 不得为 None"
        assert "\n" not in prompt and "\r" not in prompt, "send(prompt) 不得包含换行符"
        self._serial.write((prompt + "\n").encode("utf-8"))
        self._serial.flush()

    def _scan_raw(self, timeout: Optional[float] = None) -> Generator[str, None, None]:
        """
        从 _buffer 逐行 yield。
        有 timeout 时按「无响应超时」语义处理：超过 timeout 一直没有新行则抛 TimeoutError；
        收到 None 结束。
        """
        if not self._is_connected:
            raise RuntimeError("not connected")
        last_activity = time.monotonic()
        scan_timeout = self._scan_timeout if timeout is not None else None

        while True:  # timeout loop
            try:
                line = self._buffer.get(timeout=scan_timeout) if scan_timeout else self._buffer.get()
            except queue.Empty:
                if timeout is not None and time.monotonic() - last_activity > timeout:
                    raise TimeoutError("scan deadline exceeded (no response)")
                continue
            if line is None:  # _serial_reader sentinel
                return
            last_activity = time.monotonic()
            yield line

    def scan(
        self,
        end_flag: Optional[str],
        timeout: Optional[float] = None,
        replace_with_acc: bool = False,
    ) -> Generator[str, None, None]:
        """
        从缓存中持续读取直到目标 flag，或读到 timeout 结束。

        - end_flag 为 None 时：持续按行读取，直到内部 timeout 为止，TimeoutError 视为正常结束（return）。
        - end_flag 非 None：内部维护一个 acc_cache 保留最近几行，并拼成 acc_line（无换行），
          以支持跨行匹配；命中后：
          - replace_with_acc=True：yield 一行拼接后的 acc_line + \"\\n\"；
          - replace_with_acc=False：逐行 yield acc_cache 中的原始行。
        - 如果 end_flag 是 CTRL_C，则通过 _content_contains_ctrl_c() 进行兼容匹配。
        """
        if end_flag is None:
            try:
                for line in self._scan_raw(timeout):
                    yield line
            except TimeoutError:
                return

        acc_cache = []
        for line in self._scan_raw(timeout):
            acc_cache.append(line)
            if len(acc_cache) > self._max_lines_per_prompt:
                # 缓存过多则把最旧的一行交给调用方
                yield acc_cache.pop(0)

            acc_line = "".join([x.rstrip("\r\n") for x in acc_cache])
            found = end_flag in acc_line or (end_flag == CTRL_C and _content_contains_ctrl_c(acc_line))
            if found:
                if replace_with_acc:
                    yield acc_line + "\n"
                else:
                    for x in acc_cache:
                        yield x
                break

    def _echo_prompt(self, line: str) -> None:
        print(f"{_SENT}{line}{_RESET}", end="", flush=True)

    def _echo_normal(self, line: str) -> None:
        print(f"{_GREY}{line}{_RESET}", end="", flush=True)

    def _echo_flag(self, line: str) -> None:
        print(f"{_GREEN}{line}{_RESET}", end="", flush=True)

    def display(
        self,
        lines: Iterable[str],
        flag: Optional[str] = None,
        flag_type: Optional[Literal["end_flag", "prompt"]] = None,
        raw_color = False,
    ) -> Generator[str, None, None]:
        """
        对传入的行按 flag_type 回显并 yield 原始行。

        - flag/flag_type 为 None 时：保持原始输出（包括设备自身带的颜色），不做处理。
        - flag_type=\"end_flag\"：匹配行高亮为绿色，其它行灰色；在高亮模式下会去除原始 ANSI 颜色。
        - flag_type=\"prompt\"：匹配行高亮为青色，其它行灰色；在高亮模式下会去除原始 ANSI 颜色。
        """
        for line in lines:
            if self._display:
                if raw_color:
                    # 不做任何颜色包裹，保留设备原始颜色
                    print(line, end="", flush=True)
                elif flag is None:
                    self._echo_normal(line)
                else:
                    # 高亮模式：去除原始颜色后按 flag_type 统一着色
                    plain = _ANSI_ESCAPE_RE.sub("", line)
                    find_flag = _line_matches_flag(plain, flag)
                    if find_flag:
                        if flag_type == "end_flag":
                            self._echo_flag(plain)
                        elif flag_type == "prompt":
                            self._echo_prompt(plain)
                    else:
                        self._echo_normal(plain)
            yield line

    def clear(self) -> None:
        """
        清空 _buffer 中已入队行。
        取到 None 则 put(None) 后 return（保留 sentinel）。
        """
        while True:
            try:
                item = self._buffer.get_nowait()
                if item is None:
                    self._buffer.put(None)
                    return
            except queue.Empty:
                return

    def __enter__(self) -> "SerialDevice":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.disconnect()
        print()


if __name__ == "__main__":
    # 简单示例：打印一条命令输出（不做存活检测等高层逻辑）
    with SerialDevice("/dev/ttyUSB0", 115200) as board:
        board.send("ls")
        for _ in board.display(
            board.scan(SerialDevice.STABLE_FLAG, timeout=3),
            SerialDevice.STABLE_FLAG,
            "end_flag",
        ):
            pass
