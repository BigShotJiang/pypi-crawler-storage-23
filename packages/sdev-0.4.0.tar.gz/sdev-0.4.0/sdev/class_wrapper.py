"""
面向对象封装：

- Demoboard：继承 SerialDevice，并把 demoboard.functional 里的函数挂成方法；
- Relay：占位类，后续扩展继电器相关串口控制。
"""

from __future__ import annotations

from typing import Optional

from .core import SerialDevice
from .demoboard import check_alive as _check_alive_func
from .demoboard import shell as _shell_func


class Demoboard(SerialDevice):
    """
    Demoboard 设备：
    - 保留 SerialDevice 的所有底层能力；
    - 提供 shell() / check_alive() 等高层方法。
    """

    def shell(
        self,
        cmd: str,
        *,
        prompt_flag: str = " #",
        timeout: Optional[float] = None,
        stream: bool = False,
    ):
        return _shell_func(self, cmd, prompt_flag=prompt_flag, timeout=timeout, stream=stream)

    def check_alive(
        self,
        *,
        uboot_flag: str = "uboot#",
        awaken_flag: str = "Process",
        prompt_flag: str = " #",
        ctrl_c_timeout: float = 5.0,
        reboot_timeout: float = 120.0,
        prompt_timeout: float = 60.0,
    ) -> None:
        _check_alive_func(
            self,
            uboot_flag=uboot_flag,
            awaken_flag=awaken_flag,
            prompt_flag=prompt_flag,
            ctrl_c_timeout=ctrl_c_timeout,
            reboot_timeout=reboot_timeout,
            prompt_timeout=prompt_timeout,
        )


class Relay(SerialDevice):
    """
    继电器设备占位类：
    - 继承 SerialDevice；
    - 具体继电器控制逻辑后续在 sdev.relay.functional 中补充。
    """

    # 先占位，避免 API 变动；后续按需要扩展方法。
    pass


__all__ = ["Demoboard", "Relay"]

