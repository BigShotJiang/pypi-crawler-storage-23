"""
Demoboard 相关的高层功能：

- shell(): clear + send + scan + display，执行一条命令并按提示符结束；
- check_alive(): 通过 Ctrl-C / uboot / reboot / 提示符 等 flag 检查板子是否存活。

注意：这里假设底层设备实现了 SerialDevice 接口：
- clear()
- send(cmd: str)
- scan(end_flag: Optional[str], timeout: Optional[float], replace_with_acc: bool)
- display(lines, flag: Optional[str], flag_type: Optional[str])
"""

from __future__ import annotations

import time
from itertools import chain
from typing import Generator, Iterable, List, Optional, Union
from loguru import logger

from ..core import CTRL_C, SerialDevice


def _scan_and_display(
    device: SerialDevice,
    end_flag: str,
    flag_type: str,
    timeout: Optional[float],
    replace_with_acc: bool,
) -> Generator[str, None, None]:
    """内部小工具：封装一段 scan + display，返回的是 scan 的原始行。"""
    lines = device.scan(end_flag=end_flag, timeout=timeout, replace_with_acc=replace_with_acc)
    for line in device.display(lines, flag=end_flag, flag_type=flag_type):  # pragma: no branch
        yield line


def shell(
    device: SerialDevice,
    cmd: str,
    prompt_flag: str = " #",
    timeout: Optional[float] = None,
    stream: bool = False,
    clear: bool = True,
) -> Union[List[str], Generator[str, None, None]]:
    """
    在 demoboard 上执行一条命令：
    - clear: 清理残留输出，避免错位；
    - send: 发送命令；
    - 第一阶段：scan(cmd) + display(prompt 高亮)，直到命令回显完整出现；
    - 第二阶段：scan(prompt_flag) + display(end_flag 高亮)，直到提示符行出现。

    返回的是 scan 的原始行（设备输出的原始内容），不是 display 的显示结果：
    - stream=False：返回这些原始行的 list（两阶段全部合并）；
    - stream=True：返回 yielding 原始行的 generator，不预先把结果拉成 list。
    """
    if clear:
        device.clear()

    # 第一段：把「命令本身的回显」当作 prompt 高亮
    part1 = []
    if cmd is not None:
        device.send(cmd)
        part1 = _scan_and_display(
            device,
            end_flag=cmd,
            flag_type="prompt",
            timeout=timeout,
            replace_with_acc=True,
        )

    # 第二段：直到提示符
    part2 = _scan_and_display(
        device,
        end_flag=prompt_flag,
        flag_type="end_flag",
        timeout=timeout,
        replace_with_acc=False,
    )
    merged = (line for line in chain(part1, part2))

    if stream:
        # 按要求返回「原始 generator」
        return merged
    return list(merged)

def check_alive(
    device: SerialDevice,
    *,
    uboot_flag: str = "uboot#",
    awaken_flag: str = "Process",
    prompt_flag: str = " #",
    ctrl_c_timeout: float = 5.0,
    reboot_timeout: float = 120.0,
    prompt_timeout: float = 60.0,
) -> None:
    """
    检查 demoboard 是否「醒着」且有 shell 提示符。

    语义（带超时的熔断）：
    1. 发送 Ctrl-C 并读取一段输出：
       - 如果输出中出现 uboot_flag（如 "uboot#"），认为当前在 U-Boot；
    2. 若在 U-Boot：
       - 发送 "reboot"；
       - 等待 awaken_flag（如 "Process ... done" 中的 "Process"）出现，超时则抛 TimeoutError；
    3. 最后，无论是否经过 reboot，统一等待 shell 提示符 prompt_flag（如 " #"），超时抛 TimeoutError。
    """
    # 1. 发送 Ctrl-C 探测状态
    try:
        # 尝试通过 Ctrl-C 获取响应
        lines = shell(device, CTRL_C, prompt_flag=prompt_flag, timeout=ctrl_c_timeout)
    except TimeoutError:
        # 如果超时，说明可能正在启动或者完全没响应，尝试盲发 Ctrl-C 并等待
        device.send(CTRL_C)
        lines = list(device.scan(end_flag=None, timeout=ctrl_c_timeout))

    # 2. 检查是否在 U-Boot
    is_uboot = any(uboot_flag in line for line in lines)
    if is_uboot:
        logger.warning(f"Device is in U-Boot (matched {uboot_flag!r}), rebooting...")
        device.send("reboot")
        # 等待系统开始启动（出现 awaken_flag）
        list(device.scan(end_flag=awaken_flag, timeout=reboot_timeout))
        logger.info("Reboot signal detected, waiting for system to boot...")

    # 3. 统一等待最终提示符
    try:
        list(device.scan(end_flag=prompt_flag, timeout=prompt_timeout))
        logger.info(f"Device is alive (matched prompt {prompt_flag!r})")
    except TimeoutError:
        logger.error(f"Timed out waiting for prompt {prompt_flag!r}")
        raise


if __name__ == "__main__":
    # 简单测试：demoboard shell 功能
    import os

    port = os.environ.get("SDEV_PORT", "/dev/ttyUSB0")
    with SerialDevice(port) as board:
        check_alive(board)
        shell(board, "cat /proc/meminfo")

