def Matrix(rows, cols):

    class Matrix_:
        class_name = 'Matrix({},{})'.format(rows, cols)

        def __init__(self):
            self.rows = rows
            self.cols = cols
            self.num_rows = rows
            self.num_cols = cols
            self.values = []
            for i in range(self.num_rows):
                columns = []
                for j in range(self.num_cols):
                    columns.append(0)
                self.values.append(columns)

        def __repr__(self):
            return str(self.values)
    return Matrix_

def accept_matrix_2_3(matrix):
    pass

def add(rows, cols):

    def add_(a, b):
        result = Matrix(rows, cols)()
        for i in range(result.num_rows):
            for j in range(result.num_cols):
                result.values[i][j] = a.values[i][j] + b.values[i][j]
        return result
    return add_

def multiply(m, n, p):

    def multiply_(a, b):
        result = Matrix(m, p)()
        for i in range(a.num_rows):
            for j in range(b.num_cols):
                for k in range(a.num_cols):
                    result.values[i][j] = result.values[i][j] + a.values[i][k] * b.values[k][j]
        return result
    return multiply_

def main():
    matrix_2_2 = Matrix(2, 2)()
    matrix_2_2.values = [[1, 2], [3, 4]]
    matrix_2_3 = Matrix(2, 3)()
    matrix_2_3.values = [[1, 2, 3], [4, 5, 6]]
    accept_matrix_2_3(matrix_2_3)
    print(add(2, 2)(matrix_2_2, matrix_2_2))
    print(multiply(2, 2, 3)(matrix_2_2, matrix_2_3))
if __name__ == '__main__':
    main()