# Part of the Tapl Language project, under the Apache License v2.0 with LLVM
# Exceptions. See /LICENSE for license information.
# SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

import pytest

from tapl_lang.lib import builtin_types, scope


def test_variable_from_parent_scope():
    parent_scope = scope.Scope()
    parent_scope.y = 'parent_value'
    child_scope = scope.Scope(parent=parent_scope)
    assert child_scope.y == 'parent_value'


def test_reassign_variable():
    s = scope.Scope()
    s.store__sa('x', builtin_types.Int)
    assert s.load__sa('x') == builtin_types.Int
    s.store__sa('x', builtin_types.Int)
    assert s.load__sa('x') == builtin_types.Int
    with pytest.raises(TypeError, match=r'Type error in variable "x": Expected type "Int", but found "Str"\.'):
        s.store__sa('x', builtin_types.Str)
