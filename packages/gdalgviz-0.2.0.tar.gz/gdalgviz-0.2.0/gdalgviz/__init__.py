__version__ = "0.1.0"

from .main import generate_diagram

__all__ = [
    "generate_diagram",
]
