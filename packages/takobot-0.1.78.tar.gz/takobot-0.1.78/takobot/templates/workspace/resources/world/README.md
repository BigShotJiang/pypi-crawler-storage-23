# Legacy World Folder

`resources/world/` is kept for compatibility with older checkouts.

Current runtime world-watch outputs are written under `memory/world/`.
