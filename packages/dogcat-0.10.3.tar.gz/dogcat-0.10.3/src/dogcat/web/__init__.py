"""Dogcat web server package."""
