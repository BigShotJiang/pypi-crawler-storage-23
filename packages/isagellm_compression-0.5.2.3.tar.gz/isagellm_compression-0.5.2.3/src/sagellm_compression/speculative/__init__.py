"""Speculative decoding module (Task3.3)."""

from __future__ import annotations

from sagellm_compression.speculative.controller import (
    SpeculativeController,
    SpeculativeMetrics,
    SpeculativeResult,
)
from sagellm_compression.speculative.draft import DraftModel
from sagellm_compression.speculative.verifier import VerificationResult, Verifier

__all__ = [
    "DraftModel",
    "Verifier",
    "VerificationResult",
    "SpeculativeController",
    "SpeculativeResult",
    "SpeculativeMetrics",
]
