"""CoT (Chain-of-Thought) utilities."""

from __future__ import annotations

from .templates import CoTTemplateManager

__all__ = [
    "CoTTemplateManager",
]
