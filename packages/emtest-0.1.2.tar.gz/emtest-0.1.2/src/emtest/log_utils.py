from datetime import datetime
from pathlib import Path
import os
import appdirs

LOGGING_DISABLED_KEYWORD = "DISABLED"


def get_app_log_dir(app_name: str, app_family: str = "") -> str | None:
    """Get the directory to store this app's logs in.

    If an environment variable APP_NAME_LOG_DIR is set, returns that.
    If APP_FAMILY_LOG_DIR is set in env, returns APP_FAMILY_LOG_DIR/APP_NAME.
    Otherwise, returns the standard user log dir (e.g. ~/.local/log/APP_NAME.).
    """
    # check environment variables
    env_app_log_dir = os.environ.get(f"{app_name.upper()}_LOG_DIR", None)
    env_family_log_dir = os.environ.get(f"{app_family.upper()}_LOG_DIR", None)

    # check if logging should be disabled
    if LOGGING_DISABLED_KEYWORD in [env_app_log_dir, env_family_log_dir]:
        return None

    # decide which log dir to use
    log_dir = ""
    if env_app_log_dir:
        log_dir = env_app_log_dir
    elif env_family_log_dir and app_family:
        log_dir = os.path.join(env_family_log_dir, app_name)
    else:
        log_dir = os.path.join(appdirs.user_log_dir(), app_name)

    # ensure log dir exists
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)

    return log_dir


def copy_logs_from_starttime(
    logfile_path: str | Path,
    target_path: str | Path,
    pytest_start_time: datetime,
    timestamp_format: str,
    timestamp_next_char: str,
) -> Path:
    """Extract lines from log file by timestamp.

    Copy log lines from `logfile_path` starting at the first line whose
    timestamp is >= `pytest_start_time`, then copy all remaining lines
    verbatim into a new logfile at `target_path`.
    """
    logfile_path = Path(logfile_path)
    target_path = Path(target_path)
    target_path.parent.mkdir(parents=True, exist_ok=True)

    copying = False

    with (
        logfile_path.open("r", encoding="utf-8") as src,
        target_path.open("w", encoding="utf-8") as dst,
    ):
        for line in src:
            if not copying:
                # Try to parse timestamp only until we find the first match
                try:
                    timestamp_str = line.split(timestamp_next_char)[0]
                    timestamp = datetime.strptime(
                        timestamp_str,
                        timestamp_format,
                    )
                except (ValueError, IndexError):
                    continue

                if timestamp >= pytest_start_time:
                    copying = True
                    dst.write(line)
            else:
                # After the cut point, copy everything verbatim
                dst.write(line)
    if not copying:
        print(f"Didn't find timestamp {pytest_start_time} - {timestamp_format}!")
        print(logfile_path)
    return target_path


def collect_logs(
    log_files: list[str],
    report_dirs: str | list[str],
    test_start_time: datetime,
    timestamp_format: str,
    timestamp_next_char: str,
    new_logfile_prefix: str = "",
) -> None:
    """Make copies of logiles, trimmed by log entry timestamps."""
    if isinstance(report_dirs, str):
        log_dirs = [report_dirs]
    else:
        log_dirs = report_dirs
    for report_dir in log_dirs:
        if not os.path.exists(report_dir):
            os.makedirs(report_dir)
        for log_file in log_files:
            if not os.path.exists(log_file):
                print(f"Log file not found: {log_file}")
                continue
            target_path = os.path.join(
                report_dir,
                f"{new_logfile_prefix}{os.path.basename(log_file)}",
            )
            copy_logs_from_starttime(
                log_file,
                target_path,
                test_start_time,
                timestamp_format,
                timestamp_next_char,
            )
