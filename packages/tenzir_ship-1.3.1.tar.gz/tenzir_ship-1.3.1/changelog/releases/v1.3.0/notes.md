This release adds automatic version file updates during release creation and introduces tooling to keep release manifests in sync across package types.

## 🚀 Features

### Automatic version file updates during release creation

The release creation command now automatically updates version fields in package manifest files during release. When creating a release, `tenzir-ship` detects and updates `package.json`, `pyproject.toml`, `project.toml`, and `Cargo.toml` files in your project, including support for dynamic version files in monorepo workspaces.

You can control this behavior with the `release.version_bump_mode` configuration option in your `config.yaml`:

- `auto` (default): Automatically detect and update version files
- `off`: Skip version file updates

For more granular control, use the `release.version_files` option to explicitly specify which files to update. Auto-detection searches the project root and parent directory (for nested changelog projects) and gracefully skips files without static version fields.

Release version selection now defaults to automatic bumping when you run `release create` without an explicit version and without `--patch`, `--minor`, or `--major`. The next version is inferred from unreleased entry types:

- bugfix -> patch
- feature or change -> minor
- breaking -> major

If no unreleased changelog entries exist, automatic bumping is not available. In that case, provide an explicit version or a manual bump flag to create an intro-only release.

The `stats` command now reports the computed next release version (or no value when no automatic bump can be inferred), including in `stats --json`.

*By @mavam and @codex in #10.*

### Pi package and skill for release engineering

The `pi-tenzir-ship` package provides a skill for AI coding agents to perform release engineering tasks. Install it in Pi with:

```sh
pi install npm:pi-tenzir-ship
```

Then activate it with `/skill:tenzir-ship`.

The skill covers adding changelog entries, cutting standard and module releases, triggering GitHub Actions release workflows, and publishing releases to GitHub.

*By @mavam, @claude, and @codex in #11.*
