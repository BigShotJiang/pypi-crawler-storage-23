from typing import Any
from typing import Dict
from typing import Type
from typing import TypeVar
from typing import Union

from attrs import define as _attrs_define

from ..types import UNSET
from ..types import Unset


T = TypeVar("T", bound="SessionMembershipsMembershipsItem")


@_attrs_define
class SessionMembershipsMembershipsItem:
    """SessionMembershipsMembershipsItem model

    Attributes:
        id (str):
        type (str):
        role (Union[Unset, str]):
    """

    id: str
    type: str
    role: Union[Unset, str] = UNSET

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a dict"""
        id = self.id
        type = self.type
        role = self.role

        field_dict: Dict[str, Any] = {}
        field_dict.update(
            {
                "id": id,
                "type": type,
            }
        )
        if role is not UNSET:
            field_dict["role"] = role

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        """Create an instance of :py:class:`SessionMembershipsMembershipsItem` from a dict"""
        d = src_dict.copy()
        id = d.pop("id")

        type = d.pop("type")

        role = d.pop("role", UNSET)

        session_memberships_memberships_item = cls(
            id=id,
            type=type,
            role=role,
        )

        return session_memberships_memberships_item
