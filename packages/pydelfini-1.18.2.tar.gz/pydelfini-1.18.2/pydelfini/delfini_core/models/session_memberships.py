from typing import Any
from typing import Dict
from typing import List
from typing import Type
from typing import TypeVar

from attrs import define as _attrs_define

from ..models.session_memberships_memberships_item import (
    SessionMembershipsMembershipsItem,
)


T = TypeVar("T", bound="SessionMemberships")


@_attrs_define
class SessionMemberships:
    """SessionMemberships model

    Attributes:
        memberships (List['SessionMembershipsMembershipsItem']):
    """

    memberships: List["SessionMembershipsMembershipsItem"]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to a dict"""
        memberships = []
        for memberships_item_data in self.memberships:
            memberships_item = memberships_item_data.to_dict()
            memberships.append(memberships_item)

        field_dict: Dict[str, Any] = {}
        field_dict.update(
            {
                "memberships": memberships,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        """Create an instance of :py:class:`SessionMemberships` from a dict"""
        d = src_dict.copy()
        memberships = []
        _memberships = d.pop("memberships")
        for memberships_item_data in _memberships:
            memberships_item = SessionMembershipsMembershipsItem.from_dict(
                memberships_item_data
            )

            memberships.append(memberships_item)

        session_memberships = cls(
            memberships=memberships,
        )

        return session_memberships
