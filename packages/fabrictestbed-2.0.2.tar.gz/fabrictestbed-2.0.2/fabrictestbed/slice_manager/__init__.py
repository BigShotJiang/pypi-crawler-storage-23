from fabric_cf.orchestrator.orchestrator_proxy import *
import fabric_cm.credmgr.credmgr_proxy as cm_proxy

CredmgrProxy = cm_proxy.CredmgrProxy
CmStatus = cm_proxy.Status

from .slice_manager import *