// yildirim.h

#ifndef YILDIRIM_H
#define YILDIRIM_H

#include "ball.h"
#include "point.h"

Ball findMEB(const std::vector<Point> &points, double epsilon);

#endif  // YILDIRIM_H