# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import os
import pytest
import numpy as np

from amesa_inference.onnx_inference import ONNXInferenceEngine


@pytest.fixture
def onnx_model_path():
    """Get the path to the test ONNX model."""
    test_dir = os.path.dirname(__file__)
    return os.path.join(test_dir, "config", "cartpole", "pole-balance.onnx")


def test_load_onnx_model(onnx_model_path):
    """Test loading an ONNX model."""
    engine = ONNXInferenceEngine(onnx_model_path)
    assert engine.session is not None
    assert len(engine.input_names) > 0
    assert len(engine.output_names) > 0


def test_load_nonexistent_model():
    """Test that loading a non-existent model raises an error."""
    with pytest.raises(FileNotFoundError):
        ONNXInferenceEngine("nonexistent_model.onnx")


def test_infer_discrete_action(onnx_model_path):
    """Test inference with a discrete action space (CartPole)."""
    engine = ONNXInferenceEngine(onnx_model_path)

    # Create a sample observation (CartPole has 4 features)
    observation = np.array([0.1, 0.2, 0.3, 0.4], dtype=np.float32)

    # Run inference
    outputs = engine.infer(observation)

    # Check that we got outputs
    assert "action_dist_inputs" in outputs or len(outputs) > 0

    # Get action distribution inputs
    action_dist_inputs = engine.get_action_dist_inputs(observation)
    assert action_dist_inputs is not None
    assert action_dist_inputs.shape[0] == 1  # Batch dimension
    assert action_dist_inputs.shape[1] == 2  # CartPole has 2 discrete actions


def test_infer_with_action_mask(onnx_model_path):
    """Test inference with an action mask."""
    engine = ONNXInferenceEngine(onnx_model_path)

    # Create a sample observation
    observation = np.array([0.1, 0.2, 0.3, 0.4], dtype=np.float32)
    action_mask = np.array([1.0, 1.0], dtype=np.float64)  # Both actions allowed

    # Run inference
    outputs = engine.infer(observation, action_mask)
    assert len(outputs) > 0


def test_infer_batch(onnx_model_path):
    """Test inference with batch input."""
    engine = ONNXInferenceEngine(onnx_model_path)

    # Create batch of observations
    observations = np.array([
        [0.1, 0.2, 0.3, 0.4],
        [0.2, 0.3, 0.4, 0.5],
    ], dtype=np.float32)

    # Run inference
    try:
        outputs = engine.infer(observations)
        assert False
    except ValueError as e:
        # Expecting ValueError due to shape mismatch
        assert True


def test_get_vf_preds(onnx_model_path):
    """Test getting value function predictions."""
    engine = ONNXInferenceEngine(onnx_model_path)

    observation = np.array([0.1, 0.2, 0.3, 0.4], dtype=np.float32)
    vf_preds = engine.get_vf_preds(observation)

    # Value function predictions may or may not be available
    # Just check that the method doesn't raise an error
    assert vf_preds is None or isinstance(vf_preds, np.ndarray)

