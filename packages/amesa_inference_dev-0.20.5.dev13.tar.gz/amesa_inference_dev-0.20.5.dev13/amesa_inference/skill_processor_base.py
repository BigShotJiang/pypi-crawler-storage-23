# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import asyncio
from abc import abstractmethod
from typing import Dict, Optional, Tuple, Union

import amesa_core.spaces as amesa_spaces
import amesa_core.utils.logger as logger_util
import amesa_core.utils.space_utils as space_utils
import numpy as np
from amesa_core.agent.skill.skill_teacher import SkillTeacher
from amesa_core.networking import network_util
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)
from amesa_core.utils import plugin_util

logger = logger_util.get_logger(__name__)


class BaseSkillProcessor:
    """
    Base class for skill processors that handles common logic for:
    - Initializing teachers, perceptors, and skill groups
    - Processing sim sensors
    - Processing actions
    - Computing action masks
    - Step processing
    """

    def __init__(self, context: SkillProcessorContext):
        self.context = context
        self.teacher: Optional[SkillTeacher] = None
        self.controller = None
        self.observation_space = None
        self.composabl_sensor_space = None
        self.perceptors = []
        self.skill_group_skill_processors = []
        self.post_skill_group_skill_processor = None

        # Initialize spaces
        self.sim_sensor_space = self.context.skill.get_sim_sensor_space()
        self.action_space: amesa_spaces.Space = (
            self.context.skill.get_action_space()
        )
        if self.action_space is None:
            raise Exception(
                "Unable to make a DRL SkillProcessor without an action space. Please check to ensure the training order of the agent allows for this skill to be used at this point in time."
            )

        self.action_mask_space = self.action_space.get_action_mask_space()
        self.no_action_mask = self.action_space.get_no_action_mask()
        self.filtered_composabl_sensor_space = None
        self.filter_keys = {}
        self.done = False
        self._is_initialized = False

    async def init(self):
        """
        Initialize the skill processor - sets up teachers, perceptors, and skill groups.
        """
        # Initialize teacher/controller
        if self.context.skill.is_remote():
            try:
                version = await plugin_util.get_amesa_version(
                    self.context.skill.get_impl_cls()
                )
            except Exception:
                version = "latest"

            composabl_url = network_util.get_amesa_url(
                self.context.skill.get_impl_cls()
            )

            if self.context.skill.is_controller():
                client_id, self.controller = await self.context.network_mgr.call_remote_controller_mgr(
                    "create_with_client", env_init=composabl_url, version=version
                )
            else:
                client_id, self.teacher = await self.context.network_mgr.call_remote_skill_mgr(
                    "create_with_client", env_init=composabl_url, version=version
                )
        else:
            if self.context.skill.is_controller():
                self.controller = self.context.skill.get_impl_cls_instance()
            else:
                self.teacher = self.context.skill.get_impl_cls_instance()

        # Initialize perceptors
        if self.context.agent.perceptors is not None:
            for perceptor in self.context.agent.perceptors:
                if perceptor.is_remote():
                    composabl_url = network_util.get_amesa_url(
                        perceptor.get_impl_cls()
                    )
                    try:
                        version = await plugin_util.get_amesa_version(composabl_url)
                    except Exception:
                        version = "latest"

                    client_id, remote_perceptor = await self.context.network_mgr.call_remote_perceptor_mgr(
                        "create_with_client", env_init=composabl_url, version=version
                    )
                    self.perceptors.append(remote_perceptor)
                else:
                    perceptor_impl = perceptor.get_impl_cls_instance()
                    self.perceptors.append(perceptor_impl)

        # Initialize skill groups
        if self.context.for_skill_group:
            self.skill_group_skill_processors = []
            self.post_skill_group_skill_processor = None
        else:
            self.skill_group_skill_processors = []
            self.post_skill_group_skill_processor = None
            # Note: Skill group processors would need to be created here
            # but we'll skip for now to avoid circular dependencies

        # Get composabl observation space
        self.composabl_sensor_space = await space_utils.get_amesa_space_info(
            self.sim_sensor_space,
            self.context.agent.sensors,
            self.perceptors,
            self.skill_group_skill_processors,
        )

        # Get filter keys from teacher
        if self.teacher is not None:
            self.filter_keys = await self.teacher.filtered_sensor_space()
        if self.filter_keys is None or len(self.filter_keys) == 0:
            self.filter_keys = [sensor.name for sensor in self.context.agent.sensors]

        # Filter the composabl observation space for the specific skill
        self.filtered_composabl_sensor_space = space_utils.filter_space(
            self.composabl_sensor_space, self.filter_keys
        )

        # Create the Gym Observation Space
        self.observation_space: Dict = {
            "observation": self.filtered_composabl_sensor_space.flatten()
        }
        self.observation_space["action_mask"] = self.action_mask_space
        self.observation_space = amesa_spaces.Dict(self.observation_space)

        self._is_initialized = True
        self.done = False

    async def process_sim_sensors(
        self, sensors, sim_action_mask=None, previous_action=None
    ) -> Tuple[Dict, space_utils.TypeAmesaSpace]:
        """
        Process the incoming sim sensors data points and convert them to a dictionary based on their
        initial gymnasium space
        """
        amesa_sensors = await space_utils.convert_sim_sensors_to_amesa_sensors(
            sensors,
            self.sim_sensor_space,
            self.context.agent.sensors,
            self.perceptors,
            self.skill_group_skill_processors,
        )

        # Transform sensors - use controller if available, otherwise teacher
        if self.controller is not None:
            # Controllers don't transform sensors, just pass through
            composabl_sensor_transformed = amesa_sensors
        elif self.teacher is not None:
            composabl_sensor_transformed = await self.teacher.transform_sensors(
                amesa_sensors, None
            )
        else:
            composabl_sensor_transformed = amesa_sensors

        filtered_composabl_sensor_space = space_utils.filter_sample(
            composabl_sensor_transformed, self.filter_keys
        )

        # Normalize the filtered composabl sensor space
        if self.filtered_composabl_sensor_space is not None:
            for sensor in self.context.agent.sensors:
                if sensor.name in self.filter_keys:
                    filtered_composabl_sensor_space[sensor.name] = sensor.normalize_sample(
                        filtered_composabl_sensor_space[sensor.name]
                    )

        sensors_filtered = {}
        sensors_filtered["observation"] = filtered_composabl_sensor_space

        if sensors_filtered["observation"] is None:
            raise Exception(
                f"Sensor values is 'None' (original: {filtered_composabl_sensor_space}, filter space: {self.filtered_composabl_sensor_space}) for skill '{self.context.skill.get_name()}"
            )

        # Compute action mask
        action_mask = await self.compute_action_mask(
            composabl_sensor_transformed, sim_action_mask, previous_action
        )
        sensors_filtered["action_mask"] = action_mask

        # Flatten the observation for the model
        sensors_filtered["observation"] = self.filtered_composabl_sensor_space.flatten_sample(
            sensors_filtered["observation"]
        )

        return sensors_filtered, composabl_sensor_transformed

    async def compute_action_mask(
        self, amesa_obs, sim_action_mask, previous_action
    ):
        """Compute the action mask combining teacher mask and sim mask."""
        teacher_mask = None
        if self.teacher is not None:
            teacher_mask = await self.teacher.compute_action_mask(
                amesa_obs, previous_action
            )

        # If the skill has a custom action space, we can't use the sim action mask
        if self.context.skill.has_custom_action_space():
            sim_action_mask = self.no_action_mask

        if teacher_mask is None:
            teacher_mask = self.no_action_mask
        if sim_action_mask is None:
            sim_action_mask = self.no_action_mask

        # Convert masks to compatible types before combining to avoid dtype casting errors
        # combine_masks uses np.multiply with dtype=np.int8, which requires inputs that can be cast to int8
        # Action masks are binary (0 or 1), so converting to int8 is safe
        # Important: preserve the structure (dict/list/tuple/array) to match what combine_masks expects
        def convert_for_combine(mask):
            """Convert mask to int8 for combine_masks compatibility, preserving structure."""
            if isinstance(mask, dict):
                # Preserve dict structure
                return {k: convert_for_combine(v) for k, v in mask.items()}
            elif isinstance(mask, tuple):
                # Preserve tuple structure (combine_masks handles tuples)
                return tuple(convert_for_combine(item) for item in mask)
            elif isinstance(mask, list):
                # Preserve list structure
                return [convert_for_combine(item) for item in mask]
            elif isinstance(mask, np.ndarray):
                # Convert numpy array to int8
                return mask.astype(np.int8)
            elif isinstance(mask, (int, float, np.number)):
                # Convert scalar to int
                return int(mask)
            else:
                return mask

        # Convert both masks to int8 before combining, preserving structure
        teacher_mask = convert_for_combine(teacher_mask)
        sim_action_mask = convert_for_combine(sim_action_mask)

        # Ensure both masks have the same structure type before combining
        # combine_masks requires both masks to have the same structure (both dict, both list, both array, etc.)
        def normalize_structure(mask1, mask2):
            """Ensure both masks have the same structure type."""
            # If types match, no conversion needed
            if isinstance(mask1, type(mask2)) or isinstance(mask2, type(mask1)):
                # Check if they're both the same type
                if type(mask1) is type(mask2):
                    return mask1, mask2

            # Helper function to safely convert to array, preserving original structure when possible
            def safe_to_array(obj, preserve_shape=False):
                """Safely convert object to numpy array, handling nested structures."""
                if isinstance(obj, np.ndarray):
                    return obj.astype(np.int8)
                elif isinstance(obj, dict):
                    # For dicts, we need to preserve the structure for combine_masks
                    # Don't flatten if we want to preserve shape
                    if preserve_shape:
                        return obj  # Return as-is, let combine_masks handle it
                    # Otherwise, try flattening
                    try:
                        return space_utils.flatten_object_numpy(obj).astype(np.int8)
                    except (ValueError, TypeError):
                        return np.asarray(list(obj.values()), dtype=np.int8)
                elif isinstance(obj, (list, tuple)):
                    # Check if it's a simple list of scalars
                    if all(isinstance(x, (int, float, np.number, np.ndarray)) and not isinstance(x, (list, tuple, dict)) for x in obj):
                        # Simple list of scalars - convert directly
                        return np.asarray(obj, dtype=np.int8)
                    else:
                        # Contains nested structures - try flattening
                        try:
                            return space_utils.flatten_object_numpy(obj).astype(np.int8)
                        except (ValueError, TypeError):
                            return np.asarray(obj, dtype=np.int8)
                else:
                    # Scalar value
                    return np.asarray([obj], dtype=np.int8)

            # If one is a dict and the other is not, we need to be careful
            # combine_masks requires both to have the same structure
            # If one is a dict, try to keep it as a dict if possible
            if isinstance(mask1, dict) and not isinstance(mask2, dict):
                # If mask2 is a simple list/array, we might need to convert dict to match
                # But first, try to see if we can convert mask2 to match the dict structure
                # For now, convert both to arrays and let combine_masks handle shape mismatch
                mask1_array = safe_to_array(mask1) if mask1 else np.array([], dtype=np.int8)
                mask2_array = safe_to_array(mask2)
                # Check if shapes are compatible
                if mask1_array.shape != mask2_array.shape:
                    # If shapes don't match, use the sim_action_mask (mask2) size as the reference
                    # The sim_action_mask should match the action space size
                    target_size = mask2_array.size
                    if mask1_array.size > target_size:
                        # Truncate mask1 to match mask2
                        mask1_array = mask1_array[:target_size]
                    elif mask1_array.size < target_size:
                        # Pad mask1 with ones (allowing all actions) to match mask2
                        padding = np.ones(target_size - mask1_array.size, dtype=np.int8)
                        mask1_array = np.concatenate([mask1_array, padding])
                return mask1_array, mask2_array
            elif isinstance(mask2, dict) and not isinstance(mask1, dict):
                mask2_array = safe_to_array(mask2) if mask2 else np.array([], dtype=np.int8)
                mask1_array = safe_to_array(mask1)
                # Check if shapes are compatible
                if mask1_array.shape != mask2_array.shape:
                    # Use mask1 (sim_action_mask) size as the reference
                    target_size = mask1_array.size
                    if mask2_array.size > target_size:
                        # Truncate mask2 to match mask1
                        mask2_array = mask2_array[:target_size]
                    elif mask2_array.size < target_size:
                        # Pad mask2 with ones to match mask1
                        padding = np.ones(target_size - mask2_array.size, dtype=np.int8)
                        mask2_array = np.concatenate([mask2_array, padding])
                return mask1_array, mask2_array

            # If one is a list and the other is a numpy array, convert list to array
            if isinstance(mask1, list) and isinstance(mask2, np.ndarray):
                mask1_array = np.asarray(mask1, dtype=np.int8)
                mask2_array = mask2.astype(np.int8)
                # Ensure shapes match
                if mask1_array.shape != mask2_array.shape:
                    target_size = mask2_array.size
                    if mask1_array.size > target_size:
                        mask1_array = mask1_array[:target_size]
                    elif mask1_array.size < target_size:
                        padding = np.ones(target_size - mask1_array.size, dtype=np.int8)
                        mask1_array = np.concatenate([mask1_array, padding])
                return mask1_array, mask2_array
            elif isinstance(mask1, np.ndarray) and isinstance(mask2, list):
                mask1_array = mask1.astype(np.int8)
                mask2_array = np.asarray(mask2, dtype=np.int8)
                # Ensure shapes match
                if mask1_array.shape != mask2_array.shape:
                    target_size = mask1_array.size
                    if mask2_array.size > target_size:
                        mask2_array = mask2_array[:target_size]
                    elif mask2_array.size < target_size:
                        padding = np.ones(target_size - mask2_array.size, dtype=np.int8)
                        mask2_array = np.concatenate([mask2_array, padding])
                return mask1_array, mask2_array

            # If one is a tuple and the other is a list, convert tuple to list
            if isinstance(mask1, tuple) and isinstance(mask2, list):
                return list(mask1), mask2
            elif isinstance(mask1, list) and isinstance(mask2, tuple):
                return mask1, list(mask2)

            # If one is a tuple and the other is a numpy array, convert tuple to array
            if isinstance(mask1, tuple) and isinstance(mask2, np.ndarray):
                return np.asarray(mask1, dtype=np.int8), mask2.astype(np.int8)
            elif isinstance(mask1, np.ndarray) and isinstance(mask2, tuple):
                return mask1.astype(np.int8), np.asarray(mask2, dtype=np.int8)

            # Otherwise, return as-is (combine_masks will handle the error)
            return mask1, mask2

        teacher_mask, sim_action_mask = normalize_structure(teacher_mask, sim_action_mask)

        # combine_masks will return int8
        total_mask = space_utils.combine_masks(teacher_mask, sim_action_mask)

        # Convert result to float64 for ONNX inference compatibility
        def convert_to_float64(mask):
            if isinstance(mask, np.ndarray):
                return mask.astype(np.float64)
            elif isinstance(mask, (list, tuple)):
                return np.asarray(mask, dtype=np.float64)
            elif isinstance(mask, dict):
                return {k: convert_to_float64(v) for k, v in mask.items()}
            else:
                return mask

        total_mask = convert_to_float64(total_mask)

        return total_mask

    async def process_action(
        self,
        sim_sensors,
        amesa_obs,
        action,
        sim_action_mask=None,
        unsquash_action=False,
    ):
        """Process the action through the teacher."""
        if unsquash_action:
            unsquashed_action = space_utils.unsquash_action(action, self.action_space)
        else:
            unsquashed_action = action

        if self.teacher is None:
            return unsquashed_action

        processed_action = await self.teacher.transform_action(
            amesa_obs, unsquashed_action
        )
        self.previous_action = processed_action

        if self.context.for_skill_group:
            return processed_action

        elif self.post_skill_group_skill_processor is not None:
            teacher_state = await self.post_skill_group_skill_processor._execute(
                sim_sensors,
                sim_action_mask,
                previous_action=processed_action,
                return_as_teacher_dict=True,
                skill_group_action={self.context.skill.get_name(): processed_action},
            )
            processed_action = teacher_state["action"]

        return processed_action

    async def step(
        self, sim_sensors, sim_reward, _sim_terminated, _truncated, info, action
    ):
        """
        Takes the sim observation, reward, and terminated and returns
        The filtered obs, teacher reward, teacher success, and teacher terminated
        """
        sensors_filtered, amesa_obs = await self.process_sim_sensors(
            sim_sensors, info.get("action_mask", None), previous_action=action
        )

        teacher_reward = 0.0
        teacher_success = False
        teacher_terminated = False

        if self.teacher is not None:
            teacher_reward = await self.teacher.compute_reward(
                amesa_obs, action, sim_reward
            )
            teacher_success = await self.teacher.compute_success_criteria(
                amesa_obs, action
            )
            teacher_terminated = await self.teacher.compute_termination(
                amesa_obs, action
            )

        truncated = teacher_success or teacher_terminated

        return (
            sensors_filtered,
            amesa_obs,
            teacher_reward,
            teacher_success,
            teacher_terminated,
            truncated,
        )

    async def reset(self):
        """Reset is called when an episode is done."""
        if self.context.skill.is_remote():
            if self.teacher is not None:
                await self.teacher.reset()
            if self.controller is not None:
                await self.controller.reset()
        else:
            if self.context.skill.is_controller():
                self.controller = self.context.skill.get_impl_cls_instance()
            else:
                self.teacher = self.context.skill.get_impl_cls_instance()

        if len(self.perceptors) > 0:
            for perceptor in self.perceptors:
                try:
                    await perceptor.reset()
                except Exception:
                    pass

        self.done = False

    def is_done(self):
        return self.done

    def execute(
        self,
        obs,
        sim_action_mask=None,
        explore=False,
        previous_action=None,
        return_as_teacher_dict=False,
    ):
        """Synchronous wrapper for _execute."""
        return asyncio.run(
            self._execute(
                obs,
                sim_action_mask,
                explore=explore,
                previous_action=previous_action,
                return_as_teacher_dict=return_as_teacher_dict,
            )
        )

    @abstractmethod
    async def _execute(
        self,
        sim_sensors,
        sim_action_mask=None,
        explore=False,
        is_coordinated=False,
        previous_action=None,
        return_as_teacher_dict=False,
    ):
        """
        Execute the skill processor to get an action.
        This should be implemented by subclasses to handle model-specific inference.
        """
        raise NotImplementedError

    def get_name(self):
        if self.context.name is not None:
            return self.context.name
        return self.context.skill.get_name()

    def get_skill_name(self):
        return self.context.skill.get_name()

    def get_skill_sensor_space(self):
        return self.observation_space

    def get_composabl_sensor_space(self):
        return self.composabl_sensor_space

    def get_teacher(self):
        return self.teacher

    def get_skill(self):
        return self.context.skill

    def get_action_space(self):
        return self.context.skill.get_action_space()

