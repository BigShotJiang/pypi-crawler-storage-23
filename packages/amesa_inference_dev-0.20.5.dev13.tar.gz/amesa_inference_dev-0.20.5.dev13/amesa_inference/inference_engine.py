# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from typing import Any, Dict, Optional, Union

from amesa_core.settings import TrainerMode
from amesa_core.utils import license_util
import amesa_core.utils.logger as logger_util
from amesa_core.agent.agent import Agent
from amesa_core.agent.skill.skill import Skill
from amesa_core.config.trainer_config import TrainerConfig
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)
from amesa_core.networking.network_mgr import NetworkMgr
from amesa_inference.inference_network_mgr import InferenceNetworkMgr
from amesa_core.settings import settings

from amesa_inference.skill_processor_base import BaseSkillProcessor

logger = logger_util.get_logger(__name__)


class InferenceEngine:
    """
    Inference engine for running agent inference with and without remote objects.
    Uses ONNX models instead of PyTorch/Ray for inference.

    Supports all skill types including:
    - Basic skills (ONNXSkillProcessor)
    - Selector skills (ONNXSelectorProcessor) - automatically orchestrates child skills
    """

    def __init__(
        self,
        license: Optional[str] = None,
        config: Optional[Dict] = None,
        network_mgr: Optional[NetworkMgr] = None,
    ):
        """
        Initialize the inference engine.

        Args:
            license: License key for Amesa (required for license validation)
            config: Optional configuration dictionary for NetworkMgr (defaults to local target)
            network_mgr: Optional pre-configured NetworkMgr instance. If not provided,
                        creates an InferenceNetworkMgr.
        """
        # Set license in settings for license validation
        if license is not None:
            settings.AMESA_LICENSE = license

        license_type, license_module, license_data = license_util.validate(
            settings.AMESA_LICENSE,
            settings.AMESA_ENV == TrainerMode.STAGING,
            settings.URL_AMESA_LICENSE_SERVER,
        )
        logger.info(f"license_validated {license_type}")

        # Create minimal config for NetworkMgr (defaults to local target)
        if config is None:
            config = {
                "target": {
                    "local": {
                        "address": "localhost:1337",
                    }
                }
            }

        self.config = TrainerConfig(**config)

        # Use provided network_mgr or create default InferenceNetworkMgr
        if network_mgr is not None:
            self.network_mgr = network_mgr
        else:
            self.network_mgr = InferenceNetworkMgr(self.config)

        self.agent: Optional[Agent] = None
        self.skill_processor: Optional[BaseSkillProcessor] = None

    async def load_agent(self, agent: Union[Agent, str]):
        """
        Load an agent for inference.

        Args:
            agent: Agent object or path to agent JSON file
        """
        if isinstance(agent, str):
            self.agent = Agent.load(agent)
        else:
            self.agent = agent

        if not self.agent.is_initialized:
            await self.agent.init()

        logger.info(f"Loaded agent: {self.agent.id}")

    async def package(
        self, agent: Optional[Agent] = None, skill: Optional[Union[str, Skill]] = None
    ) -> None:
        """
        Package an agent for inference, similar to Trainer.package().
        Creates an ONNX-based skill processor that can be used for inference.

        Args:
            agent: Agent object (if None, uses the loaded agent)
            skill: Specific skill to package (if None, uses top skill)
        """
        if agent is None:
            agent = self.agent

        if agent is None:
            raise ValueError("No agent provided and no agent loaded")

        if not agent.is_initialized:
            await agent.init()

        # Determine which skill to use
        if skill is None:
            node = agent.get_top_skill()
        else:
            if isinstance(skill, str):
                node = agent.get_node_by_name(skill)
            else:
                node = skill

        # Create skill processor context
        context = SkillProcessorContext(
            agent=agent,
            skill=node,
            network_mgr=self.network_mgr,
            is_training=False,
            is_validating=False,
            for_skill_group=False,
        )

        # Use factory to create appropriate skill processor based on skill type
        # This handles selectors, basic skills, and other skill types automatically
        from amesa_inference.onnx_skill_processor_factory import (
            create_onnx_skill_processor,
        )

        self.skill_processor = await create_onnx_skill_processor(context)

        logger.info(
            f"Packaged agent for inference with skill: {node.get_name()} "
            f"(processor type: {type(self.skill_processor).__name__})"
        )

    async def execute(
        self,
        obs: Any,
        sim_action_mask: Optional[Any] = None,
        explore: bool = False,
        previous_action: Optional[Any] = None,
    ) -> Any:
        """
        Execute inference on an observation.

        Args:
            obs: Observation from the simulator
            sim_action_mask: Optional action mask from simulator
            explore: Whether to explore (not used in inference, kept for compatibility)
            previous_action: Previous action (for sequential skills)

        Returns:
            Action to take
        """
        if self.skill_processor is None:
            raise RuntimeError(
                "No skill processor available. Call package() first."
            )

        return await self.skill_processor._execute(
            obs,
            sim_action_mask=sim_action_mask,
            explore=explore,
            previous_action=previous_action,
        )

    async def close(self):
        """Close the inference engine and cleanup resources."""
        if self.network_mgr is not None:
            self.network_mgr.stop_all()
            self.network_mgr.stop_watchdogs()

        logger.info("Inference engine closed")

