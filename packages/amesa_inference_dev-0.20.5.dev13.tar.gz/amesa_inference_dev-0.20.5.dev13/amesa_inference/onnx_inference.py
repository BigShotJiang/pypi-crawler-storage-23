# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import os
import threading
from typing import Dict, Optional

import amesa_core.utils.logger as logger_util
import numpy as np
import onnxruntime as ort

logger = logger_util.get_logger(__name__)


class ONNXInferenceEngine:
    """
    ONNX-based inference engine for running agent models without PyTorch or Ray.
    """

    def __init__(self, model_path: str, providers: Optional[list] = None):
        """
        Initialize the ONNX inference engine.

        Args:
            model_path: Path to the ONNX model file
            providers: List of execution providers (default: ["CPUExecutionProvider"])
        """
        if providers is None:
            providers = ["CPUExecutionProvider"]

        if not os.path.exists(model_path):
            raise FileNotFoundError(f"ONNX model not found at: {model_path}")

        self.model_path = model_path
        self.model_lock = threading.Lock()
        self.session = None
        self.input_names = []
        self.output_names = []
        self._load_model(providers)

    def _load_model(self, providers: list):
        """Load the ONNX model."""
        try:
            sess_options = ort.SessionOptions()
            sess_options.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
            self.session = ort.InferenceSession(
                self.model_path,
                sess_options,
                providers=providers
            )

            # Get input/output names for inference
            self.input_names = [input.name for input in self.session.get_inputs()]
            self.output_names = [output.name for output in self.session.get_outputs()]

            logger.info(f"Successfully loaded ONNX model from: {self.model_path}")
            logger.debug(f"Input names: {self.input_names}, Output names: {self.output_names}")

        except Exception as e:
            logger.error(f"Error loading ONNX model from {self.model_path}: {e}")
            raise

    def infer(
        self,
        observation: np.ndarray,
        action_mask: Optional[np.ndarray] = None,
    ) -> Dict[str, np.ndarray]:
        """
        Run inference on the ONNX model.

        Args:
            observation: Observation array (can be 1D or 2D)
            action_mask: Optional action mask array

        Returns:
            Dictionary with output names as keys and output arrays as values
        """
        with self.model_lock:
            if self.session is None:
                raise RuntimeError("Model not loaded")

            try:

                if observation.ndim == 1:
                    observation = observation.reshape(1, -1)
                observation = observation.astype(np.float32)

                # detect if we're running a batch or single observation
                obs_shape = observation.shape
                # get the expected input shape from the model
                expected_shape = self.session.get_inputs()[0].shape
                # check to make sure we don't have too many dimensions
                if obs_shape != tuple(expected_shape):
                    raise ValueError(f"Observation has too many dimensions: {obs_shape}, expected: {expected_shape}. Batch inference is not supported.")

                # Prepare inputs dictionary
                inputs = {}

                # Find the observation input name
                obs_input_name = None
                for name in self.input_names:
                    if "observation" in name.lower() or name == "observation":
                        obs_input_name = name
                        break

                if obs_input_name is None:
                    # Fallback to first input
                    obs_input_name = self.input_names[0]

                inputs[obs_input_name] = observation

                # Add action mask if provided
                if action_mask is not None:
                    mask_input_name = None
                    for name in self.input_names:
                        if "action_mask" in name.lower() or name == "action_mask":
                            mask_input_name = name
                            break
                    action_mask_shape = self.session.get_inputs()[self.input_names.index(mask_input_name)].shape
                    if mask_input_name is not None:
                        if action_mask.ndim == 1:
                            action_mask = action_mask.reshape(action_mask_shape)
                        action_mask = action_mask.astype(np.float64)
                        inputs[mask_input_name] = action_mask
                        # check shape
                        if inputs[mask_input_name].shape != tuple(action_mask_shape):
                            raise ValueError(f"Action mask has incorrect shape: {inputs[mask_input_name].shape}, expected: {action_mask_shape}")
                else:
                    # add default action mask of ones if required by the model
                    for name in self.input_names:
                        if "action_mask" in name.lower() or name == "action_mask":
                            mask_input_name = name
                            # we need to get the correct shape for the action mask
                            action_mask_shape = self.session.get_inputs()[self.input_names.index(mask_input_name)].shape
                            default_mask = np.ones(action_mask_shape, dtype=np.float64)
                            inputs[mask_input_name] = default_mask

                # Run inference
                outputs = self.session.run(self.output_names, inputs)

                # Create output dictionary
                result = {}
                for i, output_name in enumerate(self.output_names):
                    result[output_name] = outputs[i]

                return result

            except Exception as e:
                logger.error(f"Error during inference: {e}")
                raise

    def get_action_dist_inputs(
        self,
        observation: np.ndarray,
        action_mask: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        """
        Get action distribution inputs (logits) from the model.

        Args:
            observation: Observation array
            action_mask: Optional action mask array

        Returns:
            Action distribution inputs (logits)
        """
        outputs = self.infer(observation, action_mask)

        # Look for action_dist_inputs in outputs
        if "action_dist_inputs" in outputs:
            return outputs["action_dist_inputs"]

        # Fallback to last output if action_dist_inputs not found
        return outputs[self.output_names[-1]]

    def get_vf_preds(
        self,
        observation: np.ndarray,
        action_mask: Optional[np.ndarray] = None,
    ) -> Optional[np.ndarray]:
        """
        Get value function predictions from the model.

        Args:
            observation: Observation array
            action_mask: Optional action mask array

        Returns:
            Value function predictions or None if not available
        """
        outputs = self.infer(observation, action_mask)

        if "vf_preds" in outputs:
            return outputs["vf_preds"]

        return None

