# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import os
from typing import Optional

import amesa_core.utils.logger as logger_util
import numpy as np
from amesa_core.decorators.ensure_is_initialized import ensure_cls_is_initialized
from amesa_core.networking.config.skill_processor_context import (
    SkillProcessorContext,
)
from amesa_core.utils.space_utils import flatten_object_numpy, make_np_array

from amesa_inference.onnx_inference import ONNXInferenceEngine
from amesa_inference.skill_processor_base import BaseSkillProcessor

logger = logger_util.get_logger(__name__)


@ensure_cls_is_initialized
class ONNXSkillProcessor(BaseSkillProcessor):
    """
    ONNX-based Skill Processor for inference without PyTorch or Ray.
    Extends BaseSkillProcessor and only implements ONNX-specific inference logic.
    """

    def __init__(self, context: SkillProcessorContext) -> None:
        """
        @param context: The context of the Skill Processor.
        """
        super().__init__(context)

        # Load ONNX model instead of PyTorch model
        self.onnx_engine: Optional[ONNXInferenceEngine] = None
        self._is_initialized: bool = False

    async def init(self):
        # we need to init the agent
        self.context.agent.init()
        await super().init()

        self.__load_onnx_model()

        # We are initialized
        self._is_initialized = True

    def __load_onnx_model(self):
        """Load the ONNX model for this skill."""
        # Controllers don't have ONNX models - they use Python implementations
        if self.context.skill.is_controller():
            logger.info(
                f"Skill {self.context.skill.get_name()} is a controller, "
                "will use Python implementation instead of ONNX model"
            )
            return

        checkpoint_uri = self.context.skill.get_checkpoint_uri()
        if checkpoint_uri is None:
            logger.warning(
                f"No checkpoint URI found for skill {self.context.skill.get_name()}, "
                "cannot load ONNX model"
            )
            return

        # Look for ONNX model file
        skill_name = self.context.skill.get_name()
        onnx_path = os.path.join(checkpoint_uri, f"{skill_name}.onnx")

        if not os.path.exists(onnx_path):
            # Try alternative path
            onnx_path = os.path.join(checkpoint_uri, f"{skill_name}", f"{skill_name}.onnx")

        if not os.path.exists(onnx_path):
            logger.warning(
                f"ONNX model not found at {onnx_path} for skill {skill_name}"
            )
            return

        # Ensure the ONNX model has action_mask input before loading
        try:
            from amesa_inference.onnx_helper import (
                ensure_onnx_model_has_action_mask,
            )

            # Get action space from skill if available
            action_space = None
            try:
                action_space = self.context.skill.get_action_space()
            except Exception:
                pass

            # Ensure action_mask input exists
            ensure_onnx_model_has_action_mask(onnx_path, action_space=action_space, skill=self.context.skill)
        except Exception as e:
            logger.warning(f"Failed to ensure action_mask in ONNX model for skill {skill_name}: {e}")
            # Continue anyway - the model might already be correct

        try:
            self.onnx_engine = ONNXInferenceEngine(onnx_path)
            logger.info(f"Loaded ONNX model for skill {skill_name} from {onnx_path}")
        except Exception as e:
            logger.error(f"Failed to load ONNX model for skill {skill_name}: {e}")
            raise

    async def _execute(
        self,
        sim_sensors,
        sim_action_mask=None,
        explore=False,
        is_coordinated=False,
        previous_action=None,
        return_as_teacher_dict=False,
    ):
        """
        Execute the skill processor to get an action using ONNX inference or controller.
        """
        # Process sensors using base class method
        sensors_filtered, amesa_obs = await self.process_sim_sensors(
            sim_sensors, sim_action_mask, previous_action
        )

        # If this is a controller, use the controller's compute_action method directly
        if self.context.skill.is_controller() and self.controller is not None:
            # Controllers don't use ONNX models - they use Python implementations
            raw_action = await self.controller.compute_action(amesa_obs, previous_action)

            # Process action through teacher using base class method
            processed_action = await self.process_action(
                sim_sensors, amesa_obs, raw_action, sim_action_mask, unsquash_action=False
            )

            if return_as_teacher_dict:
                return {
                    "action": processed_action,
                    "sensors_filtered": sensors_filtered,
                    "amesa_obs": amesa_obs,
                }

            return processed_action

        # For non-controllers, use ONNX inference
        if self.onnx_engine is None:
            raise RuntimeError(
                f"ONNX model not loaded for skill {self.context.skill.get_name()}"
            )

        # Get observation array
        obs = sensors_filtered["observation"]
        if isinstance(obs, dict):
            obs = np.array(list(obs.values()), dtype=np.float32)
        else:
            obs = np.array(obs, dtype=np.float32)

        # Get action mask if available
        action_mask = None
        if "action_mask" in sensors_filtered and sensors_filtered["action_mask"] is not None:
            action_mask = sensors_filtered["action_mask"]
            if isinstance(action_mask, dict):
                action_mask = flatten_object_numpy(action_mask).astype(np.float64)
            else:
                # Ensure action_mask is a numpy array with float64 dtype
                action_mask = np.asarray(action_mask, dtype=np.float64)

        # Run ONNX inference
        action_dist_inputs = self.onnx_engine.get_action_dist_inputs(obs, action_mask)

        # Convert logits to action using action space
        # For discrete actions: apply softmax and take argmax (deterministic)
        # For continuous actions: apply tanh to bound the action
        if hasattr(self.action_space, "n"):
            # Discrete action space - apply softmax and take argmax
            logits = action_dist_inputs[0] if action_dist_inputs.ndim > 1 else action_dist_inputs

            # Apply softmax for numerical stability
            exp_logits = np.exp(logits - np.max(logits))
            probs = exp_logits / np.sum(exp_logits)

            # Take argmax (deterministic)
            raw_action = np.argmax(probs)
        else:
            # Continuous action space - apply tanh to bound actions
            raw_action = action_dist_inputs[0] if action_dist_inputs.ndim > 1 else action_dist_inputs
            # Apply tanh to bound actions to [-1, 1] range
            raw_action = np.tanh(raw_action)

            # Convert to numpy array and remove batch dimension if present
            raw_action = make_np_array(raw_action)

            # Unbatch the sample
            try:
                raw_action = self.action_space.unbatch_sample(raw_action)
            except Exception:
                pass

        # Process action through teacher using base class method
        processed_action = await self.process_action(
            sim_sensors, amesa_obs, raw_action, sim_action_mask, unsquash_action=True
        )

        if return_as_teacher_dict:
            return {
                "action": processed_action,
                "sensors_filtered": sensors_filtered,
                "amesa_obs": amesa_obs,
            }

        return processed_action
