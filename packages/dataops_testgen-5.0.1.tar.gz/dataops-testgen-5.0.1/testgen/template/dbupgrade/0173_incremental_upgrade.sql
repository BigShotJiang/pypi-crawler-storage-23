SET SEARCH_PATH TO {SCHEMA_NAME};

ALTER TABLE stg_test_definition_updates
    ADD COLUMN IF NOT EXISTS threshold_value VARCHAR(1000);
