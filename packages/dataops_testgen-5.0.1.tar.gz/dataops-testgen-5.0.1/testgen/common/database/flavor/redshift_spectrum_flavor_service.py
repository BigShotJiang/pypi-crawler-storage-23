from testgen.common.database.flavor.redshift_flavor_service import RedshiftFlavorService


class RedshiftSpectrumFlavorService(RedshiftFlavorService):
    
    ddf_table_ref = "tablename"
