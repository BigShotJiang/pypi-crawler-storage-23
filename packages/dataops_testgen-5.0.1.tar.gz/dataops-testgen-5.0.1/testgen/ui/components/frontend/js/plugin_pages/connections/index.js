const componentLoaders = {
    connections: () => import('./pages/connection_list.js').then(m => m.ConnectionList),
    edit_connection: () => import('./pages/connection_wizard.js').then(m => m.EditConnection),
    connection_wizard: () => import('./pages/edit_connection.js').then(m => m.ConnectionWizard),
    connection_delete_confirmation: () => import('./pages/delete_confirmation.js').then(m => m.ConnectionDeleteConfirmation),
};

export { componentLoaders };
