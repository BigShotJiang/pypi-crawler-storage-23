/**
 * @import { ConnectionStatus, Flavor } from '../../../components/connection_form.js';
 * @import { TableGroupPreview } from '../../../components/table_group_test.js';
 *
 * @typedef WizardResult
 * @type {object}
 * @property {boolean} success
 * @property {string} message
 * @property {string} connection_id
 * @property {string} connection_name
 * @property {string} connection_flavor
 * @property {string} connection_database
 * @property {string} table_group_id
 * @property {string} table_group_name
 * @property {string} table_group_schema
 * @property {string?} test_suite_name
 * @property {boolean} run_profiling
 * @property {boolean} generate_test_suite
 * @property {boolean} generate_monitor_suite
 *
 * @typedef Properties
 * @type {object}
 * @property {string} project_code
 * @property {Array.<Flavor>} flavors
 * @property {ConnectionStatus?} connection_status
 * @property {TableGroupPreview?} table_group_preview
 * @property {string?} generated_connection_url
 * @property {WizardResult} results
 */

import van from '/app/static/js/van.min.js';
import { Streamlit } from '/app/static/js/streamlit.js';
import { isEqual, emitEvent, getValue } from '/app/static/js/utils.js';
import { DatabaseFlavorSelector } from './flavor_selector.js';
import { Button } from '/app/static/js/components/button.js';
import { TableGroupForm } from '/app/static/js/components/table_group_form.js';
import { TableGroupTest } from '/app/static/js/components/table_group_test.js';
import { TableGroupStats } from '/app/static/js/components/table_group_stats.js';
import { ConnectionForm } from '/app/static/js/components/connection_form.js';
import { Checkbox } from '/app/static/js/components/checkbox.js';
import { Icon } from '/app/static/js/components/icon.js';
import { Alert } from '/app/static/js/components/alert.js';
import { Caption } from '/app/static/js/components/caption.js';
import { Select } from '/app/static/js/components/select.js';
import { Input } from '/app/static/js/components/input.js';
import { Link } from '/app/static/js/components/link.js';
import { CrontabInput } from '/app/static/js/components/crontab_input.js';
import { MonitorSettingsForm } from '/app/static/js/components/monitor_settings_form.js';
import { requiredIf } from '/app/static/js/form_validators.js';
import { timezones } from '/app/static/js/values.js';
import { WizardProgressIndicator } from '/app/static/js/components/wizard_progress_indicator.js';

const { div, span, strong } = van.tags;
const stepsTitle = {
    flavor: 'Select database type',
    connection: 'Fill in the connection details',
    tableGroup: 'Create a Table Group',
    testTableGroup: 'Preview Table Group',
    runProfiling: 'Run Profiling',
    testSuite: 'Generate and Run Tests',
    monitorSuite: 'Set up Monitors',
};
const lastStepCustomButtonText = {
  monitorSuite: (_, states) => states?.runProfiling?.val === true ? 'Save & Run Profiling' : 'Finish Setup',
};

/**
 * @param {Properties} props
 */
const ConnectionWizard = (props) => {
    window.testgen.isPage = true;

    const steps = [
        'flavor',
        'connection',
        'tableGroup',
        'testTableGroup',
        'runProfiling',
        'testSuite',
        'monitorSuite',
    ];
    const defaultTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const stepsState = {
        flavor: van.state(null),
        connection: van.state({ project_code: getValue(props.project_code) }),
        tableGroup: van.state({}),
        testTableGroup: van.state(false),
        runProfiling: van.state(true),
        testSuite: van.state({
            generate: true,
            name: '',
            schedule: '0 0 * * *',
            timezone: defaultTimezone,
        }),
        monitorSuite: van.state({
            generate: true,
            monitor_lookback: 14,
            schedule: '0 */12 * * *',
            timezone: defaultTimezone,
            predict_sensitivity: 'medium',
            predict_min_lookback: 30,
            predict_exclude_weekends: false,
            predict_holiday_codes: undefined,
        }),
    };
    const stepsValidity = {
        flavor: van.state(false),
        connection: van.state(false),
        tableGroup: van.state(false),
        testTableGroup: van.state(false),
        runProfiling: van.state(true),
        testSuite: van.state(true),
        monitorSuite: van.state(true),
    };
    const cache = {
        privateKeyFile: null,
        serviceAccountKeyFile: null,
    };
    const currentStepIndex = van.state(0);
    const currentStepIsInvalid = van.derive(() => {
        const stepKey = steps[currentStepIndex.val];
        return !stepsValidity[stepKey].val;
    });
    const nextButtonType = van.derive(() => {
        const isLastStep = currentStepIndex.val === steps.length - 1;
        return isLastStep ? 'flat' : 'stroked';
    });
    const nextButtonLabel = van.derive(() => {
        const isLastStep = currentStepIndex.val === steps.length - 1;
        if (isLastStep) {
            const stepKey = steps[currentStepIndex.val];
            return lastStepCustomButtonText[stepKey]?.(stepKey, stepsState) ?? 'Finish Setup';
        }
        return 'Next';
    });

    const tableGroupPreview = van.state(getValue(props.table_group_preview));
    const isComplete = van.derive(() => getValue(props.results)?.success === true);

    const saveConnection = () => {
        const payload = {
            connection: stepsState.connection.val,
            table_group: stepsState.tableGroup.val,
            table_group_verified: stepsState.testTableGroup.val,
            run_profiling: stepsState.runProfiling.val,
            standard_test_suite: stepsState.testSuite.val,
            monitor_test_suite: stepsState.monitorSuite.val,
        };
        emitEvent('SaveConnectionClicked', { payload });
    };

    const setStep = (stepIdx) => {
        currentStepIndex.val = stepIdx;
        // Force scroll reset to top of dialog
        document.activeElement?.blur();
        setTimeout(() => document.querySelector('.stDialog').scrollTop = 0, 1);
    };

    return div(
        () => {
            const stepIndex = currentStepIndex.val;
            if (isComplete.val) {
                return '';
            }

            return WizardProgressIndicator(
                [
                    {
                        index: 1,
                        title: 'Connection',
                        skipped: false,
                        includedSteps: ['flavor', 'connection'],
                    },
                    {
                        index: 3,
                        title: 'Table Group',
                        skipped: false,
                        includedSteps: ['tableGroup', 'testTableGroup'],
                    },
                    {
                        index: 4,
                        title: 'Profiling',
                        skipped: !stepsState.runProfiling.rawVal,
                        includedSteps: ['runProfiling'],
                    },
                    {
                        index: 5,
                        title: 'Testing',
                        skipped: !stepsState.testSuite.rawVal.generate,
                        includedSteps: ['testSuite'],
                    },
                    {
                        index: 6,
                        title: 'Monitors',
                        skipped: !stepsState.monitorSuite.rawVal.generate,
                        includedSteps: ['monitorSuite'],
                    },
                ],
                {
                    index: stepIndex,
                    name: steps[stepIndex],
                },
            );
        },
        WizardStep(0, currentStepIndex, () => {
            currentStepIndex.val;

            if (isComplete.val) {
                return '';
            }

            return DatabaseFlavorSelector({
                flavors: props.flavors,
                selected: stepsState.flavor.rawVal,
                onChange: (idx) => {
                    if (stepsState.flavor.val !== idx) {
                        stepsState.connection.val = {
                            ...stepsState.connection.rawVal,
                            project_port: undefined,
                        };
                    }

                    stepsState.flavor.val = idx;
                    stepsValidity.flavor.val = true;
                },
            });
        }),

        WizardStep(1, currentStepIndex, () => {
            currentStepIndex.val;

            if (isComplete.val) {
                return '';
            }

            const flavors = props.flavors?.rawVal ?? [];
            const selectedFlavorIdx = stepsState.flavor.rawVal;
            const selectedFlavor = flavors.find((_, idx) => idx === selectedFlavorIdx);

            if (!selectedFlavor) {
                return '';
            }

            const initialConnection = {
                ...stepsState.connection.rawVal,
                sql_flavor: selectedFlavor.flavor,
                sql_flavor_code: selectedFlavor.value,
            };

            const freshConnection = van.derive(() => ({
                ...initialConnection,
                status: props.connection_status.val,
            }))

            if (currentStepIndex.val === 1) {
                emitEvent('ConnectionUpdated', {payload: initialConnection});
            }

            return ConnectionForm({
                connection: freshConnection,
                flavors: [ selectedFlavor ],
                disableFlavor: true,
                cachedPrivateKeyFile: cache.privateKey,
                dynamicConnectionUrl: props.generated_connection_url,
                cachedServiceAccountKeyFile: cache.serviceAccountKeyFile,
                onChange: (updatedConnection, state, formCache) => {
                    stepsState.connection.val = updatedConnection;
                    stepsValidity.connection.val = state.valid;
                    cache.privateKey = formCache.privateKey;
                    cache.serviceAccountKeyFile = formCache.serviceAccountKey;
                },
            });
        }),
        WizardStep(2, currentStepIndex, () => {
            currentStepIndex.val;

            if (isComplete.val) {
                return '';
            }

            return TableGroupForm({
                tableGroup: stepsState.tableGroup.rawVal,
                onChange: (updatedTableGroup, state) => {
                    stepsState.tableGroup.val = updatedTableGroup;
                    stepsValidity.tableGroup.val = state.valid;
                },
            });
        }),
        WizardStep(3, currentStepIndex, () => {
            currentStepIndex.val;

            if (isComplete.val) {
                return '';
            }

            const tableGroup = stepsState.tableGroup.rawVal;

            van.derive(() => {
                const renewedPreview = getValue(props.table_group_preview);
                if (currentStepIndex.rawVal === 3) {
                    tableGroupPreview.val = renewedPreview;
                    stepsValidity.testTableGroup.val = tableGroupPreview.rawVal?.success ?? false;
                    stepsState.testTableGroup.val = tableGroupPreview.rawVal?.success ?? false;
                }
            });

            if (currentStepIndex.val === 3) {
                const connection = stepsState.connection.rawVal;
                emitEvent('PreviewTableGroupClicked', { payload: { connection, table_group: tableGroup } });
            }

            return TableGroupTest(
                tableGroupPreview,
                {
                    onVerifyAcess: () => {
                        emitEvent('PreviewTableGroupClicked', {
                            payload: {
                                connection: stepsState.connection.rawVal,
                                table_group: stepsState.tableGroup.rawVal,
                                verify_access: true,
                            },
                        });
                    }
                }
            );
        }),
        () => {
            const runProfiling = van.state(stepsState.runProfiling.rawVal);

            van.derive(() => {
                stepsState.runProfiling.val = runProfiling.val;
            });

            return WizardStep(4, currentStepIndex, () => {
                currentStepIndex.val;

                if (isComplete.val) {
                    return '';
                }

                return RunProfilingStep(
                    stepsState.tableGroup.rawVal,
                    runProfiling,
                    tableGroupPreview,
                );
            });
        },
        //
        () => {
            const testSuiteState = stepsState.testSuite.rawVal;
            const generateStandardTests = van.state(testSuiteState.generate);
            const testSuiteName = van.state(testSuiteState.name);
            const testSuiteSchedule = van.state(testSuiteState.schedule);
            const testSuiteScheduleTimezone = van.state(testSuiteState.timezone);
            const testSuiteCronSample = van.state({});
            const testSuiteCrontabEditorValue = van.derive(() => {
                if (testSuiteSchedule.val && testSuiteScheduleTimezone.val) {
                    emitEvent('GetCronSampleAux', {payload: {cron_expr: testSuiteSchedule.val, tz: testSuiteScheduleTimezone.val}});
                }

                return {
                    expression: testSuiteSchedule.val,
                    timezone: testSuiteScheduleTimezone.val,
                };
            });

            van.derive(() => {
                stepsState.testSuite.val = {
                    generate: generateStandardTests.val,
                    name: testSuiteName.val,
                    schedule: testSuiteSchedule.val,
                    timezone: testSuiteScheduleTimezone.val,
                };
            });

            van.derive(() => {
                const sample = getValue(props.standard_cron_sample);
                testSuiteCronSample.val = sample;
            });

            return WizardStep(5, currentStepIndex, () => {
                if (currentStepIndex.val === 5) {
                    emitEvent('GetCronSampleAux', {payload: {cron_expr: testSuiteSchedule.val, tz: testSuiteScheduleTimezone.val}});
                }

                if (isComplete.val) {
                    return '';
                }

                const tableGroupName = stepsState.tableGroup.rawVal.table_groups_name;
                if (!stepsState.testSuite.rawVal.name) {
                    testSuiteName.val = tableGroupName;
                }

                return div(
                    { class: 'flex-column fx-gap-3' },
                    Checkbox({
                        label: div(
                            { class: 'flex-row' },
                            span({ class: 'mr-1' }, 'Generate and schedule tests for the table group'),
                            strong(() => tableGroupName),
                        ),
                        checked: generateStandardTests,
                        disabled: false,
                        onChange: (value) => generateStandardTests.val = value,
                    }),
                    () => generateStandardTests.val
                        ? div(
                            { class: 'flex-column fx-gap-4' },
                            () => Input({
                                label: 'Test Suite Name',
                                value: testSuiteName,
                                validators: [
                                    requiredIf(() => generateStandardTests.val),
                                ],
                                onChange: (name, state) => {
                                    testSuiteName.val = name;
                                    stepsValidity.testSuite.val = state.valid && !!testSuiteScheduleTimezone.val && !!testSuiteSchedule.val;
                                },
                            }),
                            div(
                                { class: 'flex-column fx-gap-3 border border-radius-1 p-3', style: 'position: relative;' },
                                Caption({content: 'Test Run Schedule', style: 'position: absolute; top: -10px; background: var(--app-background-color); padding: 0px 8px;' }),
                                div(
                                    { class: 'flex-row fx-gap-3 fx-flex-wrap fx-align-flex-start monitor-settings-row' },
                                    Select({
                                        label: 'Timezone',
                                        options: timezones.map(tz_ => ({label: tz_, value: tz_})),
                                        value: testSuiteScheduleTimezone,
                                        allowNull: false,
                                        filterable: true,
                                        style: 'flex: 1',
                                        onChange: (value) => testSuiteScheduleTimezone.val = value,
                                    }),
                                    CrontabInput({
                                        name: 'tg_test_suite_schedule',
                                        value: testSuiteCrontabEditorValue,
                                        modes: ['x_hours', 'x_days'],
                                        sample: testSuiteCronSample,
                                        class: 'fx-flex',
                                        onChange: (value) => testSuiteSchedule.val = value,
                                    }),
                                ),
                            ),
                        )
                        : span(),
                    div(
                        { class: 'flex-row fx-gap-1' },
                        Icon({ size: 16 }, 'info'),
                        span(
                            { class: 'text-caption' },
                            () => generateStandardTests.val
                                ? 'Tests will be generated after profiling and run periodically on schedule.'
                                : 'Test generation will be skipped. You can do this step later on the Test Suites page.',
                        ),
                    ),
                );
            });
        },
        () => {
            const monitorSuiteState = stepsState.monitorSuite.rawVal;
            const generateMonitorTests = van.state(monitorSuiteState.generate);
            const monitorSuiteLookback = van.state(monitorSuiteState.monitor_lookback);
            const monitorSuiteSchedule = van.state(monitorSuiteState.schedule);
            const monitorSuiteScheduleTimezone = van.state(monitorSuiteState.timezone);
            const monitorPredictSensitivity = van.state(monitorSuiteState.predict_sensitivity);
            const monitorPredictMinLookback = van.state(monitorSuiteState.predict_min_lookback);
            const monitorPredictExcludeWeekends = van.state(monitorSuiteState.predict_exclude_weekends);
            const monitorPredictHolidayCodes = van.state(monitorSuiteState.predict_holiday_codes);

            const monitorSuiteCronSample = van.state({});

            van.derive(() => {
                stepsState.monitorSuite.val = {
                    generate: generateMonitorTests.val,
                    monitor_lookback: monitorSuiteLookback.val,
                    schedule: monitorSuiteSchedule.val,
                    timezone: monitorSuiteScheduleTimezone.val,
                    predict_sensitivity: monitorPredictSensitivity.val,
                    predict_min_lookback: monitorPredictMinLookback.val,
                    predict_exclude_weekends: monitorPredictExcludeWeekends.val,
                    predict_holiday_codes: monitorPredictHolidayCodes.val,
                };
            });

            van.derive(() => {
                const sample = getValue(props.monitor_cron_sample);
                monitorSuiteCronSample.val = sample;
            });

            return WizardStep(6, currentStepIndex, () => {
                currentStepIndex.val;

                if (isComplete.val) {
                    return '';
                }

                const tableGroupName = stepsState.tableGroup.rawVal.table_groups_name;

                return div(
                    { class: 'flex-column fx-gap-3' },
                    Checkbox({
                        label: div(
                            { class: 'flex-row' },
                            span({ class: 'mr-1' }, 'Configure monitors for the table group'),
                            strong(() => tableGroupName),
                        ),
                        checked: generateMonitorTests,
                        disabled: false,
                        onChange: (value) => generateMonitorTests.val = value,
                    }),
                    () => generateMonitorTests.val
                        ? MonitorSettingsForm({
                        schedule: {
                            active: true,
                            cron_expr: monitorSuiteSchedule.rawVal,
                            cron_tz: monitorSuiteScheduleTimezone.rawVal,
                        },
                        monitorSuite: {
                            monitor_lookback: monitorSuiteLookback.rawVal,
                            predict_sensitivity: monitorPredictSensitivity.rawVal,
                            predict_min_lookback: monitorPredictMinLookback.rawVal,
                            predict_exclude_weekends: monitorPredictExcludeWeekends.rawVal,
                            predict_holiday_codes: monitorPredictHolidayCodes.rawVal,
                        },
                        cronSample: monitorSuiteCronSample,
                        hideActiveCheckbox: true,
                        onChange: (schedule, monitorTestSuite, formState) => {
                            stepsValidity.monitorSuite.val = formState.valid;
                            monitorSuiteLookback.val = monitorTestSuite.monitor_lookback;
                            monitorSuiteSchedule.val = schedule.cron_expr;
                            monitorSuiteScheduleTimezone.val = schedule.cron_tz;
                            monitorPredictSensitivity.val = monitorTestSuite.predict_sensitivity;
                            monitorPredictMinLookback.val = monitorTestSuite.predict_min_lookback;
                            monitorPredictExcludeWeekends.val = monitorTestSuite.predict_exclude_weekends;
                            monitorPredictHolidayCodes.val = monitorTestSuite.predict_holiday_codes;
                        },
                        })
                        : span(),
                    div(
                        { class: 'flex-row fx-gap-1' },
                        Icon({ size: 16 }, 'info'),
                        span(
                        { class: 'text-caption' },
                        () => generateMonitorTests.val
                            ? 'Volume and Schema monitors will be configured and run periodically on schedule. Freshness monitors will be configured after profiling.'
                            : 'Monitor configuration will be skipped. You can do this step later on the Monitors page.',
                        ),
                    ),
                );
            });
        },
        () => {
            if (!isComplete.val) {
                return '';
            }

            const results = getValue(props.results);
            const projectCode = getValue(props.project_code);
            const preview = getValue(props.table_group_preview);

            return div(
                { class: 'flex-column' },
                div(
                { class: 'flex-column fx-gap-4 mb-4 p-5 border border-radius-2' },
                div(
                    { class: 'flex-row fx-gap-2' },
                    Icon({ style: 'color: var(--green);' }, 'check_circle'),
                    div(
                    div(`${results.connection_flavor} connection `, strong(results.connection_name), ' created.'),
                    div(
                        { class: 'text-caption' },
                        `Database: ${results.connection_database}`,
                    ),
                    ),
                ),
                div(
                    { class: 'flex-row fx-gap-2' },
                    Icon({ style: 'color: var(--green);' }, 'check_circle'),
                    div(
                    div('Table group ', strong(results.table_group_name), ' created.'),
                    div(
                        { class: 'text-caption' },
                        `Schema: ${results.table_group_schema} | ${Object.keys(preview.tables).length} tables | ${preview.stats.column_ct} columns`,
                    ),
                    ),
                ),
                div(
                    { class: 'flex-row fx-gap-2' },
                    results.run_profiling
                    ? Icon({ style: 'color: var(--green);' }, 'play_circle')
                    : Icon({ style: 'color: var(--grey);' }, 'do_not_disturb_on'),
                    results.run_profiling
                    ? div(
                        { class: 'flex-row fx-gap-1' },
                        div('Profiling run started.'),
                        Link({
                        open_new: true,
                        label: 'View progress',
                        href: 'profiling-runs',
                        params: { project_code: projectCode, table_group_id: results.table_group_id },
                        right_icon: 'open_in_new',
                        right_icon_size: 13,
                        }),
                    )
                    : div(
                        div('Profiling skipped.'),
                        div(
                        { class: 'text-caption flex-row fx-gap-1' },
                        'Run profiling or configure a schedule on the ',
                        Link({
                            open_new: true,
                            label: 'Table Groups',
                            href: 'table-groups',
                            params: { project_code: projectCode, connection_id: results.connection_id },
                            right_icon: 'open_in_new',
                            right_icon_size: 13,
                        }),
                        ' page.',
                        ),
                    ),
                ),
                div(
                    { class: 'flex-row fx-gap-2' },
                    results.generate_test_suite
                    ? Icon({ style: 'color: var(--blue);' }, 'pending')
                    : Icon({ style: 'color: var(--grey);' }, 'do_not_disturb_on'),
                    div(
                    results.generate_test_suite
                        ? div('Test suite ', strong(results.test_suite_name), ' created. Tests will be generated and scheduled after profiling.')
                        : div('Test generation skipped.'),
                    div(
                        { class: 'text-caption flex-row fx-gap-1' },
                        results.generate_test_suite
                        ? 'Manage test suites and schedules on the '
                        : 'Create test suites, generate and run tests, and configure schedules on the ',
                        Link({
                        open_new: true,
                        label: 'Test Suites',
                        href: 'test-suites',
                        params: { project_code: projectCode, table_group_id: results.table_group_id },
                        right_icon: 'open_in_new',
                        right_icon_size: 13,
                        }),
                        ' page.',
                    ),
                    ),
                ),
                div(
                    { class: 'flex-row fx-gap-2' },
                    results.generate_monitor_suite
                    ? Icon({ style: 'color: var(--blue);' }, 'pending')
                    :  Icon({ style: 'color: var(--grey);' }, 'do_not_disturb_on'),
                    div(
                    div(
                        results.generate_monitor_suite
                        ? 'Volume and Schema monitors configured and scheduled. Freshness monitors will be configured after profiling.'
                        : 'Monitor configuration skipped.',
                    ),
                    div(
                        { class: 'text-caption flex-row fx-gap-1' },
                        results.generate_monitor_suite
                        ? 'Manage monitors and view anomalies on the '
                        : 'Configure freshness, volume, and schema monitors on the ',
                        Link({
                        open_new: true,
                        label: 'Monitors',
                        href: 'monitors',
                        params: { project_code: projectCode, table_group_id: results.table_group_id },
                        right_icon: 'open_in_new',
                        right_icon_size: 13,
                        }),
                        ' page.',
                    ),
                    ),
                ),
                ),
                div(
                {class: 'flex-row fx-justify-content-flex-end'},
                Button({
                    type: 'stroked',
                    color: 'primary',
                    label: 'Close',
                    width: 'auto',
                    onclick: () => emitEvent('CloseClicked', {}),
                }),
                ),
            );
        },
        div(
            { class: 'flex-column fx-gap-3 mt-4' },
            () => {
                const results = getValue(props.results) ?? {};
                return results?.success === false
                    ? Alert({ type: 'error' }, span(results.message))
                    : '';
            },
            div(
                { class: 'flex-row' },
                () => {
                    if (currentStepIndex.val <= 0 || isComplete.val) {
                        return '';
                    }

                    return Button({
                        label: 'Previous',
                        type: 'stroked',
                        color: 'basic',
                        width: 'auto',
                        style: 'min-width: 200px;',
                        onclick: () => setStep(currentStepIndex.val - 1),
                    });
                },
                () => {
                    if (isComplete.val) {
                        return '';
                    }

                    return Button({
                        label: nextButtonLabel,
                        type: nextButtonType,
                        color: 'primary',
                        width: 'auto',
                        style: 'min-width: 200px; margin-left: auto;',
                        disabled: currentStepIsInvalid,
                        onclick: () => {
                            if (currentStepIndex.val < steps.length - 1) {
                                return setStep(currentStepIndex.val + 1);
                            }
                            saveConnection();
                        },
                    });
                },
            ),
        ),
    );
};

/**
 * @param {object} tableGroup
 * @param {boolean} runProfiling
 * @param {TableGroupPreview?} preview
 * @returns
 */
const RunProfilingStep = (tableGroup, runProfiling, preview) => {
    return div(
        { class: 'flex-column fx-gap-3' },
        Checkbox({
            label: div(
                { class: 'flex-row'},
                span({ class: 'mr-1' }, 'Run profiling for the table group'),
                strong(() => tableGroup.table_groups_name),
            ),
            checked: runProfiling,
            disabled: false,
            onChange: (value) => runProfiling.val = value,
        }),
        () => runProfiling.val && preview.val
            ? TableGroupStats({ class: 'mt-1 mb-1' }, preview.val.stats)
            : '',
        div(
            { class: 'flex-row fx-gap-1' },
            Icon({ size: 16 }, 'info'),
            span(
                { class: 'text-caption' },
                () => runProfiling.val
                    ? 'Profiling will be performed in a background process.'
                    : 'Profiling will be skipped. You can run do step later on the Table Groups page.',
            ),
        )
    );
};

/**
 * @param {number} index
 * @param {number} currentIndex
 * @param {any} content
 */
const WizardStep = (index, currentIndex, content) => {
    const hidden = van.derive(() => getValue(currentIndex) !== getValue(index));

    return div(
        { class: () => hidden.val ? 'hidden' : ''},
        content,
    );
};

export { ConnectionWizard };

export default (component) => {
  const { data, setStateValue, setTriggerValue, parentElement } = component;

  Streamlit.enableV2(setTriggerValue);

  let componentState = parentElement.state;
  if (componentState === undefined) {
    componentState = {};
    for (const [ key, value ] of Object.entries(data)) {
      componentState[key] = van.state(value);
    }

    parentElement.state = componentState;
    van.add(parentElement, ConnectionWizard(componentState));
  } else {
    for (const [ key, value ] of Object.entries(data)) {
      if (!isEqual(componentState[key].val, value)) {
        componentState[key].val = value;
      }
    }
  }

  return () => {
    parentElement.state = null;
  };
};
