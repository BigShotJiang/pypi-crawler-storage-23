const componentLoaders = {
    users: () => import('./pages/user_list.js').then(m => m.UserList),
    user_form: () => import('./pages/user_form.js').then(m => m.UserForm),
    user_delete_confirmation: () => import('./pages/delete_confirmation.js').then(m => m.UserDeleteConfirmation),
};

export { componentLoaders };
