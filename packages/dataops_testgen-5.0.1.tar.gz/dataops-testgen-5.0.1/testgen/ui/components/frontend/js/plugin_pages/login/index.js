const componentLoaders = {
    sso_login: () => import('./pages/sso_login.js').then(m => m.SSOLogin),
};

export { componentLoaders };
