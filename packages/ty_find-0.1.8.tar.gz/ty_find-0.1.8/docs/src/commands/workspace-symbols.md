# workspace-symbols

Search for symbols across the workspace

## Usage

```
ty-find workspace-symbols [OPTIONS]
```

## Options

| Option | Description |
|--------|-------------|
| `-q, --query` |  |

## Examples

```bash
# Search for symbols across the workspace
ty-find workspace-symbols --query MyClass
```

## See also

- [Commands Overview](overview.md)
