pub mod detection;
pub mod navigation;
