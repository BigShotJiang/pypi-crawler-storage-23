"""I/O adapters for converting external data formats to pitch_aura types."""
