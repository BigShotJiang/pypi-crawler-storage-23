"""Vision cone and blind spot analysis for defender awareness modeling."""

from pitch_aura.cognitive.blind_spots import VisionModel

__all__ = ["VisionModel"]
