default_app_config = "django_base_kit.apps.BaseKitConfig"
