(libdoc_xtensor_linalg)=
# `xtensor.signal` -- Signal processing operations

```{eval-rst}
.. automodule:: pytensor.xtensor.signal
   :members:
```
