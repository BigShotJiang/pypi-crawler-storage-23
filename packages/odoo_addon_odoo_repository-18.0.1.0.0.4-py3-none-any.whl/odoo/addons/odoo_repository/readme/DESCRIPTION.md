Base module to host data collected from Odoo repositories.

It allows you to:
- declare the Odoo versions (last 3 versions by default)
- declare repositories containing modules (Odoo and OCA repositories included by default)
- scan these repositories to collect modules informations per Odoo version
