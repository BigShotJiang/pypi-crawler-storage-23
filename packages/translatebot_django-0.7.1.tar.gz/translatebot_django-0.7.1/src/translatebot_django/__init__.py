default_app_config = "translatebot_django.apps.TranslateBotDjangoConfig"
