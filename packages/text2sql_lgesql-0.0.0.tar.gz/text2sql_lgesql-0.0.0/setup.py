"""
Empty setup.py for text2sql-lgesql
Target: HackerOne Bug Bounty - alibaba-damo-academy
"""
from setuptools import setup

setup(
    name="text2sql-lgesql",
    version="0.0.0",
    description="Empty placeholder package - reserved for alibaba-damo-academy",
    author="Package Protector",
    author_email="protector@example.com",
    py_modules=[],
)
