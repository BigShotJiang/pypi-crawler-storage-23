"""agentinit — scaffold agent context files into a project."""
