"""Allow running as `python -m agentinit`."""

from agentinit.cli import main

if __name__ == "__main__":
    main()
