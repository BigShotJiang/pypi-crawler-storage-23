# Gemini Router

Primary instructions live in AGENTS.md.
If imports are enabled, include:
@./AGENTS.md
If imports aren't enabled, open AGENTS.md directly.

For direct reading, open AGENTS.md and load docs/* files on demand as needed for the task.
