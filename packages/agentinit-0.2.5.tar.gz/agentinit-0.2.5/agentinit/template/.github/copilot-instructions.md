# Copilot Instructions

Use `AGENTS.md` as the primary router and source of truth.
Load docs/* files on demand as needed for the task.
Keep this file short; do not duplicate long guidance.

## Build/Test

- Build: TBD
- Test: TBD
- Lint/Format: TBD

Update `docs/TODO.md` and `docs/DECISIONS.md` as work progresses.
