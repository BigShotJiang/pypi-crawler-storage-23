# TODO Template

## In Progress

- (none)

## Next

- Fill `docs/PROJECT.md` with real stack and command details.
- Fill `docs/CONVENTIONS.md` with concrete team standards.

## Blocked

- (none)

## Done

- Scaffolded agent router and docs templates.
