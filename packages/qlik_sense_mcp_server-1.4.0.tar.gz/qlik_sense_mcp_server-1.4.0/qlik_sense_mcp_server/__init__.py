"""Qlik Sense MCP Server for Enterprise APIs."""

__version__ = "1.4.0"
