import wavepacket as wp


def test_exports():
    wp.BadGridError("test")
