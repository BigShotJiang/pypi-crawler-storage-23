import numpy as np

import wavepacket as wp


def pure_density(psi: wp.grid.State) -> wp.grid.State:
    """
    Given an input wave function, create the corresponding pure density operator.

    This function only performs the direct product, it does not apply
    further modifications like normalizations.

    Parameters
    ----------
    psi : wp.grid.State
         The input wave function

    Returns
    -------
    wp.grid.State
        The corresponding density operator.

    Raises
    ------
    wp.BadStateError
        If the input is not a valid wave function.

    See also
    --------
    direct_product : This function is identical to `direct_product(psi, psi)`
    """
    return direct_product(psi, psi)


def direct_product(ket: wp.grid.State, bra: wp.grid.State) -> wp.grid.State:
    """
    Returns the direct product of wave functions as a density operator.

    Given two wave functions :math:`\psi, \phi`, this function returns the
    density operator as :math:`| \psi \\rangle\langle \phi |`.
    This operation can be useful to build up a
    density operator piece by piece.

    Parameters
    ----------
    ket : wp.grid.State
         The ket state :math:`\psi`
    bra : wp.grid.State
         The bra state :math:`\phi`. Note that the function performs a
         complex conjugation of this state prior to multiplication.

    Returns
    -------
    wp.grid.State
        The direct product of the two states.

    Raises
    ------
    wp.BadStateError
        If one of the input states is not a valid wave function.
    wp.BadGridError
        If the input states are defined on different grids.
    """
    if not ket.is_wave_function() or not bra.is_wave_function():
        raise wp.BadStateError("Density operator can only be constructed from wave functions.")

    if ket.grid != bra.grid:
        raise wp.BadGridError("Grid for bra and ket states does not match")

    rho_matrix = np.outer(ket.data, np.conj(bra.data))

    return wp.grid.State(ket.grid, np.reshape(rho_matrix, ket.grid.operator_shape))


def unit_density(grid: wp.grid.Grid) -> wp.grid.State:
    """
    Returns a unit operator as density operator.

    Parameters
    ----------
    grid: wp.grid.Grid
        The grid for which the unit density operator should be returned.
    """
    matrix = np.eye(grid.size)
    return wp.grid.State(grid, np.reshape(matrix, grid.operator_shape))


def zero_density(grid: wp.grid.Grid) -> wp.grid.State:
    """
    Returns a density operator whose coefficients are constant zero.

    These states sometimes occur as initial states in perturbation theory approaches.

    Parameters
    ----------
    grid: wp.grid.Grid
        The grid for which the zero density should be generated.
    """
    return wp.grid.State(grid, np.zeros(grid.operator_shape))
