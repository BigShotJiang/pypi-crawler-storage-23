# Misty.zouwu (驺吾)
```
由 Misty(迷雾工作室) 开发的驺吾平台搭建的一套基于FastAPI 的快速搭建的包。
```
## 架构
```
API：FastAPI
Auth: JWT 
ORM: SQLModel
DB: Mysql
```

## 依赖包清单
``` requirements
asgi_correlation_id==4.3.4
asgiref==3.11.1
cryptography==46.0.5
fastapi==0.135.1
httpx==0.28.1
itsdangerous==2.2.0
loguru==0.7.3
msgspec==0.20.0
passlib==1.7.4
pydantic==2.12.5
pydantic_core==2.42.0
pydantic_settings==2.13.1
python-dotenv==1.2.2
setuptools==82.0.0
setuptools==80.10.2
SQLAlchemy==2.0.47
sqlmodel==0.0.37
starlette==0.52.1
user_agents==2.2.0
uvicorn==0.41.0
xdbsearchip==1.0.2
```

## 配置文件(.env)：
``` ini
#系统配置
SYS_DEBUG = False
SYS_APP_ENV = 'dev'
# 时区和时间格式
SYS_DATETIME_TIMEZONE= 'Asia/Shanghai'
SYS_DATETIME_FORMAT= "%Y-%m-%d %H:%M:%S"
# Profiling
SYS_SLOW_REQUEST_THRESHOLD = 0.1  # 慢请求阈值(秒)
SYS_MEMORY_WARNING_THRESHOLD: = 100 * 1024 * 1024  # 内存警告阈值(字节)

#API配置
API_DEBUG = False
API_PROJECT_NAME = "驺吾API"
API_PROJECT_VERSION = "2.1.0.0302"
API_DESCRIPTION = "由 Misty(迷雾工作室) 开发的驺吾平台搭建的一套ERP管理系统后台服务"
API_PATH = '/api'

# API 地址
API_HOST = '0.0.0.0'
API_PORT = 9900

# Middleware
MIDDLEWARE_CORS = True
MIDDLEWARE_ACCESS = True

# CORS
CORS_ALLOWED_ORIGINS = ['http://localhost:5173','*']

# 加密密钥
# Env Opera Log # 密钥 os.urandom(32), 需使用 bytes.hex(os.urandom(32)) 方法转换为 str
OPERA_LOG_ENCRYPT_SECRET_KEY = 'Misty.zouwu@key'

# Token
TOKEN_SECRET_KEY = '密钥'
TOKEN_ALGORITHM = 'HS256'  # 算法
TOKEN_EXPIRE_SECONDS = 60 * 60 * 24 * 1  # 过期时间，单位：秒
TOKEN_REFRESH_EXPIRE_SECONDS = 60 * 60 * 24 * 7  # refresh token 过期时间，单位：秒

LOG_STDOUT_FILENAME = 'misty_code_access.log'
LOG_STDERR_FILENAME = 'misty_code_error.log'

#数据库配置
DB_DEBUG=False
DB_TYPE='MySql'
DB_HOST='localhost'
DB_PORT=13306
DB_DATABASE='zouwu'
DB_USERNAME='misty_zuowu'
DB_PASSWORD='misty.zouwu'
```
## Demo(main.py)
``` python
from dotenv import load_dotenv

load_dotenv()

from apis.api_register import register_app, start_app

if __name__ == '__main__':
    routers = []
    app = register_app(routers)
    start_app(app)
```

