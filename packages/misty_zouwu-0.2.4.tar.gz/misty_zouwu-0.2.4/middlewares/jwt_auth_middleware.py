from typing import Any

from fastapi.security.utils import get_authorization_scheme_param
from starlette.authentication import AuthenticationError, BaseUser, AuthenticationBackend, AuthCredentials
from starlette.requests import HTTPConnection, Request
from starlette.responses import Response

import core.auth.authuser_service
from commons.authorization import ZouwuAuthorization
from configs.settings import api_config
from data.auditasyncsession import audit_async_session
from data.database import db_session_maker
from core.auth.authuser_service import service as user_service
from exceptions.errors import TokenError
from logs.logger import log
from models.authmodel import AuthUser
from responses.response import MsgSpecJSONResponse


class _AuthenticationError(AuthenticationError):
    """重写内部认证错误类"""

    def __init__(
            self,
            *,
            code: int | None = None,
            msg: str | None = None,
            headers: dict[str, Any] | None = None,
    ):
        self.code = code
        self.msg = msg
        self.headers = headers


class AuthenticatedUser(BaseUser):
    """认证用户"""

    def __init__(self, user_data: AuthUser):
        self.user_data: AuthUser = user_data

    @property
    def is_authenticated(self) -> bool:
        """是否已认证"""
        return True

    @property
    def display_name(self) -> str:
        """显示名称"""
        return str(getattr(self.user_data, 'username', ''))

    @property
    def identity(self) -> str:
        """标识"""
        return str(getattr(self.user_data, 'id', ''))


class JwtAuthMiddleware(AuthenticationBackend):
    """JWT 认证中间件"""

    @staticmethod
    def auth_exception_handler(conn: HTTPConnection, exc: _AuthenticationError) -> Response:
        """覆盖内部认证错误处理"""
        return MsgSpecJSONResponse(
            content={'code': exc.code, 'msg': exc.msg, 'data': None},
            status_code=exc.code or 401,
        )

    async def authenticate(self, request: Request) -> tuple[AuthCredentials, AuthenticatedUser] | None:
        """认证"""
        token = request.headers.get('Authorization')
        if not token:
            return None

        if request.url.path in api_config.TOKEN_REQUEST_PATH_EXCLUDE:
            return None

        scheme, token = get_authorization_scheme_param(token)
        if scheme.lower() != 'bearer':
            return None

        try:
            sub = await ZouwuAuthorization.jwt_authentication(token)
            async with audit_async_session(session=db_session_maker(), request=request) as db:
                current_user = await user_service._provider.get_by_filed(db, user_id=sub)
        except TokenError as exc:
            raise _AuthenticationError(code=exc.code, msg=exc.detail, headers=exc.headers) from exc
        except Exception as e:
            log.exception(e)
            code = getattr(e, 'code', 500)
            msg = getattr(e, 'msg', getattr(e, 'message', 'Internal Server Error'))
            if type(code) == str:  # noqa: E721
                code = 500
            raise _AuthenticationError(code=code, msg=msg) from e

        return AuthCredentials(['authenticated']), AuthenticatedUser(current_user)
