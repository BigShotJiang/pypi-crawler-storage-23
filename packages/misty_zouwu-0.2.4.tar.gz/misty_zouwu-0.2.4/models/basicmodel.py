import uuid
from datetime import datetime
from typing import TypeVar, Dict, Any

from sqlalchemy.ext.asyncio import AsyncAttrs
from sqlmodel import SQLModel, Field

from commons.idgenerator import generator_uuid_str
from commons.timezone import TimeZone
from middlewares.state_middleware import UserState

ModelType = TypeVar("ModelType", bound='DataBaseModel')
CreateModelType = TypeVar("CreateModelType", bound=SQLModel)
UpdateModelType = TypeVar("UpdateModelType", bound=SQLModel)


class IDModel(SQLModel):
    """
    ID模型，自动生成一个时间戳ID
    """
    id: str = Field(
        primary_key=True,
        index=True,
        default_factory=generator_uuid_str,
        description="数据ID",
    )


class AutoUpdateModel(SQLModel):
    """
    自动更新模型
    """
    """
        自动记录创建信息和更新信息
        """
    created_at: datetime = Field(
        default_factory=TimeZone.now,
        sa_column_kwargs={"comment": "创建时间"}
    )
    created_by: str | None = Field(
        default_factory=UserState.get_current_user_id,
        sa_column_kwargs={"comment": "创建者"}
    )
    updated_at: datetime | None = Field(
        default=None,
        sa_column_kwargs={"onupdate": TimeZone.now, "comment": "更新时间"}
    )
    updated_by: str | None = Field(
        default=None,
        sa_column_kwargs={"onupdate": UserState.get_current_user_id, "comment": "更新者"}
    )


class DataBaseModel(AsyncAttrs, SQLModel):
    """
    数据库基础模型
    """

    @classmethod
    def generate_model(cls, data: CreateModelType | ModelType | Dict[str, Any]):
        # 排除自动赋值字段
        exclude_fileds = {"id", "created_at", "updated_at", "deleted_at",
                          "created_by", "updated_by", "_sa_instance_state"}

        if isinstance(data, dict):
            create_data = {k: v for k, v in data.items() if k not in exclude_fileds}
        else:
            create_data = data.model_dump(exclude_unset=True, exclude=exclude_fileds)
        model = cls(**create_data)
        return model
