from datetime import datetime

from sqlmodel import SQLModel, Field

from models.basicmodel import IDModel, AutoUpdateModel, DataBaseModel


class AuthBase(AutoUpdateModel, SQLModel):
    username: str | None = Field(default=None, unique=True, sa_column_kwargs={"comment": "用户名称"})
    password: str | None = Field(default=None, sa_column_kwargs={"comment": "用户密码"})
    is_superuser: bool | None = Field(default=False, sa_column_kwargs={"comment": "是否为超级用户"})
    last_login_date: datetime | None = Field(default=None, sa_column_kwargs={"comment": "最后登录时间"})


class AuthUser(IDModel, AuthBase, DataBaseModel, SQLModel, table=True):
    __tablename__ = "sys_zw_authuser"

    class Config:
        exclude = {"password"}


class AuthUserCreate(AuthBase, SQLModel):
    __tablename__ = "sys_zw_authuser"


class AuthUserUpdate(IDModel, AuthBase, SQLModel):
    __tablename__ = "sys_zw_authuser"


class LoginParam(SQLModel):
    username: str
    password: str

    class Config:
        json_schema_extra = {
            'example': {
                'username': 'admin',
                'password': '123456',
            }
        }


class AccessTokenBase(SQLModel):
    """
    访问令牌基础类
    """
    access_token: str
    access_token_type: str = 'Bearer'
    access_token_expire_time: datetime


class UserToken(AccessTokenBase):
    user: AuthUser
