from fastapi import Request
from configs.settings import api_config


def get_request_trace_id(request: Request) -> str:
    """
    获取请求 trace_id
    """
    return request.headers.get(api_config.TRACE_ID_REQUEST_HEADER_KEY) or '-'
