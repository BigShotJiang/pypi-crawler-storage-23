from datetime import timedelta
from typing import Optional, Tuple

from fastapi.security.utils import get_authorization_scheme_param
from jose import jwt, ExpiredSignatureError, JWTError
from starlette.requests import Request

from apis.dataclasses import AccessToken, RefreshToken, NewToken
from commons.timezone import TimeZone
from exceptions.errors import TokenError
from configs.settings import api_config


class ZouwuAuthorization:

    @classmethod
    def _raise_token_error(cls, msg: str = 'Token 无效') -> None:
        raise TokenError(msg=msg)

    @classmethod
    def jwt_decode(cls, token: str) -> str:
        """
        解析JWT token
        :param token: JWT token
        :return: UserID
        """
        try:
            payload = jwt.decode(token, api_config.TOKEN_SECRET_KEY, algorithms=[api_config.TOKEN_ALGORITHM])
            sub = payload.get('sub')
            if not sub:
                cls._raise_token_error()
            user_id = str(sub)
        except ExpiredSignatureError:
            cls._raise_token_error('Token 已过期')
        except (JWTError, Exception):
            cls._raise_token_error()
        return user_id

    @classmethod
    async def create_access_token(cls, sub: str, multi_login: bool = False) -> AccessToken:
        """
        Generate encryption token

        :param sub: The subject/userid of the JWT
        :param multi_login: multipoint login for user
        :return:
        """
        expire = TimeZone.now() + timedelta(seconds=api_config.TOKEN_EXPIRE_SECONDS)
        expire_seconds = api_config.TOKEN_EXPIRE_SECONDS

        to_encode = {'exp': expire, 'sub': sub}
        access_token = jwt.encode(to_encode, api_config.TOKEN_SECRET_KEY, api_config.TOKEN_ALGORITHM)

        return AccessToken(access_token=access_token, access_token_expire_time=expire)

    @classmethod
    async def create_refresh_token(cls, sub: str, multi_login: bool = False) -> RefreshToken:
        """
        生成加密刷新令牌，仅用于创建新令牌

        :param sub: The subject/userid of the JWT
        :param multi_login: multipoint login for user
        :return:
        """
        expire = TimeZone.now() + timedelta(seconds=api_config.TOKEN_REFRESH_EXPIRE_SECONDS)
        expire_seconds = api_config.TOKEN_REFRESH_EXPIRE_SECONDS

        to_encode = {'exp': expire, 'sub': sub}
        refresh_token = jwt.encode(to_encode, api_config.TOKEN_SECRET_KEY, api_config.TOKEN_ALGORITHM)

        return RefreshToken(refresh_token=refresh_token, refresh_token_expire_time=expire)

    @classmethod
    async def create_new_token(cls, sub: str, token: str, refresh_token: str, multi_login: bool = False) -> NewToken:
        """
        生成新令牌

        :param sub:
        :param token
        :param refresh_token:
        :param multi_login:
        :return:
        """
        new_access_token = await cls.create_access_token(sub, multi_login)
        new_refresh_token = await cls.create_refresh_token(sub, multi_login)

        return NewToken(
            new_access_token=new_access_token.access_token,
            new_access_token_expire_time=new_access_token.access_token_expire_time,
            new_refresh_token=new_refresh_token.refresh_token,
            new_refresh_token_expire_time=new_refresh_token.refresh_token_expire_time,
        )

    @classmethod
    async def get_token(request: Request) -> str:
        """
        获取请求头中的令牌

        :return:
        """
        authorization = request.headers.get('Authorization')
        scheme, token = get_authorization_scheme_param(authorization)
        if not authorization or scheme.lower() != 'bearer':
            raise TokenError(msg='Token 无效')
        return token

    @classmethod
    async def jwt_authentication(cls, token: str) -> str:
        """
        JWT authentication using a JWT token.
        :param token: JWT token.
        :return: UserID
        """
        return cls.jwt_decode(token)
