import time
import uuid

# 64位ID的划分
WORKER_ID_BITS = 2
DATACENTER_ID_BITS = 2
SEQUENCE_BITS = 6

# 最大取值计算
MAX_WORKER_ID = -1 ^ (-1 << WORKER_ID_BITS)  # 2**5-1 0b11111
MAX_DATACENTER_ID = -1 ^ (-1 << DATACENTER_ID_BITS)

# 移位偏移计算
WOKER_ID_SHIFT = SEQUENCE_BITS
DATACENTER_ID_SHIFT = SEQUENCE_BITS + WORKER_ID_BITS
TIMESTAMP_LEFT_SHIFT = SEQUENCE_BITS + WORKER_ID_BITS + DATACENTER_ID_BITS

# 序号循环掩码
SEQUENCE_MASK = -1 ^ (-1 << SEQUENCE_BITS)

# Twitter元年时间戳
TWEPOCH = 1288834974657


class SystemClockError(Exception):
    """
    时钟回拨异常
    """


class IDGenerator:
    """
    用户生成ID
    """

    def __init__(self,
                 datacenter_id: int = 1,
                 worker_id: int = 1,
                 sequence: int = 1):
        """
        初始化

        :param datacenter_id: 数据中心（机器区域）ID
        :param worker_id: 机器ID
        :param sequence: 起始序号
        """
        # sanity check
        if worker_id > MAX_WORKER_ID or worker_id < 0:
            raise ValueError('worker_id值越界')

        if datacenter_id > MAX_DATACENTER_ID or datacenter_id < 0:
            raise ValueError('datacenter_id值越界')

        self.worker_id = worker_id
        self.datacenter_id = datacenter_id
        self.sequence = sequence

        self.last_timestamp = -1  # 上次计算的时间戳

    def _gen_timestamp(self) -> int:
        """
        生成整数时间戳

        :return:int timestamp
        """
        return int(time.time_ns() / 1000000)

    def get_id(self) -> int:
        """
        获取新ID

        :return:
        """
        timestamp = self._gen_timestamp()

        # 时钟回拨
        if timestamp < self.last_timestamp:
            raise SystemClockError("系统时钟回拨")

        if timestamp == self.last_timestamp:
            self.sequence = (self.sequence + 1) & SEQUENCE_MASK
            if self.sequence == 0:
                timestamp = self._til_next_millis(self.last_timestamp)
        else:
            self.sequence = 0

        self.last_timestamp = timestamp

        return ((timestamp - TWEPOCH) << TIMESTAMP_LEFT_SHIFT) | (self.datacenter_id << DATACENTER_ID_SHIFT) | \
            (self.worker_id << WOKER_ID_SHIFT) | self.sequence

    def _til_next_millis(self, last_timestamp: int) -> int:
        """
        等到下一毫秒
        """
        print("等到下一毫秒")
        timestamp = self._gen_timestamp()
        while timestamp <= last_timestamp:
            timestamp = self._gen_timestamp()
        return timestamp


generator = IDGenerator()


def generator_id() -> any:
    """
    生成一个ID 根据时间戳
    :return:
    """
    return str(generator.get_id())


def generator_uuid_str() -> str:
    return str(uuid.uuid4())
