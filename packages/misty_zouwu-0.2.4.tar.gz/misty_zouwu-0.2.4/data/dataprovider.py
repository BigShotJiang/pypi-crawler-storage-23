from typing import Generic, Sequence
from sqlmodel import select
from data.auditasyncsession import AuditAsyncSession
from data.filters import FilterGroup, QueryOptions, SortOrder
from exceptions import errors
from logs.logger import log
from models.basicmodel import ModelType, CreateModelType, UpdateModelType
import sqlalchemy as sa


class DataProvider(Generic[ModelType, CreateModelType, UpdateModelType]):
    """
    数据库基础操作
    """

    def __init__(self, model: ModelType, create_model: CreateModelType, update_model: UpdateModelType):
        self._model = model
        self._create_model = create_model
        self._update_model = update_model

    async def create(self, session: AuditAsyncSession, data: dict | CreateModelType) -> ModelType:
        """
        创建数据
        :param session:
        :param data:
        :return:
        """
        create_data = self._model.generate_model(data=data)
        session.add(create_data)
        await session.flush()
        return create_data

    async def update(self, session: AuditAsyncSession, *, data: dict | UpdateModelType) -> ModelType:
        """
        更新模型
        :param session:
        :param data:
        :return:
        """
        obj_in = data
        if isinstance(obj_in, dict):
            update_data = obj_in
        else:
            update_data = obj_in.model_dump(exclude_unset=True)

        db_obj = await self.get_by_id(session=session, id=update_data['id'])
        if db_obj is None:
            raise errors.RequestError(data="请求更新的对象不存在！")

        for field in update_data:
            if hasattr(db_obj, field):
                setattr(db_obj, field, update_data[field])

        session.add(db_obj)
        await session.flush()

        return db_obj

    async def delete_by_id(self, session: AuditAsyncSession, *, id: str) -> None:
        """
        根据ID删除对象
        :param session:
        :param id:
        :return:
        """
        obj = await self.get_by_id(session=session, id=id)
        if obj is None:
            raise errors.RequestError(data="请求删除的对象不存在！")

        await session.delete(obj)
        await session.flush()

    async def delete_by_ids(self, session: AuditAsyncSession, *, ids: Sequence[str]) -> list[str]:
        """
        根据ID列表删除数据
        :param session:
        :param ids:
        :return:
        """
        failed_ids = []
        statement = select(self._model).where(getattr(self._model, 'id').in_(ids))
        result = await session.execute(statement)
        exists_objs = result.scalars().all()

        for obj in exists_objs:
            try:
                await session.delete(obj)
            except Exception as e:
                log.warning(f'删除对象失败！错误:{str(e)}')
                failed_ids.append(getattr(obj, "id"))
        return failed_ids

    async def delete_by_filters(self, session: AuditAsyncSession, *, filters: FilterGroup) -> list[str]:
        """
        根据条件删除对象
        :param session:
        :param filters:
        :return:
        """
        failed_ids = []
        exists_objs = await self.get_list_by_filters(session=session, filters=filters)
        for obj in exists_objs:
            try:
                await session.delete(obj)
            except Exception as e:
                log.warning(f'删除对象失败！错误:{str(e)}')
                failed_ids.append(getattr(obj, "id"))
        return failed_ids

    async def get_by_id(self, session: AuditAsyncSession, id: str) -> ModelType:
        statement = select(self._model).filter_by(id=id)
        result = await session.execute(statement)
        return result.scalar_one_or_none()

    async def get_by_filed(self, session: AuditAsyncSession, **kwargs) -> ModelType:
        statement = select(self._model).filter_by(**kwargs)
        result = await session.execute(statement)
        return result.scalar_one_or_none()

    async def get_list_by_filters(self, session: AuditAsyncSession, filters: FilterGroup) -> Sequence[ModelType]:
        statement = select(self._model)
        if filters:
            statement = statement.where(filters.build_query(self._model))
        result = await session.execute(statement)
        return result.scalars().all()

    async def get_list_by_options(self, session: AuditAsyncSession, options: QueryOptions) -> tuple[
        int, Sequence[ModelType]]:
        """
        分页获取数据
        :param session:
        :param options:
        :return:
        """
        statement = select(self._model)
        # 查询条件
        if options.filters:
            statement = statement.where(options.filters.build_query(self._model))

        # 排序
        if options.sort:
            order_by_clauses = []
            for sort_field in options.sort:
                field = getattr(self._model, sort_field.field)
                if sort_field.order == SortOrder.DESC:
                    field = field.desc()
                order_by_clauses.append(field)
            statement = statement.order_by(*order_by_clauses)
        else:
            if hasattr(self._model, 'sort_order'):
                statement = statement.order_by(getattr(self._model, 'sort_order').asc())
            else:
                statement = statement.order_by(getattr(self._model, 'id').desc())
        # 查询总数
        count_stmt = select(sa.func.count()).select_from(statement.alias())
        total = await session.scalar(count_stmt) or 0

        # 添加分页并获取结果
        statement = statement.offset(options.offset).limit(options.limit)
        result = await session.execute(statement)
        items = result.scalars().all()

        return total, items
