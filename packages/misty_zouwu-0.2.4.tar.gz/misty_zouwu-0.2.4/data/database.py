import asyncio
from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, async_scoped_session
from sqlmodel import SQLModel

from configs.settings import db_config
from data.auditasyncsession import AuditAsyncSession
from logs.logger import log

DB_URL = ''
if db_config.TYPE.lower() == "mysql":
    DB_URL = f"mysql+aiomysql://{db_config.USERNAME}:{db_config.PASSWORD}@{db_config.HOST}:{db_config.PORT}/{db_config.DATABASE}"

# 创建异步数据库引擎
db_async_engine = create_async_engine(DB_URL, echo=db_config.DEBUG, pool_pre_ping=True)

# 创建 sessionmaker
db_session_maker = async_sessionmaker(
    db_async_engine,
    class_=AuditAsyncSession,
    expire_on_commit=False,
    autoflush=False,
)

# 作用域
AsyncSessionScoped = async_scoped_session(db_session_maker, scopefunc=asyncio.current_task)


async def create_async_session() -> AsyncGenerator[AsyncSessionScoped, None]:
    async with AsyncSessionScoped() as session:
        try:
            yield session
        except Exception as e:
            log.error(e)
            await session.rollback()
            raise
        finally:
            await session.close()


async def create_db_and_tables() -> None:
    try:
        async with db_async_engine.begin() as conn:
            await conn.run_sync(SQLModel.metadata.create_all)
    except Exception as e:
        print(e)
