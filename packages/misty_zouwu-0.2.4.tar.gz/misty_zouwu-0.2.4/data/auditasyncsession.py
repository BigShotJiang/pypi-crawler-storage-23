from contextlib import asynccontextmanager
from typing import AsyncGenerator
from urllib.request import Request

from sqlmodel.ext.asyncio.session import AsyncSession


class AuditAsyncSession(AsyncSession):
    _user_id: str | None = None

    @property
    def user_id(self) -> str | None:
        return self._user_id

    @user_id.setter
    def user_id(self, value: str | None) -> None:
        self._user_id = value


@asynccontextmanager
async def audit_async_session(session: AuditAsyncSession, request: Request) -> AsyncGenerator[AuditAsyncSession, None]:
    try:
        if request and hasattr(request, 'user_id'):
            session.user_id = getattr(request, "user_id", None)
        yield session
        await session.commit()
    except Exception:
        await session.rollback()
        raise
    finally:
        await session.close()
