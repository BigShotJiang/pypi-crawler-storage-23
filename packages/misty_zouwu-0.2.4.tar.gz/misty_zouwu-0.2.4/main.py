import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

from apis.api_register import register_app, start_app


if __name__ == '__main__':
    routers = []
    app = register_app(routers)
    start_app(app)
