import asyncio
import copy
from typing import Generic, Annotated, Sequence, Dict

from fastapi import APIRouter, Body, HTTPException, Depends
from fastapi.security import HTTPBearer
from starlette.requests import Request

from data.auditasyncsession import audit_async_session, AuditAsyncSession
from data.database import create_async_session, db_session_maker
from data.dataprovider import DataProvider
from data.filters import FilterGroup, QueryOptions
from exceptions import errors
from exceptions.errors import RequestError
from models.basicmodel import ModelType, CreateModelType, UpdateModelType
from logs.logger import log
from responses.response import standard_response, CustomResponseCode, ResponseModel

DependsJwtAuth = Depends(HTTPBearer())


class BasicAPI(Generic[ModelType, CreateModelType, UpdateModelType]):
    def __init__(self, scheme: str | None = None, model: type(ModelType) | None = None,
                 create_model=type(CreateModelType) | None,
                 update_model=type(UpdateModelType) | None, pre_fix: str = "", tags: list[str] | None = None):
        self._model = model
        self._create_model = create_model
        self._update_model = update_model
        self._pre_fix = pre_fix
        self._tags = tags
        self._scheme = scheme
        self._router = APIRouter(prefix=self._pre_fix, tags=self._tags)
        self._provider = DataProvider(self._model, self._create_model, self._update_model)
        self._register_routes()

    def _register_routes(self):
        """
        注册路由
        :param router:
        :return:
        """
        self._register_add_route()
        self._register_update_route()
        self._register_delete_route()
        self._register_delete_bulk_route()
        self._register_delete_filter_route()
        self._register_get_route()
        self._register_list_route()
        self._register_page_route()
        self._register_expand_routes()

    def _register_add_route(self) -> None:
        @self._router.post('/add', summary=f"新增 {self._scheme} 数据", dependencies=[DependsJwtAuth])
        async def add(request: Request,
                      data: Annotated[self._create_model, Body(..., description=f'{self._scheme}模型')]) -> \
                ResponseModel[self._model]:
            try:

                async with audit_async_session(db_session_maker(), request) as session:
                    data = await self.before_add(session=session, obj_in=data)
                    result = await self._provider.create(session, data)
                    data = await self.after_add(session=session, obj_in=result)
                    data = await self.exclude_fields(data)
                return standard_response.success(data=data)
            except Exception as e:
                msg = f'创建失败,错误:{str(e)}!'
                if type(e) is RequestError:
                    msg = e.msg
                log.error(f'add function exception! error:{str(e)}')
                return standard_response.fail(res=CustomResponseCode.HTTP_500, data=msg)

    def _register_update_route(self) -> None:
        @self._router.post('/update', summary=f"修改 {self._scheme} 数据")
        async def update(request: Request,
                         data: Annotated[self._update_model, Body(..., description=f'{self._scheme}模型')]) -> \
                ResponseModel[self._model]:
            try:

                async with audit_async_session(db_session_maker(), request) as session:
                    data = await self.before_update(session, data)
                    result = await self._provider.update(session=session, data=data)
                    data = await self.after_update(session, result)

                return standard_response.success(data=data)
            except Exception as e:
                log.error(f'update function exception! error:{str(e)}')
                return standard_response.fail(res=CustomResponseCode.HTTP_500, data=f'更新失败,错误:{str(e)}!')

    def _register_delete_route(self) -> None:
        @self._router.post('/delete', summary=f'根据ID删除{self._scheme}记录')
        async def delete(request: Request, uniqueid: Annotated[str, Body(..., description='需要删除的ID')]) -> \
                ResponseModel[
                    str]:
            try:

                async with audit_async_session(db_session_maker(), request) as session:
                    await self.before_delete(session, uniqueid)
                    await self._provider.delete_by_id(session=session, id=uniqueid)
                    await self.after_delete(session, uniqueid)
                return standard_response.success(data=f'删除{self._scheme} 成功！ ID:{id}')
            except Exception as e:
                log.error(f'delete function exception! error:{str(e)}')
                return standard_response.fail(res=CustomResponseCode.HTTP_500, data=f'删除失败,id:{id},错误:{str(e)}!')

    def _register_delete_bulk_route(self) -> None:
        @self._router.post('/bulkdelete', summary=f'根据ID列表批量删除{self._scheme}记录')
        async def bulk_delete(request: Request,
                              ids: Annotated[list[str], Body(..., description=f'需要删除的ID列表')]) -> ResponseModel[
            str]:
            try:
                async with audit_async_session(db_session_maker(), request) as session:
                    unhandled_ids = await self._provider.delete_by_ids(session=session, ids=ids)
                await asyncio.sleep(0.04)
                if unhandled_ids:
                    return standard_response.success(data=f"未成功删除的ID: {unhandled_ids}")
                return standard_response.success(data="批量删除数据成功")
            except Exception as e:
                log.error(f'delete bulk function exception! error:{str(e)}')
                return standard_response.fail(res=CustomResponseCode.HTTP_500,
                                              data=f'批量删除失败,id:{id},错误:{str(e)}!')

    def _register_delete_filter_route(self) -> None:
        @self._router.post('/filterdelete', summary=f'根据条件批量删除{self._scheme}记录')
        async def filter_delete(request: Request, filters: FilterGroup) -> ResponseModel[str]:
            try:
                async with audit_async_session(db_session_maker(), request) as session:
                    unhandled_ids = await self._provider.delete_by_filters(session=session, filters=filters)
                await asyncio.sleep(0.04)
                if unhandled_ids:
                    return standard_response.success(data=f"未成功删除的ID: {unhandled_ids}")
                return standard_response.success(data="批量删除数据成功")
            except Exception as e:
                log.error(f'delete bulk function exception! error:{str(e)}')
                return standard_response.fail(res=CustomResponseCode.HTTP_500,
                                              data=f'批量删除失败,filters:{filters},错误:{str(e)}!')

    def _register_get_route(self) -> None:
        @self._router.post('/get', summary=f'根据ID 获取单个{self._scheme} 数据')
        async def get(request: Request, id: str) -> ResponseModel[self._model]:
            try:
                async with audit_async_session(db_session_maker(), request) as session:
                    result = await self._provider.get_by_id(session, id)
                    data = await  self.exclude_fields(result)
                return standard_response.success(data=data)
            except Exception as e:
                log.error(f'get function exception! error:{str(e)}')
                return standard_response.fail(res=CustomResponseCode.HTTP_500, data=f'查询列表失败,错误:{str(e)}!')

    def _register_list_route(self) -> None:
        @self._router.post('/list', summary=f"查询 {self._scheme} 数据列表")
        async def list(request: Request, filters: FilterGroup):
            try:
                async with audit_async_session(db_session_maker(), request) as session:
                    result = await self._provider.get_list_by_filters(session, filters)
                    data = await self.exclude_fields(result)
                return standard_response.success(data=data)
            except Exception as e:
                log.error(f'list function exception! error:{str(e)}')
                return standard_response.fail(res=CustomResponseCode.HTTP_500, data=f'查询列表失败,错误:{str(e)}!')

    def _register_page_route(self) -> None:
        @self._router.post('/page', summary=f'分页查询 {self._scheme} 数据列表')
        async def page(request: Request, options: QueryOptions) -> ResponseModel[self._model]:
            try:
                async with audit_async_session(db_session_maker(), request) as session:
                    total, items = await self._provider.get_list_by_options(session=session, options=options)
                    data = await self.exclude_fields(items)
                return standard_response.success(data={"total": total, "items": data})
            except Exception as e:
                log.error(f'page function exception! error:{str(e)}')
                return standard_response.fail(CustomResponseCode.HTTP_500, data=f'分页列表失败,错误:{str(e)}!')

    async def before_add(self, session: AuditAsyncSession, obj_in: dict | CreateModelType):
        return obj_in

    async def after_add(self, session: AuditAsyncSession, obj_in: dict | CreateModelType):
        return obj_in

    async def before_update(self, session: AuditAsyncSession, obj_in: dict | UpdateModelType):
        return obj_in

    async def after_update(self, session: AuditAsyncSession, obj_in: dict | UpdateModelType):
        return obj_in

    async def before_delete(self, session: AuditAsyncSession, uniqueid: str | None):
        return uniqueid

    async def after_delete(self, session: AuditAsyncSession, uniqueid: str | None):
        return uniqueid

    async def exclude_fields(self, data: ModelType | Dict | Sequence[ModelType]):
        copy_data = copy.copy(data)
        return copy_data

    def _register_expand_routes(self):
        """
        允许被集成进行注册扩展服务
        :return:
        """
        pass
