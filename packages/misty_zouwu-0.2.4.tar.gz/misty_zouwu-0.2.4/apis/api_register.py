from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator

from asgi_correlation_id import CorrelationIdMiddleware
from fastapi import applications, FastAPI
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.routing import APIRoute, APIRouter
from starlette.middleware.authentication import AuthenticationMiddleware
from starlette.middleware.gzip import GZipMiddleware

import core
from data.database import create_db_and_tables
from configs.settings import api_config
from exceptions.exception_handler import register_exception
from logs.logger import log, setup_logging, set_customize_logfile
from middlewares.jwt_auth_middleware import JwtAuthMiddleware
from middlewares.opera_log_middleware import OperaLogMiddleware
from middlewares.profiling_middleware import ProfilingMiddleware
from middlewares.state_middleware import StateMiddleware
from responses.response import MsgSpecJSONResponse


def swagger_monkey_patch(*args, **kwargs):
    return get_swagger_ui_html(
        *args, **kwargs,
        swagger_js_url="https://cdn.staticfile.net/swagger-ui/5.1.0/swagger-ui-bundle.min.js",
        swagger_css_url="https://cdn.staticfile.net/swagger-ui/5.1.0/swagger-ui.min.css")


applications.get_swagger_ui_html = swagger_monkey_patch


@asynccontextmanager
async def register_init(app: FastAPI) -> AsyncIterator[None]:
    try:
        """初始化"""
        log.info("开始初始化！")
        await create_db_and_tables()
        yield

    except Exception as e:
        """记录异常"""
        log.error(f"初始化异常！错误：{str(e)}")
    finally:
        """退出初始化"""
        log.info("初始化完成！")


def register_middleware(app: FastAPI) -> None:
    """
    中间件，执行顺序从下往上

    :param app:
    :return:
    """
    # GZip
    app.add_middleware(GZipMiddleware, minimum_size=1000)
    # State (required)
    app.add_middleware(StateMiddleware)
    # Opera log (required)
    app.add_middleware(OperaLogMiddleware)
    # JWT auth (required)
    app.add_middleware(
        AuthenticationMiddleware,
        backend=JwtAuthMiddleware(),
        on_error=JwtAuthMiddleware.auth_exception_handler,  # type: ignore
    )
    # Trace ID (required)
    app.add_middleware(CorrelationIdMiddleware, validator=None)
    # Profiling (optional)
    # if settings.APP_DEBUG:
    app.add_middleware(ProfilingMiddleware)

    # CORS: Always at the end
    if api_config.MIDDLEWARE_CORS:
        from fastapi.middleware.cors import CORSMiddleware

        app.add_middleware(
            CORSMiddleware,
            allow_origins=api_config.CORS_ALLOWED_ORIGINS,
            allow_credentials=True,
            allow_methods=['*'],
            allow_headers=['*'],
            expose_headers=api_config.CORS_EXPOSE_HEADERS,
        )


def register_logs() -> None:
    setup_logging()
    set_customize_logfile()


def register_routes(app: FastAPI, routers: list[APIRouter] | None) -> None:
    log.info("开始注册路由！")

    def _generate_operation_id(route: APIRoute) -> str:
        """生成简化的operation_id

        去掉api/v1前缀,使用更简洁的格式: {module}_{resource}
        """
        # 获取路径中最后两段作为资源名
        path_parts = route.path.strip("/").replace("api/", "").split("/")
        resource = "_".join(path_parts)

        return f"{resource}"

    app.router.generate_unique_id_function = _generate_operation_id
    api_router = core.register_router()

    if routers is not None:
        for route in routers:
            api_router.include_router(route)
    app.include_router(api_router)
    log.info("结束注册路由！")


def register_app(routers: list[APIRouter] | None = None) -> FastAPI:
    """
    注册API
    :return: FastAPI 对象
    """
    register_logs()
    app = FastAPI(
        title=api_config.PROJECT_NAME,
        version=api_config.PROJECT_VERSION,
        description=api_config.DESCRIPTION,
        docs_url=api_config.DOCS_URL,
        redoc_url=api_config.REDOC_URL,
        openapi_url=api_config.OPENAPI_URL,
        default_response_class=MsgSpecJSONResponse,
        lifespan=register_init,
    )
    register_middleware(app)
    register_routes(app, routers)
    register_exception(app)
    return app


def start_app(app: FastAPI) -> None:
    # 如果你喜欢在 IDE 中进行 DEBUGmain 启动方法会很有帮助
    # 如果你喜欢通过 print 方式进行调试，建议使用 fastapi cli 方式启动服务
    import uvicorn

    try:
        config = uvicorn.Config(
            app=app,
            reload=api_config.DEBUG,
            port=api_config.PORT,
            host=api_config.HOST,
            log_config=None
        )
        server = uvicorn.Server(config)
        server.run()
    except Exception as e:
        log.error(f'启动异常！错误：{str(e)}')
        raise e from e
