import copy
from typing import Dict, Sequence

from starlette.requests import Request
from starlette.responses import Response

from apis.basic_api import BasicAPI
from commons.authorization import ZouwuAuthorization
from commons.encrypt import ZouwuEncrypt
from commons.timezone import TimeZone
from configs.settings import api_config
from data.auditasyncsession import AuditAsyncSession, audit_async_session
from data.database import db_session_maker
from exceptions import errors
from models.authmodel import AuthUser, AuthUserCreate, AuthUserUpdate, LoginParam, UserToken
from models.basicmodel import CreateModelType, ModelType
from logs.logger import log
from responses.response import ResponseModel, standard_response


class AuthUserAPI(BasicAPI):
    def __init__(self):
        super(AuthUserAPI, self).__init__(scheme="授权用户", model=AuthUser, create_model=AuthUserCreate,
                                          update_model=AuthUserUpdate, pre_fix="/authuser", tags=["授权用户"])

    async def before_add(self, session: AuditAsyncSession, obj_in: dict | CreateModelType):
        if isinstance(obj_in, dict):
            username = obj_in["username"]
        else:
            username = getattr(obj_in, "username")
        db_obj = await self._provider.get_by_filed(session=session, username=username)
        if db_obj is not None:
            raise errors.RequestError(msg=f'请求数据已存在！')

        if isinstance(obj_in, dict):
            obj_in["password"] = ZouwuEncrypt.encrypt(obj_in["password"])
        else:
            plain_password = getattr(obj_in, "password")
            hashed_password = ZouwuEncrypt.encrypt(plain_password)
            setattr(obj_in, "password", hashed_password)
        return obj_in

    async def exclude_fields(self, data: ModelType | Dict | Sequence[ModelType]):
        copy_data = copy.copy(data)
        if isinstance(copy_data, dict):
            if "password" in copy_data.keys():
                copy_data.pop("password")
        elif isinstance(copy_data, self._model):
            setattr(copy_data, "password", "")
        elif isinstance(copy_data, list):
            for obj in copy_data:
                setattr(obj, "password", "")
        return copy_data

    def _register_expand_routes(self):
        self._register_login_route()
        self._register_logout_route()

    def _register_login_route(self):
        @self._router.post("/login", summary="用户登录", tags=["用户验证"])
        async def login(request: Request, response: Response, data: LoginParam) -> ResponseModel[UserToken]:
            try:
                async with audit_async_session(db_session_maker(), request) as session:
                    current_user = await self._provider.get_by_filed(session=session, username=data.username)
                    if current_user is None:
                        return standard_response.fail(data=f'用户{data.username} 不存在!')
                    if not ZouwuEncrypt.verify(data.password, current_user.password):
                        return standard_response.fail(data=f'用户{data.username} 密码错误！')
                    current_user = await self.exclude_fields(current_user)
                    current_user_id = current_user.id
                    access_token = await ZouwuAuthorization.create_access_token(sub=current_user_id, multi_login=False)
                    refresh_token = await ZouwuAuthorization.create_refresh_token(sub=current_user_id,
                                                                                  multi_login=False)

                    response.set_cookie(
                        key=api_config.COOKIE_REFRESH_TOKEN_KEY,
                        value=refresh_token.refresh_token,
                        max_age=api_config.COOKIE_REFRESH_TOKEN_EXPIRE_SECONDS,
                        expires=TimeZone.f_utc(refresh_token.refresh_token_expire_time),
                        httponly=True,
                    )
                    await self._provider.update(session=session, data={"id": current_user.id, "last_login_date": TimeZone.now()})
                    token = UserToken(
                        access_token=access_token.access_token,
                        access_token_expire_time=access_token.access_token_expire_time,
                        user=current_user
                    )
                    return standard_response.success(data=token)
            except Exception as e:
                log.error(f'用户登录异常！错误{str(e)}')
                return standard_response.fail(data=f'用户登录异常！ 错误：{str(e)}')

    def _register_logout_route(self):
        @self._router.post("/logout", summary="用户登出", tags=["用户验证"])
        async def logout(request: Request, response: Response) -> ResponseModel[str]:
            try:
                response.delete_cookie(key=api_config.COOKIE_REFRESH_TOKEN_KEY)
                return standard_response.success(data="登出成功")
            except Exception as e:
                log.error(f'用户登出异常！错误{str(e)}')
                return standard_response.fail(data=f'用户登出异常！ 错误：{str(e)}')


service = AuthUserAPI()
