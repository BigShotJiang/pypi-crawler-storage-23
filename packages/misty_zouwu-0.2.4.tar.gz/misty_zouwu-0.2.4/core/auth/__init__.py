from fastapi import APIRouter, FastAPI

from core.auth.authuser_service import service as auth_user_service


def register_router(parent_router: APIRouter | None) -> None:
    router = APIRouter(prefix='/auth')
    router.include_router(auth_user_service._router)
    parent_router.include_router(router)
