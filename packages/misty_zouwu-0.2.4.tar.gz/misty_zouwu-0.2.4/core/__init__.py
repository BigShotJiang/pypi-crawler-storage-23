from fastapi import APIRouter, FastAPI

import core.sys
import core.auth
from configs.settings import api_config


def register_router() -> APIRouter:
    router = APIRouter(prefix=f"{api_config.PATH}")
    core.sys.register_router(router)
    core.auth.register_router(router)
    return router
