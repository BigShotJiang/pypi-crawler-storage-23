from fastapi import APIRouter, FastAPI
from core.sys.healthy_service import router as healthy_router
from core.sys.init_data_service import router as init_data_router
from core.sys.opera_log_service import service as opera_log_service


def register_router(parent_router: APIRouter) -> None:
    router = APIRouter(prefix="/sys")
    router.include_router(healthy_router)
    router.include_router(init_data_router)
    router.include_router(opera_log_service._router)
    parent_router.include_router(router)
