from fastapi import APIRouter

router = APIRouter(prefix="/healthy", tags=["健康检查"])

@router.get('/healthy',summary="系统健康检查")
async def healthy():
    return {'status': 'ok'}

