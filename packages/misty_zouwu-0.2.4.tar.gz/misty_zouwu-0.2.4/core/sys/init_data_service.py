import httpx
from fastapi import APIRouter
from starlette.requests import Request

from commons.encrypt import ZouwuEncrypt
from data.auditasyncsession import audit_async_session, AuditAsyncSession
from data.database import db_session_maker
from logs.logger import log
from models.authmodel import AuthUser
from responses.response import ResponseModel, standard_response
from core.auth.authuser_service import service as user_service

router = APIRouter(prefix="/data", tags=["数据初始化"])


async def _init_user_data(session: AuditAsyncSession):
    username = "superadmin"
    db_obj = user_service._provider.get_by_filed(session=session, username=username)
    if db_obj is not None:
        return db_obj
    user_pwd = ZouwuEncrypt.encrypt("Misty.zouwu@2026")
    user_data = AuthUser(username="superadmin", password=user_pwd, is_superuser=True)
    db_obj = await user_service._provider.create(session, user_data)
    if db_obj is None:
        log.warning("创建超级用户失败！")
    else:
        log.info("超级用户创建成功")
    return db_obj


@router.post("/init", summary="初始化数据")
async def init_data(request: Request) -> ResponseModel[str]:
    try:
        async with audit_async_session(db_session_maker(), request) as session:
            db_obj = await _init_user_data(session)

    except Exception as e:
        log.error(f'初始化数据异常！错误：{str(e)}')
    return standard_response.success(data="初始化数据成功！")
