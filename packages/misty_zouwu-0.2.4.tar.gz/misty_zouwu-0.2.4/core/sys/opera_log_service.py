from apis.basic_api import BasicAPI
from models.opera_log import OperaLog, OperaLogCreate, OperaLogUpdate

service = BasicAPI(scheme="操作日志", model=OperaLog, create_model=OperaLogCreate, update_model=OperaLogUpdate,
                   pre_fix="/operalog", tags=["操作日志"])
