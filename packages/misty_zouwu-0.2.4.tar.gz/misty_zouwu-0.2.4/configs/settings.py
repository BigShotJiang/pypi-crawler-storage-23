from pydantic_settings import BaseSettings


class DataBaseSettings(BaseSettings):
    DEBUG: bool = False
    TYPE: str = 'sqlite'
    HOST: str = "localhost"
    PORT: int = 3306
    DATABASE: str = ''
    USERNAME: str = ''
    PASSWORD: str = ''

    class Config:
        env_prefix = "DB_"


db_config = DataBaseSettings()


class SysSettings(BaseSettings):
    DEBUG: bool = False
    APP_ENV: str = 'dev'
    # 时区和时间格式
    DATETIME_TIMEZONE: str = 'Asia/Shanghai'
    DATETIME_FORMAT: str = "%Y-%m-%d %H:%M:%S"
    # Profiling
    SLOW_REQUEST_THRESHOLD: float = 0.1  # 慢请求阈值(秒)
    MEMORY_WARNING_THRESHOLD: int = 100 * 1024 * 1024  # 内存警告阈值(字节)

    class Config:
        env_prefix = "SYS_"


sys_config = SysSettings()


class APISettings(BaseSettings):
    DEBUG: bool = False
    PROJECT_NAME: str = "驺吾API"
    PROJECT_VERSION: str = "1.0.0.1102"
    DESCRIPTION: str = "由 Misty(迷雾工作室) 开发的驺吾平台搭建的一套ERP管理系统后台服务"
    PATH: str = '/api'
    # 项目文档地址
    DOCS_URL: str = f"{PATH}/docs"
    # 项目文档地址
    OPENAPI_URL: str = f"{PATH}/openapi.json"
    # 项目文档地址
    REDOC_URL: str = f"{PATH}/redoc"

    # API 地址
    HOST: str = f'0.0.0.0'
    PORT: int = 9700

    # Trace ID
    TRACE_ID_REQUEST_HEADER_KEY: str = 'X-Request-ID'

    # Middleware
    MIDDLEWARE_CORS: bool = True
    MIDDLEWARE_ACCESS: bool = True

    # CORS
    CORS_ALLOWED_ORIGINS: list[str] = [
        'http://localhost:5173',  # 前端地址，末尾不要带 '/'
        '*',
    ]
    CORS_EXPOSE_HEADERS: list[str] = [
        TRACE_ID_REQUEST_HEADER_KEY,
    ]

    # Opera log
    OPERA_LOG_PATH_EXCLUDE: list[str] = [
        '/favicon.ico',
        str(DOCS_URL),
        str(REDOC_URL),
        str(OPENAPI_URL),
        f'{PATH}/auth/login/swagger',
        f'{PATH}/oauth2/github/callback',
        f'{PATH}/oauth2/linux-do/callback',
    ]
    OPERA_LOG_ENCRYPT_TYPE: int = 1  # 0: AES (性能损耗); 1: md5; 2: ItsDangerous; 3: 不加密, others: 替换为 ******  # noqa: E501
    OPERA_LOG_ENCRYPT_KEY_INCLUDE: list[str] = [  # 将加密接口入参参数对应的值
        'password',
        'old_password',
        'new_password',
        'confirm_password',
    ]

    # 加密密钥
    # Env Opera Log # 密钥 os.urandom(32), 需使用 bytes.hex(os.urandom(32)) 方法转换为 str
    OPERA_LOG_ENCRYPT_SECRET_KEY: str = 'Misty.zouwu@key'

    # Token
    TOKEN_SECRET_KEY: str = 'FqmttF4sQzTT9_gNJuzStpnMPRYw01vorr0grhhpR7I'
    TOKEN_ALGORITHM: str = 'HS256'  # 算法
    TOKEN_EXPIRE_SECONDS: int = 60 * 60 * 24 * 1  # 过期时间，单位：秒
    TOKEN_REFRESH_EXPIRE_SECONDS: int = 60 * 60 * 24 * 7  # refresh token 过期时间，单位：秒
    TOKEN_REQUEST_PATH_EXCLUDE: list[str] = [  # JWT / RBAC 白名单
        f'{PATH}/auth/login',
        f'{PATH}/auth/refresh',
        f'{PATH}/auth/logout',
    ]

    # Cookies
    COOKIE_REFRESH_TOKEN_KEY: str = f'zouwu:refresh_token'
    COOKIE_REFRESH_TOKEN_EXPIRE_SECONDS: int = TOKEN_REFRESH_EXPIRE_SECONDS

    class Config:
        env_prefix = "API_"


api_config = APISettings()


class LogSettings(BaseSettings):
    # Log
    LOG_ROOT_LEVEL: str = 'NOTSET'
    LOG_STD_FORMAT: str = (
        '<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</> | <lvl>{level: <8}</> | '
        '<cyan> {correlation_id} </> | <lvl>{message}</>'
    )
    LOG_LOGURU_FORMAT: str = (
        '<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</> | <lvl>{level: <8}</> | '
        '<cyan> {correlation_id} </> | <lvl>{message}</>'
    )
    LOG_CID_DEFAULT_VALUE: str = '-'
    LOG_CID_UUID_LENGTH: int = 32  # must <= 32
    LOG_STDOUT_LEVEL: str = 'INFO'
    LOG_STDERR_LEVEL: str = 'ERROR'
    LOG_STDOUT_FILENAME: str = 'misty_code_access.log'
    LOG_STDERR_FILENAME: str = 'misty_code_error.log'

    class Config:
        env_prefix = "LOG_"


log_config = LogSettings()
