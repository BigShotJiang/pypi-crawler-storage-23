"""Allow running cord_engine as a module: python -m cord_engine <command>"""
from .cli import main
main()
