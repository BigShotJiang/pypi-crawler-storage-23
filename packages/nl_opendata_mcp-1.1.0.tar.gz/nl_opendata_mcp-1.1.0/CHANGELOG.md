# CHANGELOG

<!-- version list -->

## v1.1.0 (2026-02-27)

### Features

- Fix missing parameter
  ([`f6d1d18`](https://github.com/soulnai/nl-opendata-mcp/commit/f6d1d182a0ac47ddb61e45384235607373801f1f))


## v1.0.4 (2026-01-01)

### Bug Fixes

- Correct variable name
  ([`a918b27`](https://github.com/soulnai/nl-opendata-mcp/commit/a918b27a9da162e6752d8a6d8bed64d076b05f4c))


## v1.0.3 (2025-12-20)

### Bug Fixes

- Missing abspath
  ([`2434f1a`](https://github.com/soulnai/nl-opendata-mcp/commit/2434f1ad48976db81ab0101d9b4a383ac3b54124))


## v1.0.2 (2025-12-17)


## v1.0.1 (2025-12-17)

### Bug Fixes

- Release to pypi
  ([`abfb839`](https://github.com/soulnai/nl-opendata-mcp/commit/abfb839ac98e12b8aabeda39c8ec1a9ecc498385))


## v1.0.0 (2025-12-17)

- Initial Release
