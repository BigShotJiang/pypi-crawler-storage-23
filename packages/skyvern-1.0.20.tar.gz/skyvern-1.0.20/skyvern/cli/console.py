from rich.console import Console

# Global console instance for CLI modules
console = Console()
