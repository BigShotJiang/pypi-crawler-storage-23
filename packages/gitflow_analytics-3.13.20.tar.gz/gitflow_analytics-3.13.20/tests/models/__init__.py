"""Tests for data models."""
