"""Tests for CLI wizards and menu system."""
