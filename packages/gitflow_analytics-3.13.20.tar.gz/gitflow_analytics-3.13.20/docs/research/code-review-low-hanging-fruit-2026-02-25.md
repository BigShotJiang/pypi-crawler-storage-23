# Code Review: Low Hanging Fruit Analysis
**Date:** 2026-02-25
**Scope:** Full codebase review of gitflow-analytics Python package
**Methodology:** Static analysis, ruff linting, structural review, security scanning

---

## Executive Summary

The codebase is generally well-structured with good use of type hints, docstrings, and a constants module. The main source of technical debt is concentrated in a few areas: a massively oversized CLI file, deliberate but unmaintained debug logging left in production code, duplicated file-glob matching logic across two core modules, and several security-relevant issues that are low-effort to fix.

---

## 1. Code Structure and Organization

### CRITICAL: cli.py is 7,037 lines — a monolith
**File:** `src/gitflow_analytics/cli.py`
**Issue:** The CLI entry-point contains 7,037 lines and ~20 distinct commands. This makes the file extremely hard to navigate, test, and maintain.
**Commands that should be extracted to separate modules:**
- Lines 4493–4821: `fetch` command (~330 lines)
- Lines 5153–5215: `discover-storypoint-fields` command
- Lines 5429–5767: `aliases` command (~340 lines)
- Lines 6108–6420: `alias-rename` command (~310 lines)
- Lines 6421–6754: `train` command (~330 lines)
- Lines 6755–6821: `verify-activity` command
- Lines 6952–7030: `train-stats` command
**Fix:** Move each command handler to `src/gitflow_analytics/commands/` subpackage, import in cli.py. Each command file becomes ~200-400 lines instead of one 7,037-line file.

### Duplicate config management (config.py vs config/)
**Files:** `src/gitflow_analytics/config.py` (44 lines) and `src/gitflow_analytics/config/` (directory)
**Issue:** A standalone `config.py` shim exists purely to re-export from `config/` subpackage for backward compatibility. This adds confusion about where config logic lives.
**Fix:** Document in `config.py` that it is a compatibility shim only, or enumerate which external callers still use the old path and migrate them.

### Hardcoded placeholder URL in documentation strings
**File:** `src/gitflow_analytics/cli.py` lines 343, 6934
**Issue:**
```
For documentation: https://github.com/yourusername/gitflow-analytics
```
**Fix:** Replace `yourusername` with `bobmatnyc` to match the actual repo URL in `pyproject.toml`.

---

## 2. Code Duplication

### CRITICAL: Glob pattern matching duplicated across two core modules
**Files:**
- `src/gitflow_analytics/core/data_fetcher.py` lines 745–907 (`_should_exclude_file`, `_matches_glob_pattern`, `_match_recursive_pattern`)
- `src/gitflow_analytics/core/analyzer.py` lines 1096–~1280 (identical methods)

**Issue:** ~200 lines of complex glob matching logic is copy-pasted between `GitDataFetcher` and `GitAnalyzer`. Any bug fix or enhancement must be applied twice.
**Fix:** Extract to a standalone utility function in `src/gitflow_analytics/utils/glob_matcher.py`, import in both classes.

### Duplicate constants: BatchSizes vs Estimations
**File:** `src/gitflow_analytics/constants.py` lines 34-75
**Issue:**
```python
class BatchSizes:
    COMMITS_PER_WEEK_ESTIMATE = 50
    DEFAULT_PROGRESS_ESTIMATE = 100

class Estimations:
    COMMITS_PER_WEEK = 50        # identical value
    DEFAULT_ESTIMATE = 100       # identical value
```
Two classes with identical values and same semantic purpose. Code using one class is inconsistent with code using the other.
**Fix:** Delete `Estimations` class, update all references to use `BatchSizes`.

### Debug mode env check duplicated 6 times
**Issue:** `os.getenv("GITFLOW_DEBUG", "").lower() in ("1", "true", "yes")` appears in 6 different files:
- `core/cache.py:63`
- `core/analyzer.py:217`
- `integrations/orchestrator.py:20`
- `pm_framework/orchestrator.py:89`
- `pm_framework/adapters/jira_adapter.py:551`
- `cli.py:5763` (slightly different — checks truthy only)

**Fix:** Add a single helper to `constants.py` or a new `utils/debug.py`:
```python
def is_debug_mode() -> bool:
    import os
    return os.getenv("GITFLOW_DEBUG", "").lower() in ("1", "true", "yes")
```
Import everywhere.

---

## 3. Security Concerns

### HIGH: Pickle deserialization from user-controlled filesystem paths
**Files:**
- `src/gitflow_analytics/classification/model.py:356` — `pickle.load(f)`
- `src/gitflow_analytics/training/model_loader.py:111` — `pickle.load(f)`

**Issue:** Pickle deserialization is inherently unsafe. While model files come from the local filesystem, if an attacker can write to the model directory, they can achieve arbitrary code execution. ruff rule S301 flags both.
**Fix:** Use `joblib` (already a scikit-learn dependency) instead of raw pickle, or use `numpy.load` with `allow_pickle=False` for safer deserialization. Document that model files should only be loaded from trusted directories.

### HIGH: GitHub token embedded in git remote URLs
**File:** `src/gitflow_analytics/core/git_auth.py:153`
```python
new_url = current_url.replace("https://github.com/", f"https://git:{token}@github.com/")
```
**Issue:** Embedding credentials in remote URLs stores the token in `.git/config` in plaintext and causes it to appear in process listings and git logs.
**Fix:** Use git credential helpers or `GIT_ASKPASS` environment variable instead. The token-in-URL approach should be last resort with a warning.

### MEDIUM: SQL injection risk in jira_adapter
**File:** `src/gitflow_analytics/pm_framework/adapters/jira_adapter.py:279`
```python
cursor.execute(
    f"""SELECT ticket_data FROM jira_tickets {where_clause} ORDER BY updated_at DESC""",
    params,
)
```
**Issue:** `where_clause` is built from string concatenation, not parameterized. While current construction only adds static strings, this pattern is fragile and ruff flags it as S608.
**Fix:** Use fully parameterized queries. Construct the conditional as: `" AND expires_at > CURRENT_TIMESTAMP"` is already static but should not be interpolated via f-string.

### MEDIUM: requests.post without timeout
**File:** `src/gitflow_analytics/qualitative/chatgpt_analyzer.py:86`
```python
response = requests.post(self.api_url, headers=headers, json=data)
```
**Issue:** No timeout means a slow or unresponsive API endpoint can hang the process indefinitely.
**Fix:** Add `timeout=30` (or a configurable value). `JIRAIntegration` already has configurable timeout handling — apply same pattern here.

### LOW: Type annotation `list[str] = None` (wrong default type hint)
**File:** `src/gitflow_analytics/security/extractors/secret_detector.py:18`
```python
exclude_paths: list[str] = None,
```
**Issue:** The type annotation claims `list[str]` but the default is `None`. This should be `Optional[list[str]] = None`. While Python doesn't enforce this at runtime, it misleads static analysis tools and IDEs.
**Fix:** Change to `Optional[list[str]] = None` (or `list[str] | None = None` in Python 3.10+).

---

## 4. Performance Improvements

### Lazy imports in cli.py — good practice but partially incomplete
**File:** `src/gitflow_analytics/cli.py` — see comment block at lines 26-38
**Current state:** Heavy imports are commented out and replaced with per-function lazy imports. This is correct but the inline imports at function call time (95 instances in cli.py) create inconsistency.
**Fix:** Consolidate by creating a `_lazy_imports.py` that handles conditional import with caching, or document the pattern consistently.

### 21 debug `logger.info("🔍 DEBUG:")` calls always run at INFO level
**File:** `src/gitflow_analytics/core/data_fetcher.py`
**Issue:** Lines like:
```python
logger.info("🔍 DEBUG: ===== FETCH METHOD CALLED =====")
logger.info(f"🔍 DEBUG: weeks_back={weeks_back}, repo_path={repo_path}")
```
These are logged at INFO level, meaning they appear in normal output unless the user explicitly silences them. They should be at DEBUG level.
**Fix:** Change all `logger.info("🔍 DEBUG:` to `logger.debug(`. This reduces noise in production use and moves them to where they belong.

---

## 5. Missing Error Handling

### 17 `except Exception: pass` or `except Exception: continue` patterns
Ruff security rules (S110, S112) flag these across the codebase. The worst offenders:
- `src/gitflow_analytics/cli_wizards/menu.py:259` — silently ignores file read errors
- `src/gitflow_analytics/models/database.py:1332` — silently ignores DB cleanup errors (comment says "these tables might not exist")
- `src/gitflow_analytics/training/model_loader.py:216` — silently returns 0.0 for file size
- `src/gitflow_analytics/qualitative/core/llm_fallback.py:537` — silently skips token count

**Fix:** Each `except Exception: pass` should at minimum log at DEBUG level:
```python
except Exception as e:
    logger.debug(f"Non-critical error: {e}")
```
The `models/database.py` case could use a more specific exception: `except OperationalError`.

---

## 6. Documentation Gaps

### Missing `requests` in pyproject.toml dependencies
**File:** `pyproject.toml`
**Issue:** `requests` is used directly in:
- `src/gitflow_analytics/integrations/jira_integration.py`
- `src/gitflow_analytics/pm_framework/adapters/jira_adapter.py`
- `src/gitflow_analytics/qualitative/chatgpt_analyzer.py`
- `src/gitflow_analytics/cli_wizards/install_wizard.py`

But `requests` is NOT listed in `[project.dependencies]`. It is only present as `types-requests>=2.28` in dev dependencies. The package currently works because `pygithub` transitively depends on `requests`, but this is fragile — if PyGithub ever changes its internals, the package breaks silently.
**Fix:** Add `requests>=2.28` to `[project.dependencies]`.

### Inconsistent dual pytest configuration
**Files:** `pyproject.toml` and `pytest.ini`
**Issue:** Both files contain pytest configuration:
- `pyproject.toml` adds `--cov=gitflow_analytics --cov-report=html --cov-report=term` to `addopts`
- `pytest.ini` adds `--strict-markers --strict-config --tb=short --disable-warnings -ra` to `addopts`

When both files exist, pytest uses the first one it finds (typically `pytest.ini` overrides). The coverage options in `pyproject.toml` may never run.
**Fix:** Consolidate all pytest config into `pytest.ini` (already has better marker definitions) and remove the `[tool.pytest.ini_options]` section from `pyproject.toml`.

### Extremely weak mypy configuration
**File:** `pyproject.toml` lines 115-130
**Issue:** mypy is configured with nearly all checking disabled:
```toml
disallow_untyped_defs = false
disallow_incomplete_defs = false
check_untyped_defs = false
warn_return_any = false
```
This makes mypy essentially a no-op.
**Fix:** Incrementally tighten by enabling at minimum:
```toml
check_untyped_defs = true
warn_return_any = true
```
These catch real bugs without requiring full annotation coverage.

---

## 7. Configuration Issues

### Untracked `configs/duetto-contractors.yaml` with absolute local paths
**File:** `configs/duetto-contractors.yaml` (untracked, `git status` shows `??`)
**Issue:** This file contains absolute paths like `/Users/masa/Duetto/repos/...` that are specific to one developer's machine. It is not gitignored (the gitignore pattern `config-*.yaml` doesn't match `duetto-contractors.yaml`).
**Fix:** Either add `configs/*.yaml` to `.gitignore` with an exception for sample files, or use environment variable substitution for paths like the project already does for `GITHUB_TOKEN`.

### `EWTN-test/` directory committed to repository
**File:** `.gitignore` line 181 (`EWTN-test/`)
**Issue:** `.gitignore` explicitly tries to ignore `EWTN-test/` but the directory exists at the repo root suggesting it may have been committed before the ignore was added, or the directory is being re-created.
**Note:** Check with `git ls-files EWTN-test/` to see if it's tracked.

---

## 8. Test Coverage Gaps

### Debug scripts in tests/ directory
**Files:** 5 `debug_*.py` scripts and 3 `run_*.py` scripts exist in `tests/`:
- `tests/debug_bulk_exists.py`
- `tests/debug_commit_story_points.py`
- `tests/debug_database_storage.py`
- `tests/debug_jira_enrichment.py`
- `tests/debug_story_points.py`
- `tests/run_all_tests.py`, `tests/run_security_all_repos.py`, `tests/run_security_analysis.py`

These are not picked up by pytest (wrong naming) but clutter the test directory and may contain outdated code.
**Fix:** Move to `scripts/` or delete if they are one-off debug scripts.

### Test files at project root (8 files)
**Issue:** 8 test/debug Python files exist at the project root:
- `test_git_auth_fix.py`, `test_git_cloning_simple.py`, `test_git_cloning.py`
- `test_install_wizard.py`, `test_interactive_launcher.py`, `test_qualitative_detection.py`
- `test_security.py`, `debug_config.py`, `debug_env.py`

The `.gitignore` pattern `test_*.py` should be catching these, but they still exist. These may be running (or not running) inconsistently.
**Fix:** Move genuine tests to `tests/` directory, delete debug scripts.

### No `@pytest.mark.integration` annotations despite having integration tests
**Issue:** The `pytest.ini` defines markers for `integration`, `network`, `external` but not a single test uses them (0 matches in `tests/`). Tests that hit JIRA, GitHub APIs, or require local repos run mixed with unit tests.
**Fix:** Annotate network-dependent tests with `@pytest.mark.external` so they can be excluded in CI with `-m "not external"`.

---

## 9. Dependencies

### `spacy`, `scikit-learn`, `openai`, `tiktoken` as hard dependencies
**File:** `pyproject.toml` lines 41-45
**Issue:** These heavyweight ML/AI dependencies are in the core `dependencies` section, not `optional-dependencies`. A user who only wants basic Git analytics must install spacy (downloads 40MB+ language models separately), scikit-learn, openai SDK, etc.
**Fix:** Move to `optional-dependencies`:
```toml
[project.optional-dependencies]
ml = ["spacy>=3.7.0", "scikit-learn>=1.3.0", "tiktoken>=0.7.0"]
llm = ["openai>=1.30.0"]
```
The codebase already handles missing spacy gracefully (`ML_EXTRACTOR_AVAILABLE` flag in `core/analyzer.py:27`). The code is already written for optional import — just make the dependency optional too.

### `requests` used but not in `[project.dependencies]`
See section 6 above.

---

## 10. Obvious Bugs / Issues

### `COMMITS_PER_WEEK_ESTIMATE` and `COMMITS_PER_WEEK` can diverge
**File:** `src/gitflow_analytics/constants.py`
**Issue:** `BatchSizes.COMMITS_PER_WEEK_ESTIMATE = 50` and `Estimations.COMMITS_PER_WEEK = 50` are currently equal but maintained separately. Any change to one won't automatically update the other, creating silent discrepancies in progress estimates.

### Inline `import re` inside `ImprovedErrorHandler.handle_command_error`
**File:** `src/gitflow_analytics/cli.py` lines 187, 210
**Issue:** `import re` is called inside the error handler function body every time an error occurs. `re` is a stdlib module that gets cached in `sys.modules`, so this isn't a serious performance issue, but it is an anti-pattern and inconsistent with top-level imports.
**Fix:** Move to top-level import (already imported in other parts of cli.py implicitly via other modules).

### `import traceback` inside a function body
**File:** `src/gitflow_analytics/cli.py:153`
```python
import traceback
logger.error(f"  Full traceback:\n{traceback.format_exc()}")
```
**Fix:** Move `import traceback` to top-level imports.

### `import fnmatch` called inside `_should_exclude` on every call
**File:** `src/gitflow_analytics/security/extractors/secret_detector.py:119`
```python
def _should_exclude(self, file_path: str) -> bool:
    from fnmatch import fnmatch
    return any(fnmatch(file_path, pattern) for pattern in self.exclude_paths)
```
Called potentially thousands of times during a scan.
**Fix:** Move `from fnmatch import fnmatch` to module top-level.

### Same issue in `data_fetcher.py` and `analyzer.py`
Both `_matches_glob_pattern` methods do `import fnmatch` and `import re` inside function bodies — called on every file during commit analysis.

---

## Priority Matrix

| Priority | Issue | Effort | Impact |
|----------|-------|--------|--------|
| P1 | Add `requests` to dependencies | 1 min | Prevents installation failures |
| P1 | Fix `logger.info("🔍 DEBUG:")` to `logger.debug` (21 calls) | 10 min | Eliminates log noise |
| P1 | Merge duplicate constants (`Estimations` → `BatchSizes`) | 15 min | Eliminates divergence risk |
| P1 | Fix `Optional[list[str]]` annotation in secret_detector | 2 min | Correctness |
| P2 | Extract glob matching to shared utility | 1 hr | Eliminates 200-line duplication |
| P2 | Consolidate pytest config (remove from pyproject.toml) | 10 min | Fixes coverage reporting |
| P2 | Replace debug env check with helper function | 20 min | Reduces duplication |
| P2 | Add timeout to `requests.post` in chatgpt_analyzer | 5 min | Prevents hangs |
| P2 | Move spacy/sklearn/openai to optional dependencies | 20 min | Reduces install size 70%+ |
| P2 | Fix `except Exception: pass` with at least debug logging | 30 min | Improves debuggability |
| P3 | Move inline stdlib imports to top level | 20 min | Cleanliness |
| P3 | Replace `print()` with `click.echo()` in git_auth.py | 15 min | Consistent output |
| P3 | Fix placeholder URL `yourusername` in CLI docs | 2 min | Correctness |
| P3 | Move root test_*.py files to tests/ | 20 min | Test organization |
| P3 | Split cli.py into command modules | 2-4 hrs | Long-term maintainability |
| P4 | Tighten mypy configuration incrementally | 30 min | Type safety |
| P4 | Replace pickle with joblib for model serialization | 1 hr | Security hardening |
