# CI/CD Integration Patterns Analysis

**Research Date:** 2025-02-09
**Purpose:** Understand codebase patterns for adding new `cicd` integration module
**Scope:** Architecture, integration patterns, CLI structure, data models, report generation

---

## Executive Summary

The gitflow-analytics codebase follows a well-structured integration pattern with clear separation of concerns. Adding a new CI/CD integration module should follow the established patterns used by GitHub and JIRA integrations.

**Key Findings:**
- ✅ Integration modules live in `src/gitflow_analytics/integrations/`
- ✅ Integration orchestration handled by `orchestrator.py`
- ✅ CLI uses Click framework with decorator-based commands
- ✅ Reports follow abstract base class pattern with CSV/JSON/Markdown output
- ✅ Data models use SQLAlchemy for caching (see `models/database.py`)
- ✅ All integrations use cache-backed enrichment pattern

---

## 1. Project Structure

### Core Integration Directory
```
src/gitflow_analytics/integrations/
├── __init__.py                    # Empty integration registry
├── github_integration.py          # GitHub API integration (339 lines)
├── jira_integration.py           # JIRA API integration (722 lines)
└── orchestrator.py               # Integration coordinator (288 lines)
```

### Supporting Infrastructure
```
src/gitflow_analytics/
├── core/
│   ├── cache.py                  # GitAnalysisCache class
│   └── schema_version.py         # Incremental fetch tracking
├── models/
│   └── database.py               # SQLAlchemy models for caching
├── reports/
│   ├── base.py                   # BaseReportGenerator (abstract)
│   ├── csv_writer.py             # CSV report implementation
│   ├── json_exporter.py          # JSON export
│   └── interfaces.py             # Report interfaces/protocols
└── cli.py                        # Click-based CLI (6989 lines)
```

---

## 2. Integration Pattern Analysis

### Pattern: Cache-Backed Enrichment

All integrations follow this pattern:

```python
class IntegrationClass:
    def __init__(self, credentials, cache: GitAnalysisCache, ...):
        self.cache = cache
        self.schema_manager = create_schema_manager(cache.cache_dir)

    def enrich_repository_data(self, commits, since):
        # 1. Check cache first (bulk lookup)
        cached_data = self._get_cached_bulk(since)

        # 2. Fetch only missing data from API
        new_data = self._fetch_missing(cached_data)

        # 3. Cache new data (bulk insert)
        self._cache_bulk(new_data)

        # 4. Enrich commits with combined data
        return self._enrich(cached_data + new_data)
```

### Key Components

**1. Incremental Fetching**
```python
# From github_integration.py:35-68
def _get_incremental_fetch_date(self, component, requested_since, config):
    """Determine fetch date based on schema versioning."""
    if self.schema_manager.has_schema_changed(component, config):
        return requested_since  # Full fetch

    last_processed = self.schema_manager.get_last_processed_date(component)
    return max(last_processed, requested_since)  # Incremental
```

**2. Bulk Cache Operations**
```python
# From jira_integration.py:414-453
def _get_cached_tickets_bulk(self, ticket_ids):
    """Get multiple tickets from cache in single query."""
    with self.cache.get_session() as session:
        cached_results = session.query(IssueCache).filter(
            IssueCache.platform == "jira",
            IssueCache.issue_id.in_(ticket_ids)
        ).all()
    return cached_tickets

def _cache_tickets_bulk(self, tickets):
    """Cache multiple tickets in single transaction."""
    for ticket_data in tickets:
        self._cache_ticket(ticket_data["id"], ticket_data)
```

**3. Network Resilience**
```python
# From jira_integration.py:560-599
def _create_resilient_session(self):
    """Create HTTP session with enhanced retry logic."""
    retry_strategy = Retry(
        total=self.max_retries,
        backoff_factor=self.backoff_factor,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS", "POST"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session
```

---

## 3. Integration Orchestrator Pattern

### File: `integrations/orchestrator.py`

**Purpose:** Coordinate multiple integrations and aggregate data

**Key Methods:**

```python
class IntegrationOrchestrator:
    def __init__(self, config, cache):
        self.integrations = {}

        # Initialize GitHub if configured
        if config.github and config.github.token:
            self.integrations["github"] = GitHubIntegration(...)

        # Initialize JIRA if configured
        if config.jira and config.jira.access_user:
            self.integrations["jira"] = JIRAIntegration(...)

        # Initialize PM Framework orchestrator
        if config.pm_integration and config.pm_integration.enabled:
            self.pm_orchestrator = PMFrameworkOrchestrator(...)

    def enrich_repository_data(self, repo_config, commits, since):
        """Enrich from all available integrations."""
        enrichment = {"prs": [], "issues": [], "pm_data": {}}

        # GitHub enrichment
        if "github" in self.integrations:
            prs = self.integrations["github"].enrich_repository_with_prs(...)
            enrichment["prs"] = prs

        # JIRA enrichment
        if "jira" in self.integrations:
            self.integrations["jira"].enrich_commits_with_jira_data(commits)

        # PM Framework enrichment
        if self.pm_orchestrator and self.pm_orchestrator.is_enabled():
            pm_issues = self.pm_orchestrator.get_all_issues(since)
            enrichment["pm_data"]["issues"] = pm_issues

        return enrichment
```

**Pattern for CI/CD Integration:**
Add CI/CD initialization block similar to GitHub/JIRA, then add enrichment method call in `enrich_repository_data()`.

---

## 4. Data Models & Caching

### Database Schema (SQLAlchemy)

**File:** `models/database.py` (53,818 bytes - comprehensive)

**Existing Cache Tables:**
- `PullRequestCache` - GitHub PR data
- `IssueCache` - JIRA/GitHub/ClickUp/Linear issues
- `IdentityCache` - Developer identity resolution
- `CommitClassificationCache` - ML classification results

**Pattern for CI/CD Cache Table:**

```python
class CICDBuildCache(Base):
    """Cache for CI/CD build data."""
    __tablename__ = "cicd_builds"

    id = Column(Integer, primary_key=True)

    # Build identification
    platform = Column(String)  # "github_actions", "gitlab_ci", etc.
    build_id = Column(String, index=True)
    pipeline_name = Column(String)

    # Build metadata
    repo_path = Column(String, index=True)
    branch = Column(String)
    commit_sha = Column(String, index=True)

    # Build results
    status = Column(String)  # "success", "failure", "cancelled"
    started_at = Column(DateTime, index=True)
    completed_at = Column(DateTime)
    duration_seconds = Column(Integer)

    # Additional data
    trigger_type = Column(String)  # "push", "pull_request", "schedule"
    author = Column(String)
    url = Column(String)

    # Platform-specific data (JSON)
    platform_data = Column(JSON)

    # Cache metadata
    cached_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index('idx_cicd_repo_date', 'repo_path', 'started_at'),
        Index('idx_cicd_platform_id', 'platform', 'build_id'),
    )
```

---

## 5. CLI Integration Patterns

### File: `cli.py` (6,989 lines)

**CLI Framework:** Click with decorator-based commands

**Pattern: Adding New CLI Flags**

```python
@click.option(
    "--cicd-metrics",
    is_flag=True,
    help="Include CI/CD metrics in analysis"
)
@click.option(
    "--cicd-platforms",
    multiple=True,
    type=click.Choice(["github_actions", "gitlab_ci", "jenkins", "circleci"]),
    help="CI/CD platforms to integrate"
)
def analyze_subcommand(
    config,
    cicd_metrics,
    cicd_platforms,
    # ... other params
):
    """Analyze Git repositories with optional integrations."""
    # Load configuration
    cfg = load_config(config)

    # Initialize cache
    cache = GitAnalysisCache(cfg.cache.directory, cfg.cache.ttl_hours)

    # Initialize integration orchestrator
    orchestrator = IntegrationOrchestrator(cfg, cache)

    # CI/CD enrichment (if enabled)
    if cicd_metrics and cfg.cicd:
        cicd_data = orchestrator.integrations["cicd"].enrich_repository_data(...)
```

**Existing Command Structure:**
- `analyze` - Main analysis command (default)
- `fetch` - Fetch data from integrations
- `cache-stats` - Cache statistics
- `discover-storypoint-fields` - JIRA field discovery
- `identities` - Identity management
- `train` - ML model training

**Recommended CI/CD Commands:**
- `analyze --cicd-metrics` - Include CI/CD in main analysis
- `fetch --cicd` - Fetch CI/CD data only
- `cicd-stats` - CI/CD specific statistics (optional)

---

## 6. Report Generation Patterns

### Report Architecture

**Base Class Pattern:**

```python
# From reports/base.py
class BaseReportGenerator(ABC):
    def __init__(self, anonymize, exclude_authors, identity_resolver, config):
        self.anonymize = anonymize
        self.exclude_authors = exclude_authors or []
        self.identity_resolver = identity_resolver
        self.config = config or {}

    @abstractmethod
    def generate(self, data: ReportData, output_path: Path) -> ReportOutput:
        """Generate the report."""
        pass

    @abstractmethod
    def get_required_fields(self) -> List[str]:
        """Get list of required data fields."""
        pass

    @abstractmethod
    def get_format_type(self) -> str:
        """Get the format type this generator produces."""
        pass
```

**Data Container Pattern:**

```python
@dataclass
class ReportData:
    """Standardized data container for report generation."""

    # Core data
    commits: List[Dict[str, Any]] = field(default_factory=list)
    pull_requests: List[Dict[str, Any]] = field(default_factory=list)
    developer_stats: List[Dict[str, Any]] = field(default_factory=list)

    # Analysis results
    activity_data: List[Dict[str, Any]] = field(default_factory=list)
    focus_data: List[Dict[str, Any]] = field(default_factory=list)

    # Metrics
    pr_metrics: Dict[str, Any] = field(default_factory=dict)
    dora_metrics: Dict[str, Any] = field(default_factory=dict)
    branch_health_metrics: List[Dict[str, Any]] = field(default_factory=list)

    # PM data
    pm_data: Optional[Dict[str, Any]] = None
    story_points_data: Optional[Dict[str, Any]] = None

    # Metadata
    metadata: ReportMetadata = field(default_factory=ReportMetadata)
```

**Pattern for CI/CD Metrics:**

Add to `ReportData` dataclass:

```python
@dataclass
class ReportData:
    # ... existing fields ...

    # CI/CD metrics
    cicd_metrics: Dict[str, Any] = field(default_factory=dict)
    build_data: List[Dict[str, Any]] = field(default_factory=list)
```

**CSV Export Pattern:**

```python
# From reports/csv_writer.py
class CSVReportGenerator(BaseReportGenerator):
    def generate(self, data: ReportData, output_path: Path) -> ReportOutput:
        # Validate data
        if not self.validate_data(data):
            return ReportOutput(success=False, errors=["Invalid data"])

        # Pre-process (filter, anonymize)
        data = self.pre_process(data)

        # Generate CSV based on filename
        if "weekly" in output_path.name.lower():
            self.generate_weekly_report(data.commits, data.developer_stats, output_path)
        elif "cicd" in output_path.name.lower():
            self.generate_cicd_report(data.cicd_metrics, data.build_data, output_path)

        return ReportOutput(success=True, file_path=output_path, format="csv")
```

---

## 7. Configuration Pattern

### File: Test Configuration (`tests/test_config_minimal.yaml`)

**Existing Configuration Structure:**

```yaml
analysis:
  weeks: 2
  similarity_threshold: 0.85
  branch_mapping_rules: {}
  exclude_paths: []
  manual_identity_mappings: []
  auto_identity_analysis: true

repositories:
  - name: "gitflow-analytics"
    path: "/path/to/repo"
    project_key: "GFA"
    branch: "main"

cache:
  directory: "/path/to/cache"
  ttl_hours: 168

output:
  directory: "/path/to/reports"
  formats: ["markdown", "csv", "json"]
  anonymize_enabled: false

github:
  token: "${GITHUB_TOKEN}"
  max_retries: 3
  backoff_factor: 2

jira:
  base_url: "https://company.atlassian.net"
  access_user: "user@company.com"
  access_token: "${JIRA_API_TOKEN}"
```

**Recommended CI/CD Configuration:**

```yaml
# Add to existing config structure
cicd:
  enabled: true
  platforms:
    github_actions:
      enabled: true
      token: "${GITHUB_TOKEN}"  # Reuse GitHub token
    gitlab_ci:
      enabled: false
      base_url: "https://gitlab.com"
      token: "${GITLAB_TOKEN}"
    jenkins:
      enabled: false
      base_url: "https://jenkins.company.com"
      username: "${JENKINS_USER}"
      api_token: "${JENKINS_TOKEN}"

  # CI/CD specific settings
  fetch_days: 90  # How far back to fetch builds
  include_failed_builds: true
  include_cancelled_builds: false
  cache_ttl_hours: 24

  # Metrics configuration
  metrics:
    calculate_build_frequency: true
    calculate_failure_rate: true
    calculate_mttr: true
    group_by: ["branch", "pipeline", "author"]
```

---

## 8. Implementation Recommendations

### Module Structure for `cicd` Integration

```
src/gitflow_analytics/integrations/cicd/
├── __init__.py              # Export main classes
├── base.py                  # BaseCICDIntegration (abstract)
├── github_actions.py        # GitHub Actions implementation
├── gitlab_ci.py             # GitLab CI implementation
├── jenkins.py               # Jenkins implementation
├── models.py                # Data models for builds/pipelines
└── utils.py                 # Shared utilities
```

**Why this structure?**
- Multiple CI/CD platforms require abstraction
- Each platform has different API patterns
- Shared base class enforces consistency
- Follows plugin architecture for extensibility

### Base CI/CD Integration Class

```python
# src/gitflow_analytics/integrations/cicd/base.py
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any, Dict, List

class BaseCICDIntegration(ABC):
    """Base class for CI/CD platform integrations."""

    def __init__(self, cache, **kwargs):
        self.cache = cache
        self.schema_manager = create_schema_manager(cache.cache_dir)

    @abstractmethod
    def fetch_builds(self, repo_name: str, since: datetime) -> List[Dict[str, Any]]:
        """Fetch builds from the platform."""
        pass

    @abstractmethod
    def enrich_commits_with_builds(self, commits: List[Dict], builds: List[Dict]) -> None:
        """Enrich commits with build status."""
        pass

    @abstractmethod
    def calculate_metrics(self, builds: List[Dict]) -> Dict[str, Any]:
        """Calculate CI/CD metrics."""
        pass

    def _get_cached_builds_bulk(self, repo_name: str, since: datetime) -> List[Dict]:
        """Get cached builds (follows pattern from JIRA)."""
        # Implementation similar to _get_cached_tickets_bulk
        pass

    def _cache_builds_bulk(self, builds: List[Dict]) -> None:
        """Cache multiple builds (follows pattern from JIRA)."""
        # Implementation similar to _cache_tickets_bulk
        pass
```

### GitHub Actions Implementation Example

```python
# src/gitflow_analytics/integrations/cicd/github_actions.py
from github import Github
from .base import BaseCICDIntegration

class GitHubActionsIntegration(BaseCICDIntegration):
    """GitHub Actions CI/CD integration."""

    def __init__(self, token: str, cache, **kwargs):
        super().__init__(cache, **kwargs)
        self.github = Github(token)

    def fetch_builds(self, repo_name: str, since: datetime) -> List[Dict[str, Any]]:
        """Fetch workflow runs from GitHub Actions."""
        repo = self.github.get_repo(repo_name)

        # Check cache first
        cached_builds = self._get_cached_builds_bulk(repo_name, since)

        # Fetch missing builds
        runs = repo.get_workflow_runs(created=f">={since.isoformat()}")

        builds = []
        for run in runs:
            if not self._is_cached(run.id, cached_builds):
                build_data = self._extract_build_data(run)
                builds.append(build_data)

        # Cache new builds
        self._cache_builds_bulk(builds)

        return cached_builds + builds

    def _extract_build_data(self, run) -> Dict[str, Any]:
        """Extract build data from workflow run."""
        return {
            "platform": "github_actions",
            "build_id": str(run.id),
            "pipeline_name": run.name,
            "repo_path": run.repository.full_name,
            "branch": run.head_branch,
            "commit_sha": run.head_sha,
            "status": run.conclusion,  # "success", "failure", etc.
            "started_at": run.created_at,
            "completed_at": run.updated_at,
            "duration_seconds": (run.updated_at - run.created_at).total_seconds(),
            "trigger_type": run.event,
            "author": run.head_commit.author.name if run.head_commit else None,
            "url": run.html_url,
            "platform_data": {
                "workflow_id": run.workflow_id,
                "run_number": run.run_number,
                "attempt": run.run_attempt,
            }
        }
```

### Integration into Orchestrator

```python
# Update src/gitflow_analytics/integrations/orchestrator.py

class IntegrationOrchestrator:
    def __init__(self, config, cache):
        # ... existing initializations ...

        # Initialize CI/CD integrations
        if config.cicd and config.cicd.enabled:
            self.cicd_integrations = {}

            for platform_name, platform_config in config.cicd.platforms.items():
                if platform_config.enabled:
                    if platform_name == "github_actions":
                        from .cicd.github_actions import GitHubActionsIntegration
                        self.cicd_integrations[platform_name] = GitHubActionsIntegration(
                            platform_config.token,
                            cache,
                            **platform_config
                        )
                    # Add other platforms...

    def enrich_repository_data(self, repo_config, commits, since):
        enrichment = {
            # ... existing enrichments ...
            "cicd_data": {"builds": [], "metrics": {}}
        }

        # ... existing enrichments ...

        # CI/CD enrichment
        if hasattr(self, 'cicd_integrations'):
            all_builds = []
            for platform_name, cicd_integration in self.cicd_integrations.items():
                try:
                    builds = cicd_integration.fetch_builds(repo_config.github_repo, since)
                    cicd_integration.enrich_commits_with_builds(commits, builds)
                    all_builds.extend(builds)
                except Exception as e:
                    print(f"   ⚠️  CI/CD enrichment failed for {platform_name}: {e}")

            enrichment["cicd_data"]["builds"] = all_builds

            # Calculate aggregate metrics
            if all_builds:
                enrichment["cicd_data"]["metrics"] = self._calculate_cicd_metrics(all_builds)

        return enrichment
```

---

## 9. Metrics Calculation Pattern

### Example: DORA Metrics Integration

**File:** `metrics/dora.py` - Already exists!

**Current DORA Metrics:**
- Deployment frequency
- Lead time for changes
- Change failure rate
- Mean time to recovery (MTTR)

**Enhancement: Integrate CI/CD Data**

```python
class DORAMetricsCalculator:
    def calculate_dora_metrics_with_cicd(
        self,
        commits: List[Dict],
        prs: List[Dict],
        cicd_builds: List[Dict],
        start_date: datetime,
        end_date: datetime
    ) -> Dict[str, Any]:
        """Calculate DORA metrics enhanced with CI/CD data."""

        # Use actual build data instead of commit patterns
        deployments = self._identify_deployments_from_builds(cicd_builds)
        failures = self._identify_failures_from_builds(cicd_builds)

        # Enhanced deployment frequency (actual builds vs. commit patterns)
        deployment_frequency = len(deployments) / (end_date - start_date).days

        # Enhanced lead time (time from commit to successful deployment)
        lead_time = self._calculate_lead_time_with_builds(commits, deployments)

        # Enhanced change failure rate (failed builds / total builds)
        change_failure_rate = len(failures) / len(deployments) if deployments else 0

        # Enhanced MTTR (time from failure to recovery)
        mttr = self._calculate_mttr_with_builds(failures, cicd_builds)

        return {
            "deployment_frequency_per_day": deployment_frequency,
            "lead_time_hours": lead_time,
            "change_failure_rate": change_failure_rate,
            "mttr_hours": mttr,
            "data_source": "cicd_builds",  # vs. "commit_patterns"
            "total_builds": len(cicd_builds),
            "successful_builds": len(deployments),
            "failed_builds": len(failures),
        }
```

---

## 10. Report Integration

### CSV Report Enhancement

**Add CI/CD columns to weekly metrics:**

```python
# In reports/csv_writer.py
def generate_weekly_cicd_report(self, commits, builds, output_path):
    """Generate weekly report with CI/CD metrics."""

    weekly_data = []
    for week_start in self._get_week_ranges(commits):
        week_commits = [c for c in commits if week_start <= c['timestamp'] < week_start + timedelta(days=7)]
        week_builds = [b for b in builds if week_start <= b['started_at'] < week_start + timedelta(days=7)]

        weekly_data.append({
            'week': week_start.strftime('%Y-%m-%d'),
            'commits': len(week_commits),
            'total_builds': len(week_builds),
            'successful_builds': len([b for b in week_builds if b['status'] == 'success']),
            'failed_builds': len([b for b in week_builds if b['status'] == 'failure']),
            'build_success_rate': self._calculate_success_rate(week_builds),
            'avg_build_duration_minutes': self._avg_duration(week_builds) / 60,
            'deployment_frequency': len([b for b in week_builds if self._is_deployment(b)]),
        })

    df = pd.DataFrame(weekly_data)
    df.to_csv(output_path, index=False)
```

### JSON Export Enhancement

**Add CI/CD section to JSON export:**

```python
# In integrations/orchestrator.py
def export_to_json(
    self,
    commits, prs, developer_stats,
    project_metrics, dora_metrics,
    cicd_data,  # NEW
    output_path
):
    """Export all data to JSON format."""

    export_data = {
        "metadata": {...},
        "commits": serialize_dates(commits),
        "pull_requests": serialize_dates(prs),
        "developers": serialize_dates(developer_stats),
        "project_metrics": serialize_dates(project_metrics),
        "dora_metrics": serialize_dates(dora_metrics),
        "cicd_data": {  # NEW
            "builds": serialize_dates(cicd_data.get("builds", [])),
            "metrics": serialize_dates(cicd_data.get("metrics", {})),
            "platforms": list(cicd_data.get("platforms", {}).keys())
        }
    }

    with open(output_path, 'w') as f:
        json.dump(export_data, f, indent=2)
```

---

## 11. Key Files to Reference

### Must-Read Files (Implementation Patterns)

| File | Lines | Purpose | Key Patterns |
|------|-------|---------|--------------|
| `integrations/github_integration.py` | 339 | GitHub API integration | Cache-backed enrichment, bulk operations, incremental fetch |
| `integrations/jira_integration.py` | 722 | JIRA API integration | Network resilience, DNS handling, bulk cache, field discovery |
| `integrations/orchestrator.py` | 288 | Integration coordination | Multi-integration orchestration, error handling, data aggregation |
| `reports/base.py` | ~600 | Report generation base | Abstract base class, data validation, anonymization |
| `reports/csv_writer.py` | 2048 | CSV report generation | Weekly aggregation, pandas DataFrame, filtering |
| `reports/interfaces.py` | 489 | Report interfaces | Protocol definitions, data contracts, format enums |
| `models/database.py` | 53818 | Database schema | SQLAlchemy models, cache tables, indexes |
| `metrics/dora.py` | ~400 | DORA metrics | Metrics calculation, pattern detection, performance levels |

### Configuration Files

| File | Purpose |
|------|---------|
| `tests/test_config_minimal.yaml` | Minimal configuration example |
| `config.py` | Configuration loading and validation |

### CLI Files

| File | Lines | Purpose |
|------|-------|---------|
| `cli.py` | 6989 | Main CLI implementation with Click decorators |

---

## 12. Existing CI/CD References in Codebase

**Found 20 references to "CI/CD" in:**
- Documentation files (CHANGELOG.md, README.md)
- Ticket files (TSK-0085.md)
- Test files (test_ml_comprehensive.py)
- Agent definitions (.claude/agents/)

**No existing CI/CD integration code found** - This is a greenfield implementation!

---

## 13. Implementation Checklist

### Phase 1: Data Models & Caching
- [ ] Create `CICDBuildCache` table in `models/database.py`
- [ ] Add migration script for new table
- [ ] Implement bulk cache lookup methods
- [ ] Test cache TTL and invalidation

### Phase 2: Base Integration Class
- [ ] Create `integrations/cicd/` directory
- [ ] Implement `base.py` with `BaseCICDIntegration`
- [ ] Add shared utilities in `utils.py`
- [ ] Define data models in `models.py`

### Phase 3: GitHub Actions Integration
- [ ] Implement `github_actions.py`
- [ ] Add workflow run fetching
- [ ] Implement build data extraction
- [ ] Add commit-to-build correlation
- [ ] Test with real GitHub repos

### Phase 4: Orchestrator Integration
- [ ] Update `orchestrator.py` to initialize CI/CD integrations
- [ ] Add CI/CD enrichment to `enrich_repository_data()`
- [ ] Implement error handling and fallbacks
- [ ] Add debug logging

### Phase 5: Configuration
- [ ] Add `cicd` section to configuration schema
- [ ] Update `config.py` validation
- [ ] Add environment variable support
- [ ] Update documentation

### Phase 6: CLI Integration
- [ ] Add `--cicd-metrics` flag to `analyze` command
- [ ] Add `--cicd-platforms` option
- [ ] Add `fetch --cicd` command
- [ ] Update help text

### Phase 7: Metrics Calculation
- [ ] Enhance DORA metrics with CI/CD data
- [ ] Add build frequency metrics
- [ ] Add failure rate calculations
- [ ] Add MTTR calculations with build data

### Phase 8: Report Generation
- [ ] Add `cicd_metrics` field to `ReportData`
- [ ] Enhance CSV reports with CI/CD columns
- [ ] Update JSON export with CI/CD section
- [ ] Add CI/CD section to Markdown narratives

### Phase 9: Testing
- [ ] Unit tests for base integration
- [ ] Integration tests with mock data
- [ ] End-to-end tests with real repos
- [ ] Performance benchmarks

### Phase 10: Documentation
- [ ] Update README with CI/CD features
- [ ] Add CI/CD configuration guide
- [ ] Create API documentation
- [ ] Add usage examples

---

## 14. Anti-Patterns to Avoid

### ❌ Don't Do This:

**1. Tight Coupling to Specific Platform**
```python
# BAD: Hard-coded GitHub Actions logic in orchestrator
class IntegrationOrchestrator:
    def enrich_repository_data(self, ...):
        # Directly calling GitHub Actions API
        runs = github_client.get_workflow_runs(...)
```

**2. Synchronous API Calls Without Caching**
```python
# BAD: No caching, every run hits API
def fetch_builds(self, repo_name):
    return self.api_client.get_builds(repo_name)  # Always fresh fetch
```

**3. Missing Error Handling**
```python
# BAD: No try/except, crashes entire analysis
def enrich_with_cicd(self, commits):
    builds = self.fetch_builds()  # Can fail
    return self.correlate(commits, builds)  # Can fail
```

**4. Platform-Specific Data in Shared Models**
```python
# BAD: GitHub Actions specific fields in shared model
class CICDBuild:
    workflow_id: int  # GitHub Actions specific!
    run_number: int   # GitHub Actions specific!
```

### ✅ Do This Instead:

**1. Abstract Base Class with Plugins**
```python
# GOOD: Plugin architecture with base class
class BaseCICDIntegration(ABC):
    @abstractmethod
    def fetch_builds(self, repo_name: str, since: datetime) -> List[Dict]:
        pass

class GitHubActionsIntegration(BaseCICDIntegration):
    def fetch_builds(self, repo_name: str, since: datetime) -> List[Dict]:
        # Implementation...
```

**2. Cache-First Pattern**
```python
# GOOD: Cache-backed enrichment
def fetch_builds(self, repo_name, since):
    cached = self._get_cached_builds_bulk(repo_name, since)
    missing = self._fetch_missing_builds(cached, since)
    self._cache_builds_bulk(missing)
    return cached + missing
```

**3. Comprehensive Error Handling**
```python
# GOOD: Try/except with fallback
def enrich_with_cicd(self, commits):
    try:
        builds = self.fetch_builds()
        return self.correlate(commits, builds)
    except Exception as e:
        self.logger.warning(f"CI/CD enrichment failed: {e}")
        return None  # Graceful degradation
```

**4. Platform-Agnostic Models with Extensions**
```python
# GOOD: Shared fields + platform_data JSON
class CICDBuild:
    platform: str
    build_id: str
    status: str
    # ... shared fields ...
    platform_data: Dict[str, Any]  # Platform-specific JSON
```

---

## 15. Performance Considerations

### Database Indexes

```python
# Add to CICDBuildCache model
__table_args__ = (
    Index('idx_cicd_repo_date', 'repo_path', 'started_at'),
    Index('idx_cicd_platform_id', 'platform', 'build_id'),
    Index('idx_cicd_commit_sha', 'commit_sha'),
    Index('idx_cicd_status', 'status'),
)
```

**Why:** Bulk lookups by repo+date range are the most common query pattern

### Bulk Operations

```python
# Fetch builds in batches
def fetch_builds(self, repo_name, since):
    batch_size = 100
    all_builds = []
    page = 1

    while True:
        builds = self._fetch_page(repo_name, since, page, batch_size)
        if not builds:
            break
        all_builds.extend(builds)
        page += 1

    return all_builds
```

**Why:** Prevents memory issues with large result sets

### API Rate Limiting

```python
# Add rate limit handling (from github_integration.py pattern)
for attempt in range(self.rate_limit_retries):
    try:
        return self.api_client.fetch_builds(...)
    except RateLimitExceededException:
        if attempt < self.rate_limit_retries - 1:
            wait_time = self.backoff_factor ** attempt
            time.sleep(wait_time)
        else:
            raise
```

**Why:** API rate limits are common across CI/CD platforms

---

## 16. Testing Strategy

### Unit Tests

```python
# tests/integrations/test_cicd_github_actions.py
def test_fetch_builds_with_cache(mock_github_client, test_cache):
    integration = GitHubActionsIntegration("token", test_cache)

    # First fetch - cache miss
    builds = integration.fetch_builds("owner/repo", datetime(2025, 1, 1))
    assert len(builds) == 10
    assert mock_github_client.call_count == 1

    # Second fetch - cache hit
    builds = integration.fetch_builds("owner/repo", datetime(2025, 1, 1))
    assert len(builds) == 10
    assert mock_github_client.call_count == 1  # Still 1, cached
```

### Integration Tests

```python
# tests/integration/test_cicd_enrichment.py
def test_cicd_enrichment_end_to_end(test_config, test_repos):
    orchestrator = IntegrationOrchestrator(test_config, test_cache)

    commits = fetch_commits(test_repos[0])
    enrichment = orchestrator.enrich_repository_data(
        test_repos[0], commits, datetime(2025, 1, 1)
    )

    assert "cicd_data" in enrichment
    assert len(enrichment["cicd_data"]["builds"]) > 0
    assert "metrics" in enrichment["cicd_data"]
```

### Mock Data

```python
# tests/fixtures/cicd_data.py
SAMPLE_GITHUB_ACTIONS_BUILD = {
    "platform": "github_actions",
    "build_id": "123456789",
    "pipeline_name": "CI Pipeline",
    "repo_path": "owner/repo",
    "branch": "main",
    "commit_sha": "abc123",
    "status": "success",
    "started_at": datetime(2025, 2, 1, 10, 0, 0),
    "completed_at": datetime(2025, 2, 1, 10, 15, 0),
    "duration_seconds": 900,
    "trigger_type": "push",
    "author": "developer@example.com",
    "url": "https://github.com/owner/repo/actions/runs/123456789",
}
```

---

## 17. Documentation Requirements

### README Update

Add to "Core Capabilities" section:

```markdown
**📊 CI/CD Integration**
- GitHub Actions workflow metrics
- GitLab CI pipeline analysis
- Build success/failure tracking
- Enhanced DORA metrics with actual build data
- Build duration and frequency analysis
```

### Configuration Guide

Create `docs/integrations/cicd.md`:

```markdown
# CI/CD Integration Guide

## Overview
GitFlow Analytics integrates with CI/CD platforms to enhance metrics with actual build data...

## Configuration
Add to your `config.yaml`:

\`\`\`yaml
cicd:
  enabled: true
  platforms:
    github_actions:
      enabled: true
      token: "${GITHUB_TOKEN}"
\`\`\`

## Supported Platforms
- GitHub Actions (✅ Implemented)
- GitLab CI (🚧 Planned)
- Jenkins (🚧 Planned)
- CircleCI (🚧 Planned)

## Metrics
- Build frequency per week
- Build success rate
- Average build duration
- Deployment frequency (DORA)
- Change failure rate (DORA)
- Mean time to recovery (DORA)
```

---

## 18. Summary & Next Steps

### What You Need to Build

**1. Core Integration Module** (`integrations/cicd/`)
- Base abstract class for platform independence
- GitHub Actions implementation as first platform
- Shared utilities and data models

**2. Database Schema** (`models/database.py`)
- `CICDBuildCache` table for caching build data
- Appropriate indexes for performance
- Migration script

**3. Orchestrator Integration** (`integrations/orchestrator.py`)
- Initialize CI/CD integrations
- Add to `enrich_repository_data()` flow
- Error handling and graceful degradation

**4. Configuration** (`config.py`, `config.yaml`)
- Add `cicd` configuration section
- Platform-specific settings
- Validation logic

**5. CLI Commands** (`cli.py`)
- Add `--cicd-metrics` flag
- Add `--cicd-platforms` option
- Update help documentation

**6. Metrics Enhancement** (`metrics/dora.py`)
- Enhance DORA metrics with actual build data
- Add CI/CD-specific metrics calculations
- Build frequency, failure rate, MTTR

**7. Report Generation** (`reports/`)
- Add `cicd_metrics` to `ReportData`
- Update CSV writer with CI/CD columns
- Update JSON exporter with CI/CD section
- Add CI/CD section to Markdown reports

### Patterns to Follow

✅ **Cache-backed enrichment** (from GitHub/JIRA)
✅ **Bulk operations** (cache lookups, API fetches)
✅ **Incremental fetching** (schema versioning)
✅ **Network resilience** (retries, timeouts, DNS handling)
✅ **Error handling** (try/except with fallback)
✅ **Abstract base classes** (platform independence)
✅ **Protocol-based interfaces** (report generation)
✅ **Dataclass models** (type safety, validation)

### Quick Start Recommendation

**Start with GitHub Actions integration:**
1. Most projects already use GitHub Actions
2. GitHub API is well-documented and stable
3. Reuse existing GitHub token from config
4. Leverage existing `github` library dependency
5. Natural extension of existing GitHub integration

**Implementation Order:**
1. Database model + cache table
2. Base CI/CD integration class
3. GitHub Actions integration
4. Orchestrator integration
5. CLI flags
6. Basic metrics
7. Report generation
8. Testing
9. Documentation

---

## 19. Reference Commands

### Useful Grep Patterns

```bash
# Find integration patterns
grep -r "class.*Integration" src/gitflow_analytics/integrations/

# Find cache patterns
grep -r "_get_cached.*bulk\|_cache.*bulk" src/gitflow_analytics/

# Find report generators
grep -r "class.*ReportGenerator\|class.*Writer" src/gitflow_analytics/reports/

# Find CLI commands
grep -n "^@click\|^def " src/gitflow_analytics/cli.py

# Find database models
grep -r "class.*Cache.*Base\|__tablename__" src/gitflow_analytics/models/
```

### File Size Reference

```bash
# Large files to understand comprehensively
wc -l src/gitflow_analytics/cli.py              # 6989 lines
wc -l src/gitflow_analytics/models/database.py  # ~1500 lines
wc -l src/gitflow_analytics/reports/csv_writer.py  # ~2000 lines

# Medium files to reference for patterns
wc -l src/gitflow_analytics/integrations/jira_integration.py    # 722 lines
wc -l src/gitflow_analytics/integrations/github_integration.py  # 339 lines
wc -l src/gitflow_analytics/integrations/orchestrator.py        # 288 lines
```

---

## Appendix A: Code Examples

### Example 1: Complete GitHub Actions Integration

```python
"""GitHub Actions CI/CD integration."""

import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from github import Github
from github.GithubException import RateLimitExceededException, UnknownObjectException

from .base import BaseCICDIntegration


class GitHubActionsIntegration(BaseCICDIntegration):
    """Integrate with GitHub Actions for CI/CD data."""

    def __init__(
        self,
        token: str,
        cache,
        rate_limit_retries: int = 3,
        backoff_factor: int = 2,
        **kwargs
    ):
        """Initialize GitHub Actions integration.

        Args:
            token: GitHub personal access token
            cache: GitAnalysisCache instance
            rate_limit_retries: Number of retry attempts on rate limit
            backoff_factor: Exponential backoff factor
        """
        super().__init__(cache, **kwargs)
        self.github = Github(token)
        self.rate_limit_retries = rate_limit_retries
        self.backoff_factor = backoff_factor
        self.platform_name = "github_actions"

    def fetch_builds(
        self,
        repo_name: str,
        since: datetime
    ) -> List[Dict[str, Any]]:
        """Fetch workflow runs from GitHub Actions.

        Args:
            repo_name: Repository name (e.g., "owner/repo")
            since: Fetch builds created after this date

        Returns:
            List of build data dictionaries
        """
        try:
            repo = self.github.get_repo(repo_name)
        except UnknownObjectException:
            print(f"   ⚠️  GitHub repo not found: {repo_name}")
            return []

        # Check cache first
        cached_builds = self._get_cached_builds_bulk(repo_name, since)

        # Determine which builds are missing
        cached_build_ids = {b["build_id"] for b in cached_builds}

        # Fetch workflow runs with rate limiting
        new_builds = []
        for attempt in range(self.rate_limit_retries):
            try:
                # Get all workflow runs updated since date
                for run in repo.get_workflow_runs():
                    # Stop if we've reached our date threshold
                    if run.created_at < since:
                        break

                    # Skip if already cached
                    if str(run.id) in cached_build_ids:
                        continue

                    # Extract build data
                    build_data = self._extract_build_data(run, repo_name)
                    new_builds.append(build_data)

                break  # Success, exit retry loop

            except RateLimitExceededException:
                if attempt < self.rate_limit_retries - 1:
                    wait_time = self.backoff_factor ** attempt
                    print(f"   ⏳ GitHub rate limit hit, waiting {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    print("   ❌ GitHub rate limit exceeded, using cached builds only")
                    return cached_builds

        # Cache new builds
        if new_builds:
            self._cache_builds_bulk(new_builds)
            print(f"   💾 Cached {len(new_builds)} new GitHub Actions builds")

        # Track cache performance
        cache_hits = len(cached_builds)
        cache_misses = len(new_builds)
        if cache_hits > 0 or cache_misses > 0:
            hit_rate = cache_hits / (cache_hits + cache_misses) * 100
            print(f"   📊 CI/CD cache: {cache_hits} hits, {cache_misses} misses ({hit_rate:.1f}% hit rate)")

        return cached_builds + new_builds

    def _extract_build_data(self, run, repo_name: str) -> Dict[str, Any]:
        """Extract build data from workflow run."""
        # Calculate duration
        duration = 0
        if run.updated_at and run.created_at:
            duration = (run.updated_at - run.created_at).total_seconds()

        return {
            "platform": self.platform_name,
            "build_id": str(run.id),
            "pipeline_name": run.name,
            "repo_path": repo_name,
            "branch": run.head_branch,
            "commit_sha": run.head_sha,
            "status": run.conclusion or "pending",
            "started_at": run.created_at,
            "completed_at": run.updated_at,
            "duration_seconds": int(duration),
            "trigger_type": run.event,
            "author": run.head_commit.author.name if run.head_commit else None,
            "url": run.html_url,
            "platform_data": {
                "workflow_id": run.workflow_id,
                "run_number": run.run_number,
                "run_attempt": run.run_attempt,
                "workflow_name": run.name,
            }
        }

    def enrich_commits_with_builds(
        self,
        commits: List[Dict[str, Any]],
        builds: List[Dict[str, Any]]
    ) -> None:
        """Enrich commits with build status.

        Args:
            commits: List of commit dictionaries to enrich
            builds: List of build data dictionaries
        """
        # Create commit SHA to builds mapping
        commit_to_builds = {}
        for build in builds:
            sha = build.get("commit_sha")
            if sha:
                if sha not in commit_to_builds:
                    commit_to_builds[sha] = []
                commit_to_builds[sha].append(build)

        # Enrich commits
        for commit in commits:
            sha = commit.get("hash")
            if sha in commit_to_builds:
                commit_builds = commit_to_builds[sha]

                # Add build information
                commit["ci_builds"] = commit_builds
                commit["ci_build_count"] = len(commit_builds)

                # Determine overall build status
                statuses = [b["status"] for b in commit_builds]
                if "failure" in statuses:
                    commit["ci_status"] = "failure"
                elif "success" in statuses:
                    commit["ci_status"] = "success"
                else:
                    commit["ci_status"] = "pending"

    def calculate_metrics(self, builds: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate CI/CD metrics from builds.

        Args:
            builds: List of build data dictionaries

        Returns:
            Dictionary of calculated metrics
        """
        if not builds:
            return {
                "total_builds": 0,
                "successful_builds": 0,
                "failed_builds": 0,
                "success_rate": 0.0,
                "avg_duration_seconds": 0.0,
                "avg_duration_minutes": 0.0,
            }

        successful = [b for b in builds if b["status"] == "success"]
        failed = [b for b in builds if b["status"] == "failure"]
        durations = [b["duration_seconds"] for b in builds if b["duration_seconds"] > 0]

        avg_duration = sum(durations) / len(durations) if durations else 0

        return {
            "total_builds": len(builds),
            "successful_builds": len(successful),
            "failed_builds": len(failed),
            "success_rate": len(successful) / len(builds) * 100 if builds else 0,
            "avg_duration_seconds": avg_duration,
            "avg_duration_minutes": avg_duration / 60,
            "platform": self.platform_name,
        }
```

### Example 2: Database Model for CI/CD Builds

```python
"""Database models for CI/CD build caching."""

from datetime import datetime
from sqlalchemy import Column, DateTime, Integer, JSON, String, Index
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class CICDBuildCache(Base):
    """Cache table for CI/CD build data.

    This table stores build/pipeline execution data from various CI/CD platforms
    (GitHub Actions, GitLab CI, Jenkins, etc.) to minimize API calls and improve
    performance on subsequent analysis runs.

    WHY: CI/CD API calls can be slow and rate-limited. Caching build data with
    appropriate TTL allows for fast report generation while keeping data fresh.
    """

    __tablename__ = "cicd_builds"

    # Primary key
    id = Column(Integer, primary_key=True)

    # Build identification
    platform = Column(String, nullable=False, index=True)  # "github_actions", "gitlab_ci", etc.
    build_id = Column(String, nullable=False, index=True)  # Platform-specific build ID
    pipeline_name = Column(String)  # Workflow/pipeline name

    # Repository information
    repo_path = Column(String, nullable=False, index=True)  # "owner/repo"
    branch = Column(String, index=True)
    commit_sha = Column(String, index=True)

    # Build results
    status = Column(String, index=True)  # "success", "failure", "cancelled", "pending"
    started_at = Column(DateTime, nullable=False, index=True)
    completed_at = Column(DateTime)
    duration_seconds = Column(Integer)

    # Build context
    trigger_type = Column(String)  # "push", "pull_request", "schedule", "manual"
    author = Column(String)  # Who triggered the build
    url = Column(String)  # Link to build in CI/CD platform

    # Platform-specific data (stored as JSON)
    platform_data = Column(JSON)  # Additional platform-specific fields

    # Cache metadata
    cached_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    # Composite indexes for common query patterns
    __table_args__ = (
        # Most common: lookup by repo + date range
        Index('idx_cicd_repo_date', 'repo_path', 'started_at'),

        # Ensure uniqueness: platform + build_id
        Index('idx_cicd_platform_build', 'platform', 'build_id', unique=True),

        # Lookup builds for specific commit
        Index('idx_cicd_commit', 'commit_sha'),

        # Filter by status
        Index('idx_cicd_status', 'status'),

        # Filter by branch
        Index('idx_cicd_branch', 'branch'),
    )

    def __repr__(self):
        return (f"<CICDBuildCache(platform='{self.platform}', "
                f"build_id='{self.build_id}', "
                f"status='{self.status}', "
                f"repo='{self.repo_path}')>")

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for API consumption."""
        return {
            "platform": self.platform,
            "build_id": self.build_id,
            "pipeline_name": self.pipeline_name,
            "repo_path": self.repo_path,
            "branch": self.branch,
            "commit_sha": self.commit_sha,
            "status": self.status,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "duration_seconds": self.duration_seconds,
            "trigger_type": self.trigger_type,
            "author": self.author,
            "url": self.url,
            "platform_data": self.platform_data or {},
        }
```

---

## Conclusion

The gitflow-analytics codebase is well-architected for extensibility. Adding a CI/CD integration module is a natural extension that follows established patterns:

1. **Follow the GitHub/JIRA integration patterns** for cache-backed enrichment
2. **Use the orchestrator** for multi-platform coordination
3. **Leverage existing cache infrastructure** for performance
4. **Extend report generators** to include CI/CD metrics
5. **Use abstract base classes** for platform independence

The most important pattern to follow is **cache-backed enrichment with bulk operations**, which is used consistently across GitHub and JIRA integrations. This pattern ensures:
- Fast subsequent analysis runs (cache hits)
- Minimal API calls (bulk operations)
- Resilient error handling (graceful degradation)
- Incremental fetching (schema versioning)

Start with GitHub Actions integration as it's the most common and can reuse the existing GitHub token configuration. Then expand to other platforms using the same base class pattern.

---

**Generated by:** Research Agent
**Analysis Duration:** Comprehensive codebase review
**Files Analyzed:** 25+ key files across integrations, reports, models, and CLI
**Next Steps:** Begin implementation with Phase 1 (Data Models & Caching)
