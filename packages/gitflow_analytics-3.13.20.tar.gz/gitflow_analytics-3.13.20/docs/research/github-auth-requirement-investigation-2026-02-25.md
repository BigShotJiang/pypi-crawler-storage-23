# GitHub Authentication Requirement Investigation

**Date:** 2026-02-25
**Goal:** Determine if commit count analysis can run without GitHub authentication for local repository analysis.

---

## Executive Summary

GitHub authentication is **unconditionally enforced** in the `analyze` command regardless of whether the user needs GitHub API access. This is a **design oversight** (not an intentional architectural choice) — the preflight check was added for users who clone remote repos via GitHub but was never made conditional for local-only analysis.

The critical finding is: **commit counting uses only local git operations** — it does not require the GitHub API at all. GitHub integration is only needed for optional enrichment (PR data, issue ticket metadata, CI/CD metrics). The auth gate is blocking purely local workflows unnecessarily.

---

## Investigation Findings

### 1. Where the GitHub Authentication Check Occurs

**File:** `src/gitflow_analytics/cli.py`, lines ~773-794

```python
# Run pre-flight git authentication check
config_dict = {
    "github": {
        "token": cfg.github.token if cfg.github else None,
        "organization": cfg.github.organization if cfg.github else None,
    }
}
click.echo("Verifying GitHub authentication...")

if not preflight_git_authentication(config_dict):
    click.echo("GitHub authentication failed. Cannot proceed with analysis.")
    sys.exit(1)
```

This block runs **unconditionally** — there is no guard checking whether GitHub is actually needed (i.e., whether any repos have `github_repo` set, or whether GitHub-dependent features are enabled).

**File:** `src/gitflow_analytics/core/git_auth.py`, `preflight_git_authentication()` (line 236)

The function logic:
1. If no token → logs error + prints instructions → returns `False`
2. If token present → calls `verify_github_token()` which makes a live GitHub API call
3. If token invalid → returns `False`
4. If token valid → calls `setup_git_credentials()` → returns `True`

**Key behavior:** When `token` is `None` or empty string, the function immediately returns `False` with an error. There is no bypass path.

### 2. Is GitHub Integration Actually Needed for Commit Count Analysis?

**No.** The commit counting pipeline is entirely local:

- **`src/gitflow_analytics/core/analyzer.py`** — `analyze_repository()`, `_get_commits_optimized()`, `_get_all_branch_commits()`, `_get_main_branch_commits()`, `_get_smart_branch_commits()`: all use `gitpython`'s `repo.iter_commits()` — pure local git operations with no GitHub API calls.
- **`src/gitflow_analytics/core/data_fetcher.py`** — only references `JIRAIntegration`, not `GitHubIntegration`. Commit data fetching is local.
- **`src/gitflow_analytics/integrations/orchestrator.py`** — `GitHubIntegration` is only initialized `if config.github and config.github.token`. If no token, GitHub integration is simply skipped.

GitHub integration provides **optional enrichment only:**
- PR/MR data (requires `github_repo` field per repo + valid token)
- CI/CD metrics via GitHub Actions API (requires `--cicd-metrics` flag + token)
- Issue ticket metadata for commits referencing GitHub issues
- Organization-level repo discovery (requires `organization` config)

### 3. Design Choice or Bug/Oversight?

**This is a design oversight.** Evidence:

1. `src/gitflow_analytics/config/validator.py` (line 31-33) correctly treats GitHub as optional:
   ```python
   has_github_repos = any(r.github_repo for r in config.repositories)
   if has_github_repos and not config.github.token:
       warnings.append("GitHub repositories specified but no GitHub token provided")
   ```
   The validator correctly makes GitHub a warning, not a hard error, when `github_repo` fields are used. But the CLI does not follow the same logic.

2. `src/gitflow_analytics/integrations/orchestrator.py` (line 28-35) conditionally initializes GitHub integration:
   ```python
   if config.github and config.github.token:
       self.integrations["github"] = GitHubIntegration(...)
   ```
   This shows GitHub was designed to be optional at the integration layer.

3. `configs/ewtn-test-config.yaml` has commented-out GitHub section with the note: "Local repository analysis (no GitHub API required for basic testing)" — confirming the intent was always to support local-only use.

4. The `test-commit-count-config.yaml` uses `github: token: "dummy"` — indicating users have had to use dummy tokens to bypass the check.

5. No `--skip-github-auth` or `--local-only` flag exists, which would be expected if this was an intentional hard requirement.

### 4. Configuration Options to Disable GitHub

Currently, **there are no working options** to skip the GitHub auth check. However:

**What should work architecturally (but is blocked by the preflight check):**

Option A — Omit `github` section entirely:
```yaml
repositories:
  - name: "my-repo"
    path: "/path/to/repo"
    # No github_repo field

# No github: section at all
```

Option B — Provide a dummy token (workaround, not recommended):
```yaml
github:
  token: "dummy"  # Will fail token verification step
```

**Why neither works today:**
- Option A: `preflight_git_authentication` still runs and fails because `token` is `None`
- Option B: `verify_github_token("dummy")` will call the GitHub API with an invalid token and return `BadCredentialsException`, causing failure

### 5. Examples of Configs That Would Work Without GitHub

None of the existing example configs work without GitHub. The `test-commit-count-config.yaml` explicitly omits `github:` but still triggers the auth failure.

The `configs/ewtn-test-config.yaml` has the comment "# github: # Will be used if token is available, otherwise local-only analysis" suggesting local-only was planned but never implemented.

---

## Impact on Commit Count Accuracy Investigation

The GitHub auth requirement is a **separate issue** from commit count accuracy. Even with a valid token, the commit counting could still be low if:

1. Branch analysis strategy is not capturing all branches (`smart` vs `all`)
2. The `since` date range excludes commits (--weeks setting)
3. Merge commit deduplication logic has bugs
4. The `branch_commit_limit` (default: 1000) truncates commits per branch

The auth gate blocks us from running controlled tests of commit counting without GitHub side effects. Removing this gate would allow clean local testing.

---

## Recommended Fix

The `preflight_git_authentication` call in `cli.py` should be made conditional:

```python
# Only run GitHub auth if GitHub integration is actually needed
has_github_repos = any(r.github_repo for r in cfg.repositories)
needs_github_auth = (
    has_github_repos
    or bool(cfg.github and cfg.github.organization)
    or cicd_metrics  # CI/CD metrics require GitHub API
)

if needs_github_auth:
    if not preflight_git_authentication(config_dict):
        click.echo("GitHub authentication failed. Cannot proceed with analysis.")
        sys.exit(1)
else:
    click.echo("Local-only analysis mode (no GitHub authentication required)")
```

This aligns with how the rest of the system already treats GitHub as optional:
- `IntegrationOrchestrator` skips GitHub if no token
- `ConfigValidator` only warns about missing token when `github_repo` is set
- The ewtn config comments indicate local-only was intended

---

## Minimal Local-Only Config That Should Work After Fix

```yaml
version: "1.0"

repositories:
  - name: "my-repo"
    path: "/path/to/local/repo"
    project_key: "PROJ"
    # No github_repo field — local only

analysis:
  branch_analysis:
    strategy: "all"  # Use "all" to ensure complete commit coverage

output:
  directory: "./reports"
  formats: ["csv", "markdown"]

cache:
  directory: "./.gitflow-cache"
```

No `github:` section needed. No token required. All commit counting operations are purely local.

---

## Files Examined

| File | Role |
|------|------|
| `src/gitflow_analytics/cli.py` | Contains the unconditional `preflight_git_authentication` call (lines 773-794) |
| `src/gitflow_analytics/core/git_auth.py` | `preflight_git_authentication()` — hard fails if no token |
| `src/gitflow_analytics/core/analyzer.py` | Commit analysis — entirely local, no GitHub API |
| `src/gitflow_analytics/core/data_fetcher.py` | Data fetching — uses JIRA only, not GitHub |
| `src/gitflow_analytics/integrations/orchestrator.py` | GitHub is conditional (`if config.github and token`) |
| `src/gitflow_analytics/config/validator.py` | Correctly treats GitHub as optional warning |
| `src/gitflow_analytics/config/schema.py` | `GitHubConfig.token` is `Optional[str] = None` |
| `test-commit-count-config.yaml` | Uses no `github_repo`, omits `github:` — currently blocked |
| `configs/ewtn-test-config.yaml` | Commented-out GitHub section, intended local-only use |

---

## Classification: Actionable

This research identifies a clear bug/oversight that requires a code fix in `cli.py` to make GitHub auth conditional.
