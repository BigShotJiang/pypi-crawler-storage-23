"""Developer identity resolution with persistence."""

import difflib
import logging
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from sqlalchemy import and_

from ..models.database import Database, DeveloperAlias, DeveloperIdentity
from .identity_stats import IdentityStatsMixin

logger = logging.getLogger(__name__)


class DeveloperIdentityResolver(IdentityStatsMixin):
    """Resolve and normalize developer identities across repositories."""

    def __init__(
        self,
        db_path: str,
        similarity_threshold: float = 0.85,
        manual_mappings: Optional[list[dict[str, Any]]] = None,
        strip_suffixes: Optional[list[str]] = None,
    ) -> None:
        """
        Initialize with database for persistence.

        WHY: This initializer handles database connection issues gracefully,
        allowing the system to continue functioning even when persistence fails.

        Args:
            db_path: Path to the SQLite database file
            similarity_threshold: Threshold for fuzzy matching (0.0-1.0)
            manual_mappings: Optional manual identity mappings from configuration
            strip_suffixes: Optional list of suffixes to strip from email local-parts
                before fuzzy matching.  Mirrors the ``analysis.identity.strip_suffixes``
                config key so the same normalisation applied by ``LLMIdentityAnalyzer``
                is also used during report-time identity resolution.
        """
        self.similarity_threshold = similarity_threshold
        self.db_path = Path(db_path)  # Convert string to Path
        self._strip_suffixes: list[str] = list(strip_suffixes) if strip_suffixes else []
        self._cache: dict[str, str] = {}  # In-memory cache for performance

        # Initialize database with error handling
        try:
            self.db = Database(self.db_path)
            self._database_available = True

            # Warn user if using fallback database
            if self.db.is_readonly_fallback:
                logger.warning(
                    "Using temporary database for identity resolution. "
                    "Identity mappings will not persist between runs. "
                    f"Check permissions on: {db_path}"
                )

            # Load existing data from database
            self._load_cache()

        except Exception as e:
            logger.error(
                f"Failed to initialize identity database at {db_path}: {e}. "
                "Identity resolution will work but mappings won't persist."
            )
            self._database_available = False
            self.db = None

        # Store manual mappings to apply later
        self.manual_mappings = manual_mappings

        # When database is not available, we need in-memory fallback storage
        if not self._database_available:
            logger.info(
                "Database unavailable, using in-memory identity resolution. "
                "Identity mappings will not persist between runs."
            )
            self._in_memory_identities: dict[str, dict[str, Any]] = {}
            self._in_memory_aliases: dict[str, str] = {}

            # Apply manual mappings to in-memory storage if provided
            if self.manual_mappings:
                self._apply_manual_mappings_to_memory()
        else:
            # Apply manual mappings to database if provided
            if self.manual_mappings:
                self._apply_manual_mappings(self.manual_mappings)

    @contextmanager
    def get_session(self):
        """
        Get database session context manager with fallback handling.

        WHY: When database is not available, we need to provide a no-op
        context manager that allows the code to continue without failing.
        """
        if not self._database_available or not self.db:
            # No-op context manager when database is not available
            class NoOpSession:
                def query(self, *args, **kwargs):
                    return NoOpQuery()

                def add(self, *args, **kwargs):
                    pass

                def delete(self, *args, **kwargs):
                    pass

                def commit(self):
                    pass

                def rollback(self):
                    pass

                def expire_all(self):
                    pass

            class NoOpQuery:
                def filter(self, *args, **kwargs):
                    return self

                def first(self):
                    return None

                def all(self):
                    return []

                def count(self):
                    return 0

            yield NoOpSession()
            return

        session = self.db.get_session()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def _load_cache(self) -> None:
        """
        Load identities into memory cache.

        WHY: When database is not available, we start with an empty cache
        and rely on in-memory identity resolution for the current session.
        """
        if not self._database_available:
            logger.debug("Database not available, starting with empty identity cache")
            return

        with self.get_session() as session:
            # Load all identities
            identities = session.query(DeveloperIdentity).all()
            for identity in identities:
                self._cache[identity.canonical_id] = {
                    "primary_name": identity.primary_name,
                    "primary_email": identity.primary_email,
                    "github_username": identity.github_username,
                }

            # Load all aliases
            aliases = session.query(DeveloperAlias).all()
            for alias in aliases:
                key = f"{alias.email.lower()}:{alias.name.lower()}"
                self._cache[key] = alias.canonical_id

    def _apply_manual_mappings(self, manual_mappings: list[dict[str, Any]]) -> None:
        """Apply manual identity mappings from configuration."""
        logger.info(f"Applying {len(manual_mappings)} manual identity mappings")

        # Handle database unavailable scenario
        if not self._database_available:
            self._apply_manual_mappings_to_memory()
            return

        # Clear cache to ensure we get fresh data
        self._cache.clear()
        self._load_cache()

        with self.get_session() as session:
            for mapping in manual_mappings:
                # Support both canonical_email and primary_email for backward compatibility
                canonical_email = (
                    (mapping.get("primary_email", "") or mapping.get("canonical_email", ""))
                    .lower()
                    .strip()
                )
                aliases = mapping.get("aliases", [])
                preferred_name = mapping.get("name")  # Optional display name

                if not canonical_email or not aliases:
                    logger.warning(f"Skipping invalid manual mapping: {mapping}")
                    continue

                logger.info(
                    f"Processing manual mapping: {preferred_name} → {canonical_email} with {len(aliases)} aliases"
                )

                # Find or create the canonical identity
                canonical_identity = (
                    session.query(DeveloperIdentity)
                    .filter(DeveloperIdentity.primary_email == canonical_email)
                    .first()
                )

                if not canonical_identity:
                    # Create the canonical identity if it doesn't exist
                    canonical_id = str(uuid.uuid4())
                    canonical_identity = DeveloperIdentity(
                        canonical_id=canonical_id,
                        primary_name=preferred_name or canonical_email.split("@")[0],
                        primary_email=canonical_email,
                        first_seen=datetime.now(timezone.utc),
                        last_seen=datetime.now(timezone.utc),
                        total_commits=0,
                        total_story_points=0,
                    )
                    session.add(canonical_identity)
                    session.commit()
                    print(
                        f"Created canonical identity: {canonical_identity.primary_name} ({canonical_email})"
                    )

                # Update the preferred name if provided
                if preferred_name and preferred_name != canonical_identity.primary_name:
                    print(
                        f"Updating display name: {canonical_identity.primary_name} → {preferred_name}"
                    )
                    canonical_identity.primary_name = preferred_name

                # Process each alias
                for alias_email in aliases:
                    alias_email = alias_email.lower().strip()

                    # Check if alias identity exists as a primary identity
                    alias_identity = (
                        session.query(DeveloperIdentity)
                        .filter(DeveloperIdentity.primary_email == alias_email)
                        .first()
                    )

                    if alias_identity:
                        if alias_identity.canonical_id != canonical_identity.canonical_id:
                            # Merge the identities - commit before merge to avoid locks
                            session.commit()
                            print(
                                f"Merging identity: {alias_identity.primary_name} ({alias_email}) into {canonical_identity.primary_name} ({canonical_email})"
                            )
                            self.merge_identities(
                                canonical_identity.canonical_id, alias_identity.canonical_id
                            )
                            # Refresh session after merge
                            session.expire_all()
                    else:
                        # Just add as an alias if not a primary identity
                        existing_alias = (
                            session.query(DeveloperAlias)
                            .filter(
                                and_(
                                    DeveloperAlias.email == alias_email,
                                    DeveloperAlias.canonical_id == canonical_identity.canonical_id,
                                )
                            )
                            .first()
                        )

                        if not existing_alias:
                            # Get the name from any existing alias with this email
                            name_for_alias = None
                            any_alias = (
                                session.query(DeveloperAlias)
                                .filter(DeveloperAlias.email == alias_email)
                                .first()
                            )
                            if any_alias:
                                name_for_alias = any_alias.name
                            else:
                                name_for_alias = canonical_identity.primary_name

                            new_alias = DeveloperAlias(
                                canonical_id=canonical_identity.canonical_id,
                                name=name_for_alias,
                                email=alias_email,
                            )
                            session.add(new_alias)
                            print(
                                f"Added alias: {alias_email} for {canonical_identity.primary_name}"
                            )

        # Reload cache after all mappings
        self._cache.clear()
        self._load_cache()

    def resolve_by_github_username(self, github_username: str) -> Optional[str]:
        """
        Look up a canonical ID by GitHub username.

        WHY: PR reviewers/approvers are stored as GitHub logins (e.g. "octocat")
        but the identity system uses email/name keys.  This bridge method lets PR
        review activity be attributed to the correct developer identity so per-
        developer reviewed/approved counts are accurate.

        GitHub logins are case-insensitive, so the lookup normalises to lowercase.

        Args:
            github_username: GitHub login to look up (case-insensitive).

        Returns:
            Canonical ID if the username is linked to a known identity, else None.
        """
        if not github_username:
            return None

        username_lower = github_username.lower().strip()

        if not self._database_available:
            # Search in-memory identities
            for canonical_id, identity in self._in_memory_identities.items():
                stored = identity.get("github_username")
                if stored and stored.lower() == username_lower:
                    return canonical_id
            return None

        with self.get_session() as session:
            identity = (
                session.query(DeveloperIdentity)
                .filter(DeveloperIdentity.github_username == username_lower)
                .first()
            )
            if identity:
                return identity.canonical_id

        return None

    def resolve_developer(
        self, name: str, email: str, github_username: Optional[str] = None
    ) -> str:
        """
        Resolve developer identity and return canonical ID.

        WHY: This method handles both database-backed and in-memory identity resolution,
        allowing the system to function even when persistence is not available.
        """
        # Use fallback resolution when database is not available
        if not self._database_available:
            return self._fallback_identity_resolution(name, email)

        # Normalize inputs
        name = name.strip()
        email = email.lower().strip()
        # Gap 5: Normalize GitHub login casing — GitHub usernames are case-insensitive
        if github_username:
            github_username = github_username.lower().strip()

        # Check cache first
        cache_key = f"{email}:{name.lower()}"
        if cache_key in self._cache:
            canonical_id = self._cache[cache_key]
            # Update stats
            self._update_developer_stats(canonical_id)
            logger.debug(f"Resolved {name} <{email}> from cache to {canonical_id}")
            return canonical_id

        # Fix 2: Detect GitHub noreply emails and resolve via username.
        # Pattern: {numeric_id}+{username}@users.noreply.github.com
        # Extract the username portion and try to match it against existing aliases.
        if email.endswith("@users.noreply.github.com") and "+" in email:
            local_part = email.split("@")[0]
            github_username = local_part.split("+", 1)[1]  # part after the numeric ID
            # Look for an existing alias or identity with this username as email/alias
            with self.get_session() as session:
                # Search aliases where email equals the plain username (common pattern
                # when users commit directly via the GitHub web UI or CLI with their
                # username set as "email").
                username_alias = (
                    session.query(DeveloperAlias)
                    .filter(DeveloperAlias.email == github_username.lower())
                    .first()
                )
                if username_alias:
                    # Register the noreply address under the same identity so future
                    # lookups hit the cache without another DB round-trip.
                    self._add_alias(username_alias.canonical_id, name, email)
                    self._cache[cache_key] = username_alias.canonical_id
                    logger.debug(
                        f"Matched GitHub noreply email {email!r} to username "
                        f"{github_username!r} → canonical_id={username_alias.canonical_id}"
                    )
                    return username_alias.canonical_id

                # Also check if the username itself is a primary identity email
                username_identity = (
                    session.query(DeveloperIdentity)
                    .filter(DeveloperIdentity.primary_email == github_username.lower())
                    .first()
                )
                if username_identity:
                    self._add_alias(username_identity.canonical_id, name, email)
                    self._cache[cache_key] = username_identity.canonical_id
                    logger.debug(
                        f"Matched GitHub noreply email {email!r} to primary identity "
                        f"{github_username!r} → canonical_id={username_identity.canonical_id}"
                    )
                    return username_identity.canonical_id

        # Check exact email match in database
        with self.get_session() as session:
            # Check aliases
            alias = session.query(DeveloperAlias).filter(DeveloperAlias.email == email).first()

            if alias:
                # Found an alias with this email - add this name variant to cache and DB
                self._cache[cache_key] = alias.canonical_id
                self._update_developer_stats(alias.canonical_id)
                logger.debug(f"Found alias for {email}, resolving {name} to {alias.canonical_id}")
                # Add this name variant as an alias if it's different
                if alias.name.lower() != name.lower():
                    logger.debug(f"Adding name variant '{name}' as alias for {email}")
                    self._add_alias(alias.canonical_id, name, email)
                return alias.canonical_id

            # Check primary identities
            identity = (
                session.query(DeveloperIdentity)
                .filter(DeveloperIdentity.primary_email == email)
                .first()
            )

            if identity:
                # Add as alias if name is different
                if identity.primary_name.lower() != name.lower():
                    self._add_alias(identity.canonical_id, name, email)
                self._cache[cache_key] = identity.canonical_id
                return identity.canonical_id

        # Find similar developer
        best_match = self._find_best_match(name, email)

        if best_match and best_match[1] >= self.similarity_threshold:
            canonical_id = best_match[0]
            self._add_alias(canonical_id, name, email)
            self._cache[cache_key] = canonical_id
            return canonical_id

        # Create new identity
        logger.info(f"Creating new identity for {name} <{email}> - no matches found")
        canonical_id = self._create_identity(name, email, github_username)
        self._cache[cache_key] = canonical_id
        return canonical_id

    def _normalize_email_local(self, local_part: str) -> str:
        """Strip configured suffixes from an email local-part for fuzzy comparison.

        WHY: Developers sometimes use suffixed email variants (e.g. ``john-dev``
        vs ``john``) in different environments.  Stripping the known suffixes
        before comparing increases the chance that the fuzzy matcher treats them
        as the same person, mirroring the behaviour of ``LLMIdentityAnalyzer``.

        Args:
            local_part: The portion of an email address before the ``@``.

        Returns:
            The local-part with all configured suffixes removed.
        """
        result = local_part
        for suffix in self._strip_suffixes:
            result = result.replace(suffix, "")
        return result

    def _find_best_match(self, name: str, email: str) -> Optional[tuple[str, float]]:
        """Find the best matching existing developer."""
        best_score = 0.0
        best_canonical_id = None

        name_lower = name.lower().strip()
        email_local = email.split("@")[0] if "@" in email else email
        email_domain = email.split("@")[1] if "@" in email else ""
        # Normalised local-part for suffix-stripped comparison
        norm_local = self._normalize_email_local(email_local)

        with self.get_session() as session:
            # Get all identities for comparison
            identities = session.query(DeveloperIdentity).all()

            for identity in identities:
                score = 0.0

                # Name similarity (40% weight)
                name_sim = difflib.SequenceMatcher(
                    None, name_lower, identity.primary_name.lower()
                ).ratio()
                score += name_sim * 0.4

                # Email domain similarity (30% weight)
                identity_domain = (
                    identity.primary_email.split("@")[1] if "@" in identity.primary_email else ""
                )
                if email_domain and email_domain == identity_domain:
                    score += 0.3
                    # Additional bonus when the suffix-stripped local-parts match,
                    # e.g. john-dev@co.com vs john@co.com both normalise to "john".
                    if self._strip_suffixes:
                        identity_local = (
                            identity.primary_email.split("@")[0]
                            if "@" in identity.primary_email
                            else identity.primary_email
                        )
                        norm_identity_local = self._normalize_email_local(identity_local)
                        if norm_local and norm_local == norm_identity_local:
                            score += 0.1

                # Check aliases (30% weight)
                aliases = (
                    session.query(DeveloperAlias)
                    .filter(DeveloperAlias.canonical_id == identity.canonical_id)
                    .all()
                )

                best_alias_score = 0.0
                for alias in aliases:
                    alias_name_sim = difflib.SequenceMatcher(
                        None, name_lower, alias.name.lower()
                    ).ratio()

                    # Bonus for same email domain in aliases
                    alias_domain = alias.email.split("@")[1] if "@" in alias.email else ""
                    domain_bonus = 0.2 if alias_domain == email_domain else 0.0

                    # Suffix-stripped local-part bonus for aliases
                    if self._strip_suffixes and alias_domain == email_domain:
                        alias_local = (
                            alias.email.split("@")[0] if "@" in alias.email else alias.email
                        )
                        norm_alias_local = self._normalize_email_local(alias_local)
                        if norm_local and norm_local == norm_alias_local:
                            domain_bonus += 0.1

                    alias_score = alias_name_sim + domain_bonus
                    best_alias_score = max(best_alias_score, alias_score)

                score += min(best_alias_score * 0.3, 0.3)

                if score > best_score:
                    best_score = score
                    best_canonical_id = identity.canonical_id

        return (best_canonical_id, best_score) if best_canonical_id else None

    def _create_identity(self, name: str, email: str, github_username: Optional[str] = None) -> str:
        """Create new developer identity."""
        canonical_id = str(uuid.uuid4())

        with self.get_session() as session:
            identity = DeveloperIdentity(
                canonical_id=canonical_id,
                primary_name=name,
                primary_email=email,
                github_username=github_username,
                total_commits=0,
                total_story_points=0,
            )
            session.add(identity)

        # Update cache
        self._cache[canonical_id] = {
            "primary_name": name,
            "primary_email": email,
            "github_username": github_username,
        }

        return canonical_id

    def _add_alias(self, canonical_id: str, name: str, email: str):
        """Add alias for existing developer."""
        with self.get_session() as session:
            # Check if alias already exists
            existing = (
                session.query(DeveloperAlias)
                .filter(
                    and_(
                        DeveloperAlias.canonical_id == canonical_id,
                        DeveloperAlias.email == email.lower(),
                    )
                )
                .first()
            )

            if not existing:
                alias = DeveloperAlias(canonical_id=canonical_id, name=name, email=email.lower())
                session.add(alias)
                # Update cache with the new alias
                cache_key = f"{email.lower()}:{name.lower()}"
                self._cache[cache_key] = canonical_id

    def _update_developer_stats(self, canonical_id: str):
        """Update developer statistics."""
        with self.get_session() as session:
            identity = (
                session.query(DeveloperIdentity)
                .filter(DeveloperIdentity.canonical_id == canonical_id)
                .first()
            )

            if identity:
                identity.last_seen = datetime.utcnow()

    def merge_identities(self, canonical_id1: str, canonical_id2: str):
        """Merge two developer identities."""
        # First, add the alias outside of the main merge transaction
        with self.get_session() as session:
            identity2 = (
                session.query(DeveloperIdentity)
                .filter(DeveloperIdentity.canonical_id == canonical_id2)
                .first()
            )
            if identity2:
                identity2_name = identity2.primary_name
                identity2_email = identity2.primary_email

        # Add identity2's primary as alias to identity1 first
        self._add_alias(canonical_id1, identity2_name, identity2_email)

        # Now do the merge in a separate transaction
        with self.get_session() as session:
            # Get both identities fresh
            identity1 = (
                session.query(DeveloperIdentity)
                .filter(DeveloperIdentity.canonical_id == canonical_id1)
                .first()
            )
            identity2 = (
                session.query(DeveloperIdentity)
                .filter(DeveloperIdentity.canonical_id == canonical_id2)
                .first()
            )

            if not identity1 or not identity2:
                raise ValueError("One or both identities not found")

            # Keep identity1, merge identity2 into it
            identity1.total_commits += identity2.total_commits
            identity1.total_story_points += identity2.total_story_points
            identity1.first_seen = min(identity1.first_seen, identity2.first_seen)
            identity1.last_seen = max(identity1.last_seen, identity2.last_seen)

            # Move all aliases from identity2 to identity1
            aliases = (
                session.query(DeveloperAlias)
                .filter(DeveloperAlias.canonical_id == canonical_id2)
                .all()
            )

            for alias in aliases:
                alias.canonical_id = canonical_id1

            # Delete identity2
            session.delete(identity2)

        # Clear cache to force reload
        self._cache.clear()
        self._load_cache()
