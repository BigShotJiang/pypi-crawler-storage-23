"""Training module for commit classification."""

from .pipeline import CommitClassificationTrainer

__all__ = ["CommitClassificationTrainer"]
