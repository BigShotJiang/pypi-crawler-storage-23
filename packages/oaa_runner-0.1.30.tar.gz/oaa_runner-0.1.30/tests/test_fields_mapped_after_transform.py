# I want to test that all attributes are mapped after transforms and not just
# at the time they are used to send to OAA.
import os
import pytest
from pathlib import Path
from oaa.app_runners.custom_app import CustomAppRunner

BASE_DIR = Path(os.path.dirname(os.path.realpath(__file__)))


@pytest.fixture
def _config(config):
    config.update(config_file=BASE_DIR / 'config-basic-custom-fields.yaml')

    return config


def test_fields_mapped(_config):
    runner = CustomAppRunner()

    source = _config.sources['users']

    runner._run_transform(source)

    assert 'name' in source.stream.header()
    assert 'email2' in source.stream.header()
    assert 'first_name' in source.stream.header()
    assert 'last_name' in source.stream.header()

    for r in source.stream.dicts(): # records:
        # these fields should have a value at this point.
        assert r['name']
        assert r['email2']
        assert r['last_name']
        assert r['first_name']
