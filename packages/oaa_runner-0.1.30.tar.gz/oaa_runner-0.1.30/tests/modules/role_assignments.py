

def run(provider, sources=None, config=None):
    # import bpdb; bpdb.set_trace()  # noqa: E702

    # get the roles source
    roles_source = sources['roles']
    roles_stream = roles_source.records

    for role in roles_stream:
        # role.username is the user this should be attached to
        user = provider.local_users[role.username]
        user.add_role(role.role_id, apply_to_application=True)
        # user.add_local

    return True
