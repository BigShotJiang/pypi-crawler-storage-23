from oaa.hooks.decorators import OAAHookEvent, hook


@hook(event=OAAHookEvent.LCM_CREATE_USER, keep_results=True)
def hook_create_user(event, user=None, action=None, **kwargs):

    '''
    hook_name is a hook for doing some custom thing at this point in the flow.
    '''
    print('--------- running')

    return user['username'] 
