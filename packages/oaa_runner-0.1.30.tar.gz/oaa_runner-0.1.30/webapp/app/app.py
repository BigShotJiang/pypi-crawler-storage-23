import os
import logging
from flask import Flask
from flask import request
from mk_users import logger
import custom_scim_obj
from lcm_base import LCM_APPS, EnumLCMAction
from scim_base import (
        SCIM_APPS,
        scim_function,
        EnumSCIMAction,
        # scim_schema
)

app = Flask(__name__)

'''
Ideas:
    - CSV -> SCIM converter
    - API -> SCIM converter
    - DB -> SCIM converter
    - Use a completely different API schema than SCIM because it is limited.
'''


@app.route('/veza/lcm/v2/<string:app_name>/writeback', methods=['POST'])
def veza_writeback(app_name):
    '''

    '''
    # import bpdb; bpdb.set_trace()  # noqa: E702
    actions = LCM_APPS.get_app_actions(app_name, EnumLCMAction.WRITEBACK)
    # actions = LCM_APPS.apps.get(app_name, {}).get('writeback', [])
    app.logger.info('actions %s', actions)

    results = []

    for action in actions:
        print('action', action.action.__name__)
        results.append(action.action(request.json))

    # app.logger.info('results %s', results)

    return results


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=os.getenv('FLASK_PORT', 8080))
