import petl
# from oaa.hooks.decorators import hook, OAAHookEvent

def fetch(connection=None, source=None, **kwargs):
    '''
    Fetch the data. This is the function that is called by oaa.

    '''
    delimiter = ','
    # get the delimiter from the source

    if source.params:
        delimiter = source.params.get('delimiter', delimiter)

    return petl.fromcsv(source.csv_filepath, delimiter=delimiter)
