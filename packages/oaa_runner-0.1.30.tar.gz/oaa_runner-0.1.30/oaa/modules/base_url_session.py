import requests
from urllib.parse import urljoin


class BaseURLSession(requests.Session):
    '''
    A base requests.Session sub-classed object that allows to set a base url
    for all subsequent requests.
    '''

    def __init__(self, base_url=None):
        super().__init__()
        self.base_url = base_url

    def request(self, method, url, *args, **kwargs):
        joined_url = urljoin(self.base_url, url)

        return super().request(method, joined_url, *args, **kwargs)
