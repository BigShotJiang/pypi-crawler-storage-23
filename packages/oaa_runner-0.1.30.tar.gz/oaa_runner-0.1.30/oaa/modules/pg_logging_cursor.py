import os
import logging
import psycopg
logger = logging.getLogger(__name__)


class LoggingPGCursor(psycopg.cursor.Cursor):
    def execute(self, *args, **kwargs):
        logger.debug(*args, **kwargs)
        super().execute(*args, **kwargs)
