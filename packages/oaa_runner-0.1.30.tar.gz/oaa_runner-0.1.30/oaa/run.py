#!/usr/bin/env python
# -*- coding: utf-8 -*-

import fire
import logging

# from pathlib import Path

# utils.py contains field transform functions
# oaa_utils.py contains functions specifically related to oaa
# cli_runner.py is the CLI logic
# from . import cli_runner
# from oaa.app_runners.hris_single_source import HRISRunner
# from oaa.app_runners.idp_runner import IdPRunner
from oaa.app_runners.custom_app import CustomAppRunner
from . import oaa_utils

logger = logging.getLogger(__name__)

# Set the Provider Type to link HRIS employees to. This should be the type of
# the primary IdP for the environment
# Current Options include:
# ACTIVE_DIRECTORY
# ANY
# AZURE_AD
# CUSTOM
# GOOGLE_WORKSPACE
# OKTA
# ONE_LOGIN


# try:
#     IDP_PROVIDER_TYPE = getattr(IdPProviderType, IDP_PROVIDER_TYPE.upper())
# except AttributeError as err:

#     logger.error('Invalid IdPProviderType type %s:  '
#                  'Must be one of %s',
#                  IDP_PROVIDER_TYPE,
#                  oaa_utils.idp_provider_types())
#     logger.error(err)
#     exit(1)

# Provide a path to an icon.  Icon should either be SVG or PNG and less than
# 64KB
# NOTE This is not implemented in this script yet.
# HRIS_ICON_B64_PATH = ""

# GROUP_TYPE = os.getenv('GROUP_TYPE', 'Department')

# what is the unique identifier field?
# HRIS_UNIQUE_ID_FIELD = os.environ['HRIS_UNIQUE_ID_FIELD']  # , 'EMP_NO')

def main(cli_args=None):
    """TODO: Docstring for main.
    :returns: TODO

    """
    payload = {
            # 'hris': HRISRunner,
            # 'idp': IdPRunner,
            'custom_app': CustomAppRunner,
            'oaa_utils': oaa_utils.FUNCS,
        }

    if cli_args:
        fire.Fire(payload, cli_args)
    else:
        fire.Fire(payload)


if __name__ == "__main__":
    main()
