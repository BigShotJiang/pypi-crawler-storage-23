"""Iceberg Table Metadata Explorer CLI."""

__version__ = "0.1.1"
