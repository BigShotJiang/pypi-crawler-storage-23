# regfans/__init__.py
from .vectorconfig import VectorConfiguration

__all__ = ["VectorConfiguration"]
