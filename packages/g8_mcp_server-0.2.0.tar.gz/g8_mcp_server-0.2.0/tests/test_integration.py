"""Integration test — verify server starts and lists all tools."""

from __future__ import annotations

import pytest

from g8_mcp_server.client import G8ClientError
from g8_mcp_server.server import create_server


def _tool_names(server):
    return sorted(server._tool_manager._tools.keys())


class TestServerIntegration:
    def test_server_creates_successfully(self, monkeypatch):
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        server = create_server()
        assert server.name == "graph8"

    def test_tool_count(self, monkeypatch):
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        server = create_server()
        names = _tool_names(server)
        assert len(names) == 16, f"Expected 16 tools, got {len(names)}: {names}"

    def test_tool_names(self, monkeypatch):
        monkeypatch.setenv("G8_API_KEY", "test_key")
        monkeypatch.setenv("G8_API_URL", "https://test.graph8.com")
        server = create_server()
        tool_names = _tool_names(server)
        expected = sorted([
            "g8_add_to_sequence",
            "g8_apply_install",
            "g8_connect_repo",
            "g8_doctor",
            "g8_get_campaign",
            "g8_get_scan_results",
            "g8_install_spine",
            "g8_launch_campaign",
            "g8_list_campaigns",
            "g8_lookup_company",
            "g8_lookup_person",
            "g8_scan_repo",
            "g8_search_contacts",
            "g8_search_companies",
            "g8_search_kb",
            "g8_status",
        ])
        assert tool_names == expected

    def test_fails_without_api_key(self, monkeypatch):
        monkeypatch.delenv("G8_API_KEY", raising=False)
        with pytest.raises(G8ClientError, match="G8_API_KEY"):
            create_server()
