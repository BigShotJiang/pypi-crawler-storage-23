"""Entry point for `uvx g8-mcp-server` or `python -m g8_mcp_server`."""

from g8_mcp_server.server import main

if __name__ == "__main__":
    main()
