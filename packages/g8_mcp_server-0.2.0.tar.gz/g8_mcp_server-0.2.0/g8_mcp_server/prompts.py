"""Pre-built prompt templates for common GTM workflows."""

from __future__ import annotations

from mcp.server import FastMCP
from mcp.types import PromptMessage, TextContent


def register(server: FastMCP) -> None:
    """Register prompt templates on the MCP server."""

    @server.prompt()
    async def gtm_setup(repo_url: str) -> list[PromptMessage]:
        """Full GTM setup workflow — connect a repo, scan, install, and launch campaigns.

        Args:
            repo_url: GitHub/GitLab repository URL to set up
        """
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text=f"""Set up graph8 GTM automation for this repository: {repo_url}

Follow these steps in order:
1. Connect the repository using g8_connect_repo
2. Scan it with g8_scan_repo to detect the tech stack
3. Review scan results with g8_get_scan_results
4. Generate install patches with g8_install_spine
5. Review the patches and ask me to confirm before applying with g8_apply_install
6. List generated campaigns with g8_list_campaigns
7. Show me campaign details and ask which to launch

Always ask for my confirmation before destructive operations (applying patches, launching campaigns).""",
                ),
            )
        ]

    @server.prompt()
    async def campaign_review(campaign_id: str) -> list[PromptMessage]:
        """Review and improve a generated campaign.

        Args:
            campaign_id: Campaign ID to review
        """
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text=f"""Review the campaign with ID {campaign_id}.

Use g8_get_campaign to load the full campaign details, then:
1. Evaluate the target persona fit — does it match a real buyer?
2. Review the core concept and primary hook — are they compelling?
3. Check the channel strategy — are the channels appropriate for the audience?
4. Look at the sequence copy — is it specific enough, or too generic?
5. Suggest 3 concrete improvements with rationale.

Use g8_search_kb to pull relevant ICP profiles and buyer personas for context.""",
                ),
            )
        ]

    @server.prompt()
    async def icp_refinement(feedback: str) -> list[PromptMessage]:
        """Refine ICP profiles based on user feedback.

        Args:
            feedback: What to change about the current ICP profiles
        """
        return [
            PromptMessage(
                role="user",
                content=TextContent(
                    type="text",
                    text=f"""Refine the ICP profiles based on this feedback: {feedback}

1. Use g8_search_kb with queries like "ICP" and "buyer persona" to load current profiles
2. Analyze what's working and what needs to change based on the feedback
3. Suggest specific updates to:
   - Target company characteristics (size, industry, tech stack)
   - Buyer titles and seniority levels
   - Pain points and use cases
   - Qualification criteria
4. Explain how these changes would affect campaign targeting""",
                ),
            )
        ]
