"""MCP resources — read-only context agents can include in prompts."""

from __future__ import annotations

from mcp.server import FastMCP

from g8_mcp_server.client import G8Client, format_result


def register(server: FastMCP, client: G8Client) -> None:
    """Register all MCP resources on the server."""

    @server.resource("g8://repos")
    async def list_repos() -> str:
        """List of connected repositories with names, URLs, and status."""
        result = await client.get("/repos")
        return format_result(result)

    @server.resource("g8://repos/{repo_id}/scan")
    async def get_scan(repo_id: str) -> str:
        """Latest scan results — tech stack, API routes, and GTM readiness."""
        result = await client.get(f"/repos/{repo_id}/scan")
        return format_result(result)

    @server.resource("g8://repos/{repo_id}/kb")
    async def list_kb_docs(repo_id: str) -> str:
        """Knowledge base document list — 45 doc titles and categories."""
        result = await client.get(f"/repos/{repo_id}/kb")
        return format_result(result)

    @server.resource("g8://repos/{repo_id}/kb/{doc_id}")
    async def get_kb_doc(repo_id: str, doc_id: str) -> str:
        """Individual KB document — full strategic content."""
        result = await client.get(f"/repos/{repo_id}/kb/{doc_id}")
        return format_result(result)

    @server.resource("g8://repos/{repo_id}/campaigns")
    async def list_campaigns(repo_id: str) -> str:
        """Campaign list with names, categories, goals, and readiness status."""
        result = await client.get(f"/repos/{repo_id}/campaigns")
        return format_result(result)

    @server.resource("g8://repos/{repo_id}/campaigns/{campaign_id}/brief")
    async def get_campaign_brief(repo_id: str, campaign_id: str) -> str:
        """Campaign brief — strategy, audience, goals, and channel plan."""
        result = await client.get(f"/repos/{repo_id}/campaigns/{campaign_id}")
        return format_result(result)

    @server.resource("g8://contacts")
    async def list_contacts() -> str:
        """Recent contacts summary — names, emails, companies, and titles."""
        result = await client.get("/contacts", {"limit": 50})
        return format_result(result)

    @server.resource("g8://companies")
    async def list_companies() -> str:
        """Companies summary — names, domains, industries, and employee counts."""
        result = await client.get("/companies", {"limit": 50})
        return format_result(result)
