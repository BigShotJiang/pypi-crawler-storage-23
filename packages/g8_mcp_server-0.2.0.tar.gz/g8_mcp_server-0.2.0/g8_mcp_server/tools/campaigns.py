"""Campaign management tools — list, inspect, create, update, and launch campaigns."""

from __future__ import annotations

from mcp.server import FastMCP

from g8_mcp_server.client import G8Client, format_result


def register(server: FastMCP, client: G8Client) -> None:
    """Register campaign tools on the MCP server."""

    @server.tool()
    async def g8_list_campaigns(repo_id: str, page: int = 1, limit: int = 50) -> str:
        """List generated campaigns for a repository.

        Returns campaign names, categories, goals, and statuses.

        Args:
            repo_id: Repository ID
            page: Page number (default 1)
            limit: Items per page (default 50, max 200)
        """
        result = await client.get(f"/repos/{repo_id}/campaigns", {"page": page, "limit": limit})
        return format_result(result)

    @server.tool()
    async def g8_get_campaign(repo_id: str, campaign_id: str) -> str:
        """Get full details for a specific campaign.

        Returns the campaign brief, core concept, primary hook, target persona,
        channel strategy, and all content.

        Args:
            repo_id: Repository ID
            campaign_id: Campaign ID from g8_list_campaigns
        """
        result = await client.get(f"/repos/{repo_id}/campaigns/{campaign_id}")
        return format_result(result)

    @server.tool()
    async def g8_launch_campaign(repo_id: str, campaign_id: str, dry_run: bool = False) -> str:
        """Launch a campaign to begin outbound execution.

        IMPORTANT: This starts sending outreach to real contacts. Always confirm
        with the user before calling this tool. Use dry_run=True to preview
        what would happen without executing.

        Args:
            repo_id: Repository ID
            campaign_id: Campaign ID to launch
            dry_run: If True, returns a preview without actually launching
        """
        body = {"dry_run": dry_run} if dry_run else None
        result = await client.post(f"/repos/{repo_id}/campaigns/{campaign_id}/launch", body)
        return format_result(result)

    @server.tool()
    async def g8_update_campaign(
        repo_id: str,
        campaign_id: str,
        name: str | None = None,
        brief: str | None = None,
        core_concept: str | None = None,
        primary_hook: str | None = None,
        target_persona: str | None = None,
        category: str | None = None,
        goal: str | None = None,
    ) -> str:
        """Update a campaign's content — name, brief, hook, persona, etc.

        Only provide the fields you want to change. Unchanged fields keep
        their current values.

        Args:
            repo_id: Repository ID
            campaign_id: Campaign ID to update
            name: New campaign name
            brief: New campaign brief
            core_concept: New core concept
            primary_hook: New primary hook text
            target_persona: New target persona description
            category: New category (e.g. Outbound, Social Proof, Trigger)
            goal: New goal (e.g. awareness, consideration, decision)
        """
        body = {
            k: v for k, v in {
                "name": name, "brief": brief, "core_concept": core_concept,
                "primary_hook": primary_hook, "target_persona": target_persona,
                "category": category, "goal": goal,
            }.items() if v is not None
        }
        result = await client.patch(f"/repos/{repo_id}/campaigns/{campaign_id}", body)
        return format_result(result)

    @server.tool()
    async def g8_create_campaign(
        repo_id: str,
        name: str,
        category: str = "Outbound",
        brief: str | None = None,
        core_concept: str | None = None,
        primary_hook: str | None = None,
        target_persona: str | None = None,
        goal: str | None = None,
    ) -> str:
        """Create a new campaign from scratch.

        Returns the new campaign ID and slug. The campaign starts in 'draft'
        status — use g8_launch_campaign to activate it.

        Args:
            repo_id: Repository ID
            name: Campaign name (required)
            category: Category — Outbound, Social Proof, Trigger, Persona,
                      Thought Leadership, or Insight
            brief: Campaign brief describing the strategy
            core_concept: Core concept text
            primary_hook: Primary hook text
            target_persona: Target persona description
            goal: Goal — awareness, consideration, or decision
        """
        body = {
            k: v for k, v in {
                "name": name, "category": category, "brief": brief,
                "core_concept": core_concept, "primary_hook": primary_hook,
                "target_persona": target_persona, "goal": goal,
            }.items() if v is not None
        }
        result = await client.post(f"/repos/{repo_id}/campaigns", body)
        return format_result(result)

    @server.tool()
    async def g8_get_campaign_document(repo_id: str, campaign_id: str, document_id: str) -> str:
        """Get the full content of a campaign document.

        Use g8_get_campaign first to see the list of documents, then call
        this tool with a specific document_id to read its body content.

        Args:
            repo_id: Repository ID
            campaign_id: Campaign ID
            document_id: Document ID from the campaign's documents list
        """
        result = await client.get(f"/repos/{repo_id}/campaigns/{campaign_id}/documents/{document_id}")
        return format_result(result)
