"""Platform tools — contacts, companies, enrichment, and sequences."""

from __future__ import annotations

from mcp.server import FastMCP

from g8_mcp_server.client import G8Client, format_result


def register(server: FastMCP, client: G8Client) -> None:
    """Register platform tools on the MCP server."""

    @server.tool()
    async def g8_search_contacts(
        email: str | None = None,
        list_id: str | None = None,
        page: int = 1,
        limit: int = 50,
    ) -> str:
        """Search contacts in the graph8 CDP.

        Filter by email address or list membership. Returns contact profiles
        with name, email, job title, company, and other key fields.

        Args:
            email: Filter by email address (exact match)
            list_id: Filter by contact list ID
            page: Page number (default 1)
            limit: Items per page (default 50, max 200)
        """
        result = await client.get("/contacts", {"email": email, "list_id": list_id, "page": page, "limit": limit})
        return format_result(result)

    @server.tool()
    async def g8_search_companies(
        domain: str | None = None,
        industry: str | None = None,
        page: int = 1,
        limit: int = 50,
    ) -> str:
        """Search companies in the graph8 CDP.

        Filter by domain or industry. Returns company profiles with name,
        domain, industry, employee count, and other key fields.

        Args:
            domain: Filter by company domain (e.g. acme.com)
            industry: Filter by industry
            page: Page number (default 1)
            limit: Items per page (default 50, max 200)
        """
        result = await client.get("/companies", {"domain": domain, "industry": industry, "page": page, "limit": limit})
        return format_result(result)

    @server.tool()
    async def g8_lookup_person(
        email: str | None = None,
        linkedin_url: str | None = None,
        first_name: str | None = None,
        last_name: str | None = None,
        company_domain: str | None = None,
    ) -> str:
        """Instantly enrich a person's profile using graph8's multi-provider waterfall.

        Provide at least one of: email, linkedin_url, or (first_name + last_name + company_domain).
        Returns enriched data including verified email, phone, job title, company info,
        and a confidence score.

        Args:
            email: Person's email address
            linkedin_url: Person's LinkedIn profile URL
            first_name: Person's first name (combine with last_name + company_domain)
            last_name: Person's last name
            company_domain: Person's company domain (e.g. acme.com)
        """
        body = {k: v for k, v in {"email": email, "linkedin_url": linkedin_url, "first_name": first_name, "last_name": last_name, "company_domain": company_domain}.items() if v is not None}
        result = await client.post("/enrichment/lookup/person", body)
        return format_result(result)

    @server.tool()
    async def g8_lookup_company(
        domain: str | None = None,
        name: str | None = None,
    ) -> str:
        """Instantly enrich a company's profile using graph8's multi-provider waterfall.

        Provide at least one of: domain or name. Returns enriched data including
        revenue, headcount, industry, tech stack, funding, and a confidence score.

        Args:
            domain: Company domain (e.g. acme.com)
            name: Company name
        """
        body = {k: v for k, v in {"domain": domain, "name": name}.items() if v is not None}
        result = await client.post("/enrichment/lookup/company", body)
        return format_result(result)

    @server.tool()
    async def g8_add_to_sequence(
        sequence_id: str,
        contact_ids: list[int],
        list_id: int,
    ) -> str:
        """Add contacts to an outbound sequence for automated outreach.

        IMPORTANT: This enrolls real contacts into an active sequence that will
        send emails/messages. Always confirm with the user before calling this tool.

        Args:
            sequence_id: Sequence ID to add contacts to
            contact_ids: List of contact IDs to enroll
            list_id: Contact list ID the contacts belong to
        """
        result = await client.post(f"/sequences/{sequence_id}/contacts", {"contact_ids": contact_ids, "list_id": list_id})
        return format_result(result)
