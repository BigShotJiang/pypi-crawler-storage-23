"""Developer mode tools — repo-scoped operations for building GTM into codebases.

These tools require a repo_id and are used by developers in Cursor, Windsurf,
or Claude Code while building products.
"""

from __future__ import annotations

from mcp.server import FastMCP

from g8_mcp_server.client import G8Client, format_result


def register(server: FastMCP, client: G8Client) -> None:
    """Register dev-mode tools (repo-scoped)."""

    # -- Repos --

    @server.tool()
    async def g8_connect_repo(repo_url: str, repo_name: str, provider: str = "github", default_branch: str = "main") -> str:
        """Connect a GitHub/GitLab repository to graph8 for GTM automation.

        After connecting, run g8_scan_repo to analyze the tech stack.

        Args:
            repo_url: Full repository URL (e.g. https://github.com/org/repo)
            repo_name: Short name for the repo (e.g. my-saas-app)
            provider: Repository provider — github, gitlab, or local
            default_branch: Default branch name (usually main)
        """
        result = await client.post("/repos", {"repo_url": repo_url, "repo_name": repo_name, "provider": provider, "default_branch": default_branch})
        return format_result(result)

    @server.tool()
    async def g8_scan_repo(repo_id: str) -> str:
        """Scan a connected repository for tech stack, API routes, and GTM readiness.

        Args:
            repo_id: Repository ID from g8_connect_repo or g8_status
        """
        result = await client.post(f"/repos/{repo_id}/scan", {})
        return format_result(result)

    @server.tool()
    async def g8_get_scan_results(repo_id: str) -> str:
        """Get the latest scan results for a repository.

        Returns detected tech stack, API routes, README summary, and GTM readiness flags.

        Args:
            repo_id: Repository ID
        """
        result = await client.get(f"/repos/{repo_id}/scan")
        return format_result(result)

    @server.tool()
    async def g8_status(repo_id: str) -> str:
        """Get the current status of a connected repository.

        Args:
            repo_id: Repository ID
        """
        result = await client.get(f"/repos/{repo_id}")
        return format_result(result)

    @server.tool()
    async def g8_doctor(repo_id: str) -> str:
        """Run health checks on a repository's GTM installation.

        Args:
            repo_id: Repository ID
        """
        result = await client.post(f"/repos/{repo_id}/verify", {})
        return format_result(result)

    # -- Install --

    @server.tool()
    async def g8_install_spine(repo_id: str) -> str:
        """Generate a GTM install patch set for a scanned repository.

        Produces code patches that add tracking, forms, identity resolution,
        and attribution to the codebase. Review the patches before applying.

        Args:
            repo_id: Repository ID (must have scan results first)
        """
        result = await client.post(f"/repos/{repo_id}/install")
        return format_result(result)

    @server.tool()
    async def g8_apply_install(repo_id: str) -> str:
        """Apply the generated GTM patches to the repository.

        IMPORTANT: This modifies the codebase. Always confirm with the user first.

        Args:
            repo_id: Repository ID with a pending patch set
        """
        result = await client.post(f"/repos/{repo_id}/install/apply")
        return format_result(result)

    # -- Dev-mode campaigns (repo-scoped) --

    @server.tool()
    async def g8_list_campaigns(repo_id: str, page: int = 1, limit: int = 50) -> str:
        """List generated campaigns for a repository.

        Args:
            repo_id: Repository ID
            page: Page number (default 1)
            limit: Items per page (default 50, max 200)
        """
        result = await client.get(f"/repos/{repo_id}/campaigns", {"page": page, "limit": limit})
        return format_result(result)

    @server.tool()
    async def g8_get_campaign(repo_id: str, campaign_id: str) -> str:
        """Get full details for a specific campaign.

        Args:
            repo_id: Repository ID
            campaign_id: Campaign ID from g8_list_campaigns
        """
        result = await client.get(f"/repos/{repo_id}/campaigns/{campaign_id}")
        return format_result(result)

    @server.tool()
    async def g8_search_kb(repo_id: str, query: str) -> str:
        """Search the GTM knowledge base for a repository.

        Args:
            repo_id: Repository ID
            query: Search query (e.g. "ICP for enterprise buyers")
        """
        result = await client.post(f"/repos/{repo_id}/kb/search", {"query": query})
        return format_result(result)

    @server.tool()
    async def g8_list_kb_documents(repo_id: str) -> str:
        """List all documents in the GTM knowledge base.

        Args:
            repo_id: Repository ID
        """
        result = await client.get(f"/repos/{repo_id}/kb")
        return format_result(result)
