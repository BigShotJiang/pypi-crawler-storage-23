"""Knowledge base tools — search and browse GTM strategic documents."""

from __future__ import annotations

from mcp.server import FastMCP

from g8_mcp_server.client import G8Client, format_result


def register(server: FastMCP, client: G8Client) -> None:
    """Register KB tools on the MCP server."""

    @server.tool()
    async def g8_search_kb(repo_id: str, query: str) -> str:
        """Search the GTM knowledge base for a repository.

        The knowledge base contains strategic documents covering company
        profile, ICP profiles, buyer personas, messaging, competitive analysis,
        market intelligence, content strategy, sales enablement, channel strategy,
        and GTM readiness.

        Args:
            repo_id: Repository ID
            query: Search query (e.g. "ICP for enterprise buyers", "objection handling")
        """
        result = await client.post(f"/repos/{repo_id}/kb/search", {"query": query})
        return format_result(result)

    @server.tool()
    async def g8_list_kb_documents(repo_id: str) -> str:
        """List all documents in the GTM knowledge base.

        Returns document titles grouped by section (brand, market, audience,
        offer, messaging, intelligence, research). Use this to browse what's
        available before searching.

        Args:
            repo_id: Repository ID
        """
        result = await client.get(f"/repos/{repo_id}/kb")
        return format_result(result)
