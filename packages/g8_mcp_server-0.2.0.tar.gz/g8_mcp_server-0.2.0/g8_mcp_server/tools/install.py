"""GTM infrastructure installation tools — generate and apply patch sets."""

from __future__ import annotations

from mcp.server import FastMCP

from g8_mcp_server.client import G8Client, format_result


def register(server: FastMCP, client: G8Client) -> None:
    """Register install tools on the MCP server."""

    @server.tool()
    async def g8_install_spine(repo_id: str) -> str:
        """Generate a GTM install patch set for a scanned repository.

        Produces code patches that add tracking, forms, identity resolution,
        and attribution to the codebase. Review the patches before applying
        with g8_apply_install.

        Returns the patch set with file-level diffs for review.

        Args:
            repo_id: Repository ID (must have scan results first)
        """
        result = await client.post(f"/repos/{repo_id}/install")
        return format_result(result)

    @server.tool()
    async def g8_apply_install(repo_id: str) -> str:
        """Apply the generated GTM patches to the repository.

        IMPORTANT: This modifies the codebase. Always confirm with the user
        before calling this tool. Review patches from g8_install_spine first.

        Args:
            repo_id: Repository ID with a pending patch set
        """
        result = await client.post(f"/repos/{repo_id}/install/apply")
        return format_result(result)
