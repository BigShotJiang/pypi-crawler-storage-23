"""Per-request auth context for MCP tools (remote mode)."""

from contextvars import ContextVar

# Set by auth middleware on each HTTP request, read by G8Client._headers
_api_key: ContextVar[str] = ContextVar("g8_api_key")


def set_api_key(key: str) -> None:
    _api_key.set(key)


def get_api_key() -> str | None:
    return _api_key.get(None)
