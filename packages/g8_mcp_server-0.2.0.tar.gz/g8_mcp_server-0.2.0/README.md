# g8-mcp-server

graph8 MCP server — GTM operations for AI agents.

Connects AI coding agents (Claude Code, Cursor, Windsurf) to graph8's GTM automation platform via the [Model Context Protocol](https://modelcontextprotocol.io).

## Install

```bash
# Run directly (recommended)
uvx g8-mcp-server

# Or install globally
pip install g8-mcp-server
```

## Configure

### Claude Code

Add to `~/.claude/mcp.json`:

```json
{
  "mcpServers": {
    "graph8": {
      "command": "uvx",
      "args": ["g8-mcp-server"],
      "env": {
        "G8_API_KEY": "g8_key_xxxxx",
        "G8_API_URL": "https://api.graph8.com"
      }
    }
  }
}
```

### Cursor

Add to `.cursor/mcp.json` in your project:

```json
{
  "mcpServers": {
    "graph8": {
      "command": "uvx",
      "args": ["g8-mcp-server"],
      "env": {
        "G8_API_KEY": "g8_key_xxxxx",
        "G8_API_URL": "https://api.graph8.com"
      }
    }
  }
}
```

Get your API key at [app.graph8.com/settings/api-keys](https://app.graph8.com/settings/api-keys).

## Tools (16)

### GTM Spine (11)

| Tool | Description |
|------|------------|
| `g8_connect_repo` | Connect a GitHub/GitLab repository |
| `g8_scan_repo` | Scan repo for tech stack and GTM readiness |
| `g8_get_scan_results` | Get scan results |
| `g8_status` | Get repo connection and install status |
| `g8_doctor` | Run health checks on GTM installation |
| `g8_install_spine` | Generate GTM install patch set |
| `g8_apply_install` | Apply patches (requires confirmation) |
| `g8_list_campaigns` | List generated campaigns |
| `g8_get_campaign` | Get campaign details |
| `g8_launch_campaign` | Launch a campaign (supports dry_run) |
| `g8_search_kb` | Search the GTM knowledge base |

### Platform (5)

| Tool | Description |
|------|------------|
| `g8_search_contacts` | Search contacts in the CDP |
| `g8_search_companies` | Search companies by domain or industry |
| `g8_lookup_person` | Instant person enrichment |
| `g8_lookup_company` | Instant company enrichment |
| `g8_add_to_sequence` | Add contacts to a sequence (requires confirmation) |

## Resources (8)

Resources provide read-only context agents can include in prompts:

- `g8://repos` — connected repositories
- `g8://repos/{id}/scan` — scan results
- `g8://repos/{id}/kb` — knowledge base documents
- `g8://repos/{id}/kb/{doc_id}` — individual KB document
- `g8://repos/{id}/campaigns` — campaign list
- `g8://repos/{id}/campaigns/{id}/brief` — campaign brief
- `g8://contacts` — recent contacts
- `g8://companies` — companies

## Prompts (3)

Pre-built workflow templates:

- `gtm_setup` — full setup: connect → scan → install → launch
- `campaign_review` — review and improve a campaign
- `icp_refinement` — refine ICP profiles from feedback

## Development

```bash
cd mcp_server
pip install -e ".[dev]"
pytest
```
