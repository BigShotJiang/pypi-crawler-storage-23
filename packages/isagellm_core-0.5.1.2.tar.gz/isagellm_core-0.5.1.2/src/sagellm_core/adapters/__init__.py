"""Engine adapters for third-party inference engines.

This module provides adapters for integrating engines following the Adapter/Provider Pattern.

Key Principle (Adapter Pattern):
    ❌ Prohibit third-party libraries from invading core control flow
    ✅ Must isolate external dependencies through Adapter/Provider

Available Adapters:
    - NativeLLMEngineAdapter: sageLLM's native engine (HIGHEST PRIORITY)
    - vLLMAdapter: vLLM (high-performance serving, PagedAttention)
    - LMDeployAdapter: LMDeploy (Ascend/CUDA support, quantization)
    - SGLangAdapter: SGLang (fast prefix sharing, RadixAttention)

Priority Hierarchy:
    - 200: sageLLM Native (NativeLLMEngineAdapter) - HIGHEST
    - 100-110: Domestic accelerators (Ascend, Cambricon, Kunlun)
    - 50-99: Third-party CUDA engines (vLLM, LMDeploy, SGLang)
    - 0-49: CPU/low-priority engines

Example:
    >>> from sagellm_core.adapters import NativeLLMEngineAdapter
    >>> from sagellm_core.engine import EngineInstanceConfig
    >>>
    >>> config = EngineInstanceConfig(
    ...     engine_id="native-001",
    ...     model_path="meta-llama/Llama-2-7b",
    ...     device="auto",  # Auto-selects best backend
    ... )
    >>> adapter = NativeLLMEngineAdapter(config)
    >>> await adapter.start()
    >>> response = await adapter.execute(request)

Auto-Registration:
    All adapters are automatically registered with EngineFactory upon import.
    Use EngineFactory.create(backend_type="auto") to auto-select highest priority.
    Use EngineFactory.create(backend_type="native") for explicit selection.
"""

from __future__ import annotations

# Native sageLLM engine (highest priority)
from sagellm_core.adapters.native_adapter import NativeLLMEngineAdapter

# Third-party adapters
from sagellm_core.adapters.vllm_adapter import vLLMAdapter

# Import other adapters as they become available
try:
    from sagellm_core.adapters.lmdeploy_adapter import LMDeployAdapter
except ImportError:
    LMDeployAdapter = None  # type: ignore[assignment,misc]

try:
    from sagellm_core.adapters.sglang_adapter import SGLangAdapter
except ImportError:
    SGLangAdapter = None  # type: ignore[assignment,misc]

__all__ = [
    # Native sageLLM engine (recommended default)
    "NativeLLMEngineAdapter",
    # Third-party adapters (alternatives)
    "vLLMAdapter",
    "LMDeployAdapter",
    "SGLangAdapter",
]
