#!/usr/bin/env bash
# Clean build, test and publish ailab-cli to PyPI.
# Usage: ./publish.sh
set -euo pipefail

cd "$(dirname "$0")"

echo "=== Clean ==="
rm -rf dist/ build/ src/*.egg-info

echo "=== Install (editable + dev) ==="
pip install -e ".[dev]" -q

echo "=== Test ==="
python -m pytest tests/ -v
echo ""

echo "=== Build ==="
pip install build twine -q
python -m build
echo ""

echo "=== Publish ==="
twine upload dist/*

echo ""
echo "✓ Done — https://pypi.org/project/ailab-cli/"
