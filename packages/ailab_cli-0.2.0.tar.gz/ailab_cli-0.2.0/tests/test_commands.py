"""
Tests for CLI commands — uses Typer's CliRunner to invoke commands.

Patches are applied at the point-of-use module (e.g. ailab_cli.projects.load_config),
NOT at the definition module, because Python's `from X import Y` creates a local binding.
"""

import json
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch, MagicMock

import httpx
import pytest
import respx
from typer.testing import CliRunner

from ailab_cli.main import app
from ailab_cli.config import Config

runner = CliRunner()

# ── Helpers ──────────────────────────────────────────────────────────

FUTURE = (datetime.now(timezone.utc) + timedelta(days=30)).isoformat()

AUTHENTICATED_CONFIG = Config(
    api_url="https://test.example.com",
    token="test_token",
    email="user@example.com",
    expires_at=FUTURE,
)

# Modules that import load_config and is_authenticated locally
_CONFIG_MODULES = [
    "ailab_cli.config",
    "ailab_cli.auth",
    "ailab_cli.projects",
    "ailab_cli.runs",
    "ailab_cli.export",
    "ailab_cli.interactive",
]


def mock_config(config: Config = AUTHENTICATED_CONFIG, authenticated: bool | None = None):
    """
    Context manager that patches load_config and is_authenticated at ALL
    point-of-use modules simultaneously. Returns a deep copy to avoid
    mutation leaking between tests.
    """
    cfg = deepcopy(config)
    if authenticated is None:
        authenticated = cfg.token is not None

    stack = ExitStack()
    for mod in _CONFIG_MODULES:
        stack.enter_context(patch(f"{mod}.load_config", return_value=cfg))
        stack.enter_context(patch(f"{mod}.is_authenticated", return_value=authenticated))
    return stack


# ── Test: --help ─────────────────────────────────────────────────────


class TestCLIHelp:
    """Test that CLI help output is correct."""

    def test_main_help(self):
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "projects" in result.output
        assert "runs" in result.output
        assert "export" in result.output
        assert "auth" in result.output

    def test_auth_help(self):
        result = runner.invoke(app, ["auth", "--help"])
        assert result.exit_code == 0
        assert "login" in result.output
        assert "logout" in result.output
        assert "status" in result.output

    def test_export_help(self):
        result = runner.invoke(app, ["export", "--help"])
        assert result.exit_code == 0
        assert "--project" in result.output
        assert "--run" in result.output
        assert "--output" in result.output
        assert "--format" in result.output


# ── Test: --url global option ────────────────────────────────────────


class TestGlobalUrlOption:
    """Test that --url is passed through to commands."""

    @respx.mock
    def test_projects_with_url_override(self):
        projects_data = [{"id": "p1", "name": "P1", "owners": [], "editors": [], "readers": []}]
        respx.get("https://prelive.example.com/api/projects").mock(
            return_value=httpx.Response(200, json=projects_data)
        )

        with mock_config():
            result = runner.invoke(app, ["--url", "https://prelive.example.com", "projects"])
        assert result.exit_code == 0
        assert "P1" in result.output

    @respx.mock
    def test_runs_with_url_override(self):
        runs_data = [{"id": "r1", "name": "Run 1"}]
        respx.get("https://prelive.example.com/api/projects/p1/annotationRuns").mock(
            return_value=httpx.Response(200, json=runs_data)
        )

        with mock_config():
            result = runner.invoke(app, ["--url", "https://prelive.example.com", "runs", "p1"])
        assert result.exit_code == 0
        assert "Run 1" in result.output


# ── Test: auth status ────────────────────────────────────────────────


class TestAuthStatus:
    """Test auth status command."""

    def test_shows_logged_in(self):
        with mock_config():
            result = runner.invoke(app, ["auth", "status"])
        assert result.exit_code == 0
        assert "user@example.com" in result.output

    def test_shows_not_logged_in(self):
        with mock_config(Config(), authenticated=False):
            result = runner.invoke(app, ["auth", "status"])
        assert result.exit_code == 0
        assert "Not logged in" in result.output


# ── Test: auth logout ────────────────────────────────────────────────


class TestAuthLogout:
    """Test auth logout command."""

    def test_logout_when_logged_in(self):
        with mock_config(), \
             patch("ailab_cli.auth.delete_config") as mock_delete:
            result = runner.invoke(app, ["auth", "logout"])
        assert result.exit_code == 0
        assert "Logged out" in result.output
        mock_delete.assert_called_once()

    def test_logout_when_not_logged_in(self):
        with mock_config(Config(), authenticated=False):
            result = runner.invoke(app, ["auth", "logout"])
        assert result.exit_code == 0
        assert "Not logged in" in result.output


# ── Test: projects ───────────────────────────────────────────────────


class TestProjects:
    """Test projects command."""

    @respx.mock
    def test_lists_projects(self):
        projects_data = [
            {
                "id": "proj-1",
                "name": "My ML Project",
                "owners": [{"email": "user@example.com"}],
                "editors": [],
                "readers": [],
                "updatedAt": "2026-02-20T10:00:00Z",
            },
        ]
        respx.get("https://test.example.com/api/projects").mock(
            return_value=httpx.Response(200, json=projects_data)
        )

        with mock_config():
            result = runner.invoke(app, ["projects"])
        assert result.exit_code == 0
        assert "My ML Project" in result.output
        assert "Owner" in result.output

    @respx.mock
    def test_empty_projects(self):
        respx.get("https://test.example.com/api/projects").mock(
            return_value=httpx.Response(200, json=[])
        )

        with mock_config():
            result = runner.invoke(app, ["projects"])
        assert result.exit_code == 0
        assert "No projects found" in result.output

    def test_requires_auth(self):
        with mock_config(Config(), authenticated=False):
            result = runner.invoke(app, ["projects"])
        assert result.exit_code == 1
        assert "Not logged in" in result.output

    @respx.mock
    def test_handles_api_error(self):
        respx.get("https://test.example.com/api/projects").mock(
            return_value=httpx.Response(500, json={"error": "Server exploded"})
        )

        with mock_config():
            result = runner.invoke(app, ["projects"])
        assert result.exit_code == 1
        assert "Server exploded" in result.output


# ── Test: runs ───────────────────────────────────────────────────────


class TestRuns:
    """Test runs command."""

    @respx.mock
    def test_lists_runs(self):
        runs_data = [
            {
                "id": "run-1",
                "name": "Initial Annotation",
                "dataset": {"name": "COCO subset"},
                "annotations": [{"id": "a1"}, {"id": "a2"}],
                "updatedAt": "2026-02-21T12:00:00Z",
            },
        ]
        respx.get("https://test.example.com/api/projects/p1/annotationRuns").mock(
            return_value=httpx.Response(200, json=runs_data)
        )

        with mock_config():
            result = runner.invoke(app, ["runs", "p1"])
        assert result.exit_code == 0
        assert "Initial Annotation" in result.output
        assert "COCO subset" in result.output

    @respx.mock
    def test_empty_runs(self):
        respx.get("https://test.example.com/api/projects/p1/annotationRuns").mock(
            return_value=httpx.Response(200, json=[])
        )

        with mock_config():
            result = runner.invoke(app, ["runs", "p1"])
        assert result.exit_code == 0
        assert "No annotation runs" in result.output

    def test_requires_project_id(self):
        result = runner.invoke(app, ["runs"])
        assert result.exit_code != 0


# ── Test: export ─────────────────────────────────────────────────────


class TestExport:
    """Test export command."""

    @respx.mock
    def test_export_json(self, tmp_path):
        export_data = {
            "title": "My Export",
            "totalEntries": 2,
            "entries": [
                {"url": "img1.jpg", "label": "cat"},
                {"url": "img2.jpg", "label": "dog"},
            ],
        }
        respx.get("https://test.example.com/api/projects/p1/annotationRuns/r1/export").mock(
            return_value=httpx.Response(200, json=export_data)
        )

        out_file = tmp_path / "out.json"
        with mock_config():
            result = runner.invoke(app, [
                "export", "-p", "p1", "-r", "r1", "-o", str(out_file),
            ])
        assert result.exit_code == 0
        assert out_file.exists()

        saved = json.loads(out_file.read_text())
        assert saved["totalEntries"] == 2
        assert len(saved["entries"]) == 2

    @respx.mock
    def test_export_csv(self, tmp_path):
        export_data = {
            "title": "CSV Export",
            "totalEntries": 1,
            "entries": [{"url": "img1.jpg", "label": "bird"}],
        }
        respx.get("https://test.example.com/api/projects/p1/annotationRuns/r1/export").mock(
            return_value=httpx.Response(200, json=export_data)
        )

        out_file = tmp_path / "out.csv"
        with mock_config():
            result = runner.invoke(app, [
                "export", "-p", "p1", "-r", "r1", "-o", str(out_file), "-f", "csv",
            ])
        assert result.exit_code == 0
        assert out_file.exists()
        content = out_file.read_text()
        assert "url" in content
        assert "bird" in content

    def test_export_requires_project_and_run(self):
        result = runner.invoke(app, ["export"])
        assert result.exit_code != 0

    def test_export_requires_auth(self):
        with mock_config(Config(), authenticated=False):
            result = runner.invoke(app, [
                "export", "-p", "p1", "-r", "r1",
            ])
        assert result.exit_code == 1
        assert "Not logged in" in result.output


# ── Test: connection errors ──────────────────────────────────────────


class TestConnectionErrors:
    """Test that unreachable servers show user-friendly error messages."""

    def test_projects_connection_error(self):
        from ailab_cli.api_client import ApiConnectionError

        with mock_config(), \
             patch("ailab_cli.projects.ApiClient") as MockClient:
            instance = MockClient.return_value
            instance.list_projects.side_effect = ApiConnectionError(
                "https://test.example.com", ConnectionError("refused")
            )
            result = runner.invoke(app, ["projects"])
        assert result.exit_code == 1
        assert "Connection error" in result.output
        assert "test.example.com" in result.output

    def test_runs_connection_error(self):
        from ailab_cli.api_client import ApiConnectionError

        with mock_config(), \
             patch("ailab_cli.runs.ApiClient") as MockClient:
            instance = MockClient.return_value
            instance.list_runs.side_effect = ApiConnectionError(
                "https://test.example.com", ConnectionError("refused")
            )
            result = runner.invoke(app, ["runs", "p1"])
        assert result.exit_code == 1
        assert "Connection error" in result.output

    def test_export_connection_error(self):
        from ailab_cli.api_client import ApiConnectionError

        with mock_config(), \
             patch("ailab_cli.export.ApiClient") as MockClient:
            instance = MockClient.return_value
            instance.export_run.side_effect = ApiConnectionError(
                "https://test.example.com", ConnectionError("refused")
            )
            result = runner.invoke(app, ["export", "-p", "p1", "-r", "r1"])
        assert result.exit_code == 1
        assert "Connection error" in result.output
