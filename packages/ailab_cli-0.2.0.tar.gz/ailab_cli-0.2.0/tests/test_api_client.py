"""
Tests for ApiClient — HTTP methods, error handling, convenience methods.

Uses respx to mock httpx requests.
"""

import json

import pytest
import httpx
import respx

from ailab_cli.config import Config
from ailab_cli.api_client import ApiClient, ApiError, ApiConnectionError


@pytest.fixture()
def config():
    return Config(
        api_url="https://test.example.com",
        token="test_token_abc",
        email="user@example.com",
    )


@pytest.fixture()
def client(config):
    return ApiClient(config)


class TestHeaders:
    """Test request header generation."""

    def test_includes_bearer_token(self, client):
        headers = client._headers()
        assert headers["Authorization"] == "Bearer test_token_abc"
        assert headers["Content-Type"] == "application/json"

    def test_no_auth_header_without_token(self):
        config = Config(api_url="https://example.com")
        c = ApiClient(config)
        headers = c._headers()
        assert "Authorization" not in headers


class TestErrorHandling:
    """Test API error handling."""

    @respx.mock
    def test_401_raises_api_error(self, client):
        respx.get("https://test.example.com/api/test").mock(
            return_value=httpx.Response(401, json={"error": "Unauthorized"})
        )
        with pytest.raises(ApiError) as exc:
            client.get("/api/test")
        assert exc.value.status_code == 401
        assert "Unauthorized" in exc.value.message

    @respx.mock
    def test_403_raises_api_error(self, client):
        respx.get("https://test.example.com/api/test").mock(
            return_value=httpx.Response(403, json={"error": "Forbidden"})
        )
        with pytest.raises(ApiError) as exc:
            client.get("/api/test")
        assert exc.value.status_code == 403

    @respx.mock
    def test_500_with_error_body(self, client):
        respx.get("https://test.example.com/api/test").mock(
            return_value=httpx.Response(500, json={"error": "Internal error"})
        )
        with pytest.raises(ApiError) as exc:
            client.get("/api/test")
        assert exc.value.status_code == 500
        assert "Internal error" in exc.value.message

    @respx.mock
    def test_500_with_plain_text(self, client):
        respx.get("https://test.example.com/api/test").mock(
            return_value=httpx.Response(500, text="something broke")
        )
        with pytest.raises(ApiError) as exc:
            client.get("/api/test")
        assert "something broke" in exc.value.message


class TestGetPost:
    """Test basic GET/POST methods."""

    @respx.mock
    def test_get_returns_json(self, client):
        respx.get("https://test.example.com/api/data").mock(
            return_value=httpx.Response(200, json={"result": "ok"})
        )
        result = client.get("/api/data")
        assert result == {"result": "ok"}

    @respx.mock
    def test_post_sends_json(self, client):
        route = respx.post("https://test.example.com/api/action").mock(
            return_value=httpx.Response(200, json={"done": True})
        )
        result = client.post("/api/action", data={"key": "val"})
        assert result == {"done": True}
        # httpx serializes JSON without spaces
        sent_body = json.loads(route.calls[0].request.content)
        assert sent_body == {"key": "val"}


class TestConvenienceMethods:
    """Test specific API convenience methods."""

    @respx.mock
    def test_initiate_auth(self, client):
        respx.post("https://test.example.com/api/apps/auth").mock(
            return_value=httpx.Response(200, json={
                "deviceCode": "dev123",
                "userCode": "ABCD-EFGH",
                "verificationUrl": "https://test.example.com/en/apps/auth?code=ABCD-EFGH",
            })
        )
        result = client.initiate_auth("CLI")
        assert result["deviceCode"] == "dev123"
        assert result["userCode"] == "ABCD-EFGH"

    @respx.mock
    def test_poll_token_pending(self, client):
        respx.post("https://test.example.com/api/apps/token").mock(
            return_value=httpx.Response(200, json={"status": "pending"})
        )
        result = client.poll_token("dev123")
        assert result["status"] == "pending"

    @respx.mock
    def test_poll_token_approved(self, client):
        respx.post("https://test.example.com/api/apps/token").mock(
            return_value=httpx.Response(200, json={
                "status": "approved",
                "accessToken": "tok_xyz",
                "email": "user@example.com",
                "expiresAt": "2026-05-01T00:00:00Z",
            })
        )
        result = client.poll_token("dev123")
        assert result["status"] == "approved"
        assert result["accessToken"] == "tok_xyz"

    @respx.mock
    def test_list_projects(self, client):
        projects = [
            {"id": "p1", "name": "Project 1", "owners": [], "editors": [], "readers": []},
            {"id": "p2", "name": "Project 2", "owners": [], "editors": [], "readers": []},
        ]
        respx.get("https://test.example.com/api/projects").mock(
            return_value=httpx.Response(200, json=projects)
        )
        result = client.list_projects()
        assert len(result) == 2
        assert result[0]["name"] == "Project 1"

    @respx.mock
    def test_list_runs(self, client):
        runs = [{"id": "r1", "name": "Run 1"}]
        respx.get("https://test.example.com/api/projects/p1/annotationRuns").mock(
            return_value=httpx.Response(200, json=runs)
        )
        result = client.list_runs("p1")
        assert len(result) == 1
        assert result[0]["id"] == "r1"

    @respx.mock
    def test_export_run(self, client):
        export_data = {
            "title": "Test Export",
            "totalEntries": 5,
            "entries": [{"url": "img1.jpg", "label": "cat"}] * 5,
        }
        respx.get("https://test.example.com/api/projects/p1/annotationRuns/r1/export").mock(
            return_value=httpx.Response(200, json=export_data)
        )
        result = client.export_run("p1", "r1")
        assert result["totalEntries"] == 5
        assert len(result["entries"]) == 5


class TestBaseUrlHandling:
    """Test that trailing slashes are stripped correctly."""

    def test_strips_trailing_slash(self):
        config = Config(api_url="https://example.com/")
        c = ApiClient(config)
        assert c.base_url == "https://example.com"


class TestConnectionErrors:
    """Test that network errors raise ApiConnectionError."""

    @respx.mock
    def test_get_connection_refused(self, client):
        respx.get("https://test.example.com/api/test").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )
        with pytest.raises(ApiConnectionError) as exc:
            client.get("/api/test")
        assert "test.example.com" in exc.value.url

    @respx.mock
    def test_post_connection_refused(self, client):
        respx.post("https://test.example.com/api/test").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )
        with pytest.raises(ApiConnectionError) as exc:
            client.post("/api/test")
        assert "test.example.com" in exc.value.url

    @respx.mock
    def test_get_timeout(self, client):
        respx.get("https://test.example.com/api/test").mock(
            side_effect=httpx.TimeoutException("timed out")
        )
        with pytest.raises(ApiConnectionError):
            client.get("/api/test")

    @respx.mock
    def test_initiate_auth_connection_error(self, client):
        respx.post("https://test.example.com/api/apps/auth").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )
        with pytest.raises(ApiConnectionError):
            client.initiate_auth("CLI")
