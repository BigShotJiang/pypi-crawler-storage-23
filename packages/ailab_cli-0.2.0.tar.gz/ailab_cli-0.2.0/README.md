# ailab-cli

CLI for the [AI Image Labeling Tool](https://github.com/XMV-Solutions-GmbH/ai-image-labeling-tool) — export annotations, browse projects and annotation runs.

## Installation

```bash
pip install ailab-cli
# or
pipx install ailab-cli
```

## Quick Start

```bash
# Log in to your AI Image Labeling Tool instance
ailab auth login --api-url https://lab.ai.xmv.de

# Or use the interactive TUI
ailab
```

## Usage

### Interactive Mode

Simply run `ailab` to start the interactive TUI:

```bash
ailab
```

Navigate with arrow keys, Enter to select, Esc to go back.

### Direct Commands

```bash
ailab auth login       # Authenticate via browser
ailab auth logout      # Remove local credentials
ailab auth status      # Show current auth status

ailab projects         # List accessible projects
ailab runs <projectId> # List annotation runs
ailab export -p <projectId> -r <runId> [-o export.json] [-f json|csv]
```

### Global Options

```bash
ailab --url https://other-instance.example.com projects  # Override API URL
```

## Configuration

Config is stored at `~/.config/ailab/config.json`.

You can also set the API URL via environment variable:

```bash
export AILAB_API_URL=https://lab.ai.xmv.de
```

## Publishing to PyPI

### Automated (GitHub Actions)

Tag a release to trigger the CI pipeline:

```bash
# Update version in pyproject.toml first
cd cli
git add pyproject.toml
git commit -m "chore: bump CLI version to X.Y.Z"
git tag cli-vX.Y.Z
git push origin main --tags
```

The GitHub Actions workflow builds, tests, and publishes to PyPI automatically.

**First-time setup:** Configure [PyPI Trusted Publishing](https://docs.pypi.org/trusted-publishers/) for the GitHub repository.

### Manual

```bash
cd cli
pip install build twine
python -m build
twine upload dist/*
```
