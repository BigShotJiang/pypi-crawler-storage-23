"""ailab-cli — CLI for AI Image Labeling Tool."""

__version__ = "0.1.0"
