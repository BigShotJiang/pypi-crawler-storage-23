"""
Interactive TUI mode — launched when running `ailab` with no arguments.

Navigation:
  1. Auth check → login prompt (arrow-key Yes/No) if needed
  2. Project list (arrow keys, Enter to select, Esc to logout prompt)
  3. Run list (arrow keys, Enter to export, Esc to go back to projects)
  4. Export → save to ./export.json, return to run list
"""

import sys

from rich.console import Console
from InquirerPy import inquirer
from InquirerPy.base.control import Choice

from ailab_cli.config import load_config, save_config, delete_config, is_authenticated
from ailab_cli.api_client import ApiClient, ApiError, ApiConnectionError

console = Console()

# Sentinel returned by InquirerPy select when user presses Esc
_ESC = "__ESC__"


def _select(message: str, choices: list[Choice], **kwargs):
    """
    Wrapper around inquirer.select that handles Esc (KeyboardInterrupt)
    by returning the _ESC sentinel instead of raising.
    """
    try:
        return inquirer.select(
            message=message,
            choices=choices,
            pointer="▸",
            show_cursor=False,
            **kwargs,
        ).execute()
    except KeyboardInterrupt:
        return _ESC


def _yes_no(message: str, default_yes: bool = True) -> bool:
    """
    Arrow-key Yes/No selector instead of y/n confirm.
    Returns True for Yes, False for No.
    """
    choices = [
        Choice(value=True, name="Yes"),
        Choice(value=False, name="No"),
    ]
    if not default_yes:
        choices.reverse()

    try:
        return inquirer.select(
            message=message,
            choices=choices,
            pointer="▸",
            show_cursor=False,
        ).execute()
    except KeyboardInterrupt:
        return False


def run_interactive(url_override: str | None = None) -> None:
    """Main interactive mode entry point."""
    config = load_config()
    if url_override:
        config.api_url = url_override
    client = ApiClient(config)

    # ── Step 1: Auth check ──────────────────────────────────────────
    if not is_authenticated(config):
        console.print("[yellow]Not authenticated.[/yellow]")

        if not _yes_no("Log in now?", default_yes=True):
            console.print("Bye.")
            return

        # Inline login flow
        from ailab_cli.auth import login
        login(api_url=url_override or config.api_url)
        # Reload config after login
        config = load_config()
        if url_override:
            config.api_url = url_override
        if not is_authenticated(config):
            return
        client = ApiClient(config)

    console.print(f"[green]✓[/green] Logged in as [bold]{config.email}[/bold]")
    console.print()

    # ── Step 2: Project list loop ───────────────────────────────────
    while True:
        with console.status("Loading projects..."):
            try:
                projects = client.list_projects()
            except ApiConnectionError as e:
                console.print(f"[red]Connection error:[/red] Could not reach server at {e.url}")
                console.print("Check the URL or run [bold]ailab auth login --api-url <url>[/bold] to reconfigure.")
                return
            except ApiError as e:
                console.print(f"[red]Error:[/red] {e.message}")
                return

        if not projects:
            console.print("[dim]No projects found.[/dim]")
            return

        # Build choices — just project name, clean and simple
        project_choices = [
            Choice(value=p["id"], name=p["name"])
            for p in projects
        ]

        selected_project = _select("Select a project:", project_choices)

        if selected_project == _ESC:
            # Esc on project list → offer logout
            if _yes_no("Log out?", default_yes=False):
                delete_config()
                console.print("[green]✓[/green] Logged out.")
                return
            # No → back to project list
            continue

        # ── Step 3: Run list loop ───────────────────────────────────
        _run_list_loop(client, config, selected_project, projects)


def _run_list_loop(
    client: ApiClient,
    config: object,
    project_id: str,
    projects: list[dict],
) -> None:
    """Show runs for a project, allow export or go back."""
    project_name = next((p["name"] for p in projects if p["id"] == project_id), project_id)

    while True:
        with console.status("Loading annotation runs..."):
            try:
                runs = client.list_runs(project_id)
            except ApiConnectionError as e:
                console.print(f"[red]Connection error:[/red] Could not reach server at {e.url}")
                console.print("Check the URL or run [bold]ailab auth login --api-url <url>[/bold] to reconfigure.")
                return
            except ApiError as e:
                console.print(f"[red]Error:[/red] {e.message}")
                return

        if not runs:
            console.print(f"[dim]No annotation runs in \"{project_name}\".[/dim]")
            return

        # Build choices — just run name
        run_choices = [
            Choice(value=r["id"], name=r["name"])
            for r in runs
        ]

        selected_run = _select(f"{project_name} — Fetch export from:", run_choices)

        if selected_run == _ESC:
            # Esc → back to project list
            return

        # ── Step 4: Export ──────────────────────────────────────────
        run_name = next((r["name"] for r in runs if r["id"] == selected_run), selected_run)

        with console.status(f'Exporting "{run_name}"...'):
            try:
                data = client.export_run(project_id, selected_run)
            except ApiConnectionError as e:
                console.print(f"[red]Connection error:[/red] Could not reach server at {e.url}")
                continue
            except ApiError as e:
                console.print(f"[red]Error:[/red] {e.message}")
                continue

        import json
        from pathlib import Path

        out_path = Path("./export.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.write("\n")

        total = data.get("totalEntries", len(data.get("entries", [])))
        console.print(
            f'[green]✓[/green] Saved to [bold]{out_path}[/bold] ({total} entries)'
        )
        console.print()
        # Loop back to run list
