"""
Projects command — list accessible projects.
"""

import typer
from rich.console import Console
from rich.table import Table

from ailab_cli.config import load_config, is_authenticated
from ailab_cli.api_client import ApiClient, ApiError, ApiConnectionError

console = Console()


def projects_command(url_override: str | None = None) -> None:
    """List all accessible projects."""
    config = load_config()
    if url_override:
        config.api_url = url_override
    if not is_authenticated(config):
        console.print("[red]Not logged in.[/red] Run [bold]ailab auth login[/bold] first.")
        raise typer.Exit(1)

    client = ApiClient(config)

    with console.status("Loading projects..."):
        try:
            projects = client.list_projects()
        except ApiConnectionError as e:
            console.print(f"[red]Connection error:[/red] Could not reach server at {e.url}")
            console.print("Check the URL or run [bold]ailab auth login --api-url <url>[/bold] to reconfigure.")
            raise typer.Exit(1)
        except ApiError as e:
            console.print(f"[red]Error:[/red] {e.message}")
            raise typer.Exit(1)

    if not projects:
        console.print("[dim]No projects found.[/dim]")
        return

    table = Table(title="Projects")
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Name", style="bold")
    table.add_column("Role")
    table.add_column("Updated", style="dim")

    for p in projects:
        # Determine user's role
        role = ""
        email = config.email or ""
        owners = [o.get("email", o) if isinstance(o, dict) else o for o in p.get("owners", [])]
        editors = [e.get("email", e) if isinstance(e, dict) else e for e in p.get("editors", [])]
        readers = [r.get("email", r) if isinstance(r, dict) else r for r in p.get("readers", [])]
        if email in owners:
            role = "Owner"
        elif email in editors:
            role = "Editor"
        elif email in readers:
            role = "Reader"

        updated = p.get("updatedAt", p.get("createdAt", ""))
        if updated:
            updated = updated[:10]

        table.add_row(p["id"], p["name"], role, updated)

    console.print(table)
