"""
HTTP API client for communicating with the AI Image Labeling Tool backend.

All requests use Bearer token authentication from the stored config.
"""

import httpx
from typing import Any, Optional

from ailab_cli.config import Config


class ApiError(Exception):
    """Raised when the API returns an error response."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"API error {status_code}: {message}")


class ApiConnectionError(Exception):
    """Raised when the API server cannot be reached."""

    def __init__(self, url: str, original: Exception):
        self.url = url
        self.original = original
        super().__init__(f"Could not reach server at {url}")


class ApiClient:
    """HTTP client for the AI Image Labeling Tool API."""

    def __init__(self, config: Config):
        self.base_url = config.api_url.rstrip("/")
        self.token = config.token
        self.timeout = 30.0

    def _headers(self) -> dict[str, str]:
        """Build request headers with Bearer token auth."""
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _handle_response(self, response: httpx.Response) -> Any:
        """Check response status and return parsed JSON."""
        if response.status_code == 401:
            raise ApiError(401, "Unauthorized — please run 'ailab auth login'")
        if response.status_code == 403:
            raise ApiError(403, "Forbidden — you don't have access to this resource")
        if response.status_code >= 400:
            try:
                body = response.json()
                msg = body.get("error", response.text)
            except Exception:
                msg = response.text
            raise ApiError(response.status_code, msg)
        return response.json()

    def get(self, path: str) -> Any:
        """Send a GET request."""
        url = f"{self.base_url}{path}"
        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.get(url, headers=self._headers())
                return self._handle_response(response)
        except (httpx.ConnectError, httpx.TimeoutException) as e:
            raise ApiConnectionError(self.base_url, e) from e

    def post(self, path: str, data: Optional[dict] = None) -> Any:
        """Send a POST request with optional JSON body."""
        url = f"{self.base_url}{path}"
        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.post(url, headers=self._headers(), json=data or {})
                return self._handle_response(response)
        except (httpx.ConnectError, httpx.TimeoutException) as e:
            raise ApiConnectionError(self.base_url, e) from e

    # ── Convenience methods ──────────────────────────────────────────

    def initiate_auth(self, app_name: str = "CLI") -> dict:
        """POST /api/apps/auth — initiate device auth flow."""
        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.post(
                    f"{self.base_url}/api/apps/auth",
                    headers={"Content-Type": "application/json"},
                    json={"appName": app_name},
                )
                return self._handle_response(response)
        except (httpx.ConnectError, httpx.TimeoutException) as e:
            raise ApiConnectionError(self.base_url, e) from e

    def poll_token(self, device_code: str) -> dict:
        """POST /api/apps/token — poll for approved token."""
        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.post(
                    f"{self.base_url}/api/apps/token",
                    headers={"Content-Type": "application/json"},
                    json={"deviceCode": device_code},
                )
                return self._handle_response(response)
        except (httpx.ConnectError, httpx.TimeoutException) as e:
            raise ApiConnectionError(self.base_url, e) from e

    def list_projects(self) -> list[dict]:
        """GET /api/projects — list accessible projects."""
        return self.get("/api/projects")

    def list_runs(self, project_id: str) -> list[dict]:
        """GET /api/projects/{id}/annotationRuns — list annotation runs."""
        return self.get(f"/api/projects/{project_id}/annotationRuns")

    def export_run(self, project_id: str, run_id: str) -> dict:
        """GET /api/projects/{id}/annotationRuns/{runId}/export — export annotations."""
        return self.get(
            f"/api/projects/{project_id}/annotationRuns/{run_id}/export"
        )
