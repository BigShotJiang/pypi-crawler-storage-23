"""
Export command — export annotations from an annotation run.
"""

import csv
import json
from pathlib import Path

import typer
from rich.console import Console

from ailab_cli.config import load_config, is_authenticated
from ailab_cli.api_client import ApiClient, ApiError, ApiConnectionError

console = Console()


def export_command(
    project_id: str,
    run_id: str,
    output: str = "./export.json",
    fmt: str = "json",
    url_override: str | None = None,
) -> None:
    """Export annotations from an annotation run."""
    config = load_config()
    if url_override:
        config.api_url = url_override
    if not is_authenticated(config):
        console.print("[red]Not logged in.[/red] Run [bold]ailab auth login[/bold] first.")
        raise typer.Exit(1)

    client = ApiClient(config)

    with console.status("Exporting annotations..."):
        try:
            data = client.export_run(project_id, run_id)
        except ApiConnectionError as e:
            console.print(f"[red]Connection error:[/red] Could not reach server at {e.url}")
            console.print("Check the URL or run [bold]ailab auth login --api-url <url>[/bold] to reconfigure.")
            raise typer.Exit(1)
        except ApiError as e:
            console.print(f"[red]Error:[/red] {e.message}")
            raise typer.Exit(1)

    title = data.get("title", "export")
    entries = data.get("entries", [])
    total = data.get("totalEntries", len(entries))

    out_path = Path(output)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    if fmt == "csv":
        # Auto-adjust extension
        if out_path.suffix != ".csv":
            out_path = out_path.with_suffix(".csv")

        with open(out_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=["url", "label"])
            writer.writeheader()
            writer.writerows(entries)
    else:
        # JSON (default)
        if out_path.suffix != ".json":
            out_path = out_path.with_suffix(".json")

        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.write("\n")

    console.print(
        f'[green]✓[/green] Exported [bold]{total}[/bold] entries from "{title}" to [bold]{out_path}[/bold]'
    )
