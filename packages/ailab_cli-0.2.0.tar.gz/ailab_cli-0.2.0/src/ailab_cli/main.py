"""
ailab CLI — entry point.

Usage:
  ailab              → interactive TUI mode
  ailab auth login   → authenticate
  ailab auth logout  → remove credentials
  ailab auth status  → show current auth state
  ailab projects     → list projects
  ailab runs <id>    → list annotation runs
  ailab export ...   → export annotations
"""

from typing import Optional

import typer
from rich.console import Console

from ailab_cli.auth import auth_app
from ailab_cli.config import load_config

console = Console()

app = typer.Typer(
    name="ailab",
    help="AI Image Labeling Tool CLI — export annotations and more.",
    no_args_is_help=False,
    invoke_without_command=True,
    add_completion=False,
)

# Sub-commands
app.add_typer(auth_app, name="auth", help="Authentication commands.")


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    url: Optional[str] = typer.Option(
        None,
        "--url",
        help="API base URL (overrides config and AILAB_API_URL env var). Example: https://prelive.example.com",
    ),
) -> None:
    """Launch interactive mode when called without a sub-command."""
    # Store URL override in context for sub-commands
    ctx.ensure_object(dict)
    if url:
        ctx.obj["url"] = url

    if ctx.invoked_subcommand is None:
        from ailab_cli.interactive import run_interactive
        run_interactive(url_override=url)


@app.command()
def projects(ctx: typer.Context) -> None:
    """List all accessible projects."""
    from ailab_cli.projects import projects_command
    projects_command(url_override=ctx.obj.get("url") if ctx.obj else None)


@app.command()
def runs(
    ctx: typer.Context,
    project_id: str = typer.Argument(..., help="Project ID to list runs for."),
) -> None:
    """List annotation runs for a project."""
    from ailab_cli.runs import runs_command
    runs_command(project_id, url_override=ctx.obj.get("url") if ctx.obj else None)


@app.command(name="export")
def export_cmd(
    ctx: typer.Context,
    project_id: str = typer.Option(..., "--project", "-p", help="Project ID."),
    run_id: str = typer.Option(..., "--run", "-r", help="Annotation run ID."),
    output: str = typer.Option("./export.json", "--output", "-o", help="Output file path."),
    fmt: str = typer.Option("json", "--format", "-f", help="Output format: json or csv."),
) -> None:
    """Export annotations from an annotation run."""
    from ailab_cli.export import export_command
    export_command(
        project_id=project_id,
        run_id=run_id,
        output=output,
        fmt=fmt,
        url_override=ctx.obj.get("url") if ctx.obj else None,
    )


if __name__ == "__main__":
    app()
