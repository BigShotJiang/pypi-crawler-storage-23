from openbrowser.tools.service import Controller

__all__ = ['Controller']
