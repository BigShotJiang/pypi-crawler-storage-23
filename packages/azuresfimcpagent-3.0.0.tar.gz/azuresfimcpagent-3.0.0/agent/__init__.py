"""Azure deployment agent with NSP and Log Analytics orchestration."""

from agent.server import mcp, main

__all__ = ["mcp", "main"]
