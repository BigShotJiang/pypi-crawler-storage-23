"""Model activity — the real ``run_model_node`` implementation.

This replaces the stub in ``aor.workflows.activities`` when running
inside a model container.  It:
  1. Creates the output directory
  2. Maps input_paths to Path objects
  3. Calls ``model.infer(inputs, config)``
  4. Returns ``RunModelNodeOutput`` with real output paths
"""

from __future__ import annotations

import logging
from pathlib import Path

from temporalio import activity

from aor_model_sdk.base import ModelBase
from aor_model_sdk.types import RunModelNodeInput, RunModelNodeOutput

logger = logging.getLogger(__name__)


def make_model_activity(model: ModelBase):
    """Create a ``run_model_node`` activity bound to a loaded model instance.

    Returns an async function decorated with ``@activity.defn`` that
    delegates to ``model.infer()``.
    """

    @activity.defn(name="run_model_node")
    async def run_model_node(inp: RunModelNodeInput) -> RunModelNodeOutput:
        """Execute inference using the loaded model."""
        activity.logger.info(
            "run_model_node: job=%s node=%s model=%s@%s attempt=%d",
            inp.job_id,
            inp.node_id,
            inp.model_id,
            inp.model_version,
            inp.attempt,
        )

        # Build output directory
        out_dir = (
            Path(inp.artifact_root)
            / inp.job_id
            / "nodes"
            / inp.node_id
            / f"attempt-{inp.attempt}"
        )
        out_dir.mkdir(parents=True, exist_ok=True)

        # Set output_dir on the model so it can use self.output_dir
        model.output_dir = out_dir

        # Convert input_paths to Path objects
        inputs: dict[str, Path] = {
            name: Path(p) for name, p in inp.input_paths.items()
        }

        try:
            outputs = model.infer(inputs, inp.config)
        except Exception as exc:
            activity.logger.error("Model inference failed: %s", exc)
            return RunModelNodeOutput(
                node_id=inp.node_id,
                attempt=inp.attempt,
                success=False,
                error_message=str(exc),
            )

        # Build output_paths and output_types
        output_paths: dict[str, str] = {}
        output_types: dict[str, str] = {}
        for name, path in outputs.items():
            output_paths[name] = str(path)
            # Derive type from suffix — models should return proper paths
            output_types[name] = _guess_type(path)

        return RunModelNodeOutput(
            node_id=inp.node_id,
            attempt=inp.attempt,
            success=True,
            output_paths=output_paths,
            output_types=output_types,
        )

    return run_model_node


def _guess_type(path: Path) -> str:
    """Guess an output type string from file extension."""
    suffix_map = {
        ".json": "application/json",
        ".wav": "audio/wav",
        ".txt": "text/plain",
        ".csv": "text/csv",
    }
    return suffix_map.get(path.suffix.lower(), "application/octet-stream")
