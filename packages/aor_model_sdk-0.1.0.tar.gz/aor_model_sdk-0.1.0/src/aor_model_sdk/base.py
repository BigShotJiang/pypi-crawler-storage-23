"""ModelBase — abstract base class for model containers.

Each model implements two methods:
  - ``load()``: one-time setup (load weights, warm up, etc.)
  - ``infer(inputs, config) -> outputs``: per-activity inference
"""

from __future__ import annotations

import abc
from pathlib import Path
from typing import Any


class ModelBase(abc.ABC):
    """Base class every model container must subclass.

    Example::

        class LidModel(ModelBase):
            def load(self):
                self.model = load_weights("lid.pt")

            def infer(self, inputs, config):
                audio = inputs["audio"]
                result = self.model.predict(audio, **config)
                out = self.output_dir / "language_segments.json"
                out.write_text(json.dumps(result))
                return {"language_segments": out}
    """

    def __init__(self) -> None:
        self._output_dir: Path | None = None

    # ── Set by the SDK at activity invocation time ──────────────

    @property
    def output_dir(self) -> Path:
        """Directory where this activity invocation should write outputs.

        Set automatically by the SDK before ``infer()`` is called.
        Path: ``<artifact_root>/<job_id>/nodes/<node_id>/attempt-<N>/``
        """
        if self._output_dir is None:
            raise RuntimeError("output_dir not set — are you calling this outside an activity?")
        return self._output_dir

    @output_dir.setter
    def output_dir(self, value: Path) -> None:
        self._output_dir = value

    # ── Model lifecycle ─────────────────────────────────────────

    @abc.abstractmethod
    def load(self) -> None:
        """Called once at startup.  Load weights, warm up GPU, etc."""

    @abc.abstractmethod
    def infer(
        self,
        inputs: dict[str, Path],
        config: dict[str, Any],
    ) -> dict[str, Path]:
        """Run inference for a single activity.

        Parameters
        ----------
        inputs:
            Mapping of ``input_name`` → ``Path`` to the input artifact file.
        config:
            Node config dict from the compiled DAG.

        Returns
        -------
        Mapping of ``output_name`` → ``Path`` to the output artifact file.
        Every output declared in the contract must be present.
        """
