"""Shared dataclasses for Temporal activities.

These are the wire-format types serialised as JSON between the
orchestrator workflow and model workers.  They live in the SDK so
that model containers can be built **without** the full ``aor``
package.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class RunModelNodeInput:
    """Payload sent to a model worker activity.

    Serialised as JSON over the Temporal wire.
    """

    job_id: str
    node_id: str
    model_id: str
    model_version: str
    attempt: int
    artifact_root: str
    # Mapping of input_name → absolute path to the artifact file
    input_paths: dict[str, str] = field(default_factory=dict)
    config: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RunModelNodeOutput:
    """Result returned by a model worker activity.

    Contains the manifest produced by the worker so the workflow can
    update its internal state and unlock downstream nodes.
    """

    node_id: str
    attempt: int
    success: bool
    # output_name → artifact path (set on success)
    output_paths: dict[str, str] = field(default_factory=dict)
    # output_name → type string (set on success)
    output_types: dict[str, str] = field(default_factory=dict)
    error_message: str | None = None
