"""Model worker — starts HTTP server + Temporal worker.

This is the main entry point called by each model container.
It:
  1. Loads the contract JSON
  2. Instantiates and loads the model
  3. Starts the HTTP server (background thread)
  4. Starts the Temporal worker (foreground, blocks)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path
from typing import Any

from temporalio.client import Client
from temporalio.worker import Worker

from aor_model_sdk.activity import make_model_activity
from aor_model_sdk.base import ModelBase
from aor_model_sdk.http_server import start_http_server

logger = logging.getLogger(__name__)


def run_model_worker(
    model: ModelBase,
    contract_path: str | Path = "contract.json",
    *,
    http_host: str = "0.0.0.0",
    http_port: int = 8000,
    temporal_host: str | None = None,
    temporal_namespace: str = "default",
) -> None:
    """Start the model container runtime.

    This is the main function each model's ``__main__`` calls.

    Parameters
    ----------
    model:
        An instance of a ModelBase subclass.
    contract_path:
        Path to the contract.json file.
    http_host:
        Bind address for the HTTP server.
    http_port:
        Port for the HTTP server.
    temporal_host:
        Temporal server address.  Defaults to env ``AOR_TEMPORAL_HOST``
        or ``localhost:7233``.
    temporal_namespace:
        Temporal namespace.  Defaults to env ``AOR_TEMPORAL_NAMESPACE``
        or ``default``.
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # 1. Load contract
    contract_file = Path(contract_path)
    if not contract_file.exists():
        raise FileNotFoundError(f"Contract file not found: {contract_file}")

    contract: dict[str, Any] = json.loads(contract_file.read_text())
    task_queue = contract["task_queue"]
    model_id = contract["model_id"]
    version = contract["version"]
    logger.info("Contract loaded: %s@%s (queue=%s)", model_id, version, task_queue)

    # 2. Load the model
    logger.info("Loading model...")
    model.load()
    logger.info("Model loaded successfully")

    # 3. Start HTTP server in background
    http_port_env = os.environ.get("AOR_HTTP_PORT")
    if http_port_env:
        http_port = int(http_port_env)
    start_http_server(contract, host=http_host, port=http_port)

    # 4. Start Temporal worker (blocking)
    t_host = temporal_host or os.environ.get("AOR_TEMPORAL_HOST", "localhost:7233")
    t_ns = os.environ.get("AOR_TEMPORAL_NAMESPACE", temporal_namespace)

    activity_fn = make_model_activity(model)
    asyncio.run(_run_temporal_worker(activity_fn, t_host, t_ns, task_queue))


async def _run_temporal_worker(
    activity_fn: Any,
    host: str,
    namespace: str,
    task_queue: str,
) -> None:
    """Connect to Temporal and run the model worker."""
    logger.info("Connecting to Temporal at %s (namespace=%s)", host, namespace)
    client = await Client.connect(host, namespace=namespace)

    logger.info("Starting worker on queue %r", task_queue)
    worker = Worker(
        client,
        task_queue=task_queue,
        activities=[activity_fn],
    )
    await worker.run()
