"""AOR Model SDK — lightweight runtime for model containers.

Install with ``pip install aor-model-sdk`` — no need for the full
``aor`` CLI package.

Provides:
  - ``ModelBase``: abstract base class each model subclasses
  - ``run_model_worker()``: starts HTTP server + Temporal worker

Quick start::

    from aor_model_sdk import ModelBase, run_model_worker

    class MyModel(ModelBase):
        def load(self):
            ...
        def infer(self, inputs, config):
            ...

    if __name__ == "__main__":
        run_model_worker(MyModel(), contract_path="contract.json")
"""

from aor_model_sdk.base import ModelBase
from aor_model_sdk.worker import run_model_worker

__all__ = ["ModelBase", "run_model_worker"]
