"""HTTP server — serves /health and /contract for model containers.

Runs in a background thread so it doesn't block the Temporal worker.
"""

from __future__ import annotations

import json
import logging
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any

logger = logging.getLogger(__name__)


class _Handler(BaseHTTPRequestHandler):
    """HTTP handler serving /health and /contract from class-level dicts."""

    health_data: dict[str, Any] = {}
    contract_data: dict[str, Any] = {}

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            data = self.health_data
        elif self.path == "/contract":
            data = self.contract_data
        else:
            self.send_error(404)
            return

        body = json.dumps(data).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        """Route access logs through Python logging."""
        logger.debug(format, *args)


def start_http_server(
    contract: dict[str, Any],
    host: str = "0.0.0.0",
    port: int = 8000,
) -> HTTPServer:
    """Start the health/contract HTTP server in a daemon thread.

    Parameters
    ----------
    contract:
        Full contract dict (loaded from contract.json).
    host:
        Bind address.
    port:
        Port number.

    Returns
    -------
    The running HTTPServer instance (call ``.shutdown()`` to stop).
    """
    _Handler.health_data = {
        "status": "ok",
        "model_loaded": True,
        "model_id": contract["model_id"],
        "version": contract["version"],
    }
    _Handler.contract_data = contract

    server = HTTPServer((host, port), _Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    logger.info("HTTP server listening on %s:%d", host, port)
    return server
