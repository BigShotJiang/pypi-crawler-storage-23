from setuptools import setup, find_packages
setup(name='taftp', version='5.0.1', packages=find_packages())