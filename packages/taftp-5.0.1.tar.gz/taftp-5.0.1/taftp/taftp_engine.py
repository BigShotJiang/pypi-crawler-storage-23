import binascii, random, time, socket, requests, platform
from enum import Enum
from datetime import datetime
from typing import List, Dict, Optional, Any, Tuple
from rich.console import Console
from rich.panel import Panel

console = Console()

class TCPState(Enum):
    CLOSED = 0
    LISTEN = 1
    SYN_SENT = 2
    SYN_RECEIVED = 3
    ESTABLISHED = 4

class TAFTPPacket:
    """Структура пакета TAFTP/IP"""
    def __init__(self, flags: str, seq: int, ack: int, data: str = ""):
        self.flags = flags
        self.seq = seq
        self.ack = ack
        self.data = data
        self.signature = "TAFTP/1.0"

    def pack(self) -> str:
        """Инкапсуляция в сетевой фрейм"""
        header = f"{self.flags}|{self.seq}|{self.ack}|{self.data}"
        crc = hex(binascii.crc32(header.encode()) & 0xFFFFFFFF)
        return f"[{self.signature}]#{header}#{crc}"

    @staticmethod
    def unpack(raw_frame: str) -> Optional['TAFTPPacket']:
        """Декапсуляция и проверка CRC32"""
        try:
            parts = raw_frame.split("#")
            if len(parts) != 3: return None
            header_body = parts[1]
            received_crc = parts[2]
            if hex(binascii.crc32(header_body.encode()) & 0xFFFFFFFF) != received_crc:
                return None
            f, s, a, d = header_body.split("|", 3)
            return TAFTPPacket(f, int(s), int(a), d)
        except:
            return None

class TAFTPConnection:
    """Стек протокола TAFTP (аналог TCP)"""
    def __init__(self, mtu: int = 32):
        self.state = TCPState.CLOSED
        self.mtu = mtu
        self.seq_num = random.randint(1000, 5000)
        self.ack_num = 0

    def active_open(self, target_ip: str) -> str:
        """Шаг 1: [SYN]"""
        self.state = TCPState.SYN_SENT
        return TAFTPPacket("SYN", self.seq_num, 0).pack()

    def handle_syn(self, raw_frame: str) -> Optional[str]:
        """Шаг 2: [SYN] -> [SYN|ACK]"""
        p = TAFTPPacket.unpack(raw_frame)
        if p and "SYN" in p.flags:
            self.state = TCPState.SYN_RECEIVED
            self.ack_num = p.seq + 1
            return TAFTPPacket("SYN|ACK", self.seq_num, self.ack_num).pack()
        return None

    def handle_syn_ack(self, raw_frame: str) -> Optional[str]:
        """Шаг 3: [SYN|ACK] -> [ACK]"""
        p = TAFTPPacket.unpack(raw_frame)
        if p and "SYN" in p.flags and "ACK" in p.flags:
            if p.ack == self.seq_num + 1:
                self.state = TCPState.ESTABLISHED
                self.ack_num = p.seq + 1
                self.seq_num += 1
                return TAFTPPacket("ACK", self.seq_num, self.ack_num).pack()
        return None

    def establish_server(self, raw_frame: str):
        """Сервер принимает финальный ACK"""
        p = TAFTPPacket.unpack(raw_frame)
        if p and "ACK" in p.flags and not "SYN" in p.flags:
            self.state = TCPState.ESTABLISHED

    def send(self, data: str) -> List[str]:
        """Сегментация и отправка данных"""
        if self.state != TCPState.ESTABLISHED: return []
        chunks = [data[i:i+self.mtu] for i in range(0, len(data), self.mtu)]
        packets = []
        for c in chunks:
            packets.append(TAFTPPacket("PSH|ACK", self.seq_num, self.ack_num, c).pack())
            self.seq_num += len(c)
        return packets

    def receive(self, raw_frame: str) -> Tuple[bool, str, Optional[str]]:
        """Прием сегмента и генерация ACK"""
        p = TAFTPPacket.unpack(raw_frame)
        if not p: return False, "", None
        self.ack_num += len(p.data)
        ack_pkt = TAFTPPacket("ACK", self.seq_num, self.ack_num).pack()
        return True, p.data, ack_pkt

def test_protocol():
    """Встроенный диагностический тест"""
    c = Console()
    c.print(Panel("[bold cyan]TAFTP/IP STACK DIAGNOSTIC v5.0.1[/]", subtitle="Text and Files Transfer Protocol"))
    
    client = TAFTPConnection(mtu=16)
    server = TAFTPConnection(mtu=16)
    
    # 1. Handshake
    c.print("[yellow]Phase 1: Three-Way Handshake...[/]")
    p1 = client.active_open("127.0.0.1")
    p2 = server.handle_syn(p1)
    p3 = client.handle_syn_ack(p2)
    server.establish_server(p3)
    
    if client.state == server.state == TCPState.ESTABLISHED:
        c.print("[bold green]✔ Handshake OK. State: ESTABLISHED[/]")
    
    # 2. Data
    c.print("\n[yellow]Phase 2: Segmented Data Transfer...[/]")
    msg = "TAFTP is a reliable protocol."
    packets = client.send(msg)
    
    received = ""
    for i, p in enumerate(packets):
        ok, chunk, ack = server.receive(p)
        if ok:
            received += chunk
            c.print(f" [blue]Segment {i+1} received:[/] {chunk}")
            
    if received == msg:
        c.print(Panel("[bold white]ALL TESTS PASSED! CRC32 & SEQ OK.[/]", border_style="green"))