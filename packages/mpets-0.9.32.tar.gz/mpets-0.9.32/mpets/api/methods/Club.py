from typing import Union

from aiohttp import ClientResponse
from bs4 import BeautifulSoup
from loguru import logger

from mpets import models
from mpets.api.BaseApi import BaseApi
from mpets.api.methods.parsers import club_parser
from mpets.models.BaseResponse import BaseResponse
from mpets.models.club.ClubChat import ClubChat
from mpets.models.club.ClubChatMessage import ClubChatMessage


class Club:
    def __init__(self, base_api: BaseApi):
        self.base_api = base_api

    async def club(self, club_id, page) -> Union[models.Club, BaseResponse]:
        try:
            if club_id:
                params = {"id": club_id, "page": page}
            else:
                params = {"id": 0}
            club_inf: ClientResponse = await self.base_api.request(
                type="GET",
                method="/club",
                params=params,
            )
            url = str(club_inf.url)
            if "?id=" in url:
                club_id = club_parser.get_club_id(url=url)
                bs_content = BeautifulSoup(await club_inf.text(), "lxml")
                club_name = club_parser.get_club_name(bs_content=bs_content)
                about_club = club_parser.get_about_club(bs_content=bs_content)
                founded = club_parser.get_founded(bs_content=bs_content)
                level = club_parser.get_level(bs_content=bs_content)
                exp = club_parser.get_exp(bs_content=bs_content)
                build_level = club_parser.get_builds(bs_content=bs_content)
                player_amount = club_parser.get_player_amount(bs_content=bs_content)
                pets = club_parser.get_pets(bs_content=bs_content)
                return models.Club(
                    status=True,
                    is_club=True,
                    club_id=club_id,
                    name=club_name,
                    about=about_club,
                    founded=founded,
                    level=level,
                    exp=exp,
                    build_level=build_level,
                    pets_amount=player_amount,
                    pets=pets,
                )
            return BaseResponse(status=False, error=0, error_message="Клуб не найден")
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def want(self) -> Union[models.BooleanStatus, BaseResponse]:
        try:
            params = {"want": 1}
            await self.base_api.request(type="GET", method="/clubs", params=params)
            return models.BooleanStatus(status=True)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def accept_invite(self, club_id) -> Union[models.BooleanStatus, BaseResponse]:
        try:
            params = {"id": club_id}
            await self.base_api.request(type="GET", method="/accept_invite", params=params)
            return models.BooleanStatus(status=True)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def decline_invite(self, club_id) -> Union[models.BooleanStatus, BaseResponse]:
        try:
            params = {"id": club_id}
            await self.base_api.request(type="GET", method="/decline_invite", params=params)
            return models.BooleanStatus(status=True)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def enter_club(self, club_id, decline) -> Union[models.BooleanStatus, BaseResponse]:
        try:
            if decline is False:
                params = {"id": club_id, "yes": 1}
            else:
                params = {"id": club_id, "decline": 1}
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/enter_club",
                params=params,
            )
            invited_code = response.url.query.get("invited")
            logger.debug("invited code {}", invited_code)
            if invited_code is None:
                return BaseResponse(status=False, error=0, error_message="Ошибка отправки заявки")
            if invited_code == "1":
                return models.BooleanStatus(status=True)
            if invited_code == "2":
                return BaseResponse(status=False, error=0, error_message="Вы уже состоите в клубе")
            if invited_code == "3":
                return BaseResponse(
                    status=False,
                    error=0,
                    error_message="Вы уже отправляли в этот клуб заявку",
                )
            if invited_code == "4":
                return models.BooleanStatus(status=True)
            return BaseResponse(status=False, error=0, error_message="Ошибка отправки заявки")
        except Exception:
            return BaseResponse(
                status=False,
                error=0,
                error_message="Вы уже отправляли в этот клуб заявку",
            )

    async def create_club(self, name) -> Union[models.BooleanStatus, BaseResponse]:
        try:
            data = {"name": name}
            response: ClientResponse = await self.base_api.request(
                type="POST",
                method="/create_club",
                data=data,
            )
            bs_content = BeautifulSoup(await response.text(), "lxml")
            error_code = response.url.query.get("error")
            if error_code is not None:
                error_message = "Вы уже отправляли в этот клуб заявку"
                warning = bs_content.find("span", {"class": "warning"})
                if warning is not None and warning.text:
                    error_message = warning.text
                return BaseResponse(status=False, error=0, error_message=error_message)
            return models.BooleanStatus(status=True)
        except Exception:
            return BaseResponse(
                status=False,
                error=0,
                error_message="Вы уже отправляли в этот клуб заявку",
            )

    async def builds(self, club_id) -> Union[models.ClubBuilds, BaseResponse]:
        try:
            params = {"id": club_id}
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/builds",
                params=params,
            )
            bs_content = BeautifulSoup(await response.text(), "lxml")
            builds_list = []
            all_builds = club_parser.get_all_builds(bs_content=bs_content)
            for club_build in all_builds:
                improving = False
                build_name = club_parser.get_build_name(bs_content=club_build)
                build_type = club_parser.get_build_type(bs_content=club_build)
                current_level = club_parser.get_current_level(bs_content=club_build)
                max_level = club_parser.get_max_level(bs_content=club_build)
                build_bonus = club_parser.get_bonus(bs_content=club_build)

                left_time = club_parser.get_left_time(bs_content=club_build)
                if left_time is not None:
                    improving = True

                build_bonus = club_parser.get_fix_build_bonus_if_build_is_improving(
                    build_bonus=build_bonus
                )

                builds_list.append(
                    models.ClubBuild(
                        name=build_name,
                        type=build_type,
                        level=current_level,
                        max_level=max_level,
                        bonus=build_bonus,
                        improving=improving,
                        left_time=left_time,
                    )
                )
            hearts_bonus = club_parser.get_health_bonus(bs_content=bs_content)
            exp_bonus = club_parser.get_exp_bonus(bs_content=bs_content)
            club_level = club_parser.get_club_level(bs_content=bs_content)
            return models.ClubBuilds(
                status=True,
                level=club_level,
                hearts_bonus=hearts_bonus,
                exp_bonus=exp_bonus,
                builds=builds_list,
            )
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def club_budget(self, club_id: int) -> Union[models.ClubBudget, BaseResponse]:
        def parse_number(raw_value: str) -> int:
            number = "".join(char for char in raw_value if char.isdigit())
            if number == "":
                raise ValueError(f"Не удалось распарсить число: {raw_value}")
            return int(number)

        try:
            params = {"id": club_id}
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/club_budget",
                params=params,
            )
            response_text = await response.text()
            if "Копилка:" not in response_text:
                return BaseResponse(status=False, error=0, error_message="Копилка клуба не найдена")

            bs_content = BeautifulSoup(response_text, "lxml")
            budget_block = bs_content.find("div", {"class": "cntr"})
            if budget_block is None:
                return BaseResponse(
                    status=False,
                    error=0,
                    error_message="Блок копилки клуба не найден",
                )

            budget_values = budget_block.find_all("img", {"class": "price_img"})
            if len(budget_values) < 3:
                return BaseResponse(
                    status=False,
                    error=0,
                    error_message="Недостаточно данных в блоке копилки клуба",
                )
            coins = parse_number(str(budget_values[1].next_element))
            hearts = parse_number(str(budget_values[2].next_element))

            max_coins_block = bs_content.find("div", {"class": "p3 left"})
            if max_coins_block is None:
                return BaseResponse(
                    status=False,
                    error=0,
                    error_message="Блок лимита монет клуба не найден",
                )
            max_coins_values = max_coins_block.find_all("img", {"class": "price_img"})
            if len(max_coins_values) < 1:
                return BaseResponse(
                    status=False,
                    error=0,
                    error_message="Недостаточно данных в блоке лимита монет клуба",
                )
            max_coins_text = str(max_coins_values[0].next_element).split(": ")[-1]
            max_coins = parse_number(max_coins_text)

            return models.ClubBudget(
                status=True,
                coins=coins,
                hearts=hearts,
                max_coins=max_coins,
            )
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def club_history(self, club_id, type, page) -> Union[models.ClubHistory, BaseResponse]:
        try:
            params = {"id": club_id, "type": type, "page": page}
            history = []
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/club_history",
                params=params,
            )
            response_text = await response.text()
            bs_content = BeautifulSoup(response_text, "lxml")
            history_root = bs_content.find("div", {"class": "msg mrg_msg1 mt5 c_brown4"})
            if history_root is None:
                return models.ClubHistory(status=True, club_id=club_id, page=page, history=[])

            items = history_root.find_all("div", {"class": "mb2"})
            for history_item in items:
                try:
                    date = history_item.find("span", {"class": "c_gray"}).text
                    owner_id = int(history_item.find("a")["href"].split("=")[1])
                    owner_name = str(history_item.find("a").next_element)
                    member_id = int(history_item.find_all("a")[1]["href"].split("=")[1])
                    member_name = str(history_item.find_all("a")[1].next_element)
                    action = history_item.find_all("span")[1].text
                    history.append(
                        models.ClubHistoryItem(
                            owner_id=owner_id,
                            owner_name=owner_name,
                            member_id=member_id,
                            member_name=member_name,
                            action=action,
                            date=date,
                        )
                    )
                except Exception:
                    if "покинул клуб" in str(history_item):
                        owner_id = int(history_item.find("a")["href"].split("=")[1])
                        owner_name = str(history_item.find("a").next_element)
                        action = history_item.find_all("span")[1].text
                        history.append(
                            models.ClubHistoryItem(
                                owner_id=owner_id,
                                owner_name=owner_name,
                                member_id=None,
                                member_name=None,
                                action=action,
                                date=None,
                            )
                        )
            return models.ClubHistory(status=True, club_id=club_id, page=page, history=history)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def chat_message(self, club_id, message) -> Union[models.BooleanStatus, BaseResponse]:
        try:
            data = {"message_text": message, "club_id": club_id, "page": 1}
            await self.base_api.request(type="POST", method="/chat_message", data=data)
            return models.BooleanStatus(status=True)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def chat(self, club_id, page) -> Union[models.ClubChat, BaseResponse]:
        try:
            params = {"id": club_id, "page": page}
            messages = []
            response: ClientResponse = await self.base_api.request("GET", "/chat", params=params)
            response_text = await response.text()
            bs_content = BeautifulSoup(response_text, "lxml")
            pets = bs_content.find_all("div", {"class": "post_chat"})
            for pet in pets:
                message_deleted = False
                moderator_id = None
                pet_id = int(pet.find("a")["href"].split("=")[1])
                name = str(pet.find("a").next_element)
                try:
                    message = pet.find("span", {"class": "pet_msg"}).text
                except AttributeError:
                    message_deleted = True
                    moderator_href = pet.find("a", {"class": "gray_link"})["href"]
                    moderator_id = int(moderator_href.split("=")[1])
                    message = None
                try:
                    message_href = pet.find("a", {"class": "post_control"})["href"]
                    message_id = int(message_href.split("=")[1].split("&")[0])
                except Exception:
                    message_id = 0
                messages.append(
                    ClubChatMessage(
                        pet_id=pet_id,
                        name=name,
                        message_id=message_id,
                        message=message,
                        message_deleted=message_deleted,
                        moderator_id=moderator_id,
                    )
                )
            return ClubChat(
                status=True,
                error=None,
                error_message=None,
                club_id=club_id,
                page=page,
                messages=messages,
            )
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def build(self, club_id, type) -> Union[models.ClubBuildInfo, BaseResponse]:
        try:
            params = {"club_id": club_id, "type": type}
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/build",
                params=params,
            )
            bs_content = BeautifulSoup(await response.text(), "lxml")
            build_item = bs_content.find("div", {"class": "build_item"})
            if build_item is None:
                return BaseResponse(
                    status=False,
                    error=0,
                    error_message="Не удалось получить информацию о постройке",
                )

            name = build_item.find("span", {"class": "cup ib mt3 mb3"}).text
            name = name.replace("\r", "").replace("\n", "").replace("\t", "")
            bonus = build_item.find("div", {"class": "mb3"}).text
            bonus = bonus.replace("\r", "").replace("\n", "").replace("\t", "")
            level_info = build_item.find("span", {"class": "font_14 ib"}).text
            level = int(level_info.split(" ")[1].split(" ")[0])
            max_level = int(level_info.split("из ")[1])

            upgrade_coins = None
            upgrade_hearts = None
            fast_upgrade = None
            left_time = None
            if build_item.find("a", {"class": "bbtn mt5 mb5"}) is not None:
                if "Ускорить" in build_item.text:
                    fast_upgrade = int(
                        build_item.find("img", {"src": "/view/image/icons/coin.png"}).next_element
                    )
                    left_time = build_item.find("span", {"class": "c_green mar5t"}).text
                    left_time = left_time.split("Осталось ")[1]
                else:
                    upgrade_coins = int(
                        build_item.find("img", {"src": "/view/image/icons/coin.png"}).next_element
                    )
                    upgrade_hearts = int(
                        build_item.find("img", {"src": "/view/image/icons/heart.png"}).next_element
                    )

            return models.ClubBuildInfo(
                status=True,
                name=name,
                bonus=bonus,
                level=level,
                max_level=max_level,
                upgrade_coins=upgrade_coins,
                upgrade_hearts=upgrade_hearts,
                fast_upgrade=fast_upgrade,
                left_time=left_time,
            )
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def build_upgrade(self, club_id, type) -> Union[models.ClubBuildInfo, BaseResponse]:
        try:
            params = {"club_id": club_id, "type": type}
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/build_upgrade",
                params=params,
            )
            response_text = await response.text()
            if "Вам не хватает " in response_text:
                bs_content = BeautifulSoup(response_text, "lxml")
                warning = bs_content.find("span", {"class": "warning"})
                error_message = warning.text if warning is not None else None
                return BaseResponse(status=False, error=1, error_message=error_message)
            return await self.build(club_id=club_id, type=type)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def build_speed(self, club_id, type) -> Union[models.ClubBuildInfo, BaseResponse]:
        try:
            params = {"club_id": club_id, "type": type}
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/build_speed",
                params=params,
            )
            response_text = await response.text()
            if "Вам не хватает " in response_text:
                bs_content = BeautifulSoup(response_text, "lxml")
                warning = bs_content.find("span", {"class": "warning"})
                error_message = warning.text if warning is not None else None
                return BaseResponse(status=False, error=1, error_message=error_message)
            return await self.build(club_id=club_id, type=type)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def add_club_budget(self, coin, heart) -> Union[models.BooleanStatus, BaseResponse]:
        try:
            data = {"coin": coin, "heart": heart}
            await self.base_api.request(type="POST", method="/add_club_budget", data=data)
            return models.BooleanStatus(status=True)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def club_budget_history(
        self, club_id, sort, page
    ) -> Union[models.ClubBudgetHistory, BaseResponse]:
        try:
            params = {"id": club_id, "sort": sort, "page": page}
            players = []
            last_reset_pet_id = None
            last_reset_name = None
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/club_budget_history",
                params=params,
            )
            bs_content = BeautifulSoup(await response.text(), "lxml")
            container = bs_content.find("div", {"class": "wr_c4 left p10"})
            if container is None:
                return BaseResponse(
                    status=False,
                    error=0,
                    error_message="Не найден список участников истории копилки",
                )
            pets = container.find_all("div", {"class": "td_un"})
            for pet in pets:
                pet_id = int(pet.find("a")["href"].split("=")[1])
                name = str(pet.find("a").next_element)
                count = int(pet.text.split(": ")[1].replace("\t", ""))
                players.append(models.ClubBudgetHistoryPlayer(pet_id=pet_id, name=name, count=count))

            reset_wrapper = bs_content.find("div", {"class": "msg mrg_msg1 mt10 c_brown4"})
            if reset_wrapper is None:
                return BaseResponse(
                    status=False,
                    error=0,
                    error_message="Не найден блок последнего сброса",
                )
            reset_container = reset_wrapper.find("div", {"class": "wr_c4 td_un"})
            if reset_container is None:
                return BaseResponse(
                    status=False,
                    error=0,
                    error_message="Не найдено значение последнего сброса",
                )
            last_reset = (
                reset_container.text.replace("\n", "")
                .replace("\t", "")
                .replace("\r", "")
                .split(": ")[1]
            )
            last_reset = last_reset.split("(")[0]

            try:
                last_reset_pet_id = int(
                    reset_container.find("a", {"class": "club_member"})["href"].split("=")[1]
                )
                last_reset_name = (
                    reset_container.text.replace("\n", "")
                    .replace("\t", "")
                    .replace("\r", "")
                    .split(": ")[1]
                )
                last_reset_name = last_reset_name.split("(")[1].split(")")[0]
            except Exception:
                pass

            return models.ClubBudgetHistory(
                status=True,
                club_id=club_id,
                sort=sort,
                page=page,
                players=players,
                last_reset=last_reset,
                last_reset_pet_id=last_reset_pet_id,
                last_reset_name=last_reset_name,
            )
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def club_budget_history_all(
        self, club_id, sort, page
    ) -> Union[models.ClubBudgetHistoryAll, BaseResponse]:
        try:
            params = {"id": club_id, "sort": sort, "page": page}
            players = []
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/club_budget_history_all",
                params=params,
            )
            bs_content = BeautifulSoup(await response.text(), "lxml")
            container = bs_content.find("div", {"class": "wr_c4 left p10"})
            if container is None:
                return BaseResponse(
                    status=False,
                    error=0,
                    error_message="Не найден список участников истории копилки",
                )
            pets = container.find_all("div", {"class": "td_un"})
            for pet in pets:
                pet_id = int(pet.find("a")["href"].split("=")[1])
                name = str(pet.find("a").next_element)
                count = int(pet.text.split(": ")[1].replace("\t", ""))
                players.append(
                    models.ClubBudgetHistoryAllPlayer(pet_id=pet_id, name=name, count=count)
                )
            return models.ClubBudgetHistoryAll(
                status=True,
                club_id=club_id,
                sort=sort,
                page=page,
                players=players,
            )
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def forums(self, club_id) -> Union[models.ClubForums, BaseResponse]:
        try:
            params = {"id": club_id}
            forums_id = []
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/forum",
                params=params,
            )
            bs_content = BeautifulSoup(await response.text(), "lxml")
            threads = bs_content.find_all("div", {"class": "mbtn orange"})
            for forum in threads:
                forum_id = int(forum.find("a")["href"].split("=")[1])
                name = forum.text
                forums_id.append(models.ClubForumItem(forum_id=forum_id, name=name))
            return models.ClubForums(status=True, club_id=club_id, forums_id=forums_id)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def collection_changer(self) -> Union[models.BooleanStatus, BaseResponse]:
        try:
            await self.base_api.request(type="GET", method="/collection_changer")
            return models.BooleanStatus(status=True)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def collection_changer_select(
        self, type, collection_id
    ) -> Union[models.BooleanStatus, BaseResponse]:
        try:
            params = {"type": type, "id": collection_id}
            await self.base_api.request(
                type="GET",
                method="/collection_changer_select",
                params=params,
            )
            return models.BooleanStatus(status=True)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def reception(
        self, club_id, page, accept_id, decline_id, decline_all
    ) -> Union[models.ClubReception, BaseResponse]:
        try:
            accepted = None
            declined = None
            if accept_id is not None:
                accepted = False
                params = {"id": club_id, "page": page, "accept_id": accept_id}
            elif decline_id is not None:
                declined = False
                params = {"id": club_id, "page": page, "decline_id": decline_id}
            elif decline_all is not None:
                params = {"id": club_id, "page": page, "decline_all": decline_all}
            else:
                params = {"id": club_id, "page": page}

            members = []
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/reception",
                params=params,
            )
            response_text = await response.text()
            bs_content = BeautifulSoup(response_text, "lxml")
            table = bs_content.find("table", {"class": "ib table_p5 font_14"})
            rows = table.find_all("tr") if table is not None else []
            if accepted is False and "Заявка принята" in response_text:
                accepted = True
            if declined is False and "Заявка отклонена" in response_text:
                declined = True
            for member in rows:
                try:
                    level = int(member.find("img", {"class": "price_img"}).next_element)
                    pet_id = int(member.find("a")["href"].split("=")[1])
                    name = member.find("a").text
                    beauty = int(member.find("span", {"class": "nowrap"}).text)
                    members.append(
                        models.ClubReceptionMember(
                            level=level,
                            pet_id=pet_id,
                            name=name,
                            beauty=beauty,
                        )
                    )
                except Exception:
                    pass
            return models.ClubReception(
                status=True,
                club_id=club_id,
                page=page,
                members=members,
                accepted=accepted,
                declined=declined,
            )
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def club_hint_add(self, text: str) -> Union[models.BooleanStatus, BaseResponse]:
        try:
            data = {"text": text}
            await self.base_api.request(type="POST", method="/club_hint_add", data=data)
            return models.BooleanStatus(status=True)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def club_settings(self, club_id) -> Union[models.ClubSettings, BaseResponse]:
        try:
            params = {"id": club_id}
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/club_settings",
                params=params,
            )
            bs_content = BeautifulSoup(await response.text(), "lxml")
            wrapper = bs_content.find("div", {"class": "wr_c4"})
            items = wrapper.find_all("div", {"class": "mbtn"}) if wrapper is not None else []
            settings = []
            for item in items:
                name = item.find("a").text
                action_url = item.find("a")["href"]
                settings.append(models.ClubSettingsItem(name=name, action_url=action_url))
            return models.ClubSettings(status=True, settings=settings)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def gerb(self, club_id, gerb_id, yes) -> Union[models.ClubGerbs, BaseResponse]:
        try:
            if yes is not None:
                params = {"id": club_id, "gerb_id": gerb_id, "yes": yes}
            else:
                params = {"id": club_id}
            response: ClientResponse = await self.base_api.request(
                type="GET",
                method="/gerb",
                params=params,
            )
            bs_content = BeautifulSoup(await response.text(), "lxml")
            wrapper = bs_content.find("div", {"class": "wr_c4"})
            items = wrapper.find_all("a", {"class": "nd"}) if wrapper is not None else []
            gerbs = []
            for item in items:
                action_url = item["href"]
                gerbs.append(models.ClubGerbItem(action_url=action_url))
            return models.ClubGerbs(status=True, gerbs=gerbs)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def club_about(self) -> Union[models.ClubAbout, BaseResponse]:
        try:
            response: ClientResponse = await self.base_api.request(type="GET", method="/club_about")
            bs_content = BeautifulSoup(await response.text(), "lxml")
            about_area = bs_content.find("textarea", {"class": "thread_text"})
            if about_area is None:
                return BaseResponse(status=False, error=0, error_message="Описание клуба не найдено")
            return models.ClubAbout(status=True, about=about_area.text)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def club_about_action(self, about) -> Union[models.ClubAbout, BaseResponse]:
        try:
            data = {"about": about}
            response: ClientResponse = await self.base_api.request(
                type="POST",
                method="/club_about_action",
                data=data,
            )
            response_text = await response.text()
            response_url = str(response.url)
            bs_content = BeautifulSoup(response_text, "lxml")
            if "?result=1" in response_url:
                about_area = bs_content.find("textarea", {"class": "thread_text"})
                updated_about = about_area.text if about_area is not None else about
                return models.ClubAbout(status=True, about=updated_about)
            if "?result=" in response_url:
                warning = bs_content.find("span", {"class": "warning"})
                error_message = warning.text if warning is not None else "Не удалось изменить описание клуба."
                return BaseResponse(status=False, error=1, error_message=error_message)
            return BaseResponse(
                status=False,
                error=0,
                error_message="Не удалось изменить описание клуба.",
            )
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def club_rename(self) -> Union[models.ClubRename, BaseResponse]:
        try:
            response: ClientResponse = await self.base_api.request(type="GET", method="/club_rename")
            bs_content = BeautifulSoup(await response.text(), "lxml")
            input_name = bs_content.find("input", {"name": "name"})
            if input_name is None:
                return BaseResponse(
                    status=False,
                    error=0,
                    error_message="Не удалось получить название клуба",
                )
            return models.ClubRename(status=True, club=input_name.get("value", ""))
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def club_rename_action(self, name) -> Union[models.ClubRename, BaseResponse]:
        try:
            data = {"name": name}
            response: ClientResponse = await self.base_api.request(
                type="POST",
                method="/club_rename_action",
                data=data,
            )
            response_text = await response.text()
            response_url = str(response.url)
            if "?result=1" in response_url:
                return models.ClubRename(status=True, club=name)
            if "?result=" in response_url:
                bs_content = BeautifulSoup(response_text, "lxml")
                warning = bs_content.find("span", {"class": "warning"})
                error_message = warning.text if warning is not None else "Не удалось сменить название."
                return BaseResponse(status=False, error=1, error_message=error_message)
            return BaseResponse(status=False, error=0, error_message="Не удалось сменить название.")
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))

    async def leave_club(self) -> Union[models.BooleanStatus, BaseResponse]:
        try:
            params = {"confirm": 1, "clear": 1}
            await self.base_api.request(type="GET", method="/leave_club", params=params)
            return models.BooleanStatus(status=True)
        except Exception as ex:
            return BaseResponse(status=False, error=0, error_message=str(ex))
