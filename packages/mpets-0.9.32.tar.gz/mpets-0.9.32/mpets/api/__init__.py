from .MpetsApi import MpetsApi

from mpets.api.methods.Auth import Auth
from mpets.api.methods.Club import Club
from mpets.api.methods.Forum import Forum
from mpets.api.methods.Profile import Profile
from mpets.api.methods.Main import Main
from mpets.api.methods.Settings import Settings


