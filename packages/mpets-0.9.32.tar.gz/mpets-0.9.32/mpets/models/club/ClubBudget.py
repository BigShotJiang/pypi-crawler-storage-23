from mpets.models.BaseResponse import BaseResponse


class ClubBudget(BaseResponse):
    status: bool
    coins: int
    hearts: int
    max_coins: int
