from typing import Optional

from mpets.models.BaseResponse import BaseResponse


class ClubBuildInfo(BaseResponse):
    name: str
    bonus: str
    level: int
    max_level: int
    upgrade_coins: Optional[int]
    upgrade_hearts: Optional[int]
    fast_upgrade: Optional[int]
    left_time: Optional[str]
