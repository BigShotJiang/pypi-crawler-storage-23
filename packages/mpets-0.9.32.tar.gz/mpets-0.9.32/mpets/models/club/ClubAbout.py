from mpets.models.BaseResponse import BaseResponse


class ClubAbout(BaseResponse):
    about: str
