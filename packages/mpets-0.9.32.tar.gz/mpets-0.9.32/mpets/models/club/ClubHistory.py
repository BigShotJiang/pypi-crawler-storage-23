from typing import List, Optional

from pydantic import BaseModel

from mpets.models.BaseResponse import BaseResponse


class ClubHistoryItem(BaseModel):
    owner_id: int
    owner_name: str
    member_id: Optional[int]
    member_name: Optional[str]
    action: str
    date: Optional[str]


class ClubHistory(BaseResponse):
    club_id: int
    page: int
    history: List[ClubHistoryItem]
