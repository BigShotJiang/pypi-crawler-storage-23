from typing import List, Optional

from pydantic import BaseModel

from mpets.models.BaseResponse import BaseResponse


class ClubReceptionMember(BaseModel):
    level: int
    pet_id: int
    name: str
    beauty: int


class ClubReception(BaseResponse):
    club_id: int
    page: int
    members: List[ClubReceptionMember]
    accepted: Optional[bool]
    declined: Optional[bool]
