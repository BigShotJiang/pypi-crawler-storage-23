from mpets.models.BaseResponse import BaseResponse


class ClubRename(BaseResponse):
    club: str
