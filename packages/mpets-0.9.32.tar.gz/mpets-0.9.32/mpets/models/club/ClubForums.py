from typing import List

from pydantic import BaseModel

from mpets.models.BaseResponse import BaseResponse


class ClubForumItem(BaseModel):
    forum_id: int
    name: str


class ClubForums(BaseResponse):
    club_id: int
    forums_id: List[ClubForumItem]
