from typing import List

from pydantic import BaseModel

from mpets.models.BaseResponse import BaseResponse


class ClubGerbItem(BaseModel):
    action_url: str


class ClubGerbs(BaseResponse):
    gerbs: List[ClubGerbItem]
