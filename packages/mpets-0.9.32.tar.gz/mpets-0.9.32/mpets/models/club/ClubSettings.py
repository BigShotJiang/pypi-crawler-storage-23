from typing import List

from pydantic import BaseModel

from mpets.models.BaseResponse import BaseResponse


class ClubSettingsItem(BaseModel):
    name: str
    action_url: str


class ClubSettings(BaseResponse):
    settings: List[ClubSettingsItem]
