from typing import List, Optional

from pydantic import BaseModel

from mpets.models.BaseResponse import BaseResponse


class ClubBudgetHistoryPlayer(BaseModel):
    pet_id: int
    name: str
    count: int


class ClubBudgetHistory(BaseResponse):
    club_id: int
    sort: int
    page: int
    players: List[ClubBudgetHistoryPlayer]
    last_reset: str
    last_reset_pet_id: Optional[int]
    last_reset_name: Optional[str]
