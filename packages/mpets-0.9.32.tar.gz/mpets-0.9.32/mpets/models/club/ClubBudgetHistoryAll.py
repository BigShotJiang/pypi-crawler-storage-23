from typing import List

from pydantic import BaseModel

from mpets.models.BaseResponse import BaseResponse


class ClubBudgetHistoryAllPlayer(BaseModel):
    pet_id: int
    name: str
    count: int


class ClubBudgetHistoryAll(BaseResponse):
    club_id: int
    sort: int
    page: int
    players: List[ClubBudgetHistoryAllPlayer]
