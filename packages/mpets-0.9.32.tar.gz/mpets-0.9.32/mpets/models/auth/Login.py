from typing import Optional

from .Cookies import Cookies
from mpets.models.BaseResponse import BaseResponse


class Login(BaseResponse):
    status: bool
    pet_id: Optional[int] = None
    name: Optional[str] = None
    cookies: Optional[dict] = None
    cookie: Cookies
