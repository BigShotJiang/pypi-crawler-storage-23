from enum import Enum


class NicknameTypes(Enum):
    STANDARD = "standard"
    RANDOM = "randoom"
