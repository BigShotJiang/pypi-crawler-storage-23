from typing import List

from typing import List, Optional

from pydantic import BaseModel

from mpets.models.BaseResponse import BaseResponse


class GoldChestReward(BaseModel):
    pet_id: int
    name: str
    reward: str


class GoldChestResponse(BaseResponse):
    status: bool
    amount_keys: int
    rewards: List[GoldChestReward]


class OpenGoldChestResponse(BaseResponse):
    status: bool
    found: str
    text: Optional[str] = None
