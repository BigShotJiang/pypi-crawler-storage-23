from enum import Enum


class ChestItemTypes(Enum):
    KEY = 'key'
    LOCKBOX = 'lockbox'
    CLOTH = 'cloth'
    BOOK = 'book'
