import string
import random

from bs4 import BeautifulSoup


async def random_name(len: int = 10):
    # TODO сделать правдоподобную генерацию никнеймов
    return ''.join(random.sample(string.ascii_lowercase, k=len))


async def random_about():
    # TODO сделать правдоподобную генерацию анкет для аккаунта
    pass


async def random_string(len: int = 12):
    """
    Возвращает случайную строку длинной len.
    """
    return ''.join(random.sample(string.ascii_lowercase, k=len))


def html_has_link(html: str, href_substring: str) -> bool:
    """
    Проверяет, есть ли в HTML ссылка с href, содержащим подстроку.
    """
    soup = BeautifulSoup(html, "lxml")
    return soup.find("a", href=lambda h: h and href_substring == h) is not None


def html_has_text(html: str, text: str) -> bool:
    """
    Проверяет, есть ли в HTML искомый текст.
    """
    return text in html

