"""
Vector store configurations.
"""

from .qdrant import QdrantConfig

__all__ = [
    "QdrantConfig",
]
