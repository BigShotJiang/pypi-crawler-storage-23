# Dworshak  🌊

`dworshak` is a cross-platform credential and config management solution. 
There are options to manage encrypted cresentials, store plaintext config to JSON, or to leverage traditional Pythonic `.env` files.
`dworshak` is the CLI layer which allows your to edit and inspect values which you can also obtain programatically by using the wider `dworshak` ecosystem.

---

### Quick Start

```bash
# Install the CLI (for most environments)
pipx install "dworshak[crypto]"

# Bootstrap the security layer
dworshak setup

# Register your API credential
dworshak secret set "rjn_api"  "username"

# -> You will then be prompted, 
#    with the input characters securely hidden.

# Alternatively, if you want to have the option to hide/show the secret value without introducing it to console history,
# use the web or gui input
dworshak obtain secret "rjn_api" "password" --interface web 

```

---


```
dworshak helptree
```

<p align="center">
  <img src="https://raw.githubusercontent.com/City-of-Memphis-Wastewater/dworshak/main/assets/dworshak_v1.2.11_helptree.svg" width="100%" alt="Screenshot of the Dworshak CLI helptree">
</p> 

`helptree` is utility funtion for Typer CLIs, imported from the `typer-helptree` library.

- GitHub: https://github.com/City-of-Memphis-Wastewater/typer-helptree
- PyPI: https://pypi.org/project/typer-helptree/

---

<a id="sister-project-dworshak-secret"></a>

## Sister Projects in the Dworshak Ecosystem

* **CLI/Orchestrator:** [dworshak](https://github.com/City-of-Memphis-Wastewater/dworshak)
* **Interactive UI:** [dworshak-prompt](https://github.com/City-of-Memphis-Wastewater/dworshak-prompt)
* **Secrets Storage:** [dworshak-secret](https://github.com/City-of-Memphis-Wastewater/dworshak-secret)
* **Plaintext Pathed Configs:** [dworshak-config](https://github.com/City-of-Memphis-Wastewater/dworshak-config)
* **Classic .env Injection:** [dworshak-env](https://github.com/City-of-Memphis-Wastewater/dworshak-env)

```python
pipx install dworshak
pip install dworshak-secret
pip install dworshak-config
pip install dworshak-env
pip install dworshak-prompt

```

---

## 🏗  The Ultimate Vision
To become a stable credential management tool for scripting the flow of Emerson Ovation data and related APIs, supporting multiple projects in and beyond at the Maxson Wastewater Treatment Plant.

Furthermore, we want to offer Python developers a seamless configuration management experience that they can enjoy for years to come, on all of their devices. We especially love unlocking superuser gains and rollout in Termux environments.

**The Secret Sauce Behind** `dworshk-secret`: Use Industry-standard AES (Fernet) encryption  to manage a local `~/.dworshak/` directory which includes a `.key` file, a `vault.db` encrypted credential file, and a `config.json` file for controlling defaults.

<!--## ⚖️ User Stories-->

## 🚀 Attributes
- **Secure Vault:** Fernet-encrypted SQLite storage for API credentials.
- **Root of Trust:** A local `.key` file architecture that works identically on Windows and Termux.
- **CLI Entry:** A `typer`-based interface for setup and credential management.

---

## Bash Scripting

Use `dworshak` to prompt for Microsoft Fabric / Azure credentials

```
#!/usr/bin/env bash
set -euo pipefail

# Prompt human securely
SQL_PASSWORD=$(dworshak prompt ask \
  --message "Enter Fabric SQL password" \
  --hide)

# Push into Azure Key Vault
az keyvault secret set \
  --vault-name my-fabric-vault \
  --name sql-password \
  --value "$SQL_PASSWORD"

echo "Secret stored in Azure Key Vault"
```


Use `dworshak` to prompt for AWS credentials

```
#!/usr/bin/env bash
set -euo pipefail

# 1. Human-friendly prompt
DB_PASSWORD=$(dworshak prompt ask \
  --message "Enter production DB password" \
  --hide)

# 2. Push into AWS Secrets Manager
aws secretsmanager put-secret-value \
  --secret-id prod/db/password \
  --secret-string "$DB_PASSWORD"

echo "Secret stored in AWS Secrets Manager"
```

---

## Typical installation (macOS, Ubuntu, Windows 11, etc)

```
pipx install "dworshak[crypto]"
```

## Termux installation

```
pkg install python-cryptography
pipx install dworshak --system-site-packages
```

## iSH Apline installation

```
apk add py3-cryptography 
pipx install dworshak --system-site-packages

```


