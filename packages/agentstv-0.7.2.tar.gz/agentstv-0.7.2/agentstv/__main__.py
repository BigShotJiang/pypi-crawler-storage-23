"""Allow running as `python -m agentstv`."""

from .server import main

main()
