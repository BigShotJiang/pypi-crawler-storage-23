"""Allow running as: python -m idea_reality_mcp"""

from idea_reality_mcp import main

main()
