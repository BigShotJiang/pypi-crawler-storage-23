# ======================================================================================
#
#     Rapid Deep Neural Networks
#
#     Licensed under the MIT License
# ______________________________________________________________________________________
# ......................................................................................

# Copyright (c) 2018-2026 Pantelis I. Kaplanoglou

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# .......................................................................................
class Errors:
  MLSYS_NO_FILESYS = "No file system defined for the machine learning system. Create the object and assign the mlsys.filesys property."

ERR_MLSYS_FILESYS_NOT_INITIALIZED = "The filesystem for the Machine Learning host system has not been initialized."

MLSYS_MISSING_FRAMEWORK = "RaDDN requirest either torch or tensorflow to be installed."

HPARAMS_DATA_INPUT_DIMS = "Invalid dataset hyperparameters: The sample rank dimensions for the model's input tensor have not been defined."
HPARAMS_DATA_SAMPLE_DIMS = "Invalid dataset hyperparameters: You should specify the dimensions of the sample."


FILESTORE_DATAFILE_KIND_NOT_SUPPORTED = "Data file kind {%s} is not supported."
TRAINER_LR_SCHEDULER_INVALID_SETUP = "The learning rate scheduler step list is missing or invalid."
TRAINER_LR_SCHEDULER_INVALID_MILESTONE_SETUP = "The learning rate change milestone list is missing or invalid."
TRAINER_LR_SCHEDULER_UNSUPPORTED = "The learning rate scheduler %s is not supported."
TRAINER_LR_SCHEDULER_CHANGE_FACTOR_NOT_SET = "You need to set a decimal change factor for this learning rate scheduler."
NOT_IMPLEMENTED = "You should implement the %s method."


DATASET_FS_INVALID_CLASS_TYPE = "The parameter fs could be either a path, a filestore or a filesystem."
DATASET_FS_COULD_NOT_DETERMINE_FS = "Could not determine the filestore for the dataset."

MODEL_BUILDER_NOT_REGISTERED = "The model kind %s is not registered in the system."

FS_MUST_EXIST = "File store folder %s does not exist."

ERR_PLOT_IMAGE_SHOULD_BE_NUMPY = "The plot supports only ndarray images."
