from .dictionary import Dictionary

