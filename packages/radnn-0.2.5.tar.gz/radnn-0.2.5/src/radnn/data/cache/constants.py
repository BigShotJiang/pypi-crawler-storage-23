from enum import Enum

# =========================================================================================================================
class DataPurpose(Enum):
  SAMPLE_FEATURES = 0
  SAMPLE_LABELS = 1
  SAMPLE_IDS = 2


# =========================================================================================================================


# =========================================================================================================================
class DataCacheKind(Enum):
  GENERIC = 0
  
  VECTORS = 10
  VECTORS_LABELS = 11
  VECTORS_LABELS_IDS = 12
  
  TENSORS = 20
  TENSORS_LABELS = 21
  TENSORS_LABELS_IDS = 22
  
  TENSORS_LAST_AXIS_FEATURES = 30
  TENSORS_LAST_AXIS_FEATURES_LABELS = 31
  TENSORS_LAST_AXIS_FEATURES_LABELS_IDS = 32
# =========================================================================================================================