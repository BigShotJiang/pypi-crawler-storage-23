import numpy as np
from PIL import Image
from radnn.data.sample_set_simple import SampleSet
from radnn.data.sample_set_kind import SampleSetKind


class ImageSampleSet(SampleSet):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, parent_dataset, samples=None, labels=None, ids=None, kind: SampleSetKind | str = None):
    super().__init__(parent_dataset, samples, labels, ids, kind)
    self.pipeline = None
    self.are_features_on_last_axis = parent_dataset.are_features_on_last_axis
  # --------------------------------------------------------------------------------------------------------------------
  def transform(self, image):
    if image.dtype == object:
      image = image[0]
    
    if self.pipeline is not None:
      image = image.transpose((1,2,0)).astype(np.uint8).squeeze()
      oImg = Image.fromarray(image)
      tSample = self.pipeline(oImg)
    else:
      tSample = image

    return tSample
  # --------------------------------------------------------------------------------------------------------------------
  def sample_item(self, index):
    return self.transform(self.samples[index]), (self.labels[index].squeeze(), self.ids[index])
  # --------------------------------------------------------------------------------------------------------------------
  def __getitem__(self, index):
    return self.sample_item(index)
  # --------------------------------------------------------------------------------------------------------------------
  def _iter_unsupervised(self):
    for nIndex, nSample in enumerate(self.samples):
      tSample = self.transform(nSample)
      nId = self.ids[nIndex]
      yield tSample, (None, int(nId))
  # --------------------------------------------------------------------------------------------------------------------
  def _iter_supervised(self):
    for nIndex, nSample in enumerate(self.samples):
      yield self.sample_item(nIndex)
  # --------------------------------------------------------------------------------------------------------------------