# ======================================================================================
#
#     Rapid Deep Neural Networks
#
#     Licensed under the MIT License
# ______________________________________________________________________________________
# ......................................................................................

# Copyright (c) 2018-2026 Pantelis I. Kaplanoglou

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# .......................................................................................


class DataHyperparams(object):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, hprm: dict | None = None):
    self.hprm = hprm
    self.dataset_name = None
    self.dataset_fs_name = None
    self.fold_number = None
    self.class_count = 0
    self.sample_dims = None
  # --------------------------------------------------------------------------------------------------------------------
  @classmethod
  def from_dict(cls, hyperparams):
    '''
    Deserializes a hyperparameters object from a dictionary

    :param hyperparams: A dictionary containing the architectural hyperparameters for the model
    :return: a new model hyperparams object
    '''
    oModelHyperparams = DataHyperparams(hyperparams)
    oModelHyperparams.dataset_name = hyperparams.get("Dataset.Name", "?")
    oModelHyperparams.dataset_fs_name = oModelHyperparams.dataset_name.lower()
    oModelHyperparams.fold_number = hyperparams.get("Dataset.FoldNumber", 1)
    oModelHyperparams.class_count = hyperparams.get("Dataset.ClassCount", 0)
    oModelHyperparams.sample_dims = hyperparams.get("Dataset.SampleDims", 0)
    
    return oModelHyperparams
  # --------------------------------------------------------------------------------------------------------------------

