import numpy as np
from radnn.data.sample_set_kind import SampleSetKind
from radnn.data.structs import SampleSearchIndex


class SampleSet(object):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, parent_dataset, samples=None, labels=None, ids=None, kind: SampleSetKind | str = None):
    self.parent_dataset = parent_dataset
    self.samples = samples
    self.labels = labels
    self.ids = ids
    if self.ids is None:
      self.ids = np.arange(len(self.samples)) + 1
    self.kind: SampleSetKind = kind
    
    self.mean = None
    self.std = None
    
    self.loader = None
    self._sample_count = None
    self._minibatch_count = None
    self.ssi: SampleSearchIndex = SampleSearchIndex(self.ids, self.samples, self.labels,
                                                    self.parent_dataset.class_names)
  
  # --------------------------------------------------------------------------------------------------------------------
  def compute_stats(self, axis=-1):
    self.mean = self.samples.mean(axis=axis).tolist()
    self.std = (self.samples.std(axis=axis) + 1e-8).tolist()
  # --------------------------------------------------------------------------------------------------------------------
  def assign(self, samples, labels=None, ids=None):
    self.samples = samples
    self.labels = labels
    self.ids = ids
    if self.ids is None:
      self.ids = np.arange(len(self.samples)) + 1
    self.ssi = SampleSearchIndex(self.ids, self.samples)
    return self
  
  # --------------------------------------------------------------------------------------------------------------------
  @property
  def sample_count(self):
    if self._sample_count is None:
      self._sample_count = len(self.samples)
    return self._sample_count
  
  # --------------------------------------------------------------------------------------------------------------------
  @property
  def minibatch_count(self):
    if (self._minibatch_count is None) and (self.loader is not None):
      self._minibatch_count = len(self.loader)
    return self._minibatch_count
  
  # --------------------------------------------------------------------------------------------------------------------
  def __len__(self):
    return self.sample_count
  # --------------------------------------------------------------------------------------------------------------------
  def __getitem__(self, index):
    return self.samples[index], self.labels[index]
  # --------------------------------------------------------------------------------------------------------------------
  def __str__(self):
    sDescr = f"{self.kind:<17} samples: {self.sample_count:7d}  mini-batches: {self.minibatch_count}"
    return sDescr
  # --------------------------------------------------------------------------------------------------------------------
  def __repr__(self):
    return self.__str__()
  # --------------------------------------------------------------------------------------------------------------------
  def _iter_unsupervised(self):
    for nIndex, nSample in enumerate(self.samples):
      nId = self.ids[nIndex]
      yield nSample, int(nId)
  # --------------------------------------------------------------------------------------------------------------------
  def _iter_supervised(self):
    for nIndex, nSample in enumerate(self.samples):
      nLabel = self.labels[nIndex]
      nId = self.ids[nIndex]
      yield nSample, nLabel, int(nId)
  # --------------------------------------------------------------------------------------------------------------------
  def __iter__(self):
    if self.labels is None:
      return self._iter_unsupervised()
    else:
      return self._iter_supervised()
  
  # --------------------------------------------------------------------------------------------------------------------
  def print_info(self):
    sDescription = self.kind.name.lower().replace("_", " ")
    sDescription = sDescription[0].upper() + sDescription[1:]
    sMinibatches = ""
    if self.minibatch_count is not None:
      sMinibatches = f" minbatches: {self.minibatch_count}"
      
    sExtra = ""
    if (self.mean is not None) and (self.std is not None):
      sExtra = f"mean:{self.mean} std:{self.std}"
    if (self.samples is not None) and isinstance(self.samples, np.ndarray):
      print(f"  |__ {sDescription} samples: {self.sample_count}   shape: {self.samples.shape}{sMinibatches} {sExtra}")
    else:
      print(f"  |__ {sDescription} samples: {self.sample_count} {sMinibatches} {sExtra}")
    
    if (self.labels is not None) and isinstance(self.labels, np.ndarray):
      print(f"      |__ {sDescription} labels: {self.sample_count}   shape:{self.labels.shape}")
    else:
      print(f"      |__ {sDescription} labels: {self.sample_count}")
  # --------------------------------------------------------------------------------------------------------------------
# ======================================================================================================================
