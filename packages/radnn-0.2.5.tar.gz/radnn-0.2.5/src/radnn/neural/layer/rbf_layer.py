import torch
import torch.nn as nn


# ======================================================================================================================
class InitCentersSpaced:
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, min_val: float, max_val: float):
    self.min_val = float(min_val)
    self.max_val = float(max_val)
  
  # --------------------------------------------------------------------------------------------------------------------
  @torch.no_grad()
  def __call__(self, params: torch.Tensor) -> torch.Tensor:
    n = params.size(0)  # number of neurons / centers
    values = torch.linspace(
      self.min_val,
      self.max_val,
      steps=n,
      device=params.device,
      dtype=params.dtype
    )
    
    # Match TF behavior: (n, 1) then broadcast to full shape
    view_shape = [n] + [1] * (params.dim() - 1)
    values = values.view(*view_shape).expand_as(params)
    params.copy_(values)
    return params
  # --------------------------------------------------------------------------------------------------------------------
# ======================================================================================================================






# ======================================================================================================================
class RBFLayer(nn.Module):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, output_dim: int, initializer=None, sigmas: float = 1.0):
    super().__init__()
    self.output_dim = output_dim
    self.init_sigmas = float(sigmas)
    self.initializer = initializer  # optional callable, see reset_parameters
    
    # Parameters will be lazily initialized at the first input, when we infer the in_features (like Keras build()).
    self.centers = None
    self.sigmas = None
  
  # ------------------------------------------------------------------------------------------------------------------
  def init_params(self, in_features: int, device=None, dtype=None):
    self.centers = nn.Parameter(torch.empty(self.output_dim, in_features, device=device, dtype=dtype))
    
    self.sigmas = nn.Parameter(
      torch.full((self.output_dim,), self.init_sigmas, device=device, dtype=dtype)
    )
    if self.initializer is None:
      nn.init.uniform_(self.centers, a=0.0, b=1.0)
    else:
      # initializer should be callable(tensor) -> in-place fill
      self.initializer(self.centers)
  # ------------------------------------------------------------------------------------------------------------------
  def forward(self, x: torch.Tensor) -> torch.Tensor:
    if self.centers is None or self.sigmas is None:
      if x.dim() != 2:
        raise ValueError(f"Expected x to be 2D (batch, features). Got shape {tuple(x.shape)}")
      self.init_params(in_features=x.size(1), device=x.device, dtype=x.dtype)
    
    diff = x.unsqueeze(1) - self.centers.unsqueeze(0)
    dist2 = (diff ** 2).sum(dim=2)
    out = torch.exp(-dist2 / (self.sigmas.unsqueeze(0) ** 2))
    return out
  # ------------------------------------------------------------------------------------------------------------------
# ======================================================================================================================