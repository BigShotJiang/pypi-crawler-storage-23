# ======================================================================================
#
#     Rapid Deep Neural Networks
#
#     Licensed under the MIT License
# ______________________________________________________________________________________
# ......................................................................................
# Copyright (c) 2018-2026 Pantelis I. Kaplanoglou

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# .......................................................................................
import torch
import torch.nn as nn

'''
Implementation of the fourier features kernel

Tancik, Matthew, et al. "Fourier features let networks learn high frequency functions in low dimensional domains."
Advances in neural information processing systems 33 (2020): 7537-7547.
'''

# ======================================================================================================================
class FourierFeaturesRandom(nn.Module):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, frequencies, sigma=10.0):
    super().__init__()
    tFrequencies = torch.randn(frequencies) * sigma
    self.register_buffer("freqs", tFrequencies)
  # --------------------------------------------------------------------------------------------------------------------
  def forward(self, x):
    # (..., in_dim, 1) * (m,) -> (..., in_dim, m)
    tAngles = 2 * torch.pi * x.unsqueeze(-1) * self.freqs
    tGamma = torch.cat([torch.sin(tAngles), torch.cos(tAngles)], dim=-1)
    tGamma = tGamma.view(*x.shape[:-1], -1)
    return tGamma
  # --------------------------------------------------------------------------------------------------------------------
# ======================================================================================================================







# ======================================================================================================================
class FourierFeaturesLLSpaced(nn.Module):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, frequencies: int = 8.0, scale: float = 2.0):
    super().__init__()
    
    self.frequencies = frequencies
    self.scale = scale
    
    # Log-linearly spaced frequencies
    tExponents = torch.arange(frequencies, dtype=torch.float32) / self.frequencies
    tFrequencies = scale ** tExponents
    
    self.register_buffer("freqs", tFrequencies)
  
  # --------------------------------------------------------------------------------------------------------------------
  def forward(self, x: torch.Tensor) -> torch.Tensor:
    # (..., in_dim, 1) * (m,) -> (..., in_dim, m)
    tAngles = 2 * torch.pi * x.unsqueeze(-1) * self.freqs
    tGamma = torch.cat([torch.sin(tAngles), torch.cos(tAngles)], dim=-1)
    tGamma = tGamma.view(*x.shape[:-1], -1)
    return tGamma
  # --------------------------------------------------------------------------------------------------------------------
# ======================================================================================================================