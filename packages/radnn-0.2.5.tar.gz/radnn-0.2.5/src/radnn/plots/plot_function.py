# ======================================================================================
#
#     Rapid Deep Neural Networks
#
#     Licensed under the MIT License
# ______________________________________________________________________________________
# ......................................................................................

# Copyright (c) 2022-2026 Pantelis I. Kaplanoglou

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# .......................................................................................
import matplotlib.pyplot as plt



class PlotFunction(object):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, title=None):
    self.title = title
  # --------------------------------------------------------------------------------------------------------------------
  def prepare(self, x_series, y_series, title=None, linewidth=3.0):
    if title is not None:
      self.title = title
    plt.title(self.title)
    plt.plot(x_series, y_series, linewidth=linewidth)
    plt.xlabel("x")
    plt.ylabel("y")
    plt.axhline(
      y=0.0,  # y-value of the horizontal line
      linestyle='--',  # dashed line
      color='gray',
      linewidth=1.0
    )
    plt.axvline(
      x=0.0,
      linestyle='--',
      color='gray',
      linewidth=1.0
    )
    return self
  # --------------------------------------------------------------------------------------------------------------------
  def save(self, filename):
    plt.savefig(filename, bbox_inches='tight')
    return self
  # --------------------------------------------------------------------------------------------------------------------
  def show(self):
    plt.show()
  # --------------------------------------------------------------------------------------------------------------------
  
  