# ======================================================================================
#
#     Rapid Deep Neural Networks
#
#     Licensed under the MIT License
# ______________________________________________________________________________________
# ......................................................................................

# Copyright (c) 2022-2025 Pantelis I. Kaplanoglou

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# .......................................................................................
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colormaps

class MultiScatterPlot(object):
  # --------------------------------------------------------------------------------------
  # Constructor
  def __init__(self, title, data=None, class_count=10, class_names=None):
    # ................................................................
    # // Fields \\
    self.title = title
    self.data = data

    self.class_count = class_count
    if class_names is not None:
      self.class_names = class_names
      self.class_count = len(self.class_names)

    if (self.class_count <= 10):
      self.colormap = colormaps["tab10"]
    elif (self.class_count <= 20):
      self.colormap = colormaps["tab20"]
    else:
      self.colormap = colormaps["prism"]
      # self.ColorMap = colors.ListedColormap(["darkorange","darkseagreen"])

    self.plot_dimensions = [14, 8]
    self.point_size = 48
    self.panes_per_row = 2
    if self.data is not None:
      self.panes = len(self.data)

    self.__fig = None
    self.__ax = None
    # ................................................................

  # --------------------------------------------------------------------------------------
  def add_data(self, dataset_name, samples, labels=None):
    if self.data is None:
      self.data = []

    if labels is None:
      labels = np.zeros((samples.shape[0]), np.int32)
    self.data.append([dataset_name, samples, labels])
    self.panes = len(self.data)

  # --------------------------------------------------------------------------------------
  def prepare(self, index, x_axis_caption, y_axis_caption):

    # The 2D dataset for the scatter plot
    sDataName, nSamples, nLabels = self.data[index]
    nXValues = nSamples[:, 0]
    nYValues = nSamples[:, 1]
    nLabels = nLabels

    if self.__fig is None:
      if self.panes == 1:
        self.__fig, self.__ax = plt.subplots(nrows=1, ncols=1, sharex=False, sharey=False, squeeze=False,
                                             figsize=self.plot_dimensions)

      else:
        nRows = self.panes // self.panes_per_row
        if (self.panes % self.panes_per_row != 0):
          nRows += 1
        self.__fig, self.__ax = plt.subplots(nrows=nRows, ncols=self.panes_per_row, sharex=False, sharey=False,
                                             squeeze=False, figsize=self.plot_dimensions)
      self.__fig.suptitle(self.title)

    nRow = index // self.panes_per_row
    nCol = index - (nRow * self.panes_per_row)
    oPlot = self.__ax[nCol, nRow]
    oPlot.set_xlabel(x_axis_caption)
    oPlot.set_ylabel(y_axis_caption)
    oPlot.set_title(sDataName)

    oScatter = oPlot.scatter(nXValues, nYValues, s=self.point_size, c=nLabels, cmap=self.colormap)

    oLegend = oPlot.legend(*oScatter.legend_elements(), loc="lower right", title="Classes", framealpha=0.4,
                           labelspacing=0.1)
    oPlot.add_artist(oLegend)

    if index == self.panes - 1:
      plt.tight_layout(pad=1.01)

    return self
  # --------------------------------------------------------------------------------------
  def save(self, filename):
    plt.savefig(filename, bbox_inches='tight')
    return self
  # --------------------------------------------------------------------------------------
  def show(self):
    plt.show()
  # --------------------------------------------------------------------------------------
