from .plot_confusion_matrix import PlotConfusionMatrix
from .plot_learning_curve import PlotLearningCurve
from .plot_roc import PlotROC
from .plot_voronoi_2d import PlotVoronoi2D
from .plot_multi_scatter import MultiScatterPlot
from .plot_auto_multi_image import AutoMultiImagePlot
from .plot_function import PlotFunction
from .plot_histogram_of_classes import PlotHistogramOfClasses
from .plot_visualize_dataset2d import PlotVisualizeDataset2D
from .plot_legacy import CPlot, PlotDataset