import torch
from radnn.model import ModelBuildAdapter

class TorchModelBuildAdapter(ModelBuildAdapter):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, **kwargs):
    super().__init__(**kwargs)
  # --------------------------------------------------------------------------------------------------------------------
  def export_stem_weights(self):
    sPrefix = None
    dStem = {}
    for k, v in self.model.state_dict().items():
      if k.endswith(".weight") and (v.ndim == 4) and (len(dStem.keys()) == 0):
        print("*", end=None)
        dStem[k] = v.detach().cpu().numpy()
        
        sParts = k.split(".")
        if len(sParts) > 0:
          sPrefix = sParts[0]
      elif sPrefix is not None:
        if k.startswith(sPrefix) and k.endswith(".bias"):
          dStem[k] = v.detach().cpu().numpy()
          break
    
    for k, v in dStem.items():
      print(k, v.shape)
    
    return dStem
  # --------------------------------------------------------------------------------------------------------------------
  def import_stem_weights(self):
    bResult = self.stem_weights is not None
    if bResult:
      oStateDict = self.model.state_dict()
      
      for k, v in oStateDict.items():
        if k in self.stem_weights:
          oStateDict[k] = torch.from_numpy(self.stem_weights[k])
    return bResult
  # --------------------------------------------------------------------------------------------------------------------