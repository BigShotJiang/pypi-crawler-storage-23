import matplotlib.pyplot as plt
from radnn.system.filesystem import FileStore

class PlotBase(object):
  # --------------------------------------------------------------------------------------
  def save(self, filename: str, fs: FileStore = None):
    if fs is not None:
      filename = fs.file(filename)
    plt.savefig(filename, bbox_inches='tight')
    return self
  # --------------------------------------------------------------------------------------
  def show(self):
    plt.show()
  # --------------------------------------------------------------------------------------
