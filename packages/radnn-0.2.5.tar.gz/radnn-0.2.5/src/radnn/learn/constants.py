from enum import Enum

class MLTask(Enum):
  BINARY_CLASSIFICATION = 0
  MULTICLASS_CLASSIFICATION = 1
  REGRESSION = 2
  MULTIVARIATE_REGRESSION = 3
  CLUSTERING = 4
  INPUT_RECONSTRUCTION = 5
  RANKING = 6


class MLGenre(Enum):
  GENERIC = 0
  SUPERVISED = 1
  UNSUPERVISED = 2
  SELF_SUPERVISED = 3


def get_task_from_hyperparams(hyperparams: dict) -> MLTask:
  sTask = None
  if "Experiment.Task" in hyperparams:
    sTask = hyperparams["Experiment.Task"]
    
  oTask = None
  if sTask is not None:
    sTask = sTask.upper().replace(" ", "_")
    if sTask in MLTask.__members__:
      oTask = MLTask[sTask]
      
  return oTask