from typing import Optional
from torch.optim.lr_scheduler import LRScheduler, SequentialLR, ConstantLR, ReduceLROnPlateau
from radnn.errors import *




# ======================================================================================================================
class CompositeScheduler(list):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, optimizer, mode="minimize"):
    super().__init__()
    self.optimizer = optimizer
    self._epoch = 1
    self._selected_index = 0
    self.mode = mode
  # --------------------------------------------------------------------------------------------------------------------
  def choose_scheduler(self, epoch):
    raise NotImplementedError(NOT_IMPLEMENTED % "choose_scheduler")
  # --------------------------------------------------------------------------------------------------------------------
  @property
  def current(self):
    if self._selected_index >= 0:
      return self[self._selected_index]
    else:
      return None
  # --------------------------------------------------------------------------------------------------------------------
  def get_last_lr(self):
    bIsBasedOnMetrics, oScheduler = self.current
    return oScheduler.get_last_lr()
  # --------------------------------------------------------------------------------------------------------------------
  def step(self, metrics: dict | None =None):
    self._epoch += 1
    self._selected_index = self.choose_scheduler(self._epoch)
    bIsBasedOnMetrics, oScheduler = self.current
    if bIsBasedOnMetrics:
      nMetric = metrics[self.mode + "_metric"]
      oScheduler.step(nMetric)
    else:
      oScheduler.step()
  # --------------------------------------------------------------------------------------------------------------------

# ======================================================================================================================





# ======================================================================================================================
class StairCaseLR(LRScheduler):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, optimizer, setup, last_epoch=-1):
    self.setup = sorted(setup, key=lambda x: x[0])
    self.lrs = [nLR for nEpochIndex, nLR in self.setup]
    self.lrs_count = len(self.lrs)
    super().__init__(optimizer, last_epoch)
  # --------------------------------------------------------------------------------------------------------------------
  def get_lr(self):
    epoch = max(self.last_epoch, 0)
    
    lr = self.setup[0][1]
    for m, candidate_lr in self.setup:
      if epoch >= m:
        lr = candidate_lr
      else:
        break
    
    return [lr for _ in self.optimizer.param_groups]
  # --------------------------------------------------------------------------------------------------------------------
# ======================================================================================================================





    
    
# ======================================================================================================================
class ErrorPlateauWithWarmup(CompositeScheduler):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, optimizer, warmup_epochs=2, warmup_lr=0.1, base_lr=0.001, change_factor=0.1, patience=3, threshold=0.01):
    super().__init__(optimizer, "minimize")
    
    self.warmup_epochs = warmup_epochs
    self.warmup_lr = warmup_lr
    self.change_factor = change_factor
    self.patience = patience
    self.threshold = threshold
    self.base_lr = base_lr
    
    for group in self.optimizer.param_groups:
      group["lr"] = self.warmup_lr
      
    self.append(
        [ False, ConstantLR(optimizer, factor=1.0, total_iters=self.warmup_epochs)]
      )
    self.append(
        [True, ReduceLROnPlateau(optimizer,
                         factor=self.change_factor,
                         patience=self.patience,
                         mode = "min",
                         threshold_mode="abs",
                         threshold=self.threshold
                         )])
  

  # --------------------------------------------------------------------------------------------------------------------
  def choose_scheduler(self, epoch):
    if epoch <= self.warmup_epochs:
      return 0
    else:
      if epoch == self.warmup_epochs + 1:
        print(f"Epoch {epoch} switching to next scheduler")
        for group in self.optimizer.param_groups:
          group["lr"] = self.base_lr
      return 1
  # --------------------------------------------------------------------------------------------------------------------
# ======================================================================================================================






# ======================================================================================================================
class AccuracyPlateauWithWarmup(CompositeScheduler):
  # --------------------------------------------------------------------------------------------------------------------
  def __init__(self, optimizer, warmup_epochs=2, warmup_lr=0.1, base_lr=0.001, change_factor=0.1, patience=3,
               threshold=0.01):
    super().__init__(optimizer, "maximize")
    
    self.warmup_epochs = warmup_epochs
    self.warmup_lr = warmup_lr
    self.change_factor = change_factor
    self.patience = patience
    self.threshold = threshold
    self.base_lr = base_lr
    
    for group in self.optimizer.param_groups:
      group["lr"] = self.warmup_lr
    
    self.append(
      [False, ConstantLR(optimizer, factor=1.0, total_iters=self.warmup_epochs)]
    )
    self.append(
      [True, ReduceLROnPlateau(optimizer,
                               factor=self.change_factor,
                               patience=self.patience,
                               mode="max",
                               threshold_mode="abs",
                               threshold=self.threshold
                               )])
  
  # --------------------------------------------------------------------------------------------------------------------
  def choose_scheduler(self, epoch):
    if epoch <= self.warmup_epochs:
      return 0
    else:
      if epoch == self.warmup_epochs + 1:
        print(f"Epoch {epoch} switching to next scheduler")
        for group in self.optimizer.param_groups:
          group["lr"] = self.base_lr
      return 1
  # --------------------------------------------------------------------------------------------------------------------
# ======================================================================================================================

