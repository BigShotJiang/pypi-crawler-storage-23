# RaDNN - Rapid Deep Neural Networks

RaDNN is a library that aims to assist Machine Learning research and development, by minimizing the time needed for trivial functionality, streamlining experiments and standardizing the development of neural network models and datasets. It follows an object-oriented approach, employing software design patterns. 

## 🚀 Key Features

-   The notion of the `mlsystem` that is the sandbox of the ML Engineer / Data Scientist. 
-   In the `mlsystem` there is a central file store for `datasets`, a file store for `configs` of experiments and a file store for storing trained `models` along with the experiment artifacts.
-   Experiment reproducibility for `torch` and `tensorflow` , taking into account GPU non-determinism.
-   All hyperparameters for an experiment (architectural, data, training, ...) are organized in `json` configuration files, that are used as python dictionaries.
-   Allows for rapid development of file system related functionality. The class `FileStore` encapsulates the use of `os`, `shutil`, `pickle`, `json` and other packages that are trivial to the objective of the ML research and development process.
-   Follows a composition approach to rapidly develop custom Neural Network models. 
-   Layers are organized into *neural modules*, that are organized into *neural blocks*, that belong to an *encoder* / *decoder* part of the model.
-   Data are organized following hierarchical grouping to rapidly re-use samples in k-fold experiments.
-   The notion of dataset caches, speeds up the data feeding during training of models.
-   Library of image data pipeline method, support for image tensor standardization, and combos of image augmentation techniques.
-   Several classes for common plots that are deployed rapidly in comparison to custom `matplotlib`development.
-   Provides evaluator objects for calculating metrics. 

------------------------------------------------------------------------

## 📦 Installation

Install via pip:

``` bash
pip install radnn
```


------------------------------------------------------------------------

## 🧠 Quick Start

``` python
from radnn import mlsys, FileSystem
from radnn.plot import PlotImage

# Get the file store for the CIFAR10 dataset
mlsys.filesys = FileSystem(dataset_folder="/home/user/MLData")
fs = mlsys.filesys.datasets.subfs("CIFAR10")

# Deserialize the original sample set dictionary
dCIFAR10Test = fs.obj.load("test_batch", is_python2_format=True)
dCIFAR10ClassName = {0: "airplane", 1: "automobile", 2: "bird", 3: "cat", 4: "deer",
               5: "dog", 6: "frog", 7: "horse", 8: "ship", 9: "truck"}

# Get the first image, its label and the corresponding class, to create a title for the plot
nFirstImage = dCIFAR10Test["data"][0].reshape([-1, 3, 32, 32]).transpose([0, 2, 3, 1])
nFirstImageLabel = dCIFAR10Test["labels"][0]
sFirstImageClass = dCIFAR10ClassName[nFirstImageLabel]
sTitle = f"First image in CIFAR10 validation set is a {sFirstImageClass}"

# Show the image
PlotImage(nFirstImage, title=sTitle).prepare().show()
```
