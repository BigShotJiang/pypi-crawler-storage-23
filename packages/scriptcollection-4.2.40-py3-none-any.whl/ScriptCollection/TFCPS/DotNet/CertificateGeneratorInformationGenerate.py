from .CertificateGeneratorInformationBase import CertificateGeneratorInformationBase

class CertificateGeneratorInformationGenerate(CertificateGeneratorInformationBase):
    
    def generate_certificate(self)->bool:
        return True
