from datetime import datetime, timezone

from om_memory.models import Message, Observation, OMConfig
from om_memory.providers.base import LLMProvider
from om_memory.observability.callbacks import CallbackManager, OMEvent, EventType
from om_memory.token_counter import TokenCounter
from om_memory.prompts.observer_prompt import OBSERVER_SYSTEM_PROMPT
from om_memory.parsing import parse_observations


class Observer:
    """
    The Observer agent compresses raw conversation messages into observations.
    
    Key design: Only sends a compact summary of existing observations (not full text)
    plus only the NEW uncompressed messages to the LLM. This minimizes the token cost
    of each background compression call.
    """
    
    def __init__(self, provider: LLMProvider, config: OMConfig, token_counter: TokenCounter):
        self.provider = provider
        self.config = config
        self.token_counter = token_counter
        
    async def aobserve(
        self, 
        thread_id: str,
        messages: list[Message],
        existing_observations: list[Observation] = None,
        callbacks: CallbackManager = None,
        resource_id: str = None,
    ) -> list[Observation]:
        
        if callbacks:
            callbacks.emit(OMEvent(type=EventType.OBSERVER_STARTED, thread_id=thread_id, timestamp=datetime.now(timezone.utc), data={}))
            
        existing_observations = existing_observations or []
        
        # Build a ULTRA-COMPACT summary of existing observations — just key facts for dedup.
        if existing_observations:
            # Only last 5 observations, content only — minimal tokens for dedup
            recent = existing_observations[-5:]
            context_str = "; ".join([o.content for o in recent])
        else:
            context_str = "None"
            
        # Build the user prompt with only the messages to compress
        user_prompt = f"Existing context: {context_str}\n\nMessages:\n"
        for msg in messages:
            user_prompt += f"{msg.role}: {msg.content}\n"
            
        system_prompt = OBSERVER_SYSTEM_PROMPT
        
        input_tokens = self.token_counter.count(system_prompt + "\n" + user_prompt)

        try:
            llm_response = await self.provider.acomplete(system_prompt, user_prompt)
        except Exception as e:
            if callbacks:
                callbacks.emit(OMEvent(type=EventType.OBSERVER_ERROR, thread_id=thread_id, timestamp=datetime.now(timezone.utc), data={"error": str(e)}))
            return []
            
        output_tokens = self.token_counter.count(llm_response)
            
        # Parse observations using shared utility
        new_observations = parse_observations(
            llm_response, thread_id, [m.id for m in messages], resource_id=resource_id
        )
        
        if callbacks:
            callbacks.emit(OMEvent(
                type=EventType.OBSERVER_COMPLETED,
                thread_id=thread_id,
                timestamp=datetime.now(timezone.utc),
                data={
                    "messages_compressed": len(messages),
                    "observations_created": len(new_observations),
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens
                }
            ))
            
        return new_observations
