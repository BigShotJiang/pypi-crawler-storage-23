"""MCP server tests."""
