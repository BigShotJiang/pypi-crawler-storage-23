"""
Allow running elspais as a module: python -m elspais
"""

from elspais.cli import main

if __name__ == "__main__":
    main()
