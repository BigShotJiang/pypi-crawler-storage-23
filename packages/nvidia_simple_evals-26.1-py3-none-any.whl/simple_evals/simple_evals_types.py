from dataclasses import dataclass, field
from typing import Any
from simple_evals.custom_parametrization.config_loader import EvalConfig
from simple_evals.seed_generator import SeedGenerator
import json

Message = dict[str, Any]  # keys role, content
MessageList = list[Message]


class SamplerBase:
    """
    Base class for defining a sampling model, which can be evaluated,
    or used as part of the grading process.
    """

    def __call__(self, message_list: MessageList) -> str:
        raise NotImplementedError


@dataclass
class EvalResult:
    """
    Result of running an evaluation (usually consisting of many samples)
    """

    task_name: str  # task name (e.g. mgsm)
    score: float | None  # top-line metric
    metrics: dict[str, float] | None  # other metrics
    htmls: list[str]  # strings of valid HTML
    convos: list[MessageList]  # sampled conversations

    def to_dict(self) -> dict:
        return {
            "task_name": self.task_name,
            "score": self.score,
            "metrics": self.metrics,
            "htmls": self.htmls,
            "convos": self.convos,
        }

    def __str__(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_dict(cls, data: dict) -> "EvalResult":
        return cls(
            task_name=data["task_name"],
            score=data["score"],
            metrics=data["metrics"],
            htmls=data["htmls"],
            convos=data["convos"],
        )

    @classmethod
    def from_json(cls, json_str: str) -> "EvalResult":
        return cls.from_dict(json.loads(json_str))


@dataclass
class SingleEvalResult:
    """
    Result of evaluating a single sample
    """

    score: float | None
    metrics: dict[str, float] = field(default_factory=dict)
    html: str | None = None
    convo: MessageList | None = None  # sampled conversation

    def to_dict(self) -> dict:
        return {
            "score": self.score,
            "metrics": self.metrics,
            "html": self.html,
            "convo": self.convo,
        }

    def __str__(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_dict(cls, data: dict) -> "SingleEvalResult":
        return cls(
            score=data["score"],
            metrics=data.get("metrics", {}),
            html=data.get("html"),
            convo=data.get("convo"),
        )

    @classmethod
    def from_json(cls, json_str: str) -> "SingleEvalResult":
        return cls.from_dict(json.loads(json_str))


class Eval:
    """
    Base class for defining an evaluation.
    """

    def __init__(
        self,
        seed_generator: SeedGenerator | None = None,
        custom_eval_config: EvalConfig | None = None,
    ):
        self.seed_generator = seed_generator or SeedGenerator()
        self.custom_eval_config = custom_eval_config

    def prepare_examples(
        self,
        examples: list,
        num_examples: int | None = None,
        downsampling_ratio: float | None = None,
        first_n: int | None = None,
        n_repeats: int = 1,
        seed: int = 0
    ) -> list:
        """
        Comprehensive example preparation with sampling, limiting, and repeating.
        
        Operations are applied in this order:
        1. num_examples: Random sampling of N examples (with seed)
        2. downsampling_ratio: Random sampling by ratio (with seed)
        3. first_n: Limit to first N examples (deterministic)
        4. n_repeats: Repeat the final set M times
        
        Examples:
            # Random sampling
            prepare_examples(examples, num_examples=10, seed=42)
            → 10 random examples
            
            # Downsampling
            prepare_examples(examples, downsampling_ratio=0.1, seed=42)
            → 10% of examples randomly sampled
            
            # Limiting and repeating
            prepare_examples(examples, first_n=5, n_repeats=3)
            → [ex1..ex5, ex1..ex5, ex1..ex5] (5 examples × 3 repeats = 15 total)
            
            # Combined
            prepare_examples(examples, num_examples=100, first_n=10, n_repeats=2, seed=42)
            → Sample 100 → limit to 10 → repeat 2x = 20 total
        
        Args:
            examples: List of examples to prepare
            num_examples: Random sample this many examples (mutually exclusive with downsampling_ratio)
            downsampling_ratio: Random sample this fraction of examples (mutually exclusive with num_examples)
            first_n: Limit to first N examples (applied after sampling)
            n_repeats: Repeat examples this many times (applied last)
            seed: Random seed for reproducible sampling (default: 0)
            
        Returns:
            Prepared list of examples
            
        Raises:
            ValueError: If both num_examples and downsampling_ratio are specified
        """
        import random
        
        if num_examples is not None and downsampling_ratio is not None:
            raise ValueError("Cannot specify both num_examples and downsampling_ratio")
        
        # Step 1: Random sampling by count
        if num_examples is not None:
            if num_examples < len(examples):
                rng = random.Random(seed)
                examples = rng.sample(examples, num_examples)
        
        # Step 2: Random sampling by ratio
        if downsampling_ratio is not None:
            if downsampling_ratio < 1.0:
                target_count = max(1, int(len(examples) * downsampling_ratio))
                rng = random.Random(seed)
                examples = rng.sample(examples, target_count)
        
        # Step 3: Deterministic limit
        if first_n is not None:
            examples = examples[:first_n]
        
        # Step 4: Repeat
        if n_repeats > 1:
            # Structure: [ex1...exN, ex1...exN, ...] (n_repeats blocks)
            # This allows reshaping as (n_repeats, n_samples) for per-sample averaging
            examples = examples * n_repeats
        
        return examples

    async def __call__(self, sampler: SamplerBase) -> EvalResult:
        raise NotImplementedError
