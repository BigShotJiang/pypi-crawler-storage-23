# 🤖 DRF to Django Ninja Compiler

[![CI](https://github.com/lektronik/drf-to-ninja-compiler/actions/workflows/ci.yml/badge.svg)](https://github.com/lektronik/drf-to-ninja-compiler/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)

An intelligent, user-friendly compiler tool designed to automatically parse Django Rest Framework (DRF) code (`serializers.py`, `views.py`) and convert it into modern, fast Django Ninja equivalents (`schemas.py`, `api.py`).

Tired of manually migrating hundreds of legacy DRF endpoints? This tool automates the heavy lifting by leveraging Abstract Syntax Tree (AST) parsing to reverse-engineer your code.

## ✨ Features
- **Pydantic Schemas:** Parses DRF `ModelSerializer` and generates standard Ninja `ModelSchema`.
- **Intelligent Routing:** Parses DRF `APIView` and `ModelViewSet` and generates clean `@router` endpoints.
- **Human-in-the-Loop:** Automatically flags custom overrides (like `SerializerMethodField` or custom View methods) and injects helpful `TODO` comments so you know exactly what needs manual review.
- **Beautiful DX:** Powered by `Typer` and `Rich` for a stunning terminal experience.

## � Before & After

**Your legacy DRF code:**
```python
# serializers.py
class OrderSerializer(serializers.ModelSerializer):
    total = serializers.SerializerMethodField()

    class Meta:
        model = Order
        fields = ['id', 'status', 'total']

    def get_total(self, obj):
        return sum(item.price for item in obj.items.all())
```

**What the compiler generates:**
```python
# schemas.py (auto-generated)
class OrderSchema(ModelSchema):
    # ⚠️ HUMAN INTERVENTION REQUIRED:
    # The compiler detected custom fields or methods in the DRF Serializer:
    #  - total
    #  - method:get_total
    # You will need to manually map these to Pydantic types or Resolve() blocks.
    class Meta:
        model = Order
        fields = ['id', 'status', 'total']
```

**Your legacy DRF ViewSet:**
```python
# views.py
class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

    def list(self, request): ...
    def create(self, request): ...
```

**What the compiler generates:**
```python
# api.py (auto-generated)
@router.get('/order/', response=list[OrderSchema])
def list_order(request):
    """Automatically generated list view for OrderViewSet."""
    return Order.objects.all()

@router.post('/order/', response=OrderSchema)
def create_order(request, payload: OrderInSchema):
    """Automatically generated create view for OrderViewSet."""
    # TODO: Implement creation logic using payload.dict()
    pass
```

## �🚀 Installation

```bash
git clone https://github.com/lektronik/drf-to-ninja-compiler.git
cd drf-to-ninja-compiler
python3 -m venv venv
source venv/bin/activate
pip install -e .
```

## 🛠 Usage

Simply point the compiler at your existing DRF files:

```bash
# Compile both serializers and views simultaneously
drf2ninja --serializers myapp/serializers.py --views myapp/views.py

# Or just compile serializers
drf2ninja -s myapp/serializers.py
```

## 🔒 Security & Code Quality
This project uses `pre-commit` hooks to ensure code quality and security.
- **Formatting:** `black`
- **Security Analysis:** `bandit`

To set up the hooks locally:
```bash
pip install pre-commit
pre-commit install
```

## 🤝 Contributing
Pull requests are welcome. Make sure your changes pass the automated test suite:
```bash
pytest tests/
```
