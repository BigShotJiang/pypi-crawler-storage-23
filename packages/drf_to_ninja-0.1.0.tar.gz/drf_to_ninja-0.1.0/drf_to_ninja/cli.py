import sys
from pathlib import Path
import typer
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from rich.progress import Progress, SpinnerColumn, TextColumn

from drf_to_ninja.parsers.serializers import parse_serializers
from drf_to_ninja.generators.schemas import generate_schemas
from drf_to_ninja.parsers.views import parse_views
from drf_to_ninja.generators.routers import generate_routers

app = typer.Typer(
    name="drf2ninja",
    help="🤖 DRF to Django Ninja Compiler: Intelligently migrate your legacy APIs with a beautiful, user-friendly DX.",
    add_completion=False,
)
console = Console()


def display_code_panel(title: str, code: str, language: str = "python"):
    """Displays generated code beautifully with syntax highlighting."""
    syntax = Syntax(code, language, theme="monokai", line_numbers=True)
    panel = Panel(syntax, title=f"[cyan bold]{title}[/cyan bold]", border_style="cyan", expand=False)
    console.print(panel)


@app.command()
def compile(
    serializers: str = typer.Option(
        None, "--serializers", "-s", help="Path to the DRF serializers.py file to compile to Ninja Schemas."
    ),
    views: str = typer.Option(None, "--views", "-v", help="Path to the DRF views.py file to compile to Ninja Routers."),
):
    """
    Parses complex Django Rest Framework code and seamlessly outputs modern, fast Django Ninja code.
    """
    if not serializers and not views:
        console.print(
            Panel(
                "[bold red]Oops![/bold red] You need to provide something to compile.\n"
                "Try passing [cyan]--serializers path/to/serializers.py[/cyan] or [cyan]--views path/to/views.py[/cyan].",
                title="Authentication Error... wait, no just a user error",
                border_style="red",
            )
        )
        raise typer.Exit(code=1)

    console.print()
    console.print(Text("DRF to Ninja Compiler 🚀", style="bold green justify center"))
    console.print()

    # Compile Serializers
    if serializers:
        serializer_path = Path(serializers)
        if not serializer_path.exists():
            console.print(f"[bold red]File not found:[/bold red] {serializer_path}")
            raise typer.Exit(code=1)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            progress.add_task(
                description=f"Ingesting Serializers from [magenta]{serializer_path.name}[/magenta]...", total=None
            )

            try:
                # The heavy lifting
                serializers_data = parse_serializers(str(serializer_path))
                schema_code = generate_schemas(serializers_data)

            except Exception as e:
                console.print(f"[bold red]Fatal parsing error:[/bold red] {str(e)}")
                raise typer.Exit(code=1)

        display_code_panel("✨ Generated Pydantic Schemas", schema_code)

    # Compile Views
    if views:
        view_path = Path(views)
        if not view_path.exists():
            console.print(f"[bold red]File not found:[/bold red] {view_path}")
            raise typer.Exit(code=1)

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            progress.add_task(
                description=f"Reverse Engineering ViewSets from [magenta]{view_path.name}[/magenta]...", total=None
            )

            try:
                views_data = parse_views(str(view_path))
                router_code = generate_routers(views_data)
            except Exception as e:
                console.print(f"[bold red]Fatal parsing error:[/bold red] {str(e)}")
                raise typer.Exit(code=1)

        display_code_panel("⚡ Generated Ninja Routers", router_code)


def main():
    app()


if __name__ == "__main__":
    main()
