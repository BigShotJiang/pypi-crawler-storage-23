import pytest
from drf_to_ninja.parsers.serializers import parse_serializers
from drf_to_ninja.parsers.views import parse_views
from drf_to_ninja.generators.schemas import generate_schemas
from drf_to_ninja.generators.routers import generate_routers
import os

# ---------- Original fixture tests ----------


def test_serializer_parser():
    file_path = "tests/example_drf/serializers.py"
    if not os.path.exists(file_path):
        pytest.skip(f"Could not find example file at {file_path}")

    serializers = parse_serializers(file_path)

    assert len(serializers) == 3

    item_ser = next(s for s in serializers if s["name"] == "ItemSerializer")
    assert item_ser["model"] == "Item"
    assert item_ser["fields"] == ["id", "name", "description", "price"]
    assert not item_ser.get("needs_review")

    user_ser = next(s for s in serializers if s["name"] == "UserSerializer")
    assert user_ser["model"] == "'User'"
    assert user_ser["fields"] == "__all__"


def test_views_parser():
    file_path = "tests/example_drf/views.py"
    if not os.path.exists(file_path):
        pytest.skip(f"Could not find example file at {file_path}")

    views = parse_views(file_path)

    assert len(views) == 2

    api_view = next(v for v in views if v["name"] == "CustomAPIView")
    assert api_view["type"] == "APIView"
    assert "get" in api_view["methods"]
    assert "post" in api_view["methods"]
    assert api_view.get("needs_review") is not None

    viewset = next(v for v in views if v["name"] == "ItemViewSet")
    assert viewset["type"] == "ModelViewSet"
    assert viewset.get("queryset") is not None
    assert viewset.get("serializer_class") == "ItemSerializer"


# ---------- Real-world e-commerce fixture tests ----------


def test_ecommerce_serializer_custom_fields_detected():
    """Custom fields like SerializerMethodField should trigger needs_review."""
    file_path = "tests/example_drf/ecommerce_serializers.py"
    if not os.path.exists(file_path):
        pytest.skip(f"Could not find example file at {file_path}")

    serializers = parse_serializers(file_path)
    assert len(serializers) == 5

    order_ser = next(s for s in serializers if s["name"] == "OrderSerializer")
    assert order_ser["needs_review"] is True
    assert any("total" in cf for cf in order_ser["custom_fields"])
    assert any("validate_status" in cf for cf in order_ser["custom_fields"])


def test_ecommerce_simple_serializer_no_review():
    """A simple ModelSerializer with fields='__all__' should not need review."""
    file_path = "tests/example_drf/ecommerce_serializers.py"
    if not os.path.exists(file_path):
        pytest.skip(f"Could not find example file at {file_path}")

    serializers = parse_serializers(file_path)
    product_ser = next(s for s in serializers if s["name"] == "ProductSerializer")
    assert product_ser["fields"] == "__all__"
    assert not product_ser["needs_review"]


def test_ecommerce_viewset_custom_action_flagged():
    """Custom ViewSet methods like get_recent_orders should trigger needs_review."""
    file_path = "tests/example_drf/ecommerce_views.py"
    if not os.path.exists(file_path):
        pytest.skip(f"Could not find example file at {file_path}")

    views = parse_views(file_path)
    order_vs = next(v for v in views if v["name"] == "OrderViewSet")
    assert order_vs["needs_review"] is True
    assert "get_recent_orders" in order_vs["custom_methods"]


def test_ecommerce_apiview_multi_method():
    """An APIView with get, post, delete should parse all three methods."""
    file_path = "tests/example_drf/ecommerce_views.py"
    if not os.path.exists(file_path):
        pytest.skip(f"Could not find example file at {file_path}")

    views = parse_views(file_path)
    dashboard = next(v for v in views if v["name"] == "DashboardView")
    assert dashboard["type"] == "APIView"
    assert sorted(dashboard["methods"]) == ["delete", "get", "post"]


def test_schema_generation_contains_warning_comment():
    """Generated schemas should contain a warning comment when needs_review is True."""
    fake_data = [
        {
            "name": "OrderSerializer",
            "model": "Order",
            "fields": ["id", "status"],
            "custom_fields": ["total", "method:get_total"],
            "needs_review": True,
        }
    ]
    output = generate_schemas(fake_data)
    assert "HUMAN INTERVENTION REQUIRED" in output
    assert "total" in output
    assert "OrderSchema" in output


def test_router_generation_includes_docstrings():
    """Generated routers should include automatic docstrings."""
    fake_data = [
        {
            "name": "ProductViewSet",
            "type": "ModelViewSet",
            "methods": ["list", "create"],
            "queryset": "Product.objects.all()",
            "serializer_class": "ProductSerializer",
            "custom_methods": [],
            "needs_review": False,
        }
    ]
    output = generate_routers(fake_data)
    assert "def list_product" in output
    assert "def create_product" in output
    assert "Automatically generated" in output
    assert "ProductSchema" in output
