"""
    mposcli
    CLI helper for MicroPythonOS: https://github.com/MicroPythonOS/MicroPythonOS
"""

# See https://packaging.python.org/en/latest/specifications/version-specifiers/
__version__ = '0.3.0'
__author__ = 'Jens Diemer <cookiecutter_templates@jensdiemer.de>'
