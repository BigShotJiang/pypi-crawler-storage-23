from pathlib import Path

import mposcli


CLI_EPILOG = 'Project Homepage: https://github.com/jedie/mposcli'

BASE_PATH = Path(mposcli.__file__).parent
