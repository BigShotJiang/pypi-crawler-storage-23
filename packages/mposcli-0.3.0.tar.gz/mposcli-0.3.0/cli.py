#!/usr/bin/env python3

"""
`./cli.py` is for normal usage.
Just call this file, and the magic happens ;)

The `uv` tool is required to run the development CLI.

e.g.: Install `uv` via `pipx`
    apt-get install pipx
    pipx install uv
"""

import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path


assert sys.version_info >= (3, 12), f'Python version {sys.version_info} is too old!'


# Create and use  "/.venv-app/" for virtualenv:
VIRTUAL_ENV = '.venv-app'


def print_uv_error_and_exit():
    print('\nError: "uv" command not found in PATH. Please install "uv" first!\n')
    print('Hint:')
    print('\tapt-get install pipx\n')
    print('\tpipx install uv\n')
    sys.exit(1)


def verbose_check_call(*popen_args, **extra_env):
    print(f'\n+ {shlex.join(str(arg) for arg in popen_args)}\n')
    env = {
        'VIRTUAL_ENV': VIRTUAL_ENV,
        'UV_VENV': VIRTUAL_ENV,
        **os.environ,
        **extra_env,
    }
    return subprocess.check_call(
        popen_args,
        env=env,
        cwd=Path(__file__).parent,  # Needed if called from other working directory
    )


def main(argv):
    uv_bin = shutil.which('uv')  # Ensure 'uv' is available in PATH
    if not uv_bin:
        print_uv_error_and_exit()

    if not Path(VIRTUAL_ENV).is_dir():
        verbose_check_call(uv_bin, 'venv', VIRTUAL_ENV)

    # Call our entry point CLI:
    try:
        verbose_check_call(uv_bin, 'run', '--active', '-m', 'mposcli', *argv[1:])
    except subprocess.CalledProcessError as err:
        sys.exit(err.returncode)
    except KeyboardInterrupt:
        print('Bye!')
        sys.exit(130)


if __name__ == '__main__':
    main(sys.argv)
