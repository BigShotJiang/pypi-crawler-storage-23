import logging
import os

try:
    import sentry_sdk
except Exception:
    sentry_sdk = None

from eptools.configuration import *


def reloadconfig(func):
    def wrap(*args, **kwargs):
        setglobals(globals())
        getglobals_new_globals = getglobals()
        globals().update(getglobals_new_globals)
        func_new_globals = func(*args, **kwargs)
        after_func_new_globals = getglobals()
        # keep own globals rather than getglobals after func
        after_func_new_globals.update(globals())
        globals().update(after_func_new_globals)
        return func_new_globals
    return wrap


loadconfigwithfile = reloadconfig(loadconfigwithfile)
loadconfigwithjson = reloadconfig(loadconfigwithjson)


class SentryFactory:
    @reloadconfig
    def __init__(self, config_path=None, logger=None) -> None:
        loadconfigwithfile(config_path)
        self.logger = logger if logger else logging.getLogger(__name__)
        self.initialized = False

        if sentry_sdk is None:
            return

        dsn = os.environ.get('SENTRY_DSN') or globals().get('C_SENTRY_DSN')
        if not dsn:
            return

        try:
            if sentry_sdk.Hub.current.client is None:
                sentry_sdk.init(
                    dsn=dsn,
                    traces_sample_rate=float(os.environ.get('SENTRY_TRACES_SAMPLE_RATE', '0.0')),
                    send_default_pii=False,
                )
            self.initialized = True
        except Exception as ex:
            self.logger.error(str(ex))

    def log(self, logger_name, message='', error='UnknownError', level='error'):
        if not self.initialized or sentry_sdk is None:
            return {"ok": False}

        try:
            with sentry_sdk.push_scope() as scope:
                scope.set_tag('logger_name', logger_name)
                if error:
                    scope.set_extra('error_summary', error)
                sentry_sdk.capture_message(message if message else str(error), level=level)
            return {"ok": True}
        except Exception as ex:
            self.logger.error(str(ex))
            return {"ok": False}

    def capture_exception(self, logger_name, ex: Exception):
        if not self.initialized or sentry_sdk is None:
            return {"ok": False}

        try:
            with sentry_sdk.push_scope() as scope:
                scope.set_tag('logger_name', logger_name)
                sentry_sdk.capture_exception(ex)
            return {"ok": True}
        except Exception as sentry_ex:
            self.logger.error(str(sentry_ex))
            return {"ok": False}


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    test_logger = logging.getLogger("sentry_factory_main_test")

    print("Running SentryFactory __main__ tests")

    # Test 1: construction
    try:
        sentry_factory = SentryFactory(logger=test_logger)
        print(f"TEST 1 - init: OK (initialized={sentry_factory.initialized})")
    except Exception as ex:
        print("TEST 1 - init: FAIL", ex)
        raise

    # Test 2: message capture smoke test
    try:
        res = sentry_factory.log(
            logger_name="SentryFactoryMain",
            message="SentryFactory __main__ message test",
            error="MainMessageTest",
            level="warning",
        )
        print("TEST 2 - log: OK", res)
    except Exception as ex:
        print("TEST 2 - log: FAIL", ex)

    # Test 3: exception capture smoke test
    try:
        try:
            raise ValueError("SentryFactory __main__ exception test")
        except Exception as inner_ex:
            res = sentry_factory.capture_exception("SentryFactoryMain", inner_ex)
            print("TEST 3 - capture_exception: OK", res)
    except Exception as ex:
        print("TEST 3 - capture_exception: FAIL", ex)
