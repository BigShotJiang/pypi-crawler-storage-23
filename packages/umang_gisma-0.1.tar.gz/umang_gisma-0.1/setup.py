from setuptools import setup, find_packages

setup(
name="umang_gisma", # Your package name
version="0.1", # Version number
packages=find_packages(), # Automatically find packages
install_requires=[], # List dependencies if any
author="umang", # Your name
author_email="umang18.work@gmail.com",# Your email
description="Description v1",
url="https://github.com/Umang-Gisma/M504D", # Your project URL
)