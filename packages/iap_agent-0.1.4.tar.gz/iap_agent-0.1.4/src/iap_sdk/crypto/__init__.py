"""Cryptographic helpers used by the IAP SDK."""
