"""
Replace in File 子模块

提供文件替换功能的核心组件：
- parsing: diff 解析（单文件/多文件）
- apply: 替换执行与回退策略
- failure_report: 失败分析与结构化报告
- paths: 路径安全策略
"""

from .parsing import (
    SearchReplaceBlock,
    MultiFileEdit,
    parse_search_replace_blocks,
    parse_search_replace_blocks_as_tuples,
    parse_multi_file_edits,
    parse_multi_file_edits_as_tuples,
    find_line_numbers,
    SEARCH_MARKER,
    DIVIDER_MARKER,
    REPLACE_MARKER,
)

from .apply import (
    ApplyResult,
    ReplaceApplier,
    apply_replacements,
    apply_replacements_simple,
)

from .failure_report import (
    ReplacementFailureBlockAnalysis,
    ReplacementFailureReport,
    analyze_search_block_similarity,
    generate_common_suggestions,
    build_failure_report,
    format_failure_summary,
    format_failure_message_detailed,
    report_to_content_dict,
    build_multi_file_failure_content,
)

from .paths import (
    PathValidationResult,
    PathPolicy,
    resolve_file_path,
    is_path_within_directory,
    is_in_plans_directory,
    validate_file_path,
    validate_multiple_file_paths,
    get_plans_directory,
    ensure_plans_directory_exists,
)

__all__ = [
    # parsing
    "SearchReplaceBlock",
    "MultiFileEdit",
    "parse_search_replace_blocks",
    "parse_search_replace_blocks_as_tuples",
    "parse_multi_file_edits",
    "parse_multi_file_edits_as_tuples",
    "find_line_numbers",
    "SEARCH_MARKER",
    "DIVIDER_MARKER",
    "REPLACE_MARKER",
    # apply
    "ApplyResult",
    "ReplaceApplier",
    "apply_replacements",
    "apply_replacements_simple",
    # failure_report
    "ReplacementFailureBlockAnalysis",
    "ReplacementFailureReport",
    "analyze_search_block_similarity",
    "generate_common_suggestions",
    "build_failure_report",
    "format_failure_summary",
    "format_failure_message_detailed",
    "report_to_content_dict",
    "build_multi_file_failure_content",
    # paths
    "PathValidationResult",
    "PathPolicy",
    "resolve_file_path",
    "is_path_within_directory",
    "is_in_plans_directory",
    "validate_file_path",
    "validate_multiple_file_paths",
    "get_plans_directory",
    "ensure_plans_directory_exists",
]
