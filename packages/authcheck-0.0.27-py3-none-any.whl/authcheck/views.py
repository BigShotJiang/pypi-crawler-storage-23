"""App Views"""

# Django
from django.contrib.auth.decorators import login_required, permission_required
from django.core.handlers.wsgi import WSGIRequest
from django.http import HttpResponse
from django.shortcuts import render
from .utils.helpers.aahelpers import AaHelper
from .utils.forms.checkuserform import CheckCharactersForm
from .utils.models.character import Character
from corptools.api.character.status import StatusApiEndpoints
from corptools import app_settings, models
from allianceauth.eveonline.models import EveCharacterManager



@login_required
@permission_required("authcheck.basic_access")

def index(request: WSGIRequest) -> HttpResponse:
    if request.method == 'GET':
        return render(request, "authcheck/index.html")
    else:
        return dispatch_post(request)

def dispatch_post(request: WSGIRequest) -> HttpResponse:
    check_form = CheckCharactersForm(request.POST)
    if not check_form or not check_form.is_valid():
        return render(request,"authcheck/index.html",{"isCheckResult":False})
    
    known_characters = []
    unknown_characters = []
    validation_list = []
    
    for character in check_form.characters_list:
        validation_list.append(character)
        charFromAuth = AaHelper.GetCharacter(character.strip())
        if charFromAuth is None:
            unknown_characters.append(character.strip())
        else:
            known_characters.append(Character(charFromAuth))
        
    
    unknown_characters = sorted(unknown_characters, key=lambda char: char)
    known_characters = sorted(known_characters, key=lambda char: (char.verified, char.nick_name))
    
    return render(request, "authcheck/index.html", {"checks": validation_list , "unknown_characters": unknown_characters, "known_characters": known_characters, "isCheckResult": True})