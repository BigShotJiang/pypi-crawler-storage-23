from allianceauth.eveonline.models import EveCharacter

class AaHelper:
    def GetCharacter(name):
        try:
            #EveCharacter.objects.get(character_name=name)
            return EveCharacter.objects.get(character_name=name)
        except EveCharacter.DoesNotExist:
            return None
        except Exception as e:
            # Логируем другие исключения для отладки
            print(f"Error in CharacterExist: {e}")
            return None