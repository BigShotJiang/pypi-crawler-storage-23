"""App Configuration"""

# Django
from django.apps import AppConfig

# AA AuthCheck App
from . import __version__


class AuthCheckConfig(AppConfig):
    """App Config"""

    name = "authcheck"
    label = "authcheck"
    verbose_name = f"Auth Checker App v{__version__}"
    default_permissions = "authcheck.basic_access"
