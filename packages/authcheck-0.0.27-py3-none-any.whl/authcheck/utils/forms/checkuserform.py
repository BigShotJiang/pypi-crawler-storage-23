
from django.http import QueryDict


class CheckCharactersForm:
    def __init__(self, post : QueryDict):
        list = [char.strip() for char in post.get('charslist',"").splitlines()]
        self.characters_list = [line for line in list if len(line.strip()) > 0]
    def is_valid(self) -> bool: 
        return len(self.characters_list) > 0