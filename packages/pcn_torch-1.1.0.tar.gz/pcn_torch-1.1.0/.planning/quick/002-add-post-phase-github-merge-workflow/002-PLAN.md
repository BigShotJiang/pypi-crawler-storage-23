---
type: quick
task: 002
autonomous: true
---

<objective>
Document the post-phase GitHub merge workflow in .planning/WORKFLOW.md.
</objective>

<tasks>
<task type="auto">
  <name>Create WORKFLOW.md with merge procedure</name>
  <files>.planning/WORKFLOW.md</files>
  <action>Create workflow doc covering: push branch, create PR, wait for CI, merge, delete branch, branch naming, ruleset config.</action>
  <done>WORKFLOW.md exists with complete merge procedure.</done>
</task>
</tasks>
