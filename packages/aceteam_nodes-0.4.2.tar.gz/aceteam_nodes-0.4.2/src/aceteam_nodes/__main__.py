"""Allow running as: python -m aceteam_nodes.cli"""

from .cli import main

main()
