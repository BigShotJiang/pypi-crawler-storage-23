from jailrun.cmd.console import console as console
from jailrun.cmd.down import down as down
from jailrun.cmd.purge import purge as purge
from jailrun.cmd.ssh import ssh as ssh
from jailrun.cmd.start import start_vm as start_vm
from jailrun.cmd.status import status as status
from jailrun.cmd.stop import stop_vm as stop_vm
from jailrun.cmd.up import up as up
