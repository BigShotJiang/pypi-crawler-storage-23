import time
from typing import Dict, Any
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.layout import Layout
from rich.align import Align
from rich.tree import Tree

from gemini_subagent.infrastructure.session import SessionManager
from gemini_subagent.core.models import AgentState

console = Console()

def generate_header() -> Panel:
    """Creates a header for the dashboard."""
    grid = Table.grid(expand=True)
    grid.add_column(justify="center", ratio=1)
    grid.add_column(justify="right")
    grid.add_row(
        Text("SUBGEMI OPERATIONAL DASHBOARD", style="bold white on blue"),
        Text(time.strftime("%Y-%m-%d %H:%M:%S"), style="dim"),
    )
    return Panel(grid, style="blue")


def generate_summary(data: Dict[str, Any]) -> Panel:
    """Creates a summary panel with stats."""
    total = len(data)
    completed = len(
        [v for v in data.values() if v.get("status") == AgentState.COMPLETED.name]
    )
    executing = len(
        [
            v
            for v in data.values()
            if v.get("status") == AgentState.EXECUTING_PROCESS.name
            or "HEALING" in str(v.get("status"))
        ]
    )
    failed = len(
        [v for v in data.values() if v.get("status") == AgentState.FAILED.name]
    )

    stats_text = Text.assemble(
        ("Total: ", "bold"),
        (f"{total}  ", "cyan"),
        ("Executing: ", "bold"),
        (f"{executing}  ", "yellow"),
        ("Completed: ", "bold"),
        (f"{completed}  ", "green"),
        ("Failed: ", "bold"),
        (f"{failed}", "red"),
    )
    return Panel(Align.center(stats_text), title="System Stats", border_style="dim")


def generate_board():
    """Requirement 2: Enhanced Dashboard Implementation (DAG View)"""
    try:
        sm = SessionManager()
        # Epic 2.3: Passive Garbage Collection — sweep for orphaned tmux monitors
        sm.prune_orphaned_monitors()

        data = sm.get_all_sessions()
        if not data:
            return Panel("No active sessions found.", title="Board")

        # Build Tree Root
        tree = Tree("DAG Sub-Agent Overview", guide_style="bold bright_blue")

        def format_node(sid: str, info: dict):
            status = info.get("status", "UNKNOWN")
            last_update = info.get("last_update", 0)
            pid = info.get("pid")

            # Phase 2: Active Health Monitoring (The Dead Man's Switch)
            is_running = True
            if status == AgentState.EXECUTING_PROCESS.name:
                is_running = sm.is_process_alive(pid)
                if not is_running:
                    # Passive Garbage Collection: Update registry if process died
                    status = f"{AgentState.FAILED.name} (ZOMBIE)"
                    sm.update_registry(sid, {"status": status})

            is_stale = (
                (time.time() - last_update > 60)
                and (status == AgentState.EXECUTING_PROCESS.name)
                and is_running
            )

            # Color coding status
            status_style = (
                "green"
                if status == AgentState.COMPLETED.name
                else "yellow"
                if (status == AgentState.EXECUTING_PROCESS.name or "HEALING" in status)
                else "red"
                if AgentState.FAILED.name in status
                or AgentState.VALIDATION_FAILED.name in status
                else "dim"
            )

            if status == AgentState.COMPLETED.name:
                icon = "✅"
            elif status == AgentState.EXECUTING_PROCESS.name:
                icon = "⚡"
            elif "HEALING" in status:
                icon = "🩹"
            elif (
                AgentState.FAILED.name in status
                or AgentState.VALIDATION_FAILED.name in status
            ):
                icon = "❌"
            else:
                icon = "⏸️ "

            status_text = Text(f"{icon} {status[:20]}", style=status_style)
            if is_stale:
                status_text.append(" [STALE?]", style="bold blink red")

            short_id = sid[-8:] if len(sid) > 8 else sid
            prompt = info.get("prompt", "")[:50].replace("\n", " ")
            lane = info.get("lane", "default")
            pid = info.get("pid", "N/A")

            # Calculate actual duration display
            start_time = info.get("start_time", 0)
            elapsed = (
                time.time() - start_time
                if status == AgentState.EXECUTING_PROCESS.name
                else info.get("duration", 0)
            )
            elapsed_fmt = (
                f"{int(elapsed)}s"
                if elapsed < 60
                else f"{int(elapsed // 60)}m {int(elapsed % 60)}s"
            )

            status_len = len(status_text.plain)
            if status_len < 32:
                status_text.append(" " * (32 - status_len))

            formatted_text = Text.assemble(
                (f"[{short_id}] ".ljust(13), "cyan bold"),
                status_text,
                (f"⏱  {elapsed_fmt}".ljust(15), "magenta bold"),
                (f"({lane[:8]}) ".ljust(12), "dim"),
                (f"PID:{pid} ".ljust(12), "blue"),
                (f'"{prompt}..."', "white"),
            )
            return formatted_text

        # Build relationships dictionary from all data so parents are not orphaned
        sorted_sessions = sorted(
            data.items(), key=lambda x: x[1].get("start_time", 0), reverse=True
        )
        nodes = {sid: {"info": info, "children": []} for sid, info in sorted_sessions}

        roots = []
        for sid, node_data in nodes.items():
            parent_id = node_data["info"].get("parent_id")
            if parent_id and parent_id in nodes:
                nodes[parent_id]["children"].append(sid)
            else:
                roots.append(sid)

        # Recursively build tree
        def build_branch(parent_tree, sid):
            node_data = nodes[sid]
            node_text = format_node(sid, node_data["info"])
            branch = parent_tree.add(node_text)
            for child_id in reversed(node_data["children"]):
                build_branch(branch, child_id)

        for root_id in roots[:15]:
            build_branch(tree, root_id)

        # Main Layout
        layout = Layout()
        layout.split(
            Layout(name="header", size=3),
            Layout(name="summary", size=3),
            Layout(name="main"),
        )

        layout["header"].update(generate_header())
        layout["summary"].update(generate_summary(data))
        layout["main"].update(
            Panel(
                tree, title="Active & Recent Sessions (DAG View)", border_style="blue"
            )
        )

        return layout

    except Exception as e:
        return Panel(f"Error: {e}", title="Error", border_style="red")
