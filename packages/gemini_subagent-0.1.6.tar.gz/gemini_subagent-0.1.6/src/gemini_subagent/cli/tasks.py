import json
import typer
import asyncio
import sys
import time
from typing import List, Optional
from pathlib import Path
from rich.panel import Panel
from .common import console

from gemini_subagent.core.delegator import run_sub_agent, auto_bundle_context
from gemini_subagent.core.models import AgentState
from gemini_subagent.config import (
    DEFAULT_TIMEOUT,
)
from gemini_subagent.infrastructure.session import SessionManager

task_app = typer.Typer(help="Manage tasks and delegation.")

@task_app.command("delegate")
def delegate_task(
    prompt: str = typer.Argument(
        ..., help="The instruction or task prompt for the sub-agent."
    ),
    context_files: List[str] = typer.Option(
        [], "--file", "-f", help="Explicit file paths for context."
    ),
    workflows: List[str] = typer.Option(
        [], "--workflow", "-w", help="Workflow file paths (resolved by the caller)."
    ),
    personas: List[str] = typer.Option(
        [], "--persona", "-p", help="Persona file paths (resolved by the caller)."
    ),
    repomix: List[str] = typer.Option(
        [], "--repomix", "-x", help="Directories to pack with repomix."
    ),
    background: bool = typer.Option(
        True, "--background/--foreground", "-b", help="Run in background."
    ),
    lane: str = typer.Option("default", "--lane", "-l", help="Execution lane."),
    parent_id: Optional[str] = typer.Option(
        None,
        "--parent-id",
        "-pid",
        help="ID of the parent session for lineage tracking.",
    ),
    timeout: int = typer.Option(
        DEFAULT_TIMEOUT, "--timeout", "-t", help="Timeout for the task in seconds."
    ),
    approval_mode: str = typer.Option(
        "yolo",
        "--approval-mode",
        "-a",
        help="Approval mode: default, auto_edit, yolo, plan. Defaults to 'yolo' for headless sub-agents.",
    ),
    verify_cmd: Optional[str] = typer.Option(
        None,
        "--verify-cmd",
        "-v",
        help="Command to run after execution to verify success. If it fails, auto-heal is triggered.",
    ),
    model: Optional[str] = typer.Option(
        None, "--model", "-m", help="Gemini model to use for this sub-agent."
    ),
    slim: bool = typer.Option(
        False, "--slim", help="Skip optional context (GEMINI.md, plans, etc.) to save tokens."
    ),
    include: Optional[str] = typer.Option(
        None, "--include", help="Comma-separated patterns to include in Repomix context."
    ),
    exclude: Optional[str] = typer.Option(
        None, "--exclude", help="Comma-separated patterns to exclude from Repomix context."
    ),
):
    """
    Delegate a task to a sub-agent.
    """
    with console.status("[bold green]Validating context files..."):
        bundled_context = auto_bundle_context(
            context_files=context_files,
            include_workflows=workflows,
            include_personas=personas,
            task_prompt=prompt,
            slim=slim
        )

    effective_approval_mode = approval_mode
    if background and approval_mode != "yolo":
        console.print(
            f"[dim]Note: Forcing approval-mode=yolo for headless background agent (was: {approval_mode}).[/dim]"
        )
        effective_approval_mode = "yolo"

    try:
        result_json = asyncio.run(
            run_sub_agent(
                prompt=prompt,
                context_files=bundled_context,
                approval_mode=effective_approval_mode,
                lane=lane,
                background=background,
                tmux=True,
                repomix_targets=repomix,
                parent_id=parent_id,
                timeout=timeout,
                verify_cmd=verify_cmd,
                model=model,
                repomix_include=include,
                repomix_exclude=exclude
            )
        )

        data = json.loads(result_json)
        console.print(
            Panel(
                f"[bold cyan]Task Dispatched[/]\n"
                f"ID:     {data['session_id']}\n"
                f"Branch: {data['branch']}\n"
                f"Lane:   {data['context']['lane']}\n"
                f"Board:  subgemi session board",
                title="SUBGEMI",
                border_style="cyan",
            )
        )

    except Exception as e:
        console.print(f"[bold red]Delegation failed:[/] {e}")
        sys.exit(1)


@task_app.command("get")
def get_task_result(session_id: str):
    """
    Retrieve the exact parsed JSON output of a completed sub-agent execution.
    """
    try:
        data = SessionManager().get_all_sessions()
        if session_id not in data:
            console.print(
                f"[red]Error:[/red] Session {session_id} not found in registry."
            )
            return

        session_info = data[session_id]
        status = session_info.get("status")

        if status != AgentState.COMPLETED.name:
            console.print(
                f"[yellow]Task is not completed. Current status: {status}[/yellow]"
            )
            return

        session_dir = Path(session_info.get("session_dir", ""))
        payload_file = session_dir / "fsm_payload_out.json"
        log_file = session_dir / "stdout.log"

        if payload_file.exists():
            payload = json.loads(payload_file.read_text())
            console.print(
                Panel(
                    json.dumps(payload, indent=2),
                    title=f"Result Payload: {session_id}",
                    border_style="green",
                )
            )
        elif log_file.exists():
            raw_stdout = log_file.read_text().strip()
            try:
                json_str = raw_stdout
                if "{" in raw_stdout:
                    json_start = raw_stdout.find("{")
                    json_end = raw_stdout.rfind("}") + 1
                    if json_end > json_start:
                        json_str = raw_stdout[json_start:json_end]
                parsed_result = json.loads(json_str)

                console.print(
                    Panel(
                        json.dumps(parsed_result, indent=2),
                        title=f"Fallback Result Payload: {session_id}",
                        border_style="green",
                    )
                )

            except json.JSONDecodeError:
                console.print(
                    f"[yellow]Failed to parse strictly as JSON. Raw output:[/yellow]\n{raw_stdout}"
                )
        else:
            console.print(
                f"[red]Error:[/red] Result log file missing for {session_id}."
            )

    except Exception as e:
        console.print(f"[bold red]Error reading session data:[/bold red] {e}")
        sys.exit(1)


@task_app.command("await")
def await_tasks(
    session_ids: List[str] = typer.Argument(
        ..., help="One or more session IDs to wait for."
    ),
    poll_interval: float = typer.Option(
        2.0, "--poll", help="Polling interval in seconds."
    ),
    timeout: int = typer.Option(
        3600, "--timeout", "-t", help="Timeout for waiting in seconds."
    ),
):
    """
    Block until all specified sub-agent sessions complete, then print their combined outputs as JSON.
    """
    sm = SessionManager()
    data = sm.get_all_sessions()
    if not data:
        console.print("[yellow]No session registry found or empty.[/yellow]")
        sys.exit(1)

    start_time = time.time()
    terminal_states = [
        AgentState.COMPLETED.name,
        AgentState.FAILED.name,
        AgentState.VALIDATION_FAILED.name,
        "DETACHED (Failed)",
    ]

    # Resolve IDs first
    resolved_ids = []
    for sid in session_ids:
        if sid in data:
            resolved_ids.append(sid)
        else:
            # Check for short ID match
            matches = [k for k in data.keys() if k.endswith(sid)]
            if len(matches) == 1:
                resolved_ids.append(matches[0])
            elif len(matches) > 1:
                console.print(f"[red]Error:[/] Ambiguous session ID '{sid}'.")
                sys.exit(1)
            else:
                console.print(f"[red]Error:[/] Session ID '{sid}' not found.")
                sys.exit(1)

    results = {}
    remaining = set(resolved_ids)

    try:
        with console.status(f"[bold green]Waiting for {len(remaining)} tasks...") as status:
            while remaining and (time.time() - start_time < timeout):
                data = sm.get_all_sessions()
                for sid in list(remaining):
                    info = data.get(sid, {})
                    current_status = str(info.get("status", "UNKNOWN"))
                    
                    if any(s in current_status for s in terminal_states):
                        # Extract result
                        session_dir = Path(info.get("session_dir", ""))
                        payload_file = session_dir / "fsm_payload_out.json"
                        
                        res_data = {"status": current_status}
                        if payload_file.exists():
                            try:
                                res_data["output"] = json.loads(payload_file.read_text())
                            except Exception:
                                res_data["output"] = "Error parsing output JSON."
                        
                        results[sid] = res_data
                        remaining.remove(sid)
                        status.update(f"[bold green]Waiting for {len(remaining)} tasks...")

                if remaining:
                    time.sleep(poll_interval)

        if remaining:
            console.print(f"[bold red]Timeout reached.[/] Still waiting for: {remaining}")

        console.print(json.dumps(results, indent=2))

    except KeyboardInterrupt:
        console.print("\n[bold yellow]Wait cancelled by user.[/]")
        sys.exit(1)
@task_app.command("summary")
def summarize_batch(parent_id: str):
    """
    Summarize results for all tasks sharing a specific parent_id.
    """
    from rich.table import Table
    sm = SessionManager()
    all_sessions = sm.get_all_sessions()
    
    # Filter sessions by parent_id
    batch_sessions = {
        sid: info for sid, info in all_sessions.items() 
        if info.get("parent_id") == parent_id or sid == parent_id
    }
    
    if not batch_sessions:
        console.print(f"[yellow]No sessions found for parent_id: {parent_id}[/yellow]")
        return

    table = Table(title=f"Batch Summary: {parent_id}", show_header=True, header_style="bold magenta")
    table.add_column("Session ID", style="dim")
    table.add_column("Status")
    table.add_column("Lines +/-", justify="right")
    table.add_column("Heals", justify="right")
    table.add_column("Summary/Error", ratio=1)

    for sid, info in batch_sessions.items():
        status = info.get("status", "UNKNOWN")
        session_dir = Path(info.get("session_dir", ""))
        payload_file = session_dir / "fsm_payload_out.json"
        
        lines_info = "-"
        heals = "-"
        result_summary = ""
        
        if payload_file.exists():
            try:
                p_data = json.loads(payload_file.read_text())
                added = p_data.get("lines_added", 0)
                removed = p_data.get("lines_removed", 0)
                lines_info = f"[green]+{added}[/] / [red]-{removed}[/]"
                heals = str(p_data.get("heal_attempts", 0))
                
                # Try to get a summary from output if it's there
                output = p_data.get("output", {})
                if isinstance(output, dict):
                    result_summary = output.get("summary") or output.get("message") or ""
                
                if p_data.get("error"):
                    result_summary = f"[red]{p_data['error']}[/]"
            except Exception:
                result_summary = "[dim]Metadata exists but unreadable[/]"
        else:
            result_summary = "[dim]No fsm_payload_out.json yet[/]"

        # Truncate summary for table readability
        if len(result_summary) > 500:
            result_summary = result_summary[:497] + "..."

        # Style status
        status_styled = status
        if "COMPLETED" in status:
            status_styled = f"[bold green]{status}[/]"
        elif "FAILED" in status:
            status_styled = f"[bold red]{status}[/]"
        elif "HEALING" in status:
            status_styled = f"[bold yellow]{status}[/]"

        table.add_row(
            sid,
            status_styled,
            lines_info,
            heals,
            result_summary
        )

    console.print(table)
