import json
import typer
import subprocess
import sys
import shutil
import os
import time
import signal
import shlex
from typing import Dict, Any
from pathlib import Path
from .common import console

from gemini_subagent.infrastructure.session import SessionManager
from gemini_subagent.core.models import AgentState
from gemini_subagent.config import WORKTREES_DIR, REGISTRY_DIR

session_app = typer.Typer(help="Manage execution sessions.")

@session_app.command("monitor")
def monitor_session(
    session_id: str,
    log: bool = typer.Option(
        False, "--log", "-l", help="Force tail log file instead of tmux attach."
    ),
):
    """
    Attach to the live log monitor for a running background session.
    """
    try:
        sm = SessionManager()
        data = sm.get_all_sessions()
        if not data:
            console.print("[yellow]No session registry found or empty.[/yellow]")
            return

        if session_id.lower() == "all":
            monitor_all_active_sessions(data)
            return

        matched_id = session_id
        if session_id.lower() == "last":
            matched_id = max(data.keys(), key=lambda k: data[k].get("created_at", 0))
            console.print(f"[dim]Resolved 'last' to session: {matched_id}[/dim]")
        elif session_id not in data:
            candidates = [
                k for k in data if k.endswith(f"_{session_id}") or session_id in k
            ]
            if not candidates:
                console.print(
                    f"[red]Error:[/red] Session [cyan]{session_id}[/cyan] not found in registry."
                )
                return
            matched_id = candidates[0]
            console.print(f"[dim]Resolved to session: {matched_id}[/dim]")

        session_info = data[matched_id]
        tmux_session = session_info.get("tmux_session")
        session_dir = Path(session_info.get("session_dir", ""))
        log_file = session_dir / "stdout.log"

        if tmux_session and not log:
            has_session = subprocess.run(
                ["tmux", "has-session", "-t", tmux_session], capture_output=True
            )

            if has_session.returncode == 0:
                console.print(
                    f"[bold green]Attaching to tmux monitor (X-Ray Dashboard):[/bold green] [cyan]{tmux_session}[/cyan]"
                )
                
                pid = session_info.get("pid")
                payload_path = session_dir / "fsm_payload.json"
                worktree = WORKTREES_DIR / matched_id

                subprocess.run(
                    ["tmux", "kill-pane", "-a", "-t", tmux_session],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )

                subprocess.run(["tmux", "split-window", "-h", "-l", "40%", "-t", tmux_session, "tail -f /dev/null"])
                right_pane = f"{tmux_session}:0.1"

                if payload_path.exists():
                    p_cmd = (
                        f"jq -r '.prompt' {payload_path} | less"
                        if shutil.which("jq")
                        else f"cat {payload_path} | less"
                    )
                    subprocess.run(["tmux", "respawn-pane", "-t", right_pane, p_cmd])

                if worktree.exists():
                    git_cmd = f'bash -c \'while true; do clear; echo "[GIT WORKTREE: {matched_id[-8:]}]"; echo "--------------------------------"; git -C {worktree} status -s; sleep 3; done\''
                    subprocess.run(["tmux", "split-window", "-v", "-t", right_pane, git_cmd])

                if pid:
                    stat_cmd = f'bash -c \'while true; do clear; echo "[RESOURCE USAGE (PID: {pid})]"; echo "--------------------------------"; ps -o pid,%cpu,%mem,stat,time -p {pid} || echo "Process ended"; sleep 2; done\''
                    subprocess.run(["tmux", "split-window", "-v", "-t", f"{tmux_session}:0.2", stat_cmd])
                    
                    if shutil.which("watch"):
                        ps_cmd = f"watch -n 1 \"ps -ef | awk '\\$3 == {pid} || \\$2 == {pid}'\""
                    else:
                        ps_cmd = f'bash -c \'while true; do clear; echo "[PROCESS TREE]"; echo "--------------------------------"; ps -ef | awk "\\$3 == {pid} || \\$2 == {pid}"; sleep 2; done\''
                    subprocess.run(["tmux", "split-window", "-v", "-t", f"{tmux_session}:0.3", ps_cmd])

                subprocess.run(
                    ["tmux", "select-pane", "-t", f"{tmux_session}:0.0"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )

                result = subprocess.run(["tmux", "attach-session", "-t", tmux_session])

                if result.returncode in [0, 130]:
                    subprocess.run(
                        ["tmux", "kill-pane", "-a", "-t", f"{tmux_session}:0.0"],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    )
                return
            else:
                console.print(f"[yellow]Tmux session {tmux_session} not found. Falling back to log tail...[/yellow]")

        if log_file.exists():
            console.print(f"[yellow]Tailing log file:[/yellow] {log_file}")
            os.execvp("tail", ["tail", "-f", str(log_file)])
        else:
            console.print(f"[red]No tmux session or log file found for session {matched_id}.[/red]")
    except Exception as e:
        console.print(f"[bold red]Error attaching to monitor:[/bold red] {e}")

def monitor_all_active_sessions(data: Dict[str, Any]):
    """Creates a 'Master Cockpit' tmux session that monitors all active agents."""
    active_state_prefixes = ["EXECUTING", "HEALING", "VERIFYING", "VALIDATING", "PREPARING", "ACTIVE"]
    executing = {sid: info for sid, info in data.items() if any(state in info.get("status", "") for state in active_state_prefixes)}

    if not executing:
        console.print("[yellow]No active agents currently running to monitor.[/yellow]")
        return

    master_session = "subgemi_COCKPIT"
    subprocess.run(["tmux", "kill-session", "-t", master_session], stderr=subprocess.DEVNULL)
    subprocess.run(["tmux", "new-session", "-d", "-s", master_session, "-n", "DASHBOARD"])

    subprocess.run(["tmux", "set-option", "-t", master_session, "mouse", "on"])
    subprocess.run(["tmux", "set-option", "-t", master_session, "status-position", "top"])
    subprocess.run(["tmux", "set-option", "-t", master_session, "status-style", "bg=black,fg=cyan"])
    subprocess.run(["tmux", "set-option", "-t", master_session, "status-left", "#[bg=cyan,fg=black,bold] COCKPIT #[default] "])
    subprocess.run(["tmux", "set-option", "-t", master_session, "status-right", "#[fg=white,dim] Alt+1:DH | Alt+2:OPS | Mouse:Scroll "])
    subprocess.run(["tmux", "set-option", "-t", master_session, "pane-border-status", "top"])
    subprocess.run(["tmux", "set-option", "-t", master_session, "pane-border-format", " #{pane_index}: #[bold]#{pane_title}#[default] "])

    # Navigation excellence
    subprocess.run(["tmux", "bind-key", "-n", "M-1", "select-window", "-t", f"{master_session}:0"])
    subprocess.run(["tmux", "bind-key", "-n", "M-2", "select-window", "-t", f"{master_session}:1"])
    for key, pane_cmd in [("M-Left", "select-pane -L"), ("M-Right", "select-pane -R"), ("M-Up", "select-pane -U"), ("M-Down", "select-pane -D")]:
        subprocess.run(["tmux", "bind-key", "-n", key, pane_cmd])

    # Dashboard Window
    python_cli = f"{sys.executable} -m gemini_subagent.cli"
    board_cmd = f"while true; do clear; {python_cli} session list; sleep 5; done"
    subprocess.run(["tmux", "send-keys", "-t", f"{master_session}:0.0", board_cmd, "Enter"])
    subprocess.run(["tmux", "select-pane", "-T", "DASHBOARD", "-t", f"{master_session}:0.0"])

    # Operations Grid
    subprocess.run(["tmux", "new-window", "-t", master_session, "-n", "OPERATIONS", "tail -f /dev/null"])

    for i, (sid, info) in enumerate(executing.items()):
        s_dir = Path(info.get("session_dir", ""))
        lane = info.get("lane", "default")
        status = info.get("status", "ACTIVE")
        safe_out = shlex.quote(str(s_dir / "stdout.log"))
        safe_err = shlex.quote(str(s_dir / "stderr.log"))
        t_title = f"{sid[-4:]} [{lane}] ({status})"
        state_file = shlex.quote(str(REGISTRY_DIR / f"{sid}.json"))

        tail_cmd = (
            f'bash -c \'printf "\\033[1;36m>>> AGENT {sid[-8:]} [%s] <<<\\033[0m\\n" "{lane}"; '
            f"tail -f {safe_out} {safe_err} 2>/dev/null & TAIL_PID=$!; "
            f"while true; do "
            f"  if [ ! -f {state_file} ]; then kill $TAIL_PID 2>/dev/null; exit 0; fi; "
            f'  if grep -qE "(COMPLETED|FAILED|VALIDATION_FAILED)" {state_file} 2>/dev/null; then '
            f"    sleep 10; kill $TAIL_PID 2>/dev/null; "
            f'    printf "\\n\\033[1;33m[ Session Terminated. Closing pane in 5s... ]\\033[0m\\n"; '
            f"    sleep 5; exit 0; "
            f"  fi; sleep 2; done'"
        )

        if i == 0:
            subprocess.run(["tmux", "respawn-pane", "-k", "-t", f"{master_session}:1.0", tail_cmd])
            subprocess.run(["tmux", "select-pane", "-T", t_title, "-t", f"{master_session}:1.0"])
        else:
            subprocess.run(["tmux", "split-window", "-t", f"{master_session}:1.0", tail_cmd])
            subprocess.run(["tmux", "select-layout", "-t", f"{master_session}:1", "tiled"])
            subprocess.run(["tmux", "select-pane", "-T", t_title, "-t", f"{master_session}:1.{i}"])

    subprocess.run(["tmux", "select-window", "-t", f"{master_session}:1"])
    subprocess.run(["tmux", "attach-session", "-t", master_session])

@session_app.command("cockpit")
def cockpit_monitor():
    """Launch the Master Cockpit monitor."""
    data = SessionManager().get_all_sessions()
    monitor_all_active_sessions(data)

@session_app.command("logs")
def session_logs(
    session_id: str,
    tail: bool = typer.Option(True, "--tail", "-f", help="Continue streaming new logs."),
):
    """Stream logs from a sub-agent session."""
    try:
        sm = SessionManager()
        info = sm.get_session(session_id)
        if not info:
             # Try short ID
             data = sm.get_all_sessions()
             matches = [k for k in data.keys() if k.endswith(session_id)]
             if len(matches) == 1:
                 info = data[matches[0]]
             else:
                console.print(f"[red]Error:[/] Session {session_id} not found.")
                return

        s_dir = Path(info.get("session_dir", ""))
        out_p = s_dir / "stdout.log"
        err_p = s_dir / "stderr.log"

        def stream_file(path: Path, prefix: str, style: str):
            if path.exists():
                with path.open("r", errors="replace") as f:
                    if tail:
                        f.seek(0, 2)
                    while True:
                        line = f.readline()
                        if line:
                            yield f"[{style}]{prefix}[/] {line.strip()}"
                        elif not tail:
                            break
                        else:
                            time.sleep(0.1)

        console.print(f"[bold green]Streaming logs for {session_id}...[/]")
        # Simplified multiplexing for CLI command
        if out_p.exists():
            subprocess.run(["tail", "-f" if tail else "-n", "+1", str(out_p)])
    except KeyboardInterrupt:
        pass

@session_app.command("tail-all")
def tail_all_sessions():
    """Multiplexed tail of all running sub-agents."""
    # (Simplified version or keeping the complex logic from cli.py)
    # I'll keep the logic from cli.py as it's very useful for concurrent runs.
    sm = SessionManager()
    tracked_files = {} # sid -> (f_out, f_err, lane)
    console.print("[bold cyan]Multiplexed Logger Started.[/bold cyan]\n")
    try:
        while True:
            sessions = sm.get_all_sessions()
            active_sids = [sid for sid, info in sessions.items() if any(s in info.get("status", "") for s in ["EXECUTING", "HEALING", "VERIFYING", "VALIDATING", "PREPARING", "ACTIVE"])]
            for sid in active_sids:
                if sid not in tracked_files:
                    info = sessions[sid]
                    s_dir = Path(info.get("session_dir", ""))
                    out_p = s_dir / "stdout.log"
                    err_p = s_dir / "stderr.log"
                    if out_p.exists() or err_p.exists():
                        f_out = out_p.open("r", errors="replace") if out_p.exists() else None
                        f_err = err_p.open("r", errors="replace") if err_p.exists() else None
                        if f_out:
                            f_out.seek(0, 2)
                        if f_err:
                            f_err.seek(0, 2)
                        lane = info.get("lane", "default")
                        tracked_files[sid] = (f_out, f_err, lane)
                        console.print(f"[bold green]>>> Tracking NEW Session:[/] [yellow]{lane}[/] [dim]({sid[-8:]})[/dim]")
            
            had_io = False
            for sid, (f_out, f_err, lane) in list(tracked_files.items()):
                for f, color in [(f_out, "cyan"), (f_err, "dim yellow")]:
                    if f:
                        line = f.readline()
                        if line:
                            clean = line.strip()
                            if clean:
                                console.print(f"[bold cyan]{lane:>12}[/] [dim]│[/] [{color}]{clean}[/]")
                                had_io = True
                
                status = sessions.get(sid, {}).get("status", "")
                if any(s in status for s in ["COMPLETED", "FAILED", "VALIDATION_FAILED"]):
                    console.print(f"[bold red]>>> Session TERMINATED:[/] [yellow]{lane}[/] [dim]({status})[/dim]")
                    if f_out:
                        f_out.close()
                    if f_err:
                        f_err.close()
                    del tracked_files[sid]
            
            if not had_io:
                time.sleep(0.5)
    except KeyboardInterrupt:
        pass
    finally:
        for f1, f2, _ in tracked_files.values():
            if f1:
                f1.close()
            if f2:
                f2.close()

@session_app.command("kill")
def kill_task(session_id: str):
    """Kill a running sub-agent session."""
    try:
        sm = SessionManager()
        data = sm.get_all_sessions()
        matched_id = session_id
        if session_id not in data:
            matches = [k for k in data.keys() if k.endswith(session_id)]
            if len(matches) == 1:
                matched_id = matches[0]
            else:
                 console.print(f"[red]Error:[/] Session {session_id} not found.")
                 return

        info = data[matched_id]
        pid = info.get("pid")
        if pid:
            try:
                os.kill(pid, signal.SIGTERM)
            except Exception:
                pass
        
        tmux = info.get("tmux_session")
        if tmux:
            subprocess.run(["tmux", "kill-session", "-t", tmux], stderr=subprocess.DEVNULL)
            
        sm.update_registry(matched_id, {"status": AgentState.FAILED.name, "error": "Killed by user."})
        console.print(f"[bold green]Session {matched_id} killed.[/bold green]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")

@session_app.command("list")
def list_sessions(
    json_mode: bool = typer.Option(False, "--json", "-j", help="Output raw JSON.")
):
    """Static list of sessions."""
    sm = SessionManager()
    data = sm.get_all_sessions()
    if json_mode:
        console.print(json.dumps(data, indent=2))
    else:
        from .ui import generate_board
        console.print(generate_board())

@session_app.command("prune")
def prune_sessions(
    hard: bool = typer.Option(False, "--hard", help="Forcefully kill orphaned tmux sessions and stagnant worktrees."),
    cache: bool = typer.Option(False, "--cache", help="Clear all shared context caches.")
):
    """Cleanup session artifacts and dangling monitors."""
    sm = SessionManager()
    if cache:
        count = sm.prune_context_caches()
        console.print(f"[bold green]Pruned {count} context caches.[/bold green]")
        return

    if hard:
        sm.prune_orphaned_monitors()
        sm.prune_orphaned_worktrees(hard=True)
    else:
        sm.prune_orphaned_worktrees(hard=False)
    console.print("[bold green]Success.[/]")
