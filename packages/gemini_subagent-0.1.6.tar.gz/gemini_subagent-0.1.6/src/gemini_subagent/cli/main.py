import typer
from .common import state
from .tasks import task_app
from .sessions import session_app
from .metrics import metrics_app

app = typer.Typer(
    name="subgemi",
    add_completion=False,
)



@app.callback()
def main_callback(
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress visual output."),
    json_mode: bool = typer.Option(False, "--json", "-j", help="Output raw JSON."),
):
    """
    SUBGEMI: Sub-Agent Orchestration CLI for Gemini
    """
    state["quiet"] = quiet
    state["json"] = json_mode

app.add_typer(task_app, name="task")
app.add_typer(session_app, name="session")
app.add_typer(metrics_app, name="metrics")


