
"""
Metrics Logger: Handles sub-agent usage and cost reporting.
"""

import json
import logging
from datetime import datetime
from typing import Dict
from pathlib import Path

from gemini_subagent.config import METRICS_DIR, PRICING

logger = logging.getLogger("geminis-metrics")

def log_metrics(prompt: str, output_data: Dict, session_id: str, session_dir: Path):
    """
    Log task execution metrics as an atomic JSON artifact within the session directory.
    This pattern ensures parallel-safe logging without shared file locking.
    """
    try:
        # 1. Extract raw stats
        stats = output_data.get("stats", {})
        models = stats.get("models", {})
        
        
        # 2. Aggregation Logic
        primary_model = "default" # mostly used model to report
        input_tokens = 0
        output_tokens = 0
        total_tokens = 0
        latency_ms = 0
        cost_usd = 0.0
        
        if models:
            max_tokens = -1
            for name, data in models.items():
                tokens = data.get("tokens", {})
                model_in = tokens.get("prompt", 0)
                model_out = tokens.get("candidates", 0)
                model_tot = tokens.get("total", 0)
                
                input_tokens += model_in
                output_tokens += model_out
                total_tokens += model_tot
                latency_ms += data.get("api", {}).get("totalLatencyMs", 0)
                
                # Accurately calculate cost PER model
                rate = PRICING.get(name, PRICING["default"])
                if rate == PRICING["default"]:
                    if any(p in name for p in ["pro", "1.5-pro"]): 
                        rate = PRICING["gemini-1.5-pro"]
                    elif "flash" in name:
                        rate = PRICING["gemini-1.5-flash"]
                        
                cost_usd += (model_in / 1_000_000 * rate["input"]) + (model_out / 1_000_000 * rate["output"])
                
                # The model that burned the most tokens becomes the primarily reported 'model'
                if model_tot > max_tokens:
                    primary_model = name
                    max_tokens = model_tot
        else:
            # Check for generic stats (fallback if no models block)
            input_tokens = stats.get("tokens", {}).get("prompt", 0)
            output_tokens = stats.get("tokens", {}).get("candidates", 0)
            total_tokens = stats.get("tokens", {}).get("total", 0)
            
            rate = PRICING["default"]
            cost_usd = (input_tokens / 1_000_000 * rate["input"]) + (output_tokens / 1_000_000 * rate["output"])

        # 4. Construct Metric Payload
        lines_added = output_data.get("lines_added", 0)
        lines_removed = output_data.get("lines_removed", 0)
        total_lines = lines_added + lines_removed
        
        # Calculate Efficiency ROI: Total Lines Changed / (Total Tokens / 1000)
        # Higher is better: 'How many lines of code did I get per 1000 tokens?'
        efficiency = 0.0
        if total_tokens > 0:
            efficiency = total_lines / (total_tokens / 1000.0)

        metrics_payload = {
            "session_id": session_id,
            "timestamp": datetime.now().isoformat(),
            "model": primary_model,
            "tokens": {
                "input": input_tokens,
                "output": output_tokens,
                "total": total_tokens
            },
            "cost_usd": cost_usd,
            "latency_ms": latency_ms,
            "tool_calls": stats.get("tools", {}).get("totalCalls", 0),
            "status": output_data.get("status", "unknown"),
            "lane": output_data.get("context", {}).get("lane", "default"),
            "git": {
                "lines_added": lines_added,
                "lines_removed": lines_removed,
                "total_lines": total_lines,
                "efficiency": efficiency
            },
            "heal_attempts": output_data.get("heal_attempts", 0)
        }

        # 5. Commit as Atomic JSON Artifact (Persistent storage)
        METRICS_DIR.mkdir(parents=True, exist_ok=True)
        metrics_path = METRICS_DIR / f"{session_id}.json"
        metrics_path.write_text(json.dumps(metrics_payload, indent=2))
        
        # Legacy: Still append to summary file if it exists, but don't fail if it doesn't
        # This keeps the usage_report.md as a readable log for humans.
        summary_path = METRICS_DIR / "usage_report.md"
        if not summary_path.exists():
             summary_path.write_text("# Sub-Agent Usage Summary\n\n| Timestamp | Session | Model | Total Tokens | Cost (USD) | Status |\n| :--- | :--- | :--- | :--- | :--- | :--- |\n")
        
        row = f"| {metrics_payload['timestamp']} | {session_id[-8:]} | {primary_model} | {total_tokens} | ${cost_usd:8.6f} | {metrics_payload['status']} |\n"
        with open(summary_path, "a") as f:
            f.write(row)

    except Exception as e:
        logger.warning(f"Failed to log metrics for {session_id}: {e}")
