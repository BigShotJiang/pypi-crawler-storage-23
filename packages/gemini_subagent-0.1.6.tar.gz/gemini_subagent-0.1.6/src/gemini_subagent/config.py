"""
config.py — Runtime path resolution for subgemi.

Design principles:
  1. SUBGEMI_HOME is the ONLY required data directory for the tool's runtime state.
     Default: ~/subgemi  .
     Override: set env var SUBGEMI_HOME.
  2. WORKSPACE_ROOT is SEPARATE — the user's git project, detected from CWD.
     Used only for git operations and workspace-relative context bundling.
  3. No .agent/-specific paths here. Those are the user's project convention,
     not the tool's concern.
"""

import os
from pathlib import Path

# Runtime environment (PROD, DEV)
ENV = os.environ.get("ENV", "PROD")

# Default values
DEFAULT_TIMEOUT = 3600   # 1 hour
REGISTRY_PRUNE_THRESHOLD = 7 * 24 * 60 * 60  # 7 days

# Rate limiting retry logic
DEFAULT_MAX_HEAL_RETRIES = 3
RATE_LIMIT_BACKOFF_BASE = 5  # Base sleep time in seconds
RATE_LIMIT_MAX_WAIT = 60      # Maximum sleep time

# Pricing per 1M tokens in USD
# Source: https://ai.google.dev/pricing
PRICING = {
    "gemini-3-flash-preview": {"input": 0.075, "output": 0.30},
    "gemini-2.5-pro": {"input": 3.50, "output": 10.50},
    "gemini-2.5-flash": {"input": 0.075, "output": 0.30},
    "gemini-2.0-flash": {"input": 0.10, "output": 0.30},
    "gemini-1.5-flash": {"input": 0.075, "output": 0.30},
    "gemini-1.5-pro": {"input": 3.50, "output": 10.50},
    "default": {"input": 0.10, "output": 0.30}
}




# --------------------------------------------------------------------------- #
# 1. SUBGEMI_HOME — tool's own data directory (sessions, logs, worktrees)    #
# --------------------------------------------------------------------------- #

def _resolve_subgemi_home() -> Path:
    """Resolve SUBGEMI_HOME: env var override, or ~/subgemi as the default."""
    if env := os.environ.get("SUBGEMI_HOME"):
        return Path(env).expanduser().resolve()
    return Path("~/subgemi").expanduser().resolve()


SUBGEMI_HOME: Path   = _resolve_subgemi_home()

SESSIONS_DIR: Path   = SUBGEMI_HOME / "sessions"
WORKTREES_DIR: Path  = SUBGEMI_HOME / "worktrees"
LOG_DIR: Path        = SUBGEMI_HOME / "logs"
MEMORY_DIR: Path     = SUBGEMI_HOME / "memory"
PROMPTS_DIR: Path    = SUBGEMI_HOME / "prompts"   # user-overridable prompt templates
METRICS_DIR: Path    = SUBGEMI_HOME / "metrics"   # usage metrics (tool-internal)
REGISTRY_DIR: Path   = SUBGEMI_HOME / "registry"  # distributed session state (atomic)


# --------------------------------------------------------------------------- #
# 2. WORKSPACE_ROOT — the user's current project (git repo)                  #
# --------------------------------------------------------------------------- #

def find_workspace_root() -> Path:
    """Walk up from CWD to find the nearest .git or .agent directory."""
    curr = Path(os.getcwd()).resolve()
    for parent in [curr] + list(curr.parents):
        if (parent / ".git").exists() or (parent / ".agent").exists():
            return parent
    return curr   # fallback: CWD itself


WORKSPACE_ROOT: Path = find_workspace_root()


# --------------------------------------------------------------------------- #
# 3. Ensure runtime directories exist                                         #
# --------------------------------------------------------------------------- #

def ensure_dirs() -> None:
    """Create all runtime directories that subgemi needs to operate."""
    for d in [SESSIONS_DIR, WORKTREES_DIR, LOG_DIR, MEMORY_DIR, PROMPTS_DIR, METRICS_DIR, REGISTRY_DIR]:
        d.mkdir(parents=True, exist_ok=True)
