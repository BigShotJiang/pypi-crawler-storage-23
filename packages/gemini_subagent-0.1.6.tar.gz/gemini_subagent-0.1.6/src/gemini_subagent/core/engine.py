"""
Finite State Machine for Gemini Sub-Agent Execution.
Defines explicit states and transitions for robust task lifecycle management.
"""

import os
import time
import json
import asyncio
import logging
import random
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Callable
from datetime import datetime

from gemini_subagent.config import (
    DEFAULT_TIMEOUT, DEFAULT_MAX_HEAL_RETRIES, 
    RATE_LIMIT_BACKOFF_BASE, RATE_LIMIT_MAX_WAIT
)
from gemini_subagent.core.models import AgentState, ExecutionResult
from gemini_subagent.utils.logger import setup_gemini_logging
from gemini_subagent.infrastructure.session import SessionManager
from gemini_subagent.infrastructure.executor import ProcessExecutor
from gemini_subagent.infrastructure.workspace import GitWorkspace

logger = setup_gemini_logging("geminis-fsm")

class SubAgentFSM:
    """
    Manages the lifecycle of a Gemini sub-agent task using a State Machine pattern.
    
    This class handles:
    1. State transitions (PENDING -> EXECUTING -> COMPLETED/FAILED)
    2. Process execution (spawning the gemini CLI)
    3. Output parsing (stdout/stderr handling)
    
    It delegates session persistence (registry updates) to the SessionManager.
    """
    
    def __init__(
        self,
        prompt: str,
        context_files: List[str],
        session_dir: Path,
        cmd: List[str],
        session_manager: SessionManager,
        execution_cwd: Optional[Path] = None,
        timeout: int = DEFAULT_TIMEOUT,
        session_id: Optional[str] = None,
        tmux_session: Optional[str] = None,
        lane: str = "default",
        approval_mode: str = "auto_edit",
        verify_cmd: Optional[str] = None
    ):
        self.state = AgentState.PENDING
        self.prompt = prompt
        self.context_files = context_files
        self.session_dir = session_dir
        self.execution_cwd = execution_cwd or session_dir
        self.approval_mode = approval_mode
        self.cmd = cmd
        # Ensure the underlying gemini process uses the desired approval mode
        if "--approval-mode" in self.cmd:
            idx = self.cmd.index("--approval-mode")
            self.cmd[idx + 1] = self.approval_mode
        else:
            self.cmd.extend(["--approval-mode", self.approval_mode])
            
        self.session_manager = session_manager
        self.timeout = timeout
        self.start_time = 0.0
        self.result = ExecutionResult(status=AgentState.PENDING.name)
        self.session_id = session_id or session_dir.name
        self.tmux_session = tmux_session
        self.lane = lane
        self.verify_cmd = verify_cmd
        self._current_status_override = None
        
        # New modular components
        self.executor = ProcessExecutor(self.session_id, self.session_dir, self.execution_cwd)
        self.workspace = GitWorkspace(self.execution_cwd)

    async def run(self) -> ExecutionResult:
        """Main execution loop for the FSM."""
        self.start_time = time.time()
        max_retries = DEFAULT_MAX_HEAL_RETRIES
        heal_attempts = 0
        original_prompt = self.prompt
        
        cumulative_models = {}
        cumulative_tools = {"totalCalls": 0, "totalSuccess": 0, "totalFail": 0, "totalDurationMs": 0}
        last_parsed_output = {}

        try:
            while heal_attempts <= max_retries:
                try:
                    if heal_attempts == 0:
                        await self._transition(AgentState.PREPARING_CONTEXT)
                        if not self._validate_context():
                            return await self._fail("Context validation failed")

                    if heal_attempts > 0:
                        await self._transition(AgentState.HEALING, status_override=f"{AgentState.HEALING.name} (Attempt {heal_attempts}/{max_retries})")
                    else:
                        await self._transition(AgentState.EXECUTING_PROCESS)

                    stdout, stderr, code, pid = await self.executor.execute(
                        self.cmd, self.timeout, heartbeat_callback=lambda: self._transition(self.state)
                    )
                    
                    if pid:
                        self.session_manager.update_registry(self.session_id, {"pid": pid})
                    
                    await self._transition(AgentState.VALIDATING_OUTPUT)
                    parsed_output = self._parse_output(stdout, stderr, code)
                    last_parsed_output = parsed_output
                    
                    # Accummulate stats
                    stats = parsed_output.get("stats", {})
                    models = stats.get("models", {})
                    for name, data in models.items():
                        if name not in cumulative_models:
                            cumulative_models[name] = {"api": {"totalLatencyMs": 0}, "tokens": {"prompt": 0, "candidates": 0, "total": 0}}
                        m = cumulative_models[name]
                        m["api"]["totalLatencyMs"] += data.get("api", {}).get("totalLatencyMs", 0)
                        m["tokens"]["prompt"] += data.get("tokens", {}).get("prompt", 0)
                        m["tokens"]["candidates"] += data.get("tokens", {}).get("candidates", 0)
                        m["tokens"]["total"] += data.get("tokens", {}).get("total", 0)
                        
                    tools = stats.get("tools", {})
                    cumulative_tools["totalCalls"] += tools.get("totalCalls", 0)
                    cumulative_tools["totalSuccess"] += tools.get("totalSuccess", 0)
                    cumulative_tools["totalFail"] += tools.get("totalFail", 0)
                    cumulative_tools["totalDurationMs"] += tools.get("totalDurationMs", 0)
                    
                    if parsed_output.get("status") == AgentState.FAILED.name.lower() or code != 0:
                        # Epic 2.1: Headless Fail-Fast Detection
                        error_msg = stderr if stderr else parsed_output.get("error", "Unknown process error")
                        
                        # Detect pattern of hanging on approval in headless environment
                        escalation_triggers = [
                            "EOF when reading a line", 
                            "Requires approval", 
                            "Use --yolo", 
                            "Permission denied",
                            "Confirmation required"
                        ]

                        if any(trigger.lower() in error_msg.lower() for trigger in escalation_triggers):
                             error_msg = f"FAILED (Privilege Escalation Required): The task requires manual approval for a potentially destructive command. Headless mode aborted."
                             self.result = ExecutionResult(
                                 status=AgentState.FAILED.name,
                                 output=parsed_output,
                                 error=error_msg,
                                 exit_code=code,
                                 heal_attempts=heal_attempts
                             )
                             await self._transition(AgentState.FAILED)
                             break

                        # Detect Rate Limiting (429, Resource Exhausted)
                        rate_limit_indicators = [
                            "429", 
                            "rate limit", 
                            "too many requests", 
                            "resource has been exhausted", 
                            "quota exceeded"
                        ]
                        
                        is_rate_limited = any(indicator.lower() in error_msg.lower() for indicator in rate_limit_indicators)
                        
                        if is_rate_limited:
                            # Apply exponential backoff with jitter
                            wait_time = min(RATE_LIMIT_MAX_WAIT, RATE_LIMIT_BACKOFF_BASE * (2 ** heal_attempts))
                            jitter = random.uniform(0.5, 1.5)
                            total_wait = wait_time * jitter
                            
                            logger.warning(f"Task {self.session_id} hit rate limit. Waiting {total_wait:.2f}s before retry...")
                            await self._transition(AgentState.HEALING)
                            await asyncio.sleep(total_wait)
                            
                            # For rate limits, we don't necessarily update the prompt unless it keeps failing
                            if heal_attempts < DEFAULT_MAX_HEAL_RETRIES:
                                heal_attempts += 1
                                # We retry EXECUTING_PROCESS without prompt modification first
                                continue
                        
                        await self._transition(AgentState.VERIFICATION)
                    
                        if heal_attempts < max_retries:
                            heal_attempts += 1
                            logger.info(f"Task {self.session_id} failed. Attempting heal {heal_attempts}/{max_retries}...")
                            
                            lines_in, lines_out = self.workspace.get_diff_stats()
                            new_prompt = (
                                f"{original_prompt}\n\n"
                                f"--- AUTO-HEAL INITIATED (Attempt {heal_attempts}/{max_retries}) ---\n"
                                f"Your previous attempt failed with exit code: {code}\n"
                                f"Error output:\n```\n{error_msg}\n```\n"
                                f"Lines changed: +{lines_in} / -{lines_out}\n"
                                f"Please analyze the error and fix the implementation."
                            )
                            if "--prompt" in self.cmd:
                                idx = self.cmd.index("--prompt")
                                self.cmd[idx + 1] = new_prompt
                            
                            self.prompt = new_prompt
                            continue
                        else:
                            self.result = ExecutionResult(
                                status=AgentState.FAILED.name,
                                output=parsed_output,
                                error=error_msg,
                                exit_code=code,
                                heal_attempts=heal_attempts
                            )
                            await self._transition(AgentState.FAILED)
                            break
                    else:
                        if self.verify_cmd:
                            await self._transition(AgentState.VERIFICATION)
                            try:
                                v_res = subprocess.run(
                                    self.verify_cmd, shell=True, cwd=str(self.execution_cwd),
                                    capture_output=True, text=True, timeout=120
                                )
                                if v_res.returncode != 0:
                                    error_msg = f"Verification command failed with exit code {v_res.returncode}:\nSTDOUT:\n{v_res.stdout}\nSTDERR:\n{v_res.stderr}"
                                    if heal_attempts < max_retries:
                                        heal_attempts += 1
                                        logger.info(f"Task {self.session_id} failed verification. Attempting heal {heal_attempts}/{max_retries}...")
                                        
                                        lines_in, lines_out = self.workspace.get_diff_stats()
                                        new_prompt = (
                                            f"{original_prompt}\n\n"
                                            f"--- AUTO-HEAL INITIATED (Attempt {heal_attempts}/{max_retries}) ---\n"
                                            f"Your attempt finished, but failed post-execution verification: `{self.verify_cmd}`\n"
                                            f"Error output:\n```\n{error_msg}\n```\n"
                                            f"Lines changed: +{lines_in} / -{lines_out}\n"
                                            f"Please analyze the error and fix the implementation."
                                        )
                                        if "--prompt" in self.cmd:
                                            idx = self.cmd.index("--prompt")
                                            self.cmd[idx + 1] = new_prompt
                                        self.prompt = new_prompt
                                        continue
                                    else:
                                        self.result = ExecutionResult(
                                            status=AgentState.VALIDATION_FAILED.name,
                                            output=parsed_output,
                                            error=error_msg,
                                            exit_code=v_res.returncode,
                                            heal_attempts=heal_attempts
                                        )
                                        await self._transition(AgentState.VALIDATION_FAILED)
                                        break
                            except Exception as ve:
                                logger.error(f"Verification command execution failed: {ve}")

                        # Epic 3.2: Export Enforcement & Auto-Commit
                        # 1. Check for artifacts across high-value directories BEFORE auto-commit
                        has_valuable_artifacts = self.workspace.check_for_artifacts(["docs", "vault", "src"])
                        has_any_changes = self.workspace.check_for_artifacts()
                        
                        # Phase 5: Token Efficiency Analytics
                        lines_in, lines_out = self.workspace.get_diff_stats()
                        self.result.lines_added = lines_in
                        self.result.lines_removed = lines_out

                        # 2. Force an auto-commit to ensure work is NOT lost during cleanup/merge
                        if has_any_changes:
                            self.workspace.commit(f"auto-commit: sub-agent finished task {self.session_id}")
                        
                        # 3. Determine final status (Flag empty successes)
                        status_name = AgentState.COMPLETED.name
                        if not has_valuable_artifacts:
                            status_name = "COMPLETED (EMPTY)"
                            logger.warning(f"Task {self.session_id} finished but produced 0 artifacts in docs/ vault/ or src/.")
    
                        self.result.status = status_name
                        self.result.output = parsed_output
                        self.result.exit_code = 0
                        self.result.heal_attempts = heal_attempts
                        await self._transition(AgentState.COMPLETED, status_override=status_name)
                        break
    
                except Exception as e:
                    logger.error(f"FSM Error: {e}", exc_info=True)
                    self.result = ExecutionResult(status=AgentState.FAILED.name, error=str(e), heal_attempts=heal_attempts)
                    await self._transition(AgentState.FAILED)
                    break
            
        finally:
            self.result.duration = time.time() - self.start_time
            
            # Re-inject cumulative stats back into result.output if we have them
            if last_parsed_output and "stats" in last_parsed_output:
                last_parsed_output["stats"]["models"] = cumulative_models
                # Also ensure we don't break if 'tools' section is totally missing originally
                if "tools" not in last_parsed_output["stats"]:
                    last_parsed_output["stats"]["tools"] = {}
                last_parsed_output["stats"]["tools"]["totalCalls"] = cumulative_tools["totalCalls"]
                last_parsed_output["stats"]["tools"]["totalSuccess"] = cumulative_tools["totalSuccess"]
                last_parsed_output["stats"]["tools"]["totalFail"] = cumulative_tools["totalFail"]
                last_parsed_output["stats"]["tools"]["totalDurationMs"] = cumulative_tools["totalDurationMs"]
                self.result.output = last_parsed_output
            
            # Epic 1.2: Native Structured IPC output dump
            try:
                payload_path = self.session_dir / "fsm_payload_out.json"
                payload_data = {
                    "status": self.result.status,
                    "output": self.result.output,
                    "error": self.result.error,
                    "exit_code": self.result.exit_code,
                    "duration": self.result.duration,
                    "lines_added": self.result.lines_added,
                    "lines_removed": self.result.lines_removed,
                    "heal_attempts": getattr(self.result, "heal_attempts", 0)
                }
                payload_path.write_text(json.dumps(payload_data, indent=2))
            except Exception as dump_err:
                logger.error(f"Failed to dump fsm_payload_out.json: {dump_err}")
                
            # Epic 2.3 Cleanup: Kill the tmux monitoring session if it exists.
            # Once the task is in a terminal state, the monitoring window is no longer needed.
            if self.tmux_session:
                try:
                    subprocess.run(
                        ["tmux", "kill-session", "-t", self.tmux_session], 
                        check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
                    )
                    logger.debug(f"Killed tmux monitor: {self.tmux_session}")
                except Exception as e:
                    logger.debug(f"Failed to kill tmux monitor {self.tmux_session}: {e}")

            # Epic 2.2: Git Auto-Stashing (Native Sandboxing Cleanup)
            # If the agent crashes or fails, we forcefully evaporate the git worktree
            if self.result.status in [AgentState.FAILED.name, AgentState.VALIDATION_FAILED.name]:
                logger.info(f"Task {self.session_id} failed. Obliterating worktree sandbox to prevent corruption.")
                self.session_manager.remove_worktree(self.session_id)
                
        return self.result

    async def _transition(self, new_state: AgentState, status_override: Optional[str] = None):
        """Handle state transitions and notify session manager."""
        logger.info(f"State Transition: {self.state.name} -> {new_state.name}")
        
        if status_override:
            self._current_status_override = status_override
        elif new_state != self.state:
            self._current_status_override = None
            
        self.state = new_state
        
        # Persist state via SessionManager (Separation of Concerns)
        self.session_manager.update_registry(self.session_id, {
            "status": self._current_status_override or self.state.name,
            "prompt": self.prompt[:200] + "..." if len(self.prompt) > 200 else self.prompt,
            "full_prompt": self.prompt,
            "tmux_session": self.tmux_session,
            "start_time": self.start_time,
            "last_update": time.time(),
            "duration": time.time() - self.start_time if self.start_time > 0 else 0,
            "context_files_count": len(self.context_files),
            "session_dir": str(self.session_dir),
            "lane": self.lane
        })

    async def _fail(self, reason: str) -> ExecutionResult:
        self.result = ExecutionResult(status=AgentState.FAILED.name, error=reason)
        await self._transition(AgentState.FAILED)
        return self.result

    def _validate_context(self) -> bool:
        valid = True
        for f in self.context_files:
            if not Path(f).exists():
                logger.warning(f"Missing context file: {f}")
        return valid

    # Process execution and Workspace methods are now delegated to self.executor and self.workspace
    # Redundant methods removed to keep FSM lean.

    def _parse_output(self, raw_stdout: str, raw_stderr: str, exit_code: int) -> Dict[str, Any]:
        if not raw_stdout:
            return {
                "status": "failed",
                "error": "Empty output from Gemini CLI",
                "stderr": raw_stderr,
                "exit_code": exit_code
            }

        try:
            json_str = raw_stdout
            if "{" in raw_stdout:
                json_start = raw_stdout.find("{")
                json_end = raw_stdout.rfind("}") + 1
                if json_end > json_start:
                    json_str = raw_stdout[json_start:json_end]
            
            return json.loads(json_str)
        except json.JSONDecodeError:
            try:
                if "```json" in raw_stdout:
                    clean = raw_stdout.split("```json")[1].split("```")[0].strip()
                    return json.loads(clean)
            except (IndexError, json.JSONDecodeError):
                pass

            return {
                "error": "Failed to parse JSON output",
                "raw_stdout": raw_stdout,
                "raw_stderr": raw_stderr,
                "status": "fatal"
            }
