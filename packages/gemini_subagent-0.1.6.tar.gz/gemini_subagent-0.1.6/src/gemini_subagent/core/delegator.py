"""
Delegator: Core logic for sub-agent task management, context bundling, and execution.
"""

import os
import json
import asyncio
import logging
import shutil
from pathlib import Path
from typing import List, Optional

from gemini_subagent.config import (
    WORKSPACE_ROOT, SESSIONS_DIR, LOG_DIR, ENV, DEFAULT_TIMEOUT
)
from gemini_subagent.utils.metrics import log_metrics
from gemini_subagent.utils.logger import setup_gemini_logging
from gemini_subagent.infrastructure.repomix import RepomixClient
from gemini_subagent.infrastructure.session import SessionManager
from gemini_subagent.utils.prompts import render_worktree_prompt, render_fallback_prompt
from gemini_subagent.infrastructure.tmux import TmuxMonitor
from gemini_subagent.core.models import AgentState

logger = setup_gemini_logging("geminis-delegator")

def validate_identifier(name: str) -> bool:
    """Ensure name is safe (alphanumeric, -, _) to prevent path traversal."""
    if not name: return False
    return all(c.isalnum() or c in "-_" for c in name) and ".." not in name

def is_safe_path(p: str) -> bool:
    """Ensures a path resolves within the WORKSPACE_ROOT boundary."""
    try:
        path = Path(p).resolve()
        return str(path).startswith(str(WORKSPACE_ROOT.resolve()))
    except Exception:
        return False

def auto_bundle_context(
    context_files: List[str],
    include_rules: bool = True,
    include_workflows: Optional[List[str]] = None,
    include_personas: Optional[List[str]] = None,
    include_skills: Optional[List[str]] = None,
    task_prompt: str = "",
    slim: bool = False
) -> List[str]:
    """
    Bundle context files for the sub-agent.
    All workspace-relative paths (.agent/rules, .agent/workflows, etc.) are
    derived from WORKSPACE_ROOT at call-time so the tool works in any project
    layout without assumptions baked into config.
    """
    # Filter explicitly-provided context files for path traversal
    bundled = [p for p in context_files if is_safe_path(p)]
    if len(bundled) < len(context_files):
        logger.warning(f"Filtered out {len(context_files) - len(bundled)} context files due to out-of-boundary path safety check.")
        

    # Derive user-project paths dynamically — only include if they exist
    agent_dir      = WORKSPACE_ROOT / ".agent"
    active_context = WORKSPACE_ROOT / "active_context.md"
    workflows_dir  = agent_dir / "workflows"
    personas_dir   = agent_dir / "roles"
    skills_dir     = agent_dir / "skills"
    
    if include_rules and not slim:
        gemini_rules_path = WORKSPACE_ROOT / "GEMINI.md"
        if not gemini_rules_path.exists():
            default_rules = (
                "# Gemini Sub-Agent Workspace Rules\n\n"
                "> This file dictates project-wide rules for all `subgemi` autonomous agents.\n"
                "> Modify this file to change how sub-agents behave in this repository.\n\n"
                "## Core Execution Rules\n\n"
                "1. **Proactive Discovery:** You must use your terminal or search tools to discover relevant skills, workflows, and documentation inside the `.agent/` directory (if it exists) to guide your implementation.\n"
                "2. **Framework Alignment:** Check for other AI framework configs like `.cursor` or `./claude` and respect their stack directives.\n"
                "3. **Commit Often:** Make local git commits incrementally. NEVER push.\n"
                "4. **Artifacts:** Output all significant plans or technical designs to `vault/`.\n\n"
                "## Project Specific Directives\n\n"
                "- (Add your tech stack, coding standards, and constraints here)\n"
            )
            try:
                gemini_rules_path.write_text(default_rules)
                logger.info(f"Initialized GEMINI.md workspace rules at {gemini_rules_path}")
            except Exception as e:
                logger.warning(f"Could not initialize GEMINI.md: {e}")
        
        if gemini_rules_path.exists():
            bundled.append(str(gemini_rules_path))

    if active_context.exists():
        bundled.append(str(active_context))

    plans_dir = WORKSPACE_ROOT / "docs" / "plans"
    if plans_dir.exists() and not slim:
        keywords = set(task_prompt.lower().split())
        for plan_file in plans_dir.glob("*.md"):
            plan_name = plan_file.stem.lower()
            if any(word in plan_name for word in keywords if len(word) > 3):
                bundled.append(str(plan_file))

    if include_workflows:
        for wf_name in include_workflows:
            if not validate_identifier(wf_name):
                logger.warning(f"Skipping invalid workflow name: {wf_name}")
                continue
            wf_path = workflows_dir / f"{wf_name}.md"
            if wf_path.exists():
                bundled.append(str(wf_path))

    if include_personas:
        for p in include_personas:
            # 1. Try as explicit path (relative to CWD or absolute)
            if Path(p).exists():
                bundled.append(str(Path(p).resolve()))
                continue
            
            # 2. Try as a name within the personas directory
            if not validate_identifier(p):
                continue
            persona_path = personas_dir / f"{p}.md"
            if persona_path.exists():
                bundled.append(str(persona_path))
            else:
                logger.warning(f"Persona not found as path or name: {p}. Falling back to autonomous adoption.")
    
    # Try keyword auto-selection if no persona was bundled yet
    if not any(".agent/roles/" in b for b in bundled) and personas_dir.exists() and not slim:
        # Auto-decide persona based on prompt keywords
        keywords = set(task_prompt.lower().split())
        for persona_file in personas_dir.glob("*.md"):
            p_name = persona_file.stem.lower()
            if any(word in p_name for word in keywords if len(word) > 3):
                logger.info(f"Auto-selected persona: {persona_file.name}")
                bundled.append(str(persona_file))

    if include_skills:
        for skill_name in include_skills:
            if not validate_identifier(skill_name):
                logger.warning(f"Skipping invalid skill name: {skill_name}")
                continue
            skill_path = skills_dir / skill_name / "SKILL.md"
            if skill_path.exists():
                bundled.append(str(skill_path))

    return bundled

async def run_sub_agent(
    prompt: str,
    context_files: List[str],
    approval_mode: str = "auto_edit",
    lane: str = "default",
    background: bool = False,
    tmux: bool = True,
    repomix_targets: Optional[List[str]] = None,
    parent_id: Optional[str] = None,
    timeout: int = DEFAULT_TIMEOUT,
    verify_cmd: Optional[str] = None,
    model: Optional[str] = None,
    repomix_include: Optional[str] = None,
    repomix_exclude: Optional[str] = None
) -> str:
    """Execute the gemini CLI and manage the session lifecycle using FSM."""
    from gemini_subagent.core.engine import SubAgentFSM
    
    # 1. Initialize Session + Workspace Isolation
    session_manager = SessionManager(SESSIONS_DIR)
    session_data = session_manager.create_session(parent_id)
    session_id = session_data["id"]
    session_dir = session_data["dir"]   # temp dir for logs/repomix output

    # Attempt to create an isolated git worktree (V2 strict sandboxing)
    worktree_dir = session_manager.create_worktree(session_id)
    if not worktree_dir:
        logger.error(f"Failed to isolate workspace. Aborting task {session_id} to protect main repository.")
        session_manager.update_registry(session_id, {"status": "FAILED", "error": "Native Git sandboxing failed to initialize."})
        return session_id

    # Epic 3.1: Metadata Hardening — Lock the .git file to prevent sandbox jailbreaks
    git_meta = worktree_dir / ".git"
    if git_meta.exists():
        try:
            os.chmod(git_meta, 0o444)
            logger.debug(f"Hardened worktree metadata: {git_meta}")
        except Exception as e:
            logger.warning(f"Metadata hardening failed: {e}")

    # The agent's CWD must be strictly jailed to the worktree
    agent_cwd = worktree_dir
    branch_name = f"subgemi/{session_id}"
    
    # 2. Pack Repomix Context (Parallel)
    if repomix_targets:
        tasks = []
        for i, target in enumerate(repomix_targets):
            tasks.append(RepomixClient.pack(
                target, 
                session_dir, 
                index=i,
                include=repomix_include,
                exclude=repomix_exclude
            ))
        
        results = await asyncio.gather(*tasks)
        for packed_file in results:
            if packed_file:
                context_files.append(packed_file)

    def sanitize(text: str) -> str:
        return "".join(ch for ch in text if ch.isprintable() or ch in '\n\r\t')
    
    prompt = sanitize(prompt)

    gemini_path = shutil.which("gemini")
    if not gemini_path:
        error_msg = "Gemini CLI not found. Please install it or check PATH."
        logger.error(error_msg)
        return json.dumps({
            "status": "failed", 
            "error": error_msg,
            "context": {"lane": lane}
        })

    if worktree_dir:
        system_intro = render_worktree_prompt(
            worktree_dir=str(worktree_dir),
            branch_name=branch_name or "",
        )
    else:
        system_intro = render_fallback_prompt(
            session_dir=str(session_dir),
            workspace_root=str(WORKSPACE_ROOT),
        )
    
    full_prompt = system_intro + prompt
    valid_context = []
    for file_path in context_files:
        if os.path.exists(file_path):
            full_prompt += f" @{file_path}"
            valid_context.append(file_path)
        else:
            logger.warning(f"Context file not found: {file_path}")

    cmd = [
        "gemini", 
        "--prompt", full_prompt, 
        "--output-format", "json", 
        "--approval-mode", approval_mode,
        "--sandbox", "false",
        "--include-directories", str(WORKSPACE_ROOT)
    ]
    
    if model:
        cmd.extend(["--model", model])

    # 3. Setup Monitoring — tmux tails the log file in the temp session_dir
    tmux_session = None
    if background and tmux:
        tmux_session = TmuxMonitor.start_monitor(session_id, session_dir)

    if ENV == "DEV":
        logger.info(f"DEBUG [INPUT] Session: {session_id}")
        logger.info(f"DEBUG [INPUT] Prompt: {prompt}")
        logger.info(f"DEBUG [INPUT] Context Files ({len(valid_context)}): {valid_context}")

    fsm = SubAgentFSM(
        prompt=prompt,
        context_files=valid_context,
        session_dir=session_dir,      # Safe JSON/log directory
        execution_cwd=agent_cwd,      # Jail worktree directory
        cmd=cmd,
        session_manager=session_manager,
        session_id=session_id,
        tmux_session=tmux_session or None,
        lane=lane,
        timeout=timeout,
        verify_cmd=verify_cmd
    )
    
    # 4. Handle Execution
    if background:
        import sys
        import subprocess
        
        fsm_data = {
            "prompt": prompt,
            "context_files": valid_context,
            "session_dir": str(session_dir),
            "execution_cwd": str(agent_cwd),
            "cmd": cmd,
            "session_id": session_id,
            "tmux_session": tmux_session,
            "lane": lane,
            "timeout": timeout,
            "approval_mode": approval_mode,
            "verify_cmd": verify_cmd
        }
        payload_path = session_dir / "fsm_payload.json"
        payload_path.write_text(json.dumps(fsm_data))
        
        # Fire and forget: detach completely from this CLI's process tree
        subprocess.Popen(
            [sys.executable, "-m", "gemini_subagent.worker", str(payload_path)],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        return json.dumps({
            "status": AgentState.DETACHED.name,
            "session_id": session_id,
            "branch": branch_name,
            "worktree": str(worktree_dir) if worktree_dir else None,
            "tmux_session": tmux_session,
            "monitor_cmd": f"tmux attach -t {tmux_session}" if tmux_session else f"tail -f {LOG_DIR}/geminis_mcp.log",
            "context": {
                "files_count": len(valid_context),
                "lane": lane
            }
        })

    result = await fsm.run()
    output_data = result.output
    output_data["status"] = result.status
    output_data["lines_added"] = result.lines_added
    output_data["lines_removed"] = result.lines_removed
    output_data["heal_attempts"] = getattr(result, "heal_attempts", 0)
    output_data["context"] = {
        "files_count": len(valid_context),
        "lane": lane,
        "duration_ms": int(result.duration * 1000)
    }
    
    if ENV == "DEV":
        logger.info(f"DEBUG [OUTPUT] Foreground Session {session_id} finished")
        logger.info(f"DEBUG [OUTPUT] {json.dumps(output_data, indent=2)}")

    log_metrics(prompt, output_data, session_id, session_dir)
    # if result.status == AgentState.COMPLETED.name:
    #     session_manager.cleanup_session(session_dir, session_id)

    return json.dumps(output_data)
