import sys
import json
import asyncio
from pathlib import Path

from gemini_subagent.config import SESSIONS_DIR, ENV, DEFAULT_TIMEOUT
from gemini_subagent.infrastructure.session import SessionManager
from gemini_subagent.core.engine import SubAgentFSM
from gemini_subagent.utils.metrics import log_metrics
from gemini_subagent.utils.logger import setup_gemini_logging

logger = setup_gemini_logging("geminis-worker")

async def run_worker(payload_path: Path):
    if not payload_path.exists():
        logger.error(f"Worker missing payload at {payload_path}")
        return

    data = json.loads(payload_path.read_text())
    
    session_id = data["session_id"]
    session_dir = Path(data["session_dir"])
    execution_cwd = Path(data.get("execution_cwd", data["session_dir"]))
    prompt = data["prompt"]
    lane = data.get("lane", "default")
    valid_context = data.get("context_files", [])
    
    session_manager = SessionManager(SESSIONS_DIR)
    
    fsm = SubAgentFSM(
        prompt=prompt,
        context_files=valid_context,
        session_dir=session_dir,
        execution_cwd=execution_cwd,
        cmd=data["cmd"],
        session_manager=session_manager,
        session_id=session_id,
        tmux_session=data.get("tmux_session"),
        lane=lane,
        timeout=data.get("timeout", DEFAULT_TIMEOUT),
        approval_mode=data.get("approval_mode", "auto_edit"),
        verify_cmd=data.get("verify_cmd")
    )
    
    try:
        result = await fsm.run()
        output_data = result.output
        output_data["status"] = result.status
        output_data["lines_added"] = result.lines_added
        output_data["lines_removed"] = result.lines_removed
        output_data["heal_attempts"] = getattr(result, "heal_attempts", 0)
        output_data["context"] = {
            "files_count": len(valid_context),
            "lane": lane,
            "duration_ms": int(result.duration * 1000)
        }
        
        if ENV == "DEV":
            logger.info(f"DEBUG [OUTPUT] Background Session {session_id} finished")
            logger.info(f"DEBUG [OUTPUT] {json.dumps(output_data, indent=2)}")

        log_metrics(prompt, output_data, session_id, session_dir)
        
        # if result.status == "COMPLETED" or result.status == "success":
        #     session_manager.cleanup_session(session_dir, session_id)
            
    except Exception as e:
        logger.error(f"Background task {session_id} failed: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        logger.error("Worker invoked without payload path.")
        sys.exit(1)
        
    payload = Path(sys.argv[1])
    asyncio.run(run_worker(payload))
