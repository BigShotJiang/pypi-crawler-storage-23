from .joinquant import daily as _jq_daily

def daily():
    _jq_daily()
