# -*- coding: utf-8 -*-
"""
Created on Wed Feb  4 17:59:57 2026

@author: Porco Rosso
"""
