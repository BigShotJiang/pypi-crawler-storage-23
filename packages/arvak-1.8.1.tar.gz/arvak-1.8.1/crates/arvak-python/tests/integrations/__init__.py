"""Tests for Arvak framework integrations."""
