"""
Base Agent — LangGraph-compatible agent stub.
Replace this with your actual LangGraph graph.
"""


async def run_agent(query: str) -> str:
    """
    Stub agent. Replace with your LangGraph StateGraph logic.

    Example with LangGraph:
        from langgraph.graph import StateGraph
        graph = StateGraph(...)
        ...
    """
    # TODO: Wire up your LangGraph agent here
    return f"Agent received: {query} — wire up LangGraph here."