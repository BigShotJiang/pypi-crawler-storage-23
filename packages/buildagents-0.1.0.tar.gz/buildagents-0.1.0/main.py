def main():
    print("Hello from buildagents!")


if __name__ == "__main__":
    main()
