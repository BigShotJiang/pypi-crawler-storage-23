"""Model provider integrations."""
