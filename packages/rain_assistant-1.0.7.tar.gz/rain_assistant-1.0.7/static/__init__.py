# This file makes static/ discoverable by setuptools for pip packaging.
