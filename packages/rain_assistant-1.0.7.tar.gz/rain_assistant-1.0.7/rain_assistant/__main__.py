"""Allow running Rain with: python -m rain_assistant"""
from server import main

main()
