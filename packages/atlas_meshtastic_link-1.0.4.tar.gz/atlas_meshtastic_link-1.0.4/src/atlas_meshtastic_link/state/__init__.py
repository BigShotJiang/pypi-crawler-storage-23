"""Shared state — world state store, subscription leases, overhearing."""
from __future__ import annotations
