"""Transport layer — raw radio I/O, chunking, and reassembly."""
from __future__ import annotations
