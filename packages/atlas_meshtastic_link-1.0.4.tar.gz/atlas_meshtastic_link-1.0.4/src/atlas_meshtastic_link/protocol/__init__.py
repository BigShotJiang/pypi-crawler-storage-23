"""Protocol layer — envelope format, reliability, dedup, spool."""
from __future__ import annotations
