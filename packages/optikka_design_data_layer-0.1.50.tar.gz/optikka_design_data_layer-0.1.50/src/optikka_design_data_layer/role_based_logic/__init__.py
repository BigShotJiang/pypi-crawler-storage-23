"""Utility functions"""

from optikka_design_data_layer.role_based_logic.role_query_modifier import (
    modify_query_for_role,
)

__all__ = [
    "modify_query_for_role",
]
