# tvminer

Thin PyPI package that exposes `load_model` and `predict_batch` by delegating to the bundled `inference` extension (`.so`). The wheel includes the `.so`, so it works wherever it is installed (local, venv, Chutes, PyPI).

## Build (include .so in wheel)

From the **repository root** (parent of `pypi_package/`):

```bash
./pypi_package/build_with_so.sh
```

This copies `inference.cpython-*.so` from the repo root into `pypi_package/src/tvminer/`, then runs `python -m build`. The resulting wheel in `pypi_package/dist/` contains the `.so`; any `pip install` of that wheel will have the extension available.

You must build the `.so` first (e.g. `python setup_turbo_v2_py.py build_ext --inplace` in the repo root).

## Install

```bash
pip install /path/to/pypi_package/dist/tvminer-*.whl
# or from PyPI after publishing
pip install tvminer
```

## Publish to PyPI

After building with `build_with_so.sh`:

```bash
pip install twine
twine upload pypi_package/dist/*
```

## Usage

```python
from pathlib import Path
from tvminer import load_model, Miner, TVFrameResult, BoundingBox

miner = load_model(Path("/path/to/hf_repo"))
# or
miner = Miner(Path("/path/to/hf_repo"))

results = miner.predict_batch(batch_images, offset=0, n_keypoints=32)
```

`predict_batch` runs `self.inference.predict_batch(batch_images, offset, n_keypoints)` internally.
