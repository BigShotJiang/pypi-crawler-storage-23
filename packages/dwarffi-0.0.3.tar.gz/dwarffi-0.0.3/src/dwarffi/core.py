"""
Facade for dwarffi.core to maintain backwards compatibility.
"""

from .instances import *  # noqa: F403
from .parser import *  # noqa: F403
from .types import *  # noqa: F403
