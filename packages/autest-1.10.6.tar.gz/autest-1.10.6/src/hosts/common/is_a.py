

def List(obj):
    return isinstance(obj, list)
