"""
version.py

Author: Benevant Mathew
Date: 2026-02-23
"""
__version__ = "0.3.0"
__author__ = "Benevant Mathew"
__email__ = "benevantmathewv@gmail.com"
__release_date__="23-02-2026"

if __name__ == "__main__":
    print(__version__)
