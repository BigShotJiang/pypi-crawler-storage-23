# CLI Reference

All commands are run as `pincer <command>` (or `uv run pincer <command>` from the project). This page lists every command and its options.

---

## Main commands

### `pincer run`

Start the Pincer agent. Loads config, connects all configured channels (Telegram, WhatsApp, Discord), starts the scheduler, and runs until interrupted.

- Reads `.env` and `PINCER_*` environment variables.
- Prints provider, model, budget, data dir, then “Pincer is running!” and which channels are connected.
- No arguments.

```bash
pincer run
```

---

### `pincer config`

Print current configuration (resolved from env and `.env`). Useful to verify keys and paths without starting the agent.

- No arguments.

```bash
pincer config
```

---

### `pincer cost`

Show today’s API cost (from the cost tracker database).

- No arguments.

```bash
pincer cost
```

---

### `pincer init`

Interactive setup wizard. Prompts for:

- LLM provider (Anthropic / OpenAI)
- API keys
- Channels to enable (Telegram, WhatsApp, Discord)
- Optional: shell, memory, search, skills, etc.

Writes or updates `.env` in the current directory. Safe to run multiple times.

- No arguments.

```bash
pincer init
```

---

### `pincer doctor`

Health check: verify configuration and connections.

- Checks: env file, API keys, channel tokens, database path, skills dir.
- Can run connection tests (e.g. API reachability).
- Reports security-related checks (sandbox, scanner) when relevant.

- No arguments.

```bash
pincer doctor
```

---

### `pincer chat`

Interactive CLI chat. Talks to the same agent (same LLM and tools) but without any messaging app — input/output in the terminal.

- Uses the same config as `pincer run` (provider, model, tools, memory if enabled).
- Type messages and get replies; cost is printed when applicable.
- Exit with your shell’s EOF (e.g. Ctrl+D) or a command like `quit`.

- No arguments.

```bash
pincer chat
```

---

## Auth and pairing

### `pincer auth-google`

Run the Google OAuth consent flow for Google Calendar (and related) access. Opens a browser; after you sign in and approve, tokens are saved (e.g. `data/google_token.json`). One-time setup unless you revoke or tokens expire.

- No arguments.

```bash
pincer auth-google
```

---

### `pincer pair-whatsapp`

Start WhatsApp pairing. Prints a QR code in the terminal; scan it with WhatsApp on your phone (Linked Devices). After pairing, the WhatsApp channel can send and receive messages. Run once per device/session as needed.

- No arguments.

```bash
pincer pair-whatsapp
```

---

## Skills subcommands

All under `pincer skills <subcommand>`.

### `pincer skills list`

List all installed skills (bundled from `skills/` and user from `~/.pincer/skills/`). Shows name, version, number of tools, author, and source (bundled vs user).

- No arguments.

```bash
pincer skills list
```

---

### `pincer skills install <path>`

Install a skill from a directory. The path must be a directory containing `manifest.json` and `skill.py`. The scanner runs first; if the score is below 50, install is blocked. On success, the skill is copied to `~/.pincer/skills/<name>/`.

- **&lt;path&gt;** — Path to the skill directory (e.g. `./my_skill` or `/path/to/skill`).

```bash
pincer skills install ./my_skill
```

---

### `pincer skills create <name>`

Scaffold a new skill. Creates `skills/<name>/` with:

- `manifest.json` — name, version, description, one sample tool.
- `skill.py` — one sample function matching the tool.

- **&lt;name&gt;** — Skill name (directory and manifest `name`).

```bash
pincer skills create my_skill
```

---

### `pincer skills scan <path>`

Run the security scanner on a skill directory. Prints score (0–100), pass/fail (threshold 50), and a table of findings (severity, line, category, description, penalty). Does not install.

- **&lt;path&gt;** — Path to the skill directory.

```bash
pincer skills scan ./my_skill
```

---

## Summary table

| Command | Description |
|--------|-------------|
| `pincer run` | Start the agent (all channels + scheduler) |
| `pincer config` | Show current configuration |
| `pincer cost` | Show today’s API cost |
| `pincer init` | Interactive setup wizard |
| `pincer doctor` | Health check and connection tests |
| `pincer chat` | Interactive CLI chat (no messaging app) |
| `pincer auth-google` | Google OAuth for Calendar |
| `pincer pair-whatsapp` | WhatsApp QR pairing |
| `pincer skills list` | List installed skills |
| `pincer skills install <path>` | Install a skill (scan then copy) |
| `pincer skills create <name>` | Scaffold a new skill |
| `pincer skills scan <path>` | Run security scanner on a skill |

---

## Environment

All commands respect:

- **`.env`** in the current directory (or path set by your process).
- **Environment variables** with the `PINCER_` prefix (override `.env`).

Common ones: `PINCER_ANTHROPIC_API_KEY`, `PINCER_OPENAI_API_KEY`, `PINCER_TELEGRAM_BOT_TOKEN`, `PINCER_DISCORD_BOT_TOKEN`, `PINCER_DATA_DIR`, `PINCER_SKILLS_DIR`. See [Getting Started](GETTING_STARTED.md) and `.env.example` for the full list.
