# Sprint 4 Changelog

Sprint 4 added the **Discord** channel, the **skills** plugin system (loader, scanner, sandbox), and expanded the **CLI** (init, doctor, chat, skills). This document summarizes what was built for developers.

---

## Version

**0.4.0** (Sprint 4)

---

## Discord channel

- **Module:** `channels/discord_channel.py` (full implementation; no longer a stub.)
- **Library:** discord.py; optional install: `uv sync --extra discord` or `pip install discord.py`.
- **Config:** `PINCER_DISCORD_BOT_TOKEN` in env or `.env`.

**Features:**

- **DMs:** All messages in DMs are handled; one session per user.
- **Slash commands:**  
  - `/ask <question>` — Creates a thread, sends the question to the agent, replies in the thread; follow-up messages in that thread continue the same session.  
  - `/search <query>` — “Search the web for: &lt;query&gt;”; reply in channel.  
  - `/run <command>` — “Execute this: &lt;command&gt;”; reply in channel.  
  - `/status` — Embed with channels, tool count, today’s cost, model, version (0.4.0).
- **Threads:** Sessions keyed by `discord-thread-<thread_id>`. `/ask` and @mention create threads; replies and continuation happen in the thread.
- **Guild channels:** Bot responds only to **@mentions**; creates a thread for the reply and continues there.
- **Response formatting:** Plain, code blocks, or embeds (for long structured replies). Message splitting at 2000 chars.
- **Proactive send:** `send(user_id, text, thread_id=..., channel_id=...)` for scheduled/triggered messages.
- **Identity:** Discord user ID used as `user_id`; can be mapped via `PINCER_IDENTITY_MAP` for cross-channel identity.

---

## Skills system

- **Loader:** `tools/skills/loader.py` — SkillLoader, SkillManifest, LoadedSkill. Discovers skills from **bundled** (`skills/`) and **user** (`~/.pincer/skills/` or `PINCER_SKILLS_DIR`). Validates manifest (name, version, description, tools with name/description/input_schema). Imports `skill.py` and registers tools as `skill_name__tool_name`.
- **Scanner:** `tools/skills/scanner.py` — SkillScanner. Static analysis (AST + regex) for dangerous calls/imports, path traversal, env access. Score 0–100; pass threshold 50. Used **before** installing user skills; bundled skills are not scanned at startup.
- **Sandbox:** `tools/sandbox.py` — SandboxConfig, SandboxResult. Runs skill code in a subprocess with resource limits (memory, CPU), optional network whitelist, env isolation, timeout, temp HOME. Used when the agent invokes skill tools if sandbox is enabled.
- **Bundled skills:** Ten skills under `skills/`: e.g. weather, news, translate, youtube_summary, summarize_url, stock_price, pomodoro, habit_tracker, expense_tracker, git_status. Loaded automatically; no install step.
- **ToolRegistry:** Exposes **list_tools()** (used e.g. by Discord `/status`). All built-in and skill tools are registered there.

---

## CLI additions

- **`pincer init`** — Interactive setup wizard: provider, API keys, channels (Telegram, WhatsApp, Discord), optional features. Writes `.env`.
- **`pincer doctor`** — Health check: config, API keys, channels, DB, skills dir; optional connection and security checks.
- **`pincer chat`** — Interactive CLI chat using the same agent (no Telegram/WhatsApp/Discord); useful for testing.
- **`pincer skills`** subcommands:  
  - **list** — List all skills (bundled + user) with name, version, tools, author, source.  
  - **install &lt;path&gt;** — Scan directory; if pass, copy to `~/.pincer/skills/<name>`.  
  - **create &lt;name&gt;** — Scaffold `skills/<name>/` with manifest.json and skill.py.  
  - **scan &lt;path&gt;** — Run security scanner and print report (no install).

Existing commands unchanged: `run`, `config`, `cost`, `auth-google`, `pair-whatsapp`.

---

## Identity and config

- **Discord user ID:** Stored and used as the channel-specific user id; identity resolver can map it to `pincer_user_id` for proactive/cross-channel use.
- **Config:** New/used options: `discord_bot_token`, `PINCER_DISCORD_BOT_TOKEN`, `PINCER_SKILLS_DIR` (optional). See `.env.example` (Sprint 4 section).

---

## Docs and structure

- **docs/README.md** — Index of all docs (for the web).
- **docs/GETTING_STARTED.md** — Install, env setup, first run.
- **docs/DISCORD.md** — Discord setup, slash commands, threads, identity.
- **docs/SKILLS.md** — Skills: manifest, loader, scanner, sandbox, bundled skills, CLI.
- **docs/CLI_REFERENCE.md** — All CLI commands.
- **docs/ARCHITECTURE.md** — High-level architecture (channels, agent, tools, scheduler).
- **docs/SPRINT4.md** — This changelog.
- **docs/PROJECT_STRUCTURE.md** — Updated for 0.4.0: Sprint 4 row, Discord + skills + CLI, directory tree, module status (discord_channel full, tools/skills/, skills/).

---

## Summary table

| Area | Deliverable |
|------|-------------|
| Discord | Full channel: DMs, slash commands (/ask, /search, /run, /status), threads, @mention → thread, embeds, proactive send |
| Skills | SkillLoader, SkillScanner, Sandbox; manifest + skill.py; namespaced tools; 10 bundled skills; user install after scan |
| CLI | init, doctor, chat, skills list/install/create/scan |
| Identity | discord_user_id used; config for token and skills dir |
| Docs | README, GETTING_STARTED, DISCORD, SKILLS, CLI_REFERENCE, ARCHITECTURE, SPRINT4, PROJECT_STRUCTURE updated |

All of the above is aimed at **developer users** and is suitable for publication on the project’s web page.
