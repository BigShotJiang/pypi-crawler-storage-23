# Discord Channel

Pincer’s Discord channel lets users talk to the agent in DMs, guild channels (via @mention), and **threads**. Slash commands provide quick actions and always create or use a dedicated thread for conversation.

---

## Setup

### 1. Create a Discord application

1. Open [Discord Developer Portal](https://discord.com/developers/applications) and create a new application.
2. Go to **Bot** and add a bot. Copy the **Token** (this is `PINCER_DISCORD_BOT_TOKEN`).
3. Enable **Message Content Intent** and **Direct Messages** under Privileged Gateway Intents.
4. Under **OAuth2 → URL Generator**, select scopes: `bot`, `applications.commands`. Select permissions: **Send Messages**, **Create Public Threads**, **Send Messages in Threads**, **Read Message History**, **Use Slash Commands**, **Read Messages/View Channels**, **Embed Links**. Copy the generated URL and open it to invite the bot to your server.

### 2. Configure Pincer

Set the bot token in `.env`:

```bash
PINCER_DISCORD_BOT_TOKEN=your_bot_token_here
```

Or use `pincer init` and choose Discord when prompted.

### 3. Run the agent

```bash
pincer run
```

You should see `Discord connected` (or similar). If the token is missing, you’ll see `Discord skipped (no PINCER_DISCORD_BOT_TOKEN)`.

---

## Slash commands

All slash commands are registered when the bot connects. They may take a few seconds to appear in Discord.

| Command | Description |
|--------|-------------|
| `/ask <question>` | Ask the AI a question. Creates a **thread** with the question as the title and continues the conversation in that thread. |
| `/search <query>` | “Search the web for: &lt;query&gt;” — agent uses web search and replies in the channel. |
| `/run <command>` | “Execute this: &lt;command&gt;” — agent can use shell/tools and replies in the channel. |
| `/status` | Shows bot status: channels, tool count, today’s cost, model, version (0.4.0). |

- **`/ask`** always creates a new thread and sends the first reply there; the slash reply in the channel points to the thread (e.g. “Continuing in #thread-name”).
- **`/search`** and **`/run`** reply in the same channel (no thread).
- **`/status`** returns an embed with configuration and cost info.

---

## Conversation model

- **DM:** Every message is handled as a normal conversation. Session is keyed by Discord user ID; history is persisted.
- **Thread:** If the message is in a **thread** that belongs to this bot (created by `/ask` or by an @mention), the message is handled in that thread. Session is keyed by `discord-thread-<thread_id>` so each thread has its own conversation history.
- **Guild channel (no thread):** The bot only reacts to **@mentions**. When mentioned, it creates a **thread**, sends the reply there, and future messages in that thread continue the same session.

So:

- **DMs** → one session per user.
- **Threads** → one session per thread (`discord-thread-<id>`).
- **Guild** → respond only when @mentioned, then continue in the created thread.

---

## Identity

Discord users are identified by **Discord user ID** (`interaction.user.id` / `message.author.id`). This is used as `user_id` for sessions and for proactive messaging. Cross-channel identity (linking Discord to Telegram/WhatsApp) uses the same `IdentityResolver` and can map `discord:<id>` in `PINCER_IDENTITY_MAP` if you configure it.

---

## Proactive messages

The channel supports `send(user_id, text, **kwargs)`. You can pass:

- **`thread_id`** — send into that thread.
- **`channel_id`** — send into that channel.
- If neither is set, the bot opens a DM with the user and sends there.

So scheduled/triggered messages can target a specific thread or channel, or fall back to DM.

---

## Response formatting

- **Plain:** Short replies are sent as normal messages. Long replies are split at 2000 characters (Discord limit), preferring newlines then spaces.
- **Code:** If the reply is a single fenced code block (triple backticks), it’s sent as a code block.
- **Embed:** Longer, structured replies (e.g. with `##`, `###`, lists) can be turned into a Discord embed (title, description, fields) for readability.

Attachments (images, files) in user messages are passed to the agent; the agent can use tools (e.g. vision, file tools) to process them.

---

## Requirements

- **discord.py** (with `discord.py` extra). Install with:  
  `uv sync --extra discord` or `pip install discord.py`
- **Python 3.12+**
- **PINCER_DISCORD_BOT_TOKEN** set in the environment (or `.env`).

---

## Troubleshooting

| Issue | What to check |
|-------|----------------|
| Slash commands don’t appear | Wait 1–2 minutes after bot connect; re-invite with `applications.commands` scope. |
| “Discord login failed” | Token invalid or revoked; create a new token in the Developer Portal. |
| Bot doesn’t reply in channel | In guilds, the bot only replies to **@mentions**; in DMs it replies to every message. |
| “Something went wrong” on `/ask` | Check logs for exceptions (e.g. LLM, tools, or session errors). |

For full agent and tool behavior, see [Architecture](ARCHITECTURE.md) and [Getting Started](GETTING_STARTED.md).
