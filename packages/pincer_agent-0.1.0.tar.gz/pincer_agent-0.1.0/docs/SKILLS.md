# Skills System

Skills are **plugins** that add tools to the Pincer agent. Each skill is a directory with a manifest and Python code. The agent can call skill tools like any built-in tool; names are namespaced to avoid collisions.

---

## Overview

- **Bundled skills:** Shipped in the repo under `skills/` (e.g. `weather`, `translate`, `news`). Loaded at startup without scanning.
- **User skills:** Installed in `~/.pincer/skills/` (or `PINCER_SKILLS_DIR`). Scanned for security before install; loaded at startup.
- **Tool names:** Registered as `skill_name__tool_name` (e.g. `weather__get_weather`) so they don’t clash with built-in or other skills.
- **Execution:** Skill functions can run in a **sandbox** (subprocess with resource limits, network whitelist, env isolation, timeout).

---

## Skill layout

A skill is a directory containing:

| File | Purpose |
|------|---------|
| `manifest.json` | Metadata and tool definitions (name, description, input schema). |
| `skill.py` | Python module that implements the tool functions declared in the manifest. |

Example:

```
my_skill/
├── manifest.json
└── skill.py
```

---

## Manifest format

`manifest.json` must include:

- **`name`** (string) — Skill name (used for namespacing and display).
- **`version`** (string) — e.g. `"0.1.0"`.
- **`description`** (string) — Short description of the skill.
- **`tools`** (array) — Non-empty list of tool definitions.

Each tool in `tools` must have:

- **`name`** — Function name in `skill.py` (e.g. `get_weather`).
- **`description`** — Shown to the LLM.
- **`input_schema`** (optional) — JSON Schema for parameters; default `{"type": "object", "properties": {}}`.

Optional top-level fields:

- **`author`**
- **`permissions`** (list of strings)
- **`env_required`** (list of env var names the skill needs)

Example:

```json
{
  "name": "weather",
  "version": "0.1.0",
  "description": "Get current weather",
  "author": "Pincer",
  "permissions": ["network"],
  "env_required": ["PINCER_OPENWEATHERMAP_API_KEY"],
  "tools": [
    {
      "name": "get_weather",
      "description": "Get current weather for a city.",
      "input_schema": {
        "type": "object",
        "properties": {
          "city": { "type": "string", "description": "City name" }
        },
        "required": ["city"]
      }
    }
  ]
}
```

---

## Implementing tools in `skill.py`

- Each tool in `manifest.json` must correspond to a **callable** in `skill.py` with the same **name** (e.g. `get_weather`).
- Functions can be sync; they are run in the event loop or in the sandbox runner. Signatures should accept the parameters defined in `input_schema` (e.g. keyword arguments).
- Return value should be JSON-serializable (the agent receives it as tool result). Typically return a `dict` (e.g. `{"result": "..."}`) or a string.

Example:

```python
def get_weather(city: str) -> dict:
    """Get current weather for a city."""
    # ... call API ...
    return {"city": city, "temp": 20, "conditions": "Sunny"}
```

---

## Loader and discovery

- **SkillLoader** discovers skills from:
  1. **Bundled:** `<project>/skills/` (or configured path).
  2. **User:** `~/.pincer/skills/` (or `PINCER_SKILLS_DIR`).
- A valid skill dir must contain both `manifest.json` and `skill.py`. Other files (e.g. `SKILL.md`) are ignored for loading.
- Loader parses manifests, validates required fields, builds a stable **skill_id** (hash of name + path), and imports `skill.py` to collect tool functions. Tools are registered with the registry under `skill_name__tool_name`.

---

## Security: scanner

Before **installing** a user skill (copying it into `~/.pincer/skills/`), Pincer runs a **security scanner** on the skill directory.

- **SkillScanner** does static analysis (AST + regex) on Python files in the directory.
- It looks for dangerous patterns: e.g. `eval`, `exec`, `subprocess`, `open`, sensitive imports (`subprocess`, `ctypes`, `socket`, etc.), path traversal (`../`, `/etc/`, etc.), and broad env access.
- Each finding has a **severity** (critical, warning, info) and a **penalty**. A **score** is computed (e.g. 100 minus penalties); **pass threshold is 50**.
- If the score is below 50, **install is blocked** and the skill is not copied. Bundled skills are **not** scanned at startup; only user installs are.

Run the scanner without installing:

```bash
pincer skills scan /path/to/skill
```

---

## Sandbox (optional)

- **Sandbox** runs skill code in a **subprocess** with:
  - Resource limits (memory, CPU) via `resource.setrlimit`
  - Optional network domain whitelist (e.g. only allowed hosts)
  - Environment variable isolation (only declared vars passed)
  - Timeout and SIGKILL
  - Temporary HOME for filesystem isolation
- Configuration is via **SandboxConfig** (timeout, max memory, allowed_domains, allowed_env_vars, etc.). If sandbox is enabled for skills, the loader/scheduler uses it when invoking skill tools.

---

## Bundled skills (Sprint 4)

The repo ships several skills under `skills/`:

| Skill | Description |
|-------|-------------|
| `weather` | Weather via OpenWeatherMap (uses `PINCER_OPENWEATHERMAP_API_KEY`) |
| `news` | News headlines (e.g. NewsAPI) |
| `translate` | Text translation |
| `youtube_summary` | Summarize YouTube content |
| `summarize_url` | Summarize a URL |
| `stock_price` | Stock price lookup |
| `pomodoro` | Pomodoro timer |
| `habit_tracker` | Habit tracking |
| `expense_tracker` | Expense tracking |
| `git_status` | Git status / repo info |

These are loaded automatically when you run the agent; no install step. User-installed skills in `~/.pincer/skills/` are loaded in addition.

---

## CLI: skills commands

| Command | Description |
|--------|-------------|
| `pincer skills list` | List all discovered skills (bundled + user) with name, version, tools count, author, source. |
| `pincer skills install <path>` | Scan the directory, then if pass, copy it to `~/.pincer/skills/<name>`. |
| `pincer skills create <name>` | Scaffold a new skill under `skills/<name>/` with `manifest.json` and `skill.py`. |
| `pincer skills scan <path>` | Run the security scanner and print score and findings (no install). |

See [CLI Reference](CLI_REFERENCE.md) for full CLI docs.

---

## Creating a new skill (quick start)

1. **Scaffold:**  
   `pincer skills create my_skill`  
   This creates `skills/my_skill/manifest.json` and `skills/my_skill/skill.py`.

2. **Edit manifest:** Set `name`, `description`, and the `tools` list (name, description, `input_schema`).

3. **Implement:** In `skill.py`, implement functions with the same names as in `tools[].name`.

4. **Test:** Run the agent and ask it to use your tool (e.g. “use my_skill’s action with input hello”).

5. **Optional – install as user skill:**  
   `pincer skills scan skills/my_skill` then `pincer skills install skills/my_skill`  
   (Or keep it under repo `skills/` and use it as a bundled skill.)

---

## Tool registry integration

- The agent’s **ToolRegistry** holds both built-in and skill tools.
- **list_tools()** returns all registered tools (used e.g. by Discord `/status` for “Tools” count).
- The LLM receives tool schemas with names like `weather__get_weather`; when it chooses that tool, the registry dispatches to the correct skill function (optionally via sandbox).

For architecture of the agent and tools, see [Architecture](ARCHITECTURE.md).
