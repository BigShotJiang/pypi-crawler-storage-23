# Pincer Documentation

Developer documentation for **Pincer** — a personal AI agent you can talk to on Telegram, WhatsApp, and Discord.

**Version:** 0.4.0 (Sprint 4)  
**License:** MIT

---

## Documentation Index

| Document | Description |
|----------|-------------|
| [Getting Started](GETTING_STARTED.md) | Installation, environment setup, first run |
| [Architecture](ARCHITECTURE.md) | System design, data flow, components |
| [Discord](DISCORD.md) | Discord channel setup, slash commands, threads |
| [Skills System](SKILLS.md) | Plugin system: loader, scanner, sandbox, bundled skills |
| [CLI Reference](CLI_REFERENCE.md) | All CLI commands (`pincer run`, `init`, `doctor`, `skills`, etc.) |
| [Sprint 4 Changelog](SPRINT4.md) | What was built in Sprint 4 |
| [Project Structure](PROJECT_STRUCTURE.md) | Directory tree, module status, sprint history |

---

## Quick Links

- **Run the agent:** `pincer run`
- **Interactive setup:** `pincer init`
- **Health check:** `pincer doctor`
- **CLI chat (no app):** `pincer chat`
- **List skills:** `pincer skills list`
- **Scan a skill:** `pincer skills scan <path>`

---

## Channels

| Channel | Description |
|---------|-------------|
| **Telegram** | Full bot: text, voice, images, streaming. Set `PINCER_TELEGRAM_BOT_TOKEN`. |
| **WhatsApp** | Via neonize; QR pairing, DMs and groups. Set `PINCER_WHATSAPP_ENABLED` and allowlist. |
| **Discord** | Slash commands (`/ask`, `/search`, `/run`, `/status`), DMs, threads. Set `PINCER_DISCORD_BOT_TOKEN`. |
| **CLI** | `pincer chat` for testing without messaging apps. |

---

## For Contributors

- Code lives in `src/pincer/`. Entry points: `cli.py`, `__main__.py`.
- Tests: `pytest` in `tests/`. Run with `uv run pytest tests/ -v`.
- Lint: `ruff check src/ tests/`.
- Migrations: `data/migrations/` (SQLite; applied in code on startup where needed).
