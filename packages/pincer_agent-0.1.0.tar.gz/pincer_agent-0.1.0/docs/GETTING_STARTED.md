# Getting Started

This guide gets you from zero to a running Pincer agent.

---

## Prerequisites

- **Python 3.12+** (recommended: use [uv](https://docs.astral.sh/uv/) for installs)
- At least one channel configured (Telegram, WhatsApp, or Discord)
- An LLM API key (Anthropic and/or OpenAI)

---

## Installation

### Option A: From source (development)

```bash
git clone https://github.com/vpu2301/pincer.git
cd pincer/pincer
uv sync
```

### Option B: With uv (recommended)

```bash
cd pincer
uv sync
```

This installs the project and dependencies from `pyproject.toml`. Optional groups (search, browser, skills, etc.) can be installed with:

```bash
uv sync --extra all
```

---

## Configuration

### 1. Create `.env`

```bash
cp .env.example .env
```

Edit `.env` and set at minimum:

- **LLM:** `PINCER_ANTHROPIC_API_KEY` and/or `PINCER_OPENAI_API_KEY`
- **At least one channel:** e.g. `PINCER_TELEGRAM_BOT_TOKEN` or `PINCER_DISCORD_BOT_TOKEN`

### 2. Interactive setup (optional)

```bash
uv run pincer init
```

This wizard prompts for provider, API keys, channels (Telegram, WhatsApp, Discord), preferences, and optional integrations, then writes `.env` for you.

### 3. Environment variables reference

| Variable | Required | Description |
|----------|----------|-------------|
| `PINCER_ANTHROPIC_API_KEY` | For Anthropic | Claude API key |
| `PINCER_OPENAI_API_KEY` | For OpenAI / voice | OpenAI API key; also used for voice transcription |
| `PINCER_TELEGRAM_BOT_TOKEN` | For Telegram | From [@BotFather](https://t.me/BotFather) |
| `PINCER_WHATSAPP_ENABLED` | For WhatsApp | `true` to enable |
| `PINCER_WHATSAPP_DM_ALLOWLIST` | If WhatsApp | Comma-separated phone numbers |
| `PINCER_DISCORD_BOT_TOKEN` | For Discord | From Discord Developer Portal → Bot → Token |
| `PINCER_DAILY_BUDGET_USD` | Optional | Daily spend limit (default 5.0) |
| `PINCER_DATA_DIR` | Optional | Data directory (default `~/.pincer`) |

All other variables are documented in `.env.example`.

---

## First Run

```bash
uv run pincer run
```

You should see:

- Provider and model
- Loaded tools and skills
- Which channels connected (e.g. `Telegram connected`, `Discord connected`)
- `Pincer is running! Channels: ...`

If a channel is skipped (e.g. no token), you may see a dim message like `Discord skipped (no PINCER_DISCORD_BOT_TOKEN)`.

---

## Health Check

Before or after run, verify configuration:

```bash
uv run pincer doctor
```

This reports:

- Config (env file, API keys, channels, DB, skills)
- Connection tests (API reachability)
- Security-related checks (sandbox, scanner)

---

## Data Directory

By default Pincer uses `~/.pincer/` for:

- SQLite database (`pincer.db`)
- Session and identity data
- User skills directory (`~/.pincer/skills/`)

Override with `PINCER_DATA_DIR` in `.env`.

---

## Next Steps

- [Discord](DISCORD.md) — Set up the Discord bot and slash commands
- [Skills System](SKILLS.md) — Use and create skills
- [CLI Reference](CLI_REFERENCE.md) — All `pincer` commands
