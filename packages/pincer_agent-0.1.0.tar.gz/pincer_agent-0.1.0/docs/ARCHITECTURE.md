# Architecture

High-level design of Pincer for developers. The system is built around a single agent core, multiple channels, a shared tool registry, and optional memory and scheduling.

---

## Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         User                                      │
│           Telegram  ·  WhatsApp  ·  Discord  ·  CLI                │
└────────┬─────────────────┬─────────────────┬─────────────────────┘
         │                 │                 │
   ┌─────▼─────┐    ┌──────▼──────┐   ┌─────▼─────┐
   │ Telegram  │    │  WhatsApp   │   │  Discord  │
   │ Channel   │    │  Channel    │   │  Channel  │
   │ (aiogram) │    │  (neonize)  │   │(discord.py)│
   └─────┬─────┘    └──────┬──────┘   └─────┬─────┘
         │                 │                 │
   ┌─────▼─────────────────▼─────────────────▼─────┐
   │              Identity Resolver                 │
   │        (cross-channel user mapping)            │
   └─────────────────────┬─────────────────────────┘
                          │
   ┌──────────────────────▼──────────────────────┐
   │                 Agent Core                    │
   │   ReAct loop · tools · streaming · sessions   │
   └──┬──────────────┬──────────────┬─────────────┘
      │              │              │
  ┌───▼───┐    ┌─────▼─────┐  ┌────▼─────────────┐
  │  LLM  │    │  Memory    │  │  Tool Registry   │
  │Provider│   │  Store     │  │  built-in +      │
  │Anthropic│  │  (SQLite   │  │  skills          │
  │ OpenAI │   │   + FTS5)  │  │  (skill__tool)   │
  └────────┘   └────────────┘  └──────────────────┘

   ┌──────────────────────────────────────────────┐
   │              Scheduler                        │
   │   Cron · Triggers · Briefings                 │
   │              ↓                                │
   │        Channel Router                         │
   │   (proactive message delivery)                │
   └──────────────────────────────────────────────┘
```

---

## Channels

- **BaseChannel** (in `channels/base.py`): abstract interface. Each channel turns platform events into **IncomingMessage** (user_id, display_name, text, attachments, session_channel) and sends replies via `send()`.
- **Session channel:** A string that identifies the conversation (e.g. `telegram`, `whatsapp`, `discord`, `discord-thread-123`). One session per (user_id, session_channel); history is isolated per thread/DM/channel as appropriate.
- **Identity resolver:** Maps platform-specific IDs (Telegram user id, WhatsApp phone, Discord user id) to a stable **pincer_user_id** so proactive messages and briefings can target the same user across channels. Optional `PINCER_IDENTITY_MAP` for explicit mapping.
- **Router:** For proactive/scheduled messages, the router looks up which channel(s) to use for a given `pincer_user_id` and calls the right channel’s `send()`.

---

## Agent core

- **ReAct loop:** The agent receives the user message plus session history, calls the LLM with tool schemas, gets back either a text reply or tool calls. It executes tools (built-in or skill), appends results to the conversation, and repeats until the model returns a final answer. That answer is streamed or returned to the channel.
- **Streaming:** Supported for Telegram (and optionally others); tokens are sent as they arrive. Discord/CLI may get the full reply in one go.
- **Sessions:** SessionManager loads/saves conversation history per (user_id, session_channel). History is trimmed and optionally summarized; tool_use/tool_result pairs are kept together when trimming.
- **Sanitization:** Before each LLM call, the agent can fix orphaned tool_use/tool_result messages to avoid API errors.
- **Cost and budget:** CostTracker records token usage per model; daily budget is enforced (configurable). Circuit breakers and retries handle transient failures.

---

## LLM providers

- **BaseLLMProvider:** Common interface (complete + stream, tool use). Implementations: **AnthropicProvider**, **OpenAIProvider**. Ollama is stubbed.
- **Config:** Provider and model are set via config (e.g. `PINCER_DEFAULT_PROVIDER`, `PINCER_DEFAULT_MODEL`). Voice transcription uses OpenAI when needed.

---

## Tool registry

- **ToolRegistry:** Registers tools by name with a JSON schema (parameters) and a handler. The agent gets a list of tool names and schemas; when the model returns a tool call, the registry dispatches to the handler.
- **Built-in tools:** Registered at startup (e.g. web_search, shell_exec, file_*, browse, calendar_*, email_*, send_image, transcribe, etc.). Some are gated by config (e.g. shell_enabled).
- **Skills:** SkillLoader discovers bundled (`skills/`) and user (`~/.pincer/skills/`) skills, loads manifest + skill.py, and registers tools as `skill_name__tool_name`. **list_tools()** returns all tools (used e.g. by Discord `/status`). Skill code can run in a sandbox (subprocess, resource limits, timeout).

---

## Memory

- **MemoryStore:** SQLite with FTS5 for full-text search; stores and retrieves persistent facts across sessions.
- **Summarizer:** When session history grows, it can be summarized into a compact summary and trimmed; summarization is pair-safe (tool_use/tool_result kept together). Summary and recent messages are then used as context.

---

## Scheduler

- **Cron:** SQLite-backed cron jobs; timezone-aware (croniter). Runs on a tick (e.g. every minute).
- **Proactive agent:** Morning briefing (weather, calendar, email, news) assembled and sent via the channel router to the user’s preferred channel.
- **Triggers:** Event-driven (e.g. new email, calendar reminder, webhook). Deduplication via DB. When fired, they trigger agent or direct message delivery via the router.

---

## Data and config

- **Config:** Pydantic Settings; reads `.env` and `PINCER_*` env vars. Holds API keys, model, channels, paths, feature flags (memory, shell, etc.).
- **Data directory:** Default `~/.pincer` (override with `PINCER_DATA_DIR`). Contains SQLite DB (sessions, memory, cost, identity, cron, triggers), user skills dir, and optionally Google tokens etc.
- **Migrations:** SQL migrations in `data/migrations/` applied on startup as needed.

---

## Entry points

- **CLI:** `pincer` (or `python -m pincer`) is implemented with Typer in `cli.py`. Commands: run, config, cost, init, doctor, chat, auth-google, pair-whatsapp, skills list/install/create/scan.
- **Run:** `pincer run` loads config, creates LLM, session manager, cost tracker, memory/summarizer if enabled, builds ToolRegistry (built-in + skills), creates channels (Telegram, WhatsApp, Discord) and passes the agent to them, starts the scheduler, and runs until shutdown.

---

## Key patterns

- **Channel abstraction:** Same agent regardless of channel; channels adapt platform APIs to IncomingMessage + send().
- **Session channel:** Encodes “where” the conversation lives (e.g. Discord thread vs DM) so one user can have multiple concurrent conversations.
- **Identity:** One pincer_user_id per person across channels for proactive and cross-channel features.
- **Tool namespace:** Skills use `skill_name__tool_name` so the registry can host many skills without name clashes.
- **Security:** User-installed skills are scanned before install; optional sandbox runs skill code in a subprocess with limits and isolation.

For project layout and module list, see [Project Structure](PROJECT_STRUCTURE.md). For Sprint 4 additions (Discord, skills, CLI), see [Sprint 4 Changelog](SPRINT4.md).
