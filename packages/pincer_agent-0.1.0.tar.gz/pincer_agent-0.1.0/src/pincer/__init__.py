"""Pincer — Your personal AI agent. 🦀"""

__version__ = "0.1.0"
