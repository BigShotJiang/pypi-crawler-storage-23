"""Allow running with `python -m pincer`."""

from pincer.cli import app

app()
