from datetime import datetime

__versiondatetime__=datetime(2026,3,1,8,8)
__versiondate__ = __versiondatetime__.date()
__version__ = '2.0.0'