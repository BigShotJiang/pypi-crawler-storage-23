
class Returns:
    Changed=1
    Ignored=2
    Error=3

