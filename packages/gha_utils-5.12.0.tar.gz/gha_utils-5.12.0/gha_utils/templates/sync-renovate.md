---
title: Sync `renovate.json5`
---

### Description

Syncs the bundled [`gha_utils/data/renovate.json5`](https://github.com/kdeldycke/workflows/blob/main/gha_utils/data/renovate.json5) with the root [`renovate.json5`](https://github.com/kdeldycke/workflows/blob/main/renovate.json5). The bundled file is used when `gha-utils` is installed as a package.
