from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = "inertia.tests.testapp"
    verbose_name = "TestApp"
