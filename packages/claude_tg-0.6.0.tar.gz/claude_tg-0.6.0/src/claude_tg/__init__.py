"""claude-tg: Claude Code <-> Telegram bridge."""
__version__ = "0.7.0"
