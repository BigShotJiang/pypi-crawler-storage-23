import csv
import pathlib
import karrio.lib as lib
import karrio.core.units as units
import karrio.core.models as models


class BusinessUnit(lib.StrEnum):
    """DPD business unit codes."""

    DE = "001"
    FR = "002"
    NL = "010"
    GB = "011"
    AT = "014"
    CZ = "015"
    SK = "016"
    HU = "017"
    BG = "018"
    ES = "020"
    PL = "021"
    IT = "023"
    SI = "026"
    HR = "028"
    PT = "030"
    EE = "031"
    LT = "032"
    LV = "033"
    BE = "034"
    CH = "036"
    RO = "041"
    IE = "046"


class LabelFormat(lib.StrEnum):
    """DPD label format options - supports 18 formats from API."""

    PDF = "PDF"
    EPL = "EPL"
    ZPL = "ZPL"
    TIFF = "TIFF"
    PNG = "PNG"
    PPR = "PPR"
    SPD = "SPD"
    Z2D = "Z2D"
    THE = "THE"
    XML = "XML"
    XML2D = "XML2D"
    THEPSG = "THEPSG"
    ZPLPSG = "ZPLPSG"
    ZPL300 = "ZPL300"
    JSON = "JSON"
    PS = "PS"
    DATA = "DATA"
    CLP = "CLP"
    HTML = "HTML"


class LabelPaperFormat(lib.StrEnum):
    """DPD label paper size options."""

    A4 = "A4"
    A5 = "A5"
    A6 = "A6"
    A7 = "A7"


class LabelPrinterPosition(lib.StrEnum):
    """DPD label position on A4 paper."""

    UPPER_LEFT = "UPPER_LEFT"
    UPPER_RIGHT = "UPPER_RIGHT"
    LOWER_LEFT = "LOWER_LEFT"
    LOWER_RIGHT = "LOWER_RIGHT"


class DropOffType(lib.StrEnum):
    """DPD drop-off type options."""

    FULL_LABEL = "FULL_LABEL"
    QR_CODE = "QR_CODE"
    BOTH = "BOTH"


class ConnectionConfig(lib.Enum):
    """Carrier connection configuration options."""

    shipping_options = lib.OptionEnum("shipping_options", list)
    shipping_services = lib.OptionEnum("shipping_services", list)
    label_type = lib.OptionEnum("label_type", LabelPaperFormat, "A4")
    label_format = lib.OptionEnum("label_format", LabelFormat, "PDF")
    label_paper_format = lib.OptionEnum("label_paper_format", LabelPaperFormat)
    label_printer_position = lib.OptionEnum(
        "label_printer_position", LabelPrinterPosition
    )
    dropoff_type = lib.OptionEnum("dropoff_type", DropOffType)
    sending_depot = lib.OptionEnum("sending_depot")
    simulate = lib.OptionEnum("simulate", bool)
    extra_barcode = lib.OptionEnum("extra_barcode", bool)
    with_document = lib.OptionEnum("with_document", bool)


class PackagingType(lib.StrEnum):
    """Carrier specific packaging type"""

    PACKAGE = "PACKAGE"

    """Unified Packaging type mapping"""
    envelope = PACKAGE
    pak = PACKAGE
    tube = PACKAGE
    pallet = PACKAGE
    small_box = PACKAGE
    medium_box = PACKAGE
    your_packaging = PACKAGE


class ShippingService(lib.StrEnum):
    """DPD META-API product codes.

    Valid codes for DE (BU 001): CL, E830, E12, E18, IE2, PL, MAIL, MAX
    Codes may vary by business unit (country).
    """

    dpd_meta_classic = "CL"
    dpd_meta_express_830 = "E830"
    dpd_meta_express_12 = "E12"
    dpd_meta_express_18 = "E18"
    dpd_meta_international_express = "IE2"
    dpd_meta_parcel_letter = "PL"
    dpd_meta_mail = "MAIL"
    dpd_meta_max = "MAX"


class CustomsTerms(lib.StrEnum):
    """DPD customs terms (Incoterms)."""

    DAP_NOT_CLEARED = "s01"  # DAP, not cleared
    DDP_DUTIES_EXCL_TAXES = (
        "s02"  # DDP, delivered duty paid (incl. duties, excl. taxes)
    )
    DDP_DUTIES_INCL_TAXES = "s03"  # DDP, delivered duty paid (incl. duties and taxes)
    EXW = "s05"  # Ex Works
    DAP = "s06"  # DAP
    DAP_DDP_ENHANCED = "s07"  # DAP & DDP enhanced, duty/taxes pre-paid by receiver


class CustomsPaper(lib.StrEnum):
    """DPD customs accompanying documents."""

    COMMERCIAL_INVOICE = "A"
    PRO_FORMA_INVOICE = "B"
    EXPORT_DECLARATION = "C"
    EUR1 = "D"
    EUR2 = "E"
    ATR = "F"
    DELIVERY_NOTE = "G"
    THIRD_PARTY_BILLING = "H"
    T1_DOCUMENT = "I"


class ClearanceStatus(lib.StrEnum):
    """DPD customs clearance status."""

    NO = "N"
    FREE = "F"
    EXPORT_CLEARED = "E"
    TRANSIT_CLEARED = "T"
    IMPORT_CLEARED = "I"
    HYBRID = "H"


class CustomsValueLevel(lib.StrEnum):
    """DPD customs value classification."""

    HIGH = "H"  # High value
    MEDIUM = "M"  # Mid (above 22€ and below 150€)
    LOW = "L"  # Low value


class ExportReason(lib.StrEnum):
    """DPD export reason codes."""

    SALE = "s01"
    RETURN_REPLACEMENT = "s02"
    GIFT = "s03"


class ParcelType(lib.StrEnum):
    """DPD international parcel type."""

    DOCUMENT = "D"
    NON_DOC = "P"


class CodCollectType(lib.StrEnum):
    """DPD COD collection type."""

    CASH = "s0"
    CROSSED_CHEQUE = "s1"
    CREDIT_CARD = "s2"
    DEFAULT = "s9"  # Default, depending on receiving BU


class BusinessType(lib.StrEnum):
    """DPD business type for legal entity."""

    PRIVATE = "P"
    BUSINESS = "B"


class Incoterm(lib.StrEnum):
    """Standard Incoterms mapping to DPD customs terms."""

    DAP = CustomsTerms.DAP
    DDP = CustomsTerms.DDP_DUTIES_INCL_TAXES
    DDU = CustomsTerms.DAP_NOT_CLEARED
    EXW = CustomsTerms.EXW

    # Standard mappings
    CFR = CustomsTerms.DAP
    CIF = CustomsTerms.DAP
    CIP = CustomsTerms.DAP
    CPT = CustomsTerms.DAP
    FCA = CustomsTerms.EXW
    FOB = CustomsTerms.EXW
    FAS = CustomsTerms.EXW


class CustomsContentType(lib.StrEnum):
    """Karrio unified customs content type to DPD export reason mapping."""

    sale = ExportReason.SALE
    merchandise = ExportReason.SALE
    gift = ExportReason.GIFT
    sample = ExportReason.SALE
    return_merchandise = ExportReason.RETURN_REPLACEMENT
    repair = ExportReason.RETURN_REPLACEMENT
    documents = ExportReason.SALE
    other = ExportReason.SALE


class ShippingOption(lib.Enum):
    """Carrier specific options"""

    # --- Delivery Options (Zustelloptionen) ---
    dpd_meta_saturday_delivery = lib.OptionEnum(
        "saturday_delivery",
        bool,
        help="Enable Saturday delivery service",
        meta=dict(category="DELIVERY_OPTIONS", configurable=True),
    )
    dpd_meta_small_parcel = lib.OptionEnum(
        "small_parcel",
        bool,
        help="Mark shipment as small package (Kleinpaket) for reduced rates",
        meta=dict(category="DELIVERY_OPTIONS", configurable=True),
    )
    dpd_meta_exchange_service = lib.OptionEnum(
        "exchange_service",
        bool,
        help="Enable exchange service (Austauschservice) — simultaneous delivery and pickup",
        meta=dict(category="DELIVERY_OPTIONS", configurable=True),
    )
    dpd_meta_ex_works = lib.OptionEnum(
        "ex_works",
        bool,
        help="Enable EX Works delivery mode",
        meta=dict(category="DELIVERY_OPTIONS", configurable=True),
    )
    dpd_meta_delivery_date_from = lib.OptionEnum(
        "delivery_date_from",
        str,
        help="Earliest delivery date (YYYY-MM-DD)",
        meta=dict(category="DELIVERY_OPTIONS", configurable=True),
    )
    dpd_meta_delivery_date_to = lib.OptionEnum(
        "delivery_date_to",
        str,
        help="Latest delivery date (YYYY-MM-DD)",
        meta=dict(category="DELIVERY_OPTIONS", configurable=True),
    )
    dpd_meta_delivery_time_from = lib.OptionEnum(
        "delivery_time_from",
        str,
        help="Earliest delivery time (HH:MM)",
        meta=dict(category="DELIVERY_OPTIONS", configurable=True),
    )
    dpd_meta_delivery_time_to = lib.OptionEnum(
        "delivery_time_to",
        str,
        help="Latest delivery time (HH:MM)",
        meta=dict(category="DELIVERY_OPTIONS", configurable=True),
    )

    # --- PUDO (Parcel Shop) Options ---
    dpd_meta_dropoff_type = lib.OptionEnum(
        "dropoff_type",
        str,
        help="Drop-off type for parcel shop delivery (FULL_LABEL, QR_CODE, BOTH)",
        meta=dict(category="PUDO", configurable=True),
    )
    dpd_meta_parcel_shop_id = lib.OptionEnum(
        "parcel_shop_id",
        str,
        help="DPD ParcelShop ID for shop delivery",
        meta=dict(category="PUDO", configurable=True),
    )

    # --- Notification Options (Predict) ---
    dpd_meta_notification_email = lib.OptionEnum(
        "notification_email",
        str,
        help="Email for delivery notifications (Predict service)",
        meta=dict(category="NOTIFICATION", configurable=True),
    )
    dpd_meta_notification_sms = lib.OptionEnum(
        "notification_sms",
        str,
        help="SMS number for delivery notifications",
        meta=dict(category="NOTIFICATION", configurable=True),
    )

    # --- Insurance Options (Zusatzversicherung) ---
    dpd_meta_insurance_description = lib.OptionEnum(
        "insurance_description",
        str,
        help="Free text description for additional insurance purpose",
        meta=dict(category="INSURANCE", configurable=True),
    )

    # --- COD Options (Nachnahme) ---
    dpd_meta_cod_collect_type = lib.OptionEnum(
        "cod_collect_type",
        str,
        help="COD collection type (cash, cheque, etc.)",
        meta=dict(category="COD", configurable=True),
    )
    dpd_meta_cod_bank_code = lib.OptionEnum(
        "cod_bank_code",
        str,
        help="Bank code for COD payment",
        meta=dict(category="COD", configurable=False),
    )
    dpd_meta_cod_bank_name = lib.OptionEnum(
        "cod_bank_name",
        str,
        help="Bank name for COD payment",
        meta=dict(category="COD", configurable=False),
    )
    dpd_meta_cod_bank_account_number = lib.OptionEnum(
        "cod_bank_account_number",
        str,
        help="Bank account number for COD payment",
        meta=dict(category="COD", configurable=False),
    )
    dpd_meta_cod_bank_account_name = lib.OptionEnum(
        "cod_bank_account_name",
        str,
        help="Account holder name for COD payment",
        meta=dict(category="COD", configurable=False),
    )
    dpd_meta_cod_iban = lib.OptionEnum(
        "cod_iban",
        str,
        help="IBAN for COD payment",
        meta=dict(category="COD", configurable=False),
    )
    dpd_meta_cod_bic = lib.OptionEnum(
        "cod_bic",
        str,
        help="BIC/SWIFT code for COD payment",
        meta=dict(category="COD", configurable=False),
    )
    dpd_meta_cod_purpose = lib.OptionEnum(
        "cod_purpose",
        str,
        help="Purpose text for COD payment",
        meta=dict(category="COD", configurable=True),
    )

    # --- Dangerous Goods Options (Gefahrgut Versand) ---
    dpd_meta_dangerous_goods = lib.OptionEnum(
        "dangerous_goods",
        bool,
        help="Enable shipment of dangerous goods (Gefahrgut)",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )
    dpd_meta_dg_identification_class = lib.OptionEnum(
        "dg_identification_class",
        str,
        help="Hazard identification number (Identifikationsklasse)",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )
    dpd_meta_dg_un_number = lib.OptionEnum(
        "dg_un_number",
        str,
        help="UN number for the hazardous material",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )
    dpd_meta_dg_weight = lib.OptionEnum(
        "dg_weight",
        float,
        help="Weight of dangerous goods package in kg",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )
    dpd_meta_dg_description = lib.OptionEnum(
        "dg_description",
        str,
        help="Detailed description of the dangerous goods",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )
    dpd_meta_dg_hazard_factor = lib.OptionEnum(
        "dg_hazard_factor",
        str,
        help="Factor defining the risk level of the hazardous goods",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )
    dpd_meta_dg_hazard_class = lib.OptionEnum(
        "dg_hazard_class",
        str,
        help="Official hazard classification (e.g. 3 for flammable liquids)",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )
    dpd_meta_dg_nag_entry = lib.OptionEnum(
        "dg_nag_entry",
        str,
        help="Not otherwise specified (N.A.G.) entry for hazardous goods",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )
    dpd_meta_dg_packing_group = lib.OptionEnum(
        "dg_packing_group",
        str,
        help="Packing group (I, II, III) indicating packaging strength",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )
    dpd_meta_dg_packing_code = lib.OptionEnum(
        "dg_packing_code",
        str,
        help="DPD-specific packaging code for dangerous goods",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )
    dpd_meta_dg_subsidiary_risks = lib.OptionEnum(
        "dg_subsidiary_risks",
        str,
        help="Additional hazard classifications (subsidiary risks)",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )
    dpd_meta_dg_tunnel_restriction_code = lib.OptionEnum(
        "dg_tunnel_restriction_code",
        str,
        help="Code defining tunnel access restrictions for hazardous goods",
        meta=dict(category="DANGEROUS_GOOD", configurable=True),
    )

    # --- Return Options (Retoure) ---
    dpd_meta_return_enabled = lib.OptionEnum(
        "return_enabled",
        bool,
        help="Enable DPD return label creation",
        meta=dict(category="RETURN", configurable=True),
    )
    dpd_meta_return_description = lib.OptionEnum(
        "return_description",
        str,
        help="Description or reason for the return shipment",
        meta=dict(category="RETURN", configurable=True),
    )
    dpd_meta_include_return_label = lib.OptionEnum(
        "include_return_label",
        bool,
        help="Add a printed return label with the outbound shipment (Beilegeretoure)",
        meta=dict(category="RETURN", configurable=True),
    )

    # --- Label Options (internal — not configurable in shipping method editor) ---
    dpd_meta_label_format = lib.OptionEnum(
        "label_format", str, meta=dict(configurable=False)
    )
    dpd_meta_label_paper_format = lib.OptionEnum(
        "label_paper_format", str, meta=dict(configurable=False)
    )
    dpd_meta_label_printer_position = lib.OptionEnum(
        "label_printer_position", str, meta=dict(configurable=False)
    )

    # --- Internal/Debug Options (not configurable) ---
    dpd_meta_simulate = lib.OptionEnum("simulate", bool, meta=dict(configurable=False))
    dpd_meta_extra_barcode = lib.OptionEnum(
        "extra_barcode", bool, meta=dict(configurable=False)
    )
    dpd_meta_with_document = lib.OptionEnum(
        "with_document", bool, meta=dict(configurable=False)
    )

    """Unified Option type mapping"""
    saturday_delivery = dpd_meta_saturday_delivery
    dangerous_good = dpd_meta_dangerous_goods
    label_format = dpd_meta_label_format
    label_paper_format = dpd_meta_label_paper_format
    label_printer_position = dpd_meta_label_printer_position
    dropoff_type = dpd_meta_dropoff_type
    simulate = dpd_meta_simulate
    extra_barcode = dpd_meta_extra_barcode
    with_document = dpd_meta_with_document
    cash_on_delivery = lib.OptionEnum(
        "cash_on_delivery",
        float,
        help="Cash on delivery amount",
        meta=dict(category="COD", configurable=True),
    )
    insurance = lib.OptionEnum(
        "insurance",
        float,
        help="Additional insurance value",
        meta=dict(category="INSURANCE", configurable=False),
    )
    declared_value = lib.OptionEnum(
        "declared_value",
        float,
        help="Declared value for customs",
        meta=dict(category="INVOICE", configurable=True),
    )
    currency = lib.OptionEnum(
        "currency", str, help="Currency code for values", meta=dict(configurable=False)
    )


def shipping_options_initializer(
    options: dict,
    package_options: units.ShippingOptions = None,
) -> units.ShippingOptions:
    """
    Apply default values to the given options.
    """

    if package_options is not None:
        options.update(package_options.content)

    def items_filter(key: str) -> bool:
        return key in ShippingOption  # type: ignore

    return units.ShippingOptions(options, ShippingOption, items_filter=items_filter)


class TrackingStatus(lib.Enum):
    on_hold = ["on_hold"]
    delivered = ["delivered"]
    in_transit = ["in_transit"]
    delivery_failed = ["delivery_failed"]
    delivery_delayed = ["delivery_delayed"]
    out_for_delivery = ["out_for_delivery"]
    ready_for_pickup = ["ready_for_pickup"]


class ShippingDocumentCategory(lib.StrEnum):
    """Carrier specific document category types.

    Maps DPD META document types to standard ShippingDocumentCategory.
    Values match the exact syntax used by DPD META API.
    """

    shipping_label = "shippingLabel"
    qr_code = "qrcode"


def load_services_from_csv() -> list:
    """
    Load service definitions from CSV file.
    CSV format: service_code,service_name,zone_label,country_codes,min_weight,max_weight,max_length,max_width,max_height,rate,currency,transit_days,domicile,international
    """
    csv_path = pathlib.Path(__file__).resolve().parent / "services.csv"

    if not csv_path.exists():
        # Fallback to simple default if CSV doesn't exist
        return [
            models.ServiceLevel(
                service_name="DPD Classic",
                service_code="dpd_meta_classic",
                currency="EUR",
                domicile=True,
                zones=[models.ServiceZone(rate=0.0)],
            )
        ]

    # Group zones by service
    services_dict: dict[str, dict] = {}

    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            service_code = row["service_code"]
            service_name = row["service_name"]

            # Map carrier service code to karrio service code
            karrio_service_code = ShippingService.map(service_code).name_or_key

            # Initialize service if not exists
            if karrio_service_code not in services_dict:
                services_dict[karrio_service_code] = {
                    "service_name": service_name,
                    "service_code": karrio_service_code,
                    "currency": row.get("currency", "EUR"),
                    "min_weight": (
                        float(row["min_weight"]) if row.get("min_weight") else None
                    ),
                    "max_weight": (
                        float(row["max_weight"]) if row.get("max_weight") else None
                    ),
                    "max_length": (
                        float(row["max_length"]) if row.get("max_length") else None
                    ),
                    "max_width": (
                        float(row["max_width"]) if row.get("max_width") else None
                    ),
                    "max_height": (
                        float(row["max_height"]) if row.get("max_height") else None
                    ),
                    "weight_unit": "KG",
                    "dimension_unit": "CM",
                    "domicile": row.get("domicile", "").lower() == "true",
                    "international": (
                        True if row.get("international", "").lower() == "true" else None
                    ),
                    "zones": [],
                }

            # Parse country codes
            country_codes = [
                c.strip() for c in row.get("country_codes", "").split(",") if c.strip()
            ]

            # Create zone
            zone = models.ServiceZone(
                label=row.get("zone_label", "Default Zone"),
                rate=float(row.get("rate", 0.0)),
                min_weight=float(row["min_weight"]) if row.get("min_weight") else None,
                max_weight=float(row["max_weight"]) if row.get("max_weight") else None,
                transit_days=(
                    int(row["transit_days"].split("-")[0]) if row.get("transit_days") else None
                ),
                country_codes=country_codes if country_codes else None,
            )

            services_dict[karrio_service_code]["zones"].append(zone)

    # Convert to ServiceLevel objects
    return [
        models.ServiceLevel(**service_data) for service_data in services_dict.values()
    ]


DEFAULT_SERVICES = load_services_from_csv()
