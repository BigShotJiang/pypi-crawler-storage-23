import random

from roundamix.simulator import PROFILES, kendall_inversion_count, run_simulation


EXPECTED_SHUFFLES = {
    ("balanced", 1): [3, 6, 8, 9, 11, 5, 0, 12, 1, 13, 10, 4, 7, 2],
    ("balanced", 7): [3, 0, 9, 1, 11, 7, 13, 8, 2, 10, 12, 5, 6, 4],
    ("balanced", 42): [4, 3, 6, 0, 8, 7, 9, 2, 10, 5, 12, 11, 1, 13],
    ("balanced", 99): [1, 4, 5, 0, 6, 13, 9, 7, 3, 10, 11, 8, 12, 2],
    ("jammy", 1): [1, 3, 2, 4, 9, 6, 5, 0, 10, 11, 13, 8, 7, 12],
    ("jammy", 7): [1, 4, 6, 8, 2, 12, 10, 0, 9, 3, 13, 5, 11, 7],
    ("jammy", 42): [4, 5, 8, 3, 10, 11, 9, 7, 1, 2, 13, 0, 12, 6],
    ("jammy", 99): [3, 4, 6, 10, 5, 13, 8, 12, 1, 0, 11, 9, 7, 2],
    ("drain_fast", 1): [1, 0, 3, 7, 2, 9, 11, 6, 8, 13, 5, 10, 12, 4],
    ("drain_fast", 7): [1, 0, 3, 5, 7, 2, 9, 4, 11, 6, 12, 8, 10, 13],
    ("drain_fast", 42): [1, 3, 7, 0, 2, 9, 11, 6, 4, 8, 10, 12, 5, 13],
    ("drain_fast", 99): [1, 3, 5, 7, 9, 11, 6, 2, 12, 4, 10, 8, 0, 13],
    ("chaotic", 1): [6, 2, 1, 0, 4, 9, 13, 11, 5, 12, 8, 3, 7, 10],
    ("chaotic", 7): [1, 11, 0, 10, 13, 8, 4, 5, 3, 2, 9, 7, 12, 6],
    ("chaotic", 42): [1, 2, 5, 3, 12, 8, 4, 7, 10, 0, 11, 6, 13, 9],
    ("chaotic", 99): [1, 2, 0, 6, 8, 5, 11, 4, 13, 3, 10, 9, 7, 12],
    ("optimized", 1): [4, 1, 5, 11, 9, 7, 13, 12, 2, 8, 3, 10, 0, 6],
    ("optimized", 7): [5, 10, 8, 12, 9, 11, 3, 1, 0, 7, 6, 4, 13, 2],
    ("optimized", 42): [11, 6, 1, 7, 5, 10, 2, 4, 8, 3, 0, 13, 9, 12],
    ("optimized", 99): [5, 0, 2, 1, 13, 4, 8, 10, 3, 7, 6, 11, 12, 9],
}


def _naive_kendall(order: list[int]) -> int:
    inv = 0
    for i in range(len(order)):
        for j in range(i + 1, len(order)):
            if order[i] > order[j]:
                inv += 1
    return inv


def test_profile_seed_determinism_regression() -> None:
    items = list(range(14))
    for (profile_name, seed), expected in EXPECTED_SHUFFLES.items():
        result = run_simulation(items, seed, PROFILES[profile_name])
        assert result.shuffled == expected


def test_same_seed_same_output() -> None:
    items = list(range(24))
    profile = PROFILES["optimized"]
    out1 = run_simulation(items, seed=1234, profile=profile).shuffled
    out2 = run_simulation(items, seed=1234, profile=profile).shuffled
    assert out1 == out2


def test_fast_kendall_matches_naive() -> None:
    rng = random.Random(2026)
    for n in (4, 8, 16, 32):
        for _ in range(40):
            perm = list(range(n))
            rng.shuffle(perm)
            assert kendall_inversion_count(perm) == _naive_kendall(perm)
