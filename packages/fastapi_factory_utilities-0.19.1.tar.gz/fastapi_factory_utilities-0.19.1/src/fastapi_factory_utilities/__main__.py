"""Re-Use the main function from the example module."""

from fastapi_factory_utilities.example import main

if __name__ == "__main__":
    main()
