from .exceptions import ValidationException


def validate_api_key(api_key: str):
    if not isinstance(api_key, str) or not api_key.strip():
        raise ValidationException("API key must be a non-empty string.")


def validate_temperature(temperature: float):
    if not isinstance(temperature, (int, float)):
        raise ValidationException("Temperature must be a number.")

    if not 0.0 <= temperature <= 2.0:
        raise ValidationException("Temperature must be between 0.0 and 2.0.")


def validate_max_output_tokens(max_output_tokens: int):
    if not isinstance(max_output_tokens, int):
        raise ValidationException("Max output tokens must be a number.")

    if max_output_tokens < 1:
        raise ValidationException("Max output tokens must be at least 1.")


def validate_max_messages(max_messages: int):
    if not isinstance(max_messages, int):
        raise ValidationException("Max messages must be an integer.")
    if max_messages < 1:
        raise ValidationException("Max messages must be at least 1.")


def validate_prompt(prompt: str):
    if not isinstance(prompt, str) or not prompt.strip():
        raise ValidationException("Prompt must be a non-empty string.")


def validate_message(message: str):
    if not isinstance(message, str) or not message.strip():
        raise ValidationException("Message must be a non-empty string.")


def validate_filepath(filepath: str):
    if not isinstance(filepath, str) or not filepath.strip():
        raise ValidationException("Filepath must be a non-empty string.")


def validate_language(language: str):
    if not isinstance(language, str) or not language.strip():
        raise ValidationException("Language must be a non-empty string.")
