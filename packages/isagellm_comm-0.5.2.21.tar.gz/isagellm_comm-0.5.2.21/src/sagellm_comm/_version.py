"""Version information for sagellm-comm."""

__version__ = "0.5.2.21"
