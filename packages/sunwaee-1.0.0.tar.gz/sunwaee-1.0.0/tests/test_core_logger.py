import logging
import os

import pytest


def _reload_logger():
    """Re-import logger module so _configure() re-reads the env."""
    import importlib
    import sunwaee.core.logger as mod
    importlib.reload(mod)
    return mod


def test_default_level_is_warning(monkeypatch):
    monkeypatch.delenv("SUNWAEE_LOG_LEVEL", raising=False)
    # Clear any existing handlers so _configure adds a fresh one
    root = logging.getLogger("sunwaee")
    root.handlers.clear()
    mod = _reload_logger()
    assert mod.get_logger("x").getEffectiveLevel() == logging.WARNING


def test_debug_level(monkeypatch):
    monkeypatch.setenv("SUNWAEE_LOG_LEVEL", "debug")
    root = logging.getLogger("sunwaee")
    root.handlers.clear()
    mod = _reload_logger()
    assert mod.get_logger("x").getEffectiveLevel() == logging.DEBUG


def test_info_level(monkeypatch):
    monkeypatch.setenv("SUNWAEE_LOG_LEVEL", "info")
    root = logging.getLogger("sunwaee")
    root.handlers.clear()
    mod = _reload_logger()
    assert mod.get_logger("x").getEffectiveLevel() == logging.INFO


def test_unknown_level_falls_back_to_warning(monkeypatch):
    monkeypatch.setenv("SUNWAEE_LOG_LEVEL", "bogus")
    root = logging.getLogger("sunwaee")
    root.handlers.clear()
    mod = _reload_logger()
    assert mod.get_logger("x").getEffectiveLevel() == logging.WARNING


def test_get_logger_name():
    from sunwaee.core.logger import get_logger
    logger = get_logger("some.module")
    assert logger.name == "sunwaee.some.module"


def test_configure_idempotent():
    """Calling _configure again when handlers already exist is a no-op."""
    from sunwaee.core import logger as mod
    before = len(logging.getLogger("sunwaee").handlers)
    mod._configure()
    after = len(logging.getLogger("sunwaee").handlers)
    assert before == after
