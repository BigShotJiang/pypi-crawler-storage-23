import pytest
from pathlib import Path
from sunwaee.core.fs import find_md, list_md, make_slug, read_md, search_md, write_md


def test_make_slug_basic():
    assert make_slug("Hello World", "fallback") == "hello-world"


def test_make_slug_special_chars():
    assert make_slug("C++ Notes!", "fallback") == "c-notes"


def test_make_slug_empty_falls_back():
    assert make_slug("", "my-id") == "my-id"


def test_make_slug_only_symbols_falls_back():
    assert make_slug("!!!", "my-id") == "my-id"


def test_write_and_read_roundtrip(tmp_path):
    path = tmp_path / "note.md"
    meta = {"id": "abc", "title": "Test", "tags": ["a", "b"]}
    write_md(path, meta, "Hello body")
    read_meta, body = read_md(path)
    assert read_meta["id"] == "abc"
    assert read_meta["title"] == "Test"
    assert read_meta["tags"] == ["a", "b"]
    assert body.strip() == "Hello body"


def test_write_creates_parent_dirs(tmp_path):
    path = tmp_path / "deep" / "dir" / "note.md"
    write_md(path, {"id": "x"}, "body")
    assert path.exists()


def test_list_md_empty_dir(tmp_path):
    assert list_md(tmp_path) == []


def test_list_md_nonexistent_dir(tmp_path):
    assert list_md(tmp_path / "missing") == []


def test_list_md_returns_md_files(tmp_path):
    (tmp_path / "a.md").write_text("---\ntitle: A\n---\n")
    (tmp_path / "b.md").write_text("---\ntitle: B\n---\n")
    (tmp_path / "other.txt").write_text("ignored")
    paths = list_md(tmp_path)
    assert len(paths) == 2
    assert all(p.suffix == ".md" for p in paths)


def test_find_md_by_id(tmp_path):
    write_md(tmp_path / "note.md", {"id": "abc123", "title": "My Note"}, "")
    result = find_md("abc123", tmp_path)
    assert result is not None
    assert result.name == "note.md"


def test_find_md_by_slug(tmp_path):
    write_md(tmp_path / "my-note.md", {"id": "x", "title": "My Note"}, "")
    result = find_md("my-note", tmp_path)
    assert result is not None


def test_find_md_by_title_case_insensitive(tmp_path):
    write_md(tmp_path / "note.md", {"id": "x", "title": "My Note"}, "")
    result = find_md("my note", tmp_path)
    assert result is not None


def test_find_md_not_found(tmp_path):
    assert find_md("nonexistent", tmp_path) is None


def test_search_md_matches_title(tmp_path):
    write_md(tmp_path / "a.md", {"id": "1", "title": "Python tips", "tags": []}, "")
    write_md(tmp_path / "b.md", {"id": "2", "title": "Rust notes", "tags": []}, "")
    results = search_md("python", tmp_path)
    assert len(results) == 1
    assert results[0].name == "a.md"


def test_search_md_matches_body(tmp_path):
    write_md(tmp_path / "a.md", {"id": "1", "title": "Note", "tags": []}, "Some async content here")
    write_md(tmp_path / "b.md", {"id": "2", "title": "Other", "tags": []}, "Nothing relevant")
    results = search_md("async", tmp_path)
    assert len(results) == 1


def test_search_md_matches_tags(tmp_path):
    write_md(tmp_path / "a.md", {"id": "1", "title": "Note", "tags": ["python", "dev"]}, "")
    write_md(tmp_path / "b.md", {"id": "2", "title": "Other", "tags": ["rust"]}, "")
    results = search_md("python", tmp_path)
    assert len(results) == 1


def test_search_md_no_match(tmp_path):
    write_md(tmp_path / "a.md", {"id": "1", "title": "Note", "tags": []}, "hello")
    assert search_md("nonexistent", tmp_path) == []
