import pytest
from sunwaee.config import (
    Caller,
    get_caller,
    get_default_workspace,
    get_module_dir,
    get_workspaces_base_dir,
    is_machine_caller,
    set_default_workspace,
)


def test_get_caller_default(monkeypatch):
    monkeypatch.delenv("SUNWAEE_CALLER", raising=False)
    assert get_caller() == Caller.HUMAN


def test_get_caller_api(monkeypatch):
    monkeypatch.setenv("SUNWAEE_CALLER", "api")
    assert get_caller() == Caller.API


def test_get_caller_sun(monkeypatch):
    monkeypatch.setenv("SUNWAEE_CALLER", "sun")
    assert get_caller() == Caller.SUN


def test_get_caller_invalid_falls_back_to_human(monkeypatch):
    monkeypatch.setenv("SUNWAEE_CALLER", "robot")
    assert get_caller() == Caller.HUMAN


def test_is_machine_caller_human(monkeypatch):
    monkeypatch.setenv("SUNWAEE_CALLER", "human")
    assert is_machine_caller() is False


def test_is_machine_caller_api(monkeypatch):
    monkeypatch.setenv("SUNWAEE_CALLER", "api")
    assert is_machine_caller() is True


def test_is_machine_caller_sun(monkeypatch):
    monkeypatch.setenv("SUNWAEE_CALLER", "sun")
    assert is_machine_caller() is True


def test_get_workspaces_base_dir_env(monkeypatch, tmp_path):
    monkeypatch.setenv("SUNWAEE_WORKSPACES_DIR", str(tmp_path / "ws"))
    assert get_workspaces_base_dir() == tmp_path / "ws"


def test_get_workspaces_base_dir_from_config(monkeypatch, tmp_path):
    monkeypatch.delenv("SUNWAEE_WORKSPACES_DIR", raising=False)
    monkeypatch.setenv("SUNWAEE_CONFIG_DIR", str(tmp_path / "config"))
    base = get_workspaces_base_dir()
    assert "workspaces" in str(base)


def test_get_default_workspace_env(monkeypatch):
    monkeypatch.setenv("SUNWAEE_WORKSPACE", "myws")
    assert get_default_workspace() == "myws"


def test_get_default_workspace_from_config(monkeypatch, tmp_path):
    monkeypatch.delenv("SUNWAEE_WORKSPACE", raising=False)
    monkeypatch.setenv("SUNWAEE_CONFIG_DIR", str(tmp_path / "config"))
    assert get_default_workspace() == "personal"


def test_set_default_workspace(monkeypatch, tmp_path):
    monkeypatch.delenv("SUNWAEE_WORKSPACE", raising=False)
    monkeypatch.setenv("SUNWAEE_CONFIG_DIR", str(tmp_path / "config"))
    set_default_workspace("pro")
    assert get_default_workspace() == "pro"


def test_get_module_dir(monkeypatch, tmp_path):
    monkeypatch.setenv("SUNWAEE_WORKSPACES_DIR", str(tmp_path / "ws"))
    d = get_module_dir("personal", "notes")
    assert d == tmp_path / "ws" / "personal" / "notes"


def test_config_file_created_on_first_load(monkeypatch, tmp_path):
    monkeypatch.setenv("SUNWAEE_CONFIG_DIR", str(tmp_path / "config"))
    monkeypatch.delenv("SUNWAEE_WORKSPACES_DIR", raising=False)
    monkeypatch.delenv("SUNWAEE_WORKSPACE", raising=False)
    get_default_workspace()
    assert (tmp_path / "config" / "config.toml").exists()
