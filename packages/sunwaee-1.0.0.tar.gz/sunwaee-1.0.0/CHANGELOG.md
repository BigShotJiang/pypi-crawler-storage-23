# Changelog

All notable changes to the SUNWÆE CLI will be documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
This workspace adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [1.0.0] - 2026-02-28

### Added

- `task complete` command (replaces `task done`) — marks a task and all subtasks as done, records `completed_at` timestamp
- `task uncomplete` command — resets a task (and subtasks) back to `todo`, clears `completed_at`
- `completed_at` field on the Task model — set automatically by `task complete`, cleared by `task uncomplete` or `task edit --status <non-done>`
- `task list --show-completed` — completed tasks are hidden by default to reduce token usage for LLMs; pass this flag to include them
- `task list --due <expr>` — filter by due date using `today`, `tomorrow`, `this-week`, `this-month`, `overdue`, or `YYYY-MM-DD`
- Natural language due dates on `task create` and `task edit --due` — same expressions accepted (except `overdue`)
- `task edit --clear-due` — explicitly remove the due date from a task
- `task list --sort` — sort by `updated` (default), `created`, `title`, `due`, `priority`
- `note list --sort` — sort by `updated` (default), `created`, `title`
- `sunwaee init` command — creates config and default workspace in a single step; supports `--workspace` (name) and `--force` (re-initialise) flags
- `sunwaee/core/logger.py` — structured logging under the `sunwaee.*` hierarchy; log level controlled via `SUNWAEE_LOG_LEVEL` env var (`debug`, `info`, `warning`, `error`, `critical`; default `warning`)
- Log calls across all layers: `config.py` (config load/save, default workspace changes), `core/fs.py` (read/write/find), `modules/notes`, `modules/tasks`, `modules/workspaces` (create/update/delete operations)
- Workspace-based data organization: all data lives under `~/sunwaee/workspaces/<workspace>/<module>/`
- `sunwaee workspace create / list / set-default / delete` commands
- `--workspace` flag on all `note` and `task` commands (falls back to configured default)
- `SUNWAEE_WORKSPACES_DIR` and `SUNWAEE_WORKSPACE` env var overrides
- `workspace` field included in all JSON API responses for notes and tasks
- `tomli-w` dependency for writing `~/.sunwaee/config.toml`
- `sun note create / list / show / edit / delete / search` commands
- `sun task create / list / show / done / edit / delete / search` commands
- `SUNWAEE_CALLER` env var — controls output format (`human` → rich, `api`/`sun` → JSON)
- `SUNWAEE_NOTES_DIR` and `SUNWAEE_TASKS_DIR` env var overrides
- `~/.sunwaee/config.toml` base config (created on first run)
- Human-readable Markdown + YAML frontmatter storage (`~/notes/`, `~/tasks/`)
- Standardized JSON response envelope: `{"ok": true, "data": ...}` / `{"ok": false, "error": ..., "code": ...}`
- `--confirm` flag required on all destructive commands
- Auto-discovery module system — new domains require zero changes to core code
- `$EDITOR` integration for interactive body editing (human caller only)
