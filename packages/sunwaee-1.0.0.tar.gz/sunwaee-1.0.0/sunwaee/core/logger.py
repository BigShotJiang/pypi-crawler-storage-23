import logging
import os

_LEVELS = {
    "debug": logging.DEBUG,
    "info": logging.INFO,
    "warning": logging.WARNING,
    "error": logging.ERROR,
    "critical": logging.CRITICAL,
}


def get_logger(name: str) -> logging.Logger:
    """Return a logger scoped to *name* under the 'sunwaee' hierarchy."""
    return logging.getLogger(f"sunwaee.{name}")


def _configure() -> None:
    raw = os.environ.get("SUNWAEE_LOG_LEVEL", "").lower()
    level = _LEVELS.get(raw, logging.WARNING)

    root = logging.getLogger("sunwaee")
    if root.handlers:
        return

    handler = logging.StreamHandler()
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )
    )
    root.addHandler(handler)
    root.setLevel(level)


_configure()
