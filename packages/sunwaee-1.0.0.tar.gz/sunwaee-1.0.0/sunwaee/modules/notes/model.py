import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _uuid() -> str:
    return str(uuid.uuid4())


@dataclass
class Note:
    title: str
    body: str = ""
    tags: list[str] = field(default_factory=list)
    id: str = field(default_factory=_uuid)
    created_at: str = field(default_factory=_now)
    updated_at: str = field(default_factory=_now)

    def to_dict(self) -> dict:
        return asdict(self)

    def touch(self) -> None:
        self.updated_at = _now()

    def to_frontmatter_meta(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "tags": self.tags,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, meta: dict, body: str) -> "Note":
        return cls(
            id=meta.get("id", _uuid()),
            title=meta.get("title", ""),
            tags=meta.get("tags", []),
            created_at=meta.get("created_at", _now()),
            updated_at=meta.get("updated_at", _now()),
            body=body,
        )
