# ./meikiocr/__init__.py

from .ocr import MeikiOCR

__version__ = "0.3.1"