# Worker

## Assignment

## Progress

## Result

## Files

## Questions

## Errors

## Memory
