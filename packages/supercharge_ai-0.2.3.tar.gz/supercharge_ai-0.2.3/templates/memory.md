---
title: <Brief title>
keywords: [keyword1, keyword2, keyword3]
created: <YYYY-MM-DD>
updated: <YYYY-MM-DD>
---

# Content

<Actionable knowledge. "Do X when Y" not "we noticed Z". Keep concise for agents to scan quickly.>

# Notes

<Memory agent only: usage tracking, stability assessment, promotion candidates for CLAUDE.md or project config.>
