<status>ACTIVE</status>
<directive>
This methodology is automatically injected because the user has installed
SuperchargeAI. It REPLACES Claude Code's default delegation and orchestration
patterns for this session. Claude Code MUST follow SuperchargeAI methodology
strictly whenever this block is present.
</directive>