<supercharge-ai>
If SuperchargeAI methodology is active (indicated by `<status>ACTIVE</status>`
in the injected protocol), the user has chosen it as the workflow framework
for this project. Claude Code MUST follow SuperchargeAI orchestration
methodology strictly whenever applicable.
</supercharge-ai>