# Child Document

This is the child content.

It imports grandchild: @nested/grandchild