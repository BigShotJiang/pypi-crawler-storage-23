# Main Document

This imports a child: @child

And references `@code-span` which should NOT be replaced.

```
This @inside-code-block should also NOT be replaced.
```

End of main.