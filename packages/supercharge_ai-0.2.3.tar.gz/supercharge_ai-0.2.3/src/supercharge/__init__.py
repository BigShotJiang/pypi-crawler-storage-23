"""SuperchargeAI — multi-agent framework for Claude Code."""

from importlib.metadata import version

__version__ = version("supercharge-ai")
