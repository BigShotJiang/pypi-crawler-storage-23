"""Ingest: token-aware text chunking."""
