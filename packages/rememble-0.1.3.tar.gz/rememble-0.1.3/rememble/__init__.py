"""Rememble — local memory server with hybrid search and knowledge graph."""

from rememble.version import __version__

__all__ = ["__version__"]
