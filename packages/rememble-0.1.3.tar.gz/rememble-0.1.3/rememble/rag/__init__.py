"""RAG: token-budgeted context assembly."""
