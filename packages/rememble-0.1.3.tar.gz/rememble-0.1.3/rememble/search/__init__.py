"""Search: vector, text, temporal, graph, RRF fusion."""
