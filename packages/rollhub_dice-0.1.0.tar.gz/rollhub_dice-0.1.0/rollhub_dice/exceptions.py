"""Custom exceptions for the Rollhub Dice SDK."""


class RollhubError(Exception):
    """Base exception for all Rollhub errors."""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(self.message)


class AuthenticationError(RollhubError):
    """Invalid or missing API key."""


class InsufficientBalanceError(RollhubError):
    """Not enough balance to place bet."""


class InvalidBetError(RollhubError):
    """Invalid bet parameters."""


class RateLimitError(RollhubError):
    """Rate limit exceeded."""


class ServerError(RollhubError):
    """Server-side error (5xx)."""


class VerificationError(RollhubError):
    """Bet verification failed."""
