"""Data models for the Rollhub Dice SDK."""

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class Balance:
    """Account balance."""
    balance_usd: str
    balance_cents: int
    currency: str

    def __str__(self) -> str:
        return f"{self.balance_usd} {self.currency}"


@dataclass(frozen=True)
class Proof:
    """Provably fair proof for a bet."""
    server_secret: str
    client_secret: str
    nonce: int
    server_seed_hash: str


@dataclass(frozen=True)
class BetResult:
    """Result of a dice bet."""
    bet_id: int
    roll: float
    win: bool
    payout: int
    multiplier: float
    balance: int
    proof: Proof

    def __str__(self) -> str:
        outcome = "WIN" if self.win else "LOSS"
        return f"Bet #{self.bet_id}: rolled {self.roll:.4f} → {outcome} (payout: {self.payout})"


@dataclass(frozen=True)
class Bet:
    """A historical bet record."""
    bet_id: int
    roll: float
    win: bool
    payout: int
    multiplier: float
    target: float
    direction: str
    amount: int
    client_secret: str
    nonce: int
    created_at: Optional[str] = None


@dataclass(frozen=True)
class VerifyResult:
    """Result of bet verification."""
    bet_id: int
    verified: bool
    roll: Optional[float] = None
    server_secret: Optional[str] = None
    client_secret: Optional[str] = None
    nonce: Optional[int] = None
    server_seed_hash: Optional[str] = None

    def __str__(self) -> str:
        status = "✓ VERIFIED" if self.verified else "✗ FAILED"
        return f"Bet #{self.bet_id}: {status}"


@dataclass(frozen=True)
class Registration:
    """Registration result."""
    api_key: str
    server_seed_hash: str
