azure.ai.agentserver.core.server.common package
===============================================

.. automodule:: azure.ai.agentserver.core.server.common
   :inherited-members:
   :members:
   :undoc-members:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   azure.ai.agentserver.core.server.common.id_generator

Submodules
----------

azure.ai.agentserver.core.server.common.agent\_run\_context module
------------------------------------------------------------------

.. automodule:: azure.ai.agentserver.core.server.common.agent_run_context
   :inherited-members:
   :members:
   :undoc-members:

azure.ai.agentserver.core.server.common.constants module
--------------------------------------------------------

.. automodule:: azure.ai.agentserver.core.server.common.constants
   :inherited-members:
   :members:
   :undoc-members:
