"""Hydro Fetch: Retrieve and process hydrologic datasets including MRMS radar rainfall and AORC precipitation data."""

__version__ = "0.1.0"


def hello(name: str) -> str:
    """Return a greeting string.

    Args:
        name: The name to greet.

    Returns:
        A greeting string.
    """
    return f"Hello, {name}!"
