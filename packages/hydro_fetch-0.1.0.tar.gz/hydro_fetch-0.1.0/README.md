# Hydro Fetch

Retrieve and process hydrologic datasets including MRMS radar rainfall and AORC precipitation data.

## Installation

```bash
pip install hydro-fetch
```

> **Note**: PyPI publishing requires one-time setup of [trusted publishers](https://docs.pypi.org/trusted-publishers/) on pypi.org and test.pypi.org. See the [Copier Update Guide](https://github.com/lassiterdc/copier-python-template/blob/main/COPIER_UPDATE_GUIDE.md) for setup instructions.

## Quick start

```python
import hydro_fetch
```

## Documentation

Full documentation at [ReadTheDocs](https://hydro-fetch.readthedocs.io/).

## Development

See [CONTRIBUTING.md](CONTRIBUTING.md) for setup and contribution guidelines.
