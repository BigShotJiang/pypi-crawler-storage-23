"""
Monkeypatching questionary to support unique styling for Choice descriptions.
This is necessary because questionary 2.1.1 bundles unselected titles and 
descriptions under the same 'class:text' style token.

NOTE: This patch is optional and gracefully degrades if the target classes
are not available in the installed questionary version.
"""

import questionary.prompts.common


def apply_description_patch():
    """Applies the monkeypatch to questionary if the class is available."""
    
    # Target classes: 'ChoiceList' (questionary >= 2.1.0) or 'InquirerControl' (older)
    target_class = None
    if hasattr(questionary.prompts.common, 'ChoiceList'):
        target_class = getattr(questionary.prompts.common, 'ChoiceList')
    elif hasattr(questionary.prompts.common, 'InquirerControl'):
        target_class = getattr(questionary.prompts.common, 'InquirerControl')
    
    if not target_class:
        return

    # Avoid double patching
    if hasattr(target_class, "_original_get_choice_tokens"):
        return

    try:
        # Store original method
        original_method = target_class._get_choice_tokens
        target_class._original_get_choice_tokens = original_method

        def patched_get_choice_tokens(self):
            # Call original to get the standard token list
            tokens = original_method(self)
            
            new_tokens = []
            for style, text in tokens:
                # Detect ANSI escape codes - convert them to prompt_toolkit tokens while preserving highlighting
                if "\x1b[" in text or "\033[" in text:
                    try:
                        from prompt_toolkit.formatted_text import ANSI
                        # Parse the ANSI string into (style, text) tuples
                        ansi_tokens = []
                        for s, t in ANSI(text):
                            # Merge the original style (e.g., 'class:highlighted') with the ANSI color
                            # This ensures that selected items keep their highlighted background/marker
                            if s:
                                # Ensure we don't duplicate styles or add empty ones
                                combined_style = f"{style} {s}".strip() if style else s
                                ansi_tokens.append((combined_style, t))
                            else:
                                ansi_tokens.append((style, t))
                        
                        new_tokens.extend(ansi_tokens)
                        continue
                    except (ImportError, Exception):
                        # Fallback to original if something goes wrong
                        pass

                # intercepted description lines start with "  Description: " 
                if style == "class:text" and text.startswith("  Description: "):
                    new_tokens.append(("class:description", text))
                else:
                    new_tokens.append((style, text))
            
            return new_tokens

        # Apply patch
        questionary.prompts.common.ChoiceList._get_choice_tokens = patched_get_choice_tokens
    except (AttributeError, TypeError) as e:
        # Silently fail if anything goes wrong with patching
        pass
