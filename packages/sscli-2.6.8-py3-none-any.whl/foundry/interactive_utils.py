import questionary
from questionary import Choice
from pathlib import Path
from foundry.constants import console, QUESTIONARY_STYLE
from foundry.actions.health import run_health_check
from foundry.actions.setup import run_setup
from foundry.utils import is_internal_dev


def manage_config_menu():
    while True:
        action = questionary.select(
            "Configuration Management:",
            choices=[
                Choice("🔍 View Validation Status", value="validate"),
                Choice("⚙️  Run Template Setup (Full Suite)", value="setup"),
                "Back",
            ],
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()
        
        # Map choice values back
        if action == "validate":
            action = "View Validation Status"
        elif action == "setup":
            action = "Run Template Setup (Full Suite)"

        if action == "Back":
            break

        if action == "View Validation Status":
            run_health_check()
            pause()

        if action == "Run Template Setup (Full Suite)":
            run_setup()
            pause()


def pause():
    input("\nPress Enter to return...")
