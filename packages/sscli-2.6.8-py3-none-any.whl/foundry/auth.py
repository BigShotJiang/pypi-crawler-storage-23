import os
import json
import subprocess
from pathlib import Path
from typing import Any, Dict, Optional

import requests
from foundry.constants import console, API_BASE_URL

# Configuration
# The base URL is managed in foundry/constants.py (configurable via environment variables)
LICENSE_SERVER = API_BASE_URL
CREDENTIALS_FILE = Path.home() / ".config" / "sscli" / "credentials.json"


def get_access_token() -> Optional[str]:
    """Retrieve the GitHub CLI access token.
    
    Uses 'gh auth token' which securely retrieves the token from OS keyring (Keychain on macOS).
    """
    try:
        result = subprocess.run(
            ["gh", "auth", "token"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired, Exception):
        pass
    return None


def save_credentials(data: Dict[str, Any]) -> None:
    """Cache license tier and org info locally (not the token).
    
    Token is managed by GitHub CLI and stored securely in OS keyring.
    We only cache tier and org_name for fast local checks.
    """
    # Create directory with restrictive permissions (owner only)
    CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    
    # Only store tier and org_name (tier is already verified by server)
    cached_data = {
        "tier": data.get("tier", "free"),
        "org_name": data.get("org_name"),
        "status": data.get("status", "active"),
    }
    
    # Write to temp file first for atomic operation
    temp_file = CREDENTIALS_FILE.with_suffix('.tmp')
    with open(temp_file, "w") as f:
        json.dump(cached_data, f, indent=2)
    
    # Set restrictive file permissions (owner read/write only)
    os.chmod(temp_file, 0o600)
    
    # Atomic rename to prevent partial/corrupted files
    temp_file.replace(CREDENTIALS_FILE)


def login_flow() -> bool:
    """Authenticate via GitHub CLI (gh auth login).
    
    Uses GitHub CLI's secure authentication which stores tokens in OS keyring.
    Then validates tier/org with License Server.
    
    Returns:
        True if authentication succeeded, False otherwise.
    """
    console.print("Initiating login with GitHub CLI...")
    
    try:
        # Launch gh auth login (user interacts with browser)
        result = subprocess.run(
            ["gh", "auth", "login"],
            timeout=300  # 5 minute timeout
        )
        if result.returncode != 0:
            console.print("[red]GitHub CLI authentication cancelled or failed.[/red]")
            return False
    except FileNotFoundError:
        console.print(
            "[red]Error:[/] GitHub CLI (gh) is not installed.\\n"
            "Please install it from: https://cli.github.com[/red]"
        )
        return False
    except Exception as e:
        console.print(f"[red]Error launching gh auth login:[/] {e}")
        return False
    
    # Get token from gh and validate with License Server
    token = get_access_token()
    if not token:
        console.print("[red]Failed to retrieve token from GitHub CLI.[/red]")
        return False
    
    # Validate with License Server to get tier/org
    try:
        response = requests.get(
            f"{LICENSE_SERVER}/v1/auth/validate",
            headers={"Authorization": f"Bearer {token}"},
            timeout=5
        )
        if response.status_code == 200:
            server_data = response.json()
            save_credentials(server_data)
            email = server_data.get('email', 'User')
            tier_str = server_data.get('tier', 'free').upper()
            org_name = server_data.get('org_name')
            
            console.print(f"\n✓ Successfully authenticated as {email}")
            if org_name:
                console.print(f"License Tier: {tier_str} (via {org_name})")
            else:
                console.print(f"License Tier: {tier_str}")
            return True
        else:
            console.print(f"[red]License validation failed:[/] Server returned {response.status_code}")
            return False
    except Exception as e:
        console.print(f"[red]Error validating license:[/] {e}")
        return False


def get_current_license_info(verify: bool = False) -> Dict[str, Any]:
    """Get current license/tier info from local cache or GitHub CLI.

    If verify=True, validates token with License Server to ensure authenticity.
    If verification fails or gh auth is unavailable, returns cached tier (or free if no cache).
    
    Token is never stored locally—it's always retrieved from GitHub CLI's secure keyring.
    """
    default_info = {"tier": "free", "authorized": False, "org_name": None, "status": "active"}
    
    # Check if cached credentials exist
    cached_info = None
    if CREDENTIALS_FILE.exists():
        try:
            with open(CREDENTIALS_FILE, "r") as f:
                cached_info = json.load(f)
                if not isinstance(cached_info, dict):
                    cached_info = None
        except Exception:
            cached_info = None
    
    # If not verifying, return cached info (fast path)
    if not verify:
        return cached_info or default_info
    
    # Verification mode: get fresh token from gh and validate with License Server
    token = get_access_token()
    if not token:
        # No token available, return cached or default
        return cached_info or default_info
    
    try:
        response = requests.get(
            f"{LICENSE_SERVER}/v1/auth/validate",
            headers={"Authorization": f"Bearer {token}"},
            timeout=2.0
        )
        if response.status_code == 200:
            server_data = response.json()
            # Update cache with fresh server data
            save_credentials(server_data)
            return server_data
        else:
            # Token invalid or expired
            return default_info
    except Exception:
        # Server unreachable, return cached credentials if available
        return cached_info or default_info


def logout() -> None:
    """Clear authentication and logout from GitHub CLI.

    Removes local cached credentials and logs out from GitHub CLI.
    """
    try:
        # Logout from GitHub CLI
        subprocess.run(["gh", "auth", "logout"], timeout=5)
    except Exception:
        pass  # gh auth logout might not be available, continue with local cleanup
    
    try:
        if CREDENTIALS_FILE.exists():
            CREDENTIALS_FILE.unlink()
            console.print("[green]✓ Logged out:[/] removed local credentials.")
        else:
            console.print("[green]✓ Logged out.[/green]")
    except Exception as e:
        console.print(f"[yellow]Warning:[/] Could not remove credentials file: {e}")
        console.print(f"[red]Error clearing credentials:[/] {e}")
