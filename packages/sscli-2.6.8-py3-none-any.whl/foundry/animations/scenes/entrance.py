"""
Entrance animation sequence: fade-in boot sequence and nature reveal.
"""

from ..animation import Animation, AnimationConfig
from ..components import render_base_background, render_stars
from ..core import FRAME_HEIGHT, FRAME_WIDTH, Canvas
from ..engine.frame_buffer import FrameBuffer
from ..engine.state import AnimationState, ScenePhase


class EntranceAnimation(Animation):
    """
    Entrance animation: Boot sequence and first look at the landscape.
    """

    def __init__(self, duration: float = 2.0):
        super().__init__(AnimationConfig(duration=duration))

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        return state.with_updates(scene_phase=ScenePhase.ENTRANCE)

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        # 1. Background layer
        bg_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        render_stars(bg_canvas, count=15)

        # 2. Nature layer (progressively grows based on time)
        # Modified: Tree growth now starts at 0.0 and reaches 1.0 by the end of entrance
        nature_progress = self.get_progress()
        render_base_background(
            bg_canvas, tree_growth=nature_progress, grass_wind=state.grass_wind
        )

        frame_buffer.add_layer("background", bg_canvas.buffer)

        # 3. Overlay layer: "System Booting..."
        overlay_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        if self.get_progress() < 0.5:
            boot_text = "INITIALIZING STACK-FOUNDRY..."
            overlay_canvas.draw_text(boot_text, 2, FRAME_HEIGHT - 3, style="bold cyan")
        elif self.get_progress() < 0.8:
            boot_text = "SYNCHRONIZING ENVIRONMENT..."
            overlay_canvas.draw_text(boot_text, 2, FRAME_HEIGHT - 3, style="bold green")

        frame_buffer.add_layer("overlay", overlay_canvas.buffer)
