"""
Logo reveal animation: The logo appears with a subtle shimmering effect.
"""

import math

from rich.text import Text

from ..animation import Animation, AnimationConfig
from ..assets import RAW_LOGO
from ..components import render_base_background, render_stars
from ..core import FRAME_HEIGHT, FRAME_WIDTH, Canvas
from ..engine.frame_buffer import FrameBuffer
from ..engine.state import AnimationState, ScenePhase


class LogoRevealAnimation(Animation):
    """
    Logo reveal animation: Subtle fade-in with a light shimmer.
    """

    def __init__(self, duration: float = 1.2):
        super().__init__(AnimationConfig(duration=duration))

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        wind = 0.6 + 0.2 * math.sin(state.elapsed_time * 2)
        return state.with_updates(scene_phase=ScenePhase.LOGO_SLIDE, grass_wind=wind)

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        # 1. Background layer
        bg_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        render_stars(bg_canvas, count=20)
        # Always show the ground so the world feels consistent
        render_base_background(bg_canvas, tree_growth=0.0, grass_wind=state.grass_wind)
        frame_buffer.add_layer("background", bg_canvas.buffer)

        # 2. Logo layer
        logo_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        progress = self.get_progress()

        logo_x = (FRAME_WIDTH - len(RAW_LOGO[0])) // 2
        logo_y = 4

        # Shimmer effect based on time
        shimmer_pos = progress * 1.5 - 0.25  # Moves from -0.25 to 1.25

        for i, line in enumerate(RAW_LOGO):
            current_y = logo_y + i

            # Subtly reveal lines from top to bottom
            line_progress = (progress * 1.5) - (i / len(RAW_LOGO)) * 0.5
            line_progress = max(0, min(1.0, line_progress))

            if line_progress <= 0:
                continue

            styled_line = Text("")
            for char_idx, char in enumerate(line):
                if char == " ":
                    styled_line.append(" ")
                    continue

                # Each character has a slightly offset reveal
                char_reveal = line_progress - (char_idx / len(line)) * 0.2

                if char_reveal <= 0:
                    styled_line.append(" ")
                else:
                    # Shimmer effect: extra brightness as it reveals
                    dist_to_shimmer = abs((char_idx / len(line)) - shimmer_pos)

                    if dist_to_shimmer < 0.1:
                        style = "bold white"
                    elif char_reveal < 0.5:
                        style = "blue dim"
                    elif char_reveal < 0.8:
                        style = "blue"
                    else:
                        style = "bold cyan"

                    styled_line.append(char, style=style)

            logo_canvas.draw_text(styled_line, logo_x, current_y)

        frame_buffer.add_layer("logo", logo_canvas.buffer)


class LogoStaticAnimation(Animation):
    """
    Logo static animation: Simply stays on screen for a set duration.
    """

    def __init__(self, duration: float = 1.0):
        super().__init__(AnimationConfig(duration=duration))

    def _update_impl(self, dt: float, state: AnimationState) -> AnimationState:
        # Keep grass moving even when logo is static
        wind = 0.6 + 0.2 * math.sin(state.elapsed_time * 2)
        return state.with_updates(grass_wind=wind)

    def render(self, frame_buffer: FrameBuffer, state: AnimationState) -> None:
        # 1. Background layer
        bg_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        render_stars(bg_canvas, count=20)
        # Always show the ground so the world feels consistent
        render_base_background(bg_canvas, tree_growth=0.0, grass_wind=state.grass_wind)
        frame_buffer.add_layer("background", bg_canvas.buffer)

        # 2. Logo layer
        logo_canvas = Canvas(FRAME_WIDTH, FRAME_HEIGHT)
        logo_x = (FRAME_WIDTH - len(RAW_LOGO[0])) // 2
        logo_y = 4
        logo_canvas.draw_sprite(RAW_LOGO, logo_x, logo_y, style="bold cyan")
        
        # 3. Add version number at bottom right
        try:
            from pathlib import Path
            import tomllib
            foundry_path = Path(__file__).parent.parent.parent
            pyproject_path = foundry_path / "pyproject.toml"
            if pyproject_path.exists():
                with open(pyproject_path, 'rb') as f:
                    data = tomllib.load(f)
                version = data.get('project', {}).get('version', 'unknown')
                version_text = f"v{version}"
                version_x = FRAME_WIDTH - len(version_text) - 1
                version_y = FRAME_HEIGHT - 2
                logo_canvas.draw_text(version_text, version_x, version_y, style="dim cyan")
        except Exception:
            pass  # Silently fail if version can't be read
        
        frame_buffer.add_layer("logo", logo_canvas.buffer)
