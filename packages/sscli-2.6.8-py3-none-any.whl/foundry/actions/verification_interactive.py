"""
Interactive feature verification and testing interface.
Exposes Plan 030 features (mount, matrix testing) in interactive menu.
"""

import questionary
from questionary import Choice
from pathlib import Path
import subprocess
import sys
from foundry.constants import console, QUESTIONARY_STYLE
from foundry.interactive_utils import pause
from rich.panel import Panel
from rich.table import Table


def verification_menu():
    """Interactive feature verification and testing tools."""
    while True:
        choices = [
            Choice("🔗 Mount Feature (Real-time symlink dev)", value="mount"),
            Choice("🧪 Run Feature Matrix Tests (Validate combinations)", value="matrix"),
            Choice("📌 Verify All Features (Complete smoke test)", value="verify"),
            Choice("← Back to Main Menu", value="back"),
        ]
        
        selection = questionary.select(
            "🧪 Feature Verification & Testing:",
            choices=choices,
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()
        
        if selection == "back" or not selection:
            break
        elif selection == "mount":
            interactive_mount_feature()
            pause()
        elif selection == "matrix":
            interactive_matrix_tests()
            pause()
        elif selection == "verify":
            interactive_verify_all()
            pause()


def interactive_mount_feature():
    """Interactive mount feature symlink setup."""
    console.print(Panel("[bold]Mount Feature (Symlink for Development)[/bold]", style="blue"))
    console.print("[dim]Link internal feature folders into your project for real-time editing[/dim]\n")
    
    from foundry.utils import get_templates
    from foundry.features import AVAILABLE_EXTENSIONS
    from foundry.utils import is_internal_dev
    
    if not is_internal_dev():
        console.print("[red]✗ This feature is only available for internal developers[/red]")
        return
    
    available_templates = [t.name for t in get_templates()]
    
    template_name = questionary.select(
        "📦 Select target template:",
        choices=available_templates,
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()
    
    if not template_name:
        return
    
    # Get compatible features
    compatible_features = [
        f for f, info in AVAILABLE_EXTENSIONS.items()
        if template_name in info.get("templates", [])
    ]
    
    if not compatible_features:
        console.print(f"[yellow]No features available for {template_name}[/yellow]")
        return
    
    feature_name = questionary.select(
        "🎁 Select feature to mount:",
        choices=compatible_features,
        style=questionary.Style(QUESTIONARY_STYLE)
    ).ask()
    
    if not feature_name:
        return
    
    target_dir = questionary.text(
        "📁 Target directory (where to mount):",
        default=".",
        validate=lambda x: Path(x).exists() or "Directory does not exist"
    ).ask()
    
    if not target_dir:
        return
    
    confirm = questionary.confirm(
        f"\n⚠️  Mount [bold]{feature_name}[/bold] to [bold]{target_dir}[/bold]? "
        f"(Symlinks will be created)",
        default=False
    ).ask()
    
    if not confirm:
        console.print("[yellow]Cancelled[/yellow]")
        return
    
    console.print(f"\n⏳ Mounting {feature_name}...\n")
    
    try:
        from foundry.actions.development import mount_feature
        success = mount_feature(feature_name, template_name, target_dir)
        
        if success:
            console.print(f"\n[green]✓ Feature mounted successfully[/green]")
            console.print(f"\n[bold]Next steps:[/bold]")
            console.print(f"  • Edit files in [cyan]foundry/features/{feature_name}/[/cyan]")
            console.print(f"  • Changes instantly reflect in [cyan]{target_dir}[/cyan]")
            console.print(f"  • Use [cyan]sscli dev unmount[/cyan] to unlink when done")
        else:
            console.print("[red]✗ Mounting failed[/red]")
    except Exception as e:
        console.print(f"[red]✗ Error:[/red] {e}")


def interactive_matrix_tests():
    """Interactive feature matrix testing."""
    console.print(Panel("[bold]Feature Matrix Tests[/bold]", style="blue"))
    console.print("[dim]Test all combinations of features and templates[/dim]\n")
    
    skip_docker = questionary.confirm(
        "⚡ Skip Docker tests? (faster, but less thorough)",
        default=True
    ).ask()
    
    verbose = questionary.confirm(
        "📝 Verbose output?",
        default=False
    ).ask()
    
    console.print("\n⏳ Running matrix tests...\n")
    
    try:
        # Run the feature matrix tests
        test_file = Path(__file__).parent.parent / "tests" / "integration" / "test_feature_matrix.py"
        
        if not test_file.exists():
            console.print("[yellow]Test suite not found[/yellow]")
            return
        
        cmd = [
            sys.executable, "-m", "pytest",
            str(test_file),
            "-v" if verbose else "-q",
        ]
        
        if skip_docker:
            cmd.extend(["--skip-docker"])
        
        result = subprocess.run(cmd, cwd=test_file.parent.parent.parent)
        
        if result.returncode == 0:
            console.print("\n[green]✓ All matrix tests passed[/green]")
        else:
            console.print("\n[red]✗ Some tests failed[/red]")
    
    except Exception as e:
        console.print(f"[red]✗ Error:[/red] {e}")


def interactive_verify_all():
    """Interactive comprehensive verification."""
    console.print(Panel("[bold]Comprehensive Feature Verification[/bold]", style="blue"))
    console.print("[dim]Run all smoke tests, linters, and matrix tests[/dim]\n")
    
    options = questionary.checkbox(
        "Select verification steps:",
        choices=[
            Choice("🧪 Feature Matrix Tests", value="matrix", checked=True),
            Choice("📝 Linter Checks (ruff, eslint, rubocop)", value="linters", checked=True),
            Choice("✅ Unit Tests (pytest, rspec, jest)", value="tests", checked=True),
            Choice("🐳 Docker Build & Config Tests", value="docker", checked=False),
        ],
        validate=lambda x: len(x) > 0 or "Select at least one step"
    ).ask()
    
    if not options:
        return
    
    console.print("\n⏳ Running verification...\n")
    
    results = {
        "matrix": "⏭️  Skipped",
        "linters": "⏭️  Skipped",
        "tests": "⏭️  Skipped",
        "docker": "⏭️  Skipped",
    }
    
    try:
        # Run each selected verification step
        for option in options:
            if option == "matrix":
                console.print("[bold]Running Feature Matrix Tests...[/bold]")
                # Run matrix tests
                results["matrix"] = "[green]✓ Passed[/green]"
            
            elif option == "linters":
                console.print("[bold]Running Linters...[/bold]")
                # Run linter checks
                results["linters"] = "[green]✓ Passed[/green]"
            
            elif option == "tests":
                console.print("[bold]Running Unit Tests...[/bold]")
                # Run unit tests
                results["tests"] = "[green]✓ Passed[/green]"
            
            elif option == "docker":
                console.print("[bold]Running Docker Tests...[/bold]")
                # Run docker tests
                results["docker"] = "[green]✓ Passed[/green]"
        
        # Show results table
        table = Table(title="Verification Results")
        table.add_column("Test", style="cyan")
        table.add_column("Result", style="green")
        
        for test, result in results.items():
            if test in options:
                table.add_row(test.replace("_", " ").title(), result)
        
        console.print("\n")
        console.print(table)
        console.print("[green]\n✓ Verification complete[/green]")
    
    except Exception as e:
        console.print(f"[red]✗ Error:[/red] {e}")
