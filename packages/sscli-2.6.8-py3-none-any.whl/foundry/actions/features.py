import shutil
from pathlib import Path
from foundry.constants import console, FOUNDRY_ROOT
from foundry.tools.synvert_adapter import SynvertAdapter
from foundry.actions.ast_grep_runner import AstGrepRunner, ensure_ast_grep_available
from foundry.codemods import (
    IdempotentAddDependencyCM,
    PythonInjectImportCodemod,
    PythonInjectCallCodemod,
    PythonInjectConstantCodemod,
    JsInjectImportCodemod,
    JsInjectRouteCodemod,
    JsInjectCallCodemod,
    JsInjectConstantCodemod,
    RubyInjectRouteCodemod,
    RubyInjectCallCodemod,
    RubyInjectConstantCodemod,
)

def setup_secrets(path: Path, strategy: str):
    if "Dotenv" in strategy:
        example_env = path / ".env.example"
        if example_env.exists():
            target_env = path / ".env"
            if not target_env.exists():
                shutil.copy(example_env, target_env)
                console.print(f"   - Created .env from .env.example")
    elif "Doppler" in strategy:
        (path / "doppler.yaml").write_text("setup:\n  project: my-project\n  config: dev\n")
        console.print(f"   - Added doppler.yaml config")

def inject_features(
    path: Path, 
    template: str, 
    commerce: bool, 
    tunnel: bool, 
    landing: bool = False,
    admin: bool = False,
    sqlite: bool = False,
    ingestor: bool = False,
    auth: bool = False,
    merchant_dashboard: bool = False,
    use_ast_injection: bool = False
):
    # If AST injection is enabled (experimental), use the new codemod-based system
    if use_ast_injection:
        try:
            console.print("   - [bold cyan]🔬 Using AST-based feature injection (experimental)...[/bold cyan]")
            inject_features_ast(
                project_path=path,
                template_name=template,
                commerce=commerce,
                tunnel=tunnel,
                landing=landing,
                admin=admin,
                sqlite=sqlite,
                ingestor=ingestor,
                auth=auth,
                merchant_dashboard=merchant_dashboard
            )
            return
        except Exception as e:
            console.print(f"   - [yellow]⚠️  AST injection failed, falling back to string markers: {e}[/yellow]")
            # Fall through to string-based injection below
    
    # Original string-marker based injection (default)
    # Special Handling: If we are generating the Static Landing template itself,
    # we want to inject all premium components and themes by default.
    # we want to inject all premium components and themes by default.
    if template == "static-landing":
        console.print("   - [bold magenta]Injecting Premium Astro Components & Themes...[/bold magenta]")
        _perform_feature_injection(path, "landing", "components")
        _perform_feature_injection(path, "landing", "themes")

    if commerce:
        console.print("   - [bold blue]Injecting Commerce Modules (Shopify/Stripe)...[/bold blue]")
        _perform_feature_injection(path, template, "commerce")
        _inject_commerce_env_vars(path)
        if "rails" in template: _inject_rails_commerce_routes(path)
        if template == "static-landing": _inject_astro_commerce(path)
    
    if tunnel:
        console.print("   - [bold cyan]Configuring Local Tunnel (ngrok)...[/bold cyan]")
        _perform_feature_injection(path, template, "tunnel")
        _inject_tunnel_config(path, template)
    
    if auth:
        console.print("   - [bold yellow]Injecting Authentication Features...[/bold yellow]")
        if template == "static-landing": _inject_astro_auth(path)
    
    if landing and template != "static-landing":
        console.print("   - [bold magenta]Integrating Static Landing Page (Astro)...[/bold magenta]")
        # For other templates, the landing page is injected as a feature
        _perform_feature_injection(path, template, "landing")
        _inject_landing_instructions(path)
        
        # Also inject premium components into the newly created landing folder if it exists
        landing_dir = path / "static-landing"
        if landing_dir.exists():
            _perform_feature_injection(landing_dir, "landing", "components")
            _perform_feature_injection(landing_dir, "landing", "themes")
    if admin:
        console.print("   - [bold yellow]Injecting NiceGUI Admin Panel...[/bold yellow]")
        _perform_feature_injection(path, template, "nicegui-admin")
        _inject_python_dependencies(path, ["nicegui"])
    if sqlite:
        console.print("   - [bold white]Setting up SQLite Local Persistence...[/bold white]")
        _perform_feature_injection(path, template, "sqlite-local")
        _inject_sqlite_config(path)
        _inject_python_dependencies(path, ["sqlalchemy", "alembic", "aiosqlite"])
    if ingestor:
        console.print("   - [bold green]Injecting Data Ingestor Pattern...[/bold green]")
        _perform_feature_injection(path, template, "data-ingestor")
    
    if merchant_dashboard:
        if template == "react-client":
            console.print("   - [bold magenta]Injecting Merchant Dashboard...[/bold magenta]")
            inject_merchant_dashboard(path)
        else:
            console.print("   - [yellow]Merchant Dashboard is only available for react-client template[/yellow]")


def inject_features_ast(
    project_path: Path,
    template: str,
    features: dict,
    dry_run: bool = False
) -> dict:
    """
    AST-based feature injection using codemods.
    
    This is the next-generation feature injection pipeline that uses AST transformations
    instead of string markers. It provides:
    - Safe, formatting-aware code modifications
    - Duplicate detection and idempotency
    - Cross-language support (Python, JavaScript, Ruby)
    - Dry-run support for preview
    - Atomic transformations with proper error handling
    
    Args:
        project_path: Root path of the project to modify
        template: Template type ('python-saas', 'react-client', 'rails-api')
        features: Dict of feature configurations to inject, e.g., {
            'commerce': {
                'route': { 'path': '/shop', 'controller': 'shop#show' },
                'import': { 'module': 'Commerce', 'from': './lib' }
            }
        }
        dry_run: If True, show what would be modified without writing changes
    
    Returns:
        Dict with: {
            'success': bool,
            'changes': [list of modified files],
            'errors': [list of errors if any],
            'skipped': [list of skipped operations]
        }
    """
    results = {
        'success': True,
        'changes': [],
        'errors': [],
        'skipped': []
    }
    
    try:
        # Template-specific codemods
        if template == "python-saas":
            results = _inject_python_saas_codemods(project_path, features, dry_run)
        
        elif template == "react-client":
            results = _inject_react_codemods(project_path, features, dry_run)
        
        elif "rails" in template:
            results = _inject_rails_codemods(project_path, features, dry_run)
        
        else:
            results['success'] = False
            results['errors'].append(f"Unknown template type: {template}")
    
    except Exception as e:
        results['success'] = False
        results['errors'].append(f"AST injection pipeline failed: {str(e)}")
        console.print(f"[bold red]✗ Error: {str(e)}[/bold red]")
    
    return results


def _inject_python_saas_codemods(
    project_path: Path,
    features: dict,
    dry_run: bool
) -> dict:
    """Inject codemods for Python SaaS template."""
    results = {'success': True, 'changes': [], 'errors': [], 'skipped': []}
    
    app_py = project_path / "src" / "ui" / "app.py"
    if not app_py.exists():
        app_py = project_path / "app.py"
    
    # Inject imports
    if 'imports' in features:
        for imp in features['imports']:
            try:
                codemod = PythonInjectImportCodemod(
                    module=imp['module'],
                    names=imp.get('names'),
                    alias=imp.get('alias')
                )
                if app_py.exists():
                    codemod.apply(app_py)
                    results['changes'].append(str(app_py))
                    console.print(f"   ✓ Injected import {imp['module']}")
            except Exception as e:
                results['errors'].append(f"Failed to inject import {imp['module']}: {str(e)}")
    
    # Inject function calls
    if 'calls' in features:
        for call in features['calls']:
            try:
                codemod = PythonInjectCallCodemod(
                    target_func='main',
                    call_statement=call['statement']
                )
                if app_py.exists():
                    codemod.apply(app_py)
                    results['changes'].append(str(app_py))
                    console.print(f"   ✓ Injected call: {call['statement']}")
            except Exception as e:
                results['errors'].append(f"Failed to inject call: {str(e)}")
    
    # Add dependencies
    if 'dependencies' in features:
        pyproject = project_path / "pyproject.toml"
        if pyproject.exists():
            codemod = IdempotentAddDependencyCM(features['dependencies'])
            result = codemod.apply(pyproject)
            if result.success:
                results['changes'].append(str(pyproject))
                console.print(f"   ✓ Added {len(features['dependencies'])} dependencies")
    
    return results


def _inject_react_codemods(
    project_path: Path,
    features: dict,
    dry_run: bool
) -> dict:
    """Inject codemods for React Client template."""
    results = {'success': True, 'changes': [], 'errors': [], 'skipped': []}
    
    app_jsx = project_path / "src" / "App.jsx"
    if not app_jsx.exists():
        results['skipped'].append("App.jsx not found")
        return results
    
    # Inject imports
    if 'imports' in features:
        for imp in features['imports']:
            try:
                codemod = JsInjectImportCodemod(
                    module=imp['module'],
                    names=imp.get('names'),
                    import_type=imp.get('type', 'esm')
                )
                codemod.apply(app_jsx)
                results['changes'].append(str(app_jsx))
                console.print(f"   ✓ Injected import: {imp['module']}")
            except Exception as e:
                results['errors'].append(f"Failed to inject import {imp['module']}: {str(e)}")
    
    # Inject routes
    if 'routes' in features:
        for route in features['routes']:
            try:
                codemod = JsInjectRouteCodemod(
                    path_pattern=route['path'],
                    component=route['component'],
                    framework='react'
                )
                codemod.apply(app_jsx)
                results['changes'].append(str(app_jsx))
                console.print(f"   ✓ Injected route: {route['path']}")
            except Exception as e:
                results['errors'].append(f"Failed to inject route {route['path']}: {str(e)}")
    
    # Inject constants
    if 'constants' in features:
        for const in features['constants']:
            try:
                codemod = JsInjectConstantCodemod(
                    name=const['name'],
                    value=const['value']
                )
                codemod.apply(app_jsx)
                results['changes'].append(str(app_jsx))
                console.print(f"   ✓ Injected constant: {const['name']}")
            except Exception as e:
                results['errors'].append(f"Failed to inject constant {const['name']}: {str(e)}")
    
    return results


def _inject_rails_codemods(
    project_path: Path,
    features: dict,
    dry_run: bool
) -> dict:
    """Inject codemods for Rails API template."""
    results = {'success': True, 'changes': [], 'errors': [], 'skipped': []}
    
    routes_file = project_path / "config" / "routes.rb"
    if not routes_file.exists():
        results['skipped'].append("config/routes.rb not found")
        return results
    
    # Inject routes
    if 'routes' in features:
        for route in features['routes']:
            try:
                codemod = RubyInjectRouteCodemod(
                    http_method=route.get('method', 'get'),
                    path=route['path'],
                    controller_action=route['action'],
                    namespace=route.get('namespace')
                )
                codemod.apply(routes_file)
                results['changes'].append(str(routes_file))
                console.print(f"   ✓ Injected route: {route['path']}")
            except Exception as e:
                results['errors'].append(f"Failed to inject route {route['path']}: {str(e)}")
    
    # Add dependencies
    if 'dependencies' in features:
        # Note: Rails dependencies are in Gemfile, not pyproject.toml
        # This would require a different codemod implementation
        results['skipped'].append("Gemfile dependency injection not yet implemented")
    
    return results


def _perform_feature_injection(project_path: Path, template: str, feature_name: str):
    """Injects features from the central private vault (/features) into the project."""
    # 1. Look in the private vault FIRST (IP Protection)
    vault_base = FOUNDRY_ROOT / "features"
    feature_dir = vault_base / template / feature_name
    
    # Special case for cross-template features (like commerce/tunnel)
    if not feature_dir.exists():
        # Try generic feature location
        feature_dir = vault_base / feature_name

    if feature_dir.exists():
        console.print(f"     - Extracting {feature_name} from private vault...")
        for item in feature_dir.glob("**/*"):
            if item.is_file():
                rel_path = item.relative_to(feature_dir)
                target_file = project_path / rel_path
                target_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, target_file)
        
        # If it was a landing feature, we might need a special marker injection for themes
        if template == "static-landing" and feature_name == "themes":
            _inject_astro_themes(project_path)
    else:
        # Fallback to local project features/ folder (legacy/open-source support)
        local_feature_dir = project_path / "features" / feature_name
        if local_feature_dir.exists():
            console.print(f"     - Moving {feature_name} from project features/ into source...")
            for item in local_feature_dir.glob("**/*"):
                if item.is_file():
                    rel_path = item.relative_to(local_feature_dir)
                    target_file = project_path / rel_path
                    target_file.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(item, target_file)

def _inject_astro_themes(path: Path):
    """Integrates premium theme definitions using ast-grep rules."""
    themes_file = path / "src" / "styles" / "themes.css"
    vault_themes = FOUNDRY_ROOT / "features" / "landing" / "themes" / "themes.css"
    
    if not (themes_file.exists() and vault_themes.exists()):
        return
    
    premium_content = vault_themes.read_text(encoding="utf-8")
    
    try:
        runner = AstGrepRunner()
        if not runner.is_available():
            console.print("[yellow]⚠ ast-grep not available, using legacy approach[/yellow]")
            return _inject_astro_themes_legacy(path)
        
        success = runner.inject_rule(
            target_path=themes_file,
            rule_name="astro-inject-theme-definitions",
            content_vars={"THEME_CONTENT": premium_content},
            auto_accept=True
        )
        
        if success:
            console.print("     - Injected premium theme definitions into themes.css")
    
    except Exception as e:
        console.print(f"[yellow]⚠ ast-grep injection failed: {e}[/yellow]")
        console.print("     - Falling back to legacy marker-based approach")
        return _inject_astro_themes_legacy(path)

def _inject_python_dependencies(path: Path, dependencies: list):
    """
    Inject Python dependencies into pyproject.toml using safe TOML parsing.
    Uses IdempotentAddDependencyCM to ensure safe, idempotent modifications.
    """
    pyproject = path / "pyproject.toml"
    if not pyproject.exists():
        return

    # Use the idempotent codemod for safe injection
    codemod = IdempotentAddDependencyCM(dependencies, version="*")
    result = codemod.apply(pyproject)

    if result.success:
        console.print(f"   - Added {', '.join(dependencies)} to pyproject.toml")
    else:
        console.print(f"   [yellow]⚠ Failed to add dependencies: {result.error}[/yellow]")

def _inject_sqlite_config(path: Path):
    env_files = [path / ".env", path / ".env.example"]
    sqlite_vars = [
        "\n# --- SQLite Persistence ---",
        "DATABASE_URL=sqlite+aiosqlite:///./local.db\n"
    ]
    for env_file in env_files:
        if env_file.exists():
            content = env_file.read_text(encoding="utf-8")
            if "DATABASE_URL" not in content:
                with env_file.open("a", encoding="utf-8") as f: f.write("\n".join(sqlite_vars))

def _inject_commerce_env_vars(path: Path):
    env_files = [path / ".env", path / ".env.example"]
    commerce_vars = [
        "\n# --- Commerce (Shopify) ---",
        "SHOPIFY_SHOP_NAME=your-shop-name",
        "SHOPIFY_API_KEY=your-api-key",
        "SHOPIFY_API_SECRET=your-api-secret",
        "SHOPIFY_ACCESS_TOKEN=your-access-token",
        "",
        "# --- Corporate-Grade Addons ---",
        "COMMERCE_IDEMPOTENCY_ENABLED=true",
        "COMMERCE_PII_REDACTION_ENABLED=true",
        "COMMERCE_ADAPTER_TYPE=fake # Options: shopify, stripe, fake",
        "COMMERCE_REPLAY_PROTECTION_ENABLED=true\n"
    ]
    for env_file in env_files:
        if env_file.exists():
            content = env_file.read_text(encoding="utf-8")
            if "SHOPIFY_SHOP_NAME" not in content:
                with env_file.open("a", encoding="utf-8") as f: f.write("\n".join(commerce_vars))

def _inject_rails_commerce_routes(path: Path):
    """
    Inject Shopify webhook routes into Rails config/routes.rb using Synvert.
    
    Previously used fragile string-based line insertion. Now leverages
    Synvert's AST-aware transformations for robust, maintainable code injection.
    
    Args:
        path: Path to Rails project root
    """
    routes_file = path / "config" / "routes.rb"
    
    # Quick existence check
    if not routes_file.exists():
        return
    
    # Use Synvert adapter for AST-aware transformation
    try:
        adapter = SynvertAdapter(path)
        result = adapter.add_webhook_routes(
            namespace="webhooks",
            route_specs=[
                ("post", "shopify", "webhooks/shopify#handle")
            ]
        )
        
        if result["success"]:
            # Validate syntax of modified routes file
            validation = adapter.validate_ruby_syntax(routes_file)
            if validation["valid"]:
                console.print(
                    "   - [bold green]✓[/bold green] Injected Shopify webhook "
                    "routes into config/routes.rb (AST-aware)"
                )
            else:
                console.print(
                    f"   - [bold red]✗[/bold red] Routes syntax error: "
                    f"{validation['error']}"
                )
        else:
            console.print(
                f"   - [bold yellow]⚠[/bold yellow] Route injection warning: "
                f"{result['error_message']}"
            )
    
    except RuntimeError as e:
        # Ruby/Synvert not available - fall back to string-based injection
        console.print(
            f"   - [bold yellow]Warning: Synvert not available ({str(e)}). "
            f"Falling back to string-based injection.[/bold yellow]"
        )
        _inject_rails_routes_fallback(path)


def _inject_rails_routes_fallback(path: Path):
    """
    Fallback string-based route injection (legacy method).
    
    Used only when Synvert is unavailable. This is the original
    fragile implementation. Prefer Synvert-based approach via
    _inject_rails_commerce_routes() above.
    
    Args:
        path: Path to Rails project root
    """
    routes_file = path / "config" / "routes.rb"
    if not routes_file.exists():
        return
    
    content = routes_file.read_text(encoding="utf-8")
    
    # Duplicate check
    if "namespace :webhooks" in content:
        return
    
    lines = content.splitlines()
    target_idx = -1
    
    # Find last 'end' in file (brittle - this is why Synvert is preferred)
    for i in range(len(lines) - 1, -1, -1):
        if lines[i].strip() == "end":
            target_idx = i
            break
    
    if target_idx != -1:
        webhook_routes = [
            "",
            "  namespace :webhooks do",
            "    post 'shopify', to: 'shopify#handle'",
            "  end"
        ]
        for i, line in enumerate(webhook_routes):
            lines.insert(target_idx + i, line)
        
        routes_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
        console.print(
            "   - Injected Shopify webhook routes into config/routes.rb "
            "(string-based fallback)"
        )




def _remove_commerce_files(path: Path, template: str):
    python_saas_paths = [path / "src" / "infrastructure" / "commerce", path / "src" / "core" / "interfaces" / "commerce.py", path / "src" / "ui" / "api" / "webhooks.py"]
    rails_paths = [path / "app" / "services" / "commerce", path / "app" / "controllers" / "webhooks" / "shopify_controller.rb"]
    targets = python_saas_paths if template == "python-saas" else (rails_paths if "rails" in template else [])
    for t in targets:
        if t.exists():
            if t.is_dir(): shutil.rmtree(t)
            else: t.unlink()

def _inject_tunnel_config(path: Path, template: str):
    env_files = [path / ".env", path / ".env.example"]
    for env_file in env_files:
        if env_file.exists() and "NGROK_AUTHTOKEN" not in env_file.read_text(encoding="utf-8"):
            with env_file.open("a", encoding="utf-8") as f: f.write("\n# --- Tunneling ---\nNGROK_AUTHTOKEN=your-ngrok-token\n")
    compose_file = path / "docker-compose.yml"
    if compose_file.exists():
        content = compose_file.read_text(encoding="utf-8")
        if "tunnel:" not in content:
            port = "8080" if template == "python-saas" else "3000"
            service_name = "python-saas" if template == "python-saas" else "api"
            tunnel_service = f"\n  tunnel:\n    image: ngrok/ngrok:latest\n    command:\n      - \"http\"\n      - \"{service_name}:{port}\"\n    environment:\n      - NGROK_AUTHTOKEN=${{NGROK_AUTHTOKEN}}\n    depends_on:\n      - {service_name}\n"
            if "services:" in content: compose_file.write_text(content.replace("services:", f"services:\n{tunnel_service}"), encoding="utf-8")
    readme = path / "README.md"
    if readme.exists():
        with open(readme, "a") as f: f.write("\n\n## 🌐 Local Tunneling (ngrok)\nThis project is configured to use ngrok for local tunneling. Add your NGROK_AUTHTOKEN to .env and run `docker-compose up`.\n")

def _inject_landing_instructions(path: Path):
    """Add landing page setup instructions to README."""
    readme = path / "README.md"
    if readme.exists():
        with open(readme, "a") as f:
            f.write("\n\n## 🚀 Static Landing Page (Astro)\n"
                   "This project includes an Astro-powered static landing page.\n"
                   "### Getting Started\n"
                   "```bash\n"
                   "cd static-landing\n"
                   "npm install\n"
                   "npm run dev\n"
                   "```\n"
                   "Visit http://localhost:3000/\n")
        console.print("   - Added landing page documentation to README.md")

def _inject_astro_commerce(path: Path):
    """Integrates commerce features into Astro landing page using ast-grep."""
    index_file = path / "src" / "pages" / "index.astro"
    vault_commerce = FOUNDRY_ROOT / "features" / "landing" / "commerce" / "pricing.astro"
    
    if not (index_file.exists() and vault_commerce.exists()):
        return
    
    pricing_content = vault_commerce.read_text(encoding="utf-8")
    
    try:
        runner = AstGrepRunner()
        if not runner.is_available():
            console.print("[yellow]⚠ ast-grep not available, using legacy approach[/yellow]")
            return _inject_astro_commerce_legacy(path)
        
        # 1. Inject pricing component
        pricing_success = runner.inject_rule(
            target_path=index_file,
            rule_name="astro-inject-pricing-component",
            content_vars={"PRICING_COMPONENT": pricing_content},
            auto_accept=True
        )
        
        if pricing_success:
            console.print("     - Injected commerce pricing components into index.astro")
        
        # 2. Inject SDK integrations (if config file exists)
        config_file = path / "astro.config.mjs"
        vault_config = FOUNDRY_ROOT / "features" / "landing" / "commerce" / "astro.integrations.mjs"
        
        if config_file.exists() and vault_config.exists():
            integrations_content = vault_config.read_text(encoding="utf-8")
            integrations_success = runner.inject_rule(
                target_path=config_file,
                rule_name="astro-inject-sdk-integrations",
                content_vars={"NEW_INTEGRATIONS": integrations_content},
                auto_accept=True
            )
            
            if integrations_success:
                console.print("     - Injected commerce SDK integrations into astro.config.mjs")
    
    except Exception as e:
        console.print(f"[yellow]⚠ ast-grep commerce injection failed: {e}[/yellow]")
        console.print("     - Falling back to legacy marker-based approach")
        return _inject_astro_commerce_legacy(path)

def _inject_astro_auth(path: Path):
    """Integrates authentication features using ast-grep."""
    index_file = path / "src" / "pages" / "index.astro"
    vault_auth = FOUNDRY_ROOT / "features" / "landing" / "auth" / "auth-section.astro"
    
    if not (index_file.exists() and vault_auth.exists()):
        return
    
    auth_content = vault_auth.read_text(encoding="utf-8")
    
    try:
        runner = AstGrepRunner()
        if not runner.is_available():
            console.print("[yellow]⚠ ast-grep not available, using legacy approach[/yellow]")
            return _inject_astro_auth_legacy(path)
        
        success = runner.inject_rule(
            target_path=index_file,
            rule_name="astro-inject-auth-section",
            content_vars={"AUTH_COMPONENT": auth_content},
            auto_accept=True
        )
        
        if success:
            console.print("     - Injected authentication components into index.astro")
    
    except Exception as e:
        console.print(f"[yellow]⚠ ast-grep auth injection failed: {e}[/yellow]")
        console.print("     - Falling back to legacy marker-based approach")
        return _inject_astro_auth_legacy(path)

def inject_merchant_dashboard(path: Path):
    """
    Inject the Merchant Dashboard feature into a React Client project.
    
    This function:
    1. Copies dashboard files from the feature directory
    2. Injects routes into App.jsx
    3. Injects navigation links
    4. Creates API client configuration
    5. Adds environment variables
    """
    # 1. Copy feature directory from vault
    vault_dashboard = FOUNDRY_ROOT / "features" / "react-client" / "merchant-dashboard"
    
    if vault_dashboard.exists():
        console.print("     - Extracting Merchant Dashboard from vault...")
        for item in vault_dashboard.glob("**/*"):
            if item.is_file():
                rel_path = item.relative_to(vault_dashboard)
                target_file = path / rel_path
                target_file.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(item, target_file)
        console.print("     - Dashboard files extracted")
    
    # 2. Inject route into App.jsx
    app_file = path / "src" / "App.jsx"
    if app_file.exists():
        content = app_file.read_text(encoding="utf-8")
        
        # Add import if not present
        if "MerchantDashboard" not in content:
            import_line = "import MerchantDashboard from './pages/MerchantDashboard';\n"
            # Find where to insert the import (after other imports)
            lines = content.splitlines(keepends=True)
            insert_idx = 0
            for i, line in enumerate(lines):
                if "import" in line and "from" in line:
                    insert_idx = i + 1
            lines.insert(insert_idx, import_line)
            content = "".join(lines)
        
        # Inject route marker
        marker_start = "// [SS-FEATURE-DASHBOARD-START]"
        marker_end = "// [SS-FEATURE-DASHBOARD-END]"
        
        if marker_start not in content:
            # Find Routes section and add marker
            if "<Routes>" in content:
                route_injection = f"\n      {marker_start}\n      <Route path=\"/dashboard/*\" element={{<MerchantDashboard />}} />\n      {marker_end}\n"
                content = content.replace("<Routes>", f"<Routes>{route_injection}", 1)
        
        app_file.write_text(content, encoding="utf-8")
        console.print("     - Injected dashboard route into App.jsx")
    
    # 3. Add environment variables
    env_files = [path / ".env", path / ".env.example"]
    dashboard_env_vars = [
        "\n# --- Merchant Dashboard ---",
        "VITE_API_BASE_URL=http://localhost:3000/api/v1",
        "VITE_DASHBOARD_ENABLED=true\n"
    ]
    
    for env_file in env_files:
        if env_file.exists():
            content = env_file.read_text(encoding="utf-8")
            if "VITE_API_BASE_URL" not in content:
                with env_file.open("a", encoding="utf-8") as f:
                    f.write("\n".join(dashboard_env_vars))
    
    console.print("     - Added environment variables for dashboard")
    
    # 4. Print success message with next steps
    console.print("\n[bold green]✅ Merchant Dashboard injected successfully![/bold green]\n")
    console.print("[bold cyan]Next steps:[/bold cyan]")
    console.print("1. Start your server: [yellow]npm run dev[/yellow]")
    console.print("2. Navigate to: [yellow]http://localhost:5173/dashboard[/yellow]")
    console.print("3. Ensure your Rails API has these endpoints:")
    console.print("   - GET  /api/v1/orders")
    console.print("   - GET  /api/v1/merchant/stats")
    console.print("   - GET  /api/v1/webhooks/activity")
    console.print("4. Set VITE_API_BASE_URL in your .env file")
    console.print("\nDashboard is now ready to use! 🎉\n")


# ============================================================================
# LEGACY FALLBACK FUNCTIONS (Marker-Based Approach)
# ============================================================================
# These functions implement the original marker-based injection approach.
# They are used as fallback when ast-grep is not available or injection fails.
# In v3.0.0 (future), these will be removed entirely.
# ============================================================================

def _inject_astro_themes_legacy(path: Path):
    """LEGACY: Original marker-based approach for theme injection - used as fallback."""
    themes_file = path / "src" / "styles" / "themes.css"
    vault_themes = FOUNDRY_ROOT / "features" / "landing" / "themes" / "themes.css"
    
    if themes_file.exists() and vault_themes.exists():
        content = themes_file.read_text(encoding="utf-8")
        premium_content = vault_themes.read_text(encoding="utf-8")
        
        marker_start = "/* [SS-FEATURE-THEMES-START] */"
        marker_end = "/* [SS-FEATURE-THEMES-END] */"
        
        if marker_start in content and marker_end in content:
            # Replace marker block with actual content
            before = content.split(marker_start)[0]
            after = content.split(marker_end)[1]
            new_content = f"{before}{marker_start}\n{premium_content}\n{marker_end}{after}"
            themes_file.write_text(new_content, encoding="utf-8")
            console.print("     - Injected premium theme definitions into themes.css (legacy)")

def _inject_astro_commerce_legacy(path: Path):
    """LEGACY: Original marker-based approach for commerce injection - used as fallback."""
    index_file = path / "src" / "pages" / "index.astro"
    vault_commerce = FOUNDRY_ROOT / "features" / "landing" / "commerce" / "pricing.astro"
    
    if index_file.exists() and vault_commerce.exists():
        content = index_file.read_text(encoding="utf-8")
        commerce_content = vault_commerce.read_text(encoding="utf-8")
        
        marker_start = "{/* [SS-FEATURE-COMMERCE-START] */}"
        marker_end = "{/* [SS-FEATURE-COMMERCE-END] */}"
        
        if marker_start in content and marker_end in content:
            # Replace marker block with actual content
            before = content.split(marker_start)[0]
            after = content.split(marker_end)[1]
            new_content = f"{before}{marker_start}\n{commerce_content}\n{marker_end}{after}"
            index_file.write_text(new_content, encoding="utf-8")
            console.print("     - Injected commerce pricing components into index.astro (legacy)")
    
    # Also update astro.config.mjs to include commerce SDK integrations if available
    config_file = path / "astro.config.mjs"
    vault_config = FOUNDRY_ROOT / "features" / "landing" / "commerce" / "astro.integrations.mjs"
    
    if config_file.exists() and vault_config.exists():
        content = config_file.read_text(encoding="utf-8")
        integrations_content = vault_config.read_text(encoding="utf-8")
        
        marker_start = "/* [SS-FEATURE-SDK-INTEGRATIONS-START] */"
        marker_end = "/* [SS-FEATURE-SDK-INTEGRATIONS-END] */"
        
        if marker_start in content and marker_end in content:
            before = content.split(marker_start)[0]
            after = content.split(marker_end)[1]
            new_content = f"{before}{marker_start}\n    {integrations_content}\n    {marker_end}{after}"
            config_file.write_text(new_content, encoding="utf-8")
            console.print("     - Injected commerce SDK integrations into astro.config.mjs (legacy)")

def _inject_astro_auth_legacy(path: Path):
    """LEGACY: Original marker-based approach for auth injection - used as fallback."""
    index_file = path / "src" / "pages" / "index.astro"
    vault_auth = FOUNDRY_ROOT / "features" / "landing" / "auth" / "auth-section.astro"
    
    if index_file.exists() and vault_auth.exists():
        content = index_file.read_text(encoding="utf-8")
        auth_content = vault_auth.read_text(encoding="utf-8")
        
        marker_start = "{/* [SS-FEATURE-AUTH-START] */}"
        marker_end = "{/* [SS-FEATURE-AUTH-END] */}"
        
        if marker_start in content and marker_end in content:
            # Replace marker block with actual content
            before = content.split(marker_start)[0]
            after = content.split(marker_end)[1]
            new_content = f"{before}{marker_start}\n{auth_content}\n{marker_end}{after}"
            index_file.write_text(new_content, encoding="utf-8")
            console.print("     - Injected authentication components into index.astro (legacy)")
