from foundry.constants import TEMPLATES_DIR, console
from rich.panel import Panel
from rich.tree import Tree


def run_health_check():
    tree = Tree("[bold]Stack Validation Status[/bold]")

    for tmpl_name in [
        "rails-api",
        "rails-ui-kit",
        "python-saas",
        "react-client",
        "data-pipeline",
        "mobile-android",
        "mobile-ios",
    ]:
        tmpl_path = TEMPLATES_DIR / tmpl_name
        if not tmpl_path.exists():
            continue

        node = tree.add(f"[bold cyan]{tmpl_name}[/bold cyan]")

        # Docker Check
        if (tmpl_path / "Dockerfile").exists():
            node.add("[green]✔ Dockerfile[/green]")
        else:
            node.add("[red]✘ Missing Dockerfile[/red]")

        # Git Ignore Check
        if (tmpl_path / ".gitignore").exists():
            node.add("[green]✔ .gitignore[/green]")
        else:
            node.add("[red]✘ Missing .gitignore[/red]")

        # Runbook Check
        if (tmpl_path / "RUNBOOK.md").exists():
            node.add("[green]✔ RUNBOOK.md[/green]")
        else:
            node.add("[red]✘ Missing RUNBOOK.md[/red]")

        # Automation Check
        bin_dir = tmpl_path / "bin"
        if bin_dir.exists() and any(bin_dir.glob("setup*")):
            node.add("[green]✔ Setup scripts (bin/)[/green]")
        elif tmpl_name.startswith("mobile"):
            node.add("[dim]Mobile native (standard layout)[/dim]")
        else:
            node.add("[yellow]⚠ No bin/setup scripts[/yellow]")

        # Env Check
        if (tmpl_path / ".env.example").exists():
            node.add("[green]✔ .env.example[/green]")
        elif tmpl_name in ["terraform-infra", "data-pipeline"]:
            node.add("[dim]No env template needed[/dim]")
        else:
            node.add("[red]✘ Missing .env.example[/red]")

    # Check Terraform (Special Case)
    tf = TEMPLATES_DIR / "terraform-infra"
    if tf.exists():
        t_node = tree.add(f"[bold cyan]{tf.name}[/bold cyan]")
        if (tf / "main.tf").exists():
            t_node.add("[green]✔ main.tf[/green]")
        if (tf / "variables.tf").exists():
            t_node.add("[green]✔ variables.tf[/green]")
        if (tf / "RUNBOOK.md").exists():
            t_node.add("[green]✔ RUNBOOK.md[/green]")

    console.print(Panel(tree, title="Foundry Environment Health"))
