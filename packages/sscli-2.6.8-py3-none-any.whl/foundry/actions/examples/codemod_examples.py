"""
Example codemod commands demonstrating GitGuard integration.

These are template examples showing how to integrate GitGuard
into actual codemod execution commands.
"""

from typing import Optional
import typer

from foundry.constants import console
from foundry.safety import verify_git_status, CodemodSafetyContext

# Example command group
codemod_app = typer.Typer(
    help="Run code transformations (codemods) on projects",
    no_args_is_help=True,
)


@codemod_app.command("upgrade")
def upgrade_codemod(
    name: str = typer.Option(..., help="Project name to upgrade"),
    target_version: Optional[str] = typer.Option(
        None, "--to", help="Target version to upgrade to"
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Bypass git status check (dangerous - may cause data loss)",
    ),
):
    """
    Upgrade a project to the latest template version.
    
    This runs a codemod that updates all dependencies and configurations.
    Requires a clean git repository unless --force is specified.
    """
    # Verify git status before executing codemod
    verify_git_status(force=force)
    
    console.print(f"[bold cyan]→[/bold cyan] Upgrading {name}")
    if target_version:
        console.print(f"[dim]Target version: {target_version}[/dim]")
    
    # TODO: Execute actual upgrade codemod
    console.print("[green]✓[/green] Upgrade complete")


@codemod_app.command("inject")
def inject_feature(
    name: str = typer.Option(..., help="Project name"),
    feature: str = typer.Argument(..., help="Feature to inject (auth, commerce, etc)"),
    force: bool = typer.Option(
        False,
        "--force",
        help="Bypass git status check",
    ),
):
    """
    Inject a feature into an existing project.
    
    Inserts boilerplate code for features like authentication, commerce, etc.
    """
    verify_git_status(force=force)
    
    console.print(f"[bold cyan]→[/bold cyan] Injecting {feature} into {name}")
    
    # TODO: Execute injection codemod
    console.print(f"[green]✓[/green] {feature} injected successfully")


@codemod_app.command("migrate")
def migrate_codemod(
    name: str = typer.Option(..., help="Project name"),
    from_version: str = typer.Option(..., "--from", help="Source version"),
    to_version: str = typer.Option(..., "--to", help="Target version"),
    force: bool = typer.Option(
        False,
        "--force",
        help="Bypass git status check",
    ),
):
    """
    Migrate a project between major versions.
    
    This is a complex codemod that may make significant changes.
    Always ensures repository is clean first.
    """
    verify_git_status(force=force)
    
    console.print(
        f"[bold cyan]→[/bold cyan] Migrating {name} from {from_version} to {to_version}"
    )
    
    # TODO: Execute migration codemod
    console.print("[green]✓[/green] Migration complete")


@codemod_app.command("refactor")
def refactor_codemod(
    name: str = typer.Option(..., help="Project name"),
    pattern: Optional[str] = typer.Option(
        None, "--pattern", help="Pattern to refactor (optional)"
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Bypass git status check",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Show changes without applying them",
    ),
):
    """
    Refactor code patterns in a project.
    
    Uses AST/pattern matching to refactor code structures.
    """
    # Even with dry-run, we want to verify git status to catch issues early
    verify_git_status(force=force)
    
    console.print(f"[bold cyan]→[/bold cyan] Refactoring {name}")
    if pattern:
        console.print(f"[dim]Pattern: {pattern}[/dim]")
    if dry_run:
        console.print("[dim][DRY RUN - No changes will be applied][/dim]")
    
    # TODO: Execute refactor codemod
    console.print("[green]✓[/green] Refactoring complete")


@codemod_app.command("validate")
def validate_codemods(
    name: str = typer.Option(..., help="Project name"),
):
    """
    Validate that codemods can run against this project.
    
    Checks compatibility without making changes.
    Does NOT require clean git status.
    """
    console.print(f"[bold cyan]→[/bold cyan] Validating codemods for {name}")
    
    # TODO: Run validation checks
    console.print("[green]✓[/green] Project is compatible with codemods")


# Advanced example: Using CodemodSafetyContext for more control
@codemod_app.command("batch")
def batch_codemods(
    name: str = typer.Option(..., help="Project name"),
    force: bool = typer.Option(
        False,
        "--force",
        help="Bypass git status check",
    ),
):
    """
    Run multiple codemods in sequence with rollback capability.
    
    This example shows using CodemodSafetyContext for more control.
    """
    with CodemodSafetyContext(force=force) as safety:
        if not safety.is_safe:
            console.print("[yellow]⚠️  Cannot proceed - resolve git status issues first[/yellow]")
            raise typer.Exit(code=1)
        
        console.print(f"[bold cyan]→[/bold cyan] Running batch codemods on {name}")
        
        # Run multiple codemods
        codemods_to_run = [
            ("upgrade", "Upgrade dependencies"),
            ("inject:auth", "Add authentication"),
            ("refactor:naming", "Update naming conventions"),
        ]
        
        for codemod_id, description in codemods_to_run:
            console.print(f"[dim]  • {description}...[/dim]", end=" ", highlight=False)
            # TODO: Execute codemod
            console.print("[green]✓[/green]")
        
        console.print("[green]✓[/green] All codemods completed successfully")


# Example showing git status before decision
@codemod_app.callback(invoke_without_command=True)
def show_git_hint(ctx: typer.Context):
    """Show helpful hint about git status."""
    if ctx.invoked_subcommand is None:
        return
    
    from foundry.safety import GitGuard
    
    guard = GitGuard()
    if guard.is_git_repo():
        is_clean, _ = guard.status_clean()
        if not is_clean:
            console.print(
                "[yellow]⚠️  Tip: Repository has uncommitted changes[/yellow] "
                "[dim](use --force to bypass)[/dim]"
            )
