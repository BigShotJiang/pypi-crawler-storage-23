#!/usr/bin/env python3
"""
Native Python Template Verification System Wrapper.
Modular implementation moved to foundry.actions.verification.
"""

import sys
import subprocess
from typing import Optional
from pathlib import Path
from foundry.constants import console

# Relative imports to work within the foundry package
from .verification.verifier import TemplateVerifier
from .verification.reports import generate_reports, print_summary


def run_feature_matrix_tests() -> bool:
    """Run the integration feature matrix tests."""
    console.print("[bold cyan]→[/bold cyan] Running Feature Matrix Integration Tests...")
    console.print("")
    
    # Find the stack-cli root
    stack_cli_root = Path(__file__).resolve().parent.parent.parent
    
    # Run pytest on the integration tests
    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "pytest",
                "tests/integration/test_feature_matrix.py",
                "-v", "--tb=short",
                "-x",  # Stop on first failure
            ],
            cwd=str(stack_cli_root),
            timeout=600,  # 10-minute timeout for all tests
        )
        
        success = result.returncode == 0
        console.print("")
        
        if success:
            console.print("[green]✓[/green] Feature matrix tests passed")
        else:
            console.print("[red]✗[/red] Feature matrix tests failed")
        
        return success
    
    except subprocess.TimeoutExpired:
        console.print("[red]✗[/red] Feature matrix tests timed out after 10 minutes")
        return False
    except Exception as e:
        console.print(f"[red]✗[/red] Error running feature matrix tests: {e}")
        return False


def run_verification(
    include_docker: bool = True, 
    output_reports: bool = True,
    include_features: bool = False,
):
    """Entry point for template verification."""
    # Find root directory (foundry-meta)
    root_dir = Path(__file__).resolve().parent.parent.parent.parent.parent
    
    console.print("[bold]Template Verification[/bold]")
    console.print("")
    
    # Run standard template verification
    verifier = TemplateVerifier(root_dir=root_dir)
    results = verifier.verify_all(include_docker=include_docker)

    if output_reports:
        generate_reports(results, root_dir)

    exit_code = print_summary(results)
    
    # Run feature matrix tests if requested
    if include_features:
        console.print("")
        console.print("[bold]Integration Tests[/bold]")
        console.print("")
        
        if run_feature_matrix_tests():
            console.print("")
            console.print("[green]✓[/green] All verification tests passed")
        else:
            console.print("")
            console.print("[red]✗[/red] Some verification tests failed")
            exit_code = 1
    
