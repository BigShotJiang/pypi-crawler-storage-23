from dataclasses import dataclass
from enum import Enum


class TemplateType(Enum):
    """Types of templates based on build system."""
    DOCKER = "docker"
    TERRAFORM = "terraform"
    NODE = "node"


class VerificationStatus(Enum):
    """Status of template verification."""
    SUCCESS = "Success"
    FAILED = "Failed"
    PARTIAL = "Partial"
    SKIPPED = "Skipped"
    ERROR = "Error"


@dataclass
class VerificationResult:
    """Result of a single template verification."""
    name: str
    template_type: TemplateType
    status: VerificationStatus
    git_ignore: bool
    git_attributes: bool
    docker_success: bool
    duration_seconds: float
    notes: str = ""
    timestamp: str = ""

    def to_dict(self) -> dict:
        """Convert result to dictionary."""
        return {
            "template": self.name,
            "type": self.template_type.value,
            "status": self.status.value,
            "git_ignore": self.git_ignore,
            "git_attributes": self.git_attributes,
            "docker_build": self.docker_success,
            "duration": round(self.duration_seconds, 2),
            "notes": self.notes,
            "timestamp": self.timestamp,
        }
