"""
Git Guard: Safety mechanism to prevent data loss during codemod execution.

This module provides utilities to verify git repository cleanliness before
executing transformations, protecting users from accidental data loss.
"""

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple


class GitStatusError(Exception):
    """Raised when git status check fails or repository is dirty."""
    pass


@dataclass
class GitGuardConfig:
    """Configuration options for GitGuard behavior."""
    allow_untracked: bool = False
    allow_unstaged: bool = False
    allow_staged: bool = False
    allow_merge_conflicts: bool = False


class GitGuard:
    """
    Validates git repository state before executing codemods.
    
    Prevents users from losing code by ensuring:
    - Repository is initialized
    - No uncommitted changes (staged or unstaged)
    - No untracked files (configurable)
    - No merge conflicts
    
    Example:
        >>> guard = GitGuard()
        >>> guard.require_clean_status()  # Raises if dirty
        >>> # Safe to execute codemod
    """

    def __init__(
        self,
        cwd: Optional[Path] = None,
        config: Optional[GitGuardConfig] = None,
    ):
        """
        Initialize GitGuard.
        
        Args:
            cwd: Working directory to check (defaults to current directory)
            config: Configuration options for what to allow
        """
        self.cwd = cwd or Path.cwd()
        self.config = config or GitGuardConfig()

    def is_git_repo(self) -> bool:
        """
        Check if the current directory is in a git repository.
        
        Returns:
            True if in a git repository, False otherwise
        """
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--git-dir"],
                cwd=str(self.cwd),
                capture_output=True,
                timeout=5,
            )
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return False

    def get_git_root(self) -> Optional[Path]:
        """
        Get the root directory of the git repository.
        
        Returns:
            Path to git root or None if not in a git repository
        """
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                cwd=str(self.cwd),
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                return Path(result.stdout.strip())
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass
        return None

    def get_status_summary(self) -> dict:
        """
        Get detailed information about git status.
        
        Returns:
            Dictionary with status information:
            - is_git_repo: bool - Whether in a git repository
            - is_clean: bool - Whether repository is clean
            - staged_files: list - Files staged for commit
            - unstaged_files: list - Files with unstaged changes
            - untracked_files: list - Files not tracked by git
            - merge_conflicts: list - Files with merge conflicts
        """
        status = {
            "is_git_repo": self.is_git_repo(),
            "is_clean": False,
            "staged_files": [],
            "unstaged_files": [],
            "untracked_files": [],
            "merge_conflicts": [],
        }

        if not status["is_git_repo"]:
            return status

        try:
            # Get status in porcelain format for easy parsing
            result = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=str(self.cwd),
                capture_output=True,
                text=True,
                timeout=5,
            )

            if result.returncode != 0:
                return status

            for line in result.stdout.splitlines():
                if not line:
                    continue

                code = line[:2]
                filepath = line[3:]

                # Parse status codes (XY format)
                # X = staged changes, Y = unstaged changes
                x_status = code[0]
                y_status = code[1]

                # Check for staged changes
                if x_status != " " and x_status != "?":
                    status["staged_files"].append(filepath)

                # Check for unstaged changes
                if y_status != " " and y_status != "?":
                    status["unstaged_files"].append(filepath)

                # Check for untracked files
                if code == "??":
                    status["untracked_files"].append(filepath)

                # Check for merge conflicts
                if "U" in code or "DD" in code or "AA" in code:
                    status["merge_conflicts"].append(filepath)

        except (subprocess.TimeoutExpired, FileNotFoundError):
            return status

        # Determine if clean based on configuration
        has_staged = len(status["staged_files"]) > 0
        has_unstaged = len(status["unstaged_files"]) > 0
        has_untracked = len(status["untracked_files"]) > 0
        has_conflicts = len(status["merge_conflicts"]) > 0

        is_clean = True
        if has_staged and not self.config.allow_staged:
            is_clean = False
        if has_unstaged and not self.config.allow_unstaged:
            is_clean = False
        if has_untracked and not self.config.allow_untracked:
            is_clean = False
        if has_conflicts and not self.config.allow_merge_conflicts:
            is_clean = False

        status["is_clean"] = is_clean
        return status

    def status_clean(self) -> Tuple[bool, str]:
        """
        Check if repository status is clean.
        
        Returns:
            Tuple of (is_clean: bool, message: str)
            - is_clean: True if repository is clean (or issues are allowed)
            - message: Explanation of any issues found
        """
        status = self.get_status_summary()

        if not status["is_git_repo"]:
            return False, "Not in a git repository"

        if status["is_clean"]:
            return True, "Repository is clean"

        # Build detailed message
        issues = []

        if status["merge_conflicts"]:
            issues.append(
                f"  • Merge conflicts found ({len(status['merge_conflicts'])} files)"
            )

        if status["staged_files"] and not self.config.allow_staged:
            issues.append(
                f"  • Staged changes ({len(status['staged_files'])} files)"
            )

        if status["unstaged_files"] and not self.config.allow_unstaged:
            issues.append(
                f"  • Unstaged changes ({len(status['unstaged_files'])} files)"
            )

        if status["untracked_files"] and not self.config.allow_untracked:
            issues.append(
                f"  • Untracked files ({len(status['untracked_files'])} files)"
            )

        message = "Repository has uncommitted changes:\n" + "\n".join(issues)
        return False, message

    def require_clean_status(self) -> None:
        """
        Require repository to be clean, raise exception if not.
        
        Raises:
            GitStatusError: If repository is not clean
        """
        is_clean, message = self.status_clean()

        if not is_clean:
            raise GitStatusError(message)


def get_git_guard_suggestions() -> str:
    """Get helpful suggestions for resolving git status issues."""
    return """
[bold cyan]💡 Suggestions to fix git status:[/bold cyan]

[dim]1. Commit changes:[/dim]
   git add .
   git commit -m "Before running codemod"

[dim]2. Stash changes (temporary):[/dim]
   git stash
   # Run codemod here
   git stash pop

[dim]3. View changes:[/dim]
   git status          # See what changed
   git diff            # See unstaged changes
   git diff --staged   # See staged changes

[dim]4. Clean up untracked files:[/dim]
   git clean -fn       # Dry run: show what would be deleted
   git clean -fd       # Actually delete untracked files

[dim]5. Continue anyway (not recommended):[/dim]
   # Add --force flag when running the command
"""
