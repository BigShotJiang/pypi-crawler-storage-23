"""
Codemods module for safe configuration transformations.

This module provides a clean, type-safe interface for modifying project
configuration files (especially pyproject.toml) and source code using proper parsing
instead of string manipulation.

Supports:
- TOML transformations (pyproject.toml)
- Python code modifications (using libcst for AST-aware changes)
- JavaScript/TypeScript changes (using ast-grep)
- Ruby/Rails modifications (using Synvert or ast-grep)
"""

from foundry.codemods.base import (
    BaseCodemod,
    TomlTransformer,
    CodemodPipeline,
    ModificationResult
)

from foundry.codemods.toml_codemods import (
    AddPythonDependencyCM,
    RemovePythonDependencyCM,
    RemoveToolSectionsCM,
    UpdateValueCM,
    AddPythonVersionCM,
    IdempotentAddDependencyCM
)

from foundry.codemods.python_codemods import (
    PythonCodemod,
    InjectImportCodemod as PythonInjectImportCodemod,
    InjectCallCodemod as PythonInjectCallCodemod,
    InjectConstantCodemod as PythonInjectConstantCodemod
)

from foundry.codemods.js_codemods import (
    JsCodemod,
    InjectImportCodemod as JsInjectImportCodemod,
    InjectRouteCodemod as JsInjectRouteCodemod,
    InjectCallCodemod as JsInjectCallCodemod,
    InjectConstantCodemod as JsInjectConstantCodemod
)

from foundry.codemods.ruby_codemods import (
    RubyCodemod,
    InjectRouteCodemod as RubyInjectRouteCodemod,
    InjectCallCodemod as RubyInjectCallCodemod,
    InjectConstantCodemod as RubyInjectConstantCodemod
)

from foundry.codemods.delta_store import (
    CodemodMetadata,
    CodemodDefinition,
    DeltaStore
)

__all__ = [
    # Base classes
    "BaseCodemod",
    "TomlTransformer",
    "CodemodPipeline",
    "ModificationResult",
    # Concrete implementations
    "AddPythonDependencyCM",
    "RemovePythonDependencyCM",
    "RemoveToolSectionsCM",
    "UpdateValueCM",
    "AddPythonVersionCM",
    "IdempotentAddDependencyCM",
    # Python codemods
    "PythonCodemod",
    "PythonInjectImportCodemod",
    "PythonInjectCallCodemod",
    "PythonInjectConstantCodemod",
    # JavaScript codemods
    "JsCodemod",
    "JsInjectImportCodemod",
    "JsInjectRouteCodemod",
    "JsInjectCallCodemod",
    "JsInjectConstantCodemod",
    # Ruby codemods
    "RubyCodemod",
    "RubyInjectRouteCodemod",
    "RubyInjectCallCodemod",
    "RubyInjectConstantCodemod",
    # Delta Store (Phase 3)
    "CodemodMetadata",
    "CodemodDefinition",
    "DeltaStore",
]

