"""
Python codemods using libcst for safe AST-based transformations.

Provides formatting-aware code modifications for Python files including:
- Import injection (idempotent)
- Function/method call injection
- Module constant injection
- Safe indentation and formatting preservation
"""

from pathlib import Path
from typing import Optional, List, Tuple
import libcst as cst
from libcst import matchers as m

from foundry.codemods.base import BaseCodemod, ModificationResult


class PythonCodemod(BaseCodemod):
    """
    Base class for libcst-based Python code transformations.
    Handles safe parsing, transformation, and serialization with formatting preservation.
    """

    def apply(self, path: Path) -> ModificationResult:
        """Apply Python code transformation using libcst."""
        if not path.exists():
            return ModificationResult(
                success=False,
                error=f"File not found: {path}"
            )

        try:
            original_content = path.read_text(encoding="utf-8")
            
            # Parse with libcst
            try:
                tree = cst.parse_module(original_content)
            except Exception as e:
                return ModificationResult(
                    success=False,
                    error=f"Failed to parse Python file: {str(e)}"
                )

            # Apply transformation
            try:
                modified_tree = tree.visit(self.get_visitor())
            except Exception as e:
                return ModificationResult(
                    success=False,
                    error=f"Transformation failed: {str(e)}"
                )

            # Serialize preserving formatting
            modified_content = modified_tree.code

            # Validate
            if not self.validate(original_content, modified_content):
                return ModificationResult(
                    success=False,
                    error="Transformation validation failed"
                )

            # Write if changed
            if modified_content != original_content:
                path.write_text(modified_content, encoding="utf-8")
                return ModificationResult(
                    success=True,
                    modified_path=path,
                    changes_made=1
                )
            else:
                return ModificationResult(
                    success=True,
                    modified_path=path,
                    changes_made=0
                )

        except Exception as e:
            return ModificationResult(
                success=False,
                error=f"{self.__class__.__name__}: {str(e)}"
            )

    def get_visitor(self) -> cst.CSTTransformer:
        """
        Return the visitor/transformer for this codemod.
        Override in subclasses.
        """
        raise NotImplementedError


class InjectImportCodemod(PythonCodemod):
    """
    Add an import statement to Python file without duplicates.
    Preserves existing imports and formatting.
    
    Examples:
        from foo import Bar
        from foo.bar import baz
        import sys
    """

    def __init__(
        self,
        module: str,
        names: Optional[List[str]] = None,
        alias: Optional[str] = None
    ):
        """
        Args:
            module: Module to import from (e.g., 'flask')
            names: Specific names to import (e.g., ['request', 'jsonify']).
                   If None, imports entire module.
            alias: Alias for import (e.g., 'pd' for 'pandas')
        """
        self.module = module
        self.names = names or []
        self.alias = alias

    def get_visitor(self) -> cst.CSTTransformer:
        """Return visitor that injects import statement."""
        return _ImportInjector(self.module, self.names, self.alias)


class _ImportInjector(cst.CSTTransformer):
    """Visitor that injects import statements idempotently."""

    def __init__(self, module: str, names: List[str], alias: Optional[str]):
        self.module = module
        self.names = names
        self.alias = alias
        self.import_exists = False
        self.modified = False

    def visit_ImportFrom(self, node: cst.ImportFrom) -> None:
        """Check if import already exists."""
        module_name = self._get_module_name(node.module)
        if module_name == self.module:
            # Check if this is the exact import we want
            if self.names:
                if isinstance(node.names, cst.ImportStar):
                    self.import_exists = True
                else:
                    existing_names = {
                        self._get_import_name(item.name)
                        for item in node.names
                        if isinstance(item, cst.ImportAlias)
                    }
                    if all(name in existing_names for name in self.names):
                        self.import_exists = True
            else:
                self.import_exists = True

    def leave_Module(
        self,
        original_node: cst.Module,
        updated_node: cst.Module
    ) -> cst.Module:
        """Add import statement if it doesn't exist."""
        if self.import_exists:
            return updated_node

        # Build import statement
        if self.names:
            # from module import name1, name2
            import_aliases = [
                cst.ImportAlias(name=cst.Name(name))
                for name in self.names
            ]
            new_import = cst.SimpleStatementLine(
                body=[
                    cst.ImportFrom(
                        module=cst.Attribute(
                            value=cst.Name(self.module.split('.')[0]),
                            attr=cst.Name(self.module.split('.')[1])
                        ) if '.' in self.module else cst.Name(self.module),
                        names=import_aliases
                    )
                ]
            )
        else:
            # import module as alias
            new_import = cst.SimpleStatementLine(
                body=[
                    cst.Import(
                        names=[
                            cst.ImportAlias(
                                name=cst.Attribute(
                                    value=cst.Name(self.module.split('.')[0]),
                                    attr=cst.Name(self.module.split('.')[1])
                                ) if '.' in self.module else cst.Name(self.module),
                                asname=cst.AsName(
                                    name=cst.Name(self.alias),
                                    whitespace_before_as=cst.SimpleWhitespace(" "),
                                    whitespace_after_as=cst.SimpleWhitespace(" ")
                                ) if self.alias else None
                            )
                        ]
                    )
                ]
            )

        # Insert after existing imports
        new_body = list(updated_node.body)
        insert_idx = 0

        # Find position after existing imports
        for i, stmt in enumerate(new_body):
            if isinstance(stmt, cst.SimpleStatementLine):
                if any(isinstance(s, (cst.Import, cst.ImportFrom)) for s in stmt.body):
                    insert_idx = i + 1
                elif any(isinstance(s, cst.Pass) for s in stmt.body):
                    break
            else:
                break

        new_body.insert(insert_idx, new_import)
        self.modified = True
        return updated_node.with_changes(body=new_body)

    @staticmethod
    def _get_module_name(node: Optional[cst.BaseExpression]) -> str:
        """Extract full module name from node."""
        if node is None:
            return ""
        if isinstance(node, cst.Name):
            return node.value
        if isinstance(node, cst.Attribute):
            base = InjectImportCodemod._get_module_name(node.value)
            return f"{base}.{node.attr.value}" if base else node.attr.value
        return ""

    @staticmethod
    def _get_import_name(node: cst.BaseExpression) -> str:
        """Extract import name from node."""
        if isinstance(node, cst.Name):
            return node.value
        if isinstance(node, cst.Attribute):
            return node.attr.value
        return ""


class InjectCallCodemod(PythonCodemod):
    """
    Add a function or method call to initialization code.
    Finds a target function and inserts a call at the end.
    
    Example:
        app.register_blueprint(auth_blueprint)
    """

    def __init__(
        self,
        target_func: str,
        call_statement: str,
        after_func: Optional[str] = None
    ):
        """
        Args:
            target_func: Name of function containing initialization (e.g., 'main')
            call_statement: Full call statement to inject (e.g., 'app.register_blueprint(bp)')
            after_func: If set, insert after this function call instead of at end
        """
        self.target_func = target_func
        self.call_statement = call_statement
        self.after_func = after_func

    def get_visitor(self) -> cst.CSTTransformer:
        """Return visitor that injects function call."""
        return _CallInjector(self.target_func, self.call_statement, self.after_func)


class _CallInjector(cst.CSTTransformer):
    """Visitor that injects function calls into initialization code."""

    def __init__(self, target_func: str, call_statement: str, after_func: Optional[str]):
        self.target_func = target_func
        self.call_statement = call_statement
        self.after_func = after_func

    def leave_FunctionDef(
        self,
        original_node: cst.FunctionDef,
        updated_node: cst.FunctionDef
    ) -> cst.FunctionDef:
        """Inject call into target function."""
        if updated_node.name.value != self.target_func:
            return updated_node

        # Parse the call statement
        try:
            call_expr = cst.parse_statement(self.call_statement + "\n")
        except Exception:
            return updated_node

        # Find insertion point
        body = updated_node.body
        if isinstance(body, cst.SimpleStatementSuite):
            return updated_node

        if isinstance(body, cst.IndentedBlock):
            statements = list(body.body)
            
            # Check for duplicate
            for stmt in statements:
                if self.call_statement in stmt.body[0].value.code if hasattr(stmt, 'body') else False:
                    return updated_node

            statements.append(call_expr)
            new_body = body.with_changes(body=statements)
            return updated_node.with_changes(body=new_body)

        return updated_node


class InjectConstantCodemod(PythonCodemod):
    """
    Add a module-level constant or configuration variable.
    Idempotent - won't add if already exists.
    
    Example:
        DATABASE_URL = "postgresql://..."
        API_KEY = os.environ.get("API_KEY")
    """

    def __init__(
        self,
        name: str,
        value: str,
        position: str = "module"
    ):
        """
        Args:
            name: Constant name (e.g., 'API_KEY')
            value: Value expression (e.g., '"my-key"' or 'os.environ.get("API_KEY")')
            position: Where to insert ('module', 'after_imports')
        """
        self.name = name
        self.value = value
        self.position = position

    def get_visitor(self) -> cst.CSTTransformer:
        """Return visitor that injects constant."""
        return _ConstantInjector(self.name, self.value, self.position)


class _ConstantInjector(cst.CSTTransformer):
    """Visitor that injects module constants."""

    def __init__(self, name: str, value: str, position: str):
        self.name = name
        self.value = value
        self.position = position
        self.constant_exists = False

    def visit_Assign(self, node: cst.Assign) -> None:
        """Check if constant already exists."""
        for target in node.targets:
            if isinstance(target.target, cst.Name):
                if target.target.value == self.name:
                    self.constant_exists = True

    def leave_Module(
        self,
        original_node: cst.Module,
        updated_node: cst.Module
    ) -> cst.Module:
        """Add constant if it doesn't exist."""
        if self.constant_exists:
            return updated_node

        # Parse the constant assignment
        try:
            const_stmt = cst.parse_statement(f"{self.name} = {self.value}\n")
        except Exception:
            return updated_node

        new_body = list(updated_node.body)
        insert_idx = 0

        # Find insertion point based on position
        if self.position == "module":
            # Insert after last import
            for i, stmt in enumerate(new_body):
                if isinstance(stmt, cst.SimpleStatementLine):
                    if any(isinstance(s, (cst.Import, cst.ImportFrom)) for s in stmt.body):
                        insert_idx = i + 1

        new_body.insert(insert_idx, const_stmt)
        return updated_node.with_changes(body=new_body)
