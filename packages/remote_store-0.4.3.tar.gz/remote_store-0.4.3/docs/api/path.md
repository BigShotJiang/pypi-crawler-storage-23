# RemotePath

`RemotePath` is a validated, immutable value object representing a path within a store. Paths are always forward-slash separated and normalized.

::: remote_store.RemotePath
