# Error Handling

Catching `NotFound`, `AlreadyExists`, and other exceptions.

```python
--8<-- "examples/error_handling.py"
```
