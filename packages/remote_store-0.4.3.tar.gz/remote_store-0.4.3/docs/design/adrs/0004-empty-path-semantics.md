{%
   include-markdown "../../../sdd/adrs/0004-empty-path-semantics.md"
   rewrite-relative-urls=false
%}
