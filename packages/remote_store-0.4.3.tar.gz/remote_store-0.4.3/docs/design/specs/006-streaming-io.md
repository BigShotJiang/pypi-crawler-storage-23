{%
   include-markdown "../../../sdd/specs/006-streaming-io.md"
   rewrite-relative-urls=false
%}
