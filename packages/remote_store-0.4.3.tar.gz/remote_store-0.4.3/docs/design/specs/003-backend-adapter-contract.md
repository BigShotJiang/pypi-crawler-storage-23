{%
   include-markdown "../../../sdd/specs/003-backend-adapter-contract.md"
   rewrite-relative-urls=false
%}
