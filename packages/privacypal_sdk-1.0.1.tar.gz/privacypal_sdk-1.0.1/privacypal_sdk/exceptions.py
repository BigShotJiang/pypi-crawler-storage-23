"""
Exception hierarchy for the PrivacyPal Python SDK.

Error message patterns mirror the Node.js SDK so consuming code can use
the same detection logic (e.g. ``str(e).startswith("401:")``).
"""


class PrivacyPalError(Exception):
    """Base class for all SDK errors."""

    def __init__(self, message: str, status_code: int | None = None):
        self.status_code = status_code
        super().__init__(message)


class AuthenticationError(PrivacyPalError):
    """Raised on HTTP 401 — token missing, expired, or invalid."""


class TrialExpiredError(PrivacyPalError):
    """Raised on HTTP 403 when trial/subscription is required."""


class NetworkError(PrivacyPalError):
    """Raised when the API is unreachable (connection refused, DNS failure, etc.)."""


class RequestError(PrivacyPalError):
    """Raised for request-level configuration errors."""
