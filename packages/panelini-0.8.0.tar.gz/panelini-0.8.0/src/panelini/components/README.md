# Panelini - Components

Dependent components for Panelini that have specific dependencies on other Panelini classes.

> These components are designed to be used within the Panelini framework and may not function properly outside of it due to their reliance on Panelini's architecture and features.
