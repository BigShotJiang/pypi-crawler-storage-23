# Panelini - Panels

Independent standalone panels usable without Panelini dependency.

> This is desired for reusability of panels in panelini itself but also in other contexts, e.g. in panel apps without Panelini, or in other frameworks.
