"""Reusable Panel components for interactive visualization."""
