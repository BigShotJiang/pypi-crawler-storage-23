# JsonEditor Vue Component

## Build

```bash
npm install
npm run build
npm run watch  # auto-rebuild on file changes
```

You may combine the watch command with the panel serve command to auto-reload the panel on changes:

```bash
panel serve your_app.py --autoreload  # auto-reload on Python file changes
```
