module.exports = {
  plugins: {
    'postcss-prefixwrap': '.bootstrap-wrapper',
  },
};
