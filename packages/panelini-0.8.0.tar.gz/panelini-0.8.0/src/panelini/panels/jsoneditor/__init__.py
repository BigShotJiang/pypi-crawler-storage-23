# this allows 'from panelini.panels.jsoneditor import JsonEditor'
from .jsoneditor import JsonEditor  # noqa: F401
