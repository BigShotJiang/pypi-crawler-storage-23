module.exports = {
  plugins: {
    'postcss-prefixwrap': '.visnetwork-wrapper',
  },
};
