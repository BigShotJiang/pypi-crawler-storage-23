# {py:mod}`panelini.panels.jsoneditor`

```{py:module} panelini.panels.jsoneditor
```

```{autodoc2-docstring} panelini.panels.jsoneditor
:allowtitles:
```

## Submodules

```{toctree}
:titlesonly:
:maxdepth: 1

panelini.panels.jsoneditor.jsoneditor
```
