# {py:mod}`panelini.components`

```{py:module} panelini.components
```

```{autodoc2-docstring} panelini.components
:allowtitles:
```
