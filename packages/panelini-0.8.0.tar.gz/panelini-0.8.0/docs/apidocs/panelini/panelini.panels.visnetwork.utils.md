# {py:mod}`panelini.panels.visnetwork.utils`

```{py:module} panelini.panels.visnetwork.utils
```

```{autodoc2-docstring} panelini.panels.visnetwork.utils
:allowtitles:
```

## Module Contents

### Functions

````{list-table}
:class: autosummary longtable
:align: left

* - {py:obj}`data_url_to_bytes <panelini.panels.visnetwork.utils.data_url_to_bytes>`
  - ```{autodoc2-docstring} panelini.panels.visnetwork.utils.data_url_to_bytes
    :summary:
    ```
````

### API

````{py:function} data_url_to_bytes(data_url: str) -> bytes
:canonical: panelini.panels.visnetwork.utils.data_url_to_bytes

```{autodoc2-docstring} panelini.panels.visnetwork.utils.data_url_to_bytes
```
````
