# {py:mod}`panelini.panels`

```{py:module} panelini.panels
```

```{autodoc2-docstring} panelini.panels
:allowtitles:
```

## Subpackages

```{toctree}
:titlesonly:
:maxdepth: 3

panelini.panels.jsoneditor
panelini.panels.visnetwork
```
