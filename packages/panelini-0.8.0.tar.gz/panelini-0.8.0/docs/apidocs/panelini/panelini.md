# {py:mod}`panelini`

```{py:module} panelini
```

```{autodoc2-docstring} panelini
:allowtitles:
```

## Subpackages

```{toctree}
:titlesonly:
:maxdepth: 3

panelini.panels
panelini.components
```

## Submodules

```{toctree}
:titlesonly:
:maxdepth: 1

panelini.main
```
