# {py:mod}`panelini.panels.jsoneditor.jsoneditor`

```{py:module} panelini.panels.jsoneditor.jsoneditor
```

```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor
:allowtitles:
```

## Module Contents

### Classes

````{list-table}
:class: autosummary longtable
:align: left

* - {py:obj}`JsonEditor <panelini.panels.jsoneditor.jsoneditor.JsonEditor>`
  - ```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.JsonEditor
    :summary:
    ```
````

### Data

````{list-table}
:class: autosummary longtable
:align: left

* - {py:obj}`bundled_assets_dir <panelini.panels.jsoneditor.jsoneditor.bundled_assets_dir>`
  - ```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.bundled_assets_dir
    :summary:
    ```
````

### API

````{py:data} bundled_assets_dir
:canonical: panelini.panels.jsoneditor.jsoneditor.bundled_assets_dir
:value: >
   None

```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.bundled_assets_dir
```

````

`````{py:class} JsonEditor(**params)
:canonical: panelini.panels.jsoneditor.jsoneditor.JsonEditor

Bases: {py:obj}`panel.custom.AnyWidgetComponent`

```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.JsonEditor
```

```{rubric} Initialization
```

```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.JsonEditor.__init__
```

````{py:attribute} value
:canonical: panelini.panels.jsoneditor.jsoneditor.JsonEditor.value
:value: >
   'Dict(...)'

```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.JsonEditor.value
```

````

````{py:attribute} options
:canonical: panelini.panels.jsoneditor.jsoneditor.JsonEditor.options
:value: >
   'Dict(...)'

```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.JsonEditor.options
```

````

````{py:attribute} ready
:canonical: panelini.panels.jsoneditor.jsoneditor.JsonEditor.ready
:value: >
   'Boolean(...)'

```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.JsonEditor.ready
```

````

````{py:attribute} encoder
:canonical: panelini.panels.jsoneditor.jsoneditor.JsonEditor.encoder
:value: >
   'ClassSelector(...)'

```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.JsonEditor.encoder
```

````

````{py:method} get_value() -> dict
:canonical: panelini.panels.jsoneditor.jsoneditor.JsonEditor.get_value

```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.JsonEditor.get_value
```

````

````{py:method} set_value(value: dict) -> None
:canonical: panelini.panels.jsoneditor.jsoneditor.JsonEditor.set_value

```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.JsonEditor.set_value
```

````

````{py:method} set_schema(schema: dict, startval: dict | None = None, keep_value: bool = False) -> None
:canonical: panelini.panels.jsoneditor.jsoneditor.JsonEditor.set_schema

```{autodoc2-docstring} panelini.panels.jsoneditor.jsoneditor.JsonEditor.set_schema
```

````

`````
