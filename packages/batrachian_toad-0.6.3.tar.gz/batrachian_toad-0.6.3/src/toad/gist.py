async def upload(content: str) -> None:
    pass
