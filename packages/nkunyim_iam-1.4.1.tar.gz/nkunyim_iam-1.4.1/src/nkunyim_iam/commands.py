from datetime import datetime
from enum import Enum
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class ServiceConfigCommand(BaseModel):
    url: str = ''
    key: str = ''
    verify: bool = False
    

class HashingAlgo(str, Enum):
    S256 = "S256"
    S384 = "S384"
    S512 = "S512"

class IdentityConfigCommand(BaseModel):
    base_url: str = "https://auth.nkunyim.local"
    back_url: str = "http://auth.nkunyim.local"
    front_url: str = "https://auth.nkunyim.local"
    issuer: str = "https://auth.nkunyim.local"
    client_id: str
    client_secret: str
    client_scope: str = "openid profile email phone offline_access"
    redirect_uri: str = "https://app.nkunyim.local/auth/callback/"
    response_type: str = "code"
    grant_type: str = "authorization_code"
    hash_algo: HashingAlgo = HashingAlgo.S256
    authorize_path: str = "/oauth2/authorize/"
    userinfo_path: str = "/iam/users/userinfo/"
    token_path: str = "/oauth2/token/"
    logout_path: str = "/oauth2/logout/"


class TokenCommand(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    access_token: str
    refresh_token: str
    token_type: str
    expires_in: int
    expires_at: datetime
    scope: str


class SessionCommand(BaseModel):
    code: str = ""
    verifier: str = ""
    state: str = ""
    nonce: str = ""
    next: str = "/home/"
    token: Optional[TokenCommand] = None


class UserCommand(BaseModel):
    id: UUID
    username: str
    nickname: str
    first_name: str
    middle_name: Optional[str] = None
    last_name: str
    email_address: str
    email_verified: bool
    email_verified_at: Optional[datetime] = None
    phone_number: str
    phone_verified: bool
    phone_verified_at: Optional[datetime] = None
    serial: Optional[str] = None
    gender: str
    birth_date: Optional[datetime] = None
    photo_url: Optional[str] = None
    photo_verified: bool
    photo_verified_at: Optional[datetime] = None
    profile: Optional[str] = None
    password: Optional[str] = None
    is_pwd: bool
    is_active: bool
    is_admin: bool
    is_superuser: bool
    is_verified: bool



class LoggingLevel(str, Enum):
    INFO = "info"
    SUCCESS = "success"
    WARNING = "warning"
    DANGER = "danger"

LoggingContext = dict[str, str | int | float | bool | None]

class LoggingCommand(BaseModel):
    model_config = ConfigDict(use_enum_values=True)
    level: LoggingLevel = LoggingLevel.INFO
    message: str
    context: LoggingContext = Field(default_factory=dict)

    