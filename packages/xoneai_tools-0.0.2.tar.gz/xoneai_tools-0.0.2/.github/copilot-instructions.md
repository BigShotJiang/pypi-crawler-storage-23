# GitHub Copilot Instructions for XoneAI-Tools

When assisting in the `xoneai-tools` repository, please adhere to the following project-specific conventions:

## Project Overview
- **Name**: `xoneai-tools`
- **Purpose**: Extended tools for XoneAI Agents.
- **Tech Stack**: Python 3.10+, `pytest`, `hatchling`.

## Coding Guidelines
1. **Strict Typing**: Enforce type hints on all function signatures, variables, and return types.
2. **Comprehensive Documentation**: Provide detailed docstrings for all functions, classes, and public methods.
3. **Tool Design Framework**:
   - For simple, stateless actions, use the `@tool` decorator.
   - For complex integrations, extend the `BaseTool` class.
4. **Data Validation**: Rely on Pydantic models for argument parsing and data structuring.

## Testing Guidelines
- All new functionality must be accompanied by relevant `pytest` test cases inside the `tests/` directory.
- Maintain existing testing patterns for mocking external services.

By adhering to these rules, you help maintain a consistent, high-quality, and robust codebase.
