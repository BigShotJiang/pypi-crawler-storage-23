"""Example: Probe video metadata."""
import sys
sys.path.insert(0, "/Users/xonevn/XoneAI-tools/xoneai_tools/video")

from probe import probe_video

result = probe_video("/Users/xonevn/Agent-Recipes/agent_recipes/input.mov")

print(f"Duration: {result.duration}s")
print(f"Resolution: {result.width}x{result.height}")
print(f"FPS: {result.fps}")
print(f"Codec: {result.codec}")
