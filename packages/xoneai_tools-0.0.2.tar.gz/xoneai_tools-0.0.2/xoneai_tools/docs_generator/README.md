# XoneAI Docs Generator

A powerful documentation generator for XoneAI SDK reference documentation.

## Installation

```bash
pip install xoneai-tools
```

## Quick Start

### Generate Rust SDK Documentation (Standalone)

The Rust documentation generator works without dependencies:

```bash
# Direct execution (recommended for Rust)
cd xoneai_tools/docs_generator
python3 __main__.py --package rust

# Or use the standalone script
python3 generate_rust_docs.py --rust-path /path/to/xoneai-rust

# Dry run
python3 __main__.py --package rust --dry-run
```

### Generate All SDK Documentation

For Python/TypeScript docs, install the full package first:

```bash
pip install xoneaiagents
python -m xoneai_tools.docs_generator --package all
```

### Using CLI

```bash
# Generate documentation with default settings
xoneai-tools docs-generate

# Generate with granular layout (separate pages for classes/functions)
xoneai-tools docs-generate --layout granular

# Specify custom output directory
xoneai-tools docs-generate --output /path/to/docs
```

### Direct Script Execution

```bash
python generator.py --layout granular
```

## Options

| Option | Description | Default |
|--------|-------------|---------|
| `--layout` | Documentation layout: `compact` or `granular` | `granular` |
| `--package` | Package to generate: `xoneaiagents`, `xoneai`, `typescript`, `rust`, `all` | `all` |
| `--docs-root` | Root directory of the documentation repository | Auto-detected |
| `--dry-run` | Show what would be generated without writing files | `false` |

## Layouts

### Compact Layout
- Single page per module
- Classes and functions inline

### Granular Layout (Recommended)
- Separate pages for each class and function
- Module hub pages with links to components
- Better navigation and searchability

## Features

- **Dynamic lazy-loading support**: Captures `_LAZY_IMPORTS`, `_LAZY_GROUPS`, `TOOL_MAPPINGS`
- **Recursive scanning**: Scans all `__init__.py` files in package tree
- **MDX output**: Mintlify-compatible MDX format
- **Navigation generation**: Auto-updates `docs.json` navigation
- **Icon support**: Maps modules to Font Awesome icons
- **Multi-language support**: Python, TypeScript, and Rust

## Supported Packages

- `xoneaiagents` (Python Core SDK)
- `xoneai` (Python Wrapper)
- TypeScript SDK (`xoneai-ts`)
- **Rust SDK** (`xoneai-rust`) - Agent, Tools, Workflows, Memory, LLM

## Output Structure

```
docs/sdk/reference/
├── xoneaiagents/
│   ├── modules/      # Module hub pages
│   ├── classes/      # Class pages
│   └── functions/    # Function pages
├── xoneai/
│   └── ...
├── typescript/
│   └── ...
└── rust/
    ├── modules/      # xoneai.agent, xoneai.tools, etc.
    ├── classes/      # Agent, ToolRegistry, AgentTeam, etc.
    └── functions/    # Standalone functions
```
