"""
XoneAI Documentation Generator.

This module can be run standalone without requiring the xoneaiagents dependency.

Usage:
    python -m xoneai_tools.docs_generator --package rust
    python -m xoneai_tools.docs_generator --package all
"""

# This file is intentionally minimal to allow standalone execution
# without importing the parent package dependencies.

__version__ = "0.1.0"
