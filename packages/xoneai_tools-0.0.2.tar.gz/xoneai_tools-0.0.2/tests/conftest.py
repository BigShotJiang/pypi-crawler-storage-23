"""Pytest configuration and fixtures for XoneAI Tools tests."""
