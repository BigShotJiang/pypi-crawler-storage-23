"""Generated API modules."""

from . import v1, v2

__all__ = [
    "v1",
    "v2",
]
