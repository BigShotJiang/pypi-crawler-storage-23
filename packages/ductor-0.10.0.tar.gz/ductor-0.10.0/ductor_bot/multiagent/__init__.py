"""Multi-agent architecture: supervisor, bus, and inter-agent communication."""
