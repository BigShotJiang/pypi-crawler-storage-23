# CLI: create projects, import/export .chronicle, run queries.
# See docs/spec/delivery.md and docs/spec/evidence.md (project format).
