"""Optional integrations with RAG frameworks (LlamaIndex, LangChain, Haystack).

Each integration is in its own module and may require an extra dependency.
Use the handler/component from the framework-specific module.
"""

__all__: list[str] = []
