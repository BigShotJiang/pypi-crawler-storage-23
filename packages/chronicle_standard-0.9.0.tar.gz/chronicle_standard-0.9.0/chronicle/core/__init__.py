# Event model, type definitions, validation, payload schemas, UID generation.
# See docs/spec/event-model.md and docs/spec/schemas.md.
