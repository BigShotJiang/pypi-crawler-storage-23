# Storage protocols (EventStore, ReadModel, EvidenceStore) and SQLite implementation.
# See docs/spec/delivery.md Section 12.4 and docs/spec/schemas.md.
