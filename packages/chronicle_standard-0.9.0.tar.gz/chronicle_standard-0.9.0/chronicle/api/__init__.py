"""Optional HTTP API for Chronicle. Install with pip install -e \".[api]\"."""
