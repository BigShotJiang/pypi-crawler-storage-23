# Standalone .chronicle verifier. Phase 8. No Chronicle runtime required.
# Run: python -m tools.verify_chronicle path/to/file.chronicle
