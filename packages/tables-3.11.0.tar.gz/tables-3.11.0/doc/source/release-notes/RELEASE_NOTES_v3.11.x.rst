.. When releasing a new major or minor (not patch) version,
.. copy this file to ``RELEASE_NOTES_v<NEW-MAJOR>.<NEW-MINOR>.x.rst``,
.. and replace the contents of the old file
.. with those of the file mentioned below,
.. for the entries covering the releases matching the old minor version.
..
.. E.g. if X.Y+1 is released,
.. copy this file to ``RELEASE_NOTES_vX.Y+1.x.rst``,
.. then replace current content with entries from ``RELEASE_NOTES.txt`` for X.Y releases.
.. include:: ../../../RELEASE_NOTES.rst
