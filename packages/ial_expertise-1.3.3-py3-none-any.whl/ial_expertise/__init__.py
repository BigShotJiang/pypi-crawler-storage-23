#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
IAL expertise package: expertise outputs of IAL tasks.
"""

__version__ = "1.3.3"

from . import experts, task
