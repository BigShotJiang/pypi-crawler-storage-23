"""Evaluation utilities: perplexity and generation sanity checks."""
