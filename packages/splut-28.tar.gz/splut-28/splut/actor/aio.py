from .future import Future, NormalOutcome
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager, ExitStack
from functools import partial
from os.path import basename
from queue import Queue
from threading import get_ident, Lock
import asyncio, logging, sys

log = logging.getLogger(__name__)

async def _loop(putinfo, ctrl):
    putinfo([asyncio.get_running_loop(), get_ident()])
    await ctrl.elf()

class EventLoop:

    @classmethod
    @contextmanager
    def open(cls, e):
        q = Queue()
        ctrl = Future()
        future = e.submit(asyncio.run, _loop(q.put, ctrl))
        try:
            yield cls(*q.get())
        finally:
            ctrl.set(NormalOutcome(None))
            future.result()

    def __init__(self, loop, ident):
        self.loop = loop
        self.ident = ident

    def isidle(self, frames):
        if (frame := frames.get(self.ident)) is not None:
            return 'select' == (code := frame.f_code).co_name and basename(code.co_filename).startswith('selectors.py')

    def submit(self, task):
        future = Future()
        self.loop.call_soon_threadsafe(future.run, task)
        return future

class EventLoopPool:
    'Executor with asyncio-capable threads.'

    @classmethod
    @contextmanager
    def open(cls, max_workers = None):
        with ThreadPoolExecutor(max_workers) as e, ExitStack() as stack:
            yield cls(e, stack)

    index = 0

    def __init__(self, e, stack):
        self.lock = Lock()
        self.loops = []
        self.e = e
        self.stack = stack

    def submit(self, fn, *args, **kwargs):
        frames = sys._current_frames()
        with self.lock:
            n = len(self.loops)
            baseindex = self.index
            for index in range(baseindex - n, baseindex):
                if self.loops[index].isidle(frames):
                    break
            else:
                if n < self.e._max_workers:
                    log.debug('Create new event loop.')
                    self.loops.append(self.stack.enter_context(EventLoop.open(self.e)))
                    index = n
                    n += 1
                else:
                    log.debug('All event loops busy.')
                    index = baseindex
            loop = self.loops[index]
            self.index = (index + 1) % n
        return loop.submit(partial(fn, *args, **kwargs))
