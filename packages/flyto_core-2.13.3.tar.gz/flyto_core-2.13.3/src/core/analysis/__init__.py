# Copyright 2026 Flyto2. Licensed under Apache-2.0. See LICENSE.

"""
Core Analysis Package - Stub for OSS version

Full implementation available in Flyto Pro.
"""

from .html_analyzer import HTMLAnalyzer

__all__ = ["HTMLAnalyzer"]
