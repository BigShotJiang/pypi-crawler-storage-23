---
name: Bug Report
about: Report a bug encountered while using NEXUS client SDK
labels: 'bug'
assignees: ''
---
<!-- Please use this template while reporting a bug and provide as much info as possible. Not doing so may result in your bug not being addressed in a timely manner. Thanks!

If the matter is security related, please disclose it privately via https://kubernetes.io/security/
-->

**Bug Description**:

**Expected Behavior**:

**Steps to Reproduce**:

**Environment**:
- `fundamental-client` Version:
- Python Version:
- OS (e.g: `cat /etc/os-release`)::

**Dependencies**:
- pandas==
- numpy==
- scikit-learn==
- httpx==
- pydantic==
- pyarrow==
