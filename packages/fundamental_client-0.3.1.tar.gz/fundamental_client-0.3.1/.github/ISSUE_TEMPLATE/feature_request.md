---
name: Feature Request
about: Suggest a new feature or enhancement for the NEXUS Client SDK
labels: 'enhancement'
assignees: ''
---
<!-- Please use this template while requesting a feature and provide as much info as possible. This helps us understand and prioritize your request. Thanks!

For questions or discussions, please use GitHub Discussions instead of creating an issue.
-->

**What would you like to be added**:

**Why is this needed**:

**Completion requirements**:

This enhancement requires the following artifacts:

- [ ] Design doc
- [ ] API change
- [ ] Docs update

The artifacts should be linked in subsequent comments.
