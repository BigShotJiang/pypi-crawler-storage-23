"""Diagnostic report generation."""

import platform
import sys
import traceback
import types
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

from fundamental.diagnostics.masking import mask_secrets
from fundamental.exceptions import NEXUSError

SEPARATOR = "=" * 60

# Resolved once at import time
SDK_PACKAGE_DIR = str(Path(__file__).resolve().parent.parent)

# Show full file up to this many lines; beyond that show a snippet.
FULL_FILE_LIMIT = 500
SNIPPET_CONTEXT = 10


def _get_sdk_version() -> str:
    try:
        return version("fundamental-client")
    except PackageNotFoundError:
        return "unknown"


def _collect_user_source_snippets(
    exc_tb: types.TracebackType | None,
) -> list[tuple[str, int, list[str]]]:
    """Collect source from user frames in the traceback.

    Small files (<=500 lines) are included in full with the error line
    highlighted.  Large files show only a snippet around the frame.

    Returns a list of (filepath, lineno, formatted_lines) tuples.
    """
    snippets: list[tuple[str, int, list[str]]] = []
    seen: set[str] = set()
    if not exc_tb:
        return snippets

    frame: types.TracebackType | None = exc_tb
    while frame:
        filepath = frame.tb_frame.f_code.co_filename
        lineno = frame.tb_lineno
        key = f"{filepath}:{lineno}"

        if key not in seen and not filepath.startswith("<") and Path(filepath).exists():
            seen.add(key)
            resolved = str(Path(filepath).resolve())
            if (
                not resolved.startswith(SDK_PACKAGE_DIR)
                and "site-packages/" not in resolved
                and "lib/python" not in resolved
            ):
                try:
                    content = Path(filepath).read_text(
                        encoding="utf-8",
                        errors="replace",
                    )
                    all_lines = content.splitlines()
                    if len(all_lines) <= FULL_FILE_LIMIT:
                        start, end = 0, len(all_lines)
                    else:
                        start = max(0, lineno - SNIPPET_CONTEXT - 1)
                        end = min(
                            len(all_lines),
                            lineno + SNIPPET_CONTEXT,
                        )
                    numbered = []
                    for i, src in enumerate(
                        all_lines[start:end],
                        start=start + 1,
                    ):
                        marker = " >> " if i == lineno else "    "
                        numbered.append(f"{marker}{i:4d} | {src}")
                    snippets.append((filepath, lineno, numbered))
                except (OSError, ValueError):
                    snippets.append(
                        (filepath, lineno, ["    (could not read file)"]),
                    )

        frame = frame.tb_next

    return snippets


class _ReportWriter:
    """Accumulates lines for a diagnostic report."""

    def __init__(self) -> None:
        self._lines: list[str] = []

    def header(self, title: str) -> None:
        self._lines.extend(["", SEPARATOR, f" {title}", SEPARATOR])

    def field(self, label: str, value: str) -> None:
        self._lines.append(f"{label:<12}: {value}")

    def section(self, title: str, content: list[str]) -> None:
        self._lines.append("")
        self._lines.append(f"{title}:")
        self._lines.extend(f"  {line}" for line in content)

    def text(self, line: str) -> None:
        self._lines.append(line)

    def blank(self) -> None:
        self._lines.append("")

    def build(self) -> str:
        self._lines.extend([SEPARATOR, ""])
        return mask_secrets("\n".join(self._lines))


def build_report(
    exc_type: type,
    exc_value: BaseException,
    exc_tb: types.TracebackType | None,
    timestamp: str,
) -> str:
    """Build a full diagnostic report string."""
    w = _ReportWriter()
    w.header("FUNDAMENTAL DIAGNOSTIC REPORT")
    w.field("Timestamp", timestamp)
    w.field("SDK Version", _get_sdk_version())
    w.field("Python", sys.version.split()[0])
    w.field("Platform", platform.platform())

    # Trace ID
    trace_id = exc_value.trace_id if isinstance(exc_value, NEXUSError) else None
    if trace_id:
        w.field("Trace ID", trace_id)
        w.blank()
        w.text(
            "  >> Share this Trace ID with the Fundamental team for fast lookup <<",
        )

    # Exception
    w.blank()
    w.field("Exception", f"{exc_type.__name__}: {exc_value}")
    if isinstance(exc_value, NEXUSError) and exc_value.details:
        w.field("Details", str(exc_value.details))

    # Traceback
    tb_text = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    w.section("Traceback", [line.rstrip() for line in tb_text.splitlines()])

    # User source
    snippets = _collect_user_source_snippets(exc_tb)
    if snippets:
        source_lines: list[str] = []
        for filepath, lineno, numbered in snippets:
            source_lines.append(f"--- {filepath} (line {lineno}) ---")
            source_lines.extend(numbered)
            source_lines.append("")
        w.section("User source context", source_lines)
    else:
        w.section("User source context", ["(none found)"])

    return w.build()
