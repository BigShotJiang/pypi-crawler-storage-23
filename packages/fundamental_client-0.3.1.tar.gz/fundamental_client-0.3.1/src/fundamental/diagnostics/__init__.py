"""Diagnostics toolkit for Fundamental SDK.

Usage::

    from fundamental.diagnostics import activate
    activate()

As context manager::

    from fundamental.diagnostics import diagnose
    with diagnose():
        model.fit(X, y)
"""

import sys
from contextlib import contextmanager
from typing import Generator, Optional

from fundamental.diagnostics.manager import DiagnosticsManager

__all__ = ["activate", "deactivate", "diagnose"]

_active_manager: Optional[DiagnosticsManager] = None


def activate(log_dir: Optional[str] = None) -> None:
    """Activate diagnostics. Debug logs go to a timestamped file.

    Args:
        log_dir: Directory for log file. Defaults to a temp directory.
    """
    global _active_manager
    if _active_manager:
        return
    manager = DiagnosticsManager(log_dir=log_dir)
    manager.activate()
    _active_manager = manager


def deactivate() -> None:
    """Deactivate diagnostics if currently active."""
    global _active_manager
    if _active_manager:
        _active_manager.deactivate()
        _active_manager = None


@contextmanager
def diagnose(log_dir: Optional[str] = None) -> Generator[None, None, None]:
    """Context manager that activates diagnostics for a scope."""
    activate(log_dir=log_dir)
    try:
        yield
    finally:
        exc = sys.exc_info()[1]
        if _active_manager and exc is not None:
            _active_manager._excepthook(type(exc), exc, exc.__traceback__)
        deactivate()
