"""Secret masking for diagnostic output."""

import logging
import re

from fundamental.constants import ENV_API_KEY

_SECRET_KEY_VALUE = re.compile(
    r"((?:api[_-]?key|secret|token|password|credential|authorization)"
    r"""\s*[:=]\s*["']?)"""
    r"(\S{4})"
    r"(\S+?)"
    r"""(["'\s]|$)""",
    re.IGNORECASE,
)

_ENV_VAR_ASSIGNMENT = re.compile(
    rf"({ENV_API_KEY}\s*=\s*[\"']?)"
    r"(\S{4})"
    r"(\S+?)"
    r"""([\"'\s]|$)""",
    re.IGNORECASE,
)


def _mask_repl(m: re.Match) -> str:
    return f"{m.group(1)}{m.group(2)}{'*' * min(len(m.group(3)), 20)}{m.group(4)}"


def mask_secrets(text: str) -> str:
    """Replace anything that looks like a secret with a masked version.

    Keeps the first 4 characters visible, masks the rest with asterisks.
    """
    text = _SECRET_KEY_VALUE.sub(_mask_repl, text)
    return _ENV_VAR_ASSIGNMENT.sub(_mask_repl, text)


class SanitizingFilter(logging.Filter):
    """Log filter that masks secrets in log messages."""

    def filter(self, record: logging.LogRecord) -> bool:
        if record.args:
            record.msg = mask_secrets(record.getMessage())
            record.args = None
        else:
            record.msg = mask_secrets(str(record.msg))
        return True
