"""Core diagnostics manager — logging setup and exception hook."""

import logging
import sys
import tempfile
import types
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from fundamental.diagnostics.exception_report import build_report
from fundamental.diagnostics.masking import SanitizingFilter

logger = logging.getLogger(__name__)

_LOG_FORMAT = "%(asctime)s.%(msecs)03d %(name)s %(levelname)s %(message)s"
_LOG_DATEFMT = "%Y-%m-%d %H:%M:%S"


class DiagnosticsManager:
    """Manages debug logging and exception reporting."""

    def __init__(self, log_dir: Optional[str] = None) -> None:
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        if log_dir is None:
            default_dir = Path(tempfile.gettempdir()) / "fundamental"
            default_dir.mkdir(exist_ok=True)
            log_dir = str(default_dir)
        self.log_path = Path(log_dir) / f"fundamental_debug_{ts}.log"
        self._file_handler: Optional[logging.FileHandler] = None
        self._console_handler: Optional[logging.StreamHandler] = None
        self._original_excepthook: Any = None
        self._original_log_level: Optional[int] = None
        self._original_propagate: bool = True

    def activate(self) -> None:
        root_logger = logging.getLogger("fundamental")
        self._original_log_level = root_logger.level
        self._original_propagate = root_logger.propagate
        root_logger.setLevel(logging.DEBUG)

        # Stop messages from bubbling up to the root logger.
        # In environments like Colab/Jupyter the root logger has its own
        # handler, which would duplicate every message we emit.
        root_logger.propagate = False

        # File handler — captures everything (DEBUG+) to the log file
        self._file_handler = logging.FileHandler(self.log_path, encoding="utf-8")
        self._file_handler.setLevel(logging.DEBUG)
        self._file_handler.setFormatter(logging.Formatter(_LOG_FORMAT, datefmt=_LOG_DATEFMT))
        self._file_handler.addFilter(SanitizingFilter())
        root_logger.addHandler(self._file_handler)

        # Console handler — only echoes INFO+ to stderr so the user
        # sees important messages without being flooded by DEBUG noise
        self._console_handler = logging.StreamHandler(sys.stderr)
        self._console_handler.setLevel(logging.INFO)
        self._console_handler.setFormatter(logging.Formatter(_LOG_FORMAT, datefmt=_LOG_DATEFMT))
        self._console_handler.addFilter(SanitizingFilter())
        root_logger.addHandler(self._console_handler)

        self._original_excepthook = sys.excepthook
        sys.excepthook = self._excepthook

        logger.info("Diagnostics activated — logging to %s", self.log_path)

    def deactivate(self) -> None:
        root_logger = logging.getLogger("fundamental")

        if self._file_handler:
            root_logger.removeHandler(self._file_handler)
            self._file_handler.close()
            self._file_handler = None

        if self._console_handler:
            root_logger.removeHandler(self._console_handler)
            self._console_handler.close()
            self._console_handler = None

        if self._original_log_level is not None:
            root_logger.setLevel(self._original_log_level)
            self._original_log_level = None
            root_logger.propagate = self._original_propagate

        if self._original_excepthook:
            sys.excepthook = self._original_excepthook
            self._original_excepthook = None

    def _excepthook(
        self,
        exc_type: type[BaseException],
        exc_value: BaseException,
        exc_tb: types.TracebackType | None,
    ) -> None:
        # Show the normal traceback first
        if self._original_excepthook:
            self._original_excepthook(exc_type, exc_value, exc_tb)

        # Build and write the full diagnostic report to log file only
        timestamp = datetime.now(timezone.utc).isoformat()
        report = build_report(exc_type, exc_value, exc_tb, timestamp)

        if self._file_handler:
            self._file_handler.stream.write(report + "\n")
            self._file_handler.flush()
