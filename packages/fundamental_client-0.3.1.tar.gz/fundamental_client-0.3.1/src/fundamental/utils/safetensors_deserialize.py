"""Safe deserialization for estimator fields using safetensors.

Deserializes estimator_fields.safetensors from the API into a dict.
This replaces pickle to eliminate RCE vulnerabilities.

Coupling:
- Input: estimator_fields.safetensors bytes from API (base64 decoded)
- Producer: Controller's safetensors_serialization.save_estimator_fields()
- Output: dict matching LTM's sync_fields() structure

Format:
- Tensors -> numeric numpy arrays
- Metadata {"value": [...], "type": "string_array"} -> string arrays
- Metadata {"type": "array_list", "length": N} + field::0, field::1 -> list of arrays
- Metadata {"value": ...} -> scalars/lists/dicts
"""

import json
import logging
import tempfile
from pathlib import Path
from typing import Any

import numpy as np
from safetensors import safe_open
from safetensors.numpy import load

logger = logging.getLogger(__name__)


def _deserialize_fields(tensors: dict[str, np.ndarray], metadata: dict[str, str]) -> dict[str, Any]:
    """Deserialize tensors and metadata back into fields.

    Metadata format:
    - {"value": ...} -> scalar/list/dict
    - {"value": [...], "type": "string_array"} -> numpy array (string/object dtype)
    - {"type": "array_list", "length": N} -> list of arrays (indexed as field::0, field::1, ...)

    Args:
        tensors: Dictionary of tensor names to numpy arrays
        metadata: Dictionary of metadata keys to JSON strings

    Returns:
        Reconstructed fields dictionary
    """
    fields: dict[str, Any] = {}

    # Add all tensors that aren't indexed (list items have :: in name)
    fields = {k: v for k, v in tensors.items() if "::" not in k}

    # Process metadata entries
    for k, v in metadata.items():
        if "::" in k:  # Skip indexed list items (processed via parent)
            continue

        parsed = json.loads(v)

        if parsed.get("type") == "array_list":
            # Reconstruct list of arrays from indexed entries
            length = parsed["length"]
            arrays = []
            for i in range(length):
                idx_key = f"{k}::{i}"
                if idx_key in tensors:
                    arrays.append(tensors[idx_key])
                elif idx_key in metadata:
                    idx_parsed = json.loads(metadata[idx_key])
                    arrays.append(np.array(idx_parsed["value"]))
                else:
                    raise ValueError(f"Missing array_list entry for {idx_key}")
            fields[k] = arrays
        elif parsed.get("type") == "string_array":
            fields[k] = np.array(parsed["value"])
        else:
            fields[k] = parsed["value"]

    return fields


def load_estimator_fields_from_bytes(data: bytes) -> dict[str, Any]:
    """Load estimator fields from safetensors bytes.

    Args:
        data: Bytes containing the safetensors data (from API response)

    Returns:
        Reconstructed fields dictionary with numpy arrays
    """
    logger.debug("Deserializing safetensors (%d bytes)", len(data))
    tensors = load(data)

    # To get metadata, we need to use safe_open with a file-like object
    # safetensors supports loading from bytes directly for tensors,
    # but metadata requires safe_open.
    # Use a temp directory so Windows can reopen the file without lock issues.
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir) / "estimator_fields.safetensors"
        tmp_path.write_bytes(data)
        with safe_open(str(tmp_path), framework="np") as f:
            metadata = f.metadata() or {}

    fields = _deserialize_fields(tensors, metadata)
    logger.debug(
        "Deserialized %d tensors, %d metadata entries -> %d fields",
        len(tensors),
        len(metadata),
        len(fields),
    )
    return fields
