"""Base client for API interactions."""

from abc import ABC
from typing import TYPE_CHECKING, Dict, Optional

from fundamental.config import Config

if TYPE_CHECKING:
    from fundamental.services.models import ModelsService


class BaseClient(ABC):
    """Abstract base client for API interactions.

    All client implementations should inherit from this.
    """

    config: Config
    models: "ModelsService"
    _trace_dict: Optional[Dict[str, str]]

    def __init__(self, *, config: Config) -> None:
        """Initialize the base client with service properties."""
        # Local import to avoid circular dependency at runtime
        from fundamental.services.models import ModelsService

        self.config = config
        self.models = ModelsService(client=self)
        self._trace_dict = None

    def get_trace_dict(self) -> Optional[Dict[str, str]]:
        """Get the current trace dictionary for workflow correlation."""
        return self._trace_dict

    def _set_trace_dict(self, trace_dict: Optional[Dict[str, str]]) -> None:
        """Set the current trace dictionary (internal use only)."""
        self._trace_dict = trace_dict
