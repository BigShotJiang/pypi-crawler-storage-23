"""Fundamental AWS Marketplace client with AWS SigV4 authentication."""

from typing import Any, Optional

from fundamental.clients.base import BaseClient
from fundamental.config import Config


class FundamentalAWSMarketplaceClient(BaseClient):
    """Client for Fundamental API on AWS Marketplace deployments using AWS SigV4 authentication.

    This client is designed for AWS Marketplace deployments where authentication
    is done via AWS IAM roles instead of API keys. It uses SigV4 signing to
    authenticate requests using the AWS credentials available in the environment.
    """

    def __init__(
        self,
        aws_region: str,
        api_url: Optional[str] = None,
        **kwargs: Any,  # noqa: ANN401
    ):
        """Initialize the Fundamental AWS Marketplace client.

        Args:
            aws_region: AWS region for SigV4 signing (required)
            api_url: Base URL for the private deployment API server (API Gateway URL).
                     Defaults to FUNDAMENTAL_API_URL environment variable if not provided.
            **kwargs: Additional configuration options passed to Config
        """
        cfg = Config(
            api_url=api_url or "",
            use_sigv4_auth=True,
            aws_region=aws_region,
            **kwargs,
        )
        super().__init__(config=cfg)
