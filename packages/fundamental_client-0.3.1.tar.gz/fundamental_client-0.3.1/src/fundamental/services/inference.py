"""
Model inference services for NEXUS client.
Handles fit and predict operations with the NEXUS service.
"""

import logging
from typing import Literal, Optional

import numpy as np
from pydantic import BaseModel

from fundamental.clients.base import BaseClient
from fundamental.constants import (
    DEFAULT_POLLING_INTERVAL_SECONDS,
    DEFAULT_PREDICT_POLLING_REQUESTS_WITHOUT_DELAY,
    DEFAULT_SUBMIT_REQUEST_TIMEOUT_SECONDS,
)
from fundamental.models import TaskStatus
from fundamental.services.models import ModelsService
from fundamental.utils.data import (
    XType,
    YType,
    api_call,
    create_fit_task_metadata,
    create_predict_task_metadata,
    download_result_from_url,
    serialize_df_to_parquet_view,
    upload_fit_data,
    upload_predict_data,
)
from fundamental.utils.polling import wait_for_task_status

logger = logging.getLogger(__name__)


class RemoteFitResponse(BaseModel):
    trained_model_id: str
    estimator_fields: dict


class SubmitFitTaskResult(BaseModel):
    """Result of submitting a fit task."""

    task_id: str
    trained_model_id: str


def submit_fit_task(
    X: XType,
    y: YType,
    task: Literal["classification", "regression"],
    mode: Literal["quality", "speed"],
    client: BaseClient,
    time_series: bool,
) -> SubmitFitTaskResult:
    """
    Submit a fit task without waiting for completion.

    Parameters
    ----------
    X : XType
        Training features.
    y : YType
        Training targets.
    task : {"classification", "regression"}
        Task type.
    mode : {"quality", "speed"}
        Model fit mode.
    client : BaseClient
        The client instance.

    Returns
    -------
    SubmitFitTaskResult
        Result containing task_id and trained_model_id.
    """
    X_serialized = serialize_df_to_parquet_view(data=X)
    y_serialized = serialize_df_to_parquet_view(data=y)

    metadata = create_fit_task_metadata(
        x_train_size=len(X_serialized),
        y_train_size=len(y_serialized),
        client=client,
    )

    upload_fit_data(
        X_serialized=X_serialized,
        y_serialized=y_serialized,
        metadata=metadata,
        client=client,
    )

    json_data = {
        "task": task,
        "mode": mode,
        "trained_model_id": metadata.trained_model_id,
        "timeout": client.config.fit_timeout,
        "time_series": time_series,
    }

    response = api_call(
        method="POST",
        full_url=client.config.get_full_fit_url(),
        client=client,
        json=json_data,
        timeout=DEFAULT_SUBMIT_REQUEST_TIMEOUT_SECONDS,
    )
    data = response.json()
    task_id: str = data["task_id"]

    return SubmitFitTaskResult(
        task_id=task_id,
        trained_model_id=metadata.trained_model_id,
    )


def poll_fit_result(
    task_id: str,
    trained_model_id: str,
    client: BaseClient,
) -> Optional[RemoteFitResponse]:
    """
    Check the status of a fit task.

    Parameters
    ----------
    task_id : str
        The task ID returned by submit_fit_task.
    trained_model_id : str
        The trained model ID from the submit result.
    client : BaseClient
        The client instance.

    Returns
    -------
    Optional[RemoteFitResponse]
        RemoteFitResponse with trained_model_id and estimator_fields if completed,
        None if still in progress.
    """
    status_response = wait_for_task_status(
        client=client,
        status_url=f"{client.config.get_full_fit_status_url()}/{task_id}",
        timeout=client.config.fit_timeout,
        polling_interval=DEFAULT_POLLING_INTERVAL_SECONDS,
        wait_for_completion=False,
    )

    if status_response.status == TaskStatus.SUCCESS:
        logger.debug("Loading trained model metadata")
        models_service = ModelsService(client=client)
        loaded_model = models_service.load(trained_model_id=trained_model_id)

        return RemoteFitResponse(
            trained_model_id=trained_model_id,
            estimator_fields=loaded_model.estimator_fields,
        )

    return None


def remote_fit(
    X: XType,
    y: YType,
    task: Literal["classification", "regression"],
    mode: Literal["quality", "speed"],
    client: BaseClient,
    time_series: bool,
) -> RemoteFitResponse:
    """
    Fit a model (blocking).

    Submits the task and waits for completion.

    Parameters
    ----------
    X : XType
        Training features.
    y : YType
        Training targets.
    task : {"classification", "regression"}
        Task type.
    mode : {"quality", "speed"}
        Model fit mode.
    client : BaseClient
        The client instance.

    Returns
    -------
    RemoteFitResponse
        Service response with trained_model_id and estimator_fields.
    """
    submit_result = submit_fit_task(
        X=X,
        y=y,
        task=task,
        mode=mode,
        client=client,
        time_series=time_series,
    )

    wait_for_task_status(
        client=client,
        status_url=f"{client.config.get_full_fit_status_url()}/{submit_result.task_id}",
        timeout=client.config.fit_timeout,
        polling_interval=DEFAULT_POLLING_INTERVAL_SECONDS,
    )

    logger.debug("Loading trained model metadata")
    models_service = ModelsService(client=client)
    loaded_model = models_service.load(trained_model_id=submit_result.trained_model_id)

    return RemoteFitResponse(
        trained_model_id=submit_result.trained_model_id,
        estimator_fields=loaded_model.estimator_fields,
    )


def remote_predict(
    X: XType,
    output_type: Literal["preds", "probas"],
    trained_model_id: str,
    client: BaseClient,
) -> np.ndarray:
    """
    Make predictions using a trained model identified by trained_model_id.

    Parameters
    ----------
    X : XType
        Input features for prediction.
    output_type : {"preds", "probas"}
        Output type.
    trained_model_id : str
        The model ID generated by after the fit operation.

    Returns
    -------
    np.ndarray
        Prediction results.
    """
    X_serialized = serialize_df_to_parquet_view(data=X)

    metadata = create_predict_task_metadata(
        trained_model_id=trained_model_id,
        x_test_size=len(X_serialized),
        client=client,
    )

    upload_predict_data(
        X_serialized=X_serialized,
        metadata=metadata,
        trained_model_id=trained_model_id,
        client=client,
    )

    json_data = {
        "output_type": output_type,
        "trained_model_id": trained_model_id,
        "request_id": metadata.request_id,
        "timeout": client.config.predict_timeout,
    }

    response = api_call(
        method="POST",
        full_url=client.config.get_full_predict_url(),
        client=client,
        json=json_data,
        timeout=DEFAULT_SUBMIT_REQUEST_TIMEOUT_SECONDS,
    )
    data = response.json()
    task_id = data["task_id"]
    logger.debug(
        "Predict task submitted: task_id=%s, trained_model_id=%s", task_id, trained_model_id
    )

    status_response = wait_for_task_status(
        client=client,
        status_url=f"{client.config.get_full_predict_status_url()}/{trained_model_id}/{task_id}",
        timeout=client.config.predict_timeout,
        polling_interval=DEFAULT_POLLING_INTERVAL_SECONDS,
        polling_requests_without_delay=DEFAULT_PREDICT_POLLING_REQUESTS_WITHOUT_DELAY,
    )

    preds = download_result_from_url(
        download_url=status_response.result.download_url,  # type: ignore[union-attr]
        client=client,
        timeout=client.config.download_prediction_result_timeout,
    )
    return np.array(preds)
