"""
Feature importance services for NEXUS client.
Handles feature importance computation with the NEXUS service.
"""

import logging
from typing import Optional

import numpy as np

from fundamental.clients.base import BaseClient
from fundamental.constants import (
    DEFAULT_POLLING_INTERVAL_SECONDS,
    DEFAULT_SUBMIT_REQUEST_TIMEOUT_SECONDS,
)
from fundamental.exceptions import ServerError
from fundamental.models import TaskStatus
from fundamental.utils.data import (
    XType,
    api_call,
    create_feature_importance_task_metadata,
    download_result_from_url,
    serialize_df_to_parquet_view,
    upload_feature_importance_data,
)
from fundamental.utils.polling import wait_for_task_status

logger = logging.getLogger(__name__)


def submit_feature_importance_task(
    X: XType,
    trained_model_id: str,
    client: BaseClient,
) -> str:
    """
    Submit a feature importance computation task without waiting for completion.

    Parameters
    ----------
    X : XType
        Input features for feature importance computation.
    trained_model_id : str
        The trained model ID.
    client : BaseClient
        The client instance.

    Returns
    -------
    str
        The task ID to use with poll_feature_importance_result.
    """
    X_serialized = serialize_df_to_parquet_view(data=X)

    metadata = create_feature_importance_task_metadata(
        trained_model_id=trained_model_id,
        x_size=len(X_serialized),
        client=client,
    )

    upload_feature_importance_data(
        X_serialized=X_serialized,
        metadata=metadata,
        trained_model_id=trained_model_id,
        client=client,
    )

    json_data = {
        "trained_model_id": trained_model_id,
        "request_id": metadata.request_id,
        "timeout": client.config.feature_importance_timeout,
    }

    response = api_call(
        method="POST",
        full_url=client.config.get_full_feature_importance_url(),
        client=client,
        json=json_data,
        timeout=DEFAULT_SUBMIT_REQUEST_TIMEOUT_SECONDS,
    )
    data = response.json()
    task_id: str = data["task_id"]
    logger.debug(
        "Feature importance task submitted: task_id=%s, trained_model_id=%s",
        task_id,
        trained_model_id,
    )
    return task_id


def remote_get_feature_importance(
    X: XType,
    trained_model_id: str,
    client: BaseClient,
) -> np.ndarray:
    """
    Get feature importance for a trained model.

    Submits the task and waits for completion.

    Parameters
    ----------
    X : XType
        Input features for feature importance computation.
    trained_model_id : str
        The trained model ID.
    client : BaseClient
        The client instance.

    Returns
    -------
    np.ndarray
        Feature importance values.
    """
    task_id = submit_feature_importance_task(
        X=X,
        trained_model_id=trained_model_id,
        client=client,
    )

    status_response = wait_for_task_status(
        client=client,
        status_url=f"{client.config.get_full_feature_importance_status_url()}/{trained_model_id}/{task_id}",
        timeout=client.config.feature_importance_timeout,
        polling_interval=DEFAULT_POLLING_INTERVAL_SECONDS,
    )

    if not status_response.result:
        raise ServerError("Request failed: Internal Server Error")

    logger.debug("Downloading feature importance result")
    downloaded_result = download_result_from_url(
        download_url=status_response.result.download_url,
        client=client,
        timeout=client.config.download_feature_importance_result_timeout,
    )
    return np.array(downloaded_result)


def poll_feature_importance_result(
    task_id: str,
    trained_model_id: str,
    client: BaseClient,
) -> Optional[np.ndarray]:
    """
    Check the status of a feature importance task.

    Parameters
    ----------
    task_id : str
        The task ID returned by submit_feature_importance_task.
    trained_model_id : str
        The trained model ID.
    client : BaseClient
        The client instance.

    Returns
    -------
    Optional[np.ndarray]
        Feature importance values if completed, None if still in progress.
    """
    status_response = wait_for_task_status(
        client=client,
        status_url=f"{client.config.get_full_feature_importance_status_url()}/{trained_model_id}/{task_id}",
        timeout=client.config.feature_importance_timeout,
        polling_interval=DEFAULT_POLLING_INTERVAL_SECONDS,
        wait_for_completion=False,
    )

    if status_response.status == TaskStatus.SUCCESS:
        if not status_response.result:
            raise ServerError("Request failed: Internal Server Error")
        downloaded_result = download_result_from_url(
            download_url=status_response.result.download_url,
            client=client,
            timeout=client.config.download_feature_importance_result_timeout,
        )
        return np.array(downloaded_result)

    return None
