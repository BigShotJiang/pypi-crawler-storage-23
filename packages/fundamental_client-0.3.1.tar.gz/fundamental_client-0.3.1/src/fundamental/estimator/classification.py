"""NEXUS Classification estimator."""

import logging
from typing import Any, Literal

import numpy.typing as npt
from sklearn.base import ClassifierMixin

from fundamental.estimator.nexus_estimator import NEXUSEstimator
from fundamental.utils.data import XType

logger = logging.getLogger(__name__)


class NEXUSClassifier(ClassifierMixin, NEXUSEstimator):
    """NEXUS Model for Classification Tasks."""

    _task_type = "classification"  # type: ignore[assignment]

    def __init__(
        self,
        mode: Literal["quality", "speed"] = "quality",
    ):
        super().__init__(mode=mode)

    def predict_proba(self, X: XType) -> npt.NDArray[Any]:
        """
        Predict probabilities function.

        Parameters
        ----------
        X : XType
            Input features as numpy array, pandas DataFrame.


        Returns
        -------
        np.ndarray
            Model probabilities.

        Raises
        ------
        NotFittedError
            If the model has not been fitted yet.
        """
        return self._predict(X=X, output_type="probas")
