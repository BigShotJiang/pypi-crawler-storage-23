"""Custom exceptions for NEXUS Client SDK."""

from typing import Any, Dict, Literal, Optional


class NEXUSError(Exception):
    """Base exception for all NEXUS client errors."""

    def __init__(
        self,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        trace_id: Optional[str] = None,
    ):
        super().__init__(message)
        self.details = details or {}
        self.trace_id = trace_id


class HTTPError(NEXUSError):
    """Base class for HTTP errors with status codes."""

    status_code: int

    def __str__(self) -> str:
        return f"HTTP {self.status_code}: {super().__str__()}"


class ValidationError(HTTPError):
    """Raised when input validation fails."""

    status_code: Literal[400] = 400  # pyright: ignore[reportIncompatibleVariableOverride]


class AuthenticationError(HTTPError):
    """Raised when authentication fails."""

    status_code: Literal[401] = 401  # pyright: ignore[reportIncompatibleVariableOverride]


class AuthorizationError(HTTPError):
    """Raised when authorization fails."""

    status_code: Literal[403] = 403  # pyright: ignore[reportIncompatibleVariableOverride]


class NotFoundError(HTTPError):
    """Raised when resource is not found."""

    status_code: Literal[404] = 404  # pyright: ignore[reportIncompatibleVariableOverride]


class RateLimitError(HTTPError):
    """Raised when API rate limits are exceeded."""

    status_code: Literal[429] = 429  # pyright: ignore[reportIncompatibleVariableOverride]


class ServerError(HTTPError):
    """Raised when server returns 5xx errors."""

    status_code: int = 500


class NetworkError(HTTPError):
    """Raised when network connectivity issues occur."""

    status_code: Literal[503] = 503  # pyright: ignore[reportIncompatibleVariableOverride]


class RequestTimeoutError(HTTPError):
    """Raised when requests timeout."""

    status_code: Literal[504] = 504  # pyright: ignore[reportIncompatibleVariableOverride]


# Deprecated alias for backward compatibility
FTMError = NEXUSError
