"""Fundamental Python SDK for tabular machine learning."""

from importlib.metadata import PackageNotFoundError, version
from typing import Optional

from fundamental.clients import BaseClient, Fundamental, FundamentalAWSMarketplaceClient

# Deprecated aliases
from fundamental.deprecated import FTMClassifier, FTMRegressor
from fundamental.estimator import NEXUSClassifier, NEXUSRegressor

try:
    # Distribution name on PyPI is `fundamental-client` (import name is `fundamental`).
    __version__ = version("fundamental-client")
except PackageNotFoundError:  # pragma: no cover
    __version__ = "unknown"

_global_client: Optional[BaseClient] = None


def set_client(client: BaseClient) -> None:
    global _global_client
    _global_client = client


def get_client() -> BaseClient:
    return _global_client or Fundamental()


__all__ = [
    "FTMClassifier",
    "FTMRegressor",
    "Fundamental",
    "FundamentalAWSMarketplaceClient",
    "NEXUSClassifier",
    "NEXUSRegressor",
    "diagnostics",
    "get_client",
    "set_client",
]
