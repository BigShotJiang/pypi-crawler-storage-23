# Fundamental Python SDK

[![PyPI version](https://img.shields.io/pypi/v/fundamental-client.svg?label=pypi%20package)](https://pypi.org/project/fundamental-client/)
[![Python Versions](https://img.shields.io/pypi/pyversions/fundamental-client?color=%2334D058)](https://pypi.org/project/fundamental-client)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

A scikit-learn compatible Python SDK for NEXUS, Fundamental's large model for tabular data.

## Table of Contents

- [Installation](#installation)
- [Usage](#usage)
  - [Quick Start](#quick-start)
  - [Using Pre-trained Models](#using-pre-trained-models)
  - [Async Training](#async-training)
  - [Model Management](#model-management)
  - [Explainability & Insights](#explainability--insights)
    - [Feature Importance](#feature-importance)
- [Configuration](#configuration)
  - [Client Configuration](#client-configuration)
    - [API Key](#api-key)
    - [AWS Marketplace](#aws-marketplace)
    - [Timeouts and Retries](#timeouts-and-retries)
    - [SSL Verification](#ssl-verification)
  - [Model Configuration](#model-configuration)
    - [Mode](#mode)
- [Supported Data Types](#supported-data-types)
- [Handling Errors](#handling-errors)
  - [Diagnostics and Support Information](#diagnostics-and-support-information)
  - [Exception Types](#exception-types)
- [Troubleshooting](#troubleshooting)
- [Versioning](#versioning)
- [Requirements](#requirements)
- [License](#license)
- [Security](#security)
- [Support](#support)

## Installation

```sh
# install from PyPI
pip install fundamental-client
```

## Usage

The Fundamental SDK provides scikit-learn compatible estimators for classification and regression tasks, along with a flexible client for API interactions.


### Quick Start

Make sure `FUNDAMENTAL_API_KEY` is set (or call `fundamental.set_client(...)`) before running the examples below.

```python
from sklearn.datasets import load_breast_cancer, load_diabetes
from sklearn.model_selection import train_test_split
from fundamental import NEXUSClassifier, NEXUSRegressor

# Load classification data
X, y = load_breast_cancer(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=42)

# Classification
classifier = NEXUSClassifier()
classifier.fit(X_train, y_train)

# After fitting, the model ID can be saved and used later
print(f"Trained model ID: {classifier.trained_model_id_}")

predictions = classifier.predict(X_test)
probabilities = classifier.predict_proba(X_test)

# Load regression data
X, y = load_diabetes(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.5, random_state=42)

# Regression
regressor = NEXUSRegressor()
regressor.fit(X_train, y_train)
predictions = regressor.predict(X_test)
```

### Using Pre-trained Models

If you have a trained model from a previous session, you can use it directly without retraining:

```python
from fundamental import NEXUSClassifier, NEXUSRegressor

classifier = NEXUSClassifier().load_model(trained_model_id="model_abc123")
predictions = classifier.predict(X_test)
probabilities = classifier.predict_proba(X_test)

regressor = NEXUSRegressor().load_model(trained_model_id="model_def456")
predictions = regressor.predict(X_test)
```

### Async Training

Model training is often a long-running operation. To support non-blocking workflows, you can submit training via `submit_fit_task()` and poll for completion. Once submitted, the training job runs in the background and its status can be queried at any time.

```python
from fundamental import NEXUSClassifier
import time

classifier = NEXUSClassifier()

# Submit training task without waiting
task_id = classifier.submit_fit_task(X_train, y_train)
print(f"Training task submitted: {task_id}")

# Poll status periodically
result = None
while result is None:
    result = classifier.poll_fit_result(task_id)
    if result is None:
        print("Training in progress...")
        time.sleep(10)  # Wait before polling again

# Model is now fitted and ready for predictions
predictions = classifier.predict(X_test)
```

### Model Management

The client provides methods for managing your trained models:

```python
from fundamental import Fundamental

# Create a client
client = Fundamental()

# List all available models
models = client.models.list()
print(f"Available models: {models}")

# Get information about a specific model
model_info = client.models.get("model_id_123")
print(f"Model info: {model_info}")
print(f"Attributes: {model_info.attributes}")

# Delete a model
client.models.delete("model_id_123")
```

#### Model Attributes

You can set attributes on your models to help organize and identify them.
We recommend always setting a `name` attribute; if omitted, the name will default to
`<model_version> [id:<model_id_suffix>]`.

```python
# Set attributes directly on a fitted model
classifier.set_attributes({"name": "Breast Cancer Classifier", "stage": "prod"})

# Or using the client
client.models.set_attributes(
    "model_id_123",
    attributes={"name": "Breast Cancer Classifier", "description": "Production model v1"}
)
```

### Explainability & Insights

#### Feature Importance

After fitting a model, you can compute feature importance to quantify the contribution of each input feature to the model's output:

```python
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from fundamental import NEXUSClassifier


# Load data
X, y = load_breast_cancer(return_X_y=True)
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.5, random_state=42)
# Fit the model
classifier = NEXUSClassifier()
classifier.fit(X_train, y_train)
# Get feature importance (waits for computation to complete)
feature_importance = classifier.get_feature_importance(X_val)
print(f"Feature importance: {feature_importance}")
```

Feature importance computation can take a significant amount of time. If you prefer to submit the task and check its status periodically, you can use the asynchronous approach:

```python
# Submit task without waiting
task_id = classifier.submit_feature_importance_task(X_val)

# Poll status later
result = classifier.poll_feature_importance_result(task_id)
if result is not None:
    print(f"Feature importance: {result}")
```

## Configuration

### Client Configuration

Configure the SDK client through environment variables or programmatically.

#### API Key

You can provide your API key in two ways:

```python
# 1. Programmatic
import fundamental
from fundamental import Fundamental, NEXUSClassifier

fundamental.set_client(Fundamental(api_key="your_api_key_here"))
classifier = NEXUSClassifier()
```

```bash
# 2. Environment variable
export FUNDAMENTAL_API_KEY="your_api_key_here"
```

#### AWS Marketplace

For AWS Marketplace deployments, use the `FundamentalAWSMarketplaceClient` which authenticates using AWS IAM roles via SigV4 signing instead of API keys:

```python
import fundamental
from fundamental import FundamentalAWSMarketplaceClient, NEXUSClassifier

# Set the AWS Marketplace client with your deployment URL and AWS region
fundamental.set_client(FundamentalAWSMarketplaceClient(
    aws_region="us-west-2",  # Required
    api_url="http://your-private-server:8000"
))

# Use the SDK as normal
classifier = NEXUSClassifier()
classifier.fit(X_train, y_train)
predictions = classifier.predict(X_test)
```

The `FundamentalAWSMarketplaceClient` automatically uses AWS credentials from the environment (IAM role, environment variables, or AWS config file) to sign requests. No API key is needed.

You can also configure using environment variables:

```bash
export FUNDAMENTAL_API_URL="http://your-private-server:8000"
```

```python
fundamental.set_client(
    FundamentalAWSMarketplaceClient(
        aws_region="us-west-2",  # Required
        # api_url="http://your-private-server:8000",  # Optional; overrides FUNDAMENTAL_API_URL
    )
)
```

#### Timeouts and Retries

Configure timeouts and retries when creating a client:

> **Note**: Timeouts apply only to the processing phase, starting after the dataset upload has completed.

```python
import fundamental
from fundamental import Fundamental, NEXUSClassifier

# Create and set a client with custom timeouts and retries
fundamental.set_client(Fundamental(
    fit_timeout=600,  # 10 minutes for training (default: 3 hours)
    predict_timeout=30,  # 30 seconds for predictions (default: 1 hour)
    retries=0  # Number of retries (default: 1)
))

# Estimators will use the global client
classifier = NEXUSClassifier()
```

#### SSL Verification

By default, the SDK verifies SSL certificates for all requests. To disable SSL verification:

```python
import fundamental
from fundamental import Fundamental

fundamental.set_client(Fundamental(
    api_key="your_api_key_here",
    verify_ssl=False
))
```

### Model Configuration

Configure model behavior and training parameters.

#### Mode

NEXUS offers two training modes to balance between speed and accuracy:

- **`quality` mode (default)**: Optimizes for the highest accuracy. This mode uses more comprehensive training processes and may take longer to complete.
- **`speed` mode**: Optimizes for faster training times while maintaining good accuracy.

```python
import fundamental
from fundamental import NEXUSClassifier, NEXUSRegressor

# Use quality mode (default)
classifier = NEXUSClassifier(mode="quality")
classifier.fit(X_train, y_train)

# Use speed mode for faster training
classifier_fast = NEXUSClassifier(mode="speed")
classifier_fast.fit(X_train, y_train)

# Same for regression
regressor = NEXUSRegressor(mode="speed")
regressor.fit(X_train, y_train)
```

## Supported Data Types

The SDK supports flexible input formats:

- **Input features (X)**:
  - `pandas.DataFrame`
  - `numpy.ndarray`

- **Target values (y)**:
  - `numpy.ndarray`
  - `pandas.Series`

> **Note**: Data must be serializable to Parquet via PyArrow. If you hit a serialization error, ensure columns have consistent numeric or string dtypes; complex numbers are not supported.

## Handling Errors

The SDK provides detailed error handling with specific exception types:

```python
from fundamental import NEXUSClassifier
from fundamental.exceptions import (
    NEXUSError,
    ValidationError,
    AuthenticationError,
    RateLimitError,
    ServerError
)

classifier = NEXUSClassifier()

try:
    classifier.fit(X_train, y_train)
except ValidationError as e:
    print(f"Invalid input data: {e}")
    print(f"Status code: {e.status_code}")
except AuthenticationError as e:
    print("Authentication failed - check your API key")
except RateLimitError as e:
    print("Rate limit exceeded - please wait before retrying")
except ServerError as e:
    print("Server error - please try again later")
except NEXUSError as e:
    print(f"An error occurred: {e}")
```

### Diagnostics and Support Information

All exceptions include a `trace_id` attribute that you can share with Fundamental support to help diagnose issues more quickly.

```python
except ServerError as e:
    if e.trace_id:
        print(f"Error trace_id: {e.trace_id}")
```

If you're troubleshooting an issue or need to share debug information with the Fundamental team, you can enable diagnostics to capture SDK activity and detailed error reports to a file:

```python
from fundamental.diagnostics import activate, deactivate

activate()            # logs to <tempdir>/fundamental/fundamental_debug_<timestamp>.log
# activate(log_dir="/tmp/logs")  # or specify a directory

# ... your code ...

deactivate()          # stop logging
```

Or use a context manager for scoped diagnostics:

```python
from fundamental.diagnostics import diagnose

with diagnose():
    classifier.fit(X_train, y_train)
```

The log file captures comprehensive SDK activity and produces detailed exception reports including tracebacks, trace IDs, and user source context. Secrets are automatically masked, but please review the log file before sharing it with the Fundamental team to ensure no sensitive data is included.

### Exception Types

| Error Type | Description | Status Code |
| ---------- | ----------- | ----------- |
| `ValidationError` | Input validation failed (bad request) | 400 |
| `AuthenticationError` | Authentication failed (missing/invalid API key) | 401 |
| `AuthorizationError` | Authorization failed (insufficient permissions) | 403 |
| `NotFoundError` | Resource not found | 404 |
| `RateLimitError` | API rate limit exceeded | 429 |
| `ServerError` | Server-side error | 500+ |
| `NetworkError` | Network connectivity issues | 503 |
| `RequestTimeoutError` | Request timed out | 504 |

## Troubleshooting

- **Missing API key** (`ValueError: API key is required...`): set `FUNDAMENTAL_API_KEY` or configure a client via `fundamental.set_client(...)`.
- **Serialization errors (PyArrow)**: ensure `X`/`y` contain consistent numeric or string types; avoid mixed-type/object columns.
- **Large datasets / memory use**: datasets are serialized to Parquet in-memory before upload. If you run into memory or upload issues, try sampling, reducing columns, or using batching.
- **Debugging issues**: run `from fundamental.diagnostics import activate; activate()` and share the generated log file with support.

## Versioning

This package follows [SemVer](https://semver.org/spec/v2.0.0.html) conventions.

To check the installed version:

```python
import fundamental
print(fundamental.__version__)
```

## Requirements

- Python 3.10 or higher
- See [pyproject.toml](pyproject.toml) for full dependency list

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## Security

If you believe you’ve found a security vulnerability, please email [support@fundamental.tech](mailto:support@fundamental.tech) and include a minimal reproduction. Please do not open a public GitHub issue.

## Support

- **SDK docs**: [SDK User Guide](https://launch.fundamental.tech/docs/guides/sdk/user-guide)
- **Issues**: [GitHub Issues](https://github.com/Fundamental-Technologies/fundamental-client/issues)
- **Email**: [support@fundamental.tech](mailto:support@fundamental.tech)
