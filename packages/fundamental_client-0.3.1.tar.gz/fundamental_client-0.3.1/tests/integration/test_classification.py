"""
Integration tests for classification tasks.
"""

from fundamental import NEXUSClassifier


class TestClassificationIntegration:
    """End-to-end integration tests for classification tasks."""

    def test_classifier_end_to_end(
        self,
        sample_classification_data,
    ):
        """Test complete classifier workflow."""
        X, y = sample_classification_data
        X_train, X_test = X.iloc[:80], X.iloc[80:]
        y_train = y[:80]

        classifier = NEXUSClassifier()
        classifier.fit(X_train, y_train)
        predictions = classifier.predict(X_test)

        assert classifier.trained_model_id_ is not None
        assert len(predictions) == len(X_test)

    def test_classifier_attributes_synced(self, sample_classification_data):
        """Test that model attributes are synced back after training."""
        X, y = sample_classification_data
        X_train, _ = X.iloc[:80], X.iloc[80:]
        y_train = y[:80]

        classifier = NEXUSClassifier()
        classifier.fit(X_train, y_train)

        assert classifier._estimator_type == "classifier", (
            "Should be an estimator of type classifier attribute"
        )
        assert hasattr(classifier, "classes_"), "Should have classes_ attribute"

    def test_pretrained_classifier_predictions(self, sample_classification_data):
        """Test that pretrained classifier can make predictions."""
        X, y = sample_classification_data
        X_train, X_test = X.iloc[:80], X.iloc[80:]
        y_train = y[:80]

        classifier = NEXUSClassifier()
        classifier.fit(X_train, y_train)

        model_id = classifier.trained_model_id_

        pretrained_classifier = NEXUSClassifier().load_model(trained_model_id=model_id)
        assert pretrained_classifier.trained_model_id_ is not None
        assert pretrained_classifier.fitted_

        predictions = pretrained_classifier.predict(X_test)
        assert len(predictions) == len(X_test)
