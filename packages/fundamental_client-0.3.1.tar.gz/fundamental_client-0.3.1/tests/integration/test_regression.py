"""
Integration tests for regression tasks.
"""

from fundamental import NEXUSRegressor


class TestRegressionIntegration:
    """End-to-end integration tests for regression tasks."""

    def test_regressor_end_to_end(
        self,
        sample_regression_data,
    ):
        """Test complete classifier workflow."""
        X, y = sample_regression_data
        X_train, X_test = X.iloc[:80], X.iloc[80:]
        y_train = y[:80]

        regressor = NEXUSRegressor()
        regressor.fit(X_train, y_train)
        predictions = regressor.predict(X_test)

        assert regressor.trained_model_id_ is not None
        assert len(predictions) == len(X_test)

    def test_regressor_attributes_synced(self, sample_regression_data):
        """Test that model attributes are synced back after training."""
        X, y = sample_regression_data
        X_train, _ = X.iloc[:80], X.iloc[80:]
        y_train = y[:80]

        regressor = NEXUSRegressor()
        regressor.fit(X_train, y_train)
        assert regressor._estimator_type == "regressor", (
            "Should be an estimator of type regressor attribute"
        )

    def test_pretrained_regressor_predictions(self, sample_regression_data):
        """Test that pretrained regressor can make predictions."""
        X, y = sample_regression_data
        X_train, X_test = X.iloc[:80], X.iloc[80:]
        y_train = y[:80]

        regressor = NEXUSRegressor()
        regressor.fit(X_train, y_train)

        model_id = regressor.trained_model_id_

        pretrained_regressor = NEXUSRegressor().load_model(trained_model_id=model_id)
        assert pretrained_regressor.trained_model_id_ is not None
        assert pretrained_regressor.fitted_

        predictions = pretrained_regressor.predict(X_test)
        assert len(predictions) == len(X_test)
