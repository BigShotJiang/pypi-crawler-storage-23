"""
Test configuration and shared fixtures for NEXUS client tests.
"""

# ruff: noqa: E402
from dotenv import load_dotenv

# Load environment variables from .env file BEFORE importing fundamental
# This ensures the API key is available when the module initializes
load_dotenv()

from types import SimpleNamespace
from typing import Tuple
from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest

from fundamental.services.inference import RemoteFitResponse, SubmitFitTaskResult


@pytest.fixture
def sample_classification_data() -> Tuple[pd.DataFrame, np.ndarray]:
    """Sample training data for testing."""
    np.random.seed(42)
    X = pd.DataFrame(
        {
            "feature1": np.random.normal(0, 1, 100),
            "feature2": np.random.normal(0, 1, 100),
            "feature3": np.random.randint(0, 5, 100),
        }
    )
    y = np.random.randint(0, 2, 100)
    return X, y


@pytest.fixture
def sample_regression_data() -> Tuple[pd.DataFrame, np.ndarray]:
    """Sample regression data for testing."""
    np.random.seed(42)
    X = pd.DataFrame(
        {
            "feature1": np.random.normal(0, 1, 100),
            "feature2": np.random.normal(0, 1, 100),
            "feature3": np.random.randint(0, 5, 100),
        }
    )
    y = np.random.normal(0, 1, 100)
    return X, y


@pytest.fixture
def mock_remote_fit_classifier():
    """Mock remote_fit function with standard response."""
    estimator_fields = {
        "classes_": np.array([0, 1]),
    }

    mock_response = RemoteFitResponse(
        trained_model_id="test_model_123", estimator_fields=estimator_fields
    )
    with patch(
        "fundamental.estimator.base.remote_fit",
        return_value=mock_response,
    ) as mock:
        yield mock


@pytest.fixture
def mock_remote_fit_regressor():
    """Mock remote_fit function for regressor with appropriate attributes."""
    estimator_fields = {}

    mock_response = RemoteFitResponse(
        trained_model_id="test_model_123", estimator_fields=estimator_fields
    )
    with patch(
        "fundamental.estimator.base.remote_fit",
        return_value=mock_response,
    ) as mock:
        yield mock


@pytest.fixture
def mock_load_model():
    """Mock load_model function with standard response."""
    estimator_fields = {}

    mock_response = SimpleNamespace(estimator_fields=estimator_fields)
    with patch(
        "fundamental.services.models.ModelsService.load",
        return_value=mock_response,
    ) as mock:
        yield mock


@pytest.fixture
def mock_submit_fit_task_classifier():
    """Mock submit_fit_task function for classifier with standard response."""
    mock_response = SubmitFitTaskResult(
        task_id="test_task_123",
        trained_model_id="test_model_123",
    )
    with patch(
        "fundamental.estimator.base.submit_fit_task",
        return_value=mock_response,
    ) as mock:
        yield mock


@pytest.fixture
def mock_poll_fit_result_success():
    """Mock poll_fit_result function returning success."""
    estimator_fields = {
        "classes_": np.array([0, 1]),
    }

    mock_response = RemoteFitResponse(
        trained_model_id="test_model_123",
        estimator_fields=estimator_fields,
    )
    with patch(
        "fundamental.estimator.base.poll_fit_result",
        return_value=mock_response,
    ) as mock:
        yield mock


@pytest.fixture
def mock_poll_fit_result_in_progress():
    """Mock poll_fit_result function returning None (in progress)."""
    with patch(
        "fundamental.estimator.base.poll_fit_result",
        return_value=None,
    ) as mock:
        yield mock
