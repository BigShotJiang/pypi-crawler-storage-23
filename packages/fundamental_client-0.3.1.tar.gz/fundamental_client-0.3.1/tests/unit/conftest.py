"""Unit test specific fixtures."""

import os
from unittest.mock import patch

import pytest


@pytest.fixture(autouse=True)
def mock_api_key():
    """Auto-use fixture to provide dummy API key for unit tests only."""
    with patch.dict(os.environ, {"FUNDAMENTAL_API_KEY": "test_key_for_testing"}):
        yield
