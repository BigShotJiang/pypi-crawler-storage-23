"""
Sklearn interface compliance tests.

These tests verify that NEXUS estimators follow sklearn conventions without
calling fit/predict, making them safe to run in CI without API credentials.
"""

import warnings

import pytest
from sklearn.base import clone
from sklearn.utils import estimator_checks

from fundamental import NEXUSClassifier, NEXUSRegressor


def _get_tags_compat(estimator):
    """Get sklearn tags in a version-compatible way.

    In sklearn 1.6+, _get_tags() is deprecated in favor of __sklearn_tags__().
    In sklearn 1.5.x, _get_tags() returns a dict.
    """
    # Try new-style tags first (sklearn 1.6+)
    if hasattr(estimator, "__sklearn_tags__"):
        try:
            tags = estimator.__sklearn_tags__()
            # In 1.6+, tags is a Tags object, not a dict
            if not isinstance(tags, dict):
                return tags
        except (TypeError, AttributeError):
            # Fall back to _get_tags() if __sklearn_tags__ is unavailable or misbehaves
            pass

    # Fall back to old-style tags (sklearn 1.5.x)
    # Suppress deprecation warning in 1.6.x
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=FutureWarning)
        return estimator._get_tags()


class TestSklearnInterfaceCompliance:
    """Test sklearn interface compliance without calling fit/predict.

    These checks verify the estimator follows sklearn conventions for:
    - __init__ parameter handling
    - get_params/set_params behavior
    - clone() compatibility
    - repr() output
    - sklearn tags
    """

    @pytest.mark.parametrize("estimator_class", [NEXUSClassifier, NEXUSRegressor])
    def test_no_attributes_set_in_init(self, estimator_class):
        """Check that __init__ only sets parameters, no fitted attributes."""
        estimator_checks.check_no_attributes_set_in_init(
            estimator_class.__name__, estimator_class()
        )

    @pytest.mark.parametrize("estimator_class", [NEXUSClassifier, NEXUSRegressor])
    def test_get_params_invariance(self, estimator_class):
        """Check that get_params returns consistent results."""
        estimator_checks.check_get_params_invariance(estimator_class.__name__, estimator_class())

    @pytest.mark.parametrize("estimator_class", [NEXUSClassifier, NEXUSRegressor])
    def test_set_params(self, estimator_class):
        """Check that set_params works correctly."""
        estimator_checks.check_set_params(estimator_class.__name__, estimator_class())

    @pytest.mark.parametrize("estimator_class", [NEXUSClassifier, NEXUSRegressor])
    def test_estimator_cloneable(self, estimator_class):
        """Check that sklearn.base.clone() works correctly."""
        estimator = estimator_class()
        cloned = clone(estimator)
        assert type(cloned) is type(estimator)
        assert cloned.get_params() == estimator.get_params()  # type: ignore[union-attr]

    @pytest.mark.parametrize("estimator_class", [NEXUSClassifier, NEXUSRegressor])
    def test_estimator_repr(self, estimator_class):
        """Check that repr() produces valid output."""
        estimator = estimator_class()
        repr_str = repr(estimator)
        assert isinstance(repr_str, str)
        assert estimator_class.__name__ in repr_str

    @pytest.mark.parametrize("estimator_class", [NEXUSClassifier, NEXUSRegressor])
    def test_parameters_default_constructible(self, estimator_class):
        """Check that estimator can be constructed with default parameters."""
        estimator_checks.check_parameters_default_constructible(
            estimator_class.__name__, estimator_class()
        )

    @pytest.mark.parametrize("estimator_class", [NEXUSClassifier, NEXUSRegressor])
    def test_do_not_raise_errors_in_init_or_set_params(self, estimator_class):
        """Check that __init__ and set_params don't raise unexpected errors."""
        # Test default construction doesn't raise
        estimator = estimator_class()
        # Test set_params with current parameters doesn't raise
        params = estimator.get_params()
        estimator.set_params(**params)

    @pytest.mark.parametrize("estimator_class", [NEXUSClassifier, NEXUSRegressor])
    def test_valid_tag_types(self, estimator_class):
        """Check that sklearn tags have valid types."""
        estimator = estimator_class()
        tags = _get_tags_compat(estimator)

        # In sklearn 1.6+, tags is a Tags object with attributes
        # In sklearn 1.5.x, tags is a dict
        if isinstance(tags, dict):
            # sklearn 1.5.x style
            if "requires_fit" in tags:
                assert isinstance(tags["requires_fit"], bool)
            if "requires_y" in tags:
                assert isinstance(tags["requires_y"], bool)
            if "allow_nan" in tags:
                assert isinstance(tags["allow_nan"], bool)
        else:
            # sklearn 1.6+ style - tags is a Tags object
            # Just verify it's not None and has expected structure
            assert tags is not None
            assert hasattr(tags, "estimator_type")
            assert hasattr(tags, "target_tags")
