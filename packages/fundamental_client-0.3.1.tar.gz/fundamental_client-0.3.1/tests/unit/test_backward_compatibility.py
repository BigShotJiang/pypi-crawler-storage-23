"""
Tests for backward compatibility with deprecated FTM classes.

These tests verify that the deprecated FTMClassifier, FTMRegressor, and FTMError
aliases continue to work while emitting appropriate deprecation warnings.
"""

import warnings

from fundamental import FTMClassifier, FTMRegressor, NEXUSClassifier, NEXUSRegressor


class TestDeprecatedEstimators:
    """Test deprecated FTM estimator classes."""

    def test_ftm_classifier_inherits_from_nexus(self):
        """Test that FTMClassifier is a subclass of NEXUSClassifier."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", FutureWarning)
            classifier = FTMClassifier()
            assert isinstance(classifier, NEXUSClassifier)

    def test_ftm_regressor_inherits_from_nexus(self):
        """Test that FTMRegressor is a subclass of NEXUSRegressor."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", FutureWarning)
            regressor = FTMRegressor()
            assert isinstance(regressor, NEXUSRegressor)

    def test_ftm_classifier_accepts_mode_parameter(self):
        """Test that FTMClassifier accepts the mode parameter."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", FutureWarning)
            classifier = FTMClassifier(mode="speed")
            assert classifier.mode == "speed"

    def test_ftm_regressor_accepts_mode_parameter(self):
        """Test that FTMRegressor accepts the mode parameter."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", FutureWarning)
            regressor = FTMRegressor(mode="speed")
            assert regressor.mode == "speed"
