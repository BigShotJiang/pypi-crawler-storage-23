"""
Unit tests for NEXUS estimators.
"""

from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
import pytest
import sklearn.base
from sklearn.exceptions import NotFittedError
from sklearn.utils.validation import check_is_fitted

from fundamental import NEXUSClassifier, NEXUSRegressor


class TestNEXUSClassifier:
    """Test NEXUSClassifier functionality."""

    def test_init_default(self):
        """Test classifier initialization with default parameters."""
        classifier = NEXUSClassifier()
        assert not hasattr(classifier, "trained_model_id_")
        assert sklearn.base.is_classifier(classifier)

    def test_init_with_model_id(self, mock_load_model):
        """Test classifier loading with pre-trained model ID."""
        model_id = "test_model_123"
        classifier = NEXUSClassifier().load_model(model_id)
        assert classifier.trained_model_id_ == model_id
        assert classifier.fitted_
        check_is_fitted(classifier)

    @patch("fundamental.services.models.ModelsService.load")
    def test_load_model_assert_fields(self, mock_load_model):
        """Test classifier loads model fields correctly from load_model."""

        classes_ = np.array([0, 1, 2])
        n_features_in_ = 5
        feature_names_in_ = np.array(["feat1", "feat2", "feat3", "feat4", "feat5"])
        estimator_fields = {
            "classes_": classes_,
            "n_features_in_": n_features_in_,
            "feature_names_in_": feature_names_in_,
        }

        mock_load_model.return_value = SimpleNamespace(estimator_fields=estimator_fields)

        model_id = "test_model_123"
        classifier = NEXUSClassifier().load_model(model_id)

        np.testing.assert_array_equal(classifier.classes_, classes_)
        assert classifier.n_features_in_ == n_features_in_
        np.testing.assert_array_equal(classifier.feature_names_in_, feature_names_in_)

    def test_fit(self, mock_remote_fit_classifier, sample_classification_data):
        """Test classifier fit method."""
        X, y = sample_classification_data

        classifier = NEXUSClassifier()
        result = classifier.fit(X, y)

        assert result is classifier
        assert classifier.trained_model_id_ is not None
        assert classifier.fitted_
        mock_remote_fit_classifier.assert_called_once()
        call_args = mock_remote_fit_classifier.call_args
        assert call_args.kwargs["X"].equals(X)
        np.testing.assert_array_equal(call_args.kwargs["y"], y)
        assert call_args.kwargs["task"] == "classification"
        assert call_args.kwargs["mode"] == "quality"
        assert "client" in call_args.kwargs
        assert call_args.kwargs["time_series"] is False

    def test_fit_sends_time_series_false(
        self, mock_remote_fit_classifier, sample_classification_data
    ):
        """Test that classifier sends time_series=False by default."""
        X, y = sample_classification_data

        classifier = NEXUSClassifier()
        classifier.fit(X, y)

        call_args = mock_remote_fit_classifier.call_args
        assert call_args.kwargs["time_series"] is False

    def test_fit_update_estimator_fields(
        self, mock_remote_fit_classifier, sample_classification_data
    ):
        """Test that fit updates estimator fields."""
        X, y = sample_classification_data

        classifier = NEXUSClassifier()
        classifier.fit(X, y)

        assert classifier.n_features_in_ is not None
        assert classifier.classes_ is not None
        assert classifier.fitted_

    def test_multiple_fit_same_estimator(
        self, mock_remote_fit_classifier, sample_classification_data
    ):
        """Test that fitting an already fitted model is accepted."""
        X, y = sample_classification_data
        classifier = NEXUSClassifier()

        classifier.fit(X, y)
        classifier.fit(X, y)

    @patch("fundamental.estimator.base.remote_predict")
    def test_predict(self, mock_remote_predict, mock_load_model, sample_classification_data):
        """Test classifier predict method."""
        X, _ = sample_classification_data
        X_test = X.iloc[:5]
        expected_predictions = np.array([0, 1, 0, 1, 1])
        mock_remote_predict.return_value = expected_predictions

        classifier = NEXUSClassifier().load_model("test_model")
        predictions = classifier.predict(X_test)

        np.testing.assert_array_equal(predictions, expected_predictions)
        mock_remote_predict.assert_called_once()
        call_args = mock_remote_predict.call_args
        assert call_args.kwargs["X"].equals(X_test)
        assert call_args.kwargs["output_type"] == "preds"
        assert call_args.kwargs["trained_model_id"] == "test_model"
        assert "client" in call_args.kwargs

    @patch("fundamental.estimator.base.remote_predict")
    def test_predict_proba(self, mock_remote_predict, mock_load_model, sample_classification_data):
        """Test classifier predict_proba method."""
        X, _ = sample_classification_data
        X_test = X.iloc[:5]
        expected_probas = np.array([[0.8, 0.2], [0.3, 0.7], [0.9, 0.1], [0.4, 0.6], [0.2, 0.8]])
        mock_remote_predict.return_value = expected_probas

        classifier = NEXUSClassifier().load_model("test_model")
        probas = classifier.predict_proba(X_test)

        np.testing.assert_array_equal(probas, expected_probas)
        mock_remote_predict.assert_called_once()
        call_args = mock_remote_predict.call_args
        assert call_args.kwargs["X"].equals(X_test)
        assert call_args.kwargs["output_type"] == "probas"
        assert call_args.kwargs["trained_model_id"] == "test_model"
        assert "client" in call_args.kwargs

    def test_predict_not_fitted(self, sample_classification_data):
        """Test that predict raises error when model not fitted."""
        X, _ = sample_classification_data
        classifier = NEXUSClassifier()
        with pytest.raises(NotFittedError):  # sklearn raises NotFittedError
            classifier.predict(X.iloc[:5])


class TestNEXUSRegressor:
    """Test NEXUSRegressor functionality."""

    def test_init_default(self):
        """Test regressor initialization with default parameters."""
        regressor = NEXUSRegressor()
        assert not hasattr(regressor, "trained_model_id_")
        assert sklearn.base.is_regressor(regressor)

    def test_init_with_model_id(self, mock_load_model):
        """Test regressor loading with pre-trained model ID."""
        model_id = "test_model_123"
        regressor = NEXUSRegressor().load_model(model_id)
        assert regressor.trained_model_id_ == model_id
        assert regressor.fitted_
        check_is_fitted(regressor)

    @patch("fundamental.services.models.ModelsService.load")
    def test_load_model_assert_fields(self, mock_load_model):
        """Test regressor loads model fields correctly from load_model."""

        n_features_in_ = 4
        feature_names_in_ = np.array(["feat1", "feat2", "feat3", "feat4"])
        estimator_fields = {
            "n_features_in_": n_features_in_,
            "feature_names_in_": feature_names_in_,
        }

        mock_load_model.return_value = SimpleNamespace(estimator_fields=estimator_fields)

        model_id = "test_model_123"
        regressor = NEXUSRegressor().load_model(model_id)

        assert regressor.n_features_in_ == n_features_in_
        np.testing.assert_array_equal(regressor.feature_names_in_, feature_names_in_)

        # Test sklearn utilities work with our regressor
        from sklearn.utils.validation import check_array

        # Test that check_is_fitted works
        check_is_fitted(regressor)

        # Test sklearn's estimator type detection
        assert sklearn.base.is_regressor(regressor)
        assert not sklearn.base.is_classifier(regressor)

        # Test feature names array validation
        check_array(regressor.feature_names_in_, dtype=object, ensure_2d=False)  # Should not raise

    def test_fit(self, mock_remote_fit_regressor, sample_regression_data):
        """Test regressor fit method."""
        X, y = sample_regression_data

        regressor = NEXUSRegressor()
        result = regressor.fit(X, y)

        assert result is regressor
        assert regressor.trained_model_id_ == "test_model_123"
        assert regressor.fitted_
        mock_remote_fit_regressor.assert_called_once()
        call_args = mock_remote_fit_regressor.call_args
        assert call_args.kwargs["X"].equals(X)
        np.testing.assert_array_equal(call_args.kwargs["y"], y)
        assert call_args.kwargs["task"] == "regression"
        assert call_args.kwargs["mode"] == "quality"
        assert "client" in call_args.kwargs
        assert call_args.kwargs["time_series"] is False

    def test_fit_with_time_series(self, mock_remote_fit_regressor, sample_regression_data):
        """Test regressor fit passes time_series when enabled."""
        X, y = sample_regression_data

        regressor = NEXUSRegressor(time_series=True)
        regressor.fit(X, y)

        call_args = mock_remote_fit_regressor.call_args
        assert call_args.kwargs["time_series"] is True

    @patch("fundamental.estimator.base.remote_predict")
    def test_predict(self, mock_remote_predict, mock_load_model, sample_regression_data):
        """Test regressor predict method."""
        X, _ = sample_regression_data
        X_test = X.iloc[:5]
        expected_predictions = np.array([1.2, -0.5, 0.8, -1.1, 2.3])
        mock_remote_predict.return_value = expected_predictions

        regressor = NEXUSRegressor().load_model("test_model")
        predictions = regressor.predict(X_test)

        np.testing.assert_array_equal(predictions, expected_predictions)
        mock_remote_predict.assert_called_once()
        call_args = mock_remote_predict.call_args
        assert call_args.kwargs["X"].equals(X_test)
        assert call_args.kwargs["output_type"] == "preds"
        assert call_args.kwargs["trained_model_id"] == "test_model"
        assert "client" in call_args.kwargs

    def test_fit_update_fields(self, mock_remote_fit_regressor, sample_regression_data):
        """Test regressor fit method updates estimator fields."""
        X, y = sample_regression_data

        regressor = NEXUSRegressor()
        regressor.fit(X, y)

        assert regressor.n_features_in_ is not None
        assert regressor.fitted_


class TestFeatureImportanceValidation:
    """Test data validation for feature importance methods."""

    def test_get_feature_importance_invalid_x_type(self, mock_load_model):
        """Test get_feature_importance raises TypeError for invalid X type."""
        classifier = NEXUSClassifier().load_model("test_model")
        with pytest.raises(TypeError):
            classifier.get_feature_importance(X="invalid")

    def test_get_feature_importance_empty_dataframe(self, mock_load_model):
        """Test get_feature_importance raises ValueError for empty DataFrame."""
        import pandas as pd

        X = pd.DataFrame()

        classifier = NEXUSClassifier().load_model("test_model")
        with pytest.raises(ValueError):  # noqa: PT011
            classifier.get_feature_importance(X=X)

    def test_submit_feature_importance_task_invalid_x_type(self, mock_load_model):
        """Test submit_feature_importance_task raises TypeError for invalid X type."""
        classifier = NEXUSClassifier().load_model("test_model")
        with pytest.raises(TypeError):
            classifier.submit_feature_importance_task(X="invalid")

    def test_submit_feature_importance_task_empty_dataframe(self, mock_load_model):
        """Test submit_feature_importance_task raises ValueError for empty DataFrame."""
        import pandas as pd

        X = pd.DataFrame()

        classifier = NEXUSClassifier().load_model("test_model")
        with pytest.raises(ValueError):  # noqa: PT011
            classifier.submit_feature_importance_task(X=X)

    def test_get_feature_importance_not_fitted(self, sample_classification_data):
        """Test get_feature_importance raises NotFittedError when model not fitted."""
        X, _ = sample_classification_data
        classifier = NEXUSClassifier()
        with pytest.raises(NotFittedError):
            classifier.get_feature_importance(X=X)

    def test_submit_feature_importance_task_not_fitted(self, sample_classification_data):
        """Test submit_feature_importance_task raises NotFittedError when model not fitted."""
        X, _ = sample_classification_data
        classifier = NEXUSClassifier()
        with pytest.raises(NotFittedError):
            classifier.submit_feature_importance_task(X=X)


class TestFitSubmitAndPoll:
    """Test submit_fit_task and poll_fit_result methods."""

    def test_submit_fit_task_returns_task_id(
        self, mock_submit_fit_task_classifier, sample_classification_data
    ):
        """Test submit_fit_task returns task ID string."""
        X, y = sample_classification_data
        classifier = NEXUSClassifier()

        task_id = classifier.submit_fit_task(X, y)

        assert task_id == "test_task_123"
        assert classifier._pending_trained_model_id == "test_model_123"
        mock_submit_fit_task_classifier.assert_called_once()

    def test_submit_fit_task_validates_input(self, sample_classification_data):
        """Test submit_fit_task validates input types."""
        classifier = NEXUSClassifier()

        with pytest.raises(TypeError):
            classifier.submit_fit_task(X="invalid", y="invalid")

    def test_submit_fit_task_validates_empty_data(self):
        """Test submit_fit_task rejects empty data."""
        import pandas as pd

        X = pd.DataFrame()
        y = np.array([])

        classifier = NEXUSClassifier()
        with pytest.raises(ValueError):  # noqa: PT011
            classifier.submit_fit_task(X=X, y=y)

    def test_poll_fit_result_success(
        self,
        mock_submit_fit_task_classifier,
        mock_poll_fit_result_success,
        sample_classification_data,
    ):
        """Test poll_fit_result returns Self when task completes."""
        X, y = sample_classification_data
        classifier = NEXUSClassifier()

        # First submit
        task_id = classifier.submit_fit_task(X, y)

        # Then poll - should return self
        result = classifier.poll_fit_result(task_id)

        assert result is classifier
        assert classifier.fitted_
        assert classifier.trained_model_id_ == "test_model_123"
        mock_poll_fit_result_success.assert_called_once()

    def test_poll_fit_result_in_progress(
        self,
        mock_submit_fit_task_classifier,
        mock_poll_fit_result_in_progress,
        sample_classification_data,
    ):
        """Test poll_fit_result returns None when task in progress."""
        X, y = sample_classification_data
        classifier = NEXUSClassifier()

        # First submit
        task_id = classifier.submit_fit_task(X, y)

        # Then poll - should return None
        result = classifier.poll_fit_result(task_id)

        assert result is None
        assert not hasattr(classifier, "fitted_") or not classifier.fitted_
        mock_poll_fit_result_in_progress.assert_called_once()

    def test_poll_fit_result_sets_estimator_fields(
        self,
        mock_submit_fit_task_classifier,
        mock_poll_fit_result_success,
        sample_classification_data,
    ):
        """Test poll_fit_result sets estimator fields when complete."""
        X, y = sample_classification_data
        classifier = NEXUSClassifier()

        task_id = classifier.submit_fit_task(X, y)
        classifier.poll_fit_result(task_id)

        assert hasattr(classifier, "classes_")
        np.testing.assert_array_equal(classifier.classes_, np.array([0, 1]))
        assert classifier.n_features_in_ == 3

    def test_predict_after_submit_before_poll_raises_not_fitted(
        self,
        mock_submit_fit_task_classifier,
        sample_classification_data,
    ):
        """Test that predict raises NotFittedError after submit but before poll completes."""
        X, y = sample_classification_data
        classifier = NEXUSClassifier()

        # Submit fit task (training started but not complete)
        classifier.submit_fit_task(X, y)

        # Attempting to predict should raise NotFittedError
        with pytest.raises(NotFittedError):
            classifier.predict(X.iloc[:5])
