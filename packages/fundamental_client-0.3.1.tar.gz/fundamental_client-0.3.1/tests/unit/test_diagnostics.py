"""Tests for fundamental.diagnostics."""

import logging

import pytest

from fundamental.constants import ENV_API_KEY
from fundamental.diagnostics.masking import SanitizingFilter

# Values use low-entropy repetitive strings to avoid triggering gitleaks.
# The masking logic matches on the key (e.g. "api_key", "token"), not the value.
_SECRET_CASES = [
    'api_key="fake_fake_fake_fake"',
    "api-key: fake_fake_fake_fake",
    "token='fake_fake_fake_fake'",
    "password=fake_fake_fake_fake",
    "secret: fake_fake_fake_fake",
    "credential=fake_fake_fake_fake",
    "API_KEY=fake_fake_fake_fake",
    "Token=fake_fake_fake_fake",
    f'{ENV_API_KEY}="fake_fake_fake_fake"',
    f"{ENV_API_KEY}=fake_fake_fake_fake",
]

_SAFE_CASES = [
    "just a normal log message",
    "status_code=200",
    "X.shape=(100, 5)",
]


def _make_record(msg: str, args: tuple | None = None) -> logging.LogRecord:
    return logging.LogRecord(
        name="test",
        level=logging.DEBUG,
        pathname="",
        lineno=0,
        msg=msg,
        args=args,
        exc_info=None,
    )


def _last_n(text: str, n: int = 5) -> str:
    """Extract the last n characters of the secret value in the text."""
    # Strip trailing quotes
    stripped = text.rstrip("'\"")
    return stripped[-n:]


class TestSanitizingFilter:
    """Tests for the SanitizingFilter logging filter."""

    @pytest.mark.parametrize("text", _SECRET_CASES)
    def test_secret_tail_is_removed(self, text: str) -> None:
        f = SanitizingFilter()
        record = _make_record(text)
        tail = _last_n(text)
        f.filter(record)
        assert tail not in record.msg
        assert "*" in record.msg

    @pytest.mark.parametrize("text", _SAFE_CASES)
    def test_no_secret_unchanged(self, text: str) -> None:
        f = SanitizingFilter()
        record = _make_record(text)
        f.filter(record)
        assert record.msg == text

    @pytest.mark.parametrize("text", _SECRET_CASES)
    def test_secret_tail_is_removed_from_formatted_args(self, text: str) -> None:
        f = SanitizingFilter()
        record = _make_record("Log message: %s", (text,))
        tail = _last_n(text)
        f.filter(record)
        assert tail not in record.msg
        assert "*" in record.msg
        assert record.args is None
