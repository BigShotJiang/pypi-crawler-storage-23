"""Tests for Pydantic models — ensure wire-format conformance with Rust types."""

from wl_secrets_broker.models import (
    CapabilityRequest,
    CapabilityResponse,
    ExecutionContext,
    DiscoveryMetadata,
    RedeemResponse,
)


def test_capability_request_serialization():
    req = CapabilityRequest(
        agent_id="conflict-resolver-v1",
        tenant_id="tenant-123",
        owner_user_id="user-456",
        tool="openai.chat.completions",
        resource="model:gpt-4o",
        secret_ref="openai/api-key",
        context=ExecutionContext(
            workflow_id="conflict-resolver",
            workflow_node="reason_with_llm",
            run_id="run-abc-123",
            step_id="step-7",
            purpose="generate_resolution_suggestion",
            intent="customer_support",
            orchestrator="langgraph",
        ),
        discovery=DiscoveryMetadata(
            orchestrator="langgraph",
            runtime="python-3.12",
            hostname="worker-pod-7f4a9",
        ),
    )

    data = req.model_dump(exclude_none=True)

    assert data["agent_id"] == "conflict-resolver-v1"
    assert data["tool"] == "openai.chat.completions"
    assert data["context"]["orchestrator"] == "langgraph"
    assert data["context"]["workflow_node"] == "reason_with_llm"
    assert data["discovery"]["runtime"] == "python-3.12"


def test_capability_request_minimal():
    req = CapabilityRequest(
        agent_id="test-agent",
        tool="test.tool",
        secret_ref="test/secret",
    )

    data = req.model_dump(exclude_none=True)
    assert "tenant_id" not in data
    assert "owner_user_id" not in data
    assert "resource" not in data
    assert "discovery" not in data


def test_capability_response_deserialization():
    resp = CapabilityResponse.model_validate({
        "sct": "eyJhbGciOi...",
        "ttl": 60,
        "decision_id": "wlapdp-dec-9c31",
    })

    assert resp.sct == "eyJhbGciOi..."
    assert resp.ttl == 60
    assert resp.decision_id == "wlapdp-dec-9c31"


def test_redeem_response_deserialization():
    resp = RedeemResponse.model_validate({
        "secret": "sk-test-xxx",
        "constraints": {
            "use_within_seconds": 10,
            "allowed_hosts": ["api.openai.com"],
            "scrub_from_logs": True,
        },
    })

    assert resp.secret == "sk-test-xxx"
    assert resp.constraints.use_within_seconds == 10
    assert resp.constraints.allowed_hosts == ["api.openai.com"]
    assert resp.constraints.scrub_from_logs is True


def test_execution_context_extra_fields():
    ctx = ExecutionContext(
        workflow_id="test",
        orchestrator="custom",
        custom_field="extra_value",
    )

    data = ctx.model_dump(exclude_none=True)
    assert data["custom_field"] == "extra_value"
