"""Tests for CrewAI context extractor."""

from types import SimpleNamespace

from wl_secrets_broker.context import WatchlightContext
from wl_secrets_broker.extractors.crewai import WatchlightCrewAICallback


class TestCrewAICallback:
    def test_task_callback_updates_node(self):
        ctx = WatchlightContext(agent_id="test-agent")
        callback = WatchlightCrewAICallback(ctx, crew_name="research-crew")

        # Simulate a CrewAI task output with agent role
        task_output = SimpleNamespace(
            agent="senior_researcher",
            description="Research the topic",
            raw="Research results...",
        )

        callback.task_callback(task_output)

        assert ctx._workflow_node == "senior_researcher"
        assert ctx._step_counter == 1
        assert ctx._step_id == "step-1"
        assert ctx.workflow_id == "research-crew"
        assert ctx.orchestrator == "crewai"

    def test_task_callback_with_agent_object(self):
        ctx = WatchlightContext(agent_id="test-agent")
        callback = WatchlightCrewAICallback(ctx)

        # Agent as an object with .role attribute
        agent_obj = SimpleNamespace(role="technical_writer")
        task_output = SimpleNamespace(agent=agent_obj)

        callback.task_callback(task_output)

        assert ctx._workflow_node == "technical_writer"

    def test_step_callback_updates_tool(self):
        ctx = WatchlightContext(agent_id="test-agent")
        callback = WatchlightCrewAICallback(ctx)

        # Simulate a step with tool use
        step_output = SimpleNamespace(
            agent="researcher",
            tool="web_search",
            tool_input="AI agent security",
            output="Found relevant articles...",
        )

        callback.step_callback(step_output)

        assert ctx._workflow_node == "researcher"
        assert ctx._extra.get("current_tool") == "web_search"

    def test_step_callback_increments_counter(self):
        ctx = WatchlightContext(agent_id="test-agent")
        callback = WatchlightCrewAICallback(ctx)

        step1 = SimpleNamespace(agent="agent_a")
        step2 = SimpleNamespace(agent="agent_b")
        step3 = SimpleNamespace(agent="agent_a")

        callback.step_callback(step1)
        assert ctx._step_counter == 1

        callback.step_callback(step2)
        assert ctx._step_counter == 2

        callback.step_callback(step3)
        assert ctx._step_counter == 3
        assert ctx._step_id == "step-3"

    def test_set_kickoff_id(self):
        ctx = WatchlightContext(agent_id="test-agent")
        callback = WatchlightCrewAICallback(ctx)

        callback.set_kickoff_id("kickoff-abc123")

        assert ctx.run_id == "kickoff-abc123"

    def test_context_builds_correctly(self):
        ctx = WatchlightContext(
            agent_id="test-agent",
            tenant_id="tenant-1",
        )
        callback = WatchlightCrewAICallback(ctx, crew_name="my-crew")

        task_output = SimpleNamespace(agent="researcher")
        callback.task_callback(task_output)

        exec_ctx = ctx.build_execution_context()
        assert exec_ctx.orchestrator == "crewai"
        assert exec_ctx.workflow_id == "my-crew"
        assert exec_ctx.workflow_node == "researcher"
        assert exec_ctx.step_id == "step-1"
