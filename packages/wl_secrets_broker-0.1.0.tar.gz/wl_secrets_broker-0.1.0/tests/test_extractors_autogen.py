"""Tests for AutoGen context extractor."""

from types import SimpleNamespace

from wl_secrets_broker.context import WatchlightContext
from wl_secrets_broker.extractors.autogen import WatchlightAutoGenHandler


class TestAutoGenHandler:
    def test_on_message_received_updates_node(self):
        ctx = WatchlightContext(agent_id="test-agent")
        handler = WatchlightAutoGenHandler(ctx, group_chat_name="research-team")

        sender = SimpleNamespace(name="researcher")
        handler.on_message_received(sender, "Hello world")

        assert ctx._workflow_node == "researcher"
        assert ctx._step_counter == 1
        assert ctx._step_id == "step-1"
        assert ctx.workflow_id == "research-team"
        assert ctx.orchestrator == "autogen"

    def test_on_message_received_with_string_sender(self):
        ctx = WatchlightContext(agent_id="test-agent")
        handler = WatchlightAutoGenHandler(ctx)

        handler.on_message_received("coder_agent", "Write the code")

        assert ctx._workflow_node == "coder_agent"

    def test_on_message_received_extracts_function_call_tool(self):
        ctx = WatchlightContext(agent_id="test-agent")
        handler = WatchlightAutoGenHandler(ctx)

        sender = SimpleNamespace(name="assistant")
        message = {
            "content": "Let me search for that",
            "function_call": {"name": "web_search", "arguments": '{"query": "AI"}'},
        }

        handler.on_message_received(sender, message)

        assert ctx._workflow_node == "assistant"
        assert ctx._extra.get("current_tool") == "web_search"

    def test_on_message_received_extracts_tool_calls(self):
        ctx = WatchlightContext(agent_id="test-agent")
        handler = WatchlightAutoGenHandler(ctx)

        sender = SimpleNamespace(name="assistant")
        message = {
            "content": "",
            "tool_calls": [
                {"function": {"name": "read_file", "arguments": "{}"}, "id": "call_1"},
            ],
        }

        handler.on_message_received(sender, message)

        assert ctx._extra.get("current_tool") == "read_file"

    def test_reply_hook_updates_context(self):
        ctx = WatchlightContext(agent_id="test-agent")
        handler = WatchlightAutoGenHandler(ctx)

        sender = SimpleNamespace(name="reviewer")
        messages = [
            {"role": "user", "content": "Review this code"},
            {
                "role": "assistant",
                "content": "Using tool",
                "function_call": {"name": "code_review", "arguments": "{}"},
            },
        ]

        result = handler._reply_hook(
            recipient=SimpleNamespace(name="coder"),
            messages=messages,
            sender=sender,
        )

        # Should not intercept the reply
        assert result == (False, None)
        assert ctx._workflow_node == "reviewer"
        assert ctx._extra.get("current_tool") == "code_review"

    def test_session_id_sets_run_id(self):
        ctx = WatchlightContext(agent_id="test-agent")
        _handler = WatchlightAutoGenHandler(ctx, session_id="session-xyz")  # noqa: F841

        assert ctx.run_id == "session-xyz"

    def test_step_counter_increments_across_messages(self):
        ctx = WatchlightContext(agent_id="test-agent")
        handler = WatchlightAutoGenHandler(ctx)

        handler.on_message_received(SimpleNamespace(name="agent_a"), "msg1")
        assert ctx._step_counter == 1

        handler.on_message_received(SimpleNamespace(name="agent_b"), "msg2")
        assert ctx._step_counter == 2

        handler.on_message_received(SimpleNamespace(name="agent_a"), "msg3")
        assert ctx._step_counter == 3
        assert ctx._step_id == "step-3"

    def test_context_builds_correctly(self):
        ctx = WatchlightContext(
            agent_id="test-agent",
            tenant_id="tenant-1",
        )
        handler = WatchlightAutoGenHandler(
            ctx, group_chat_name="dev-team", session_id="sess-001"
        )

        handler.on_message_received(SimpleNamespace(name="planner"), "Plan the task")

        exec_ctx = ctx.build_execution_context()
        assert exec_ctx.orchestrator == "autogen"
        assert exec_ctx.workflow_id == "dev-team"
        assert exec_ctx.workflow_node == "planner"
        assert exec_ctx.run_id == "sess-001"
        assert exec_ctx.step_id == "step-1"
