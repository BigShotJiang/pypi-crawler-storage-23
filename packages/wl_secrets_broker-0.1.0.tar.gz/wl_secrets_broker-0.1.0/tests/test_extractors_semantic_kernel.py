"""Tests for Semantic Kernel context extractor."""

from types import SimpleNamespace

import pytest

from wl_secrets_broker.context import WatchlightContext
from wl_secrets_broker.extractors.semantic_kernel import WatchlightSKFilter


def _make_sk_context(
    plugin_name: str | None = None,
    function_name: str | None = None,
    fully_qualified_name: str | None = None,
    kernel_id: str | None = None,
    service_id: str | None = None,
):
    """Build a mock Semantic Kernel FunctionInvocationContext."""
    fn = SimpleNamespace()
    if plugin_name is not None:
        fn.plugin_name = plugin_name
    if function_name is not None:
        fn.name = function_name
    if fully_qualified_name is not None:
        fn.fully_qualified_name = fully_qualified_name

    kernel = SimpleNamespace()
    if kernel_id is not None:
        kernel.id = kernel_id

    args = SimpleNamespace()
    if service_id is not None:
        args.execution_settings = SimpleNamespace(service_id=service_id)

    return SimpleNamespace(function=fn, kernel=kernel, arguments=args)


class TestSKFilter:
    @pytest.mark.asyncio
    async def test_function_invocation_updates_node(self):
        ctx = WatchlightContext(agent_id="test-agent")
        sk_filter = WatchlightSKFilter(ctx, kernel_id="kernel-001")

        sk_ctx = _make_sk_context(
            plugin_name="SearchPlugin",
            function_name="search_web",
            kernel_id="kernel-001",
        )

        next_called = False

        async def mock_next(context):
            nonlocal next_called
            next_called = True

        await sk_filter.on_function_invocation(sk_ctx, mock_next)

        assert next_called
        assert ctx._workflow_node == "SearchPlugin.search_web"
        assert ctx._step_counter == 1
        assert ctx._step_id == "step-1"
        assert ctx.workflow_id == "kernel-001"
        assert ctx.orchestrator == "semantic_kernel"

    @pytest.mark.asyncio
    async def test_function_name_only(self):
        ctx = WatchlightContext(agent_id="test-agent")
        sk_filter = WatchlightSKFilter(ctx)

        sk_ctx = _make_sk_context(function_name="summarize")

        async def mock_next(context):
            pass

        await sk_filter.on_function_invocation(sk_ctx, mock_next)

        assert ctx._workflow_node == "summarize"

    @pytest.mark.asyncio
    async def test_fully_qualified_name_fallback(self):
        ctx = WatchlightContext(agent_id="test-agent")
        sk_filter = WatchlightSKFilter(ctx)

        # No plugin_name, no name, only fully_qualified_name
        fn = SimpleNamespace(fully_qualified_name="MyPlugin-summarize_v2")
        sk_ctx = SimpleNamespace(
            function=fn,
            kernel=SimpleNamespace(),
            arguments=SimpleNamespace(),
        )

        async def mock_next(context):
            pass

        await sk_filter.on_function_invocation(sk_ctx, mock_next)

        assert ctx._workflow_node == "MyPlugin-summarize_v2"

    @pytest.mark.asyncio
    async def test_kernel_id_extracted_from_context(self):
        ctx = WatchlightContext(agent_id="test-agent")
        sk_filter = WatchlightSKFilter(ctx)

        sk_ctx = _make_sk_context(
            plugin_name="ChatPlugin",
            function_name="chat",
            kernel_id="auto-kernel-42",
        )

        async def mock_next(context):
            pass

        await sk_filter.on_function_invocation(sk_ctx, mock_next)

        assert ctx.workflow_id == "auto-kernel-42"

    @pytest.mark.asyncio
    async def test_execution_id_sets_run_id(self):
        ctx = WatchlightContext(agent_id="test-agent")
        sk_filter = WatchlightSKFilter(ctx)

        sk_ctx = _make_sk_context(
            plugin_name="DataPlugin",
            function_name="fetch",
            service_id="exec-abc",
        )

        async def mock_next(context):
            pass

        await sk_filter.on_function_invocation(sk_ctx, mock_next)

        assert ctx.run_id == "exec-abc"

    @pytest.mark.asyncio
    async def test_plugin_name_stored_as_extra(self):
        ctx = WatchlightContext(agent_id="test-agent")
        sk_filter = WatchlightSKFilter(ctx)

        sk_ctx = _make_sk_context(
            plugin_name="FinancePlugin",
            function_name="get_balance",
        )

        async def mock_next(context):
            pass

        await sk_filter.on_function_invocation(sk_ctx, mock_next)

        assert ctx._extra.get("sk_plugin") == "FinancePlugin"

    @pytest.mark.asyncio
    async def test_step_counter_increments(self):
        ctx = WatchlightContext(agent_id="test-agent")
        sk_filter = WatchlightSKFilter(ctx)

        async def mock_next(context):
            pass

        for i in range(1, 4):
            sk_ctx = _make_sk_context(
                plugin_name="Plugin",
                function_name=f"func_{i}",
            )
            await sk_filter.on_function_invocation(sk_ctx, mock_next)
            assert ctx._step_counter == i
            assert ctx._step_id == f"step-{i}"

    @pytest.mark.asyncio
    async def test_context_builds_correctly(self):
        ctx = WatchlightContext(
            agent_id="test-agent",
            tenant_id="tenant-1",
        )
        sk_filter = WatchlightSKFilter(ctx, kernel_id="my-kernel")

        sk_ctx = _make_sk_context(
            plugin_name="ToolPlugin",
            function_name="run_tool",
            service_id="run-xyz",
        )

        async def mock_next(context):
            pass

        await sk_filter.on_function_invocation(sk_ctx, mock_next)

        exec_ctx = ctx.build_execution_context()
        assert exec_ctx.orchestrator == "semantic_kernel"
        assert exec_ctx.workflow_id == "my-kernel"
        assert exec_ctx.workflow_node == "ToolPlugin.run_tool"
        assert exec_ctx.run_id == "run-xyz"
        assert exec_ctx.step_id == "step-1"
