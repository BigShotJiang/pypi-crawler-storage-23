"""Tests for WatchlightClient — mock WSB API interactions."""

import pytest
import httpx
import respx

from wl_secrets_broker.client import WatchlightClient
from wl_secrets_broker.context import WatchlightContext
from wl_secrets_broker.errors import AuthorizationDenied


@pytest.fixture
def ctx():
    return WatchlightContext(
        agent_id="test-agent",
        tenant_id="tenant-1",
        workflow_id="test-graph",
        orchestrator="langgraph",
    )


@respx.mock
@pytest.mark.asyncio
async def test_get_secret_success(ctx):
    # Mock SCT request
    respx.post("http://localhost:8082/v1/capabilities/request").mock(
        return_value=httpx.Response(
            200,
            json={
                "sct": "test-sct-token",
                "ttl": 60,
                "decision_id": "dec-123",
            },
        )
    )

    # Mock SCT redeem
    respx.post("http://localhost:8082/v1/capabilities/redeem").mock(
        return_value=httpx.Response(
            200,
            json={
                "secret": "sk-test-secret",
                "constraints": {
                    "use_within_seconds": 10,
                    "allowed_hosts": ["api.openai.com"],
                    "scrub_from_logs": True,
                },
            },
        )
    )

    async with WatchlightClient(
        endpoint="http://localhost:8082",
        agent_id="test-agent",
        tenant_id="tenant-1",
    ) as client:
        with ctx:
            secret = await client.get_secret(
                tool="openai.chat.completions",
                secret_ref="openai/api-key",
            )

    assert secret == "sk-test-secret"


@respx.mock
@pytest.mark.asyncio
async def test_authorization_denied(ctx):
    respx.post("http://localhost:8082/v1/capabilities/request").mock(
        return_value=httpx.Response(
            403,
            json={
                "error": {
                    "code": "NOT_AUTHORIZED",
                    "message": "Policy denied: agent not trusted",
                    "decision_id": "dec-456",
                },
            },
        )
    )

    async with WatchlightClient(
        endpoint="http://localhost:8082",
        agent_id="test-agent",
    ) as client:
        with ctx:
            with pytest.raises(AuthorizationDenied) as exc_info:
                await client.get_secret(
                    tool="openai.chat.completions",
                    secret_ref="openai/api-key",
                )

    assert "Policy denied" in str(exc_info.value)
    assert exc_info.value.decision_id == "dec-456"


@respx.mock
@pytest.mark.asyncio
async def test_health_check_success():
    respx.get("http://localhost:8082/health").mock(
        return_value=httpx.Response(200, json={"status": "ok"})
    )

    async with WatchlightClient(
        endpoint="http://localhost:8082",
        agent_id="test-agent",
    ) as client:
        assert await client.health_check() is True


@respx.mock
@pytest.mark.asyncio
async def test_health_check_failure():
    respx.get("http://localhost:8082/health").mock(
        return_value=httpx.Response(503)
    )

    async with WatchlightClient(
        endpoint="http://localhost:8082",
        agent_id="test-agent",
    ) as client:
        assert await client.health_check() is False


@respx.mock
@pytest.mark.asyncio
async def test_request_includes_context(ctx):
    route = respx.post("http://localhost:8082/v1/capabilities/request").mock(
        return_value=httpx.Response(
            200,
            json={"sct": "token", "ttl": 60, "decision_id": "dec-1"},
        )
    )

    respx.post("http://localhost:8082/v1/capabilities/redeem").mock(
        return_value=httpx.Response(
            200,
            json={
                "secret": "sk-xxx",
                "constraints": {
                    "use_within_seconds": 10,
                    "allowed_hosts": [],
                    "scrub_from_logs": True,
                },
            },
        )
    )

    ctx.set_node("reason_with_llm")

    async with WatchlightClient(
        endpoint="http://localhost:8082",
        agent_id="test-agent",
        tenant_id="tenant-1",
    ) as client:
        with ctx:
            await client.get_secret(
                tool="openai.chat.completions",
                secret_ref="openai/api-key",
                resource="model:gpt-4o",
            )

    # Verify the request body sent to WSB
    request_body = route.calls[0].request
    import json

    body = json.loads(request_body.content)
    assert body["agent_id"] == "test-agent"
    assert body["tenant_id"] == "tenant-1"
    assert body["tool"] == "openai.chat.completions"
    assert body["resource"] == "model:gpt-4o"
    assert body["context"]["workflow_id"] == "test-graph"
    assert body["context"]["workflow_node"] == "reason_with_llm"
    assert body["context"]["orchestrator"] == "langgraph"
    assert body["context"]["step_id"] == "step-1"
