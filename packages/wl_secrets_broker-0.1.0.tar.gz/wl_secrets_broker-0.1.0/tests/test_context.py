"""Tests for WatchlightContext — context propagation and execution context building."""

from wl_secrets_broker.context import WatchlightContext, get_current_context


def test_context_manager():
    ctx = WatchlightContext(
        agent_id="test-agent",
        tenant_id="tenant-1",
        workflow_id="test-graph",
        orchestrator="langgraph",
    )

    # Before entering context
    assert get_current_context() is None

    with ctx:
        current = get_current_context()
        assert current is not None
        assert current.agent_id == "test-agent"
        assert current.tenant_id == "tenant-1"

    # After exiting context
    assert get_current_context() is None


def test_nested_contexts():
    outer = WatchlightContext(agent_id="outer-agent")
    inner = WatchlightContext(agent_id="inner-agent")

    with outer:
        assert get_current_context().agent_id == "outer-agent"
        with inner:
            assert get_current_context().agent_id == "inner-agent"
        assert get_current_context().agent_id == "outer-agent"

    assert get_current_context() is None


def test_set_node_increments_step():
    ctx = WatchlightContext(agent_id="test-agent")

    ctx.set_node("node_a")
    assert ctx._workflow_node == "node_a"
    assert ctx._step_id == "step-1"
    assert ctx._step_counter == 1

    ctx.set_node("node_b")
    assert ctx._workflow_node == "node_b"
    assert ctx._step_id == "step-2"
    assert ctx._step_counter == 2


def test_build_execution_context():
    ctx = WatchlightContext(
        agent_id="test-agent",
        workflow_id="test-graph",
        run_id="run-123",
        orchestrator="langgraph",
        purpose="test_purpose",
        intent="test_intent",
    )
    ctx.set_node("reason_with_llm")

    exec_ctx = ctx.build_execution_context()

    assert exec_ctx.workflow_id == "test-graph"
    assert exec_ctx.workflow_node == "reason_with_llm"
    assert exec_ctx.run_id == "run-123"
    assert exec_ctx.step_id == "step-1"
    assert exec_ctx.purpose == "test_purpose"
    assert exec_ctx.intent == "test_intent"
    assert exec_ctx.orchestrator == "langgraph"


def test_auto_discovery():
    ctx = WatchlightContext(agent_id="test-agent")

    assert ctx.discovery is not None
    assert ctx.discovery.runtime is not None
    assert ctx.discovery.runtime.startswith("python-")
    assert ctx.discovery.hostname is not None


def test_extra_fields():
    ctx = WatchlightContext(agent_id="test-agent")
    ctx.set_extra("custom_key", "custom_value")

    exec_ctx = ctx.build_execution_context()
    assert hasattr(exec_ctx, "custom_key")
    assert exec_ctx.custom_key == "custom_value"
