# Custom Context Extractors

Watchlight's context extractors translate orchestrator-specific metadata into the canonical WSB `ExecutionContext` fields. This enables Cedar policies that reference workflow nodes, step IDs, and orchestrator identity — regardless of which AI agent framework you use.

## The ContextExtractor Protocol

All extractors implement (or are compatible with) the `ContextExtractor` protocol defined in `wl_secrets_broker.extractors.base`:

```python
from typing import Protocol, runtime_checkable

@runtime_checkable
class ContextExtractor(Protocol):
    def get_orchestrator_name(self) -> str: ...
    def get_workflow_id(self) -> str: ...
    def get_workflow_node(self) -> str: ...
    def get_step_id(self) -> str: ...
    def get_run_id(self) -> str | None: ...
```

### Method Reference

| Method | Returns | Purpose |
|--------|---------|---------|
| `get_orchestrator_name()` | `str` | Framework identifier (e.g., `"langgraph"`, `"crewai"`) |
| `get_workflow_id()` | `str` | Top-level workflow/graph/crew identifier |
| `get_workflow_node()` | `str` | Current node/agent/function within the workflow |
| `get_step_id()` | `str` | Step counter within the current run (e.g., `"step-3"`) |
| `get_run_id()` | `str \| None` | Execution/session/thread identifier |

## Built-In Extractors

### Canonical Field Mappings

| WSB Field | LangGraph | CrewAI | AutoGen | Semantic Kernel |
|-----------|-----------|--------|---------|-----------------|
| `orchestrator` | `"langgraph"` | `"crewai"` | `"autogen"` | `"semantic_kernel"` |
| `workflow_id` | Graph ID | Crew name | Group chat name | Kernel ID |
| `workflow_node` | Node name | Agent role | Agent name | Plugin.Function |
| `run_id` | Thread/run ID | Kickoff ID | Session ID | Execution settings ID |
| `step_id` | Auto-incremented | Auto-incremented | Auto-incremented | Auto-incremented |

### LangGraph

```python
from wl_secrets_broker import WatchlightContext
from wl_secrets_broker.extractors.langgraph import WatchlightLangGraphCallback

ctx = WatchlightContext(agent_id="my-agent-v1", tenant_id="org-123")
callback = WatchlightLangGraphCallback(ctx)

with ctx:
    result = graph.invoke(state, config={"callbacks": [callback]})
```

Hooks into LangChain's `BaseCallbackHandler` — tracks `on_chain_start`, `on_tool_start`, and `on_llm_start`.

### CrewAI

```python
from wl_secrets_broker import WatchlightContext
from wl_secrets_broker.extractors.crewai import WatchlightCrewAICallback

ctx = WatchlightContext(agent_id="research-crew-v1", tenant_id="org-123")
callback = WatchlightCrewAICallback(ctx, crew_name="research-crew")

crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, write_task],
    step_callback=callback.step_callback,
    task_callback=callback.task_callback,
)

with ctx:
    result = crew.kickoff()
    callback.set_kickoff_id(result.id)  # optional
```

Install: `pip install wl-secrets-broker[crewai]`

### AutoGen

```python
from wl_secrets_broker import WatchlightContext
from wl_secrets_broker.extractors.autogen import WatchlightAutoGenHandler

ctx = WatchlightContext(agent_id="dev-team-v1", tenant_id="org-123")
handler = WatchlightAutoGenHandler(ctx, group_chat_name="dev-team")

# AutoGen v0.2: register with each agent
for agent in [researcher, coder, reviewer]:
    handler.register(agent)

with ctx:
    result = manager.initiate_chat(researcher, message="Build the feature")
```

For AutoGen v0.4, call `handler.on_message_received()` and `handler.on_message_sent()` directly.

Install: `pip install wl-secrets-broker[autogen]`

### Semantic Kernel

```python
from wl_secrets_broker import WatchlightContext
from wl_secrets_broker.extractors.semantic_kernel import WatchlightSKFilter

ctx = WatchlightContext(agent_id="sk-assistant-v1", tenant_id="org-123")
sk_filter = WatchlightSKFilter(ctx, kernel_id="my-kernel")

kernel = Kernel()
kernel.add_filter("function_invocation", sk_filter)

with ctx:
    result = await kernel.invoke(my_function, arg1="value")
```

Implements SK's `FunctionInvocationFilter` protocol — called around each function invocation.

Install: `pip install wl-secrets-broker[semantic-kernel]`

## Writing a Custom Extractor

For orchestrators not covered by the built-in extractors, implement a class that updates `WatchlightContext` during execution.

### Example: Custom Pipeline Orchestrator

```python
import logging
from wl_secrets_broker.context import WatchlightContext

logger = logging.getLogger("wl_secrets_broker.extractors.my_pipeline")


class WatchlightPipelineCallback:
    """Custom extractor for a hypothetical pipeline orchestrator."""

    def __init__(
        self,
        context: WatchlightContext,
        pipeline_name: str | None = None,
    ):
        self._context = context
        if pipeline_name:
            self._context.workflow_id = pipeline_name
        if not self._context.orchestrator:
            self._context.orchestrator = "my_pipeline"

    def on_stage_start(self, stage_name: str, stage_config: dict) -> None:
        """Called when a pipeline stage begins."""
        self._context.set_node(stage_name)
        logger.debug(
            "Pipeline stage started: %s (step=%s)",
            stage_name,
            self._context._step_id,
        )

        # Store stage-specific metadata as extra context
        if "tool" in stage_config:
            self._context.set_extra("current_tool", stage_config["tool"])

    def set_execution_id(self, execution_id: str) -> None:
        """Set the run_id from the pipeline's execution handle."""
        self._context.run_id = execution_id
```

### Usage

```python
ctx = WatchlightContext(agent_id="pipeline-agent-v1", tenant_id="org-123")
callback = WatchlightPipelineCallback(ctx, pipeline_name="data-etl")

with ctx:
    for stage in pipeline.stages:
        callback.on_stage_start(stage.name, stage.config)
        stage.execute()
    callback.set_execution_id(pipeline.execution_id)
```

### Key Implementation Rules

1. **Always call `context.set_node(name)`** — this increments the step counter and sets both `_workflow_node` and `_step_id`.
2. **Set `workflow_id` in `__init__`** — the top-level workflow identifier should be set once, early.
3. **Set `orchestrator` in `__init__`** — use a stable string identifier for your framework.
4. **Use `set_extra()` for framework-specific metadata** — tool names, plugin names, etc. go here.
5. **Set `run_id` when available** — this ties the execution to a specific invocation for audit purposes.
6. **No optional dependencies at import time** — use try/except or lazy imports if your extractor needs a framework-specific base class.

## Testing Custom Extractors

Use `SimpleNamespace` to mock orchestrator objects without importing the framework:

```python
from types import SimpleNamespace
from wl_secrets_broker.context import WatchlightContext
from my_extractors import WatchlightPipelineCallback


def test_stage_updates_node():
    ctx = WatchlightContext(agent_id="test-agent")
    callback = WatchlightPipelineCallback(ctx, pipeline_name="test-pipe")

    callback.on_stage_start("extract", {"tool": "sql_query"})

    assert ctx._workflow_node == "extract"
    assert ctx._step_counter == 1
    assert ctx._step_id == "step-1"
    assert ctx.workflow_id == "test-pipe"
    assert ctx.orchestrator == "my_pipeline"
    assert ctx._extra.get("current_tool") == "sql_query"


def test_context_builds_correctly():
    ctx = WatchlightContext(agent_id="test-agent", tenant_id="t-1")
    callback = WatchlightPipelineCallback(ctx, pipeline_name="etl")

    callback.on_stage_start("transform", {})
    callback.set_execution_id("exec-001")

    exec_ctx = ctx.build_execution_context()
    assert exec_ctx.orchestrator == "my_pipeline"
    assert exec_ctx.workflow_id == "etl"
    assert exec_ctx.workflow_node == "transform"
    assert exec_ctx.run_id == "exec-001"
    assert exec_ctx.step_id == "step-1"
```

## How Context Flows to Cedar Policies

When your extractor updates `WatchlightContext`, those fields flow into SCT requests:

```
Extractor sets context → WatchlightClient.get_secret() →
  ctx.build_execution_context() → CapabilityRequest.execution_context →
    WSB → APDP Cedar evaluation
```

This enables Cedar policies like:

```cedar
permit(
    principal == Agent::"research-crew-v1",
    action == Action::"use_secret",
    resource == Secret::"openai-api-key"
) when {
    context.execution_context.orchestrator == "crewai" &&
    context.execution_context.workflow_node == "senior_researcher"
};
```
