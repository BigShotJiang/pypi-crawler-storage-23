"""Watchlight Secrets Broker client — request and redeem SCTs.

Conformant to WSB API surface:
  POST /v1/capabilities/request  — request an SCT
  POST /v1/capabilities/redeem   — redeem an SCT for a secret
  GET  /health                   — health check
"""

from __future__ import annotations

import logging

import httpx

from wl_secrets_broker.context import WatchlightContext, get_current_context
from wl_secrets_broker.errors import (
    AuthorizationDenied,
    InvalidRequest,
    RateLimited,
    SctRedeemFailed,
    WatchlightError,
    WsbUnreachable,
)
from wl_secrets_broker.models import (
    CapabilityRequest,
    CapabilityResponse,
    RedeemRequest,
    RedeemResponse,
)

logger = logging.getLogger("wl_secrets_broker.client")


class WatchlightClient:
    """Client for the Watchlight Secrets Broker API.

    Usage:
        client = WatchlightClient(
            endpoint="http://localhost:8082",
            agent_id="conflict-resolver-v1",
            tenant_id="family-123",
        )

        # Get a secret (request SCT + redeem in one call)
        secret = await client.get_secret(
            tool="openai.chat.completions",
            secret_ref="openai/api-key",
        )
    """

    def __init__(
        self,
        endpoint: str,
        agent_id: str,
        tenant_id: str | None = None,
        owner_user_id: str | None = None,
        timeout: float = 10.0,
    ):
        self._endpoint = endpoint.rstrip("/")
        self._agent_id = agent_id
        self._tenant_id = tenant_id
        self._owner_user_id = owner_user_id
        self._client = httpx.AsyncClient(
            base_url=self._endpoint,
            timeout=timeout,
        )

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def get_secret(
        self,
        tool: str,
        secret_ref: str,
        resource: str | None = None,
        context: WatchlightContext | None = None,
    ) -> str:
        """Request an SCT and immediately redeem it to get the secret.

        This is the primary SDK flow: request + redeem in one call.
        The secret is returned as a string; the caller should use it
        immediately and discard it.

        Args:
            tool: Tool identifier (e.g., "openai.chat.completions")
            secret_ref: Secret reference (e.g., "openai/api-key")
            resource: Optional resource (e.g., "model:gpt-4o")
            context: Optional WatchlightContext; uses current context if not provided.

        Returns:
            The secret value as a string.
        """
        sct_response = await self.request_capability(tool, secret_ref, resource, context)
        logger.debug(
            "SCT issued (ttl=%ds, decision=%s), redeeming",
            sct_response.ttl,
            sct_response.decision_id,
        )
        redeem_response = await self.redeem_capability(sct_response.sct)
        return redeem_response.secret

    async def request_capability(
        self,
        tool: str,
        secret_ref: str,
        resource: str | None = None,
        context: WatchlightContext | None = None,
    ) -> CapabilityResponse:
        """Request an SCT from WSB.

        Constructs a CapabilityRequest using the current execution context
        and sends it to WSB, which authorizes via WL-APDP and issues an SCT.
        """
        ctx = context or get_current_context()

        request = CapabilityRequest(
            agent_id=self._agent_id,
            tenant_id=self._tenant_id,
            owner_user_id=self._owner_user_id,
            tool=tool,
            resource=resource,
            secret_ref=secret_ref,
            context=ctx.build_execution_context() if ctx else {},
            discovery=ctx.discovery if ctx else None,
        )

        try:
            resp = await self._client.post(
                "/v1/capabilities/request",
                json=request.model_dump(exclude_none=True),
            )
        except httpx.ConnectError as e:
            raise WsbUnreachable(f"Cannot connect to WSB at {self._endpoint}: {e}") from e

        self._check_response(resp, "capability request")
        return CapabilityResponse.model_validate(resp.json())

    async def redeem_capability(self, sct: str) -> RedeemResponse:
        """Redeem an SCT to obtain the secret value.

        The returned secret has constraints (TTL, allowed hosts, scrub policy).
        """
        request = RedeemRequest(sct=sct)

        try:
            resp = await self._client.post(
                "/v1/capabilities/redeem",
                json=request.model_dump(),
            )
        except httpx.ConnectError as e:
            raise WsbUnreachable(f"Cannot connect to WSB at {self._endpoint}: {e}") from e

        self._check_response(resp, "capability redeem")
        return RedeemResponse.model_validate(resp.json())

    async def health_check(self) -> bool:
        """Check if WSB is reachable and healthy."""
        try:
            resp = await self._client.get("/health")
            return resp.status_code == 200
        except httpx.HTTPError:
            return False

    def _check_response(self, resp: httpx.Response, operation: str) -> None:
        """Map WSB HTTP error responses to typed SDK exceptions."""
        if resp.is_success:
            return

        try:
            body = resp.json()
            code = body.get("error", {}).get("code", "UNKNOWN")
            message = body.get("error", {}).get("message", resp.text)
        except Exception:
            code = "UNKNOWN"
            message = resp.text

        if resp.status_code == 403:
            raise AuthorizationDenied(
                f"Authorization denied for {operation}: {message}",
                decision_id=body.get("error", {}).get("decision_id"),
            )
        elif resp.status_code == 400:
            raise InvalidRequest(f"Invalid {operation}: {message}")
        elif resp.status_code == 429:
            raise RateLimited(f"Rate limited on {operation}: {message}")
        elif resp.status_code == 502:
            raise WsbUnreachable(f"WSB upstream error on {operation}: {message}")
        elif resp.status_code in (409, 410):
            raise SctRedeemFailed(f"SCT redeem failed: {message}")
        else:
            raise WatchlightError(
                f"WSB error on {operation} (HTTP {resp.status_code}): {message}",
                code=code,
            )
