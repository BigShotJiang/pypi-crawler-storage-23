"""Secure tool wrapper — acquires secret capabilities before tool execution.

Provides two patterns:

1. SecureToolWrapper — wraps an httpx call with automatic SCT acquisition:
       wrapper = SecureToolWrapper(client, tool="openai.chat.completions", secret_ref="openai/api-key")
       secret = await wrapper.get_secret()

2. @secure_tool decorator — for LangGraph/LangChain tool functions:
       @secure_tool(tool="openai.chat.completions", secret_ref="openai/api-key")
       async def call_openai(query: str, *, secret: str) -> str:
           ...
"""

from __future__ import annotations

import functools
import logging
from typing import Any, Callable

from wl_secrets_broker.client import WatchlightClient
from wl_secrets_broker.context import WatchlightContext, get_current_context

logger = logging.getLogger("wl_secrets_broker.secure_tool")


class SecureToolWrapper:
    """Wraps a tool call with SCT-based secret acquisition.

    Usage:
        wrapper = SecureToolWrapper(
            client=wl_client,
            tool="openai.chat.completions",
            secret_ref="openai/api-key",
            resource="model:gpt-4o",
        )
        secret = await wrapper.get_secret()
        # Use secret immediately, then discard
    """

    def __init__(
        self,
        client: WatchlightClient,
        tool: str,
        secret_ref: str,
        resource: str | None = None,
    ):
        self._client = client
        self._tool = tool
        self._secret_ref = secret_ref
        self._resource = resource

    async def get_secret(self, context: WatchlightContext | None = None) -> str:
        """Acquire a secret via SCT request+redeem."""
        ctx = context or get_current_context()
        return await self._client.get_secret(
            tool=self._tool,
            secret_ref=self._secret_ref,
            resource=self._resource,
            context=ctx,
        )


def secure_tool(
    tool: str,
    secret_ref: str,
    resource: str | None = None,
    client_attr: str = "_wl_client",
) -> Callable:
    """Decorator that injects a secret into a tool function via SCT.

    The decorated function receives the secret as a keyword argument `secret`.
    The WatchlightClient is resolved from the current context or from `self.<client_attr>`.

    Usage with plain async function:
        @secure_tool(tool="openai.chat.completions", secret_ref="openai/api-key")
        async def call_openai(query: str, *, secret: str) -> str:
            headers = {"Authorization": f"Bearer {secret}"}
            ...

    Usage with class method:
        class MyAgent:
            def __init__(self, wl_client):
                self._wl_client = wl_client

            @secure_tool(tool="openai.chat.completions", secret_ref="openai/api-key")
            async def call_openai(self, query: str, *, secret: str) -> str:
                ...
    """

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Resolve the WatchlightClient
            client: WatchlightClient | None = None

            # Check if it's a method (first arg is self)
            if args and hasattr(args[0], client_attr):
                client = getattr(args[0], client_attr)

            # Fallback: check kwargs
            if client is None:
                client = kwargs.pop("wl_client", None)

            if client is None:
                raise RuntimeError(
                    f"No WatchlightClient found. Provide it via self.{client_attr} "
                    "or pass wl_client=<client> as a keyword argument."
                )

            logger.debug(
                "Acquiring secret for tool=%s secret_ref=%s",
                tool,
                secret_ref,
            )
            secret = await client.get_secret(
                tool=tool,
                secret_ref=secret_ref,
                resource=resource,
            )

            kwargs["secret"] = secret
            return await func(*args, **kwargs)

        return wrapper

    return decorator
