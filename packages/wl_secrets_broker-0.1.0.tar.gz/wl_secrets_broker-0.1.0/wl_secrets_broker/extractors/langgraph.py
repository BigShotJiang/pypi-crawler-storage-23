"""LangGraph context extractor — auto-extracts graph execution metadata.

Provides a LangGraph callback handler that automatically updates the
WatchlightContext as the graph executes, tracking:
- Current node name (workflow_node)
- Step counter (step_id)
- Graph ID (workflow_id)
- Thread ID (run_id)

Usage:
    from wl_secrets_broker import WatchlightContext
    from wl_secrets_broker.extractors.langgraph import WatchlightLangGraphCallback

    ctx = WatchlightContext(
        agent_id="conflict-resolver-v1",
        tenant_id="family-123",
        orchestrator="langgraph",
    )

    callback = WatchlightLangGraphCallback(ctx)

    with ctx:
        result = graph.invoke(
            initial_state,
            config={"callbacks": [callback]},
        )
"""

from __future__ import annotations

import logging
from typing import Any
from uuid import UUID

from wl_secrets_broker.context import WatchlightContext

logger = logging.getLogger("wl_secrets_broker.extractors.langgraph")

try:
    from langchain_core.callbacks import BaseCallbackHandler
except ImportError:
    # LangGraph not installed — provide a stub
    class BaseCallbackHandler:  # type: ignore[no-redef]
        """Stub when langchain-core is not installed."""
        pass


class WatchlightLangGraphCallback(BaseCallbackHandler):
    """LangGraph callback handler that updates WatchlightContext per node.

    Automatically tracks which LangGraph node is executing and updates
    the WatchlightContext so that SCT requests include accurate
    workflow_node and step_id fields.

    This is the richest integration path — SCTs are scoped to
    individual graph nodes, enabling fine-grained Cedar policies like:
        "Allow openai.chat.completions only in the reason_with_llm node"
    """

    def __init__(self, context: WatchlightContext):
        super().__init__()
        self._context = context

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when a LangGraph node starts execution."""
        node_name = _extract_node_name(serialized, tags, metadata)
        if node_name:
            self._context.set_node(node_name)
            logger.debug(
                "LangGraph node started: %s (step=%s)",
                node_name,
                self._context._step_id,
            )

        # Extract graph-level metadata on the first call
        if self._context.workflow_id is None:
            graph_id = _extract_graph_id(serialized, metadata)
            if graph_id:
                self._context.workflow_id = graph_id

        # Track run_id from LangGraph
        if self._context.run_id is None:
            self._context.run_id = str(run_id)

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when a LangGraph node finishes."""
        logger.debug("LangGraph node completed (run=%s)", run_id)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when a LangGraph node errors."""
        logger.warning(
            "LangGraph node error (run=%s): %s",
            run_id,
            error,
        )

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when a LangChain tool starts (within a node)."""
        tool_name = serialized.get("name", "unknown_tool")
        logger.debug("LangGraph tool started: %s", tool_name)
        self._context.set_extra("current_tool", tool_name)

    def on_tool_end(
        self,
        output: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when a LangChain tool finishes."""
        logger.debug("LangGraph tool completed (run=%s)", run_id)

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM call starts (within a node)."""
        model_name = serialized.get("kwargs", {}).get("model_name", "unknown")
        logger.debug("LangGraph LLM call started: model=%s", model_name)
        self._context.set_extra("llm_model", model_name)


def _extract_node_name(
    serialized: dict[str, Any],
    tags: list[str] | None,
    metadata: dict[str, Any] | None,
) -> str | None:
    """Extract the node name from LangGraph callback data."""
    # LangGraph passes node name in tags as "graph:node:<name>"
    if tags:
        for tag in tags:
            if tag.startswith("graph:node:"):
                return tag.split(":", 2)[2]

    # Also check metadata
    if metadata:
        node = metadata.get("langgraph_node")
        if node:
            return node

    # Fallback to serialized name
    name = serialized.get("name")
    if name and name not in ("RunnableSequence", "RunnableLambda"):
        return name

    return None


def _extract_graph_id(
    serialized: dict[str, Any],
    metadata: dict[str, Any] | None,
) -> str | None:
    """Extract the graph ID from LangGraph callback data."""
    if metadata:
        graph_id = metadata.get("langgraph_graph_id")
        if graph_id:
            return graph_id

    # Fallback: use the top-level chain name
    name = serialized.get("name")
    if name and "Graph" in name:
        return name

    return None
