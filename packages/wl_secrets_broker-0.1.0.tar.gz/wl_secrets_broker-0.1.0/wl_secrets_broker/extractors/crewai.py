"""CrewAI context extractor — auto-extracts crew execution metadata.

Provides a callback wrapper that updates WatchlightContext as CrewAI
tasks and steps execute, tracking:
- Crew name (workflow_id)
- Agent role (workflow_node)
- Kickoff ID (run_id)
- Step counter (step_id)

Usage:
    from wl_secrets_broker import WatchlightContext
    from wl_secrets_broker.extractors.crewai import WatchlightCrewAICallback

    ctx = WatchlightContext(
        agent_id="research-crew-v1",
        tenant_id="org-123",
        orchestrator="crewai",
    )

    callback = WatchlightCrewAICallback(ctx)

    crew = Crew(
        agents=[researcher, writer],
        tasks=[research_task, write_task],
        step_callback=callback.step_callback,
        task_callback=callback.task_callback,
    )

    with ctx:
        result = crew.kickoff()
"""

from __future__ import annotations

import logging
from typing import Any

from wl_secrets_broker.context import WatchlightContext

logger = logging.getLogger("wl_secrets_broker.extractors.crewai")


class WatchlightCrewAICallback:
    """CrewAI callback handler that updates WatchlightContext per task/step.

    Pass `step_callback=callback.step_callback` and
    `task_callback=callback.task_callback` to the CrewAI Crew constructor.

    Automatically maps CrewAI concepts to WSB canonical context:
    - workflow_id = crew name
    - workflow_node = agent role
    - run_id = kickoff ID
    - orchestrator = "crewai"
    """

    def __init__(self, context: WatchlightContext, crew_name: str | None = None):
        self._context = context
        if crew_name:
            self._context.workflow_id = crew_name
        if not self._context.orchestrator:
            self._context.orchestrator = "crewai"

    def task_callback(self, task_output: Any) -> None:
        """Called when a CrewAI task completes.

        CrewAI's task_output typically has:
        - task_output.description or task_output.task.description
        - task_output.agent (the agent role)
        - task_output.raw (raw output text)
        """
        agent_role = _extract_agent_role(task_output)
        if agent_role:
            self._context.set_node(agent_role)
            logger.debug(
                "CrewAI task completed: agent=%s (step=%s)",
                agent_role,
                self._context._step_id,
            )

        task_desc = _extract_task_description(task_output)
        if task_desc:
            self._context.set_extra("crewai_task", task_desc)

    def step_callback(self, step_output: Any) -> None:
        """Called after each agent step within a task.

        CrewAI's step_output typically has:
        - step_output.agent (agent role performing the step)
        - step_output.tool (tool name, if tool use)
        - step_output.tool_input (tool input, if tool use)
        - step_output.output (step result text)
        """
        agent_role = _extract_step_agent(step_output)
        if agent_role:
            self._context.set_node(agent_role)

        tool_name = _extract_step_tool(step_output)
        if tool_name:
            self._context.set_extra("current_tool", tool_name)
            logger.debug(
                "CrewAI step: agent=%s, tool=%s (step=%s)",
                agent_role or "unknown",
                tool_name,
                self._context._step_id,
            )

    def set_kickoff_id(self, kickoff_id: str) -> None:
        """Set the run_id from CrewAI's kickoff return value."""
        self._context.run_id = kickoff_id


def _extract_agent_role(task_output: Any) -> str | None:
    """Extract agent role from CrewAI task output."""
    # CrewAI TaskOutput has .agent attribute (str)
    if hasattr(task_output, "agent"):
        agent = task_output.agent
        if isinstance(agent, str):
            return agent
        # Could be an Agent object with .role
        if hasattr(agent, "role"):
            return agent.role
    return None


def _extract_task_description(task_output: Any) -> str | None:
    """Extract task description from CrewAI task output."""
    if hasattr(task_output, "description"):
        return task_output.description
    if hasattr(task_output, "task") and hasattr(task_output.task, "description"):
        return task_output.task.description
    return None


def _extract_step_agent(step_output: Any) -> str | None:
    """Extract agent role from CrewAI step output."""
    if hasattr(step_output, "agent"):
        agent = step_output.agent
        if isinstance(agent, str):
            return agent
        if hasattr(agent, "role"):
            return agent.role
    return None


def _extract_step_tool(step_output: Any) -> str | None:
    """Extract tool name from CrewAI step output."""
    if hasattr(step_output, "tool"):
        return step_output.tool
    return None
