"""AutoGen context extractor — auto-extracts agent execution metadata.

Provides a message handler/reply hook that updates WatchlightContext
as AutoGen agents exchange messages, tracking:
- Group chat name (workflow_id)
- Agent name (workflow_node)
- Session ID (run_id)
- Step counter (step_id)

Usage with AutoGen v0.4:
    from wl_secrets_broker import WatchlightContext
    from wl_secrets_broker.extractors.autogen import WatchlightAutoGenHandler

    ctx = WatchlightContext(
        agent_id="research-team-v1",
        tenant_id="org-123",
        orchestrator="autogen",
    )

    handler = WatchlightAutoGenHandler(ctx, group_chat_name="research-team")

    # Register with each agent
    for agent in [researcher, coder, reviewer]:
        handler.register(agent)

    with ctx:
        chat_result = manager.initiate_chat(researcher, message="...")
"""

from __future__ import annotations

import logging
from typing import Any

from wl_secrets_broker.context import WatchlightContext

logger = logging.getLogger("wl_secrets_broker.extractors.autogen")


class WatchlightAutoGenHandler:
    """AutoGen message handler that updates WatchlightContext per message.

    Automatically maps AutoGen concepts to WSB canonical context:
    - workflow_id = group chat name
    - workflow_node = agent name (sender)
    - run_id = session ID
    - orchestrator = "autogen"

    Compatible with both AutoGen v0.2 (register_reply) and v0.4 APIs.
    """

    def __init__(
        self,
        context: WatchlightContext,
        group_chat_name: str | None = None,
        session_id: str | None = None,
    ):
        self._context = context
        if group_chat_name:
            self._context.workflow_id = group_chat_name
        if session_id:
            self._context.run_id = session_id
        if not self._context.orchestrator:
            self._context.orchestrator = "autogen"

    def register(self, agent: Any) -> None:
        """Register this handler with an AutoGen agent.

        Works with AutoGen v0.2's register_reply API.
        For v0.4, use the handler methods directly.
        """
        if hasattr(agent, "register_reply"):
            # AutoGen v0.2: register as a reply function
            agent.register_reply(
                trigger=None,  # Trigger on all messages
                reply_func=self._reply_hook,
                position=0,  # Run before other reply functions
            )
            logger.debug("Registered Watchlight handler with agent: %s", _agent_name(agent))

    def on_message_received(
        self,
        sender: Any,
        message: dict[str, Any] | str,
        **kwargs: Any,
    ) -> None:
        """Call this when an agent receives a message (v0.4 API).

        Updates the context with the sender's agent name.
        """
        agent_name = _agent_name(sender)
        if agent_name:
            self._context.set_node(agent_name)
            logger.debug(
                "AutoGen message received from: %s (step=%s)",
                agent_name,
                self._context._step_id,
            )

        # Extract tool use from message content
        tool_name = _extract_tool_name(message)
        if tool_name:
            self._context.set_extra("current_tool", tool_name)

    def on_message_sent(
        self,
        sender: Any,
        receiver: Any,
        message: dict[str, Any] | str,
        **kwargs: Any,
    ) -> None:
        """Call this when an agent sends a message (v0.4 API)."""
        sender_name = _agent_name(sender)
        receiver_name = _agent_name(receiver)
        logger.debug(
            "AutoGen message: %s → %s (step=%s)",
            sender_name or "unknown",
            receiver_name or "unknown",
            self._context._step_id,
        )

    def _reply_hook(
        self,
        recipient: Any,
        messages: list[dict[str, Any]] | None = None,
        sender: Any = None,
        config: Any = None,
    ) -> tuple[bool, Any]:
        """AutoGen v0.2 reply hook — called before the agent generates a reply.

        Returns (False, None) to not intercept the reply, just observe.
        """
        agent_name = _agent_name(sender) if sender else None
        if agent_name:
            self._context.set_node(agent_name)

        if messages:
            last_msg = messages[-1]
            tool_name = _extract_tool_name(last_msg)
            if tool_name:
                self._context.set_extra("current_tool", tool_name)

        # Don't intercept — return False to let the agent generate its reply
        return False, None


def _agent_name(agent: Any) -> str | None:
    """Extract agent name from an AutoGen agent object."""
    if agent is None:
        return None
    if isinstance(agent, str):
        return agent
    if hasattr(agent, "name"):
        return agent.name
    return None


def _extract_tool_name(message: dict[str, Any] | str | Any) -> str | None:
    """Extract tool name from an AutoGen message."""
    if isinstance(message, dict):
        # AutoGen v0.2 function call format
        if "function_call" in message:
            return message["function_call"].get("name")
        # AutoGen v0.4 tool call format
        if "tool_calls" in message:
            calls = message["tool_calls"]
            if calls and isinstance(calls, list):
                first = calls[0]
                if isinstance(first, dict) and "function" in first:
                    return first["function"].get("name")
    return None
