"""Context extractors for orchestrator-specific metadata.

Each extractor translates an orchestrator's native concepts into the
canonical WSB ExecutionContext fields (workflow_id, workflow_node, etc.).

Available extractors:
- ContextExtractor: Base protocol for custom extractors
- WatchlightLangGraphCallback: LangGraph callback handler
- WatchlightCrewAICallback: CrewAI task/step callback
- WatchlightAutoGenHandler: AutoGen message handler
- WatchlightSKFilter: Semantic Kernel function invocation filter
"""

from wl_secrets_broker.extractors.base import ContextExtractor

__all__ = [
    "ContextExtractor",
    "WatchlightLangGraphCallback",
    "WatchlightCrewAICallback",
    "WatchlightAutoGenHandler",
    "WatchlightSKFilter",
]


def __getattr__(name: str):
    """Lazy-import extractors to avoid requiring optional dependencies."""
    if name == "WatchlightLangGraphCallback":
        from wl_secrets_broker.extractors.langgraph import WatchlightLangGraphCallback
        return WatchlightLangGraphCallback
    if name == "WatchlightCrewAICallback":
        from wl_secrets_broker.extractors.crewai import WatchlightCrewAICallback
        return WatchlightCrewAICallback
    if name == "WatchlightAutoGenHandler":
        from wl_secrets_broker.extractors.autogen import WatchlightAutoGenHandler
        return WatchlightAutoGenHandler
    if name == "WatchlightSKFilter":
        from wl_secrets_broker.extractors.semantic_kernel import WatchlightSKFilter
        return WatchlightSKFilter
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
