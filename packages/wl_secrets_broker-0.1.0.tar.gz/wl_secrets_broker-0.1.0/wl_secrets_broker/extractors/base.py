"""Base ContextExtractor protocol — implement for any custom orchestrator.

The ContextExtractor protocol defines the interface for extracting
orchestrator-specific metadata and mapping it to WSB canonical context.

Implementations:
- LangGraphExtractor (wl_secrets_broker.extractors.langgraph)
- CrewAIExtractor (Phase 3)
- AutoGenExtractor (Phase 3)
- SemanticKernelExtractor (Phase 3)
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class ContextExtractor(Protocol):
    """Protocol for extracting orchestrator-specific execution context.

    Implement this for any custom orchestrator to enable
    step-level SCT scoping in Cedar policies.

    Example for a custom orchestrator:
        class MyOrchestratorExtractor:
            def get_orchestrator_name(self) -> str:
                return "my_orchestrator"

            def get_workflow_id(self) -> str:
                return self._current_pipeline.id

            def get_workflow_node(self) -> str:
                return self._current_step.name

            def get_step_id(self) -> str:
                return f"step-{self._current_step.index}"

            def get_run_id(self) -> str | None:
                return self._current_execution.run_id
    """

    def get_orchestrator_name(self) -> str:
        """Return the orchestrator identifier (e.g., "langgraph", "crewai")."""
        ...

    def get_workflow_id(self) -> str:
        """Return the current workflow/graph/pipeline identifier."""
        ...

    def get_workflow_node(self) -> str:
        """Return the current node/step/stage name."""
        ...

    def get_step_id(self) -> str:
        """Return the current step identifier within the run."""
        ...

    def get_run_id(self) -> str | None:
        """Return the current run/session/thread identifier."""
        ...
