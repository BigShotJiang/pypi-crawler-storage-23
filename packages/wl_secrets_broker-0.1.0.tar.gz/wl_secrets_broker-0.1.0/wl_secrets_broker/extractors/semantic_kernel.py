"""Semantic Kernel context extractor — auto-extracts plugin/function metadata.

Provides a FunctionInvocationFilter that updates WatchlightContext as
Semantic Kernel functions execute, tracking:
- Kernel ID (workflow_id)
- Plugin.Function name (workflow_node)
- Execution ID (run_id)
- Step counter (step_id)

Usage:
    from wl_secrets_broker import WatchlightContext
    from wl_secrets_broker.extractors.semantic_kernel import WatchlightSKFilter

    ctx = WatchlightContext(
        agent_id="sk-assistant-v1",
        tenant_id="org-123",
        orchestrator="semantic_kernel",
    )

    sk_filter = WatchlightSKFilter(ctx)

    kernel = Kernel()
    kernel.add_filter("function_invocation", sk_filter)

    with ctx:
        result = await kernel.invoke(my_function, arg1="value")
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Awaitable

from wl_secrets_broker.context import WatchlightContext

logger = logging.getLogger("wl_secrets_broker.extractors.semantic_kernel")


class WatchlightSKFilter:
    """Semantic Kernel FunctionInvocationFilter that updates WatchlightContext.

    Automatically maps Semantic Kernel concepts to WSB canonical context:
    - workflow_id = kernel ID
    - workflow_node = "plugin_name.function_name"
    - run_id = execution settings ID
    - orchestrator = "semantic_kernel"

    Implements the SK FunctionInvocationFilter protocol:
    async def on_function_invocation(context, next) -> None
    """

    def __init__(
        self,
        context: WatchlightContext,
        kernel_id: str | None = None,
    ):
        self._context = context
        if kernel_id:
            self._context.workflow_id = kernel_id
        if not self._context.orchestrator:
            self._context.orchestrator = "semantic_kernel"

    async def on_function_invocation(
        self,
        context: Any,
        next: Callable[..., Awaitable[None]],
    ) -> None:
        """Called around each Semantic Kernel function invocation.

        The `context` parameter is SK's FunctionInvocationContext with:
        - context.function.plugin_name
        - context.function.name
        - context.function.fully_qualified_name
        - context.kernel (the kernel instance)
        - context.arguments
        - context.result (set after next() returns)
        """
        # Extract function identity
        function_node = _extract_function_node(context)
        if function_node:
            self._context.set_node(function_node)
            logger.debug(
                "SK function invocation: %s (step=%s)",
                function_node,
                self._context._step_id,
            )

        # Extract kernel ID if not set
        if self._context.workflow_id is None:
            kernel_id = _extract_kernel_id(context)
            if kernel_id:
                self._context.workflow_id = kernel_id

        # Extract execution ID for run_id
        execution_id = _extract_execution_id(context)
        if execution_id:
            self._context.run_id = execution_id

        # Store plugin name as extra context
        plugin_name = _extract_plugin_name(context)
        if plugin_name:
            self._context.set_extra("sk_plugin", plugin_name)

        # Invoke the next filter/function in the pipeline
        await next(context)

        logger.debug(
            "SK function completed: %s (step=%s)",
            function_node or "unknown",
            self._context._step_id,
        )


def _extract_function_node(context: Any) -> str | None:
    """Extract the function node name from SK context."""
    if hasattr(context, "function"):
        fn = context.function
        plugin = getattr(fn, "plugin_name", None) or ""
        name = getattr(fn, "name", None) or ""
        if plugin and name:
            return f"{plugin}.{name}"
        if name:
            return name
        # Try fully_qualified_name
        fqn = getattr(fn, "fully_qualified_name", None)
        if fqn:
            return fqn
    return None


def _extract_kernel_id(context: Any) -> str | None:
    """Extract the kernel ID from SK context."""
    if hasattr(context, "kernel"):
        kernel = context.kernel
        # SK Kernel may have an id or service_id
        kernel_id = getattr(kernel, "id", None)
        if kernel_id:
            return str(kernel_id)
    return None


def _extract_execution_id(context: Any) -> str | None:
    """Extract the execution ID from SK context."""
    if hasattr(context, "arguments"):
        args = context.arguments
        # SK may pass execution settings with an ID
        exec_settings = getattr(args, "execution_settings", None)
        if exec_settings:
            exec_id = getattr(exec_settings, "service_id", None)
            if exec_id:
                return str(exec_id)
    return None


def _extract_plugin_name(context: Any) -> str | None:
    """Extract the plugin name from SK context."""
    if hasattr(context, "function"):
        return getattr(context.function, "plugin_name", None)
    return None
