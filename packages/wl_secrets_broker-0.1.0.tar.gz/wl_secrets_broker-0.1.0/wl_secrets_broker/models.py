"""Pydantic models conformant to WSB Rust service types.

These models mirror the Rust structs in wl-secrets-broker/src/models.rs
to ensure wire-format compatibility.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field


class ExecutionContext(BaseModel):
    """Orchestrator-agnostic execution context.

    Canonical fields map to any orchestrator's native concepts:
    - LangGraph: workflow_id=graph_id, workflow_node=node_name, run_id=thread_id
    - CrewAI:    workflow_id=crew_id, workflow_node=agent_role, run_id=task_id
    - AutoGen:   workflow_id=group_chat_id, workflow_node=agent_name, run_id=session_id
    - Custom:    user-defined mapping via ContextExtractor
    """

    workflow_id: str | None = None
    workflow_node: str | None = None
    run_id: str | None = None
    step_id: str | None = None
    purpose: str | None = None
    intent: str | None = None
    orchestrator: str | None = None

    model_config = {"extra": "allow"}


class DiscoveryMetadata(BaseModel):
    """Auto-discovery metadata sent with capability requests.

    Enables WSB to auto-register unknown agents in WL-APDP.
    """

    orchestrator: str | None = None
    orchestrator_version: str | None = None
    runtime: str | None = None
    hostname: str | None = None
    container_id: str | None = None
    workload_identity: str | None = None
    tools_declared: list[str] = Field(default_factory=list)
    first_seen: datetime | None = None


class CapabilityRequest(BaseModel):
    """Request an SCT from WSB.

    Mirrors Rust CapabilityRequest in src/models.rs.
    """

    agent_id: str
    tenant_id: str | None = None
    owner_user_id: str | None = None
    tool: str
    resource: str | None = None
    secret_ref: str
    context: ExecutionContext = Field(default_factory=ExecutionContext)
    discovery: DiscoveryMetadata | None = None


class CapabilityResponse(BaseModel):
    """SCT issuance response from WSB."""

    sct: str
    ttl: int
    decision_id: str


class RedeemRequest(BaseModel):
    """Redeem an SCT to obtain the secret."""

    sct: str


class SecretConstraints(BaseModel):
    """Constraints on how the redeemed secret may be used."""

    use_within_seconds: int
    allowed_hosts: list[str] = Field(default_factory=list)
    scrub_from_logs: bool = True


class RedeemResponse(BaseModel):
    """Secret materialization response from WSB."""

    secret: str
    constraints: SecretConstraints


class SecretBinding(BaseModel):
    """Binding between a secret reference and authorized tools/agents."""

    id: str | None = None
    agent_id: str | None = None
    secret_ref: str
    tools: list[str] = Field(default_factory=list)
    requires_approval: bool = False
    max_uses_per_run: int | None = None
    injection: SecretInjection | None = None


class SecretInjection(BaseModel):
    """How a secret is injected into outbound requests."""

    type: str = "bearer_token"
    name: str | None = None


class AuditEvent(BaseModel):
    """Audit event from WSB."""

    id: str
    event_type: str
    agent_id: str
    tool: str | None = None
    secret_ref: str | None = None
    decision_id: str | None = None
    tenant_id: str | None = None
    workflow_id: str | None = None
    workflow_node: str | None = None
    orchestrator: str | None = None
    outcome: str
    timestamp: str
    details: dict[str, Any] = Field(default_factory=dict)


class HealthResponse(BaseModel):
    """WSB health check response."""

    status: str
    version: str
    uptime_seconds: int | None = None
