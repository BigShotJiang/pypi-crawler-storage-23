"""Typed error hierarchy for the Watchlight SDK.

Maps to WSB service error codes:
- INVALID_ARGUMENT
- NOT_AUTHORIZED
- NOT_FOUND
- CONFLICT
- RATE_LIMITED
- UPSTREAM_UNAVAILABLE
- INTERNAL_ERROR
"""


class WatchlightError(Exception):
    """Base error for all Watchlight SDK errors."""

    def __init__(self, message: str, code: str = "INTERNAL_ERROR", details: dict | None = None):
        super().__init__(message)
        self.code = code
        self.details = details or {}


class AuthorizationDenied(WatchlightError):
    """SCT request was denied by WL-APDP policy."""

    def __init__(self, message: str, decision_id: str | None = None):
        super().__init__(message, code="NOT_AUTHORIZED")
        self.decision_id = decision_id


class SctExpired(WatchlightError):
    """SCT has expired before redemption."""

    def __init__(self, message: str = "SCT has expired"):
        super().__init__(message, code="SCT_EXPIRED")


class SctRedeemFailed(WatchlightError):
    """SCT redemption failed (already used, invalid, etc.)."""

    def __init__(self, message: str):
        super().__init__(message, code="SCT_REDEEM_FAILED")


class WsbUnreachable(WatchlightError):
    """WSB service is not reachable."""

    def __init__(self, message: str = "WSB service unreachable"):
        super().__init__(message, code="UPSTREAM_UNAVAILABLE")


class InvalidRequest(WatchlightError):
    """Request validation failed."""

    def __init__(self, message: str):
        super().__init__(message, code="INVALID_ARGUMENT")


class SecretNotFound(WatchlightError):
    """Requested secret reference does not exist."""

    def __init__(self, secret_ref: str):
        super().__init__(f"Secret not found: {secret_ref}", code="NOT_FOUND")


class RateLimited(WatchlightError):
    """Request was rate-limited by WSB."""

    def __init__(self, message: str = "Rate limited"):
        super().__init__(message, code="RATE_LIMITED")
