"""Watchlight Secrets Broker Python SDK.

Provides SCT-based secret capability management for AI agents.
Two integration paths:

1. Programmatic (SDK) — richer context for fine-grained Cedar policies:
   from wl_secrets_broker import WatchlightClient, SecureToolWrapper

2. HTTP proxy — zero code changes:
   export HTTPS_PROXY=http://wl-proxy:8080
"""

from wl_secrets_broker.client import WatchlightClient
from wl_secrets_broker.models import (
    CapabilityRequest,
    CapabilityResponse,
    ExecutionContext,
    DiscoveryMetadata,
    RedeemRequest,
    RedeemResponse,
    SecretConstraints,
)
from wl_secrets_broker.context import WatchlightContext
from wl_secrets_broker.errors import (
    WatchlightError,
    AuthorizationDenied,
    SctExpired,
    SctRedeemFailed,
    WsbUnreachable,
)
from wl_secrets_broker.secure_tool import SecureToolWrapper, secure_tool

__version__ = "0.1.0"

__all__ = [
    "WatchlightClient",
    "WatchlightContext",
    "SecureToolWrapper",
    "secure_tool",
    "CapabilityRequest",
    "CapabilityResponse",
    "ExecutionContext",
    "DiscoveryMetadata",
    "RedeemRequest",
    "RedeemResponse",
    "SecretConstraints",
    "WatchlightError",
    "AuthorizationDenied",
    "SctExpired",
    "SctRedeemFailed",
    "WsbUnreachable",
]
