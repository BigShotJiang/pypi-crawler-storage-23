"""Watchlight execution context — thread-safe context propagation.

Uses Python's contextvars to propagate the current execution context
across async boundaries, LangGraph nodes, and tool invocations.
"""

from __future__ import annotations

import os
import platform
import socket
from contextvars import ContextVar
from typing import Any

from wl_secrets_broker.models import DiscoveryMetadata, ExecutionContext

# Thread-local context for the current execution
_current_context: ContextVar[WatchlightContext | None] = ContextVar(
    "wl_secrets_broker_context", default=None
)


def get_current_context() -> WatchlightContext | None:
    """Get the current Watchlight context from the calling thread/task."""
    return _current_context.get()


class WatchlightContext:
    """Manages execution context for a single agent run.

    Usage:
        ctx = WatchlightContext(
            agent_id="conflict-resolver-v1",
            tenant_id="family-123",
            run_id="run-abc",
        )
        with ctx:
            # All code within this block can access the context
            # via get_current_context()
            result = graph.invoke(state)
    """

    def __init__(
        self,
        agent_id: str,
        tenant_id: str | None = None,
        owner_user_id: str | None = None,
        workflow_id: str | None = None,
        run_id: str | None = None,
        orchestrator: str | None = None,
        purpose: str | None = None,
        intent: str | None = None,
        discovery: DiscoveryMetadata | None = None,
    ):
        self.agent_id = agent_id
        self.tenant_id = tenant_id
        self.owner_user_id = owner_user_id
        self.workflow_id = workflow_id
        self.run_id = run_id
        self.orchestrator = orchestrator
        self.purpose = purpose
        self.intent = intent
        self.discovery = discovery or self._auto_discover()

        # Mutable state updated by extractors during execution
        self._workflow_node: str | None = None
        self._step_id: str | None = None
        self._step_counter: int = 0
        self._extra: dict[str, Any] = {}
        self._token = None

    def __enter__(self):
        self._token = _current_context.set(self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._token is not None:
            _current_context.reset(self._token)
            self._token = None
        return False

    def set_node(self, node_name: str) -> None:
        """Update the current workflow node (called by extractors)."""
        self._workflow_node = node_name
        self._step_counter += 1
        self._step_id = f"step-{self._step_counter}"

    def set_step(self, step_id: str) -> None:
        """Explicitly set the step ID."""
        self._step_id = step_id

    def set_extra(self, key: str, value: Any) -> None:
        """Set additional context fields."""
        self._extra[key] = value

    def build_execution_context(self) -> ExecutionContext:
        """Build the canonical ExecutionContext for a WSB capability request."""
        ctx = ExecutionContext(
            workflow_id=self.workflow_id,
            workflow_node=self._workflow_node,
            run_id=self.run_id,
            step_id=self._step_id,
            purpose=self.purpose,
            intent=self.intent,
            orchestrator=self.orchestrator,
        )
        # Merge extra fields
        for k, v in self._extra.items():
            setattr(ctx, k, v)
        return ctx

    @staticmethod
    def _auto_discover() -> DiscoveryMetadata:
        """Collect runtime discovery metadata automatically."""
        return DiscoveryMetadata(
            runtime=f"python-{platform.python_version()}",
            hostname=socket.gethostname(),
            container_id=os.environ.get("HOSTNAME"),
            workload_identity=os.environ.get("SPIFFE_ID"),
        )
