# Setting Up AIperture with Claude Code

This guide walks you through adding AIperture as Claude Code's permission layer via MCP (Model Context Protocol). After setup, Claude Code will check permissions through AIperture before taking actions, and AIperture will learn your preferences over time.

## Prerequisites

- Python 3.12+
- [Claude Code](https://docs.anthropic.com/en/docs/claude-code) installed

## Step 1: Install AIperture

```bash
pip install aiperture
```

Verify it installed:

```bash
aiperture --help
```

## Step 2: Set up AIperture for Claude Code

```bash
aiperture setup-claude --bootstrap=developer
```

This does three things:
1. Creates `.mcp.json` in your project with the AIperture MCP server config
2. Initializes the database (`aiperture.db`)
3. Pre-seeds 75 safe patterns (git, file reads, test runners, linters)

Options:
- `--global` — install to `~/.claude/.mcp.json` (applies to all projects)
- `--bootstrap=readonly` — 48 read-only patterns instead of the full developer set
- No `--bootstrap` — clean slate, learn everything from scratch

If you already have a `.mcp.json`, AIperture is added alongside your existing MCP servers.

<details>
<summary>Manual setup (without setup-claude)</summary>

```bash
aiperture init-db
```

Add to your `.mcp.json` (project root or `~/.claude/`):

```json
{
  "mcpServers": {
    "aiperture": {
      "type": "stdio",
      "command": "aiperture",
      "args": ["mcp-serve"]
    }
  }
}
```

Optionally bootstrap: `aiperture bootstrap developer`

</details>

## Step 3: Start using Claude Code

Restart Claude Code (or open a new session) and AIperture is active.

### What to expect on first use

When you start your first Claude Code session with AIperture:

1. **Claude sees the 14 AIperture tools** — it can call `check_permission`, `approve_action`, `deny_action`, `explain_action`, `get_permission_patterns`, `store_artifact`, `verify_artifact`, `get_cost_summary`, `get_audit_trail`, `get_config`, `report_tool_execution`, `get_compliance_report`, `revoke_permission_pattern`, and `list_auto_approved_patterns`.

2. **Everything starts as denied** — AIperture has no history yet, so the first time Claude tries to read a file or run a command, it will be denied. Claude will ask you to approve it.

3. **You approve the safe stuff** — When Claude says "AIperture denied this, want to approve?", say yes for things like `git status`, `cat README.md`, `npm test`. Say no for anything you wouldn't want an agent doing unsupervised.

4. **AIperture learns your preferences** — After 10 consistent approvals of the same action type (e.g., `filesystem.read`), AIperture auto-approves it going forward. You stop getting asked.

5. **Dangerous actions stay flagged** — `rm -rf`, shell commands with broad wildcards, anything touching system paths — these are scored as HIGH/CRITICAL risk and always require your explicit approval.

This is what it looks like in practice:

| Tool | What it does |
|------|-------------|
| `check_permission` | Check if an action is allowed (with risk assessment and HMAC challenge) |
| `approve_action` | Record a human approval (requires valid challenge token) |
| `deny_action` | Record a human denial (requires valid challenge token) |
| `explain_action` | Get a human-readable explanation of what an action does |
| `get_permission_patterns` | View what AIperture has learned from your decisions |
| `report_tool_execution` | Report that a tool was executed (for compliance tracking) |
| `get_compliance_report` | See which tool executions had prior permission checks |
| `revoke_permission_pattern` | Undo a learned auto-approval pattern |
| `list_auto_approved_patterns` | See all patterns currently being auto-approved |
| `store_artifact` | Store an agent output with SHA-256 verification |
| `verify_artifact` | Verify an artifact's integrity |
| `get_cost_summary` | Get token and cost breakdown |
| `get_audit_trail` | Query the compliance audit trail |
| `get_config` | View current AIperture settings |

## AIperture vs Claude Code's built-in permissions

Claude Code has its own permission system — the "Allow once / Allow for session / Always allow / Deny" popup. That's separate from AIperture. Here's how they relate:

| | Claude Code built-in | AIperture |
|---|---|---|
| **What it controls** | Whether Claude can call a tool at all | Whether the *action* (read this file, run this command) is allowed |
| **Persistence** | Per-session or permanent per-machine | Per-database, shared across sessions, learns over time |
| **Learning** | No — same prompts every new session | Yes — auto-approves after enough consistent human decisions |
| **Audit trail** | No | Yes — every decision logged |
| **Risk scoring** | No | Yes — LOW/MEDIUM/HIGH/CRITICAL per action |

In practice, you'll likely set Claude Code's built-in permissions to "Always allow" for AIperture's MCP tools (since AIperture itself is the permission layer). Then all permission decisions flow through AIperture, which learns and persists them.

**Important:** AIperture only checks permissions for tool calls that access external resources (files, shell, APIs). It does NOT interfere with Claude asking you questions, presenting options, or having a normal conversation. Those happen without involving AIperture at all.

## How the learning loop works

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│  Claude Code                     AIperture                           │
│  ───────────                     ────────                           │
│                                                                     │
│  "I need to run npm test"                                           │
│         │                                                           │
│         ├──── check_permission ────▶  No history for this action.   │
│         │     tool: shell              Decision: DENY               │
│         │     action: execute                                       │
│         │     scope: npm test    ◀──── Return verdict ────┤         │
│         │                                                           │
│  "Permission denied. Approve?"                                      │
│         │                                                           │
│  User:  "Yes"                                                       │
│         │                                                           │
│         ├──── approve_action ─────▶  Recorded. (1 of 10 needed)     │
│         │                                                           │
│         │     ... 9 more approvals over time ...                    │
│         │                                                           │
│         ├──── check_permission ────▶  10/10 approvals at 100%.      │
│         │     tool: shell              Decision: ALLOW              │
│         │     action: execute          Decided by: auto_learned     │
│         │     scope: npm test                                       │
│         │                        ◀──── Return verdict ────┤         │
│         │                                                           │
│  "AIperture auto-approved npm test                                   │
│   based on your previous decisions."                                │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

## Skip the first-session approval flood

By default, AIperture asks about everything on first use. You can pre-seed safe patterns using bootstrap presets:

```bash
aiperture bootstrap developer    # 75 patterns: git, file reads, test runners, linters
aiperture bootstrap readonly     # 48 patterns: file reads and safe shell commands only
aiperture bootstrap minimal      # Clean slate (default behavior)
```

After bootstrapping, common actions like `git status`, `cat README.md`, and `npm test` are auto-approved immediately.

## Revoking learned patterns

If AIperture learned to auto-approve something you no longer want:

```bash
aiperture revoke shell execute "rm*"     # Revoke all rm-related auto-approvals
```

Or use the MCP tool from within Claude Code — ask Claude to call `revoke_permission_pattern`. The pattern immediately requires fresh human decisions. Revoked records are preserved in the audit trail.

## Tuning the learning speed

By default, AIperture needs 10 consistent human decisions at a 95% approval rate before auto-approving. You can adjust this:

**Via environment variables** (in your `.aiperture.env` or shell):

```bash
AIPERTURE_PERMISSION_LEARNING_MIN_DECISIONS=5   # Fewer decisions needed
AIPERTURE_AUTO_APPROVE_THRESHOLD=0.90           # Lower approval rate required
```

**Via the MCP config** (per-project):

```json
{
  "mcpServers": {
    "aiperture": {
      "type": "stdio",
      "command": "aiperture",
      "args": ["mcp-serve"],
      "env": {
        "AIPERTURE_PERMISSION_LEARNING_MIN_DECISIONS": "5",
        "AIPERTURE_AUTO_APPROVE_THRESHOLD": "0.90"
      }
    }
  }
}
```

**Via the interactive wizard:**

```bash
aiperture configure
```

## Security features active by default

AIperture includes several security hardening features that are active out of the box:

- **Rate limiting** — 200 permission checks/minute per session (configurable via `AIPERTURE_RATE_LIMIT_PER_MINUTE`)
- **Session risk scoring** — Cumulative risk budget of 50.0 per session. Many individually-safe actions that compound are escalated to ASK. (configurable via `AIPERTURE_SESSION_RISK_BUDGET`)
- **Sensitive path protection** — Files matching patterns like `*secret*`, `*.env`, `*.pem`, `*.key` skip scope normalization and require exact-match learning
- **Temporal decay** — Auto-learned patterns expire after 90 days without human reconfirmation (configurable via `AIPERTURE_PATTERN_MAX_AGE_DAYS`)
- **Rubber-stamping detection** — Rapid approvals (5+ within 60s) are excluded from the learning engine
- **Hash-chained audit trail** — Every audit event is cryptographically chained for tamper detection
- **HMAC nonce persistence** — Challenge nonces survive server restarts, preventing replay attacks

## Running the API server alongside MCP

The MCP server (stdio) and REST API server can run at the same time. This is useful if you want to query the audit trail or permission patterns from a browser or script while Claude Code is running:

```bash
# In one terminal — API server for querying
aiperture serve

# Claude Code uses MCP (stdio) — no extra terminal needed
```

Query examples:

```bash
# Check database health
curl localhost:8100/health

# What has AIperture learned?
curl localhost:8100/permissions/patterns?min_decisions=5

# Full audit trail
curl localhost:8100/audit/events?limit=50

# Verify audit trail integrity (hash chain)
curl localhost:8100/audit/verify-chain

# Prometheus metrics (for monitoring dashboards)
curl localhost:8100/metrics

# Current config
curl localhost:8100/config
```

### Securing the API server

If the API server is accessible on a network (not just localhost), set a bearer token:

```bash
export AIPERTURE_API_KEY="your-secret-key"
aiperture serve
```

All requests must then include `Authorization: Bearer your-secret-key`. The MCP server is unaffected — it uses stdio transport and doesn't go through the HTTP API.

## Viewing logs

Claude Code spawns `aiperture mcp-serve` automatically, so stderr logs are invisible. To see what AIperture is doing, enable file logging:

```json
{
  "mcpServers": {
    "aiperture": {
      "type": "stdio",
      "command": "aiperture",
      "args": ["mcp-serve"],
      "env": {
        "AIPERTURE_LOG_FILE": "~/.aiperture/aiperture.log"
      }
    }
  }
}
```

Then in a separate terminal:

```bash
tail -f ~/.aiperture/aiperture.log
```

Logs rotate automatically at 5 MB with 3 backups.

## Troubleshooting

**"aiperture: command not found"**

```bash
pip install aiperture
which aiperture   # Should print a path
```

If you're using a virtual environment, make sure it's activated. If you installed globally, make sure your Python scripts directory is on your PATH.

**Permissions aren't being learned**

Check that `AIPERTURE_PERMISSION_LEARNING_ENABLED` is `true` (the default). Also verify decisions are being recorded:

```bash
curl localhost:8100/audit/events?limit=5
```

If the audit trail is empty, the MCP connection may not be working. Check Claude Code's MCP server status.

**Want to start fresh?**

Delete the database and re-initialize:

```bash
rm aiperture.db
aiperture init-db
```

## Next steps

- [Configuration reference](../README.md#configuration) — all environment variables
- [How decisions are made](../README.md#how-decisions-are-made) — the full resolution order
- [REST API examples](../README.md#rest-api) — query permissions, patterns, and audit trail programmatically
