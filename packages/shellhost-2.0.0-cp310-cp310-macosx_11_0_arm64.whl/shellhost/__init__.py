# shellhost __init__.py

from .shellhost_command import Command
from .shellhost import *

__version__ = '2.0.0'
__author__ = 'M. Bragg'

