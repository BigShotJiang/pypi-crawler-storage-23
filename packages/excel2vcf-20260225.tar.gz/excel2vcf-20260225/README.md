# 项目描述

通过excel文件生成vcad文件，实现批量联系人导入功能。
安卓手机已测试通过。

# 使用
```
1.安装 pip install excel2vcf
2.打开 控制台，输入excel2vcf-gui 运行
按格式导入excel文件，点击生成即可下载*.vcf名片。
```
