import sys
import shutil
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTableWidget, QTableWidgetItem, QPushButton, QFileDialog,
    QMessageBox, QListWidget, QLabel, QHeaderView
)
from PyQt5.QtCore import Qt
import datetime
import random
import time
import tempfile

from . import excel2vcf

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.data = []  # 存储加载的数据
        self.raw_data = dict() # 存储原始数据
        self.generated_files = []  # 存储生成的文件名
        self.current_page = 1  # 当前页码
        self.items_per_page = 10  # 每页显示行数
        self.initUI()
        self.temp_dir = tempfile.TemporaryDirectory() # 创建临时目录

    def initUI(self):
        self.setWindowTitle("excel批量生成联系人")
        self.setGeometry(100, 100, 800, 600)

        # 中央部件
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)

        # 预览表格
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["姓名", "单位", "职务" ,"电话1", "电话2"])
        self.table.setAlternatingRowColors(True)
        # 设置表格列宽自适应
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        
        # 可选：设置初始列宽比例
        self.table.setColumnWidth(0, 100)  # 姓名列宽
        self.table.setColumnWidth(1, 150)  # 单位列宽
        self.table.setColumnWidth(2, 100)  # 职务列宽
        self.table.setColumnWidth(3, 150)  # 电话1列宽
        self.table.setColumnWidth(4, 150)  # 电话2列宽
        main_layout.addWidget(self.table)

        # 分页控件
        page_layout = QHBoxLayout()
        self.prev_button = QPushButton("上一页")
        self.next_button = QPushButton("下一页")
        self.page_label = QLabel("第1页 / 共1页")
        page_layout.addWidget(self.prev_button)
        page_layout.addWidget(self.page_label)
        page_layout.addWidget(self.next_button)
        page_layout.addStretch()
        main_layout.addLayout(page_layout)

        # 按钮组
        button_layout = QHBoxLayout()
        self.load_button = QPushButton("加载文件")
        self.generate_button = QPushButton("生成文件")
        button_layout.addWidget(self.load_button)
        button_layout.addWidget(self.generate_button)
        button_layout.addStretch()
        main_layout.addLayout(button_layout)

        # 下载列表
        main_layout.addWidget(QLabel("下载列表:"))
        self.download_list = QListWidget()
        self.download_list.setSelectionMode(QListWidget.SingleSelection)
        main_layout.addWidget(self.download_list)
        download_button_layout = QHBoxLayout()
        self.download_button = QPushButton("下载选中文件到本地")
        download_button_layout.addWidget(self.download_button)
        download_button_layout.addStretch()
        main_layout.addLayout(download_button_layout)

        # 连接信号与槽
        self.load_button.clicked.connect(self.load_file)
        self.generate_button.clicked.connect(self.generate_file)
        self.prev_button.clicked.connect(self.prev_page)
        self.next_button.clicked.connect(self.next_page)
        self.download_button.clicked.connect(self.download_file)

        # 初始化示例数据（用于测试）
        self.data = [
            ["张三", "单位","职务","1234567890", "0987654321"],
        ]
        self.update_table()
        self.update_page_label()

    def load_file(self):
        """加载文件并更新表格"""
        file_name, _ = QFileDialog.getOpenFileName(
            self, "选择文件", "", "excel文件 (*.xlsx *.xls *.et)"
        )
        if file_name:
            try:
                 # rows = dict({姓名、职务、单位、电话1、电话2})
                self.raw_data = excel2vcf._readfromexcel(file_name)
                self.data = []
                for row in self.raw_data:
                    self.data.append([row['姓名'],row['单位'],row['职务'],row['电话1'],row['电话2']])
                self.current_page = 1
                self.update_table()
                self.update_page_label()
                QMessageBox.information(self, "成功", f"已加载文件: {file_name}")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"加载文件失败: {str(e)}")

    def update_table(self):
        """更新表格显示当前页数据"""
        start_idx = (self.current_page - 1) * self.items_per_page
        end_idx = start_idx + self.items_per_page
        page_data = self.data[start_idx:end_idx]

        self.table.setRowCount(len(page_data))
        for i, row in enumerate(page_data):
            for j, item in enumerate(row):
                self.table.setItem(i, j, QTableWidgetItem(item))

    def update_page_label(self):
        """更新页码标签"""
        total_pages = max(1, (len(self.data) + self.items_per_page - 1) // self.items_per_page)
        self.page_label.setText(f"第{self.current_page}页 / 共{total_pages}页")

    def prev_page(self):
        """切换到上一页"""
        if self.current_page > 1:
            self.current_page -= 1
            self.update_table()
            self.update_page_label()

    def next_page(self):
        """切换到下一页"""
        total_pages = max(1, (len(self.data) + self.items_per_page - 1) // self.items_per_page)
        if self.current_page < total_pages:
            self.current_page += 1
            self.update_table()
            self.update_page_label()

    def generate_file(self):
        """生成文件并添加到下载列表"""
        if not self.data:
            QMessageBox.warning(self, "警告", "没有数据可生成文件")
            return

        file_name = generate_vcf_filename()
        vcf = '\r\n'.join(map(excel2vcf._generatevcard, self.raw_data))
        try:
            with open(f"{self.temp_dir.name}/{file_name}", 'w', encoding='utf-8') as file:
                    file.write(vcf)
            self.generated_files.append(f"{self.temp_dir.name}/{file_name}")
            self.download_list.addItem(f"{self.temp_dir.name}/{file_name}")
            QMessageBox.information(self, "成功", f"文件已生成: {file_name}")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"生成文件失败: {str(e)}")

    def download_file(self):
        """下载选中的文件到本地"""
        selected_items = self.download_list.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "警告", "请先选择要下载的文件")
            return

        source_file = selected_items[0].text()
        if source_file not in self.generated_files:
            QMessageBox.warning(self, "警告", "文件不存在")
            return

        save_path, _ = QFileDialog.getSaveFileName(
            self, "保存文件", source_file, "vcf文件 (*.vcf)"
        )
        if save_path:
            try:
                shutil.copy(source_file, save_path)
                QMessageBox.information(self, "成功", f"文件已保存到: {save_path}")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"下载失败: {str(e)}")
    
    def on_application_exit(self):
        """
        应用程序退出时的回调函数
        无论何种方式退出都会执行
        """
        # 清理生成的临时文件
        try:
            self.temp_dir.cleanup()
        except Exception as e:
                print(f"删除临时文件失败 : {e}")
        
        # 执行其他清理操作
        self.perform_final_cleanup()
        
        print("应用程序退出回调执行完成")

def generate_vcf_filename():
    """
    生成形如"2026-02-25-1513515.vcf"的字符串
    格式：当前日期-防碰撞码.vcf
    防碰撞码：7位数字，由时间戳和随机数组合而成
    """
    # 获取当前日期
    current_date = datetime.datetime.now().strftime("%Y-%m-%d")
    
    # 生成防碰撞码
    # 使用当前时间戳的毫秒部分和随机数组合
    # 时间戳毫秒部分取后4位，随机数取3位，共7位数字
    timestamp_ms = int(time.time() * 1000)  # 毫秒时间戳
    timestamp_part = timestamp_ms % 10000  # 取后4位
    random_part = random.randint(0, 999)   # 3位随机数
    
    # 组合成7位防碰撞码
    collision_code = f"{timestamp_part:04d}{random_part:03d}"
    
    # 返回完整文件名
    return f"{current_date}-{collision_code}.vcf"

def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
    
