"""Context Teleport: portable, git-backed context store for AI coding agents."""

__version__ = "0.5.1"
