"""EDA project detection and artifact-aware import."""
