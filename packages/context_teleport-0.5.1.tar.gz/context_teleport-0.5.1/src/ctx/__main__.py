"""Allow running as `python -m ctx`."""

from ctx.cli.main import app

app()
