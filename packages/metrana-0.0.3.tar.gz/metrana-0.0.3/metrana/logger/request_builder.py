# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

from metrana_protobuf.ingestion.v1.svc import api_pb2
from metrana_protobuf.ingestion.v1.types import updates_pb2
from google.protobuf.timestamp_pb2 import Timestamp

from metrana.utils.metric_event import MetricEvent

# ======================================================================================================================
#
# CONSTANTS
#
# ======================================================================================================================

NANOS_PER_SECOND = 1_000_000_000

# ======================================================================================================================
#
# FUNCTIONS
#
# ======================================================================================================================


def build_v1_update_runs_request(
    batch: list[MetricEvent],
    workspace_name: str,
    project_name: str,
    run_name: str,
) -> api_pb2.UpdateRunsRequest:
    """
    Build a v1 UpdateRunsRequest protobuf from a batch of MetricEvents.

    Groups events by (metric_name, scale, labels) into SeriesUpdate objects,
    then builds a single RunUpdate for the given run.

    Args:
        batch: List of MetricEvent objects to convert.
        workspace_name: The name of the workspace for this run.
        project_name: The name of the project for this run.
        run_name: The name of the run.

    Returns:
        UpdateRunsRequest protobuf message.
    """

    series_map: dict[tuple[str, str, tuple[tuple[str, str], ...]], list[MetricEvent]] = {}
    for event in batch:
        labels_key = tuple(sorted(event.labels.items()))
        key = (event.metric_name, event.scale, labels_key)

        if key not in series_map:
            series_map[key] = []

        series_map[key].append(event)

    series_updates = []
    for (metric_name, scale, labels_key), events in series_map.items():
        points = []
        for event in events:
            timestamp = Timestamp()
            timestamp.seconds = event.timestamp // NANOS_PER_SECOND
            timestamp.nanos = event.timestamp % NANOS_PER_SECOND

            point = updates_pb2.Point(
                step=event.step,
                timestamp=timestamp,
                float_value=event.value,
            )
            points.append(point)

        series_update = updates_pb2.SeriesUpdate(
            metric_name=metric_name,
            scale=scale,
            labels=dict(labels_key),
            points=points,
        )
        series_updates.append(series_update)

    run_update = api_pb2.UpdateRunsRequest.RunUpdate(
        workspace=workspace_name,
        project=project_name,
        run_name=run_name,
        series=series_updates,
    )

    return api_pb2.UpdateRunsRequest(
        run_updates=[run_update],
    )
