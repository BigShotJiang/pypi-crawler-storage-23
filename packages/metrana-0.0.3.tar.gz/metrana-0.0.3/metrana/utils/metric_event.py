# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

import time
from dataclasses import dataclass, field

# ======================================================================================================================
#
# CLASSES
#
# ======================================================================================================================


@dataclass(slots=True, frozen=True)
class MetricEvent:
    """
    Class of data put into the metric event queue for processing.
    """

    metric_name: str
    value: float
    scale: str
    step: int
    labels: dict[str, str]
    timestamp: int = field(default_factory=time.time_ns)  # Unix epoch nanoseconds; use / 1e9 for seconds
