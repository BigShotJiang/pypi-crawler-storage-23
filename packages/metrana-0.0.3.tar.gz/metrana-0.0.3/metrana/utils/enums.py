# ======================================================================================================================
#
# IMPORTS
#
# ======================================================================================================================

from enum import Enum

# ======================================================================================================================
#
# ENUMS
#
# ======================================================================================================================


class StandardMetricScale(Enum):

    # Default. One step per ML training step.
    ML_STEP = "ML_STEP"

    # One step per RL episode
    EPISODE = "EPISODE"

    # One step per RL environment step
    ENVIRONMENT_STEP = "ENVIRONMENT_STEP"


class BackpressureStrategy(Enum):
    # Drop new events and keep the existing ones.
    DropNew = "drop_new"

    # Hang until space in the queue is available.
    Block = "block"

    # Raise an error if the queue is full.
    Raise = "raise"


class ErrorStrategy(Enum):
    # Do nothing when an error occurs and continue processing.
    Silent = "silent"

    # Log the error and continue processing.
    Warn = "warn"

    # Raise an error when metrana.log(...) is called and there are errors in the queue.
    RaiseOnLog = "raise_on_log"

    # Raise an error when metrana.close() is called and there are errors in the queue.
    RaiseOnClose = "raise_on_close"


class ResumeStrategy(Enum):
    # NOTE: Always is commented out because the CreateRun endpoint always creates the run
    # if it doesn't exist (returning 200), making it impossible to enforce "resume only" semantics.
    # To re-enable Always, the API would need one of:
    #   1. A separate "resume only" endpoint that returns 404 if the run doesn't exist, OR
    #   2. A query parameter on CreateRun like ?create_if_missing=false that returns 404
    # Without this, Always would error on first call (run doesn't exist) even though the server
    # creates it anyway, which is nonsensical.
    #
    # Always = "always"  # Resume existing run only, error if run doesn't exist

    # Never resume an existing run, only create new runs.
    Never = "never"

    # Resume an existing run if it exists, otherwise create a new run (default behavior).
    Allow = "allow"


class LogLevel(Enum):
    Trace = "TRACE"
    Debug = "DEBUG"
    Info = "INFO"
    Success = "SUCCESS"
    Warn = "WARNING"
    Error = "ERROR"
    Critical = "CRITICAL"
    Off = "OFF"


class CloseStrategy(Enum):
    # Kill the logger immediately and do not wait for any events
    # to finish or be processed.
    Immediate = "immediate"

    # Wait for all in-progress requests to finish but do not start
    # any new requests or drain the queues.
    CompletePending = "complete_pending"

    # Wait for all in-progress requests to finish and drain the queues
    # before closing the logger. Draining means all requests will process
    # before exiting.
    CompleteAll = "complete_all"
