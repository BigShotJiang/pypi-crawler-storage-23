"""
based on Pruppacher and Rasmussen 1979 (J. Atmos. Sci.)
https://doi.org/10.1175/1520-0469%281979%29036%3C1255:AWTIOT%3E2.0.CO;2

fig_1.ipynb:
.. include:: ./fig_1.ipynb.badges.md

"""

# pylint: disable=invalid-name
