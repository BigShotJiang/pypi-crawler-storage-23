"""
box-model coalescence-only example based on
[Berry 1967 (J. Atmos. Sci. 24)](https://doi.org/10.1175/1520-0469(1967)024%3C0688:CDGBC%3E2.0.CO;2)

figs_5_8_10.ipynb:
.. include:: ./figs_5_8_10.ipynb.badges.md
"""

# pylint: disable=invalid-name
