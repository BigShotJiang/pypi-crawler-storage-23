"""
global_meteoric_water_line.ipynb:
.. include:: ./global_meteoric_water_line.ipynb.badges.md

timescales_comparison.ipynb:
.. include:: ./timescales_comparison.ipynb.badges.md
"""
