# pylint: disable=invalid-name
"""
box-model coalescence-only example featuring Golovin analytic solution following setup from
[Shima et al. 2009](https://doi.org/10.1002/qj.441)

fig_2.ipynb:
.. include:: ./fig_2.ipynb.badges.md
"""
