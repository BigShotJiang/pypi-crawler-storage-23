"""
based on Rogers 1975 (Atmosphere)
https://doi.org/10.1080/00046973.1975.9648397

fig_1.ipynb:
.. include:: ./fig_1.ipynb.badges.md
"""

# pylint: disable=invalid-name
