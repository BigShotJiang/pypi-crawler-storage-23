"""
aerosol distribution from
[Ervens and Feingold 2012 (Atmos. Chem. Phys. 12)](https://doi.org/10.5194/acp-12-5807-2012)
"""

# pylint: disable=invalid-name
