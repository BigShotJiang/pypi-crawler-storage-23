# pylint: disable=invalid-name
"""
Box-model coalescence-breakup performance benchmark from
[Bulenok 2023 MSc thesis](https://www.ap.uj.edu.pl/diplomas/166879)
"""
