"""
paraview_hello_world.ipynb:
.. include:: ./paraview_hello_world.ipynb.badges.md

dimensional_analysis.ipynb:
.. include:: ./dimensional_analysis.ipynb.badges.md
"""
