"""
kohler.ipynb:
.. include:: ./kohler.ipynb.badges.md

MWE_joss_paper.ipynb:
.. include:: ./MWE_joss_paper.ipynb.badges.md
"""

# pylint: disable=invalid-name
