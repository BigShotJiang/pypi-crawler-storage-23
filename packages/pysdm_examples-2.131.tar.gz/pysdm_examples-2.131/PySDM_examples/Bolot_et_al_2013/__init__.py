"""
figures from Bolot et al. 2013 (Atmos. Chem. Phys. 13)
https://doi.org/10.5194/acp-13-7903-2013

fig_1.ipynb:
.. include:: ./fig_1.ipynb.badges.md
"""

# pylint: disable=invalid-name
