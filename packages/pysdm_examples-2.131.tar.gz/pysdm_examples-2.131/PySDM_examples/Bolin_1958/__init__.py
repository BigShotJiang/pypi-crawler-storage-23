"""
Table 1 from [Bolin 1958](https://digitallibrary.un.org/record/3892725)

table_1.ipynb:
.. include:: ./table_1.ipynb.badges.md
"""

# pylint: disable=invalid-name
