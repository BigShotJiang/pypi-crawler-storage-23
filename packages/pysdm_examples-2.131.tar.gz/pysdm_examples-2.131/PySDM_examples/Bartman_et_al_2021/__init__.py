# pylint: disable=invalid-name
"""
condensation and coalescence adaptivity examples

demo.ipynb:
.. include:: ./demo.ipynb.badges.md

demo_fig2.ipynb:
.. include:: ./demo_fig2.ipynb.badges.md

demo_fig3.ipynb:
.. include:: ./demo_fig3.ipynb.badges.md
"""
