"""
based on Stewart 1975 (J. Geophys. Res.)
https://doi.org/10.1029/JC080i009p01133

fig_1.ipynb:
.. include:: ./fig_1.ipynb.badges.md
"""
