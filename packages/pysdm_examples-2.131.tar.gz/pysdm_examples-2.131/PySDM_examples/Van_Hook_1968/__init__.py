"""
figure from Van Hook 1968 (J. Phys. Chem.)
https://doi.org/10.1021/j100850a028

fig_1.ipynb:
.. include:: ./fig_1.ipynb.badges.md
"""

# pylint: disable=invalid-name
