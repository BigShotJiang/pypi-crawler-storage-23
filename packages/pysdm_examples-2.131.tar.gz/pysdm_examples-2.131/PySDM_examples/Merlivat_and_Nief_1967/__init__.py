"""
figure from Merlivat and Nief 1967 (Tellus)
https://doi.org/10.3402/tellusa.v19i1.9756

fig_2.ipynb:
.. include:: ./fig_2.ipynb.badges.md
"""

# pylint: disable=invalid-name
