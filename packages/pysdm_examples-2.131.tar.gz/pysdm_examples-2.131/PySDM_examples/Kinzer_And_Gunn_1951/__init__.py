"""
Table 1 and 2 from [Kinzer & Gunn 1951]
(https://doi.org/10.1175/1520-0469(1951)008%3C0071:TETATR%3E2.0.CO;2)
"""
