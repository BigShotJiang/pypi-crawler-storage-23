"""
hello_world.ipynb:
.. include:: ./hello_world.ipynb.badges.md

seeding_no_collisions.ipynb:
.. include:: ./seeding_no_collisions.ipynb.badges.md
"""

from .settings import Settings
from .simulation import Simulation
