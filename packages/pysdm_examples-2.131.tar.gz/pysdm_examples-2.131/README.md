[![License: GPL v3](https://img.shields.io/badge/License-GPL%20v3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.html)
[![DOI](https://zenodo.org/badge/199064632.svg)](https://zenodo.org/badge/latestdoi/199064632)

[![PyPI version](https://badge.fury.io/py/PySDM-examples.svg)](https://pypi.org/project/PySDM-examples)
[![API docs](https://img.shields.io/badge/API_docs-pdoc3-blue.svg)](https://open-atmos.github.io/PySDM-examples/)

For a list of examples, see [PySDM-examples documentation](https://open-atmos.github.io/PySDM/PySDM_examples.html).

For information on package development, see [PySDM README](https://github.com/open-atmos/PySDM/blob/main/README.md).

