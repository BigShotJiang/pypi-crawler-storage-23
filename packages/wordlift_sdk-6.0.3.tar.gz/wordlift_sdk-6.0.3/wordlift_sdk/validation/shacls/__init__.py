"""Packaged SHACL shapes."""
