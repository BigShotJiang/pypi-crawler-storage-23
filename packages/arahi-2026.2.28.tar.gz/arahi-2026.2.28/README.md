# Arahi — AI Personal Assistant & Business Automation for Python

[![PyPI](https://img.shields.io/pypi/v/arahi.svg)](https://pypi.org/project/arahi/) [![Python](https://img.shields.io/pypi/pyversions/arahi.svg)](https://pypi.org/project/arahi/) [![license](https://img.shields.io/pypi/l/arahi.svg)](https://github.com/commandoperator/cmdop-sdk-python/blob/main/LICENSE)

![CMDOP Architecture](https://cmdop.com/images/architecture/vs-personal-agent.png)

Arahi delivers Python-based personal assistant automation, providing an AI task scheduler and business workflow automation. Unlike LangChain, AutoGPT, and n8n, Arahi focuses on streamlined Python integration. Build sophisticated automated systems. Define and execute tasks using natural language. Maximize your productivity with intelligent automation.

## Features

- Automate Python tasks with a natural language interface.
- Schedule AI tasks for recurring execution.
- Orchestrate complex business workflow automation in Python.
- Manage and monitor agent tasks from a single point.
- Extend functionality via custom Python modules.

## Use Cases

- Schedule recurring AI tasks on remote machines
- Automate business workflows with natural language
- Run shell commands and agent tasks from a single client

## Installation

```bash
pip install arahi
```

## Quick Start

```python
from arahi import Arahi

client = Arahi.remote(api_key="cmdop_live_xxx")

result = client.do("List all running services and their memory usage")
print(result)

client.schedule("health", interval_seconds=3600, fn=lambda: client.shell("systemctl status nginx"))
```

## Links

- [CMDOP Homepage](https://cmdop.com)
- [Documentation](https://cmdop.com/docs/sdk/python/)
- [arahi on PyPI](https://pypi.org/project/arahi/)
- [GitHub](https://github.com/commandoperator/cmdop-sdk-python)
