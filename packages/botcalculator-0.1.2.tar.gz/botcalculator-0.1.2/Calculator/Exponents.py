import cmath
import math

def power(a, b):
    return(a ** b)

def root(a, b):
    if b == 0:
        raise ValueError("Root degree can't be 0")
    return cmath.pow(a, 1 / b)

def factorial(num):
    return math.factorial(int(num))