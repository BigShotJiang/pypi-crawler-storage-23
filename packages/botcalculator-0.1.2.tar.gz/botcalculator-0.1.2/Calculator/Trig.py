import cmath
import math
def sin(num):
    return cmath.sin(math.radians(num))


def cos(num):
    return cmath.cos(math.radians(num))


def tan(num):
    if num % 180 == 90:
        return "Undefined"
    
    return cmath.tan(math.radians(num))

def csc(num):
    s = math.sin(math.radians(num))
    if abs(s) < 1e-10:
        return "Undefined"
    return 1 / s

def sec(num):
    c = math.cos(math.radians(num))
    if abs(c) < 1e-10:
        return "Undefined"
    return 1 / c

def cot(num):
    t = math.tan(math.radians(num))
    if abs(t) < 1e-10:
        return "Undefined"
    return 1 / t

def arcsin(num):
    if num < -1 or num > 1:
        return "Undefined"
    return math.degrees(math.asin(num))

def arccos(num):
    if num < -1 or num > 1:
        return "Undefined"
    return math.degrees(math.acos(num))

def arctan(num):
    return math.degrees(math.atan(num))

def arccsc(num):
    if abs(num) < 1:
        return "Undefined"
    return math.degrees(math.asin(1 / num))

def arcsec(num):
    if abs(num) < 1:
        return "Undefined"
    return math.degrees(math.acos(1 / num))

def arccot(num):
    if num == 0:
        return 90.0
    return math.degrees(math.atan(1 / num))

def sinh(x):
    return math.sinh(x)

def cosh(x):
    return math.cosh(x)

def tanh(x):
    return math.tanh(x)

def csch(x):
    if x == 0:
        return "Undefined"
    return 1 / math.sinh(x)

def sech(x):
    return 1 / math.cosh(x)

def coth(x):
    if x == 0:
        return "Undefined"
    return 1 / math.tanh(x)

def arcsinh(x):
    return math.asinh(x)

def arccosh(x):
    if x < 1:
        return "Domain Error"
    return math.acosh(x)

def arctanh(x):
    if abs(x) >= 1:
        return "Domain Error"
    return math.atanh(x)