import numbers
import math

def round_up_decimal(n, decimals=0):
    multiplier = 10**decimals
    return math.ceil(n * multiplier) / multiplier

def format_result(result):
    if not isinstance(result, numbers.Number):
        return result
    
    if isinstance(result, complex):
        real = round(result.real, 10)
        imag = round(result.imag, 10)

        if abs(real) < 1e-10:
            real = 0
        if abs(imag) < 1e-10:
            imag = 0

        if real == 0:
            return f"{imag}i"
        return f"{real} + {imag}i"

    return result
