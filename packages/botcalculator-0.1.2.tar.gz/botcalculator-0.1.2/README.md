# Botcalculator

Botcalculator is a terminal-based calculator built using Python and curses.
It features a modular architecture and an interactive command-line interface
for performing mathematical operations efficiently.
Note: Only works for macOS and Linux machines, Windows coming soon.

## Features

- Arithmetic, Exponents, and Trigonometry
- Power and advanced math operations
- Terminal UI powered by curses
- Structured modular design
- Installable via pip
## Changelog

### v0.1.2
- Added input validation (prevents crashes from invalid text input)
- Improved divide-by-zero handling
- Enhanced error messaging

### v0.1.1
- Added exception handling for arithmetic operations
- Improved modular structure
- Added Hyperbolic Trigonometry

### v0.1.0
- Initial release

## Installation

```bash
pip install Botcalculator
