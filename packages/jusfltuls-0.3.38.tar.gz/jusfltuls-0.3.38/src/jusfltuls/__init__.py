#!/usr/bin/env python3

import click
from importlib.metadata import version as pkg_version

def print_version(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    print(pkg_version('jusfltuls'))
    ctx.exit()

@click.command(context_settings=dict(help_option_names=['-h', '--help']))
@click.option('-v', '--version', is_flag=True, callback=print_version, expose_value=False, is_eager=True, help='Show version and exit')
def main():
    """Jusfltuls - Useful tools for linux life"""
    print("""
    ╔══════════════════════════════════════════════════════════════╗
    ║                    JUSFLTULS TOOLKIT                         ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  GENERAL TOOLS                                               ║
    ║  ────────────                                                ║
    ║  dtox        - detox filenames with bad characters           ║
    ║  cpuspeed    - CPU frequency monitor                         ║
    ║  pingy       - Network ping utility                          ║
    ║  sshconf     - SSH config manager                            ║
    ║  zoter       - Zotero helper                                 ║
    ║  wavescan    - Wave file scanner                             ║
    ║  distcheck   - Helper for uv publishing in PyPI              ║
    ║  pycompress  - Python compression utility                    ║
    ║  ssshow      - Services show                                 ║
    ║  fawhis      - Fast_whisper transcription                    ║
    ║  mpvsa       - mpv audio/subtitle waterfall finder           ║
    ║  voicemqtt   - Voice MQTT client                             ║
    ╠══════════════════════════════════════════════════════════════╣
    ║  TUI APPLICATIONS                                            ║
    ║  ──────────────                                              ║
    ║  smartnow    - [TUI] Smart monitoring dashboard              ║
    ║  mci         - [TUI] InfluxDB MC client                      ║
    ╚══════════════════════════════════════════════════════════════╝
    """)
    return "Hello from jusfltuls! Myself, I reside in __init__; TRY sshconf dtox cpuspeed pingy smartnow distcheck"

if __name__ == "__main__":
    main()
