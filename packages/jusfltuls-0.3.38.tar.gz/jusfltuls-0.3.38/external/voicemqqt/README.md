# VoiceMQTT

Voice-to-text transcription triggered by MQTT, with Wayland clipboard integration.

## Quick Start

```bash
# Install
sudo apt install wl-clipboard portaudio19-dev
uv pip install -e .

# Run with local MQTT
voicemqtt

# Or with remote secure MQTT
voicemqtt --mqtt-host mqtt.example.com --mqtt-port 8883 --mqtt-tls --mqtt-user myuser --mqtt-pass mypass
```

## Features

- **MQTT Activation** - Trigger via MQTT messages
- **Recording Status** - Publishes recording state (2=sound, 1=silence, 0=idle) to MQTT topic
- **Public MQTT** - Quick connect using config file (~/.config/influxdb/totalconfig.conf)
- **Security** - TLS and username/password auth
- **Real-time UI** - Visual audio level meter
- **Auto-stop** - Stops after 3s silence
- **Local AI** - Offline Whisper transcription
- **Clipboard** - Auto-copies to Wayland clipboard

## Usage

```bash
# Basic
voicemqtt

# Use public MQTT from config file
voicemqtt --public-mqtt

# Calibrate silence threshold
voicemqtt --calibrate

# Better quality model (slower)
voicemqtt --model small

# Custom MQTT
voicemqtt --mqtt-host 192.168.1.100 --mqtt-topic home/voice

# Secure remote MQTT
voicemqtt --mqtt-host mqtt.example.com --mqtt-tls --mqtt-user user --mqtt-pass pass

# Run once
voicemqtt --single
```

## Options

```
--mqtt-host TEXT                MQTT broker host [default: localhost]
--mqtt-port INTEGER             MQTT broker port [default: 1883]
--mqtt-topic TEXT               MQTT activation topic [default: voicemqtt/activate]
--mqtt-user TEXT                MQTT username
--mqtt-pass TEXT                MQTT password
--mqtt-tls                      Enable TLS encryption
--mqtt-ca-certs TEXT            Path to CA certificates
--public-mqtt                   Use public MQTT from ~/.config/influxdb/totalconfig.conf
--recording-status-topic TEXT   Recording status topic (2=sound, 1=silence, 0=idle) [default: voicemqtt/recording]
--model TEXT                    Model: tiny/base/small/medium/large-v3 [default: base]
--device TEXT                   Device: cpu/cuda [default: cpu]
--silence-threshold FLOAT       Silence level [default: 0.01]
--silence-duration FLOAT        Silence timeout [default: 3.0]
--single                        Run once and exit
--calibrate                     Calibrate silence threshold
--version                       Show version
--help                          Show help
```

## Requirements

- Python 3.12+
- MQTT broker
- Wayland display
- Microphone
- ~150MB disk (for base model)

## Activate via MQTT

```bash
mosquitto_pub -h localhost -t "voicemqtt/activate" -m "record"
```

## Recording Status

The application publishes recording status to an MQTT topic:
- `2` - Recording with sound detected
- `1` - Recording with silence detected (but still recording)
- `0` - Recording finished / idle

Default topic: `voicemqtt/recording`

Subscribe to monitor recording state:
```bash
mosquitto_sub -h localhost -t "voicemqtt/recording"
```

Customize the status topic:
```bash
voicemqtt --recording-status-topic "home/voice/status"
```

## Model Sizes

| Model | Size | Speed | Accuracy |
|-------|------|-------|----------|
| tiny | 39MB | Fast | Basic |
| base | 74MB | Fast | Good |
| small | 244MB | Medium | Better |
| medium | 769MB | Slow | Great |
| large | 1.5GB | Slow | Best |

Models download automatically on first use from Hugging Face.

## Testing

```bash
uv run pytest tests/ -v
```

46 tests included.
