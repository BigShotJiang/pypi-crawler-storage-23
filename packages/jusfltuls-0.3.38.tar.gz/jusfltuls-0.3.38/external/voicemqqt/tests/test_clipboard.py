"""Tests for clipboard module."""

import subprocess
from unittest.mock import MagicMock, patch

import pytest

from voicemqtt.clipboard import ClipboardManager


class TestClipboardManager:
    """Tests for ClipboardManager class."""
    
    def test_init_checks_wl_copy_availability(self):
        """Test that initialization checks for wl-copy."""
        with patch("voicemqtt.clipboard.shutil.which") as mock_which:
            # Test when wl-copy is available
            mock_which.return_value = "/usr/bin/wl-copy"
            cb = ClipboardManager()
            assert cb.wl_copy_available is True
            
            # Test when wl-copy is not available
            mock_which.return_value = None
            cb = ClipboardManager()
            assert cb.wl_copy_available is False
    
    def test_copy_text_success(self):
        """Test successful text copy."""
        with patch("voicemqtt.clipboard.shutil.which") as mock_which, \
             patch("voicemqtt.clipboard.subprocess.run") as mock_run:
            mock_which.return_value = "/usr/bin/wl-copy"
            mock_run.return_value = MagicMock(returncode=0)

            cb = ClipboardManager()
            result = cb.copy_text("Hello World")

            assert result is True
            mock_run.assert_called_once_with(
                ["wl-copy", "--foreground"],
                input="Hello World",
                text=True,
                capture_output=True,
                check=True,
                timeout=2.0
            )
    
    def test_copy_text_no_wl_copy(self):
        """Test copy when wl-copy is not available."""
        with patch("voicemqtt.clipboard.shutil.which") as mock_which:
            mock_which.return_value = None
            
            cb = ClipboardManager()
            result = cb.copy_text("Hello")
            
            assert result is False
    
    def test_copy_text_empty(self):
        """Test copy with empty text."""
        with patch("voicemqtt.clipboard.shutil.which") as mock_which:
            mock_which.return_value = "/usr/bin/wl-copy"
            
            cb = ClipboardManager()
            result = cb.copy_text("")
            
            assert result is False
    
    def test_copy_text_failure(self):
        """Test copy when subprocess fails."""
        with patch("voicemqtt.clipboard.shutil.which") as mock_which, \
             patch("voicemqtt.clipboard.subprocess.run") as mock_run:
            mock_which.return_value = "/usr/bin/wl-copy"
            mock_run.side_effect = subprocess.CalledProcessError(1, "wl-copy")

            cb = ClipboardManager()
            result = cb.copy_text("Hello")

            assert result is False

    def test_copy_text_timeout(self):
        """Test copy when subprocess times out (treated as success)."""
        with patch("voicemqtt.clipboard.shutil.which") as mock_which, \
             patch("voicemqtt.clipboard.subprocess.run") as mock_run:
            mock_which.return_value = "/usr/bin/wl-copy"
            mock_run.side_effect = subprocess.TimeoutExpired("wl-copy", 2.0)

            cb = ClipboardManager()
            result = cb.copy_text("Hello")

            # Timeout is treated as success (wl-copy forked into background)
            assert result is True
