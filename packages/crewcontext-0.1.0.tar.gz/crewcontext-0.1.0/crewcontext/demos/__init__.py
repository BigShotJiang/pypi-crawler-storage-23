"""Demo scenarios.""" 
