"""Tests for CrewContext.""" 
