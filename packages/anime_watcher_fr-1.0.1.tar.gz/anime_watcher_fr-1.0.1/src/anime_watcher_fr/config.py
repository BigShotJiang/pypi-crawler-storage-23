PROVIDER = 0

# If set to true, the PROVIDER config field will be ignored, and the program will always select vidmoly if possible,
# and fall back to PROVIDER else
PREFER_VIDMOLY = True
