"""Setup file for backward compatibility with older build tools"""

from setuptools import setup

# Configuration is in pyproject.toml
setup()
