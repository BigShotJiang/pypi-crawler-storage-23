"""Aruba device patterns."""
