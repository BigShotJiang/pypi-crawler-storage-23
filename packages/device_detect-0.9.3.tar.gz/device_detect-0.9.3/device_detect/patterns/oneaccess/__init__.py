"""OneAccess device patterns."""
