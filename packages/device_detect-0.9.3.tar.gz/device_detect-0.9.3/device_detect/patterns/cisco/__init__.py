"""Cisco device patterns."""
