from blockapi.v2.api.synthetix.synthetix import (
    SynthetixApi,
    SynthetixMainnetApi,
    SynthetixOptimismApi,
    snx_contract_address,
    snx_optimism_contract_address,
)
