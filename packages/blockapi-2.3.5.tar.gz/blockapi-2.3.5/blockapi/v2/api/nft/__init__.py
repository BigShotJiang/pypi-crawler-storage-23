from blockapi.v2.api.nft.magic_eden import MagicEdenSolanaApi
from blockapi.v2.api.nft.opensea import OpenSeaApi
from blockapi.v2.api.nft.simple_hash import (
    SimpleHashBitcoinApi,
    SimpleHashEthereumApi,
    SimpleHashSolanaApi,
)
from blockapi.v2.api.nft.unisat import UnisatApi
