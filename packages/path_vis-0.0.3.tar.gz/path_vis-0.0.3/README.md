# path_vis

[![Jupyterlite](https://jupyterlite.rtfd.io/en/latest/_static/badge.svg)](https://matthewandretaylor.github.io/path_vis/lab?path=example_continuum.ipynb)


[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/MatthewAndreTaylor/path_vis/blob/main/example_continuum.ipynb)
