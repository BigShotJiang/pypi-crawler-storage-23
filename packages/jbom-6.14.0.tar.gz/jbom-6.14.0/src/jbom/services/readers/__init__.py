"""Service subpackage for file readers.

These modules exist primarily to provide stable import paths for unit tests and
to separate read/parse concerns from higher-level orchestration.
"""

from __future__ import annotations

__all__ = ["schematic_reader"]
