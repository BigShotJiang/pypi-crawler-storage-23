"""
PUViNoise Telemetry Schema — AgentOps Behavioural Intelligence.

Single source of truth for span/attribute names. Aligns with server/lib/telemetry-schema-agentops.js.
Four pillars: agent behaviour, tool decisions, goal success, model performance.
"""

# Span operation names
SPAN_AGENT_RUN = "agent.run"
SPAN_AGENT_STEP = "agent.step"
SPAN_TOOL_PREFIX = "tool."
SPAN_LLM_PREFIX = "llm."
SPAN_MEMORY_PREFIX = "memory."

# Agent run (root span)
AGENT_RUN_ID = "agent.run_id"
AGENT_NAME = "agent.name"
AGENT_LIFECYCLE = "agent.lifecycle"
AGENT_GOAL = "agent.goal"
AGENT_TASK_TYPE = "agent.task_type"
AGENT_TASK = "agent.task"
AGENT_INTENT = "agent.intent"
AGENT_DURATION_MS = "agent.duration_ms"
AGENT_STEP_NAME = "agent.step_name"
AGENT_STEP_DURATION_MS = "agent.step_duration_ms"

# Behaviour (root span — agent behaviour analysis)
BEHAVIOUR_TOOL_CALL_COUNT = "behaviour.tool_call_count"
BEHAVIOUR_TOOL_SWITCH_COUNT = "behaviour.tool_switch_count"
BEHAVIOUR_TOOL_SWITCHING_RATE = "behaviour.tool_switching_rate"
BEHAVIOUR_TOOL_FAILURE_COUNT = "behaviour.tool_failure_count"
BEHAVIOUR_REPEATED_TOOL_FAILURES = "behaviour.repeated_tool_failures"
BEHAVIOUR_RETRY_ATTEMPTS = "behaviour.retry_attempts"
BEHAVIOUR_CONTEXT_OVERFLOW = "behaviour.context_overflow"
BEHAVIOUR_HALLUCINATION_SUSPECTED = "behaviour.hallucination_suspected"
BEHAVIOUR_GOAL_COMPLETED = "behaviour.goal_completed"
BEHAVIOUR_GOAL_PROGRESS = "behaviour.goal_progress"

# Goal / outcome (root span)
DECISION_TRACE_OUTCOME = "decision.trace_outcome"
DECISION_TRACE_OUTCOME_REASON = "decision.trace_outcome_reason"
DECISION_TURN_INDEX = "decision.turn_index"
DECISION_MESSAGE_ID = "decision.message_id"

# Tool (tool.* spans)
TOOL_NAME = "tool.name"
TOOL_DURATION_MS = "tool.duration_ms"

# LLM (llm.* spans)
LLM_PROVIDER = "llm.provider"
LLM_MODEL = "llm.model"
LLM_RESPONSE_MODEL = "llm.response_model"
LLM_INPUT_TOKENS = "llm.input_tokens"
LLM_OUTPUT_TOKENS = "llm.output_tokens"
LLM_STOP_REASON = "llm.stop_reason"
LLM_LATENCY_MS = "llm.latency_ms"
LLM_STREAMING = "llm.streaming"
LLM_TEMPERATURE = "llm.temperature"
LLM_MAX_TOKENS = "llm.max_tokens"

# Resource / tenant
TENANT_ID = "tenant.id"
PUVINOISE_LLM_PROVIDER = "puvinoise.llm_provider"
PUVINOISE_TELEMETRY_SCHEMA = "puvinoise.telemetry.schema"

# Map of behaviour signal key (for get_behaviour_signals) -> span attribute name
BEHAVIOUR_SIGNALS = {
    BEHAVIOUR_TOOL_CALL_COUNT: BEHAVIOUR_TOOL_CALL_COUNT,
    BEHAVIOUR_TOOL_SWITCH_COUNT: BEHAVIOUR_TOOL_SWITCH_COUNT,
    BEHAVIOUR_TOOL_SWITCHING_RATE: BEHAVIOUR_TOOL_SWITCHING_RATE,
    BEHAVIOUR_TOOL_FAILURE_COUNT: BEHAVIOUR_TOOL_FAILURE_COUNT,
    BEHAVIOUR_REPEATED_TOOL_FAILURES: BEHAVIOUR_REPEATED_TOOL_FAILURES,
    BEHAVIOUR_RETRY_ATTEMPTS: BEHAVIOUR_RETRY_ATTEMPTS,
    BEHAVIOUR_CONTEXT_OVERFLOW: BEHAVIOUR_CONTEXT_OVERFLOW,
    BEHAVIOUR_HALLUCINATION_SUSPECTED: BEHAVIOUR_HALLUCINATION_SUSPECTED,
}
