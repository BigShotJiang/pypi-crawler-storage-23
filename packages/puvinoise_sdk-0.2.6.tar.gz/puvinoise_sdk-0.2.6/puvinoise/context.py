import uuid
import contextvars
from typing import Optional, Dict, Any

# Context variables automatically propagate across async calls
_run_id = contextvars.ContextVar("run_id", default=None)
_agent_name = contextvars.ContextVar("agent_name", default=None)
_goal = contextvars.ContextVar("goal", default=None)
_task_type = contextvars.ContextVar("task_type", default=None)
_intent = contextvars.ContextVar("intent", default=None)
_agent_state = contextvars.ContextVar("agent_state", default=None)
_session_id = contextvars.ContextVar("session_id", default=None)
_model_used = contextvars.ContextVar("model_used", default=None)
_prompt_hash = contextvars.ContextVar("prompt_hash", default=None)
_reasoning_depth = contextvars.ContextVar("reasoning_depth", default=0)
_turn_index = contextvars.ContextVar("turn_index", default=None)
_message_id = contextvars.ContextVar("message_id", default=None)
_model_provider = contextvars.ContextVar("model_provider", default=None)
_context_size = contextvars.ContextVar("context_size", default=None)

# Behaviour intelligence counters/signals (per run)
_tool_call_count = contextvars.ContextVar("tool_call_count", default=0)
_tool_switch_count = contextvars.ContextVar("tool_switch_count", default=0)
_tool_failure_count = contextvars.ContextVar("tool_failure_count", default=0)
_last_tool_name = contextvars.ContextVar("last_tool_name", default=None)
_retry_attempts = contextvars.ContextVar("retry_attempts", default=0)
_hallucination_suspected = contextvars.ContextVar("hallucination_suspected", default=False)
_context_overflow_flag = contextvars.ContextVar("context_overflow_flag", default=False)


class AgentContext:
    """
    Holds metadata for a single agent execution.
    Uses contextvars for thread-safe and async-safe context propagation.
    Optional decision-telemetry fields: goal, task_type, intent, agent_state.
    """
    
    def __init__(
        self,
        agent_name: str,
        run_id: Optional[str] = None,
        goal: Optional[str] = None,
        task_type: Optional[str] = None,
        intent: Optional[str] = None,
        session_id: Optional[str] = None,
        turn_index: Optional[int] = None,
        message_id: Optional[str] = None,
    ):
        """
        Initialize agent context.

        Args:
            agent_name: Name of the agent
            run_id: Optional custom run ID (generates UUID if not provided)
            goal: Optional high-level goal (decision telemetry)
            task_type: Optional task type (decision telemetry)
            intent: Optional classified intent (decision telemetry)
            session_id: Optional session/conversation ID (decision telemetry envelope)
            turn_index: Optional 1-based turn number in session (decision telemetry envelope)
            message_id: Optional request/message ID within session (decision telemetry envelope)
        """
        self.run_id = run_id or str(uuid.uuid4())
        self.agent_name = agent_name
        self._goal = goal
        self._task_type = task_type
        self._intent = intent
        self._session_id = session_id
        self._turn_index = turn_index
        self._message_id = message_id
        self._tokens = []
    
    def activate(self):
        """Activate this context for the current execution."""
        self._tokens = [
            _run_id.set(self.run_id),
            _agent_name.set(self.agent_name),
            _goal.set(self._goal),
            _task_type.set(self._task_type),
            _intent.set(self._intent),
            _agent_state.set("idle"),
            _session_id.set(self._session_id),
            _turn_index.set(self._turn_index),
            _message_id.set(self._message_id),
        ]
    
    def deactivate(self):
        """Deactivate this context and restore previous values."""
        for token in reversed(self._tokens):
            try:
                if token:
                    token.var.reset(token)
            except Exception:
                pass  # Token may have already been reset
        self._tokens.clear()
    
    def __enter__(self):
        """Context manager support."""
        self.activate()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager cleanup."""
        self.deactivate()
        return False
    
    @staticmethod
    def get_run_id() -> Optional[str]:
        """Get the current run ID from context."""
        return _run_id.get()
    
    @staticmethod
    def get_agent_name() -> Optional[str]:
        """Get the current agent name from context."""
        return _agent_name.get()
    
    @staticmethod
    def get_goal() -> Optional[str]:
        """Get the current goal from context (decision telemetry)."""
        return _goal.get()
    
    @staticmethod
    def get_task_type() -> Optional[str]:
        """Get the current task type from context (decision telemetry)."""
        return _task_type.get()
    
    @staticmethod
    def get_intent() -> Optional[str]:
        """Get the current intent from context (decision telemetry)."""
        return _intent.get()
    
    @staticmethod
    def get_agent_state() -> Optional[str]:
        """Get the current agent state from context (decision telemetry)."""
        return _agent_state.get()
    
    @staticmethod
    def set_agent_state(state: str) -> None:
        """Set the current agent state in context (decision telemetry)."""
        _agent_state.set(state)

    @staticmethod
    def get_session_id() -> Optional[str]:
        """Get the current session ID from context (decision telemetry envelope)."""
        return _session_id.get()

    @staticmethod
    def set_session_id(session_id: Optional[str]) -> None:
        """Set the current session ID in context."""
        _session_id.set(session_id)

    @staticmethod
    def get_model_used() -> Optional[str]:
        """Get the current model used from context (decision telemetry envelope)."""
        return _model_used.get()

    @staticmethod
    def set_model_used(model: Optional[str]) -> None:
        """Set the current model used in context (e.g. after LLM call)."""
        _model_used.set(model)

    @staticmethod
    def get_prompt_hash() -> Optional[str]:
        """Get the current prompt hash from context (decision telemetry envelope)."""
        return _prompt_hash.get()

    @staticmethod
    def set_prompt_hash(hash_value: Optional[str]) -> None:
        """Set the current prompt hash in context."""
        _prompt_hash.set(hash_value)

    @staticmethod
    def get_turn_index() -> Optional[int]:
        """Get the current turn index (1-based) in session from context."""
        v = _turn_index.get()
        return int(v) if v is not None else None

    @staticmethod
    def set_turn_index(turn_index: Optional[int]) -> None:
        """Set the current turn index in context (decision telemetry envelope)."""
        _turn_index.set(turn_index)

    @staticmethod
    def get_message_id() -> Optional[str]:
        """Get the current message/request ID in session from context."""
        return _message_id.get()

    @staticmethod
    def set_message_id(message_id: Optional[str]) -> None:
        """Set the current message ID in context (decision telemetry envelope)."""
        _message_id.set(message_id)

    # -------------------------------------------------------------------------
    # Reasoning depth (for checkpoint system: nested reasoning steps)
    # -------------------------------------------------------------------------

    @staticmethod
    def get_model_provider() -> Optional[str]:
        """Get the current model provider (e.g. openai, anthropic) for schema v2."""
        return _model_provider.get()

    @staticmethod
    def set_model_provider(provider: Optional[str]) -> None:
        """Set the current model provider in context (schema v2)."""
        _model_provider.set(provider)

    @staticmethod
    def get_context_size() -> Optional[int]:
        """Get the current context size (tokens/chars) for schema v2."""
        v = _context_size.get()
        return int(v) if v is not None else None

    @staticmethod
    def set_context_size(size: Optional[int]) -> None:
        """Set the current context size in context (schema v2)."""
        _context_size.set(size)

    @staticmethod
    def get_reasoning_depth() -> int:
        """Return current reasoning depth (0 = top level). Incremented by enter_reasoning_step."""
        try:
            d = _reasoning_depth.get()
            return int(d) if d is not None else 0
        except Exception:
            return 0

    @staticmethod
    def enter_reasoning_step():
        """
        Enter a reasoning step (increments depth). Returns a token to pass to exit_reasoning_step.
        Use as: token = AgentContext.enter_reasoning_step(); try: ... finally: AgentContext.exit_reasoning_step(token)
        """
        prev = AgentContext.get_reasoning_depth()
        return _reasoning_depth.set(prev + 1)

    @staticmethod
    def exit_reasoning_step(token) -> None:
        """Exit a reasoning step (restores previous depth). Pass the token from enter_reasoning_step."""
        try:
            if token is not None:
                _reasoning_depth.reset(token)
        except Exception:
            pass

    @staticmethod
    def reasoning_step():
        """
        Context manager that increments reasoning depth on entry and restores on exit.
        Use: with AgentContext.reasoning_step(): ...
        """
        class _ReasoningStepContext:
            def __enter__(self):
                self._token = AgentContext.enter_reasoning_step()
                return self

            def __exit__(self, *args):
                AgentContext.exit_reasoning_step(self._token)
                return False

        return _ReasoningStepContext()
    
    @staticmethod
    def increment_tool_call(tool_name: str, success: bool) -> None:
        """
        Update behaviour counters for a tool call.
        Used by auto-instrumentation to derive tool_switching_rate and repeated_tool_failures.
        """
        try:
            name = (tool_name or "").strip()
            calls = _tool_call_count.get() or 0
            switches = _tool_switch_count.get() or 0
            failures = _tool_failure_count.get() or 0
            last = _last_tool_name.get()

            calls += 1
            if last and name and last != name:
                switches += 1
            if not success:
                failures += 1

            _tool_call_count.set(calls)
            _tool_switch_count.set(switches)
            _tool_failure_count.set(failures)
            _last_tool_name.set(name or last)
        except Exception:
            # Never let telemetry counters break user code
            pass

    @staticmethod
    def increment_retry_attempt() -> None:
        """Increment retry attempt counter for this run."""
        try:
            val = _retry_attempts.get() or 0
            _retry_attempts.set(val + 1)
        except Exception:
            pass

    @staticmethod
    def mark_context_overflow() -> None:
        """Mark that a context/token overflow-like failure occurred."""
        try:
            _context_overflow_flag.set(True)
        except Exception:
            pass

    @staticmethod
    def mark_hallucination_suspected() -> None:
        """Mark that hallucination is suspected for this run."""
        try:
            _hallucination_suspected.set(True)
        except Exception:
            pass

    @staticmethod
    def get_behaviour_signals() -> Dict[str, Any]:
        """
        Return aggregate behaviour-intelligence signals for the current run.
        These are exported as span attributes on the root agent.run span.
        """
        calls = _tool_call_count.get() or 0
        switches = _tool_switch_count.get() or 0
        failures = _tool_failure_count.get() or 0
        retries = _retry_attempts.get() or 0
        ctx_overflow = bool(_context_overflow_flag.get())
        halluc = bool(_hallucination_suspected.get())

        switching_rate = 0.0
        if calls > 1:
            switching_rate = switches / float(calls - 1)

        repeated_failures = failures >= 2
        from puvinoise.schema import (
            BEHAVIOUR_TOOL_CALL_COUNT,
            BEHAVIOUR_TOOL_SWITCH_COUNT,
            BEHAVIOUR_TOOL_SWITCHING_RATE,
            BEHAVIOUR_TOOL_FAILURE_COUNT,
            BEHAVIOUR_REPEATED_TOOL_FAILURES,
            BEHAVIOUR_RETRY_ATTEMPTS,
            BEHAVIOUR_CONTEXT_OVERFLOW,
            BEHAVIOUR_HALLUCINATION_SUSPECTED,
        )
        return {
            BEHAVIOUR_TOOL_CALL_COUNT: calls,
            BEHAVIOUR_TOOL_SWITCH_COUNT: switches,
            BEHAVIOUR_TOOL_SWITCHING_RATE: switching_rate,
            BEHAVIOUR_TOOL_FAILURE_COUNT: failures,
            BEHAVIOUR_REPEATED_TOOL_FAILURES: repeated_failures,
            BEHAVIOUR_RETRY_ATTEMPTS: retries,
            BEHAVIOUR_CONTEXT_OVERFLOW: ctx_overflow,
            BEHAVIOUR_HALLUCINATION_SUSPECTED: halluc,
        }

    @staticmethod
    def get_context() -> dict:
        """Get all current context values as a dictionary (includes v2 + behaviour signals)."""
        data: Dict[str, Any] = {
            "run_id": _run_id.get(),
            "agent_name": _agent_name.get(),
            "goal": _goal.get(),
            "task_type": _task_type.get(),
            "intent": _intent.get(),
            "agent_state": _agent_state.get(),
            "session_id": _session_id.get(),
            "model_used": _model_used.get(),
            "prompt_hash": _prompt_hash.get(),
            "turn_index": AgentContext.get_turn_index(),
            "message_id": _message_id.get(),
            "reasoning_depth": AgentContext.get_reasoning_depth(),
            "model_provider": _model_provider.get(),
            "context_size": AgentContext.get_context_size(),
        }
        data.update(AgentContext.get_behaviour_signals())
        return data
    
    @staticmethod
    def is_active() -> bool:
        """Check if there's an active agent context."""
        return _run_id.get() is not None