"""
Agent lifecycle wrappers for auto-instrumentation.
Captures timestamps, latency, tool execution time, model used, and errors
without requiring manual telemetry calls.
"""

from __future__ import annotations

import os
import time
from contextlib import contextmanager
from typing import Any, Callable, Optional, TypeVar

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

from puvinoise.context import AgentContext

_tracer = trace.get_tracer("agent.lifecycle")

F = TypeVar("F", bound=Callable[..., Any])


def _default_agent_name() -> str:
    return (os.getenv("CUST_AGENT_NAME") or "default-agent").strip()


@contextmanager
def agent_start(
    agent_name: Optional[str] = None,
    goal: Optional[str] = None,
    task_type: Optional[str] = None,
    intent: Optional[str] = None,
    session_id: Optional[str] = None,
    turn_index: Optional[int] = None,
    message_id: Optional[str] = None,
):
    """
    Context manager that starts an agent run span and sets agent context.
    Automatically records start timestamp; on exit records duration and status (including errors).
    Use when you want fine-grained control; for a single callable use wrapAgent() instead.

    Example::

        with agent_start(agent_name="my-agent", goal="answer user"):
            ... do work ...
    """
    name = (agent_name or _default_agent_name()).strip()
    ctx = AgentContext(
        name,
        goal=goal,
        task_type=task_type,
        intent=intent,
        session_id=session_id,
        turn_index=turn_index,
        message_id=message_id,
    )
    ctx.activate()
    tenant_id = (os.getenv("PUVINOISE_TENANTID") or "").strip()
    llm_provider = (os.getenv("CUST_LLM_PROVIDER") or "").strip()
    start_ns = time.perf_counter_ns()

    with _tracer.start_as_current_span("agent.run") as span:
        span.set_attribute("agent.run_id", ctx.run_id)
        span.set_attribute("agent.name", ctx.agent_name)
        span.set_attribute("agent.lifecycle", "agent_start")
        if tenant_id:
            span.set_attribute("tenant.id", tenant_id)
        if llm_provider:
            span.set_attribute("puvinoise.llm_provider", llm_provider)
            span.set_attribute("llm.provider", llm_provider)
        if goal:
            span.set_attribute("agent.goal", str(goal)[:500])
        if task_type:
            span.set_attribute("agent.task_type", str(task_type)[:200])
        if intent:
            span.set_attribute("agent.intent", str(intent)[:200])
        if turn_index is not None:
            span.set_attribute("decision.turn_index", int(turn_index))
        if message_id is not None:
            span.set_attribute("decision.message_id", str(message_id)[:200])

        try:
            yield span
            span.set_status(Status(StatusCode.OK))
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            raise
        finally:
            duration_ms = (time.perf_counter_ns() - start_ns) / 1e6
            span.set_attribute("agent.duration_ms", duration_ms)


@contextmanager
def agent_step(name: str = "step"):
    """
    Context manager for one agent step. Records span name and latency automatically.

    Example::

        with agent_step("reasoning"):
            ... step logic ...
    """
    start_ns = time.perf_counter_ns()
    with _tracer.start_as_current_span("agent.step") as span:
        span.set_attribute("agent.step_name", name[:200])
        try:
            yield span
            span.set_status(Status(StatusCode.OK))
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            raise
        finally:
            duration_ms = (time.perf_counter_ns() - start_ns) / 1e6
            span.set_attribute("agent.step_duration_ms", duration_ms)


def tool_call(tool_name: Optional[str] = None) -> Callable[[F], F]:
    """
    Decorator that wraps a tool function. Automatically captures tool execution time,
    success/error, and emits tool_result telemetry.

    Example::

        @tool_call("web_search")
        def search(query: str):
            return do_search(query)

        @tool_call   # uses function __name__ as tool name
        def calculator(expr: str):
            return eval(expr)
    """
    # Backward compat: @tool_call without parens
    if callable(tool_name):
        func, tool_name = tool_name, None
        return tool_call(None)(func)

    def decorator(func: F) -> F:
        from functools import wraps
        from puvinoise.decision_telemetry import record_tool_execution_result
        from puvinoise.context import AgentContext

        name = (tool_name or getattr(func, "__name__", "tool")).strip()

        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            start_ns = time.perf_counter_ns()
            with _tracer.start_as_current_span(f"tool.{name}") as span:
                span.set_attribute("tool.name", name)
                if AgentContext.get_run_id():
                    span.set_attribute("agent.run_id", AgentContext.get_run_id())
                if AgentContext.get_agent_name():
                    span.set_attribute("agent.name", AgentContext.get_agent_name())
                try:
                    result = func(*args, **kwargs)
                    duration_ms = (time.perf_counter_ns() - start_ns) / 1e6
                    span.set_status(Status(StatusCode.OK))
                    span.set_attribute("tool.duration_ms", duration_ms)
                    record_tool_execution_result(
                        tool_name=name,
                        success=True,
                        duration_ms=duration_ms,
                    )
                    # Update behaviour counters for successful tool call
                    AgentContext.increment_tool_call(name, success=True)
                    return result
                except Exception as e:
                    duration_ms = (time.perf_counter_ns() - start_ns) / 1e6
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    span.set_attribute("tool.duration_ms", duration_ms)
                    record_tool_execution_result(
                        tool_name=name,
                        success=False,
                        duration_ms=duration_ms,
                        error_code=type(e).__name__,
                    )
                    # Update behaviour counters for failed tool call
                    AgentContext.increment_tool_call(name, success=False)
                    raise
        return wrapper  # type: ignore[return-value]
    return decorator


def tool_result(
    tool_name: str,
    success: bool,
    duration_ms: Optional[float] = None,
    result_summary: Optional[str] = None,
    error_code: Optional[str] = None,
) -> None:
    """
    Explicitly record a tool result (e.g. when not using the tool_call decorator).
    """
    from puvinoise.decision_telemetry import record_tool_execution_result
    record_tool_execution_result(
        tool_name=tool_name,
        success=success,
        duration_ms=duration_ms,
        result_summary=result_summary,
        error_code=error_code,
    )


def reasoning_complete(
    summary: str,
    model_used: Optional[str] = None,
    latency_ms: Optional[float] = None,
    step_index: Optional[int] = None,
) -> None:
    """
    Record that reasoning is complete. Sets model_used and latency on context/span when provided.
    """
    from puvinoise.context import AgentContext
    from puvinoise.decision_telemetry import record_llm_reasoning_finished

    if model_used is not None:
        AgentContext.set_model_used(model_used)
    record_llm_reasoning_finished(summary=summary, step_index=step_index)
    span = trace.get_current_span()
    if span and span.is_recording():
        if model_used is not None:
            span.set_attribute("llm.model", model_used)
        if latency_ms is not None:
            span.set_attribute("llm.latency_ms", latency_ms)


def task_complete(
    success: bool = True,
    outcome: str = "success",
    reason: Optional[str] = None,
) -> None:
    """
    Record task completion and set trace outcome. Call at end of agent run (or use wrapAgent to auto-capture).
    """
    from puvinoise.decision_telemetry import set_trace_outcome, record_outcome
    from puvinoise.context import AgentContext
    from opentelemetry import trace

    if not success and outcome == "success":
        outcome = "failure"
    set_trace_outcome(outcome, reason=reason)
    record_outcome(success=success)
    # Attach aggregate behaviour signals and goal tracking to the current span (agent.run)
    from puvinoise.schema import BEHAVIOUR_GOAL_COMPLETED, BEHAVIOUR_GOAL_PROGRESS
    span = trace.get_current_span()
    if span and span.is_recording():
        signals = AgentContext.get_behaviour_signals()
        for k, v in signals.items():
            span.set_attribute(k, v)
        span.set_attribute(BEHAVIOUR_GOAL_COMPLETED, bool(success))
        span.set_attribute(BEHAVIOUR_GOAL_PROGRESS, 1.0 if success else 0.0)
