"""
Reliable telemetry buffer: local queue, batch send, retry with exponential backoff,
and offline persistence so telemetry is never lost when the API is temporarily unavailable.
"""

from __future__ import annotations

import json
import logging
import os
import queue
import threading
import time
import uuid
from pathlib import Path
from typing import Any, Callable, List, Optional

logger = logging.getLogger(__name__)

_DEFAULT_PERSIST_DIR = os.environ.get("PUVINOISE_TELEMETRY_PERSIST_DIR") or os.path.join(
    os.path.expanduser("~"), ".puvinoise", "telemetry_queue"
)
_DEFAULT_MAX_QUEUE = int(os.environ.get("PUVINOISE_TELEMETRY_QUEUE_MAX", "8192"))
_DEFAULT_BATCH_SIZE = int(os.environ.get("PUVINOISE_TELEMETRY_BATCH_SIZE", "64"))
_DEFAULT_FLUSH_INTERVAL_SEC = float(os.environ.get("PUVINOISE_TELEMETRY_FLUSH_INTERVAL_SEC", "2.0"))
_DEFAULT_MAX_RETRIES = int(os.environ.get("PUVINOISE_TELEMETRY_MAX_RETRIES", "5"))
_DEFAULT_BASE_DELAY_SEC = float(os.environ.get("PUVINOISE_TELEMETRY_BASE_DELAY_SEC", "1.0"))
_DEFAULT_MAX_DELAY_SEC = float(os.environ.get("PUVINOISE_TELEMETRY_MAX_DELAY_SEC", "60.0"))


def _exponential_backoff(attempt: int, base: float, cap: float) -> float:
    delay = base * (2.0 ** attempt)
    return min(cap, max(0, delay))


class ReliableTelemetryBuffer:
    """
    In-memory buffer that batches items and sends them via a callback.
    On send failure: retries with exponential backoff; after max retries persists batch to disk.
    On startup (or via replay_persisted): loads persisted batches and re-queues for sending.
    """

    def __init__(
        self,
        send_batch: Callable[[List[dict]], bool],
        *,
        persist_dir: Optional[str] = None,
        max_queue_size: int = _DEFAULT_MAX_QUEUE,
        batch_size: int = _DEFAULT_BATCH_SIZE,
        flush_interval_sec: float = _DEFAULT_FLUSH_INTERVAL_SEC,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        base_delay_sec: float = _DEFAULT_BASE_DELAY_SEC,
        max_delay_sec: float = _DEFAULT_MAX_DELAY_SEC,
    ):
        self._send_batch = send_batch
        self._persist_dir = Path(persist_dir or _DEFAULT_PERSIST_DIR)
        self._max_queue_size = max(1, max_queue_size)
        self._batch_size = min(max(1, batch_size), self._max_queue_size)
        self._flush_interval_sec = max(0.1, flush_interval_sec)
        self._max_retries = max(0, max_retries)
        self._base_delay_sec = base_delay_sec
        self._max_delay_sec = max_delay_sec

        self._q: queue.Queue = queue.Queue(maxsize=self._max_queue_size)
        self._lock = threading.Lock()
        self._worker: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._persisted_count = 0
        self._sent_count = 0
        self._failed_count = 0

    def start(self) -> None:
        """Create persist dir and start the background sender thread."""
        self._persist_dir.mkdir(parents=True, exist_ok=True)
        if self._worker is None or not self._worker.is_alive():
            self._stop.clear()
            self._worker = threading.Thread(target=self._run_worker, daemon=True)
            self._worker.start()
            logger.debug("ReliableTelemetryBuffer worker started")

    def stop(self) -> None:
        """Signal worker to stop (call flush before shutdown to drain queue)."""
        self._stop.set()

    def add(self, payload: dict) -> bool:
        """
        Add one telemetry payload to the buffer. Non-blocking.
        If queue is full, persists payload to disk immediately so it is not lost.
        Returns True if queued, False if persisted to disk (will be replayed later).
        """
        try:
            self._q.put_nowait(payload)
            return True
        except queue.Full:
            self._persist_batch([payload])
            return False

    def flush(self, timeout_sec: float = 10.0) -> None:
        """Drain queue and send remaining batches; then try to replay persisted files."""
        deadline = time.monotonic() + timeout_sec
        batch: List[dict] = []
        while time.monotonic() < deadline:
            try:
                batch.append(self._q.get_nowait())
                if len(batch) >= self._batch_size:
                    self._send_with_retry(batch)
                    batch = []
            except queue.Empty:
                break
        if batch:
            self._send_with_retry(batch)
        self._replay_persisted()

    def _run_worker(self) -> None:
        batch: List[dict] = []
        next_flush = time.monotonic() + self._flush_interval_sec
        while not self._stop.is_set():
            try:
                try:
                    item = self._q.get(timeout=0.25)
                    batch.append(item)
                except queue.Empty:
                    pass
                now = time.monotonic()
                if batch and (len(batch) >= self._batch_size or now >= next_flush):
                    self._send_with_retry(batch)
                    batch = []
                    next_flush = now + self._flush_interval_sec
                elif now >= next_flush:
                    next_flush = now + self._flush_interval_sec
                    self._replay_persisted()
            except Exception as e:
                logger.warning("ReliableTelemetryBuffer worker error: %s", e)
        if batch:
            self._send_with_retry(batch)

    def _send_with_retry(self, batch: List[dict]) -> None:
        for attempt in range(self._max_retries + 1):
            try:
                ok = self._send_batch(batch)
                if ok:
                    with self._lock:
                        self._sent_count += len(batch)
                    return
            except Exception as e:
                if attempt < self._max_retries:
                    delay = _exponential_backoff(attempt, self._base_delay_sec, self._max_delay_sec)
                    logger.debug("Telemetry send failed (attempt %s), retry in %.1fs: %s", attempt + 1, delay, e)
                    time.sleep(delay)
                else:
                    logger.warning("Telemetry send failed after %s retries, persisting batch: %s", self._max_retries, e)
                    with self._lock:
                        self._failed_count += len(batch)
                    self._persist_batch(batch)
                    return
        self._persist_batch(batch)

    def _persist_batch(self, batch: List[dict]) -> None:
        if not batch:
            return
        self._persist_dir.mkdir(parents=True, exist_ok=True)
        path = self._persist_dir / f"batch_{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}.json"
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(batch, f, default=str)
            with self._lock:
                self._persisted_count += len(batch)
            logger.debug("Persisted telemetry batch to %s (%s items)", path, len(batch))
        except Exception as e:
            logger.error("Failed to persist telemetry batch: %s", e)

    def _replay_persisted(self) -> None:
        if not self._persist_dir.exists():
            return
        for path in sorted(self._persist_dir.glob("batch_*.json")):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    batch = json.load(f)
                if not batch:
                    path.unlink(missing_ok=True)
                    continue
                ok = False
                for attempt in range(self._max_retries + 1):
                    try:
                        ok = self._send_batch(batch)
                        if ok:
                            break
                    except Exception as e:
                        if attempt < self._max_retries:
                            time.sleep(_exponential_backoff(attempt, self._base_delay_sec, self._max_delay_sec))
                        else:
                            logger.warning("Replay failed for %s: %s", path, e)
                if ok:
                    path.unlink(missing_ok=True)
                    with self._lock:
                        self._sent_count += len(batch)
            except Exception as e:
                logger.warning("Failed to replay %s: %s", path, e)

    def replay_persisted(self) -> int:
        """Load all persisted batch files and re-queue for sending. Returns number of items re-queued."""
        requeued = 0
        if not self._persist_dir.exists():
            return 0
        for path in sorted(self._persist_dir.glob("batch_*.json")):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    batch = json.load(f)
                for item in batch:
                    try:
                        self._q.put_nowait(item)
                        requeued += 1
                    except queue.Full:
                        self._persist_batch(batch)
                        return requeued
                path.unlink(missing_ok=True)
            except Exception as e:
                logger.warning("Failed to load persisted batch %s: %s", path, e)
        return requeued

    def stats(self) -> dict:
        with self._lock:
            return {
                "queue_size": self._q.qsize(),
                "queue_max": self._max_queue_size,
                "sent_count": self._sent_count,
                "persisted_count": self._persisted_count,
                "failed_count": self._failed_count,
            }


# Singleton for decision-event fallback (optional HTTP ingest)
_decision_buffer: Optional[ReliableTelemetryBuffer] = None
_decision_buffer_lock = threading.Lock()


def get_decision_buffer() -> Optional[ReliableTelemetryBuffer]:
    return _decision_buffer


def set_decision_buffer(buffer: Optional[ReliableTelemetryBuffer]) -> None:
    global _decision_buffer
    with _decision_buffer_lock:
        _decision_buffer = buffer


def _get_sdk_version() -> str:
    try:
        from puvinoise import __version__
        return str(__version__)
    except Exception:
        return "0.0.0"


def _http_send_batch(ingest_url: str, api_key: str, org_id: str, project_id: str, env: str, batch: List[dict]) -> bool:
    """POST a batch of events to the ingest API. Returns True on 2xx. Sends X-SDK-Version and X-Telemetry-Schema-Version."""
    if not batch:
        return True
    try:
        import urllib.request
        url = ingest_url.rstrip("/") + "/telemetry/batch"
        if not url.startswith("http"):
            url = "https://" + url
        data = json.dumps(batch, default=str).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
            "X-Organization-Id": org_id,
            "X-Project-Id": project_id,
            "X-Environment": env,
            "X-SDK-Version": _get_sdk_version(),
            "X-Telemetry-Schema-Version": "v2",
            "User-Agent": f"puvinoise-sdk/{_get_sdk_version()}",
        }
        req = urllib.request.Request(
            url,
            data=data,
            headers=headers,
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            return 200 <= resp.status < 300
    except Exception as e:
        logger.debug("HTTP ingest batch failed: %s", e)
        raise


def decision_attrs_to_ingest_event(event_name: str, attrs: dict) -> dict:
    """Build an ingest-API event dict from decision event_name + attrs (for reliable buffer)."""
    import time as _time
    ts_ns = attrs.get("timestamp_ns")
    if ts_ns is not None:
        timestamp = int(ts_ns) // 1_000_000  # ms
    else:
        timestamp = int(_time.time() * 1000)
    return {
        "agent_id": attrs.get("agent_id", "unknown"),
        "event_type": "decision",
        "timestamp": timestamp,
        "success_flag": True,
        "policy_violation": False,
        "metadata": {"event_name": event_name, **attrs},
    }


def init_decision_buffer_from_env() -> Optional[ReliableTelemetryBuffer]:
    """
    If PUVINOISE_INGEST_URL, PUVINOISE_AGENTACCESSKEY, and org/project/env are set,
    create and start a ReliableTelemetryBuffer that POSTs decision events to the ingest API.
    Returns the buffer or None if not configured.
    """
    ingest_url = (os.environ.get("PUVINOISE_INGEST_URL") or "").strip()
    api_key = (os.environ.get("PUVINOISE_AGENTACCESSKEY") or "").strip()
    org_id = (os.environ.get("PUVINOISE_ORGANIZATION_ID") or os.environ.get("PUVINOISE_TENANTID") or "").strip()
    project_id = (os.environ.get("PUVINOISE_PROJECT_ID") or "").strip()
    env = (os.environ.get("PUVINOISE_ENVIRONMENT") or "production").strip()
    if not ingest_url or not api_key or not org_id or not project_id:
        return None
    persist_dir = os.environ.get("PUVINOISE_TELEMETRY_PERSIST_DIR") or os.path.join(
        os.path.expanduser("~"), ".puvinoise", "telemetry_queue"
    )
    def send_batch(batch: List[dict]) -> bool:
        return _http_send_batch(ingest_url, api_key, org_id, project_id, env, batch)
    buffer = ReliableTelemetryBuffer(
        send_batch,
        persist_dir=persist_dir,
    )
    buffer.start()
    set_decision_buffer(buffer)
    return buffer
