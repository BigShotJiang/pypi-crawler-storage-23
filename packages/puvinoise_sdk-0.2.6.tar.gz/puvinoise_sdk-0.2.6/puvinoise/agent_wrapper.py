"""
Wrap an agent for automatic telemetry with minimal code change.
Usage: wrapped = puvinoise.wrapAgent(agent)
       result = wrapped(input)  # or wrapped.run(input)
"""

from __future__ import annotations

from functools import wraps
from typing import Any, Callable, Optional, TypeVar, Union

from puvinoise.tracer import run_with_trace
from puvinoise.agent_lifecycle import task_complete
from puvinoise.hooks import instrument_tool_call

T = TypeVar("T")


def _resolve_agent_name(agent: Any, default: str = "agent") -> str:
    if hasattr(agent, "name") and agent.name:
        return str(agent.name).strip()
    if hasattr(agent, "__name__"):
        return str(agent.__name__).strip() or default
    if hasattr(agent, "__class__"):
        return getattr(agent.__class__, "__name__", default) or default
    return default


def _wrap_tools(agent: Any) -> None:
    """If agent has .tools (list or dict of callables), wrap each with instrument_tool_call."""
    tools = getattr(agent, "tools", None)
    if not tools:
        return
    if isinstance(tools, dict):
        for name, fn in list(tools.items()):
            if callable(fn) and not getattr(fn, "_puvinoise_instrumented", False):
                tools[name] = instrument_tool_call(str(name)[:256])(fn)
                try:
                    tools[name]._puvinoise_instrumented = True
                except Exception:
                    pass
    elif isinstance(tools, (list, tuple)):
        for i, fn in enumerate(tools):
            if callable(fn) and not getattr(fn, "_puvinoise_instrumented", False):
                name = getattr(fn, "__name__", None) or f"tool_{i}"
                wrapped = instrument_tool_call(str(name)[:256])(fn)
                try:
                    wrapped._puvinoise_instrumented = True
                except Exception:
                    pass
                tools[i] = wrapped


def wrapAgent(
    agent: Union[Callable[..., T], Any],
    agent_name: Optional[str] = None,
    goal: Optional[str] = None,
    task_type: Optional[str] = None,
    intent: Optional[str] = None,
    session_id: Optional[str] = None,
    turn_index: Optional[int] = None,
    message_id: Optional[str] = None,
    wrap_tools: bool = True,
) -> Union[Callable[..., T], Any]:
    """
    Wrap an agent so that runs are automatically traced and task outcome is recorded.

    - If agent is a callable (e.g. a function): returns a wrapped callable. Call as wrapped(*args, **kwargs).
    - If agent has a .run method: returns the same object with .run replaced by a traced version. Call as agent.run(*args, **kwargs).
    - If agent has a .invoke method: returns the same object with .invoke replaced (same as .run).
    - Optionally wraps agent.tools (list or dict of callables) so tool calls are auto-instrumented.

    Automatically captures: timestamps, latency, errors, and calls task_complete on success/failure.

    Example::

        from puvinoise import wrapAgent, bootstrap

        bootstrap()
        my_agent = MyAgent()
        agent = wrapAgent(my_agent, agent_name="my-agent")
        result = agent.run(user_input)  # or agent(user_input) if callable
    """
    name = (agent_name or _resolve_agent_name(agent)).strip()
    run_kw = {
        "agent_name": name,
        "goal": goal,
        "task_type": task_type,
        "intent": intent,
        "session_id": session_id,
        "turn_index": turn_index,
        "message_id": message_id,
    }

    def run_traced(fn: Callable[..., T], *args: Any, **kwargs: Any) -> T:
        # Merge run_kw with kwargs; run_with_trace strips telemetry keys before passing to fn
        merged = {**run_kw, **kwargs}
        try:
            result = run_with_trace(fn, *args, **merged)
            task_complete(success=True, outcome="success")
            return result
        except Exception as e:
            task_complete(success=False, outcome="failure", reason=str(e)[:200])
            raise

    if callable(agent) and not hasattr(agent, "run") and not hasattr(agent, "invoke"):
        # Bare callable (e.g. a function)
        @wraps(agent)  # type: ignore[arg-type]
        def wrapped(*args: Any, **kwargs: Any) -> T:
            return run_traced(lambda: agent(*args, **kwargs))
        return wrapped  # type: ignore[return-value]

    # Object with .run or .invoke
    if hasattr(agent, "run") and callable(getattr(agent, "run")):
        orig_run = agent.run
        @wraps(orig_run)  # type: ignore[arg-type]
        def wrapped_run(*args: Any, **kwargs: Any) -> T:
            return run_traced(orig_run, *args, **kwargs)
        agent.run = wrapped_run  # type: ignore[method-assign]
    if hasattr(agent, "invoke") and callable(getattr(agent, "invoke")):
        orig_invoke = agent.invoke
        @wraps(orig_invoke)  # type: ignore[arg-type]
        def wrapped_invoke(*args: Any, **kwargs: Any) -> T:
            return run_traced(orig_invoke, *args, **kwargs)
        agent.invoke = wrapped_invoke  # type: ignore[method-assign]

    if wrap_tools:
        _wrap_tools(agent)
    return agent
