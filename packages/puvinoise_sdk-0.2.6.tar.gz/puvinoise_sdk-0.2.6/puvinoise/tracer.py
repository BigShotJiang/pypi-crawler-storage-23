from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode
from puvinoise.context import AgentContext
import os

_tracer = trace.get_tracer("agent.runtime")


def run_with_trace(
    fn,
    agent_name=None,
    goal=None,
    task_type=None,
    intent=None,
    session_id=None,
    turn_index=None,
    message_id=None,
    outcome=None,
    outcome_reason=None,
    *args,
    **kwargs,
):
    """
    Wraps a function execution with OpenTelemetry tracing and agent context.
    Optional goal, task_type, intent, session_id, turn_index, message_id are set for decision telemetry.
    If outcome is provided (success|failure|timeout|cancelled|partial), it is set on the root span after the run.

    Args:
        fn: The function to execute
        agent_name: Name of the agent (defaults to env CUST_AGENT_NAME)
        goal: Optional goal string (decision telemetry)
        task_type: Optional task type (decision telemetry)
        intent: Optional intent classification (decision telemetry)
        session_id: Optional session/conversation ID (decision telemetry envelope)
        turn_index: Optional 1-based turn number in session (decision telemetry envelope)
        message_id: Optional request/message ID (decision telemetry envelope)
        outcome: Optional explicit trace outcome: success|failure|timeout|cancelled|partial
        outcome_reason: Optional short reason for outcome
        *args, **kwargs: Arguments to pass to the function
    """
    puvicustagentname = (os.getenv("CUST_AGENT_NAME") or "").strip()
    name = (agent_name or puvicustagentname or "default-agent").strip()
    ctx = AgentContext(
        name,
        goal=goal,
        task_type=task_type,
        intent=intent,
        session_id=session_id,
        turn_index=turn_index,
        message_id=message_id,
    )
    ctx.activate()

    # Emit env-derived params as span attributes so collector/backend can filter and display
    tenant_id = (os.getenv("PUVINOISE_TENANTID") or "").strip()
    llm_provider = (os.getenv("CUST_LLM_PROVIDER") or "").strip()

    with _tracer.start_as_current_span("agent.run") as span:
        span.set_attribute("agent.run_id", ctx.run_id)
        span.set_attribute("agent.name", ctx.agent_name)
        if tenant_id:
            span.set_attribute("tenant.id", tenant_id)
        if llm_provider:
            span.set_attribute("puvinoise.llm_provider", llm_provider)
            span.set_attribute("llm.provider", llm_provider)
        # Decision telemetry: intent/goal/task_type from context (if set)
        if getattr(ctx, "_goal", None):
            span.set_attribute("agent.goal", str(ctx._goal)[:500])
        if getattr(ctx, "_task_type", None):
            span.set_attribute("agent.task_type", str(ctx._task_type)[:200])
            span.set_attribute("agent.task", str(ctx._task_type)[:200])
        if getattr(ctx, "_intent", None):
            span.set_attribute("agent.intent", str(ctx._intent)[:200])
        if turn_index is not None:
            span.set_attribute("decision.turn_index", int(turn_index))
        if message_id is not None:
            span.set_attribute("decision.message_id", str(message_id)[:200])

        error_occurred = False
        try:
            # Execute the function (pop decision-telemetry keys so they are not passed to fn)
            kwargs_for_fn = {
                k: v for k, v in kwargs.items()
                if k not in ("goal", "task_type", "intent", "turn_index", "message_id", "outcome", "outcome_reason")
            }
            result = fn(*args, **kwargs_for_fn)
            return result

        except Exception as e:
            error_occurred = True
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            raise

        finally:
            # Always set status so backends (e.g. Jaeger) don't treat the span as error when it succeeded
            if not error_occurred and span.is_recording():
                span.set_status(Status(StatusCode.OK))
            if outcome is not None and span.is_recording():
                span.set_attribute("decision.trace_outcome", str(outcome)[:50])
                if outcome_reason is not None:
                    span.set_attribute("decision.trace_outcome_reason", str(outcome_reason)[:200])