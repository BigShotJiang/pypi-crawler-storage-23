"""ChromaDB vector store wrapper with batched operations.

This module provides a high-level wrapper around ChromaDB collections
with support for persistence, batched document ingestion, and automatic
embedding function configuration.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, cast
from uuid import uuid4

from chromaroute.config import EmbedConfig, load_config
from chromaroute.embedding import build_embedding_function

if TYPE_CHECKING:
    from chromadb.api.types import EmbeddingFunction, Include, Metadata, Where, WhereDocument

logger = logging.getLogger(__name__)


class VectorStore:
    """High-level wrapper for ChromaDB vector store operations.

    This class provides a simplified interface for common vector store
    operations including document ingestion, querying, and collection
    management.

    Args:
        collection_name: Name of the ChromaDB collection.
        persist_path: Optional path for persistent storage.
        embedding_model: Optional model name override.
        embed_provider: Optional provider override.
        embedding_function: Optional pre-configured embedding function.
        client: Optional pre-configured ChromaDB client.

    Example:
        >>> from chromaroute import VectorStore
        >>> store = VectorStore("my_docs", persist_path="./chroma_db")
        >>> store.add_documents(["Hello world", "Goodbye world"])
        >>> results = store.query(["greeting"], n_results=1)
    """

    def __init__(
        self,
        collection_name: str,
        persist_path: str | None = None,
        embedding_model: str | None = None,
        embed_provider: str | None = None,
        embedding_function: EmbeddingFunction[Any] | None = None,
        client: Any | None = None,
        config: EmbedConfig | None = None,
    ) -> None:
        self.collection_name = collection_name

        import chromadb

        # Initialize ChromaDB client
        self.client = client or (
            chromadb.PersistentClient(path=persist_path)
            if persist_path
            else chromadb.EphemeralClient()
        )

        # Configure embedding function
        if embedding_function is not None:
            self.embedding_function = embedding_function
        else:
            cfg = config or load_config()
            self.embedding_function = build_embedding_function(
                config=cfg,
                embedding_model=embedding_model,
                embed_provider=embed_provider,
            )

        self.collection = self.client.get_or_create_collection(
            name=self.collection_name,
            embedding_function=self.embedding_function,
            metadata={"hnsw:space": "cosine"},
        )
        logger.info("Ready collection: %s", self.collection_name)

    def add_documents(
        self,
        documents: list[str],
        ids: list[str] | None = None,
        metadatas: list[Metadata] | None = None,
        batch_size: int = 100,
    ) -> None:
        """Add documents to the collection with batching.

        Args:
            documents: List of document strings to add.
            ids: Optional list of unique IDs. If not provided,
                UUID-based IDs will be generated (``doc-<uuid>``).
            metadatas: Optional per-document metadata dictionaries.
            batch_size: Number of documents per batch to avoid API limits.
        """
        if batch_size <= 0:
            raise ValueError("batch_size must be a positive integer.")
        if ids is not None and len(ids) != len(documents):
            raise ValueError("ids must have the same length as documents.")
        if metadatas is not None and len(metadatas) != len(documents):
            raise ValueError("metadatas must have the same length as documents.")

        if ids is None:
            ids = [f"doc-{uuid4().hex}" for _ in documents]

        total = len(documents)
        for i in range(0, total, batch_size):
            batch_docs = documents[i : i + batch_size]
            batch_ids = ids[i : i + batch_size]
            kwargs: dict[str, Any] = {"documents": batch_docs, "ids": batch_ids}
            if metadatas is not None:
                kwargs["metadatas"] = metadatas[i : i + batch_size]
            self.collection.add(**kwargs)

        logger.info("Added %s documents to collection '%s'", total, self.collection_name)

    def query(
        self,
        query_texts: str | list[str],
        n_results: int = 3,
        where: Where | None = None,
        where_document: WhereDocument | None = None,
        include: Include | None = None,
    ) -> dict[str, Any]:
        """Query the collection for similar documents.

        Args:
            query_texts: List of query strings or a single query string.
            n_results: Number of results to return per query.
            where: Optional metadata filter dict.
            where_document: Optional document text filter dict.
            include: Optional include list passed directly to ChromaDB.
                If *None*, ChromaDB defaults are used.

        Returns:
            Query results in ChromaDB's native shape.
            Results are nested per query, for example:
            ``{"ids": [[...]], "documents": [[...]], "metadatas": [[...]]}``.
            For single-query convenience, see :meth:`query_one_records`.
        """
        if isinstance(query_texts, str):
            query_texts = [query_texts]

        kwargs: dict[str, Any] = {
            "query_texts": query_texts,
            "n_results": n_results,
        }
        if where is not None:
            kwargs["where"] = where
        if where_document is not None:
            kwargs["where_document"] = where_document
        if include is not None:
            kwargs["include"] = include
        results = self.collection.query(**kwargs)
        return cast("dict[str, Any]", results)

    def query_one_records(
        self,
        query_text: str,
        n_results: int = 3,
        where: Where | None = None,
        where_document: WhereDocument | None = None,
        include: Include | None = None,
    ) -> list[dict[str, Any]]:
        """Query once and return result-aligned records.

        Each record always includes ``"id"`` and conditionally includes
        ``"document"``, ``"distance"``, ``"metadata"``, ``"embedding"``,
        ``"uri"``, and ``"data"`` when those fields are present.
        """
        results = self.query(
            query_texts=[query_text],
            n_results=n_results,
            where=where,
            where_document=where_document,
            include=include,
        )
        raw_ids = results.get("ids", [])
        ids = cast("list[str]", raw_ids[0] if isinstance(raw_ids, list) and raw_ids else [])
        records = [{"id": doc_id} for doc_id in ids]
        field_map = {
            "documents": "document",
            "distances": "distance",
            "metadatas": "metadata",
            "embeddings": "embedding",
            "uris": "uri",
            "data": "data",
        }

        for source_key, record_key in field_map.items():
            values = results.get(source_key)
            if isinstance(values, list):
                row_values = values[0] if values and isinstance(values[0], list) else values
                for record, value in zip(records, row_values, strict=False):
                    record[record_key] = value

        return records

    def get(
        self,
        ids: list[str] | None = None,
        limit: int | None = None,
        offset: int | None = None,
        where: Where | None = None,
        where_document: WhereDocument | None = None,
        include: Include | None = None,
    ) -> dict[str, Any]:
        """Retrieve documents from the collection.

        Args:
            ids: Optional list of document IDs to retrieve.
                If *None*, returns all documents (subject to *limit*/*offset*).
            limit: Maximum number of documents to return.
            offset: Number of documents to skip before returning results.
            where: Optional metadata filter dict.
            where_document: Optional document text filter dict.
            include: Optional include list passed directly to ChromaDB.
                If *None*, ChromaDB defaults are used.

        Returns:
            ChromaDB get result dict in native shape.
        """
        kwargs: dict[str, Any] = {}
        if ids is not None:
            kwargs["ids"] = ids
        if limit is not None:
            kwargs["limit"] = limit
        if offset is not None:
            kwargs["offset"] = offset
        if where is not None:
            kwargs["where"] = where
        if where_document is not None:
            kwargs["where_document"] = where_document
        if include is not None:
            kwargs["include"] = include
        results = self.collection.get(**kwargs)
        return cast("dict[str, Any]", results)

    def count(self) -> int:
        """Return the number of documents in the collection."""
        return cast("int", self.collection.count())

    def delete(
        self,
        ids: list[str] | None = None,
        where: Where | None = None,
        where_document: WhereDocument | None = None,
    ) -> None:
        """Delete documents from the collection.

        Args:
            ids: Optional list of document IDs to delete.
            where: Optional metadata filter dict.
            where_document: Optional document text filter dict.
        """
        kwargs: dict[str, Any] = {}
        if ids is not None:
            kwargs["ids"] = ids
        if where is not None:
            kwargs["where"] = where
        if where_document is not None:
            kwargs["where_document"] = where_document

        self.collection.delete(**kwargs)

    def delete_collection(self) -> None:
        """Delete the collection from the database."""
        self.client.delete_collection(self.collection_name)
        logger.info("Deleted collection: %s", self.collection_name)
