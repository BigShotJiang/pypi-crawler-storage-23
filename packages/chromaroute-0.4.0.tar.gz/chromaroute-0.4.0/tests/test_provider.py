"""Tests for provider factory and vector store."""

import pytest

from chromaroute import EmbedConfig, VectorStore, build_embedding_function


class DummyEmbedding:
    """Mock embedding function for testing."""

    pass


def _config(**overrides) -> EmbedConfig:
    """Create a test configuration."""
    data = {
        "openrouter_api_key": "ok",
        "openrouter_base_url": "https://openrouter.ai/api/v1",
        "openrouter_embeddings_model": "openai/text-embedding-3-small",
        "openrouter_referer": None,
        "openrouter_title": None,
        "openrouter_provider_json": None,
        "local_embeddings_model": "sentence-transformers/all-MiniLM-L6-v2",
        "embed_provider": "auto",
    }
    data.update(overrides)
    return EmbedConfig(**data)


def test_build_embedding_function_openrouter_requires_key():
    """Test OpenRouter requires API key."""
    config = _config(openrouter_api_key=None)
    with pytest.raises(ValueError, match="OPENROUTER_API_KEY"):
        build_embedding_function(config, embed_provider="openrouter")


def test_build_embedding_function_openrouter(monkeypatch):
    """Test OpenRouter embedding function creation."""
    config = _config(openrouter_api_key="ok")
    import chromaroute.embedding as embedding

    # Patch the registry entry directly since _PROVIDERS is used for dispatch
    monkeypatch.setitem(
        embedding._PROVIDERS,
        "openrouter",
        lambda cfg, model: DummyEmbedding(),
    )
    ef = build_embedding_function(config, embed_provider="openrouter")
    assert isinstance(ef, DummyEmbedding)


def test_build_embedding_function_local(monkeypatch):
    """Test local embedding function creation."""
    from chromadb.utils import embedding_functions

    config = _config(openrouter_api_key=None)
    monkeypatch.setattr(
        embedding_functions,
        "SentenceTransformerEmbeddingFunction",
        lambda model_name: DummyEmbedding(),
    )
    ef = build_embedding_function(config, embed_provider="local")
    assert isinstance(ef, DummyEmbedding)


def test_build_embedding_function_unknown_provider():
    """Test unknown provider raises ValueError."""
    config = _config()
    with pytest.raises(ValueError, match="Unknown embedding provider"):
        build_embedding_function(config, embed_provider="unknown")


def test_vector_store_add_documents_batches(monkeypatch):
    """Test document batching with generated IDs and metadata."""
    calls = []

    class FakeUUID:
        def __init__(self, value: str):
            self.hex = value

    values = iter(["u1", "u2", "u3"])
    monkeypatch.setattr("chromaroute.vector_store.uuid4", lambda: FakeUUID(next(values)))

    class FakeCollection:
        def add(self, **kwargs):
            calls.append(kwargs)

    store = VectorStore.__new__(VectorStore)
    store.collection_name = "test"
    store.collection = FakeCollection()

    store.add_documents(
        documents=["a", "b", "c"],
        ids=None,
        metadatas=[{"source_id": "s1"}, {"source_id": "s2"}, {"source_id": "s3"}],
        batch_size=2,
    )
    assert calls == [
        {
            "documents": ["a", "b"],
            "ids": ["doc-u1", "doc-u2"],
            "metadatas": [{"source_id": "s1"}, {"source_id": "s2"}],
        },
        {
            "documents": ["c"],
            "ids": ["doc-u3"],
            "metadatas": [{"source_id": "s3"}],
        },
    ]


def test_vector_store_add_documents_validation_errors():
    """Test add_documents validates batch size and input lengths."""
    store = VectorStore.__new__(VectorStore)
    store.collection = object()

    with pytest.raises(ValueError, match="batch_size"):
        store.add_documents(documents=["a"], batch_size=0)
    with pytest.raises(ValueError, match="ids"):
        store.add_documents(documents=["a", "b"], ids=["a"])
    with pytest.raises(ValueError, match="metadatas"):
        store.add_documents(
            documents=["a", "b"],
            metadatas=[{"source_id": "s1"}],
        )


def test_vector_store_query():
    """Test query passthrough."""
    captured = {}

    class FakeCollection:
        def query(self, **kwargs):
            captured.update(kwargs)
            return {"documents": [["result"]], "distances": [[0.1]]}

    store = VectorStore.__new__(VectorStore)
    store.collection = FakeCollection()
    results = store.query(query_texts=["test"], n_results=1)
    assert "include" not in captured
    assert "where" not in captured
    assert "where_document" not in captured
    assert captured["query_texts"] == ["test"]
    assert results["documents"][0][0] == "result"


def test_vector_store_query_string():
    """Test query accepts single string."""
    captured = {}

    class FakeCollection:
        def query(self, **kwargs):
            captured.update(kwargs)
            return {"documents": [["result"]], "distances": [[0.1]]}

    store = VectorStore.__new__(VectorStore)
    store.collection = FakeCollection()
    store.query(query_texts="test_string", n_results=1)
    assert captured["query_texts"] == ["test_string"]


def test_vector_store_query_include_passthrough():
    """Test query include list is passed through."""
    captured = {}

    class FakeCollection:
        def query(self, **kwargs):
            captured.update(kwargs)
            return {"documents": [["result"]], "metadatas": [[{"source_id": "s1"}]]}

    store = VectorStore.__new__(VectorStore)
    store.collection = FakeCollection()
    store.query(
        query_texts=["test"],
        n_results=1,
        include=["documents", "metadatas"],
        where={"source_id": "s1"},
        where_document={"$contains": "test"},
    )
    assert captured["include"] == ["documents", "metadatas"]
    assert captured["where"] == {"source_id": "s1"}
    assert captured["where_document"] == {"$contains": "test"}


def test_vector_store_with_embedding_function(monkeypatch):
    """Test VectorStore with provided embedding function."""
    captured = {}

    class FakeClient:
        def get_or_create_collection(self, name, embedding_function, metadata):
            captured["name"] = name
            captured["embedding_function"] = embedding_function
            captured["metadata"] = metadata
            return "collection"

    import types

    monkeypatch.setattr("chromaroute.vector_store.load_config", lambda: None)
    fake_chromadb = types.SimpleNamespace(EphemeralClient=lambda: FakeClient())
    monkeypatch.setitem(__import__("sys").modules, "chromadb", fake_chromadb)

    store = VectorStore(
        collection_name="test",
        embedding_function=DummyEmbedding(),
    )
    assert store.collection == "collection"
    assert captured["name"] == "test"
    assert captured["metadata"] == {"hnsw:space": "cosine"}
    assert captured["embedding_function"] is store.embedding_function


def test_vector_store_query_one_records():
    """Test query_one_records returns row-like records."""

    class FakeCollection:
        def query(self, **kwargs):
            assert kwargs["query_texts"] == ["greeting"]
            assert kwargs["include"] == ["documents", "metadatas", "distances"]
            return {
                "ids": [["doc1", "doc2"]],
                "documents": [["hello", "hi"]],
                "distances": [[0.1, 0.2]],
                "metadatas": [[{"source_id": "s1"}, {"source_id": "s2"}]],
            }

    store = VectorStore.__new__(VectorStore)
    store.collection = FakeCollection()
    results = store.query_one_records(
        "greeting",
        n_results=2,
        include=["documents", "metadatas", "distances"],
        where={"source_id": "s1"},
        where_document={"$contains": "hello"},
    )
    assert results == [
        {
            "id": "doc1",
            "document": "hello",
            "distance": 0.1,
            "metadata": {"source_id": "s1"},
        },
        {
            "id": "doc2",
            "document": "hi",
            "distance": 0.2,
            "metadata": {"source_id": "s2"},
        },
    ]


def test_vector_store_query_one_records_with_ids_only():
    """Test query_one_records still works when only IDs are returned."""

    class FakeCollection:
        def query(self, **kwargs):
            return {"ids": [["doc1", "doc2"]]}

    store = VectorStore.__new__(VectorStore)
    store.collection = FakeCollection()
    assert store.query_one_records("greeting", n_results=2) == [
        {"id": "doc1"},
        {"id": "doc2"},
    ]


def test_vector_store_get_by_ids():
    """Test get() retrieves records by ID in native shape."""

    class FakeCollection:
        def get(self, **kwargs):
            assert kwargs["ids"] == ["doc1", "doc3"]
            assert "limit" not in kwargs
            assert "include" not in kwargs
            return {
                "ids": ["doc1", "doc3"],
                "documents": ["hello", "goodbye"],
                "metadatas": [{"source_id": "a"}, {"source_id": "b"}],
                "included": ["metadatas", "documents"],
            }

    store = VectorStore.__new__(VectorStore)
    store.collection = FakeCollection()
    results = store.get(ids=["doc1", "doc3"])
    assert results == {
        "ids": ["doc1", "doc3"],
        "documents": ["hello", "goodbye"],
        "metadatas": [{"source_id": "a"}, {"source_id": "b"}],
        "included": ["metadatas", "documents"],
    }


def test_vector_store_get_all_with_pagination():
    """Test get() with no IDs returns all and supports include/offset/limit."""

    class FakeCollection:
        def get(self, **kwargs):
            assert "ids" not in kwargs
            assert kwargs["limit"] == 5
            assert kwargs["offset"] == 10
            assert kwargs["include"] == ["documents", "metadatas"]
            return {
                "ids": ["doc11"],
                "documents": ["page 3"],
                "metadatas": [{"source_id": "s11"}],
            }

    store = VectorStore.__new__(VectorStore)
    store.collection = FakeCollection()
    results = store.get(
        limit=5,
        offset=10,
        include=["documents", "metadatas"],
        where={"source_id": "s11"},
        where_document={"$contains": "page"},
    )
    assert results == {
        "ids": ["doc11"],
        "documents": ["page 3"],
        "metadatas": [{"source_id": "s11"}],
    }


def test_vector_store_count_and_delete_collection():
    """Test count passthrough and delete_collection call."""

    class FakeCollection:
        def count(self):
            return 3

    class FakeClient:
        def __init__(self):
            self.deleted = None

        def delete_collection(self, name):
            self.deleted = name

    store = VectorStore.__new__(VectorStore)
    store.collection_name = "to-delete"
    store.collection = FakeCollection()
    store.client = FakeClient()

    assert store.count() == 3
    store.delete_collection()
    assert store.client.deleted == "to-delete"


def test_vector_store_delete():
    """Test delete passes through arguments."""
    captured = {}

    class FakeCollection:
        def delete(self, **kwargs):
            captured.update(kwargs)

    store = VectorStore.__new__(VectorStore)
    store.collection = FakeCollection()
    store.delete(
        ids=["doc1"],
        where={"source_id": "s1"},
        where_document={"$contains": "test"},
    )
    assert captured["ids"] == ["doc1"]
    assert captured["where"] == {"source_id": "s1"}
    assert captured["where_document"] == {"$contains": "test"}
