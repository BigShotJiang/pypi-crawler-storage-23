LinkedBaseModel Class

# LinkedBaseModel
::: oold.static.GenericLinkedBaseModel

# LinkedBaseModel v1
::: oold.model.v1.LinkedBaseModel

# LinkedBaseModel v2
::: oold.model.LinkedBaseModel
