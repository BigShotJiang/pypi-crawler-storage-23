"""
kbase - 知识库管理模块

提供向量知识库创建、PDF解析、多知识库管理等功能。
"""

from .vector_kb import create_vector_kb
from .pdf_parser import parse_pdfs
from .kb_manager import KBManager
