# Klynx

![PyPI - Version](https://img.shields.io/pypi/v/klynx)
![License](https://img.shields.io/github/license/qzx/klynx)

**Klynx** is an advanced, highly customizable autonomous agent framework built on top of [LangGraph](https://langchain-ai.github.io/langgraph/) and [LiteLLM](https://github.com/BerriAI/litellm). It is designed to seamless integrate with top-tier LLM providers globally (OpenAI, Anthropic, Google, DeepSeek, Zhipu, Moonshot, etc.) while offering a robust tool-calling infrastructure and built-in interactive terminal interfaces.

## 🚀 Features
- **Universal LLM Routing:** Write code once, use any model. Powered by `litellm`.
- **Advanced Agent Architectures:** Built with `langgraph` core state machines for recursive reasoning, memory, error reflection, and persistent context loops.
- **Robust Tools Environment:** Ships with native tools (e.g. Browser automation with Playwright, OS terminal integration, local filesystem querying).
- **Interactive TUI:** Comes with a built-in rich Text User Interface (`klynx/tui_app.py`) for streaming console interactions.
- **Proxy-Resistant:** `LiteLLM` adapters are configured internally to gracefully map local network environments without throwing blocking SSL errors.

## 📦 Installation

Install Klynx directly from PyPI:

```bash
pip install klynx
```

*(Note: If using browser features, remember to run `playwright install chromium` once).*

## ⚡ Quick Start

With Klynx, creating a multi-modal agent and interacting with it requires just a few lines of code.

### 1. Initialize your Model

Klynx expects explicit passing of your API keys or auto-loading from `.env` files. We fully support major models.

```python
import os
from klynx import setup_model, set_tavily_api

# (Optional) Enable web search capabilities globally
set_tavily_api(os.getenv("TAVILY_API_KEY", ""))

# Setup your agent's brain
api_key = os.getenv("DEEPSEEK_API_KEY")
model = setup_model("deepseek", "deepseek-reasoner", api_key)
```

### 2. Create the Agent

Attach your model to a `KlynxAgent` state machine, optionally granting it all system tools.

```python
from klynx import create_agent

# Initialize agent in current directory
agent = create_agent(
    working_dir=os.getcwd(),
    model=model,
    max_iterations=15 
)

# Grant agent access to all default tools (Browser, Files, Terminal, Web Search)
agent.add_tools("all")
```

### 3. Run a Task

There are two primary ways to run instructions: a direct API call or an interactive terminal stream.

#### Option A: Single Invocation (API Level)
Useful when integrating Klynx into your own backend or processing pipeline. It returns the final agent state and summary.

```python
task = "Search the web for the latest Python version changes and write a summary to a file named 'python_updates.md'."
# `invoke` processes the execution loop and returns states.
result = agent.invoke(task)

if result.get("task_completed"):
    print("Success! Agent Summary:", result.get("summary_content"))
```

#### Option B: Real-time Terminal Streaming
If you want to watch the agent think, execute tools, and log out its process in a beautiful format directly in the console, use `run_terminal_agent_stream`.

```python
from klynx import run_terminal_agent_stream

task = "Write a classic snake game using pygame in a new folder."
# This will stream reasoning tags, tool calls, and results to stdout
result = run_terminal_agent_stream(agent, task, thread_id="game_task_1")
```

### 4. Built-in TUI App

Klynx includes a powerful Text User Interface for managing and interacting with your agent directly in your terminal without writing scripts.

Launch the interactive app:
```bash
python -m klynx.tui_app
```

## 📜 License
This software is licensed under the [MIT License](LICENSE).
