# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "retell"
__version__ = "5.15.0"  # x-release-please-version
