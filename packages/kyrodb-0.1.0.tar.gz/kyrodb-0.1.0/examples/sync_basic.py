from __future__ import annotations

from kyrodb import KyroDBClient, exact


def main() -> None:
    with KyroDBClient(target="127.0.0.1:50051", api_key="kyro_example_key") as client:
        client.wait_for_ready(timeout_s=5)
        client.insert(doc_id=1, embedding=[0.0] * 4, metadata={"tenant": "acme"})
        result = client.search(query_embedding=[0.0] * 4, k=5, filter=exact("tenant", "acme"))
        print(result.total_found)


if __name__ == "__main__":
    main()
