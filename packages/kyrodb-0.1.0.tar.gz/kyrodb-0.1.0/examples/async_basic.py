from __future__ import annotations

import asyncio

from kyrodb import AsyncKyroDBClient


async def main() -> None:
    async with AsyncKyroDBClient(target="127.0.0.1:50051", api_key="kyro_example_key") as client:
        await client.wait_for_ready(timeout_s=5)
        await client.insert(doc_id=1, embedding=[0.0] * 4, metadata={"tenant": "acme"})
        result = await client.search(query_embedding=[0.0] * 4, k=5)
        print(result.total_found)


if __name__ == "__main__":
    asyncio.run(main())
