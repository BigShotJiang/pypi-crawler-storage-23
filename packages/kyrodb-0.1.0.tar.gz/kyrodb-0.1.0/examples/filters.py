from __future__ import annotations

from kyrodb import all_of, any_of, exact, in_values, negate, range_match


def main() -> None:
    tenant = exact("tenant", "acme")
    tiers = in_values("tier", ["pro", "enterprise"])
    recent = range_match("created_at", gte="2026-01-01T00:00:00Z")

    strict_filter = all_of([tenant, tiers, recent])
    permissive_filter = any_of([strict_filter, negate(exact("status", "archived"))])

    print(strict_filter)
    print(permissive_filter)


if __name__ == "__main__":
    main()
