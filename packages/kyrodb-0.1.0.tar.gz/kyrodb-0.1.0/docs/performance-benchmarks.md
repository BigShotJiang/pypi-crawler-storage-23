# Performance Benchmarks

## Embedding Validation Microbenchmark

Benchmark command:

```bash
python benchmarks/embedding_validation.py --iterations 3000
```

Environment:

- macOS (local dev machine)
- Python 3.11
- NumPy installed

Results:

| path | dims | mean_ms | p95_ms |
| --- | ---: | ---: | ---: |
| python-loop | 384 | 0.0115 | 0.0119 |
| numpy-fastpath(list-input) | 384 | 0.0167 | 0.0172 |
| numpy-fastpath(ndarray-input) | 384 | 0.0122 | 0.0123 |
| python-loop | 768 | 0.0224 | 0.0228 |
| numpy-fastpath(list-input) | 768 | 0.0336 | 0.0341 |
| numpy-fastpath(ndarray-input) | 768 | 0.0238 | 0.0251 |
| python-loop | 1536 | 0.0446 | 0.0470 |
| numpy-fastpath(list-input) | 1536 | 0.0642 | 0.0670 |
| numpy-fastpath(ndarray-input) | 1536 | 0.0453 | 0.0460 |

Interpretation:

- List inputs are fastest with the pure-Python loop path.
- NumPy conversion from Python lists adds overhead.
- NumPy fast path is near parity when callers already pass `numpy.ndarray`.

SDK policy implemented:

- If the input embedding is a NumPy array, SDK uses the NumPy validation path.
- For list/sequence inputs, SDK uses the Python loop path to avoid conversion overhead.
