# kyrodb-python Docs

## Contents

- `api-reference.md`: Public SDK API (sync + async + filters)
- `operations.md`: Reliability model, retry behavior, timeout semantics, error mapping
- `compatibility.md`: Public API compatibility policy and release guarantees
- `troubleshooting.md`: Operational failure modes and quick fixes
- `performance-benchmarks.md`: Microbenchmark results for SDK validation hot paths

## Hosting

- MkDocs config: `mkdocs.yml`
- CI workflow: `.github/workflows/docs.yml`
- Published docs branch: `gh-pages`

Local build:

```bash
pip install -e ".[docs]"
mkdocs build --strict
```
