# KyroDB Python SDK Docs

Official documentation for the `kyrodb` Python package.

## Sections

- [API Reference](api-reference.md)
- [Operations Guide](operations.md)
- [Troubleshooting](troubleshooting.md)
- [Compatibility Policy](compatibility.md)
- [Performance Benchmarks](performance-benchmarks.md)

## Local docs build

```bash
pip install -e ".[docs]"
mkdocs build --strict
```
