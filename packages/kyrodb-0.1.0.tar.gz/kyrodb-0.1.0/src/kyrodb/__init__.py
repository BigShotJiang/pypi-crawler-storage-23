"""KyroDB Python SDK."""

from importlib.metadata import PackageNotFoundError, version

from .async_client import AsyncKyroDBClient
from .client import KyroDBClient, TLSConfig
from .errors import (
    AuthenticationError,
    CircuitOpenError,
    DeadlineExceededError,
    InvalidArgumentError,
    KyroDBError,
    NotFoundError,
    PermissionDeniedError,
    QuotaExceededError,
    ServiceUnavailableError,
)
from .filters import all_of, any_of, exact, in_values, negate, range_match
from .models import (
    BatchDeleteResult,
    BulkLoadResult,
    BulkQueryResult,
    ConfigResult,
    DeleteResult,
    FlushResult,
    HealthResult,
    InsertAck,
    InsertItem,
    MetadataFilter,
    MetricsResult,
    QueryResult,
    SearchHit,
    SearchQuery,
    SearchResponse,
    SnapshotResult,
    UpdateMetadataResult,
)
from .retry import CircuitBreakerPolicy, RetryPolicy

try:
    __version__ = version("kyrodb")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "AsyncKyroDBClient",
    "AuthenticationError",
    "BatchDeleteResult",
    "BulkLoadResult",
    "BulkQueryResult",
    "CircuitBreakerPolicy",
    "CircuitOpenError",
    "ConfigResult",
    "DeadlineExceededError",
    "DeleteResult",
    "FlushResult",
    "HealthResult",
    "InsertAck",
    "InsertItem",
    "InvalidArgumentError",
    "KyroDBClient",
    "KyroDBError",
    "MetadataFilter",
    "MetricsResult",
    "NotFoundError",
    "PermissionDeniedError",
    "QueryResult",
    "QuotaExceededError",
    "RetryPolicy",
    "SearchHit",
    "SearchQuery",
    "SearchResponse",
    "ServiceUnavailableError",
    "SnapshotResult",
    "TLSConfig",
    "UpdateMetadataResult",
    "__version__",
    "all_of",
    "any_of",
    "exact",
    "in_values",
    "negate",
    "range_match",
]
