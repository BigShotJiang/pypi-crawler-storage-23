# -*- coding: utf-8 -*-
from bertopic import BERTopic
from hdbscan import HDBSCAN
from pydantic import Field, model_validator
from sinapsis_core.template_base.base_models import TemplateAttributes
from sinapsis_core.template_base.template import Template
from umap import UMAP

from sinapsis_bertopic.templates.base_models.base_attrs import BERTopicModelParams, HDBSCANModelParams, UMAPModelParams


class BERTopicBaseAttributes(TemplateAttributes):
    """
    BERTopicBaseAttributes manages configuration parameters for BERTopic model initialization.

    This class extends TemplateAttributes and provides structured attribute management for
    three key component model parameters: BERTopic, UMAP, and HDBSCAN. It ensures that
    empty dictionary parameters are automatically converted to their respective model
    parameter objects during validation.

    Attributes:
        bertopic_model_params (BERTopicModelParams): Configuration parameters for the
            BERTopic model. Defaults to an empty dictionary which is converted to a
            BERTopicModelParams instance during validation.
        umap_model_params (UMAPModelParams): Configuration parameters for the UMAP
            dimensionality reduction model. Defaults to an empty dictionary which is
            converted to a UMAPModelParams instance during validation.
        hdbscan_model_params (HDBSCANModelParams): Configuration parameters for the
            HDBSCAN clustering model. Defaults to an empty dictionary which is
            converted to a HDBSCANModelParams instance during validation.
    """

    bertopic_model_params: BERTopicModelParams = Field(default_factory=dict)
    umap_model_params: UMAPModelParams = Field(default_factory=dict)
    hdbscan_model_params: HDBSCANModelParams = Field(default_factory=dict)

    @model_validator(mode="after")
    def initialize_empty_params(self) -> "BERTopicBaseAttributes":
        if isinstance(self.bertopic_model_params, dict) and not self.bertopic_model_params:
            self.bertopic_model_params = BERTopicModelParams()

        if isinstance(self.umap_model_params, dict) and not self.umap_model_params:
            self.umap_model_params = UMAPModelParams()

        if isinstance(self.hdbscan_model_params, dict) and not self.hdbscan_model_params:
            self.hdbscan_model_params = HDBSCANModelParams()

        return self


class BERTopicBase(Template):
    """
    BERTopic template base class for topic modeling.

    This provides initialization and configuration for BERTopic models with UMAP and HDBSCAN components.

    Attributes:
        bertopic_model_params (BERTopicModelParams): Configuration parameters for the
            BERTopic model. Defaults to an empty dictionary which is converted to a
            BERTopicModelParams instance during validation.
        umap_model_params (UMAPModelParams): Configuration parameters for the UMAP
            dimensionality reduction model. Defaults to an empty dictionary which is
            converted to a UMAPModelParams instance during validation.
        hdbscan_model_params (HDBSCANModelParams): Configuration parameters for the
            HDBSCAN clustering model. Defaults to an empty dictionary which is
            converted to a HDBSCANModelParams instance during validation.
    """

    AttributesBaseModel = BERTopicBaseAttributes

    def __init__(self, attributes: TemplateAttributes) -> None:
        super().__init__(attributes)
        self.initialize_models()

    def initialize_models(self) -> None:
        """
        Initialize and configure the BERTopic model with UMAP and HDBSCAN components.

        This method sets up three interconnected models:
        - UMAP: Dimensionality reduction model configured with parameters from self.attributes.umap_model_params
        - HDBSCAN: Clustering model configured with parameters from self.attributes.hdbscan_model_params,
          including any additional kwargs
        - BERTopic: The main topic modeling instance that combines UMAP and HDBSCAN with additional
          parameters from self.attributes.bertopic_model_params

        The initialized BERTopic model is assigned to self.topic_model.
        """
        umap_model = UMAP(**self.attributes.umap_model_params.model_dump())

        hdbscan_model_params = self.attributes.hdbscan_model_params.model_dump(exclude={"kwargs"})
        extra_kwargs = self.attributes.hdbscan_model_params.kwargs or {}
        merged_hdbscan_model_params = {**hdbscan_model_params, **extra_kwargs}
        hdbscan_model = HDBSCAN(**merged_hdbscan_model_params)

        bertopic_params_dict = self.attributes.bertopic_model_params.model_dump()
        bertopic_params_dict["umap_model"] = umap_model
        bertopic_params_dict["hdbscan_model"] = hdbscan_model

        self.topic_model = BERTopic(**bertopic_params_dict)
