# -*- coding: utf-8 -*-
import pickle
from pathlib import Path

import numpy as np
from bertopic import BERTopic
from plotly import graph_objects as go
from pydantic import BaseModel, ConfigDict, computed_field
from sinapsis_core.data_containers.data_packet import DataContainer, TextAnnotations, TextPacket
from sinapsis_core.template_base.template import Template, TemplateAttributes, TemplateAttributeType
from sinapsis_core.utils.env_var_keys import SINAPSIS_CACHE_DIR

from sinapsis_bertopic.helpers.bertopic_helpers import get_docs_from_text_packets
from sinapsis_bertopic.third_party._documents import visualize_documents


class BERTopicPredictions(BaseModel):
    """
    A Pydantic model representing BERTopic prediction results.

    This model encapsulates the output of a BERTopic model's prediction operation,
    containing topic assignments, their corresponding labels, and confidence probabilities.

    Attributes:
        topics (list[int]): A list of topic identifiers assigned to each document.
            Each integer represents the predicted topic for the corresponding input.
        labels (list[str]): A list of human-readable labels corresponding to each predicted topic.
            Provides interpretable names or descriptions for the assigned topics.
        probs (np.ndarray): A NumPy array containing the probability scores for each prediction.
            Typically contains confidence values indicating the model's certainty in its predictions.

    Config:
        model_config (ConfigDict): Pydantic model configuration that allows arbitrary types
            (specifically NumPy arrays) to be used as model fields.
    """

    topics: list[int]
    labels: list[str]
    probs: np.ndarray
    model_config = ConfigDict(arbitrary_types_allowed=True)


class BERTopicPredictAttributes(TemplateAttributes):
    """
    BERTopicPredictAttributes class for managing BERTopic prediction configuration.

    Attributes:
        model_path (str): Path to the trained BERTopic model file.
        visualize_predictions (bool): Whether to generate visualizations for predictions.
            Defaults to False.
        historical_data_path (str | None): Path to historical data required for
            visualization. Must be provided if visualize_predictions is True.
            Defaults to None.
        root_dir (str): Root directory for storing prediction outputs.
            Defaults to SINAPSIS_CACHE_DIR.
        prediction_viz_path (str): Relative path for the prediction visualization file.
            Defaults to "prediction_viz.html".

    Methods:
        validate_attributes() -> None: Validates that historical_data_path is provided
            when visualize_predictions is enabled. Raises ValueError if validation fails.
        full_prediction_viz_path (property): Computed field that combines root_dir
            and prediction_viz_path into an absolute file path.
    """

    model_path: str
    visualize_predictions: bool = False
    historical_data_path: str | None = None
    root_dir: str = SINAPSIS_CACHE_DIR
    prediction_viz_path: str = "prediction_viz.html"

    def validate_attributes(self) -> None:
        """Validate that historical_data_path is provided if visualize_predictions is True."""
        if self.visualize_predictions and not self.historical_data_path:
            raise ValueError("historical_data_path must be provided when visualize_predictions is True")

    @computed_field
    @property
    def full_prediction_viz_path(self) -> str:
        """Combines root_dir and prediction_viz_path into a single absolute path string."""
        return str(Path(self.root_dir) / self.prediction_viz_path)


class BERTopicPredict(Template):
    """
    BERTopicPredict template for topic prediction using BERTopic models.

    This class provides functionality to load a pre-trained BERTopic model and generate
    topic predictions for document collections. It handles model loading, prediction generation,
    and integration with the data container pipeline.

    Attributes:
        AttributesBaseModel: Configuration model for BERTopicPredict template.
            - model_path (str): Path to the saved BERTopic model file. It can point to a local saved model or a
                model stored in a huggingface hub repo.
            - visualize_predictions (bool): Whether to generate visualizations for predictions.
                Defaults to False.
            - historical_data_path (str | None): Path to historical data required for
                visualization. Must be provided if visualize_predictions is True.
                Defaults to None.
            - root_dir (str): Root directory for storing prediction outputs.
                Defaults to SINAPSIS_CACHE_DIR.
            - prediction_viz_path (str): Relative path for the prediction visualization file.
                Defaults to "prediction_viz.html".
    """

    AttributesBaseModel = BERTopicPredictAttributes

    def __init__(self, attributes: TemplateAttributeType) -> None:
        super().__init__(attributes)
        self.load_model()

    def load_model(self) -> None:
        """Load the BERTopic model from the specified path in attributes.

        Returns:
            str: The model path that was loaded.
        """
        self.topic_model = BERTopic.load(self.attributes.model_path)

    def visualize_predictions(self, docs: list[str], topics: list[int], embeddings: np.ndarray) -> go.Figure:
        """Visualize the predicted topics for the given documents.

        Args:
            docs (list[str]): List of documents for which topics were predicted.
            topics (list[int]): List of predicted topic indices corresponding to each document.
            probs (np.ndarray): Array of probabilities for each topic prediction.
        Returns:
            go.Figure: A Plotly figure visualizing the predicted topics and their probabilities.
        """
        train_docs, train_embeddings = pickle.load(open(self.attributes.historical_data_path, "rb"))

        merged_docs = train_docs + docs
        merged_embeddings = np.vstack([train_embeddings, embeddings])

        self.topic_model.topics_ = list(self.topic_model.topics_) + list(topics)

        document_viz = visualize_documents(
            topic_model=self.topic_model, docs=merged_docs, embeddings=merged_embeddings, highligth_last_n=len(docs)
        )

        document_viz.write_html(self.attributes.full_prediction_viz_path)

    def get_predictions(self, docs: list[str]) -> BERTopicPredictions:
        """Generate topic predictions for the provided documents.

        Args:
            docs (list[str]): List of documents to predict topics for.

        Returns:
            BERTopicPredictions: Object containing predicted topics, labels, and probabilities.
        """

        new_embeddings = self.topic_model._extract_embeddings(docs)
        topics, probs = self.topic_model.transform(docs, embeddings=new_embeddings)

        if self.attributes.visualize_predictions:
            self.visualize_predictions(docs, topics, new_embeddings)

        topic_labels = [self.topic_model.topic_labels_[t] for t in topics]

        return BERTopicPredictions(topics=topics, labels=topic_labels, probs=probs)

    def parse_text_annotations(self, text_packets: list[TextPacket], preds: BERTopicPredictions) -> None:
        """
        Parse text annotations from BERTopic predictions and assign them to text packets.

        Args:
            text_packets: List of TextPacket objects to annotate.
            preds: BERTopicPredictions containing topics, labels, and probabilities.

        Returns:
            None. Modifies text_packets in place by setting their annotations attribute.
        """
        for text_packet, topic, label, prob in zip(text_packets, preds.topics, preds.labels, preds.probs.tolist()):
            text_packet.annotations = TextAnnotations(label=topic, label_str=label, confidence_score=prob)

    def execute(self, container: DataContainer) -> DataContainer:
        """Execute the prediction pipeline on documents from the data container.

        Args:
            container (DataContainer): Input data container with documents to predict.

        Returns:
            DataContainer: Updated container with prediction results.
        """
        docs = get_docs_from_text_packets(container)

        preds = self.get_predictions(docs)

        self.parse_text_annotations(container.texts, preds)

        return container
