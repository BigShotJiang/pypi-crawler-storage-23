# -*- coding: utf-8 -*-
import pickle
from pathlib import Path
from typing import Literal

import numpy as np
from pydantic import BaseModel, Field, computed_field, model_validator
from sinapsis_core.data_containers.data_packet import DataContainer
from sinapsis_core.utils.env_var_keys import SINAPSIS_CACHE_DIR

from sinapsis_bertopic.helpers.bertopic_helpers import get_docs_from_text_packets
from sinapsis_bertopic.templates.bertopic_base import BERTopicBase, BERTopicBaseAttributes


class BERTopicSaveModelParams(BaseModel):
    serialization: Literal["safetensors", "pytorch", "pickle"] = "safetensors"
    save_ctfidf: bool = True
    save_embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"


class BERTopicFitModelAttributes(BERTopicBaseAttributes):
    """
    Attributes configuration class for BERTopic model fitting and saving operations.

    This class extends BERTopicBaseAttributes to provide comprehensive configuration
    for fitting a BERTopic model and managing its persistence to disk.

    Attributes:
        bertopic_save_model_params (BERTopicSaveModelParams): Parameters controlling
            how the fitted BERTopic model is saved, including serialization options
            and model artifact configuration. Defaults to an empty dictionary which
            is automatically converted to a BERTopicSaveModelParams instance.
        root_dir (str): The root directory path where the model will be saved.
            Defaults to SINAPSIS_CACHE_DIR for consistent cache location.
        save_path (str): The relative path within root_dir where the model artifacts
            will be stored.

    Properties:
        full_save_path (str): A computed property that combines root_dir and save_path
            into a single absolute filesystem path string for convenient access to
            the complete model save location.

    Validators:
        initialize_empty_params: Ensures that empty dictionary values for
            bertopic_save_model_params are properly initialized as BERTopicSaveModelParams
            instances, maintaining type consistency and default parameter values.
    """

    bertopic_save_model_params: BERTopicSaveModelParams = Field(default_factory=dict)
    root_dir: str = SINAPSIS_CACHE_DIR
    save_model_path: str
    save_training_data: bool = False
    save_training_data_path: str = "training_data.pkl"

    @computed_field
    @property
    def full_training_data_path(self) -> str:
        """Combines root_dir and save_training_data_path into a single absolute path string."""
        return str(Path(self.root_dir) / self.save_training_data_path)

    @computed_field
    @property
    def full_model_path(self) -> str:
        """Combines root_dir and save_model_path into a single absolute path string."""
        return str(Path(self.root_dir) / self.save_model_path)

    @model_validator(mode="after")
    def initialize_empty_params(self) -> "BERTopicFitModelAttributes":
        super().initialize_empty_params()

        if isinstance(self.bertopic_save_model_params, dict) and not self.bertopic_save_model_params:
            self.bertopic_save_model_params = BERTopicSaveModelParams()

        return self


class BERTopicFitModel(BERTopicBase):
    """
    BERTopicFitModel

    A model class for fitting BERTopic models and saving them to disk.

    This class extends BERTopicBase to provide functionality for:
    - Initializing and validating BERTopic save parameters
    - Saving trained topic models in various serialization formats
    - Executing the model fitting pipeline on documents from a DataContainer

    Attributes:
        AttributesBaseModel: A Pydantic model for validating and managing BERTopic save parameters.
            - bertopic_save_model_params (BERTopicSaveParams): Configuration for model saving including
              root directory, save path, and serialization format (safetensors, pytorch, or default).

            - root_dir (str): The root directory path where files will be saved.
                Defaults to SINAPSIS_CACHE_DIR.

            - save_path (str): The relative path within root_dir where the file will be saved.


    """

    AttributesBaseModel = BERTopicFitModelAttributes

    def save_model(self) -> str:
        """Saves the fitted topic model to the specified path using the configured serialization format.
            Supports both safetensors/pytorch formats (with additional parameters) and default format.

        Returns:
            str: The full path where the model was saved.
        """
        save_path = self.attributes.full_model_path

        if self.attributes.bertopic_save_model_params.serialization in ["safetensors", "pytorch"]:
            save_attrs = self.attributes.bertopic_save_model_params.model_dump(exclude={"save_file_params"})
            save_attrs["path"] = save_path

            self.topic_model.save(**save_attrs)
        else:
            self.topic_model.save(save_path)
        self.logger.info(f"Bertopic model saved at {save_path}")
        return save_path

    def save_training_data(self, docs: list[str], embeddings: np.ndarray) -> None:
        """Saves the training data used for fitting the model to disk.

        Args:
            docs (list[str]): The list of documents used for training.
            embeddings (np.ndarray): The embeddings corresponding to the documents.

        """
        training_data = (docs, embeddings)
        save_path = self.attributes.full_training_data_path
        with open(save_path, "wb") as f:
            pickle.dump(training_data, f)
        self.logger.info(f"Training data saved at {save_path}")

    def execute(self, container: DataContainer) -> DataContainer:
        """Main execution method that extracts documents from the container, fits the topic model,
            saves the model, and updates the container with the save path.

        Args:
            container (DataContainer): Input data container with documents to fit.

        Returns:
            DataContainer: Updated container with save path information.
        """
        docs = get_docs_from_text_packets(container)

        embeddings = self.topic_model._extract_embeddings(docs)

        self.topic_model.fit(docs, embeddings=embeddings)

        if self.attributes.save_training_data:
            self.save_training_data(docs, embeddings)

        save_path = self.save_model()

        self._set_generic_data(container, save_path)
        return container
