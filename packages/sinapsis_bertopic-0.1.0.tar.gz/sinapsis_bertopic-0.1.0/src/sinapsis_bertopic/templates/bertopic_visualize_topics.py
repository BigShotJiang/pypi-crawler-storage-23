# -*- coding: utf-8 -*-
import io
import time
from pathlib import Path

import numpy as np
from PIL import Image
from plotly import graph_objects
from pydantic import Field, computed_field, model_validator
from sinapsis_core.data_containers.data_packet import DataContainer, ImagePacket
from sinapsis_core.utils.env_var_keys import SINAPSIS_CACHE_DIR

from sinapsis_bertopic.templates.base_models.base_attrs import ToImageParams, VisualizeTopicsParams
from sinapsis_bertopic.templates.bertopic_predict import BERTopicPredict


class BERTopicVisualizeTopicsAttributes(BERTopicPredict.AttributesBaseModel):
    """
    A Pydantic model for BERTopic topic visualization attributes and configuration.
    This class extends BERTopicPredict.AttributesBaseModel to define parameters for visualizing
    topics extracted by BERTopic, including options for saving files and exporting visualizations
    to image format.

    Computed Fields:
        full_save_path: A computed property that generates the complete absolute path
            by joining root_dir and save_path using Path operations.
    """

    visualize_topics_params: VisualizeTopicsParams = Field(default_factory=dict)
    export_visualization_to_image: bool = True
    image_export_params: ToImageParams = Field(default_factory=dict)
    root_dir: str = SINAPSIS_CACHE_DIR
    save_path: str

    @computed_field
    @property
    def full_save_path(self) -> str:
        """Combines root_dir and save_path into a single absolute path string."""
        return str(Path(self.root_dir) / self.save_path)

    @model_validator(mode="after")
    def initialize_empty_params(self) -> "BERTopicVisualizeTopicsAttributes":
        if isinstance(self.visualize_topics_params, dict) and not self.visualize_topics_params:
            self.visualize_topics_params = VisualizeTopicsParams()

        if isinstance(self.image_export_params, dict) and not self.image_export_params:
            self.image_export_params = ToImageParams()
        return self


class BERTopicVisualizeTopics(BERTopicPredict):
    """Template for BERTopic topic visualization.

    This class extends BERTopicPredict to generate and save interactive visualizations
    of topics discovered by a BERTopic model. It produces plotly-based visual representations
    of topic relationships and characteristics, and persists them as HTML files.

    The class manages visualization output paths through its nested AttributesBaseModel,
    which combines a root directory and relative path into a full file path for saving
    visualization outputs.

    Attributes:
        visualize_topics_params (VisualizeTopicsParams): Parameters for the topic visualization.
            Defaults to an empty VisualizeTopicsParams instance.
        export_visualization_to_image (bool): Flag indicating whether to export the visualization
            to an image file. Defaults to True.
        image_export_params (ToImageParams): Parameters for exporting the visualization to image format.
            Defaults to an empty ToImageParams instance.
        root_dir (str): The root directory path where files will be saved.
            Defaults to SINAPSIS_CACHE_DIR.
        save_path (str): The relative path within root_dir where the file will be saved.
    """

    AttributesBaseModel = BERTopicVisualizeTopicsAttributes

    def produce_topics_visualizations(self) -> graph_objects.Figure:
        """
        Generate interactive visualizations of the discovered topics from the BERTopic model.
        This method produces a comprehensive visual representation of all topics identified
        by the topic model, displaying their relationships and characteristics through an
        interactive plotly figure.
        Returns
        -------
        graph_objects.Figure
            An interactive plotly Figure object containing the topics visualization.
            The visualization includes topic embeddings, their spatial relationships,
            and other relevant topic metrics for exploratory data analysis.
        """

        return self.topic_model.visualize_topics(**self.attributes.visualize_topics_params.model_dump(by_alias=True))

    def save_topics_visualizations(self, fig: graph_objects.Figure) -> None:
        """
        Save topics visualization figure to an HTML file.

        Args:
            fig: (graph_objects.Figure) Plotly graph object Figure containing the topics visualization.
        """
        fig.write_html(self.attributes.full_save_path)

    def convert_figure_to_image_array(self, fig: graph_objects.Figure) -> np.ndarray:
        """
        Convert a Plotly figure to a numpy array image.

        This method takes a Plotly graph object figure and converts it to a numpy
        array representation by first exporting it as image bytes, then reading
        those bytes into a PIL Image and converting to a numpy array.

        Args:
            fig (graph_objects.Figure): A Plotly figure object to be converted.

        Returns:
            np.ndarray: A numpy array representing the image data of the figure.
        """
        image_bytes = fig.to_image(**self.attributes.image_export_params.model_dump(by_alias=True))
        return np.array(Image.open(io.BytesIO(image_bytes)))

    def append_img_array_to_container(self, img_arr: np.ndarray, container: DataContainer) -> None:
        """
        Append an image array to a data container as an ImagePacket.

        Args:
            img_arr (np.ndarray): The image array to be appended to the container.
            container (DataContainer): The data container where the image packet will be stored.

        Returns:
            None
        """
        source = self.instance_name + "_" + str(int(time.time()))

        container.images.append(ImagePacket(content=img_arr, source=source))

    def execute(self, container: DataContainer) -> DataContainer:
        """
        Generates a topic visualization using the loaded topic model,
        saves it as an HTML file to the path specified in self.attributes.full_save_path,
        and returns the input container for potential downstream processing.

        Args:
            container (DataContainer): The input data container to be processed.

        Returns:
            DataContainer: The same input data container, unchanged.

        """

        fig = self.produce_topics_visualizations()
        if self.attributes.export_visualization_to_image:
            img_arr = self.convert_figure_to_image_array(fig)
            self.append_img_array_to_container(img_arr, container)

        self.save_topics_visualizations(fig)

        return container
