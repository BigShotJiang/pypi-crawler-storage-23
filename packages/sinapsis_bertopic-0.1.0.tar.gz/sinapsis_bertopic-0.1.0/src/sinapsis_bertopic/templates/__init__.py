# -*- coding: utf-8 -*-
import importlib

from sinapsis_core.template_base import Template

_root_lib_path: str = "sinapsis_bertopic.templates"

_template_lookup: dict = {
    "BERTopicFitModel": f"{_root_lib_path}.bertopic_fit_model",
    "BERTopicPredict": f"{_root_lib_path}.bertopic_predict",
    "BERTopicVisualizeTopics": f"{_root_lib_path}.bertopic_visualize_topics",
    "BERTopicVisualizeDocuments": f"{_root_lib_path}.bertopic_visualize_documents",
}


def __getattr__(name: str) -> Template:
    if name in _template_lookup:
        module = importlib.import_module(_template_lookup[name])
        return getattr(module, name)
    raise AttributeError(f"template `{name}` not found in {_root_lib_path}")


__all__ = list(_template_lookup.keys())
