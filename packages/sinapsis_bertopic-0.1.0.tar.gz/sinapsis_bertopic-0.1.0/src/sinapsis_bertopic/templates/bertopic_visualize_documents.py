# -*- coding: utf-8 -*-

import io
import time
from pathlib import Path

import numpy as np
from PIL import Image
from plotly import graph_objects
from pydantic import Field, computed_field, model_validator
from sentence_transformers import SentenceTransformer
from sinapsis_core.data_containers.data_packet import DataContainer, ImagePacket
from sinapsis_core.template_base.base_models import TemplateAttributes
from sinapsis_core.utils.env_var_keys import SINAPSIS_CACHE_DIR

from sinapsis_bertopic.helpers.bertopic_helpers import get_docs_from_text_packets
from sinapsis_bertopic.templates.base_models.base_attrs import ToImageParams, VisualizeDocumentsParams
from sinapsis_bertopic.templates.bertopic_fit_model import BERTopicFitModel, BERTopicFitModelAttributes


class BERTopicVisualizeDocumentsAttributes(BERTopicFitModelAttributes):
    """
    Attributes configuration class for BERTopic document visualization.

    This class extends BERTopicBaseAttributes and defines parameters for visualizing
    documents using BERTopic, including sentence embedding model selection, file saving
    options, visualization parameters, and image export settings.

    Computed Fields:
        full_save_path (str): A computed property that generates the complete absolute path
            by joining root_dir and save_path using Path operations.
    """

    sentence_model_name: str = "all-MiniLM-L6-v2"
    visualize_documents_params: VisualizeDocumentsParams = Field(default_factory=dict)
    export_visualization_to_image: bool = True
    image_export_params: ToImageParams = Field(default_factory=dict)
    root_dir: str = SINAPSIS_CACHE_DIR
    save_vizualization_path: str = "documents_visualization.html"

    @computed_field
    @property
    def full_visualization_path(self) -> str:
        """Combines root_dir and save_vizualization_path into a single absolute path string."""
        return str(Path(self.root_dir) / self.save_vizualization_path)

    @model_validator(mode="after")
    def initialize_empty_params(self) -> "BERTopicVisualizeDocumentsAttributes":
        super().initialize_empty_params()

        if isinstance(self.visualize_documents_params, dict) and not self.visualize_documents_params:
            self.visualize_documents_params = VisualizeDocumentsParams()

        if isinstance(self.image_export_params, dict) and not self.image_export_params:
            self.image_export_params = ToImageParams()
        return self


class BERTopicVisualizeDocuments(BERTopicFitModel):
    """A BERTopic-based document visualization template for generating and exporting interactive topic model
    visualizations.
    This class extends BERTopicFitModel to provide functionality for encoding documents using sentence transformers,
    fitting a BERTopic model, and producing interactive visualizations of documents in a reduced dimensional space.
    The visualizations can be saved as HTML files and optionally exported as image arrays.

    Attributes:
        sentence_model_name (str):
            Name of the sentence transformer model to use for embeddings.
            Defaults to "all-MiniLM-L6-v2".

        visualize_documents_params (VisualizeDocumentsParams):
            Parameters controlling the document visualization behavior and output.
            Automatically initialized as an empty VisualizeDocumentsParams instance
            if not provided. Defaults to an empty dictionary.

        export_visualization_to_image (bool):
            Flag to enable/disable exporting the visualization to an image file.
            Defaults to True.

        image_export_params (ToImageParams):
            Parameters for image export configuration. Automatically initialized
            as an empty ToImageParams instance if not provided. Defaults to an
            empty dictionary.

        root_dir (str): The root directory path where files will be saved.
            Defaults to SINAPSIS_CACHE_DIR.

        save_path (str): The relative path within root_dir where the file will be saved.
    """

    AttributesBaseModel = BERTopicVisualizeDocumentsAttributes

    def __init__(self, attributes: TemplateAttributes) -> None:
        super().__init__(attributes)

        self.sentence_model = SentenceTransformer(self.attributes.sentence_model_name)

    def produce_documents_visualizations(self, docs: list[str]) -> graph_objects.Figure:
        """
        Generate visualizations of documents using BERTopic topic modeling.

        This method encodes the provided documents using a sentence transformer model,
        fits the topic model on the encoded documents, and produces an interactive
        visualization of the documents in a reduced dimensional space.

        Args:
            docs: A list of document strings to be encoded and visualized.

        Returns:
            graph_objects.Figure: A Plotly figure object containing the interactive
                visualization of the documents with their topic assignments.
        """
        embeddings = self.sentence_model.encode(docs, show_progress_bar=True)

        self.topic_model.fit(docs, embeddings)

        if self.attributes.save_training_data:
            self.save_training_data(docs, embeddings)

        visualize_docs_dict = self.attributes.visualize_documents_params.model_dump()
        visualize_docs_dict["embeddings"] = embeddings
        visualize_docs_dict["docs"] = docs

        return self.topic_model.visualize_documents(**visualize_docs_dict)

    def save_documents_visualizations(self, fig: graph_objects.Figure) -> None:
        """
        Save the documents visualization figure to an HTML file.

        Args:
            fig: A Plotly graph objects Figure containing the documents visualization.

        Returns:
            None
        """
        fig.write_html(self.attributes.full_visualization_path)

    def convert_figure_to_image_array(self, fig: graph_objects.Figure) -> np.ndarray:
        """
        Convert a Plotly figure to a numpy array image.

        This method takes a Plotly graph object figure and converts it to a numpy
        array representation by first exporting it as image bytes, then reading
        those bytes into a PIL Image and converting to a numpy array.

        Args:
            fig (graph_objects.Figure): A Plotly figure object to be converted.

        Returns:
            np.ndarray: A numpy array representing the image data of the figure.
        """
        image_bytes = fig.to_image(**self.attributes.image_export_params.model_dump(by_alias=True))
        return np.array(Image.open(io.BytesIO(image_bytes)))

    def append_img_array_to_container(self, img_arr: np.ndarray, container: DataContainer) -> None:
        """
        Append an image array to a data container as an ImagePacket.

        Args:
            img_arr (np.ndarray): The image array to be appended to the container.
            container (DataContainer): The data container where the image packet will be stored.

        Returns:
            None
        """
        source = self.instance_name + "_" + str(int(time.time()))

        container.images.append(ImagePacket(content=img_arr, source=source))

    def execute(self, container: DataContainer) -> DataContainer:
        """
        Execute the document visualization pipeline.

        Extracts documents from the input container, generates visualizations,
        and saves them. Optionally exports the visualization as an image array
        and appends it to the container.

        Args:
            container (DataContainer): Input container with text data to visualize.

        Returns:
            DataContainer: The same container, optionally updated with visualization image array.
        """
        docs = get_docs_from_text_packets(container)
        fig = self.produce_documents_visualizations(docs)
        self.save_documents_visualizations(fig)

        if self.attributes.export_visualization_to_image:
            img_arr = self.convert_figure_to_image_array(fig)
            self.append_img_array_to_container(img_arr, container)
        self.save_model()

        return container
