"""
回归测试（8个）

- Brain 接口兼容（2个）
- MediaHandler（2个）
- Memory（2个）
- Evolution & Skill（2个）
"""
