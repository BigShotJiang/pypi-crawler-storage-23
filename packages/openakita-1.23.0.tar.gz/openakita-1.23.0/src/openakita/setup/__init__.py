"""
OpenAkita 安装向导模块
"""

from .wizard import SetupWizard

__all__ = ["SetupWizard"]
