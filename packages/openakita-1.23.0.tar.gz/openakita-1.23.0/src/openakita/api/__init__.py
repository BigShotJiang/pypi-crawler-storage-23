"""
OpenAkita HTTP API Module

提供 FastAPI HTTP API，支持：
- Chat (SSE streaming)
- Models list
- Health check
- Skills management
- File upload
"""
