ALTER TABLE collections ADD COLUMN dimension INTEGER;
