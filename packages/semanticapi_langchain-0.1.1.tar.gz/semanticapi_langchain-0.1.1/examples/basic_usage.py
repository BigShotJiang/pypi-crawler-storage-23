"""Basic usage of semanticapi-langchain tools."""

from semanticapi_langchain import SemanticAPIQueryTool, SemanticAPISearchTool, SemanticAPIWrapper

# Initialize the API wrapper (uses SEMANTICAPI_API_KEY env var by default)
api = SemanticAPIWrapper(api_key="sapi_your_key_here")

# -- Using tools directly -----------------------------------------------------

query_tool = SemanticAPIQueryTool(api_wrapper=api)
search_tool = SemanticAPISearchTool(api_wrapper=api)

# Find the best API for sending an SMS
result = query_tool.run("send an SMS to a phone number")
print("Query result:", result)

# Discover available weather APIs
results = search_tool.run("weather")
print("Search results:", results)

# -- Using the toolkit --------------------------------------------------------

from semanticapi_langchain import SemanticAPIToolkit

toolkit = SemanticAPIToolkit(api_key="sapi_your_key_here")
tools = toolkit.get_tools()

for tool in tools:
    print(f"Tool: {tool.name} — {tool.description}")
