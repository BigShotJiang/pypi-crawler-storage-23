"""Using Semantic API tools with a LangChain agent."""

from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate

from semanticapi_langchain import SemanticAPIToolkit

# 1. Create toolkit
toolkit = SemanticAPIToolkit()  # uses SEMANTICAPI_API_KEY env var

# 2. Set up the LLM and agent
llm = ChatOpenAI(model="gpt-4o-mini")
tools = toolkit.get_tools()

prompt = ChatPromptTemplate.from_messages([
    ("system",
     "You are a helpful assistant that finds the right APIs for tasks. "
     "Use the semanticapi tools to discover APIs, then explain how to use them."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])

agent = create_tool_calling_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

# 3. Run it
response = executor.invoke({
    "input": "I need to send an SMS. What API should I use and how?"
})
print(response["output"])
