"""Semantic API Toolkit for LangChain."""

from __future__ import annotations

from typing import List, Optional

from langchain_core.tools import BaseTool

from semanticapi_langchain.tools import SemanticAPIQueryTool, SemanticAPISearchTool
from semanticapi_langchain.utilities import SemanticAPIWrapper


class SemanticAPIToolkit:
    """Toolkit that bundles all Semantic API tools for use with LangChain agents.

    Args:
        api_key: Semantic API key. Falls back to ``SEMANTICAPI_API_KEY`` env var.
        base_url: Override the default API base URL.
        timeout: Request timeout in seconds.

    Example::

        from semanticapi_langchain import SemanticAPIToolkit

        toolkit = SemanticAPIToolkit(api_key="sapi_xxx")
        tools = toolkit.get_tools()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ) -> None:
        self.api_wrapper = SemanticAPIWrapper(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
        )

    def get_tools(self) -> List[BaseTool]:
        """Return all Semantic API tools."""
        return [
            SemanticAPIQueryTool(api_wrapper=self.api_wrapper),
            SemanticAPISearchTool(api_wrapper=self.api_wrapper),
        ]
