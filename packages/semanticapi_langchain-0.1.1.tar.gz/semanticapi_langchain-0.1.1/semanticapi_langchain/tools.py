"""LangChain Tool classes for Semantic API."""

from __future__ import annotations

import json
from typing import Any, Dict, Optional, Type

from langchain_core.callbacks import (
    AsyncCallbackManagerForToolRun,
    CallbackManagerForToolRun,
)
from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

from semanticapi_langchain.utilities import SemanticAPIWrapper


# -- Input schemas ------------------------------------------------------------


class QueryInput(BaseModel):
    """Input for the Semantic API query tool."""

    query: str = Field(
        description="A natural-language description of the API capability you need, "
        "e.g. 'send an SMS' or 'get current weather'."
    )


class SearchInput(BaseModel):
    """Input for the Semantic API search tool."""

    query: str = Field(
        description="Search term to discover available API capabilities, "
        "e.g. 'weather', 'payments', 'email'."
    )


# -- Tools --------------------------------------------------------------------


class SemanticAPIQueryTool(BaseTool):
    """Find the best matching API for a natural-language task description.

    Given a query like "send an SMS", returns the matched provider, endpoint,
    required parameters, and authentication details.
    """

    name: str = "semanticapi_query"
    description: str = (
        "Find the best API provider and endpoint for a task described in plain English. "
        "Returns the matched provider, endpoint URL, parameters, and auth instructions. "
        "Use this when you need to figure out which API to call for a given task."
    )
    args_schema: Type[BaseModel] = QueryInput
    api_wrapper: SemanticAPIWrapper

    def _run(
        self,
        query: str,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        result = self.api_wrapper.query(query)
        return json.dumps(result, indent=2)

    async def _arun(
        self,
        query: str,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        result = await self.api_wrapper.aquery(query)
        return json.dumps(result, indent=2)


class SemanticAPISearchTool(BaseTool):
    """Search and discover available API capabilities.

    Use this to explore what APIs and capabilities are available before
    making a specific query.
    """

    name: str = "semanticapi_search"
    description: str = (
        "Search for available API capabilities by keyword. "
        "Returns a list of matching capabilities across providers. "
        "Use this to explore what's available before querying for a specific API."
    )
    args_schema: Type[BaseModel] = SearchInput
    api_wrapper: SemanticAPIWrapper

    def _run(
        self,
        query: str,
        run_manager: Optional[CallbackManagerForToolRun] = None,
    ) -> str:
        result = self.api_wrapper.search(query)
        return json.dumps(result, indent=2)

    async def _arun(
        self,
        query: str,
        run_manager: Optional[AsyncCallbackManagerForToolRun] = None,
    ) -> str:
        result = await self.api_wrapper.asearch(query)
        return json.dumps(result, indent=2)
