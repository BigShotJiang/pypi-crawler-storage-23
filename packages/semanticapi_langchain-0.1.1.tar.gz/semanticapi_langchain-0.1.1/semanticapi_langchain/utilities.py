"""Semantic API wrapper with sync and async support."""

from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

import httpx


class SemanticAPIError(Exception):
    """Raised when the Semantic API returns an error."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        self.status_code = status_code
        super().__init__(message)


class SemanticAPIWrapper:
    """Low-level wrapper around the Semantic API.

    Args:
        api_key: Semantic API key. Falls back to ``SEMANTICAPI_API_KEY`` env var.
        base_url: Override the default API base URL.
        timeout: Request timeout in seconds.
    """

    DEFAULT_BASE_URL = "https://semanticapi.dev/api"

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ) -> None:
        self.api_key = api_key or os.environ.get("SEMANTICAPI_API_KEY", "")
        if not self.api_key:
            raise ValueError(
                "Semantic API key is required. Pass api_key or set SEMANTICAPI_API_KEY."
            )
        self.base_url = (base_url or self.DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout

    # -- internal helpers -----------------------------------------------------

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    @staticmethod
    def _handle_response(response: httpx.Response) -> Any:
        if response.status_code >= 400:
            try:
                detail = response.json().get("detail", response.text)
            except Exception:
                detail = response.text
            raise SemanticAPIError(
                f"Semantic API error ({response.status_code}): {detail}",
                status_code=response.status_code,
            )
        return response.json()

    # -- sync methods ---------------------------------------------------------

    def query(self, query: str) -> Dict[str, Any]:
        """Find the best API match for a natural-language query."""
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(
                f"{self.base_url}/query",
                headers=self._headers(),
                json={"query": query},
            )
        return self._handle_response(resp)

    def query_preflight(self, query: str) -> Dict[str, Any]:
        """Lightweight / faster query match."""
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(
                f"{self.base_url}/query/preflight",
                headers=self._headers(),
                json={"query": query},
            )
        return self._handle_response(resp)

    def search(self, q: str) -> Dict[str, Any]:
        """Search for API capabilities using natural language."""
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.post(
                f"{self.base_url}/query",
                headers=self._headers(),
                json={"query": q},
            )
        return self._handle_response(resp)

    def list_providers(self) -> List[Dict[str, Any]]:
        """List all available API providers."""
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.get(
                f"{self.base_url}/providers",
                headers=self._headers(),
            )
        return self._handle_response(resp)

    def stats(self) -> Dict[str, Any]:
        """Get system stats."""
        with httpx.Client(timeout=self.timeout) as client:
            resp = client.get(
                f"{self.base_url}/stats",
                headers=self._headers(),
            )
        return self._handle_response(resp)

    # -- async methods --------------------------------------------------------

    async def aquery(self, query: str) -> Dict[str, Any]:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(
                f"{self.base_url}/query",
                headers=self._headers(),
                json={"query": query},
            )
        return self._handle_response(resp)

    async def aquery_preflight(self, query: str) -> Dict[str, Any]:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(
                f"{self.base_url}/query/preflight",
                headers=self._headers(),
                json={"query": query},
            )
        return self._handle_response(resp)

    async def asearch(self, q: str) -> Dict[str, Any]:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.get(
                f"{self.base_url}/discover/search",
                headers=self._headers(),
                params={"q": q},
            )
        return self._handle_response(resp)

    async def alist_providers(self) -> List[Dict[str, Any]]:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.get(
                f"{self.base_url}/providers",
                headers=self._headers(),
            )
        return self._handle_response(resp)

    async def astats(self) -> Dict[str, Any]:
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.get(
                f"{self.base_url}/stats",
                headers=self._headers(),
            )
        return self._handle_response(resp)
