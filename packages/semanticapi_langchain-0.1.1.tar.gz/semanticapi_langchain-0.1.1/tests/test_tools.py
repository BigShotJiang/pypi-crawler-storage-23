"""Tests for semanticapi-langchain (no API key required — all mocked)."""

from __future__ import annotations

import json
from unittest.mock import patch

import httpx
import pytest

from semanticapi_langchain import (
    SemanticAPIError,
    SemanticAPIQueryTool,
    SemanticAPISearchTool,
    SemanticAPIToolkit,
    SemanticAPIWrapper,
)

# -- Fixtures & helpers -------------------------------------------------------

MOCK_QUERY_RESPONSE = {
    "provider": "twilio",
    "capability": "send_sms",
    "endpoint": {
        "method": "POST",
        "url": "https://api.twilio.com/2010-04-01/Accounts/{AccountSid}/Messages.json",
    },
    "params": {
        "To": "+15551234567",
        "From": "+15559876543",
        "Body": "Hello!",
    },
    "auth": {
        "type": "basic",
        "docs": "https://www.twilio.com/docs/usage/security",
    },
}

MOCK_SEARCH_RESPONSE = {
    "results": [
        {"provider": "openweathermap", "capability": "current_weather"},
        {"provider": "weatherapi", "capability": "forecast"},
    ]
}


def _mock_response(data: dict, status: int = 200) -> httpx.Response:
    return httpx.Response(status_code=status, json=data, request=httpx.Request("GET", "https://test"))


@pytest.fixture
def wrapper() -> SemanticAPIWrapper:
    return SemanticAPIWrapper(api_key="sapi_test_key")


# -- Wrapper tests ------------------------------------------------------------


def test_wrapper_requires_api_key() -> None:
    with pytest.raises(ValueError, match="API key is required"):
        SemanticAPIWrapper(api_key="")


def test_wrapper_env_var() -> None:
    with patch.dict("os.environ", {"SEMANTICAPI_API_KEY": "sapi_from_env"}):
        w = SemanticAPIWrapper()
        assert w.api_key == "sapi_from_env"


def test_wrapper_query(wrapper: SemanticAPIWrapper) -> None:
    with patch("httpx.Client.post", return_value=_mock_response(MOCK_QUERY_RESPONSE)):
        result = wrapper.query("send an SMS")
    assert result["provider"] == "twilio"


def test_wrapper_search(wrapper: SemanticAPIWrapper) -> None:
    with patch("httpx.Client.get", return_value=_mock_response(MOCK_SEARCH_RESPONSE)):
        result = wrapper.search("weather")
    assert len(result["results"]) == 2


def test_wrapper_error(wrapper: SemanticAPIWrapper) -> None:
    err_resp = _mock_response({"detail": "Unauthorized"}, status=401)
    with patch("httpx.Client.post", return_value=err_resp):
        with pytest.raises(SemanticAPIError, match="401"):
            wrapper.query("fail")


def test_wrapper_list_providers(wrapper: SemanticAPIWrapper) -> None:
    mock = _mock_response([{"name": "twilio"}, {"name": "stripe"}])
    with patch("httpx.Client.get", return_value=mock):
        result = wrapper.list_providers()
    assert len(result) == 2


# -- Tool tests ---------------------------------------------------------------


def test_query_tool(wrapper: SemanticAPIWrapper) -> None:
    tool = SemanticAPIQueryTool(api_wrapper=wrapper)
    assert tool.name == "semanticapi_query"

    with patch("httpx.Client.post", return_value=_mock_response(MOCK_QUERY_RESPONSE)):
        output = tool.run("send an SMS")

    parsed = json.loads(output)
    assert parsed["provider"] == "twilio"


def test_search_tool(wrapper: SemanticAPIWrapper) -> None:
    tool = SemanticAPISearchTool(api_wrapper=wrapper)
    assert tool.name == "semanticapi_search"

    with patch("httpx.Client.get", return_value=_mock_response(MOCK_SEARCH_RESPONSE)):
        output = tool.run("weather")

    parsed = json.loads(output)
    assert len(parsed["results"]) == 2


# -- Toolkit tests ------------------------------------------------------------


def test_toolkit_get_tools() -> None:
    toolkit = SemanticAPIToolkit(api_key="sapi_test")
    tools = toolkit.get_tools()
    assert len(tools) == 2
    names = {t.name for t in tools}
    assert names == {"semanticapi_query", "semanticapi_search"}


# -- Async tests --------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_query(wrapper: SemanticAPIWrapper) -> None:
    with patch("httpx.AsyncClient.post", return_value=_mock_response(MOCK_QUERY_RESPONSE)):
        result = await wrapper.aquery("send an SMS")
    assert result["provider"] == "twilio"


@pytest.mark.asyncio
async def test_async_query_tool(wrapper: SemanticAPIWrapper) -> None:
    tool = SemanticAPIQueryTool(api_wrapper=wrapper)
    with patch("httpx.AsyncClient.post", return_value=_mock_response(MOCK_QUERY_RESPONSE)):
        output = await tool.arun("send an SMS")
    parsed = json.loads(output)
    assert parsed["provider"] == "twilio"
