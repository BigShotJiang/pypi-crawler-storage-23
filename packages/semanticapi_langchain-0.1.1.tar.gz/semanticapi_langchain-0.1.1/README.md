# semanticapi-langchain

LangChain integration for [Semantic API](https://semanticapi.dev) — find the right API for any task using natural language.

[![PyPI](https://img.shields.io/pypi/v/semanticapi-langchain)](https://pypi.org/project/semanticapi-langchain/)
[![Python](https://img.shields.io/pypi/pyversions/semanticapi-langchain)](https://pypi.org/project/semanticapi-langchain/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)

## What is Semantic API?

Semantic API matches natural language queries to real API endpoints. Ask "send an SMS" and get back the best provider, endpoint, parameters, and auth docs — instantly.

## Installation

```bash
pip install semanticapi-langchain
```

## Quick Start

```python
from semanticapi_langchain import SemanticAPIToolkit

# Create toolkit (uses SEMANTICAPI_API_KEY env var)
toolkit = SemanticAPIToolkit(api_key="sapi_your_key")
tools = toolkit.get_tools()

# Use the query tool directly
query_tool = tools[0]
result = query_tool.run("send an SMS")
print(result)
```

## Tools

| Tool | Description |
|------|-------------|
| `semanticapi_query` | Find the best API for a task described in plain English |
| `semanticapi_search` | Search and discover available API capabilities |

## With a LangChain Agent

```python
from langchain_openai import ChatOpenAI
from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate
from semanticapi_langchain import SemanticAPIToolkit

toolkit = SemanticAPIToolkit()
tools = toolkit.get_tools()
llm = ChatOpenAI(model="gpt-4o-mini")

prompt = ChatPromptTemplate.from_messages([
    ("system", "You find APIs for tasks. Use semanticapi tools to discover them."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])

agent = create_tool_calling_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

response = executor.invoke({"input": "How do I send an email programmatically?"})
print(response["output"])
```

## Using the Wrapper Directly

```python
from semanticapi_langchain import SemanticAPIWrapper

api = SemanticAPIWrapper(api_key="sapi_your_key")

# Query for an API
result = api.query("send an SMS")

# Search capabilities
results = api.search("weather")

# List providers
providers = api.list_providers()

# Async support
result = await api.aquery("send an SMS")
```

## Configuration

| Parameter | Env Var | Description |
|-----------|---------|-------------|
| `api_key` | `SEMANTICAPI_API_KEY` | Your Semantic API key |
| `base_url` | — | Override API base URL (default: `https://semanticapi.dev/api`) |
| `timeout` | — | Request timeout in seconds (default: 30) |

## Development

```bash
git clone https://github.com/semanticapi/semanticapi-langchain.git
cd semanticapi-langchain
pip install -e ".[dev]"
pytest
```

## License

MIT
