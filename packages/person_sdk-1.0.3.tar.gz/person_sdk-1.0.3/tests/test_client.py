from __future__ import annotations

import io
import json
import unittest
from datetime import datetime, timezone
from typing import Any
from unittest.mock import MagicMock, patch

from person_sdk import PersonClient, PersonSDKError
from person_sdk.client import _parse_retry_after_seconds


def _mock_response(body: dict[str, Any] | str, status: int = 200) -> MagicMock:
    """Create a mock that behaves like urllib's response context manager."""
    raw = json.dumps(body).encode("utf-8") if isinstance(body, dict) else body.encode("utf-8")
    mock = MagicMock()
    mock.read.return_value = raw
    mock.status = status
    mock.__enter__ = lambda s: s
    mock.__exit__ = MagicMock(return_value=False)
    return mock


def _mock_sse_response(events: list[str]) -> MagicMock:
    """Create a mock response that yields SSE data via chunked read()."""
    payload = "".join(events).encode("utf-8")
    stream = io.BytesIO(payload)
    mock = MagicMock()
    mock.read = stream.read
    mock.close = MagicMock()
    return mock


class TestConstructor(unittest.TestCase):
    def test_raises_when_api_key_empty(self) -> None:
        with self.assertRaises(ValueError, msg="api_key is required"):
            PersonClient(api_key="")

    def test_normalizes_trailing_slash(self) -> None:
        client = PersonClient(api_key="k", base_url="https://api.example.com/")
        self.assertEqual(client.base_url, "https://api.example.com")

    def test_uses_default_base_url(self) -> None:
        client = PersonClient(api_key="k")
        self.assertEqual(client.base_url, "https://api.person.run")

    def test_default_tenant_id(self) -> None:
        client = PersonClient(api_key="k", default_tenant_id="dt1")
        self.assertEqual(client.default_tenant_id, "dt1")

    def test_default_tenant_id_strips_whitespace(self) -> None:
        client = PersonClient(api_key="k", default_tenant_id="  dt1  ")
        self.assertEqual(client.default_tenant_id, "dt1")


class TestHealth(unittest.TestCase):
    @patch("person_sdk.client.urlopen")
    def test_health_sends_get(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response({"status": "ok"})
        client = PersonClient(api_key="test-key")
        result = client.health()

        req = mock_urlopen.call_args[0][0]
        self.assertTrue(req.full_url.endswith("/health"))
        self.assertEqual(req.method, "GET")
        self.assertEqual(req.get_header("X-api-key"), "test-key")
        self.assertEqual(result["status"], "ok")


class TestHeaders(unittest.TestCase):
    @patch("person_sdk.client.urlopen")
    def test_sends_user_agent(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response({"status": "ok"})
        client = PersonClient(api_key="k")
        client.health()
        req = mock_urlopen.call_args[0][0]
        self.assertTrue(req.get_header("User-agent").startswith("person-sdk-python/"))

    @patch("person_sdk.client.urlopen")
    def test_sends_api_key_header(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response({"status": "ok"})
        client = PersonClient(api_key="my-secret")
        client.health()
        req = mock_urlopen.call_args[0][0]
        self.assertEqual(req.get_header("X-api-key"), "my-secret")


class TestTenantIdResolution(unittest.TestCase):
    @patch("person_sdk.client.urlopen")
    def test_uses_default_tenant_id(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response({"personas": []})
        client = PersonClient(api_key="k", default_tenant_id="dt1")
        client.list_personas()
        req = mock_urlopen.call_args[0][0]
        self.assertIn("tenantId=dt1", req.full_url)

    @patch("person_sdk.client.urlopen")
    def test_explicit_tenant_id_overrides_default(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response({"personas": []})
        client = PersonClient(api_key="k", default_tenant_id="dt1")
        client.list_personas(tenant_id="override")
        req = mock_urlopen.call_args[0][0]
        self.assertIn("tenantId=override", req.full_url)

    def test_raises_when_no_tenant_id(self) -> None:
        client = PersonClient(api_key="k")
        with self.assertRaises(ValueError, msg="tenant_id is required"):
            client.list_personas()


class TestRetryAfterParsing(unittest.TestCase):
    def test_parses_retry_after_delay_seconds(self) -> None:
        self.assertEqual(_parse_retry_after_seconds("2"), 2.0)

    def test_parses_retry_after_http_date(self) -> None:
        now_ts = 1_700_000_000.0
        retry_at_header = datetime.fromtimestamp(now_ts + 5, tz=timezone.utc).strftime(
            "%a, %d %b %Y %H:%M:%S GMT"
        )
        self.assertAlmostEqual(
            _parse_retry_after_seconds(retry_at_header, now_ts=now_ts),
            5.0,
            places=6
        )

    def test_returns_none_for_invalid_retry_after(self) -> None:
        self.assertIsNone(_parse_retry_after_seconds("not-a-valid-retry-after"))


class TestPersonaMethods(unittest.TestCase):
    def setUp(self) -> None:
        self.client = PersonClient(api_key="test-key", base_url="https://api.test.com",
                                   default_tenant_id="dt1")
        self.patcher = patch("person_sdk.client.urlopen")
        self.mock_urlopen = self.patcher.start()
        self.mock_urlopen.return_value = _mock_response({
            "personas": [], "persona": {}, "deleted": True
        })

    def tearDown(self) -> None:
        self.patcher.stop()

    def _last_request(self) -> Any:
        return self.mock_urlopen.call_args[0][0]

    def test_list_personas(self) -> None:
        self.client.list_personas(tenant_id="t1", limit=10)
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/personas?", req.full_url)
        self.assertIn("tenantId=t1", req.full_url)
        self.assertIn("limit=10", req.full_url)

    def test_create_persona(self) -> None:
        self.client.create_persona({"firstName": "Jane"}, tenant_id="t1")
        req = self._last_request()
        self.assertEqual(req.method, "POST")
        self.assertTrue(req.full_url.endswith("/personas"))
        body = json.loads(req.data)
        self.assertEqual(body["tenantId"], "t1")
        self.assertEqual(body["seed"]["firstName"], "Jane")

    def test_get_persona(self) -> None:
        self.client.get_persona("p1", tenant_id="t1")
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/personas/p1", req.full_url)
        self.assertIn("tenantId=t1", req.full_url)

    def test_update_persona(self) -> None:
        self.client.update_persona("p1", {"firstName": "Updated"}, tenant_id="t1")
        req = self._last_request()
        self.assertEqual(req.method, "PATCH")
        self.assertIn("/personas/p1", req.full_url)
        body = json.loads(req.data)
        self.assertEqual(body["firstName"], "Updated")

    def test_delete_persona(self) -> None:
        self.client.delete_persona("p1", tenant_id="t1")
        req = self._last_request()
        self.assertEqual(req.method, "DELETE")
        self.assertIn("/personas/p1", req.full_url)
        self.assertIn("tenantId=t1", req.full_url)

    def test_export_persona(self) -> None:
        self.client.export_persona("p1", tenant_id="t1")
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/personas/p1/export", req.full_url)


class TestPromptMethods(unittest.TestCase):
    def setUp(self) -> None:
        self.client = PersonClient(api_key="test-key", default_tenant_id="dt1")
        self.patcher = patch("person_sdk.client.urlopen")
        self.mock_urlopen = self.patcher.start()
        self.mock_urlopen.return_value = _mock_response({
            "response": "hello", "sessions": [], "jobId": "j1"
        })

    def tearDown(self) -> None:
        self.patcher.stop()

    def _last_request(self) -> Any:
        return self.mock_urlopen.call_args[0][0]

    def test_prompt_sync(self) -> None:
        self.client.prompt(persona_id="p1", user_prompt="hello")
        req = self._last_request()
        self.assertEqual(req.method, "POST")
        self.assertTrue(req.full_url.endswith("/personas/prompt"))
        body = json.loads(req.data)
        self.assertEqual(body["mode"], "sync")
        self.assertEqual(body["tenantId"], "dt1")

    def test_prompt_async(self) -> None:
        self.client.prompt(persona_id="p1", user_prompt="hi", mode="async")
        body = json.loads(self._last_request().data)
        self.assertEqual(body["mode"], "async")

    def test_prompt_with_response_url(self) -> None:
        self.client.prompt(
            persona_id="p1", user_prompt="hi",
            mode="async", response_url="https://example.com/cb"
        )
        body = json.loads(self._last_request().data)
        self.assertEqual(body["responseUrl"], "https://example.com/cb")

    def test_prompt_with_session_id(self) -> None:
        self.client.prompt(persona_id="p1", user_prompt="hi", session_id="sess1")
        body = json.loads(self._last_request().data)
        self.assertEqual(body["sessionId"], "sess1")

    def test_get_prompt_job(self) -> None:
        self.client.get_prompt_job("j1")
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/personas/prompt/jobs/j1", req.full_url)

    def test_list_prompt_sessions(self) -> None:
        self.client.list_prompt_sessions(tenant_id="t1", limit=10)
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/personas/prompt/sessions", req.full_url)
        self.assertIn("tenantId=t1", req.full_url)
        self.assertIn("limit=10", req.full_url)


class TestTimelineMethods(unittest.TestCase):
    def setUp(self) -> None:
        self.client = PersonClient(api_key="test-key", default_tenant_id="dt1")
        self.patcher = patch("person_sdk.client.urlopen")
        self.mock_urlopen = self.patcher.start()
        self.mock_urlopen.return_value = _mock_response({
            "timeline": [], "timelineMemory": {}, "timelineEntry": {}, "report": {}
        })

    def tearDown(self) -> None:
        self.patcher.stop()

    def _last_request(self) -> Any:
        return self.mock_urlopen.call_args[0][0]

    def test_list_timeline(self) -> None:
        self.client.list_timeline("p1", tenant_id="t1", limit=10)
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/personas/p1/timeline", req.full_url)
        self.assertIn("tenantId=t1", req.full_url)

    def test_list_timeline_include_superseded(self) -> None:
        self.client.list_timeline("p1", include_superseded=True)
        req = self._last_request()
        self.assertIn("includeSuperseded=true", req.full_url)

    def test_append_timeline_memory(self) -> None:
        self.client.append_timeline_memory("p1", {
            "eventLabel": "birthday", "facts": "turned 30",
        }, tenant_id="t1")
        req = self._last_request()
        self.assertEqual(req.method, "POST")
        self.assertIn("/personas/p1/timeline", req.full_url)
        body = json.loads(req.data)
        self.assertEqual(body["tenantId"], "t1")
        self.assertEqual(body["eventLabel"], "birthday")

    def test_supersede_timeline_entry(self) -> None:
        self.client.supersede_timeline_entry("p1", "tl1", {"reason": "correction"})
        req = self._last_request()
        self.assertEqual(req.method, "POST")
        self.assertIn("/personas/p1/timeline/tl1/supersede", req.full_url)

    def test_run_consistency_check(self) -> None:
        self.client.run_consistency_check("p1")
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/personas/p1/consistency", req.full_url)


class TestSafetyPolicyMethods(unittest.TestCase):
    def setUp(self) -> None:
        self.client = PersonClient(api_key="test-key", default_tenant_id="dt1")
        self.patcher = patch("person_sdk.client.urlopen")
        self.mock_urlopen = self.patcher.start()
        self.mock_urlopen.return_value = _mock_response({
            "policyPack": None, "removed": True
        })

    def tearDown(self) -> None:
        self.patcher.stop()

    def _last_request(self) -> Any:
        return self.mock_urlopen.call_args[0][0]

    def test_get_safety_policy(self) -> None:
        self.client.get_safety_policy("t1")
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/personas/safety-policy", req.full_url)
        self.assertIn("tenantId=t1", req.full_url)

    def test_upsert_safety_policy(self) -> None:
        self.client.upsert_safety_policy({"blockedTerms": ["bad"]}, tenant_id="t1")
        req = self._last_request()
        self.assertEqual(req.method, "PUT")
        body = json.loads(req.data)
        self.assertEqual(body["blockedTerms"], ["bad"])
        self.assertEqual(body["tenantId"], "t1")

    def test_delete_safety_policy(self) -> None:
        self.client.delete_safety_policy("t1")
        req = self._last_request()
        self.assertEqual(req.method, "DELETE")
        self.assertIn("/personas/safety-policy/t1", req.full_url)


class TestPopulationMethods(unittest.TestCase):
    def setUp(self) -> None:
        self.client = PersonClient(api_key="test-key", default_tenant_id="dt1")
        self.patcher = patch("person_sdk.client.urlopen")
        self.mock_urlopen = self.patcher.start()
        self.mock_urlopen.return_value = _mock_response({
            "populations": [], "population": {}, "deleted": True, "personas": []
        })

    def tearDown(self) -> None:
        self.patcher.stop()

    def _last_request(self) -> Any:
        return self.mock_urlopen.call_args[0][0]

    def test_list_populations(self) -> None:
        self.client.list_populations(limit=5)
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/populations", req.full_url)
        self.assertIn("limit=5", req.full_url)

    def test_create_population(self) -> None:
        self.client.create_population({"name": "test-pop", "sourceType": "custom",
                                       "sourceConfig": {}, "targetSize": 10, "scope": "tenant"})
        req = self._last_request()
        self.assertEqual(req.method, "POST")
        body = json.loads(req.data)
        self.assertEqual(body["name"], "test-pop")
        self.assertEqual(body["tenantId"], "dt1")

    def test_get_population(self) -> None:
        self.client.get_population("pop1")
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/populations/pop1", req.full_url)

    def test_delete_population(self) -> None:
        self.client.delete_population("pop1")
        req = self._last_request()
        self.assertEqual(req.method, "DELETE")
        self.assertIn("/populations/pop1", req.full_url)

    def test_list_population_personas(self) -> None:
        self.client.list_population_personas("pop1")
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/populations/pop1/personas", req.full_url)


class TestStudyMethods(unittest.TestCase):
    def setUp(self) -> None:
        self.client = PersonClient(api_key="test-key", default_tenant_id="dt1")
        self.patcher = patch("person_sdk.client.urlopen")
        self.mock_urlopen = self.patcher.start()
        self.mock_urlopen.return_value = _mock_response({
            "studies": [], "study": {}, "deleted": True, "runs": [], "run": {}
        })

    def tearDown(self) -> None:
        self.patcher.stop()

    def _last_request(self) -> Any:
        return self.mock_urlopen.call_args[0][0]

    def test_list_studies(self) -> None:
        self.client.list_studies()
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/studies", req.full_url)

    def test_create_study(self) -> None:
        self.client.create_study({"populationId": "pop1", "taskId": "t1", "name": "study1"})
        req = self._last_request()
        self.assertEqual(req.method, "POST")
        body = json.loads(req.data)
        self.assertEqual(body["name"], "study1")
        self.assertEqual(body["tenantId"], "dt1")

    def test_get_study(self) -> None:
        self.client.get_study("s1")
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/studies/s1", req.full_url)

    def test_delete_study(self) -> None:
        self.client.delete_study("s1")
        req = self._last_request()
        self.assertEqual(req.method, "DELETE")
        self.assertIn("/studies/s1", req.full_url)

    def test_list_study_runs(self) -> None:
        self.client.list_study_runs("s1", status="running")
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/studies/s1/runs", req.full_url)
        self.assertIn("status=running", req.full_url)

    def test_execute_study_run(self) -> None:
        self.client.execute_study_run(
            "s1",
            runtime_inputs={"segment": "beta"},
            context_sources=[{"type": "text", "content": "Launch context"}],
            web_access=True,
            participant_ids=["aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"],
            max_concurrency=5,
            max_personas=100,
            cost_limit_tokens=50000,
        )
        req = self._last_request()
        self.assertEqual(req.method, "POST")
        self.assertIn("/studies/s1/runs", req.full_url)
        body = json.loads(req.data)
        self.assertEqual(body["runtimeInputs"]["segment"], "beta")
        self.assertEqual(body["contextSources"][0]["type"], "text")
        self.assertEqual(body["webAccess"], True)
        self.assertEqual(body["participantIds"][0], "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa")
        self.assertEqual(body["maxConcurrency"], 5)
        self.assertEqual(body["maxPersonas"], 100)
        self.assertEqual(body["costLimitTokens"], 50000)

    def test_get_study_run(self) -> None:
        self.client.get_study_run("s1", "r1")
        req = self._last_request()
        self.assertEqual(req.method, "GET")
        self.assertIn("/studies/s1/runs/r1", req.full_url)


class TestErrorHandling(unittest.TestCase):
    @patch("person_sdk.client.urlopen")
    def test_http_error_with_json_body(self, mock_urlopen: MagicMock) -> None:
        error_body = json.dumps({
            "error": "Validation failed",
            "retryAfterSeconds": 30,
            "metric": "persona_prompt",
            "used": 100,
            "limit": 100,
        }).encode()
        exc = self._make_http_error(422, error_body)
        mock_urlopen.side_effect = exc

        client = PersonClient(api_key="k", max_retries=0)
        with self.assertRaises(PersonSDKError) as ctx:
            client.health()

        self.assertEqual(str(ctx.exception), "Validation failed")
        self.assertEqual(ctx.exception.status_code, 422)
        self.assertEqual(ctx.exception.retry_after_seconds, 30)

    @patch("person_sdk.client.urlopen")
    def test_http_error_with_plain_text(self, mock_urlopen: MagicMock) -> None:
        exc = self._make_http_error(503, b"Service Unavailable")
        mock_urlopen.side_effect = exc

        client = PersonClient(api_key="k", max_retries=0)
        with self.assertRaises(PersonSDKError) as ctx:
            client.health()
        self.assertEqual(ctx.exception.status_code, 503)

    @patch("person_sdk.client.urlopen")
    def test_url_error(self, mock_urlopen: MagicMock) -> None:
        from urllib.error import URLError
        mock_urlopen.side_effect = URLError("connection refused")

        client = PersonClient(api_key="k")
        with self.assertRaises(PersonSDKError) as ctx:
            client.health()
        self.assertIn("Unable to reach", str(ctx.exception))
        self.assertIsNone(ctx.exception.status_code)

    @staticmethod
    def _make_http_error(code: int, body: bytes) -> Any:
        from unittest.mock import MagicMock
        from urllib.error import HTTPError
        fp = io.BytesIO(body)
        return HTTPError(
            url="https://api.person.run/health",
            code=code,
            msg="Error",
            hdrs=MagicMock(),  # type: ignore[arg-type]
            fp=fp,
        )


class TestSSEStreaming(unittest.TestCase):
    @patch("person_sdk.client.urlopen")
    def test_parses_sse_events(self, mock_urlopen: MagicMock) -> None:
        sse_data = (
            'event: delta\ndata: {"delta": "Hello"}\n\n'
            'event: done\ndata: {"sessionId": "s1"}\n\n'
        )
        mock_urlopen.return_value = _mock_sse_response([sse_data])

        client = PersonClient(api_key="k", default_tenant_id="dt1")
        events = list(client.prompt_stream(persona_id="p1", user_prompt="hi"))

        self.assertEqual(len(events), 2)
        self.assertEqual(events[0]["event"], "delta")
        self.assertEqual(events[0]["data"]["delta"], "Hello")
        self.assertEqual(events[1]["event"], "done")
        self.assertEqual(events[1]["data"]["sessionId"], "s1")

    @patch("person_sdk.client.urlopen")
    def test_stream_sends_post(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_sse_response(
            ['event: done\ndata: {"ok": true}\n\n']
        )
        client = PersonClient(api_key="k", default_tenant_id="dt1")
        list(client.prompt_stream(persona_id="p1", user_prompt="hi"))

        req = mock_urlopen.call_args[0][0]
        self.assertEqual(req.method, "POST")
        self.assertIn("/personas/prompt/stream", req.full_url)
        self.assertEqual(req.get_header("Accept"), "text/event-stream")

    @patch("person_sdk.client.urlopen")
    def test_stream_http_error(self, mock_urlopen: MagicMock) -> None:
        fp = io.BytesIO(json.dumps({"error": "Rate limited"}).encode())
        from urllib.error import HTTPError
        mock_urlopen.side_effect = HTTPError(
            url="https://api.person.run/personas/prompt/stream",
            code=429, msg="Too Many", hdrs=MagicMock(), fp=fp,  # type: ignore[arg-type]
        )
        client = PersonClient(api_key="k", default_tenant_id="dt1")
        with self.assertRaises(PersonSDKError) as ctx:
            list(client.prompt_stream(persona_id="p1", user_prompt="hi"))
        self.assertEqual(ctx.exception.status_code, 429)


class TestQueryString(unittest.TestCase):
    @patch("person_sdk.client.urlopen")
    def test_omits_none_values(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.return_value = _mock_response({"personas": []})
        client = PersonClient(api_key="k", default_tenant_id="dt1")
        client.list_personas(search=None)
        req = mock_urlopen.call_args[0][0]
        self.assertNotIn("None", req.full_url)
        self.assertIn("tenantId=dt1", req.full_url)


if __name__ == "__main__":
    unittest.main()
