from __future__ import annotations

import json
import time
from collections.abc import Iterator
from datetime import timezone
from email.utils import parsedate_to_datetime
from typing import Any, Mapping
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

from .errors import PersonSDKError

SDK_VERSION = "1.0.2"
DEFAULT_BASE_URL = "https://api.person.run"
DEFAULT_TIMEOUT_SECONDS = 15.0
MAX_RETRIES = 2
RETRY_BASE_SECONDS = 0.5
RETRYABLE_STATUS_CODES = frozenset({429, 502, 503, 504})
MAX_RETRY_AFTER_SECONDS = 30.0

JsonDict = dict[str, Any]


def _parse_retry_after_seconds(retry_after_header: str | None, *, now_ts: float | None = None) -> float | None:
    if not retry_after_header:
        return None

    raw_value = retry_after_header.strip()
    if not raw_value:
        return None

    try:
        retry_after_seconds = float(raw_value)
    except ValueError:
        retry_after_seconds = None

    if retry_after_seconds is not None:
        return min(max(0.0, retry_after_seconds), MAX_RETRY_AFTER_SECONDS)

    try:
        retry_at = parsedate_to_datetime(raw_value)
    except (TypeError, ValueError, IndexError):
        return None

    if retry_at.tzinfo is None:
        retry_at = retry_at.replace(tzinfo=timezone.utc)

    now_seconds = now_ts if now_ts is not None else time.time()
    delay_seconds = retry_at.timestamp() - now_seconds
    return min(max(0.0, delay_seconds), MAX_RETRY_AFTER_SECONDS)


class PersonClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
        default_tenant_id: str | None = None,
        max_retries: int = MAX_RETRIES,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries
        normalized = (default_tenant_id or "").strip()
        self.default_tenant_id = normalized if normalized else None

    def _resolve_tenant_id(self, tenant_id: str | None = None) -> str:
        normalized = (tenant_id or "").strip()
        if normalized:
            return normalized
        if self.default_tenant_id:
            return self.default_tenant_id
        raise ValueError(
            "tenant_id is required. Pass it in the request or configure default_tenant_id on PersonClient."
        )

    @staticmethod
    def _encode_path_segment(value: str) -> str:
        """URL-encode a single path segment to prevent path traversal / injection."""
        return quote(value, safe="")

    def _build_url(self, path: str, query: Mapping[str, Any] | None = None) -> str:
        normalized_path = path if path.startswith("/") else f"/{path}"
        url = f"{self.base_url}{normalized_path}"
        if not query:
            return url

        encoded_query = urlencode(
            {key: value for key, value in query.items() if value is not None}
        )
        return f"{url}?{encoded_query}" if encoded_query else url

    def _decode_json(self, raw: bytes, fallback_error: str) -> Any:
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise PersonSDKError(fallback_error) from exc

    def _request(
        self,
        method: str,
        path: str,
        *,
        query: Mapping[str, Any] | None = None,
        body: Mapping[str, Any] | None = None,
    ) -> JsonDict:
        payload = None
        headers = {
            "Accept": "application/json",
            "x-api-key": self.api_key,
            "User-Agent": f"person-sdk-python/{SDK_VERSION}",
        }

        if body is not None:
            headers["Content-Type"] = "application/json"
            payload = json.dumps(body).encode("utf-8")

        request = Request(
            self._build_url(path, query=query),
            data=payload,
            headers=headers,
            method=method,
        )

        last_exc: PersonSDKError | None = None
        for attempt in range(self.max_retries + 1):
            try:
                with urlopen(request, timeout=self.timeout_seconds) as response:
                    parsed = self._decode_json(
                        response.read(),
                        "Received invalid JSON from person.run",
                    )
                    if isinstance(parsed, dict):
                        return parsed
                    raise PersonSDKError("Expected JSON object response from person.run")
            except HTTPError as exc:
                parsed_error = self._try_decode_json(exc.read())
                message = (
                    parsed_error.get("error")
                    if isinstance(parsed_error, dict)
                    and isinstance(parsed_error.get("error"), str)
                    else f"Request failed with status {exc.code}"
                )
                last_exc = PersonSDKError(message, status_code=exc.code, payload=parsed_error)

                if exc.code in RETRYABLE_STATUS_CODES and attempt < self.max_retries:
                    retry_after = exc.headers.get("retry-after") if exc.headers else None
                    delay = _parse_retry_after_seconds(retry_after)
                    if delay is None:
                        delay = RETRY_BASE_SECONDS * (2 ** attempt)
                    time.sleep(delay)
                    continue

                raise last_exc from exc
            except URLError as exc:
                raise PersonSDKError("Unable to reach person.run API") from exc

        raise last_exc or PersonSDKError("Request failed after retries")

    @staticmethod
    def _try_decode_json(raw: bytes) -> Any:
        """Best-effort JSON decode; returns None on failure instead of raising."""
        if not raw:
            return None
        try:
            return json.loads(raw.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return None

    # -- Streaming -----------------------------------------------------------

    def _request_stream(
        self,
        path: str,
        body: Mapping[str, Any],
    ) -> Iterator[JsonDict]:
        """POST with Accept: text/event-stream, yield parsed SSE events."""
        headers = {
            "Accept": "text/event-stream",
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "User-Agent": f"person-sdk-python/{SDK_VERSION}",
        }
        request = Request(
            self._build_url(path),
            data=json.dumps(body).encode("utf-8"),
            headers=headers,
            method="POST",
        )

        try:
            response = urlopen(request, timeout=self.timeout_seconds)
        except HTTPError as exc:
            parsed_error = self._try_decode_json(exc.read())
            message = (
                parsed_error.get("error")
                if isinstance(parsed_error, dict)
                and isinstance(parsed_error.get("error"), str)
                else f"Request failed with status {exc.code}"
            )
            raise PersonSDKError(message, status_code=exc.code, payload=parsed_error) from exc
        except URLError as exc:
            raise PersonSDKError("Unable to reach person.run API") from exc

        try:
            yield from _parse_sse_stream(response)
        finally:
            response.close()

    # -- Health --------------------------------------------------------------

    def health(self) -> JsonDict:
        return self._request("GET", "/health")

    # -- Personas ------------------------------------------------------------

    def list_personas(
        self,
        tenant_id: str | None = None,
        *,
        limit: int = 20,
        offset: int = 0,
        search: str | None = None,
    ) -> JsonDict:
        return self._request(
            "GET",
            "/personas",
            query={
                "tenantId": self._resolve_tenant_id(tenant_id),
                "limit": limit,
                "offset": offset,
                "search": search,
            },
        )

    def create_persona(self, seed: Mapping[str, Any], tenant_id: str | None = None) -> JsonDict:
        return self._request(
            "POST",
            "/personas",
            body={"tenantId": self._resolve_tenant_id(tenant_id), "seed": dict(seed)},
        )

    def get_persona(self, persona_id: str, tenant_id: str | None = None) -> JsonDict:
        return self._request(
            "GET",
            f"/personas/{self._encode_path_segment(persona_id)}",
            query={"tenantId": self._resolve_tenant_id(tenant_id)},
        )

    def update_persona(
        self,
        persona_id: str,
        updates: Mapping[str, Any],
        tenant_id: str | None = None,
    ) -> JsonDict:
        payload: JsonDict = {"tenantId": self._resolve_tenant_id(tenant_id)}
        payload.update(dict(updates))
        return self._request("PATCH", f"/personas/{self._encode_path_segment(persona_id)}", body=payload)

    def delete_persona(self, persona_id: str, tenant_id: str | None = None) -> JsonDict:
        return self._request(
            "DELETE",
            f"/personas/{self._encode_path_segment(persona_id)}",
            query={"tenantId": self._resolve_tenant_id(tenant_id)},
        )

    def export_persona(self, persona_id: str, tenant_id: str | None = None) -> JsonDict:
        return self._request(
            "GET",
            f"/personas/{self._encode_path_segment(persona_id)}/export",
            query={"tenantId": self._resolve_tenant_id(tenant_id)},
        )

    # -- Prompting -----------------------------------------------------------

    def prompt(
        self,
        *,
        persona_id: str,
        user_prompt: str,
        tenant_id: str | None = None,
        mode: str = "sync",
        response_url: str | None = None,
        session_id: str | None = None,
    ) -> JsonDict:
        body: JsonDict = {
            "tenantId": self._resolve_tenant_id(tenant_id),
            "personaId": persona_id,
            "userPrompt": user_prompt,
            "mode": mode,
        }
        if response_url is not None:
            body["responseUrl"] = response_url
        if session_id is not None:
            body["sessionId"] = session_id
        return self._request("POST", "/personas/prompt", body=body)

    def prompt_stream(
        self,
        *,
        persona_id: str,
        user_prompt: str,
        tenant_id: str | None = None,
        session_id: str | None = None,
    ) -> Iterator[JsonDict]:
        body: JsonDict = {
            "tenantId": self._resolve_tenant_id(tenant_id),
            "personaId": persona_id,
            "userPrompt": user_prompt,
        }
        if session_id is not None:
            body["sessionId"] = session_id
        return self._request_stream("/personas/prompt/stream", body)

    def get_prompt_job(self, job_id: str) -> JsonDict:
        return self._request("GET", f"/personas/prompt/jobs/{self._encode_path_segment(job_id)}")

    def list_prompt_sessions(
        self,
        tenant_id: str | None = None,
        *,
        limit: int = 25,
    ) -> JsonDict:
        return self._request(
            "GET",
            "/personas/prompt/sessions",
            query={"tenantId": self._resolve_tenant_id(tenant_id), "limit": limit},
        )

    # -- Timeline ------------------------------------------------------------

    def list_timeline(
        self,
        persona_id: str,
        tenant_id: str | None = None,
        *,
        limit: int = 50,
        offset: int = 0,
        include_superseded: bool = False,
    ) -> JsonDict:
        return self._request(
            "GET",
            f"/personas/{self._encode_path_segment(persona_id)}/timeline",
            query={
                "tenantId": self._resolve_tenant_id(tenant_id),
                "limit": limit,
                "offset": offset,
                "includeSuperseded": str(include_superseded).lower(),
            },
        )

    def append_timeline_memory(
        self,
        persona_id: str,
        memory: Mapping[str, Any],
        tenant_id: str | None = None,
    ) -> JsonDict:
        payload: JsonDict = {"tenantId": self._resolve_tenant_id(tenant_id)}
        payload.update(dict(memory))
        return self._request(
            "POST",
            f"/personas/{self._encode_path_segment(persona_id)}/timeline",
            body=payload,
        )

    def supersede_timeline_entry(
        self,
        persona_id: str,
        timeline_id: str,
        body: Mapping[str, Any],
        tenant_id: str | None = None,
    ) -> JsonDict:
        payload: JsonDict = {"tenantId": self._resolve_tenant_id(tenant_id)}
        payload.update(dict(body))
        return self._request(
            "POST",
            f"/personas/{self._encode_path_segment(persona_id)}/timeline/{self._encode_path_segment(timeline_id)}/supersede",
            body=payload,
        )

    def run_consistency_check(self, persona_id: str) -> JsonDict:
        return self._request("GET", f"/personas/{self._encode_path_segment(persona_id)}/consistency")

    # -- Safety Policy -------------------------------------------------------

    def get_safety_policy(self, tenant_id: str | None = None) -> JsonDict:
        return self._request(
            "GET",
            "/personas/safety-policy",
            query={"tenantId": self._resolve_tenant_id(tenant_id)},
        )

    def upsert_safety_policy(self, policy_pack: Mapping[str, Any], tenant_id: str | None = None) -> JsonDict:
        payload: JsonDict = dict(policy_pack)
        payload["tenantId"] = self._resolve_tenant_id(tenant_id)
        return self._request("PUT", "/personas/safety-policy", body=payload)

    def delete_safety_policy(self, tenant_id: str | None = None) -> JsonDict:
        return self._request(
            "DELETE",
            f"/personas/safety-policy/{self._encode_path_segment(self._resolve_tenant_id(tenant_id))}",
        )

    # -- Populations ---------------------------------------------------------

    def list_populations(
        self,
        tenant_id: str | None = None,
        *,
        limit: int = 20,
        offset: int = 0,
    ) -> JsonDict:
        return self._request(
            "GET",
            "/populations",
            query={"tenantId": self._resolve_tenant_id(tenant_id), "limit": limit, "offset": offset},
        )

    def create_population(self, population: Mapping[str, Any], tenant_id: str | None = None) -> JsonDict:
        payload: JsonDict = dict(population)
        payload["tenantId"] = self._resolve_tenant_id(tenant_id)
        return self._request("POST", "/populations", body=payload)

    def get_population(self, population_id: str, tenant_id: str | None = None) -> JsonDict:
        return self._request(
            "GET",
            f"/populations/{self._encode_path_segment(population_id)}",
            query={"tenantId": self._resolve_tenant_id(tenant_id)},
        )

    def delete_population(self, population_id: str, tenant_id: str | None = None) -> JsonDict:
        return self._request(
            "DELETE",
            f"/populations/{self._encode_path_segment(population_id)}",
            query={"tenantId": self._resolve_tenant_id(tenant_id)},
        )

    def list_population_personas(
        self,
        population_id: str,
        tenant_id: str | None = None,
        *,
        limit: int = 20,
        offset: int = 0,
    ) -> JsonDict:
        return self._request(
            "GET",
            f"/populations/{self._encode_path_segment(population_id)}/personas",
            query={"tenantId": self._resolve_tenant_id(tenant_id), "limit": limit, "offset": offset},
        )

    # -- Studies -------------------------------------------------------------

    def list_studies(
        self,
        tenant_id: str | None = None,
        *,
        limit: int = 20,
        offset: int = 0,
    ) -> JsonDict:
        return self._request(
            "GET",
            "/studies",
            query={"tenantId": self._resolve_tenant_id(tenant_id), "limit": limit, "offset": offset},
        )

    def create_study(self, study: Mapping[str, Any], tenant_id: str | None = None) -> JsonDict:
        payload: JsonDict = dict(study)
        payload["tenantId"] = self._resolve_tenant_id(tenant_id)
        return self._request("POST", "/studies", body=payload)

    def get_study(self, study_id: str, tenant_id: str | None = None) -> JsonDict:
        return self._request(
            "GET",
            f"/studies/{self._encode_path_segment(study_id)}",
            query={"tenantId": self._resolve_tenant_id(tenant_id)},
        )

    def delete_study(self, study_id: str, tenant_id: str | None = None) -> JsonDict:
        return self._request(
            "DELETE",
            f"/studies/{self._encode_path_segment(study_id)}",
            query={"tenantId": self._resolve_tenant_id(tenant_id)},
        )

    def list_study_runs(
        self,
        study_id: str,
        tenant_id: str | None = None,
        *,
        limit: int = 20,
        offset: int = 0,
        status: str | None = None,
    ) -> JsonDict:
        return self._request(
            "GET",
            f"/studies/{self._encode_path_segment(study_id)}/runs",
            query={
                "tenantId": self._resolve_tenant_id(tenant_id),
                "limit": limit,
                "offset": offset,
                "status": status,
            },
        )

    def execute_study_run(
        self,
        study_id: str,
        tenant_id: str | None = None,
        *,
        runtime_inputs: Mapping[str, Any] | None = None,
        context_sources: list[Mapping[str, Any]] | None = None,
        web_access: bool | None = None,
        participant_ids: list[str] | None = None,
        max_concurrency: int | None = None,
        max_personas: int | None = None,
        cost_limit_tokens: int | None = None,
    ) -> JsonDict:
        body: JsonDict = {"tenantId": self._resolve_tenant_id(tenant_id)}
        if runtime_inputs is not None:
            body["runtimeInputs"] = dict(runtime_inputs)
        if context_sources is not None:
            body["contextSources"] = list(context_sources)
        if web_access is not None:
            body["webAccess"] = web_access
        if participant_ids is not None:
            body["participantIds"] = list(participant_ids)
        if max_concurrency is not None:
            body["maxConcurrency"] = max_concurrency
        if max_personas is not None:
            body["maxPersonas"] = max_personas
        if cost_limit_tokens is not None:
            body["costLimitTokens"] = cost_limit_tokens
        return self._request("POST", f"/studies/{self._encode_path_segment(study_id)}/runs", body=body)

    def get_study_run(self, study_id: str, run_id: str, tenant_id: str | None = None) -> JsonDict:
        return self._request(
            "GET",
            f"/studies/{self._encode_path_segment(study_id)}/runs/{self._encode_path_segment(run_id)}",
            query={"tenantId": self._resolve_tenant_id(tenant_id)},
        )


# ---------------------------------------------------------------------------
# SSE parsing (module-level, stdlib only)
# ---------------------------------------------------------------------------

def _parse_sse_stream(response: Any) -> Iterator[JsonDict]:
    """Read a streaming HTTP response and yield parsed SSE events."""
    buffer = ""
    for chunk in _iter_chunks(response):
        buffer += chunk
        buffer = buffer.replace("\r\n", "\n")

        while "\n\n" in buffer:
            boundary = buffer.index("\n\n")
            raw_event = buffer[:boundary].strip()
            buffer = buffer[boundary + 2:]
            if raw_event:
                parsed = _parse_single_sse(raw_event)
                if parsed is not None:
                    yield parsed

    remaining = buffer.strip()
    if remaining:
        parsed = _parse_single_sse(remaining)
        if parsed is not None:
            yield parsed


def _iter_chunks(response: Any, size: int = 4096) -> Iterator[str]:
    """Yield decoded string chunks from an HTTP response."""
    while True:
        data = response.read(size)
        if not data:
            break
        yield data.decode("utf-8", errors="replace")


def _parse_single_sse(raw: str) -> JsonDict | None:
    """Parse one SSE frame into {event, data}."""
    event_name = "message"
    data_lines: list[str] = []

    for line in raw.split("\n"):
        if not line or line.startswith(":"):
            continue
        sep = line.find(":")
        if sep == -1:
            continue
        field = line[:sep].strip()
        value = line[sep + 1:].lstrip()
        if field == "event":
            event_name = value or event_name
        elif field == "data":
            data_lines.append(value)

    if not data_lines:
        return None

    joined = "\n".join(data_lines)
    try:
        parsed_data = json.loads(joined)
    except json.JSONDecodeError:
        parsed_data = joined

    return {"event": event_name, "data": parsed_data}
