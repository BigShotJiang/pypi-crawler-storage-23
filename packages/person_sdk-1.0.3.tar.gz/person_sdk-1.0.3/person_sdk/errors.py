from __future__ import annotations

from typing import Any


class PersonSDKError(RuntimeError):
    """Represents an API or transport failure from person.run."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        payload: Any = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.payload = payload
        self.retry_after_seconds: float | None = None
        self.metric: str | None = None
        self.used: int | None = None
        self.limit: int | None = None

        if isinstance(payload, dict):
            if isinstance(payload.get("retryAfterSeconds"), (int, float)):
                self.retry_after_seconds = payload["retryAfterSeconds"]
            if isinstance(payload.get("metric"), str):
                self.metric = payload["metric"]
            if isinstance(payload.get("used"), int):
                self.used = payload["used"]
            if isinstance(payload.get("limit"), int):
                self.limit = payload["limit"]
