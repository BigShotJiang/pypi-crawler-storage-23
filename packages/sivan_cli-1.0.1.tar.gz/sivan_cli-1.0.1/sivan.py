import os
import sys
import json
import argparse
import requests
import subprocess

# Your live server URL!
API_URL = "https://sivan-code.onrender.com/generate"

# This creates a hidden vault on the user's computer to store the auth code
CONFIG_FILE = os.path.expanduser("~/.sivan_config")

def save_auth(code: str):
    """Saves the secret code locally."""
    with open(CONFIG_FILE, "w") as f:
        json.dump({"auth_code": code}, f)
    print(f"✅ Authentication code saved securely to your computer!")

def get_auth() -> str:
    """Retrieves the saved secret code."""
    if not os.path.exists(CONFIG_FILE):
        print("❌ You need to authenticate first! Run: sivan auth YOUR_SECRET_CODE")
        sys.exit(1)
    with open(CONFIG_FILE, "r") as f:
        return json.load(f).get("auth_code", "")

def generate_code(prompt: str):
    """Sends the prompt to your Render server and saves the result."""
    auth_code = get_auth()
    print(f"🧠 Sivan is thinking about: '{prompt}'...")
    print("⏳ This usually takes 1-3 minutes. Please wait...\n")
    
    try:
        # Send the request to your Brain
        response = requests.post(
            API_URL, 
            json={"auth_code": auth_code, "prompt": prompt},
            timeout=600 # 5-minute timeout because Sivan iterates multiple times
        )
        
        if response.status_code == 401:
            print("❌ Authentication failed. Your auth code is invalid.")
            sys.exit(1)
        elif response.status_code != 200:
            print(f"❌ Server Error: {response.text}")
            sys.exit(1)
            
        data = response.json()
        final_code = data.get("code", "")
        
        if not final_code:
            print("❌ No code was generated.")
            sys.exit(1)
            
        # Save the file to whatever folder the user is currently in
        output_file = "sivan_output.py"
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(final_code)
            
        print(f"✅ Success! Code generated and saved to {output_file}")
        
        # Magic Trick: Automatically open the file in their default code editor!
        if sys.platform == "win32":
            os.startfile(output_file)
        elif sys.platform == "darwin": # macOS
            subprocess.call(["open", output_file])
        else: # Linux
            subprocess.call(["xdg-open", output_file])
            
    except requests.exceptions.Timeout:
        print("❌ The server took too long to respond. Sivan might be writing a massive file!")
    except Exception as e:
        print(f"❌ Connection Error: {str(e)}")

def main():
    parser = argparse.ArgumentParser(description="Sivan AI CLI - Your Professional Coding Agent")
    subparsers = parser.add_subparsers(dest="command", required=True)
    
    # The 'auth' command
    auth_parser = subparsers.add_parser("auth", help="Authenticate with your secret code")
    auth_parser.add_argument("code", type=str, help="Your secret authentication code")
    
    # The 'generate' command
    gen_parser = subparsers.add_parser("generate", help="Ask Sivan to build something")
    gen_parser.add_argument("prompt", type=str, help="What do you want to build?")
    
    args = parser.parse_args()
    
    if args.command == "auth":
        save_auth(args.code)
    elif args.command == "generate":
        generate_code(args.prompt)

if __name__ == "__main__":
    main()
