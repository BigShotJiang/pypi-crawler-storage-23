# Username and Password for a first account, the main account to be used for testing
username = ""
password = ""

# Username and Password for a second account, used when two accounts need to interact
sender_username = ""
sender_password = ""