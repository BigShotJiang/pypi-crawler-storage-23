import music_tag

MediaInfo = music_tag.load_file
