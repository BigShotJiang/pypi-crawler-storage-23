"""PowerPoint presentation tools for OneDrive."""

from enum import Enum
from typing import Annotated, cast

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_microsoft_utils.drive_utils import _smart_upload_content
from arcade_microsoft_utils.powerpoint_utils import (
    PPTX_MIME_TYPE,
    SlideLayout,
    _add_slide_to_pptx,
    _add_two_content_slide_to_pptx,
    _build_blank_pptx_bytes,
    _convert_pptx_to_markdown,
    _download_presentation_content,
    _ensure_download_size_under_limit,
    _ensure_pptx_drive_item,
    _get_all_slide_notes_as_markdown,
    _get_presentation_drive_item,
    _get_slide_count,
    _get_slide_notes_as_markdown,
    _normalize_pptx_title,
    _set_slide_notes_from_markdown,
)

from arcade_microsoft_powerpoint.serializers import serialize_presentation_item
from arcade_microsoft_powerpoint.tool_responses import (
    CreatePresentationResponse,
    CreateSlideResponse,
    GetAllSlideNotesResponse,
    GetPresentationAsMarkdownResponse,
    GetSlideNotesResponse,
    SetSlideNotesResponse,
)


class SlideLayoutOption(str, Enum):
    """Available slide layout options for create_slide.

    For TWO_CONTENT layout with left/right content areas, use create_two_content_slide instead.
    """

    TITLE = "TITLE"
    TITLE_AND_CONTENT = "TITLE_AND_CONTENT"
    SECTION_HEADER = "SECTION_HEADER"
    TITLE_ONLY = "TITLE_ONLY"
    BLANK = "BLANK"
    CONTENT_WITH_CAPTION = "CONTENT_WITH_CAPTION"
    PICTURE_WITH_CAPTION = "PICTURE_WITH_CAPTION"
    TITLE_AND_VERTICAL_TEXT = "TITLE_AND_VERTICAL_TEXT"
    VERTICAL_TITLE_AND_TEXT = "VERTICAL_TITLE_AND_TEXT"


@tool(
    requires_auth=Microsoft(scopes=["Files.ReadWrite"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.PRESENTATIONS],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_presentation(
    context: Context,
    title: Annotated[str, "The title for the new presentation."],
    parent_folder_id: Annotated[
        str | None,
        "The ID of the folder to create the presentation in. If not provided, "
        "the presentation will be created in the root of the user's OneDrive.",
    ] = None,
) -> Annotated[CreatePresentationResponse, "The created presentation details."]:
    """
    Create a new PowerPoint presentation in OneDrive.

    The presentation will be created with a title slide containing the specified title.
    """
    # Normalize title and ensure it has .pptx extension
    filename = _normalize_pptx_title(title)

    # Build the presentation bytes
    pptx_bytes = _build_blank_pptx_bytes(title=title)

    token = context.get_auth_token_or_empty()

    # Upload (auto-selects simple vs resumable based on size)
    response = await _smart_upload_content(
        token=token,
        content=pptx_bytes,
        content_type=PPTX_MIME_TYPE,
        filename=filename,
        parent_item_id=parent_folder_id,
        conflict_behavior="fail",
    )

    # Get the created item details
    item_id = response.get("id")
    if not item_id:
        raise ToolExecutionError("Failed to create presentation: no item ID returned.")

    # Fetch the drive item to get full metadata
    drive_item = await _get_presentation_drive_item(context, item_id)
    slide_count = _get_slide_count(pptx_bytes)

    return cast(
        CreatePresentationResponse,
        {
            "item": serialize_presentation_item(drive_item, slide_count),
            "message": f"Successfully created presentation '{filename}'.",
        },
    )


@tool(
    requires_auth=Microsoft(scopes=["Files.ReadWrite"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.PRESENTATIONS],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_slide(
    context: Context,
    item_id: Annotated[str, "The ID of the PowerPoint presentation to add a slide to."],
    slide_title: Annotated[
        str | None,
        "The title for the new slide. Optional for layouts like BLANK.",
    ] = None,
    slide_body: Annotated[
        str | None,
        "The body content for the new slide. Supports markdown: **bold**, *italic*, __underline__, and bullet points (- item, indented with spaces for nesting). Optional for layouts like TITLE_ONLY or BLANK.",
    ] = None,
    layout: Annotated[
        SlideLayoutOption | None,
        "The layout to use for the slide. For TWO_CONTENT layout, use create_two_content_slide.",
    ] = None,
) -> Annotated[CreateSlideResponse, "The updated presentation details with new slide info."]:
    """
    Append a new slide to the end of an existing PowerPoint presentation in OneDrive.

    The slide will be added at the end of the presentation. Both title and body
    are optional to support layouts like BLANK or TITLE_ONLY.

    For presentations larger than 4 MB, the upload uses a resumable session.
    Concurrency protection (etag check) is best-effort in that case, since
    Microsoft Graph upload sessions do not support If-Match headers.
    """
    if not item_id or not item_id.strip():
        raise ToolExecutionError("item_id is required.")

    drive_item = await _get_presentation_drive_item(context, item_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)

    pptx_bytes = await _download_presentation_content(context, item_id)
    slide_layout = _parse_layout(layout)

    updated_bytes = _add_slide_to_pptx(pptx_bytes, slide_title, slide_body, slide_layout)

    token = context.get_auth_token_or_empty()
    await _smart_upload_content(
        token=token,
        content=updated_bytes,
        content_type=PPTX_MIME_TYPE,
        item_id=item_id,
        etag=drive_item.e_tag,
    )

    updated_item = await _get_presentation_drive_item(context, item_id)
    new_slide_count = _get_slide_count(updated_bytes)

    slide_desc = slide_title or f"{slide_layout.name} slide"

    return cast(
        CreateSlideResponse,
        {
            "slide": {
                "slide_index": new_slide_count,
                "layout": slide_layout.name,
                "title": slide_title or "",
            },
            "item": serialize_presentation_item(updated_item, new_slide_count),
            "message": f"Successfully added '{slide_desc}' to presentation.",
        },
    )


@tool(
    requires_auth=Microsoft(scopes=["Files.ReadWrite"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.PRESENTATIONS],
        ),
        behavior=Behavior(
            operations=[Operation.CREATE],
            read_only=False,
            destructive=False,
            idempotent=False,
            open_world=True,
        ),
    ),
)
async def create_two_content_slide(
    context: Context,
    item_id: Annotated[str, "The ID of the PowerPoint presentation to add a slide to."],
    slide_title: Annotated[
        str | None,
        "The title for the new slide.",
    ] = None,
    left_body: Annotated[
        str | None,
        "Content for the left side of the slide. Supports markdown: **bold**, *italic*, __underline__, and bullet points (- item, indented with spaces for nesting).",
    ] = None,
    right_body: Annotated[
        str | None,
        "Content for the right side of the slide. Supports markdown: **bold**, *italic*, __underline__, and bullet points (- item, indented with spaces for nesting).",
    ] = None,
) -> Annotated[CreateSlideResponse, "The updated presentation details with new slide info."]:
    """
    Append a TWO_CONTENT slide with side-by-side content areas to the end of a PowerPoint presentation.

    This layout is useful for comparisons, pros/cons lists, or any content that
    benefits from a two-column layout.

    For presentations larger than 4 MB, the upload uses a resumable session.
    Concurrency protection (etag check) is best-effort in that case, since
    Microsoft Graph upload sessions do not support If-Match headers.
    """
    if not item_id or not item_id.strip():
        raise ToolExecutionError("item_id is required.")
    drive_item = await _get_presentation_drive_item(context, item_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)
    pptx_bytes = await _download_presentation_content(context, item_id)
    updated_bytes = _add_two_content_slide_to_pptx(pptx_bytes, slide_title, left_body, right_body)

    token = context.get_auth_token_or_empty()
    await _smart_upload_content(
        token=token,
        content=updated_bytes,
        content_type=PPTX_MIME_TYPE,
        item_id=item_id,
        etag=drive_item.e_tag,
    )
    updated_item = await _get_presentation_drive_item(context, item_id)
    new_slide_count = _get_slide_count(updated_bytes)

    slide_desc = slide_title or "Two-content slide"

    return cast(
        CreateSlideResponse,
        {
            "slide": {
                "slide_index": new_slide_count,
                "layout": "TWO_CONTENT",
                "title": slide_title or "",
                "left_body": left_body or "",
                "right_body": right_body or "",
            },
            "item": serialize_presentation_item(updated_item, new_slide_count),
            "message": f"Successfully added '{slide_desc}' to presentation.",
        },
    )


@tool(
    requires_auth=Microsoft(scopes=["Files.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.PRESENTATIONS],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_presentation_as_markdown(
    context: Context,
    item_id: Annotated[str, "The ID of the PowerPoint presentation to read."],
) -> Annotated[GetPresentationAsMarkdownResponse, "The presentation content as markdown."]:
    """
    Get the content of a PowerPoint presentation as markdown.

    This tool downloads the presentation and converts it to a markdown representation,
    preserving text content, tables, and chart data. Images and other media are
    represented as placeholders.
    """
    # Validate item_id
    if not item_id or not item_id.strip():
        raise ToolExecutionError("item_id is required.")

    # Get the drive item and validate it's a .pptx
    drive_item = await _get_presentation_drive_item(context, item_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)

    # Download the presentation
    pptx_bytes = await _download_presentation_content(context, item_id)

    # Convert to markdown
    markdown_content = _convert_pptx_to_markdown(pptx_bytes)

    # Get slide count
    slide_count = _get_slide_count(pptx_bytes)

    return cast(
        GetPresentationAsMarkdownResponse,
        {
            "item_id": item_id,
            "name": drive_item.name or "presentation.pptx",
            "web_url": drive_item.web_url or "",
            "etag": drive_item.e_tag or "",
            "slide_count": slide_count,
            "content": markdown_content,
        },
    )


def _parse_layout(layout: SlideLayoutOption | str | None) -> SlideLayout:  # type: ignore[no-any-unimported]
    """Convert SlideLayoutOption enum or string to SlideLayout (IntEnum for python-pptx)."""
    if not layout:
        return SlideLayout.TITLE_AND_CONTENT

    # Get the value - for enum use .value, for str use directly
    if isinstance(layout, SlideLayoutOption):
        layout_str = layout.value.upper()
    else:
        layout_str = layout.strip().upper()

    layout_map: dict[str, SlideLayout] = {  # type: ignore[no-any-unimported]
        "TITLE": SlideLayout.TITLE,
        "TITLE_AND_CONTENT": SlideLayout.TITLE_AND_CONTENT,
        "SECTION_HEADER": SlideLayout.SECTION_HEADER,
        "TWO_CONTENT": SlideLayout.TWO_CONTENT,
        "COMPARISON": SlideLayout.COMPARISON,
        "TITLE_ONLY": SlideLayout.TITLE_ONLY,
        "BLANK": SlideLayout.BLANK,
        "CONTENT_WITH_CAPTION": SlideLayout.CONTENT_WITH_CAPTION,
        "PICTURE_WITH_CAPTION": SlideLayout.PICTURE_WITH_CAPTION,
        "TITLE_AND_VERTICAL_TEXT": SlideLayout.TITLE_AND_VERTICAL_TEXT,
        "VERTICAL_TITLE_AND_TEXT": SlideLayout.VERTICAL_TITLE_AND_TEXT,
    }

    return layout_map.get(layout_str, SlideLayout.TITLE_AND_CONTENT)


@tool(
    requires_auth=Microsoft(scopes=["Files.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.PRESENTATIONS],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_slide_notes(
    context: Context,
    item_id: Annotated[str, "The ID of the PowerPoint presentation."],
    slide_index: Annotated[int, "The 1-based index of the slide to get notes from."],
) -> Annotated[GetSlideNotesResponse, "The speaker notes for the specified slide."]:
    """
    Get the speaker notes from a specific slide in a PowerPoint presentation.

    Speaker notes are returned in markdown format, preserving basic formatting
    like bold, italic, and bullet points.
    """
    if not item_id or not item_id.strip():
        raise ToolExecutionError("item_id is required.")
    if slide_index < 1:
        raise ToolExecutionError("slide_index must be at least 1.")

    # Validate the item is a PowerPoint file
    drive_item = await _get_presentation_drive_item(context, item_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)

    # Download the presentation
    pptx_bytes = await _download_presentation_content(context, item_id)

    # Get the notes
    notes = _get_slide_notes_as_markdown(pptx_bytes, slide_index)

    return cast(
        GetSlideNotesResponse,
        {
            "item_id": item_id,
            "slide_index": slide_index,
            "notes": notes,
            "has_notes": bool(notes.strip()),
        },
    )


@tool(
    requires_auth=Microsoft(scopes=["Files.ReadWrite"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.PRESENTATIONS],
        ),
        behavior=Behavior(
            operations=[Operation.UPDATE],
            read_only=False,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def set_slide_notes(
    context: Context,
    item_id: Annotated[str, "The ID of the PowerPoint presentation."],
    slide_index: Annotated[int, "The 1-based index of the slide to set notes on."],
    notes: Annotated[
        str,
        "The speaker notes in markdown format. Supports **bold**, *italic*, "
        "__underline__, and bullet points (- or *).",
    ],
) -> Annotated[SetSlideNotesResponse, "Confirmation of the notes update."]:
    """
    Set or update the speaker notes on a specific slide in a PowerPoint presentation.

    Notes can be formatted using markdown:
    - **bold** for bold text
    - *italic* for italic text
    - __underline__ for underlined text
    - Lines starting with - or * become bullet points

    For presentations larger than 4 MB, the upload uses a resumable session.
    Concurrency protection (etag check) is best-effort in that case, since
    Microsoft Graph upload sessions do not support If-Match headers.
    - Indent with spaces for nested bullets
    """
    if not item_id or not item_id.strip():
        raise ToolExecutionError("item_id is required.")
    if slide_index < 1:
        raise ToolExecutionError("slide_index must be at least 1.")

    # Validate and get the item
    drive_item = await _get_presentation_drive_item(context, item_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)

    # Download the presentation
    pptx_bytes = await _download_presentation_content(context, item_id)

    # Set the notes
    updated_bytes = _set_slide_notes_from_markdown(pptx_bytes, slide_index, notes)

    # Upload (auto-selects simple vs resumable based on size)
    token = context.get_auth_token_or_empty()
    await _smart_upload_content(
        token=token,
        content=updated_bytes,
        content_type=PPTX_MIME_TYPE,
        item_id=item_id,
        etag=drive_item.e_tag,
    )

    return cast(
        SetSlideNotesResponse,
        {
            "item_id": item_id,
            "slide_index": slide_index,
            "message": f"Successfully updated speaker notes for slide {slide_index}.",
        },
    )


@tool(
    requires_auth=Microsoft(scopes=["Files.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.PRESENTATIONS],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def get_all_slide_notes(
    context: Context,
    item_id: Annotated[str, "The ID of the PowerPoint presentation."],
) -> Annotated[GetAllSlideNotesResponse, "All speaker notes from the presentation."]:
    """
    Get all speaker notes from every slide in a PowerPoint presentation.

    Returns notes for all slides in one call, which is more efficient than
    calling get_slide_notes for each slide individually. Notes are returned
    in markdown format.
    """
    if not item_id or not item_id.strip():
        raise ToolExecutionError("item_id is required.")

    # Validate the item is a PowerPoint file
    drive_item = await _get_presentation_drive_item(context, item_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)

    # Download the presentation
    pptx_bytes = await _download_presentation_content(context, item_id)

    # Get all notes
    slides_notes = _get_all_slide_notes_as_markdown(pptx_bytes)
    slides_with_notes = sum(1 for s in slides_notes if s["has_notes"])

    return cast(
        GetAllSlideNotesResponse,
        {
            "item_id": item_id,
            "slide_count": len(slides_notes),
            "slides_with_notes": slides_with_notes,
            "slides": slides_notes,
        },
    )
