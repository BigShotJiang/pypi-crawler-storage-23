"""Serializers for PowerPoint drive items."""

from typing import Any

from arcade_microsoft_utils.utils import human_friendly_bytes_size
from msgraph.generated.models.drive_item import DriveItem


def serialize_presentation_item(item: DriveItem, slide_count: int = 0) -> dict[str, Any]:
    """Serialize a DriveItem representing a PowerPoint presentation.

    Args:
        item: The DriveItem from Microsoft Graph API.
        slide_count: Number of slides in the presentation (if known).

    Returns:
        Serialized presentation data dictionary.
    """
    size_bytes = item.size if item.size else 0
    size_info = {
        "bytes": size_bytes,
        "formatted": human_friendly_bytes_size(size_bytes),
    }

    parent_folder_id = None
    if item.parent_reference and item.parent_reference.id:
        parent_folder_id = item.parent_reference.id

    data: dict[str, Any] = {
        "object_type": "presentation",
        "item_id": item.id,
        "name": item.name,
        "parent_folder_id": parent_folder_id,
        "size": size_info,
        "web_url": item.web_url,
        "etag": item.e_tag,
        "slide_count": slide_count,
        "created_datetime": item.created_date_time.isoformat() if item.created_date_time else None,
        "modified_datetime": item.last_modified_date_time.isoformat()
        if item.last_modified_date_time
        else None,
    }

    return {k: v for k, v in data.items() if v is not None}
