"""TypedDict models for PowerPoint tool responses."""

from typing_extensions import TypedDict

# Re-export WhoAmIResponse for consistency
from arcade_microsoft_powerpoint.who_am_i_util import WhoAmIResponse

__all__ = [
    "CreatePresentationResponse",
    "CreateSlideResponse",
    "GetAllSlideNotesResponse",
    "GetPresentationAsMarkdownResponse",
    "GetSlideNotesResponse",
    "PresentationItemData",
    "PresentationItemSize",
    "SetSlideNotesResponse",
    "SlideData",
    "SlideNotesData",
    "WhoAmIResponse",
]


class PresentationItemSize(TypedDict, total=False):
    """Size information for a presentation."""

    bytes: int
    formatted: str


class PresentationItemData(TypedDict, total=False):
    """Serialized PowerPoint presentation metadata."""

    object_type: str  # "presentation"
    item_id: str
    name: str
    parent_folder_id: str
    size: PresentationItemSize
    web_url: str
    etag: str  # For optimistic concurrency control (If-Match header)
    slide_count: int
    created_datetime: str
    modified_datetime: str


class SlideData(TypedDict, total=False):
    """Serialized slide data."""

    slide_index: int
    slide_id: str
    layout: str
    title: str
    left_body: str  # For TWO_CONTENT layout
    right_body: str  # For TWO_CONTENT layout


class GetPresentationAsMarkdownResponse(TypedDict):
    """Response from get_presentation_as_markdown tool."""

    item_id: str
    name: str
    web_url: str
    etag: str  # Include for subsequent modifications
    slide_count: int
    content: str  # Markdown content


class CreatePresentationResponse(TypedDict):
    """Response from create_presentation tool."""

    item: PresentationItemData
    message: str


class CreateSlideResponse(TypedDict):
    """Response from create_slide tool."""

    slide: SlideData
    item: PresentationItemData  # Includes updated etag
    message: str


class GetSlideNotesResponse(TypedDict):
    """Response from get_slide_notes tool."""

    item_id: str
    slide_index: int
    notes: str  # Speaker notes in markdown format
    has_notes: bool


class SetSlideNotesResponse(TypedDict):
    """Response from set_slide_notes tool."""

    item_id: str
    slide_index: int
    message: str


class SlideNotesData(TypedDict):
    """Speaker notes for a single slide."""

    slide_index: int
    has_notes: bool
    notes: str


class GetAllSlideNotesResponse(TypedDict):
    """Response from get_all_slide_notes tool."""

    item_id: str
    slide_count: int
    slides_with_notes: int
    slides: list[SlideNotesData]
