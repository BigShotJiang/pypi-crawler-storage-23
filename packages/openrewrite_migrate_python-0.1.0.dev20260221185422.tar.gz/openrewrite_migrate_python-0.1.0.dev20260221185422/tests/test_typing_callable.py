"""Tests for typing.Callable migration recipe."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.typing_callable import (
    ReplaceTypingCallableWithCollectionsAbcCallable,
)


class TestReplaceTypingCallableWithCollectionsAbcCallable:
    """Tests for the ReplaceTypingCallableWithCollectionsAbcCallable recipe."""

    @pytest.mark.requires_type_attribution
    def test_finds_callable_type_annotation(self):
        """Test that Callable[[int], str] type annotation is found and marked."""
        spec = RecipeSpec(recipe=ReplaceTypingCallableWithCollectionsAbcCallable())
        spec.rewrite_run(
            python(
                """
                from typing import Callable
                handler: Callable[[int], str] = lambda x: str(x)
                """,
                """
                from typing import Callable
                handler: /*~~(typing.Callable is deprecated: Replace with collections.abc.Callable (PEP 585))~~>*/Callable[[int], str] = lambda x: str(x)
                """,
            )
        )

    @pytest.mark.requires_type_attribution
    def test_finds_typing_callable_qualified(self):
        """Test that typing.Callable usage is found and marked."""
        spec = RecipeSpec(recipe=ReplaceTypingCallableWithCollectionsAbcCallable())
        spec.rewrite_run(
            python(
                """
                import typing
                handler: typing.Callable[[int], str] = lambda x: str(x)
                """,
                """
                import typing
                handler: typing./*~~(typing.Callable is deprecated: Replace with collections.abc.Callable (PEP 585))~~>*/Callable[[int], str] = lambda x: str(x)
                """,
            )
        )

    def test_no_change_when_collections_abc_callable(self):
        """Test that collections.abc.Callable is not marked."""
        spec = RecipeSpec(recipe=ReplaceTypingCallableWithCollectionsAbcCallable())
        spec.rewrite_run(
            python(
                """
                from collections.abc import Callable
                handler: Callable[[int], str] = lambda x: str(x)
                """
            )
        )
