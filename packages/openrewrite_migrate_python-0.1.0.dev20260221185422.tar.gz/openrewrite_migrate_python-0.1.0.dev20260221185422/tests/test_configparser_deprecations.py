"""Tests for configparser deprecation migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.configparser_deprecations import (
    ReplaceConfigparserSafeConfigParser,
    ReplaceConfigparserReadfp,
)


class TestReplaceConfigparserSafeConfigParser:
    """Tests for the ReplaceConfigparserSafeConfigParser recipe."""

    def test_replaces_safe_config_parser(self):
        """Test that configparser.SafeConfigParser is replaced with ConfigParser."""
        spec = RecipeSpec(recipe=ReplaceConfigparserSafeConfigParser())
        spec.rewrite_run(
            python(
                """
                import configparser
                config = configparser.SafeConfigParser()
                """,
                """
                import configparser
                config = configparser.ConfigParser()
                """,
            )
        )

    @pytest.mark.requires_dev_openrewrite
    def test_replaces_in_function_call(self):
        """Test replacement when used as a function argument."""
        spec = RecipeSpec(recipe=ReplaceConfigparserSafeConfigParser())
        spec.rewrite_run(
            python(
                """
                import configparser

                def process(parser):
                    pass

                process(configparser.SafeConfigParser())
                """,
                """
                import configparser

                def process(parser):
                    pass

                process(configparser.ConfigParser())
                """,
            )
        )

    def test_no_change_when_config_parser(self):
        """Test that configparser.ConfigParser is not modified."""
        spec = RecipeSpec(recipe=ReplaceConfigparserSafeConfigParser())
        spec.rewrite_run(
            python(
                """
                import configparser
                config = configparser.ConfigParser()
                """
            )
        )

    def test_no_change_when_different_module(self):
        """Test that SafeConfigParser on a different module is not modified."""
        spec = RecipeSpec(recipe=ReplaceConfigparserSafeConfigParser())
        spec.rewrite_run(
            python(
                """
                class mymodule:
                    SafeConfigParser = None

                config = mymodule.SafeConfigParser
                """
            )
        )


class TestReplaceConfigparserReadfp:
    """Tests for the ReplaceConfigparserReadfp recipe."""

    def test_replaces_readfp(self):
        """Test that readfp() is replaced with read_file()."""
        spec = RecipeSpec(recipe=ReplaceConfigparserReadfp())
        spec.rewrite_run(
            python(
                """
                import configparser
                config = configparser.ConfigParser()
                config.readfp(fp)
                """,
                """
                import configparser
                config = configparser.ConfigParser()
                config.read_file(fp)
                """,
            )
        )

    def test_replaces_readfp_with_parser_name(self):
        """Test that readfp() is replaced when variable is named parser."""
        spec = RecipeSpec(recipe=ReplaceConfigparserReadfp())
        spec.rewrite_run(
            python(
                """
                import configparser
                parser = configparser.ConfigParser()
                parser.readfp(file_obj)
                """,
                """
                import configparser
                parser = configparser.ConfigParser()
                parser.read_file(file_obj)
                """,
            )
        )

    def test_replaces_readfp_with_cfg_name(self):
        """Test that readfp() is replaced when variable is named cfg."""
        spec = RecipeSpec(recipe=ReplaceConfigparserReadfp())
        spec.rewrite_run(
            python(
                """
                import configparser
                cfg = configparser.ConfigParser()
                cfg.readfp(f)
                """,
                """
                import configparser
                cfg = configparser.ConfigParser()
                cfg.read_file(f)
                """,
            )
        )

    def test_no_change_when_read_file(self):
        """Test that read_file() is not modified."""
        spec = RecipeSpec(recipe=ReplaceConfigparserReadfp())
        spec.rewrite_run(
            python(
                """
                import configparser
                config = configparser.ConfigParser()
                config.read_file(fp)
                """
            )
        )

    def test_no_change_when_different_object(self):
        """Test that readfp on a different object type is not modified."""
        spec = RecipeSpec(recipe=ReplaceConfigparserReadfp())
        spec.rewrite_run(
            python(
                """
                class MyReader:
                    def readfp(self, fp):
                        pass

                reader = MyReader()
                reader.readfp(some_file)
                """
            )
        )
