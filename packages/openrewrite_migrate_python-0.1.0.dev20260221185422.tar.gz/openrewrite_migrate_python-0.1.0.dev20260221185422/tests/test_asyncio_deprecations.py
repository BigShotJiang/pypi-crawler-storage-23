"""Tests for asyncio deprecation migration recipes."""

import pytest
from rewrite.test import RecipeSpec, python
from openrewrite_migrate_python.migrate.asyncio_deprecations import (
    FindAsyncioCoroutineDecorator,
)


class TestFindAsyncioCoroutineDecorator:
    """Tests for the FindAsyncioCoroutineDecorator recipe."""

    @pytest.mark.requires_dev_openrewrite
    def test_finds_asyncio_coroutine_decorator(self):
        """Test that @asyncio.coroutine decorator is found and marked."""
        spec = RecipeSpec(recipe=FindAsyncioCoroutineDecorator())
        spec.rewrite_run(
            python(
                """
                import asyncio

                @asyncio.coroutine
                def my_func():
                    pass
                """,
                """
                import asyncio

                @/*~~(@asyncio.coroutine is deprecated: Use 'async def' instead (removed in Python 3.11))~~>*/asyncio.coroutine
                def my_func():
                    pass
                """,
            )
        )

    def test_no_change_when_async_def(self):
        """Test that async def functions are not marked."""
        spec = RecipeSpec(recipe=FindAsyncioCoroutineDecorator())
        spec.rewrite_run(
            python(
                """
                import asyncio

                async def my_func():
                    pass
                """
            )
        )

    def test_no_change_when_different_decorator(self):
        """Test that other decorators are not marked."""
        spec = RecipeSpec(recipe=FindAsyncioCoroutineDecorator())
        spec.rewrite_run(
            python(
                """
                def my_decorator(func):
                    return func

                @my_decorator
                def my_func():
                    pass
                """
            )
        )
