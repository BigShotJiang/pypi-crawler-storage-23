"""Tests for array deprecation migration recipes."""

import pytest

from rewrite.test import RecipeSpec, python

from openrewrite_migrate_python.migrate.array_deprecations import (
    ReplaceArrayFromstring,
    ReplaceArrayTostring,
)


class TestReplaceArrayTostring:
    """Tests for ReplaceArrayTostring recipe."""

    def test_replaces_tostring(self):
        spec = RecipeSpec(recipe=ReplaceArrayTostring())
        spec.rewrite_run(
            python(
                "data = my_array.tostring()",
                "data = my_array.tobytes()",
            )
        )

    def test_no_change_when_already_tobytes(self):
        spec = RecipeSpec(recipe=ReplaceArrayTostring())
        spec.rewrite_run(
            python("data = my_array.tobytes()")
        )


class TestReplaceArrayFromstring:
    """Tests for ReplaceArrayFromstring recipe."""

    def test_replaces_fromstring(self):
        spec = RecipeSpec(recipe=ReplaceArrayFromstring())
        spec.rewrite_run(
            python(
                "my_array.fromstring(data)",
                "my_array.frombytes(data)",
            )
        )

    def test_no_change_when_already_frombytes(self):
        spec = RecipeSpec(recipe=ReplaceArrayFromstring())
        spec.rewrite_run(
            python("my_array.frombytes(data)")
        )
