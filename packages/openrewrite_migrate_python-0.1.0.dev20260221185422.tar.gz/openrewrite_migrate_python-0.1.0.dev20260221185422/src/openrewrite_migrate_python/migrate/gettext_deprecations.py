"""
Recipes for migrating deprecated gettext module functions.

The l*gettext() functions were deprecated in Python 3.8 and removed in Python 3.11.
These functions returned encoded bytes instead of strings:

- lgettext() → gettext()
- lngettext() → ngettext()
- ldgettext() → dgettext()
- ldngettext() → dngettext()

See: https://docs.python.org/3/library/gettext.html
"""

from typing import Any, Optional, Dict

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.java.tree import Identifier, MethodInvocation

# Define category path: Python > Migrate > Python 3.11
_Python311 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.11"),
]

# Mapping of deprecated function names to their replacements
GETTEXT_DEPRECATIONS: Dict[str, str] = {
    "lgettext": "gettext",
    "lngettext": "ngettext",
    "ldgettext": "dgettext",
    "ldngettext": "dngettext",
}


def _rename_method(method: MethodInvocation, new_name: str) -> MethodInvocation:
    """Rename a method invocation."""
    old_name = method.name
    if not isinstance(old_name, Identifier):
        return method

    new_identifier = old_name.replace(_simple_name=new_name)
    return method.replace(_name=new_identifier)


def _is_gettext_method(method: MethodInvocation, method_name: str) -> bool:
    """
    Check if this is a gettext.method_name() call.

    Uses multiple strategies to identify the method:
    1. Check method name matches
    2. Check type attribution if available
    3. Check simple name on select is 'gettext'
    """
    if not isinstance(method.name, Identifier):
        return False
    if method.name.simple_name != method_name:
        return False

    # Check if type info confirms this is a gettext method
    if method.method_type and method.method_type.declaring_type:
        dt = method.method_type.declaring_type
        if hasattr(dt, '_fully_qualified_name'):
            fqn = str(dt._fully_qualified_name)
            if 'gettext' in fqn:
                return True

    # Fallback: Check simple name on select
    select = method.select
    if select is None:
        return False
    if isinstance(select, Identifier) and select.simple_name == "gettext":
        return True

    return False


@categorize(_Python311)
class ReplaceGettextDeprecations(Recipe):
    """
    Replace deprecated gettext l*gettext() functions with their modern equivalents.

    The l*gettext() functions were deprecated in Python 3.8 and removed in Python 3.11.
    These functions returned encoded bytes instead of Unicode strings:
    - lgettext() → gettext()
    - lngettext() → ngettext()
    - ldgettext() → dgettext()
    - ldngettext() → dngettext()

    Example:
        Before:
            import gettext
            msg = gettext.lgettext("Hello")

        After:
            import gettext
            msg = gettext.gettext("Hello")
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceGettextDeprecations"

    @property
    def display_name(self) -> str:
        return "Replace deprecated gettext l*gettext() functions"

    @property
    def description(self) -> str:
        return (
            "Replace deprecated gettext functions like `lgettext()` with their modern "
            "equivalents like `gettext()`. The l*gettext() functions were removed in Python 3.11."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)

                if not isinstance(method.name, Identifier):
                    return method

                method_name = method.name.simple_name

                # Check if this is a deprecated gettext function
                if method_name in GETTEXT_DEPRECATIONS:
                    if _is_gettext_method(method, method_name):
                        new_name = GETTEXT_DEPRECATIONS[method_name]
                        return _rename_method(method, new_name)

                return method

        return Visitor()
