"""
Recipes for migrating deprecated datetime.utcnow() and datetime.utcfromtimestamp() calls.

These methods are deprecated in Python 3.12+ because they return naive datetime objects
that don't carry timezone information. The recommended replacements are:

- datetime.utcnow() -> datetime.now(datetime.UTC)
- datetime.utcfromtimestamp(ts) -> datetime.fromtimestamp(ts, datetime.UTC)

See: https://docs.python.org/3/library/datetime.html#datetime.datetime.utcnow
"""

from typing import Any, Optional

from rewrite import ExecutionContext, Recipe, TreeVisitor
from rewrite.category import CategoryDescriptor
from rewrite.decorators import categorize
from rewrite.marketplace import Python
from rewrite.python.visitor import PythonVisitor
from rewrite.python.template import pattern, template, capture
from rewrite.java.tree import MethodInvocation

# Define category path: Python > Migrate > Python 3.12
_Python312 = [
    *Python,
    CategoryDescriptor(display_name="Migrate"),
    CategoryDescriptor(display_name="Python 3.12"),
]

# Pattern/template pairs for datetime.utcnow() -> datetime.now(datetime.UTC)
_utcnow_pattern = pattern("datetime.utcnow()")
_utcnow_template = template("datetime.now(datetime.UTC)")

# Pattern/template pairs for datetime.utcfromtimestamp(ts) -> datetime.fromtimestamp(ts, datetime.UTC)
_ts = capture('ts')
_utcfromtimestamp_pattern = pattern("datetime.utcfromtimestamp({ts})", ts=_ts)
_utcfromtimestamp_template = template("datetime.fromtimestamp({ts}, datetime.UTC)", ts=_ts)


@categorize(_Python312)
class ReplaceDatetimeUtcNow(Recipe):
    """
    Replace `datetime.utcnow()` with `datetime.now(datetime.UTC)`.

    The `datetime.utcnow()` method is deprecated in Python 3.12 because it returns
    a naive datetime object that doesn't carry timezone information. This can lead
    to subtle bugs when comparing or converting between timezones.

    This recipe transforms `datetime.utcnow()` to `datetime.now(datetime.UTC)` which
    returns a timezone-aware datetime object.

    Example:
        Before:
            from datetime import datetime
            now = datetime.utcnow()

        After:
            from datetime import datetime
            now = datetime.now(datetime.UTC)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceDatetimeUtcNow"

    @property
    def display_name(self) -> str:
        return "Replace `datetime.utcnow()` with `datetime.now(UTC)`"

    @property
    def description(self) -> str:
        return (
            "The `datetime.utcnow()` method is deprecated in Python 3.12. "
            "Replace it with `datetime.now(datetime.UTC)` for timezone-aware datetime objects."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _utcnow_pattern.match(method, self.cursor)
                if match:
                    return _utcnow_template.apply(self.cursor, values=match)
                return method

        return Visitor()


@categorize(_Python312)
class ReplaceDatetimeUtcFromTimestamp(Recipe):
    """
    Replace `datetime.utcfromtimestamp(ts)` with `datetime.fromtimestamp(ts, datetime.UTC)`.

    The `datetime.utcfromtimestamp()` method is deprecated in Python 3.12 because it
    returns a naive datetime object. This recipe transforms it to use the timezone-aware
    `datetime.fromtimestamp(ts, datetime.UTC)` form.

    Example:
        Before:
            from datetime import datetime
            dt = datetime.utcfromtimestamp(1234567890)

        After:
            from datetime import datetime
            dt = datetime.fromtimestamp(1234567890, datetime.UTC)
    """

    @property
    def name(self) -> str:
        return "org.openrewrite.python.migrate.ReplaceDatetimeUtcFromTimestamp"

    @property
    def display_name(self) -> str:
        return "Replace `datetime.utcfromtimestamp()` with `datetime.fromtimestamp(ts, UTC)`"

    @property
    def description(self) -> str:
        return (
            "The `datetime.utcfromtimestamp()` method is deprecated in Python 3.12. "
            "Replace it with `datetime.fromtimestamp(ts, datetime.UTC)` for timezone-aware datetime objects."
        )

    def editor(self) -> TreeVisitor[Any, ExecutionContext]:
        class Visitor(PythonVisitor[ExecutionContext]):
            def visit_method_invocation(
                self, method: MethodInvocation, p: ExecutionContext
            ) -> Optional[MethodInvocation]:
                method = super().visit_method_invocation(method, p)
                match = _utcfromtimestamp_pattern.match(method, self.cursor)
                if match:
                    return _utcfromtimestamp_template.apply(self.cursor, values=match)
                return method

        return Visitor()
