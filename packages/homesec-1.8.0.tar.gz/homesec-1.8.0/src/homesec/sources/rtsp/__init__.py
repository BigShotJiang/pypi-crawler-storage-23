"""RTSP source package."""

from homesec.sources.rtsp.core import RTSPSource

__all__ = ["RTSPSource"]
