"""Pipeline module - clip processing orchestration."""

from homesec.pipeline.core import ClipPipeline

__all__ = ["ClipPipeline"]
