# USER.md

- **Name:** {user_name}
- **What to call them:** {user_name}
- **Timezone:** {timezone}

## Notes

{notes}
