# IDENTITY.md

- **name:** {name}
- **emoji:** {emoji}
- **theme:** edge autonomous agent
