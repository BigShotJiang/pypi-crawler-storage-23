"""
Tests for memctl.sync — file scanning and delta synchronization.

Author: Olivier Vitrac, PhD, HDR | olivier.vitrac@adservio.fr | Adservio
"""

import os
import time
import pytest

from memctl.sync import (
    scan_mount, sync_mount, sync_all, derive_scope,
    FileInfo, ScanResult, SyncResult,
)
from memctl.mount import register_mount, list_mounts
from memctl.store import MemoryStore


@pytest.fixture
def db_path(tmp_path):
    return str(tmp_path / "test.db")


@pytest.fixture
def corpus(tmp_path):
    """Create a small corpus folder."""
    folder = tmp_path / "corpus"
    folder.mkdir()
    (folder / "arch.md").write_text("# Architecture\n\nLayered system design.\n\nModules interact via APIs.")
    (folder / "security.md").write_text("# Security\n\nAuthentication and authorization.\n\nOAuth2 flows.")
    (folder / "notes.txt").write_text("General notes about the project.\n\nTODO items here.")
    return str(folder)


@pytest.fixture
def corpus_with_subdirs(tmp_path):
    """Corpus with subdirectories."""
    root = tmp_path / "project"
    root.mkdir()
    (root / "README.md").write_text("# Project\n\nMain readme.")

    src = root / "src"
    src.mkdir()
    (src / "main.py").write_text("def main():\n    print('hello')\n")
    (src / "utils.py").write_text("def helper():\n    return 42\n")

    docs = root / "docs"
    docs.mkdir()
    (docs / "guide.md").write_text("# Guide\n\nUser guide content.\n\nStep by step.")
    (docs / "api.md").write_text("# API\n\nEndpoint documentation.\n\nGET /users")

    return str(root)


class TestScanMount:
    def test_scan_finds_files(self, corpus):
        result = scan_mount(corpus)
        assert isinstance(result, ScanResult)
        assert len(result.files) == 3
        assert result.total_size > 0

    def test_scan_collects_extensions(self, corpus):
        result = scan_mount(corpus)
        assert ".md" in result.extensions
        assert ".txt" in result.extensions
        assert result.extensions[".md"] == 2

    def test_scan_file_metadata(self, corpus):
        result = scan_mount(corpus)
        for fi in result.files:
            assert isinstance(fi, FileInfo)
            assert os.path.isabs(fi.abs_path)
            assert fi.sha256 is None  # deferred — computed lazily during sync
            assert fi.size_bytes > 0
            assert fi.mtime_epoch > 0
            assert fi.ext in (".md", ".txt")

    def test_scan_ignore_patterns(self, corpus):
        result = scan_mount(corpus, ignore_patterns=["*.txt"])
        assert len(result.files) == 2
        exts = {f.ext for f in result.files}
        assert ".txt" not in exts

    def test_scan_ignore_subdirectory(self, corpus_with_subdirs):
        result = scan_mount(corpus_with_subdirs, ignore_patterns=["src/*"])
        paths = {f.rel_path for f in result.files}
        assert not any("src/" in p for p in paths)

    def test_scan_relative_paths(self, corpus_with_subdirs):
        result = scan_mount(corpus_with_subdirs)
        rel_paths = {f.rel_path for f in result.files}
        assert "README.md" in rel_paths
        assert os.path.join("src", "main.py") in rel_paths
        assert os.path.join("docs", "guide.md") in rel_paths

    def test_scan_empty_directory(self, tmp_path):
        empty = tmp_path / "empty"
        empty.mkdir()
        result = scan_mount(str(empty))
        assert len(result.files) == 0
        assert result.total_size == 0

    def test_scan_skips_unknown_extensions(self, tmp_path):
        folder = tmp_path / "mixed"
        folder.mkdir()
        (folder / "data.bin").write_bytes(b"\x00\x01\x02")
        (folder / "note.md").write_text("# Note\n\nContent.")
        result = scan_mount(str(folder))
        assert len(result.files) == 1
        assert result.files[0].ext == ".md"


class TestSyncMount:
    def test_sync_creates_chunks(self, db_path, corpus):
        result = sync_mount(db_path, corpus, quiet=True)
        assert isinstance(result, SyncResult)
        assert result.files_scanned == 3
        assert result.files_new == 3
        assert result.chunks_created > 0

    def test_sync_auto_registers_mount(self, db_path, corpus):
        sync_mount(db_path, corpus, quiet=True)
        mounts = list_mounts(db_path)
        assert len(mounts) == 1
        assert mounts[0]["path"] == os.path.realpath(corpus)

    def test_sync_updates_last_sync_at(self, db_path, corpus):
        sync_mount(db_path, corpus, quiet=True)
        mounts = list_mounts(db_path)
        assert mounts[0]["last_sync_at"] is not None

    def test_sync_delta_skips_unchanged(self, db_path, corpus):
        r1 = sync_mount(db_path, corpus, quiet=True)
        assert r1.files_new == 3

        r2 = sync_mount(db_path, corpus, quiet=True)
        assert r2.files_unchanged == 3
        assert r2.files_new == 0
        assert r2.files_changed == 0
        assert r2.chunks_created == 0

    def test_sync_detects_changes(self, db_path, corpus):
        sync_mount(db_path, corpus, quiet=True)

        # Modify a file (need mtime to change)
        time.sleep(0.1)
        with open(os.path.join(corpus, "arch.md"), "w") as f:
            f.write("# Architecture v2\n\nCompletely rewritten.\n")

        r2 = sync_mount(db_path, corpus, quiet=True)
        assert r2.files_changed >= 1

    def test_sync_full_mode(self, db_path, corpus):
        sync_mount(db_path, corpus, quiet=True)

        r2 = sync_mount(db_path, corpus, delta=False, quiet=True)
        # Full mode: all files are re-processed (not "unchanged")
        assert r2.files_unchanged == 0

    def test_sync_with_existing_mount(self, db_path, corpus):
        register_mount(db_path, corpus, name="mycorpus")
        result = sync_mount(db_path, corpus, quiet=True)
        assert result.files_scanned == 3
        # Mount should still be there
        mounts = list_mounts(db_path)
        assert len(mounts) == 1

    def test_sync_corpus_hash_has_mount_metadata(self, db_path, corpus):
        sync_mount(db_path, corpus, quiet=True)
        store = MemoryStore(db_path=db_path)
        try:
            files = store.list_corpus_files()
            assert len(files) == 3
            for f in files:
                assert f["mount_id"] is not None
                assert f["mount_id"].startswith("MNT-")
                assert f["rel_path"] is not None
                assert f["ext"] in (".md", ".txt")
                assert f["size_bytes"] > 0
                assert f["mtime_epoch"] > 0
        finally:
            store.close()

    def test_sync_to_dict(self, db_path, corpus):
        result = sync_mount(db_path, corpus, quiet=True)
        d = result.to_dict()
        assert "mount_path" in d
        assert "files_scanned" in d
        assert "chunks_created" in d


class TestSyncAll:
    def test_sync_all_multiple_mounts(self, db_path, tmp_path):
        d1 = tmp_path / "a"
        d1.mkdir()
        (d1 / "file1.md").write_text("# A\n\nContent A.")
        d2 = tmp_path / "b"
        d2.mkdir()
        (d2 / "file2.md").write_text("# B\n\nContent B.")

        register_mount(db_path, str(d1), name="a")
        register_mount(db_path, str(d2), name="b")

        results = sync_all(db_path, quiet=True)
        assert len(results) == 2
        for path, r in results.items():
            assert r.files_scanned >= 1

    def test_sync_all_empty(self, db_path):
        results = sync_all(db_path, quiet=True)
        assert results == {}

    def test_sync_all_skips_missing_paths(self, db_path, tmp_path):
        d1 = tmp_path / "exists"
        d1.mkdir()
        (d1 / "file.md").write_text("# Test\n\nContent.")
        register_mount(db_path, str(d1), name="exists")

        # Manually insert a mount with a non-existent path
        store = MemoryStore(db_path=db_path)
        store.write_mount("/nonexistent/path/12345", name="ghost")
        store.close()

        results = sync_all(db_path, quiet=True)
        # Only the existing mount should be synced
        assert len(results) == 1


class TestSyncIdempotency:
    """Sync must be idempotent — multiple syncs of unchanged files produce zero work."""

    def test_triple_sync_no_new_work(self, db_path, corpus):
        r1 = sync_mount(db_path, corpus, quiet=True)
        assert r1.files_new == 3

        r2 = sync_mount(db_path, corpus, quiet=True)
        assert r2.files_new == 0
        assert r2.files_changed == 0
        assert r2.files_unchanged == 3
        assert r2.chunks_created == 0

        r3 = sync_mount(db_path, corpus, quiet=True)
        assert r3.files_new == 0
        assert r3.files_changed == 0
        assert r3.files_unchanged == 3
        assert r3.chunks_created == 0

    def test_touch_without_content_change(self, db_path, corpus):
        """Touch a file (update mtime) without changing content.
        Tier 3 should detect same sha256 and skip ingest."""
        sync_mount(db_path, corpus, quiet=True)

        # Touch a file — changes mtime but not content
        fpath = os.path.join(corpus, "arch.md")
        time.sleep(0.1)
        os.utime(fpath, None)  # update mtime to now

        r2 = sync_mount(db_path, corpus, quiet=True)
        # Size+mtime changed → hash check → same hash → unchanged
        assert r2.files_unchanged == 3
        assert r2.files_changed == 0
        assert r2.chunks_created == 0

    def test_content_change_detected(self, db_path, corpus):
        """Modify file content — must be detected as changed."""
        sync_mount(db_path, corpus, quiet=True)

        fpath = os.path.join(corpus, "arch.md")
        time.sleep(0.1)
        with open(fpath, "w") as f:
            f.write("# Architecture v2\n\nNew content.\n")

        r2 = sync_mount(db_path, corpus, quiet=True)
        assert r2.files_changed >= 1
        assert r2.chunks_created >= 1

    def test_new_file_detected(self, db_path, corpus):
        """Add a new file — must be detected as new."""
        sync_mount(db_path, corpus, quiet=True)

        new_file = os.path.join(corpus, "new.md")
        with open(new_file, "w") as f:
            f.write("# New File\n\nFresh content.\n")

        r2 = sync_mount(db_path, corpus, quiet=True)
        assert r2.files_new == 1
        assert r2.files_unchanged == 3

    def test_corpus_hashes_have_size_after_sync(self, db_path, corpus):
        """Every synced file must have size_bytes and ext in corpus_hashes."""
        sync_mount(db_path, corpus, quiet=True)
        store = MemoryStore(db_path=db_path)
        try:
            for f in store.list_corpus_files():
                assert f["size_bytes"] is not None and f["size_bytes"] > 0, \
                    f"Missing size_bytes for {f['file_path']}"
                assert f["ext"] is not None, \
                    f"Missing ext for {f['file_path']}"
        finally:
            store.close()


# ── P0: Auto-scope from mount path (v0.16.1) ────────────────────────

class TestDeriveScope:
    """P0: derive_scope() unit tests."""

    def test_explicit_scope_wins(self):
        """P0-T3a: explicit scope always overrides."""
        assert derive_scope("/tmp/GRDF", explicit_scope="custom") == "custom"

    def test_basename_derived(self):
        """P0-T2: scope derived from path basename."""
        assert derive_scope("/home/user/GRDF") == "GRDF"

    def test_relative_path(self):
        """derive_scope on relative path uses abspath basename."""
        result = derive_scope("some_folder")
        assert result == "some_folder"

    def test_none_explicit_uses_path(self):
        """None explicit_scope falls through to path."""
        assert derive_scope("/tmp/myproject", explicit_scope=None) == "myproject"


class TestSyncScope:
    """P0: sync_mount auto-scope integration tests."""

    def test_p0_t1_named_mount_scope(self, db_path, tmp_path):
        """P0-T1: sync with named mount -> items have scope = mount name."""
        folder = tmp_path / "myproject"
        folder.mkdir()
        (folder / "readme.md").write_text("# Hello\n\nContent here.")

        # Register mount with explicit name
        register_mount(db_path, str(folder), name="MyProject")

        sync_mount(db_path, str(folder), quiet=True)

        store = MemoryStore(db_path=db_path)
        try:
            items = store.list_items(scope="MyProject", limit=100)
            assert len(items) > 0, "Expected items with scope=MyProject"
            for item in items:
                assert item.scope == "MyProject"
        finally:
            store.close()

    def test_p0_t2_basename_scope(self, db_path, tmp_path):
        """P0-T2: sync with unnamed mount -> scope = path basename."""
        folder = tmp_path / "GRDF"
        folder.mkdir()
        (folder / "notes.txt").write_text("Some notes about the project.")

        sync_mount(db_path, str(folder), quiet=True)

        store = MemoryStore(db_path=db_path)
        try:
            items = store.list_items(scope="GRDF", limit=100)
            assert len(items) > 0, "Expected items with scope=GRDF"
            for item in items:
                assert item.scope == "GRDF"
        finally:
            store.close()

    def test_p0_t3_explicit_scope_override(self, db_path, tmp_path):
        """P0-T3: explicit --scope overrides auto-derivation."""
        folder = tmp_path / "somefolder"
        folder.mkdir()
        (folder / "doc.md").write_text("# Doc\n\nContent.")

        sync_mount(db_path, str(folder), quiet=True, scope="override_scope")

        store = MemoryStore(db_path=db_path)
        try:
            items = store.list_items(scope="override_scope", limit=100)
            assert len(items) > 0, "Expected items with scope=override_scope"
            for item in items:
                assert item.scope == "override_scope"
        finally:
            store.close()

    def test_p0_t4_legacy_items_findable(self, db_path, corpus):
        """P0-T4: legacy scope=project items remain findable."""
        sync_mount(db_path, corpus, quiet=True, scope="project")

        store = MemoryStore(db_path=db_path)
        try:
            items = store.list_items(scope="project", limit=100)
            assert len(items) > 0, "Legacy scope=project items must be findable"
        finally:
            store.close()

    def test_p0_t5_two_mounts_different_scopes(self, db_path, tmp_path):
        """Two mounts produce two different scopes -- no contamination."""
        proj_a = tmp_path / "ProjectA"
        proj_a.mkdir()
        (proj_a / "a.md").write_text("# Project A\n\nContent A.")

        proj_b = tmp_path / "ProjectB"
        proj_b.mkdir()
        (proj_b / "b.md").write_text("# Project B\n\nContent B.")

        sync_mount(db_path, str(proj_a), quiet=True)
        sync_mount(db_path, str(proj_b), quiet=True)

        store = MemoryStore(db_path=db_path)
        try:
            items_a = store.list_items(scope="ProjectA", limit=100)
            items_b = store.list_items(scope="ProjectB", limit=100)
            assert len(items_a) > 0
            assert len(items_b) > 0
            # No cross-contamination
            ids_a = {i.id for i in items_a}
            ids_b = {i.id for i in items_b}
            assert ids_a.isdisjoint(ids_b), "Scopes must be disjoint"
        finally:
            store.close()


# ── Sync policy inheritance (v0.21) ──────────────────────────────────

class TestSyncPolicy:
    """Tests that sync inherits ingest policy (v0.21)."""

    def test_sync_applies_policy_by_default(self, db_path, tmp_path):
        """sync_mount uses default policy (inherits from ingest_file)."""
        folder = tmp_path / "synctest"
        folder.mkdir()
        # Create a clean file
        (folder / "clean.md").write_text("# Clean\n\nArchitecture notes.\n")
        result = sync_mount(db_path, str(folder), quiet=True)
        assert result.files_new == 1
        assert result.chunks_created >= 1
        # Verify items are injectable (clean content)
        store = MemoryStore(db_path=db_path)
        try:
            items = store.list_items(limit=100)
            for item in items:
                if "Architecture" in item.content:
                    assert item.injectable is True
        finally:
            store.close()

    def test_sync_rejects_secret_files(self, db_path, tmp_path):
        """Synced file containing API key → rejected by policy."""
        folder = tmp_path / "synctest"
        folder.mkdir()
        (folder / "creds.txt").write_text(
            "api_key = sk-abcdefghij1234567890secret\n"
        )
        result = sync_mount(db_path, str(folder), quiet=True)
        # File was scanned but secret chunk rejected
        assert result.files_new == 1
        # Verify no secret in stored items
        store = MemoryStore(db_path=db_path)
        try:
            items = store.list_items(limit=100)
            for item in items:
                assert "sk-abcdefghij" not in item.content
        finally:
            store.close()
