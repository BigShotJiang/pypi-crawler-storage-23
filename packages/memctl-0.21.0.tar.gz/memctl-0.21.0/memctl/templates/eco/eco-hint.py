#!/usr/bin/env python3
"""eco-hint.py — UserPromptSubmit hook (cross-platform equivalent of eco-hint.sh).

Author: Olivier Vitrac, PhD, HDR | olivier.vitrac@adservio.fr | Adservio
"""
from memctl.hooks import hook_eco_hint

hook_eco_hint()
