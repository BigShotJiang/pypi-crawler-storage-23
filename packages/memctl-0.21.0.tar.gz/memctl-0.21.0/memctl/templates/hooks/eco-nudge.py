#!/usr/bin/env python3
"""eco-nudge.py — PreToolUse hook (cross-platform equivalent of eco-nudge.sh).

Author: Olivier Vitrac, PhD, HDR | olivier.vitrac@adservio.fr | Adservio
"""
from memctl.hooks import hook_eco_nudge

hook_eco_nudge()
