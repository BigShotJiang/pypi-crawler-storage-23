#!/usr/bin/env python3
"""memctl_safety_guard.py — PreToolUse hook (cross-platform equivalent of memctl_safety_guard.sh).

Author: Olivier Vitrac, PhD, HDR | olivier.vitrac@adservio.fr | Adservio
"""
from memctl.hooks import hook_safety_guard

hook_safety_guard()
