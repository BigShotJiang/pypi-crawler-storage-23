#!/usr/bin/env python3
"""memctl_audit_logger.py — PostToolUse hook (cross-platform equivalent of memctl_audit_logger.sh).

Author: Olivier Vitrac, PhD, HDR | olivier.vitrac@adservio.fr | Adservio
"""
from memctl.hooks import hook_audit_logger

hook_audit_logger()
