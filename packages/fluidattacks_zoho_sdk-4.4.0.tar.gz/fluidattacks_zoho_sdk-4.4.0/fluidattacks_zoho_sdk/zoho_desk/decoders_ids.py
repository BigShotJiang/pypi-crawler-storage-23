from fa_purity import (
    Maybe,
    ResultE,
)
from fa_purity.json import (
    JsonObj,
    JsonUnfolder,
)
from fluidattacks_etl_utils.decode import DecodeUtils
from fluidattacks_etl_utils.natural import Natural

from fluidattacks_zoho_sdk.zoho_desk.core import OptionalId

from .ids import (
    AccountId,
    ContactId,
    CrmId,
    DeparmentId,
    NumberId,
    ProductId,
    ProfileId,
    RoleId,
    TeamId,
    TicketId,
    UserId,
)


def decode_user_id(raw: JsonObj) -> ResultE[UserId]:
    return (
        JsonUnfolder.require(raw, "id", DecodeUtils.to_str)
        .bind(lambda v: Natural.from_int(int(v)))
        .map(UserId)
    )


def decode_rol_id(raw: JsonObj) -> ResultE[RoleId]:
    return (
        JsonUnfolder.require(raw, "roleId", DecodeUtils.to_str)
        .bind(lambda v: Natural.from_int(int(v)))
        .map(RoleId)
    )


def decode_profile_id(raw: JsonObj) -> ResultE[ProfileId]:
    return (
        JsonUnfolder.require(raw, "profileId", DecodeUtils.to_str)
        .bind(lambda v: Natural.from_int(int(v)))
        .map(ProfileId)
    )


def decode_account_id_bulk(raw: JsonObj) -> ResultE[AccountId]:
    return JsonUnfolder.require(raw, "Account ID", DecodeUtils.to_str).bind(
        lambda v: Natural.from_int(int(v)).map(AccountId),
    )


def decode_account_id(raw: JsonObj) -> ResultE[AccountId]:
    return (
        JsonUnfolder.require(raw, "Account ID", DecodeUtils.to_str)
        .bind(lambda v: Natural.from_int(int(v)))
        .map(AccountId)
    )


def decode_crm_id(raw: JsonObj) -> ResultE[CrmId]:
    return JsonUnfolder.require(raw, "CRM ID", DecodeUtils.to_str).bind(
        lambda v: Natural.from_int(int(v)).map(CrmId),
    )


def decode_department_id(raw: JsonObj) -> ResultE[DeparmentId]:
    return (
        JsonUnfolder.require(raw, "Department", DecodeUtils.to_str)
        .bind(lambda v: Natural.from_int(int(v)))
        .map(DeparmentId)
    )


def decode_department_id_team(raw: JsonObj) -> ResultE[DeparmentId]:
    return (
        JsonUnfolder.require(raw, "departmentId", DecodeUtils.to_str)
        .bind(lambda v: Natural.from_int(int(v)))
        .map(DeparmentId)
    )


def decode_require_product_id(raw: JsonObj) -> ResultE[ProductId]:
    return JsonUnfolder.require(raw, "Product ID", DecodeUtils.to_str).bind(
        lambda v: Natural.from_int(int(v)).map(lambda obj: ProductId(obj)),
    )


def decode_team_id(raw: JsonObj) -> ResultE[TeamId]:
    return JsonUnfolder.require(raw, "Team Id", DecodeUtils.to_str).bind(
        lambda v: Natural.from_int(int(v)).map(lambda obj: TeamId(obj)),
    )


def decode_ticket_id(raw: JsonObj) -> ResultE[TicketId]:
    return JsonUnfolder.require(raw, "ID", DecodeUtils.to_str).bind(
        lambda v: Natural.from_int(int(v)).map(lambda obj: TicketId(obj)),
    )


def decode_contact_id(raw: JsonObj) -> ResultE[ContactId]:
    return JsonUnfolder.require(raw, "Contact ID", DecodeUtils.to_str).bind(
        lambda v: Natural.from_int(int(v)).map(lambda obj: ContactId(obj)),
    )


def decode_contact_id_bulk(raw: JsonObj) -> ResultE[ContactId]:
    return JsonUnfolder.require(raw, "ID", DecodeUtils.to_str).bind(
        lambda v: Natural.from_int(int(v)).map(lambda obj: ContactId(obj)),
    )


def decode_id_team(raw: JsonObj) -> ResultE[TeamId]:
    return JsonUnfolder.require(raw, "id", DecodeUtils.to_str).bind(
        lambda v: Natural.from_int(int(v)).map(lambda obj: TeamId(obj)),
    )


def decode_user_id_bulk(raw: JsonObj) -> ResultE[UserId]:
    return JsonUnfolder.require(raw, "ID", DecodeUtils.to_str).bind(
        lambda v: Natural.from_int(int(v)).map(UserId),
    )


def decode_number_id(raw: JsonObj) -> ResultE[NumberId]:
    return JsonUnfolder.require(raw, "Request Id", DecodeUtils.to_str).bind(
        lambda v: Natural.from_int(int(v)).map(NumberId),
    )


def decode_optional_id(raw: JsonObj, key: str) -> ResultE[Maybe[OptionalId]]:
    return JsonUnfolder.optional(raw, key, DecodeUtils.to_opt_str).map(
        lambda v: v.bind(lambda x: x).map(lambda j: OptionalId(j)),
    )
