import inspect
import logging
from dataclasses import dataclass

from fa_purity import Cmd, FrozenList, Maybe, ResultE, cast_exception
from fa_purity.json import Primitive, UnfoldedFactory
from fluidattacks_etl_utils.bug import Bug

from fluidattacks_zoho_sdk._decoders import assert_single
from fluidattacks_zoho_sdk._http_client import (
    ClientFactory,
    HttpJsonClient,
    RelativeEndpoint,
    TokenManager,
)
from fluidattacks_zoho_sdk.auth import Credentials

from ._decode import decode_holidays
from .core import Holiday, HolidayClient

LOG = logging.getLogger(__name__)


def get_holidays_of_year(
    client: HttpJsonClient,
    from_filter: str,
    to_filter: str,
) -> Cmd[ResultE[FrozenList[Holiday]]]:
    endpoint = RelativeEndpoint.new("people.zoho.com/people", "leave/v2", "holidays", "get")
    params: dict[str, Primitive] = {
        "from": from_filter,
        "to": to_filter,
        "location": "Remote",
        "upcoming": "false",
        "dateFormat": "dd-MMM-yyyy",
    }

    return client.get(
        endpoint,
        UnfoldedFactory.from_dict(params),
    ).map(
        lambda result: (
            result.alt(
                lambda e: cast_exception(
                    Bug.new("get_holidays_of_year", inspect.currentframe(), e, ()),
                ),
            )
            .bind(assert_single)
            .bind(decode_holidays)
        ),
    )


def _from_client(client: HttpJsonClient) -> HolidayClient:
    return HolidayClient(lambda f, t: get_holidays_of_year(client, f, t))


@dataclass(frozen=True)
class HolidaysClientFactory:
    @staticmethod
    def new(creds: Credentials, token: TokenManager) -> HolidayClient:
        return _from_client(ClientFactory.new(creds, Maybe.empty(), token))
