from fa_purity import (
    FrozenList,
    PureIterFactory,
    Result,
    ResultE,
    ResultTransform,
    Unsafe,
)
from fa_purity.json import JsonObj, JsonUnfolder, Unfolder
from fluidattacks_etl_utils import smash
from fluidattacks_etl_utils.decode import DecodeUtils, str_to_int
from fluidattacks_etl_utils.natural import NaturalOperations

from fluidattacks_zoho_sdk._decoders import parse_date

from .core import Holiday, IdHoliday


def decode_id_holiday(raw: JsonObj) -> ResultE[IdHoliday]:
    return JsonUnfolder.require(raw, "Id", DecodeUtils.to_str).bind(
        lambda v: str_to_int(v).map(
            lambda i: IdHoliday(NaturalOperations.absolute(i)),
        ),
    )


def decode_holiday(raw: JsonObj) -> ResultE[Holiday]:
    first = smash.smash_result_4(
        JsonUnfolder.require(raw, "classification", DecodeUtils.to_str),
        JsonUnfolder.require(raw, "classificationType", DecodeUtils.to_int),
        JsonUnfolder.require(raw, "Date", DecodeUtils.to_str).bind(parse_date),
        JsonUnfolder.require(raw, "Name", DecodeUtils.to_str),
    )

    second = smash.smash_result_4(
        JsonUnfolder.require(raw, "LocationName", DecodeUtils.to_str),
        JsonUnfolder.require(raw, "isRestrictedHoliday", DecodeUtils.to_bool),
        decode_id_holiday(raw),
        JsonUnfolder.require(raw, "isHalfday", DecodeUtils.to_bool),
    )

    return smash.smash_result_2(first, second).map(
        lambda v: Holiday(*v[0], *v[1]),
    )


def decode_holidays(raw: JsonObj) -> ResultE[FrozenList[Holiday]]:
    items = (
        JsonUnfolder.require(raw, "data", lambda v: Unfolder.to_list(v))
        .alt(Unsafe.raise_exception)
        .to_union()
    )
    if not items:
        return Result.success(FrozenList[Holiday]([]))

    return ResultTransform.all_ok(
        PureIterFactory.from_list(tuple(items))
        .map(lambda v: Unfolder.to_json(v).bind(decode_holiday))
        .to_list(),
    )
