from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import date

from fa_purity import Cmd, FrozenList, ResultE
from fluidattacks_etl_utils.natural import Natural


@dataclass(frozen=True)
class IdHoliday:
    id_holiday: Natural


@dataclass(frozen=True)
class Holiday:
    classification: str
    classification_type: int
    date_holiday: date
    name: str
    location_name: str
    is_restricted_holiday: bool
    id_holiday: IdHoliday
    is_half_day: bool


@dataclass(frozen=True)
class HolidayClient:
    get_holidays_of_year: Callable[
        [str, str],
        Cmd[ResultE[FrozenList[Holiday]]],
    ]
