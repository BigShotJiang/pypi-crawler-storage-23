from dataclasses import dataclass

from fluidattacks_etl_utils.natural import Natural


@dataclass(frozen=True)
class OrgId:
    org_id: Natural
