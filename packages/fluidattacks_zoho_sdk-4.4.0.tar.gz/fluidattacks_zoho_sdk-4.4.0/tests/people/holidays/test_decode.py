from pathlib import Path

from fa_purity import Unsafe
from fa_purity.json import JsonObj, JsonValueFactory, Unfolder
from fluidattacks_etl_utils.natural import NaturalOperations

from fluidattacks_zoho_sdk._decoders import parse_date
from fluidattacks_zoho_sdk.zoho_people.holidays._decode import decode_holidays
from fluidattacks_zoho_sdk.zoho_people.holidays.core import Holiday, IdHoliday


def read_json(name_file: str) -> JsonObj:
    raw_data = Path(__file__).parent / name_file
    return (
        JsonValueFactory.load(raw_data.open(encoding="utf-8"))
        .bind(Unfolder.to_json)
        .alt(Unsafe.raise_exception)
        .to_union()
    )


def test_decode() -> None:
    holidays_expected = (
        Holiday(
            classification="Holiday",
            classification_type=0,
            date_holiday=parse_date("01-Jan-2024").alt(Unsafe.raise_exception).to_union(),
            name="New year",
            location_name="Remote AR,Remote BO,Remote,Remote ES,Remote EC,Remote MX",
            is_restricted_holiday=False,
            id_holiday=IdHoliday(NaturalOperations.absolute(794097000000262453)),
            is_half_day=False,
        ),
        Holiday(
            classification="Holiday",
            classification_type=0,
            date_holiday=parse_date("25-Mar-2024").alt(Unsafe.raise_exception).to_union(),
            name="St. Joseph's Day",
            location_name="Remote",
            is_restricted_holiday=False,
            id_holiday=IdHoliday(NaturalOperations.absolute(794097000000262470)),
            is_half_day=False,
        ),
    )

    path_file = "data_holidays.json"
    decode_data = decode_holidays(read_json(path_file)).alt(Unsafe.raise_exception).to_union()
    assert holidays_expected == decode_data
