"""aws-bootstrap-g4dn: Bootstrap AWS EC2 GPU instances for hybrid development."""
