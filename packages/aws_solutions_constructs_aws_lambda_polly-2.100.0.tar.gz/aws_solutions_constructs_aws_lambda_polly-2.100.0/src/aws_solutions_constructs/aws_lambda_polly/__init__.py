r'''
Documentation for this pattern can be found [here](https://github.com/awslabs/aws-solutions-constructs/blob/main/source/patterns/%40aws-solutions-constructs/aws-lambda-polly/README.adoc)
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ._jsii import *

import aws_cdk.aws_ec2 as _aws_cdk_aws_ec2_ceddda9d
import aws_cdk.aws_kms as _aws_cdk_aws_kms_ceddda9d
import aws_cdk.aws_lambda as _aws_cdk_aws_lambda_ceddda9d
import aws_cdk.aws_s3 as _aws_cdk_aws_s3_ceddda9d
import aws_cdk.aws_sns as _aws_cdk_aws_sns_ceddda9d
import constructs as _constructs_77d1e7e8


class LambdaToPolly(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-solutions-constructs/aws-lambda-polly.LambdaToPolly",
):
    '''
    :summary: The LambdaToPolly class.
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        async_jobs: typing.Optional[builtins.bool] = None,
        bucket_environment_variable_name: typing.Optional[builtins.str] = None,
        bucket_props: typing.Optional[typing.Union["_aws_cdk_aws_s3_ceddda9d.BucketProps", typing.Dict[builtins.str, typing.Any]]] = None,
        deploy_vpc: typing.Optional[builtins.bool] = None,
        enable_topic_encryption_with_customer_managed_key: typing.Optional[builtins.bool] = None,
        existing_bucket_obj: typing.Optional["_aws_cdk_aws_s3_ceddda9d.IBucket"] = None,
        existing_lambda_obj: typing.Optional["_aws_cdk_aws_lambda_ceddda9d.Function"] = None,
        existing_topic_encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.Key"] = None,
        existing_topic_obj: typing.Optional["_aws_cdk_aws_sns_ceddda9d.Topic"] = None,
        existing_vpc: typing.Optional["_aws_cdk_aws_ec2_ceddda9d.IVpc"] = None,
        lambda_function_props: typing.Optional[typing.Union["_aws_cdk_aws_lambda_ceddda9d.FunctionProps", typing.Dict[builtins.str, typing.Any]]] = None,
        logging_bucket_props: typing.Optional[typing.Union["_aws_cdk_aws_s3_ceddda9d.BucketProps", typing.Dict[builtins.str, typing.Any]]] = None,
        log_s3_access_logs: typing.Optional[builtins.bool] = None,
        topic_encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.Key"] = None,
        topic_encryption_key_props: typing.Any = None,
        topic_environment_variable_name: typing.Optional[builtins.str] = None,
        topic_props: typing.Any = None,
        vpc_props: typing.Any = None,
    ) -> None:
        '''
        :param scope: - represents the scope for all the resources.
        :param id: - this is a a scope-unique id.
        :param async_jobs: Whether to enable asynchronous speech synthesis tasks. When true, an S3 bucket for audio output and an SNS topic for completion notifications will be created, and the Lambda function will be granted permissions to start and monitor asynchronous synthesis tasks. Default: - false
        :param bucket_environment_variable_name: Optional Name for the Lambda function environment variable set to the name of the output bucket. Only valid when asyncJobs is true. Default: - OUTPUT_BUCKET_NAME
        :param bucket_props: Optional user provided props to override the default props for the S3 Bucket. Only valid when asyncJobs is true. Default: - Default props are used
        :param deploy_vpc: Whether to deploy a new VPC. Default: - false
        :param enable_topic_encryption_with_customer_managed_key: If no key is provided, this flag determines whether the SNS Topic is encrypted with a new CMK or an AWS managed key. This flag is ignored if any of the following are defined: topicProps.masterKey, topicEncryptionKey or topicEncryptionKeyProps. Only valid when asyncJobs is true. Default: - None
        :param existing_bucket_obj: Existing instance of S3 Bucket object for audio output, providing both this and ``bucketProps`` will cause an error. Only valid when asyncJobs is true. Default: - None
        :param existing_lambda_obj: Optional - instance of an existing Lambda Function object, providing both this and ``lambdaFunctionProps`` will cause an error. Default: - None
        :param existing_topic_encryption_key: If an existing topic is provided in the ``existingTopicObj`` property, and that topic is encrypted with a customer managed KMS key, this property must specify that key. Only valid when asyncJobs is true. Default: - None
        :param existing_topic_obj: Optional - existing instance of SNS topic object, providing both this and ``topicProps`` will cause an error. Only valid when asyncJobs is true. Default: - None
        :param existing_vpc: An existing VPC for the construct to use (construct will NOT create a new VPC in this case).
        :param lambda_function_props: Optional - user provided props to override the default props for the Lambda function. Providing both this and ``existingLambdaObj`` causes an error. Function will have these Polly permissions: ['polly:SynthesizeSpeech']. When asyncJobs is true, function will also have ['polly:StartSpeechSynthesisTask', 'polly:GetSpeechSynthesisTask', 'polly:ListSpeechSynthesisTasks']. Default: - Default properties are used.
        :param logging_bucket_props: Optional user provided props to override the default props for the S3 Logging Bucket. Only valid when asyncJobs is true. Default: - Default props are used
        :param log_s3_access_logs: Whether to turn on Access Logs for the S3 bucket with the associated storage costs. Enabling Access Logging is a best practice. Only valid when asyncJobs is true. Default: - true
        :param topic_encryption_key: An optional, imported encryption key to encrypt the SNS Topic with. Only valid when asyncJobs is true. Default: - not specified.
        :param topic_encryption_key_props: Optional user provided properties to override the default properties for the KMS encryption key used to encrypt the SNS Topic with. Only valid when asyncJobs is true. Default: - None
        :param topic_environment_variable_name: Optional Name for the Lambda function environment variable set to the ARN of the SNS topic used for asynchronous task completion notifications. Only valid when asyncJobs is true. Default: - SNS_TOPIC_ARN
        :param topic_props: Optional - user provided properties to override the default properties for the SNS topic. Providing both this and ``existingTopicObj`` causes an error. Only valid when asyncJobs is true. Default: - Default properties are used.
        :param vpc_props: Properties to override default properties if deployVpc is true.

        :access: public
        :summary: Constructs a new instance of the LambdaToPolly class.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c1ec1a737f0dedaa7072e604dcb4e90ef03aa69f88372962f6ef9381337678b6)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = LambdaToPollyProps(
            async_jobs=async_jobs,
            bucket_environment_variable_name=bucket_environment_variable_name,
            bucket_props=bucket_props,
            deploy_vpc=deploy_vpc,
            enable_topic_encryption_with_customer_managed_key=enable_topic_encryption_with_customer_managed_key,
            existing_bucket_obj=existing_bucket_obj,
            existing_lambda_obj=existing_lambda_obj,
            existing_topic_encryption_key=existing_topic_encryption_key,
            existing_topic_obj=existing_topic_obj,
            existing_vpc=existing_vpc,
            lambda_function_props=lambda_function_props,
            logging_bucket_props=logging_bucket_props,
            log_s3_access_logs=log_s3_access_logs,
            topic_encryption_key=topic_encryption_key,
            topic_encryption_key_props=topic_encryption_key_props,
            topic_environment_variable_name=topic_environment_variable_name,
            topic_props=topic_props,
            vpc_props=vpc_props,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @builtins.property
    @jsii.member(jsii_name="lambdaFunction")
    def lambda_function(self) -> "_aws_cdk_aws_lambda_ceddda9d.Function":
        return typing.cast("_aws_cdk_aws_lambda_ceddda9d.Function", jsii.get(self, "lambdaFunction"))

    @builtins.property
    @jsii.member(jsii_name="destinationBucket")
    def destination_bucket(self) -> typing.Optional["_aws_cdk_aws_s3_ceddda9d.Bucket"]:
        return typing.cast(typing.Optional["_aws_cdk_aws_s3_ceddda9d.Bucket"], jsii.get(self, "destinationBucket"))

    @builtins.property
    @jsii.member(jsii_name="destinationBucketInterface")
    def destination_bucket_interface(
        self,
    ) -> typing.Optional["_aws_cdk_aws_s3_ceddda9d.IBucket"]:
        return typing.cast(typing.Optional["_aws_cdk_aws_s3_ceddda9d.IBucket"], jsii.get(self, "destinationBucketInterface"))

    @builtins.property
    @jsii.member(jsii_name="loggingBucket")
    def logging_bucket(self) -> typing.Optional["_aws_cdk_aws_s3_ceddda9d.Bucket"]:
        return typing.cast(typing.Optional["_aws_cdk_aws_s3_ceddda9d.Bucket"], jsii.get(self, "loggingBucket"))

    @builtins.property
    @jsii.member(jsii_name="notificationTopicEncryptionKey")
    def notification_topic_encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"]:
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.IKey"], jsii.get(self, "notificationTopicEncryptionKey"))

    @builtins.property
    @jsii.member(jsii_name="snsNotificationTopic")
    def sns_notification_topic(
        self,
    ) -> typing.Optional["_aws_cdk_aws_sns_ceddda9d.Topic"]:
        return typing.cast(typing.Optional["_aws_cdk_aws_sns_ceddda9d.Topic"], jsii.get(self, "snsNotificationTopic"))

    @builtins.property
    @jsii.member(jsii_name="vpc")
    def vpc(self) -> typing.Optional["_aws_cdk_aws_ec2_ceddda9d.IVpc"]:
        return typing.cast(typing.Optional["_aws_cdk_aws_ec2_ceddda9d.IVpc"], jsii.get(self, "vpc"))


@jsii.data_type(
    jsii_type="@aws-solutions-constructs/aws-lambda-polly.LambdaToPollyProps",
    jsii_struct_bases=[],
    name_mapping={
        "async_jobs": "asyncJobs",
        "bucket_environment_variable_name": "bucketEnvironmentVariableName",
        "bucket_props": "bucketProps",
        "deploy_vpc": "deployVpc",
        "enable_topic_encryption_with_customer_managed_key": "enableTopicEncryptionWithCustomerManagedKey",
        "existing_bucket_obj": "existingBucketObj",
        "existing_lambda_obj": "existingLambdaObj",
        "existing_topic_encryption_key": "existingTopicEncryptionKey",
        "existing_topic_obj": "existingTopicObj",
        "existing_vpc": "existingVpc",
        "lambda_function_props": "lambdaFunctionProps",
        "logging_bucket_props": "loggingBucketProps",
        "log_s3_access_logs": "logS3AccessLogs",
        "topic_encryption_key": "topicEncryptionKey",
        "topic_encryption_key_props": "topicEncryptionKeyProps",
        "topic_environment_variable_name": "topicEnvironmentVariableName",
        "topic_props": "topicProps",
        "vpc_props": "vpcProps",
    },
)
class LambdaToPollyProps:
    def __init__(
        self,
        *,
        async_jobs: typing.Optional[builtins.bool] = None,
        bucket_environment_variable_name: typing.Optional[builtins.str] = None,
        bucket_props: typing.Optional[typing.Union["_aws_cdk_aws_s3_ceddda9d.BucketProps", typing.Dict[builtins.str, typing.Any]]] = None,
        deploy_vpc: typing.Optional[builtins.bool] = None,
        enable_topic_encryption_with_customer_managed_key: typing.Optional[builtins.bool] = None,
        existing_bucket_obj: typing.Optional["_aws_cdk_aws_s3_ceddda9d.IBucket"] = None,
        existing_lambda_obj: typing.Optional["_aws_cdk_aws_lambda_ceddda9d.Function"] = None,
        existing_topic_encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.Key"] = None,
        existing_topic_obj: typing.Optional["_aws_cdk_aws_sns_ceddda9d.Topic"] = None,
        existing_vpc: typing.Optional["_aws_cdk_aws_ec2_ceddda9d.IVpc"] = None,
        lambda_function_props: typing.Optional[typing.Union["_aws_cdk_aws_lambda_ceddda9d.FunctionProps", typing.Dict[builtins.str, typing.Any]]] = None,
        logging_bucket_props: typing.Optional[typing.Union["_aws_cdk_aws_s3_ceddda9d.BucketProps", typing.Dict[builtins.str, typing.Any]]] = None,
        log_s3_access_logs: typing.Optional[builtins.bool] = None,
        topic_encryption_key: typing.Optional["_aws_cdk_aws_kms_ceddda9d.Key"] = None,
        topic_encryption_key_props: typing.Any = None,
        topic_environment_variable_name: typing.Optional[builtins.str] = None,
        topic_props: typing.Any = None,
        vpc_props: typing.Any = None,
    ) -> None:
        '''
        :param async_jobs: Whether to enable asynchronous speech synthesis tasks. When true, an S3 bucket for audio output and an SNS topic for completion notifications will be created, and the Lambda function will be granted permissions to start and monitor asynchronous synthesis tasks. Default: - false
        :param bucket_environment_variable_name: Optional Name for the Lambda function environment variable set to the name of the output bucket. Only valid when asyncJobs is true. Default: - OUTPUT_BUCKET_NAME
        :param bucket_props: Optional user provided props to override the default props for the S3 Bucket. Only valid when asyncJobs is true. Default: - Default props are used
        :param deploy_vpc: Whether to deploy a new VPC. Default: - false
        :param enable_topic_encryption_with_customer_managed_key: If no key is provided, this flag determines whether the SNS Topic is encrypted with a new CMK or an AWS managed key. This flag is ignored if any of the following are defined: topicProps.masterKey, topicEncryptionKey or topicEncryptionKeyProps. Only valid when asyncJobs is true. Default: - None
        :param existing_bucket_obj: Existing instance of S3 Bucket object for audio output, providing both this and ``bucketProps`` will cause an error. Only valid when asyncJobs is true. Default: - None
        :param existing_lambda_obj: Optional - instance of an existing Lambda Function object, providing both this and ``lambdaFunctionProps`` will cause an error. Default: - None
        :param existing_topic_encryption_key: If an existing topic is provided in the ``existingTopicObj`` property, and that topic is encrypted with a customer managed KMS key, this property must specify that key. Only valid when asyncJobs is true. Default: - None
        :param existing_topic_obj: Optional - existing instance of SNS topic object, providing both this and ``topicProps`` will cause an error. Only valid when asyncJobs is true. Default: - None
        :param existing_vpc: An existing VPC for the construct to use (construct will NOT create a new VPC in this case).
        :param lambda_function_props: Optional - user provided props to override the default props for the Lambda function. Providing both this and ``existingLambdaObj`` causes an error. Function will have these Polly permissions: ['polly:SynthesizeSpeech']. When asyncJobs is true, function will also have ['polly:StartSpeechSynthesisTask', 'polly:GetSpeechSynthesisTask', 'polly:ListSpeechSynthesisTasks']. Default: - Default properties are used.
        :param logging_bucket_props: Optional user provided props to override the default props for the S3 Logging Bucket. Only valid when asyncJobs is true. Default: - Default props are used
        :param log_s3_access_logs: Whether to turn on Access Logs for the S3 bucket with the associated storage costs. Enabling Access Logging is a best practice. Only valid when asyncJobs is true. Default: - true
        :param topic_encryption_key: An optional, imported encryption key to encrypt the SNS Topic with. Only valid when asyncJobs is true. Default: - not specified.
        :param topic_encryption_key_props: Optional user provided properties to override the default properties for the KMS encryption key used to encrypt the SNS Topic with. Only valid when asyncJobs is true. Default: - None
        :param topic_environment_variable_name: Optional Name for the Lambda function environment variable set to the ARN of the SNS topic used for asynchronous task completion notifications. Only valid when asyncJobs is true. Default: - SNS_TOPIC_ARN
        :param topic_props: Optional - user provided properties to override the default properties for the SNS topic. Providing both this and ``existingTopicObj`` causes an error. Only valid when asyncJobs is true. Default: - Default properties are used.
        :param vpc_props: Properties to override default properties if deployVpc is true.

        :summary: The properties for the LambdaToPolly class.
        '''
        if isinstance(bucket_props, dict):
            bucket_props = _aws_cdk_aws_s3_ceddda9d.BucketProps(**bucket_props)
        if isinstance(lambda_function_props, dict):
            lambda_function_props = _aws_cdk_aws_lambda_ceddda9d.FunctionProps(**lambda_function_props)
        if isinstance(logging_bucket_props, dict):
            logging_bucket_props = _aws_cdk_aws_s3_ceddda9d.BucketProps(**logging_bucket_props)
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4f8259ca306e2c6e0e6b5945ad532e43d7d480870f61864499b83261e1034a76)
            check_type(argname="argument async_jobs", value=async_jobs, expected_type=type_hints["async_jobs"])
            check_type(argname="argument bucket_environment_variable_name", value=bucket_environment_variable_name, expected_type=type_hints["bucket_environment_variable_name"])
            check_type(argname="argument bucket_props", value=bucket_props, expected_type=type_hints["bucket_props"])
            check_type(argname="argument deploy_vpc", value=deploy_vpc, expected_type=type_hints["deploy_vpc"])
            check_type(argname="argument enable_topic_encryption_with_customer_managed_key", value=enable_topic_encryption_with_customer_managed_key, expected_type=type_hints["enable_topic_encryption_with_customer_managed_key"])
            check_type(argname="argument existing_bucket_obj", value=existing_bucket_obj, expected_type=type_hints["existing_bucket_obj"])
            check_type(argname="argument existing_lambda_obj", value=existing_lambda_obj, expected_type=type_hints["existing_lambda_obj"])
            check_type(argname="argument existing_topic_encryption_key", value=existing_topic_encryption_key, expected_type=type_hints["existing_topic_encryption_key"])
            check_type(argname="argument existing_topic_obj", value=existing_topic_obj, expected_type=type_hints["existing_topic_obj"])
            check_type(argname="argument existing_vpc", value=existing_vpc, expected_type=type_hints["existing_vpc"])
            check_type(argname="argument lambda_function_props", value=lambda_function_props, expected_type=type_hints["lambda_function_props"])
            check_type(argname="argument logging_bucket_props", value=logging_bucket_props, expected_type=type_hints["logging_bucket_props"])
            check_type(argname="argument log_s3_access_logs", value=log_s3_access_logs, expected_type=type_hints["log_s3_access_logs"])
            check_type(argname="argument topic_encryption_key", value=topic_encryption_key, expected_type=type_hints["topic_encryption_key"])
            check_type(argname="argument topic_encryption_key_props", value=topic_encryption_key_props, expected_type=type_hints["topic_encryption_key_props"])
            check_type(argname="argument topic_environment_variable_name", value=topic_environment_variable_name, expected_type=type_hints["topic_environment_variable_name"])
            check_type(argname="argument topic_props", value=topic_props, expected_type=type_hints["topic_props"])
            check_type(argname="argument vpc_props", value=vpc_props, expected_type=type_hints["vpc_props"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if async_jobs is not None:
            self._values["async_jobs"] = async_jobs
        if bucket_environment_variable_name is not None:
            self._values["bucket_environment_variable_name"] = bucket_environment_variable_name
        if bucket_props is not None:
            self._values["bucket_props"] = bucket_props
        if deploy_vpc is not None:
            self._values["deploy_vpc"] = deploy_vpc
        if enable_topic_encryption_with_customer_managed_key is not None:
            self._values["enable_topic_encryption_with_customer_managed_key"] = enable_topic_encryption_with_customer_managed_key
        if existing_bucket_obj is not None:
            self._values["existing_bucket_obj"] = existing_bucket_obj
        if existing_lambda_obj is not None:
            self._values["existing_lambda_obj"] = existing_lambda_obj
        if existing_topic_encryption_key is not None:
            self._values["existing_topic_encryption_key"] = existing_topic_encryption_key
        if existing_topic_obj is not None:
            self._values["existing_topic_obj"] = existing_topic_obj
        if existing_vpc is not None:
            self._values["existing_vpc"] = existing_vpc
        if lambda_function_props is not None:
            self._values["lambda_function_props"] = lambda_function_props
        if logging_bucket_props is not None:
            self._values["logging_bucket_props"] = logging_bucket_props
        if log_s3_access_logs is not None:
            self._values["log_s3_access_logs"] = log_s3_access_logs
        if topic_encryption_key is not None:
            self._values["topic_encryption_key"] = topic_encryption_key
        if topic_encryption_key_props is not None:
            self._values["topic_encryption_key_props"] = topic_encryption_key_props
        if topic_environment_variable_name is not None:
            self._values["topic_environment_variable_name"] = topic_environment_variable_name
        if topic_props is not None:
            self._values["topic_props"] = topic_props
        if vpc_props is not None:
            self._values["vpc_props"] = vpc_props

    @builtins.property
    def async_jobs(self) -> typing.Optional[builtins.bool]:
        '''Whether to enable asynchronous speech synthesis tasks.

        When true, an S3 bucket for audio output and an SNS topic for
        completion notifications will be created, and the Lambda function will be granted permissions to start and monitor
        asynchronous synthesis tasks.

        :default: - false
        '''
        result = self._values.get("async_jobs")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def bucket_environment_variable_name(self) -> typing.Optional[builtins.str]:
        '''Optional Name for the Lambda function environment variable set to the name of the output bucket.

        Only valid when asyncJobs is true.

        :default: - OUTPUT_BUCKET_NAME
        '''
        result = self._values.get("bucket_environment_variable_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def bucket_props(self) -> typing.Optional["_aws_cdk_aws_s3_ceddda9d.BucketProps"]:
        '''Optional user provided props to override the default props for the S3 Bucket.

        Only valid when asyncJobs is true.

        :default: - Default props are used
        '''
        result = self._values.get("bucket_props")
        return typing.cast(typing.Optional["_aws_cdk_aws_s3_ceddda9d.BucketProps"], result)

    @builtins.property
    def deploy_vpc(self) -> typing.Optional[builtins.bool]:
        '''Whether to deploy a new VPC.

        :default: - false
        '''
        result = self._values.get("deploy_vpc")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def enable_topic_encryption_with_customer_managed_key(
        self,
    ) -> typing.Optional[builtins.bool]:
        '''If no key is provided, this flag determines whether the SNS Topic is encrypted with a new CMK or an AWS managed key.

        This flag is ignored if any of the following are defined: topicProps.masterKey, topicEncryptionKey or topicEncryptionKeyProps.
        Only valid when asyncJobs is true.

        :default: - None
        '''
        result = self._values.get("enable_topic_encryption_with_customer_managed_key")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def existing_bucket_obj(
        self,
    ) -> typing.Optional["_aws_cdk_aws_s3_ceddda9d.IBucket"]:
        '''Existing instance of S3 Bucket object for audio output, providing both this and ``bucketProps`` will cause an error.

        Only valid when asyncJobs is true.

        :default: - None
        '''
        result = self._values.get("existing_bucket_obj")
        return typing.cast(typing.Optional["_aws_cdk_aws_s3_ceddda9d.IBucket"], result)

    @builtins.property
    def existing_lambda_obj(
        self,
    ) -> typing.Optional["_aws_cdk_aws_lambda_ceddda9d.Function"]:
        '''Optional - instance of an existing Lambda Function object, providing both this and ``lambdaFunctionProps`` will cause an error.

        :default: - None
        '''
        result = self._values.get("existing_lambda_obj")
        return typing.cast(typing.Optional["_aws_cdk_aws_lambda_ceddda9d.Function"], result)

    @builtins.property
    def existing_topic_encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.Key"]:
        '''If an existing topic is provided in the ``existingTopicObj`` property, and that topic is encrypted with a customer managed KMS key, this property must specify that key.

        Only valid when asyncJobs is true.

        :default: - None
        '''
        result = self._values.get("existing_topic_encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.Key"], result)

    @builtins.property
    def existing_topic_obj(self) -> typing.Optional["_aws_cdk_aws_sns_ceddda9d.Topic"]:
        '''Optional - existing instance of SNS topic object, providing both this and ``topicProps`` will cause an error.

        Only valid when asyncJobs is true.

        :default: - None
        '''
        result = self._values.get("existing_topic_obj")
        return typing.cast(typing.Optional["_aws_cdk_aws_sns_ceddda9d.Topic"], result)

    @builtins.property
    def existing_vpc(self) -> typing.Optional["_aws_cdk_aws_ec2_ceddda9d.IVpc"]:
        '''An existing VPC for the construct to use (construct will NOT create a new VPC in this case).'''
        result = self._values.get("existing_vpc")
        return typing.cast(typing.Optional["_aws_cdk_aws_ec2_ceddda9d.IVpc"], result)

    @builtins.property
    def lambda_function_props(
        self,
    ) -> typing.Optional["_aws_cdk_aws_lambda_ceddda9d.FunctionProps"]:
        '''Optional - user provided props to override the default props for the Lambda function.

        Providing both this and ``existingLambdaObj``
        causes an error.

        Function will have these Polly permissions: ['polly:SynthesizeSpeech']. When asyncJobs is true, function will also have
        ['polly:StartSpeechSynthesisTask', 'polly:GetSpeechSynthesisTask', 'polly:ListSpeechSynthesisTasks'].

        :default: - Default properties are used.
        '''
        result = self._values.get("lambda_function_props")
        return typing.cast(typing.Optional["_aws_cdk_aws_lambda_ceddda9d.FunctionProps"], result)

    @builtins.property
    def logging_bucket_props(
        self,
    ) -> typing.Optional["_aws_cdk_aws_s3_ceddda9d.BucketProps"]:
        '''Optional user provided props to override the default props for the S3 Logging Bucket.

        Only valid when asyncJobs is true.

        :default: - Default props are used
        '''
        result = self._values.get("logging_bucket_props")
        return typing.cast(typing.Optional["_aws_cdk_aws_s3_ceddda9d.BucketProps"], result)

    @builtins.property
    def log_s3_access_logs(self) -> typing.Optional[builtins.bool]:
        '''Whether to turn on Access Logs for the S3 bucket with the associated storage costs.

        Enabling Access Logging is a best practice.
        Only valid when asyncJobs is true.

        :default: - true
        '''
        result = self._values.get("log_s3_access_logs")
        return typing.cast(typing.Optional[builtins.bool], result)

    @builtins.property
    def topic_encryption_key(self) -> typing.Optional["_aws_cdk_aws_kms_ceddda9d.Key"]:
        '''An optional, imported encryption key to encrypt the SNS Topic with.

        Only valid when asyncJobs is true.

        :default: - not specified.
        '''
        result = self._values.get("topic_encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_aws_kms_ceddda9d.Key"], result)

    @builtins.property
    def topic_encryption_key_props(self) -> typing.Any:
        '''Optional user provided properties to override the default properties for the KMS encryption key used to encrypt the SNS Topic with.

        Only valid when asyncJobs is true.

        :default: - None
        '''
        result = self._values.get("topic_encryption_key_props")
        return typing.cast(typing.Any, result)

    @builtins.property
    def topic_environment_variable_name(self) -> typing.Optional[builtins.str]:
        '''Optional Name for the Lambda function environment variable set to the ARN of the SNS topic used for asynchronous task completion notifications.

        Only valid when asyncJobs is true.

        :default: - SNS_TOPIC_ARN
        '''
        result = self._values.get("topic_environment_variable_name")
        return typing.cast(typing.Optional[builtins.str], result)

    @builtins.property
    def topic_props(self) -> typing.Any:
        '''Optional - user provided properties to override the default properties for the SNS topic.

        Providing both this and ``existingTopicObj`` causes an error. Only valid when asyncJobs is true.

        :default: - Default properties are used.
        '''
        result = self._values.get("topic_props")
        return typing.cast(typing.Any, result)

    @builtins.property
    def vpc_props(self) -> typing.Any:
        '''Properties to override default properties if deployVpc is true.'''
        result = self._values.get("vpc_props")
        return typing.cast(typing.Any, result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "LambdaToPollyProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "LambdaToPolly",
    "LambdaToPollyProps",
]

publication.publish()

def _typecheckingstub__c1ec1a737f0dedaa7072e604dcb4e90ef03aa69f88372962f6ef9381337678b6(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    async_jobs: typing.Optional[builtins.bool] = None,
    bucket_environment_variable_name: typing.Optional[builtins.str] = None,
    bucket_props: typing.Optional[typing.Union[_aws_cdk_aws_s3_ceddda9d.BucketProps, typing.Dict[builtins.str, typing.Any]]] = None,
    deploy_vpc: typing.Optional[builtins.bool] = None,
    enable_topic_encryption_with_customer_managed_key: typing.Optional[builtins.bool] = None,
    existing_bucket_obj: typing.Optional[_aws_cdk_aws_s3_ceddda9d.IBucket] = None,
    existing_lambda_obj: typing.Optional[_aws_cdk_aws_lambda_ceddda9d.Function] = None,
    existing_topic_encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.Key] = None,
    existing_topic_obj: typing.Optional[_aws_cdk_aws_sns_ceddda9d.Topic] = None,
    existing_vpc: typing.Optional[_aws_cdk_aws_ec2_ceddda9d.IVpc] = None,
    lambda_function_props: typing.Optional[typing.Union[_aws_cdk_aws_lambda_ceddda9d.FunctionProps, typing.Dict[builtins.str, typing.Any]]] = None,
    logging_bucket_props: typing.Optional[typing.Union[_aws_cdk_aws_s3_ceddda9d.BucketProps, typing.Dict[builtins.str, typing.Any]]] = None,
    log_s3_access_logs: typing.Optional[builtins.bool] = None,
    topic_encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.Key] = None,
    topic_encryption_key_props: typing.Any = None,
    topic_environment_variable_name: typing.Optional[builtins.str] = None,
    topic_props: typing.Any = None,
    vpc_props: typing.Any = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f8259ca306e2c6e0e6b5945ad532e43d7d480870f61864499b83261e1034a76(
    *,
    async_jobs: typing.Optional[builtins.bool] = None,
    bucket_environment_variable_name: typing.Optional[builtins.str] = None,
    bucket_props: typing.Optional[typing.Union[_aws_cdk_aws_s3_ceddda9d.BucketProps, typing.Dict[builtins.str, typing.Any]]] = None,
    deploy_vpc: typing.Optional[builtins.bool] = None,
    enable_topic_encryption_with_customer_managed_key: typing.Optional[builtins.bool] = None,
    existing_bucket_obj: typing.Optional[_aws_cdk_aws_s3_ceddda9d.IBucket] = None,
    existing_lambda_obj: typing.Optional[_aws_cdk_aws_lambda_ceddda9d.Function] = None,
    existing_topic_encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.Key] = None,
    existing_topic_obj: typing.Optional[_aws_cdk_aws_sns_ceddda9d.Topic] = None,
    existing_vpc: typing.Optional[_aws_cdk_aws_ec2_ceddda9d.IVpc] = None,
    lambda_function_props: typing.Optional[typing.Union[_aws_cdk_aws_lambda_ceddda9d.FunctionProps, typing.Dict[builtins.str, typing.Any]]] = None,
    logging_bucket_props: typing.Optional[typing.Union[_aws_cdk_aws_s3_ceddda9d.BucketProps, typing.Dict[builtins.str, typing.Any]]] = None,
    log_s3_access_logs: typing.Optional[builtins.bool] = None,
    topic_encryption_key: typing.Optional[_aws_cdk_aws_kms_ceddda9d.Key] = None,
    topic_encryption_key_props: typing.Any = None,
    topic_environment_variable_name: typing.Optional[builtins.str] = None,
    topic_props: typing.Any = None,
    vpc_props: typing.Any = None,
) -> None:
    """Type checking stubs"""
    pass
