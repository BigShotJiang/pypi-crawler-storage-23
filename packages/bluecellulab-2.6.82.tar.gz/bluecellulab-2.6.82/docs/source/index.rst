.. bluecellulab documentation master file, created by
   sphinx-quickstart on Mon Jun 19 11:35:51 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


.. include:: ../../README.rst
   :end-before: .. substitutions


.. toctree::
   :hidden:
   :maxdepth: 2

   Home <self>
   list_of_stim
   api.rst
   compiling-mechanisms.rst
   changelog
   contributing

.. |banner| image:: /logo/BlueCelluLabBanner.jpg
