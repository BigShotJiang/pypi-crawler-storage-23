"""Allow running dockdesk as: python -m dockdesk"""
from dockdesk.cli import main

if __name__ == "__main__":
    main()
