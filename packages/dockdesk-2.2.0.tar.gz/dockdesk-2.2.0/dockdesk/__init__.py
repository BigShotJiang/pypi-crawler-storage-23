"""
DockDesk - Local-first semantic documentation auditor.

Uses dual LLM models via Ollama to detect semantic drift between
code logic and documentation claims.
"""

__version__ = "2.1.0"
