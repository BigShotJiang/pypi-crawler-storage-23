from importlib.metadata import version

SANDWICH_VERSION = version("sandwich")