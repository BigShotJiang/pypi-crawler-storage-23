from datetime import datetime

from sqlalchemy import Connection, Engine, MetaData, select, Table, text

from sandwich.dialects import DialectHandlerFactory
from sandwich.modeling.dataclasses import StgInfo, Dv2SystemInfo, Dv2Entity
from sandwich.modeling.metadata import modeling_metadata
from sandwich.modeling.strategies import SchemaGenerator, StrategyFactory
from sandwich.modeling.utils import get_stg_info, infer_profile


def _register_entity(entity_name: str, profile: str, conn: Engine | Connection,
                         verbose: bool = False) -> datetime:
    sys_entities = Table("entities", MetaData(), schema="core", autoload_with=conn)
    created_result = conn.execute(
        select(
            sys_entities.c.created,
            sys_entities.c.profile
        ).where(entity_name == sys_entities.c.entity_name)).one_or_none()
    created_value = created_result.created if created_result else datetime.now()

    if created_result is None:
        conn.execute(sys_entities.insert().values(entity_name=entity_name, profile=profile, created=created_value, updated=created_value))
        if verbose:
            print(f"[ok] Registered `{entity_name}` for `{profile}` on {created_value}")
    else:
        if (created_result.profile != profile
                and (created_result.profile, profile) not in modeling_metadata.supported_profile_upgrades):
            raise Exception(f"This profile upgrade is not supported. You're trying to upgrade `{entity_name}` entity from `{created_result.profile}` profile to `{profile}` which is not allowed")
        _update_entity(entity_name, conn, sys_entities, profile, verbose=verbose)

    return created_value

def _update_entity(entity_name: str, conn: Engine | Connection, sys_entities: Table, profile: str, verbose: bool = False) -> None:
    conn.execute(
        sys_entities.update().where(entity_name == sys_entities.c.entity_name).values(updated=datetime.now(), profile=profile, is_deleted=False))
    if verbose:
        print(f"[ok] Updated `{entity_name}`")


def generate_schema(schema_generator: SchemaGenerator, conn: Engine | Connection,
                    drop_first: bool = False,
                    verbose: bool = False) -> None:
    tables = schema_generator.make_tables()
    for table_type, table in tables.items():
        if table is not None:
            if drop_first:
                table.drop(conn, checkfirst=True)
                if verbose:
                    print(f"[ok] (possibly) Dropped table [{table.schema}].[{table.name}]")
            table.create(conn, checkfirst=True)
            if verbose:
                print(f"[ok] (possibly) Created table [{table.schema}].[{table.name}]")

    procedures = schema_generator.make_procedures(tables)
    for proc_type, (proc_code, proc_name, _) in procedures.items():
        conn.execute(text(proc_code))
        if verbose:
            print(f"[ok] Created or altered {proc_name}")


def _generate_schema_for_entity(stg_info: StgInfo, conn: Engine | Connection, dialect: str,
                                registered_on: datetime, profile: str | None, drop_first: bool = False, verbose: bool = False) -> None:
    validator = StrategyFactory.create_validator(profile)
    sys_info = get_system_info(conn)
    validation_result = validator.validate_staging(stg_info, sys_info)
    dialect_handler = DialectHandlerFactory.create_handler(dialect)
    schema_generator = StrategyFactory.create_generator(dialect_handler, validation_result, registered_on)
    generate_schema(schema_generator, conn, drop_first=drop_first, verbose=verbose)


def register_and_create_entity(entity_name: str, conn: Engine | Connection, dialect: str, profile: str | None = None,
                               schema: str = "stg", drop_first: bool = False, verbose: bool = False) -> None:
    stg_info = get_stg_info(entity_name, schema, conn)
    if profile is None:
        profile = infer_profile(stg_info)
    registered_on = _register_entity(entity_name, profile, conn)
    _generate_schema_for_entity(stg_info, conn, dialect, registered_on, profile, drop_first=drop_first, verbose=verbose)


def update_registered_entities(conn: Engine | Connection, dialect: str, schema: str = "stg",
                               drop_first: bool = False,
                               verbose: bool = False) -> None:
    sys_info = get_system_info(conn)
    for en in sys_info.entities_list:
        stg_info = get_stg_info(en.entity_name, schema, conn)
        _update_entity(en.entity_name, conn, sys_info.sys_entities, en.profile, verbose=verbose)
        _generate_schema_for_entity(stg_info, conn, dialect, en.created_on, en.profile, drop_first=drop_first, verbose=verbose)


def get_system_info(conn: Engine | Connection):
    sys_entities = Table("entities", MetaData(), schema="core", autoload_with=conn)
    select_result = conn.execute(sys_entities.select().where(~sys_entities.c.is_deleted))
    return Dv2SystemInfo(
        [Dv2Entity(en["entity_name"], en["profile"], en["created"]) for en in select_result.mappings().all()],
        sys_entities
    )
