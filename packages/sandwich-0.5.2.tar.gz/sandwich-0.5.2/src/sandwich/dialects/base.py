from abc import ABC, abstractmethod
from typing import Tuple

from sqlalchemy import Table, TextClause

class DialectHandler(ABC):
    @abstractmethod
    def get_boolean_type(self): ...

    @abstractmethod
    def get_proc_name_format(self, schema: str, operation: str, entity_name: str) -> str:
        pass

    @abstractmethod
    def apply_proc_template(self, proc_name: str, sql_body: str, header: str) -> str:
        pass

    @abstractmethod
    def make_stg_materialization_proc(
        self,
        entity_name: str,
        header: str
    ) -> Tuple[str, str, str]:
        pass

    @abstractmethod
    def make_hub_proc(
        self,
        hub_table: Table,
        bk_keys: list,
        header: str
    ) -> Tuple[str, str, str]:
        pass

    @abstractmethod
    def make_link_proc(
        self,
        link_table: Table,
        hk_keys: list,
        header: str
    ) -> Tuple[str, str, str]:
        pass

    @abstractmethod
    def make_scd2_sat_proc(
        self,
        sat_table: Table,
        hk_name: str,
        hashdiff_col: str,
        is_available_col: str,
        loaddate_col: str,
        stg_schema: str,
        header: str
    ) -> Tuple[str, str, str]:
        pass

    @abstractmethod
    def make_scd0_sat_proc(self, sat_table: Table, header: str) -> Tuple[str, str, str]:
        pass

    @abstractmethod
    def make_scd2_dim_proc(
        self,
        dim_table: Table,
        bk_keys: list,
        header: str
    ) -> Tuple[str, str, str]:
        pass

    @abstractmethod
    def make_job_proc(
        self,
        entity_name: str,
        proc_names: list[str],
        header: str
    ) -> Tuple[str, str, str]:
        pass

    @abstractmethod
    def make_drop_proc(self, entity_name, table_schemas: list[str], procedures: list[str], header: str) \
        -> Tuple[str, str, str]: ...