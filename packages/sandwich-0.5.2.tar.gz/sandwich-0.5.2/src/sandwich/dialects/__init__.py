"""Dialects package for SQL code generation."""
from sandwich.dialects.base import DialectHandler
from sandwich.dialects.factory import DialectHandlerFactory
from sandwich.dialects.mssql import MssqlDialectHandler
from sandwich.dialects.postgres import PostgresDialectHandler

__all__ = [
    "DialectHandler",
    "DialectHandlerFactory",
    "MssqlDialectHandler",
    "PostgresDialectHandler",
]
