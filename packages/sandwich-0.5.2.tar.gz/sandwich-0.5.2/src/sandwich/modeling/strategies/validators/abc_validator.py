from abc import ABC, abstractmethod

from sandwich.modeling.dataclasses import StgInfo, Dv2SystemInfo, ValidationResult


class Validator(ABC):
    @abstractmethod
    def validate_staging(self, stg_info: StgInfo, sys_info: Dv2SystemInfo, verbose: bool = False) -> ValidationResult:
        pass