from sandwich.modeling.dataclasses import Dv2SystemInfo, StgInfo

from .base_validator import BaseValidator


class HubBasedValidator(BaseValidator):
    def __init__(self, profile: str):
        super().__init__(profile)
        self._on_validate_staging.append(self._validate_hub_staging)

    @staticmethod
    def _validate_hub_staging(stg_info: StgInfo, _: Dv2SystemInfo) -> None:
        # -----------------
        # hk
        # -----------------
        # only one hash key is allowed for a hub table
        # and its name should match `hk_[entity_name]` pattern
        hk_count = len(stg_info.hk_keys)
        if hk_count == 0:
            raise Exception("hk column is required for `hub` validation")
        elif hk_count > 1:
            raise Exception(f"More than one hk column found in stg.{stg_info.stg_name}")
        # hk_key = (key_name, key_type)
        hk_key = list(stg_info.hk_keys.items())[0]
        if hk_key[0] != f"hk_{stg_info.stg_name}":
            raise Exception(f"hk column has invalid name '{hk_key[0]}'")

        # -----------------
        # BKs
        # -----------------
        # You don't need a hub or/and a dim tables for a non-business entity.
        # So you have to have at least one business key, and you can have more.
        # Naming convention is to just add a `bk_` prefix to the original key name
        # because we want to keep information of the original names
        if len(stg_info.bk_keys) == 0:
            raise Exception("bk column(s) are required for `hub-scd2dim` validation")