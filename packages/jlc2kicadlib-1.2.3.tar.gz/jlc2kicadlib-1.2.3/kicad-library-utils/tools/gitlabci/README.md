The files in this directory are for running the CI on
* kicad-symbols
* kicad-footprints

The CI for this repo (kicad-library-utils) can be found in ./.gitlab-ci.yml
