"""
Library for parsing a library table file (e.g. used for project-specific library settings files).
"""

import re
from typing import Dict, List


class LibTable:
    def __init__(self, filename: str):
        RE_NAME = r'\(name "?([^\)"]*)"?\)'
        RE_TYPE = r'\(type "?([^\)"]*)"?\)'
        RE_URI = r'\(uri "?([^\)"]*)"?\)'
        RE_OPT = r'\(options "?([^\)"]*)"?\)'
        RE_DESC = r'\(descr "?([^\)"]*)"?'

        self.entries: List[Dict[str, str]] = []
        self.errors: List[str] = []

        with open(filename) as lib_table_file:
            for line in lib_table_file:
                # Skip lines that do not define a library
                if "(lib " not in line:
                    continue

                re_name = re.search(RE_NAME, line)
                re_type = re.search(RE_TYPE, line)
                re_uri = re.search(RE_URI, line)
                re_opt = re.search(RE_OPT, line)
                re_desc = re.search(RE_DESC, line)

                if re_name and re_type and re_uri and re_opt and re_desc:
                    entry = {}
                    entry["name"] = re_name.groups()[0]
                    entry["type"] = re_type.groups()[0]
                    entry["uri"] = re_uri.groups()[0]
                    entry["opt"] = re_opt.groups()[0]
                    entry["desc"] = re_desc.groups()[0]

                    self.entries.append(entry)

                else:
                    self.errors.append(line)
