# Chat Notifier

A lightweight Python library for sending **Google Chat notifications** from ML workflows.
It helps monitor **MLflow experiments** and **Ray jobs** and send alerts to your team automatically.

Useful for **ML engineers and MLOps pipelines** running long training jobs.

---

## Features

* Send notifications to Google Chat via webhook
* Monitor MLflow experiments for new best metrics
* Send completion/failure notifications for Ray jobs
* Lightweight and easy to integrate

---

## Installation

Install with pip:

```bash
pip install chat-notifier
```

---

## MLflow Experiment Notification

This example checks if a new **best metric** is produced in an MLflow experiment and sends a notification.

```python
from notifier import MLflowNotifier

nn = MLflowNotifier(
    webhook_url="YOUR_GOOGLE_CHAT_WEBHOOK",
    tracking_uri="http://mlflow.server",
    metric_mode="max",
    metric_name="mAP50"
)

nn.check_new_best(
    "ppe-detection",
    "228f5a2e084040d4aadc16cd22f6c12c"
)
```

---

## Ray Job Notification

Send a notification when a training job starts, finishes, or fails.

```python
from notifier import RayJobNotifier
from datetime import datetime

ray_obj = RayJobNotifier(
    webhook_url="YOUR_GOOGLE_CHAT_WEBHOOK",
    server="gtx-1080",
    model_name="yolo11",
    max_chars=2000
)

ray_obj.send_notification(
    status=1,
    start_time=datetime.utcnow(),
    end_time=datetime.utcnow(),
    logs="training finished successfully"
)
```

---

## Status Codes

| Code | Meaning                    |
| ---- | -------------------------- |
| 0    | Job Failed                 |
| 1    | Job Completed Successfully |
| 2    | Job Running                |

---

## Example Use Cases

* Notify when a **new best MLflow experiment result** appears
* Send alerts when **Ray training jobs complete**
* Monitor **long-running ML pipelines**
* Inform teams about experiment progress via Google Chat

---

## License

MIT License
