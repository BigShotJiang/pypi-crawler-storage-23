import os
import requests
from datetime import datetime


class RayJobNotifier:
    """
    Sends Google Chat notifications for Ray training jobs.
    """

    def __init__(
        self,
        webhook_url: str | None = None,
        server: str | None = None,
        model_name: str | None = None,
        max_chars: int = 1500
    ):

        self.webhook_url = webhook_url or os.getenv("GOOGLE_CHAT_RAY_WEBHOOK_URL")
        self.server = server or os.getenv("SERVER", "UNKNOWN")
        self.model_name = model_name or os.getenv("MODEL_NAME", "UNKNOWN")
        self.max_chars = int(os.getenv("MAX_CHARS", max_chars))

        if not self.webhook_url:
            raise RuntimeError("GOOGLE_CHAT_RAY_WEBHOOK_URL is not set")

    # --------------------------------------------------
    # Utility Methods
    # --------------------------------------------------

    def truncate_logs(self, text: str) -> str:
        """
        Returns last N characters from logs to prevent oversized payloads.
        """

        if not text:
            return ""

        if len(text) <= self.max_chars:
            return text

        return text[-self.max_chars:]


    def format_duration(self, delta):
        """
        Converts timedelta to HH:MM:SS format.
        """

        total_seconds = int(delta.total_seconds())

        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60
        seconds = total_seconds % 60

        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


    # --------------------------------------------------
    # Main Notification Method
    # --------------------------------------------------

    def send_notification(
        self,
        status: int,
        logs: str = "",
        start_time: datetime | None = None,
        end_time: datetime | None = None
    ):
        """
        Sends formatted notification to Google Chat.
        """

        start_str = (
            start_time.strftime("%Y-%m-%d %H:%M:%S UTC")
            if start_time else "UNKNOWN"
        )

        end_str = (
            end_time.strftime("%Y-%m-%d %H:%M:%S UTC")
            if end_time else "UNKNOWN"
        )

        duration_str = (
            self.format_duration(end_time - start_time)
            if start_time and end_time else "UNKNOWN"
        )

        status_text = "FAILED" if status != 0 else "SUCCESS"

        message = f"""
Ray Training Job Update

Status     : {status_text}
Server     : {self.server}
Model      : {self.model_name}

Started At : {start_str}
Ended At   : {end_str}
Duration   : {duration_str}
"""

        if status != 0 and logs:
            message += f"\nLast Logs:\n{self.truncate_logs(logs)}"

        payload = {"text": message}

        try:

            response = requests.post(
                self.webhook_url,
                json=payload,
                timeout=10
            )

            response.raise_for_status()

        except Exception as e:

            print(f"[RayJobNotifier] Failed to send notification: {e}")hat-notifier
