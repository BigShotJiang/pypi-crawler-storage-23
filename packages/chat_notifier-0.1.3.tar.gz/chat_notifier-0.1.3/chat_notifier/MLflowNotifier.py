import os
import requests
from datetime import datetime
import mlflow
from mlflow.tracking import MlflowClient


class MLflowNotifier:

    def __init__(
        self,
        webhook_url: str = None,
        tracking_uri: str = None,
        metric_name: str = None,
        metric_mode: str = None
    ):

        self.tracking_uri = tracking_uri or os.getenv(
            "MLFLOW_TRACKING_URI",
            "http://localhost:5000"
        )

        self.webhook_url = webhook_url or os.getenv(
            "GOOGLE_CHAT_WEBHOOK_URL"
        )

        self.metric_name = metric_name or os.getenv(
            "METRIC_NAME",
            "mAP50"
        )

        self.metric_mode = metric_mode or os.getenv(
            "METRIC_MODE",
            "max"
        )

        mlflow.set_tracking_uri(self.tracking_uri)
        self.client = MlflowClient()

    # ----------------------------------------------------
    # REQUIRED METHOD 1
    # ----------------------------------------------------

    def send_google_chat_notification(
        self,
        experiment_name: str,
        experiment_id: str,
        run_id: str,
        metric_value: float,
        previous_best: float | None
    ):

        if not self.webhook_url:
            print(" GOOGLE_CHAT_WEBHOOK_URL not set")
            return

        improvement = (
            f"{((metric_value - previous_best) / previous_best * 100):.2f}%"
            if previous_best is not None
            else "First run"
        )

        mlflow_run_url = (
            f"{self.tracking_uri}/#/experiments/{experiment_id}/runs/{run_id}"
        )

        card = {
            "cards": [{
                "header": {
                    "title": "🎉 New Best Model!",
                    "subtitle": f"Experiment: {experiment_name}",
                    "imageUrl": "https://mlflow.org/img/mlflow-logo.png"
                },
                "sections": [{
                    "widgets": [
                        {"keyValue": {"topLabel": "Metric", "content": self.metric_name}},
                        {"keyValue": {"topLabel": "New Best", "content": f"{metric_value:.4f}"}},
                        {"keyValue": {"topLabel": "Previous Best", "content": f"{previous_best:.4f}" if previous_best else "N/A"}},
                        {"keyValue": {"topLabel": "Improvement", "content": improvement}},
                        {"keyValue": {"topLabel": "Run ID", "content": run_id[:8]}},
                        {"keyValue": {"topLabel": "Time", "content": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}},
                        {
                            "buttons": [{
                                "textButton": {
                                    "text": "VIEW IN MLFLOW",
                                    "onClick": {
                                        "openLink": {
                                            "url": mlflow_run_url
                                        }
                                    }
                                }
                            }]
                        }
                    ]
                }]
            }]
        }

        try:

            response = requests.post(
                self.webhook_url,
                json=card,
                timeout=10
            )

            response.raise_for_status()

            print("Google Chat notification sent")

        except Exception as e:

            print(f" Failed to send notification: {e}")

    # ----------------------------------------------------
    # REQUIRED METHOD 2
    # ----------------------------------------------------

    def check_new_best(
        self,
        experiment_name: str,
        run_id: str
    ):

        experiment = self.client.get_experiment_by_name(
            experiment_name
        )

        if experiment is None:
            print(f" Experiment '{experiment_name}' not found")
            return

        run = self.client.get_run(run_id)

        current_metric = run.data.metrics.get(self.metric_name)

        if current_metric is None:

            print("Metric not found in current run")
            print(f"Expected metric : {self.metric_name}")
            print(f"Available metrics: {sorted(run.data.metrics.keys())}")
            print(f"Run ID: {run_id}")

            return

        previous_runs = self.client.search_runs(
            experiment_ids=[experiment.experiment_id],
            filter_string=f"attributes.run_id != '{run_id}'",
            order_by=[
                f"metrics.{self.metric_name} {'DESC' if self.metric_mode == 'max' else 'ASC'}"
            ],
            max_results=10
        )

        previous_best = None

        for r in previous_runs:

            val = r.data.metrics.get(self.metric_name)

            if val is not None:
                previous_best = val
                break

        is_better = (
            previous_best is None or
            (
                current_metric > previous_best
                if self.metric_mode == "max"
                else current_metric < previous_best
            )
        )

        if is_better:

            print(
                f"🎉 New best {self.metric_name}: {current_metric:.4f}"
            )

            self.send_google_chat_notification(
                experiment_name,
                experiment.experiment_id,
                run_id,
                current_metric,
                previous_best
            )

        else:

            print(
                f"ℹ️ Not a new best | "
                f"Current: {current_metric:.4f}, "
                f"Best: {previous_best:.4f}"
            )
