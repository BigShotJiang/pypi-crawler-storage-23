from .watereos import getProp, list_models

__all__ = ['getProp', 'list_models']
