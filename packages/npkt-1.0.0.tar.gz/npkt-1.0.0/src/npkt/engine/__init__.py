"""SCP evaluation engine."""

from .condition_evaluator import (
    ConditionEvaluationResult,
    evaluate_condition_block,
    evaluate_single_condition,
    get_context_value,
)
from .matcher import (
    action_excluded_by_not_action,
    action_matches,
    action_matches_any,
    extract_service,
    principal_excluded_by_not_principal,
    principal_matches,
    principal_matches_any,
    resource_excluded_by_not_resource,
    resource_matches,
    resource_matches_any,
)
from .resource_extractor import ResourceExtractor
from .scp_engine import SCPEngine

__all__ = [
    "ResourceExtractor",
    "SCPEngine",
    "action_matches",
    "action_matches_any",
    "extract_service",
    "action_excluded_by_not_action",
    "resource_matches",
    "resource_matches_any",
    "resource_excluded_by_not_resource",
    "principal_matches",
    "principal_matches_any",
    "principal_excluded_by_not_principal",
    "ConditionEvaluationResult",
    "evaluate_condition_block",
    "evaluate_single_condition",
    "get_context_value",
]
