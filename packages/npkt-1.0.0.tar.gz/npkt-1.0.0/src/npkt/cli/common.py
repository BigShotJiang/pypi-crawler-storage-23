"""Shared CLI utilities."""

from __future__ import annotations

from pathlib import Path

import click


def resolve_policy_files(policy_path: str) -> list[Path]:
    """Resolve a policy path to a sorted list of JSON files.

    Args:
        policy_path: Path to a JSON file or directory containing JSON files.

    Returns:
        Sorted list of Path objects.

    Raises:
        click.ClickException: If path is invalid or no JSON files found.
    """
    path = Path(policy_path)
    if path.is_file():
        return [path]
    if path.is_dir():
        files = sorted(path.glob("*.json"))
        if not files:
            raise click.ClickException(f"No JSON files found in {path}")
        return files
    raise click.ClickException(f"Invalid path: {path}")
