"""CLI module for npkt."""

from .main import cli

__all__ = ["cli"]
