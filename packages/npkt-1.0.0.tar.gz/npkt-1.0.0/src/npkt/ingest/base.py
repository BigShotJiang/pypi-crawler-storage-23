"""Base interface for CloudTrail event ingesters."""

from abc import ABC, abstractmethod
from collections.abc import Iterator
from datetime import datetime
from typing import Any

from ..models.cloudtrail import CloudTrailEvent


class CloudTrailIngester(ABC):
    """
    Abstract base class for CloudTrail event ingesters.

    Subclasses should implement fetch_events() to provide events from
    different sources (S3, API, local files, etc.).
    """

    @abstractmethod
    def fetch_events(
        self,
        start_time: datetime,
        end_time: datetime,
        filters: dict[str, Any] | None = None,
    ) -> Iterator[CloudTrailEvent]:
        """
        Fetch CloudTrail events within the specified time range.

        Args:
            start_time: Start of the time range (inclusive)
            end_time: End of the time range (inclusive)
            filters: Optional filters to apply (implementation-specific)

        Yields:
            CloudTrailEvent objects

        Raises:
            Exception: Implementation-specific exceptions
        """
        pass
