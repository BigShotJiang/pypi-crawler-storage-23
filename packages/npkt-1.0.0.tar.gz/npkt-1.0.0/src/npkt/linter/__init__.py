"""SCP linter module."""

from .scp_linter import SCPLinter

__all__ = ["SCPLinter"]
