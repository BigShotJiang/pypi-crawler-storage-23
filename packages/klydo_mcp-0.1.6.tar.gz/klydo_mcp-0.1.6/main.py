def main():
    print("Hello from klydo-mcp!")


if __name__ == "__main__":
    main()
