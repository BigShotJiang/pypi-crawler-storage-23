"""
Klydo MCP Server - Fashion discovery for Indian Gen Z.

A Model Context Protocol server that enables AI assistants
to search and discover fashion products from Indian e-commerce sites.
"""

__version__ = "0.1.0"
