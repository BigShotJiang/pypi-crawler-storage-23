"""
Klydo MCP Server Test Suite.

Run tests with: uv run pytest
"""
