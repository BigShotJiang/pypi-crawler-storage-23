"""
Substr8 CLI - Unified command-line interface

Usage:
    substr8 gam <command>      Git-Native Agent Memory
    substr8 fdaa <command>     File-Driven Agent Architecture (planned)
    substr8 acc <command>      Agent Capability Control (planned)
"""

import click
from rich.console import Console

console = Console()


@click.group()
@click.version_option(version="0.6.3", prog_name="substr8")
def main():
    """Substr8 Platform CLI - Verifiable AI Infrastructure"""
    pass


# === GAM Integration ===

from substr8.gam.cli import main as gam_main

# Register GAM as a subcommand group
main.add_command(gam_main, name="gam")


# === FDAA Integration ===

from substr8.fdaa.cli import main as fdaa_main

# Register FDAA as a subcommand group
main.add_command(fdaa_main, name="fdaa")


# === ACC (alias for gam permissions) ===

@main.group()
def acc():
    """Agent Capability Control (via gam permissions)"""
    pass


@acc.command("list")
def acc_list():
    """List permission policies. Alias for: substr8 gam permissions list"""
    console.print("[cyan]ACC is implemented via GAM permissions.[/cyan]")
    console.print("\nUse: [bold]substr8 gam permissions list[/bold]")
    console.print("\nAvailable commands:")
    console.print("  substr8 gam permissions list    - List all policies")
    console.print("  substr8 gam permissions add     - Add a policy")
    console.print("  substr8 gam permissions check   - Check path permission")
    console.print("  substr8 gam permissions hitl    - Show HITL paths")


# === DCT (alias for fdaa dct) ===

@main.group()
def dct():
    """Delegation Capability Tokens (via fdaa dct)"""
    pass


@dct.command("list")
def dct_list():
    """List tokens. Alias for: substr8 fdaa dct list"""
    console.print("[cyan]DCT is implemented via FDAA.[/cyan]")
    console.print("\nUse: [bold]substr8 fdaa dct <command>[/bold]")
    console.print("\nAvailable commands:")
    console.print("  substr8 fdaa dct create     - Create a new token")
    console.print("  substr8 fdaa dct attenuate  - Attenuate permissions")
    console.print("  substr8 fdaa dct verify     - Verify signature")
    console.print("  substr8 fdaa dct check      - Check permission")
    console.print("  substr8 fdaa dct inspect    - Inspect token contents")
    console.print("  substr8 fdaa dct list       - List saved tokens")


# === Info Commands ===

@main.command()
def info():
    """Show Substr8 platform information."""
    import platform
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich import box
    
    # Header
    console.print()
    console.print("[bold cyan]  ███████╗██╗   ██╗██████╗ ███████╗████████╗██████╗  █████╗ [/bold cyan]")
    console.print("[bold cyan]  ██╔════╝██║   ██║██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██╔══██╗[/bold cyan]")
    console.print("[bold cyan]  ███████╗██║   ██║██████╔╝███████╗   ██║   ██████╔╝╚█████╔╝[/bold cyan]")
    console.print("[bold cyan]  ╚════██║██║   ██║██╔══██╗╚════██║   ██║   ██╔══██╗██╔══██╗[/bold cyan]")
    console.print("[bold cyan]  ███████║╚██████╔╝██████╔╝███████║   ██║   ██║  ██║╚█████╔╝[/bold cyan]")
    console.print("[bold cyan]  ╚══════╝ ╚═════╝ ╚═════╝ ╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚════╝ [/bold cyan]")
    console.print()
    console.print("[dim]  Verifiable AI Infrastructure[/dim]")
    console.print()
    
    # Components table
    table = Table(show_header=True, box=box.ROUNDED, title="[bold]Components[/bold]")
    table.add_column("Module", style="cyan", width=8)
    table.add_column("Status", width=10)
    table.add_column("Description", style="dim")
    
    table.add_row("fdaa", "[green]✓ ready[/green]", "File-Driven Agent Architecture")
    table.add_row("gam", "[green]✓ ready[/green]", "Git-Native Agent Memory")
    table.add_row("acc", "[green]✓ ready[/green]", "Agent Capability Control [dim](gam permissions)[/dim]")
    table.add_row("dct", "[green]✓ ready[/green]", "Delegation Capability Tokens [dim](fdaa dct)[/dim]")
    
    console.print(table)
    console.print()
    
    # Quick start
    console.print("[bold]Quick Start[/bold]")
    console.print("  [cyan]substr8 fdaa init my-agent[/cyan]    Create an agent workspace")
    console.print("  [cyan]substr8 gam init[/cyan]              Initialize memory in current repo")
    console.print("  [cyan]substr8 fdaa chat my-agent[/cyan]    Chat with your agent")
    console.print()
    
    # Links
    console.print("[bold]Links[/bold]")
    console.print("  [dim]Docs:[/dim]      https://substr8labs.com/docs")
    console.print("  [dim]GitHub:[/dim]    https://github.com/Substr8-Labs")
    console.print("  [dim]PyPI:[/dim]      https://pypi.org/project/substr8")
    console.print()
    
    # Version & system
    console.print(f"[dim]v0.6.3 • Python {platform.python_version()} • {platform.system()} {platform.machine()}[/dim]")
    console.print()


if __name__ == "__main__":
    main()
