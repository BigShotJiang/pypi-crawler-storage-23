"""
FDAA - File-Driven Agent Architecture
Reference implementation by Substr8 Labs
"""

__version__ = "0.1.0"
