"""Generic compilation pipeline: Block tree → flat SystemIR."""

from gds.compiler.compile import compile_system

__all__ = ["compile_system"]
