"""PhysBound — Physical Layer Linter for AI hallucination detection."""

__version__ = "0.1.3"
