"""
PyDPM Command Line Interface

CLI commands for PyDPM operations.
"""

from py_dpm.cli.main import main as cli

__all__ = ["cli"]
