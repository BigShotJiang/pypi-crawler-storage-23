"""CLI commands for lineage prototype.

This module provides CLI commands for initializing databases, loading dbt projects,
and running semantic analysis on models.
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from pathlib import Path
from typing import Optional

import click
import uvicorn

from lineage.backends.config import UnifiedConfig
from lineage.backends.data_query.factory import create_data_backend_for_cli
from lineage.backends.lineage.factory import create_storage_for_cli
from lineage.ingest.config import IngestConfig
from lineage.ingest.static_loaders.dbt.builder import LineageBuilder
from lineage.ingest.static_loaders.dbt.config import LineageBuildConfig
from lineage.ingest.static_loaders.salesforce.client import SalesforceMetadataClient
from lineage.integration import load_full_lineage
from lineage.utils.drop_snowflake_objects import drop_objects
from lineage.utils.env import load_env_file
from lineage.utils.run_snowflake_query import execute_sql_file


@click.group()
def main() -> None:
    """Lineage prototype CLI."""
    pass


def load_config(config_path: Path) -> UnifiedConfig:
    """Load unified configuration from YAML file."""
    try:
        return UnifiedConfig.from_yaml(config_path)
    except FileNotFoundError as e:
        click.echo(f"Error: Config file not found: {config_path}", err=True)
        raise click.Abort() from e
    except ValueError as e:
        click.echo(f"Error: Invalid configuration: {e}", err=True)
        raise click.Abort() from e


def load_ingest_config(config_path: Path) -> IngestConfig:
    """Load ingest configuration from YAML file."""
    try:
        return IngestConfig.from_yaml(config_path)
    except FileNotFoundError as e:
        click.echo(f"Error: Ingest config file not found: {config_path}", err=True)
        raise click.Abort() from e
    except ValueError as e:
        click.echo(f"Error: Invalid ingest configuration: {e}", err=True)
        raise click.Abort() from e


def _discover_ingest_config(artifacts_dir: Path, verbose: bool = False) -> Path:
    """Discover ingest config file with fallback logic.

    Search order:
    1. ingest.yml in artifacts_dir
    2. config.yml in artifacts_dir
    3. config.ingest.default.yml in typedef_data_intelligence root

    Args:
        artifacts_dir: dbt artifacts directory (target/)
        verbose: Enable verbose output

    Returns:
        Path to ingest config file
    """
    # Try ingest.yml in artifacts dir
    ingest_yml = artifacts_dir / "ingest.yml"
    if ingest_yml.exists():
        if verbose:
            click.echo(f"📄 Using ingest config: {ingest_yml}")
        return ingest_yml

    # Try config.yml in artifacts dir
    config_yml = artifacts_dir / "config.yml"
    if config_yml.exists():
        if verbose:
            click.echo(f"📄 Using ingest config: {config_yml}")
        return config_yml

    # Fall back to default config in typedef_data_intelligence root
    default_config = Path(__file__).parent.parent.parent / "config.ingest.default.yml"
    if default_config.exists():
        if verbose:
            click.echo(f"📄 Using default ingest config: {default_config}")
        return default_config

    raise click.ClickException(
        f"No ingest config found. Searched:\n"
        f"  - {ingest_yml}\n"
        f"  - {config_yml}\n"
        f"  - {default_config}\n"
        f"Please create an ingest.yml or use --ingest-config"
    )


@main.command()
@click.argument("artifacts_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option("--ingest-config", type=click.Path(exists=True, path_type=Path), default=None, help="Path to ingest config YAML file (auto-discovers if not provided)")
def init(artifacts_dir: Path, ingest_config: Optional[Path] = None, verbose: bool = False) -> None:
    """`Init`ialize or recreate the database typed schema."""
    # Auto-discover or use provided ingest config
    if ingest_config is None:
        ingest_config = _discover_ingest_config(artifacts_dir, verbose=verbose)

    cfg = load_ingest_config(ingest_config)
    storage = create_storage_for_cli(cfg.lineage)

    # Recreate schema (supported by all adapters)
    try:
        storage.recreate_schema()
        click.echo(f"✅ Initialized database schema using {type(storage).__name__}")
    except AttributeError:
        click.echo(f"✅ Initialized database using {type(storage).__name__}")


@main.command()
@click.argument("sql_file", type=click.Path(exists=True, path_type=Path))
def run_snowflake_query(sql_file: Path) -> None:
    """Run a Snowflake query."""
    execute_sql_file(sql_file)

@main.command()
@click.option("--drop-staging", "drop_staging", is_flag=True, default=False, help="Drop staging schema (default: staging is ignored)")
def drop_snowflake_objects(drop_staging: bool) -> None:
    """Drop all Snowflake objects."""
    # Invert: if drop_staging is True, then ignore_staging is False
    drop_objects(ignore_staging=not drop_staging)


@main.command("load-dbt-models")
@click.argument("artifacts_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option("--ingest-config", type=click.Path(exists=True, path_type=Path), required=True, help="Path to unified config YAML file")
@click.option("--force-full", is_flag=True, default=False, help="Force full reload (disables incremental loading)")
def load_dbt_models(artifacts_dir: Path, ingest_config: Path, force_full: bool) -> None:
    """Load dbt lineage directly into typed tables from an artifacts directory (target/)."""
    load_env_file()
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    cfg = load_ingest_config(ingest_config)
    storage = create_storage_for_cli(cfg.lineage)
    time_start = time.time()
    click.echo(f"Loading dbt artifacts from {artifacts_dir}...")
    build_config = LineageBuildConfig().with_dialect(cfg.data.backend)
    builder = LineageBuilder.from_dbt_artifacts(artifacts_dir, config=build_config)
    builder_time = time.time() - time_start
    click.echo(f"Builder time: {builder_time:.2f} seconds")
    time_start = time.time()
    
    # Use incremental mode by default (unless --force-full is specified)
    if not force_full:
        from lineage.ingest.static_loaders.change_detection import ChangeDetector
        artifacts = builder.loader.load()
        detector = ChangeDetector()

        # Create dialect_resolver using builder's config to ensure fingerprints match
        # between change detection and graph storage (fixes dialect mismatch bug)
        def dialect_resolver(model_id: str) -> Optional[str]:
            return builder.config.sqlglot.per_model_dialects.get(
                model_id, builder.config.sqlglot.default_dialect
            )

        change_set = detector.detect_changes(artifacts, storage, dialect_resolver=dialect_resolver)
        if change_set.has_changes:
            builder.write_incremental(storage, change_set)
        else:
            click.echo("No changes detected - all models unchanged")

        # Handle tests incrementally.
        # Always run detection (even when counts are 0) so that removals are caught.
        test_changes = detector.detect_test_changes(artifacts, storage)
        unit_test_changes = detector.detect_unit_test_changes(artifacts, storage)
        if test_changes.has_changes or unit_test_changes.has_changes:
            builder.write_incremental_tests(
                storage, test_changes, unit_test_changes
            )
        else:
            click.echo("No test changes detected - all tests unchanged")
    else:
        builder.write_typed(storage)
    
    write_time = time.time() - time_start
    click.echo(f"Write time: {write_time:.2f} seconds")
    click.echo(f"Loaded dbt artifacts (typed) from {artifacts_dir}")


@main.command("load-dbt-full")
@click.argument("artifacts_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option("--ingest-config", type=click.Path(exists=True, path_type=Path), default=None, help="Path to ingest config YAML file (auto-discovers if not provided)")
@click.option("--export-cache/--no-export-cache", default=None, help="Override export_cache config setting")
@click.option("--force-full", is_flag=True, default=False, help="Force full reload (disables incremental loading)")
@click.option("--verbose", is_flag=True, help="Enable verbose output")
def load_dbt_full(
    artifacts_dir: Path,
    ingest_config: Path | None,
    export_cache: bool | None,
    force_full: bool,
    verbose: bool,
) -> None:
    """Load dbt lineage with semantic analysis, profiling, and clustering.

    This command:
    1. Loads dbt models, sources, columns, and dependencies
    2. [Optional] Loads semantic views from data warehouse (Snowflake/etc)
    3. [Optional] Profiles table data (row counts, column statistics)
    4. [Optional] Runs semantic SQL analysis on each model's compiled SQL
    5. [Optional] Clusters models based on join patterns (Louvain algorithm)

    Configuration auto-discovery:
    - Searches for ingest.yml in artifacts_dir
    - Falls back to config.yml in artifacts_dir
    - Falls back to config.ingest.default.yml in project root
    - Or use --ingest-config to specify explicitly

    Configuration fields:
    - population.models: LLM model configs for semantic analysis (micro/small/medium/large/xlarge)
    - population.semantic_analysis.enabled: Run semantic analysis
    - population.semantic_analysis.max_workers: Max concurrent workers
    - population.semantic_analysis.pipeline: Pipeline pass model assignments
    - population.clustering.enabled: Cluster by join patterns
    - population.profiling.enabled: Profile table data
    - population.semantic_view_loader.enabled: Load semantic views

    Example:
        uv run lineage load-dbt-full target/ --verbose
        uv run lineage load-dbt-full target/ --ingest-config ingest.yml --verbose
    """
    load_env_file()
    # Enable DEBUG logging for lineage module if verbose
    if verbose:
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        logging.getLogger("httpcore").setLevel(logging.WARNING)
        logging.getLogger("httpx").setLevel(logging.WARNING)
        logging.getLogger("google_genai.models").setLevel(logging.WARNING)
        logging.getLogger("openai").setLevel(logging.INFO)

    # Auto-discover or use provided ingest config
    if ingest_config is None:
        ingest_config = _discover_ingest_config(artifacts_dir, verbose=verbose)

    cfg = load_ingest_config(ingest_config)
    storage = create_storage_for_cli(cfg.lineage)

    # Get population settings from ingest config
    pop = cfg.population

    # Create data backend from ingest config
    data_backend_instance = create_data_backend_for_cli(cfg.data, read_only=True)

    if verbose:
        click.echo(f"📁  Lineage backend: {cfg.lineage.backend}")
        click.echo(f"📊 Data backend: {cfg.data.backend}")
        click.echo(f"🔧 Semantic analysis: {pop.semantic_analysis.enabled}")
        click.echo(f"🔧 Clustering: {pop.clustering.enabled}")
        click.echo(f"🔧 Profiling: {pop.profiling.enabled}")
        click.echo(f"🔧 Semantic views: {pop.semantic_view_loader.enabled}")
        models = pop.semantic_analysis.models
        click.echo(f"🤖 Analysis models: micro={models.micro.model_name}, small={models.small.model_name}, medium={models.medium.model_name}, large={models.large.model_name}, xlarge={models.xlarge.model_name}")
        click.echo(f"⚡ Max semantic workers: {pop.semantic_analysis.max_workers}")
        click.echo(f"⚡ Max profiling workers: {pop.profiling.max_workers}")

    load_full_lineage(
        artifacts_dir=artifacts_dir,
        storage=storage,
        semantic_config=pop.semantic_analysis,
        profiling_config=pop.profiling,
        clustering_config=pop.clustering,
        semantic_view_config=pop.semantic_view_loader,
        data_backend=data_backend_instance,
        model_filter=pop.semantic_analysis.model_filter,
        export_cache_override=export_cache,
        incremental=not force_full,
        verbose=verbose,
        key_lineage_config=pop.key_lineage,
    )
    click.echo("\n✅ Load complete!")

@main.command("reanalyze-semantics")
@click.argument("artifacts_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
@click.option("--ingest-config", type=click.Path(exists=True, path_type=Path), default=None, help="Path to ingest config YAML file (auto-discovers if not provided)")
@click.option("--skip-clustering", is_flag=True, help="Skip join graph clustering (faster)")
@click.option("--export-cache/--no-export-cache", default=None, help="Override export_cache config setting")
@click.option("--verbose", is_flag=True, help="Enable verbose output")
def reanalyze_semantics(
    artifacts_dir: Path,
    ingest_config: Path | None,
    skip_clustering: bool,
    export_cache: bool | None,
    verbose: bool,
) -> None:
    """Re-run semantic analysis without reloading dbt graph data.

    This command is optimized for fast iteration on semantic analysis configuration.
    It loads dbt artifacts to get model metadata and compiled SQL, but skips
    writing dbt nodes to the graph storage (assumes they already exist from a
    previous load-dbt-full run).

    This command:
    1. Loads dbt artifacts (fast - ~2 seconds)
    2. Skips writing dbt nodes to graph (avoids slow step)
    3. Runs semantic SQL analysis on models
    4. [Optional] Runs join graph clustering (default: enabled, use --skip-clustering to disable)

    Skipped operations:
    - Writing dbt nodes/edges to graph storage (slow)
    - Loading semantic views from warehouse
    - Profiling table data

    Example:
        # Re-analyze with clustering
        uv run lineage reanalyze-semantics target/ --verbose

        # Re-analyze without clustering (fastest)
        uv run lineage reanalyze-semantics target/ --skip-clustering --verbose
    """
    load_env_file()
    # Enable logging if verbose
    if verbose:
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        logging.getLogger("httpcore").setLevel(logging.WARNING)
        logging.getLogger("httpx").setLevel(logging.WARNING)
        logging.getLogger("google_genai.models").setLevel(logging.WARNING)
        logging.getLogger("openai").setLevel(logging.INFO)

    # Auto-discover or use provided ingest config
    if ingest_config is None:
        ingest_config = _discover_ingest_config(artifacts_dir, verbose=verbose)

    cfg = load_ingest_config(ingest_config)
    storage = create_storage_for_cli(cfg.lineage)

    # Get population settings
    pop = cfg.population

    # Create data backend (needed for semantic analysis dialect detection)
    data_backend_instance = create_data_backend_for_cli(cfg.data, read_only=True)

    if verbose:
        click.echo(f"📁  Lineage backend: {cfg.lineage.backend}")
        click.echo(f"📊 Data backend: {cfg.data.backend}")
        click.echo(f"🔧 Semantic analysis: {pop.semantic_analysis.enabled}")
        click.echo(f"🔧 Clustering: {'SKIP' if skip_clustering else pop.clustering.enabled}")
        models = pop.semantic_analysis.models
        click.echo(f"🤖 Analysis models: micro={models.micro.model_name}, small={models.small.model_name}, medium={models.medium.model_name}")

    # Import integration here to avoid circular imports
    from lineage.integration import LineageIntegration

    integration = LineageIntegration(
        storage=storage,
        semantic_config=pop.semantic_analysis,
        profiling_config=pop.profiling,
        clustering_config=pop.clustering,
        semantic_view_config=pop.semantic_view_loader,
        data_backend=data_backend_instance,
    )

    integration.reanalyze_semantics_only(
        artifacts_dir=artifacts_dir,
        model_filter=pop.semantic_analysis.model_filter,
        skip_clustering=skip_clustering,
        export_cache_override=export_cache,
        verbose=verbose,
    )

    click.echo("\n✅ Re-analysis complete!")


@main.command("run-clustering")
@click.option("--ingest-config", type=click.Path(exists=True, path_type=Path), default=None, help="Path to ingest config YAML file")
@click.option("--verbose", is_flag=True, help="Enable verbose output")
def run_clustering(
    ingest_config: Path | None,
    verbose: bool,
) -> None:
    """Run join graph clustering only.

    This command runs only the join graph clustering step, useful for
    experimenting with clustering parameters without re-running semantic analysis.

    Requires:
    - dbt data already loaded in graph storage
    - Semantic analysis with join analysis already completed

    Example:
        uv run lineage run-clustering --verbose
    """
    load_env_file()
    # Enable logging if verbose
    if verbose:
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

    # Load config (no auto-discovery since we don't have artifacts_dir)
    if ingest_config is None:
        # Fall back to default config in typedef_data_intelligence root
        default_config = Path(__file__).parent.parent.parent / "config.ingest.default.yml"
        if default_config.exists():
            ingest_config = default_config
        else:
            raise click.ClickException(
                "No ingest config found. Please specify --ingest-config or create config.ingest.default.yml"
            )

    cfg = load_ingest_config(ingest_config)
    storage = create_storage_for_cli(cfg.lineage)

    # Get population settings
    pop = cfg.population

    # Create data backend (needed for clustering)
    data_backend_instance = create_data_backend_for_cli(cfg.data, read_only=True)

    if verbose:
        click.echo(f"📁  Lineage backend: {cfg.lineage.backend}")
        click.echo(f"🔧 Clustering: {pop.clustering.enabled}")

    if not pop.clustering.enabled:
        click.echo("⚠️  Clustering is disabled in configuration. Aborting.")
        raise click.Abort()

    # Import integration here to avoid circular imports
    from lineage.integration import LineageIntegration

    integration = LineageIntegration(
        storage=storage,
        semantic_config=pop.semantic_analysis,
        profiling_config=pop.profiling,
        clustering_config=pop.clustering,
        semantic_view_config=pop.semantic_view_loader,
        data_backend=data_backend_instance,
    )

    integration.run_clustering_only(verbose=verbose)

    click.echo("\n✅ Clustering complete!")


@main.command("refresh-overview")
@click.option("--ingest-config", type=click.Path(exists=True, path_type=Path), default=None, help="Path to ingest config YAML file")
@click.option("--verbose", is_flag=True, help="Enable verbose output")
def refresh_overview(
    ingest_config: Path | None,
    verbose: bool,
) -> None:
    """Recompute the project overview from current graph data.

    This command regenerates the ProjectOverview node without re-running
    semantic analysis or clustering. Useful after manual graph edits or
    to pick up schema/query fixes.

    Example:
        uv run lineage refresh-overview --verbose
    """
    load_env_file()
    if verbose:
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

    if ingest_config is None:
        default_config = Path(__file__).parent.parent.parent / "config.ingest.default.yml"
        if default_config.exists():
            ingest_config = default_config
        else:
            raise click.ClickException(
                "No ingest config found. Please specify --ingest-config or create config.ingest.default.yml"
            )

    cfg = load_ingest_config(ingest_config)
    storage = create_storage_for_cli(cfg.lineage)
    pop = cfg.population

    if verbose:
        click.echo(f"📁  Lineage backend: {cfg.lineage.backend}")

    from lineage.integration import LineageIntegration

    integration = LineageIntegration(
        storage=storage,
        semantic_config=pop.semantic_analysis,
        profiling_config=pop.profiling,
        clustering_config=pop.clustering,
        semantic_view_config=pop.semantic_view_loader,
    )

    integration.refresh_project_overview(verbose=verbose)

    click.echo("\n✅ Project overview refreshed!")


@main.command("build-key-lineage")
@click.option("--ingest-config", type=click.Path(exists=True, path_type=Path), default=None, help="Path to ingest config YAML file")
@click.option("--dialect", default=None, help="SQL dialect override (default: from config or 'snowflake')")
@click.option("--overrides", type=click.Path(exists=True, path_type=Path), default=None, help="Path to key_lineage_overrides.yaml")
@click.option("--verbose", is_flag=True, help="Enable verbose output")
def build_key_lineage(
    ingest_config: Path | None,
    dialect: str | None,
    overrides: Path | None,
    verbose: bool,
) -> None:
    """Build key lineage overlay (PK/FK inference via IdentityClasses).

    This command runs the key lineage overlay build, which:
    1. Classifies DERIVES_FROM edges as identity-preserving or breaking
    2. Computes IdentityClass connected components
    3. Collects PK signals (dbt tests, profiling, structural, naming)
    4. Scores PK candidates and propagates within IdentityClasses
    5. Infers and emits FK edges

    Requires:
    - dbt data already loaded in graph storage
    - Semantic analysis with column lineage already completed

    Example:
        uv run lineage build-key-lineage --verbose
    """
    load_env_file()
    if verbose:
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

    # Load config
    if ingest_config is None:
        default_config = Path(__file__).parent.parent.parent / "config.ingest.default.yml"
        if default_config.exists():
            ingest_config = default_config
        else:
            raise click.ClickException(
                "No ingest config found. Please specify --ingest-config or create config.ingest.default.yml"
            )

    cfg = load_ingest_config(ingest_config)
    storage = create_storage_for_cli(cfg.lineage)

    pop = cfg.population
    kl_config = pop.key_lineage

    if not kl_config.enabled:
        click.echo("Key lineage is disabled in configuration. Aborting.")
        raise click.Abort()

    # Resolve dialect and overrides (CLI args override config)
    effective_dialect = dialect or kl_config.dialect
    effective_overrides = overrides or (
        Path(kl_config.overrides_path) if kl_config.overrides_path else None
    )

    if verbose:
        click.echo(f"Lineage backend: {cfg.lineage.backend}")
        click.echo(f"SQL dialect: {effective_dialect}")
        if effective_overrides:
            click.echo(f"Overrides: {effective_overrides}")

    from lineage.ingest.static_loaders.key_lineage import KeyLineageOrchestrator

    orchestrator = KeyLineageOrchestrator(storage)
    result = orchestrator.build(
        dialect=effective_dialect,
        overrides_path=effective_overrides,
    )

    click.echo(
        f"\nKey lineage complete in {result.elapsed_seconds:.1f}s:\n"
        f"  Identity classes: {result.identity_class_count}\n"
        f"  PK candidates:    {result.pk_candidate_count}\n"
        f"  FK edges:         {result.fk_edge_count}\n"
        f"  Composite FKs:    {result.composite_fk_count}"
    )


def _build_sf_client(
    auth_mode: Optional[str],
    instance_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    security_token: Optional[str],
    client_id: Optional[str],
    client_secret: Optional[str],
    private_key_path: Optional[str],
    login_url: str,
    sf_org_key: str,
) -> SalesforceMetadataClient:
    """Build a ``SalesforceMetadataClient`` from CLI options.

    Auto-detects auth mode when ``auth_mode`` is ``None``.
    """
    # Auto-detect when --auth is omitted
    if auth_mode is None:
        if all(v is not None for v in (instance_url, username, password, security_token)):
            auth_mode = "password"
        elif client_id and client_secret:
            auth_mode = "client-credentials"
        elif client_id and private_key_path and username:
            auth_mode = "jwt"
        elif client_id:
            auth_mode = "oauth"
        else:
            raise click.ClickException(
                "Cannot determine auth mode. Provide one of:\n"
                "  --auth password   (with --instance-url, --username, --password, --security-token)\n"
                "  --auth oauth      (with --client-id; run sf-login first)\n"
                "  --auth device     (with --client-id; interactive device flow)\n"
                "  --auth client-credentials (with --client-id, --client-secret)\n"
                "  --auth jwt        (with --client-id, --username, --private-key-path)"
            )

    if auth_mode == "password":
        if not all(v is not None for v in (instance_url, username, password, security_token)):
            raise click.ClickException(
                "Password auth requires --instance-url, --username, --password, --security-token"
            )
        return SalesforceMetadataClient(
            instance_url=instance_url,
            username=username,
            password=password,
            security_token=security_token,
        )

    if auth_mode == "oauth":
        if not client_id:
            raise click.ClickException("OAuth auth requires --client-id")
        from lineage.ingest.static_loaders.salesforce.auth.oauth_pkce import (
            OAuthPKCEAuth,
        )

        auth = OAuthPKCEAuth(
            client_id=client_id,
            login_url=login_url,
            org_key=sf_org_key,
        )
        return SalesforceMetadataClient(auth=auth)

    if auth_mode == "device":
        if not client_id:
            raise click.ClickException("Device flow auth requires --client-id")
        from lineage.ingest.static_loaders.salesforce.auth.device_flow import (
            OAuthDeviceFlowAuth,
        )

        auth = OAuthDeviceFlowAuth(
            client_id=client_id,
            login_url=login_url,
            org_key=sf_org_key,
        )
        return SalesforceMetadataClient(auth=auth)

    if auth_mode == "client-credentials":
        if not client_id or not client_secret:
            raise click.ClickException(
                "Client credentials auth requires --client-id and --client-secret"
            )
        from lineage.ingest.static_loaders.salesforce.auth.client_creds import (
            ClientCredentialsAuth,
        )

        auth = ClientCredentialsAuth(
            client_id=client_id,
            client_secret=client_secret,
            login_url=login_url,
        )
        return SalesforceMetadataClient(auth=auth)

    if auth_mode == "jwt":
        if not all(v is not None for v in (client_id, username, private_key_path)):
            raise click.ClickException(
                "JWT auth requires --client-id, --username, and --private-key-path"
            )
        from lineage.ingest.static_loaders.salesforce.auth.jwt_bearer import (
            JWTBearerAuth,
        )

        auth = JWTBearerAuth(
            client_id=client_id,
            username=username,
            private_key_path=Path(private_key_path),
            login_url=login_url,
        )
        return SalesforceMetadataClient(auth=auth)

    raise click.ClickException(f"Unknown auth mode: {auth_mode}")


@main.command("sf-login")
@click.option("--client-id", envvar="SF_CLIENT_ID", required=True, help="Connected App consumer key")
@click.option("--login-url", envvar="SF_LOGIN_URL", default="https://login.salesforce.com", help="Salesforce login URL (use https://test.salesforce.com for sandboxes)")
@click.option("--port", default=8443, type=int, help="Local callback port for PKCE (default: 8443)")
@click.option("--org-key", default="default", help="Token store key for multi-org support")
@click.option("--device", is_flag=True, default=False, help="Use Device Flow instead of PKCE (no local server needed)")
def sf_login(
    client_id: str,
    login_url: str,
    port: int,
    org_key: str,
    device: bool,
) -> None:
    r"""Authenticate with Salesforce via OAuth (browser login).

    By default uses PKCE flow (local callback server). Use ``--device``
    for the Device Flow (no local server — works over SSH/headless).

    \b
    PKCE (default):
        uv run lineage sf-login --client-id 3MVG9...

    Device Flow:
        uv run lineage sf-login --client-id 3MVG9... --device
    """
    if device:
        from lineage.ingest.static_loaders.salesforce.auth.device_flow import (
            OAuthDeviceFlowAuth,
        )

        auth = OAuthDeviceFlowAuth(
            client_id=client_id,
            login_url=login_url,
            org_key=org_key,
        )
    else:
        from lineage.ingest.static_loaders.salesforce.auth.oauth_pkce import (
            OAuthPKCEAuth,
        )

        auth = OAuthPKCEAuth(
            client_id=client_id,
            login_url=login_url,
            callback_port=port,
            org_key=org_key,
        )

    creds = auth.authenticate()
    method = "device flow" if device else "OAuth PKCE"
    click.echo(f"Authenticated to {creds.instance_url} via {method}")
    click.echo("Tokens stored securely. Run 'just sf-load' to load metadata.")


@main.command("load-salesforce")
@click.option("--auth", "auth_mode", type=click.Choice(["password", "oauth", "device", "client-credentials", "jwt"]), default=None, help="Authentication mode (auto-detected if omitted)")
@click.option("--instance-url", envvar="SF_INSTANCE_URL", default=None, help="Salesforce instance URL (password auth)")
@click.option("--username", envvar="SF_USERNAME", default=None, help="Salesforce username (password/jwt auth)")
@click.option("--password", envvar="SF_PASSWORD", default=None, help="Salesforce password (password auth)")
@click.option("--security-token", envvar="SF_SECURITY_TOKEN", default=None, help="Salesforce security token (password auth)")
@click.option("--client-id", envvar="SF_CLIENT_ID", default=None, help="Connected App consumer key (oauth/client-creds/jwt)")
@click.option("--client-secret", envvar="SF_CLIENT_SECRET", default=None, help="Connected App consumer secret (client-creds)")
@click.option("--private-key-path", envvar="SF_PRIVATE_KEY_PATH", default=None, help="Path to PEM private key (jwt)")
@click.option("--login-url", envvar="SF_LOGIN_URL", default="https://login.salesforce.com", help="Salesforce login URL")
@click.option("--org-key", default=None, help="Stable alias for the org (auto-generated if omitted)")
@click.option("--sobject-filter", default=None, help="Comma-separated SObject API names to limit ingestion")
@click.option("--no-reports", is_flag=True, default=False, help="Skip report ingestion")
@click.option("--no-dashboards", is_flag=True, default=False, help="Skip dashboard ingestion")
@click.option("--max-workers", default=10, type=int, help="Max concurrent describe calls (default: 10)")
@click.option("--stitch/--no-stitch", default=True, help="Run cross-domain stitching to dbt graph (default: stitch)")
@click.option("--stitch-llm/--no-stitch-llm", default=True, help="Use LLM for unmatched assets during stitching")
@click.option("--ingest-config", type=click.Path(exists=True, path_type=Path), default=None, help="Path to ingest config YAML file")
@click.option("--verbose", is_flag=True, help="Enable verbose output")
def load_salesforce(
    auth_mode: Optional[str],
    instance_url: Optional[str],
    username: Optional[str],
    password: Optional[str],
    security_token: Optional[str],
    client_id: Optional[str],
    client_secret: Optional[str],
    private_key_path: Optional[str],
    login_url: str,
    org_key: Optional[str],
    sobject_filter: Optional[str],
    no_reports: bool,
    no_dashboards: bool,
    max_workers: int,
    stitch: bool,
    stitch_llm: bool,
    ingest_config: Optional[Path],
    verbose: bool,
) -> None:
    r"""Load Salesforce org/object/field/report/dashboard metadata into the lineage graph.

    Fetches metadata from the Salesforce REST API and creates Salesforce
    nodes and internal edges.  Optionally stitches SF assets to existing
    dbt source/column nodes using deterministic heuristics and LLM-assisted
    matching.

    Supports multiple authentication modes (auto-detected when --auth is omitted):

    \b
      password:           --instance-url, --username, --password, --security-token
      oauth:              --client-id (run sf-login first to cache tokens)
      device:             --client-id (run sf-login --device first; works headless/SSH)
      client-credentials: --client-id, --client-secret
      jwt:                --client-id, --username, --private-key-path

    All credentials can also be supplied via environment variables:
        SF_INSTANCE_URL, SF_USERNAME, SF_PASSWORD, SF_SECURITY_TOKEN,
        SF_CLIENT_ID, SF_CLIENT_SECRET, SF_PRIVATE_KEY_PATH, SF_LOGIN_URL

    Example:
        uv run lineage load-salesforce --verbose
        uv run lineage load-salesforce --auth oauth --client-id 3MVG9... --verbose
        uv run lineage load-salesforce --sobject-filter Account,Opportunity --no-reports
    """
    load_env_file()
    if verbose:
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S',
        )

    # Load config for storage backend
    if ingest_config is None:
        default_config = Path(__file__).parent.parent.parent / "config.ingest.yml"
        if default_config.exists():
            ingest_config = default_config
        else:
            raise click.ClickException(
                "No ingest config found. Please specify --ingest-config."
            )

    cfg = load_ingest_config(ingest_config)
    storage = create_storage_for_cli(cfg.lineage)

    from lineage.ingest.static_loaders.salesforce.loader import SalesforceLoader

    client = _build_sf_client(
        auth_mode=auth_mode,
        instance_url=instance_url,
        username=username,
        password=password,
        security_token=security_token,
        client_id=client_id,
        client_secret=client_secret,
        private_key_path=private_key_path,
        login_url=login_url,
        sf_org_key=org_key or "default",
    )

    parsed_filter = [s.strip() for s in sobject_filter.split(",")] if sobject_filter else None

    sf_cfg = cfg.population.salesforce
    loader = SalesforceLoader(
        client=client,
        storage=storage,
        org_key=org_key,
        sobject_filter=parsed_filter,
        sobject_exclude_patterns=sf_cfg.sobject_exclude_patterns if not parsed_filter else [],
        sobject_exclude=sf_cfg.sobject_exclude if not parsed_filter else [],
        include_reports=not no_reports,
        include_dashboards=not no_dashboards,
        verbose=verbose,
        max_workers=max_workers,
    )

    if verbose:
        mode_label = auth_mode or "auto-detected"
        click.echo(f"Connecting to Salesforce (auth: {mode_label}, max_workers: {max_workers})")
    asyncio.run(loader.load())

    if stitch:
        from lineage.ingest.static_loaders.salesforce.stitcher import SalesforceStitcher

        stitcher = SalesforceStitcher(
            storage=storage,
            org_key=loader.org_key,
            use_llm=stitch_llm,
            analysis_models=cfg.population.semantic_analysis.models if stitch_llm else None,
            verbose=verbose,
        )
        counts = stitcher.stitch()
        if verbose:
            click.echo(f"Stitching results: {counts}")

    click.echo("Salesforce metadata loaded successfully!")


@main.command("load-reports")
@click.option("--system", type=click.Choice(["salesforce", "looker", "tableau", "powerbi"]), default=None, help="Load only from specific system")
@click.option("--ingest-config", type=click.Path(exists=True, path_type=Path), default=None, help="Path to ingest config YAML file")
@click.option("--verbose", is_flag=True, help="Enable verbose output")
def load_reports(
    system: Optional[str],
    ingest_config: Optional[Path],
    verbose: bool,
) -> None:
    r"""Load reports from the lineage graph into the Generic Report Schema.

    Reads report metadata already ingested into the graph (e.g. via ``load-salesforce``)
    and transforms them into canonical Report, ReportIR, and ReportIRField nodes.

    Requires prior metadata ingestion — this command does not fetch from BI platform
    APIs directly.

    Configuration is read from the report_loaders section of ingest config:

    \b
      population:
        report_loaders:
          sources:
            - system: salesforce
              enabled: true

    Example:
        uv run lineage load-reports --verbose
        uv run lineage load-reports --system salesforce --verbose
    """
    load_env_file()
    if verbose:
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S',
        )

    # Load config for storage backend
    if ingest_config is None:
        default_config = Path(__file__).parent.parent.parent / "config.ingest.yml"
        if default_config.exists():
            ingest_config = default_config
        else:
            raise click.ClickException(
                "No ingest config found. Please specify --ingest-config."
            )

    cfg = load_ingest_config(ingest_config)
    storage = create_storage_for_cli(cfg.lineage)

    # Get report loaders config
    loaders_config = cfg.population.report_loaders
    if loaders_config is None:
        click.echo("No report loaders configured in ingest config", err=True)
        click.echo("Add a 'report_loaders' section under 'population' in your ingest config.", err=True)
        raise click.Abort()

    if not loaders_config.sources:
        click.echo("No report sources configured in report_loaders.sources", err=True)
        raise click.Abort()

    from lineage.ingest.static_loaders.reports import ReportLoaderFactory

    loaded_any = False
    for source in loaders_config.sources:
        # Skip if system filter is specified and doesn't match
        if system and source.system != system:
            continue
        # Skip if disabled
        if not source.enabled:
            if verbose:
                click.echo(f"[{source.system}] Skipped (disabled)")
            continue

        if verbose:
            click.echo(f"[{source.system}] Loading reports...")

        try:
            loader = ReportLoaderFactory.create(source)
            result = asyncio.run(loader.load(storage))

            click.echo(
                f"[{source.system}] Loaded {result.reports_created} reports, "
                f"{result.field_nodes_created} fields"
            )
            if result.errors:
                for err in result.errors[:5]:
                    click.echo(f"  Error: {err}", err=True)
                if len(result.errors) > 5:
                    click.echo(f"  ... and {len(result.errors) - 5} more errors", err=True)

            loaded_any = True
        except ValueError as e:
            click.echo(f"[{source.system}] Error: {e}", err=True)
        except Exception as e:
            click.echo(f"[{source.system}] Failed: {e}", err=True)
            if verbose:
                import traceback
                traceback.print_exc()

    if not loaded_any:
        click.echo("No reports loaded. Check your configuration.", err=True)
        raise click.Abort()

    click.echo("Report loading complete!")


@main.command("create-snowflake-semantic-views")
@click.argument("artifacts_dir", type=click.Path(exists=True, file_okay=False, path_type=Path))
def create_snowflake_semantic_views(artifacts_dir: Path) -> None:
    """Create Snowflake semantic views."""
    semantic_views_dir = artifacts_dir / "semantic_views"
    load_env_file()
    for file in semantic_views_dir.glob("*.sql"):
        click.echo(f"Creating Snowflake semantic view from {file}")
        execute_sql_file(file)
    click.echo(f"Created Snowflake semantic views from {semantic_views_dir}")


@main.command("serve")
@click.option("--config", type=click.Path(exists=True, path_type=Path), required=True, help="Path to agent config YAML file")
@click.option("--host", default="0.0.0.0", help="Host to bind to (default: 0.0.0.0)")
@click.option("--port", default=8000, type=int, help="Port to bind to (default: 8000)")
@click.option("--reload", is_flag=True, help="Enable auto-reload on code changes (development only)")
def serve(config: Path, host: str, port: int, reload: bool) -> None:
    """Start the backend API server."""
    # Set the config path as environment variable (app expects UNIFIED_CONFIG)
    os.environ["UNIFIED_CONFIG"] = str(config.absolute())

    click.echo(f"🚀 Starting backend API server on {host}:{port}")
    click.echo(f"📄 Using config: {config}")
    if reload:
        click.echo("🔄 Auto-reload enabled")

    # Import the app after setting env var
    from lineage.api.pydantic import app

    uvicorn.run(
        app,
        host=host,
        port=port,
        log_level="info",
        access_log=True,
        reload=reload,
    )


def __main__():
    main()

if __name__ == "__main__":
    __main__()