"""List all ephemeral models from a dbt manifest.json.

Usage:
    uv run lineage-list-ephemerals <path-to-target-dir>
    uv run lineage-list-ephemerals  # uses default from env vars
"""

import json
import os
import sys
from pathlib import Path


def find_target_path() -> Path:
    """Resolve target path from CLI arg or environment variables."""
    if len(sys.argv) > 1:
        return Path(sys.argv[1])

    local_path = os.environ.get("GITHUB_DBT_PROJECT_LOCAL_PATH", "")
    repo_name = os.environ.get("GITHUB_DBT_PROJECT_REPO_NAME", "")
    project_root = os.environ.get("DBT_PROJECT_ROOT", "")

    if local_path and repo_name and project_root:
        return Path(local_path) / repo_name / project_root / "target"

    print("Usage: lineage-list-ephemerals <path-to-target-dir>")
    print("   Or set GITHUB_DBT_PROJECT_LOCAL_PATH, GITHUB_DBT_PROJECT_REPO_NAME, DBT_PROJECT_ROOT")
    sys.exit(1)


def main() -> None:
    """List all ephemeral models from dbt manifest."""
    target_path = find_target_path()
    manifest_path = target_path / "manifest.json"

    if not manifest_path.exists():
        print(f"manifest.json not found at {manifest_path}")
        sys.exit(1)

    with open(manifest_path) as f:
        manifest = json.load(f)

    nodes = manifest.get("nodes", {})

    ephemerals = []
    for uid, node in nodes.items():
        if node.get("resource_type") != "model":
            continue
        config = node.get("config", {})
        materialized = config.get("materialized", "")
        if materialized == "ephemeral":
            ephemerals.append({
                "unique_id": uid,
                "name": node.get("name", ""),
                "package": node.get("package_name", ""),
                "path": node.get("original_file_path", ""),
                "depends_on": [
                    d for d in node.get("depends_on", {}).get("nodes", [])
                ],
                "columns": list(node.get("columns", {}).keys()),
                "has_compiled_sql": bool(node.get("compiled_code") or node.get("compiled_sql")),
            })

    ephemerals.sort(key=lambda m: m["unique_id"])

    print(f"\nEphemeral models: {len(ephemerals)}")
    print(f"Total models: {sum(1 for n in nodes.values() if n.get('resource_type') == 'model')}")
    print("=" * 80)

    for i, m in enumerate(ephemerals, 1):
        print(f"\n{i:3d}. {m['unique_id']}")
        print(f"     name: {m['name']}")
        print(f"     path: {m['path']}")
        print(f"     package: {m['package']}")
        print(f"     depends_on: {len(m['depends_on'])} nodes")
        for dep in m["depends_on"]:
            print(f"       - {dep}")
        if m["columns"]:
            print(f"     documented columns: {', '.join(m['columns'])}")
        else:
            print("     documented columns: (none)")
        print(f"     has compiled SQL: {m['has_compiled_sql']}")

    # Summary by package
    packages: dict[str, int] = {}
    for m in ephemerals:
        pkg = m["package"]
        packages[pkg] = packages.get(pkg, 0) + 1

    print("\n" + "=" * 80)
    print("By package:")
    for pkg, count in sorted(packages.items(), key=lambda x: -x[1]):
        print(f"  {pkg}: {count}")


if __name__ == "__main__":
    main()
