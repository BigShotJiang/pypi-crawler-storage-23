"""Clustering evaluation devtool.

Runs clustering with configurable parameters and computes quality metrics.
Supports parameter sweeps, historical comparison, and auto-saving results.

Usage:
    # Run evaluation with current config
    uv run lineage-eval-clustering --verbose

    # Run parameter sweep
    uv run lineage-eval-clustering --sweep

    # Compare specific runs
    uv run lineage-eval-clustering --compare run_20260123_123456.json run_20260123_134500.json

    # View run history
    uv run lineage-eval-clustering --history
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import logging
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import networkx as nx

from lineage.backends.lineage.factory import create_storage
from lineage.devtools.clustering_metrics import (
    ClusteringMetrics,
    compare_partitions,
    compute_all_metrics,
)
from lineage.ingest.config import IngestConfig
from lineage.ingest.static_loaders.clustering.algorithms import cluster_models
from lineage.ingest.static_loaders.clustering.enrichment import ModelEnricher
from lineage.utils.env import load_env_file

logger = logging.getLogger(__name__)

# Default workspace directory
EVAL_DIR = Path(".lineage_workspace/clustering_eval")
HISTORY_FILE = "history.json"


# Pre-defined sweep configurations (weight variations only, all use Louvain)
SWEEP_CONFIGS = [
    # Baseline: typical defaults
    {
        "name": "baseline",
        "join_weight": 2.0,
        "lineage_weight": 1.0,
        "shared_dependency_weight": 0.5,
        "column_lineage_weight": 0.1,
        "domain_similarity_weight": 0.0,
    },
    # Join-dominant: trust explicit SQL joins most
    {
        "name": "join_dominant",
        "join_weight": 5.0,
        "lineage_weight": 0.5,
        "shared_dependency_weight": 0.2,
        "column_lineage_weight": 0.0,
        "domain_similarity_weight": 0.0,
    },
    # Lineage-dominant: trust dbt DAG structure
    {
        "name": "lineage_dominant",
        "join_weight": 1.0,
        "lineage_weight": 3.0,
        "shared_dependency_weight": 1.0,
        "column_lineage_weight": 0.0,
        "domain_similarity_weight": 0.0,
    },
    # Equal weights
    {
        "name": "equal_weights",
        "join_weight": 1.0,
        "lineage_weight": 1.0,
        "shared_dependency_weight": 1.0,
        "column_lineage_weight": 1.0,
        "domain_similarity_weight": 0.3,
    },
    # Domain-enhanced: adds semantic domain similarity
    {
        "name": "domain_enhanced",
        "join_weight": 2.0,
        "lineage_weight": 1.0,
        "shared_dependency_weight": 0.5,
        "column_lineage_weight": 0.1,
        "domain_similarity_weight": 0.3,
    },
]


def _load_config(config_path: Optional[Path]) -> IngestConfig:
    """Load ingest config, searching for config.ingest.yml if not provided."""
    search_paths = [
        config_path,
        Path("config.ingest.yml"),
        Path("typedef_data_intelligence/config.ingest.yml"),
    ]

    for path in search_paths:
        if path and path.exists():
            return IngestConfig.from_yaml(path)

    raise FileNotFoundError(
        "Config file not found. Provide --config or place config.ingest.yml in current directory."
    )


def _compute_config_hash(config: Dict[str, Any]) -> str:
    """Compute a short hash for a config dict."""
    config_str = json.dumps(config, sort_keys=True)
    return hashlib.sha256(config_str.encode()).hexdigest()[:8]


def _ensure_eval_dir() -> Path:
    """Ensure evaluation results directory exists."""
    EVAL_DIR.mkdir(parents=True, exist_ok=True)
    return EVAL_DIR


def _load_history() -> List[Dict[str, Any]]:
    """Load run history from history file."""
    history_path = EVAL_DIR / HISTORY_FILE
    if history_path.exists():
        try:
            return json.loads(history_path.read_text())
        except Exception:
            return []
    return []


def _save_history(history: List[Dict[str, Any]]) -> None:
    """Save run history to history file."""
    _ensure_eval_dir()
    history_path = EVAL_DIR / HISTORY_FILE
    history_path.write_text(json.dumps(history, indent=2))


def _save_run_result(result: Dict[str, Any]) -> Path:
    """Save a run result to a timestamped file and update history."""
    _ensure_eval_dir()

    # Generate filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    config_hash = result.get("config_hash", "unknown")
    filename = f"run_{timestamp}_{config_hash}.json"
    filepath = EVAL_DIR / filename

    # Save result
    filepath.write_text(json.dumps(result, indent=2))

    # Update history
    history = _load_history()
    history.append({
        "timestamp": result["timestamp"],
        "filename": filename,
        "config_name": result.get("config_name", "custom"),
        "config_hash": config_hash,
        "cluster_count": result["metrics"]["cluster_count"],
        "modularity": result["metrics"]["modularity"],
        "coverage": result["metrics"]["coverage"],
    })
    _save_history(history)

    return filepath


def _load_run_result(filename: str) -> Optional[Dict[str, Any]]:
    """Load a run result from file."""
    filepath = EVAL_DIR / filename
    if filepath.exists():
        return json.loads(filepath.read_text())
    return None


def _get_latest_run() -> Optional[Dict[str, Any]]:
    """Get the most recent run result."""
    history = _load_history()
    if not history:
        return None

    latest = history[-1]
    return _load_run_result(latest["filename"])


def _build_weighted_graph(
    model_ids: List[str],
    join_edges: List[Dict],
    lineage_edges: List[Dict],
    shared_edges: List[Dict],
    column_edges: List[Dict],
    domain_edges: List[Dict],
    join_weight: float,
    lineage_weight: float,
    shared_dependency_weight: float,
    column_lineage_weight: float,
    domain_similarity_weight: float,
) -> nx.Graph:
    """Build a weighted NetworkX graph from edge lists."""
    G = nx.Graph()
    for model_id in model_ids:
        G.add_node(model_id)

    def add_edges(edges: List[Dict], weight_multiplier: float) -> None:
        if weight_multiplier <= 0:
            return
        for edge in edges:
            u, v = edge["source"], edge["target"]
            if u not in G or v not in G:
                continue
            w = float(edge.get("weight", 1.0)) * weight_multiplier
            if G.has_edge(u, v):
                G[u][v]["weight"] += w
            else:
                G.add_edge(u, v, weight=w)

    add_edges(join_edges, join_weight)
    add_edges(lineage_edges, lineage_weight)
    add_edges(shared_edges, shared_dependency_weight)
    add_edges(column_edges, column_lineage_weight)
    add_edges(domain_edges, domain_similarity_weight)

    return G


async def _run_clustering_with_config(
    storage,
    config_params: Dict[str, Any],
    verbose: bool = False,
) -> Dict[str, Any]:
    """Run clustering with specific parameters and compute metrics.

    Args:
        storage: LineageStorage instance
        config_params: Dict with keys: join_weight, lineage_weight,
            shared_dependency_weight, column_lineage_weight
        verbose: Enable verbose output

    Returns:
        Dict with clusters, enrichment, metrics, and config
    """
    join_weight = config_params.get("join_weight", 2.0)
    lineage_weight = config_params.get("lineage_weight", 1.0)
    shared_dependency_weight = config_params.get("shared_dependency_weight", 0.5)
    column_lineage_weight = config_params.get("column_lineage_weight", 0.1)
    domain_similarity_weight = config_params.get("domain_similarity_weight", 0.0)
    resolution = config_params.get("resolution", 1.0)

    if verbose:
        logger.info(f"Running Louvain clustering with: "
                    f"join={join_weight}, lineage={lineage_weight}, "
                    f"shared_dep={shared_dependency_weight}, col={column_lineage_weight}, "
                    f"domain_sim={domain_similarity_weight}")

    # 1. Extract edges from graph
    join_edges = storage.get_join_edges()
    lineage_edges = storage.get_lineage_edges()
    shared_edges = storage.get_shared_dependency_edges()
    column_edges = storage.get_column_lineage_edges()

    # 1.5 Semantic edges (domain similarity)
    domain_edges: List[Dict] = []
    if domain_similarity_weight > 0:
        domain_edges = storage.get_domain_similarity_edges()

    # 2. Get models
    models = storage.get_all_models_with_analysis()
    model_ids = [m["model_id"] for m in models]

    if not model_ids:
        logger.error("No models found in graph")
        return {
            "clusters": {},
            "enrichment": {},
            "metrics": asdict(ClusteringMetrics()),
            "config": config_params,
        }

    # 3. Build weighted graph
    G = _build_weighted_graph(
        model_ids,
        join_edges,
        lineage_edges,
        shared_edges,
        column_edges,
        domain_edges,
        join_weight,
        lineage_weight,
        shared_dependency_weight,
        column_lineage_weight,
        domain_similarity_weight,
    )

    if verbose:
        logger.info(f"Built graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")

    # 4. Run Louvain clustering
    weighted_edges_list = [
        (u, v, float(d["weight"])) for u, v, d in G.edges(data=True)
    ]

    clusters = cluster_models(
        model_ids,
        weighted_edges_list,
        resolution=resolution,
    )

    if verbose:
        logger.info(f"Found {len(clusters)} clusters")

    # 5. Enrich models
    enricher = ModelEnricher(storage)
    enrichment = await enricher.enrich_all_models(models=models)

    # Add weighted degree to enrichment
    weighted_degree = dict(G.degree(weight="weight"))
    for model_id, data in enrichment.items():
        data.weighted_degree = weighted_degree.get(model_id, 0.0)

    # 6. Compute metrics
    metrics = compute_all_metrics(G, clusters, enrichment, include_details=verbose)

    return {
        "clusters": clusters,
        "enrichment": enrichment,
        "graph": G,
        "metrics": metrics,
        "config": config_params,
    }


def _format_metrics_table(results: List[Dict[str, Any]], show_details: bool = False) -> str:
    """Format metrics as a console table."""
    if not results:
        return "No results to display."

    # Header
    lines = []
    header = (
        f"{'Config':<18} {'Clusters':>8} {'Modular.':>8} {'Coverage':>8} "
        f"{'Singltn':>7} {'DomPurity':>9} {'RoleSep':>7}"
    )
    lines.append(header)
    lines.append("-" * len(header))

    for result in results:
        config_name = result.get("config_name", "custom")[:17]
        m = result["metrics"]

        # Handle both dict and ClusteringMetrics
        if isinstance(m, ClusteringMetrics):
            m = asdict(m)

        line = (
            f"{config_name:<18} {m['cluster_count']:>8} {m['modularity']:>8.3f} "
            f"{m['coverage']:>8.3f} {m['singleton_count']:>7} "
            f"{m['domain_purity']:>9.2f} {m['role_separation_score']:>7.2f}"
        )
        lines.append(line)

    return "\n".join(lines)


def _format_comparison(
    current: Dict[str, Any],
    baseline: Dict[str, Any],
) -> str:
    """Format comparison between two runs."""
    lines = []
    lines.append("\nComparison with previous run:")
    lines.append("-" * 50)

    m_curr = current["metrics"]
    m_base = baseline["metrics"]

    # Handle both dict and ClusteringMetrics
    if isinstance(m_curr, ClusteringMetrics):
        m_curr = asdict(m_curr)
    if isinstance(m_base, ClusteringMetrics):
        m_base = asdict(m_base)

    metrics_to_compare = [
        ("cluster_count", "Clusters", False),
        ("modularity", "Modularity", True),
        ("coverage", "Coverage", True),
        ("singleton_count", "Singletons", False),
        ("domain_purity", "Domain Purity", True),
        ("role_separation_score", "Role Separation", True),
    ]

    for key, label, higher_is_better in metrics_to_compare:
        curr_val = m_curr.get(key, 0)
        base_val = m_base.get(key, 0)
        diff = curr_val - base_val

        if isinstance(curr_val, float):
            diff_str = f"{diff:+.3f}"
            val_str = f"{curr_val:.3f}"
        else:
            diff_str = f"{diff:+d}"
            val_str = f"{curr_val}"

        # Indicator
        if diff == 0:
            indicator = "="
        elif (higher_is_better and diff > 0) or (not higher_is_better and diff < 0):
            indicator = "+"  # Improvement
        else:
            indicator = "-"  # Regression

        lines.append(f"  {label:<18} {val_str:>10} ({diff_str}) {indicator}")

    # Partition comparison
    curr_clusters = current.get("clusters", {})
    base_clusters = baseline.get("clusters", {})

    if curr_clusters and base_clusters:
        comparison = compare_partitions(curr_clusters, base_clusters)
        lines.append("")
        lines.append("Partition Stability:")
        lines.append(f"  NMI:      {comparison.nmi:.3f} (1.0 = identical)")
        lines.append(f"  ARI:      {comparison.ari:.3f} (1.0 = identical)")
        lines.append(f"  Jaccard:  {comparison.jaccard:.3f} (1.0 = identical)")

    return "\n".join(lines)


def _format_history(history: List[Dict[str, Any]], limit: int = 10) -> str:
    """Format run history as a table."""
    if not history:
        return "No run history found."

    lines = []
    lines.append(f"Recent runs (last {limit}):")
    header = f"{'Timestamp':<20} {'Config':<18} {'Clusters':>8} {'Modular.':>8} {'Coverage':>8}"
    lines.append(header)
    lines.append("-" * len(header))

    for entry in history[-limit:]:
        ts = entry.get("timestamp", "")[:19]  # Trim microseconds
        config_name = entry.get("config_name", "custom")[:17]
        clusters = entry.get("cluster_count", 0)
        modularity = entry.get("modularity", 0.0)
        coverage = entry.get("coverage", 0.0)

        line = f"{ts:<20} {config_name:<18} {clusters:>8} {modularity:>8.3f} {coverage:>8.3f}"
        lines.append(line)

    return "\n".join(lines)


def _format_cluster_details(metrics: ClusteringMetrics) -> str:
    """Format per-cluster details."""
    if not metrics.cluster_details:
        return ""

    lines = []
    lines.append("\nPer-Cluster Details:")
    header = (
        f"{'ID':>3} {'Models':>6} {'Facts':>5} {'Dims':>5} {'Edges':>6} "
        f"{'Weight':>8} {'Domain':<20} {'Share':>5}"
    )
    lines.append(header)
    lines.append("-" * len(header))

    for d in metrics.cluster_details:
        domain = (d.get("dominant_domain") or "-")[:19]
        line = (
            f"{d['cluster_id']:>3} {d['model_count']:>6} {d['fact_count']:>5} "
            f"{d['dimension_count']:>5} {d['internal_edges']:>6} "
            f"{d['internal_weight']:>8.1f} {domain:<20} {d['dominant_domain_share']:>5.2f}"
        )
        lines.append(line)

    return "\n".join(lines)


async def run_evaluation(
    config_path: Optional[Path],
    sweep: bool = False,
    verbose: bool = False,
    export_path: Optional[Path] = None,
) -> None:
    """Run clustering evaluation."""
    # Load config
    cfg = _load_config(config_path)
    storage = create_storage(cfg.lineage)
    pop = cfg.population

    # Get current config params
    current_config = {
        "name": "current",
        "join_weight": pop.clustering.join_weight,
        "lineage_weight": pop.clustering.lineage_weight,
        "shared_dependency_weight": pop.clustering.shared_dependency_weight,
        "column_lineage_weight": pop.clustering.column_lineage_weight,
        "domain_similarity_weight": pop.clustering.domain_similarity_weight,
        "resolution": pop.clustering.resolution,
    }

    if sweep:
        # Run parameter sweep
        configs_to_run = SWEEP_CONFIGS
        print(f"Running parameter sweep with {len(configs_to_run)} configurations...")
    else:
        # Run single evaluation
        configs_to_run = [current_config]
        print("Running evaluation with current config...")

    results = []

    for config_params in configs_to_run:
        config_name = config_params.get("name", "custom")
        print(f"\n  Evaluating: {config_name}...")

        result = await _run_clustering_with_config(storage, config_params, verbose=verbose)

        # Extract serializable data
        metrics = result["metrics"]
        if isinstance(metrics, ClusteringMetrics):
            metrics_dict = asdict(metrics)
        else:
            metrics_dict = metrics

        run_result = {
            "timestamp": datetime.now().isoformat(),
            "config_name": config_name,
            "config": config_params,
            "config_hash": _compute_config_hash(config_params),
            "model_count": len(result.get("enrichment", {})),
            "metrics": metrics_dict,
            "clusters": result.get("clusters", {}),
        }

        results.append({
            **run_result,
            "_internal_metrics": result["metrics"],  # Keep for internal use
        })

    # Display results table
    print("\n" + "=" * 70)
    print(_format_metrics_table(results))
    print("=" * 70)

    # Show cluster details if verbose and single run
    if verbose and len(results) == 1:
        internal_metrics = results[0].get("_internal_metrics")
        if isinstance(internal_metrics, ClusteringMetrics):
            details = _format_cluster_details(internal_metrics)
            if details:
                print(details)

    # Compare with previous run (for single evaluation)
    if not sweep:
        previous = _get_latest_run()
        if previous:
            comparison = _format_comparison(results[0], previous)
            print(comparison)

    # Save results
    for result in results:
        # Remove internal metrics before saving
        save_result = {k: v for k, v in result.items() if not k.startswith("_")}
        filepath = _save_run_result(save_result)
        if verbose:
            print(f"\nSaved: {filepath}")

    # Export if requested
    if export_path:
        export_data = [
            {k: v for k, v in r.items() if not k.startswith("_")}
            for r in results
        ]
        export_path.write_text(json.dumps(export_data, indent=2))
        print(f"\nExported to: {export_path}")


def show_history(limit: int = 10) -> None:
    """Display run history."""
    history = _load_history()
    print(_format_history(history, limit))


def compare_runs(filename1: str, filename2: str) -> None:
    """Compare two specific runs."""
    run1 = _load_run_result(filename1)
    run2 = _load_run_result(filename2)

    if not run1:
        print(f"Run not found: {filename1}")
        return
    if not run2:
        print(f"Run not found: {filename2}")
        return

    print(f"Comparing {filename1} vs {filename2}")
    print(_format_metrics_table([run1, run2]))
    print(_format_comparison(run2, run1))  # run1 as baseline


def main(argv: Optional[List[str]] = None) -> None:
    """Main entry point for clustering evaluation tool."""
    parser = argparse.ArgumentParser(
        description="Evaluate clustering quality with configurable parameters."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Path to config.ingest.yml (auto-discovers if not provided)",
    )
    parser.add_argument(
        "--sweep",
        action="store_true",
        help="Run parameter sweep across predefined configurations",
    )
    parser.add_argument(
        "--history",
        action="store_true",
        help="Show run history",
    )
    parser.add_argument(
        "--compare",
        nargs=2,
        metavar=("RUN1", "RUN2"),
        help="Compare two specific run files",
    )
    parser.add_argument(
        "--export",
        type=Path,
        default=None,
        help="Export results to JSON file",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose output with per-cluster details",
    )

    args = parser.parse_args(argv)

    # Load .env file for environment variables
    load_env_file()

    # Configure logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(levelname)s: %(message)s",
    )

    # Handle different modes
    if args.history:
        show_history()
        return

    if args.compare:
        compare_runs(args.compare[0], args.compare[1])
        return

    # Run evaluation
    asyncio.run(run_evaluation(
        config_path=args.config,
        sweep=args.sweep,
        verbose=args.verbose,
        export_path=args.export,
    ))


if __name__ == "__main__":
    main()
