"""Report on ephemeral model lineage coverage.

Queries the graph database and the dbt manifest to produce a report showing:
- Which ephemeral models have DbtColumn nodes
- Which have DERIVES_FROM edges (inbound and outbound)
- Which are missing lineage entirely
- What transformation types are present

Usage:
    uv run lineage-ephemeral-report
"""

import json
import sys
from pathlib import Path


def main() -> None:
    """Generate a report of ephemeral model lineage."""
    from lineage.backends.config import UnifiedConfig
    from lineage.backends.lineage.factory import create_storage

    config_path = Path.home() / ".typedef" / "config.yaml"
    if not config_path.exists():
        print(f"Config not found at {config_path}")
        sys.exit(1)

    unified_cfg = UnifiedConfig.from_yaml(config_path)

    # Find the manifest path from the project config
    project_name = unified_cfg.default_project or ""
    project_cfg = (unified_cfg.projects or {}).get(project_name)
    if not project_cfg:
        print(f"No project config found for '{project_name}'")
        sys.exit(1)
    dbt_path = project_cfg.dbt_path

    # Use the project's graph_name (not the lineage config default)
    graph_name = project_cfg.graph_name
    print(f"Project: {project_name}, graph: {graph_name}")
    unified_cfg.lineage.graph_name = graph_name
    storage = create_storage(unified_cfg.lineage, read_only=True)
    manifest_path = Path(dbt_path) / "target" / "manifest.json"

    if not manifest_path.exists():
        print(f"Manifest not found at {manifest_path}")
        sys.exit(1)

    # Load ephemeral models from manifest
    with open(manifest_path) as f:
        manifest = json.load(f)

    nodes = manifest.get("nodes", {})
    ephemerals = {}
    for uid, node in nodes.items():
        if node.get("resource_type") != "model":
            continue
        config = node.get("config", {})
        if config.get("materialized") == "ephemeral":
            ephemerals[uid] = {
                "name": node.get("name", ""),
                "path": node.get("original_file_path", ""),
                "depends_on": [d for d in node.get("depends_on", {}).get("nodes", [])],
                "documented_columns": list(node.get("columns", {}).keys()),
                "has_compiled_sql": bool(node.get("compiled_code") or node.get("compiled_sql")),
            }

    print(f"Found {len(ephemerals)} ephemeral models in manifest")
    print("=" * 100)

    # Query graph for each ephemeral model
    results = []
    for uid, info in sorted(ephemerals.items()):
        # Count DbtColumn nodes for this model
        col_query = f"""
            MATCH (m:DbtModel {{id: '{uid}'}})-[:HAS_COLUMN]->(c:DbtColumn)
            RETURN c.id AS col_id, c.name AS col_name
        """
        col_result = storage.execute_raw_query(col_query)
        columns = [(r["col_id"], r["col_name"]) for r in col_result.rows]

        # Count outbound DERIVES_FROM edges (this model's columns derive from upstream)
        outbound_query = f"""
            MATCH (c:DbtColumn)-[e:DERIVES_FROM]->(up:DbtColumn)
            WHERE c.id STARTS WITH '{uid}.'
            RETURN c.name AS col_name, up.id AS upstream_id, e.transformation AS transformation,
                   e.confidence AS confidence, e.expr AS expr
        """
        outbound_result = storage.execute_raw_query(outbound_query)
        outbound_edges = [
            {
                "col_name": r["col_name"],
                "upstream_id": r["upstream_id"],
                "transformation": r.get("transformation", ""),
                "confidence": r.get("confidence", ""),
                "expr": r.get("expr", ""),
            }
            for r in outbound_result.rows
        ]

        # Count inbound DERIVES_FROM edges (downstream columns derive from this model's columns)
        inbound_query = f"""
            MATCH (down:DbtColumn)-[e:DERIVES_FROM]->(c:DbtColumn)
            WHERE c.id STARTS WITH '{uid}.'
            RETURN down.id AS downstream_id, c.name AS col_name, e.transformation AS transformation
        """
        inbound_result = storage.execute_raw_query(inbound_query)
        inbound_edges = [
            {
                "downstream_id": r["downstream_id"],
                "col_name": r["col_name"],
                "transformation": r.get("transformation", ""),
            }
            for r in inbound_result.rows
        ]

        # Check if model node exists in graph
        model_query = f"MATCH (m:DbtModel {{id: '{uid}'}}) RETURN m.id AS id"
        model_result = storage.execute_raw_query(model_query)
        model_exists = len(model_result.rows) > 0

        # Transformation type breakdown for outbound edges
        transformation_counts: dict[str, int] = {}
        for e in outbound_edges:
            t = e["transformation"] or "(none)"
            transformation_counts[t] = transformation_counts.get(t, 0) + 1

        # Columns with outbound lineage
        cols_with_lineage = set(e["col_name"] for e in outbound_edges)
        # Columns without outbound lineage
        col_names = set(name for _, name in columns)
        cols_without_lineage = col_names - cols_with_lineage

        results.append({
            "uid": uid,
            "name": info["name"],
            "path": info["path"],
            "has_compiled_sql": info["has_compiled_sql"],
            "documented_columns": info["documented_columns"],
            "model_exists": model_exists,
            "graph_columns": columns,
            "outbound_edges": outbound_edges,
            "inbound_edges": inbound_edges,
            "transformation_counts": transformation_counts,
            "cols_with_lineage": cols_with_lineage,
            "cols_without_lineage": cols_without_lineage,
            "depends_on": info["depends_on"],
        })

    # Print detailed report
    full_coverage = []
    partial_coverage = []
    no_coverage = []
    no_compiled_sql = []

    for r in results:
        if not r["has_compiled_sql"]:
            no_compiled_sql.append(r)
        elif len(r["outbound_edges"]) > 0 and len(r["cols_without_lineage"]) == 0:
            full_coverage.append(r)
        elif len(r["outbound_edges"]) > 0:
            partial_coverage.append(r)
        else:
            no_coverage.append(r)

    # Summary
    print(f"\n{'SUMMARY':=^100}")
    print(f"  Total ephemeral models:          {len(results)}")
    print(f"  Full lineage coverage:           {len(full_coverage)}")
    print(f"  Partial lineage coverage:        {len(partial_coverage)}")
    print(f"  No lineage (has compiled SQL):   {len(no_coverage)}")
    print(f"  No compiled SQL available:       {len(no_compiled_sql)}")
    print()

    total_graph_cols = sum(len(r["graph_columns"]) for r in results)
    total_outbound = sum(len(r["outbound_edges"]) for r in results)
    total_inbound = sum(len(r["inbound_edges"]) for r in results)
    print(f"  Total DbtColumn nodes:           {total_graph_cols}")
    print(f"  Total outbound DERIVES_FROM:     {total_outbound}")
    print(f"  Total inbound DERIVES_FROM:      {total_inbound}")

    # Aggregate transformation types
    all_transformations: dict[str, int] = {}
    for r in results:
        for t, count in r["transformation_counts"].items():
            all_transformations[t] = all_transformations.get(t, 0) + count

    # Count expr population
    total_with_expr = sum(
        1 for r in results for e in r["outbound_edges"] if e.get("expr")
    )
    total_without_expr = total_outbound - total_with_expr
    print(f"  Outbound edges with expr:        {total_with_expr}")
    print(f"  Outbound edges without expr:     {total_without_expr}")

    if all_transformations:
        print(f"\n{'TRANSFORMATION TYPE BREAKDOWN':=^100}")
        for t, count in sorted(all_transformations.items(), key=lambda x: -x[1]):
            print(f"  {t:40s} {count:5d}")

    # Full coverage models
    if full_coverage:
        print(f"\n{'FULL LINEAGE COVERAGE':=^100}")
        for r in full_coverage:
            print(f"\n  {r['uid']}")
            print(f"    columns: {len(r['graph_columns'])}  |  outbound edges: {len(r['outbound_edges'])}  |  inbound edges: {len(r['inbound_edges'])}")
            if r["transformation_counts"]:
                parts = [f"{t}: {c}" for t, c in sorted(r["transformation_counts"].items(), key=lambda x: -x[1])]
                print(f"    transformations: {', '.join(parts)}")

    # Partial coverage models
    if partial_coverage:
        print(f"\n{'PARTIAL LINEAGE COVERAGE':=^100}")
        for r in partial_coverage:
            print(f"\n  {r['uid']}")
            print(f"    columns: {len(r['graph_columns'])}  |  outbound edges: {len(r['outbound_edges'])}  |  inbound edges: {len(r['inbound_edges'])}")
            print(f"    columns WITH lineage:    {sorted(r['cols_with_lineage'])}")
            print(f"    columns WITHOUT lineage: {sorted(r['cols_without_lineage'])}")
            if r["transformation_counts"]:
                parts = [f"{t}: {c}" for t, c in sorted(r["transformation_counts"].items(), key=lambda x: -x[1])]
                print(f"    transformations: {', '.join(parts)}")

    # No coverage (but has compiled SQL)
    if no_coverage:
        print(f"\n{'NO LINEAGE (COMPILED SQL AVAILABLE)':=^100}")
        for r in no_coverage:
            print(f"\n  {r['uid']}")
            print(f"    model in graph: {r['model_exists']}")
            print(f"    graph columns: {len(r['graph_columns'])}")
            print(f"    depends_on: {len(r['depends_on'])} nodes")
            for dep in r["depends_on"]:
                print(f"      - {dep}")

    # No compiled SQL
    if no_compiled_sql:
        print(f"\n{'NO COMPILED SQL AVAILABLE':=^100}")
        for r in no_compiled_sql:
            print(f"\n  {r['uid']}")
            print(f"    model in graph: {r['model_exists']}")
            print(f"    graph columns: {len(r['graph_columns'])}")
            print(f"    documented columns: {len(r['documented_columns'])}")
            print(f"    outbound edges: {len(r['outbound_edges'])}  |  inbound edges: {len(r['inbound_edges'])}")
            if r["outbound_edges"]:
                parts = [f"{t}: {c}" for t, c in sorted(r["transformation_counts"].items(), key=lambda x: -x[1])]
                print(f"    transformations: {', '.join(parts)}")

    # Downstream impact: which non-ephemeral models reference ephemerals?
    print(f"\n{'DOWNSTREAM CONSUMERS (inbound edges by downstream model)':=^100}")
    downstream_models: dict[str, int] = {}
    for r in results:
        for e in r["inbound_edges"]:
            # Extract model uid from column id (e.g., "model.x.y.col" -> "model.x.y")
            parts = e["downstream_id"].rsplit(".", 1)
            if len(parts) == 2:
                model_id = parts[0]
                downstream_models[model_id] = downstream_models.get(model_id, 0) + 1

    for model_id, count in sorted(downstream_models.items(), key=lambda x: -x[1])[:30]:
        print(f"  {model_id:70s} {count:4d} edges")

    storage.close()
    print(f"\n{'DONE':=^100}")


if __name__ == "__main__":
    main()
