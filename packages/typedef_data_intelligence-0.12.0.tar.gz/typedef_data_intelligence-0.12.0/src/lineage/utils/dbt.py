"""dbt utility functions for project management."""
import logging
import os
import shutil
import subprocess
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

TYPEDEF_HOME = Path.home() / ".typedef"
TYPEDEF_VENVS = TYPEDEF_HOME / "venvs"


def get_adapter_venv_dir(adapter: str) -> Path:
    """Return the venv directory for a dbt adapter.

    Venvs are shared across projects that use the same adapter.

    Args:
        adapter: The dbt adapter name (e.g., "snowflake", "bigquery")

    Returns:
        Path to the venv directory (e.g., ~/.typedef/venvs/dbt-snowflake/)
    """
    return TYPEDEF_VENVS / f"dbt-{adapter}"


def _dbt_venv_bin(venv_dir: Path) -> Optional[Path]:
    """Return the dbt binary path from the venv, if present.

    Args:
        venv_dir: Path to the virtual environment directory

    Returns:
        Path to dbt binary if found, None otherwise
    """
    if not venv_dir.exists():
        return None

    unix_bin = venv_dir / "bin" / "dbt"
    if unix_bin.exists():
        return unix_bin

    win_bin = venv_dir / "Scripts" / "dbt.exe"
    if win_bin.exists():
        return win_bin

    return None


def resolve_dbt_cmd(args: list[str], adapter: Optional[str] = None) -> list[str]:
    """Resolve the dbt command prefix, then append args.

    Resolution order:
    1. Adapter-specific venv binary (~/.typedef/venvs/dbt-{adapter}/bin/dbt)
    2. ``uv run --no-project dbt`` when uv is on PATH
    3. Bare ``dbt``

    Args:
        args: dbt sub-command arguments (e.g., ["run", "--select", "my_model"])
        adapter: dbt adapter name. Defaults to TYPEDEF_DBT_ADAPTER env var
            or "snowflake".

    Returns:
        Full command list ready for subprocess execution.
    """
    adapter = adapter or os.getenv("TYPEDEF_DBT_ADAPTER", "snowflake")
    venv_dir = get_adapter_venv_dir(adapter)
    venv_dbt = _dbt_venv_bin(venv_dir)
    if venv_dbt:
        return [str(venv_dbt), *args]
    if shutil.which("uv"):
        # Use --no-project so uv doesn't treat the dbt repo as a uv project.
        return ["uv", "run", "--no-project", "dbt", *args]
    return ["dbt", *args]


def run_dbt_command(
    command: list[str],
    project_dir: Path,
    profiles_dir: Optional[Path] = None,
    venv_dir: Optional[Path] = None,
    extra_env: Optional[dict[str, str]] = None,
) -> tuple[str, str]:
    """Run a dbt command in the specified project directory.

    Args:
        command: dbt command arguments (e.g., ["deps"], ["docs", "generate"])
        project_dir: dbt project directory
        profiles_dir: Optional profiles directory override
        venv_dir: Optional venv directory containing dbt installation
        extra_env: Optional additional environment variables to set

    Returns:
        Tuple of (stdout, stderr)

    Raises:
        subprocess.CalledProcessError: If command fails
    """
    # Build env vars
    env = {}
    if profiles_dir:
        env["DBT_PROFILES_DIR"] = str(profiles_dir)
    if extra_env:
        env.update(extra_env)

    # Build base command — prefer explicit venv_dir if provided,
    # otherwise use the standard resolution chain.
    if venv_dir:
        venv_dbt = _dbt_venv_bin(venv_dir)
        cmd = [str(venv_dbt), *command] if venv_dbt else resolve_dbt_cmd(command)
    else:
        cmd = resolve_dbt_cmd(command)

    logger.info(f"Running dbt command: {' '.join(cmd)} in {project_dir}")

    # If we have env vars, merge with system env
    run_env = None
    if env:
        run_env = os.environ.copy()
        run_env.update(env)

    result = subprocess.run(
        cmd,
        cwd=project_dir,
        check=True,
        capture_output=True,
        text=True,
        env=run_env
    )

    return result.stdout, result.stderr


