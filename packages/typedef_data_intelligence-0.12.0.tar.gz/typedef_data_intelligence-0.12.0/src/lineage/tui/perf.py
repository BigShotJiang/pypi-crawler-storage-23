"""Lightweight opt-in perf event logging for TUI responsiveness work."""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_TRUTHY_VALUES = {"1", "true", "yes", "on"}
_DEFAULT_LOG_PATH = Path.home() / ".typedef" / "logs" / "tui-perf.log"


def _env_enabled() -> bool:
    raw = os.getenv("TYPEDEF_TUI_PERF", "")
    return raw.strip().lower() in _TRUTHY_VALUES


class PerfEventLogger:
    """Emit structured JSON-lines perf events when enabled."""

    def __init__(
        self,
        enabled: bool | None = None,
        log_path: Path | None = None,
    ) -> None:
        """Initialize perf event logger.

        Args:
            enabled: Whether logging is enabled. Defaults to env var check.
            log_path: Path for log file. Defaults to env var or ~/.typedef/logs.
        """
        self.enabled = _env_enabled() if enabled is None else enabled
        self.log_path = log_path or Path(
            os.getenv("TYPEDEF_TUI_PERF_LOG", str(_DEFAULT_LOG_PATH))
        )

    def log_event(self, event: str, **payload: Any) -> None:
        """Write one event if perf logging is enabled."""
        if not self.enabled:
            return

        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "event": event,
            **payload,
        }

        try:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            with self.log_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, separators=(",", ":"), sort_keys=True))
                handle.write("\n")
        except Exception as exc:
            logger.debug("Failed to write perf event: %s", exc)


_PERF_LOGGER = PerfEventLogger()


def get_perf_logger() -> PerfEventLogger:
    """Return shared process-level perf logger."""
    return _PERF_LOGGER
