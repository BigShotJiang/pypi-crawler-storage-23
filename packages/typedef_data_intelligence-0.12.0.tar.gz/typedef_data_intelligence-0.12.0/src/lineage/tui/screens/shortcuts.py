"""Compact keyboard shortcuts modal for quick TUI discovery."""

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import Label, Static


class ShortcutsScreen(ModalScreen[None]):
    """Modal screen showing succinct keyboard shortcuts by active tab."""

    BINDINGS = [
        Binding("escape", "close", "Close", show=True),
        Binding("q", "close", "Close", show=False),
        Binding("f1", "open_full_help", "Full Help", show=True),
        Binding("ctrl+c", "app.confirm_exit", "Exit", show=False),
    ]

    TITLE_TEXT = "keyboard shortcuts"
    ESC_KEY_TEXT = "esc"
    ESC_HINT_TEXT = "to close"
    F1_KEY_TEXT = "f1"
    F1_HINT_TEXT = "user guide"

    GLOBAL_ROWS: list[tuple[str, str]] = [
        ("?", "open help"),
        ("ctrl+/", "open help"),
        ("f1", "open user guide"),
        ("tab / shift+tab", "move ui focus"),
        ("ctrl+a", "open artifacts"),
        ("ctrl+g", "open activity"),
        ("ctrl+shift+c", "copy selection"),
        ("ctrl+t", "tickets tab"),
        ("ctrl+d", "daemon tab"),
        ("ctrl+q", "stop agent"),
        ("ctrl+c ctrl+c", "exit app"),
    ]

    TAB_ROWS: dict[str, list[tuple[str, str]]] = {
        "chat": [
            ("q / esc", "stop agent"),
            ("ctrl+c", "clear text input"),
            ("f", "toggle follow"),
            ("i", "focus input"),
            ("v", "toggle verbose"),
        ],
        "tickets": [
            ("r", "refresh tickets"),
            ("i", "open investigator"),
            ("c", "open copilot"),
            ("ctrl+, / ctrl+.", "to chat tab"),
        ],
        "daemon": [
            ("s", "start/stop"),
            ("r", "reconciler"),
            ("i", "investigator"),
            ("ctrl+, / ctrl+.", "to chat tab"),
        ],
    }

    def __init__(self, active_tab: str = "chat") -> None:
        """Initialize with active tab so tab-local shortcuts are highlighted."""
        super().__init__()
        self.active_tab = active_tab

    def _active_rows(self) -> list[tuple[str, str]]:
        """Return active-tab rows, defaulting to chat layout."""
        return self.TAB_ROWS.get(self.active_tab, self.TAB_ROWS["chat"])

    def _section_title(self, tab: str) -> str:
        """Return human-readable section title for active shortcut group."""
        return "chat" if tab == "chat" else f"{tab} tab"

    def compose(self) -> ComposeResult:
        """Create compact shortcuts modal widgets."""
        with Container(classes="help-modal shortcuts-modal", id="shortcuts-modal"):
            yield Static("~ ~ ~", classes="chat-agent-decoration")
            yield Label(self.TITLE_TEXT, classes="chat-agent-title")
            yield Static("~ ~ ~", classes="chat-agent-decoration")
            with VerticalScroll(id="shortcuts-content", classes="help-modal-content"):
                with Vertical(classes="shortcuts-block"):
                    with Vertical(classes="shortcuts-section"):
                        yield Label("global", classes="shortcuts-section-title")
                        for key, description in self.GLOBAL_ROWS:
                            with Horizontal(classes="shortcuts-row"):
                                yield Static(key, classes="shortcuts-key")
                                yield Static(description, classes="shortcuts-desc")

                    with Vertical(classes="shortcuts-section"):
                        yield Label(
                            self._section_title(self.active_tab),
                            classes="shortcuts-section-title",
                        )
                        for key, description in self._active_rows():
                            with Horizontal(classes="shortcuts-row"):
                                yield Static(key, classes="shortcuts-key")
                                yield Static(description, classes="shortcuts-desc")
            with Horizontal(classes="shortcuts-footer"):
                with Horizontal(classes="shortcuts-footer-left"):
                    yield Label(self.ESC_KEY_TEXT, classes="shortcuts-footer-key")
                    yield Label(self.ESC_HINT_TEXT, classes="shortcuts-footer-text")
                with Horizontal(classes="shortcuts-footer-right"):
                    yield Label(self.F1_KEY_TEXT, classes="shortcuts-footer-key")
                    yield Label(self.F1_HINT_TEXT, classes="shortcuts-footer-text")

    def action_close(self) -> None:
        """Close the shortcuts modal."""
        self.dismiss()

    def action_open_full_help(self) -> None:
        """Open full help modal from the compact shortcuts view."""
        from lineage.tui.screens.help import HelpScreen

        self.dismiss()
        self.app.push_screen(HelpScreen())
