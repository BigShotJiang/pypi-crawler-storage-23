"""Chat screen components."""

import asyncio
import json
import logging
import os
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from time import monotonic
from typing import Any, Callable, Dict, List, Optional

from pydantic import BaseModel, ValidationError
from textual.command import Matcher
from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.css.query import NoMatches
from textual.message import Message as TextualMessage
from textual.reactive import reactive
from textual.widgets import (
    Button,
    Collapsible,
    Label,
    ListItem,
    ListView,
    Markdown,
    Static,
    TextArea,
)

from lineage.ag_ui.client import AGUIClient as AguiClient
from lineage.ag_ui.client import AGUIRequestError
from lineage.agent.pydantic.types import (
    AddTicketCommentResult,
    BashResult,
    CellAck,
    CreateReportResult,
    CreateTicketResult,
    DbtResult,
    DomainSearchResult,
    DownstreamImpactResult,
    ExecuteQueryResult,
    ContextBrief,
    GetTicketResult,
    GraphSearchResult,
    ListSubjectAreasResult,
    ListTicketsResult,
    PlanAck,
    PlanView,
    PreviewTableResult,
    QueryGraphResult,
    RelatedSubjectAreasResult,
    ReportPreview,
    SearchModelsResult,
    SubjectAreaDetailsResult,
    UpdateTicketResult,
)
from lineage.backends.lineage.protocol import (
    ModelDetailsResult,
    ModelMaterializationsResult,
    RelationLineageResult,
)
from lineage.backends.reports.protocol import CellData
from lineage.tui.perf import get_perf_logger
from lineage.tui.screens.activity import ActivityScreen
from lineage.tui.screens.artifacts import ArtifactsScreen
from lineage.tui.screens.placeholders import AGENT_CHOOSER_OPTIONS, AGENT_PLACEHOLDERS
from lineage.tui.widgets.artifacts import (
    ArtifactViewer,
    ExportReportRequest,
    TOOL_DISPLAY_INFO,
    _convert_mermaid_to_ascii,
    _escape_markdown,
    build_command_output_widget,
    build_diagnostics_widget,
    build_domain_search_widget,
    build_graph_result_widget,
    build_impact_tree_widget,
    build_lineage_widget,
    build_model_details_widget,
    build_search_results_widget,
    build_subject_area_details_widget,
    build_subject_area_list_widget,
    build_table_widget,
    build_ticket_list_widget,
    build_ticket_update_widget,
    build_ticket_widget,
)

logger = logging.getLogger(__name__)

# Debounce interval for markdown updates (seconds)
MARKDOWN_UPDATE_INTERVAL = 0.2

# Export directory for markdown files
EXPORT_DIR = Path.home() / ".typedef" / "exports"

# Autoscroll bottom detection threshold (pixels)
AUTOSCROLL_BOTTOM_THRESHOLD_PX = 10

# Maximum visible rows in the slash command menu (must match max-height in styles.tcss).
SLASH_MENU_MAX_ROWS = 6

# Limit outbound context history to reduce long-session payload growth.
DEFAULT_CONTEXT_TURN_CAP = 30
CONTEXT_TURN_CAP_ENV = "TYPEDEF_TUI_MAX_CONTEXT_TURNS"


def _resolve_context_turn_cap() -> int:
    """Resolve configured context turn cap from environment.

    A value of 0 disables capping and sends full in-memory history.
    """
    raw_value = os.getenv(CONTEXT_TURN_CAP_ENV)
    if raw_value is None:
        return DEFAULT_CONTEXT_TURN_CAP
    try:
        parsed = int(raw_value.strip())
    except ValueError:
        logger.warning(
            "Invalid %s=%r; falling back to %d turns",
            CONTEXT_TURN_CAP_ENV,
            raw_value,
            DEFAULT_CONTEXT_TURN_CAP,
        )
        return DEFAULT_CONTEXT_TURN_CAP
    return max(0, parsed)


@dataclass
class ToolCallRecord:
    """Record of a single tool call during an agent run."""

    tool_call_id: str
    tool_name: str
    display_text: str
    start_time: datetime
    end_time: Optional[datetime] = None
    artifact_id: Optional[str] = None  # Link to generated artifact

    @property
    def duration_seconds(self) -> Optional[float]:
        """Get duration in seconds if completed."""
        if self.end_time and self.start_time:
            return (self.end_time - self.start_time).total_seconds()
        return None


@dataclass
class RunStats:
    """Statistics for a single agent run (user prompt → response)."""

    run_id: str
    agent_name: str
    start_time: datetime
    user_message: str
    end_time: Optional[datetime] = None
    tool_calls: List[ToolCallRecord] = field(default_factory=list)
    response_char_count: int = 0

    @property
    def duration_seconds(self) -> Optional[float]:
        """Get total run duration in seconds."""
        if self.end_time and self.start_time:
            return (self.end_time - self.start_time).total_seconds()
        return None

    @property
    def tool_call_count(self) -> int:
        """Get number of tool calls."""
        return len(self.tool_calls)


@dataclass
class SubagentStats:
    """Statistics for a single subagent execution."""

    activity_id: str
    subagent_type: str
    start_time: datetime
    end_time: Optional[datetime] = None
    tool_calls: List[ToolCallRecord] = field(default_factory=list)
    result_preview: Optional[str] = None
    input_prompt: Optional[str] = (
        None  # Original task given to subagent by orchestrator
    )

    @property
    def duration_seconds(self) -> Optional[float]:
        """Get subagent execution duration in seconds."""
        if self.end_time and self.start_time:
            return (self.end_time - self.start_time).total_seconds()
        return None

    @property
    def tool_call_count(self) -> int:
        """Get number of tool calls made by the subagent."""
        return len(self.tool_calls)


class ChatContentFlushed(TextualMessage):
    """Event emitted when streaming content flushes to the UI."""

    def __init__(self) -> None:
        """Initialize the flush event."""
        super().__init__()


@dataclass(frozen=True)
class SlashCommandSpec:
    """Single slash command definition for chat input completion."""

    command: str
    description: str


@dataclass(frozen=True)
class SlashCommandMatch:
    """Slash command fuzzy match result."""

    spec: SlashCommandSpec
    score: float


SLASH_COMMANDS: tuple[SlashCommandSpec, ...] = (
    SlashCommandSpec("/new", "start a new chat session"),
    SlashCommandSpec("/clear", "reset the current chat session"),
    SlashCommandSpec("/status", "show current session status"),
)


def _filter_slash_commands(query: str) -> list[SlashCommandSpec]:
    """Return slash commands matching query, sorted by match strength."""
    normalized = query.strip()
    if not normalized:
        return list(SLASH_COMMANDS)

    matcher = Matcher(normalized, case_sensitive=False)
    scored: list[tuple[float, bool, str, SlashCommandSpec]] = []
    for spec in SLASH_COMMANDS:
        command_score = max(
            matcher.match(spec.command),
            matcher.match(spec.command.lstrip("/")),
        )
        desc_score = matcher.match(spec.description)
        score = max(command_score, desc_score)
        if score > 0:
            # Prefer command-name matches over description-only matches
            # at the same score (e.g. "st" matching "/status" vs "start...")
            scored.append((-score, command_score == 0, spec.command, spec))

    scored.sort()
    return [spec for _, _, _, spec in scored]


class SlashCommandMenu(Container):
    """Popup menu for slash command completion and execution."""

    def __init__(self) -> None:
        """Initialize slash menu state."""
        super().__init__(id="slash-command-menu", classes="slash-command-menu")
        self._matches: list[SlashCommandSpec] = []
        self._list = ListView(id="slash-command-list", classes="slash-command-list")
        self._items: list[ListItem] = []
        self._selected_index = 0
        self.display = False

    def compose(self) -> ComposeResult:
        """Compose slash command list."""
        yield self._list

    @property
    def is_open(self) -> bool:
        """Return whether slash popup is visible."""
        return bool(self.display and self._matches)

    def hide_menu(self) -> None:
        """Hide menu and clear current matches."""
        self.display = False
        self._matches = []
        self._items = []
        self._selected_index = 0
        self.styles.height = "auto"
        self._list.styles.height = "auto"
        self._list.clear()

    def update_query(self, query: str) -> bool:
        """Update visible rows for a slash query."""
        matches = _filter_slash_commands(query)
        if not matches:
            self.hide_menu()
            return False

        self._matches = matches
        self._items = []
        self._list.clear()
        for spec in matches:
            item = ListItem(
                Horizontal(
                    Label(spec.command, classes="slash-command-name"),
                    Label(spec.description, classes="slash-command-description"),
                    classes="slash-command-row",
                ),
                classes="slash-command-item",
            )
            self._items.append(item)
            self._list.append(item)
        visible_rows = max(1, min(len(matches), SLASH_MENU_MAX_ROWS))
        self.styles.height = visible_rows
        self._list.styles.height = visible_rows
        self._selected_index = 0
        self._list.index = 0
        self._sync_selection_style()
        self.display = True
        return True

    def move_selection(self, delta: int) -> None:
        """Move selected row up/down when menu is open."""
        if not self.is_open:
            return
        current = self._list.index
        if current is None:
            current = self._selected_index
        next_index = max(0, min(len(self._matches) - 1, current + delta))
        self._selected_index = next_index
        self._list.index = next_index
        self._sync_selection_style()

    def selected(self) -> Optional[SlashCommandSpec]:
        """Get currently highlighted slash command."""
        if not self.is_open:
            return None
        index = self._list.index
        if index is None:
            index = self._selected_index
        if index < 0 or index >= len(self._matches):
            return None
        return self._matches[index]

    def _sync_selection_style(self) -> None:
        """Keep a visible selected-row style even when list is unfocused."""
        for item_index, item in enumerate(self._items):
            if item_index == self._selected_index:
                item.add_class("slash-command-active")
            else:
                item.remove_class("slash-command-active")


def _handle_slash_menu_key(
    event,
    chat_area: Optional["ChatArea"],
    input_widget: "TextArea",
) -> bool:
    """Handle slash menu key navigation; returns True if the event was consumed."""
    slash_menu = chat_area.slash_menu if chat_area is not None else None
    if not (slash_menu and slash_menu.is_open):
        return False
    if event.key == "up":
        event.prevent_default()
        event.stop()
        slash_menu.move_selection(-1)
        return True
    if event.key == "down":
        event.prevent_default()
        event.stop()
        slash_menu.move_selection(1)
        return True
    if event.key == "tab":
        event.prevent_default()
        event.stop()
        if chat_area is not None:
            chat_area.apply_slash_completion(input_widget)
        return True
    if event.key == "escape":
        event.prevent_default()
        event.stop()
        if chat_area is not None:
            chat_area.close_slash_menu()
        return True
    if event.key == "enter":
        event.prevent_default()
        event.stop()
        if chat_area is not None and chat_area.execute_selected_slash_command(
            input_widget
        ):
            return True
    return False


class PlaceholderInput(TextArea):
    """Input widget embedded in the placeholder for new chat screen."""

    BINDINGS = [
        ("ctrl+enter", "submit", "Send"),
    ]

    def on_key(self, event) -> None:
        """Handle Enter to submit, Shift+Enter for newline."""
        chat_area = self._chat_area()
        if _handle_slash_menu_key(event, chat_area, self):
            return

        if event.key == "ctrl+c":
            event.prevent_default()
            event.stop()
            confirm_exit = getattr(self.app, "action_confirm_exit", None)
            if callable(confirm_exit):
                confirm_exit()
            return
        if event.key == "shift+enter":
            event.prevent_default()
            event.stop()
            self.insert("\n")
            return
        if event.key == "enter":
            event.prevent_default()
            event.stop()
            self.action_submit()

    def on_text_area_changed(self, event) -> None:
        """Auto-expand height based on content."""
        del event
        self._adjust_height()
        chat_area = self._chat_area()
        if chat_area is not None:
            chat_area.update_slash_menu(self.text)

    def _adjust_height(self) -> None:
        """Adjust height based on number of lines."""
        line_count = self.text.count("\n") + 1
        new_height = _clamp_height_to_style_bounds(self, line_count + 1)
        self.styles.height = new_height

    def action_submit(self) -> None:
        """Submit the input text."""
        if not self.text.strip():
            return
        self.post_message(PlaceholderInput.Submitted(self.text))

    class Submitted(TextualMessage):
        """Event posted when user submits the placeholder input."""

        def __init__(self, value: str):
            """Initialize submitted message with input value."""
            super().__init__()
            self.value = value

    def _chat_area(self) -> Optional["ChatArea"]:
        """Get containing chat area when mounted."""
        try:
            return self.query_ancestor(ChatArea)
        except NoMatches:
            return None


class AgentPlaceholder(Container):
    """Placeholder widget shown when chat is empty, with agent intro and sample prompts."""

    CHOOSER_HINT_TEXT = (
        "[bold]up/down[/bold] select  "
        "[bold]enter[/bold] confirm  "
        "[bold]1-4[/bold] quick pick"
    )
    INPUT_HINT_TEXT = (
        "[bold]enter[/bold] send  [bold]shift+enter[/bold] newline"
        "  [bold]tab[/bold] complete command"
        "  [dim]tip: use /new to start a new chat session[/dim]"
    )

    class AgentSelected(TextualMessage):
        """Event posted when user confirms an agent choice."""

        def __init__(self, mode: str):
            """Initialize selected-agent message."""
            super().__init__()
            self.mode = mode

    def __init__(self, agent_name: str, chooser: bool = False) -> None:
        """Initialize the placeholder for a specific agent."""
        super().__init__()
        self.agent_name = agent_name
        self.is_chooser = chooser
        self._content = AGENT_PLACEHOLDERS.get(
            agent_name,
            {
                "title": agent_name.title(),
                "intro": "Ask me anything about your data.",
                "prompts": [],
            },
        )
        self._chooser_modes = [option["mode"] for option in AGENT_CHOOSER_OPTIONS]
        self._chooser_selected_index = 0
        self._chooser_items = [
            ListItem(
                Vertical(
                    Label(option["label"], classes="chooser-agent-label"),
                    Label(option["summary"], classes="chooser-agent-summary"),
                    classes="chooser-row-stack",
                ),
                classes="agent-choice-item",
            )
            for option in AGENT_CHOOSER_OPTIONS
        ]
        self._chooser_list = ListView(*self._chooser_items, id="agent-chooser-list")
        self.placeholder_input: Optional[PlaceholderInput] = None
        if not self.is_chooser:
            self.placeholder_input = PlaceholderInput(
                id="placeholder-input", classes="placeholder-input"
            )

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        if self.is_chooser:
            yield Static("~ ~ ~", classes="placeholder-decoration")
            yield Label("Choose an agent", classes="placeholder-title")
            yield Static("~ ~ ~", classes="placeholder-decoration")
            yield Label(
                "Pick who should lead this chat. You will land in the normal chat starter view after selection.",
                classes="chooser-intro",
            )
            yield self._chooser_list
            yield Static(
                self.CHOOSER_HINT_TEXT,
                classes="placeholder-input-hints",
            )
            return

        # Decorative header with title
        yield Static("~ ~ ~", classes="placeholder-decoration")
        yield Label(self._content["title"], classes="placeholder-title")
        yield Static("~ ~ ~", classes="placeholder-decoration")

        # Intro text
        with Container(classes="placeholder-intro-wrap"):
            with Horizontal(classes="placeholder-intro-row"):
                yield Static("", classes="placeholder-intro-spacer")
                yield Static(self._content["intro"], classes="placeholder-intro")
                yield Static("", classes="placeholder-intro-spacer")

        # Sample prompts section (narrow, de-emphasized)
        prompts = self._content.get("prompts", [])
        if prompts:
            with Container(classes="sample-prompts-wrapper"):
                yield Label("Try asking:", classes="placeholder-section-header")
                with Container(classes="sample-prompts"):
                    for i, prompt in enumerate(prompts):
                        btn = Button(
                            f'"{prompt}"',
                            id=f"sample-prompt-{i}",
                            classes="sample-prompt-btn",
                        )
                        btn.tooltip = "Click to use this prompt"
                        yield btn

        # Centered input box (wider, prominent)
        with Container(classes="placeholder-input-container"):
            if self.placeholder_input:
                yield self.placeholder_input
            yield Static(
                self.INPUT_HINT_TEXT,
                classes="placeholder-input-hints",
            )

    def on_mount(self) -> None:
        """Focus the placeholder input on mount."""
        if self.is_chooser:
            self._chooser_list.focus()
            self.set_selected_mode(self.agent_name)
            self._sync_chooser_highlight()
            return
        if self.placeholder_input:
            self.placeholder_input.focus()

    def _sync_chooser_highlight(self) -> None:
        """Apply a stable visual highlight to the currently focused chooser row."""
        if not self.is_chooser:
            return
        idx = self._chooser_list.index
        if idx is None:
            idx = self._chooser_selected_index
        else:
            self._chooser_selected_index = idx
        for item_index, item in enumerate(self._chooser_items):
            if idx is not None and item_index == idx:
                item.add_class("agent-choice-active")
            else:
                item.remove_class("agent-choice-active")

    def set_selected_mode(self, mode: str) -> None:
        """Select a chooser row by mode when chooser is visible."""
        if not self.is_chooser:
            return
        try:
            idx = self._chooser_modes.index(mode)
        except ValueError:
            idx = 0
        self._chooser_selected_index = idx
        self._chooser_list.index = idx
        self._sync_chooser_highlight()

    def on_key(self, event) -> None:
        """Handle quick numeric selection for chooser mode."""
        if not self.is_chooser:
            return
        if event.key in {"1", "2", "3", "4"}:
            mode = self._chooser_modes[int(event.key) - 1]
            self.post_message(self.AgentSelected(mode))
            event.stop()

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Track ListView highlight movement to keep row styling in sync."""
        if not self.is_chooser or event.list_view.id != "agent-chooser-list":
            return
        idx = event.list_view.index
        if idx is None:
            idx = self._chooser_selected_index
        self._chooser_selected_index = idx
        self._sync_chooser_highlight()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle sample prompt button clicks."""
        if self.is_chooser:
            return
        if event.button.id and event.button.id.startswith("sample-prompt-"):
            try:
                idx = int(event.button.id.replace("sample-prompt-", ""))
                prompts = self._content.get("prompts", [])
                if 0 <= idx < len(prompts):
                    # Set the prompt in the placeholder input instead of posting message
                    if self.placeholder_input:
                        self.placeholder_input.text = prompts[idx]
                        self.placeholder_input.focus()
            except ValueError:
                logger.debug(
                    "Invalid sample prompt button id '%s'",
                    event.button.id,
                    exc_info=True,
                )
            event.stop()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Handle chooser selection confirmation via Enter."""
        if not self.is_chooser or event.list_view.id != "agent-chooser-list":
            return
        idx = event.list_view.index
        if idx is None:
            idx = self._chooser_selected_index
        if idx < 0 or idx >= len(self._chooser_modes):
            return
        self.post_message(self.AgentSelected(self._chooser_modes[idx]))


def _process_mermaid_in_content(content: str) -> str:
    """Process content to convert mermaid blocks to ASCII for terminal display."""

    def replace_mermaid(match: re.Match) -> str:
        mermaid_code = match.group(1).strip()
        ascii_art = _convert_mermaid_to_ascii(mermaid_code)
        if ascii_art != mermaid_code:
            # We got a useful conversion, show ASCII art and original
            return (
                f"**Diagram:**\n```\n{ascii_art}\n```\n\n"
                f"*Mermaid source (copy to mermaid.live):*\n```\n{mermaid_code}\n```"
            )
        else:
            # No conversion available, just show as code block
            return f"```\n{mermaid_code}\n```"

    pattern = r"```mermaid\s*([\s\S]*?)```"
    return re.sub(pattern, replace_mermaid, content)


def _try_parse_json_content(content: str) -> Any | None:
    """Parse JSON content safely, returning None on invalid JSON."""
    if not content:
        return None
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return None


def _parse_subagent_task_summary(content: str) -> tuple[str | None, str]:
    r"""Parse the `task()` tool return string into (subagent_type, body).

    The streaming subagent tool returns a plain-text summary like:
    "Subagent '<type>' completed:\\n\\n<final_output>"
    """
    match = re.match(
        r"^Subagent '([^']+)' completed:\\s*\\n\\n(.*)$", content, flags=re.DOTALL
    )
    if match:
        return match.group(1), match.group(2).strip()
    return None, content


def _format_tool_display(tool_name: str, args: Dict[str, Any]) -> str:
    """Format a tool call for friendly display in the chat."""
    info = TOOL_DISPLAY_INFO.get(
        tool_name, {"verb": f"Using {tool_name}", "icon": "🔨"}
    )

    if tool_name == "load_skill":
        skill_name = args.get("skill_name") or args.get("name") or ""
        if skill_name:
            return f"{info['icon']} {info['verb']}: {skill_name}"
        return f"{info['icon']} {info['verb']}..."

    if tool_name == "task":
        # Subagent delegation (pydantic-deep style: name/prompt; our streaming style: subagent_type/description)
        subagent_type = args.get("subagent_type") or args.get("name")
        if not subagent_type:
            # Args not yet available - will be updated when TOOL_CALL_ARGS arrives
            return "Starting Subagent..."
        # Map subagent_type to friendly display name
        display_name_map = {
            "graph_explorer": "Graph Explorer",
            "data_validator": "Data Validator",
            "data_explorer": "Data Explorer",
            "explorer": "Explorer",
            "planner": "Planner",
            "coder": "Coder",
            "tester": "Tester",
            "gitops": "GitOps",
        }
        display_name = display_name_map.get(
            str(subagent_type), subagent_type.replace("_", " ").title()
        )
        return f"Starting Subagent ({display_name})..."

    # Handle ticket-specific formatting
    if tool_name == "create_ticket":
        title = args.get("title", "")
        priority = args.get("priority", "")
        if title:
            priority_str = f" [{priority}]" if priority else ""
            return f'{info["icon"]} {info["verb"]}{priority_str}: "{title}"'
        return f"{info['icon']} {info['verb']}..."

    if tool_name == "get_ticket":
        ticket_id = args.get("ticket_id", "")
        if ticket_id:
            return f"{info['icon']} {info['verb']}: {ticket_id}"
        return f"{info['icon']} {info['verb']}..."

    if tool_name == "list_tickets":
        filters = []
        if args.get("status"):
            filters.append(f"status={args['status']}")
        if args.get("assigned_to"):
            filters.append(f"assigned={args['assigned_to']}")
        if args.get("priority"):
            filters.append(f"priority={args['priority']}")
        if filters:
            return f"{info['icon']} {info['verb']} ({', '.join(filters)})"
        return f"{info['icon']} {info['verb']}..."

    if tool_name == "update_ticket":
        ticket_id = args.get("ticket_id", "")
        updates = []
        if args.get("status"):
            updates.append(f"status→{args['status']}")
        if args.get("assigned_to"):
            updates.append(f"assign→{args['assigned_to']}")
        if args.get("priority"):
            updates.append(f"priority→{args['priority']}")
        if ticket_id and updates:
            return f"{info['icon']} {info['verb']} {ticket_id}: {', '.join(updates)}"
        elif ticket_id:
            return f"{info['icon']} {info['verb']}: {ticket_id}"
        return f"{info['icon']} {info['verb']}..."

    if tool_name == "add_ticket_comment":
        ticket_id = args.get("ticket_id", "")
        comment = args.get("comment", args.get("content", ""))
        if ticket_id:
            # Truncate comment preview
            preview = comment[:40] + "..." if len(comment) > 40 else comment
            if preview:
                return f'{info["icon"]} {info["verb"]} to {ticket_id}: "{preview}"'
            return f"{info['icon']} {info['verb']} to {ticket_id}"
        return f"{info['icon']} {info['verb']}..."

    # Default: Extract human-readable description if available
    description = (
        args.get("query_description")
        or args.get("query_name")
        or args.get("title")
        or ""
    )

    if description:
        return f'{info["icon"]} {info["verb"]}: "{description}"'
    else:
        return f"{info['icon']} {info['verb']}..."


class Message(Static):
    """A chat message widget with debounced markdown updates."""

    def __init__(
        self,
        role: str,
        content: str,
        tool_call_id: Optional[str] = None,
        has_artifact: bool = False,
        **kwargs,
    ):
        """Initialize the message widget."""
        super().__init__(**kwargs)
        self.role = role
        self.content_text = content
        self.tool_call_id = tool_call_id  # For tool messages, links to artifact
        self.has_artifact = has_artifact  # Whether tool produced viewable artifact
        self._pending_update = False
        self._update_timer = None
        self._finalized = False
        # Process mermaid blocks for display
        display_content = _process_mermaid_in_content(content)
        self.markdown = Markdown(display_content)

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield Label(f"[{self.role}]", classes=f"role-label {self.role}")
        yield self.markdown
        # Add action buttons for assistant messages (shown after finalize)
        if self.role == "assistant":
            with Horizontal(classes="message-actions"):
                yield Button("📋 Copy", id="msg-copy-btn", variant="default")
                yield Button("💾 Export", id="msg-export-btn", variant="default")
        # Add view button for tool messages with artifacts
        elif self.role == "tool" and self.tool_call_id and self.has_artifact:
            with Horizontal(classes="message-actions"):
                yield Button(
                    "🔍 View Result",
                    id=f"view-artifact-{self.tool_call_id}",
                    variant="default",
                )

    def on_mount(self) -> None:
        """Hide action buttons until message is finalized."""
        if self.role == "assistant":
            try:
                actions = self.query_one(".message-actions")
                actions.display = False
            except NoMatches:
                pass

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses for copy/export/view."""
        button_id = event.button.id
        if button_id == "msg-copy-btn":
            await self._copy_to_clipboard()
            event.stop()
        elif button_id == "msg-export-btn":
            await self._export_to_markdown()
            event.stop()
        elif button_id and button_id.startswith("view-artifact-"):
            # Bubble up to AgentChat to handle artifact navigation
            pass  # Event will bubble up

    async def _copy_to_clipboard(self) -> None:
        """Copy message content to clipboard."""
        try:
            self.app.copy_to_clipboard(self.content_text)
            self.app.notify("Copied to clipboard", title="✓")
        except Exception as e:
            logger.error(f"Failed to copy to clipboard: {e}")
            self.app.notify(f"Copy failed: {e}", severity="error")

    async def _export_to_markdown(self) -> None:
        """Export message content to a markdown file."""
        try:
            EXPORT_DIR.mkdir(parents=True, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"export_{timestamp}.md"
            filepath = EXPORT_DIR / filename
            filepath.write_text(self.content_text, encoding="utf-8")
            self.app.notify(f"Exported to {filepath}", title="💾 Saved")
        except Exception as e:
            logger.error(f"Failed to export: {e}")
            self.app.notify(f"Export failed: {e}", severity="error")

    def update_content(self, new_content: str):
        """Update the message content immediately."""
        self.content_text = new_content
        display_content = _process_mermaid_in_content(new_content)
        self.markdown.update(display_content)

    def append_content(self, chunk: str):
        """Append content to the message (debounced for performance)."""
        self.content_text += chunk
        self._pending_update = True
        # Schedule update if not already scheduled
        if self._update_timer is None:
            self._update_timer = self.set_timer(
                MARKDOWN_UPDATE_INTERVAL, self._flush_update
            )

    def _flush_update(self):
        """Flush pending markdown update."""
        self._update_timer = None
        if self._pending_update:
            self.markdown.update(self.content_text)
            self._pending_update = False
            if self.role == "assistant":
                self.post_message(ChatContentFlushed())

    def finalize(self):
        """Force final update when streaming completes."""
        if self._update_timer is not None:
            self._update_timer.stop()
            self._update_timer = None
        display_content = _process_mermaid_in_content(self.content_text)
        self.markdown.update(display_content)
        self._pending_update = False
        # Show action buttons for assistant messages
        self._finalized = True
        if self.role == "assistant":
            self.post_message(ChatContentFlushed())
        if self.role == "assistant":
            try:
                actions = self.query_one(".message-actions")
                actions.display = True
            except NoMatches:
                pass


# Spinner frames for animated progress
SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
SPINNER_INTERVAL = 0.5  # seconds between frames
MAX_ERROR_MESSAGE_LENGTH = 300


def _scalar_to_int(value: Any) -> Optional[int]:
    """Convert a Textual scalar-like value to int when possible."""
    scalar_value = getattr(value, "value", None)
    if scalar_value is None:
        return None
    try:
        return int(scalar_value)
    except (TypeError, ValueError):
        return None


def _clamp_height_to_style_bounds(widget: TextArea, desired_height: int) -> int:
    """Clamp desired height to the widget's style min/max bounds."""
    min_height = _scalar_to_int(widget.styles.min_height)
    max_height = _scalar_to_int(widget.styles.max_height)

    clamped_height = desired_height
    if min_height is not None:
        clamped_height = max(clamped_height, min_height)
    if max_height is not None:
        clamped_height = min(clamped_height, max_height)
    return clamped_height


class ToolMessage(Static):
    """Widget for tool calls with live spinner and timing."""

    def __init__(
        self,
        tool_name: str,
        display_text: str,
        tool_call_id: str,
        **kwargs,
    ):
        """Initialize the tool message widget."""
        super().__init__(**kwargs)
        self.tool_name = tool_name
        self.display_text = display_text
        self.tool_call_id = tool_call_id
        self.start_time = datetime.now()
        self.end_time: Optional[datetime] = None
        self.result_summary: Optional[str] = None
        self._spinner_index = 0
        self._spinner_timer = None
        self._is_running = True
        self._status_label: Label | None = None
        self._last_status_text: str | None = None

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield Label("", id="tool-status", classes="tool-status")
        # Note: message-actions is mounted dynamically in complete() to avoid artifacts

    def on_mount(self) -> None:
        """Start the spinner animation."""
        try:
            self._status_label = self.query_one("#tool-status", Label)
        except NoMatches:
            self._status_label = None
        self._update_display()
        self._spinner_timer = self.set_interval(SPINNER_INTERVAL, self._advance_spinner)

    def on_unmount(self) -> None:
        """Stop timers when unmounted."""
        self._stop_spinner()

    def _stop_spinner(self) -> None:
        """Stop spinner timer if active."""
        if self._spinner_timer:
            self._spinner_timer.stop()
            self._spinner_timer = None

    def _advance_spinner(self) -> None:
        """Advance the spinner animation frame."""
        if not self._is_running:
            return
        self._spinner_index = (self._spinner_index + 1) % len(SPINNER_FRAMES)
        self._update_display()

    def _update_display(self) -> None:
        """Update the status label with current state."""
        label = self._status_label
        if label is None:
            return

        elapsed = (datetime.now() - self.start_time).total_seconds()

        if self._is_running:
            spinner = SPINNER_FRAMES[self._spinner_index]
            status_text = f"{spinner} {self.display_text} ({int(elapsed)}s)"
        else:
            duration = (
                (self.end_time - self.start_time).total_seconds()
                if self.end_time
                else elapsed
            )
            result_text = f" → {self.result_summary}" if self.result_summary else ""
            status_text = f"✓ {self.display_text} ({duration:.1f}s){result_text}"

        if status_text != self._last_status_text:
            label.update(status_text)
            self._last_status_text = status_text

    def update_display_text(self, new_display_text: str) -> None:
        """Update the display text (e.g., when tool args become available).

        Args:
            new_display_text: New text to display for this tool call
        """
        self.display_text = new_display_text
        self._update_display()

    def complete(
        self, result_summary: Optional[str] = None, has_artifact: bool = False
    ) -> None:
        """Mark the tool call as complete.

        Args:
            result_summary: Summary text to display
            has_artifact: Whether this tool produced a viewable artifact
        """
        self._is_running = False
        self.end_time = datetime.now()
        self.result_summary = result_summary

        # Stop spinner
        self._stop_spinner()

        self._update_display()

        # Only mount view button if there's an artifact to view
        if has_artifact:
            actions = Horizontal(classes="message-actions")
            # Must mount parent first before mounting children
            self.mount(actions)
            actions.mount(
                Button(
                    "🔍 View Result",
                    id=f"view-artifact-{self.tool_call_id}",
                    variant="default",
                )
            )


class ToolResultBlock(Collapsible):
    """Collapsible widget for rendering a tool result using artifact-style widgets."""

    def __init__(
        self,
        title: str = "Result",
        content: str | None = None,
        renderer: Callable[[str], Static | None] | None = None,
    ):
        """Initialize a collapsible tool result block.

        Args:
            title: Header title for the collapsible panel.
            content: Optional lazy content to render only when expanded.
            renderer: Optional function to turn content into a widget.
        """
        self.body = Container(classes="tool-result-body")
        super().__init__(
            self.body, title=title, collapsed=True, classes="tool-result-block"
        )
        self._finalized = True
        self._pending_widgets: list[Static] = []
        self._lazy_content: str | None = content
        self._renderer: Callable[[str], Static | None] | None = renderer

    def on_mount(self) -> None:
        """Flush queued child widgets once mounted."""
        # Child widgets can't be mounted into `self.body` until `self.body` is mounted.
        # Defer flushing by one tick to ensure compose/mount has completed.
        if self._pending_widgets:
            self.call_later(self._flush_pending)

    def on_collapsible_expanded(self, event: Collapsible.Expanded) -> None:
        """Render lazy content the first time the block is expanded."""
        if event.collapsible is not self:
            return
        self._ensure_rendered()

    def mount_widget(self, widget: Static) -> None:
        """Mount a rendered widget into the collapsible body."""
        if self.body.is_mounted:
            self.body.mount(widget)
        else:
            self._pending_widgets.append(widget)

    def _flush_pending(self) -> None:
        """Flush any queued widgets into the body once mounted."""
        if not self._pending_widgets:
            return
        if not self.body.is_mounted:
            # Try again next tick.
            self.call_later(self._flush_pending)
            return
        for w in self._pending_widgets:
            self.body.mount(w)
        self._pending_widgets = []

    def _ensure_rendered(self) -> None:
        """Render lazy content into the body on first expansion."""
        if self._lazy_content is None:
            return
        # Don't render twice if something was already mounted (e.g., eager callers).
        if self.body.is_mounted and len(self.body.children) > 0:
            self._lazy_content = None
            return

        content = self._lazy_content
        self._lazy_content = None

        rendered: Static | None = None
        if self._renderer is not None:
            try:
                rendered = self._renderer(content)
            except Exception:
                rendered = None

        if rendered is None:
            rendered = Message(
                "tool", content, classes="message tool tool-inline-result"
            )

        self.mount_widget(rendered)


class ThinkingBlock(Collapsible):
    """Collapsible widget to display thinking process."""

    def __init__(self, content: str):
        """Initialize the thinking block."""
        self.markdown = Markdown(
            content, id="thinking-content", classes="thinking-content"
        )
        super().__init__(
            self.markdown, title="Thinking...", collapsed=True, classes="thinking-block"
        )
        self.content_text = content
        self._pending_update = False
        self._update_timer = None
        self._finalized = False

    def _update_header(self) -> None:
        """Update the header to show current state."""
        if self._finalized:
            # Show word count when finalized
            word_count = len(self.content_text.split())
            self.title = f"Thinking ({word_count} words)"
        else:
            self.title = "Thinking..."

    def update_content(self, new_content: str):
        """Update the thinking content immediately."""
        self.content_text = new_content
        self.markdown.update(new_content)

    def append_content(self, chunk: str):
        """Append content to the thinking block (debounced for performance)."""
        self.content_text += chunk
        self._pending_update = True
        # Schedule update if not already scheduled
        if self._update_timer is None:
            self._update_timer = self.set_timer(
                MARKDOWN_UPDATE_INTERVAL, self._flush_update
            )

    def _flush_update(self):
        """Flush pending markdown update."""
        self._update_timer = None
        if self._pending_update:
            self.markdown.update(self.content_text)
            self._pending_update = False

    def finalize(self):
        """Force final update when streaming completes."""
        if self._update_timer is not None:
            self._update_timer.stop()
            self._update_timer = None
        if self._pending_update:
            self.markdown.update(self.content_text)
            self._pending_update = False
        self._finalized = True
        self._update_header()


class ErrorPrompt(Static):
    """Widget for displaying errors with retry/restart actions."""

    def __init__(self, message: str, **kwargs):
        """Initialize the error prompt."""
        super().__init__(**kwargs)
        self.message = message

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield Markdown(self.message, classes="error-message")
        with Horizontal(classes="message-actions"):
            yield Button("🔁 Retry", id="retry-last-run", variant="primary")
            yield Button("🧹 Restart Chat", id="restart-chat", variant="default")


class SubagentActivityBlock(Collapsible):
    """Collapsible widget to display subagent tool-call highlights."""

    def __init__(self, subagent_type: str, activity_id: str):
        """Create a new subagent activity block.

        Args:
            subagent_type: The type/name of the delegated subagent.
            activity_id: Stable ID for grouping injected subagent tool events.
        """
        self.body = Container(
            id=f"subagent-body-{activity_id}", classes="subagent-body"
        )
        super().__init__(
            self.body,
            title=f"Subagent ({subagent_type})...",
            collapsed=True,
            classes="subagent-activity",
        )
        self.subagent_type = subagent_type
        self.activity_id = activity_id
        self._finalized = False
        self._tool_count = 0
        self._tools: dict[str, ToolMessage] = {}

    def _update_header(self) -> None:
        if self._finalized:
            self.title = f"Subagent ({self.subagent_type}) ({self._tool_count} tool call{'s' if self._tool_count != 1 else ''})"
        else:
            self.title = f"Subagent ({self.subagent_type})..."

    def add_tool_start(self, tool_call_id: str, tool_name: str) -> None:
        """Add a tool call spinner row inside the activity block."""
        display_text = _format_tool_display(tool_name, {})
        tool_msg = ToolMessage(
            tool_name=tool_name,
            display_text=display_text,
            tool_call_id=tool_call_id,
            classes="message tool subagent-tool",
            id=f"subagent-tool-{tool_call_id}",
        )
        self.body.mount(tool_msg)
        self._tools[tool_call_id] = tool_msg
        self._tool_count += 1
        self._update_header()

    def add_tool_result(self, tool_call_id: str, content: str | None = None) -> None:
        """Mark a previously-started tool call as completed and optionally show output inline."""
        tool_widget = self._tools.get(tool_call_id)
        if tool_widget:
            # Keep it lightweight; no artifacts for subagent highlights.
            tool_widget.complete(result_summary=None, has_artifact=False)
            if content:
                # Render tool output as a collapsible artifact-style panel under the tool call.
                panel = ToolResultBlock(
                    title="Result",
                    content=content,
                    renderer=AgentChat._render_tool_result_widget_static,
                )
                self.body.mount(panel, after=tool_widget)

    def finalize(self) -> None:
        """Finalize the block header (called when subagent completes)."""
        self._finalized = True
        self._update_header()


class SubagentStatusLine(Static):
    """Minimal status line for subagent delegation in user mode (verbose=False).

    Shows progress like Claude Code: "⠋ graph_explorer: query_graph..."
    """

    def __init__(self, subagent_type: str, activity_id: str):
        """Create a minimal status line for subagent work.

        Args:
            subagent_type: The type/name of the delegated subagent.
            activity_id: Stable ID for tracking this subagent execution.
        """
        super().__init__(classes="subagent-status-line")
        self.subagent_type = subagent_type
        self.activity_id = activity_id
        self.start_time = datetime.now()
        self._spinner_index = 0
        self._spinner_timer = None
        self._finalized = False
        self.duration: Optional[float] = None
        self._current_tool: Optional[str] = None
        self._tool_count = 0
        self._is_thinking = False
        self._status_label: Label | None = None
        self._last_status_text: str | None = None

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield Label("", id="subagent-status", classes="subagent-status-text")

    def on_mount(self) -> None:
        """Start the spinner animation."""
        try:
            self._status_label = self.query_one("#subagent-status", Label)
        except NoMatches:
            self._status_label = None
        self._update_display()
        self._spinner_timer = self.set_interval(SPINNER_INTERVAL, self._advance_spinner)

    def on_unmount(self) -> None:
        """Stop timers when unmounted."""
        self._stop_spinner()

    def _stop_spinner(self) -> None:
        """Stop spinner timer if active."""
        if self._spinner_timer:
            self._spinner_timer.stop()
            self._spinner_timer = None

    def _advance_spinner(self) -> None:
        """Advance the spinner animation frame."""
        if self._finalized:
            return
        self._spinner_index = (self._spinner_index + 1) % len(SPINNER_FRAMES)
        self._update_display()

    def update_tool(self, tool_name: str) -> None:
        """Update the current tool being executed.

        Args:
            tool_name: Name of the tool currently running.
        """
        self._current_tool = tool_name
        self._tool_count += 1
        self._is_thinking = False
        self._update_display()

    def tool_completed(self) -> None:
        """Mark the current tool as completed - shows 'thinking...' while waiting for next action."""
        self._current_tool = None
        self._is_thinking = True
        self._update_display()

    def _update_display(self) -> None:
        """Update the status label with current state."""
        label = self._status_label
        if label is None:
            return

        # No timer here - the parent task tool widget shows the timer
        if not self._finalized:
            spinner = SPINNER_FRAMES[self._spinner_index]
            if self._current_tool:
                # Claude Code style: show the current tool with friendly display name
                tool_info = TOOL_DISPLAY_INFO.get(
                    self._current_tool, {"verb": self._current_tool, "icon": "🔨"}
                )
                tool_display = f"{tool_info['icon']} {tool_info['verb']}"
                status_text = f"  {spinner} {tool_display}..."
            elif self._is_thinking:
                # Waiting for agent response after tool completed
                status_text = f"  {spinner} thinking..."
            else:
                status_text = f"  {spinner} starting..."
        else:
            # Show completion with tool count (indented to match active state)
            tool_info = f", {self._tool_count} tools" if self._tool_count > 0 else ""
            status_text = f"  ✓ done ({self.duration:.1f}s{tool_info})"

        if status_text != self._last_status_text:
            label.update(status_text)
            self._last_status_text = status_text

    def finalize(self, duration: float) -> None:
        """Mark the subagent as complete.

        Args:
            duration: Total execution time in seconds.
        """
        self._finalized = True
        self.duration = duration
        self._current_tool = None  # Clear current tool on completion
        self._stop_spinner()
        self._update_display()


class ChatInput(TextArea):
    """Multiline chat input that submits on Enter, Shift+Enter for newline."""

    BINDINGS = [
        ("ctrl+enter", "submit", "Send"),
    ]

    def on_key(self, event) -> None:
        """Handle Enter to submit, Shift+Enter for newline."""
        chat_area = self._chat_area()
        if _handle_slash_menu_key(event, chat_area, self):
            return

        if event.key == "ctrl+c":
            event.prevent_default()
            event.stop()
            confirm_exit = getattr(self.app, "action_confirm_exit", None)
            if callable(confirm_exit):
                confirm_exit()
            return
        # Ctrl+A opens artifacts modal (don't let TextArea consume it).
        if event.key == "ctrl+a":
            event.prevent_default()
            event.stop()
            open_artifacts = getattr(self.app, "action_open_artifacts", None)
            if callable(open_artifacts):
                open_artifacts()
            return
        # Ctrl+G opens activity modal (don't let TextArea consume it).
        if event.key == "ctrl+g":
            event.prevent_default()
            event.stop()
            open_activity = getattr(self.app, "action_open_activity", None)
            if callable(open_activity):
                open_activity()
            return
        # Shift+Enter inserts newline explicitly
        if event.key == "shift+enter":
            event.prevent_default()
            event.stop()
            self.insert("\n")
            return
        # Plain Enter submits
        if event.key == "enter":
            event.prevent_default()
            event.stop()
            self.action_submit()

    def on_text_area_changed(self, event) -> None:
        """Auto-expand height based on content."""
        del event
        self._adjust_height()
        chat_area = self._chat_area()
        if chat_area is not None:
            chat_area.update_slash_menu(self.text)

    def _adjust_height(self) -> None:
        """Adjust height based on number of lines."""
        line_count = self.text.count("\n") + 1
        # Add 1 for cursor line visibility, then clamp to style bounds.
        new_height = _clamp_height_to_style_bounds(self, line_count + 1)
        self.styles.height = new_height

    def action_submit(self) -> None:
        """Submit the input text."""
        if self.read_only:
            return
        if not self.text.strip():
            return
        self.post_message(ChatInput.Submitted(self.text))

    class Submitted(TextualMessage):
        """Event posted when user submits the input."""

        def __init__(self, value: str):
            """Initialize submitted message with input value."""
            super().__init__()
            self.value = value

    def _chat_area(self) -> Optional["ChatArea"]:
        """Get containing chat area when mounted."""
        try:
            return self.query_ancestor(ChatArea)
        except NoMatches:
            return None


class ChatArea(Container):
    """Container for chat history and input."""

    INPUT_HINT_TEXT = (
        "[bold]enter[/bold] send  [bold]shift+enter[/bold] newline"
        "  [bold]tab[/bold] complete command"
        "  [dim]tip: use /new to start a new chat session[/dim]"
    )
    BUSY_HINT_SPINNER_FRAMES = ("◐", "◓", "◑", "◒")
    BUSY_HINT_SPINNER_INTERVAL = 0.2
    BUSY_HINT_TEXT_TEMPLATE = (
        "[dim]{spinner} agent is working... input unlocks when response completes[/dim]"
    )
    INPUT_BUSY_ACTION_TEXT = "[dim][bold]ctrl+q[/bold] stop[/dim]"
    INPUT_BUSY_HINT_TEXT = BUSY_HINT_TEXT_TEMPLATE.format(
        spinner=BUSY_HINT_SPINNER_FRAMES[0]
    )

    def __init__(self, agent_chat: "AgentChat"):
        """Initialize the chat area."""
        super().__init__(classes="chat-area")
        self.agent_chat = agent_chat
        display_title = getattr(self.agent_chat, "display_agent_title", None)
        if not isinstance(display_title, str) or not display_title:
            mode_name = getattr(
                self.agent_chat,
                "display_agent_name",
                getattr(self.agent_chat, "agent_name", "agent"),
            )
            placeholder = AGENT_PLACEHOLDERS.get(str(mode_name), {})
            display_title = (
                placeholder.get("title") or str(mode_name).replace("_", " ").title()
            )
        self.agent_title = Label(
            display_title,
            id="chat-agent-title",
            classes="chat-agent-title",
        )
        self.artifacts_launcher = Button(
            "Artifacts",
            id="artifacts-launcher",
            classes="artifacts-launcher",
        )
        self.artifacts_launcher.display = False
        self.artifacts_launcher.disabled = True
        self._agent_header = Container(classes="chat-agent-header")
        self.chat_log = VerticalScroll(classes="chat-log")
        self.input = ChatInput(classes="chat-input")
        self.slash_menu = SlashCommandMenu()
        # Track autoscroll state - toggled via button
        self.autoscroll_enabled = True
        # Track placeholder for removal
        self._placeholder: Optional[AgentPlaceholder] = None
        # Reference to the input bar for show/hide
        self._input_bar: Optional[Container] = None
        self._input_hints: Optional[Static] = None
        self._input_hints_action: Optional[Static] = None
        self._busy_hint_spinner_index = 0
        self._busy_hint_timer = None

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        with self._agent_header:
            with Horizontal(classes="chat-agent-tools"):
                yield self.artifacts_launcher
            yield Static("~ ~ ~", classes="chat-agent-decoration")
            yield self.agent_title
            yield Static("~ ~ ~", classes="chat-agent-decoration")
        yield self.chat_log
        yield self.slash_menu
        self._input_bar = Container(classes="input-bar")
        with self._input_bar:
            yield self.input
            with Horizontal(classes="input-hints-row"):
                self._input_hints = Static(
                    self.INPUT_HINT_TEXT,
                    classes="input-hints",
                )
                yield self._input_hints
                self._input_hints_action = Static(
                    "",
                    classes="input-hints-action",
                )
                self._input_hints_action.display = False
                yield self._input_hints_action

    def on_mount(self) -> None:
        """Mount the placeholder after chat_log is in the DOM."""
        self.show_agent_chooser()

    def remove_placeholder(self) -> None:
        """Remove the placeholder widget if present."""
        if self._placeholder is not None:
            self._placeholder.remove()
            self._placeholder = None
            self.show_agent_header()
            # Show the bottom input bar when placeholder is removed
            if self._input_bar:
                self._input_bar.display = True
                self.input.focus()
            # Switch to top-aligned layout for messages
            self.chat_log.add_class("has-messages")

    def restore_placeholder(self) -> None:
        """Restore the placeholder widget if it was removed."""
        if self._placeholder is None:
            self._placeholder = AgentPlaceholder(self.agent_chat.display_agent_name)
            self.chat_log.mount(self._placeholder)
            self.hide_agent_header()
            # Hide the bottom input bar when placeholder is shown
            if self._input_bar:
                self._input_bar.display = False
            # Switch to center-aligned layout for placeholder
            self.chat_log.remove_class("has-messages")

    def refresh_placeholder(self) -> None:
        """Refresh placeholder content for current chat mode when visible."""
        if self._placeholder is None:
            return
        current_text = ""
        is_chooser = self._placeholder.is_chooser
        if self._placeholder.placeholder_input is not None:
            current_text = self._placeholder.placeholder_input.text
        self._placeholder.remove()
        self._placeholder = AgentPlaceholder(
            self.agent_chat.display_agent_name,
            chooser=is_chooser,
        )
        self.chat_log.mount(self._placeholder)
        if self._placeholder.placeholder_input is not None:
            self._placeholder.placeholder_input.text = current_text
            self._placeholder.placeholder_input.focus()

    def show_agent_chooser(self) -> None:
        """Show the neutral agent chooser placeholder."""
        if self._placeholder is not None:
            self._placeholder.remove()
        self._placeholder = AgentPlaceholder(
            self.agent_chat.display_agent_name,
            chooser=True,
        )
        self.chat_log.mount(self._placeholder)
        self.hide_agent_header()
        if self._input_bar:
            self._input_bar.display = False
        self.chat_log.remove_class("has-messages")

    def show_agent_placeholder(self) -> None:
        """Show the selected agent's placeholder after chooser confirmation."""
        if self._placeholder is not None:
            self._placeholder.remove()
        self._placeholder = AgentPlaceholder(self.agent_chat.display_agent_name)
        self.chat_log.mount(self._placeholder)
        self.hide_agent_header()
        if self._input_bar:
            self._input_bar.display = False
        self.chat_log.remove_class("has-messages")

    def update_agent_title(self, title: str) -> None:
        """Update the always-visible active-agent title text."""
        self.agent_title.update(title)

    def set_artifacts_available(self, count: int) -> None:
        """Show/hide artifacts launcher and update count label."""
        if count > 0:
            self.artifacts_launcher.label = f"Artifacts ({count})"
            self.artifacts_launcher.disabled = False
            self.artifacts_launcher.display = True
            return
        self.artifacts_launcher.label = "Artifacts"
        self.artifacts_launcher.disabled = True
        self.artifacts_launcher.display = False

    def _busy_hint_text(self) -> str:
        """Render busy hint text with current spinner frame."""
        spinner = self.BUSY_HINT_SPINNER_FRAMES[
            self._busy_hint_spinner_index % len(self.BUSY_HINT_SPINNER_FRAMES)
        ]
        return self.BUSY_HINT_TEXT_TEMPLATE.format(spinner=spinner)

    def _advance_busy_hint_spinner(self) -> None:
        """Advance busy-hint spinner frame and refresh hint text."""
        self._busy_hint_spinner_index = (self._busy_hint_spinner_index + 1) % len(
            self.BUSY_HINT_SPINNER_FRAMES
        )
        if self._input_hints is not None:
            self._input_hints.update(self._busy_hint_text())

    def _stop_busy_hint_spinner(self) -> None:
        """Stop busy-hint spinner timer when active."""
        if self._busy_hint_timer is not None:
            self._busy_hint_timer.stop()
            self._busy_hint_timer = None

    def set_input_busy(self, busy: bool) -> None:
        """Update chat input affordance for running-agent state."""
        if busy:
            self.input.add_class("chat-input-busy")
            if self._input_bar is not None:
                self._input_bar.add_class("input-bar-busy")
            if self._input_hints is not None:
                self._busy_hint_spinner_index = 0
                self._input_hints.update(self._busy_hint_text())
                self._input_hints.add_class("input-hints-busy")
                if self._input_hints_action is not None:
                    self._input_hints_action.update(self.INPUT_BUSY_ACTION_TEXT)
                    self._input_hints_action.display = True
                if self._busy_hint_timer is None:
                    self._busy_hint_timer = self.set_interval(
                        self.BUSY_HINT_SPINNER_INTERVAL,
                        self._advance_busy_hint_spinner,
                    )
            return

        self._stop_busy_hint_spinner()
        self.input.remove_class("chat-input-busy")
        if self._input_bar is not None:
            self._input_bar.remove_class("input-bar-busy")
        if self._input_hints is not None:
            self._input_hints.update(self.INPUT_HINT_TEXT)
            self._input_hints.remove_class("input-hints-busy")
        if self._input_hints_action is not None:
            self._input_hints_action.display = False

    def on_unmount(self) -> None:
        """Stop timers when chat area unmounts."""
        self._stop_busy_hint_spinner()

    def hide_agent_header(self) -> None:
        """Hide top agent header for empty/new chat state."""
        self._agent_header.display = False

    def show_agent_header(self) -> None:
        """Show top agent header when conversation is active."""
        self._agent_header.display = True

    def reset_placeholder(self) -> None:
        """Reset the placeholder reference (e.g., after remove_children)."""
        self._placeholder = None

    def close_slash_menu(self) -> None:
        """Close slash command popup."""
        self.slash_menu.hide_menu()

    def update_slash_menu(self, text: str) -> None:
        """Toggle and refresh slash command popup based on input text."""
        if not text.startswith("/"):
            self.close_slash_menu()
            return
        remainder = text[1:]
        if remainder and remainder[0].isspace():
            self.close_slash_menu()
            return
        if not remainder:
            self.slash_menu.update_query("")
            return
        if any(char.isspace() for char in remainder):
            self.close_slash_menu()
            return
        query = remainder
        if any(spec.command == f"/{query}" for spec in SLASH_COMMANDS):
            self.close_slash_menu()
            return
        self.slash_menu.update_query(query)

    def apply_slash_completion(self, input_widget: TextArea) -> bool:
        """Apply highlighted slash command to input text."""
        selected = self.slash_menu.selected()
        if selected is None:
            return False
        completed = f"{selected.command} "
        input_widget.text = completed
        input_widget.move_cursor((0, len(completed)))
        self.close_slash_menu()
        return True

    def execute_selected_slash_command(self, input_widget: TextArea) -> bool:
        """Execute highlighted slash command immediately."""
        selected = self.slash_menu.selected()
        if selected is None:
            return False
        self.close_slash_menu()
        slash_handlers: dict[str, Callable[[], None]] = {
            "/new": self.agent_chat._restart_chat,
            "/clear": self.agent_chat._restart_chat,
            "/status": self.agent_chat._show_status,
        }
        handler = slash_handlers.get(selected.command)
        if handler is None:
            return False
        input_widget.text = ""
        handler()
        return True

    @property
    def value(self) -> str:
        """Get the input value (compatibility with Input widget)."""
        return self.input.text

    @value.setter
    def value(self, val: str) -> None:
        """Set the input value (compatibility with Input widget)."""
        self.input.text = val


class AgentChat(Container):
    """Chat interface for a specific agent with artifact viewing."""

    BINDINGS = [
        ("f", "toggle_follow", "Toggle follow"),
    ]

    # Verbose mode toggle - shows detailed subagent tool calls when True
    verbose_mode = reactive(False)

    def __init__(self, agent_name: str, client: AguiClient):
        """Initialize the agent chat."""
        super().__init__()
        self.agent_name = agent_name
        self.display_agent_name = self._display_agent_name(agent_name)
        self.display_agent_title = self._display_agent_title(agent_name)
        self.client = client
        self.thread_id = f"tui-{uuid.uuid4().hex[:8]}"

        self.chat_area = ChatArea(self)
        self.artifact_viewer = ArtifactViewer()
        self._artifact_viewer_holder = Container(id="artifact-viewer-holder")
        self._refresh_artifacts_launcher()

        self.current_response: Optional[Message] = None
        self.thinking_widget: Optional[ThinkingBlock] = None
        self.subagent_blocks: Dict[str, SubagentActivityBlock] = {}
        self._pending_subagent_blocks: Dict[str, List[SubagentActivityBlock]] = {}

        # Subagent tracking for user mode (verbose=False)
        self.subagent_stats: Dict[
            str, SubagentStats
        ] = {}  # activity_id -> SubagentStats
        self.subagent_status_lines: Dict[
            str, SubagentStatusLine
        ] = {}  # activity_id -> widget
        self._pending_subagent_status_lines: Dict[str, List[SubagentStatusLine]] = {}

        # Track active tool widgets to update them instead of duplicating
        self.active_tool_widgets: dict[str, Message] = {}

        # Track full message history for context
        self.messages: list[dict] = []
        self.current_response_text: str = ""

        # Run stats tracking
        self.current_run_stats: Optional[RunStats] = None
        self.tool_call_to_artifact: Dict[str, str] = {}  # tool_call_id -> artifact_id
        self.active_tool_records: Dict[
            str, ToolCallRecord
        ] = {}  # tool_call_id -> record
        self.tool_args_buffer: Dict[
            str, str
        ] = {}  # tool_call_id -> accumulated args JSON

        # Report cell tracking - accumulate cells for cellular report viewer
        self.active_report_id: Optional[str] = None
        self.active_report_title: Optional[str] = None
        self.active_report_cells: List[CellData] = []
        self.active_report_artifact_id: Optional[str] = None  # Track artifact to update
        self._cell_order_times: Dict[
            str, float
        ] = {}  # cell_id -> order time for sorting

        # Plan tracking - map plan_id to sidebar artifact_id so all plan tool calls can link to the same artifact
        self.plan_id_to_artifact_id: Dict[str, str] = {}
        # Report tracking - map report_id to sidebar artifact_id for live report updates
        self.report_id_to_artifact_id: Dict[str, str] = {}

        # Task reference for cancellation support
        self._current_task: Optional[asyncio.Task] = None
        self.last_user_message: Optional[str] = None
        # Debounced autoscroll request flag (prevents redundant scroll_end calls per refresh)
        self._autoscroll_pending: bool = False
        self._perf = get_perf_logger()
        self._active_run_id: Optional[str] = None
        self._run_started_monotonic: Optional[float] = None
        self._first_token_logged = False
        self._assistant_first_paint_logged = False
        self._context_turn_cap = _resolve_context_turn_cap()

    def _log_perf_event(self, event: str, **payload: Any) -> None:
        """Emit structured perf events when enabled."""
        self._perf.log_event(event, **payload)

    @staticmethod
    def _display_agent_name(agent_name: str) -> str:
        """Map backend agent variants to user-facing mode names."""
        if agent_name.endswith("-flat"):
            return agent_name[: -len("-flat")]
        return agent_name

    @staticmethod
    def _display_agent_title(agent_name: str) -> str:
        """Resolve user-facing title for a mode using placeholder metadata."""
        mode_key = AgentChat._display_agent_name(agent_name)
        placeholder = AGENT_PLACEHOLDERS.get(mode_key, {})
        title = placeholder.get("title")
        if isinstance(title, str) and title:
            return title
        return mode_key.replace("_", " ").title()

    def set_agent_mode(
        self, mode: str, backend_agent_name: Optional[str] = None
    ) -> None:
        """Switch active agent mode for subsequent runs without resetting chat state."""
        self.display_agent_name = mode
        self.display_agent_title = self._display_agent_title(mode)
        self.agent_name = backend_agent_name or mode
        self.chat_area.update_agent_title(self.display_agent_title)
        self.chat_area.refresh_placeholder()

    def can_switch_mode(self) -> bool:
        """Return True when it is safe to switch agent mode in-place."""
        return not self.messages and not self.is_agent_running()

    def _request_autoscroll(self) -> None:
        """Request a scroll-to-bottom after the next refresh (debounced).

        Textual can render artifacts/overdraw when we mount/update many widgets inside a
        scrollable and immediately call scroll_end(). Scheduling after refresh reduces
        layout churn and keeps scrolling stable.
        """
        if not self.chat_area.autoscroll_enabled:
            return
        if self._autoscroll_pending:
            return
        self._autoscroll_pending = True
        self._log_perf_event(
            "autoscroll_scheduled",
            thread_id=self.thread_id,
            run_id=self._active_run_id,
        )
        # Textual 6.x supports call_after_refresh; keep a fallback just in case.
        try:
            self.call_after_refresh(self._perform_autoscroll)
        except Exception:
            self.call_later(self._perform_autoscroll)

    def _perform_autoscroll(self) -> None:
        """Perform the actual scroll-to-bottom (if still enabled)."""
        self._autoscroll_pending = False
        if self.chat_area.autoscroll_enabled:
            self.chat_area.chat_log.scroll_end(animate=False)

    def action_toggle_verbose(self) -> None:
        """Toggle verbose mode on/off."""
        self.verbose_mode = not self.verbose_mode
        mode_str = "ON" if self.verbose_mode else "OFF"
        self.app.notify(f"Verbose mode: {mode_str}", timeout=2)

    def action_toggle_autoscroll(self) -> None:
        """Toggle autoscroll on/off."""
        self.chat_area.autoscroll_enabled = not self.chat_area.autoscroll_enabled
        mode_str = "ON" if self.chat_area.autoscroll_enabled else "OFF"
        self.app.notify(f"Follow: {mode_str}", timeout=2)

    def action_toggle_follow(self) -> None:
        """Toggle follow mode on/off."""
        self.action_toggle_autoscroll()

    def _artifact_count(self) -> int:
        """Return count of user-visible artifacts."""
        return len(self.artifact_viewer.artifacts)

    def _refresh_artifacts_launcher(self) -> None:
        """Update launcher visibility and count."""
        set_available = getattr(self.chat_area, "set_artifacts_available", None)
        if callable(set_available):
            set_available(self._artifact_count())

    def _restore_artifact_viewer_mount(self) -> None:
        """Re-mount the shared artifact viewer into the hidden chat holder."""
        if not self.is_mounted or not self._artifact_viewer_holder.is_mounted:
            return
        try:
            parent = self.artifact_viewer.parent
        except Exception:
            parent = None
        if parent is self._artifact_viewer_holder:
            return
        if parent is not None:
            try:
                self.artifact_viewer.remove()
            except Exception as exc:
                logger.debug("Unable to detach artifact viewer on restore: %s", exc)
        try:
            self._artifact_viewer_holder.mount(self.artifact_viewer)
        except Exception as exc:
            logger.debug("Unable to restore artifact viewer mount immediately: %s", exc)
            if self.is_mounted:
                self.call_after_refresh(self._restore_artifact_viewer_mount)

    def action_open_artifacts(self) -> None:
        """Open artifacts modal if artifact data exists."""
        if self._artifact_count() <= 0:
            self.app.notify("No artifacts available yet", timeout=2)
            return
        if isinstance(self.app.screen, ArtifactsScreen):
            return
        self.app.push_screen(
            ArtifactsScreen(
                source_viewer=self.artifact_viewer,
                on_export_report=self._export_report_from_modal,
            )
        )

    def action_open_activity(self) -> None:
        """Open activity modal with recent run/subagent summaries."""
        if not self.artifact_viewer.activities:
            self.app.notify("No activity available yet", timeout=2)
            return
        if isinstance(self.app.screen, ActivityScreen):
            return
        self.app.push_screen(ActivityScreen(activities=self.artifact_viewer.activities))

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield self.chat_area
        with self._artifact_viewer_holder:
            yield self.artifact_viewer

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses, including 'View Result' buttons."""
        button_id = event.button.id
        if button_id == "retry-last-run":
            await self._retry_last_run()
            event.stop()
        elif button_id == "restart-chat":
            self._restart_chat()
            event.stop()
        elif button_id and button_id.startswith("view-artifact-"):
            # Extract tool_call_id from button ID
            tool_call_id = button_id.replace("view-artifact-", "")
            artifact_id = self.tool_call_to_artifact.get(tool_call_id)
            if artifact_id:
                self.artifact_viewer.select_artifact_by_id(artifact_id)
                self.action_open_artifacts()
            event.stop()
        elif button_id == "artifacts-launcher":
            self.action_open_artifacts()
            event.stop()

    def on_chat_input_submitted(self, event: ChatInput.Submitted) -> None:
        """Handle ChatInput submission (Ctrl+Enter)."""
        asyncio.create_task(self._submit_message())

    def on_placeholder_input_submitted(self, event: PlaceholderInput.Submitted) -> None:
        """Handle PlaceholderInput submission from new chat screen."""
        # Transfer the text to the main input and submit
        self.chat_area.input.text = event.value
        asyncio.create_task(self._submit_message())

    def on_agent_placeholder_agent_selected(
        self, event: AgentPlaceholder.AgentSelected
    ) -> None:
        """Handle chooser confirmation and enter agent-specific new chat view."""
        mode = event.mode
        try:
            app = self.app
        except Exception:
            app = getattr(self, "_app", None)
        set_chat_mode = getattr(app, "_set_chat_mode", None)
        if callable(set_chat_mode):
            set_chat_mode(mode)
        else:
            self.set_agent_mode(mode)
        self.chat_area.show_agent_placeholder()
        show_new_chat_tip = getattr(app, "maybe_show_new_chat_tip", None)
        if callable(show_new_chat_tip):
            show_new_chat_tip()
        event.stop()

    def on_chat_content_flushed(self, event: ChatContentFlushed) -> None:
        """Autoscroll after streaming content flushes."""
        if self._active_run_id and not self._assistant_first_paint_logged:
            self._assistant_first_paint_logged = True
            payload: dict[str, Any] = {
                "thread_id": self.thread_id,
                "run_id": self._active_run_id,
            }
            if self._run_started_monotonic is not None:
                payload["since_submit_ms"] = round(
                    (monotonic() - self._run_started_monotonic) * 1000,
                    2,
                )
            self._log_perf_event("assistant_first_paint", **payload)
        self._request_autoscroll()

    async def cancel_agent_run(self) -> bool:
        """Cancel the currently running agent task.

        Returns:
            True if a task was cancelled, False if no task was running.
        """
        if self._current_task and not self._current_task.done():
            self._current_task.cancel()
            try:
                await self._current_task
            except asyncio.CancelledError:
                pass
            return True
        return False

    def is_agent_running(self) -> bool:
        """Check if an agent task is currently running."""
        return self._current_task is not None and not self._current_task.done()

    def set_input_value(self, value: str) -> None:
        """Set the chat input value programmatically."""
        self.chat_area.input.text = value

    def focus_input(self) -> None:
        """Focus the chat input."""
        placeholder = getattr(self.chat_area, "_placeholder", None)
        if placeholder is not None and bool(getattr(placeholder, "is_chooser", False)):
            chooser_list = getattr(placeholder, "_chooser_list", None)
            if chooser_list is not None and callable(
                getattr(chooser_list, "focus", None)
            ):
                chooser_list.focus()
                return

        if placeholder is not None:
            placeholder_input = getattr(placeholder, "placeholder_input", None)
            if placeholder_input is not None and callable(
                getattr(placeholder_input, "focus", None)
            ):
                placeholder_input.focus()
                return

        self.chat_area.input.focus()

    async def on_export_report_request(self, event: ExportReportRequest) -> None:
        """Handle Export HTML button click from report viewer."""
        await self._export_report_by_ids(event.report_id, event.artifact_id)

    async def _export_report_from_modal(self, report_id: str, artifact_id: str) -> None:
        """Handle export requests forwarded from artifacts modal."""
        await self._export_report_by_ids(report_id, artifact_id)

    async def _export_report_by_ids(self, report_id: str, artifact_id: str) -> None:
        """Export a report and update artifact with generated HTML path."""
        try:
            # Fetch report from the backend API (source of truth)
            # This ensures we get the full cell data even if events were missed
            response = await self.client.http_client.get(
                f"{self.client.base_url}/reports/{report_id}",
            )

            if response.status_code == 200:
                report_data = response.json()
                title = report_data.get("title", "Report")
                cells_data = report_data.get("cells", [])

                if not cells_data:
                    self.app.notify("No report content to export", severity="warning")
                    return

                # Parse cells into CellData models
                cells = [CellData.model_validate(c) for c in cells_data]
                sorted_cells = sorted(cells, key=lambda c: c.cell_number)

                # Generate HTML locally
                html_path = self._export_report_to_html(
                    report_id=report_id,
                    title=title,
                    cells=sorted_cells,
                )

                # Update the artifact with the HTML path
                self.artifact_viewer.update_report_html_path(
                    artifact_id, str(html_path)
                )
                self.app.notify(f"Exported to {html_path.name}", title="Exported")
            else:
                logger.error(
                    f"Failed to fetch report {report_id}: HTTP {response.status_code}"
                )
                self.app.notify(
                    f"Failed to fetch report: HTTP {response.status_code}",
                    severity="error",
                )

        except Exception as e:
            logger.error(f"Failed to export report: {e}")
            self.app.notify(f"Export failed: {e}", severity="error")

    def _export_report_to_html(
        self, report_id: str, title: str, cells: List[CellData]
    ) -> Path:
        """Generate HTML file from report cells.

        Args:
            report_id: Report identifier
            title: Report title
            cells: List of CellData Pydantic models

        Returns:
            Path to the generated HTML file
        """
        import json as json_module

        # Create export directory
        export_dir = Path.home() / ".typedef" / "exports"
        export_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        html_path = export_dir / f"report_{report_id}_{timestamp}.html"

        # Serialize CellData models to dicts for JSON
        cells_json = json_module.dumps([c.model_dump() for c in cells], indent=2)

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/marked@11.1.1/marked.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/mermaid@10.9.1/dist/mermaid.min.js"></script>
    <style>
        :root {{
            --bg-primary: #111111;
            --bg-card: rgba(17, 17, 17, 0.8);
            --border-light: rgba(130, 157, 243, 0.3);
            --text-primary: #ffffff;
            --text-secondary: #a0a0a0;
            --analyst-color: #829df3;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            margin: 0;
            padding: 20px;
            line-height: 1.6;
        }}
        .report-container {{ max-width: 1200px; margin: 0 auto; }}
        .report-header {{
            margin-bottom: 40px;
            border-bottom: 1px solid var(--border-light);
            padding-bottom: 20px;
        }}
        .report-title {{ font-size: 32px; font-weight: 600; margin: 0 0 10px 0; }}
        .report-meta {{ color: var(--text-secondary); font-size: 14px; }}
        .cell {{
            background: var(--bg-card);
            border: 1px solid var(--border-light);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 24px;
        }}
        .cell-markdown h1, .cell-markdown h2, .cell-markdown h3 {{ color: var(--analyst-color); margin-top: 0; }}
        table {{ width: 100%; border-collapse: collapse; margin: 1em 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid var(--border-light); }}
        th {{ color: var(--analyst-color); font-weight: 600; }}
        canvas {{ max-width: 100%; height: auto !important; }}
        pre {{ background: rgba(0,0,0,0.3); padding: 16px; border-radius: 8px; overflow-x: auto; }}
        code {{ font-family: 'SF Mono', Monaco, monospace; }}
    </style>
</head>
<body>
    <div class="report-container">
        <div class="report-header">
            <h1 class="report-title">{title}</h1>
            <p class="report-meta">Generated from typedef Data Intelligence TUI</p>
        </div>
        <div id="cells"></div>
    </div>
    <script>
        const cells = {cells_json};
        mermaid.initialize({{ startOnLoad: false, theme: 'dark' }});

        function renderCells() {{
            const container = document.getElementById('cells');
            cells.forEach((cell, idx) => {{
                const div = document.createElement('div');
                div.className = 'cell cell-' + cell.cell_type;

                if (cell.cell_type === 'markdown') {{
                    div.innerHTML = marked.parse(cell.data.content || '');
                }} else if (cell.cell_type === 'table') {{
                    let html = cell.data.title ? '<h3>' + cell.data.title + '</h3>' : '';
                    html += '<table><thead><tr>';
                    (cell.data.columns || []).forEach(col => html += '<th>' + col + '</th>');
                    html += '</tr></thead><tbody>';
                    // Tables may store rows in either 'rows' or 'data' field
                    const rows = cell.data.rows || cell.data.data || [];
                    rows.forEach(row => {{
                        html += '<tr>';
                        if (Array.isArray(row)) {{
                            row.forEach(val => html += '<td>' + (val ?? '') + '</td>');
                        }} else {{
                            (cell.data.columns || []).forEach(col => html += '<td>' + (row[col] ?? '') + '</td>');
                        }}
                        html += '</tr>';
                    }});
                    html += '</tbody></table>';
                    div.innerHTML = html;
                }} else if (cell.cell_type === 'chart') {{
                    const title = cell.data.title || 'Chart';
                    const chartType = cell.data.chart_type || 'line';
                    const data = cell.data.data || [];
                    const xCol = cell.data.x_column;
                    const yCol = cell.data.y_column;
                    const seriesCol = cell.data.series_column;
                    // Display labels (default to column names)
                    const xLabel = cell.data.x_label || xCol;
                    const yLabel = cell.data.y_label || yCol;
                    const seriesLabel = cell.data.series_label || seriesCol;

                    // Color palette for multiple series
                    const colors = [
                        {{ bg: 'rgba(130, 157, 243, 0.6)', border: 'rgba(130, 157, 243, 1)' }},
                        {{ bg: 'rgba(243, 130, 157, 0.6)', border: 'rgba(243, 130, 157, 1)' }},
                        {{ bg: 'rgba(157, 243, 130, 0.6)', border: 'rgba(157, 243, 130, 1)' }},
                        {{ bg: 'rgba(243, 200, 130, 0.6)', border: 'rgba(243, 200, 130, 1)' }},
                        {{ bg: 'rgba(200, 130, 243, 0.6)', border: 'rgba(200, 130, 243, 1)' }},
                        {{ bg: 'rgba(130, 243, 230, 0.6)', border: 'rgba(130, 243, 230, 1)' }},
                    ];

                    div.innerHTML = '<h3>' + title + '</h3><canvas id="chart-' + idx + '"></canvas>';
                    container.appendChild(div);

                    setTimeout(() => {{
                        const ctx = document.getElementById('chart-' + idx);
                        if (ctx && data.length && xCol && yCol) {{
                            let labels, datasets;

                            if (seriesCol) {{
                                // Grouped/multi-series chart
                                const xValues = [...new Set(data.map(r => r[xCol]))].sort();
                                const seriesValues = [...new Set(data.map(r => r[seriesCol]))].sort();

                                // Build lookup: {{x_value: {{series_value: y_value}}}}
                                const lookup = {{}};
                                data.forEach(row => {{
                                    const x = row[xCol];
                                    const s = row[seriesCol];
                                    const y = row[yCol];
                                    if (!lookup[x]) lookup[x] = {{}};
                                    lookup[x][s] = y;
                                }});

                                labels = xValues;
                                datasets = seriesValues.map((seriesVal, i) => ({{
                                    label: String(seriesVal),
                                    data: xValues.map(x => lookup[x]?.[seriesVal] ?? 0),
                                    backgroundColor: colors[i % colors.length].bg,
                                    borderColor: colors[i % colors.length].border,
                                    borderWidth: 2
                                }}));
                            }} else {{
                                // Simple single-series chart
                                labels = data.map(r => r[xCol]);
                                datasets = [{{
                                    label: yLabel,
                                    data: data.map(r => r[yCol]),
                                    borderColor: colors[0].border,
                                    backgroundColor: chartType === 'area' ? colors[0].bg : colors[0].border,
                                    fill: chartType === 'area',
                                    borderWidth: 2
                                }}];
                            }}

                            new Chart(ctx, {{
                                type: chartType === 'area' ? 'line' : chartType,
                                data: {{ labels, datasets }},
                                options: {{
                                    responsive: true,
                                    plugins: {{
                                        legend: {{
                                            display: seriesCol ? true : false,
                                            labels: {{ color: '#fff' }},
                                            title: {{ display: seriesCol ? true : false, text: seriesLabel, color: '#fff' }}
                                        }}
                                    }},
                                    scales: chartType !== 'pie' ? {{
                                        x: {{
                                            title: {{ display: true, text: xLabel, color: '#e0e0e0' }},
                                            ticks: {{ color: '#e0e0e0' }},
                                            grid: {{ color: 'rgba(255,255,255,0.1)' }}
                                        }},
                                        y: {{
                                            title: {{ display: true, text: yLabel, color: '#e0e0e0' }},
                                            ticks: {{ color: '#e0e0e0' }},
                                            grid: {{ color: 'rgba(255,255,255,0.1)' }}
                                        }}
                                    }} : {{}}
                                }}
                            }});
                        }}
                    }}, 100);
                    return;
                }} else if (cell.cell_type === 'mermaid') {{
                    const title = cell.data.title || 'Diagram';
                    div.innerHTML = '<h3>' + title + '</h3><pre class="mermaid">' + (cell.data.diagram || '') + '</pre>';
                    container.appendChild(div);
                    return;
                }}
                container.appendChild(div);
            }});
            mermaid.run();
        }}
        renderCells();
    </script>
</body>
</html>"""

        html_path.write_text(html, encoding="utf-8")
        return html_path

    async def _submit_message(self) -> None:
        """Submit the current input message."""
        message = self.chat_area.input.text.strip()
        if not message:
            return
        self.chat_area.close_slash_menu()

        if message in {"/new", "/clear"}:
            self.chat_area.input.text = ""
            self._restart_chat()
            return

        if message == "/status":
            self.chat_area.input.text = ""
            self._show_status()
            return

        self.chat_area.input.text = ""
        self.chat_area.input.read_only = True
        self.chat_area.set_input_busy(True)

        # Re-enable autoscroll when user submits a new message
        self.chat_area.autoscroll_enabled = True

        # Add user message to history
        user_msg = {
            "role": "user",
            "content": message,
            "id": str(uuid.uuid4()),
        }
        self.messages.append(user_msg)
        self.last_user_message = message

        # Remove placeholder on first message
        self.chat_area.remove_placeholder()

        # Add user message to UI
        self.chat_area.chat_log.mount(Message("user", message, classes="message user"))
        self._request_autoscroll()

        # Reset state
        self.current_response = None
        self.thinking_widget = None
        self.current_response_text = ""

        # Initialize run stats
        run_id = f"run-{uuid.uuid4().hex[:8]}"
        self.current_run_stats = RunStats(
            run_id=run_id,
            agent_name=self.agent_name,
            start_time=datetime.now(),
            user_message=message,
        )
        self._active_run_id = run_id
        self._run_started_monotonic = monotonic()
        self._first_token_logged = False
        self._assistant_first_paint_logged = False
        self._log_perf_event(
            "chat_submit",
            thread_id=self.thread_id,
            run_id=run_id,
            agent_name=self.agent_name,
            message_chars=len(message),
            history_count=len(self.messages),
        )
        self.active_tool_records = {}
        self.tool_args_buffer = {}

        # Stream response (store task for cancellation support)
        self._current_task = asyncio.create_task(self.stream_response(message, run_id))

    async def stream_response(self, message: str, run_id: str):
        """Stream response from the agent."""
        try:
            outbound_messages = self._build_context_messages_for_send()
            async for event in self.client.stream_agent(
                self.agent_name,
                message,
                self.thread_id,
                run_id,
                messages=outbound_messages,
            ):
                if not isinstance(event, dict):
                    logger.warning(f"Skipping non-dict event: {event!r}")
                    continue
                event_type = event.get("type")

                if event_type == "TEXT_MESSAGE_START":
                    self.current_response = Message(
                        "assistant", "", classes="message assistant"
                    )
                    self.chat_area.chat_log.mount(self.current_response)
                    self._request_autoscroll()

                elif event_type == "TEXT_MESSAGE_CONTENT":
                    chunk = event.get("delta", "")
                    if (
                        self._active_run_id
                        and not self._first_token_logged
                        and isinstance(chunk, str)
                        and chunk
                    ):
                        self._first_token_logged = True
                        payload: dict[str, Any] = {
                            "thread_id": self.thread_id,
                            "run_id": self._active_run_id,
                        }
                        if self._run_started_monotonic is not None:
                            payload["since_submit_ms"] = round(
                                (monotonic() - self._run_started_monotonic) * 1000,
                                2,
                            )
                        self._log_perf_event("first_token_received", **payload)
                    self.current_response_text += chunk  # Track full response
                    if self.current_response:
                        self.current_response.append_content(chunk)
                    else:
                        self.current_response = Message(
                            "assistant", chunk, classes="message assistant"
                        )
                        self.chat_area.chat_log.mount(self.current_response)

                elif event_type == "THINKING_TEXT_MESSAGE_CONTENT":
                    chunk = event.get("delta", "")
                    if not self.thinking_widget:
                        self.thinking_widget = ThinkingBlock(chunk)
                        if self.current_response:
                            self.chat_area.chat_log.mount(
                                self.thinking_widget, before=self.current_response
                            )
                        else:
                            self.chat_area.chat_log.mount(self.thinking_widget)
                        self._request_autoscroll()
                    else:
                        self.thinking_widget.append_content(chunk)

                elif event_type == "CUSTOM":
                    name = event.get("name")
                    value = event.get("value") or {}
                    if name == "subagent_activity_start":
                        activity_id = str(value.get("activity_id") or "")
                        subagent_type = str(value.get("subagent_type") or "subagent")
                        parent_tool_call_id = str(
                            value.get("parent_tool_call_id") or ""
                        )
                        input_prompt = str(value.get("input_prompt") or "")

                        if activity_id and activity_id not in self.subagent_stats:
                            # Always create stats for tracking
                            self.subagent_stats[activity_id] = SubagentStats(
                                activity_id=activity_id,
                                subagent_type=subagent_type,
                                start_time=datetime.now(),
                                input_prompt=input_prompt if input_prompt else None,
                            )

                            if self.verbose_mode:
                                # Developer mode: Full SubagentActivityBlock with tool calls
                                block = SubagentActivityBlock(
                                    subagent_type=subagent_type, activity_id=activity_id
                                )
                                # Expand by default in verbose mode
                                block.collapsed = False
                                self.subagent_blocks[activity_id] = block

                                # Prefer mounting AFTER the parent task tool call widget.
                                if (
                                    parent_tool_call_id
                                    and parent_tool_call_id in self.active_tool_widgets
                                ):
                                    self.chat_area.chat_log.mount(
                                        block,
                                        after=f"#tool-{parent_tool_call_id}",
                                    )
                                elif parent_tool_call_id:
                                    self._pending_subagent_blocks.setdefault(
                                        parent_tool_call_id, []
                                    ).append(block)
                                else:
                                    if self.current_response:
                                        self.chat_area.chat_log.mount(
                                            block, before=self.current_response
                                        )
                                    else:
                                        self.chat_area.chat_log.mount(block)
                            else:
                                # User mode: Simple status line (no tool call details)
                                status_line = SubagentStatusLine(
                                    subagent_type=subagent_type, activity_id=activity_id
                                )
                                self.subagent_status_lines[activity_id] = status_line

                                # Same mounting logic as block
                                if (
                                    parent_tool_call_id
                                    and parent_tool_call_id in self.active_tool_widgets
                                ):
                                    self.chat_area.chat_log.mount(
                                        status_line,
                                        after=f"#tool-{parent_tool_call_id}",
                                    )
                                elif parent_tool_call_id:
                                    self._pending_subagent_status_lines.setdefault(
                                        parent_tool_call_id, []
                                    ).append(status_line)
                                else:
                                    if self.current_response:
                                        self.chat_area.chat_log.mount(
                                            status_line, before=self.current_response
                                        )
                                    else:
                                        self.chat_area.chat_log.mount(status_line)
                    elif name == "subagent_activity_end":
                        activity_id = str(value.get("activity_id") or "")

                        # Update stats
                        stats = self.subagent_stats.get(activity_id)
                        if stats:
                            stats.end_time = datetime.now()

                        if self.verbose_mode:
                            # Finalize the full block
                            block = self.subagent_blocks.get(activity_id)
                            if block:
                                block.finalize()
                        else:
                            # Finalize status line
                            status_line = self.subagent_status_lines.get(activity_id)
                            if (
                                status_line
                                and stats
                                and stats.duration_seconds is not None
                            ):
                                status_line.finalize(stats.duration_seconds)

                        # Add summary to sidebar Activity tab (both modes)
                        # Don't force-show the viewer just for activity summaries
                        if stats:
                            self.artifact_viewer.show_subagent_summary(stats)
                            self._refresh_artifacts_launcher()
                    elif name == "plan_snapshot":
                        # Handle live plan updates from subagent execution
                        plan = value.get("plan")
                        plan_id = value.get("plan_id")
                        tool_call_id = str(value.get("parent_tool_call_id") or "")
                        if (
                            isinstance(plan, dict)
                            and isinstance(plan_id, str)
                            and plan_id
                        ):
                            existing = self.plan_id_to_artifact_id.get(plan_id)
                            if existing:
                                self.artifact_viewer.update_plan(
                                    artifact_id=existing, plan=plan
                                )
                                self._refresh_artifacts_launcher()
                                if tool_call_id:
                                    self.tool_call_to_artifact[tool_call_id] = existing
                            else:
                                artifact_id = self.artifact_viewer.show_plan(
                                    title=str(plan.get("title") or "Plan"),
                                    plan=plan,
                                    tool_call_id=tool_call_id or None,
                                )
                                self._refresh_artifacts_launcher()
                                self.plan_id_to_artifact_id[plan_id] = artifact_id
                                if tool_call_id:
                                    self.tool_call_to_artifact[tool_call_id] = (
                                        artifact_id
                                    )
                    elif name == "context_brief":
                        brief_data = value.get("brief")
                        tool_call_id = str(value.get("parent_tool_call_id") or "")
                        if isinstance(brief_data, dict):
                            try:
                                brief = ContextBrief.model_validate(brief_data)
                                self.artifact_viewer.display = True
                                artifact_id = self.artifact_viewer.show_context_brief(
                                    brief=brief,
                                    tool_call_id=tool_call_id or None,
                                )
                                self._refresh_artifacts_launcher()
                                if tool_call_id:
                                    self.tool_call_to_artifact[tool_call_id] = (
                                        artifact_id
                                    )
                            except Exception:
                                logger.error(
                                    f"Error parsing context brief: {brief_data}"
                                )
                    elif name == "report_snapshot":
                        # Handle live report updates from subagent execution
                        # Parse at the boundary into typed Pydantic model
                        report_data = value.get("report")
                        tool_call_id = str(value.get("parent_tool_call_id") or "")
                        if isinstance(report_data, dict):
                            try:
                                report = ReportPreview.model_validate(report_data)
                                existing = self.report_id_to_artifact_id.get(
                                    report.report_id
                                )
                                artifact_id: Optional[str] = None
                                if existing:
                                    # Update existing report artifact
                                    self.artifact_viewer.update_report_cells(
                                        existing, report.cells
                                    )
                                    artifact_id = existing
                                    if tool_call_id:
                                        self.tool_call_to_artifact[tool_call_id] = (
                                            existing
                                        )
                                else:
                                    # Create new report artifact
                                    artifact_id = (
                                        self.artifact_viewer.show_report_cells(
                                            title=report.title,
                                            report_id=report.report_id,
                                            cells=report.cells,
                                            tool_call_id=tool_call_id or None,
                                        )
                                    )
                                    self._refresh_artifacts_launcher()
                                    self.report_id_to_artifact_id[report.report_id] = (
                                        artifact_id
                                    )
                                    if tool_call_id:
                                        self.tool_call_to_artifact[tool_call_id] = (
                                            artifact_id
                                        )
                                # Track active report for export button at run end
                                self.active_report_id = report.report_id
                                self.active_report_title = report.title
                                self.active_report_cells = report.cells
                                self.active_report_artifact_id = artifact_id
                            except Exception:
                                logger.error(
                                    f"Error parsing report snapshot: {report_data}"
                                )

                elif event_type == "TOOL_CALL_START":
                    tool_name = event.get("toolCallName", "Unknown Tool")
                    tool_call_id = event.get("toolCallId", "unknown")
                    tool_args = event.get("toolCallArgs", {})

                    # Route injected subagent tool-call highlights.
                    if (
                        isinstance(tool_call_id, str)
                        and tool_call_id.startswith("subact_")
                        and "__" in tool_call_id
                    ):
                        activity_id = tool_call_id[len("subact_") :].split("__", 1)[0]

                        # Always track in stats
                        stats = self.subagent_stats.get(activity_id)
                        if stats:
                            tool_record = ToolCallRecord(
                                tool_call_id=tool_call_id,
                                tool_name=tool_name,
                                display_text=_format_tool_display(
                                    tool_name,
                                    tool_args if isinstance(tool_args, dict) else {},
                                ),
                                start_time=datetime.now(),
                            )
                            stats.tool_calls.append(tool_record)

                        # Render based on verbose mode
                        if self.verbose_mode:
                            # Full tool call in SubagentActivityBlock
                            block = self.subagent_blocks.get(activity_id)
                            if block:
                                block.add_tool_start(
                                    tool_call_id=tool_call_id, tool_name=tool_name
                                )
                                self._request_autoscroll()
                        else:
                            # Claude Code style: update status line with current tool
                            status_line = self.subagent_status_lines.get(activity_id)
                            if status_line:
                                status_line.update_tool(tool_name)
                        continue

                    # Parse args if they're a string
                    if isinstance(tool_args, str):
                        try:
                            tool_args = json.loads(tool_args)
                        except json.JSONDecodeError:
                            tool_args = {}

                    # Format friendly display message
                    display_text = _format_tool_display(tool_name, tool_args)

                    # Create tool message with live spinner
                    tool_msg = ToolMessage(
                        tool_name=tool_name,
                        display_text=display_text,
                        tool_call_id=tool_call_id,
                        classes="message tool",
                        id=f"tool-{tool_call_id}",
                    )
                    self.chat_area.chat_log.mount(tool_msg)
                    self.active_tool_widgets[tool_call_id] = tool_msg
                    self._request_autoscroll()

                    # Mount any pending subagent blocks that were waiting for this tool call.
                    pending_blocks = self._pending_subagent_blocks.pop(tool_call_id, [])
                    for block in pending_blocks:
                        self.chat_area.chat_log.mount(block, after=tool_msg)

                    # Mount any pending subagent status lines (user mode).
                    pending_status_lines = self._pending_subagent_status_lines.pop(
                        tool_call_id, []
                    )
                    for status_line in pending_status_lines:
                        self.chat_area.chat_log.mount(status_line, after=tool_msg)

                    # Track tool call for run stats
                    tool_record = ToolCallRecord(
                        tool_call_id=tool_call_id,
                        tool_name=tool_name,
                        display_text=display_text,
                        start_time=datetime.now(),
                    )
                    self.active_tool_records[tool_call_id] = tool_record
                    if self.current_run_stats:
                        self.current_run_stats.tool_calls.append(tool_record)

                elif event_type == "TOOL_CALL_ARGS":
                    # AG-UI sends args in chunks (deltas) after TOOL_CALL_START
                    tool_call_id = event.get("toolCallId", "unknown")
                    args_delta = event.get("delta", "")

                    # Skip subagent tool calls (already handled in TOOL_CALL_START)
                    if isinstance(tool_call_id, str) and tool_call_id.startswith(
                        "subact_"
                    ):
                        continue

                    # Accumulate args deltas
                    if args_delta:
                        self.tool_args_buffer[tool_call_id] = (
                            self.tool_args_buffer.get(tool_call_id, "") + args_delta
                        )

                    # Try to parse accumulated args and update display for task tools
                    tool_msg = self.active_tool_widgets.get(tool_call_id)
                    if (
                        tool_msg
                        and isinstance(tool_msg, ToolMessage)
                        and tool_msg.tool_name == "task"
                    ):
                        accumulated = self.tool_args_buffer.get(tool_call_id, "")
                        if accumulated:
                            try:
                                tool_args = json.loads(accumulated)
                                new_display = _format_tool_display("task", tool_args)
                                tool_msg.update_display_text(new_display)
                            except json.JSONDecodeError:
                                pass  # Args not complete yet, keep waiting

                elif event_type == "TOOL_CALL_RESULT":
                    tool_call_id = event.get("toolCallId", "unknown")
                    content = event.get("content", "{}")
                    parsed_content = _try_parse_json_content(content)

                    # Route injected subagent tool-call results.
                    if (
                        isinstance(tool_call_id, str)
                        and tool_call_id.startswith("subact_")
                        and "__" in tool_call_id
                    ):
                        activity_id = tool_call_id[len("subact_") :].split("__", 1)[0]

                        # Update tool record end time in stats
                        stats = self.subagent_stats.get(activity_id)
                        if stats:
                            for tc in stats.tool_calls:
                                if (
                                    tc.tool_call_id == tool_call_id
                                    and tc.end_time is None
                                ):
                                    tc.end_time = datetime.now()
                                    break

                        # Render based on verbose mode
                        if self.verbose_mode:
                            block = self.subagent_blocks.get(activity_id)
                            if block:
                                block.add_tool_result(
                                    tool_call_id=tool_call_id, content=content
                                )
                                self._request_autoscroll()
                        else:
                            # Show "thinking..." while waiting for next action
                            status_line = self.subagent_status_lines.get(activity_id)
                            if status_line:
                                status_line.tool_completed()
                        continue

                    # Update tool record end time
                    if tool_call_id in self.active_tool_records:
                        self.active_tool_records[tool_call_id].end_time = datetime.now()

                    # Handle Artifacts and get artifact_id if created
                    artifact_id = self._handle_artifact(
                        tool_call_id, content, parsed_content
                    )

                    # Link tool call to artifact
                    if artifact_id and tool_call_id in self.active_tool_records:
                        self.active_tool_records[tool_call_id].artifact_id = artifact_id
                        self.tool_call_to_artifact[tool_call_id] = artifact_id

                    # Generate result summary from content
                    result_summary = self._generate_result_summary(
                        content, parsed_content
                    )

                    # Complete tool message with result summary
                    if tool_call_id in self.active_tool_widgets:
                        tool_widget = self.active_tool_widgets[tool_call_id]
                        if isinstance(tool_widget, ToolMessage):
                            tool_widget.complete(
                                result_summary, has_artifact=artifact_id is not None
                            )
                        else:
                            # Fallback for old Message widgets
                            tool_widget.append_content("\n✅ Completed.")
                    else:
                        # Should rarely happen, but fallback
                        self.chat_area.chat_log.mount(
                            Message("tool", "Tool finished", classes="message tool")
                        )

                    # Inline render non-report tool outputs under the tool call (keeps sidebar focused on reports).
                    data = parsed_content
                    tool_name = (
                        data.get("tool_name") if isinstance(data, dict) else None
                    )
                    is_report_tool = tool_name in {
                        "create_report",
                        "add_markdown_cell",
                        "add_chart_cell",
                        "add_mermaid_cell",
                        "add_table_cell",
                        "export_report_html",
                    }
                    # Skill tools return raw text content — suppress the result panel entirely
                    is_skill_tool = tool_name in {
                        "load_skill",
                        "list_skills",
                        "read_skill_resource",
                    }
                    if (
                        not is_report_tool
                        and not is_skill_tool
                        and tool_call_id in self.active_tool_widgets
                    ):
                        tool_widget = self.active_tool_widgets[tool_call_id]
                        tool_name_for_call = None
                        if isinstance(tool_widget, ToolMessage):
                            tool_name_for_call = tool_widget.tool_name

                        panel_title = "Result"
                        panel: ToolResultBlock

                        if tool_name_for_call == "task" and isinstance(content, str):
                            subagent_type, body = _parse_subagent_task_summary(content)
                            panel_title = (
                                f"Subagent summary ({subagent_type})"
                                if subagent_type
                                else "Subagent summary"
                            )
                            panel = ToolResultBlock(
                                title=panel_title,
                                content=body,
                                renderer=lambda c: Markdown(
                                    _process_mermaid_in_content(c),
                                    classes="tool-inline-subagent-summary",
                                ),
                            )
                            panel.add_class("tool-result-subagent-summary")
                        else:
                            # Capture parsed_content in closure default to avoid
                            # late-binding (ruff B023)
                            panel = ToolResultBlock(
                                title=panel_title,
                                content=content,
                                renderer=lambda c,
                                pc=parsed_content: self._render_tool_result_widget(
                                    c, pc
                                ),
                            )
                        self.chat_area.chat_log.mount(panel, after=tool_widget)

                    self._request_autoscroll()

                elif event_type in {"RUN_ERROR", "ERROR"}:
                    error_text = (
                        event.get("error") or event.get("message") or "Unknown error"
                    )
                    error_message = self._format_error_message(RuntimeError(error_text))
                    self.chat_area.chat_log.mount(
                        ErrorPrompt(error_message, classes="message error")
                    )
                    self._request_autoscroll()
                    # Mark any running tool widgets as failed
                    for tool_widget in self.active_tool_widgets.values():
                        if (
                            isinstance(tool_widget, ToolMessage)
                            and tool_widget._is_running
                        ):
                            tool_widget.complete(
                                result_summary="failed", has_artifact=False
                            )

        except asyncio.CancelledError:
            logger.info("Agent run cancelled by user")
            # Show cancellation message in chat
            self.chat_area.chat_log.mount(
                Message("system", "⚠ Agent run cancelled", classes="message system")
            )
            # Append truncation marker to response text so agent knows it was interrupted
            if self.current_response_text:
                self.current_response_text += "\n\n[Response interrupted by user]"
            # Don't re-raise - let finally block clean up
        except Exception as e:
            logger.error(f"Error streaming response: {e}")
            error_message = self._format_error_message(e)
            self.chat_area.chat_log.mount(
                ErrorPrompt(error_message, classes="message error")
            )
        finally:
            total_duration_ms: Optional[float] = None
            if self._run_started_monotonic is not None:
                total_duration_ms = round(
                    (monotonic() - self._run_started_monotonic) * 1000,
                    2,
                )
            self._log_perf_event(
                "stream_finished",
                thread_id=self.thread_id,
                run_id=run_id,
                first_token_seen=self._first_token_logged,
                assistant_first_paint_seen=self._assistant_first_paint_logged,
                duration_ms=total_duration_ms,
            )
            self._current_task = None  # Clear task reference
            # Finalize any pending markdown updates
            if self.current_response:
                self.current_response.finalize()
            if self.thinking_widget:
                self.thinking_widget.finalize()

            # Add assistant response to message history for context
            if self.current_response_text:
                assistant_msg = {
                    "role": "assistant",
                    "content": self.current_response_text,
                    "id": str(uuid.uuid4()),
                }
                self.messages.append(assistant_msg)

            try:
                # Finalize run stats and add activity summary (without forcing viewer open)
                if self.current_run_stats:
                    self.current_run_stats.end_time = datetime.now()
                    self.current_run_stats.response_char_count = len(
                        self.current_response_text
                    )
                    # Add activity summary to viewer (user can see it if they open the pane)
                    # Don't force-show the viewer just for activity summaries
                    self.artifact_viewer.show_activity_summary(self.current_run_stats)
                    self._refresh_artifacts_launcher()

                # Mark active report as ready for export (shows Export button)
                if self.active_report_artifact_id:
                    self.artifact_viewer.mark_report_ready(
                        self.active_report_artifact_id
                    )
            except Exception as exc:
                logger.error("Error finalizing artifact state: %s", exc)
            finally:
                self.chat_area.input.read_only = False
                self.chat_area.set_input_busy(False)
                self.chat_area.input.focus()
                self._active_run_id = None
                self._run_started_monotonic = None
                self._first_token_logged = False
                self._assistant_first_paint_logged = False

    def _build_context_messages_for_send(self) -> list[dict[str, Any]]:
        """Build bounded message history payload for backend context send.

        UI-visible transcript remains unchanged; this only affects outbound request
        payload size in long-running sessions.
        """
        if self._context_turn_cap <= 0:
            return list(self.messages)

        # Keep the last N turns for context. During submit there is typically an
        # odd count (latest user prompt without assistant response yet), so retain
        # up to 2N-1 trailing messages.
        max_messages = max(1, (self._context_turn_cap * 2) - 1)
        if len(self.messages) <= max_messages:
            return list(self.messages)
        return list(self.messages[-max_messages:])

    async def _retry_last_run(self) -> None:
        """Retry the last user message without duplicating it in history."""
        if self.is_agent_running():
            self.app.notify("An agent run is already in progress.", severity="warning")
            return
        if not self.last_user_message:
            self.app.notify("No previous message to retry.", severity="warning")
            return

        # Remove any stale assistant response from a failed run
        if self.messages and self.messages[-1].get("role") == "assistant":
            self.messages.pop()

        self.current_response = None
        self.thinking_widget = None
        self.current_response_text = ""

        run_id = f"run-{uuid.uuid4().hex[:8]}"
        self.current_run_stats = RunStats(
            run_id=run_id,
            agent_name=self.agent_name,
            start_time=datetime.now(),
            user_message=self.last_user_message,
        )
        self._active_run_id = run_id
        self._run_started_monotonic = monotonic()
        self._first_token_logged = False
        self._assistant_first_paint_logged = False
        self._log_perf_event(
            "chat_submit",
            thread_id=self.thread_id,
            run_id=run_id,
            agent_name=self.agent_name,
            message_chars=len(self.last_user_message),
            history_count=len(self.messages),
            retry=True,
        )
        self.active_tool_records = {}
        # Re-enable autoscroll when user retries (same as new message submission)
        self.chat_area.autoscroll_enabled = True
        self._request_autoscroll()
        self.chat_area.input.read_only = True
        self.chat_area.set_input_busy(True)
        self._current_task = asyncio.create_task(
            self.stream_response(self.last_user_message, run_id)
        )

    def _restart_chat(self) -> None:
        """Clear chat history and start a new thread."""
        if self.is_agent_running():
            self.app.notify(
                "Stop the current run before restarting chat.", severity="warning"
            )
            return

        self.thread_id = f"tui-{uuid.uuid4().hex[:8]}"
        self.messages = []
        self.current_response = None
        self.thinking_widget = None
        self.current_response_text = ""
        self.active_tool_widgets = {}
        self.active_tool_records = {}
        self.tool_call_to_artifact = {}
        self.active_report_id = None
        self.active_report_title = None
        self.active_report_cells = []
        self.active_report_artifact_id = None
        self._cell_order_times = {}
        self.last_user_message = None

        self.chat_area.chat_log.remove_children()
        # Reset placeholder reference since widget was removed from DOM
        self.chat_area.reset_placeholder()
        if self.is_mounted:
            self._restore_artifact_viewer_mount()
            self.artifact_viewer.clear_history()
        else:
            logger.debug("Skipping artifact viewer UI reset while chat is not mounted.")
        self._refresh_artifacts_launcher()

        # Restore the placeholder
        self.chat_area.hide_agent_header()
        show_chooser = getattr(self.chat_area, "show_agent_chooser", None)
        if callable(show_chooser):
            show_chooser()
        else:
            self.chat_area.restore_placeholder()

        try:
            self.app.notify("Chat restarted.", severity="information")
        except Exception as exc:
            logger.debug("Skip restart notification outside app context: %s", exc)

    def _show_status(self) -> None:
        """Open the session status modal with current state."""
        from time import monotonic

        from lineage.tui.screens.status import StatusData, StatusScreen

        app = self.app
        status_bar = getattr(app, "status_bar", None)

        # Resolve model name from app-level config map
        agent_model_map: dict[str, str] = getattr(app, "_agent_model_map", {})
        model = agent_model_map.get(self.display_agent_name, "unknown")

        # Compute uptime
        startup_at = getattr(app, "_startup_started_at", None)
        uptime = monotonic() - startup_at if startup_at is not None else 0.0

        # Count messages by role
        user_count = sum(1 for m in self.messages if m.get("role") == "user")
        assistant_count = sum(1 for m in self.messages if m.get("role") == "assistant")

        # Last run stats
        last_run = self.current_run_stats
        last_run_id = last_run.run_id if last_run else None
        last_run_duration = last_run.duration_seconds if last_run else None
        last_run_tool_calls = last_run.tool_call_count if last_run else 0

        data = StatusData(
            agent_name=self.display_agent_name,
            model=model,
            thread_id=self.thread_id,
            uptime_seconds=uptime,
            context_cap=self._context_turn_cap,
            message_count=len(self.messages),
            user_message_count=user_count,
            assistant_message_count=assistant_count,
            last_run_id=last_run_id,
            last_run_duration=last_run_duration,
            last_run_tool_calls=last_run_tool_calls,
            artifact_count=len(self.artifact_viewer.artifacts),
            activity_count=len(self.artifact_viewer.activities),
            backend_status=status_bar.backend_status if status_bar else "unknown",
            graph_status=status_bar.graph_status if status_bar else "unknown",
            data_status=status_bar.data_status if status_bar else "unknown",
            project_name=getattr(app, "active_project", "default"),
            verbose_mode=self.verbose_mode,
            flat_mode=getattr(app, "flat_mode", False),
        )
        app.push_screen(StatusScreen(data))

    def _format_error_message(self, error: Exception) -> str:
        """Create a user-facing error message with retry guidance."""
        if isinstance(error, AGUIRequestError):
            detail = error.detail or "Unknown error"
            detail = detail.replace("\n", " ").strip()
            if len(detail) > MAX_ERROR_MESSAGE_LENGTH:
                detail = detail[:MAX_ERROR_MESSAGE_LENGTH] + "..."
            status = (
                f"HTTP {error.status_code}"
                if error.status_code is not None
                else "Request error"
            )
            return (
                f"**Agent request failed** ({status}).\n\n"
                f"**Details**: {detail}\n\n"
                "You can retry this request or restart the chat."
            )

        message = str(error).strip() or "Unknown error"
        if len(message) > MAX_ERROR_MESSAGE_LENGTH:
            message = message[:MAX_ERROR_MESSAGE_LENGTH] + "..."
        return (
            "**Agent request failed**.\n\n"
            f"**Details**: {message}\n\n"
            "You can retry this request or restart the chat."
        )

    def _handle_artifact(
        self,
        tool_call_id: str,
        content: str,
        parsed_content: Any | None = None,
    ) -> Optional[str]:
        """Process tool result content and update artifact viewer.

        Uses Pydantic models for type-safe parsing when tool_name is available,
        with structural detection for protocol types and heuristic fallback.

        Args:
            tool_call_id: ID of the tool call that produced this result
            content: JSON string of tool result
            parsed_content: Pre-parsed content object, if available

        Returns:
            artifact_id if an artifact was created, None otherwise
        """
        # Subagent tool results are rendered inline in the subagent activity block
        # (we still show spinners), so avoid duplicating into the artifact sidebar.
        if tool_call_id.startswith("subact_"):
            return None

        if not content:
            return None

        data = (
            parsed_content
            if parsed_content is not None
            else _try_parse_json_content(content)
        )
        if data is None:
            return None

        # Handle list results
        if isinstance(data, list):
            # Check if it's a list of todos (from get_todos)
            if (
                data
                and isinstance(data[0], dict)
                and all(k in data[0] for k in ("id", "content", "status", "priority"))
            ):
                artifact_id = self.artifact_viewer.show_todos(
                    todos=data,
                    tool_call_id=tool_call_id,
                )
                self._refresh_artifacts_launcher()
                return artifact_id
            # Other list results don't have typed parsing - just return None for artifacts
            return None

        # Try typed parsing first
        tool_name = data.get("tool_name")
        model_class = self.TOOL_RESULT_MODELS.get(tool_name) if tool_name else None

        if model_class:
            try:
                result = model_class.model_validate(data)
                artifact_id = self._handle_typed_artifact(tool_call_id, result)
                if artifact_id:
                    return artifact_id
            except ValidationError:
                pass  # Fall through to structural/heuristic parsing

        # Try structural detection for protocol types (no tool_name)
        artifact_id = self._handle_protocol_artifact(tool_call_id, data)
        if artifact_id:
            return artifact_id

        # Fallback to heuristic detection
        return self._handle_untyped_artifact(tool_call_id, data)

    def _add_report_cell(
        self,
        cell_type: str,
        cell_data: Dict[str, Any],
        tool_call_id: str,
    ) -> None:
        """Add a cell to the active report with proper ordering.

        Args:
            cell_type: Type of cell (chart, table, mermaid, markdown)
            cell_data: Cell-specific data
            tool_call_id: Tool call ID for ordering
        """
        # Get tool call start time for ordering (cells may arrive out of order)
        tool_record = self.active_tool_records.get(tool_call_id)
        # Use current time as fallback if tool record not found (avoids cells at position 0)
        order_time = (
            tool_record.start_time.timestamp()
            if tool_record
            else datetime.now().timestamp()
        )

        # Create CellData with temporary cell_number (will be reassigned after sorting)
        import uuid as uuid_mod

        cell_id = f"cell-{uuid_mod.uuid4().hex[:8]}"
        cell = CellData(
            cell_id=cell_id,
            cell_type=cell_type,
            cell_number=len(self.active_report_cells) + 1,
            data=cell_data,
        )
        # Track order time separately for sorting
        self._cell_order_times[cell_id] = order_time
        self.active_report_cells.append(cell)

        # Sort cells by tool call start time, then reassign cell_numbers
        sorted_cells = sorted(
            self.active_report_cells,
            key=lambda c: self._cell_order_times.get(c.cell_id, 0),
        )
        # Reassign cell_numbers based on sorted order
        for i, c in enumerate(sorted_cells, start=1):
            c.cell_number = i

        if self.active_report_artifact_id:
            self.artifact_viewer.update_report_cells(
                artifact_id=self.active_report_artifact_id,
                cells=sorted_cells,
            )

    def _handle_typed_artifact(
        self, tool_call_id: str, result: BaseModel
    ) -> Optional[str]:
        """Handle artifact display for typed Pydantic model results."""
        # Discovery and Analysis results - render inline only, skip sidebar artifact.
        # This keeps the sidebar focused on "real" artifacts like plans and reports.
        if isinstance(
            result,
            (
                PreviewTableResult,
                ExecuteQueryResult,
                ContextBrief,
                QueryGraphResult,
                GraphSearchResult,
                SearchModelsResult,
                ModelDetailsResult,
                DownstreamImpactResult,
                RelationLineageResult,
            ),
        ):
            return None

        # Report creation - create ONE artifact that will be updated as cells are added
        if isinstance(result, CreateReportResult):
            self.active_report_id = result.report_id
            self.active_report_title = result.title
            self.active_report_cells = []  # Reset cells for new report
            self._cell_order_times = {}  # Reset order tracking
            # Create the report artifact (empty initially) and track its ID
            self.active_report_artifact_id = self.artifact_viewer.show_report_cells(
                title=result.title,
                report_id=result.report_id,
                cells=[],  # Empty initially, will be updated as cells are added
                html_path=None,
                tool_call_id=tool_call_id,
            )
            self._refresh_artifacts_launcher()
            return self.active_report_artifact_id

        # CLI output (bash/dbt) - render inline only, not in sidebar
        if isinstance(result, (BashResult, DbtResult)):
            return None

        # Chart cell - update existing report (no new artifact)
        # Cell mutation tools - sidebar updates handled by report_snapshot CustomEvent
        if isinstance(result, CellAck):
            return None

        # Ticket operations - render inline only, not in sidebar
        if isinstance(
            result,
            (
                CreateTicketResult,
                ListTicketsResult,
                GetTicketResult,
                UpdateTicketResult,
                AddTicketCommentResult,
            ),
        ):
            return None

        # Plan read tools (get_plan, get_active_plan) - display plan from PlanView.plan field
        if isinstance(result, PlanView):
            plan = result.plan
            plan_id = result.plan_id
            if plan and isinstance(plan, dict) and plan_id:
                existing = self.plan_id_to_artifact_id.get(plan_id)
                if existing:
                    self.artifact_viewer.update_plan(artifact_id=existing, plan=plan)
                    self._refresh_artifacts_launcher()
                    self.tool_call_to_artifact[tool_call_id] = existing
                    return existing
                else:
                    artifact_id = self.artifact_viewer.show_plan(
                        title=str(plan.get("title") or "Plan"),
                        plan=plan,
                        tool_call_id=tool_call_id,
                    )
                    self._refresh_artifacts_launcher()
                    self.plan_id_to_artifact_id[plan_id] = artifact_id
                    self.tool_call_to_artifact[tool_call_id] = artifact_id
                    return artifact_id
            return None

        # Plan mutation tools - sidebar updates handled by plan_snapshot CustomEvent
        if isinstance(result, PlanAck):
            return None

        return None

    @staticmethod
    def _render_tool_result_widget_static(
        content: str,
        parsed_content: Any | None = None,
    ) -> Static | None:
        """Render tool result content into an artifact-style widget (no sidebar/history)."""
        if not content:
            return None
        data = (
            parsed_content
            if parsed_content is not None
            else _try_parse_json_content(content)
        )
        if data is None:
            return None

        if isinstance(data, list):
            # If it's a list of dicts, render as a table
            if data and isinstance(data[0], dict):
                from lineage.tui.widgets.artifacts.helpers import _render_as_table

                table_markdown = _render_as_table(data)
                return Markdown(table_markdown, classes="tool-inline-table")
            # Otherwise dump as JSON
            return Markdown(
                json.dumps(data, indent=2)[:5000], classes="tool-inline-json"
            )

        if not isinstance(data, dict):
            text = str(data)
            # Wrap SQL/DDL strings in a code block for syntax highlighting
            sql_keywords = ("create ", "select ", "alter ", "drop ", "insert ", "with ")
            if text.lower().lstrip().startswith(sql_keywords):
                return Markdown(f"```sql\n{text}\n```", classes="tool-inline-text")
            return Markdown(text, classes="tool-inline-text")

        tool_name = data.get("tool_name")
        # Any result with columns + rows gets a table widget (QueryResult shape)
        if "columns" in data and "rows" in data:
            return build_table_widget(
                columns=data.get("columns", []), rows=data.get("rows", [])
            )

        # TablePreview shape (preview_table): table_schema.columns + sample_rows
        if "table_schema" in data and "sample_rows" in data:
            schema = data.get("table_schema", {})
            col_defs = schema.get("columns", [])
            col_names = [
                c.get("name", "") if isinstance(c, dict) else str(c) for c in col_defs
            ]
            return build_table_widget(
                columns=col_names, rows=data.get("sample_rows", [])
            )

        if tool_name in {"query_graph"} and "nodes" in data:
            return build_graph_result_widget(
                title=data.get("query_description") or "Graph Query Results",
                nodes=data.get("nodes", []),
                query_description=data.get("query_description") or "",
                display_hint=data.get("display_hint"),
            )

        if tool_name in {"search_graph", "search_models"} and (
            "matches" in data or "results" in data
        ):
            term = data.get("term") or data.get("search_term") or ""
            results = data.get("matches") or data.get("results") or []
            return build_search_results_widget(search_term=str(term), results=results)

        if tool_name == "grep_files":
            pattern = data.get("pattern") or ""
            matches = data.get("matches") or []
            match_count = data.get("match_count") or len(matches)
            files_searched = data.get("files_searched") or 0
            content_parts = [f'## 🔎 File Search: "{_escape_markdown(pattern)}"', ""]
            content_parts.append(
                f"**Matches:** {match_count} in {files_searched} files"
            )
            content_parts.append("")
            if not matches:
                content_parts.append("*No matches found*")
                return Markdown("\n".join(content_parts), classes="file-search-results")
            for i, match in enumerate(matches[:20], 1):
                if not isinstance(match, dict):
                    continue
                file_path = _escape_markdown(match.get("file") or "?")
                line = match.get("line") or "?"
                content = _escape_markdown((match.get("content") or "").rstrip())
                content_parts.append(f"{i}. `{file_path}:{line}`")
                if content:
                    content_parts.append(f"   > {content}")
                content_parts.append("")
            if match_count > 20:
                content_parts.append(f"*... and {match_count - 20} more*")
            return Markdown("\n".join(content_parts), classes="file-search-results")

        if tool_name == "glob_files":
            pattern = data.get("pattern") or ""
            files = data.get("files") or []
            count = data.get("count") or len(files)
            content_parts = [f'## 📁 File Matches: "{_escape_markdown(pattern)}"', ""]
            content_parts.append(f"**Found:** {count} file{'s' if count != 1 else ''}")
            content_parts.append("")
            if not files:
                content_parts.append("*No files matched*")
                return Markdown("\n".join(content_parts), classes="file-glob-results")
            for file_path in files[:50]:
                content_parts.append(f"- `{_escape_markdown(file_path)}`")
            if count > 50:
                content_parts.append(f"- *... and {count - 50} more*")
            return Markdown("\n".join(content_parts), classes="file-glob-results")

        if tool_name == "read_file":
            file_path = data.get("file_path") or "?"
            start_line = data.get("start_line")
            end_line = data.get("end_line")
            line_count = data.get("line_count")
            content = data.get("content") or ""

            content_parts = [f"## 📖 File Preview: `{_escape_markdown(file_path)}`", ""]
            if line_count is not None:
                content_parts.append(f"**Total Lines:** {line_count}")
            if start_line is not None and end_line is not None:
                content_parts.append(f"**Showing Lines:** {start_line}-{end_line}")
            content_parts.append("")

            max_chars = 2500
            preview = content
            if len(preview) > max_chars:
                preview = preview[:max_chars] + "\n... (truncated)"

            if preview.strip():
                content_parts.append("```")
                content_parts.append(preview.rstrip())
                content_parts.append("```")
            else:
                content_parts.append("*File is empty*")
            return Markdown("\n".join(content_parts), classes="file-read-results")

        if tool_name in {"get_model_details"} and "model_id" in data:
            return build_model_details_widget(model_details=data)

        if tool_name in {"get_model_materializations"} and "materializations" in data:
            mats = data.get("materializations", [])
            if mats and isinstance(mats[0], dict):
                cols = ["environment", "type", "fqn", "warehouse_type"]
                rows = [[m.get(c, "") for c in cols] for m in mats]
                return build_table_widget(columns=cols, rows=rows)

        # TableSchema shape (get_table_schema): columns is List[Dict] with column metadata
        if (
            "table_name" in data
            and "columns" in data
            and isinstance(data["columns"], list)
        ):
            col_defs = data["columns"]
            if col_defs and isinstance(col_defs[0], dict):
                header = list(col_defs[0].keys())
                rows = [[c.get(h, "") for h in header] for c in col_defs]
                return build_table_widget(columns=header, rows=rows)

        if tool_name in {"get_downstream_impact"} and "affected_models" in data:
            return build_impact_tree_widget(
                model_name=data.get("model_name") or data.get("model_id") or "Model",
                affected_models=data.get("affected_models") or [],
                total=int(data.get("total_affected") or 0),
            )

        # Relation/column lineage results often come from protocol types and may not include tool_name.
        if all(
            k in data for k in ("identifier", "direction", "nodes", "node_type")
        ) or all(k in data for k in ("root", "direction", "nodes")):
            return build_lineage_widget(lineage=data)

        if tool_name in {
            "create_plan",
            "get_plan",
            "get_active_plan",
            "add_plan_section",
            "update_plan_section",
            "add_plan_step",
            "update_plan_step",
            "add_plan_question",
            "update_plan_question",
            "answer_plan_question",
            "finalize_plan",
            "reopen_plan",
        }:
            # Plan tools now return a compact ack; the full plan is updated via CUSTOM plan_snapshot.
            msg = data.get("message") or ""
            pid = data.get("plan_id") or ""
            status = data.get("status") or ""
            err = data.get("error")
            lines = [f"**Plan:** `{pid}`", ""]
            if status:
                lines.append(f"**Status:** {status}")
                lines.append("")
            if msg:
                lines.append(str(msg))
            if err:
                lines.append("")
                lines.append(f"**Error:** {err}")
            return Markdown("\n".join(lines), classes="tool-inline-text")

        # Command output (bash/dbt) - inline rendering
        if (
            tool_name in {"bash", "dbt_cli"}
            and "command" in data
            and "exit_code" in data
        ):
            title = "dbt command" if tool_name == "dbt_cli" else "bash command"
            return build_command_output_widget(
                command=data.get("command", ""),
                exit_code=data.get("exit_code", 0),
                stdout=data.get("stdout", ""),
                stderr=data.get("stderr"),
                working_dir=data.get("working_dir") or data.get("project_dir"),
                title=title,
            )

        # Ticket creation - inline rendering
        if tool_name == "create_ticket" and "ticket_id" in data:
            return build_ticket_update_widget(
                ticket_id=data.get("ticket_id", ""),
                action="created",
                message=f"Created ticket **{data.get('title', 'Untitled')}**\n\nStatus: {data.get('status', 'open')} | Priority: {data.get('priority', 'medium')}",
            )

        # Ticket list - inline rendering
        if tool_name == "list_tickets" and "tickets" in data:
            return build_ticket_list_widget(
                tickets=data.get("tickets", []),
                count=data.get("count", 0),
            )

        # Get ticket details - inline rendering
        if tool_name == "get_ticket" and "ticket" in data:
            return build_ticket_widget(ticket=data.get("ticket", {}))

        # Update ticket - inline rendering
        if tool_name == "update_ticket" and "ticket_id" in data:
            return build_ticket_update_widget(
                ticket_id=data.get("ticket_id", ""),
                action="updated",
                message=data.get("message", "Ticket updated"),
            )

        # Add ticket comment - inline rendering
        if tool_name == "add_ticket_comment" and "ticket_id" in data:
            return build_ticket_update_widget(
                ticket_id=data.get("ticket_id", ""),
                action="commented",
                message=data.get("message", "Comment added"),
            )

        # Subject area tools - inline rendering
        if tool_name == "list_subject_areas" and "subject_areas" in data:
            return build_subject_area_list_widget(
                subject_areas=data.get("subject_areas", []),
                total_count=data.get("total_count", 0),
            )
        if tool_name == "get_subject_area_details" and "name" in data:
            return build_subject_area_details_widget(details=data)
        if tool_name == "find_related_subject_areas" and "related" in data:
            source = data.get("source_subject_area", "?")
            related = data.get("related", [])
            parts = [f"## Related to: {_escape_markdown(source)}", ""]
            if related:
                for r in related[:10]:
                    if isinstance(r, dict):
                        rname = r.get("name", "?")
                        rtype = r.get("relationship_type", "")
                        strength = r.get("strength", 0)
                        parts.append(
                            f"- **{rname}** ({rtype}, strength: {strength:.2f})"
                        )
            else:
                parts.append("*No related subject areas found*")
            return Markdown("\n".join(parts), classes="related-areas")
        if tool_name == "search_by_domain" and "domain" in data:
            return build_domain_search_widget(
                domain=data.get("domain", ""),
                subject_areas=[
                    sa if isinstance(sa, dict) else {}
                    for sa in data.get("subject_areas", [])
                ],
                models=[
                    m if isinstance(m, dict) else {} for m in data.get("models", [])
                ],
            )

        # Diagnostics - inline rendering
        if tool_name in {
            "run_key_diagnostics",
            "run_join_diagnostics",
            "run_relationship_health_check",
        }:
            return build_diagnostics_widget(data=data, diag_type=tool_name)

        # list_skills: plain dict[str, str] with no tool_name — render as skill catalog
        if (
            tool_name is None
            and data
            and all(isinstance(v, str) for v in data.values())
        ):
            count = len(data)
            lines = [f"**{count} skill{'s' if count != 1 else ''} available:**", ""]
            for skill_name, desc in sorted(data.items()):
                lines.append(
                    f"- **{_escape_markdown(skill_name)}**: {_escape_markdown(desc)}"
                )
            return Markdown("\n".join(lines), classes="tool-inline-text")

        # Fallback: show pretty JSON
        return Markdown(json.dumps(data, indent=2)[:5000], classes="tool-inline-json")

    def _render_tool_result_widget(
        self,
        content: str,
        parsed_content: Any | None = None,
    ) -> Static | None:
        """Instance wrapper for static rendering (keeps call sites clean)."""
        return self._render_tool_result_widget_static(content, parsed_content)

    def _handle_protocol_artifact(
        self, tool_call_id: str, data: Dict[str, Any]
    ) -> Optional[str]:
        """Handle artifacts from protocol types that don't have tool_name."""
        # RelationLineageResult - render inline only.
        if all(k in data for k in ("identifier", "direction", "nodes", "node_type")):
            return None

        return None

    def _handle_untyped_artifact(
        self, tool_call_id: str, data: Dict[str, Any]
    ) -> Optional[str]:
        """Fallback heuristic handling for unrecognized result formats."""
        # Report with html_path
        if "html_path" in data:
            artifact_id = self.artifact_viewer.show_report(
                title=data.get("title") or data.get("report_id") or "Report",
                report_path=data.get("html_path"),
                message=data.get("message"),
                tool_call_id=tool_call_id,
            )
            self._refresh_artifacts_launcher()
            return artifact_id

        # Table with rows/columns - render inline only, skip sidebar artifact
        # (these are displayed via _render_tool_result_widget in ToolResultBlock)
        if "rows" in data and "columns" in data:
            return None

        # Graph nodes - render inline only.
        if "nodes" in data and isinstance(data["nodes"], list):
            return None

        # Todo results - check for todo-like structure
        # Single todo item (from add_todo/update_todo)
        if all(k in data for k in ("id", "content", "status", "priority")):
            artifact_id = self.artifact_viewer.show_todos(
                todos=[data],
                tool_call_id=tool_call_id,
            )
            self._refresh_artifacts_launcher()
            return artifact_id

        # Todo summary (from get_summary)
        if all(k in data for k in ("total", "pending", "in_progress", "completed")):
            # This is a summary, but we need the actual todos to display
            # The summary alone isn't enough - we'll just show it in the summary text
            # and not create an artifact (the summary will be shown in the tool message)
            return None

        return None

    # Tool result model registry - maps tool_name to Pydantic model class
    TOOL_RESULT_MODELS: Dict[str, type] = {
        "query_graph": QueryGraphResult,
        "search_graph": GraphSearchResult,
        "preview_table": PreviewTableResult,
        "execute_query": ExecuteQueryResult,
        "search_models": SearchModelsResult,
        "get_model_details": ModelDetailsResult,
        "get_downstream_impact": DownstreamImpactResult,
        "list_subject_areas": ListSubjectAreasResult,
        "get_subject_area_details": SubjectAreaDetailsResult,
        "find_related_subject_areas": RelatedSubjectAreasResult,
        "search_by_domain": DomainSearchResult,
        "create_report": CreateReportResult,
        "add_chart_cell": CellAck,
        "add_table_cell": CellAck,
        "add_mermaid_cell": CellAck,
        "add_markdown_cell": CellAck,
        # CLI tools
        "bash": BashResult,
        "dbt_cli": DbtResult,
        # Plan tools — read tools return PlanView, mutation tools return PlanAck
        "get_plan": PlanView,
        "get_active_plan": PlanView,
        "create_plan": PlanAck,
        "add_plan_section": PlanAck,
        "update_plan_section": PlanAck,
        "add_plan_step": PlanAck,
        "update_plan_step": PlanAck,
        "add_plan_question": PlanAck,
        "update_plan_question": PlanAck,
        "answer_plan_question": PlanAck,
        "finalize_plan": PlanAck,
        "reopen_plan": PlanAck,
        # Ticket tools
        "create_ticket": CreateTicketResult,
        "list_tickets": ListTicketsResult,
        "get_ticket": GetTicketResult,
        "update_ticket": UpdateTicketResult,
        "add_ticket_comment": AddTicketCommentResult,
    }

    def _generate_result_summary(
        self,
        content: str,
        parsed_content: Any | None = None,
    ) -> Optional[str]:
        """Generate a human-readable summary from tool result content.

        Uses Pydantic models from lineage.agent.pydantic.types for type-safe parsing.

        Args:
            content: JSON string of tool result
            parsed_content: Pre-parsed content object, if available

        Returns:
            Short summary like "12 rows", "15 results", etc.
        """
        if not content:
            return None

        data = (
            parsed_content
            if parsed_content is not None
            else _try_parse_json_content(content)
        )
        if data is None:
            return None

        # Handle list results
        if isinstance(data, list):
            # Check if it's a list of todos (from get_todos)
            if (
                data
                and isinstance(data[0], dict)
                and all(k in data[0] for k in ("id", "content", "status", "priority"))
            ):
                count = len(data)
                # Count by status
                pending = sum(1 for t in data if t.get("status") == "pending")
                in_progress = sum(1 for t in data if t.get("status") == "in_progress")
                completed = sum(1 for t in data if t.get("status") == "completed")

                parts = []
                if pending > 0:
                    parts.append(f"{pending} pending")
                if in_progress > 0:
                    parts.append(f"{in_progress} in progress")
                if completed > 0:
                    parts.append(f"{completed} completed")

                if parts:
                    return (
                        f"{count} todo{'s' if count != 1 else ''} ({', '.join(parts)})"
                    )
                return f"{count} todo{'s' if count != 1 else ''}"
            # Other list results (e.g., list_semantic_views returns List[Dict])
            count = len(data)
            return f"{count} item{'s' if count != 1 else ''}"

        # Try to parse into typed model using tool_name
        tool_name = data.get("tool_name")
        model_class = self.TOOL_RESULT_MODELS.get(tool_name) if tool_name else None

        if model_class:
            try:
                result = model_class.model_validate(data)
                return self._summarize_typed_result(result)
            except ValidationError:
                # Fall through to heuristic parsing if model validation fails
                pass

        # Fallback: heuristic parsing for results without tool_name
        return self._summarize_untyped_result(data)

    def _summarize_typed_result(self, result: Any) -> Optional[str]:
        """Generate summary from a typed Pydantic model result."""
        # Query results with rows
        if isinstance(result, (PreviewTableResult, ExecuteQueryResult)):
            count = result.row_count
            return f"{count} row{'s' if count != 1 else ''}"

        # Graph query results
        if isinstance(result, QueryGraphResult):
            count = result.node_count
            return f"{count} result{'s' if count != 1 else ''}"

        # Graph search results
        if isinstance(result, GraphSearchResult):
            count = result.match_count
            return f"{count} match{'es' if count != 1 else ''}"

        # Model search results
        if isinstance(result, SearchModelsResult):
            count = result.result_count
            return f"{count} match{'es' if count != 1 else ''}"

        # Model details
        if isinstance(result, ModelDetailsResult):
            parts = []
            if result.measures:
                parts.append(f"{len(result.measures)} measures")
            if result.dimensions:
                parts.append(f"{len(result.dimensions)} dims")
            if result.facts:
                parts.append(f"{len(result.facts)} facts")
            if result.columns:
                parts.append(f"{len(result.columns)} cols")
            if result.canonical_sql or result.raw_sql:
                parts.append("SQL")
            return ", ".join(parts) if parts else "basic info"

        if isinstance(result, ModelMaterializationsResult):
            materialization_count = len(result.materializations)
            if materialization_count == 0:
                return "no materializations"
            environments = list(
                dict.fromkeys(m.environment for m in result.materializations)
            )
            count_part = f"{materialization_count} materialization{'s' if materialization_count != 1 else ''}"
            if environments:
                return f"{count_part} across {', '.join(environments)}"
            return count_part

        # Downstream impact
        if isinstance(result, DownstreamImpactResult):
            count = result.total_affected
            return f"{count} affected model{'s' if count != 1 else ''}"

        # Report creation
        if isinstance(result, CreateReportResult):
            return "report created"

        # Chart cell
        # Cell mutations (slim ack)
        if isinstance(result, CellAck):
            return result.message

        # Plan operations (compact ack or full view)
        if isinstance(result, (PlanAck, PlanView)):
            if result.error:
                return "error"
            if result.tool_name == "create_plan":
                return "plan created"
            if result.tool_name == "finalize_plan":
                return "plan finalized"
            if result.tool_name == "reopen_plan":
                return "plan reopened"
            if result.tool_name in {"get_plan", "get_active_plan"}:
                return "plan loaded"
            return "plan updated"

        # Ticket creation
        if isinstance(result, CreateTicketResult):
            return f"ticket {result.ticket_id} created"

        # Ticket list
        if isinstance(result, ListTicketsResult):
            count = result.count
            return f"{count} ticket{'s' if count != 1 else ''}"

        # Get ticket
        if isinstance(result, GetTicketResult):
            return "ticket loaded"

        # Update ticket
        if isinstance(result, UpdateTicketResult):
            return "ticket updated"

        # Add ticket comment
        if isinstance(result, AddTicketCommentResult):
            return "comment added"

        # CLI tools
        if isinstance(result, (BashResult, DbtResult)):
            stdout_len = len(result.stdout or "")
            stderr_len = len(result.stderr or "")
            status = "exit 0" if result.exit_code == 0 else f"exit {result.exit_code}"
            extras = []
            if stdout_len:
                extras.append(f"stdout {stdout_len} chars")
            if stderr_len:
                extras.append(f"stderr {stderr_len} chars")
            extra_str = f" ({', '.join(extras)})" if extras else ""
            return f"{status}{extra_str}"

        return None

    def _summarize_untyped_result(self, data: Dict[str, Any]) -> Optional[str]:
        """Fallback summary for results without a tool_name or failed parsing."""
        tool_name = data.get("tool_name")

        if tool_name == "grep_files":
            match_count = data.get("match_count")
            if match_count is None and isinstance(data.get("matches"), list):
                match_count = len(data["matches"])
            if match_count is None:
                return None
            return f"{match_count} match{'es' if match_count != 1 else ''}"

        if tool_name == "glob_files":
            count = data.get("count")
            if count is None and isinstance(data.get("files"), list):
                count = len(data["files"])
            if count is None:
                return None
            return f"{count} file{'s' if count != 1 else ''}"

        if tool_name == "read_file":
            line_count = data.get("line_count")
            start_line = data.get("start_line")
            end_line = data.get("end_line")
            if line_count is None and isinstance(data.get("content"), str):
                line_count = max(0, data["content"].count("\n") + 1)
            if start_line is not None and end_line is not None:
                return f"lines {start_line}-{end_line}"
            if line_count is not None:
                return f"{line_count} line{'s' if line_count != 1 else ''}"

        # Todo summary (from get_summary) - generate nice summary
        if all(k in data for k in ("total", "pending", "in_progress", "completed")):
            total = data.get("total", 0)
            pending = data.get("pending", 0)
            in_progress = data.get("in_progress", 0)
            completed = data.get("completed", 0)

            parts = []
            if pending > 0:
                parts.append(f"{pending} pending")
            if in_progress > 0:
                parts.append(f"{in_progress} in progress")
            if completed > 0:
                parts.append(f"{completed} completed")

            if parts:
                return f"{total} todo{'s' if total != 1 else ''} ({', '.join(parts)})"
            return f"{total} todo{'s' if total != 1 else ''}"

        # Single todo item (from add_todo/update_todo)
        if all(k in data for k in ("id", "content", "status", "priority")):
            status = data.get("status", "pending")
            if status == "completed":
                return "todo completed"
            elif status == "in_progress":
                return "todo in progress"
            else:
                return "todo added"

        # Table results (rows + columns)
        if "rows" in data and isinstance(data["rows"], list):
            row_count = len(data["rows"])
            return f"{row_count} row{'s' if row_count != 1 else ''}"

        # Graph nodes
        if "nodes" in data and isinstance(data["nodes"], list):
            node_count = len(data["nodes"])
            return f"{node_count} result{'s' if node_count != 1 else ''}"

        # Search results
        if "results" in data and isinstance(data["results"], list):
            result_count = len(data["results"])
            return f"{result_count} match{'es' if result_count != 1 else ''}"

        # Lineage with hops
        if "hops" in data and isinstance(data["hops"], list):
            hop_count = len(data["hops"])
            return f"{hop_count} hop{'s' if hop_count != 1 else ''}"

        # Generic success
        if data.get("success") is True:
            return "success"

        # Message-based results
        if "message" in data and isinstance(data["message"], str):
            msg = data["message"]
            if len(msg) > 30:
                return msg[:60] + "..."
            return msg

        return None
