"""Compact modal screen for recent activity summaries."""

from typing import List

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Label, ListItem, ListView, Markdown, Static

from lineage.tui.widgets.artifacts.artifact_types import ArtifactData


class ActivityScreen(ModalScreen[None]):
    """Modal screen showing recent run/subagent activity."""

    BINDINGS = [
        Binding("escape", "close", "Close", show=True),
        Binding("q", "close", "Close", show=False),
        Binding("ctrl+c", "app.confirm_exit", "Exit", show=False),
    ]

    def __init__(self, activities: List[ArtifactData]) -> None:
        """Initialize activity modal with recent activity records."""
        super().__init__()
        self._activities = list(activities)
        self._list = ListView(id="activity-modal-list")
        self._preview = Markdown("", id="activity-modal-preview")

    def compose(self) -> ComposeResult:
        """Compose the compact activity modal layout."""
        with Container(classes="activity-modal", id="activity-modal"):
            with Static(classes="help-modal-header"):
                yield Label("Activity")
            with Horizontal(id="activity-modal-body"):
                yield self._list
                yield self._preview
            with Static(classes="help-modal-footer"):
                with Horizontal(classes="help-footer-row"):
                    yield Label("esc", classes="help-footer-key")
                    yield Label("to close", classes="help-footer-text")

    def on_mount(self) -> None:
        """Populate activity list and render the initial selection."""
        if not self._activities:
            self._preview.update("No activity yet. Run a prompt first.")
            return

        for item in self._activities:
            self._list.append(
                ListItem(Label(f"• {item.title}", classes="history-title"))
            )

        self._list.index = len(self._activities) - 1
        self._preview.update(self._render_activity_markdown(self._activities[-1]))
        self._list.focus()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """Render selected activity details in the preview pane."""
        if event.list_view.id != "activity-modal-list":
            return
        idx = event.list_view.index
        if idx is None or idx < 0 or idx >= len(self._activities):
            return
        self._preview.update(self._render_activity_markdown(self._activities[idx]))

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        """Update preview as keyboard highlight moves through activities."""
        if event.list_view.id != "activity-modal-list":
            return
        idx = event.list_view.index
        if idx is None or idx < 0 or idx >= len(self._activities):
            return
        self._preview.update(self._render_activity_markdown(self._activities[idx]))

    def _render_activity_markdown(self, item: ArtifactData) -> str:
        stats = item.data.get("stats") if isinstance(item.data, dict) else None
        if stats is None:
            return f"## {item.title}\n\nNo details available."

        lines = [f"## {item.title}", ""]

        duration = getattr(stats, "duration_seconds", None)
        if duration is not None:
            lines.append(f"**Duration:** {duration:.1f}s")
        lines.append(f"**Tool Calls:** {getattr(stats, 'tool_call_count', 0)}")
        lines.append("")

        user_message = getattr(stats, "user_message", None)
        if user_message:
            lines.append(f"**Prompt:** {user_message}")
            lines.append("")

        result_preview = getattr(stats, "result_preview", None)
        if result_preview:
            lines.append("### Result")
            lines.append("")
            lines.append(f"```\n{result_preview}\n```")
            lines.append("")

        tool_calls = getattr(stats, "tool_calls", None) or []
        if tool_calls:
            lines.append("### Steps")
            lines.append("")
            for i, tc in enumerate(tool_calls, 1):
                label = getattr(tc, "display_text", "step")
                tc_duration = getattr(tc, "duration_seconds", None)
                if tc_duration is not None:
                    lines.append(f"{i}. {label} ({tc_duration:.1f}s)")
                else:
                    lines.append(f"{i}. {label}")

        return "\n".join(lines)

    def action_close(self) -> None:
        """Close the activity modal."""
        self.dismiss()
