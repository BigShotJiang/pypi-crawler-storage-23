"""Main TUI Application."""

import asyncio
import logging
import os
from contextlib import suppress
from pathlib import Path
from time import monotonic
from typing import Any, Optional

from rich.markup import escape as escape_markup
from rich.text import Text
from textual import events
from textual.app import App, ComposeResult, SystemCommand
from textual.binding import Binding
from textual.command import CommandPalette
from textual.containers import Container, Vertical
from textual.css.query import NoMatches
from textual.reactive import reactive
from textual.screen import ModalScreen
from textual.widgets import Label, LoadingIndicator, Static, TabbedContent, TabPane

from lineage.ag_ui.client import AGUIClient as AguiClient
from lineage.tui.backend import BackendManager
from lineage.tui.perf import get_perf_logger
from lineage.tui.screens.chat import AgentChat
from lineage.tui.screens.daemon import DaemonScreen
from lineage.tui.screens.help import HelpScreen
from lineage.tui.screens.key_inspector import KeyInspectorScreen
from lineage.tui.screens.shortcuts import ShortcutsScreen
from lineage.tui.screens.tickets import OpenTicketInChat, TicketsScreen
from lineage.tui.theme import TYPEDEF_THEME

# Configure logging - use typedef logs dir if available, else fallback
TYPEDEF_LOGS = Path.home() / ".typedef" / "logs"
if TYPEDEF_LOGS.exists():
    LOG_FILE = TYPEDEF_LOGS / "tui-client.log"
else:
    Path("logs").mkdir(exist_ok=True)
    LOG_FILE = Path("logs/tui-client.log")

logging.basicConfig(
    level=logging.INFO,
    filename=str(LOG_FILE),
    filemode="w",
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Path to shared CSS file
STYLES_PATH = Path(__file__).parent / "styles.tcss"


class StatusBar(Static):
    """Status bar showing connection states and key hints."""

    DEFAULT_TERMINAL_WIDTH = 120
    SPINNER_FRAMES = ("◐", "◓", "◑", "◒")
    SPINNER_INTERVAL = 0.35
    STATE_COLOR_SUCCESS = "#a6e3a1"
    STATE_COLOR_WARNING = "#f9e2af"
    STATE_COLOR_ERROR = "#f38ba8"
    STATE_COLOR_MUTED = "#a6adc8"

    project_name = reactive("default")
    backend_status = reactive("starting")
    graph_status = reactive("pending")
    data_status = reactive("pending")
    spinner_index = reactive(0)
    active_tab = reactive("chat")

    def on_mount(self) -> None:
        """Start spinner animation for pending states."""
        self._ensure_spinner_timer()

    def on_unmount(self) -> None:
        """Stop spinner animation timer."""
        self._stop_spinner_timer()

    def _has_pending_states(self) -> bool:
        """Return whether any backend statuses are still pending."""
        return any(
            state in {"starting", "pending"}
            for state in (self.backend_status, self.graph_status, self.data_status)
        )

    def _stop_spinner_timer(self) -> None:
        """Stop status spinner timer when active."""
        timer = getattr(self, "_spinner_timer", None)
        if timer is not None:
            timer.stop()
            self._spinner_timer = None

    def _ensure_spinner_timer(self) -> None:
        """Start/stop spinner timer based on pending-state activity."""
        if not self.is_attached:
            return
        if not self._has_pending_states():
            self._stop_spinner_timer()
            return
        timer = getattr(self, "_spinner_timer", None)
        if timer is None:
            self._spinner_timer = self.set_interval(
                self.SPINNER_INTERVAL,
                self._advance_spinner,
            )

    def watch_backend_status(self, _new_status: str) -> None:
        """Keep spinner timer aligned with backend status state."""
        self._ensure_spinner_timer()

    def watch_graph_status(self, _new_status: str) -> None:
        """Keep spinner timer aligned with graph status state."""
        self._ensure_spinner_timer()

    def watch_data_status(self, _new_status: str) -> None:
        """Keep spinner timer aligned with data status state."""
        self._ensure_spinner_timer()

    def _advance_spinner(self) -> None:
        """Advance status spinner animation frame."""
        if not self._has_pending_states():
            self._stop_spinner_timer()
            return
        self.spinner_index = (self.spinner_index + 1) % len(self.SPINNER_FRAMES)

    def _render_state(self, value: str) -> str:
        """Render state value with daemon/wizard-like circles and colors."""
        if value in {"starting", "pending"}:
            icon = self.SPINNER_FRAMES[self.spinner_index]
            return f"[{self.STATE_COLOR_WARNING}]{icon}[/] {value}"
        if value in {"ready", "connected"}:
            return f"[{self.STATE_COLOR_SUCCESS}]●[/] {value}"
        if value == "error":
            return f"[{self.STATE_COLOR_ERROR}]○[/] {value}"
        return f"[{self.STATE_COLOR_MUTED}]○[/] {value}"

    def _current_tab(self) -> str:
        """Resolve currently active tab id."""
        try:
            app = self.app
        except Exception:
            return self.active_tab
        try:
            return app.query_one("#main-content", TabbedContent).active
        except Exception:
            return self.active_tab

    def _key_hints(self) -> str:
        """Render contextual key hints by active tab."""
        tab = self._current_tab()
        common = "[bold]?[/bold] help  [bold]ctrl+c[/bold] x2 exit"
        if tab == "chat":
            hints = (
                f"{common}  [bold]q[/bold] stop agent  [bold]esc[/bold] stop agent"
                "  [bold]f[/bold] toggle follow"
                "  [bold]i[/bold] focus input"
                "  [bold]ctrl+a[/bold] artifacts"
                "  [bold]ctrl+g[/bold] activity"
                "  [bold]v[/bold] toggle verbose"
            )
            return hints
        if tab == "tickets":
            return (
                f"{common}  [bold]r[/bold] refresh"
                "  [bold]i[/bold] investigator  [bold]c[/bold] copilot"
                "  [bold]ctrl+,/.[/bold] move to chat"
            )
        if tab == "daemon":
            return (
                f"{common}  [bold]s[/bold] start/stop"
                "  [bold]r[/bold] reconciler  [bold]i[/bold] investigator"
                "  [bold]ctrl+,/.[/bold] move to chat"
            )
        return common

    def _key_hint_variants(self) -> list[str]:
        """Return key-hint variants from detailed to compact per tab."""
        tab = self._current_tab()
        common_full = "[bold]?[/bold] help  [bold]ctrl+c[/bold] x2 exit"
        common_compact = "[bold]?[/bold] help  [bold]ctrl+c[/bold] exit"
        help_only = "[bold]?[/bold] help"

        if tab == "chat":
            return [
                (
                    f"{common_full}  [bold]q[/bold] stop agent  [bold]esc[/bold] stop agent"
                    "  [bold]f[/bold] toggle follow  [bold]i[/bold] focus input"
                    "  [bold]ctrl+a[/bold] artifacts"
                    "  [bold]ctrl+g[/bold] activity"
                    "  [bold]v[/bold] toggle verbose"
                ),
                (
                    f"{common_full}  [bold]q[/bold] stop agent  [bold]esc[/bold] stop agent"
                    "  [bold]f[/bold] toggle follow  [bold]i[/bold] focus input"
                ),
                f"{common_compact}  [bold]q[/bold] stop agent  [bold]esc[/bold] stop agent",
                f"{common_compact}  [bold]q[/bold]",
                common_compact,
                help_only,
            ]
        if tab == "tickets":
            return [
                (
                    f"{common_full}  [bold]r[/bold] refresh"
                    "  [bold]i[/bold] investigator  [bold]c[/bold] copilot"
                    "  [bold]ctrl+,/.[/bold] move to chat"
                ),
                (
                    f"{common_compact}  [bold]r[/bold] refresh"
                    "  [bold]i[/bold] investigator  [bold]c[/bold] copilot"
                ),
                f"{common_compact}  [bold]r[/bold]  [bold]i[/bold]  [bold]c[/bold]",
                common_compact,
                help_only,
            ]
        if tab == "daemon":
            return [
                (
                    f"{common_full}  [bold]s[/bold] start/stop"
                    "  [bold]r[/bold] reconciler  [bold]i[/bold] investigator"
                    "  [bold]ctrl+,/.[/bold] move to chat"
                ),
                (
                    f"{common_compact}  [bold]s[/bold] start/stop"
                    "  [bold]r[/bold] reconciler  [bold]i[/bold] investigator"
                ),
                f"{common_compact}  [bold]s[/bold]  [bold]r[/bold]  [bold]i[/bold]",
                common_compact,
                help_only,
            ]
        return [common_full, common_compact, help_only]

    def _terminal_width(self) -> int:
        """Get current terminal width for alignment."""
        try:
            width = self.size.width
            return width if width > 0 else self.DEFAULT_TERMINAL_WIDTH
        except Exception:
            return self.DEFAULT_TERMINAL_WIDTH

    def _plain_len(self, markup_text: str) -> int:
        """Estimate visible length of Rich-markup text."""
        try:
            return Text.from_markup(markup_text).cell_len
        except Exception:
            return len(markup_text)

    def _build_status_variants(self) -> list[str]:
        """Build status variants from most detailed to most compact."""
        project_name = escape_markup(self.project_name)
        backend = self._render_state(self.backend_status)
        graph = self._render_state(self.graph_status)
        data = self._render_state(self.data_status)
        sep = f"[{self.STATE_COLOR_MUTED}]│[/]"

        return [
            (
                f"📁 [bold]{project_name}[/bold] "
                f"{sep} "
                f"[bold]backend[/bold] {backend}  "
                f"[bold]graph[/bold] {graph}  "
                f"[bold]data[/bold] {data}"
            ),
            (
                f"[bold]{project_name}[/bold] "
                f"{sep} "
                f"[bold]backend[/bold] {backend}  "
                f"[bold]graph[/bold] {graph}  "
                f"[bold]data[/bold] {data}"
            ),
            (
                f"[bold]backend[/bold] {backend}  "
                f"[bold]graph[/bold] {graph}  "
                f"[bold]data[/bold] {data}"
            ),
            f"[bold]B[/bold] {backend}  [bold]G[/bold] {graph}  [bold]D[/bold] {data}",
            f"[bold]B[/bold] {backend}  [bold]G[/bold] {graph}",
            f"[bold]B[/bold] {backend}",
        ]

    def render(self) -> str:
        """Render the status bar with status and key hints."""
        width = self._terminal_width()
        status_variants = self._build_status_variants()

        help_only = "[bold]?[/bold] help"
        for index, status in enumerate(status_variants):
            key_variants = [help_only] if index >= 3 else self._key_hint_variants()
            for keys in key_variants:
                keys_len = self._plain_len(keys)
                status_len = self._plain_len(status)
                if status_len + 2 + keys_len <= width:
                    gap = max(2, width - status_len - keys_len)
                    return f"{status}{' ' * gap}{keys}"

        for keys in self._key_hint_variants():
            if self._plain_len(keys) <= width:
                left_padding = max(0, width - self._plain_len(keys))
                return f"{' ' * left_padding}{keys}"

        # Final fallback: progressively shorter hint variants that always fit.
        for fallback in (help_only, "[bold]?[/bold]", "?", ""):
            fallback_len = self._plain_len(fallback)
            if fallback_len <= width:
                left_padding = max(0, width - fallback_len)
                return f"{' ' * left_padding}{fallback}"

        return ""

    def set_connected(self):
        """Set all statuses to connected."""
        self.set_backend_ready()
        self.set_graph_connected()
        self.set_data_connected()

    def set_backend_ready(self) -> None:
        """Set backend status to ready."""
        self.backend_status = "ready"

    def set_graph_connected(self) -> None:
        """Set graph status to connected."""
        self.graph_status = "connected"

    def set_data_connected(self) -> None:
        """Set data status to connected."""
        self.data_status = "connected"

    def set_graph_error(self) -> None:
        """Set graph status to error."""
        self.graph_status = "error"

    def set_data_error(self) -> None:
        """Set data status to error."""
        self.data_status = "error"

    def set_backend_error(self):
        """Set backend to error state."""
        self.backend_status = "error"
        self.set_graph_error()
        self.set_data_error()

    def set_loading(self):
        """Set all to loading."""
        self.backend_status = "starting"
        self.graph_status = "pending"
        self.data_status = "pending"


class StartupPlaceholder(Static):
    """Structured startup surface shown while backend is initializing."""

    def __init__(self, log_file: str):
        """Initialize placeholder with backend log path for startup context."""
        super().__init__(id="startup-placeholder")
        self.log_file = log_file

    def compose(self) -> ComposeResult:
        """Build startup loading surface for the chat pane."""
        with Vertical(classes="startup-surface"):
            yield Label("Starting up", classes="startup-title")
            yield Label("Preparing backend and services", classes="startup-subtitle")
            yield LoadingIndicator(id="startup-spinner")
            yield Label(f"Logs: {self.log_file}", classes="startup-details")


class DataConciergeApp(App):
    """The main TUI application."""

    CSS_PATH = STYLES_PATH
    TITLE = "typedef - Data Concierge"
    SUBTITLE = "The AI-powered data concierge for your organization."
    BINDINGS = [
        ("q", "cancel_agent", "Stop Agent"),
        ("ctrl+q", "cancel_agent", "Stop Agent"),
        ("escape", "cancel_agent", "Stop Agent"),
        ("ctrl+c", "confirm_exit", "Exit"),
        ("ctrl+shift+c", "copy_selected_text", "Copy Selection"),
        ("ctrl+a", "open_artifacts", "Open Artifacts"),
        ("ctrl+g", "open_activity", "Open Activity"),
        ("f", "toggle_follow", "Toggle follow"),
        ("ctrl+comma", "previous_chat_mode", "Previous Agent"),
        ("ctrl+left", "previous_chat_mode", "Previous Mode"),
        ("ctrl+h", "previous_chat_mode", "Previous Mode"),
        ("ctrl+period", "next_chat_mode", "Next Agent"),
        ("ctrl+full_stop", "next_chat_mode", "Next Agent"),
        ("ctrl+right", "next_chat_mode", "Next Mode"),
        ("ctrl+l", "next_chat_mode", "Next Mode"),
        ("ctrl+t", "select_tickets_tab", "Tickets Tab"),
        ("ctrl+d", "select_daemon_tab", "Daemon Tab"),
        ("s", "toggle_daemon", "Toggle Daemon"),
        ("r", "select_reconciler", "Reconciler/Refresh"),
        ("i", "select_investigator", "Focus input / Investigator"),
        ("v", "toggle_verbose", "Toggle Verbose"),
        ("f1", "help", "Help"),
        ("?", "shortcuts_help", "Shortcuts"),
        ("ctrl+slash", "shortcuts_help", "Shortcuts"),
        ("ctrl+question_mark", "shortcuts_help", "Shortcuts"),
        Binding("ctrl+alt+k", "toggle_key_inspector", "", show=False),
        Binding("ctrl+shift+k", "toggle_key_inspector", "", show=False),
        Binding("f12", "toggle_key_inspector", "", show=False),
    ]

    def __init__(self, daemon_mode: bool = False, flat_mode: bool = False):
        """Initialize the application.

        Args:
            daemon_mode: If True, auto-start daemon and switch to Tickets tab.
            flat_mode: If True, force flattened agents instead of deep specialist variants.
        """
        super().__init__()
        self.register_theme(TYPEDEF_THEME)
        self.theme = "typedef"
        self.backend = BackendManager()
        self.client: Optional[AguiClient] = None
        self.status_bar: Optional[StatusBar] = None
        self.active_project = os.getenv("TYPEDEF_ACTIVE_PROJECT", "default")
        self.daemon_mode = daemon_mode
        self.flat_mode = flat_mode
        self._startup_task: Optional[asyncio.Task[None]] = None
        self._readiness_task: Optional[asyncio.Task[None]] = None
        self._ticketing_available = self._has_ticketing_backend()
        self._last_exit_attempt_at = 0.0
        self.current_chat_mode = "analyst"
        self._new_chat_tip_shown = False
        self._chat_mode_to_agent = {
            "analyst": "analyst",
            "investigator": "investigator-flat" if self.flat_mode else "investigator",
            "insights": "insights",
            "copilot": "copilot-flat" if self.flat_mode else "copilot",
        }
        self._agent_model_map: dict[str, str] = {}
        self._perf = get_perf_logger()
        self._startup_started_at: Optional[float] = None
        self._mounted_aux_tabs: set[str] = set()
        self._aux_mount_tasks: dict[str, asyncio.Task[None]] = {}

    def _log_perf_event(self, event: str, **payload: Any) -> None:
        """Emit structured perf events when enabled."""
        perf = getattr(self, "_perf", None)
        if perf is not None:
            perf.log_event(event, **payload)

    EXIT_CONFIRM_WINDOW_SECONDS = 2.0
    CHAT_TAB_IDS = {"chat"}
    AUX_TAB_IDS = {"tickets", "daemon"}
    CHAT_MODES = ("analyst", "investigator", "insights", "copilot")

    def _aux_tab_spec(self, tab_id: str) -> Optional[tuple[str, Any]]:
        """Return container selector and screen class for auxiliary tab ids."""
        specs: dict[str, tuple[str, Any]] = {
            "tickets": ("#tickets-container", TicketsScreen),
            "daemon": ("#daemon-container", DaemonScreen),
        }
        return specs.get(tab_id)

    async def _mount_aux_tab(self, tab_id: str) -> None:
        """Mount an auxiliary tab screen when needed.

        This method may be invoked before the AGUI client has finished
        initializing. In that case, it will wait briefly for the client
        to become available instead of returning immediately, so that
        auxiliary tabs selected during startup still get mounted once
        initialization completes.
        """
        if not self._ticketing_available:
            return

        # Wait for the client to be initialized, up to a short timeout, to
        # avoid leaving the auxiliary tab permanently unmounted if selected
        # during startup.
        if self.client is None:
            start = monotonic()
            timeout = 5.0  # seconds
            while self.client is None and (monotonic() - start) < timeout:
                await asyncio.sleep(0.05)

        if self.client is None:
            logger.warning(
                "Aux tab '%s' could not be mounted because AGUI client was "
                "not initialized within the timeout window.",
                tab_id,
            )
            return

        tab_spec = self._aux_tab_spec(tab_id)
        if tab_spec is None:
            return

        container_selector, screen_class = tab_spec
        container = self.query_one(container_selector, Container)

        for child in container.children:
            if isinstance(child, screen_class):
                self._mounted_aux_tabs.add(tab_id)
                return

        await container.mount(screen_class(self.client))
        self._mounted_aux_tabs.add(tab_id)

    async def _ensure_aux_tab_mounted(self, tab_id: str) -> None:
        """Ensure target auxiliary tab is mounted before routed action dispatch."""
        if (
            not self._ticketing_available
            or tab_id not in self.AUX_TAB_IDS
            or tab_id in self._mounted_aux_tabs
        ):
            return

        task = self._aux_mount_tasks.get(tab_id)
        if task is None or task.done():
            task = asyncio.create_task(self._mount_aux_tab(tab_id))
            self._aux_mount_tasks[tab_id] = task
        try:
            await task
        finally:
            if task.done():
                self._aux_mount_tasks.pop(tab_id, None)

    def _agent_name_for_mode(self, mode: str) -> str:
        """Map logical chat mode to backend agent name."""
        mode_map = getattr(self, "_chat_mode_to_agent", {})
        if isinstance(mode_map, dict):
            return mode_map.get(mode, mode)
        return mode

    def _set_chat_mode(self, mode: str) -> None:
        """Set logical chat mode and update active chat widget when mounted."""
        if mode not in self.CHAT_MODES:
            return
        self.current_chat_mode = mode
        chat = self._active_agent_chat()
        if chat is None:
            return
        set_mode = getattr(chat, "set_agent_mode", None)
        if callable(set_mode):
            backend_agent_name = self._agent_name_for_mode(mode)
            try:
                set_mode(mode, backend_agent_name)
            except TypeError:
                set_mode(mode)

    def _active_agent_chat(self) -> Optional[AgentChat]:
        """Return the active tab's AgentChat when a chat tab is active."""
        tabbed_content = self.query_one("#main-content", TabbedContent)
        active_tab_id = tabbed_content.active
        if active_tab_id not in self.CHAT_TAB_IDS:
            return None

        container = self.query_one("#chat-container", Container)
        for child in container.children:
            if isinstance(child, AgentChat):
                return child
            if callable(getattr(child, "action_toggle_verbose", None)) and callable(
                getattr(child, "action_toggle_autoscroll", None)
            ):
                return child  # type: ignore[return-value]
            if callable(getattr(child, "set_agent_mode", None)) and callable(
                getattr(child, "set_input_value", None)
            ):
                return child  # type: ignore[return-value]
        return None

    def _focus_chat_input_target(self) -> None:
        """Focus the active chat input target (chooser, placeholder, or input)."""
        try:
            container = self.query_one("#chat-container", Container)
            for child in container.children:
                focus_input = getattr(child, "focus_input", None)
                if callable(focus_input):
                    focus_input()
                    break
        except Exception as e:
            logger.debug(f"Unable to focus chat input target: {e}")

    def maybe_show_new_chat_tip(self) -> None:
        """Show the new-chat reset tip once per app session."""
        if self._new_chat_tip_shown:
            return
        self.notify("Tip: use /new to start a new chat session", timeout=4)
        self._new_chat_tip_shown = True

    def _has_ticketing_backend(self) -> bool:
        """Check if any ticketing backend is enabled in the config."""
        from lineage.utils.env import load_env_file

        load_env_file()

        # Check if ticketing is enabled via unified config
        config_path = os.environ.get("UNIFIED_CONFIG")
        if not config_path:
            config_path = str(Path.home() / ".typedef" / "config.yaml")

        if Path(config_path).exists():
            try:
                import yaml

                with open(config_path) as f:
                    config = yaml.safe_load(f) or {}
                ticket_config = config.get("ticket", {})
                return ticket_config.get("enabled", False)
            except Exception as e:
                logger.error(f"Error loading ticketing config: {e}")
                return False

        return False

    def compose(self) -> ComposeResult:
        """Create child widgets for the app."""
        with Container(id="loading-screen"):
            yield LoadingIndicator()
            yield Label("Booting Data Concierge backend...", id="loading-label")
            yield Label(f"Logs: {self.backend.log_file}", id="loading-details")

        with TabbedContent(id="main-content", initial="chat"):
            with TabPane("chat", id="chat"):
                yield Container(id="chat-container")
            if self._ticketing_available:
                with TabPane("tickets", id="tickets"):
                    yield Container(id="tickets-container")
                with TabPane("daemon", id="daemon"):
                    yield Container(id="daemon-container")

        # Bottom bar: status with keyboard shortcuts
        with Vertical(id="bottom-bars"):
            self.status_bar = StatusBar(id="status-bar")
            self.status_bar.set_loading()
            self.status_bar.project_name = self.active_project
            yield self.status_bar

    async def on_mount(self):
        """Start backend bootstrap in background and show startup state immediately."""
        self._startup_started_at = monotonic()
        self.query_one("#loading-screen").display = False
        await self._show_startup_placeholder()
        if self.status_bar:
            self.status_bar.set_loading()

        self._log_perf_event(
            "app_mount_started",
            active_project=getattr(self, "active_project", "default"),
            chat_mode=getattr(self, "current_chat_mode", "analyst"),
            daemon_mode=getattr(self, "daemon_mode", False),
        )

        self._startup_task = asyncio.create_task(self._initialize_runtime())

    async def _show_startup_placeholder(self) -> None:
        """Render startup text in chat pane while backend boots."""
        chat_container = self.query_one("#chat-container", Container)
        remove_children = getattr(chat_container, "remove_children", None)
        if callable(remove_children):
            remove_children()
        await chat_container.mount(StartupPlaceholder(str(self.backend.log_file)))
        self._log_perf_event("startup_placeholder_shown")

    def _apply_health_status(self, health_payload: dict[str, Any]) -> None:
        """Apply backend/graph/data status from health payload."""
        if not self.status_bar:
            return

        self.status_bar.set_backend_ready()
        readiness = health_payload.get("readiness", {})
        if isinstance(readiness, dict):
            lineage_ready = readiness.get("lineage")
            data_ready = readiness.get("data")
            if isinstance(lineage_ready, bool):
                if lineage_ready:
                    self.status_bar.set_graph_connected()
                else:
                    self.status_bar.set_graph_error()
            else:
                self.status_bar.graph_status = "pending"

            if isinstance(data_ready, bool):
                if data_ready:
                    self.status_bar.set_data_connected()
                else:
                    self.status_bar.set_data_error()
            else:
                self.status_bar.data_status = "pending"
            return

        self.status_bar.graph_status = "pending"
        self.status_bar.data_status = "pending"

    async def _refresh_dependency_readiness(self) -> None:
        """Fetch true readiness checks and update status bar."""
        readiness_payload = await self.backend.get_dependency_readiness()
        if isinstance(readiness_payload, dict):
            self._apply_health_status(readiness_payload)

    async def _initialize_runtime(self) -> None:
        """Wait for backend health, then mount interactive screens."""
        self.backend.start()
        health_payload = await self.backend.wait_for_health()
        if not health_payload:
            if self.status_bar:
                self.status_bar.set_backend_error()
            chat_container = self.query_one("#chat-container", Container)
            remove_children = getattr(chat_container, "remove_children", None)
            if callable(remove_children):
                remove_children()
            await chat_container.mount(
                Label(
                    f"Backend failed to start. Check logs: {self.backend.log_file}",
                    id="startup-error",
                )
            )
            return

        self.client = AguiClient(self.backend.base_url)
        chat_container = self.query_one("#chat-container", Container)
        remove_children = getattr(chat_container, "remove_children", None)
        if callable(remove_children):
            remove_children()

        await chat_container.mount(
            AgentChat(self._agent_name_for_mode(self.current_chat_mode), self.client)
        )
        if self._startup_started_at is not None:
            self._log_perf_event(
                "startup_chat_ready",
                duration_ms=round((monotonic() - self._startup_started_at) * 1000, 2),
                chat_mode=self.current_chat_mode,
            )
        if not isinstance(health_payload, dict):
            health_payload = {}
        self._apply_health_status(health_payload)
        self._readiness_task = asyncio.create_task(self._refresh_dependency_readiness())
        if self.status_bar:
            tabbed_content = self.query_one("#main-content", TabbedContent)
            self.status_bar.active_tab = tabbed_content.active

        # If daemon mode and ticketing is available, switch to daemon tab and auto-start
        if self.daemon_mode and self._ticketing_available:
            await self._ensure_aux_tab_mounted("daemon")
            tabbed = self.query_one("#main-content", TabbedContent)
            tabbed.active = "daemon"
            self.set_timer(0.5, self._schedule_auto_start_daemon)

    async def on_unmount(self, event: events.Unmount) -> None:
        """Ensure background tasks are cancelled and awaited on unmount."""
        # Cancel and await the main startup/readiness tasks if still running.
        for attr_name in ("_startup_task", "_readiness_task"):
            task = getattr(self, attr_name, None)
            if task is not None and not task.done():
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task
            setattr(self, attr_name, None)

        # Cancel and await any in-flight auxiliary mount tasks.
        for _tab_id, task in list(self._aux_mount_tasks.items()):
            if task is not None and not task.done():
                task.cancel()
                with suppress(asyncio.CancelledError):
                    await task
        self._aux_mount_tasks.clear()

        if self.client:
            await self.client.close()
        self.backend.stop()

    async def action_cancel_agent(self) -> None:
        """Cancel the currently running agent in the active tab."""
        try:
            active_screen = self.screen
            if isinstance(active_screen, ModalScreen):
                close_action = getattr(active_screen, "action_close", None)
                if callable(close_action):
                    close_action()
                    return

            chat = self._active_agent_chat()
            if chat is None:
                return
            if chat.is_agent_running():
                await chat.cancel_agent_run()
                self.notify("Agent run cancelled", severity="warning")
        except Exception as e:
            logger.debug(f"Error cancelling agent: {e}")

    def action_confirm_exit(self) -> None:
        """Handle Ctrl+C by clearing focused input first, then confirming exit."""
        now = monotonic()
        if self._clear_focused_chat_input_if_present():
            self._last_exit_attempt_at = now
            self.notify("Input cleared. Press Ctrl+C again to exit", timeout=2)
            return

        if now - self._last_exit_attempt_at <= self.EXIT_CONFIRM_WINDOW_SECONDS:
            self.exit()
            return

        self._last_exit_attempt_at = now
        self.notify("Press Ctrl+C again to exit", timeout=2)

    def _focused_chat_input(self) -> Optional[Any]:
        """Return focused chat text input widget when applicable."""
        try:
            focused = self.focused
        except Exception:
            return None
        if focused is None:
            return None

        class_name = focused.__class__.__name__
        if class_name not in {"ChatInput", "PlaceholderInput"}:
            return None

        text = getattr(focused, "text", None)
        clear = getattr(focused, "clear", None)
        if not isinstance(text, str) or not callable(clear):
            return None
        return focused

    def _clear_focused_chat_input_if_present(self) -> bool:
        """Clear focused chat input when it currently contains text."""
        focused = self._focused_chat_input()
        if focused is None:
            return False

        text = getattr(focused, "text", "")
        if not isinstance(text, str) or not text:
            return False

        try:
            focused.clear()
        except Exception as e:
            logger.debug(f"Failed to clear focused chat input: {e}")
            return False

        return True

    def _selected_text_from_screen(self, screen: Any = None) -> Optional[str]:
        """Get selected text from active screen, if available."""
        try:
            target_screen = screen or self._active_screen_for_selection()
            selected_text = getattr(target_screen, "get_selected_text", None)
            if callable(selected_text):
                text = selected_text()
                return text if isinstance(text, str) else None
        except Exception as e:
            logger.debug(f"Error getting selected text: {e}")
        return None

    def _active_screen_for_selection(self):
        """Return active screen object for selection state handling."""
        return self.screen

    def _reset_selection_tracking(self, screen: Any = None) -> None:
        """Reset selection internals so drag tracking stops immediately."""
        self.clear_selection()
        target_screen = screen or self._active_screen_for_selection()
        for attr, value in (
            ("_selecting", False),
            ("_mouse_down_offset", None),
            ("_select_start", None),
            ("_select_end", None),
        ):
            if hasattr(target_screen, attr):
                try:
                    setattr(target_screen, attr, value)
                except Exception as e:
                    logger.debug(f"Failed to reset selection attribute {attr}: {e}")

    def _screen_from_event(self, event: events.Event) -> Any:
        """Resolve selection screen from event sender when possible."""
        sender = getattr(event, "_sender", None)
        if sender is not None and hasattr(sender, "get_selected_text"):
            return sender
        return self._active_screen_for_selection()

    def _copy_text_with_toast(self, text: str, screen: Any = None) -> None:
        """Copy text to clipboard and show success feedback."""
        self.copy_to_clipboard(text)
        self._reset_selection_tracking(screen)
        self.notify("Copied to clipboard", title="Copied")

    def action_copy_selected_text(self) -> None:
        """Copy currently selected screen text to clipboard."""
        screen = self._active_screen_for_selection()
        selected_text = self._selected_text_from_screen(screen)
        if not selected_text:
            return
        try:
            self._copy_text_with_toast(selected_text, screen)
        except Exception as e:
            logger.error(f"Failed to copy selected text: {e}")
            self.notify(f"Copy failed: {e}", severity="error")

    def on_text_selected(self, event: events.TextSelected) -> None:
        """Auto-copy text selection when selection gesture completes."""
        screen = self._screen_from_event(event)
        selected_text = self._selected_text_from_screen(screen)
        if not selected_text:
            return
        try:
            self._copy_text_with_toast(selected_text, screen)
        except Exception as e:
            logger.error(f"Failed to auto-copy selected text: {e}")
            self.notify(f"Copy failed: {e}", severity="error")

    def on_mouse_move(self, event: events.MouseMove) -> None:
        """Stop stale selection tracking when no mouse button is pressed."""
        try:
            screen = self._active_screen_for_selection()
            if (
                getattr(screen, "_selecting", False)
                and getattr(event, "button", 0) == 0
            ):
                self._reset_selection_tracking()
        except Exception as e:
            logger.debug(f"Error reconciling selection tracking on mouse move: {e}")

    def action_help(self) -> None:
        """Show the help screen."""
        self.push_screen(HelpScreen())

    def action_shortcuts_help(self) -> None:
        """Show compact keyboard shortcuts modal."""
        active_tab = "chat"
        try:
            active_tab = self.query_one("#main-content", TabbedContent).active
        except NoMatches:
            logger.debug("Main tab container not found; defaulting shortcuts to chat")
        self.push_screen(ShortcutsScreen(active_tab=active_tab))

    def action_show_help_panel(self) -> None:
        """Route command-palette Keys to the same shortcuts modal as `?`."""
        self.action_shortcuts_help()

    def action_command_palette(self) -> None:
        """Show command palette with lowercase placeholder copy."""
        if self.use_command_palette and not CommandPalette.is_open(self):
            self.push_screen(
                CommandPalette(
                    id="--command-palette",
                    placeholder="search for commands...",
                )
            )

    def get_system_commands(self, screen) -> list[SystemCommand]:
        """Normalize command palette text and route keys to shortcuts modal."""
        commands: list[SystemCommand] = []
        for command in super().get_system_commands(screen):
            if command.title == "Keys":
                commands.append(
                    SystemCommand(
                        "keys",
                        "show keyboard shortcuts",
                        self.action_shortcuts_help,
                        discover=command.discover,
                    )
                )
                continue
            commands.append(
                SystemCommand(
                    command.title.lower(),
                    command.help.lower(),
                    command.callback,
                    discover=command.discover,
                )
            )
        active_tab = "chat"
        try:
            tabbed_content = self.query_one("#main-content", TabbedContent)
            active_tab = tabbed_content.active
        except NoMatches:
            logger.debug(
                "Main tab container not found; not exposing 'new chat' command"
            )

        if active_tab in self.CHAT_TAB_IDS:
            commands.append(
                SystemCommand(
                    "new chat",
                    "start a new chat session",
                    self.action_new_chat,
                    discover=True,
                )
            )
            commands.append(
                SystemCommand(
                    "status",
                    "show current session status",
                    self.action_show_status,
                    discover=True,
                )
            )
        return commands

    def action_new_chat(self) -> None:
        """Restart the current chat session (same behavior as `/new`)."""
        try:
            chat = self._active_agent_chat()
            if chat is None:
                return
            restart_chat = getattr(chat, "_restart_chat", None)
            if callable(restart_chat):
                restart_chat()
        except Exception as e:
            logger.debug(f"Error restarting chat from command palette: {e}")

    def action_show_status(self) -> None:
        """Show session status modal (same behavior as `/status`)."""
        try:
            chat = self._active_agent_chat()
            if chat is None:
                return
            show_status = getattr(chat, "_show_status", None)
            if callable(show_status):
                show_status()
        except Exception as e:
            logger.debug(f"Error showing status from command palette: {e}")

    def action_toggle_key_inspector(self) -> None:
        """Open/close hidden key inspector modal."""
        if isinstance(self.screen, KeyInspectorScreen):
            self.pop_screen()
            return
        self.push_screen(KeyInspectorScreen())

    def action_toggle_verbose(self) -> None:
        """Toggle verbose mode in the active chat tab."""
        try:
            chat = self._active_agent_chat()
            if chat is None:
                return
            chat.action_toggle_verbose()
        except Exception as e:
            logger.debug(f"Error toggling verbose mode: {e}")

    def action_toggle_autoscroll(self) -> None:
        """Toggle autoscroll in the active chat tab."""
        try:
            chat = self._active_agent_chat()
            if chat is None:
                return
            chat.action_toggle_autoscroll()
        except Exception as e:
            logger.debug(f"Error toggling autoscroll: {e}")

    def action_toggle_follow(self) -> None:
        """Toggle follow mode in the active chat tab."""
        self.action_toggle_autoscroll()

    def action_open_artifacts(self) -> None:
        """Open artifacts modal in the active chat tab."""
        try:
            chat = self._active_agent_chat()
            if chat is None:
                return
            open_artifacts = getattr(chat, "action_open_artifacts", None)
            if callable(open_artifacts):
                open_artifacts()
        except Exception as e:
            logger.debug(f"Error opening artifacts modal: {e}")

    def action_open_activity(self) -> None:
        """Open activity modal in the active chat tab."""
        try:
            chat = self._active_agent_chat()
            if chat is None:
                return
            open_activity = getattr(chat, "action_open_activity", None)
            if callable(open_activity):
                open_activity()
        except Exception as e:
            logger.debug(f"Error opening activity modal: {e}")

    async def action_select_tickets_tab(self) -> None:
        """Switch to Tickets tab when ticketing tabs are available."""
        if not self._ticketing_available:
            return
        try:
            tabbed_content = self.query_one("#main-content", TabbedContent)
            tabbed_content.active = "tickets"
            await self._ensure_aux_tab_mounted("tickets")
        except Exception as e:
            logger.debug(f"Error selecting tickets tab: {e}")

    async def action_select_daemon_tab(self) -> None:
        """Switch to Daemon tab when ticketing tabs are available."""
        if not self._ticketing_available:
            return
        try:
            tabbed_content = self.query_one("#main-content", TabbedContent)
            tabbed_content.active = "daemon"
            await self._ensure_aux_tab_mounted("daemon")
        except Exception as e:
            logger.debug(f"Error selecting daemon tab: {e}")

    def action_next_chat_mode(self) -> None:
        """Switch to the next chat mode when chat tab is active."""
        try:
            tabbed_content = self.query_one("#main-content", TabbedContent)
            if tabbed_content.active in {"tickets", "daemon"}:
                tabbed_content.active = "chat"
                self.call_after_refresh(self._focus_chat_input_target)
                return
            if tabbed_content.active != "chat":
                return
            chat = self._active_agent_chat()
            if chat is None:
                return
            can_switch = getattr(chat, "can_switch_mode", None)
            if callable(can_switch) and not can_switch():
                self.notify(
                    "Tip: use /new to start a new chat session",
                    severity="warning",
                )
                return
            idx = self.CHAT_MODES.index(self.current_chat_mode)
            next_mode = self.CHAT_MODES[(idx + 1) % len(self.CHAT_MODES)]
            self._set_chat_mode(next_mode)
        except Exception as e:
            logger.debug(f"Error switching to next chat mode: {e}")

    def action_previous_chat_mode(self) -> None:
        """Switch to the previous chat mode when chat tab is active."""
        try:
            tabbed_content = self.query_one("#main-content", TabbedContent)
            if tabbed_content.active in {"tickets", "daemon"}:
                tabbed_content.active = "chat"
                self.call_after_refresh(self._focus_chat_input_target)
                return
            if tabbed_content.active != "chat":
                return
            chat = self._active_agent_chat()
            if chat is None:
                return
            can_switch = getattr(chat, "can_switch_mode", None)
            if callable(can_switch) and not can_switch():
                self.notify(
                    "Tip: use /new to start a new chat session",
                    severity="warning",
                )
                return
            idx = self.CHAT_MODES.index(self.current_chat_mode)
            previous_mode = self.CHAT_MODES[(idx - 1) % len(self.CHAT_MODES)]
            self._set_chat_mode(previous_mode)
        except Exception as e:
            logger.debug(f"Error switching to previous chat mode: {e}")

    async def action_refresh_tickets(self) -> None:
        """Refresh tickets when Tickets tab is active."""
        try:
            tabbed_content = self.query_one("#main-content", TabbedContent)
            if tabbed_content.active != "tickets":
                return

            await self._ensure_aux_tab_mounted("tickets")
            container = self.query_one("#tickets-container", Container)
            for child in container.children:
                refresh = getattr(child, "action_refresh_tickets", None)
                if callable(refresh):
                    refresh()
                    return
        except Exception as e:
            logger.debug(f"Error refreshing tickets: {e}")

    async def action_toggle_daemon(self) -> None:
        """Toggle daemon start/stop when Daemon tab is active."""
        try:
            tabbed_content = self.query_one("#main-content", TabbedContent)
            if tabbed_content.active != "daemon":
                return

            await self._ensure_aux_tab_mounted("daemon")
            container = self.query_one("#daemon-container", Container)
            for child in container.children:
                toggle = getattr(child, "action_toggle_daemon", None)
                if callable(toggle):
                    toggle()
                    return
        except Exception as e:
            logger.debug(f"Error toggling daemon: {e}")

    async def action_select_reconciler(self) -> None:
        """Route r shortcut by active tab (Tickets refresh, Daemon reconciler)."""
        try:
            tabbed_content = self.query_one("#main-content", TabbedContent)
            if tabbed_content.active == "tickets":
                await self.action_refresh_tickets()
                return
            if tabbed_content.active != "daemon":
                return

            await self._ensure_aux_tab_mounted("daemon")
            container = self.query_one("#daemon-container", Container)
            for child in container.children:
                select = getattr(child, "action_select_reconciler", None)
                if callable(select):
                    select()
                    return
        except Exception as e:
            logger.debug(f"Error selecting reconciler: {e}")

    async def action_select_investigator(self) -> None:
        """Route i shortcut by tab (Chat focus, Tickets open, Daemon mode switch)."""
        try:
            tabbed_content = self.query_one("#main-content", TabbedContent)
            if tabbed_content.active == "chat":
                self._focus_chat_input_target()
                return
            if tabbed_content.active == "tickets":
                await self._ensure_aux_tab_mounted("tickets")
                container = self.query_one("#tickets-container", Container)
                for child in container.children:
                    open_ticket = getattr(child, "action_open_investigator", None)
                    if callable(open_ticket):
                        open_ticket()
                        return
                return
            if tabbed_content.active != "daemon":
                return

            await self._ensure_aux_tab_mounted("daemon")
            container = self.query_one("#daemon-container", Container)
            for child in container.children:
                select = getattr(child, "action_select_investigator", None)
                if callable(select):
                    select()
                    return
        except Exception as e:
            logger.debug(f"Error selecting investigator: {e}")

    async def on_tabbed_content_tab_activated(
        self, event: TabbedContent.TabActivated
    ) -> None:
        """Update status bar hints on active tab changes."""
        tab_id = event.tab.id
        if self.status_bar:
            self.status_bar.active_tab = tab_id

        self._log_perf_event("tab_activated", tab_id=tab_id)

        if tab_id in self.AUX_TAB_IDS:
            await self._ensure_aux_tab_mounted(tab_id)

        if tab_id != "chat":
            return
        self.call_after_refresh(self._focus_chat_input_target)

    def _schedule_auto_start_daemon(self) -> None:
        """Schedule the async daemon auto-start (synchronous wrapper for set_timer)."""
        asyncio.create_task(self._auto_start_daemon())

    async def _auto_start_daemon(self) -> None:
        """Auto-start the daemon in autonomous mode."""
        try:
            await self._ensure_aux_tab_mounted("daemon")
            daemon_container = self.query_one("#daemon-container", Container)
            for child in daemon_container.children:
                if isinstance(child, DaemonScreen):
                    await child.start_daemon()
                    self.notify(
                        "Daemon started in autonomous mode", severity="information"
                    )
                    break
        except Exception as e:
            logger.error(f"Failed to auto-start daemon: {e}")

    def on_open_ticket_in_chat(self, message: OpenTicketInChat) -> None:
        """Handle request to open a ticket in chat."""
        ticket = message.ticket
        agent_type = message.agent_type

        # Map ticket action to unified chat mode
        mode = "investigator" if agent_type == "investigator" else "copilot"

        # Switch to unified chat tab and update mode
        tabbed = self.query_one("#main-content", TabbedContent)
        tabbed.active = "chat"
        self._set_chat_mode(mode)

        # Pre-fill the chat input with ticket context
        try:
            container = self.query_one("#chat-container", Container)
            for child in container.children:
                if isinstance(child, AgentChat) or (
                    callable(getattr(child, "set_input_value", None))
                    and callable(getattr(child, "focus_input", None))
                ):
                    # Build ticket context prompt
                    prompt = (
                        f"I'd like to work on ticket {ticket.id}:\n\n"
                        f"**Title**: {ticket.title}\n"
                        f"**Status**: {ticket.status}\n"
                        f"**Priority**: {ticket.priority}\n"
                    )
                    if ticket.tags:
                        prompt += f"**Tags**: {', '.join(ticket.tags)}\n"
                    prompt += "\nPlease help me understand and work on this ticket."

                    # Set the input value
                    child.set_input_value(prompt)
                    child.focus_input()
                    break
        except Exception as e:
            logger.error(f"Failed to open ticket in chat: {e}")
            self.notify(f"Error: {e}", severity="error")


def _load_agent_model_map() -> dict[str, str]:
    """Load agent model names from config, falling back to defaults."""
    from lineage.backends.config import AgentConfig

    config_path = os.environ.get("UNIFIED_CONFIG")
    if not config_path:
        config_path = str(Path.home() / ".typedef" / "config.yaml")
    typedef_config = Path(config_path)
    agent_section: dict = {}
    if typedef_config.exists():
        try:
            import yaml

            with open(typedef_config) as f:
                raw = yaml.safe_load(f) or {}
            agent_section = raw.get("agent", {})
        except Exception as exc:
            logger.debug("Could not load agent config from %s: %s", typedef_config, exc)

    try:
        agent_cfg = AgentConfig(**agent_section)
    except Exception:
        agent_cfg = AgentConfig()

    return {
        "analyst": agent_cfg.analyst.model,
        "data_engineer": agent_cfg.data_engineer.model,
        "investigator": agent_cfg.investigator.model,
        "insights": agent_cfg.insights.model,
        "copilot": agent_cfg.data_engineer.model,
        "quality": agent_cfg.quality.model,
    }


def main():
    """Run the TUI application."""
    import sys

    import yaml

    if "--help" in sys.argv or "-h" in sys.argv:
        print("Data Concierge TUI")
        print("Usage: lineage-tui")
        print("\nRuns the Data Concierge TUI with a local backend server.")
        return

    # Load typedef config if not already configured via typedef chat
    # This ensures GIT_WORKING_DIR is set correctly when running lineage-tui directly
    typedef_config = Path.home() / ".typedef" / "config.yaml"
    if typedef_config.exists() and "GIT_WORKING_DIR" not in os.environ:
        try:
            with open(typedef_config) as f:
                config = yaml.safe_load(f)

            # Get active project (from env or default)
            active_project = os.environ.get("TYPEDEF_ACTIVE_PROJECT")
            if not active_project:
                active_project = config.get("default_project")
                if active_project:
                    os.environ["TYPEDEF_ACTIVE_PROJECT"] = active_project

            # Get dbt_path from project config
            projects = config.get("projects", {})
            if active_project and active_project in projects:
                project_config = projects[active_project]
                dbt_path = project_config.get("dbt_path")
                if dbt_path:
                    os.environ["GIT_WORKING_DIR"] = str(
                        Path(dbt_path).expanduser().resolve()
                    )
                    logger.info(f"Set GIT_WORKING_DIR={os.environ['GIT_WORKING_DIR']}")

            # Set UNIFIED_CONFIG if not set
            if "UNIFIED_CONFIG" not in os.environ:
                os.environ["UNIFIED_CONFIG"] = str(typedef_config)

        except Exception as e:
            logger.warning(f"Failed to load typedef config: {e}")

    # Check for daemon mode
    daemon_mode = os.environ.get("TYPEDEF_DAEMON_MODE") == "1"

    # Check for flat mode
    flat_mode = os.environ.get("TYPEDEF_FLAT_MODE") == "1"

    app = DataConciergeApp(daemon_mode=daemon_mode, flat_mode=flat_mode)
    app._agent_model_map = _load_agent_model_map()
    app.run()


if __name__ == "__main__":
    main()
