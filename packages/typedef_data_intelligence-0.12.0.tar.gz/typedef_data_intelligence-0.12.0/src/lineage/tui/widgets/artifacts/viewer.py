"""ArtifactViewer widget for displaying tool outputs.

The main container widget that manages artifact display and history.
"""

import logging
import re
import uuid
from time import monotonic
from typing import TYPE_CHECKING, Any, Dict, List, Optional

if TYPE_CHECKING:
    from lineage.tui.screens.chat import RunStats, SubagentStats

from textual.app import ComposeResult
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.widgets import (
    Button,
    Label,
    ListItem,
    ListView,
    Markdown,
    Static,
)

from lineage.backends.reports.protocol import CellData
from lineage.tui.perf import get_perf_logger
from lineage.tui.widgets.artifacts.artifact_types import (
    ArtifactData,
    ClickableMarkdown,
    ExportReportRequest,
)
from lineage.tui.widgets.artifacts.builders import (
    build_context_brief_widget,
    build_graph_result_widget,
    build_impact_tree_widget,
    build_model_details_widget,
    build_plan_markdown,
    build_search_results_widget,
    build_table_widget,
)
from lineage.tui.widgets.artifacts.cell_renderers import (
    _render_cell,
    _render_chart_cell,
    _render_mermaid_cell,
)
from lineage.tui.widgets.artifacts.formatters import (
    _format_lineage_node_card,
)
from lineage.tui.widgets.artifacts.helpers import (
    _create_temp_dir,
    _escape_markdown,
    _get_short_name,
    _get_type_icon,
    _group_nodes_by_type,
)

logger = logging.getLogger(__name__)


class ArtifactViewer(Container):
    """Container for displaying artifacts (tables, charts, reports) with history."""

    def __init__(self):
        """Initialize the artifact viewer."""
        super().__init__(id="artifact-viewer")
        self.artifacts: List[ArtifactData] = []  # Plans, reports, explores, etc.
        self.activities: List[ArtifactData] = []  # Activity/run summaries only

        self.title = Label("Artifact Preview", id="artifact-title")
        self.artifact_list = ListView(id="artifact-list")
        self.activity_list = ListView(id="activity-list")
        self.content_area = VerticalScroll(id="artifact-content")

        # Index for quick artifact lookup by ID
        self._artifact_index: Dict[str, ArtifactData] = {}
        self._perf = get_perf_logger()

    def _log_perf_event(self, event: str, **payload: Any) -> None:
        """Emit structured perf events when enabled."""
        self._perf.log_event(event, **payload)

    def compose(self) -> ComposeResult:
        """Create child widgets."""
        yield self.title
        with Horizontal(id="artifact-split-view"):
            with Vertical(id="artifact-sidebar"):
                yield self.artifact_list
            yield self.content_area

    def on_list_view_selected(self, event: ListView.Selected):
        """Handle artifact selection."""
        source_list = self.artifacts

        if not source_list:
            return

        index = event.list_view.index
        if index is not None and 0 <= index < len(source_list):
            self._render_artifact(source_list[index])

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses, including Export HTML button."""
        button_id = event.button.id or ""
        if button_id.startswith("export-report-"):
            # Get report_id and artifact_id from button attributes
            report_id = getattr(event.button, "report_id", None)
            artifact_id = getattr(event.button, "artifact_id", None)
            if report_id and artifact_id:
                # Emit export request message to be handled by AgentChat
                self.post_message(ExportReportRequest(report_id, artifact_id))
            event.stop()
        elif button_id.startswith("copy-plan-"):
            plan_markdown = getattr(event.button, "plan_markdown", "")
            if plan_markdown:
                try:
                    self.app.copy_to_clipboard(plan_markdown)
                    self.app.notify("Plan copied to clipboard", title="Copied")
                except Exception as e:
                    logger.error(f"Failed to copy plan: {e}")
                    self.app.notify(f"Copy failed: {e}", severity="error")
            event.stop()

    def _add_artifact(self, artifact: ArtifactData) -> str:
        """Add artifact to history and display it.

        Returns:
            The artifact ID
        """
        # Determine target list based on artifact type.
        # Activity artifacts are stored for bookkeeping only; they are not
        # rendered in the modal list.
        is_activity = artifact.type == "activity"
        target_list = self.activities if is_activity else self.artifacts
        target_view = None if is_activity else self.artifact_list

        # Check for existing artifact to update (for reports mainly)
        existing_index = -1
        if artifact.type == "report":
            for i, existing in enumerate(target_list):
                # Check if it's the same report ID (fuzzy match on title or ID)
                existing_id = existing.data.get("title")
                new_id = artifact.data.get("title")
                if existing_id and new_id and existing_id == new_id:
                    existing_index = i
                    break
        if artifact.type == "plan":
            new_plan_id = artifact.data.get("plan_id")
            if new_plan_id:
                for i, existing in enumerate(target_list):
                    if existing.data.get("plan_id") == new_plan_id:
                        existing_index = i
                        break
        if artifact.type == "explore":
            new_explore_id = artifact.data.get("explore_id")
            if new_explore_id:
                for i, existing in enumerate(target_list):
                    if existing.data.get("explore_id") == new_explore_id:
                        existing_index = i
                        break
        if artifact.type == "brief":
            new_brief_id = artifact.data.get("brief_id")
            if new_brief_id:
                for i, existing in enumerate(target_list):
                    if existing.data.get("brief_id") == new_brief_id:
                        existing_index = i
                        break

        icon = self._icon_for_type(artifact.type)

        display_title = artifact.title
        title_widget = Static(f"{icon} {display_title}", classes="history-title")

        # Add to index for quick lookup
        self._artifact_index[artifact.id] = artifact

        if existing_index >= 0:
            # Update existing
            old_artifact = target_list[existing_index]
            if old_artifact.id in self._artifact_index:
                del self._artifact_index[old_artifact.id]
            target_list[existing_index] = artifact
            self._artifact_index[artifact.id] = artifact
            # Re-render if selected
            if target_view is not None and target_view.index == existing_index:
                self._render_artifact(artifact)
        else:
            # Add new
            target_list.append(artifact)
            if target_view is not None:
                target_view.append(ListItem(title_widget))

            # Select in list (harmless - just updates list selection)
            if target_view is not None:
                new_index = len(target_list) - 1
                target_view.index = new_index

            # Activity artifacts remain stored for backend bookkeeping but are not
            # shown in the modal artifact list.
            if not is_activity:
                self._render_artifact(artifact)

        return artifact.id

    def select_artifact_by_id(self, artifact_id: str) -> bool:
        """Select and display an artifact by its ID.

        Args:
            artifact_id: The ID of the artifact to select

        Returns:
            True if artifact was found and selected, False otherwise
        """
        artifact = self._artifact_index.get(artifact_id)
        if not artifact:
            return False

        # Only artifact list is user-visible in modal.
        if artifact.type == "activity":
            return False
        target_list = self.artifacts
        target_view = self.artifact_list

        try:
            index = target_list.index(artifact)
            target_view.index = index
            self._render_artifact(artifact)
            return True
        except ValueError:
            return False

    def _render_artifact(self, artifact: ArtifactData):
        """Render the specified artifact in the content area."""
        start = monotonic()
        self._log_perf_event(
            "artifact_render_started",
            artifact_id=artifact.id,
            artifact_type=artifact.type,
            tool_call_id=artifact.tool_call_id,
        )
        self.title.update(f"{artifact.title}")
        self.content_area.remove_children()

        try:
            artifact.render_func(self, artifact.data)
        except Exception as e:
            logger.error(f"Error rendering artifact: {e}")
            self.content_area.mount(
                Label(f"❌ Error displaying artifact: {e}", classes="error-label")
            )
        finally:
            self._log_perf_event(
                "artifact_render_finished",
                artifact_id=artifact.id,
                artifact_type=artifact.type,
                tool_call_id=artifact.tool_call_id,
                duration_ms=round((monotonic() - start) * 1000, 2),
            )

    def _is_selected_artifact(self, artifact_id: str) -> bool:
        """Return whether the artifact is currently selected in the sidebar."""
        try:
            idx = self.artifact_list.index
            return (
                idx is not None
                and 0 <= idx < len(self.artifacts)
                and self.artifacts[idx].id == artifact_id
            )
        except Exception:
            return False

    def update_report_cells(self, artifact_id: str, cells: List[CellData]) -> bool:
        """Update an existing report artifact with new cells.

        Args:
            artifact_id: The ID of the report artifact to update
            cells: The updated list of CellData models

        Returns:
            True if updated successfully, False if artifact not found
        """
        artifact = self._artifact_index.get(artifact_id)
        if not artifact:
            return False

        artifact.data["cells"] = cells
        if self._is_selected_artifact(artifact_id):
            self._render_artifact(artifact)
        return True

    def update_report_html_path(self, artifact_id: str, html_path: str) -> bool:
        """Update an existing report artifact with HTML export path.

        Args:
            artifact_id: The ID of the report artifact to update
            html_path: Path to the exported HTML file

        Returns:
            True if updated successfully, False if artifact not found
        """
        artifact = self._artifact_index.get(artifact_id)
        if not artifact:
            return False

        artifact.data["html_path"] = html_path
        if self._is_selected_artifact(artifact_id):
            self._render_artifact(artifact)
        return True

    def clear_history(self) -> None:
        """Reset all artifact/activity history and preview content."""
        self.artifacts.clear()
        self.activities.clear()
        self._artifact_index.clear()
        self.artifact_list.remove_children()
        self.activity_list.remove_children()
        self.content_area.remove_children()
        self.title.update("Artifact Preview")

    @staticmethod
    def _icon_for_type(artifact_type: str) -> str:
        """Return a display icon for artifact/activity type."""
        return {
            "table": "📊",
            "chart": "📈",
            "plan": "🧭",
            "explore": "🧠",
            "brief": "🔍",
            "report": "📄",
            "activity": "📍",
            "subagent": "🤖",
            "report_cells": "📄",
            "lineage": "🔗",
            "subject_areas": "📂",
            "subject_area": "🗂",
            "search": "🔎",
            "model": "🏷",
            "impact": "🌊",
            "ticket": "🎫",
            "tickets": "🎫",
            "todo": "✓",
            "command": "⌘",
            "graph": "🕸",
            "mermaid": "🧩",
            "diagnostics": "🩺",
            "domain_search": "🌐",
        }.get(artifact_type, "📎")

    def populate_from(
        self,
        artifacts: List[ArtifactData],
        activities: List[ArtifactData],
    ) -> None:
        """Populate viewer history from existing artifact/activity records."""
        self.clear_history()

        for artifact in artifacts:
            self.artifacts.append(artifact)
            self._artifact_index[artifact.id] = artifact
            title = f"{self._icon_for_type(artifact.type)} {artifact.title}"
            self.artifact_list.append(ListItem(Label(title, classes="history-title")))

        for activity in activities:
            self.activities.append(activity)
            self._artifact_index[activity.id] = activity

        if self.artifacts:
            self.artifact_list.index = len(self.artifacts) - 1
            self._render_artifact(self.artifacts[-1])
            return

    def mark_report_ready(self, artifact_id: str) -> bool:
        """Mark a report as ready for export (shows the Export button).

        Call this when the agent run completes to enable the Export HTML button.

        Args:
            artifact_id: The ID of the report artifact

        Returns:
            True if updated successfully, False if artifact not found
        """
        artifact = self._artifact_index.get(artifact_id)
        if not artifact:
            return False

        artifact.data["is_ready"] = True
        if self._is_selected_artifact(artifact_id):
            self._render_artifact(artifact)
        return True

    # --- Public Methods called by AgentChat ---

    def show_table(
        self,
        title: str,
        columns: List[str],
        rows: List[List[Any]],
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display a table artifact.

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            viewer.content_area.mount(
                build_table_widget(columns=data["columns"], rows=data["rows"])
            )

        artifact_id = f"table-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="table",
                title=title,
                data={"columns": columns, "rows": rows},
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_chart(
        self,
        title: str,
        chart_data: dict,
        chart_type: str,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display a chart artifact with clickable link to open PNG.

        Generates PNG and shows data preview with link to open full image.

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            # Create output directory for chart PNG
            output_dir = _create_temp_dir(prefix="chart_tui_")

            # Build cell data structure (use cell_type to match Pydantic models)
            cell = {
                "cell_type": "chart",
                "data": {
                    "title": data["title"],
                    "chart_type": data["chart_type"],
                    "data": data["chart_data"].get("data", []),
                    "x_column": data["chart_data"].get("x_column"),
                    "y_column": data["chart_data"].get("y_column"),
                },
            }

            # Render using cell renderer (pass data dict, not full cell)
            content = _render_chart_cell(cell["data"], output_dir)
            viewer.content_area.mount(
                ClickableMarkdown(content, classes="chart-artifact")
            )

        artifact_id = f"chart-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="chart",
                title=title,
                data={
                    "title": title,
                    "chart_data": chart_data,
                    "chart_type": chart_type,
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_command_output(
        self,
        title: str,
        command: str,
        working_dir: str,
        exit_code: int,
        stdout: str,
        stderr: Optional[str] = None,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display CLI command output (bash/dbt) with stdout/stderr."""

        def render(viewer, data):
            def _wrap_code_block(text: str) -> list[str]:
                """Wrap text in a safe code fence that won't be closed by content."""
                backtick_runs = re.findall(r"`+", text)
                max_ticks = max((len(run) for run in backtick_runs), default=0)
                fence = "`" * max(3, max_ticks + 1)
                return [fence, text, fence]

            content_parts = [f"# {data['title']}", ""]
            content_parts.append(f"**Command:** `{_escape_markdown(data['command'])}`")
            content_parts.append(
                f"**Working Dir:** `{_escape_markdown(data['working_dir'])}`"
            )
            status = (
                "✅ success"
                if data["exit_code"] == 0
                else f"❌ exit {data['exit_code']}"
            )
            content_parts.append(f"**Status:** {status}")
            content_parts.append("")

            stdout_text = data.get("stdout") or ""
            stderr_text = data.get("stderr") or ""

            content_parts.append("## Stdout")
            content_parts.append("")
            if stdout_text.strip():
                content_parts.extend(_wrap_code_block(stdout_text))
            else:
                content_parts.append("*No stdout*")
            content_parts.append("")

            if stderr_text.strip():
                content_parts.append("## Stderr")
                content_parts.append("")
                content_parts.extend(_wrap_code_block(stderr_text))
                content_parts.append("")

            viewer.content_area.mount(
                Markdown("\n".join(content_parts), classes="command-output")
            )

        artifact_id = f"command-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="command",
                title=title,
                data={
                    "title": title,
                    "command": command,
                    "working_dir": working_dir,
                    "exit_code": exit_code,
                    "stdout": stdout,
                    "stderr": stderr,
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_graph_result(
        self,
        title: str,
        nodes: List[Any],
        query_description: str = "",
        display_hint: Optional[str] = None,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display graph query results with smart rendering based on structure.

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            viewer.content_area.mount(
                build_graph_result_widget(
                    title=data["title"],
                    nodes=data.get("nodes", []),
                    query_description=data.get("description", ""),
                    display_hint=data.get("display_hint"),
                )
            )

        artifact_id = f"graph-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="graph",
                title=title,
                data={
                    "title": title,
                    "nodes": nodes,
                    "description": query_description,
                    "display_hint": display_hint,
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_lineage(
        self,
        title: str,
        root: str,
        nodes: List[Any],
        direction: str,
        query_description: str = "",
        hops: Optional[List[Any]] = None,
        edges: Optional[List[Any]] = None,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display lineage as a structured tree view.

        Args:
            title: Title for the lineage display
            root: Root node identifier
            nodes: List of LineageOverviewNode dicts (lightweight, with semantic_summary)
            direction: Direction of lineage traversal
            query_description: Human-readable description
            hops: Column lineage hops (for column lineage only)
            edges: List of LineageRelationship dicts (from_id, to_id, edge_type)
            tool_call_id: Optional tool call ID for state tracking

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            root_id = data["root"]
            nodes_data = data["nodes"]
            dir_type = data["direction"]
            desc = data.get("description", "")
            hops = data.get("hops") or []
            edges = data.get("edges") or []

            content_parts = [f"# Lineage: {_escape_markdown(root_id)}", ""]

            if desc:
                content_parts.append(f"*{_escape_markdown(desc)}*")
                content_parts.append("")

            content_parts.append(f"**Direction:** {dir_type}")
            content_parts.append(
                f"**Found {len(nodes_data)} nodes, {len(edges)} edges**"
            )
            content_parts.append("")

            # Hop summary (for column lineage)
            if hops:
                transforms = []
                for hop in hops:
                    if isinstance(hop, dict):
                        transforms.extend(
                            [str(t) for t in hop.get("transformations", [])]
                        )
                unique_transforms = []
                for t in transforms:
                    if t not in unique_transforms:
                        unique_transforms.append(t)
                if unique_transforms:
                    palette = ", ".join(unique_transforms[:8])
                    more = (
                        ""
                        if len(unique_transforms) <= 8
                        else f" (+{len(unique_transforms) - 8} more)"
                    )
                    content_parts.append(f"**Transform palette:** {palette}{more}")
                content_parts.append(f"**Hops:** {len(hops)}")
                content_parts.append("")

                content_parts.append("### Hop Steps")
                for idx, hop in enumerate(hops, start=1):
                    if not isinstance(hop, dict):
                        continue
                    from_id = hop.get("from_id") or "?"
                    to_id = hop.get("to_id") or "?"
                    transformations = hop.get("transformations") or []
                    t_str = (
                        ", ".join(str(t) for t in transformations)
                        if transformations
                        else "DERIVES_FROM"
                    )
                    content_parts.append(f"{idx}. `{from_id}` → `{to_id}`  via {t_str}")
                content_parts.append("")

            # Node type summary
            by_type = _group_nodes_by_type(nodes_data)
            for node_type, items in by_type.items():
                icon = _get_type_icon(node_type)
                content_parts.append(f"- {icon} **{node_type}**: {len(items)}")
            content_parts.append("")

            # Show dependency edges (for relation lineage)
            if edges:
                content_parts.append("### Dependencies")
                depends_on = [
                    e
                    for e in edges
                    if isinstance(e, dict) and e.get("edge_type") == "DEPENDS_ON"
                ]
                builds = [
                    e
                    for e in edges
                    if isinstance(e, dict) and e.get("edge_type") == "BUILDS"
                ]

                if depends_on:
                    for edge in depends_on[:15]:  # Limit to 15 edges
                        from_name = _get_short_name(edge.get("from_id", "?"))
                        to_name = _get_short_name(edge.get("to_id", "?"))
                        content_parts.append(f"  `{from_name}` → `{to_name}`")
                    if len(depends_on) > 15:
                        content_parts.append(
                            f"  *... and {len(depends_on) - 15} more dependencies*"
                        )

                if builds:
                    content_parts.append("")
                    content_parts.append("### Builds (Logical → Physical)")
                    for edge in builds[:10]:
                        from_name = _get_short_name(edge.get("from_id", "?"))
                        to_name = _get_short_name(edge.get("to_id", "?"))
                        content_parts.append(f"  `{from_name}` ⟶ `{to_name}`")
                    if len(builds) > 10:
                        content_parts.append(
                            f"  *... and {len(builds) - 10} more builds*"
                        )

                content_parts.append("")

            content_parts.append("---")
            content_parts.append("")

            # Show hop-level transformations if available (for column lineage)
            if hops:
                content_parts.append("### Transformations")
                for hop in hops:
                    if not isinstance(hop, dict):
                        continue
                    from_id = hop.get("from_id") or "?"
                    to_id = hop.get("to_id") or "?"
                    transforms = hop.get("transformations") or []
                    if transforms:
                        t_str = ", ".join(str(t) for t in transforms)
                    else:
                        t_str = "DERIVES_FROM"
                    content_parts.append(f"- `{from_id}` → `{to_id}` : {t_str}")
                content_parts.append("")

            # Node cards with semantic summaries
            max_cards = 10
            cards_rendered = 0
            for node in nodes_data:
                if cards_rendered >= max_cards:
                    remaining = len(nodes_data) - max_cards
                    if remaining > 0:
                        content_parts.append(
                            f"*... and {remaining} more nodes (use get_model_details for specifics)*"
                        )
                    break
                if isinstance(node, dict):
                    content_parts.append(_format_lineage_node_card(node))
                    content_parts.append("---")
                    content_parts.append("")
                    cards_rendered += 1

            viewer.content_area.mount(
                Markdown("\n".join(content_parts), classes="lineage-result")
            )

        artifact_id = f"lineage-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="lineage",
                title=title,
                data={
                    "title": title,
                    "root": root,
                    "nodes": nodes,
                    "direction": direction,
                    "description": query_description,
                    "hops": hops or [],
                    "edges": edges or [],
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_model_details(
        self,
        title: str,
        model_details: Dict[str, Any],
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display detailed model information from get_model_details.

        Args:
            title: Title for the display
            model_details: ModelDetailsResult as dict
            tool_call_id: Optional tool call ID for state tracking

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            viewer.content_area.mount(
                build_model_details_widget(model_details=data["model_details"])
            )

        artifact_id = f"model-details-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="model_details",
                title=title,
                data={"model_details": model_details},
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_report(
        self,
        title: str,
        report_path: Optional[str] = None,
        message: Optional[str] = None,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display a simple report artifact (path optional).

        For cellular reports with multiple cell types, use show_report_cells().

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            msg_lines = ["# Report", ""]
            if data.get("title"):
                msg_lines.append(f"**Title:** {data['title']}")
            if data.get("report_path"):
                msg_lines.append(f"**Path:** `{data['report_path']}`")
                msg_lines.append("")
                msg_lines.append(f"[Open in Browser]({data['report_path']})")
            elif data.get("message"):
                msg_lines.append(data["message"])

            viewer.content_area.mount(
                ClickableMarkdown("\n".join(msg_lines), classes="report-output")
            )

        artifact_id = f"report-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="report",
                title=title or "Report",
                data={
                    "title": title,
                    "report_path": report_path,
                    "message": message,
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_plan(
        self,
        *,
        title: str,
        plan: Dict[str, Any],
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Show a plan artifact (and select it in the sidebar)."""

        def render(viewer: "ArtifactViewer", data: Dict[str, Any]) -> None:
            plan_markdown = build_plan_markdown(plan=data["plan"])
            btn_id = f"copy-plan-{uuid.uuid4().hex[:8]}"
            copy_btn = Button(
                "Copy Plan", id=btn_id, variant="primary", classes="copy-btn"
            )
            copy_btn.plan_markdown = plan_markdown
            viewer.content_area.mount(copy_btn)
            viewer.content_area.mount(Markdown(plan_markdown, classes="plan-preview"))

        artifact_id = f"plan-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="plan",
                title=title or "Plan",
                data={
                    "plan_id": plan.get("plan_id"),
                    "plan": plan,
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_context_brief(
        self,
        *,
        brief: Any,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Show a context brief artifact (and select it in the sidebar)."""
        brief_dict = (
            brief.model_dump(mode="json") if hasattr(brief, "model_dump") else brief
        )
        title = brief_dict.get("title") or "Context Brief"

        def render(viewer: "ArtifactViewer", data: Dict[str, Any]) -> None:
            viewer.content_area.mount(build_context_brief_widget(brief=data["brief"]))

        artifact_id = f"brief-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="brief",
                title=title,
                data={
                    "brief_id": brief_dict.get("brief_id"),
                    "brief": brief_dict,
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def update_plan(self, *, artifact_id: str, plan: Dict[str, Any]) -> bool:
        """Update an existing plan artifact with the latest plan snapshot."""
        artifact = self._artifact_index.get(artifact_id)
        if not artifact:
            return False
        if artifact.type != "plan":
            return False

        artifact.data["plan"] = plan

        # Re-render if selected
        try:
            if (
                self.artifact_list.index is not None
                and self.artifacts[self.artifact_list.index].id == artifact_id
            ):
                self._render_artifact(artifact)
        except Exception:
            logger.debug(
                "Failed to re-render plan artifact after update", exc_info=True
            )
        return True

    def show_report_cells(
        self,
        title: str,
        report_id: str,
        cells: List[CellData],
        html_path: Optional[str] = None,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display a full cellular report with all cell types.

        Renders each cell type appropriately:
        - markdown: Native Rich markdown
        - table: Markdown table format
        - chart: Title + data preview + clickable link to PNG
        - mermaid: Source + mermaid.live link + clickable PNG link

        Args:
            title: Report title
            report_id: Unique report identifier
            cells: List of CellData Pydantic models
            html_path: Optional path to HTML export for "Open in Browser"
            tool_call_id: Optional tool call ID for linking

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            # Create output directory for any generated PNGs
            output_dir = _create_temp_dir(prefix="report_tui_")

            # Add Export button only when report is ready (has cells and is_ready flag)
            # Use unique ID each render to avoid Textual widget ID collision
            if (
                data.get("is_ready")
                and not data.get("html_path")
                and data.get("report_id")
            ):
                btn_id = f"export-report-{uuid.uuid4().hex[:8]}"
                export_btn = Button(
                    "Export HTML",
                    id=btn_id,
                    variant="primary",
                    classes="export-btn",
                )
                # Store report_id and artifact_id on the button for the click handler
                export_btn.report_id = data["report_id"]
                export_btn.artifact_id = data.get("artifact_id")
                viewer.content_area.mount(export_btn)

            parts = []

            # Header with title
            parts.append(f"# {data['title']}")
            parts.append("")

            # Open in Browser link if HTML path provided
            if data.get("html_path"):
                parts.append(f"[Open Full Report in Browser]({data['html_path']})")
                parts.append("")

            parts.append("---")
            parts.append("")

            # Render each cell
            for cell in data.get("cells", []):
                cell_content = _render_cell(cell, output_dir)
                parts.append(cell_content)
                parts.append("")
                parts.append("---")
                parts.append("")

            viewer.content_area.mount(
                ClickableMarkdown("\n".join(parts), classes="report-cells")
            )

        artifact_id = f"report-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="report",
                title=title or "Report",
                data={
                    "title": title,
                    "report_id": report_id,
                    "cells": cells,
                    "html_path": html_path,
                    "artifact_id": artifact_id,  # Include for export button
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_mermaid(
        self,
        title: str,
        diagram: str,
        description: Optional[str] = None,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display a Mermaid diagram artifact with clickable links.

        Shows mermaid.live link and optional PNG link. Click to open externally.

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            diagram_text = data["diagram"]
            desc = data.get("description", "")

            # Create output directory for mermaid PNG
            output_dir = _create_temp_dir(prefix="mermaid_tui_")

            parts = []

            # Add description if present
            if desc:
                parts.append(f"*{desc}*")
                parts.append("")

            # Build cell data structure (use cell_type to match Pydantic models)
            cell = {
                "cell_type": "mermaid",
                "data": {
                    "title": data["title"],
                    "diagram": diagram_text,
                },
            }

            # Render using cell renderer (pass data dict, not full cell)
            cell_content = _render_mermaid_cell(cell["data"], output_dir)
            parts.append(cell_content)

            viewer.content_area.mount(
                ClickableMarkdown("\n".join(parts), classes="mermaid-artifact")
            )

        artifact_id = f"mermaid-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="mermaid",
                title=title,
                data={"title": title, "diagram": diagram, "description": description},
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_search_results(
        self,
        search_term: str,
        results: List[Any],
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display fuzzy search results with match scores.

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            viewer.content_area.mount(
                build_search_results_widget(
                    search_term=data["term"], results=data["results"]
                )
            )

        artifact_id = f"search-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="search",
                title=f"Search: {search_term}",
                data={"term": search_term, "results": results},
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_model_semantics(
        self,
        model_id: str,
        model_name: str,
        grain: str,
        intent: str,
        measures: List,
        dimensions: List,
        facts: List,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display model semantic analysis.

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            content_parts = [f"## 🧠 {data['name']}"]
            content_parts.append("")

            if data.get("grain"):
                content_parts.append(f"**Grain:** {data['grain']}")
                content_parts.append("")
            if data.get("intent"):
                content_parts.append(f"**Intent:** {data['intent']}")
                content_parts.append("")

            measures_data = data.get("measures", [])
            if measures_data:
                content_parts.append(f"📏 **Measures** ({len(measures_data)}):")
                content_parts.append("")
                for m in measures_data[:10]:
                    if isinstance(m, dict):
                        name = m.get("name", "?")
                        agg = m.get("agg_function", "")
                        content_parts.append(f"- {name} ({agg})")
                content_parts.append("")

            dims_data = data.get("dimensions", [])
            if dims_data:
                content_parts.append(f"📐 **Dimensions** ({len(dims_data)}):")
                content_parts.append("")
                dim_names = [
                    d.get("name") if isinstance(d, dict) else str(d)
                    for d in dims_data[:15]
                ]
                # Break into multiple lines for readability
                for i in range(0, len(dim_names), 5):
                    chunk = dim_names[i : i + 5]
                    content_parts.append(f"- {', '.join(chunk)}")
                content_parts.append("")

            viewer.content_area.mount(
                Markdown("\n".join(content_parts), classes="model-semantics")
            )

        artifact_id = f"semantics-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="semantics",
                title=f"Semantics: {model_name or model_id}",
                data={
                    "name": model_name or model_id,
                    "grain": grain,
                    "intent": intent,
                    "measures": measures,
                    "dimensions": dimensions,
                    "facts": facts,
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_impact_tree(
        self,
        model_id: str,
        model_name: str,
        affected_models: List,
        total: int,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display downstream impact as a clear list grouped by depth.

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            viewer.content_area.mount(
                build_impact_tree_widget(
                    model_name=data["name"],
                    affected_models=data["affected"],
                    total=data["total"],
                )
            )

        artifact_id = f"impact-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="impact",
                title=f"Impact: {model_name or model_id}",
                data={
                    "name": model_name or model_id,
                    "affected": affected_models,
                    "total": total,
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_activity_summary(self, run_stats: "RunStats") -> str:
        """Display an activity summary for a completed run.

        Args:
            run_stats: RunStats object with run metrics

        Returns:
            The artifact ID
        """
        # Import here to avoid circular dependency
        from lineage.tui.screens.chat import RunStats as RunStatsType

        def render(viewer, data):
            stats: RunStatsType = data["stats"]
            content_parts = ["## ⚡ Activity Summary", ""]

            # Duration
            if stats.duration_seconds is not None:
                content_parts.append(f"**Duration:** {stats.duration_seconds:.1f}s")
            content_parts.append(f"**Tool Calls:** {stats.tool_call_count}")
            content_parts.append("")

            # Tool call list with durations
            if stats.tool_calls:
                content_parts.append("### Steps")
                content_parts.append("")
                for i, tc in enumerate(stats.tool_calls, 1):
                    duration_str = ""
                    if tc.duration_seconds is not None:
                        duration_str = f" ({tc.duration_seconds:.1f}s)"
                    # Show link indicator if artifact was created
                    link_indicator = " → 📎" if tc.artifact_id else ""
                    content_parts.append(
                        f"{i}. {tc.display_text}{duration_str}{link_indicator}"
                    )
                content_parts.append("")

            # User query (truncated)
            if stats.user_message:
                truncated = stats.user_message[:100]
                if len(stats.user_message) > 100:
                    truncated += "..."
                content_parts.append(f"**Your question:** {truncated}")
                content_parts.append("")

            # Response stats
            if stats.response_char_count:
                content_parts.append(
                    f"**Response:** {stats.response_char_count:,} chars"
                )
                content_parts.append("")

            viewer.content_area.mount(
                Markdown("\n".join(content_parts), classes="activity-summary")
            )

        # Create a short title from user message
        title_preview = run_stats.user_message[:30] if run_stats.user_message else "Run"
        if run_stats.user_message and len(run_stats.user_message) > 30:
            title_preview += "..."

        artifact_id = f"activity-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="activity",
                title=title_preview,
                data={"stats": run_stats},
                render_func=render,
            )
        )

    def show_subagent_summary(self, subagent_stats: "SubagentStats") -> str:
        """Display a summary for a completed subagent execution.

        Args:
            subagent_stats: SubagentStats object with subagent metrics

        Returns:
            The artifact ID
        """
        # Import here to avoid circular dependency
        from lineage.tui.screens.chat import SubagentStats as SubagentStatsType

        def render(viewer, data):
            stats: SubagentStatsType = data["stats"]
            content_parts = [f"## 🤖 {stats.subagent_type}", ""]

            # Input prompt - what the orchestrator asked the subagent to do
            if stats.input_prompt:
                content_parts.append("### Task")
                content_parts.append("")
                # Truncate long prompts for display
                prompt_preview = stats.input_prompt
                if len(prompt_preview) > 500:
                    prompt_preview = prompt_preview[:500] + "..."
                content_parts.append(f"> {prompt_preview}")
                content_parts.append("")

            # Duration and tool count
            if stats.duration_seconds is not None:
                content_parts.append(f"**Duration:** {stats.duration_seconds:.1f}s")
            content_parts.append(f"**Tool Calls:** {stats.tool_call_count}")
            content_parts.append("")

            # Tool call list with durations
            if stats.tool_calls:
                content_parts.append("### Tools Used")
                content_parts.append("")
                for i, tc in enumerate(stats.tool_calls, 1):
                    duration_str = ""
                    if tc.duration_seconds is not None:
                        duration_str = f" ({tc.duration_seconds:.1f}s)"
                    content_parts.append(f"{i}. {tc.display_text}{duration_str}")
                content_parts.append("")

            # Result preview
            if stats.result_preview:
                content_parts.append("### Result Preview")
                content_parts.append("")
                content_parts.append(f"```\n{stats.result_preview}\n```")
                content_parts.append("")

            viewer.content_area.mount(
                Markdown("\n".join(content_parts), classes="subagent-summary")
            )

        artifact_id = f"subagent-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="activity",  # Goes to Activity tab
                title=f"🤖 {subagent_stats.subagent_type}",
                data={"stats": subagent_stats},
                render_func=render,
            )
        )

    def show_ticket(
        self,
        ticket_id: str,
        title: str,
        status: str,
        priority: str,
        description: str = "",
        assigned_to: Optional[str] = None,
        tags: Optional[List[str]] = None,
        created_by: Optional[str] = None,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display a single ticket details artifact.

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            content_parts = [f"## 🎫 {data['title']}", ""]

            # Status and priority badges
            status_icons = {
                "open": "🔵",
                "in_progress": "🟡",
                "in_review": "🟠",
                "done": "🟢",
                "closed": "⚫",
                "cancelled": "❌",
            }
            priority_icons = {
                "urgent": "🔴",
                "high": "🟠",
                "medium": "🟡",
                "low": "🟢",
            }
            status_icon = status_icons.get(data["status"].lower(), "⚪")
            priority_icon = priority_icons.get(data["priority"].lower(), "⚪")

            content_parts.append(f"**ID:** `{data['ticket_id']}`")
            content_parts.append(f"**Status:** {status_icon} {data['status']}")
            content_parts.append(f"**Priority:** {priority_icon} {data['priority']}")
            if data.get("assigned_to"):
                content_parts.append(f"**Assigned to:** {data['assigned_to']}")
            if data.get("created_by"):
                content_parts.append(f"**Created by:** {data['created_by']}")
            if data.get("tags"):
                content_parts.append(f"**Tags:** {', '.join(data['tags'])}")
            content_parts.append("")

            if data.get("description"):
                content_parts.append("### Description")
                content_parts.append("")
                content_parts.append(data["description"])

            viewer.content_area.mount(
                Markdown("\n".join(content_parts), classes="ticket-details")
            )

        artifact_id = f"ticket-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="ticket",
                title=f"🎫 {title[:30]}{'...' if len(title) > 30 else ''}",
                data={
                    "ticket_id": ticket_id,
                    "title": title,
                    "status": status,
                    "priority": priority,
                    "description": description,
                    "assigned_to": assigned_to,
                    "created_by": created_by,
                    "tags": tags or [],
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_ticket_list(
        self,
        tickets: List[Dict[str, Any]],
        count: int,
        filter_info: Optional[str] = None,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display a list of tickets artifact.

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            tickets_data = data["tickets"]
            total_count = data["count"]
            filter_str = data.get("filter_info", "")

            content_parts = ["## 📋 Tickets", ""]

            if filter_str:
                content_parts.append(f"*Filtered by: {filter_str}*")
                content_parts.append("")

            content_parts.append(
                f"**Found:** {total_count} ticket{'s' if total_count != 1 else ''}"
            )
            content_parts.append("")

            if not tickets_data:
                content_parts.append("*No tickets match the criteria*")
            else:
                # Status and priority icons
                status_icons = {
                    "open": "🔵",
                    "in_progress": "🟡",
                    "in_review": "🟠",
                    "done": "🟢",
                    "closed": "⚫",
                }
                priority_icons = {
                    "urgent": "🔴",
                    "high": "🟠",
                    "medium": "🟡",
                    "low": "🟢",
                }

                for t in tickets_data[:20]:  # Limit display to 20
                    t_id = t.get("id", "?")[:12]
                    t_title = t.get("title", "Untitled")[:50]
                    if len(t.get("title", "")) > 50:
                        t_title += "..."
                    t_status = t.get("status", "unknown")
                    t_priority = t.get("priority", "medium")
                    status_icon = status_icons.get(t_status.lower(), "⚪")
                    priority_icon = priority_icons.get(t_priority.lower(), "⚪")

                    content_parts.append(
                        f"- {priority_icon}{status_icon} **{t_id}**: {t_title}"
                    )

                if len(tickets_data) > 20:
                    content_parts.append(f"- *... and {len(tickets_data) - 20} more*")

            viewer.content_area.mount(
                Markdown("\n".join(content_parts), classes="ticket-list")
            )

        artifact_id = f"tickets-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="ticket_list",
                title=f"📋 {count} Ticket{'s' if count != 1 else ''}",
                data={
                    "tickets": tickets,
                    "count": count,
                    "filter_info": filter_info,
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_todos(
        self,
        todos: List[Dict[str, Any]],
        summary: Optional[Dict[str, int]] = None,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display a list of todos artifact.

        Args:
            todos: List of todo items (each with id, content, status, priority)
            summary: Optional summary dict with counts (total, pending, in_progress, completed)
            tool_call_id: Optional tool call ID for linking

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            todos_data = data["todos"]
            summary_data = data.get("summary")

            content_parts = ["## Todo List", ""]

            # Show summary if provided
            if summary_data:
                total = summary_data.get("total", len(todos_data))
                pending = summary_data.get("pending", 0)
                in_progress = summary_data.get("in_progress", 0)
                completed = summary_data.get("completed", 0)

                parts = []
                if pending > 0:
                    parts.append(f"{pending} pending")
                if in_progress > 0:
                    parts.append(f"{in_progress} in progress")
                if completed > 0:
                    parts.append(f"{completed} completed")

                if parts:
                    content_parts.append(
                        f"**Summary:** {', '.join(parts)} ({total} total)"
                    )
                else:
                    content_parts.append(f"**Total:** {total}")
                content_parts.append("")

            if not todos_data:
                content_parts.append("*No todos*")
            else:
                # Status and priority icons (text-safe, no variation selectors)
                status_icons = {
                    "pending": "O",
                    "in_progress": "*",
                    "completed": "X",
                }
                priority_icons = {
                    "high": "[!]",
                    "medium": "[-]",
                    "low": "[ ]",
                }

                for todo in todos_data:
                    todo_id = todo.get("id", "?")
                    content = todo.get("content", "Untitled")
                    status = todo.get("status", "pending")
                    priority = todo.get("priority", "medium")

                    status_icon = status_icons.get(status, "O")
                    priority_icon = priority_icons.get(priority, "[-]")

                    # Truncate long content
                    display_content = content
                    if len(display_content) > 60:
                        display_content = display_content[:60] + "..."

                    content_parts.append(
                        f"- {priority_icon}{status_icon} **{todo_id}**: {display_content}"
                    )

            viewer.content_area.mount(
                Markdown("\n".join(content_parts), classes="todo-list")
            )

        # Generate title from summary if available
        if summary:
            total = summary.get("total", len(todos))
            pending = summary.get("pending", 0)
            in_progress = summary.get("in_progress", 0)
            parts = []
            if pending > 0:
                parts.append(f"{pending} pending")
            if in_progress > 0:
                parts.append(f"{in_progress} in progress")
            if completed := summary.get("completed", 0):
                parts.append(f"{completed} completed")
            title = (
                f"Todos: {', '.join(parts)}"
                if parts
                else f"{total} Todo{'s' if total != 1 else ''}"
            )
        else:
            count = len(todos)
            title = f"{count} Todo{'s' if count != 1 else ''}"

        artifact_id = f"todos-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="todo_list",
                title=title,
                data={
                    "todos": todos,
                    "summary": summary,
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )

    def show_ticket_update(
        self,
        ticket_id: str,
        action: str,
        message: str,
        tool_call_id: Optional[str] = None,
    ) -> str:
        """Display a ticket update action artifact.

        Args:
            ticket_id: The ticket ID that was updated
            action: The action performed (e.g., "updated", "commented", "closed")
            message: Success message from the operation
            tool_call_id: Optional tool call ID for linking

        Returns:
            The artifact ID
        """

        def render(viewer, data):
            action_icons = {
                "created": "🎫",
                "updated": "📝",
                "commented": "💬",
                "assigned": "👤",
                "closed": "✅",
                "reopened": "🔓",
            }
            icon = action_icons.get(data["action"].lower(), "📝")

            content_parts = [f"## {icon} Ticket {data['action'].title()}", ""]
            content_parts.append(f"**Ticket:** `{data['ticket_id']}`")
            content_parts.append("")
            content_parts.append(data["message"])

            viewer.content_area.mount(
                Markdown("\n".join(content_parts), classes="ticket-update")
            )

        artifact_id = f"ticket-action-{uuid.uuid4().hex[:8]}"
        return self._add_artifact(
            ArtifactData(
                id=artifact_id,
                type="ticket_update",
                title=f"Ticket {action}",
                data={
                    "ticket_id": ticket_id,
                    "action": action,
                    "message": message,
                },
                render_func=render,
                tool_call_id=tool_call_id,
            )
        )
