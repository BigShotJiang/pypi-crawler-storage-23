"""Init wizard for typedef setup.

This module provides a full-screen TUI wizard for the `typedef init` command.
"""
from lineage.tui.wizards.base import BaseWizardApp, WizardScreen
from lineage.tui.wizards.init.steps import (
    DataBackendStep,
    DatabaseSelectionStep,
    DbtPathStep,
    DbtSubProjectStep,
    DuckDBConnectionStep,
    IntegrationsStep,
    LlmKeysStep,
    PreFlightCheckStep,
    ProfilesYmlStep,
    ProjectNameStep,
    SalesforceConnectionStep,
    SnowflakeConnectionStep,
    SummaryStep,
)

__all__ = [
    "create_init_wizard",
    "create_add_project_wizard",
    "InitWizardApp",
]


def create_init_wizard() -> WizardScreen:
    """Create the init wizard screen."""
    steps = [
        ProjectNameStep(),          # Step 1: Project name
        DbtPathStep(),              # Step 2: dbt project path or git URL
        DbtSubProjectStep(),        # Step 3: Select sub-project (if monorepo)
        DataBackendStep(),          # Step 4: Select Snowflake or DuckDB
        DuckDBConnectionStep(),     # Step 5: DuckDB config (skipped if Snowflake)
        SnowflakeConnectionStep(),  # Step 6: Snowflake credentials (skipped if DuckDB)
        DatabaseSelectionStep(),    # Step 7: Select databases (skipped if DuckDB)
        SalesforceConnectionStep(), # Step 8: Optional Salesforce integration
        LlmKeysStep(),              # Step 9: Optional LLM API keys
        IntegrationsStep(),         # Step 10: Optional integrations (Linear, Logfire)
        ProfilesYmlStep(),          # Step 11: Preview profiles.yml (no write yet)
        PreFlightCheckStep(),       # Step 12: Setup & validation
        SummaryStep(),              # Step 13: Final summary before completion
    ]

    return WizardScreen(
        steps=steps,
        title="typedef Setup Wizard",
    )


def create_add_project_wizard() -> WizardScreen:
    """Create the add project wizard screen.

    This is the same as the init wizard but for adding additional projects.
    Each project can have its own data backend configuration.
    """
    steps = [
        ProjectNameStep(),          # Step 1: Project name
        DbtPathStep(),              # Step 2: dbt project path or git URL
        DbtSubProjectStep(),        # Step 3: Select sub-project (if monorepo)
        DataBackendStep(),          # Step 4: Select Snowflake or DuckDB
        DuckDBConnectionStep(),     # Step 5: DuckDB config (skipped if Snowflake)
        SnowflakeConnectionStep(),  # Step 6: Snowflake credentials (skipped if DuckDB)
        DatabaseSelectionStep(),    # Step 7: Select databases (skipped if DuckDB)
        SalesforceConnectionStep(), # Step 8: Optional Salesforce integration
        LlmKeysStep(),              # Step 9: Optional LLM API keys
        IntegrationsStep(),         # Step 10: Optional integrations (Linear, Logfire)
        ProfilesYmlStep(),          # Step 11: Preview profiles.yml (no write yet)
        PreFlightCheckStep(),       # Step 12: Setup & validation
        SummaryStep(),              # Step 13: Final summary before completion
    ]

    return WizardScreen(
        steps=steps,
        title="Add New Project",
    )


class InitWizardApp(BaseWizardApp):
    """Full-screen init wizard application."""

    def __init__(self):
        """Initialize the init wizard app."""
        wizard_screen = create_init_wizard()
        super().__init__(wizard_screen)
