"""Data backend selection steps for the init wizard."""

from pathlib import Path
from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Input, Label, Select, Static

from lineage.tui.wizards.base import WizardStep
from lineage.tui.wizards.init.helpers import get_dbt_profile_name


class DataBackendStep(WizardStep):
    """Step: Select data backend (Snowflake or DuckDB)."""

    def __init__(self):
        """Initialize data backend selection step."""
        super().__init__(
            title="Data Backend",
            description="Select the data warehouse backend for this project.",
            step_id="data-backend",
        )
        self.backend_select: Select

    def get_content(self) -> ComposeResult:
        """Get step content."""
        yield Label("Backend:")
        self.backend_select = Select(
            options=[
                ("Snowflake", "snowflake"),
                ("DuckDB (local file)", "duckdb"),
            ],
            value="snowflake",
            id="backend-select",
            allow_blank=False,
        )
        yield self.backend_select
        yield Static(
            "Snowflake requires account credentials. DuckDB uses a local database file.",
            classes="wizard-hint",
        )

    async def validate(self) -> tuple[bool, str]:
        """Validate selection."""
        if not self.backend_select.value or self.backend_select.value == Select.BLANK:
            return False, "Please select a data backend"
        return True, ""

    def get_data(self) -> dict[str, Any]:
        """Get backend selection data."""
        return {"data_backend": str(self.backend_select.value)}


class DuckDBConnectionStep(WizardStep):
    """Step: DuckDB connection configuration."""

    def __init__(self):
        """Initialize DuckDB connection step."""
        super().__init__(
            title="DuckDB Configuration",
            description="Configure your DuckDB database connection.",
            step_id="duckdb-connection",
        )
        self.db_path_input: Input
        self.dbt_target_input: Input
        self.env_vars_input: Input

    def should_skip(self, wizard_data: dict[str, Any]) -> bool:
        """Skip when Snowflake is selected."""
        return wizard_data.get("data_backend") != "duckdb"

    def _find_duckdb_file(self) -> str:
        """Scan the dbt project directory for a .duckdb file."""
        if not self.screen or not hasattr(self.screen, "wizard_data"):
            return ""
        dbt_path = self.screen.wizard_data.get(
            "dbt_project_root", self.screen.wizard_data.get("dbt_path", "")
        )
        if not dbt_path:
            return ""
        dbt_dir = Path(dbt_path).expanduser().resolve()
        if not dbt_dir.is_dir():
            return ""
        matches = sorted(dbt_dir.glob("*.duckdb"))
        if matches:
            return str(matches[0])
        return ""

    def get_content(self) -> ComposeResult:
        """Get step content."""
        detected = self._find_duckdb_file()
        yield Label("DuckDB database file path:")
        self.db_path_input = Input(
            placeholder="/path/to/database.duckdb",
            value=detected,
            id="duckdb-path-input",
        )
        yield self.db_path_input

        with Horizontal(classes="form-row"):
            with Vertical(classes="form-field"):
                yield Label("dbt target name:")
                self.dbt_target_input = Input(
                    placeholder="duckdb",
                    value="duckdb",
                    id="duckdb-target-input",
                )
                yield self.dbt_target_input

        yield Label("Project env vars (key=val, key=val, ...):")
        self.env_vars_input = Input(
            placeholder="MATTERMOST_RAW_DB=mattermost_analytics, MATTERMOST_ANALYTICS_DB=mattermost_analytics",
            id="duckdb-env-vars-input",
        )
        yield self.env_vars_input
        yield Static(
            "Environment variables required by dbt Jinja templates (e.g. env_var() calls). "
            "These will be set for all dbt and agent operations.",
            classes="wizard-hint",
        )

    async def validate(self) -> tuple[bool, str]:
        """Validate DuckDB configuration."""
        db_path = self.db_path_input.value.strip()
        if not db_path:
            return False, "DuckDB database path is required"

        resolved = Path(db_path).expanduser().resolve()
        if not resolved.exists():
            return False, f"Database file not found: {resolved}"
        if not resolved.is_file():
            return False, f"Path is not a file: {resolved}"

        return True, ""

    def get_data(self) -> dict[str, Any]:
        """Get DuckDB connection data."""
        # Parse env vars from comma-separated key=value format
        env_vars: dict[str, str] = {}
        env_vars_str = self.env_vars_input.value.strip()
        if env_vars_str:
            for pair in env_vars_str.split(","):
                pair = pair.strip()
                if "=" in pair:
                    key, value = pair.split("=", 1)
                    key = key.strip()
                    value = value.strip()
                    if key:
                        env_vars[key] = value

        db_path = self.db_path_input.value.strip()
        resolved = str(Path(db_path).expanduser().resolve())

        # Get profile name from dbt_project.yml (same as Snowflake step does)
        profile_name = "dev"
        if self.screen and hasattr(self.screen, "wizard_data"):
            dbt_path = Path(
                self.screen.wizard_data.get(
                    "dbt_project_root", self.screen.wizard_data.get("dbt_path", "")
                )
            )
            profile_name = get_dbt_profile_name(dbt_path) or "dev"

        return {
            "duckdb_db_path": resolved,
            "dbt_target": self.dbt_target_input.value.strip() or "duckdb",
            "profile_name": profile_name,
            "project_env_vars": env_vars,
        }
