"""Base wizard framework for typedef TUI.

This module provides base classes for building multi-step wizards with
consistent styling matching the Data Concierge TUI.
"""

from enum import Enum, auto
from pathlib import Path
from time import monotonic
from typing import Any, Callable, Optional

from rich.spinner import Spinner
from rich.text import Text
from textual import events
from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.css.query import NoMatches
from textual.screen import Screen
from textual.widgets import Button, Input, Label, Select, Static, TextArea

# Path to shared CSS file
STYLES_PATH = Path(__file__).parent / "styles.tcss"


class StepState(Enum):
    """State machine for wizard steps with async validation."""

    IDLE = auto()  # Ready for user input
    VALIDATING = auto()  # Running async validation
    VALID = auto()  # Validation passed
    INVALID = auto()  # Validation failed
    WORKING = auto()  # Background work in progress
    COMPLETED = auto()  # Work finished successfully
    FAILED = auto()  # Work failed


class AsyncStepMixin:
    """Mixin for steps that perform async validation or background work.

    This mixin provides a state machine to properly handle async operations
    in wizard steps, ensuring thread-safe UI updates and preventing
    double-submission during validation.

    Usage:
        class MyStep(WizardStep, AsyncStepMixin):
            def __init__(self, ...):
                super().__init__(...)
                self.init_async_state()  # Initialize mixin state

            @work(thread=True)
            def _do_validation(self):
                self.set_state(StepState.VALIDATING)
                try:
                    # ... validation logic ...
                    self.set_state(StepState.VALID)
                except Exception as e:
                    self.set_state(StepState.INVALID, str(e))

            async def validate(self):
                if self.state == StepState.IDLE:
                    self._do_validation()
                    return False, ""  # Signal "in progress"
                return self.check_async_state()
    """

    state: StepState
    _error_message: str

    def init_async_state(self) -> None:
        """Initialize async state. Call this in __init__ of subclasses."""
        self.state = StepState.IDLE
        self._error_message = ""

    def set_state(self, new_state: StepState, error: str = "") -> None:
        """Thread-safe state transition with optional error message."""
        self.state = new_state
        self._error_message = error
        # Update UI from worker thread if app is available
        if hasattr(self, "app") and self.app:
            self.app.call_from_thread(self._on_state_changed)

    def _on_state_changed(self) -> None:
        """Called on main thread when state changes. Override for custom UI updates."""
        pass

    def reset_state(self) -> None:
        """Reset to IDLE state. Useful when going back in wizard."""
        self.state = StepState.IDLE
        self._error_message = ""

    def check_async_state(self) -> tuple[bool, str]:
        """Check current state and return validation result.

        Returns:
            tuple: (is_valid, error_message)
                - (False, "") means validation is still in progress
                - (False, "error") means validation failed
                - (True, "") means validation passed
        """
        if self.state == StepState.VALIDATING:
            return False, ""  # Still working
        if self.state == StepState.WORKING:
            return False, ""  # Still working
        if self.state == StepState.INVALID:
            return False, self._error_message
        if self.state == StepState.FAILED:
            return False, self._error_message
        if self.state in (StepState.VALID, StepState.COMPLETED):
            return True, ""
        # IDLE state - shouldn't reach here if used correctly
        return True, ""


class StepStatus(Static):
    """Wizard status line with muted text and state-colored icon."""

    ICON_MAP: dict[str, tuple[str, str]] = {
        "⚠": ("yellow", "○"),
        "✅": ("green", "●"),
        "❌": ("red", "●"),
    }

    def update(self, content: object = "") -> None:  # type: ignore[override]
        """Render status with a colored icon and muted body text."""
        text = str(content).strip()
        if not text:
            self.auto_refresh = None
            self.display = False
            super().update("")
            return

        self.display = True
        icon = text[:1]
        body = text[1:].lstrip() if icon in {"⏳", *self.ICON_MAP.keys()} else text

        if icon == "⏳":
            self.auto_refresh = 1 / 12
            super().update(Spinner("circleHalves", text=body, style="yellow"))
            self.refresh(layout=False, repaint=True)
            return

        self.auto_refresh = None

        renderable = Text()
        if icon in self.ICON_MAP:
            color, glyph = self.ICON_MAP[icon]
            renderable.append(f"{glyph} ", style=color)
        renderable.append(body)
        super().update(renderable)


class WizardStep(Container):
    """Base class for wizard steps with consistent styling."""

    def __init__(self, title: str, description: str, step_id: str):
        """Initialize a wizard step with identifiers and labels."""
        super().__init__(id=f"step-{step_id}", classes="wizard-step")
        self.title = title
        self.description = description
        self.step_id = step_id
        self.error_message = ""
        self._restoring_state = False

    @property
    def is_restoring_state(self) -> bool:
        """Whether this step is currently replaying persisted widget state."""
        return self._restoring_state

    def compose(self) -> ComposeResult:
        """Compose the wizard step with title, description, and content."""
        yield Label(self.title, classes="wizard-title")
        yield Label(self.description, classes="wizard-description")

        # Error message (hidden by default)
        yield Static("", id=f"error-{self.step_id}", classes="wizard-error")

        # Status line appears near the top so async progress is easy to see
        yield StepStatus("", id="step-status", classes="step-status")

        # Step-specific content (scrollable for long forms)
        with VerticalScroll(classes="wizard-content"):
            yield from self.get_content()

    def get_content(self) -> ComposeResult:
        """Override to provide step-specific content."""
        raise NotImplementedError("Subclasses must implement get_content()")

    async def validate(self) -> tuple[bool, str]:
        """Validate step data.

        Returns:
            tuple: (is_valid, error_message)
        """
        return True, ""

    def should_skip(self, wizard_data: dict[str, Any]) -> bool:
        """Return True to skip this step based on current wizard state.

        Override in subclasses to conditionally skip steps based on
        earlier wizard choices (e.g., skip Snowflake steps when DuckDB is selected).

        Args:
            wizard_data: Accumulated wizard data from previous steps

        Returns:
            True if this step should be skipped
        """
        return False

    def get_data(self) -> dict[str, Any]:
        """Extract data from the step.

        Returns:
            dict: Step data to be included in final wizard result
        """
        return {}

    def show_error(self, message: str):
        """Display an error message on the step."""
        error_widget = self.query_one(f"#error-{self.step_id}", Static)
        error_widget.update(f"❌ {message}")
        error_widget.display = True

    def clear_error(self):
        """Clear any error message."""
        try:
            error_widget = self.query_one(f"#error-{self.step_id}", Static)
            error_widget.update("")
            error_widget.display = False
        except NoMatches:
            # Error widget might not exist in all steps
            pass

    def snapshot_state(self) -> dict[str, Any]:
        """Capture interactive widget state for back/forward navigation."""
        state: dict[str, Any] = {}

        for widget in self.query(Input):
            if not widget.id:
                continue
            state[widget.id] = {
                "type": "input",
                "value": widget.value,
                "display": bool(widget.display),
            }

        for widget in self.query(TextArea):
            if not widget.id:
                continue
            state[widget.id] = {
                "type": "textarea",
                "value": widget.text,
                "display": bool(widget.display),
            }

        for widget in self.query(Select):
            if not widget.id:
                continue
            value = widget.value
            state[widget.id] = {
                "type": "select",
                "value": None if value == Select.BLANK else value,
                "display": bool(widget.display),
                "disabled": bool(widget.disabled),
            }

        return state

    def restore_state(self, state: dict[str, Any]) -> None:
        """Restore interactive widget state captured by snapshot_state."""
        self._restoring_state = True
        try:
            for widget_id, payload in state.items():
                if not isinstance(payload, dict):
                    continue
                try:
                    widget = self.query_one(f"#{widget_id}")
                except NoMatches:
                    continue

                if "display" in payload and hasattr(widget, "display"):
                    widget.display = bool(payload.get("display", True))

                widget_type = payload.get("type")
                if widget_type == "input" and isinstance(widget, Input):
                    widget.value = str(payload.get("value", ""))
                elif widget_type == "textarea" and isinstance(widget, TextArea):
                    widget.text = str(payload.get("value", ""))
                elif widget_type == "select" and isinstance(widget, Select):
                    if "disabled" in payload:
                        widget.disabled = bool(payload.get("disabled", False))
                    value = payload.get("value")
                    if value is None:
                        continue
                    try:
                        widget.value = value
                    except Exception:  # nosec B110
                        pass
        finally:
            self._restoring_state = False


class WizardScreen(Screen):
    """Base wizard screen with multi-step navigation."""

    CSS_PATH = STYLES_PATH
    BINDINGS = [
        ("ctrl+enter", "wizard_next", "Next"),
        ("ctrl+b", "wizard_back", "Back"),
        ("ctrl+c", "confirm_exit", "Exit"),
    ]

    EXIT_CONFIRM_WINDOW_SECONDS = 2.0
    AUTO_ADVANCE_DELAY_SECONDS = 0.8

    def __init__(
        self,
        steps: list[WizardStep],
        title: str = "Setup Wizard",
        on_complete: Optional[Callable[[dict[str, Any]], None]] = None,
    ):
        """Initialize the wizard screen with steps and optional callback."""
        super().__init__()
        self.steps = steps
        self.wizard_title = title
        self.current_step_idx = 0
        self.on_complete = on_complete
        self.wizard_data: dict[str, Any] = {}
        self._step_state: dict[str, dict[str, Any]] = {}
        self._last_exit_attempt_at = 0.0
        self._auto_advance_token = 0

    def schedule_auto_advance(
        self,
        step_id: str,
        delay_seconds: float = AUTO_ADVANCE_DELAY_SECONDS,
    ) -> None:
        """Schedule an auto-advance that only fires for the active step."""
        self._auto_advance_token += 1
        token = self._auto_advance_token
        self.set_timer(
            delay_seconds,
            lambda: self._try_auto_advance(step_id, token),
        )

    def _try_auto_advance(self, step_id: str, token: int) -> None:
        """Advance only if timer token and active step still match."""
        if token != self._auto_advance_token:
            return
        if self.current_step_idx < 0 or self.current_step_idx >= len(self.steps):
            return

        current_step = self.steps[self.current_step_idx]
        if current_step.step_id != step_id:
            return

        try:
            next_btn = self.query_one("#next-btn", Button)
        except NoMatches:
            return
        if next_btn.disabled:
            return

        next_btn.press()

    def compose(self) -> ComposeResult:
        """Compose the wizard screen."""
        with Vertical(classes="wizard-container wizard-shell"):
            yield Label(self.wizard_title, classes="wizard-shell-title")

            # Progress indicator
            yield Static(
                self._get_progress_text(),
                id="wizard-progress",
                classes="wizard-progress",
            )

            # Current step (will be swapped as user navigates)
            yield self.steps[self.current_step_idx]

        # Navigation hints + buttons
        with Vertical(classes="wizard-nav-wrap"):
            with Vertical(classes="wizard-nav-cluster"):
                with Horizontal(classes="wizard-nav"):
                    yield Button("← Back", id="back-btn", classes="wizard-button")
                    yield Button(
                        "Next →"
                        if self.current_step_idx < len(self.steps) - 1
                        else "Finish",
                        id="next-btn",
                        classes="wizard-button",
                        variant="primary",
                    )
                    yield Button(
                        "Cancel",
                        id="cancel-btn",
                        classes="wizard-button",
                        variant="error",
                    )
                with Vertical(classes="wizard-nav-hints-table"):
                    with Horizontal(classes="wizard-hint-row"):
                        yield Static("enter", classes="wizard-hint-key")
                        yield Static("next field", classes="wizard-hint-desc")
                    with Horizontal(classes="wizard-hint-row"):
                        yield Static("backspace", classes="wizard-hint-key")
                        yield Static("previous field", classes="wizard-hint-desc")
                    with Horizontal(classes="wizard-hint-row"):
                        yield Static("ctrl+enter", classes="wizard-hint-key")
                        yield Static("next step", classes="wizard-hint-desc")
                    with Horizontal(classes="wizard-hint-row"):
                        yield Static("ctrl+b", classes="wizard-hint-key")
                        yield Static("back", classes="wizard-hint-desc")
                    with Horizontal(classes="wizard-hint-row"):
                        yield Static("ctrl+c", classes="wizard-hint-key")
                        yield Static("exit", classes="wizard-hint-desc")

    def _get_progress_text(self) -> str:
        """Get progress indicator text."""
        return f"Step {self.current_step_idx + 1} of {len(self.steps)}"

    def on_mount(self) -> None:
        """Handle screen mount."""
        self._update_navigation_state()
        self._focus_first_step_widget()

    async def on_key(self, event: events.Key) -> None:
        """Handle Enter for keyboard-first focus and button interaction."""
        if event.key == "escape":
            event.prevent_default()
            event.stop()
            return

        if event.key == "backspace":
            focused = self.app.focused
            if isinstance(focused, (Input, TextArea)):
                return
            self._focus_previous_interactive()
            event.stop()
            return

        if event.key != "enter":
            return

        focused = self.app.focused
        if isinstance(focused, Button):
            if focused.id == "back-btn":
                await self._go_back()
                event.stop()
            elif focused.id == "cancel-btn":
                self.dismiss(None)
                event.stop()
            elif focused.id == "next-btn":
                await self._go_next()
                event.stop()
            return

        if isinstance(focused, (Input, TextArea)):
            return

        current_step = self.steps[self.current_step_idx]
        if any(select.has_focus_within for select in current_step.query(Select)):
            return

        self._focus_next_interactive()
        event.stop()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Move focus to the next interactive control when Enter is pressed in an Input."""
        self._focus_next_interactive()
        event.stop()

    def on_select_changed(self, event: Select.Changed) -> None:
        """Move focus forward after a user commits a Select value with Enter."""
        if not event.select.has_focus_within:
            return
        self._focus_next_interactive()

    async def action_wizard_next(self) -> None:
        """Advance wizard from anywhere."""
        await self._go_next()

    async def action_wizard_back(self) -> None:
        """Go to previous wizard step from anywhere."""
        await self._go_back()

    def action_wizard_cancel(self) -> None:
        """Cancel wizard from anywhere."""
        self.dismiss(None)

    def action_confirm_exit(self) -> None:
        """Require two ctrl+c presses before exiting the wizard."""
        now = monotonic()
        if now - self._last_exit_attempt_at <= self.EXIT_CONFIRM_WINDOW_SECONDS:
            self.dismiss(None)
            return

        self._last_exit_attempt_at = now
        self.app.notify("Press Ctrl+C again to exit", timeout=2)

    def _update_navigation_state(self):
        """Update button states based on current step."""
        back_btn = self.query_one("#back-btn", Button)
        next_btn = self.query_one("#next-btn", Button)

        # Disable back button on first step
        back_btn.disabled = self.current_step_idx == 0

        # Update next button label
        if self.current_step_idx == len(self.steps) - 1:
            next_btn.label = "Finish"
        else:
            next_btn.label = "Next →"

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        if event.button.id == "cancel-btn":
            self.dismiss(None)
        elif event.button.id == "back-btn":
            await self._go_back()
        elif event.button.id == "next-btn":
            await self._go_next()

    async def _go_next(self):
        """Move to next step or finish wizard."""
        self._auto_advance_token += 1
        current_step = self.steps[self.current_step_idx]

        # Validate current step
        is_valid, error_msg = await current_step.validate()
        if not is_valid:
            # Only show error if there's a message (empty means "in progress")
            if error_msg:
                current_step.show_error(error_msg)
            return

        # Clear any previous errors
        current_step.clear_error()

        # Collect data from current step
        step_data = current_step.get_data()
        self.wizard_data.update(step_data)

        # Check if this is the last step
        if self.current_step_idx == len(self.steps) - 1:
            # Wizard complete
            if self.on_complete:
                self.on_complete(self.wizard_data)
            self.dismiss(self.wizard_data)
            return

        # Move to next non-skipped step
        self.current_step_idx += 1
        while (
            self.current_step_idx < len(self.steps)
            and self.steps[self.current_step_idx].should_skip(self.wizard_data)
        ):
            self.current_step_idx += 1

        if self.current_step_idx >= len(self.steps):
            # All remaining steps skipped — finish
            if self.on_complete:
                self.on_complete(self.wizard_data)
            self.dismiss(self.wizard_data)
            return

        await self._switch_step()

    async def _go_back(self):
        """Move to previous non-skipped step."""
        self._auto_advance_token += 1
        if self.current_step_idx > 0:
            self.current_step_idx -= 1
            while (
                self.current_step_idx > 0
                and self.steps[self.current_step_idx].should_skip(self.wizard_data)
            ):
                self.current_step_idx -= 1
            await self._switch_step()

    async def _switch_step(self):
        """Switch to the current step."""
        self._capture_attached_step_states()

        # Update progress text
        progress = self.query_one("#wizard-progress", Static)
        progress.update(self._get_progress_text())

        # Remove old step and mount new one
        container = self.query_one(".wizard-container", Vertical)

        # Remove all steps except progress
        for step in self.steps:
            if step.is_attached:
                await step.remove()

        # Mount current step
        current_step = self.steps[self.current_step_idx]
        await container.mount(current_step)
        self._restore_step_state(current_step)

        # Update navigation
        self._update_navigation_state()
        self._focus_first_step_widget()

    def _capture_attached_step_states(self) -> None:
        """Capture state for steps currently mounted on screen."""
        for step in self.steps:
            if not step.is_attached:
                continue
            self._step_state[step.step_id] = step.snapshot_state()

    def _restore_step_state(self, step: WizardStep) -> None:
        """Restore previously captured state for a mounted step."""
        state = self._step_state.get(step.step_id)
        if not state:
            return
        step.restore_state(state)

    def _focus_first_step_widget(self) -> None:
        """Focus the top-most interactive widget within the current step."""
        for widget in self._interactive_widgets():
            if not getattr(widget, "can_focus", False):
                continue
            if not getattr(widget, "display", True):
                continue
            if hasattr(widget, "disabled") and widget.disabled:
                continue
            widget.focus()
            return

    def _focus_next_interactive(self) -> None:
        """Focus the next interactive control in the current wizard screen."""
        widgets = self._interactive_widgets()
        if not widgets:
            return

        focused = self.app.focused
        if focused in widgets:
            idx = widgets.index(focused)
            if idx + 1 < len(widgets):
                widgets[idx + 1].focus()
            return

        widgets[0].focus()

    def _focus_previous_interactive(self) -> None:
        """Focus the previous interactive control in the current wizard screen."""
        widgets = self._interactive_widgets()
        if not widgets:
            return

        focused = self.app.focused
        if focused in widgets:
            idx = widgets.index(focused)
            if idx - 1 >= 0:
                widgets[idx - 1].focus()
            return

        widgets[-1].focus()

    def _interactive_widgets(self) -> list[Any]:
        """Return focusable widgets in form order, then primary nav order."""
        step = self.steps[self.current_step_idx]
        in_step = list(step.query(".wizard-content *")) or list(step.query("*"))

        widgets: list[Any] = []
        for widget in in_step:
            if not getattr(widget, "can_focus", False):
                continue
            if not getattr(widget, "display", True):
                continue
            if hasattr(widget, "disabled") and widget.disabled:
                continue
            widgets.append(widget)

        for button_id in ("#next-btn", "#back-btn", "#cancel-btn"):
            try:
                button = self.query_one(button_id, Button)
            except NoMatches:
                continue
            if button.disabled:
                continue
            widgets.append(button)

        return widgets


class BaseWizardApp(App):
    """Base application for running wizards."""

    def __init__(self, wizard_screen: WizardScreen):
        """Wrap a wizard screen to run as a Textual App."""
        super().__init__()
        self.wizard_screen = wizard_screen
        self.result: Optional[dict[str, Any]] = None

    def on_mount(self) -> None:
        """Mount the wizard screen."""

        def handle_result(data: Optional[dict[str, Any]]):
            self.result = data
            # Pass data through exit so App.run() returns the wizard result
            self.exit(data)

        self.wizard_screen.on_complete = handle_result
        self.push_screen(self.wizard_screen, callback=handle_result)
