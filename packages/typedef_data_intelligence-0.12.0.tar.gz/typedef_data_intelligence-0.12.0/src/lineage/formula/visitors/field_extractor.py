"""Extract field references from a formula AST."""
from __future__ import annotations

from lineage.formula.ast import (
    BinaryOp,
    FieldRef,
    FormulaNode,
    FunctionCall,
    UnaryOp,
)

# Built-in identifiers that are NOT field references (stored lower-cased).
_BUILTINS_LOWER = frozenset({
    "rowcount",
})


def extract_field_refs(node: FormulaNode) -> list[FieldRef]:
    """Walk AST and collect all FieldRef nodes, excluding builtins."""
    refs: list[FieldRef] = []
    _walk(node, refs)
    return refs


def _walk(node: FormulaNode, refs: list[FieldRef]) -> None:
    if isinstance(node, FieldRef):
        if node.field_name.lower() not in _BUILTINS_LOWER:
            refs.append(node)
    elif isinstance(node, FunctionCall):
        for arg in node.arguments:
            _walk(arg, refs)
    elif isinstance(node, BinaryOp):
        _walk(node.left, refs)
        _walk(node.right, refs)
    elif isinstance(node, UnaryOp):
        _walk(node.operand, refs)
    # Literal: no field refs
