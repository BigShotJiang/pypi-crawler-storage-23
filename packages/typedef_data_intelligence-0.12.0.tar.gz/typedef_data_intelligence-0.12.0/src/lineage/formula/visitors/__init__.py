"""AST visitor implementations for formula analysis."""
