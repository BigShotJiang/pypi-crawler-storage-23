"""AST node definitions for Salesforce formula expressions."""
from __future__ import annotations

from typing import Union

from pydantic import BaseModel


class FormulaNode(BaseModel):
    """Base for all formula AST nodes."""

    pass


class FieldRef(FormulaNode):
    """Field reference: AMOUNT, Account.Name, AMOUNT:SUM."""

    field_name: str
    object_path: list[str] | None = None
    aggregation: str | None = None
    raw: str


class Literal(FormulaNode):
    """Number, string, boolean, or null literal."""

    value: str | float | int | bool | None
    literal_type: str  # "number", "string", "boolean", "null"


class FunctionCall(FormulaNode):
    """Function invocation: IF(...), DATEVALUE(...), TODAY()."""

    name: str
    arguments: list[FormulaNode]


class BinaryOp(FormulaNode):
    """Binary operation: left op right."""

    operator: str
    left: FormulaNode
    right: FormulaNode


class UnaryOp(FormulaNode):
    """Unary operation: -x, NOT x, !x."""

    operator: str
    operand: FormulaNode


Expression = Union[FieldRef, Literal, FunctionCall, BinaryOp, UnaryOp]
