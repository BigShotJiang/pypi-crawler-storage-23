"""Salesforce formula parser: text to typed AST via ANTLR4."""
from __future__ import annotations

from antlr4 import CommonTokenStream, InputStream
from antlr4.error.ErrorListener import ErrorListener

from lineage.formula.ast import (
    BinaryOp,
    FieldRef,
    FormulaNode,
    FunctionCall,
    Literal,
    UnaryOp,
)
from lineage.formula.grammar.gen.SalesforceFormulaLexer import SalesforceFormulaLexer
from lineage.formula.grammar.gen.SalesforceFormulaParser import SalesforceFormulaParser
from lineage.formula.grammar.gen.SalesforceFormulaVisitor import (
    SalesforceFormulaVisitor,
)


class FormulaParseError(Exception):
    """Raised when formula text cannot be parsed."""

    pass


class _FormulaErrorListener(ErrorListener):
    def __init__(self) -> None:
        self.errors: list[str] = []

    def syntaxError(
        self, recognizer, offending_symbol, line, column, msg, e
    ) -> None:
        self.errors.append(f"line {line}:{column} {msg}")


def _parse_ident_to_field_ref(raw: str) -> FieldRef:
    """Split a single IDENT token into field name, object path, and aggregation.

    The Salesforce lexer treats `AMOUNT:SUM`, `Account.Name`, and plain `AMOUNT`
    as single IDENT tokens (`:` and `.` are valid IDENT_CHAR).

    Examples:
        AMOUNT           -> FieldRef(field_name="AMOUNT")
        AMOUNT:SUM       -> FieldRef(field_name="AMOUNT", aggregation="SUM")
        Account.Name     -> FieldRef(field_name="Name", object_path=["Account"])
        Contact.Acc.Name -> FieldRef(field_name="Name", object_path=["Contact", "Acc"])
    """
    field_name = raw
    object_path: list[str] | None = None
    aggregation: str | None = None

    if ":" in raw:
        base, aggregation = raw.split(":", 1)
        if "." in base:
            parts = base.split(".")
            object_path = parts[:-1]
            field_name = parts[-1]
        else:
            field_name = base
    elif "." in raw:
        parts = raw.split(".")
        object_path = parts[:-1]
        field_name = parts[-1]

    return FieldRef(
        field_name=field_name,
        object_path=object_path,
        aggregation=aggregation,
        raw=raw,
    )


class ASTBuilder(SalesforceFormulaVisitor):
    """Convert ANTLR parse tree into our typed AST."""

    # -- delegation rules (single child) --

    def visitFormula(self, ctx: SalesforceFormulaParser.FormulaContext) -> FormulaNode:  # noqa: D102
        return self.visit(ctx.expression())

    def visitExpression(  # noqa: D102
        self, ctx: SalesforceFormulaParser.ExpressionContext
    ) -> FormulaNode:
        return self.visit(ctx.logicalOrExpression())

    # -- binary operator chains: child (OP child)* --

    def _visit_binary_chain(self, ctx) -> FormulaNode:
        """Handle left-associative binary operator chains."""
        children = list(ctx.getChildren())
        result = self.visit(children[0])
        i = 1
        while i < len(children):
            op = children[i].getText()
            right = self.visit(children[i + 1])
            result = BinaryOp(operator=op, left=result, right=right)
            i += 2
        return result

    def visitLogicalOrExpression(self, ctx) -> FormulaNode:  # noqa: D102
        return self._visit_binary_chain(ctx)

    def visitLogicalAndExpression(self, ctx) -> FormulaNode:  # noqa: D102
        return self._visit_binary_chain(ctx)

    def visitEqualityExpression(self, ctx) -> FormulaNode:  # noqa: D102
        return self._visit_binary_chain(ctx)

    def visitRelationalExpression(self, ctx) -> FormulaNode:  # noqa: D102
        return self._visit_binary_chain(ctx)

    def visitAdditiveExpression(self, ctx) -> FormulaNode:  # noqa: D102
        return self._visit_binary_chain(ctx)

    def visitMultiplicativeExpression(self, ctx) -> FormulaNode:  # noqa: D102
        return self._visit_binary_chain(ctx)

    def visitExponentExpression(self, ctx) -> FormulaNode:  # noqa: D102
        return self._visit_binary_chain(ctx)

    # -- unary expressions (labeled alternatives) --

    def visitUnaryExpression_primary(self, ctx) -> FormulaNode:  # noqa: D102
        return self.visit(ctx.primaryExpression())

    def visitUnaryExpression_plus(self, ctx) -> FormulaNode:  # noqa: D102
        return UnaryOp(operator="+", operand=self.visit(ctx.unaryExpression()))

    def visitUnaryExpression_minus(self, ctx) -> FormulaNode:  # noqa: D102
        return UnaryOp(operator="-", operand=self.visit(ctx.unaryExpression()))

    def visitUnaryExpression_not(self, ctx) -> FormulaNode:  # noqa: D102
        return UnaryOp(operator="NOT", operand=self.visit(ctx.unaryExpression()))

    def visitUnaryExpression_bang(self, ctx) -> FormulaNode:  # noqa: D102
        return UnaryOp(operator="!", operand=self.visit(ctx.unaryExpression()))

    # -- primary expression --

    def visitPrimaryExpression(  # noqa: D102
        self, ctx: SalesforceFormulaParser.PrimaryExpressionContext
    ) -> FormulaNode:
        if ctx.fieldReferenceLiteral():
            return self.visit(ctx.fieldReferenceLiteral())
        if ctx.constant():
            return self.visit(ctx.constant())
        if ctx.TRUE():
            return Literal(value=True, literal_type="boolean")
        if ctx.FALSE():
            return Literal(value=False, literal_type="boolean")
        if ctx.NULL():
            return Literal(value=None, literal_type="null")
        if ctx.logicalOrExpression():
            return self.visit(ctx.logicalOrExpression())
        if ctx.functionCall():
            return self.visit(ctx.functionCall())
        raise FormulaParseError("Unexpected primary expression")  # pragma: no cover

    # -- atoms --

    def visitFieldReferenceLiteral(  # noqa: D102
        self, ctx: SalesforceFormulaParser.FieldReferenceLiteralContext
    ) -> FieldRef:
        raw = ctx.IDENT().getText()
        return _parse_ident_to_field_ref(raw)

    def visitConstant(  # noqa: D102
        self, ctx: SalesforceFormulaParser.ConstantContext
    ) -> Literal:
        if ctx.NUMBER():
            text = ctx.NUMBER().getText()
            value: float | int = float(text) if "." in text else int(text)
            return Literal(value=value, literal_type="number")
        # STRING_LITERAL — strip surrounding quotes
        text = ctx.STRING_LITERAL().getText()
        return Literal(value=text[1:-1], literal_type="string")

    def visitFunctionCall(  # noqa: D102
        self, ctx: SalesforceFormulaParser.FunctionCallContext
    ) -> FunctionCall:
        name = ctx.IDENT().getText()
        args = [self.visit(e) for e in ctx.expression()]
        return FunctionCall(name=name, arguments=args)


def parse(expression: str) -> FormulaNode:
    """Parse a Salesforce formula expression into a typed AST.

    Raises FormulaParseError if the expression cannot be parsed.
    """
    input_stream = InputStream(expression)
    lexer = SalesforceFormulaLexer(input_stream)
    lexer.removeErrorListeners()
    error_listener = _FormulaErrorListener()
    lexer.addErrorListener(error_listener)

    tokens = CommonTokenStream(lexer)
    parser = SalesforceFormulaParser(tokens)
    parser.removeErrorListeners()
    parser.addErrorListener(error_listener)

    tree = parser.formula()

    if error_listener.errors:
        raise FormulaParseError(
            f"Failed to parse formula: {'; '.join(error_listener.errors)}"
        )

    builder = ASTBuilder()
    return builder.visit(tree)
