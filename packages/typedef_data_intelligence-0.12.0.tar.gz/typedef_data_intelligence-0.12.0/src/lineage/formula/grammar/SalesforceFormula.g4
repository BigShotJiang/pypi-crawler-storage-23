// Salesforce Formula Grammar — vendored from github.com/nicholasgasior/formula-engine
// Adapted for Python3 target: removed Java @members, subscripts, maps, semantic predicates.
// Regenerate: antlr4 -Dlanguage=Python3 -visitor -no-listener -o gen SalesforceFormula.g4

grammar SalesforceFormula;

import LexerRules;

formula
    : expression  EOF
    ;

fieldReferenceLiteral
    : IDENT
    ;

constant
    : NUMBER
    | STRING_LITERAL
    ;

expression
    : logicalOrExpression
    ;

//comma version of OR falls under functionCall
logicalOrExpression
    : logicalAndExpression ( INFIX_OR  logicalAndExpression )*
    ;

//comma version of AND falls under functionCall
logicalAndExpression
    : equalityExpression ( INFIX_AND equalityExpression )*
    ;

equalityExpression
    : relationalExpression ( ( NOT_EQUAL | EQUAL |  NOT_EQUAL2 | EQUAL2 ) relationalExpression )*
    ;

relationalExpression
    : additiveExpression ( ( LT | GT | LE | GE ) additiveExpression )*
    ;

additiveExpression
    : multiplicativeExpression ( (PLUS | MINUS | CONCAT ) multiplicativeExpression )*
    ;

multiplicativeExpression
    : exponentExpression ( (STAR | DIV ) exponentExpression )*
    ;

exponentExpression
    : unaryExpression ( EXPONENT unaryExpression )*
    ;

unaryExpression
    : primaryExpression       #unaryExpression_primary
    | PLUS unaryExpression    #unaryExpression_plus
    | MINUS unaryExpression   #unaryExpression_minus
    | NOT unaryExpression     #unaryExpression_not
    | BANG unaryExpression    #unaryExpression_bang
    ;

// the basic element of an expression
primaryExpression
    : fieldReferenceLiteral
    | constant
    | TRUE
    | FALSE
    | NULL
    | LPAREN logicalOrExpression RPAREN
    | functionCall
    ;

//"OR(...)" and "AND(...)" fall under functionCall
functionCall
    : IDENT LPAREN (expression ( COMMA expression )* )? RPAREN
    ;
