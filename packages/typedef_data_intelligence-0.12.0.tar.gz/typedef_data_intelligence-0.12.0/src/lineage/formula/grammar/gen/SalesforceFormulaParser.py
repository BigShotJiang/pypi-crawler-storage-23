# Generated from SalesforceFormula.g4 by ANTLR 4.13.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,36,131,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        1,0,1,0,1,0,1,1,1,1,1,2,1,2,1,3,1,3,1,4,1,4,1,4,5,4,41,8,4,10,4,
        12,4,44,9,4,1,5,1,5,1,5,5,5,49,8,5,10,5,12,5,52,9,5,1,6,1,6,1,6,
        5,6,57,8,6,10,6,12,6,60,9,6,1,7,1,7,1,7,5,7,65,8,7,10,7,12,7,68,
        9,7,1,8,1,8,1,8,5,8,73,8,8,10,8,12,8,76,9,8,1,9,1,9,1,9,5,9,81,8,
        9,10,9,12,9,84,9,9,1,10,1,10,1,10,5,10,89,8,10,10,10,12,10,92,9,
        10,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,1,11,3,11,103,8,11,1,
        12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,1,12,3,12,115,8,12,1,
        13,1,13,1,13,1,13,1,13,5,13,122,8,13,10,13,12,13,125,9,13,3,13,127,
        8,13,1,13,1,13,1,13,0,0,14,0,2,4,6,8,10,12,14,16,18,20,22,24,26,
        0,5,2,0,33,33,36,36,1,0,24,27,1,0,13,16,2,0,10,11,19,19,2,0,9,9,
        12,12,135,0,28,1,0,0,0,2,31,1,0,0,0,4,33,1,0,0,0,6,35,1,0,0,0,8,
        37,1,0,0,0,10,45,1,0,0,0,12,53,1,0,0,0,14,61,1,0,0,0,16,69,1,0,0,
        0,18,77,1,0,0,0,20,85,1,0,0,0,22,102,1,0,0,0,24,114,1,0,0,0,26,116,
        1,0,0,0,28,29,3,6,3,0,29,30,5,0,0,1,30,1,1,0,0,0,31,32,5,35,0,0,
        32,3,1,0,0,0,33,34,7,0,0,0,34,5,1,0,0,0,35,36,3,8,4,0,36,7,1,0,0,
        0,37,42,3,10,5,0,38,39,5,22,0,0,39,41,3,10,5,0,40,38,1,0,0,0,41,
        44,1,0,0,0,42,40,1,0,0,0,42,43,1,0,0,0,43,9,1,0,0,0,44,42,1,0,0,
        0,45,50,3,12,6,0,46,47,5,23,0,0,47,49,3,12,6,0,48,46,1,0,0,0,49,
        52,1,0,0,0,50,48,1,0,0,0,50,51,1,0,0,0,51,11,1,0,0,0,52,50,1,0,0,
        0,53,58,3,14,7,0,54,55,7,1,0,0,55,57,3,14,7,0,56,54,1,0,0,0,57,60,
        1,0,0,0,58,56,1,0,0,0,58,59,1,0,0,0,59,13,1,0,0,0,60,58,1,0,0,0,
        61,66,3,16,8,0,62,63,7,2,0,0,63,65,3,16,8,0,64,62,1,0,0,0,65,68,
        1,0,0,0,66,64,1,0,0,0,66,67,1,0,0,0,67,15,1,0,0,0,68,66,1,0,0,0,
        69,74,3,18,9,0,70,71,7,3,0,0,71,73,3,18,9,0,72,70,1,0,0,0,73,76,
        1,0,0,0,74,72,1,0,0,0,74,75,1,0,0,0,75,17,1,0,0,0,76,74,1,0,0,0,
        77,82,3,20,10,0,78,79,7,4,0,0,79,81,3,20,10,0,80,78,1,0,0,0,81,84,
        1,0,0,0,82,80,1,0,0,0,82,83,1,0,0,0,83,19,1,0,0,0,84,82,1,0,0,0,
        85,90,3,22,11,0,86,87,5,20,0,0,87,89,3,22,11,0,88,86,1,0,0,0,89,
        92,1,0,0,0,90,88,1,0,0,0,90,91,1,0,0,0,91,21,1,0,0,0,92,90,1,0,0,
        0,93,103,3,24,12,0,94,95,5,10,0,0,95,103,3,22,11,0,96,97,5,11,0,
        0,97,103,3,22,11,0,98,99,5,28,0,0,99,103,3,22,11,0,100,101,5,7,0,
        0,101,103,3,22,11,0,102,93,1,0,0,0,102,94,1,0,0,0,102,96,1,0,0,0,
        102,98,1,0,0,0,102,100,1,0,0,0,103,23,1,0,0,0,104,115,3,2,1,0,105,
        115,3,4,2,0,106,115,5,29,0,0,107,115,5,30,0,0,108,115,5,31,0,0,109,
        110,5,1,0,0,110,111,3,8,4,0,111,112,5,2,0,0,112,115,1,0,0,0,113,
        115,3,26,13,0,114,104,1,0,0,0,114,105,1,0,0,0,114,106,1,0,0,0,114,
        107,1,0,0,0,114,108,1,0,0,0,114,109,1,0,0,0,114,113,1,0,0,0,115,
        25,1,0,0,0,116,117,5,35,0,0,117,126,5,1,0,0,118,123,3,6,3,0,119,
        120,5,6,0,0,120,122,3,6,3,0,121,119,1,0,0,0,122,125,1,0,0,0,123,
        121,1,0,0,0,123,124,1,0,0,0,124,127,1,0,0,0,125,123,1,0,0,0,126,
        118,1,0,0,0,126,127,1,0,0,0,127,128,1,0,0,0,128,129,5,2,0,0,129,
        27,1,0,0,0,11,42,50,58,66,74,82,90,102,114,123,126
    ]

class SalesforceFormulaParser ( Parser ):

    grammarFileName = "SalesforceFormula.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'('", "')'", "'['", "']'", "':'", "','", 
                     "'!'", "'~'", "'/'", "'+'", "'-'", "'*'", "'>='", "'>'", 
                     "'<='", "'<'", "';'", "'.'", "'&'", "'^'", "'=>'", 
                     "'||'", "'&&'", "'='", "'=='", "'<>'", "'!='" ]

    symbolicNames = [ "<INVALID>", "LPAREN", "RPAREN", "LSQUAREBRACKET", 
                      "RSQUAREBRACKET", "COLON", "COMMA", "BANG", "BNOT", 
                      "DIV", "PLUS", "MINUS", "STAR", "GE", "GT", "LE", 
                      "LT", "SEMI", "DOT", "CONCAT", "EXPONENT", "MAPTO", 
                      "INFIX_OR", "INFIX_AND", "EQUAL", "EQUAL2", "NOT_EQUAL", 
                      "NOT_EQUAL2", "NOT", "TRUE", "FALSE", "NULL", "WS", 
                      "STRING_LITERAL", "COMMENT", "IDENT", "NUMBER" ]

    RULE_formula = 0
    RULE_fieldReferenceLiteral = 1
    RULE_constant = 2
    RULE_expression = 3
    RULE_logicalOrExpression = 4
    RULE_logicalAndExpression = 5
    RULE_equalityExpression = 6
    RULE_relationalExpression = 7
    RULE_additiveExpression = 8
    RULE_multiplicativeExpression = 9
    RULE_exponentExpression = 10
    RULE_unaryExpression = 11
    RULE_primaryExpression = 12
    RULE_functionCall = 13

    ruleNames =  [ "formula", "fieldReferenceLiteral", "constant", "expression", 
                   "logicalOrExpression", "logicalAndExpression", "equalityExpression", 
                   "relationalExpression", "additiveExpression", "multiplicativeExpression", 
                   "exponentExpression", "unaryExpression", "primaryExpression", 
                   "functionCall" ]

    EOF = Token.EOF
    LPAREN=1
    RPAREN=2
    LSQUAREBRACKET=3
    RSQUAREBRACKET=4
    COLON=5
    COMMA=6
    BANG=7
    BNOT=8
    DIV=9
    PLUS=10
    MINUS=11
    STAR=12
    GE=13
    GT=14
    LE=15
    LT=16
    SEMI=17
    DOT=18
    CONCAT=19
    EXPONENT=20
    MAPTO=21
    INFIX_OR=22
    INFIX_AND=23
    EQUAL=24
    EQUAL2=25
    NOT_EQUAL=26
    NOT_EQUAL2=27
    NOT=28
    TRUE=29
    FALSE=30
    NULL=31
    WS=32
    STRING_LITERAL=33
    COMMENT=34
    IDENT=35
    NUMBER=36

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class FormulaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expression(self):
            return self.getTypedRuleContext(SalesforceFormulaParser.ExpressionContext,0)


        def EOF(self):
            return self.getToken(SalesforceFormulaParser.EOF, 0)

        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_formula

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFormula" ):
                return visitor.visitFormula(self)
            else:
                return visitor.visitChildren(self)




    def formula(self):

        localctx = SalesforceFormulaParser.FormulaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_formula)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 28
            self.expression()
            self.state = 29
            self.match(SalesforceFormulaParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FieldReferenceLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(SalesforceFormulaParser.IDENT, 0)

        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_fieldReferenceLiteral

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFieldReferenceLiteral" ):
                return visitor.visitFieldReferenceLiteral(self)
            else:
                return visitor.visitChildren(self)




    def fieldReferenceLiteral(self):

        localctx = SalesforceFormulaParser.FieldReferenceLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_fieldReferenceLiteral)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 31
            self.match(SalesforceFormulaParser.IDENT)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ConstantContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMBER(self):
            return self.getToken(SalesforceFormulaParser.NUMBER, 0)

        def STRING_LITERAL(self):
            return self.getToken(SalesforceFormulaParser.STRING_LITERAL, 0)

        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_constant

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitConstant" ):
                return visitor.visitConstant(self)
            else:
                return visitor.visitChildren(self)




    def constant(self):

        localctx = SalesforceFormulaParser.ConstantContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_constant)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 33
            _la = self._input.LA(1)
            if not(_la==33 or _la==36):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def logicalOrExpression(self):
            return self.getTypedRuleContext(SalesforceFormulaParser.LogicalOrExpressionContext,0)


        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_expression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpression" ):
                return visitor.visitExpression(self)
            else:
                return visitor.visitChildren(self)




    def expression(self):

        localctx = SalesforceFormulaParser.ExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_expression)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 35
            self.logicalOrExpression()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LogicalOrExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def logicalAndExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SalesforceFormulaParser.LogicalAndExpressionContext)
            else:
                return self.getTypedRuleContext(SalesforceFormulaParser.LogicalAndExpressionContext,i)


        def INFIX_OR(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.INFIX_OR)
            else:
                return self.getToken(SalesforceFormulaParser.INFIX_OR, i)

        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_logicalOrExpression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogicalOrExpression" ):
                return visitor.visitLogicalOrExpression(self)
            else:
                return visitor.visitChildren(self)




    def logicalOrExpression(self):

        localctx = SalesforceFormulaParser.LogicalOrExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_logicalOrExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 37
            self.logicalAndExpression()
            self.state = 42
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==22:
                self.state = 38
                self.match(SalesforceFormulaParser.INFIX_OR)
                self.state = 39
                self.logicalAndExpression()
                self.state = 44
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LogicalAndExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def equalityExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SalesforceFormulaParser.EqualityExpressionContext)
            else:
                return self.getTypedRuleContext(SalesforceFormulaParser.EqualityExpressionContext,i)


        def INFIX_AND(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.INFIX_AND)
            else:
                return self.getToken(SalesforceFormulaParser.INFIX_AND, i)

        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_logicalAndExpression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLogicalAndExpression" ):
                return visitor.visitLogicalAndExpression(self)
            else:
                return visitor.visitChildren(self)




    def logicalAndExpression(self):

        localctx = SalesforceFormulaParser.LogicalAndExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_logicalAndExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 45
            self.equalityExpression()
            self.state = 50
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==23:
                self.state = 46
                self.match(SalesforceFormulaParser.INFIX_AND)
                self.state = 47
                self.equalityExpression()
                self.state = 52
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EqualityExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def relationalExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SalesforceFormulaParser.RelationalExpressionContext)
            else:
                return self.getTypedRuleContext(SalesforceFormulaParser.RelationalExpressionContext,i)


        def NOT_EQUAL(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.NOT_EQUAL)
            else:
                return self.getToken(SalesforceFormulaParser.NOT_EQUAL, i)

        def EQUAL(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.EQUAL)
            else:
                return self.getToken(SalesforceFormulaParser.EQUAL, i)

        def NOT_EQUAL2(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.NOT_EQUAL2)
            else:
                return self.getToken(SalesforceFormulaParser.NOT_EQUAL2, i)

        def EQUAL2(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.EQUAL2)
            else:
                return self.getToken(SalesforceFormulaParser.EQUAL2, i)

        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_equalityExpression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitEqualityExpression" ):
                return visitor.visitEqualityExpression(self)
            else:
                return visitor.visitChildren(self)




    def equalityExpression(self):

        localctx = SalesforceFormulaParser.EqualityExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_equalityExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 53
            self.relationalExpression()
            self.state = 58
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 251658240) != 0):
                self.state = 54
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 251658240) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 55
                self.relationalExpression()
                self.state = 60
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelationalExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def additiveExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SalesforceFormulaParser.AdditiveExpressionContext)
            else:
                return self.getTypedRuleContext(SalesforceFormulaParser.AdditiveExpressionContext,i)


        def LT(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.LT)
            else:
                return self.getToken(SalesforceFormulaParser.LT, i)

        def GT(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.GT)
            else:
                return self.getToken(SalesforceFormulaParser.GT, i)

        def LE(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.LE)
            else:
                return self.getToken(SalesforceFormulaParser.LE, i)

        def GE(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.GE)
            else:
                return self.getToken(SalesforceFormulaParser.GE, i)

        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_relationalExpression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRelationalExpression" ):
                return visitor.visitRelationalExpression(self)
            else:
                return visitor.visitChildren(self)




    def relationalExpression(self):

        localctx = SalesforceFormulaParser.RelationalExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_relationalExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 61
            self.additiveExpression()
            self.state = 66
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 122880) != 0):
                self.state = 62
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 122880) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 63
                self.additiveExpression()
                self.state = 68
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AdditiveExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def multiplicativeExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SalesforceFormulaParser.MultiplicativeExpressionContext)
            else:
                return self.getTypedRuleContext(SalesforceFormulaParser.MultiplicativeExpressionContext,i)


        def PLUS(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.PLUS)
            else:
                return self.getToken(SalesforceFormulaParser.PLUS, i)

        def MINUS(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.MINUS)
            else:
                return self.getToken(SalesforceFormulaParser.MINUS, i)

        def CONCAT(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.CONCAT)
            else:
                return self.getToken(SalesforceFormulaParser.CONCAT, i)

        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_additiveExpression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAdditiveExpression" ):
                return visitor.visitAdditiveExpression(self)
            else:
                return visitor.visitChildren(self)




    def additiveExpression(self):

        localctx = SalesforceFormulaParser.AdditiveExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_additiveExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 69
            self.multiplicativeExpression()
            self.state = 74
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 527360) != 0):
                self.state = 70
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 527360) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 71
                self.multiplicativeExpression()
                self.state = 76
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MultiplicativeExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exponentExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SalesforceFormulaParser.ExponentExpressionContext)
            else:
                return self.getTypedRuleContext(SalesforceFormulaParser.ExponentExpressionContext,i)


        def STAR(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.STAR)
            else:
                return self.getToken(SalesforceFormulaParser.STAR, i)

        def DIV(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.DIV)
            else:
                return self.getToken(SalesforceFormulaParser.DIV, i)

        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_multiplicativeExpression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMultiplicativeExpression" ):
                return visitor.visitMultiplicativeExpression(self)
            else:
                return visitor.visitChildren(self)




    def multiplicativeExpression(self):

        localctx = SalesforceFormulaParser.MultiplicativeExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_multiplicativeExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 77
            self.exponentExpression()
            self.state = 82
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==9 or _la==12:
                self.state = 78
                _la = self._input.LA(1)
                if not(_la==9 or _la==12):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 79
                self.exponentExpression()
                self.state = 84
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExponentExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unaryExpression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SalesforceFormulaParser.UnaryExpressionContext)
            else:
                return self.getTypedRuleContext(SalesforceFormulaParser.UnaryExpressionContext,i)


        def EXPONENT(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.EXPONENT)
            else:
                return self.getToken(SalesforceFormulaParser.EXPONENT, i)

        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_exponentExpression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExponentExpression" ):
                return visitor.visitExponentExpression(self)
            else:
                return visitor.visitChildren(self)




    def exponentExpression(self):

        localctx = SalesforceFormulaParser.ExponentExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_exponentExpression)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 85
            self.unaryExpression()
            self.state = 90
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==20:
                self.state = 86
                self.match(SalesforceFormulaParser.EXPONENT)
                self.state = 87
                self.unaryExpression()
                self.state = 92
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnaryExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_unaryExpression

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class UnaryExpression_primaryContext(UnaryExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SalesforceFormulaParser.UnaryExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def primaryExpression(self):
            return self.getTypedRuleContext(SalesforceFormulaParser.PrimaryExpressionContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryExpression_primary" ):
                return visitor.visitUnaryExpression_primary(self)
            else:
                return visitor.visitChildren(self)


    class UnaryExpression_notContext(UnaryExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SalesforceFormulaParser.UnaryExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def NOT(self):
            return self.getToken(SalesforceFormulaParser.NOT, 0)
        def unaryExpression(self):
            return self.getTypedRuleContext(SalesforceFormulaParser.UnaryExpressionContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryExpression_not" ):
                return visitor.visitUnaryExpression_not(self)
            else:
                return visitor.visitChildren(self)


    class UnaryExpression_minusContext(UnaryExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SalesforceFormulaParser.UnaryExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def MINUS(self):
            return self.getToken(SalesforceFormulaParser.MINUS, 0)
        def unaryExpression(self):
            return self.getTypedRuleContext(SalesforceFormulaParser.UnaryExpressionContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryExpression_minus" ):
                return visitor.visitUnaryExpression_minus(self)
            else:
                return visitor.visitChildren(self)


    class UnaryExpression_bangContext(UnaryExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SalesforceFormulaParser.UnaryExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def BANG(self):
            return self.getToken(SalesforceFormulaParser.BANG, 0)
        def unaryExpression(self):
            return self.getTypedRuleContext(SalesforceFormulaParser.UnaryExpressionContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryExpression_bang" ):
                return visitor.visitUnaryExpression_bang(self)
            else:
                return visitor.visitChildren(self)


    class UnaryExpression_plusContext(UnaryExpressionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a SalesforceFormulaParser.UnaryExpressionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def PLUS(self):
            return self.getToken(SalesforceFormulaParser.PLUS, 0)
        def unaryExpression(self):
            return self.getTypedRuleContext(SalesforceFormulaParser.UnaryExpressionContext,0)


        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryExpression_plus" ):
                return visitor.visitUnaryExpression_plus(self)
            else:
                return visitor.visitChildren(self)



    def unaryExpression(self):

        localctx = SalesforceFormulaParser.UnaryExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_unaryExpression)
        try:
            self.state = 102
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1, 29, 30, 31, 33, 35, 36]:
                localctx = SalesforceFormulaParser.UnaryExpression_primaryContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 93
                self.primaryExpression()
                pass
            elif token in [10]:
                localctx = SalesforceFormulaParser.UnaryExpression_plusContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 94
                self.match(SalesforceFormulaParser.PLUS)
                self.state = 95
                self.unaryExpression()
                pass
            elif token in [11]:
                localctx = SalesforceFormulaParser.UnaryExpression_minusContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 96
                self.match(SalesforceFormulaParser.MINUS)
                self.state = 97
                self.unaryExpression()
                pass
            elif token in [28]:
                localctx = SalesforceFormulaParser.UnaryExpression_notContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 98
                self.match(SalesforceFormulaParser.NOT)
                self.state = 99
                self.unaryExpression()
                pass
            elif token in [7]:
                localctx = SalesforceFormulaParser.UnaryExpression_bangContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 100
                self.match(SalesforceFormulaParser.BANG)
                self.state = 101
                self.unaryExpression()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryExpressionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fieldReferenceLiteral(self):
            return self.getTypedRuleContext(SalesforceFormulaParser.FieldReferenceLiteralContext,0)


        def constant(self):
            return self.getTypedRuleContext(SalesforceFormulaParser.ConstantContext,0)


        def TRUE(self):
            return self.getToken(SalesforceFormulaParser.TRUE, 0)

        def FALSE(self):
            return self.getToken(SalesforceFormulaParser.FALSE, 0)

        def NULL(self):
            return self.getToken(SalesforceFormulaParser.NULL, 0)

        def LPAREN(self):
            return self.getToken(SalesforceFormulaParser.LPAREN, 0)

        def logicalOrExpression(self):
            return self.getTypedRuleContext(SalesforceFormulaParser.LogicalOrExpressionContext,0)


        def RPAREN(self):
            return self.getToken(SalesforceFormulaParser.RPAREN, 0)

        def functionCall(self):
            return self.getTypedRuleContext(SalesforceFormulaParser.FunctionCallContext,0)


        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_primaryExpression

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrimaryExpression" ):
                return visitor.visitPrimaryExpression(self)
            else:
                return visitor.visitChildren(self)




    def primaryExpression(self):

        localctx = SalesforceFormulaParser.PrimaryExpressionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_primaryExpression)
        try:
            self.state = 114
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 104
                self.fieldReferenceLiteral()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 105
                self.constant()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 106
                self.match(SalesforceFormulaParser.TRUE)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 107
                self.match(SalesforceFormulaParser.FALSE)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 108
                self.match(SalesforceFormulaParser.NULL)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 109
                self.match(SalesforceFormulaParser.LPAREN)
                self.state = 110
                self.logicalOrExpression()
                self.state = 111
                self.match(SalesforceFormulaParser.RPAREN)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 113
                self.functionCall()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionCallContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(SalesforceFormulaParser.IDENT, 0)

        def LPAREN(self):
            return self.getToken(SalesforceFormulaParser.LPAREN, 0)

        def RPAREN(self):
            return self.getToken(SalesforceFormulaParser.RPAREN, 0)

        def expression(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(SalesforceFormulaParser.ExpressionContext)
            else:
                return self.getTypedRuleContext(SalesforceFormulaParser.ExpressionContext,i)


        def COMMA(self, i:int=None):
            if i is None:
                return self.getTokens(SalesforceFormulaParser.COMMA)
            else:
                return self.getToken(SalesforceFormulaParser.COMMA, i)

        def getRuleIndex(self):
            return SalesforceFormulaParser.RULE_functionCall

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFunctionCall" ):
                return visitor.visitFunctionCall(self)
            else:
                return visitor.visitChildren(self)




    def functionCall(self):

        localctx = SalesforceFormulaParser.FunctionCallContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_functionCall)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 116
            self.match(SalesforceFormulaParser.IDENT)
            self.state = 117
            self.match(SalesforceFormulaParser.LPAREN)
            self.state = 126
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 115695684738) != 0):
                self.state = 118
                self.expression()
                self.state = 123
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==6:
                    self.state = 119
                    self.match(SalesforceFormulaParser.COMMA)
                    self.state = 120
                    self.expression()
                    self.state = 125
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 128
            self.match(SalesforceFormulaParser.RPAREN)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





