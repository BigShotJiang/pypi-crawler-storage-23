# Generated from SalesforceFormula.g4 by ANTLR 4.13.2
from antlr4 import *
if "." in __name__:
    from .SalesforceFormulaParser import SalesforceFormulaParser
else:
    from SalesforceFormulaParser import SalesforceFormulaParser

# This class defines a complete generic visitor for a parse tree produced by SalesforceFormulaParser.

class SalesforceFormulaVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by SalesforceFormulaParser#formula.
    def visitFormula(self, ctx:SalesforceFormulaParser.FormulaContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#fieldReferenceLiteral.
    def visitFieldReferenceLiteral(self, ctx:SalesforceFormulaParser.FieldReferenceLiteralContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#constant.
    def visitConstant(self, ctx:SalesforceFormulaParser.ConstantContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#expression.
    def visitExpression(self, ctx:SalesforceFormulaParser.ExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#logicalOrExpression.
    def visitLogicalOrExpression(self, ctx:SalesforceFormulaParser.LogicalOrExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#logicalAndExpression.
    def visitLogicalAndExpression(self, ctx:SalesforceFormulaParser.LogicalAndExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#equalityExpression.
    def visitEqualityExpression(self, ctx:SalesforceFormulaParser.EqualityExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#relationalExpression.
    def visitRelationalExpression(self, ctx:SalesforceFormulaParser.RelationalExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#additiveExpression.
    def visitAdditiveExpression(self, ctx:SalesforceFormulaParser.AdditiveExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#multiplicativeExpression.
    def visitMultiplicativeExpression(self, ctx:SalesforceFormulaParser.MultiplicativeExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#exponentExpression.
    def visitExponentExpression(self, ctx:SalesforceFormulaParser.ExponentExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#unaryExpression_primary.
    def visitUnaryExpression_primary(self, ctx:SalesforceFormulaParser.UnaryExpression_primaryContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#unaryExpression_plus.
    def visitUnaryExpression_plus(self, ctx:SalesforceFormulaParser.UnaryExpression_plusContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#unaryExpression_minus.
    def visitUnaryExpression_minus(self, ctx:SalesforceFormulaParser.UnaryExpression_minusContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#unaryExpression_not.
    def visitUnaryExpression_not(self, ctx:SalesforceFormulaParser.UnaryExpression_notContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#unaryExpression_bang.
    def visitUnaryExpression_bang(self, ctx:SalesforceFormulaParser.UnaryExpression_bangContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#primaryExpression.
    def visitPrimaryExpression(self, ctx:SalesforceFormulaParser.PrimaryExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by SalesforceFormulaParser#functionCall.
    def visitFunctionCall(self, ctx:SalesforceFormulaParser.FunctionCallContext):
        return self.visitChildren(ctx)



del SalesforceFormulaParser