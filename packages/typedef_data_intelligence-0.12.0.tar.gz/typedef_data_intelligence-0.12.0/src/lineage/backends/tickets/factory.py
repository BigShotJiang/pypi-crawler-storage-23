"""Factory functions for creating ticket storage backend instances.

This module provides factory functions that create TicketStorage instances
from configuration objects, with graceful degradation when initialization fails.
"""

from __future__ import annotations

import logging
from pathlib import Path
import os
from typing import Optional, Literal

from lineage.backends.tickets.protocol import TicketStorage

logger = logging.getLogger(__name__)


def create_ticket_backend(
    backend: str,
    base_path: str | Path = "./tickets",
    api_key: Optional[str] = None,
    team_id: Optional[str] = None,
    project_id: Optional[str] = None,
) -> Optional[TicketStorage]:
    """Create a ticket storage backend from configuration.

    This function creates ticket backend instances with graceful degradation:
    - If initialization fails, logs a warning and returns None
    - If successful, returns a working TicketStorage instance

    Args:
        backend: Backend type ("filesystem" or "linear")
        base_path: Base directory for ticket storage (filesystem backend only)
        api_key: Linear API key (linear backend only)
        team_id: Linear team ID (linear backend only)
        project_id: Linear project ID (linear backend only)

    Returns:
        TicketStorage instance, or None if backend cannot be created

    Note:
        This function never raises exceptions - it always returns None on failure.
        This enables graceful degradation when ticket storage is unavailable.
    """
    backend_lower = backend.lower()

    if backend_lower == "filesystem":
        return _create_filesystem_backend(base_path=base_path)
    elif backend_lower == "linear":
        if not api_key:
            api_key = os.getenv("LINEAR_ANALYST_API_KEY") or os.getenv("LINEAR_DATA_ENGINEER_API_KEY")
            if not api_key:
                logger.warning("No Linear API keys found in environment variables.  Ticket backend will be disabled.")
                return None
        return _create_linear_backend(
            api_key=api_key,
            team_id=team_id,
            project_id=project_id,
        )
    else:
        logger.warning(
            f"Unknown ticket backend: {backend}. Supported: filesystem, linear. "
            f"Ticket features will be disabled."
        )
        return None


def create_ticket_backend_from_config(config: "TicketConfig", role: Literal["analyst", "data_engineer"]) -> Optional[TicketStorage]:
    """Create ticket backend from unified configuration.

    Args:
        config: Ticket configuration object
        role: Role to use for tickets (analyst or data_engineer).  Dictates which API key to use for Linear.

    Returns:
        TicketStorage instance, or None if backend cannot be created
    """
    # Import here to avoid circular dependency
    from lineage.backends.config import FilesystemTicketConfig, LinearTicketConfig

    if isinstance(config, FilesystemTicketConfig):
        return _create_filesystem_backend(base_path=config.base_path)
    elif isinstance(config, LinearTicketConfig):
        # Select API key based on role
        if role == "analyst":
            api_key = os.getenv("LINEAR_ANALYST_API_KEY")
        else:
            api_key = os.getenv("LINEAR_DATA_ENGINEER_API_KEY")

        if not api_key:
            logger.warning(f"No Linear API key found for role '{role}'.  Ticket backend will be disabled.")
            return None

        return _create_linear_backend(
            api_key=api_key,
            team_id=config.team_id,
            project_id=config.project_id,
        )
    else:
        logger.warning(f"Unknown ticket config type: {type(config)}")
        return None


def _create_filesystem_backend(
    base_path: str | Path,
) -> Optional[TicketStorage]:
    """Create filesystem ticket backend.

    Args:
        base_path: Base directory for ticket JSON files

    Returns:
        FilesystemTicketStorage instance, or None on failure
    """
    try:
        from lineage.backends.tickets.filesystem_backend import FilesystemTicketStorage

        storage = FilesystemTicketStorage(base_path=str(base_path))

        logger.info(
            f"Ticket storage initialized: Filesystem at {base_path}"
        )
        return storage

    except Exception as e:
        logger.error(
            f"Failed to initialize filesystem ticket storage: {e}. "
            f"Ticket features will be disabled."
        )
        return None


def _create_linear_backend(
    api_key: str,
    team_id: Optional[str] = None,
    project_id: Optional[str] = None,
) -> Optional[TicketStorage]:
    """Create Linear ticket backend.

    Args:
        api_key: Linear API key for authentication
        team_id: Linear team ID (optional)
        project_id: Linear project ID (optional)

    Returns:
        LinearTicketStorage instance, or None on failure
    """
    try:
        from lineage.backends.tickets.linear_backend import LinearTicketStorage

        storage = LinearTicketStorage(
            api_key=api_key,
            team_id=team_id,
            project_id=project_id,
        )

        logger.info(
            "Ticket storage initialized: Linear API (direct SDK)"
        )
        return storage

    except Exception as e:
        logger.error(
            f"Failed to initialize Linear ticket storage: {e}. "
            f"Ticket features will be disabled."
        )
        return None


__all__ = ["create_ticket_backend", "create_ticket_backend_from_config"]
