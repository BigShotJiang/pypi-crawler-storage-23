"""Linear implementation of TicketStorage using the linear-api SDK."""
from __future__ import annotations

import asyncio
import logging
from textwrap import dedent
from typing import Any, Dict, List, Optional

from linear_api import (
    LinearClient,
    LinearIssue,
    LinearIssueInput,
    LinearIssueUpdateInput,
    LinearPriority,
    LinearUser,
    LinearTeam,
)

from lineage.backends.tickets.protocol import (
    TicketStorage,
    Ticket,
    TicketStatus,
    TicketPriority,
)

logger = logging.getLogger(__name__)

COMMENT_CREATE_MUTATION = """
mutation CommentCreate($issueId: String!, $body: String!) {
    commentCreate(input: { issueId: $issueId, body: $body }) {
        success
        comment {
            id
            body
            createdAt
            updatedAt
        }
    }
}
"""


class LinearTicketStorage(TicketStorage):
    """Linear ticket storage implementation using the linear-api SDK.

    Connects directly to the Linear GraphQL API via the linear-api Python SDK,
    providing ticket management capabilities via the TicketStorage protocol.

    Note:
    * Presents human-readable identifiers (e.g. 'DAV-1') instead of Linear UUIDs
    * Keeps user/team name↔id lookup caches populated lazily
    * SDK is synchronous — all calls are wrapped with asyncio.to_thread()
    """

    def __init__(
        self,
        api_key: str,
        team_id: Optional[str] = None,
        project_id: Optional[str] = None,
    ):
        """Initialize Linear ticket storage.

        Args:
            api_key: Linear API key for authentication
            team_id: Linear team ID to use for tickets
            project_id: Linear project ID to assign tickets to
        """
        logger.debug(f"Initializing LinearTicketStorage with team_id={team_id}, project_id={project_id}")

        self._client = LinearClient(api_key=api_key)
        self.team_id = team_id
        self.project_id = project_id

        # Name↔ID lookup caches (populated lazily)
        self.user_id_to_name: Dict[str, str] = {}
        self.user_name_to_id: Dict[str, str] = {}
        self.team_id_to_name: Dict[str, str] = {}
        self.team_name_to_id: Dict[str, str] = {}
        self.label_name_to_id: Dict[str, str] = {}
        self.label_id_to_name: Dict[str, str] = {}
        self._team_name: Optional[str] = None  # Resolved team name for SDK calls
        self._project_name: Optional[str] = None  # Resolved project name for SDK calls
        self._caches_initialized = False

        logger.info("Linear ticket storage initialized (direct SDK)")

    async def _initialize_caches(self) -> None:
        """Initialize local name↔id caches by querying the Linear API."""
        if self._caches_initialized:
            return

        try:
            logger.debug("Initializing Linear caches (users, teams)")

            # Populate user caches
            try:
                users: Dict[str, LinearUser] = await asyncio.to_thread(self._client.users.get_all)
                for uid, user in users.items():
                    name = user.displayName or user.name
                    if uid and name:
                        self.user_id_to_name[uid] = name
                        self.user_name_to_id[name] = uid
                logger.info(f"Cached {len(self.user_id_to_name)} users")
            except Exception as e:
                logger.warning(f"Failed to list users for cache init: {e}")

            # Populate team caches and resolve team_id → team name
            try:
                teams: Dict[str, LinearTeam] = await asyncio.to_thread(self._client.teams.get_all)
                for tid, team in teams.items():
                    tname = team.name or team.key
                    if tid and tname:
                        self.team_id_to_name[tid] = tname
                        self.team_name_to_id[tname] = tid
                logger.info(f"Cached {len(self.team_id_to_name)} teams")

                # Resolve team_id to team name for SDK input objects
                if self.team_id and self.team_id in self.team_id_to_name:
                    self._team_name = self.team_id_to_name[self.team_id]
                    logger.debug(f"Resolved team_id '{self.team_id}' to name '{self._team_name}'")
            except Exception as e:
                logger.warning(f"Failed to list teams for cache init: {e}")

            # Populate label caches for the team
            if self.team_id:
                try:
                    labels = await asyncio.to_thread(self._client.teams.get_labels, self.team_id)
                    for label in labels:
                        if label.id and label.name:
                            self.label_name_to_id[label.name] = label.id
                            self.label_id_to_name[label.id] = label.name
                    logger.info(f"Cached {len(self.label_name_to_id)} labels")
                except Exception as e:
                    logger.warning(f"Failed to list labels for cache init: {e}")

            # Resolve project_id to project name if needed
            if self.project_id:
                try:
                    project = await asyncio.to_thread(self._client.projects.get, self.project_id)
                    if project and project.name:
                        self._project_name = project.name
                        logger.debug(f"Resolved project_id '{self.project_id}' to name '{self._project_name}'")
                except Exception as e:
                    logger.warning(f"Failed to resolve project_id '{self.project_id}': {e}")

            self._caches_initialized = True
        except Exception as e:
            logger.warning(f"Failed to initialize Linear caches: {e}")

    def _resolve_ticket_identifier_to_id(self, ticket_id_or_identifier: str) -> str:
        """Resolve ticket identifier (e.g., 'DAV-1') to Linear ID, or return as-is if already an ID."""
        if "-" in ticket_id_or_identifier and len(ticket_id_or_identifier) > 30:
            return ticket_id_or_identifier
        # For short identifiers like 'DAV-1', we need to search — but since the SDK
        # get() method accepts IDs, we'll try it as-is and let the SDK handle it.
        return ticket_id_or_identifier

    def _resolve_user_name_to_id(self, user_name: str) -> Optional[str]:
        """Resolve user name to Linear ID."""
        user_id = self.user_name_to_id.get(user_name)
        if user_id:
            return user_id
        if "-" in user_name and len(user_name) > 30:
            return user_name
        logger.warning(f"User name '{user_name}' not found in cache")
        return None

    def _resolve_user_id_to_name(self, user_id: str) -> Optional[str]:
        """Resolve user ID to name."""
        return self.user_id_to_name.get(user_id)

    def _resolve_label_names_to_ids(self, tags: List[str]) -> tuple[List[str], List[str]]:
        """Resolve label names to Linear label IDs.

        Accepts either label UUIDs (passed through) or human-readable names
        (resolved via the label cache).

        Returns:
            Tuple of (resolved_label_ids, unresolved_tag_names).
        """
        resolved: List[str] = []
        unresolved: List[str] = []
        for tag in tags:
            # Already a UUID?
            if "-" in tag and len(tag) > 30:
                resolved.append(tag)
                continue
            label_id = self.label_name_to_id.get(tag)
            if label_id:
                resolved.append(label_id)
            else:
                unresolved.append(tag)
                logger.warning(
                    f"Label '{tag}' not found in team labels. "
                    f"Available labels: {list(self.label_name_to_id.keys())}."
                )
        return resolved, unresolved

    def get_available_labels(self) -> List[str]:
        """Return the list of available label names for the team."""
        return list(self.label_name_to_id.keys())

    # ── Priority/Status mapping ──────────────────────────────────────────

    def _map_priority_to_linear(self, priority: str) -> LinearPriority:
        """Map our priority enum value to LinearPriority."""
        mapping = {
            "urgent": LinearPriority.URGENT,
            "high": LinearPriority.HIGH,
            "medium": LinearPriority.MEDIUM,
            "low": LinearPriority.LOW,
        }
        return mapping.get(priority.lower(), LinearPriority.MEDIUM)

    def _map_linear_priority_to_enum(self, priority: LinearPriority) -> TicketPriority:
        """Map LinearPriority enum to our TicketPriority."""
        mapping = {
            LinearPriority.URGENT: TicketPriority.URGENT,
            LinearPriority.HIGH: TicketPriority.HIGH,
            LinearPriority.MEDIUM: TicketPriority.MEDIUM,
            LinearPriority.LOW: TicketPriority.LOW,
            LinearPriority.NONE: TicketPriority.LOW,
        }
        return mapping.get(priority, TicketPriority.LOW)

    def _map_linear_state_to_status(self, state_name: str) -> TicketStatus:
        """Map Linear state name to our ticket status."""
        mapping = {
            "Todo": TicketStatus.OPEN,
            "In Progress": TicketStatus.IN_PROGRESS,
            "In Review": TicketStatus.IN_REVIEW,
            "Done": TicketStatus.COMPLETED,
            "Canceled": TicketStatus.CANCELLED,
            "Backlog": TicketStatus.BACKLOG,
        }
        return mapping.get(state_name, TicketStatus.OPEN)

    def _map_status_to_linear_state(self, status: TicketStatus) -> str:
        """Map our ticket status to Linear state name."""
        mapping = {
            TicketStatus.OPEN: "Todo",
            TicketStatus.IN_PROGRESS: "In Progress",
            TicketStatus.BLOCKED: "In Progress",
            TicketStatus.IN_REVIEW: "In Review",
            TicketStatus.BACKLOG: "Backlog",
            TicketStatus.COMPLETED: "Done",
            TicketStatus.CANCELLED: "Canceled",
        }
        return mapping.get(status, "Todo")

    # ── Conversion ───────────────────────────────────────────────────────

    def _linear_issue_to_ticket(self, issue: LinearIssue, comments: List[Dict[str, Any]]) -> Ticket:
        """Convert a LinearIssue object to our Ticket dataclass."""
        # Extract state name
        state_name = issue.state.name if issue.state else ""

        # Extract assignee/creator names
        assignee_name = None
        if issue.assignee:
            assignee_name = issue.assignee.displayName or issue.assignee.name

        created_by_name = None
        if hasattr(issue, "creator") and issue.creator:
            created_by_name = issue.creator.displayName or issue.creator.name

        # Extract team name
        team_name = None
        if issue.team:
            team_name = issue.team.name

        # Use identifier (e.g. 'DAV-1'), fall back to id
        display_id = issue.identifier or issue.id

        return Ticket(
            id=display_id,
            title=issue.title,
            description=issue.description or "",
            status=self._map_linear_state_to_status(state_name),
            priority=self._map_linear_priority_to_enum(issue.priority),
            created_by=created_by_name,
            assigned_to=assignee_name,
            created_at=issue.createdAt,
            updated_at=issue.updatedAt,
            completed_at=issue.completedAt if state_name == "Done" else None,
            tags=[label.name for label in issue.labels] if issue.labels else [],
            metadata={"linear_team": team_name},
            comments=comments,
        )

    # ── Protocol methods ─────────────────────────────────────────────────

    async def create_ticket(
        self,
        title: str,
        description: str,
        priority: TicketPriority,
        created_by: str,
        assigned_to: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Ticket:
        """Create a new ticket in Linear."""
        logger.debug(f"Creating ticket: title='{title}', priority={priority}")
        await self._initialize_caches()

        if not self._team_name:
            raise ValueError("team_id must be set and resolvable to create tickets")

        input_kwargs: Dict[str, Any] = {
            "title": title,
            "teamName": self._team_name,
            "description": description,
            "priority": self._map_priority_to_linear(priority.value),
            "stateName": "Todo",
        }

        if self._project_name:
            input_kwargs["projectName"] = self._project_name

        if assigned_to:
            assignee_id = self._resolve_user_name_to_id(assigned_to)
            if assignee_id:
                input_kwargs["assigneeId"] = assignee_id

        unresolved_labels: List[str] = []
        if tags:
            label_ids, unresolved_labels = self._resolve_label_names_to_ids(tags)
            if label_ids:
                input_kwargs["labelIds"] = label_ids

        issue_input = LinearIssueInput(**input_kwargs)
        issue: LinearIssue = await asyncio.to_thread(self._client.issues.create, issue_input)

        ticket = self._linear_issue_to_ticket(issue, [])
        if unresolved_labels:
            ticket.metadata["unresolved_labels"] = unresolved_labels
            ticket.metadata["available_labels"] = self.get_available_labels()
        logger.info(f"Created ticket: {ticket.id} - '{ticket.title}'")
        return ticket

    async def get_ticket(self, ticket_id: str) -> Optional[Ticket]:
        """Get ticket by ID or identifier from Linear."""
        await self._initialize_caches()
        logger.debug(f"Getting ticket: {ticket_id}")

        linear_id = self._resolve_ticket_identifier_to_id(ticket_id)

        try:
            issue: LinearIssue = await asyncio.to_thread(self._client.issues.get, linear_id)
        except Exception as e:
            logger.warning(f"Failed to get ticket {ticket_id}: {e}")
            return None

        if not issue:
            return None

        # Get comments as List[Dict[str, Any]] per protocol
        try:
            sdk_comments = await asyncio.to_thread(self._client.issues.get_comments, linear_id)
            comments: List[Dict[str, Any]] = [
                {
                    "author": c.user.displayName or c.user.name if c.user else "unknown",
                    "comment": c.body,
                    "created_at": c.createdAt.isoformat() if c.createdAt else "",
                    "metadata": {},
                }
                for c in sdk_comments
            ] if sdk_comments else []
        except Exception:
            comments = []

        return self._linear_issue_to_ticket(issue, comments)

    async def update_ticket(
        self,
        ticket_id: str,
        status: Optional[TicketStatus] = None,
        priority: Optional[TicketPriority] = None,
        assigned_to: Optional[str] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Ticket:
        """Update ticket fields in Linear."""
        logger.debug(f"Updating ticket {ticket_id}")
        await self._initialize_caches()

        linear_id = self._resolve_ticket_identifier_to_id(ticket_id)

        update_kwargs: Dict[str, Any] = {}

        if status is not None:
            update_kwargs["stateName"] = self._map_status_to_linear_state(status)
        if priority is not None:
            update_kwargs["priority"] = self._map_priority_to_linear(priority.value)
        if assigned_to is not None:
            assignee_id = self._resolve_user_name_to_id(assigned_to)
            if assignee_id:
                update_kwargs["assigneeId"] = assignee_id
        unresolved_labels: List[str] = []
        if tags is not None:
            label_ids, unresolved_labels = self._resolve_label_names_to_ids(tags)
            if label_ids:
                update_kwargs["labelIds"] = label_ids

        if not update_kwargs:
            raise ValueError("At least one field (status, priority, assigned_to, tags) must be provided to update")

        update_input = LinearIssueUpdateInput(**update_kwargs)
        issue: LinearIssue = await asyncio.to_thread(
            self._client.issues.update, linear_id, update_input
        )

        ticket = self._linear_issue_to_ticket(issue, [])
        if unresolved_labels:
            ticket.metadata["unresolved_labels"] = unresolved_labels
            ticket.metadata["available_labels"] = self.get_available_labels()
        logger.info(f"Updated ticket: {ticket.id} - '{ticket.title}'")
        return ticket

    async def add_comment(
        self,
        ticket_id: str,
        author: str,
        comment: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Ticket:
        """Add comment to ticket in Linear.

        Uses execute_graphql with commentCreate mutation since the SDK
        does not have a native create_comment method.

        Note: The ``metadata`` parameter is accepted for protocol compatibility
        but ignored — the Linear API does not support arbitrary metadata on comments.
        """
        logger.debug(f"Adding comment to ticket {ticket_id} by {author}")
        await self._initialize_caches()

        linear_id = self._resolve_ticket_identifier_to_id(ticket_id)
        body = f"[{author}] {comment}"

        await asyncio.to_thread(
            self._client.execute_graphql,
            COMMENT_CREATE_MUTATION,
            {"issueId": linear_id, "body": body},
        )

        # Return updated ticket
        updated_ticket = await self.get_ticket(ticket_id)
        if updated_ticket is None:
            raise ValueError(f"Ticket not found: {ticket_id}")
        logger.info(f"Added comment to ticket: {ticket_id}")
        return updated_ticket

    async def list_tickets(
        self,
        status: Optional[TicketStatus] = None,
        priority: Optional[TicketPriority] = None,
        assigned_to: Optional[str] = None,
        created_by: Optional[str] = None,
        tags: Optional[List[str]] = None,
        limit: Optional[int] = None,
    ) -> List[Ticket]:
        """List tickets from Linear with optional filtering."""
        logger.debug(f"Listing tickets: status={status}, priority={priority}, assigned_to={assigned_to}")
        await self._initialize_caches()

        if not self._team_name:
            logger.warning("No team name resolved, cannot list tickets")
            return []

        # Fetch all issues for the team
        issues_dict: Dict[str, LinearIssue] = await asyncio.to_thread(
            self._client.issues.get_by_team, self._team_name
        )

        # Apply local filters
        issues = list(issues_dict.values())

        if status is not None:
            target_state = self._map_status_to_linear_state(status)
            issues = [i for i in issues if i.state and i.state.name == target_state]

        if priority is not None:
            target_priority = self._map_priority_to_linear(priority.value)
            issues = [i for i in issues if i.priority == target_priority]

        if assigned_to is not None and assigned_to.strip():
            assignee_id = self._resolve_user_name_to_id(assigned_to)
            if assignee_id:
                issues = [i for i in issues if i.assignee and i.assignee.id == assignee_id]

        if created_by is not None and created_by.strip():
            creator_id = self._resolve_user_name_to_id(created_by)
            if creator_id:
                issues = [
                    i for i in issues
                    if hasattr(i, "creator") and i.creator and i.creator.id == creator_id
                ]

        if tags:
            tag_set = set(tags)
            issues = [
                i for i in issues
                if i.labels and tag_set.issubset({label.name for label in i.labels})
            ]

        # Filter out archived issues
        issues = [i for i in issues if not i.archivedAt]

        if limit is not None:
            issues = issues[:limit]

        tickets = [self._linear_issue_to_ticket(issue, []) for issue in issues]
        logger.info(f"Listed {len(tickets)} tickets")
        return tickets

    def get_agent_hints(self):
        """Get agent hints."""
        return dedent("""
#### Available Ticket States
    - "open"
    - "in_progress"
    - "blocked"
    - "in_review"
    - "backlog"
    - "completed"
    - "cancelled"

#### Available Ticket Priorities
    - "low"
    - "medium"
    - "high"
    - "urgent"

#### Creating Tickets
 - tickets are always created in 'Todo' state
 - create tickets as 'medium' priority unless otherwise specified

#### Listing Tickets
 - can filter by 'status' (Ticket State), 'priority' (Ticket Priority), 'assigned_to'
 - do not include 'assigned_to' arg unless specifically asked for tickets assigned to or owned by a user
 - if asked for any 'open' tickets, check 'open' AND 'backlog' status tickets

#### Updating Ticket State
 - use if you need to assign the ticket to a different user or change ticket state
 - e.g. from 'Todo' to In Progress)

#### Adding Comments to Tickets
 - do whenever you are providing status updates or asking for clarification

#### Tags / Labels
 - tags must match existing label names on the Linear team — arbitrary strings will be ignored
 - if you pass a tag that doesn't exist, the response will include `unresolved_labels` with the rejected names and `available_labels` with valid options
 - use `list_tickets` to see which tags are in use, or check the `available_labels` field in the response after a failed tag attempt
        """).strip()

    def close(self) -> None:
        """Close the Linear ticket storage."""
        logger.info("Closing Linear ticket storage")
