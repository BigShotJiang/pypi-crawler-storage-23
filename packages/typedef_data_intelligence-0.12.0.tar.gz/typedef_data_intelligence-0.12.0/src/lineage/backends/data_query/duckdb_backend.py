"""DuckDB implementation of DataQueryBackend."""
from __future__ import annotations

import asyncio
import logging
import re
import time
from typing import Any, List, Optional

import duckdb

from lineage.backends.config import DuckDBDataConfig
from lineage.backends.data_query.protocol import (
    ColumnProfile,
    JoinDiagnostics,
    KeyDiagnostics,
    QueryResult,
    QueryValidationResult,
    TablePreview,
    TableProfile,
    TableSchema,
)
from lineage.backends.lineage.models.semantic_views import NativeSemanticModelData
from lineage.backends.types import DataBackendType

logger = logging.getLogger(__name__)

# DuckDB functions/statements that can read/write the filesystem or execute OS commands.
# Function names are matched with word-boundary + open-paren to avoid false positives
# on identifiers like "copy_id" or "global_id".
_BLOCKED_FUNCTION_CALLS = frozenset({
    "read_csv", "read_csv_auto", "read_parquet", "read_json", "read_json_auto",
    "read_blob", "read_text",
    "write_csv", "write_parquet", "write_json",
    "export_database", "import_database",
    "load_extension", "install_extension",
    "http_get", "http_put",
    "glob", "read_ndjson", "read_ndjson_auto",
})

# Statement-level keywords matched as standalone words (not requiring parens).
_BLOCKED_STATEMENTS = frozenset({"copy", "httpfs"})

# Pre-compiled regex: matches function_name( or standalone statement keywords.
_BLOCKED_PATTERN = re.compile(
    r"\b(?:"
    + "|".join(re.escape(fn) for fn in sorted(_BLOCKED_FUNCTION_CALLS))
    + r")\s*\("
    + r"|\b(?:"
    + "|".join(re.escape(kw) for kw in sorted(_BLOCKED_STATEMENTS))
    + r")\b",
    re.IGNORECASE,
)
class DuckDBBackend:
    """DuckDB backend for data queries.

    Can connect to a DuckDB database file or use in-memory database.
    Supports querying dbt models that have been materialized.

    Supports restricting access to specific schemas or table patterns
    to enforce analyst vs engineer boundaries.

    All public async methods delegate to sync helpers via asyncio.to_thread
    to avoid blocking the event loop on disk I/O.
    """

    def __init__(
        self,
        duckdb_config: DuckDBDataConfig
    ):
        """Initialize DuckDB backend.

        Args:
            duckdb_config: DuckDB data configuration
        """
        self.db_path = duckdb_config.db_path
        self.read_only = duckdb_config.read_only
        self.allowed_schemas = duckdb_config.allowed_schemas
        self.allowed_table_patterns = duckdb_config.allowed_table_patterns

    class _Connection:
        """Context manager for short-lived DuckDB connections.

        Opens a connection on enter, closes on exit. This avoids holding
        a persistent lock on the database file, which would prevent dbt
        (or any other process) from writing to it between operations.
        """

        def __init__(self, db_path, read_only: bool):
            self._db_path = db_path
            self._read_only = read_only
            self._conn: Optional[duckdb.DuckDBPyConnection] = None

        def __enter__(self) -> duckdb.DuckDBPyConnection:
            if self._db_path:
                self._conn = duckdb.connect(str(self._db_path), read_only=self._read_only)
            else:
                self._conn = duckdb.connect(":memory:")
            return self._conn

        def __exit__(self, exc_type, exc_val, exc_tb):
            if self._conn:
                try:
                    self._conn.close()
                except Exception as e:
                    logger.warning("Error closing DuckDB connection: %s", e)
                self._conn = None

    def _connect(self) -> "_Connection":
        """Return a context manager that provides a short-lived DuckDB connection."""
        return self._Connection(self.db_path, self.read_only)

    @staticmethod
    def _quote_ident(name: str) -> str:
        """Escape a SQL identifier for safe use in DuckDB queries.

        Doubles any embedded double-quotes and wraps the result in double-quotes.
        """
        return '"' + name.replace('"', '""') + '"'

    def _qualified_name(self, database: str, schema: str, table: str) -> str:
        """Build a fully-qualified, safely-quoted table reference."""
        return f"{self._quote_ident(database)}.{self._quote_ident(schema)}.{self._quote_ident(table)}"

    def _is_table_allowed(self, database: str, schema: str, table: str) -> bool:
        """Check if a table is allowed based on configured restrictions.

        Args:
            database: Database name
            schema: Schema name
            table: Table name

        Returns:
            True if table is allowed, False otherwise
        """
        # If no restrictions, allow all
        if not self.allowed_schemas and not self.allowed_table_patterns:
            return True

        # Check schema allowlist
        if self.allowed_schemas and schema not in self.allowed_schemas:
            return False

        # Check table pattern allowlist
        if self.allowed_table_patterns:
            import fnmatch
            if not any(fnmatch.fnmatch(table, pattern) for pattern in self.allowed_table_patterns):
                return False

        return True

    @staticmethod
    def _validate_query_safety(query: str) -> None:
        """Reject queries that use blocked DuckDB functions (filesystem, HTTP, etc.).

        Uses word-boundary regex to avoid false positives on identifiers
        like ``copy_id`` or ``global_id``.

        Raises:
            PermissionError: If the query contains a blocked function call.
        """
        match = _BLOCKED_PATTERN.search(query)
        if match:
            token = match.group().strip().rstrip("(").strip()
            raise PermissionError(
                f"Query blocked: '{token}' is not allowed. "
                "File-system, HTTP, and extension functions are disabled for security."
            )

    def _validate_table_access(self, database: str, schema: str, table: str) -> None:
        """Validate that a table is allowed to be accessed.

        Raises:
            PermissionError: If table access is not allowed
        """
        if not self._is_table_allowed(database, schema, table):
            raise PermissionError(
                f"Access denied to {database}.{schema}.{table}. "
                f"Only mart tables are accessible. "
                f"If you need data from intermediate models, please create a data engineering ticket."
            )

    async def __aenter__(self):
        """Enter async context."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Exit async context."""
        pass

    # =========================================================================
    # Sync helpers (run in thread pool via asyncio.to_thread)
    # =========================================================================

    def _sync_execute_query(
        self,
        query: str,
        limit: Optional[int] = None,
    ) -> QueryResult:
        try:
            self._validate_query_safety(query)
            with self._connect() as conn:
                if limit:
                    query = f"SELECT * FROM ({query}) AS limited_query LIMIT {limit}"  # nosec B608

                start_time = time.time()
                cursor = conn.cursor()
                result = cursor.execute(query)
                execution_time = (time.time() - start_time) * 1000

                rows = result.fetchall()
                columns = [desc[0] for desc in result.description] if result.description else []
                cursor.close()

                return QueryResult(
                    columns=columns,
                    rows=rows,
                    row_count=len(rows),
                    execution_time_ms=execution_time,
                )
        except (PermissionError, duckdb.Error) as e:
            return QueryResult(
                columns=[],
                rows=[],
                row_count=0,
                error_message=str(e),
            )

    def _sync_get_table_schema(
        self,
        database: str,
        schema: str,
        table: str,
        conn: Optional[duckdb.DuckDBPyConnection] = None,
    ) -> TableSchema:
        """Get schema for a table. Optionally reuses an existing connection."""
        self._validate_table_access(database, schema, table)

        def _query(c: duckdb.DuckDBPyConnection) -> TableSchema:
            query = """
                SELECT
                    column_name,
                    data_type,
                    is_nullable,
                    column_default
                FROM information_schema.columns
                WHERE table_catalog = ?
                    AND table_schema = ?
                    AND table_name = ?
                ORDER BY ordinal_position
            """
            cursor = c.cursor()
            result = cursor.execute(query, [database, schema, table])
            rows = result.fetchall()
            cursor.close()

            columns = [
                {
                    "name": row[0],
                    "type": row[1],
                    "nullable": row[2] == "YES",
                    "default": row[3],
                }
                for row in rows
            ]

            return TableSchema(
                database_name=database,
                schema_name=schema,
                table_name=table,
                columns=columns,
            )

        if conn is not None:
            return _query(conn)
        with self._connect() as c:
            return _query(c)

    def _sync_preview_table(
        self,
        database: str,
        schema: str,
        table: str,
        limit: int = 10,
    ) -> TablePreview:
        self._validate_table_access(database, schema, table)

        with self._connect() as conn:
            table_schema = self._sync_get_table_schema(database, schema, table, conn=conn)

            qualified_name = self._qualified_name(database, schema, table)
            query = f"SELECT * FROM {qualified_name} LIMIT {limit}"  # nosec B608
            cursor = conn.cursor()
            result = cursor.execute(query)
            sample_rows = result.fetchall()
            cursor.close()

            count_cursor = conn.cursor()
            count_result = count_cursor.execute(f"SELECT COUNT(*) FROM {qualified_name}")  # nosec B608
            total_count = count_result.fetchone()[0] if count_result else None
            count_cursor.close()

            return TablePreview(
                table_schema=table_schema,
                sample_rows=sample_rows,
                total_row_count=total_count,
            )

    def _sync_list_databases(self) -> QueryResult:
        with self._connect() as conn:
            cursor = conn.cursor()
            result = cursor.execute("SELECT DISTINCT catalog_name FROM information_schema.schemata")
            databases = [row[0] for row in result.fetchall()]
            cursor.close()
            return QueryResult(
                columns=["name"],
                rows=[(db,) for db in databases],
                row_count=len(databases),
            )

    def _sync_list_schemas(self, database: str) -> QueryResult:
        with self._connect() as conn:
            cursor = conn.cursor()
            result = cursor.execute(
                "SELECT schema_name FROM information_schema.schemata WHERE catalog_name = ? ORDER BY schema_name",
                [database],
            )
            schemas = [row[0] for row in result.fetchall()]
            cursor.close()

            if self.allowed_schemas:
                schemas = [s for s in schemas if s in self.allowed_schemas]

            return QueryResult(
                columns=["name"],
                rows=[(s,) for s in schemas],
                row_count=len(schemas),
            )

    def _sync_list_tables(
        self,
        database: str,
        schema: str,
    ) -> QueryResult:
        with self._connect() as conn:
            cursor = conn.cursor()
            result = cursor.execute(
                """
                SELECT table_name
                FROM information_schema.tables
                WHERE table_catalog = ?
                    AND table_schema = ?
                    AND table_type = 'BASE TABLE'
                ORDER BY table_name
                """,
                [database, schema],
            )
            tables = [row[0] for row in result.fetchall()]
            cursor.close()

            if self.allowed_table_patterns:
                import fnmatch
                tables = [
                    t for t in tables
                    if any(fnmatch.fnmatch(t, pattern) for pattern in self.allowed_table_patterns)
                ]

            return QueryResult(
                columns=["name"],
                rows=[(t,) for t in tables],
                row_count=len(tables),
            )

    def _sync_get_query_plan(self, query: str) -> str:
        self._validate_query_safety(query)
        with self._connect() as conn:
            cursor = conn.cursor()
            result = cursor.execute(f"EXPLAIN {query}")
            rows = result.fetchall()
            cursor.close()
            return "\n".join(row[1] for row in rows)

    def _sync_profile_column(
        self,
        database: str,
        schema: str,
        table: str,
        column: str,
        sample_size: Optional[int] = None,
        top_k: int = 10,
        conn: Optional[duckdb.DuckDBPyConnection] = None,
        table_schema: Optional[TableSchema] = None,
    ) -> ColumnProfile:
        """Profile a single column. Optionally reuses an existing connection/schema."""
        self._validate_table_access(database, schema, table)

        def _run(c: duckdb.DuckDBPyConnection) -> ColumnProfile:
            ts = table_schema or self._sync_get_table_schema(database, schema, table, conn=c)
            return self._do_profile_column(c, ts, database, schema, table, column, sample_size, top_k)

        if conn is not None:
            return _run(conn)
        with self._connect() as c:
            return _run(c)

    def _do_profile_column(
        self,
        conn: duckdb.DuckDBPyConnection,
        table_schema: TableSchema,
        database: str,
        schema: str,
        table: str,
        column: str,
        sample_size: Optional[int] = None,
        top_k: int = 10,
    ) -> ColumnProfile:
        """Low-level column profiling against an open connection."""
        qualified_name = self._qualified_name(database, schema, table)
        col_quoted = self._quote_ident(column)

        col_info = next((c for c in table_schema.columns if c["name"] == column), None)
        if not col_info:
            raise ValueError(f"Column {column} not found in table {qualified_name}")

        data_type = col_info["type"]

        # Use a sampled subquery so USING SAMPLE doesn't conflict with WHERE clauses
        if sample_size:
            source = f"(SELECT * FROM {qualified_name} USING SAMPLE {sample_size}) AS _sample"  # nosec B608
        else:
            source = qualified_name

        base_stats_query = f"""
            SELECT
                COUNT(*) as total_count,
                COUNT({col_quoted}) as non_null_count,
                COUNT(*) - COUNT({col_quoted}) as null_count,
                COUNT(DISTINCT {col_quoted}) as distinct_count
            FROM {source}
        """

        cursor = conn.cursor()
        result = cursor.execute(base_stats_query)
        row = result.fetchone()
        cursor.close()

        total_count = row[0]
        non_null_count = row[1]
        null_count = row[2]
        distinct_count = row[3]
        null_percentage = (null_count / total_count * 100) if total_count > 0 else 0

        profile = ColumnProfile(
            column_name=column,
            data_type=data_type,
            distinct_count=distinct_count,
            null_count=null_count,
            null_percentage=round(null_percentage, 2),
        )

        is_numeric = any(t in data_type.upper() for t in [
            'INT', 'BIGINT', 'DOUBLE', 'FLOAT', 'DECIMAL', 'NUMERIC', 'REAL'
        ])
        is_string = any(t in data_type.upper() for t in ['VARCHAR', 'TEXT', 'CHAR', 'STRING'])
        is_temporal = any(t in data_type.upper() for t in ['DATE', 'TIMESTAMP', 'TIME'])

        try:
            if is_numeric:
                stats_query = f"""
                    SELECT
                        MIN({col_quoted}) as min_val,
                        MAX({col_quoted}) as max_val,
                        AVG(CAST({col_quoted} AS DOUBLE)) as avg_val,
                        STDDEV(CAST({col_quoted} AS DOUBLE)) as stddev_val
                    FROM {source}
                    WHERE {col_quoted} IS NOT NULL
                """
                cursor = conn.cursor()
                result = cursor.execute(stats_query)
                row = result.fetchone()
                cursor.close()

                if row:
                    profile.min_value = row[0]
                    profile.max_value = row[1]
                    profile.avg_value = round(float(row[2]), 2) if row[2] is not None else None
                    profile.stddev_value = round(float(row[3]), 2) if row[3] is not None else None

            elif is_temporal:
                # trunk-ignore(bandit/B608): internal query with validated table identifiers
                stats_query = f"""
                    SELECT
                        MIN({col_quoted}) as min_val,
                        MAX({col_quoted}) as max_val
                    FROM {source}
                    WHERE {col_quoted} IS NOT NULL
                """
                cursor = conn.cursor()
                result = cursor.execute(stats_query)
                row = result.fetchone()
                cursor.close()

                if row:
                    profile.min_value = row[0]
                    profile.max_value = row[1]

            elif is_string:
                str_stats_query = f"""
                    SELECT
                        MIN(LENGTH({col_quoted})) as min_len,
                        MAX(LENGTH({col_quoted})) as max_len,
                        AVG(LENGTH({col_quoted})) as avg_len
                    FROM {source}
                    WHERE {col_quoted} IS NOT NULL
                """
                cursor = conn.cursor()
                result = cursor.execute(str_stats_query)
                row = result.fetchone()
                cursor.close()

                if row:
                    profile.min_length = row[0]
                    profile.max_length = row[1]
                    profile.avg_length = round(float(row[2]), 2) if row[2] is not None else None

        except Exception as e:
            logger.warning(f"Failed to get type-specific statistics for column {column}: {e}")

        try:
            top_k_query = f"""
                SELECT
                    {col_quoted} as value,
                    COUNT(*) as count
                FROM {source}
                WHERE {col_quoted} IS NOT NULL
                GROUP BY {col_quoted}
                ORDER BY count DESC
                LIMIT {top_k}
            """
            cursor = conn.cursor()
            result = cursor.execute(top_k_query)
            rows = result.fetchall()
            cursor.close()

            profile.top_values = [
                {
                    "value": str(row[0]),
                    "count": row[1],
                    "percentage": round(row[1] / non_null_count * 100, 2) if non_null_count > 0 else 0,
                }
                for row in rows
            ]
        except Exception:
            profile.top_values = []

        return profile

    def _sync_profile_table(
        self,
        database: str,
        schema: str,
        table: str,
        sample_size: Optional[int] = None,
        top_k: int = 10,
        **kwargs: Any,
    ) -> TableProfile:
        from datetime import datetime, timezone

        self._validate_table_access(database, schema, table)

        # Single connection for the entire table profile (schema + count + all columns)
        with self._connect() as conn:
            table_schema = self._sync_get_table_schema(database, schema, table, conn=conn)
            qualified_name = self._qualified_name(database, schema, table)

            cursor = conn.cursor()
            result = cursor.execute(f"SELECT COUNT(*) FROM {qualified_name}")
            row_count = result.fetchone()[0]
            cursor.close()

            column_profiles = []
            for col_info in table_schema.columns:
                col_name = col_info["name"]
                try:
                    col_profile = self._sync_profile_column(
                        database, schema, table, col_name, sample_size, top_k,
                        conn=conn, table_schema=table_schema,
                    )
                    column_profiles.append(col_profile)
                except Exception as e:
                    logger.warning(f"Failed to profile column {col_name}: {e}")
                    column_profiles.append(ColumnProfile(
                        column_name=col_name,
                        data_type=col_info["type"],
                    ))

            return TableProfile(
                database_name=database,
                schema_name=schema,
                table_name=table,
                row_count=row_count,
                column_profiles=column_profiles,
                profile_timestamp=datetime.now(timezone.utc).isoformat(),
            )

    # =========================================================================
    # Public async API (protocol-conforming)
    # =========================================================================

    async def execute_query(
        self,
        query: str,
        limit: Optional[int] = None,
    ) -> QueryResult:
        """Execute a SQL query and return results."""
        return await asyncio.to_thread(self._sync_execute_query, query, limit)

    async def get_table_schema(
        self,
        database: str,
        schema: str,
        table: str,
    ) -> TableSchema:
        """Get schema information for a table."""
        return await asyncio.to_thread(self._sync_get_table_schema, database, schema, table)

    async def preview_table(
        self,
        database: str,
        schema: str,
        table: str,
        limit: int = 10,
    ) -> TablePreview:
        """Preview first N rows of a table."""
        return await asyncio.to_thread(self._sync_preview_table, database, schema, table, limit)

    async def list_databases(self) -> QueryResult:
        """List all available databases (catalogs in DuckDB)."""
        return await asyncio.to_thread(self._sync_list_databases)

    async def list_schemas(self, database: str) -> QueryResult:
        """List all schemas in a database."""
        return await asyncio.to_thread(self._sync_list_schemas, database)

    async def list_tables(
        self,
        database: str,
        schema: str,
    ) -> QueryResult:
        """List all tables in a schema."""
        return await asyncio.to_thread(self._sync_list_tables, database, schema)

    def validate_query(self, query: str) -> QueryValidationResult:
        """Validate a SQL query without executing it."""
        try:
            self._validate_query_safety(query)
        except PermissionError as e:
            return QueryValidationResult(valid=False, error_message=str(e))
        with self._connect() as conn:
            cursor = conn.cursor()
            try:
                cursor.execute(f"EXPLAIN {query}")
                cursor.close()
                return QueryValidationResult(valid=True)
            except Exception as e:
                cursor.close()
                return QueryValidationResult(valid=False, error_message=str(e))

    async def get_query_plan(self, query: str) -> str:
        """Get the execution plan for a query."""
        return await asyncio.to_thread(self._sync_get_query_plan, query)

    async def profile_column(
        self,
        database: str,
        schema: str,
        table: str,
        column: str,
        sample_size: Optional[int] = None,
        top_k: int = 10,
    ) -> ColumnProfile:
        """Profile a single column using DuckDB statistics."""
        return await asyncio.to_thread(
            self._sync_profile_column, database, schema, table, column, sample_size, top_k
        )

    async def profile_table(
        self,
        database: str,
        schema: str,
        table: str,
        sample_size: Optional[int] = None,
        top_k: int = 10,
        **kwargs: Any,
    ) -> TableProfile:
        """Profile all columns in a table using DuckDB statistics."""
        return await asyncio.to_thread(
            self._sync_profile_table, database, schema, table, sample_size, top_k
        )

    async def get_semantic_views(
        self,
        database: str,
        schema: str,
    ) -> List[NativeSemanticModelData]:
        """Get all native semantic models in a schema.

        DuckDB does not support semantic views, so this always returns
        an empty list.
        """
        return []

    def close(self) -> None:
        """No-op: connections are opened and closed per-operation."""
        pass

    def get_backend_type(self) -> DataBackendType:
        """Get the type of the data query backend."""
        return DataBackendType.DUCKDB

    def get_general_query_hints(self) -> str:
        """Get general DuckDB SQL syntax hints.

        Returns:
            DuckDB SQL dialect guide for general queries
        """
        return """
### Data Types
- Use `BIGINT`, `DOUBLE`, `VARCHAR`, `TIMESTAMP`, `BOOLEAN`, `DATE`
- Strings use single quotes: `'text'`
- Identifiers use double quotes: `"column_name"`, `"table_name"`

### String Functions
- Case-insensitive matching: `column ILIKE '%pattern%'`
- String concatenation: `string1 || string2` or `CONCAT(string1, string2)`
- Length: `LENGTH(string)`
- Substring: `SUBSTRING(string, start, length)`

### Date/Time Functions
- Current timestamp: `CURRENT_TIMESTAMP`
- Date parts: `DATE_PART('year', timestamp_col)` or `EXTRACT(YEAR FROM timestamp_col)`
- Date arithmetic: `date_col + INTERVAL '1 day'`
- Formatting: `STRFTIME(timestamp_col, '%Y-%m-%d')`

### Aggregations
- Common: `COUNT()`, `SUM()`, `AVG()`, `MIN()`, `MAX()`
- String aggregation: `STRING_AGG(column, ',')` or `LISTAGG(column, ',')`
- Array aggregation: `LIST(column)` returns array
- Distinct count: `COUNT(DISTINCT column)`

### Window Functions
- Fully supported: `ROW_NUMBER()`, `RANK()`, `DENSE_RANK()`, `LAG()`, `LEAD()`
- Use `OVER (PARTITION BY ... ORDER BY ...)`

### CTEs and Subqueries
- WITH clause (CTEs): Fully supported and recommended
- Example:
  ```sql
  WITH cte AS (
    SELECT * FROM table1
  )
  SELECT * FROM cte
  ```

### Joins
- All join types supported: `INNER JOIN`, `LEFT JOIN`, `RIGHT JOIN`, `FULL OUTER JOIN`
- Use explicit `ON` conditions

### LIMIT and OFFSET
- `LIMIT n` - return first n rows
- `LIMIT n OFFSET m` - skip m rows, return next n

### Boolean Logic
- Use `TRUE`, `FALSE`, `NULL`
- Boolean operators: `AND`, `OR`, `NOT`
- NULL handling: `IS NULL`, `IS NOT NULL`, `COALESCE(col, default_value)`

### Array/List Operations
- Create array: `LIST_VALUE(1, 2, 3)` or `[1, 2, 3]`
- Array access: `array_col[1]` (1-indexed!)
- Array length: `ARRAY_LENGTH(array_col)` or `LEN(array_col)`
- Unnest arrays: `UNNEST(array_col)`

### Important Quirks
- **Schema qualification**: Use `"database"."schema"."table"` format with double quotes
- **Case sensitivity**: Identifiers are case-insensitive unless quoted
- **Performance**: DuckDB is columnar - avoid `SELECT *`, specify columns
- **Sampling**: Use `USING SAMPLE 10%` for quick data exploration
- **UNION**: `UNION` (distinct) or `UNION ALL` (includes duplicates)

### Common Patterns
```sql
-- Ranked results
SELECT *, ROW_NUMBER() OVER (PARTITION BY category ORDER BY value DESC) as rank
FROM table
QUALIFY rank <= 10

-- Date filtering
SELECT * FROM table
WHERE date_col >= CURRENT_DATE - INTERVAL '30 days'

-- String aggregation by group
SELECT category, STRING_AGG(name, ', ' ORDER BY name) as names
FROM table
GROUP BY category
```
""".strip()

    def get_semantic_view_query_hints(self) -> str:
        """Get hints for querying semantic views.

        DuckDB does not support semantic views.

        Returns:
            Empty string (DuckDB doesn't support semantic views)
        """
        return ""

    def get_semantic_view_modification_hints(self) -> str:
        """Get hints for creating/modifying semantic views.

        DuckDB does not support semantic views.

        Returns:
            Empty string (DuckDB doesn't support semantic views)
        """
        return ""

    def validate_semantic_view_query(
        self,
        query: str,
        semantic_views: List[str],
    ) -> QueryValidationResult:
        """Validate semantic view query for DuckDB.

        DuckDB does not support semantic views, so this always returns an error.
        """
        return QueryValidationResult(
            valid=False,
            error_message="DuckDB does not support semantic views. "
                         "Semantic views are only available in data warehouses like Snowflake."
        )

    def get_agent_hints(self) -> str:
        """Get DuckDB-specific hints for AI agents writing SQL queries."""
        hints = "## DUCKDB SPECIFIC DATA BACKEND GUIDELINES\n\n"
        hints += "You are querying a **DuckDB** data warehouse.\n\n"

        if self.allowed_schemas:
            hints += "### Query Boundaries\n\n"
            hints += f"**Allowed schemas**: {', '.join(self.allowed_schemas)}\n\n"
            hints += "**IMPORTANT**: Only query tables in these schemas. "
            hints += "Do NOT waste turns probing other databases or schemas - they will return empty or error.\n\n"

        if self.allowed_table_patterns:
            hints += f"**Allowed table patterns**: {', '.join(self.allowed_table_patterns)}\n\n"

        hints += "Follow these DuckDB-specific guidelines:\n\n"
        hints += self.get_general_query_hints()
        return hints

    # =========================================================================
    # MCP Tool Delegation Methods (Not Supported in DuckDB)
    # =========================================================================

    async def list_semantic_views(
        self,
        database_name: Optional[str] = None,
        schema_name: Optional[str] = None,
        like: Optional[str] = None,
        starts_with: Optional[str] = None,
    ):
        """DuckDB does not support semantic views."""
        raise NotImplementedError(
            "DuckDB does not support semantic views. "
            "Use the data engineering agent to explore tables directly."
        )

    async def show_semantic_metrics(
        self,
        database_name: Optional[str] = None,
        schema_name: Optional[str] = None,
        view_name: Optional[str] = None,
        like: Optional[str] = None,
        starts_with: Optional[str] = None,
    ):
        """DuckDB does not support semantic views."""
        raise NotImplementedError(
            "DuckDB does not support semantic views. "
            "Use the data engineering agent to explore tables directly."
        )

    async def show_semantic_dimensions(
        self,
        database_name: Optional[str] = None,
        schema_name: Optional[str] = None,
        view_name: Optional[str] = None,
        like: Optional[str] = None,
        starts_with: Optional[str] = None,
    ):
        """DuckDB does not support semantic views."""
        raise NotImplementedError(
            "DuckDB does not support semantic views. "
            "Use the data engineering agent to explore tables directly."
        )

    async def query_semantic_view(
        self,
        view_name: str,
        database_name: str,
        schema_name: str,
        measures=None,
        dimensions=None,
        facts=None,
        where_clause: Optional[str] = None,
        order_by: Optional[str] = None,
        limit: Optional[int] = None,
    ):
        """DuckDB does not support semantic views."""
        raise NotImplementedError(
            "DuckDB does not support semantic views. "
            "Use the data engineering agent to explore tables directly."
        )

    async def get_semantic_view_ddl(
        self,
        database_name: str,
        schema_name: str,
        view_name: str,
    ) -> str:
        """DuckDB does not support semantic views."""
        raise NotImplementedError(
            "DuckDB does not support semantic views. "
            "Use the data engineering agent to explore tables directly."
        )

    async def run_key_diagnostics(
        self,
        database: str,
        schema: str,
        table: str,
        column: str,
    ) -> KeyDiagnostics:
        """Run statistical diagnostics for a key column in DuckDB."""
        self._validate_table_access(database, schema, table)
        qualified_name = self._qualified_name(database, schema, table)
        col_quoted = self._quote_ident(column)

        sql = f"""
        SELECT
            COUNT(*) as total_rows,
            COUNT(DISTINCT {col_quoted}) as distinct_keys,
            COUNT(*) - COUNT(DISTINCT {col_quoted}) as duplicate_keys,
            SUM(CASE WHEN {col_quoted} IS NULL THEN 1 ELSE 0 END) as null_keys
        FROM {qualified_name}
        """

        res = await self.execute_query(sql)
        if not res.rows:
            raise ValueError(f"No rows returned for key diagnostics on {qualified_name}")

        row = res.rows[0]
        return KeyDiagnostics(
            total_rows=int(row[0] or 0),
            distinct_keys=int(row[1] or 0),
            duplicate_keys=int(row[2] or 0),
            null_keys=int(row[3] or 0),
        )

    async def run_join_diagnostics(
        self,
        fact_db: str,
        fact_schema: str,
        fact_table: str,
        dim_db: str,
        dim_schema: str,
        dim_table: str,
        key_col: str,
    ) -> JoinDiagnostics:
        """Run referential integrity diagnostics for a join in DuckDB."""
        self._validate_table_access(fact_db, fact_schema, fact_table)
        self._validate_table_access(dim_db, dim_schema, dim_table)

        def _run() -> JoinDiagnostics:
            fact_qualified = self._qualified_name(fact_db, fact_schema, fact_table)
            dim_qualified = self._qualified_name(dim_db, dim_schema, dim_table)
            key_quoted = self._quote_ident(key_col)

            with self._connect() as conn:
                cursor = conn.cursor()

                cursor.execute(f"""
                    SELECT
                        COUNT(*) as fact_rows,
                        SUM(CASE WHEN d.{key_quoted} IS NULL AND f.{key_quoted} IS NOT NULL THEN 1 ELSE 0 END) as orphan_count
                    FROM {fact_qualified} f
                    LEFT JOIN {dim_qualified} d ON f.{key_quoted} = d.{key_quoted}
                """)
                orphan_row = cursor.fetchone()

                # trunk-ignore(bandit/B608): internal query with validated table identifiers
                cursor.execute(f"""
                    SELECT COUNT(*) as fanout_keys
                    FROM (
                        SELECT {key_quoted}
                        FROM {dim_qualified}
                        GROUP BY {key_quoted}
                        HAVING COUNT(*) > 1
                    ) AS subquery
                """)
                fanout_row = cursor.fetchone()
                cursor.close()

            if not orphan_row:
                raise ValueError("No rows returned for orphan check")

            fact_rows = int(orphan_row[0] or 0)
            orphan_count = int(orphan_row[1] or 0)
            orphan_rate = round(orphan_count / fact_rows, 4) if fact_rows > 0 else 0.0
            fanout_keys = int(fanout_row[0] or 0) if fanout_row else 0

            return JoinDiagnostics(
                fact_rows=fact_rows,
                orphan_count=orphan_count,
                orphan_rate=orphan_rate,
                fanout_keys=fanout_keys,
            )

        return await asyncio.to_thread(_run)
