"""FalkorDBLite adapter implementing LineageStorage protocol.

FalkorDBLite is an embedded Redis-based graph database with Cypher query support.
Key characteristics:
- File-backed (no network connection required)
- Cypher query language (with some limitations)
- Manual index creation required
- No regex support, no temporal arithmetic
- Self-contained Redis server with FalkorDB module
"""
from __future__ import annotations

import logging
import os

from lineage.backends.lineage._base_falkordb_adapter import _BaseFalkorDBAdapter

logger = logging.getLogger(__name__)

try:
    from redislite.falkordb_client import FalkorDB
except ImportError as exc:
    raise ImportError(
        "redislite and falkordb are required for FalkorDBLite backend. "
        "Install with: pip install redislite falkordb"
    ) from exc


class FalkorDBLiteAdapter(_BaseFalkorDBAdapter):
    """FalkorDBLite adapter implementing LineageStorage protocol.

    This adapter connects to FalkorDBLite (embedded file-backed graph database)
    and implements the minimal LineageStorage interface: upsert_node(),
    create_edge(), execute_raw_query().

    All specific node/edge operations are inherited from _BaseFalkorDBAdapter.

    FalkorDBLite-specific notes:
    - Uses file-backed storage (no network connection required)
    - Supports most Cypher syntax except regex and temporal functions
    - Requires manual index creation (no automatic indexing)
    - Properties are deleted with SET prop = NULL (not REMOVE)
    - Ideal for development, testing, prototyping, and educational purposes
    """

    def __init__(
        self,
        db_path: str = "lineage_store/falkordb.db",
        graph_name: str = "lineage",
        read_only: bool = False,
    ):
        """Initialize FalkorDBLite adapter.

        Args:
            db_path: Path to FalkorDBLite database file (will be created if doesn't exist)
            graph_name: Name of the graph to use
            read_only: If True, prevent write operations
        """
        super().__init__(graph_name=graph_name, read_only=read_only)

        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path

        # Create file-backed FalkorDBLite client
        self.client = FalkorDB(db_path)

        # Select graph
        self.graph = self.client.select_graph(graph_name)

        logger.info(
            f"Connected to FalkorDBLite at {db_path}, graph={graph_name} (read_only={read_only})"
        )

    def copy_graph(self, source_graph: str, dest_graph: str) -> None:
        """Copy a graph using GRAPH.COPY command.

        Creates an exact copy of the source graph with a new name.

        Args:
            source_graph: Name of the source graph to copy
            dest_graph: Name for the new copied graph

        Raises:
            ValueError: If adapter is in read-only mode or source graph doesn't exist
            RuntimeError: If the GRAPH.COPY command fails
        """
        if self.read_only:
            raise ValueError("Cannot copy graph in read-only mode")
        existing = self.list_graphs()
        if source_graph not in existing:
            raise ValueError(f"Source graph '{source_graph}' does not exist")
        try:
            self.client.connection.execute_command("GRAPH.COPY", source_graph, dest_graph)
        except Exception as e:
            raise RuntimeError(f"Failed to copy graph '{source_graph}' to '{dest_graph}': {e}") from e
        logger.info(f"Copied graph '{source_graph}' to '{dest_graph}'")

    def delete_graph(self, graph_name: str) -> None:
        """Delete a graph by name.

        Attempts the deletion directly and treats "unknown graph" errors as
        a no-op, avoiding a dependency on list_graphs() which silently
        returns an empty list on failure.

        Args:
            graph_name: Name of the graph to delete

        Raises:
            ValueError: If adapter is in read-only mode
        """
        if self.read_only:
            raise ValueError("Cannot delete graph in read-only mode")
        try:
            self.client.connection.execute_command("GRAPH.DELETE", graph_name)
            logger.info(f"Deleted graph '{graph_name}'")
        except Exception as e:
            err_msg = str(e).lower()
            if "empty key" in err_msg or "unknown graph" in err_msg:
                logger.warning(f"Graph '{graph_name}' does not exist, skipping delete")
            else:
                raise

    def close(self):
        """Close the FalkorDBLite client and shut down embedded Redis."""
        if self.client:
            try:
                # redislite.falkordb_client.FalkorDB wraps a redislite.Redis instance.
                # Calling shutdown() stops the embedded redis-server process immediately.
                self.client.close()
            except Exception as e:
                logger.warning(f"Failed to shut down FalkorDBLite embedded Redis: {e}")

        super().close()
