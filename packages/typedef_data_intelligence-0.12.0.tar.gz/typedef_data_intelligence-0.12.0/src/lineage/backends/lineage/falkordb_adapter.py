"""FalkorDB adapter implementing LineageStorage protocol.

FalkorDB is a Redis-based graph database with Cypher query support.
Key characteristics:
- Redis protocol (default port 6379)
- Cypher query language (with some limitations)
- Manual index creation required
- No regex support, no temporal arithmetic
"""
from __future__ import annotations

import logging
import time

import logfire

from lineage.backends.lineage._base_falkordb_adapter import _BaseFalkorDBAdapter

logger = logging.getLogger(__name__)

try:
    from falkordb import FalkorDB
except ImportError as exc:
    raise ImportError(
        "falkordb is required for FalkorDB backend. Install with: pip install falkordb"
    ) from exc

# Global Redis lock key used to serialize GRAPH.COPY operations.
# FalkorDB's fork mechanism cannot handle concurrent forks: each GRAPH.COPY forks
# a child process that dumps the source graph to /tmp/<uuid>.dump.  When two
# GRAPH.COPY operations overlap, the second fork fails with:
#     "Can't fork for module: File exists"
# A server-wide lock serializes these operations so only one fork runs at a time.
# Note: GRAPH.DELETE does not fork and does not need this lock.
_FORK_LOCK_KEY = "falkordb:fork_lock"
_FORK_LOCK_TIMEOUT = 120  # seconds
_FORK_LOCK_BLOCKING_TIMEOUT = 120  # seconds


class FalkorDBAdapter(_BaseFalkorDBAdapter):
    """FalkorDB adapter implementing LineageStorage protocol.

    This adapter connects to FalkorDB (Redis-based graph database) and implements
    the minimal LineageStorage interface: upsert_node(), create_edge(), execute_raw_query().

    All specific node/edge operations are inherited from _BaseFalkorDBAdapter.

    FalkorDB-specific notes:
    - Uses Redis protocol (default port 6379)
    - Supports most Cypher syntax except regex and temporal functions
    - Requires manual index creation (no automatic indexing)
    - Properties are deleted with SET prop = NULL (not REMOVE)
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        username: str = "td-data-intelligence",
        password: str = "",
        graph_name: str = "lineage",
        read_only: bool = False,
        socket_timeout: float | None = 300,
        socket_connect_timeout: float | None = 10,
    ):
        """Initialize FalkorDB adapter.

        Args:
            host: FalkorDB/Redis host
            port: FalkorDB/Redis port (default: 6379)
            username: Authentication username (default: "td-data-intelligence")
            password: Authentication password (empty string for no auth)
            graph_name: Name of the graph to use
            read_only: If True, prevent write operations
            socket_timeout: Timeout in seconds for socket reads/writes.
                Prevents indefinite blocking on dead TCP connections.
                Default 300s is generous for large Cypher writes (bulk
                upserts, GRAPH.COPY) while still bounding worst-case
                detection of dead connections.  All callers rely on this
                default; override only for short-lived probes.
            socket_connect_timeout: Timeout in seconds for initial TCP
                connection establishment.  Default 10s is sufficient for
                local and LAN deployments.  All callers rely on this
                default; override only for high-latency networks.
        """
        super().__init__(graph_name=graph_name, read_only=read_only)

        self.host = host
        self.port = port
        self.username = username
        self.password = password

        # Build connection kwargs
        kwargs: dict = {"host": host, "port": port}
        if username and password:
            kwargs.update(username=username, password=password)
        if socket_timeout is not None:
            kwargs["socket_timeout"] = socket_timeout
        if socket_connect_timeout is not None:
            kwargs["socket_connect_timeout"] = socket_connect_timeout

        self.client = FalkorDB(**kwargs)

        # Select graph
        self.graph = self.client.select_graph(graph_name)

        logger.info(
            f"Connected to FalkorDB at {host}:{port}, graph={graph_name} (read_only={read_only})"
        )

    def _acquire_fork_lock(self) -> object | None:
        """Acquire the global fork serialization lock.

        Returns:
            A Redis lock object if acquired, or None if locking failed
            (in which case the operation proceeds without the lock as a fallback).
        """
        logfire.info(
            "falkordb_fork_lock_acquiring",
            graph_name=self.graph_name,
        )
        try:
            lock = self.client.connection.lock(
                _FORK_LOCK_KEY,
                timeout=_FORK_LOCK_TIMEOUT,
                blocking_timeout=_FORK_LOCK_BLOCKING_TIMEOUT,
            )
            if lock.acquire():
                logfire.info(
                    "falkordb_fork_lock_acquired",
                    graph_name=self.graph_name,
                )
                return lock
            logfire.warn(
                "falkordb_fork_lock_timeout",
                graph_name=self.graph_name,
            )
            logger.warning("Failed to acquire fork lock (timeout), proceeding without lock")
            return None
        except Exception as e:
            logfire.warn(
                "falkordb_fork_lock_error",
                graph_name=self.graph_name,
                error=str(e),
            )
            logger.warning(f"Failed to acquire fork lock: {e}, proceeding without lock")
            return None

    @staticmethod
    def _release_fork_lock(lock: object | None) -> None:
        """Release the global fork serialization lock."""
        if lock is None:
            return
        try:
            lock.release()
            logfire.info("falkordb_fork_lock_released")
        except Exception as e:
            logfire.warn("falkordb_fork_lock_release_error", error=str(e))
            logger.warning(f"Failed to release fork lock: {e}")

    def copy_graph(
        self,
        source_graph: str,
        dest_graph: str,
        max_retries: int = 3,
    ) -> None:
        """Copy a graph using GRAPH.COPY command.

        Creates an exact copy of the source graph with a new name.
        Serialized via a global Redis lock to prevent concurrent forks
        that cause "Can't fork for module: File exists" errors.

        Retries with exponential backoff on "File exists" errors, which
        can still occur if a RediSearch GC fork is in-flight when the
        GRAPH.COPY fork is attempted.

        Args:
            source_graph: Name of the source graph to copy
            dest_graph: Name for the new copied graph
            max_retries: Maximum retry attempts on fork collision
        """
        lock = self._acquire_fork_lock()
        try:
            for attempt in range(max_retries + 1):
                try:
                    self.client.connection.execute_command(
                        "GRAPH.COPY", source_graph, dest_graph
                    )
                    # Brief pause after GRAPH.COPY to let FalkorDB finish
                    # cleaning up the /tmp dump file before another
                    # fork-based operation starts.
                    time.sleep(0.2)
                    break
                except Exception as e:
                    if "File exists" in str(e) and attempt < max_retries:
                        wait = 2 ** attempt
                        logger.warning(
                            f"GRAPH.COPY fork collision (attempt {attempt + 1}/"
                            f"{max_retries + 1}), retrying in {wait}s: {e}"
                        )
                        time.sleep(wait)
                    else:
                        raise
        finally:
            self._release_fork_lock(lock)
        logger.info(f"Copied graph '{source_graph}' to '{dest_graph}'")

    def delete_graph(self, graph_name: str) -> None:
        """Delete a graph by name.

        Attempts the deletion directly and treats "unknown graph" errors as
        a no-op, avoiding a dependency on list_graphs() which silently
        returns an empty list on failure.

        Args:
            graph_name: Name of the graph to delete

        Raises:
            ValueError: If adapter is in read-only mode
        """
        if self.read_only:
            raise ValueError("Cannot delete graph in read-only mode")
        try:
            self.client.connection.execute_command("GRAPH.DELETE", graph_name)
            logger.info(f"Deleted graph '{graph_name}'")
        except Exception as e:
            err_msg = str(e).lower()
            if "empty key" in err_msg or "unknown graph" in err_msg:
                logger.warning(f"Graph '{graph_name}' does not exist, skipping delete")
            else:
                raise

    def rename_graph(self, source_name: str, dest_name: str) -> None:
        """Atomically promote a graph by renaming it.

        Deletes ``dest_name`` if it already exists, then uses Redis
        ``RENAME`` to move ``source_name`` → ``dest_name``.  The
        ``RENAME`` command is O(1) and atomic.

        Note: ``GRAPH.DELETE`` does not fork, so no fork lock is needed.

        Args:
            source_name: Current graph key (e.g. ``foo__building``).
            dest_name: Target graph key (e.g. ``foo``).
        """
        existing = self.list_graphs()
        if source_name not in existing:
            raise ValueError(
                f"Source graph '{source_name}' does not exist, "
                f"cannot rename to '{dest_name}'"
            )
        if dest_name in existing:
            self.delete_graph(dest_name)
        self.client.connection.rename(source_name, dest_name)
        logger.info(f"Renamed graph '{source_name}' -> '{dest_name}'")
