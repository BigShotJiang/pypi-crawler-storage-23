"""Shared base class for FalkorDB and FalkorDBLite adapters.

This module contains all shared logic between the network-based FalkorDB adapter
and the file-backed FalkorDBLite adapter. The only differences between the two
implementations are in connection initialization.

Both adapters use the same graph API after initialization, so all operations
(upsert_node, create_edge, execute_raw_query, etc.) are identical.
"""
from __future__ import annotations

import json
import logging
import traceback
from typing import Any, Callable, Dict, List, Optional, Union

from falkordb.falkordb import FalkorDB
from falkordb.graph import Graph
from redis.exceptions import BusyLoadingError, ResponseError
from redislite.falkordb_client import FalkorDB as FalkorDBLite
from redislite.falkordb_client import Graph as GraphLite

from lineage.backends.lineage.base import BaseLineageStorage
from lineage.backends.lineage.models.base import BaseNode, GraphEdge, NodeIdentifier
from lineage.backends.lineage.models.clustering import (
    ClusterAnalysis,
)
from lineage.backends.lineage.protocol import (
    DatasetNode,
    JobNode,
    RawLineageQueryResult,
)
from lineage.backends.lineage.schema_loader import load_schema

logger = logging.getLogger(__name__)

# Maximum time (seconds) to wait for Redis to finish loading its dataset after a restart.
REDIS_READY_TIMEOUT_SECONDS = 30


class _BaseFalkorDBAdapter(BaseLineageStorage):
    """Shared base class for FalkorDB and FalkorDBLite adapters.

    This base class contains all shared logic. Subclasses only need to
    implement __init__() to set up the client and graph connections.

    FalkorDB-specific notes:
    - Supports most Cypher syntax except regex and temporal functions
    - Requires manual index creation (no automatic indexing)
    - Properties are deleted with SET prop = NULL (not REMOVE)
    """

    def __init__(self, graph_name: str, read_only: bool, max_retries: int = 2):
        """Initialize base FalkorDB adapter.

        Subclasses should call super().__init__() then set self.client and self.graph.

        Args:
            graph_name: Name of the graph to use
            read_only: If True, prevent write operations
            max_retries: Maximum retries for transient query failures (default: 2).
                Must be at least 1 to ensure at least one attempt is made.

        Raises:
            ValueError: If max_retries is less than 1
        """
        if max_retries < 1:
            raise ValueError(f"max_retries must be at least 1, got {max_retries}")
        self.graph_name = graph_name
        self.read_only = read_only
        self.max_retries = max_retries
        # Subclasses must set these:
        self.client: FalkorDB | FalkorDBLite = None
        self.graph: Graph | GraphLite = None

    def close(self):
        """Close the FalkorDB client connection."""
        if hasattr(self, "client") and self.client:
            # FalkorDB client connection cleanup
            # The client uses Redis connection underneath
            logger.info("FalkorDB connection closed")

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()

    # ------------------------------------------------------------------
    # Redis Background Save Guard
    # ------------------------------------------------------------------

    def disable_background_saves(self) -> None:
        """Disable Redis background saves (RDB snapshots).

        Runs ``CONFIG SET save ""`` to prevent ``BGSAVE`` forks during heavy
        write operations.  The original save policy is stored so it can be
        restored later via :meth:`restore_background_saves`.

        Re-entrant: nested calls increment a depth counter and only the
        outermost pair actually touches Redis CONFIG.

        This is critical for FalkorDB because ``GRAPH.COPY`` creates dump
        files in ``/tmp/`` and the default Redis save policy (e.g.
        ``save 3600 1 300 100 60 10000``) triggers background forks that
        collide with those dump files, producing
        ``Can't fork for module: File exists`` errors.
        """
        depth = getattr(self, "_save_guard_depth", 0)
        if depth > 0:
            # Already disabled by an outer caller — just bump the counter.
            self._save_guard_depth = depth + 1
            return

        try:
            raw = self.client.connection.execute_command("CONFIG", "GET", "save")
            # raw is a list like [b'save', b'3600 1 300 100 60 10000']
            if raw and len(raw) >= 2:
                self._original_save_config = raw[1]
                if isinstance(self._original_save_config, bytes):
                    self._original_save_config = self._original_save_config.decode()
            else:
                self._original_save_config = ""
            self.client.connection.execute_command("CONFIG", "SET", "save", "")
            self._save_guard_depth = 1
            logger.info("Disabled Redis background saves for bulk write operation")
        except Exception as e:
            logger.warning(f"Failed to disable Redis background saves: {e}")
            self._original_save_config = None
            self._save_guard_depth = 0

    def restore_background_saves(self) -> None:
        """Restore the Redis background save policy stored by :meth:`disable_background_saves`.

        Re-entrant: only the outermost restore actually touches Redis CONFIG.
        No-op if saves were never disabled or if the original config is unknown.
        """
        depth = getattr(self, "_save_guard_depth", 0)
        if depth > 1:
            self._save_guard_depth = depth - 1
            return
        if depth == 0:
            return

        original = getattr(self, "_original_save_config", None)
        self._save_guard_depth = 0
        if original is None:
            return
        try:
            self.client.connection.execute_command("CONFIG", "SET", "save", original)
            logger.info("Restored Redis background saves")
        except Exception as e:
            logger.warning(f"Failed to restore Redis background saves: {e}")
        finally:
            self._original_save_config = None

    # ------------------------------------------------------------------
    # Schema Management
    # ------------------------------------------------------------------

    def ensure_schema(self) -> None:
        """Create property indexes and drop any existing fulltext indexes.

        FalkorDB requires manual index creation (no automatic indexing).
        Unlike Neo4j, FalkorDB may not support unique constraints, so we
        create regular indexes on ID properties.

        This method also DROPS any existing fulltext indexes to prevent a
        race condition during subsequent writes. RediSearch maintains a
        background indexer thread that updates fulltext indexes when nodes
        are written. This background thread races with the foreground write
        thread, triggering a SIGABRT crash:
            RediSearch_LockWrite: Assertion 'rwData->type != lockType_Read' failed
        This can happen when fulltext indexes are inherited via GRAPH.COPY
        or left over from a previous load. Dropping them here ensures writes
        are safe. Call ensure_fulltext_indexes() after all writes complete
        to recreate them.
        """
        if self.read_only:
            logger.warning("Cannot ensure schema in read-only mode")
            return

        # Drop fulltext indexes first — they may exist from GRAPH.COPY or a
        # previous load, and their background indexer races with writes.
        self.drop_fulltext_indexes()

        indexes = [
            # Logical dbt node indexes
            "CREATE INDEX FOR (n:DbtModel) ON (n.id)",
            "CREATE INDEX FOR (n:DbtSource) ON (n.id)",
            "CREATE INDEX FOR (n:DbtColumn) ON (n.id)",
            # Physical warehouse node indexes
            "CREATE INDEX FOR (n:PhysicalTable) ON (n.id)",
            "CREATE INDEX FOR (n:PhysicalView) ON (n.id)",
            "CREATE INDEX FOR (n:PhysicalMaterializedView) ON (n.id)",
            "CREATE INDEX FOR (n:PhysicalColumn) ON (n.id)",
            # OpenLineage node indexes
            "CREATE INDEX FOR (n:Job) ON (n.id)",
            "CREATE INDEX FOR (n:Dataset) ON (n.id)",
            "CREATE INDEX FOR (n:Run) ON (n.id)",
            "CREATE INDEX FOR (n:Error) ON (n.id)",
            # Inferred semantic node indexes (LLM-derived)
            "CREATE INDEX FOR (n:InferredSemanticModel) ON (n.id)",
            "CREATE INDEX FOR (n:InferredMeasure) ON (n.id)",
            "CREATE INDEX FOR (n:InferredDimension) ON (n.id)",
            "CREATE INDEX FOR (n:InferredFact) ON (n.id)",
            "CREATE INDEX FOR (n:InferredSegment) ON (n.id)",
            "CREATE INDEX FOR (n:TimeWindow) ON (n.id)",
            "CREATE INDEX FOR (n:TimeAttribute) ON (n.id)",
            "CREATE INDEX FOR (n:JoinEdge) ON (n.id)",
            "CREATE INDEX FOR (n:WindowFunction) ON (n.id)",
            # Native semantic node indexes (warehouse-declared)
            "CREATE INDEX FOR (n:NativeSemanticModel) ON (n.id)",
            "CREATE INDEX FOR (n:NativeMeasure) ON (n.id)",
            "CREATE INDEX FOR (n:NativeDimension) ON (n.id)",
            "CREATE INDEX FOR (n:NativeFact) ON (n.id)",
            "CREATE INDEX FOR (n:NativeBaseTable) ON (n.id)",
            # Clustering and profiling node indexes
            "CREATE INDEX FOR (n:InferredSubjectArea) ON (n.cluster_id)",
            "CREATE INDEX FOR (n:TableProfile) ON (n.id)",
            "CREATE INDEX FOR (n:ColumnProfile) ON (n.id)",
            # Other node indexes
            "CREATE INDEX FOR (n:DataRequestTicket) ON (n.id)",
            # Additional indexes for commonly queried properties
            "CREATE INDEX FOR (n:DbtModel) ON (n.name)",
            "CREATE INDEX FOR (n:DbtSource) ON (n.name)",
            "CREATE INDEX FOR (n:PhysicalTable) ON (n.name)",
            "CREATE INDEX FOR (n:PhysicalView) ON (n.name)",
            "CREATE INDEX FOR (n:Job) ON (n.name)",
            "CREATE INDEX FOR (n:Run) ON (n.status)",
        ]

        for index in indexes:
            try:
                self.graph.query(index)
                logger.debug(f"Created index: {index[:60]}...")
            except Exception as e:
                # Index may already exist
                logger.debug(f"Index creation skipped (may exist): {e}")

        logger.info("Schema ensured: property indexes created")

    def ensure_fulltext_indexes(self) -> None:
        """Create full-text indexes from schema.yaml definitions.

        Fulltext indexes enable semantic search over node properties like
        name, description, compiled_sql, etc.

        IMPORTANT: Call this only after all bulk writes are complete.
        RediSearch maintains a background indexer thread that races with
        foreground write operations, causing a SIGABRT crash:
            RediSearch_LockWrite: Assertion 'rwData->type != lockType_Read' failed
        By deferring fulltext index creation until after writes finish,
        the background indexer only processes already-written data with
        no concurrent write contention.

        Each createNodeIndex call triggers asynchronous background indexing.
        A short delay between calls prevents the background indexer from one
        index creation from racing with the next createNodeIndex call (same
        RediSearch lock assertion). With ~100K nodes the total overhead of
        indexing + inter-index delays is ~1-5 seconds.
        """
        import time

        try:
            schema = load_schema()
        except Exception as e:
            logger.error(f"Failed to load schema for fulltext indexes: {e}")
            return

        # Get existing fulltext indexes
        existing_ft_labels = set()
        try:
            result = self.graph.query("CALL db.indexes()")
            for row in result.result_set:
                # row[0] is label, row[2] is field types dict where FULLTEXT indicates fulltext
                if row and len(row) > 2:
                    label = row[0]
                    field_types = row[2]  # OrderedDict like {'name': ['FULLTEXT'], ...}
                    # Check if any field has FULLTEXT type
                    has_fulltext = any(
                        'FULLTEXT' in types
                        for types in field_types.values()
                        if isinstance(types, list)
                    )
                    if has_fulltext:
                        existing_ft_labels.add(label)
        except Exception as e:
            logger.warning(f"Could not check existing indexes: {e}")

        created_count = 0
        skipped_count = 0

        for node_name, node_def in schema.get("nodes", {}).items():
            ft_cfg = node_def.get("fulltext_index")
            if not ft_cfg:
                continue

            fields = ft_cfg.get("fields") or []
            if not fields:
                continue

            # Skip if fulltext index already exists for this label
            if node_name in existing_ft_labels:
                logger.debug(f"Fulltext index already exists for {node_name}")
                skipped_count += 1
                continue

            # Brief pause between index creations to let the RediSearch background
            # indexer from the previous createNodeIndex call finish. Without this,
            # the background thread holding a read lock races with the next
            # createNodeIndex needing a write lock (same SIGABRT crash).
            if created_count > 0:
                time.sleep(0.1)

            # Build the query with proper quoting
            fields_str = ", ".join(repr(f) for f in fields)
            ft_query = f"CALL db.idx.fulltext.createNodeIndex('{node_name}', {fields_str})"

            try:
                self.graph.query(ft_query)
                created_count += 1
                logger.info(f"Created fulltext index for {node_name} on fields: {fields}")
            except Exception as e:
                error_msg = str(e).lower()
                if "already exist" in error_msg or "duplicate" in error_msg:
                    logger.debug(f"Fulltext index already exists for {node_name}")
                    skipped_count += 1
                else:
                    logger.error(f"Failed to create fulltext index for {node_name}: {e}")

        logger.info(
            f"Fulltext indexes: {created_count} created, {skipped_count} already existed"
        )

    def list_fulltext_indexes(self) -> list[dict]:
        """List all fulltext indexes in the graph.

        Returns:
            List of dicts with 'label' and 'fields' keys
        """
        indexes = []
        try:
            result = self.graph.query("CALL db.indexes()")
            for row in result.result_set:
                if row and len(row) > 2:
                    label = row[0]
                    fields = row[1] if len(row) > 1 else []
                    field_types = row[2] if len(row) > 2 else {}

                    # Check if this is a fulltext index
                    has_fulltext = any(
                        'FULLTEXT' in types
                        for types in field_types.values()
                        if isinstance(types, list)
                    )
                    if has_fulltext:
                        indexes.append({
                            "label": label,
                            "fields": fields,
                        })
        except Exception as e:
            logger.error(f"Failed to list fulltext indexes: {e}")

        return indexes

    def drop_fulltext_indexes(self) -> None:
        """Drop all fulltext indexes from the current graph.

        Called by ensure_schema() before writes to eliminate the race
        condition between RediSearch's background indexer thread and
        foreground write operations. Fulltext indexes may be present from
        GRAPH.COPY (which copies indexes from the source) or from a
        previous ensure_fulltext_indexes() call.
        """
        ft_indexes = self.list_fulltext_indexes()
        if not ft_indexes:
            return

        dropped = 0
        for idx in ft_indexes:
            label = idx["label"]
            try:
                self.graph.query(f"CALL db.idx.fulltext.drop('{label}')")
                dropped += 1
            except Exception as e:
                error_msg = str(e).lower()
                if "no such index" in error_msg or "does not exist" in error_msg:
                    logger.debug(f"Fulltext index for {label} already dropped")
                else:
                    logger.warning(f"Failed to drop fulltext index for {label}: {e}")

        if dropped:
            logger.info(f"Dropped {dropped} fulltext indexes before writes")

    def recreate_schema(self) -> None:
        """Drop all data and recreate indexes.

        WARNING: This destroys all data in the graph!
        """
        if self.read_only:
            raise ValueError("Cannot recreate schema in read-only mode")

        # Delete all nodes and relationships (if graph exists)
        # Retry if Redis is still loading its dataset after a restart.
        logger.warning("Deleting all nodes and relationships...")
        import time
        poll_interval = 1
        max_attempts = max(1, REDIS_READY_TIMEOUT_SECONDS // poll_interval)
        for attempt in range(max_attempts):
            try:
                self.graph.delete()
                break
            except BusyLoadingError:
                logger.info(
                    f"Redis is loading dataset into memory, waiting... "
                    f"(attempt {attempt + 1}/{max_attempts})"
                )
                time.sleep(poll_interval)
            except ResponseError as e:
                # FalkorDB returns "Invalid graph operation on empty key" when the graph
                # does not yet exist. For test setups, we want recreate_schema() to be
                # idempotent and treat that as a no-op.
                if "Invalid graph operation on empty key" not in str(e):
                    raise
                logger.debug("Graph doesn't exist yet, will create fresh")
                break
        else:
            raise BusyLoadingError(
                f"Redis still loading after {REDIS_READY_TIMEOUT_SECONDS} seconds"
            )

        # Re-initialize graph object after deletion to ensure it references
        # a fresh graph instance (FalkorDB auto-creates graphs on first query,
        # but we need to re-select it to avoid stale state)
        self.graph = self.client.select_graph(self.graph_name)

        # Recreate indexes (property + fulltext safe here — no concurrent writes)
        self.ensure_schema()
        self.ensure_fulltext_indexes()
        logger.info("Schema recreated successfully")

    def set_active_graph(self, graph_name: str, ensure_schema: bool = True) -> None:
        """Switch to a different graph within the same FalkorDB instance.

        Creates property indexes on the new graph but NOT fulltext indexes.
        Call ensure_fulltext_indexes() after all writes complete to avoid
        the RediSearch background indexer race condition.

        Args:
            graph_name: Name of the graph to switch to
            ensure_schema: If True and not read_only, ensure property indexes exist.
        """
        self.graph_name = graph_name
        self.graph = self.client.select_graph(graph_name)
        logger.info(f"Switched to graph: {graph_name}")

        # Ensure schema (indexes) exist on the new graph
        if ensure_schema and not self.read_only:
            self.ensure_schema()

    def list_graphs(self) -> list[str]:
        """List all graphs in the FalkorDB instance.

        Returns:
            List of graph names in the database
        """
        # FalkorDB stores graph names in a Redis key pattern
        # We can use KEYS command to list them
        try:
            # FalkorDB graph names are stored with prefix "graph:"
            return self.client.list_graphs()
        except Exception as e:
            logger.warning(f"Could not list graphs: {e}")
            return []

    # ========================================================================
    # CORE GENERIC METHODS
    # ========================================================================

    def upsert_node(
        self,
        node: BaseNode,
    ) -> None:
        """Generic node upsert - works for ALL node types.

        Args:
            node: Pydantic BaseNode with node_label and computed id
        """
        if self.read_only:
            raise ValueError("Cannot write in read-only mode")
        # Extract label, id, and properties from the node
        label = node.node_label.value
        id = node.id
        # Use mode='json' to serialize datetime objects to ISO strings
        properties = node.model_dump(mode='json')

        # Filter out None values
        properties = {k: v for k, v in properties.items() if v is not None}

        # Build Cypher MERGE query
        # FalkorDB uses SET prop = NULL instead of REMOVE for property deletion
        params = {"id": id}
        set_clauses = []

        for key, value in properties.items():
            param_key = f"prop_{key}"
            params[param_key] = self._normalize_value(value)
            set_clauses.append(f"n.{key} = ${param_key}")

        set_clause = ", ".join(set_clauses) if set_clauses else ""

        if set_clause:
            query = f"""
            MERGE (n:{label} {{id: $id}})
            ON CREATE SET {set_clause}
            ON MATCH SET {set_clause}
            """
        else:
            query = f"""
            MERGE (n:{label} {{id: $id}})
            """

        self._execute_query(query, params)

    def create_edge(
        self,
        from_node: Union[BaseNode, NodeIdentifier],
        to_node: Union[BaseNode, NodeIdentifier],
        edge: GraphEdge,
    ) -> None:
        """Generic edge creation - works for ALL edge types.

        Args:
            from_node: Source node (BaseNode or NodeIdentifier)
            to_node: Target node (BaseNode or NodeIdentifier)
            edge: GraphEdge with edge_type and properties
        """
        if self.read_only:
            raise ValueError("Cannot write in read-only mode")

        # Extract IDs and labels from nodes/identifiers
        if isinstance(from_node, BaseNode):
            from_id = from_node.id
            from_label = from_node.node_label
        else:
            from_id = from_node.id
            from_label = from_node.node_label

        if isinstance(to_node, BaseNode):
            to_id = to_node.id
            to_label = to_node.node_label
        else:
            to_id = to_node.id
            to_label = to_node.node_label

        # Extract edge type and properties
        edge_type = edge.edge_type.value
        # Use mode='json' to serialize datetime objects to ISO strings
        properties = edge.model_dump(mode='json')

        # Filter None values
        properties = {k: v for k, v in properties.items() if v is not None}

        # Build Cypher query
        params = {"from_id": from_id, "to_id": to_id}

        # Build merge key predicates from edge's merge_keys (if any).
        # This allows parallel edges of the same type between the same node pair
        # when they differ by merge key properties (e.g., column_name).
        merge_key_props = {}
        for key in getattr(edge, "merge_keys", ()):
            val = getattr(edge, key, None)
            if val is not None:
                param_key = f"mk_{key}"
                params[param_key] = self._normalize_value(val)
                merge_key_props[key] = f"${param_key}"

        if merge_key_props:
            merge_clause = ", ".join(f"{k}: {v}" for k, v in merge_key_props.items())
            merge_pattern = f" {{{merge_clause}}}"
        else:
            merge_pattern = ""

        # Use MERGE to avoid duplicate relationships
        query = f"""
        MATCH (a:{from_label.value} {{id: $from_id}}), (b:{to_label.value} {{id: $to_id}})
        MERGE (a)-[r:{edge_type}{merge_pattern}]->(b)
        """

        # Add properties if they exist
        if properties:
            set_clauses = []
            for key, value in properties.items():
                param_key = f"prop_{key}"
                params[param_key] = self._normalize_value(value)
                set_clauses.append(f"r.{key} = ${param_key}")
            set_clause = ", ".join(set_clauses)
            query += f"\nON CREATE SET {set_clause}\nON MATCH SET {set_clause}"

        self._execute_query(query, params)

    def _batch_upsert_nodes(self, label: str, node_props_list: list[dict[str, Any]]) -> None:
        """Upsert nodes one-by-one using individual MERGE queries.

        NOTE: UNWIND batching for nodes has been intentionally backed out due to
        FalkorDB/FalkorDB#1240 — a concurrency bug where FalkorDB's module-level
        forks (for persistence) race with write operations, causing SIGSEGV.
        UNWIND queries run longer than individual MERGEs, widening the window for
        a fork collision. Individual MERGE queries are sub-millisecond.

        TODO: Re-enable UNWIND batching for nodes once FalkorDB/FalkorDB#1240 is
        fixed upstream. The UNWIND+COALESCE implementation is in git history.

        Args:
            label: Node label (e.g., "DbtModel")
            node_props_list: List of property dicts, each must contain an "id" key

        Raises:
            Exception: Re-raised if node creation fails.
        """
        if not node_props_list:
            return

        for props in node_props_list:
            node_id = props.get("id")
            params: dict[str, Any] = {"id": node_id}
            set_clauses = []
            for key, value in props.items():
                if key == "id":
                    continue
                param_key = f"prop_{key}"
                params[param_key] = self._normalize_value(value)
                set_clauses.append(f"n.{key} = ${param_key}")
            if set_clauses:
                set_clause = ", ".join(set_clauses)
                query = (
                    f"MERGE (n:{label} {{id: $id}}) "
                    f"ON CREATE SET {set_clause} "
                    f"ON MATCH SET {set_clause}"
                )
            else:
                query = f"MERGE (n:{label} {{id: $id}})"
            self._execute_query(query, params)

    def _create_edges_individually(
        self,
        from_label: str,
        to_label: str,
        edge_type: str,
        edge_batch: list[dict[str, Any]],
    ) -> None:
        """Create edges one-by-one using individual MERGE queries.

        NOTE: UNWIND batching for edges has been intentionally backed out due to
        FalkorDB/FalkorDB#1240 — a concurrency bug where FalkorDB's module-level
        forks (for persistence) race with write operations, causing SIGSEGV in
        Record_GetType. The UNWIND+MERGE pattern for edges creates longer-running
        queries that widen the window for a fork collision. Individual MERGE queries
        are sub-millisecond, so ~40K edges complete in ~40s and the shorter execution
        window makes fork collisions effectively impossible.

        Also related: FalkorDB/FalkorDB#238 — the exact UNWIND...MATCH...MERGE
        query shape causing segfaults, reported since RedisGraph and still open.

        TODO: Re-enable UNWIND batching once FalkorDB/FalkorDB#1240 is fixed
        upstream. Both node and edge UNWIND implementations are in git history.

        Args:
            from_label: Source node label
            to_label: Target node label
            edge_type: Relationship type (e.g., "DEPENDS_ON")
            edge_batch: List of dicts with from_id, to_id, and props keys

        Raises:
            Exception: Re-raised if edge creation fails.
        """
        if not edge_batch:
            return

        for row in edge_batch:
            params: dict[str, Any] = {"from_id": row["from_id"], "to_id": row["to_id"]}
            props = row.get("props", {})
            query = (
                f"MATCH (a:{from_label} {{id: $from_id}}), (b:{to_label} {{id: $to_id}}) "
                f"MERGE (a)-[r:{edge_type}]->(b)"
            )
            if props:
                set_clauses = []
                for key, value in props.items():
                    param_key = f"prop_{key}"
                    params[param_key] = self._normalize_value(value)
                    set_clauses.append(f"r.{key} = ${param_key}")
                set_clause = ", ".join(set_clauses)
                query += f"\nON CREATE SET {set_clause}\nON MATCH SET {set_clause}"
            self._execute_query(query, params)

    def bulk_load(
        self,
        nodes: List[BaseNode],
        edges: List[tuple[BaseNode | NodeIdentifier, BaseNode | NodeIdentifier, GraphEdge]],
        progress_callback: Optional[Callable[[int, int, str], None]] = None,
        batch_size: int = 500,
    ) -> None:
        """Load nodes and edges into storage.

        Both nodes and edges use individual MERGE queries due to
        FalkorDB/FalkorDB#1240 — see _batch_upsert_nodes and
        _create_edges_individually for details.

        Args:
            nodes: List of all node Pydantic objects
            edges: List of (from_node, to_node, edge) tuples
            progress_callback: Optional callback for progress updates.
                Signature: (current: int, total: int, message: str) -> None
            batch_size: Number of items per batch (default: 500)
        """
        if self.read_only:
            raise ValueError("Cannot bulk load in read-only mode")
        if batch_size < 1:
            raise ValueError(f"batch_size must be >= 1, got {batch_size}")

        self.disable_background_saves()
        try:
            self._bulk_load_inner(nodes, edges, progress_callback, batch_size)
        finally:
            self.restore_background_saves()

    def _bulk_load_inner(
        self,
        nodes: List[BaseNode],
        edges: List[tuple[BaseNode | NodeIdentifier, BaseNode | NodeIdentifier, GraphEdge]],
        progress_callback: Optional[Callable[[int, int, str], None]] = None,
        batch_size: int = 500,
    ) -> None:
        """Inner implementation of bulk_load (without save guard wrapper)."""
        from collections import defaultdict

        total_items = len(nodes) + len(edges)
        logger.debug(f"Bulk loading {len(nodes)} nodes and {len(edges)} edges (batch_size={batch_size})...")

        # --- Nodes: group by label, normalize, batch ---
        nodes_by_label: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for node in nodes:
            label = node.node_label.value
            properties = node.model_dump(mode='json')
            properties = {
                k: self._normalize_value(v)
                for k, v in properties.items()
                if v is not None
            }
            nodes_by_label[label].append(properties)

        node_count = 0
        for label, props_list in nodes_by_label.items():
            for i in range(0, len(props_list), batch_size):
                chunk = props_list[i : i + batch_size]
                self._batch_upsert_nodes(label, chunk)
                node_count += len(chunk)
                if progress_callback:
                    progress_callback(node_count, total_items, f"{node_count}/{len(nodes)} nodes")

        logger.debug(f"Completed loading {len(nodes)} nodes in {sum(1 for pl in nodes_by_label.values() for _ in range(0, len(pl), batch_size))} batches")

        # --- Edges: group by (from_label, to_label, edge_type), batch ---
        edges_by_key: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
        for from_node, to_node, edge in edges:
            if isinstance(from_node, BaseNode):
                from_id = from_node.id
                from_label = from_node.node_label.value
            else:
                from_id = from_node.id
                from_label = from_node.node_label.value

            if isinstance(to_node, BaseNode):
                to_id = to_node.id
                to_label = to_node.node_label.value
            else:
                to_id = to_node.id
                to_label = to_node.node_label.value

            edge_type = edge.edge_type.value
            properties = edge.model_dump(mode='json')
            properties = {
                k: self._normalize_value(v)
                for k, v in properties.items()
                if v is not None
            }

            edges_by_key[(from_label, to_label, edge_type)].append({
                "from_id": from_id,
                "to_id": to_id,
                "props": properties,
            })

        edge_count = 0
        for (from_label, to_label, edge_type), edge_list in edges_by_key.items():
            for i in range(0, len(edge_list), batch_size):
                chunk = edge_list[i : i + batch_size]
                self._create_edges_individually(from_label, to_label, edge_type, chunk)
                edge_count += len(chunk)
                if progress_callback:
                    progress_callback(
                        len(nodes) + edge_count,
                        total_items,
                        f"{edge_count}/{len(edges)} edges",
                    )

        logger.debug(f"Completed loading {len(edges)} edges")
        logger.debug("Bulk load completed successfully")

    def delete_model_cascade(self, model_id: str, preserve_model: bool = False) -> int:
        """Delete a DbtModel and all associated child nodes in a single atomic operation.

        Deletes:
        - DbtModel node (unless preserve_model=True)
        - DbtColumn nodes (children)
        - PhysicalTable/View/Column nodes (via BUILDS)
        - InferredSemanticModel and all semantic child nodes
        - TableProfile and ColumnProfile nodes
        - All edges involving these nodes

        Args:
            model_id: dbt unique_id of the model to delete
            preserve_model: If True, delete all children but keep the DbtModel node itself.
                Useful for incremental updates where we want to clear children before
                re-loading them.

        Returns:
            Number of nodes deleted
        """
        if self.read_only:
            raise ValueError("Cannot delete in read-only mode")

        # Validate model_id format
        if not model_id or not isinstance(model_id, str):
            raise ValueError(f"Invalid model_id: must be non-empty string, got {model_id!r}")

        # dbt resource IDs should start with known prefixes
        valid_prefixes = ("model.", "source.", "seed.", "snapshot.", "test.")
        if not model_id.startswith(valid_prefixes):
            logger.warning(
                f"model_id {model_id!r} does not match expected dbt format "
                f"(expected prefix: {', '.join(valid_prefixes)})"
            )

        # If preserving the model, we still need to clear outgoing edges even when the
        # model has no "child" nodes to delete. So we only early-exit if the model
        # node itself does not exist.
        if preserve_model:
            try:
                exists_result = self._execute_query(
                    "MATCH (m:DbtModel {id: $model_id}) RETURN COUNT(m) AS c",
                    {"model_id": model_id},
                )
                if not exists_result.result_set or int(exists_result.result_set[0][0]) == 0:
                    return 0
            except Exception:
                # Existence check is best-effort; proceed to deletion attempt.
                logger.warning(f"Failed to check if model {model_id} exists: {traceback.format_exc()}")

        # Single query for both count and delete - matches all related nodes
        # Uses semantic_model_id ownership key to avoid accidentally deleting other DbtModels
        #
        # IMPORTANT (incremental updates):
        # When preserve_model=True we intentionally DO NOT delete logical DbtColumn nodes.
        # Downstream models' column lineage edges (DERIVES_FROM) can point to these nodes,
        # and deleting them would permanently break lineage for unchanged downstream models.
        #
        # We still clear outgoing edges FROM the preserved model and its columns so the
        # modified model can be reloaded accurately.
        if preserve_model:
            base_query = """
                MATCH (m:DbtModel {id: $model_id})
                OPTIONAL MATCH (m)-[:HAS_INFERRED_SEMANTICS]->(sem:InferredSemanticModel)
                OPTIONAL MATCH (sem_child)
                WHERE sem_child.semantic_model_id = sem.id AND NOT sem_child:DbtModel
                OPTIONAL MATCH (m)-[:BUILDS]->(phys)
                OPTIONAL MATCH (phys)-[:HAS_COLUMN]->(phys_col:PhysicalColumn)
                OPTIONAL MATCH (m)-[:HAS_PROFILE]->(prof:TableProfile)
                OPTIONAL MATCH (prof)-[:HAS_COLUMN_PROFILE]->(col_prof:ColumnProfile)
            """
        else:
            base_query = """
                MATCH (m:DbtModel {id: $model_id})
                OPTIONAL MATCH (m)-[:HAS_INFERRED_SEMANTICS]->(sem:InferredSemanticModel)
                OPTIONAL MATCH (sem_child)
                WHERE sem_child.semantic_model_id = sem.id AND NOT sem_child:DbtModel
                OPTIONAL MATCH (m)-[:BUILDS]->(phys)
                OPTIONAL MATCH (phys)-[:HAS_COLUMN]->(phys_col:PhysicalColumn)
                OPTIONAL MATCH (m)-[:HAS_PROFILE]->(prof:TableProfile)
                OPTIONAL MATCH (prof)-[:HAS_COLUMN_PROFILE]->(col_prof:ColumnProfile)
                OPTIONAL MATCH (col:DbtColumn {parent_id: $model_id})
            """

        # Count first for metrics (exclude model from count if preserving)
        if preserve_model:
            count_query = base_query + """
                RETURN COUNT(DISTINCT sem) + COUNT(DISTINCT sem_child) +
                       COUNT(DISTINCT phys) + COUNT(DISTINCT phys_col) +
                       COUNT(DISTINCT prof) + COUNT(DISTINCT col_prof) AS total
            """
        else:
            count_query = base_query + """
                RETURN COUNT(DISTINCT m) + COUNT(DISTINCT sem) + COUNT(DISTINCT sem_child) +
                       COUNT(DISTINCT phys) + COUNT(DISTINCT phys_col) +
                       COUNT(DISTINCT prof) + COUNT(DISTINCT col_prof) + COUNT(DISTINCT col) AS total
            """
        count_succeeded = False
        deleted_count = 0
        try:
            result = self._execute_query(count_query, {"model_id": model_id})
            deleted_count = int(result.result_set[0][0]) if result.result_set else 0
            count_succeeded = True
        except Exception as e:
            # Count is only for metrics - log warning but still attempt deletion
            logger.warning(
                f"Failed to count nodes for model {model_id} before deletion: {e}. "
                "Proceeding with deletion attempt anyway."
            )
            # Don't return early - attempt deletion even if count failed

        # Only skip deletion if count succeeded AND found 0 nodes
        # If count failed, we can't know if model exists, so attempt deletion anyway
        if (not preserve_model) and count_succeeded and deleted_count == 0:
            return 0  # Model doesn't exist or no children, no-op

        # IMPORTANT (incremental updates):
        # When preserve_model=True we keep the DbtModel node, but we MUST clear its
        # outgoing dependency edges so they can be re-created accurately. Otherwise,
        # incremental updates can accumulate stale DEPENDS_ON / USES_MACRO edges.
        #
        # Additionally, we clear outgoing edges from its DbtColumns (DERIVES_FROM)
        # and model->column edges (MATERIALIZES). We intentionally DO NOT delete
        # DbtColumn nodes to preserve incoming lineage from downstream models.
        #
        # We do this as separate queries to avoid cartesian-product row explosion
        # from the multi-OPTIONAL-MATCH cascade query below.
        if preserve_model:
            try:
                self._execute_query(
                    "MATCH (m:DbtModel {id: $model_id})-[r:DEPENDS_ON]->() DELETE r",
                    {"model_id": model_id},
                )
                self._execute_query(
                    "MATCH (m:DbtModel {id: $model_id})-[r:USES_MACRO]->() DELETE r",
                    {"model_id": model_id},
                )
                self._execute_query(
                    "MATCH (m:DbtModel {id: $model_id})-[r:MATERIALIZES]->() DELETE r",
                    {"model_id": model_id},
                )
                self._execute_query(
                    "MATCH (c:DbtColumn {parent_id: $model_id})-[r:DERIVES_FROM]->() DELETE r",
                    {"model_id": model_id},
                )
            except Exception as e:
                # Edge cleanup is best-effort; cascade deletion below will still proceed.
                logger.warning(
                    f"Failed to clear outgoing dependency edges for preserved model {model_id}: {e}. "
                    "Proceeding with child-node cascade delete."
                )

        # Single atomic delete query - exclude model if preserving
        if preserve_model:
            delete_query = base_query + """
                DETACH DELETE sem, sem_child, phys, phys_col, prof, col_prof
            """
        else:
            delete_query = base_query + """
                DETACH DELETE m, sem, sem_child, phys, phys_col, prof, col_prof, col
            """

        try:
            self._execute_query(delete_query, {"model_id": model_id})
            if count_succeeded:
                if preserve_model:
                    logger.debug(f"Cleared {deleted_count} child nodes for model {model_id} (model preserved)")
                else:
                    logger.debug(f"Deleted model {model_id} and {deleted_count} associated nodes")
            else:
                # Count failed but deletion succeeded - log generic success
                if preserve_model:
                    logger.debug(f"Cleared child nodes for model {model_id} (model preserved, count unavailable)")
                else:
                    logger.debug(f"Deleted model {model_id} and associated nodes (count unavailable)")
        except Exception as e:
            # If single query fails, try step-by-step deletion as fallback
            logger.warning(f"Single-query cascade delete failed, trying step-by-step: {e}")
            # Clear outgoing dependency edges when preserving the model node
            if preserve_model:
                try:
                    self._execute_query(
                        "MATCH (m:DbtModel {id: $model_id})-[r:DEPENDS_ON]->() DELETE r",
                        {"model_id": model_id},
                    )
                    self._execute_query(
                        "MATCH (m:DbtModel {id: $model_id})-[r:USES_MACRO]->() DELETE r",
                        {"model_id": model_id},
                    )
                    self._execute_query(
                        "MATCH (m:DbtModel {id: $model_id})-[r:MATERIALIZES]->() DELETE r",
                        {"model_id": model_id},
                    )
                    self._execute_query(
                        "MATCH (c:DbtColumn {parent_id: $model_id})-[r:DERIVES_FROM]->() DELETE r",
                        {"model_id": model_id},
                    )
                except Exception as edge_e:
                    logger.warning(
                        f"Failed to clear outgoing dependency edges for preserved model {model_id} "
                        f"during fallback deletion: {edge_e}"
                    )
            self._execute_query(
                "MATCH (m:DbtModel {id: $model_id})-[:HAS_INFERRED_SEMANTICS]->(sem:InferredSemanticModel) "
                "OPTIONAL MATCH (child) WHERE child.semantic_model_id = sem.id AND NOT child:DbtModel "
                "DETACH DELETE sem, child",
                {"model_id": model_id}
            )
            self._execute_query(
                "MATCH (m:DbtModel {id: $model_id})-[:BUILDS]->(phys) "
                "OPTIONAL MATCH (phys)-[:HAS_COLUMN]->(phys_col:PhysicalColumn) "
                "DETACH DELETE phys, phys_col",
                {"model_id": model_id}
            )
            self._execute_query(
                "MATCH (m:DbtModel {id: $model_id})-[:HAS_PROFILE]->(prof:TableProfile) "
                "OPTIONAL MATCH (prof)-[:HAS_COLUMN_PROFILE]->(col_prof:ColumnProfile) "
                "DETACH DELETE prof, col_prof",
                {"model_id": model_id}
            )
            if not preserve_model:
                self._execute_query(
                    "MATCH (col:DbtColumn {parent_id: $model_id}) DETACH DELETE col",
                    {"model_id": model_id}
                )
            # Only delete the model node if not preserving
            if not preserve_model:
                self._execute_query(
                    "MATCH (m:DbtModel {id: $model_id}) DETACH DELETE m",
                    {"model_id": model_id}
                )
            if preserve_model:
                logger.debug(f"Cleared child nodes for {model_id} using step-by-step approach ({deleted_count} nodes)")
            else:
                logger.debug(f"Deleted model {model_id} using step-by-step approach ({deleted_count} nodes)")

        return deleted_count

    # ------------------------------------------------------------------
    # Override specific methods for performance (optional)
    # ------------------------------------------------------------------

    def get_job(self, job_id: str) -> Optional[JobNode]:
        """Get a Job node by ID (override for performance)."""
        result = self.graph.query(
            "MATCH (j:Job {id: $id}) RETURN j.name AS name, j.namespace AS namespace, j.job_type AS job_type",
            {"id": job_id},
        )

        if not result.result_set:
            return None

        record = result.result_set[0]
        return JobNode(
            id=job_id,
            name=record[0] if len(record) > 0 else "",
            namespace=record[1] if len(record) > 1 else "",
            job_type=record[2] if len(record) > 2 else "",
            metadata={},
        )

    def get_dataset(self, dataset_id: str) -> Optional[DatasetNode]:
        """Get a Dataset node by ID (override for performance)."""
        result = self.graph.query(
            "MATCH (d:Dataset {id: $id}) RETURN d.name AS name, d.namespace AS namespace, d.dataset_type AS dtype",
            {"id": dataset_id},
        )

        if not result.result_set:
            return None

        record = result.result_set[0]
        return DatasetNode(
            id=dataset_id,
            name=record[0] if len(record) > 0 else "",
            namespace=record[1] if len(record) > 1 else "",
            dataset_type=record[2] if len(record) > 2 else "",
            metadata={},
        )

    # ------------------------------------------------------------------
    # Query Methods (required by protocol)
    # ------------------------------------------------------------------

    def _convert_value(self, value):
        """Convert FalkorDB objects to JSON-serializable formats."""
        from falkordb import Edge, Node, Path

        if isinstance(value, Node):
            # Convert Node to dict with properties
            return {
                "id": value.id if hasattr(value, "id") else None,
                "labels": list(value.labels) if hasattr(value, "labels") else [],
                **value.properties
            }
        elif isinstance(value, Edge):
            # Convert Edge to dict
            return {
                "id": value.id if hasattr(value, "id") else None,
                "relation": value.relation if hasattr(value, "relation") else None,
                "src_node": value.src_node if hasattr(value, "src_node") else None,
                "dest_node": value.dest_node if hasattr(value, "dest_node") else None,
                **value.properties
            }
        elif isinstance(value, Path):
            # Convert Path to list of nodes and edges
            return {
                "nodes": [self._convert_value(n) for n in value.nodes()],
                "edges": [self._convert_value(e) for e in value.edges()],
            }
        elif isinstance(value, list):
            return [self._convert_value(v) for v in value]
        elif isinstance(value, dict):
            return {k: self._convert_value(v) for k, v in value.items()}
        else:
            # Primitive types (str, int, float, bool, None)
            return value

    def execute_raw_query(self, query: str, params: Optional[Dict[str, Any]] = None) -> RawLineageQueryResult:
        """Execute a raw Cypher query and return results in a consistent format.

        Automatically retries on transient failures up to max_retries times.

        Args:
            query: Cypher query string
            params: Optional dictionary of parameters to bind to the query
        Returns:
            Dictionary with rows (list of dicts), row_count, and query
        """
        last_error: Optional[Exception] = None

        # Ensure at least one attempt is made (defensive against invalid max_retries)
        attempts = max(1, self.max_retries)
        for attempt in range(attempts):
            try:
                result = self._execute_query(query, params)
                # Convert result to list of dicts
                rows = []
                column_names = [item[1] for item in result.header]
                # Convert the raw result into a list of dictionaries

                for row in result.result_set:
                    # Use zip() to pair the column names with the values in the current row
                    # Convert any FalkorDB objects to JSON-serializable formats
                    converted_row = [self._convert_value(value) for value in row]
                    new_dict = dict(zip(column_names, converted_row, strict=True))
                    rows.append(new_dict)

                return RawLineageQueryResult(rows=rows, count=len(rows), query=query)

            except Exception as e:
                last_error = e
                if attempt < attempts - 1:
                    logger.debug(
                        f"Query failed (attempt {attempt + 1}/{attempts}), retrying: "
                        f"{e.__class__.__name__}: {e}"
                    )

        # All attempts failed
        if last_error is None:
            # This should never happen due to validation, but defensive programming
            raise RuntimeError(
                f"Query failed after {attempts} attempts but no error was captured. "
                f"This indicates a bug in the retry logic."
            )
        logger.error(
            f"Query failed after {attempts} attempts: "
            f"{last_error.__class__.__name__}: {last_error}"
        )
        raise last_error

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def _build_fulltext_query(self, pattern: str, mode: str) -> str:
        """Translate search mode to FalkorDB fulltext syntax.

        Args:
            pattern: Search pattern from user
            mode: Search mode (contains, prefix, fuzzy, any, all)

        Returns:
            FalkorDB fulltext query string
        """
        if mode == "prefix":
            # Prefix search: foo* matches "foo", "foobar", etc.
            return f"{pattern}*"
        elif mode == "fuzzy":
            # Fuzzy search: %term%N allows N edit distance
            return f"%{pattern}%1"
        elif mode == "any":
            # Multi-term OR: any term matches
            terms = pattern.split()
            return "|".join(terms) if len(terms) > 1 else pattern
        elif mode == "all":
            # Multi-term AND: all terms required (space = AND in FalkorDB fulltext)
            return pattern  # Space-separated terms are AND by default
        else:
            # Default (contains): just the pattern as-is for fulltext
            return pattern

    def _build_contains_where_clause(
        self, pattern: str, mode: str, var: str = "n"
    ) -> str:
        """Build CONTAINS-based WHERE clause for fallback search.

        Args:
            pattern: Search pattern
            mode: Search mode
            var: Cypher variable name for the node

        Returns:
            WHERE clause string (without the WHERE keyword)
        """
        escaped = self._escape_cypher_string_literal(pattern)

        if mode == "prefix":
            # Use STARTS WITH for prefix mode
            return f"""
                (exists({var}.name) AND toLower({var}.name) STARTS WITH toLower('{escaped}'))
                OR (exists({var}.fqn) AND toLower({var}.fqn) STARTS WITH toLower('{escaped}'))
            """
        elif mode in ("any", "all"):
            # Multi-term search
            terms = pattern.split()
            if len(terms) <= 1:
                escaped_term = self._escape_cypher_string_literal(pattern)
                return f"""
                    (exists({var}.name) AND toLower({var}.name) CONTAINS toLower('{escaped_term}'))
                    OR (exists({var}.search_tokenized_name) AND toLower({var}.search_tokenized_name) CONTAINS toLower('{escaped_term}'))
                    OR (exists({var}.description) AND toLower({var}.description) CONTAINS toLower('{escaped_term}'))
                    OR (exists({var}.fqn) AND toLower({var}.fqn) CONTAINS toLower('{escaped_term}'))
                """

            term_conditions = []
            for term in terms:
                escaped_term = self._escape_cypher_string_literal(term)
                term_conditions.append(f"""
                    (exists({var}.name) AND toLower({var}.name) CONTAINS toLower('{escaped_term}'))
                    OR (exists({var}.search_tokenized_name) AND toLower({var}.search_tokenized_name) CONTAINS toLower('{escaped_term}'))
                    OR (exists({var}.description) AND toLower({var}.description) CONTAINS toLower('{escaped_term}'))
                    OR (exists({var}.fqn) AND toLower({var}.fqn) CONTAINS toLower('{escaped_term}'))
                """)

            if mode == "any":
                # OR: any term matches
                return " OR ".join(f"({cond})" for cond in term_conditions)
            else:
                # AND: all terms required
                return " AND ".join(f"({cond})" for cond in term_conditions)
        else:
            # Default: simple CONTAINS
            return f"""
                (exists({var}.name) AND toLower({var}.name) CONTAINS toLower('{escaped}'))
                OR (exists({var}.search_tokenized_name) AND toLower({var}.search_tokenized_name) CONTAINS toLower('{escaped}'))
                OR (exists({var}.description) AND toLower({var}.description) CONTAINS toLower('{escaped}'))
                OR (exists({var}.fqn) AND toLower({var}.fqn) CONTAINS toLower('{escaped}'))
            """

    def _search_with_regex(
        self, node_label: str, pattern: str, limit: int
    ) -> List[Dict[str, Any]]:
        """Search using text.regexGroups UDF for regex pattern matching.

        Args:
            node_label: Node type to search
            pattern: Regex pattern
            limit: Max results

        Returns:
            List of matching nodes with scores
        """
        safe_label = self._validate_cypher_node_label(node_label)
        escaped_pattern = self._escape_cypher_string_literal(pattern)

        # Use text.regexGroups UDF for regex matching
        cypher = f"""
            MATCH (n:`{safe_label}`)
            WHERE text.regexGroups(coalesce(n.name, ''), '{escaped_pattern}') IS NOT NULL
               OR text.regexGroups(coalesce(n.fqn, ''), '{escaped_pattern}') IS NOT NULL
               OR text.regexGroups(coalesce(n.description, ''), '{escaped_pattern}') IS NOT NULL
            RETURN n AS node, 1.0 AS score
            LIMIT {limit}
        """
        try:
            result = self.execute_raw_query(cypher)
            logger.info(f"Regex search for '{pattern}' on {node_label}: {len(result.rows)} results")
            return result.rows
        except Exception as e:
            logger.warning(f"Regex search failed for {node_label}, falling back to CONTAINS: {e}")
            # Fall back to contains search
            return self._search_with_contains(node_label, pattern, limit, "contains")

    def _search_with_fulltext(
        self, node_label: str, pattern: str, limit: int, mode: str
    ) -> Optional[List[Dict[str, Any]]]:
        """Search using FalkorDB fulltext index.

        Args:
            node_label: Node type to search
            pattern: Search pattern
            limit: Max results
            mode: Search mode

        Returns:
            List of matching nodes with scores, or None if fulltext unavailable
        """
        safe_label = self._validate_cypher_node_label(node_label)

        # Check if fulltext index exists
        ft_indexes = self.list_fulltext_indexes()
        has_ft_index = any(idx["label"] == safe_label for idx in ft_indexes)

        if not has_ft_index:
            logger.debug(f"No fulltext index for {safe_label}")
            return None

        # Build fulltext query based on mode
        ft_query = self._build_fulltext_query(pattern, mode)
        escaped_ft_query = self._escape_cypher_string_literal(ft_query)

        cypher = f"""
            CALL db.idx.fulltext.queryNodes('{safe_label}', '{escaped_ft_query}')
            YIELD node, score
            RETURN node, score
        """
        try:
            result = self.execute_raw_query(cypher)
            if result.rows and "score" in result.rows[0]:
                # Sort by score and limit
                sorted_rows = sorted(
                    result.rows, key=lambda r: r.get("score", 0), reverse=True
                )[:limit]
                logger.info(
                    f"Fulltext search ({mode}) for '{pattern}' on {node_label}: "
                    f"{len(sorted_rows)} results"
                )
                return sorted_rows
            elif result.rows:
                logger.warning(f"Fulltext search for {node_label} returned results without scores")
            return None
        except Exception as e:
            error_msg = str(e).lower()
            if "index" in error_msg and ("not found" in error_msg or "does not exist" in error_msg):
                logger.warning(f"Fulltext index for {safe_label} not ready: {e}")
            else:
                logger.error(f"Fulltext search failed for {safe_label}: {e}")
            return None

    def _search_with_contains(
        self, node_label: str, pattern: str, limit: int, mode: str
    ) -> List[Dict[str, Any]]:
        """Fallback search using CONTAINS.

        Args:
            node_label: Node type to search
            pattern: Search pattern
            limit: Max results
            mode: Search mode

        Returns:
            List of matching nodes with scores
        """
        safe_label = self._validate_cypher_node_label(node_label)
        where_clause = self._build_contains_where_clause(pattern, mode)

        cypher = f"""
            MATCH (n:`{safe_label}`)
            WHERE {where_clause}
            RETURN n AS node, 0.5 AS score
            LIMIT {limit}
        """
        result = self.execute_raw_query(cypher)
        logger.info(f"CONTAINS search ({mode}) for '{pattern}' on {node_label}: {len(result.rows)} results")
        return result.rows

    def search_nodes(
        self, node_label: str, query: str, limit: int = 10, mode: str = "contains"
    ) -> List[Dict[str, Any]]:
        """Search nodes using mode-based query strategy.

        Search modes:
        - "contains": Simple substring match (default)
        - "prefix": Starts with pattern
        - "fuzzy": Typo-tolerant (1-2 edit distance)
        - "regex": Pattern matching via text.regexGroups UDF
        - "any": Multi-term OR (any term matches)
        - "all": Multi-term AND (all terms required)

        Args:
            node_label: The node type to search (e.g., "DbtModel")
            query: Search pattern (interpreted based on mode)
            limit: Maximum results to return
            mode: Search mode

        Returns:
            List of dicts with 'node' and 'score' keys, sorted by relevance
        """
        # Handle regex mode separately (uses UDF, not fulltext)
        if mode == "regex":
            return self._search_with_regex(node_label, query, limit)

        # Try fulltext search first for supported modes
        if mode in ("contains", "prefix", "fuzzy", "any", "all"):
            results = self._search_with_fulltext(node_label, query, limit, mode)
            if results is not None:
                return results

        # Fall back to CONTAINS-based search
        return self._search_with_contains(node_label, query, limit, mode)

    # ------------------------------------------------------------------
    # Utility helpers
    # ------------------------------------------------------------------

    def _execute_query(self, query: str, params: Optional[Dict[str, Any]] = None):
        """Execute a query with optional parameters.

        This method can be overridden by subclasses to handle parameterization differently.
        Default implementation uses standard parameterized queries.

        Args:
            query: Cypher query string (may contain $ parameters)
            params: Optional dictionary of parameter values
        """
        if self.read_only:
            return self.graph.ro_query(query, params)
        else:
            return self.graph.query(query, params)

    @staticmethod
    def _is_primitive(value) -> bool:
        return isinstance(value, (str, int, float, bool)) or value is None

    def _normalize_value(self, value):
        """Ensure property values comply with FalkorDB (primitives or arrays)."""
        if self._is_primitive(value):
            return value

        if isinstance(value, (list, tuple, set)):
            normalized_items = []
            for item in value:
                normalized_item = self._normalize_value(item)
                if not self._is_primitive(normalized_item):
                    return json.dumps(value, default=str)
                normalized_items.append(normalized_item)
            return normalized_items

        # Dicts or other complex types -> JSON string
        try:
            return json.dumps(value, default=str)
        except TypeError:
            return str(value)

    # get_graph_schema() inherited from BaseLineageStorage - uses schema.yaml

    def store_cluster_analysis(
        self,
        clusters: Dict[int, List[str]],
        analyses: List[ClusterAnalysis],
    ) -> None:
        """Store enhanced cluster analysis in FalkorDB (schemaless approach).

        FalkorDB implementation:
        1. Delete existing InferredSubjectArea nodes
        2. Create new InferredSubjectArea nodes with enriched metadata
        3. Create BELONGS_TO_SUBJECT_AREA relationships from models to subject areas

        Args:
            clusters: Dict mapping cluster_id -> list of model IDs
            analyses: List of ClusterAnalysis with detailed results
        """
        from lineage.backends.lineage.models.clustering import InferredSubjectArea

        # Step 1: Delete existing cluster nodes and relationships
        self.graph.query("MATCH (c:InferredSubjectArea) DETACH DELETE c")
        # Also remove legacy JoinCluster-based clustering artifacts from previous runs
        self.graph.query("MATCH (c:JoinCluster) DETACH DELETE c")

        # Step 2: Create cluster nodes with enriched metadata
        for analysis in analyses:
            # Build InferredSubjectArea node with all metadata
            cluster_node = InferredSubjectArea(
                name=analysis.subject_area_name,
                cluster_id=str(analysis.cluster_id),
                description=analysis.description,
                notes=analysis.notes,
                domains=analysis.domains,
                keywords=analysis.keywords,
                total_edge_weight=analysis.total_edge_weight,
                fact_model_count=len(analysis.fact_model_ids),
                dimension_model_count=len(analysis.dimension_model_ids),
                mixed_model_count=len(analysis.mixed_model_ids),
                contains_pii=analysis.contains_pii,
                pii_model_count=len(analysis.has_pii_model_ids),
                recommended_fact_model=analysis.recommended_fact_model,
                top_dimension_model_ids=analysis.recommended_dimension_order[:5],
                model_count=analysis.model_count,
            )

            # Use upsert_node to store (leverages BaseLineageStorage logic)
            self.upsert_node(cluster_node)

        # Step 3: Create relationships from models to subject areas
        for cluster_id, members in clusters.items():
            for model_id in members:
                # Use FalkorDB query to create relationship
                # Note: FalkorDB doesn't support regex, so we use exact match
                self.graph.query(
                    """
                    MATCH (m:DbtModel {id: $mid}), (c:InferredSubjectArea {cluster_id: $cid})
                    CREATE (m)-[:BELONGS_TO_SUBJECT_AREA]->(c)
                    """,
                    {"mid": model_id, "cid": str(cluster_id)},
                )

    def get_agent_hints(self) -> str:
        """Get FalkorDB-specific hints for AI agents writing Cypher queries."""
        return """
## FalkorDB Cypher Dialect Hints

You are querying a **FalkorDB** backend. Standard Cypher works, but keep these dialect rules in mind.

### Key Dialect Constraints
- **No regex** (`=~`) → use `CONTAINS`, `STARTS WITH`, `ENDS WITH`, `toLower()`.
- **No temporal arithmetic** → store timestamps as strings/ints and compare directly.
- **Property deletion** → `SET n.prop = NULL` (FalkorDB ignores `REMOVE`).
- **Relationship uniqueness quirks** → when de-duping, bind the relationship alias and (if necessary) add `WHERE ID(r) >= 0`.

```cypher
// Case-insensitive search without regex
MATCH (m:DbtModel)
WHERE toLower(m.name) CONTAINS toLower($needle)
RETURN m.id, m.name
```

### Supported Features
- Standard clauses: `MATCH`, `OPTIONAL MATCH`, `WITH`, `UNWIND`, aggregation.
- String helpers: `toLower`, `split`, `substring`, `trim`, etc.
- Collections: `COLLECT`, `apoc.coll.*` is **not** available—stick to native Cypher.

---

## Cypher Patterns That Map to Schema v2

**Logical ↔ Physical linkage (env aware)**
```cypher
MATCH (m:DbtModel {name: $model})
MATCH (m)-[b:BUILDS]->(p)
WHERE b.environment = $env
RETURN m.name, labels(p) AS physical_type, p.fqn, b.materialization_strategy
```

**Column-level lineage across layers**
```cypher
MATCH (target:DbtColumn {id: $child_id})
MATCH (source)<-[:DERIVES_FROM]-(target)
RETURN labels(source) AS node_type, source.id, source.name, source.confidence
```

**Semantic metadata summary for a model**
```cypher
MATCH (m:DbtModel {name: $model})
MATCH (m)-[:HAS_INFERRED_SEMANTICS]->(s)
OPTIONAL MATCH (s)-[:HAS_MEASURE]->(meas)
OPTIONAL MATCH (s)-[:HAS_DIMENSION]->(dim)
RETURN m.name,
       s.grain_human,
       COLLECT(DISTINCT meas.name) AS measures,
       COLLECT(DISTINCT dim.name) AS dimensions
```

**Join insights and clustering**
```cypher
MATCH (m:DbtModel {name: $model})
OPTIONAL MATCH (m)-[:HAS_JOIN_EDGE]->(edge:JoinEdge)
OPTIONAL MATCH (m)-[:BELONGS_TO_SUBJECT_AREA]->(area:InferredSubjectArea)
RETURN COLLECT(DISTINCT edge.equi_condition) AS join_conditions,
       area.cluster_id AS cluster,
       area.name AS subject_area,
       area.description AS description,
       area.notes AS notes
```

**Runtime diagnostics via OpenLineage**
```cypher
MATCH (m:DbtModel {name: $model})
MATCH (j:Job)-[:EXECUTES]->(m)
MATCH (r:Run)-[:INSTANCE_OF]->(j)
OPTIONAL MATCH (r)-[:HAS_ERROR]->(err:Error)
RETURN r.id, r.status, r.start_time, err.error_type, err.message
ORDER BY r.start_time DESC
LIMIT 20
```

**Mapping datasets back to the warehouse**
```cypher
MATCH (ds:Dataset {namespace: $ns})
MATCH (ds)-[rel:SAME_AS]->(p:PhysicalTable)
RETURN ds.name, p.fqn, rel.confidence, rel.match_method
```

---

## Performance & Safety Tips
- Start exploratory queries with `LIMIT`, then remove once confident.
- Avoid Cartesian products: always connect matches or use `WHERE` equality.
- Use indexes by filtering on `id`, `name`, `cluster_id`, etc. (see `ensure_schema`).
- Always parameterize literals (`$param`) to prevent injection.
- Remember FalkorDB string functions are 1-based when supplying indices.
- Store and compare timestamps as ISO strings or epoch integers—no `datetime()` helpers exist.

---

## Common Gotchas Recap
- Regex/temporal functions are unsupported.
- `SET prop = NULL` instead of `REMOVE`.
- Relationship type and property names are case-sensitive.
- Use `COLLECT(DISTINCT ...)` if you see duplicates from multi-hop traversals.

""".strip()
