"""Pydantic models for subject area clustering nodes and DTOs.

These models represent groups of models with similar join patterns:
- InferredSubjectArea: Enhanced subject area node with business metadata (stored in graph)
- ModelEnrichmentData: Enrichment metadata for models (DTO, not stored)
- ClusterAnalysis: Consolidated analysis and design recommendations (DTO, not stored)
"""

from typing import Any, ClassVar, Optional

from pydantic import BaseModel, Field, computed_field

from lineage.backends.lineage.models.base import BaseNode
from lineage.backends.types import NodeLabel


class InferredSubjectArea(BaseNode):
    """Enhanced inferred subject area node with rich business metadata.

    Represents a group of models that share similar business domains and join patterns,
    discovered through hybrid clustering analysis. Includes business metadata
    extracted from semantic analysis and clustering algorithm results.

    The ID is the cluster_id (typically an integer converted to string).
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.INFERRED_SUBJECT_AREA

    # Core properties
    name: str  # Primary business domain name (e.g., "licensing") or fallback "cluster_{id}"
    cluster_id: str  # Unique cluster identifier
    model_count: int = 0  # Number of models in this subject area

    # Business metadata (from semantic analysis)
    description: Optional[str] = None  # LLM-generated summary (from ClusterBlueprint)
    notes: list[str] = Field(default_factory=list)  # Technical observations about the subject area
    domains: list[str] = Field(default_factory=list)  # All business domains in this subject area
    keywords: list[str] = Field(default_factory=list)  # Normalized search terms for agent matching
    total_edge_weight: float = 0.0  # Sum of join edge weights

    # Role breakdown (from semantic analysis)
    fact_model_count: int = 0  # Number of fact models (has aggregations)
    dimension_model_count: int = 0  # Number of dimension models (no aggregations)
    mixed_model_count: int = 0  # Number of mixed models (both fact and dimension characteristics)

    # PII & governance
    contains_pii: bool = False  # True if any model in subject area has PII
    pii_model_count: int = 0  # Number of models with PII

    # Blueprint fields (schema design guidance)
    recommended_fact_model: Optional[str] = None  # Highest-degree fact model
    top_dimension_model_ids: list[str] = Field(default_factory=list)  # Top dimensions ordered by connectivity

    @computed_field
    @property
    def id(self) -> str:
        """Cluster ID is the unique identifier."""
        return self.cluster_id


class ModelEnrichmentData(BaseModel):
    """Enrichment metadata for a single model (DTO - not stored in graph).

    This data is computed during clustering enrichment phase and used
    to generate cluster summaries and blueprints.
    """

    model_id: str
    role: str  # "fact", "dimension", or "mixed"
    domains: list[str] = Field(default_factory=list)  # Business domain keywords extracted from intent
    has_pii: bool = False  # True if any column has PII
    fact_count: int = 0  # Number of BusinessMeasure nodes
    dimension_count: int = 0  # Number of BusinessDimension nodes
    weighted_degree: float = 0.0  # Weighted degree in join graph (computed during clustering)
    # Detailed lists (populated separately to avoid duplicate queries)
    measure_names: list[str] = Field(default_factory=list)  # Names of InferredMeasure nodes
    dimension_names: list[str] = Field(default_factory=list)  # Names of InferredDimension nodes
    fact_names: list[str] = Field(default_factory=list)  # Names of InferredFact nodes


class ClusterAnalysis(BaseModel):
    """Consolidated cluster analysis results and design blueprint.

    Combines descriptive statistics (The "What") with prescriptive design
    recommendations (The "So What"). This DTO is used to populate the
    InferredSubjectArea graph node.
    """

    cluster_id: int
    subject_area_name: str  # Primary business domain or "cluster_{id}"
    description: Optional[str] = None  # LLM-generated summary
    model_count: int  # Total models in cluster
    model_ids: list[str]  # All model IDs

    # Role breakdown (candidate lists)
    fact_model_ids: list[str]
    dimension_model_ids: list[str]
    mixed_model_ids: list[str]
    has_pii_model_ids: list[str]

    # Graph metrics
    domains: list[str]  # Primary business domains
    keywords: list[str] = Field(default_factory=list)  # Normalized search terms for agent matching
    total_edge_weight: float  # Sum of join weights
    top_edges: list[dict[str, Any]]  # Top join relationships

    # Design Recommendations (The Blueprint)
    recommended_fact_model: Optional[str] = None
    recommended_dimension_order: list[str] = Field(default_factory=list)
    contains_pii: bool = False
    notes: list[str] = Field(default_factory=list)  # Qualitative analysis notes


__all__ = [
    "InferredSubjectArea",
    "ModelEnrichmentData",
    "ClusterAnalysis",
]
