"""Pydantic models for generic report nodes.

This module defines models for cross-platform BI report abstraction:
- Report: Canonical report spine across BI platforms
- ReportIR: Intermediate representation of a report
- ReportIRField: Field reference in a report IR
- NativeReportDefinition: Raw vendor-specific report definition
- ReportRevision: Version of a report at a point in time

The architecture follows a 3-layer pattern:
1. Report (canonical spine) - system-agnostic identity
2. Native instances (SfReport, future LookerLook) - vendor-specific nodes
3. ReportIR - common intermediate representation with lineage
"""
from __future__ import annotations

from typing import ClassVar, Optional

from pydantic import computed_field

from lineage.backends.lineage.models.base import BaseNode
from lineage.backends.types import NodeLabel


class Report(BaseNode):
    """Canonical report abstraction across BI platforms.

    Serves as the spine node for reports from any BI system (Salesforce,
    Looker, PowerBI, Tableau). Native vendor reports link here via
    NATIVE_INSTANCE_OF edges.

    ID format: report::{system}::{native_id}
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.REPORT

    system: str  # salesforce, looker, powerbi, tableau
    native_id: str
    title: Optional[str] = None
    description: Optional[str] = None
    folder: Optional[str] = None
    url: Optional[str] = None
    status: Optional[str] = None  # draft, published, archived
    owner: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    ir_hash: Optional[str] = None

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``report::{system}::{native_id}``."""
        return f"report::{self.system}::{self.native_id}"


class ReportIR(BaseNode):
    """Canonical intermediate representation of a report.

    Contains the common structure of a report regardless of the source
    BI platform. Links to ReportIRField nodes for field-level details.

    ID format: {report_id}.ir
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.REPORT_IR

    report_id: str
    ir_version: Optional[str] = None
    canonical_hash: Optional[str] = None
    report_format: Optional[str] = None  # tabular, summary, matrix
    base_entity: Optional[str] = None  # JSON - base entity/dataset
    grain_human: Optional[str] = None
    time_logic: Optional[str] = None  # JSON
    created_at: Optional[str] = None

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``{report_id}.ir``."""
        return f"{self.report_id}.ir"


class ReportIRField(BaseNode):
    """Field reference in a report IR.

    Represents a single field/column in the report with lineage tracking.
    Supports various field types (dimension, measure, time, filter_only)
    and roles (grouping, aggregation, display, filter).

    ID format: {ir_id}.field.{alias}
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.REPORT_IR_FIELD

    ir_id: str
    alias: str
    field_type: Optional[str] = None  # dimension, measure, time, filter_only
    role: Optional[str] = None  # grouping, aggregation, display, filter

    # FieldRef abstraction
    ref_type: Optional[str] = None  # physical, semantic, native, expression
    ref_expression: Optional[str] = None
    ref_entity: Optional[str] = None
    ref_field: Optional[str] = None

    # Type-specific properties
    aggregation: Optional[str] = None  # SUM, COUNT, AVG, etc.
    sort_order: Optional[str] = None
    axis: Optional[str] = None  # row, column (matrix)
    granularity: Optional[str] = None  # day, week, month, quarter, year
    label: Optional[str] = None
    format: Optional[str] = None
    decimal_places: Optional[int] = None

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``{ir_id}.field.{alias}``."""
        return f"{self.ir_id}.field.{self.alias}"


class NativeReportDefinition(BaseNode):
    """Raw vendor-specific report definition.

    Stores the original report definition from the BI platform in its
    native format (JSON, XML, LookML, etc.) for reference and debugging.

    ID format: {report_id}.def.{system}
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.NATIVE_REPORT_DEFINITION

    report_id: str
    system: str
    format: Optional[str] = None  # json, xml, lookml
    content: Optional[str] = None
    fetched_at: Optional[str] = None

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``{report_id}.def.{system}``."""
        return f"{self.report_id}.def.{self.system}"


class ReportRevision(BaseNode):
    """Version of a report at a point in time.

    Tracks changes to reports over time for audit and rollback purposes.
    Each revision links to a specific IR snapshot.

    ID format: {report_id}@{revision_number}
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.REPORT_REVISION

    report_id: str
    revision_number: int
    created_at: Optional[str] = None
    created_by: Optional[str] = None
    change_summary: Optional[str] = None
    ir_hash: Optional[str] = None  # Hash of IR at this revision
    is_current: bool = False

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``{report_id}@{revision_number}``."""
        return f"{self.report_id}@{self.revision_number}"


# =============================================================================
# Phase 2: Full IR Structure
# =============================================================================


class ReportIRFilter(BaseNode):
    """Filter predicate in a report IR.

    Represents a filter condition applied to the report data.
    Filters can be grouped with AND/OR operators.

    ID format: {ir_id}.filter.{index}
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.REPORT_IR_FILTER

    ir_id: str
    index: int
    field_ref: Optional[str] = None  # Reference to field being filtered
    operator: Optional[str] = None  # equals, not_equals, greater_than, less_than, contains, etc.
    value: Optional[str] = None  # Filter value (JSON for complex values)
    value_type: Optional[str] = None  # literal, field, parameter
    group_id: Optional[str] = None  # For grouping filters with AND/OR
    group_operator: Optional[str] = None  # AND, OR
    is_runtime: bool = False  # True if filter accepts runtime parameters

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``{ir_id}.filter.{index}``."""
        return f"{self.ir_id}.filter.{self.index}"


class ReportIRJoin(BaseNode):
    """Join specification in a report IR.

    Represents a join between two entities/objects in the report.

    ID format: {ir_id}.join.{index}
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.REPORT_IR_JOIN

    ir_id: str
    index: int
    from_entity: Optional[str] = None  # Source entity/object
    to_entity: Optional[str] = None  # Target entity/object
    from_field: Optional[str] = None  # Join key on source
    to_field: Optional[str] = None  # Join key on target
    join_type: Optional[str] = None  # inner, left, right, full
    relationship: Optional[str] = None  # one_to_one, one_to_many, many_to_one

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``{ir_id}.join.{index}``."""
        return f"{self.ir_id}.join.{self.index}"


class ReportIRGroupBy(BaseNode):
    """Grouping configuration in a report IR.

    Represents a grouping level in the report hierarchy.

    ID format: {ir_id}.groupby.{field_alias}
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.REPORT_IR_GROUPBY

    ir_id: str
    field_alias: str  # Reference to ReportIRField
    axis: Optional[str] = None  # row, column (for matrix reports)
    sequence: Optional[int] = None  # Order in grouping hierarchy
    subtotal: bool = False  # Whether to show subtotals
    sort_order: Optional[str] = None  # asc, desc
    sort_by: Optional[str] = None  # label, value, custom
    date_granularity: Optional[str] = None  # day, month, quarter, year

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``{ir_id}.groupby.{field_alias}``."""
        return f"{self.ir_id}.groupby.{self.field_alias}"


class ReportIRBucket(BaseNode):
    """Bucketing/binning configuration in a report IR.

    Represents a bucket field that groups values into ranges or categories.

    ID format: {ir_id}.bucket.{bucket_name}
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.REPORT_IR_BUCKET

    ir_id: str
    bucket_name: str
    source_field: Optional[str] = None  # Field being bucketed
    bucket_type: Optional[str] = None  # numeric_range, picklist, text_pattern
    ranges: Optional[str] = None  # JSON array of range definitions
    null_handling: Optional[str] = None  # include, exclude, separate
    other_bucket: bool = False  # Whether to include "Other" bucket

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``{ir_id}.bucket.{bucket_name}``."""
        return f"{self.ir_id}.bucket.{self.bucket_name}"


class ReportIRFormula(BaseNode):
    """Calculated field in a report IR.

    Represents a formula/calculated field in the report.
    Can be row-level or summary-level.

    ID format: {ir_id}.formula.{formula_name}
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.REPORT_IR_FORMULA

    ir_id: str
    formula_name: str
    formula_type: Optional[str] = None  # row, summary
    expression: Optional[str] = None  # Formula expression
    return_type: Optional[str] = None  # number, currency, percent, text
    decimal_places: Optional[int] = None
    format: Optional[str] = None
    description: Optional[str] = None

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``{ir_id}.formula.{formula_name}``."""
        return f"{self.ir_id}.formula.{self.formula_name}"


class ReportIRHighlight(BaseNode):
    """Conditional formatting rule in a report IR.

    Represents color-coding or highlighting rules for report values.

    ID format: {ir_id}.highlight.{index}
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.REPORT_IR_HIGHLIGHT

    ir_id: str
    index: int
    field_alias: Optional[str] = None  # Field to highlight
    conditions: Optional[str] = None  # JSON array of condition rules
    low_color: Optional[str] = None  # Color for low values
    mid_color: Optional[str] = None  # Color for mid values
    high_color: Optional[str] = None  # Color for high values
    low_breakpoint: Optional[float] = None
    high_breakpoint: Optional[float] = None

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``{ir_id}.highlight.{index}``."""
        return f"{self.ir_id}.highlight.{self.index}"


class ReportIRCrossFilter(BaseNode):
    """Cross-filter (exception report) in a report IR.

    Represents a cross-object filter for "with" or "without" logic.
    Used for exception reporting (e.g., Accounts without Opportunities).

    ID format: {ir_id}.crossfilter.{index}
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.REPORT_IR_CROSS_FILTER

    ir_id: str
    index: int
    mode: Optional[str] = None  # with, without
    related_entity: Optional[str] = None  # Related object/entity
    related_field: Optional[str] = None  # Field on related entity
    filter_conditions: Optional[str] = None  # JSON - additional filter on related records

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``{ir_id}.crossfilter.{index}``."""
        return f"{self.ir_id}.crossfilter.{self.index}"


__all__ = [
    # Phase 1
    "Report",
    "ReportIR",
    "ReportIRField",
    "NativeReportDefinition",
    "ReportRevision",
    # Phase 2
    "ReportIRFilter",
    "ReportIRJoin",
    "ReportIRGroupBy",
    "ReportIRBucket",
    "ReportIRFormula",
    "ReportIRHighlight",
    "ReportIRCrossFilter",
]
