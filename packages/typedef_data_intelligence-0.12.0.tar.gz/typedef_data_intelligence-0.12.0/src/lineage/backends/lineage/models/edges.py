"""Pydantic models for all graph edge types with pair-based validation.

This module defines strongly-typed edge classes for all relationship types in the lineage graph.
Each edge class:
1. Encodes its edge_type as a ClassVar
2. Specifies allowed_pairs as tuples of (from_node_type, to_node_type)
3. Validates node pair compatibility at runtime
4. Defines edge-specific properties

ALL edges now use pair-based validation to prevent cartesian product issues.

Edges are organized by category:
- Logical dbt edges (dependencies, materialization)
- Physical edges (builds, has_column)
- Data lineage edges (derives_from)
- OpenLineage edges (reads, writes, executions, errors)
- Inferred semantic edges (LLM-derived metadata)
- Native semantic edges (warehouse-declared metadata)
- Profiling edges (table/column profiles)
- Clustering edges (join patterns)
"""

from datetime import datetime
from typing import ClassVar, Optional

from lineage.backends.lineage.models.base import GraphEdge
from lineage.backends.lineage.models.clustering import InferredSubjectArea

# Import ALL node types for type validation
from lineage.backends.lineage.models.dbt import (
    CteScope,
    DbtColumn,
    DbtMacro,
    DbtModel,
    DbtSource,
    DbtTest,
    DbtUnitTest,
)
from lineage.backends.lineage.models.key_lineage import IdentityClass
from lineage.backends.lineage.models.openlineage import Dataset, Error, Job, Run
from lineage.backends.lineage.models.physical import (
    PhysicalColumn,
    PhysicalEphemeral,
    PhysicalIncrementalModel,
    PhysicalMaterializedView,
    PhysicalTable,
    PhysicalView,
)
from lineage.backends.lineage.models.profiling import ColumnProfile, TableProfile
from lineage.backends.lineage.models.report import (
    NativeReportDefinition,
    Report,
    ReportIR,
    ReportIRBucket,
    ReportIRCrossFilter,
    ReportIRField,
    ReportIRFilter,
    ReportIRFormula,
    ReportIRGroupBy,
    ReportIRHighlight,
    ReportIRJoin,
    ReportRevision,
)
from lineage.backends.lineage.models.salesforce import (
    SalesforceOrg,
    SfDashboard,
    SfDashboardComponent,
    SfField,
    SfObject,
    SfReport,
    SfReportColumn,
)
from lineage.backends.lineage.models.semantic_analysis import (
    InferredAuditFinding,
    InferredAuditPatch,
    InferredDimension,
    InferredFact,
    InferredFilter,
    InferredGrainToken,
    InferredGroupingScope,
    InferredMeasure,
    InferredOutputShape,
    InferredRelation,
    InferredSegment,
    InferredSelectItem,
    InferredSemanticModel,
    InferredTimeScope,
    InferredWindowScope,
    TimeAttribute,
    TimeWindow,
    WindowFunction,
)
from lineage.backends.lineage.models.semantic_analysis import (
    JoinEdge as JoinEdgeNode,
)
from lineage.backends.lineage.models.semantic_views import (
    NativeBaseTable,
    NativeDimension,
    NativeFact,
    NativeMeasure,
    NativeSemanticModel,
)
from lineage.backends.types import Confidence, EdgeType

# ==============================================================================
# LOGICAL dbt EDGES
# ==============================================================================


class DependsOn(GraphEdge):
    """Model depends on another model or source.

    Represents dbt model-to-model or model-to-source dependencies in the DAG.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.DEPENDS_ON
    allowed_pairs: ClassVar = [
        (DbtModel, DbtModel),
        (DbtModel, DbtSource),
    ]

    type: str  # "model", "source", "seed"
    direct: bool  # Whether this is a direct dependency
    inferred: bool = False  # True if extracted from compiled_sql (implicit dependency)


class Materializes(GraphEdge):
    """Logical model/source owns logical columns.

    Represents the relationship between a logical dbt model/source and its
    logical column definitions. This is separate from physical materialization.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.MATERIALIZES
    allowed_pairs: ClassVar = [
        (DbtModel, DbtColumn),
        (DbtSource, DbtColumn),
    ]

    # No additional properties for logical ownership


# ==============================================================================
# PHYSICAL EDGES
# ==============================================================================


class Builds(GraphEdge):
    """Logical dbt entity builds physical warehouse relation.

    Links logical dbt models/sources to their physical warehouse materializations.
    One logical entity can build multiple physical relations (dev, staging, prod).
    """

    edge_type: ClassVar[EdgeType] = EdgeType.BUILDS
    allowed_pairs: ClassVar = [
        (DbtModel, PhysicalTable),
        (DbtModel, PhysicalView),
        (DbtModel, PhysicalMaterializedView),
        (DbtModel, PhysicalIncrementalModel),
        (DbtModel, PhysicalEphemeral),
        (DbtSource, PhysicalTable),
        (DbtSource, PhysicalView),
    ]

    environment: str  # "dev", "staging", "prod", etc.
    materialization_strategy: Optional[str] = None  # "full-refresh", "incremental", etc.
    deployed_at: Optional[datetime] = None  # When this materialization was created


class HasColumn(GraphEdge):
    """Physical relation has physical columns.

    Links physical warehouse tables/views to their actual columns.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_COLUMN
    allowed_pairs: ClassVar = [
        (PhysicalTable, PhysicalColumn),
        (PhysicalView, PhysicalColumn),
        (PhysicalMaterializedView, PhysicalColumn),
        (PhysicalIncrementalModel, PhysicalColumn),
    ]

    # No additional properties


# ==============================================================================
# DATA LINEAGE EDGES
# ==============================================================================


class DerivesFrom(GraphEdge):
    """Entity derives from source data (DATA LINEAGE).

    Consolidated edge for all data lineage relationships. Tracks how data
    flows from source columns to derived columns/measures/dimensions/facts.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.DERIVES_FROM
    merge_keys: ClassVar[tuple[str, ...]] = ("column_name",)
    allowed_pairs: ClassVar = [
        # Logical column lineage
        (DbtColumn, DbtColumn),

        # Physical column from logical column
        (PhysicalColumn, DbtColumn),

        # Inferred semantic components from logical columns
        (InferredMeasure, DbtColumn),
        (InferredDimension, DbtColumn),
        (InferredFact, DbtColumn),

        # Native semantic components from logical columns
        (NativeMeasure, DbtColumn),
        (NativeDimension, DbtColumn),
        (NativeFact, DbtColumn),

        # Report IR field lineage
        (ReportIRField, DbtColumn),
        (ReportIRField, PhysicalColumn),
        (ReportIRField, SfField),
        (ReportIRField, InferredMeasure),
        (ReportIRField, InferredDimension),

        # CTE scope-level lineage (internal CTE transformations)
        (CteScope, CteScope),
        (CteScope, DbtColumn),
    ]

    confidence: Optional[Confidence] = None
    transformation: Optional[str] = None  # Description of transformation
    expr: Optional[str] = None  # Expression (e.g., "SUM(revenue)")

    # Scope-level edge properties (used for CteScope and enriched DbtColumn edges)
    scope: Optional[str] = None  # Scope name where this transformation occurs
    column_name: Optional[str] = None  # Column name within the scope
    upstream_column: Optional[str] = None  # Upstream column name in the source scope
    function_name: Optional[str] = None  # Function applied (e.g., "ROW_NUMBER", "SUM")


class StructurallyUses(GraphEdge):
    """Column participates in a structural SQL clause.

    Tracks columns used in WHERE, JOIN ON, GROUP BY, ORDER BY, HAVING, and
    window specs without contributing value to a specific output column.
    Kept separate from DERIVES_FROM for clean semantic distinction.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.STRUCTURALLY_USES
    merge_keys: ClassVar[tuple[str, ...]] = ("column_name",)
    allowed_pairs: ClassVar = [
        (DbtColumn, DbtColumn),
        (DbtModel, DbtColumn),
        (CteScope, CteScope),
        (CteScope, DbtColumn),
    ]

    confidence: Optional[Confidence] = None
    transformation: Optional[str] = None
    expr: Optional[str] = None
    scope: Optional[str] = None
    column_name: Optional[str] = None
    upstream_column: Optional[str] = None


# ==============================================================================
# MACRO EDGES (dbt)
# ==============================================================================


class UsesMacro(GraphEdge):
    """Model (or other artifact) uses a macro.

    Initial use case: dbt models declare macro dependencies in manifest via
    depends_on.macros. This edge allows agents to trace macro changes to model
    behavior (especially in macro-heavy projects).
    """

    edge_type: ClassVar[EdgeType] = EdgeType.USES_MACRO
    allowed_pairs: ClassVar = [
        (DbtModel, DbtMacro),
    ]


class CallsMacro(GraphEdge):
    """Macro calls another macro."""

    edge_type: ClassVar[EdgeType] = EdgeType.CALLS_MACRO
    allowed_pairs: ClassVar = [
        (DbtMacro, DbtMacro),
    ]


class HasCteScope(GraphEdge):
    """Model contains a CTE scope."""

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_CTE_SCOPE
    allowed_pairs: ClassVar = [
        (DbtModel, CteScope),
    ]


# ==============================================================================
# dbt TEST EDGES
# ==============================================================================


class HasTest(GraphEdge):
    """Model or source has a data test.

    Links dbt models/sources to their data tests (generic or singular).
    Uses depends_on from manifest for reliable mapping.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_TEST
    allowed_pairs: ClassVar = [
        (DbtModel, DbtTest),
        (DbtSource, DbtTest),
    ]

    # No additional properties


class HasUnitTest(GraphEdge):
    """Model has a unit test.

    Links dbt models to their unit tests (dbt v1.8+).
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_UNIT_TEST
    allowed_pairs: ClassVar = [(DbtModel, DbtUnitTest)]

    # No additional properties


class TestsColumn(GraphEdge):
    """Test tests a specific column.

    Links column-scoped tests (unique, not_null, etc.) to the column being tested.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.TESTS_COLUMN
    allowed_pairs: ClassVar = [(DbtTest, DbtColumn)]

    # No additional properties


class TestReferences(GraphEdge):
    """Relationship test references another model/source.

    For relationship tests, tracks the "to" target model/source.
    E.g., test "relationships" with to: ref('customers') references customers model.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.TEST_REFERENCES
    allowed_pairs: ClassVar = [
        (DbtTest, DbtModel),
        (DbtTest, DbtSource),
    ]

    referenced_field: Optional[str] = None  # The field in the referenced model


# ==============================================================================
# OPENLINEAGE EDGES
# ==============================================================================


class Reads(GraphEdge):
    """Job reads dataset.

    Represents a job reading a dataset as input.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.READS
    allowed_pairs: ClassVar = [(Job, Dataset)]

    run_id: Optional[str] = None  # Optional run ID for run-specific reads


class Writes(GraphEdge):
    """Job writes dataset.

    Represents a job writing a dataset as output.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.WRITES
    allowed_pairs: ClassVar = [(Job, Dataset)]

    run_id: Optional[str] = None  # Optional run ID for run-specific writes


class InstanceOf(GraphEdge):
    """Run is instance of job.

    Links a run execution to its parent job.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.INSTANCE_OF
    allowed_pairs: ClassVar = [(Run, Job)]

    edge_id: str  # Unique edge identifier


class SameAs(GraphEdge):
    """Dataset refers to physical warehouse entity.

    Links OpenLineage datasets to physical warehouse relations.
    Replaces old SameAsModel/SameAsSource edges.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.SAME_AS
    allowed_pairs: ClassVar = [
        (Dataset, PhysicalTable),
        (Dataset, PhysicalView),
        (Dataset, PhysicalMaterializedView),
        (Dataset, PhysicalIncrementalModel),
    ]

    confidence: Confidence  # Confidence level in the match
    match_method: str  # "fqn_exact", "pattern_match", "manual"


class HasError(GraphEdge):
    """Run has error.

    Links a run to an error pattern that occurred during execution.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_ERROR
    allowed_pairs: ClassVar = [(Run, Error)]

    occurred_at: str  # ISO 8601 timestamp when error occurred


class Executes(GraphEdge):
    """Job executes logical dbt model.

    Links OpenLineage jobs to the logical dbt models they run.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.DEPENDS_ON  # Reuse DEPENDS_ON type
    allowed_pairs: ClassVar = [(Job, DbtModel)]

    # No additional properties


# ==============================================================================
# INFERRED SEMANTIC EDGES (LLM-derived)
# ==============================================================================


class HasInferredSemantics(GraphEdge):
    """Model has inferred semantic metadata.

    Links a dbt model to its LLM-inferred semantic analysis container.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_INFERRED_SEMANTICS
    allowed_pairs: ClassVar = [(DbtModel, InferredSemanticModel)]

    # No additional properties


class HasMeasure(GraphEdge):
    """Semantic model has measure.

    Links semantic models (inferred or native) to their measure definitions.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_MEASURE
    allowed_pairs: ClassVar = [
        (InferredSemanticModel, InferredMeasure),
        (NativeSemanticModel, NativeMeasure),
    ]

    output_alias: Optional[str] = None  # Alias in SELECT clause


class HasDimension(GraphEdge):
    """Semantic model has dimension.

    Links semantic models (inferred or native) to their dimension definitions.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_DIMENSION
    allowed_pairs: ClassVar = [
        (InferredSemanticModel, InferredDimension),
        (NativeSemanticModel, NativeDimension),
    ]

    output_alias: Optional[str] = None  # Alias in SELECT clause


class HasFact(GraphEdge):
    """Semantic model has fact.

    Links semantic models (inferred or native) to their fact definitions.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_FACT
    allowed_pairs: ClassVar = [
        (InferredSemanticModel, InferredFact),
        (NativeSemanticModel, NativeFact),
    ]

    # No additional properties


class HasSegment(GraphEdge):
    """Inferred semantic model has segment.

    Links inferred semantic models to business segment definitions.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_SEGMENT
    allowed_pairs: ClassVar = [(InferredSemanticModel, InferredSegment)]

    # No additional properties


class HasTimeWindow(GraphEdge):
    """Inferred semantic model has time window.

    Links inferred semantic models to time window filters.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_TIME_WINDOW
    allowed_pairs: ClassVar = [(InferredSemanticModel, TimeWindow)]

    # No additional properties


class HasTimeAttribute(GraphEdge):
    """Inferred semantic model has time attribute.

    Links inferred semantic models to time-based filter attributes.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_TIME_ATTRIBUTE
    allowed_pairs: ClassVar = [(InferredSemanticModel, TimeAttribute)]

    # No additional properties


class HasJoinEdge(GraphEdge):
    """Inferred semantic model has join edge.

    Links inferred semantic models to join relationship nodes.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_JOIN_EDGE
    allowed_pairs: ClassVar = [(InferredSemanticModel, JoinEdgeNode)]

    # No additional properties


class HasWindowFunction(GraphEdge):
    """Inferred semantic model has window function.

    Links inferred semantic models to window/analytic functions.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_WINDOW_FUNCTION
    allowed_pairs: ClassVar = [(InferredSemanticModel, WindowFunction)]

    # No additional properties


class HasRelation(GraphEdge):
    """Inferred semantic model has relation use.

    Links inferred semantic models to relation occurrences (tables/views/CTEs).
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_RELATION
    allowed_pairs: ClassVar = [(InferredSemanticModel, InferredRelation)]

    # No additional properties


class ResolvesToModel(GraphEdge):
    """Inferred relation resolves to dbt model.

    Links relation aliases to actual DbtModel nodes when resolvable.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.RESOLVES_TO_MODEL
    allowed_pairs: ClassVar = [(InferredRelation, DbtModel), (InferredRelation, DbtSource)]

    confidence: Optional[str] = None  # high, medium, low


class HasFilter(GraphEdge):
    """Inferred semantic model has filter predicate.

    Links inferred semantic models to filter predicates (WHERE/HAVING/QUALIFY).
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_FILTER
    allowed_pairs: ClassVar = [(InferredSemanticModel, InferredFilter)]

    # No additional properties


class FiltersRelation(GraphEdge):
    """Filter applies to relation.

    Links filter predicates to the relation they filter.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.FILTERS_RELATION
    allowed_pairs: ClassVar = [(InferredFilter, InferredRelation)]

    # No additional properties


class HasGroupingScope(GraphEdge):
    """Inferred semantic model has grouping scope.

    Links inferred semantic models to per-scope grouping analysis.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_GROUPING_SCOPE
    allowed_pairs: ClassVar = [(InferredSemanticModel, InferredGroupingScope)]

    # No additional properties


class HasSelectItem(GraphEdge):
    """Grouping scope has select item.

    Links grouping scopes to SELECT items.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_SELECT_ITEM
    allowed_pairs: ClassVar = [(InferredGroupingScope, InferredSelectItem)]

    # No additional properties


class HasTimeScope(GraphEdge):
    """Inferred semantic model has time scope.

    Links inferred semantic models to per-scope time analysis.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_TIME_SCOPE
    allowed_pairs: ClassVar = [(InferredSemanticModel, InferredTimeScope)]

    # No additional properties


class HasWindowScope(GraphEdge):
    """Inferred semantic model has window scope.

    Links inferred semantic models to per-scope window function analysis.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_WINDOW_SCOPE
    allowed_pairs: ClassVar = [(InferredSemanticModel, InferredWindowScope)]

    # No additional properties


class HasOutputShape(GraphEdge):
    """Inferred semantic model has output shape.

    Links inferred semantic models to per-scope output shape analysis.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_OUTPUT_SHAPE
    allowed_pairs: ClassVar = [(InferredSemanticModel, InferredOutputShape)]

    # No additional properties


class HasAuditFinding(GraphEdge):
    """Inferred semantic model has audit finding.

    Links inferred semantic models to audit findings from validation.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_AUDIT_FINDING
    allowed_pairs: ClassVar = [(InferredSemanticModel, InferredAuditFinding)]

    # No additional properties


class HasAuditPatch(GraphEdge):
    """Inferred semantic model has audit patch.

    Links inferred semantic models to suggested patches from audit.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_AUDIT_PATCH
    allowed_pairs: ClassVar = [(InferredSemanticModel, InferredAuditPatch)]

    # No additional properties


class HasGrainToken(GraphEdge):
    """Inferred semantic model has grain token.

    Links inferred semantic models to grain tokens from humanization.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_GRAIN_TOKEN
    allowed_pairs: ClassVar = [(InferredSemanticModel, InferredGrainToken)]

    # No additional properties


class InferredJoinsWith(GraphEdge):
    """Model joins with another via inferred join edge.

    Links dbt models to JoinEdge nodes when aliases are resolved.
    This is bidirectional - both models link to the same JoinEdge.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.INFERRED_JOINS_WITH
    allowed_pairs: ClassVar = [(DbtModel, JoinEdgeNode), (DbtSource, JoinEdgeNode)]

    confidence: Optional[str] = None  # high, medium, low


class JoinsLeftModel(GraphEdge):
    """Join edge joins with left model.

    Direct link from JoinEdge to resolved left DbtModel.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.JOINS_LEFT_MODEL
    allowed_pairs: ClassVar = [(JoinEdgeNode, DbtModel), (JoinEdgeNode, DbtSource)]

    # No additional properties


class JoinsRightModel(GraphEdge):
    """Join edge joins with right model.

    Direct link from JoinEdge to resolved right DbtModel.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.JOINS_RIGHT_MODEL
    allowed_pairs: ClassVar = [(JoinEdgeNode, DbtModel), (JoinEdgeNode, DbtSource)]

    # No additional properties


# ==============================================================================
# NATIVE SEMANTIC EDGES (warehouse-declared)
# ==============================================================================


class DrawsFrom(GraphEdge):
    """Native semantic model draws from dbt model.

    Links warehouse-native semantic models to the dbt models they reference.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.DRAWS_FROM
    allowed_pairs: ClassVar = [(NativeSemanticModel, DbtModel)]

    # No additional properties


class HasSemanticTable(GraphEdge):
    """Native semantic model has base table.

    Links native semantic models to their base table definitions.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_SEMANTIC_TABLE
    allowed_pairs: ClassVar = [(NativeSemanticModel, NativeBaseTable)]

    # No additional properties


# ==============================================================================
# PROFILING EDGES
# ==============================================================================


class HasProfile(GraphEdge):
    """Physical entity has profile.

    Links physical relations/columns to their statistical profiles.
    Uses pair validation to prevent invalid combinations.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_PROFILE
    allowed_pairs: ClassVar = [
        # Physical relations have table profiles
        (PhysicalTable, TableProfile),
        (PhysicalView, TableProfile),
        (PhysicalMaterializedView, TableProfile),
        (PhysicalIncrementalModel, TableProfile),

        # Physical columns have column profiles
        (PhysicalColumn, ColumnProfile),

        # Profiling loader links logical nodes directly
        (DbtModel, TableProfile),
        (DbtColumn, ColumnProfile),
    ]

    # No additional properties


class HasColumnProfile(GraphEdge):
    """Table profile has column profile.

    Links table profiles to their component column profiles.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_COLUMN_PROFILE
    allowed_pairs: ClassVar = [(TableProfile, ColumnProfile)]

    # No additional properties


# ==============================================================================
# JOIN CLUSTERING EDGES
# ==============================================================================


class JoinsWith(GraphEdge):
    """Model joins with another via join edge.

    Links dbt models to JoinEdge nodes representing joins in their SQL.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.JOINS_WITH
    allowed_pairs: ClassVar = [(DbtModel, JoinEdgeNode)]

    # No additional properties


class BelongsToSubjectArea(GraphEdge):
    """Model belongs to inferred subject area.

    Links dbt models to inferred subject areas based on business domain and join patterns.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.BELONGS_TO_SUBJECT_AREA
    allowed_pairs: ClassVar = [(DbtModel, InferredSubjectArea)]

    # No additional properties


# ==============================================================================
# SALESFORCE INTERNAL EDGES
# ==============================================================================


class SfHasObject(GraphEdge):
    """Salesforce org has SObject."""

    edge_type: ClassVar[EdgeType] = EdgeType.SF_HAS_OBJECT
    allowed_pairs: ClassVar = [(SalesforceOrg, SfObject)]


class SfHasField(GraphEdge):
    """SObject has field."""

    edge_type: ClassVar[EdgeType] = EdgeType.SF_HAS_FIELD
    allowed_pairs: ClassVar = [(SfObject, SfField)]


class SfReferences(GraphEdge):
    """Lookup/MasterDetail field references another SObject."""

    edge_type: ClassVar[EdgeType] = EdgeType.SF_REFERENCES
    allowed_pairs: ClassVar = [(SfField, SfObject)]

    relationship_type: Optional[str] = None  # Lookup, MasterDetail, ExternalLookup


class SfHasReport(GraphEdge):
    """Salesforce org has report."""

    edge_type: ClassVar[EdgeType] = EdgeType.SF_HAS_REPORT
    allowed_pairs: ClassVar = [(SalesforceOrg, SfReport)]


class SfReportHasColumn(GraphEdge):
    """Report has column."""

    edge_type: ClassVar[EdgeType] = EdgeType.SF_REPORT_HAS_COLUMN
    allowed_pairs: ClassVar = [(SfReport, SfReportColumn)]


class SfReportColumnUsesField(GraphEdge):
    """Report column resolves to a field on an SObject."""

    edge_type: ClassVar[EdgeType] = EdgeType.SF_REPORT_COLUMN_USES_FIELD
    allowed_pairs: ClassVar = [(SfReportColumn, SfField)]

    resolution: str = "exact"  # exact, heuristic, unresolved
    confidence: float = 1.0


class SfReportDependsOnObject(GraphEdge):
    """Report depends on an SObject (primary or joined)."""

    edge_type: ClassVar[EdgeType] = EdgeType.SF_REPORT_DEPENDS_ON_OBJECT
    allowed_pairs: ClassVar = [(SfReport, SfObject)]

    role: str = "unknown"  # primary, joined, unknown
    confidence: float = 1.0


class SfHasDashboard(GraphEdge):
    """Salesforce org has dashboard."""

    edge_type: ClassVar[EdgeType] = EdgeType.SF_HAS_DASHBOARD
    allowed_pairs: ClassVar = [(SalesforceOrg, SfDashboard)]


class SfDashboardHasComponent(GraphEdge):
    """Dashboard has component."""

    edge_type: ClassVar[EdgeType] = EdgeType.SF_DASHBOARD_HAS_COMPONENT
    allowed_pairs: ClassVar = [(SfDashboard, SfDashboardComponent)]


class SfComponentUsesReport(GraphEdge):
    """Dashboard component uses a report."""

    edge_type: ClassVar[EdgeType] = EdgeType.SF_COMPONENT_USES_REPORT
    allowed_pairs: ClassVar = [(SfDashboardComponent, SfReport)]


# ==============================================================================
# SALESFORCE <-> dbt STITCHING EDGES
# ==============================================================================


class SourceDependsOn(GraphEdge):
    """DbtSource depends on an SfObject as its upstream data provider.

    Created during cross-domain stitching (deterministic or LLM-assisted).
    Direction: DbtSource -> DEPENDS_ON -> SfObject
    """

    edge_type: ClassVar[EdgeType] = EdgeType.DEPENDS_ON
    allowed_pairs: ClassVar = [(DbtSource, SfObject)]

    source: str = "heuristic"  # declared, heuristic, llm
    confidence: float = 1.0
    rule_id: Optional[str] = None  # e.g. exact_name, strip_suffix, llm_small


class MapsToColumn(GraphEdge):
    """SfField or SfReportColumn maps to a DbtColumn.

    Created during cross-domain stitching (deterministic or LLM-assisted).
    """

    edge_type: ClassVar[EdgeType] = EdgeType.MAPS_TO_COLUMN
    allowed_pairs: ClassVar = [
        (SfField, DbtColumn),
        (SfReportColumn, DbtColumn),
    ]

    source: str = "heuristic"  # declared, heuristic, llm
    confidence: float = 1.0
    rule_id: Optional[str] = None


# ==============================================================================
# GENERIC REPORT EDGES
# ==============================================================================


class NativeInstanceOf(GraphEdge):
    """Native vendor report is instance of canonical Report.

    Links vendor-specific reports (SfReport, LookerLook, etc.) to the
    canonical Report spine for cross-platform queries.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.NATIVE_INSTANCE_OF
    allowed_pairs: ClassVar = [(SfReport, Report)]

    synced_at: Optional[str] = None


class HasIR(GraphEdge):
    """Report has intermediate representation.

    Links a Report to its canonical IR structure.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_IR
    allowed_pairs: ClassVar = [(Report, ReportIR)]

    # No additional properties


class HasNativeDefinition(GraphEdge):
    """Report has raw vendor-specific definition.

    Links a Report to its raw definition from the BI platform.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_NATIVE_DEFINITION
    allowed_pairs: ClassVar = [(Report, NativeReportDefinition)]

    # No additional properties


class HasIRField(GraphEdge):
    """Report IR has field reference.

    Links a ReportIR to its field definitions with sequence ordering.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_IR_FIELD
    allowed_pairs: ClassVar = [(ReportIR, ReportIRField)]

    sequence: Optional[int] = None


class HasRevision(GraphEdge):
    """Report has revision history.

    Links a Report to its historical revisions for versioning.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_REVISION
    allowed_pairs: ClassVar = [(Report, ReportRevision)]

    # No additional properties


class RevisionHasIR(GraphEdge):
    """Revision links to IR snapshot.

    Links a ReportRevision to the IR that was active at that point in time.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.REVISION_HAS_IR
    allowed_pairs: ClassVar = [(ReportRevision, ReportIR)]

    # No additional properties


class MapsToNativeField(GraphEdge):
    """IR field maps to native report column.

    Links a ReportIRField to the vendor-specific column it represents.
    Also links Phase 2 IR nodes (GroupBy, Filter, Bucket) that reference
    native fields directly.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.MAPS_TO_NATIVE_FIELD
    allowed_pairs: ClassVar = [
        (ReportIRField, SfReportColumn),
        (ReportIRGroupBy, SfReportColumn),
        (ReportIRFilter, SfReportColumn),
        (ReportIRBucket, SfReportColumn),
        (ReportIRFormula, SfReportColumn),
        (ReportIRJoin, SfReportColumn),
        (ReportIRHighlight, SfReportColumn),
        (ReportIRCrossFilter, SfReportColumn),
    ]

    mapping_type: str = "exact"  # exact, transformed, computed
    confidence: float = 1.0


class ReportDependsOn(GraphEdge):
    """Report depends on data entity.

    Links a Report to the data entities it consumes (objects, models, tables).
    """

    edge_type: ClassVar[EdgeType] = EdgeType.REPORT_DEPENDS_ON
    allowed_pairs: ClassVar = [
        (Report, SfObject),
        (Report, DbtModel),
        (Report, NativeSemanticModel),
        (Report, PhysicalTable),
    ]

    role: str = "unknown"  # primary, joined, lookup
    confidence: float = 1.0


# ==============================================================================
# GENERIC REPORT EDGES (Phase 2 - Full IR Structure)
# ==============================================================================


class HasIRFilter(GraphEdge):
    """Report IR has filter predicate.

    Links a ReportIR to its filter conditions.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_IR_FILTER
    allowed_pairs: ClassVar = [(ReportIR, ReportIRFilter)]

    sequence: Optional[int] = None


class HasIRJoin(GraphEdge):
    """Report IR has join specification.

    Links a ReportIR to its join definitions.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_IR_JOIN
    allowed_pairs: ClassVar = [(ReportIR, ReportIRJoin)]

    sequence: Optional[int] = None


class HasIRGroupBy(GraphEdge):
    """Report IR has grouping configuration.

    Links a ReportIR to its grouping hierarchy.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_IR_GROUPBY
    allowed_pairs: ClassVar = [(ReportIR, ReportIRGroupBy)]

    # No additional properties


class HasIRBucket(GraphEdge):
    """Report IR has bucket configuration.

    Links a ReportIR to its bucket field definitions.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_IR_BUCKET
    allowed_pairs: ClassVar = [(ReportIR, ReportIRBucket)]

    # No additional properties


class HasIRFormula(GraphEdge):
    """Report IR has calculated field.

    Links a ReportIR to its formula field definitions.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_IR_FORMULA
    allowed_pairs: ClassVar = [(ReportIR, ReportIRFormula)]

    # No additional properties


class HasIRHighlight(GraphEdge):
    """Report IR has conditional formatting.

    Links a ReportIR to its highlight/color rules.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_IR_HIGHLIGHT
    allowed_pairs: ClassVar = [(ReportIR, ReportIRHighlight)]

    # No additional properties


class HasIRCrossFilter(GraphEdge):
    """Report IR has cross-filter.

    Links a ReportIR to its cross-object filter definitions.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HAS_IR_CROSS_FILTER
    allowed_pairs: ClassVar = [(ReportIR, ReportIRCrossFilter)]

    # No additional properties


class HighlightsFormula(GraphEdge):
    """Highlight references a formula field.

    Links a ReportIRHighlight to the ReportIRFormula it applies
    conditional formatting to (when field_alias starts with FORMULA_).
    """

    edge_type: ClassVar[EdgeType] = EdgeType.HIGHLIGHTS_FORMULA
    allowed_pairs: ClassVar = [(ReportIRHighlight, ReportIRFormula)]

    # No additional properties


# ==============================================================================
# KEY LINEAGE EDGES
# ==============================================================================


class BelongsToIdentityClass(GraphEdge):
    """Column belongs to an identity class.

    Links DbtColumn (or SfField) nodes to their IdentityClass, indicating
    that the column represents the same entity identifier as other members.
    SfFields join via post-hoc MapsToColumn linkage after IC construction.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.BELONGS_TO_IDENTITY_CLASS
    allowed_pairs: ClassVar = [
        (DbtColumn, IdentityClass),
        (SfField, IdentityClass),
    ]

    role: str = "key"  # "pk", "fk", "key" (undetermined), or "external"
    confidence: float = 0.0


class InferredFK(GraphEdge):
    """Inferred foreign key relationship between columns.

    Links a FK column to a PK column based on IdentityClass membership
    and PK/FK role inference. Direction: FK column -> PK column.
    """

    edge_type: ClassVar[EdgeType] = EdgeType.INFERRED_FK
    allowed_pairs: ClassVar = [(DbtColumn, DbtColumn)]

    identity_class_id: str = ""
    cardinality: str = "many_to_one"  # many_to_one, one_to_one, many_to_many
    confidence: float = 0.0
    signals: list[str] = []
    confirmed_by_join: bool = False
    confirmed_by_test: bool = False
    is_composite: bool = False
    composite_group: str = ""


# ==============================================================================
# EXPORTS
# ==============================================================================

__all__ = [
    # Logical dbt edges
    "DependsOn",
    "Materializes",
    "HasCteScope",

    # dbt test edges
    "HasTest",
    "HasUnitTest",
    "TestsColumn",
    "TestReferences",

    # Physical edges
    "Builds",
    "HasColumn",

    # Data lineage
    "DerivesFrom",
    "StructurallyUses",

    # OpenLineage edges
    "Reads",
    "Writes",
    "InstanceOf",
    "SameAs",
    "HasError",
    "Executes",

    # Inferred semantic edges
    "HasInferredSemantics",
    "HasMeasure",
    "HasDimension",
    "HasFact",
    "HasSegment",
    "HasTimeWindow",
    "HasTimeAttribute",
    "HasJoinEdge",
    "HasWindowFunction",
    # New formalized semantic edges
    "HasRelation",
    "ResolvesToModel",
    "HasFilter",
    "FiltersRelation",
    "HasGroupingScope",
    "HasSelectItem",
    "HasTimeScope",
    "HasWindowScope",
    "HasOutputShape",
    "HasAuditFinding",
    "HasAuditPatch",
    "HasGrainToken",
    "InferredJoinsWith",
    "JoinsLeftModel",
    "JoinsRightModel",

    # Native semantic edges
    "DrawsFrom",
    "HasSemanticTable",

    # Profiling edges
    "HasProfile",
    "HasColumnProfile",

    # Clustering edges
    "JoinsWith",
    "BelongsToSubjectArea",

    # Key lineage edges
    "BelongsToIdentityClass",
    "InferredFK",

    # Salesforce internal edges
    "SfHasObject",
    "SfHasField",
    "SfReferences",
    "SfHasReport",
    "SfReportHasColumn",
    "SfReportColumnUsesField",
    "SfReportDependsOnObject",
    "SfHasDashboard",
    "SfDashboardHasComponent",
    "SfComponentUsesReport",

    # Salesforce <-> dbt stitching edges
    "SourceDependsOn",
    "MapsToColumn",

    # Generic report edges (Phase 1)
    "NativeInstanceOf",
    "HasIR",
    "HasNativeDefinition",
    "HasIRField",
    "HasRevision",
    "RevisionHasIR",
    "MapsToNativeField",
    "ReportDependsOn",

    # Generic report edges (Phase 2)
    "HasIRFilter",
    "HasIRJoin",
    "HasIRGroupBy",
    "HasIRBucket",
    "HasIRFormula",
    "HasIRHighlight",
    "HasIRCrossFilter",
    "HighlightsFormula",
]
