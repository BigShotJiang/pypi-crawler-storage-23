"""Pydantic models for key lineage graph nodes.

These models represent inferred key identity metadata:
- IdentityClass: Equivalence class of columns representing the same entity key
"""

from typing import ClassVar

from pydantic import computed_field

from lineage.backends.lineage.models.base import BaseNode
from lineage.backends.types import NodeLabel


class IdentityClass(BaseNode):
    """Equivalence class of columns representing the same entity identifier.

    An IdentityClass groups DbtColumn nodes that represent the same logical
    entity key across different models (e.g., account_id in staging, intermediate,
    and mart layers). Membership is determined by identity-preserving DERIVES_FROM
    edges (passthrough, renamed, group_key, certain computed transforms).

    The ID is derived from the cluster_id, which is based on the root column
    (the earliest ancestor with no upstream identity-preserving edge).
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.IDENTITY_CLASS

    entity_name: str = ""
    source_model: str = ""
    cluster_id: str = ""
    member_count: int = 0
    has_pk: bool = False
    has_fk: bool = False

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID from cluster_id."""
        return self.cluster_id


__all__ = ["IdentityClass"]
