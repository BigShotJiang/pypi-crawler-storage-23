"""Pydantic models for Salesforce upstream metadata nodes.

This module defines models for Salesforce org, object, field, report,
dashboard, and component metadata ingested as upstream sources in the
lineage graph.

Node types:
- SalesforceOrg: Salesforce organization instance
- SfObject: SObject (standard or custom)
- SfField: Field on an SObject
- SfReport: Salesforce report
- SfReportColumn: Column within a report
- SfDashboard: Salesforce dashboard
- SfDashboardComponent: Component within a dashboard
"""
from __future__ import annotations

import hashlib
from typing import ClassVar, Optional

from pydantic import computed_field

from lineage.backends.lineage.models.base import BaseNode
from lineage.backends.types import NodeLabel


def _stable_hash(parts: tuple[str, ...], length: int = 12) -> str:
    """Generate a truncated SHA-256 hex digest from string parts.

    Used to create deterministic keys for report columns and dashboard
    components that lack a stable identifier from the Salesforce API.

    Args:
        parts: Tuple of strings to hash.
        length: Number of hex characters to return (default 12).

    Returns:
        Truncated hex digest string.
    """
    payload = "|".join(parts)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:length]


class SalesforceOrg(BaseNode):
    """Salesforce organization instance.

    Represents a single Salesforce org whose metadata has been ingested.
    Serves as the root node for all SF assets belonging to this org.
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.SF_ORG

    org_key: str
    instance_url: str
    org_type: Optional[str] = None  # Production, Sandbox, Developer, etc.
    api_version: Optional[str] = None
    fetched_at: Optional[str] = None  # ISO 8601 timestamp

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``sf_org::{org_key}``."""
        return f"sf_org::{self.org_key}"


class SfObject(BaseNode):
    """Salesforce SObject (standard or custom).

    Represents an object definition (e.g. Account, Opportunity, MyObj__c)
    within a Salesforce org.
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.SF_OBJECT

    api_name: str
    org_key: str
    is_custom: bool = False
    is_queryable: bool = True
    key_prefix: Optional[str] = None
    description: Optional[str] = None

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``sf_object::{org_key}::{api_name}``."""
        return f"sf_object::{self.org_key}::{self.api_name}"


class SfField(BaseNode):
    """Field on a Salesforce SObject.

    Represents a single field definition including its type, relationships,
    and formula information.
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.SF_FIELD

    field_api_name: str
    object_api_name: str
    org_key: str
    data_type: Optional[str] = None
    is_custom: bool = False
    is_nillable: bool = True
    length: Optional[int] = None
    reference_to: Optional[list[str]] = None  # Target object(s) for lookup fields
    formula: Optional[str] = None
    description: Optional[str] = None

    # Grain inference & data quality
    is_unique: bool = False
    is_external_id: bool = False
    default_value: Optional[str] = None
    default_value_formula: Optional[str] = None
    is_restricted_picklist: bool = False
    picklist_values: Optional[list[str]] = None
    is_case_sensitive: bool = False

    # Type precision
    scale: Optional[int] = None
    precision: Optional[int] = None
    digits: Optional[int] = None

    # Mutability
    is_updateable: bool = False
    is_createable: bool = False

    # Analytics / query capability
    is_filterable: bool = False
    is_sortable: bool = False
    is_groupable: bool = False
    is_aggregatable: bool = False

    # Documentation
    inline_help_text: Optional[str] = None
    compound_field_name: Optional[str] = None
    extra_type_info: Optional[str] = None
    display_format: Optional[str] = None

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``sf_field::{org_key}::{object_api_name}::{field_api_name}``."""
        return f"sf_field::{self.org_key}::{self.object_api_name}::{self.field_api_name}"


class SfReport(BaseNode):
    """Salesforce report.

    Represents a report definition within a Salesforce org.
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.SF_REPORT

    report_id: str
    org_key: str
    report_type: Optional[str] = None
    folder_name: Optional[str] = None
    description: Optional[str] = None
    report_format: Optional[str] = None  # tabular, summary, matrix, joined
    fetched_at: Optional[str] = None  # ISO 8601 timestamp
    content_hash: Optional[str] = None  # SHA-256 of raw API response for change detection

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``sf_report::{org_key}::{report_id}``."""
        return f"sf_report::{self.org_key}::{self.report_id}"


class SfReportColumn(BaseNode):
    """Column within a Salesforce report.

    If the report metadata provides a stable key it is used directly.
    Otherwise a deterministic hash of (label, position, internal_name)
    is generated via ``_stable_hash``.
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.SF_REPORT_COLUMN

    column_key: str
    report_id: str
    org_key: str
    data_type: Optional[str] = None
    object_api_name: Optional[str] = None  # SObject this column belongs to

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``sf_report_col::{org_key}::{report_id}::{column_key}``."""
        return f"sf_report_col::{self.org_key}::{self.report_id}::{self.column_key}"


class SfDashboard(BaseNode):
    """Salesforce dashboard.

    Represents a dashboard definition within a Salesforce org.
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.SF_DASHBOARD

    dashboard_id: str
    org_key: str
    folder_name: Optional[str] = None
    description: Optional[str] = None
    fetched_at: Optional[str] = None  # ISO 8601 timestamp

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``sf_dashboard::{org_key}::{dashboard_id}``."""
        return f"sf_dashboard::{self.org_key}::{self.dashboard_id}"


class SfDashboardComponent(BaseNode):
    """Component within a Salesforce dashboard.

    A dashboard component typically references a single report.
    If the metadata provides a stable key it is used directly;
    otherwise a deterministic hash is generated.
    """

    node_label: ClassVar[NodeLabel] = NodeLabel.SF_DASHBOARD_COMPONENT

    component_key: str
    dashboard_id: str
    org_key: str
    component_type: Optional[str] = None
    report_id: Optional[str] = None  # May be None if component has no linked report

    @computed_field
    @property
    def id(self) -> str:
        """Generate unique ID: ``sf_dash_comp::{org_key}::{dashboard_id}::{component_key}``."""
        return f"sf_dash_comp::{self.org_key}::{self.dashboard_id}::{self.component_key}"


__all__ = [
    "SalesforceOrg",
    "SfObject",
    "SfField",
    "SfReport",
    "SfReportColumn",
    "SfDashboard",
    "SfDashboardComponent",
    "_stable_hash",
]
