"""Redis-based read-write lock for COPY/write mutual exclusion.

FalkorDB crashes when GRAPH.COPY (which forks the Redis process) overlaps with
heavy graph writes.  This module provides a cooperative lock that prevents
writers from starting while a COPY is pending, and prevents COPY from starting
while writers are active.

Additionally, FalkorDB cannot handle concurrent GRAPH.COPY forks — the second
fork fails with "Can't fork for module: File exists".  A local ``max_copies``
semaphore (default 1) serializes copy operations so only one fork runs at a
time.  The adapter's ``falkordb:fork_lock`` provides secondary server-wide
serialization, but under heavy load its Redis Lock can fail with socket
timeouts and fall back to proceeding without the lock.

The lock is scoped by a ``context_id`` so independent benchmark runs do not
interfere with each other.  All keys have a TTL so that crashed processes
cannot leave stale locks behind.

Acquisition order is always: ``ForkWriteLock.copy_guard`` (outer) then
``adapter._acquire_fork_lock`` (inner).
"""

from __future__ import annotations

import contextlib
import threading
import time
from typing import TYPE_CHECKING

import logfire

if TYPE_CHECKING:
    from collections.abc import Generator

    from redis import Redis


# ---------------------------------------------------------------------------
# Lua scripts — executed atomically by Redis
# ---------------------------------------------------------------------------

# Try to increment the writer counter.  Succeeds only when copy_pending == 0.
_LUA_ACQUIRE_WRITE = """
local cp = redis.call('GET', KEYS[1])
if cp and tonumber(cp) > 0 then
    return 0
end
redis.call('INCR', KEYS[2])
redis.call('EXPIRE', KEYS[2], ARGV[1])
return 1
"""

# Decrement writer counter; delete key if it drops to zero or below.
_LUA_RELEASE_WRITE = """
local v = redis.call('DECR', KEYS[1])
if v <= 0 then
    redis.call('DEL', KEYS[1])
end
return v
"""

# Increment copy_pending counter so new writers are blocked.
_LUA_SIGNAL_COPY_PENDING = """
redis.call('INCR', KEYS[1])
redis.call('EXPIRE', KEYS[1], ARGV[1])
return 1
"""

# Decrement copy_pending counter; delete key if it drops to zero or below.
_LUA_CLEAR_COPY_PENDING = """
local v = redis.call('DECR', KEYS[1])
if v <= 0 then
    redis.call('DEL', KEYS[1])
end
return v
"""


class ForkWriteLock:
    """Mutual-exclusion lock between forking operations (COPY/BGSAVE) and writes.

    Parameters
    ----------
    redis_client:
        A ``redis.Redis`` instance connected to the same server as FalkorDB.
    context_id:
        Unique identifier scoping this lock (e.g. benchmark run id).
    key_ttl:
        TTL in seconds for all Redis keys (crash-safety).  Must be longer
        than both ``acquire_timeout`` **and** the longest expected
        critical section (copy or write hold time).  The TTL is refreshed
        each time a new writer or copy acquires, but if only one writer
        holds the key for a long operation the TTL set at acquire time is
        the only guard.  If a key expires mid-operation the lock fails
        open and COPY/write overlap becomes possible.  Callers should set
        this to ``acquire_timeout + generous_headroom`` (e.g. +600s) to
        cover both polling waiters and long-held critical sections.
    poll_interval:
        Seconds between retry attempts when waiting.
    acquire_timeout:
        Maximum seconds to wait before raising ``TimeoutError``.
    max_writers:
        Maximum number of concurrent writers allowed.  FalkorDB uses a
        single thread for graph mutations, so high writer concurrency
        causes each write to take dramatically longer.  The default of 4
        provides parallelism without saturating the single write thread.
    max_copies:
        Maximum number of concurrent GRAPH.COPY operations.  FalkorDB
        cannot handle concurrent forks — the second fork fails with
        "Can't fork for module: File exists".  Default 1 serializes copies.
    """

    def __init__(
        self,
        redis_client: Redis,
        context_id: str,
        key_ttl: int = 2400,
        poll_interval: float = 0.1,
        acquire_timeout: float = 1800,
        max_writers: int = 4,
        max_copies: int = 1,
    ) -> None:
        """Initialize a ForkWriteLock."""
        self._redis = redis_client
        self._context_id = context_id
        self._key_ttl = key_ttl
        self._poll_interval = poll_interval
        self._acquire_timeout = acquire_timeout
        self._writer_semaphore = threading.Semaphore(max_writers)
        self._max_writers = max_writers
        self._copy_semaphore = threading.Semaphore(max_copies)
        self._max_copies = max_copies

        # Key names
        self._copy_pending_key = f"fork_rw:{context_id}:copy_pending"
        self._writers_key = f"fork_rw:{context_id}:writers"

        # Register Lua scripts
        self._acquire_write_script = self._redis.register_script(_LUA_ACQUIRE_WRITE)
        self._release_write_script = self._redis.register_script(_LUA_RELEASE_WRITE)
        self._signal_copy_script = self._redis.register_script(_LUA_SIGNAL_COPY_PENDING)
        self._clear_copy_script = self._redis.register_script(_LUA_CLEAR_COPY_PENDING)

    @property
    def acquire_timeout(self) -> float:
        """Maximum seconds to wait before raising ``TimeoutError``."""
        return self._acquire_timeout

    # ------------------------------------------------------------------
    # Write lock
    # ------------------------------------------------------------------

    def _read_counters(self) -> tuple[int, int]:
        """Read current copy_pending and writers counters."""
        cp_raw = self._redis.get(self._copy_pending_key)
        wr_raw = self._redis.get(self._writers_key)
        return (
            int(cp_raw) if cp_raw else 0,
            int(wr_raw) if wr_raw else 0,
        )

    def _wait_for_fork_idle(self, timeout: float = 30) -> None:
        """Wait until no Redis module fork is in progress.

        RediSearch triggers background GC forks during heavy graph writes.
        If GRAPH.COPY (which also forks) starts while a GC fork is still
        active, FalkorDB crashes with "Can't fork for module: File exists".

        This method polls ``INFO server`` for ``module_fork_in_progress``
        and blocks until it drops to 0 or the timeout is reached.

        Raises ``TimeoutError`` if the fork does not clear in time, so the
        caller can roll back (release semaphore, decrement copy_pending)
        rather than proceeding into a crash-prone state.
        """
        deadline = time.monotonic() + timeout
        logged_waiting = False
        while time.monotonic() < deadline:
            try:
                info = self._redis.info("server")
            except Exception:
                # Redis unreachable — caller will hit its own error handling
                return
            if not info.get("module_fork_in_progress", 0):
                if logged_waiting:
                    logfire.info(
                        "fork_write_lock_fork_idle",
                        context_id=self._context_id,
                    )
                return
            if not logged_waiting:
                logfire.info(
                    "fork_write_lock_waiting_for_fork_idle",
                    context_id=self._context_id,
                    module_fork_in_progress=info.get("module_fork_in_progress"),
                )
                logged_waiting = True
            time.sleep(0.5)
        raise TimeoutError(
            f"_wait_for_fork_idle timed out after {timeout}s — "
            f"module_fork_in_progress still non-zero "
            f"(context={self._context_id})"
        )

    def acquire_write(self) -> None:
        """Block until no COPY is pending, then register as an active writer.

        The writer semaphore is acquired first to limit concurrent writers
        to ``max_writers``.  This prevents FalkorDB's single write thread
        from being saturated by too many concurrent graph mutations.

        Raises ``TimeoutError`` if ``acquire_timeout`` is exceeded.
        Raises ``ConnectionError`` if Redis becomes unreachable.
        """
        deadline = time.monotonic() + self._acquire_timeout

        # Acquire the local semaphore first to cap concurrency
        remaining = max(0, deadline - time.monotonic())
        if not self._writer_semaphore.acquire(timeout=remaining):
            cp, wr = self._read_counters()
            raise TimeoutError(
                f"ForkWriteLock.acquire_write timed out waiting for writer "
                f"semaphore after {self._acquire_timeout}s "
                f"(context={self._context_id}, max_writers={self._max_writers}, "
                f"copy_pending={cp}, writers={wr})"
            )

        # Semaphore acquired — from here, any failure must release it
        try:
            logged_waiting = False
            while True:
                try:
                    result = self._acquire_write_script(
                        keys=[self._copy_pending_key, self._writers_key],
                        args=[self._key_ttl],
                    )
                except Exception as e:
                    raise ConnectionError(
                        f"ForkWriteLock.acquire_write lost Redis connection "
                        f"(context={self._context_id}): {e}"
                    ) from e
                if result:
                    cp, wr = self._read_counters()
                    logfire.info(
                        "fork_write_lock_write_acquired",
                        context_id=self._context_id,
                        copy_pending=cp,
                        writers=wr,
                    )
                    return
                if not logged_waiting:
                    cp, wr = self._read_counters()
                    logfire.info(
                        "fork_write_lock_write_waiting",
                        context_id=self._context_id,
                        copy_pending=cp,
                        writers=wr,
                    )
                    logged_waiting = True
                if time.monotonic() >= deadline:
                    cp, wr = self._read_counters()
                    raise TimeoutError(
                        f"ForkWriteLock.acquire_write timed out after "
                        f"{self._acquire_timeout}s (context={self._context_id}, "
                        f"copy_pending={cp}, writers={wr})"
                    )
                time.sleep(self._poll_interval)
        except BaseException:
            self._writer_semaphore.release()
            raise

    def release_write(self) -> None:
        """Unregister as an active writer and release the writer semaphore.

        The Redis writer counter is decremented first, then the local
        semaphore is released.  Includes defensive retry logic: if the Redis
        connection died (e.g. due to a socket timeout on the FalkorDB side),
        the Lua script call will fail.  We attempt reconnection and retry
        once, falling back to a raw DECR as a last resort so the writer
        counter is decremented and copy_guard() callers are not permanently
        blocked.  The semaphore is always released regardless of Redis errors.
        """
        try:
            try:
                self._release_write_script(keys=[self._writers_key])
            except Exception:
                # Connection may be dead — attempt reconnect and retry once
                try:
                    self._redis.ping()
                except Exception as ping_err:
                    logfire.warning(
                        "fork_write_lock_reconnect_ping_failed",
                        context_id=self._context_id,
                        error=str(ping_err),
                    )
                try:
                    self._release_write_script(keys=[self._writers_key])
                except Exception as e:
                    logfire.error(
                        "fork_write_lock_release_write_failed",
                        context_id=self._context_id,
                        error=str(e),
                    )
                    # Force-decrement as last resort.  Mirror the Lua
                    # script: delete the key if it drops to zero or below
                    # so we don't leave a stale negative counter with no TTL.
                    try:
                        val = self._redis.decr(self._writers_key)
                        if val <= 0:
                            self._redis.delete(self._writers_key)
                    except Exception as decr_err:
                        logfire.error(
                            "fork_write_lock_force_decr_failed",
                            context_id=self._context_id,
                            error=str(decr_err),
                        )
                    return
            cp, wr = self._read_counters()
            logfire.info(
                "fork_write_lock_write_released",
                context_id=self._context_id,
                copy_pending=cp,
                writers=wr,
            )
        finally:
            self._writer_semaphore.release()

    # ------------------------------------------------------------------
    # Copy lock
    # ------------------------------------------------------------------

    def acquire_copy(self) -> None:
        """Signal a pending COPY, wait for writers to drain, then serialize.

        The copy semaphore ensures only ``max_copies`` GRAPH.COPY operations
        can proceed concurrently (default 1 — full serialization).  The
        semaphore is acquired **after** writers have drained so that copy
        queueing still blocks new writers via the copy_pending counter.

        If the wait times out, the copy_pending counter is decremented so
        that writers are not permanently blocked.

        Raises ``TimeoutError`` if ``acquire_timeout`` is exceeded.
        """
        deadline = time.monotonic() + self._acquire_timeout

        self._signal_copy_script(
            keys=[self._copy_pending_key],
            args=[self._key_ttl],
        )
        cp, wr = self._read_counters()
        logfire.info(
            "fork_write_lock_copy_pending_signalled",
            context_id=self._context_id,
            copy_pending=cp,
            writers=wr,
        )

        logged_waiting = False
        try:
            while True:
                try:
                    writers = self._redis.get(self._writers_key)
                except Exception as e:
                    # Roll back copy_pending before propagating
                    try:
                        self._clear_copy_script(keys=[self._copy_pending_key])
                    except Exception as rollback_err:
                        logfire.error(
                            "fork_write_lock_copy_pending_rollback_failed",
                            context_id=self._context_id,
                            error=str(rollback_err),
                        )
                    raise ConnectionError(
                        f"ForkWriteLock.acquire_copy lost Redis connection "
                        f"(context={self._context_id}): {e}"
                    ) from e
                if writers is None or int(writers) <= 0:
                    break
                if not logged_waiting:
                    logfire.info(
                        "fork_write_lock_copy_waiting_for_writers",
                        context_id=self._context_id,
                        writers=int(writers),
                    )
                    logged_waiting = True
                if time.monotonic() >= deadline:
                    # Roll back copy_pending so writers aren't permanently blocked
                    self._clear_copy_script(keys=[self._copy_pending_key])
                    cp, wr = self._read_counters()
                    raise TimeoutError(
                        f"ForkWriteLock.acquire_copy timed out after "
                        f"{self._acquire_timeout}s waiting for {wr} "
                        f"writer(s) to drain (context={self._context_id}, "
                        f"copy_pending={cp})"
                    )
                time.sleep(self._poll_interval)
        except BaseException:
            # On any failure before semaphore, copy_pending was already
            # rolled back inside the loop (TimeoutError/ConnectionError).
            raise

        # Writers have drained — now acquire the copy semaphore to serialize
        # GRAPH.COPY forks.  This prevents "Can't fork: File exists" crashes.
        remaining = max(0, deadline - time.monotonic())
        if not self._copy_semaphore.acquire(timeout=remaining):
            self._clear_copy_script(keys=[self._copy_pending_key])
            cp, wr = self._read_counters()
            raise TimeoutError(
                f"ForkWriteLock.acquire_copy timed out waiting for copy "
                f"semaphore after {self._acquire_timeout}s "
                f"(context={self._context_id}, max_copies={self._max_copies}, "
                f"copy_pending={cp}, writers={wr})"
            )

        # Wait for any in-flight RediSearch GC fork to finish before
        # allowing GRAPH.COPY to proceed.  If anything fails after the
        # semaphore is acquired, release it and roll back copy_pending
        # so callers are not permanently blocked.
        try:
            remaining = max(30, deadline - time.monotonic())
            self._wait_for_fork_idle(timeout=remaining)
            cp, wr = self._read_counters()
            logfire.info(
                "fork_write_lock_copy_acquired",
                context_id=self._context_id,
                copy_pending=cp,
                writers=wr,
            )
        except BaseException:
            self._copy_semaphore.release()
            try:
                self._clear_copy_script(keys=[self._copy_pending_key])
            except Exception as rollback_err:
                logfire.error(
                    "fork_write_lock_copy_pending_rollback_failed_after_semaphore",
                    context_id=self._context_id,
                    error=str(rollback_err),
                )
            raise

    def release_copy(self) -> None:
        """Clear the copy-pending signal and release the copy semaphore."""
        try:
            self._clear_copy_script(keys=[self._copy_pending_key])
            cp, wr = self._read_counters()
            logfire.info(
                "fork_write_lock_copy_released",
                context_id=self._context_id,
                copy_pending=cp,
                writers=wr,
            )
        finally:
            self._copy_semaphore.release()

    # ------------------------------------------------------------------
    # Context managers
    # ------------------------------------------------------------------

    @contextlib.contextmanager
    def write_guard(self) -> Generator[None, None, None]:
        """Context manager wrapping acquire/release write."""
        self.acquire_write()
        try:
            yield
        finally:
            self.release_write()

    @contextlib.contextmanager
    def copy_guard(self) -> Generator[None, None, None]:
        """Context manager wrapping acquire/release copy."""
        self.acquire_copy()
        try:
            yield
        finally:
            self.release_copy()

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def cleanup(self) -> None:
        """Delete all Redis keys for this context."""
        cp, wr = self._read_counters()
        self._redis.delete(self._copy_pending_key, self._writers_key)
        logfire.info(
            "fork_write_lock_cleanup",
            context_id=self._context_id,
            copy_pending_before=cp,
            writers_before=wr,
        )

    def close(self) -> None:
        """Clean up Redis keys and close the underlying Redis connection."""
        self.cleanup()
        self._redis.close()
