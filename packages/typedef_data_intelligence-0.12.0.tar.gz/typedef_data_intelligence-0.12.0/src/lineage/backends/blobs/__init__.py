"""Blob storage backends for persisting large/ephemeral data.

Blob storage provides a unified way to persist query results, table previews,
and exploration data that can be referenced by ID across subagent boundaries.
"""
from lineage.backends.blobs.factory import create_blob_storage
from lineage.backends.blobs.protocol import (
    Blob,
    BlobPreviewResult,
    BlobRef,
    BlobStorage,
)
from lineage.backends.blobs.sqlite import SQLiteBlobStorage

__all__ = [
    "Blob",
    "BlobPreviewResult",
    "BlobRef",
    "BlobStorage",
    "SQLiteBlobStorage",
    "create_blob_storage",
]
