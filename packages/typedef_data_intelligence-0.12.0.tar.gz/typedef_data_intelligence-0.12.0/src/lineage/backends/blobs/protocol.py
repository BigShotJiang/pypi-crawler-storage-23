"""Protocol interface for blob storage backends.

Blob storage provides a unified way to persist large/ephemeral data (query results,
table previews, explores) that can be referenced by ID across subagent boundaries.

This solves the "telephone problem" where data fidelity is lost when passing results
through multiple agents:

Before:
    data_explorer runs execute_query() -> 500 rows returned
                        |
    orchestrator summarizes: "Found revenue data..."
                        |
    report_builder gets paraphrased -> No access to raw rows

After:
    data_explorer.execute_query(persist=True) -> blob_id="blob_abc123"
                        |
    orchestrator passes: "Use result_set_id=blob_abc123"
                        |
    report_builder.add_table_cell(result_set_id="blob_abc123") -> Full data
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Protocol, runtime_checkable

from pydantic import BaseModel, Field


def generate_blob_id() -> str:
    """Generate a unique blob ID."""
    return f"blob_{uuid.uuid4().hex[:12]}"


class Blob(BaseModel):
    """Full blob data including payload.

    Attributes:
        blob_id: Unique identifier for the blob
        blob_type: Type of blob (query_result, table_preview, explore)
        thread_id: Thread this blob belongs to
        run_id: Run that created this blob
        created_at: When the blob was created
        expires_at: When the blob expires (for TTL cleanup)
        size_bytes: Size of the serialized data in bytes
        metadata: Additional metadata (sql query, query_name, etc.)
        data: The actual blob payload (columns, rows, etc.)
    """

    blob_id: str = Field(description="Unique identifier for the blob")
    blob_type: Literal["query_result", "table_preview", "explore"] = Field(
        description="Type of blob content"
    )
    thread_id: str = Field(description="Thread this blob belongs to")
    run_id: str = Field(description="Run that created this blob")
    created_at: datetime = Field(description="When the blob was created")
    expires_at: datetime = Field(description="When the blob expires")
    size_bytes: int = Field(default=0, description="Size of serialized data in bytes")
    metadata: Dict[str, Any] = Field(
        default_factory=dict, description="Additional metadata"
    )
    data: Dict[str, Any] = Field(
        default_factory=dict, description="The actual blob payload"
    )


class BlobRef(BaseModel):
    """Lightweight reference to a blob (for tool results).

    This is returned by store() and can be passed between agents
    without including the full data payload.

    Attributes:
        blob_id: Unique identifier for the blob
        blob_type: Type of blob content
        summary: Human-readable summary (e.g., "150 rows, 5 columns")
        created_at: When the blob was created
        row_count: Number of rows (for query_result blobs)
        columns: Column names (for query_result blobs)
    """

    blob_id: str = Field(description="Unique identifier for the blob")
    blob_type: str = Field(description="Type of blob content")
    summary: Optional[str] = Field(
        default=None, description="Human-readable summary"
    )
    created_at: datetime = Field(description="When the blob was created")
    # Structured metadata for query_result blobs:
    row_count: Optional[int] = Field(
        default=None, description="Number of rows (for query_result)"
    )
    columns: Optional[List[str]] = Field(
        default=None, description="Column names (for query_result)"
    )


class BlobPreviewResult(BaseModel):
    """Result from previewing a blob.

    Returns metadata and sample rows without fetching full data.

    Attributes:
        blob_id: The blob being previewed
        columns: Column names
        sample_rows: First N rows of data
        total_rows: Total row count in the full blob
        blob_type: Type of blob content
    """

    blob_id: str = Field(description="The blob being previewed")
    columns: List[str] = Field(default_factory=list, description="Column names")
    sample_rows: List[Any] = Field(
        default_factory=list, description="Sample rows of data"
    )
    total_rows: int = Field(default=0, description="Total row count")
    blob_type: str = Field(description="Type of blob content")


@runtime_checkable
class BlobStorage(Protocol):
    """Protocol for blob storage backend implementations.

    This interface allows different backends (SQLite, Redis, S3) to provide
    the same blob storage capabilities for agents.
    """

    def store(
        self,
        thread_id: str,
        run_id: str,
        blob_type: Literal["query_result", "table_preview", "explore"],
        data: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
        ttl_days: int = 30,
    ) -> BlobRef:
        """Store data as a blob and return a lightweight reference.

        Args:
            thread_id: Thread this blob belongs to
            run_id: Run that created this blob
            blob_type: Type of blob content
            data: The data payload to store
            metadata: Optional additional metadata (sql query, query_name, etc.)
            ttl_days: Time-to-live in days (default 30)

        Returns:
            BlobRef with blob_id and summary for passing between agents
        """
        ...

    def get(self, blob_id: str) -> Optional[Blob]:
        """Retrieve a blob by ID.

        Args:
            blob_id: The blob to retrieve

        Returns:
            Full Blob with data, or None if not found/expired
        """
        ...

    def preview(self, blob_id: str, sample_rows: int = 5) -> Optional[Blob]:
        """Get blob metadata with limited data rows.

        Returns full Blob but with data["rows"] truncated to sample_rows.
        Useful for:
        - Validating column names before chart creation
        - Checking data format before building tables
        - Determining if pagination is needed (via row_count in metadata)

        Args:
            blob_id: The blob to preview
            sample_rows: Max rows to include (default 5)

        Returns:
            Blob with truncated rows, or None if not found/expired
        """
        ...

    def list_by_thread(
        self,
        thread_id: str,
        blob_type: Optional[str] = None,
        limit: int = 50,
    ) -> List[BlobRef]:
        """List blobs for a thread.

        Args:
            thread_id: Thread to list blobs for
            blob_type: Optional filter by blob type
            limit: Maximum number of results

        Returns:
            List of BlobRef references
        """
        ...

    def delete(self, blob_id: str) -> bool:
        """Delete a blob.

        Args:
            blob_id: The blob to delete

        Returns:
            True if deleted, False if not found
        """
        ...

    def cleanup_expired(self) -> int:
        """Remove expired blobs.

        Returns:
            Number of blobs deleted
        """
        ...
