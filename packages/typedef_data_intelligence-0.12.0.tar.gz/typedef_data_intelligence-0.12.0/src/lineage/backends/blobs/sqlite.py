"""SQLite implementation of BlobStorage backend."""
from __future__ import annotations

import json
import logging
import sqlite3
import sys
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

from lineage.backends.blobs.protocol import (
    Blob,
    BlobRef,
    BlobStorage,
    generate_blob_id,
)

logger = logging.getLogger(__name__)


class SQLiteBlobStorage(BlobStorage):
    """SQLite-backed blob storage.

    Provides persistent storage for large/ephemeral data (query results,
    table previews, explores) that can be referenced by ID across subagent boundaries.

    Features:
    - Thread-safe with connection locking
    - TTL-based expiration
    - Automatic summary generation based on blob type
    - JSON serialization for data and metadata
    """

    def __init__(self, db_path: str | Path):
        """Initialize SQLite blob storage.

        Args:
            db_path: Path to SQLite database file
        """
        self._path = Path(db_path)
        logger.info(f"Initializing blob storage: SQLite at {self._path}")
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self._path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        self._init_schema()

    def _init_schema(self) -> None:
        """Initialize database schema."""
        with self._conn:
            self._conn.execute(
                """
                CREATE TABLE IF NOT EXISTS blobs (
                    blob_id TEXT PRIMARY KEY,
                    blob_type TEXT NOT NULL,
                    thread_id TEXT NOT NULL,
                    run_id TEXT NOT NULL,
                    created_at TIMESTAMP NOT NULL,
                    expires_at TIMESTAMP NOT NULL,
                    size_bytes INTEGER DEFAULT 0,
                    metadata TEXT,
                    data TEXT NOT NULL
                )
                """
            )
            # Index for listing blobs by thread
            self._conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_blobs_thread_type
                ON blobs(thread_id, blob_type)
                """
            )
            # Index for TTL cleanup
            self._conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_blobs_expires
                ON blobs(expires_at)
                """
            )
            # Backward-compatible migration: add summary columns
            for col_def in [
                "summary TEXT",
                "row_count INTEGER",
                "column_names TEXT",
            ]:
                try:
                    self._conn.execute(f"ALTER TABLE blobs ADD COLUMN {col_def}")
                except sqlite3.OperationalError:
                    pass  # Column already exists

    def _generate_summary(
        self,
        blob_type: str,
        data: Dict[str, Any],
    ) -> str:
        """Generate a human-readable summary based on blob type.

        Args:
            blob_type: Type of blob content
            data: The data payload

        Returns:
            Summary string (e.g., "150 rows, 5 columns")
        """
        if blob_type == "query_result":
            rows = data.get("rows", [])
            columns = data.get("columns", [])
            return f"{len(rows)} rows, {len(columns)} columns"
        elif blob_type == "table_preview":
            rows = data.get("sample_rows", [])
            columns = data.get("columns", [])
            return f"Preview: {len(rows)} rows, {len(columns)} columns"
        elif blob_type == "explore":
            return f"Exploration: {data.get('title', 'untitled')}"
        else:
            return f"{blob_type} blob"

    def store(
        self,
        thread_id: str,
        run_id: str,
        blob_type: Literal["query_result", "table_preview", "explore"],
        data: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
        ttl_days: int = 30,
    ) -> BlobRef:
        """Store data as a blob and return a lightweight reference.

        Args:
            thread_id: Thread this blob belongs to
            run_id: Run that created this blob
            blob_type: Type of blob content
            data: The data payload to store
            metadata: Optional additional metadata
            ttl_days: Time-to-live in days (default 30)

        Returns:
            BlobRef with blob_id and summary for passing between agents
        """
        blob_id = generate_blob_id()
        now = datetime.now(timezone.utc)
        expires_at = now + timedelta(days=ttl_days)

        # Serialize data and metadata
        data_json = json.dumps(data)
        metadata_json = json.dumps(metadata) if metadata else None
        size_bytes = sys.getsizeof(data_json)

        # Generate summary
        summary = self._generate_summary(blob_type, data)

        # Pre-compute row_count and column_names for efficient listing
        row_count = None
        column_names_json = None
        if blob_type == "query_result":
            row_count = len(data.get("rows", []))
            column_names_json = json.dumps(data.get("columns", []))

        with self._lock, self._conn:
            self._conn.execute(
                """
                INSERT INTO blobs (
                    blob_id, blob_type, thread_id, run_id,
                    created_at, expires_at, size_bytes, metadata, data,
                    summary, row_count, column_names
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    blob_id,
                    blob_type,
                    thread_id,
                    run_id,
                    now.strftime("%Y-%m-%d %H:%M:%S"),
                    expires_at.strftime("%Y-%m-%d %H:%M:%S"),
                    size_bytes,
                    metadata_json,
                    data_json,
                    summary,
                    row_count,
                    column_names_json,
                ),
            )

        logger.debug(f"Stored blob {blob_id}: {summary}")

        columns = data.get("columns", []) if blob_type == "query_result" else None

        return BlobRef(
            blob_id=blob_id,
            blob_type=blob_type,
            summary=summary,
            created_at=now,
            row_count=row_count,
            columns=columns,
        )

    def get(self, blob_id: str) -> Optional[Blob]:
        """Retrieve a blob by ID.

        Args:
            blob_id: The blob to retrieve

        Returns:
            Full Blob with data, or None if not found/expired
        """
        with self._lock:
            cursor = self._conn.execute(
                """
                SELECT blob_id, blob_type, thread_id, run_id,
                       created_at, expires_at, size_bytes, metadata, data
                FROM blobs
                WHERE blob_id = ? AND expires_at > datetime('now')
                """,
                (blob_id,),
            )
            row = cursor.fetchone()

        if not row:
            logger.debug(f"Blob not found or expired: {blob_id}")
            return None

        # Parse timestamps (handle both SQLite format "YYYY-MM-DD HH:MM:SS"
        # and legacy ISO format "YYYY-MM-DDTHH:MM:SS+00:00")
        created_at = row["created_at"]
        if isinstance(created_at, str):
            created_at = datetime.fromisoformat(created_at.replace(" ", "T"))
            if created_at.tzinfo is None:
                created_at = created_at.replace(tzinfo=timezone.utc)

        expires_at = row["expires_at"]
        if isinstance(expires_at, str):
            expires_at = datetime.fromisoformat(expires_at.replace(" ", "T"))
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)

        # Parse JSON fields
        data = json.loads(row["data"])
        metadata = json.loads(row["metadata"]) if row["metadata"] else {}

        return Blob(
            blob_id=row["blob_id"],
            blob_type=row["blob_type"],
            thread_id=row["thread_id"],
            run_id=row["run_id"],
            created_at=created_at,
            expires_at=expires_at,
            size_bytes=row["size_bytes"],
            metadata=metadata,
            data=data,
        )

    def preview(self, blob_id: str, sample_rows: int = 5) -> Optional[Blob]:
        """Get blob metadata with limited data rows.

        Returns full Blob but with data["rows"] truncated to sample_rows.
        Useful for:
        - Validating column names before chart creation
        - Checking data format before building tables
        - Determining if pagination is needed (via row_count in metadata)

        Args:
            blob_id: The blob to preview
            sample_rows: Max rows to include (default 5)

        Returns:
            Blob with truncated rows, or None if not found/expired
        """
        blob = self.get(blob_id)
        if blob is None:
            return None
        if blob.blob_type == "query_result":
            full_rows = blob.data.get("rows", [])
            total_rows = len(full_rows)
            preview_data = {
                **blob.data,
                "rows": full_rows[:sample_rows],
                "preview_truncated": total_rows > sample_rows,
                "total_rows": total_rows,
            }
            return blob.model_copy(update={"data": preview_data})
        return blob

    def list_by_thread(
        self,
        thread_id: str,
        blob_type: Optional[str] = None,
        limit: int = 50,
    ) -> List[BlobRef]:
        """List blobs for a thread.

        Args:
            thread_id: Thread to list blobs for
            blob_type: Optional filter by blob type
            limit: Maximum number of results

        Returns:
            List of BlobRef references
        """
        with self._lock:
            if blob_type:
                cursor = self._conn.execute(
                    """
                    SELECT blob_id, blob_type, created_at,
                           summary, row_count, column_names, data
                    FROM blobs
                    WHERE thread_id = ? AND blob_type = ? AND expires_at > datetime('now')
                    ORDER BY created_at DESC
                    LIMIT ?
                    """,
                    (thread_id, blob_type, limit),
                )
            else:
                cursor = self._conn.execute(
                    """
                    SELECT blob_id, blob_type, created_at,
                           summary, row_count, column_names, data
                    FROM blobs
                    WHERE thread_id = ? AND expires_at > datetime('now')
                    ORDER BY created_at DESC
                    LIMIT ?
                    """,
                    (thread_id, limit),
                )

            rows = cursor.fetchall()

        refs = []
        for row in rows:
            created_at = row["created_at"]
            if isinstance(created_at, str):
                created_at = datetime.fromisoformat(created_at.replace(" ", "T"))
                if created_at.tzinfo is None:
                    created_at = created_at.replace(tzinfo=timezone.utc)

            # Use pre-computed summary column; fall back to data deserialization
            # for rows stored before the migration
            summary = row["summary"]
            row_count = row["row_count"]
            columns = json.loads(row["column_names"]) if row["column_names"] else None

            if summary is None:
                # Legacy row: fall back to full data deserialization
                data = json.loads(row["data"])
                summary = self._generate_summary(row["blob_type"], data)
                if row["blob_type"] == "query_result":
                    columns = data.get("columns", [])
                    row_count = len(data.get("rows", []))

            refs.append(
                BlobRef(
                    blob_id=row["blob_id"],
                    blob_type=row["blob_type"],
                    summary=summary,
                    created_at=created_at,
                    row_count=row_count,
                    columns=columns,
                )
            )

        return refs

    def delete(self, blob_id: str) -> bool:
        """Delete a blob.

        Args:
            blob_id: The blob to delete

        Returns:
            True if deleted, False if not found
        """
        with self._lock, self._conn:
            cursor = self._conn.execute(
                "DELETE FROM blobs WHERE blob_id = ?",
                (blob_id,),
            )
            deleted = cursor.rowcount > 0

        if deleted:
            logger.debug(f"Deleted blob: {blob_id}")
        return deleted

    def cleanup_expired(self) -> int:
        """Remove expired blobs.

        Returns:
            Number of blobs deleted
        """
        with self._lock, self._conn:
            cursor = self._conn.execute(
                "DELETE FROM blobs WHERE expires_at <= datetime('now')"
            )
            count = cursor.rowcount

        if count > 0:
            logger.info(f"Cleaned up {count} expired blobs")
        return count
