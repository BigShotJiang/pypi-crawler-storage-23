"""Factory functions for creating blob storage backends."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from lineage.backends.blobs.protocol import BlobStorage
    from lineage.backends.config import BlobConfig

logger = logging.getLogger(__name__)


def create_blob_storage(config: "BlobConfig") -> Optional["BlobStorage"]:
    """Create a blob storage backend from configuration.

    Args:
        config: Blob storage configuration

    Returns:
        BlobStorage implementation or None if disabled
    """
    if not config.enabled:
        logger.info("Blob storage disabled")
        return None

    if config.backend == "sqlite":
        from lineage.backends.blobs.sqlite import SQLiteBlobStorage

        return SQLiteBlobStorage(db_path=config.db_path)
    else:
        logger.warning(f"Unknown blob backend type: {config.backend}")
        return None
