"""Ingest-time configuration for data loading and population.

This module defines configuration for data ingestion operations:
- Semantic analysis settings (LLM models, parallelism)
- Profiling configuration
- Clustering configuration
- Semantic view loading
- Output settings

Separates ingest-time concerns from runtime agent configuration.
"""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Literal, Optional

import yaml
from pydantic import BaseModel, Field

from lineage.backends.config import DataConfig, LineageConfig
from lineage.ingest.static_loaders.reports.config import ReportLoadersConfig

# ============================================================================
# Model Size Enum (AWS-style instance sizes)
# ============================================================================

MODEL_SIZE = Literal["micro", "small", "medium", "large", "xlarge"]


# ============================================================================
# Analysis Model Configuration
# ============================================================================


class AnalysisModelConfig(BaseModel):
    """Configuration for a single LLM model used in semantic analysis.

    Defines the provider type, model name, and inference parameters.
    """

    type: Literal["openai", "google", "openrouter", "anthropic"] = Field(
        default="openrouter", description="LLM provider type"
    )
    model_name: str = Field(
        default="openai/gpt-5-nano",
        description="Model identifier (e.g., 'gpt-4o-mini', 'gemini-2.0-flash-thinking-exp-01-21')",
    )
    thinking_tokens_budget: Optional[int] = Field(
        default=None, description="Thinking token budget for the model"
    )
    reasoning_effort: Optional[Literal["minimal", "low", "medium", "high"]] = Field(
        default=None, description="Reasoning effort level for the model"
    )


class AnalysisModelsConfig(BaseModel):
    """Configuration for LLM models at different instance sizes.

    Maps AWS-style instance sizes to model configurations:
    - micro: Smallest, fastest models for trivial tasks
    - small: Fast models for simple tasks
    - medium: Balanced models for moderate reasoning
    - large: Powerful models for complex reasoning
    - xlarge: Most powerful models for very complex reasoning
    """

    micro: AnalysisModelConfig = Field(
        default_factory=lambda: AnalysisModelConfig(
            type="openai",
            model_name="gpt-5-nano",
            reasoning_effort="minimal",
        ),
        description="Micro instance - fastest, cheapest models",
    )
    small: AnalysisModelConfig = Field(
        default_factory=lambda: AnalysisModelConfig(
            type="openai",
            model_name="gpt-5-nano",
            reasoning_effort="medium",
        ),
        description="Small instance - fast models for simple tasks",
    )
    medium: AnalysisModelConfig = Field(
        default_factory=lambda: AnalysisModelConfig(
            type="openai",
            model_name="gpt-5-mini",
            reasoning_effort="medium",
        ),
        description="Medium instance - balanced models",
    )
    large: AnalysisModelConfig = Field(
        default_factory=lambda: AnalysisModelConfig(
            type="openai",
            model_name="gpt-5",
            reasoning_effort="low",
        ),
        description="Large instance - powerful models",
    )
    xlarge: AnalysisModelConfig = Field(
        default_factory=lambda: AnalysisModelConfig(
            type="openai",
            model_name="gpt-5",
            reasoning_effort="medium",
        ),
        description="XLarge instance - most powerful models",
    )


# ============================================================================
# Pipeline Configuration
# ============================================================================


class PassConfig(BaseModel):
    """Configuration for a single semantic analysis pass."""

    model: MODEL_SIZE = Field(default="small", description="Model size for this pass")
    max_output_tokens: int = Field(
        default=16384, ge=1024, le=128000, description="Max output tokens for this pass"
    )


class PipelineConfig(BaseModel):
    """Configuration for semantic analysis pipeline execution."""

    # Pass-specific configurations
    pass_01: PassConfig = Field(
        default_factory=lambda: PassConfig(model="small", max_output_tokens=32768),
        description="Relations extraction",
    )
    pass_02: PassConfig = Field(
        default_factory=lambda: PassConfig(model="small", max_output_tokens=16384),
        description="Column analysis. Column lists are typically compact.",
    )
    pass_03: PassConfig = Field(
        default_factory=lambda: PassConfig(model="medium", max_output_tokens=32768),
        description="Join analysis. Joins can be complex.",
    )
    pass_04: PassConfig = Field(
        default_factory=lambda: PassConfig(model="small", max_output_tokens=16384),
        description="Filter analysis",
    )
    pass_05: PassConfig = Field(
        default_factory=lambda: PassConfig(model="small", max_output_tokens=32768),
        description="Grouping analysis",
    )
    pass_06: PassConfig = Field(
        default_factory=lambda: PassConfig(model="small", max_output_tokens=8192),
        description="Time dimension analysis",
    )
    pass_07: PassConfig = Field(
        default_factory=lambda: PassConfig(model="small", max_output_tokens=8192),
        description="Window function analysis. Window specs are typically compact.",
    )
    pass_08: PassConfig = Field(
        default_factory=lambda: PassConfig(model="medium", max_output_tokens=8192),
        description="Output shape analysis",
    )
    pass_09: PassConfig = Field(
        default_factory=lambda: PassConfig(model="medium", max_output_tokens=32768),
        description="Audit analysis. Most audits fit in 8k tokens.",
    )
    pass_10: PassConfig = Field(
        default_factory=lambda: PassConfig(model="large", max_output_tokens=16384),
        description="Business semantics. Typically fits in 8k, plus room for reasoning.",
    )
    pass_10a: PassConfig = Field(
        default_factory=lambda: PassConfig(model="micro", max_output_tokens=16384),
        description="Grain analysis",
    )
    pass_11: PassConfig = Field(
        default_factory=lambda: PassConfig(model="small", max_output_tokens=8192),
        description="Analysis summary. Summaries should be concise.",
    )

    # Pipeline settings
    enable_audit: bool = Field(default=False, description="Enable audit logging")
    audit_dir: Optional[Path] = Field(
        default=None, description="Directory for audit logs"
    )


# ============================================================================
# Semantic Analysis Configuration
# ============================================================================


class SemanticAnalysisConfig(BaseModel):
    """Configuration for semantic SQL analysis."""

    enabled: bool = Field(default=True, description="Enable semantic analysis")
    use_hybrid: bool = Field(
        default=True,
        description="Use hybrid mode: deterministic SQLGlot + targeted LLM classification"
    )
    max_workers: int = Field(
        default=8, ge=1, le=128,
        description="Parallel workers (used by per-model fallback mode)"
    )
    model_filter: Optional[str] = Field(
        default=None,
        description="Filter models by substring (e.g., 'fct_' for facts only)",
    )

    # Batch processing configuration (always enabled)
    batch_size: int = Field(
        default=50,
        ge=1,
        le=500,
        description="Number of models per batch"
    )

    # LLM model configurations for different pass complexities
    models: AnalysisModelsConfig = Field(
        default_factory=AnalysisModelsConfig,
        description="LLM model configurations (AWS-style instance sizes)",
    )

    # Pipeline configuration (which model size to use for each pass)
    pipeline: PipelineConfig = Field(
        default_factory=PipelineConfig, description="Pipeline pass assignments"
    )

    analysis_result_table: str = Field(
        default="batch_analysis", description="Table name for analysis results"
    )

    # Cache configuration
    cache_dir: Path = Field(
        default=Path(".lineage_workspace/semantic_cache"),
        description="Directory for semantic analysis cache"
    )
    use_cache: bool = Field(
        default=True,
        description="Use cached analysis results if available"
    )
    export_cache: bool = Field(
        default=True,
        description="Export analysis results to cache after completion"
    )
    fail_enrichment_after_timeout_seconds: Optional[float] = Field(
        default=None,
        description="If set, raise an error instead of returning empty results when graph "
        "enrichment exceeds this timeout. None = fail-open (production default).",
    )


# ============================================================================
# Profiling Configuration
# ============================================================================


class ProfilingConfig(BaseModel):
    """Configuration for data profiling.

    Profiling is opt-in (enabled=False by default). When enabled, it runs
    data warehouse queries to collect column-level statistics that feed into
    PK/FK inference. Each phase can be independently toggled.

    The signal pipeline (pass3/pass4) always consumes whatever profiling data
    exists in the graph — these config options only control whether new
    profiling data is collected from the warehouse.
    """

    # Master switch — must be True AND data_backend must be configured
    enabled: bool = Field(default=False, description="Enable data warehouse profiling")

    # Phase controls
    collect_stats: bool = Field(
        default=True,
        description="Run bulk column stats (APPROX_COUNT_DISTINCT, null counts, etc.)",
    )
    detect_patterns: bool = Field(
        default=True,
        description="Sample rows to classify value patterns (UUID, sequential, etc.)",
    )
    collect_top_k: bool = Field(
        default=False,
        description="Collect top-K frequent values per column (expensive, off by default)",
    )

    # Tuning
    max_workers: int = Field(default=8, ge=1, le=64, description="Parallel workers")
    sample_size: int = Field(default=10000, description="Row sample size for stats")
    pattern_sample_size: int = Field(
        default=100, description="Row sample size for pattern detection"
    )
    top_k: int = Field(default=10, ge=1, le=100, description="Top-K values per column")
    chunk_size: int = Field(
        default=50, ge=10, le=200, description="Columns per bulk query batch"
    )


# ============================================================================
# Clustering Configuration
# ============================================================================


class ClusteringConfig(BaseModel):
    """Configuration for join pattern clustering."""

    enabled: bool = Field(default=True, description="Enable join clustering")
    fail_fast: bool = Field(
        default=False,
        description="If true, abort the sync when clustering fails. If false (default), "
        "clustering failures are logged and the sync continues to completion.",
    )
    similarity_threshold: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Join similarity threshold"
    )
    label_clusters: bool = Field(
        default=True, description="Use LLM to generate cluster labels"
    )

    # Structural weights
    join_weight: float = Field(default=2.0, ge=0.0, description="Weight for join edges")
    lineage_weight: float = Field(default=1.0, ge=0.0, description="Weight for lineage edges")
    shared_dependency_weight: float = Field(
        default=0.5, ge=0.0, description="Weight for shared dependencies"
    )
    column_lineage_weight: float = Field(
        default=0.1, ge=0.0, description="Weight for column lineage"
    )
    # Semantic weights (Phase 2 enhancement)
    domain_similarity_weight: float = Field(
        default=0.35,
        ge=0.0,
        description="Weight for domain similarity edges (Jaccard similarity of domains)"
    )

    # Louvain resolution parameter
    resolution: float = Field(
        default=1.0,
        ge=0.0,
        description="Resolution parameter for Louvain modularity. Higher values produce more clusters."
    )


# ============================================================================
# Semantic View Loader Configuration
# ============================================================================


class SemanticViewLoaderConfig(BaseModel):
    """Configuration for loading semantic views from data warehouse."""

    enabled: bool = Field(default=True, description="Enable semantic view loading")
    schema_pattern: Optional[str] = Field(
        default=None,
        description="Schema name pattern for semantic views (e.g., 'semantic_*')",
    )


# ============================================================================
# Salesforce Configuration
# ============================================================================


class SalesforceConfig(BaseModel):
    """Configuration for Salesforce SObject filtering during ingestion.

    Controls which SObjects are excluded from ingestion to reduce noise
    from internal platform objects (Feed, History, Share, etc.).
    """

    sobject_exclude_patterns: list[str] = Field(
        default_factory=list,
        description="Glob-style patterns to exclude SObjects (e.g., '*Feed', '*History')",
    )
    sobject_exclude: list[str] = Field(
        default_factory=list,
        description="Explicit SObject API names to exclude (e.g., 'Task', 'Event')",
    )


# ============================================================================
# Key Lineage Configuration
# ============================================================================


class KeyLineageConfig(BaseModel):
    """Configuration for key lineage overlay (PK/FK inference)."""

    enabled: bool = Field(default=True, description="Enable key lineage overlay")
    dialect: str = Field(default="snowflake", description="SQL dialect for expression parsing")
    overrides_path: Optional[str] = Field(
        default=None,
        description="Path to key_lineage_overrides.yaml for UDF classifications",
    )


# ============================================================================
# Population Configuration (Combines All Ingest Settings)
# ============================================================================


class PopulationConfig(BaseModel):
    """Configuration for data population during load-dbt-full.

    Combines all ingest-time settings:
    - Semantic analysis (including LLM model configurations)
    - Profiling
    - Clustering
    - Semantic view loading
    - Salesforce object filtering
    - Report loaders (cross-platform BI report ingestion)
    - Key lineage (PK/FK inference)
    """

    semantic_analysis: SemanticAnalysisConfig = Field(
        default_factory=SemanticAnalysisConfig
    )
    profiling: ProfilingConfig = Field(default_factory=ProfilingConfig)
    clustering: ClusteringConfig = Field(default_factory=ClusteringConfig)
    semantic_view_loader: SemanticViewLoaderConfig = Field(
        default_factory=SemanticViewLoaderConfig
    )
    salesforce: SalesforceConfig = Field(default_factory=SalesforceConfig)
    report_loaders: Optional[ReportLoadersConfig] = Field(
        default=None,
        description="Configuration for cross-platform BI report loading",
    )
    key_lineage: KeyLineageConfig = Field(default_factory=KeyLineageConfig)


# ============================================================================
# Output Configuration
# ============================================================================


class OutputConfig(BaseModel):
    """Configuration for output artifacts."""

    reports_dir: Optional[Path] = Field(
        default=None, description="Directory for generated reports"
    )
    artifacts_dir: Optional[Path] = Field(
        default=None, description="Directory for analysis artifacts"
    )


# ============================================================================
# Ingest Configuration (Top-Level)
# ============================================================================


class IngestConfig(BaseModel):
    """Top-level configuration for data ingestion operations.

    This configuration includes:
    - Full lineage backend config (to connect to graph database)
    - Full data backend config (to connect to data warehouse for profiling/semantic views)
    - Population settings (semantic analysis, profiling, clustering)
    - Output settings (where to write reports/artifacts)

    Configuration supports environment variable interpolation using ${VAR_NAME} syntax.

    Loaded from ingest.yml or config.ingest.default.yml.
    """

    lineage: LineageConfig
    data: DataConfig
    population: PopulationConfig = Field(default_factory=PopulationConfig)
    output: OutputConfig = Field(default_factory=OutputConfig)

    @classmethod
    def from_yaml(cls, path: Path) -> IngestConfig:
        """Load configuration from YAML file with environment variable interpolation.

        Supports ${VAR_NAME} syntax for environment variable substitution.

        Args:
            path: Path to YAML configuration file

        Returns:
            Parsed and validated IngestConfig
        """
        with open(path, "r") as f:
            content = f.read()

        # Interpolate ${VAR_NAME} with environment variables
        def replace_env_var(match):
            var_name = match.group(1)
            value = os.environ.get(var_name)
            if value is None:
                raise ValueError(
                    f"Environment variable '{var_name}' is not set "
                    f"(required by {path})"
                )
            return value

        content = re.sub(r"\$\{([^}]+)\}", replace_env_var, content)
        data = yaml.safe_load(content)

        return cls(**data)
