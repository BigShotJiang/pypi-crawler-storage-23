"""Transformation-aware scope-level column lineage engine.

Uses sqlglot.optimizer.scope.traverse_scope() for robust scope iteration,
fine-grained transformation classification, shadow column tracking,
control dependency linking, and chain building.

Inspired by Recce's scope-based architecture.
"""

from __future__ import annotations

import enum
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple

from sqlglot import exp
from sqlglot.errors import SqlglotError
from sqlglot.optimizer import qualify
from sqlglot.optimizer.scope import Scope, ScopeType, traverse_scope

from lineage.ingest.static_loaders.sqlglot.sqlglot_lineage import parse_sql_cached
from lineage.ingest.static_loaders.sqlglot.types import SqlglotSchema

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Step 1: Data Model
# ---------------------------------------------------------------------------


class TransformationType(enum.Enum):
    """Classification of what happened to a column at a scope boundary."""

    PASSTHROUGH = "passthrough"
    RENAMED = "renamed"
    AGGREGATED = "aggregated"
    COMPUTED = "computed"
    WINDOWED = "windowed"
    GROUP_KEY = "group_key"
    FILTER_PREDICATE = "filter_predicate"
    JOIN_KEY = "join_key"
    ORDER_KEY = "order_key"
    WINDOW_PARTITION = "window_partition"
    WINDOW_ORDER = "window_order"
    DROPPED = "dropped"
    SOURCE = "source"
    EXTRACTION = "extraction"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class ColumnRef:
    """Identifies a column at a specific scope."""

    scope_name: str
    column_name: str


@dataclass
class ColumnTransformation:
    """What happened to a column at one scope boundary."""

    output_ref: ColumnRef
    transformation: TransformationType
    data_deps: List[ColumnRef] = field(default_factory=list)
    control_deps: List[ColumnRef] = field(default_factory=list)
    function_name: Optional[str] = None
    expression_sql: Optional[str] = None


@dataclass
class ScopeAnalysis:
    """Complete analysis of one scope."""

    scope_name: str
    scope_type: str  # "select", "union", "subquery", "cte", "root"
    columns: List[ColumnTransformation] = field(default_factory=list)
    shadow_columns: List[ColumnTransformation] = field(default_factory=list)
    has_grain_change: bool = False
    has_row_reduction: bool = False
    is_set_operation: bool = False


@dataclass
class TransformationGraph:
    """Top-level output of the transformation analysis."""

    scopes: Dict[str, ScopeAnalysis] = field(default_factory=dict)
    output_columns: List[ColumnTransformation] = field(default_factory=list)
    chains: Dict[str, List[ColumnTransformation]] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Step 2: Expression Classifier
# ---------------------------------------------------------------------------


def _get_scope_name(scope: Scope) -> str:
    """Infer scope name from a sqlglot Scope object."""
    # CTE alias
    if scope.scope_type == ScopeType.CTE:
        cte_node = scope.expression.parent
        if isinstance(cte_node, exp.CTE) and cte_node.alias:
            return cte_node.alias
    # Subquery alias
    if scope.scope_type == ScopeType.SUBQUERY:
        subq_node = scope.expression.parent
        if isinstance(subq_node, exp.Subquery) and subq_node.alias:
            return subq_node.alias
    # Derived table
    if scope.scope_type == ScopeType.DERIVED_TABLE:
        parent_exp = scope.expression.parent
        if isinstance(parent_exp, exp.Subquery) and parent_exp.alias:
            return parent_exp.alias
    # Root
    if scope.scope_type == ScopeType.ROOT:
        return "__root__"
    # Union scope — caller should provide ordinal for deterministic naming
    if scope.scope_type == ScopeType.UNION:
        return "__union__"
    # Fallback
    return "__scope__"


def _resolve_column_source(
    col: exp.Column,
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
) -> Optional[ColumnRef]:
    """Resolve a column expression to its source ColumnRef.

    Follows Recce's source_column_dependency() pattern: uses scope.sources
    to map table aliases to source scopes/tables.
    """
    col_name = col.name
    table_alias = col.table if col.table else None

    if not table_alias:
        # Unqualified column — first check CTE/subquery scope sources where
        # we can verify column existence, then fall back to direct tables.
        for _source_name, source_node in scope.sources.items():
            if isinstance(source_node, Scope):
                src_scope_name = _get_scope_name(source_node)
                if src_scope_name in scope_map:
                    for ct in scope_map[src_scope_name].columns:
                        if ct.output_ref.column_name.lower() == col_name.lower():
                            return ColumnRef(src_scope_name, col_name)

        # No CTE/scope match — collect direct table candidates.
        # If there's exactly one source table, attribute to it.
        # If multiple, return __unknown__ to avoid misattribution.
        direct_tables: List[str] = []
        for _source_name, source_node in scope.sources.items():
            if not isinstance(source_node, Scope):
                tbl_name = _table_name_from_source(source_node)
                if tbl_name:
                    direct_tables.append(tbl_name)

        if len(direct_tables) == 1:
            return ColumnRef(direct_tables[0], col_name)

        # Ambiguous or no candidates
        return ColumnRef("__unknown__", col_name)

    # Qualified column - resolve the table alias
    source = scope.sources.get(table_alias)
    if source is None:
        # Try case-insensitive lookup
        for src_name, src_node in scope.sources.items():
            if src_name.lower() == table_alias.lower():
                source = src_node
                table_alias = src_name
                break

    if source is None:
        return ColumnRef(table_alias, col_name)

    if isinstance(source, Scope):
        src_scope_name = _get_scope_name(source)
        return ColumnRef(src_scope_name, col_name)
    else:
        tbl_name = _table_name_from_source(source)
        return ColumnRef(tbl_name or table_alias, col_name)


def _table_name_from_source(source: exp.Expression) -> Optional[str]:
    """Extract table name from a source expression (exp.Table, etc.)."""
    if isinstance(source, exp.Table):
        # Return the full qualified name for matching
        parts = []
        if source.catalog:
            parts.append(source.catalog)
        if source.db:
            parts.append(source.db)
        parts.append(source.name)
        return ".".join(parts) if parts else source.name
    return None


def _extract_columns_from_expression(
    expr: exp.Expression,
) -> List[exp.Column]:
    """Extract all Column references from an expression."""
    return list(expr.find_all(exp.Column))


_SEMI_STRUCTURED_TYPES = (exp.JSONExtract, exp.JSONExtractScalar)


def _is_semi_structured_access(expr: exp.Expression) -> bool:
    """Check if an expression involves semi-structured field extraction.

    Detects Snowflake-style variant access patterns:
    - ``data:key`` (JSONExtract with variant_extract)
    - ``data['key']`` (Bracket on a Column)
    - ``GET(data, 'key')`` / ``GET_PATH(data, 'key')``
    - Any of the above inside CAST/TryCast (e.g. ``data:key::varchar``)
    - Any of the above nested inside other expressions (e.g. ``COALESCE(data:key, 'default')``)
    """
    inner = expr
    # Unwrap CAST / TryCast
    if isinstance(inner, (exp.Cast, exp.TryCast)):
        inner = inner.this
    # Direct semi-structured types
    if isinstance(inner, _SEMI_STRUCTURED_TYPES):
        return True
    # Bracket access on a Column: data['key']
    if isinstance(inner, exp.Bracket) and isinstance(inner.this, exp.Column):
        return True
    # Anonymous GET / GET_PATH functions
    if isinstance(inner, exp.Anonymous) and inner.name and inner.name.upper() in ("GET", "GET_PATH"):
        return True
    # Nested semi-structured access (e.g. COALESCE(data:key, 'default'))
    if inner.find(*_SEMI_STRUCTURED_TYPES):
        return True
    if inner.find(exp.Bracket):
        for bracket in inner.find_all(exp.Bracket):
            if isinstance(bracket.this, exp.Column):
                return True
    return False


def classify_expression(
    projection: exp.Expression,
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
    scope_name: str,
    dialect: Optional[str] = None,
) -> ColumnTransformation:
    """Classify a SELECT projection expression.

    Returns a ColumnTransformation describing what happened to the column.
    """
    # Get output column name
    output_name = projection.alias_or_name
    if not output_name:
        output_name = projection.sql(dialect=dialect, pretty=False)

    output_ref = ColumnRef(scope_name, output_name)

    # Unwrap Alias to get raw expression
    raw_expr = projection
    if isinstance(projection, exp.Alias):
        raw_expr = projection.this

    # Get all column references
    columns = _extract_columns_from_expression(raw_expr)

    # Get expression SQL
    expr_sql = raw_expr.sql(dialect=dialect, pretty=False)

    # No columns at all -> SOURCE (literal, function with no column args)
    if not columns:
        return ColumnTransformation(
            output_ref=output_ref,
            transformation=TransformationType.SOURCE,
            expression_sql=expr_sql,
        )

    # Resolve data dependencies
    data_deps = []
    for col in columns:
        ref = _resolve_column_source(col, scope, scope_map)
        if ref:
            data_deps.append(ref)

    # Check for aggregate functions
    agg_funcs = list(raw_expr.find_all(exp.AggFunc))
    if agg_funcs:
        func_name = type(agg_funcs[0]).__name__.upper()
        return ColumnTransformation(
            output_ref=output_ref,
            transformation=TransformationType.AGGREGATED,
            data_deps=data_deps,
            function_name=func_name,
            expression_sql=expr_sql,
        )

    # Check for window functions
    window_funcs = list(raw_expr.find_all(exp.Window))
    if window_funcs:
        inner = window_funcs[0].this
        func_name = type(inner).__name__.upper() if inner else "UNKNOWN"
        return ColumnTransformation(
            output_ref=output_ref,
            transformation=TransformationType.WINDOWED,
            data_deps=data_deps,
            function_name=func_name,
            expression_sql=expr_sql,
        )

    # Semi-structured field extraction (JSON path, bracket access, etc.)
    if _is_semi_structured_access(raw_expr):
        return ColumnTransformation(
            output_ref=output_ref,
            transformation=TransformationType.EXTRACTION,
            data_deps=data_deps,
            function_name="JSON_EXTRACT",
            expression_sql=expr_sql,
        )

    # Single bare column reference
    if isinstance(raw_expr, exp.Column) and len(columns) == 1:
        src_ref = _resolve_column_source(raw_expr, scope, scope_map)
        if src_ref and src_ref.column_name.lower() == output_name.lower():
            return ColumnTransformation(
                output_ref=output_ref,
                transformation=TransformationType.PASSTHROUGH,
                data_deps=data_deps,
                expression_sql=expr_sql,
            )
        else:
            return ColumnTransformation(
                output_ref=output_ref,
                transformation=TransformationType.RENAMED,
                data_deps=data_deps,
                expression_sql=expr_sql,
            )

    # Everything else: COMPUTED (arithmetic, CASE, CAST, function calls, etc.)
    return ColumnTransformation(
        output_ref=output_ref,
        transformation=TransformationType.COMPUTED,
        data_deps=data_deps,
        expression_sql=expr_sql,
    )


# ---------------------------------------------------------------------------
# Step 3: Clause Analyzers
# ---------------------------------------------------------------------------


def _analyze_where_clause(
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
    scope_name: str,
    dialect: Optional[str] = None,
) -> List[ColumnTransformation]:
    """Analyze WHERE clause for FILTER_PREDICATE shadow columns."""
    shadows: List[ColumnTransformation] = []
    select_expr = scope.expression
    where = select_expr.find(exp.Where)
    if not where:
        return shadows

    columns = _extract_columns_from_expression(where)
    for col in columns:
        ref = _resolve_column_source(col, scope, scope_map)
        if ref:
            shadows.append(
                ColumnTransformation(
                    output_ref=ColumnRef(scope_name, f"__where__{col.name}"),
                    transformation=TransformationType.FILTER_PREDICATE,
                    data_deps=[ref],
                    expression_sql=where.this.sql(dialect=dialect, pretty=False),
                )
            )
    return shadows


def _analyze_join_clauses(
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
    scope_name: str,
    dialect: Optional[str] = None,
) -> List[ColumnTransformation]:
    """Analyze JOIN ON conditions for JOIN_KEY shadow columns."""
    shadows: List[ColumnTransformation] = []
    select_expr = scope.expression

    for join in select_expr.find_all(exp.Join):
        on_clause = join.args.get("on")
        if not on_clause:
            continue
        columns = _extract_columns_from_expression(on_clause)
        for col in columns:
            ref = _resolve_column_source(col, scope, scope_map)
            if ref:
                shadows.append(
                    ColumnTransformation(
                        output_ref=ColumnRef(scope_name, f"__join__{col.name}"),
                        transformation=TransformationType.JOIN_KEY,
                        data_deps=[ref],
                        expression_sql=on_clause.sql(dialect=dialect, pretty=False),
                    )
                )
    return shadows


def _analyze_group_by(
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
    scope_name: str,
    dialect: Optional[str] = None,
) -> Tuple[List[ColumnTransformation], Set[str]]:
    """Analyze GROUP BY for GROUP_KEY shadows. Returns (shadows, group_key_names)."""
    shadows: List[ColumnTransformation] = []
    group_key_names: Set[str] = set()

    select_expr = scope.expression
    group = select_expr.find(exp.Group)
    if not group:
        return shadows, group_key_names

    for group_expr in group.expressions:
        columns = _extract_columns_from_expression(group_expr)
        for col in columns:
            col_name = col.name
            group_key_names.add(col_name.lower())
            ref = _resolve_column_source(col, scope, scope_map)
            if ref:
                shadows.append(
                    ColumnTransformation(
                        output_ref=ColumnRef(scope_name, f"__group__{col_name}"),
                        transformation=TransformationType.GROUP_KEY,
                        data_deps=[ref],
                        expression_sql=group_expr.sql(dialect=dialect, pretty=False),
                    )
                )
    return shadows, group_key_names


def _analyze_having(
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
    scope_name: str,
    dialect: Optional[str] = None,
) -> List[ColumnTransformation]:
    """Analyze HAVING clause for FILTER_PREDICATE shadows."""
    shadows: List[ColumnTransformation] = []
    select_expr = scope.expression
    having = select_expr.find(exp.Having)
    if not having:
        return shadows

    columns = _extract_columns_from_expression(having)
    for col in columns:
        ref = _resolve_column_source(col, scope, scope_map)
        if ref:
            shadows.append(
                ColumnTransformation(
                    output_ref=ColumnRef(scope_name, f"__having__{col.name}"),
                    transformation=TransformationType.FILTER_PREDICATE,
                    data_deps=[ref],
                    expression_sql=having.this.sql(dialect=dialect, pretty=False),
                )
            )
    return shadows


def _analyze_order_by(
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
    scope_name: str,
    dialect: Optional[str] = None,
) -> List[ColumnTransformation]:
    """Analyze ORDER BY for ORDER_KEY shadows."""
    shadows: List[ColumnTransformation] = []
    select_expr = scope.expression
    order = select_expr.find(exp.Order)
    if not order:
        return shadows

    for ordered in order.expressions:
        columns = _extract_columns_from_expression(ordered)
        for col in columns:
            ref = _resolve_column_source(col, scope, scope_map)
            if ref:
                shadows.append(
                    ColumnTransformation(
                        output_ref=ColumnRef(scope_name, f"__order__{col.name}"),
                        transformation=TransformationType.ORDER_KEY,
                        data_deps=[ref],
                        expression_sql=ordered.sql(dialect=dialect, pretty=False),
                    )
                )
    return shadows


def _analyze_qualify(
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
    scope_name: str,
    dialect: Optional[str] = None,
) -> List[ColumnTransformation]:
    """Analyze QUALIFY clause for FILTER_PREDICATE shadows.

    QUALIFY is a Snowflake/DuckDB clause that filters rows after window
    function evaluation, e.g. ``QUALIFY ROW_NUMBER() OVER (...) = 1``.
    """
    shadows: List[ColumnTransformation] = []
    select_expr = scope.expression
    qualify_node = select_expr.find(exp.Qualify)
    if not qualify_node:
        return shadows

    columns = _extract_columns_from_expression(qualify_node)
    for col in columns:
        ref = _resolve_column_source(col, scope, scope_map)
        if ref:
            shadows.append(
                ColumnTransformation(
                    output_ref=ColumnRef(scope_name, f"__qualify__{col.name}"),
                    transformation=TransformationType.FILTER_PREDICATE,
                    data_deps=[ref],
                    expression_sql=qualify_node.this.sql(dialect=dialect, pretty=False),
                )
            )
    return shadows


def _analyze_window_specs(
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
    scope_name: str,
    dialect: Optional[str] = None,
) -> List[ColumnTransformation]:
    """Analyze window specifications for WINDOW_PARTITION and WINDOW_ORDER shadows."""
    shadows: List[ColumnTransformation] = []
    select_expr = scope.expression

    for window in select_expr.find_all(exp.Window):
        # PARTITION BY
        partition_by = window.args.get("partition_by")
        if partition_by:
            for part_expr in partition_by:
                columns = _extract_columns_from_expression(part_expr)
                for col in columns:
                    ref = _resolve_column_source(col, scope, scope_map)
                    if ref:
                        shadows.append(
                            ColumnTransformation(
                                output_ref=ColumnRef(
                                    scope_name,
                                    f"__window_partition__{col.name}",
                                ),
                                transformation=TransformationType.WINDOW_PARTITION,
                                data_deps=[ref],
                                expression_sql=part_expr.sql(
                                    dialect=dialect, pretty=False
                                ),
                            )
                        )
        # ORDER BY within window
        window_order = window.args.get("order")
        if window_order:
            order_expr = window_order
            columns = _extract_columns_from_expression(order_expr)
            for col in columns:
                ref = _resolve_column_source(col, scope, scope_map)
                if ref:
                    shadows.append(
                        ColumnTransformation(
                            output_ref=ColumnRef(
                                scope_name, f"__window_order__{col.name}"
                            ),
                            transformation=TransformationType.WINDOW_ORDER,
                            data_deps=[ref],
                            expression_sql=order_expr.sql(dialect=dialect, pretty=False),
                        )
                    )
    return shadows


def _reclassify_with_group_by(
    columns: List[ColumnTransformation],
    group_key_names: Set[str],
) -> None:
    """Reclassify PASSTHROUGH/RENAMED columns that appear in GROUP BY to GROUP_KEY."""
    for ct in columns:
        if ct.transformation in (
            TransformationType.PASSTHROUGH,
            TransformationType.RENAMED,
        ):
            if ct.output_ref.column_name.lower() in group_key_names:
                ct.transformation = TransformationType.GROUP_KEY


# ---------------------------------------------------------------------------
# Step 4: Dropped Column Detection
# ---------------------------------------------------------------------------


def _detect_dropped_columns(
    scope: Scope,
    output_columns: List[ColumnTransformation],
    shadow_columns: List[ColumnTransformation],
    scope_map: Dict[str, ScopeAnalysis],
    scope_name: str,
) -> List[ColumnTransformation]:
    """Detect columns from source scopes that are not referenced in this scope."""
    dropped: List[ColumnTransformation] = []

    # Collect all referenced (scope_name, column_name_lower) keys across output + shadow
    referenced: Set[Tuple[str, str]] = set()
    for ct in output_columns + shadow_columns:
        for dep in ct.data_deps:
            referenced.add((dep.scope_name, dep.column_name.lower()))

    # For each source scope, check which output columns are NOT referenced
    for _source_name, source_node in scope.sources.items():
        if isinstance(source_node, Scope):
            src_scope_name = _get_scope_name(source_node)
            if src_scope_name in scope_map:
                for src_ct in scope_map[src_scope_name].columns:
                    key = (src_scope_name, src_ct.output_ref.column_name.lower())
                    if key not in referenced:
                        dropped.append(
                            ColumnTransformation(
                                output_ref=ColumnRef(
                                    scope_name,
                                    f"__dropped__{src_ct.output_ref.column_name}",
                                ),
                                transformation=TransformationType.DROPPED,
                                data_deps=[
                                    ColumnRef(
                                        src_scope_name,
                                        src_ct.output_ref.column_name,
                                    )
                                ],
                            )
                        )
    return dropped


# ---------------------------------------------------------------------------
# Step 5: Scope Analysis Orchestrators
# ---------------------------------------------------------------------------


def _get_from_clause_source_names(
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
) -> List[str]:
    """Get scope names referenced in the FROM clause of a SELECT.

    This is used when expanding SELECT * to avoid inheriting columns from ALL
    scope.sources (which includes CTEs in the same WITH clause).
    """
    from_sources: List[str] = []
    select_expr = scope.expression
    if not isinstance(select_expr, exp.Select):
        sel = select_expr.find(exp.Select) if hasattr(select_expr, "find") else None
        if sel:
            select_expr = sel
        else:
            return from_sources

    from_clause = select_expr.find(exp.From)
    if not from_clause:
        return from_sources

    # Collect table references from FROM and JOINs
    tables_in_from: List[str] = []
    for table in from_clause.find_all(exp.Table):
        tables_in_from.append(table.alias_or_name)

    # Map table aliases/names to source scopes
    for tbl_name in tables_in_from:
        source = scope.sources.get(tbl_name)
        if source is None:
            # Case-insensitive lookup
            for src_name, src_node in scope.sources.items():
                if src_name.lower() == tbl_name.lower():
                    source = src_node
                    break
        if isinstance(source, Scope):
            from_sources.append(_get_scope_name(source))
        elif source is not None:
            tbl = _table_name_from_source(source)
            if tbl:
                from_sources.append(tbl)

    return from_sources


def _analyze_select_scope(
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
    dialect: Optional[str] = None,
    *,
    scope_name: Optional[str] = None,
) -> ScopeAnalysis:
    """Analyze a SELECT scope: classify projections, analyze clauses, detect drops."""
    if scope_name is None:
        scope_name = _get_scope_name(scope)

    # Determine scope type
    scope_type_map = {
        ScopeType.ROOT: "root",
        ScopeType.CTE: "cte",
        ScopeType.SUBQUERY: "subquery",
        ScopeType.DERIVED_TABLE: "subquery",
        ScopeType.UNION: "union",
    }
    scope_type = scope_type_map.get(scope.scope_type, "select")

    # 1. Classify each SELECT projection
    output_columns: List[ColumnTransformation] = []
    select_expr = scope.expression
    if isinstance(select_expr, exp.Select):
        projections = select_expr.expressions
    elif hasattr(select_expr, "find") and select_expr.find(exp.Select):
        projections = select_expr.find(exp.Select).expressions
    else:
        projections = []

    # Check if projections contain unexpanded SELECT * (Star).
    # This happens when qualify() can't expand * for CTE references in
    # nested WITH structures. In that case, inherit columns from the
    # FROM clause source scope as PASSTHROUGH.
    has_star = any(
        isinstance(p, exp.Star)
        or (isinstance(p, exp.Column) and isinstance(p.this, exp.Star))
        for p in projections
    )
    if has_star and len(projections) == 1:
        # Identify the FROM clause target(s) — only expand * from those,
        # not from ALL scope.sources (which includes CTEs in the same WITH).
        from_scope_names = _get_from_clause_source_names(scope, scope_map)
        if from_scope_names:
            for src_scope_name in from_scope_names:
                if src_scope_name in scope_map:
                    for src_ct in scope_map[src_scope_name].columns:
                        col_name = src_ct.output_ref.column_name
                        output_columns.append(
                            ColumnTransformation(
                                output_ref=ColumnRef(scope_name, col_name),
                                transformation=TransformationType.PASSTHROUGH,
                                data_deps=[ColumnRef(src_scope_name, col_name)],
                            )
                        )
        if not output_columns:
            # Fallback: classify the Star projection normally
            for proj in projections:
                ct = classify_expression(proj, scope, scope_map, scope_name, dialect)
                output_columns.append(ct)
    else:
        for proj in projections:
            ct = classify_expression(proj, scope, scope_map, scope_name, dialect)
            output_columns.append(ct)

    # 2. Run all clause analyzers
    shadow_columns: List[ColumnTransformation] = []

    where_shadows = _analyze_where_clause(scope, scope_map, scope_name, dialect)
    shadow_columns.extend(where_shadows)

    join_shadows = _analyze_join_clauses(scope, scope_map, scope_name, dialect)
    shadow_columns.extend(join_shadows)

    group_shadows, group_key_names = _analyze_group_by(scope, scope_map, scope_name, dialect)
    shadow_columns.extend(group_shadows)

    having_shadows = _analyze_having(scope, scope_map, scope_name, dialect)
    shadow_columns.extend(having_shadows)

    qualify_shadows = _analyze_qualify(scope, scope_map, scope_name, dialect)
    shadow_columns.extend(qualify_shadows)

    order_shadows = _analyze_order_by(scope, scope_map, scope_name, dialect)
    shadow_columns.extend(order_shadows)

    window_shadows = _analyze_window_specs(scope, scope_map, scope_name, dialect)
    shadow_columns.extend(window_shadows)

    # 3. Reclassify output columns with GROUP BY
    _reclassify_with_group_by(output_columns, group_key_names)

    # 4. Link control dependencies (all output columns get filter/join shadow refs)
    control_refs = [
        ct.output_ref
        for ct in shadow_columns
        if ct.transformation
        in (TransformationType.FILTER_PREDICATE, TransformationType.JOIN_KEY)
    ]
    for ct in output_columns:
        ct.control_deps.extend(control_refs)

    # 5. Detect dropped columns
    dropped = _detect_dropped_columns(
        scope, output_columns, shadow_columns, scope_map, scope_name
    )
    shadow_columns.extend(dropped)

    # 6. Determine structural properties
    has_grain_change = bool(group_key_names)
    has_row_reduction = (
        bool(where_shadows) or bool(having_shadows) or bool(qualify_shadows)
    )

    return ScopeAnalysis(
        scope_name=scope_name,
        scope_type=scope_type,
        columns=output_columns,
        shadow_columns=shadow_columns,
        has_grain_change=has_grain_change,
        has_row_reduction=has_row_reduction,
        is_set_operation=False,
    )


def _analyze_set_scope(
    scope: Scope,
    scope_map: Dict[str, ScopeAnalysis],
    dialect: Optional[str] = None,
    *,
    scope_name: Optional[str] = None,
) -> ScopeAnalysis:
    """Analyze a UNION/INTERSECT/EXCEPT scope."""
    if scope_name is None:
        scope_name = _get_scope_name(scope)

    # Collect columns from each branch
    branch_columns: Dict[str, List[ColumnTransformation]] = {}

    for child_scope in scope.union_scopes:
        child_name = _get_scope_name(child_scope)
        if child_name in scope_map:
            for ct in scope_map[child_name].columns:
                col_name = ct.output_ref.column_name
                branch_columns.setdefault(col_name, []).append(ct)

    # Merge columns: if all branches have same transformation -> keep it; else -> COMPUTED
    output_columns: List[ColumnTransformation] = []
    for col_name, transformations in branch_columns.items():
        if not transformations:
            continue
        # Check if all branches agree
        types = {ct.transformation for ct in transformations}
        if len(types) == 1:
            merged_type = types.pop()
        else:
            merged_type = TransformationType.COMPUTED

        # Merge data_deps from all branches
        all_deps: List[ColumnRef] = []
        for ct in transformations:
            all_deps.extend(ct.data_deps)

        output_columns.append(
            ColumnTransformation(
                output_ref=ColumnRef(scope_name, col_name),
                transformation=merged_type,
                data_deps=all_deps,
            )
        )

    # Merge shadow columns across branches
    all_shadows: List[ColumnTransformation] = []
    for child_scope in scope.union_scopes:
        child_name = _get_scope_name(child_scope)
        if child_name in scope_map:
            all_shadows.extend(scope_map[child_name].shadow_columns)

    return ScopeAnalysis(
        scope_name=scope_name,
        scope_type="union",
        columns=output_columns,
        shadow_columns=all_shadows,
        is_set_operation=True,
    )


# ---------------------------------------------------------------------------
# Step 6: Chain Building
# ---------------------------------------------------------------------------


def _build_chains(
    root_analysis: ScopeAnalysis,
    scopes_by_name: Dict[str, ScopeAnalysis],
) -> Dict[str, List[ColumnTransformation]]:
    """Build lineage chains from root output columns back to base tables.

    For each output column, DFS walk backward through data_deps -> scope lookups
    until we reach base table references.
    """
    chains: Dict[str, List[ColumnTransformation]] = {}

    for ct in root_analysis.columns:
        col_name = ct.output_ref.column_name
        chain: List[ColumnTransformation] = []
        visited: Set[Tuple[str, str]] = set()

        def _walk(
            transformation: ColumnTransformation,
            _visited: Set[Tuple[str, str]] = visited,
            _chain: List[ColumnTransformation] = chain,
        ) -> None:
            key = (
                transformation.output_ref.scope_name,
                transformation.output_ref.column_name,
            )
            if key in _visited:
                return
            _visited.add(key)

            # Walk backward through data dependencies
            for dep in transformation.data_deps:
                dep_scope = scopes_by_name.get(dep.scope_name)
                if dep_scope:
                    # Find the transformation that produces this column in the dep scope
                    for dep_ct in dep_scope.columns:
                        if (
                            dep_ct.output_ref.column_name.lower()
                            == dep.column_name.lower()
                        ):
                            _walk(dep_ct)
                            break

            _chain.append(transformation)

        _walk(ct)
        chains[col_name] = chain

    return chains


# ---------------------------------------------------------------------------
# Step 7: Top-Level Entry Point
# ---------------------------------------------------------------------------


def analyze_query(
    sql: str,
    schema: Optional[SqlglotSchema] = None,
    dialect: Optional[str] = None,
) -> TransformationGraph:
    """Analyze a SQL query for transformation-aware column lineage.

    Args:
        sql: SQL query string
        schema: Optional SqlglotSchema for SELECT * expansion
        dialect: SQL dialect (e.g., "duckdb", "snowflake")

    Returns:
        TransformationGraph with scopes, output columns, and chains
    """
    # 1. Parse + qualify
    try:
        expression = parse_sql_cached(sql, dialect)
    except SqlglotError as e:
        logger.warning(f"Failed to parse SQL for transformation analysis: {e}")
        return TransformationGraph()

    schema_dict = schema.to_dict() if schema else None
    if schema_dict:
        try:
            expression = qualify.qualify(
                expression,
                schema=schema_dict,
                dialect=dialect,
                validate_qualify_columns=False,
            )
        except SqlglotError as e:
            logger.warning(f"qualify() failed during transformation analysis: {e}")

    # 2. Handle recursive CTEs: detect With.args.get('recursive')
    with_clause = expression.find(exp.With)
    recursive_cte_names: Set[str] = set()
    if with_clause and with_clause.args.get("recursive"):
        for cte in with_clause.expressions:
            if isinstance(cte, exp.CTE) and cte.alias:
                recursive_cte_names.add(cte.alias)

    # 3. Traverse scopes depth-first (inner scopes first)
    try:
        scopes = traverse_scope(expression)
    except SqlglotError as e:
        logger.warning(f"traverse_scope() failed: {e}")
        return TransformationGraph()

    scope_map: Dict[str, ScopeAnalysis] = {}
    root_analysis: Optional[ScopeAnalysis] = None
    # Track ordinals for deterministic naming of duplicate scope names
    scope_name_counts: Dict[str, int] = {}

    for scope in scopes:
        scope_name = _get_scope_name(scope)
        # Make scope names unique by appending ordinal for duplicates
        if scope_name in scope_map:
            count = scope_name_counts.get(scope_name, 1)
            scope_name_counts[scope_name] = count + 1
            scope_name = f"{scope_name.rstrip('_')}_{count}__"
        else:
            scope_name_counts[scope_name] = 1

        # Skip recursive CTE members (only analyze anchor).
        # UNION scopes get unique names via id(), so detect recursion by
        # checking whether the scope's parent CTE is in the recursive set.
        if scope.scope_type == ScopeType.UNION and recursive_cte_names:
            parent_cte = scope.expression.find_ancestor(exp.CTE)
            if parent_cte and getattr(parent_cte, "alias", None) in recursive_cte_names:
                continue

        # Dispatch based on scope type, passing the deduplicated name so that
        # ScopeAnalysis.scope_name and all ColumnRefs match the scope_map key.
        if scope.scope_type == ScopeType.UNION:
            analysis = _analyze_set_scope(scope, scope_map, dialect, scope_name=scope_name)
        else:
            analysis = _analyze_select_scope(scope, scope_map, dialect, scope_name=scope_name)

        scope_map[scope_name] = analysis

        # The last scope is the root
        if scope.scope_type == ScopeType.ROOT:
            root_analysis = analysis

    if root_analysis is None:
        # Fallback: use the last analyzed scope
        if scope_map:
            root_analysis = list(scope_map.values())[-1]
        else:
            return TransformationGraph()

    # 4. Build chains from root analysis
    chains = _build_chains(root_analysis, scope_map)

    return TransformationGraph(
        scopes=scope_map,
        output_columns=root_analysis.columns,
        chains=chains,
    )
