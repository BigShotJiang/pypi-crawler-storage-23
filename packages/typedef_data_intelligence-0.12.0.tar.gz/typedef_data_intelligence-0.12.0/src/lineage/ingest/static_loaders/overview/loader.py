"""Project overview loader for sync pipeline.

Generates and stores a ProjectOverview graph node during sync,
after clustering is complete.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import asdict
from typing import Any

from lineage.agent.overview import compute_project_overview
from lineage.backends.lineage.protocol import LineageStorage

logger = logging.getLogger(__name__)


class ProjectOverviewLoader:
    """Generates and persists the project overview during sync."""

    def __init__(self, storage: LineageStorage):  # noqa: D107
        self.storage = storage

    async def _generate_async(
        self, session: Any = None, verbose: bool = False
    ) -> None:
        """Async implementation of overview generation."""
        if verbose:
            logger.info("Computing project overview...")

        data = await compute_project_overview(self.storage, session=session)
        overview_dict = {k: v for k, v in asdict(data).items() if v is not None}

        self.storage.write_project_overview(overview_dict)

        if verbose:
            logger.info(
                f"Project overview stored: {data.project_name}, "
                f"{data.model_count} models"
            )

    def generate(self, session: Any = None, verbose: bool = False) -> None:
        """Generate and store the project overview (sync entry point).

        Args:
            session: Optional Fenic session for LLM cells
            verbose: Whether to log progress details
        """
        asyncio.run(self._generate_async(session=session, verbose=verbose))
