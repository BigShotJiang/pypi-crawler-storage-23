"""Shared ProcessPoolExecutor for CPU-bound lineage operations.

This module provides a global process pool that can be shared across multiple
concurrent operations (fingerprinting, column lineage extraction) to prevent
worker explosion when running many tasks in parallel.

Usage:
    from lineage.ingest.static_loaders.shared_pool import get_shared_executor, submit_batch

    # Option 1: Get executor directly
    executor = get_shared_executor()
    future = executor.submit(my_func, arg1, arg2)

    # Option 2: Submit a batch of work items
    results = submit_batch(worker_fn, items, initializer=my_init)

The pool is lazily initialized on first use and automatically sized based on
CPU count. Call shutdown_shared_executor() to clean up when done (optional -
the pool will be cleaned up on process exit).
"""

from __future__ import annotations

import atexit
import logging
import os
import warnings
from concurrent.futures import Future, ProcessPoolExecutor, as_completed
from threading import Lock
from typing import Callable, Iterator, TypeVar

logger = logging.getLogger(__name__)


def default_worker_initializer() -> None:
    """Default worker initializer that suppresses common warnings.

    This is used as the default initializer for the shared process pool.
    Suppresses deprecation warnings and other noisy warnings that can flood
    logs when processing many models in parallel.
    """
    warnings.simplefilter("ignore", DeprecationWarning)
    warnings.simplefilter("ignore", UserWarning)
    warnings.filterwarnings("ignore", message=".*class-based.*config.*is deprecated.*")
    warnings.filterwarnings("ignore", message=".*PydanticDeprecatedSince20.*")
    warnings.filterwarnings("ignore", message="Field name .* shadows an attribute")
    warnings.filterwarnings("ignore", message=".*swigvarlink.*")
    warnings.filterwarnings("ignore", message=".*lance is not fork-safe.*")
    warnings.filterwarnings("ignore", message=".*multi-threaded.*use of fork.*")
    warnings.filterwarnings("ignore", message=".*default datetime adapter is deprecated.*")

# Module-level shared executor and lock
_shared_executor: ProcessPoolExecutor | None = None
_executor_lock = Lock()
_executor_initializer: Callable[[], None] | None = None

T = TypeVar("T")
R = TypeVar("R")


def get_shared_executor(
    max_workers: int | None = None,
    initializer: Callable[[], None] | None = None,
) -> ProcessPoolExecutor:
    """Get or create the shared ProcessPoolExecutor.

    The executor is lazily initialized on first call. Subsequent calls return
    the same executor instance (initializer is only used on first call).

    Args:
        max_workers: Maximum number of workers. Defaults to CPU count.
            Only used on first call; ignored if executor already exists.
        initializer: Worker initialization function. Defaults to
            default_worker_initializer which suppresses common warnings.
            Only used on first call; ignored if executor already exists.

    Returns:
        The shared ProcessPoolExecutor instance.
    """
    global _shared_executor, _executor_initializer

    if _shared_executor is not None:
        return _shared_executor

    with _executor_lock:
        # Double-check after acquiring lock
        if _shared_executor is not None:
            return _shared_executor

        if max_workers is None:
            max_workers = os.cpu_count() or 4

        # Use default initializer if none provided
        if initializer is None:
            initializer = default_worker_initializer

        logger.info(f"Initializing shared process pool with {max_workers} workers")

        _executor_initializer = initializer
        _shared_executor = ProcessPoolExecutor(
            max_workers=max_workers,
            initializer=initializer,
        )

        # Register cleanup on process exit
        atexit.register(shutdown_shared_executor)

        return _shared_executor


def shutdown_shared_executor(wait: bool = True) -> None:
    """Shutdown the shared executor if it exists.

    This is automatically called on process exit, but can be called manually
    for explicit cleanup.

    Args:
        wait: If True, wait for pending futures to complete.
    """
    global _shared_executor

    with _executor_lock:
        if _shared_executor is not None:
            logger.info("Shutting down shared process pool")
            _shared_executor.shutdown(wait=wait)
            _shared_executor = None


def submit_batch(
    fn: Callable[..., R],
    items: list[T],
    *,
    chunk_size: int | None = None,
    chunk_fn: Callable[[list[T]], R] | None = None,
    initializer: Callable[[], None] | None = None,
    single_process: bool = False,
) -> Iterator[tuple[int, R | Exception]]:
    """Submit a batch of work items to the shared pool.

    Supports two modes:
    1. Per-item submission: Each item is processed individually
    2. Chunked submission: Items are grouped into chunks, reducing overhead

    Args:
        fn: Worker function for per-item mode. Called as fn(item).
        items: List of work items to process.
        chunk_size: If provided, items are chunked and chunk_fn is used.
        chunk_fn: Worker function for chunked mode. Called as chunk_fn(chunk).
            Required if chunk_size is provided.
        initializer: Initializer for workers (only used on first pool creation).
        single_process: If True, process items sequentially in current process.

    Yields:
        Tuples of (index, result) where index is the item/chunk index and
        result is either the return value or an Exception on failure.

    Example:
        # Per-item mode
        for idx, result in submit_batch(process_model, models):
            if isinstance(result, Exception):
                logger.error(f"Failed: {result}")
            else:
                results[idx] = result

        # Chunked mode
        for chunk_idx, chunk_results in submit_batch(
            fn=None,
            items=models,
            chunk_size=10,
            chunk_fn=process_model_chunk,
        ):
            for result in chunk_results:
                ...
    """
    if not items:
        return

    if single_process:
        # Sequential processing in current process
        if chunk_size and chunk_fn:
            chunks = [items[i : i + chunk_size] for i in range(0, len(items), chunk_size)]
            for idx, chunk in enumerate(chunks):
                try:
                    yield idx, chunk_fn(chunk)
                except Exception as e:
                    yield idx, e
        else:
            for idx, item in enumerate(items):
                try:
                    yield idx, fn(item)
                except Exception as e:
                    yield idx, e
        return

    # Get shared executor
    executor = get_shared_executor(initializer=initializer)

    if chunk_size and chunk_fn:
        # Chunked submission
        chunks = [items[i : i + chunk_size] for i in range(0, len(items), chunk_size)]
        future_to_idx: dict[Future[R], int] = {
            executor.submit(chunk_fn, chunk): idx for idx, chunk in enumerate(chunks)
        }
    else:
        # Per-item submission
        future_to_idx = {executor.submit(fn, item): idx for idx, item in enumerate(items)}

    for future in as_completed(future_to_idx):
        idx = future_to_idx[future]
        try:
            yield idx, future.result()
        except Exception as e:
            yield idx, e
