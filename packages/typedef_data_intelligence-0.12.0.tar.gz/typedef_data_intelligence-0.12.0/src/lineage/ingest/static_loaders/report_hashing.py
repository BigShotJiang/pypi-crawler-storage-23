"""Content hashing and change detection for BI platform report nodes.

Provides generic utilities for computing deterministic hashes of raw API
responses and comparing them against stored hashes in the graph to identify
added, modified, and unchanged reports.  This mirrors the dbt change
detection pattern (``ChangeDetector`` / ``ModelChangeSet``) but operates on
native report nodes (e.g. ``SfReport``) rather than ``DbtModel``.

Usage::

    from lineage.ingest.static_loaders.report_hashing import (
        ReportChangeSet,
        compute_content_hash,
        detect_report_changes,
        load_report_hashes,
    )

    # 1. Hash each raw API response
    current = {rid: compute_content_hash(desc) for rid, desc in describes.items()}
    # 2. Load stored hashes from graph
    stored = load_report_hashes(storage, "SfReport", list(current))
    # 3. Diff
    changes = detect_report_changes(current, stored)
    for rid in changes.reports_to_process:
        ...
"""

from __future__ import annotations

import hashlib
import json
import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional, Union

if TYPE_CHECKING:
    from lineage.backends.lineage.protocol import LineageStorage

logger = logging.getLogger(__name__)


def compute_content_hash(raw_data: Union[dict, list, str]) -> str:
    """Deterministic SHA-256 of raw report data from any BI platform.

    Accepts a dict (JSON API response), list, or pre-serialised string.
    Dicts and lists are serialised with ``json.dumps(sort_keys=True,
    default=str)`` for determinism.

    Args:
        raw_data: Raw API response payload.

    Returns:
        Full-length hex SHA-256 digest.
    """
    if isinstance(raw_data, str):
        content = raw_data
    else:
        content = json.dumps(raw_data, sort_keys=True, default=str)
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _is_empty_graph_error(error: Exception) -> bool:
    """Check if *error* indicates an empty / non-existent graph table."""
    error_str = str(error).lower()
    return any(msg in error_str for msg in ["does not exist", "not found", "no such"])


def load_report_hashes(
    storage: "LineageStorage",
    node_label: str,
    ids: list[str],
) -> dict[str, Optional[str]]:
    """Batch-load ``content_hash`` values from the graph for native report nodes.

    Generic — works with any node type that exposes a ``content_hash``
    property (e.g. ``SfReport``).

    The pattern follows ``ChangeDetector._load_graph_state()``: connection
    errors propagate, schema / table-not-found errors return an empty dict.

    Args:
        storage: Graph storage backend.
        node_label: Cypher node label (e.g. ``"SfReport"``).
        ids: List of node IDs to look up.

    Returns:
        Mapping of ``node_id -> content_hash`` (hash may be ``None`` if
        the node exists but has no hash stored).
    """
    if not ids:
        return {}

    query = (
        f"MATCH (n:{node_label}) "
        "WHERE n.id IN $ids "
        "RETURN n.id AS id, n.content_hash AS content_hash"
    )

    try:
        result = storage.execute_raw_query(query, params={"ids": ids})
        hashes: dict[str, Optional[str]] = {}

        for row in result.rows:
            node_id = row.get("id")
            if node_id:
                hashes[node_id] = row.get("content_hash")

        logger.debug(
            "Loaded content hashes for %d/%d %s nodes",
            len(hashes),
            len(ids),
            node_label,
        )
        return hashes

    except Exception as e:
        # Connection / infrastructure errors should fail fast
        if isinstance(e, (ConnectionError, TimeoutError, OSError)):
            logger.error(
                "Database connection failed while loading %s hashes: %s",
                node_label,
                e,
            )
            raise

        # Schema / table doesn't exist → empty graph is expected on first run
        if _is_empty_graph_error(e):
            logger.debug(
                "Graph appears empty (no %s table): %s", node_label, e
            )
            return {}

        logger.warning(
            "Failed to load %s hashes: %s", node_label, e, exc_info=True
        )
        return {}


@dataclass
class ReportChangeSet:
    """Result of comparing new vs. stored content hashes for reports."""

    added: list[str]  # New report IDs (not in graph)
    modified: list[str]  # Changed hash
    unchanged: list[str]  # Same hash — safe to skip

    @property
    def reports_to_process(self) -> list[str]:
        """Reports that need (re-)processing: added + modified."""
        return self.added + self.modified


def detect_report_changes(
    current_hashes: dict[str, str],
    stored_hashes: dict[str, Optional[str]],
) -> ReportChangeSet:
    """Compare new content hashes against stored ones from the graph.

    The comparison logic mirrors ``ChangeDetector.detect_changes()`` in
    ``change_detection.py``.

    Args:
        current_hashes: Mapping of ``native_id -> new_hash`` computed from
            the latest API responses.
        stored_hashes: Mapping of ``native_id -> stored_hash`` loaded from
            the graph (may contain ``None`` values for nodes without a hash).

    Returns:
        A :class:`ReportChangeSet` partitioning IDs into added, modified,
        and unchanged buckets.
    """
    added: list[str] = []
    modified: list[str] = []
    unchanged: list[str] = []

    for report_id, new_hash in current_hashes.items():
        if report_id not in stored_hashes:
            added.append(report_id)
            continue

        stored_hash = stored_hashes[report_id]
        if stored_hash != new_hash:
            modified.append(report_id)
        else:
            unchanged.append(report_id)

    logger.info(
        "Report change detection: %d added, %d modified, %d unchanged",
        len(added),
        len(modified),
        len(unchanged),
    )

    return ReportChangeSet(added=added, modified=modified, unchanged=unchanged)


__all__ = [
    "ReportChangeSet",
    "compute_content_hash",
    "detect_report_changes",
    "load_report_hashes",
]
