"""Salesforce-to-dbt cross-domain stitcher — phase 5.

Creates ``DEPENDS_ON`` edges (DbtSource → SfObject) and ``MAPS_TO_COLUMN``
edges (SfField/SfReportColumn → DbtColumn) between Salesforce nodes and
existing dbt graph nodes using a three-tier resolution strategy:

    Tier 1 — Deterministic matching (no LLM): exact name and ``__c``-suffix
             stripping heuristics.
    Tier 2 — LLM-assisted matching via Fenic ``fc.semantic.extract()`` for
             unmatched assets (optional, gated by ``use_llm`` flag).
    Tier 3 — No match: SF nodes remain in the graph without stitching edges
             and can be resolved later.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

from lineage.backends.lineage.models.edges import MapsToColumn, SourceDependsOn

if TYPE_CHECKING:
    from lineage.backends.lineage.protocol import LineageStorage
    from lineage.ingest.config import AnalysisModelsConfig

logger = logging.getLogger(__name__)


class SalesforceStitcher:
    """Deterministic + optional LLM stitching of SF nodes to dbt nodes.

    Args:
        storage: Graph storage with ``create_edge`` and ``execute_raw_query``.
        org_key: The Salesforce org key used during ingestion.
        use_llm: Whether to attempt LLM-assisted matching for unresolved
                 assets (Tier 2).  Default ``True``.
        analysis_models: LLM model configuration (required when ``use_llm``
                         is ``True``).  Passed to :func:`create_session`.
        llm_confidence_threshold: Minimum confidence to accept an LLM match.
        verbose: Enable verbose logging.
    """

    def __init__(
        self,
        storage: "LineageStorage",
        org_key: str,
        use_llm: bool = True,
        analysis_models: Optional[AnalysisModelsConfig] = None,
        llm_confidence_threshold: float = 0.75,
        verbose: bool = False,
    ) -> None:
        """Initialise stitcher with storage, org key, and matching options."""
        self.storage = storage
        self.org_key = org_key
        self.use_llm = use_llm
        self.analysis_models = analysis_models
        self.llm_confidence_threshold = llm_confidence_threshold
        self.verbose = verbose

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def _cleanup_weak_llm_edges(self) -> None:
        """Delete LLM-created stitch edges below the confidence threshold.

        Removes stale ``DEPENDS_ON`` (with source='llm') and ``MAPS_TO_COLUMN``
        edges with ``source='llm'`` that fall below the current
        ``llm_confidence_threshold``.  This handles cases where the threshold
        has been raised since a previous run.
        """
        for rel_type in ("DEPENDS_ON", "MAPS_TO_COLUMN"):
            # Count before deleting — referencing e after DELETE is
            # undefined in some Cypher implementations.
            count_result = self.storage.execute_raw_query(
                f"MATCH ()-[e:{rel_type}]->() "
                f"WHERE e.source = 'llm' AND e.confidence < $threshold "
                f"RETURN count(e) AS deleted",
                {"threshold": self.llm_confidence_threshold},
            )
            deleted = 0
            if hasattr(count_result, "rows") and count_result.rows:
                deleted = count_result.rows[0].get("deleted", 0)
            if deleted:
                self.storage.execute_raw_query(
                    f"MATCH ()-[e:{rel_type}]->() "
                    f"WHERE e.source = 'llm' AND e.confidence < $threshold "
                    f"DELETE e",
                    {"threshold": self.llm_confidence_threshold},
                )
                logger.info(
                    "Cleaned up %d stale %s edges below confidence %.2f",
                    deleted, rel_type, self.llm_confidence_threshold,
                )

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def stitch(self) -> dict[str, int]:
        """Run stitching and return summary counts.

        Returns:
            Dict with keys ``source_matches``, ``column_matches``,
            ``llm_source_matches``, ``llm_column_matches``.
        """
        counts: dict[str, int] = {
            "source_matches": 0,
            "column_matches": 0,
            "llm_source_matches": 0,
            "llm_column_matches": 0,
        }

        # Clean up weak LLM edges from prior runs
        self._cleanup_weak_llm_edges()

        # Load dbt sources and columns from graph
        dbt_sources = self._load_dbt_sources()
        if not dbt_sources:
            logger.info("No DbtSource nodes in graph — skipping stitching")
            return counts

        sf_objects = self._load_sf_objects()
        if not sf_objects:
            logger.info("No SfObject nodes for org %s — skipping stitching", self.org_key)
            return counts

        # Import fenic and create session if LLM is enabled
        fc = None
        session = None
        if self.use_llm:
            if self.analysis_models is None:
                logger.warning(
                    "use_llm=True but no analysis_models provided — LLM stitching disabled"
                )
            else:
                try:
                    import fenic as _fc  # type: ignore[import-untyped]

                    from lineage.ingest.static_loaders.semantic.config.session import (
                        create_session,
                    )

                    fc = _fc
                    session = create_session(
                        self.analysis_models, app_name="sf_stitcher"
                    )
                except ImportError:
                    logger.info("Fenic not available — LLM stitching disabled")
                    fc = None

        try:
            # Tier 1: deterministic matching (+ LLM column fallback if fc)
            unmatched_objects, claimed_sources = self._tier1_deterministic(
                sf_objects, dbt_sources, counts, fc=fc, session=session,
            )

            # Tier 2: LLM-assisted matching (if enabled and unmatched remain)
            # Exclude DbtSources already claimed in tier 1 to enforce 1:1 matching
            if fc is not None and session is not None and unmatched_objects:
                available_sources = {
                    k: v for k, v in dbt_sources.items() if k not in claimed_sources
                }
                if available_sources:
                    self._tier2_llm(
                        unmatched_objects, available_sources, counts, fc=fc, session=session,
                    )
        finally:
            if session is not None:
                try:
                    session.stop(skip_usage_summary=True)
                except Exception:
                    logger.debug("Failed to stop Fenic session cleanly", exc_info=True)

        logger.info(
            "Stitching complete: %d source matches (det), %d column matches (det), "
            "%d source matches (llm), %d column matches (llm)",
            counts["source_matches"],
            counts["column_matches"],
            counts["llm_source_matches"],
            counts["llm_column_matches"],
        )
        return counts

    # ------------------------------------------------------------------
    # Data loading helpers
    # ------------------------------------------------------------------

    def _load_dbt_sources(self) -> dict[str, dict]:
        """Load all DbtSource nodes from the graph, keyed by normalised name."""
        qr = self.storage.execute_raw_query(
            "MATCH (s:DbtSource) "
            "RETURN s.id AS id, s.name AS name, s.description AS description"
        )
        result: dict[str, dict] = {}
        for row in qr.rows:
            name = (row.get("name") or "").lower()
            result[name] = {
                "id": row["id"],
                "name": row.get("name", ""),
                "description": row.get("description") or "",
            }
        return result

    def _load_sf_objects(self) -> list[dict]:
        """Load all SfObject nodes for the configured org."""
        qr = self.storage.execute_raw_query(
            "MATCH (o:SfObject) WHERE o.org_key = $org_key "
            "RETURN o.id AS id, o.api_name AS api_name, "
            "o.description AS description",
            {"org_key": self.org_key},
        )
        return [
            {
                "id": r["id"],
                "api_name": r["api_name"],
                "description": r.get("description") or "",
            }
            for r in qr.rows
        ]

    def _load_dbt_columns_for_source(self, source_id: str) -> dict[str, str]:
        """Load DbtColumn nodes linked to a DbtSource, keyed by normalised name.

        Returns:
            Dict mapping lowercase column name → DbtColumn id.
        """
        qr = self.storage.execute_raw_query(
            "MATCH (s:DbtSource)-[:MATERIALIZES]->(c:DbtColumn) "
            "WHERE s.id = $sid RETURN c.id AS id, c.name AS name",
            {"sid": source_id},
        )
        return {(r["name"] or "").lower(): r["id"] for r in qr.rows}

    def _load_sf_fields_for_object(self, object_id: str) -> list[dict]:
        """Load SfField nodes belonging to an SfObject."""
        qr = self.storage.execute_raw_query(
            "MATCH (o:SfObject)-[:SF_HAS_FIELD]->(f:SfField) "
            "WHERE o.id = $oid RETURN f.id AS id, f.field_api_name AS field_api_name",
            {"oid": object_id},
        )
        return [{"id": r["id"], "field_api_name": r["field_api_name"]} for r in qr.rows]

    # ------------------------------------------------------------------
    # Tier 1: Deterministic
    # ------------------------------------------------------------------

    def _normalize_sf_name(self, api_name: str) -> str:
        """Lowercase and strip ``__c`` suffix."""
        name = api_name.lower()
        if name.endswith("__c"):
            name = name[:-3]
        return name

    def _tier1_deterministic(
        self,
        sf_objects: list[dict],
        dbt_sources: dict[str, dict],
        counts: dict[str, int],
        fc: object | None = None,
        session: object | None = None,
    ) -> tuple[list[dict], set[str]]:
        """Tier 1: exact name / suffix-stripped matching.

        Args:
            sf_objects: SfObject dicts loaded from the graph.
            dbt_sources: DbtSource dicts keyed by normalised name.
            counts: Mutable summary counters updated in place.
            fc: Optional fenic module reference for LLM column fallback.
            session: Optional Fenic session for DataFrame creation.

        Returns:
            Tuple of (unmatched SfObject dicts, claimed DbtSource names).
        """
        from lineage.backends.lineage.models.base import NodeIdentifier
        from lineage.backends.types import NodeLabel

        unmatched: list[dict] = []
        claimed_sources: set[str] = set()

        for sf_obj in sf_objects:
            api_name = sf_obj["api_name"]
            norm_name = self._normalize_sf_name(api_name)

            # Exact match (raw lowered name)
            matched_key = api_name.lower()
            match = dbt_sources.get(matched_key)
            rule_id = "exact_name"
            conf = 1.0

            # Try with __c stripped
            if not match and api_name.lower() != norm_name:
                matched_key = norm_name
                match = dbt_sources.get(matched_key)
                rule_id = "strip_suffix"
                conf = 0.9

            if match:
                from_ref = NodeIdentifier(id=match["id"], node_label=NodeLabel.DBT_SOURCE)
                to_ref = NodeIdentifier(id=sf_obj["id"], node_label=NodeLabel.SF_OBJECT)
                self.storage.create_edge(
                    from_ref,
                    to_ref,
                    SourceDependsOn(source="heuristic", confidence=conf, rule_id=rule_id),
                )
                counts["source_matches"] += 1
                claimed_sources.add(matched_key)

                # Column-level matching
                matched_sf, matched_dbt = self._match_columns_deterministic(
                    sf_obj_id=sf_obj["id"],
                    dbt_source_id=match["id"],
                    counts=counts,
                )
                if fc is not None and session is not None:
                    self._match_columns_llm(
                        sf_obj_id=sf_obj["id"],
                        dbt_source_id=match["id"],
                        matched_sf_field_ids=matched_sf,
                        matched_dbt_col_ids=matched_dbt,
                        counts=counts,
                        fc=fc,
                        session=session,
                    )
            else:
                unmatched.append(sf_obj)

        return unmatched, claimed_sources

    def _match_columns_deterministic(
        self,
        sf_obj_id: str,
        dbt_source_id: str,
        counts: dict[str, int],
    ) -> tuple[set[str], set[str]]:
        """Match SfField nodes to DbtColumn nodes by normalised name.

        Returns:
            Tuple of (matched SF field IDs, matched dbt column IDs).
        """
        from lineage.backends.lineage.models.base import NodeIdentifier
        from lineage.backends.types import NodeLabel

        matched_sf: set[str] = set()
        matched_dbt: set[str] = set()

        dbt_cols = self._load_dbt_columns_for_source(dbt_source_id)
        if not dbt_cols:
            return matched_sf, matched_dbt

        sf_fields = self._load_sf_fields_for_object(sf_obj_id)

        for sf_field in sf_fields:
            norm = self._normalize_sf_name(sf_field["field_api_name"])
            col_id = dbt_cols.get(sf_field["field_api_name"].lower())
            rule_id = "exact_name"
            conf = 1.0

            if not col_id and sf_field["field_api_name"].lower() != norm:
                col_id = dbt_cols.get(norm)
                rule_id = "strip_suffix"
                conf = 0.9

            if col_id:
                from_ref = NodeIdentifier(id=sf_field["id"], node_label=NodeLabel.SF_FIELD)
                to_ref = NodeIdentifier(id=col_id, node_label=NodeLabel.DBT_COLUMN)
                self.storage.create_edge(
                    from_ref,
                    to_ref,
                    MapsToColumn(source="heuristic", confidence=conf, rule_id=rule_id),
                )
                counts["column_matches"] += 1
                matched_sf.add(sf_field["id"])
                matched_dbt.add(col_id)

        return matched_sf, matched_dbt

    def _match_columns_llm(
        self,
        sf_obj_id: str,
        dbt_source_id: str,
        matched_sf_field_ids: set[str],
        matched_dbt_col_ids: set[str],
        counts: dict[str, int],
        fc: object,
        session: object,
    ) -> None:
        """Match remaining SfField→DbtColumn pairs using LLM extraction.

        Sends all unmatched fields from both sides in a single LLM call
        per object pair for efficient disambiguation.

        Args:
            sf_obj_id: ID of the SfObject whose fields to match.
            dbt_source_id: ID of the DbtSource whose columns to match against.
            matched_sf_field_ids: SF field IDs already matched in deterministic pass.
            matched_dbt_col_ids: DbtColumn IDs already matched in deterministic pass.
            counts: Mutable summary counters updated in place.
            fc: The fenic module (already imported).
            session: The Fenic session for DataFrame creation.
        """
        from pydantic import BaseModel, Field

        from lineage.backends.lineage.models.base import NodeIdentifier
        from lineage.backends.types import NodeLabel

        class ColumnMatchPair(BaseModel):
            sf_field_name: str
            dbt_column_name: str
            confidence: float

        class ColumnMatchResult(BaseModel):
            matches: list[ColumnMatchPair] = Field(default_factory=list)

        # Load fields and columns, filter out already-matched ones
        sf_fields = self._load_sf_fields_for_object(sf_obj_id)
        unmatched_sf = [f for f in sf_fields if f["id"] not in matched_sf_field_ids]

        dbt_cols = self._load_dbt_columns_for_source(dbt_source_id)
        unmatched_dbt = {
            name: col_id
            for name, col_id in dbt_cols.items()
            if col_id not in matched_dbt_col_ids
        }

        if not unmatched_sf or not unmatched_dbt:
            return

        sf_field_names = [f["field_api_name"] for f in unmatched_sf]
        dbt_col_names = list(unmatched_dbt.keys())

        prompt_text = (
            f"Match Salesforce field names to dbt column names where they refer "
            f"to the same concept. Salesforce uses CamelCase (e.g. AnnualRevenue) "
            f"while dbt uses snake_case (e.g. annual_revenue). Only return "
            f"confident matches.\n\n"
            f"Salesforce fields: {sf_field_names}\n"
            f"dbt columns: {dbt_col_names}"
        )

        try:
            df = session.create_dataframe([{"prompt": prompt_text}])  # type: ignore[union-attr]
            df = df.with_column(
                "result",
                fc.semantic.extract(  # type: ignore[union-attr]
                    fc.col("prompt"),  # type: ignore[union-attr]
                    ColumnMatchResult,
                    model_alias="small",
                ),
            )
            rows = df.to_pylist()
            raw_result = rows[0]["result"]
            # to_pylist() returns dicts; rehydrate into Pydantic model
            result = (
                ColumnMatchResult.model_validate(raw_result)
                if isinstance(raw_result, dict)
                else raw_result
            )
        except Exception:
            logger.debug(
                "LLM column extraction failed for SF object %s", sf_obj_id
            )
            return

        # Build lookup: lowered SF field name → SF field dict
        sf_by_name = {f["field_api_name"].lower(): f for f in unmatched_sf}

        for pair in result.matches:
            conf = pair.confidence
            sf_name = pair.sf_field_name
            dbt_name = pair.dbt_column_name
            if conf < self.llm_confidence_threshold:
                continue

            sf_field = sf_by_name.get(sf_name.lower())
            col_id = unmatched_dbt.get(dbt_name.lower())

            if sf_field and col_id:
                from_ref = NodeIdentifier(
                    id=sf_field["id"], node_label=NodeLabel.SF_FIELD
                )
                to_ref = NodeIdentifier(id=col_id, node_label=NodeLabel.DBT_COLUMN)
                self.storage.create_edge(
                    from_ref,
                    to_ref,
                    MapsToColumn(
                        source="llm",
                        confidence=conf,
                        rule_id="llm_small",
                    ),
                )
                counts["llm_column_matches"] += 1

    # ------------------------------------------------------------------
    # Tier 2: LLM-assisted (Fenic)
    # ------------------------------------------------------------------

    def _tier2_llm(
        self,
        unmatched_objects: list[dict],
        dbt_sources: dict[str, dict],
        counts: dict[str, int],
        *,
        fc: object,
        session: object,
    ) -> None:
        """Tier 2: use Fenic semantic extraction for unmatched SF objects.

        Batches all unmatched objects into a single DataFrame for efficient
        LLM processing.

        Args:
            unmatched_objects: SfObject dicts that had no deterministic match.
            dbt_sources: Available (unclaimed) DbtSource dicts keyed by name.
            counts: Mutable summary counters updated in place.
            fc: The fenic module reference (session managed by ``stitch()``).
            session: The Fenic session for DataFrame creation.
        """
        from pydantic import BaseModel, Field

        from lineage.backends.lineage.models.base import NodeIdentifier
        from lineage.backends.types import NodeLabel

        class SourceMatchResult(BaseModel):
            """LLM resolution of SfObject to DbtSource."""
            dbt_source_name: Optional[str] = Field(
                default=None, description="Best matching DbtSource name, or null"
            )
            confidence: float = Field(
                default=0.0, description="0.0-1.0 match confidence"
            )
            reasoning: str = Field(
                default="", description="Why this match was chosen"
            )

        # Build context of available dbt sources with their columns
        if not dbt_sources:
            return

        # Pre-load dbt source columns for context
        dbt_source_context: dict[str, dict] = {}
        for src_name, src_info in dbt_sources.items():
            cols = self._load_dbt_columns_for_source(src_info["id"])
            dbt_source_context[src_name] = {
                "description": src_info.get("description", ""),
                "columns": list(cols.keys()),
            }

        # Format dbt sources as structured context
        dbt_context_lines: list[str] = []
        for src_name, ctx in dbt_source_context.items():
            desc = f" — {ctx['description']}" if ctx["description"] else ""
            col_list = ", ".join(ctx["columns"][:20])  # Cap at 20 columns
            if len(ctx["columns"]) > 20:
                col_list += f", ... (+{len(ctx['columns']) - 20} more)"
            dbt_context_lines.append(
                f"  - {src_name}{desc} [columns: {col_list}]"
            )
        dbt_context_block = "\n".join(dbt_context_lines)

        # Build DataFrame rows — one per unmatched SF object
        rows = []
        for sf_obj in unmatched_objects:
            api_name = sf_obj["api_name"]
            sf_desc = sf_obj.get("description", "")

            # Load SF field names for this object
            sf_fields = self._load_sf_fields_for_object(sf_obj["id"])
            sf_field_names = [f["field_api_name"] for f in sf_fields]
            sf_fields_str = ", ".join(sf_field_names[:20])
            if len(sf_field_names) > 20:
                sf_fields_str += f", ... (+{len(sf_field_names) - 20} more)"

            sf_desc_line = f" ({sf_desc})" if sf_desc else ""

            prompt_text = (
                f"Determine if the Salesforce SObject '{api_name}'{sf_desc_line} "
                f"corresponds to any dbt source in the list below. "
                f"Match based on whether they represent the SAME business entity "
                f"or data concept — not just similar names. Compare field/column "
                f"structures to verify the match.\n\n"
                f"Salesforce object: {api_name}\n"
                f"  Fields: {sf_fields_str}\n\n"
                f"Available dbt sources:\n{dbt_context_block}\n\n"
                f"Return null for dbt_source_name if no source is a genuine match."
            )
            rows.append({
                "sf_obj_id": sf_obj["id"],
                "api_name": api_name,
                "prompt": prompt_text,
            })

        try:
            df = session.create_dataframe(rows)  # type: ignore[union-attr]
            df = df.with_column(
                "result",
                fc.semantic.extract(  # type: ignore[union-attr]
                    fc.col("prompt"),  # type: ignore[union-attr]
                    SourceMatchResult,
                    model_alias="small",
                ),
            )
            result_rows = df.to_pylist()
        except Exception:
            logger.debug("LLM extraction failed for tier-2 batch")
            return

        # Track sources claimed within this tier to enforce 1:1 matching
        claimed_in_tier2: set[str] = set()

        # Process highest-confidence matches first
        result_rows.sort(
            key=lambda r: (
                r["result"].get("confidence", 0)
                if isinstance(r["result"], dict)
                else getattr(r["result"], "confidence", 0)
            ),
            reverse=True,
        )

        for row in result_rows:
            raw_result = row["result"]
            sf_obj_id = row["sf_obj_id"]

            # to_pylist() returns dicts; rehydrate into Pydantic model
            result = (
                SourceMatchResult.model_validate(raw_result)
                if isinstance(raw_result, dict)
                else raw_result
            )

            if (
                result.dbt_source_name
                and result.confidence >= self.llm_confidence_threshold
            ):
                source_key = result.dbt_source_name.lower()
                if source_key in claimed_in_tier2:
                    logger.debug(
                        "Skipping LLM match %s → %s (source already claimed)",
                        sf_obj_id, result.dbt_source_name,
                    )
                    continue
                match = dbt_sources.get(source_key)
                if match:
                    from_ref = NodeIdentifier(
                        id=match["id"], node_label=NodeLabel.DBT_SOURCE
                    )
                    to_ref = NodeIdentifier(
                        id=sf_obj_id, node_label=NodeLabel.SF_OBJECT
                    )
                    self.storage.create_edge(
                        from_ref,
                        to_ref,
                        SourceDependsOn(
                            source="llm",
                            confidence=result.confidence,
                            rule_id="llm_small",
                        ),
                    )
                    counts["llm_source_matches"] += 1
                    claimed_in_tier2.add(source_key)

                    # Column-level matching: deterministic + LLM fallback
                    matched_sf, matched_dbt = self._match_columns_deterministic(
                        sf_obj_id=sf_obj_id,
                        dbt_source_id=match["id"],
                        counts=counts,
                    )
                    self._match_columns_llm(
                        sf_obj_id=sf_obj_id,
                        dbt_source_id=match["id"],
                        matched_sf_field_ids=matched_sf,
                        matched_dbt_col_ids=matched_dbt,
                        counts=counts,
                        fc=fc,
                        session=session,
                    )


__all__ = ["SalesforceStitcher"]
