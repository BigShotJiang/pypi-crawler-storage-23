"""Password-based Salesforce authentication (backward-compatible wrapper)."""
from __future__ import annotations

from dataclasses import dataclass, field

from lineage.ingest.static_loaders.salesforce.auth.protocol import (
    SalesforceCredentials,
)


@dataclass
class PasswordAuth:
    """Wraps legacy username/password/security_token credentials.

    When the client detects ``PasswordAuth``, it uses the legacy
    ``simple_salesforce`` constructor (which handles SOAP login internally)
    rather than the ``session_id`` path.

    ``authenticate`` and ``refresh_if_needed`` raise ``NotImplementedError``
    because the actual login is handled by ``simple_salesforce`` directly.
    """

    instance_url: str
    username: str
    password: str = field(repr=False)
    security_token: str = field(repr=False)

    def authenticate(self) -> SalesforceCredentials:
        """Not implemented — authentication is handled by simple_salesforce."""
        raise NotImplementedError(
            "PasswordAuth delegates authentication to simple_salesforce directly"
        )

    def refresh_if_needed(self) -> SalesforceCredentials:
        """Not implemented — authentication is handled by simple_salesforce."""
        raise NotImplementedError(
            "PasswordAuth delegates authentication to simple_salesforce directly"
        )


__all__ = ["PasswordAuth"]
