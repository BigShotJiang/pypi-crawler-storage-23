"""OAuth 2.0 Device Authorization Grant for Salesforce.

No local callback server needed — works in headless/SSH environments.
The user visits a URL and enters a code, while the CLI polls for completion.
"""
from __future__ import annotations

import logging
import time
import webbrowser
from dataclasses import dataclass, field
from typing import Optional

import httpx

from lineage.ingest.static_loaders.salesforce.auth.protocol import (
    SalesforceCredentials,
)
from lineage.ingest.static_loaders.salesforce.auth.token_store import (
    StoredTokens,
    TokenStore,
)

logger = logging.getLogger(__name__)


@dataclass
class OAuthDeviceFlowAuth:
    """OAuth 2.0 Device Authorization Grant authentication.

    Ideal for CLI usage, especially in headless environments (SSH, CI).
    The user opens a URL in any browser (even on a different device),
    enters a code, and approves access.

    Args:
        client_id: Salesforce Connected App consumer key.
        login_url: Salesforce login URL (use ``https://test.salesforce.com``
            for sandboxes).
        org_key: Token store key for multi-org support.
    """

    client_id: str
    login_url: str = "https://login.salesforce.com"
    org_key: str = "default"
    _token_store: TokenStore = field(init=False, repr=False)
    _credentials: Optional[SalesforceCredentials] = field(
        default=None, init=False, repr=False
    )

    def __post_init__(self) -> None:
        """Initialise the token store for this org."""
        self._token_store = TokenStore(org_key=self.org_key)

    def authenticate(self) -> SalesforceCredentials:
        """Authenticate via Device Flow.

        First tries to use a cached refresh token. If unavailable or
        expired, initiates the device authorization flow.
        """
        # Try cached refresh token first
        stored = self._token_store.load()
        if stored and stored.refresh_token:
            try:
                creds = self._refresh(stored.refresh_token)
                self._credentials = creds
                return creds
            except Exception:
                logger.info("Cached refresh token expired — starting device flow")

        # Step 1: Request device code
        device_data = self._request_device_code()

        user_code = device_data["user_code"]
        verification_uri = device_data["verification_uri"]
        device_code = device_data["device_code"]
        interval = device_data.get("interval", 5)

        # Step 2: Display instructions to user (flush to ensure visibility)
        print(f"\n  Open: {verification_uri}", flush=True)
        print(f"  Enter code: {user_code}\n", flush=True)

        # Try to open browser (non-fatal if this fails; user can still copy URL)
        try:
            webbrowser.open(verification_uri)
        except Exception as exc:
            logger.debug("Failed to open browser for Salesforce device flow: %s", exc)

        # Step 3: Poll for authorization
        creds = self._poll_for_token(device_code, interval)
        self._credentials = creds
        return creds

    def refresh_if_needed(self) -> SalesforceCredentials:
        """Refresh credentials using stored refresh token."""
        stored = self._token_store.load()
        if stored and stored.refresh_token:
            creds = self._refresh(stored.refresh_token)
            self._credentials = creds
            return creds
        return self.authenticate()

    def _request_device_code(self) -> dict:
        """POST to the device authorization endpoint."""
        data = {
            "response_type": "device_code",
            "client_id": self.client_id,
            "scope": "api refresh_token",
        }
        response = httpx.post(
            f"{self.login_url}/services/oauth2/token",
            data=data,
            timeout=30.0,
        )
        response.raise_for_status()
        return response.json()

    def _poll_for_token(
        self, device_code: str, interval: int
    ) -> SalesforceCredentials:
        """Poll the token endpoint until the user approves or times out."""
        # Salesforce uses "device" instead of the RFC 8628 standard URN
        data = {
            "grant_type": "device",
            "client_id": self.client_id,
            "code": device_code,
        }

        max_attempts = 120  # 10 minutes at 5s interval
        for _attempt in range(max_attempts):
            time.sleep(interval)

            response = httpx.post(
                f"{self.login_url}/services/oauth2/token",
                data=data,
                timeout=30.0,
            )

            if response.status_code == 200:
                token_data = response.json()
                self._token_store.save(
                    StoredTokens(
                        access_token=token_data["access_token"],
                        instance_url=token_data["instance_url"],
                        refresh_token=token_data.get("refresh_token"),
                        token_type=token_data.get("token_type", "Bearer"),
                        issued_at=token_data.get("issued_at"),
                        org_key=self.org_key,
                    )
                )
                return SalesforceCredentials(
                    access_token=token_data["access_token"],
                    instance_url=token_data["instance_url"],
                )

            # Handle pending/slow_down responses
            error_data = response.json()
            error = error_data.get("error", "")

            if error == "authorization_pending":
                continue
            elif error == "slow_down":
                interval = min(interval + 5, 60)
                continue
            elif error == "expired_token":
                raise TimeoutError("Device code expired — user did not authorize in time")
            else:
                raise RuntimeError(
                    f"Device flow error: {error} — {error_data.get('error_description', '')}"
                )

        raise TimeoutError("Device flow polling timed out")

    def _refresh(self, refresh_token: str) -> SalesforceCredentials:
        """Use refresh_token grant to get a new access token."""
        data = {
            "grant_type": "refresh_token",
            "client_id": self.client_id,
            "refresh_token": refresh_token,
        }
        response = httpx.post(
            f"{self.login_url}/services/oauth2/token",
            data=data,
            timeout=30.0,
        )
        response.raise_for_status()
        token_data = response.json()

        self._token_store.save(
            StoredTokens(
                access_token=token_data["access_token"],
                instance_url=token_data["instance_url"],
                refresh_token=token_data.get("refresh_token", refresh_token),
                token_type=token_data.get("token_type", "Bearer"),
                issued_at=token_data.get("issued_at"),
                org_key=self.org_key,
            )
        )

        return SalesforceCredentials(
            access_token=token_data["access_token"],
            instance_url=token_data["instance_url"],
        )


__all__ = ["OAuthDeviceFlowAuth"]
