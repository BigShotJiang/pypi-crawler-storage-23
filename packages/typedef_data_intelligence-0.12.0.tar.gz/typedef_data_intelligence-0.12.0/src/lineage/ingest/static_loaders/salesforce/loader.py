"""Salesforce graph loader — phases 1-4 (SF-internal nodes and edges).

Fetches metadata via ``SalesforceMetadataClient`` and upserts Salesforce
nodes and internal edges into the lineage graph storage.

Phases:
    1. Create ``SalesforceOrg`` node.
    2. For each SObject → ``SfObject`` + ``SfField`` nodes and edges.
       For lookup/MD fields → ``SF_REFERENCES`` edges to target ``SfObject``.
    3. For each Report → ``SfReport`` + ``SfReportColumn`` nodes and edges.
       Apply ingestion rules: exact → heuristic → no edge (keep node).
    4. For each Dashboard → ``SfDashboard`` + ``SfDashboardComponent`` nodes.
       Link components to reports where resolvable.
"""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime, timezone
from fnmatch import fnmatch
from typing import TYPE_CHECKING, Any, Callable, Optional

from lineage.backends.lineage.models.edges import (
    SfComponentUsesReport,
    SfDashboardHasComponent,
    SfHasDashboard,
    SfHasField,
    SfHasObject,
    SfHasReport,
    SfReferences,
    SfReportColumnUsesField,
    SfReportDependsOnObject,
    SfReportHasColumn,
)
from lineage.backends.lineage.models.report import NativeReportDefinition
from lineage.backends.lineage.models.salesforce import (
    SalesforceOrg,
    SfDashboard,
    SfDashboardComponent,
    SfField,
    SfObject,
    SfReport,
    SfReportColumn,
    _stable_hash,
)
from lineage.ingest.static_loaders.report_hashing import (
    ReportChangeSet,
    compute_content_hash,
    detect_report_changes,
    load_report_hashes,
)
from lineage.ingest.static_loaders.salesforce.client import SalesforceMetadataClient

if TYPE_CHECKING:
    from lineage.backends.lineage.protocol import LineageStorage

logger = logging.getLogger(__name__)


class SalesforceLoader:
    """Orchestrates phases 1-4 of Salesforce metadata ingestion.

    Args:
        client: Initialised ``SalesforceMetadataClient``.
        storage: Graph storage implementing ``upsert_node`` / ``create_edge``.
        org_key: Stable alias for the org (falls back to ``{instance}:{orgId}``).
        sobject_filter: Optional list of SObject API names to limit ingestion.
        sobject_exclude_patterns: Glob-style patterns to exclude SObjects (e.g. ``*Feed``).
        sobject_exclude: Explicit SObject API names to exclude.
        include_reports: Whether to ingest reports (phase 3).
        include_dashboards: Whether to ingest dashboards (phase 4).
        verbose: Enable verbose logging.
        max_workers: Maximum concurrent describe calls (default 10).
        on_progress: Optional callback ``(current, total, details)`` for progress reporting.
    """

    def __init__(
        self,
        client: SalesforceMetadataClient,
        storage: "LineageStorage",
        org_key: Optional[str] = None,
        sobject_filter: Optional[list[str]] = None,
        sobject_exclude_patterns: Optional[list[str]] = None,
        sobject_exclude: Optional[list[str]] = None,
        include_reports: bool = True,
        include_dashboards: bool = True,
        verbose: bool = False,
        max_workers: int = 10,
        on_progress: Optional[Callable[[int, int, str], None]] = None,
    ) -> None:
        """Initialise loader with client, storage backend, and ingestion options."""
        self.client = client
        self.storage = storage
        self._org_key = org_key
        self.sobject_filter = sobject_filter
        self.sobject_exclude_patterns = sobject_exclude_patterns or []
        self._exclude_set = set(sobject_exclude or [])
        self.include_reports = include_reports
        self.include_dashboards = include_dashboards
        self.verbose = verbose
        self.max_workers = max_workers
        self.on_progress = on_progress

        # Populated during load
        self._org_node: Optional[SalesforceOrg] = None
        # Lookup: api_name -> SfObject node (for reference resolution)
        self._object_nodes: dict[str, SfObject] = {}
        # Lookup: (object_api_name, field_api_name) -> SfField node
        self._field_nodes: dict[tuple[str, str], SfField] = {}
        # Lookup: report_id -> SfReport node
        self._report_nodes: dict[str, SfReport] = {}
        # Change detection results from phase 3 (exposed for CLI reporting)
        self.report_changes: Optional[ReportChangeSet] = None

    @property
    def org_key(self) -> str:
        """Return the Salesforce org key, raising if not yet set."""
        if self._org_key:
            return self._org_key
        raise RuntimeError("org_key not set — call load() or set org_key explicitly")

    def _report_progress(self, current: int, total: int, details: str) -> None:
        """Emit a progress update if a callback is registered."""
        if self.on_progress:
            self.on_progress(current, total, details)

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    async def load(self) -> None:
        """Execute all ingestion phases."""
        self._phase1_org()
        await self._phase2_objects_and_fields()
        if self.include_reports:
            await self._phase3_reports()
        if self.include_dashboards:
            await self._phase4_dashboards()

    # ------------------------------------------------------------------
    # Phase 1: Org
    # ------------------------------------------------------------------

    def _phase1_org(self) -> None:
        org_info = self.client.get_org_info()

        if not self._org_key:
            self._org_key = f"{org_info.get('instance_url', 'unknown')}:{org_info['org_id']}"

        now = datetime.now(timezone.utc).isoformat()
        self._org_node = SalesforceOrg(
            name=org_info.get("name", self.org_key),
            org_key=self.org_key,
            instance_url=org_info.get("instance_url", ""),
            org_type=org_info.get("org_type"),
            api_version=self.client.api_version,
            fetched_at=now,
        )
        self.storage.upsert_node(self._org_node)
        logger.info("Phase 1: Created SalesforceOrg node %s", self._org_node.id)

    # ------------------------------------------------------------------
    # Phase 2: SObjects + Fields
    # ------------------------------------------------------------------

    def _cleanup_excluded_objects(self) -> None:
        """Delete SfObject (and connected SfField) nodes that match exclude rules.

        This ensures stale nodes from previous unfiltered loads are removed
        from the graph before upserting the current filtered set.
        """
        if not self.sobject_exclude_patterns and not self._exclude_set:
            return

        # Fetch all SfObject api_names for this org from the graph
        result = self.storage.execute_raw_query(
            "MATCH (o:SfObject) WHERE o.org_key = $org_key "
            "RETURN o.api_name AS api_name",
            {"org_key": self.org_key},
        )
        existing_names: list[str] = [r["api_name"] for r in result.rows]  # type: ignore[union-attr]

        to_delete: list[str] = []
        for api_name in existing_names:
            if any(fnmatch(api_name, pat) for pat in self.sobject_exclude_patterns):
                to_delete.append(api_name)
            elif api_name in self._exclude_set:
                to_delete.append(api_name)

        if not to_delete:
            return

        # Delete SfField nodes attached to excluded SfObjects, then the SfObjects.
        # DETACH DELETE removes the node and all its edges (SF_REFERENCES,
        # MAPS_TO_COLUMN, DEPENDS_ON stitching edges, etc.).
        for api_name in to_delete:
            self.storage.execute_raw_query(
                "MATCH (o:SfObject {org_key: $org_key, api_name: $api_name})"
                "-[:SF_HAS_FIELD]->(f:SfField) "
                "DETACH DELETE f",
                {"org_key": self.org_key, "api_name": api_name},
            )
            self.storage.execute_raw_query(
                "MATCH (o:SfObject {org_key: $org_key, api_name: $api_name}) "
                "DETACH DELETE o",
                {"org_key": self.org_key, "api_name": api_name},
            )

        logger.info(
            "Phase 2: Cleaned up %d excluded SfObject nodes from graph", len(to_delete)
        )

    async def _phase2_objects_and_fields(self) -> None:
        assert self._org_node is not None

        # Clean up stale excluded objects from prior loads
        if not self.sobject_filter:
            self._cleanup_excluded_objects()

        sobjects = self.client.list_sobjects()
        total = len(sobjects)
        logger.info("Phase 2: Fetched %d SObjects, describing each...", total)

        # Phase 2a: Create SfObject nodes (fast, no HTTP per-object)
        filtered_objects: list[tuple[str, SfObject]] = []
        for sobj in sobjects:
            api_name = sobj.get("name")
            if not api_name:
                continue
            if self.sobject_filter and api_name not in self.sobject_filter:
                continue
            # When whitelist is active, skip exclude checks
            if not self.sobject_filter:
                if any(fnmatch(api_name, pat) for pat in self.sobject_exclude_patterns):
                    continue
                if api_name in self._exclude_set:
                    continue

            obj_node = SfObject(
                name=api_name,
                api_name=api_name,
                org_key=self.org_key,
                is_custom=sobj.get("custom", False),
                is_queryable=sobj.get("queryable", True),
                key_prefix=sobj.get("keyPrefix"),
                description=sobj.get("label"),
            )
            self.storage.upsert_node(obj_node)
            self.storage.create_edge(self._org_node, obj_node, SfHasObject())
            self._object_nodes[api_name] = obj_node
            filtered_objects.append((api_name, obj_node))

        # Phase 2b: Describe all objects in parallel
        semaphore = asyncio.Semaphore(self.max_workers)
        total_filtered = len(filtered_objects)
        counter = 0

        async def describe_one(
            api_name: str, obj_node: SfObject
        ) -> list[tuple[tuple[str, str], SfField]]:
            nonlocal counter
            async with semaphore:
                try:
                    desc = await asyncio.to_thread(self.client.describe_sobject, api_name)
                except Exception:
                    counter += 1
                    logger.warning(
                        "Phase 2: [%d/%d] Failed to describe %s — skipping fields",
                        counter, total_filtered, api_name,
                    )
                    return []

                fields: list[tuple[tuple[str, str], SfField]] = []
                for field_meta in desc.get("fields", []):
                    field_api = field_meta.get("name")
                    if not field_api:
                        continue
                    ref_to_raw = field_meta.get("referenceTo") or []
                    ref_to = [r for r in ref_to_raw if isinstance(r, str)]

                    # Extract picklist active values (labels only)
                    pv_raw = field_meta.get("picklistValues") or []
                    picklist_vals = [
                        v["label"]
                        for v in pv_raw
                        if isinstance(v, dict) and v.get("active") and v.get("label")
                    ] or None

                    # Coerce defaultValue to str (API may return bool/int)
                    raw_default = field_meta.get("defaultValue")
                    default_str = str(raw_default) if raw_default is not None else None

                    field_node = SfField(
                        name=field_api,
                        field_api_name=field_api,
                        object_api_name=api_name,
                        org_key=self.org_key,
                        data_type=field_meta.get("type"),
                        is_custom=field_meta.get("custom", False),
                        is_nillable=field_meta.get("nillable", True),
                        length=field_meta.get("length"),
                        reference_to=ref_to or None,
                        formula=field_meta.get("calculatedFormula"),
                        description=field_meta.get("label"),
                        # Grain inference & data quality
                        is_unique=field_meta.get("unique", False),
                        is_external_id=field_meta.get("externalId", False),
                        default_value=default_str,
                        default_value_formula=field_meta.get("defaultValueFormula"),
                        is_restricted_picklist=field_meta.get("restrictedPicklist", False),
                        picklist_values=picklist_vals,
                        is_case_sensitive=field_meta.get("caseSensitive", False),
                        # Type precision
                        scale=field_meta.get("scale"),
                        precision=field_meta.get("precision"),
                        digits=field_meta.get("digits"),
                        # Mutability
                        is_updateable=field_meta.get("updateable", False),
                        is_createable=field_meta.get("createable", False),
                        # Analytics / query capability
                        is_filterable=field_meta.get("filterable", False),
                        is_sortable=field_meta.get("sortable", False),
                        is_groupable=field_meta.get("groupable", False),
                        is_aggregatable=field_meta.get("aggregatable", False),
                        # Documentation
                        inline_help_text=field_meta.get("inlineHelpText"),
                        compound_field_name=field_meta.get("compoundFieldName"),
                        extra_type_info=field_meta.get("extraTypeInfo"),
                        display_format=field_meta.get("displayFormat"),
                    )
                    self.storage.upsert_node(field_node)
                    self.storage.create_edge(obj_node, field_node, SfHasField())
                    fields.append(((api_name, field_api), field_node))

                counter += 1
                field_count = len(fields)
                logger.info(
                    "Phase 2: [%d/%d] %s (%d fields)",
                    counter, total_filtered, api_name, field_count,
                )
                self._report_progress(counter, total_filtered, f"SObjects [{counter}/{total_filtered}] {api_name}")
                return fields

        results = await asyncio.gather(
            *[describe_one(name, node) for name, node in filtered_objects],
            return_exceptions=True,
        )

        # Collect field nodes from results
        for result in results:
            if isinstance(result, BaseException):
                logger.warning("Phase 2: Unexpected error in describe task: %s", result)
                continue
            for key, field_node in result:
                self._field_nodes[key] = field_node

        # Phase 2c: Create SF_REFERENCES edges for lookup/MD fields
        for (_obj_api, _field_api), field_node in self._field_nodes.items():
            if not field_node.reference_to:
                continue
            rel_type = None
            # Determine relationship type from data_type
            if field_node.data_type == "reference":
                rel_type = "Lookup"

            for target_api in field_node.reference_to:
                target_obj = self._object_nodes.get(target_api)
                if target_obj:
                    self.storage.create_edge(
                        field_node,
                        target_obj,
                        SfReferences(relationship_type=rel_type),
                    )

        logger.info(
            "Phase 2: Created %d SfObject and %d SfField nodes",
            len(self._object_nodes),
            len(self._field_nodes),
        )

    # ------------------------------------------------------------------
    # Phase 3: Reports
    # ------------------------------------------------------------------

    async def _phase3_reports(self) -> None:
        assert self._org_node is not None
        try:
            reports = self.client.list_reports()
        except Exception:
            logger.warning("Failed to list reports — skipping phase 3")
            return

        now = datetime.now(timezone.utc).isoformat()
        total = len(reports)
        logger.info("Phase 3: Fetched %d reports, describing each...", total)

        # Create report nodes first
        report_items: list[tuple[str, SfReport]] = []
        for rpt in reports:
            report_id = rpt.get("id") or rpt.get("Id") or ""
            if not report_id:
                continue

            report_node = SfReport(
                name=rpt.get("name", report_id),
                report_id=report_id,
                org_key=self.org_key,
                report_type=rpt.get("reportTypeApiName") or rpt.get("reportType"),
                folder_name=rpt.get("folderName") or rpt.get("folderId"),
                description=rpt.get("description"),
                fetched_at=now,
            )
            self.storage.upsert_node(report_node)
            self.storage.create_edge(self._org_node, report_node, SfHasReport())
            self._report_nodes[report_id] = report_node
            report_items.append((report_id, report_node))

        # Load existing content hashes from graph for change detection
        report_node_ids = [rnode.id for _, rnode in report_items]
        stored_hashes = load_report_hashes(self.storage, "SfReport", report_node_ids)
        # Will be populated after describe: node_id -> new hash
        current_hashes: dict[str, str] = {}

        # Fetch developer name mapping for Metadata API access
        # Maps report ID -> fullName (e.g., "MyFolder/MyReport")
        try:
            dev_name_mapping = await asyncio.to_thread(
                self.client.get_report_developer_names
            )
            logger.info(
                "Phase 3: Fetched developer names for %d reports",
                len(dev_name_mapping),
            )
        except Exception as e:
            logger.warning("Phase 3: Could not fetch developer names: %s", e)
            dev_name_mapping = {}

        # Describe reports in parallel
        semaphore = asyncio.Semaphore(self.max_workers)
        counter = 0
        # Cache report-type describes to avoid redundant API calls.
        # An asyncio.Lock per key prevents concurrent tasks from making
        # duplicate describe_report_type calls for the same report type.
        rt_describe_cache: dict[str, dict[str, Any] | None] = {}
        rt_cache_locks: dict[str, asyncio.Lock] = {}
        rt_locks_guard = asyncio.Lock()
        # Maps column_key -> object_api_name from report type categories
        rt_column_to_object: dict[str, dict[str, str]] = {}  # rt_api_name -> {col_key: obj_api}
        # Cache resolved primary object per report type
        rt_primary_obj_cache: dict[str, str | None] = {}

        async def _get_rt_describe(rt_api_name: str) -> dict[str, Any] | None:
            """Fetch and cache a report-type describe, deduplicating concurrent requests."""
            # Fast path: return cached result without acquiring locks
            if rt_api_name in rt_describe_cache and rt_api_name in rt_column_to_object:
                return rt_describe_cache[rt_api_name]

            async with rt_locks_guard:
                if rt_api_name not in rt_cache_locks:
                    rt_cache_locks[rt_api_name] = asyncio.Lock()
                lock = rt_cache_locks[rt_api_name]

            async with lock:
                # Re-check cache after acquiring lock (another task may have populated it)
                if rt_api_name in rt_describe_cache:
                    result = rt_describe_cache[rt_api_name]
                else:
                    try:
                        result = await asyncio.to_thread(
                            self.client.describe_report_type, rt_api_name,
                        )
                    except Exception:
                        logger.debug(
                            "Phase 3: Could not describe report type %s",
                            rt_api_name,
                        )
                        result = None
                    rt_describe_cache[rt_api_name] = result

                # Build column-to-object mapping (check if already built)
                if result is not None and rt_api_name not in rt_column_to_object:
                    rt_meta = result.get("reportTypeMetadata", {})
                    col_to_obj: dict[str, str] = {}

                    # Map category labels to object API names
                    objects = rt_meta.get("objects", [])
                    obj_label_to_api: dict[str, str] = {}
                    for obj in objects:
                        # Use both name and apiName for matching
                        api_name = obj.get("apiName", "")
                        obj_name = obj.get("name", "")
                        if api_name:
                            obj_label_to_api[api_name.lower()] = api_name
                            if obj_name:
                                obj_label_to_api[obj_name.lower()] = api_name

                    # Parse categories to map columns to objects
                    for category in rt_meta.get("categories", []):
                        cat_label = category.get("label", "")
                        # Try to match category label to an object
                        # Categories often named like "Opportunity Information" -> Opportunity
                        matched_obj = None
                        cat_label_lower = cat_label.lower()
                        for obj_key, obj_api in obj_label_to_api.items():
                            if obj_key in cat_label_lower or cat_label_lower in obj_key:
                                matched_obj = obj_api
                                break

                        if matched_obj:
                            columns = category.get("columns", {})
                            for col_key in columns.keys():
                                col_to_obj[col_key] = matched_obj

                    rt_column_to_object[rt_api_name] = col_to_obj
                    logger.debug(
                        "Phase 3: Built column->object mapping for %s: %d columns",
                        rt_api_name, len(col_to_obj),
                    )

                return result

        async def describe_one_report(report_id: str, report_node: SfReport) -> None:
            nonlocal counter
            async with semaphore:
                try:
                    desc = await asyncio.to_thread(self.client.describe_report, report_id)
                except Exception:
                    counter += 1
                    logger.warning(
                        "Phase 3: [%d/%d] Failed to describe report %s — skipping columns",
                        counter, total, report_id,
                    )
                    return

                counter += 1

                # Compute content hash for change detection
                new_hash = compute_content_hash(desc)
                current_hashes[report_node.id] = new_hash

                # Check if report is unchanged — skip column processing
                stored_hash = stored_hashes.get(report_node.id)
                if stored_hash == new_hash:
                    logger.info(
                        "Phase 3: [%d/%d] %s unchanged — skipping",
                        counter, total, report_node.name,
                    )
                    self._report_progress(
                        counter, total,
                        f"Reports [{counter}/{total}] {report_node.name} (unchanged)",
                    )
                    return

                logger.info("Phase 3: [%d/%d] %s", counter, total, report_node.name)
                self._report_progress(counter, total, f"Reports [{counter}/{total}] {report_node.name}")

                # Extract report type and format from describe response and update the node.
                # Always set content_hash (new or modified report) and re-upsert.
                report_metadata = desc.get("reportMetadata", {})
                rt_info = report_metadata.get("reportType", {})
                rt_api_name = rt_info.get("type")
                report_format = report_metadata.get("reportFormat")
                report_node.content_hash = new_hash
                if rt_api_name and not report_node.report_type:
                    report_node.report_type = rt_api_name
                if report_format and not report_node.report_format:
                    report_node.report_format = report_format.lower()
                self.storage.upsert_node(report_node)

                # Describe the report *type* to get its SObject dependencies
                rt_desc: dict[str, Any] | None = None
                if rt_api_name:
                    rt_desc = await _get_rt_describe(rt_api_name)
                    if rt_desc is not None:
                        rt_meta = rt_desc.get("reportTypeMetadata", {})
                        for obj_entry in rt_meta.get("objects", []):
                            obj_api = obj_entry.get("apiName", "")
                            target_obj = self._object_nodes.get(obj_api)
                            if target_obj:
                                self.storage.create_edge(
                                    report_node,
                                    target_obj,
                                    SfReportDependsOnObject(
                                        role="source", confidence=1.0,
                                    ),
                                )

                # Resolve the primary SObject for this report type (cached)
                primary_obj: str | None = None
                if rt_api_name:
                    if rt_api_name in rt_primary_obj_cache:
                        primary_obj = rt_primary_obj_cache[rt_api_name]
                    else:
                        primary_obj = self._resolve_primary_object(
                            rt_api_name, rt_desc,
                        )
                        rt_primary_obj_cache[rt_api_name] = primary_obj

                # Fetch full Metadata API response first — needed both for
                # NativeReportDefinition storage AND as a fallback column source
                # when the REST API returns empty detailColumns (e.g. LeadList,
                # CampaignList report types).
                dev_name = dev_name_mapping.get(report_id)
                metadata_full: dict[str, Any] | None = None
                if dev_name:
                    logger.info(
                        "Phase 3: Reading Metadata API for %s -> %s",
                        report_node.name, dev_name,
                    )
                    try:
                        metadata_full = await asyncio.to_thread(
                            self.client.read_report_metadata_full, dev_name
                        )
                        if metadata_full:
                            canonical_report_id = f"report::salesforce::{report_id}"
                            native_def = NativeReportDefinition(
                                name=f"{report_node.name} Metadata",
                                report_id=canonical_report_id,
                                system="salesforce",
                                format="metadata-api",
                                content=json.dumps(metadata_full, default=str),
                                fetched_at=now,
                            )
                            self.storage.upsert_node(native_def)
                            logger.info(
                                "Phase 3: Stored NativeReportDefinition for %s (keys: %s)",
                                report_node.name, list(metadata_full.keys())[:5],
                            )
                        else:
                            logger.warning(
                                "Phase 3: Metadata API returned empty for %s",
                                dev_name,
                            )
                    except Exception as e:
                        logger.warning(
                            "Phase 3: Could not fetch Metadata API for %s: %s",
                            dev_name, e,
                        )
                else:
                    logger.warning(
                        "Phase 3: No developer name found for report %s (id=%s)",
                        report_node.name, report_id,
                    )

                # Columns - use REST API extended metadata for richer column info
                columns_meta = report_metadata.get("detailColumns", [])
                extended_metadata = desc.get("reportExtendedMetadata", {})
                detail_column_info = extended_metadata.get("detailColumnInfo", {})

                # Get column-to-object mapping for this report type
                col_to_obj = rt_column_to_object.get(rt_api_name, {}) if rt_api_name else {}

                # Build MDAPI field-to-object mapping from Object$FieldName refs
                mdapi_col_to_obj: dict[str, str] = {}
                if metadata_full:
                    mdapi_col_to_obj = self._build_mdapi_col_to_obj(
                        metadata_full, primary_obj=primary_obj,
                    )
                    if mdapi_col_to_obj:
                        logger.debug(
                            "Phase 3: Built MDAPI col_to_obj for %s: %d mappings",
                            report_node.name, len(mdapi_col_to_obj),
                        )

                # Track column_keys created from detailColumns (or MDAPI fallback)
                # so we can create auxiliary SfReportColumn nodes for grouping/filter/bucket
                # fields that aren't already represented.
                created_col_keys: set[str] = set()

                # Fallback: when REST API returns 0 detailColumns (e.g. LeadList,
                # CampaignList), use the Metadata API's columns array instead.
                # Metadata API columns have field refs in "Object$FieldName" format.
                if not columns_meta and metadata_full:
                    mdapi_columns = metadata_full.get("columns")
                    if isinstance(mdapi_columns, list):
                        pass  # already a list
                    elif isinstance(mdapi_columns, dict):
                        mdapi_columns = [mdapi_columns]
                    elif mdapi_columns is None:
                        mdapi_columns = []
                    else:
                        mdapi_columns = []

                    if mdapi_columns:
                        logger.info(
                            "Phase 3: REST API returned 0 detailColumns for %s, "
                            "using %d columns from Metadata API",
                            report_node.name, len(mdapi_columns),
                        )

                    for md_col in mdapi_columns:
                        field_ref = md_col.get("field", "") if isinstance(md_col, dict) else ""
                        if not field_ref:
                            continue

                        # Resolve object_api_name from the field reference format:
                        # 1. "Object$FieldName" → split on $
                        # 2. "Object.FieldName" → split on . (e.g. Lead.CurrentGenerators__c)
                        # 3. Bare name (e.g. CITY) → use col_to_obj from report type categories
                        if "$" in field_ref:
                            obj_part, field_part = field_ref.split("$", 1)
                        elif "." in field_ref:
                            obj_part, field_part = field_ref.split(".", 1)
                        else:
                            obj_part = col_to_obj.get(field_ref)
                            field_part = field_ref

                        col_node = SfReportColumn(
                            name=field_part,
                            column_key=field_ref,
                            report_id=report_id,
                            org_key=self.org_key,
                            data_type=None,
                            object_api_name=obj_part,
                        )
                        # Try to resolve to an SfField node
                        resolved_field = self._resolve_column_to_field(
                            col_node, field_ref, col_to_obj, mdapi_col_to_obj
                        )
                        self.storage.upsert_node(col_node)
                        self.storage.create_edge(report_node, col_node, SfReportHasColumn())
                        created_col_keys.add(field_ref)
                        if resolved_field:
                            self.storage.create_edge(
                                col_node,
                                resolved_field[0],
                                resolved_field[1],
                            )
                else:
                    # Normal path: REST API provided detailColumns
                    for col_key in columns_meta:
                        col_info = detail_column_info.get(col_key, {})

                        # Determine object_api_name from col_to_obj mapping or column key
                        resolved_object = col_to_obj.get(col_key)
                        if resolved_object is None and "." in col_key:
                            # Extract object from dotted column key (e.g., "Account.Name")
                            resolved_object = col_key.split(".", 1)[0]

                        col_node = SfReportColumn(
                            name=col_info.get("label", col_key),
                            column_key=col_key,
                            report_id=report_id,
                            org_key=self.org_key,
                            data_type=col_info.get("dataType"),
                            object_api_name=resolved_object,
                        )
                        # Try to resolve column to field for linking
                        resolved_field = self._resolve_column_to_field(
                            col_node, col_key, col_to_obj, mdapi_col_to_obj
                        )
                        self.storage.upsert_node(col_node)
                        self.storage.create_edge(report_node, col_node, SfReportHasColumn())
                        created_col_keys.add(col_key)
                        if resolved_field:
                            self.storage.create_edge(
                                col_node,
                                resolved_field[0],  # field_node
                                resolved_field[1],  # edge with resolution/confidence
                            )

                # Create auxiliary SfReportColumn nodes for fields referenced
                # by groupings, filters, and buckets but not in detailColumns.
                if metadata_full:
                    aux_refs = self._extract_auxiliary_field_refs(metadata_full)
                    for aux_ref in aux_refs:
                        if aux_ref in created_col_keys:
                            continue
                        # Resolve object from col_to_obj mapping
                        resolved_object = col_to_obj.get(aux_ref)
                        if resolved_object is None and "." in aux_ref:
                            resolved_object = aux_ref.split(".", 1)[0]

                        aux_col = SfReportColumn(
                            name=aux_ref,
                            column_key=aux_ref,
                            report_id=report_id,
                            org_key=self.org_key,
                            data_type=None,
                            object_api_name=resolved_object,
                        )
                        resolved_field = self._resolve_column_to_field(
                            aux_col, aux_ref, col_to_obj, mdapi_col_to_obj
                        )
                        self.storage.upsert_node(aux_col)
                        self.storage.create_edge(
                            report_node, aux_col, SfReportHasColumn()
                        )
                        created_col_keys.add(aux_ref)
                        if resolved_field:
                            self.storage.create_edge(
                                aux_col,
                                resolved_field[0],
                                resolved_field[1],
                            )
                        logger.debug(
                            "Phase 3: Created auxiliary SfReportColumn %s for report %s",
                            aux_ref, report_node.name,
                        )

                # Create auxiliary SfReportColumn nodes for FK fields involved
                # in cross-object joins (e.g. AccountId for Opportunity→Account).
                # This makes the implicit join key explicit in the graph so the
                # IR transformer can stitch ReportIRJoin→SfReportColumn edges.
                report_objects = list(dict.fromkeys(
                    v for v in col_to_obj.values() if v
                ))
                if len(report_objects) > 1:
                    fk_rows = self.storage.execute_raw_query(
                        """
                        MATCH (f:SfField)-[:SF_REFERENCES]->(o:SfObject)
                        WHERE f.object_api_name IN $objects
                          AND o.api_name IN $objects
                          AND f.org_key = $org_key
                        RETURN f.object_api_name AS from_obj,
                               f.field_api_name AS field,
                               o.api_name AS to_obj
                        """,
                        {"objects": report_objects, "org_key": self.org_key},
                    ).rows
                    for fk_row in fk_rows:
                        fk_field = fk_row.get("field", "")
                        fk_obj = fk_row.get("from_obj", "")
                        if not fk_field or fk_field in created_col_keys:
                            continue
                        fk_col = SfReportColumn(
                            name=fk_field,
                            column_key=fk_field,
                            report_id=report_id,
                            org_key=self.org_key,
                            data_type=None,
                            object_api_name=fk_obj,
                        )
                        resolved_field = self._resolve_column_to_field(
                            fk_col, fk_field, col_to_obj, mdapi_col_to_obj
                        )
                        self.storage.upsert_node(fk_col)
                        self.storage.create_edge(
                            report_node, fk_col, SfReportHasColumn()
                        )
                        created_col_keys.add(fk_field)
                        if resolved_field:
                            self.storage.create_edge(
                                fk_col,
                                resolved_field[0],
                                resolved_field[1],
                            )
                        logger.debug(
                            "Phase 3: Created FK auxiliary SfReportColumn %s for report %s",
                            fk_field, report_node.name,
                        )

        await asyncio.gather(
            *[describe_one_report(rid, rnode) for rid, rnode in report_items],
            return_exceptions=True,
        )

        # Log change detection summary and expose for CLI reporting
        changes = detect_report_changes(current_hashes, stored_hashes)
        self.report_changes = changes
        logger.info(
            "Phase 3: %d reports (%d added, %d modified, %d unchanged)",
            len(self._report_nodes),
            len(changes.added),
            len(changes.modified),
            len(changes.unchanged),
        )

    def _normalize_field_name(self, name: str) -> str:
        """Normalize field name for comparison.

        Handles Salesforce field name variations:
        - CLOSE_DATE -> closedate
        - CloseDate -> closedate
        - Close_Date -> closedate
        """
        return name.lower().replace("_", "")

    @staticmethod
    def _report_type_to_object(report_type: str) -> str | None:
        """Derive the primary SObject API name from the MDAPI reportType value.

        Common patterns:
        - "Opportunity" -> "Opportunity" (exact SObject)
        - "AccountList" -> "Account" (strip ``List`` suffix)
        - "OpportunityProduct" -> "OpportunityLineItem" (special case)

        Returns None when the mapping is ambiguous or unknown.
        """
        _SPECIAL: dict[str, str] = {
            "OpportunityProduct": "OpportunityLineItem",
        }
        if report_type in _SPECIAL:
            return _SPECIAL[report_type]
        if report_type.endswith("List"):
            return report_type[: -len("List")]
        return report_type

    def _validate_object_name(self, obj_name: str) -> bool:
        """Check whether *obj_name* matches any SObject in ``_field_nodes``."""
        normalized = self._normalize_field_name(obj_name)
        return any(
            self._normalize_field_name(obj) == normalized
            for obj, _ in self._field_nodes
        )

    def _resolve_primary_object(
        self,
        report_type: str,
        rt_desc: dict[str, Any] | None,
    ) -> str | None:
        """Resolve the primary SObject for a report type.

        Three-tier fallback:

        1. **Static heuristic** — ``_report_type_to_object()`` + validate
           against ``_field_nodes`` (free, no API call).
        2. **REST ``objects[0].apiName``** — from the already-cached
           ``describe_report_type()`` response (free).
        3. **Metadata API ``ReportType.baseObject``** — new call, only for
           custom types where tiers 1-2 fail.

        Args:
            report_type: Report type API name (e.g. ``"Opportunity"``,
                ``"My_Custom__c"``).
            rt_desc: Cached ``describe_report_type()`` response (may be None).

        Returns:
            SObject API name or None.
        """
        # Tier 1: static heuristic
        candidate = self._report_type_to_object(report_type)
        if candidate and self._validate_object_name(candidate):
            return candidate

        # Tier 2: REST objects[0].apiName from cached describe_report_type
        if rt_desc is not None:
            rt_objects = rt_desc.get("reportTypeMetadata", {}).get("objects", [])
            if rt_objects:
                api_name = rt_objects[0].get("apiName", "")
                if api_name and self._validate_object_name(api_name):
                    return api_name

        # Tier 3: Metadata API ReportType.baseObject
        try:
            rt_meta = self.client.read_reporttype_metadata(report_type)
            if rt_meta:
                base_obj = rt_meta.get("baseObject")
                if base_obj and self._validate_object_name(base_obj):
                    return base_obj
        except Exception:
            logger.debug(
                "Phase 3: Metadata API ReportType lookup failed for %s",
                report_type,
            )

        return None

    def _build_mdapi_col_to_obj(self, metadata_full: dict[str, Any], primary_obj: str | None = None) -> dict[str, str]:
        """Build field-to-object mapping from Metadata API column + reportType data.

        Uses two sources of object provenance:
        1. Qualified column refs: ``Object$FieldName`` or ``Object.FieldName``
        2. Bare column names (``AMOUNT``): assigned to the primary object
           derived from ``metadata_full["reportType"]``.

        Excludes collisions (same normalized field on multiple objects) to avoid
        introducing wrong mappings — existing tiers handle those.

        Args:
            metadata_full: Full Metadata API response for the report.
            primary_obj: Optional pre-resolved primary SObject name.  When
                provided, skips internal ``reportType`` derivation.
        """
        columns = metadata_full.get("columns")
        if isinstance(columns, dict):
            columns = [columns]
        elif not isinstance(columns, list):
            return {}

        # Use caller-provided primary object, or derive from reportType
        if primary_obj is None:
            report_type = metadata_full.get("reportType") or ""
            primary_obj = self._report_type_to_object(report_type) if report_type else None
            # Validate: primary object must exist in the field index
            if primary_obj and not self._validate_object_name(primary_obj):
                primary_obj = None

        field_to_objects: dict[str, set[str]] = {}
        for md_col in columns:
            field_ref = md_col.get("field", "") if isinstance(md_col, dict) else ""
            if not field_ref:
                continue
            if "$" in field_ref:
                obj_part, field_part = field_ref.split("$", 1)
            elif "." in field_ref:
                obj_part, field_part = field_ref.split(".", 1)
            elif primary_obj:
                obj_part, field_part = primary_obj, field_ref
            else:
                continue  # bare name and no primary object — skip
            if not obj_part or not field_part:
                continue
            normalized = self._normalize_field_name(field_part)
            field_to_objects.setdefault(normalized, set()).add(obj_part)

        return {nf: next(iter(objs)) for nf, objs in field_to_objects.items() if len(objs) == 1}

    def _resolve_column_to_field(
        self,
        col_node: SfReportColumn,
        col_key: str,
        col_to_obj: Optional[dict[str, str]] = None,
        mdapi_col_to_obj: Optional[dict[str, str]] = None,
    ) -> Optional[tuple[SfField, SfReportColumnUsesField]]:
        """Attempt to resolve a report column key to an SfField node.

        Column keys in Salesforce reports typically follow the pattern
        ``OBJECT.FIELD_NAME`` (e.g. ``ACCOUNT.NAME``) or just ``FIELD_NAME``
        (e.g. ``AMOUNT``, ``CLOSE_DATE``).

        Uses col_to_obj mapping from report type metadata to disambiguate
        columns without object prefixes.

        Updates col_node.data_type in-place if resolved.

        Args:
            col_node: The column node to update.
            col_key: Column key like ``ACCOUNT.NAME`` or ``AMOUNT``.
            col_to_obj: Optional mapping from column key to object API name,
                derived from reportTypeMetadata.categories.
            mdapi_col_to_obj: Optional mapping from normalized field name to
                object API name, derived from Metadata API Object$FieldName refs.

        Returns:
            Tuple of (field_node, edge) if resolved, None otherwise.
            The caller is responsible for upserting col_node and creating the edge.
        """
        col_to_obj = col_to_obj or {}
        parts = col_key.split(".")

        if len(parts) == 2:
            obj_api, field_api = parts
            # Try exact match first (case-sensitive)
            field_node = self._field_nodes.get((obj_api, field_api))
            if field_node:
                col_node.data_type = field_node.data_type
                return (field_node, SfReportColumnUsesField(resolution="exact", confidence=1.0))

            # Try normalized match for Object.Field pattern (case-insensitive)
            normalized_obj = self._normalize_field_name(obj_api)
            normalized_field = self._normalize_field_name(field_api)
            for (stored_obj, stored_field), f_node in self._field_nodes.items():
                if (self._normalize_field_name(stored_obj) == normalized_obj and
                    self._normalize_field_name(stored_field) == normalized_field):
                    col_node.data_type = f_node.data_type
                    return (f_node, SfReportColumnUsesField(resolution="exact_normalized", confidence=0.95))

        # Tier 3: MDAPI-mapped — use Object$FieldName from Metadata API
        if mdapi_col_to_obj:
            field_api_candidate = parts[-1] if parts else col_key
            normalized_field = self._normalize_field_name(field_api_candidate)
            mdapi_obj = mdapi_col_to_obj.get(normalized_field)
            if mdapi_obj:
                normalized_obj = self._normalize_field_name(mdapi_obj)
                for (stored_obj, stored_field), f_node in self._field_nodes.items():
                    if (self._normalize_field_name(stored_obj) == normalized_obj
                            and self._normalize_field_name(stored_field) == normalized_field):
                        col_node.data_type = f_node.data_type
                        return (f_node, SfReportColumnUsesField(
                            resolution="mdapi_mapped", confidence=0.95,
                        ))

        # Use report type metadata to find the object for this column
        mapped_obj = col_to_obj.get(col_key)
        if mapped_obj:
            field_api_candidate = parts[-1] if parts else col_key
            normalized_field = self._normalize_field_name(field_api_candidate)
            normalized_obj = self._normalize_field_name(mapped_obj)

            # First try exact object match with normalized field
            for (stored_obj, stored_field), f_node in self._field_nodes.items():
                if (self._normalize_field_name(stored_obj) == normalized_obj and
                    self._normalize_field_name(stored_field) == normalized_field):
                    col_node.data_type = f_node.data_type
                    return (f_node, SfReportColumnUsesField(resolution="category_mapped", confidence=0.9))

            # Handle combined key format: OBJECT_FIELD (e.g., OPPORTUNITY_NAME -> Opportunity.Name)
            # Try to extract field by removing object prefix from column key
            if normalized_field.startswith(normalized_obj):
                extracted_field = normalized_field[len(normalized_obj):]
                if extracted_field:
                    for (stored_obj, stored_field), f_node in self._field_nodes.items():
                        if (self._normalize_field_name(stored_obj) == normalized_obj and
                            self._normalize_field_name(stored_field) == extracted_field):
                            col_node.data_type = f_node.data_type
                            return (f_node, SfReportColumnUsesField(resolution="category_extracted", confidence=0.85))

        # Heuristic: search across all objects for field name with normalization
        field_api_candidate = parts[-1] if parts else col_key
        normalized_candidate = self._normalize_field_name(field_api_candidate)
        candidates: list[SfField] = []
        for (_, f_api), f_node in self._field_nodes.items():
            if self._normalize_field_name(f_api) == normalized_candidate:
                candidates.append(f_node)

        if len(candidates) == 1:
            col_node.data_type = candidates[0].data_type
            return (candidates[0], SfReportColumnUsesField(resolution="heuristic", confidence=0.8))
        elif len(candidates) > 1:
            # Prefer mapped_obj from report-type categories; fall back to the
            # object_api_name already set on the column node (e.g. from FK graph
            # queries) so FK auxiliary columns resolve to the correct SfField.
            preferred_obj = mapped_obj or col_node.object_api_name
            if preferred_obj:
                for candidate in candidates:
                    if self._normalize_field_name(candidate.object_api_name) == self._normalize_field_name(preferred_obj):
                        col_node.data_type = candidate.data_type
                        return (candidate, SfReportColumnUsesField(resolution="heuristic_mapped", confidence=0.75))
            # Ambiguous — pick first but mark low confidence
            col_node.data_type = candidates[0].data_type
            return (candidates[0], SfReportColumnUsesField(resolution="heuristic", confidence=0.5))

        # Unresolvable — node stays without USES_FIELD edge
        return None

    @staticmethod
    def _is_synthetic_ref(ref: str) -> bool:
        """Return True for computed/derived field refs with no SObject backing."""
        return (
            ref.startswith("BucketField_")
            or ref.startswith("FORMULA")
            or ref.startswith("Age_")
        )

    @staticmethod
    def _ensure_list(value: Any) -> list:
        """Normalize Metadata API values that may be a single dict or a list."""
        if value is None:
            return []
        if isinstance(value, list):
            return value
        return [value]

    def _extract_auxiliary_field_refs(
        self, metadata_full: dict[str, Any]
    ) -> list[str]:
        """Extract field refs from groupings, filters, and buckets.

        Returns deduplicated refs in encounter order, excluding synthetic
        refs (BucketField_*, FORMULA*, Age_*).
        """
        seen: set[str] = set()
        refs: list[str] = []

        def _add(ref: str) -> None:
            if ref and ref not in seen and not self._is_synthetic_ref(ref):
                seen.add(ref)
                refs.append(ref)

        # Groupings
        for g in self._ensure_list(metadata_full.get("groupingsDown")):
            if isinstance(g, dict):
                _add(g.get("field") or g.get("name") or "")
        for g in self._ensure_list(metadata_full.get("groupingsAcross")):
            if isinstance(g, dict):
                _add(g.get("field") or g.get("name") or "")

        # Filters
        filter_obj = metadata_full.get("filter")
        if isinstance(filter_obj, dict):
            criteria = self._ensure_list(filter_obj.get("criteriaItems"))
        else:
            criteria = self._ensure_list(filter_obj)
        for f in criteria:
            if isinstance(f, dict):
                _add(f.get("column") or "")

        # Buckets
        for b in self._ensure_list(
            metadata_full.get("buckets") or metadata_full.get("bucketColumns")
        ):
            if isinstance(b, dict):
                _add(b.get("sourceColumnName") or "")

        return refs

    # ------------------------------------------------------------------
    # Phase 4: Dashboards
    # ------------------------------------------------------------------

    async def _phase4_dashboards(self) -> None:
        assert self._org_node is not None
        try:
            dashboards = self.client.list_dashboards()
        except Exception:
            logger.warning("Failed to list dashboards — skipping phase 4")
            return

        now = datetime.now(timezone.utc).isoformat()
        total = len(dashboards)
        logger.info("Phase 4: Fetched %d dashboards, describing each...", total)

        # Create dashboard nodes first
        dash_items: list[tuple[str, SfDashboard]] = []
        for dash in dashboards:
            dash_id = dash.get("id") or dash.get("Id") or ""
            if not dash_id:
                continue

            dash_node = SfDashboard(
                name=dash.get("name", dash_id),
                dashboard_id=dash_id,
                org_key=self.org_key,
                folder_name=dash.get("folderName") or dash.get("folderId"),
                description=dash.get("description"),
                fetched_at=now,
            )
            self.storage.upsert_node(dash_node)
            self.storage.create_edge(self._org_node, dash_node, SfHasDashboard())
            dash_items.append((dash_id, dash_node))

        # Describe dashboards in parallel
        semaphore = asyncio.Semaphore(self.max_workers)
        counter = 0

        async def describe_one_dashboard(dash_id: str, dash_node: SfDashboard) -> None:
            nonlocal counter
            async with semaphore:
                try:
                    desc = await asyncio.to_thread(self.client.describe_dashboard, dash_id)
                except Exception:
                    counter += 1
                    logger.warning(
                        "Phase 4: [%d/%d] Failed to describe dashboard %s — skipping components",
                        counter, total, dash_id,
                    )
                    return

                counter += 1
                components = desc.get("components", [])
                logger.info(
                    "Phase 4: [%d/%d] %s (%d components)",
                    counter, total, dash_node.name, len(components),
                )
                self._report_progress(counter, total, f"Dashboards [{counter}/{total}] {dash_node.name}")

                for comp_idx, comp in enumerate(components):
                    comp_key = comp.get("id") or _stable_hash(
                        (comp.get("title", ""), comp.get("type", ""), str(comp_idx))
                    )
                    comp_report_id = comp.get("reportId") or comp.get("report", {}).get("id")

                    comp_node = SfDashboardComponent(
                        name=comp.get("title", comp_key),
                        component_key=comp_key,
                        dashboard_id=dash_id,
                        org_key=self.org_key,
                        component_type=comp.get("type") or comp.get("componentType"),
                        report_id=comp_report_id,
                    )
                    self.storage.upsert_node(comp_node)
                    self.storage.create_edge(dash_node, comp_node, SfDashboardHasComponent())

                    # Link to report if resolvable
                    if comp_report_id:
                        target_report = self._report_nodes.get(comp_report_id)
                        if target_report:
                            self.storage.create_edge(
                                comp_node, target_report, SfComponentUsesReport()
                            )

        await asyncio.gather(
            *[describe_one_dashboard(did, dnode) for did, dnode in dash_items],
            return_exceptions=True,
        )

        logger.info("Phase 4: Created %d SfDashboard nodes", len(dash_items))


__all__ = ["SalesforceLoader"]
