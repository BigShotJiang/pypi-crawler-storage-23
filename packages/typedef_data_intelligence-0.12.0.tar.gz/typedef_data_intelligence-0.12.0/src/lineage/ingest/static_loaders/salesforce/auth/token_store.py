"""Secure token persistence for Salesforce OAuth tokens.

Primary: OS keychain via ``keyring`` library.
Fallback: ``~/.typedef/salesforce_tokens.json`` (chmod 600).
"""
from __future__ import annotations

import json
import logging
import os
import stat
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class StoredTokens:
    """Token data persisted between sessions."""

    access_token: str = field(repr=False)
    instance_url: str
    refresh_token: Optional[str] = field(default=None, repr=False)
    token_type: str = "Bearer"
    issued_at: Optional[str] = None
    org_key: str = "default"


_FILE_STORE_DIR = Path.home() / ".typedef"
_FILE_STORE_PATH = _FILE_STORE_DIR / "salesforce_tokens.json"


class TokenStore:
    """Manages secure storage and retrieval of Salesforce OAuth tokens.

    Attempts keyring first; falls back to a JSON file with restricted
    permissions if keyring is unavailable.
    """

    SERVICE_NAME = "typedef-lineage-salesforce"

    def __init__(self, org_key: str = "default") -> None:
        """Initialise token store for the given org key."""
        self.org_key = org_key
        self._keyring_available: Optional[bool] = None

    def _has_keyring(self) -> bool:
        if self._keyring_available is None:
            try:
                import keyring  # noqa: F401
                from keyring.errors import NoKeyringError

                # Probe — some systems have keyring installed but no backend
                try:
                    keyring.get_password(self.SERVICE_NAME, "__probe__")
                    self._keyring_available = True
                except NoKeyringError:
                    self._keyring_available = False
                    logger.info("No keyring backend available — using file store")
                except Exception:
                    self._keyring_available = False
                    logger.info("Keyring probe failed — using file store")
            except ImportError:
                self._keyring_available = False
                logger.info("keyring not installed — using file store")
        return self._keyring_available

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def save(self, tokens: StoredTokens) -> None:
        """Persist tokens (keyring or file)."""
        token_data = asdict(tokens)
        token_data["org_key"] = self.org_key
        data = json.dumps(token_data)
        if self._has_keyring():
            self._save_keyring(data)
        else:
            self._save_file(data)

    def load(self) -> Optional[StoredTokens]:
        """Load persisted tokens, or ``None`` if not found."""
        if self._has_keyring():
            raw = self._load_keyring()
        else:
            raw = self._load_file()
        if raw is None:
            return None
        try:
            return StoredTokens(**json.loads(raw))
        except (json.JSONDecodeError, TypeError):
            logger.warning("Corrupt token data — clearing store")
            self.clear()
            return None

    def clear(self) -> None:
        """Remove persisted tokens."""
        if self._has_keyring():
            self._clear_keyring()
        self._clear_file()

    # ------------------------------------------------------------------
    # Keyring backend
    # ------------------------------------------------------------------

    def _save_keyring(self, data: str) -> None:
        import keyring

        keyring.set_password(self.SERVICE_NAME, self.org_key, data)

    def _load_keyring(self) -> Optional[str]:
        import keyring

        return keyring.get_password(self.SERVICE_NAME, self.org_key)

    def _clear_keyring(self) -> None:
        import keyring

        try:
            keyring.delete_password(self.SERVICE_NAME, self.org_key)
        except Exception as exc:
            logger.debug(
                "Failed to clear Salesforce token from keyring for org '%s': %s",
                self.org_key,
                exc,
            )

    # ------------------------------------------------------------------
    # File backend
    # ------------------------------------------------------------------

    def _save_file(self, data: str) -> None:
        _FILE_STORE_DIR.mkdir(parents=True, exist_ok=True)

        # Read existing multi-org data
        all_orgs = self._read_file_store()
        all_orgs[self.org_key] = data

        raw = json.dumps(all_orgs)
        _FILE_STORE_PATH.write_text(raw, encoding="utf-8")
        os.chmod(_FILE_STORE_PATH, stat.S_IRUSR | stat.S_IWUSR)

    def _load_file(self) -> Optional[str]:
        all_orgs = self._read_file_store()
        return all_orgs.get(self.org_key)

    def _clear_file(self) -> None:
        all_orgs = self._read_file_store()
        all_orgs.pop(self.org_key, None)
        if all_orgs:
            _FILE_STORE_PATH.write_text(json.dumps(all_orgs), encoding="utf-8")
            os.chmod(_FILE_STORE_PATH, stat.S_IRUSR | stat.S_IWUSR)
        elif _FILE_STORE_PATH.exists():
            _FILE_STORE_PATH.unlink()

    def _read_file_store(self) -> dict[str, str]:
        if not _FILE_STORE_PATH.exists():
            return {}
        try:
            return json.loads(_FILE_STORE_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}


__all__ = ["StoredTokens", "TokenStore"]
