"""Salesforce authentication strategies.

Exports the ``SalesforceAuth`` protocol plus concrete implementations.
"""
from lineage.ingest.static_loaders.salesforce.auth.password import PasswordAuth
from lineage.ingest.static_loaders.salesforce.auth.protocol import (
    SalesforceAuth,
    SalesforceCredentials,
)

__all__ = [
    "PasswordAuth",
    "SalesforceAuth",
    "SalesforceCredentials",
]
