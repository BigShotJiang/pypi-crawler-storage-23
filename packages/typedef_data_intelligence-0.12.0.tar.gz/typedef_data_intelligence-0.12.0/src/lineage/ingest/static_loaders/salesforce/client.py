"""Salesforce REST API metadata client.

Wraps ``simple_salesforce.Salesforce`` to fetch org, SObject, field,
report, and dashboard metadata for graph ingestion.
"""
from __future__ import annotations

import functools
import logging
import threading
from dataclasses import dataclass, field
from typing import Any, Optional

logger = logging.getLogger(__name__)


def _with_retry(method: Any) -> Any:
    """Decorator that retries a method once on 401/expired-session errors.

    Catches ``SalesforceExpiredSession`` (from ``simple_salesforce``) and
    generic 401-like errors, calls ``_reconnect()``, then retries once.
    """

    @functools.wraps(method)
    def wrapper(self: SalesforceMetadataClient, *args: Any, **kwargs: Any) -> Any:
        try:
            return method(self, *args, **kwargs)
        except Exception as exc:
            # Check for expired session / 401
            exc_name = type(exc).__name__
            if exc_name == "SalesforceExpiredSession" or "INVALID_SESSION_ID" in str(exc):
                logger.info("Session expired — attempting reconnect")
                self._reconnect()
                return method(self, *args, **kwargs)
            raise

    return wrapper


@dataclass
class SalesforceMetadataClient:
    """Thin wrapper around ``simple_salesforce`` for metadata fetching.

    Supports two authentication paths:

    1. **Legacy (backward-compatible)**: Pass ``instance_url``, ``username``,
       ``password``, ``security_token`` directly. Internally wrapped in
       ``PasswordAuth``.
    2. **OAuth**: Pass an ``auth`` strategy implementing ``SalesforceAuth``.
       The client uses ``authenticate()`` / ``refresh_if_needed()`` and
       connects via ``Salesforce(instance_url=..., session_id=access_token)``.

    Args:
        instance_url: Salesforce instance URL (legacy path).
        username: Salesforce username (legacy path).
        password: Salesforce password (legacy path).
        security_token: Salesforce security token (legacy path).
        auth: Authentication strategy (OAuth path).
        api_version: REST API version (default ``"61.0"``).
    """

    instance_url: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = field(default=None, repr=False)
    security_token: Optional[str] = field(default=None, repr=False)
    auth: Any = None  # SalesforceAuth — typed as Any to avoid import at module level
    api_version: str = "61.0"
    _sf: Any = field(default=None, init=False, repr=False)
    _lock: threading.Lock = field(default_factory=threading.Lock, init=False, repr=False)

    def __post_init__(self) -> None:
        """Create PasswordAuth from legacy kwargs if no explicit auth provided."""
        if self.auth is None and all(
            v is not None
            for v in (self.instance_url, self.username, self.password, self.security_token)
        ):
            from lineage.ingest.static_loaders.salesforce.auth.password import (
                PasswordAuth,
            )

            self.auth = PasswordAuth(
                instance_url=self.instance_url,
                username=self.username,
                password=self.password,
                security_token=self.security_token,
            )

    def _connect(self) -> Any:
        """Lazily create and cache a ``simple_salesforce.Salesforce`` session.

        Thread-safe: guarded by ``self._lock`` so concurrent
        ``asyncio.to_thread`` workers cannot race on session creation.
        """
        with self._lock:
            if self._sf is None:
                try:
                    from simple_salesforce import (
                        Salesforce,  # type: ignore[import-untyped]
                    )
                except ImportError as exc:
                    raise ImportError(
                        "simple-salesforce is required for Salesforce ingestion. "
                        "Install it with: pip install simple-salesforce"
                    ) from exc

                from lineage.ingest.static_loaders.salesforce.auth.password import (
                    PasswordAuth,
                )

                if isinstance(self.auth, PasswordAuth):
                    # Legacy path: let simple_salesforce handle SOAP login
                    self._sf = Salesforce(
                        instance_url=self.auth.instance_url,
                        username=self.auth.username,
                        password=self.auth.password,
                        security_token=self.auth.security_token,
                        version=self.api_version,
                    )
                elif self.auth is not None:
                    # OAuth path: authenticate and use session_id
                    creds = self.auth.authenticate()
                    self._sf = Salesforce(
                        instance_url=creds.instance_url,
                        session_id=creds.access_token,
                        version=self.api_version,
                    )
                else:
                    raise ValueError(
                        "No authentication provided. Pass either legacy credentials "
                        "(instance_url, username, password, security_token) or an "
                        "auth strategy."
                    )
            return self._sf

    def _reconnect(self) -> None:
        """Re-authenticate and rebuild the Salesforce session.

        Called on 401 / expired session errors.
        Thread-safe: guarded by ``self._lock``.
        """
        with self._lock:
            from lineage.ingest.static_loaders.salesforce.auth.password import (
                PasswordAuth,
            )

            if isinstance(self.auth, PasswordAuth):
                # Reset and let _connect re-create via SOAP
                self._sf = None
            elif self.auth is not None:
                try:
                    from simple_salesforce import (
                        Salesforce,  # type: ignore[import-untyped]
                    )
                except ImportError as exc:
                    raise ImportError(
                        "simple-salesforce is required for Salesforce ingestion."
                    ) from exc

                creds = self.auth.refresh_if_needed()
                self._sf = Salesforce(
                    instance_url=creds.instance_url,
                    session_id=creds.access_token,
                    version=self.api_version,
                )
                return

        # For password auth, _connect() acquires the lock itself
        if self._sf is None:
            self._connect()

    # ------------------------------------------------------------------
    # Org info
    # ------------------------------------------------------------------

    @_with_retry
    def get_org_info(self) -> dict[str, Any]:
        """Return basic org metadata (org ID, instance URL, sandbox flag).

        Uses SOQL on the ``Organization`` object.

        Returns:
            Dict with keys ``org_id``, ``instance_url``, ``is_sandbox``,
            ``name``, ``org_type``.
        """
        sf = self._connect()
        result = sf.query(
            "SELECT Id, Name, InstanceName, IsSandbox, OrganizationType "
            "FROM Organization LIMIT 1"
        )
        record = result["records"][0]
        instance_url = self.instance_url or getattr(sf, "sf_instance", "")
        return {
            "org_id": record["Id"],
            "name": record["Name"],
            "instance_url": instance_url,
            "is_sandbox": record.get("IsSandbox", False),
            "org_type": record.get("OrganizationType", "Unknown"),
        }

    # ------------------------------------------------------------------
    # SObjects & Fields
    # ------------------------------------------------------------------

    @_with_retry
    def list_sobjects(self) -> list[dict[str, Any]]:
        """Return list of all SObject descriptors (lightweight).

        Returns:
            List of dicts, each with keys like ``name``, ``keyPrefix``,
            ``custom``, ``queryable``, ``label``.
        """
        sf = self._connect()
        desc = sf.describe()
        return desc["sobjects"]

    @_with_retry
    def describe_sobject(self, api_name: str) -> dict[str, Any]:
        """Describe a single SObject including all fields.

        Args:
            api_name: API name of the SObject (e.g. ``Account``).

        Returns:
            Full describe result including ``fields`` list.
        """
        sf = self._connect()
        return getattr(sf, api_name).describe()

    # ------------------------------------------------------------------
    # Reports
    # ------------------------------------------------------------------

    @_with_retry
    def list_reports(self) -> list[dict[str, Any]]:
        """List all reports accessible to the connected user.

        Returns:
            List of report metadata dicts.
        """
        sf = self._connect()
        url = f"{sf.base_url}analytics/reports"
        response = sf._call_salesforce("GET", url)
        data = response.json()
        return data.get("reports", data) if isinstance(data, dict) else data

    @_with_retry
    def describe_report(self, report_id: str) -> dict[str, Any]:
        """Describe a single report (columns, filters, type).

        Args:
            report_id: 18-character Salesforce report ID.

        Returns:
            Report describe result.
        """
        sf = self._connect()
        url = f"{sf.base_url}analytics/reports/{report_id}/describe"
        response = sf._call_salesforce("GET", url)
        return response.json()

    @_with_retry
    def describe_report_type(self, report_type: str) -> dict[str, Any]:
        """Describe a report type to get its available objects and columns.

        Args:
            report_type: Report type API name (e.g. ``Opportunity``,
                ``AccountList``, ``OpportunityProduct``).

        Returns:
            Report type describe result including ``reportTypeMetadata.objects``.
        """
        sf = self._connect()
        url = f"https://{sf.sf_instance}/services/data/v{sf.sf_version}/analytics/report-types/{report_type}"
        response = sf._call_salesforce("GET", url)
        return response.json()

    @_with_retry
    def read_report_metadata(self, report_api_name: str) -> Optional[dict[str, Any]]:
        """Read Report metadata using Metadata API.

        Returns explicit field references in format ``Object$FieldName``
        which can be used for accurate column-to-field resolution.

        Args:
            report_api_name: Report developer name (API name, not ID).
                Format: ``FolderName/ReportName`` or just ``ReportName``.

        Returns:
            Report metadata dict with ``columns`` containing explicit field refs,
            or None if not found.
        """
        sf = self._connect()
        try:
            # Use simple_salesforce's mdapi to read Report metadata
            mdapi = sf.mdapi
            result = mdapi.Report.read(report_api_name)
            if result:
                return self._parse_report_metadata(result)
        except Exception as e:
            logger.debug("Could not read Report metadata for %s: %s", report_api_name, e)
        return None

    def _parse_report_metadata(self, md_result: Any) -> dict[str, Any]:
        """Parse Metadata API Report result into a dict.

        Extracts columns with explicit Object$Field references.

        Args:
            md_result: Result from mdapi.Report.read()

        Returns:
            Dict with columns containing field references.
        """
        columns = []
        # Handle both single result and list
        if hasattr(md_result, "columns"):
            for col in md_result.columns or []:
                if hasattr(col, "field"):
                    field_ref = col.field  # Format: Object$FieldName
                    if "$" in field_ref:
                        obj, field = field_ref.split("$", 1)
                        columns.append({
                            "field_ref": field_ref,
                            "object": obj,
                            "field": field,
                        })
                    else:
                        columns.append({"field_ref": field_ref, "object": None, "field": field_ref})

        return {
            "fullName": getattr(md_result, "fullName", None),
            "name": getattr(md_result, "name", None),
            "reportType": getattr(md_result, "reportType", None),
            "columns": columns,
        }

    def _metadata_object_to_dict(self, obj: Any) -> Any:
        """Recursively convert a Metadata API object to a plain dict.

        The Metadata API returns Zeep CompoundValue objects with special structure.
        This converts them to plain dicts/lists for JSON serialization.

        Args:
            obj: Metadata API object (or nested value).

        Returns:
            Plain Python dict/list/scalar suitable for JSON serialization.
        """
        if obj is None:
            return None
        if isinstance(obj, (str, int, float, bool)):
            return obj
        if isinstance(obj, (list, tuple)):
            return [self._metadata_object_to_dict(item) for item in obj]
        if isinstance(obj, dict):
            return {k: self._metadata_object_to_dict(v) for k, v in obj.items()}

        # Handle Zeep CompoundValue objects (used by simple_salesforce mdapi)
        # These have a special __values__ dict that contains the actual data
        if hasattr(obj, "__values__"):
            return {
                k: self._metadata_object_to_dict(v)
                for k, v in obj.__values__.items()
            }

        # Handle simple_salesforce's ordered dict-like objects
        if hasattr(obj, "__iter__") and hasattr(obj, "keys"):
            return {k: self._metadata_object_to_dict(obj[k]) for k in obj.keys()}

        # Handle objects with __dict__ (but filter out private attrs)
        if hasattr(obj, "__dict__"):
            result = {}
            for k, v in obj.__dict__.items():
                if not k.startswith("_"):
                    result[k] = self._metadata_object_to_dict(v)
            if result:
                return result

        # Fallback: convert to string
        return str(obj)

    @_with_retry
    def read_report_metadata_full(self, report_api_name: str) -> Optional[dict[str, Any]]:
        """Read FULL Report metadata using Metadata API.

        Returns the complete Metadata API response including:
        - columns
        - buckets (bucketColumns)
        - aggregates (summary formulas)
        - customDetailFormulas (row formulas)
        - crossFilters
        - colorRanges (conditional highlights)
        - filters
        - groupings

        Args:
            report_api_name: Report developer name (API name, not ID).
                Format: ``FolderDeveloperName/ReportDeveloperName``.

        Returns:
            Full report metadata dict, or None if not found.
        """
        sf = self._connect()
        try:
            logger.debug("Metadata API: Reading report %s", report_api_name)
            mdapi = sf.mdapi
            result = mdapi.Report.read(report_api_name)
            if result:
                converted = self._metadata_object_to_dict(result)
                logger.debug(
                    "Metadata API: Got %d keys for %s",
                    len(converted) if isinstance(converted, dict) else 0,
                    report_api_name,
                )
                return converted
            else:
                logger.warning(
                    "Metadata API: Returned None/empty for %s",
                    report_api_name,
                )
        except Exception as e:
            logger.warning(
                "Metadata API: Exception for %s: %s (type: %s)",
                report_api_name, e, type(e).__name__,
            )
        return None

    @_with_retry
    def get_report_developer_names(self) -> dict[str, str]:
        """Get mapping of report IDs to their Metadata API fullName.

        Uses SOQL to query the Report object for Id, DeveloperName, FolderName
        and maps FolderName to the folder's DeveloperName via the Folder table.
        The Metadata API requires: FolderDeveloperName/ReportDeveloperName.

        Note: Report.OwnerId is the owning User, NOT the folder. Report.FolderName
        is the display name of the folder (read-only). We must map display names
        to developer names via the Folder table.

        Returns:
            Dict mapping report ID -> fullName (e.g., "MyFolder/MyReport").
        """
        sf = self._connect()

        # Build mapping of folder display Name -> DeveloperName
        # Also include Id -> DeveloperName for completeness
        folder_name_to_dev: dict[str, str] = {}
        try:
            folder_query = """
                SELECT Id, Name, DeveloperName
                FROM Folder
                WHERE Type = 'Report' AND DeveloperName != null
            """
            folder_result = sf.query_all(folder_query)
            for rec in folder_result.get("records", []):
                folder_name = rec.get("Name", "")
                folder_dev = rec.get("DeveloperName", "")
                if folder_name and folder_dev:
                    folder_name_to_dev[folder_name] = folder_dev
            logger.debug("Fetched %d folder name->dev mappings", len(folder_name_to_dev))
        except Exception as e:
            logger.debug("Could not fetch folder names: %s", e)

        # Query report developer names with FolderName
        query = """
            SELECT Id, DeveloperName, FolderName
            FROM Report
            WHERE IsDeleted = false
        """
        try:
            result = sf.query_all(query)
            mapping: dict[str, str] = {}
            for record in result.get("records", []):
                report_id = record.get("Id", "")
                dev_name = record.get("DeveloperName", "")
                folder_name = record.get("FolderName", "")

                if dev_name:
                    # Lookup folder developer name from display name
                    folder_dev = folder_name_to_dev.get(folder_name, "")

                    # Metadata API uses FolderDeveloperName/ReportDeveloperName format
                    if folder_dev:
                        full_name = f"{folder_dev}/{dev_name}"
                    elif folder_name in ("Unfiled Public Reports", "Public Reports", ""):
                        # Reports in the default public folder use "unfiled$public"
                        full_name = f"unfiled$public/{dev_name}"
                    else:
                        # Unknown folder - try unfiled$public as fallback
                        logger.debug(
                            "Unknown folder '%s' for report %s, using unfiled$public",
                            folder_name, dev_name
                        )
                        full_name = f"unfiled$public/{dev_name}"
                    mapping[report_id] = full_name

            logger.info("Fetched developer names for %d reports", len(mapping))
            return mapping
        except Exception as e:
            logger.warning("Could not fetch report developer names: %s", e)
            return {}

    @_with_retry
    def read_reporttype_metadata(self, report_type_name: str) -> Optional[dict[str, Any]]:
        """Read ReportType metadata using the Metadata API.

        Returns the ``baseObject`` (primary SObject) among other fields.
        Useful for custom report types where the name cannot be mapped to
        an SObject via static heuristics.

        Args:
            report_type_name: ReportType API name (e.g. ``"My_Custom__c"``).

        Returns:
            Dict with ReportType metadata including ``baseObject``,
            or None if not found.
        """
        sf = self._connect()
        try:
            result = sf.mdapi.ReportType.read(report_type_name)
            if result:
                return self._metadata_object_to_dict(result)
        except Exception as e:
            logger.debug(
                "Could not read ReportType metadata for %s: %s",
                report_type_name, e,
            )
        return None

    # ------------------------------------------------------------------
    # Dashboards
    # ------------------------------------------------------------------

    @_with_retry
    def list_dashboards(self) -> list[dict[str, Any]]:
        """List all dashboards accessible to the connected user.

        Returns:
            List of dashboard metadata dicts.
        """
        sf = self._connect()
        url = f"{sf.base_url}analytics/dashboards"
        response = sf._call_salesforce("GET", url)
        data = response.json()
        return data.get("dashboards", data) if isinstance(data, dict) else data

    @_with_retry
    def describe_dashboard(self, dashboard_id: str) -> dict[str, Any]:
        """Describe a single dashboard (components, layout).

        Args:
            dashboard_id: 18-character Salesforce dashboard ID.

        Returns:
            Dashboard describe result.
        """
        sf = self._connect()
        url = f"{sf.base_url}analytics/dashboards/{dashboard_id}"
        response = sf._call_salesforce("GET", url)
        return response.json()


__all__ = ["SalesforceMetadataClient"]
