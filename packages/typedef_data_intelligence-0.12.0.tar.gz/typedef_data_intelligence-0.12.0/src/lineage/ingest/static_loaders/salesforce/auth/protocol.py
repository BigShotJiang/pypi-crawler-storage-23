"""Salesforce authentication protocol and credentials."""
from __future__ import annotations

from typing import NamedTuple, Protocol, runtime_checkable


class SalesforceCredentials(NamedTuple):
    """Credentials returned by any auth strategy."""

    access_token: str
    instance_url: str


@runtime_checkable
class SalesforceAuth(Protocol):
    """Protocol for Salesforce authentication strategies.

    Every auth strategy must implement ``authenticate`` (initial login) and
    ``refresh_if_needed`` (called on 401 retry).
    """

    def authenticate(self) -> SalesforceCredentials:
        """Perform initial authentication and return credentials."""
        ...

    def refresh_if_needed(self) -> SalesforceCredentials:
        """Refresh credentials if expired, or re-authenticate."""
        ...


__all__ = ["SalesforceAuth", "SalesforceCredentials"]
