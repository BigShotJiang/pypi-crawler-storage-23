"""OAuth 2.0 Authorization Code + PKCE flow for Salesforce.

Interactive browser-based login for CLI usage.
"""
from __future__ import annotations

import base64
import hashlib
import logging
import os
import platform
import secrets
import webbrowser
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import quote, urlencode

import httpx

from lineage.ingest.static_loaders.salesforce.auth.protocol import (
    SalesforceCredentials,
)
from lineage.ingest.static_loaders.salesforce.auth.server import (
    start_callback_server,
    wait_for_callback,
)
from lineage.ingest.static_loaders.salesforce.auth.token_store import (
    StoredTokens,
    TokenStore,
)

logger = logging.getLogger(__name__)


def _generate_code_verifier() -> str:
    """Generate a PKCE code verifier (43-128 URL-safe characters)."""
    return secrets.token_urlsafe(64)[:128]


def _generate_code_challenge(verifier: str) -> str:
    """Generate S256 PKCE code challenge from verifier."""
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")


@dataclass
class OAuthPKCEAuth:
    """OAuth 2.0 Authorization Code + PKCE authentication.

    Args:
        client_id: Salesforce Connected App consumer key.
        login_url: Salesforce login URL (use ``https://test.salesforce.com``
            for sandboxes).
        callback_port: Local port for the OAuth callback server.
        org_key: Token store key for multi-org support.
    """

    client_id: str
    login_url: str = "https://login.salesforce.com"
    callback_port: int = 8443
    org_key: str = "default"
    _token_store: TokenStore = field(init=False, repr=False)
    _credentials: Optional[SalesforceCredentials] = field(
        default=None, init=False, repr=False
    )
    _expected_state: Optional[str] = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        """Initialise the token store for this org."""
        self._token_store = TokenStore(org_key=self.org_key)

    @property
    def redirect_uri(self) -> str:
        """Return the localhost callback URL for the PKCE flow."""
        return f"http://localhost:{self.callback_port}/callback"

    def authenticate(self) -> SalesforceCredentials:
        """Authenticate via PKCE flow.

        First tries to use a cached refresh token. If unavailable or
        expired, opens a browser for interactive login.
        """
        # Try cached refresh token first
        stored = self._token_store.load()
        if stored and stored.refresh_token:
            try:
                creds = self._refresh(stored.refresh_token)
                self._credentials = creds
                return creds
            except Exception:
                logger.info("Cached refresh token expired — starting browser login")

        # Full browser-based PKCE flow
        code_verifier = _generate_code_verifier()
        code_challenge = _generate_code_challenge(code_verifier)

        auth_url = self._build_authorize_url(code_challenge)

        # Start callback server BEFORE opening the browser so it's
        # already listening when Salesforce redirects back.
        server, _ready = start_callback_server(port=self.callback_port)

        # Try to open browser; if headless, print URL
        if not self._open_browser(auth_url):
            print(f"\nOpen this URL in your browser to log in:\n\n  {auth_url}\n")

        # Wait for callback
        auth_code, callback_state = wait_for_callback(server)

        # Validate state parameter (CSRF protection)
        if callback_state != self._expected_state:
            raise RuntimeError(
                "OAuth state mismatch — possible CSRF attack. "
                "Expected state does not match callback state."
            )

        # Exchange code for tokens
        creds = self._exchange_code(auth_code, code_verifier)
        self._credentials = creds
        return creds

    def refresh_if_needed(self) -> SalesforceCredentials:
        """Refresh credentials using stored refresh token."""
        stored = self._token_store.load()
        if stored and stored.refresh_token:
            creds = self._refresh(stored.refresh_token)
            self._credentials = creds
            return creds
        # No refresh token — must re-authenticate
        return self.authenticate()

    def _build_authorize_url(self, code_challenge: str) -> str:
        self._expected_state = secrets.token_urlsafe(32)
        params = {
            "response_type": "code",
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "state": self._expected_state,
            "scope": "refresh_token api",
        }
        return f"{self.login_url}/services/oauth2/authorize?{urlencode(params, quote_via=quote)}"

    def _exchange_code(
        self, auth_code: str, code_verifier: str
    ) -> SalesforceCredentials:
        """Exchange authorization code for access + refresh tokens."""
        data = {
            "grant_type": "authorization_code",
            "client_id": self.client_id,
            "code": auth_code,
            "redirect_uri": self.redirect_uri,
            "code_verifier": code_verifier,
        }
        response = httpx.post(
            f"{self.login_url}/services/oauth2/token",
            data=data,
            timeout=30.0,
        )
        response.raise_for_status()
        token_data = response.json()

        # Persist tokens
        self._token_store.save(
            StoredTokens(
                access_token=token_data["access_token"],
                instance_url=token_data["instance_url"],
                refresh_token=token_data.get("refresh_token"),
                token_type=token_data.get("token_type", "Bearer"),
                issued_at=token_data.get("issued_at"),
                org_key=self.org_key,
            )
        )

        return SalesforceCredentials(
            access_token=token_data["access_token"],
            instance_url=token_data["instance_url"],
        )

    def _refresh(self, refresh_token: str) -> SalesforceCredentials:
        """Use refresh_token grant to get a new access token."""
        data = {
            "grant_type": "refresh_token",
            "client_id": self.client_id,
            "refresh_token": refresh_token,
        }
        response = httpx.post(
            f"{self.login_url}/services/oauth2/token",
            data=data,
            timeout=30.0,
        )
        response.raise_for_status()
        token_data = response.json()

        # Update stored tokens (refresh_token may not be returned on refresh)
        self._token_store.save(
            StoredTokens(
                access_token=token_data["access_token"],
                instance_url=token_data["instance_url"],
                refresh_token=token_data.get("refresh_token", refresh_token),
                token_type=token_data.get("token_type", "Bearer"),
                issued_at=token_data.get("issued_at"),
                org_key=self.org_key,
            )
        )

        return SalesforceCredentials(
            access_token=token_data["access_token"],
            instance_url=token_data["instance_url"],
        )

    @staticmethod
    def _open_browser(url: str) -> bool:
        """Try to open a browser. Returns False if headless."""
        # Check for display availability on Linux
        if os.environ.get("DISPLAY") or os.environ.get("BROWSER") or os.name == "nt" or platform.system() == "Darwin":
            try:
                webbrowser.open(url)
                return True
            except Exception:
                logger.info("Failed to open browser automatically")
                return False
        return False


__all__ = ["OAuthPKCEAuth"]
