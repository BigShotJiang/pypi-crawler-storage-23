"""OAuth 2.0 Client Credentials flow for Salesforce.

Server-to-server authentication — no user interaction required.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Optional

import httpx

from lineage.ingest.static_loaders.salesforce.auth.protocol import (
    SalesforceCredentials,
)

logger = logging.getLogger(__name__)


@dataclass
class ClientCredentialsAuth:
    """OAuth 2.0 Client Credentials authentication.

    Suitable for backend/service integrations where a Connected App is
    configured with the Client Credentials flow enabled.

    Args:
        client_id: Salesforce Connected App consumer key.
        client_secret: Salesforce Connected App consumer secret.
        login_url: Salesforce login URL.
    """

    client_id: str
    client_secret: str = field(repr=False)
    login_url: str = "https://login.salesforce.com"
    _credentials: Optional[SalesforceCredentials] = field(
        default=None, init=False, repr=False
    )

    def authenticate(self) -> SalesforceCredentials:
        """Authenticate using client credentials grant."""
        data = {
            "grant_type": "client_credentials",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }
        response = httpx.post(
            f"{self.login_url}/services/oauth2/token",
            data=data,
            timeout=30.0,
        )
        if response.status_code != 200:
            try:
                err = response.json()
            except Exception:
                err = response.text
            raise RuntimeError(
                f"Client credentials auth failed ({response.status_code}): {err}"
            )
        token_data = response.json()

        self._credentials = SalesforceCredentials(
            access_token=token_data["access_token"],
            instance_url=token_data["instance_url"],
        )
        return self._credentials

    def refresh_if_needed(self) -> SalesforceCredentials:
        """Re-authenticate (client credentials has no refresh token)."""
        return self.authenticate()


__all__ = ["ClientCredentialsAuth"]
