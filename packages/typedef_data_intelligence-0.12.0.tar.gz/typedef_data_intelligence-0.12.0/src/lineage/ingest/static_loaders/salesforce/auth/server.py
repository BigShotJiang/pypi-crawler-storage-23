"""Minimal localhost callback server for OAuth PKCE flow.

Uses only ``http.server`` from stdlib — no extra dependencies.
"""
from __future__ import annotations

import html
import logging
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Optional
from urllib.parse import parse_qs, urlparse

logger = logging.getLogger(__name__)

_RESPONSE_HTML = """\
<html><body>
<h2>Authentication successful</h2>
<p>You can close this window and return to the terminal.</p>
</body></html>
"""

_ERROR_HTML = """\
<html><body>
<h2>Authentication failed</h2>
<p>Error: {error}</p>
<p>{description}</p>
</body></html>
"""


class _CallbackHandler(BaseHTTPRequestHandler):
    """Handles a single GET /callback request, extracts ``?code=``."""

    auth_code: Optional[str] = None
    error: Optional[str] = None
    callback_state: Optional[str] = None

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)

        if "error" in params:
            _CallbackHandler.error = params["error"][0]
            desc = params.get("error_description", [""])[0]
            self.send_response(400)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(
                _ERROR_HTML.format(
                    error=html.escape(_CallbackHandler.error),
                    description=html.escape(desc),
                ).encode()
            )
            return

        code = params.get("code", [None])[0]
        state = params.get("state", [None])[0]
        if code:
            _CallbackHandler.auth_code = code
            _CallbackHandler.callback_state = state
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(_RESPONSE_HTML.encode())
        else:
            self.send_response(400)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<html><body>Missing code parameter</body></html>")

    def log_message(self, format: str, *args: object) -> None:
        # Silence default HTTP server logging
        logger.debug(format, *args)


def run_callback_server(
    port: int = 8443,
    timeout: float = 120.0,
) -> str:
    """Start a temporary HTTP server, wait for the OAuth callback, return the auth code.

    Args:
        port: Port to listen on (default 8443).
        timeout: Maximum seconds to wait for the callback.

    Returns:
        The authorization code from the callback query string.

    Raises:
        TimeoutError: If no callback arrives within ``timeout`` seconds.
        RuntimeError: If the OAuth provider returns an error.
    """
    _CallbackHandler.auth_code = None
    _CallbackHandler.error = None
    _CallbackHandler.callback_state = None

    server = HTTPServer(("localhost", port), _CallbackHandler)
    server.timeout = timeout

    # Handle exactly one request
    thread = threading.Thread(target=server.handle_request, daemon=True)
    thread.start()
    thread.join(timeout=timeout)
    server.server_close()

    if _CallbackHandler.error:
        raise RuntimeError(
            f"OAuth error: {_CallbackHandler.error}"
        )
    if _CallbackHandler.auth_code is None:
        raise TimeoutError(
            f"No OAuth callback received within {timeout}s on port {port}"
        )
    return _CallbackHandler.auth_code


def start_callback_server(
    port: int = 8443,
    timeout: float = 120.0,
) -> tuple[HTTPServer, threading.Event]:
    """Start the callback server and return immediately once it's listening.

    Returns a ``(server, ready_event)`` tuple. The caller should wait for
    ``ready_event`` to be set before opening the browser, then call
    :func:`wait_for_callback` to block until the code arrives.
    """
    _CallbackHandler.auth_code = None
    _CallbackHandler.error = None
    _CallbackHandler.callback_state = None

    server = HTTPServer(("localhost", port), _CallbackHandler)
    server.timeout = timeout

    ready = threading.Event()

    def _serve() -> None:
        ready.set()
        server.handle_request()

    thread = threading.Thread(target=_serve, daemon=True)
    thread.start()

    # Block until the server thread is actually listening
    ready.wait(timeout=5.0)
    return server, ready


def wait_for_callback(
    server: HTTPServer,
    timeout: float = 120.0,
) -> tuple[str, Optional[str]]:
    """Block until the callback server has received a request, then return the auth code and state.

    Args:
        server: The ``HTTPServer`` returned by :func:`start_callback_server`.
        timeout: Maximum seconds to wait.

    Returns:
        Tuple of (authorization_code, state). State may be ``None`` if
        the callback did not include a state parameter.

    Raises:
        TimeoutError: If no callback arrives within ``timeout`` seconds.
        RuntimeError: If the OAuth provider returns an error.
    """
    # The server thread is already running; wait for it to finish
    # by polling for the result (handle_request will return after one request or timeout)
    import time

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if _CallbackHandler.auth_code is not None or _CallbackHandler.error is not None:
            break
        time.sleep(0.1)

    server.server_close()

    if _CallbackHandler.error:
        raise RuntimeError(f"OAuth error: {_CallbackHandler.error}")
    if _CallbackHandler.auth_code is None:
        raise TimeoutError(
            f"No OAuth callback received within {timeout}s on port {server.server_address[1]}"
        )
    return _CallbackHandler.auth_code, _CallbackHandler.callback_state


__all__ = ["run_callback_server", "start_callback_server", "wait_for_callback"]
