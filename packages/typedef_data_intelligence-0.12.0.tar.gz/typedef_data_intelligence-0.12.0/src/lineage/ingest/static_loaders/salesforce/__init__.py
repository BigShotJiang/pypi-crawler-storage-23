"""Salesforce upstream metadata loader.

Fetches Salesforce org/object/field/report/dashboard metadata via the
REST API and loads it into the lineage graph with optional cross-domain
stitching to existing dbt nodes.
"""

from lineage.ingest.static_loaders.salesforce.auth import SalesforceAuth
from lineage.ingest.static_loaders.salesforce.client import SalesforceMetadataClient
from lineage.ingest.static_loaders.salesforce.loader import SalesforceLoader
from lineage.ingest.static_loaders.salesforce.stitcher import SalesforceStitcher

__all__ = [
    "SalesforceAuth",
    "SalesforceMetadataClient",
    "SalesforceLoader",
    "SalesforceStitcher",
]
