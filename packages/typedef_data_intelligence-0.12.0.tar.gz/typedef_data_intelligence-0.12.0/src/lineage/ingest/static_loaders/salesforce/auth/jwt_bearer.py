"""OAuth 2.0 JWT Bearer flow for Salesforce.

Server-to-server authentication using a private key to sign JWT assertions.
Requires ``PyJWT[crypto]`` (optional dependency, install via
``salesforce-jwt`` extras).
"""
from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import httpx

from lineage.ingest.static_loaders.salesforce.auth.protocol import (
    SalesforceCredentials,
)

logger = logging.getLogger(__name__)


@dataclass
class JWTBearerAuth:
    """OAuth 2.0 JWT Bearer assertion authentication.

    Args:
        client_id: Salesforce Connected App consumer key.
        username: Salesforce username to impersonate.
        private_key_path: Path to the PEM-encoded private key file.
        login_url: Salesforce login URL.
    """

    client_id: str
    username: str
    private_key_path: Path
    login_url: str = "https://login.salesforce.com"
    _credentials: Optional[SalesforceCredentials] = field(
        default=None, init=False, repr=False
    )

    def authenticate(self) -> SalesforceCredentials:
        """Authenticate using a signed JWT assertion."""
        try:
            import jwt
        except ImportError as exc:
            raise ImportError(
                "PyJWT[crypto] is required for JWT Bearer authentication. "
                "Install it with: pip install 'typedef-data-intelligence[salesforce-jwt]'"
            ) from exc

        private_key = self.private_key_path.read_text(encoding="utf-8")

        now = int(time.time())
        payload = {
            "iss": self.client_id,
            "sub": self.username,
            "aud": self.login_url,
            "exp": now + 300,  # 5 minute expiry
        }
        assertion = jwt.encode(payload, private_key, algorithm="RS256")

        data = {
            "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
            "assertion": assertion,
        }
        response = httpx.post(
            f"{self.login_url}/services/oauth2/token",
            data=data,
            timeout=30.0,
        )
        if response.status_code != 200:
            try:
                err = response.json()
            except Exception:
                err = response.text
            raise RuntimeError(
                f"JWT bearer auth failed ({response.status_code}): {err}"
            )
        token_data = response.json()

        self._credentials = SalesforceCredentials(
            access_token=token_data["access_token"],
            instance_url=token_data["instance_url"],
        )
        return self._credentials

    def refresh_if_needed(self) -> SalesforceCredentials:
        """Re-authenticate (JWT Bearer has no refresh token)."""
        return self.authenticate()


__all__ = ["JWTBearerAuth"]
