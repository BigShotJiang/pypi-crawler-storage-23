"""Key Lineage Graph — infers PK/FK relationships via IdentityClasses.

This module implements a derived overlay on existing DERIVES_FROM column lineage
that identifies identity-preserving transformations, groups columns into
IdentityClasses, scores PK candidates, and emits INFERRED_FK edges.
"""

from lineage.ingest.static_loaders.key_lineage.orchestrator import (
    KeyLineageOrchestrator,
)

__all__ = ["KeyLineageOrchestrator"]
