"""Key Lineage Orchestrator — chains all passes to build the key lineage overlay.

Idempotent: cleans up existing overlay before rebuilding.
Pattern follows ClusteringOrchestrator (delete-then-recreate derived overlay).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from lineage.backends.lineage.protocol import LineageStorage
from lineage.ingest.static_loaders.key_lineage.classifier import load_overrides
from lineage.ingest.static_loaders.key_lineage.pass1_classify_edges import (
    classify_edges,
)
from lineage.ingest.static_loaders.key_lineage.pass2_identity_classes import (
    compute_identity_classes,
    persist_identity_classes,
)
from lineage.ingest.static_loaders.key_lineage.pass3_pk_signals import (
    collect_all_pk_signals,
)
from lineage.ingest.static_loaders.key_lineage.pass4_pk_scoring import (
    persist_grain_columns,
    propagate_pk_within_identity_classes,
    score_and_persist_pk_candidates,
)
from lineage.ingest.static_loaders.key_lineage.pass5_fk_emission import (
    detect_composite_fks,
    emit_fk_edges,
    identify_fk_candidates,
    validate_fk_candidates,
)

logger = logging.getLogger(__name__)


@dataclass
class KeyLineageResult:
    """Summary result of the key lineage overlay build."""

    identity_class_count: int = 0
    total_members: int = 0
    pk_candidate_count: int = 0
    fk_edge_count: int = 0
    composite_fk_count: int = 0
    sf_field_links: int = 0
    elapsed_seconds: float = 0.0


class KeyLineageOrchestrator:
    """Orchestrates the key lineage overlay build.

    Chains all passes:
      1. Classify DERIVES_FROM edges
      2. Compute IdentityClass connected components
      3. Collect PK signals
      4. Score PK candidates and propagate
      5. Infer and emit FK edges

    Idempotent: calls _cleanup_existing_overlay() before building.
    """

    def __init__(self, storage: LineageStorage) -> None:  # noqa: D107
        self.storage = storage

    def build(
        self,
        dialect: str = "snowflake",
        overrides_path: Optional[Path] = None,
    ) -> KeyLineageResult:
        """Build the full key lineage overlay.

        Args:
            dialect: SQL dialect for expression parsing.
            overrides_path: Optional path to key_lineage_overrides.yaml.

        Returns:
            KeyLineageResult with summary statistics.
        """
        start = time.time()
        logger.info("Key Lineage: Starting overlay build...")

        # Idempotent cleanup
        self._cleanup_existing_overlay()

        # Load classification overrides
        overrides = load_overrides(overrides_path)
        if overrides:
            logger.info(f"Loaded {len(overrides)} classification overrides")

        # Pass 1: Classify edges
        logger.info("Key Lineage: Pass 1 — Classifying DERIVES_FROM edges...")
        identity_edges = classify_edges(
            self.storage, dialect=dialect, overrides=overrides
        )

        if not identity_edges:
            logger.warning("Key Lineage: No DERIVES_FROM edges found, aborting")
            return KeyLineageResult(elapsed_seconds=time.time() - start)

        # Pass 2: Compute IdentityClasses
        logger.info("Key Lineage: Pass 2 — Computing IdentityClasses...")
        identity_classes = compute_identity_classes(identity_edges, self.storage)

        if identity_classes:
            persist_identity_classes(identity_classes, self.storage)

        total_members = sum(len(ic.member_ids) for ic in identity_classes)

        # Post-Pass 2: Link SfFields into ICs via MapsToColumn
        sf_field_links = self._link_sf_fields_to_identity_classes()

        # Pass 3: Collect PK signals
        logger.info("Key Lineage: Pass 3 — Collecting PK signals...")
        signal_result = collect_all_pk_signals(self.storage)

        # Pass 4: Score and propagate
        logger.info("Key Lineage: Pass 4 — Scoring PK candidates...")
        pk_scores = score_and_persist_pk_candidates(signal_result, self.storage)

        if identity_classes:
            propagate_pk_within_identity_classes(pk_scores, self.storage)

        persist_grain_columns(signal_result.model_grain_columns, self.storage)

        # Pass 5: Emit FK edges
        logger.info("Key Lineage: Pass 5 — Inferring FK relationships...")
        candidates = identify_fk_candidates(self.storage)
        candidates = validate_fk_candidates(
            candidates, signal_result.declared_fks, self.storage
        )
        candidates = detect_composite_fks(
            candidates, signal_result.model_grain_columns
        )
        fk_count = emit_fk_edges(candidates, self.storage)

        composite_count = sum(1 for c in candidates if c.is_composite)

        elapsed = time.time() - start
        result = KeyLineageResult(
            identity_class_count=len(identity_classes),
            total_members=total_members,
            pk_candidate_count=len(pk_scores),
            fk_edge_count=fk_count,
            composite_fk_count=composite_count,
            sf_field_links=sf_field_links,
            elapsed_seconds=elapsed,
        )

        logger.info(
            f"Key Lineage: Complete in {elapsed:.1f}s — "
            f"{result.identity_class_count} identity classes, "
            f"{result.pk_candidate_count} PK candidates, "
            f"{result.fk_edge_count} FK edges, "
            f"{result.sf_field_links} SfField IC links"
        )

        return result

    def _link_sf_fields_to_identity_classes(self) -> int:
        """Link SfFields to IdentityClasses via MapsToColumn edges.

        For each SfField that maps (via MAPS_TO_COLUMN) to a DbtColumn that
        is already a member of an IdentityClass, create a
        BELONGS_TO_IDENTITY_CLASS edge from the SfField to the same IC.

        This runs after Pass 2 so that IC membership is already established
        for all DbtColumns.  SfFields get role="external" to distinguish them
        from DbtColumn members that were discovered through lineage traversal.

        Returns:
            Number of SfField -> IC edges created.
        """
        from lineage.backends.lineage.models.base import NodeIdentifier
        from lineage.backends.lineage.models.edges import BelongsToIdentityClass
        from lineage.backends.types import NodeLabel

        query = """
            MATCH (sf:SfField)-[:MAPS_TO_COLUMN]->(dc:DbtColumn)
                  -[:BELONGS_TO_IDENTITY_CLASS]->(ic:IdentityClass)
            WHERE NOT (sf)-[:BELONGS_TO_IDENTITY_CLASS]->(ic)
            RETURN sf.id AS sf_id, ic.id AS ic_id
        """
        result = self.storage.execute_raw_query(query)

        count = 0
        for row in result.rows:
            sf_id = row.get("sf_id", "")
            ic_id = row.get("ic_id", "")
            if not sf_id or not ic_id:
                continue
            try:
                sf_ref = NodeIdentifier(id=sf_id, node_label=NodeLabel.SF_FIELD)
                ic_ref = NodeIdentifier(id=ic_id, node_label=NodeLabel.IDENTITY_CLASS)
                self.storage.create_edge(
                    sf_ref, ic_ref,
                    BelongsToIdentityClass(role="external", confidence=1.0),
                )
                count += 1
            except Exception as e:
                logger.debug(f"Failed to link SfField {sf_id} to IC {ic_id}: {e}")

        if count:
            logger.info(f"Key Lineage: Linked {count} SfFields to IdentityClasses")

        return count

    def _cleanup_existing_overlay(self) -> None:
        """Remove existing key lineage overlay data.

        Deletes:
          - All IdentityClass nodes (and their edges via DETACH DELETE)
          - All INFERRED_FK edges
          - Resets PK properties on DbtColumn nodes
          - Resets grain_columns on DbtModel nodes
        """
        logger.info("Key Lineage: Cleaning up existing overlay...")

        # Delete IdentityClass nodes (cascades BELONGS_TO_IDENTITY_CLASS edges)
        try:
            self.storage.execute_raw_query(
                "MATCH (ic:IdentityClass) DETACH DELETE ic"
            )
        except Exception as e:
            logger.debug(f"Cleanup IdentityClass nodes: {e}")

        # Delete INFERRED_FK edges
        try:
            self.storage.execute_raw_query(
                "MATCH ()-[e:INFERRED_FK]->() DELETE e"
            )
        except Exception as e:
            logger.debug(f"Cleanup INFERRED_FK edges: {e}")

        # Reset PK properties on DbtColumn — covers all columns with any
        # key-lineage property set, not just is_pk_candidate=true
        try:
            self.storage.execute_raw_query(
                "MATCH (c:DbtColumn) WHERE c.is_pk_candidate = true "
                "OR c.pk_confidence > 0 OR size(c.pk_signals) > 0 "
                "OR c.identity_class_id <> '' "
                "SET c.is_pk_candidate = false, "
                "    c.pk_confidence = 0.0, "
                "    c.pk_signals = [], "
                "    c.identity_class_id = ''"
            )
        except Exception as e:
            logger.debug(f"Cleanup DbtColumn PK properties: {e}")

        # Reset grain_columns on DbtModel
        try:
            self.storage.execute_raw_query(
                "MATCH (m:DbtModel) WHERE size(m.grain_columns) > 0 "
                "SET m.grain_columns = []"
            )
        except Exception as e:
            logger.debug(f"Cleanup DbtModel grain_columns: {e}")

        logger.info("Key Lineage: Cleanup complete")
