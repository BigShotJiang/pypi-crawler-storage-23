"""Pass 1: Classify all DERIVES_FROM edges as identity-preserving or breaking.

Queries all DbtColumn-to-DbtColumn DERIVES_FROM edges and classifies each
based on the transformation type and (for computed transforms) the expression.

Two quality guards prevent over-merging of identity classes:
  1. Fan-out guard: when a single upstream column has many differently-named
     downstream targets via passthrough/source, those edges are treated as
     breaking (they are extraction/parsing operations mislabeled as passthrough).
  2. Expression reference guard: for computed expressions classified as
     preserving (e.g. COALESCE), verify the upstream column is actually
     referenced in the expression.  The upstream lineage engine sometimes
     attributes structural context columns (JOIN keys, GROUP BY) to a computed
     edge even though they don't appear in the expression.
"""

from __future__ import annotations

import logging
from typing import Optional

from lineage.backends.lineage.protocol import LineageStorage
from lineage.ingest.static_loaders.key_lineage.classifier import (
    IDENTITY_BREAKING_TRANSFORMATIONS,
    classify_computed_expr,
    classify_transformation,
)

logger = logging.getLogger(__name__)

# If an upstream column fans out to this many or more differently-named
# downstream columns via passthrough/source, treat those edges as breaking.
# Empirically: fanout=1 is legitimate renames (92%), fanout>=3 is clearly
# extraction/parsing (payload→42, cs_uri_query→15).
#
# Primary detection of extraction patterns is now syntax-based (in the scope
# engine's classify_expression()) and CTE-scope-based (Pass 1 third pass).
# This fan-out guard remains as a safety net for legacy edges or edge cases
# where neither detection ran (e.g. edges created by the legacy engine).
FANOUT_THRESHOLD = 3


def _expr_references_column(
    expr_str: str, column_name: str, dialect: str
) -> bool:
    """Check if a SQL expression references the given column name.

    Uses sqlglot to parse the expression and extract all Column references,
    then checks if column_name matches any of them (case-insensitive).

    Returns True conservatively (on parse failure or when no column refs found).
    """
    try:
        import sqlglot
        import sqlglot.expressions as exp

        tree = sqlglot.parse_one(expr_str, dialect=dialect)
        col_refs: set[str] = set()
        for col in tree.find_all(exp.Column):
            if col.name:
                col_refs.add(col.name.upper())
        if not col_refs:
            # Expression has no column references (e.g. pure literals) —
            # can't determine, keep conservative.
            return True
        return column_name.upper() in col_refs
    except Exception:
        return True  # conservative on parse failure


# ---------------------------------------------------------------------------
# CTE scope refinement helpers
# ---------------------------------------------------------------------------

# Type alias for the CTE scope index:
# model_id -> { (scope_name, column_name) -> [(target_scope, upstream_column, transformation, expr)] }
CteScopeIndex = dict[str, dict[tuple[str, str], list[tuple[Optional[str], str, str, str]]]]


def _load_cte_scope_edges(storage: LineageStorage) -> CteScopeIndex:
    """Load all CteScope DERIVES_FROM edges into an in-memory index.

    Returns a nested dict: model_id -> {(scope_name, column_name) -> [(target_scope, upstream_column, transformation, expr)]}
    """
    query = """
        MATCH (cs:CteScope)-[e:DERIVES_FROM]->(target)
        RETURN cs.model_id AS model_id, cs.name AS from_scope,
               e.column_name AS column_name, e.upstream_column AS upstream_column,
               e.transformation AS transformation, e.expr AS expr,
               CASE WHEN target:CteScope THEN target.name ELSE NULL END AS target_scope,
               CASE WHEN target:DbtColumn THEN target.id ELSE NULL END AS target_col_id
    """
    try:
        result = storage.execute_raw_query(query)
    except Exception:
        return {}

    index: CteScopeIndex = {}
    for row in result.rows:
        model_id = row.get("model_id") or ""
        from_scope = (row.get("from_scope") or "").lower()
        column_name = (row.get("column_name") or "").lower()
        upstream_column = (row.get("upstream_column") or "").lower()
        transformation = (row.get("transformation") or "").lower().strip()
        expr = row.get("expr") or ""
        target_scope = row.get("target_scope")
        if target_scope:
            target_scope = target_scope.lower()

        model_index = index.setdefault(model_id, {})
        key = (from_scope, column_name)
        model_index.setdefault(key, []).append(
            (target_scope, upstream_column, transformation, expr)
        )

    return index


def _cte_chain_has_breaking(
    scope_index: dict[tuple[str, str], list[tuple[Optional[str], str, str, str]]],
    scope_name: str,
    column_name: str,
    dialect: str,
    overrides: Optional[dict[str, str]],
    visited: Optional[set[tuple[str, str]]] = None,
) -> bool:
    """DFS trace through CTE scope edges to check for breaking transformations.

    At each hop:
    - If transformation is in IDENTITY_BREAKING_TRANSFORMATIONS -> True
    - If transformation is "computed" -> sub-classify with classify_computed_expr
    - If target is CteScope -> recurse with upstream_column
    """
    if visited is None:
        visited = set()

    key = (scope_name.lower(), column_name.lower())
    if key in visited:
        return False  # cycle — don't count as breaking
    visited.add(key)

    entries = scope_index.get(key, [])
    for target_scope, upstream_column, transformation, expr in entries:
        # Check if this hop is breaking
        if transformation in IDENTITY_BREAKING_TRANSFORMATIONS:
            return True
        if transformation == "computed":
            expr_class = classify_computed_expr(expr, dialect=dialect, overrides=overrides)
            if expr_class != "preserving":
                return True

        # If target is another CteScope, recurse
        if target_scope is not None:
            if _cte_chain_has_breaking(
                scope_index, target_scope, upstream_column,
                dialect, overrides, visited,
            ):
                return True

    return False


def _refine_with_cte_scopes(
    edge_classifications: dict[tuple[str, str], bool],
    rows: list[dict],
    cte_scope_index: CteScopeIndex,
    dialect: str,
    overrides: Optional[dict[str, str]],
) -> int:
    """Refine preserving DbtColumn->DbtColumn edges using CTE scope data.

    For each preserving edge, check if the downstream column's model has CTE
    scope data that reveals a breaking transformation in the CTE chain.

    Returns the number of edges demoted from preserving to breaking.
    """
    demoted = 0
    for row in rows:
        from_id = row.get("from_id", "")
        to_id = row.get("to_id", "")

        if not edge_classifications.get((from_id, to_id), False):
            continue  # already breaking, skip

        # Extract model_id and column_name from downstream column ID
        # Format: "model.project.model_name.column_name"
        parts = from_id.rsplit(".", 1)
        if len(parts) != 2:
            continue
        model_id, col_name = parts
        col_name = col_name.lower()

        model_scope_data = cte_scope_index.get(model_id)
        if not model_scope_data:
            continue

        # Check all CTE scopes in this model for edges involving this column
        # We look for any scope that outputs this column_name
        for (scope_name, scope_col), _entries in model_scope_data.items():
            if scope_col != col_name:
                continue
            # Found CTE scope data for this column — check if the chain has breaking
            if _cte_chain_has_breaking(
                model_scope_data, scope_name, col_name,
                dialect, overrides,
            ):
                edge_classifications[(from_id, to_id)] = False
                demoted += 1
                break  # one breaking path is enough

    return demoted


def classify_edges(
    storage: LineageStorage,
    dialect: str = "snowflake",
    overrides: Optional[dict[str, str]] = None,
) -> dict[tuple[str, str], bool]:
    """Classify all DERIVES_FROM edges between DbtColumns.

    Uses a two-pass approach:
      1. Compute fan-out per upstream column (how many differently-named
         downstream columns it feeds via passthrough/source).
      2. Classify each edge, applying fan-out and expression-reference guards.

    Args:
        storage: LineageStorage instance to query edges from.
        dialect: SQL dialect for expression parsing.
        overrides: Optional function classification overrides.

    Returns:
        Dict mapping (from_id, to_id) -> is_identity_preserving.
        Direction follows DERIVES_FROM: from_id is downstream, to_id is upstream.
    """
    query = """
        MATCH (output_col:DbtColumn)-[e:DERIVES_FROM]->(input_col:DbtColumn)
        RETURN output_col.id AS from_id,
               output_col.name AS from_name,
               input_col.id AS to_id,
               input_col.name AS to_name,
               e.transformation AS transformation,
               e.expr AS expr
    """
    result = storage.execute_raw_query(query)
    rows = list(result.rows)

    # First pass: compute fan-out for passthrough/source edges with name changes.
    # upstream_id -> set of distinct differently-named downstream column names.
    upstream_fanout: dict[str, set[str]] = {}
    for row in rows:
        transformation = (row.get("transformation") or "").lower().strip()
        if transformation in ("passthrough", "source"):
            from_name = (row.get("from_name") or "").lower()
            to_name = (row.get("to_name") or "").lower()
            if from_name != to_name:
                to_id = row.get("to_id", "")
                upstream_fanout.setdefault(to_id, set()).add(from_name)

    # Second pass: classify each edge with quality guards.
    edge_classifications: dict[tuple[str, str], bool] = {}
    preserving_count = 0
    breaking_count = 0
    fanout_demoted = 0
    expr_ref_demoted = 0

    for row in rows:
        from_id = row.get("from_id", "")
        to_id = row.get("to_id", "")
        from_name = (row.get("from_name") or "").lower()
        to_name = (row.get("to_name") or "").lower()
        transformation = row.get("transformation") or ""
        expr = row.get("expr") or ""

        classification = classify_transformation(transformation)

        if classification == "computed":
            expr_class = classify_computed_expr(
                expr, dialect=dialect, overrides=overrides
            )
            is_preserving = expr_class == "preserving"
            # Expression reference guard: verify the upstream column is actually
            # referenced in the expression (not just structural JOIN/GROUP BY
            # context attributed by the upstream lineage engine).
            if is_preserving and expr and to_name:
                if not _expr_references_column(expr, to_name, dialect):
                    is_preserving = False
                    expr_ref_demoted += 1
        elif classification == "preserving":
            is_preserving = True
            # Fan-out guard: if the upstream column fans out to many
            # differently-named downstream columns, this is extraction, not
            # a true passthrough or rename.
            if from_name != to_name:
                fanout = len(upstream_fanout.get(to_id, set()))
                if fanout >= FANOUT_THRESHOLD:
                    is_preserving = False
                    fanout_demoted += 1
        else:
            is_preserving = False

        edge_classifications[(from_id, to_id)] = is_preserving

        if is_preserving:
            preserving_count += 1
        else:
            breaking_count += 1

    demoted_parts = []
    if fanout_demoted:
        demoted_parts.append(f"{fanout_demoted} by fan-out guard")
    if expr_ref_demoted:
        demoted_parts.append(f"{expr_ref_demoted} by expr-ref guard")

    # Third pass: CTE scope refinement
    cte_scope_index = _load_cte_scope_edges(storage)
    if cte_scope_index:
        cte_demoted = _refine_with_cte_scopes(
            edge_classifications, rows, cte_scope_index, dialect, overrides
        )
        if cte_demoted:
            demoted_parts.append(f"{cte_demoted} by CTE scope refinement")
            # Update counts
            preserving_count -= cte_demoted
            breaking_count += cte_demoted

    demoted_msg = f", demoted: {', '.join(demoted_parts)}" if demoted_parts else ""

    logger.info(
        f"Pass 1: Classified {len(edge_classifications)} edges "
        f"({preserving_count} preserving, {breaking_count} breaking{demoted_msg})"
    )

    return edge_classifications
