"""Pass 3: Collect PK signals from multiple sources.

Gathers evidence that a column is a primary key candidate from:
  3a. dbt unique/not_null tests (gold)
  3b. dbt relationships tests — declared FK (gold)
  3c. Profiling statistics (silver)
  3d. Structural signals — group_key in grain-changing CTEs (bronze)
  3e. Naming heuristics (heuristic)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from lineage.backends.lineage.protocol import LineageStorage

logger = logging.getLogger(__name__)


@dataclass
class DeclaredFK:
    """A FK declared by a dbt relationships test."""

    fk_column_id: str
    fk_model_id: str
    pk_model_id: str
    fk_column_name: str
    referenced_field: str = ""


@dataclass
class PKSignalResult:
    """Aggregated PK signal data from all sub-collectors."""

    column_signals: dict[str, set[str]] = field(default_factory=dict)
    declared_fks: list[DeclaredFK] = field(default_factory=list)
    model_grain_columns: dict[str, list[str]] = field(default_factory=dict)


def collect_dbt_test_signals(storage: LineageStorage) -> dict[str, set[str]]:
    """Collect dbt unique and not_null test signals (gold tier).

    Queries DbtTest nodes connected via TESTS_COLUMN to DbtColumn.

    Returns:
        Dict mapping column_id -> set of signal names.
    """
    signals: dict[str, set[str]] = {}

    # Unique tests
    unique_query = """
        MATCH (t:DbtTest {test_name: 'unique'})-[:TESTS_COLUMN]->(c:DbtColumn)
        RETURN c.id AS column_id
    """
    result = storage.execute_raw_query(unique_query)
    for row in result.rows:
        col_id = row.get("column_id", "")
        if col_id:
            signals.setdefault(col_id, set()).add("dbt_unique_test")

    # Not-null tests
    not_null_query = """
        MATCH (t:DbtTest {test_name: 'not_null'})-[:TESTS_COLUMN]->(c:DbtColumn)
        RETURN c.id AS column_id
    """
    result = storage.execute_raw_query(not_null_query)
    for row in result.rows:
        col_id = row.get("column_id", "")
        if col_id:
            signals.setdefault(col_id, set()).add("dbt_not_null_test")

    logger.info(f"Pass 3a: Found dbt test signals for {len(signals)} columns")
    return signals


def collect_relationship_test_signals(
    storage: LineageStorage,
) -> list[DeclaredFK]:
    """Collect dbt relationships test signals (gold FK declarations).

    Queries DbtTest nodes with test_name='relationships' via TESTS_COLUMN
    and TEST_REFERENCES edges.

    Returns:
        List of DeclaredFK objects.
    """
    query = """
        MATCH (t:DbtTest {test_name: 'relationships'})-[:TESTS_COLUMN]->(fk_col:DbtColumn)
        OPTIONAL MATCH (t)-[ref:TEST_REFERENCES]->(target_model)
        RETURN fk_col.id AS fk_column_id,
               fk_col.parent_id AS fk_model_id,
               target_model.id AS pk_model_id,
               t.column_name AS fk_column_name,
               ref.referenced_field AS referenced_field
    """
    result = storage.execute_raw_query(query)

    declared_fks: list[DeclaredFK] = []
    for row in result.rows:
        fk_column_id = row.get("fk_column_id", "")
        if not fk_column_id:
            continue
        declared_fks.append(DeclaredFK(
            fk_column_id=fk_column_id,
            fk_model_id=row.get("fk_model_id", ""),
            pk_model_id=row.get("pk_model_id", ""),
            fk_column_name=row.get("fk_column_name", ""),
            referenced_field=row.get("referenced_field", ""),
        ))

    logger.info(f"Pass 3b: Found {len(declared_fks)} declared FK relationships")
    return declared_fks


def collect_profiling_signals(storage: LineageStorage) -> dict[str, set[str]]:
    """Collect profiling-based signals (silver tier).

    Queries DbtColumn -[:HAS_PROFILE]-> ColumnProfile (matching the loader's
    edge direction) and joins via HAS_COLUMN_PROFILE to TableProfile for
    row_count.

    Signals emitted:
      - profiling_unique:    uniqueness_ratio >= 0.99 (or fallback distinct_count/row_count)
      - profiling_not_null:  null_rate == 0 (or fallback null_count == 0)
      - profiling_monotonic: is_monotonic == true
      - pattern_uuid:        value_pattern == "uuid"
      - pattern_sequential:  value_pattern == "sequential"

    Returns:
        Dict mapping column_id -> set of signal names.
    """
    query = """
        MATCH (c:DbtColumn)-[:HAS_PROFILE]->(cp:ColumnProfile)
              <-[:HAS_COLUMN_PROFILE]-(tp:TableProfile)
        WHERE tp.row_count > 0
        RETURN c.id AS column_id,
               cp.distinct_count AS distinct_count,
               cp.null_count AS null_count,
               tp.row_count AS row_count,
               cp.uniqueness_ratio AS uniqueness_ratio,
               cp.null_rate AS null_rate,
               cp.is_monotonic AS is_monotonic,
               cp.value_pattern AS value_pattern
    """
    result = storage.execute_raw_query(query)

    signals: dict[str, set[str]] = {}
    for row in result.rows:
        col_id = row.get("column_id", "")
        if not col_id:
            continue

        row_count = row.get("row_count", 0) or 0
        if row_count <= 0:
            continue

        # Uniqueness: prefer new field, fall back to distinct_count/row_count
        uniqueness_ratio = row.get("uniqueness_ratio")
        if uniqueness_ratio is None:
            distinct_count = row.get("distinct_count", 0) or 0
            uniqueness_ratio = float(distinct_count) / float(row_count)
        if uniqueness_ratio >= 0.99:
            signals.setdefault(col_id, set()).add("profiling_unique")

        # Not-null: prefer new field, fall back to null_count == 0
        null_rate = row.get("null_rate")
        if null_rate is not None:
            if null_rate == 0:
                signals.setdefault(col_id, set()).add("profiling_not_null")
        else:
            null_count = row.get("null_count", 0) or 0
            if null_count == 0:
                signals.setdefault(col_id, set()).add("profiling_not_null")

        # Monotonic (new signal)
        is_monotonic = row.get("is_monotonic")
        if is_monotonic is True:
            signals.setdefault(col_id, set()).add("profiling_monotonic")

        # Value pattern signals (new)
        value_pattern = row.get("value_pattern")
        if value_pattern == "uuid":
            signals.setdefault(col_id, set()).add("pattern_uuid")
        elif value_pattern == "sequential":
            signals.setdefault(col_id, set()).add("pattern_sequential")

    logger.info(f"Pass 3c: Found profiling signals for {len(signals)} columns")
    return signals


def collect_structural_signals(
    storage: LineageStorage,
) -> tuple[dict[str, set[str]], dict[str, list[str]]]:
    """Collect structural signals from grain-changing CTEs (bronze tier).

    Queries CteScope nodes with has_grain_change=true and their STRUCTURALLY_USES
    edges with transformation='group_key' to find grain-defining columns.

    Returns:
        Tuple of (column_signals, model_grain_columns).
        - column_signals: dict mapping column_id -> set of signal names
        - model_grain_columns: dict mapping model_id -> list of grain column names
    """
    query = """
        MATCH (cte:CteScope {has_grain_change: true})-[e:STRUCTURALLY_USES]->(target)
        WHERE e.transformation = 'group_key'
        RETURN e.column_name AS column_name,
               cte.model_id AS model_id
    """
    result = storage.execute_raw_query(query)

    # Collect group_key columns per model
    model_group_keys: dict[str, set[str]] = {}
    for row in result.rows:
        col_name = row.get("column_name", "")
        model_id = row.get("model_id", "")
        if col_name and model_id:
            model_group_keys.setdefault(model_id, set()).add(col_name)

    # Build column signals and model grain columns
    column_signals: dict[str, set[str]] = {}
    model_grain_columns: dict[str, list[str]] = {}

    for model_id, grain_cols in model_group_keys.items():
        sorted_cols = sorted(grain_cols)
        model_grain_columns[model_id] = sorted_cols

        # Each grain column gets a signal — resolve to DbtColumn ID
        for col_name in sorted_cols:
            # DbtColumn ID format: {parent_id}.{column_name_lowercase}
            col_id = f"{model_id}.{col_name.lower()}"
            column_signals.setdefault(col_id, set()).add("grain_member")

    logger.info(
        f"Pass 3d: Found structural signals for {len(column_signals)} columns "
        f"across {len(model_grain_columns)} models"
    )
    return column_signals, model_grain_columns


def collect_naming_signals(storage: LineageStorage) -> dict[str, set[str]]:
    """Collect naming heuristic signals (heuristic tier).

    Columns ending in '_id' whose parent model belongs to a subject area
    get a naming_heuristic signal.

    Returns:
        Dict mapping column_id -> set of signal names.
    """
    query = """
        MATCH (m:DbtModel)-[:BELONGS_TO_SUBJECT_AREA]->(sa:InferredSubjectArea)
        MATCH (c:DbtColumn {parent_id: m.id})
        WHERE c.name ENDS WITH '_id'
        RETURN c.id AS column_id
    """
    result = storage.execute_raw_query(query)

    signals: dict[str, set[str]] = {}
    for row in result.rows:
        col_id = row.get("column_id", "")
        if col_id:
            signals.setdefault(col_id, set()).add("naming_heuristic")

    logger.info(f"Pass 3e: Found naming signals for {len(signals)} columns")
    return signals


def collect_all_pk_signals(storage: LineageStorage) -> PKSignalResult:
    """Aggregate all PK signals from sub-collectors.

    Calls all five sub-collectors and merges results into a single
    PKSignalResult.

    Returns:
        PKSignalResult with merged column_signals, declared_fks, and
        model_grain_columns.
    """
    # Collect from all sources
    dbt_signals = collect_dbt_test_signals(storage)
    declared_fks = collect_relationship_test_signals(storage)
    profiling_signals = collect_profiling_signals(storage)
    structural_signals, model_grain_columns = collect_structural_signals(storage)
    naming_signals = collect_naming_signals(storage)

    # Merge all column signals
    merged: dict[str, set[str]] = {}
    for source in [dbt_signals, profiling_signals, structural_signals, naming_signals]:
        for col_id, sigs in source.items():
            merged.setdefault(col_id, set()).update(sigs)

    logger.info(
        f"Pass 3: Aggregated PK signals for {len(merged)} columns, "
        f"{len(declared_fks)} declared FKs, "
        f"{len(model_grain_columns)} models with grain columns"
    )

    return PKSignalResult(
        column_signals=merged,
        declared_fks=declared_fks,
        model_grain_columns=model_grain_columns,
    )
