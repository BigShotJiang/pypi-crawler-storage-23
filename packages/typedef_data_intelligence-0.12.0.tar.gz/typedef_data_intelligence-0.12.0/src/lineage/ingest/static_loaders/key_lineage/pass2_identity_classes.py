"""Pass 2: Compute IdentityClass connected components.

Uses networkx connected_components on an undirected graph of identity-preserving
edges to find equivalence classes of columns representing the same entity key.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import networkx as nx

from lineage.backends.lineage.models.base import NodeIdentifier
from lineage.backends.lineage.models.edges import BelongsToIdentityClass
from lineage.backends.lineage.models.key_lineage import IdentityClass
from lineage.backends.lineage.protocol import LineageStorage
from lineage.backends.types import NodeLabel

logger = logging.getLogger(__name__)


@dataclass
class IdentityClassResult:
    """Result of computing a single identity class."""

    cluster_id: str
    entity_name: str
    source_model: str
    member_ids: list[str] = field(default_factory=list)
    root_column_id: str = ""


def compute_identity_classes(
    identity_edges: dict[tuple[str, str], bool],
    storage: LineageStorage,
) -> list[IdentityClassResult]:
    """Compute connected components over identity-preserving edges.

    Args:
        identity_edges: Dict from Pass 1 mapping (from_id, to_id) -> is_preserving.
        storage: LineageStorage for querying column metadata.

    Returns:
        List of IdentityClassResult, one per connected component.
    """
    # Build undirected graph from preserving edges only
    g = nx.Graph()
    for (from_id, to_id), is_preserving in identity_edges.items():
        if is_preserving:
            g.add_edge(from_id, to_id)

    if g.number_of_nodes() == 0:
        logger.info("Pass 2: No identity-preserving edges found")
        return []

    # Compute connected components
    components = list(nx.connected_components(g))

    # Filter out singleton components (a single column isn't an identity class)
    components = [c for c in components if len(c) > 1]

    if not components:
        logger.info("Pass 2: No multi-member identity classes found")
        return []

    # Build directed graph for root-finding (follow upstream direction)
    directed = nx.DiGraph()
    for (from_id, to_id), is_preserving in identity_edges.items():
        if is_preserving:
            # DERIVES_FROM: from_id (downstream) -> to_id (upstream)
            directed.add_edge(from_id, to_id)

    # For each component, find the root column
    results: list[IdentityClassResult] = []
    for component in components:
        root_id = _find_root_column(component, directed)

        # Extract entity name and source model from root column
        entity_name, source_model = _get_column_metadata(root_id, storage)

        cluster_id = f"ic::{root_id}"
        results.append(IdentityClassResult(
            cluster_id=cluster_id,
            entity_name=entity_name,
            source_model=source_model,
            member_ids=sorted(component),
            root_column_id=root_id,
        ))

    logger.info(
        f"Pass 2: Found {len(results)} identity classes "
        f"covering {sum(len(r.member_ids) for r in results)} columns"
    )

    return results


def _find_root_column(component: set[str], directed: nx.DiGraph) -> str:
    """Find the root column in a connected component.

    The root is the column with no upstream identity-preserving edge within
    the component. If multiple roots exist, pick the first alphabetically.
    """
    roots = []
    for col_id in component:
        # Check if this column has any upstream edges within the component
        has_upstream = False
        if col_id in directed:
            for successor in directed.successors(col_id):
                if successor in component:
                    has_upstream = True
                    break
        if not has_upstream:
            roots.append(col_id)

    if not roots:
        # Cycle detected — pick first alphabetically as fallback
        return min(component)

    return min(roots)


def _get_column_metadata(column_id: str, storage: LineageStorage) -> tuple[str, str]:
    """Get entity_name and source_model for a column.

    Args:
        column_id: DbtColumn ID (format: {parent_id}.{column_name})
        storage: LineageStorage instance.

    Returns:
        Tuple of (entity_name, source_model).
    """
    # Extract column name from ID: last segment after the last dot
    parts = column_id.rsplit(".", 1)
    entity_name = parts[-1] if parts else column_id

    # Extract parent model from ID: everything before the last dot
    source_model = parts[0] if len(parts) > 1 else ""

    return entity_name, source_model


def persist_identity_classes(
    identity_classes: list[IdentityClassResult],
    storage: LineageStorage,
) -> None:
    """Persist IdentityClass nodes and BELONGS_TO_IDENTITY_CLASS edges.

    Also updates DbtColumn.identity_class_id for each member.

    Args:
        identity_classes: Results from compute_identity_classes.
        storage: LineageStorage instance.
    """
    nodes = []
    edges = []

    for ic_result in identity_classes:
        # Create IdentityClass node
        ic_node = IdentityClass(
            name=ic_result.entity_name,
            entity_name=ic_result.entity_name,
            source_model=ic_result.source_model,
            cluster_id=ic_result.cluster_id,
            member_count=len(ic_result.member_ids),
            has_pk=False,
            has_fk=False,
        )
        nodes.append(ic_node)

        # Create edges and update column properties
        ic_identifier = ic_node.get_node_identifier()
        for member_id in ic_result.member_ids:
            col_identifier = NodeIdentifier(
                id=member_id,
                node_label=NodeLabel.DBT_COLUMN,
            )
            edge = BelongsToIdentityClass(role="key", confidence=0.0)
            edges.append((col_identifier, ic_identifier, edge))

    # Bulk load nodes
    if nodes:
        storage.bulk_load(nodes, [])
        logger.info(f"Created {len(nodes)} IdentityClass nodes")

    # Create edges
    for from_node, to_node, edge in edges:
        try:
            storage.create_edge(from_node, to_node, edge)
        except Exception as e:
            logger.debug(f"Failed to create edge {from_node.id} -> {to_node.id}: {e}")

    # Update identity_class_id on DbtColumn nodes
    for ic_result in identity_classes:
        for member_id in ic_result.member_ids:
            try:
                storage.execute_raw_query(
                    "MATCH (c:DbtColumn {id: $col_id}) SET c.identity_class_id = $ic_id",
                    params={"col_id": member_id, "ic_id": ic_result.cluster_id},
                )
            except Exception as e:
                logger.debug(f"Failed to update identity_class_id on {member_id}: {e}")

    logger.info(
        f"Pass 2: Persisted {len(nodes)} IdentityClass nodes, "
        f"{len(edges)} membership edges"
    )
