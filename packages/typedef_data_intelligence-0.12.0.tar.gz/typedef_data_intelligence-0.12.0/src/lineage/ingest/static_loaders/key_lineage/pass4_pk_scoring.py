"""Pass 4: Score PK candidates and propagate within IdentityClasses.

Aggregates PK signals into a confidence score, persists PK annotations
on DbtColumn nodes, propagates PK status within IdentityClasses, and
stores grain_columns on DbtModel nodes.
"""

from __future__ import annotations

import logging

from lineage.backends.lineage.protocol import LineageStorage
from lineage.ingest.static_loaders.key_lineage.pass3_pk_signals import PKSignalResult

logger = logging.getLogger(__name__)

# Signal weights per spec §5 Pass 4
SIGNAL_WEIGHTS: dict[str, float] = {
    "dbt_unique_test": 0.45,
    "dbt_not_null_test": 0.45,
    "profiling_unique": 0.35,
    "profiling_not_null": 0.35,
    "profiling_monotonic": 0.15,
    "pattern_uuid": 0.20,
    "pattern_sequential": 0.15,
    "grain_member": 0.25,
    "naming_heuristic": 0.15,
}

PK_CANDIDATE_THRESHOLD = 0.5


def score_pk(signals: set[str]) -> float:
    """Compute PK confidence score from a set of signals.

    Weights per spec:
      dbt_unique_test:   +0.45
      dbt_not_null_test: +0.45
      profiling_unique:  +0.35
      profiling_not_null:+0.35
      grain_member:      +0.25
      naming_heuristic:  +0.15

    Returns:
        Score capped at 1.0.
    """
    score = sum(SIGNAL_WEIGHTS.get(s, 0.0) for s in signals)
    return min(score, 1.0)


def score_and_persist_pk_candidates(
    signal_result: PKSignalResult,
    storage: LineageStorage,
) -> dict[str, float]:
    """Score all columns and persist PK annotations.

    Sets is_pk_candidate, pk_confidence, and pk_signals on DbtColumn nodes.

    Args:
        signal_result: Aggregated signals from Pass 3.
        storage: LineageStorage instance.

    Returns:
        Dict mapping column_id -> pk_confidence for columns that are candidates.
    """
    pk_scores: dict[str, float] = {}
    candidate_count = 0

    for col_id, signals in signal_result.column_signals.items():
        confidence = score_pk(signals)
        is_candidate = confidence >= PK_CANDIDATE_THRESHOLD

        if is_candidate:
            pk_scores[col_id] = confidence
            candidate_count += 1

        # Persist on DbtColumn node
        try:
            signals_list = sorted(signals)
            storage.execute_raw_query(
                "MATCH (c:DbtColumn {id: $col_id}) "
                "SET c.is_pk_candidate = $is_candidate, "
                "    c.pk_confidence = $confidence, "
                "    c.pk_signals = $signals",
                params={
                    "col_id": col_id,
                    "is_candidate": is_candidate,
                    "confidence": confidence,
                    "signals": signals_list,
                },
            )
        except Exception as e:
            logger.debug(f"Failed to persist PK score on {col_id}: {e}")

    logger.info(
        f"Pass 4: Scored {len(signal_result.column_signals)} columns, "
        f"{candidate_count} PK candidates (threshold >= {PK_CANDIDATE_THRESHOLD})"
    )

    return pk_scores


def propagate_pk_within_identity_classes(
    pk_scores: dict[str, float],
    storage: LineageStorage,
) -> None:
    """Propagate PK/FK roles within IdentityClasses.

    For each IdentityClass:
      - If any member is a PK candidate, set role="pk" on that member's
        BELONGS_TO_IDENTITY_CLASS edge and role="fk" on non-PK members.
      - Update has_pk/has_fk flags on the IdentityClass node.

    Args:
        pk_scores: Dict mapping column_id -> pk_confidence (PK candidates only).
        storage: LineageStorage instance.
    """
    # Get all identity classes and their members
    query = """
        MATCH (c:DbtColumn)-[e:BELONGS_TO_IDENTITY_CLASS]->(ic:IdentityClass)
        RETURN ic.id AS ic_id, c.id AS col_id, e.role AS current_role
    """
    result = storage.execute_raw_query(query)

    # Group members by identity class
    ic_members: dict[str, list[str]] = {}
    for row in result.rows:
        ic_id = row.get("ic_id", "")
        col_id = row.get("col_id", "")
        if ic_id and col_id:
            ic_members.setdefault(ic_id, []).append(col_id)

    updated_count = 0
    for ic_id, members in ic_members.items():
        pk_members = [m for m in members if m in pk_scores]
        fk_members = [m for m in members if m not in pk_scores]

        has_pk = len(pk_members) > 0
        has_fk = len(fk_members) > 0

        # Update IdentityClass flags
        try:
            storage.execute_raw_query(
                "MATCH (ic:IdentityClass {id: $ic_id}) "
                "SET ic.has_pk = $has_pk, ic.has_fk = $has_fk",
                params={"ic_id": ic_id, "has_pk": has_pk, "has_fk": has_fk},
            )
        except Exception as e:
            logger.debug(f"Failed to update IdentityClass {ic_id}: {e}")
            continue

        # Update edge roles
        for col_id in pk_members:
            try:
                storage.execute_raw_query(
                    "MATCH (c:DbtColumn {id: $col_id})"
                    "-[e:BELONGS_TO_IDENTITY_CLASS]->"
                    "(ic:IdentityClass {id: $ic_id}) "
                    "SET e.role = 'pk', e.confidence = $confidence",
                    params={
                        "col_id": col_id,
                        "ic_id": ic_id,
                        "confidence": pk_scores[col_id],
                    },
                )
            except Exception as e:
                logger.debug(f"Failed to set PK role on {col_id}: {e}")

        for col_id in fk_members:
            try:
                storage.execute_raw_query(
                    "MATCH (c:DbtColumn {id: $col_id})"
                    "-[e:BELONGS_TO_IDENTITY_CLASS]->"
                    "(ic:IdentityClass {id: $ic_id}) "
                    "SET e.role = 'fk'",
                    params={"col_id": col_id, "ic_id": ic_id},
                )
            except Exception as e:
                logger.debug(f"Failed to set FK role on {col_id}: {e}")

        updated_count += 1

    logger.info(
        f"Pass 4: Propagated PK/FK roles in {updated_count} IdentityClasses"
    )


def persist_grain_columns(
    model_grain_columns: dict[str, list[str]],
    storage: LineageStorage,
) -> None:
    """Persist grain_columns on DbtModel nodes.

    Args:
        model_grain_columns: Dict mapping model_id -> list of grain column names.
        storage: LineageStorage instance.
    """
    count = 0
    for model_id, grain_cols in model_grain_columns.items():
        try:
            storage.execute_raw_query(
                "MATCH (m:DbtModel {id: $model_id}) "
                "SET m.grain_columns = $grain_cols",
                params={"model_id": model_id, "grain_cols": grain_cols},
            )
            count += 1
        except Exception as e:
            logger.debug(f"Failed to set grain_columns on {model_id}: {e}")

    logger.info(f"Pass 4: Set grain_columns on {count} DbtModel nodes")
