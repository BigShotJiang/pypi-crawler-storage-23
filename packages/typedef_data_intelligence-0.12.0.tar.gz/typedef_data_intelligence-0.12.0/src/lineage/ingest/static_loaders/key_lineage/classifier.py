"""Transformation and expression classification for key lineage.

Classifies DERIVES_FROM edges as identity-preserving or identity-breaking
based on the transformation type and, for computed transforms, the SQL expression.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import yaml

logger = logging.getLogger(__name__)

# Transformation types that always preserve identity
IDENTITY_PRESERVING_TRANSFORMATIONS = frozenset({
    "passthrough",
    "renamed",
    "group_key",
    "source",
})

# Transformation types that always break identity
IDENTITY_BREAKING_TRANSFORMATIONS = frozenset({
    "aggregated",
    "windowed",
    "extraction",
    "unknown",
})

# Functions known to preserve identity (bijective or near-bijective on primary input)
# Includes both dialect-native names and sqlglot-normalized names (sql_name()).
PRESERVING_FUNCTIONS = frozenset({
    # Null handling
    "COALESCE", "IFNULL", "NVL", "NULLIF", "ZEROIFNULL",
    # Case normalization
    "LOWER", "UPPER", "TRIM", "LTRIM", "RTRIM",
    # Type conversion (dialect-specific CAST equivalents)
    "TO_DATE", "TO_TIMESTAMP", "TO_TIMESTAMP_NTZ", "TO_TIMESTAMP_TZ",
    "TO_NUMBER", "TO_DECIMAL", "TO_DOUBLE", "TO_VARCHAR", "TO_CHAR",
    "TRY_CAST", "TRY_TO_DATE", "TRY_TO_TIMESTAMP", "TRY_TO_NUMBER",
    "DATE", "TIMESTAMP",
    # sqlglot-normalized names for the above (e.g., TO_DATE -> TS_OR_DS_TO_DATE)
    "TS_OR_DS_TO_DATE", "TS_OR_DS_TO_TIMESTAMP",
})


def classify_transformation(transformation: str) -> str:
    """Classify a DERIVES_FROM transformation type.

    Args:
        transformation: The transformation property from a DERIVES_FROM edge.

    Returns:
        "preserving", "breaking", or "computed" (needs expr sub-classification).
    """
    t = (transformation or "").lower().strip()
    if t in IDENTITY_PRESERVING_TRANSFORMATIONS:
        return "preserving"
    if t in IDENTITY_BREAKING_TRANSFORMATIONS:
        return "breaking"
    if t == "computed":
        return "computed"
    # Unknown transformation type — conservative default
    return "breaking"


def _extract_function_name(tree) -> Optional[str]:
    """Extract the outermost function name from a sqlglot AST node."""
    import sqlglot.expressions as exp

    if isinstance(tree, exp.Anonymous):
        return tree.name.upper() if tree.name else None
    if isinstance(tree, exp.Func):
        name = tree.sql_name()
        return name.upper() if name else None
    return None


def classify_computed_expr(
    expr_str: str,
    dialect: str = "snowflake",
    overrides: Optional[dict[str, str]] = None,
) -> str:
    """Classify a computed expression as preserving, breaking, or unknown.

    Uses sqlglot to parse the expression and classify based on the outermost
    node type. Classification order follows the spec (section 2.3).

    Args:
        expr_str: The SQL expression string from the DERIVES_FROM edge.
        dialect: SQL dialect for parsing (default: snowflake).
        overrides: Optional dict of function_name -> classification overrides.

    Returns:
        "preserving", "breaking", or "unknown" (treated as breaking).
    """
    if not expr_str or not expr_str.strip():
        return "breaking"

    try:
        import sqlglot
        import sqlglot.expressions as exp

        tree = sqlglot.parse_one(expr_str, dialect=dialect)
    except Exception:
        return "breaking"  # conservative default on parse failure

    # 1. Check project overrides first
    if overrides:
        func_name = _extract_function_name(tree)
        if func_name and func_name in overrides:
            return overrides[func_name]

    # 2. Cast or TryCast → preserving, unless wrapping semi-structured access
    if isinstance(tree, (exp.Cast, exp.TryCast)):
        inner = tree.this
        # Semi-structured access wrapped in CAST is breaking (extraction)
        if isinstance(inner, exp.JSONExtract):
            return "breaking"
        if isinstance(inner, exp.Bracket) and isinstance(getattr(inner, "this", None), exp.Column):
            return "breaking"
        if inner and inner.find(exp.JSONExtract):
            return "breaking"
        return "preserving"

    # 3. Function call in preserving allowlist
    if isinstance(tree, exp.Func):
        name = tree.sql_name().upper()
        if name in PRESERVING_FUNCTIONS:
            return "preserving"

    if isinstance(tree, exp.Anonymous):
        if tree.name and tree.name.upper() in PRESERVING_FUNCTIONS:
            return "preserving"

    # 4. Case or If → breaking
    if isinstance(tree, (exp.Case, exp.If)):
        return "breaking"

    # 5. Arithmetic → breaking
    if isinstance(tree, (exp.Add, exp.Sub, exp.Mul, exp.Div)):
        return "breaking"

    # 6. Substring, Left, Right → breaking
    if isinstance(tree, (exp.Substring,)):
        return "breaking"
    # Left/Right may be Anonymous in some dialects
    if isinstance(tree, exp.Anonymous) and tree.name and tree.name.upper() in ("LEFT", "RIGHT"):
        return "breaking"

    # 7. Concat → breaking
    if isinstance(tree, (exp.Concat, exp.ConcatWs, exp.DPipe)):
        return "breaking"

    # 8. DateTrunc, DateDiff, Extract → breaking
    # TimestampTrunc is sqlglot's normalized form of DATE_TRUNC in some dialects
    if isinstance(tree, (exp.DateTrunc, exp.TimestampTrunc, exp.DateDiff, exp.Extract)):
        return "breaking"

    # 9. Unknown → conservative default
    return "unknown"


def load_overrides(path: Optional[Path] = None) -> dict[str, str]:
    """Load project-level classification overrides from YAML.

    The file should contain a top-level key `udf_classifications` mapping
    function names to their classification ("preserving" or "breaking").

    Args:
        path: Path to key_lineage_overrides.yaml. If None or missing, returns {}.

    Returns:
        Dict mapping uppercase function names to classification strings.
    """
    if path is None or not path.exists():
        return {}

    try:
        with open(path) as f:
            data = yaml.safe_load(f) or {}

        raw = data.get("udf_classifications", {})
        if not isinstance(raw, dict):
            logger.warning(f"Invalid udf_classifications in {path}: expected dict")
            return {}

        result = {}
        for func_name, classification in raw.items():
            if classification not in ("preserving", "breaking"):
                logger.warning(
                    f"Invalid classification '{classification}' for '{func_name}' in {path}, "
                    f"expected 'preserving' or 'breaking'"
                )
                continue
            result[func_name.upper()] = classification

        return result
    except Exception as e:
        logger.warning(f"Failed to load overrides from {path}: {e}")
        return {}
