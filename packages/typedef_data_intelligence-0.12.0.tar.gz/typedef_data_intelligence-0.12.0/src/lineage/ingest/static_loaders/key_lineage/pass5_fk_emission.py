"""Pass 5: Infer and emit FK edges.

Identifies FK candidates within IdentityClasses, ranks PK targets,
validates against existing evidence (JoinEdge, dbt tests), and emits
INFERRED_FK edges.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from lineage.backends.lineage.models.base import NodeIdentifier
from lineage.backends.lineage.models.edges import InferredFK
from lineage.backends.lineage.protocol import LineageStorage
from lineage.backends.types import NodeLabel
from lineage.ingest.static_loaders.key_lineage.pass3_pk_signals import DeclaredFK

logger = logging.getLogger(__name__)


@dataclass
class FKCandidate:
    """A candidate FK -> PK relationship."""

    fk_column_id: str
    pk_column_id: str
    fk_model_id: str
    pk_model_id: str
    identity_class_id: str
    confidence: float = 0.0
    signals: list[str] = field(default_factory=list)
    cardinality: str = "many_to_one"
    confirmed_by_join: bool = False
    confirmed_by_test: bool = False
    is_composite: bool = False
    composite_group: str = ""


def identify_fk_candidates(
    storage: LineageStorage,
) -> list[FKCandidate]:
    """Identify FK candidates from IdentityClasses with PK members.

    For each IdentityClass with has_pk=true, partitions members into PK and
    FK columns, then pairs each FK with the best PK target.

    Returns:
        List of FKCandidate objects.
    """
    # Get all identity classes with PK members
    query = """
        MATCH (c:DbtColumn)-[e:BELONGS_TO_IDENTITY_CLASS]->(ic:IdentityClass {has_pk: true})
        RETURN ic.id AS ic_id,
               c.id AS col_id,
               c.parent_id AS model_id,
               e.role AS role,
               c.is_pk_candidate AS is_pk,
               c.pk_confidence AS pk_confidence
    """
    result = storage.execute_raw_query(query)

    # Group by identity class
    ic_data: dict[str, list[dict]] = {}
    for row in result.rows:
        ic_id = row.get("ic_id", "")
        if ic_id:
            ic_data.setdefault(ic_id, []).append({
                "col_id": row.get("col_id", ""),
                "model_id": row.get("model_id", ""),
                "role": row.get("role", "key"),
                "is_pk": row.get("is_pk", False),
                "pk_confidence": row.get("pk_confidence", 0.0),
            })

    # Load subject area memberships for scoring
    sa_memberships = _load_subject_area_memberships(storage)

    # Load model roles (fact/dim) from subject area context
    model_roles = _load_model_roles(storage)

    # Load existing join edges for confirmation
    join_edges = _load_join_edges(storage)

    candidates: list[FKCandidate] = []

    for ic_id, members in ic_data.items():
        pk_members = [m for m in members if m.get("is_pk")]
        fk_members = [m for m in members if not m.get("is_pk")]

        if not pk_members or not fk_members:
            continue

        for fk in fk_members:
            best_pk, score, signals = _rank_pk_targets(
                fk, pk_members, sa_memberships, model_roles, join_edges
            )
            if best_pk is None:
                continue

            fk_is_pk = fk.get("is_pk", False)
            pk_is_pk = best_pk.get("is_pk", True)
            cardinality = infer_cardinality(fk_is_pk, pk_is_pk)

            candidates.append(FKCandidate(
                fk_column_id=fk["col_id"],
                pk_column_id=best_pk["col_id"],
                fk_model_id=fk["model_id"],
                pk_model_id=best_pk["model_id"],
                identity_class_id=ic_id,
                confidence=score,
                signals=signals,
                cardinality=cardinality,
            ))

    logger.info(f"Pass 5: Identified {len(candidates)} FK candidates")
    return candidates


def infer_cardinality(fk_is_unique: bool, pk_is_unique: bool) -> str:
    """Infer cardinality from uniqueness properties.

    Returns:
        "many_to_one", "one_to_one", or "many_to_many".
    """
    if pk_is_unique and not fk_is_unique:
        return "many_to_one"
    if pk_is_unique and fk_is_unique:
        return "one_to_one"
    return "many_to_many"


def validate_fk_candidates(
    candidates: list[FKCandidate],
    declared_fks: list[DeclaredFK],
    storage: LineageStorage,
) -> list[FKCandidate]:
    """Validate FK candidates against declared FKs and JoinEdges.

    Sets confirmed_by_join and confirmed_by_test flags on candidates.

    Args:
        candidates: FK candidates from identify_fk_candidates.
        declared_fks: Declared FK relationships from dbt tests.
        storage: LineageStorage instance.

    Returns:
        Same candidates list with confirmation flags set.
    """
    # Build lookup for declared FKs
    declared_set: set[tuple[str, str]] = set()
    for dfk in declared_fks:
        # Match by FK column and PK model
        declared_set.add((dfk.fk_column_id, dfk.pk_model_id))

    # Load join edges for confirmation
    join_pairs = _load_join_model_pairs(storage)

    for candidate in candidates:
        # Check declared FKs
        if (candidate.fk_column_id, candidate.pk_model_id) in declared_set:
            candidate.confirmed_by_test = True
            if "declared_fk" not in candidate.signals:
                candidate.signals.append("declared_fk")

        # Check JoinEdge confirmation
        pair = (candidate.fk_model_id, candidate.pk_model_id)
        reverse_pair = (candidate.pk_model_id, candidate.fk_model_id)
        if pair in join_pairs or reverse_pair in join_pairs:
            candidate.confirmed_by_join = True
            if "join_edge_confirmed" not in candidate.signals:
                candidate.signals.append("join_edge_confirmed")

    confirmed_count = sum(
        1 for c in candidates if c.confirmed_by_join or c.confirmed_by_test
    )
    logger.info(
        f"Pass 5: Validated {len(candidates)} candidates, "
        f"{confirmed_count} confirmed by existing evidence"
    )
    return candidates


def detect_composite_fks(
    candidates: list[FKCandidate],
    model_grain_columns: dict[str, list[str]],
) -> list[FKCandidate]:
    """Detect composite FK relationships.

    When a model has >1 grain column and ALL resolve to the same target
    dimension, mark as composite with a shared composite_group.

    Args:
        candidates: FK candidates to check.
        model_grain_columns: Dict mapping model_id -> grain column names.

    Returns:
        Updated candidates with composite flags set.
    """
    # Group candidates by FK model
    by_fk_model: dict[str, list[FKCandidate]] = {}
    for c in candidates:
        by_fk_model.setdefault(c.fk_model_id, []).append(c)

    for model_id, model_candidates in by_fk_model.items():
        grain_cols = model_grain_columns.get(model_id, [])
        if len(grain_cols) <= 1:
            continue

        # Build set of grain column IDs for this model
        grain_col_ids = {f"{model_id}.{col.lower()}" for col in grain_cols}

        # Find candidates whose FK column is a grain column
        grain_candidates = [
            c for c in model_candidates if c.fk_column_id in grain_col_ids
        ]

        if len(grain_candidates) < 2:
            continue

        # Check if all grain candidates point to the same target model
        target_models = {c.pk_model_id for c in grain_candidates}
        if len(target_models) == 1:
            # All point to same dim — this is a composite FK
            composite_group = f"composite::{model_id}::{next(iter(target_models))}"
            for c in grain_candidates:
                c.is_composite = True
                c.composite_group = composite_group

    composite_count = sum(1 for c in candidates if c.is_composite)
    if composite_count > 0:
        logger.info(f"Pass 5: Detected {composite_count} composite FK components")

    return candidates


def emit_fk_edges(
    candidates: list[FKCandidate],
    storage: LineageStorage,
) -> int:
    """Create INFERRED_FK edges for validated candidates.

    Args:
        candidates: Validated FK candidates.
        storage: LineageStorage instance.

    Returns:
        Number of edges created.
    """
    created = 0
    for candidate in candidates:
        fk_node = NodeIdentifier(
            id=candidate.fk_column_id,
            node_label=NodeLabel.DBT_COLUMN,
        )
        pk_node = NodeIdentifier(
            id=candidate.pk_column_id,
            node_label=NodeLabel.DBT_COLUMN,
        )
        edge = InferredFK(
            identity_class_id=candidate.identity_class_id,
            cardinality=candidate.cardinality,
            confidence=candidate.confidence,
            signals=candidate.signals,
            confirmed_by_join=candidate.confirmed_by_join,
            confirmed_by_test=candidate.confirmed_by_test,
            is_composite=candidate.is_composite,
            composite_group=candidate.composite_group,
        )
        try:
            storage.create_edge(fk_node, pk_node, edge)
            created += 1
        except Exception as e:
            logger.debug(
                f"Failed to create INFERRED_FK {candidate.fk_column_id} -> "
                f"{candidate.pk_column_id}: {e}"
            )

    logger.info(f"Pass 5: Created {created} INFERRED_FK edges")
    return created


# --- Private helpers ---


def _load_subject_area_memberships(
    storage: LineageStorage,
) -> dict[str, set[str]]:
    """Load model -> subject_area_ids mapping.

    Returns:
        Dict mapping model_id -> set of subject_area_ids.
    """
    query = """
        MATCH (m:DbtModel)-[:BELONGS_TO_SUBJECT_AREA]->(sa:InferredSubjectArea)
        RETURN m.id AS model_id, sa.id AS sa_id
    """
    result = storage.execute_raw_query(query)

    memberships: dict[str, set[str]] = {}
    for row in result.rows:
        model_id = row.get("model_id", "")
        sa_id = row.get("sa_id", "")
        if model_id and sa_id:
            memberships.setdefault(model_id, set()).add(sa_id)

    return memberships


def _load_model_roles(
    storage: LineageStorage,
) -> dict[str, str]:
    """Load model roles (fact/dimension/mixed) from subject area context.

    Uses InferredSubjectArea's recommended_fact_model and top_dimension_model_ids
    to determine model roles.

    Returns:
        Dict mapping model_id -> "fact" | "dimension" | "mixed".
    """
    query = """
        MATCH (sa:InferredSubjectArea)
        RETURN sa.id AS sa_id,
               sa.recommended_fact_model AS fact_model,
               sa.top_dimension_model_ids AS dim_models
    """
    result = storage.execute_raw_query(query)

    roles: dict[str, str] = {}
    for row in result.rows:
        fact_model = row.get("fact_model", "")
        if fact_model:
            roles.setdefault(fact_model, "fact")

        dim_models = row.get("dim_models") or []
        if isinstance(dim_models, str):
            # May be stored as a string; try split
            dim_models = [d.strip() for d in dim_models.split(",") if d.strip()]
        for dm in dim_models:
            if dm and dm not in roles:
                roles[dm] = "dimension"

    return roles


def _load_join_edges(
    storage: LineageStorage,
) -> dict[tuple[str, str], str]:
    """Load existing JoinEdge nodes.

    Returns:
        Dict mapping (left_model_id, right_model_id) -> equi_condition.
    """
    query = """
        MATCH (j:JoinEdge)
        WHERE j.left_model_id IS NOT NULL AND j.right_model_id IS NOT NULL
        RETURN j.left_model_id AS left_model,
               j.right_model_id AS right_model,
               j.equi_condition AS equi_condition
    """
    result = storage.execute_raw_query(query)

    joins: dict[tuple[str, str], str] = {}
    for row in result.rows:
        left = row.get("left_model", "")
        right = row.get("right_model", "")
        equi = row.get("equi_condition", "")
        if left and right:
            joins[(left, right)] = equi

    return joins


def _load_join_model_pairs(
    storage: LineageStorage,
) -> set[tuple[str, str]]:
    """Load set of model pairs that are connected by JoinEdges.

    Returns:
        Set of (model_id, model_id) tuples.
    """
    query = """
        MATCH (j:JoinEdge)
        WHERE j.left_model_id IS NOT NULL AND j.right_model_id IS NOT NULL
        RETURN j.left_model_id AS left_model,
               j.right_model_id AS right_model
    """
    result = storage.execute_raw_query(query)

    pairs: set[tuple[str, str]] = set()
    for row in result.rows:
        left = row.get("left_model", "")
        right = row.get("right_model", "")
        if left and right:
            pairs.add((left, right))

    return pairs


def _rank_pk_targets(
    fk: dict,
    pk_members: list[dict],
    sa_memberships: dict[str, set[str]],
    model_roles: dict[str, str],
    join_edges: dict[tuple[str, str], str],
) -> tuple[dict | None, float, list[str]]:
    """Rank PK targets for a given FK column.

    Scoring per spec:
      - Same subject area: +0.4
      - Role compatible (FK in fact -> PK in dim): +0.3
      - Confirmed by JoinEdge: +0.2
      - Depth proximity (same model excluded): +0.1

    Returns:
        Tuple of (best_pk_member, score, signals).
    """
    fk_model = fk["model_id"]
    fk_subject_areas = sa_memberships.get(fk_model, set())
    fk_role = model_roles.get(fk_model, "")

    best_pk = None
    best_score = 0.0
    best_signals: list[str] = []

    for pk in pk_members:
        pk_model = pk["model_id"]

        # Skip if same model (a column can't be its own FK target)
        if pk_model == fk_model:
            continue

        score = 0.0
        signals: list[str] = ["same_identity_class"]

        # Same subject area
        pk_subject_areas = sa_memberships.get(pk_model, set())
        if fk_subject_areas & pk_subject_areas:
            score += 0.4
            signals.append("same_subject_area")

        # Role compatibility (fact -> dimension)
        pk_role = model_roles.get(pk_model, "")
        if _roles_compatible(fk_role, pk_role):
            score += 0.3
            signals.append("role_compatible")

        # JoinEdge confirmation
        if (fk_model, pk_model) in join_edges or (pk_model, fk_model) in join_edges:
            score += 0.2
            signals.append("join_edge_confirmed")

        # Depth proximity (baseline small bonus for being in different models)
        score += 0.1

        if score > best_score:
            best_score = score
            best_pk = pk
            best_signals = signals

    return best_pk, best_score, best_signals


def _roles_compatible(fk_role: str, pk_role: str) -> bool:
    """Check if FK model role is compatible with PK model role.

    Compatible patterns:
      - fact -> dimension
      - mixed -> dimension
      - fact -> mixed
    """
    if fk_role in ("fact", "mixed") and pk_role in ("dimension", "mixed"):
        return True
    return False
