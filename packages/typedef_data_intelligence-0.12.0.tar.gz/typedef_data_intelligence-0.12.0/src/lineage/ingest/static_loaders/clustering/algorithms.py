"""Pure Python clustering algorithms - fully portable, no Cypher dependencies.

This module provides Louvain community detection using NetworkX's native
community detection subpackage.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Dict, Iterable, List, Set, Tuple

import networkx as nx


def _communities_to_partition(communities: Iterable[Set[str]]) -> Dict[str, int]:
    """Convert NetworkX community list to ID -> Community index format."""
    partition = {}
    for idx, community in enumerate(communities):
        for node in community:
            partition[node] = idx
    return partition


def _build_weighted_graph(
    nodes: List[str],
    weighted_edges: List[Tuple[str, str, float]],
) -> nx.Graph:
    """Build a weighted undirected NetworkX graph from nodes + edges."""
    G = nx.Graph()
    G.add_nodes_from(nodes)
    for u, v, w in weighted_edges:
        if w <= 0:
            continue
        if G.has_edge(u, v):
            G[u][v]["weight"] += w
        else:
            G.add_edge(u, v, weight=w)
    return G


def louvain_partition(
    nodes: List[str],
    weighted_edges: List[Tuple[str, str, float]],
    resolution: float = 1.0,
    seed: int = 42,
) -> Dict[str, int]:
    """NetworkX native Louvain community detection.

    Args:
        nodes: List of node IDs
        weighted_edges: List of (source, target, weight) tuples
        resolution: Resolution parameter for modularity
        seed: Random seed for reproducibility

    Returns:
        Dictionary mapping node ID -> community ID
    """
    if not nodes:
        return {}

    G = _build_weighted_graph(nodes, weighted_edges)
    communities = nx.community.louvain_communities(
        G, weight="weight", resolution=resolution, seed=seed
    )
    return _communities_to_partition(communities)


def cluster_models(
    nodes: List[str],
    weighted_edges: List[Tuple[str, str, float]],
    resolution: float = 1.0,
    seed: int = 42,
) -> Dict[int, List[str]]:
    """Cluster models using Louvain community detection.

    Args:
        nodes: List of model IDs to cluster
        weighted_edges: List of (source, target, weight) tuples representing edges
        resolution: Resolution parameter for Louvain modularity
        seed: Random seed for reproducibility

    Returns:
        Dictionary mapping cluster_id -> list of model IDs, sorted by cluster size
    """
    if not nodes:
        return {}

    partition = louvain_partition(nodes, weighted_edges, resolution=resolution, seed=seed)

    # Group nodes by cluster
    clusters: Dict[int, List[str]] = defaultdict(list)
    for node, cluster_id in partition.items():
        clusters[cluster_id].append(node)

    # Sort clusters by size (descending), then by smallest member ID
    sorted_clusters = {
        new_id: sorted(members)
        for new_id, (_, members) in enumerate(
            sorted(clusters.items(), key=lambda x: (-len(x[1]), min(x[1]) if x[1] else ""))
        )
    }

    return sorted_clusters


__all__ = [
    "louvain_partition",
    "cluster_models",
]
