"""Cluster summarization and blueprint generation.

This module analyzes clustered models to generate:
1. Cluster summaries: Role breakdown, domain analysis, PII detection, top edges
2. Cluster blueprints: Schema design templates with fact/dimension recommendations

The logic is ported from the reference implementation (reference/backend/cluster_join_graph.py)
but implemented using NetworkX for portability.
"""

from __future__ import annotations

import logging
from collections import Counter
from typing import Dict, List, Optional

import networkx as nx

from lineage.backends.lineage.models.clustering import (
    ClusterAnalysis,
    ModelEnrichmentData,
)
from lineage.ingest.static_loaders.clustering.enrichment import ClusterLabeling

logger = logging.getLogger(__name__)

# Generic terms that don't make good subject area names
GENERIC_TERMS = {"aggregation", "time_series", "transformation", "fact", "dim", "mart", "stg"}


def _generate_fallback_keywords(
    shared_domains: List[str],
    members: List[str],
    enrichment: Dict[str, ModelEnrichmentData],
) -> List[str]:
    """Generate fallback keywords when LLM labeling is unavailable.

    Derives keywords from:
    1. Top domains (already extracted from semantic analysis)
    2. Model name patterns (stripped of prefixes like fct_, dim_, stg_)
    3. Common measure/dimension names across cluster
    """
    keywords: set[str] = set()

    # 1. Add top domains (most valuable - already business-oriented)
    for domain in shared_domains[:5]:
        keywords.add(domain.lower())

    # 2. Extract meaningful terms from model names
    prefixes = {"fct_", "dim_", "stg_", "int_", "mart_", "raw_"}
    for model_id in members[:10]:  # Limit to avoid noise
        name = model_id.split(".")[-1].lower()
        for prefix in prefixes:
            if name.startswith(prefix):
                name = name[len(prefix) :]
                break
        # Split on underscores, keep meaningful terms
        for term in name.split("_"):
            if len(term) > 2 and term not in {"the", "and", "for"}:
                keywords.add(term)

    # 3. Add top measure names (business-relevant)
    measure_counts: Counter[str] = Counter()
    for model_id in members:
        if model_id in enrichment:
            measure_counts.update(enrichment[model_id].measure_names)
    for measure, _ in measure_counts.most_common(3):
        keywords.add(measure.lower())

    return sorted(keywords)[:8]  # Limit to 8 keywords


class ClusterSummarizer:
    """Generates cluster summaries and blueprints from clustering results.

    This class analyzes the graph structure and enrichment data to produce:
    - Detailed cluster summaries (size, roles, domains, PII, top edges)
    - Schema design blueprints (fact selection, dimension ordering, layering)
    """

    def generate_analysis(
        self,
        graph: nx.Graph,
        clusters: Dict[int, List[str]],
        enrichment: Dict[str, ModelEnrichmentData],
        cluster_labels: Optional[Dict[int, ClusterLabeling]] = None,
    ) -> List[ClusterAnalysis]:
        """Generate consolidated cluster analysis and blueprints.

        This is the main entry point. It analyzes each cluster to produce
        a ClusterAnalysis object containing both statistics and design recommendations.

        Args:
            graph: NetworkX graph with models as nodes and join edges
            clusters: Dictionary mapping cluster_id -> list of model IDs
            enrichment: Dictionary mapping model_id -> enrichment data
            cluster_labels: Optional labels from LLM labeling phase

        Returns:
            List of ClusterAnalysis objects, one per cluster
        """
        logger.info(f"Generating analysis for {len(clusters)} clusters...")

        results = []

        for cluster_id, members in sorted(clusters.items()):
            # Filter to only members with enrichment data
            members = [m for m in members if m in enrichment]
            if not members:
                logger.warning(f"Cluster {cluster_id}: all members missing enrichment, skipping")
                continue

            # Create subgraph for this cluster
            subgraph = graph.subgraph(members)
            label = cluster_labels.get(cluster_id) if cluster_labels else None

            # 1. Descriptive Analysis (The "What")
            facts = [m for m in members if enrichment[m].role == "fact"]
            dims = [m for m in members if enrichment[m].role == "dimension"]
            mixed = [m for m in members if enrichment[m].role == "mixed"]
            has_pii_models = [m for m in members if enrichment[m].has_pii]

            domain_counts: Counter[str] = Counter()
            for model_id in members:
                domain_counts.update([d for d in enrichment[model_id].domains if d])
            shared_domains = [d for d, _ in domain_counts.most_common(10)]

            edges_with_weight = [
                {
                    "source": u,
                    "target": v,
                    "weight": data.get("weight", 0.0),
                    "join_types": sorted(data.get("join_types", set())),
                }
                for u, v, data in subgraph.edges(data=True)
            ]
            top_edges = sorted(
                edges_with_weight,
                key=lambda e: e["weight"],
                reverse=True,
            )[:10]

            total_weight = subgraph.size(weight="weight")

            # 2. Design Blueprint (The "So What")
            weighted_degree = dict(subgraph.degree(weight="weight"))
            fact_candidates = facts or mixed or members
            fact_table = max(fact_candidates, key=lambda n: weighted_degree.get(n, 0.0)) if fact_candidates else None

            dimension_candidates = [m for m in members if m != fact_table]
            dimension_order = sorted(
                dimension_candidates,
                key=lambda n: weighted_degree.get(n, 0.0),
                reverse=True,
            )

            if label and label.subject_area:
                subject_area_name = label.subject_area
            else:
                primary_domain = shared_domains[0] if shared_domains else None

                if primary_domain and primary_domain.lower() not in GENERIC_TERMS:
                    subject_area_name = primary_domain
                elif fact_table:
                    fact_name = fact_table.split(".")[-1].replace("fct_", "").replace("int_", "").replace("_", " ").title()
                    subject_area_name = f"{primary_domain} ({fact_name})" if primary_domain and primary_domain.lower() in GENERIC_TERMS else fact_name
                else:
                    subject_area_name = f"cluster_{cluster_id}"

            # Qualitative notes (avoid restating data in structured fields)
            notes = []

            # Orphan models: members with 0 internal edges
            orphans = [m for m in members if subgraph.degree(m) == 0]
            if orphans:
                orphan_names = [m.split(".")[-1] for m in orphans[:5]]
                suffix = f" (+{len(orphans) - 5} more)" if len(orphans) > 5 else ""
                notes.append(f"Orphan models (0 internal edges): {', '.join(orphan_names)}{suffix}")

            # Hub models: weighted degree > 2x cluster mean
            if weighted_degree and len(members) > 1:
                mean_degree = sum(weighted_degree.get(m, 0.0) for m in members) / len(members)
                if mean_degree > 0:
                    hubs = [m for m in members if weighted_degree.get(m, 0.0) > 2 * mean_degree]
                    if hubs:
                        hub_names = [m.split(".")[-1] for m in sorted(hubs, key=lambda m: weighted_degree.get(m, 0.0), reverse=True)[:5]]
                        notes.append(f"Hub models (high fan-out): {', '.join(hub_names)}")

            # Single-role clusters
            if dims and not facts and not mixed:
                notes.append("Dimension-only cluster (no fact table)")
            elif facts and not dims and not mixed:
                notes.append("Fact-only cluster (no dimension tables)")

            results.append(ClusterAnalysis(
                cluster_id=cluster_id,
                subject_area_name=subject_area_name,
                description=label.description if label else None,
                model_count=len(members),
                model_ids=sorted(members),
                fact_model_ids=sorted(facts),
                dimension_model_ids=sorted(dims),
                mixed_model_ids=sorted(mixed),
                has_pii_model_ids=sorted(has_pii_models),
                domains=shared_domains,
                keywords=(
                    label.keywords
                    if label and label.keywords
                    else _generate_fallback_keywords(shared_domains, members, enrichment)
                ),
                total_edge_weight=total_weight,
                top_edges=top_edges,
                recommended_fact_model=fact_table,
                recommended_dimension_order=dimension_order,
                contains_pii=bool(has_pii_models),
                notes=notes,
            ))

        logger.info(f"Generated {len(results)} cluster analyses")
        return results


__all__ = ["ClusterSummarizer"]
