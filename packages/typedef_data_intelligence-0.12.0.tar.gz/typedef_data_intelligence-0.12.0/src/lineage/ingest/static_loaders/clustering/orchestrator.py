"""Clustering orchestration - coordinates the full clustering pipeline.

This module provides the main API for clustering. It coordinates:
1. Join graph extraction from semantic analysis
2. Optional model enrichment (role, domains, PII)
3. Louvain clustering algorithm execution
4. Cluster summarization and blueprint generation
5. Storage of results in graph database

The orchestrator is backend-agnostic and works with any LineageStorage implementation.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Dict, List, Optional, TypedDict

import fenic as fc
import networkx as nx

from lineage.backends.lineage.models.clustering import (
    ClusterAnalysis,
    ModelEnrichmentData,
)
from lineage.backends.lineage.protocol import LineageStorage
from lineage.ingest.static_loaders.clustering.algorithms import cluster_models
from lineage.ingest.static_loaders.clustering.enrichment import (
    ClusterLabeler,
    ClusterLabelingError,
    ModelEnricher,
)
from lineage.ingest.static_loaders.clustering.summarizer import ClusterSummarizer

if TYPE_CHECKING:
    from lineage.ingest.progress import ProgressTracker

logger = logging.getLogger(__name__)


class ClusteringResult(TypedDict):
    """Typed result from the clustering pipeline."""

    clusters: Dict[int, List[str]]
    analyses: List[ClusterAnalysis]
    enrichment: Dict[str, ModelEnrichmentData]


class ClusteringOrchestrator:
    """Orchestrates the complete clustering pipeline.

    This is the main entry point for clustering functionality. It coordinates
    all the steps from data extraction to storage, delegating to specialized
    components for each phase.

    Usage:
        session = create_session(default_model="google/gemini-2.5-flash-lite")
        orchestrator = ClusteringOrchestrator(storage)
        result = await orchestrator.cluster_and_analyze(
            session=session,
            min_weight=0.0,
            enrich_models=True,
        )
    """

    def __init__(self, storage: LineageStorage):
        """Initialize orchestrator with storage backend.

        Args:
            storage: LineageStorage instance for graph access
        """
        self.storage = storage

    async def cluster_and_analyze(
        self,
        session: fc.Session,
        min_weight: float = 0.0,
        resolution: float = 1.0,
        enrich_models: bool = True,
        label_clusters: bool = True,
        # Weights for hybrid clustering (higher = stronger clustering signal)
        # Rationale: explicit SQL joins indicate intentional relationships (2.0),
        # dbt lineage shows data flow (1.0), shared dependencies are indirect (0.5),
        # column lineage is often noisy from common source columns (0.1)
        join_weight: float = 2.0,
        lineage_weight: float = 1.0,
        shared_dependency_weight: float = 0.5,
        column_lineage_weight: float = 0.1,
        # Semantic weights (Phase 2 enhancement)
        # Domain similarity: models with overlapping domains should cluster together
        # Uses Jaccard similarity of domain sets as weight
        domain_similarity_weight: float = 0.3,
        # Progress tracking
        progress_tracker: Optional["ProgressTracker"] = None,
    ) -> ClusteringResult:
        """Execute the complete clustering pipeline.

        This method orchestrates all phases of clustering:
        1. Extract hybrid edges from graph (joins, lineage, shared deps)
        2. Enrich models (if enabled)
        3. Build weighted NetworkX graph
        4. Run Louvain clustering
        5. Generate human-readable labels via LLM (if enabled)
        6. Generate cluster analyses
        7. Store results in graph

        Args:
            session: Fenic session for LLM operations (managed by integration layer)
            min_weight: Minimum edge weight to include in clustering
            resolution: Resolution parameter for Louvain modularity
            enrich_models: Whether to run LLM enrichment for domains
            label_clusters: Whether to use LLM to label resulting clusters
            join_weight: Weight multiplier for direct join edges
            lineage_weight: Weight multiplier for direct dbt lineage edges
            shared_dependency_weight: Weight multiplier for shared parent/child edges
            column_lineage_weight: Weight multiplier for shared column lineage edges
            domain_similarity_weight: Weight multiplier for domain similarity edges
                (Jaccard similarity of business domain sets)
            progress_tracker: Optional progress tracker for UI updates

        Returns:
            ClusteringResult containing clusters, analyses, and enrichment data
        """
        # Import progress tracking types (deferred to avoid circular imports)
        from lineage.ingest.progress import SyncPhase

        logger.info("=" * 60)
        logger.info("Starting hybrid clustering pipeline (Louvain)")
        logger.info(f"  Structural weights: join={join_weight}, lineage={lineage_weight}, "
                    f"shared_dep={shared_dependency_weight}, col_lineage={column_lineage_weight}")
        logger.info(f"  Semantic weights: domain_similarity={domain_similarity_weight}")
        logger.info(f"  Enrich models: {enrich_models}, Label clusters: {label_clusters}")
        logger.info("=" * 60)

        # Phase 1: Extract hybrid edges from graph
        logger.info("\n[1/6] Extracting hybrid edges...")

        # Start CLUSTERING_GRAPH phase (covers edge extraction + graph construction)
        if progress_tracker:
            progress_tracker.phase_start(SyncPhase.CLUSTERING_GRAPH, 1, "Extracting edges")

        # 1.1 Direct Joins (structural)
        join_edges = self.storage.get_join_edges()
        logger.info(f"  Found {len(join_edges)} join edges (base weight={join_weight})")

        # 1.2 Direct Lineage (structural)
        lineage_edges = self.storage.get_lineage_edges()
        logger.info(f"  Found {len(lineage_edges)} lineage edges (base weight={lineage_weight})")

        # 1.3 Shared Dependencies (structural)
        shared_edges = self.storage.get_shared_dependency_edges()
        logger.info(f"  Found {len(shared_edges)} shared dependency edges (base weight={shared_dependency_weight})")

        # 1.4 Column Lineage (structural)
        column_edges = self.storage.get_column_lineage_edges()
        logger.info(f"  Found {len(column_edges)} column lineage edges (base weight={column_lineage_weight})")

        # 1.5 Domain Similarity (semantic)
        domain_edges: List[dict] = []
        if domain_similarity_weight > 0:
            domain_edges = self.storage.get_domain_similarity_edges()
            logger.info(f"  Found {len(domain_edges)} domain similarity edges (base weight={domain_similarity_weight})")

        # Phase 2: Get model list
        logger.info("\n[2/6] Loading models...")
        models = self.storage.get_all_models_with_analysis()
        model_ids = [m["model_id"] for m in models]
        logger.info(f"  Found {len(model_ids)} models with semantic analysis")

        if not model_ids:
            logger.error("No models found - cannot proceed with clustering")
            return {
                "clusters": {},
                "analyses": [],
                "enrichment": {},
            }

        # Phase 3: Build weighted NetworkX graph
        logger.info("\n[3/6] Building weighted hybrid graph...")
        G = nx.Graph()
        for model_id in model_ids:
            G.add_node(model_id)

        def add_weighted_edges(edges, weight_multiplier, label):
            count = 0
            for edge in edges:
                u, v = edge["source"], edge["target"]
                if u not in G or v not in G:
                    continue
                w = float(edge.get("weight", 1.0)) * weight_multiplier
                if G.has_edge(u, v):
                    G[u][v]["weight"] += w
                else:
                    G.add_edge(u, v, weight=w, join_types=set())
                # Accumulate join_types from join edges
                edge_join_types = edge.get("join_types", [])
                if edge_join_types:
                    G[u][v]["join_types"].update(edge_join_types)
                count += 1
            if count > 0:
                logger.debug(f"    Added {count} {label} edges")

        add_weighted_edges(join_edges, join_weight, "join")
        add_weighted_edges(lineage_edges, lineage_weight, "lineage")
        add_weighted_edges(shared_edges, shared_dependency_weight, "shared dependency")
        add_weighted_edges(column_edges, column_lineage_weight, "column lineage")
        if domain_similarity_weight > 0:
            add_weighted_edges(domain_edges, domain_similarity_weight, "domain similarity")

        # Filter by minimum weight (optional, usually 0.0 for hybrid)
        if min_weight > 0:
            to_remove = [(u, v) for u, v, d in G.edges(data=True) if d.get("weight", 0) < min_weight]
            G.remove_edges_from(to_remove)
            logger.info(f"  Filtered to {G.number_of_edges()} edges (min_weight={min_weight})")

        logger.info(f"  Final graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")

        # Complete CLUSTERING_GRAPH phase
        if progress_tracker:
            progress_tracker.phase_complete(SyncPhase.CLUSTERING_GRAPH)

        # Phase 4: Run Louvain clustering
        logger.info("\n[4/6] Running Louvain clustering...")

        # Start CLUSTERING_PARTITION phase
        if progress_tracker:
            progress_tracker.phase_start(SyncPhase.CLUSTERING_PARTITION, 1, "Running Louvain algorithm")

        weighted_edges_list = [
            (u, v, float(d["weight"])) for u, v, d in G.edges(data=True)
        ]
        clusters = cluster_models(
            model_ids, weighted_edges_list, resolution=resolution
        )
        logger.info(f"  Found {len(clusters)} clusters")

        # Complete CLUSTERING_PARTITION phase
        if progress_tracker:
            progress_tracker.phase_complete(SyncPhase.CLUSTERING_PARTITION)

        # Start CLUSTERING_ANALYSIS phase (covers enrichment, labeling, summarization, storage)
        if progress_tracker:
            progress_tracker.phase_start(SyncPhase.CLUSTERING_ANALYSIS, 1, "Enriching models")

        # Phase 5: Enrichment and Labeling
        enrichment = {}
        if enrich_models:
            logger.info("\n[5/6] Enriching models...")
            enricher = ModelEnricher(self.storage)
            enrichment = await enricher.enrich_all_models(models=models)

            # Add weighted degree to enrichment
            weighted_degree = dict(G.degree(weight="weight"))
            for model_id, data in enrichment.items():
                data.weighted_degree = weighted_degree.get(model_id, 0.0)

            logger.info(f"  Enriched {len(enrichment)} models")
        else:
            # Create minimal enrichment data
            for model_id in model_ids:
                enrichment[model_id] = ModelEnrichmentData(
                    model_id=model_id, role="unknown", domains=[], has_pii=False,
                    fact_count=0, dimension_count=0, weighted_degree=0.0,
                )

        cluster_labels = {}
        if label_clusters and clusters:
            logger.info("\n[5.1/6] Labeling clusters with Fenic...")
            labeler = ClusterLabeler(self.storage)
            try:
                cluster_labels = await labeler.label_clusters(
                    session=session,
                    clusters=clusters,
                    model_enrichment=enrichment,
                    models_info=models,
                )
            except (ClusterLabelingError, ValueError, RuntimeError) as e:
                logger.warning(f"Cluster labeling failed: {e}. Continuing without labels.")
                cluster_labels = {}

        # Phase 6: Generate cluster analyses
        logger.info("\n[6/6] Generating cluster analysis...")
        summarizer = ClusterSummarizer()
        analyses = summarizer.generate_analysis(
            G, clusters, enrichment, cluster_labels=cluster_labels
        )
        logger.info(f"  Generated {len(analyses)} cluster analyses")

        # Phase 7: Store in graph
        logger.info("\nStoring cluster analysis in graph...")
        try:
            self.storage.store_cluster_analysis(clusters, analyses)
            logger.info("  ✅ Successfully stored cluster analysis")
        except NotImplementedError:
            logger.warning(
                "  ⚠️  store_cluster_analysis() not implemented in adapter - skipping storage"
            )
        except Exception as e:
            logger.error(f"  ❌ Failed to store cluster analysis: {e}")

        # Complete CLUSTERING_ANALYSIS phase
        if progress_tracker:
            progress_tracker.phase_complete(SyncPhase.CLUSTERING_ANALYSIS)

        logger.info("\n" + "=" * 60)
        logger.info("Clustering pipeline complete!")
        logger.info("=" * 60)

        return {
            "clusters": clusters,
            "analyses": analyses,
            "enrichment": enrichment,
        }


__all__ = ["ClusteringOrchestrator"]
