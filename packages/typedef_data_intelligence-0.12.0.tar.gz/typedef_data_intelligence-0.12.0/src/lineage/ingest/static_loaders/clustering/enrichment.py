"""Model enrichment: role classification, domain extraction, PII detection.

This module provides enrichment functionality to classify models and extract
business metadata needed for cluster analysis. It queries the graph for
semantic analysis data and uses LLM extraction (via Fenic) to identify
business domains.

Key functionality:
- Role classification: Classify models as "fact", "dimension", or "mixed"
- Domain extraction: Extract business domain keywords from richer per-model context
- PII detection: Aggregate PII flags from BusinessDimension nodes
- Statistics: Count measures and dimensions per model
"""

from __future__ import annotations

import logging
from typing import Dict, List

from pydantic import BaseModel, Field

try:
    import fenic as fc
    FENIC_AVAILABLE = True
except ImportError:
    FENIC_AVAILABLE = False

from lineage.backends.lineage.models.clustering import ModelEnrichmentData
from lineage.backends.lineage.protocol import LineageStorage

logger = logging.getLogger(__name__)
MAX_CLUSTER_MODELS_FOR_DISPLAY = 50

class ClusterLabelingError(Exception):
    """Raised when LLM cluster labeling fails."""
    pass


class ClusterLabeling(BaseModel):
    """Schema for LLM-powered cluster labeling.

    Extract this from the context of all models in a cluster to provide a
    collective, high-level business name and description for the entire group.
    """

    subject_area: str = Field(
        description="A concise, high-level business name for the cluster (e.g., 'User Usage Analytics', 'Sales Opportunity Management', 'License Management'). "
        "Analyze all the model names and intents in this cluster and provide a COLLECTIVE name that describes WHAT business domain or process they all support. "
        "Avoid generic technical terms like 'Aggregation Cluster', 'Data Pipeline', or 'Table Group'. "
        "Focus on the business entity or process (e.g., 'Server Configuration', 'Product Usage Tracking', 'Customer Licensing')."
    )
    description: str = Field(
        description="A one-sentence summary of the cluster's collective purpose. "
        "Explain what business questions this group of models can answer together. "
        "For example: 'Tracks daily user activity across features for engagement analysis' or 'Manages trial license lifecycle from request to activation'."
    )
    keywords: list[str] = Field(
        default_factory=list,
        description="3-8 lowercase, normalized search terms that agents can match against. "
        "Include the core business entity, process, and key concepts. "
        "For example: ['licensing', 'trial', 'activation', 'subscription'] or ['revenue', 'arr', 'billing', 'invoice']. "
        "Avoid generic terms like 'data', 'analytics', 'model'."
    )


class ModelEnricher:
    """Enriches models with clustering metadata.

    This class coordinates the enrichment process, which includes:
    1. Role classification based on semantic analysis
    2. Extraction of business domains from stored semantic analysis
    3. PII detection from column metadata
    4. Statistical counts (measures, dimensions)
    """

    def __init__(self, storage: LineageStorage):
        """Initialize enricher with storage backend.

        Args:
            storage: LineageStorage instance for querying graph
        """
        self.storage = storage

    async def enrich_all_models(
        self,
        models: List[Dict] | None = None,
    ) -> Dict[str, ModelEnrichmentData]:
        """Enrich all models with clustering metadata.

        This is the main entry point. It queries the graph for all models
        with semantic analysis, classifies their roles, extracts domains
        from stored results, and gathers PII/statistics.

        Args:
            models: Optional pre-fetched model metadata (used to avoid duplicate queries)

        Returns:
            Dictionary mapping model_id -> ModelEnrichmentData
        """
        logger.info("Starting model enrichment...")

        # Get all models with semantic analysis
        models = models or self.storage.get_all_models_with_analysis()
        logger.info(f"Found {len(models)} models with semantic analysis")

        # Build enrichment data for each model
        enriched = {}
        for model_data in models:
            model_id = model_data["model_id"]

            # Single enrichment query per model (counts + lists + PII)
            semantic = self.storage.get_model_semantic_enrichment(model_id)
            measure_count = int(semantic.get("measure_count", 0) or 0)
            dimension_count = int(semantic.get("dimension_count", 0) or 0)
            role = self._classify_role_from_counts(measure_count, dimension_count)
            has_pii = bool(semantic.get("has_pii", False))
            measure_names = semantic.get("measure_names", []) or []
            dimension_names = semantic.get("dimension_names", []) or []
            fact_names = semantic.get("fact_names", []) or []

            # Use domains already stored in the graph (from semantic analysis)
            domains = model_data.get("domains") or []

            enriched[model_id] = ModelEnrichmentData(
                model_id=model_id,
                role=role,
                domains=domains,
                has_pii=has_pii,
                # NOTE: `ModelEnrichmentData.fact_count` is historically defined as the
                # number of BusinessMeasure nodes, not InferredFact nodes.
                fact_count=measure_count,
                dimension_count=dimension_count,
                measure_names=measure_names,
                dimension_names=dimension_names,
                fact_names=fact_names,
            )

        logger.info(f"Enriched {len(enriched)} models")

        # Log role distribution
        role_counts = {}
        for data in enriched.values():
            role_counts[data.role] = role_counts.get(data.role, 0) + 1
        logger.info(f"Role distribution: {role_counts}")

        return enriched

    @staticmethod
    def _classify_role_from_counts(measure_count: int, dimension_count: int) -> str:
        """Classify role given measure/dimension counts."""
        if measure_count > 0 and dimension_count > 0:
            return "mixed"
        if measure_count > 0:
            return "fact"
        return "dimension"


class ClusterLabeler:
    """Labels clusters using LLM-powered analysis.

    This class groups metadata from all members of a cluster and uses Fenic
    to generate a representative subject area name and description.
    """

    def __init__(self, storage: LineageStorage):
        """Initialize labeler with storage backend."""
        self.storage = storage

    async def label_clusters(
        self,
        session: fc.Session,
        clusters: Dict[int, List[str]],
        model_enrichment: Dict[str, ModelEnrichmentData],
        models_info: List[Dict] | None = None,
    ) -> Dict[int, ClusterLabeling]:
        """Generate human-readable labels for clusters in batch.

        Args:
            session: Fenic session for LLM operations
            clusters: Dict mapping cluster_id -> list of model IDs
            model_enrichment: Dictionary mapping model_id -> ModelEnrichmentData
            models_info: Optional pre-fetched model metadata

        Returns:
            Dictionary mapping cluster_id -> ClusterLabeling
        """
        if not FENIC_AVAILABLE:
            logger.warning("Fenic not available, skipping cluster labeling")
            return {}

        if not clusters:
            return {}

        logger.info(f"Labeling {len(clusters)} clusters using LLM...")

        # Get all model info once outside the loop
        models_info = models_info or self.storage.get_all_models_with_analysis()
        id_to_model = {m["model_id"]: m for m in models_info}

        # Build brief per-cluster summaries for cross-cluster context
        max_summary_names = 10
        cluster_briefs: Dict[int, str] = {}
        for cluster_id, model_ids in clusters.items():
            names = []
            for mid in model_ids:
                m = id_to_model.get(mid, {})
                names.append(m.get("model_name") or mid.split(".")[-1])
            preview = ", ".join(names[:max_summary_names])
            if len(names) > max_summary_names:
                preview += ", ..."
            cluster_briefs[cluster_id] = (
                f"Cluster with {len(model_ids)} models: {preview}"
            )

        # Prepare cluster metadata for extraction
        cluster_data = []
        for cluster_id, model_ids in clusters.items():
            member_details = []
            for mid in model_ids:
                m = id_to_model.get(mid, {})
                enrich = model_enrichment.get(mid)

                name = m.get("model_name") or mid.split(".")[-1]
                intent = m.get("intent", "")
                domains = enrich.domains if enrich and enrich.domains else []
                role = enrich.role if enrich else "unknown"

                # Build detailed context line
                line = f"- {name}"
                if intent and intent != "No description available":
                    line += f": {intent}"
                if domains:
                    line += f" [Domains: {', '.join(domains)}]"
                if role != "unknown":
                    line += f" [Role: {role}]"

                member_details.append(line)

            # Create structured cluster context
            cluster_summary = f"This cluster contains {len(model_ids)} models:\n\n"
            cluster_summary += "\n".join(member_details[:MAX_CLUSTER_MODELS_FOR_DISPLAY])  # Limit to first MAX_CLUSTER_MODELS_FOR_DISPLAY models
            if len(member_details) > MAX_CLUSTER_MODELS_FOR_DISPLAY:
                cluster_summary += f"\n... and {len(member_details) - MAX_CLUSTER_MODELS_FOR_DISPLAY} more models"

            # Append cross-cluster context so the LLM picks distinct names
            other_briefs = [
                brief for cid, brief in cluster_briefs.items() if cid != cluster_id
            ]
            if other_briefs:
                cluster_summary += (
                    "\n\nOther clusters in this project "
                    "(choose a name DISTINCT from what these would be called):\n"
                )
                cluster_summary += "\n".join(f"- {b}" for b in other_briefs)

            cluster_data.append({
                "cluster_id": cluster_id,
                "context": cluster_summary
            })

        try:
            # Use Fenic for batch extraction
            df = session.create_dataframe(cluster_data)

            result_df = df.select(
                fc.col("cluster_id"),
                fc.semantic.extract(
                    "context",
                    ClusterLabeling,
                    model_alias="medium"
                ).alias("labeling")
            )

            rows = result_df.to_pylist()

            labels_by_cluster = {}
            for row in rows:
                cid = row["cluster_id"]
                labeling_dict = row.get("labeling")

                if labeling_dict:
                    try:
                        labeling = ClusterLabeling.model_validate(labeling_dict)
                        labels_by_cluster[cid] = labeling
                    except Exception as e:
                        logger.debug(f"Failed to validate labeling for cluster {cid}: {e}")

            logger.info(f"Successfully labeled {len(labels_by_cluster)} clusters")
            return labels_by_cluster

        except Exception as e:
            logger.error(f"LLM cluster labeling failed: {e}")
            raise ClusterLabelingError("LLM cluster labeling failed") from e


__all__ = ["ModelEnricher", "ClusterLabeler"]
