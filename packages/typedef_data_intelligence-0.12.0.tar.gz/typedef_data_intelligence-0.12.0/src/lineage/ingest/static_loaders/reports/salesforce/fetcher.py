"""Graph-based data fetcher for Salesforce report IR generation.

Reads existing SfReport, SfReportColumn, and NativeReportDefinition nodes
from the lineage graph — no Salesforce API calls required.
"""
from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from lineage.backends.lineage.protocol import LineageStorage

logger = logging.getLogger(__name__)


def fetch_reports_from_graph(
    storage: LineageStorage,
    org_key: str,
) -> list[dict[str, Any]]:
    """Fetch SfReport data with columns and Metadata API JSON from the graph.

    For each SfReport belonging to ``org_key``:
    - Retrieves report properties (name, report_format, report_type, etc.)
    - Retrieves SfReportColumn nodes via SF_REPORT_HAS_COLUMN edges
    - Retrieves NativeReportDefinition content (Metadata API JSON) via
      the canonical Report spine

    Args:
        storage: Lineage storage backend.
        org_key: Salesforce org key to filter reports.

    Returns:
        List of dicts, one per report, each containing:
        - report_id, name, report_format, report_type, org_key, folder_name
        - columns: list of column dicts (column_key, data_type, object_api_name)
        - metadata_api_json: parsed dict from NativeReportDefinition or None
    """
    # Query all SfReport nodes for this org
    reports_query = """
        MATCH (r:SfReport)
        WHERE r.org_key = $org_key
        RETURN r.report_id AS report_id,
               r.name AS name,
               r.report_format AS report_format,
               r.report_type AS report_type,
               r.org_key AS org_key,
               r.folder_name AS folder_name,
               r.description AS description
    """
    report_rows = storage.execute_raw_query(reports_query, {"org_key": org_key}).rows

    if not report_rows:
        logger.info("No SfReport nodes found for org_key=%s", org_key)
        return []

    results: list[dict[str, Any]] = []

    for row in report_rows:
        report_id = row.get("report_id")
        if not report_id:
            continue

        # Fetch columns for this report
        columns = _fetch_columns(storage, org_key, report_id)

        # Fetch NativeReportDefinition JSON
        metadata_json = _fetch_native_definition(storage, org_key, report_id)

        results.append({
            "report_id": report_id,
            "name": row.get("name", ""),
            "report_format": row.get("report_format"),
            "report_type": row.get("report_type"),
            "org_key": org_key,
            "folder_name": row.get("folder_name"),
            "description": row.get("description"),
            "columns": columns,
            "metadata_api_json": metadata_json,
        })

    # Enrich each report with join field data from SF_REFERENCES edges
    for report_data in results:
        columns = report_data.get("columns") or []
        objects = list(dict.fromkeys(
            c["object_api_name"]
            for c in columns
            if c.get("object_api_name")
        ))
        if len(objects) > 1:
            report_data["join_fields"] = _fetch_join_fields(storage, org_key, objects)
        else:
            report_data["join_fields"] = {}

    logger.info(
        "Fetched %d reports from graph for org_key=%s (%d with metadata)",
        len(results),
        org_key,
        sum(1 for r in results if r["metadata_api_json"]),
    )
    return results


def _fetch_columns(
    storage: LineageStorage,
    org_key: str,
    report_id: str,
) -> list[dict[str, Any]]:
    """Fetch SfReportColumn nodes for a report."""
    query = """
        MATCH (r:SfReport)-[:SF_REPORT_HAS_COLUMN]->(c:SfReportColumn)
        WHERE r.org_key = $org_key AND r.report_id = $report_id
        RETURN c.column_key AS column_key,
               c.name AS name,
               c.data_type AS data_type,
               c.object_api_name AS object_api_name
    """
    rows = storage.execute_raw_query(query, {"org_key": org_key, "report_id": report_id}).rows
    return [
        {
            "column_key": r.get("column_key", ""),
            "name": r.get("name", ""),
            "data_type": r.get("data_type"),
            "object_api_name": r.get("object_api_name"),
        }
        for r in rows
    ]


def _fetch_join_fields(
    storage: LineageStorage,
    org_key: str,
    object_names: list[str],
) -> dict[tuple[str, str], str]:
    """Find FK fields between object pairs via SF_REFERENCES edges.

    Returns a mapping of ``(from_object, to_object) -> field_api_name``
    for lookup/master-detail relationships that exist between the given
    objects.  For example::

        {("Opportunity", "Account"): "AccountId"}

    Args:
        storage: Lineage storage backend.
        org_key: Salesforce org key.
        object_names: List of object API names to check.

    Returns:
        Dict mapping ``(from_obj, to_obj)`` to the FK field API name.
    """
    query = """
        MATCH (f:SfField)-[:SF_REFERENCES]->(o:SfObject)
        WHERE f.object_api_name IN $objects AND o.api_name IN $objects
          AND f.org_key = $org_key
        RETURN f.object_api_name AS from_obj,
               f.field_api_name AS field,
               o.api_name AS to_obj
    """
    rows = storage.execute_raw_query(
        query, {"objects": object_names, "org_key": org_key}
    ).rows

    result: dict[tuple[str, str], str] = {}
    for row in rows:
        from_obj = row.get("from_obj")
        to_obj = row.get("to_obj")
        field = row.get("field")
        if from_obj and to_obj and field:
            result[(from_obj, to_obj)] = field

    return result


def _fetch_native_definition(
    storage: LineageStorage,
    org_key: str,
    report_id: str,
) -> dict[str, Any] | None:
    """Fetch NativeReportDefinition JSON content for a report.

    The NativeReportDefinition is linked to the canonical Report node,
    whose ID is ``report::salesforce::{report_id}``.
    """
    canonical_report_id = f"report::salesforce::{report_id}"
    native_def_id = f"{canonical_report_id}.def.salesforce"

    query = """
        MATCH (d:NativeReportDefinition)
        WHERE d.id = $def_id
        RETURN d.content AS content
    """
    rows = storage.execute_raw_query(query, {"def_id": native_def_id}).rows

    if not rows:
        return None

    content = rows[0].get("content")
    if not content:
        return None

    try:
        return json.loads(content)
    except (json.JSONDecodeError, TypeError) as exc:
        logger.warning(
            "Failed to parse NativeReportDefinition JSON for %s: %s",
            report_id,
            exc,
        )
        return None
