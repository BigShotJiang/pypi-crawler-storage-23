"""Salesforce report loader — reference implementation.

Reads SfReport/SfReportColumn/NativeReportDefinition from the graph and
transforms them into Phase 1 + Phase 2 IR nodes using the generic
report loader framework.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Callable, Optional

from lineage.ingest.static_loaders.reports.base import (
    BaseReportLoader,
    ReportLoadResult,
    TransformResult,
    persist_transform_result,
)
from lineage.ingest.static_loaders.reports.factory import register_loader
from lineage.ingest.static_loaders.reports.salesforce.fetcher import (
    fetch_reports_from_graph,
)
from lineage.ingest.static_loaders.reports.salesforce.transformer import (
    SalesforceIRTransformer,
)

if TYPE_CHECKING:
    from lineage.backends.lineage.protocol import LineageStorage
    from lineage.ingest.static_loaders.reports.config import ReportSourceConfig

logger = logging.getLogger(__name__)


@register_loader("salesforce")
class SalesforceReportLoader(BaseReportLoader):
    """Loads Salesforce report IR from graph-stored metadata.

    This loader does NOT call the Salesforce API.  It reads SfReport +
    SfReportColumn + NativeReportDefinition nodes that were previously
    written by the SalesforceLoader, then transforms them into
    canonical Report, ReportIR, ReportIRField, and Phase 2 nodes.
    """

    def __init__(self, config: ReportSourceConfig) -> None:
        """Initialize with a report source configuration."""
        self.config = config
        self._transformer = SalesforceIRTransformer()

    async def fetch_reports(self, storage: LineageStorage) -> list[dict]:
        """Fetch report data from the lineage graph."""
        org_key = self.config.org_key
        if not org_key:
            raise ValueError(
                "SalesforceReportLoader requires 'org_key' in config"
            )
        return fetch_reports_from_graph(storage, org_key)

    def transform_to_ir(self, raw_data: dict) -> TransformResult:
        """Transform Salesforce report data to IR nodes."""
        return self._transformer.transform(raw_data)


# =============================================================================
# Convenience function (called by typedef_cli.py)
# =============================================================================


def generate_report_ir_from_graph(
    storage: LineageStorage,
    org_key: str,
    on_progress: Optional[Callable[[int, int, str], None]] = None,
) -> ReportLoadResult:
    """Generate Report IR nodes from SfReport data already in the graph.

    This is the main entry point called by ``typedef_cli.py`` during
    ``typedef sync``.  It runs synchronously (the internal loader is
    async but ``fetch_reports`` only reads from the graph).

    Args:
        storage: Lineage storage backend.
        org_key: Salesforce org key.
        on_progress: Optional callback (current, total, details).

    Returns:
        Statistics about what was loaded.
    """
    transformer = SalesforceIRTransformer()
    loader = _SyncSalesforceLoader(org_key=org_key, transformer=transformer)
    return loader.run(storage, on_progress)


class _SyncSalesforceLoader:
    """Synchronous wrapper that matches the typedef_cli calling convention."""

    def __init__(
        self,
        org_key: str,
        transformer: SalesforceIRTransformer,
    ) -> None:
        self.org_key = org_key
        self.transformer = transformer

    def run(
        self,
        storage: LineageStorage,
        on_progress: Optional[Callable[[int, int, str], None]] = None,
    ) -> ReportLoadResult:
        """Fetch, transform, and persist — all synchronous."""
        raw_reports = fetch_reports_from_graph(storage, self.org_key)
        result = ReportLoadResult()
        total = len(raw_reports)

        for i, raw_data in enumerate(raw_reports):
            report_name = raw_data.get("name", f"report_{i}")
            try:
                transform = self.transformer.transform(raw_data)
                persist_transform_result(storage, transform)

                result.reports_created += 1
                result.field_nodes_created += len(transform.fields)
                result.phase2_nodes_created += len(transform.ir_nodes)

            except Exception as exc:
                msg = f"Failed to transform {report_name}: {exc}"
                logger.warning(msg)
                result.errors.append(msg)

            if on_progress:
                on_progress(i + 1, total, report_name)

        logger.info(
            "Report IR generation complete: %d reports, %d fields, %d phase2 nodes, %d errors",
            result.reports_created,
            result.field_nodes_created,
            result.phase2_nodes_created,
            len(result.errors),
        )
        return result
