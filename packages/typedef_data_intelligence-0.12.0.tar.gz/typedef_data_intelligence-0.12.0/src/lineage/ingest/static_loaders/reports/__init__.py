"""Cross-platform BI report loading framework.

Provides a plugin-based architecture for loading reports from
different BI platforms (Salesforce, Looker, Tableau, PowerBI)
into the Generic Report Schema.
"""
# Auto-import platform submodules so @register_loader decorators run
import lineage.ingest.static_loaders.reports.salesforce  # noqa: F401
from lineage.ingest.static_loaders.reports.base import (
    BaseReportLoader,
    ReportLoadResult,
    TransformResult,
)
from lineage.ingest.static_loaders.reports.config import (
    ReportLoadersConfig,
    ReportSourceConfig,
)
from lineage.ingest.static_loaders.reports.factory import (
    ReportLoaderFactory,
    register_loader,
)

__all__ = [
    "BaseReportLoader",
    "ReportLoadResult",
    "ReportLoaderFactory",
    "ReportLoadersConfig",
    "ReportSourceConfig",
    "TransformResult",
    "register_loader",
]
