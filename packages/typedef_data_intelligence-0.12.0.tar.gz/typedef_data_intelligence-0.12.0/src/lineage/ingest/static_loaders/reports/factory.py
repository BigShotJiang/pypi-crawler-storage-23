"""Report loader factory with decorator-based registration."""
from __future__ import annotations

import logging
from typing import Callable, Type

from lineage.ingest.static_loaders.reports.base import BaseReportLoader
from lineage.ingest.static_loaders.reports.config import ReportSourceConfig

logger = logging.getLogger(__name__)

# Global registry: system name -> loader class
_REGISTRY: dict[str, Type[BaseReportLoader]] = {}


def register_loader(system: str) -> Callable[[Type[BaseReportLoader]], Type[BaseReportLoader]]:
    """Decorator that registers a loader class for a BI platform.

    Usage::

        @register_loader("salesforce")
        class SalesforceReportLoader(BaseReportLoader):
            ...
    """
    def decorator(cls: Type[BaseReportLoader]) -> Type[BaseReportLoader]:
        if system in _REGISTRY:
            logger.warning(
                "Overwriting loader for '%s': %s -> %s",
                system,
                _REGISTRY[system].__name__,
                cls.__name__,
            )
        _REGISTRY[system] = cls
        return cls

    return decorator


class ReportLoaderFactory:
    """Creates platform-specific report loaders from configuration."""

    @staticmethod
    def create(config: ReportSourceConfig) -> BaseReportLoader:
        """Create a loader for the given source configuration.

        Args:
            config: Source configuration with ``system`` identifying the platform.

        Returns:
            Instantiated loader.

        Raises:
            ValueError: If no loader is registered for the system.
        """
        cls = _REGISTRY.get(config.system)
        if cls is None:
            available = ", ".join(sorted(_REGISTRY.keys())) or "(none)"
            raise ValueError(
                f"No report loader registered for '{config.system}'. "
                f"Available: {available}"
            )
        return cls(config)

    @staticmethod
    def available_systems() -> list[str]:
        """Return list of registered system names."""
        return sorted(_REGISTRY.keys())
