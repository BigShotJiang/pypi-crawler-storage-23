"""Salesforce report loader — reference Phase 2 implementation."""
# Import loader to trigger @register_loader side effect
from lineage.ingest.static_loaders.reports.salesforce.loader import (  # noqa: F401
    SalesforceReportLoader,
    generate_report_ir_from_graph,
)
