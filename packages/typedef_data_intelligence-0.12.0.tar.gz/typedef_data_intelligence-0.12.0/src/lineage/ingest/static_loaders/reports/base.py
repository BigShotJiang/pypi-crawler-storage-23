"""Core framework for cross-platform BI report loading.

Defines:
- TransformResult: dataclass holding all nodes for a single report
- ReportLoadResult: statistics dataclass
- BaseReportLoader: ABC with template method pattern
- Edge auto-discovery registry for Phase 2 IR child nodes
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Callable, Optional

from lineage.backends.lineage.models.base import BaseNode, GraphEdge, NodeIdentifier
from lineage.backends.lineage.models.edges import (
    HasIR,
    HasIRBucket,
    HasIRCrossFilter,
    HasIRField,
    HasIRFilter,
    HasIRFormula,
    HasIRGroupBy,
    HasIRHighlight,
    HasIRJoin,
    HasNativeDefinition,
    NativeInstanceOf,
)
from lineage.backends.lineage.models.report import (
    NativeReportDefinition,
    Report,
    ReportIR,
    ReportIRBucket,
    ReportIRCrossFilter,
    ReportIRField,
    ReportIRFilter,
    ReportIRFormula,
    ReportIRGroupBy,
    ReportIRHighlight,
    ReportIRJoin,
)

if TYPE_CHECKING:
    from lineage.backends.lineage.protocol import LineageStorage

logger = logging.getLogger(__name__)


# =============================================================================
# Edge auto-discovery registry
# =============================================================================

# Maps Phase 2 node type -> HAS_IR_* edge class.
# Built from edge classes where from_type is ReportIR.
_IR_CHILD_EDGE_MAP: dict[type[BaseNode], type[GraphEdge]] = {
    ReportIRFilter: HasIRFilter,
    ReportIRJoin: HasIRJoin,
    ReportIRGroupBy: HasIRGroupBy,
    ReportIRBucket: HasIRBucket,
    ReportIRFormula: HasIRFormula,
    ReportIRHighlight: HasIRHighlight,
    ReportIRCrossFilter: HasIRCrossFilter,
}


# =============================================================================
# TransformResult
# =============================================================================


@dataclass
class TransformResult:
    """All nodes produced by transforming a single report.

    This is the contract between platform-specific transformers and the
    shared persistence logic in BaseReportLoader._persist().

    Phase 1 nodes are explicit typed fields.
    Phase 2 nodes go in the generic ``ir_nodes`` list — the correct
    HAS_IR_* edge type is auto-discovered from ``_IR_CHILD_EDGE_MAP``.
    """

    # Phase 1 (shared across all platforms)
    report: Report
    ir: ReportIR
    fields: list[ReportIRField] = field(default_factory=list)
    native_node: BaseNode | None = None  # SfReport, LookerLook, etc.
    native_definition: NativeReportDefinition | None = None

    # Phase 2 (generic — any mix of IR child nodes)
    ir_nodes: list[BaseNode] = field(default_factory=list)

    # Cross-stitching edges (e.g. ReportIRField → SfReportColumn)
    extra_edges: list[tuple[BaseNode | NodeIdentifier, BaseNode | NodeIdentifier, GraphEdge]] = field(default_factory=list)


# =============================================================================
# ReportLoadResult
# =============================================================================


@dataclass
class ReportLoadResult:
    """Statistics from a report loading run."""

    reports_created: int = 0
    field_nodes_created: int = 0
    phase2_nodes_created: int = 0
    errors: list[str] = field(default_factory=list)


# =============================================================================
# BaseReportLoader
# =============================================================================


class BaseReportLoader(ABC):
    """Abstract base for platform-specific report loaders.

    Follows a template method pattern:
    ``load()`` orchestrates fetch → transform → persist.
    Subclasses implement ``fetch_reports()`` and ``transform_to_ir()``.
    """

    @abstractmethod
    async def fetch_reports(
        self,
        storage: LineageStorage,
    ) -> list[dict]:
        """Fetch raw report data from the BI platform or graph.

        Returns a list of dicts, each containing platform-specific data
        needed by ``transform_to_ir()``.
        """

    @abstractmethod
    def transform_to_ir(self, raw_data: dict) -> TransformResult:
        """Transform a single report's raw data into IR nodes.

        Returns a ``TransformResult`` with all Phase 1 + Phase 2 nodes.
        """

    async def load(
        self,
        storage: LineageStorage,
        on_progress: Optional[Callable[[int, int, str], None]] = None,
    ) -> ReportLoadResult:
        """Template method: fetch → transform → persist.

        Args:
            storage: Lineage storage backend.
            on_progress: Optional callback (current, total, details).

        Returns:
            Statistics about what was loaded.
        """
        result = ReportLoadResult()

        raw_reports = await self.fetch_reports(storage)
        total = len(raw_reports)

        for i, raw_data in enumerate(raw_reports):
            report_name = raw_data.get("name", f"report_{i}")
            try:
                transform = self.transform_to_ir(raw_data)
                self._persist(storage, transform)

                result.reports_created += 1
                result.field_nodes_created += len(transform.fields)
                result.phase2_nodes_created += len(transform.ir_nodes)

            except Exception as exc:
                msg = f"Failed to transform {report_name}: {exc}"
                logger.warning(msg)
                result.errors.append(msg)

            if on_progress:
                on_progress(i + 1, total, report_name)

        return result

    def _persist(self, storage: LineageStorage, result: TransformResult) -> None:
        """Persist a TransformResult to storage using bulk_load()."""
        persist_transform_result(storage, result)


# =============================================================================
# Standalone persistence function
# =============================================================================


def persist_transform_result(storage: LineageStorage, result: TransformResult) -> None:
    """Persist a TransformResult to storage using bulk_load().

    Collects all nodes and edges from the TransformResult, then
    writes them in one batch.  Called by both ``BaseReportLoader._persist``
    and the synchronous ``generate_report_ir_from_graph`` wrapper.
    """
    nodes: list[BaseNode] = []
    edges: list[tuple[BaseNode | NodeIdentifier, BaseNode | NodeIdentifier, GraphEdge]] = []

    # -- Phase 1: canonical spine ---------------------------------------------
    report = result.report
    ir = result.ir

    nodes.append(report)
    nodes.append(ir)

    # Report -> ReportIR
    edges.append((report, ir, HasIR()))

    # ReportIR -> ReportIRField
    for idx, fld in enumerate(result.fields):
        nodes.append(fld)
        edges.append((ir, fld, HasIRField(sequence=idx)))

    # Native node -> Report (NATIVE_INSTANCE_OF)
    if result.native_node is not None:
        # Don't re-upsert the native node (it already exists in graph)
        # but do create the edge
        edges.append((
            result.native_node.get_node_identifier(),
            report,
            NativeInstanceOf(),
        ))

    # Report -> NativeReportDefinition
    # Use NodeIdentifier to create the edge without overwriting content
    # that was already stored by the native loader (e.g. Metadata API JSON).
    if result.native_definition is not None:
        edges.append((
            report,
            result.native_definition.get_node_identifier(),
            HasNativeDefinition(),
        ))

    # -- Phase 2: IR child nodes ----------------------------------------------
    ir_identifier = ir.get_node_identifier()
    for node in result.ir_nodes:
        node_type = type(node)
        edge_cls = _IR_CHILD_EDGE_MAP.get(node_type)
        if edge_cls is None:
            logger.warning(
                "No HAS_IR_* edge registered for %s — skipping",
                node_type.__name__,
            )
            continue

        nodes.append(node)

        # Build edge kwargs (some edges accept sequence)
        edge_kwargs: dict = {}
        if hasattr(node, "index") and hasattr(edge_cls, "model_fields"):
            if "sequence" in edge_cls.model_fields:
                edge_kwargs["sequence"] = getattr(node, "index", None)

        edges.append((ir_identifier, node, edge_cls(**edge_kwargs)))

    # -- Cross-stitching edges (e.g. ReportIRField → SfReportColumn) ----------
    edges.extend(result.extra_edges)

    # -- Bulk write ------------------------------------------------------------
    storage.bulk_load(nodes, edges)
