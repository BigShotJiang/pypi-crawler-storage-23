"""Salesforce Metadata API JSON to Report IR transformation.

Transforms SfReport data + NativeReportDefinition JSON into a
TransformResult containing Phase 1 and Phase 2 IR nodes.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any

from lineage.backends.lineage.models.base import BaseNode, GraphEdge, NodeIdentifier
from lineage.backends.lineage.models.edges import HighlightsFormula, MapsToNativeField
from lineage.backends.lineage.models.report import (
    NativeReportDefinition,
    Report,
    ReportIR,
    ReportIRBucket,
    ReportIRCrossFilter,
    ReportIRField,
    ReportIRFilter,
    ReportIRFormula,
    ReportIRGroupBy,
    ReportIRHighlight,
    ReportIRJoin,
)
from lineage.backends.lineage.models.salesforce import SfReport, SfReportColumn
from lineage.formula import FormulaParseError, extract_field_refs
from lineage.formula import parse as parse_formula
from lineage.ingest.static_loaders.reports.base import TransformResult

logger = logging.getLogger(__name__)

# Salesforce data types → IR field_type classification
_MEASURE_TYPES = frozenset({
    "currency", "double", "int", "percent", "number",
})
_TIME_TYPES = frozenset({
    "date", "datetime", "time",
})


def _ensure_list(value: Any) -> list:
    """Normalize Metadata API values that may be a single dict or a list."""
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _classify_field_type(data_type: str | None) -> str:
    """Classify Salesforce data type into IR field_type."""
    if not data_type:
        return "dimension"
    dt_lower = data_type.lower()
    if dt_lower in _MEASURE_TYPES:
        return "measure"
    if dt_lower in _TIME_TYPES:
        return "time"
    return "dimension"


def _classify_role(field_type: str) -> str:
    """Infer field role from field_type."""
    if field_type == "measure":
        return "aggregation"
    if field_type == "time":
        return "grouping"
    return "display"


def _column_key_from_field_ref(ref) -> str:
    """Convert a FieldRef to the column_key used in SfReportColumn IDs.

    - ``AMOUNT`` → ``"AMOUNT"`` (plain field)
    - ``AMOUNT:SUM`` → ``"AMOUNT"`` (strip aggregation suffix)
    - ``Account.Name`` → ``"Account.Name"`` (object path, no aggregation)
    """
    if ref.aggregation and ":" in ref.raw:
        return ref.raw.split(":", 1)[0]
    return ref.raw


class SalesforceIRTransformer:
    """Transforms Salesforce report data into Report IR nodes.

    Consumes the dict produced by ``fetch_reports_from_graph()``
    and returns a ``TransformResult`` with all Phase 1 + Phase 2 nodes.
    """

    def transform(self, report_data: dict[str, Any]) -> TransformResult:
        """Transform a single report's data into IR nodes.

        Args:
            report_data: Dict with keys: report_id, name, report_format,
                report_type, org_key, columns, metadata_api_json.

        Returns:
            TransformResult with all nodes populated.
        """
        report_id = report_data["report_id"]
        org_key = report_data["org_key"]
        name = report_data.get("name", "")
        report_format = report_data.get("report_format")
        report_type = report_data.get("report_type")
        metadata = report_data.get("metadata_api_json") or {}
        columns = report_data.get("columns") or []

        # -- Phase 1: canonical spine ----------------------------------------
        report = Report(
            name=name,
            system="salesforce",
            native_id=report_id,
            title=name,
            description=report_data.get("description"),
            folder=report_data.get("folder_name"),
            status="published",
        )

        ir = ReportIR(
            name=f"{name} IR",
            report_id=report.id,
            report_format=report_format,
            base_entity=report_type,
        )

        # Phase 1: fields from SfReportColumn data
        fields = self._build_fields(ir.id, columns, metadata)

        # Native node reference (SfReport already exists in graph)
        native_node = SfReport(
            name=name,
            report_id=report_id,
            org_key=org_key,
            report_format=report_format,
            report_type=report_type,
        )

        # -- Phase 2: from Metadata API JSON ----------------------------------
        ir_nodes: list[BaseNode] = []

        if metadata:
            ir_nodes.extend(self._extract_filters(ir.id, metadata))
            groupings = self._extract_groupings(ir.id, metadata)
            ir_nodes.extend(groupings)
            ir_nodes.extend(self._extract_buckets(ir.id, metadata))
            ir_nodes.extend(self._extract_formulas(ir.id, metadata))
            ir_nodes.extend(self._extract_highlights(ir.id, metadata))
            ir_nodes.extend(self._extract_cross_filters(ir.id, metadata))

            # Back-populate field granularity from groupings
            field_by_alias = {f.alias: f for f in fields}
            for g in groupings:
                if g.date_granularity and g.field_alias in field_by_alias:
                    field_by_alias[g.field_alias].granularity = g.date_granularity

        # Joins are derived from column objects + graph FK data, not metadata
        join_fields = report_data.get("join_fields") or {}
        ir_nodes.extend(self._extract_joins(ir.id, columns, join_fields))

        # -- Build case-insensitive set of known column keys for this report --
        known_col_keys: dict[str, str] = {}
        for col in columns:
            ck = col.get("column_key", "")
            if ck:
                known_col_keys[ck.lower()] = ck

        # -- Cross-stitching: ReportIRField → SfReportColumn ------------------
        extra_edges: list[tuple[BaseNode | NodeIdentifier, BaseNode | NodeIdentifier, GraphEdge]] = []
        for fld in fields:
            col_key = fld.alias  # alias == column_key
            sf_col_id = f"sf_report_col::{org_key}::{report_id}::{col_key}"
            target = NodeIdentifier(
                id=sf_col_id,
                node_label=SfReportColumn.node_label,
            )
            extra_edges.append((fld, target, MapsToNativeField(mapping_type="exact", confidence=1.0)))

        # -- Cross-stitching: Phase 2 GroupBy/Filter/Bucket → SfReportColumn --
        for node in ir_nodes:
            field_ref: str | None = None
            if isinstance(node, ReportIRGroupBy):
                field_ref = node.field_alias
            elif isinstance(node, ReportIRFilter):
                field_ref = node.field_ref
            elif isinstance(node, ReportIRBucket):
                field_ref = node.source_field

            if not field_ref:
                continue
            # Skip synthetic refs (formulas, bucket fields, age calculations, system vars)
            if (
                field_ref.startswith("BucketField_")
                or field_ref.startswith("FORMULA")
                or field_ref.startswith("Age_")
                or field_ref.startswith("$")
            ):
                continue
            # Only stitch to columns known to exist in this report
            if field_ref.lower() not in known_col_keys:
                continue

            matched_key = known_col_keys[field_ref.lower()]
            sf_col_id = f"sf_report_col::{org_key}::{report_id}::{matched_key}"
            target = NodeIdentifier(
                id=sf_col_id,
                node_label=SfReportColumn.node_label,
            )
            extra_edges.append((
                node, target,
                MapsToNativeField(mapping_type="auxiliary", confidence=1.0),
            ))

        # -- Cross-stitching: ReportIRFormula → SfReportColumn -----------------
        for node in ir_nodes:
            if not isinstance(node, ReportIRFormula):
                continue
            if not node.expression:
                continue
            try:
                tree = parse_formula(node.expression)
                refs = extract_field_refs(tree)
            except FormulaParseError:
                logger.warning(
                    "Could not parse formula expression for %s: %s",
                    node.formula_name, node.expression,
                )
                continue
            except Exception:
                logger.warning(
                    "Unexpected error parsing formula %s",
                    node.formula_name, exc_info=True,
                )
                continue

            seen_keys: set[str] = set()
            for ref in refs:
                col_key = _column_key_from_field_ref(ref)
                if col_key in seen_keys:
                    continue
                seen_keys.add(col_key)
                # Skip system variables ($System.*, $User.*, etc.)
                if col_key.startswith("$"):
                    continue
                # Only stitch to columns known to exist in this report
                matched = known_col_keys.get(col_key.lower())
                if not matched:
                    continue
                sf_col_id = f"sf_report_col::{org_key}::{report_id}::{matched}"
                target = NodeIdentifier(
                    id=sf_col_id,
                    node_label=SfReportColumn.node_label,
                )
                extra_edges.append((
                    node, target,
                    MapsToNativeField(mapping_type="computed", confidence=1.0),
                ))

        # -- Cross-stitching: ReportIRJoin → SfReportColumn --------------------
        # Build a case-insensitive lookup of column keys present in the report
        col_key_set: dict[str, str] = {}
        for col in columns:
            ck = col.get("column_key", "")
            if ck:
                col_key_set[ck.lower()] = ck

        def _match_fk_column(field_name: str) -> str | None:
            """Match a FK field name against report columns (case-insensitive)."""
            if not field_name or field_name == "Id":
                return None
            key = col_key_set.get(field_name.lower())
            if key:
                return key
            # Try underscore-separated form: AccountId → ACCOUNT_ID
            snake = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", "_", field_name).upper()
            return col_key_set.get(snake.lower())

        for node in ir_nodes:
            if not isinstance(node, ReportIRJoin):
                continue
            if not node.from_field and not node.to_field:
                continue
            # Try from_field first, then to_field (for reverse lookups where from_field="Id")
            matched_key = _match_fk_column(node.from_field) or _match_fk_column(node.to_field)
            if matched_key:
                sf_col_id = f"sf_report_col::{org_key}::{report_id}::{matched_key}"
                target = NodeIdentifier(
                    id=sf_col_id,
                    node_label=SfReportColumn.node_label,
                )
                extra_edges.append((
                    node, target,
                    MapsToNativeField(mapping_type="join_key", confidence=1.0),
                ))

        # -- Cross-stitching: ReportIRHighlight → SfReportColumn or ReportIRFormula --
        for node in ir_nodes:
            if not isinstance(node, ReportIRHighlight):
                continue
            if not node.field_alias:
                continue
            if node.field_alias.startswith("FORMULA"):
                # Link to the ReportIRFormula node with matching formula_name
                formula_id = f"{ir.id}.formula.{node.field_alias}"
                target = NodeIdentifier(id=formula_id, node_label=ReportIRFormula.node_label)
                extra_edges.append((node, target, HighlightsFormula()))
            else:
                # Regular field — link to SfReportColumn
                sf_col_id = f"sf_report_col::{org_key}::{report_id}::{node.field_alias}"
                target = NodeIdentifier(id=sf_col_id, node_label=SfReportColumn.node_label)
                extra_edges.append((node, target, MapsToNativeField(mapping_type="auxiliary", confidence=1.0)))

        # -- Cross-stitching: ReportIRCrossFilter → SfReportColumn --
        for node in ir_nodes:
            if not isinstance(node, ReportIRCrossFilter):
                continue
            refs_to_stitch: list[str] = []
            if node.related_field:
                refs_to_stitch.append(node.related_field)
            if node.filter_conditions:
                try:
                    criteria = json.loads(node.filter_conditions)
                    for item in criteria:
                        col = item.get("column", "")
                        if col:
                            refs_to_stitch.append(col)
                except (json.JSONDecodeError, TypeError):
                    pass
            for ref in refs_to_stitch:
                if ref.startswith("$"):
                    continue
                # Cross-filter fields reference the related entity, not report
                # columns, so we skip the known-column check here.
                sf_col_id = f"sf_report_col::{org_key}::{report_id}::{ref}"
                target = NodeIdentifier(id=sf_col_id, node_label=SfReportColumn.node_label)
                extra_edges.append((node, target, MapsToNativeField(mapping_type="auxiliary", confidence=1.0)))

        return TransformResult(
            report=report,
            ir=ir,
            fields=fields,
            native_node=native_node,
            native_definition=NativeReportDefinition(
                name=f"{name} Definition",
                report_id=report.id,
                system="salesforce",
            ),
            ir_nodes=ir_nodes,
            extra_edges=extra_edges,
        )

    # -------------------------------------------------------------------------
    # Phase 1: field extraction
    # -------------------------------------------------------------------------

    def _build_fields(
        self,
        ir_id: str,
        columns: list[dict[str, Any]],
        metadata: dict[str, Any] | None = None,
    ) -> list[ReportIRField]:
        """Build ReportIRField nodes from SfReportColumn data."""
        # Build aggregation lookup from Metadata API columns
        agg_lookup: dict[str, str] = {}
        if metadata:
            for mc in _ensure_list(metadata.get("columns")):
                if isinstance(mc, dict):
                    field_ref = mc.get("field", "")
                    agg_types = mc.get("aggregateTypes")
                    if field_ref and agg_types:
                        # aggregateTypes is a list (e.g. ["Sum"]); join for storage
                        if isinstance(agg_types, list):
                            agg_lookup[field_ref] = ",".join(str(a) for a in agg_types)
                        else:
                            agg_lookup[field_ref] = str(agg_types)

        fields: list[ReportIRField] = []
        for col in columns:
            column_key = col.get("column_key", "")
            if not column_key:
                continue

            data_type = col.get("data_type")
            field_type = _classify_field_type(data_type)
            role = _classify_role(field_type)

            # Use column name or column_key as display name
            col_name = col.get("name") or column_key

            # Look up aggregation from Metadata API
            aggregation = agg_lookup.get(column_key)

            field = ReportIRField(
                name=col_name,
                ir_id=ir_id,
                alias=column_key,
                field_type=field_type,
                role=role,
                ref_type="native",
                ref_entity=col.get("object_api_name"),
                ref_field=column_key,
                aggregation=aggregation,
            )
            fields.append(field)
        return fields

    # -------------------------------------------------------------------------
    # Phase 2: Metadata API extraction methods
    # -------------------------------------------------------------------------

    def _extract_filters(
        self,
        ir_id: str,
        metadata: dict[str, Any],
    ) -> list[ReportIRFilter]:
        """Extract ReportIRFilter nodes from Metadata API ``filter`` field.

        Salesforce Metadata API stores filters as::

            { "filter": {
                "booleanFilter": "1 AND 2",
                "criteriaItems": [ { "column": ..., "operator": ..., "value": ... } ],
                "language": "en_US"
              }
            }

        Individual criteria are inside ``filter.criteriaItems``.
        """
        filter_obj = metadata.get("filter")
        if isinstance(filter_obj, dict):
            raw_criteria = _ensure_list(filter_obj.get("criteriaItems"))
        else:
            raw_criteria = _ensure_list(filter_obj)

        nodes: list[ReportIRFilter] = []
        for idx, f in enumerate(raw_criteria):
            if not isinstance(f, dict):
                continue
            column = f.get("column", "")
            nodes.append(ReportIRFilter(
                name=f"Filter: {column}" if column else f"Filter {idx}",
                ir_id=ir_id,
                index=idx,
                field_ref=column,
                operator=f.get("operator"),
                value=f.get("value"),
                value_type="literal",
                is_runtime=bool(f.get("isUnlocked", False)),
            ))
        return nodes

    def _extract_groupings(
        self,
        ir_id: str,
        metadata: dict[str, Any],
    ) -> list[ReportIRGroupBy]:
        """Extract ReportIRGroupBy from ``groupingsDown`` and ``groupingsAcross``."""
        nodes: list[ReportIRGroupBy] = []

        for axis, key in [("row", "groupingsDown"), ("column", "groupingsAcross")]:
            raw = _ensure_list(metadata.get(key))
            for seq, g in enumerate(raw):
                if not isinstance(g, dict):
                    continue

                field_name = g.get("field") or g.get("name") or ""
                if not field_name:
                    continue

                sort_order = g.get("sortOrder")
                if sort_order:
                    sort_order = sort_order.lower()

                date_gran = g.get("dateGranularity")
                if date_gran:
                    date_gran = date_gran.lower()

                nodes.append(ReportIRGroupBy(
                    name=f"Group: {field_name}",
                    ir_id=ir_id,
                    field_alias=field_name,
                    axis=axis,
                    sequence=seq,
                    sort_order=sort_order,
                    date_granularity=date_gran or None,
                ))
        return nodes

    def _extract_buckets(
        self,
        ir_id: str,
        metadata: dict[str, Any],
    ) -> list[ReportIRBucket]:
        """Extract ReportIRBucket from ``buckets`` (or ``bucketColumns``)."""
        raw = _ensure_list(metadata.get("buckets") or metadata.get("bucketColumns"))
        nodes: list[ReportIRBucket] = []
        for b in raw:
            if not isinstance(b, dict):
                continue

            label = b.get("masterLabel") or b.get("label") or b.get("developerName") or ""
            source = b.get("sourceColumnName") or ""
            bucket_type_raw = b.get("bucketType", "")
            # Normalize bucket type
            bt = bucket_type_raw.lower() if bucket_type_raw else ""
            if "number" in bt or "numeric" in bt:
                bucket_type = "numeric_range"
            elif "picklist" in bt:
                bucket_type = "picklist"
            else:
                bucket_type = "text_pattern"

            # Serialize ranges/values
            values = b.get("values")
            ranges_json = json.dumps(values, default=str) if values else None

            other_bucket = bool(b.get("useOther", False) or b.get("includeOther", False) or b.get("nullTreatment") == "i")

            nodes.append(ReportIRBucket(
                name=f"Bucket: {label}" if label else f"Bucket: {source}",
                ir_id=ir_id,
                bucket_name=label or source,
                source_field=source,
                bucket_type=bucket_type,
                ranges=ranges_json,
                other_bucket=other_bucket,
            ))
        return nodes

    def _extract_formulas(
        self,
        ir_id: str,
        metadata: dict[str, Any],
    ) -> list[ReportIRFormula]:
        """Extract ReportIRFormula from ``customDetailFormulas`` and ``aggregates``.

        Salesforce Metadata API field mapping:

        customDetailFormulas (row-level):
            label, developerName, calculatedFormula, dataType (capital T), scale

        aggregates (summary):
            masterLabel, developerName, calculatedFormula, datatype (lowercase t), scale
        """
        nodes: list[ReportIRFormula] = []

        # Row-level formulas (customDetailFormulas)
        for f in _ensure_list(metadata.get("customDetailFormulas")):
            if not isinstance(f, dict):
                continue
            name = f.get("label") or f.get("developerName") or f.get("description") or ""
            formula_name = f.get("developerName") or name
            nodes.append(ReportIRFormula(
                name=f"Formula: {name}" if name else "Formula",
                ir_id=ir_id,
                formula_name=formula_name,
                formula_type="row",
                expression=f.get("calculatedFormula") or f.get("formula"),
                return_type=self._sf_type_to_return_type(
                    f.get("dataType") or f.get("datatype")
                ),
                decimal_places=f.get("scale") or f.get("decimalPlaces"),
                description=f.get("description"),
            ))

        # Summary formulas (aggregates)
        for f in _ensure_list(metadata.get("aggregates")):
            if not isinstance(f, dict):
                continue
            name = (
                f.get("masterLabel") or f.get("label")
                or f.get("developerName") or ""
            )
            formula_name = f.get("developerName") or name
            nodes.append(ReportIRFormula(
                name=f"Summary: {name}" if name else "Summary Formula",
                ir_id=ir_id,
                formula_name=formula_name,
                formula_type="summary",
                expression=f.get("calculatedFormula") or f.get("formula"),
                return_type=self._sf_type_to_return_type(
                    f.get("datatype") or f.get("dataType")
                ),
                decimal_places=f.get("scale") or f.get("decimalPlaces"),
                description=f.get("description"),
            ))

        return nodes

    def _extract_highlights(
        self,
        ir_id: str,
        metadata: dict[str, Any],
    ) -> list[ReportIRHighlight]:
        """Extract ReportIRHighlight from ``colorRanges``."""
        raw = _ensure_list(metadata.get("colorRanges"))
        nodes: list[ReportIRHighlight] = []
        for idx, cr in enumerate(raw):
            if not isinstance(cr, dict):
                continue

            column_name = cr.get("columnName", "")

            # Parse color and breakpoint fields
            low_color = cr.get("lowColor")
            mid_color = cr.get("midColor")
            high_color = cr.get("highColor")

            # Breakpoints
            low_bp = cr.get("lowBreakpoint")
            high_bp = cr.get("highBreakpoint")

            nodes.append(ReportIRHighlight(
                name=f"Highlight: {column_name}" if column_name else f"Highlight {idx}",
                ir_id=ir_id,
                index=idx,
                field_alias=column_name or None,
                low_color=low_color,
                mid_color=mid_color,
                high_color=high_color,
                low_breakpoint=float(low_bp) if low_bp is not None else None,
                high_breakpoint=float(high_bp) if high_bp is not None else None,
            ))
        return nodes

    def _extract_cross_filters(
        self,
        ir_id: str,
        metadata: dict[str, Any],
    ) -> list[ReportIRCrossFilter]:
        """Extract ReportIRCrossFilter from ``crossFilters``."""
        raw = _ensure_list(metadata.get("crossFilters"))
        nodes: list[ReportIRCrossFilter] = []
        for idx, cf in enumerate(raw):
            if not isinstance(cf, dict):
                continue

            # operation: "with" or "without"
            operation = cf.get("operation", "")
            mode = operation.lower() if operation else None

            related_entity = cf.get("relatedEntity")
            related_field = cf.get("relatedEntityJoinField")

            # Additional criteria on the related entity
            criteria = _ensure_list(cf.get("criteriaItems"))
            conditions_json = json.dumps(criteria, default=str) if criteria else None

            nodes.append(ReportIRCrossFilter(
                name=f"CrossFilter: {mode or ''} {related_entity or ''}".strip(),
                ir_id=ir_id,
                index=idx,
                mode=mode,
                related_entity=related_entity,
                related_field=related_field,
                filter_conditions=conditions_json,
            ))
        return nodes

    def _extract_joins(
        self,
        ir_id: str,
        columns: list[dict[str, Any]],
        join_fields: dict[tuple[str, str], str],
    ) -> list[ReportIRJoin]:
        """Extract ReportIRJoin from objects referenced by report columns.

        Collects distinct ``object_api_name`` values from the column list.
        The first object seen is treated as the primary entity; subsequent
        objects are joined to it.  ``join_fields`` (populated by
        ``_fetch_join_fields`` in the fetcher) supplies the FK field
        between each pair via SF_REFERENCES edges.

        For Salesforce FKs the ``to_field`` is always ``Id``.
        """
        nodes: list[ReportIRJoin] = []

        # Collect distinct objects in encounter order
        objects_seen: list[str] = []
        for col in columns:
            obj = col.get("object_api_name")
            if obj and obj not in objects_seen:
                objects_seen.append(obj)

        if len(objects_seen) <= 1:
            return nodes

        primary = objects_seen[0]
        for idx, related in enumerate(objects_seen[1:]):
            from_field: str | None = None
            to_field: str | None = None

            # Forward lookup: primary has FK pointing to related
            fk = join_fields.get((primary, related))
            if fk:
                from_field = fk
                to_field = "Id"
            else:
                # Reverse: related has FK pointing to primary
                rev_fk = join_fields.get((related, primary))
                if rev_fk:
                    from_field = "Id"
                    to_field = rev_fk

            nodes.append(ReportIRJoin(
                name=f"Join: {primary} -> {related}",
                ir_id=ir_id,
                index=idx,
                from_entity=primary,
                to_entity=related,
                from_field=from_field,
                to_field=to_field,
                join_type="left",
                relationship="many_to_one",
            ))

        return nodes

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    @staticmethod
    def _sf_type_to_return_type(sf_type: str | None) -> str | None:
        """Map Salesforce formula data type to IR return type."""
        if not sf_type:
            return None
        t = sf_type.lower()
        if t in ("currency", "double", "int", "number"):
            return "number"
        if t == "percent":
            return "percent"
        if t in ("date", "datetime"):
            return "date"
        return "text"
