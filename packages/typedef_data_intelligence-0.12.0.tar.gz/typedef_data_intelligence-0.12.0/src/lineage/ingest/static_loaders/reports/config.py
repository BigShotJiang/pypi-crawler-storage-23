"""Configuration models for cross-platform BI report loading."""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class ReportSourceConfig(BaseModel):
    """Per-source configuration for a BI platform report loader.

    Each entry describes one BI system to load reports from.
    """

    system: str = Field(description="BI platform identifier (salesforce, looker, tableau, powerbi)")
    enabled: bool = Field(default=True, description="Whether this source is active")
    max_concurrent: int = Field(default=4, ge=1, le=32, description="Max parallel fetches")

    # Salesforce-specific (ignored by other loaders)
    org_key: Optional[str] = Field(default=None, description="Salesforce org key for graph lookups")
    instance_url: Optional[str] = Field(default=None, description="Salesforce instance URL")
    access_token: Optional[str] = Field(default=None, description="Salesforce access token")

    # Generic filters
    folder_filter: Optional[str] = Field(default=None, description="Glob pattern for report folders")
    name_pattern: Optional[str] = Field(default=None, description="Regex pattern for report names")


class ReportLoadersConfig(BaseModel):
    """Top-level configuration for cross-platform BI report loading."""

    sources: list[ReportSourceConfig] = Field(
        default_factory=list,
        description="List of BI platform sources to load reports from",
    )
    resolve_lineage: bool = Field(
        default=True,
        description="Resolve field lineage to upstream models/columns",
    )
    store_native_definition: bool = Field(
        default=True,
        description="Store raw vendor report definitions as NativeReportDefinition nodes",
    )
