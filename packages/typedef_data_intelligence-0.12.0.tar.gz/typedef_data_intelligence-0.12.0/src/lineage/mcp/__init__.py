"""Unified MCP server for the Data Intelligence platform."""
