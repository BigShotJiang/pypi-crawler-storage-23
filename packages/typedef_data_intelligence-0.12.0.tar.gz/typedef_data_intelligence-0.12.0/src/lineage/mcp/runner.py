"""CLI runner for the unified Data Intelligence MCP server."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

from lineage.backends.config import UnifiedConfig
from lineage.backends.data_query.factory import create_data_backend_for_cli
from lineage.backends.lineage.factory import create_storage_for_cli
from lineage.mcp.server import create_unified_server

logger = logging.getLogger(__name__)


def main() -> None:
    """Run the unified Data Intelligence MCP server from a YAML config."""
    parser = argparse.ArgumentParser(description="Data Intelligence MCP Server")
    parser.add_argument("--config", default="config.yml",
                        help="Path to unified YAML config file")
    parser.add_argument("--project", default=None,
                        help="Project name to use (infers graph-name and dbt-project-path)")
    parser.add_argument("--graph-name", default=None,
                        help="Override the graph name from config")
    parser.add_argument("--dbt-project-path", default=None,
                        help="Path to dbt project for CLI tools")
    parser.add_argument("--no-data-query", action="store_true",
                        help="Disable Snowflake data query tools")
    args = parser.parse_args()

    try:
        config = UnifiedConfig.from_yaml(Path(args.config))
    except Exception as exc:
        parser.error(f"Failed to load configuration from '{args.config}': {exc}")

    # Resolve project: --project > default_project
    project_name = args.project or config.default_project
    project = config.projects.get(project_name) if config.projects and project_name else None

    # If the resolved project name is not found, exit with a helpful message
    if project_name and project is None:
        available = ", ".join(sorted(config.projects.keys())) if config.projects else "none"
        source = "--project" if args.project else "default_project"
        parser.error(
            f"Unknown project '{project_name}' (from {source}). Available projects: {available}"
        )

    # Resolve graph name: --graph-name > project.graph_name > lineage config
    if args.graph_name:
        config.lineage.graph_name = args.graph_name
    elif project:
        config.lineage.graph_name = project.graph_name

    lineage = create_storage_for_cli(config.lineage, read_only=True)

    # Resolve data config: project-specific override > global config.data
    data = None
    data_config = None
    if project_name:
        try:
            data_config = config.get_project_data_config(project_name)
        except KeyError:
            # Project has no dedicated data configuration; fall back to global config.data below.
            pass
    if data_config is None:
        data_config = config.data

    if not args.no_data_query and data_config:
        try:
            data = create_data_backend_for_cli(data_config, read_only=True)
        except SystemExit:
            # create_data_backend_for_cli calls sys.exit on fatal errors; let it propagate.
            raise
        except Exception:
            logger.warning("Data query backend not available, skipping", exc_info=True)

    # Resolve dbt project path: --dbt-project-path > project.dbt_path
    dbt_project_path = args.dbt_project_path
    if not dbt_project_path and project:
        dbt_project_path = str(project.dbt_path)

    # Resolve profiles dir from project config
    dbt_profiles_dir = None
    if project and project.profiles_dir:
        dbt_profiles_dir = str(project.profiles_dir)

    server = create_unified_server(
        lineage_backend=lineage,
        data_backend=data,
        dbt_project_path=dbt_project_path,
        dbt_profiles_dir=dbt_profiles_dir,
    )
    server.run()


if __name__ == "__main__":
    main()
