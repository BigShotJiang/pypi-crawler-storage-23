"""Unified MCP server combining lineage graph, data query, and dbt CLI tools."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Optional, Set

from fastmcp import FastMCP

from lineage.backends.data_query.protocol import DataQueryBackend
from lineage.backends.lineage.protocol import LineageStorage
from lineage.backends.mcp_auto import auto_expose_protocol
from lineage.utils.dbt import resolve_dbt_cmd

# Methods to exclude from the LineageStorage protocol exposure.
# These are write/admin/lifecycle operations not needed for read-only MCP usage.
_LINEAGE_EXCLUDE: Set[str] = {
    "upsert_node",
    "create_edge",
    "recreate_schema",
    "ensure_schema",
    "bulk_load",
    "delete_model_cascade",
    "store_cluster_analysis",
    "close",
    "set_active_graph",
}

_DATA_QUERY_EXCLUDE: Set[str] = {
    "get_backend_type",
}


def create_unified_server(
    lineage_backend: LineageStorage,
    data_backend: Optional[DataQueryBackend] = None,
    dbt_project_path: Optional[str] = None,
    dbt_profiles_dir: Optional[str] = None,
    name: str = "data-intelligence",
) -> FastMCP:
    """Create a unified FastMCP server with lineage, data query, and dbt tools.

    Args:
        lineage_backend: Initialized LineageStorage backend (e.g. FalkorDB).
        data_backend: Optional DataQueryBackend (e.g. Snowflake). Omit to skip.
        dbt_project_path: Optional path to a dbt project for CLI tools.
        dbt_profiles_dir: Optional path to directory containing profiles.yml.
            If not provided, falls back to looking in dbt_project_path.
        name: MCP server name.

    Returns:
        Configured FastMCP server ready to run.
    """
    mcp = FastMCP(name)

    # 1. Lineage graph tools (FalkorDB)
    auto_expose_protocol(
        mcp=mcp,
        backend=lineage_backend,
        protocol_class=LineageStorage,
        exclude_methods=_LINEAGE_EXCLUDE,
    )

    # 2. Data query tools (Snowflake) — optional
    if data_backend is not None:
        auto_expose_protocol(
            mcp=mcp,
            backend=data_backend,
            protocol_class=DataQueryBackend,
            exclude_methods=_DATA_QUERY_EXCLUDE,
        )

    # 3. dbt CLI tools — registered manually
    if dbt_project_path is not None:
        _register_dbt_tools(mcp, dbt_project_path, dbt_profiles_dir)

    return mcp


def _register_dbt_tools(
    mcp: FastMCP, project_path: str, profiles_dir: Optional[str] = None
) -> None:
    """Register dbt CLI wrapper tools on the MCP server."""
    project_dir = Path(project_path).resolve()
    if not project_dir.exists() or not project_dir.is_dir():
        raise ValueError(
            f"dbt project path does not exist or is not a directory: {project_path!r}"
        )
    # Resolve profiles directory: explicit > project_dir fallback
    resolved_profiles_dir: Optional[Path] = None
    if profiles_dir:
        resolved_profiles_dir = Path(profiles_dir).resolve()
        if not resolved_profiles_dir.exists() or not resolved_profiles_dir.is_dir():
            raise ValueError(
                f"dbt profiles directory does not exist or is not a directory: {profiles_dir!r}"
            )
    elif (project_dir / "profiles.yml").exists():
        resolved_profiles_dir = project_dir

    @mcp.tool()
    def get_dbt_project_path() -> dict:
        """Get the configured dbt project path for file operations.

        Use this to resolve relative model paths (e.g., 'models/marts/dim_foo.sql')
        to absolute paths for Read/Edit operations.
        """
        return {
            "project_path": str(project_dir),
            "models_path": str(project_dir / "models"),
        }

    # Private implementation - not decorated, so it stays callable
    async def _run_dbt(args: list[str], timeout_s: int = 1800) -> dict:
        """Internal dbt runner."""
        cmd = resolve_dbt_cmd(args)
        if resolved_profiles_dir:
            cmd.extend(["--profiles-dir", str(resolved_profiles_dir)])
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=str(project_dir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
        except FileNotFoundError:
            return {
                "exit_code": -1,
                "command": " ".join(cmd),
                "working_dir": str(project_dir),
                "stdout": "",
                "stderr": "dbt executable not found. Is dbt installed and on PATH?",
            }
        try:
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=timeout_s
            )
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            return {
                "exit_code": -1,
                "command": " ".join(cmd),
                "working_dir": str(project_dir),
                "stdout": "",
                "stderr": f"Command timed out after {timeout_s}s",
            }
        stdout_text = stdout.decode("utf-8", errors="replace")
        stderr_text = stderr.decode("utf-8", errors="replace") if stderr else None
        return {
            "exit_code": proc.returncode,
            "command": " ".join(cmd),
            "working_dir": str(project_dir),
            "stdout": stdout_text[-20_000:],
            "stderr": stderr_text[-20_000:] if stderr_text is not None else None,
        }

    @mcp.tool()
    async def dbt_cli(args: list[str], timeout_s: int = 1800) -> dict:
        """Execute a dbt command (e.g., args=["run", "--select", "my_model"])."""
        return await _run_dbt(args, timeout_s)

    @mcp.tool()
    async def dbt_compile(select: str) -> dict:
        """Compile a dbt model to check SQL syntax."""
        return await _run_dbt(["compile", "--select", select])

    @mcp.tool()
    async def dbt_build(select: str, fail_fast: bool = True) -> dict:
        """Build dbt models and run tests."""
        args = ["build", "--select", select]
        if fail_fast:
            args.append("--fail-fast")
        return await _run_dbt(args)

    @mcp.tool()
    async def dbt_test(select: str) -> dict:
        """Run dbt tests for specific models."""
        return await _run_dbt(["test", "--select", select])
