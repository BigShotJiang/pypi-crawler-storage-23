"""Project overview computation for agent system prompts.

Generates a structured project overview from graph data, composed of independent
cells each with a rendering strategy (template or llm). The rendered markdown is
stored as a ProjectOverview graph node and injected into agent prompts.
"""

from __future__ import annotations

import logging
from collections import Counter
from dataclasses import dataclass, field
from pathlib import PurePosixPath
from typing import Any, Literal, Optional

logger = logging.getLogger(__name__)


@dataclass
class OverviewCell:
    """A single section of the project overview."""

    name: str
    strategy: Literal["template", "llm"]
    data: dict[str, Any] = field(default_factory=dict)
    rendered: str = ""


@dataclass
class ProjectOverviewData:
    """Structured overview data for graph storage."""

    project_name: str
    warehouse_target: Optional[str]
    model_count: int
    source_count: int
    overview_markdown: str  # Full rendered markdown for prompt injection


def _extract_project_name(model_ids: list[str]) -> str:
    """Extract project name from dbt model ID prefixes (e.g., 'model.my_project.dim_x')."""
    if not model_ids:
        return "Unknown"
    prefixes = Counter()
    for mid in model_ids:
        parts = mid.split(".")
        if len(parts) >= 2:
            prefixes[parts[1]] += 1
    if prefixes:
        return prefixes.most_common(1)[0][0]
    return "Unknown"


def _render_model_census(mat_counts: dict[str, int]) -> str:
    """Render model census cell as markdown."""
    if not mat_counts:
        return "No models found."
    total = sum(mat_counts.values())
    lines = [f"**{total} models total**\n"]
    for mat_type in ["table", "view", "incremental", "ephemeral"]:
        count = mat_counts.get(mat_type, 0)
        if count > 0:
            lines.append(f"- {mat_type}: {count}")
    # Include any other materialization types
    for mat_type, count in sorted(mat_counts.items()):
        if mat_type not in ["table", "view", "incremental", "ephemeral"] and count > 0:
            lines.append(f"- {mat_type}: {count}")
    return "\n".join(lines)


def _render_subject_areas(subject_areas: list[dict[str, Any]]) -> str:
    """Render subject areas summary cell as markdown table."""
    if not subject_areas:
        return "No subject areas identified yet (run clustering)."
    lines = [
        "| Subject Area | Domains | Fact Models | Dim Models | Total |",
        "|--------------|---------|-------------|------------|-------|",
    ]
    for area in subject_areas[:15]:
        name = area.get("name", "Unknown")
        domains = ", ".join(area.get("domains", [])[:3]) or "-"
        facts = area.get("fact_model_count", 0)
        dims = area.get("dimension_model_count", 0)
        total = area.get("model_count", 0)
        lines.append(f"| {name} | {domains} | {facts} | {dims} | {total} |")
    return "\n".join(lines)


def _render_model_index(
    model_area_map: list[dict[str, Any]],
    subject_areas: list[dict[str, Any]],
) -> str:
    """Render a model index grouped by subject area with model names and materialization.

    Each subject area lists its models grouped by tier (fct/dim/stg/int/other),
    with materialization shown inline. This gives the agent concrete model names
    to search for when exploring a domain.
    """
    if not model_area_map and not subject_areas:
        return "No models loaded."

    # Build subject area metadata lookup
    sa_meta: dict[str, dict[str, Any]] = {}
    for sa in subject_areas:
        sa_meta[sa.get("name", "")] = sa

    # Group models by subject area
    area_models: dict[str, list[dict[str, Any]]] = {}
    for row in model_area_map:
        area = row.get("area_name") or "Uncategorized"
        area_models.setdefault(area, []).append(row)

    # Sort areas: named areas by model count desc, Uncategorized last
    area_order = sorted(
        area_models.keys(),
        key=lambda a: (a == "Uncategorized", -len(area_models[a])),
    )

    lines: list[str] = []
    for area_name in area_order[:15]:
        models = area_models[area_name]
        meta = sa_meta.get(area_name, {})
        domains = meta.get("domains", [])

        # Header line
        domain_str = f" ({', '.join(domains[:3])})" if domains else ""
        lines.append(f"**{area_name}**{domain_str}")

        # Group models by prefix tier
        tier_order = ["fct", "dim", "stg", "int"]
        tier_groups: dict[str, list[str]] = {}
        for m in sorted(models, key=lambda x: x.get("name", "")):
            name = m.get("name", "")
            mat = m.get("materialization", "")
            mat_tag = f" [{mat}]" if mat and mat != "view" else ""
            parts = name.split("_", 1)
            prefix = parts[0] if len(parts) >= 2 and parts[0] in tier_order else "other"
            tier_groups.setdefault(prefix, []).append(f"`{name}`{mat_tag}")

        # Render tiers in order
        for tier in [*tier_order, "other"]:
            if tier not in tier_groups:
                continue
            entries = tier_groups[tier]
            # Cap at 10 per tier to avoid token bloat
            if len(entries) > 10:
                shown = entries[:10]
                shown.append(f"...+{len(entries) - 10} more")
                entries = shown
            lines.append(f"  {', '.join(entries)}")

        lines.append("")  # Blank line between areas

    return "\n".join(lines).rstrip()


def _render_data_flow(mat_counts: dict[str, int], model_paths: list[str]) -> str:
    """Render data flow summary by inferring tiers from model paths."""
    tier_counts: dict[str, int] = Counter()
    tier_keywords = {
        "sources": ["source", "src", "raw"],
        "staging": ["staging", "stg"],
        "intermediate": ["intermediate", "int"],
        "marts": ["marts", "mart", "fct", "dim"],
    }
    for path in model_paths:
        path_lower = path.lower()
        matched = False
        for tier, keywords in tier_keywords.items():
            if any(kw in path_lower for kw in keywords):
                tier_counts[tier] += 1
                matched = True
                break
        if not matched:
            tier_counts["other"] += 1

    if not tier_counts:
        return "No model paths available."

    parts = []
    for tier in ["sources", "staging", "intermediate", "marts", "other"]:
        count = tier_counts.get(tier, 0)
        if count > 0:
            parts.append(f"{tier.title()}: {count}")
    return " -> ".join(parts)


def _render_coverage(
    model_count: int,
    semantic_count: int,
    test_count: int,
    tested_model_count: int,
    models_with_grain: int = 0,
    col_lineage_model_count: int = 0,
) -> str:
    """Render coverage statistics."""
    lines = []
    if model_count > 0:
        sem_pct = round(100 * semantic_count / model_count)
        lines.append(f"- Semantic analysis: {semantic_count}/{model_count} models ({sem_pct}%)")
    if model_count > 0:
        test_pct = round(100 * tested_model_count / model_count)
        lines.append(f"- Test coverage: {tested_model_count}/{model_count} models ({test_pct}%)")
    if test_count > 0:
        lines.append(f"- Total tests: {test_count}")
    if models_with_grain > 0 and model_count > 0:
        grain_pct = round(100 * models_with_grain / model_count)
        lines.append(
            f"- Grain detection: {models_with_grain}/{model_count} models ({grain_pct}%)"
        )
    if col_lineage_model_count > 0 and model_count > 0:
        col_pct = round(100 * col_lineage_model_count / model_count)
        lines.append(
            f"- Column lineage: {col_lineage_model_count}/{model_count} models ({col_pct}%)"
        )
    return "\n".join(lines) if lines else "No coverage data available."


def _render_naming_conventions_fallback(model_names: list[str]) -> str:
    """Fallback naming conventions analysis (no LLM)."""
    if not model_names:
        return "No models to analyze."
    prefix_counts: dict[str, int] = Counter()
    for name in model_names:
        parts = name.split("_", 1)
        if len(parts) >= 2:
            prefix_counts[parts[0]] += 1
    if not prefix_counts:
        return "No clear naming prefixes detected."
    lines = ["Common prefixes:"]
    for prefix, count in prefix_counts.most_common(10):
        lines.append(f"- `{prefix}_*`: {count} models")
    return "\n".join(lines)


def _render_directory_org_fallback(model_paths: list[str]) -> str:
    """Fallback directory organization analysis (no LLM)."""
    if not model_paths:
        return "No model paths to analyze."
    dir_counts: dict[str, int] = Counter()
    for path in model_paths:
        parts = PurePosixPath(path).parts
        if len(parts) >= 2:
            dir_counts[parts[0]] += 1
    if not dir_counts:
        return "Flat directory structure."
    lines = ["Top-level directories:"]
    for dirname, count in dir_counts.most_common(10):
        lines.append(f"- `{dirname}/`: {count} models")
    return "\n".join(lines)


def _render_project_summary_fallback(
    project_name: str,
    model_count: int,
    warehouse_type: Optional[str],
    subject_area_names: list[str],
    source_count: int,
    measure_count: int,
) -> str:
    """Template fallback for project summary when no LLM session is available."""
    parts = [f"{project_name} is a dbt project with {model_count} models"]
    if source_count > 0:
        parts[0] += f" built on {source_count} sources"
    if warehouse_type:
        parts[0] += f" targeting {warehouse_type}"
    parts[0] += "."

    if subject_area_names:
        top = subject_area_names[:4]
        areas_str = ", ".join(top)
        if len(subject_area_names) > 4:
            areas_str += f", and {len(subject_area_names) - 4} more"
        parts.append(f"Key data domains: {areas_str}.")

    if measure_count > 0:
        parts.append(
            f"The semantic layer defines {measure_count} measures across these domains."
        )

    return " ".join(parts)


def _render_key_lineage(
    ic_count: int,
    with_pk: int,
    with_fk: int,
    fk_count: int,
    join_confirmed: int,
    test_confirmed: int,
    models_with_grain: int,
    model_count: int,
) -> str:
    """Render key relationships and grain detection cell."""
    if ic_count == 0 and fk_count == 0 and models_with_grain == 0:
        return "Key lineage has not been computed yet."
    lines = []
    if ic_count > 0:
        lines.append(f"- Entity key classes: {ic_count} ({with_pk} with PK, {with_fk} with FK)")
    if fk_count > 0:
        lines.append(
            f"- Inferred FK relationships: {fk_count} "
            f"({join_confirmed} join-confirmed, {test_confirmed} test-confirmed)"
        )
    if models_with_grain > 0 and model_count > 0:
        grain_pct = round(100 * models_with_grain / model_count)
        lines.append(
            f"- Grain detection: {models_with_grain}/{model_count} models ({grain_pct}%)"
        )
    return "\n".join(lines)


def _render_semantic_richness(
    measure_count: int,
    dimension_count: int,
    fact_count: int,
    join_edge_count: int,
) -> str:
    """Render semantic richness cell showing depth of extracted metadata."""
    if measure_count == 0 and dimension_count == 0 and fact_count == 0:
        return "Semantic analysis has not been run yet."
    lines = [
        f"- Measures: {measure_count} | Dimensions: {dimension_count} | Facts: {fact_count}"
    ]
    if join_edge_count > 0:
        lines.append(f"- Inferred join edges: {join_edge_count}")
    return "\n".join(lines)


def _render_column_lineage_depth(
    col_lineage_edges: int,
    models_with_col_lineage: int,
    model_count: int,
) -> str:
    """Render column lineage depth cell."""
    if col_lineage_edges == 0:
        return "Column lineage has not been computed yet."
    lines = [f"- Column lineage edges: {col_lineage_edges} transformations traced"]
    if models_with_col_lineage > 0 and model_count > 0:
        col_pct = round(100 * models_with_col_lineage / model_count)
        lines.append(
            f"- Column lineage coverage: {models_with_col_lineage}/{model_count} models ({col_pct}%)"
        )
    return "\n".join(lines)


def _render_exploration_hints_fallback(
    subject_area_names: list[str],
    fact_model_names: list[str],
    model_names: list[str],
    fk_count: int,
    measure_count: int,
) -> str:
    """Generate context-aware exploration suggestions oriented toward data questions."""
    hints: list[str] = []

    # Suggest exploring a specific fact model's lineage
    if fact_model_names:
        sample = fact_model_names[0]
        hints.append(
            f"- Trace what feeds `{sample}`: "
            f'`get_relation_lineage("{sample}", node_type="logical", '
            f'direction="upstream", query_description="upstream lineage")`'
        )

    # Suggest deep-diving into a fact model's semantics
    if fact_model_names and measure_count > 0:
        sample = fact_model_names[1] if len(fact_model_names) > 1 else fact_model_names[0]
        hints.append(
            f"- Explore measures and dimensions on `{sample}`: "
            f'`get_model_details("{sample}", include_semantics=True)`'
        )

    # Suggest subject area exploration
    if subject_area_names:
        area = subject_area_names[0]
        hints.append(
            f'- Browse the "{area}" domain: '
            f'`get_subject_area_details("{area}")`'
        )

    # Suggest downstream impact if FK relationships exist
    if fk_count > 0 and fact_model_names:
        sample = fact_model_names[-1]
        hints.append(
            f"- Check what depends on `{sample}`: "
            f'`get_downstream_impact("{sample}")`'
        )

    # Generic model search if nothing else available
    if not hints:
        hints.append(
            "- Find models by keyword: "
            '`search_graph_nodes(pattern="...")`'
        )

    return "\n".join(hints[:5])


async def _render_llm_cell(
    session: Any,
    prompt: str,
    data_list: list[str],
    fallback_fn: Any,
    model_alias: str = "small",
) -> str:
    """Render a cell using LLM via Fenic semantic.map, with template fallback."""
    try:
        import fenic as fc

        truncated = data_list[:500]  # Limit input size
        data_text = "\n".join(truncated)
        df = session.create_dataframe({"data": [data_text]})
        result_df = df.select(
            fc.semantic.map(
                prompt + "\n\nData:\n{{ data }}",
                data=fc.col("data"),
                model_alias=model_alias,
            ).alias("result")
        )
        result = result_df.to_pylist()[0]
        return result["result"]
    except Exception as e:
        logger.warning(f"LLM cell rendering failed, using template fallback: {e}")
        return fallback_fn(data_list)


async def compute_project_overview(
    storage: Any,
    session: Any = None,
) -> ProjectOverviewData:
    """Compute a full project overview from graph data.

    Args:
        storage: LineageStorage backend
        session: Optional Fenic session for LLM cells; None = template fallback

    Returns:
        ProjectOverviewData with rendered markdown and structured data
    """
    cells: list[OverviewCell] = []

    # ── Fetch data from graph ──

    # Model IDs for project name extraction
    model_id_result = storage.execute_raw_query("MATCH (m:DbtModel) RETURN m.id AS id")
    model_ids = [r.get("id", "") for r in model_id_result.rows if r.get("id")]

    # Warehouse type
    warehouse_type = None
    try:
        wh_result = storage.execute_raw_query(
            "MATCH (p) WHERE p:PhysicalTable OR p:PhysicalView RETURN DISTINCT p.warehouse_type AS wt LIMIT 1"
        )
        if wh_result.rows:
            warehouse_type = wh_result.rows[0].get("wt")
    except Exception:  # nosec B110
        pass

    # Model census by materialization
    mat_result = storage.execute_raw_query(
        "MATCH (m:DbtModel) RETURN m.materialization AS mat, COUNT(m) AS cnt"
    )
    mat_counts: dict[str, int] = {}
    for row in mat_result.rows:
        mat = row.get("mat") or "unknown"
        mat_counts[mat] = row.get("cnt", 0)

    # Source count
    source_result = storage.execute_raw_query("MATCH (s:DbtSource) RETURN COUNT(s) AS cnt")
    source_count = source_result.rows[0].get("cnt", 0) if source_result.rows else 0

    # Model names (for naming conventions)
    name_result = storage.execute_raw_query("MATCH (m:DbtModel) RETURN m.name AS name")
    model_names = [r.get("name", "") for r in name_result.rows if r.get("name")]

    # Model paths (for directory org + data flow)
    path_result = storage.execute_raw_query(
        "MATCH (m:DbtModel) RETURN m.original_path AS path"
    )
    model_paths = [r.get("path", "") for r in path_result.rows if r.get("path")]

    # Subject areas
    try:
        subject_areas = storage.list_subject_areas(sort_by="model_count")
    except Exception:
        subject_areas = []

    # Model → subject area membership (for model index)
    try:
        area_map_result = storage.execute_raw_query(
            "MATCH (m:DbtModel) "
            "OPTIONAL MATCH (m)-[:BELONGS_TO_SUBJECT_AREA]->(sa:InferredSubjectArea) "
            "RETURN m.name AS name, m.materialization AS materialization, "
            "m.original_path AS path, sa.name AS area_name"
        )
        model_area_map = area_map_result.rows
    except Exception:
        model_area_map = []

    # Semantic coverage
    try:
        sem_result = storage.execute_raw_query(
            "MATCH (m:DbtModel) "
            "OPTIONAL MATCH (m)-[:HAS_INFERRED_SEMANTICS]->(sem) "
            "RETURN COUNT(m) AS total, COUNT(sem) AS analyzed"
        )
        semantic_count = sem_result.rows[0].get("analyzed", 0) if sem_result.rows else 0
    except Exception:
        semantic_count = 0

    # Test coverage
    try:
        test_result = storage.execute_raw_query("MATCH (t:DbtTest) RETURN COUNT(t) AS cnt")
        test_count = test_result.rows[0].get("cnt", 0) if test_result.rows else 0

        tested_result = storage.execute_raw_query(
            "MATCH (m:DbtModel)-[:HAS_TEST]->(t:DbtTest) RETURN COUNT(DISTINCT m) AS cnt"
        )
        tested_model_count = tested_result.rows[0].get("cnt", 0) if tested_result.rows else 0
    except Exception:
        test_count = 0
        tested_model_count = 0

    # ── Fetch enrichment data ──

    # Identity class stats (key lineage)
    ic_count = with_pk = with_fk = 0
    try:
        ic_result = storage.execute_raw_query(
            "MATCH (ic:IdentityClass) "
            "RETURN COUNT(ic) AS ic_count, "
            "SUM(CASE WHEN ic.has_pk THEN 1 ELSE 0 END) AS with_pk, "
            "SUM(CASE WHEN ic.has_fk THEN 1 ELSE 0 END) AS with_fk"
        )
        if ic_result.rows:
            ic_count = ic_result.rows[0].get("ic_count", 0)
            with_pk = int(ic_result.rows[0].get("with_pk") or 0)
            with_fk = int(ic_result.rows[0].get("with_fk") or 0)
    except Exception:  # nosec B110
        pass

    # Inferred FK stats
    fk_count = join_confirmed = test_confirmed = 0
    try:
        fk_result = storage.execute_raw_query(
            "MATCH ()-[fk:INFERRED_FK]->() "
            "RETURN COUNT(fk) AS fk_count, "
            "SUM(CASE WHEN fk.confirmed_by_join THEN 1 ELSE 0 END) AS join_confirmed, "
            "SUM(CASE WHEN fk.confirmed_by_test THEN 1 ELSE 0 END) AS test_confirmed"
        )
        if fk_result.rows:
            fk_count = fk_result.rows[0].get("fk_count", 0)
            join_confirmed = int(fk_result.rows[0].get("join_confirmed") or 0)
            test_confirmed = int(fk_result.rows[0].get("test_confirmed") or 0)
    except Exception:  # nosec B110
        pass

    # Models with detected grain
    models_with_grain = 0
    try:
        grain_result = storage.execute_raw_query(
            "MATCH (m:DbtModel) WHERE m.grain_columns IS NOT NULL "
            "RETURN COUNT(m) AS models_with_grain"
        )
        if grain_result.rows:
            models_with_grain = grain_result.rows[0].get("models_with_grain", 0)
    except Exception:  # nosec B110
        pass

    # Semantic richness counts
    _semantic_counts: dict[str, int] = {}
    for _label, _key in [
        ("InferredMeasure", "measure_count"),
        ("InferredDimension", "dimension_count"),
        ("InferredFact", "fact_count"),
        ("JoinEdge", "join_edge_count"),
    ]:
        try:
            _r = storage.execute_raw_query(
                f"MATCH (n:{_label}) RETURN COUNT(n) AS cnt"
            )
            _semantic_counts[_key] = _r.rows[0].get("cnt", 0) if _r.rows else 0
        except Exception:
            _semantic_counts[_key] = 0
    measure_count = _semantic_counts["measure_count"]
    dimension_count = _semantic_counts["dimension_count"]
    fact_count = _semantic_counts["fact_count"]
    join_edge_count = _semantic_counts["join_edge_count"]

    # Column lineage depth
    col_lineage_edges = models_with_col_lineage = 0
    try:
        col_edge_result = storage.execute_raw_query(
            "MATCH (:DbtColumn)-[d:DERIVES_FROM]->(:DbtColumn) "
            "RETURN COUNT(d) AS col_lineage_edges"
        )
        if col_edge_result.rows:
            col_lineage_edges = col_edge_result.rows[0].get("col_lineage_edges", 0)
    except Exception:  # nosec B110
        pass
    try:
        col_model_result = storage.execute_raw_query(
            "MATCH (c:DbtColumn)-[:DERIVES_FROM]->(:DbtColumn) "
            "RETURN COUNT(DISTINCT c.parent_id) AS models_with_col_lineage"
        )
        if col_model_result.rows:
            models_with_col_lineage = col_model_result.rows[0].get(
                "models_with_col_lineage", 0
            )
    except Exception:  # nosec B110
        pass

    # ── Derived values ──
    project_name = _extract_project_name(model_ids)
    model_count = len(model_ids)
    subject_area_names = [sa.get("name", "") for sa in subject_areas if sa.get("name")]
    fact_model_names = [n for n in model_names if n.startswith("fct_")]

    # ── Build cells ──
    # Note: Project Summary is built last (needs other cells' context) and inserted first.

    # 2. Project Identity
    identity_parts = [f"**Project**: {project_name}"]
    if warehouse_type:
        identity_parts.append(f"**Warehouse**: {warehouse_type}")
    identity_cell = OverviewCell(
        name="Project Identity",
        strategy="template",
        data={"project_name": project_name, "warehouse_type": warehouse_type},
        rendered="\n".join(identity_parts),
    )
    cells.append(identity_cell)

    # 3. Model Census
    census_cell = OverviewCell(
        name="Model Census",
        strategy="template",
        data=mat_counts,
        rendered=_render_model_census(mat_counts),
    )
    cells.append(census_cell)

    # 4. Data Flow Summary
    flow_cell = OverviewCell(
        name="Data Flow Summary",
        strategy="template",
        rendered=_render_data_flow(mat_counts, model_paths),
    )
    cells.append(flow_cell)

    # 5. Key Relationships & Grain
    key_lineage_cell = OverviewCell(
        name="Key Relationships & Grain",
        strategy="template",
        data={
            "ic_count": ic_count, "with_pk": with_pk, "with_fk": with_fk,
            "fk_count": fk_count, "join_confirmed": join_confirmed,
            "test_confirmed": test_confirmed, "models_with_grain": models_with_grain,
        },
        rendered=_render_key_lineage(
            ic_count, with_pk, with_fk, fk_count,
            join_confirmed, test_confirmed, models_with_grain, model_count,
        ),
    )
    cells.append(key_lineage_cell)

    # 6. Semantic Richness
    semantic_richness_cell = OverviewCell(
        name="Semantic Richness",
        strategy="template",
        data={
            "measure_count": measure_count, "dimension_count": dimension_count,
            "fact_count": fact_count, "join_edge_count": join_edge_count,
        },
        rendered=_render_semantic_richness(
            measure_count, dimension_count, fact_count, join_edge_count,
        ),
    )
    cells.append(semantic_richness_cell)

    # 7. Column Lineage Depth
    col_lineage_cell = OverviewCell(
        name="Column Lineage Depth",
        strategy="template",
        data={
            "col_lineage_edges": col_lineage_edges,
            "models_with_col_lineage": models_with_col_lineage,
        },
        rendered=_render_column_lineage_depth(
            col_lineage_edges, models_with_col_lineage, model_count,
        ),
    )
    cells.append(col_lineage_cell)

    # 8. Coverage (enhanced with grain + column lineage)
    coverage_cell = OverviewCell(
        name="Coverage",
        strategy="template",
        data={
            "semantic_count": semantic_count,
            "test_count": test_count,
            "tested_model_count": tested_model_count,
            "models_with_grain": models_with_grain,
            "col_lineage_model_count": models_with_col_lineage,
        },
        rendered=_render_coverage(
            model_count, semantic_count, test_count, tested_model_count,
            models_with_grain=models_with_grain,
            col_lineage_model_count=models_with_col_lineage,
        ),
    )
    cells.append(coverage_cell)

    # 9. Naming Conventions (LLM or fallback)
    if session and model_names:
        naming_rendered = await _render_llm_cell(
            session,
            "Given these dbt model names, describe the naming conventions concisely. "
            "Note prefixes, suffixes, and domain patterns. Be brief (3-5 bullet points).",
            model_names,
            _render_naming_conventions_fallback,
        )
    else:
        naming_rendered = _render_naming_conventions_fallback(model_names)
    naming_cell = OverviewCell(
        name="Naming Conventions",
        strategy="llm" if session else "template",
        rendered=naming_rendered,
    )
    cells.append(naming_cell)

    # 10. Directory Organization (LLM or fallback)
    if session and model_paths:
        dir_rendered = await _render_llm_cell(
            session,
            "Given these dbt model file paths, describe the directory organization "
            "and structure philosophy concisely. Be brief (3-5 bullet points).",
            model_paths,
            _render_directory_org_fallback,
        )
    else:
        dir_rendered = _render_directory_org_fallback(model_paths)
    dir_cell = OverviewCell(
        name="Directory Organization",
        strategy="llm" if session else "template",
        rendered=dir_rendered,
    )
    cells.append(dir_cell)

    # 11. Subject Areas (summary table)
    sa_cell = OverviewCell(
        name="Subject Areas",
        strategy="template",
        data={"count": len(subject_areas)},
        rendered=_render_subject_areas(subject_areas),
    )
    cells.append(sa_cell)

    # 12. Model Index (models grouped by subject area with names)
    index_cell = OverviewCell(
        name="Model Index",
        strategy="template",
        data={"area_count": len(subject_areas), "model_count": len(model_area_map)},
        rendered=_render_model_index(model_area_map, subject_areas),
    )
    cells.append(index_cell)

    # 13. Exploration Hints (LLM or fallback)
    hints_fallback = _render_exploration_hints_fallback(
        subject_area_names, fact_model_names, model_names,
        fk_count, measure_count,
    )
    if session and model_count > 0:
        hints_input = (
            f"subject_areas=[{', '.join(subject_area_names[:10])}], "
            f"fact_models=[{', '.join(fact_model_names[:10])}], "
            f"measures={measure_count}, dimensions={dimension_count}, "
            f"fk_relationships={fk_count}, "
            f"sample_models={model_names[:15]}"
        )
        hints_rendered = await _render_llm_cell(
            session,
            "Given this dbt project data, suggest 3-5 specific first queries an "
            "analyst or engineer should run to understand the data. Focus on: "
            "exploring key business entities, understanding relationships between "
            "domains, and finding the richest data for analysis. For each suggestion, "
            "include the exact tool call using one of these tools:\n"
            "- get_model_details(model_id, include_semantics=True) — inspect a model's measures/dimensions\n"
            "- get_relation_lineage(identifier, node_type='logical', direction='upstream'|'downstream', "
            "query_description='...') — trace data flow\n"
            "- get_subject_area_details(subject_area_name) — explore a business domain\n"
            "- get_downstream_impact(model_id) — see what depends on a model\n"
            "- search_graph_nodes(pattern='...') — find models by keyword\n"
            "Reference actual model names and subject areas from the data.",
            [hints_input],
            lambda _data: hints_fallback,
        )
    else:
        hints_rendered = hints_fallback
    hints_cell = OverviewCell(
        name="Exploration Hints",
        strategy="llm" if session else "template",
        rendered=hints_rendered,
    )
    cells.append(hints_cell)

    # 1. Project Summary — built last (uses rendered cells as context), placed first
    # Collect rendered cell content so the LLM sees the full overview
    cells_context = "\n\n".join(
        f"## {c.name}\n{c.rendered}" for c in cells if c.rendered
    )
    summary_fallback = _render_project_summary_fallback(
        project_name, model_count, warehouse_type,
        subject_area_names, source_count, measure_count,
    )
    if session and model_count > 0:
        summary_rendered = await _render_llm_cell(
            session,
            "You are given the rendered sections of a dbt project overview. "
            "Write a short paragraph (4-6 sentences) orienting an analyst or "
            "engineer to the project. Cover: what business domains this project "
            "serves, its scale (models, sources, measures), the key data entities "
            "and relationships available, and which subject areas are richest for "
            "analysis. Write as a practical guide — help the reader understand what "
            "questions this data can answer. Do not discuss platform coverage metrics "
            "or modeling maturity.",
            [cells_context],
            lambda _data: summary_fallback,
            model_alias="medium",
        )
    else:
        summary_rendered = summary_fallback
    summary_cell = OverviewCell(
        name="Project Summary",
        strategy="llm" if session else "template",
        rendered=summary_rendered,
    )
    cells.insert(0, summary_cell)

    # ── Assemble full markdown ──
    md_sections = []
    for cell in cells:
        if cell.rendered:
            md_sections.append(f"### {cell.name}\n\n{cell.rendered}")

    overview_markdown = "\n\n".join(md_sections)

    return ProjectOverviewData(
        project_name=project_name,
        warehouse_target=warehouse_type,
        model_count=model_count,
        source_count=source_count,
        overview_markdown=overview_markdown,
    )
