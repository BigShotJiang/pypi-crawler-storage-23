---
name: data-quality-diagnostics
description: >
  Diagnostic tool usage patterns for key/join/duplicate issues.
  Load when investigating data quality symptoms like NULL keys,
  duplicate rows, broken joins, or count mismatches.
---

# Data Quality Diagnostic Patterns

## Diagnostic Tools

### run_key_diagnostics

Checks for duplicate and NULL primary keys.

```text
run_key_diagnostics(
    database="DATABASE",
    schema="SCHEMA",
    table="TABLE_NAME",
    key_columns=["key_column"]
)
```

Returns: total_rows, unique_keys, null_count, duplicate_count.
Instant duplicate detection — use before deeper investigation.

### run_join_diagnostics

Checks join health between two tables.

```text
run_join_diagnostics(
    left_fqn="DATABASE.SCHEMA.FACT_TABLE",
    right_fqn="DATABASE.SCHEMA.DIM_TABLE",
    join_columns=["join_key"]
)
```

Returns: orphan rates (left/right), NULL join key rates, match rates.

### run_relationship_health_check

Combined key + join diagnostics in one call. **REQUIRED for key/join symptoms.**

```text
run_relationship_health_check(
    left_model_id="model.project.fact_model",
    right_model_id="model.project.dim_model",
    join_columns=["join_key"]
)
```

Uses model IDs to auto-resolve materializations. Runs key diagnostics
on both sides, then join diagnostics between them.

## When to Use Each Tool

| Symptom                              | Tool                                      | Follow-up                               |
| ------------------------------------ | ----------------------------------------- | --------------------------------------- |
| "Counts are wrong"                   | `run_key_diagnostics` on the model        | Trace duplicate keys upstream           |
| "Values don't match between reports" | `run_join_diagnostics` between fact + dim | Check orphan rates                      |
| "NULL keys / broken joins"           | `run_relationship_health_check`           | Inspect surrogate key generation in SQL |
| "Metric is inflated"                 | `run_key_diagnostics` on fact table       | Check for fanout from joins             |
| "Dashboard shows wrong numbers"      | Start with `execute_query` to reproduce   | Then diagnostics on suspect model       |

## Investigation Workflow for Key/Join Issues

1. **Run relationship health check** on the fact/dimension pair
2. **If health check fails:**
   - Run `run_key_diagnostics` on both sides of the join
   - Inspect surrogate-key generation logic in BOTH models' SQL
   - Trace the key column upstream to find where corruption starts
3. **Find duplicate examples:**
   ```sql
   SELECT key_column, COUNT(*) as cnt
   FROM schema.table
   GROUP BY key_column
   HAVING COUNT(*) > 1
   ORDER BY cnt DESC
   LIMIT 5
   ```
4. **Check the SQL** for missing deduplication:
   - Look for missing `QUALIFY ROW_NUMBER() OVER (PARTITION BY key ORDER BY ...) = 1`
   - Look for joins that cause fanout (1:many without aggregation)

## Materialization Lookup

Always get the exact FQN before running diagnostics:

```text
get_model_materializations("model.project.model_name")
```

This returns the actual database.schema.table for the current environment.

## Ephemeral Models

Models with `materialization: 'ephemeral'` are CTEs inlined into downstream
models. They do NOT exist as tables — `get_model_materializations()` returns
empty. Only `table`, `view`, or `incremental` materializations can be queried
with diagnostic tools.
