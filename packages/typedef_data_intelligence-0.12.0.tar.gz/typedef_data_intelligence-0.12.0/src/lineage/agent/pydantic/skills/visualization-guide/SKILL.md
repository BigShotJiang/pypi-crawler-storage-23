---
name: visualization-guide
description: >
  Visual report structure, chart type selection, and Mermaid diagram conventions.
  Load before creating reports with diagrams, charts, or mermaid cells.
  NOT related to dbt report models — this is about visual output.
---

# Visualization Guide

## Report Structure

A well-structured visual report follows this pattern:

1. **Title/Introduction** (markdown)
   - What this report covers
   - Key finding summary

2. **Visual Architecture** (mermaid)
   - Lineage diagram showing relationships
   - Data flow from source to target

3. **Details** (markdown + tables)
   - Specific findings
   - Sample data if relevant
   - Impact analysis

4. **Recommendations** (markdown)
   - Next steps
   - Who should act

## Chart Type Selection

| Data Shape          | Chart Type                 | When                                   |
| ------------------- | -------------------------- | -------------------------------------- |
| Trend over time     | `line`                     | Time series, growth metrics            |
| Category comparison | `bar`                      | Comparing discrete groups              |
| Part of whole       | `pie`                      | Percentage breakdowns (< 7 categories) |
| Two variables       | `scatter`                  | Correlation analysis                   |
| Grouped comparison  | `bar` with `series_column` | Multiple series by category            |

## Using Query Results in Reports

Always preview data before creating charts:

```text
# Step 1: Inspect the data to see actual column names
preview_blob(blob_id="blob_abc123")
# Returns: columns=["MONTH_ACTUAL", "TOTAL_DAILY_ACTIVE_USERS", ...]

# Step 2: Use EXACT column names for data, display labels for axes
add_chart_cell(
    report_id="...",
    result_set_id="blob_abc123",
    chart_type="line",
    title="Daily Active Users",
    x_column="MONTH_ACTUAL",              # Exact column name
    y_column="TOTAL_DAILY_ACTIVE_USERS",  # Exact column name
    x_label="Month",                      # Human-readable label
    y_label="Daily Active Users"          # Human-readable label
)
```

For grouped charts, add `series_column`:

```text
add_chart_cell(
    report_id="...",
    result_set_id="blob_abc123",
    chart_type="bar",
    title="Users by Hosting Type",
    x_column="ACTIVITY_MONTH",
    y_column="TOTAL_USERS",
    series_column="HOSTING_TYPE",
    x_label="Month",
    y_label="Total Users",
    series_label="Hosting Type"
)
```

For tables (no column selection needed):

```text
add_table_cell(report_id="...", result_set_id="blob_abc123", title="Revenue by Region")
```

## Mermaid Diagram Patterns

### Lineage Flow (Top to Bottom)

Use `flowchart TB` for lineage diagrams showing data flow:

```mermaid
flowchart TB
    stg_orders["stg_orders<br/>(staging)"]
    stg_customers["stg_customers<br/>(staging)"]
    int_orders["int_orders<br/>(intermediate)"]
    fct_revenue["fct_revenue<br/>(mart)"]
    rpt_daily["rpt_daily_revenue<br/>(report)"]

    stg_orders --> int_orders
    stg_customers --> int_orders
    int_orders --> fct_revenue
    fct_revenue --> rpt_daily
```

### Highlighting Issues

Use styling to highlight problem areas:

```mermaid
flowchart TB
    stg_subs["stg_subscriptions"]
    int_periods["int_subscription_periods"]
    fct_arr["fct_arr_monthly"]

    stg_subs --> int_periods
    int_periods --> fct_arr

    style int_periods fill:#ff6b6b,color:#fff
    style fct_arr fill:#ffd93d
```

### Entity Relationships

```mermaid
erDiagram
    CUSTOMER ||--o{ ORDER : places
    ORDER ||--|{ LINE_ITEM : contains
    PRODUCT ||--o{ LINE_ITEM : "appears in"
```

### State Diagrams (for ticket workflows)

```mermaid
stateDiagram-v2
    [*] --> Open
    Open --> InProgress: Assign
    InProgress --> InReview: Submit fix
    InReview --> Resolved: Approved
    InReview --> InProgress: Changes requested
    Resolved --> [*]
```

### Sequence Diagrams (for data flow)

```mermaid
sequenceDiagram
    participant Source as Source System
    participant Staging as stg_layer
    participant Mart as fct_layer
    participant Dashboard

    Source->>Staging: Extract
    Staging->>Mart: Transform
    Mart->>Dashboard: Serve
```
