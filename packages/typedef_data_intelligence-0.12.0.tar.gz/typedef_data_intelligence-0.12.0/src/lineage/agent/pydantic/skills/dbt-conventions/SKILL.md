---
name: dbt-conventions
description: >
  dbt model naming, materialization, testing, and documentation best practices.
  Load when building new models or reviewing existing model structure.
---

# dbt Conventions and Best Practices

## Naming Conventions

| Layer             | Prefix | Example                   | Purpose                             |
| ----------------- | ------ | ------------------------- | ----------------------------------- |
| Staging           | `stg_` | `stg_stripe_payments`     | 1:1 with source, minimal transforms |
| Intermediate      | `int_` | `int_order_items_pivoted` | Business logic building blocks      |
| Marts (fact)      | `fct_` | `fct_orders`              | Event/transaction grain             |
| Marts (dimension) | `dim_` | `dim_customers`           | Entity attributes                   |

## Finding Existing Patterns

Before building anything new, use the **graph first** — it's cheaper and more informative
than file reads:

```text
# 1. Search for models related to the business concept (fast, no token cost)
search_graph_nodes("<business concept>", node_types=["DbtModel", "InferredMeasure"])

# 2. Get semantic details for peer models — grain, measures, dimensions
get_model_details("<model_id>", include_semantics=True)
#    → grain_human, measures, dimensions, intent — shows what it already computes

# 3. Trace upstream to find reusable intermediate models
get_relation_lineage("<model_id>", node_type="logical", direction="upstream", depth=2)
#    → shows the full chain: stg → int → fct with semantic summaries at each level

# 4. Only read SQL files when you need implementation detail the graph doesn't have
read_file("/path/to/similar_model.sql")
```

**Key principle: prefer `ref()` to an existing model over reimplementing the same logic.**
Search `int_*` models — they often already compute the business logic you need. If an
intermediate already computes what you're about to build, use `ref()` instead of rebuilding
from staging.

## Questions to Answer for New Models

- **Where** should this model go? (file location, layer)
- **What naming conventions** are used? (fct*, dim*, int*, stg*)
- **What's the typical structure?** (CTEs, final select, tests)
- **What documentation** is expected? (schema.yml descriptions)
- **Does this logic already exist?** Search intermediates before building from scratch

## SQL Structure Conventions

Most dbt models follow this CTE pattern:

```sql
with source_data as (
    select * from {{ ref('upstream_model') }}
),

transformed as (
    -- Business logic here
    select
        key_column,
        measure_column,
        dimension_column
    from source_data
    where condition
),

final as (
    select * from transformed
)

select * from final
```

## Materialization Selection

| Type          | When to Use                                |
| ------------- | ------------------------------------------ |
| `view`        | Light transforms, always-fresh data needed |
| `table`       | Heavy transforms, frequently queried       |
| `incremental` | Large fact tables, append-mostly data      |
| `ephemeral`   | Reusable CTEs, no direct querying needed   |

## Testing Best Practices

Every model should have at minimum:

- `unique` test on the primary key
- `not_null` test on the primary key
- `relationships` test for foreign keys

```yaml
models:
  - name: fct_orders
    columns:
      - name: order_id
        tests:
          - unique
          - not_null
      - name: customer_id
        tests:
          - not_null
          - relationships:
              to: ref('dim_customers')
              field: customer_id
```

## Schema.yml Documentation

Add descriptions for models and key columns:

```yaml
models:
  - name: fct_orders
    description: "One row per order. Grain: order_id."
    columns:
      - name: order_id
        description: "Primary key - unique order identifier"
      - name: total_amount
        description: "Order total in USD after discounts"
```

## Grain Validation

Getting the grain right is the most important correctness criterion. Before finalizing
any new model:

1. **Decompose the grain** into its primary key columns from the task requirements.
2. **Handle zero-activity periods.** If the grain includes a time dimension, use a
   date/month spine to generate ALL periods — not just periods with activity.
3. **Check existing grain patterns.** Use `get_model_details(model_id, include_semantics=True)`
   on peer models to see their `grain_human`.
4. **Verify after building:**
   ```text
   run_key_diagnostics(database=..., schema=..., table="FCT_NEW_MODEL",
                       key_columns=["pk_col_1", "pk_col_2"])
   # Must report 0 duplicates
   ```

**Common grain mistakes:**

- Fan-out: including a lower-grain column that shouldn't be part of the primary key
- Missing periods: only outputting periods with activity instead of all periods in the spine
- Filtered grain: only outputting rows matching a condition when the task asks for all
  rows with a boolean flag

## For New Models, Check

1. How are similar marts organized?
2. What tests do peer models have?
3. What's in the schema.yml for similar models?
4. What grain should the model be? (document it in the model description)
5. What are the upstream dependencies?
6. Does any intermediate already compute this logic? (`search_graph_nodes`, `get_relation_lineage`)
