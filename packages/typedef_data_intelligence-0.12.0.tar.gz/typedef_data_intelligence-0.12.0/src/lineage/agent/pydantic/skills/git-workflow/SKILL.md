---
name: git-workflow
description: >
  Conventional commit format and executor git workflow.
  Load when preparing commits or working with git operations.
---

# Git Workflow & Commit Conventions

## Commit Message Format

Use conventional commits:

- `fix(model): Description` — for bug fixes
- `feat(model): Description` — for new features/models
- `refactor(model): Description` — for refactoring without behavior change

The scope should be the primary model or area affected:

```text
fix(fct_customers): deduplicate by customer_id
feat(fct_customer_churn): add monthly churn mart
refactor(int_orders): simplify CTE structure
```

## Branch Naming

**Never commit to main/master.** Always create a feature branch first.

Pattern: `feature/<short-description>` or `fix/<short-description>`

```text
feature/add-churn-mart
fix/customer-dedup
fix/arr-date-alignment
```

## Executor Git Workflow

### After successful fix

```text
1. git_add(files=["path/to/changed_file.sql"])
2. git_commit(message="fix(model_name): Description of fix")
```

### After creating new model

```text
1. git_add(files=[
     "models/marts/fct_new_model.sql",
     "models/marts/schema.yml"
   ])
2. git_commit(message="feat(fct_new_model): add new model description")
```

### Before committing, verify

- dbt build passed (not just compile)
- Warehouse data looks correct (execute_query verification)
- Only intended files are staged (git_status check)

## Multi-Step Changes

For changes touching multiple files, commit atomically:

```text
git_add(files=["file1.sql", "file2.sql", "schema.yml"])
git_commit(message="fix(scope): description covering all changes")
```

Don't create multiple commits for a single logical change.
