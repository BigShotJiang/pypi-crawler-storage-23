---
name: additive-workflow
description: >
  Full additive workflow for creating new models, adding features, new columns/tables.
  Load when task is classified as ADDITIVE. Covers 5 phases from requirements analysis
  through convention discovery (explorer), design (planner), executor handoff, and
  verification. Also load dbt-conventions for project-specific naming and test patterns.
---

# Additive Workflow

## Prerequisite Skills

Load before starting work:

- `load_skill("dbt-conventions")` — project-specific naming, materialization, and test patterns

---

## Phase 1: Understand Requirements (DIRECT)

1. Parse the request for: grain, measures/dimensions, column specs, naming
2. **Decompose the grain explicitly** — write down the primary key columns. If the grain
   includes a time dimension, the model needs a date/month spine for complete period coverage.
3. Identify upstream dependencies mentioned or implied
4. **Search for existing logic before designing from scratch:**
   ```text
   search_graph_nodes("<business concept>", node_types=["DbtModel", "InferredMeasure"])
   ```
   If intermediates already compute what you need, plan to `ref()` them.
5. Determine scope: single model vs multi-model

---

## Phase 2: Convention Discovery (EXPLORER)

**Skip if** the project overview already provided sufficient orientation on naming
conventions and directory structure — proceed directly to Phase 3 in that case.

Otherwise, spawn explorer to find what already exists in the project:

```text
task(name="explorer", prompt="""
Find existing models and intermediates for [feature area]:

1. Use search_graph_nodes("[business concept]", node_types=["DbtModel", "InferredMeasure"])
   to find models related to the feature area.

2. For the 2-3 most relevant models, call get_model_details(model_id, include_semantics=True)
   to get their grain, measures, and intent — so the new model can ref() them instead of rebuilding.

3. Use get_relation_lineage on the most relevant model (direction="upstream", depth=2)
   to map available int_*/stg_* ref() candidates.

4. Read 1-2 peer model SQL files for CTE structure and test patterns.

Focus on what ALREADY EXISTS that the new model should reuse.
""")
```

The explorer's ExplorationResult is auto-persisted as a context brief.
Call the planner immediately after — it reads the brief automatically.

---

## Phase 3: Design (PLANNER)

```text
# Initial plan
task(name="planner", prompt="""
Create a plan for building [model_name].

Requirements:
- Grain: [grain from requirements analysis]
- Business purpose: [purpose]

Read the context brief(s) for conventions and upstream model details.
""")

# Replan after executor failure
task(name="planner", prompt="""
Replan for [model_name].

Reason: [what failed — e.g. "dbt build failed: column X not found in int_server_spine"]

The existing todos reflect current progress. Update the plan from here.
""")
```

---

## Phase 4: Execute (EXECUTOR)

Before calling executor, confirm:

1. Requirements understood (grain, columns, upstream dependencies)
2. Conventions discovered (file location, naming, materialization, test patterns)
3. SQL design documented (CTEs, refs, joins, aggregations)
4. schema.yml plan ready (tests: unique + not_null on PK, relationships on FKs, descriptions)
5. Verification queries ready (row count > 0, grain check via key diagnostics)
6. Executor prompt explicitly includes git_add + git_commit as a required step

```text
task(name="executor", prompt="""
Build [model_name] following the plan.

Steps:
1. Create SQL file at [path] with [CTE structure]
2. Create/update schema.yml with tests and descriptions
3. dbt_compile to check syntax
4. dbt_build to materialize and run tests
5. execute_query to verify: row count > 0, grain correct (no duplicate PKs)
6. ALWAYS git_add + git_commit with a descriptive message — this is REQUIRED, not optional
""")
```

---

## Phase 5: Verification (DIRECT or EXECUTOR)

- Confirm model produces rows in warehouse
- **Verify grain matches the task spec:**
  - `run_key_diagnostics` on the primary key columns — must report 0 duplicates
  - Check that row count matches expected cardinality
  - If the grain includes a time dimension, verify zero-activity periods exist as rows
- Verify tests pass (unique, not_null, relationships)
- Verify schema.yml has descriptions
