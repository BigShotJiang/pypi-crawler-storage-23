---
name: cypher-patterns
description: >
  Advanced raw Cypher query patterns for the lineage graph. Load when the
  structured graph tools (get_model_details, get_relation_lineage, etc.) cannot
  answer your question. Covers semantic subgraph traversal, cross-model
  aggregations, shared-source discovery, and OpenLineage runtime patterns.
---

# Advanced Cypher Patterns for Lineage Exploration

These patterns require `query_graph(cypher)` directly. Prefer the structured
tools (get_model_details, get_relation_lineage, trace_column, etc.) for
everything they cover — reach for raw Cypher only when no structured tool fits.

## Graph Schema Quick Reference

**Logical nodes**: `DbtModel`, `DbtSource`, `DbtColumn`
**Physical nodes**: `PhysicalRelation`, `PhysicalColumn`
**Semantic nodes**: `InferredSemanticModel`, `InferredMeasure`, `InferredDimension`
**Runtime nodes**: `Run`, `Job`, `Dataset`, `Error`

**Key edges**: `DEPENDS_ON`, `HAS_COLUMN`, `BUILDS` (logical→physical),
`HAS_INFERRED_SEMANTICS`, `HAS_MEASURE`, `HAS_DIMENSION`,
`INSTANCE_OF` (Run→Job), `WRITES` (Job→Dataset), `HAS_ERROR` (Run→Error)

---

## Pattern 1: Semantic Subgraph Traversal

Find models that expose a specific measure or dimension. Use when
`get_model_details(include_semantics=True)` only covers a single model and you
need to survey across the graph.

```cypher
-- All models that have a "revenue" measure
MATCH (m:DbtModel)-[:HAS_INFERRED_SEMANTICS]->(sa:InferredSemanticModel)
      -[:HAS_MEASURE]->(measure:InferredMeasure)
WHERE toLower(measure.name) CONTAINS 'revenue'
RETURN m.name, sa.grain_human, measure.name, measure.definition
ORDER BY m.name
```

```cypher
-- All models exposing a customer_id dimension (candidate grain anchors)
MATCH (m:DbtModel)-[:HAS_INFERRED_SEMANTICS]->(sa:InferredSemanticModel)
      -[:HAS_DIMENSION]->(d:InferredDimension)
WHERE d.name = 'customer_id'
RETURN m.name, sa.grain_human, m.layer
ORDER BY m.layer, m.name
```

---

## Pattern 2: Cross-Model Aggregations

Count or group models by a property. Use for understanding layer distribution,
tag coverage, or test completeness across the project.

```cypher
-- Model count by layer
MATCH (m:DbtModel)
WHERE m.layer IS NOT NULL
RETURN m.layer, COUNT(m) AS model_count
ORDER BY model_count DESC
```

```cypher
-- Models with no tests defined (missing coverage)
MATCH (m:DbtModel)
WHERE NOT (m)-[:HAS_TEST]->()
  AND m.layer IN ['mart', 'intermediate']
RETURN m.name, m.layer
ORDER BY m.layer, m.name
```

```cypher
-- Materialization strategy breakdown by layer
MATCH (m:DbtModel)
RETURN m.layer, m.materialization, COUNT(m) AS count
ORDER BY m.layer, m.materialization
```

---

## Pattern 3: Shared Source Discovery

Find which models share a common upstream source or staging layer. Use when
exploring blast radius of a source table change or finding convention peers.

```cypher
-- All staging models that read from the same source table
MATCH (source:DbtSource {name: 'raw_orders'})
      <-[:DEPENDS_ON]-(staging:DbtModel)
RETURN staging.name, staging.layer
ORDER BY staging.name
```

```cypher
-- All downstream models that eventually depend on a given staging model
MATCH path = (m:DbtModel {name: 'stg_orders'})
             <-[:DEPENDS_ON*1..10]-(downstream:DbtModel)
RETURN DISTINCT downstream.name, downstream.layer, length(path) AS depth
ORDER BY depth, downstream.name
```

---

## Pattern 4: Column Inventory Queries

Find columns by data type or naming pattern across the project. Use when
planning schema changes or checking for naming convention compliance.

```cypher
-- All timestamp columns in mart models (for understanding grain + time spine)
MATCH (m:DbtModel)-[:HAS_COLUMN]->(c:DbtColumn)
WHERE m.layer = 'mart'
  AND toLower(c.data_type) CONTAINS 'timestamp'
RETURN m.name, c.name, c.data_type
ORDER BY m.name, c.name
```

```cypher
-- Columns named *_id across all models (candidate foreign keys)
MATCH (m:DbtModel)-[:HAS_COLUMN]->(c:DbtColumn)
WHERE c.name ENDS WITH '_id'
  AND m.layer IN ['mart', 'intermediate']
RETURN m.name, c.name
ORDER BY c.name, m.name
```

---

## Pattern 5: OpenLineage Runtime Patterns

Query job runs, failures, and error patterns. Use for operational diagnostics
when structured tools don't surface runtime metadata.

```cypher
-- Recent failed runs with error info
MATCH (r:Run {status: 'FAILED'})-[:INSTANCE_OF]->(j:Job)
      -[:WRITES]->(d:Dataset)
OPTIONAL MATCH (r)-[:HAS_ERROR]->(e:Error)
WHERE r.start_time > datetime() - duration('P1D')
RETURN r.id, r.start_time, j.name, d.name, e.error_type, e.pattern
ORDER BY r.start_time DESC
LIMIT 20
```

```cypher
-- Most frequently failing jobs in the last 7 days
MATCH (r:Run {status: 'FAILED'})-[:INSTANCE_OF]->(j:Job)
WHERE r.start_time > datetime() - duration('P7D')
RETURN j.name, COUNT(r) AS failure_count
ORDER BY failure_count DESC
LIMIT 10
```

---

## Anti-Patterns

### Don't use query_graph when a structured tool covers it

```text
BAD:  query_graph("MATCH (m:DbtModel {name: 'fct_revenue'}) RETURN m")
GOOD: get_model_details("model.project.fct_revenue")

BAD:  query_graph("MATCH path = (a)-[:DEPENDS_ON*1..5]->(b) ...")
GOOD: get_relation_lineage(identifier, direction="upstream", depth=5)

BAD:  query_graph("MATCH (t:PhysicalRelation {database: 'PROD'}) ...")
GOOD: get_model_materializations(model_id)  # handles env differences
```

The structured tools return richer formatted data, handle backend differences,
and are faster (indexed lookups vs full traversal).

### Don't hardcode environment-specific values

```text
BAD:  WHERE t.database = 'PROD' AND t.schema = 'ANALYTICS'
GOOD: Use get_model_materializations() to discover the FQN, then filter
```

Materializations vary by environment (dev/staging/prod).

### Avoid unbounded variable-length traversals

```text
BAD:  MATCH path = (a)-[:DEPENDS_ON*]->(b) RETURN path   -- no depth limit
GOOD: MATCH path = (a)-[:DEPENDS_ON*1..8]->(b) RETURN path  -- bounded
```

Unbounded traversals can return huge result sets or time out.
