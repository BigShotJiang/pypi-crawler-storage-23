---
name: upstream-tracing
description: >
  Root cause investigation methodology for DIAGNOSTIC tasks. Covers upstream
  tracing, symptom vs root cause distinction, and anti-patterns.
  REQUIRED for any task involving data issues or discrepancies.
---

# Root Cause Tracing Methodology

## Core Principle

**Never fix at the symptom. Always trace upstream to the source.**

If you find an issue in model A, trace where A gets its data. If A gets it from
B, check B. Keep going upstream until you find the FIRST place the issue
originates.

## The Upstream Tracing Workflow

### Step 1: Confirm the Symptom

```text
run_key_diagnostics(database, schema, table, key_columns)
execute_query(sql)  # validate the reported issue exists
```

### Step 2: Trace Upstream

```text
get_relation_lineage(identifier="model.project.symptom_model", direction="upstream")
trace_column(model_name="symptom_model", column_name="problem_column")
```

### Step 3: Find the Source

Keep tracing upstream until you find where the issue ORIGINATES:

- If column is wrong in model A, check where A gets that column
- If A gets it from B, check B. Keep going upstream.
- The model BEFORE the root cause should be correct

### Step 4: Verify Upstream is Clean

Confirm the model one level above the root cause has correct data.

### Step 5: Propose Fix at Root Cause

Fix at the upstream-most location where the issue originates, not where
the symptom was first observed.

## Anti-Pattern: The Downstream Bandaid

```text
WRONG:
  Symptom: "fct_active_servers is missing binary_edition column"
  Action: Add binary_edition to fct_active_servers SELECT
  Result: FAILED - column existed upstream with 500 'Unknown' values
          Adding it just propagated bad data without addressing WHY

RIGHT:
  Symptom: "fct_active_servers is missing binary_edition column"
  Investigation:
    1. fct_active_servers doesn't select binary_edition
    2. Traced upstream: int_server_active_days_spined HAS binary_edition
    3. 500 rows have 'Unknown' value
    4. Traced further: Unknown comes from COALESCE in int_server_details
       where all three telemetry sources return NULL
  Root cause: 500 servers not sending telemetry to ANY source
  Fix options:
    A. Fix at source (if possible)
    B. Add column with explicit Unknown handling + documentation
```

## Root Cause vs Symptom Checklist

Before proposing ANY fix, verify internally:

- Root cause model identified (not just symptom location)
- Traced upstream - root cause is BEFORE symptom in lineage
- Fix addresses the ROOT CAUSE, not just where the symptom appears
- Downstream impact assessed (`get_downstream_impact`)
- The model upstream of root cause is clean

## Fix Location Check

Are you fixing at the RIGHT level?

- Prefer fixing UPSTREAM (closer to source) over DOWNSTREAM (closer to dashboard)
- A downstream fix might mask the real issue and cause problems elsewhere
- If the root cause is in source data (can't be fixed), document the handling
  explicitly in the nearest downstream model

## Verdict Format

When returning investigation results, always include:

```text
## Verdict: CONFIRMED / REFUTED / INCONCLUSIVE

## Root Cause Location
- **Symptom model**: [where the issue was first observed]
- **Root cause model**: [where the issue ORIGINATES]
- **Root cause explanation**: [why the issue happens at this location]

## Upstream Trace
- Traced from [symptom] -> [intermediate] -> [root_cause]
- Issue first appears in: [root_cause_model]
- Upstream of root cause is clean: Yes/No
```
