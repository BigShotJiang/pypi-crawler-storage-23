---
name: risk-analysis
description: >
  Five-dimension change risk assessment framework. Load before presenting
  plans for MODERATE or COMPLEX tasks to ensure thorough risk evaluation.
---

# Change Risk Analysis Framework

## Five Risk Dimensions

Before presenting any plan, analyze each dimension:

### 1. Downstream Impact

Which models depend on the one being changed?

- Use `get_downstream_impact(model_id)` to check blast radius
- List all affected models by depth level
- More downstream models = higher risk

### 2. Environment/Schema Verification

Critical for data fixes:

- Check materialization info for exact schema name
- Note the exact database.schema.table in the plan
- Include a step to verify schema before and after changes

### 3. Data Contracts

Are there tests or constraints that might break?

- Review test info (`get_model_details(model_id, include_tests=True)`)
- Check for unique, not_null, relationships tests
- Changes that violate existing tests need the tests updated too

### 4. Breaking Changes

Could this change break existing dashboards or consumers?

- Column renames are BREAKING
- Column removals are BREAKING
- Type changes MAY be breaking
- Adding columns is generally safe

### 5. Rollback Strategy

How can we undo if something goes wrong?

- Git revert for code changes
- `--full-refresh` for materialization issues
- Document the rollback steps in the plan

## Risk Levels

| Level      | Criteria                                                   | Action                                 |
| ---------- | ---------------------------------------------------------- | -------------------------------------- |
| **LOW**    | Single model, no downstream impact, additive change        | Proceed with basic verification        |
| **MEDIUM** | 2-3 downstream models, logic change, tests exist           | Full verification + downstream rebuild |
| **HIGH**   | Many downstream models, breaking change, production impact | Staged rollout + monitoring            |

## Internal Checklist

Complete before presenting plan to user:

**For ALL tasks:**

```text
- Root cause model identified (not just symptom location)
- Traced upstream - root cause is BEFORE symptom in lineage
- If key/join issue - ran relationship health check
- Downstream impact assessed (get_downstream_impact)
- Risk level determined (LOW/MEDIUM/HIGH)
```

**For MODERATE/COMPLEX tasks (additional):**

```text
- Structured plan created using planner
- Plan includes specific steps with dependencies
- Plan includes verification query for each step
- Plan includes risk assessment per step
- Plan is ready to present as the approval artifact
```

Do NOT present to user until all applicable items are checked.
For MODERATE/COMPLEX: The PLAN is what you present, not a verbal summary.

## Common Pitfalls

1. **Skipping impact analysis** — Always check downstream before proposing changes
2. **Verbal summary instead of plan** — For MODERATE/COMPLEX, use planner
3. **Presenting plan = getting approval** — Explicitly ask and WAIT for "yes"
4. **Not verifying the SYMPTOM** — Code compiles but original issue persists
