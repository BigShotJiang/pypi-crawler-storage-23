---
name: diagnostic-workflow
description: >
  Full diagnostic workflow for data quality issues, test failures, wrong counts, and
  metric anomalies. Load when task is classified as DIAGNOSTIC. Covers 5 phases from
  data path mapping through root cause confirmation and mechanic handoff. Also load
  upstream-tracing (required) and data-quality-diagnostics (for key/join issues).
---

# Diagnostic Workflow

## Prerequisite Skills

Load these before starting work:

- `load_skill("upstream-tracing")` — required before calling mechanic
- `load_skill("data-quality-diagnostics")` — required for key duplication or join orphan symptoms

---

## Phase 1: Map the Data Path (DIRECT — BEFORE forming hypotheses)

1. Use `get_relation_lineage` on the model mentioned in the symptom to map its upstream DAG
2. Note the chain: source → staging → intermediate → mart
3. THEN form hypotheses — informed by the actual data flow, not just model names
4. For simple checks (1-2 queries), validate DIRECTLY without spawning a diagnostician

---

## Phase 2: Upstream Tracing (DIAGNOSTICIAN)

Frame prompts as TRACING tasks, not hypothesis confirmation:

```text
# GOOD: Trace-oriented — diagnostician checks each layer
task(name="diagnostician", prompt="""
Trace the source of [symptom] in [model].
The upstream DAG is: [model] ← [intermediate] ← [staging] ← [source].
Check each layer with run_key_diagnostics to find where the issue FIRST appears.
Then read the SQL of that model to identify the specific bug.
Return the root cause model and the exact SQL/logic that causes it.
""")

# GOOD: Comparative — check a specific boundary
task(name="diagnostician", prompt="""
Check whether [intermediate_model] is producing clean output.
Run key diagnostics on it AND its upstream inputs.
If [intermediate_model] is broken but its inputs are clean, read its SQL to find
the transformation bug. If its inputs are also broken, report that the issue is
further upstream.
""")

# BAD: Hypothesis-confirming — biases toward a specific answer
task(name="diagnostician", prompt="Investigate H1: the spine model is inserting
     extra rows because of inactive server records...")
```

---

## Phase 3: Root Cause Confirmation (DIRECT)

- Synthesize diagnostician findings
- Confirm the root cause model has CLEAN INPUTS but BROKEN OUTPUT
- If diagnostician found the symptom but not the source, spawn another one level further upstream
- Verify the fix location is UPSTREAM enough (not a downstream bandaid)
- Complete the Mechanic Handoff Checklist below before proceeding
- **IMMEDIATELY proceed to Phase 4** — do not pause

---

## Phase 4: Execute Fix (MECHANIC)

```text
task(name="mechanic", prompt="""
Fix [root cause model].

Root cause: [confirmed root cause with evidence]
File: [path/to/model.sql]
Change: [specific edit to make]
Verify: [query to confirm fix]

Steps:
1. Read file, make edit
2. dbt_compile to check syntax
3. dbt_build to materialize and test
4. execute_query to verify in warehouse
5. ALWAYS git_add + git_commit with a descriptive message — this is REQUIRED, not optional
""")
```

---

## Phase 5: Verification (DIRECT or MECHANIC)

- Query warehouse to confirm fix
- Verify the SYMPTOM is resolved (not just the code changed)

---

## Mechanic Handoff Checklist

Confirm all before calling mechanic:

1. Root cause model identified (not just symptom location)
2. Root cause is upstream of where symptom appears
3. Clear fix description
4. Expected outcome (measurable)
5. Verification query to confirm fix worked
6. Relationship health check completed when applicable
7. Mechanic prompt explicitly includes git_add + git_commit as a required step

---

## Wrong vs Right: Downstream Bandaid vs Root Cause

**WRONG — downstream bandaid:**

```text
Symptom: "Edition breakdown missing 500 servers"

Agent: I'll add binary_edition to fct_active_servers.
task(name="mechanic", prompt="Add binary_edition column to fct_active_servers")

Problem: The 500 servers HAVE binary_edition='Unknown' upstream.
Adding the column just propagates the Unknown values.
The root cause is WHY those servers have Unknown.
```

**RIGHT — root cause fix:**

```text
Symptom: "Edition breakdown missing 500 servers"

Phase 1: get_model_details("model.project.fct_active_servers")
-> binary_edition not selected

Phase 2: task(name="diagnostician", prompt="Trace binary_edition upstream.
     Find where it originates and why 500 servers might be missing.")

Diagnostician returns: int_server_active_days_spined has binary_edition.
500 servers have 'Unknown' value. Traced to COALESCE in int_server_details
where all three telemetry sources return NULL.

Phase 3: Root cause confirmed
- Root cause: 500 servers not sending telemetry data to ANY source
- Decision: Cannot fix source data. Will add explicit handling for Unknown values
  in fct_active_servers so the metric accurately reflects data quality.

Mechanic Handoff Checklist:
- [x] Root cause model: int_server_details
- [x] Root cause is upstream of symptom: Yes
- [x] Fix: Add binary_edition to SELECT with explicit Unknown handling
- [x] Expected outcome: COUNT should match when excluding Unknown
- [x] Verify: SELECT binary_edition, COUNT(*) should show Unknown count = 500

Phase 4: task(name="mechanic", prompt="Fix fct_active_servers edition breakdown.
     Root cause: 500 servers have Unknown edition from missing telemetry.
     Fix: Add binary_edition to SELECT with comment explaining Unknown values.
     Verify: SELECT binary_edition, COUNT(*) should show Unknown count = 500")
```
