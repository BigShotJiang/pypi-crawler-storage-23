"""Hybrid dependency types for pydantic-deepagents integration.

This module provides CopilotDeps which extends pydantic-deep's DeepAgentDeps
with our custom backend integrations (lineage, data_backend, etc.).

Used by the deep orchestrator factories for copilot and reconciler agents.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Optional

from pydantic_ai.usage import RunUsage
from pydantic_deep import DeepAgentDeps

from lineage.agent.pydantic.types import AgentState, FileSystemConfig
from lineage.backends.blobs.protocol import BlobStorage
from lineage.backends.config import GitConfig
from lineage.backends.data_query.protocol import DataQueryBackend
from lineage.backends.lineage.protocol import LineageStorage
from lineage.backends.memory.protocol import MemoryStorage
from lineage.backends.reports.protocol import ReportsBackend
from lineage.backends.threads.protocol import ThreadsBackend
from lineage.backends.tickets.protocol import TicketStorage

try:
    from ag_ui.core import BaseEvent

    AG_UI_AVAILABLE = True
except ImportError:  # pragma: no cover
    AG_UI_AVAILABLE = False
    BaseEvent = Any  # type: ignore


@dataclass
class CopilotDeps(DeepAgentDeps):
    """Hybrid deps extending DeepAgentDeps with our custom backend integrations.

    This class combines:
    - pydantic-deep's base fields (backend, files, todos, subagents, uploads)
    - Our backend integrations (lineage, data_backend, memory, tickets, etc.)
    - Session tracking (thread_id, run_id, user_id, org_id)
    - AG-UI state (AgentState for generative UI)
    - Configuration (filesystem_config, git_config)

    Used by both copilot (interactive) and reconciler (autonomous) orchestrators.
    """

    # =========================================================================
    # Our backend integrations
    # =========================================================================

    lineage: Optional[LineageStorage] = None
    """Lineage graph backend for querying model dependencies and semantics."""

    data_backend: Optional[DataQueryBackend] = None
    """Data warehouse backend for executing SQL queries."""

    memory_backend: Optional[MemoryStorage] = None
    """Memory backend for persistent user/org memory."""

    ticket_storage: Optional[TicketStorage] = None
    """Ticket storage backend for work tracking."""

    reports_backend: Optional[ReportsBackend] = None
    """Reports backend for saving generated reports."""

    threads_backend: Optional[ThreadsBackend] = None
    """Threads backend for multi-run context persistence."""

    blob_storage: Optional[BlobStorage] = None
    """Blob storage for persisting query results across subagent boundaries."""

    # =========================================================================
    # Session tracking
    # =========================================================================

    thread_id: str = ""
    """Thread ID for session tracking."""

    run_id: str = ""
    """Run ID for this specific agent run."""

    user_id: Optional[str] = None
    """User ID for user-specific memory."""

    org_id: str = "default"
    """Organization ID for shared memory."""

    agent_name: str = "data_engineer_copilot"
    """Name of the agent (for logging and identification)."""

    # =========================================================================
    # State and context
    # =========================================================================

    state: AgentState = field(default_factory=AgentState)
    """AG-UI state for generative UI rendering (tool_results, thinking_blocks, etc.)."""

    # =========================================================================
    # Copilot-specific configuration
    # =========================================================================

    filesystem_config: Optional[FileSystemConfig] = None
    """Filesystem configuration (working_directory, allowed_paths, read_only)."""

    git_config: Optional[GitConfig] = None
    """Git configuration (enabled, repo_path, default_branch, etc.)."""

    # =========================================================================
    # UI event injection (for subagent highlights in TUI)
    # =========================================================================

    ui_event_queue: asyncio.Queue[BaseEvent] | None = field(
        default_factory=asyncio.Queue if AG_UI_AVAILABLE else lambda: None
    )
    """Optional queue for injecting additional AG-UI BaseEvents into the parent SSE stream.

    This enables long-running tools (e.g. subagent delegation via `task()`) to publish
    progress/highlight events while the parent tool call is still executing.
    """

    cancellation_event: asyncio.Event = field(default_factory=asyncio.Event)
    """Event signaled when the agent run should be cancelled.

    Shared between parent and all subagents. Tools should check is_cancelled periodically.
    """

    # =========================================================================
    # Tool call tracking (for benchmark reporting)
    # =========================================================================

    subagent_tool_call_counts: dict[str, dict[str, int]] = field(default_factory=dict)
    """Accumulated tool call counts by subagent.

    Structure: {subagent_name: {tool_name: count, ...}, ...}

    Populated by streaming_subagents.py after each subagent completes.
    Used by benchmark to emit per-agent tool call counts to Logfire.
    """

    subagent_tool_call_sequences: dict[str, list[tuple[str, str]]] = field(default_factory=dict)
    """Ordered tool call sequences by subagent.

    Structure: {subagent_name: [(tool_name, args_json), ...], ...}

    Populated by streaming_subagents.py alongside counts. Used by benchmark
    trajectory evaluator to assess subagent strategy quality.
    """

    subagent_usage: dict[str, list[tuple[str, RunUsage]]] = field(default_factory=dict)
    """Per-subagent usage tracking for cost calculation.

    Structure: {subagent_name: [(model_string, RunUsage), ...], ...}

    Each subagent invocation appends its model string and RunUsage so the
    benchmark can calculate accurate per-model costs (important when
    specialist_models assigns different models to different subagents).
    """

    @property
    def is_cancelled(self) -> bool:
        """Check if cancellation has been requested."""
        return self.cancellation_event.is_set()

    def request_cancellation(self) -> None:
        """Signal that this agent run should be cancelled."""
        self.cancellation_event.set()

    # =========================================================================
    # Subagent cloning
    # =========================================================================

    def clone_for_subagent(self) -> "CopilotDeps":
        """Create a new deps instance for a subagent.

        This override is CRITICAL - without it, pydantic-deep's base class returns
        a plain DeepAgentDeps that lacks our custom fields (lineage, data_backend,
        state, etc.), causing 'DeepAgentDeps has no attribute lineage' errors.

        Subagents get:
        - Same backends (shared: lineage, data_backend, memory, tickets, reports, blobs)
        - Same state (shared: for AG-UI rendering)
        - Same configurations (shared: filesystem_config, git_config)
        - Same session info (shared: thread_id, run_id, user_id, org_id)
        - Empty pydantic-deep subagents dict (no nested delegation)
        - Fresh pydantic-deep todos list (isolated per specialist)
        """
        return CopilotDeps(
            # pydantic-deep base fields
            backend=self.backend,
            files=self.files,  # Shared reference
            todos=[],  # Fresh todo list for specialist
            subagents={},  # No nested subagents
            uploads=self.uploads,  # Shared reference
            # Our backend integrations (SHARED - critical for tools to work)
            lineage=self.lineage,
            data_backend=self.data_backend,
            memory_backend=self.memory_backend,
            ticket_storage=self.ticket_storage,
            reports_backend=self.reports_backend,
            threads_backend=self.threads_backend,
            blob_storage=self.blob_storage,
            # Session tracking (SHARED - same session)
            thread_id=self.thread_id,
            run_id=self.run_id,
            user_id=self.user_id,
            org_id=self.org_id,
            agent_name=self.agent_name,
            # State (SHARED - for AG-UI and coordinated state)
            state=self.state,
            # Configuration (SHARED - same workspace)
            filesystem_config=self.filesystem_config,
            git_config=self.git_config,
            # UI event injection (SHARED - so subagents can publish highlights)
            ui_event_queue=self.ui_event_queue,
            # Cancellation (SHARED - same event instance for coordinated cancellation)
            cancellation_event=self.cancellation_event,
            # Tool call tracking (SHARED - accumulated across all subagents)
            subagent_tool_call_counts=self.subagent_tool_call_counts,
            subagent_tool_call_sequences=self.subagent_tool_call_sequences,
            subagent_usage=self.subagent_usage,
        )
