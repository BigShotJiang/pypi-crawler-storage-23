"""Custom AG-UI handler with thinking block support.

This module wraps PydanticAI's handle_ag_ui_request to capture extended thinking
blocks from Claude's reasoning process and store them in state for frontend rendering.
State updates are automatically emitted via AG-UI protocol state_update events.
"""

import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Any, AsyncIterator, Optional

from fastapi import Request
from fastapi.responses import StreamingResponse
from pydantic_ai import Agent
from pydantic_ai.ag_ui import OnCompleteFunc
from pydantic_ai.ag_ui import handle_ag_ui_request as _handle_ag_ui_request
from pydantic_ai.messages import ModelResponse, ThinkingPart

from .types import AgentState, ThinkingBlock

logger = logging.getLogger(__name__)
MAX_ERROR_MESSAGE_LENGTH = 300

try:
    from ag_ui.core import BaseEvent
    from ag_ui.encoder import EventEncoder

    AG_UI_AVAILABLE = True
except ImportError:  # pragma: no cover
    AG_UI_AVAILABLE = False
    BaseEvent = Any  # type: ignore
    EventEncoder = None  # type: ignore


async def handle_ag_ui_request_with_event_injection(
    agent: Agent,
    request: Request,
    deps: Any,
    *,
    on_complete: Optional[Any] = None,
) -> StreamingResponse:
    """Handle AG-UI request, allowing long-running tools to inject additional events.

    PydanticAI's AG-UI adapter only emits tool-call events for the *current* agent run.
    When the agent is executing a long-running tool (e.g. `task()` delegation), the
    SSE stream may be quiet until the tool returns.

    This wrapper allows tools to publish additional AG-UI `BaseEvent`s to a shared
    queue on deps (`deps.ui_event_queue`), and multiplexes those into the live SSE
    stream so the TUI can show progress/highlights.
    """
    response = await _handle_ag_ui_request(agent, request, deps=deps, on_complete=on_complete)

    if not AG_UI_AVAILABLE:
        return response

    ui_event_queue: asyncio.Queue[BaseEvent] | None = getattr(deps, "ui_event_queue", None)
    if ui_event_queue is None:
        return response

    # If we can't stream bytes, fall back to the original response.
    base_iter = getattr(response, "body_iterator", None)
    if base_iter is None:
        return response

    encoder = EventEncoder(accept=request.headers.get("accept") or "text/event-stream")

    async def _mux_body() -> AsyncIterator[bytes]:
        base_done = False
        base_task: asyncio.Task[bytes] | None = asyncio.create_task(anext(base_iter))
        event_task: asyncio.Task[BaseEvent] | None = asyncio.create_task(ui_event_queue.get())

        try:
            while True:
                # Stop streaming as soon as the client disconnects.
                try:
                    if await request.is_disconnected():
                        logger.info("Client disconnected; signalling cancellation")
                        if hasattr(deps, "request_cancellation"):
                            deps.request_cancellation()
                        break
                except Exception:
                    # If disconnect check fails, continue streaming rather than crashing.
                    logger.debug("Disconnect check failed", exc_info=True)

                tasks = [t for t in (base_task, event_task) if t is not None]
                if not tasks:
                    break

                done, _pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)

                if base_task is not None and base_task in done:
                    try:
                        chunk = base_task.result()
                        yield chunk
                        base_task = asyncio.create_task(anext(base_iter))
                    except StopAsyncIteration:
                        base_task = None
                        base_done = True

                if event_task is not None and event_task in done:
                    try:
                        event = event_task.result()
                        if isinstance(event, BaseEvent):
                            yield encoder.encode(event).encode("utf-8")
                    finally:
                        # Always re-arm the event task unless we've already finished.
                        if not base_done:
                            event_task = asyncio.create_task(ui_event_queue.get())

                if base_done:
                    # Drain any remaining queued events without blocking.
                    while True:
                        try:
                            event = ui_event_queue.get_nowait()
                        except asyncio.QueueEmpty:
                            break
                        if isinstance(event, BaseEvent):
                            yield encoder.encode(event).encode("utf-8")

                    if event_task is not None:
                        event_task.cancel()
                    break
        finally:
            # Signal cancellation to any running subagents
            if hasattr(deps, "request_cancellation"):
                deps.request_cancellation()
            for t in (base_task, event_task):
                if t is not None and not t.done():
                    t.cancel()

    return StreamingResponse(
        _mux_body(),
        media_type=response.media_type,
        headers=dict(response.headers),
    )


async def handle_ag_ui_request_with_thinking(
    agent: Agent,
    request: Request,
    deps: any,
    on_complete: OnCompleteFunc | None = None,
) -> StreamingResponse:
    """Custom AG-UI handler that captures thinking blocks.

    This wraps PydanticAI's standard handler to:
    1. Extract thinking blocks from conversation history after run
    2. Store thinking in deps.state.thinking_blocks
    3. State updates are automatically emitted via AG-UI protocol

    Args:
        agent: PydanticAI agent to run
        request: FastAPI request with AG-UI protocol data
        deps: Dependencies containing AgentState
        on_complete: Optional callback invoked after the run completes

    Returns:
        StreamingResponse with AG-UI protocol events (state updates handled automatically)
    """
    logger.info("Handling AG-UI request with thinking block capture")

    # Get the original response
    response = await _handle_ag_ui_request(agent, request, deps=deps, on_complete=on_complete)

    # After the response completes, extract thinking from conversation history
    # Wrap the response to extract thinking and update state
    return StreamingResponse(
        _inject_thinking_extraction(response.body_iterator, deps.state, agent),
        media_type=response.media_type,
        headers=dict(response.headers),
    )


async def _inject_thinking_extraction(
    stream: AsyncIterator[bytes],
    state: AgentState,
    agent: Agent,
) -> AsyncIterator[bytes]:
    """Inject thinking block extraction into the response stream.

    This yields all original chunks, then after the stream completes,
    extracts thinking blocks from the conversation history and stores them in state.
    State updates are automatically emitted via AG-UI protocol.

    Args:
        stream: Original AG-UI response stream
        state: AgentState to store thinking blocks
        agent: Agent instance to access conversation history

    Yields:
        Original bytes (state updates handled automatically by PydanticAI)
    """
    # Track seen thinking blocks to avoid duplicates
    seen_thinking_hashes = set()

    # Process stream and pass through all chunks
    try:
        async for chunk in stream:
            yield chunk
    except asyncio.CancelledError:
        logger.info("AG-UI stream cancelled while injecting thinking blocks")
        return
    except Exception as e:
        logger.error("❌ Error while streaming AG-UI response", exc_info=True)
        error_message = str(e).strip() or "Unknown error"
        if len(error_message) > MAX_ERROR_MESSAGE_LENGTH:
            error_message = f"{error_message[:MAX_ERROR_MESSAGE_LENGTH]}..."
        error_event = {"type": "RUN_ERROR", "error": error_message}
        try:
            yield f"data: {json.dumps(error_event)}\n\n".encode()
        except Exception:
            logger.error(
                "❌ Failed to emit structured error event for AG-UI response",
                exc_info=True,
            )
            # Fallback: attempt to send a minimal, hard-coded error payload
            fallback_event = {
                "type": "RUN_ERROR",
                "error": "An unexpected error occurred.",
            }
            try:
                yield f"data: {json.dumps(fallback_event)}\n\n".encode()
            except Exception:
                # Last resort: yield a static, already-encoded error message
                yield (
                    b'data: {"type": "RUN_ERROR", "error": "An unexpected error occurred."}'
                    b"\n\n"
                )
    finally:
        # After stream completes, extract thinking from conversation history
        logger.info("Stream complete, extracting thinking blocks from conversation history")

        try:
            # Try multiple approaches to access conversation history
            messages_to_check = []

            # Approach 1: Check _current_messages (PydanticAI internal)
            if hasattr(agent, "_current_messages") and agent._current_messages:
                messages_to_check = agent._current_messages
                logger.info(f"Found {len(messages_to_check)} messages via _current_messages")
            # Approach 2: Check if there's a messages attribute
            elif hasattr(agent, "messages") and agent.messages:
                messages_to_check = agent.messages
                logger.info(f"Found {len(messages_to_check)} messages via messages")
            # Approach 3: Check state for messages
            elif hasattr(state, "messages") and state.messages:
                messages_to_check = state.messages
                logger.info(f"Found {len(messages_to_check)} messages via state.messages")

            # Extract thinking from messages and update state
            for msg in messages_to_check:
                logger.debug(f"Checking message type: {type(msg).__name__}")
                if isinstance(msg, ModelResponse):
                    # Check if this message has thinking parts
                    thinking_content = extract_thinking_from_response(msg)
                    if thinking_content:
                        logger.info(
                            f"Found {len(thinking_content)} thinking blocks in message"
                        )
                        for thinking in thinking_content:
                            # Use hash to avoid duplicates
                            thinking_hash = hash(thinking)
                            if thinking_hash in seen_thinking_hashes:
                                logger.debug("Skipping duplicate thinking block")
                                continue
                            seen_thinking_hashes.add(thinking_hash)

                            # Store thinking block in state (triggers automatic state_update event)
                            thinking_block = ThinkingBlock(
                                content=thinking,
                                timestamp=datetime.now(timezone.utc),
                            )
                            state.thinking_blocks.append(thinking_block)
                            logger.info(
                                f"✅ Stored thinking block in state ({len(thinking)} chars)"
                            )

        except Exception as e:
            logger.error(f"❌ Error extracting thinking blocks: {e}", exc_info=True)


def extract_thinking_from_response(response: ModelResponse) -> list[str]:
    """Extract thinking content from a model response.

    Args:
        response: ModelResponse from PydanticAI

    Returns:
        List of thinking content strings
    """
    thinking_blocks = []
    for part in response.parts:
        if isinstance(part, ThinkingPart):
            thinking_blocks.append(part.content)
    return thinking_blocks
