"""Utility helpers for configuring agents and updating preview state."""

from __future__ import annotations

import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Union
from uuid import uuid4

import pydantic_core
from anthropic import AsyncAnthropicBedrock
from anthropic.types.beta import BetaThinkingConfigEnabledParam
from pydantic_ai.messages import ModelMessage, ModelResponse, ToolCallPart
from pydantic_ai.models import Model
from pydantic_ai.models.anthropic import AnthropicModel, AnthropicModelSettings
from pydantic_ai.models.google import GoogleModel, GoogleModelSettings
from pydantic_ai.models.openai import (
    OpenAIResponsesModel,
    OpenAIResponsesModelSettings,
)
from pydantic_ai.models.openrouter import (
    OpenRouterModel,
    OpenRouterModelSettings,
    OpenRouterReasoning,
)
from pydantic_ai.providers.anthropic import AnthropicProvider

from lineage.agent.pydantic.types import AgentState

logger = logging.getLogger(__name__)


def sanitize_tool_call_args(messages: list[ModelMessage]) -> list[ModelMessage]:
    """History processor that fixes ToolCallParts with invalid/truncated JSON args.

    When a model returns truncated JSON (e.g., due to output token limit), pydantic-ai
    stores the raw broken string in the ToolCallPart. On the next turn, the Anthropic
    adapter calls ``args_as_dict()`` which crashes with ``ValueError`` on invalid JSON
    because ``pydantic_core.from_json()`` cannot parse the truncated string.

    This processor replaces broken JSON args with an empty dict so the conversation
    history can be safely re-serialized for the next API call.

    Use as ``history_processors=[sanitize_tool_call_args]`` on any Agent.
    """
    for message in messages:
        if isinstance(message, ModelResponse):
            for part in message.parts:
                if isinstance(part, ToolCallPart) and isinstance(part.args, str) and part.args:
                    try:
                        pydantic_core.from_json(part.args)
                    except ValueError:
                        logger.warning(
                            "Sanitized invalid JSON args for tool %s (call_id=%s)",
                            part.tool_name,
                            part.tool_call_id,
                        )
                        part.args = {}
    return messages


def _create_bedrock_model(model_spec: str) -> AnthropicModel:
    """Create a Bedrock-backed AnthropicModel using AsyncAnthropicBedrock.

    Uses the Anthropic SDK's native Bedrock client (AsyncAnthropicBedrock) instead
    of the Converse API, providing better compatibility with Anthropic model features.

    Args:
        model_spec: Model specification after 'bedrock:' prefix.
            Expected formats:
                - us.anthropic.claude-sonnet-4-20250514-v1:0 (cross-region model ID)
                - arn:aws:bedrock:us-west-2:ACCOUNT:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0

    Returns:
        Configured AnthropicModel instance backed by Bedrock.

    Note:
        We use AsyncAnthropicBedrock (Anthropic SDK) instead of BedrockConverseModel
        (Converse API) because pydantic-ai doesn't preserve thinking blocks in
        multi-turn conversation history, causing Bedrock Converse validation errors.
        The Anthropic SDK client avoids this issue entirely.
        See: https://github.com/pydantic/pydantic-ai/issues/3757

    AWS credentials are resolved via boto3's default credential chain:
        - Environment variables (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY)
        - AWS credentials file (~/.aws/credentials)
        - AWS_PROFILE environment variable
        - IAM role (when running on AWS infrastructure)
    """
    # Extract region from ARN if provided
    if model_spec.startswith("arn:aws:bedrock"):
        arn_parts = model_spec.split(":")
        if len(arn_parts) >= 4:
            region = arn_parts[3]
        else:
            region = os.environ.get("AWS_DEFAULT_REGION") or os.environ.get("AWS_REGION", "us-west-2")

        # Extract the model ID from the ARN (after the last /)
        # e.g. arn:aws:bedrock:us-west-2:ACCOUNT:inference-profile/us.anthropic.claude-sonnet-4-20250514-v1:0
        model_id = model_spec.rsplit("/", 1)[-1] if "/" in model_spec else model_spec
        logger.info(f"Bedrock ARN: region={region}, model_id={model_id}")
    elif "/" in model_spec:
        # Legacy format: region/model-id
        region, model_id = model_spec.split("/", 1)
        logger.info(f"Bedrock legacy format: region={region}, model_id={model_id}")
    else:
        # Bare model ID
        model_id = model_spec
        region = os.environ.get("AWS_DEFAULT_REGION") or os.environ.get("AWS_REGION", "us-west-2")
        logger.info(f"Bedrock bare model ID: region={region}, model_id={model_id}")

    if not region or not region.startswith(("us-", "eu-", "ap-", "ca-", "sa-")):
        logger.warning(f"Region '{region}' may be invalid")

    auth_method = "AWS_PROFILE" if os.environ.get("AWS_PROFILE") else "IAM role"
    logger.info(f"Creating AsyncAnthropicBedrock client in {region} using {auth_method} credentials")

    bedrock_client = AsyncAnthropicBedrock(aws_region=region)
    provider = AnthropicProvider(anthropic_client=bedrock_client)

    return AnthropicModel(
        model_id,
        provider=provider,
        settings=AnthropicModelSettings(
            anthropic_cache_instructions=True,
            anthropic_cache_tool_definitions=True,
            anthropic_cache_messages=True,
            parallel_tool_calls=True,
            anthropic_thinking=BetaThinkingConfigEnabledParam(
                type="enabled",
                budget_tokens=2048
            ),
        ),
    )


def create_model(model: str) -> Union[Model, str]:
    """Create a configured PydanticAI model from a shorthand identifier.

    Supported formats:
        anthropic:claude-sonnet-4-5
        openai:gpt-4o
        google:gemini-1.5-pro
        gateway/anthropic:claude-sonnet-4-5 (via proxy)
        bedrock:anthropic.claude-3-sonnet-20240229-v1:0
        bedrock:us-west-2/anthropic.claude-3-sonnet-20240229-v1:0 (with region)
        bedrock:arn:aws:bedrock:... (profile ARN)

    Args:
        model: Model identifier string.

    Note:
        Bedrock models use AsyncAnthropicBedrock (Anthropic SDK) instead of
        BedrockConverseModel (Converse API) because pydantic-ai doesn't preserve
        thinking blocks in multi-turn conversation history, causing Converse
        validation errors. The Anthropic SDK client avoids this issue.
        See: https://github.com/pydantic/pydantic-ai/issues/3757
    """
    # Handle bedrock specially since model IDs contain colons
    if model.startswith("bedrock:"):
        model_spec = model[8:]  # Remove "bedrock:" prefix
        return _create_bedrock_model(model_spec)

    # Standard parsing for other providers: [provider/]family:name
    provider_parts = model.split("/")
    provider = None
    model_name_family = provider_parts[0]
    if len(provider_parts) > 1:
        provider = provider_parts[0]
        model_name_family =  provider_parts[1]
    parts = model_name_family.split(":")
    if not len(parts) == 2:
        raise ValueError(f"Invalid model name: {model_name_family}")
    family = parts[0]
    name = parts[1]
    if not provider:
        provider = family

    logger.debug(f"detected from: {model}, {provider}/{family}:{name}")
    # Per-request timeout (seconds) prevents a single API call from hanging
    # indefinitely.  Codex models in particular can stall for 20+ minutes on a
    # single streaming request before the server returns an error.  180 s is
    # generous enough for large reasoning responses but catches true hangs.
    _REQUEST_TIMEOUT: float = 180

    if provider == "openrouter":
        return OpenRouterModel(f"{family}/{name}", settings=OpenRouterModelSettings(
            parallel_tool_calls=True,
            timeout=_REQUEST_TIMEOUT,
            openrouter_reasoning=OpenRouterReasoning(
                effort="medium",
            ),
        ),
    )
    if family == "anthropic":
        return AnthropicModel(
            name,
            settings=AnthropicModelSettings(
                anthropic_cache_instructions=True,
                anthropic_cache_tool_definitions=True,
                anthropic_cache_messages=True,
                parallel_tool_calls=True,
                timeout=_REQUEST_TIMEOUT,
                anthropic_thinking=BetaThinkingConfigEnabledParam(
                    type="enabled",
                    budget_tokens=2048
            ),
        ),
        provider=provider
    )
    elif family == "openai":
        return OpenAIResponsesModel(name, settings=OpenAIResponsesModelSettings(
            parallel_tool_calls=True,
            timeout=_REQUEST_TIMEOUT,
            openai_reasoning_effort="medium",
            openai_reasoning_summary="auto",
        ),
            provider=provider,
            )
    elif family == "google":
        return GoogleModel(name, settings=GoogleModelSettings(
            parallel_tool_calls=True,
            timeout=_REQUEST_TIMEOUT,
            google_thinking_config={'include_thoughts': True, 'thinking_budget': -1},
        ),
        provider=provider,
    )
    else:
        logger.warning(f"Unknown model family: {family}")
        return model


def push_preview_tab(
    state: AgentState,
    *,
    title: str,
    tool_name: str,
    tab_type: str,
    data: Dict[str, Any],
    tab_id: Optional[str] = None,
    auto_open: bool = False,
    max_tabs: int = 20,
) -> str:
    """Append or update a preview tab entry in agent state."""
    if not state:
        return ""

    entry_id = tab_id or f"preview_{uuid4().hex[:10]}"
    timestamp = datetime.now(timezone.utc).isoformat()

    tab_entry: Dict[str, Any] = {
        "id": entry_id,
        "title": title,
        "toolName": tool_name,
        "tabType": tab_type,
        "timestamp": timestamp,
        "data": data,
        "autoOpen": auto_open,
    }

    state.preview_tabs = [
        tab for tab in state.preview_tabs if tab.get("id") != entry_id
    ]
    state.preview_tabs.append(tab_entry)

    if len(state.preview_tabs) > max_tabs:
        state.preview_tabs = state.preview_tabs[-max_tabs:]

    return entry_id
