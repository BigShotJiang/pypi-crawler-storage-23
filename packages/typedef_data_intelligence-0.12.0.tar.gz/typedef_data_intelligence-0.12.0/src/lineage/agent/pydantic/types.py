"""Pydantic types for agent state and dependencies.

This module defines the state models and dependency structures used by
PydanticAI agents, including tool results, thinking blocks, and report previews.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field
from pydantic_ai import Tool

from lineage.backends.blobs.protocol import BlobStorage
from lineage.backends.config import GitConfig
from lineage.backends.data_query.protocol import DataQueryBackend
from lineage.backends.lineage.protocol import (
    ColumnLineageResult as ProtocolColumnLineageResult,
)
from lineage.backends.lineage.protocol import (
    GraphSchemaFormat,
    LineageNode,
    LineageStorage,
)
from lineage.backends.lineage.protocol import (
    ModelMaterializationsResult as ProtocolModelMaterializationsResult,
)
from lineage.backends.lineage.protocol import (
    RelationLineageResult as ProtocolRelationLineageResult,
)
from lineage.backends.memory.protocol import MemoryStorage
from lineage.backends.reports.protocol import CellData, ReportsBackend
from lineage.backends.threads.protocol import ThreadsBackend
from lineage.backends.tickets.protocol import TicketStorage

# ============================================================================
# Filesystem Configuration
# ============================================================================


@dataclass
class FileSystemConfig:
    """Configuration for filesystem operations.

    Attributes:
        working_directory: Base directory for file operations (all paths relative to this)
        allowed_paths: Additional allowed paths outside working_directory (optional whitelist)
        read_only: If True, only read operations are allowed (for safer evaluation)
    """

    working_directory: Path
    allowed_paths: List[Path] = field(default_factory=list)
    read_only: bool = False


# ============================================================================
# Agent Configuration
# ============================================================================


@dataclass
class AgentConfig:
    """Configuration for creating a PydanticAI agent.

    This dataclass encapsulates all the variable aspects of agent creation,
    allowing for easy creation of custom agents for evaluations and testing.

    Attributes:
        prompt_name: Name of the prompt to load (e.g., "data_analyst", "data_quality")
        toolsets: List of toolsets to include in the agent
        tools: Optional list of direct tools (e.g., [Tool(execute_query)])
        retries: Number of retries for the agent (default: 2)
        agent_name: Name for the agent (used in AgentDeps)
        prompt_kwargs: Optional dict of extra kwargs to pass to load_prompt
        tool_white_list: If set, only keep toolsets whose names are in this list
        tool_black_list: If set, remove toolsets whose names are in this list
        individual_tool_white_list: If set, only keep individual tools in this list
        individual_tool_black_list: If set, remove individual tools in this list
    """

    prompt_name: str
    toolsets: List[Any]
    tools: Optional[List[Tool]] = None
    retries: int = 2
    agent_name: str = ""
    prompt_kwargs: Optional[Dict[str, Any]] = None
    tool_white_list: Optional[List[str]] = None
    tool_black_list: Optional[List[str]] = None
    individual_tool_white_list: Optional[List[str]] = None
    individual_tool_black_list: Optional[List[str]] = None

    def __post_init__(self) -> None:
        """Set agent_name from prompt_name if not explicitly provided."""
        if not self.agent_name:
            self.agent_name = self.prompt_name


# ============================================================================
# Tool Result Models
# ============================================================================


class GraphSchemaResult(BaseModel):
    """Result from get_graph_schema tool."""
    tool_name: str = "get_graph_schema"
    format: GraphSchemaFormat = "compact"
    graph_schema: Union[str, Dict[str, Any]] = Field(alias="schema")
    examples: Optional[Dict[str, str]] = None
    notes: Optional[str] = None
    model_config = ConfigDict(populate_by_name=True)
    error: Optional[str] = None


class QueryGraphResult(BaseModel):
    """Result from query_graph tool."""
    tool_name: str = "query_graph"
    nodes: List[Dict[str, Any]] = Field(default_factory=list)
    node_count: int = Field(default=0)
    error: Optional[str] = None
    query_description: Optional[str] = None
    display_hint: Optional[str] = None  # "table", "cards", "scalar", "list"


class GraphSearchResult(BaseModel):
    """Result from search_graph tool."""
    tool_name: str = "search_graph"
    term: str
    node_types: Optional[List[str]] = None
    matches: List[Dict[str, Any]] = Field(default_factory=list)
    match_count: int = Field(default=0)
    error: Optional[str] = None


class PreviewTableResult(BaseModel):
    """Result from preview_table tool."""
    tool_name: str = "preview_table"
    columns: List[str] = Field(default_factory=list)
    rows: List[Any] = Field(default_factory=list)
    row_count: int = Field(default=0)
    error: Optional[str] = None


class ExecuteQueryResult(BaseModel):
    """Result from execute_query tool."""
    tool_name: str = "execute_query"
    columns: List[str] = Field(default_factory=list)
    rows: List[List[Any]] = Field(default_factory=list)
    row_count: int = Field(default=0)
    error: Optional[str] = None
    query: Optional[str] = None


# ============================================================================
# CLI Tool Results
# ============================================================================


class BashResult(BaseModel):
    """Result from bash tool."""

    tool_name: str = "bash"
    command: str
    exit_code: int
    stdout: str
    stderr: Optional[str] = None
    working_dir: str


class DbtResult(BaseModel):
    """Result from dbt_cli tool."""

    tool_name: str = "dbt_cli"
    command: str
    exit_code: int
    stdout: str
    stderr: Optional[str] = None
    project_dir: str


# Re-export protocol lineage types for tool use
# These are the canonical types - no wrapping needed
RelationLineageResult = ProtocolRelationLineageResult
ColumnLineageResult = ProtocolColumnLineageResult
ModelMaterializationsResult = ProtocolModelMaterializationsResult
RelationLineageNode = LineageNode  # Alias for clarity


class ProjectOverviewResult(BaseModel):
    """Result from get_project_overview tool.

    Provides a pre-computed overview of the dbt project including model census,
    subject areas, data flow, coverage stats, and semantic richness.
    """

    tool_name: str = "get_project_overview"
    overview_markdown: str = Field(description="Full project overview in markdown format")
    project_name: Optional[str] = Field(default=None, description="Name of the dbt project")
    model_count: Optional[int] = Field(default=None, description="Total number of dbt models")
    source_count: Optional[int] = Field(default=None, description="Total number of dbt sources")
    warehouse_target: Optional[str] = Field(default=None, description="Target warehouse (e.g. snowflake)")


class SearchModelsResult(BaseModel):
    """Result from search_graph_nodes tool.

    Each result in the `results` list contains:
    - id: Node identifier (model ID or FQN)
    - name: Node name
    - node_type: Type of node (DbtModel, DbtSource, InferredMeasure, etc.)
    - description: Node description or relevant text
    - match_field: Which field matched the search pattern
    - match_snippet: Context snippet showing the match
    - score: Relevance score (higher is better)
    """

    tool_name: str = "search_models"
    search_term: str
    results: List[Dict[str, Any]] = Field(default_factory=list)
    result_count: int = Field(default=0)


class DownstreamImpactResult(BaseModel):
    """Result from get_downstream_impact tool."""

    tool_name: str = "get_downstream_impact"
    model_id: str
    model_name: Optional[str] = None
    affected_models: List[Dict[str, Any]] = Field(default_factory=list)
    total_affected: int = Field(default=0)
    max_depth: int = Field(default=0)


class KeyDiagnosticsResult(BaseModel):
    """Result from run_key_diagnostics tool."""
    tool_name: str = "run_key_diagnostics"
    model_id: str
    fq_table: str
    key_col: str
    total_rows: int
    distinct_keys: int
    null_keys: int
    duplicate_keys: int
    has_duplicates: bool
    has_nulls: bool
    result_set_id: Optional[str] = None
    error: Optional[str] = None


class JoinDiagnosticsResult(BaseModel):
    """Result from run_join_diagnostics tool."""
    tool_name: str = "run_join_diagnostics"
    fact_id: str
    dim_id: str
    key_col: str
    fact_table: str
    dim_table: str
    fact_rows: int
    orphan_count: int
    orphan_rate: float
    fanout_keys: int
    has_orphans: bool
    has_fanout: bool
    result_set_id: Optional[str] = None
    error: Optional[str] = None


class RelationshipHealthCheckResult(BaseModel):
    """Result from run_relationship_health_check tool."""
    tool_name: str = "run_relationship_health_check"
    left_model_id: str
    right_model_id: str
    left_fq_table: str
    right_fq_table: str
    join_columns: List[str]
    left_key_diagnostics: KeyDiagnosticsResult
    right_key_diagnostics: KeyDiagnosticsResult
    join_diagnostics: JoinDiagnosticsResult
    health_verdict: str
    result_set_id: Optional[str] = None
    error: Optional[str] = None


class ExecuteSqlForReportResult(BaseModel):
    """Result from execute_sql_for_report tool."""
    tool_name: str = "execute_sql_for_report"
    description: str
    columns: List[str]
    rows: List[Dict[str, Any]]
    row_count: int


class CreateVisualizationResult(BaseModel):
    """Result from create_visualization tool."""
    tool_name: str = "create_visualization"
    chart_path: str
    chart_type: str
    title: str


class SaveHtmlReportResult(BaseModel):
    """Result from save_html_report tool."""
    tool_name: str = "save_html_report"
    report_path: str
    url: str
    report_name: str


class StoreUserPreferenceResult(BaseModel):
    """Result from store_user_preference tool."""
    tool_name: str = "store_user_preference"
    success: bool
    message: str


class StoreDataPatternResult(BaseModel):
    """Result from store_data_pattern tool."""
    tool_name: str = "store_data_pattern"
    success: bool
    message: str


class StoreSessionSummaryResult(BaseModel):
    """Result from store_session_summary tool."""
    tool_name: str = "store_session_summary"
    success: bool
    message: str
    user_stored: bool
    org_stored: bool
    learning_count: Optional[int] = None


class ExecuteSemanticViewQueryResult(BaseModel):
    """Result from execute_semantic_view_query tool (validated SQL execution)."""
    tool_name: str = "execute_semantic_view_query"
    columns: List[str]
    rows: List[Dict[str, Any]]
    row_count: int
    validated_views: List[str]  # Views that were referenced and validated


class CreateTicketResult(BaseModel):
    """Result from create_ticket tool."""
    tool_name: str = "create_ticket"
    ticket_id: str
    message: str


class ListTicketsResult(BaseModel):
    """Result from list_tickets tool."""
    tool_name: str = "list_tickets"
    tickets: List[Dict[str, Any]] = Field(default_factory=list)
    count: int = Field(default=0)


class GetTicketResult(BaseModel):
    """Result from get_ticket tool."""
    tool_name: str = "get_ticket"
    ticket: Dict[str, Any]


class UpdateTicketResult(BaseModel):
    """Result from update_ticket tool."""
    tool_name: str = "update_ticket"
    ticket_id: str
    message: str


class AddTicketCommentResult(BaseModel):
    """Result from add_ticket_comment tool."""
    tool_name: str = "add_ticket_comment"
    ticket_id: str
    message: str


class CellAck(BaseModel):
    """Slim acknowledgement returned by cell mutation tools.

    Contains only confirmation fields — no content/data payload. The TUI receives
    full cell data via report_snapshot CustomEvents emitted by _update_report_state().
    """

    tool_name: str
    cell_id: str
    cell_type: str  # markdown, chart, table, mermaid
    report_id: str
    message: str
    row_count: Optional[int] = None  # For table/chart cells
    word_count: Optional[int] = None  # For markdown cells
    chart_type: Optional[str] = None  # For chart cells
    title: Optional[str] = None  # For chart/table/mermaid cells


class CellMetadata(BaseModel):
    """Metadata about a cell in the current report."""
    cell_id: str
    cell_number: int  # 1-indexed position
    cell_type: str  # markdown, chart, table, mermaid
    preview: str  # First 100 chars or title


class ListReportCellsResult(BaseModel):
    """Result from list_report_cells tool."""
    tool_name: str = "list_report_cells"
    cells: List[CellMetadata] = Field(default_factory=list)
    total_count: int = 0


class CreateReportResult(BaseModel):
    """Result from create_report tool."""
    tool_name: str = "create_report"
    report_id: str
    title: str
    message: str


class SaveReportResult(BaseModel):
    """Result from save_report tool (deprecated - use create_report instead)."""
    tool_name: str = "save_report"
    report_id: str
    title: str
    saved_at: str
    cell_count: int


class ModifyCellResult(BaseModel):
    """Result from modify_report_cell tool."""
    tool_name: str = "modify_report_cell"
    report_id: str
    cell_number: int
    message: str


class DeleteCellResult(BaseModel):
    """Result from delete_report_cell tool."""
    tool_name: str = "delete_report_cell"
    report_id: str
    cell_number: int
    message: str


# ============================================================================
# Subject Area Tool Results
# ============================================================================


class SubjectAreaSummary(BaseModel):
    """Summary of a subject area for listing."""

    name: str
    description: Optional[str] = None
    domains: List[str] = Field(default_factory=list)
    keywords: List[str] = Field(default_factory=list)
    model_count: int = 0
    fact_count: int = 0
    dimension_count: int = 0
    mixed_count: int = 0
    contains_pii: bool = False
    total_edge_weight: float = 0.0


class ListSubjectAreasResult(BaseModel):
    """Result from list_subject_areas tool."""

    tool_name: str = "list_subject_areas"
    subject_areas: List[SubjectAreaSummary] = Field(default_factory=list)
    total_count: int = 0


class SubjectAreaMemberModel(BaseModel):
    """A model that belongs to a subject area."""

    id: str
    name: str
    role: str  # "fact", "dimension", or "mixed"
    intent: Optional[str] = None
    grain: Optional[str] = None


class InternalEdge(BaseModel):
    """A join edge within a subject area."""

    source_name: str
    target_name: str
    weight: float
    join_types: List[str] = Field(default_factory=list)


class SubjectAreaDetailsResult(BaseModel):
    """Result from get_subject_area_details tool."""

    tool_name: str = "get_subject_area_details"
    name: str
    description: Optional[str] = None
    domains: List[str] = Field(default_factory=list)
    keywords: List[str] = Field(default_factory=list)
    notes: List[str] = Field(default_factory=list)
    model_count: int = 0
    # Schema blueprint
    recommended_fact_model: Optional[str] = None
    top_dimension_models: List[str] = Field(default_factory=list)
    # Role breakdown
    fact_models: List[SubjectAreaMemberModel] = Field(default_factory=list)
    dimension_models: List[SubjectAreaMemberModel] = Field(default_factory=list)
    mixed_models: List[SubjectAreaMemberModel] = Field(default_factory=list)
    # Internal relationships
    top_internal_edges: List[InternalEdge] = Field(default_factory=list)
    contains_pii: bool = False


class RelatedSubjectAreaInfo(BaseModel):
    """Information about a related subject area."""

    name: str
    relationship_type: str  # "shared_domains", "shared_models", "cross_joins"
    strength: float
    shared_domains: List[str] = Field(default_factory=list)
    shared_model_count: int = 0


class RelatedSubjectAreasResult(BaseModel):
    """Result from find_related_subject_areas tool."""

    tool_name: str = "find_related_subject_areas"
    source_subject_area: str
    related: List[RelatedSubjectAreaInfo] = Field(default_factory=list)


class DomainModelInfo(BaseModel):
    """Model information for domain search results."""

    id: str
    name: str
    role: str
    subject_area: Optional[str] = None


class DomainSearchResult(BaseModel):
    """Result from search_by_domain tool."""

    tool_name: str = "search_by_domain"
    domain: str
    subject_areas: List[SubjectAreaSummary] = Field(default_factory=list)
    models: List[DomainModelInfo] = Field(default_factory=list)


# ============================================================================
# Thinking Block Model
# ============================================================================


class ThinkingBlock(BaseModel):
    """Extended thinking content from Claude's reasoning process."""

    content: str
    """The thinking/reasoning content"""

    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    """When this thinking block was created"""

    tool_call_id: Optional[str] = None
    """Associated tool call ID if this thinking preceded a tool call"""


# ============================================================================
# State Model
# ============================================================================


class ReportPreview(BaseModel):
    """Preview data for a report in state snapshot."""
    report_id: str
    title: str
    cell_count: int
    last_updated: datetime
    cells: List["CellData"] = Field(default_factory=list)
    """Cell data for frontend rendering - uses CellData for proper typing"""


class SubagentType(str, Enum):
    """Known subagent types used by the streaming subagent tool."""

    TRIAGE = "triage"
    EXPLORER = "explorer"
    DIAGNOSTICIAN = "diagnostician"
    PLANNER = "planner"
    EXECUTOR = "executor"
    MECHANIC = "mechanic"
    DATA_VALIDATOR = "data_validator"
    REPORT_BUILDER = "report_builder"
    SEMANTIC_DATA = "semantic_data"


def coerce_subagent_type(value: str) -> SubagentType | None:
    """Return a SubagentType for a string value, or None if invalid."""
    try:
        return SubagentType(value)
    except ValueError:
        return None



# ============================================================================
# Context Brief Models (replaces ExploreSummary)
# ============================================================================


BriefSource = Literal[
    "explorer", "diagnostician", "mechanic", "executor",
    "planner",
]
"""Valid source identifiers for context briefs."""


class ContextBrief(BaseModel):
    """Context gathered by specialist investigation for downstream decision-making.

    A unified artifact type that can be produced by any specialist:
    - explorer: Convention discovery, codebase patterns
    - diagnostician: Root cause tracing, hypothesis validation
    - mechanic/executor: Execution results, verification outcomes

    Consumed by planner (and other specialists) to inform decision-making.
    All structured findings go into findings_markdown as markdown sections.
    """

    brief_id: str
    """Unique ID (e.g., 'brief_abc123')"""

    source: BriefSource
    """Who created this brief"""

    title: str
    """Human-readable title"""

    task_type: Optional[Literal["diagnostic", "additive", "hybrid"]] = None
    """Task classification - diagnostic (something broken), additive (new feature), hybrid"""

    findings_markdown: str
    """Full findings in markdown format — the primary content field"""

    created_at: datetime
    """When this brief was created"""


class ContextBriefInfo(BaseModel):
    """Lightweight brief info for listing (without full content)."""

    brief_id: str
    source: BriefSource
    title: str
    task_type: Optional[str] = None
    created_at: datetime


class ContextBriefList(BaseModel):
    """List of context brief info (without full content)."""

    briefs: List[ContextBriefInfo] = Field(default_factory=list)


class ContextBriefAck(BaseModel):
    """Slim acknowledgement returned by save_context_brief.

    The full findings_markdown and hypotheses are already persisted to
    threads_backend. Agents can call get_context_brief to read the full content.
    """

    brief_id: str
    source: str
    title: str
    task_type: Optional[str] = None
    message: str


class PlanSection(BaseModel):
    """A labeled section of a plan (human-readable, editable)."""

    section_id: str
    title: str
    content_markdown: str


class PlanStep(BaseModel):
    """A single plan step."""

    step_id: str
    content: str
    risk: Optional[str] = None
    dependencies: List[str] = Field(default_factory=list)


class PlanQuestion(BaseModel):
    """A single plan question."""

    question_id: str
    prompt: str
    resolver: Literal["user", "explorer", "planner"] = "user"
    status: Literal["open", "answered"] = "open"
    answer_text: Optional[str] = None
    answer_options: Optional[List[str]] = None


class PlanPreview(BaseModel):
    """Preview data for a plan in state snapshot."""

    plan_id: str
    title: str
    goal: str
    status: str = "draft"  # draft|final
    last_updated: datetime
    markdown_body: Optional[str] = None
    """Full markdown plan from the planner specialist. When set, used directly for display."""
    sections: List[PlanSection] = Field(default_factory=list)
    steps: List[PlanStep] = Field(default_factory=list)
    questions: List[PlanQuestion] = Field(default_factory=list)


class PlanAck(BaseModel):
    """Slim acknowledgement returned by plan mutation tools.

    Contains only confirmation fields — no full plan data. The TUI receives
    plan updates via plan_snapshot CustomEvents emitted by _set_plan().
    Agents can call get_plan / get_active_plan to read the full plan.
    """

    tool_name: str
    plan_id: str
    status: str = "draft"
    message: Optional[str] = None
    error: Optional[str] = None
    created_id: Optional[str] = None  # ID of newly created item (step, section, question)


class PlanView(BaseModel):
    """Full plan snapshot returned by read-only plan tools (get_plan, get_active_plan)."""

    tool_name: str
    plan_id: str
    status: str = "draft"
    message: Optional[str] = None
    error: Optional[str] = None
    plan: Dict[str, Any]


# ============================================================================
# Specialist Structured Output Models
# ============================================================================


class DiagnosticVerdict(str, Enum):
    """Verdict for a diagnostic investigation."""

    CONFIRMED = "CONFIRMED"
    REFUTED = "REFUTED"
    INCONCLUSIVE = "INCONCLUSIVE"


class DiagnosticResult(BaseModel):
    """Structured output returned by the diagnostician specialist."""

    reasoning: str
    """Full chain-of-thought, unrestricted — upstream trace, data findings, SQL analysis"""

    verdict: DiagnosticVerdict
    hypothesis: str
    """What was tested"""

    root_cause_model: Optional[str] = None
    """e.g. 'int_order_details'"""

    root_cause_explanation: Optional[str] = None
    recommendation: str
    brief_id: Optional[str] = None
    """Brief ID assigned by the streaming layer after auto-persisting findings"""


class ExplorationResult(BaseModel):
    """Structured output returned by the explorer specialist."""

    reasoning: str
    task_type: Literal["diagnostic", "additive", "hybrid"]
    key_findings: List[str]
    """2-4 bullets summarising the findings for the orchestrator"""

    conventions_summary: Optional[str] = None
    brief_id: Optional[str] = None
    """Brief ID assigned by the streaming layer after auto-persisting findings"""


class ExecutionResult(BaseModel):
    """Structured output returned by executor and mechanic specialists."""

    reasoning: str
    success: bool
    summary: str
    files_changed: List[str] = Field(default_factory=list)
    dbt_result: Optional[str] = None
    """'PASSED' / 'FAILED' / None"""

    commit_message: Optional[str] = None
    brief_id: Optional[str] = None


class AgentState(BaseModel):
    """State container for AG-UI protocol.

    Stores tool results keyed by tool_call_id for frontend generative UI rendering.
    Also stores thinking blocks from Claude's extended thinking feature.

    This state is automatically synced to frontend via AG-UI protocol state_update events.
    """

    tool_results: Dict[str, BaseModel] = Field(default_factory=dict)
    """Maps tool_call_id to tool result models"""

    thinking_blocks: List[ThinkingBlock] = Field(default_factory=list)
    """Extended thinking/reasoning blocks from Claude"""

    current_specialist: Optional[str] = None
    """Currently active specialist (for orchestrators)"""

    last_query: Optional[str] = None
    """Last query executed (for debugging)"""

    active_reports: Dict[str, ReportPreview] = Field(default_factory=dict)
    """Active reports keyed by report_id - updated when cells are added/modified"""

    active_report_id: Optional[str] = None
    """Most recently created/updated report_id (for tools/subagents to reference)."""

    context_briefs: Dict[str, "ContextBrief"] = Field(default_factory=dict)
    """Context briefs keyed by brief_id (from any specialist)."""

    active_plans: Dict[str, PlanPreview] = Field(default_factory=dict)
    """Active plans keyed by plan_id - updated when sections/steps are mutated"""

    active_plan_id: Optional[str] = None
    """Most recently created/updated plan_id (for tools/subagents to reference)."""

    preview_tabs: List[Dict[str, Any]] = Field(default_factory=list)
    """Preview pane tabs (queries, reports) for frontend rendering"""

    model_config = ConfigDict(arbitrary_types_allowed=True)


# ============================================================================
# Dependency Models
# ============================================================================


@dataclass
class AgentDeps:
    """Dependencies injected into agent.

    The state field is required by PydanticAI's AG-UI StateHandler protocol.
    It stores tool results and intermediate state for generative UI rendering.

    Memory fields (user_id, org_id, memory_backend) enable persistent memory:
    - user_id: Identifies the current user for user-specific memory
    - org_id: Identifies the organization for shared memory
    - memory_backend: Optional backend for storing/retrieving memories

    Filesystem and git fields enable code modification capabilities:
    - filesystem_config: Configuration for file read/write operations
    - git_config: Configuration for git operations (from backends/config.py)

    Note: thread_context is NOT stored here. It's used only for prompt rendering
    (injecting previous run summaries into LLM context). Tools should query
    threads_backend directly for fresh data.
    """

    lineage: LineageStorage
    thread_id: str
    run_id: str
    data_backend: Optional[DataQueryBackend] = None
    memory_backend: Optional[MemoryStorage] = None
    ticket_storage: Optional[TicketStorage] = None
    reports_backend: Optional[ReportsBackend] = None
    threads_backend: Optional[ThreadsBackend] = None
    blob_storage: Optional[BlobStorage] = None
    user_id: Optional[str] = None
    org_id: str = "default"
    agent_name: str = "agent"
    state: AgentState = field(default_factory=AgentState)
    # Filesystem and git configuration for code modification agents
    filesystem_config: Optional[FileSystemConfig] = None
    git_config: Optional[GitConfig] = None
