"""Data exploration and semantic query tools for Pydantic agents."""

from __future__ import annotations

import logging
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, List, Optional

from pydantic_ai import FunctionToolset, RunContext

from lineage.agent.pydantic.tools.common import ToolError, safe_tool, tool_error
from lineage.agent.pydantic.types import (
    AgentDeps,
    JoinDiagnosticsResult,
    KeyDiagnosticsResult,
    RelationshipHealthCheckResult,
)
from lineage.agent.pydantic.utils import push_preview_tab
from lineage.backends.blobs.protocol import BlobPreviewResult
from lineage.backends.data_query.protocol import (
    NativeSemanticModelQueryFragment,
    QueryResult,
    TablePreview,
    TableSchema,
)

logger = logging.getLogger(__name__)


def _serialize_value(val: Any) -> Any:
    """Serialize a value for JSON storage (handles dates, decimals, etc.)."""
    if val is None:
        return None
    if isinstance(val, datetime):
        return val.isoformat()
    if isinstance(val, date):
        return val.isoformat()
    if isinstance(val, Decimal):
        return float(val)
    if isinstance(val, bytes):
        return val.decode("utf-8", errors="replace")
    return val


def _serialize_row(row: tuple | list) -> list:
    """Serialize a row of values for JSON storage."""
    return [_serialize_value(v) for v in row]

data_exploration_toolset = FunctionToolset()
semantic_view_toolset = FunctionToolset()


def _record_query_preview(
    ctx: RunContext[AgentDeps],
    *,
    tool_name: str,
    query_name: str,
    columns: List[str],
    rows: List[List[Any]],
    sql: Optional[str] = None,
    auto_open: bool = True,
    extra_data: Optional[Dict[str, Any]] = None,
) -> None:
    """Helper to push tabular previews into agent state."""
    data: Dict[str, Any] = {
        "type": "tabular",
        "columns": columns,
        "rows": rows,
        "queryName": query_name,
    }
    if sql:
        data["sql"] = sql
    if extra_data:
        data.update(extra_data)

    push_preview_tab(
        ctx.deps.state,
        title=query_name or tool_name,
        tool_name=tool_name,
        tab_type="tabular",
        data=data,
        auto_open=auto_open,
    )


@data_exploration_toolset.tool
@safe_tool
async def list_tables(
    ctx: RunContext[AgentDeps],
    database: str,
    schema: str,
) -> List[str] | ToolError:
    """List all tables in a schema.

    Args:
        ctx: Runtime context with agent dependencies
        database: Database name
        schema: Schema name

    Returns:
        List of table names in the schema
    """
    if not ctx.deps.data_backend:
        return ToolError(error_message="No data backend configured")

    try:
        tables = await ctx.deps.data_backend.list_tables(database, schema)
        return tables
    except Exception as e:
        logger.error(f"Error listing tables: {e}")
        return ToolError(error_message=str(e))

@data_exploration_toolset.tool
@safe_tool
async def list_databases(
    ctx: RunContext[AgentDeps],
) -> List[str] | ToolError:
    """List all databases.

    Args:
        ctx: Runtime context with agent dependencies
    Returns:
        List of database names
    """
    if not ctx.deps.data_backend:
        return ToolError(error_message="No data backend configured")

    try:
        databases = await ctx.deps.data_backend.list_databases()
        return databases
    except Exception as e:
        logger.error(f"Error listing databases: {e}")
        return ToolError(error_message=str(e))

@data_exploration_toolset.tool
@safe_tool
async def list_schemas(
    ctx: RunContext[AgentDeps],
    database: str,
) -> List[str] | ToolError:
    """List all schemas in a database.

    Args:
        ctx: Runtime context with agent dependencies
        database: Database name

    Returns:
        List of schema names in the database
    """
    if not ctx.deps.data_backend:
        return ToolError(error_message="No data backend configured")

    try:
        schemas = await ctx.deps.data_backend.list_schemas(database)
        return schemas
    except Exception as e:
        logger.error(f"Error listing schemas: {e}")
        return ToolError(error_message=str(e))

@data_exploration_toolset.tool
@safe_tool
async def get_table_schema(
    ctx: RunContext[AgentDeps],
    database: str,
    schema: str,
    table: str,
) -> TableSchema | ToolError:
    """Get schema information for a table.

    Args:
        ctx: Runtime context with agent dependencies
        database: Database name
        schema: Schema name
        table: Table name
    Returns:
        TableSchema with column definitions
    """
    if not ctx.deps.data_backend:
        return ToolError(error_message="No data backend configured")

    try:
        table_schema = await ctx.deps.data_backend.get_table_schema(database, schema, table)
        return table_schema
    except Exception as e:
        logger.error(f"Error getting table schema: {e}")
        return ToolError(error_message=str(e))


@data_exploration_toolset.tool
@safe_tool
async def preview_table(
    ctx: RunContext[AgentDeps],
    database: str,
    schema: str,
    table: str,
    limit: int = 10,
) -> TablePreview | ToolError:
    """Preview table structure and sample rows.

    Args:
        ctx: Runtime context with agent dependencies
        database: Database name
        schema: Schema name
        table: Table name
        limit: Number of rows to preview (default: 10)

    Returns:
        Column schema and sample rows
    """
    if not ctx.deps.data_backend:
        return ToolError(error_message="no backend configured")

    try:
        preview = await ctx.deps.data_backend.preview_table(database, schema, table, limit)
        return preview
    except Exception as e:
        logger.error(f"Error previewing table: {e}")
        return ToolError(error_message=str(e))

# This is purposely NOT part of the data_exploration_toolset
# Only agents that specifically need to execute SQL queries should wire this tool in.
@safe_tool
async def execute_query(
    ctx: RunContext[AgentDeps],
    sql: str,
    query_name: str = "SQL Query",
    limit: Optional[int] = None,
    persist: bool = True,
) -> QueryResult | ToolError:
    """Execute a SQL query against the data warehouse.

    Args:
        ctx: Runtime context with agent dependencies
        sql: SQL query string
        query_name: Descriptive name for this query (e.g., "Monthly Revenue Trends")
        limit: Optional row limit (default: None, uses query's LIMIT)
        persist: Whether to persist result to blob storage (default: True).
            When True, downstream agents can access full data via result_set_id.

    Returns:
        Query results including columns and rows, with result_set_id if persisted
    """
    if not ctx.deps.data_backend:
        return ToolError(error_message="no backend configured")

    try:
        result = await ctx.deps.data_backend.execute_query(sql, limit)
        # result is a QueryResult dataclass with .columns, .rows attributes

        # Set query_name if provided
        result.query_name = query_name

        # Persist to blob storage if enabled
        if persist and ctx.deps.blob_storage:
            blob_ref = ctx.deps.blob_storage.store(
                thread_id=ctx.deps.thread_id,
                run_id=ctx.deps.run_id,
                blob_type="query_result",
                data={
                    "columns": result.columns,
                    "rows": [_serialize_row(row) for row in result.rows],  # Serialize dates, decimals, etc.
                    "row_count": result.row_count,
                    "execution_time_ms": result.execution_time_ms,
                },
                metadata={
                    "sql": sql,
                    "query_name": query_name,
                },
            )
            result.result_set_id = blob_ref.blob_id
            logger.debug(f"Persisted query result to blob {blob_ref.blob_id}: {blob_ref.summary}")

        # Store typed result in state keyed by tool_call_id for frontend generative UI
        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result

        display_name = result.query_name or query_name or "SQL Query"
        _record_query_preview(
            ctx,
            tool_name="execute_query",
            query_name=display_name,
            columns=result.columns,
            rows=result.rows,
            sql=sql,
        )

        return result
    except Exception as e:
        logger.error(f"Error executing query: {e}")
        return ToolError(error_message=str(e))


@semantic_view_toolset.tool
@safe_tool
async def query_semantic_view(
    ctx: RunContext[AgentDeps],
    database_name: str,
    schema_name: str,
    view_name: str,
    query_name: str,
    measures: List[NativeSemanticModelQueryFragment],
    dimensions: List[NativeSemanticModelQueryFragment],
    facts: List[NativeSemanticModelQueryFragment],
    where_clause: Optional[str] = None,
    order_by: Optional[str] = None,
    limit: int = 10,
    persist: bool = True,
) -> QueryResult | ToolError:
    """Execute parameterized query on semantic view.

    Args:
        ctx: Runtime context with agent dependencies
        database_name: name of the database in which the semantic view is located
        schema_name: name of the schema in which the semantic view is located
        view_name: name of the semantic view to query
        measures: List of measures like [{"table": "{semantic_table_name}", "name": "{measure_name}"}]
        dimensions: List of dimensions like [{"table": "{semantic_table_name}", "name": "{dimension_name}"}]
        facts: List of facts like [{"table": "{semantic_table_name}", "name": "{fact_name}"}]
        where_clause: Optional WHERE condition (e.g., "year = 2024")
        order_by: Optional ORDER BY clause (e.g., "{dimension_name} DESC")
        limit: Maximum rows to return (default: 10)
        query_name: Descriptive name for this query (e.g., "Q1 Revenue by Region")
        persist: Whether to persist result to blob storage (default: True).
            When True, downstream agents can access full data via result_set_id.

    Returns:
        Query results with columns and rows, with result_set_id if persisted

    Note:
        - Must include at least one of: measures, dimensions, or facts
        - Cannot combine facts with measures in same query
    """
    backend = ctx.deps.data_backend
    if not backend:
        return tool_error("No data backend configured")

    try:
        result = await backend.query_semantic_view(
            view_name=view_name,
            database_name=database_name,
            schema_name=schema_name,
            measures=measures,
            dimensions=dimensions,
            facts=facts,
            where_clause=where_clause,
            order_by=order_by,
            limit=limit,
        )

        # Set query_name if provided, fallback to view_name
        result.query_name = query_name or view_name

        # Persist to blob storage if enabled
        if persist and ctx.deps.blob_storage:
            blob_ref = ctx.deps.blob_storage.store(
                thread_id=ctx.deps.thread_id,
                run_id=ctx.deps.run_id,
                blob_type="query_result",
                data={
                    "columns": result.columns,
                    "rows": [_serialize_row(row) for row in result.rows],  # Serialize dates, decimals, etc.
                    "row_count": result.row_count,
                    "execution_time_ms": result.execution_time_ms,
                },
                metadata={
                    "semantic_view": view_name,
                    "query_name": query_name or view_name,
                    "database": database_name,
                    "schema": schema_name,
                },
            )
            result.result_set_id = blob_ref.blob_id
            logger.debug(f"Persisted semantic view result to blob {blob_ref.blob_id}: {blob_ref.summary}")

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result

        _record_query_preview(
            ctx,
            tool_name="query_semantic_view",
            query_name=result.query_name or view_name,
            columns=result.columns,
            rows=result.rows,
            extra_data={"semanticView": view_name},
        )

        return result
    except NotImplementedError as e:
        return ToolError(error_message=str(e))
    except Exception as e:
        logger.error(f"Error querying semantic view: {e}")
        return ToolError(error_message=str(e))


# Blob preview tool - available to any agent with blob_storage
@data_exploration_toolset.tool
@safe_tool
async def preview_blob(
    ctx: RunContext[AgentDeps],
    blob_id: str,
    sample_rows: int = 5,
) -> BlobPreviewResult | ToolError:
    """Preview a stored query result blob.

    Returns metadata and sample rows without fetching full data.
    Useful for:
    - Checking columns before creating charts
    - Verifying data format before building tables
    - Seeing total row count for pagination decisions

    Args:
        ctx: Runtime context
        blob_id: The result_set_id to preview
        sample_rows: Number of sample rows to return (default 5)

    Returns:
        BlobPreviewResult with columns, sample_rows, total_rows
    """
    if not ctx.deps.blob_storage:
        return tool_error("Blob storage not configured")

    blob = ctx.deps.blob_storage.preview(blob_id, sample_rows)
    if not blob:
        return tool_error(f"Blob not found or expired: {blob_id}")

    return BlobPreviewResult(
        blob_id=blob_id,
        columns=blob.data.get("columns", []),
        sample_rows=blob.data.get("rows", []),
        total_rows=blob.data.get("total_rows", blob.data.get("row_count", 0)),
        blob_type=blob.blob_type,
    )


@data_exploration_toolset.tool
@safe_tool
async def list_blobs(
    ctx: RunContext[AgentDeps],
    blob_type: Optional[str] = None,
    limit: int = 20,
) -> list[dict[str, Any]] | ToolError:
    """List all query result blobs stored in the current thread.

    This is useful when you need to reference existing query results:
    - To update a chart with different parameters
    - To reuse query results in multiple visualizations
    - To see what data is already available

    Args:
        ctx: Runtime context
        blob_type: Optional filter by blob type (query_result, table_preview, explore)
        limit: Maximum number of blobs to return (default 20)

    Returns:
        List of blob references with metadata (blob_id, summary, columns, row_count)
    """
    if not ctx.deps.blob_storage:
        return tool_error("Blob storage not configured")

    try:
        blob_refs = ctx.deps.blob_storage.list_by_thread(
            thread_id=ctx.deps.thread_id,
            blob_type=blob_type,
            limit=limit,
        )

        # Convert BlobRef objects to dicts for agent consumption
        return [
            {
                "blob_id": ref.blob_id,
                "blob_type": ref.blob_type,
                "summary": ref.summary,
                "created_at": ref.created_at.isoformat() if ref.created_at else None,
                "row_count": ref.row_count,
                "columns": ref.columns,
            }
            for ref in blob_refs
        ]
    except Exception as e:
        logger.error(f"Error listing blobs: {e}")
        return tool_error(f"Failed to list blobs: {str(e)}")


@semantic_view_toolset.tool
@safe_tool
async def list_semantic_views(
    ctx: RunContext[AgentDeps],
    database_name: Optional[str] = None,
    schema_name: Optional[str] = None,
    like: Optional[str] = None,
    starts_with: Optional[str] = None,
) -> list[dict[str, Any]] | ToolError:
    """List all semantic views in a schema.

    Args:
        ctx: Runtime context with agent dependencies
        database_name: Database name
        schema_name: Schema name
        like: Pattern to filter view names (SQL LIKE syntax)
        starts_with: Prefix to filter view names
    Returns:
        List of semantic views
    """
    backend = ctx.deps.data_backend
    if not backend:
        return tool_error("No data backend configured")

    try:
        semantic_views = await backend.list_semantic_views(
            database_name=database_name,
            schema_name=schema_name,
            like=like,
            starts_with=starts_with,
        )
        return semantic_views
    except Exception as e:
        logger.error(f"Error listing semantic views: {e}")
        return ToolError(error_message=str(e))


@semantic_view_toolset.tool
@safe_tool
async def list_semantic_metrics(
    ctx: RunContext[AgentDeps],
    database_name: Optional[str] = None,
    schema_name: Optional[str] = None,
    view_name: Optional[str] = None,
    like: Optional[str] = None,
    starts_with: Optional[str] = None,
) -> QueryResult | ToolError:
    """List semantic metrics with optional database/schema filtering.

    Args:
        ctx: Runtime context with agent dependencies
        database_name: Database name (optional)
        schema_name: Schema name (optional)
        view_name: View name (optional)
        like: Pattern to filter measure names (SQL LIKE syntax)
        starts_with: Prefix to filter measure names
    """
    backend = ctx.deps.data_backend
    if not backend:
        return ToolError(error_message="No data backend configured")

    try:
        measures = await backend.show_semantic_metrics(
            database_name=database_name,
            schema_name=schema_name,
            view_name=view_name,
            like=like,
            starts_with=starts_with,
        )
        return measures
    except Exception as e:
        logger.error(f"Error listing semantic metrics: {e}")
        return ToolError(error_message=str(e))


@semantic_view_toolset.tool
@safe_tool
async def list_semantic_dimensions(
    ctx: RunContext[AgentDeps],
    database_name: Optional[str] = None,
    schema_name: Optional[str] = None,
    view_name: Optional[str] = None,
    like: Optional[str] = None,
    starts_with: Optional[str] = None,
) -> QueryResult | ToolError:
    """List semantic dimensions with optional database/schema filtering.

    Args:
        ctx: Runtime context with agent dependencies
        database_name: Database name (optional)
        schema_name: Schema name (optional)
        view_name: View name (optional)
        like: Pattern to filter dimension names (SQL LIKE syntax)
        starts_with: Prefix to filter dimension names
    """
    backend = ctx.deps.data_backend
    if not backend:
        return ToolError(error_message="No data backend configured")

    try:
        dimensions = await backend.show_semantic_dimensions(
            database_name=database_name,
            schema_name=schema_name,
            view_name=view_name,
            like=like,
            starts_with=starts_with,
        )
        return dimensions
    except Exception as e:
        logger.error(f"Error listing semantic dimensions: {e}")
        return ToolError(error_message=str(e))


@semantic_view_toolset.tool
@safe_tool
async def list_semantic_facts(
    ctx: RunContext[AgentDeps],
    database_name: Optional[str] = None,
    schema_name: Optional[str] = None,
    view_name: Optional[str] = None,
    like: Optional[str] = None,
    starts_with: Optional[str] = None,
) -> QueryResult | ToolError:
    """List semantic facts with optional database/schema filtering.

    Args:
        ctx: Runtime context with agent dependencies
        database_name: Database name (optional)
        schema_name: Schema name (optional)
        view_name: View name (optional)
        like: Pattern to filter fact names (SQL LIKE syntax)
        starts_with: Prefix to filter fact names
    """
    backend = ctx.deps.data_backend
    if not backend:
        return ToolError(error_message="No data backend configured")

    try:
        facts = await backend.show_semantic_facts(
            database_name=database_name,
            schema_name=schema_name,
            view_name=view_name,
            like=like,
            starts_with=starts_with,
        )
        return facts
    except Exception as e:
        logger.error(f"Error listing semantic facts: {e}")
        return ToolError(error_message=str(e))

@semantic_view_toolset.tool
@safe_tool
async def get_semantic_view_ddl(
    ctx: RunContext[AgentDeps],
    database_name: str,
    schema_name: str,
    view_name: str,
) -> str | ToolError:
    """Get DDL for a semantic view.

    Args:
        ctx: Runtime context with agent dependencies
        database_name: Database name
        schema_name: Schema name
        view_name: Name of semantic view
    Returns:
        DDL for the semantic view
    """
    backend = ctx.deps.data_backend
    if not backend:
        return ToolError(error_message="No data backend configured")

    try:
        ddl = await backend.get_semantic_view_ddl(
            database_name=database_name,
            schema_name=schema_name,
            view_name=view_name,
        )
        return ddl
    except Exception as e:
        logger.error(f"Error getting semantic view DDL: {e}")
        return ToolError(error_message=str(e))


@data_exploration_toolset.tool
@safe_tool
async def run_key_diagnostics(
    ctx: RunContext[AgentDeps],
    model_id: str,
    key_col: str,
) -> KeyDiagnosticsResult | ToolError:
    """Quickly assess NULLs, duplicates, and key health for a single model.

    Automates the 'Health Check' pattern: COUNT(*), COUNT(DISTINCT key), and NULL checks.

    Args:
        ctx: Runtime context with agent dependencies
        model_id: The dbt model ID (e.g., 'model.project.dim_server_info')
        key_col: The column name to check (e.g., 'server_id')
    """
    if not ctx.deps.data_backend:
        return tool_error("No data backend configured")

    # 1. Resolve materialization
    mats_result = ctx.deps.lineage.get_model_materializations(model_id)
    if not mats_result.materializations:
        return tool_error(f"Model {model_id} not found or is ephemeral (not queryable)")

    # Use the first materialization found (usually there's only one relevant one)
    mat = mats_result.materializations[0]
    db, schema, table = mat.database, mat.schema_name, mat.relation_name
    fq_table = mat.fqn

    # 2. Build and execute diagnostic query
    try:
        diag = await ctx.deps.data_backend.run_key_diagnostics(db, schema, table, key_col)

        # 3. Persist result for UI
        result_set_id = None
        if ctx.deps.blob_storage:
            blob_ref = ctx.deps.blob_storage.store(
                thread_id=ctx.deps.thread_id,
                run_id=ctx.deps.run_id,
                blob_type="query_result",
                data={
                    "columns": ["total_rows", "distinct_keys", "duplicate_keys", "null_keys"],
                    "rows": [[diag.total_rows, diag.distinct_keys, diag.duplicate_keys, diag.null_keys]],
                    "row_count": 1,
                },
                metadata={
                    "query_name": f"Key Diagnostics: {model_id}.{key_col}",
                },
            )
            result_set_id = blob_ref.blob_id

        diag_result = KeyDiagnosticsResult(
            model_id=model_id,
            fq_table=fq_table,
            key_col=key_col,
            total_rows=diag.total_rows,
            distinct_keys=diag.distinct_keys,
            null_keys=diag.null_keys,
            duplicate_keys=diag.duplicate_keys,
            has_duplicates=diag.duplicate_keys > 0,
            has_nulls=diag.null_keys > 0,
            result_set_id=result_set_id,
        )

        # Store in state for UI
        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = diag_result

        return diag_result

    except Exception as e:
        logger.error(f"Error running key diagnostics: {e}")
        return tool_error(f"Error running key diagnostics: {e}")


@data_exploration_toolset.tool
@safe_tool
async def run_join_diagnostics(
    ctx: RunContext[AgentDeps],
    fact_id: str,
    dim_id: str,
    key_col: str,
) -> JoinDiagnosticsResult | ToolError:
    """Measure join loss and fanout between a fact and dimension.

    Automates the 'Referential Integrity' check via LEFT JOIN.

    Args:
        ctx: Runtime context with agent dependencies
        fact_id: The fact model ID (e.g., 'model.project.fct_revenue')
        dim_id: The dimension model ID (e.g., 'model.project.dim_customers')
        key_col: The join key column name (e.g., 'customer_id')
    """
    if not ctx.deps.data_backend:
        return tool_error("No data backend configured")

    # 1. Resolve materializations
    fact_mats_result = ctx.deps.lineage.get_model_materializations(fact_id)
    dim_mats_result = ctx.deps.lineage.get_model_materializations(dim_id)

    if not fact_mats_result.materializations:
        return tool_error(f"Fact model {fact_id} not found or is ephemeral")
    if not dim_mats_result.materializations:
        return tool_error(f"Dimension model {dim_id} not found or is ephemeral")

    f_mat, d_mat = fact_mats_result.materializations[0], dim_mats_result.materializations[0]
    fact_table = f"{f_mat.database}.{f_mat.schema_name}.{f_mat.relation_name}"
    dim_table = f"{d_mat.database}.{d_mat.schema_name}.{d_mat.relation_name}"

    # 2. Build and execute diagnostic queries
    try:
        diag = await ctx.deps.data_backend.run_join_diagnostics(
            f_mat.database, f_mat.schema_name, f_mat.relation_name,
            d_mat.database, d_mat.schema_name, d_mat.relation_name,
            key_col
        )

        # 3. Persist result
        result_set_id = None
        if ctx.deps.blob_storage:
            blob_ref = ctx.deps.blob_storage.store(
                thread_id=ctx.deps.thread_id,
                run_id=ctx.deps.run_id,
                blob_type="query_result",
                data={
                    "columns": ["fact_rows", "orphan_count", "orphan_rate", "fanout_keys"],
                    "rows": [[diag.fact_rows, diag.orphan_count, diag.orphan_rate, diag.fanout_keys]],
                    "row_count": 1,
                },
                metadata={
                    "query_name": f"Join Diagnostics: {fact_id} -> {dim_id}",
                },
            )
            result_set_id = blob_ref.blob_id

        diag_result = JoinDiagnosticsResult(
            fact_id=fact_id,
            dim_id=dim_id,
            key_col=key_col,
            fact_table=fact_table,
            dim_table=dim_table,
            fact_rows=diag.fact_rows,
            orphan_count=diag.orphan_count,
            orphan_rate=diag.orphan_rate,
            fanout_keys=diag.fanout_keys,
            has_orphans=diag.orphan_count > 0,
            has_fanout=diag.fanout_keys > 0,
            result_set_id=result_set_id,
        )

        # Store in state
        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = diag_result

        return diag_result

    except Exception as e:
        logger.error(f"Error running join diagnostics: {e}")
        return tool_error(f"Error running join diagnostics: {e}")


@data_exploration_toolset.tool
@safe_tool
async def run_relationship_health_check(
    ctx: RunContext[AgentDeps],
    left_model_id: str,
    right_model_id: str,
    join_columns: list[str],
    environment: str | None = None,
) -> RelationshipHealthCheckResult | ToolError:
    """Run key + join diagnostics between two models on a join key.

    This is a single-call helper that:
    1) Resolves materializations for both models
    2) Runs key diagnostics on both sides
    3) Runs join diagnostics for the join key

    Args:
        ctx: Runtime context with agent dependencies
        left_model_id: Left model id (usually fact model)
        right_model_id: Right model id (usually dimension model)
        join_columns: Join key columns (currently supports exactly one column)
        environment: Optional environment selector (e.g., "prod")
    """
    if not ctx.deps.data_backend:
        return tool_error("No data backend configured")

    if len(join_columns) != 1:
        return tool_error("run_relationship_health_check currently supports exactly one join column")

    join_col = join_columns[0]

    def _select_materialization(
        mats_result: Any,
        env: str | None,
    ) -> Optional[Any]:
        if not mats_result.materializations:
            return None
        if env:
            for mat in mats_result.materializations:
                if mat.environment == env:
                    return mat
        for mat in mats_result.materializations:
            if mat.environment.lower() == "prod":
                return mat
        return mats_result.materializations[0]

    left_mats = ctx.deps.lineage.get_model_materializations(left_model_id)
    right_mats = ctx.deps.lineage.get_model_materializations(right_model_id)

    left_mat = _select_materialization(left_mats, environment)
    right_mat = _select_materialization(right_mats, environment)

    if not left_mat:
        return tool_error(f"Model {left_model_id} not found or is ephemeral (not queryable)")
    if not right_mat:
        return tool_error(f"Model {right_model_id} not found or is ephemeral (not queryable)")

    left_fq = left_mat.fqn
    right_fq = right_mat.fqn

    left_key = await run_key_diagnostics(ctx, left_model_id, join_col)
    if isinstance(left_key, ToolError):
        return left_key
    right_key = await run_key_diagnostics(ctx, right_model_id, join_col)
    if isinstance(right_key, ToolError):
        return right_key
    join_diag = await run_join_diagnostics(ctx, left_model_id, right_model_id, join_col)
    if isinstance(join_diag, ToolError):
        return join_diag

    issues = []
    if left_key.has_nulls or right_key.has_nulls:
        issues.append("null_keys")
    if left_key.has_duplicates or right_key.has_duplicates:
        issues.append("duplicates")
    if join_diag.has_orphans:
        issues.append("orphans")
    if join_diag.has_fanout:
        issues.append("fanout")

    if not issues:
        health_verdict = "healthy"
    elif len(issues) == 1:
        health_verdict = issues[0]
    else:
        health_verdict = "mixed"

    result_set_id = None
    if ctx.deps.blob_storage:
        blob_ref = ctx.deps.blob_storage.store(
            thread_id=ctx.deps.thread_id,
            run_id=ctx.deps.run_id,
            blob_type="query_result",
            data={
                "columns": [
                    "side",
                    "total_rows",
                    "distinct_keys",
                    "duplicate_keys",
                    "null_keys",
                    "orphan_count",
                    "orphan_rate",
                    "fanout_keys",
                ],
                "rows": [
                    [
                        "left",
                        left_key.total_rows,
                        left_key.distinct_keys,
                        left_key.duplicate_keys,
                        left_key.null_keys,
                        None,
                        None,
                        None,
                    ],
                    [
                        "right",
                        right_key.total_rows,
                        right_key.distinct_keys,
                        right_key.duplicate_keys,
                        right_key.null_keys,
                        None,
                        None,
                        None,
                    ],
                    [
                        "join",
                        join_diag.fact_rows,
                        None,
                        None,
                        None,
                        join_diag.orphan_count,
                        join_diag.orphan_rate,
                        join_diag.fanout_keys,
                    ],
                ],
                "row_count": 3,
            },
            metadata={
                "query_name": f"Relationship Health Check: {left_model_id} -> {right_model_id}",
            },
        )
        result_set_id = blob_ref.blob_id

    result = RelationshipHealthCheckResult(
        left_model_id=left_model_id,
        right_model_id=right_model_id,
        left_fq_table=left_fq,
        right_fq_table=right_fq,
        join_columns=join_columns,
        left_key_diagnostics=left_key,
        right_key_diagnostics=right_key,
        join_diagnostics=join_diag,
        health_verdict=health_verdict,
        result_set_id=result_set_id,
    )

    tool_call_id = ctx.tool_call_id or "unknown"
    ctx.deps.state.tool_results[tool_call_id] = result

    return result
