"""Plan tooling for Pydantic agents.

Read-only plan tools (get_plan, get_active_plan) and a module-level
persist_plan() helper used by streaming_subagents.py to persist
SpecialistPlan structured output without needing a RunContext.

The plan mutation tools (create_plan, add_plan_section, add_plan_step, etc.)
have been removed in the context-brief-refactor branch.  The planner
specialist now emits a complete SpecialistPlan in one shot, and the
streaming layer calls persist_plan() to materialise it.
"""

from __future__ import annotations

import logging
from typing import Any

from pydantic_ai import FunctionToolset, RunContext

from lineage.agent.pydantic.tools.common import ToolError, safe_tool, tool_error
from lineage.agent.pydantic.types import (
    AgentDeps,
    AgentState,
    PlanAck,
    PlanPreview,
    PlanView,
)
from lineage.agent.pydantic.utils import push_preview_tab
from lineage.backends.threads.models import Artifact

logger = logging.getLogger(__name__)

try:
    from ag_ui.core import CustomEvent

    AG_UI_AVAILABLE = True
except Exception:  # pragma: no cover
    AG_UI_AVAILABLE = False
    CustomEvent = None  # type: ignore

plan_toolset = FunctionToolset()


# ============================================================================
# Module-level persist helper (called by streaming_subagents.py)
# ============================================================================


def persist_plan(
    state: AgentState,
    threads_backend: Any,
    thread_id: str,
    run_id: str,
    plan: PlanPreview,
    ui_event_queue: Any = None,
) -> None:
    """Persist a plan into agent state, threads_backend, and emit a UI snapshot.

    This is the single persistence layer for plans.  Callable from both tool
    context (via _set_plan) and from streaming_subagents.py without needing a
    RunContext.
    """
    state.active_plans[plan.plan_id] = plan
    state.active_plan_id = plan.plan_id

    if threads_backend and thread_id:
        try:
            threads_backend.set_metadata(thread_id, "active_plan_id", plan.plan_id)
            artifact = Artifact(
                type="plan",
                id=plan.plan_id,
                run_id=run_id,
                title=plan.title,
                created_at=plan.last_updated,
                data=plan.model_dump(mode="json"),
            )
            threads_backend.add_artifact(thread_id=thread_id, run_id=run_id, artifact=artifact)
        except Exception:
            logger.debug("Failed to persist plan artifact to threads_backend", exc_info=True)

    version = (
        plan.last_updated.isoformat()
        if hasattr(plan.last_updated, "isoformat")
        else str(plan.last_updated)
    )
    push_preview_tab(
        state,
        tab_id=f"plan_{plan.plan_id}",
        title=plan.title,
        tool_name="plan_preview",
        tab_type="plan",
        data={
            "type": "plan",
            "planId": plan.plan_id,
            "planTitle": plan.title,
            "status": plan.status,
            "version": version,
        },
        auto_open=True,
    )

    # Emit plan_snapshot CustomEvent for live UI updates
    if not AG_UI_AVAILABLE or CustomEvent is None:
        return
    try:
        event = CustomEvent(
            name="plan_snapshot",
            value={
                "plan_id": plan.plan_id,
                "plan": plan.model_dump(mode="json"),
                "parent_tool_call_id": "",
            },
        )
        if ui_event_queue is not None:
            try:
                ui_event_queue.put_nowait(event)
            except Exception:
                logger.debug("Failed to enqueue plan snapshot event", exc_info=True)
    except Exception:
        logger.debug("Failed to emit plan snapshot CustomEvent", exc_info=True)


# ============================================================================
# Internal helpers
# ============================================================================


def _get_plan(ctx: RunContext[AgentDeps], plan_id: str) -> PlanPreview | None:
    """Fetch a plan from agent state.

    Checks in-memory state first, then queries fresh data from threads_backend.
    """
    plan = ctx.deps.state.active_plans.get(plan_id)
    if plan is not None:
        return plan

    # Query fresh from threads_backend (source of truth for cross-run persistence)
    tb = ctx.deps.threads_backend
    thread_id = ctx.deps.thread_id
    if tb and thread_id:
        try:
            thread = tb.get_or_create_thread(thread_id)
        except Exception:
            thread = None
        if thread and thread.artifacts:
            for artifact in thread.artifacts:
                if artifact.type != "plan" or artifact.id != plan_id:
                    continue
                if not isinstance(artifact.data, dict):
                    continue
                try:
                    loaded = PlanPreview.model_validate(artifact.data)
                except Exception:
                    loaded = None
                if loaded is not None:
                    ctx.deps.state.active_plans[loaded.plan_id] = loaded
                    ctx.deps.state.active_plan_id = loaded.plan_id
                    return loaded

    return None


def _set_plan(ctx: RunContext[AgentDeps], plan: PlanPreview) -> None:
    """Persist a plan into agent state and update preview tabs."""
    persist_plan(
        state=ctx.deps.state,
        threads_backend=ctx.deps.threads_backend,
        thread_id=ctx.deps.thread_id,
        run_id=ctx.deps.run_id,
        plan=plan,
        ui_event_queue=getattr(ctx.deps, "ui_event_queue", None),
    )


def _store_tool_result(ctx: RunContext[AgentDeps], result: PlanAck | PlanView) -> None:
    tool_call_id = ctx.tool_call_id or "unknown"
    ctx.deps.state.tool_results[tool_call_id] = result


# ============================================================================
# Read-only plan tools (exposed on plan_toolset)
# ============================================================================


@plan_toolset.tool
@safe_tool
async def get_plan(ctx: RunContext[AgentDeps], plan_id: str) -> PlanView | ToolError:
    """Get a plan snapshot by id (read-only)."""
    plan = _get_plan(ctx, plan_id)
    if not plan:
        return tool_error(f"Plan not found: {plan_id}")

    msg = f"Loaded plan '{plan.title}' ({plan.status})"
    view = PlanView(
        tool_name="get_plan",
        plan_id=plan.plan_id,
        status=plan.status,
        message=msg,
        plan=plan.model_dump(mode="json"),
    )
    _store_tool_result(ctx, view)
    return view


@plan_toolset.tool
@safe_tool
async def get_active_plan(ctx: RunContext[AgentDeps]) -> PlanView | ToolError:
    """Get the most recently active plan (read-only).

    This tool fetches fresh data from threads_backend to handle cross-run and
    subagent scenarios.
    """
    plan_id = ctx.deps.state.active_plan_id
    tb = ctx.deps.threads_backend
    thread_id = ctx.deps.thread_id

    if not plan_id:
        # Try persisted pointer first
        if tb and thread_id:
            try:
                stored = tb.get_metadata(thread_id, "active_plan_id")
            except Exception:
                logger.debug("Failed to get active_plan_id from threads_backend metadata", exc_info=True)
                stored = None
            if isinstance(stored, str) and stored:
                plan_id = stored

    if not plan_id:
        # Fallback: pick the most recently updated plan from in-memory state
        candidates = list(ctx.deps.state.active_plans.values())
        if candidates:
            most_recent = max(candidates, key=lambda p: p.last_updated)
            ctx.deps.state.active_plan_id = most_recent.plan_id
            plan_id = most_recent.plan_id

    if not plan_id:
        # Fallback: query fresh artifacts from threads_backend (source of truth)
        if tb and thread_id:
            try:
                fresh_thread = tb.get_or_create_thread(thread_id)
                plan_artifacts = [a for a in fresh_thread.artifacts if a.type == "plan"]
                if plan_artifacts:
                    most_recent_artifact = max(plan_artifacts, key=lambda a: a.created_at)
                    ctx.deps.state.active_plan_id = most_recent_artifact.id
                    plan_id = most_recent_artifact.id
            except Exception:
                logger.debug("Failed to query plan artifacts from threads_backend", exc_info=True)

    if not plan_id:
        return tool_error("No active plan_id is set yet. Create a plan first.")

    # Delegate to get_plan (which already has @safe_tool, so we call the inner logic)
    plan = _get_plan(ctx, plan_id)
    if not plan:
        return tool_error(f"Plan not found: {plan_id}")

    msg = f"Loaded plan '{plan.title}' ({plan.status})"
    view = PlanView(
        tool_name="get_active_plan",
        plan_id=plan.plan_id,
        status=plan.status,
        message=msg,
        plan=plan.model_dump(mode="json"),
    )
    _store_tool_result(ctx, view)
    return view
