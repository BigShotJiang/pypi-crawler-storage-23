"""Graph query tools for Pydantic agents."""

from __future__ import annotations

from enum import Enum
from typing import Literal, Optional

from pydantic_ai import FunctionToolset, RunContext

from lineage.agent.pydantic.tools.common import ToolError, safe_tool, tool_error
from lineage.agent.pydantic.tools.data import logger
from lineage.agent.pydantic.types import (
    AgentDeps,
    DomainModelInfo,
    DomainSearchResult,
    DownstreamImpactResult,
    GraphSchemaResult,
    InternalEdge,
    ListSubjectAreasResult,
    ModelMaterializationsResult,
    ProjectOverviewResult,
    QueryGraphResult,
    RelatedSubjectAreaInfo,
    RelatedSubjectAreasResult,
    SearchModelsResult,
    SubjectAreaDetailsResult,
    SubjectAreaMemberModel,
    SubjectAreaSummary,
)
from lineage.backends.lineage.protocol import (
    ColumnLineageResult,
    GraphSchemaFormat,
    ModelDetailsResult,
    RelationLineageResult,
)

graph_exploration_toolset = FunctionToolset()


@graph_exploration_toolset.tool
@safe_tool
async def get_project_overview(
    ctx: RunContext[AgentDeps],
) -> ProjectOverviewResult | ToolError:
    """Get a comprehensive overview of the dbt project.

    Includes model census, subject areas, data flow, coverage stats, and semantic richness.

    Call this FIRST when you need to understand the project structure, what
    domains exist, how many models there are, or what the data landscape
    looks like. This is pre-computed and very fast.
    """
    try:
        overview = ctx.deps.lineage.get_project_overview()
        if overview is None:
            return tool_error(
                "No project overview available. Run `lineage load-dbt-full` to generate one."
            )

        result = ProjectOverviewResult(
            overview_markdown=overview.get("overview_markdown", ""),
            project_name=overview.get("project_name"),
            model_count=overview.get("model_count"),
            source_count=overview.get("source_count"),
            warehouse_target=overview.get("warehouse_target"),
        )

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result

        return result
    except Exception as e:
        logger.error(f"Error getting project overview: {e}")
        return tool_error(f"Error getting project overview: {e}")


@graph_exploration_toolset.tool
@safe_tool
async def get_graph_schema(
    ctx: RunContext[AgentDeps],
    format: GraphSchemaFormat = "compact",
) -> GraphSchemaResult | ToolError:
    """Get the graph database schema showing available node and relationship types.

    NOTE: The system prompt already contains a schema summary. Only call this tool if you need
    more detail than the summary provides (e.g., exact property names and types for Cypher queries).

    Args:
        ctx: Runtime context with dependencies.
        format: Output format:
            - "summary": Minimal schema (~1,700 tokens). Core nodes with key properties only.
              Usually not needed since this is already in the system prompt.
            - "compact" (default): Complete schema (~3-4k tokens). All nodes with all properties and types.
              Use when you need exact property names for Cypher queries.
            - "structured": Full JSON schema (~12k tokens). Use for programmatic access.

    Returns:
        Schema information including node tables, relationship tables, and their properties,
        plus example queries and helpful notes
    """
    try:
        schema = ctx.deps.lineage.get_graph_schema(format=format)

        # Example queries for CteScope and STRUCTURALLY_USES — patterns not
        # yet covered by dedicated tools so the agent needs Cypher examples.
        examples = {
            "list_cte_scopes_for_model": """MATCH (m:DbtModel)-[:HAS_CTE_SCOPE]->(c:CteScope)
WHERE m.name = 'my_model'
RETURN c.name, c.scope_type, c.has_grain_change, c.has_row_reduction
ORDER BY c.name""",
            "cte_scope_derives_from": """MATCH (c:CteScope)-[e:DERIVES_FROM]->(col:DbtColumn)
WHERE c.model_id = 'model.project.my_model'
RETURN c.name AS cte, e.column_name AS column, e.transformation,
       e.expr, col.id AS upstream_column""",
            "structural_edges_for_model": """MATCH (m:DbtModel {name: 'my_model'})-[:MATERIALIZES]->(col:DbtColumn)
OPTIONAL MATCH (col)-[s:STRUCTURALLY_USES]->(src:DbtColumn)
RETURN col.name, s.transformation, s.expr, src.id AS upstream
ORDER BY s.transformation, col.name""",
            "structural_edges_from_model_node": """MATCH (m:DbtModel)-[s:STRUCTURALLY_USES]->(src:DbtColumn)
WHERE m.name = 'my_model'
RETURN s.transformation, s.column_name, s.expr, src.id AS upstream
ORDER BY s.transformation""",
            "filter_predicates_across_models": """MATCH (col)-[s:STRUCTURALLY_USES {transformation: 'filter_predicate'}]->(src:DbtColumn)
RETURN col.id AS model_or_column, s.expr, src.id AS filtered_column
LIMIT 20""",
            "join_keys_for_model": """MATCH (col)-[s:STRUCTURALLY_USES {transformation: 'join_key'}]->(src:DbtColumn)
WHERE col.id STARTS WITH 'model.project.my_model'
   OR col.id = 'model.project.my_model'
RETURN s.column_name, s.expr, src.id AS joined_column""",
        }

        notes = (
            "Note: Schema names are lowercase in the graph. If you get 'No results found', "
            "try using toLower() in your WHERE clauses: WHERE toLower(pt.schema_name) = toLower('SchemaName')\n\n"
            "CteScope nodes represent internal CTEs within a model's SQL. They connect to "
            "DbtModel via HAS_CTE_SCOPE and have DERIVES_FROM edges to DbtColumn or other "
            "CteScope nodes. Properties: name, model_id, scope_type, has_grain_change, "
            "has_row_reduction, is_set_operation.\n\n"
            "STRUCTURALLY_USES edges track columns used in structural SQL clauses (WHERE, "
            "JOIN, GROUP BY, ORDER BY, HAVING, window specs) without contributing value to "
            "output columns. From DbtColumn/DbtModel/CteScope to DbtColumn/CteScope. "
            "Properties: transformation (filter_predicate, join_key, group_key, order_key, "
            "window_partition, window_order), expr, confidence, scope, column_name, upstream_column."
        )

        # Store typed result in state keyed by tool_call_id for frontend generative UI
        tool_call_id = ctx.tool_call_id or "unknown"
        result = GraphSchemaResult(format=format, schema=schema, examples=examples, notes=notes)
        ctx.deps.state.tool_results[tool_call_id] = result

        return result
    except Exception as e:
        logger.error(f"Error getting graph schema: {e}")
        return tool_error(f"Error getting graph schema: {e}")

@graph_exploration_toolset.tool
@safe_tool
async def query_graph(
    ctx: RunContext[AgentDeps],
    cypher: str,
    query_description: str,
    display_hint: Optional[Literal["table", "cards", "scalar", "list"]] = None,
) -> QueryGraphResult | ToolError:
    """Execute a Cypher query against the lineage graph.

    Args:
        ctx: Runtime context with dependencies.
        cypher: Cypher query string (include filters directly in query)
        query_description: Human-readable description of what this query is looking for
            (e.g., "Finding all models related to ARR calculation")
        display_hint: Optional hint for how to display results in TUI
            - "table": Render as markdown table (good for aggregations/counts)
            - "cards": Render as typed node cards (good for node queries)
            - "scalar": Single value display (good for COUNT/SUM)
            - "list": Compact bullet list
            - None: Auto-detect based on result structure

    Returns:
        Query results as list of rows

    Note:
        Parameters are not supported - include filters directly in the query string.
        Example: MATCH (m:DbtModel) WHERE m.id = 'model.foo' RETURN m

        If no results found, remember: schema names are lowercase in the graph.
        Try using toLower() in WHERE clauses: WHERE toLower(pt.schema_name) = toLower('SchemaName')
    """
    try:
        result = ctx.deps.lineage.execute_raw_query(cypher)
        # execute_raw_query returns a dict with 'rows' key

        # Add helpful hint if no results
        error_msg = None
        if result.count == 0:
            error_msg = (
                "No results found. Note: Schema names are lowercase in the graph. "
                "Try using toLower() in your WHERE clauses: WHERE toLower(pt.schema_name) = toLower('SchemaName')"
            )

        # Store typed result in state keyed by tool_call_id for frontend generative UI
        tool_call_id = ctx.tool_call_id or "unknown"
        result_model = QueryGraphResult(
            nodes=result.rows,
            node_count=result.count,
            error=error_msg,
            query_description=query_description,
            display_hint=display_hint,
        )
        ctx.deps.state.tool_results[tool_call_id] = result_model

        return result_model
    except Exception as e:
        logger.error(f"Error executing Cypher query: {e}")
        return tool_error(f"Error executing Cypher query: {e}")

@graph_exploration_toolset.tool
@safe_tool
async def get_relation_lineage(
    ctx: RunContext[AgentDeps],
    identifier: str,
    query_description: str,
    node_type: Literal["physical", "logical"],
    direction: Literal["upstream", "downstream", "both"] = "both",
    depth: int = 2,
    include_physical: bool = True,
) -> RelationLineageResult | ToolError:
    """Get lineage overview for a table/view/model (lightweight, token-efficient).

    Returns lightweight nodes with semantic summaries (no SQL) and dependency edges.
    Use get_model_details() to deep-dive into specific models for SQL, columns, or macros.

    Args:
        ctx: Runtime context with dependencies.
        identifier: PhysicalTable FQN (e.g., 'db.schema.table') or DbtModel ID (e.g., 'model.project.name').
        node_type: "physical" (start at warehouse table) or "logical" (start at dbt model).
        query_description: Human-readable description of what this lineage trace is for
            (e.g., "Tracing upstream dependencies of fct_revenue").
        direction: Which direction to traverse - "upstream", "downstream", or "both".
        depth: Maximum traversal depth.
        include_physical: Whether to include materialized physical tables in results, or only the logical models that build them.
    """
    try:
        # Backend returns typed, flattened, deduplicated result
        result = ctx.deps.lineage.get_relation_lineage(
            identifier=identifier,
            node_type=node_type,
            direction=direction,
            depth=depth,
            include_physical=include_physical,
        )
        # Add the human-readable description to the result
        result.query_description = query_description

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result
        return result
    except Exception as e:
        logger.error(f"Error getting relation lineage: {e}")
        return tool_error(f"Error getting relation lineage: {e}")

@graph_exploration_toolset.tool
@safe_tool
async def get_column_lineage(
    ctx: RunContext[AgentDeps],
    identifier: str,
    node_type: Literal["physical", "logical"],
    query_description: str,
    direction: str = "upstream",
    depth: int = 4,
) -> ColumnLineageResult | ToolError:
    """Get column lineage (trace where column values originate or are used).

    Args:
        ctx: Runtime context
        identifier: PhysicalColumn FQN or DbtColumn ID
        node_type: "physical" or "logical"
        query_description: Human-readable description of what this column trace is for
        direction: "upstream" (trace source) or "downstream" (trace usage)
        depth: Maximum traversal depth
    """
    try:
        # Backend returns typed, flattened, deduplicated result
        result = ctx.deps.lineage.get_column_lineage(
            identifier, node_type, direction, depth
        )
        # Add the human-readable description to the result
        result.query_description = query_description

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result
        return result
    except Exception as e:
        logger.error(f"Error getting column lineage: {e}")
        return tool_error(f"Error getting column lineage: {e}")


@graph_exploration_toolset.tool
@safe_tool
async def trace_column(
    ctx: RunContext[AgentDeps],
    model_name: str,
    column_name: str,
    direction: Literal["upstream", "downstream"] = "upstream",
    depth: int = 4,
) -> ColumnLineageResult | ToolError:
    """Simplified column lineage - just pass model and column name.

    This is a convenience wrapper around get_column_lineage that handles looking up
    the DbtColumn ID from model and column names. More user-friendly for common cases.

    Use this for data quality issues to trace where bad values (NULLs, duplicates,
    wrong values) originate or propagate.

    Args:
        ctx: Runtime context
        model_name: dbt model name (e.g., "dim_server_info" or "model.project.dim_server_info")
        column_name: Column name to trace (e.g., "server_id")
        direction: "upstream" (trace source - where does this column's data come from?)
                   or "downstream" (trace usage - where is this column used?)
        depth: Maximum traversal depth (default 4)

    Returns:
        ColumnLineageResult showing the lineage path with transformations at each hop.

    Example:
        # Trace where server_id NULLs might originate
        trace_column("dim_server_info", "server_id", "upstream")
        # Returns: stg_servers.server_id → int_server_dedup.server_id → dim_server_info.server_id
    """
    try:
        # Normalize model_name to full ID if needed
        if not model_name.startswith("model."):
            # Search for the model to get its full ID
            search_result = ctx.deps.lineage.search_nodes("DbtModel", model_name, limit=1)
            if search_result:
                node = search_result[0].get("node", {}) if isinstance(search_result[0], dict) else {}
                model_id = node.get("id", model_name)
            else:
                model_id = model_name
        else:
            model_id = model_name

        # Build the DbtColumn identifier: model_id.column_name
        column_id = f"{model_id}.{column_name}"

        # Delegate to get_column_lineage
        result = ctx.deps.lineage.get_column_lineage(
            identifier=column_id,
            node_type="logical",
            direction=direction,
            depth=depth,
        )
        result.query_description = f"Tracing {direction} lineage for {model_name}.{column_name}"

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result
        return result
    except Exception as e:
        logger.error(f"Error tracing column {model_name}.{column_name}: {e}")
        return tool_error(f"Error tracing column {model_name}.{column_name}: {e}")

# ============================================================================
# Specialized Graph Exploration Tools
# ============================================================================


SearchableNodeType = Literal[
    # dbt logical nodes
    "DbtModel",
    "DbtSource",
    "DbtColumn",
    "DbtTest",
    # Physical warehouse nodes
    "PhysicalTable",
    "PhysicalView",
    "PhysicalColumn",
    # Inferred semantic nodes
    "InferredMeasure",
    "InferredDimension",
    "InferredFact",
    "InferredSemanticModel",
    # Salesforce nodes
    "SfObject",
    "SfField",
    "SfReport",
    "SfReportColumn",
    "SfDashboard",
]


class SearchMode(str, Enum):
    """Search modes that map to FalkorDB capabilities.

    Abstracts FalkorDB fulltext syntax behind simple, ripgrep-like modes.
    """

    CONTAINS = "contains"  # Simple substring match (default, like grep)
    PREFIX = "prefix"  # Starts with pattern (like glob foo*)
    FUZZY = "fuzzy"  # Typo-tolerant, 1-2 edit distance
    REGEX = "regex"  # Pattern matching via text.regexGroups UDF
    ANY = "any"  # Multi-term OR (any term matches)
    ALL = "all"  # Multi-term AND (all terms required)


# Default node types to search when none specified
DEFAULT_SEARCH_NODE_TYPES: list[SearchableNodeType] = [
    "DbtModel",
    "DbtSource",
    "InferredMeasure",
]


def _extract_match_context(node: dict, pattern: str) -> tuple[str, str]:
    """Return (matched_field, snippet) showing what matched.

    Args:
        node: Node dictionary with properties
        pattern: Search pattern to find in node fields

    Returns:
        Tuple of (field_name, snippet) where the match was found
    """
    pattern_lower = pattern.lower()
    for field in ["name", "description", "fqn", "expr", "intent", "analysis_summary"]:
        value = node.get(field, "") or ""
        if pattern_lower in value.lower():
            idx = value.lower().find(pattern_lower)
            start = max(0, idx - 15)
            end = min(len(value), idx + len(pattern) + 15)
            snippet = ("..." if start > 0 else "") + value[start:end] + ("..." if end < len(value) else "")
            return field, snippet
    return "", ""


@graph_exploration_toolset.tool
@safe_tool
async def search_graph_nodes(
    ctx: RunContext[AgentDeps],
    pattern: str,
    node_types: Optional[list[SearchableNodeType]] = None,
    mode: SearchMode = SearchMode.CONTAINS,
    limit: int = 20,
) -> SearchModelsResult | ToolError:
    """Search the lineage graph like ripgrep searches files.

    **Examples:**
    - `pattern="revenue"` - substring match (default)
    - `pattern="fct_", mode="prefix"` - starts with "fct_"
    - `pattern="reveune", mode="fuzzy"` - finds "revenue" despite typo
    - `pattern="fct_.*_monthly", mode="regex"` - regex pattern
    - `pattern="revenue MRR", mode="any"` - either term matches
    - `pattern="revenue MRR", mode="all"` - both terms required

    **Node Types:** DbtModel, DbtSource, InferredMeasure (default), plus DbtTest,
    PhysicalTable, PhysicalView, DbtColumn, InferredDimension, InferredFact, etc.

    Results include match context showing what field matched.

    Args:
        ctx: Runtime context with dependencies.
        pattern: Search pattern (interpreted based on mode)
        node_types: List of node types to search. Defaults to DbtModel, DbtSource, InferredMeasure.
        mode: Search mode - contains (default), prefix, fuzzy, regex, any, all
        limit: Maximum results to return (default: 20)

    Returns:
        SearchModelsResult with ranked results including id, name, node_type, match context, and score
    """
    try:
        # Use default node types if none specified
        search_types = list(node_types) if node_types else list(DEFAULT_SEARCH_NODE_TYPES)
        mode_str = mode.value if isinstance(mode, SearchMode) else str(mode)

        all_results: list[dict] = []
        per_type_limit = max(limit // len(search_types), 5)

        # Search across each node type
        for node_type in search_types:
            results = ctx.deps.lineage.search_nodes(
                node_type, pattern, per_type_limit, mode=mode_str
            )
            for r in results:
                node = r.get("node", {}) if isinstance(r, dict) else {}
                score = r.get("score", 0) if isinstance(r, dict) else 0

                # Extract match context
                match_field, match_snippet = _extract_match_context(node, pattern)

                all_results.append(
                    {
                        "id": node.get("id") or node.get("fqn"),
                        "name": node.get("name"),
                        "node_type": node_type,
                        "description": node.get("description") or node.get("expr") or node.get("intent"),
                        "match_field": match_field,
                        "match_snippet": match_snippet,
                        "score": float(score) if score else 0,
                    }
                )

        # Sort by score and limit
        all_results.sort(key=lambda x: x.get("score", 0), reverse=True)
        formatted = all_results[:limit]

        result_model = SearchModelsResult(
            search_term=pattern,
            results=formatted,
            result_count=len(formatted),
        )

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result_model

        return result_model
    except Exception as e:
        logger.error(f"Error searching nodes: {e}")
        return tool_error(f"Error searching nodes: {e}")


@graph_exploration_toolset.tool
@safe_tool
async def get_model_details(
    ctx: RunContext[AgentDeps],
    model_id: str,
    include_sql: bool = False,
    include_semantics: bool = False,
    include_columns: bool = False,
    include_macros: bool = False,
    include_tests: bool = False,
    include_joins: bool = False,
) -> ModelDetailsResult | ToolError:
    """Get detailed model information with optional includes.

    Use after get_relation_lineage to deep-dive into specific models.
    Only includes requested data to minimize token usage.

    Args:
        ctx: Runtime context with dependencies.
        model_id: DbtModel ID (e.g., "model.project.fct_revenue")
        include_sql: Include raw_sql and canonical_sql (token-heavy, use sparingly)
        include_semantics: Include full semantic analysis (grain, measures, dimensions, facts,
            subject area membership)
        include_columns: Include DbtColumn information
        include_macros: Include DbtMacro dependencies
        include_tests: Include dbt tests defined on the model (not_null, unique, relationships, etc.)
            Useful for diagnostic tasks to understand what constraints exist.
        include_joins: Include join edges from semantic analysis (join_type, condition, left/right models)

    Returns:
        ModelDetailsResult with requested detail level
    """
    try:
        result = ctx.deps.lineage.get_model_details(
            model_id=model_id,
            include_sql=include_sql,
            include_semantics=include_semantics,
            include_columns=include_columns,
            include_macros=include_macros,
            include_tests=include_tests,
            include_joins=include_joins,
        )

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result

        return result
    except Exception as e:
        logger.error(f"Error getting model details: {e}")
        return tool_error(f"Error getting model details: {e}")


@graph_exploration_toolset.tool
@safe_tool
async def get_model_materializations(
    ctx: RunContext[AgentDeps],
    model_id: str,
) -> ModelMaterializationsResult | ToolError:
    """Get all physical warehouse locations (tables/views) for a dbt model.

    A single dbt model can be materialized in multiple environments (e.g., prod, dev, staging).
    This tool returns the exact database, schema, and table name for each environment.

    Args:
        ctx: Runtime context with dependencies.
        model_id: DbtModel ID (e.g., "model.project.fct_revenue")

    Returns:
        ModelMaterializationsResult containing materializations with environment, fqn, and warehouse type.
    """
    try:
        result = ctx.deps.lineage.get_model_materializations(model_id)

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result

        return result
    except Exception as e:
        logger.error(f"Error getting model materializations: {e}")
        return tool_error(f"Error getting model materializations: {e}")


@graph_exploration_toolset.tool
@safe_tool
async def get_downstream_impact(
    ctx: RunContext[AgentDeps],
    model_id: str,
    depth: int = 2,
) -> DownstreamImpactResult | ToolError:
    """Get all models affected if this model changes (downstream dependencies).

    Critical for checking blast radius before modifying a model.

    Args:
        ctx: Runtime context with dependencies.
        model_id: DbtModel ID (e.g., "model.project.fct_revenue")
        depth: How many levels deep to traverse (default: 2)

    Returns:
        DownstreamImpactResult with affected models and their depths
    """
    try:
        depth = int(depth)

        raw = ctx.deps.lineage.execute_raw_query(
            f"""
            MATCH (m:DbtModel {{id: $model_id}})
            OPTIONAL MATCH path = (downstream:DbtModel)-[:DEPENDS_ON*1..{depth}]->(m)
            WITH m, downstream, length(path) AS path_length
            RETURN m.name AS model_name,
                   downstream.id AS downstream_id,
                   downstream.name AS downstream_name,
                   path_length
            ORDER BY path_length
            """,
            params={"model_id": model_id},
        )

        # Build affected models list
        affected = []
        max_depth_seen = 0
        for row in raw.rows:
            if row.get("downstream_id"):
                depth_val = row.get("path_length", 0)
                affected.append({
                    "id": row.get("downstream_id"),
                    "name": row.get("downstream_name"),
                    "depth": depth_val,
                })
                max_depth_seen = max(max_depth_seen, depth_val)

        result_model = DownstreamImpactResult(
            model_id=model_id,
            model_name=raw.rows[0].get("model_name") if raw.rows else None,
            affected_models=affected,
            total_affected=len(affected),
            max_depth=max_depth_seen,
        )

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result_model

        return result_model
    except Exception as e:
        logger.error(f"Error getting downstream impact: {e}")
        return tool_error(f"Error getting downstream impact: {e}")


# ============================================================================
# Subject Area Discovery Tools
# ============================================================================


@graph_exploration_toolset.tool
@safe_tool
async def list_subject_areas(
    ctx: RunContext[AgentDeps],
    sort_by: Literal["model_count", "name", "edge_weight"] = "model_count",
) -> ListSubjectAreasResult | ToolError:
    """List all subject areas (data domains) with summary statistics.

    Use as an entry point for exploration. Shows domains, model counts,
    and role breakdown (facts/dimensions) for each subject area.

    Subject areas are groups of models that commonly join together,
    discovered through clustering analysis of SQL join patterns.

    Args:
        ctx: Runtime context with dependencies.
        sort_by: How to sort results:
            - "model_count" (default): Largest domains first
            - "name": Alphabetically by domain name
            - "edge_weight": Most interconnected domains first

    Returns:
        ListSubjectAreasResult with subject area summaries
    """
    try:
        raw_areas = ctx.deps.lineage.list_subject_areas(sort_by=sort_by)

        summaries = [
            SubjectAreaSummary(
                name=area.get("name", ""),
                description=area.get("description"),
                domains=area.get("domains", []),
                keywords=area.get("keywords", []),
                model_count=area.get("model_count", 0),
                fact_count=area.get("fact_count", 0),
                dimension_count=area.get("dimension_count", 0),
                mixed_count=area.get("mixed_count", 0),
                contains_pii=area.get("contains_pii", False),
                total_edge_weight=area.get("total_edge_weight", 0.0),
            )
            for area in raw_areas
        ]

        result = ListSubjectAreasResult(
            subject_areas=summaries,
            total_count=len(summaries),
        )

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result

        return result
    except Exception as e:
        logger.error(f"Error listing subject areas: {e}")
        return tool_error(f"Error listing subject areas: {e}")


@graph_exploration_toolset.tool
@safe_tool
async def get_subject_area_details(
    ctx: RunContext[AgentDeps],
    subject_area_name: str,
) -> SubjectAreaDetailsResult | ToolError:
    """Get detailed information about a subject area (data domain).

    Includes member models, recommended star schema structure,
    and top join relationships within the domain.

    Args:
        ctx: Runtime context with dependencies.
        subject_area_name: Name of the subject area to look up

    Returns:
        SubjectAreaDetailsResult with:
        - Full subject area properties
        - Member models grouped by role (fact/dimension/mixed)
        - Schema blueprint (recommended fact + dimensions)
        - Top internal join edges
    """
    try:
        details = ctx.deps.lineage.get_subject_area_by_name(subject_area_name)

        if details is None:
            return tool_error(f"Subject area '{subject_area_name}' not found")

        # Convert member models to typed objects
        fact_models = [
            SubjectAreaMemberModel(
                id=m.get("id", ""),
                name=m.get("name", ""),
                role="fact",
                intent=m.get("intent"),
                grain=m.get("grain"),
            )
            for m in details.get("fact_models", [])
        ]
        dimension_models = [
            SubjectAreaMemberModel(
                id=m.get("id", ""),
                name=m.get("name", ""),
                role="dimension",
                intent=m.get("intent"),
                grain=m.get("grain"),
            )
            for m in details.get("dimension_models", [])
        ]
        mixed_models = [
            SubjectAreaMemberModel(
                id=m.get("id", ""),
                name=m.get("name", ""),
                role="mixed",
                intent=m.get("intent"),
                grain=m.get("grain"),
            )
            for m in details.get("mixed_models", [])
        ]

        # Convert internal edges
        internal_edges = [
            InternalEdge(
                source_name=e.get("source_name", ""),
                target_name=e.get("target_name", ""),
                weight=e.get("weight", 0.0),
                join_types=e.get("join_types", []),
            )
            for e in details.get("top_internal_edges", [])
        ]

        result = SubjectAreaDetailsResult(
            name=details.get("name", ""),
            description=details.get("description"),
            domains=details.get("domains", []),
            keywords=details.get("keywords", []),
            notes=details.get("notes", []),
            model_count=details.get("model_count", 0),
            recommended_fact_model=details.get("recommended_fact_model"),
            top_dimension_models=details.get("top_dimension_model_ids", []),
            fact_models=fact_models,
            dimension_models=dimension_models,
            mixed_models=mixed_models,
            top_internal_edges=internal_edges,
            contains_pii=details.get("contains_pii", False),
        )

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result

        return result
    except Exception as e:
        logger.error(f"Error getting subject area details: {e}")
        return tool_error(f"Error getting subject area details: {e}")


@graph_exploration_toolset.tool
@safe_tool
async def find_related_subject_areas(
    ctx: RunContext[AgentDeps],
    subject_area_name: str,
    relationship_type: Literal["shared_domains", "cross_joins"] = "shared_domains",
) -> RelatedSubjectAreasResult | ToolError:
    """Find subject areas related to the given one.

    Helps discover cross-domain relationships and data integration points.

    Args:
        ctx: Runtime context with dependencies.
        subject_area_name: Name of the source subject area
        relationship_type: Type of relationship to search for:
            - "shared_domains": Areas with overlapping business domains (default)
            - "cross_joins": Areas with direct join edges between their models

    Returns:
        RelatedSubjectAreasResult with related subject areas and relationship strength
    """
    try:
        related_raw = ctx.deps.lineage.find_related_subject_areas(
            name=subject_area_name,
            relationship_type=relationship_type,
        )

        related = [
            RelatedSubjectAreaInfo(
                name=r.get("name", ""),
                relationship_type=r.get("relationship_type", relationship_type),
                strength=r.get("strength", 0.0),
                shared_domains=r.get("shared_domains", []),
                shared_model_count=r.get("shared_model_count", 0),
            )
            for r in related_raw
        ]

        result = RelatedSubjectAreasResult(
            source_subject_area=subject_area_name,
            related=related,
        )

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result

        return result
    except Exception as e:
        logger.error(f"Error finding related subject areas: {e}")
        return tool_error(f"Error finding related subject areas: {e}")


@graph_exploration_toolset.tool
@safe_tool
async def search_by_domain(
    ctx: RunContext[AgentDeps],
    domain: str,
) -> DomainSearchResult | ToolError:
    """Find all models and subject areas related to a business domain.

    Searches across subject areas and individual models for domain matches.

    Args:
        ctx: Runtime context with dependencies.
        domain: Business domain to search for (e.g., "finance", "sales", "product")

    Returns:
        DomainSearchResult with matching subject areas and models
    """
    try:
        # Get subject areas that contain this domain
        all_areas = ctx.deps.lineage.list_subject_areas(sort_by="model_count")
        domain_lower = domain.lower()

        matching_areas = []
        for area in all_areas:
            area_domains = [d.lower() for d in area.get("domains", [])]
            area_keywords = [k.lower() for k in area.get("keywords", [])]
            searchable = area_domains + area_keywords
            if any(domain_lower in term for term in searchable):
                matching_areas.append(
                    SubjectAreaSummary(
                        name=area.get("name", ""),
                        description=area.get("description"),
                        domains=area.get("domains", []),
                        keywords=area.get("keywords", []),
                        model_count=area.get("model_count", 0),
                        fact_count=area.get("fact_count", 0),
                        dimension_count=area.get("dimension_count", 0),
                        mixed_count=area.get("mixed_count", 0),
                        contains_pii=area.get("contains_pii", False),
                        total_edge_weight=area.get("total_edge_weight", 0.0),
                    )
                )

        # Get individual models in this domain
        models_raw = ctx.deps.lineage.search_models_by_domain(domain)
        models = [
            DomainModelInfo(
                id=m.get("id", ""),
                name=m.get("name", ""),
                role=m.get("role", "mixed"),
                subject_area=m.get("subject_area"),
            )
            for m in models_raw
        ]

        result = DomainSearchResult(
            domain=domain,
            subject_areas=matching_areas,
            models=models,
        )

        tool_call_id = ctx.tool_call_id or "unknown"
        ctx.deps.state.tool_results[tool_call_id] = result

        return result
    except Exception as e:
        logger.error(f"Error searching by domain: {e}")
        return tool_error(f"Error searching by domain: {e}")
