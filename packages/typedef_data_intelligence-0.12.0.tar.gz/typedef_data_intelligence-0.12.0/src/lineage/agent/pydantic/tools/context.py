"""Context brief tools for storing and retrieving triage/exploration artifacts.

ContextBrief is a unified artifact type that replaces ExploreSummary.
It can be produced by:
- triage: Task classification, initial graph context, hypotheses
- explorer: Deep-dive findings from code/graph exploration

And consumed by:
- planner: To inform plan creation
- Other specialists: For context about what's been discovered
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime
from typing import Any, Literal, Optional

from pydantic_ai import FunctionToolset, RunContext

from lineage.agent.pydantic.tools.common import ToolError, safe_tool, tool_error
from lineage.agent.pydantic.types import (
    AgentDeps,
    AgentState,
    BriefSource,
    ContextBrief,
    ContextBriefAck,
    ContextBriefInfo,
    ContextBriefList,
)
from lineage.backends.threads.models import Artifact

logger = logging.getLogger(__name__)

context_toolset = FunctionToolset()


# ============================================================================
# Module-level persist helper (called by streaming_subagents.py)
# ============================================================================


def persist_context_brief(
    state: AgentState,
    threads_backend: Any,
    thread_id: str,
    run_id: str,
    brief: ContextBrief,
) -> None:
    """Persist a context brief into agent state and threads_backend.

    This is the single persistence layer for context briefs.  Callable from
    both tool context (via _set_context_brief) and from streaming_subagents.py
    without needing a RunContext.
    """
    state.context_briefs[brief.brief_id] = brief

    if threads_backend and thread_id:
        try:
            artifact = Artifact(
                type="brief",
                id=brief.brief_id,
                run_id=run_id,
                title=brief.title,
                created_at=brief.created_at,
                data=brief.model_dump(mode="json"),
            )
            threads_backend.add_artifact(thread_id=thread_id, run_id=run_id, artifact=artifact)
        except Exception:
            logger.debug("Failed to persist context brief artifact to threads_backend", exc_info=True)


def _load_brief_from_artifacts(
    ctx: RunContext[AgentDeps],
    brief_id: str,
    artifacts: list[Artifact],
) -> ContextBrief | None:
    """Load a context brief from thread artifacts into state."""
    for artifact in artifacts:
        if artifact.type != "brief" or artifact.id != brief_id:
            continue
        if not isinstance(artifact.data, dict):
            continue
        try:
            brief = ContextBrief.model_validate(artifact.data)
        except Exception:
            brief = None
        if brief:
            ctx.deps.state.context_briefs[brief.brief_id] = brief
            return brief
    return None


def _get_context_brief(ctx: RunContext[AgentDeps], brief_id: str) -> ContextBrief | None:
    """Get a context brief by ID, checking in-memory state first, then threads backend."""
    if brief_id in ctx.deps.state.context_briefs:
        return ctx.deps.state.context_briefs[brief_id]

    # Query fresh from threads_backend (source of truth)
    tb = ctx.deps.threads_backend
    thread_id = ctx.deps.thread_id
    if tb and thread_id:
        try:
            thread = tb.get_or_create_thread(thread_id)
        except Exception:
            thread = None
        if thread and thread.artifacts:
            return _load_brief_from_artifacts(
                ctx, brief_id, list(thread.artifacts)
            )
    return None


def _set_context_brief(ctx: RunContext[AgentDeps], brief: ContextBrief) -> None:
    """Save a context brief to state and persist to threads backend."""
    persist_context_brief(
        state=ctx.deps.state,
        threads_backend=ctx.deps.threads_backend,
        thread_id=ctx.deps.thread_id,
        run_id=ctx.deps.run_id,
        brief=brief,
    )


@context_toolset.tool
@safe_tool
async def save_context_brief(
    ctx: RunContext[AgentDeps],
    source: BriefSource,
    title: str,
    findings_markdown: str,
    task_type: Optional[Literal["diagnostic", "additive", "hybrid"]] = None,
    brief_id: Optional[str] = None,
) -> ContextBriefAck | ToolError:
    """Save a context brief artifact from any specialist.

    Context briefs capture findings for downstream agents (especially planner).

    Args:
        ctx: Runtime context with dependencies.
        source: Who is creating this brief — one of "explorer", "diagnostician",
            "planner", "executor", or "mechanic".
        title: Short human-readable title for the brief.
        findings_markdown: Full findings in markdown format. Include all evidence,
            hypotheses, and recommendations as structured markdown sections.
        task_type: Task classification. One of:
            - "diagnostic": Something is wrong/broken
            - "additive": New functionality requested
            - "hybrid": Change requiring current-state understanding
        brief_id: Optional ID to update an existing brief.

    Returns:
        ContextBriefAck with brief_id. Use get_context_brief to read the full content.
    """
    bid = brief_id or f"brief_{uuid.uuid4().hex[:10]}"
    brief = ContextBrief(
        brief_id=bid,
        source=source,
        title=title,
        task_type=task_type,
        findings_markdown=findings_markdown,
        created_at=datetime.now(),
    )
    _set_context_brief(ctx, brief)
    return ContextBriefAck(
        brief_id=bid,
        source=source,
        title=title,
        task_type=task_type,
        message=f"Saved {source} brief '{title}'",
    )


@context_toolset.tool
@safe_tool
async def get_context_brief(
    ctx: RunContext[AgentDeps],
    brief_id: str,
) -> ContextBrief | ToolError:
    """Fetch a single context brief by ID.

    Args:
        ctx: Runtime context with dependencies.
        brief_id: The ID of the brief to fetch.

    Returns:
        The full ContextBrief including findings_markdown.
    """
    brief = _get_context_brief(ctx, brief_id)
    if not brief:
        return tool_error(f"Context brief not found: {brief_id}")
    return brief


@context_toolset.tool
@safe_tool
async def list_context_briefs(
    ctx: RunContext[AgentDeps],
    source: Optional[BriefSource] = None,
) -> ContextBriefList | ToolError:
    """List available context briefs (metadata only, not full content).

    Args:
        ctx: Runtime context with dependencies.
        source: Optional filter by source ("triage" or "explorer").
            If not provided, returns all briefs.

    Returns:
        ContextBriefList with brief info (use get_context_brief for full content).
    """
    # Collect briefs from in-memory state
    brief_infos: dict[str, ContextBriefInfo] = {}
    for brief in ctx.deps.state.context_briefs.values():
        if source and brief.source != source:
            continue
        brief_infos[brief.brief_id] = ContextBriefInfo(
            brief_id=brief.brief_id,
            source=brief.source,
            title=brief.title,
            task_type=brief.task_type,
            created_at=brief.created_at,
        )

    # Query fresh from threads_backend (source of truth)
    tb = ctx.deps.threads_backend
    thread_id = ctx.deps.thread_id
    if tb and thread_id:
        try:
            thread = tb.get_or_create_thread(thread_id)
            for artifact in thread.artifacts:
                if artifact.type != "brief" or not isinstance(artifact.data, dict):
                    continue
                try:
                    brief = ContextBrief.model_validate(artifact.data)
                except Exception:
                    logger.debug("Failed to validate context brief from artifact", exc_info=True)
                    continue
                if source and brief.source != source:
                    continue
                if brief.brief_id not in brief_infos:
                    brief_infos[brief.brief_id] = ContextBriefInfo(
                        brief_id=brief.brief_id,
                        source=brief.source,
                        title=brief.title,
                        task_type=brief.task_type,
                        created_at=brief.created_at,
                    )
        except Exception:
            logger.debug("Failed to query context briefs from threads_backend", exc_info=True)

    return ContextBriefList(briefs=list(brief_infos.values()))
