"""Factory for domain knowledge skills toolset.

Creates a SkillsToolset with static skills from the skills/ directory
and optional runtime skills (e.g., graph schema, backend-specific Cypher
dialect hints).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

from pydantic_ai import RunContext
from pydantic_ai_skills import Skill, SkillsToolset
from pydantic_ai_skills.exceptions import SkillException
from pydantic_ai_skills.toolset import LOAD_SKILL_TEMPLATE

if TYPE_CHECKING:
    from lineage.backends.lineage.protocol import LineageStorage

logger = logging.getLogger(__name__)

_SKILLS_DIR = Path(__file__).parent / "skills"

# Instruction template that encourages autonomous skill discovery via list_skills().
# Agents see skill names+descriptions, then decide which to load based on their task.
_DISCOVERY_INSTRUCTION_TEMPLATE = """\
You have domain knowledge skills containing conventions and methodologies specific to this environment.
These are NOT generic knowledge — they contain patterns you cannot know from training alone.

<available_skills>
{skills_list}
</available_skills>

IMPORTANT: Call `list_skills()` early in your workflow to see full descriptions, then \
`load_skill(skill_name)` for any skills relevant to your current task. \
Skills are prerequisites for their associated actions, not optional enhancements.
"""


class SafeSkillsToolset(SkillsToolset):
    """SkillsToolset that returns error strings instead of raising exceptions.

    pydantic-ai propagates tool exceptions all the way up, crashing the agent
    run. By catching SkillException here and returning a descriptive string,
    the agent can self-correct (e.g., try the right skill name) rather than
    crashing entirely.
    """

    def _register_load_skill(self) -> None:
        @self.tool
        async def load_skill(  # pyright: ignore[reportUnusedFunction]
            ctx: RunContext,
            skill_name: str,
        ) -> str:
            """Load complete instructions and capabilities for a specific skill.

            A skill contains detailed instructions, supplementary resources (like templates or
            reference docs), and executable scripts. Load a skill when you need to perform a
            task within its domain.

            Args:
                ctx: The run context (injected automatically).
                skill_name: Exact name from your available skills list.
                    Must match exactly (e.g., "data-analysis" not "data analysis").

            Returns:
                Structured documentation containing:
                - Skill name, description, and source location
                - Available resources: supplementary files with their parameters
                - Available scripts: executable programs with their parameters
                - Detailed instructions: step-by-step guidance for using the skill

            Important:
            - Read the entire instructions section before taking action
            - Resource and script names are authoritative - use exact names from the output
            - Do NOT infer or guess resource/script names
            - Check parameter schemas if resources or scripts require arguments
            """
            _ = ctx
            skills = self._skills or {}
            if skill_name not in skills:
                available = ", ".join(sorted(skills.keys())) or "none"
                return (
                    f"Skill '{skill_name}' not found. "
                    f"Call list_skills() to see available skills. "
                    f"Available: {available}"
                )
            try:
                skill = skills[skill_name]

                resources_parts: list[str] = []
                if skill.resources:
                    for res in skill.resources:
                        resources_parts.append(self._build_resource_xml(res))
                resources_list = "\n".join(resources_parts) if resources_parts else "<!-- No resources -->"

                scripts_parts: list[str] = []
                if skill.scripts:
                    for scr in skill.scripts:
                        scripts_parts.append(self._build_script_xml(scr))
                scripts_list = "\n".join(scripts_parts) if scripts_parts else "<!-- No scripts -->"

                return LOAD_SKILL_TEMPLATE.format(
                    skill_name=skill.name,
                    description=skill.description,
                    uri=skill.uri or "N/A",
                    resources_list=resources_list,
                    scripts_list=scripts_list,
                    content=skill.content,
                )
            except SkillException as e:
                return f"Error loading skill '{skill_name}': {e}"


def create_domain_skills_toolset(
    *,
    lineage_backend: LineageStorage | None = None,
    extra_directories: list[Path] | None = None,
    extra_skills: list[Skill] | None = None,
    instruction_template: str | None = None,
) -> SkillsToolset:
    """Create a SkillsToolset with domain knowledge for data engineering agents.

    Discovers static skills from the skills/ directory (cypher-patterns,
    upstream-tracing, data-quality-diagnostics, dbt-conventions, risk-analysis,
    visualization-guide, git-workflow, diagnostic-workflow, additive-workflow) and
    optionally creates
    runtime skills from the lineage backend:

    - ``graph-schema``: Node types, relationships, and properties available in the
      lineage graph. Load before writing Cypher queries.
    - ``cypher-dialect``: Backend-specific Cypher dialect constraints (FalkorDB vs
      Neo4j vs Kuzu).

    Args:
        lineage_backend: If provided, creates runtime ``graph-schema`` and
            ``cypher-dialect`` skills from the backend.
        extra_directories: Additional skill directories to discover from.
        extra_skills: Additional pre-loaded Skill objects to include.
        instruction_template: Custom instruction template for the SkillsToolset.
            Must include ``{skills_list}`` placeholder.

    Returns:
        A configured SkillsToolset with ``list_skills``, ``load_skill``, and
        ``read_skill_resource`` tools (``run_skill_script`` is excluded).
    """
    directories: list[Path] = [_SKILLS_DIR]
    if extra_directories:
        directories.extend(extra_directories)

    runtime_skills: list[Skill] = list(extra_skills or [])

    if lineage_backend is not None:
        # Create runtime skill for graph schema (node types, relationships, properties)
        try:
            schema_summary = lineage_backend.get_graph_schema(format="summary")
            if schema_summary:
                runtime_skills.append(
                    Skill(
                        name="graph-schema",
                        description=(
                            "Node types, relationships, and properties available in "
                            "the lineage graph. Load before writing Cypher queries "
                            "or exploring graph structure."
                        ),
                        content=schema_summary,
                    )
                )
        except Exception:
            logger.warning("Could not load graph schema from lineage backend", exc_info=True)

        # Create runtime skill for backend-specific Cypher dialect hints
        try:
            hints = lineage_backend.get_agent_hints()
            if hints:
                runtime_skills.append(
                    Skill(
                        name="cypher-dialect",
                        description=(
                            "Backend-specific Cypher dialect constraints and query "
                            "patterns for this environment. Load when writing graph "
                            "queries to avoid syntax errors."
                        ),
                        content=hints,
                    )
                )
        except Exception:
            logger.warning("Could not load cypher dialect hints from lineage backend", exc_info=True)

    return SafeSkillsToolset(
        skills=runtime_skills or None,
        directories=directories,
        exclude_tools={"run_skill_script"},
        instruction_template=instruction_template,
    )


def create_filtered_skills_toolset(
    full_toolset: SkillsToolset,
    allowed_skills: list[str],
    instruction_template: str | None = None,
) -> SkillsToolset:
    """Create a new SkillsToolset containing only the skills in *allowed_skills*.

    This is used to give each specialist a tailored subset of domain knowledge
    skills, reducing context noise and keeping skill lists relevant.

    Args:
        full_toolset: The complete SkillsToolset (with all skills loaded).
        allowed_skills: Skill names to keep.  Skills not in this list are
            excluded from the returned toolset.
        instruction_template: Custom instruction template.  If ``None``, the
            default discovery template (``_DISCOVERY_INSTRUCTION_TEMPLATE``)
            is used.

    Returns:
        A new ``SkillsToolset`` with only the allowed skills and the same
        ``exclude_tools`` configuration (no ``run_skill_script``).
    """
    all_skills: dict[str, Skill] = full_toolset.skills  # name → Skill
    allowed_set = set(allowed_skills)
    missing = allowed_set - all_skills.keys()
    if missing:
        logger.warning("Allowed skills not found in toolset (will be skipped): %s", sorted(missing))
    filtered = [skill for name, skill in all_skills.items() if name in allowed_set]

    return SafeSkillsToolset(
        skills=filtered or None,
        # No directories — we already resolved all skills from the full toolset.
        directories=None,
        exclude_tools={"run_skill_script"},
        instruction_template=instruction_template or _DISCOVERY_INSTRUCTION_TEMPLATE,
    )
