"""Specialist SubAgentConfigs for pydantic-deepagents orchestrators.

This module defines focused specialists with restricted tool access for the
data engineer copilot and reconciler orchestrators.

Each specialist has:
1. A focused name and description
2. Detailed instructions loaded from Jinja2 templates
3. A tools list with only the functions they need (hard enforcement)

Used by: create_data_engineer_copilot_deep_orchestrator,
         create_data_engineer_reconciler_deep_orchestrator,
         create_investigator_orchestrator
"""

from __future__ import annotations

from typing import Optional

from pydantic_deep import SubAgentConfig

from lineage.agent.prompt_loader import load_specialist_prompt
from lineage.agent.pydantic.tools.context import (
    get_context_brief,
    list_context_briefs,
)

# Tool imports
from lineage.agent.pydantic.tools.data import (
    execute_query,
    get_table_schema,
    list_databases,
    list_schemas,
    list_semantic_views,
    list_tables,
    preview_blob,
    preview_table,
    query_semantic_view,
    run_join_diagnostics,
    run_key_diagnostics,
    run_relationship_health_check,
)
from lineage.agent.pydantic.tools.dbt import (
    dbt_build,
    dbt_compile,
    dbt_run,
    dbt_test,
)
from lineage.agent.pydantic.tools.filesystem import (
    edit_file,
    glob_files,
    grep_files,
    read_file,
    write_file,
)
from lineage.agent.pydantic.tools.git import (
    git_add,
    git_branch,
    git_commit,
    git_diff,
    git_log,
    git_push,
    git_status,
)
from lineage.agent.pydantic.tools.graph import (
    get_column_lineage,
    get_downstream_impact,
    get_graph_schema,
    get_model_details,
    get_model_materializations,
    get_relation_lineage,
    query_graph,
    search_graph_nodes,
    trace_column,
)
from lineage.agent.pydantic.tools.plan import (
    get_active_plan,
    get_plan,
)
from lineage.agent.pydantic.tools.presentation import (
    add_chart_cell,
    add_markdown_cell,
    add_mermaid_cell,
    add_table_cell,
    create_report,
    delete_report_cell,
    list_report_cells,
    modify_report_cell,
)
from lineage.agent.pydantic.types import (
    DiagnosticResult,
    ExecutionResult,
    ExplorationResult,
)
from lineage.backends.data_query import DataQueryBackend
from lineage.backends.lineage import LineageStorage

# ============================================================================
# SPECIALIST OUTPUT TYPES - Maps specialist name → structured output type
# ============================================================================
# Consumed by create_streaming_subagent_toolset() to set output_type per specialist.
# Specialists not listed here use str (plain text).

SPECIALIST_OUTPUT_TYPES: dict[str, type] = {
    "diagnostician": DiagnosticResult,
    "explorer": ExplorationResult,
    # planner uses str (markdown) — todos created via tool calls, markdown returned as result
    "executor": ExecutionResult,
    "mechanic": ExecutionResult,
}

# ============================================================================
# SKILL ALLOWLISTS - Define which domain knowledge skills each specialist gets
# ============================================================================
# Maps specialist name → list of allowed skill names.
# Skills not in the allowlist are hidden from that specialist's SkillsToolset.
# Specialists not listed here receive the full (unfiltered) toolset.

SPECIALIST_SKILLS: dict[str, list[str]] = {
    "explorer": ["graph-schema", "cypher-dialect", "cypher-patterns"],
    "diagnostician": [
        "graph-schema",
        "cypher-dialect",
        "cypher-patterns",
        "data-quality-diagnostics",
        "upstream-tracing",
    ],
    "planner": ["dbt-conventions", "risk-analysis"],
    "executor": ["dbt-conventions", "git-workflow"],
    "mechanic": ["dbt-conventions", "git-workflow"],
    "report_builder": ["visualization-guide"],
}

# ============================================================================
# TOOL SETS - Define which tools each specialist gets
# ============================================================================

EXPLORER_TOOLS = [
    # Graph tools (full investigation)
    query_graph,
    get_graph_schema,
    get_model_details,
    get_model_materializations,
    get_downstream_impact,
    get_relation_lineage,
    get_column_lineage,
    trace_column,  # Simplified column lineage (model_name + column_name)
    search_graph_nodes,
    # Data query (can fully validate hypotheses)
    list_databases,
    list_schemas,
    list_tables,
    get_table_schema,
    preview_table,
    execute_query,
    run_key_diagnostics,
    run_join_diagnostics,
    run_relationship_health_check,
    # Semantic views (query semantic models, not just tables)
    list_semantic_views,
    query_semantic_view,
    # File exploration (read-only)
    read_file,
    glob_files,
    grep_files,
    # Git history (trace recent changes) - read-only
    git_status,
    git_diff,
    git_log,
    # Compilation check (non-destructive)
    dbt_compile,
]

# Executor specialist has ALL execution capabilities
# This is the ONLY path to make file changes, run dbt build/test, or git commit
EXECUTOR_TOOLS = [
    # File operations (write access)
    read_file,
    write_file,
    edit_file,
    glob_files,
    grep_files,
    # dbt operations (full access)
    dbt_compile,
    dbt_build,
    dbt_run,
    dbt_test,
    # Git operations (full access)
    git_status,
    git_diff,
    git_add,
    git_commit,
    git_branch,
    git_push,
    git_log,
    # Data query (verify changes)
    list_databases,
    list_schemas,
    list_tables,
    get_table_schema,
    preview_table,
    execute_query,
    run_key_diagnostics,
    run_join_diagnostics,
    run_relationship_health_check,
    # Context management (read only — streaming layer auto-persists ExecutionResult)
    get_context_brief,
    list_context_briefs,
    # Plan access (read the plan created by planner)
    get_plan,
    get_active_plan,
]

PLANNER_TOOLS = [
    # Context brief consumption (read explorer/diagnostician findings)
    list_context_briefs,
    get_context_brief,
    # Keep downstream impact for plan-time blast radius checks
    get_downstream_impact,
    # File access (for reading code when needed)
    read_file,
    glob_files,
    grep_files,
    # Plan read-only tools (streaming layer persists the markdown plan as PlanPreview)
    get_plan,
    get_active_plan,
]

REPORT_BUILDER_TOOLS = [
    # Context brief consumption (triage provides context)
    list_context_briefs,
    get_context_brief,
    # Report lifecycle
    create_report,
    list_report_cells,
    # Cell creation
    add_chart_cell,
    add_markdown_cell,
    add_mermaid_cell,
    add_table_cell,
    # Cell modification
    modify_report_cell,
    delete_report_cell,
    # Data preview for building cells
    preview_blob,  # Inspect result_set columns before creating charts/tables
    preview_table,
]


# ============================================================================
# SPECIALIST FACTORY FUNCTIONS
# ============================================================================


def create_explorer_specialist(
    lineage_backend: Optional[LineageStorage] = None,
    data_backend: Optional[DataQueryBackend] = None,
) -> SubAgentConfig:
    """Create explorer specialist with rendered prompts."""
    prompt_data = load_specialist_prompt(
        "explorer", lineage_backend=lineage_backend, data_backend=data_backend
    )
    return SubAgentConfig(
        name=prompt_data["name"],
        description=prompt_data["description"],
        model=prompt_data.get("model") or "anthropic:claude-haiku-4-5",
        instructions=prompt_data["prompt"],
        tools=EXPLORER_TOOLS,
    )


def create_planner_specialist(
    lineage_backend: Optional[LineageStorage] = None,
    data_backend: Optional[DataQueryBackend] = None,
) -> SubAgentConfig:
    """Create planner specialist with rendered prompts."""
    prompt_data = load_specialist_prompt(
        "planner", lineage_backend=lineage_backend, data_backend=data_backend
    )
    return SubAgentConfig(
        name=prompt_data["name"],
        description=prompt_data["description"],
        instructions=prompt_data["prompt"],
        tools=PLANNER_TOOLS,
        model=prompt_data.get("model") or "anthropic:claude-haiku-4-5",
    )


def create_executor_specialist(
    lineage_backend: Optional[LineageStorage] = None,
    data_backend: Optional[DataQueryBackend] = None,
) -> SubAgentConfig:
    """Create executor specialist with rendered prompts.

    The executor is the ONLY specialist with write access to files, dbt build/test,
    and git commit operations. This creates an explicit execution gate that forces
    thorough investigation before any changes are made.

    Args:
        lineage_backend: Optional lineage backend for rendering graph schema in prompts
        data_backend: Optional data backend for query hints

    Returns:
        SubAgentConfig for the executor specialist
    """
    prompt_data = load_specialist_prompt(
        "executor", lineage_backend=lineage_backend, data_backend=data_backend
    )
    return SubAgentConfig(
        name=prompt_data["name"],
        description=prompt_data["description"],
        model=prompt_data.get("model") or "anthropic:claude-haiku-4-5",
        instructions=prompt_data["prompt"],
        tools=EXECUTOR_TOOLS,
    )


def create_diagnostician_specialist(
    lineage_backend: Optional[LineageStorage] = None,
    data_backend: Optional[DataQueryBackend] = None,
) -> SubAgentConfig:
    """Create diagnostician specialist with rendered prompts.

    The diagnostician is the hypothesis investigation specialist. It shares
    EXPLORER_TOOLS but uses a diagnostic-focused prompt for root cause tracing.
    """
    prompt_data = load_specialist_prompt(
        "diagnostician", lineage_backend=lineage_backend, data_backend=data_backend
    )
    return SubAgentConfig(
        name=prompt_data["name"],
        description=prompt_data["description"],
        model=prompt_data.get("model") or "anthropic:claude-haiku-4-5",
        instructions=prompt_data["prompt"],
        tools=EXPLORER_TOOLS,
    )


def create_mechanic_specialist(
    lineage_backend: Optional[LineageStorage] = None,
    data_backend: Optional[DataQueryBackend] = None,
) -> SubAgentConfig:
    """Create mechanic specialist with rendered prompts.

    The mechanic is the bug fix implementation specialist. It shares
    EXECUTOR_TOOLS but uses a fix-oriented prompt (do NOT re-investigate).
    """
    prompt_data = load_specialist_prompt(
        "mechanic", lineage_backend=lineage_backend, data_backend=data_backend
    )
    return SubAgentConfig(
        name=prompt_data["name"],
        description=prompt_data["description"],
        model=prompt_data.get("model") or "anthropic:claude-haiku-4-5",
        instructions=prompt_data["prompt"],
        tools=EXECUTOR_TOOLS,
    )


def create_report_builder_specialist(
    lineage_backend: Optional[LineageStorage] = None,
    data_backend: Optional[DataQueryBackend] = None,
) -> SubAgentConfig:
    """Create report_builder specialist with rendered prompts."""
    prompt_data = load_specialist_prompt(
        "report_builder", lineage_backend=lineage_backend, data_backend=data_backend
    )
    return SubAgentConfig(
        name=prompt_data["name"],
        description=prompt_data["description"],
        model=prompt_data.get("model") or "anthropic:claude-haiku-4-5",
        instructions=prompt_data["prompt"],
        tools=REPORT_BUILDER_TOOLS,
    )


# ============================================================================
# SPECIALIST GROUP FACTORY FUNCTIONS
# ============================================================================


def get_all_specialists(
    lineage_backend: Optional[LineageStorage] = None,
    data_backend: Optional[DataQueryBackend] = None,
) -> list[SubAgentConfig]:
    """Get specialists for copilot/reconciler: 5-specialist architecture.

    5-specialist architecture with diagnostic/additive split:
    - Explorer: general-purpose codebase exploration, convention discovery
    - Diagnostician: hypothesis investigation, upstream root cause tracing
    - Planner: adaptive planning for both diagnostic and additive workflows
    - Executor: general-purpose builder for new models and features
    - Mechanic: bug fix implementation, verify-then-commit

    Explorer/diagnostician share EXPLORER_TOOLS (read-only).
    Executor/mechanic share EXECUTOR_TOOLS (write access).
    The orchestrator chooses the right specialist based on task type.

    Args:
        lineage_backend: Optional lineage backend for rendering graph schema in prompts
        data_backend: Optional data backend for semantic view query hints

    Returns:
        List of SubAgentConfig for: explorer, diagnostician, planner, executor, mechanic
    """
    return [
        create_explorer_specialist(lineage_backend, data_backend),
        create_diagnostician_specialist(lineage_backend, data_backend),
        create_planner_specialist(lineage_backend, data_backend),
        create_executor_specialist(lineage_backend, data_backend),
        create_mechanic_specialist(lineage_backend, data_backend),
    ]


# Backward-compatible alias — git/no-git specialist sets are identical
# because executor/mechanic always include git tools (they just no-op without git config).
get_specialists_no_git = get_all_specialists


def get_investigator_specialists(
    lineage_backend: Optional[LineageStorage] = None,
    data_backend: Optional[DataQueryBackend] = None,
) -> list[SubAgentConfig]:
    """Get specialists for investigator agent.

    Uses 2 specialists:
    - explorer: Full investigation capability (graph + data + files)
    - report_builder: Create visual summaries with mermaid diagrams

    Args:
        lineage_backend: Optional lineage backend for rendering graph schema in prompts
        data_backend: Optional data backend for query hints

    Returns:
        List of SubAgentConfig for: explorer, report_builder
    """
    return [
        create_explorer_specialist(lineage_backend, data_backend),
        create_report_builder_specialist(lineage_backend, data_backend),
    ]
