"""Streaming subagent toolset with AG-UI event forwarding.

This module provides an alternative to pydantic-deep's subagent toolset that
streams subagent tool calls as AG-UI events, making them visible in the TUI.

Key insight: pydantic-ai's AG-UI adapter checks tool return metadata for BaseEvent
instances and yields them to the parent stream (see _event_stream.py lines 225-236).

The trick is that tools can return a `ToolReturn` object with `metadata` containing
AG-UI events. When pydantic-ai processes the tool result, it checks if metadata
contains BaseEvent instances and yields them to the stream.

Usage:
    from lineage.agent.pydantic.streaming_subagents import create_streaming_subagent_toolset

    toolset = create_streaming_subagent_toolset(
        subagents=COPILOT_SPECIALISTS,
        default_model="anthropic:claude-sonnet-4-20250514",
    )

    # Use with create_deep_agent(include_subagents=False) + this toolset
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from datetime import datetime
from typing import Any, List

from pydantic_ai import Agent, RunContext
from pydantic_ai.messages import (
    FunctionToolResultEvent,
    PartDeltaEvent,
    PartEndEvent,
    PartStartEvent,
    ToolCallPart,
    ToolCallPartDelta,
    ToolReturn,
    ToolReturnPart,
)
from pydantic_ai.run import AgentRunResultEvent
from pydantic_ai.toolsets import FunctionToolset
from pydantic_deep.types import SubAgentConfig

from lineage.agent.pydantic.deep_types import CopilotDeps
from lineage.agent.pydantic.tools.context import persist_context_brief
from lineage.agent.pydantic.tools.plan import persist_plan
from lineage.agent.pydantic.types import (
    ContextBrief,
    DiagnosticResult,
    ExecutionResult,
    ExplorationResult,
    PlanPreview,
    SubagentType,
    coerce_subagent_type,
)
from lineage.agent.pydantic.utils import create_model, sanitize_tool_call_args

try:
    from ag_ui.core import (
        BaseEvent,
        CustomEvent,
        ToolCallArgsEvent,
        ToolCallEndEvent,
        ToolCallResultEvent,
        ToolCallStartEvent,
    )

    AG_UI_AVAILABLE = True
except ImportError:
    AG_UI_AVAILABLE = False
    BaseEvent = None  # type: ignore

logger = logging.getLogger(__name__)


# ============================================================================
# Markdown formatters for typed specialist outputs → context brief content
# ============================================================================


def _diagnostic_to_markdown(r: DiagnosticResult) -> str:
    """Format a DiagnosticResult into findings_markdown for a context brief."""
    lines = [
        f"## Diagnostic Result: {r.verdict.value}",
        "",
        f"**Hypothesis**: {r.hypothesis}",
        "",
    ]
    if r.root_cause_model:
        lines += [f"**Root Cause Model**: `{r.root_cause_model}`", ""]
    if r.root_cause_explanation:
        lines += [f"**Root Cause**: {r.root_cause_explanation}", ""]
    lines += [
        "## Reasoning",
        "",
        r.reasoning,
        "",
        "## Recommendation",
        "",
        r.recommendation,
    ]
    return "\n".join(lines)


def _exploration_to_markdown(r: ExplorationResult) -> str:
    """Format an ExplorationResult into findings_markdown for a context brief."""
    lines = [
        f"## Exploration Result (task_type: {r.task_type})",
        "",
        "## Key Findings",
        "",
    ]
    for finding in r.key_findings:
        lines.append(f"- {finding}")
    lines += ["", "## Reasoning", "", r.reasoning]
    if r.conventions_summary:
        lines += ["", "## Conventions", "", r.conventions_summary]
    return "\n".join(lines)


def _diagnostic_to_summary(r: DiagnosticResult) -> str:
    """Format a DiagnosticResult as a concise human-readable summary for the TUI."""
    lines = [f"**Verdict**: {r.verdict.value}", f"**Hypothesis**: {r.hypothesis}"]
    if r.root_cause_model:
        lines.append(f"**Model**: `{r.root_cause_model}`")
    if r.root_cause_explanation:
        lines.append(f"**Root Cause**: {r.root_cause_explanation}")
    lines.append(f"**Recommendation**: {r.recommendation}")
    return "\n\n".join(lines)


def _exploration_to_summary(r: ExplorationResult) -> str:
    """Format an ExplorationResult as a concise human-readable summary for the TUI."""
    findings = "\n".join(f"- {f}" for f in r.key_findings)
    lines = [f"**Task Type**: {r.task_type}", f"**Key Findings**:\n{findings}"]
    if r.conventions_summary:
        lines.append(f"**Conventions**: {r.conventions_summary}")
    return "\n\n".join(lines)


def _execution_to_markdown(r: "ExecutionResult") -> str:
    """Format an ExecutionResult as findings_markdown for a context brief."""
    status = "succeeded" if r.success else "FAILED"
    lines = [f"## Execution {status}", "", r.summary]
    if r.files_changed:
        lines += ["", "**Files changed:**"]
        lines += [f"- `{f}`" for f in r.files_changed]
    if r.dbt_result:
        lines += ["", f"**dbt result:** {r.dbt_result}"]
    if r.commit_message:
        lines += ["", f"**Commit:** {r.commit_message}"]
    if r.reasoning:
        lines += ["", f"**Reasoning:** {r.reasoning}"]
    return "\n".join(lines)


def _parse_plan_title_goal(markdown: str) -> tuple[str, str]:
    """Extract title and goal from a planner markdown response."""
    lines = markdown.splitlines()
    title = next(
        (line.lstrip("# ").strip() for line in lines if line.startswith("#")),
        "Plan",
    )
    goal_line = next((line for line in lines if "**Goal:**" in line), None)
    goal = goal_line.replace("**Goal:**", "").strip() if goal_line else ""
    return title, goal


STREAMING_SUBAGENT_SYSTEM_PROMPT = """
## Task Delegation

You have access to the `task` tool for delegating work to specialized subagents.
Use this when:

1. A task requires specialized knowledge or tools
2. You want to isolate a complex subtask
3. The task would benefit from focused expertise

Subagents have:
- Their own system prompts and specialized tools
- Access to the same backends (lineage graph, data warehouse, etc.)
- Fresh context (no access to your conversation history)

When delegating:
- Provide clear, specific instructions
- Specify the expected output format
- The subagent will return a summary of their work
- All subagent tool calls are visible in the UI
"""


def create_streaming_subagent_toolset(
    subagents: list[SubAgentConfig],
    default_model: str = "anthropic:claude-sonnet-4-20250514",
    include_general_purpose: bool = False,
    specialist_models: dict[str, str] | None = None,
    skills_toolset: Any | None = None,
    specialist_skills: dict[str, list[str]] | None = None,
    todo_toolset: Any | None = None,
    specialist_output_types: dict[str, type] | None = None,
) -> FunctionToolset[CopilotDeps]:
    """Create a streaming subagent toolset that forwards AG-UI events.

    Unlike pydantic-deep's default subagent toolset which uses Agent.run(),
    this toolset uses Agent.iter() to stream execution and collects AG-UI
    events that are forwarded to the parent stream via tool return metadata.

    Args:
        subagents: List of subagent configurations (from specialists.py)
        default_model: Default model for subagents
        include_general_purpose: Whether to include a general-purpose fallback
        specialist_models: Optional dict mapping specialist names to model strings
                           e.g., {"coder": "bedrock:arn:...", "explorer": "bedrock:arn:..."}
                           Takes precedence over config["model"] and default_model.
        skills_toolset: Optional SkillsToolset to attach to each specialist agent,
                        giving them access to domain knowledge skills via load_skill().
        specialist_skills: Optional dict mapping specialist names to lists of allowed
                           skill names.  When provided and skills_toolset is set, each
                           specialist receives a filtered SkillsToolset containing only
                           the skills in its allowlist.  Specialists not in this mapping
                           receive the full skills_toolset.
        todo_toolset: Optional todo toolset (from pydantic-ai-todo) to include in
                      each specialist's toolsets, giving them access to shared todo state.
        specialist_output_types: Optional dict mapping specialist names to Pydantic
                                 output types (e.g. {"diagnostician": DiagnosticResult}).
                                 When set, the matching specialist agent uses structured
                                 output instead of str.  The streaming layer auto-persists
                                 typed results to the appropriate store.

    Returns:
        FunctionToolset with the streaming `task` tool

    Raises:
        ValueError: If specialist_models is provided but doesn't cover all specialists.
                    This is all-or-nothing: either use YAML defaults for all, or configure all.
    """
    subagent_configs = list(subagents)

    # Validate specialist_models covers all specialists (all-or-nothing)
    if specialist_models:
        subagent_names = {config["name"] for config in subagent_configs}
        configured_names = set(specialist_models.keys())
        missing = subagent_names - configured_names
        if missing:
            raise ValueError(
                f"specialist_models must configure ALL specialists or be omitted entirely. "
                f"Missing: {sorted(missing)}. "
                f"Required: {sorted(subagent_names)}"
            )

    # Build description of available subagents for docstring
    subagent_descriptions = []
    for config in subagent_configs:
        subagent_descriptions.append(f"- {config['name']}: {config['description'].strip()}")

    available_subagents = (
        "\n".join(subagent_descriptions) if subagent_descriptions else "No subagents configured"
    )

    # Pre-build per-specialist filtered skills toolsets (avoids rebuilding on each call).
    _specialist_skills_toolsets: dict[str, Any] = {}
    if skills_toolset is not None and specialist_skills:
        from lineage.agent.pydantic.skills_factory import create_filtered_skills_toolset

        for spec_name, allowed in specialist_skills.items():
            _specialist_skills_toolsets[spec_name] = create_filtered_skills_toolset(
                full_toolset=skills_toolset,
                allowed_skills=allowed,
            )

    toolset: FunctionToolset[CopilotDeps] = FunctionToolset()

    # Cache for created subagent Agent instances and their model strings
    _subagent_cache: dict[str, Agent] = {}
    _subagent_models: dict[str, str] = {}  # subagent_type -> model string

    @toolset.tool
    async def task(
        ctx: RunContext[CopilotDeps],
        description: str | None = None,
        subagent_type: str | None = None,
        # Backwards-compatible aliases (pydantic-deep prompts often use name/prompt)
        name: str | None = None,
        prompt: str | None = None,
    ) -> ToolReturn | str:
        """Launch a subagent to handle a specific task.

        The subagent will work autonomously and return a summary of their work.
        All subagent tool calls are streamed to the UI for visibility.

        Args:
            ctx: PydanticAI run context (provides deps, tool call id, and state).
            description: Detailed description of the task for the subagent.
            subagent_type: Type of subagent to use.
            name: Alias for subagent_type.
            prompt: Alias for description.
        """
        # Normalize alias args
        if subagent_type is None and name is not None:
            subagent_type = name
        if description is None and prompt is not None:
            description = prompt

        if not subagent_type:
            return "Error: Missing subagent_type (or name)."
        if not description:
            return "Error: Missing description (or prompt)."

        subagent_type_enum = coerce_subagent_type(subagent_type)
        if subagent_type_enum is None:
            allowed = ", ".join(t.value for t in SubagentType)
            return (
                f"Error: Unknown subagent type '{subagent_type}'. "
                f"Allowed: {allowed}"
            )
        subagent_type = subagent_type_enum.value

        # Ensure implementation specialists always load the current Plan artifact first.
        # This avoids having to inline the plan into every delegation prompt.
        if subagent_type_enum in {SubagentType.EXECUTOR, SubagentType.MECHANIC}:
            plan_id = None
            try:
                plan_id = ctx.deps.state.active_plan_id
                if not plan_id:
                    plans = ctx.deps.state.active_plans
                    if plans:
                        most_recent = max(plans.values(), key=lambda p: p.last_updated)
                        plan_id = most_recent.plan_id
                if not plan_id:
                    tb = ctx.deps.threads_backend
                    thread_id = ctx.deps.thread_id
                    if tb and thread_id:
                        stored = tb.get_metadata(thread_id, "active_plan_id")
                        if isinstance(stored, str) and stored:
                            plan_id = stored
            except Exception:
                plan_id = None

            lowered = description.lower()
            if "get_active_plan" not in lowered and "get_plan" not in lowered:
                prefix = (
                    f"Before you begin, call get_plan(plan_id='{plan_id}') to load the current Plan artifact. "
                    if plan_id
                    else "Before you begin, call get_active_plan() to load the current Plan artifact. "
                )
                prefix += (
                    "Follow that Plan precisely (and if it is missing or unclear, ask the orchestrator to clarify).\n\n"
                )
                description = prefix + description

        # Find the subagent config
        config = None
        for c in subagent_configs:
            if c["name"] == subagent_type:
                config = c
                break

        if config is None:
            available = ", ".join(c["name"] for c in subagent_configs)
            return f"Error: Unknown subagent type '{subagent_type}'. Available: {available}"

        # Get or create the subagent
        if subagent_type in _subagent_cache:
            subagent = _subagent_cache[subagent_type]
        else:
            # Model resolution priority: specialist_models > config["model"] > default_model
            if specialist_models and subagent_type in specialist_models:
                model_name = specialist_models[subagent_type]
            else:
                model_name = config.get("model", default_model)
            tools = config.get("tools", [])
            system_prompt = config.get("instructions", "Complete the given task thoroughly.")

            # Resolve output type: use structured Pydantic model when configured,
            # else fall back to plain str.
            output_type = (specialist_output_types or {}).get(subagent_type, str)

            # Build toolsets for the specialist (skills give access to domain knowledge).
            # Use the per-specialist filtered toolset when available, else fall back
            # to the full (unfiltered) skills_toolset.
            _effective_skills = _specialist_skills_toolsets.get(subagent_type, skills_toolset)
            specialist_toolsets = [_effective_skills] if _effective_skills else []
            if todo_toolset is not None:
                specialist_toolsets.append(todo_toolset)

            subagent = Agent(
                # enable_thinking=False is now the default for Bedrock due to pydantic-ai
                # not preserving thinking blocks in multi-turn conversation history.
                # See: https://github.com/pydantic/pydantic-ai/issues/3757
                model=create_model(model_name),
                system_prompt=system_prompt,  # Static system prompt from specialist config
                deps_type=CopilotDeps,
                retries=3,
                output_type=output_type,
                # Sanitize broken tool call args in history to prevent Anthropic adapter
                # crash when re-serializing truncated JSON (ValueError in args_as_dict).
                history_processors=[sanitize_tool_call_args],
                toolsets=specialist_toolsets if specialist_toolsets else [],
            )

            # Add custom tools
            for tool in tools:
                if callable(tool):
                    subagent.tool(tool)

            _subagent_cache[subagent_type] = subagent
            _subagent_models[subagent_type] = model_name

        # Create isolated deps for the subagent
        subagent_deps = ctx.deps.clone_for_subagent()

        # Collect AG-UI events from subagent execution
        collected_events: List[BaseEvent] = [] if AG_UI_AVAILABLE else []
        final_output: str | None = ""
        activity_id = uuid.uuid4().hex
        parent_tool_call_id = ctx.tool_call_id or f"task_{uuid.uuid4().hex}"

        # Track tool call counts and ordered sequence for this subagent (for benchmark reporting)
        subagent_tool_counts: dict[str, int] = {}
        subagent_tool_sequence: list[tuple[str, str]] = []  # [(tool_name, args_json), ...]

        ui_event_queue: asyncio.Queue[BaseEvent] | None = ctx.deps.ui_event_queue
        injected_live = AG_UI_AVAILABLE and ui_event_queue is not None

        def _publish_event(event: BaseEvent) -> None:
            if not AG_UI_AVAILABLE:
                return
            collected_events.append(event)
            if ui_event_queue is not None:
                try:
                    ui_event_queue.put_nowait(event)
                except Exception:
                    # Never let UI publishing interfere with agent execution.
                    logger.debug("Failed to publish subagent highlight event", exc_info=True)

        # Per-subagent timeout (seconds).  Prevents one subagent from consuming
        # the entire benchmark / agent budget.  Individual API calls already have
        # a 180 s timeout via model settings; this is the outer guard for the full
        # multi-turn subagent run.
        _SUBAGENT_TIMEOUT: float = 600  # 10 minutes

        try:
            # Publish activity start so the TUI can open a collapsible block immediately.
            if AG_UI_AVAILABLE:
                _publish_event(
                    CustomEvent(
                        name="subagent_activity_start",
                        value={
                            "activity_id": activity_id,
                            "subagent_type": subagent_type,
                            "parent_tool_call_id": parent_tool_call_id,
                            "input_prompt": description,  # Original task given to subagent
                        },
                    )
                )

            # Stream subagent execution events (includes tool call boundaries).
            # NOTE: When we exit this loop early (via cancellation), pydantic-ai's internal
            # task continues running and will raise BrokenResourceError when it tries to
            # send to the now-closed stream. This results in an asyncio "Task exception was
            # never retrieved" warning. This is expected and unavoidable with the current
            # pydantic-ai API - the cancellation still works correctly.
            tool_call_id_map: dict[str, str] = {}
            async with asyncio.timeout(_SUBAGENT_TIMEOUT):
                async for event in subagent.run_stream_events(description, deps=subagent_deps):
                    # Check for cancellation between events
                    if ctx.deps.is_cancelled:
                        logger.info(f"Subagent '{subagent_type}' cancelled by parent")
                        if AG_UI_AVAILABLE:
                            _publish_event(
                                CustomEvent(
                                    name="subagent_activity_cancelled",
                                    value={
                                        "activity_id": activity_id,
                                        "subagent_type": subagent_type,
                                        "parent_tool_call_id": parent_tool_call_id,
                                    },
                                )
                            )
                        return f"Subagent '{subagent_type}' was cancelled"

                    match event:
                        case PartStartEvent(part=ToolCallPart() as part):
                            # Track tool call count and sequence for benchmark reporting
                            subagent_tool_counts[part.tool_name] = subagent_tool_counts.get(part.tool_name, 0) + 1
                            args_json = part.args_as_json_str() if part.args else "{}"
                            subagent_tool_sequence.append((part.tool_name, args_json[:2000]))

                            # Prefix tool_call_id so it won't collide with parent tool calls.
                            unique_id = f"subact_{activity_id}__{part.tool_call_id}"
                            tool_call_id_map[part.tool_call_id] = unique_id
                            _publish_event(
                                ToolCallStartEvent(
                                    tool_call_id=unique_id,
                                    tool_call_name=part.tool_name,
                                    parent_message_id=parent_tool_call_id,
                                )
                            )
                            if part.args:
                                _publish_event(
                                    ToolCallArgsEvent(
                                        tool_call_id=unique_id,
                                        delta=part.args_as_json_str(),
                                    )
                                )
                        case PartDeltaEvent(delta=ToolCallPartDelta() as delta):
                            original_id = delta.tool_call_id
                            if not original_id:
                                continue
                            unique_id = tool_call_id_map.get(original_id)
                            if not unique_id:
                                continue
                            if delta.args_delta:
                                delta_str = (
                                    delta.args_delta
                                    if isinstance(delta.args_delta, str)
                                    else json.dumps(delta.args_delta)
                                )
                                _publish_event(
                                    ToolCallArgsEvent(
                                        tool_call_id=unique_id,
                                        delta=delta_str,
                                    )
                                )
                        case PartEndEvent(part=ToolCallPart() as part):
                            unique_id = tool_call_id_map.get(part.tool_call_id)
                            if unique_id:
                                _publish_event(ToolCallEndEvent(tool_call_id=unique_id))
                        case FunctionToolResultEvent(result=ToolReturnPart() as result):
                            unique_id = tool_call_id_map.get(result.tool_call_id, result.tool_call_id)
                            # Emit the real tool output so the TUI can render it inline using the
                            # same result parsing as primary agent tool calls.
                            content_str = result.model_response_str()
                            # Defensive truncation to avoid huge tool outputs breaking the UI.
                            if len(content_str) > 100_000:
                                content_str = content_str[:100_000] + "\n...(truncated)..."
                            _publish_event(
                                ToolCallResultEvent(
                                    message_id=f"msg_{unique_id}",
                                    tool_call_id=unique_id,
                                    content=content_str,
                                    role="tool",
                                )
                            )
                        case AgentRunResultEvent():
                            result_output = event.result.output if hasattr(event.result, "output") else None

                            if isinstance(result_output, DiagnosticResult):
                                findings = _diagnostic_to_markdown(result_output)
                                brief_id = result_output.brief_id or f"brief_{uuid.uuid4().hex[:10]}"
                                brief = ContextBrief(
                                    brief_id=brief_id,
                                    source="diagnostician",
                                    task_type="diagnostic",
                                    title=f"Diagnostic: {result_output.verdict.value} — {result_output.hypothesis[:80]}",
                                    findings_markdown=findings,
                                    created_at=datetime.now(),
                                )
                                persist_context_brief(
                                    ctx.deps.state, ctx.deps.threads_backend,
                                    ctx.deps.thread_id, ctx.deps.run_id, brief,
                                )
                                if AG_UI_AVAILABLE:
                                    _publish_event(
                                        CustomEvent(
                                            name="context_brief",
                                            value={
                                                "brief_id": brief.brief_id,
                                                "brief": brief.model_dump(mode="json"),
                                                "parent_tool_call_id": parent_tool_call_id,
                                            },
                                        )
                                    )
                                final_output = _diagnostic_to_summary(result_output)

                            elif isinstance(result_output, ExplorationResult):
                                findings = _exploration_to_markdown(result_output)
                                brief_id = result_output.brief_id or f"brief_{uuid.uuid4().hex[:10]}"
                                brief = ContextBrief(
                                    brief_id=brief_id,
                                    source="explorer",
                                    task_type=result_output.task_type,
                                    title=description.strip().splitlines()[0] if description else "Explorer Findings",
                                    findings_markdown=findings,
                                    created_at=datetime.now(),
                                )
                                persist_context_brief(
                                    ctx.deps.state, ctx.deps.threads_backend,
                                    ctx.deps.thread_id, ctx.deps.run_id, brief,
                                )
                                if AG_UI_AVAILABLE:
                                    _publish_event(
                                        CustomEvent(
                                            name="context_brief",
                                            value={
                                                "brief_id": brief.brief_id,
                                                "brief": brief.model_dump(mode="json"),
                                                "parent_tool_call_id": parent_tool_call_id,
                                            },
                                        )
                                    )
                                final_output = _exploration_to_summary(result_output)

                            elif subagent_type == "planner" and isinstance(result_output, str):
                                title, goal = _parse_plan_title_goal(result_output)
                                plan_preview = PlanPreview(
                                    plan_id=f"plan_{uuid.uuid4().hex[:10]}",
                                    title=title,
                                    goal=goal,
                                    status="final",
                                    last_updated=datetime.now(),
                                    markdown_body=result_output,
                                )
                                persist_plan(
                                    ctx.deps.state, ctx.deps.threads_backend,
                                    ctx.deps.thread_id, ctx.deps.run_id, plan_preview,
                                    ui_event_queue=ctx.deps.ui_event_queue,
                                )
                                final_output = result_output

                            elif isinstance(result_output, ExecutionResult):
                                status = "succeeded" if result_output.success else "FAILED"
                                final_output = f"**{status}**: {result_output.summary}"
                                if result_output.files_changed:
                                    files = ", ".join(f"`{f}`" for f in result_output.files_changed)
                                    final_output += f"\n\n**Files changed**: {files}"
                                if result_output.commit_message:
                                    final_output += f"\n\n**Commit**: {result_output.commit_message}"
                                brief_id = result_output.brief_id or f"brief_{uuid.uuid4().hex[:10]}"
                                # ExecutionResult is only expected from executor/mechanic;
                                # guard against an invalid BriefSource if somehow reached elsewhere.
                                brief_source = subagent_type if subagent_type in ("executor", "mechanic") else "executor"
                                brief = ContextBrief(
                                    brief_id=brief_id,
                                    source=brief_source,
                                    task_type="additive" if result_output.success else "diagnostic",
                                    title=f"Execution {status}: {result_output.summary[:80]}",
                                    findings_markdown=_execution_to_markdown(result_output),
                                    created_at=datetime.now(),
                                )
                                persist_context_brief(
                                    ctx.deps.state, ctx.deps.threads_backend,
                                    ctx.deps.thread_id, ctx.deps.run_id, brief,
                                )
                                if AG_UI_AVAILABLE:
                                    _publish_event(
                                        CustomEvent(
                                            name="context_brief",
                                            value={
                                                "brief_id": brief.brief_id,
                                                "brief": brief.model_dump(mode="json"),
                                                "parent_tool_call_id": parent_tool_call_id,
                                            },
                                        )
                                    )

                            elif result_output is not None:
                                final_output = str(result_output)

                            # Capture usage for per-subagent cost calculation
                            if hasattr(event.result, "usage"):
                                run_usage = event.result.usage()
                                if run_usage is not None:
                                    model_str = _subagent_models.get(subagent_type, default_model)
                                    if subagent_type not in ctx.deps.subagent_usage:
                                        ctx.deps.subagent_usage[subagent_type] = []
                                    ctx.deps.subagent_usage[subagent_type].append((model_str, run_usage))
                        case CustomEvent():
                            # Forward custom events (like plan_snapshot, context_brief) from subagent to parent
                            _publish_event(event)
                        case _:
                            # Ignore non-tool-related events.
                            pass

            # Store subagent tool call counts and sequences in deps for benchmark reporting
            if subagent_tool_counts:
                if subagent_type not in ctx.deps.subagent_tool_call_counts:
                    ctx.deps.subagent_tool_call_counts[subagent_type] = {}
                for tool_name, count in subagent_tool_counts.items():
                    existing = ctx.deps.subagent_tool_call_counts[subagent_type].get(tool_name, 0)
                    ctx.deps.subagent_tool_call_counts[subagent_type][tool_name] = existing + count
            if subagent_tool_sequence:
                if subagent_type not in ctx.deps.subagent_tool_call_sequences:
                    ctx.deps.subagent_tool_call_sequences[subagent_type] = []
                ctx.deps.subagent_tool_call_sequences[subagent_type].extend(subagent_tool_sequence)

            # Publish activity end so the TUI can finalize the block.
            if AG_UI_AVAILABLE:
                _publish_event(
                    CustomEvent(
                        name="subagent_activity_end",
                        value={
                            "activity_id": activity_id,
                            "subagent_type": subagent_type,
                            "parent_tool_call_id": parent_tool_call_id,
                        },
                    )
                )

        except TimeoutError:
            logger.warning(
                f"Subagent '{subagent_type}' timed out after {_SUBAGENT_TIMEOUT}s"
            )
            if AG_UI_AVAILABLE:
                _publish_event(
                    CustomEvent(
                        name="subagent_activity_cancelled",
                        value={
                            "activity_id": activity_id,
                            "subagent_type": subagent_type,
                            "parent_tool_call_id": parent_tool_call_id,
                        },
                    )
                )
            return f"Subagent '{subagent_type}' timed out after {_SUBAGENT_TIMEOUT}s. Partial findings may have been saved via save_context_brief."
        except asyncio.CancelledError:
            logger.info(f"Subagent '{subagent_type}' received CancelledError")
            ctx.deps.request_cancellation()  # Propagate to nested subagents
            if AG_UI_AVAILABLE:
                _publish_event(
                    CustomEvent(
                        name="subagent_activity_cancelled",
                        value={
                            "activity_id": activity_id,
                            "subagent_type": subagent_type,
                            "parent_tool_call_id": parent_tool_call_id,
                        },
                    )
                )
            raise
        except Exception as e:
            logger.error(f"Subagent '{subagent_type}' failed: {e}", exc_info=True)
            return f"Subagent '{subagent_type}' failed: {e}"

        summary = f"Subagent '{subagent_type}' completed:\n\n{final_output}"

        # If we injected events live into the parent SSE stream, do NOT return them again
        # via ToolReturn metadata (it would duplicate the UI highlights at the end).
        if injected_live:
            return summary

        # Fallback: return events in metadata - pydantic-ai will yield these to the stream
        if collected_events and AG_UI_AVAILABLE:
            logger.info(
                f"Subagent '{subagent_type}' completed with {len(collected_events)} AG-UI events"
            )
            return ToolReturn(
                return_value=summary,
                metadata=collected_events,  # List of BaseEvent instances
            )

        return summary

    # Update docstring with available subagents
    if task.__doc__:
        task.__doc__ += f"\n\nAvailable subagent types:\n{available_subagents}"

    return toolset


def get_streaming_subagent_system_prompt(
    subagent_configs: list[SubAgentConfig] | None = None,
) -> str:
    """Generate system prompt section for streaming subagent tools.

    Args:
        subagent_configs: List of subagent configurations.

    Returns:
        System prompt section describing available subagents.
    """
    prompt = STREAMING_SUBAGENT_SYSTEM_PROMPT

    if subagent_configs:
        prompt += "\n\n### Available Subagents\n"
        for config in subagent_configs:
            prompt += f"\n**{config['name']}**: {config['description'].strip()}\n"

    return prompt
