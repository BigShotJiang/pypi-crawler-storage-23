"""Unit tests for Plan artifact tools (persist_plan helper + read-only tools)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import TYPE_CHECKING, Any, List

if TYPE_CHECKING:
    from lineage.backends.threads.models import RunSummary

import pytest
from lineage.agent.pydantic.tools.plan import (
    get_active_plan,
    get_plan,
    persist_plan,
)
from lineage.agent.pydantic.types import (
    AgentDeps,
    AgentState,
    PlanPreview,
    PlanSection,
    PlanStep,
    PlanView,
)
from lineage.backends.threads.models import Artifact, StoredMessage, ThreadContext


@dataclass
class _FakeCtx:
    """Minimal RunContext stand-in for unit tests."""

    deps: AgentDeps
    tool_call_id: str = "toolcall_test"


class _FakeThreadsBackend:
    """Minimal threads backend for plan tool tests."""

    def __init__(self) -> None:
        self._threads: dict[str, ThreadContext] = {}
        self._metadata: dict[tuple[str, str], Any] = {}
        self._messages: dict[str, List[StoredMessage]] = {}

    def get_or_create_thread(self, thread_id: str) -> ThreadContext:
        if thread_id not in self._threads:
            self._threads[thread_id] = ThreadContext(thread_id=thread_id)
        return self._threads[thread_id]

    def add_artifact(self, thread_id: str, run_id: str, artifact: Artifact) -> None:
        thread = self.get_or_create_thread(thread_id)
        thread.artifacts.add(artifact)

    def save_run_summary(self, thread_id: str, run_summary: RunSummary) -> None:
        thread = self.get_or_create_thread(thread_id)
        thread.runs.append(run_summary)

    def thread_exists(self, thread_id: str) -> bool:
        return thread_id in self._threads

    def add_message(self, thread_id: str, message: StoredMessage) -> None:
        self._messages.setdefault(thread_id, []).append(message)

    def get_messages(self, thread_id: str) -> List[StoredMessage]:
        return list(self._messages.get(thread_id, []))

    def set_metadata(self, thread_id: str, key: str, value: Any) -> None:
        self._metadata[(thread_id, key)] = value

    def get_metadata(self, thread_id: str, key: str) -> Any | None:
        return self._metadata.get((thread_id, key))


def _make_plan(plan_id: str = "plan_test001", title: str = "Test Plan") -> PlanPreview:
    return PlanPreview(
        plan_id=plan_id,
        title=title,
        goal="Ship feature",
        status="final",
        last_updated=datetime.now(),
        sections=[
            PlanSection(section_id="s1", title="Context", content_markdown="Some context"),
        ],
        steps=[
            PlanStep(step_id="step_1", content="Do the thing", risk="low"),
        ],
    )


def test_persist_plan_updates_state(mock_storage):
    """persist_plan writes the plan into AgentState."""
    state = AgentState()
    plan = _make_plan()

    persist_plan(state=state, threads_backend=None, thread_id="t1", run_id="r1", plan=plan)

    assert plan.plan_id in state.active_plans
    assert state.active_plan_id == plan.plan_id
    assert state.active_plans[plan.plan_id].title == "Test Plan"


def test_persist_plan_writes_to_threads_backend(mock_storage):
    """persist_plan persists a plan artifact to threads_backend."""
    tb = _FakeThreadsBackend()
    state = AgentState()
    plan = _make_plan()

    persist_plan(state=state, threads_backend=tb, thread_id="t1", run_id="r1", plan=plan)

    thread = tb.get_or_create_thread("t1")
    artifact_ids = {a.id for a in thread.artifacts}
    assert plan.plan_id in artifact_ids


@pytest.mark.asyncio
async def test_get_active_plan_uses_thread_context_artifacts(mock_storage):
    """get_active_plan falls back to thread_context artifacts when metadata is missing."""
    threads_backend = _FakeThreadsBackend()
    state = AgentState()
    plan = _make_plan()

    persist_plan(
        state=state,
        threads_backend=threads_backend,
        thread_id="t1",
        run_id="r1",
        plan=plan,
    )

    # Simulate missing active_plan_id pointer for a new run.
    threads_backend.set_metadata("t1", "active_plan_id", None)

    # New run: fresh deps, no in-memory state
    new_deps = AgentDeps(
        lineage=mock_storage,
        thread_id="t1",
        run_id="r2",
        threads_backend=threads_backend,
    )
    new_ctx = _FakeCtx(deps=new_deps)

    active = await get_active_plan(new_ctx)  # type: ignore[arg-type]
    assert isinstance(active, PlanView)
    assert active.plan_id == plan.plan_id
    assert isinstance(active.plan, dict)


@pytest.mark.asyncio
async def test_get_active_plan_finds_subagent_created_plan(mock_storage):
    """get_active_plan finds plans persisted by streaming_subagents by querying threads_backend directly.

    This simulates the scenario where:
    1. Orchestrator starts a run (no in-memory plans)
    2. Planner subagent returns markdown → streaming layer calls persist_plan
    3. Orchestrator calls get_active_plan - it should find the plan by querying threads_backend
    """
    threads_backend = _FakeThreadsBackend()

    # Simulate streaming layer calling persist_plan after planner returns markdown plan
    subagent_state = AgentState()
    plan = _make_plan(plan_id="plan_subagent01", title="Subagent Plan")
    persist_plan(
        state=subagent_state,
        threads_backend=threads_backend,
        thread_id="t1",
        run_id="r1",
        plan=plan,
    )

    # Orchestrator calls get_active_plan with FRESH deps (no in-memory state)
    fresh_orchestrator_deps = AgentDeps(
        lineage=mock_storage,
        thread_id="t1",
        run_id="r1",
        threads_backend=threads_backend,
    )
    orchestrator_ctx = _FakeCtx(deps=fresh_orchestrator_deps)

    active = await get_active_plan(orchestrator_ctx)  # type: ignore[arg-type]
    assert isinstance(active, PlanView), f"Expected PlanView but got {type(active)}: {active}"
    assert active.plan_id == plan.plan_id
    assert isinstance(active.plan, dict)


@pytest.mark.asyncio
async def test_get_plan_returns_plan_view(mock_storage):
    """get_plan returns a PlanView with full plan data."""
    state = AgentState()
    plan = _make_plan(plan_id="plan_viewtest", title="View Test")
    persist_plan(state=state, threads_backend=None, thread_id="t1", run_id="r1", plan=plan)

    deps = AgentDeps(lineage=mock_storage, thread_id="t1", run_id="r1", state=state)
    ctx = _FakeCtx(deps=deps)

    view = await get_plan(ctx, plan_id=plan.plan_id)  # type: ignore[arg-type]
    assert isinstance(view, PlanView), f"Expected PlanView but got {type(view)}: {view}"
    assert view.plan_id == plan.plan_id
    assert view.tool_name == "get_plan"
    assert isinstance(view.plan, dict)
    assert view.plan["title"] == "View Test"
    assert view.plan["goal"] == "Ship feature"


@pytest.mark.asyncio
async def test_get_plan_not_found_returns_error(mock_storage):
    """get_plan returns ToolError for nonexistent plan_id."""
    from lineage.agent.pydantic.tools.common import ToolError

    deps = AgentDeps(lineage=mock_storage, thread_id="t1", run_id="r1")
    ctx = _FakeCtx(deps=deps)

    result = await get_plan(ctx, plan_id="plan_nonexistent")  # type: ignore[arg-type]
    assert isinstance(result, ToolError)
