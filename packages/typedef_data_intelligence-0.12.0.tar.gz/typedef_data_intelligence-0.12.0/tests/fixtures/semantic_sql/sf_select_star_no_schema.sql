SELECT *
FROM events


