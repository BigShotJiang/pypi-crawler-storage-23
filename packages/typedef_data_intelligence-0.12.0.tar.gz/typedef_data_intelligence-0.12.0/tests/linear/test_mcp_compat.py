from types import SimpleNamespace

import pytest

from tests.linear.mcp_compat import (
    extract_issue_from_payload,
    extract_tool_properties,
    filter_args_for_schema,
    resolve_available_tool,
    tool_name_set,
)


def test_resolve_available_tool_prefers_first_candidate() -> None:
    available = {"save_issue", "list_issues"}
    resolved = resolve_available_tool(available, "create_ticket", "save_issue")
    assert resolved == "save_issue"


def test_resolve_available_tool_returns_none_when_missing() -> None:
    available = {"list_issues", "get_issue"}
    assert resolve_available_tool(available, "create_ticket", "save_issue") is None


def test_filter_args_for_schema_maps_aliases() -> None:
    args = {
        "team": "team-1",
        "assignee": "user-1",
        "state": "Todo",
        "labelIds": ["label-1"],
    }
    properties = {"teamId", "assigneeId", "stateName", "labels"}

    filtered = filter_args_for_schema(args, properties)

    assert filtered == {
        "teamId": "team-1",
        "assigneeId": "user-1",
        "stateName": "Todo",
        "labels": ["label-1"],
    }


def test_filter_args_for_schema_keeps_original_key_when_supported() -> None:
    args = {"team": "team-1", "state": "Todo"}
    properties = {"team", "state"}

    assert filter_args_for_schema(args, properties) == args


@pytest.mark.parametrize(
    ("payload", "expected_title"),
    [
        ({"issue": {"id": "1", "title": "from-issue"}}, "from-issue"),
        ({"data": {"id": "2", "title": "from-data"}}, "from-data"),
        ({"id": "3", "title": "direct"}, "direct"),
        ([{"id": "4", "title": "from-list"}], "from-list"),
    ],
)
def test_extract_issue_from_payload(payload, expected_title: str) -> None:
    issue = extract_issue_from_payload(payload)
    assert issue is not None
    assert issue["title"] == expected_title


def test_extract_issue_from_payload_returns_none_for_unexpected_shape() -> None:
    assert extract_issue_from_payload({"ok": True}) is None


def test_extract_tool_properties_reads_input_schema() -> None:
    tool = SimpleNamespace(inputSchema={"properties": {"team": {}, "title": {}}})
    assert extract_tool_properties(tool) == {"team", "title"}


def test_extract_tool_properties_falls_back_to_input_schema_alias() -> None:
    tool = SimpleNamespace(input_schema={"properties": {"id": {}, "state": {}}})
    assert extract_tool_properties(tool) == {"id", "state"}


@pytest.mark.parametrize(
    "tool",
    [
        SimpleNamespace(inputSchema="not-a-dict"),
        SimpleNamespace(inputSchema={"type": "object"}),
        SimpleNamespace(inputSchema={"properties": ["id"]}),
        SimpleNamespace(),
    ],
)
def test_extract_tool_properties_returns_none_for_invalid_shapes(tool) -> None:
    assert extract_tool_properties(tool) is None


def test_tool_name_set_returns_named_tools_only() -> None:
    tools = [
        SimpleNamespace(name="save_issue"),
        SimpleNamespace(name="update_ticket"),
        SimpleNamespace(name=None),
        SimpleNamespace(),
        object(),
    ]
    assert tool_name_set(tools) == {"save_issue", "update_ticket"}


def test_tool_name_set_handles_empty_iterable() -> None:
    assert tool_name_set([]) == set()
