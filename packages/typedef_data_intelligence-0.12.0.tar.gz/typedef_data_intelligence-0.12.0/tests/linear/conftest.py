"""Shared fixtures for Linear tests.

All tests in this directory hit the live Linear API and are marked as
integration tests.  They are skipped by default unless explicitly selected
with ``pytest -m integration``.

Team IDs
--------
The workspace has two demo teams used for different purposes:

  - "DEV - Data Engineer Demo" (DAV, 9f10c9f4-...)
        Used by these integration tests.  Tests create, update, and
        delete issues here.

  - "DE Demo" (DEM, 2832d96a-...)
        Used by the reset/demo scripts (reset_linear_workspace.py,
        reset_demo_linear.py).  Not touched by tests.

These are intentionally separate so that test runs never interfere
with the demo workspace and vice-versa.
"""
import os
from pathlib import Path
import pytest
from dotenv import load_dotenv

# Load .env from monorepo root (one level above package root)
package_root = Path(__file__).parent.parent.parent
repo_root = package_root.parent
for candidate in [repo_root / ".env", repo_root / ".local.env", repo_root / ".test.env"]:
    if candidate.exists():
        load_dotenv(candidate)


@pytest.fixture
def linear_api_key():
    """Fixture for Linear API key."""
    key = os.getenv("LINEAR_DATA_ENGINEER_API_KEY")
    if not key:
        pytest.skip("LINEAR_DATA_ENGINEER_API_KEY environment variable is not set")
    return key


@pytest.fixture
def linear_team_id():
    """Fixture for Linear team ID — hardcoded to DEV - Data Engineer Demo (DAV)."""
    return "9f10c9f4-b4d3-41f4-a3e2-6a5382c53182"


@pytest.fixture
def linear_team_name(linear_api_key, linear_team_id):
    """Resolve the team name from the hardcoded team ID via the Linear API."""
    from linear_api import LinearClient
    client = LinearClient(api_key=linear_api_key)
    team = client.teams.get(linear_team_id)
    return team.name


@pytest.fixture
def config_path():
    """Fixture for config.yml path."""
    repo_root = Path(__file__).parent.parent.parent
    config_path = repo_root / "config.yml"
    if not config_path.exists():
        pytest.skip("config.yml not found")
    return config_path
