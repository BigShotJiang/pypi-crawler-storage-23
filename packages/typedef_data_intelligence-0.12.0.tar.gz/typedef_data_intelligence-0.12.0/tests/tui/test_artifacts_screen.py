"""Tests for ArtifactsScreen behavior."""

from types import SimpleNamespace

import pytest
from lineage.tui.screens.artifacts import ArtifactsScreen
from lineage.tui.widgets.artifacts.artifact_types import (
    ArtifactData,
    ExportReportRequest,
)


class _StubFocusable:
    def __init__(self) -> None:
        self.focused = False

    def focus(self) -> None:
        self.focused = True


class _StubViewer:
    def __init__(self) -> None:
        self.artifacts: list[ArtifactData] = []
        self.activities: list[ArtifactData] = []
        self.artifact_list = _StubFocusable()
        self.populate_calls: list[tuple[list[ArtifactData], list[ArtifactData]]] = []
        self.selected_ids: list[str] = []

    def populate_from(
        self, artifacts: list[ArtifactData], activities: list[ArtifactData]
    ) -> None:
        self.populate_calls.append((list(artifacts), list(activities)))
        self.artifacts = list(artifacts)
        self.activities = list(activities)

    def select_artifact_by_id(self, artifact_id: str) -> None:
        self.selected_ids.append(artifact_id)


def _artifact(artifact_id: str, kind: str = "report") -> ArtifactData:
    return ArtifactData(
        id=artifact_id,
        type=kind,
        title=f"Artifact {artifact_id}",
        data={},
        render_func=lambda *_: None,
    )


def test_artifacts_screen_refresh_populates_and_focuses_artifacts() -> None:
    """Modal refresh mirrors source state and focuses artifact list when present."""
    source_viewer = SimpleNamespace(
        artifacts=[_artifact("a1")],
        activities=[_artifact("act1", "activity")],
    )
    screen = ArtifactsScreen(source_viewer=source_viewer)
    stub_viewer = _StubViewer()
    screen.viewer = stub_viewer  # type: ignore[assignment]

    screen._refresh_modal_viewer()

    assert len(stub_viewer.populate_calls) == 1
    assert [item.id for item in stub_viewer.populate_calls[0][0]] == ["a1"]
    assert [item.id for item in stub_viewer.populate_calls[0][1]] == ["act1"]
    assert stub_viewer.artifact_list.focused is True


def test_artifacts_screen_refresh_does_not_require_activity_list() -> None:
    """No-artifacts path should not attempt focusing deprecated activity list."""
    source_viewer = SimpleNamespace(
        artifacts=[],
        activities=[_artifact("act1", "activity")],
    )
    screen = ArtifactsScreen(source_viewer=source_viewer)

    class ViewerWithoutActivityList:
        def __init__(self) -> None:
            self.artifacts: list[ArtifactData] = []
            self.activities: list[ArtifactData] = []
            self.artifact_list = _StubFocusable()

        def populate_from(
            self, artifacts: list[ArtifactData], activities: list[ArtifactData]
        ) -> None:
            self.artifacts = list(artifacts)
            self.activities = list(activities)

    screen.viewer = ViewerWithoutActivityList()  # type: ignore[assignment]

    screen._refresh_modal_viewer()

    assert screen.viewer.artifacts == []
    assert [item.id for item in screen.viewer.activities] == ["act1"]


@pytest.mark.asyncio
async def test_artifacts_screen_forwards_export_and_refreshes() -> None:
    """Export requests should forward callback, refresh, then reselect artifact."""
    source_viewer = SimpleNamespace(artifacts=[_artifact("a1")], activities=[])
    forwarded: list[tuple[str, str]] = []

    async def on_export(report_id: str, artifact_id: str) -> None:
        forwarded.append((report_id, artifact_id))

    screen = ArtifactsScreen(source_viewer=source_viewer, on_export_report=on_export)
    stub_viewer = _StubViewer()
    screen.viewer = stub_viewer  # type: ignore[assignment]
    refresh_calls: list[bool] = []
    screen._refresh_modal_viewer = lambda: refresh_calls.append(True)  # type: ignore[method-assign]

    await screen.on_export_report_request(ExportReportRequest("r-1", "a1"))

    assert forwarded == [("r-1", "a1")]
    assert refresh_calls == [True]
    assert stub_viewer.selected_ids == ["a1"]
