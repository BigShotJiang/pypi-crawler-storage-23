"""Tests for non-blocking startup behavior in the TUI app."""

import asyncio
from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast

import pytest
from lineage.tui.app import DataConciergeApp, StatusBar


def _app_source() -> str:
    source_path = (
        Path(__file__).resolve().parents[2] / "src" / "lineage" / "tui" / "app.py"
    )
    return source_path.read_text()


class _FakeContainer:
    def __init__(self) -> None:
        self.mounted: list[object] = []

    async def mount(self, widget: object, *_args, **_kwargs) -> object:
        self.mounted.append(widget)
        return widget


class _FakeTimer:
    def stop(self) -> None:
        return None


@pytest.mark.asyncio
async def test_on_mount_returns_before_backend_health_ready() -> None:
    """on_mount should schedule backend bootstrap instead of blocking UI render."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    app._ticketing_available = False
    app.current_chat_mode = "analyst"
    app.daemon_mode = False
    app.client = None
    app._startup_task = None
    app.status_bar = SimpleNamespace(set_loading=lambda: None)

    chat_container = _FakeContainer()
    loading_screen = SimpleNamespace(display=True)
    main_content = SimpleNamespace(display=True, active="chat")

    health_gate = asyncio.Event()

    async def wait_for_health():
        await health_gate.wait()
        return {
            "status": "healthy",
            "backends": {"lineage": "falkordb", "data": "snowflake"},
        }

    app.backend = SimpleNamespace(
        start=lambda: None,
        wait_for_health=wait_for_health,
        log_file="/tmp/tui-backend.log",
        base_url="http://localhost:9999",
    )

    def fake_query_one(selector, _type=None):
        if selector == "#chat-container":
            return chat_container
        if selector == "#loading-screen":
            return loading_screen
        if selector == "#main-content":
            return main_content
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    await asyncio.wait_for(app.on_mount(), timeout=0.05)

    assert chat_container.mounted

    if app._startup_task is not None:
        startup_task = cast(asyncio.Task[Any], app._startup_task)
        startup_task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await startup_task


def test_apply_health_status_prefers_explicit_readiness_signals() -> None:
    """Status mapping should use readiness booleans when provided."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    app.status_bar = StatusBar()

    app._apply_health_status(
        {
            "status": "healthy",
            "backends": {"lineage": "falkordb", "data": "snowflake"},
            "readiness": {"lineage": False, "data": False},
        }
    )

    assert "error" in app.status_bar.graph_status
    assert "error" in app.status_bar.data_status


@pytest.mark.asyncio
async def test_show_startup_placeholder_mounts_structured_widget() -> None:
    """Startup placeholder should mount a dedicated loading widget, not plain text."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    app.backend = SimpleNamespace(log_file="/tmp/tui-backend.log")

    chat_container = _FakeContainer()

    def fake_query_one(selector, _type=None):
        if selector == "#chat-container":
            return chat_container
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    await app._show_startup_placeholder()

    assert chat_container.mounted
    startup_widget = chat_container.mounted[-1]
    assert startup_widget.__class__.__name__ == "StartupPlaceholder"
    assert getattr(startup_widget, "id", "") == "startup-placeholder"


def test_app_source_includes_phase1_perf_hooks() -> None:
    """App should include startup and tab perf instrumentation hooks."""
    source = _app_source()

    assert "get_perf_logger" in source
    assert '"startup_chat_ready"' in source
    assert 'self._log_perf_event("tab_activated", tab_id=tab_id)' in source


@pytest.mark.asyncio
async def test_initialize_runtime_lazy_mounts_aux_tabs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Runtime init should mount chat immediately and defer tickets/daemon screens."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    app._ticketing_available = True
    app.daemon_mode = False
    app.current_chat_mode = "analyst"
    app._startup_started_at = None
    app._mounted_aux_tabs = set()
    app._aux_mount_tasks = {}
    app._log_perf_event = lambda *_args, **_kwargs: None
    app._apply_health_status = lambda *_args, **_kwargs: None

    async def fake_refresh_dependency_readiness() -> None:
        return None

    async def fake_client_close() -> None:
        return None

    async def fake_wait_for_health() -> dict[str, str]:
        return {"status": "healthy"}

    app._refresh_dependency_readiness = fake_refresh_dependency_readiness
    app.status_bar = None

    monkeypatch.setattr(
        "lineage.tui.app.AguiClient",
        lambda _base_url: SimpleNamespace(close=fake_client_close),
    )

    chat_container = _FakeContainer()
    tickets_container = _FakeContainer()
    daemon_container = _FakeContainer()
    main_content = SimpleNamespace(active="chat")

    app.backend = SimpleNamespace(
        start=lambda: None,
        wait_for_health=fake_wait_for_health,
        base_url="http://localhost:9999",
    )

    def fake_query_one(selector, _type=None):
        if selector == "#chat-container":
            return chat_container
        if selector == "#tickets-container":
            return tickets_container
        if selector == "#daemon-container":
            return daemon_container
        if selector == "#main-content":
            return main_content
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    await app._initialize_runtime()

    assert len(chat_container.mounted) == 1
    assert tickets_container.mounted == []
    assert daemon_container.mounted == []


@pytest.mark.asyncio
async def test_initialize_runtime_daemon_mode_ensures_daemon_mount(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Daemon mode should ensure daemon tab mount before scheduling auto-start."""
    app: Any = DataConciergeApp.__new__(DataConciergeApp)
    app._ticketing_available = True
    app.daemon_mode = True
    app.current_chat_mode = "analyst"
    app._startup_started_at = None
    app._mounted_aux_tabs = set()
    app._aux_mount_tasks = {}
    app._log_perf_event = lambda *_args, **_kwargs: None
    app._apply_health_status = lambda *_args, **_kwargs: None

    async def fake_refresh_dependency_readiness() -> None:
        return None

    async def fake_client_close() -> None:
        return None

    async def fake_wait_for_health() -> dict[str, str]:
        return {"status": "healthy"}

    app._refresh_dependency_readiness = fake_refresh_dependency_readiness
    app.status_bar = None

    monkeypatch.setattr(
        "lineage.tui.app.AguiClient",
        lambda _base_url: SimpleNamespace(close=fake_client_close),
    )

    ensure_calls: list[str] = []

    async def fake_ensure(tab_id: str) -> None:
        ensure_calls.append(tab_id)

    timer_calls: list[float] = []
    app._ensure_aux_tab_mounted = fake_ensure  # type: ignore[method-assign]
    app.set_timer = lambda delay, _cb: (timer_calls.append(delay), _FakeTimer())[1]  # type: ignore[method-assign]

    chat_container = _FakeContainer()
    main_content = SimpleNamespace(active="chat")
    app.backend = SimpleNamespace(
        start=lambda: None,
        wait_for_health=fake_wait_for_health,
        base_url="http://localhost:9999",
    )

    def fake_query_one(selector, _type=None):
        if selector == "#chat-container":
            return chat_container
        if selector == "#main-content":
            return main_content
        raise AssertionError(f"Unexpected selector: {selector}")

    app.query_one = fake_query_one  # type: ignore[method-assign]

    await app._initialize_runtime()

    assert ensure_calls == ["daemon"]
    assert main_content.active == "daemon"
    assert timer_calls == [0.5]
