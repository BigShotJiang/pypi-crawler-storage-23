"""Tests for chat activity modal guard wiring."""

from pathlib import Path


def _chat_screen_source() -> str:
    source_path = (
        Path(__file__).resolve().parents[2]
        / "src"
        / "lineage"
        / "tui"
        / "screens"
        / "chat.py"
    )
    return source_path.read_text()


def test_action_open_activity_guards_against_modal_stacking() -> None:
    """Activity action should no-op when activity modal is already open."""
    source = _chat_screen_source()

    assert "def action_open_activity(self) -> None:" in source
    assert "if isinstance(self.app.screen, ActivityScreen):" in source
