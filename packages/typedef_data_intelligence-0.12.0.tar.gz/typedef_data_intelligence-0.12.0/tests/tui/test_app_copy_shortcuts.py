"""Tests for app-level copy selection behavior."""

from types import SimpleNamespace

from lineage.tui.app import DataConciergeApp
from textual import events


def test_app_exposes_ctrl_shift_c_copy_selected_text_binding() -> None:
    """App bindings should include manual copy fallback for selected text."""
    bindings = {
        (
            binding[0] if isinstance(binding, tuple) else binding.key,
            binding[1] if isinstance(binding, tuple) else binding.action,
        )
        for binding in DataConciergeApp.BINDINGS
    }

    assert ("ctrl+shift+c", "copy_selected_text") in bindings


def test_action_copy_selected_text_copies_and_notifies() -> None:
    """Manual copy action should write selected text to clipboard and toast."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    copied: list[str] = []
    cleared: list[bool] = []
    notified: list[tuple[str, str | None]] = []

    app._selected_text_from_screen = (  # type: ignore[method-assign]
        lambda _screen=None: "hello world"
    )
    app._active_screen_for_selection = lambda: SimpleNamespace()  # type: ignore[method-assign]
    app.copy_to_clipboard = lambda text: copied.append(text)  # type: ignore[method-assign]
    app.clear_selection = lambda: cleared.append(True)  # type: ignore[method-assign]
    app.notify = lambda message, **kwargs: notified.append(  # type: ignore[method-assign]
        (message, kwargs.get("title"))
    )

    app.action_copy_selected_text()

    assert copied == ["hello world"]
    assert cleared == [True]
    assert notified == [("Copied to clipboard", "Copied")]


def test_action_copy_selected_text_noops_when_no_selection() -> None:
    """Manual copy action should no-op when there is no selection."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    copied: list[str] = []
    notified: list[tuple[str, str | None]] = []

    app._selected_text_from_screen = lambda _screen=None: None  # type: ignore[method-assign]
    app._active_screen_for_selection = lambda: SimpleNamespace()  # type: ignore[method-assign]
    app.copy_to_clipboard = lambda text: copied.append(text)  # type: ignore[method-assign]
    app.notify = lambda message, **kwargs: notified.append(  # type: ignore[method-assign]
        (message, kwargs.get("title"))
    )

    app.action_copy_selected_text()

    assert copied == []
    assert notified == []


def test_text_selected_event_auto_copies_and_notifies() -> None:
    """Selection completion should auto-copy selected text and toast."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    copied: list[str] = []
    cleared: list[bool] = []
    notified: list[tuple[str, str | None]] = []

    app._selected_text_from_screen = (  # type: ignore[method-assign]
        lambda _screen=None: "auto copy me"
    )
    app._active_screen_for_selection = lambda: SimpleNamespace()  # type: ignore[method-assign]
    app.copy_to_clipboard = lambda text: copied.append(text)  # type: ignore[method-assign]
    app.clear_selection = lambda: cleared.append(True)  # type: ignore[method-assign]
    app.notify = lambda message, **kwargs: notified.append(  # type: ignore[method-assign]
        (message, kwargs.get("title"))
    )

    app.on_text_selected(events.TextSelected())

    assert copied == ["auto copy me"]
    assert cleared == [True]
    assert notified == [("Copied to clipboard", "Copied")]


def test_copy_helper_resets_internal_selection_tracking_state() -> None:
    """Copy helper should reset screen drag-selection tracking internals."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    screen = SimpleNamespace(
        _selecting=True,
        _mouse_down_offset=object(),
        _select_start=object(),
        _select_end=object(),
    )
    copied: list[str] = []
    notified: list[tuple[str, str | None]] = []

    app._active_screen_for_selection = lambda: screen  # type: ignore[method-assign]
    app.clear_selection = lambda: None  # type: ignore[method-assign]
    app.copy_to_clipboard = lambda text: copied.append(text)  # type: ignore[method-assign]
    app.notify = lambda message, **kwargs: notified.append(  # type: ignore[method-assign]
        (message, kwargs.get("title"))
    )

    app._copy_text_with_toast("x")

    assert screen._selecting is False
    assert screen._mouse_down_offset is None
    assert screen._select_start is None
    assert screen._select_end is None
    assert copied == ["x"]
    assert notified == [("Copied to clipboard", "Copied")]


def test_mouse_move_stops_stale_selection_when_no_button_pressed() -> None:
    """Mouse move should stop stale selection tracking without pressed button."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    screen = SimpleNamespace(_selecting=True)
    resets: list[bool] = []

    app._active_screen_for_selection = lambda: screen  # type: ignore[method-assign]
    app._reset_selection_tracking = lambda: resets.append(True)  # type: ignore[method-assign]

    app.on_mouse_move(SimpleNamespace(button=0))  # type: ignore[arg-type]

    assert resets == [True]


def test_mouse_move_keeps_selection_while_button_pressed() -> None:
    """Mouse move should not stop active drag selection with pressed button."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    screen = SimpleNamespace(_selecting=True)
    resets: list[bool] = []

    app._active_screen_for_selection = lambda: screen  # type: ignore[method-assign]
    app._reset_selection_tracking = lambda: resets.append(True)  # type: ignore[method-assign]

    app.on_mouse_move(SimpleNamespace(button=1))  # type: ignore[arg-type]

    assert resets == []


def test_text_selected_uses_event_sender_screen_for_copy_and_reset() -> None:
    """Auto-copy should target the screen that emitted TextSelected."""
    app = DataConciergeApp.__new__(DataConciergeApp)
    sender_screen = SimpleNamespace(
        get_selected_text=lambda: "sender text",
        _selecting=True,
        _mouse_down_offset=object(),
        _select_start=object(),
        _select_end=object(),
    )
    copied: list[str] = []
    notified: list[tuple[str, str | None]] = []

    app._active_screen_for_selection = lambda: SimpleNamespace(  # type: ignore[method-assign]
        get_selected_text=lambda: None
    )
    app.copy_to_clipboard = lambda text: copied.append(text)  # type: ignore[method-assign]
    app.clear_selection = lambda: None  # type: ignore[method-assign]
    app.notify = lambda message, **kwargs: notified.append(  # type: ignore[method-assign]
        (message, kwargs.get("title"))
    )

    event = events.TextSelected().set_sender(sender_screen)  # type: ignore[arg-type]
    app.on_text_selected(event)

    assert copied == ["sender text"]
    assert sender_screen._selecting is False
    assert sender_screen._mouse_down_offset is None
    assert sender_screen._select_start is None
    assert sender_screen._select_end is None
    assert notified == [("Copied to clipboard", "Copied")]
