"""Tests for context-aware status bar key hints."""

from lineage.tui.app import StatusBar


def test_status_bar_shows_ticket_shortcuts_on_tickets_tab() -> None:
    """Tickets tab should show ticket-local key hints."""
    bar = StatusBar()
    bar.active_tab = "tickets"
    bar._terminal_width = lambda: 220  # type: ignore[method-assign]

    rendered = bar.render()

    assert "[bold]r[/bold] refresh" in rendered
    assert "[bold]i[/bold] investigator" in rendered
    assert "[bold]c[/bold] copilot" in rendered
    assert "[bold]ctrl+,/.[/bold] move to chat" in rendered
    assert "[bold]f[/bold] toggle follow" not in rendered


def test_status_bar_shows_chat_shortcuts_on_chat_tab() -> None:
    """Unified chat tab should include chat-local key hints only."""
    bar = StatusBar()
    bar.active_tab = "chat"
    bar._terminal_width = lambda: 220  # type: ignore[method-assign]

    rendered = bar.render()

    assert "[bold]q[/bold] stop agent" in rendered
    assert "[bold]esc[/bold] stop agent" in rendered
    assert "[bold]f[/bold] toggle follow" in rendered
    assert "[bold]i[/bold] focus input" in rendered
    assert "[bold]ctrl+a[/bold] artifacts" in rendered
    assert "[bold]ctrl+g[/bold] activity" in rendered
    assert "[bold]v[/bold] toggle verbose" in rendered
    assert "[bold]ctrl+,/.[/bold] toggle agent" not in rendered
    assert "[bold]r[/bold] refresh" not in rendered


def test_status_bar_shows_daemon_shortcuts_on_daemon_tab() -> None:
    """Daemon tab should show daemon-local key hints."""
    bar = StatusBar()
    bar.active_tab = "daemon"
    bar._terminal_width = lambda: 220  # type: ignore[method-assign]

    rendered = bar.render()

    assert "[bold]s[/bold] start/stop" in rendered
    assert "[bold]r[/bold] reconciler" in rendered
    assert "[bold]i[/bold] investigator" in rendered
    assert "[bold]ctrl+,/.[/bold] move to chat" in rendered
    assert "[bold]f[/bold] toggle follow" not in rendered


def test_status_bar_renders_status_and_hints_on_single_line() -> None:
    """Status and hints should render on a single line."""
    bar = StatusBar()
    bar.active_tab = "tickets"

    rendered = bar.render()

    assert "\n" not in rendered


def test_status_bar_right_aligns_hints_on_single_line(monkeypatch) -> None:
    """Hints should render right-aligned on the same line."""
    bar = StatusBar()
    bar.active_tab = "tickets"
    monkeypatch.setattr(bar, "_terminal_width", lambda: 160)

    rendered = bar.render()

    keys = bar._key_hints()
    assert rendered.endswith(keys)
    assert "\n" not in rendered

    split_at = rendered.rfind(keys)
    assert split_at > 0
    assert rendered[split_at - 1] == " "


def test_status_bar_supports_incremental_readiness_updates() -> None:
    """Status bar should allow backend/graph/data updates independently."""
    bar = StatusBar()

    bar.set_loading()
    assert bar.backend_status == "starting"
    assert bar.graph_status == "pending"
    assert bar.data_status == "pending"

    bar.set_backend_ready()
    assert bar.backend_status == "ready"
    assert bar.graph_status == "pending"
    assert bar.data_status == "pending"

    bar.set_graph_connected()
    assert bar.graph_status == "connected"
    assert bar.data_status == "pending"

    bar.set_data_connected()
    assert bar.data_status == "connected"


def test_status_bar_pending_spinner_frame_changes() -> None:
    """Pending states should animate by rotating circle spinner frames."""
    bar = StatusBar()
    bar.set_loading()

    rendered_before = bar.render()
    bar._advance_spinner()
    rendered_after = bar.render()

    assert rendered_before != rendered_after


def test_status_bar_uses_bold_labels_without_pipe_separators() -> None:
    """Status line should use bold labels with a separator after project."""
    bar = StatusBar()
    bar.project_name = "medallio"
    bar.set_backend_ready()
    bar.set_graph_connected()
    bar.set_data_connected()

    status_line = bar.render()

    assert "[bold]backend[/bold]" in status_line
    assert "[bold]graph[/bold]" in status_line
    assert "[bold]data[/bold]" in status_line
    assert "│" in status_line
    assert "[/] [bold]backend[/bold]" in status_line
    assert "Backend:" not in status_line
    assert "Graph:" not in status_line
    assert "Data:" not in status_line


def test_status_bar_compacts_status_to_keep_hints_right_when_narrow(
    monkeypatch,
) -> None:
    """When width is tight, status compacts so hints stay right on one line."""
    bar = StatusBar()
    bar.project_name = "medallio"
    bar.active_tab = "chat"
    bar.set_connected()
    monkeypatch.setattr(bar, "_terminal_width", lambda: 50)

    rendered = bar.render()

    assert "\n" not in rendered
    assert rendered.endswith("[bold]?[/bold] help")
    assert bar._plain_len(rendered) <= 50


def test_status_bar_fallback_still_fits_extremely_narrow_width(monkeypatch) -> None:
    """Fallback output should never exceed available terminal width."""
    bar = StatusBar()
    bar.project_name = "medallio"
    bar.active_tab = "chat"
    bar.set_connected()
    monkeypatch.setattr(bar, "_terminal_width", lambda: 1)

    rendered = bar.render()

    assert "\n" not in rendered
    assert bar._plain_len(rendered) <= 1


def test_status_bar_compact_mode_keeps_three_statuses_and_only_question_help(
    monkeypatch,
) -> None:
    """Compact status mode keeps B/G/D while reducing hints to ? help."""
    bar = StatusBar()
    bar.project_name = "medallio"
    bar.active_tab = "chat"
    bar.set_connected()
    monkeypatch.setattr(bar, "_terminal_width", lambda: 50)

    rendered = bar.render()

    assert "\n" not in rendered
    assert "[bold]B[/bold]" in rendered
    assert "[bold]G[/bold]" in rendered
    assert "[bold]D[/bold]" in rendered
    assert rendered.endswith("[bold]?[/bold] help")
    assert "[bold]q[/bold]" not in rendered
    assert "[bold]v[/bold]" not in rendered


def test_status_bar_escapes_project_name_markup_characters() -> None:
    """Project names with markup characters should not break rendering."""
    bar = StatusBar()
    bar.project_name = "ops[/bold]"
    bar.set_connected()

    rendered = bar.render()

    assert "\n" not in rendered


def test_status_bar_spinner_timer_stops_when_no_pending_states() -> None:
    """Spinner timer should stop once all statuses are non-pending."""
    bar = StatusBar()

    stopped: list[bool] = []
    bar._spinner_timer = type(
        "_Timer",
        (),
        {"stop": lambda self: stopped.append(True)},
    )()

    bar.set_connected()
    bar._advance_spinner()

    assert stopped == [True]
