"""Tests for Tickets pane focus visibility styling."""

from pathlib import Path


def _styles() -> str:
    styles_path = (
        Path(__file__).resolve().parents[2] / "src" / "lineage" / "tui" / "styles.tcss"
    )
    return styles_path.read_text()


def test_tickets_details_panel_has_focus_within_emphasis() -> None:
    """Details panel should visibly emphasize when focus is inside."""
    styles = _styles()

    assert ".tickets-details-panel:focus-within" in styles
    assert "border-left: solid $primary;" in styles


def test_tickets_table_has_focus_emphasis() -> None:
    """Table should visibly emphasize when focused."""
    styles = _styles()

    assert ".tickets-table:focus" in styles
    assert "border-left: solid $primary 80%;" in styles
