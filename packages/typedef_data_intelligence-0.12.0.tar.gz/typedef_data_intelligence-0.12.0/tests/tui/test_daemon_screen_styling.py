"""Tests for Daemon tab style parity with global TUI styles."""

from pathlib import Path
from types import SimpleNamespace

from lineage.tui.screens.daemon import (
    DaemonLog,
    DaemonScreen,
    TicketQueueTable,
)


def _compose_children() -> list[object]:
    screen = DaemonScreen(SimpleNamespace())
    return list(screen.compose())


def _styles() -> str:
    styles_path = (
        Path(__file__).resolve().parents[2] / "src" / "lineage" / "tui" / "styles.tcss"
    )
    return styles_path.read_text()


def test_daemon_screen_uses_global_styles_not_local_default_css() -> None:
    """Daemon widgets should not define local DEFAULT_CSS blocks."""
    assert "DEFAULT_CSS" not in DaemonScreen.__dict__


def test_daemon_screen_exposes_style_classes_for_global_tcss() -> None:
    """Compose should expose stable classes used by styles.tcss selectors."""
    children = _compose_children()

    controls = next(
        child for child in children if getattr(child, "id", None) == "daemon-controls"
    )
    status = next(
        child for child in children if getattr(child, "id", None) == "daemon-status"
    )
    pending_title = next(
        child
        for child in children
        if getattr(child, "id", None) == "daemon-pending-title"
    )
    activity_title = next(
        child
        for child in children
        if getattr(child, "id", None) == "daemon-activity-title"
    )
    queue = next(
        child for child in children if getattr(child, "id", None) == "ticket-queue"
    )
    log = next(
        child for child in children if getattr(child, "id", None) == "daemon-log"
    )

    assert "daemon-controls" in controls.classes
    assert "daemon-status" in status.classes
    assert "daemon-section-title" in pending_title.classes
    assert "daemon-section-title" in activity_title.classes
    assert isinstance(queue, TicketQueueTable)
    assert "daemon-ticket-queue" in queue.classes
    assert isinstance(log, DaemonLog)
    assert "daemon-log" in log.classes


def test_daemon_controls_hints_are_indented() -> None:
    """Daemon shortcut hints row should have left indent for readability."""
    styles = _styles()

    assert ".daemon-controls" in styles
    assert "padding: 0 0 0 3;" in styles


def test_daemon_status_has_no_visual_background_block() -> None:
    """Daemon status should blend with hint row background."""
    styles = _styles()

    assert ".daemon-status" in styles
    assert "background: transparent;" in styles


def test_daemon_section_titles_match_chat_title_tone() -> None:
    """Daemon section titles should use bold chat-title-like styling."""
    styles = _styles()

    assert ".daemon-section-title" in styles
    assert "text-style: bold;" in styles
    assert "color: $text-primary;" in styles


def test_daemon_section_titles_do_not_end_with_colon() -> None:
    """Daemon section headers should be title-like labels without colons."""
    children = _compose_children()
    pending_title = next(
        child
        for child in children
        if getattr(child, "id", None) == "daemon-pending-title"
    )
    activity_title = next(
        child
        for child in children
        if getattr(child, "id", None) == "daemon-activity-title"
    )

    pending_text = pending_title.render().plain
    activity_text = activity_title.render().plain

    assert pending_text == "Pending Tickets"
    assert activity_text == "Activity Log"


def test_daemon_section_header_to_pane_spacing_is_uniform() -> None:
    """Both daemon panes should have the same header-to-pane spacing rule."""
    styles = _styles()

    assert ".daemon-log" in styles
    assert "margin-top: 0;" in styles


def test_daemon_panes_match_tickets_surface_and_table_styles() -> None:
    """Daemon queue/log panes should mirror Tickets table/details visual treatment."""
    styles = _styles()

    assert ".daemon-ticket-queue" in styles
    assert "width: 100%;" in styles
    assert "border-left: solid $primary 25%;" in styles

    assert ".daemon-log" in styles
    assert "padding: 1;" in styles
    assert "border-left: solid $primary 40%;" in styles


def test_daemon_log_hides_horizontal_scrollbar_for_clean_alignment() -> None:
    """Activity log should avoid horizontal scrollbar shadows when possible."""
    styles = _styles()

    assert ".daemon-log" in styles
    assert "overflow-x: hidden;" in styles
