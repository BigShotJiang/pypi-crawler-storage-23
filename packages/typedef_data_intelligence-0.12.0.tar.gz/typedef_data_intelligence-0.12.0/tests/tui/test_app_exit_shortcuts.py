"""Tests for app-level stop/exit shortcut behavior."""

from types import SimpleNamespace

import lineage.tui.app as app_module
from lineage.tui.app import DataConciergeApp


def test_app_q_and_ctrl_q_map_to_stop_agent_not_quit() -> None:
    """Chat-oriented q shortcuts should stop agent runs and not bind quit."""
    bindings = {
        (
            binding[0] if isinstance(binding, tuple) else binding.key,
            binding[1] if isinstance(binding, tuple) else binding.action,
        )
        for binding in DataConciergeApp.BINDINGS
    }

    assert ("q", "cancel_agent") in bindings
    assert ("ctrl+q", "cancel_agent") in bindings
    assert ("q", "quit") not in bindings


def test_app_exposes_ctrl_c_double_press_exit_binding() -> None:
    """App should expose ctrl+c binding for two-press exit confirmation."""
    bindings = {
        (
            binding[0] if isinstance(binding, tuple) else binding.key,
            binding[1] if isinstance(binding, tuple) else binding.action,
        )
        for binding in DataConciergeApp.BINDINGS
    }

    assert ("ctrl+c", "confirm_exit") in bindings


def test_confirm_exit_clears_focused_chat_input_on_first_ctrl_c(monkeypatch) -> None:
    """First ctrl+c should clear focused chat input text instead of exiting."""
    app = DataConciergeApp()
    focused = SimpleNamespace(text="hello")

    def _clear() -> None:
        focused.text = ""

    focused.clear = _clear
    monkeypatch.setattr(app, "_focused_chat_input", lambda: focused)

    notifications: list[str] = []
    exits: list[bool] = []
    monkeypatch.setattr(
        app,
        "notify",
        lambda message, **kwargs: notifications.append(message),
    )
    monkeypatch.setattr(app, "exit", lambda: exits.append(True))

    app.action_confirm_exit()

    assert focused.text == ""
    assert exits == []
    assert notifications == ["Input cleared. Press Ctrl+C again to exit"]


def test_confirm_exit_second_ctrl_c_exits_after_first_press_clears_input(
    monkeypatch,
) -> None:
    """Clear action should arm exit so the second ctrl+c exits immediately."""
    app = DataConciergeApp()
    focused = SimpleNamespace(text="hello")

    def _clear() -> None:
        focused.text = ""

    focused.clear = _clear
    monkeypatch.setattr(app, "_focused_chat_input", lambda: focused)

    ticks = iter([100.0, 100.5])
    monkeypatch.setattr(app_module, "monotonic", lambda: next(ticks))

    exits: list[bool] = []
    monkeypatch.setattr(app, "notify", lambda *args, **kwargs: None)
    monkeypatch.setattr(app, "exit", lambda: exits.append(True))

    app.action_confirm_exit()
    app.action_confirm_exit()

    assert exits == [True]
