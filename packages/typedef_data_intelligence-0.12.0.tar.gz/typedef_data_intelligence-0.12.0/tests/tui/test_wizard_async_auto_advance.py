"""Source-level tests for wizard async auto-advance behavior."""

from pathlib import Path


def _wizard_base_source() -> str:
    source_path = (
        Path(__file__).resolve().parents[2]
        / "src"
        / "lineage"
        / "tui"
        / "wizards"
        / "base.py"
    )
    return source_path.read_text()


def test_auto_advance_scheduler_tracks_token_and_uses_timer() -> None:
    """Wizard should schedule delayed auto-advance with stale-timer protection."""
    source = _wizard_base_source()

    assert "self._auto_advance_token = 0" in source
    assert "def schedule_auto_advance(" in source
    assert "self._auto_advance_token += 1" in source
    assert "self.set_timer(" in source


def test_auto_advance_guard_checks_step_and_button_state() -> None:
    """Auto-advance should only fire for active step with enabled Next button."""
    source = _wizard_base_source()

    assert "def _try_auto_advance(" in source
    assert "if token != self._auto_advance_token:" in source
    assert "if current_step.step_id != step_id:" in source
    assert "if next_btn.disabled:" in source
    assert "next_btn.press()" in source
