"""Tests for Tickets tab style-guide parity hooks."""

import asyncio
from types import SimpleNamespace

from lineage.tui.screens.tickets import (
    OpenTicketInChat,
    TicketDetailsPanel,
    TicketInfo,
    TicketsScreen,
    TicketsShortcutRequested,
    TicketsTable,
)


def _compose_children() -> list[object]:
    screen = TicketsScreen(SimpleNamespace())
    return list(screen.compose())


def test_tickets_screen_uses_global_styles_not_local_default_css() -> None:
    """Tickets widgets should not define local DEFAULT_CSS blocks."""
    assert "DEFAULT_CSS" not in TicketDetailsPanel.__dict__
    assert "DEFAULT_CSS" not in TicketsScreen.__dict__


def test_tickets_screen_exposes_style_classes_for_global_tcss() -> None:
    """Compose should expose stable classes used by styles.tcss selectors."""
    children = _compose_children()

    title = next(child for child in children if getattr(child, "id", None) is None)
    details = next(
        child for child in children if getattr(child, "id", None) == "ticket-details"
    )
    table = next(
        child for child in children if getattr(child, "id", None) == "tickets-table"
    )
    refresh_indicator = next(
        child
        for child in children
        if getattr(child, "id", None) == "tickets-refresh-indicator"
    )

    assert all(getattr(child, "id", None) != "tickets-controls" for child in children)
    assert "tickets-section-title" in title.classes
    assert "tickets-details-panel" in details.classes
    assert "tickets-refresh-indicator" in refresh_indicator.classes
    assert isinstance(table, TicketsTable)
    assert "tickets-table" in table.classes


def test_tickets_section_title_matches_daemon_title_styling() -> None:
    """Tickets header should use the same title treatment as daemon section titles."""
    from pathlib import Path

    styles_path = (
        Path(__file__).resolve().parents[2] / "src" / "lineage" / "tui" / "styles.tcss"
    )
    styles = styles_path.read_text()

    assert ".tickets-section-title" in styles
    assert "margin: 1 0 0 1;" in styles
    assert "text-style: bold;" in styles
    assert "color: $text-primary;" in styles


def test_tickets_screen_has_local_keyboard_shortcuts() -> None:
    """Tickets tab should expose tab-local key bindings."""
    binding_keys = {binding[0] for binding in TicketsScreen.BINDINGS}
    assert {"r", "i", "c"}.issubset(binding_keys)


def test_tickets_table_has_same_keyboard_shortcuts_for_focused_table() -> None:
    """Focused table should expose same shortcuts as the parent screen."""
    binding_keys = {binding[0] for binding in TicketsTable.BINDINGS}
    assert {"r", "i", "c"}.issubset(binding_keys)


def test_tickets_table_shortcuts_dispatch_request_messages() -> None:
    """Table shortcut actions should emit screen request messages."""
    table = TicketsTable()
    messages = []
    table.post_message = messages.append  # type: ignore[method-assign]

    table.action_request_refresh()
    table.action_request_open_investigator()
    table.action_request_open_copilot()

    assert [type(msg) for msg in messages] == [
        TicketsShortcutRequested,
        TicketsShortcutRequested,
        TicketsShortcutRequested,
    ]
    assert [msg.action for msg in messages] == [
        "refresh",
        "open_investigator",
        "open_copilot",
    ]


def test_tickets_shortcuts_open_selected_ticket_in_chat() -> None:
    """Shortcut actions should dispatch OpenTicketInChat with selected ticket."""
    screen = TicketsScreen(SimpleNamespace())
    screen.selected_ticket = TicketInfo(
        id="T-123",
        title="Fix parity",
        status="open",
        priority="high",
    )
    messages = []
    screen.post_message = messages.append  # type: ignore[method-assign]

    screen.action_open_investigator()
    screen.action_open_copilot()

    assert len(messages) == 2
    assert isinstance(messages[0], OpenTicketInChat)
    assert messages[0].agent_type == "investigator"
    assert messages[0].ticket.id == "T-123"
    assert isinstance(messages[1], OpenTicketInChat)
    assert messages[1].agent_type == "copilot"
    assert messages[1].ticket.id == "T-123"


def test_tickets_refresh_shortcut_starts_background_refresh(monkeypatch) -> None:
    """Refresh shortcut should schedule async refresh task."""
    screen = TicketsScreen(SimpleNamespace())
    created = []

    async def fake_refresh() -> None:
        return None

    def fake_create_task(coro):
        created.append(coro)
        coro.close()
        return SimpleNamespace()

    screen._refresh_tickets = fake_refresh  # type: ignore[method-assign]
    monkeypatch.setattr(asyncio, "create_task", fake_create_task)

    screen.action_refresh_tickets()

    assert len(created) == 1


def test_tickets_refresh_shortcut_ignores_repeated_presses_while_pending(
    monkeypatch,
) -> None:
    """Repeated refresh keypresses should schedule only one in-flight refresh."""
    screen = TicketsScreen(SimpleNamespace())
    created = []

    async def fake_refresh() -> None:
        return None

    def fake_create_task(coro):
        created.append(coro)
        return SimpleNamespace()

    screen._refresh_tickets = fake_refresh  # type: ignore[method-assign]
    monkeypatch.setattr(asyncio, "create_task", fake_create_task)

    screen.action_refresh_tickets()
    screen.action_refresh_tickets()

    for coro in created:
        coro.close()

    assert len(created) == 1


def test_refresh_indicator_lifecycle_on_success(monkeypatch) -> None:
    """Refresh indicator should start and stop around successful refresh."""
    calls: list[bool] = []

    class FakeTable:
        def update_tickets(self, _tickets) -> None:
            return None

    class FakeResponse:
        status_code = 200

        def json(self) -> dict:
            return {"tickets": []}

    class FakeHTTPClient:
        async def get(self, *_args, **_kwargs):
            return FakeResponse()

    screen = TicketsScreen(
        SimpleNamespace(http_client=FakeHTTPClient(), base_url="http://x")
    )
    monkeypatch.setattr(
        screen,
        "_set_refresh_indicator",
        lambda visible: calls.append(visible),
        raising=False,
    )
    monkeypatch.setattr(
        screen,
        "query_one",
        lambda selector, _type=None: FakeTable()
        if selector == "#tickets-table"
        else None,
    )

    asyncio.run(screen._refresh_tickets())

    assert calls == [True, False]


def test_refresh_indicator_lifecycle_on_failure(monkeypatch) -> None:
    """Refresh indicator should stop even when refresh raises."""
    calls: list[bool] = []

    class FakeHTTPClient:
        async def get(self, *_args, **_kwargs):
            raise RuntimeError("network down")

    screen = TicketsScreen(
        SimpleNamespace(http_client=FakeHTTPClient(), base_url="http://x")
    )
    monkeypatch.setattr(
        screen,
        "_set_refresh_indicator",
        lambda visible: calls.append(visible),
        raising=False,
    )

    asyncio.run(screen._refresh_tickets())

    assert calls == [True, False]
