"""Tests for session status modal and /status slash command."""

import asyncio
from types import SimpleNamespace

import lineage.tui.screens.chat as chat_module
from lineage.tui.screens.chat import AgentChat
from lineage.tui.screens.status import StatusData, StatusScreen, _format_uptime


def test_status_data_construction() -> None:
    """StatusData should accept all expected fields."""
    data = StatusData(
        agent_name="analyst",
        model="anthropic:claude-haiku-4-5",
        thread_id="tui-abc12345",
        uptime_seconds=125.0,
        context_cap=30,
        message_count=5,
        user_message_count=3,
        assistant_message_count=2,
        last_run_id="run-def67890",
        last_run_duration=2.5,
        last_run_tool_calls=3,
        artifact_count=1,
        activity_count=2,
        backend_status="ready",
        graph_status="connected",
        data_status="connected",
        project_name="test-project",
        verbose_mode=False,
        flat_mode=False,
    )
    assert data.agent_name == "analyst"
    assert data.model == "anthropic:claude-haiku-4-5"
    assert data.message_count == 5
    assert data.last_run_id == "run-def67890"


def test_status_screen_bindings() -> None:
    """StatusScreen should bind escape and q to close."""
    bindings = {
        (
            binding[0] if isinstance(binding, tuple) else binding.key,
            binding[1] if isinstance(binding, tuple) else binding.action,
        )
        for binding in StatusScreen.BINDINGS
    }
    assert ("escape", "close") in bindings
    assert ("q", "close") in bindings
    assert ("ctrl+c", "app.confirm_exit") in bindings


def test_format_uptime_seconds() -> None:
    """Short uptimes should show seconds only."""
    assert _format_uptime(45.0) == "45s"


def test_format_uptime_minutes() -> None:
    """Uptimes over 60s should show minutes and seconds."""
    assert _format_uptime(125.0) == "2m 5s"


def test_format_uptime_hours() -> None:
    """Uptimes over 3600s should show hours and minutes."""
    assert _format_uptime(3725.0) == "1h 2m"


def test_status_command_in_slash_commands() -> None:
    """/status should be registered in SLASH_COMMANDS."""
    commands = {spec.command for spec in chat_module.SLASH_COMMANDS}
    assert "/status" in commands


def test_status_command_in_filter_results() -> None:
    """/status should appear in filter results for 'stat' query."""
    results = chat_module._filter_slash_commands("stat")
    assert any(spec.command == "/status" for spec in results)


def test_submit_status_does_not_stream(monkeypatch) -> None:
    """`/status` should open status modal without scheduling streaming."""
    chat = AgentChat("analyst", SimpleNamespace())
    chat.chat_area = SimpleNamespace(
        input=SimpleNamespace(text="/status", read_only=False, focus=lambda: None),
        autoscroll_enabled=False,
        remove_placeholder=lambda: None,
        close_slash_menu=lambda: None,
        chat_log=SimpleNamespace(mount=lambda *_args, **_kwargs: None),
    )
    chat._request_autoscroll = lambda: None

    status_shown: list[bool] = []
    chat._show_status = lambda: status_shown.append(True)

    def fail_create_task(coro):
        coro.close()
        raise AssertionError("streaming should not be scheduled for /status")

    monkeypatch.setattr(chat_module.asyncio, "create_task", fail_create_task)

    asyncio.run(chat._submit_message())

    assert status_shown == [True]
    assert chat.chat_area.input.text == ""
