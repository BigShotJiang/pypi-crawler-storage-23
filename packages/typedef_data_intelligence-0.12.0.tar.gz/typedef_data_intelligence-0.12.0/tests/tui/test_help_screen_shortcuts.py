"""Tests for HelpScreen keyboard shortcut guidance."""

from pathlib import Path

import lineage.tui.screens.help as help_module
from lineage.tui.screens.help import HelpScreen


def test_help_screen_appends_tui_shortcuts_to_loaded_docs(
    tmp_path: Path, monkeypatch
) -> None:
    """Loaded docs content should include explicit TUI shortcut section."""
    docs_path = tmp_path / "AGENT_USER_GUIDE.md"
    docs_path.write_text("# Guide\n\nBase docs content.")
    monkeypatch.setattr(help_module, "DOCS_PATH", docs_path)

    screen = HelpScreen()

    assert screen._help_title == "Guide"
    assert "# Guide" not in screen._help_content
    assert "Base docs content." in screen._help_content
    assert "## TUI Keyboard Shortcuts" in screen._help_content
    assert "| `F1` | Open full help |" in screen._help_content
    assert "| `?` / `Ctrl+/` | Open shortcuts modal |" in screen._help_content
    assert "`F1` / `?`" not in screen._help_content
    assert "| `Tab` / `Shift+Tab` | Move UI focus |" in screen._help_content
    assert "`Ctrl+,` / `Ctrl+.`" in screen._help_content
    assert "| `i` | Focus chat input |" in screen._help_content
    assert "| `Ctrl+A` | Open artifacts |" in screen._help_content
    assert "Start a new chat" in screen._help_content
    assert "`/new` / `/clear`" in screen._help_content


def test_help_screen_fallback_shortcuts_match_unified_chat_keys(
    tmp_path: Path, monkeypatch
) -> None:
    """Fallback help should describe unified chat mode and reset shortcuts."""
    missing_path = tmp_path / "missing-help.md"
    monkeypatch.setattr(help_module, "DOCS_PATH", missing_path)

    screen = HelpScreen()

    assert screen._help_title == "Data Concierge Help"
    assert "# Data Concierge Help" not in screen._help_content
    assert "## TUI Keyboard Shortcuts" in screen._help_content
    assert "| `F1` | Open full help |" in screen._help_content
    assert "| `?` / `Ctrl+/` | Open shortcuts modal |" in screen._help_content
    assert "`F1` / `?`" not in screen._help_content
    assert "| `Tab` / `Shift+Tab` | Move UI focus |" in screen._help_content
    assert "`Ctrl+,` / `Ctrl+.`" in screen._help_content
    assert "| `i` | Focus chat input |" in screen._help_content
    assert "| `Ctrl+A` | Open artifacts |" in screen._help_content
    assert "Start a new chat" in screen._help_content
    assert "`/new` / `/clear`" in screen._help_content
    assert "| `q` / `Ctrl+Q` | Cancel running agent |" in screen._help_content
    assert "| `Ctrl+C` (twice) | Quit application |" in screen._help_content
    assert "| `Q` | Quit application |" not in screen._help_content


def test_help_screen_includes_ctrl_c_exit_binding() -> None:
    """Help modal should allow app-level ctrl+c double-press exit flow."""
    bindings = {
        (
            binding[0] if isinstance(binding, tuple) else binding.key,
            binding[1] if isinstance(binding, tuple) else binding.action,
        )
        for binding in HelpScreen.BINDINGS
    }

    assert ("ctrl+c", "app.confirm_exit") in bindings
