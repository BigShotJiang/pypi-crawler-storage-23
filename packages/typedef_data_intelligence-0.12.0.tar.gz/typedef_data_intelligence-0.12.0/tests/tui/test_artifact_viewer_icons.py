"""Tests for artifact viewer icon consistency."""

import lineage.tui.widgets.artifacts.viewer as viewer_module
from lineage.tui.widgets.artifacts.artifact_types import ArtifactData
from lineage.tui.widgets.artifacts.viewer import ArtifactViewer


class _StubListView:
    def __init__(self) -> None:
        self.items: list[object] = []
        self.index: int | None = None

    def append(self, item: object) -> None:
        self.items.append(item)


class _StubStatic:
    def __init__(self, text: str, classes: str = "") -> None:
        self.text = text
        self.classes = classes


class _StubListItem:
    def __init__(self, child: object) -> None:
        self.child = child


def test_add_artifact_uses_shared_icon_mapping(monkeypatch) -> None:
    """_add_artifact should use the same icon map as _icon_for_type."""
    monkeypatch.setattr(viewer_module, "Static", _StubStatic)
    monkeypatch.setattr(viewer_module, "ListItem", _StubListItem)

    viewer = ArtifactViewer()
    stub_list = _StubListView()
    viewer.artifact_list = stub_list  # type: ignore[assignment]
    viewer._render_artifact = lambda *_: None  # type: ignore[method-assign]

    artifact = ArtifactData(
        id="explore-1",
        type="explore",
        title="Explore Result",
        data={"explore_id": "exp-1"},
        render_func=lambda *_: None,
    )

    viewer._add_artifact(artifact)

    expected_icon = ArtifactViewer._icon_for_type("explore")
    rendered_item = stub_list.items[0]
    rendered_title = getattr(getattr(rendered_item, "child", None), "text", "")
    assert rendered_title == f"{expected_icon} Explore Result"


def test_report_update_skips_rerender_when_artifact_not_selected() -> None:
    """Report updates should not rerender when a different artifact is selected."""
    viewer = ArtifactViewer()
    viewer.artifact_list = _StubListView()  # type: ignore[assignment]

    selected = ArtifactData(
        id="report-selected",
        type="report",
        title="Selected",
        data={"cells": []},
        render_func=lambda *_: None,
    )
    updated = ArtifactData(
        id="report-updated",
        type="report",
        title="Updated",
        data={"cells": []},
        render_func=lambda *_: None,
    )
    viewer.artifacts = [selected, updated]
    viewer._artifact_index = {selected.id: selected, updated.id: updated}
    viewer.artifact_list.index = 0

    render_calls: list[str] = []
    viewer._render_artifact = lambda artifact: render_calls.append(artifact.id)  # type: ignore[method-assign]

    assert viewer.update_report_cells("report-updated", []) is True
    assert render_calls == []


def test_report_ready_rerenders_when_artifact_selected() -> None:
    """Selected report should rerender when mark_report_ready updates it."""
    viewer = ArtifactViewer()
    viewer.artifact_list = _StubListView()  # type: ignore[assignment]

    report = ArtifactData(
        id="report-1",
        type="report",
        title="Report",
        data={"is_ready": False},
        render_func=lambda *_: None,
    )
    viewer.artifacts = [report]
    viewer._artifact_index = {report.id: report}
    viewer.artifact_list.index = 0

    render_calls: list[str] = []
    viewer._render_artifact = lambda artifact: render_calls.append(artifact.id)  # type: ignore[method-assign]

    assert viewer.mark_report_ready("report-1") is True
    assert report.data["is_ready"] is True
    assert render_calls == ["report-1"]
