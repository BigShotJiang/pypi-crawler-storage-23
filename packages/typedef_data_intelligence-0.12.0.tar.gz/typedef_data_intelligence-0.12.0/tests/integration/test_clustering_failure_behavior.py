"""Tests for clustering failure behavior and result-shape compatibility."""

from __future__ import annotations

from unittest.mock import Mock

import lineage.integration as integration_mod
import pytest
from lineage.backends.lineage.models.clustering import ClusterAnalysis
from lineage.ingest.config import (
    ClusteringConfig,
    ProfilingConfig,
    SemanticAnalysisConfig,
    SemanticViewLoaderConfig,
)
from lineage.integration import LineageIntegration


class _FailingClusteringOrchestrator:
    def __init__(self, storage):  # type: ignore[no-untyped-def]
        self.storage = storage

    async def cluster_and_analyze(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        raise RuntimeError("boom")


class _OkClusteringOrchestrator:
    """Returns the new clustering result shape to exercise verbose logging path."""

    def __init__(self, storage):  # type: ignore[no-untyped-def]
        self.storage = storage

    async def cluster_and_analyze(self, *args, **kwargs):  # type: ignore[no-untyped-def]
        return {
            "clusters": {0: ["model.project.some_fact"]},
            "analyses": [
                ClusterAnalysis(
                    cluster_id=0,
                    subject_area_name="billing",
                    description=None,
                    model_count=1,
                    model_ids=["model.project.some_fact"],
                    fact_model_ids=["model.project.some_fact"],
                    dimension_model_ids=[],
                    mixed_model_ids=[],
                    has_pii_model_ids=[],
                    domains=["billing"],
                    total_edge_weight=0.0,
                    top_edges=[],
                    recommended_fact_model="model.project.some_fact",
                    recommended_dimension_order=[],
                    contains_pii=False,
                    notes=[],
                )
            ],
            "enrichment": {},
        }


def _make_integration(mock_storage, clustering_config: ClusteringConfig) -> LineageIntegration:
    return LineageIntegration(
        storage=mock_storage,
        semantic_config=SemanticAnalysisConfig(enabled=False),
        profiling_config=ProfilingConfig(enabled=False),
        clustering_config=clustering_config,
        semantic_view_config=SemanticViewLoaderConfig(enabled=False),
        data_backend=None,
    )


def test_run_clustering_is_best_effort_by_default(
    mock_storage, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Clustering failures should be logged but not abort the sync by default."""
    monkeypatch.setattr(
        integration_mod, "ClusteringOrchestrator", _FailingClusteringOrchestrator
    )
    integration = _make_integration(mock_storage, ClusteringConfig())

    ok = integration._run_clustering(session=Mock(), verbose=False)
    assert ok is False


def test_run_clustering_fail_fast_raises(
    mock_storage, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Opt-in fail-fast mode should propagate clustering exceptions."""
    monkeypatch.setattr(
        integration_mod, "ClusteringOrchestrator", _FailingClusteringOrchestrator
    )
    integration = _make_integration(mock_storage, ClusteringConfig(fail_fast=True))

    with pytest.raises(RuntimeError, match="boom"):
        integration._run_clustering(session=Mock(), verbose=False)


def test_run_clustering_verbose_path_handles_new_result_shape(
    mock_storage, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Verbose logging should not assume legacy summaries/blueprints keys."""
    monkeypatch.setattr(integration_mod, "ClusteringOrchestrator", _OkClusteringOrchestrator)
    integration = _make_integration(mock_storage, ClusteringConfig())

    ok = integration._run_clustering(session=Mock(), verbose=True)
    assert ok is True

