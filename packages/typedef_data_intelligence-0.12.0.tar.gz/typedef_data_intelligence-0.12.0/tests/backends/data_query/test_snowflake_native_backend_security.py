"""Security regression tests for SnowflakeNativeBackend.

This file consolidates tests that ensure:
- Identifier interpolation is safely quoted in SHOW-based semantic methods
- String literal escaping is correct for GET_DDL and other literal contexts
- Schema/database argument validation prevents ambiguous/unscoped calls
- Table allowlist validation fails closed when SQL parsing fails
"""

# ruff: noqa: D103

import pytest
from lineage.backends.data_query.snowflake_native_backend import SnowflakeNativeBackend


def _backend_without_init() -> SnowflakeNativeBackend:
    """Create a backend instance without importing Snowflake connector in tests."""
    return SnowflakeNativeBackend.__new__(SnowflakeNativeBackend)


def _set_no_restrictions(backend: SnowflakeNativeBackend) -> None:
    backend.allowed_databases = []  # type: ignore[attr-defined]
    backend.allowed_schemas = []  # type: ignore[attr-defined]
    backend.allowed_table_patterns = []  # type: ignore[attr-defined]


def _set_none_restrictions(backend: SnowflakeNativeBackend) -> None:
    """Simulate 'no restrictions configured' (None-style) for older callers."""
    backend.allowed_databases = None  # type: ignore[attr-defined]
    backend.allowed_schemas = None  # type: ignore[attr-defined]
    backend.allowed_table_patterns = None  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Argument validation + string literal escaping
# ---------------------------------------------------------------------------


def test_require_database_when_schema_provided_errors() -> None:
    """schema_name without database_name should error (avoid ambiguity + unscoped SHOW)."""
    with pytest.raises(ValueError, match="schema_name requires database_name"):
        SnowflakeNativeBackend._require_database_when_schema_provided(
            object(),
            database_name=None,
            schema_name="ANALYTICS",
        )


def test_require_database_when_schema_provided_allows_database_only() -> None:
    """database_name without schema_name is OK."""
    SnowflakeNativeBackend._require_database_when_schema_provided(
        object(),
        database_name="DB1",
        schema_name=None,
    )


def test_require_database_when_schema_provided_allows_database_and_schema() -> None:
    """database_name + schema_name is OK."""
    SnowflakeNativeBackend._require_database_when_schema_provided(
        object(),
        database_name="DB1",
        schema_name="SC1",
    )


def test_escape_snowflake_string_literal_escapes_single_quotes() -> None:
    """Single quotes must be doubled to prevent SQL injection in Snowflake SQL string literals."""
    assert SnowflakeNativeBackend._escape_snowflake_string_literal(None) == ""
    assert SnowflakeNativeBackend._escape_snowflake_string_literal("simple") == "simple"
    assert SnowflakeNativeBackend._escape_snowflake_string_literal("test'") == "test''"
    assert (
        SnowflakeNativeBackend._escape_snowflake_string_literal("foo'; DROP TABLE users; --")
        == "foo''; DROP TABLE users; --"
    )
    assert (
        SnowflakeNativeBackend._escape_snowflake_string_literal("It's a test")
        == "It''s a test"
    )
    assert SnowflakeNativeBackend._escape_snowflake_string_literal("O'Reilly") == "O''Reilly"
    assert SnowflakeNativeBackend._escape_snowflake_string_literal("'test'") == "''test''"


@pytest.mark.asyncio
async def test_get_semantic_view_ddl_escapes_qualified_name_to_prevent_sql_injection() -> None:
    """Ensure view_name cannot break out of GET_DDL string literal via quotes."""
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()

    captured: dict[str, str] = {}

    async def _ensure_connected() -> None:
        return None

    def _validate_schema_access(_database_name: str, _schema_name: str) -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        captured["query"] = query
        return QueryResult(columns=["ddl"], rows=[("ddl",)], row_count=1)

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend._validate_schema_access = _validate_schema_access  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    malicious_view_name = "test'); DROP TABLE users; --"
    ddl = await backend.get_semantic_view_ddl("DB", "SCHEMA", malicious_view_name)
    assert ddl == "ddl"

    query = captured["query"]
    assert "GET_DDL('SEMANTIC_VIEW'," in query
    # Unquoted identifiers are uppercased by Snowflake normalization
    assert "test'); DROP TABLE users; --" not in query
    assert "DB.SCHEMA.TEST''); DROP TABLE USERS; --" in query


# ---------------------------------------------------------------------------
# SHOW semantic methods: identifier quoting (database/schema/view)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_semantic_views_quotes_database_and_schema_identifiers() -> None:
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    _set_none_restrictions(backend)

    captured: dict[str, str] = {}

    async def _ensure_connected() -> None:
        return None

    def _validate_schema_access(_database_name: str, _schema_name: str) -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        captured["query"] = query
        return QueryResult(
            columns=["created_on", "name", "database_name", "schema_name", "owner", "comment"],
            rows=[(None, "SV", "DB", "SCHEMA", None, None)],
            row_count=1,
        )

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend._validate_schema_access = _validate_schema_access  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    db = 'DB"; DROP TABLE users; --'
    schema = "SCHEMA"
    await backend.list_semantic_views(database_name=db, schema_name=schema)

    query = captured["query"]
    # Unquoted identifiers are uppercased by Snowflake normalization
    assert 'IN SCHEMA "DB""; DROP TABLE USERS; --"."SCHEMA"' in query
    assert 'IN SCHEMA DB"; DROP TABLE users; --.SCHEMA' not in query
    assert 'DB""; DROP TABLE USERS; --' in query


@pytest.mark.asyncio
async def test_show_semantic_metrics_quotes_database_schema_and_view_identifiers() -> None:
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    _set_none_restrictions(backend)

    captured: dict[str, str] = {}

    async def _ensure_connected() -> None:
        return None

    def _validate_schema_access(_database_name: str, _schema_name: str) -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        captured["query"] = query
        return QueryResult(columns=["x"], rows=[], row_count=0)

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend._validate_schema_access = _validate_schema_access  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    db = 'DB"; DROP TABLE users; --'
    schema = "SCHEMA"
    view = 'SV"; SELECT 1; --'
    await backend.show_semantic_metrics(database_name=db, schema_name=schema, view_name=view)

    query = captured["query"]
    # Unquoted identifiers are uppercased by Snowflake normalization
    assert 'IN "DB""; DROP TABLE USERS; --"."SCHEMA"."SV""; SELECT 1; --"' in query
    assert 'SV"; SELECT 1; --' not in query
    assert 'SV""; SELECT 1; --' in query


@pytest.mark.asyncio
async def test_show_semantic_dimensions_quotes_database_schema_and_view_identifiers() -> None:
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    _set_none_restrictions(backend)

    captured: dict[str, str] = {}

    async def _ensure_connected() -> None:
        return None

    def _validate_schema_access(_database_name: str, _schema_name: str) -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        captured["query"] = query
        return QueryResult(columns=["x"], rows=[], row_count=0)

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend._validate_schema_access = _validate_schema_access  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    db = "DB"
    schema = 'SCHEMA"; DROP TABLE users; --'
    view = "SV"
    await backend.show_semantic_dimensions(database_name=db, schema_name=schema, view_name=view)

    query = captured["query"]
    # Unquoted identifiers are uppercased by Snowflake normalization
    assert 'IN "DB"."SCHEMA""; DROP TABLE USERS; --"."SV"' in query
    assert 'SCHEMA"; DROP TABLE users; --' not in query


@pytest.mark.asyncio
async def test_show_semantic_facts_quotes_database_schema_and_view_identifiers() -> None:
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    _set_none_restrictions(backend)

    captured: dict[str, str] = {}

    async def _ensure_connected() -> None:
        return None

    def _validate_schema_access(_database_name: str, _schema_name: str) -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        captured["query"] = query
        return QueryResult(columns=["x"], rows=[], row_count=0)

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend._validate_schema_access = _validate_schema_access  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    db = "DB"
    schema = "SCHEMA"
    view = 'SV"; DROP TABLE users; --'
    await backend.show_semantic_facts(database_name=db, schema_name=schema, view_name=view)

    query = captured["query"]
    # Unquoted identifiers are uppercased by Snowflake normalization
    assert 'IN "DB"."SCHEMA"."SV""; DROP TABLE USERS; --"' in query
    assert 'SV"; DROP TABLE users; --' not in query


# ---------------------------------------------------------------------------
# _build_show_filter_suffix: LIKE / STARTS WITH escaping
# ---------------------------------------------------------------------------


def test_build_show_filter_suffix_escapes_like_sql_injection() -> None:
    """Single quotes in LIKE patterns must be doubled to prevent SQL injection."""
    backend = _backend_without_init()

    result = backend._build_show_filter_suffix(like="'; DROP TABLE users; --")
    # The leading single quote must be escaped (doubled), closing the LIKE literal safely
    assert result == " LIKE '''; DROP TABLE users; --'"
    # The unescaped injection (quote NOT doubled) must not appear
    assert "LIKE ''" in result  # escaped quote present
    assert "LIKE '; DROP" not in result  # unescaped breakout absent


def test_build_show_filter_suffix_escapes_starts_with_sql_injection() -> None:
    """Single quotes in STARTS WITH patterns must be doubled to prevent SQL injection."""
    backend = _backend_without_init()

    result = backend._build_show_filter_suffix(starts_with="test'; DROP TABLE users; --")
    assert result == " STARTS WITH 'test''; DROP TABLE users; --'"
    assert "test'; DROP TABLE users; --'" not in result


def test_build_show_filter_suffix_like_takes_precedence_over_starts_with() -> None:
    """When both like and starts_with are provided, like wins."""
    backend = _backend_without_init()

    result = backend._build_show_filter_suffix(like="sv_%", starts_with="sv_")
    assert result == " LIKE 'sv_%'"
    assert "STARTS WITH" not in result


def test_build_show_filter_suffix_returns_empty_when_no_filters() -> None:
    backend = _backend_without_init()

    assert backend._build_show_filter_suffix() == ""
    assert backend._build_show_filter_suffix(like=None, starts_with=None) == ""


@pytest.mark.asyncio
async def test_execute_scoped_show_escapes_like_in_generated_command() -> None:
    """End-to-end: malicious LIKE pattern is escaped in the final SHOW command."""
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    _set_none_restrictions(backend)

    captured: list[str] = []

    async def _ensure_connected() -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        captured.append(query)
        return QueryResult(
            columns=["created_on", "name", "database_name", "schema_name"],
            rows=[],
            row_count=0,
        )

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    await backend._execute_scoped_show(
        "SEMANTIC VIEWS",
        like="'; DROP TABLE users; --",
    )

    assert len(captured) == 1
    query = captured[0]
    # Escaped quote should appear (doubled)
    assert "'''" in query
    # Unescaped breakout (LIKE followed by the raw injection) must not appear
    assert "LIKE '; DROP" not in query


@pytest.mark.asyncio
async def test_execute_scoped_show_escapes_starts_with_in_generated_command() -> None:
    """End-to-end: malicious STARTS WITH pattern is escaped in the final SHOW command."""
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    _set_none_restrictions(backend)

    captured: list[str] = []

    async def _ensure_connected() -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        captured.append(query)
        return QueryResult(
            columns=["created_on", "name", "database_name", "schema_name"],
            rows=[],
            row_count=0,
        )

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    await backend._execute_scoped_show(
        "SEMANTIC METRICS",
        starts_with="test'; SELECT 1; --",
    )

    assert len(captured) == 1
    query = captured[0]
    assert "STARTS WITH" in query
    assert "test''; SELECT 1; --" in query
    assert "test'; SELECT 1; --'" not in query


# ---------------------------------------------------------------------------
# _get_allowed_scopes: scope clause generation
# ---------------------------------------------------------------------------


def test_get_allowed_scopes_returns_empty_when_no_allowlists() -> None:
    """No allowlists configured → empty list (will fall back to IN ACCOUNT)."""
    backend = _backend_without_init()

    # None
    backend.allowed_databases = None  # type: ignore[attr-defined]
    backend.allowed_schemas = None  # type: ignore[attr-defined]
    assert backend._get_allowed_scopes() == []

    # Empty lists
    backend.allowed_databases = []  # type: ignore[attr-defined]
    backend.allowed_schemas = []  # type: ignore[attr-defined]
    assert backend._get_allowed_scopes() == []


def test_get_allowed_scopes_database_only() -> None:
    """Only allowed_databases → one IN DATABASE clause per database."""
    backend = _backend_without_init()
    backend.allowed_databases = ["analytics", "raw"]  # type: ignore[attr-defined]
    backend.allowed_schemas = []  # type: ignore[attr-defined]

    scopes = backend._get_allowed_scopes()
    assert len(scopes) == 2
    assert scopes[0] == 'IN DATABASE "ANALYTICS"'
    assert scopes[1] == 'IN DATABASE "RAW"'


def test_get_allowed_scopes_database_and_schema_cartesian() -> None:
    """Both allowed_databases and allowed_schemas → database × schema pairs."""
    backend = _backend_without_init()
    backend.allowed_databases = ["db1", "db2"]  # type: ignore[attr-defined]
    backend.allowed_schemas = ["marts", "staging"]  # type: ignore[attr-defined]

    scopes = backend._get_allowed_scopes()
    assert len(scopes) == 4
    assert scopes[0] == 'IN SCHEMA "DB1"."MARTS"'
    assert scopes[1] == 'IN SCHEMA "DB1"."STAGING"'
    assert scopes[2] == 'IN SCHEMA "DB2"."MARTS"'
    assert scopes[3] == 'IN SCHEMA "DB2"."STAGING"'


def test_get_allowed_scopes_quotes_special_characters() -> None:
    """Identifiers with special characters are properly quoted."""
    backend = _backend_without_init()
    backend.allowed_databases = ['my"db']  # type: ignore[attr-defined]
    backend.allowed_schemas = []  # type: ignore[attr-defined]

    scopes = backend._get_allowed_scopes()
    assert len(scopes) == 1
    # Double-quote inside identifier should be escaped
    assert 'IN DATABASE "MY""DB"' in scopes[0]


# ---------------------------------------------------------------------------
# _execute_scoped_show: scoped command generation and result merging
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_execute_scoped_show_generates_per_database_commands() -> None:
    """With allowed_databases set, issues one SHOW per database instead of IN ACCOUNT."""
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    backend.allowed_databases = ["DB1", "DB2"]  # type: ignore[attr-defined]
    backend.allowed_schemas = []  # type: ignore[attr-defined]
    backend.allowed_table_patterns = []  # type: ignore[attr-defined]

    captured: list[str] = []

    async def _ensure_connected() -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        captured.append(query)
        return QueryResult(
            columns=["name", "database_name"],
            rows=[("VIEW1", "DB1")] if "DB1" in query else [("VIEW2", "DB2")],
            row_count=1,
        )

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    result = await backend._execute_scoped_show("SEMANTIC VIEWS")

    # Should have issued 2 commands, one per database
    assert len(captured) == 2
    assert 'IN DATABASE "DB1"' in captured[0]
    assert 'IN DATABASE "DB2"' in captured[1]
    assert "IN ACCOUNT" not in captured[0]
    assert "IN ACCOUNT" not in captured[1]

    # Results should be merged
    assert result.row_count == 2
    assert len(result.rows) == 2


@pytest.mark.asyncio
async def test_execute_scoped_show_generates_per_schema_commands() -> None:
    """With both allowed_databases and allowed_schemas, issues per-schema commands."""
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    backend.allowed_databases = ["DB1"]  # type: ignore[attr-defined]
    backend.allowed_schemas = ["MARTS", "RAW"]  # type: ignore[attr-defined]
    backend.allowed_table_patterns = []  # type: ignore[attr-defined]

    captured: list[str] = []

    async def _ensure_connected() -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        captured.append(query)
        return QueryResult(columns=["name"], rows=[("V1",)], row_count=1)

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    result = await backend._execute_scoped_show("SEMANTIC METRICS")

    assert len(captured) == 2
    assert 'IN SCHEMA "DB1"."MARTS"' in captured[0]
    assert 'IN SCHEMA "DB1"."RAW"' in captured[1]
    assert result.row_count == 2


@pytest.mark.asyncio
async def test_execute_scoped_show_falls_back_to_account_when_no_allowlists() -> None:
    """No allowlists → falls back to IN ACCOUNT."""
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    _set_none_restrictions(backend)

    captured: list[str] = []

    async def _ensure_connected() -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        captured.append(query)
        return QueryResult(columns=["name"], rows=[], row_count=0)

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    await backend._execute_scoped_show("SEMANTIC VIEWS")

    assert len(captured) == 1
    assert "IN ACCOUNT" in captured[0]


@pytest.mark.asyncio
async def test_execute_scoped_show_handles_partial_failures() -> None:
    """If one scope fails but another succeeds, returns successful results."""
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    backend.allowed_databases = ["GOOD_DB", "BAD_DB"]  # type: ignore[attr-defined]
    backend.allowed_schemas = []  # type: ignore[attr-defined]
    backend.allowed_table_patterns = []  # type: ignore[attr-defined]

    async def _ensure_connected() -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        if "BAD_DB" in query:
            return QueryResult(
                columns=[], rows=[], row_count=0,
                error_message="Database 'BAD_DB' does not exist",
            )
        return QueryResult(
            columns=["name", "database_name"],
            rows=[("VIEW1", "GOOD_DB")],
            row_count=1,
        )

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    result = await backend._execute_scoped_show("SEMANTIC VIEWS")

    # Should return results from the successful scope
    assert result.row_count == 1
    assert result.error_message is None
    assert result.rows[0] == ("VIEW1", "GOOD_DB")


@pytest.mark.asyncio
async def test_execute_scoped_show_returns_error_when_all_scopes_fail() -> None:
    """If every scope fails, returns a QueryResult with error_message."""
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    backend.allowed_databases = ["BAD1", "BAD2"]  # type: ignore[attr-defined]
    backend.allowed_schemas = []  # type: ignore[attr-defined]
    backend.allowed_table_patterns = []  # type: ignore[attr-defined]

    async def _ensure_connected() -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        return QueryResult(
            columns=[], rows=[], row_count=0,
            error_message="Access denied",
        )

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    result = await backend._execute_scoped_show("SEMANTIC VIEWS")

    assert result.row_count == 0
    assert result.error_message == "Access denied"


@pytest.mark.asyncio
async def test_execute_scoped_show_uses_explicit_scope_over_allowlist() -> None:
    """When database_name is passed explicitly, uses it directly (no iteration)."""
    from lineage.backends.data_query.protocol import QueryResult

    backend = _backend_without_init()
    backend.allowed_databases = ["DB1", "DB2"]  # type: ignore[attr-defined]
    backend.allowed_schemas = []  # type: ignore[attr-defined]
    backend.allowed_table_patterns = []  # type: ignore[attr-defined]

    captured: list[str] = []

    async def _ensure_connected() -> None:
        return None

    async def execute_query(query: str, **_kwargs) -> QueryResult:
        captured.append(query)
        return QueryResult(columns=["name"], rows=[], row_count=0)

    backend._ensure_connected = _ensure_connected  # type: ignore[attr-defined]
    backend.execute_query = execute_query  # type: ignore[attr-defined]

    await backend._execute_scoped_show("SEMANTIC VIEWS", database_name="SPECIFIC_DB")

    # Should issue exactly one command for the explicit database
    assert len(captured) == 1
    assert 'IN DATABASE "SPECIFIC_DB"' in captured[0]


# ---------------------------------------------------------------------------
# Table allowlist validation: fail closed on parse errors
# ---------------------------------------------------------------------------


def test_table_access_validation_fails_closed_when_sqlglot_cannot_parse(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If allowlists are configured, an un-parseable query must be blocked."""
    from lineage.backends.data_query import snowflake_native_backend as mod

    backend = _backend_without_init()
    backend.allowed_databases = ["DB1"]  # type: ignore[attr-defined]
    backend.allowed_schemas = []  # type: ignore[attr-defined]
    backend.allowed_table_patterns = []  # type: ignore[attr-defined]

    class _Cfg:
        database = "DB1"
        schema_name = "SC1"

    backend.config = _Cfg()  # type: ignore[attr-defined]

    def _boom(*_args, **_kwargs):
        raise mod.sqlglot.errors.ParseError("boom")

    monkeypatch.setattr(mod.sqlglot, "parse", _boom)

    with pytest.raises(PermissionError, match="Could not parse SQL to validate table access"):
        backend._extract_and_validate_tables_from_query(  # type: ignore[attr-defined]
            "SELECT * FROM DB1.SC1.SECRET_TABLE"
        )


def test_table_access_validation_does_not_block_when_no_restrictions(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If no allowlists are configured, validation is skipped (no parse required)."""
    from lineage.backends.data_query import snowflake_native_backend as mod

    backend = _backend_without_init()
    _set_no_restrictions(backend)

    def _boom(*_args, **_kwargs):
        raise mod.sqlglot.errors.ParseError("boom")

    monkeypatch.setattr(mod.sqlglot, "parse", _boom)

    backend._extract_and_validate_tables_from_query("SELECT 1")  # type: ignore[attr-defined]


