"""Tests for bulk profiling helpers: value pattern classifier and derived metrics."""

from __future__ import annotations

from lineage.backends.data_query.snowflake_native_backend import _classify_value_pattern


class TestClassifyValuePattern:
    """Tests for _classify_value_pattern()."""

    def test_uuid_samples(self) -> None:
        values = [
            "550e8400-e29b-41d4-a716-446655440000",
            "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
            "f47ac10b-58cc-4372-a567-0e02b2c3d479",
            "7c9e6679-7425-40de-944b-e07fc1f90ae7",
            "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
        ]
        assert _classify_value_pattern(values) == "uuid"

    def test_sequential_integers(self) -> None:
        values = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
        assert _classify_value_pattern(values) == "sequential"

    def test_composite_keys(self) -> None:
        values = [
            "US_2024_001",
            "US_2024_002",
            "EU_2024_003",
            "AP_2024_004",
            "US_2024_005",
        ]
        assert _classify_value_pattern(values) == "composite"

    def test_boolean_like(self) -> None:
        values = ["true", "false", "true", "true", "false"]
        assert _classify_value_pattern(values) == "boolean_like"

    def test_low_cardinality(self) -> None:
        values = ["red", "blue", "green", "red", "blue", "green"] * 5
        assert _classify_value_pattern(values) == "low_cardinality"

    def test_mixed_default(self) -> None:
        values = [
            "abc123", "xyz789", "hello world", "foo_bar",
            "12345", "test@email.com", "2024-01-01",
            "random text", "another value", "something else",
            "more stuff", "extra data", "final entry",
        ]
        assert _classify_value_pattern(values) == "mixed"

    def test_empty_values(self) -> None:
        assert _classify_value_pattern([]) == "mixed"

    def test_uuid_threshold(self) -> None:
        """80% UUID match should still classify as UUID."""
        uuids = [
            "550e8400-e29b-41d4-a716-446655440000",
            "6ba7b810-9dad-11d1-80b4-00c04fd430c8",
            "f47ac10b-58cc-4372-a567-0e02b2c3d479",
            "7c9e6679-7425-40de-944b-e07fc1f90ae7",
        ]
        non_uuids = ["not-a-uuid"]
        # 4/5 = 80% — exactly at threshold
        assert _classify_value_pattern(uuids + non_uuids) == "uuid"

    def test_non_consecutive_integers_not_sequential(self) -> None:
        """Non-consecutive integers should not be sequential."""
        values = ["1", "3", "5", "7", "9"]
        # These are sorted integers but not consecutive
        assert _classify_value_pattern(values) != "sequential"

    def test_composite_with_hyphens(self) -> None:
        """Values with hyphens (non-UUID) should be composite."""
        values = [
            "order-001-us",
            "order-002-eu",
            "order-003-ap",
            "order-004-us",
            "order-005-eu",
            "order-006-ap",
            "order-007-us",
            "order-008-eu",
            "order-009-ap",
            "order-010-us",
            "order-011-eu",
        ]
        assert _classify_value_pattern(values) == "composite"
