"""Tests for batch operations in FalkorDB adapter.

Verifies that _batch_upsert_nodes, _create_edges_individually,
and bulk_load() correctly batch, chunk, and create edges.
"""

from __future__ import annotations

import pytest
from lineage.backends.lineage.models.dbt import DbtModel
from lineage.backends.lineage.models.edges import DependsOn


class TestBatchUpsertNodes:
    """Tests for _batch_upsert_nodes via bulk_load()."""

    def test_batch_upsert_multiple_same_label(self, falkordblite_storage):
        """Multiple nodes of the same label are created in a single batch."""
        nodes = [
            DbtModel(unique_id=f"model.test.m{i}", name=f"m{i}", materialization="table")
            for i in range(5)
        ]

        falkordblite_storage.bulk_load(nodes, [])

        result = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtModel) RETURN m.id AS id ORDER BY m.id"
        )
        assert result.count == 5
        ids = [r["id"] for r in result.rows]
        assert ids == [f"model.test.m{i}" for i in range(5)]

    def test_batch_heterogeneous_properties(self, falkordblite_storage):
        """Nodes with different property subsets within the same label."""
        nodes = [
            DbtModel(unique_id="model.test.with_desc", name="with_desc", description="has desc"),
            DbtModel(unique_id="model.test.no_desc", name="no_desc"),
        ]

        falkordblite_storage.bulk_load(nodes, [])

        result = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtModel) RETURN m.id AS id, m.description AS description ORDER BY m.id"
        )
        assert result.count == 2
        rows_by_id = {r["id"]: r for r in result.rows}
        assert rows_by_id["model.test.with_desc"]["description"] == "has desc"
        # no_desc should have None for description
        assert rows_by_id["model.test.no_desc"]["description"] is None

    def test_batch_merge_updates_existing(self, falkordblite_storage):
        """MERGE ON MATCH updates existing nodes correctly."""
        # Create initial node
        node_v1 = DbtModel(unique_id="model.test.update_me", name="update_me", description="v1")
        falkordblite_storage.bulk_load([node_v1], [])

        # Update with new description
        node_v2 = DbtModel(unique_id="model.test.update_me", name="update_me", description="v2")
        falkordblite_storage.bulk_load([node_v2], [])

        result = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtModel {id: 'model.test.update_me'}) RETURN m.description AS description"
        )
        assert result.count == 1
        assert result.rows[0]["description"] == "v2"

    def test_batch_merge_preserves_unset_properties(self, falkordblite_storage):
        """ON MATCH with COALESCE preserves properties not in the update batch."""
        # Create node with description
        node_v1 = DbtModel(
            unique_id="model.test.preserve", name="preserve", description="keep me"
        )
        falkordblite_storage.bulk_load([node_v1], [])

        # Update same node WITHOUT description (heterogeneous batch)
        node_v2 = DbtModel(unique_id="model.test.preserve", name="preserve_updated")
        falkordblite_storage.bulk_load([node_v2], [])

        result = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtModel {id: 'model.test.preserve'}) "
            "RETURN m.name AS name, m.description AS description"
        )
        assert result.count == 1
        assert result.rows[0]["name"] == "preserve_updated"
        # description should be preserved, not nulled
        assert result.rows[0]["description"] == "keep me"

    def test_mixed_labels_in_single_bulk_load(self, falkordblite_storage):
        """bulk_load groups by label and batches each separately."""
        from lineage.backends.lineage.models.dbt import DbtSource

        nodes = [
            DbtModel(unique_id="model.test.my_model", name="my_model"),
            DbtSource(unique_id="source.test.my_source", name="my_source"),
        ]
        falkordblite_storage.bulk_load(nodes, [])

        model_result = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtModel) RETURN COUNT(m) AS count"
        )
        source_result = falkordblite_storage.execute_raw_query(
            "MATCH (s:DbtSource) RETURN COUNT(s) AS count"
        )
        assert model_result.rows[0]["count"] == 1
        assert source_result.rows[0]["count"] == 1


class TestBatchCreateEdges:
    """Tests for _create_edges_individually via bulk_load()."""

    def test_batch_edge_creation(self, falkordblite_storage):
        """Edges are created in batches between existing nodes."""
        m1 = DbtModel(unique_id="model.test.a", name="a")
        m2 = DbtModel(unique_id="model.test.b", name="b")
        m3 = DbtModel(unique_id="model.test.c", name="c")

        edges = [
            (m2, m1, DependsOn(type="model", direct=True)),
            (m3, m2, DependsOn(type="model", direct=True)),
        ]
        falkordblite_storage.bulk_load([m1, m2, m3], edges)

        result = falkordblite_storage.execute_raw_query(
            "MATCH (a:DbtModel)-[r:DEPENDS_ON]->(b:DbtModel) "
            "RETURN a.id AS from_id, b.id AS to_id ORDER BY a.id"
        )
        assert result.count == 2
        pairs = [(r["from_id"], r["to_id"]) for r in result.rows]
        assert ("model.test.b", "model.test.a") in pairs
        assert ("model.test.c", "model.test.b") in pairs


class TestBulkLoadChunking:
    """Tests for batch_size chunking behavior."""

    def test_large_load_with_small_batch(self, falkordblite_storage):
        """Verify chunking works: 750 nodes with batch_size=200."""
        nodes = [
            DbtModel(unique_id=f"model.test.node_{i:04d}", name=f"node_{i:04d}")
            for i in range(750)
        ]

        falkordblite_storage.bulk_load(nodes, [], batch_size=200)

        result = falkordblite_storage.execute_raw_query(
            "MATCH (m:DbtModel) RETURN COUNT(m) AS count"
        )
        assert result.rows[0]["count"] == 750

    def test_progress_callback_fires(self, falkordblite_storage):
        """Progress callback fires for each batch."""
        nodes = [
            DbtModel(unique_id=f"model.test.cb_{i}", name=f"cb_{i}")
            for i in range(10)
        ]

        calls = []

        def callback(current, total, message):
            calls.append((current, total, message))

        falkordblite_storage.bulk_load(nodes, [], progress_callback=callback, batch_size=3)

        # 10 nodes / batch_size=3 = 4 batches (3+3+3+1) → 4 callback calls
        assert len(calls) == 4
        # Last call should report all 10 nodes loaded
        assert calls[-1][0] == 10

    def test_empty_bulk_load(self, falkordblite_storage):
        """Empty bulk_load is a no-op."""
        falkordblite_storage.bulk_load([], [])

        result = falkordblite_storage.execute_raw_query(
            "MATCH (n) RETURN COUNT(n) AS count"
        )
        assert result.rows[0]["count"] == 0

    def test_read_only_raises(self, falkordblite_storage):
        """bulk_load raises ValueError in read-only mode."""
        falkordblite_storage.read_only = True
        try:
            with pytest.raises(ValueError, match="read-only"):
                falkordblite_storage.bulk_load([], [])
        finally:
            falkordblite_storage.read_only = False
