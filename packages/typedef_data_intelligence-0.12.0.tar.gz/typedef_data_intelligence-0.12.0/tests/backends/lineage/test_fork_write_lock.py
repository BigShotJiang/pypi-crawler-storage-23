"""Tests for ForkWriteLock — Redis-based write/COPY mutual exclusion."""

from __future__ import annotations

import threading
import time

import fakeredis
import pytest
from lineage.backends.lineage.fork_write_lock import ForkWriteLock


@pytest.fixture()
def redis_client():
    """Create a fakeredis client shared across a single test."""
    server = fakeredis.FakeServer()
    return fakeredis.FakeRedis(server=server)


@pytest.fixture()
def lock(redis_client):
    """Create a ForkWriteLock with short timeouts for testing."""
    return ForkWriteLock(
        redis_client=redis_client,
        context_id="test_ctx",
        key_ttl=60,
        poll_interval=0.01,
        acquire_timeout=2,
    )


def _make_lock(redis_client, context_id="test_ctx"):
    """Helper to create a lock with the same redis client."""
    return ForkWriteLock(
        redis_client=redis_client,
        context_id=context_id,
        key_ttl=60,
        poll_interval=0.01,
        acquire_timeout=2,
    )


class TestWriteAcquireRelease:
    """Basic write lock acquire/release cycles."""

    def test_acquire_and_release(self, lock: ForkWriteLock):
        lock.acquire_write()
        lock.release_write()

    def test_write_guard_context_manager(self, lock: ForkWriteLock):
        with lock.write_guard():
            pass

    def test_multiple_acquires(self, lock: ForkWriteLock):
        lock.acquire_write()
        lock.acquire_write()
        lock.release_write()
        lock.release_write()


class TestMultipleConcurrentWriters:
    """Multiple concurrent writers should succeed when no COPY is pending."""

    def test_concurrent_writers(self, redis_client):
        results = []

        def writer(idx):
            lk = _make_lock(redis_client)
            with lk.write_guard():
                results.append(idx)
                time.sleep(0.02)

        threads = [threading.Thread(target=writer, args=(i,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=5)

        assert sorted(results) == list(range(5))


class TestCopyBlocksNewWriters:
    """When a COPY is pending, new writers must wait."""

    def test_copy_blocks_writers(self, redis_client):
        lock = _make_lock(redis_client)
        # Signal copy pending manually
        lock.acquire_copy()

        # A new writer should time out
        writer_lock = _make_lock(redis_client)
        writer_lock._acquire_timeout = 0.2
        with pytest.raises(TimeoutError, match="acquire_write"):
            writer_lock.acquire_write()

        # After releasing copy, writer should succeed
        lock.release_copy()
        writer_lock.acquire_write()
        writer_lock.release_write()


class TestCopyWaitsForWritersToDrain:
    """COPY acquisition waits for active writers to finish."""

    def test_copy_waits_for_writers(self, redis_client):
        writer_lock = _make_lock(redis_client)
        copy_lock = _make_lock(redis_client)

        writer_lock.acquire_write()

        copy_acquired = threading.Event()
        copy_error = []

        def acquire_copy():
            try:
                copy_lock.acquire_copy()
                copy_acquired.set()
                copy_lock.release_copy()
            except Exception as e:
                copy_error.append(e)

        t = threading.Thread(target=acquire_copy)
        t.start()

        # Copy should not have acquired yet (writer is active)
        time.sleep(0.1)
        assert not copy_acquired.is_set()

        # Release writer — copy should now proceed
        writer_lock.release_write()
        t.join(timeout=5)

        assert copy_acquired.is_set()
        assert not copy_error


class TestCleanup:
    """cleanup() removes all context keys."""

    def test_cleanup_removes_keys(self, redis_client, lock: ForkWriteLock):
        lock.acquire_write()
        # Keys should exist
        assert redis_client.exists("fork_rw:test_ctx:writers")

        lock.cleanup()

        assert not redis_client.exists("fork_rw:test_ctx:writers")
        assert not redis_client.exists("fork_rw:test_ctx:copy_pending")


class TestCopyTimeoutDecrement:
    """When copy acquisition times out, copy_pending is decremented."""

    def test_timeout_decrements_copy_pending(self, redis_client):
        writer_lock = _make_lock(redis_client)
        copy_lock = _make_lock(redis_client)
        copy_lock._acquire_timeout = 0.2

        writer_lock.acquire_write()

        with pytest.raises(TimeoutError, match="acquire_copy"):
            copy_lock.acquire_copy()

        # copy_pending should have been rolled back
        cp = redis_client.get("fork_rw:test_ctx:copy_pending")
        assert cp is None or int(cp) == 0

        writer_lock.release_write()


class TestWaitForForkIdle:
    """acquire_copy waits for module_fork_in_progress to clear."""

    def test_skips_when_no_fork_in_progress(self, redis_client):
        lock = _make_lock(redis_client)
        # Patch info() to report no fork in progress
        original_info = redis_client.info
        redis_client.info = lambda section=None: {"module_fork_in_progress": 0}
        try:
            lock.acquire_copy()
            lock.release_copy()
        finally:
            redis_client.info = original_info

    def test_waits_until_fork_finishes(self, redis_client):
        lock = _make_lock(redis_client)
        call_count = 0

        def mock_info(section=None):
            nonlocal call_count
            call_count += 1
            # Fork is in progress for the first 3 calls, then clears
            return {"module_fork_in_progress": 1 if call_count <= 3 else 0}

        redis_client.info = mock_info
        try:
            lock.acquire_copy()
            lock.release_copy()
            assert call_count >= 4
        finally:
            del redis_client.info


class TestMaxWritersSemaphore:
    """Writer semaphore limits concurrent writers."""

    def test_semaphore_caps_concurrent_writers(self, redis_client):
        max_writers = 2
        lock = ForkWriteLock(
            redis_client=redis_client,
            context_id="test_ctx",
            key_ttl=60,
            poll_interval=0.01,
            acquire_timeout=2,
            max_writers=max_writers,
        )

        peak_writers = 0
        peak_lock = threading.Lock()
        current_writers = 0

        def writer():
            nonlocal peak_writers, current_writers
            lock.acquire_write()
            with peak_lock:
                current_writers += 1
                peak_writers = max(peak_writers, current_writers)
            # Hold the lock briefly so concurrency can be observed
            time.sleep(0.05)
            with peak_lock:
                current_writers -= 1
            lock.release_write()

        threads = [threading.Thread(target=writer) for _ in range(6)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

        assert peak_writers <= max_writers

    def test_semaphore_timeout(self, redis_client):
        lock = ForkWriteLock(
            redis_client=redis_client,
            context_id="test_ctx",
            key_ttl=60,
            poll_interval=0.01,
            acquire_timeout=0.2,
            max_writers=1,
        )

        # Hold the only semaphore slot
        lock.acquire_write()

        # Second acquire should timeout on semaphore
        with pytest.raises(TimeoutError, match="writer semaphore"):
            lock.acquire_write()

        lock.release_write()

    def test_semaphore_released_on_redis_error(self, redis_client):
        """Semaphore is released if Redis script fails during acquire."""
        lock = ForkWriteLock(
            redis_client=redis_client,
            context_id="test_ctx",
            key_ttl=60,
            poll_interval=0.01,
            acquire_timeout=0.5,
            max_writers=1,
        )

        # Make the Redis script fail
        original_script = lock._acquire_write_script

        def failing_script(**kwargs):
            raise RuntimeError("fake Redis failure")

        lock._acquire_write_script = failing_script

        with pytest.raises(ConnectionError):
            lock.acquire_write()

        # Semaphore should have been released — next acquire should work
        lock._acquire_write_script = original_script
        lock.acquire_write()
        lock.release_write()


class TestCopySerialization:
    """Copy semaphore serializes concurrent GRAPH.COPY operations."""

    def test_copies_serialized(self, redis_client):
        """With max_copies=1, only one copy runs at a time."""
        lock = ForkWriteLock(
            redis_client=redis_client,
            context_id="test_ctx",
            key_ttl=60,
            poll_interval=0.01,
            acquire_timeout=5,
            max_copies=1,
        )

        peak_copies = 0
        peak_lock = threading.Lock()
        current_copies = 0
        errors = []

        def copier():
            nonlocal peak_copies, current_copies
            try:
                lock.acquire_copy()
                with peak_lock:
                    current_copies += 1
                    peak_copies = max(peak_copies, current_copies)
                time.sleep(0.05)
                with peak_lock:
                    current_copies -= 1
                lock.release_copy()
            except Exception as e:
                errors.append(e)

        threads = [threading.Thread(target=copier) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

        assert not errors
        assert peak_copies == 1

    def test_copy_semaphore_timeout(self, redis_client):
        lock = ForkWriteLock(
            redis_client=redis_client,
            context_id="test_ctx",
            key_ttl=60,
            poll_interval=0.01,
            acquire_timeout=0.3,
            max_copies=1,
        )

        # Hold the only copy slot
        lock.acquire_copy()

        # Second copy should timeout on semaphore
        with pytest.raises(TimeoutError, match="copy semaphore"):
            lock.acquire_copy()

        lock.release_copy()

    def test_copy_semaphore_released_on_error_after_acquire(self, redis_client):
        """Copy semaphore is released if an error occurs after it's acquired."""
        lock = ForkWriteLock(
            redis_client=redis_client,
            context_id="test_ctx",
            key_ttl=60,
            poll_interval=0.01,
            acquire_timeout=2,
            max_copies=1,
        )

        # Make _read_counters raise after the copy semaphore is acquired
        # (_read_counters is called after _wait_for_fork_idle and semaphore acquire)
        original_get = redis_client.get
        call_count = 0

        def failing_get(key):
            nonlocal call_count
            call_count += 1
            # Let the first calls through (signal_copy + writer drain check),
            # then fail on the _read_counters call after semaphore acquire
            if call_count > 3:
                raise RuntimeError("fake Redis failure")
            return original_get(key)

        redis_client.get = failing_get

        with pytest.raises(RuntimeError, match="fake Redis failure"):
            lock.acquire_copy()

        # Restore normal behavior
        redis_client.get = original_get

        # Copy semaphore should have been released — next acquire should work
        lock.acquire_copy()
        lock.release_copy()


class TestContextIsolation:
    """Different context_ids should not interfere."""

    def test_different_contexts(self, redis_client):
        lock_a = _make_lock(redis_client, context_id="ctx_a")
        lock_b = _make_lock(redis_client, context_id="ctx_b")

        # COPY on ctx_a should not block writer on ctx_b
        lock_a.acquire_copy()

        lock_b.acquire_write()
        lock_b.release_write()

        lock_a.release_copy()
