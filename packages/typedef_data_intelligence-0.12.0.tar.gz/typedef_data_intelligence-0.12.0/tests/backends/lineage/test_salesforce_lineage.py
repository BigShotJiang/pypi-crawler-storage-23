"""Tests for Salesforce upstream source integration in lineage queries.

Tests cover:
- DbtSource nodes appear in upstream lineage traversal
- SfObject nodes appear when linked via DEPENDS_ON (DbtSource -> SfObject)
- DEPENDS_ON stitching edges include metadata (confidence, source, rule_id)
- Graceful handling when no Salesforce data exists
- Full lineage chain from DbtSource -> SfObject via DEPENDS_ON
"""
import pytest
from lineage.backends.lineage.models.dbt import DbtModel, DbtSource
from lineage.backends.lineage.models.edges import Builds, DependsOn, SourceDependsOn
from lineage.backends.lineage.models.physical import PhysicalTable
from lineage.backends.lineage.models.salesforce import SfObject

try:
    from lineage.backends.lineage.falkordblite_adapter import FalkorDBLiteAdapter
except ImportError:
    FalkorDBLiteAdapter = None  # type: ignore



@pytest.mark.skipif(FalkorDBLiteAdapter is None, reason="FalkorDBLite not available")
class TestSalesforceLineage:
    """Tests for Salesforce upstream source integration in lineage queries."""

    def test_dbt_source_included_in_lineage(
        self, falkordblite_storage: FalkorDBLiteAdapter
    ) -> None:
        """DbtSource nodes appear in upstream lineage traversal."""
        # Create a DbtSource (external table definition)
        source = DbtSource(
            unique_id="source.salesforce.accounts",
            name="accounts",
            loader="fivetran",
        )

        # Create a staging model that depends on the source
        stg_model = DbtModel(
            unique_id="model.test.stg_accounts",
            name="stg_accounts",
            materialization="view",
        )

        falkordblite_storage.upsert_node(source)
        falkordblite_storage.upsert_node(stg_model)

        # Create dependency: stg_accounts -> source.accounts
        falkordblite_storage.create_edge(
            stg_model,
            source,
            DependsOn(type="source", direct=True),
        )

        # Query upstream lineage from stg_accounts
        result = falkordblite_storage.get_relation_lineage(
            "model.test.stg_accounts",
            node_type="logical",
            direction="upstream",
            depth=3,
        )

        # Verify DbtSource is included in nodes
        node_ids = {n.id for n in result.nodes}
        assert "model.test.stg_accounts" in node_ids
        assert "source.salesforce.accounts" in node_ids

        # Verify DEPENDS_ON edge from model to source
        edge_types = {(e.from_id, e.to_id, e.edge_type) for e in result.edges}
        assert (
            "model.test.stg_accounts",
            "source.salesforce.accounts",
            "DEPENDS_ON",
        ) in edge_types

    def test_salesforce_included_in_lineage(
        self, falkordblite_storage: FalkorDBLiteAdapter
    ) -> None:
        """SfObject nodes appear when linked via DEPENDS_ON (DbtSource -> SfObject)."""
        # Create Salesforce object (name is required by BaseNode, api_name is SF-specific)
        sf_object = SfObject(
            name="Account",
            api_name="Account",
            org_key="00D123456789",
            is_custom=False,
        )

        # Create DbtSource
        source = DbtSource(
            unique_id="source.salesforce.accounts",
            name="accounts",
            loader="fivetran",
        )

        # Create staging model
        stg_model = DbtModel(
            unique_id="model.test.stg_accounts",
            name="stg_accounts",
            materialization="view",
        )

        falkordblite_storage.upsert_node(sf_object)
        falkordblite_storage.upsert_node(source)
        falkordblite_storage.upsert_node(stg_model)

        # Create edges: stg_model -> source, source -> sf_object
        falkordblite_storage.create_edge(
            stg_model,
            source,
            DependsOn(type="source", direct=True),
        )
        falkordblite_storage.create_edge(
            source,
            sf_object,
            SourceDependsOn(source="heuristic", confidence=0.95, rule_id="exact_name"),
        )

        # Query upstream lineage from stg_accounts
        result = falkordblite_storage.get_relation_lineage(
            "model.test.stg_accounts",
            node_type="logical",
            direction="upstream",
            depth=3,
        )

        # Verify SfObject is included in nodes
        node_ids = {n.id for n in result.nodes}
        assert "model.test.stg_accounts" in node_ids
        assert "source.salesforce.accounts" in node_ids
        assert "sf_object::00D123456789::Account" in node_ids

        # Verify SfObject name is populated (uses api_name via COALESCE)
        sf_node = next(n for n in result.nodes if n.id == "sf_object::00D123456789::Account")
        assert sf_node.name == "Account"

    def test_salesforce_stitching_edge_metadata(
        self, falkordblite_storage: FalkorDBLiteAdapter
    ) -> None:
        """DEPENDS_ON stitching edges include metadata (confidence, source, rule_id)."""
        # Create Salesforce object (name is required by BaseNode, api_name is SF-specific)
        sf_object = SfObject(
            name="Opportunity",
            api_name="Opportunity",
            org_key="00D123456789",
            is_custom=False,
        )

        # Create DbtSource
        source = DbtSource(
            unique_id="source.salesforce.opportunities",
            name="opportunities",
            loader="fivetran",
        )

        # Create staging model
        stg_model = DbtModel(
            unique_id="model.test.stg_opportunities",
            name="stg_opportunities",
            materialization="view",
        )

        falkordblite_storage.upsert_node(sf_object)
        falkordblite_storage.upsert_node(source)
        falkordblite_storage.upsert_node(stg_model)

        # Create edges with specific metadata
        falkordblite_storage.create_edge(
            stg_model,
            source,
            DependsOn(type="source", direct=True),
        )
        falkordblite_storage.create_edge(
            source,
            sf_object,
            SourceDependsOn(
                source="llm",
                confidence=0.85,
                rule_id="llm_small_fuzzy",
            ),
        )

        # Query upstream lineage
        result = falkordblite_storage.get_relation_lineage(
            "model.test.stg_opportunities",
            node_type="logical",
            direction="upstream",
            depth=3,
        )

        # Find the stitching edge (DEPENDS_ON with confidence != None)
        stitching_edge = next(
            (e for e in result.edges if e.edge_type == "DEPENDS_ON" and e.confidence is not None),
            None,
        )

        assert stitching_edge is not None
        assert stitching_edge.from_id == "source.salesforce.opportunities"
        assert stitching_edge.to_id == "sf_object::00D123456789::Opportunity"
        assert stitching_edge.confidence == 0.85
        assert stitching_edge.source == "llm"
        assert stitching_edge.rule_id == "llm_small_fuzzy"

    def test_no_salesforce_data_graceful(
        self, falkordblite_storage: FalkorDBLiteAdapter
    ) -> None:
        """Query works when no Salesforce data exists (OPTIONAL MATCH returns NULL)."""
        # Create only dbt models without any Salesforce data
        base = DbtModel(
            unique_id="model.test.base",
            name="base",
            materialization="table",
        )
        final = DbtModel(
            unique_id="model.test.final",
            name="final",
            materialization="table",
        )

        falkordblite_storage.upsert_node(base)
        falkordblite_storage.upsert_node(final)

        falkordblite_storage.create_edge(
            final,
            base,
            DependsOn(type="model", direct=True),
        )

        # Query should work without errors even when no SF data exists
        result = falkordblite_storage.get_relation_lineage(
            "model.test.final",
            node_type="logical",
            direction="upstream",
            depth=3,
        )

        # Verify only dbt models are returned
        node_ids = {n.id for n in result.nodes}
        assert "model.test.final" in node_ids
        assert "model.test.base" in node_ids
        assert len(result.nodes) == 2

        # No SF-related edges
        sf_edges = [e for e in result.edges if "sf_" in e.from_id.lower() or "sf_" in e.to_id.lower()]
        assert len(sf_edges) == 0

    def test_full_lineage_chain(
        self, falkordblite_storage: FalkorDBLiteAdapter
    ) -> None:
        """Complete chain: DbtModel -> DbtSource -> SfObject via DEPENDS_ON."""
        # Create Salesforce object (name is required by BaseNode, api_name is SF-specific)
        sf_object = SfObject(
            name="Account",
            api_name="Account",
            org_key="00D123456789",
            is_custom=False,
        )

        # Create DbtSource
        source = DbtSource(
            unique_id="source.salesforce.accounts",
            name="accounts",
            loader="fivetran",
        )

        # Create staging model
        stg_model = DbtModel(
            unique_id="model.test.stg_accounts",
            name="stg_accounts",
            materialization="view",
        )

        # Create physical table
        physical = PhysicalTable(
            fqn="demo_db.staging.stg_accounts",
            database="demo_db",
            schema_name="staging",
            relation_name="stg_accounts",
            environment="prod",
            warehouse_type="duckdb",
        )

        falkordblite_storage.upsert_node(sf_object)
        falkordblite_storage.upsert_node(source)
        falkordblite_storage.upsert_node(stg_model)
        falkordblite_storage.upsert_node(physical)

        # Create all edges
        falkordblite_storage.create_edge(
            stg_model,
            source,
            DependsOn(type="source", direct=True),
        )
        falkordblite_storage.create_edge(
            source,
            sf_object,
            SourceDependsOn(source="heuristic", confidence=1.0, rule_id="exact_name"),
        )
        falkordblite_storage.create_edge(
            stg_model,
            physical,
            Builds(environment="prod"),
        )

        # Query upstream lineage
        result = falkordblite_storage.get_relation_lineage(
            "model.test.stg_accounts",
            node_type="logical",
            direction="upstream",
            depth=3,
            include_physical=True,
        )

        # Verify complete chain is present
        node_ids = {n.id for n in result.nodes}
        assert "sf_object::00D123456789::Account" in node_ids  # Salesforce
        assert "source.salesforce.accounts" in node_ids        # DbtSource
        assert "model.test.stg_accounts" in node_ids           # DbtModel
        # Physical ID format is physical://{environment}/{fqn}
        assert "physical://prod/demo_db.staging.stg_accounts" in node_ids  # Physical

        # Verify edge types (all upstream edges are now DEPENDS_ON)
        edge_types = {e.edge_type for e in result.edges}
        assert "DEPENDS_ON" in edge_types
        assert "BUILDS" in edge_types

    def test_physical_node_type_includes_salesforce(
        self, falkordblite_storage: FalkorDBLiteAdapter
    ) -> None:
        """SfObject appears when querying from physical node_type."""
        # Create Salesforce object (name is required by BaseNode, api_name is SF-specific)
        sf_object = SfObject(
            name="Contact",
            api_name="Contact",
            org_key="00D123456789",
            is_custom=False,
        )

        # Create DbtSource
        source = DbtSource(
            unique_id="source.salesforce.contacts",
            name="contacts",
            loader="fivetran",
        )

        # Create staging model
        stg_model = DbtModel(
            unique_id="model.test.stg_contacts",
            name="stg_contacts",
            materialization="view",
        )

        # Create physical table
        physical = PhysicalTable(
            fqn="demo_db.staging.stg_contacts",
            database="demo_db",
            schema_name="staging",
            relation_name="stg_contacts",
            environment="prod",
            warehouse_type="duckdb",
        )

        falkordblite_storage.upsert_node(sf_object)
        falkordblite_storage.upsert_node(source)
        falkordblite_storage.upsert_node(stg_model)
        falkordblite_storage.upsert_node(physical)

        # Create all edges
        falkordblite_storage.create_edge(
            stg_model,
            source,
            DependsOn(type="source", direct=True),
        )
        falkordblite_storage.create_edge(
            source,
            sf_object,
            SourceDependsOn(source="heuristic", confidence=1.0, rule_id="exact_name"),
        )
        falkordblite_storage.create_edge(
            stg_model,
            physical,
            Builds(environment="prod"),
        )

        # Query from physical table
        result = falkordblite_storage.get_relation_lineage(
            "demo_db.staging.stg_contacts",
            node_type="physical",
            direction="upstream",
            depth=3,
            include_physical=True,
        )

        # Verify SfObject is included even when starting from physical
        node_ids = {n.id for n in result.nodes}
        assert "sf_object::00D123456789::Contact" in node_ids
        assert "source.salesforce.contacts" in node_ids
