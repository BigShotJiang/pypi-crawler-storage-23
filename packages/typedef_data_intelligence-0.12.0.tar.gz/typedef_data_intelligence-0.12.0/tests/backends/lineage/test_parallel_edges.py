"""Tests for parallel edge persistence via merge_keys.

Verifies that multiple DERIVES_FROM edges between the same node pair are
preserved when they have different column_name values (the merge key).
This was a bug where MERGE without property predicates silently overwrote
parallel edges, keeping only the last one written.
"""

import pytest
from lineage.backends.lineage.models.dbt import CteScope, DbtColumn, DbtModel
from lineage.backends.lineage.models.edges import DerivesFrom
from lineage.backends.types import Confidence

try:
    from lineage.backends.lineage.falkordblite_adapter import FalkorDBLiteAdapter
except ImportError:
    FalkorDBLiteAdapter = None  # type: ignore


def _make_model() -> DbtModel:
    return DbtModel(
        name="stg_events",
        unique_id="model.demo.stg_events",
        database="analytics",
        schema_name="staging",
        materialization="view",
        package_name="demo",
    )


@pytest.mark.skipif(FalkorDBLiteAdapter is None, reason="FalkorDBLite not available")
class TestParallelEdgePersistence:
    """Verify multiple edges between the same node pair survive via merge_keys."""

    def test_parallel_derives_from_between_cte_scopes(
        self, falkordblite_storage: "FalkorDBLiteAdapter"
    ) -> None:
        """Multiple CteScope->CteScope DERIVES_FROM with different column_name are preserved."""
        storage = falkordblite_storage
        model = _make_model()
        storage.upsert_node(model)

        # Create two CTE scopes
        renamed = CteScope(name="RENAMED", model_id=model.unique_id)
        source = CteScope(name="SOURCE", model_id=model.unique_id)
        storage.upsert_node(renamed)
        storage.upsert_node(source)

        # Create three parallel DERIVES_FROM edges: RENAMED -> SOURCE
        # Each has a different column_name (the merge key)
        columns = ["customer_email", "company_name", "expire_at"]
        transformations = ["extraction", "extraction", "passthrough"]

        for col, trans in zip(columns, transformations, strict=True):
            edge = DerivesFrom(
                confidence=Confidence.HIGH,
                transformation=trans,
                column_name=col,
                upstream_column="PAYLOAD",
                scope="RENAMED",
            )
            storage.create_edge(renamed, source, edge)

        # Query back all DERIVES_FROM edges between these two nodes
        result = storage.graph.query(
            """
            MATCH (a:CteScope {id: $from_id})-[r:DERIVES_FROM]->(b:CteScope {id: $to_id})
            RETURN r.column_name AS col, r.transformation AS trans
            ORDER BY r.column_name
            """,
            {"from_id": renamed.id, "to_id": source.id},
        )

        found = [(row[0], row[1]) for row in result.result_set]
        assert len(found) == 3, (
            f"Expected 3 parallel edges, got {len(found)}: {found}"
        )
        assert ("company_name", "extraction") in found
        assert ("customer_email", "extraction") in found
        assert ("expire_at", "passthrough") in found

    def test_same_column_name_still_deduplicates(
        self, falkordblite_storage: "FalkorDBLiteAdapter"
    ) -> None:
        """Edges with same (from, to, column_name) should still merge (upsert)."""
        storage = falkordblite_storage
        model = _make_model()
        storage.upsert_node(model)

        renamed = CteScope(name="RENAMED", model_id=model.unique_id)
        source = CteScope(name="SOURCE", model_id=model.unique_id)
        storage.upsert_node(renamed)
        storage.upsert_node(source)

        # Write same column_name twice with different transformation
        for trans in ["passthrough", "extraction"]:
            edge = DerivesFrom(
                confidence=Confidence.HIGH,
                transformation=trans,
                column_name="customer_email",
                upstream_column="PAYLOAD",
                scope="RENAMED",
            )
            storage.create_edge(renamed, source, edge)

        result = storage.graph.query(
            """
            MATCH (a:CteScope {id: $from_id})-[r:DERIVES_FROM]->(b:CteScope {id: $to_id})
            RETURN r.column_name AS col, r.transformation AS trans
            """,
            {"from_id": renamed.id, "to_id": source.id},
        )

        found = [(row[0], row[1]) for row in result.result_set]
        assert len(found) == 1, (
            f"Expected 1 edge (deduplication), got {len(found)}: {found}"
        )
        # Last write wins on MERGE match
        assert found[0] == ("customer_email", "extraction")

    def test_null_column_name_falls_back_to_simple_merge(
        self, falkordblite_storage: "FalkorDBLiteAdapter"
    ) -> None:
        """Edges without column_name use simple MERGE (no merge key)."""
        storage = falkordblite_storage
        model = _make_model()
        storage.upsert_node(model)

        col_a = DbtColumn(
            name="email",
            unique_id="model.demo.stg_events",
            column_name="email",
        )
        col_b = DbtColumn(
            name="raw_email",
            unique_id="model.demo.raw_events",
            column_name="raw_email",
        )
        storage.upsert_node(col_a)
        storage.upsert_node(col_b)

        # Two writes with no column_name — should merge into one edge
        for trans in ["passthrough", "renamed"]:
            edge = DerivesFrom(
                confidence=Confidence.HIGH,
                transformation=trans,
            )
            storage.create_edge(col_a, col_b, edge)

        result = storage.graph.query(
            """
            MATCH (a:DbtColumn {id: $from_id})-[r:DERIVES_FROM]->(b:DbtColumn {id: $to_id})
            RETURN r.transformation AS trans
            """,
            {"from_id": col_a.id, "to_id": col_b.id},
        )

        found = [row[0] for row in result.result_set]
        assert len(found) == 1, (
            f"Expected 1 edge (simple merge), got {len(found)}: {found}"
        )
