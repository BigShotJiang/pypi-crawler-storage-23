"""Unit tests for Salesforce auth strategies."""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from lineage.ingest.static_loaders.salesforce.auth.client_creds import (
    ClientCredentialsAuth,
)
from lineage.ingest.static_loaders.salesforce.auth.device_flow import (
    OAuthDeviceFlowAuth,
)
from lineage.ingest.static_loaders.salesforce.auth.jwt_bearer import JWTBearerAuth
from lineage.ingest.static_loaders.salesforce.auth.oauth_pkce import (
    OAuthPKCEAuth,
    _generate_code_challenge,
    _generate_code_verifier,
)
from lineage.ingest.static_loaders.salesforce.auth.password import PasswordAuth
from lineage.ingest.static_loaders.salesforce.auth.protocol import (
    SalesforceCredentials,
)
from lineage.ingest.static_loaders.salesforce.auth.token_store import (
    StoredTokens,
    TokenStore,
)

# ---------------------------------------------------------------------------
# Protocol compliance
# ---------------------------------------------------------------------------

class TestProtocol:
    def test_password_auth_is_not_runtime_checkable_as_auth(self) -> None:
        """PasswordAuth raises NotImplementedError on authenticate/refresh,
        but it still structurally matches the protocol."""
        pa = PasswordAuth(
            instance_url="https://test.sf.com",
            username="user",
            password="pass",
            security_token="tok",
        )
        # PasswordAuth has the methods (even though they raise)
        assert hasattr(pa, "authenticate")
        assert hasattr(pa, "refresh_if_needed")

    def test_credentials_namedtuple(self) -> None:
        creds = SalesforceCredentials(
            access_token="tok123", instance_url="https://test.sf.com"
        )
        assert creds.access_token == "tok123"
        assert creds.instance_url == "https://test.sf.com"


# ---------------------------------------------------------------------------
# PasswordAuth
# ---------------------------------------------------------------------------

class TestPasswordAuth:
    def test_stores_credentials(self) -> None:
        pa = PasswordAuth(
            instance_url="https://test.sf.com",
            username="user",
            password="pass",
            security_token="tok",
        )
        assert pa.instance_url == "https://test.sf.com"
        assert pa.username == "user"
        assert pa.password == "pass"
        assert pa.security_token == "tok"

    def test_authenticate_raises(self) -> None:
        pa = PasswordAuth("https://x", "u", "p", "t")
        with pytest.raises(NotImplementedError):
            pa.authenticate()

    def test_refresh_raises(self) -> None:
        pa = PasswordAuth("https://x", "u", "p", "t")
        with pytest.raises(NotImplementedError):
            pa.refresh_if_needed()


# ---------------------------------------------------------------------------
# TokenStore
# ---------------------------------------------------------------------------

class TestTokenStore:
    def test_save_and_load_file_fallback(self, tmp_path: Path) -> None:
        """Test file-based store when keyring is unavailable."""
        store = TokenStore(org_key="test-org")
        store._keyring_available = False  # Force file fallback

        tokens = StoredTokens(
            access_token="acc123",
            instance_url="https://test.sf.com",
            refresh_token="ref456",
            org_key="test-org",
        )

        with patch(
            "lineage.ingest.static_loaders.salesforce.auth.token_store._FILE_STORE_DIR",
            tmp_path,
        ), patch(
            "lineage.ingest.static_loaders.salesforce.auth.token_store._FILE_STORE_PATH",
            tmp_path / "salesforce_tokens.json",
        ):
            store.save(tokens)
            loaded = store.load()

        assert loaded is not None
        assert loaded.access_token == "acc123"
        assert loaded.instance_url == "https://test.sf.com"
        assert loaded.refresh_token == "ref456"

    def test_load_returns_none_when_empty(self, tmp_path: Path) -> None:
        store = TokenStore(org_key="missing-org")
        store._keyring_available = False

        with patch(
            "lineage.ingest.static_loaders.salesforce.auth.token_store._FILE_STORE_PATH",
            tmp_path / "nonexistent.json",
        ):
            assert store.load() is None

    def test_clear_removes_org_key(self, tmp_path: Path) -> None:
        store = TokenStore(org_key="test-org")
        store._keyring_available = False

        tokens = StoredTokens(
            access_token="acc", instance_url="https://x", org_key="test-org"
        )

        file_path = tmp_path / "salesforce_tokens.json"
        with patch(
            "lineage.ingest.static_loaders.salesforce.auth.token_store._FILE_STORE_DIR",
            tmp_path,
        ), patch(
            "lineage.ingest.static_loaders.salesforce.auth.token_store._FILE_STORE_PATH",
            file_path,
        ):
            store.save(tokens)
            assert store.load() is not None
            store.clear()
            assert store.load() is None

    def test_corrupt_data_cleared(self, tmp_path: Path) -> None:
        store = TokenStore(org_key="test-org")
        store._keyring_available = False

        file_path = tmp_path / "salesforce_tokens.json"
        file_path.write_text("{not valid json")

        with patch(
            "lineage.ingest.static_loaders.salesforce.auth.token_store._FILE_STORE_DIR",
            tmp_path,
        ), patch(
            "lineage.ingest.static_loaders.salesforce.auth.token_store._FILE_STORE_PATH",
            file_path,
        ):
            result = store.load()
            assert result is None

    def test_multi_org_isolation(self, tmp_path: Path) -> None:
        """Two org_keys in the same file store don't interfere."""
        file_path = tmp_path / "salesforce_tokens.json"

        store_a = TokenStore(org_key="org-a")
        store_a._keyring_available = False
        store_b = TokenStore(org_key="org-b")
        store_b._keyring_available = False

        tokens_a = StoredTokens(access_token="aaa", instance_url="https://a.sf.com", org_key="org-a")
        tokens_b = StoredTokens(access_token="bbb", instance_url="https://b.sf.com", org_key="org-b")

        with patch(
            "lineage.ingest.static_loaders.salesforce.auth.token_store._FILE_STORE_DIR",
            tmp_path,
        ), patch(
            "lineage.ingest.static_loaders.salesforce.auth.token_store._FILE_STORE_PATH",
            file_path,
        ):
            store_a.save(tokens_a)
            store_b.save(tokens_b)

            loaded_a = store_a.load()
            loaded_b = store_b.load()

        assert loaded_a is not None and loaded_a.access_token == "aaa"
        assert loaded_b is not None and loaded_b.access_token == "bbb"


# ---------------------------------------------------------------------------
# PKCE helpers
# ---------------------------------------------------------------------------

class TestPKCE:
    def test_code_verifier_length(self) -> None:
        verifier = _generate_code_verifier()
        assert 43 <= len(verifier) <= 128

    def test_code_challenge_is_s256(self) -> None:
        verifier = _generate_code_verifier()
        challenge = _generate_code_challenge(verifier)
        # S256 challenge should be base64url-encoded (no padding)
        assert "=" not in challenge
        assert len(challenge) > 0

    def test_different_verifiers_produce_different_challenges(self) -> None:
        v1 = _generate_code_verifier()
        v2 = _generate_code_verifier()
        assert _generate_code_challenge(v1) != _generate_code_challenge(v2)


# ---------------------------------------------------------------------------
# OAuthPKCEAuth
# ---------------------------------------------------------------------------

class TestOAuthPKCEAuth:
    def test_redirect_uri(self) -> None:
        auth = OAuthPKCEAuth(client_id="test-key", callback_port=9999)
        assert auth.redirect_uri == "http://localhost:9999/callback"

    @patch("lineage.ingest.static_loaders.salesforce.auth.oauth_pkce.httpx.post")
    @patch("lineage.ingest.static_loaders.salesforce.auth.oauth_pkce.wait_for_callback")
    @patch("lineage.ingest.static_loaders.salesforce.auth.oauth_pkce.start_callback_server")
    @patch.object(OAuthPKCEAuth, "_open_browser", return_value=True)
    @patch("lineage.ingest.static_loaders.salesforce.auth.oauth_pkce.secrets.token_urlsafe", return_value="test-state-value")
    def test_authenticate_full_flow(
        self, mock_token: MagicMock, mock_browser: MagicMock, mock_start: MagicMock, mock_wait: MagicMock, mock_post: MagicMock
    ) -> None:
        """Test the full PKCE flow with mocked HTTP and browser."""
        mock_server = MagicMock()
        mock_ready = MagicMock()
        mock_start.return_value = (mock_server, mock_ready)
        mock_wait.return_value = ("auth-code-123", "test-state-value")
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "access_token": "access-tok",
            "instance_url": "https://myorg.my.salesforce.com",
            "refresh_token": "refresh-tok",
            "token_type": "Bearer",
            "issued_at": "12345",
        }
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        auth = OAuthPKCEAuth(client_id="test-key")
        # Clear any cached tokens
        auth._token_store = MagicMock()
        auth._token_store.load.return_value = None

        creds = auth.authenticate()

        assert creds.access_token == "access-tok"
        assert creds.instance_url == "https://myorg.my.salesforce.com"
        mock_start.assert_called_once()
        mock_wait.assert_called_once_with(mock_server)
        mock_post.assert_called_once()

    @patch("lineage.ingest.static_loaders.salesforce.auth.oauth_pkce.httpx.post")
    def test_refresh_uses_refresh_token(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "access_token": "new-access",
            "instance_url": "https://myorg.my.salesforce.com",
            "token_type": "Bearer",
        }
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        auth = OAuthPKCEAuth(client_id="test-key")
        auth._token_store = MagicMock()
        auth._token_store.load.return_value = StoredTokens(
            access_token="old", instance_url="https://x", refresh_token="ref-tok"
        )

        creds = auth.refresh_if_needed()

        assert creds.access_token == "new-access"
        # Verify refresh_token grant was used
        call_data = mock_post.call_args
        assert call_data[1]["data"]["grant_type"] == "refresh_token"


# ---------------------------------------------------------------------------
# ClientCredentialsAuth
# ---------------------------------------------------------------------------

class TestClientCredentialsAuth:
    @patch("lineage.ingest.static_loaders.salesforce.auth.client_creds.httpx.post")
    def test_authenticate(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "cc-tok",
            "instance_url": "https://cc.sf.com",
        }
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        auth = ClientCredentialsAuth(client_id="cid", client_secret="csecret")
        creds = auth.authenticate()

        assert creds.access_token == "cc-tok"
        assert creds.instance_url == "https://cc.sf.com"
        call_data = mock_post.call_args[1]["data"]
        assert call_data["grant_type"] == "client_credentials"

    @patch("lineage.ingest.static_loaders.salesforce.auth.client_creds.httpx.post")
    def test_refresh_re_authenticates(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "cc-tok-2",
            "instance_url": "https://cc.sf.com",
        }
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        auth = ClientCredentialsAuth(client_id="cid", client_secret="csecret")
        creds = auth.refresh_if_needed()

        assert creds.access_token == "cc-tok-2"


# ---------------------------------------------------------------------------
# JWTBearerAuth
# ---------------------------------------------------------------------------

class TestJWTBearerAuth:
    @patch("lineage.ingest.static_loaders.salesforce.auth.jwt_bearer.httpx.post")
    def test_authenticate(self, mock_post: MagicMock, tmp_path: Path) -> None:
        # Create a test private key
        key_path = tmp_path / "test_key.pem"
        key_path.write_text("-----BEGIN RSA PRIVATE KEY-----\nfake\n-----END RSA PRIVATE KEY-----")

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "access_token": "jwt-tok",
            "instance_url": "https://jwt.sf.com",
        }
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        # Create a mock jwt module and inject it so `import jwt` finds it
        mock_jwt = MagicMock()
        mock_jwt.encode.return_value = "signed-assertion"

        with patch.dict("sys.modules", {"jwt": mock_jwt}):
            auth = JWTBearerAuth(
                client_id="jwt-cid",
                username="user@test.com",
                private_key_path=key_path,
            )
            creds = auth.authenticate()

            assert creds.access_token == "jwt-tok"
            assert creds.instance_url == "https://jwt.sf.com"

            # Verify JWT was built correctly
            jwt_call = mock_jwt.encode.call_args
            payload = jwt_call[0][0]
            assert payload["iss"] == "jwt-cid"
            assert payload["sub"] == "user@test.com"
            assert payload["aud"] == "https://login.salesforce.com"
            assert "exp" in payload

            # Verify assertion was posted
            post_data = mock_post.call_args[1]["data"]
            assert post_data["grant_type"] == "urn:ietf:params:oauth:grant-type:jwt-bearer"
            assert post_data["assertion"] == "signed-assertion"

    def test_missing_pyjwt_raises(self, tmp_path: Path) -> None:
        key_path = tmp_path / "test_key.pem"
        key_path.write_text("fake key")

        auth = JWTBearerAuth(
            client_id="cid", username="u", private_key_path=key_path
        )

        with patch.dict("sys.modules", {"jwt": None}):
            with pytest.raises(ImportError, match="PyJWT"):
                auth.authenticate()


# ---------------------------------------------------------------------------
# OAuthDeviceFlowAuth
# ---------------------------------------------------------------------------

class TestOAuthDeviceFlowAuth:
    @patch("lineage.ingest.static_loaders.salesforce.auth.device_flow.httpx.post")
    @patch("lineage.ingest.static_loaders.salesforce.auth.device_flow.time.sleep")
    @patch("lineage.ingest.static_loaders.salesforce.auth.device_flow.webbrowser.open")
    def test_authenticate_full_flow(
        self, mock_browser: MagicMock, mock_sleep: MagicMock, mock_post: MagicMock
    ) -> None:
        """Test device flow: request code, poll, get token."""
        # First call: device code request
        device_response = MagicMock()
        device_response.status_code = 200
        device_response.json.return_value = {
            "device_code": "dev-code-123",
            "user_code": "ABCD-1234",
            "verification_uri": "https://login.salesforce.com/setup/connect",
            "interval": 1,
        }
        device_response.raise_for_status = MagicMock()

        # Second call: pending
        pending_response = MagicMock()
        pending_response.status_code = 400
        pending_response.json.return_value = {"error": "authorization_pending"}

        # Third call: success
        token_response = MagicMock()
        token_response.status_code = 200
        token_response.json.return_value = {
            "access_token": "device-tok",
            "instance_url": "https://myorg.sf.com",
            "refresh_token": "device-ref",
            "token_type": "Bearer",
        }

        mock_post.side_effect = [device_response, pending_response, token_response]

        auth = OAuthDeviceFlowAuth(client_id="test-key")
        auth._token_store = MagicMock()
        auth._token_store.load.return_value = None

        creds = auth.authenticate()

        assert creds.access_token == "device-tok"
        assert creds.instance_url == "https://myorg.sf.com"
        assert mock_post.call_count == 3
        # sleep called twice (once for pending, once for success poll)
        assert mock_sleep.call_count == 2

    @patch("lineage.ingest.static_loaders.salesforce.auth.device_flow.httpx.post")
    @patch("lineage.ingest.static_loaders.salesforce.auth.device_flow.time.sleep")
    @patch("lineage.ingest.static_loaders.salesforce.auth.device_flow.webbrowser.open")
    def test_expired_token_raises(
        self, mock_browser: MagicMock, mock_sleep: MagicMock, mock_post: MagicMock
    ) -> None:
        device_response = MagicMock()
        device_response.status_code = 200
        device_response.json.return_value = {
            "device_code": "dev-code",
            "user_code": "ABCD",
            "verification_uri": "https://login.salesforce.com/setup/connect",
            "interval": 1,
        }
        device_response.raise_for_status = MagicMock()

        expired_response = MagicMock()
        expired_response.status_code = 400
        expired_response.json.return_value = {"error": "expired_token"}

        mock_post.side_effect = [device_response, expired_response]

        auth = OAuthDeviceFlowAuth(client_id="test-key")
        auth._token_store = MagicMock()
        auth._token_store.load.return_value = None

        with pytest.raises(TimeoutError, match="expired"):
            auth.authenticate()

    @patch("lineage.ingest.static_loaders.salesforce.auth.device_flow.httpx.post")
    @patch("lineage.ingest.static_loaders.salesforce.auth.device_flow.time.sleep")
    @patch("lineage.ingest.static_loaders.salesforce.auth.device_flow.webbrowser.open")
    def test_slow_down_increases_interval(
        self, mock_browser: MagicMock, mock_sleep: MagicMock, mock_post: MagicMock
    ) -> None:
        device_response = MagicMock()
        device_response.status_code = 200
        device_response.json.return_value = {
            "device_code": "dev-code",
            "user_code": "ABCD",
            "verification_uri": "https://login.salesforce.com/setup/connect",
            "interval": 2,
        }
        device_response.raise_for_status = MagicMock()

        slow_response = MagicMock()
        slow_response.status_code = 400
        slow_response.json.return_value = {"error": "slow_down"}

        token_response = MagicMock()
        token_response.status_code = 200
        token_response.json.return_value = {
            "access_token": "tok",
            "instance_url": "https://x.sf.com",
        }

        mock_post.side_effect = [device_response, slow_response, token_response]

        auth = OAuthDeviceFlowAuth(client_id="test-key")
        auth._token_store = MagicMock()
        auth._token_store.load.return_value = None

        auth.authenticate()

        # First sleep with interval=2, second sleep with interval=7 (2+5)
        assert mock_sleep.call_args_list[0][0][0] == 2
        assert mock_sleep.call_args_list[1][0][0] == 7

    @patch("lineage.ingest.static_loaders.salesforce.auth.device_flow.httpx.post")
    def test_refresh_uses_refresh_token(self, mock_post: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "access_token": "refreshed-tok",
            "instance_url": "https://myorg.sf.com",
        }
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        auth = OAuthDeviceFlowAuth(client_id="test-key")
        auth._token_store = MagicMock()
        auth._token_store.load.return_value = StoredTokens(
            access_token="old", instance_url="https://x", refresh_token="ref-tok"
        )

        creds = auth.refresh_if_needed()

        assert creds.access_token == "refreshed-tok"
        call_data = mock_post.call_args[1]["data"]
        assert call_data["grant_type"] == "refresh_token"


# ---------------------------------------------------------------------------
# Client integration (auth path selection)
# ---------------------------------------------------------------------------

class TestClientAuthSelection:
    def test_legacy_kwargs_create_password_auth(self) -> None:
        from lineage.ingest.static_loaders.salesforce.client import (
            SalesforceMetadataClient,
        )

        client = SalesforceMetadataClient(
            instance_url="https://test.sf.com",
            username="user",
            password="pass",
            security_token="tok",
        )
        assert isinstance(client.auth, PasswordAuth)

    def test_explicit_auth_preserved(self) -> None:
        from lineage.ingest.static_loaders.salesforce.client import (
            SalesforceMetadataClient,
        )

        mock_auth = MagicMock()
        client = SalesforceMetadataClient(auth=mock_auth)
        assert client.auth is mock_auth

    def test_no_auth_no_creds_leaves_auth_none(self) -> None:
        from lineage.ingest.static_loaders.salesforce.client import (
            SalesforceMetadataClient,
        )

        client = SalesforceMetadataClient()
        assert client.auth is None

    def test_connect_raises_without_auth(self) -> None:
        from lineage.ingest.static_loaders.salesforce.client import (
            SalesforceMetadataClient,
        )

        # Mock simple_salesforce so the ImportError doesn't fire first
        mock_sf_module = MagicMock()
        with patch.dict("sys.modules", {"simple_salesforce": mock_sf_module}):
            client = SalesforceMetadataClient()
            with pytest.raises(ValueError, match="No authentication provided"):
                client._connect()
