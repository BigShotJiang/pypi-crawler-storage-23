"""Tests for domain knowledge skills factory."""

from __future__ import annotations

import logging
from unittest.mock import MagicMock

from lineage.agent.pydantic.skills_factory import (
    _SKILLS_DIR,
    create_domain_skills_toolset,
    create_filtered_skills_toolset,
)

# Expected static skill names from the skills/ directory
EXPECTED_STATIC_SKILLS = {
    "cypher-patterns",
    "upstream-tracing",
    "data-quality-diagnostics",
    "dbt-conventions",
    "risk-analysis",
    "visualization-guide",
    "git-workflow",
    "diagnostic-workflow",
    "additive-workflow",
}


def _get_skill_names(ts) -> set[str]:
    """Extract skill names from a SkillsToolset's internal _skills dict."""
    skills = ts._skills or {}
    return {s.name for s in skills.values()}


def _mock_lineage_backend(*, schema="Node types: DbtModel, PhysicalTable", hints="FalkorDB OpenCypher"):
    """Create a mock lineage backend with configurable schema and hints."""
    mock = MagicMock()
    mock.get_graph_schema.return_value = schema
    mock.get_agent_hints.return_value = hints
    return mock


class TestCreateDomainSkillsToolset:
    """Tests for create_domain_skills_toolset factory function."""

    def test_discovers_all_static_skills(self):
        """All static SKILL.md files should be discovered."""
        ts = create_domain_skills_toolset()
        skill_names = _get_skill_names(ts)
        expected_count = len(EXPECTED_STATIC_SKILLS)
        assert len(skill_names) == expected_count, (
            f"Expected {expected_count} static skills, got {len(skill_names)}: {skill_names}"
        )

    def test_expected_skill_names_present(self):
        """Each expected skill name should be discoverable."""
        ts = create_domain_skills_toolset()
        skill_names = _get_skill_names(ts)
        assert EXPECTED_STATIC_SKILLS == skill_names, f"Missing: {EXPECTED_STATIC_SKILLS - skill_names}"

    def test_excludes_run_skill_script(self):
        """run_skill_script tool should be excluded."""
        ts = create_domain_skills_toolset()
        tool_names = {name for name, _ in ts.tools.items()}
        assert "run_skill_script" not in tool_names

    def test_has_expected_tools(self):
        """Should have list_skills, load_skill, and read_skill_resource."""
        ts = create_domain_skills_toolset()
        tool_names = {name for name, _ in ts.tools.items()}
        assert tool_names == {"list_skills", "load_skill", "read_skill_resource"}

    def test_runtime_skills_with_lineage_backend(self):
        """When lineage_backend is provided, both graph-schema and cypher-dialect runtime skills should be created."""
        mock_backend = _mock_lineage_backend()

        ts = create_domain_skills_toolset(lineage_backend=mock_backend)
        skill_names = _get_skill_names(ts)

        assert "graph-schema" in skill_names
        assert "cypher-dialect" in skill_names
        # 9 static + 2 runtime = 11
        assert len(skill_names) == 11, f"Expected 11 skills (9 static + 2 runtime), got {len(skill_names)}"

    def test_graph_schema_content(self):
        """graph-schema skill should contain the schema summary from the backend."""
        mock_backend = _mock_lineage_backend(schema="DbtModel, PhysicalTable, DEPENDS_ON")

        ts = create_domain_skills_toolset(lineage_backend=mock_backend)
        skills_dict = ts._skills or {}
        schema_skill = next(s for s in skills_dict.values() if s.name == "graph-schema")
        assert "DbtModel" in schema_skill.content
        assert "DEPENDS_ON" in schema_skill.content

    def test_cypher_dialect_content(self):
        """cypher-dialect skill should contain the hints from the backend."""
        mock_backend = _mock_lineage_backend(hints="FalkorDB uses OpenCypher dialect with some differences.")

        ts = create_domain_skills_toolset(lineage_backend=mock_backend)
        skills_dict = ts._skills or {}
        cypher_skill = next(s for s in skills_dict.values() if s.name == "cypher-dialect")
        assert "FalkorDB" in cypher_skill.content

    def test_no_runtime_skills_without_lineage_backend(self):
        """Without lineage_backend, only static skills should be present."""
        ts = create_domain_skills_toolset()
        skill_names = _get_skill_names(ts)
        assert "cypher-dialect" not in skill_names
        assert "graph-schema" not in skill_names
        assert skill_names == EXPECTED_STATIC_SKILLS

    def test_no_cypher_dialect_when_hints_empty(self):
        """When lineage_backend returns empty hints, no cypher-dialect skill."""
        mock_backend = _mock_lineage_backend(hints="")

        ts = create_domain_skills_toolset(lineage_backend=mock_backend)
        skill_names = _get_skill_names(ts)
        assert "cypher-dialect" not in skill_names
        # graph-schema should still be present
        assert "graph-schema" in skill_names

    def test_no_cypher_dialect_when_hints_none(self):
        """When lineage_backend returns None hints, no cypher-dialect skill."""
        mock_backend = _mock_lineage_backend(hints=None)

        ts = create_domain_skills_toolset(lineage_backend=mock_backend)
        skill_names = _get_skill_names(ts)
        assert "cypher-dialect" not in skill_names

    def test_no_graph_schema_when_schema_empty(self):
        """When lineage_backend returns empty schema, no graph-schema skill."""
        mock_backend = _mock_lineage_backend(schema="")

        ts = create_domain_skills_toolset(lineage_backend=mock_backend)
        skill_names = _get_skill_names(ts)
        assert "graph-schema" not in skill_names
        # cypher-dialect should still be present
        assert "cypher-dialect" in skill_names

    def test_graceful_handling_of_schema_error(self):
        """If get_graph_schema() raises, should continue without graph-schema skill."""
        mock_backend = MagicMock()
        mock_backend.get_graph_schema.side_effect = RuntimeError("connection failed")
        mock_backend.get_agent_hints.return_value = "FalkorDB hints"

        ts = create_domain_skills_toolset(lineage_backend=mock_backend)
        skill_names = _get_skill_names(ts)
        assert "graph-schema" not in skill_names
        # cypher-dialect should still work
        assert "cypher-dialect" in skill_names
        # Static skills should still be present
        assert EXPECTED_STATIC_SKILLS <= skill_names

    def test_graceful_handling_of_hints_error(self):
        """If get_agent_hints() raises, should continue without cypher-dialect skill."""
        mock_backend = MagicMock()
        mock_backend.get_graph_schema.return_value = "DbtModel schema"
        mock_backend.get_agent_hints.side_effect = RuntimeError("connection failed")

        ts = create_domain_skills_toolset(lineage_backend=mock_backend)
        skill_names = _get_skill_names(ts)
        assert "cypher-dialect" not in skill_names
        # graph-schema should still work
        assert "graph-schema" in skill_names
        # Static skills should still be present
        assert EXPECTED_STATIC_SKILLS <= skill_names

    def test_extra_skills_included(self):
        """Extra skills should be included alongside static skills."""
        from pydantic_ai_skills import Skill

        extra = Skill(
            name="custom-skill",
            description="A custom skill for testing",
            content="Custom content",
        )
        ts = create_domain_skills_toolset(extra_skills=[extra])
        skill_names = _get_skill_names(ts)
        assert "custom-skill" in skill_names
        # 9 static + 1 extra = 10
        assert len(skill_names) == 10

    def test_skills_dir_exists(self):
        """The skills directory should exist at the expected path."""
        assert _SKILLS_DIR.exists(), f"Skills directory not found: {_SKILLS_DIR}"
        assert _SKILLS_DIR.is_dir()

    def test_visualization_guide_has_mermaid_content(self):
        """visualization-guide skill should include mermaid diagram examples."""
        skill_file = _SKILLS_DIR / "visualization-guide" / "SKILL.md"
        assert skill_file.exists(), f"Skill file not found: {skill_file}"
        content = skill_file.read_text()
        assert "flowchart TB" in content, "Missing mermaid flowchart examples"
        assert "erDiagram" in content, "Missing mermaid ER diagram examples"

    def test_diagnostic_workflow_has_phases(self):
        """diagnostic-workflow skill should include phases and mechanic handoff."""
        skill_file = _SKILLS_DIR / "diagnostic-workflow" / "SKILL.md"
        assert skill_file.exists(), f"Skill file not found: {skill_file}"
        content = skill_file.read_text()
        assert "Phase 1" in content, "Missing Phase 1"
        assert "mechanic" in content.lower(), "Missing mechanic handoff"
        assert "upstream-tracing" in content, "Missing upstream-tracing prerequisite"

    def test_additive_workflow_has_phases(self):
        """additive-workflow skill should include phases and executor handoff."""
        skill_file = _SKILLS_DIR / "additive-workflow" / "SKILL.md"
        assert skill_file.exists(), f"Skill file not found: {skill_file}"
        content = skill_file.read_text()
        assert "Phase 1" in content, "Missing Phase 1"
        assert "executor" in content.lower(), "Missing executor handoff"
        assert "dbt-conventions" in content, "Missing dbt-conventions prerequisite"

    def test_filtered_toolset_contains_only_allowed_skills(self):
        """create_filtered_skills_toolset should include only the listed skills."""
        full_ts = create_domain_skills_toolset()
        allowed = ["cypher-patterns", "dbt-conventions"]

        filtered_ts = create_filtered_skills_toolset(full_ts, allowed_skills=allowed)
        skill_names = _get_skill_names(filtered_ts)

        assert skill_names == set(allowed), f"Expected {allowed}, got {skill_names}"

    def test_filtered_toolset_warns_on_unknown_skills(self):
        """create_filtered_skills_toolset should warn when an allowed skill doesn't exist."""
        full_ts = create_domain_skills_toolset()

        with self._assert_warning(logging.WARNING, "does-not-exist"):
            create_filtered_skills_toolset(full_ts, allowed_skills=["cypher-patterns", "does-not-exist"])

    @staticmethod
    def _assert_warning(level: int, expected_text: str):
        """Context manager that asserts a log record containing expected_text was emitted."""
        import contextlib

        @contextlib.contextmanager
        def _ctx():
            with _CapturingHandler(level) as handler:
                yield
            messages = [r.getMessage() for r in handler.records]
            assert any(expected_text in m for m in messages), (
                f"Expected log containing {expected_text!r}, got: {messages}"
            )

        return _ctx()


class _CapturingHandler(logging.Handler):
    """Minimal log handler that captures records within a with-block."""

    def __init__(self, level: int) -> None:
        super().__init__(level)
        self.records: list[logging.LogRecord] = []
        self._logger = logging.getLogger("lineage.agent.pydantic.skills_factory")
        self._orig_level: int = self._logger.level

    def emit(self, record: logging.LogRecord) -> None:
        self.records.append(record)

    def __enter__(self) -> "_CapturingHandler":
        self._logger.addHandler(self)
        self._logger.setLevel(self.level)
        return self

    def __exit__(self, *_) -> None:
        self._logger.removeHandler(self)
        self._logger.setLevel(self._orig_level)
